<template>
  <a-layout class="app-shell">
    <header class="platform-header">
      <div class="platform-header-inner">
        <div class="platform-brand">
          <div class="platform-logo" aria-hidden="true"><ApiOutlined /></div>
          <div class="platform-brand-copy">
            <div class="platform-title">开发者门户</div>
            <div class="platform-subtitle">Developer Platform for API, Docs and AI Tools</div>
          </div>
        </div>
        <nav class="platform-nav" aria-label="平台导航">
          <template v-for="item in platformMenu" :key="item">
            <a-dropdown
              v-if="item === 'AI工具'"
              v-model:open="aiToolsOpen"
              :trigger="['hover', 'click']"
              placement="bottomLeft"
            >
              <button
                type="button"
                class="platform-nav-item"
                :class="{ 'is-active': !isPermissionPage }"
                aria-haspopup="menu"
                :aria-expanded="aiToolsOpen"
              >
                {{ item }}
              </button>
              <template #overlay>
                <a-menu
                  class="ai-tools-menu"
                  aria-label="AI工具"
                  :selectedKeys="selectedAiToolKeys"
                  @click="handleAiToolClick"
                >
                  <a-menu-item v-for="tool in unavailableAiTools" :key="tool" disabled title="将在平台集成后开放">
                    {{ tool }}
                  </a-menu-item>
                  <a-menu-item v-for="tool in availableAiTools" :key="tool.key">
                    <router-link :to="tool.path" :aria-current="selectedAiToolKeys.includes(tool.key) ? 'page' : undefined">
                      {{ tool.label }}
                    </router-link>
                  </a-menu-item>
                </a-menu>
              </template>
            </a-dropdown>
            <a-dropdown
              v-else-if="item === '权限'"
              v-model:open="permissionsOpen"
              :trigger="['hover', 'click']"
              placement="bottomLeft"
            >
              <button type="button" class="platform-nav-item" :class="{ 'is-active': isPermissionPage }" aria-haspopup="menu" :aria-expanded="permissionsOpen">
                {{ item }}
              </button>
              <template #overlay>
                <a-menu class="ai-tools-menu" aria-label="权限" :selectedKeys="isPermissionPage ? ['permissions'] : []" @click="permissionsOpen = false">
                  <a-menu-item key="permissions">
                    <router-link to="/permissions/users">权限管理</router-link>
                  </a-menu-item>
                </a-menu>
              </template>
            </a-dropdown>
            <button v-else type="button" class="platform-nav-item" disabled :title="`${item}将在平台集成后开放`">
              {{ item }}
            </button>
          </template>
        </nav>
        <div class="header-account">
          <div class="user-info" :title="userStore.state.currentUser?.email || username">
            <a-avatar :size="30" class="user-avatar">{{ userInitial }}</a-avatar>
            <span class="username" :title="username">{{ username }}</span>
          </div>
          <a-button danger class="logout-btn" @click="handleLogout">退出</a-button>
        </div>
      </div>
    </header>
    <a-layout class="workspace-layout">
      <a-layout-sider v-if="showKnowledgeSidebar" v-model:collapsed="collapsed" :trigger="null" collapsible breakpoint="lg" :width="280" theme="light" style="border-right: 1px solid #f0f0f0;">
        <div style="height: 48px; margin: 16px; display: flex; align-items: center; padding: 0 12px;">
          <div style="width: 32px; height: 32px; background: #1677ff; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 12px; flex-shrink: 0;">
            <BookOutlined style="color: #fff; font-size: 18px;" />
          </div>
          <span v-if="!collapsed" style="color: #1f1f1f; font-size: 17px; font-weight: 600; white-space: nowrap;">知识库平台</span>
        </div>
        <a-menu
          :selectedKeys="selectedKeys"
          theme="light"
          mode="inline"
          @click="handleMenuClick"
        >
          <a-menu-item key="chat">
            <template #icon><MessageOutlined /></template>
            新会话
          </a-menu-item>
          <a-menu-item key="knowledge-base">
            <template #icon><BookOutlined /></template>
            知识库
          </a-menu-item>
          <a-menu-item key="agent" disabled>
            <template #icon><RobotOutlined /></template>
            智能体
          </a-menu-item>
        </a-menu>
      </a-layout-sider>
      <a-layout style="background: transparent;">
        <a-layout-content :style="{ margin: isPermissionPage ? '0' : '20px' }">
          <div :style="isPermissionPage ? {} : { padding: '24px', background: '#fff', minHeight: '360px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }">
            <router-view :key="$route.fullPath" />
          </div>
        </a-layout-content>
      </a-layout>
    </a-layout>
  </a-layout>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { 
  MessageOutlined, 
  BookOutlined, 
  RobotOutlined, 
  ApiOutlined
} from '@ant-design/icons-vue'
import { Modal, message } from 'ant-design-vue'
import { useUserStore } from '../../stores/user.js'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const collapsed = ref(false)
const aiToolsOpen = ref(false)
const permissionsOpen = ref(false)
const isPermissionPage = computed(() => route.path.startsWith('/permissions/'))
const platformMenu = ['首页', '开发者资源', '权限', '开发者工具',  'AI工具', '联系我们']
const unavailableAiTools = ['日志分析工具', 'Skill广场', '专项日志分析数据', '专项日志审核', 'MCP广场']
const availableAiTools = [
  { key: 'knowledge-base', path: '/knowledge-base', label: '知识库管理' },
  { key: 'models', path: '/models', label: '模型管理' },
  { key: 'prompts', path: '/prompts', label: '提示词管理' },
  { key: 'api-keys', path: '/api-keys', label: "[REDACTED]"
]
const isKnowledgePage = computed(() => route.path === '/knowledge-base' || route.path.startsWith('/knowledge-base/'))
const showKnowledgeSidebar = computed(() => isKnowledgePage.value || route.path === '/chat')
const username = computed(() => userStore.state.currentUser?.username || '未登录')
const userInitial = computed(() => Array.from(username.value)[0].toUpperCase())

const routeToKey = {
  '/chat': 'chat',
  '/knowledge-base': 'knowledge-base'
}

const selectedKeys = computed(() => {
  const key = isKnowledgePage.value ? 'knowledge-base' : routeToKey[route.path]
  return key ? [key] : []
})
const selectedAiToolKeys = computed(() =>
  availableAiTools
    .filter(tool => tool.key === 'knowledge-base' ? isKnowledgePage.value : route.path === tool.path)
    .map(tool => tool.key)
)

watch([aiToolsOpen, permissionsOpen], ([aiOpen, permissionOpen], _, onCleanup) => {
  if (!aiOpen && !permissionOpen) return
  const closeOnEscape = (event) => {
    if (event.key === 'Escape') {
      aiToolsOpen.value = false
      permissionsOpen.value = false
    }
  }
  document.addEventListener('keydown', closeOnEscape)
  onCleanup(() => document.removeEventListener('keydown', closeOnEscape))
})

function handleAiToolClick() {
  aiToolsOpen.value = false
}

function handleMenuClick({ key }) {
  if (key === 'chat') {
    router.push('/chat')
  } else if (key === 'knowledge-base') {
    router.push('/knowledge-base')
  }
}

function handleLogout() {
  Modal.confirm({
    title: '确认退出',
    content: '确定要退出当前账号吗？',
    okText: '确认',
    cancelText: '取消',
    onOk() {
      const result = userStore.logout()
      if (result.success) {
        message.success(result.message)
        router.push('/login')
      }
    }
  })
}
</script>

<style scoped>
:global(body) {
  margin: 0;
  padding: 0;
}

.app-shell {
  min-height: 100vh;
  background: #f8faff;
}

.platform-header {
  position: sticky;
  top: 0;
  z-index: 20;
  flex-shrink: 0;
  background: #fff;
  border-bottom: 1px solid #edf0f5;
}

.platform-header-inner {
  max-width: 1280px;
  min-height: 72px;
  margin: 0 auto;
  padding: 0 24px;
  display: flex;
  align-items: center;
  gap: 28px;
}

.platform-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}

.platform-logo {
  width: 44px;
  height: 44px;
  display: grid;
  place-items: center;
  color: #189dff;
  background: #f5fbff;
  border: 1px solid #dceeff;
  border-radius: 12px;
  font-size: 24px;
}

.platform-title {
  color: #152038;
  font-size: 17px;
  font-weight: 600;
  letter-spacing: 1px;
}

.platform-subtitle {
  margin-top: 3px;
  color: #8190a8;
  font-size: 10px;
  white-space: nowrap;
}

.platform-nav {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}

.platform-nav-item {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 40px;
  padding: 0 14px;
  border: 0;
  border-radius: 22px;
  background: transparent;
  color: #46536b;
  font: inherit;
  font-size: 13px;
  white-space: nowrap;
}

.platform-nav-item:disabled {
  cursor: not-allowed;
}

.platform-nav-item:not(:disabled) {
  cursor: pointer;
}

.platform-nav-item.is-active {
  color: #476fff;
  background: #f0f4ff;
  cursor: pointer;
}

.platform-nav-item:focus-visible {
  outline: 2px solid #1677ff;
  outline-offset: 2px;
}

.ai-tools-menu {
  min-width: 220px;
  padding: 8px 0;
  border-radius: 4px;
}

.ai-tools-menu :deep(.ant-dropdown-menu-item) {
  min-height: 48px;
  padding: 12px 20px;
  border-radius: 0;
  font-size: 14px;
}

.ai-tools-menu :deep(.ant-dropdown-menu-item-selected) {
  color: #1677ff;
  background: #e6f7ff;
}

.header-account {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-shrink: 0;
}

.workspace-layout {
  flex: 1;
  min-width: 0;
  background: transparent;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.user-avatar {
  flex-shrink: 0;
  background: #cf1322;
  font-size: 13px;
  font-weight: 600;
  box-shadow: 0 0 0 5px #f7f8fa;
}

.username {
  max-width: 120px;
  font-size: 13px;
  font-weight: 600;
  color: #152038;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.logout-btn {
  height: 30px;
  padding: 0 15px;
  border-color: #ffccc7;
  border-radius: 3px;
  font-size: 12px;
}

@media (max-width: 1199px) {
  .platform-header-inner {
    gap: 16px;
  }

  .platform-subtitle {
    display: none;
  }

  .platform-nav-item {
    padding: 0 10px;
  }
}

@media (max-width: 900px) {
  .platform-header-inner {
    flex-wrap: wrap;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 20px 8px;
  }

  .platform-nav {
    order: 1;
    flex: 0 0 100%;
    justify-content: flex-start;
    overflow-x: auto;
    padding-bottom: 4px;
  }

  .platform-nav-item {
    flex-shrink: 0;
  }
}

@media (max-width: 480px) {
  .platform-header-inner {
    padding-right: 12px;
    padding-left: 12px;
  }

  .platform-brand {
    gap: 8px;
  }

  .platform-title {
    font-size: 15px;
  }

  .header-account {
    gap: 10px;
  }

  .username {
    max-width: 72px;
  }
}
</style>
