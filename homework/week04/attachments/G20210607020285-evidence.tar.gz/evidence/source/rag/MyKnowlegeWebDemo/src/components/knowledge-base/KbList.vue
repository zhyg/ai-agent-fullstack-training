<template>
  <div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
      <h2 style="margin: 0;">知识库管理</h2>
      <a-button type="primary" @click="$emit('create')">新建知识库</a-button>
    </div>
    <EmptyKb v-if="knowledgeBases.length === 0" @create="$emit('create')" />
    <div v-else>
      <KbCard
        v-for="kb in knowledgeBases"
        :key="kb.id"
        :kb="kb"
        :models="models"
        @enter="(k) => $emit('enter', k)"
        @edit="(k) => $emit('edit', k)"
        @delete="(k) => $emit('delete', k)"
      />
    </div>
  </div>
</template>

<script setup>
import KbCard from './KbCard.vue'
import EmptyKb from './EmptyKb.vue'

defineProps({
  knowledgeBases: {
    type: Array,
    required: true
  },
  models: {
    type: Array,
    required: true
  }
})

defineEmits(['create', 'enter', 'edit', 'delete'])
</script>
