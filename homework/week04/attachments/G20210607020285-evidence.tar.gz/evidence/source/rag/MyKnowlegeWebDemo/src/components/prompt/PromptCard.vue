<template>
  <div class="prompt-card" @mouseenter="hovered = true" @mouseleave="hovered = false">
    <div class="card-header">
      <div class="card-icon">
        <FileTextOutlined />
      </div>
      <div class="card-title-area">
        <div class="card-title-row">
          <span class="card-title">{{ prompt.name }}</span>
          <a-tag v-if="prompt.version" color="blue">v{{ prompt.version.replace(/^v+/i, '') }}</a-tag>
        </div>
        <a-tooltip :title="prompt.description">
          <span class="card-description">{{ prompt.description || '暂无描述' }}</span>
        </a-tooltip>
      </div>
      <div class="card-actions">
        <a-button type="text" size="small" @click="$emit('edit', prompt)">
          <template #icon><EditOutlined /></template>
          设置
        </a-button>
        <a-button type="text" size="small" danger @click="$emit('delete', prompt)">
          <template #icon><DeleteOutlined /></template>
          删除
        </a-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { FileTextOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'

defineProps({
  prompt: {
    type: Object,
    required: true
  }
})

defineEmits(['edit', 'delete'])

const hovered = ref(false)
</script>

<style scoped>
.prompt-card {
  background: linear-gradient(135deg, #f0f7ff 0%, #e8f4fd 50%, #f5f0ff 100%);
  border: 1px solid #dce9f7;
  border-radius: 12px;
  padding: 20px 24px;
  margin-bottom: 12px;
  transition: all 0.3s ease;
  cursor: default;
}

.prompt-card:hover {
  background: linear-gradient(135deg, #e8f2fc 0%, #ddeefb 50%, #eee8fc 100%);
  border-color: #b8d4f0;
  box-shadow: 0 4px 12px rgba(0, 80, 180, 0.06);
  transform: translateY(-1px);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 16px;
}

.card-icon {
  width: 42px;
  height: 42px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 20px;
  flex-shrink: 0;
}

.card-title-area {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.card-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.card-title {
  font-size: 15px;
  font-weight: 600;
  color: #1f1f1f;
  line-height: 1.4;
}

.card-description {
  font-size: 13px;
  color: #8c8c8c;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.4;
}

.card-actions {
  display: flex;
  gap: 4px;
  flex-shrink: 0;
}

.card-actions .ant-btn {
  font-size: 13px;
  border-radius: 6px;
}

.card-actions .ant-btn:hover {
  background: #f5f5f5;
}

.card-actions .ant-btn-dangerous:hover {
  background: #fff1f0;
}
</style>
