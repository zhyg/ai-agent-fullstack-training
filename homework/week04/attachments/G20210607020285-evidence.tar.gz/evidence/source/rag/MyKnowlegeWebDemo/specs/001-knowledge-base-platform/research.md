# Research: 知识库平台原型

**Feature**: 001-knowledge-base-platform
**Date**: 2026-10-23

## 研究主题

### 1. Vue 3 + Ant Design Vue 4.x 项目初始化

**Decision**: 使用 Vite 5+ 作为构建工具，通过 `npm create vite@latest` 创建 Vue 3 项目

**Rationale**: Vite 是 Vue 3 官方推荐的构建工具，开发体验优秀（HMR 快速、配置简洁），与 Vue 3 生态深度集成。相比 Webpack，Vite 的启动速度更快，开发效率更高。

**Alternatives considered**:
- **Vue CLI + Webpack**: Vue CLI 已进入维护模式，官方推荐使用 Vite
- **Nuxt.js**: SSR/SSG 框架，对于纯前端原型过于复杂

### 2. Ant Design Vue 4.x 组件选择

**Decision**: 按需引入组件，使用以下核心组件

**Rationale**: 全量引入会增加包体积，按需引入更适合原型项目

| 功能需求 | Ant Design Vue 组件 | 说明 |
| -------- | ------------------- | ---- |
| 侧边栏导航 | `a-menu` + `a-layout-sider` | 内置菜单组件，支持高亮选中项 |
| 页面布局 | `a-layout` + `a-layout-content` | 标准布局容器 |
| 模型卡片 | `a-card` | 灵活的内容卡片 |
| 新建模型表单 | `a-drawer` + `a-form` | 侧边抽屉 + 表单验证 |
| 新建知识库 | `a-modal` + `a-form` | 模态对话框 + 表单验证 |
| 编辑知识库 | `a-drawer` + `a-form` | 侧边抽屉 + 表单验证 |
| 删除确认 | `a-modal` (confirm) | 内置确认对话框 |
| 模型选择 | `a-select` | 下拉选择框 |
| 空状态 | `a-empty` + `a-button` | 内置空状态组件 |
| 表单验证 | `a-form` rules | 内置验证规则 |

**Alternatives considered**:
- **Element Plus**: 功能类似但风格不同，用户指定使用 Ant Design Vue
- **Naive UI**: 更轻量但社区生态不如 Ant Design Vue 成熟

### 3. 数据持久化方案

**Decision**: 使用浏览器 localStorage，通过 composable 封装读写操作

**Rationale**: 
- 纯前端原型无需复杂数据管理
- localStorage 容量（约 5MB）足以存储原型数据（< 100 条记录）
- 无需额外依赖，浏览器原生支持

**Alternatives considered**:
- **IndexedDB**: 容量更大但 API 复杂，原型阶段不需要
- **Pinia + localStorage 插件**: 引入状态管理库，增加复杂度但对原型价值有限
- **SessionStorage**: 关闭标签页数据丢失，不符合"刷新后保留"的要求

### 4. 路由方案

**Decision**: 使用 vue-router 4，配置两个路由 + 默认重定向

**Rationale**: vue-router 是 Vue 3 官方路由方案，与 Composition API 完美集成。默认路由指向知识库页面。

**路由配置**:
- `/` → 重定向到 `/knowledge-base`
- `/knowledge-base` → 知识库管理页面
- `/models` → 模型管理页面
- 其他路由 → 重定向到 `/`

**Alternatives considered**:
- **组件切换（v-if）**: 不使用路由，通过组件切换实现。简单但不支持 URL 导航和浏览器前进后退
- **Hash 路由**: 使用 createWebHashHistory，适合无服务器部署

### 5. 项目创建命令

**Decision**: 使用以下命令初始化项目

```bash
npm create vite@latest . -- --template vue
npm install ant-design-vue@4 vue-router@4
```

**Rationale**: Vite 的 `vue` 模板提供最小化 Vue 3 项目结构，手动安装所需依赖，保持项目简洁。

### 6. ID 生成策略

**Decision**: 使用 `Date.now() + Math.random().toString(36).substr(2, 9)` 生成唯一 ID

**Rationale**: 纯前端无需 UUID 库，简单的时间戳 + 随机字符串组合即可满足原型需求，避免引入额外依赖。

**Alternatives considered**:
- **uuid 库**: 标准化 UUID 但需引入依赖
- **crypto.randomUUID()**: 现代浏览器支持但兼容性稍差
