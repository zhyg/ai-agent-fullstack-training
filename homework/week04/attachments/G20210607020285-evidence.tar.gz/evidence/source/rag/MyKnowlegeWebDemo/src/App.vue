<template>
  <AppLayout v-if="!isAuthPage" :key="'app-layout'" />
  <router-view v-else :key="'auth-page'" />
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import AppLayout from './components/layout/AppLayout.vue'

const route = useRoute()

// 判断是否为认证页面（登录/注册）
const isAuthPage = computed(() => {
  return route.path === '/login' || route.path === '/register'
})
</script>
