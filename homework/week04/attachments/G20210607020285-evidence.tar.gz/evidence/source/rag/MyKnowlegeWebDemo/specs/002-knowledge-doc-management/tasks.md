# Tasks: 知识库中知识的管理

**Input**: Design documents from `/specs/002-knowledge-doc-management/`

**Prerequisites**: plan.md (required), spec.md (required), research.md, data-model.md, contracts/ui-contracts.md, quickstart.md

**Tests**: 未在 spec 中明确要求自动化测试，本清单不生成测试任务；以 `quickstart.md` 作为验收脚本。

**Organization**: 任务按用户故事（US1~US6，对应 spec.md 中的 Story 1~6）分组，便于独立实现、独立测试、增量交付 MVP。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行执行（不同文件、无未完成依赖）
- **[Story]**: 任务归属的用户故事（US1~US6）
- Setup / Foundational / Polish 阶段不带 Story 标签
- 每条任务必须包含精确的文件路径

## Path Conventions

沿用 001 号特性的"单项目"结构：

- `src/components/knowledge/` — 002 新增组件目录
- `src/stores/` — Composable 风格的 store
- `src/utils/` — 工具函数
- `src/views/` — 页面组件
- `src/composables/useStorage.js` — 扩展 IndexedDB 封装
- `src/router/index.js` — 路由配置

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 安装新依赖、创建新目录、为后续阶段做准备

- [x] T001 执行 `npm install @vue-office/docx @vue-office/excel @vue-office/pptx @vue-office/pdf @kangc/v-md-editor` 安装 5 个新增依赖，并核对 `package.json` 的 `dependencies` 列表
- [x] T002 [P] 创建目录 `src/components/knowledge/`（按 plan.md 的 Source Code 章节）
- [x] T003 [P] 创建目录 `src/utils/`（若尚未存在）
- [x] T004 阅读 `specs/002-knowledge-doc-management/data-model.md`，在 `src/composables/useStorage.js` 中扩展 IndexedDB 封装方法：`saveBlob(storeName, key, blob)`、`getBlob(storeName, key)`、`deleteBlob(storeName, key)`、`saveText(storeName, key, text)`、`getText(storeName, key, text)`；数据库名为 `kb_files_db`，包含 `files` 与 `parsed_contents` 两个 object store

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 完成所有用户故事依赖的基础设施（store、工具函数、路由）。⚠️ 必须全部完成后才能进入用户故事阶段。

- [x] T005 [P] 按 `data-model.md` 的 Folder 实体定义实现 `src/stores/folder.js` 的 `useFolderStore`：包含 `state`、`getFoldersByKbId(kbId)`、`getFolderById(id)`、基础 `createFolder`、`renameFolder`、`deleteFolder`、`reorderFolder` 方法；localStorage key 为 `kb_folders`；`order` 为非负整数；`parentId` 为 `null`（根目录）或已存在的目录 ID
- [x] T006 [P] 按 `data-model.md` 的 Document 实体定义实现 `src/stores/document.js` 的 `useDocumentStore`：包含 `state`、`getDocumentsByFolderId`、`getDocumentsByKbId`、`getDocumentById`、基础 `createDocument`、`deleteDocument`、`batchDeleteDocuments`、`addTag`、`updateTags`；localStorage key 为 `kb_documents`；`size` ≤ 524288000 字节（500MB）；`status` 枚举为 `parsing`/`success`/`failed`；`tags` 为字符串数组并在单文档内去重
- [x] T007 [P] 实现 `src/utils/tree.js`：导出 `buildTree(flatFolders, kbId)`、`isDescendant(flatFolders, ancestorId, descendantId)`、`resolveConflictName(siblingNames, desiredName)` 三个函数；`buildTree` 输出形如 `{ key, title, children }` 的 a-tree 数据结构；`resolveConflictName` 在重名时按"原名(1)"、"原名(2)"... 递增
- [x] T008 [P] 实现 `src/utils/file.js`：导出 `formatFileSize(bytes)`（输出 KB/MB/GB）、`getExtension(filename)`（小写）、`getRendererType(extension)`（返回 `office-docx`/`office-excel`/`office-pptx`/`office-pdf`/`markdown`/`text` 之一）
- [x] T009 在 `src/router/index.js` 中新增参数化路由 `{ path: '/knowledge-base/:kbId', name: 'KnowledgeManagement', component: () => import('../views/KnowledgeManagement.vue'), props: false }`，保留已有的 `/knowledge-base` 与 `/models` 路由

**Checkpoint**: 基础 store、工具、路由就绪，可并行进入 US1~US3 阶段

---

## Phase 3: User Story 1 - 浏览知识库中的目录与文档 (Priority: P1) 🎯 MVP

**Goal**: 用户点击知识库卡片后，可看到左侧目录树 + 右侧文档表的"知识管理"页面骨架，能切换目录查看对应文档列表（空状态）。

**Independent Test**: 执行 `quickstart.md` 的 **V1（进入知识管理页面）** 与 **V2（创建根目录）** 前半段（仅渲染树，不含创建行为），通过手动点击验证左右分栏与空状态。

### Implementation for User Story 1

- [x] T010 [P] [US1] 实现 `src/components/knowledge/FolderTree.vue` 的骨架：接收 `kbId` 与 `selectedFolderId` props；调用 `useFolderStore.getFoldersByKbId` + `buildTree` 生成 `treeData`；使用 `a-tree` 渲染；目录为空时显示 `a-empty` + "新建根目录"按钮（触发 `create-root` 事件）
- [x] T011 [P] [US1] 实现 `src/components/knowledge/DocumentTable.vue` 的骨架：接收 `folderId`、`documents`、`selectedRowKeys` props；使用 `a-table` 按 `contracts/ui-contracts.md` 定义的 7 列（名称/标签/大小/状态/创建时间/更新时间/操作）渲染；标签列使用 `a-tag` 数组渲染；大小列调用 `formatFileSize`；状态列用颜色图标区分 `parsing`/`success`/`failed`；无文档时使用 `a-empty`
- [x] T012 [US1] 实现 `src/views/KnowledgeManagement.vue`：挂载时从 `route.params.kbId` 获取知识库 ID，调用 `useKbStore.getKbById` 获取当前知识库（不存在则 `router.push('/knowledge-base')`）；维护 `currentFolderId`、`selectedRowKeys`、各种模态框开关状态；左右分栏使用 `a-layout`（左侧 `a-layout-sider` 宽 280px，右侧 `a-layout-content`）；引入 FolderTree 与 DocumentTable；`FolderTree @select` 触发 `DocumentTable` 刷新
- [x] T013 [US1] 扩展 `src/components/knowledge-base/KbCard.vue`：在现有"设置"/"删除"按钮旁新增"进入"按钮（`a-button type="primary"`），点击触发 `router.push({ name: 'KnowledgeManagement', params: { kbId: kb.id } })`，并通过 emit 保留原有的 `edit`/`delete` 事件
- [x] T014 [US1] 更新 `specs/001-knowledge-base-platform/contracts/ui-contracts.md` 中 KbCard.vue 章节，记录新增的"进入"按钮行为，保持契约文档与代码一致

**Checkpoint**: 点击知识库卡片可进入知识管理页面；左右分栏展示；目录/文档表骨架渲染；空目录显示空状态

---

## Phase 4: User Story 2 - 管理目录结构 (Priority: P1)

**Goal**: 用户可以新建根目录/子目录、重命名、删除（级联）、拖拽排序/嵌套；拖拽遇同名目录自动重命名。

**Independent Test**: 执行 `quickstart.md` 的 **V2（创建根目录）、V3（创建子目录与嵌套）、V4（重命名）、V5（拖拽排序与嵌套）、V6（拖拽同名冲突）、V7（删除目录级联）**，全部通过即表明 US2 独立可用。

### Implementation for User Story 2

- [x] T015 [P] [US2] 实现 `src/components/knowledge/FolderActionModal.vue`：接收 `visible`、`type`（`create-root`/`create-child`/`rename`/`delete`）、`folder`、`kbId` props；创建/重命名模式使用 `a-form` + `a-input`（`name` 字段必填）；删除模式使用 `a-modal` 确认样式显示"确认删除目录 {name} 及其所有子目录与文档吗？"；submit 事件 payload 结构按 `contracts/ui-contracts.md` 定义
- [x] T016 [US2] 扩展 `src/stores/folder.js` 的 `createFolder(data)`：自动计算 `order`（新目录排在同级最后）；持久化到 `kb_folders`；`kbId` 必须已存在、`parentId` 若非 `null` 必须是同知识库的目录 ID；创建完成后返回新目录对象
- [x] T017 [US2] 扩展 `src/stores/folder.js` 的 `renameFolder(id, newName)`：更新 `name` 与 `updatedAt`，持久化；非空校验
- [x] T018 [US2] 扩展 `src/stores/folder.js` 的 `deleteFolder(id)`：递归找出该目录下所有子孙目录（通过 `isDescendant` 或递归查 `parentId`），对每个目录调用 `useDocumentStore.batchDeleteDocuments` 删除其下文档（含 IndexedDB Blob/文本），最后从 `kb_folders` 中移除所有相关目录
- [x] T019 [US2] 扩展 `src/stores/folder.js` 新增 `moveFolder(id, newParentId, newIndex)`：使用 `isDescendant` 阻止拖拽到自身或子孙目录；新 `parentId` 下若已存在同名目录，使用 `resolveConflictName` 自动重命名并通过 `message.info` 提示；调整同 `parentId` 下其他目录的 `order` 以腾出 `newIndex` 位置；持久化
- [x] T020 [US2] 在 `src/components/knowledge/FolderTree.vue` 中启用 `a-tree draggable`，添加 `@drop`、`allowDrop` 处理：`allowDrop` 调用 `isDescendant` 阻止无效落点；`@drop` 解析 `dropPosition`（-1/0/1）与 `dropToGap`，计算新 `parentId` 与 `newIndex` 后调用 `store.moveFolder`；悬浮目录节点时显示"..."按钮，点击弹出 `a-dropdown` 含三项菜单（新建目录/删除目录/修改目录名称）
- [x] T021 [US2] 在 `src/views/KnowledgeManagement.vue` 中接入 `FolderActionModal`：处理 FolderTree 的 `create-root`、`create-child`、`rename`、`delete` 事件，设置 `folderActionState`；`submit` 回调分别调用 `store.createFolder`/`renameFolder`/`deleteFolder`；成功后刷新目录树并保持选中态
- [x] T022 [US2] 为 `a-tree` 与 `a-dropdown` 在 `src/components/knowledge/FolderTree.vue` 中添加必要样式（悬浮显"..."、菜单宽度、节点图标）；若需要，通过 `<style scoped>` 覆盖 ant-design 默认样式

**Checkpoint**: 所有目录 CRUD + 拖拽排序/嵌套 + 同名冲突处理 + 级联删除全部可用；刷新后数据持久化

---

## Phase 5: User Story 3 - 上传与新建知识文档 (Priority: P1)

**Goal**: 用户可向指定目录上传任意文件或压缩包（≤ 500MB），系统模拟解析状态转换；可按文档类型查看渲染后的内容。

**Independent Test**: 执行 `quickstart.md` 的 **V8（上传单文件）、V9（超大文件拒绝）、V10（上传压缩包）、V13（Office 详情）、V14（Markdown 详情）**，全部通过即表明 US3 独立可用。

### Implementation for User Story 3

- [x] T023 [P] [US3] 实现 `src/components/knowledge/DocumentCreateModal.vue`：接收 `visible`、`folderId`、`kbId` props；使用 `a-modal` + `a-upload-dragger`；`beforeUpload` 校验文件大小 ≤ 524288000 字节（500MB），超出则 `message.error('文件大小超过 500MB 限制')` 并返回 `false` 阻止；`accept` 不限定以支持任意类型（含 `.zip`、`.tar.gz`）；确认按钮触发 `submit` 事件，payload 为 `{ file, folderId, kbId }`；关闭对话框不影响已提交的上传任务
- [x] T024 [US3] 扩展 `src/stores/document.js` 的 `createDocument(meta, fileBlob)`：生成 ID（`generateId()`）；按 Clarifications Q2 将 `description` 字段模拟为"从文件首段/元数据自动提取"（原型可固定为"解析中..."占位，状态转 `success` 后替换为前 100 字符摘要）；`status='parsing'`；将 Blob 通过 `saveBlob('files', docId, fileBlob)` 写入 IndexedDB；启动 `setTimeout`（随机 2~5 秒），80% 概率转 `status='success'` 并写入模拟解析文本到 `parsed_contents`，20% 概率转 `status='failed'` 并写入 `errorMessage`
- [x] T025 [US3] 实现 `src/components/knowledge/DocumentDetailDrawer.vue`：接收 `visible`、`document` props；使用 `a-drawer` + `a-descriptions` 展示元信息（名称、描述、标签、大小、状态、创建时间、更新时间）；内容区根据 `getRendererType(document.extension)` 动态渲染：`office-docx` → `<vue-office-docx />`、`office-excel` → `<vue-office-excel />`、`office-pptx` → `<vue-office-pptx />`、`office-pdf` → `<vue-office-pdf />`、`markdown` → `<v-md-preview />`、其他 → `<pre>` 或 "暂不支持预览" 占位；挂载时通过 `getBlob('files', id)` 与 `getText('parsed_contents', id)` 异步加载数据
- [x] T026 [US3] 在 `src/views/KnowledgeManagement.vue` 中接入 DocumentCreateModal 与 DocumentDetailDrawer：点击"新建知识"按钮打开创建模态框；`submit` 回调调用 `store.createDocument` 并刷新文档列表；点击表格行（非按钮区域）打开详情抽屉
- [x] T027 [US3] 在主入口（`src/main.js` 或对应局部 import）中为 vue-office 子组件与 v-md-editor 注册必要样式（如 `import '@vue-office/docx/lib/index.css'`、`import '@kangc/v-md-editor/lib/style/preview.css'`），确保渲染正常

**Checkpoint**: 上传、状态模拟、超大文件拒绝、详情抽屉多格式渲染均工作正常

---

## Phase 6: User Story 4 - 批量删除知识文档 (Priority: P2)

**Goal**: 用户可多选文档进行批量删除；`status=parsing` 的文档被拒绝删除并提示。

**Independent Test**: 执行 `quickstart.md` 的 **V11（批量删除）、V12（拒绝删除解析中）**，全部通过即表明 US4 独立可用。

### Implementation for User Story 4

- [x] T028 [P] [US4] 在 `src/components/knowledge/DocumentTable.vue` 中启用 `a-table` 多选（`rowSelection`），受控绑定 `selectedRowKeys`；在表格上方添加"批量删除"按钮（`a-button danger`），未选中时禁用；`batch-delete` 事件 payload 为选中的 ID 数组
- [x] T029 [US4] 扩展 `src/stores/document.js` 的 `batchDeleteDocuments(ids)`：遍历 ids，对每个文档校验 `status`：若为 `parsing` 则跳过并累计"被忽略"计数；否则调用内部删除（移除元数据 + `deleteBlob('files', id)` + `deleteBlob('parsed_contents', id)`）；返回 `{ deleted, skipped }` 结构
- [x] T030 [US4] 扩展 `src/stores/document.js` 的 `deleteDocument(id)`：单条删除版本，若 `status=parsing` 则直接返回 `refused: true` 且不执行删除
- [x] T031 [US4] 在 `src/views/KnowledgeManagement.vue` 中接入批量删除与单行删除：表格上方"批量删除"按钮触发确认 `Modal.confirm` 后调用 `store.batchDeleteDocuments`，根据返回的 `skipped` 数量使用 `message.warning` 提示"N 篇解析中文档已跳过"；单行删除使用 `a-popconfirm` 并调用 `store.deleteDocument`，若返回 `refused: true` 则 `message.warning('请等待解析完成后再操作')`

**Checkpoint**: 批量/单行删除均工作正常；解析中文档被明确拒绝；刷新后状态持久化

---

## Phase 7: User Story 5 - 查看知识详情与文档内容 (Priority: P2)

**Goal**: 与 US3 共用 `DocumentDetailDrawer`，本阶段聚焦"从标签入口查看详情"的链路（标签的新增/修改按钮位于详情抽屉中）。

**Independent Test**: 在 US3 已通过的详情抽屉中，点击抽屉内"新增标签"/"修改标签"按钮能正常打开标签模态框（完整链路在 US6 验证）。

### Implementation for User Story 5

- [x] T032 [US5] 在 `src/components/knowledge/DocumentDetailDrawer.vue` 的元信息区"标签"行旁添加"新增标签"与"修改标签"按钮；点击分别触发 `add-tag` 与 `edit-tag` 事件；`status=parsing` 时按钮禁用
- [x] T033 [US5] 确保 `src/views/KnowledgeManagement.vue` 中详情抽屉内的标签事件被捕获并传递给 DocumentActionModal（US6 的模态框），本阶段先预留事件绑定与 `docActionState` 状态字段

**Checkpoint**: 详情抽屉完整展示所有元信息 + 标签按钮；事件链路预留到 US6

---

## Phase 8: User Story 6 - 文档标签管理 (Priority: P3)

**Goal**: 用户可从表格操作列或详情抽屉中为文档新增/修改标签，标签实时刷新。

**Independent Test**: 执行 `quickstart.md` 的 **V15（新增/修改标签）**，通过即表明 US6 独立可用。

### Implementation for User Story 6

- [x] T034 [P] [US6] 实现 `src/components/knowledge/DocumentActionModal.vue`：接收 `visible`、`type`（`add-tag`/`edit-tag`）、`document` props；使用 `a-modal` + `a-form`；`tags` 字段使用 `a-select` 配置 `mode="tags"` 支持动态输入多个标签；`edit-tag` 模式预填现有标签；submit 事件 payload 为 `{ documentId, tags }`（数组）；提交前对数组去重
- [x] T035 [US6] 在 `src/components/knowledge/DocumentTable.vue` 的操作列中接入 DocumentActionModal：渲染"新增标签"、"修改标签"、"删除"三个按钮；前两者触发对应事件；"删除"按钮保留 `a-popconfirm` 行为（与 US4 一致）
- [x] T036 [US6] 在 `src/views/KnowledgeManagement.vue` 中接入 DocumentActionModal：维护 `docActionState = { visible, type, targetDocument }`；`submit` 回调分别调用 `store.addTag`（`add-tag` 模式）或 `store.updateTags`（`edit-tag` 模式）；成功后刷新当前文档列表与详情抽屉内的标签展示

**Checkpoint**: 标签新增/修改均工作正常；去重生效；表格与详情抽屉同步刷新

---

## Phase 9: Polish & Cross-Cutting Concerns

**Purpose**: 跨故事一致性、UX 细节、整体验收

- [x] T037 [P] 检查所有 `a-modal` / `a-drawer` / `a-popconfirm` 的中文文案，统一使用 ant-design-vue 的 `ConfigProvider` + `zhCN` 本地化（若尚未配置）
- [x] T038 [P] 为 `src/views/KnowledgeManagement.vue` 添加空目录与空文档的友好引导文案（如"选中左侧目录或新建根目录"、"当前目录暂无文档，点击新建知识开始上传"）
- [x] T039 按 `quickstart.md` 执行全部 V1~V16 验收场景，修复发现的问题；特别关注 SC-003（详情 2s 打开）、SC-004（50 篇批量 5s 完成）、SC-006（1000 文档/10 层目录流畅）
- [x] T040 更新 `specs/002-knowledge-doc-management/contracts/ui-contracts.md` 与 `data-model.md`，使其与实现后的代码契约保持一致（如实际字段名、事件名、方法签名变更）

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即开始
- **Foundational (Phase 2)**: 依赖 Phase 1 完成，**阻塞所有 US 阶段**
- **US1 (Phase 3)**: 依赖 Foundational；不依赖其他 US
- **US2 (Phase 4)**: 依赖 Foundational + US1（共享 FolderTree 组件与页面骨架）
- **US3 (Phase 5)**: 依赖 Foundational + US1（共享 DocumentTable 组件与页面骨架）
- **US4 (Phase 6)**: 依赖 Foundational + US3（共享 DocumentTable 与详情抽屉）
- **US5 (Phase 7)**: 依赖 US3（扩展 DocumentDetailDrawer）
- **US6 (Phase 8)**: 依赖 US5（接收抽屉内标签事件）+ US1（共享 DocumentTable）
- **Polish (Phase 9)**: 依赖所有 US 阶段完成

### User Story Dependencies

- **US1 (P1)**: Foundational 完成后可开始
- **US2 (P1)**: Foundational + US1 完成后可开始
- **US3 (P1)**: Foundational + US1 完成后可开始；可与 US2 **并行**
- **US4 (P2)**: US3 完成后可开始
- **US5 (P2)**: US3 完成后可开始；可与 US4 **并行**
- **US6 (P3)**: US5 完成后可开始

### Within Each User Story

- [P] 标记的任务可并行执行（不同文件）
- 先实现 Store/组件（独立文件），再实现 View（集成文件）
- 模态框组件先于页面集成
- Store 方法先于组件行为
- 每个 Checkpoint 停下手动验收

### Parallel Opportunities

- **Phase 1**: T002 与 T003 可并行
- **Phase 2**: T005、T006、T007、T008 可并行（不同文件）
- **US1**: T010、T011 可并行（两个独立组件）
- **US2**: T015 独立组件可先行；T016~T019 同文件顺序执行
- **US3**: T023 独立组件可先行；T025 独立组件也可先行
- **US4**: T028 可与 T029/T030 并行（组件 vs store）
- **US6**: T034 独立组件可先行
- **Polish**: T037、T038 可并行

---

## Parallel Example: User Story 1

```text
# 两个独立组件骨架并行实现：
Task: T010 [P] [US1] FolderTree.vue 骨架
Task: T011 [P] [US1] DocumentTable.vue 骨架

# 完成后：
Task: T012 [US1] KnowledgeManagement.vue 集成两个组件
Task: T013 [US1] KbCard.vue 新增"进入"按钮
Task: T014 [US1] 更新 001 号契约文档
```

## Parallel Example: User Story 3

```text
# 模态框与抽屉组件并行实现：
Task: T023 [P] [US3] DocumentCreateModal.vue
Task: T025 [P] [US3] DocumentDetailDrawer.vue

# 完成后：
Task: T024 [US3] store.createDocument（含状态模拟）
Task: T026 [US3] KnowledgeManagement.vue 集成
Task: T027 [US3] vue-office / v-md-editor 样式注册
```

---

## Implementation Strategy

### MVP First (US1 + US2 + US3)

1. 完成 Phase 1: Setup
2. 完成 Phase 2: Foundational（阻塞后续）
3. 完成 Phase 3: US1（浏览骨架）
4. 完成 Phase 4: US2（目录管理）
5. 完成 Phase 5: US3（上传与详情）
6. **STOP and VALIDATE**: 执行 quickstart V1~V10、V13~V14 独立验收
7. 可演示 / 发布 MVP（已覆盖核心主流程）

### Incremental Delivery

1. Setup + Foundational → 基础就绪
2. + US1 → 骨架可见 → 验收
3. + US2 → 目录管理完成 → 验收
4. + US3 → 上传与查看完成 → 验收（**MVP!**）
5. + US4 → 批量删除完成 → 验收
6. + US5 → 详情入口完成 → 验收
7. + US6 → 标签管理完成 → 验收
8. + Polish → 整体验收

### Parallel Team Strategy

若有多人协作：

1. 共同完成 Phase 1 + Phase 2
2. Foundational 完成后：
   - 开发者 A：US1 → US2 → US6（目录/标签线）
   - 开发者 B：US3 → US4 → US5（文档/详情线）
3. 两条线在 US5/US6 处汇合，通过 `docActionState` 集成

---

## Notes

- [P] 任务位于不同文件，可并行执行
- [Story] 标签便于在 issue / PR 中追踪任务归属
- 每个 Checkpoint 是独立验证点，可随时停下发布增量版本
- 避免跨 US 同文件冲突：`KnowledgeManagement.vue` 被多个 US 扩展，**必须按 US 顺序逐步修改**，不要并行
- 提交建议：每个 Checkpoint 至少一次 commit；[P] 任务可合并为一次 commit
- 不生成自动化测试任务（spec 未要求 TDD）；以 quickstart.md 为验收标准
