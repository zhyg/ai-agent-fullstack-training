import { reactive } from 'vue'
import {
  getItem,
  setItem,
  generateId,
  saveBlob,
  getBlob,
  deleteBlob
} from '../composables/useStorage.js'
import { getExtension } from '../utils/file.js'

const DOCUMENTS_KEY = 'documents'
const MAX_FILE_SIZE = 524288000 // 500MB
const PARSE_MIN_DELAY = 2000
const PARSE_MAX_DELAY = 5000
const PARSE_SUCCESS_RATE = 0.8

const state = reactive({
  documents: getItem(DOCUMENTS_KEY) || []
})

function persist() {
  setItem(DOCUMENTS_KEY, state.documents)
}

function getDocumentsByFolderId(folderId) {
  return state.documents.filter((d) => d.folderId === folderId)
}

function getDocumentsByKbId(kbId) {
  return state.documents.filter((d) => d.kbId === kbId)
}

function getDocumentById(id) {
  return state.documents.find((d) => d.id === id) || null
}

/**
 * 创建文档元数据 + 写入 Blob + 启动解析状态模拟
 * @param {Object} meta { kbId, folderId, name, size, mimeType?, description? }
 * @param {Blob} fileBlob
 * @param {Object} options { onStatusChange?: (doc) => void }
 */
function createDocument(meta, fileBlob, options = {}) {
  const { kbId, folderId, name, size, mimeType, description } = meta
  if (!kbId || !folderId || !name) throw new Error('kbId/folderId/name required')
  if (typeof size !== 'number' || size < 0) throw new Error('invalid size')
  if (size > MAX_FILE_SIZE) throw new Error(`file size exceeds ${MAX_FILE_SIZE} bytes limit`)

  const id = generateId()
  const now = Date.now()
  const extension = getExtension(name)

  const doc = reactive({
    id,
    kbId,
    folderId,
    name,
    description: description ?? '解析中...',
    tags: [],
    size,
    mimeType: mimeType ?? '',
    extension,
    status: 'parsing',
    errorMessage: null,
    createdAt: now,
    updatedAt: now
  })

  state.documents.push(doc)
  persist()

  // 异步写入 IndexedDB
  if (fileBlob) {
    saveBlob('files', id, fileBlob).catch((err) => {
      console.error('saveBlob failed', err)
    })
  }

  // 状态模拟：2~5 秒后，80% 成功，20% 失败
  const delay =
    PARSE_MIN_DELAY + Math.random() * (PARSE_MAX_DELAY - PARSE_MIN_DELAY)
  setTimeout(() => {
    const current = getDocumentById(id)
    if (!current) return
    if (Math.random() < PARSE_SUCCESS_RATE) {
      current.status = 'success'
      current.description = current.description === '解析中...'
        ? `${current.name}（已解析）`
        : current.description
      current.updatedAt = Date.now()
      // 写入模拟解析文本
      saveBlob(
        'parsed_contents',
        id,
        `这是 ${current.name} 的模拟解析内容。\n\n原型阶段未实现真实解析，此处为占位文本。`
      ).catch(() => {})
    } else {
      current.status = 'failed'
      current.errorMessage = '模拟解析失败（原型随机触发）'
      current.description = '解析失败'
      current.updatedAt = Date.now()
    }
    persist()
    if (typeof options.onStatusChange === 'function') {
      options.onStatusChange(current)
    }
  }, delay)

  return doc
}

/**
 * 单条删除
 * @returns {{ refused: boolean }}
 */
function deleteDocument(id) {
  const doc = getDocumentById(id)
  if (!doc) return { refused: false }

  state.documents = state.documents.filter((d) => d.id !== id)
  persist()
  deleteBlob('files', id).catch(() => {})
  deleteBlob('parsed_contents', id).catch(() => {})
  return { refused: false }
}

/**
 * 批量删除
 * @returns {{ deleted: number }}
 */
function batchDeleteDocuments(ids) {
  let deleted = 0
  const toDeleteIds = []
  for (const id of ids) {
    const doc = getDocumentById(id)
    if (!doc) continue
    toDeleteIds.push(id)
  }
  for (const id of toDeleteIds) {
    deleteBlob('files', id).catch(() => {})
    deleteBlob('parsed_contents', id).catch(() => {})
  }
  state.documents = state.documents.filter((d) => !toDeleteIds.includes(d.id))
  deleted = toDeleteIds.length
  persist()
  return { deleted }
}

/**
 * 删除某目录下所有文档（级联删除用）
 */
function deleteDocumentsByFolderId(folderId) {
  const targets = state.documents.filter((d) => d.folderId === folderId)
  for (const doc of targets) {
    deleteBlob('files', doc.id).catch(() => {})
    deleteBlob('parsed_contents', doc.id).catch(() => {})
  }
  state.documents = state.documents.filter((d) => d.folderId !== folderId)
  persist()
}

function addTag(id, tag) {
  const doc = getDocumentById(id)
  if (!doc) throw new Error('document not found')
  if (!tag || !String(tag).trim()) return doc
  const normalized = String(tag).trim()
  if (!doc.tags.includes(normalized)) {
    doc.tags.push(normalized)
    doc.updatedAt = Date.now()
    persist()
  }
  return doc
}

function updateTags(id, tags) {
  const doc = getDocumentById(id)
  if (!doc) throw new Error('document not found')
  if (!Array.isArray(tags)) throw new Error('tags must be an array')
  // 去重 + 去空
  const unique = Array.from(
    new Set(tags.map((t) => String(t).trim()).filter((t) => t))
  )
  doc.tags = unique
  doc.updatedAt = Date.now()
  persist()
  return doc
}

async function getFileBlob(id) {
  return getBlob('files', id)
}

async function getParsedContent(id) {
  const value = await getBlob('parsed_contents', id)
  return value === null ? null : String(value)
}

export function useDocumentStore() {
  return {
    state,
    getDocumentsByFolderId,
    getDocumentsByKbId,
    getDocumentById,
    createDocument,
    deleteDocument,
    batchDeleteDocuments,
    deleteDocumentsByFolderId,
    addTag,
    updateTags,
    getFileBlob,
    getParsedContent
  }
}
