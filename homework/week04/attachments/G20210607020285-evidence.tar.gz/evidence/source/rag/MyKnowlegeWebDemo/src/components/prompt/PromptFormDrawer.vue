<template>
  <a-drawer
    :title="'设置提示词'"
    :open="visible"
    width="70vw"
    @close="handleClose"
  >
    <a-form
      ref="formRef"
      :model="formState"
      :rules="rules"
      layout="vertical"
      @finish="handleSubmit"
    >
      <a-form-item label="提示词名称" name="name">
        <a-input v-model:value="formState.name" placeholder="请输入提示词名称" />
      </a-form-item>
      <a-form-item label="版本" name="version">
        <a-input v-model:value="formState.version" placeholder="版本不可修改" disabled />
      </a-form-item>
      <a-form-item label="描述" name="description">
        <a-textarea 
          v-model:value="formState.description" 
          placeholder="请输入提示词描述" 
          :rows="3"
        />
      </a-form-item>
      <a-form-item label="内容" name="content">
        <a-textarea 
          v-model:value="formState.content" 
          placeholder="请输入提示词内容" 
          :rows="12"
        />
      </a-form-item>
      <a-form-item>
        <a-space>
          <a-button type="primary" html-type="submit">确认</a-button>
          <a-button @click="handleClose">取消</a-button>
        </a-space>
      </a-form-item>
    </a-form>
  </a-drawer>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  prompt: {
    type: Object,
    default: null
  }
})

const emit = defineEmits(['close', 'submit'])

const formRef = ref(null)
const formState = ref({ 
  name: '', 
  version: '',
  description: '', 
  content: '' 
})

const rules = {
  name: [{ required: true, message: '请输入提示词名称' }]
}

watch(() => props.visible, (val) => {
  if (val && props.prompt) {
    formState.value = { 
      name: props.prompt.name, 
      version: props.prompt.version,
      description: props.prompt.description || '', 
      content: props.prompt.content || '' 
    }
  } else if (val) {
    formState.value = { 
      name: '', 
      version: '',
      description: '', 
      content: '' 
    }
  }
})

function handleSubmit() {
  emit('submit', { ...formState.value })
}

function handleClose() {
  emit('close')
  formRef.value?.resetFields()
}
</script>
