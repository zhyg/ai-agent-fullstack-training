import { reactive } from 'vue'
import { getItem, setItem, removeItem, generateId } from '../composables/useStorage.js'

const CHATS_KEY = 'knowledge_platform_chats'

export function useChatStore() {
  const state = reactive({
    chats: getItem(CHATS_KEY) || [],
    currentChatId: null
  })

  // 获取所有会话
  function getChats() {
    return state.chats
  }

  // 获取当前会话
  function getCurrentChat() {
    if (!state.currentChatId) return null
    return state.chats.find(chat => chat.id === state.currentChatId)
  }

  // 创建新会话
  function createChat(title = '新会话') {
    const newChat = {
      id: generateId(),
      title,
      messages: [],
      model: null,
      prompt: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    state.chats.unshift(newChat)
    state.currentChatId = newChat.id
    saveChats()

    return newChat
  }

  // 删除会话
  function deleteChat(chatId) {
    const index = state.chats.findIndex(chat => chat.id === chatId)
    if (index !== -1) {
      state.chats.splice(index, 1)
      if (state.currentChatId === chatId) {
        state.currentChatId = state.chats.length > 0 ? state.chats[0].id : null
      }
      saveChats()
    }
  }

  // 修改会话标题
  function updateChatTitle(chatId, title) {
    const chat = state.chats.find(chat => chat.id === chatId)
    if (chat) {
      chat.title = title
      chat.updatedAt = new Date().toISOString()
      saveChats()
    }
  }

  // 选择会话
  function selectChat(chatId) {
    state.currentChatId = chatId
  }

  // 添加消息
  function addMessage(chatId, message) {
    const chat = state.chats.find(chat => chat.id === chatId)
    if (chat) {
      chat.messages.push({
        id: generateId(),
        role: message.role,
        content: message.content,
        timestamp: new Date().toISOString()
      })
      chat.updatedAt = new Date().toISOString()
      saveChats()
    }
  }

  // 设置会话的模型
  function setChatModel(chatId, model) {
    const chat = state.chats.find(chat => chat.id === chatId)
    if (chat) {
      chat.model = model
      chat.updatedAt = new Date().toISOString()
      saveChats()
    }
  }

  // 设置会话的提示词
  function setChatPrompt(chatId, prompt) {
    const chat = state.chats.find(chat => chat.id === chatId)
    if (chat) {
      chat.prompt = prompt
      chat.updatedAt = new Date().toISOString()
      saveChats()
    }
  }

  // 保存会话到 localStorage
  function saveChats() {
    setItem(CHATS_KEY, state.chats)
  }

  // 清空所有会话
  function clearAllChats() {
    state.chats = []
    state.currentChatId = null
    saveChats()
  }

  return {
    state,
    getChats,
    getCurrentChat,
    createChat,
    deleteChat,
    updateChatTitle,
    selectChat,
    addMessage,
    setChatModel,
    setChatPrompt,
    clearAllChats
  }
}
