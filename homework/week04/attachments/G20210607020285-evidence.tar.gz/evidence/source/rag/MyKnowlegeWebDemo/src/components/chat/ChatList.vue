<template>
  <div class="chat-list-container">
    <div class="chat-list-header">
      <a-button type="primary" block @click="handleCreateChat">
        <template #icon><PlusOutlined /></template>
        新建会话
      </a-button>
    </div>
    
    <div class="chat-list">
      <div
        v-for="chat in chats"
        :key="chat.id"
        :class="['chat-item', { active: chat.id === currentChatId }]"
        @click="handleSelectChat(chat.id)"
      >
        <div class="chat-item-content">
          <div class="chat-icon">
            <MessageOutlined />
          </div>
          <div class="chat-info">
            <div class="chat-title" v-if="!editingChatId || editingChatId !== chat.id">
              {{ chat.title }}
            </div>
            <a-input
              v-else
              v-model:value="editingTitle"
              size="small"
              @blur="handleSaveTitle(chat.id)"
              @pressEnter="handleSaveTitle(chat.id)"
              @click.stop
            />
            <div class="chat-time">
              {{ formatTime(chat.updatedAt) }}
            </div>
          </div>
        </div>
        
        <div class="chat-actions" @click.stop>
          <a-button
            type="text"
            size="small"
            @click="handleEditTitle(chat)"
          >
            <template #icon><EditOutlined /></template>
          </a-button>
          <a-button
            type="text"
            size="small"
            danger
            @click="handleDeleteChat(chat)"
          >
            <template #icon><DeleteOutlined /></template>
          </a-button>
        </div>
      </div>
      
      <a-empty v-if="chats.length === 0" description="暂无会话" />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { PlusOutlined, MessageOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { Modal, message } from 'ant-design-vue'

const props = defineProps({
  chats: {
    type: Array,
    default: () => []
  },
  currentChatId: {
    type: String,
    default: null
  }
})

const emit = defineEmits(['create', 'select', 'delete', 'update-title'])

const editingChatId = ref(null)
const editingTitle = ref('')

function handleCreateChat() {
  emit('create')
}

function handleSelectChat(chatId) {
  emit('select', chatId)
}

function handleDeleteChat(chat) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除会话 "${chat.title}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    onOk() {
      emit('delete', chat.id)
      message.success('会话删除成功')
    }
  })
}

function handleEditTitle(chat) {
  editingChatId.value = chat.id
  editingTitle.value = chat.title
}

function handleSaveTitle(chatId) {
  if (editingTitle.value.trim()) {
    emit('update-title', chatId, editingTitle.value.trim())
  }
  editingChatId.value = null
  editingTitle.value = ''
}

function formatTime(timeStr) {
  const date = new Date(timeStr)
  const now = new Date()
  const diff = now - date
  
  // 今天
  if (diff < 24 * 60 * 60 * 1000 && date.getDate() === now.getDate()) {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
  }
  
  // 昨天
  if (diff < 48 * 60 * 60 * 1000) {
    return '昨天'
  }
  
  // 一周内
  if (diff < 7 * 24 * 60 * 60 * 1000) {
    return `${Math.floor(diff / (24 * 60 * 60 * 1000))}天前`
  }
  
  // 更早
  return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' })
}
</script>

<style scoped>
.chat-list-container {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #fafafa;
}

.chat-list-header {
  padding: 16px;
  border-bottom: 1px solid #f0f0f0;
  background: #fff;
}

.chat-list {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.chat-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px;
  margin-bottom: 4px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.chat-item:hover {
  background: #e6f7ff;
}

.chat-item.active {
  background: #1890ff;
  color: #fff;
}

.chat-item-content {
  display: flex;
  align-items: center;
  flex: 1;
  overflow: hidden;
}

.chat-icon {
  width: 32px;
  height: 32px;
  border-radius: 6px;
  background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  flex-shrink: 0;
  color: #fff;
  font-size: 16px;
}

.chat-item.active .chat-icon {
  background: rgba(255, 255, 255, 0.2);
}

.chat-info {
  flex: 1;
  overflow: hidden;
}

.chat-title {
  font-size: 14px;
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 4px;
}

.chat-time {
  font-size: 12px;
  color: #8c8c8c;
}

.chat-item.active .chat-time {
  color: rgba(255, 255, 255, 0.8);
}

.chat-actions {
  display: flex;
  gap: 4px;
  opacity: 0;
  transition: opacity 0.2s;
}

.chat-item:hover .chat-actions {
  opacity: 1;
}

.chat-item.active .chat-actions :deep(.ant-btn) {
  color: rgba(255, 255, 255, 0.8);
}

.chat-item.active .chat-actions :deep(.ant-btn:hover) {
  color: #fff;
}

:deep(.ant-empty-description) {
  color: #8c8c8c;
}
</style>
