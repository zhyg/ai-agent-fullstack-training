# Tasks: 知识库平台原型

**Input**: Design documents from `specs/001-knowledge-base-platform/`

**Prerequisites**: plan.md ✅, spec.md ✅, research.md ✅, data-model.md ✅, contracts/ ✅

**Tests**: 原型阶段不要求自动化测试，所有验证通过手动测试完成（参考 quickstart.md）

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup (项目初始化)

**Purpose**: 创建 Vue 3 项目并安装依赖

- [x] T001 使用 Vite 创建 Vue 3 项目：运行 `npm create vite@latest . -- --template vue` 在项目根目录
- [x] T002 安装核心依赖：运行 `npm install ant-design-vue@4 vue-router@4`
- [x] T003 [P] 创建项目目录结构：`src/router/`, `src/stores/`, `src/composables/`, `src/views/`, `src/components/layout/`, `src/components/model/`, `src/components/knowledge-base/`
- [x] T004 [P] 配置 `src/main.js` 入口文件：导入并注册 Ant Design Vue 全局组件，创建 Vue app 实例，挂载 router

---

## Phase 2: Foundational (基础架构)

**Purpose**: 核心基础设施，所有 User Story 的前置依赖

**⚠️ CRITICAL**: 本阶段完成前，不可开始任何 User Story 的实现

- [x] T005 [P] 创建 localStorage 操作封装 composable，提供 `getItem(key)`, `setItem(key, value)`, `removeItem(key)` 方法，在 `src/composables/useStorage.js`
- [x] T006 [P] 创建 ID 生成工具函数 `generateId()`：使用 `Date.now().toString(36) + Math.random().toString(36).substr(2, 9)` 生成唯一 ID，在 `src/composables/useStorage.js` 中导出
- [x] T007 实现模型数据 Store `useModelStore`：提供 `getModels()`, `getModelById(id)`, `createModel(data)`, `updateModel(id, data)`, `deleteModel(id)` 方法，使用 localStorage key `kb_models`，Model 实体包含字段 id(String,required), name(String,required,非空), url(String,required,非空), key(String,required,非空), createdAt(Number), updatedAt(Number)，在 `src/stores/model.js`
- [x] T008 实现知识库数据 Store `useKbStore`：提供 `getKnowledgeBases()`, `getKbById(id)`, `createKb(data)`, `updateKb(id, data)`, `deleteKb(id)` 方法，使用 localStorage key `kb_knowledge_bases`，KnowledgeBase 实体包含字段 id(String,required), name(String,required,非空), description(String,optional), llmModelId(String,required,非空), embeddingModelId(String,required,非空), imageModelId(String,required,非空), rerankModelId(String,required,非空), createdAt(Number), updatedAt(Number)，在 `src/stores/knowledgeBase.js`
- [x] T009 [P] 配置 vue-router 路由：`/` 重定向到 `/knowledge-base`，`/knowledge-base` 指向知识库页面，`/models` 指向模型管理页面，使用 `createWebHashHistory`，在 `src/router/index.js`
- [x] T010 实现 AppLayout 布局组件：使用 `a-layout` + `a-layout-sider`(固定宽度 200px) + `a-layout-content`，侧边栏内嵌 `a-menu`(mode="inline")，菜单项为"新会话"(disabled)、"知识库"(/knowledge-base)、"智能体"(disabled)、"模型管理"(/models)，selectedKeys 绑定当前路由，内容区域使用 `router-view`，在 `src/components/layout/AppLayout.vue`
- [x] T011 配置 `src/App.vue`：使用 AppLayout 作为根布局组件

**Checkpoint**: 基础架构就绪——应用可启动并显示侧边栏导航，路由可切换

---

## Phase 3: User Story 1 - 模型管理：创建与配置模型 (Priority: P1) 🎯 MVP

**Goal**: 用户可以查看模型列表、创建新模型、编辑已有模型、删除模型

**Independent Test**: 可以独立测试模型完整生命周期——创建模型 → 查看列表 → 修改配置 → 删除模型，刷新页面后数据保留

### Implementation for User Story 1

- [x] T012 [P] [US1] 实现 EmptyModel 空状态组件：使用 `a-empty` + `a-button`，显示引导文案"还没有模型，立即创建第一个"，点击按钮触发 `create` 事件，在 `src/components/model/EmptyModel.vue`
- [x] T013 [P] [US1] 实现 ModelCard 模型卡片组件：使用 `a-card`，Props: model(Model,required)；展示模型名称（标题）、URL 摘要（`a-tooltip` hover 显示完整 URL）；包含"设置"和"删除"按钮，分别触发 `edit` 和 `delete` 事件，在 `src/components/model/ModelCard.vue`
- [x] T014 [US1] 实现 ModelList 模型列表组件：Props: models(Model[],required)；遍历 models 渲染 ModelCard 列表；models 为空时渲染 EmptyModel；包含页面顶部"新建模型"按钮；冒泡 `create`, `edit`, `delete` 事件，在 `src/components/model/ModelList.vue`
- [x] T015 [US1] 实现 ModelFormDrawer 模型表单抽屉组件：Props: visible(Boolean,required), model(Model|null,optional,default=null)；使用 `a-drawer` + `a-form`；表单字段：name(`a-input`,required,验证规则 `[{required:true,message:'请输入模型名称'}]`)、url(`a-input`,required,验证规则 `[{required:true,message:'请输入模型 URL'}]`)、key(`a-input`,required,验证规则 `[{required:true,message:'请输入 API Key'}]`)；model 非 null 时预填已有值；提交时触发 `submit` 事件传递 `{name,url,key}`；关闭时触发 `close` 事件，在 `src/components/model/ModelFormDrawer.vue`
- [x] T016 [US1] 实现 ModelManagement 模型管理页面：使用 useModelStore 获取模型列表；管理状态 models/drawerVisible/editingModel；"新建模型"按钮打开 ModelFormDrawer(editingModel=null)；卡片"设置"按钮打开 ModelFormDrawer(editingModel=model)；卡片"删除"按钮使用 `Modal.confirm` 弹出确认对话框；创建/编辑/删除操作调用 store 对应方法并刷新列表，在 `src/views/ModelManagement.vue`

**Checkpoint**: 模型管理功能完整可用，可独立测试

---

## Phase 4: User Story 2 - 知识库管理：创建与配置知识库 (Priority: P2)

**Goal**: 用户可以查看知识库列表、创建新知识库（选择四种模型）、编辑已有知识库、删除知识库

**Independent Test**: 在已有至少一个模型的前提下，测试知识库完整生命周期——创建知识库 → 查看列表 → 修改配置 → 删除知识库，刷新页面后数据保留

### Implementation for User Story 2

- [x] T017 [P] [US2] 实现 EmptyKb 知识库空状态组件：使用 `a-empty` + `a-button`，显示引导文案"还没有知识库，立即创建第一个"，点击按钮触发 `create` 事件，在 `src/components/knowledge-base/EmptyKb.vue`
- [x] T018 [P] [US2] 实现 KbCard 知识库卡片组件：使用 `a-card`，Props: kb(KnowledgeBase,required), models(Model[],required)；展示知识库名称（标题）、描述摘要（截断显示）、关联的四个模型名称（通过 model ID 从 models 数组查找显示名称）；包含"设置"和"删除"按钮，分别触发 `edit` 和 `delete` 事件，在 `src/components/knowledge-base/KbCard.vue`
- [x] T019 [US2] 实现 KbList 知识库列表组件：Props: knowledgeBases(KnowledgeBase[],required), models(Model[],required)；遍历 knowledgeBases 渲染 KbCard 列表；knowledgeBases 为空时渲染 EmptyKb；包含页面顶部"新建知识库"按钮；冒泡 `create`, `edit`, `delete` 事件，在 `src/components/knowledge-base/KbList.vue`
- [x] T020 [US2] 实现 KbCreateModal 知识库创建对话框组件：Props: visible(Boolean,required), models(Model[],required)；使用 `a-modal` + `a-form`；表单字段：name(`a-input`,required,验证规则 `[{required:true,message:'请输入知识库名称'}]`)、description(`a-textarea`,optional)、llmModelId(`a-select`,required,验证规则 `[{required:true,message:'请选择 LLM 模型'}]`,options 从 models 映射)、embeddingModelId(`a-select`,required,同上)、imageModelId(`a-select`,required,同上)、rerankModelId(`a-select`,required,同上)；当 models 为空时选择框显示 placeholder "请先创建模型"且禁止提交；提交时触发 `submit` 事件，在 `src/components/knowledge-base/KbCreateModal.vue`
- [x] T021 [US2] 实现 KbFormDrawer 知识库编辑抽屉组件：Props: visible(Boolean,required), kb(KnowledgeBase,required), models(Model[],required)；使用 `a-drawer` + `a-form`；表单字段同 KbCreateModal 但预填 kb 的当前值；提交时触发 `submit` 事件，在 `src/components/knowledge-base/KbFormDrawer.vue`
- [x] T022 [US2] 实现 KnowledgeBase 知识库管理页面：使用 useKbStore 和 useModelStore 获取知识库列表和模型列表；管理状态 knowledgeBases/models/createModalVisible/drawerVisible/editingKb；"新建知识库"按钮打开 KbCreateModal；卡片"设置"按钮打开 KbFormDrawer；卡片"删除"按钮使用 `Modal.confirm` 弹出确认对话框；创建/编辑/删除操作调用 store 对应方法并刷新列表，在 `src/views/KnowledgeBase.vue`

**Checkpoint**: 知识库管理功能完整可用，可独立测试

---

## Phase 5: User Story 3 - 侧边栏导航与页面切换 (Priority: P3)

**Goal**: 用户通过侧边栏菜单在知识库和模型管理页面之间切换，默认展示知识库页面

**Independent Test**: 点击各菜单项后页面正确切换，菜单高亮正确，默认页面为知识库

### Implementation for User Story 3

- [x] T023 [US3] 验证并完善 AppLayout 导航行为：确保侧边栏菜单点击后路由正确切换（`/knowledge-base` 和 `/models`），selectedKeys 与当前路由同步高亮，"新会话"和"智能体"菜单项为 disabled 状态不可点击，首次加载默认展示知识库页面，在 `src/components/layout/AppLayout.vue`

**Checkpoint**: 导航功能完整可用，所有页面可通过菜单切换

---

## Phase 6: Polish & Cross-Cutting Concerns (打磨)

**Purpose**: 全局优化和最终验证

- [x] T024 [P] 确保所有对话框/抽屉已打开时忽略重复点击"新建"按钮（通过 v-model 控制 visible 状态，已打开时不重复弹出）
- [x] T025 [P] 验证所有表单必填字段校验：模型表单（name/url/key 非空）、知识库表单（name 非空 + 四个模型必选），校验不通过时阻止提交并显示红色错误提示
- [x] T026 验证 localStorage 持久化：创建数据 → 刷新页面 → 数据仍然完整保留
- [x] T027 执行 quickstart.md 中的全部 7 个验证场景，确认所有预期结果通过

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖——立即开始
- **Foundational (Phase 2)**: 依赖 Setup 完成——**阻塞所有 User Story**
- **US1 - 模型管理 (Phase 3)**: 依赖 Foundational 完成
- **US2 - 知识库管理 (Phase 4)**: 依赖 Foundational 完成，功能上依赖 US1 的模型 Store（但可独立实现 UI）
- **US3 - 导航 (Phase 5)**: 依赖 Foundational 完成（AppLayout 已在 Phase 2 创建，此阶段为验证完善）
- **Polish (Phase 6)**: 依赖所有 User Story 完成

### User Story Dependencies

- **US1 (P1)**: Foundational 完成后可开始，无 Story 间依赖
- **US2 (P2)**: Foundational 完成后可开始，需要 useModelStore 提供模型列表给知识库表单的下拉选择框
- **US3 (P3)**: Foundational 完成后可开始，主要是验证 AppLayout 已有功能

### Within Each User Story

- 子组件（Card, Empty, Drawer, Modal）→ 列表组件 → 页面组件
- 页面组件集成所有子组件和 Store

### Parallel Opportunities

- T003 和 T004 可并行
- T005 和 T006 可并行
- T009 和 T010 可并行
- US1 的 T012 和 T013 可并行
- US2 的 T017 和 T018 可并行
- Phase 6 的 T024 和 T025 可并行

---

## Parallel Example: User Story 1

```text
# 并行创建子组件：
Task T012: "实现 EmptyModel 空状态组件 in src/components/model/EmptyModel.vue"
Task T013: "实现 ModelCard 模型卡片组件 in src/components/model/ModelCard.vue"

# 然后依次：
Task T014: "实现 ModelList 模型列表组件 (依赖 T012, T013)"
Task T015: "实现 ModelFormDrawer 模型表单抽屉组件"
Task T016: "实现 ModelManagement 页面 (依赖 T014, T015)"
```

## Parallel Example: User Story 2

```text
# 并行创建子组件：
Task T017: "实现 EmptyKb 空状态组件 in src/components/knowledge-base/EmptyKb.vue"
Task T018: "实现 KbCard 知识库卡片组件 in src/components/knowledge-base/KbCard.vue"

# 然后依次：
Task T019: "实现 KbList 知识库列表组件 (依赖 T017, T018)"
Task T020: "实现 KbCreateModal 知识库创建对话框"
Task T021: "实现 KbFormDrawer 知识库编辑抽屉"
Task T022: "实现 KnowledgeBase 页面 (依赖 T019, T020, T021)"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL - blocks all stories)
3. Complete Phase 3: User Story 1 (模型管理)
4. **STOP and VALIDATE**: 手动测试模型的创建、编辑、删除、刷新保留
5. 可演示/交付

### Incremental Delivery

1. Setup + Foundational → 基础架构就绪
2. Add US1 (模型管理) → 手动测试 → 可演示 (**MVP!**)
3. Add US2 (知识库管理) → 手动测试 → 可演示
4. Add US3 (导航验证) → 手动测试 → 可演示
5. Polish → 全面验证 → 完整交付

---

## Notes

- [P] tasks = 不同文件，无依赖，可并行执行
- [Story] label 映射任务到具体 User Story
- 每个 User Story 应可独立完成和测试
- 每完成一个任务或逻辑组后提交
- 在任何 Checkpoint 可停下来独立验证 Story
- 避免：模糊任务、同文件冲突、破坏独立性的跨 Story 依赖
