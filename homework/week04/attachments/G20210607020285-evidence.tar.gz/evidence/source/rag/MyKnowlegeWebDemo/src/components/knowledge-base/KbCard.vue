<template>
  <div class="kb-card" @mouseenter="hovered = true" @mouseleave="hovered = false" @click="$emit('enter', kb)">
    <div class="card-header">
      <div class="card-icon">
        <DatabaseOutlined />
      </div>
      <div class="card-title-area">
        <span class="card-title">{{ kb.name }}</span>
        <span v-if="kb.description" class="card-desc">{{ kb.description }}</span>
      </div>
      <div class="card-actions">
        <a-button type="text" size="small" @click.stop="$emit('edit', kb)">
          <template #icon><EditOutlined /></template>
          设置
        </a-button>
        <a-button type="text" size="small" danger @click.stop="$emit('delete', kb)">
          <template #icon><DeleteOutlined /></template>
          删除
        </a-button>
      </div>
    </div>
    <div class="card-models">
      <div class="model-tag">
        <span class="tag-label">LLM</span>
        <span class="tag-value">{{ getModelName(kb.llmModelId) }}</span>
      </div>
      <div class="model-tag">
        <span class="tag-label">Embedding</span>
        <span class="tag-value">{{ getModelName(kb.embeddingModelId) }}</span>
      </div>
      <div class="model-tag">
        <span class="tag-label">图片识别</span>
        <span class="tag-value">{{ getModelName(kb.imageModelId) }}</span>
      </div>
      <div class="model-tag">
        <span class="tag-label">Rerank</span>
        <span class="tag-value">{{ getModelName(kb.rerankModelId) }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import {
  DatabaseOutlined,
  EditOutlined,
  DeleteOutlined
} from '@ant-design/icons-vue'

const props = defineProps({
  kb: {
    type: Object,
    required: true
  },
  models: {
    type: Array,
    required: true
  }
})

defineEmits(['enter', 'edit', 'delete'])

const hovered = ref(false)

function getModelName(modelId) {
  const model = props.models.find(m => m.id === modelId)
  return model ? model.name : '(已删除)'
}
</script>

<style scoped>
.kb-card {
  background: linear-gradient(135deg, #f0f7ff 0%, #e8f4fd 50%, #f5f0ff 100%);
  border: 1px solid #dce9f7;
  border-radius: 12px;
  padding: 20px 24px;
  margin-bottom: 12px;
  transition: all 0.3s ease;
  cursor: pointer;
}

.kb-card:hover {
  background: linear-gradient(135deg, #e8f2fc 0%, #ddeefb 50%, #eee8fc 100%);
  border-color: #b8d4f0;
  box-shadow: 0 4px 12px rgba(0, 80, 180, 0.06);
  transform: translateY(-1px);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 16px;
}

.card-icon {
  width: 42px;
  height: 42px;
  background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 20px;
  flex-shrink: 0;
}

.card-title-area {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.card-title {
  font-size: 15px;
  font-weight: 600;
  color: #1f1f1f;
  line-height: 1.4;
}

.card-desc {
  font-size: 13px;
  color: #8c8c8c;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.4;
}

.card-actions {
  display: flex;
  gap: 4px;
  flex-shrink: 0;
}

.card-actions .ant-btn {
  font-size: 13px;
  border-radius: 6px;
}

.card-actions .ant-btn:hover {
  background: #f5f5f5;
}

.card-actions .ant-btn-dangerous:hover {
  background: #fff1f0;
}

.card-models {
  margin-top: 16px;
  padding-top: 14px;
  border-top: 1px solid #f5f5f5;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px 24px;
}

.model-tag {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
}

.tag-label {
  color: #8c8c8c;
  flex-shrink: 0;
  min-width: 60px;
}

.tag-value {
  color: #595959;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
