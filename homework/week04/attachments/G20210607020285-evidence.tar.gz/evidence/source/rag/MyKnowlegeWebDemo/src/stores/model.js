import { reactive } from 'vue'
import { getItem, setItem, generateId } from '../composables/useStorage.js'
import { getModelCategory } from '../utils/model.js'

const MODELS_KEY = 'models'

const state = reactive({
  models: (getItem(MODELS_KEY) || []).map(model => ({
    ...model,
    category: getModelCategory(model),
    provider: model.provider || 'Open AI',
    displayName: model.displayName || model.name
  }))
})

function persist() {
  setItem(MODELS_KEY, state.models)
}

export function useModelStore() {
  function getModelById(id) {
    return state.models.find(m => m.id === id) || null
  }

  function createModel(data) {
    const now = Date.now()
    const model = {
      id: generateId(),
      name: data.name,
      displayName: data.displayName || data.name,
      provider: data.provider || 'Open AI',
      category: getModelCategory(data),
      url: data.url,
      key: data.key,
      maxToken: data.maxToken || null,
      rpm: data.rpm ?? null,
      tpm: data.tpm ?? null,
      inputPerMillion: data.inputPerMillion ?? null,
      outputPerMillion: data.outputPerMillion ?? null,
      cachedInputPerMillion: data.cachedInputPerMillion ?? null,
      createdAt: now,
      updatedAt: now
    }
    state.models.push(model)
    persist()
    return model
  }

  function updateModel(id, data) {
    const index = state.models.findIndex(m => m.id === id)
    if (index === -1) return null
    state.models[index] = {
      ...state.models[index],
      ...data,
      updatedAt: Date.now()
    }
    persist()
    return state.models[index]
  }

  function deleteModel(id) {
    const index = state.models.findIndex(m => m.id === id)
    if (index !== -1) {
      state.models.splice(index, 1)
      persist()
    }
  }

  return {
    state,
    getModelById,
    createModel,
    updateModel,
    deleteModel
  }
}
