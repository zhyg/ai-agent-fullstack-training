/**
 * 目录树工具函数
 * - buildTree：扁平目录 → a-tree treeData
 * - isDescendant：判断祖先关系（拖拽校验）
 * - resolveConflictName：解决同级同名冲突
 */

/**
 * 将扁平目录数组构建为 a-tree 需要的嵌套树数据
 * @param {Array} flatFolders 所有目录（扁平）
 * @param {string} kbId 知识库 ID
 * @returns {Array<TreeNode>} a-tree treeData
 */
export function buildTree(flatFolders, kbId) {
  const scoped = flatFolders.filter((f) => f.kbId === kbId)
  const groupByParent = new Map()
  for (const folder of scoped) {
    const key = folder.parentId ?? '__root__'
    if (!groupByParent.has(key)) groupByParent.set(key, [])
    groupByParent.get(key).push(folder)
  }
  for (const [, list] of groupByParent) {
    list.sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  }

  const buildChildren = (parentId) => {
    const key = parentId ?? '__root__'
    const children = groupByParent.get(key) || []
    return children.map((folder) => ({
      key: folder.id,
      title: folder.name,
      children: buildChildren(folder.id),
      // 透传元数据，方便组件直接使用
      isLeaf: !(groupByParent.get(folder.id) && groupByParent.get(folder.id).length > 0),
      raw: folder
    }))
  }

  return buildChildren(null)
}

/**
 * 判断 ancestorId 是否是 descendantId 的祖先（含自身）
 * @param {Array} flatFolders
 * @param {string} ancestorId
 * @param {string} descendantId
 * @returns {boolean}
 */
export function isDescendant(flatFolders, ancestorId, descendantId) {
  if (ancestorId === descendantId) return true
  const byId = new Map(flatFolders.map((f) => [f.id, f]))
  let currentId = descendantId
  let safety = flatFolders.length + 1
  while (currentId && safety-- > 0) {
    const current = byId.get(currentId)
    if (!current) return false
    if (current.parentId === ancestorId) return true
    currentId = current.parentId
  }
  return false
}

/**
 * 解决同级目录同名冲突：按"原名(1)"、"原名(2)"递增
 * @param {string[]} siblingNames 同级已有目录名数组
 * @param {string} desiredName 期望名称
 * @returns {string} 不冲突的最终名称
 */
export function resolveConflictName(siblingNames, desiredName) {
  if (!siblingNames.includes(desiredName)) return desiredName

  // 解析 base 与 (N) 后缀
  const match = desiredName.match(/^(.*?)(?:\((\d+)\))?$/)
  const base = (match[1] ?? desiredName).trim() || desiredName

  let i = 1
  while (siblingNames.includes(`${base}(${i})`)) {
    i++
  }
  return `${base}(${i})`
}
