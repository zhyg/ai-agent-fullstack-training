<template>
  <div class="chat-area-container">
    <div v-if="!currentChat" class="empty-state">
      <a-empty description="选择或创建一个会话开始聊天">
        <template #image>
          <div class="empty-icon">
            <MessageOutlined />
          </div>
        </template>
        <a-button type="primary" @click="$emit('create-chat')">
          <template #icon><PlusOutlined /></template>
          新建会话
        </a-button>
      </a-empty>
    </div>
    
    <div v-else class="chat-content">
      <div class="chat-header">
        <div class="chat-header-title">
          <MessageOutlined style="margin-right: 8px; color: #1890ff;" />
          {{ currentChat.title }}
        </div>
        <div class="chat-header-info">
          <a-tag v-if="currentChat.model" color="blue">
            <template #icon><ApiOutlined /></template>
            {{ getModelName(currentChat.model) }}
          </a-tag>
          <a-tag v-if="currentChat.prompt" color="green">
            <template #icon><FileTextOutlined /></template>
            {{ currentChat.prompt.name }}
          </a-tag>
        </div>
      </div>
      
      <div class="messages-container" ref="messagesContainer">
        <div v-if="currentChat.messages.length === 0" class="messages-empty">
          <div class="welcome-message">
            <div class="welcome-icon">
              <RobotOutlined />
            </div>
            <h3>你好！我是 AI 助手</h3>
            <p>有什么我可以帮助你的吗？</p>
          </div>
        </div>
        
        <div
          v-for="message in currentChat.messages"
          :key="message.id"
          :class="['message-item', message.role]"
        >
          <div class="message-avatar">
            <a-avatar v-if="message.role === 'user'" :size="36">
              <template #icon><UserOutlined /></template>
            </a-avatar>
            <a-avatar
              v-else
              :size="36"
              style="background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);"
            >
              <template #icon><RobotOutlined /></template>
            </a-avatar>
          </div>
          <div class="message-content">
            <div class="message-header">
              {{ message.role === 'user' ? '你' : 'AI 助手' }}
              <span class="message-time">{{ formatMessageTime(message.timestamp) }}</span>
            </div>
            <div class="message-text">{{ message.content }}</div>
          </div>
        </div>
        
        <div v-if="isLoading" class="message-item assistant">
          <div class="message-avatar">
            <a-avatar
              :size="36"
              style="background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);"
            >
              <template #icon><RobotOutlined /></template>
            </a-avatar>
          </div>
          <div class="message-content">
            <div class="message-header">AI 助手</div>
            <div class="message-text typing">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        </div>
      </div>
      
      <MessageInput
        :models="models"
        :prompts="prompts"
        :current-model="currentChat.model"
        :current-prompt="currentChat.prompt"
        @send="handleSend"
        @model-change="handleModelChange"
        @prompt-change="handlePromptChange"
        ref="messageInputRef"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, watch, nextTick } from 'vue'
import {
  MessageOutlined,
  UserOutlined,
  RobotOutlined,
  PlusOutlined,
  ApiOutlined,
  FileTextOutlined
} from '@ant-design/icons-vue'
import MessageInput from './MessageInput.vue'

const props = defineProps({
  currentChat: {
    type: Object,
    default: null
  },
  models: {
    type: Array,
    default: () => []
  },
  prompts: {
    type: Array,
    default: () => []
  },
  isLoading: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['send-message', 'model-change', 'prompt-change', 'create-chat'])

const messagesContainer = ref(null)
const messageInputRef = ref(null)

// 监听消息变化，自动滚动到底部
watch(
  () => props.currentChat?.messages,
  () => {
    nextTick(() => {
      if (messagesContainer.value) {
        messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
      }
    })
  },
  { deep: true }
)

// 监听会话变化，设置输入框的模型和提示词
watch(
  () => props.currentChat,
  (newChat) => {
    if (newChat && messageInputRef.value) {
      if (newChat.model) {
        messageInputRef.value.setModel(newChat.model.id)
      }
      if (newChat.prompt) {
        messageInputRef.value.setPrompt(newChat.prompt.id)
      }
    }
  },
  { immediate: true }
)

function getModelName(model) {
  if (typeof model === 'string') {
    const found = props.models.find(m => m.id === model)
    return found ? found.name : model
  }
  return model?.name || '未知模型'
}

function formatMessageTime(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleTimeString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

function handleSend(data) {
  emit('send-message', data)
}

function handleModelChange(model) {
  emit('model-change', model)
}

function handlePromptChange(prompt) {
  emit('prompt-change', prompt)
}
</script>

<style scoped>
.chat-area-container {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #fff;
}

.empty-state {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.empty-icon {
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  font-size: 36px;
  color: #fff;
}

.chat-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.chat-header {
  padding: 16px 24px;
  border-bottom: 1px solid #f0f0f0;
  background: #fafafa;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.chat-header-title {
  font-size: 16px;
  font-weight: 600;
  color: #1f1f1f;
}

.chat-header-info {
  display: flex;
  gap: 8px;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
}

.messages-empty {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.welcome-message {
  text-align: center;
}

.welcome-icon {
  width: 64px;
  height: 64px;
  background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
  font-size: 28px;
  color: #fff;
}

.welcome-message h3 {
  font-size: 20px;
  font-weight: 600;
  color: #1f1f1f;
  margin: 0 0 8px 0;
}

.welcome-message p {
  font-size: 14px;
  color: #8c8c8c;
  margin: 0;
}

.message-item {
  display: flex;
  margin-bottom: 24px;
}

.message-item.user {
  flex-direction: row-reverse;
}

.message-avatar {
  margin: 0 12px;
  flex-shrink: 0;
}

.message-content {
  max-width: 70%;
}

.message-header {
  font-size: 12px;
  color: #8c8c8c;
  margin-bottom: 4px;
}

.message-time {
  margin-left: 8px;
}

.message-text {
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.6;
  word-wrap: break-word;
}

.message-item.user .message-header {
  text-align: right;
}

.message-item.user .message-text {
  background: #1890ff;
  color: #fff;
  border-top-right-radius: 4px;
}

.message-item.assistant .message-text {
  background: #f5f5f5;
  color: #1f1f1f;
  border-top-left-radius: 4px;
}

/* 打字动画 */
.message-text.typing {
  display: flex;
  gap: 4px;
  padding: 16px;
}

.message-text.typing span {
  width: 8px;
  height: 8px;
  background: #8c8c8c;
  border-radius: 50%;
  animation: typing 1.4s infinite ease-in-out;
}

.message-text.typing span:nth-child(1) {
  animation-delay: 0s;
}

.message-text.typing span:nth-child(2) {
  animation-delay: 0.2s;
}

.message-text.typing span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
  }
  30% {
    transform: translateY(-10px);
  }
}
</style>
