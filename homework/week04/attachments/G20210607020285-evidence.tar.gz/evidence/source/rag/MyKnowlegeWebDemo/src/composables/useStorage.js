const STORAGE_PREFIX = 'kb_'
const INDEXED_DB_NAME = 'kb_files_db'
const INDEXED_DB_VERSION = 1

// ========== localStorage 封装 ==========

export function getItem(key) {
  const raw = localStorage.getItem(STORAGE_PREFIX + key)
  if (raw === null) return null
  try {
    return JSON.parse(raw)
  } catch {
    return raw
  }
}

export function setItem(key, value) {
  localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value))
}

export function removeItem(key) {
  localStorage.removeItem(STORAGE_PREFIX + key)
}

export function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9)
}

// ========== IndexedDB 封装 ==========

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(INDEXED_DB_NAME, INDEXED_DB_VERSION)
    request.onupgradeneeded = (event) => {
      const db = event.target.result
      if (!db.objectStoreNames.contains('files')) {
        db.createObjectStore('files')
      }
      if (!db.objectStoreNames.contains('parsed_contents')) {
        db.createObjectStore('parsed_contents')
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

async function runTx(storeName, mode, fn) {
  const db = await openDb()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode)
    const store = tx.objectStore(storeName)
    const result = fn(store)
    tx.oncomplete = () => resolve(result?.__resolve !== undefined ? result.__resolve : undefined)
    tx.onerror = () => reject(tx.error)
    // 支持 fn 返回 Promise 的场景
    if (result && typeof result.then === 'function') {
      result
        .then((value) => {
          tx.oncomplete = () => resolve(value)
        })
        .catch((err) => {
          try { tx.abort() } catch {}
          reject(err)
        })
    }
  })
}

export async function saveBlob(storeName, key, blob) {
  const db = await openDb()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite')
    tx.objectStore(storeName).put(blob, key)
    tx.oncomplete = () => resolve()
    tx.onerror = () => reject(tx.error)
  })
}

export async function getBlob(storeName, key) {
  const db = await openDb()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly')
    const req = tx.objectStore(storeName).get(key)
    req.onsuccess = () => resolve(req.result ?? null)
    req.onerror = () => reject(req.error)
  })
}

export async function deleteBlob(storeName, key) {
  const db = await openDb()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite')
    tx.objectStore(storeName).delete(key)
    tx.oncomplete = () => resolve()
    tx.onerror = () => reject(tx.error)
  })
}

export async function saveText(storeName, key, text) {
  return saveBlob(storeName, key, text)
}

export async function getText(storeName, key) {
  const value = await getBlob(storeName, key)
  return value === null ? null : String(value)
}

// runTx 目前未使用，保留以备未来扩展
void runTx
