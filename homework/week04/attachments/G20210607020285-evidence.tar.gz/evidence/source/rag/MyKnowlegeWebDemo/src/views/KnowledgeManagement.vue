<template>
  <div class="knowledge-management" v-if="currentKb">
    <div class="km-header">
      <a-button type="text" @click="goBack">
        <template #icon><ArrowLeftOutlined /></template>
        返回
      </a-button>
      <h2 style="margin: 0;">
        {{ currentKb.name }}
        <span class="km-subtitle">/ 知识管理</span>
      </h2>
    </div>

    <div class="km-body">
      <aside class="km-sidebar">
        <FolderTree
          :kb-id="currentKb.id"
          :selected-folder-id="currentFolderId"
          @select="handleFolderSelect"
          @create-root="openFolderAction('create-root', null)"
          @create-child="(parent) => openFolderAction('create-child', parent)"
          @rename="(folder) => openFolderAction('rename', folder)"
          @delete="(folder) => openFolderAction('delete', folder)"
          @drop="handleFolderDrop"
        />
      </aside>

      <section class="km-main">
        <DocumentTable
          :folder-id="currentFolderId"
          :folder-name="currentFolderName"
          :documents="currentDocuments"
          :selected-row-keys="selectedRowKeys"
          @select-change="(keys) => (selectedRowKeys = keys)"
          @row-click="openDocumentDetail"
          @create="openCreateDocModal"
          @batch-delete="handleBatchDelete"
          @delete="handleDeleteDocument"
          @add-tag="openDocAction"
          @remove-tag="handleRemoveTag"
        />
      </section>
    </div>

    <!-- 目录操作模态框（US2） -->
    <FolderActionModal
      :visible="folderActionState.visible"
      :type="folderActionState.type"
      :folder="folderActionState.targetFolder"
      :kb-id="currentKb.id"
      @close="closeFolderAction"
      @submit="handleFolderActionSubmit"
    />

    <!-- 新建知识模态框（US3） -->
    <DocumentCreateModal
      :visible="createDocModalVisible"
      :folder-id="currentFolderId"
      :kb-id="currentKb.id"
      @close="closeCreateDocModal"
      @submit="handleCreateDocument"
    />

    <!-- 详情抽屉（US3/US5） -->
    <DocumentDetailDrawer
      :visible="detailDrawerVisible"
      :document="viewingDocument"
      @close="closeDocumentDetail"
      @add-tag="openDocAction"
      @remove-tag="handleRemoveTag"
    />

    <!-- 标签操作模态框（US6） -->
    <DocumentActionModal
      :visible="docActionState.visible"
      :document="docActionState.targetDocument"
      @close="closeDocAction"
      @submit="handleDocActionSubmit"
    />
  </div>

  <a-result
    v-else
    status="404"
    title="知识库不存在"
    sub-title="您访问的知识库不存在或已被删除"
  >
    <template #extra>
      <a-button type="primary" @click="goBack">返回知识库列表</a-button>
    </template>
  </a-result>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { message, Modal } from 'ant-design-vue'
import { ArrowLeftOutlined } from '@ant-design/icons-vue'
import { useKbStore } from '../stores/knowledgeBase.js'
import { useFolderStore } from '../stores/folder.js'
import { useDocumentStore } from '../stores/document.js'
import FolderTree from '../components/knowledge/FolderTree.vue'
import DocumentTable from '../components/knowledge/DocumentTable.vue'
import FolderActionModal from '../components/knowledge/FolderActionModal.vue'
import DocumentCreateModal from '../components/knowledge/DocumentCreateModal.vue'
import DocumentDetailDrawer from '../components/knowledge/DocumentDetailDrawer.vue'
import DocumentActionModal from '../components/knowledge/DocumentActionModal.vue'

const route = useRoute()
const router = useRouter()
const kbStore = useKbStore()
const folderStore = useFolderStore()
const documentStore = useDocumentStore()

const kbId = computed(() => route.params.kbId)
const currentKb = computed(() => (kbId.value ? kbStore.getKbById(kbId.value) : null))

const currentFolderId = ref(null)
const currentFolderName = computed(() => {
  if (!currentFolderId.value) return ''
  const f = folderStore.getFolderById(currentFolderId.value)
  return f ? f.name : ''
})

const currentDocuments = computed(() => {
  if (!currentFolderId.value) return []
  return documentStore.getDocumentsByFolderId(currentFolderId.value)
})

const selectedRowKeys = ref([])

// 目录操作状态
const folderActionState = ref({
  visible: false,
  type: 'create-root',
  targetFolder: null
})

// 文档创建模态框
const createDocModalVisible = ref(false)

// 文档详情抽屉
const detailDrawerVisible = ref(false)
const viewingDocument = ref(null)

// 文档标签操作
const docActionState = ref({
  visible: false,
  targetDocument: null
})

// 路由变化时重置状态
watch(
  kbId,
  () => {
    currentFolderId.value = null
    selectedRowKeys.value = []
    // 自动选中第一个根目录（若有）
    const rootFolders = folderStore
      .getFoldersByKbId(kbId.value)
      .filter((f) => (f.parentId ?? null) === null)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
    if (rootFolders.length > 0) {
      currentFolderId.value = rootFolders[0].id
    }
  },
  { immediate: true }
)

function goBack() {
  router.push({ name: 'KnowledgeBase' })
}

function handleFolderSelect(folder) {
  currentFolderId.value = folder ? folder.id : null
  selectedRowKeys.value = []
}

function openFolderAction(type, folder) {
  folderActionState.value = { visible: true, type, targetFolder: folder }
}
function closeFolderAction() {
  folderActionState.value.visible = false
}
function handleFolderActionSubmit(data) {
  // 由 US2 阶段的 FolderActionModal 调用，此处做分发
  try {
    if (folderActionState.value.type === 'create-root') {
      folderStore.createFolder({
        kbId: currentKb.value.id,
        parentId: null,
        name: data.name
      })
      message.success('根目录创建成功')
    } else if (folderActionState.value.type === 'create-child') {
      folderStore.createFolder({
        kbId: currentKb.value.id,
        parentId: folderActionState.value.targetFolder.id,
        name: data.name
      })
      message.success('子目录创建成功')
    } else if (folderActionState.value.type === 'rename') {
      folderStore.renameFolder(folderActionState.value.targetFolder.id, data.name)
      message.success('目录重命名成功')
    } else if (folderActionState.value.type === 'delete') {
      Modal.confirm({
        title: '确认删除',
        content: `确定要删除目录 "${folderActionState.value.targetFolder.name}" 及其所有子目录与文档吗？`,
        okText: '确认',
        cancelText: '取消',
        okButtonProps: { danger: true },
        onOk: () => {
          folderStore.deleteFolder(
            folderActionState.value.targetFolder.id,
            (folderId) => documentStore.deleteDocumentsByFolderId(folderId)
          )
          if (currentFolderId.value === folderActionState.value.targetFolder.id) {
            currentFolderId.value = null
          }
          message.success('目录删除成功')
          closeFolderAction()
        }
      })
      return // 删除需要二次确认，不在此处关闭
    }
    closeFolderAction()
  } catch (err) {
    message.error(err.message || '操作失败')
  }
}

function handleFolderDrop({ dragId, newParentId, newIndex }) {
  try {
    const { renamed } = folderStore.moveFolder(dragId, newParentId, newIndex)
    if (renamed) {
      message.info(`目标位置存在同名目录，已自动重命名为"${folderStore.getFolderById(dragId).name}"`)
    }
  } catch (err) {
    if (err.message === 'cannot drop onto self or descendant') {
      message.warning('不能将目录拖拽到自身或其子孙目录下')
    } else {
      message.error(err.message || '拖拽失败')
    }
  }
}

function openCreateDocModal() {
  if (!currentFolderId.value) {
    message.warning('请先选择目录')
    return
  }
  createDocModalVisible.value = true
}
function closeCreateDocModal() {
  createDocModalVisible.value = false
}
function handleCreateDocument({ file, folderId, kbId: kId }) {
  // US3 阶段实现：调用 documentStore.createDocument
  try {
    documentStore.createDocument(
      {
        kbId: kId,
        folderId,
        name: file.name,
        size: file.size,
        mimeType: file.type
      },
      file
    )
    message.success('上传成功，正在解析...')
    closeCreateDocModal()
  } catch (err) {
    if (err.message.includes('524288000') || err.message.includes('limit')) {
      message.error('文件大小超过 500MB 限制')
    } else {
      message.error(err.message || '上传失败')
    }
  }
}

function openDocumentDetail(doc) {
  viewingDocument.value = doc
  detailDrawerVisible.value = true
}
function closeDocumentDetail() {
  detailDrawerVisible.value = false
  viewingDocument.value = null
}

function handleBatchDelete(ids) {
  Modal.confirm({
    title: '确认批量删除',
    content: `确定要删除选中的 ${ids.length} 篇文档吗？`,
    okText: '确认',
    cancelText: '取消',
    okButtonProps: { danger: true },
    onOk: () => {
      const { deleted } = documentStore.batchDeleteDocuments(ids)
      selectedRowKeys.value = []
      message.success(`已删除 ${deleted} 篇文档`)
    }
  })
}

function handleDeleteDocument(doc) {
  documentStore.deleteDocument(doc.id)
  message.success('文档已删除')
}

function openDocAction(doc) {
  docActionState.value = { visible: true, targetDocument: doc }
}
function closeDocAction() {
  docActionState.value.visible = false
}
function handleDocActionSubmit({ documentId, tags }) {
  try {
    for (const tag of tags) {
      documentStore.addTag(documentId, tag)
    }
    message.success('标签新增成功')
    closeDocAction()
  } catch (err) {
    message.error(err.message || '标签操作失败')
  }
}

function handleRemoveTag(doc, tag) {
  Modal.confirm({
    title: '确认删除标签',
    content: `确定要删除标签“${tag}”吗？`,
    okText: '删除',
    cancelText: '取消',
    okButtonProps: { danger: true },
    onOk: () => {
      try {
        const current = documentStore.getDocumentById(doc.id)
        if (!current) throw new Error('文档不存在')
        documentStore.updateTags(doc.id, current.tags.filter((value) => value !== tag))
        message.success('标签已删除')
      } catch (err) {
        message.error(err.message || '标签删除失败')
      }
    }
  })
}
</script>

<style scoped>
.knowledge-management {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.km-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f0f0f0;
}

.km-subtitle {
  font-size: 14px;
  color: #8c8c8c;
  font-weight: 400;
  margin-left: 8px;
}

.km-body {
  display: flex;
  gap: 16px;
  padding-top: 16px;
  flex: 1;
  min-height: 0;
}

.km-sidebar {
  width: 280px;
  flex-shrink: 0;
  background: #fafafa;
  border-radius: 8px;
  border: 1px solid #f0f0f0;
  overflow: hidden;
}

.km-main {
  flex: 1;
  min-width: 0;
  overflow: auto;
}
</style>
