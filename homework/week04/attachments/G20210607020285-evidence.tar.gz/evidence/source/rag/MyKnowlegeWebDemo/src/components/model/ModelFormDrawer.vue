<template>
  <a-drawer
    :title="`${model ? '设置' : '新建'}${categoryLabel}`"
    :open="visible"
    width="70vw"
    @close="handleClose"
  >
    <a-form
      ref="formRef"
      :model="formState"
      :rules="rules"
      layout="vertical"
      @finish="handleSubmit"
    >
      <a-form-item label="模型分类" name="category">
        <a-select v-model:value="formState.category" :options="categoryOptions" />
      </a-form-item>
      <a-form-item label="模型名称" name="name">
        <a-input v-model:value="formState.name" placeholder="请输入模型名称" />
      </a-form-item>
      <a-form-item label="模型显示名称" name="displayName">
        <a-input v-model:value="formState.displayName" placeholder="请输入模型显示名称" />
      </a-form-item>
      <a-form-item label="模型供应商" name="provider">
        <a-select v-model:value="formState.provider" :options="providerOptions" placeholder="请选择模型供应商" />
      </a-form-item>
      <a-form-item label="URL" name="url">
        <a-input v-model:value="formState.url" placeholder="请输入模型 URL" />
      </a-form-item>
      <a-form-item label="API Key" name="key">
        <a-input v-model:value="formState.key" placeholder="请输入 API Key" />
      </a-form-item>
      
      <a-divider>上下文设置</a-divider>

      <a-form-item label="上下文窗口（tokens）" name="maxToken">
        <a-input-number
          v-model:value="formState.maxToken"
          placeholder="请输入上下文窗口大小，例如 128000"
          style="width: 100%"
          :min="1"
          :max="Number.MAX_SAFE_INTEGER"
          :step="1"
        />
      </a-form-item>

      <a-divider>Rate Limit</a-divider>
      
      <a-form-item label="RPM (每分钟请求数)" name="rpm">
        <a-input-number 
          v-model:value="formState.rpm" 
          placeholder="请输入 RPM" 
          style="width: 100%"
          :min="0"
        />
      </a-form-item>
      
      <a-form-item label="TPM (每分钟 token 数)" name="tpm">
        <a-input-number 
          v-model:value="formState.tpm" 
          placeholder="请输入 TPM" 
          style="width: 100%"
          :min="0"
        />
      </a-form-item>
      
      <a-divider>价格设置 (每百万 tokens)</a-divider>
      
      <a-form-item label="输入 tokens (/tokens)" name="inputPerMillion">
        <a-input-number 
          v-model:value="formState.inputPerMillion" 
          placeholder="请输入每百万输入 tokens 价格" 
          style="width: 100%"
          :min="0"
          :step="0.01"
        />
      </a-form-item>
      
      <a-form-item label="输出 tokens (/tokens)" name="outputPerMillion">
        <a-input-number 
          v-model:value="formState.outputPerMillion" 
          placeholder="请输入每百万输出 tokens 价格" 
          style="width: 100%"
          :min="0"
          :step="0.01"
        />
      </a-form-item>
      
      <a-form-item label="缓存命中 tokens (/tokens)" name="cachedInputPerMillion">
        <a-input-number 
          v-model:value="formState.cachedInputPerMillion" 
          placeholder="请输入每百万缓存命中 tokens 价格" 
          style="width: 100%"
          :min="0"
          :step="0.01"
        />
      </a-form-item>
      <a-form-item>
        <a-space>
          <a-button type="primary" html-type="submit">确认</a-button>
          <a-button @click="handleClose">取消</a-button>
        </a-space>
      </a-form-item>
    </a-form>
  </a-drawer>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { MODEL_CATEGORIES, getModelCategory } from '../../utils/model.js'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  model: {
    type: Object,
    default: null
  },
  category: {
    type: String,
    default: 'chat'
  }
})

const emit = defineEmits(['close', 'submit'])

const formRef = ref(null)
const categoryOptions = MODEL_CATEGORIES.map(category => ({ value: category.value, label: category.formLabel }))
const providerOptions = [
  { value: 'Open AI', label: 'Open AI' },
  { value: 'Anthropic', label: 'Anthropic' }
]
const categoryLabel = computed(() => MODEL_CATEGORIES.find(category => category.value === formState.value.category)?.formLabel || '模型')
const formState = ref({ 
  category: 'chat',
  name: '',
  displayName: '',
  provider: 'Open AI',
  url: '',
  key: '',
  maxToken: null,
  rpm: null,
  tpm: null,
  inputPerMillion: null,
  outputPerMillion: null,
  cachedInputPerMillion: null
})

const rules = {
  category: [{ required: true, message: '请选择模型分类' }],
  name: [{ required: true, message: '请输入模型名称' }],
  displayName: [{ required: true, message: '请输入模型显示名称' }],
  provider: [{ required: true, message: '请选择模型供应商' }],
  maxToken: [{ type: 'integer', min: 1, max: Number.MAX_SAFE_INTEGER, message: '上下文窗口须为大于 0 的安全整数' }],
  url: [{ required: true, message: '请输入模型 URL' }],
  key: [{ required: true, message: '请输入 API Key' }]
}

watch(() => props.visible, (val) => {
  if (val && props.model) {
    formState.value = {
      category: getModelCategory(props.model),
      name: props.model.name,
      displayName: props.model.displayName || props.model.name,
      provider: props.model.provider || 'Open AI',
      url: props.model.url,
      key: props.model.key,
      maxToken: props.model.maxToken ?? null,
      rpm: props.model.rpm ?? null,
      tpm: props.model.tpm ?? null,
      inputPerMillion: props.model.inputPerMillion ?? null,
      outputPerMillion: props.model.outputPerMillion ?? null,
      cachedInputPerMillion: props.model.cachedInputPerMillion ?? null
    }
  } else if (val) {
    formState.value = {
      category: props.category,
      name: '',
      displayName: '',
      provider: 'Open AI',
      url: '',
      key: '',
      maxToken: null,
      rpm: null,
      tpm: null,
      inputPerMillion: null,
      outputPerMillion: null,
      cachedInputPerMillion: null
    }
  }
})

function handleSubmit() {
  emit('submit', { ...formState.value })
}

function handleClose() {
  emit('close')
  formRef.value?.resetFields()
}
</script>
