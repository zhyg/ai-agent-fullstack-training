import { reactive } from 'vue'
import { getItem, setItem, generateId } from '../composables/useStorage.js'
import { resolveConflictName, isDescendant } from '../utils/tree.js'

const FOLDERS_KEY = 'folders'

const state = reactive({
  folders: getItem(FOLDERS_KEY) || []
})

function persist() {
  setItem(FOLDERS_KEY, state.folders)
}

function getFoldersByKbId(kbId) {
  return state.folders.filter((f) => f.kbId === kbId)
}

function getFolderById(id) {
  return state.folders.find((f) => f.id === id) || null
}

/**
 * 新建目录（根目录或子目录）
 * @param {Object} data { kbId, parentId, name }
 */
function createFolder(data) {
  const { kbId, parentId, name } = data
  if (!kbId) throw new Error('kbId required')
  if (!name || !name.trim()) throw new Error('name required')
  if (parentId !== null && parentId !== undefined) {
    const parent = getFolderById(parentId)
    if (!parent) throw new Error('parent folder not found')
    if (parent.kbId !== kbId) throw new Error('parent folder belongs to different kb')
  }

  // 同级已有目录名列表
  const siblingNames = state.folders
    .filter((f) => f.kbId === kbId && (f.parentId ?? null) === (parentId ?? null))
    .map((f) => f.name)

  const finalName = resolveConflictName(siblingNames, name.trim())

  // 计算 order：同父级最大值 +1
  const siblings = state.folders.filter(
    (f) => f.kbId === kbId && (f.parentId ?? null) === (parentId ?? null)
  )
  const maxOrder = siblings.reduce((max, f) => Math.max(max, f.order ?? 0), -1)

  const now = Date.now()
  const folder = {
    id: generateId(),
    kbId,
    parentId: parentId ?? null,
    name: finalName,
    order: maxOrder + 1,
    createdAt: now,
    updatedAt: now
  }
  state.folders.push(folder)
  persist()
  return folder
}

/**
 * 重命名目录（同级冲突自动重命名）
 */
function renameFolder(id, newName) {
  const folder = getFolderById(id)
  if (!folder) throw new Error('folder not found')
  if (!newName || !newName.trim()) throw new Error('name required')

  const siblingNames = state.folders
    .filter(
      (f) =>
        f.kbId === folder.kbId &&
        (f.parentId ?? null) === (folder.parentId ?? null) &&
        f.id !== id
    )
    .map((f) => f.name)

  const finalName = resolveConflictName(siblingNames, newName.trim())
  folder.name = finalName
  folder.updatedAt = Date.now()
  persist()
  return folder
}

/**
 * 级联删除目录：递归删除其下所有子孙目录，并删除所有目录下文档
 * @param {string} id 目录 ID
 * @param {Function} onDocumentDelete 删除文档的回调（由外部注入 document store 的删除方法）
 */
function deleteFolder(id, onDocumentDelete) {
  const folder = getFolderById(id)
  if (!folder) return

  // 收集所有要删除的目录 id（含自身）
  const toDeleteIds = new Set([id])
  let changed = true
  while (changed) {
    changed = false
    for (const f of state.folders) {
      if (!toDeleteIds.has(f.id) && toDeleteIds.has(f.parentId)) {
        toDeleteIds.add(f.id)
        changed = true
      }
    }
  }

  // 删除这些目录下的所有文档
  if (typeof onDocumentDelete === 'function') {
    for (const folderId of toDeleteIds) {
      onDocumentDelete(folderId)
    }
  }

  // 删除目录
  state.folders = state.folders.filter((f) => !toDeleteIds.has(f.id))
  persist()
}

/**
 * 调整同级排序（简单实现：把目标 order 之后的同级顺序后移）
 */
function reorderFolder(id, newOrder) {
  const folder = getFolderById(id)
  if (!folder) return null
  const siblings = state.folders
    .filter(
      (f) => f.kbId === folder.kbId && (f.parentId ?? null) === (folder.parentId ?? null)
    )
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))

  // 重建 order
  const newSiblings = siblings.filter((f) => f.id !== id)
  newSiblings.splice(newOrder, 0, folder)
  newSiblings.forEach((f, index) => {
    f.order = index
  })
  folder.updatedAt = Date.now()
  persist()
  return folder
}

/**
 * 拖拽移动目录（支持跨父级）
 * @param {string} id 被拖拽目录 ID
 * @param {string|null} newParentId 新父目录 ID，null 表示成为根目录
 * @param {number} newIndex 在同级中的新位置索引
 * @param {Object} options { onRename?: (finalName) => void }
 * @returns {Object} { folder, renamed: boolean }
 */
function moveFolder(id, newParentId, newIndex, options = {}) {
  const folder = getFolderById(id)
  if (!folder) throw new Error('folder not found')

  // 禁止拖拽到自身或子孙目录
  if (newParentId !== null && newParentId !== undefined) {
    if (isDescendant(state.folders, id, newParentId)) {
      throw new Error('cannot drop onto self or descendant')
    }
    const parent = getFolderById(newParentId)
    if (!parent) throw new Error('new parent not found')
    if (parent.kbId !== folder.kbId) throw new Error('cross-kb move not allowed')
  }

  const finalParentId = newParentId ?? null

  // 冲突检测：目标父级下是否有同名目录
  const siblingNames = state.folders
    .filter(
      (f) => f.kbId === folder.kbId && (f.parentId ?? null) === finalParentId && f.id !== id
    )
    .map((f) => f.name)

  let renamed = false
  if (siblingNames.includes(folder.name)) {
    const finalName = resolveConflictName(siblingNames, folder.name)
    folder.name = finalName
    renamed = true
    if (typeof options.onRename === 'function') options.onRename(finalName)
  }

  // 从旧位置移除
  const oldParentId = folder.parentId ?? null
  folder.parentId = finalParentId
  folder.updatedAt = Date.now()

  // 重建目标同级的 order
  const targetSiblings = state.folders
    .filter(
      (f) => f.kbId === folder.kbId && (f.parentId ?? null) === finalParentId && f.id !== id
    )
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  targetSiblings.splice(newIndex, 0, folder)
  targetSiblings.forEach((f, index) => {
    f.order = index
  })

  // 重建原同级的 order
  if (oldParentId !== finalParentId) {
    const oldSiblings = state.folders
      .filter(
        (f) => f.kbId === folder.kbId && (f.parentId ?? null) === oldParentId && f.id !== id
      )
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
    oldSiblings.forEach((f, index) => {
      f.order = index
    })
  }

  persist()
  return { folder, renamed }
}

export function useFolderStore() {
  return {
    state,
    getFoldersByKbId,
    getFolderById,
    createFolder,
    renameFolder,
    deleteFolder,
    reorderFolder,
    moveFolder
  }
}
