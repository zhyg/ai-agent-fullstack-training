<template>
  <div>
    <PromptList 
      :prompts="promptStore.state.prompts"
      @create="openCreateModal"
      @edit="openEditDrawer"
      @delete="handleDelete"
    />

    <!-- 新建提示词对话框 -->
    <PromptCreateModal
      :visible="createModalVisible"
      @close="closeCreateModal"
      @submit="handleCreateSubmit"
    />

    <!-- 设置提示词抽屉 -->
    <PromptFormDrawer
      :visible="editDrawerVisible"
      :prompt="editingPrompt"
      @close="closeEditDrawer"
      @submit="handleEditSubmit"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Modal, message } from 'ant-design-vue'
import { usePromptStore } from '../stores/prompt.js'
import PromptList from '../components/prompt/PromptList.vue'
import PromptCreateModal from '../components/prompt/PromptCreateModal.vue'
import PromptFormDrawer from '../components/prompt/PromptFormDrawer.vue'

const promptStore = usePromptStore()

const createModalVisible = ref(false)
const editDrawerVisible = ref(false)
const editingPrompt = ref(null)

function openCreateModal() {
  createModalVisible.value = true
}

function closeCreateModal() {
  createModalVisible.value = false
}

function openEditDrawer(prompt) {
  editingPrompt.value = prompt
  editDrawerVisible.value = true
}

function closeEditDrawer() {
  editDrawerVisible.value = false
  editingPrompt.value = null
}

function handleCreateSubmit(data) {
  promptStore.createPrompt(data)
  closeCreateModal()
  message.success('提示词创建成功')
}

function handleEditSubmit(data) {
  if (editingPrompt.value) {
    promptStore.updatePrompt(editingPrompt.value.id, data)
    closeEditDrawer()
    message.success('提示词更新成功')
  }
}

function handleDelete(prompt) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除提示词 "${prompt.name}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    onOk() {
      promptStore.deletePrompt(prompt.id)
      message.success('提示词删除成功')
    }
  })
}
</script>


