export const MODEL_CATEGORIES = [
  { value: 'chat', label: '对话', formLabel: '对话模型' },
  { value: 'embedding', label: 'Embedding', formLabel: 'Embedding 模型' },
  { value: 'rerank', label: 'ReRank', formLabel: 'ReRank 模型' },
  { value: 'vision', label: '视觉', formLabel: '视觉模型' },
  { value: 'speech', label: '语音', formLabel: '语音模型' }
]

// 旧模型没有分类，统一视为对话模型，保留原有配置和引用。
export function getModelCategory(model) {
  return model.category ?? 'chat'
}

export function formatContextWindow(value) {
  if (!value) return ''
  if (value >= 1000000) return `${Number((value / 1000000).toFixed(2))}M`
  if (value >= 1000) return `${Number((value / 1000).toFixed(2))}K`
  return String(value)
}
