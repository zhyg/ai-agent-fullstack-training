<template>
  <div>
    <KbList
      :knowledgeBases="kbStore.state.knowledgeBases"
      :models="modelStore.state.models"
      @create="openCreateModal"
      @enter="handleEnter"
      @edit="openEditDrawer"
      @delete="handleDelete"
    />
    <KbCreateModal
      :visible="createModalVisible"
      :models="modelStore.state.models"
      @close="closeCreateModal"
      @submit="handleCreateSubmit"
    />
    <KbFormDrawer
      :visible="drawerVisible"
      :kb="editingKb"
      :models="modelStore.state.models"
      @close="closeDrawer"
      @submit="handleEditSubmit"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { Modal, message } from 'ant-design-vue'
import { useKbStore } from '../stores/knowledgeBase.js'
import { useModelStore } from '../stores/model.js'
import KbList from '../components/knowledge-base/KbList.vue'
import KbCreateModal from '../components/knowledge-base/KbCreateModal.vue'
import KbFormDrawer from '../components/knowledge-base/KbFormDrawer.vue'

const kbStore = useKbStore()
const modelStore = useModelStore()
const router = useRouter()

const createModalVisible = ref(false)
const drawerVisible = ref(false)
const editingKb = ref(null)

function openCreateModal() {
  createModalVisible.value = true
}

function closeCreateModal() {
  createModalVisible.value = false
}

function openEditDrawer(kb) {
  editingKb.value = kb
  drawerVisible.value = true
}

function closeDrawer() {
  drawerVisible.value = false
  editingKb.value = null
}

function handleCreateSubmit(data) {
  kbStore.createKb(data)
  message.success('知识库创建成功')
  closeCreateModal()
}

function handleEditSubmit(data) {
  kbStore.updateKb(editingKb.value.id, data)
  message.success('知识库更新成功')
  closeDrawer()
}

function handleEnter(kb) {
  router.push({ name: 'KnowledgeManagement', params: { kbId: kb.id } })
}

function handleDelete(kb) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除知识库 "${kb.name}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    onOk() {
      kbStore.deleteKb(kb.id)
      message.success('知识库删除成功')
    }
  })
}
</script>
