<template>
  <div class="folder-tree">
    <div class="folder-tree-header">
      <span class="folder-tree-title">目录</span>
      <a-button type="text" size="small" @click="$emit('create-root')">
        <template #icon><PlusOutlined /></template>
        新建根目录
      </a-button>
    </div>

    <a-empty
      v-if="treeData.length === 0"
      description="暂无目录，点击上方按钮新建根目录"
      :image-style="{ height: '60px' }"
      style="padding: 24px 0"
    />

    <a-tree
      v-else
      :tree-data="treeData"
      :selected-keys="selectedKeys"
      :draggable="true"
      :allow-drop="allowDrop"
      block-node
      @select="handleSelect"
      @drop="handleDrop"
    >
      <template #title="{ key, title, raw }">
        <div class="tree-node">
          <span class="tree-node-title">{{ title }}</span>
          <a-dropdown :trigger="['click']" @click.stop>
            <a-button
              class="tree-node-more"
              type="text"
              size="small"
              @click.stop
            >
              <template #icon><MoreOutlined /></template>
            </a-button>
            <template #overlay>
              <a-menu @click="(info) => handleMenuClick(info, raw)">
                <a-menu-item key="create-child">新建目录</a-menu-item>
                <a-menu-item key="rename">修改目录名称</a-menu-item>
                <a-menu-item key="delete" danger>删除目录</a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
        </div>
      </template>
    </a-tree>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { PlusOutlined, MoreOutlined } from '@ant-design/icons-vue'
import { buildTree, isDescendant } from '../../utils/tree.js'
import { useFolderStore } from '../../stores/folder.js'

const props = defineProps({
  kbId: {
    type: String,
    required: true
  },
  selectedFolderId: {
    type: String,
    default: null
  }
})

const emit = defineEmits([
  'select',
  'create-root',
  'create-child',
  'rename',
  'delete',
  'drop'
])

const folderStore = useFolderStore()

const treeData = computed(() => {
  return buildTree(folderStore.state.folders, props.kbId)
})

const selectedKeys = computed(() => {
  return props.selectedFolderId ? [props.selectedFolderId] : []
})

function handleSelect(keys, info) {
  const key = keys[0] ?? null
  const folder = key ? folderStore.getFolderById(key) : null
  emit('select', folder)
}

function allowDrop({ dropNode, dragNode }) {
  // 禁止拖拽到自身或子孙目录
  if (isDescendant(folderStore.state.folders, dragNode.key, dropNode.key)) {
    return false
  }
  return true
}

function handleDrop(info) {
  const dragId = info.dragNode.key
  const dropId = info.node.key
  const dropPosition = info.dropPosition
  const dropToGap = info.dropToGap

  // 计算新的 parentId 与 newIndex
  let newParentId
  let siblingList
  if (dropToGap) {
    // 放入间隙：与 dropNode 同父级
    const dropFolder = folderStore.getFolderById(dropId)
    newParentId = dropFolder?.parentId ?? null
    siblingList = folderStore.state.folders
      .filter(
        (f) =>
          f.kbId === props.kbId &&
          (f.parentId ?? null) === newParentId &&
          f.id !== dragId
      )
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  } else {
    // 放入目标节点内部
    newParentId = dropId
    siblingList = folderStore.state.folders
      .filter(
        (f) =>
          f.kbId === props.kbId &&
          (f.parentId ?? null) === newParentId &&
          f.id !== dragId
      )
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  }

  let newIndex
  if (dropToGap) {
    const dropIdx = siblingList.findIndex((f) => f.id === dropId)
    // dropPosition: -1 表示 dropNode 上方，1 表示下方
    newIndex = dropPosition < 0 ? dropIdx : dropIdx + 1
  } else {
    newIndex = siblingList.length
  }

  emit('drop', { dragId, newParentId, newIndex })
}

function handleMenuClick(info, folder) {
  const type = info.key
  if (type === 'create-child') emit('create-child', folder)
  else if (type === 'rename') emit('rename', folder)
  else if (type === 'delete') emit('delete', folder)
}
</script>

<style scoped>
.folder-tree {
  height: 100%;
  overflow: auto;
  padding: 8px 0;
}

.folder-tree-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 16px 12px;
  border-bottom: 1px solid #f0f0f0;
  margin-bottom: 8px;
}

.folder-tree-title {
  font-size: 14px;
  font-weight: 600;
  color: #1f1f1f;
}

.tree-node {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding-right: 4px;
}

.tree-node-title {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.tree-node-more {
  opacity: 0;
  transition: opacity 0.2s;
  padding: 0 4px;
}

.tree-node:hover .tree-node-more {
  opacity: 1;
}

:deep(.ant-tree-node-content-wrapper) {
  display: flex;
  align-items: center;
}

:deep(.ant-tree-title) {
  flex: 1;
}
</style>
