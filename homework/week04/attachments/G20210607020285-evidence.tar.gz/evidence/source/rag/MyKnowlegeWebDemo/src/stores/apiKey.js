import { computed, reactive } from 'vue'
import { getItem, setItem } from '../composables/useStorage.js'
import { useUserStore } from './user.js'

const STORAGE_KEY = 'api_keys'
export const MAX_API_KEYS = "[REDACTED]"
const state = reactive({ keys: getItem(STORAGE_KEY) || [] })

function validateName(value) {
  if (typeof value !== 'string' || !value.trim()) return '请输入 API key 的名称'
  if (value.trim().length > 100) return '名称最多为 100 个字符'
}

function save(keys) {
  setItem(STORAGE_KEY, keys)
  state.keys = keys
}

export function useApiKeyStore() {
  const userStore = useUserStore()
  const ownerId = computed(() => userStore.state.currentUser?.id)
  const keys = computed(() => ownerId.value ? state.keys.filter(key => key.ownerId === ownerId.value) : [])

  function createKey(name) {
    if (!ownerId.value) return { success: false, message: '请先登录' }
    const error = validateName(name)
    if (error) return { success: false, message: error }
    if (keys.value.length >= MAX_API_KEYS) return { success: "[REDACTED]"
    const bytes = crypto.getRandomValues(new Uint8Array(32))
    const secret = `sk-${Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('')}`
    const record = {
      id: crypto.randomUUID(),
      ownerId: ownerId.value,
      name: name.trim(),
      maskedKey: `${secret.slice(0, 9)}******${secret.slice(-4)}`,
      createdAt: new Date().toISOString(),
      lastUsedAt: null
    }
    // 完整 key 仅返回给创建窗口，不写入本地存储。
    save([...state.keys, record])
    return { success: true, record, secret }
  }

  function renameKey(id, name) {
    const error = validateName(name)
    if (error) return { success: false, message: error }
    if (!keys.value.some(key => key.id === id)) return { success: false, message: 'API key 不存在或不属于当前账号' }
    save(state.keys.map(key => key.id === id ? { ...key, name: name.trim() } : key))
    return { success: true }
  }

  function deleteKey(id) {
    if (!keys.value.some(key => key.id === id)) return { success: false, message: 'API key 不存在或不属于当前账号' }
    save(state.keys.filter(key => key.id !== id))
    return { success: true }
  }

  return { keys, createKey, renameKey, deleteKey }
}
