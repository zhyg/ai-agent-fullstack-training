<template>
  <a-modal
    :open="visible"
    :title="modalTitle"
    ok-text="确认"
    cancel-text="取消"
    @ok="handleSubmit"
    @cancel="$emit('close')"
  >
    <a-form
      v-if="type !== 'delete'"
      :model="formState"
      :label-col="{ span: 5 }"
    >
      <a-form-item label="目录名称" name="name" :rules="[{ required: true, message: '请输入目录名称' }]">
        <a-input v-model:value="formState.name" placeholder="请输入目录名称" />
      </a-form-item>
    </a-form>
    <div v-else>
      确定要删除目录 <strong>{{ folder?.name }}</strong> 及其所有子目录与文档吗？
    </div>
  </a-modal>
</template>

<script setup>
import { reactive, computed, watch } from 'vue'

const props = defineProps({
  visible: { type: Boolean, required: true },
  type: { type: String, required: true },
  folder: { type: Object, default: null },
  kbId: { type: String, required: true }
})

const emit = defineEmits(['close', 'submit'])

const formState = reactive({ name: '' })

const modalTitle = computed(() => {
  if (props.type === 'create-root') return '新建根目录'
  if (props.type === 'create-child') return '新建子目录'
  if (props.type === 'rename') return '修改目录名称'
  if (props.type === 'delete') return '确认删除'
  return '目录操作'
})

watch(
  () => props.visible,
  (val) => {
    if (val) {
      if (props.type === 'rename' && props.folder) {
        formState.name = props.folder.name
      } else {
        formState.name = ''
      }
    }
  }
)

function handleSubmit() {
  if (props.type === 'delete') {
    emit('submit', { id: props.folder?.id })
    return
  }
  if (!formState.name || !formState.name.trim()) return
  if (props.type === 'create-root') {
    emit('submit', { name: formState.name.trim() })
  } else if (props.type === 'create-child') {
    emit('submit', { parentId: props.folder?.id, name: formState.name.trim() })
  } else if (props.type === 'rename') {
    emit('submit', { id: props.folder?.id, name: formState.name.trim() })
  }
}
</script>
