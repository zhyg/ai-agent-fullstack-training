# Data Model: 知识库中知识的管理

**Feature**: 002-knowledge-doc-management
**Date**: 2026-10-24

## 实体定义

### Folder（目录）

知识库内的组织单元，支持无限层级嵌套。采用扁平化存储（每个目录记录包含 `parentId`），渲染时递归生成嵌套树结构。

| 字段 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String | 是 | 唯一标识，`generateId()` 生成 |
| kbId | String | 是 | 所属知识库 ID（关联 KnowledgeBase.id） |
| parentId | String \| null | 是 | 父目录 ID，根目录为 `null` |
| name | String | 是 | 目录名称 |
| order | Number | 是 | 同级目录排序权重，数字小者靠前 |
| createdAt | Number | 是 | 创建时间戳（Date.now()） |
| updatedAt | Number | 是 | 更新时间戳（Date.now()） |

**验证规则**:
- `name`: 非空字符串
- `kbId`: 非空，必须是已存在的知识库 ID
- `parentId`: 允许 null（表示根目录），否则必须是同知识库下的目录 ID
- `order`: 非负整数

**关系**:
- 一个知识库下可以有多个根目录（一对多）
- 一个目录下可以有多个子目录（一对多，自引用）
- 一个目录下可以有多个文档（一对多，见 Document）
- 删除目录时级联删除其下所有子目录与文档

**特殊约束**:
- 拖拽时禁止将目录放置到自身或其子孙目录下（由 store 的 `moveFolder` 方法保证）
- 拖拽到同名目录时，自动重命名为"原名(1)"并递增（由 store 处理）

### Document（文档）

知识库中的知识载体，挂载在某个目录下。元数据存于 localStorage，文件 Blob 与解析内容存于 IndexedDB。

| 字段 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String | 是 | 唯一标识，`generateId()` 生成 |
| kbId | String | 是 | 所属知识库 ID |
| folderId | String | 是 | 所属目录 ID |
| name | String | 是 | 文档名称（含扩展名） |
| description | String | 否 | 文档描述（解析时由系统从文件首段/元数据自动提取） |
| tags | String[] | 是 | 标签数组（默认 `[]`） |
| size | Number | 是 | 文件大小（字节） |
| mimeType | String | 否 | 文件 MIME 类型 |
| extension | String | 是 | 文件扩展名（小写，如 `pdf`、`md`） |
| status | String | 是 | 解析状态：`parsing` / `success` / `failed` |
| errorMessage | String | 否 | 解析失败时的错误信息 |
| createdAt | Number | 是 | 创建时间戳（Date.now()） |
| updatedAt | Number | 是 | 更新时间戳（Date.now()） |

**验证规则**:
- `name`: 非空字符串
- `kbId`: 非空，必须是已存在的知识库 ID
- `folderId`: 非空，必须是已存在的目录 ID
- `size`: 非负整数，且 ≤ 524288000（500MB）
- `status`: 枚举值 `parsing` / `success` / `failed`
- `tags`: 字符串数组，单文档内标签去重

**关系**:
- 一个文档属于一个目录（多对一）
- 一个文档属于一个知识库（多对一）
- 删除文档时同步删除 localStorage 元数据 + IndexedDB 中的文件 Blob 与解析内容

**状态机**:

```
[上传提交] → parsing
    ├─(模拟 2~5s, 80% 概率)→ success
    └─(模拟 2~5s, 20% 概率)→ failed

约束：status=parsing 时禁止删除（拒绝并以 Toast 提示）
```

## 存储结构

### localStorage Key 设计

| Key | 值类型 | 说明 |
| --- | ------ | ---- |
| `kb_folders` | JSON Array | 所有目录的扁平数组 |
| `kb_documents` | JSON Array | 所有文档的元数据数组 |

> 延续 001 号特性的前缀规范（`kb_`），新增 2 个 Key。

### IndexedDB 设计

**数据库名**: `kb_files_db`
**版本**: 1
**Object Stores**:

| Store 名 | Key 类型 | 值类型 | 说明 |
| -------- | -------- | ------ | ---- |
| `files` | String（documentId） | Blob | 文档原始文件 |
| `parsed_contents` | String（documentId） | String | 解析后的文本内容 |

> IndexedDB 操作通过 `useStorage.js` 扩展出的 `saveBlob` / `getBlob` / `deleteBlob` / `saveText` / `getText` / `deleteText` 方法封装。

### 数据存储示例

**Folders**:
```json
[
  {
    "id": "m1abc123",
    "kbId": "kb001",
    "parentId": null,
    "name": "产品文档",
    "order": 0,
    "createdAt": 1698048000000,
    "updatedAt": 1698048000000
  },
  {
    "id": "m2def456",
    "kbId": "kb001",
    "parentId": "m1abc123",
    "name": "PRD",
    "order": 0,
    "createdAt": 1698048000000,
    "updatedAt": 1698048000000
  }
]
```

**Documents**:
```json
[
  {
    "id": "d1xyz789",
    "kbId": "kb001",
    "folderId": "m2def456",
    "name": "需求规格书.pdf",
    "description": "2026 年 Q1 产品需求规格说明文档",
    "tags": ["PRD", "Q1"],
    "size": 1258291,
    "mimeType": "application/pdf",
    "extension": "pdf",
    "status": "success",
    "errorMessage": null,
    "createdAt": 1698048000000,
    "updatedAt": 1698048000000
  }
]
```

## 数据操作封装

### useFolderStore（stores/folder.js）

| 方法 | 参数 | 返回值 | 说明 |
| ---- | ---- | ------ | ---- |
| `getFoldersByKbId(kbId)` | `kbId: String` | `Folder[]` | 获取某知识库下所有目录（扁平） |
| `getFolderTree(kbId)` | `kbId: String` | `TreeNode[]` | 构建 a-tree 需要的嵌套树 |
| `getFolderById(id)` | `id: String` | `Folder \| null` | 按 ID 获取目录 |
| `createFolder(data)` | `data: {kbId, parentId, name}` | `Folder` | 新建目录（自动处理 order） |
| `renameFolder(id, newName)` | `id: String, newName: String` | `Folder` | 重命名目录 |
| `deleteFolder(id)` | `id: String` | `void` | 级联删除目录及其子目录与文档 |
| `moveFolder(id, newParentId, newIndex)` | `id, newParentId, newIndex: Number` | `Folder` | 拖拽移动目录（含同级重命名冲突处理） |
| `reorderFolder(id, newOrder)` | `id: String, newOrder: Number` | `Folder` | 调整同级排序 |

### useDocumentStore（stores/document.js）

| 方法 | 参数 | 返回值 | 说明 |
| ---- | ---- | ------ | ---- |
| `getDocumentsByFolderId(folderId)` | `folderId: String` | `Document[]` | 获取某目录下的文档列表 |
| `getDocumentsByKbId(kbId)` | `kbId: String` | `Document[]` | 获取某知识库下所有文档 |
| `getDocumentById(id)` | `id: String` | `Document \| null` | 按 ID 获取文档元数据 |
| `createDocument(meta, fileBlob)` | `meta: Partial<Document>, fileBlob: Blob` | `Document` | 新建文档元数据 + 存入 Blob + 触发状态模拟 |
| `deleteDocument(id)` | `id: String` | `void` | 删除文档（元数据 + IndexedDB 内容）；status=parsing 时拒绝 |
| `batchDeleteDocuments(ids)` | `ids: String[]` | `void` | 批量删除（过滤掉 status=parsing 的文档） |
| `addTag(id, tag)` | `id: String, tag: String` | `Document` | 新增标签（去重） |
| `updateTags(id, tags)` | `id: String, tags: String[]` | `Document` | 覆盖更新标签 |
| `getFileBlob(id)` | `id: String` | `Promise<Blob \| null>` | 从 IndexedDB 读取文件 Blob |
| `getParsedContent(id)` | `id: String` | `Promise<String \| null>` | 从 IndexedDB 读取解析后文本 |

## 状态转换汇总

- **Folder**: 创建 → 可重命名 / 可移动 / 可排序 → 可删除（级联）
- **Document**:
  - `parsing` → `success` / `failed`（由模拟定时器驱动）
  - `parsing` 状态下禁止删除
  - `success` / `failed` 状态下可删除

## 辅助工具

### buildTree 算法（utils/tree.js）

```
输入：flatFolders[], kbId
输出：TreeNode[] (a-tree 格式)

流程：
1. 过滤出 kbId 匹配的目录
2. 按 parentId 分组为 Map<parentId, Folder[]>
3. 按 order 升序排序每个分组
4. 递归构建树节点：
   TreeNode = { key: id, title: name, children: buildTree(parentId=id) }
```

### 冲突重命名算法

```
输入：targetParentId, desiredName, excludeId?
输出：finalName

流程：
1. 获取 targetParentId 下所有子目录名
2. 若 desiredName 不存在 → 直接返回
3. 否则从 desiredName 中解析 base 与 (N) 后缀
4. 循环 base(1), base(2), ... 直到找到可用名
5. 返回可用名
```
