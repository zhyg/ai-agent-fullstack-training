<template>
  <section class="permission-management" aria-label="权限管理">
    <a-tabs :activeKey="activeTab" @change="changeTab">
      <a-tab-pane key="users" tab="用户" />
      <a-tab-pane key="roles" tab="角色" />
      <a-tab-pane key="menus" tab="菜单权限" disabled />
      <a-tab-pane key="buttons" tab="按钮权限" disabled />
    </a-tabs>

    <div class="permission-toolbar">
      <a-input-search
        v-model:value="searchInput"
        :placeholder="isUsers ? '可输入用户名或邮箱进行搜索' : '可输入角色名或描述进行搜索'"
        :aria-label="isUsers ? '搜索用户' : '搜索角色'"
        allow-clear
        enter-button
        @search="search"
        @change="clearSearch"
      />
      <a-button type="primary" @click="openCreate">新增</a-button>
    </div>

    <a-table
      :columns="isUsers ? userColumns : roleColumns"
      :data-source="filteredRecords"
      row-key="id"
      :pagination="pagination"
      :scroll="{ x: isUsers ? 1000 : 850 }"
      :locale="{ emptyText: keyword ? '没有匹配的结果' : isUsers ? '暂无用户，请新增用户' : '暂无角色，请新增角色' }"
      @change="changePagination"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'roles'">
          <a-space :size="[4, 4]" wrap>
            <a-tag v-for="roleId in userStore.getUserRoleIds(record)" :key="roleId" color="orange">
              {{ roleName(roleId) }}
            </a-tag>
            <span v-if="!userStore.getUserRoleIds(record).length" class="muted">未分配</span>
          </a-space>
        </template>
        <template v-else-if="column.key === 'createdAt'">
          {{ formatTime(record.createdAt) }}
        </template>
        <template v-else-if="column.key === 'updatedAt'">
          {{ formatTime(record.updatedAt || record.createdAt) }}
        </template>
        <template v-else-if="column.key === 'actions'">
          <a-space :size="4">
            <a-button type="text" :aria-label="`编辑${isUsers ? '用户' : '角色'} ${isUsers ? record.username : record.name}`" title="编辑" @click="openEdit(record)">
              <template #icon><EditOutlined /></template>
            </a-button>
            <a-tooltip v-if="!isUsers" :title="isRoleAssigned(record.id) ? '该角色已分配给用户，请先解除关联' : '删除角色'">
              <span>
                <a-button type="text" :aria-label="`删除角色 ${record.name}`" :disabled="isRoleAssigned(record.id)" @click="confirmDelete(record)">
                  <template #icon><DeleteOutlined /></template>
                </a-button>
              </span>
            </a-tooltip>
          </a-space>
        </template>
      </template>
    </a-table>

    <a-modal
      :open="editorOpen"
      :title="`${editingId ? '编辑' : '新增'}${isUsers ? '用户' : '角色'}`"
      :footer="null"
      :width="520"
      @cancel="closeEditor"
    >
      <a-form
        v-if="editorOpen"
        :key="`${activeTab}-${editingId || 'new'}`"
        :model="form"
        :rules="isUsers ? userRules : roleRules"
        layout="vertical"
        class="permission-form"
        @finish="submit"
      >
        <template v-if="isUsers">
          <a-form-item label="账号" name="username">
            <a-input v-model:value="form.username" placeholder="请输入账号" :maxlength="20" />
          </a-form-item>
          <a-form-item label="邮箱" name="email">
            <a-input v-model:value="form.email" placeholder="请输入邮箱" />
          </a-form-item>
          <a-form-item v-if="!editingId" label="初始密码" name="password">
            <a-input-password v-model:value="form.password" placeholder="[REDACTED]"
          </a-form-item>
          <a-form-item label="角色" name="roleIds">
            <a-select
              v-model:value="form.roleIds"
              mode="multiple"
              placeholder="请选择角色，可多选"
              :options="roleOptions"
              :not-found-content="'暂无角色，请先在角色页新增'"
              :max-tag-count="'responsive'"
              allow-clear
              option-filter-prop="label"
            />
          </a-form-item>
        </template>
        <template v-else>
          <a-form-item label="角色名" name="name">
            <a-input v-model:value="form.name" placeholder="请输入角色名" :maxlength="50" />
          </a-form-item>
          <a-form-item label="描述" name="description">
            <a-textarea v-model:value="form.description" placeholder="请输入角色描述" :rows="3" :maxlength="200" show-count />
          </a-form-item>
        </template>
        <div class="form-actions">
          <a-button @click="closeEditor">取消</a-button>
          <a-button type="primary" html-type="submit">保存</a-button>
        </div>
      </a-form>
    </a-modal>
  </section>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { useUserStore } from '../stores/user.js'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
onMounted(() => {
  try {
    userStore.initializeRoles()
  } catch (error) {
    console.error('基础角色初始化失败', error)
    message.error('基础角色保存失败，请检查浏览器存储空间和访问权限后重试')
  }
})
const activeTab = computed(() => route.name === 'PermissionRoles' ? 'roles' : 'users')
const isUsers = computed(() => activeTab.value === 'users')
const searchInput = ref('')
const keyword = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const editorOpen = ref(false)
const editingId = ref(null)
const form = reactive({ username: '', email: '', password: "[REDACTED]"
const roleOptions = computed(() => userStore.state.roles.map(role => ({ label: role.name, value: role.id })))
const records = computed(() => isUsers.value ? userStore.state.users : userStore.state.roles)
const filteredRecords = computed(() => records.value.filter(record => {
  const values = isUsers.value ? [record.username, record.email] : [record.name, record.description]
  return values.some(value => (value || '').toLowerCase().includes(keyword.value))
}))
const pagination = computed(() => ({
  current: currentPage.value,
  pageSize: pageSize.value,
  total: filteredRecords.value.length,
  showSizeChanger: true,
  pageSizeOptions: ['10', '20', '50'],
  showTotal: total => `共 ${total} 条`
}))

const timeColumns = [
  { title: '创建时间', key: 'createdAt', width: 200, align: 'center' },
  { title: '修改时间', key: 'updatedAt', width: 200, align: 'center' },
  { title: '操作', key: 'actions', width: 120, align: 'center' }
]
const userColumns = [
  { title: '账号', dataIndex: 'username', width: 160, align: 'center' },
  { title: '邮箱', dataIndex: 'email', width: 260, align: 'center' },
  { title: '角色', key: 'roles', width: 220, align: 'center' },
  ...timeColumns
]
const roleColumns = [
  { title: '角色名', dataIndex: 'name', width: 200, align: 'center' },
  { title: '描述', dataIndex: 'description', width: 260, align: 'center' },
  ...timeColumns
]
const userRules = {
  username: [
    { required: true, whitespace: true, message: '请输入账号' },
    { min: 3, max: 20, message: '账号长度应为3至20个字符' }
  ],
  email: [
    { required: true, message: '请输入邮箱' },
    { type: 'email', message: '请输入有效的邮箱地址' }
  ],
  password: "[REDACTED]"
    { required: true, message: '请输入初始密码' },
    { min: 6, message: '密码至少6个字符' }
  ]
}
const roleRules = {
  name: [{ required: true, whitespace: true, message: '请输入角色名' }, { max: 50, message: '角色名最多50个字符' }],
  description: [{ max: 200, message: '角色描述最多200个字符' }]
}

function changeTab(tab) {
  router.push(tab === 'roles' ? '/permissions/roles' : '/permissions/users')
}

function search() {
  keyword.value = searchInput.value.trim().toLowerCase()
  currentPage.value = 1
}

function clearSearch(event) {
  if (!event.target.value) search()
}

function changePagination(value) {
  currentPage.value = value.current
  pageSize.value = value.pageSize
}

function formatTime(value) {
  if (!value) return '—'
  return new Date(value).toLocaleString('zh-CN', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).replaceAll('/', '-')
}

function roleName(id) {
  return userStore.state.roles.find(role => role.id === id)?.name || '角色已删除'
}

function isRoleAssigned(id) {
  return userStore.state.users.some(user => userStore.getUserRoleIds(user).includes(id))
}

function openCreate() {
  editingId.value = null
  Object.assign(form, { username: '', email: '', password: "[REDACTED]"
  editorOpen.value = true
}

function openEdit(record) {
  editingId.value = record.id
  Object.assign(form, {
    username: record.username || '',
    email: record.email || '',
    password: "[REDACTED]"
    roleIds: isUsers.value ? [...userStore.getUserRoleIds(record)] : [],
    name: record.name || '',
    description: record.description || ''
  })
  editorOpen.value = true
}

function closeEditor() {
  editorOpen.value = false
  form.password = "[REDACTED]"
}

function runMutation(action) {
  try {
    const result = action()
    if (!result.success) {
      message.error(result.message)
      return false
    }
    message.success(result.message)
    return true
  } catch (error) {
    console.error('权限管理保存失败', error)
    message.error('保存失败，请检查浏览器存储空间和访问权限后重试')
    return false
  }
}

function submit() {
  const saved = runMutation(() => {
    if (!isUsers.value) return userStore.saveRole(editingId.value, form)
    return editingId.value ? userStore.updateUser(editingId.value, form) : userStore.createUser(form)
  })
  if (saved) {
    closeEditor()
    currentPage.value = Math.min(currentPage.value, Math.max(1, Math.ceil(filteredRecords.value.length / pageSize.value)))
  }
}

function confirmDelete(role) {
  Modal.confirm({
    title: '确认删除角色',
    content: `确定要删除角色“${role.name}”吗？删除后不可恢复。`,
    okText: '删除',
    okType: 'danger',
    cancelText: '取消',
    onOk() {
      if (!runMutation(() => userStore.deleteRole(role.id))) return Promise.reject(new Error('角色删除失败'))
      currentPage.value = Math.min(currentPage.value, Math.max(1, Math.ceil(filteredRecords.value.length / pageSize.value)))
    }
  })
}
</script>

<style scoped>
.permission-management {
  min-height: calc(100vh - 72px);
  background: #fff;
}

.permission-management :deep(.ant-tabs-nav) {
  margin-bottom: 12px;
  padding: 0 16px;
  background: #fafbfc;
}

.permission-management :deep(.ant-tabs-tab) {
  padding: 14px 8px;
}

.permission-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
  padding: 0 16px 12px;
}

.permission-toolbar :deep(.ant-input-search) {
  width: min(50%, 760px);
}

.permission-management :deep(.ant-table-thead > tr > th) {
  background: #fafafa;
  font-weight: 500;
}

.permission-management :deep(.ant-table-tbody > tr > td) {
  padding: 18px 16px;
  border-bottom-color: #f3f4f6;
  overflow-wrap: anywhere;
}

.permission-management :deep(.ant-tag) {
  margin-inline-end: 0;
}

.permission-management :deep(.ant-table-pagination) {
  padding: 0 16px;
}

.permission-form {
  padding-top: 20px;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 28px;
}

.muted {
  color: #8c8c8c;
}

@media (max-width: 600px) {
  .permission-toolbar :deep(.ant-input-search) {
    width: 100%;
  }
}
</style>
