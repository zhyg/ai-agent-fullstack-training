<template>
  <a-drawer
    :open="visible"
    :title="document?.name || '文档详情'"
    width="70vw"
    :destroy-on-close="true"
    @close="$emit('close')"
  >
    <template v-if="document">
      <a-descriptions :column="2" bordered size="small">
        <a-descriptions-item label="名称" :span="2">
          {{ document.name }}
        </a-descriptions-item>
        <a-descriptions-item label="描述" :span="2">
          {{ document.description || '—' }}
        </a-descriptions-item>
        <a-descriptions-item label="标签" :span="2">
          <a-tag
            v-for="tag in document.tags"
            :key="tag"
            color="blue"
            closable
            style="margin-right: 4px"
            @close.prevent.stop="$emit('remove-tag', document, tag)"
          >
            {{ tag }}
          </a-tag>
          <span v-if="document.tags.length === 0">—</span>
          <a-button
            type="link"
            size="small"
            @click="$emit('add-tag', document)"
          >
            新增
          </a-button>
        </a-descriptions-item>
        <a-descriptions-item label="大小">
          {{ formatFileSize(document.size) }}
        </a-descriptions-item>
        <a-descriptions-item label="状态">
          <a-tag :color="statusColor(document.status)">
            {{ statusText(document.status) }}
          </a-tag>
        </a-descriptions-item>
        <a-descriptions-item label="创建时间">
          {{ formatDate(document.createdAt) }}
        </a-descriptions-item>
        <a-descriptions-item label="更新时间">
          {{ formatDate(document.updatedAt) }}
        </a-descriptions-item>
      </a-descriptions>

      <a-divider class="content-divider">文档内容</a-divider>

      <a-tabs v-model:activeKey="activeContentTab" class="content-tabs">
        <a-tab-pane key="original">
          <template #tab>
            <span>原始内容</span>
            <span class="tab-caption">SOURCE</span>
          </template>
          <div class="doc-content">
            <template v-if="contentLoading">
              <div class="content-state"><a-spin tip="正在读取原文件..." /></div>
            </template>
            <template v-else-if="contentError">
              <a-alert :message="contentError" type="error" show-icon />
            </template>
            <template v-else-if="rendererType === 'markdown'">
              <MdPreview
                :modelValue="originalContent || ''"
                style="background: transparent"
              />
            </template>
            <template v-else-if="rendererType === 'office-docx' && fileArrayBuffer">
              <VueOfficeDocx :src="fileArrayBuffer" @rendered="onRendered" />
            </template>
            <template v-else-if="rendererType === 'office-excel' && fileArrayBuffer">
              <VueOfficeExcel
                class="excel-viewer"
                :src="fileArrayBuffer"
                @rendered="onRendered"
              />
            </template>
            <template v-else-if="rendererType === 'office-pptx' && fileArrayBuffer">
              <VueOfficePptx :src="fileArrayBuffer" @rendered="onRendered" />
            </template>
            <template v-else-if="rendererType === 'office-pdf' && fileArrayBuffer">
              <VueOfficePdf
                class="pdf-viewer"
                :src="fileArrayBuffer"
                @rendered="onRendered"
              />
            </template>
            <template v-else-if="originalContent !== null">
              <pre class="plain-content">{{ originalContent }}</pre>
            </template>
            <template v-else>
              <a-empty description="暂不支持预览" />
            </template>
          </div>
        </a-tab-pane>

        <a-tab-pane key="markdown">
          <template #tab>
            <span>解析后的 Markdown</span>
            <span class="tab-caption">MARKDOWN</span>
          </template>
          <div class="result-panel">
            <div class="result-heading">
              <div>
                <div class="result-title">结构化文本</div>
                <div class="result-subtitle">模拟解析结果，用于预览文档清洗后的内容</div>
              </div>
              <a-tag color="blue">Markdown</a-tag>
            </div>
            <MdPreview
              :modelValue="parsedMarkdown"
              class="parsed-markdown"
            />
          </div>
        </a-tab-pane>

        <a-tab-pane key="chunks">
          <template #tab>
            <span>文档分片</span>
            <span class="tab-caption">{{ mockChunks.length }} CHUNKS</span>
          </template>
          <div class="chunks-panel">
            <div class="result-heading chunks-heading">
              <div>
                <div class="result-title">切分预览</div>
                <div class="result-subtitle">以下分片为演示数据，实际内容以解析任务结果为准</div>
              </div>
              <a-tag color="processing">{{ mockChunks.length }} 个分片</a-tag>
            </div>
            <article
              v-for="chunk in mockChunks"
              :key="chunk.id"
              class="chunk-card"
            >
              <header class="chunk-header">
                <span class="chunk-index">CHUNK {{ String(chunk.id).padStart(2, '0') }}</span>
                <span class="chunk-metrics">{{ chunk.characters }} 字符 <i /> {{ chunk.tokens }} tokens</span>
              </header>
              <div class="chunk-title">{{ chunk.title }}</div>
              <p class="chunk-text">{{ chunk.content }}</p>
            </article>
          </div>
        </a-tab-pane>
      </a-tabs>
    </template>
  </a-drawer>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { MdPreview } from 'md-editor-v3'
import 'md-editor-v3/lib/preview.css'
import VueOfficeDocx from '@vue-office/docx'
import '@vue-office/docx/lib/index.css'
import VueOfficeExcel from '@vue-office/excel'
import '@vue-office/excel/lib/index.css'
import VueOfficePptx from '@vue-office/pptx'
import VueOfficePdf from '@vue-office/pdf'
import { formatFileSize, getRendererType } from '../../utils/file.js'
import { useDocumentStore } from '../../stores/document.js'

const props = defineProps({
  visible: { type: Boolean, required: true },
  document: { type: Object, default: null }
})

defineEmits(['close', 'add-tag', 'remove-tag'])

const documentStore = useDocumentStore()

const originalContent = ref(null)
const parsedContent = ref('')
const fileArrayBuffer = ref(null)
const contentLoading = ref(false)
const contentError = ref('')
const activeContentTab = ref('original')

const rendererType = computed(() => {
  return getRendererType(props.document?.extension || '')
})

const parsedMarkdown = computed(() => {
  return parsedContent.value || [
    `# ${props.document?.name || '文档解析结果'}`,
    '',
    '> 此处为模拟解析内容，展示原始文档转换为 Markdown 后的结构。',
    '',
    '## 内容概览',
    '',
    '文档内容已完成文本提取与基础格式整理。标题、段落和列表等结构会在真实解析后保留。',
    '',
    '## 处理说明',
    '',
    '- 清理多余空行与重复空白',
    '- 识别标题层级和段落边界',
    '- 为后续知识检索准备规范文本'
  ].join('\n')
})

const mockChunks = computed(() => [
  {
    id: 1,
    title: '文档概览',
    content: '此分片为演示数据。真实解析后将包含文档开头的主题说明与核心概念。',
    characters: 42,
    tokens: 28
  },
  {
    id: 2,
    title: '主要内容',
    content: '系统会按语义边界拆分较长段落，并保留上下文信息，便于检索时准确召回。',
    characters: 39,
    tokens: 26
  },
  {
    id: 3,
    title: '补充说明',
    content: '分片长度和重叠范围由知识库的解析配置决定。当前内容仅用于界面预览。',
    characters: 37,
    tokens: 25
  }
])

function statusColor(status) {
  if (status === 'parsing') return 'processing'
  if (status === 'success') return 'success'
  if (status === 'failed') return 'error'
  return 'default'
}

function statusText(status) {
  if (status === 'parsing') return '解析中'
  if (status === 'success') return '解析完成'
  if (status === 'failed') return '解析失败'
  return status
}

function formatDate(ts) {
  if (!ts) return '—'
  const d = new Date(ts)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`
}

function onRendered() {
  // 占位回调
}

watch(
  () => [props.visible, props.document?.id],
  async ([visible, id], _, onCleanup) => {
    let cancelled = false
    onCleanup(() => { cancelled = true })
    originalContent.value = null
    parsedContent.value = ''
    fileArrayBuffer.value = null
    contentError.value = ''
    contentLoading.value = false
    activeContentTab.value = 'original'
    if (!visible || !id) return
    contentLoading.value = true
    const type = rendererType.value
    try {
      const [blob, parsed] = await Promise.all([
        documentStore.getFileBlob(id),
        documentStore.getParsedContent(id)
      ])
      if (cancelled) return
      parsedContent.value = parsed || ''
      if (!blob) throw new Error('原文件不存在，请重新上传文档')
      if (type.startsWith('office-')) {
        const buffer = await blob.arrayBuffer()
        if (!cancelled) fileArrayBuffer.value = buffer
      } else {
        const text = await blob.text()
        if (!cancelled) originalContent.value = text
      }
    } catch (err) {
      if (cancelled) return
      contentError.value = err.message || '读取原文件失败'
      console.error('load document content failed', err)
    } finally {
      if (!cancelled) contentLoading.value = false
    }
  },
  { immediate: true }
)
</script>

<style scoped>
.content-divider {
  margin: 20px 0 12px;
  color: #202a35;
  font-weight: 600;
}

.content-tabs :deep(.ant-tabs-nav) {
  margin-bottom: 16px;
}

.content-tabs :deep(.ant-tabs-tab) {
  padding: 10px 2px;
}

.tab-caption {
  margin-left: 8px;
  color: #9aa4b2;
  font-size: 10px;
  letter-spacing: 0.07em;
}

.doc-content {
  min-height: 220px;
}

.content-state {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 220px;
  border: 1px solid #edf0f3;
  border-radius: 8px;
  background: #fbfcfd;
}

.result-panel,
.chunks-panel {
  overflow: hidden;
  border: 1px solid #e9edf1;
  border-radius: 8px;
  background: #fff;
}

.result-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  padding: 17px 20px;
  border-bottom: 1px solid #edf0f3;
  background: #fbfcfd;
}

.result-title {
  color: #263340;
  font-size: 14px;
  font-weight: 600;
}

.result-subtitle {
  margin-top: 4px;
  color: #8994a2;
  font-size: 12px;
}

.parsed-markdown {
  min-height: 240px;
}

.parsed-markdown :deep(.md-editor-preview-wrapper) {
  padding: 20px 24px;
}

.chunks-panel {
  padding-bottom: 4px;
}

.chunks-heading {
  margin-bottom: 14px;
}

.chunk-card {
  margin: 0 16px 12px;
  padding: 15px 18px;
  border: 1px solid #edf0f3;
  border-radius: 7px;
  background: #fff;
  transition: border-color 160ms ease, box-shadow 160ms ease;
}

.chunk-card:hover {
  border-color: #c9d8e8;
  box-shadow: 0 4px 14px rgba(33, 54, 76, 0.05);
}

.chunk-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.chunk-index {
  color: #3f6e9d;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.1em;
}

.chunk-metrics {
  color: #9aa4b2;
  font-size: 11px;
}

.chunk-metrics i {
  display: inline-block;
  width: 3px;
  height: 3px;
  margin: 0 6px 3px;
  border-radius: 50%;
  background: #b7c0ca;
}

.chunk-title {
  margin-top: 10px;
  color: #263340;
  font-size: 13px;
  font-weight: 600;
}

.chunk-text {
  margin: 6px 0 0;
  color: #687584;
  font-size: 13px;
  line-height: 1.7;
}

.excel-viewer {
  width: 100%;
  height: 65vh;
  min-height: 520px;
  overflow: hidden;
  border: 1px solid #f0f0f0;
  border-radius: 6px;
}

.pdf-viewer {
  width: 100%;
  height: 75vh;
  min-height: 560px;
  overflow: auto;
  background: #f5f5f5;
  border: 1px solid #f0f0f0;
  border-radius: 6px;
}

.plain-content {
  background: #fafafa;
  padding: 16px;
  border-radius: 6px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: ui-monospace, 'SF Mono', Menlo, monospace;
  font-size: 13px;
  max-height: 60vh;
  overflow: auto;
}
</style>
