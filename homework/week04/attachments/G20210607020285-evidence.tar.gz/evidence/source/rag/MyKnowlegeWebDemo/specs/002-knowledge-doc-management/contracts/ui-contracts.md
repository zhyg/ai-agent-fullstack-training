# UI Component Contracts: 知识库中知识的管理

**Feature**: 002-knowledge-doc-management
**Date**: 2026-10-24

## 概述

本文档定义"知识库中知识的管理"特性新增/扩展的组件契约。所有组件使用 Vue 3 Composition API (`<script setup>`) 编写，沿用 001 号特性的编码风格。

---

## 页面组件

### KnowledgeManagement.vue

知识管理主页面（左侧目录树 + 右侧文档表），路径：`/knowledge-base/:kbId`。

**Props**: 无（通过 `route.params.kbId` 获取当前知识库 ID）

**内部状态**:
- `currentKb: KnowledgeBase | null` — 当前知识库
- `currentFolderId: String | null` — 当前选中目录 ID（默认选中第一个根目录或 null）
- `documents: Document[]` — 当前目录下的文档列表
- `createDocModalVisible: Boolean` — 新建知识对话框开关
- `selectedRowKeys: String[]` — 表格多选键
- `viewingDocument: Document | null` — 正在查看详情的文档
- `detailDrawerVisible: Boolean` — 详情抽屉开关
- `folderActionState: { visible: Boolean, type: 'create-root' | 'create-child' | 'rename' | 'delete', targetFolder: Folder | null }` — 目录操作模态框状态
- `docActionState: { visible: Boolean, type: 'add-tag' | 'edit-tag', targetDocument: Document | null }` — 文档标签模态框状态

**行为**:
1. 挂载时从 `useKbStore` 获取知识库信息，不存在则跳转回 `/knowledge-base`
2. 从 `useFolderStore` 获取当前知识库的目录树
3. 选中目录变化时从 `useDocumentStore` 刷新文档列表
4. 删除目录/文档成功后刷新列表；批量删除时忽略 `status=parsing` 的文档并给出提示
5. 详情抽屉内根据文档扩展名渲染不同组件

---

## 目录管理组件

### FolderTree.vue

左侧目录树，封装 a-tree 组件，支持展开/折叠、拖拽排序与嵌套、悬浮操作菜单。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| kbId | `String` | 是 | - | 所属知识库 ID |
| selectedFolderId | `String \| null` | 否 | `null` | 当前选中目录 ID |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| select | `folder: Folder \| null` | 选中某个目录 |
| create-root | 无 | 点击"新建根目录"按钮 |
| create-child | `parent: Folder` | 点击某目录菜单中的"新建目录" |
| rename | `folder: Folder` | 点击某目录菜单中的"修改目录名称" |
| delete | `folder: Folder` | 点击某目录菜单中的"删除目录" |

**内部行为**:
- 从 store 获取扁平目录并通过 `buildTree` 生成 `treeData`
- 启用 `a-tree` 的 `draggable` 属性
- `@drop` 事件调用 `store.moveFolder(dragNodeId, dropNodeId, dropPosition)`
- `allowDrop` 阻止拖拽到自身或子孙目录
- 悬浮目录节点时显示"..."按钮（`a-dropdown`），点击后展开三项菜单
- 空状态展示"新建根目录"引导按钮

**Ant Design 组件**: `a-tree`、`a-dropdown`、`a-menu`、`a-button`、`a-empty`

### FolderActionModal.vue

统一的目录操作模态框，支持四种模式。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 对话框是否可见 |
| type | `'create-root' \| 'create-child' \| 'rename' \| 'delete'` | 是 | - | 操作类型 |
| folder | `Folder \| null` | 否 | `null` | 目标目录（重命名/删除/创建子目录时的父目录） |
| kbId | `String` | 是 | - | 当前知识库 ID（用于创建根目录） |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭对话框 |
| submit | `data` | 提交操作，data 结构随 type 变化（见下） |

**submit payload 结构**:
- `create-root`: `{ name }`
- `create-child`: `{ parentId, name }`
- `rename`: `{ id, name }`
- `delete`: `{ id }`

**表单字段**（仅创建/重命名模式）:
- `name`: `a-input`，必填

**删除模式**:
- 使用 `a-modal` 的确认样式，显示"确认删除目录 {name} 及其所有子目录与文档吗？"

**Ant Design 组件**: `a-modal`、`a-form`、`a-form-item`、`a-input`

---

## 文档管理组件

### DocumentTable.vue

右侧文档列表表格。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| folderId | `String \| null` | 是 | - | 当前目录 ID |
| documents | `Document[]` | 是 | - | 文档列表 |
| selectedRowKeys | `String[]` | 是 | - | 多选状态（受控） |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| select-change | `keys: String[]` | 多选变化 |
| row-click | `document: Document` | 点击行（打开详情） |
| create | 无 | 点击"新建知识"按钮 |
| batch-delete | `ids: String[]` | 批量删除 |
| delete | `document: Document` | 单行删除 |
| add-tag | `document: Document` | 单行新增标签 |
| edit-tag | `document: Document` | 单行修改标签 |

**表格列定义**:

| 列名 | 字段 | 渲染 |
| ---- | ---- | ---- |
| 名称 | `name` | 字符串 |
| 标签 | `tags` | `a-tag` 数组渲染 |
| 大小 | `size` | 格式化显示（KB/MB/GB） |
| 状态 | `status` | 颜色图标：`parsing`=蓝、`success`=绿、`failed`=红 |
| 创建时间 | `createdAt` | 日期格式化 |
| 更新时间 | `updatedAt` | 日期格式化 |
| 操作 | - | 按钮组：新增标签 / 修改标签 / 删除 |

**Ant Design 组件**: `a-table`、`a-tag`、`a-button`、`a-popconfirm`（用于单行删除确认）

**特殊行为**:
- 未选中任何文档时，"批量删除"按钮禁用
- `status=parsing` 的行其"删除"按钮禁用或点击后 Toast 提示

### DocumentCreateModal.vue

新建知识（文件上传）对话框。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 对话框是否可见 |
| folderId | `String` | 是 | - | 目标目录 ID |
| kbId | `String` | 是 | - | 知识库 ID |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭对话框（不影响进行中的上传） |
| submit | `{ file, folderId, kbId }` | 选中文件并确认 |

**行为**:
- 使用 `a-upload-dragger` 支持拖拽上传
- `beforeUpload` 校验大小 ≤ 500MB，超大文件 Toast 报错并阻止
- 确认按钮触发 `submit`，由父组件调用 store 创建 Document 记录并启动状态模拟
- 关闭对话框不影响已提交的上传任务

**Ant Design 组件**: `a-modal`、`a-upload-dragger`、`a-button`

### DocumentDetailDrawer.vue

文档详情抽屉。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 抽屉是否可见 |
| document | `Document \| null` | 是 | - | 当前文档 |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭抽屉 |
| add-tag | `document: Document` | 新增标签 |
| edit-tag | `document: Document` | 修改标签 |

**内容布局**:
- 顶部元信息区：名称、描述、标签（`a-tag` 数组）、大小、状态、创建时间、更新时间
- 下方内容区：根据文档扩展名动态渲染
  - `.docx/.doc` → `<vue-office-docx />`
  - `.xlsx/.xls` → `<vue-office-excel />`
  - `.pptx/.ppt` → `<vue-office-pptx />`
  - `.pdf` → `<vue-office-pdf />`
  - `.md/.markdown` → `<v-md-preview />`
  - 其他 → `<pre>` 文本 或 "暂不支持预览" 占位

**Ant Design 组件**: `a-drawer`、`a-descriptions`、`a-tag`、`a-button`、`a-empty`

### DocumentActionModal.vue

文档标签操作模态框。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 对话框是否可见 |
| type | `'add-tag' \| 'edit-tag'` | 是 | - | 操作类型 |
| document | `Document \| null` | 否 | `null` | 目标文档 |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭对话框 |
| submit | `data: { documentId, tags }` | 提交标签数组 |

**表单字段**:
- `tags`: `a-select`（mode="tags"），支持动态输入多个标签

**Ant Design 组件**: `a-modal`、`a-form`、`a-form-item`、`a-select`

---

## 扩展的 Composables / 工具

### useStorage.js（扩展）

| 函数 | 签名 | 说明 |
| ---- | ---- | ---- |
| `saveBlob(storeName, key, blob)` | `(string, string, Blob) => Promise<void>` | 保存 Blob 到 IndexedDB |
| `getBlob(storeName, key)` | `(string, string) => Promise<Blob \| null>` | 从 IndexedDB 读取 Blob |
| `deleteBlob(storeName, key)` | `(string, string) => Promise<void>` | 从 IndexedDB 删除 |
| `saveText(storeName, key, text)` | `(string, string, string) => Promise<void>` | 保存文本到 IndexedDB |
| `getText(storeName, key)` | `(string, string) => Promise<string \| null>` | 从 IndexedDB 读取文本 |

> 内部封装 IndexedDB 的 `kb_files_db` 数据库，`files` 与 `parsed_contents` 两个 object store。

### utils/tree.js（新增）

| 函数 | 签名 | 说明 |
| ---- | ---- | ---- |
| `buildTree(folders, kbId)` | `(Folder[], string) => TreeNode[]` | 扁平目录构建 a-tree 数据 |
| `isDescendant(folders, ancestorId, descendantId)` | `(Folder[], string, string) => Boolean` | 判断祖先关系（用于拖拽校验） |
| `resolveConflictName(siblingNames, desiredName)` | `(string[], string) => string` | 生成不冲突的目录名 |

### utils/file.js（新增）

| 函数 | 签名 | 说明 |
| ---- | ---- | ---- |
| `formatFileSize(bytes)` | `(number) => string` | 字节数格式化为 KB/MB/GB |
| `getExtension(filename)` | `(string) => string` | 提取扩展名（小写） |
| `getRendererType(extension)` | `(string) => 'office-docx' \| 'office-excel' \| 'office-pptx' \| 'office-pdf' \| 'markdown' \| 'text'` | 根据扩展名返回渲染类型 |

---

## 路由扩展

在 `src/router/index.js` 中新增路由：

```javascript
{
  path: '/knowledge-base/:kbId',
  name: 'KnowledgeManagement',
  component: () => import('../views/KnowledgeBaseManagement.vue'),
  props: false
}
```

**KbCard.vue 扩展行为**:
- 新增"进入"按钮（或点击卡片整体），通过 `router.push({ name: 'KnowledgeManagement', params: { kbId } })` 进入知识管理页面。
