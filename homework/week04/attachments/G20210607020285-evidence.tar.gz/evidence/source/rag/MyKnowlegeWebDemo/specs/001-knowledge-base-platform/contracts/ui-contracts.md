# UI Component Contracts: 知识库平台原型

**Feature**: 001-knowledge-base-platform
**Date**: 2026-10-23

## 概述

本文档定义各组件的 Props 接口契约。所有组件使用 Vue 3 Composition API (`<script setup>`) 编写。

---

## 布局组件

### AppLayout.vue

页面整体布局，包含侧边栏和内容区域。

**Props**: 无（内部使用 `a-layout` 组合）

**结构**:
```
a-layout (full height)
├── a-layout-sider (固定宽度 200px)
│   └── a-menu (mode="inline", selectedKeys 绑定当前路由)
│       ├── 新会话 (disabled)
│       ├── 知识库 → /knowledge-base
│       ├── 智能体 (disabled)
│       └── 模型管理 → /models
└── a-layout-content
    └── router-view
```

---

## 模型管理组件

### ModelList.vue

模型卡片列表容器。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| models | `Model[]` | 是 | - | 模型列表数据 |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| create | 无 | 点击"新建模型"按钮 |
| edit | `model: Model` | 点击卡片"设置"按钮 |
| delete | `model: Model` | 点击卡片"删除"按钮 |

**行为**: 当 `models` 为空时显示 `EmptyModel` 组件。

### ModelCard.vue

单个模型信息卡片。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| model | `Model` | 是 | - | 模型数据 |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| edit | `model: Model` | 点击"设置"按钮 |
| delete | `model: Model` | 点击"删除"按钮 |

**展示内容**:
- 模型名称（卡片标题）
- URL 摘要（截断显示，hover 显示完整）
- "设置"按钮
- "删除"按钮

**Ant Design 组件**: `a-card`

### ModelFormDrawer.vue

模型创建/编辑抽屉表单。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 抽屉是否可见 |
| model | `Model \| null` | 否 | `null` | 编辑时传入已有模型，创建时为 null |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭抽屉 |
| submit | `data: { name, url, key }` | 表单验证通过后提交 |

**表单字段**:
- `name`: `a-input`，必填
- `url`: `a-input`，必填
- `key`: `a-input`，必填

**Ant Design 组件**: `a-drawer` + `a-form` + `a-form-item` + `a-input` + `a-button`

**验证规则**:
```
name: [{ required: true, message: '请输入模型名称' }]
url:  [{ required: true, message: '请输入模型 URL' }]
key:  [{ required: true, message: '请输入 API Key' }]
```

### EmptyModel.vue

模型列表空状态引导。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| 无 | - | - | - | - |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| create | 无 | 点击"创建第一个模型"按钮 |

**展示内容**: 使用 `a-empty` 组件 + 引导文案 + 创建按钮

---

## 知识库管理组件

### KbList.vue

知识库卡片列表容器。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| knowledgeBases | `KnowledgeBase[]` | 是 | - | 知识库列表数据 |
| models | `Model[]` | 是 | - | 模型列表（用于显示关联模型名称） |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| create | 无 | 点击"新建知识库"按钮 |
| edit | `kb: KnowledgeBase` | 点击卡片"设置"按钮 |
| delete | `kb: KnowledgeBase` | 点击卡片"删除"按钮 |

**行为**: 当 `knowledgeBases` 为空时显示 `EmptyKb` 组件。

### KbCard.vue

单个知识库信息卡片。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| kb | `KnowledgeBase` | 是 | - | 知识库数据 |
| models | `Model[]` | 是 | - | 模型列表（用于显示关联模型名称） |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| enter | `kb: KnowledgeBase` | 点击"进入"按钮，跳转到知识管理页（由 002 特性新增） |
| edit | `kb: KnowledgeBase` | 点击"设置"按钮 |
| delete | `kb: KnowledgeBase` | 点击"删除"按钮 |

**展示内容**:
- 知识库名称（卡片标题）
- 描述摘要（截断显示）
- 关联的四个模型名称（通过 model ID 查找显示）
- "设置"按钮
- "删除"按钮

**交互行为**:
- 点击卡片任意区域触发 `enter` 事件，跳转至 `/knowledge-base/:kbId`（由 002 特性新增）
- "设置"与"删除"按钮使用 `@click.stop` 阻止冒泡，避免触发 enter
- 卡片 `cursor: pointer` 提示可点击

**Ant Design 组件**: `a-card`、`a-button`

### KbCreateModal.vue

创建知识库模态对话框。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 对话框是否可见 |
| models | `Model[]` | 是 | - | 可选模型列表 |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭对话框 |
| submit | `data: { name, description, llmModelId, embeddingModelId, imageModelId, rerankModelId }` | 表单验证通过后提交 |

**表单字段**:
- `name`: `a-input`，必填
- `description`: `a-textarea`，可选
- `llmModelId`: `a-select`，必选
- `embeddingModelId`: `a-select`，必选
- `imageModelId`: `a-select`，必选
- `rerankModelId`: `a-select`，必选

**Ant Design 组件**: `a-modal` + `a-form` + `a-form-item` + `a-input` + `a-textarea` + `a-select`

**验证规则**:
```
name:            [{ required: true, message: '请输入知识库名称' }]
llmModelId:      [{ required: true, message: '请选择 LLM 模型' }]
embeddingModelId:[{ required: true, message: '请选择 Embedding 模型' }]
imageModelId:    [{ required: true, message: '请选择图片识别模型' }]
rerankModelId:   [{ required: true, message: '请选择 Rerank 模型' }]
```

**特殊行为**: 当 `models` 为空时，模型选择框显示 placeholder "请先创建模型"，且禁止提交。

### KbFormDrawer.vue

编辑知识库抽屉表单。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| visible | `Boolean` | 是 | - | 抽屉是否可见 |
| kb | `KnowledgeBase` | 是 | - | 要编辑的知识库 |
| models | `Model[]` | 是 | - | 可选模型列表 |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| close | 无 | 关闭抽屉 |
| submit | `data: { name, description, llmModelId, embeddingModelId, imageModelId, rerankModelId }` | 表单验证通过后提交 |

**表单字段**: 同 KbCreateModal，但预填当前值

**Ant Design 组件**: `a-drawer` + `a-form` + `a-form-item` + `a-input` + `a-textarea` + `a-select`

### EmptyKb.vue

知识库列表空状态引导。

| Prop | Type | Required | Default | Description |
| ---- | ---- | -------- | ------- | ----------- |
| 无 | - | - | - | - |

**Events**:
| Event | Payload | Description |
| ----- | ------- | ----------- |
| create | 无 | 点击"创建第一个知识库"按钮 |

**展示内容**: 使用 `a-empty` 组件 + 引导文案 + 创建按钮

---

## 页面组件

### ModelManagement.vue

模型管理页面。

**内部状态**:
- `models: Model[]` — 从 store 获取
- `drawerVisible: Boolean` — 抽屉开关
- `editingModel: Model | null` — 当前编辑的模型（null 表示新建）

**行为**:
1. 加载时从 store 获取模型列表
2. "新建模型"按钮打开 ModelFormDrawer（editingModel=null）
3. 卡片"设置"按钮打开 ModelFormDrawer（editingModel=model）
4. 卡片"删除"按钮弹出 `Modal.confirm` 确认对话框
5. 创建/编辑/删除成功后更新列表

### KnowledgeBase.vue

知识库管理页面。

**内部状态**:
- `knowledgeBases: KnowledgeBase[]` — 从 store 获取
- `models: Model[]` — 从 store 获取
- `createModalVisible: Boolean` — 创建对话框开关
- `drawerVisible: Boolean` — 编辑抽屉开关
- `editingKb: KnowledgeBase | null` — 当前编辑的知识库

**行为**:
1. 加载时从 store 获取知识库列表和模型列表
2. "新建知识库"按钮打开 KbCreateModal
3. 卡片"设置"按钮打开 KbFormDrawer
4. 卡片"删除"按钮弹出 `Modal.confirm` 确认对话框
5. 创建/编辑/删除成功后更新列表
