import { reactive, computed } from 'vue'
import { getItem, setItem, removeItem, generateId } from '../composables/useStorage.js'

const USERS_KEY = 'knowledge_platform_users'
const CURRENT_USER_KEY = 'knowledge_platform_current_user'
const ROLES_KEY = 'knowledge_platform_roles'
const initializedAt = new Date().toISOString()
const initialRoles = [
  { id: 'admin', name: 'admin', description: '管理员', createdAt: initializedAt, updatedAt: initializedAt },
  { id: 'user', name: 'user', description: '普通用户', createdAt: initializedAt, updatedAt: initializedAt }
]
const state = reactive({
  users: getItem(USERS_KEY) || [],
  currentUser: getItem(CURRENT_USER_KEY) || null,
  roles: getItem(ROLES_KEY) ?? initialRoles
})

function getUserRoleIds(user) {
  return user.roleIds ?? (state.roles.some(role => role.id === 'user') ? ['user'] : [])
}

function initializeRoles() {
  if (getItem(ROLES_KEY) === null) setItem(ROLES_KEY, state.roles)
}

function validateUser(data, id) {
  if (!data.username || data.username.length < 3 || data.username.length > 20) {
    return '账号长度应为3至20个字符'
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) return '请输入有效的邮箱地址'
  if ((!id || data.password) && (!data.password || data.password.length < 6)) return '密码至少6个字符'
  if (state.users.some(user => user.id !== id && user.username.toLowerCase() === data.username.toLowerCase())) {
    return '用户名已存在'
  }
  if (state.users.some(user => user.id !== id && user.email.toLowerCase() === data.email.toLowerCase())) {
    return '邮箱已被注册'
  }
  if (!Array.isArray(data.roleIds) || data.roleIds.some(roleId => !state.roles.some(role => role.id === roleId))) {
    return '所选角色不存在，请重新选择'
  }
}

function saveUsers(users) {
  const updatedCurrentUser = users.find(user => user.id === state.currentUser?.id)
  let currentUser = state.currentUser
  if (updatedCurrentUser) {
    const { password, ...userInfo } = "[REDACTED]"
    currentUser = userInfo
  }
  initializeRoles()
  const previousUsers = getItem(USERS_KEY)
  setItem(USERS_KEY, users)
  try {
    if (updatedCurrentUser) setItem(CURRENT_USER_KEY, currentUser)
  } catch (error) {
    if (previousUsers === null) removeItem(USERS_KEY)
    else setItem(USERS_KEY, previousUsers)
    throw error
  }
  state.users = users
  state.currentUser = currentUser
}

export function useUserStore() {
  // 计算属性：用户是否已登录
  const isLoggedIn = computed(() => !!state.currentUser)

  // 注册新用户
  function register(userData) {
    const result = createUser({ ...userData, roleIds: getUserRoleIds({}) })
    return result.success ? { ...result, message: '注册成功' } : result
  }

  function createUser(userData) {
    const data = {
      username: userData.username.trim(),
      email: userData.email.trim(),
      password: "[REDACTED]"
      roleIds: [...new Set(userData.roleIds)]
    }
    const error = validateUser(data)
    if (error) return { success: false, message: error }
    const now = new Date().toISOString()
    const newUser = {
      ...data,
      id: generateId(),
      createdAt: now,
      updatedAt: now
    }
    saveUsers([...state.users, newUser])
    return { success: true, message: '用户创建成功' }
  }

  function updateUser(id, userData) {
    const user = state.users.find(item => item.id === id)
    if (!user) return { success: false, message: '用户不存在，请刷新后重试' }
    const data = {
      username: userData.username.trim(),
      email: userData.email.trim(),
      roleIds: [...new Set(userData.roleIds)]
    }
    const error = validateUser(data, id)
    if (error) return { success: false, message: error }
    saveUsers(state.users.map(item => item.id === id ? { ...user, ...data, updatedAt: new Date().toISOString() } : item))
    return { success: true, message: '用户更新成功' }
  }

  function saveRole(id, roleData) {
    const name = roleData.name.trim()
    const description = roleData.description.trim()
    if (!name || name.length > 50) return { success: false, message: '角色名须为1至50个字符' }
    if (description.length > 200) return { success: false, message: '角色描述最多200个字符' }
    if (id && !state.roles.some(role => role.id === id)) return { success: false, message: '角色不存在，请刷新后重试' }
    if (state.roles.some(role => role.id !== id && role.name.toLowerCase() === name.toLowerCase())) {
      return { success: false, message: '角色名已存在' }
    }
    const now = new Date().toISOString()
    const roles = id
      ? state.roles.map(role => role.id === id ? { ...role, name, description, updatedAt: now } : role)
      : [...state.roles, { id: generateId(), name, description, createdAt: now, updatedAt: now }]
    setItem(ROLES_KEY, roles)
    state.roles = roles
    return { success: true, message: id ? '角色更新成功' : '角色创建成功' }
  }

  function deleteRole(id) {
    if (!state.roles.some(role => role.id === id)) return { success: false, message: '角色不存在，请刷新后重试' }
    if (state.users.some(user => getUserRoleIds(user).includes(id))) {
      return { success: false, message: '该角色已分配给用户，请先解除关联后再删除' }
    }
    const roles = state.roles.filter(role => role.id !== id)
    setItem(ROLES_KEY, roles)
    state.roles = roles
    return { success: true, message: '角色删除成功' }
  }

  // 用户登录
  function login(username, password) {
    const user = state.users.find(
      user => user.username === username && user.password ="[REDACTED]"
    )

    if (!user) {
      return { success: false, message: '用户名或密码错误' }
    }

    // 保存当前用户（不包含密码）
    const { password: _, ...userWithoutPassword } = "[REDACTED]"
    state.currentUser = userWithoutPassword
    setItem(CURRENT_USER_KEY, userWithoutPassword)

    return { success: true, message: '登录成功', user: userWithoutPassword }
  }

  // 用户退出
  function logout() {
    state.currentUser = null
    removeItem(CURRENT_USER_KEY)
    return { success: true, message: '退出成功' }
  }

  // 获取当前用户信息
  function getCurrentUserInfo() {
    return state.currentUser
  }

  return {
    state,
    isLoggedIn,
    register,
    createUser,
    updateUser,
    saveRole,
    deleteRole,
    getUserRoleIds,
    initializeRoles,
    login,
    logout,
    getCurrentUserInfo
  }
}
