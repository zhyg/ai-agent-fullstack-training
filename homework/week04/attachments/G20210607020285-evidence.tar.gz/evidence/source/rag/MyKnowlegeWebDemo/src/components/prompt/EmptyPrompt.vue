<template>
  <div class="empty-prompt">
    <div class="empty-icon">
      <FileTextOutlined />
    </div>
    <h3 class="empty-title">还没有提示词</h3>
    <p class="empty-description">创建您的第一个提示词，开始构建强大的 AI 交互</p>
    <a-button type="primary" size="large" @click="$emit('create')">
      <template #icon><PlusOutlined /></template>
      新建提示词
    </a-button>
  </div>
</template>

<script setup>
import { FileTextOutlined, PlusOutlined } from '@ant-design/icons-vue'

defineEmits(['create'])
</script>

<style scoped>
.empty-prompt {
  text-align: center;
  padding: 80px 20px;
}

.empty-icon {
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 24px;
  font-size: 36px;
  color: #fff;
}

.empty-title {
  font-size: 20px;
  font-weight: 600;
  color: #1f1f1f;
  margin-bottom: 8px;
}

.empty-description {
  font-size: 14px;
  color: #8c8c8c;
  margin-bottom: 24px;
}
</style>
