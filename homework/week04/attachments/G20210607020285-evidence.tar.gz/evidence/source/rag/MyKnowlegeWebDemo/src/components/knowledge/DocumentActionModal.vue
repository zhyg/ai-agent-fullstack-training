<template>
  <a-modal
    :open="visible"
    title="新增标签"
    ok-text="确认"
    cancel-text="取消"
    @ok="handleSubmit"
    @cancel="$emit('close')"
  >
    <a-form :label-col="{ span: 5 }">
      <a-form-item label="标签">
        <a-select
          v-model:value="tags"
          mode="tags"
          placeholder="输入标签后按回车添加"
          style="width: 100%"
        />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  visible: { type: Boolean, required: true },
  document: { type: Object, default: null }
})

const emit = defineEmits(['close', 'submit'])

const tags = ref([])

watch(
  () => props.visible,
  () => {
    tags.value = []
  }
)

function handleSubmit() {
  if (!props.document) return
  const unique = Array.from(new Set(tags.value.map((t) => String(t).trim()).filter(Boolean)))
  emit('submit', { documentId: props.document.id, tags: unique })
}
</script>
