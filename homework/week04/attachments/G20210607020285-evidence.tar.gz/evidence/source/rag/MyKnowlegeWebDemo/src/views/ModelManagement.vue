<template>
  <div>
    <ModelList
      :models="modelStore.state.models"
      @create="openCreateDrawer"
      @edit="openEditDrawer"
      @delete="handleDelete"
    />
    <ModelFormDrawer
      :visible="drawerVisible"
      :model="editingModel"
      :category="creatingCategory"
      @close="closeDrawer"
      @submit="handleSubmit"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Modal, message } from 'ant-design-vue'
import { useModelStore } from '../stores/model.js'
import ModelList from '../components/model/ModelList.vue'
import ModelFormDrawer from '../components/model/ModelFormDrawer.vue'

const modelStore = useModelStore()
const drawerVisible = ref(false)
const editingModel = ref(null)
const creatingCategory = ref('chat')

function openCreateDrawer(category = 'chat') {
  editingModel.value = null
  creatingCategory.value = category
  drawerVisible.value = true
}

function openEditDrawer(model) {
  editingModel.value = model
  drawerVisible.value = true
}

function closeDrawer() {
  drawerVisible.value = false
  editingModel.value = null
}

function handleSubmit(data) {
  if (editingModel.value) {
    modelStore.updateModel(editingModel.value.id, data)
    message.success('模型更新成功')
  } else {
    modelStore.createModel(data)
    message.success('模型创建成功')
  }
  closeDrawer()
}

function handleDelete(model) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除模型 "${model.name}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    onOk() {
      modelStore.deleteModel(model.id)
      message.success('模型删除成功')
    }
  })
}
</script>
