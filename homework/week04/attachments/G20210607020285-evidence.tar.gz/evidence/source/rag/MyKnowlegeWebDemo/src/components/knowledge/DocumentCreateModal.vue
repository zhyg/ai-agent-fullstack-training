<template>
  <a-modal
    :open="visible"
    title="新建知识"
    ok-text="确认上传"
    cancel-text="取消"
    :confirm-loading="false"
    @ok="handleSubmit"
    @cancel="$emit('close')"
  >
    <a-upload-dragger
      :before-upload="beforeUpload"
      :file-list="fileList"
      :max-count="1"
      @remove="handleRemove"
    >
      <p class="ant-upload-drag-icon">
        <InboxOutlined />
      </p>
      <p class="ant-upload-text">点击或拖拽文件到此处上传</p>
      <p class="ant-upload-hint">
        支持任意类型文件及 .zip / .tar.gz 压缩包，单文件上限 500MB
      </p>
    </a-upload-dragger>
  </a-modal>
</template>

<script setup>
import { ref, watch } from 'vue'
import { InboxOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'

const MAX_FILE_SIZE = 524288000 // 500MB

const props = defineProps({
  visible: { type: Boolean, required: true },
  folderId: { type: String, default: null },
  kbId: { type: String, required: true }
})

const emit = defineEmits(['close', 'submit'])

const fileList = ref([])

watch(
  () => props.visible,
  (val) => {
    if (!val) fileList.value = []
  }
)

function beforeUpload(file) {
  if (file.size > MAX_FILE_SIZE) {
    message.error('文件大小超过 500MB 限制')
    return false
  }
  fileList.value = [file]
  return false // 不自动上传
}

function handleRemove() {
  fileList.value = []
}

function handleSubmit() {
  if (!props.folderId) {
    message.warning('请先选择目录')
    return
  }
  if (fileList.value.length === 0) {
    message.warning('请先选择文件')
    return
  }
  emit('submit', {
    file: fileList.value[0],
    folderId: props.folderId,
    kbId: props.kbId
  })
}
</script>
