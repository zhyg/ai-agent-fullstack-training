# Implementation Plan: 知识库中知识的管理

**Branch**: `002-knowledge-doc-management` | **Date**: 2026-10-24 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/002-knowledge-doc-management/spec.md`

## Summary

为知识库平台实现"知识库中知识的管理"功能：在已有知识库列表的基础上，新增**知识管理页面**，提供左侧**可拖拽的目录树**与右侧**文档表格**，支持目录的增删改查与拖拽排序/嵌套，支持文档的上传（含压缩包）、批量删除、详情查看（Office / Markdown / 普通文档多渲染）以及标签管理。技术路线沿用 001 号特性的 Vue 3 + ant-design-vue 4.x + 纯前端存储方案，新增 `@vue-office/*` 与 `@kangc/v-md-editor` 依赖实现文档渲染，并引入 IndexedDB 作为文件 Blob 与解析文本的存储层。

## Technical Context

**Language/Version**: JavaScript (ES2022) + Vue 3.5.x

**Primary Dependencies**:
- `vue@^3.5.44`
- `ant-design-vue@^4.2.6`
- `vue-router@^4.6.4`
- `@vue-office/docx`、`@vue-office/excel`、`@vue-office/pptx`、`@vue-office/pdf`（新增）
- `@kangc/v-md-editor`（新增）
- 浏览器原生 IndexedDB（无封装库依赖，手写薄封装）

**Storage**:
- 元数据：`localStorage`（`kb_folders` / `kb_documents`）
- 文件 Blob + 解析文本：IndexedDB `kb_files_db`（`files` / `parsed_contents`）

**Testing**: 端到端手动验收（详见 [quickstart.md](./quickstart.md)），无自动化测试框架（与 001 号特性保持一致）

**Target Platform**: 现代桌面浏览器（Chrome 110+ / Edge 110+ / Firefox 115+ / Safari 16.4+），仅桌面 UI，不做移动端适配

**Project Type**: 纯前端原型（web-app），无后端

**Performance Goals**:
- 详情抽屉 2 秒内打开（SC-003）
- 批量删除 50 篇文档 5 秒内完成列表刷新（SC-004）
- 单知识库 ≤ 1000 篇文档、≤ 10 层目录时交互流畅无卡顿（SC-006）

**Constraints**:
- 单文件上传上限 500MB（spec 澄清 Q1）
- `status=parsing` 的文档禁止删除（spec 澄清 Q5）
- 目录拖拽到同名目录时自动重命名为"原名(1)"并 Toast 提示（spec 澄清 Q4）
- 拖拽禁止到自身或子孙目录
- 纯前端，无后端接口

**Scale/Scope**:
- 单知识库 ≤ 1000 篇文档
- 目录层级 ≤ 10 层
- 单文件 ≤ 500MB

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

当前项目未配置 `.specify/memory/constitution.md` 的具体原则（文件为模板占位符）。因此本计划无具体 Constitution 门控需要校验，以 001 号特性确立的项目惯例为治理依据：

| 项目惯例 | 002 特性遵循情况 |
| -------- | ---------------- |
| Vue 3 + ant-design-vue 4.x 组件优先 | ✅ 新增组件全部基于 ant-design-vue，三方渲染组件为 PRD 明确指定 |
| Composable + reactive + localStorage 状态管理 | ✅ 新增 `useFolderStore` / `useDocumentStore` 沿用相同模式 |
| ID 生成沿用 `generateId()` | ✅ 复用 `useStorage.js` |
| 路由沿用 vue-router 4 | ✅ 新增 `/knowledge-base/:kbId` 参数化路由 |
| 纯前端，不引入后端 | ✅ 文件存储使用 IndexedDB，保持前端闭环 |

**GATE 评估**：全部通过，无违规。

## Project Structure

### Documentation (this feature)

```text
specs/002-knowledge-doc-management/
├── plan.md              # 本文件
├── research.md          # Phase 0 技术决策
├── data-model.md        # Phase 1 数据模型
├── quickstart.md        # Phase 1 验收指南
├── contracts/
│   └── ui-contracts.md  # Phase 1 组件契约
├── checklists/
│   └── requirements.md  # 规格质量检查表
└── spec.md              # 功能规格
```

### Source Code (repository root)

```text
src/
├── components/
│   ├── knowledge-base/              # 001 已有，扩展 KbCard 跳转行为
│   │   ├── KbCard.vue               # 新增"进入"按钮
│   │   └── ...（其他沿用）
│   ├── knowledge/                   # 002 新增
│   │   ├── FolderTree.vue
│   │   ├── FolderActionModal.vue
│   │   ├── DocumentTable.vue
│   │   ├── DocumentCreateModal.vue
│   │   ├── DocumentDetailDrawer.vue
│   │   └── DocumentActionModal.vue
│   └── layout/                      # 沿用
├── composables/
│   └── useStorage.js                # 扩展 IndexedDB 封装
├── stores/
│   ├── model.js                     # 沿用
│   ├── knowledgeBase.js             # 沿用
│   ├── folder.js                    # 002 新增
│   └── document.js                  # 002 新增
├── utils/
│   ├── tree.js                      # 002 新增：buildTree / isDescendant / resolveConflictName
│   └── file.js                      # 002 新增：formatFileSize / getExtension / getRendererType
├── views/
│   ├── KnowledgeBase.vue            # 沿用
│   ├── KnowledgeManagement.vue      # 002 新增
│   └── ModelManagement.vue          # 沿用
├── router/
│   └── index.js                     # 新增 /knowledge-base/:kbId 路由
├── App.vue                          # 沿用
└── main.js                          # 沿用

public/                              # 沿用
```

**Structure Decision**: 沿用 001 号特性的"单项目 + 功能目录"结构，新增 `components/knowledge/`、`stores/folder.js`、`stores/document.js`、`utils/tree.js`、`utils/file.js` 与 `views/KnowledgeManagement.vue`，不引入新层级。

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

无 Constitution 违规，无需记录复杂度追踪项。
