import { createRouter, createWebHashHistory } from 'vue-router'
import KnowledgeBase from '../views/KnowledgeBase.vue'
import ModelManagement from '../views/ModelManagement.vue'
import PromptManagement from '../views/PromptManagement.vue'
import ChatManagement from '../views/ChatManagement.vue'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import { getItem } from '../composables/useStorage.js'

const routes = [
  {
    path: '/',
    redirect: '/chat'
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/chat',
    name: 'Chat',
    component: ChatManagement,
    meta: { requiresAuth: true }
  },
  {
    path: '/knowledge-base',
    name: 'KnowledgeBase',
    component: KnowledgeBase,
    meta: { requiresAuth: true }
  },
  {
    path: '/knowledge-base/:kbId',
    name: 'KnowledgeManagement',
    component: () => import('../views/KnowledgeManagement.vue'),
    props: false,
    meta: { requiresAuth: true }
  },
  {
    path: '/models',
    name: 'Models',
    component: ModelManagement,
    meta: { requiresAuth: true }
  },
  {
    path: '/api-keys',
    name: 'ApiKeys',
    component: () => import('../views/ApiKeyManagement.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/permissions',
    redirect: '/permissions/users'
  },
  {
    path: '/permissions/users',
    name: 'PermissionUsers',
    component: () => import('../views/PermissionManagement.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/permissions/roles',
    name: 'PermissionRoles',
    component: () => import('../views/PermissionManagement.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/prompts',
    name: 'Prompts',
    component: PromptManagement,
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

// 路由守卫：检查登录状态
router.beforeEach((to, from, next) => {
  const currentUser = getItem('knowledge_platform_current_user')
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth)
  
  if (requiresAuth && !currentUser) {
    // 需要认证但未登录，跳转到登录页
    next('/login')
  } else if ((to.path === '/login' || to.path === '/register') && currentUser) {
    // 已登录用户访问登录/注册页，跳转到首页
    next('/chat')
  } else {
    next()
  }
})

export default router
