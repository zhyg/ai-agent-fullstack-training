<template>
  <div class="document-table">
    <div class="document-table-toolbar">
      <h3 style="margin: 0;">
        {{ folderTitle }}
      </h3>
      <div class="toolbar-actions">
        <a-button
          danger
          :disabled="selectedRowKeys.length === 0"
          @click="$emit('batch-delete', [...selectedRowKeys])"
        >
          <template #icon><DeleteOutlined /></template>
          批量删除
        </a-button>
        <a-button
          type="primary"
          :disabled="!folderId"
          @click="$emit('create')"
        >
          <template #icon><PlusOutlined /></template>
          新建知识
        </a-button>
      </div>
    </div>

    <a-table
      :columns="columns"
      :data-source="documents"
      :row-key="(record) => record.id"
      :row-selection="rowSelection"
      :pagination="{ pageSize: 20, showSizeChanger: false }"
      :custom-row="customRow"
      size="middle"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'name'">
          <span class="doc-name">{{ record.name }}</span>
        </template>
        <template v-else-if="column.key === 'tags'">
          <a-tag
            v-for="tag in record.tags"
            :key="tag"
            color="blue"
            closable
            style="margin-right: 4px"
            @close.prevent.stop="$emit('remove-tag', record, tag)"
          >
            {{ tag }}
          </a-tag>
          <span v-if="record.tags.length === 0" class="text-muted">—</span>
        </template>
        <template v-else-if="column.key === 'size'">
          {{ formatSize(record.size) }}
        </template>
        <template v-else-if="column.key === 'status'">
          <a-tag :color="statusColor(record.status)">
            <template v-if="record.status === 'parsing'" #icon>
              <SyncOutlined spin />
            </template>
            <template v-else-if="record.status === 'success'" #icon>
              <CheckCircleOutlined />
            </template>
            <template v-else-if="record.status === 'failed'" #icon>
              <CloseCircleOutlined />
            </template>
            {{ statusText(record.status) }}
          </a-tag>
        </template>
        <template v-else-if="column.key === 'createdAt'">
          {{ formatDate(record.createdAt) }}
        </template>
        <template v-else-if="column.key === 'updatedAt'">
          {{ formatDate(record.updatedAt) }}
        </template>
        <template v-else-if="column.key === 'action'">
          <a-dropdown :trigger="['hover']">
            <a-button
              type="text"
              size="small"
              aria-label="文档操作"
              @click.stop
            >
              <template #icon><SmallDashOutlined /></template>
            </a-button>
            <template #overlay>
              <a-menu @click="({ key, domEvent }) => handleAction(key, record, domEvent)">
                <a-menu-item key="add-tag">新增标签</a-menu-item>
                <a-menu-divider />
                <a-menu-item key="delete" danger>
                  删除
                </a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
        </template>
      </template>

      <template #emptyText>
        <a-empty description="当前目录暂无文档，点击「新建知识」开始上传" />
      </template>
    </a-table>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { Modal } from 'ant-design-vue'
import {
  PlusOutlined,
  DeleteOutlined,
  SyncOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  SmallDashOutlined
} from '@ant-design/icons-vue'
import { formatFileSize } from '../../utils/file.js'

const props = defineProps({
  folderId: {
    type: String,
    default: null
  },
  folderName: {
    type: String,
    default: ''
  },
  documents: {
    type: Array,
    required: true
  },
  selectedRowKeys: {
    type: Array,
    required: true
  }
})

const emit = defineEmits([
  'select-change',
  'row-click',
  'create',
  'batch-delete',
  'delete',
  'add-tag',
  'remove-tag'
])

const columns = [
  { title: '名称', dataIndex: 'name', key: 'name', ellipsis: true },
  { title: '标签', dataIndex: 'tags', key: 'tags', width: 200 },
  { title: '大小', dataIndex: 'size', key: 'size', width: 100 },
  { title: '状态', dataIndex: 'status', key: 'status', width: 120 },
  { title: '创建时间', dataIndex: 'createdAt', key: 'createdAt', width: 160 },
  { title: '更新时间', dataIndex: 'updatedAt', key: 'updatedAt', width: 160 },
  { title: '操作', key: 'action', width: 80, fixed: 'right' }
]

const folderTitle = computed(() => {
  return props.folderName ? `${props.folderName} 的文档` : '请先选择目录'
})

const rowSelection = computed(() => ({
  selectedRowKeys: props.selectedRowKeys,
  onChange: (keys) => emit('select-change', keys)
}))

const customRow = (record) => ({
  onClick: () => emit('row-click', record),
  style: { cursor: 'pointer' }
})

function handleAction(key, record, domEvent) {
  domEvent.stopPropagation()
  if (key === 'delete') {
    Modal.confirm({
      title: '确定要删除这篇文档吗？',
      okText: '确认',
      cancelText: '取消',
      okButtonProps: { danger: true },
      onOk: () => emit('delete', record)
    })
  } else if (key === 'add-tag') {
    emit(key, record)
  }
}

function formatSize(size) {
  return formatFileSize(size)
}

function statusColor(status) {
  if (status === 'parsing') return 'processing'
  if (status === 'success') return 'success'
  if (status === 'failed') return 'error'
  return 'default'
}

function statusText(status) {
  if (status === 'parsing') return '解析中'
  if (status === 'success') return '解析完成'
  if (status === 'failed') return '解析失败'
  return status
}

function formatDate(ts) {
  if (!ts) return '—'
  const d = new Date(ts)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`
}
</script>

<style scoped>
.document-table {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.document-table-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0 16px;
  border-bottom: 1px solid #f0f0f0;
  margin-bottom: 16px;
}

.toolbar-actions {
  display: flex;
  gap: 8px;
}

.doc-name {
  color: #1890ff;
  font-weight: 500;
}

.doc-name:hover {
  text-decoration: underline;
}

.text-muted {
  color: #bfbfbf;
}
</style>
