<template>
  <div class="chat-management">
    <div class="chat-sidebar">
      <ChatList
        :chats="chatStore.state.chats"
        :current-chat-id="chatStore.state.currentChatId"
        @create="handleCreateChat"
        @select="handleSelectChat"
        @delete="handleDeleteChat"
        @update-title="handleUpdateTitle"
      />
    </div>
    
    <div class="chat-main">
      <ChatArea
        :current-chat="currentChat"
        :models="modelStore.state.models"
        :prompts="promptStore.state.prompts"
        :is-loading="isLoading"
        @send-message="handleSendMessage"
        @model-change="handleModelChange"
        @prompt-change="handlePromptChange"
        @create-chat="handleCreateChat"
      />
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { message } from 'ant-design-vue'
import { useChatStore } from '../stores/chat.js'
import { useModelStore } from '../stores/model.js'
import { usePromptStore } from '../stores/prompt.js'
import ChatList from '../components/chat/ChatList.vue'
import ChatArea from '../components/chat/ChatArea.vue'

const chatStore = useChatStore()
const modelStore = useModelStore()
const promptStore = usePromptStore()
const isLoading = ref(false)

const currentChat = computed(() => chatStore.getCurrentChat())

function handleCreateChat() {
  const newChat = chatStore.createChat()
  message.success('新会话已创建')
}

function handleSelectChat(chatId) {
  chatStore.selectChat(chatId)
}

function handleDeleteChat(chatId) {
  chatStore.deleteChat(chatId)
}

function handleUpdateTitle(chatId, title) {
  chatStore.updateChatTitle(chatId, title)
  message.success('会话标题已更新')
}

function handleSendMessage(data) {
  const { content, modelId, promptId } = data
  const chatId = chatStore.state.currentChatId
  
  if (!chatId) {
    message.warning('请先选择或创建一个会话')
    return
  }
  
  // 添加用户消息
  chatStore.addMessage(chatId, {
    role: 'user',
    content
  })
  
  // 设置模型和提示词
  if (modelId) {
    const model = modelStore.state.models.find(m => m.id === modelId)
    if (model) {
      chatStore.setChatModel(chatId, model)
    }
  }
  
  if (promptId) {
    const prompt = promptStore.state.prompts.find(p => p.id === promptId)
    if (prompt) {
      chatStore.setChatPrompt(chatId, prompt)
    }
  }
  
  // 模拟 AI 回复
  simulateAIResponse(chatId, content)
}

function simulateAIResponse(chatId, userMessage) {
  isLoading.value = true
  
  // 模拟 AI 回复延迟
  setTimeout(() => {
    const responses = [
      '这是一个很好的问题！让我来为您解答...',
      '感谢您的提问。根据我的理解，...',
      '您好！关于您提到的问题，我认为...',
      '这个话题很有趣。从我的角度来看...'
    ]
    
    const randomResponse = responses[Math.floor(Math.random() * responses.length)]
    
    chatStore.addMessage(chatId, {
      role: 'assistant',
      content: `${randomResponse}\n\n这是模拟的 AI 回复。在实际应用中，这里会连接到真实的 AI 模型 API 进行对话。`
    })
    
    isLoading.value = false
  }, 1000)
}

function handleModelChange(model) {
  const chatId = chatStore.state.currentChatId
  if (chatId && model) {
    chatStore.setChatModel(chatId, model)
  }
}

function handlePromptChange(prompt) {
  const chatId = chatStore.state.currentChatId
  if (chatId) {
    chatStore.setChatPrompt(chatId, prompt)
  }
}
</script>

<style scoped>
.chat-management {
  display: flex;
  height: calc(100vh - 160px);
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
}

.chat-sidebar {
  width: 320px;
  border-right: 1px solid #f0f0f0;
  background: #fafafa;
}

.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
</style>
