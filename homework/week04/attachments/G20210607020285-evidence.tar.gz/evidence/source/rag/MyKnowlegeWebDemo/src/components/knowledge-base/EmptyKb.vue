<template>
  <div style="text-align: center; padding: 80px 0;">
    <a-empty description="还没有知识库">
      <template #description>
        <p>还没有知识库，立即创建第一个</p>
      </template>
      <a-button type="primary" @click="$emit('create')">创建第一个知识库</a-button>
    </a-empty>
  </div>
</template>

<script setup>
defineEmits(['create'])
</script>
