/**
 * 文件相关工具函数
 * - formatFileSize：字节数 → KB/MB/GB
 * - getExtension：提取扩展名（小写）
 * - getRendererType：扩展名 → 渲染类型
 */

const SIZE_UNITS = ['B', 'KB', 'MB', 'GB', 'TB']

/**
 * 字节数格式化为可读大小
 * @param {number} bytes
 * @returns {string}
 */
export function formatFileSize(bytes) {
  if (bytes === null || bytes === undefined || Number.isNaN(bytes)) return '0 B'
  if (bytes < 0) return '0 B'
  if (bytes === 0) return '0 B'
  let value = bytes
  let unitIndex = 0
  while (value >= 1024 && unitIndex < SIZE_UNITS.length - 1) {
    value /= 1024
    unitIndex++
  }
  const fixed = value >= 10 || unitIndex === 0 ? Math.round(value) : Number(value.toFixed(2))
  return `${fixed} ${SIZE_UNITS[unitIndex]}`
}

/**
 * 提取文件扩展名（小写）
 * @param {string} filename
 * @returns {string} 不含点的小写扩展名，无扩展名时返回空字符串
 */
export function getExtension(filename) {
  if (!filename || typeof filename !== 'string') return ''
  const lastDot = filename.lastIndexOf('.')
  if (lastDot <= 0 || lastDot === filename.length - 1) return ''
  return filename.slice(lastDot + 1).toLowerCase()
}

/**
 * 根据扩展名返回渲染类型
 * @param {string} extension 小写扩展名
 * @returns {'office-docx' | 'office-excel' | 'office-pptx' | 'office-pdf' | 'markdown' | 'text'}
 */
export function getRendererType(extension) {
  const ext = (extension || '').toLowerCase()
  if (ext === 'doc' || ext === 'docx') return 'office-docx'
  if (ext === 'xls' || ext === 'xlsx') return 'office-excel'
  if (ext === 'ppt' || ext === 'pptx') return 'office-pptx'
  if (ext === 'pdf') return 'office-pdf'
  if (ext === 'md' || ext === 'markdown') return 'markdown'
  return 'text'
}
