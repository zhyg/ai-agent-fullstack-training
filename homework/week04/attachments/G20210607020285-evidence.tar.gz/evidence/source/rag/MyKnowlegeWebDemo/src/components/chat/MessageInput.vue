<template>
  <div class="message-input-container">
    <div class="input-toolbar">
      <div class="toolbar-left">
        <a-select
          v-model:value="selectedModel"
          placeholder="选择模型"
          style="width: 200px"
          @change="handleModelChange"
        >
          <a-select-option v-for="model in models" :key="model.id" :value="model.id">
            <div style="display: flex; align-items: center;">
              <ApiOutlined style="margin-right: 8px; color: #1890ff;" />
              {{ model.name }}
            </div>
          </a-select-option>
        </a-select>
        
        <a-select
          v-model:value="selectedPrompt"
          placeholder="选择提示词"
          style="width: 200px; margin-left: 8px;"
          allowClear
          @change="handlePromptChange"
        >
          <a-select-option v-for="prompt in prompts" :key="prompt.id" :value="prompt.id">
            <div style="display: flex; align-items: center;">
              <FileTextOutlined style="margin-right: 8px; color: #52c41a;" />
              {{ prompt.name }}
              <span v-if="prompt.version" style="color: #8c8c8c; font-size: 12px; margin-left: 8px;">
                v{{ prompt.version.replace(/^v+/i, '') }}
              </span>
            </div>
          </a-select-option>
        </a-select>
      </div>
    </div>
    
    <div class="input-area">
      <a-textarea
        v-model:value="inputMessage"
        :placeholder="placeholder"
        :auto-size="{ minRows: 3, maxRows: 6 }"
        @pressEnter="handleSend"
      />
      <a-button
        type="primary"
        :disabled="!inputMessage.trim() || !selectedModel"
        @click="handleSend"
        class="send-btn"
      >
        <template #icon><SendOutlined /></template>
        发送
      </a-button>
    </div>
    
    <div v-if="!selectedModel" class="input-tip">
      <AlertOutlined style="margin-right: 4px;" />
      请先选择一个模型
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ApiOutlined, FileTextOutlined, SendOutlined, AlertOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'

const props = defineProps({
  models: {
    type: Array,
    default: () => []
  },
  prompts: {
    type: Array,
    default: () => []
  },
  currentModel: {
    type: Object,
    default: null
  },
  currentPrompt: {
    type: Object,
    default: null
  }
})

const emit = defineEmits(['send', 'model-change', 'prompt-change'])

const inputMessage = ref('')
const selectedModel = ref(props.currentModel?.id || null)
const selectedPrompt = ref(props.currentPrompt?.id || null)

const placeholder = computed(() => {
  if (!selectedModel.value) {
    return '请先选择模型...'
  }
  return '输入消息，按 Enter 发送...'
})

function handleSend(e) {
  // Shift+Enter 换行
  if (e && e.shiftKey) {
    return
  }
  
  // 阻止默认换行
  if (e) {
    e.preventDefault()
  }
  
  if (!inputMessage.value.trim()) {
    message.warning('请输入消息内容')
    return
  }
  
  if (!selectedModel.value) {
    message.warning('请先选择模型')
    return
  }
  
  emit('send', {
    content: inputMessage.value.trim(),
    modelId: selectedModel.value,
    promptId: selectedPrompt.value
  })
  
  inputMessage.value = ''
}

function handleModelChange(modelId) {
  const model = props.models.find(m => m.id === modelId)
  emit('model-change', model)
}

function handlePromptChange(promptId) {
  const prompt = promptId ? props.prompts.find(p => p.id === promptId) : null
  emit('prompt-change', prompt)
}

// 暴露方法供父组件调用
function setModel(modelId) {
  selectedModel.value = modelId
}

function setPrompt(promptId) {
  selectedPrompt.value = promptId
}

defineExpose({
  setModel,
  setPrompt
})
</script>

<style scoped>
.message-input-container {
  border-top: 1px solid #f0f0f0;
  background: #fff;
  padding: 16px;
}

.input-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.toolbar-left {
  display: flex;
  align-items: center;
}

.input-area {
  position: relative;
}

.input-area :deep(.ant-input) {
  resize: none;
  padding-right: 80px;
  border-radius: 8px;
}

.send-btn {
  position: absolute;
  right: 8px;
  bottom: 8px;
  border-radius: 6px;
}

.input-tip {
  margin-top: 8px;
  font-size: 12px;
  color: #faad14;
  display: flex;
  align-items: center;
}

:deep(.ant-select-selector) {
  border-radius: 6px !important;
}

:deep(.ant-select-selection-item) {
  display: flex;
  align-items: center;
}
</style>
