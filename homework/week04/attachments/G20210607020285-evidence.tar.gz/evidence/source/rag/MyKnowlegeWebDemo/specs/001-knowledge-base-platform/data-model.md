# Data Model: 知识库平台原型

**Feature**: 001-knowledge-base-platform
**Date**: 2026-10-23

## 实体定义

### Model（模型）

代表一个 AI 模型服务的连接配置。

| 字段 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String | 是 | 唯一标识，自动生成（时间戳+随机串） |
| name | String | 是 | 模型名称（友好显示名） |
| url | String | 是 | 模型服务地址 |
| key | String | 是 | API 访问密钥 |
| createdAt | Number | 是 | 创建时间戳（Date.now()） |
| updatedAt | Number | 是 | 更新时间戳（Date.now()） |

**验证规则**:
- `name`: 非空字符串
- `url`: 非空字符串
- `key`: 非空字符串

**关系**:
- 一个模型可以被多个知识库引用（一对多）
- 模型删除时不检查引用关系（原型简化策略）

### KnowledgeBase（知识库）

代表一个知识管理单元，关联四个不同类型的模型。

| 字段 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String | 是 | 唯一标识，自动生成（时间戳+随机串） |
| name | String | 是 | 知识库名称 |
| description | String | 否 | 知识库描述 |
| llmModelId | String | 是 | 关联的 LLM 模型 ID |
| embeddingModelId | String | 是 | 关联的 Embedding 模型 ID |
| imageModelId | String | 是 | 关联的图片识别模型 ID |
| rerankModelId | String | 是 | 关联的 Rerank 模型 ID |
| createdAt | Number | 是 | 创建时间戳（Date.now()） |
| updatedAt | Number | 是 | 更新时间戳（Date.now()） |

**验证规则**:
- `name`: 非空字符串
- `llmModelId`: 非空，必须是已存在的模型 ID
- `embeddingModelId`: 非空，必须是已存在的模型 ID
- `imageModelId`: 非空，必须是已存在的模型 ID
- `rerankModelId`: 非空，必须是已存在的模型 ID

**关系**:
- 每个知识库引用四个模型（多对一）
- 四个模型字段可以指向同一个模型

## 存储结构

### localStorage Key 设计

| Key | 值类型 | 说明 |
| --- | ------ | ---- |
| `kb_models` | JSON Array | 所有模型的数组 |
| `kb_knowledge_bases` | JSON Array | 所有知识库的数组 |

### 数据存储示例

**Models**:
```json
[
  {
    "id": "1698048000000abc123",
    "name": "GPT-4",
    "url": "https://api.openai.com/v1/chat/completions",
    "key": "[REDACTED_API_TOKEN]",
    "createdAt": 1698048000000,
    "updatedAt": 1698048000000
  }
]
```

**KnowledgeBases**:
```json
[
  {
    "id": "1698048000000def456",
    "name": "产品文档库",
    "description": "存储产品相关文档和知识",
    "llmModelId": "1698048000000abc123",
    "embeddingModelId": "1698048000000abc123",
    "imageModelId": "1698048000000abc123",
    "rerankModelId": "1698048000000abc123",
    "createdAt": 1698048000000,
    "updatedAt": 1698048000000
  }
]
```

## 数据操作封装

### useModelStore（stores/model.js）

| 方法 | 参数 | 返回值 | 说明 |
| ---- | ---- | ------ | ---- |
| `getModels()` | 无 | `Model[]` | 获取所有模型 |
| `getModelById(id)` | `id: String` | `Model \| null` | 根据 ID 获取单个模型 |
| `createModel(data)` | `data: {name, url, key}` | `Model` | 创建新模型 |
| `updateModel(id, data)` | `id: String, data: {name?, url?, key?}` | `Model` | 更新模型 |
| `deleteModel(id)` | `id: String` | `void` | 删除模型 |

### useKbStore（stores/knowledgeBase.js）

| 方法 | 参数 | 返回值 | 说明 |
| ---- | ---- | ------ | ---- |
| `getKnowledgeBases()` | 无 | `KnowledgeBase[]` | 获取所有知识库 |
| `getKbById(id)` | `id: String` | `KnowledgeBase \| null` | 根据 ID 获取单个知识库 |
| `createKb(data)` | `data: {name, description?, llmModelId, embeddingModelId, imageModelId, rerankModelId}` | `KnowledgeBase` | 创建新知识库 |
| `updateKb(id, data)` | `id: String, data: Partial<KnowledgeBase>` | `KnowledgeBase` | 更新知识库 |
| `deleteKb(id)` | `id: String` | `void` | 删除知识库 |

## 状态转换

本原型中的数据实体为简单 CRUD 操作，无复杂状态机：

- **Model**: 创建 → 可编辑 → 可删除
- **KnowledgeBase**: 创建 → 可编辑 → 可删除

无软删除、审核流程、版本控制等复杂状态管理。
