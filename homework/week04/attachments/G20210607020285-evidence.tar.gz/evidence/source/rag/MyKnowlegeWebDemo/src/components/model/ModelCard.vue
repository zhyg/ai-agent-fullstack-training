<template>
  <div class="model-card">
    <div class="card-header">
      <div class="card-icon">
        <component :is="categoryIcon" />
      </div>
      <div class="card-title-area">
        <span class="card-title">{{ model.displayName || model.name }}</span>
        <span class="card-metadata">
          {{ model.provider || 'Open AI' }}
        </span>
        <a-tooltip :title="model.url">
          <span class="card-url">{{ model.url }}</span>
        </a-tooltip>
      </div>
      <div class="card-actions">
        <a-button type="text" size="small" @click="$emit('edit', model)">
          <template #icon><EditOutlined /></template>
          设置
        </a-button>
        <a-button type="text" size="small" danger @click="$emit('delete', model)">
          <template #icon><DeleteOutlined /></template>
          删除
        </a-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { CommentOutlined, DatabaseOutlined, SortAscendingOutlined, PictureOutlined, AudioOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { getModelCategory } from '../../utils/model.js'

const props = defineProps({
  model: {
    type: Object,
    required: true
  }
})

defineEmits(['edit', 'delete'])

const categoryIcon = computed(() => ({
  chat: CommentOutlined,
  embedding: DatabaseOutlined,
  rerank: SortAscendingOutlined,
  vision: PictureOutlined,
  speech: AudioOutlined
})[getModelCategory(props.model)])
</script>

<style scoped>
.model-card {
  background: #fff;
  border: 1px solid #e3e3e3;
  border-radius: 16px;
  padding: 24px;
  min-height: 142px;
  display: flex;
  align-items: center;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
  cursor: default;
}

.model-card:hover {
  border-color: #b7d9c6;
  box-shadow: 0 4px 14px rgba(30, 70, 50, 0.04);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 16px;
  width: 100%;
  flex-wrap: wrap;
}

.card-icon {
  width: 56px;
  height: 56px;
  background: #edf0fc;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #1457c7;
  font-size: 26px;
  flex-shrink: 0;
}

.card-title-area {
  flex: 1;
  min-width: 0;
  flex-basis: 140px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.card-title {
  font-size: 20px;
  font-weight: 600;
  color: #1f1f1f;
  line-height: 1.4;
  overflow-wrap: anywhere;
}

.card-metadata {
  color: #777;
  font-size: 15px;
}

.card-url {
  font-size: 13px;
  color: #8c8c8c;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.4;
}

.card-actions {
  display: flex;
  gap: 4px;
  flex-shrink: 0;
}

.card-actions .ant-btn {
  font-size: 13px;
  border-radius: 6px;
}

.card-actions .ant-btn:hover {
  background: #f5f5f5;
}

.card-actions .ant-btn-dangerous:hover {
  background: #fff1f0;
}
</style>
