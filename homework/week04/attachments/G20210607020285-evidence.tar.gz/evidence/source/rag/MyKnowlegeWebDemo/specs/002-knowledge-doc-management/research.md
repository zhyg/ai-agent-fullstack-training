# Research: 知识库中知识的管理

**Feature**: 002-knowledge-doc-management
**Date**: 2026-10-24

## 研究主题

### 1. 目录树数据结构设计

**Decision**: 采用扁平化存储（每个目录记录包含 `parentId`），在渲染时通过递归计算生成嵌套树结构。

**Rationale**:
- 扁平结构便于拖拽操作时仅修改 `parentId` 和 `order` 字段即可完成移动/排序，无需深层递归
- 与 001 号特性的数据模型风格一致（Model / KnowledgeBase 均为扁平数组）
- 便于 localStorage 序列化，避免深层嵌套导致的序列化复杂性
- 渲染时通过 `buildTree(flatFolders, parentId)` 递归函数生成 a-tree 需要的 `treeData` 结构

**Alternatives considered**:
- **嵌套结构存储**：每个目录包含 `children` 数组。优点是渲染直观，缺点是拖拽/排序时需要递归查找与更新，容易出错
- **路径字符串（如 `/a/b/c`）**：便于检索但不便于拖拽修改父目录，放弃

### 2. Ant Design Vue 的 a-tree 拖拽 API

**Decision**: 使用 a-tree 组件的 `draggable` 属性启用拖拽，监听 `@drop` 事件获取 `dropPosition`（-1 上方 / 0 内部 / 1 下方）和 `dropToGap`（是否放入间隙），结合 `allowDrop` 回调阻止无效操作。

**Rationale**:
- a-tree 的 `draggable` 原生支持同级排序和嵌套操作，无需引入第三方拖拽库
- `dropPosition=0 && !dropToGap` 表示放入目标节点内部 → 修改 `parentId`
- `dropPosition=-1/1` 表示插入间隙 → 保持原 `parentId`，仅调整 `order`
- `allowDrop` 回调可阻止"拖拽到自身或子孙目录"等非法操作

**Alternatives considered**:
- **vuedraggable / sortablejs**：对树形嵌套支持较弱，且增加依赖
- **手写拖拽**：开发成本高、体验难保证，放弃

### 3. 目录拖拽冲突处理（同名目录）

**Decision**: 拖拽落点若目标父目录下已存在同名子目录，系统在 store 层自动将拖入目录重命名为"原名(1)"（必要时递增到 "(2)"、"(3)"），并通过 ant-design-vue 的 `message.info` 提示用户。

**Rationale**:
- 对应 spec Clarifications 中 Q4 的答案
- 在 store 方法 `moveFolder(id, newParentId, newIndex)` 内部处理冲突逻辑，保持组件层纯粹
- 递增后缀算法简单可靠，满足原型需求

**Alternatives considered**:
- 拒绝拖拽并报错 → 用户体验差
- 弹出确认框 → 中断拖拽流程，违反直觉
- 合并同名目录 → 状态复杂且容易丢数据

### 4. a-upload 组件与 500MB 大小校验

**Decision**: 使用 a-upload 组件的 `beforeUpload` 钩子在上传前校验文件大小（≤ 500MB）和文件类型，超大文件直接 reject 并通过 `message.error` 提示。

**Rationale**:
- `beforeUpload` 可同步返回 `false` 阻止上传，无需发起网络请求
- 对于原型，上传动作实际为"状态模拟"，`beforeUpload` 返回 `false` 后手动将文件信息注入 store 即可
- 通过 `accept="*/*"` 或不限定 accept 支持任意文件类型；额外支持 `.zip`、`.tar.gz`

**Alternatives considered**:
- 自定义上传按钮 + `input[type=file]` → 无法复用 ant-design 上传体验，放弃
- 使用 `a-upload-dragger` 替代 `a-upload` → 可作为 UX 增强选项，两者并存

### 5. 文件数据存储策略（元数据 vs 文件内容）

**Decision**: 采用"元数据 + Blob 引用"分层存储：
- 元数据（名称、大小、状态、标签、创建时间等）存入 localStorage 的 `kb_documents` 数组
- 文件原始 Blob 存入 IndexedDB 的 `kb_files` object store，以 `documentId` 为 key
- 解析后的文本内容存入 IndexedDB 的 `kb_parsed_contents` object store，以 `documentId` 为 key

**Rationale**:
- localStorage 上限约 5MB，无法承载实际文件数据，即使 500MB 文件上限的元数据也足够
- IndexedDB 容量充足（一般 ≥ 50MB），适合存储文件 Blob 与解析文本
- 分层设计使元数据查询快速（列表展示无需读取文件），文件内容按需加载
- 使用 `useStorage.js` 扩展出 IndexedDB 封装（`saveBlob` / `getBlob` / `deleteBlob`）

**Alternatives considered**:
- 全部存 IndexedDB → 元数据查询稍慢但可行；为保持与 001 一致，优先 localStorage
- 全部存 localStorage → 5MB 上限严重受限，无法支持原型的多文档场景
- 纯内存（不持久化） → 刷新丢失，不符合项目持久化约定

### 6. 状态模拟（解析中 → 解析完成/失败）

**Decision**: 上传成功后立即创建 Document 记录（状态=`parsing`），通过 `setTimeout` 模拟 2~5 秒后随机转为 `success` 或 `failed`（80% 成功）。

**Rationale**:
- 纯前端原型无真实解析能力，状态机需模拟以便验收 SC-003 等可度量结果
- 2~5 秒区间足以让用户感知"解析中"到"完成"的状态切换
- 80% 成功率使"解析失败"边界情况可被自然触发

**Alternatives considered**:
- 固定 3 秒全部成功 → 无法覆盖"解析失败"场景
- 100% 失败 → 主流程无法验收
- 用户手动切换状态 → 违背"自动解析"的 PRD 描述

### 7. 文档类型渲染策略

**Decision**: 按文件扩展名分类渲染：
- `.doc/.docx/.xls/.xlsx/.ppt/.pptx/.pdf` → `vue-office` 组件（`@vue-office/docx`、`@vue-office/excel`、`@vue-office/pptx`、`@vue-office/pdf`）
- `.md/.markdown` → `@kangc/v-md-editor`（只读预览模式）
- 其他 → `<pre>` 文本展示或"暂不支持预览"占位提示

**Rationale**:
- vue-office 是 Vue 3 生态中主流 Office 渲染方案，各子包独立按需安装
- v-md-editor 提供完善的 Markdown 预览组件，支持主题切换
- 扩展名判断简单可靠，原型无需引入 MIME 嗅探

**Alternatives considered**:
- 使用 pdf.js 直接渲染 PDF → vue-office/pdf 内部已封装，重复劳动
- 使用 marked/markdown-it 手写渲染 → 缺乏样式与交互，v-md-editor 更完整
- MIME 类型嗅探 → 原型无需此复杂度

### 8. 状态管理模式选择

**Decision**: 沿用 001 号特性已有的"Vue 3 `reactive()` composable + localStorage"模式，新增 `useFolderStore`、`useDocumentStore` 两个 store，不引入 Pinia。

**Rationale**:
- 001 号特性已确立此模式（`useKbStore` / `useModelStore`），保持一致性
- composable 模式通过 `reactive()` 提供响应式，配合 localStorage 持久化，足够原型使用
- 引入 Pinia 会打破现有代码风格，收益有限

**Alternatives considered**:
- 引入 Pinia → 增加依赖、改变现有 store 风格，放弃
- 纯组件内状态 → 不利于跨组件共享（如目录选中影响文档列表）

### 9. 目录/文档 ID 生成

**Decision**: 沿用 001 号特性的 `generateId()`（`Date.now().toString(36) + Math.random().toString(36).substr(2, 9)`）。

**Rationale**: 一致性优先，无需引入新依赖。

**Alternatives considered**:
- `crypto.randomUUID()` → 更标准但对原型无必要
- `uuid` 库 → 增加依赖

### 10. 路由与页面结构

**Decision**: 在 vue-router 中新增路由 `/knowledge-base/:kbId`，渲染 `KnowledgeManagement.vue` 页面；从知识库卡片点击进入时通过 `router.push` 跳转。

**Rationale**:
- 参数化路由符合"每个知识库有独立的目录树与文档列表"的设计
- 保留 `/knowledge-base` 作为列表页，`/knowledge-base/:kbId` 作为详情页，URL 结构清晰

**Alternatives considered**:
- 单页面切换（v-if）→ URL 无法表达当前知识库，不利于分享与刷新
- 嵌套路由 → 复杂度过高，参数化单一页面即可满足

### 11. 新增依赖清单

| 依赖包 | 用途 | 必要性 |
| ------ | ---- | ------ |
| `@vue-office/docx` | Word 文档渲染 | 是 |
| `@vue-office/excel` | Excel 表格渲染 | 是 |
| `@vue-office/pptx` | PPT 演示文稿渲染 | 是 |
| `@vue-office/pdf` | PDF 渲染 | 是 |
| `@kangc/v-md-editor` | Markdown 预览 | 是 |
| `dexie` (可选) | IndexedDB 封装库 | 可选（也可手写原生 API 封装） |

**Rationale**: vue-office 子包独立安装按需加载，避免全量引入；v-md-editor 是 PRD 明确指定。dexie 可作为 IndexedDB 操作的便利层，若团队倾向最小依赖则手写封装。

**Alternatives considered**:
- 手写 IndexedDB 封装 → 无依赖但代码量增加
- localforage → 另一选项但 dexie 与 Vue 生态更契合
