import { reactive } from 'vue'
import { getItem, setItem, generateId } from '../composables/useStorage.js'

const PROMPTS_KEY = 'prompts'

const state = reactive({
  prompts: getItem(PROMPTS_KEY) || []
})

function persist() {
  setItem(PROMPTS_KEY, state.prompts)
}

export function usePromptStore() {
  function getPromptById(id) {
    return state.prompts.find(p => p.id === id) || null
  }

  function createPrompt(data) {
    const now = Date.now()
    const prompt = {
      id: generateId(),
      name: data.name,
      version: data.version || '1.0.0',
      description: data.description || '',
      content: data.content || '',
      createdAt: now,
      updatedAt: now
    }
    state.prompts.push(prompt)
    persist()
    return prompt
  }

  function updatePrompt(id, data) {
    const index = state.prompts.findIndex(p => p.id === id)
    if (index === -1) return null
    state.prompts[index] = {
      ...state.prompts[index],
      ...data,
      // 版本不可修改，保持原值
      version: state.prompts[index].version,
      updatedAt: Date.now()
    }
    persist()
    return state.prompts[index]
  }

  function deletePrompt(id) {
    const index = state.prompts.findIndex(p => p.id === id)
    if (index !== -1) {
      state.prompts.splice(index, 1)
      persist()
    }
  }

  return {
    state,
    getPromptById,
    createPrompt,
    updatePrompt,
    deletePrompt
  }
}
