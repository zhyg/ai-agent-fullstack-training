import { reactive } from 'vue'
import { getItem, setItem, generateId } from '../composables/useStorage.js'

const KB_KEY = 'knowledge_bases'

const state = reactive({
  knowledgeBases: getItem(KB_KEY) || []
})

function persist() {
  setItem(KB_KEY, state.knowledgeBases)
}

export function useKbStore() {
  function getKbById(id) {
    return state.knowledgeBases.find(kb => kb.id === id) || null
  }

  function createKb(data) {
    const now = Date.now()
    const kb = {
      id: generateId(),
      name: data.name,
      description: data.description || '',
      llmModelId: data.llmModelId,
      embeddingModelId: data.embeddingModelId,
      imageModelId: data.imageModelId,
      rerankModelId: data.rerankModelId,
      createdAt: now,
      updatedAt: now
    }
    state.knowledgeBases.push(kb)
    persist()
    return kb
  }

  function updateKb(id, data) {
    const index = state.knowledgeBases.findIndex(kb => kb.id === id)
    if (index === -1) return null
    state.knowledgeBases[index] = {
      ...state.knowledgeBases[index],
      ...data,
      updatedAt: Date.now()
    }
    persist()
    return state.knowledgeBases[index]
  }

  function deleteKb(id) {
    const index = state.knowledgeBases.findIndex(kb => kb.id === id)
    if (index !== -1) {
      state.knowledgeBases.splice(index, 1)
      persist()
    }
  }

  return {
    state,
    getKbById,
    createKb,
    updateKb,
    deleteKb
  }
}
