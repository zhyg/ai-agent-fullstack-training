# Quickstart: 知识库中知识的管理

**Feature**: 002-knowledge-doc-management
**Date**: 2026-10-24

## 概述

本文档为"知识库中知识的管理"特性的端到端验收指南，提供可运行的验证场景，用于证明功能按 spec.md 工作。实现细节请参考 `data-model.md` 与 `contracts/ui-contracts.md`。

## 先决条件

1. 完成 001 号特性（`specs/001-knowledge-base-platform`）的部署
2. 已安装新增依赖：`@vue-office/docx`、`@vue-office/excel`、`@vue-office/pptx`、`@vue-office/pdf`、`@kangc/v-md-editor`
3. 开发服务器启动：`npm run dev`
4. 浏览器可访问 `http://localhost:5173`
5. 至少创建一个模型（001 号特性）
6. 至少创建一个知识库并关联模型（001 号特性）

## 验证场景

### V1: 进入知识管理页面

**前提**: 已创建至少一个知识库

**步骤**:
1. 访问 `/knowledge-base`
2. 点击某个知识库卡片

**预期结果**:
- 浏览器跳转到 `/knowledge-base/:kbId`
- 页面分为左右两栏：左侧为目录树（初始为空），右侧为文档表格（空状态）
- 左侧存在"新建根目录"引导按钮

**涉及组件**: `KbCard.vue`、`KnowledgeManagement.vue`、`FolderTree.vue`、`DocumentTable.vue`

---

### V2: 创建根目录

**前提**: 处于知识管理页面

**步骤**:
1. 点击"新建根目录"按钮
2. 在弹出的模态框中输入"产品文档"
3. 点击"确定"

**预期结果**:
- 模态框关闭
- 左侧目录树出现"产品文档"节点
- 刷新页面后目录仍然存在（localStorage 持久化）

**涉及组件**: `FolderTree.vue`、`FolderActionModal.vue`、`useFolderStore.createFolder`

---

### V3: 创建子目录与嵌套

**前提**: 已有根目录"产品文档"

**步骤**:
1. 鼠标悬浮"产品文档"节点，点击出现的"..."按钮
2. 在下拉菜单中选择"新建目录"
3. 在弹出的模态框中输入"PRD"并确定
4. 重复以上步骤在"PRD"下再创建"V1"子目录

**预期结果**:
- 目录树显示三层嵌套结构：产品文档 → PRD → V1
- 展开/折叠正常
- 刷新后结构保留

**涉及组件**: `FolderTree.vue`、`FolderActionModal.vue`

---

### V4: 重命名目录

**前提**: 已有目录"V1"

**步骤**:
1. 鼠标悬浮"V1"节点，点击"..."按钮
2. 选择"修改目录名称"
3. 在模态框中输入"V1.0"并确定

**预期结果**:
- 目录树中节点名称立即更新为"V1.0"
- 刷新后保留新名称

**涉及组件**: `FolderTree.vue`、`FolderActionModal.vue`、`useFolderStore.renameFolder`

---

### V5: 拖拽调整目录顺序与嵌套

**前提**: 在"产品文档"下有两个平级子目录"PRD"和"设计"

**步骤**:
1. 拖拽"设计"节点到"PRD"上方释放
2. 观察顺序变化
3. 拖拽"PRD"节点到"设计"节点上释放（覆盖）

**预期结果**:
- 步骤 1 后"设计"排在"PRD"之前
- 步骤 3 后"PRD"成为"设计"的子目录
- 刷新后结构保留

**涉及组件**: `FolderTree.vue`（a-tree draggable）、`useFolderStore.moveFolder`、`useFolderStore.reorderFolder`

---

### V6: 拖拽同名目录冲突处理

**前提**: "产品文档"下已存在"PRD"目录

**步骤**:
1. 在"设计"目录下也创建一个名为"PRD"的子目录
2. 将"设计/PRD"拖拽到"产品文档"下

**预期结果**:
- 原"产品文档/PRD"保持不变
- 被拖入的目录被自动重命名为"PRD(1)"
- 页面弹出 Toast 提示告知用户重命名结果

**涉及组件**: `FolderTree.vue`、`useFolderStore.moveFolder`（冲突处理）、`resolveConflictName`

---

### V7: 删除目录（级联）

**前提**: "产品文档"下存在"PRD"子目录，且"PRD"下有若干文档

**步骤**:
1. 鼠标悬浮"PRD"，点击"..." → "删除目录"
2. 在弹出的确认模态框中点击"确定"

**预期结果**:
- "PRD"节点从树中消失
- "PRD"下的文档一并被删除
- 刷新后保持删除状态

**涉及组件**: `FolderActionModal.vue`、`useFolderStore.deleteFolder`、`useDocumentStore.batchDeleteDocuments`

---

### V8: 上传单文件

**前提**: 已选中某目录（如"V1.0"）

**步骤**:
1. 点击"新建知识"按钮
2. 在弹出的对话框中选择一个本地 PDF 文件（< 500MB）
3. 点击确定

**预期结果**:
- 对话框关闭
- 右侧表格立即出现新文档行，状态为"解析中"（蓝色图标）
- 2~5 秒后状态自动转为"解析完成"（绿色图标，80% 概率）或"解析失败"（红色图标，20% 概率）
- 刷新后文档元数据保留

**涉及组件**: `DocumentCreateModal.vue`、`DocumentTable.vue`、`useDocumentStore.createDocument`、状态模拟定时器

---

### V9: 上传超大文件拒绝

**前提**: 同上

**步骤**:
1. 点击"新建知识"
2. 选择一个 > 500MB 的文件
3. 观察上传组件反馈

**预期结果**:
- 文件被拒绝添加
- 弹出 Toast 错误提示"文件大小超过 500MB 限制"
- 表格无新增记录

**涉及组件**: `DocumentCreateModal.vue`（a-upload `beforeUpload`）

---

### V10: 上传压缩包自动解压

**前提**: 同上

**步骤**:
1. 点击"新建知识"
2. 选择一个 `.zip` 文件（含多个文档）
3. 点击确定

**预期结果**:
- 系统为包内每个文件创建独立的 Document 记录
- 每个记录经历"解析中 → 解析完成/失败"的状态转换
- 表格显示多行新记录

**涉及组件**: `DocumentCreateModal.vue`、`useDocumentStore.createDocument`（原型阶段可简化为单记录模拟）

---

### V11: 批量删除文档

**前提**: 目录下有多篇文档（含至少一篇非"解析中"状态）

**步骤**:
1. 在表格中勾选 3 篇文档
2. 点击表格上方"批量删除"按钮
3. 在确认对话框中点击"确定"

**预期结果**:
- 被选中的非"解析中"文档从表格中消失
- 若存在"解析中"文档则被忽略并 Toast 提示
- IndexedDB 中对应 Blob 与解析内容被清除

**涉及组件**: `DocumentTable.vue`、`useDocumentStore.batchDeleteDocuments`

---

### V12: 单行删除"解析中"文档被拒绝

**前提**: 目录下存在一篇 `status=parsing` 的文档

**步骤**:
1. 点击该行"删除"按钮
2. 在 `a-popconfirm` 中点击"确定"

**预期结果**:
- 删除操作被拒绝
- Toast 提示"请等待解析完成后再操作"
- 该行仍然显示

**涉及组件**: `DocumentTable.vue`、`useDocumentStore.deleteDocument`

---

### V13: 查看文档详情（Office 类型）

**前提**: 目录下存在一篇 `.pdf` 状态的 `success` 文档

**步骤**:
1. 点击该行任意位置（非按钮区域）

**预期结果**:
- 右侧弹出抽屉
- 顶部展示元信息：名称、描述、标签、大小、状态、创建/更新时间
- 下方使用 `<vue-office-pdf />` 渲染 PDF 内容

**涉及组件**: `DocumentDetailDrawer.vue`、`@vue-office/pdf`

---

### V14: 查看文档详情（Markdown 类型）

**前提**: 目录下存在一篇 `.md` 状态的 `success` 文档

**步骤**:
1. 点击该行

**预期结果**:
- 抽屉打开
- 下方使用 `<v-md-preview />` 渲染 Markdown 内容

**涉及组件**: `DocumentDetailDrawer.vue`、`@kangc/v-md-editor`

---

### V15: 新增/修改标签

**前提**: 目录下存在一篇文档

**步骤**:
1. 点击该行"新增标签"按钮
2. 在模态框中输入"PRD"、"Q1"两个标签并确定
3. 点击该行"修改标签"按钮
4. 在模态框中删除"Q1"并确定

**预期结果**:
- 步骤 2 后表格"标签"列显示 `PRD`、`Q1` 两个 `a-tag`
- 步骤 4 后仅剩 `PRD` 一个标签
- 刷新后标签保留

**涉及组件**: `DocumentTable.vue`、`DocumentActionModal.vue`、`useDocumentStore.addTag`、`useDocumentStore.updateTags`

---

### V16: 级联删除目录时同步清理 IndexedDB

**前提**: 目录下有多篇文档

**步骤**:
1. 删除包含文档的目录（见 V7）
2. 通过 DevTools → Application → IndexedDB 检查 `kb_files_db` 的 `files` 与 `parsed_contents` 两个 store

**预期结果**:
- 被删除文档对应的 Blob 与解析内容均已清除
- 其他文档数据保留

**涉及组件**: `useFolderStore.deleteFolder`、`useDocumentStore.batchDeleteDocuments`、`useStorage.js` IndexedDB 封装

---

## 性能与规模验收

| 场景 | 期望 |
| ---- | ---- |
| 单知识库 1000 篇文档、10 层目录 | 目录树与表格交互无卡顿（SC-006） |
| 单文档详情抽屉打开 | 2 秒内完成（SC-003） |
| 批量删除 50 篇文档 | 5 秒内列表刷新（SC-004） |
| 首次使用者完成"创建目录并上传文档" | 无说明情况下 90% 成功率（SC-005） |

## 参考

- 功能规格：[spec.md](./spec.md)
- 数据模型：[data-model.md](./data-model.md)
- 组件契约：[contracts/ui-contracts.md](./contracts/ui-contracts.md)
- 技术决策：[research.md](./research.md)
