


## 知识库页面设计
在“知识管理后台服务”中

点击“知识库”菜单后，进到知识库管理页面，在该页面中，用户可以创建新的知识库、设置或删除某个已经创建的知识库。

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeBase.vue

MyKnowlegeWebDemo/src/components/knowledge-base/KbList.vue

### 新建知识库
点击“新建知识库”按钮时，弹出对话框（使用a-modal组件）

在该窗口中，用户可以设置
知识库的名字（名字必填）、
知识库的描述、
选择LLM模型（模型必选，使用下拉选择框a-select组件，选择已经创建的模型）
选择Embedding模型（模型必选，使用下拉选择框a-select组件，选择已经创建的模型）
选择图片识别模型（模型必选，使用下拉选择框a-select组件，选择已经创建的模型）
选择Rerank模型（模型必选，使用下拉选择框a-select组件，选择已经创建的模型）

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeBase.vue

MyKnowlegeWebDemo/src/components/knowledge-base/KbCreateModal.vue

### 删除知识库
在知识库列表中，每个知识库的右侧有一个“删除”按钮，点击后，弹出确认删除对话框（使用a-modal组件），用户点击确认后，删除该知识库。

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeBase.vue

### 设置（修改）知识库
在知识库列表中，每个知识库的右侧有一个“设置”按钮，点击后，弹出设置知识库对话框（使用a-drawer组件），在该窗口中，用户可以修改知识库的名字（名字必填）、描述、选择LLM模型、选择Embedding模型、选择图片识别模型、选择Rerank模型

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeBase.vue

MyKnowlegeWebDemo/src/components/knowledge-base/KbFormDrawer.vue

## 知识库中知识的管理
点击某个知识库，进入知识管理页面

### 知识列表
在知识管理页面中，用户可以查看该知识库中的知识列表

在该页面中，左侧是知识的目录层级结构，用户可以新建根目录，同时，用户可以在目录中创建子目录，目录可以无限层级嵌套。

同时，目录结构还可以拖动，实现目录的排序和嵌套。鼠标悬浮到某个目录，显示“...”,点击后，弹出下拉菜单，显示“新建目录”、“删除目录”、“修改目录名称”选项，每个选项点击后，都弹出模态框（使用a-modal组件）

目录结构使用a-tree组件

右侧，展示该目录下的文档列表，展示为table表结构，包含文档的名称、标签、大小、状态（包含解析中、解析完成、解析失败），创建时间、更新时间、操作（操作包含删除、新增标签、修改标签）。

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeManagement.vue

MyKnowlegeWebDemo/src/components/knowledge/DocumentTable.vue

MyKnowlegeWebDemo/src/components/knowledge/FolderTree.vue

### 新建知识
点击“新建知识”按钮时，弹出对话框（使用a-modal组件），在该窗口中，用户可以上传任意类型的文件或zip、tar.gz等压缩包，上传后，系统会自动解析并生成知识库。

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeManagement.vue

MyKnowlegeWebDemo/src/components/knowledge/DocumentCreateModal.vue
### 删除知识
在知识列表中，table是可多选的，用户可以选择多个文档进行批量删除，删除后，系统会自动删除对应的文件和解析生成的知识。

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeManagement.vue

MyKnowlegeWebDemo/src/components/knowledge/DocumentTable.vue


### 知识的查看
点击table中的某个知识，可以弹出模型对话框（使用a-drawer组件），查看知识的详细信息，

包括名称、描述、内容、标签、大小、状态（包含解析中、解析完成、解析失败），创建时间、更新时间，文档内容、解析后的markdown内容、文档分片数据

如果文档是Office文件类，可以使用vue-office组件进行渲染

如果文档是markdown文件，可以使用kangc/v-md-editor组件进行渲染

如果是其他类型文件，直接按照普通文档进行展示即可

页面效果参考：MyKnowlegeWebDemo/src/views/KnowledgeManagement.vue

MyKnowlegeWebDemo/src/components/knowledge/DocumentTable.vue

MyKnowlegeWebDemo/src/components/knowledge/DocumentDetailDrawer.vue





