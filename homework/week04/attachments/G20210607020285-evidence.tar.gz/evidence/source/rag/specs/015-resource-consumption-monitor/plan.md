# Implementation Plan: 资源消耗监控

**Branch**: `015-resource-consumption-monitor` | **Date**: 2026-11-25 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/015-resource-consumption-monitor/spec.md`

## Summary

在 AI→知识库侧边栏新增"资源消耗监控"页面（2 Tab × 3 子视图），基于 Prometheus 已采集的 `llm_tokens_total` / `llm_cost_estimate` 指标，按北京时间自然日/月展示各模型消耗曲线。技术路径：KnowledgeManage 新增 `/api/knowledge/consumption` 查询接口（JWT 鉴权 + 权限隔离），服务端按桶拼装 PromQL `increase` 瞬时查询调 Prometheus HTTP API（http://localhost:9091，配置化），返回补 0、截断至当前的序列；前端新增 ECharts 折线图页面，复用现有 axios + Bearer 模式。无新增数据库表。

## Technical Context

**Language/Version**: Python 3.11（KnowledgeManage 后端）；JavaScript / Vue 3.5（frontend）

**Primary Dependencies**: 后端 FastAPI + httpx + pydantic（已有）；前端 ant-design-vue 4.2 + axios + pinia + vue-router（已有），**新增 echarts**（按需引入 LineChart/Grid/Tooltip/Legend/CanvasRenderer）

**Storage**: Prometheus（只读外部数据源，http://localhost:9091）；无新增数据库表/迁移

**Testing**: pytest（沿用 `patch("app.dependencies.decode_token")` + mock Prometheus HTTP 的既有模式）；前端 `npm run build` 编译验证

**Target Platform**: macOS 开发 / Linux 服务器；现代浏览器（Chrome/Safari/Edge）

**Project Type**: Web application（FastAPI 微服务 + Vue SPA，多仓库目录单 workspace）

**Performance Goals**: 默认条件进页 ≤5s 出图（SC-001）；单视图 ≤31 个桶查询，asyncio 并发执行，Prometheus 单查询超时 10s

**Constraints**: JWT 鉴权复用；普通用户越权 403；Prometheus 地址不暴露给前端；北京时间自然日/月切分；费用 6 位小数；进行中周期截断至当前；补 0 仅限已经过时间点

**Scale/Scope**: 模型数十个、用户数十人量级；同一时刻单图渲染；6 个视图（token/费用 × 人日/人月/所有人月）

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

`.specify/memory/constitution.md` 为未填充模板，无正式门禁条款。沿用项目既有实践作为软门禁：

| 软门禁 | 评估 |
|--------|------|
| 配置驱动（外部地址入 config.*.yaml，不硬编码） | PASS — 新增 `prometheus` 配置段（url/timeout/retention_days） |
| 鉴权复用（JWT + get_current_user，不新建 auth） | PASS — 沿用 dependencies.get_current_user |
| 权限判定与既有模块一致 | PASS — `"permission_manage" in permissions`（同 prompt_service._is_admin / 前端 userStore.isAdmin） |
| 测试覆盖（pytest 可独立运行，不依赖活库） | PASS — mock Prometheus HTTP 与 UserManage 解析 |
| 无不必要的存储/复杂度 | PASS — 只读查询，无新表、无缓存层、无新服务 |

**Post-Phase-1 复查**: PASS（设计未引入新违规；详见 Complexity Tracking 为空）

## Project Structure

### Documentation (this feature)

```text
specs/015-resource-consumption-monitor/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/
│   └── consumption-api.md
└── tasks.md             # Phase 2 output (/speckit-tasks - NOT created here)
```

### Source Code (repository root)

```text
KnowledgeManage/
├── app/
│   ├── core/config.py              # + PrometheusConfig（url/timeout/retention_days）
│   ├── routers/consumption.py      # 新增：GET /consumption/options、/consumption/series
│   ├── schemas/consumption.py      # 新增：查询参数与响应模型
│   ├── services/consumption_service.py  # 新增：PromQL 拼装、桶切分、补0、权限、email 解析
│   └── main.py                     # 注册 consumption router
├── config.dev.yaml / config.test.yaml / config.prod.yaml  # + prometheus 段
└── tests/test_consumption.py       # 新增：权限/口径/时间边界/补0/故障

frontend/
├── package.json                    # + echarts 依赖
├── src/
│   ├── views/ResourceMonitor.vue   # 新增：2 Tab × 3 子视图主页面
│   ├── components/monitor/
│   │   ├── ConsumptionChart.vue    # ECharts 折线图封装（init/dispose/resize）
│   │   └── MonitorFilters.vue      # 筛选器（user/模型/月份/年份 + 查询按钮）
│   ├── services/monitorApi.js      # axios 实例 + Bearer + 401 跳登录（沿用 evaluationApi 模式）
│   ├── router/index.js             # + /monitor 路由
│   └── components/layout/AppLayout.vue  # + 侧边栏菜单项、路由映射
└── vite.config.js                  # 无需改动（/api/knowledge 代理已存在）
```

**Structure Decision**: 沿用既有"后端 KnowledgeManage + 前端 frontend"双目录结构。后端按 routers/schemas/services 三层既有惯例新增 consumption 模块；前端按 views/components/services 惯例新增 monitor 模块。LlmGateway 零改动（指标已就绪）。

## Complexity Tracking

无宪法门禁违规，无需复杂度豁免。