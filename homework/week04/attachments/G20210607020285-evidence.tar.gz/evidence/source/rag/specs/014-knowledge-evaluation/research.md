# Research: 知识库评测（014-knowledge-evaluation）

**Date**: 2026-11-24 | **Plan**: [plan.md](./plan.md)

所有技术决策均基于对现有代码的核实（文件路径见各条）。规格层 25+3 项决策已定，本文仅解决"如何落地"的技术选择；无遗留 NEEDS CLARIFICATION。

## R1. agent 链路复用方式：新增无会话入口

- **Decision**: 在 `agent_runtime/evaluation.py` 新增 `run_evaluation_question(*, agent_id, kb_ids, user_id, question, cancel_event, emit)`：根 span `evaluation.item`（`start_as_current_span`，属性 evaluation.run_id/item.seq/enduser.id）→ `build_snapshot(db, agent_id, kb_ids, user_id)` → `RequestRuntimeState(history=[], chat_id="", ...)` → 跳过 `history_qa_service` → `_get_runner(agent_type)(state, emit)` → 返回 `{content, meta, trace_id, error?}`。
- **Rationale**: 现有统一入口 `run_agent_generation`（`agent_runtime/__init__.py` L47-103）强依赖 Chat 表记录（chat_id 查 Chat 取 agent_id/kb_ids），而决策21 明确评测不产生会话数据；`build_snapshot` 与三个 flow runner 均不依赖 Chat，可直接复用。flow 内部 span 经 OTel 当前上下文自动挂到 `evaluation.item` 根下，满足决策22"同一 trace"。
- **Alternatives considered**: ① 为每题创建隐藏 Chat/Message 再调 `run_agent_generation`——违反"不产生会话数据"，污染会话列表与历史检索，拒绝；② 给 `run_agent_generation` 加 optional chat 旁路参数——侵入会话主链路、回归风险大，拒绝。

## R2. 澄清/空检索终止的判定口径

- **Decision**: flow 返回 `meta.terminate_reason == "clarify_failed"` → 该题记失败，failure_reason 取 content（即澄清 reason，flow 已把 reason 作为 content 返回，见 `flows/quick_qa.py` L37-44），两项得分置空；`terminate_reason == "empty_retrieval"` → 视为正常 agent 答案（"检索结果为空…"），照常进入评分。
- **Rationale**: 决策4 仅规定"需澄清记失败"；空检索是 agent 的合法终态答案（非执行错误），召回率自然为低分，符合评测语义。
- **Alternatives considered**: 空检索也记失败——规格未授权，且会掩盖"知识库覆盖不足"这一真实评测信号，拒绝。

## R3. 上下文快照来源

- **Decision**: 每题上下文 = flow 返回的 `meta.references`（`ReferenceItem` 列表：chunk_id/document_id/kb_id/file_name/content/score），原样落 `evaluation_items.context` JSONB；`{context}` 渲染仅取 file_name+content（决策5/8）。
- **Rationale**: `quick_qa._answer_node`（L139-151）答案生成前 `rt.chunks.clear()` 后仅保留压缩后片段，`meta.references` 即"最终进入答案生成提示词的片段集合"；多轮 flow 的 references 已按 013 实现汇总各轮最终采纳片段，与决策5 完全一致。
- **Alternatives considered**: 落 `state.chunks` 全量累积——含被淘汰片段，不符合"最终进入提示词"定义，拒绝。

## R4. 评分调用与重试

- **Decision**: 复用 `llm_client.call_json`（`llm_client.py` L174-226，已含容错提取 `extract_json_object`、Pydantic 校验、业务重试 3 次、重试附上次输出与错误、`JsonValidationFailed.raw_output`）。新增两个结果模型（`schemas/evaluation.py`）：`RecallResult{key_points: List[{point: str, covered: StrictBool}]（min_length=1，空数组校验失败→重试，澄清 Q1）, recall: float}`；`AccuracyResult{issues: List[{type, content, evidence}]}`（空数组合法=100 分）。purpose 取 `evaluation_recall` / `evaluation_accuracy`。
- **Rationale**: 与既有 JSON 重试规范完全一致（记忆 f8c3b144），零新造轮子；`call_json` 的 span 参数支持传入评分子 span（R10）。
- **Alternatives considered**: 自写评分重试循环——重复实现且易与既有分层规范漂移，拒绝。

## R5. 得分核算与 JSON 落库

- **Decision**: 召回率 = covered 数 / key_points 总数（后端核算，忽略模型自报 recall）；准确度 = max(0, 100 − 5×len(issues))（百分比数值）。落库：`recall_analysis`/`accuracy_analysis` 存最终采纳的合法 JSON（`parsed.model_dump()`）；评分失败题额外存 `JsonValidationFailed.raw_output` 至 `recall_raw_output`/`accuracy_raw_output`。`ModelUnavailableError`（网关传输层重试耗尽）→ 该题对应评分记失败，不业务重试。
- **Rationale**: 决策6/7/14、FR-021~026；后端核算消除模型算术误差（SC-005）。
- **Alternatives considered**: 采信模型自报 recall——决策6 明确拒绝。

## R6. 后台任务与 SSE 进度机制

- **Decision**: 进程内 `asyncio.create_task` 执行器（`evaluation_runner.py`）+ 每 run 一个事件订阅表（`dict[run_id, set[asyncio.Queue]]`）。SSE 端点 `GET /evaluations/runs/{id}/events` 用 `StreamingResponse(media_type="text/event-stream")`（模式同 `routers/chats.py` L198-202）：连接即发 snapshot 事件（当前进度/状态），随后增量 progress 事件，终态发 done 后关闭。取消：`POST .../cancel` 写 DB `cancel_requested=true` 并 set 进程内 Event；执行器在每题开始前查 DB 标记。断线重连/页面刷新靠 snapshot 事件恢复，无需 Redis Stream。
- **Rationale**: 部署为 uvicorn 单 worker（Dockerfile CMD 核实），进程内任务+队列足够；会话的 Redis Stream/租约机制（chat_service）是为跨实例接管设计，评测无此需求（重启即标记失败，决策16）。DB 取消标记保证重启/多实例下语义仍正确。SSE 推送为决策18 明确选择。
- **Alternatives considered**: ① 复用 chat 的 Redis Stream+租约——复杂度高且评测不需要接管，拒绝；② 前端轮询——决策18 已否决。

## R7. 单题超时兜底

- **Decision**: 执行器对"agent 作答 + 召回率评分 + 准确度评分"整体 `asyncio.wait_for(..., timeout=600)`（常量 `ITEM_TIMEOUT_SECONDS=600`，不做配置项）；超时先 set 该题 cancel_event（终止内部模型调用）再记该题失败（原因"执行超时"），继续下一题。
- **Rationale**: 澄清 Q2；wait_for 取消协程后网关 httpx 调用随协程取消释放，队列与题间取消不被阻塞。
- **Alternatives considered**: 仅依赖网关超时（httpx 120s/300s）+循环上限——单次调用有界但多轮累积无界，挂起风险仍在，拒绝。

## R8. 运行中锁定与实时配置

- **Decision**: 锁定校验在写路径做：测试集重新上传/删除前查 `evaluation_runs` 是否存在 `status='running' AND test_set_id=该ID`；评测设置保存前查当前用户是否有 running 任务。智能体/知识库不锁定；执行器**每题**重新 `build_snapshot`（决策24 实时生效），评测设置（分析模型/评分提示词）因锁定在任务期内不变，开跑时读取一次即可。
- **Rationale**: 决策24；DB 查询即锁，无需额外锁表/Redis 锁；任务结束（completed/cancelled/failed）后查询自然不命中=自动解锁。
- **Alternatives considered**: 开跑全量快照冻结——用户已否决（决策24 澄清记录）。

## R9. 分析模型下拉与预检口径

- **Decision**: 下拉数据复用前端 `modelApi.listModels`（网关 `/models`，page_size=1000 一次取全），前端过滤 `category === 'chat'`。网关 models 表无启用字段（`snapshot.py` 头注 R3 约定：存在即启用、查不到即失效），故"仅启用态"落地为"存在且 category=chat"；预检用 `llm_client.resolve_model` 校验存在性与 category。提示词下拉复用 `promptApi.listPrompts`（后端已按可见性过滤），展示 name+version，按 prompt_id 保存。
- **Rationale**: 澄清 Q3 与网关现实模型（无 status 字段）调和：删除即"停用"，预检兜底事后删除场景；零网关改动。
- **Alternatives considered**: 给网关 models 加启用字段/过滤参数——超出本期范围且无需求支撑，拒绝。

## R10. 评分 trace 子 span

- **Decision**: 评分在 `evaluation.item` 根 span 上下文内创建子 span `evaluation.recall` / `evaluation.accuracy`（每次重试在同一 span 内，`call_json` 已写 `json_validation_retry` 事件），调 `tracing.set_prompt_attrs(span, prompt_snapshot, purpose)` 写 prompt.name/version/purpose（014 规范）；span 输入为渲染后提示词、输出为模型响应（`call_json`/`chat_completion` 已写）。
- **Rationale**: 决策22；`tracing.py` 助手齐备（L99 set_prompt_attrs、L118 add_event）。
- **Alternatives considered**: 评分独立 trace——决策22 已否决。

## R11. TraceDrawer 复用与过期判定

- **Decision**: `TraceDrawer.vue` 新增可选 prop `fetcher: Function`（默认仍按 chatId/message 调 `fetchMessageTrace`），评测页传 `() => fetchEvaluationItemTrace(runId, itemId)`；`notReadyReason` 增加 `expired` 分支文案"轨迹已过期清理"。后端评测 trace 路由：归属校验 → `trace_query_service.fetch_trace(item.trace_id, item.created_at)`；`ready=false` 且 `item.created_at` 距当前 >48 小时 → 返回 `reason="expired"`，否则 `pending`。
- **Rationale**: 决策21/23；`fetch_trace` 只查 ±1 天索引（`trace_query_service.span_indices`），超窗必然查不到，48 小时是与索引窗口一致的确定性过期判据，不虚构保留期天数。抽屉组件其余零改动。
- **Alternatives considered**: 复制一份评测专用抽屉——重复代码，拒绝；查 ES ILM 实际保留期——项目无 ILM 配置可查（已核实），±1 天窗口即事实边界。

## R12. 重启容错与优雅关闭

- **Decision**: `main.py` lifespan 启动段调 `evaluation_service.recover_interrupted_runs()`：`UPDATE evaluation_runs SET status='failed', error_message='服务重启中断', finished_at=now() WHERE status='running'`；关闭段调 `evaluation_runner.shutdown()`（set 全部 cancel_event 并等待任务收尾，模式同 `chat_service.finish_generations`）。
- **Rationale**: 决策16/FR-018；启动标记保证 SC-006（重启后 1 分钟内状态正确）；已完成题目逐题落库天然保留。
- **Alternatives considered**: 断点续跑——决策16 已否决。

## R13. 平均分与列表聚合

- **Decision**: 平均分不冗余落 runs 表，列表/详情查询时对 `evaluation_items` 按 `status='success'` 做 AVG 聚合（单条 SQL join/lateral）；无成功题 → 返回 null，前端展示空。已取消任务同口径。
- **Rationale**: 决策12/25、FR-030；逐题落库+实时聚合避免双写一致性问题，500 题规模聚合开销可忽略；SC-005 人工复算直接对明细表成立。
- **Alternatives considered**: runs 表存 avg 每题更新——引入冗余与部分失败下的一致性维护成本，拒绝。

## R14. 前端页面与菜单接入

- **Decision**: 新路由 `/evaluation` → `EvaluationManagement.vue`（a-tabs：设置/评测）；`AppLayout.vue` 知识库侧栏在"智能体"菜单项后新增 key="evaluation"（同步 `knowledgeRoutes`/`routeMap`/`aiRoutes` 数组，L149-196 核实）；组件按 plan.md 结构拆分；`evaluationApi.js` 沿用 traceApi.js 的 axios 实例+401 拦截模式；SSE 客户端用 fetch + Authorization 头流式读取（沿用 chatApi.js L88-94 既有模式），不用原生 EventSource/token-query（EventSource 无法携带 Authorization 头，token-query 会新增认证面且与契约 Bearer 鉴权不符）。
- **Rationale**: FR-001 菜单与"智能体"同级；复用既有布局/认证/组件模式，前端零新依赖。
- **Alternatives considered**: 评测并入 KnowledgeManagement.vue 内 tab——该视图是单知识库文档管理（/knowledge/:kbId），与全局评测菜单语义不符，拒绝。

## 既有代码核实清单

| 事实 | 出处 |
|------|------|
| run_agent_generation 依赖 Chat；build_snapshot/flow 不依赖 | agent_runtime/__init__.py L47-123、snapshot.py L53 |
| clarify_failed/empty_retrieval 经 meta.terminate_reason 返回 | flows/quick_qa.py L37-44、L124-131 |
| meta.references 即最终答案上下文 | flows/quick_qa.py L139-151、schemas/agent_runtime.py ReferenceItem |
| call_json 容错提取+重试 3 次+raw_output | llm_client.py L174-226 |
| 网关模型无启用字段、category 含 'chat' | snapshot.py 头注、LlmGateway/app/schemas/model.py L12 |
| SSE 用 StreamingResponse；单 worker 部署 | routers/chats.py L198-202、KnowledgeManage/Dockerfile CMD |
| fetch_trace ±1 天索引、0 命中→pending | trace_query_service.py L20-30、L80-92 |
| TraceDrawer 绑定 fetchMessageTrace(chatId,messageId) | components/trace/TraceDrawer.vue props/loadTrace |
| 模型/提示词/知识库下拉 API 已存在 | frontend/src/services/modelApi.js、promptApi.js、knowledgeBaseApi.js |
| 表约定：String(36) uuid PK/JSONB/TIMESTAMP/schema | models/message.py、prompt.py、chat.py |
| lifespan 启动/关闭钩子模式 | app/main.py lifespan |