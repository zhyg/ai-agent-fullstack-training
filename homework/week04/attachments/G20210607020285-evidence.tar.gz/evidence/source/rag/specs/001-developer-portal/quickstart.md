# Quickstart: 开发者门户平台

**Feature**: 001-developer-portal | **Date**: 2026-10-27

## Prerequisites

- Node.js 18+ / npm
- Python 3.10+
- PostgreSQL 14+（开发环境三个服务共享 `127.0.0.1:5432/mydb`，通过 Schema 隔离）

## 1. 后端服务启动

每个后端服务均支持多环境配置（dev/test/prod），通过 `APP_ENV` 环境变量指定。

**开发环境数据库**: 三个服务共享 `postgresql://admin:[REDACTED]@127.0.0.1:5432/mydb`，通过 PostgreSQL Schema（`user_manage` / `knowledge_manage` / `llm_gateway`）进行逻辑隔离。详见 [research.md R-012](./research.md#r-012-多环境配置管理devtestprod)。

### UserManage 服务

```bash
cd UserManage
pip install -r requirements.txt

# 根据当前环境配置 config.{env}.yaml 中的数据库连接信息
# 可选环境: dev / test / prod
export APP_ENV=dev

alembic upgrade head          # 数据库迁移
uvicorn app.main:app --port 8001
```

**验证**: 访问 `http://localhost:8001/docs` 查看自动生成的 Swagger 文档

### KnowledgeManage 服务

```bash
cd KnowledgeManage
pip install -r requirements.txt
export APP_ENV=dev
alembic upgrade head
uvicorn app.main:app --port 8002
```

**验证**: 访问 `http://localhost:8002/docs`

### LlmGateway 服务

```bash
cd LlmGateway
pip install -r requirements.txt
export APP_ENV=dev
alembic upgrade head
uvicorn app.main:app --port 8003
```

**验证**: 访问 `http://localhost:8003/docs`

### 环境配置文件说明

每个服务根目录下有三份配置文件：
- `config.dev.yaml` — 开发环境（本地数据库、DEBUG 日志、SQL 打印）
- `config.test.yaml` — 测试环境（测试数据库、INFO 日志）
- `config.prod.yaml` — 生产环境（生产数据库、WARNING 日志、关闭 SQL 打印）

## 2. 前端启动

前端使用 Vite 内置的 `.env` 文件管理多环境后端服务地址。详见 [research.md R-013](./research.md#r-013-前端多环境配置vite-env-文件)。

```bash
cd frontend
npm install

# 开发环境（默认加载 .env.development，指向本地后端服务）
npm run dev

# 测试环境构建
npm run build --mode test

# 生产环境构建（默认加载 .env.production）
npm run build
```

**验证**: 访问 `http://localhost:5173`

**环境配置文件说明**：
- `.env.development` — 开发环境（后端地址指向 localhost）
- `.env.test` — 测试环境（后端地址指向测试服务器）
- `.env.production` — 生产环境（后端地址指向生产域名）

## 3. 端到端验证场景

### 场景 1: 用户注册 → 登录 → 退出

1. 打开注册页面，输入用户名、邮箱、密码、确认密码
2. 点击注册，验证注册成功并跳转登录页
3. 输入刚注册的账号密码，点击登录
4. 验证成功进入平台主页面
5. 点击退出按钮，验证跳转回登录页

### 场景 2: 提示词管理（普通用户视角）

1. 以普通用户登录
2. 进入提示词管理页面，验证列表为空
3. 点击"新建提示词"，填写名称和内容，提交
4. 验证列表中出现新创建的提示词
5. 点击"设置"按钮，修改描述和内容，保存
6. 点击"删除"按钮，确认删除，验证列表为空

### 场景 3: 提示词管理（管理员视角）

1. 以管理员登录
2. 进入提示词管理页面，验证能看到所有用户的提示词及所有者信息
3. 验证管理员只能编辑/删除自己创建的提示词
4. 验证管理员可以删除其他用户的提示词

### 场景 4: 模型管理（仅管理员）

1. 以管理员登录，进入模型管理页面
2. 点击"新建模型"，填写名字、URL、Key 等配置，提交
3. 验证列表中出现新模型，API Key 以掩码显示
4. 编辑模型时 API Key 留空，修改其他参数并确认，验证保存成功且原密钥不变
5. 编辑时输入新 API Key，验证保存后使用新密钥；脱敏值仅用于展示，不作为密钥提交
4. 以普通用户登录，验证无法访问模型管理页面

### 场景 5: 会话管理

1. 以普通用户登录，进入会话管理页面
2. 点击"新建会话"，选择一个模型和提示词
3. 输入消息，验证 LLM 流式回复正常显示
4. 返回列表，验证历史会话保留
5. 删除会话，验证列表更新

### 场景 6: 权限管理

1. 以管理员登录，进入权限管理页面
2. 在用户管理标签下添加新用户
3. 在角色管理标签下创建新角色，勾选权限项
4. 为新用户分配角色
5. 以新用户登录，验证权限生效

### 场景 7: 登录锁定

1. 在登录页面，连续输入 5 次错误密码
2. 第 6 次尝试时，验证显示"账户已锁定"提示
3. 等待 15 分钟后（或修改数据库 locked_until 字段），验证可以正常登录

## 4. 测试命令

### 后端测试

```bash
# 各服务目录下执行
cd UserManage && pytest -v
cd KnowledgeManage && pytest -v
cd LlmGateway && pytest -v
```

### 前端测试

```bash
cd frontend && npx vitest run
```

## 参考文档

- 数据模型: [data-model.md](./data-model.md)
- API 合约:
  - [UserManage API](./contracts/user-manage-api.md)
  - [KnowledgeManage API](./contracts/knowledge-manage-api.md)
  - [LlmGateway API](./contracts/llm-gateway-api.md)
- 技术调研: [research.md](./research.md)
