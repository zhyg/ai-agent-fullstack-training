# Data Model: 聊天流式生成取消与断线恢复

**Feature**: 005-chat-stream-cancel | **Date**: 2026-10-30

## Existing Entities (No Schema Changes)

本功能不引入新的数据库表或字段变更。现有的 `Chat` 和 `Message` 模型已满足需求。

### Chat (app/models/chat.py)

| Field | Type | Description |
|-------|------|-------------|
| id | String(36) PK | 会话唯一标识 |
| title | String(200) | 会话标题 |
| user_id | String(36) | 所属用户 |
| model_id | String(36) nullable | 模型 ID |
| model_name | String(200) nullable | 模型显示名称 |
| prompt_id | String(36) nullable | 提示词 ID |
| status | String(20) default "idle" | 会话状态 |
| created_at | TIMESTAMP | 创建时间 |
| updated_at | TIMESTAMP | 更新时间 |

### Message (app/models/message.py)

| Field | Type | Description |
|-------|------|-------------|
| id | String(36) PK | 消息唯一标识 |
| chat_id | String(36) | 所属会话 |
| role | String(20) | 消息角色: user/assistant/system |
| content | Text | 消息内容 |
| created_at | TIMESTAMP | 创建时间 |

## State Machine

```
                  ┌──────────────┐
                  │              │
     ┌────────┐   │   ┌──────────┴──┐   ┌───────────┐
     │  idle  │───┼──▶│ generating  │──▶│ completed │
     └────────┘   │   └──────────────┘   └───────────┘
                  │          │
     ┌──────────┐ │          │    ┌───────────┐
     │completed │─┘          └──▶│ cancelled │
     └──────────┘                └───────────┘
                                      │
     ┌───────────┐                    │
     │ cancelled │────────────────────┘
     └───────────┘  (re-enter generating via new send)
```

### State Transitions (VALID_TRANSITIONS)

| From | Allowed Targets | Trigger |
|------|-----------------|---------|
| idle | generating | 用户发送新消息 |
| generating | completed | LLM 流式生成正常结束 |
| generating | cancelled | 用户点击取消（cancel_chat API） |
| completed | generating | 用户发送新消息 |
| cancelled | generating | 用户发送新消息 |

**终态**: `completed` 和 `cancelled` 为终态，不可再转换。但可以从终态进入新的 `generating` 周期（发送新消息）。

## In-Memory Entities (New)

### _GenerationJob (dataclass)

运行时内存对象，不持久化到数据库。服务重启后由 `finish_generations()` 清理。

| Field | Type | Description |
|-------|------|-------------|
| task | asyncio.Task | 后台 asyncio 任务（从 LLM Gateway 读取流） |
| cancel | asyncio.Event | 取消信号，由 Redis listener 或 cancel_chat 触发 |
| detached | asyncio.Event | 前端 SSE 连接已断开标记 |
| done | asyncio.Event | 生成完成标记 |
| _live | asyncio.Queue | 事件分发队列，后台任务写入，SSE 客户端读取 |
| content_buffer | str | 已接收的完整文本内容缓存 |

### _generations (module-level dict)

```python
_generations: dict[str, _GenerationJob] = {}
```

- Key: `chat_id` (str)
- Value: `_GenerationJob` 实例
- 生命周期：`send_message_stream` 创建 → 后台任务完成时自动移除
- 同一 chat_id 同时最多一个活跃 job

## Relationships

```
User (1) ──< Chat (1) ──< Message (N)
                │
                └── _GenerationJob (0..1, in-memory only)
```

- 一个用户拥有多个会话
- 一个会话包含多条消息
- 一个会话在生成中时关联一个内存中的 `_GenerationJob`（可选，仅运行时存在）
