# Tasks: 知识库中文档管理

**Input**: Design documents from `/specs/008-knowledge-doc-management/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Not explicitly requested — test tasks omitted.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Backend**: `KnowledgeManage/app/` (FastAPI service)
- **Frontend**: `frontend/src/` (Vue 3 SPA)
- **Config**: `KnowledgeManage/config.*.yaml`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 安装新依赖、配置 MinIO 对象存储

- [x] T001 Add `minio`, `py7zr`, `rarfile` to backend dependencies in `KnowledgeManage/requirements.txt`
- [x] T002 [P] Add `md-editor-v3`, `@vue-office/docx`, `@vue-office/excel`, `@vue-office/pptx`, `@vue-office/pdf` to frontend dependencies in `frontend/package.json`
- [x] T003 Add `MinioConfig` (endpoint, access_key, secret_key, secure, bucket fields) to `Settings` class in `KnowledgeManage/app/core/config.py`
- [x] T004 [P] Add `minio` config section to `KnowledgeManage/config.dev.yaml`, `KnowledgeManage/config.prod.yaml`, `KnowledgeManage/config.test.yaml`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 核心数据模型、MinIO 客户端、共享前端基础设施，所有 User Story 依赖此阶段

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T005 [P] Create `Folder` SQLAlchemy model in `KnowledgeManage/app/models/folder.py` — fields: id(String36 PK UUID), name(String200 NOT NULL), kb_id(String36 NOT NULL FK→knowledge_bases.id), parent_id(String36 NULLABLE FK→folders.id), order(Integer NOT NULL DEFAULT 0), created_at(TIMESTAMP), updated_at(TIMESTAMP); constraints: UniqueConstraint(kb_id, parent_id, name), Index(kb_id), Index(parent_id); schema: settings.database.db_schema
- [x] T006 [P] Create `Document` SQLAlchemy model in `KnowledgeManage/app/models/document.py` — fields: id(String36 PK UUID), name(String500 NOT NULL), description(String1000 NULLABLE), tags(Text DEFAULT '[]'), file_size(BigInteger NOT NULL), mime_type(String200 NULLABLE), extension(String50 NULLABLE), status(String20 NOT NULL DEFAULT 'parsing'), storage_path(String1000 NOT NULL), folder_id(String36 NOT NULL FK→folders.id), kb_id(String36 NOT NULL FK→knowledge_bases.id), created_at(TIMESTAMP), updated_at(TIMESTAMP); indexes: Index(folder_id), Index(kb_id), Index(status); schema: settings.database.db_schema
- [x] T007 Register Folder and Document models in `KnowledgeManage/app/models/__init__.py`
- [x] T008 Generate Alembic migration `add_folders_documents` and verify with `alembic upgrade head` in `KnowledgeManage/alembic/versions/`
- [x] T009 Create MinIO client singleton wrapper in `KnowledgeManage/app/core/minio_client.py` — initialize from MinioConfig, provide `get_client()`, `get_bucket()`, `ensure_bucket_exists()` functions
- [x] T010 [P] Create `FolderCreate` (name: str 1-200, parent_id: Optional[str]), `FolderUpdate` (name: Optional[str] 1-200, parent_id: Optional[str], order: Optional[int]), `FolderResponse` (all fields with from_attributes), `FolderMoveRequest` (target_parent_id, target_index, auto_rename) Pydantic schemas in `KnowledgeManage/app/schemas/folder.py`
- [x] T011 [P] Create `DocumentCreate`, `DocumentUpdate` (description: Optional[str] max 1000, tags: Optional[list[str]]), `DocumentResponse` (all fields, tags as list[str] with JSON serialization), `DocumentUploadResponse` (documents list, message), `TagAddRequest` (tags: list[str]), `TagRemoveRequest` (tag: str), `BatchDeleteRequest` (document_ids: list[str]), `BatchDeleteResponse` (deleted, skipped, message), `DocumentFileResponse` (url, expires_in) Pydantic schemas in `KnowledgeManage/app/schemas/document.py`
- [x] T012 Implement storage service in `KnowledgeManage/app/services/storage_service.py` — functions: `upload_file(bucket, object_path, file_data, content_type)`, `get_presigned_url(bucket, object_path, expires)`, `delete_object(bucket, object_path)`, `delete_objects_by_prefix(bucket, prefix)` using minio_client wrapper
- [x] T013 Create folder/document API service in `frontend/src/services/documentApi.js` — axios instance with same pattern as knowledgeBaseApi.js (JWT interceptor, 401 handler, baseURL: VITE_KNOWLEDGE_MANAGE_URL), export functions: listFolders, createFolder, updateFolder, deleteFolder, moveFolder, listDocuments, getDocument, updateDocument, uploadDocument, addTags, removeTag, deleteDocument, batchDeleteDocuments, getDocumentFileUrl
- [x] T014 [P] Create `useFolderStore` Pinia store in `frontend/src/stores/folder.js` — state: folders[], loading; actions: fetchFolders(kbId), createFolder(kbId, data), updateFolder(folderId, data), deleteFolder(folderId), moveFolder(folderId, data); include snake_case→camelCase conversion (toCamelCase/toSnakeCase) matching existing knowledgeBase.js pattern
- [x] T015 [P] Create `useDocumentStore` Pinia store in `frontend/src/stores/document.js` — state: documents[], total, loading; actions: fetchDocuments(folderId, page, pageSize), getDocument(docId), updateDocument(docId, data), uploadDocument(folderId, file), addTags(docId, tags), removeTag(docId, tag), deleteDocument(docId), batchDeleteDocuments(ids), getDocumentFileUrl(docId); include snake_case→camelCase conversion, tags JSON array handling
- [x] T016 [P] Create file utility functions in `frontend/src/utils/file.js` — `formatFileSize(bytes)` (B→KB→MB→GB auto-format), `getRendererType(extension)` (returns 'markdown'|'office-docx'|'office-excel'|'office-pptx'|'office-pdf'|'text' based on file extension), `isCompressedFile(extension)` (returns true for .zip/.rar/.7z/.tar.gz/.tgz)
- [x] T017 Register `folders` and `documents` routers in `KnowledgeManage/app/main.py` — import and `app.include_router(folders.router, prefix="/api/knowledge")`, `app.include_router(documents.router, prefix="/api/knowledge")`
- [x] T018 Add route `path: 'knowledge/:kbId', name: 'KnowledgeManagement', component: () => import('../views/KnowledgeManagement.vue')` as child of layout route in `frontend/src/router/index.js`

**Checkpoint**: Foundation ready — user story implementation can now begin

---

## Phase 3: User Story 1 - 知识库详情页导航 (Priority: P1) 🎯 MVP

**Goal**: 用户从知识库列表进入知识库详情页，看到左右分栏布局（目录树 + 文档列表区域），知识库不存在时显示 404

**Independent Test**: 从知识库列表点击卡片 → 验证跳转到详情页，显示正确的布局和标题栏

### Implementation for User Story 1

- [x] T019 [US1] Create `KnowledgeManagement.vue` view in `frontend/src/views/KnowledgeManagement.vue` — layout: header (back button ArrowLeftOutlined + kb name + "/ 知识管理" subtitle), body (left aside 280px sidebar + right main area), 404 fallback (a-result status="404" with "返回知识库列表" button); computed: currentKb from route.params.kbId via kbStore; watch kbId to reset state and auto-select first root folder (sorted by order asc); emit folder-select/create/delete events as placeholders for US2/US3/US4
- [x] T020 [US1] Update `handleEnter(kb)` in `frontend/src/views/KnowledgeBaseManagement.vue` — change from `router.push('/knowledge')` to `router.push({ name: 'KnowledgeManagement', params: { kbId: kb.id } })`

**Checkpoint**: Knowledge base detail page navigable, layout renders correctly

---

## Phase 4: User Story 2 - 目录树管理 (Priority: P1)

**Goal**: 左侧目录树支持创建根目录/子目录、重命名、删除（级联）、拖拽排序，选中目录联动右侧文档列表

**Independent Test**: 创建根目录 → 创建子目录 → 重命名 → 拖拽移动 → 删除 → 验证树结构正确更新

### Backend for User Story 2

- [x] T021 [P] [US2] Implement `folder_service` in `KnowledgeManage/app/services/folder_service.py` — functions: `list_folders(db, kb_id, user_id)` (return all folders for kb, verify kb ownership), `create_folder(db, kb_id, user_id, data)` (validate kb ownership, validate parent exists & belongs to kb if parent_id provided, check same-name uniqueness under parent_id raising 409 ValueError, set order to max_sibling_order+1), `update_folder(db, folder_id, user_id, data)` (verify ownership via kb→user_id, check name uniqueness if name changed, validate cannot move to self/descendant by recursive parent traversal raising 422 ValueError), `delete_folder(db, folder_id, user_id)` (recursive collect all descendant folder IDs, delete all documents under those folders from DB + MinIO via storage_service, delete folders, return counts), `move_folder(db, folder_id, user_id, data)` (validate no self-descendant move, check target name uniqueness — if conflict and auto_rename=True, append " (2)" suffix and increment, update parent_id and recalculate order for affected siblings)
- [x] T022 [US2] Implement folder router in `KnowledgeManage/app/routers/folders.py` — prefix="/knowledge-bases" for list/create, standalone for update/delete/move; endpoints: `GET /{kb_id}/folders` (200 list), `POST /{kb_id}/folders` (201 create, catch ValueError→409), `PUT /folders/{folder_id}` (200 update, catch ValueError→409/422), `DELETE /folders/{folder_id}` (200 delete with counts), `PUT /folders/{folder_id}/move` (200 move with renamed flag); all endpoints use `Depends(get_current_user)` and `Depends(get_db)`; verify kb ownership by calling `knowledge_base_service.get_knowledge_base`

### Frontend for User Story 2

- [x] T023 [P] [US2] Create `FolderTree.vue` component in `frontend/src/components/knowledge/FolderTree.vue` — props: kbId, selectedFolderId; emits: select, create-root, create-child, rename, delete, drop; use a-tree with draggable=true, block-node; custom title slot with tree-node layout (title + hover-visible "more" dropdown menu: 新建目录/修改目录名称/删除目录); allowDrop function: reject if dropNode is descendant of dragNode (use isDescendant helper from utils); handleDrop: calculate newParentId and newIndex based on dropToGap/dropPosition, emit drop event; empty state: a-empty with "暂无目录，点击上方按钮新建根目录"
- [x] T024 [P] [US2] Create `FolderActionModal.vue` component in `frontend/src/components/knowledge/FolderActionModal.vue` — props: visible, type('create-root'|'create-child'|'rename'|'delete'), folder; emit: close, submit; title computed by type; form with name input (required rule) for create/rename, pre-fill name on rename via watch visible; delete type shows confirmation text; handleSubmit emits appropriate data per type
- [x] T025 [US2] Create tree utility in `frontend/src/utils/tree.js` — `buildTree(folders, kbId)` (convert flat folder list to a-tree treeData format with key/title/children/raw, sorted by order), `isDescendant(folders, ancestorId, targetId)` (recursive check if targetId is under ancestorId)
- [x] T026 [US2] Integrate FolderTree, FolderActionModal into `KnowledgeManagement.vue` — wire folder events: handleFolderSelect (set currentFolderId, clear selectedRowKeys), openFolderAction/closeFolderAction (modal state), handleFolderActionSubmit (dispatch to folderStore by type: create-root, create-child, rename, delete with Modal.confirm for delete), handleFolderDrop (call folderStore.moveFolder with auto_rename, show message if renamed)
- [x] T027 [US2] Add folder fetch on mount in `KnowledgeManagement.vue` — call `folderStore.fetchFolders(kbId)` in watch(kbId, ..., {immediate: true}), auto-select first root folder after fetch completes

**Checkpoint**: Full folder tree CRUD + drag-drop working, directory selection drives right panel

---

## Phase 5: User Story 3 - 文档上传 (Priority: P1)

**Goal**: 用户在选定目录下上传文件（普通文件或压缩包），系统存储到 MinIO 并创建文档记录

**Independent Test**: 选择目录 → 点击"新建知识" → 上传 .docx 文件 → 验证文档出现在列表中且状态为"解析中"

### Backend for User Story 3

- [x] T028 [US3] Implement `document_service.upload_document` in `KnowledgeManage/app/services/document_service.py` — function receives db, folder_id, user_id, file(UploadFile): verify kb ownership, validate file_size ≤ 524288000 (500MB, raise 413 HTTPException), generate document UUID, compute storage_path as `{kb_id}/{folder_id}/{doc_id}/{filename}`, call storage_service.upload_file, create Document record (name=file.filename, file_size=file.size, mime_type=file.content_type, extension=os.path.splitext(filename)[1].lstrip('.'), status='parsing', storage_path, folder_id, kb_id), return document; for compressed files (check extension against .zip/.rar/.7z/.tar.gz/.tgz): save to temp, extract using zipfile/tarfile/py7zr/rarfile, traverse extracted files preserving directory structure, for each file: create intermediate folders if needed (reusing folder_service create logic), upload to MinIO, create Document record, cleanup temp files, return list of documents
- [x] T029 [US3] Implement upload endpoint in `KnowledgeManage/app/routers/documents.py` — `POST /folders/{folder_id}/documents/upload` with `file: UploadFile = File(...)`, call document_service.upload_document, return 201 with DocumentUploadResponse (documents list + message "上传成功，正在解析..."); handle 413 for oversized files, 404 for missing folder

### Frontend for User Story 3

- [x] T030 [P] [US3] Create `DocumentCreateModal.vue` component in `frontend/src/components/knowledge/DocumentCreateModal.vue` — props: visible, folderId, kbId; emits: close, submit; a-modal with a-upload-dragger (max-count=1), beforeUpload validates file.size ≤ 524288000 (show message.error if exceeded, return false to prevent auto-upload), hint text "支持任意类型文件及 .zip .rar .7z .tar.gz 压缩包，单文件上限 500MB"; handleSubmit validates folderId selected and file selected, emits {file, folderId, kbId}
- [x] T031 [US3] Integrate DocumentCreateModal into `KnowledgeManagement.vue` — add createDocModalVisible ref, openCreateDocModal function (check currentFolderId, show warning if not selected), closeCreateDocModal, handleCreateDocument: call documentStore.uploadDocument(file, folderId, kbId), show message.success("上传成功，正在解析..."), close modal

**Checkpoint**: File upload functional, documents appear in list with "parsing" status

---

## Phase 6: User Story 4 - 文档列表与操作 (Priority: P2)

**Goal**: 文档列表展示、标签增删、单个/批量删除

**Independent Test**: 在有文档的目录下 → 查看表格渲染 → 新增/删除标签 → 删除文档 → 批量删除

### Backend for User Story 4

- [x] T032 [P] [US4] Implement `document_service.list_documents` and `get_document` in `KnowledgeManage/app/services/document_service.py` — `list_documents(db, folder_id, user_id, page, page_size)`: verify kb ownership via folder→kb→user_id chain, query documents where folder_id matches, paginate (default page_size=20), return (items, total); `get_document(db, document_id, user_id)`: verify ownership, return document with tags deserialized from JSON
- [x] T033 [P] [US4] Implement `document_service.update_tags` and `remove_tag` in `KnowledgeManage/app/services/document_service.py` — `add_tags(db, doc_id, user_id, new_tags)`: load doc, deserialize existing tags, merge (dedup + strip whitespace + filter empty), serialize back, commit; `remove_tag(db, doc_id, user_id, tag)`: load doc, filter out target tag, serialize, commit
- [x] T034 [P] [US4] Implement `document_service.delete_document` and `batch_delete` in `KnowledgeManage/app/services/document_service.py` — `delete_document(db, doc_id, user_id)`: verify ownership, check status != 'parsing' (raise 409 ValueError), delete MinIO object via storage_service.delete_object, delete DB record, return True; `batch_delete_documents(db, doc_ids, user_id)`: iterate ids, skip parsing status docs (count skipped), delete others (DB + MinIO), return {deleted, skipped}
- [x] T035 [US4] Implement document CRUD endpoints in `KnowledgeManage/app/routers/documents.py` — `GET /folders/{folder_id}/documents` (200 paginated), `GET /documents/{doc_id}` (200 detail), `PUT /documents/{doc_id}` (200 update description/tags), `PUT /documents/{doc_id}/tags/add` (200 add tags), `PUT /documents/{doc_id}/tags/remove` (200 remove tag), `DELETE /documents/{doc_id}` (200 delete, catch ValueError→409 for parsing status), `POST /documents/batch-delete` (200 with deleted/skipped counts)

### Frontend for User Story 4

- [x] T036 [P] [US4] Create `DocumentTable.vue` component in `frontend/src/components/knowledge/DocumentTable.vue` — props: folderId, folderName, documents, selectedRowKeys; emits: select-change, row-click, create, batch-delete, delete, add-tag, remove-tag; columns: name(blue clickable), tags(colored a-tag closable), size(formatFileSize), status(tag with icon: parsing=SyncOutlined spin/processing, success=CheckCircleOutlined/success, failed=CloseCircleOutlined/error), createdAt, updatedAt, action(dropdown: 新增标签 + divider + 删除(danger, disabled if parsing)); toolbar: "{folderName} 的文档" or "请先选择目录", batch-delete button (disabled if no selection), 新建知识 button (disabled if no folderId); a-table with pagination pageSize=20, customRow onClick→emit row-click, row-selection
- [x] T037 [P] [US4] Create `DocumentActionModal.vue` component in `frontend/src/components/knowledge/DocumentActionModal.vue` — props: visible, document; emits: close, submit; a-modal with a-select mode="tags" for tag input, placeholder "输入标签后按回车添加"; on submit: dedupe + trim + filter empty, emit {documentId, tags}
- [x] T038 [US4] Integrate DocumentTable and DocumentActionModal into `KnowledgeManagement.vue` — wire document table events: handle row-click→open detail drawer (US5), batch-delete with Modal.confirm (call documentStore.batchDeleteDocuments, show deleted/skipped message), delete with Modal.confirm (call documentStore.deleteDocument, check refused for parsing), add-tag→open DocumentActionModal, remove-tag with Modal.confirm (call documentStore.removeTag); bind document list to computed currentDocuments from documentStore filtered by currentFolderId

**Checkpoint**: Document list with tags and delete fully functional

---

## Phase 7: User Story 5 - 文档详情预览 (Priority: P2)

**Goal**: 点击文档行打开详情抽屉，预览原始内容（多格式渲染），编辑描述，管理标签

**Independent Test**: 点击文档 → 抽屉打开 → 基础信息显示 → 切换三个 Tab 验证渲染 → 编辑描述保存

### Backend for User Story 5

- [x] T039 [US5] Implement `document_service.get_document_file_url` in `KnowledgeManage/app/services/document_service.py` — function: load document, verify ownership, call storage_service.get_presigned_url(bucket, storage_path, expires=3600), return {url, expires_in}
- [x] T040 [US5] Add file URL endpoint in `KnowledgeManage/app/routers/documents.py` — `GET /documents/{doc_id}/file` (200 with DocumentFileResponse), return presigned URL for MinIO object

### Frontend for User Story 5

- [x] T041 [P] [US5] Create `DocumentDetailDrawer.vue` component in `frontend/src/components/knowledge/DocumentDetailDrawer.vue` — props: visible, document; emits: close, add-tag, remove-tag; a-drawer width="70vw" destroyOnClose; basic info: a-descriptions (name span=2, description span=2 with inline edit button, tags with closable a-tag + "新增" link, size formatFileSize, status tag, created_at, updated_at); content tabs: 原始内容(SOURCE) with conditional renderer (MdPreview for markdown, VueOfficeDocx/Excel/Pptx/Pdf for office types via fileArrayBuffer, pre for text, a-empty for unsupported), loading state a-spin, error state a-alert; 解析后的 Markdown(MARKDOWN) with mock MdPreview content; 文档分片(CHUNKS) with mock chunk cards (id, title, content, characters, tokens)
- [x] T042 [US5] Add inline description editing in `DocumentDetailDrawer.vue` — description area: display mode shows text + edit icon button, click to switch to edit mode (a-input textarea + save/cancel buttons), on save call documentStore.updateDocument(docId, {description: newDescription}), show message.success, refresh display
- [x] T043 [US5] Implement file content loading in `DocumentDetailDrawer.vue` — watch(visible, document?.id): call documentStore.getDocumentFileUrl(docId), fetch file blob via axios responseType='blob', for office types convert to ArrayBuffer, for text types read as text; manage contentLoading/contentError refs; cleanup on close/cancel
- [x] T044 [US5] Integrate DocumentDetailDrawer into `KnowledgeManagement.vue` — add detailDrawerVisible/viewingDocument refs, openDocumentDetail(doc) sets viewing and opens drawer, closeDocumentDetail clears state; pass add-tag/remove-tag events through to existing handlers

**Checkpoint**: Full document detail preview with multi-format rendering functional

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: 集成验证、错误处理、代码清理

- [x] T045 Run quickstart.md validation scenarios end-to-end, fix any issues found
- [x] T046 [P] Add global error handling for MinIO connection failures in storage_service.py — catch connection errors, return user-friendly messages
- [x] T047 [P] Add file type validation in upload endpoint — verify file extension against supported compressed formats list (.zip, .rar, .7z, .tar.gz, .tgz), reject unknown archive formats with clear error message
- [x] T048 Verify all API error responses return consistent format (detail field) matching existing patterns in KnowledgeManage service
- [x] T049 [P] Add loading states and empty states across all frontend components (FolderTree empty, DocumentTable empty, detail drawer loading)
- [x] T050 Ensure tags JSON serialization/deserialization handles edge cases (empty array, special characters, unicode) in document_service.py

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — start immediately
- **Foundational (Phase 2)**: Depends on Phase 1 (T001-T004) — BLOCKS all user stories
  - T007 depends on T005+T006 (model registration before migration)
  - T008 depends on T007 (migration after registration)
  - T012 depends on T009 (storage service uses minio client)
  - T017 depends on T021+T022+T028+T035+T039+T040 (router registration after implementation — alternatively, create stub routers earlier)
- **US1 (Phase 3)**: Depends on Phase 2 (needs router, store, route)
- **US2 (Phase 4)**: Depends on Phase 2 + US1 (needs FolderTree integrated into KnowledgeManagement.vue)
- **US3 (Phase 5)**: Depends on Phase 2 + US2 (needs folder selection working)
- **US4 (Phase 6)**: Depends on Phase 2 + US2 (needs folder selection working)
- **US5 (Phase 7)**: Depends on Phase 2 + US4 (needs document list working for row-click)
- **Polish (Phase 8)**: Depends on all user stories

### User Story Dependencies

- **US1**: After Foundational — standalone navigation page
- **US2**: After US1 — adds folder tree to the detail page
- **US3**: After US2 — needs folder selection to upload
- **US4**: After US2 — needs folder selection to list documents (can parallel with US3)
- **US5**: After US4 — needs document list to click for detail (can parallel with US3)

### Within Each User Story

- Backend service → Backend router → Frontend component → Integration into KnowledgeManagement.vue

### Parallel Opportunities

- **Phase 1**: T002, T004 can run in parallel
- **Phase 2**: T005+T006, T009, T010+T011, T013+T014+T015+T016 can all run in parallel
- **Phase 4**: T021+T023+T024+T025 can run in parallel (different files)
- **Phase 6**: T032+T033+T034, T036+T037 can run in parallel
- **US3 and US4** can be worked on in parallel after US2 completes (different files)

---

## Parallel Example: Phase 2 Foundational

```bash
# Launch all independent backend models + schemas + frontend utilities together:
Task: T005 "Create Folder model in KnowledgeManage/app/models/folder.py"
Task: T006 "Create Document model in KnowledgeManage/app/models/document.py"
Task: T009 "Create MinIO client wrapper in KnowledgeManage/app/core/minio_client.py"
Task: T010 "Create Folder schemas in KnowledgeManage/app/schemas/folder.py"
Task: T011 "Create Document schemas in KnowledgeManage/app/schemas/document.py"
Task: T013 "Create documentApi.js in frontend/src/services/documentApi.js"
Task: T014 "Create folder store in frontend/src/stores/folder.js"
Task: T015 "Create document store in frontend/src/stores/document.js"
Task: T016 "Create file utils in frontend/src/utils/file.js"
```

---

## Implementation Strategy

### MVP First (US1 Only)

1. Complete Phase 1: Setup (dependencies + config)
2. Complete Phase 2: Foundational (models + services + stores)
3. Complete Phase 3: US1 — 知识库详情页导航
4. **STOP and VALIDATE**: Navigate to detail page, verify layout and 404 handling
5. Deploy/demo if ready

### Incremental Delivery

1. Setup + Foundational → Foundation ready
2. Add US1 (详情页导航) → Test → Demo
3. Add US2 (目录树管理) → Test → Demo (folders working!)
4. Add US3 (文档上传) → Test → Demo (can upload files!)
5. Add US4 (文档列表) → Test → Demo (full document management!)
6. Add US5 (文档详情) → Test → Demo (complete feature!)
7. Polish → Final validation

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Developer A: US1 → US2 (page + folder tree)
3. Developer B: US3 → US4 (upload + list, backend focus)
4. Once US2 done: Developer B integrates frontend with Developer A's page
5. Developer C: US5 (detail preview, independent component)

---

## Notes

- [P] tasks = different files, no dependencies — safe to parallelize
- All paths relative to repository root `/Volumes/MySSD/mycode/Ai/myKnowlege/`
- Backend service files follow existing pattern: `app/models/`, `app/schemas/`, `app/services/`, `app/routers/`
- Frontend files follow existing pattern: `src/stores/`, `src/services/`, `src/components/`, `src/views/`, `src/utils/`
- Commit after each task or logical group of tasks
- Refer to `MyKnowlegeWebDemo/` components for UI reference implementation
