# API Contracts: 聊天流式生成取消与断线恢复

**Feature**: 005-chat-stream-cancel | **Date**: 2026-10-30

## Overview

本功能的 API 变更集中在 KnowledgeManage 服务。LlmGateway 和 UserManage 无需修改。

---

## Contract 1: POST /chats/{chat_id}/messages (修改)

**Base URL**: KnowledgeManage (`/api/knowledge`)

**变更说明**: 重构为支持"后台生成 + SSE 观察者"模式。当已有活跃的生成任务时，直接附加到该任务而非启动新的生成。

### Request

```http
POST /api/knowledge/chats/{chat_id}/messages
Authorization: Bearer <JWT>
Content-Type: application/json

{
  "content": "用户消息内容"
}
```

### SSE Events (Response: text/event-stream)

**delta 事件** — AI 正在输出内容:
```json
data: {"type": "delta", "content": "生成的文本片段"}
```

**usage 事件** — Token 使用统计:
```json
data: {"type": "usage", "input": 100, "output": 50, "cached": 0, "reasoning": 0}
```

**error 事件** — 生成过程错误:
```json
data: {"type": "error", "message": "错误描述"}
```

**cancelled 事件** — 用户主动取消:
```json
data: {"type": "cancelled", "chat_id": "uuid"}
```

**done 事件** — 生成完成:
```json
data: {"type": "done"}
```

**流结束标记**:
```
data: [DONE]
```

### 行为说明

- **首次发送**: 创建 `_GenerationJob`，启动后台任务，SSE 流实时推送事件
- **重新连接（会话仍在 generating）**: 附加到已有的 `_GenerationJob`，从 `_live` 队列读取缓冲事件，然后继续实时推送
- **前端断开连接**: SSE 生成器退出，设置 `job.detached`，后台任务继续运行
- **前端主动取消**: 通过 cancel API（见 Contract 2）触发，SSE 流收到 `cancelled` 事件后结束

---

## Contract 2: POST /chats/{chat_id}/cancel (已有，无变更)

**Base URL**: KnowledgeManage (`/api/knowledge`)

### Request

```http
POST /api/knowledge/chats/{chat_id}/cancel
Authorization: Bearer <JWT>
```

### Response

```json
200 OK
{
  "id": "chat-uuid",
  "status": "cancelled",
  "message": "会话已取消"
}
```

### Error Responses

| Status | Condition | Body |
|--------|-----------|------|
| 404 | 会话不存在或无权访问 | `{"detail": "会话不存在或无权访问"}` |
| 409 | 会话不在 generating 状态 | `{"detail": "Cannot cancel chat in 'idle' state..."}` |

### 行为说明

- 将会话状态从 `generating` 转换为 `cancelled`
- 通过 Redis Pub/Sub 发布取消信号
- 后台任务的 Redis listener 收到信号后中断 LLM Gateway 连接
- 已接收的部分内容保存为 Message（content 末尾追加 `\n[已取消]`）
- 操作幂等：对已 cancelled 的会话再次调用返回 409

---

## Contract 3: GET /chats/{chat_id}/messages (已有，无变更)

**Base URL**: KnowledgeManage (`/api/knowledge`)

### 行为说明（重新连接场景）

- 前端进入会话页面时，通过此 API 加载已持久化的历史消息
- 如果最近一条消息的会话状态为 `generating`，前端自动触发 SSE 连接（Contract 1）以获取实时生成内容

---

## Frontend Store API Changes

### chatStore 新增/修改

| Action | 说明 |
|--------|------|
| `sendMessage(content)` | 修改：使用 AbortController 管理 SSE 流 |
| `cancelGeneration()` | 新增：调用 cancel API + abort SSE 流 + 更新状态 |
| `resumeStream(chatId)` | 新增：检测到 generating 状态时自动重新建立 SSE 连接 |

### chatStore 新增状态

| State | Type | 说明 |
|-------|------|------|
| `isCancelling` | Boolean | 取消操作进行中，防止重复点击 |

### chatApi 新增/修改

| Function | 说明 |
|----------|------|
| `sendMessage(chatId, content, onChunk, onDone, onError, signal)` | 修改：新增 `signal` 参数（AbortSignal） |
| `cancelChat(chatId)` | 新增：调用 `POST /chats/{chat_id}/cancel` |
