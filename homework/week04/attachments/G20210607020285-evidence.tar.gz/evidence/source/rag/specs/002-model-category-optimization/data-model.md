# Data Model: 模型管理优化

**Feature**: 002-model-category-optimization | **Date**: 2026-10-28

## Entity: Model（模型）

**Table**: `llm_gateway.models`（PostgreSQL schema: `llm_gateway`）

### Fields

| 字段 | 类型 | 约束 | 说明 | 变更类型 |
|------|------|------|------|----------|
| `id` | VARCHAR(36) | PK, UUID | 模型唯一标识 | 不变 |
| `name` | VARCHAR(100) | NOT NULL, 复合唯一(provider, name) | API 模型标识符 | **修改**：新增复合唯一约束 |
| `display_name` | VARCHAR(200) | NULLABLE | 模型显示名称（缺省使用 name） | **新增** |
| `category` | VARCHAR(20) | NOT NULL, DEFAULT 'chat' | 模型分类枚举值 | **新增** |
| `provider` | VARCHAR(100) | NOT NULL | 模型供应商名称 | **新增** |
| `context_tokens` | INTEGER | NOT NULL | 上下文窗口大小（原 max_tokens） | **重命名** |
| `url` | VARCHAR(500) | NOT NULL | LLM API 端点 URL | 不变 |
| `api_key_encrypted` | TEXT | NOT NULL | Fernet 加密后的 API Key | 不变 |
| `rpm` | INTEGER | NOT NULL | Rate Limit: Requests Per Minute | 不变 |
| `tpm` | INTEGER | NOT NULL | Rate Limit: Tokens Per Minute | 不变 |
| `input_per_million` | NUMERIC(10,4) | NOT NULL | 输入 token 价格/百万 | 不变 |
| `output_per_million` | NUMERIC(10,4) | NOT NULL | 输出 token 价格/百万 | 不变 |
| `cached_input_per_million` | NUMERIC(10,4) | NOT NULL | 缓存命中 token 价格/百万 | 不变 |
| `created_at` | TIMESTAMP | NOT NULL | 创建时间（UTC） | 不变 |
| `updated_at` | TIMESTAMP | NOT NULL | 最后更新时间（UTC） | 不变 |

### Constraints

- **Primary Key**: `id`
- **Composite Unique**: `(provider, name)` — 同一供应商下模型名称不可重复
- **NOT NULL**: `category`, `provider`, `context_tokens`, `name`, `url`, `api_key_encrypted`, `rpm`, `tpm`, 价格字段
- **DEFAULT**: `category` 默认值为 `'chat'`（兼容旧数据）

### Category Enum Values

| 值 | 中文标签 | 说明 |
|----|---------|------|
| `chat` | 对话模型 | 默认分类，用于 SSE 流式对话 |
| `embedding` | Embedding 模型 | 文本向量化 |
| `rerank` | ReRank 模型 | 搜索结果重排序 |
| `vision` | 视觉模型 | 图像理解 |
| `speech` | 语音模型 | 语音处理 |

### Validation Rules（应用层 Pydantic）

- `category`: `Literal['chat', 'embedding', 'rerank', 'vision', 'speech']`
- `provider`: 非空字符串，min_length=1, max_length=100
- `display_name`: 可选字符串，max_length=200
- `name`: 非空字符串，min_length=1, max_length=100；在同一 provider 下唯一
- `context_tokens`: 整数，ge=1

### State Transitions

无状态机。Model 实体为 CRUD 资源型实体，无生命周期状态转换。

### Migration Plan

```python
# Alembic migration (upgrade):
def upgrade():
    # 1. 新增列
    op.add_column('models', sa.Column('category', sa.String(20), nullable=False, server_default='chat'), schema='llm_gateway')
    op.add_column('models', sa.Column('provider', sa.String(100), nullable=False, server_default='OpenAI'), schema='llm_gateway')
    op.add_column('models', sa.Column('display_name', sa.String(200), nullable=True), schema='llm_gateway')

    # 2. 重命名列
    op.alter_column('models', 'max_tokens', new_column_name='context_tokens', schema='llm_gateway')

    # 3. 添加复合唯一约束
    op.create_unique_constraint('uq_models_provider_name', 'models', ['provider', 'name'], schema='llm_gateway')

    # 4. 移除 server_default（仅在迁移时使用）
    op.alter_column('models', 'category', server_default=None, schema='llm_gateway')
    op.alter_column('models', 'provider', server_default=None, schema='llm_gateway')
```

### Relationships

- Model 与 Chat 为一对多关系（一个模型可被多个会话引用），通过 `chat.model_id` 外键关联。本特性不修改此关系。
- Model 无与其他实体的直接关联。

### Indexes

- 建议为 `category` 列添加索引以加速分类筛选查询：`CREATE INDEX idx_models_category ON llm_gateway.models(category)`
- 复合唯一约束 `(provider, name)` 自动创建唯一索引
