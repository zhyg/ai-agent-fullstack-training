# Data Model: 开发者门户平台

**Feature**: 001-developer-portal | **Date**: 2026-10-27

## Overview

三个微服务各自独立数据库，跨服务通过 ID 引用。所有表包含 `created_at` 和 `updated_at` 时间戳字段。

**开发环境数据库共享**: 三个服务共享同一个 PostgreSQL 数据库（`127.0.0.1:5432/mydb`），通过 Schema 隔离：

| 服务 | Schema | 数据库连接 |
| ---- | ------ | ---------- |
| UserManage | `user_manage` | `postgresql://admin:[REDACTED]@127.0.0.1:5432/mydb` |
| KnowledgeManage | `knowledge_manage` | `postgresql://admin:[REDACTED]@127.0.0.1:5432/mydb` |
| LlmGateway | `llm_gateway` | `postgresql://admin:[REDACTED]@127.0.0.1:5432/mydb` |

详见 [research.md R-012](./research.md#r-012-多环境配置管理devtestprod)。

---

## UserManage 服务

### users 表

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | VARCHAR(36) | PK | UUID 主键 |
| uid | VARCHAR(50) | UNIQUE, NOT NULL | 用户名，3-20 字符 |
| email | VARCHAR(100) | UNIQUE, NOT NULL | 邮箱 |
| password | VARCHAR(255) | NOT NULL | bcrypt 哈希密码 |
| role_ids | JSON | NOT NULL, DEFAULT '[]' | 关联角色 ID 列表 |
| login_fail_count | INTEGER | NOT NULL, DEFAULT 0 | 连续登录失败次数 |
| locked_until | TIMESTAMP | NULLABLE | 锁定截止时间 |
| is_active | BOOLEAN | NOT NULL, DEFAULT TRUE | 账户是否激活 |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**索引**: `idx_users_uid` (uid), `idx_users_email` (email)

### roles 表

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | VARCHAR(36) | PK | UUID 主键 |
| name | VARCHAR(50) | UNIQUE, NOT NULL | 角色名 |
| description | VARCHAR(200) | DEFAULT '' | 角色描述 |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |


**初始数据**:
- admin 角色: 系统内置管理员角色
- user 角色: 系统内置普通用户角色

---

## KnowledgeManage 服务

### prompts 表

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | VARCHAR(36) | PK | UUID 主键 |
| name | VARCHAR(100) | NOT NULL | 提示词名称（必填，不唯一） |
| version | VARCHAR(20) | NOT NULL | 版本号（必填） |
| description | TEXT | DEFAULT '' | 描述 |
| content | TEXT | NOT NULL | 提示词内容（必填） |
| creator_id | VARCHAR(36) | NOT NULL | 创建者用户 ID（引用 UserManage.users.id） |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**索引**: `idx_prompts_creator` (creator_id)

**访问控制规则**:
- 普通用户: 只能查询/编辑/删除 `creator_id = current_user_id` 的记录
- 管理员: 可查询所有记录，但只能编辑/删除 `creator_id = current_user_id` 的记录
- 被删除用户的提示词: `creator_id` 保留原始值，应用层显示为"已删除用户"

### chats 表

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | VARCHAR(36) | PK | UUID 主键 |
| title | VARCHAR(200) | NOT NULL | 会话标题 |
| user_id | VARCHAR(36) | NOT NULL | 所属用户 ID（引用 UserManage.users.id） |
| model_id | VARCHAR(36) | NULLABLE | 当前使用的模型 ID（引用 LlmGateway.models.id） |
| prompt_id | VARCHAR(36) | NULLABLE | 当前使用的提示词 ID（引用 KnowledgeManage.prompts.id） |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**索引**: `idx_chats_user` (user_id)

### messages 表

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | VARCHAR(36) | PK | UUID 主键 |
| chat_id | VARCHAR(36) | FK → chats.id, NOT NULL | 所属会话 |
| role | VARCHAR(20) | NOT NULL | 消息角色: user / assistant / system |
| content | TEXT | NOT NULL | 消息内容 |
| created_at | TIMESTAMP | NOT NULL | 创建时间（时间戳） |

**索引**: `idx_messages_chat` (chat_id), `idx_messages_chat_created` (chat_id, created_at)

---

## LlmGateway 服务

### models 表

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | VARCHAR(36) | PK | UUID 主键 |
| name | VARCHAR(100) | NOT NULL | 模型名称（必填） |
| url | VARCHAR(500) | NOT NULL | LLM API 端点 URL（必填） |
| api_key_encrypted | TEXT | NOT NULL | Fernet 加密后的 API Key（必填） |
| max_tokens | INTEGER | NOT NULL | 上下文窗口大小（必填） |
| rpm | INTEGER | NOT NULL | Rate Limit: Requests Per Minute（必填，0=不限） |
| tpm | INTEGER | NOT NULL | Rate Limit: Tokens Per Minute（必填，0=不限） |
| input_per_million | DECIMAL(10,4) | NOT NULL | 输入 token 价格/百万（必填） |
| output_per_million | DECIMAL(10,4) | NOT NULL | 输出 token 价格/百万（必填） |
| cached_input_per_million | DECIMAL(10,4) | NOT NULL | 缓存命中 token 价格/百万（必填） |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

---

## 跨服务引用关系

```text
UserManage.users (id)
    ├──→ KnowledgeManage.prompts (creator_id)     # 提示词创建者
    ├──→ KnowledgeManage.chats (user_id)          # 会话所属用户
    └──→ UserManage.roles (role_ids, JSON 数组)  # 用户关联角色

LlmGateway.models (id)
    └──→ KnowledgeManage.chats (model_id)         # 会话使用的模型

KnowledgeManage.prompts (id)
    └──→ KnowledgeManage.chats (prompt_id)        # 会话使用的提示词

KnowledgeManage.chats (id)
    └──→ KnowledgeManage.messages (chat_id)       # 会话消息
```

**注意**: 跨服务引用使用字符串 ID（UUID），不使用数据库外键约束。各服务在应用层处理引用完整性。当被引用的用户被删除时，KnowledgeManage 中的 `creator_id`/`user_id` 保留原始值，应用层检测用户不存在时显示"已删除用户"。
