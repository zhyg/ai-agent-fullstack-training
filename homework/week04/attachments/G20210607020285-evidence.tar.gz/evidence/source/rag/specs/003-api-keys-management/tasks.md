# Tasks: API Keys Management

**Input**: Design documents from `/specs/003-api-keys-management/`

**Prerequisites**: plan.md ✅, spec.md ✅, research.md ✅, data-model.md ✅, contracts/ ✅, quickstart.md ✅

**Tests**: Not explicitly requested — test tasks omitted. Validate via quickstart.md.

**Organization**: Tasks grouped by user story. US1+US2 (P1 创建+删除) share one phase; US3+US4 (P2 编辑+列表) share one phase.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: US1=创建, US2=删除, US3=编辑名称, US4=查看列表

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: No new project setup needed — all files are additions to existing UserManage and frontend projects.

_(此阶段无任务，项目已有完整的基础设施)_

---

## Phase 2: Foundational (Backend Core + Frontend Skeleton)

**Purpose**: Build the complete backend API and frontend page skeleton that all user stories depend on.

**⚠️ CRITICAL**: All user story work depends on this phase being complete.

- [x] T001 [P] Create Alembic migration `002_add_api_keys.py` in `UserManage/alembic/versions/002_add_api_keys.py` — 创建 `api_keys` 表（schema 从 `settings.database.db_schema` 读取），包含字段：`id` VARCHAR(36) PK, `user_id` VARCHAR(36) NOT NULL FK→users.id ON DELETE CASCADE, `name` VARCHAR(100) NOT NULL, `key_hash` VARCHAR(64) NOT NULL, `masked_key` VARCHAR(50) NOT NULL, `created_at` TIMESTAMP NOT NULL default now(), `last_used_at` TIMESTAMP NULLABLE；索引：`idx_api_keys_user_id` on `user_id`, `idx_api_keys_key_hash` on `key_hash`；down_revision 为 `"001_initial"`
- [x] T002 [P] Add `generate_api_key()` and `hash_api_key()` helper functions in `UserManage/app/core/security.py` — `generate_api_key()` 使用 `secrets` 模块生成格式为 `sk-` + 32位随机字符（`string.ascii_letters + string.digits`）的密钥；`hash_api_key(key: str) -> str` 使用 `hashlib.sha256` 返回十六进制哈希值；同时添加 `mask_api_key(key: "[REDACTED]"
- [x] T003 Create SQLAlchemy model ApiKey in `UserManage/app/models/api_key.py` — 参照 `UserManage/app/models/user.py` 的模式：`__tablename__ = "api_keys"`，`__table_args__` 包含两个 Index 和 `{"schema": "[REDACTED]"
- [x] T004 Create Pydantic request/response schemas in `UserManage/app/schemas/api_key.py` — 参照 `UserManage/app/schemas/user.py` 的模式：`ApiKeyCreateRequest(name: str = Field(..., min_length=1, max_length=100))`，`ApiKeyUpdateRequest(name: str = Field(..., min_length=1, max_length=100))`，`ApiKeyVerifyRequest(key: str = Field(..., min_length=1))`，`ApiKeyCreateResponse(id, name, masked_key, secret, created_at, last_used_at)`，`ApiKeyResponse(id, name, masked_key, created_at, last_used_at)` 带 `ConfigDict(from_attributes=True)`，`PaginatedApiKeyResponse(items, total, page, page_size)`，`ApiKeyVerifyResponse(valid, key_id="[REDACTED]"
- [x] T005 Implement API key business logic service in `UserManage/app/services/api_key_service.py` — 参照 `UserManage/app/services/user_service.py` 的模式：`create_api_key(db, user_id, name)` 先 COUNT 检查 ≤20 上限，调用 `generate_api_key()` 生成完整密钥，`hash_api_key()` 计算哈希，`mask_api_key()` 生成脱敏版，存入数据库，返回 `(ApiKey, secret)` 元组；`list_api_keys(db, user_id, page, page_size)` 按 `created_at DESC` 分页查询；`update_api_key_name(db, key_id, user_id, name)` 验证归属后更新名称；`delete_api_key(db, key_id, user_id)` 物理删除（`db.delete`），验证归属；`count_user_keys(db, user_id)` 统计数量；`verify_api_key(db, key)` 计算哈希后查找匹配记录并更新 `last_used_at`；所有查询需过滤 `user_id` 确保数据隔离
- [x] T006 [P] Create API router with all endpoints in `UserManage/app/routers/api_keys.py` — 参照 `UserManage/app/routers/users.py` 的模式：`APIRouter(prefix="/api-keys", tags=["API Key 管理"])`；`POST /` 创建（201, 依赖 `get_current_user`，从 token 取 `user_id`，调用 `create_api_key`，返回含 `secret` 的 `ApiKeyCreateResponse`）；`GET /` 列表（依赖 `get_current_user`，支持 `page`/`page_size` Query 参数）；`PUT /{key_id}` 更新名称（依赖 `get_current_user`，验证 `key_id` 归属）；`DELETE /{key_id}` 删除（依赖 `get_current_user`，返回 `{"message": "[REDACTED]"
- [x] T007 Register api_keys router in `UserManage/app/main.py` — 在 `app.include_router` 区域添加 `app.include_router(api_keys.router, prefix="[REDACTED]"

**Checkpoint**: Backend API fully functional. Can test with curl: login → create key → list keys → update name → delete key.

---

## Phase 3: US1 创建 + US2 删除 (Priority: P1) 🎯 MVP

**Goal**: Users can create API keys (with one-time secret display) and delete keys (with confirmation).

**Independent Test**: Login → create a key → see secret popup → copy secret → close popup → key appears in list → delete the key → confirm → key disappears.

### Implementation for User Story 1 (创建) & User Story 2 (删除)

- [x] T008 [P] [US1] Create API service layer in `frontend/src/services/apiKeyApi.js` — 参照 `frontend/src/services/promptApi.js` 的模式：axios 实例（baseURL 使用 `VITE_USER_MANAGE_URL` 或 `/api/user`，附加 JWT interceptor 和 401 interceptor）；导出函数：`listApiKeys(page, pageSize)`, `createApiKey(name)`, `updateApiKey(keyId, name)`, `deleteApiKey(keyId)`
- [x] T009 [P] [US1] Create Pinia store in `frontend/src/stores/apiKey.js` — 参照 `frontend/src/stores/` 下现有 store 的模式：`defineStore('apiKey')`；state 包含 `keys: "[REDACTED]"
- [x] T010 [US1] [US2] Create API Keys management page in `frontend/src/views/ApiKeyManagement.vue` — 参考 `MyKnowlegeWebDemo/src/views/ApiKeyManagement.vue` 的完整页面结构和样式：页面标题 "API keys"，描述文字说明密钥安全须知和上限 20 个；工具栏右侧显示 `{keyCount} / 20` 计数和 "创建 API key" 按钮（达到上限时 `disabled`）；`a-table` 展示列：名称、Tracking ID、Key（脱敏）、创建日期、最新使用日期、操作（编辑/删除图标按钮）；分页配置 `pageSize: "[REDACTED]"
- [x] T011 [P] [US1] Add route for API keys page in `frontend/src/router/index.js` — 在 `children` 数组中（`path: '/'` 的子路由）添加 `{ path: 'api-keys', name: 'ApiKeyManagement', component: "[REDACTED]"
- [x] T012 [P] [US1] Add "API keys" menu item under AI dropdown in `frontend/src/components/layout/AppLayout.vue` — 在 AI 下拉菜单的 `a-menu` 中添加 `<a-menu-item key="api-keys"><router-link to="/api-keys">API keys</router-link></a-menu-item>`（位于 "模型管理" 之后）；更新 `aiRoutes` 数组添加 `'/api-keys'`；更新 `routeToKey` 对象添加 `'/api-keys': "[REDACTED]"

**Checkpoint**: Users can navigate to API keys page, create a key (see + copy secret once), and delete a key with confirmation. Full create+delete cycle works independently.

---

## Phase 4: US3 编辑名称 + US4 查看列表 (Priority: P2)

**Goal**: Users can edit key names and the list page fully supports search filtering and pagination.

**Independent Test**: Edit a key's name → name updates in list. Type in search box → list filters in real-time. Create 11+ keys → pagination works.

### Implementation for User Story 3 (编辑名称) & User Story 4 (查看列表)

- [x] T013 [P] [US3] Add `updateKeyName` action to Pinia store in `frontend/src/stores/apiKey.js` — 调用 `apiKeyApi.updateApiKey(keyId, name)`，成功后更新 `keys` 数组中对应项的 `name` 字段
- [x] T014 [P] [US3] Implement edit name modal logic in `frontend/src/views/ApiKeyManagement.vue` — 复用 T010 已创建的模态框组件，添加编辑模式逻辑：点击编辑图标按钮时设置 `editingId` 和 `form.name` 为当前记录值，打开模态框标题为 "修改 API key"，提交时调用 store 的 `updateKeyName`，成功后 `message.success('名称已保存')`；添加 `openEdit(record)`, `openCreate()` 切换编辑/创建模式
- [x] T015 [P] [US4] Add search input with real-time filtering in `frontend/src/views/ApiKeyManagement.vue` — 在工具栏区域添加 `a-input-search` 组件（`placeholder="[REDACTED]"
- [x] T016 [P] [US4] Implement table pagination and empty state in `frontend/src/views/ApiKeyManagement.vue` — 配置 `a-table` 的 `pagination` 属性：`{ pageSize: "[REDACTED]"

**Checkpoint**: All 4 user stories functional. Edit name works, list with search and pagination works. Complete feature ready.

---

## Phase 5: Polish & Cross-Cutting Concerns

**Purpose**: Internal integration endpoint, validation, and cleanup.

- [x] T017 [P] Verify the internal verify endpoint works in `UserManage/app/routers/api_keys.py` — 手动测试 `POST /api/user/api-keys/verify` 端点：传入有效完整密钥返回 `{"valid":"[REDACTED]"
- [ ] T018 Run quickstart.md end-to-end validation — 按 `specs/003-api-keys-management/quickstart.md` 的 Step 1-6 逐步验证：数据库迁移 → 后端启动 → API curl 测试（创建/列表/编辑/删除/验证） → 前端启动 → 浏览器端到端验证 → 边界条件（20个上限、纯空格名称、未登录重定向）
- [x] T019 [P] Add error handling for network failures and edge cases in `frontend/src/views/ApiKeyManagement.vue` — 为所有 store 操作（create/delete/update/fetch）添加 try-catch，失败时 `message.error('操作失败，请重试')`；创建/删除/编辑按钮在请求中显示 loading 状态；确保组件 `onBeforeUnmount` 清理密钥展示状态

---

## Dependencies & Execution Order

### Phase Dependencies

- **Foundational (Phase 2)**: No external dependencies — can start immediately
- **US1+US2 (Phase 3)**: Depends on Phase 2 completion (backend API must be running)
- **US3+US4 (Phase 4)**: Depends on Phase 3 completion (page and store must exist)
- **Polish (Phase 5)**: Depends on Phase 4 completion

### Within Phase 2 (Foundational)

- T001 (migration) + T002 (security) → 并行，无依赖
- T003 (model) → 依赖 T001（需要表结构定义）+ T002（需要 hash 函数）
- T004 (schemas) → 依赖 T003（需要 model 字段信息）
- T005 (service) → 依赖 T003 + T004
- T006 (router) → 依赖 T005
- T007 (register) → 依赖 T006

### Within Phase 3 (US1+US2)

- T008 (api service) + T009 (store) → 并行，不同文件
- T010 (Vue page) → 依赖 T009（需要 store）
- T011 (route) + T012 (menu) → 并行，与 T010 可并行（不同文件）

### Within Phase 4 (US3+US4)

- T013 + T014 + T015 + T016 → 大部分可并行（T014 依赖 T013，T015/T016 独立）

---

## Parallel Example: Phase 2 (Foundational)

```bash
# Launch together (different files):
Task T001: "Create Alembic migration 002_add_api_keys.py in UserManage/alembic/versions/"
Task T002: "Add generate_api_key() and hash_api_key() in UserManage/app/core/security.py"
```

## Parallel Example: Phase 3 (US1+US2)

```bash
# Launch together (different files):
Task T008: "Create API service in frontend/src/services/apiKeyApi.js"
Task T009: "Create Pinia store in frontend/src/stores/apiKey.js"
Task T011: "Add route in frontend/src/router/index.js"
Task T012: "Add menu item in frontend/src/components/layout/AppLayout.vue"
```

---

## Implementation Strategy

### MVP First (US1 创建 Only)

1. Complete Phase 2: Foundational (全部后端 API)
2. Complete Phase 3 前半: T008-T010 仅实现创建功能
3. **STOP and VALIDATE**: 用户可以创建 Key 并看到完整密钥
4. 继续 Phase 3 后半: 添加删除功能
5. Deploy/demo if ready

### Incremental Delivery

1. Phase 2 → Backend API 完整可用（curl 验证）
2. Phase 3 → 前端创建+删除完整可用（MVP!）
3. Phase 4 → 编辑+列表搜索+分页完整可用
4. Phase 5 → 内部验证端点+端到端验证+错误处理
5. 每个阶段增加价值而不破坏前序功能

---

## Notes

- [P] tasks = different files, no dependencies on same file
- Backend router (T006) implements all endpoints in one task to avoid same-file conflicts
- Frontend Vue page (T010) creates the full page skeleton, Phase 4 tasks add specific feature logic
- Reference implementation: `MyKnowlegeWebDemo/src/views/ApiKeyManagement.vue` for exact UI behavior and styling
- Key security: complete secret returned only in POST response, never stored or returned again
