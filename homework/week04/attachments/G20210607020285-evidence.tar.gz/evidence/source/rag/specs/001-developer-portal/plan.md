# Implementation Plan: 开发者门户平台

**Branch**: `001-developer-portal` | **Date**: 2026-10-27 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-developer-portal/spec.md`

## Summary

开发一个前后端分离的开发者门户平台，提供用户管理、提示词管理、模型管理（LLM Gateway）和会话管理功能。前端使用 Vue3 + Ant Design Vue 4.x 单仓库，后端拆分为 3 个 Python3 微服务（UserManage、KnowledgeManage、LlmGateway），数据存储使用 PostgreSQL，服务间通过 RESTful API 通信。

## Technical Context

**Language/Version**: 前端 Vue 3.5 + JavaScript；后端 Python 3.x

**Primary Dependencies**:
- 前端：Vue 3、Ant Design Vue 4.x、Vue Router 4、Pinia（或 reactive stores）
- 后端 UserManage：FastAPI、SQLAlchemy、passlib（密码哈希）、PyJWT（认证令牌）、Pydantic V2（接口参数校验）
- 后端 KnowledgeManage：FastAPI、SQLAlchemy、Pydantic V2
- 后端 LlmGateway：FastAPI、SQLAlchemy、httpx（调用外部 LLM API）、Pydantic V2

**Storage**: PostgreSQL（每个微服务独立数据库或独立 schema）

**Testing**: 前端 Vitest；后端 pytest + httpx AsyncClient

**Target Platform**: 现代浏览器（Chrome/Firefox/Edge）+ Linux 服务器

**Project Type**: web-application（前后端分离，微服务架构）

**Performance Goals**: 页面加载 < 2s，API 响应 < 500ms（常规 CRUD）

**Constraints**: 密码哈希存储，API Key 加密存储，登录失败锁定（5 次/15 分钟）

**Scale/Scope**: 内部平台，预计 10-100 用户，5 个主页面（登录、注册、提示词、模型、会话、权限）

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

constitution.md 为模板占位符，无活跃原则需要检查。GATE 通过。

## Project Structure

### Documentation (this feature)

```text
specs/001-developer-portal/
├── plan.md              # 本文件
├── research.md          # Phase 0 输出
├── data-model.md        # Phase 1 输出
├── quickstart.md        # Phase 1 输出
├── contracts/           # Phase 1 输出
│   ├── user-manage-api.md
│   ├── knowledge-manage-api.md
│   └── llm-gateway-api.md
└── tasks.md             # Phase 2 输出（/speckit-tasks 生成）
```

### Source Code (repository root)

```text
# 前端（单仓库）
frontend/
├── src/
│   ├── components/
│   │   ├── layout/          # AppLayout 等布局组件
│   │   ├── auth/            # Login, Register 表单组件
│   │   ├── prompt/          # PromptCard, PromptCreateModal, PromptFormDrawer 等
│   │   ├── model/           # ModelCard, ModelFormDrawer 等
│   │   ├── chat/            # ChatArea, ChatList, MessageInput 等
│   │   └── permission/      # UserTable, RoleTable, RoleFormModal 等
│   ├── views/
│   │   ├── Login.vue
│   │   ├── Register.vue
│   │   ├── PromptManagement.vue
│   │   ├── ModelManagement.vue
│   │   ├── ChatManagement.vue
│   │   └── PermissionManagement.vue
│   ├── stores/              # Pinia stores 或 reactive stores
│   │   ├── user.js
│   │   ├── prompt.js
│   │   ├── model.js
│   │   ├── chat.js
│   │   └── permission.js
│   ├── services/            # API 调用层
│   │   ├── userApi.js
│   │   ├── promptApi.js
│   │   ├── modelApi.js
│   │   └── chatApi.js
│   ├── router/
│   │   └── index.js
│   ├── utils/
│   ├── App.vue
│   └── main.js
├── .env.development         # 开发环境配置（后端服务地址等）
├── .env.test                # 测试环境配置
├── .env.production          # 生产环境配置
├── public/
├── index.html
├── vite.config.js
└── package.json

# 后端 - UserManage 服务（独立仓库）
UserManage/
├── app/
│   ├── main.py              # FastAPI app 入口
│   ├── models/              # SQLAlchemy models
│   │   ├── user.py
│   │   └── role.py
│   ├── schemas/             # Pydantic schemas
│   │   ├── user.py
│   │   └── role.py
│   ├── routers/             # API 路由
│   │   ├── auth.py          # 登录/注册/退出
│   │   ├── users.py         # 用户 CRUD
│   │   └── roles.py         # 角色 CRUD
│   ├── services/            # 业务逻辑
│   │   ├── auth_service.py
│   │   ├── user_service.py
│   │   └── role_service.py
│   ├── core/
│   │   ├── config.py        # 配置加载（YAML 多环境）
│   │   ├── security.py      # JWT + 密码哈希
│   │   └── database.py      # DB 连接
│   └── dependencies.py      # 依赖注入（当前用户、权限校验）
├── config.dev.yaml          # 开发环境配置
├── config.test.yaml         # 测试环境配置
├── config.prod.yaml         # 生产环境配置
├── tests/
├── alembic/                 # 数据库迁移
├── requirements.txt
└── Dockerfile

# 后端 - KnowledgeManage 服务（独立仓库）
KnowledgeManage/
├── app/
│   ├── main.py
│   ├── models/
│   │   ├── prompt.py
│   │   ├── chat.py
│   │   └── message.py
│   ├── schemas/
│   │   ├── prompt.py
│   │   └── chat.py
│   ├── routers/
│   │   ├── prompts.py       # 提示词 CRUD
│   │   └── chats.py         # 会话 CRUD
│   ├── services/
│   │   ├── prompt_service.py
│   │   └── chat_service.py
│   ├── core/
│   │   ├── config.py        # 配置加载（YAML 多环境）
│   │   └── database.py
│   └── dependencies.py
├── config.dev.yaml
├── config.test.yaml
├── config.prod.yaml
├── tests/
├── alembic/
├── requirements.txt
└── Dockerfile

# 后端 - LlmGateway 服务（独立仓库）
LlmGateway/
├── app/
│   ├── main.py
│   ├── models/
│   │   └── model.py
│   ├── schemas/
│   │   └── model.py
│   ├── routers/
│   │   └── models.py        # 模型配置 CRUD
│   ├── services/
│   │   ├── model_service.py
│   │   └── llm_proxy.py     # LLM API 代理
│   ├── core/
│   │   ├── config.py        # 配置加载（YAML 多环境）
│   │   └── database.py
│   └── dependencies.py
├── config.dev.yaml
├── config.test.yaml
├── config.prod.yaml
├── tests/
├── alembic/
├── requirements.txt
└── Dockerfile
```

**Structure Decision**: 采用微服务架构，前端单仓库 + 后端 3 个独立仓库。前端通过 Vite 内置的 `.env` 文件（development/test/production）管理多环境后端服务地址。每个后端服务遵循 FastAPI 标准分层结构（routers → services → models），使用 SQLAlchemy ORM + Alembic 迁移，并通过三份 YAML 配置文件（config.dev/test/prod.yaml）管理多环境数据库和服务地址。前端参考 MyKnowlegeWebDemo 的组件结构，使用 Ant Design Vue 4.x 组件库。

## Complexity Tracking

> Constitution 无活跃原则，无违规项。
