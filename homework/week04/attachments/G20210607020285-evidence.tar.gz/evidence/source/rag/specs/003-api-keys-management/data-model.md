# Data Model: API Keys Management

**Feature**: 003-api-keys-management
**Date**: 2026-10-28

## Entity: ApiKey

**Table name**: `api_keys`
**Schema**: `user_manage`（与 UserManage 服务其他表一致）

### Fields

| Field | Type | Nullable | Default | Description |
|-------|------|----------|---------|-------------|
| `id` | VARCHAR(36) | NOT NULL | UUID v4 | 主键，Tracking ID |
| `user_id` | VARCHAR(36) | NOT NULL | — | 所属用户 ID，外键关联 users.id |
| `name` | VARCHAR(100) | NOT NULL | — | 用户自定义的 Key 名称 |
| `key_hash` | VARCHAR(64) | NOT NULL | — | 完整密钥的 SHA-256 哈希值，用于验证 |
| `masked_key` | VARCHAR(50) | NOT NULL | — | 脱敏版本，如 `[REDACTED_API_TOKEN]...WxYz` |
| `created_at` | TIMESTAMP | NOT NULL | UTC now | 创建时间 |
| `last_used_at` | TIMESTAMP | NULL | NULL | 最后使用时间，初始为 NULL（前端显示"尚未使用"） |

### Indexes

| Index Name | Columns | Purpose |
|-----------|---------|---------|
| `idx_api_keys_user_id` | `user_id` | 按用户查询 Key 列表 |
| `idx_api_keys_key_hash` | `key_hash` | 验证 Key 时按哈希值快速查找 |

### Constraints

| Constraint | Type | Description |
|-----------|------|-------------|
| `pk_api_keys` | PRIMARY KEY | `id` |
| `fk_api_keys_user` | FOREIGN KEY | `user_id` → `users.id`（级联删除） |
| `chk_api_keys_name` | CHECK | `LENGTH(TRIM(name)) > 0`（名称去空格后非空） |

### Relationships

- **ApiKey → User**: "[REDACTED]"
- **User → ApiKey**: "[REDACTED]"
- 级联删除：用户被删除时，其所有 API Key 一并删除

### State Transitions

```
[创建] → Active (正常使用)
Active → [物理删除] (不可恢复)
```

无其他状态转换（不支持禁用/恢复/过期等状态）。

### Validation Rules

- `name`: 1-100 字符，去除首尾空格后非空
- `key_hash`: 64 字符的 SHA-256 十六进制字符串
- `masked_key`: 格式为 `sk-{前8位}...{后4位}`
- 每个用户的 Key 数量上限: 20

## Entity: User (existing, no changes)

现有 User 模型无需修改。通过 `user_id` 外键关联即可。

## Key Generation Flow

```
1. 生成: sk- + secrets.token_urlsafe(24)[:32] → 完整 Key（如 [REDACTED_API_TOKEN]...）
2. 计算哈希: SHA-256(完整 Key) → key_hash
3. 生成脱敏版: sk-{Key[3:11]}...{Key[-4:]} → masked_key
4. 存储: (id, user_id, name, key_hash, masked_key, created_at)
5. 返回: 完整 Key（仅此一次，不存储）
```

## Key Verification Flow

```
1. LLM Gateway 收到请求，提取完整 Key
2. 调用 UserManage /api/user/api-keys/verify，传入完整 Key
3. UserManage 计算 SHA-256(Key)，在 api_keys 表查找匹配的 key_hash
4. 找到 → 返回有效 + user_id；未找到 → 返回无效
5. 找到时更新 last_used_at 为当前时间
```
