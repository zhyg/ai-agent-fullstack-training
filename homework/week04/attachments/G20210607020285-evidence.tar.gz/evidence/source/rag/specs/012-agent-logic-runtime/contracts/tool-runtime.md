# Contract: 统一 Tool Runtime 与 13 工具契约

**Feature**: 012-agent-logic-runtime | 内部契约（`agent_runtime/tools/runtime.py`），仅 planning_reasoning 流程使用

工具键与既有 `schemas/agent.py::TOOL_KEYS` 一致（13 个）。未启用工具不进入模型 tools 列表（FR-023）。

---

## 1. 统一执行入口（FR-029/030）

```python
async def execute_tool(
    call_id: str,            # 模型 tool_call id，全程透传不丢失
    tool_name: str,          # TOOL_KEYS 之一（且必须在快照启用清单内）
    args: dict,              # 模型入参（JSON）
    ctx: RequestRuntimeState,# 快照/累积片段/plan/白名单/取消信号
) -> ToolResult
```

**执行规则**：
1. 取消检查：`ctx.cancel_event` 已置位 → `{success:false, code:"cancelled"}`，不执行
2. 入参校验：按工具 Pydantic 模型校验，失败 → `{success:false, code:"invalid_args", content:校验错误说明}`（不抛异常、不重试）
3. 执行：内部异常最多重试 3 次，仍失败 → `{success:false, code:"execution_failed", content:错误摘要}`
4. 串行执行：一轮决策内多个 tool_calls 按序逐个执行，每个执行前重复取消检查
5. 截断：content 超 `tool_result_max_tokens`（默认 4000，tiktoken 估算）→ 截断并附 `"\n[结果已截断，共 N 条]"`
6. 轨迹：每次执行包 `agent.tool.{tool_name}` span，属性 `tool.call_id`、`agent.input`（args）、`agent.output`（ToolResult）

**结果信封（ToolResult）**：

```json
{"success": true, "code": "ok", "content": "模型可见字符串（JSON 或文本）", "artifact_path": null}
```

结果码：`ok` / `empty_result` / `invalid_args` / `execution_failed` / `forbidden_sql` / `url_not_allowed` / `cancelled`。
失败/空结果一律回传模型继续决策，不终止流程（FR-025）；回传为 OpenAI `{"role":"tool","tool_call_id":call_id,"content":json.dumps(result)}` 消息。

---

## 2. 计划管理工具（FR-024，仅操作本次请求内存 plan）

| 工具 | 入参 | 成功 content | 失败情形 |
|---|---|---|---|
| createPlan | `{title: str, steps: [{description: str}]}`（steps 1–50） | `{plan_id, title, steps:[{step_id, description, status:"pending"}]}` | 已存在 plan → invalid_args（单请求单 plan，需先 delete） |
| listPlan | `{}` | `{plans: [{plan_id, title, step_count, done_count}]}`（0 或 1 条） | — |
| getPlan | `{plan_id: str}` | 完整 plan JSON | plan_id 不匹配 → invalid_args |
| updatePlan | `{plan_id: str, title?: str, steps?: [{step_id?: str, description?: str, status?: "pending|in_progress|done"}]}` | 更新后完整 plan | plan_id 不匹配 / step_id 不存在 → invalid_args |
| deletePlan | `{plan_id: str}` | `{deleted: true}` | plan_id 不匹配 → invalid_args |

plan 不落库；请求结束/停止随 state 丢弃。

## 3. 知识工具（FR-025，行为与共用步骤一致）

| 工具 | 入参 | 成功 content | 空/失败语义 |
|---|---|---|---|
| rewriteQuestion | `{question: str}` | `{rewritten_question: str}`（JSON 容错+业务重试 3 次） | 最终校验失败 → execution_failed |
| bm25Search | `{query: str, top_k?: int(1–100, 默认快照 keyword_top_k)}` | `{chunks: [{chunk_id, document_id, file_name, content, score, sqlite_url?}]}` | 空 → `{success:true, code:"empty_result", content:"{\"chunks\":[]}"}` |
| vectorSearch | `{query: str, top_k?: int(1–100, 默认 vector_top_k)}` | 同上 | embedding 失败 → execution_failed（工具内不终止流程，回传模型）；空同上 |
| hybridSearch | `{query: str, top_k?: int(1–100, 默认 hybrid_top_k)}` | 同上（RRF 融合后截断） | 同上 |
| rerank | `{query: str, chunk_ids: [str], top_n?: int(默认 rerank_top_n)}` | `{chunks: [...按 relevance 排序]}`（chunk_ids 限本次已检索片段） | 网关失败 → 降级按原始分截断（code=ok，content 附 degraded:true）；未知 chunk_id → invalid_args |
| zip | `{question: str, chunk_ids: [str]}` | `{kept_chunk_ids: [str]}`（过滤式压缩，模型输出 kept_indexes 经映射；越界/重复/非整数业务重试） | 空数组合法 → empty_result；最终校验失败 → execution_failed |

检索类工具命中片段即并入 `ctx.chunks`（去重累积）并将 `sqlite_url` 加入白名单；压缩保留片段补充文档名。

## 4. 表格工具（FR-026/027）

### listTableMetaData

- 入参：`{sqlite_url: str}`
- 校验：URL ∈ `ctx.sqlite_whitelist`（本次请求检索片段出现过的地址），否则 `{success:false, code:"url_not_allowed"}`
- 执行：预签名下载（≤50MB / ≤30s）→ 本地缓存 `/tmp/km_sqlite_cache/{sha256(url)}.db`（TTL 1h）→ 只读连接读 `sqlite_master` + `PRAGMA table_info`
- 成功 content：`{tables: [{name, description, columns: [{name, type}]}]}`

### sqlExecute

- 入参：`{sqlite_url: str, sql_query: str}`
- 校验（顺序）：
  1. URL 白名单（同上）→ `url_not_allowed`
  2. SQL 只读校验：剥注释/空白后以 SELECT 开头；`sqlite3.complete_statement` 单语句；拒绝多语句、DDL/DML/ATTACH、写 PRAGMA → `{success:false, code:"forbidden_sql"}`
  3. 连接级只读：`sqlite3.connect("file:{path}?mode=ro", uri=True)`（双保险）
- 成功 content：`{columns: [str], rows: [[...]], row_count: N}`；行数上限 500，超出截断附说明
- 执行失败（语法错误等）→ execution_failed 回传模型

---

## 5. 模型侧 tools 声明

规划推理决策调用使用 OpenAI function calling 格式：启用工具逐个映射为 `{"type":"function","function":{"name":tool_key,"description":中文用途说明,"parameters":入参 JSON Schema}}`；planning 提示词后追加协议说明（可先 createPlan、按规划推进、无需更多工具时直接给出最终答复意图）。每次决策调用计一轮（FR-028），达 loop_count 上限强制进入答案生成并记 `forced_convergence` 事件。