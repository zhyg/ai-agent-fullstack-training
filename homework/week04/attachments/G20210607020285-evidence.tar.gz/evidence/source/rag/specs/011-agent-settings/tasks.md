# Tasks: 智能体菜单功能完善（智能体配置管理）

**Input**: Design documents from `/specs/011-agent-settings/`

**Prerequisites**: plan.md、spec.md、research.md、data-model.md、contracts/agent-api.md、quickstart.md

**Tests**: 后端 pytest 测试按 plan.md Testing 约定与 research.md R10 包含（`KnowledgeManage/tests/test_agents.py`）；前端无单测基建，按 quickstart.md 手动验收。

**Organization**: 任务按用户故事分组，每个故事可独立实现、独立验收、增量交付。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行（不同文件、无未完成依赖）
- **[Story]**: 所属用户故事（US1–US4）；Setup/Foundational/Polish 无故事标签
- 描述含确切文件路径；路径相对仓库根 `/Volumes/MySSD/mycode/Ai/myKnowlege`

## Path Conventions

- 后端：`KnowledgeManage/app/{models,schemas,routers,services}/`、`KnowledgeManage/alembic/versions/`、`KnowledgeManage/tests/`
- 前端：`frontend/src/{services,stores,utils,views,components}/`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 确认现有基线可用，本期无新依赖、无新服务

- [X] T001 [P] 验证后端基线：在 KnowledgeManage/ 下执行 `alembic upgrade head` 与 `python -m pytest tests/ -x -q` 确认现有迁移与测试全绿（Python：/Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python），记录当前 alembic head revision 供 T004 衔接
- [X] T002 [P] 验证前端基线：确认 frontend/package.json 已含 ant-design-vue 4.x、@ant-design/icons-vue、pinia、axios 依赖，frontend/vite.config.js 已配置 /api/knowledge、/api/llm、/api/user 代理，`npm run build` 通过

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 数据模型、迁移预置、校验 Schema、前端共享常量/API/Store——所有用户故事的共同前置

**⚠️ CRITICAL**: 本阶段完成前不得开始任何用户故事

- [X] T003 [P] 创建 Agent 模型 KnowledgeManage/app/models/agent.py：表 `knowledge_manage.agents`，字段约束按 data-model.md——id String(36) PK 默认 uuid4；type String(20) NOT NULL UNIQUE（枚举 quick_qa/reasoning_action/planning_reasoning）；name String(100) NOT NULL UNIQUE；icon String(50) NOT NULL；description Text NOT NULL 默认 ''；status String(10) NOT NULL 默认 'enabled'（枚举 enabled/disabled）；config JSONB NOT NULL；created_at/updated_at TIMESTAMP NOT NULL 默认 utcnow（updated_at onupdate utcnow）；无外键；沿用现有 models 的 Column 声明式风格并在 models/__init__.py 导出
- [X] T004 创建 Alembic 迁移 KnowledgeManage/alembic/versions/<rev>_add_agents.py（down_revision 接 T001 记录的 head）：建 agents 表与 type/name 唯一约束；同 revision 插入三条预置数据（按 type 判存保证幂等）：quick_qa/快速问答/thunderbolt/“提供快速问答功能，用户输入问题，直接检索回答”；reasoning_action/推理行动/bulb/“提供react的多轮推理功能”；planning_reasoning/规划推理/partition/“提供plan+react的智能规划、多轮推理功能”；status 均 enabled；预置 config 按 data-model.md：prompts 各用途 null、retrieval mode=vector 且 20/20/20/15、models 各引用 null 且 max_tokens=5000、loop_count 按类型 10/100（quick_qa 无）、tools 仅 planning_reasoning 全 12 项；提供 downgrade 删表（依赖 T003）
- [X] T005 [P] 创建 Pydantic v2 Schema KnowledgeManage/app/schemas/agent.py：AgentResponse（含 id/type/name/icon/description/status/config/created_at/updated_at）、AgentUpdate（name 1–100 字符、icon、description、config）、StatusUpdate（status 枚举 enabled/disabled）、Config 嵌套模型——vector_top_k/keyword_top_k/hybrid_top_k/rerank_top_n 整数 1–100 默认 20/20/20/15；loop_count 整数 1–1000；max_tokens 整数 1–50000 默认 5000；retrieval.mode 枚举 vector/keyword/hybrid；按 type 裁剪（quick_qa 仅 5 用途 prompts、无 loop_count/tools；reasoning_action 含 sufficiency、loop_count 默认 10；planning_reasoning 含 planning、loop_count 默认 100、tools 限 12 个固定 key）；忽略未知键、校验已知键；条件必填规则（分析模型必填；mode∈{vector,hybrid} 时 embedding 必填；rerank 模型必填；用途提示词按类型必填）留出服务层校验入口；风格对齐现有 schemas/prompt.py 的 Field 约束
- [X] T006 [P] 创建前端常量 frontend/src/utils/agent.js：类型枚举与中文名映射；各类型提示词用途清单（quick_qa=clarify/rewrite/answer/compress/rerank；reasoning_action=+sufficiency；planning_reasoning=+planning）及中文标签；12 个工具 key 与中文名（createPlan/listPlan/getPlan/updatePlan/deletePlan/rewriteQuestion/bm25Search/vectorSearch/rerank/zip/listTableMetaData/sqlExecute）；内置图标库＝@ant-design/icons-vue 固定子集的 key→组件映射（含 thunderbolt/bulb/partition）；各类型默认 config 与左侧菜单项清单（4/5/6 项）
- [X] T007 [P] 创建前端 API 封装 frontend/src/services/agentApi.js：按 contracts/agent-api.md 经 /api/knowledge 代理实现 listAgents()（GET /agents）、getAgent(id)（GET /agents/{id}）、updateAgent(id, payload)（PUT /agents/{id}）、updateAgentStatus(id, status)（PATCH /agents/{id}/status）；沿用现有 services 的 axios 实例与错误处理惯例；不提供 create/delete 方法（FR-014）
- [X] T008 创建 Pinia store frontend/src/stores/agent.js：列表加载（含停用）、停用/启用动作（调 updateAgentStatus 后更新本地状态）、当前编辑智能体与未保存草稿态管理（打开弹窗深拷贝 config、取消/关闭丢弃、保存成功后刷新列表）；依赖 T007
- [X] T009 执行迁移并核验预置：KnowledgeManage/ 下 `alembic upgrade head`，查询 agents 表确认恰 3 行、type/name/description/status/config 与 T004 预置一致，重复执行 upgrade 不产生重复行（依赖 T004）

**Checkpoint**: 数据与共享层就绪——用户故事可开始（US1 必须先行交付入口，US2–US4 依赖 US1 的页面与弹窗承载）

---

## Phase 3: User Story 1 - 浏览智能体卡片与停用/启用 (Priority: P1) 🎯 MVP

**Goal**: 智能体页展示三张预置卡片（名称/图标/描述/状态），管理员可停用/启用且持久化，普通用户只读，无新建/删除入口

**Independent Test**: 进入智能体页见三张卡片；停用→刷新→启用→刷新状态保持（quickstart V-001/V-002/V-003/V-011）；普通用户无操作菜单且直连接口写操作返回 403

### Implementation for User Story 1

- [X] T010 [US1] 实现列表/详情/状态服务 KnowledgeManage/app/services/agent_service.py：list_agents 返回全部（含 disabled）；get_agent 不存在抛 404 “智能体不存在”；set_status 仅变更 status（枚举校验，非法值 400）、幂等（同状态重复请求返回当前对象）、不触碰 config（依赖 T003/T005）
- [X] T011 [US1] 实现路由 KnowledgeManage/app/routers/agents.py：GET /agents（返回 {"items":[...]}）、GET /agents/{agent_id}、PATCH /agents/{agent_id}/status；读接口 Depends(get_current_user)，PATCH 写接口 Depends(require_permission("permission_manage"))（复用 KnowledgeManage/app/dependencies.py 现有工厂，非管理员 403 “无权访问：需要 permission_manage 权限”）；不实现 POST /agents 与 DELETE（FR-014）（依赖 T010）
- [X] T012 [US1] 注册路由 KnowledgeManage/app/main.py：include agents router，沿用现有 router 注册方式（依赖 T011）
- [X] T013 [P] [US1] 后端测试 KnowledgeManage/tests/test_agents.py：预置存在性（恰 3 条、type/description/status 符合 FR-016）、GET 列表/详情/404、PATCH 停用→启用→config 不变→幂等、非法 status 400、普通用户 GET 200 而 PATCH 403；沿用现有 tests 的 client/db fixture 约定
- [X] T014 [P] [US1] 创建卡片组件 frontend/src/components/agent/AgentCard.vue：展示名称/图标（utils/agent.js key→组件映射）/描述/状态标识（disabled 置灰＋“已停用”标签）；右上角“...”a-dropdown：管理员＋enabled→[编辑,停用]、管理员＋disabled→[编辑,启用]、普通用户（userStore.isAdmin=false）不渲染操作项；无新建/删除项；emit edit/toggle-status 事件
- [X] T015 [US1] 替换占位页 frontend/src/views/AgentManagement.vue：加载 agent store 列表渲染三张 AgentCard 栅格；处理 toggle-status（调 store 动作、成功 message、失败提示）；edit 事件本期仅预留（US2 接入弹窗）；页面无新建/删除按钮（依赖 T008/T014）

**Checkpoint**: US1 独立可验收——卡片列表＋停用/启用闭环＋权限只读（V-001/V-002/V-003/V-011），即 MVP

---

## Phase 4: User Story 2 - 编辑快速问答智能体配置 (Priority: P2)

**Goal**: 快速问答编辑弹窗（左菜单 4 项：基础信息/提示词/检索策略/模型配置），配置保存持久化、重开回显、越界拦截、名称唯一、引用失效标记

**Independent Test**: 打开快速问答弹窗逐项修改保存→重开 100% 回显；输入 0/101 拦截；切换检索方式条件项正确；取消不污染；重名 409（quickstart V-004–V-008/V-010）

### Implementation for User Story 2

- [X] T016 [US2] 实现更新服务 KnowledgeManage/app/services/agent_service.py 追加 update_agent：name 跨智能体唯一预检（重名 409 “智能体名称已存在”，DB unique 约束兜底）；按 type 裁剪 config（忽略未知键）；必填用途 prompt_id 存在性校验（查同库 prompts 表，不存在 400）；条件必填（分析模型必填；mode∈{vector,hybrid} 时 embedding 必填；rerank 模型必填）；忽略请求中的 status/type；last-write-wins 无版本字段（依赖 T010）
- [X] T017 [US2] 追加 PUT /agents/{agent_id} 端点 KnowledgeManage/app/routers/agents.py：仅管理员（require_permission("permission_manage")），Body=AgentUpdate，200 返回更新后对象、400 校验失败、403 非管理员、404 不存在、409 重名（依赖 T016）
- [X] T018 [P] [US2] 后端测试 KnowledgeManage/tests/test_agents.py 追加更新用例：合法更新回显一致、越界值（0/101/50001）400、必填缺失 400、必填 prompt_id 不存在 400、重名 409、非管理员 PUT 403、PUT 携带 status/type 被忽略、quick_qa 携带 loop_count/tools 被忽略
- [X] T019 [P] [US2] 创建弹窗容器 frontend/src/components/agent/AgentEditModal.vue：a-Modal 左侧 a-menu 右侧配置区；菜单项按 type 从 utils/agent.js 取（quick_qa 4 项）；打开时深拷贝 store 草稿、菜单切换保留未保存修改、取消/关闭丢弃；“保存”触发表单校验→updateAgent→成功关闭并刷新列表；失效引用必填项拦截保存
- [X] T020 [P] [US2] 创建基础信息区 frontend/src/components/agent/sections/BasicInfoSection.vue：名称（1–100 字符必填）与描述可编辑；图标选择器仅从 utils/agent.js 内置图标库选择（网格单选），无上传入口（FR-006）
- [X] T021 [P] [US2] 创建提示词区 frontend/src/components/agent/sections/PromptsSection.vue：按 type 渲染用途下拉（quick_qa 5 个）；选项复用 GET /api/knowledge/prompts（page_size=100 循环翻页至 total，遵循现有可见性、不做用途过滤），展示名称＋版本、值为 prompt_id；已删除引用显示“已失效”tag；列表为空给“请先前往提示词管理配置”引导；必填用途未选/失效拦截保存
- [X] T022 [P] [US2] 创建检索策略区 frontend/src/components/agent/sections/RetrievalSection.vue：检索方式单选下拉（向量/关键词/混合）；mode=vector 仅显 vector_top_k、keyword 仅显 keyword_top_k、hybrid 仅显 hybrid_top_k（默认均 20、范围 1–100）；rerank_top_n 恒显示（默认 15、范围 1–100）；三召回数量独立保存切换不重置；不做重排与召回跨字段校验
- [X] T023 [P] [US2] 创建模型配置区 frontend/src/components/agent/sections/ModelsSection.vue：分析模型下拉＝模型 store 中 category=chat、向量模型＝embedding、ReRank＝rerank（复用现有 modelApi/model store 全量加载，零后端改动）；max_tokens 数字输入默认 5000 范围 1–50000；已删除模型引用显示“已失效”tag；条件必填（分析/rerank 必填，embedding 按 mode）；空列表引导“请先前往模型管理配置”
- [X] T024 [US2] 集成编辑入口 frontend/src/views/AgentManagement.vue：AgentCard edit 事件打开 AgentEditModal（传入对应 agent）；保存成功后卡片以新名称/图标/描述刷新；409/400 错误 message 提示（依赖 T019–T023）

**Checkpoint**: US2 独立可验收——快速问答完整编辑闭环（V-004–V-008/V-010），共用配置模式全部就位

---

## Phase 5: User Story 3 - 编辑推理行动智能体配置 (Priority: P3)

**Goal**: 推理行动弹窗菜单 5 项（＋循环次数），提示词 6 用途（＋资源充足判断），循环次数默认 10、范围 1–1000

**Independent Test**: 打开推理行动弹窗核对 5 项菜单与 6 个提示词下拉；循环默认 10；输入 0/1001 拦截；修改保存重开回显（quickstart V-004/V-006）

### Implementation for User Story 3

- [X] T025 [US3] 核验/补全推理行动类型规则 KnowledgeManage/app/schemas/agent.py 与 KnowledgeManage/app/services/agent_service.py：prompts 含 sufficiency 必填用途（不含 planning）、loop_count 默认 10 范围 1–1000、无 tools；PUT 越界 loop_count 400（T005/T016 已含规则则本任务仅补差异）
- [X] T026 [P] [US3] 创建循环次数区 frontend/src/components/agent/sections/LoopSection.vue：数字输入，默认值按 type（reasoning_action=10、planning_reasoning=100），范围 1–1000，越界即时提示并拦截保存
- [X] T027 [US3] 接入差异化菜单 frontend/src/components/agent/AgentEditModal.vue 与 frontend/src/components/agent/sections/PromptsSection.vue：reasoning_action 左侧菜单 5 项（＋循环次数→LoopSection）、提示词 6 下拉（＋资源充足判断 sufficiency），用途清单从 utils/agent.js 读取（依赖 T026）
- [X] T028 [P] [US3] 后端测试 KnowledgeManage/tests/test_agents.py 追加推理行动用例：loop_count 默认 10、边界 1/1000 可保存、0/1001 400、sufficiency 必填缺失 400、携带 tools 被忽略

**Checkpoint**: US3 独立可验收——类型差异化菜单/配置扩展模式验证通过

---

## Phase 6: User Story 4 - 编辑规划推理智能体配置 (Priority: P4)

**Goal**: 规划推理弹窗菜单 6 项（＋工具配置），提示词“规划分析”替换“资源充足判断”，循环默认 100，12 工具复选框默认全选且持久化

**Independent Test**: 打开规划推理弹窗核对 6 项菜单、12 复选框默认全选；取消“SQL执行”“压缩”保存重开保持；循环默认 100；“规划分析”下拉存在（quickstart V-009）

### Implementation for User Story 4

- [X] T029 [US4] 核验/补全规划推理类型规则 KnowledgeManage/app/schemas/agent.py 与 KnowledgeManage/app/services/agent_service.py：tools 仅 planning_reasoning、元素限 12 个固定 key（非法 key 400）、默认全选；prompts 含 planning（不含 sufficiency）；被取消勾选工具对应用途（rewrite/rerank/compress/检索类）转可选；loop_count 默认 100（T005/T016 已含规则则本任务仅补差异）
- [X] T030 [P] [US4] 创建工具配置区 frontend/src/components/agent/sections/ToolsSection.vue：12 个 a-checkbox（key 与中文名从 utils/agent.js 读取），默认全部勾选，勾选集合持久化到 config.tools
- [X] T031 [US4] 接入差异化菜单 frontend/src/components/agent/AgentEditModal.vue 与 frontend/src/components/agent/sections/PromptsSection.vue：planning_reasoning 左侧菜单 6 项（＋工具配置→ToolsSection）、提示词第 6 项为“规划分析”（planning）、LoopSection 默认 100；取消勾选工具时对应提示词用途必填标记转可选（依赖 T030）
- [X] T032 [P] [US4] 后端测试 KnowledgeManage/tests/test_agents.py 追加规划推理用例：tools 默认 12 项、取消两项后保存回显恰缺两 key、非法工具 key 400、取消勾选工具后对应提示词可为 null、loop_count 默认 100、携带 sufficiency 被忽略

**Checkpoint**: 全部四个故事独立可验收

---

## Phase 7: Polish & Cross-Cutting Concerns

- [X] T033 [P] 全量回归：KnowledgeManage/ 下 `python -m pytest tests/ -q` 全绿（含既有测试无回归）
- [ ] T034 按 specs/011-agent-settings/quickstart.md 执行 V-001–V-011 端到端手动验收（三服务＋前端启动、管理员/普通用户双账号），核对 SC-001–SC-006
- [X] T035 [P] 前端构建核验 frontend/ 下 `npm run build` 通过；清理调试代码与未用导入

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即可做
- **Foundational (Phase 2)**: 依赖 Setup；T004←T003、T008←T007、T009←T004；阻塞所有用户故事
- **US1 (Phase 3)**: 依赖 Foundational；T011←T010、T012←T011、T015←T008/T014
- **US2 (Phase 4)**: 依赖 US1（页面/卡片入口承载弹窗）；T017←T016、T024←T019–T023
- **US3 (Phase 5)**: 依赖 US2（复用弹窗容器与四配置区）；T027←T026
- **US4 (Phase 6)**: 依赖 US3（复用 LoopSection 与差异化菜单模式）；T031←T030
- **Polish (Phase 7)**: 依赖全部故事完成

### User Story Dependencies

- US1 独立可交付（MVP）；US2 需 US1 的页面入口；US3 需 US2 的弹窗与共用配置区；US4 需 US3 的循环次数区——本期编辑弹窗为共享容器，故事按优先级串行是最稳妥路径；后端各类型规则（T025/T029）与前端区组件（T026/T030）可提前并行准备

### Within Each User Story

- 服务先于路由；后端与前端组件可并行（不同文件）；集成任务最后
- 测试任务与实现同故事内并行编写，Checkpoint 前须全绿

### Parallel Opportunities

- Phase 2：T003/T005/T006/T007 四线并行（模型/Schema/前端常量/API 封装互不依赖）
- US1：T013（后端测试）∥ T014（卡片组件）
- US2：T018 ∥ T019 ∥ T020 ∥ T021 ∥ T022 ∥ T023 六线并行（全部不同新文件）
- US3/US4：T026/T028、T030/T032 各自并行

---

## Parallel Example: User Story 2

```bash
# 后端与前端六组件并行启动：
Task: "T018 更新接口测试 in KnowledgeManage/tests/test_agents.py"
Task: "T019 弹窗容器 in frontend/src/components/agent/AgentEditModal.vue"
Task: "T020 基础信息区 in frontend/src/components/agent/sections/BasicInfoSection.vue"
Task: "T021 提示词区 in frontend/src/components/agent/sections/PromptsSection.vue"
Task: "T022 检索策略区 in frontend/src/components/agent/sections/RetrievalSection.vue"
Task: "T023 模型配置区 in frontend/src/components/agent/sections/ModelsSection.vue"
# 全部完成后 → T024 集成
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Phase 1 Setup → Phase 2 Foundational（阻塞项，必须完成）
2. Phase 3 US1：卡片列表＋停用/启用＋权限只读
3. **STOP and VALIDATE**：V-001/V-002/V-003/V-011 独立验收
4. 可演示：智能体菜单从占位页变为可用管理页

### Incremental Delivery

1. Setup + Foundational → 数据与共享层就绪
2. US1 → 验收 → 演示（MVP）
3. US2 → 快速问答完整编辑闭环 → 验收（共用配置模式就位）
4. US3 → 循环次数＋资源充足判断 → 验收（差异化模式验证）
5. US4 → 工具配置＋规划分析 → 验收 → Phase 7 全量回归＋quickstart 验收

### Parallel Team Strategy

- 一人后端（T003–T005、T010–T012、T016–T017、T025、T029）＋一人前端（T006–T008、T014–T015、T019–T024、T026–T027、T030–T031），Foundational 完成后按故事对齐联调

---

## Notes

- [P]＝不同文件、无未完成依赖；故事标签仅出现在 US 阶段任务
- 数值约束（1–100/1–1000/1–50000）、必填联动、12 工具 key、预置描述均已 verbatim 写入对应任务，实现时无需再做决策
- 本期 MUST NOT：实现智能体运行流程、修改会话页面、改动提示词管理、提供新建/删除智能体
- 每个任务或逻辑组完成后提交；任一 Checkpoint 可停下独立验收