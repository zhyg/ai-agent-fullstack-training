# Tasks: LLM 统一模型调用网关

**Input**: Design documents from `/specs/004-llm-gateway-unified/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: Not explicitly requested in the feature specification. Test tasks are omitted.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **LlmGateway service**: `LlmGateway/app/`
- **KnowledgeManage service**: `KnowledgeManage/app/`
- New adapter layer: `LlmGateway/app/adapters/`
- New gateway core: `LlmGateway/app/gateway/`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 项目初始化、新增包结构、安装新依赖

- [x] T001 创建 `LlmGateway/app/adapters/` 包（`__init__.py`）
- [x] T002 创建 `LlmGateway/app/gateway/` 包（`__init__.py`）
- [x] T003 更新 `LlmGateway/requirements.txt` 新增 `prometheus_client`、`redis` 依赖并安装
- [x] T004 [P] 在 `LlmGateway/app/core/config.py` 中新增 `RedisConfig` 配置类（host、port、db、password），更新 `Settings` 模型
- [x] T005 [P] 在 `LlmGateway/config.dev.yaml` 中新增 `redis` 配置节（host: 127.0.0.1, port: 6379, db: 0）

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 适配器基类、能力注册表、错误码、Schema 等核心基础设施。**所有 User Story 均依赖此阶段完成。**

- [x] T006 创建统一错误码与异常类在 `LlmGateway/app/gateway/errors.py`：定义 `GatewayError` 基类及所有子类（`AuthenticationError`/401/invalid_api_key、`ModelNotFoundError`/404/model_not_found、`InvalidRequestError`/422/invalid_request、`PromptNotFoundError`/422/prompt_not_found、`SchemaValidationError`/422/schema_validation_failed、`RateLimitError`/429/rate_limit_exceeded、`AdapterUnavailableError`/502/adapter_unavailable、`UpstreamError`/502/upstream_error、`PromptServiceUnavailableError`/503/prompt_service_unavailable、`UpstreamTimeoutError`/504/upstream_timeout），每个异常含 `message`、`error_type`、`error_code`、`http_status` 属性，参考 [contracts/openai-compatible-api.md](contracts/openai-compatible-api.md) 统一错误码表
- [x] T007 在 `LlmGateway/app/models/model.py` 的 `Model` 类中新增 `capabilities` 字段：`Column(JSON, nullable=False, default=list, server_default='[]', comment="模型能力列表")`，参考 [data-model.md](data-model.md) Model 表定义
- [x] T008 [P] 更新 `LlmGateway/app/schemas/model.py`：在 `ModelCreate`、`ModelUpdate`、`ModelResponse` 三个 Pydantic 模型中新增 `capabilities: list[str]` 字段（Create/Update 默认 `["streaming"]`，Response 直接映射）
- [x] T009 创建能力注册表在 `LlmGateway/app/gateway/registry.py`：实现 `CapabilityRegistry` 类，含 `adapters: dict[str, BaseAdapter]`（provider→适配器实例）、`models: dict[str, ModelConfig]`（model_name→模型配置）、`capability_index: dict[str, list[str]]`（capability→model_name 列表）；提供 `load_from_db(db)` 方法从数据库加载所有 Model 记录并构建索引；提供 `find_models_by_capabilities(capabilities: list[str]) -> list[ModelConfig]` 方法按能力匹配模型；`ModelConfig` 数据类含 name、provider、url、api_key、capabilities、rpm、tpm、pricing 字段，参考 [data-model.md](data-model.md) CapabilityRegistry 定义
- [x] T010 创建适配器抽象基类在 `LlmGateway/app/adapters/base.py`：定义 `BaseAdapter` 抽象类，含 `provider: str` 属性、`capabilities: list[str]` 属性、`health_status: str` 属性（默认 "healthy"）；抽象方法 `async def complete(self, model_config, messages, **kwargs) -> dict`（非流式调用）和 `async def stream(self, model_config, messages, **kwargs) -> AsyncGenerator[dict, None]`（流式调用，yield 标准化事件 dict）
- [x] T011 创建 OpenAI 适配器在 `LlmGateway/app/adapters/openai_adapter.py`：继承 `BaseAdapter`，`provider="openai"`，`capabilities=["streaming", "structured_output"]`；`complete()` 方法使用 httpx 调用 OpenAI Responses API（POST model_config.url，Bearer token 认证，请求体含 model/messages/temperature/max_tokens），解析响应为统一格式；`stream()` 方法使用 httpx stream 模式，逐行解析 SSE `data:` 事件，yield `{"type": "delta", "content": "..."}` 事件，流结束时 yield `{"type": "usage", ...}` 和 `{"type": "done"}`
- [x] T012 创建 Anthropic 适配器在 `LlmGateway/app/adapters/anthropic_adapter.py`：继承 `BaseAdapter`，`provider="anthropic"`，`capabilities=["streaming"]`；`complete()` 方法使用 httpx 调用 Anthropic Messages API（POST model_config.url，`x-api-key` header 认证，请求体含 model/messages/max_tokens/system），解析响应为统一格式（映射 Anthropic 的 content blocks 到 OpenAI 兼容的 message）；`stream()` 方法类似 OpenAI 适配器但解析 Anthropic SSE 格式（`event: "[REDACTED]"
- [x] T013 创建 OpenAI Compatible 请求/响应 Schema 在 `LlmGateway/app/schemas/chat_completion.py`：定义 `ChatCompletionMessage`（role: str 枚举 system/user/assistant，content: str min_length=1）、`ResponseFormat`（type: str 枚举 text/json_object 默认 text，schema: dict|None 默认 None）、`ChatCompletionRequest`（model: str 必填，messages: list[ChatCompletionMessage] min_length=1，stream: bool 默认 False，temperature: float 默认 1.0 ge=0 le=2，max_tokens: int|None 默认 None，response_format: ResponseFormat|None 默认 None，prompt_name: str|None 默认 None，prompt_version: str|None 默认 None）；定义 `ChatCompletionChoice`（index: int，message: dict，finish_reason: str）、`UsageInfo`（prompt_tokens: int，completion_tokens: int，total_tokens: int，cached_tokens: int 默认 0，reasoning_tokens: int 默认 0）、`ChatCompletionResponse`（id: str，object: str="chat.completion"，created: int，model: str，choices: list[ChatCompletionChoice]，usage: UsageInfo），参考 [contracts/openai-compatible-api.md](contracts/openai-compatible-api.md) 请求/响应 Schema

**Checkpoint**: 适配器层和 Gateway 核心基础设施就绪，所有 User Story 可开始实现

---

## Phase 3: User Story 1 - 统一模型调用 API (Priority: P1) 🎯 MVP

**Goal**: 调用方通过统一 API 可调用不同供应商模型并返回格式一致的响应

**Independent Test**: 向 `/api/llm/v1/chat/completions` 发送两个不同模型的请求（stream=false），均返回 200 且响应结构一致

### Implementation for User Story 1

- [x] T014 [P] [US1] 创建 API Key 鉴权依赖在 `LlmGateway/app/dependencies.py`：新增 `async def get_api_key_user(credentials: "[REDACTED]"
- [x] T015 [US1] 创建 Gateway 服务在 `LlmGateway/app/services/llm_gateway_service.py`：实现 `LLMGatewayService` 类，核心方法 `async def process_request(request: ChatCompletionRequest, user: dict, db: Session) -> ChatCompletionResponse`，编排调用链：1) 从 CapabilityRegistry 按 model 名称查找 ModelConfig，未找到抛 ModelNotFoundError；2) 调用 RateLimiter 检查限流（初期空实现）；3) 获取对应 Adapter，调用 `adapter.complete()`；4) 将适配器返回结果翻译为 ChatCompletionResponse 格式，参考 [contracts/openai-compatible-api.md](contracts/openai-compatible-api.md) 非流式响应格式
- [x] T016 [US1] 创建 OpenAI Compatible API 路由在 `LlmGateway/app/routers/v1_chat.py`：定义 `router = APIRouter(prefix="/v1", tags=["OpenAI Compatible"])`，实现 `POST /v1/chat/completions` 端点，使用 `Depends(get_api_key_user)` 鉴权，接收 `ChatCompletionRequest` body；当 `stream="[REDACTED]"
- [x] T017 [US1] 更新 `LlmGateway/app/main.py`：导入并注册 v1_chat router（`app.include_router(v1_chat.router, prefix="/api/llm")`），在 lifespan 中初始化 `CapabilityRegistry`（调用 `load_from_db`）并存入 `app.state.registry`
- [x] T018 [US1] 更新 `LlmGateway/app/services/model_service.py`：在 `create_model()` 和 `update_model()` 中处理 `capabilities` 字段（从 Schema 读取并写入 Model），在 `_model_to_response()` 中返回 `capabilities` 字段

**Checkpoint**: US1 完成 — 统一 API 非流式调用可工作，两个供应商模型均可正确响应

---

## Phase 4: User Story 2 - 流式实时输出 (Priority: P1)

**Goal**: 支持 stream=true 的 SSE 流式响应，逐块返回内容，流结束有 usage 和 [DONE]

**Independent Test**: 发送 `stream=true` 请求，验证 SSE 逐块返回内容 delta，最终 chunk 含 `finish_reason:"stop"` + `usage`，最后 `data: [DONE]`

### Implementation for User Story 2

- [x] T019 [P] [US2] 创建 SSE 格式化工具在 `LlmGateway/app/gateway/sse.py`：实现 `format_sse_event(data: dict) -> str` 函数（返回 `f"data: {json.dumps(data)}\n\n"`）、`format_sse_done() -> str`（返回 `"data: [DONE]\n\n"`）、`format_delta_chunk(id, model, content) -> str`（构造 OpenAI chunk 格式并 SSE 编码）、`format_final_chunk(id, model, usage) -> str`（构造含 finish_reason=stop 和 usage 的最终 chunk）、`format_error_event(error: GatewayError) -> str`（构造错误事件并 SSE 编码）
- [x] T020 [P] [US2] 在 `LlmGateway/app/adapters/openai_adapter.py` 中完善 `stream()` 方法：确保正确解析 OpenAI SSE 格式，每个 `data:` 行解析为 JSON，提取 `choices[0].delta.content` yield `{"type": "delta", "content": ...}`，最后一个 chunk 提取 `usage` yield `{"type": "usage", ...}`，然后 yield `{"type": "done"}`；处理流中错误（HTTP 非 200）yield `{"type": "error", ...}`
- [x] T021 [P] [US2] 在 `LlmGateway/app/adapters/anthropic_adapter.py` 中完善 `stream()` 方法：解析 Anthropic SSE 格式（`event:` + `data:` 行），`content_block_delta` 事件 yield `{"type": "delta", "content": ...}`，`message_stop` 事件 yield `{"type": "done"}`，`message_delta` 事件提取 usage yield `{"type": "usage", ...}`
- [x] T022 [US2] 在 `LlmGateway/app/services/llm_gateway_service.py` 中新增 `async def process_stream_request(request, user, db) -> AsyncGenerator[str, None]`：1) 查找 ModelConfig 和 Adapter；2) 调用 `adapter.stream()` 获取异步生成器；3) 使用 `sse.py` 格式化每个事件为 SSE 字符串 yield 出去；4) 流结束 yield `format_sse_done()`；5) 流中异常捕获后 yield `format_error_event()` 再 yield `format_sse_done()`，确保只有一个终态
- [x] T023 [US2] 在 `LlmGateway/app/routers/v1_chat.py` 中完善 `stream=true` 分支：调用 `gateway_service.process_stream_request()` 获取生成器，返回 `StreamingResponse(generator, media_type="text/event-stream")`，添加 `Cache-Control: no-cache`、`Connection: keep-alive` 等 SSE 标准 headers

**Checkpoint**: US1 + US2 完成 — 流式和非流式调用均可工作

---

## Phase 5: User Story 3 - 结构化输出 (Priority: P2)

**Goal**: 支持 response_format=json_object 约束返回合法 JSON，Schema 校验通过

**Independent Test**: 发送带 `response_format.type=json_object` + `schema` 的请求，验证返回的 content 是合法 JSON 且符合 Schema

### Implementation for User Story 3

- [x] T024 [P] [US3] 创建 JSON 修复器在 `LlmGateway/app/gateway/json_repair.py`：实现 `def extract_json(text: str) -> str | None`（用正则提取文本中的 JSON 块，支持 `{...}` 和 `[...]` 格式）、`def repair_and_validate(raw: str, schema: dict | None, max_attempts: int = 3) -> dict | None`（循环 max_attempts 次：尝试 json.loads(raw)，失败则 extract_json 再 loads，成功后如有 schema 则用 Pydantic 动态模型校验，校验通过返回解析后的 dict，全部失败返回 None），参考 research.md R-006
- [x] T025 [US3] 在 `LlmGateway/app/services/llm_gateway_service.py` 的 `process_request()` 中集成结构化输出：当 `request.response_format` 存在且 `type="json_object"` 时：1) 将 schema 传递给适配器（让供应商约束输出）；2) 获取响应后提取 `choices[0].message.content`；3) 调用 `repair_and_validate(content, schema)` 校验和修复；4) 成功则用修复后的 JSON 替换 content；5) 失败（返回 None）则抛出 `SchemaValidationError`（含 raw_output），参考 FR-010/011/012/013
- [x] T026 [US3] 在 `LlmGateway/app/services/llm_gateway_service.py` 的 `process_stream_request()` 中集成流式结构化输出：当 `request.response_format` 存在时：1) 流式传输过程中累积 content delta 到缓冲区；2) 流结束后（收到 done 事件）对完整缓冲区调用 `repair_and_validate()`；3) 成功则将校验后的 JSON 作为最终 content 发送；4) 失败则 yield 错误事件

**Checkpoint**: US1-3 完成 — 流式/非流式结构化输出均可工作

---

## Phase 6: User Story 4 - 系统提示词模板引用 (Priority: P2)

**Goal**: 通过 prompt_name + version 从 KnowledgeManage 获取模板并应用为系统提示词

**Independent Test**: 指定 prompt_name/version 调用模型，验证模型响应体现了模板的系统提示词影响

### Implementation for User Story 4

- [x] T027 [US4] 创建提示词模板服务在 `LlmGateway/app/services/prompt_service.py`：实现 `async def fetch_prompt(prompt_name: str, version: str, services_config: dict) -> dict` 函数，使用 httpx 调用 KnowledgeManage 服务 `GET /api/knowledge/prompts?name={name}&version={version}`（URL 从 config services.knowledge_manage 获取）；成功返回 `{id, name, version, content}`；HTTP 404 抛出 `PromptNotFoundError`；连接失败/超时/非 200 抛出 `PromptServiceUnavailableError`，参考 FR-014/FR-015/FR-015a 和 research.md R-008
- [x] T028 [US4] 在 `LlmGateway/app/services/llm_gateway_service.py` 的 `process_request()` 和 `process_stream_request()` 中集成提示词解析：当 `request.prompt_name` 和 `request.prompt_version` 均存在时：1) 调用 `fetch_prompt()` 获取模板；2) 将模板 content 作为 `{"role": "system", "content": ...}` 插入到 messages 列表最前面（如果用户已传 system message 则追加而非替换）；3) `prompt_name` 存在但 `prompt_version` 缺失时返回 `InvalidRequestError`；4) 模板获取失败时直接抛异常终止请求（不降级）

**Checkpoint**: US1-4 完成 — 提示词模板引用可工作

---

## Phase 7: User Story 5 - 韧性与弹性保障 (Priority: P2)

**Goal**: 限流（RPM/TPM）、指数退避重试（最多 3 次 + jitter）、能力匹配 Fallback

**Independent Test**: 模拟超过 RPM 限流返回 429；模拟供应商超时验证自动重试；模拟适配器不可用验证 Fallback

### Implementation for User Story 5

- [x] T029 [P] [US5] 创建限流器在 `LlmGateway/app/gateway/rate_limiter.py`：实现 `RateLimiterManager` 类，为每个 model_name 维护独立的限流器实例；`SlidingWindowCounter` 类实现 RPM 限流（`def allow_request(self) -> bool`：记录请求时间戳，滑动窗口内计数是否 < limit）；`TokenBucket` 类实现 TPM 限流（`def allow_tokens(self, estimated_tokens: int) -> bool`：令牌桶容量 = tpm，按时间补充令牌）；`RateLimiterManager.check(model_name: str, estimated_tokens: int = 0)` 方法同时检查 RPM 和 TPM，超限抛出 `RateLimitError`，参考 research.md R-003 和 data-model.md RateLimiter
- [x] T030 [P] [US5] 创建重试策略在 `LlmGateway/app/gateway/retry.py`：实现 `async def execute_with_retry(coro_factory, max_retries: int = 3, base_delay: float = 1.0, retryable_exceptions: tuple = (UpstreamError, UpstreamTimeoutError)) -> Any` 函数；每次失败后计算 `delay = base_delay * 2^attempt + random.uniform(0, base_delay)`（full jitter）；仅对 `retryable_exceptions` 中的异常类型重试；超过 max_retries 后抛出最后一次异常；记录每次重试日志（attempt 编号、延迟时间、错误信息），参考 research.md R-004
- [x] T031 [US5] 在 `LlmGateway/app/gateway/router.py` 中实现能力路由器：创建 `CapabilityRouter` 类，持有 `CapabilityRegistry` 引用；`def route(self, model_name: str, capabilities_required: list[str]) -> tuple[ModelConfig, BaseAdapter]`：按 model_name 查找 ModelConfig，验证其 capabilities 包含 capabilities_required，返回 (config, adapter)；`def find_fallback(self, capabilities_required: list[str], exclude_models: list[str]) -> tuple[ModelConfig, BaseAdapter] | None`：调用 `registry.find_models_by_capabilities()` 找到所有满足能力的模型，排除 exclude_models 列表中的，返回第一个可用的 (config, adapter) 或 None
- [x] T032 [US5] 在 `LlmGateway/app/services/llm_gateway_service.py` 中集成限流、重试和 Fallback：1) 在 `process_request()` 开头调用 `RateLimiterManager.check(model_name)`；2) 将 `adapter.complete()` 调用包装在 `execute_with_retry()` 中；3) 重试失败后调用 `CapabilityRouter.find_fallback()` 尝试 Fallback 模型；4) Fallback 成功则用 Fallback 模型重试；5) 所有尝试失败则抛出最终异常
- [x] T033 [US5] 在 `LlmGateway/app/services/llm_gateway_service.py` 的 `process_stream_request()` 中实现流式重试边界：1) 首 delta 前（尚未 yield 任何 content）可重试和 Fallback（复用 process_request 的重试逻辑）；2) 首 delta 后（已 yield 至少一个 content 事件）发生错误时直接 yield error 事件并终止流，不重试不 Fallback

**Checkpoint**: US1-5 完成 — 限流、重试、Fallback 均可工作

---

## Phase 8: User Story 6 - 可观测性 (Priority: P2)

**Goal**: 每次调用记录 token 用量、成本、延迟、trace 数据，暴露 Prometheus 指标端点

**Independent Test**: 发送调用后访问 `/metrics` 端点，可查到 `llm_request_total`、`llm_tokens_total` 等指标且含 `user_email` 标签

### Implementation for User Story 6

- [x] T034 [P] [US6] 创建可观测性模块在 `LlmGateway/app/gateway/observability.py`：使用 `prometheus_client` 定义指标：`llm_request_total`（Counter，labels: model, provider, user_email, finish_reason）、`llm_tokens_total`（Counter，labels: model, user_email, type[input/output/cached/reasoning]）、`llm_latency_seconds`（Histogram，labels: model, phase[queue/route/ttft/generation/total]）、`llm_cost_estimate`（Counter，labels: model, user_email）、`llm_retry_total`（Counter，labels: model）、`llm_fallback_total`（Counter，labels: from_model, to_model）；实现 `def record_invocation(record: InvocationRecord)` 函数更新所有指标；实现 `def setup_metrics_endpoint(app)` 函数注册 `/metrics` 端点，参考 research.md R-005 和 data-model.md InvocationRecord
- [x] T035 [P] [US6] 在 `LlmGateway/app/gateway/observability.py` 中新增结构化日志：实现 `def log_invocation(record: InvocationRecord)` 函数，使用 Python `logging` 输出 JSON 格式日志（含 trace_id、call_id、user_email、model、provider、tokens、latency、retries、fallback_used、finish_reason、error_code、estimated_cost），参考 PRD 指标与日志分工
- [x] T036 [US6] 在 `LlmGateway/app/services/llm_gateway_service.py` 中集成可观测性：1) 在 `process_request()` 和 `process_stream_request()` 开头记录 `start_time`；2) 在各阶段（queue、route、ttft、generation）记录时间戳；3) 调用完成后构建 `InvocationRecord`（trace_id 用 uuid4、call_id 用 uuid4、从 user 获取 user_email、从 response 获取 tokens、计算 latency 各阶段、计算 estimated_cost = input_tokens * input_per_million / 1e6 + output_tokens * output_per_million / 1e6 + cached_tokens * cached_input_per_million / 1e6）；4) 调用 `record_invocation()` 和 `log_invocation()`；5) TTFT 以首个有业务意义的 delta 为准（流式场景记录首个非空 content 的时间）
- [x] T037 [US6] 更新 `LlmGateway/app/main.py`：在 lifespan 中调用 `setup_metrics_endpoint(app)` 注册 `/metrics` 端点

**Checkpoint**: US1-6 完成 — 可观测性数据完整记录

---

## Phase 9: User Story 7 - 聊天会话管理 (Priority: P3)

**Goal**: KnowledgeManage 服务中实现会话创建/消息/取消/历史，状态机 + Redis Pub/Sub 取消信号

**Independent Test**: 创建会话 → 发消息流式接收 → 取消会话 → 重新打开查看历史消息

### Implementation for User Story 7

- [x] T038 [P] [US7] 创建 LlmGateway 数据库迁移：在 `LlmGateway/alembic/versions/` 下新增迁移脚本，为 `models` 表添加 `capabilities JSON NOT NULL DEFAULT '[]'` 列，参考 [data-model.md](data-model.md) Model 迁移说明
- [x] T039 [P] [US7] 创建 KnowledgeManage 数据库迁移：在 `KnowledgeManage/alembic/versions/` 下新增迁移脚本，为 `chats` 表添加 `status VARCHAR(20) NOT NULL DEFAULT 'idle'` 列，参考 [data-model.md](data-model.md) Chat 迁移说明
- [x] T040 [US7] 在 `KnowledgeManage/app/models/chat.py` 的 `Chat` 类中新增 `status` 字段：`Column(String(20), nullable=False, default="idle", comment="会话状态: idle/generating/completed/cancelled")`，参考 [data-model.md](data-model.md) Chat 状态定义
- [x] T041 [P] [US7] 更新 `KnowledgeManage/app/schemas/chat.py`（或对应 schema 文件）：在 `ChatCreate`、`ChatResponse` 中新增 `status` 字段（Create 忽略/默认 idle，Response 映射），新增 `ChatMessageCreate`（content: str min_length=1）、`ChatMessageResponse`（id/chat_id/role/content/created_at）、`ChatCancelResponse`（id/status/message）
- [x] T042 [US7] 在 `KnowledgeManage/app/core/config.py` 中新增 `RedisConfig` 配置类，更新 `Settings` 模型；在 `KnowledgeManage/config.dev.yaml` 中新增 redis 配置节；更新 `KnowledgeManage/requirements.txt` 新增 `redis` 依赖
- [x] T043 [US7] 实现聊天服务状态机在 `KnowledgeManage/app/services/chat_service.py`：实现 `ChatService` 类，方法包括：`create_chat()` — 创建会话，status 默认 idle；`send_message()` — 1) 检查状态（idle 或 completed/cancelled 均可复用），将 status 转为 generating；2) 保存用户消息到 Message 表；3) 通过 httpx 调用 LlmGateway `/api/llm/v1/chat/completions`（stream=true），SSE 流透传给前端；4) 流结束时将完整助手响应保存到 Message 表，status 转为 completed；`cancel_chat()` — 1) 检查 status 为 generating，否则返回 409；2) status 转为 cancelled；3) 通过 Redis Pub/Sub publish 取消信号（channel: `chat:{chat_id}:cancel`）；`get_messages()` — 分页查询 Message 表；`list_chats()` — 按 user_id 分页查询 Chat 表
- [x] T044 [US7] 在 `KnowledgeManage/app/services/chat_service.py` 中实现 Redis Pub/Sub 取消监听：在 `send_message()` 的流式处理中启动异步任务订阅 `chat:{chat_id}:cancel` channel；收到取消信号后中断 httpx 流、停止写入 Message、将 status 保持 cancelled；未收到信号则正常完成
- [x] T045 [US7] 实现聊天会话路由在 `KnowledgeManage/app/routers/chats.py`（重写现有）：`POST /chats` — 创建会话（201）；`POST /chats/{chat_id}/messages` — 发送消息，返回 SSE StreamingResponse；`POST /chats/{chat_id}/cancel` — 取消会话（200）；`GET /chats/{chat_id}/messages` — 获取消息历史（200，分页）；`GET /chats` — 获取当前用户会话列表（200，分页）；所有端点使用 `Depends(get_current_user)` JWT 鉴权，参考 [contracts/chat-sessions-api.md](contracts/chat-sessions-api.md)
- [x] T046 [US7] 更新 `KnowledgeManage/app/main.py`：确保 chats router 正确注册（`app.include_router(chats.router, prefix="/api/knowledge")`），在 lifespan 中初始化 Redis 连接池并存入 `app.state.redis`

**Checkpoint**: US1-7 全部完成 — 聊天会话端到端可工作

---

## Phase 10: Polish & Cross-Cutting Concerns

**Purpose**: 端到端验证、跨切面优化

- [x] T047 运行 [quickstart.md](quickstart.md) 中的 V-001 至 V-008 全部 8 个验证场景，确认所有功能点通过
- [x] T048 在 `LlmGateway/app/routers/v1_chat.py` 中添加请求体大小限制和输入消毒（防止超大 messages 列表）
- [x] T049 更新 `LlmGateway/app/main.py` 的 CORS 配置：将 `allow_origins=["*"]` 改为从配置文件读取（为后续外部访问预留安全策略扩展点），参考 spec.md 澄清 Q1

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即开始
- **Foundational (Phase 2)**: 依赖 Phase 1 完成 — **阻塞所有 User Story**
- **US1 (Phase 3)**: 依赖 Phase 2 — 🎯 MVP 最小可交付
- **US2 (Phase 4)**: 依赖 Phase 3（流式复用 Gateway Service）
- **US3 (Phase 5)**: 依赖 Phase 3（结构化输出在 process_request 中集成）
- **US4 (Phase 6)**: 依赖 Phase 3（提示词解析在 process_request 中集成）
- **US5 (Phase 7)**: 依赖 Phase 3（限流/重试/Fallback 在 Gateway Service 中集成）
- **US6 (Phase 8)**: 依赖 Phase 3（可观测性在 Gateway Service 中集成）
- **US7 (Phase 9)**: 依赖 Phase 3 + Phase 4（聊天会话调用 Gateway 的流式 API）
- **Polish (Phase 10)**: 依赖所有 User Story 完成

### User Story Dependencies

- **US1 (P1)**: Foundational 完成后可开始，无依赖其他 Story
- **US2 (P1)**: 依赖 US1（复用 Gateway Service 和路由）
- **US3 (P2)**: 依赖 US1（在 process_request 中集成）
- **US4 (P2)**: 依赖 US1（在 process_request 中集成）
- **US5 (P2)**: 依赖 US1（在 Gateway Service 中集成限流/重试/Fallback）
- **US6 (P2)**: 依赖 US1（在 Gateway Service 中集成可观测性）
- **US7 (P3)**: 依赖 US1 + US2（聊天会话调用 Gateway 流式 API）

### Within Each User Story

- 模型/Schema 变更 → 服务层 → 路由层 → 集成
- 标记 [P] 的任务可在同一 Phase 内并行执行

---

## Parallel Example: Phase 2 (Foundational)

```bash
# 以下任务可在 Phase 2 内并行执行（不同文件，无依赖）：
Task: "T007 Model 实体新增 capabilities 字段 in LlmGateway/app/models/model.py"
Task: "T008 更新 model Schema in LlmGateway/app/schemas/model.py"
Task: "T006 统一错误码 in LlmGateway/app/gateway/errors.py"
```

## Parallel Example: Phase 4 (US2)

```bash
# 适配器流式实现可并行：
Task: "T020 OpenAI 适配器 stream() in LlmGateway/app/adapters/openai_adapter.py"
Task: "T021 Anthropic 适配器 stream() in LlmGateway/app/adapters/anthropic_adapter.py"
Task: "T019 SSE 格式化工具 in LlmGateway/app/gateway/sse.py"
```

## Parallel Example: Phase 7 (US5)

```bash
# 限流器和重试策略可并行：
Task: "T029 限流器 in LlmGateway/app/gateway/rate_limiter.py"
Task: "T030 重试策略 in LlmGateway/app/gateway/retry.py"
```

## Parallel Example: Phase 8 (US6)

```bash
# Prometheus 指标和结构化日志可并行：
Task: "T034 Prometheus 指标 in LlmGateway/app/gateway/observability.py"
Task: "T035 结构化日志 in LlmGateway/app/gateway/observability.py"
```

---

## Implementation Strategy

### MVP First (US1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL - blocks all stories)
3. Complete Phase 3: User Story 1 (统一模型调用 API)
4. **STOP and VALIDATE**: 运行 quickstart V-001（非流式调用两个模型）
5. 部署/Demo — 此时已有可工作的统一 API

### Incremental Delivery

1. Setup + Foundational → 基础就绪
2. US1 → 验证 → Demo（MVP! 统一 API 非流式调用）
3. US2 → 验证 → Demo（流式输出）
4. US3 → 验证 → Demo（结构化输出）
5. US4 → 验证 → Demo（提示词模板）
6. US5 → 验证 → Demo（限流/重试/Fallback）
7. US6 → 验证 → Demo（可观测性）
8. US7 → 验证 → Demo（聊天会话）

### Recommended Sequential Order

由于 Gateway Service（`llm_gateway_service.py`）被 US3-6 共同修改，建议按顺序实现以避免合并冲突：US1 → US2 → US3 → US4 → US5 → US6 → US7

---

## Notes

- [P] tasks = 不同文件，无依赖，可并行
- [Story] label 映射到 spec.md 中的 User Story 编号
- 每个 User Story 完成后应独立可测试
- Gateway Service 是多个 Story 的交汇点，按顺序实现可减少冲突
- 数据库迁移（T038、T039）可在 Phase 9 之前提前执行
