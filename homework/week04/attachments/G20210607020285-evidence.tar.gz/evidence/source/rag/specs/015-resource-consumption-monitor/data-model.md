# Data Model: 资源消耗监控

**Feature**: 015-resource-consumption-monitor | **Date**: 2026-11-25

本功能为**只读查询**，无新增数据库表、无迁移、无状态机。以下为传输对象（DTO）与领域概念定义。

## 1. 领域概念

### 1.1 消耗桶（Bucket）

一个自然日或自然月时间区间（北京时间 Asia/Shanghai）。

| 属性 | 类型 | 规则 |
|------|------|------|
| label | string | 日桶 `YYYY-MM-DD`，月桶 `YYYY-MM`（X 轴刻度） |
| start / end | datetime | 北京时间边界；end 为桶结束时刻（不含） |
| window_seconds | int | end - start 的秒数；完整日桶 86400，完整月桶为当月实际秒数 |
| partial | bool | 进行中周期最后一个桶：end=now，window 为已经过秒数 |

**切分规则**（FR-012/014/018）：
- 人日视图：所选月份的全部自然日；若为当前月，截断至今天（含今天的 partial 桶）
- 人月/所有人月视图：所选年份的 1–12 月；若为当前年，截断至本月（含本月 partial 桶）
- 未来期间不可选（前端选择器禁用 + 后端校验拒绝）
- 补 0 仅作用于已经过的桶；partial 桶值为截至当前累计

### 1.2 消耗序列（Series）

一个模型在查询期间内的逐桶消耗值。

| 属性 | 类型 | 规则 |
|------|------|------|
| model | string | 模型名（PromQL `sum by (model)` 折叠后） |
| values | number[] | 与 buckets 等长对齐；token 为非负整数，费用为非负浮点（6 位小数） |

**聚合口径**（FR-010/011/013）：
- token：`llm_tokens_total{type!="cached"}`，input+output+reasoning，全 category
- 费用：`llm_cost_estimate_total` 全量（活体核验：counter 实际名带 _total 后缀）
- 人视图按 user_email 精确过滤；所有人视图跨用户求和
- 每桶值 = `increase(...[window])` 在桶结束时刻的瞬时查询结果（counter 重置安全）
- 无数据桶补 0；increase 不得产生负值（PromQL 保证）

## 2. 传输对象（schemas/consumption.py）

### 2.1 ConsumptionQuery（GET /consumption/series 查询参数）

| 字段 | 类型 | 必填 | 校验 |
|------|------|------|------|
| metric | enum | 是 | `tokens` \| `cost` |
| scope | enum | 是 | `user_daily` \| `user_monthly` \| `all_monthly` |
| user_email | string | scope=user_* 时必填 | 非空；普通用户必须等于本人 email（后端解析），否则 403 |
| models | string（逗号分隔） | 否 | 空/缺省 = 全部模型；非空时逐项正则转义 |
| month | string | scope=user_daily 时必填 | `YYYY-MM`；不得晚于当前月 |
| year | int | scope=*_monthly 时必填 | 2000–当前年；不得晚于当前年 |

**权限规则**（FR-003/004）：
- `scope=all_monthly`：仅管理员（`permission_manage`），否则 403
- `scope=user_*` 且 user_email ≠ 本人：仅管理员，否则 403
- 本人 email 来源：UserManage `GET /api/user/users/{sub}`（Bearer 透传），解析失败 502

### 2.2 SeriesOut（series 响应）

| 字段 | 类型 | 说明 |
|------|------|------|
| metric | string | 回显 |
| scope | string | 回显 |
| buckets | string[] | 桶标签升序（日 `YYYY-MM-DD` / 月 `YYYY-MM`） |
| series | Series[] | `{model, values}`；按模型名排序；补 0 模型范围仅限 models 显式勾选的模型（区间全 0 仍返回），全选时仅返回区间内有数据的模型 |
| out_of_retention | bool | 请求期间整体早于 now-retention_days 时为 true，buckets/series 为空 |

### 2.3 OptionsOut（GET /consumption/options 响应）

| 字段 | 类型 | 说明 |
|------|------|------|
| user_emails | string[] | 管理员：指标中出现过的全部非空 email；普通用户：仅本人 email |
| models | string[] | 指标中出现过的全部非空模型名 |
| is_admin | bool | 便于前端渲染视图可见性（与 userStore.isAdmin 双保险） |

### 2.4 PrometheusConfig（core/config.py 新增）

| 字段 | 类型 | 默认 | 说明 |
|------|------|------|------|
| url | str | http://localhost:9091 | Prometheus 地址（决策8） |
| timeout | float | 10.0 | 单查询 httpx 超时秒 |
| retention_days | int | 15 | 保留期提示阈值（R-005） |

## 3. 外部依赖数据（只读）

| 来源 | 用途 | 失败处理 |
|------|------|----------|
| Prometheus `/api/v1/query` | 逐桶 increase 聚合 | 502 + detail，前端错误提示 |
| Prometheus `/api/v1/label/{name}/values?match[]=llm_tokens_total` | 筛选选项 | options 接口 502 |
| UserManage `/api/user/users/{uid}` | 当前用户 email 解析 | 502"无法解析当前用户身份" |

## 4. 前端视图状态（ResourceMonitor.vue）

| 状态 | 说明 |
|------|------|
| activeTab | `tokens` \| `cost`（两 Tab 筛选条件独立保留） |
| activeScope | `user_daily` \| `user_monthly` \| `all_monthly`（所有人月仅管理员可见） |
| filters | user_email / models[] / month / year（默认：本人、全选、当前月/年） |
| chartData | SeriesOut；请求序号竞态保护（最新请求胜出） |
| loading / error | 查询按钮 loading；out_of_retention 与 502 分别提示 |