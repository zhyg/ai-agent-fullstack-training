# API Contract: 文档处理与分片

## 概述

KnowledgeManage 服务在现有文档管理 API 基础上扩展文档处理与分片相关接口。

基础路径: `/api/knowledge`

---

## 1. 文档上传（扩展）

### `POST /folders/{folder_id}/documents/upload`

**变更**: 新增 chunk_config 和 ai_question_count 参数。

**Form Data**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| file | File | 是 | 上传文件 |
| original_filename | string | 否 | 原始文件名 |
| original_filename_b64 | string | 否 | 原始文件名 base64 |
| chunk_strategy | string | 否 | 分块策略: "heading"(默认) / "fixed" |
| chunk_size | int | 否 | 分块大小 (100-4000, 默认 512) |
| chunk_overlap | int | 否 | 分块重叠 (0-500, 默认 80) |
| separators | string | 否 | 启用的分隔符 JSON 数组 |
| ai_question_count | int | 否 | AI问题生成数 (1-10, 默认 3) |

**Response** (201):
```json
{
  "documents": [
    {
      "id": "uuid",
      "name": "file.pdf",
      "status": "pending",
      "file_size": 102400
    }
  ],
  "message": "上传成功，正在处理..."
}
```

> **注意**: 压缩包上传时，chunk_strategy/chunk_size/chunk_overlap/separators 参数被忽略，各文件使用默认策略。

---

## 2. 文档状态查询

### `GET /documents/{document_id}`

**Response** (200):
```json
{
  "id": "uuid",
  "name": "file.pdf",
  "status": "chunking",
  "file_size": 102400,
  "skipped_files": null,
  "created_at": "2026-11-18T10:00:00Z"
}
```

**status 枚举**: `pending` | `parsing` | `chunking` | `embedding` | `ai_generating` | `completed` | `failed`

### `WS /documents/{document_id}/status/ws`

连接后 5 秒内发送 Access Token 作为首条文本消息。校验文档访问权限后，服务端发送当前文档 JSON，并在处理状态更新时推送新快照。断线重连会重新获取当前状态，无需轮询。`4401` 表示令牌无效或过期，`4404` 表示文档不存在或不可访问，`1013` 表示推送暂时不可用。部署反向代理时须允许该路由的 WebSocket Upgrade。

文档列表订阅当前页的文档；详情与列表中的同一文档共享连接。两处使用相同的中文状态标签。

### `GET /documents/{document_id}/markdown/preview`

使用 `?source=true` 可预览原始 Markdown（仅限 Markdown 文档）。压缩包内的配图按 Markdown 所在目录匹配，并在原始预览和解析预览中返回签名地址。

同一压缩包内，被 Markdown 引用的图片只存一份，不作为独立文档导入。引用同一图片的文档及分片共享图片地址和同一组 OCR／Caption 分片，最后一个引用删除后清理共享资源。未被引用的受支持图片仍独立导入和处理。

校验文档访问权限后，返回 `{"content": "..."}`。预览内容中的文档内图片引用会替换为有效期 1 小时的 MinIO 签名 URL，存储中的 Markdown 保持不变。文档未生成 Markdown 时返回 `404`，暂时无法读取存储时返回 `503`。

原有 `GET /documents/{document_id}/markdown` 仍返回原始 Markdown 文件的签名 URL。

---

## 3. 查询文档分片列表

### `GET /documents/{document_id}/chunks`

**Query Parameters**:

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| page | int | 1 | 页码 |
| page_size | int | 50 | 每页数量 (1-200) |
| chunk_type | string | null | 过滤类型 (text/image/table_row/ai_question 等) |

**Response** (200):
```json
{
  "items": [
    {
      "chunk_id": "c001",
      "document_id": "uuid",
      "chunk_type": "text",
      "content": "[文件名: manual.docx]\n## 第一章...",
      "image_url": ["minio://images/fig1.png"],
      "parent_chunk_id": null,
      "sqlite_url": null,
      "chunk_index": 0,
      "created_at": "2026-11-18T10:05:00Z"
    }
  ],
  "total": 42,
  "page": 1,
  "page_size": 50
}
```

---

## 4. 查询分片的子 chunks

### `GET /chunks/{chunk_id}/children`

获取指定 chunk 的所有子 chunks（image_ocr/image_caption/ai_question）。

**Response** (200):
```json
{
  "items": [
    {
      "chunk_id": "c003",
      "chunk_type": "image_ocr",
      "content": "这是一张系统架构图...",
      "image_url": "minio://images/fig1.png",
      "parent_chunk_id": "c001"
    },
    {
      "chunk_id": "c006",
      "chunk_type": "ai_question",
      "content": "这个系统的三个模块分别是什么？",
      "parent_chunk_id": "c001"
    }
  ]
}
```

---

## 5. 重新处理文档

### `POST /documents/{document_id}/reprocess`

用新的分块参数重新处理已完成的文档（删除旧 chunks，重新分片）。

**Request Body**:
```json
{
  "chunk_strategy": "fixed",
  "chunk_size": 1000,
  "chunk_overlap": 150,
  "separators": ["\n\n", "\n", "。", "."],
  "ai_question_count": 5
}
```

**Response** (200):
```json
{
  "id": "uuid",
  "status": "pending",
  "message": "重新处理已开始"
}
```

---

## 6. 表格数据查询

### `GET /chunks/{chunk_id}/table-data`

下载并查询 chunk 关联的 SQLite db 文件中的数据。

**Query Parameters**:

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| sql | string | null | 自定义 SQL 查询（只允许 SELECT） |
| limit | int | 100 | 返回行数上限 |

**Response** (200):
```json
{
  "table_name": "employee_info",
  "columns": ["name", "department", "level"],
  "rows": [
    ["张三", "技术部", "P7"],
    ["李四", "产品部", "P8"]
  ],
  "total": 150
}
```

---

## 错误响应

所有接口的错误响应格式统一:

```json
{
  "detail": "错误描述信息"
}
```

| HTTP 状态码 | 场景 |
|------------|------|
| 400 | 参数校验失败、表格格式不合规 |
| 404 | 文档/chunk 不存在 |
| 403 | 无权访问 |
| 503 | 外部服务不可用（MinerU/ES/MinIO） |
