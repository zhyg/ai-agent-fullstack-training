# Research: API Keys Management

**Feature**: 003-api-keys-management
**Date**: 2026-10-28

## R-001: API Key 生成算法与格式

**Decision**: 使用 Python `secrets` 模块生成密码学安全的随机字符串，格式为 `sk-` + 32位随机字符（a-z, A-Z, 0-9）

**Rationale**:
- `secrets` 是 Python 标准库中专为密码学安全设计的模块，比 `random` 更适合生成密钥
- 32位随机字符提供约 190 bit 的熵（62^32 ≈ 2.3 × 10^57），远超暴力破解可行性
- `sk-` 前缀是业界事实标准（OpenAI、Anthropic 等），便于人工识别和系统快速判断 Key 类型

**Alternatives considered**:
- UUID v4：标准化但无人类可读前缀，且仅 122 bit 熵
- JWT 格式：过于复杂，不适合静态密钥场景
- 自定义更长/更短字符串：32位已平衡安全性和可用性

## R-002: 密钥存储策略

**Decision**: 后端存储密钥的 SHA-256 哈希值（用于验证）和脱敏版本（用于展示），不存储明文

**Rationale**:
- 使用 `hashlib.sha256` 计算密钥哈希，验证时对用户传入的完整 Key 计算哈希后比对
- 脱敏格式：`sk-` + 前8位 + `...` + 后4位（从完整 Key 中截取，创建时一并生成）
- 与密码存储策略一致（项目已使用 bcrypt 存储密码哈希），遵循最小信息暴露原则

**Alternatives considered**:
- 可逆加密（Fernet）：可恢复明文但降低安全性，不符合"创建后不可再查看"的需求
- 仅存储脱敏版本：无法验证 Key 有效性，LLM Gateway 无法确认 Key 是否合法
- bcrypt 哈希：适用于密码（短字符串 + 慢速哈希），API Key 验证需要快速比对，SHA-256 更合适

## R-003: 脱敏 Key 展示格式

**Decision**: 列表展示格式为 `[REDACTED_API_TOKEN]...XXXX`（前缀 + 前8位随机字符 + `...` + 后4位字符）

**Rationale**:
- 用户可识别 Key 的前缀和后缀，便于在多个 Key 间区分
- 中间部分用 `...` 替代，保证安全性
- 参考页面 ApiKeyManagement.vue 中使用 `<code>` 标签展示

**Alternatives considered**:
- 仅显示后4位：区分度不足
- 显示前4位+后4位：安全性略低，且不如带前缀直观

## R-004: 数量上限与并发控制

**Decision**: 单用户最多 20 个 API Key，后端在创建时先 COUNT 再 INSERT，数据库层面无需额外约束

**Rationale**:
- 20 个上限是业界常见标准（OpenAI 默认 5 个，GitHub 默认 100 个），对本平台足够
- 并发创建场景：后端在事务中先查询当前数量，超限则拒绝。PostgreSQL 默认 READ COMMITTED 隔离级别下，极端并发可能导致略微超限，但影响极小（最多超限1-2个），可接受

**Alternatives considered**:
- 数据库层面 CHECK 约束：需要触发器或子查询，复杂度过高
- 分布式锁：过度设计，20个上限的超限风险可忽略

## R-005: LLM Gateway 验证流程

**Decision**: LLM Gateway 在收到 API 请求时，将完整 Key 发送给 UserManage 的 `/api/user/api-keys/verify` 内部端点进行验证

**Rationale**:
- UserManage 作为 Key 的拥有者，负责验证逻辑，职责清晰
- 内部验证端点接收完整 Key，计算 SHA-256 哈希后在数据库中匹配，匹配成功则返回 Key 所属用户信息和 Key 有效性
- LLM Gateway 无需存储任何 Key 信息，仅作为代理转发

**Alternatives considered**:
- LLM Gateway 直接查询数据库：跨服务直接访问数据库违反微服务原则
- 共享密钥缓存（Redis）：增加基础设施复杂度，当前规模不需要

## R-006: 前端搜索实现方式

**Decision**: 搜索采用前端本地过滤（基于已加载的列表数据），不调用后端搜索 API

**Rationale**:
- 单用户最多 20 个 Key，数据量极小，前端本地过滤性能足够
- 分页场景下（每页10条），搜索框清空后显示全部数据并重新分页
- 参考页面 ApiKeyManagement.vue 的交互模式，搜索在前端完成即可

**Alternatives considered**:
- 后端搜索 API：对于 20 条数据的上限完全多余，增加不必要的后端复杂度

## R-007: 数据库迁移策略

**Decision**: 新增 Alembic 迁移文件 `002_add_api_keys.py`，在 `user_manage` schema 下创建 `api_keys` 表

**Rationale**:
- 遵循项目现有的 Alembic 迁移模式（001_initial → 002_add_api_keys）
- 表位于 `user_manage` schema 下，与其他 UserManage 表一致
- 迁移脚本从 `settings.database.db_schema` 读取 schema 名称

**Alternatives considered**: 无替代方案，项目已建立统一的迁移模式
