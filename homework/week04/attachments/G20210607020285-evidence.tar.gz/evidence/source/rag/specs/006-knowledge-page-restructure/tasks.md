# Tasks: 知识库管理页面重组

**Input**: Design documents from `/specs/006-knowledge-page-restructure/`

**Prerequisites**: plan.md (required), spec.md (required), research.md, data-model.md, quickstart.md

**Tests**: 未要求自动化测试，本任务清单不含测试任务。验证通过 quickstart.md 中的手动场景完成。

**Organization**: US1（菜单重命名）和 US2（侧边栏导航）深度耦合，合并在同一阶段实现。US3（占位页面）和 US4（回归验证）为独立阶段。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Frontend**: `frontend/src/`
- **Components**: `frontend/src/components/layout/`
- **Views**: `frontend/src/views/`
- **Router**: `frontend/src/router/`

---

## Phase 1: Setup

**Purpose**: 确认现有代码基线，无新增依赖或项目初始化

- [x] T001 确认 `frontend/package.json` 无需新增 npm 依赖（现有 ant-design-vue、vue-router、@ant-design/icons-vue 已满足需求）
- [x] T002 确认后端服务无需变更（PRD 提及"注意调整前后端逻辑"，但当前后端无菜单名称相关接口或配置）

---

## Phase 2: 顶部菜单重命名 + 侧边栏导航框架 (US1 + US2, Priority: P1) 🎯 MVP

**Goal**: 将"AI→会话管理"重命名为"AI→知识库管理"，并在知识库平台区域引入左侧边栏（含"新会话"、"知识库"、"智能体"三个菜单项及路由切换）

**Independent Test**: 打开顶部"AI"下拉菜单确认文字为"知识库管理"；点击后进入知识库平台区域，左侧显示边栏且三个菜单项可切换

### Implementation for US1 + US2

- [x] T003 [US1] [US2] 修改 `frontend/src/router/index.js`：在根路由 `/` 的 `children` 数组中新增两条路由 — `{ path: 'knowledge', name: 'KnowledgeManagement', component: () => import('../views/KnowledgeManagement.vue') }` 和 `{ path: 'agent', name: 'AgentManagement', component: () => import('../views/AgentManagement.vue') }`，与现有 `/chat` 路由平级
- [x] T004 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue` 顶部导航 AI 下拉菜单：将 `key="chat"` 的 `<router-link to="/chat">会话管理</router-link>` 改为 `<router-link to="/chat">知识库管理</router-link>`
- [x] T005 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：在 `<script setup>` 中引入 `MessageOutlined`、`BookOutlined`、`RobotOutlined` 图标组件（从 `@ant-design/icons-vue` 导入）
- [x] T006 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：新增 `collapsed` ref 和 `showKnowledgeSidebar` computed 属性 — 当 `route.path` 为 `/chat`、`/knowledge` 或 `/agent` 时返回 `true`
- [x] T007 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：新增 `selectedKeys` computed 属性 — 基于 `routeToKey` 映射（`'/chat': 'chat'`、`'/knowledge': 'knowledge'`、`'/agent': 'agent'`）从当前路由路径推导菜单高亮 key
- [x] T008 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：新增 `handleSidebarMenuClick` 函数 — 接收菜单 key 参数，使用 `router.push()` 导航到对应路由（`chat` → `/chat`，`knowledge` → `/knowledge`，`agent` → `/agent`）
- [x] T009 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue` 模板：在 `<a-layout class="workspace-layout">` 内部、`<a-layout-content>` 之前，添加条件渲染的 `<a-layout-sider v-if="showKnowledgeSidebar">` 侧边栏组件，包含标题"知识库平台"（带 BookOutlined 图标）和三个 `<a-menu-item>`（key 分别为 `chat`、`knowledge-base`、`agent`，图标分别为 MessageOutlined、BookOutlined、RobotOutlined，文字分别为"新会话"、"知识库"、"智能体"），菜单绑定 `selectedKeys` 和 `handleSidebarMenuClick`
- [x] T010 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：为侧边栏添加 scoped CSS 样式（侧边栏标题区域 logo 样式参考 MyKnowlegeWebDemo AppLayout.vue 第 80-85 行）
- [x] T011 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：更新 `aiRoutes` 数组，将新增的 `/knowledge` 和 `/agent` 路径加入，确保顶部"AI"按钮高亮状态在知识库平台所有子页面下均正确
- [x] T012 [US1] [US2] 修改 `frontend/src/components/layout/AppLayout.vue`：更新 `routeToKey` 映射对象，新增 `'/knowledge': 'knowledge'` 和 `'/agent': 'agent'` 条目

**Checkpoint**: 顶部菜单已重命名；知识库平台区域侧边栏可显示、可切换、高亮正确

---

## Phase 3: 知识库与智能体占位页面 (US3, Priority: P2)

**Goal**: 创建知识库和智能体两个占位页面，使侧边栏菜单切换有目标页面可渲染

**Independent Test**: 分别点击"知识库"和"智能体"菜单项，确认对应页面渲染且不报错

### Implementation for US3

- [x] T013 [P] [US3] 创建 `frontend/src/views/KnowledgeManagement.vue`：包含 `<template>` 中显示"知识库"占位文字（居中显示，灰色字体），`<script setup>` 为空，`<style scoped>` 设置基本居中样式
- [x] T014 [P] [US3] 创建 `frontend/src/views/AgentManagement.vue`：包含 `<template>` 中显示"智能体"占位文字（居中显示，灰色字体），`<script setup>` 为空，`<style scoped>` 设置基本居中样式

**Checkpoint**: 三个菜单项切换正常，占位页面渲染无报错

---

## Phase 4: 新会话页面回归验证 (US4, Priority: P2)

**Goal**: 确认 ChatManagement.vue 在新布局下的全部聊天功能正常工作

**Independent Test**: 在"新会话"页面执行创建会话、发送消息、模型切换、流式生成、取消生成等操作

### Implementation for US4

- [x] T015 [US4] 检查 `frontend/src/views/ChatManagement.vue` 的样式是否与新侧边栏布局兼容 — 确认 `height: calc(100vh - 160px)` 在侧边栏存在时仍然正确（侧边栏不影响主内容区高度计算）
- [x] T016 [US4] 确认 ChatManagement.vue 的 `<template>` 和 `<script setup>` 逻辑无需修改 — 所有 store 引用（chatStore、modelStore、promptStore）、事件处理函数、组件引用保持不变

**Checkpoint**: 新会话页面全部原有功能正常，无回归

---

## Phase 5: Polish & Cross-Cutting Concerns

**Purpose**: 整体验证和收尾

- [x] T017 按 `specs/006-knowledge-page-restructure/quickstart.md` 中的 V-001 至 V-007 验证场景逐一执行手动测试
- [x] T018 验证边界场景：直接 URL 访问 `/knowledge` 和 `/agent`、页面刷新后菜单高亮保持、从非知识库页面返回知识库区域时侧边栏状态正确

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即执行
- **US1+US2 (Phase 2)**: 依赖 Setup 完成，是所有后续工作的基础
- **US3 (Phase 3)**: 依赖 Phase 2 的路由注册（T003），但两个占位页面文件可在 T003 之后并行创建
- **US4 (Phase 4)**: 依赖 Phase 2 完成（布局变更可能影响 ChatManagement 样式）
- **Polish (Phase 5)**: 依赖全部前置阶段完成

### User Story Dependencies

- **US1+US2 (P1)**: Setup 完成后可开始，无跨故事依赖
- **US3 (P2)**: 依赖 US1+US2 中的路由注册（T003），占位页面创建可并行
- **US4 (P2)**: 依赖 US1+US2 的布局变更完成

### Within Each Phase

- Phase 2: T003（路由）→ T004-T012（AppLayout 修改）按顺序执行
- Phase 3: T013 和 T014 可完全并行（[P] 标记）
- Phase 4: T015 和 T016 按顺序执行

### Parallel Opportunities

- Phase 3 的 T013 和 T014 可在不同终端同时执行

---

## Parallel Example: User Story 3

```text
# 同时创建两个占位页面：
Task: T013 "创建 frontend/src/views/KnowledgeManagement.vue"
Task: T014 "创建 frontend/src/views/AgentManagement.vue"
```

---

## Implementation Strategy

### MVP First (US1 + US2)

1. Complete Phase 1: Setup（确认无需新增依赖）
2. Complete Phase 2: 菜单重命名 + 侧边栏导航框架
3. **临时处理**: 知识库和智能体路由暂时指向 ChatManagement 或 404（快速验证导航框架）
4. **STOP and VALIDATE**: 顶部菜单文字正确、侧边栏显示、三个菜单项可切换

### Incremental Delivery

1. Phase 1 + Phase 2 → 导航框架就绪（MVP!）
2. Phase 3: 添加占位页面 → 菜单切换完整闭环
3. Phase 4: 回归验证 → 确认零回归
4. Phase 5: 全量手动测试 → 准备上线

---

## Notes

- 本特性为纯前端变更，无后端任务
- US1 和 US2 深度耦合（共享 AppLayout.vue 和 router/index.js），合并为一个阶段
- 无自动化测试任务（项目当前无前端测试框架）
- 所有 [P] 任务为不同文件，无依赖冲突
