# Tasks: 知识库评测（014-knowledge-evaluation）

**Input**: Design documents from `/specs/014-knowledge-evaluation/`

**Prerequisites**: plan.md、spec.md、research.md（R1–R14）、data-model.md、contracts/evaluation-api.md、quickstart.md

**Tests**: 包含测试任务——plan.md/quickstart.md 明确定义 5 个测试文件与 SC 验证要求，且项目既有特性均含 pytest 回归。

**Organization**: 按用户故事分组（US1 设置与测试集 P1 → US2 执行 P2 → US3 结果 P3 → US4 trace P4），每个故事可独立实现与验证。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行（不同文件、无未完成依赖）
- **[Story]**: 所属用户故事（US1–US4）；Setup/Foundational/Polish 无故事标签

## Path Conventions

后端 `KnowledgeManage/app/`、测试 `KnowledgeManage/tests/`、前端 `frontend/src/`（见 plan.md Project Structure）。

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 建立模块骨架，无新依赖（plan.md：零新增依赖）

- [X] T001 创建后端模块骨架：`KnowledgeManage/app/schemas/evaluation.py`、`KnowledgeManage/app/services/evaluation_service.py`、`KnowledgeManage/app/services/evaluation_runner.py`、`KnowledgeManage/app/routers/evaluations.py`（APIRouter prefix="/evaluations"、tags=["evaluations"]，模块 docstring 注明契约来源 contracts/evaluation-api.md）
- [X] T002 [P] 创建前端 API 骨架 `frontend/src/services/evaluationApi.js`：axios 实例 baseURL `/api/knowledge/evaluations` + Bearer 请求拦截器 + 401 清 token 跳登录（逐行沿用 `frontend/src/services/traceApi.js` 模式）

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 4 表模型 + 迁移 + 路由注册 + 前端页面容器——所有故事的共同前置

**⚠️ CRITICAL**: 本阶段完成前任何用户故事不得开始

- [X] T003 [P] 创建 `KnowledgeManage/app/models/evaluation_setting.py`：EvaluationSetting（表 evaluation_settings，schema=settings.database.db_schema；id String(36) uuid PK；user_id String(36) NOT NULL UNIQUE；analysis_model_id/recall_prompt_id/accuracy_prompt_id String(36) NULL；created_at/updated_at TIMESTAMP UTC，updated_at onupdate；唯一索引 uq_evaluation_settings_user）
- [X] T004 [P] 创建 `KnowledgeManage/app/models/evaluation_test_set.py`：EvaluationTestSet（表 evaluation_test_sets；id String(36) PK；user_id String(36) NOT NULL；name String(100) NOT NULL；items JSONB NOT NULL；item_count Integer NOT NULL；唯一约束 (user_id, name) uq_evaluation_test_sets_user_name + idx_evaluation_test_sets_user）
- [X] T005 [P] 创建 `KnowledgeManage/app/models/evaluation_run.py`：EvaluationRun（表 evaluation_runs；字段按 data-model.md §3：knowledge_base_ids/knowledge_base_names JSONB NOT NULL、agent_id/agent_name、test_set_id/test_set_name 快照、status String(20) default 'running'（running/completed/cancelled/failed）、total_items/completed_items Integer、cancel_requested Boolean default False、error_message Text NULL、started_at/finished_at/created_at；索引 idx_evaluation_runs_user_created(user_id, created_at)、idx_evaluation_runs_status(status)、idx_evaluation_runs_test_set(test_set_id, status)）
- [X] T006 [P] 创建 `KnowledgeManage/app/models/evaluation_item.py`：EvaluationItem（表 evaluation_items；字段按 data-model.md §4：run_id FK→evaluation_runs.id ON DELETE CASCADE、seq Integer（(run_id, seq) 唯一 uq_evaluation_items_run_seq）、question/standard_answer Text NOT NULL、status default 'pending'（pending/success/failed）、agent_answer Text、context JSONB、recall/accuracy Float NULL、recall_analysis/accuracy_analysis JSONB、recall_raw_output/accuracy_raw_output Text、failure_reason Text、trace_id String(32) NULL、created_at/completed_at；索引 idx_evaluation_items_run(run_id, status)）；在 `KnowledgeManage/app/models/__init__.py` 导出 4 个新模型
- [X] T007 创建 Alembic 迁移 `KnowledgeManage/alembic/versions/<rev>_add_evaluation_tables.py`（down_revision 指向当前 head，`alembic heads` 确认；创建 4 表与全部索引/唯一约束/FK CASCADE；downgrade 逆序 drop）；执行 `alembic upgrade head` 并验证 4 表存在（依赖 T003–T006）
- [X] T008 在 `KnowledgeManage/app/main.py` 注册 evaluations router（`app.include_router(evaluations.router, prefix="/api/knowledge")`，模式同既有 router）；验证 app 可导入、OpenAPI 出现 /api/knowledge/evaluations 路径（依赖 T001）
- [X] T009 [P] 前端页面容器与菜单：新增 `frontend/src/views/EvaluationManagement.vue`（a-tabs 设置/评测，内容暂占位）；`frontend/src/router/index.js` 新增 `/evaluation` 路由（AppLayout 子路由）；`frontend/src/components/layout/AppLayout.vue` 知识库侧栏"智能体"菜单项后新增 key="evaluation"「知识库评测」，同步 knowledgeRoutes/routeMap/aiRoutes 数组（FR-001 菜单与"智能体"同级）

**Checkpoint**: 迁移就绪、路由可达、页面容器可见——用户故事可开始

---

## Phase 3: User Story 1 - 评测设置与测试集管理 (Priority: P1) 🎯 MVP

**Goal**: 用户完成分析模型/召回率/准确度提示词配置与测试集上传/删除/下载/重新上传，仅本人可见

**Independent Test**: 仅本故事即可验证——三项配置选择保存、合法/非法测试集上传校验、删除/下载/重新上传、跨用户隔离（quickstart 场景 A 步骤 1–2、E-3）

### Tests for User Story 1

> 先写测试并确认 FAIL，再实现

- [X] T010 [P] [US1] 编写 `KnowledgeManage/tests/test_evaluation_settings.py`：GET 空默认值、PUT upsert、提示词非本人 400、本人存在 running run 时 PUT 409（直接插 run 行模拟）、跨用户不可见（US1-1/2/7、FR-002~004/009）
- [X] T011 [P] [US1] 编写 `KnowledgeManage/tests/test_evaluation_test_sets.py`：上传合法 10 题成功；空数组/顶层非数组/缺字段/question 或 answer 空串/501 题/2MB+1 字节拒绝且 detail 指明具体错误；恰好 500 题与 2MB 允许；重名 409；下载导出标准 JSON；重新上传覆盖（ID/名称不变、重新校验）；删除；被 running run 选中时删除/重新上传 409；跨用户 404（US1-3/4/5/6、FR-005~009、决策20）

### Implementation for User Story 1

- [X] T012 [US1] 在 `KnowledgeManage/app/schemas/evaluation.py` 实现设置与测试集 schema：SettingsOut/SettingsUpdate（三引用可空）、TestSetOut/TestSetListOut；测试集校验函数 validate_test_set_payload（文件 ≤2MB；顶层数组；1 ≤ 题数 ≤ 500；每项 question/answer 均为 strip 后非空字符串；错误信息含第 N 项/何字段，FR-006 逐字约束）
- [X] T013 [US1] 在 `KnowledgeManage/app/services/evaluation_service.py` 实现：get_settings/upsert_settings（保存前查本人 status='running' 任务→409 锁定；提示词归属校验）；测试集 list/create（重名 409）/delete/reupload（覆盖 items+item_count，名称/ID 不变）/export（标准 [{question, answer}] 数组）；删除与重新上传前查 `evaluation_runs.status='running' AND test_set_id=本ID`→409（FR-009，R8）；全部查询按 user_id 隔离（依赖 T012）
- [X] T014 [US1] 在 `KnowledgeManage/app/routers/evaluations.py` 实现契约 §1/§2 端点：GET/PUT /settings；GET/POST /test-sets（multipart name+file，201）；GET /test-sets/{id}/download（Content-Disposition attachment; filename="{name}.json"）；PUT/DELETE /test-sets/{id}；状态码 400/404/409 按契约（依赖 T013）
- [X] T015 [P] [US1] 在 `frontend/src/services/evaluationApi.js` 实现 US1 方法：getSettings/saveSettings/listTestSets/uploadTestSet/reuploadTestSet/downloadTestSet/deleteTestSet（multipart 与 blob 下载处理）
- [X] T016 [P] [US1] 创建 `frontend/src/components/evaluation/TestSetUploadModal.vue`：名称输入（重新上传模式隐藏名称）+ JSON 文件选择 + 前端预校验提示 + 提交结果/错误展示
- [X] T017 [US1] 实现 `frontend/src/components/evaluation/EvaluationSettings.vue` 并接入 EvaluationManagement.vue 设置 tab：分析模型下拉（modelApi.listModels page_size=1000 过滤 category==='chat'，R9）、召回率/准确度提示词下拉（promptApi 仅本人，展示 name+version）、保存（锁定 409 提示）；测试集列表（名称/题数/时间）+ 删除二次确认/下载/重新上传（集成 T016 弹窗）（依赖 T015/T016）

**Checkpoint**: US1 独立可用——设置与测试集闭环（MVP）

---

## Phase 4: User Story 2 - 发起评测与执行控制 (Priority: P2)

**Goal**: 选择知识库+智能体+测试集发起异步评测，逐题串行执行+评分+SSE 进度+取消+超时+重启容错+运行中锁定

**Independent Test**: 3 题小测试集发起评测，验证预检拦截、进度推送、逐题落库、取消、单题失败容错、重启标记失败（quickstart 场景 A-3/4、B、C）

### Tests for User Story 2

- [X] T018 [P] [US2] 编写 `KnowledgeManage/tests/test_evaluation_runs.py`：POST /runs 预检一次性列出全部失效项 400 且不建任务（模型/提示词/智能体停用/知识库删除逐项与组合）；kb_ids 空 400；本人已有 running 409；创建即返 201 且逐题预建 pending 明细含 question/standard_answer 快照；cancel 后当前题完成才终止、状态 cancelled、已完成保留；restart recovery 将 running 标 failed（error_message=服务重启中断）；全题失败仍 completed；running 时删除记录 409；运行中修改智能体配置→后续题按新配置实时生效（FR-020，每题重建 snapshot，决策24）（US2-1/2/3/6/8/9、FR-010~020）
- [X] T019 [P] [US2] 编写 `KnowledgeManage/tests/test_evaluation_scoring.py`（mock llm_client）：召回率=covered/总数（忽略模型自报 recall）；准确度=max(0,100−5×issues 数)；空 key_points 校验失败重试、耗尽记失败留 raw_output；围栏包裹容错提取；重试 3 次附上次输出与错误；ModelUnavailableError 不业务重试直接记失败；clarify_failed 记失败原因=澄清 reason 得分置空；empty_retrieval 视为正常答案照常评分；最终采纳 JSON 落库（重试多次存最后成功那次）；单题 wait_for 600s 超时记失败继续；断言评分子 span 名 evaluation.recall/evaluation.accuracy 与 prompt.name/version 属性（FR-037，span 属性断言容错解析）（US2-4/5/10、FR-021~027/037、澄清 Q1/Q2、R2/R5/R7）

### Implementation for User Story 2

- [X] T020 [P] [US2] 在 `KnowledgeManage/app/schemas/evaluation.py` 追加：RecallResult{key_points: List[KeyPoint] Field(min_length=1), recall: float}、KeyPoint{point: str(min_length=1), covered: StrictBool}、AccuracyResult{issues: List[Issue]}（空数组合法）、Issue{type/content/evidence: str}；RunCreate{knowledge_base_ids: List[str](≥1), agent_id, test_set_id}；SSE 事件模型 snapshot/progress/done（契约 §3）
- [X] T021 [P] [US2] 创建 `KnowledgeManage/app/services/agent_runtime/evaluation.py`：run_evaluation_question(*, agent_id, kb_ids, user_id, question, cancel_event, emit)——根 span `evaluation.item`（start_as_current_span，属性 evaluation.run_id/item.seq/enduser.id）→ build_snapshot → RequestRuntimeState(history=[], chat_id="") → 跳过 history_qa_service → _get_runner 分发 flow → 返回 {content, meta, trace_id, error?}；异常映射模式同 run_agent_generation；不创建 Chat/Message（R1，决策21）
- [X] T022 [US2] 在 `KnowledgeManage/app/services/evaluation_runner.py` 实现评分协程：渲染占位符（召回率 {question}/{standard_answer}/{agent_answer}；准确度另加 {context}，仅渲染文档名+片段内容不含得分，决策5/8）；在 evaluation.item 上下文内建子 span evaluation.recall/evaluation.accuracy + tracing.set_prompt_attrs；调 llm_client.call_json（purpose=evaluation_recall/evaluation_accuracy）；后端核算得分；捕获 JsonValidationFailed 存 raw_output、ModelUnavailableError 记失败（R4/R5/R10，依赖 T020/T021）
- [X] T023 [US2] 在 `KnowledgeManage/app/services/evaluation_runner.py` 实现执行器：asyncio.create_task 启动；逐题串行——每题前查 DB cancel_requested（命中→当前已完成后终止标 cancelled）、每题重新 build_snapshot（决策24 实时生效）、整题 asyncio.wait_for(600)（超时 set cancel_event 记失败"执行超时"继续）、每题完成即 UPDATE 明细与 completed_items 并发布 progress 事件；终态 completed/cancelled/failed（任务级异常→failed+error_message）发布 done；事件订阅表 dict[run_id, set[Queue]]；shutdown() 收尾（R6/R7/R12，依赖 T022）
- [X] T024 [US2] 在 `KnowledgeManage/app/services/evaluation_service.py` 追加：create_run（全量预检 FR-011：设置三项齐备+resolve_model 存在且 category=chat+两提示词存在且本人+智能体 enabled+知识库全部存在且本人+测试集本人，失效项一次性汇总 400；并发检查 409；ID+名称快照；逐题预建 pending 行；启动执行器）；cancel_run（写 cancel_requested+set 进程内 Event，终态 409）；recover_interrupted_runs（UPDATE running→failed，error_message='服务重启中断'，finished_at=now）（依赖 T023）
- [X] T025 [US2] 在 `KnowledgeManage/app/routers/evaluations.py` 追加：POST /runs（201 立即返回）；POST /runs/{id}/cancel；GET /runs/{id}/events（StreamingResponse text/event-stream：连接即发 snapshot，增量 progress，终态 done 后关闭；已终态连接即发 done；404 归属校验）（契约 §3，依赖 T024）
- [X] T026 [US2] 修改 `KnowledgeManage/app/main.py` lifespan：启动段调 evaluation_service.recover_interrupted_runs()（SC-006）；关闭段调 evaluation_runner.shutdown()（模式同 chat_service.finish_generations）（依赖 T024）
- [X] T027 [P] [US2] 在 `frontend/src/services/evaluationApi.js` 追加：createRun/cancelRun/subscribeRunEvents（SSE 用 fetch + Authorization 头流式读取，沿用 chatApi.js 既有 SSE 模式，不用原生 EventSource/token-query；断线重连靠 snapshot 恢复）
- [X] T028 [US2] 实现 `frontend/src/components/evaluation/EvaluationPanel.vue` 发起区并接入评测 tab：知识库多选（≥1）/智能体单选（启用态）/测试集单选（本人）；开始评测（存在进行中置灰提示；预检 400 展示失效项）；SSE 进度条（已完成 N/总数 M + 任务状态）；取消按钮（依赖 T027）

**Checkpoint**: US2 独立可用——评测执行闭环，结果已落库

---

## Phase 5: User Story 3 - 评测结果查看与管理 (Priority: P3)

**Goal**: 历史评测列表（平均分仅统计成功题）+ 每题详情（含分析 JSON/失败原因/原始输出）+ 记录删除

**Independent Test**: 基于已完成/已取消/全失败任务验证列表字段、平均分口径、详情展示项、快照展示与删除规则（quickstart 场景 A-5/6、B-4、E-1/2）

### Tests for User Story 3

- [X] T029 [US3] 在 `KnowledgeManage/tests/test_evaluation_runs.py` 追加结果用例：列表分页+字段（开始时间/名称快照/状态）；平均分仅 success 题（10 题 8 成功 2 失败口径）、已取消照常展示、无成功题 null；详情按 seq 升序含全部字段（context/分析 JSON/失败题 raw_output）；测试集/知识库/智能体删除后快照照常；DELETE 级联删明细、running 409；跨用户 404（US3 全部场景、FR-028~034、R13；同文件接续 T018 不并行）

### Implementation for User Story 3

- [X] T030 [US3] 在 `KnowledgeManage/app/services/evaluation_service.py` 追加：list_runs（created_at 倒序分页；AVG(recall)/AVG(accuracy) FILTER (WHERE status='success') 实时聚合，无成功题 null（R13；实现为单次列投影查询+进程内仅 success 行求均，与 AVG FILTER 口径等价且可单测）；get_run_detail（items 按 seq 升序全字段）；delete_run（running→409 须先取消；FK CASCADE 级联）
- [X] T031 [US3] 在 `KnowledgeManage/app/routers/evaluations.py` 追加：GET /runs?page&page_size、GET /runs/{id}、DELETE /runs/{id}（204/409），响应结构按契约 §3（依赖 T030）
- [X] T032 [P] [US3] 在 `frontend/src/services/evaluationApi.js` 追加：listRuns/getRun/deleteRun
- [X] T033 [P] [US3] 创建 `frontend/src/components/evaluation/EvaluationDetail.vue`：每题问题/标准答案/上下文（文档名+内容+得分）/agent 答案/召回率（×100 百分比）/准确度/两份分析 JSON 格式化展示；失败题 failure_reason + 最后一次原始输出折叠面板；trace 入口按钮占位（US4 接线）；null 得分展示空
- [X] T034 [US3] 在 `frontend/src/components/evaluation/EvaluationPanel.vue` 追加历史列表区：列表列（开始时间/知识库/智能体/测试集名/平均召回率/平均准确度/状态）+ 点击进详情（T033）+ 删除二次确认（进行中提示先取消）（依赖 T032/T033）

**Checkpoint**: US3 独立可用——评测产出可消费可复核

---

## Phase 6: User Story 4 - 题目级执行轨迹 trace (Priority: P4)

**Goal**: 每题 trace 以会话页同款右侧宽幅抽屉展示，覆盖 agent 链路+评分子 span，归属校验+过期提示

**Independent Test**: 已完成评测某题点 trace 验证抽屉/评分子 span/跨用户拦截/过期提示（quickstart 场景 D）

### Tests for User Story 4

- [X] T035 [P] [US4] 编写 `KnowledgeManage/tests/test_evaluation_trace.py`：归属校验（他人 run/他人 item/item 不属于 run 均 404）；trace_id 空→no_trace；fetch_trace 命中透传 Jaeger 格式；未命中且 created_at ≤48h→pending、>48h→expired；ES 异常→503（US4 全部场景、FR-035~038、R11；模式沿用 tests/test_trace_query.py）

### Implementation for User Story 4

- [X] T036 [US4] 在 `KnowledgeManage/app/services/evaluation_service.py` 与 `KnowledgeManage/app/routers/evaluations.py` 实现 GET /runs/{run_id}/items/{item_id}/trace：run.user_id=当前用户 且 item.run_id=run_id（不校验会话）；trace_id 空→{ready:false, reason:"no_trace"}；复用 trace_query_service.fetch_trace(item.trace_id, item.created_at)；未命中且 created_at 距今 >48h→reason="expired" 否则 "pending"；ES 异常 503（契约 §4，依赖 T035 先 FAIL）
- [X] T037 [P] [US4] 修改 `frontend/src/services/traceApi.js` 新增 fetchEvaluationItemTrace(runId, itemId)（返回结构同 fetchMessageTrace）；修改 `frontend/src/components/trace/TraceDrawer.vue`：新增可选 prop fetcher: Function（默认仍走 chatId/message 原逻辑，会话页零影响），notReadyReason 增加 expired 分支文案"轨迹已过期清理"
- [X] T038 [US4] 在 `frontend/src/components/evaluation/EvaluationDetail.vue` 接线 trace 按钮（trace_id 非空显示）：打开 TraceDrawer 并传 fetcher=() => fetchEvaluationItemTrace(runId, itemId)（依赖 T036/T037）

**Checkpoint**: 全部用户故事独立可用

---

## Phase 7: Polish & Cross-Cutting Concerns

- [ ] T039 [P] 全量后端回归 `pytest KnowledgeManage/tests/ -q`：零新增失败（已知存量失败 test_agents.py::test_three_presets_exist_with_correct_defaults 依赖活库数据，与本特性无关）
- [ ] T040 [P] 前端构建验证 `cd frontend && npm run build` 成功；会话页 trace 抽屉回归确认（TraceDrawer 改动不影响原有用法）
- [ ] T041 按 `specs/014-knowledge-evaluation/quickstart.md` 执行手工场景 A–E 并逐条核对 SC-001~008；确认会话列表无评测产生的会话/消息（决策21）、ES 评测根 span 为 evaluation.item

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖
- **Foundational (Phase 2)**: 依赖 Setup；T003–T006 并行 → T007 迁移 → T008 注册；T009 前端容器可并行；**阻塞全部故事**
- **US1 (Phase 3)**: 依赖 Foundational（锁定查询仅读 runs 表，不依赖 US2 执行逻辑）
- **US2 (Phase 4)**: 依赖 Foundational；资产（设置/测试集）可手工插库独立测试，与 US1 无代码依赖
- **US3 (Phase 5)**: 依赖 Foundational；数据可插库独立测试；页面集成复用 US2 的 EvaluationPanel.vue（T034 在 T028 后）
- **US4 (Phase 6)**: 依赖 Foundational；trace_id 数据可插库独立测试；按钮接线依赖 US3 的 EvaluationDetail.vue（T038 在 T033 后）
- **Polish (Phase 7)**: 依赖全部故事完成

### User Story Dependencies（代码级）

- US1：独立（T010–T017 仅依赖 Phase 2）
- US2：独立（T018–T028 仅依赖 Phase 2）
- US3：后端独立；前端 T034 需 T028（同文件 EvaluationPanel.vue）
- US4：后端独立；前端 T038 需 T033（同文件 EvaluationDetail.vue）
- 同文件任务严禁并行：schemas/evaluation.py（T012→T020）、evaluation_service.py（T013→T024→T030→T036）、evaluation_runner.py（T022→T023）、routers/evaluations.py（T014→T025→T031→T036）、evaluationApi.js（T002→T015→T027→T032）、test_evaluation_runs.py（T018→T029）

### Within Each User Story

- 测试先写并确认 FAIL → schema/模型 → service → router → 前端
- T021（agent 入口）与 T020（schema）可并行 → T022 评分 → T023 执行器 → T024 服务 → T025 路由 → T026 lifespan

### Parallel Opportunities

- Phase 2：T003/T004/T005/T006/T009 五任务并行
- US1：T010/T011 并行；T015/T016 并行
- US2：T018/T019/T020/T021/T027 五任务并行
- US3：T032/T033 并行
- 跨故事：Phase 2 完成后 US1 与 US2 的**不同文件**任务可并行（如 T018/T019/T021/T027 与 T010/T011/T015/T016）；共享文件（schemas/evaluation.py、evaluation_service.py、routers/evaluations.py、evaluationApi.js）必须按上述同文件串行链执行，US3/US4 同理（前端集成点除外）

---

## Parallel Example: User Story 2

```bash
# 测试与无依赖实现同时启动：
Task: "T018 tests/test_evaluation_runs.py 执行控制用例"
Task: "T019 tests/test_evaluation_scoring.py 评分用例（mock llm_client）"
Task: "T020 schemas/evaluation.py 评分 JSON 模型"
Task: "T021 agent_runtime/evaluation.py 无会话入口"
Task: "T027 evaluationApi.js US2 方法"
# 汇聚后串行：T022 → T023 → T024 → T025 → T026 → T028
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Phase 1 Setup → Phase 2 Foundational（迁移/路由/容器）
2. Phase 3 US1 → **STOP & VALIDATE**：设置+测试集闭环（quickstart 场景 A-1/2、E-3）
3. 可交付演示：评测准备能力就绪

### Incremental Delivery

1. Setup + Foundational → 基础就绪
2. US1 → 独立验证 → 演示（MVP）
3. US2 → 独立验证（3 题小集跑通执行/取消/容错）→ 演示：核心评测价值
4. US3 → 独立验证（列表/详情/平均分/删除）→ 演示：结果可消费
5. US4 → 独立验证（trace 抽屉/权限/过期）→ 演示：排查能力
6. Polish：全量回归 + 构建 + quickstart A–E

### Parallel Team Strategy

Phase 2 完成后：开发 A 做 US1（前端+设置服务），开发 B 做 US2 独有文件（agent_runtime/evaluation.py、evaluation_runner.py、测试）；共享文件（schemas/service/router/evaluationApi.js）按同文件串行链协调；US3/US4 后端随后并行，前端集成点（T034/T038）按同文件依赖顺序收尾。

---

## Notes

- 评分重试/容错提取一律复用 llm_client.call_json，禁止新造重试循环（R4）
- 评测全程不创建 Chat/Message（决策21）；trace 根 span 为 evaluation.item（R1）
- trace 属性断言容错解析（to_json_attr 对裸串原样返回的已知坑）
- 每任务或逻辑组完成后提交；checkpoint 处可停下独立验证