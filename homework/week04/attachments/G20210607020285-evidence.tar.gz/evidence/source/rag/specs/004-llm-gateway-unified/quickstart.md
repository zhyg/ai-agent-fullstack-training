# Quickstart: LLM 统一模型调用网关

**Feature**: 004-llm-gateway-unified | **Date**: 2026-10-28

## 前置条件

1. UserManage 服务运行中（端口 8001）
2. KnowledgeManage 服务运行中（端口 8002）
3. PostgreSQL 数据库已创建 `mydb`，schema `llm_gateway` 和 `knowledge_manage` 已存在
4. Redis 服务运行中（用于聊天会话取消信号传播）
5. 至少配置两个供应商的 API Key（如 DeepSeek v4 pro 和 DeepSeek V4 flash）

## 环境启动

```bash
# LlmGateway 服务
cd LlmGateway
APP_ENV=dev uvicorn app.main:app --host 0.0.0.0 --port 8003

# KnowledgeManage 服务
cd KnowledgeManage
APP_ENV=dev uvicorn app.main:app --host 0.0.0.0 --port 8002
```

## 数据库迁移

```bash
# LlmGateway - 新增 capabilities 字段
cd LlmGateway
alembic upgrade head

# KnowledgeManage - 新增 status 字段
cd KnowledgeManage
alembic upgrade head
```

## 验证场景

### V-001: 非流式模型调用（P1）

**验证目标**: 统一 API 可调用不同供应商模型并返回格式一致的响应

```bash
# 获取 API Key（通过 003-api-keys-management 创建）
API_KEY="[REDACTED]"

# 调用模型 A（OpenAI Responses API 适配器）
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "Hello, who are you?"}],
    "stream": false
  }'

# 调用模型 B（Anthropic Messages API 适配器）
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-v4-flash",
    "messages": [{"role": "user", "content": "Hello, who are you?"}],
    "stream": false
  }'
```

**预期**: 两个请求均返回 200，响应结构一致（含 id、object、choices、usage）。

---

### V-002: 流式模型调用（P1）

**验证目标**: stream=true 时 SSE 逐块返回，流结束有 usage 和 [DONE]

```bash
curl -N -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "Write a short poem"}],
    "stream": true
  }'
```

**预期**:
- 响应 `Content-Type: text/event-stream`
- 逐行收到 `data: {...}` 事件，每行含内容 delta
- 最终 chunk 含 `finish_reason: "stop"` 和 `usage` 字段
- 最后一行 `data: [DONE]`

---

### V-003: 结构化输出（P2）

**验证目标**: response_format=json_object 时返回合法 JSON，Schema 校验通过

```bash
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "List 3 programming languages"}],
    "stream": false,
    "response_format": {
      "type": "json_object",
      "schema": {
        "type": "object",
        "properties": {
          "languages": {
            "type": "array",
            "items": {"type": "string"}
          }
        },
        "required": ["languages"]
      }
    }
  }'
```

**预期**: 响应的 `choices[0].message.content` 为合法 JSON，含 `languages` 数组字段。

---

### V-004: 提示词模板引用（P2）

**验证目标**: 传入 prompt_name + version 时，系统从 KnowledgeManage 获取模板并应用

```bash
# 先在 KnowledgeManage 中创建一个提示词模板
curl -X POST http://localhost:8002/api/knowledge/prompts \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "translator",
    "version": "1.0",
    "content": "You are a professional translator. Translate all user input to English."
  }'

# 使用模板调用模型
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "你好世界"}],
    "stream": false,
    "prompt_name": "translator",
    "prompt_version": "1.0"
  }'
```

**预期**: 模型响应将中文翻译为英文，证明系统提示词模板已生效。

---

### V-005: 限流验证（P2）

**验证目标**: 超过模型 RPM 配置时返回 429

```bash
# 将模型 RPM 临时设为 5（通过管理 API）
# 然后快速发送 6 个请求
for i in $(seq 1 6); do
  curl -s -o /dev/null -w "%{http_code}\n" \
    -X POST http://localhost:8003/api/llm/v1/chat/completions \
    -H "Authorization: Bearer $API_KEY" \
    -H "Content-Type: application/json" \
    -d '{"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}], "stream": false}'
done
```

**预期**: 前 5 个请求返回 200，第 6 个返回 429。

---

### V-006: 重试与错误处理（P2）

**验证目标**: 供应商不可用时自动重试/Fallback，全部失败返回统一错误码

```bash
# 请求一个配置了无效 URL 的模型（模拟供应商不可用）
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "invalid-model",
    "messages": [{"role": "user", "content": "test"}],
    "stream": false
  }'
```

**预期**: 返回 404 错误（model_not_found）或 502 错误（adapter_unavailable），含统一错误码格式。

---

### V-007: 可观测性验证（P2）

**验证目标**: 调用后可在 Prometheus 端点查到对应指标

```bash
# 1. 发送一次模型调用
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}], "stream": false}'

# 2. 查看 Prometheus 指标
curl http://localhost:8003/metrics | grep llm_
```

**预期**: 能看到 `llm_request_total`、`llm_tokens_total`、`llm_latency_seconds` 等指标，且含 `user_email` 标签。

---

### V-008: 聊天会话端到端（P3）

**验证目标**: 创建会话 → 发送消息 → 流式接收 → 取消 → 查看历史

```bash
# 1. 创建会话
CHAT_ID=$(curl -s -X POST http://localhost:8002/api/knowledge/chats \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title": "Test session", "model_id": "model-uuid"}' | jq -r '.id')

# 2. 发送消息（流式接收 SSE）
curl -N -X POST http://localhost:8002/api/knowledge/chats/$CHAT_ID/messages \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content": "Tell me a long story"}' &

# 3. 取消会话（在流式输出进行中）
sleep 2
curl -X POST http://localhost:8002/api/knowledge/chats/$CHAT_ID/cancel \
  -H "Authorization: Bearer $JWT_TOKEN"

# 4. 查看历史消息
curl http://localhost:8002/api/knowledge/chats/$CHAT_ID/messages \
  -H "Authorization: Bearer $JWT_TOKEN"
```

**预期**:
- 步骤 2: SSE 流正常返回内容片段
- 步骤 3: 返回 200，状态变为 `cancelled`
- 步骤 4: 能看到已生成的部分消息历史

## 参考

- API 合同详情: [contracts/openai-compatible-api.md](contracts/openai-compatible-api.md)
- 聊天会话合同: [contracts/chat-sessions-api.md](contracts/chat-sessions-api.md)
- 数据模型: [data-model.md](data-model.md)
