# Quickstart: 文档解析与分片验证指南

## 前提条件

以下服务必须已启动并可用：

| 服务 | 地址 | 说明 |
|------|------|------|
| PostgreSQL | localhost:5432 | 用户 `admin`，数据库 `mydb`，schema `knowledge_manage` |
| Elasticsearch | localhost:9200 | 用户 `elastic`，密码 `123456` |
| MinIO (RustFS) | localhost:9000 | 用户 `minioadmin`，密码 `minioadmin`，bucket `myknowlege` |
| Redis | localhost:6379 | 默认配置 |
| LlmGateway | localhost:8003 | 需已配置 Embedding/LLM/视觉模型 |
| MinerU | localhost:8000 | 文档解析服务 |
| UserManage | localhost:8001 | 用户认证服务 |

## 验证场景

### V1: 单文档上传与标题切分

1. **启动 KnowledgeManage 服务**:
   ```bash
   cd KnowledgeManage && uvicorn app.main:app --reload --port 8002
   ```

2. **通过前端或 API 上传 PDF/DOCX 文件**:
   - 设置分块策略为"按标题切分"
   - 分块大小 512，分块重叠 80
   - AI问题数 3

3. **验证点**:
   - [ ] Document 表 status 依次变化: `pending → parsing → chunking → embedding → ai_generating → completed`
   - [ ] ES 索引 `knowledge_chunks_{kb_id}` 中存在 text/image_ocr/image_caption/table_row/ai_question 类型的 chunks
   - [ ] 每个 text chunk 的 content 前缀包含 `[文件名: xxx]`
   - [ ] 表格行 chunk 未被中间截断（验证行完整性）
   - [ ] 前端"文档分片"tab 展示所有分片，图片正确渲染

4. **查询 chunks API**:
   ```bash
   curl http://localhost:8002/api/knowledge/documents/{doc_id}/chunks?page=1&page_size=10
   ```

### V2: 按固定长度切分

1. 上传同一文档，设置分块策略为"按固定长度切分"，chunk_size=1000，chunk_overlap=150
2. **验证点**:
   - [ ] 分片长度不超过 1000 字符（表格行 chunk 除外）
   - [ ] 相邻分片有约 150 字符重叠
   - [ ] 分隔符按优先级生效

### V3: 独立图片上传

1. 上传单张 PNG 图片
2. **验证点**:
   - [ ] 生成 image chunk（parent_chunk_id = null）
   - [ ] 生成 image_ocr chunk（parent_chunk_id → image chunk）
   - [ ] 上传含表格的图片时，`image_ocr` 保留 MinerU 返回的表格 Markdown，但不保留 `images/...` 裁剪图引用
   - [ ] 生成 image_caption chunk（parent_chunk_id → image chunk）
   - [ ] 前端"原始内容"和"解析后Markdown"均展示图片

### V4: 独立表格文件上传

1. 上传 xlsx 文件（含多 sheet）
2. **验证点**:
   - [ ] 校验通过（无合并单元格、表头在第一行、无空行）
   - [ ] SQLite db 文件存储在 MinIO（`{kb_id}/{doc_id}/tables/`）
   - [ ] 每个 sheet 生成 table_row chunks
   - [ ] 前端"原始内容"展示表格

### V5: 压缩包批量上传

1. 上传包含 docx + xlsx + png 的 zip 文件
2. **验证点**:
   - [ ] 各文件按默认策略处理（docx→标题切分，xlsx→表格行，png→图片 chunk）
   - [ ] 前端不显示分块设置选项
   - [ ] 不支持的文件类型被跳过并提示

### V6: 失败处理验证

- 在解析进行中删除文档，确认后端停止后续处理，并清理已生成的分片和中间文件，不再写入处理状态。

1. **模拟 MinerU 服务不可用**: 停止 MinerU 服务后上传文档
2. **验证点**:
   - [ ] Document status 标记为 `failed`
   - [ ] ES 中无残留 chunks
   - [ ] MinIO 中无残留中间文件
   - [ ] 前端显示"处理失败"状态

### V7: 重新上传同名文档

1. 上传一个文件处理完成后，再次上传同名文件
2. **验证点**:
   - [ ] 旧文档的 chunks 和 MinIO 文件被清理
   - [ ] 新文档重新处理

## 数据验证 SQL

```sql
-- 查看文档处理状态
SELECT id, name, status FROM knowledge_manage.documents ORDER BY created_at DESC LIMIT 10;

-- 查看 ES 索引中的 chunks 数量
-- 通过 Kibana 或 curl:
curl -u elastic:123456 http://localhost:9200/knowledge_chunks_*/_count
```

## 相关文档

- [数据模型](./data-model.md)
- [API 契约](./contracts/document-processing-api.md)
- [技术研究](./research.md)
