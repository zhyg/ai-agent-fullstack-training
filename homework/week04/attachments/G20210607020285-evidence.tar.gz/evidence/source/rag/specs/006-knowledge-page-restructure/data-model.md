# Data Model: 知识库管理页面重组

**Date**: 2026-11-16

本特性为纯前端导航重组，不涉及数据库表、API 接口或后端数据模型的变更。以下为导航结构的数据模型描述。

## 导航结构

### 知识库平台侧边栏菜单

| 字段 | 类型 | 说明 |
|------|------|------|
| key | string | 菜单项唯一标识：`"chat"` / `"knowledge"` / `"agent"` |
| label | string | 菜单项显示文字：`"新会话"` / `"知识库"` / `"智能体"` |
| icon | component | Ant Design 图标组件：`MessageOutlined` / `BookOutlined` / `RobotOutlined` |
| route | string | 对应路由路径：`"/chat"` / `"/knowledge"` / `"/agent"` |

### 路由-菜单映射（routeToKey）

| 路由路径 | 菜单 Key | 视图组件 |
|---------|----------|---------|
| `/chat` | `chat` | `ChatManagement.vue` |
| `/knowledge` | `knowledge` | `KnowledgeManagement.vue` |
| `/agent` | `agent` | `AgentManagement.vue` |

### 侧边栏可见性规则

侧边栏在以下路由路径下可见：
- `/chat`
- `/knowledge`
- `/agent`

其他路由（`/prompts`、`/models`、`/api-keys`、`/permissions`）下侧边栏不显示。

### 顶部导航菜单变更

| 变更前 | 变更后 |
|--------|--------|
| AI → 会话管理 (`/chat`) | AI → 知识库管理 (`/chat`) |

菜单项在 AI 下拉菜单中的位置不变（保持在提示词管理之后、模型管理之前）。
