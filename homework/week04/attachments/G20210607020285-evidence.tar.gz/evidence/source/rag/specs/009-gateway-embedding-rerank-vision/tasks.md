# Tasks: LLM Gateway 支持 Embedding、Rerank、视觉模型

**Input**: Design documents from `/specs/009-gateway-embedding-rerank-vision/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: 未明确要求 TDD，不包含独立测试任务。各服务方法应在实现时包含基本的错误处理验证。

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **LlmGateway**: `LlmGateway/app/` — Python 后端服务
- **Frontend**: `frontend/src/` — Vue.js 管理前端
- **Migrations**: `LlmGateway/alembic/versions/` — 数据库迁移脚本

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 确认现有代码基线，无需新建项目结构

- [x] T001 确认 LlmGateway 现有代码可正常启动运行（`uvicorn app.main:app`），确认 alembic 配置正确

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 所有用户故事共同依赖的基础设施变更——数据库迁移、数据模型扩展、运行时配置、协议 Schema。**必须在任何用户故事之前完成。**

- [x] T002 [P] 创建 alembic 迁移脚本，向 models 表新增 `dimensions`(Integer, nullable)、`max_input_tokens`(Integer, nullable)、`supported_modalities`(JSON, nullable) 三个字段，在 `LlmGateway/alembic/versions/` 下
- [x] T003 [P] 在 `LlmGateway/app/models/model.py` 的 Model 类中新增 `dimensions`(Integer, nullable)、`max_input_tokens`(Integer, nullable)、`supported_modalities`(JSON, nullable) 三个 SQLAlchemy Column
- [x] T004 [P] 在 `LlmGateway/app/adapters/base.py` 的 `ModelConfig` dataclass 中新增字段：`category: str = "chat"`、`dimensions: int | None = None`、`max_input_tokens: int | None = None`、`supported_modalities: list[str] | None = None`
- [x] T005 [P] 在 `LlmGateway/app/adapters/base.py` 的 `BaseAdapter` 类中新增 `embed()` 和 `rerank()` 可选方法，默认抛出 `NotImplementedError`
- [x] T006 修改 `LlmGateway/app/gateway/registry.py` 的 `ModelRegistry.load_from_db()` 加载新字段（category、dimensions、max_input_tokens、supported_modalities）到 ModelConfig；修改 `get_model_config()` 方法签名新增 `category: str | None = None` 参数，当指定 category 时校验模型分类是否匹配，不匹配则抛出 `ModelNotFoundError`
- [x] T007 [P] 在 `LlmGateway/app/schemas/model.py` 的 `ModelCreate`、`ModelUpdate`、`ModelResponse` Schema 中新增 `dimensions`(Optional[int])、`max_input_tokens`(Optional[int])、`supported_modalities`(Optional[list[str]]) 字段
- [x] T008 [P] 在 `LlmGateway/app/schemas/chat_completion.py` 中新增 `ContentPart` Pydantic 模型（type: Literal["text","image_url"]，text: Optional[str]，image_url: Optional[dict]）；将 `ChatCompletionMessage.content` 类型从 `str` 改为 `Union[str, list[ContentPart]]`
- [x] T009 修改 `LlmGateway/app/adapters/openai_adapter.py`：重构 URL 构建逻辑——将 `_normalize_url` 替换为 `_build_url(base_url, sub_path)` 方法，`_build_url("https://api.openai.com/v1", "chat/completions")` → `"https://api.openai.com/v1/chat/completions"`；现有 `complete()` 和 `stream()` 调用 `_build_url(url, "chat/completions")`
- [x] T010 修改 `LlmGateway/app/services/llm_gateway_service.py` 的消息序列化逻辑：将 `m.content` 直接赋值改为 `isinstance` 类型判断——若 content 为 str 则直接赋值，若为 `list[ContentPart]` 则做 `[part.model_dump(exclude_none=True) for part in m.content]` 转换

**Checkpoint**: 数据库迁移可执行，ModelConfig 包含新字段，Registry 支持 category 过滤，OpenAI URL 重构完成，Chat 消息体已支持多模态。所有用户故事的基础设施已就绪。

---

## Phase 3: User Story 1 - 文本向量化 Embedding API (Priority: P1) 🎯 MVP

**Goal**: 提供 `POST /api/llm/v1/embeddings` 端点，接受单条或批量文本，返回向量表示，记录用量和成本。

**Independent Test**: 向 `/v1/embeddings` 发送单段文本请求，验证返回 200 且 `data` 数组包含正确维度的向量，`usage.prompt_tokens > 0`。

### Implementation for User Story 1

- [x] T011 [P] [US1] 创建 Embedding 请求/响应 Pydantic Schema：`EmbeddingRequest`（model: str, input: Union[str, list[str]] max 2048 items, dimensions: Optional[int]）和 `EmbeddingResponse`（object: "list", data: list[EmbeddingData], model: str, usage: UsageInfo），在 `LlmGateway/app/schemas/embedding.py`
- [x] T012 [US1] 在 `LlmGateway/app/adapters/openai_adapter.py` 中实现 `embed()` 方法：POST `{base_url}/embeddings`，payload 含 `model`、`input`、可选 `dimensions`，解析 OpenAI 兼容响应并转换为 EmbeddingResponse 格式
- [x] T013 [US1] 在 `LlmGateway/app/services/llm_gateway_service.py` 中新增 `process_embedding_request()` 方法：流程为 解析 model(category=embedding) → 限流(RPM/TPM，TPM 按 `sum(len(t)//4 for t in texts)` 估算) → 重试(execute_with_retry, 最多3次) → adapter.embed() → 记录 InvocationRecord(category="embedding", input_count=文本条数) → 计算成本(input_tokens * input_per_million) → 返回 EmbeddingResponse
- [x] T014 [US1] 创建 `LlmGateway/app/routers/v1_embeddings.py`：实现 `POST /v1/embeddings` 端点，解析 EmbeddingRequest，调用 LLMGatewayService.process_embedding_request()，返回 EmbeddingResponse。错误处理：model 不存在或 category 不匹配返回 404，input 校验失败返回 400
- [x] T015 [US1] 修改 `LlmGateway/app/main.py`：导入并注册 v1_embeddings router（prefix 与现有 v1_chat 一致）

**Checkpoint**: Embedding 端点可用，单条/批量文本请求返回正确向量，用量和成本已记录。

---

## Phase 4: User Story 2 - 搜索结果重排序 Rerank API (Priority: P2)

**Goal**: 提供 `POST /api/llm/v1/rerank` 端点，接受查询和候选文档，返回按相关性排序的结果。

**Independent Test**: 向 `/v1/rerank` 发送查询和 3 条文档，验证返回结果按 `relevance_score` 降序排列。

### Implementation for User Story 2

- [x] T016 [P] [US2] 创建 Rerank 请求/响应 Pydantic Schema：`RerankRequest`（model: str, query: str max 10000 chars, documents: list[str] 1-500 items, top_n: Optional[int] ge=1, return_documents: bool default=True）和 `RerankResponse`（id: str, results: list[RerankResult], model: str, usage: UsageInfo），在 `LlmGateway/app/schemas/rerank.py`
- [x] T017 [US2] 创建 `LlmGateway/app/adapters/cohere_rerank_adapter.py`：实现 `CohereRerankAdapter`，继承 `BaseAdapter`，实现 `rerank()` 方法——POST `{base_url}/rerank`（Cohere 兼容格式），payload 含 `model`、`query`、`documents`、`top_n`、`return_documents`，解析响应并转换为 RerankResponse 格式。`complete()`/`stream()`/`embed()` 保持 NotImplementedError
- [x] T018 [US2] 在 `LlmGateway/app/services/llm_gateway_service.py` 中新增 `process_rerank_request()` 方法：流程为 解析 model(category=rerank) → 限流(RPM/TPM，TPM 按 `(len(query)+sum(len(d) for d in docs))//4` 估算) → 重试(execute_with_retry, 最多3次) → adapter.rerank() → 记录 InvocationRecord(category="rerank", input_count=文档条数) → 计算成本(input_tokens * input_per_million) → 返回 RerankResponse
- [x] T019 [US2] 创建 `LlmGateway/app/routers/v1_rerank.py`：实现 `POST /v1/rerank` 端点，解析 RerankRequest，校验 documents 非空且 ≤500 条，调用 LLMGatewayService.process_rerank_request()，返回 RerankResponse。错误处理：model 不存在或 category 不匹配返回 404，documents 校验失败返回 400
- [x] T020 [US2] 修改 `LlmGateway/app/main.py`：注册 v1_rerank router；在 lifespan 中注册 `CohereRerankAdapter`（与现有 OpenAIAdapter、AnthropicAdapter 注册方式一致）

**Checkpoint**: Rerank 端点可用，查询和文档请求返回按分数降序排列的结果，用量和成本已记录。

---

## Phase 5: User Story 3 - 图片理解 Vision API (Priority: P2)

**Goal**: 扩展现有 Chat 接口，支持在消息中嵌入图片（URL 或 Base64），视觉模型能理解图片并返回文字回答。

**Independent Test**: 向 `/v1/chat/completions` 发送包含图片 URL 的消息，验证视觉模型返回对图片内容的文字描述。

### Implementation for User Story 3

- [x] T021 [US3] 修改 `LlmGateway/app/routers/v1_chat.py`：在处理请求时增加 Vision 校验逻辑——当 `ChatCompletionMessage.content` 为 `list[ContentPart]` 且包含 `image_url` 类型时，检查 `model_config.supported_modalities` 是否包含 `"image"`，若不包含则返回 400 `invalid_request` 提示该模型不支持图片输入；对 `image_url` 中的 Base64 Data URI 校验大小，超过 20MB 返回 400 提示图片过大
- [x] T022 [US3] 修改 `LlmGateway/app/routers/v1_chat.py`：确保 Vision 模型（category=vision）收到纯文本请求（content 为 str 或仅含 type=text 的 ContentPart）时，走标准 Chat 链路正常处理不报错

**Checkpoint**: Vision 模型可接受图片请求并返回文字理解，纯文本模型拒绝图片请求返回 400，Vision 模型处理纯文本请求正常。现有 Chat API 完全向后兼容。

---

## Phase 6: User Story 4 - 管理员配置多类型模型 (Priority: P1)

**Goal**: 管理员在模型管理面板中添加/编辑 Embedding、Rerank、Vision 类型模型，前端表单根据所选 category 动态显示专属字段。

**Independent Test**: 在管理面板添加一个 Embedding 模型并填写 dimensions，验证保存成功且列表中可见。

### Implementation for User Story 4

- [x] T023 [P] [US4] 修改 `frontend/src/stores/model.js`：在模型数据中新增 `dimensions`、`max_input_tokens`、`supported_modalities` 字段，确保 CRUD 操作携带这些字段
- [x] T024 [US4] 修改 `frontend/src/views/ModelManagement.vue`：在模型表单中新增分类专属字段区域——当 category 为 `embedding` 时显示 `dimensions`(number input) 和 `max_input_tokens`(number input)；当 category 为 `rerank` 时显示 `max_input_tokens`(number input)；当 category 为 `vision` 时显示 `supported_modalities`(多选或 JSON 输入)；当 category 为 `chat` 时隐藏所有专属字段
- [x] T025 [US4] 修改 `frontend/src/views/ModelManagement.vue`：确保模型列表中展示 category 标签，编辑现有 Chat 模型时新增字段为空不影响保存

**Checkpoint**: 管理员可通过前端表单添加 Embedding/Rerank/Vision 模型，表单字段根据 category 动态切换，现有 Chat 模型编辑不受影响。

---

## Phase 7: User Story 5 - 多类型模型统一监控 (Priority: P3)

**Goal**: 运维人员在监控面板中按模型类型（category）维度查看调用量、Token 用量、成本和延迟。

**Independent Test**: 执行若干 Embedding/Rerank 请求后，访问 `/metrics` 端点确认 `llm_request_total` 指标包含 `category` 标签。

### Implementation for User Story 5

- [x] T026 [US5] 修改 `LlmGateway/app/gateway/observability.py`：在 `InvocationRecord` dataclass 中新增 `category: str = "chat"` 和 `input_count: int | None = None` 字段
- [x] T027 [US5] 修改 `LlmGateway/app/gateway/observability.py`：在现有 Prometheus 指标 `llm_request_total`、`llm_tokens_total`、`llm_latency_seconds`、`llm_cost_estimate` 的 labels 中新增 `"category"`（破坏性变更，需同步更新 Grafana Dashboard）
- [x] T028 [P] [US5] 在 `LlmGateway/app/gateway/observability.py` 中新增 Embedding 专属指标：`llm_embedding_requests_total` Counter（labels: model, user_email）和 `llm_embedding_texts_total` Counter（labels: model, user_email）
- [x] T029 [P] [US5] 在 `LlmGateway/app/gateway/observability.py` 中新增 Rerank 专属指标：`llm_rerank_requests_total` Counter（labels: model, user_email）和 `llm_rerank_documents_total` Counter（labels: model, user_email）
- [x] T030 [US5] 修改 `LlmGateway/app/gateway/observability.py` 的成本计算逻辑：Embedding 成本 = `input_tokens * input_per_million`（无 output 费用）；Rerank 成本 = `input_tokens * input_per_million`（按 query+documents 总 token 计，无 output 费用）；Chat/Vision 保持现有公式不变

**Checkpoint**: Prometheus 指标中包含 `category` 标签，Embedding/Rerank 专属指标可见，各类型成本计算正确。

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: 跨用户故事的验证和收尾工作

- [x] T031 运行 quickstart.md 中的全部 12 个验证场景（V-001 ~ V-012），确认所有场景通过预期结果
- [x] T032 执行向后兼容性验证：使用升级前格式的纯文本 Chat 请求（content 为 string），确认响应与升级前完全一致（SC-005）
- [x] T033 更新 `LlmGateway/README.md`：新增 Embedding/Rerank/Vision API 使用文档，包含端点说明、请求示例和响应格式

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup — **BLOCKS all user stories**
- **US1 Embedding (Phase 3)**: Depends on Foundational
- **US2 Rerank (Phase 4)**: Depends on Foundational
- **US3 Vision (Phase 5)**: Depends on Foundational
- **US4 Admin Config (Phase 6)**: Depends on Foundational（后端 API Schema 已在 T007 更新）
- **US5 Monitoring (Phase 7)**: Depends on Foundational；与 US1-US3 的服务方法协作（InvocationRecord 字段已在 Phase 7 定义，服务方法在 Phase 3-5 中已使用该字段）
- **Polish (Phase 8)**: Depends on all user stories complete

### User Story Dependencies

- **US1 (P1)**: Can start after Phase 2 — 无其他故事依赖
- **US2 (P2)**: Can start after Phase 2 — 无其他故事依赖
- **US3 (P2)**: Can start after Phase 2 — 无其他故事依赖
- **US4 (P1)**: Can start after Phase 2 — 后端 API 已就绪，前端独立修改
- **US5 (P3)**: Can start after Phase 2 — 与 US1-US3 并行但建议在其后以便端到端验证

**注意**: US1、US2、US3、US4 在 Phase 2 完成后可完全并行实施。

### Within Each User Story

- Schemas before adapters
- Adapters before services
- Services before routers
- Router registration last

### Parallel Opportunities

- Phase 2 中标记 [P] 的 T002、T003、T004、T005、T007、T008 可并行执行
- Phase 3 的 T011 可与 Phase 4 的 T016 并行（不同文件）
- Phase 7 的 T028 和 T029 可并行执行（同一文件但不同代码块）

---

## Parallel Example: User Story 1 (Embedding)

```text
# Launch schemas and adapter research in parallel:
Task T011: "Create Embedding request/response Schema in app/schemas/embedding.py"

# After schema, proceed sequentially:
Task T012: "Implement embed() in OpenAIAdapter"
Task T013: "Implement process_embedding_request() in service"
Task T014: "Create /v1/embeddings router"
Task T015: "Register embeddings router in main.py"
```

## Parallel Example: Cross-Story Parallelism

```text
# After Phase 2 (Foundational) is complete, all stories can proceed in parallel:
Story US1: T011 → T012 → T013 → T014 → T015
Story US2: T016 → T017 → T018 → T019 → T020
Story US3: T021 → T022
Story US4: T023 → T024 → T025
Story US5: T026 → T027 → T028/T029 → T030
```

---

## Implementation Strategy

### MVP First (US1 Embedding + US4 Admin Config)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: US1 Embedding — 核心 API 能力
4. Complete Phase 6: US4 Admin Config — 管理员可配置模型
5. **STOP and VALIDATE**: 测试 Embedding 端点 + 管理面板配置
6. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add US1 Embedding → Test independently → Deploy (MVP!)
3. Add US4 Admin Config → Admin can configure → Deploy
4. Add US2 Rerank → Test independently → Deploy
5. Add US3 Vision → Test independently → Deploy
6. Add US5 Monitoring → Full observability → Deploy
7. Polish → Final validation → Release

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Once Foundational is done:
   - Developer A: US1 Embedding (Phase 3)
   - Developer B: US4 Admin Config (Phase 6)
   - Developer C: US2 Rerank (Phase 4)
3. Stories complete and integrate independently
4. US3 Vision and US5 Monitoring follow

---

## Notes

- [P] tasks = different files or independent code blocks, no dependencies
- [Story] label maps task to specific user story for traceability
- 每个用户故事应可独立完成和测试
- T009（URL 重构）是关键风险点——需确保现有 Chat 功能不受影响
- T027（Prometheus category label）为破坏性变更，上线前需同步更新 Grafana Dashboard
- Commit after each task or logical group
- 所有路径相对于仓库根目录
