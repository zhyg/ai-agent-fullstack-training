# Phase 0 Research: 智能体逻辑实现

**Feature**: 012-agent-logic-runtime | **Date**: 2026-11-23

Technical Context 中无遗留 NEEDS CLARIFICATION（规格澄清已收敛权限/交互项，PRD §0.3 默认值已采纳）。本文档对实现层面的技术选型与既有代码差异点逐项给出决策。所有决策均基于对现有代码的实际核查。

---

## R1. 编排框架：langgraph StateGraph + httpx 网关客户端

- **Decision**: 三类流程用 `langgraph.StateGraph` 建模（节点=步骤，条件边=循环/收敛分支），状态载体为 TypedDict 风格的 `RequestRuntimeState`；模型调用统一用 `httpx.AsyncClient` 发送 OpenAI 兼容 payload 到 LlmGateway，不引入 llamaindex 的 LLM/Workflow 抽象（llama-index-core 依赖保留但本特性不使用）。
- **Rationale**:
  - PRD 明确实现库选择归 plan 决定（spec Assumptions）；langgraph 的条件边天然表达"充足判断→下一轮/答案"与"有工具调用→继续决策"两类循环，且 state 即请求级内存态，与"plan 不落库"决策（澄清 13）吻合。
  - 既有 `chat_service` 已用 httpx 流式调网关（`/api/llm/v1/chat/completions`），复用同一模式可精确控制 SSE 增量、取消检查点与超时；llamaindex 的封装会遮蔽流式细节并使取消传播复杂化。
  - langgraph 支持在节点入口检查 `asyncio.Event` 取消信号，满足 FR-031"停止信号传达至所有待执行环节"。
- **Alternatives considered**:
  - llamaindex Workflow/AgentRunner：事件驱动抽象与既有 SSE/取消骨架集成成本高，流式后处理（引用缓冲）需绕过其回调链 → 拒绝。
  - 纯手写 asyncio 循环：可行但三类流程共享步骤/分支逻辑会重复，且 PRD 倾向 langgraph；langgraph 图结构可直接映射 trace span 树 → 拒绝手写。

## R2. 模型接入与 display_name 解析

- **Decision**: 复用 `embedding_service.resolve_model_name(model_id)` 的跨 schema 只读查询模式（`SELECT COALESCE(display_name, name), context_tokens FROM llm_gateway.models WHERE id=:mid`，带内存缓存），扩展为 `resolve_model(model_id) -> {name, context_tokens, category}`。chat/embeddings/rerank 分别 POST 网关 `/api/llm/v1/chat/completions`、`/api/llm/v1/embeddings`、`/api/llm/v1/rerank`，Bearer `settings.llm_api_key`。
- **Rationale**: 网关已实现限流/传输层重试/观测（specs/004、009），业务层只需处理 JSON 校验重试（澄清 7）；rerank 为 Cohere 兼容 schema（query/documents/top_n/return_documents，已核查 `LlmGateway/app/schemas/rerank.py`）。
- **Alternatives considered**: 直连 provider（违反澄清 3）；经网关管理 API 查模型（引入服务间强耦合，跨 schema 只读查询是仓库既有惯例）→ 均拒绝。

## R3. "模型存在且启用"的判定口径

- **Decision**: 已核查 `LlmGateway/app/models/model.py`——models 表**无 enabled/status 字段**，全仓库无停用概念。预检（FR-003）中"模型存在且启用"落地为"模型记录存在"；"运行中被停用"落地为"运行中被删除"（resolve 失败或网关返回 model not found）。
- **Rationale**: 与现有模型管理能力一致，不臆造不存在的状态机。
- **Alternatives considered**: 为网关新增启用字段——超出本特性范围（spec 边界：不改动网关）→ 拒绝。

## R4. 断线语义：租约宽限后视同停止

- **Decision**: agent 模式下，SSE 客户端断开时不立即取消，而是启动租约宽限倒计时（复用既有 `LEASE_SECONDS=30`）：宽限期内前端 `resumeStream`（空 content reattach）成功则继续；租约到期仍无人认领 → 发布取消信号，流程按"用户停止"终止（部分答案落库标记"已停止"）。显式点击停止仍走既有 Pub/Sub 立即取消。旧"模型+提示词"模式保持现状（detach 后台继续）。
- **Rationale**: 现有 `chat_service` 断线仅 `job.detached.set()` 后台继续，与规格 FR-032"断线视同停止"冲突；但立即取消会破坏既有"刷新页面恢复生成中会话"体验（`resumeStream` 已上线）。租约宽限是两者的最小改动折中：页面刷新秒级重连不受影响，真正离开 30s 后流程终止，满足"断线视同停止"且复用既有租约机制（spec Assumptions 明示"复用既有生成租约"）。
- **Alternatives considered**: 断线立即取消（刷新页面即丢流程，UX 回退）；保持 detach 继续（违反 FR-032）→ 均拒绝。

## R5. 停止标记与取消检查点

- **Decision**: agent 模式取消落库标记为 `content + "\n[已停止]"`（旧模式保留 `"\n[已取消]"` 不动）。取消检查点设置在：每个 langgraph 节点入口、每次模型调用发起前、流式读取循环每批 delta、每个工具执行前（串行队列逐个检查）。检查点命中即抛 `AgentCancelled`，由 finalize 统一落库。
- **Rationale**: FR-031/SC-005 要求停止后 3s 内无新模型/工具调用；流式 delta 批间检查保证长答案也能秒级中断。工具串行执行（FR-030）使"广播至所有待执行工具"退化为队列前统一检查，实现简单且语义等价。
- **Alternatives considered**: 仅节点级检查（一次模型调用可能耗时 >3s，达不到 SC-005）→ 拒绝。

## R6. 消息/会话的持久化扩展

- **Decision**: Alembic 单迁移：
  - `chats` 增 `agent_id`(String36, nullable)、`agent_type`(String30, nullable)、`knowledge_base_ids`(JSONB, nullable, 默认空列表)。`agent_id IS NULL` 即存量旧模式会话（只读）。保留 model_id/model_name/prompt_id 列不删。
  - `messages` 增 `trace_id`(String32, nullable, index)、`meta`(JSONB, nullable)。assistant 消息 meta 存 `{stopped, references[], usage, error_code, raw_output, forced_convergence, terminate_reason}`；user 消息 meta 存 `{trace_id}` 冗余不需要——trace_id 直接写在**该轮 user 消息与 assistant 消息**两行上（FR-034"每个用户问题对应轨迹标识"，前端按 assistant 消息查）。
- **Rationale**: 引用弹层需在消息回放时还原"文档名+片段内容+文档链接"，必须随消息持久化 references；trace_id 是 OTel 128bit hex（32 字符）。JSONB 与仓库 `agents.config` 既有用法一致。
- **Alternatives considered**: 新建 message_references 表（引用只随消息整取，无独立查询需求，JSONB 足够）；trace_id 只存 assistant 行（user 行也存便于按问题定位，成本一列）→ 前者拒绝。

## R7. ES 检索实现（BM25 / 向量 / RRF 混合，多库融合）

- **Decision**: 新建 `retrieval_service.py`，不改既有索引 mapping（已核查 `es_client.ensure_index`：content=text/standard 分词，embeddings=dense_vector）：
  - BM25：`match` on `content`，size=keyword_top_k；
  - 向量：`script_score` + `cosineSimilarity(params.qv, 'embeddings') + 1.0`，size=vector_top_k（兼容 dense_vector 未显式 index:true 的旧索引，召回 ≤100 时性能可接受）；
  - 混合：两路各取 top_k 后在 Python 内做 RRF 融合（`score = Σ 1/(60+rank)`，k=60），按 chunk_id 合并去重，截断 hybrid_top_k；
  - 多知识库：ES 多索引查询（`index="knowledge_chunks_a,knowledge_chunks_b"`，`ignore_unavailable=True`——不存在的索引等同空结果，符合规格 Edge Case）；BM25 分数跨索引可比性弱，混合模式一律走 RRF（按名次而非原始分）规避；纯 BM25 多库时按 ES 返回分排序截断总数。
  - 问题向量化复用 `embedding_service.generate_embeddings`（网关重试后仍失败 → 抛流程级异常）。
- **Rationale**: 不迁移存量索引即可完成三种检索；RRF 是规格采纳的默认融合算法；script_score 避免对既有 mapping 的 index/similarity 假设。
- **Alternatives considered**: ES 原生 `rrf` retriever（需 8.14+ 且许可级别限制，版本风险）；kNN search（要求 dense_vector index=true，存量索引不保证）→ 均拒绝。

## R8. rerank 降级与压缩空结果语义

- **Decision**: `rerank_service.py` 调网关失败（网关重试后仍报错/超时）→ 按检索原始分排序截断 `rerank_top_n` 条继续，trace 记录 `rerank_degraded` 事件。压缩 `kept_indexes=[]` 为合法空结果：快速问答终止提示"检索结果为空"落库；推理行动视为不充足进下一轮；规划推理返回空 tool result。
- **Rationale**: 直接落实澄清 8/9，无备选分歧。
- **Alternatives considered**: 无。

## R9. token 预算估算

- **Decision**: 引入 `tiktoken`（cl100k_base）做近似计数：预算 = 快照中分析模型 `context_tokens` − `max_output_tokens`；核算对象 = 系统提示词 + 会话历史（默认最近 10 轮）+ 累积片段 + 引用协议文案。超预算先截最早历史轮次，再按轮次从早到晚淘汰片段，至少保留最新 1 条（FR-019）。工具结果截断上限默认 4000 tokens（`agent_runtime.tool_result_max_tokens` 可配）。
- **Rationale**: 网关聚合多 provider，无法拿到统一精确 tokenizer；cl100k_base 对中英文均为保守近似（中文偏多计），预算控制宁紧勿松。tiktoken 轻量且是 llama-index-core 生态常见依赖。
- **Alternatives considered**: 字符数/4 启发式（中文误差过大）；按 provider 精确 tokenizer（需感知网关路由目标，破坏统一接入）→ 均拒绝。

## R10. 循环空转检测阈值

- **Decision**: `new_question` 归一化（去空白/标点/大小写）后与上一轮完全相同，或 `difflib.SequenceMatcher` 相似度 ≥ 0.9 → 提前收敛进入答案生成，trace 记录 `idle_loop_converged` 事件。阈值 0.9 为默认值（规格未定数值，属低影响项）。
- **Rationale**: 标准库实现零依赖；0.9 足以拦截"换个标点再问一遍"式空转。
- **Alternatives considered**: embedding 余弦相似（每轮多一次网关调用，成本与延迟不划算）→ 拒绝。

## R11. Trace 采集：OTel SDK → OTLP gRPC → Collector → ES

- **Decision**: 新增 `agent_runtime/tracing.py`：进程级单例 TracerProvider（Resource `service.name=knowledge-manage-agent`）+ `BatchSpanProcessor` + `OTLPSpanExporter(endpoint=settings.tracing.otlp_endpoint, insecure=True)`，与 `opentelemetryDemo/demo.py` 及 `otel-collector-config.yaml` 的既有链路（4317 → ES `jaeger-span-YYYY-MM-DD`）一致。span 树约定：
  - 根 `agent.run`（属性：chat_id、message_id、agent_type、enduser.id、session.id），其 trace_id 即落库值；
  - 步骤子 span：`agent.clarify` / `agent.rewrite` / `agent.retrieve.{mode}` / `agent.rerank` / `agent.compress` / `agent.sufficiency` / `agent.plan_decision` / `agent.answer` / `agent.tool.{toolName}`，循环轮次以属性 `agent.loop` 标注；工具内部的模型调用（rewriteQuestion/zip）在工具 span 下按对应步骤名产生子 span，保证每次模型调用入轨迹；
  - 每步输入/输出以 span 属性 `agent.input` / `agent.output`（JSON 字符串，单属性截断上限 32KB）记录，含完整提示词与模型原始输出（澄清 Q1：不脱敏）；
  - 降级/强制收敛/无效引用/空转收敛以 span event 记录（`rerank_degraded`、`forced_convergence`、`invalid_ref_dropped`、`idle_loop_converged`）；
  - 工具 span 属性携带 `tool.call_id` 全链路一致（FR-029）；
  - 请求 finalize 时 `force_flush(timeout=5s)` 缩短"写入中"窗口；导出失败仅记日志不影响主流程（FR-033）。
  - `tracing.enabled=false` 时用 NoOp Tracer，本地开发无 Collector 也可跑通（trace 查询返回"写入中/不可用"提示）。
- **Rationale**: 完全复用已验证的 demo 链路与 TraceViewer 数据格式，不新建轨迹存储。
- **Alternatives considered**: 自写轨迹表（违反"数据结构以既有轨迹存储格式为准"）；SimpleSpanProcessor 同步导出（阻塞主流程）→ 均拒绝。

## R12. Trace 查询代理与格式转换

- **Decision**: 新接口 `GET /chats/{chat_id}/messages/{message_id}/trace`：校验消息归属当前用户会话 → 取 message.trace_id 与 created_at → 查 ES 索引 `jaeger-span-{date-1},{date},{date+1}`（±1 天容错，`term: traceID`）→ 将 ES 文档转换为 Jaeger UI 格式 `{data:[{traceID, spans, processes}]}`（TraceViewer `api.ts` 已按此格式消费，时间单位微秒）。无 trace_id 或查询为空 → 200 `{ready:false}`（前端提示"trace 写入中，稍后重试"）；跨用户 → 403。
- **Rationale**: FR-036 明确要求后端代理 + 日期容错 + 归属校验；前端不直连 ES。ES jaeger 文档字段（traceID/spanID/operationName/references/startTime/duration/tags/process）与 Jaeger API 字段基本同名，转换主要是 references 的 CHILD_OF 规范化与 processes 去重合并。
- **Alternatives considered**: 部署 Jaeger Query 服务并代理其 API（多一个常驻服务，且现有 Collector 直写 ES 无 jaeger-query）→ 拒绝。

## R13. 引用协议与流式后处理

- **Decision**: 上下文注入格式：每片段 `[cN] (文档名) 内容`，cN 从 1 递增；答案提示词尾部追加系统级来源协议（仅引用出现过的句柄、`<ref id="cN"/>` 内联于结论同句、禁止暴露原始片段/知识库标识）。流式后处理状态机：缓冲疑似不完整 `<ref ...>` 前缀（最长标签长度），完整标签校验 cN 有效性——有效则原样下发 `<ref id="cN"/>`，无效则丢弃并记 trace 事件。SSE 在答案流开始前下发一次 `references` 事件（cN → {document_id, file_name, content, image_urls}），前端据此把 ref 标签渲染为可点击上标，点击弹层展示文档名+片段内容+"查看文档"链接（跳既有文档预览路由）。落库 content 保留 ref 标签，meta.references 存完整映射。图片：片段内容与 references 中的 MinIO 路径统一替换为预签名 URL（expires=86400，与 chunks 路由一致，满足 ≥1h）；过期刷新走新接口 `POST /chats/{chat_id}/messages/{message_id}/refresh-urls` 重签并返回。
- **Rationale**: 后端展开为"文档名+片段内容"通过 references 映射交付（而非把全文塞进答案文本），答案文本保持简洁、弹层数据可回放；预签名复用 `storage_service.get_presigned_url` 既有实现。
- **Alternatives considered**: 后端把引用展开为 Markdown 脚注全文（答案膨胀、图片链接无法集中刷新）；前端自行解析检索结果（前端无检索数据）→ 均拒绝。

## R14. Tool Runtime 统一入口与受控结果

- **Decision**: `tools/runtime.py` 提供 `execute_tool(call_id, name, args, ctx, cancel_event) -> ToolResult`：13 工具各配 Pydantic 入参模型（校验失败直接返回失败结果，不抛异常）；执行异常内部重试最多 3 次后返回失败结果；结果信封 `{success, code, content, artifact_path?}`；content 超 4000 tokens 截断并附"结果已截断，共 N 条"。工具串行执行；每次执行包 `agent.tool.{name}` span，call_id 从模型输出→执行→tool result 消息→trace 全程透传。未启用工具不进入模型的 tools 列表（对模型不可见）。
- **Rationale**: FR-025/029/030 直接落地；信封与 OpenAI tool 消息协议兼容（content 为字符串 JSON）。
- **Alternatives considered**: 并行工具执行（违反 FR-030 串行约定）→ 拒绝。

## R15. 表格工具安全（listTableMetaData / sqlExecute）

- **Decision**:
  - 下载：仅接受本次请求检索片段中出现过的 `sqlite_url`（白名单集合存于 RequestRuntimeState）；经 `storage_service.get_presigned_url` 下载，上限 50MB / 30s；本地缓存 `/tmp/km_sqlite_cache/{sha256(url)}.db`，命中复用，TTL 1h 定期清理。
  - 只读保障（双保险）：① 语句校验——剥注释/空白后必须以 SELECT 开头、`sqlite3.complete_statement` 判定单语句、拒绝分号多语句与 ATTACH/PRAGMA 写形式；② 连接级——`sqlite3.connect("file:...?mode=ro", uri=True)` 只读打开，写操作在引擎层必然失败。
  - 元数据：`sqlite_master` + `PRAGMA table_info`（只读 PRAGMA 允许）返回表名/列名/类型 JSON；表描述取自片段内容中的表格描述（若有）。
  - 查询结果行数上限 500 行，超出截断附说明。
- **Rationale**: FR-026/027、SC-008；连接级只读使校验绕过也无法写库。
- **Alternatives considered**: 仅前缀校验（注释/编码绕过风险）；每次重新下载（延迟与带宽浪费）→ 均拒绝。

## R16. 配置快照与预检

- **Decision**: 开跑前 `snapshot.py` 一次性解析并冻结：各用途提示词**内容**（查 prompts 表）、分析/embedding/rerank 模型 `{id, name(display_name), context_tokens}`、检索配置、loop_count、tools、max_output_tokens——全部存入内存快照，运行中不再读配置表（FR-004）。预检失败（提示词不存在/模型不存在/知识库不存在或非本人所有）→ 立即 SSE error 事件并指明配置项，不落 assistant 消息。运行中网关返回 model not found 等 → 流程级异常终止。
- **Rationale**: 澄清 11 + FR-003/004；提示词冻结内容而非引用，天然免疫运行中修改。
- **Alternatives considered**: 每步实时读配置（违反快照决策）→ 拒绝。

## R17. 新增配置项与默认值

- **Decision**: `config.{env}.yaml` 新增两段（Settings 对应扩展，均有默认值，缺省可跑）：
  - `tracing`: `enabled=true`、`otlp_endpoint="http://localhost:4317"`、`service_name="knowledge-manage-agent"`
  - `agent_runtime`: `tool_result_max_tokens=4000`、`history_rounds=10`、`similarity_threshold=0.9`、`sqlite_max_bytes=52428800`、`sqlite_download_timeout=30`、`sqlite_cache_ttl=3600`、`sql_max_rows=500`、`presign_expires=86400`、`rrf_k=60`
- **Rationale**: 规格未定数值的低影响项在此定默认值并可配，避免硬编码。
- **Alternatives considered**: 全部硬编码（后续调参需改码）→ 拒绝。

## R18. 前端 trace 组件移植与 SSE 协议扩展

- **Decision**: TraceViewer 的 `TraceTimeline.vue`/`SpanDetail.vue`/`StatisticsView.vue` 及 `api.ts` 的 `buildSpanTree`（CHILD_OF 构树、微秒时间轴）移植为 JS 放入 `frontend/src/components/trace/`，外层 `TraceDrawer.vue` 用 ant-design-vue `a-drawer`（width≈60%，右侧滑出，无路由）。SSE 协议在既有 delta/usage/error/done/cancelled 之上新增 `step`（{step, status, loop, message?}，不含中间原始输出）与 `references` 事件；前端 chatApi 解析器与 chat store 相应扩展，旧事件格式兼容保留。
- **Rationale**: 澄清 Q4（抽屉）+ FR-035/015；TraceViewer 组件为纯 Vue3 无外部依赖，移植成本低；SSE 增量扩展不破坏旧模式前端。
- **Alternatives considered**: iframe 嵌 TraceViewer（双构建部署、鉴权传递复杂）；新增 /trace 路由（违反澄清 Q4）→ 均拒绝。

## R19. 并发拒绝与流程入口

- **Decision**: 复用既有 `chat_service` 生成租约：同会话已有活跃 generation（status=generating 且租约有效）时新提问返回 409（既有 `_claim_generation` 原子抢占机制），前端提示"当前问答尚未结束"。agent 模式入口在 `send_message_stream` 内按 `chat.agent_id` 分支：非空走 `agent_runtime.run_agent_generation`（产出事件进同一 `_GenerationJob` 队列/Redis Stream，取消/恢复/落库骨架全复用）；为空走旧路径。
- **Rationale**: FR-032 并发拒绝；最小侵入复用跨实例流恢复与观察者队列，避免重写生成生命周期。
- **Alternatives considered**: 独立 agent 问答端点（取消/恢复/租约需全套重做）→ 拒绝。