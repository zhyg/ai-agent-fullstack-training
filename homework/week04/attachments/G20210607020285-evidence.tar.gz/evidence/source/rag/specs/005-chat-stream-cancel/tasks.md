# Tasks: 聊天流式生成取消与断线恢复

**Input**: Design documents from `/specs/005-chat-stream-cancel/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: 已有测试文件 `test_chat_background.py`（10 个测试）和 `test_chat_stream.py` 定义了目标 API 契约，需要在实现过程中确保全部通过。

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup (No code changes)

**Purpose**: Review existing code and test files to understand target API contract

- [x] T001 Review existing test contract in `KnowledgeManage/tests/test_chat_background.py` — extract the expected module-level API: `_generations` dict, `_GenerationJob` (task/cancel/detached/done/_live), `finish_generations()`, `SessionLocal`, and `send_message_stream(chat_id, content, user_id)` 3-arg signature
- [x] T002 Review existing test contract in `KnowledgeManage/tests/test_chat_stream.py` — understand the current SSE event parsing and ensure backward compatibility
- [x] T003 Review current implementation in `KnowledgeManage/app/services/chat_service.py` — map the existing `send_message_stream` flow (state transition → save user message → call LLM Gateway → stream events → save assistant message) to identify what stays and what changes

---

## Phase 2: Foundational (Backend Infrastructure)

**Purpose**: Refactor `chat_service.py` to "background task + observer queue" architecture. This is the CRITICAL foundation that ALL user stories depend on.

**⚠️ CRITICAL**: No user story work can begin until this phase is complete.

- [x] T004 Add module-level imports and references at top of `KnowledgeManage/app/services/chat_service.py`: import `dataclasses` module, add `SessionLocal` module-level reference (set from `app.core.database.SessionLocal`), add `_generations: dict[str, _GenerationJob] = {}` module-level dict
- [x] T005 Define `_GenerationJob` dataclass in `KnowledgeManage/app/services/chat_service.py` with fields: `task: asyncio.Task`, `cancel: asyncio.Event`, `detached: asyncio.Event`, `done: asyncio.Event`, `_live: asyncio.Queue`, `content_buffer: str` (default empty string). Add helper methods: `_emit(event_str)` to put SSE event string onto `_live` queue
- [x] T006 Implement `_run_generation(job, chat_id, payload, headers, endpoint)` async function in `KnowledgeManage/app/services/chat_service.py` — the core background task that: (1) creates own DB session via `SessionLocal()`, (2) subscribes to Redis cancel channel and sets `job.cancel` on signal, (3) opens httpx stream to LLM Gateway, (4) reads SSE lines and on each delta: appends to `job.content_buffer` + calls `job._emit()` with formatted event, (5) checks `job.cancel` before each line to break early, (6) on completion: saves assistant message via `save_message()`, transitions chat status to `completed`, emits done/done-marker events, sets `job.done`, (7) on cancel: saves partial content with `\n[已取消]` suffix, emits `cancelled` event, (8) in finally block: cleans up Redis subscriber, removes job from `_generations` dict, emits `[DONE]`
- [x] T007 Refactor `send_message_stream(chat_id, user_content, user_id)` in `KnowledgeManage/app/services/chat_service.py` — remove `db` parameter, new signature takes 3 args. The function becomes an async generator that: (1) checks if `_generations[chat_id]` already has an active job → if so, reattach (see T015); (2) otherwise validates chat exists and has model, transitions status to `generating` using own `SessionLocal()` session, saves user message; (3) creates `_GenerationJob` with new Events/Queue; (4) starts `_run_generation` as `asyncio.create_task`; (5) stores job in `_generations[chat_id]`; (6) yields events from `job._live` queue until `job.done` or `job.cancel` is set; (7) on generator exit (client disconnect): sets `job.detached` and stops yielding but does NOT cancel the background task
- [x] T008 Update `cancel_chat()` in `KnowledgeManage/app/services/chat_service.py` — after publishing Redis cancel signal, also look up `_generations.get(chat_id)` and call `job.cancel.set()` if found, to provide fast in-process cancel signal
- [x] T009 Update `send_message` route in `KnowledgeManage/app/routers/chats.py` — change `send_message_stream(db, chat_id, body.content, current_user["id"])` to `send_message_stream(chat_id, body.content, current_user["id"])` (remove `db` arg, matching new 3-arg signature)

**Checkpoint**: Run `python -m pytest tests/test_chat_background.py -v` from KnowledgeManage directory. Target: all 10 tests pass. If tests fail, debug and fix before proceeding.

---

## Phase 3: User Story 1 - 主动取消生成 (Priority: P1) 🎯 MVP

**Goal**: User clicks cancel button during AI generation, full cascade disconnect (frontend → KnowledgeManage → LLM Gateway → model provider), partial content preserved.

**Independent Test**: Send a message, wait for streaming to start, call `POST /chats/{chat_id}/cancel`, verify: streaming stops, partial content saved with `[已取消]` suffix, chat status is `cancelled`.

### Backend Validation for User Story 1

- [x] T010 [US1] Verify cancel cascade test passes: `test_cancel_from_redis_interrupts_idle_upstream` in `KnowledgeManage/tests/test_chat_background.py` — Redis cancel signal → `job.cancel` set → upstream stream interrupted → partial content saved with `\n[已取消]`
- [x] T011 [US1] Verify connected cancel test passes: `test_connected_cancel_emits_cancelled_not_error` in `KnowledgeManage/tests/test_chat_background.py` — while SSE client still connected, cancel via Redis → client receives `cancelled` event (not error) → `[DONE]` marker sent
- [x] T012 [US1] Verify idempotent cancel test passes: `test_cancel_next_generation_does_not_inherit_previous_signal` in `KnowledgeManage/tests/test_chat_background.py` — cancel first generation, start new generation → new job's cancel event is fresh (not set)
- [x] T013 [US1] Verify cancel after browser close test passes: `test_cancel_after_browser_close_interrupts_idle_upstream` in `KnowledgeManage/tests/test_chat_background.py` — browser closes (detach) → then cancel API called → background task still interrupted, upstream connection closed

### Frontend API Layer for User Story 1

- [x] T014 [P] [US1] Add `cancelChat(chatId)` function in `frontend/src/services/chatApi.js` — calls `POST /chats/{chatId}/cancel` via the existing axios `api` instance, returns response data

### Frontend Store for User Story 1

- [x] T015 [US1] Add `cancelGeneration()` action and `isCancelling` ref to `frontend/src/stores/chat.js` — implementation: (1) set `isCancelling = true`, (2) call `chatApi.cancelChat(currentChatId)`, (3) abort the current SSE stream via stored `AbortController`, (4) set `streaming = false`, (5) set `isCancelling = false`. Also modify `sendMessage()` to: create an `AbortController`, store it in module scope, pass `controller.signal` to `chatApi.sendMessage()`

### Frontend UI for User Story 1

- [x] T016 [P] [US1] Add cancel button to `frontend/src/components/chat/MessageInput.vue` — when `isStreaming` is true, replace the send button with a danger-colored "取消" button (using `StopOutlined` icon from `@ant-design/icons-vue`), emit `cancel` event on click. Disable button while `isCancelling` is true. Add `isCancelling` to props.
- [x] T017 [US1] Wire cancel flow in `frontend/src/views/ChatManagement.vue` — import `cancelGeneration` from chatStore, handle `@cancel` event from `ChatArea`/`MessageInput`, call `chatStore.cancelGeneration()`. Pass `isCancelling` state down to `ChatArea` and `MessageInput`.

**Checkpoint**: User Story 1 fully functional — cancel button works, cascade disconnect verified, partial content preserved.

---

## Phase 4: User Story 2 - 页面离开后数据保持与恢复 (Priority: P2)

**Goal**: When user leaves page during generation, backend continues fetching from LLM Gateway. When user returns, cached content is returned and streaming resumes if still active.

**Independent Test**: Start generation, close browser tab, wait for completion, reopen session → full content preserved, status is `completed`.

### Backend Detach Behavior for User Story 2

- [x] T018 [US2] Verify browser close continues generation test passes: `test_browser_close_continues_and_persists_full_response` in `KnowledgeManage/tests/test_chat_background.py` — stream closed by client → `job.detached` set → background task continues → full content saved → status transitions to `completed` → job removed from `_generations`
- [x] T019 [US2] Verify HTTP disconnect does not cancel test passes: `test_http_disconnect_does_not_cancel_generation` in `KnowledgeManage/tests/test_chat_background.py` — ASGI `http.disconnect` event → `job.detached` set → task continues → content saved as `completed`
- [x] T020 [US2] Verify SSE cancel does not cancel generation test passes: `test_cancelling_sse_while_waiting_does_not_cancel_generation` in `KnowledgeManage/tests/test_chat_background.py` — cancelling the SSE observer (reader) → `job.detached` set but `job.cancel` NOT set → background task continues to completion

### Backend Reattach/Replay for User Story 2

- [x] T021 [US2] Implement reattach logic in `send_message_stream` in `KnowledgeManage/app/services/chat_service.py` — when called with a `chat_id` that has an active job in `_generations`: (1) do NOT create a new job or send a new user message, (2) drain existing events from `job._live` queue and yield them, (3) continue reading from `job._live` for new events until `job.done` or `job.cancel`
- [x] T022 [US2] Verify reattach test passes: `test_duplicate_send_reattaches_to_active_job` in `KnowledgeManage/tests/test_chat_background.py` — first stream disconnected → second call to `send_message_stream` reattaches to same job → receives delta events → `[DONE]` marker → same job remains in `_generations` → only one `save_message` call

### Backend Graceful Shutdown for User Story 2

- [x] T023 [US2] Implement `finish_generations()` async function in `KnowledgeManage/app/services/chat_service.py` — for each active job in `_generations`: (1) set `job.cancel`, (2) `await job.task` with timeout (e.g., 5 seconds). This ensures all in-flight content is persisted before shutdown.
- [x] T024 [US2] Update lifespan in `KnowledgeManage/app/main.py` — in the shutdown phase (after `yield`), import and call `await chat_service.finish_generations()` before closing Redis pool

### Frontend Reconnection for User Story 2

- [x] T025 [US2] Add `resumeStream(chatId)` action in `frontend/src/stores/chat.js` — called when entering a chat that has `status === 'generating'`: (1) fetch messages via `fetchMessages(chatId)` to load persisted history, (2) create a streaming assistant message placeholder, (3) call `chatApi.sendMessage(chatId, '', onChunk, onDone, onError, signal)` with empty content to reattach to the active backend generation job, (4) stream remaining content
- [x] T026 [US2] Integrate `resumeStream` in `frontend/src/views/ChatManagement.vue` — when a chat is selected (`selectChat`), after loading messages, check if `currentChat.status === 'generating'`, if so call `chatStore.resumeStream(chatId)`. Also check chat status from the `ChatResponse` returned by `selectChat`/`fetchChats`.

**Checkpoint**: User Story 2 fully functional — page leave preserves data, reconnect replays content and resumes streaming.

---

## Phase 5: User Story 3 - 取消按钮界面呈现与状态联动 (Priority: P3)

**Goal**: Button state correctly reflects session state — "发送" when idle/completed, "取消" when generating, transitions are smooth and unambiguous.

**Independent Test**: Send message → button changes to "取消" → generation ends → button reverts to "发送". Repeat with cancel → button reverts immediately.

### Frontend Button State Management for User Story 3

- [x] T027 [P] [US3] Add status display to `frontend/src/components/chat/ChatArea.vue` — show chat status indicator near the header when `currentChat.status` is `generating` (e.g., a small "生成中..." tag or loading spinner). Pass `isCancelling` prop through to `MessageInput`.
- [x] T028 [US3] Enhance `MessageInput.vue` button state logic in `frontend/src/components/chat/MessageInput.vue` — ensure: (1) idle/completed/cancelled → show "发送" button (disabled if no input or no model), (2) generating → show "取消" button (danger style, `StopOutlined` icon), (3) cancelling → "取消" button shown but disabled with loading state. Use `isStreaming` and `isCancelling` props to drive the state.
- [x] T029 [US3] Sync chat status from backend in `frontend/src/stores/chat.js` — after `sendMessage` completes (done or cancelled callback), update `currentChat.status` in the store to `completed` or `cancelled`. After `cancelGeneration()`, immediately set `currentChat.status = 'cancelled'`. Ensure `fetchChats` returns the latest status.

**Checkpoint**: All three user stories independently functional. UI button states are smooth and correct.

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Final validation and cleanup

- [x] T030 Run all backend tests: `python -m pytest tests/ -v` from `KnowledgeManage/` directory — all tests in `test_chat_background.py` (10 tests) and `test_chat_stream.py` must pass
- [ ] T031 [P] Run quickstart.md validation scenarios VS-001 through VS-005 manually (requires running services and a registered LLM model)
- [x] T032 [P] Remove the legacy `stream_llm_response` function from `KnowledgeManage/app/services/chat_service.py` if no longer referenced — it's the old non-cancel streaming function that has been superseded by the new `send_message_stream` (N/A: function does not exist)
- [x] T033 [P] Add structured logging for cancel and detach events in `KnowledgeManage/app/services/chat_service.py` — log `chat_stream_cancel`, `chat_stream_detach`, `chat_stream_reattach` with `stream_id` and `chat_id` for observability

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — review only
- **Foundational (Phase 2)**: Depends on Phase 1 understanding — BLOCKS all user stories
- **US1 (Phase 3)**: Depends on Phase 2 completion
- **US2 (Phase 4)**: Depends on Phase 2 completion, partially overlaps with US1 (reattach depends on base architecture)
- **US3 (Phase 5)**: Depends on US1 frontend (cancel button exists) + US2 frontend (resume integration)
- **Polish (Phase 6)**: Depends on all user stories complete

### User Story Dependencies

```
Phase 2 (Foundational) ──┬──▶ Phase 3 (US1: Cancel)
                          └──▶ Phase 4 (US2: Page Leave/Reconnect)
                                         │
Phase 3 + Phase 4 ──────────────────▶ Phase 5 (US3: UI State)
```

- **US1** and **US2** backend tasks can proceed in parallel after Phase 2
- **US3** requires both US1 and US2 frontend to be complete
- **US2** frontend (resumeStream) can be developed in parallel with US1 frontend

### Within Each Phase

- **Phase 2**: T004 → T005 → T006 → T007 → T008 → T009 (sequential, same file)
- **Phase 3**: Backend tests (T010-T013) run as checkpoints; Frontend API (T014) and UI (T016) can be parallel [P]; Store (T015) depends on T014; Wire (T017) depends on T015+T016
- **Phase 4**: Backend tests (T018-T020) as checkpoints; Reattach (T021) + graceful shutdown (T023) are sequential; Frontend (T025-T026) can be parallel with backend
- **Phase 5**: T027 [P] can start early; T028 depends on T016 from US1; T029 depends on T015+T025

### Parallel Opportunities

- T014 [P] [US1] (chatApi.js) and T016 [P] [US1] (MessageInput.vue) — different files
- T027 [P] [US3] (ChatArea.vue status indicator) — independent of other US3 tasks
- T031 [P], T032 [P], T033 [P] (Polish) — all independent of each other

---

## Parallel Example: Phase 3 (User Story 1)

```text
# After backend checkpoints pass:

# Launch API and UI tasks together:
Task T014: "Add cancelChat(chatId) function in frontend/src/services/chatApi.js"
Task T016: "Add cancel button to frontend/src/components/chat/MessageInput.vue"

# Then sequential:
Task T015: "Add cancelGeneration() to frontend/src/stores/chat.js" (depends on T014)
Task T017: "Wire cancel flow in frontend/src/views/ChatManagement.vue" (depends on T015 + T016)
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (review existing code)
2. Complete Phase 2: Foundational (CRITICAL — backend refactoring)
3. Complete Phase 3: User Story 1 (Cancel generation)
4. **STOP and VALIDATE**: Cancel button works, cascade disconnect verified
5. Deploy/demo if ready — this alone is valuable

### Incremental Delivery

1. Setup + Foundational → Backend infrastructure ready
2. Add US1 (Cancel) → Test independently → Demo (MVP!)
3. Add US2 (Page Leave/Reconnect) → Test independently → Demo (robustness!)
4. Add US3 (UI Polish) → Test independently → Complete feature
5. Each story adds value without breaking previous stories

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- All `test_chat_background.py` tests (T010-T013, T018-T022) are ALREADY WRITTEN — they define the target API contract. Implementation must make them pass.
- `test_chat_stream.py` tests must continue to pass (backward compatibility)
- LlmGateway requires ZERO changes — existing `StreamingResponse` + `aclosing()` handles client disconnect
- Commit after each task or logical group
- The `_run_generation` function (T006) is the most complex task — it combines the existing stream reading logic from `send_message_stream` with the new observer queue pattern
