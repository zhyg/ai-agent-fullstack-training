# Tasks: 模型管理优化

**Input**: Design documents from `/specs/002-model-category-optimization/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/model-api.md, quickstart.md

**Tests**: 规格中未明确要求测试任务，故不包含独立测试任务。

**Organization**: 任务按用户故事分组，支持独立实现和测试。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行执行（不同文件，无依赖）
- **[Story]**: 所属用户故事（US1, US2, US3）
- 描述中包含精确文件路径

## Path Conventions

- **后端**: `LlmGateway/app/` (Python/FastAPI)
- **前端**: `frontend/src/` (Vue 3 + Ant Design Vue 4.x)
- **参考实现**: `MyKnowlegeWebDemo/src/` (Demo 参考代码)

---

## Phase 1: Setup（共享基础设施）

**Purpose**: 前端工具模块初始化，为后续所有用户故事提供共享的分类常量和辅助函数。

- [x] T001 创建前端模型工具模块 `frontend/src/utils/model.js`，定义 `MODEL_CATEGORIES` 常量数组（含 value/label/formLabel：`{value:'chat',label:'对话',formLabel:'对话模型'}`、`{value:'embedding',label:'Embedding',formLabel:'Embedding 模型'}`、`{value:'rerank',label:'ReRank',formLabel:'ReRank 模型'}`、`{value:'vision',label:'视觉',formLabel:'视觉模型'}`、`{value:'speech',label:'语音',formLabel:'语音模型'}`）；导出 `getModelCategory(model)` 函数（`return model.category ?? 'chat'`，兼容旧模型无分类字段）；导出 `formatContextWindow(value)` 函数（≥1M 显示 `xM`、≥1K 显示 `xK`、否则原值）。参照 `MyKnowlegeWebDemo/src/utils/model.js`

---

## Phase 2: Foundational（阻塞性前置任务）

**Purpose**: 数据库迁移和后端核心实体变更——所有用户故事都依赖此阶段完成。

**⚠️ CRITICAL**: 在此阶段完成前，不可开始任何用户故事的后端工作。

- [x] T002 创建 Alembic 迁移脚本 `LlmGateway/alembic/versions/<auto>_add_category_provider_display_context.py`：① `op.add_column('models', sa.Column('category', sa.String(20), nullable=False, server_default='chat'), schema='llm_gateway')`；② `op.add_column('models', sa.Column('provider', sa.String(100), nullable=False, server_default='OpenAI'), schema='llm_gateway')`；③ `op.add_column('models', sa.Column('display_name', sa.String(200), nullable=True), schema='llm_gateway')`；④ `op.alter_column('models', 'max_tokens', new_column_name='context_tokens', schema='llm_gateway')`；⑤ `op.create_unique_constraint('uq_models_provider_name', 'models', ['provider', 'name'], schema='llm_gateway')`；⑥ 移除 server_default；⑦ downgrade 函数执行逆操作。使用 `alembic revision --autogenerate -m "add_category_provider_display_context"` 生成
- [x] T003 更新 Model ORM 实体 `LlmGateway/app/models/model.py`：① 新增 `category = Column(String(20), nullable=False, default='chat', comment="模型分类")`；② 新增 `provider = Column(String(100), nullable=False, comment="模型供应商")`；③ 新增 `display_name = Column(String(200), nullable=True, comment="模型显示名称")`；④ 将 `max_tokens` 字段重命名为 `context_tokens = Column(Integer, nullable=False, comment="上下文窗口大小")`；⑤ 在 `__table_args__` 中添加 `UniqueConstraint('provider', 'name', name='uq_models_provider_name')`
- [x] T004 更新 Pydantic Schema `LlmGateway/app/schemas/model.py`：① `ModelCreate` 新增字段 `category: Literal['chat','embedding','rerank','vision','speech']`（必填）、`provider: str = Field(..., min_length=1, max_length=100)`（必填）、`display_name: Optional[str] = Field(None, max_length=200)`（可选）；② 将 `max_tokens` 字段重命名为 `context_tokens: int = Field(..., ge=1)`；③ `ModelUpdate` 同步新增上述三个字段（均必填，display_name 可选）并重命名 `max_tokens`→`context_tokens`；④ `ModelResponse` 新增 `display_name: Optional[str]`、`category: str`、`provider: str` 字段，将 `max_tokens` 重命名为 `context_tokens`

**Checkpoint**: 迁移和 Schema 就绪，可开始用户故事实现。

---

## Phase 3: User Story 1 - 模型分类创建 (Priority: P1) 🎯 MVP

**Goal**: 管理员创建/编辑模型时可选择分类、填写供应商和显示名称，后端 API 支持新字段并校验唯一性。

**Independent Test**: 新建一个模型，验证分类（chat）、供应商（OpenAI）、显示名称（GPT-4o）、context_tokens（128000）被正确保存和返回。

### Implementation for User Story 1

- [x] T005 [US1] 重构 `LlmGateway/app/services/model_service.py` 的 `create_model` 函数：① 接收并存储 `category`、`provider`、`display_name` 字段；② 使用 `context_tokens` 替代 `max_tokens`；③ 在 `db.add()` 之前新增唯一性预检查：查询 `db.query(Model).filter(Model.provider == data.provider, Model.name == data.name).first()`，若存在则 raise `ValueError("该供应商下已存在同名模型")`
- [x] T006 [US1] 重构 `LlmGateway/app/services/model_service.py` 的 `update_model` 函数：① 同步更新 `category`、`provider`、`display_name`、`context_tokens` 字段；② 唯一性预检查须排除当前模型自身：`db.query(Model).filter(Model.provider == data.provider, Model.name == data.name, Model.id != model_id).first()`
- [x] T007 [US1] 重构 `LlmGateway/app/services/model_service.py` 的 `_model_to_response` 函数：① 返回 dict 新增 `category`、`provider`、`display_name` 键；② 将 `max_tokens` 键替换为 `context_tokens`
- [x] T008 [US1] 更新 `LlmGateway/app/routers/models.py` 的 `create_model` 端点：捕获 service 层抛出的 `ValueError` 并返回 `HTTPException(status_code=409, detail="该供应商下已存在同名模型")`
- [x] T009 [US1] 更新 `LlmGateway/app/routers/models.py` 的 `update_model` 端点：同样捕获 `ValueError` 并返回 409
- [x] T010 [P] [US1] 重构前端模型表单抽屉 `frontend/src/components/model/ModelFormDrawer.vue`：① 表单新增"模型分类"字段（`<a-select>` 绑定 `formState.category`，选项从 `MODEL_CATEGORIES` 导入，使用 `formLabel` 作为显示文本）；② 新增"模型供应商"字段（`<a-select>` 绑定 `formState.provider`，预设选项 `[{value:'OpenAI',label:'OpenAI'},{value:'Anthropic',label:'Anthropic'}]`，启用 `showSearch` 支持自定义输入）；③ 新增"模型显示名称"字段（`<a-input>` 绑定 `formState.display_name`，placeholder "请输入模型显示名称"）；④ 将"上下文窗口"表单项的 `name` 和绑定从 `max_tokens` 改为 `context_tokens`；⑤ `formState` 初始值新增 `category:'chat'`、`provider:'OpenAI'`、`display_name:''`，重命名 `max_tokens`→`context_tokens`；⑥ `rules` 新增 `category:[{required:true,message:'请选择模型分类'}]`、`provider:[{required:true,message:'请选择模型供应商'}]`，`display_name` 不设 required；⑦ watch 编辑回填时读取 `model.category`、`model.provider`、`model.display_name`、`model.context_tokens`；⑧ 参照 `MyKnowlegeWebDemo/src/components/model/ModelFormDrawer.vue` 的布局和字段顺序
- [x] T011 [P] [US1] 更新 `frontend/src/services/modelApi.js`：`createModel` 和 `updateModel` 请求体字段从 `max_tokens` 改为 `context_tokens`（前端发送的 data 对象已包含新字段，无需额外修改 API 调用方式）
- [x] T012 [US1] 更新 `frontend/src/stores/model.js`：`createModel` 和 `updateModel` 的 `modelData` 参数自然传递新字段（category/provider/display_name/context_tokens），无需修改 store 逻辑

**Checkpoint**: 管理员可以创建带分类、供应商、显示名称的模型；API 校验 name 在供应商内唯一。

---

## Phase 4: User Story 2 - 分类展示与筛选 (Priority: P2)

**Goal**: 模型列表页面按分类标签页分组展示模型，默认激活"对话模型"标签，每个标签显示模型计数，分类内按创建时间倒序排列。

**Independent Test**: 在模型列表中切换到不同分类标签，验证每个标签下仅展示对应类型的模型，且默认激活"对话模型"。

### Implementation for User Story 2

- [x] T013 [US2] 重构前端模型列表组件 `frontend/src/components/model/ModelList.vue`：① 将平铺列表改为 `<a-tabs>` 分类标签页布局（参照 `MyKnowlegeWebDemo/src/components/model/ModelList.vue`）；② `activeCategory` 默认值为 `'chat'`（非 `'all'`）；③ 每个 `<a-tab-pane>` 显示分类标签和计数，格式 `${category.label}(${filteredCount})`；④ `filteredModels` 计算属性：当 `activeCategory` 为具体分类时筛选 `getModelCategory(model) === activeCategory`，按 `created_at` 倒序排列；⑤ 空分类展示 `<a-empty description="暂无该分类模型" />`；⑥ "新建模型"按钮点击时 emit `create` 事件并传递当前 `activeCategory`
- [x] T014 [P] [US2] 更新前端模型卡片组件 `frontend/src/components/model/ModelCard.vue`：① 标题显示 `model.display_name || model.name`；② 新增供应商信息展示（`model.provider`）；③ 根据模型分类显示不同图标（chat→CommentOutlined, embedding→DatabaseOutlined, rerank→SortAscendingOutlined, vision→PictureOutlined, speech→AudioOutlined），导入 `getModelCategory` 从 `../../utils/model.js`；④ 将 `max_tokens` 标签替换为 `context_tokens`（使用 `formatContextWindow` 格式化）；⑤ 参照 `MyKnowlegeWebDemo/src/components/model/ModelCard.vue` 的卡片布局（2列网格 `.model-grid`、分类图标区 `.card-icon`、标题区 `.card-title-area`）
- [x] T015 [US2] 更新 `frontend/src/views/ModelManagement.vue`：① `openCreateDrawer` 函数接收 `category` 参数并传递给 `ModelFormDrawer`（新增 `:category` prop）；② `ModelFormDrawer` 组件新增 `:category="creatingCategory"` 绑定
- [x] T016 [US2] 更新 `frontend/src/stores/model.js`：`fetchModels` 调用时传入较大 `pageSize`（如 1000）以一次性加载全部模型用于前端分类筛选；或新增 `fetchAllModels` 方法调用 `modelApi.listModels(1, 1000)`

**Checkpoint**: 模型列表按分类标签页展示，默认"对话模型"，切换即时响应，卡片显示分类/供应商/显示名称。

---

## Phase 5: User Story 3 - 会话中选择分类模型 (Priority: P3)

**Goal**: 会话页面的模型选择器按分类分组展示模型，方便用户根据用途快速选择。

**Independent Test**: 在会话页面的模型选择器中查看分组展示，选择不同分类的模型后正常发送消息。

### Implementation for User Story 3

- [x] T017 [US3] 重构 `frontend/src/components/chat/MessageInput.vue` 的模型选择器：① 将 `<a-select-option v-for="model in models">` 改为 `<a-select-opt-group>` 分组结构；② 导入 `MODEL_CATEGORIES` 和 `getModelCategory` 从 `../../utils/model.js`；③ 按 `MODEL_CATEGORIES` 顺序生成分组，每组内列出该分类的模型（`models.filter(m => getModelCategory(m) === cat.value)`）；④ 每个分组标签显示 `category.formLabel`（如"对话模型"）；⑤ 每个模型选项显示 `model.display_name || model.name`
- [x] T018 [US3] 更新 `frontend/src/components/chat/ChatArea.vue` 的 `getModelName` 函数：优先返回 `model.display_name || model.name`（而非仅 `model.name`）

**Checkpoint**: 会话模型选择器按分类分组展示，选择模型后正常发送 SSE 消息。

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: 跨故事的收尾工作和质量验证。

- [x] T019 运行 `cd LlmGateway && alembic upgrade head` 验证迁移执行成功且旧数据正确归入默认分类
- [x] T020 按照 `specs/002-model-category-optimization/quickstart.md` 的 Step 3（后端 API 验证）和 Step 4（前端 UI 验证）执行端到端验证
- [x] T021 检查 `frontend/src/components/chat/MessageInput.vue` 中 `model.name` 引用是否已统一为 `model.display_name || model.name`，确保全局展示一致性
- [x] T022 检查 `LlmGateway/app/services/model_service.py` 的 `list_models` 函数排序：确认使用 `Model.created_at.desc()` 排序（而非 `Model.updated_at.desc()`），与 FR-005 的"按创建时间倒序"一致

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即开始
- **Foundational (Phase 2)**: 依赖 Phase 1 完成 → **阻塞所有用户故事**
- **US1 (Phase 3)**: 依赖 Phase 2
- **US2 (Phase 4)**: 依赖 Phase 2 + Phase 3（US2 的 ModelList 需要 US1 的 store/API 变更）
- **US3 (Phase 5)**: 依赖 Phase 2（仅需新字段存在于 API 响应中）
- **Polish (Phase 6)**: 依赖所有用户故事完成

### User Story Dependencies

- **US1 (P1)**: Phase 2 完成后可开始，无故事间依赖
- **US2 (P2)**: Phase 2 + Phase 3 完成后开始（依赖 US1 的 store 全量加载和 API 字段变更）
- **US3 (P3)**: Phase 2 完成后可开始，与 US1/US2 独立（仅需 API 返回新字段）

### Within Each User Story

- 后端 service/router 变更 → 前端组件更新
- 前端工具模块（Phase 1）→ 所有前端组件任务

### Parallel Opportunities

- T010 和 T011 可并行（不同文件）
- T013 和 T014 可并行（不同组件文件）
- Phase 3 的后端任务（T005-T009）须顺序执行，但 T010/T011（前端）可与后端并行

---

## Parallel Example: User Story 1

```text
# 后端任务顺序执行（同文件依赖）：
Task T005: 重构 model_service.py create_model
Task T006: 重构 model_service.py update_model
Task T007: 重构 model_service.py _model_to_response
Task T008: 更新 routers/models.py create_model
Task T009: 更新 routers/models.py update_model

# 前端任务可并行启动（不同文件）：
Task T010 [P]: 重构 ModelFormDrawer.vue
Task T011 [P]: 更新 modelApi.js
```

## Parallel Example: User Story 2

```text
# 前端组件可并行（不同文件）：
Task T013: 重构 ModelList.vue
Task T014 [P]: 更新 ModelCard.vue

# 然后顺序执行：
Task T015: 更新 ModelManagement.vue（依赖 T013 的 emit 接口）
Task T016: 更新 stores/model.js
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup → `frontend/src/utils/model.js`
2. Complete Phase 2: Foundational → 数据库迁移 + ORM + Schema
3. Complete Phase 3: US1 → 后端 API + 前端表单
4. **STOP and VALIDATE**: 创建带分类/供应商/显示名称的模型，验证 API 和表单
5. Deploy/demo if ready

### Incremental Delivery

1. Setup + Foundational → 数据库和 Schema 就绪
2. US1 → 模型创建/编辑支持新字段 → 验证 → Deploy (MVP!)
3. US2 → 模型列表分类标签页 → 验证 → Deploy
4. US3 → 会话模型选择器分组 → 验证 → Deploy
5. Polish → 端到端验证

---

## Notes

- [P] 任务 = 不同文件，无依赖，可并行
- [Story] 标签映射到 spec.md 中的用户故事
- 迁移使用 `server_default` 策略确保旧数据自动填充默认值
- 前端分类筛选在内存中完成，满足 SC-002 的 1 秒响应要求
- 所有 `max_tokens` → `context_tokens` 重命名须在 Phase 2 的迁移和 Schema 中统一完成
