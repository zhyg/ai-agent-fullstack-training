# Research: 文档解析与分片

## R1: Elasticsearch Python 客户端选择

**Decision**: 使用 `elasticsearch[async]` 官方 Python 客户端（v8.x），支持异步操作。

**Rationale**:
- 官方客户端提供完整的 ES 8.x 功能支持（向量搜索、dense_vector mapping）
- 异步支持（`AsyncElasticsearch`）适配 FastAPI 异步架构
- 内置连接池管理和重试机制

**Alternatives considered**:
- `elasticsearch-dsl`: 上层抽象，但与 ES 8.x 兼容性存在风险，额外学习成本
- 直接使用 HTTP 客户端: 过于底层，缺乏 bulk 操作和连接管理

**依赖**: 需在 `requirements.txt` 添加 `elasticsearch[async]>=8.0`

---

## R2: MinerU API 集成模式

**Decision**: 使用 `httpx.AsyncClient` 调用 MinerU HTTP API，同步解析模式（`POST /file_parse`）。

**Rationale**:
- 现有 `mineru3/test_parse.py` 已验证 `/file_parse` 同步接口可用
- `httpx` 已在项目依赖中（v0.28.1），支持异步调用
- 同步解析简化错误处理流程（一次请求一次响应）
- 需要显式传递 `formula_enable` 和 `table_enable` 参数

**Alternatives considered**:
- 异步轮询模式（`/tasks` + 轮询）: 适合超大文件，但增加复杂度，当前阶段不需要
- gRPC 客户端: MinerU 未暴露 gRPC 接口

**配置**: MinerU 服务地址添加到 `config.*.yaml` 的 `services` 段（如 `mineru: "http://localhost:8000"`）

---

## R3: 文档分块策略实现

**Decision**: 基于 LlamaIndex `MarkdownNodeParser` 实现按标题切分，自定义 `TextSplitter` 实现按固定长度切分。

**Rationale**:
- `myTest/myChunk/test_markdown_chunk.py` 已验证 `MarkdownNodeParser` 的可用性
- LlamaIndex 的 `MarkdownNodeParser` 提供 `header_path` 元数据，满足标题路径展示需求
- 固定长度切分使用 LlamaIndex 的 `SentenceSplitter`（支持自定义分隔符列表、chunk_size、chunk_overlap）

**Alternatives considered**:
- 纯自定义实现: 需要处理大量边界情况，开发成本高
- LangChain text splitters: 功能类似但引入额外依赖

**依赖**: 需在 `requirements.txt` 添加 `llama-index-core`

---

## R4: 表格预处理与 SQLite 动态建表

**Decision**: 使用 Python `sqlite3` 标准库创建临时 SQLite db，通过 LLM 生成英文表名，动态建表写入数据后上传到 MinIO。

**Rationale**:
- SQLite 文件是轻量级的结构化数据存储方案，适合存储在 MinIO 中按需下载查询
- `sqlite3` 是 Python 标准库，无需额外依赖
- 中文表名/列名转英文通过 LlmGateway 调用大模型完成，确保语义准确

**Alternatives considered**:
- 直接存储 CSV: 不支持多 sheet、不支持 SQL 查询
- 存储为 JSON: 查询性能差，不支持 SQL

**注意**:
- 表名转英文需调用大模型，存在翻译不准确的风险（已在 Assumptions 中记录）
- SQLite 文件在本地临时目录创建，上传到 MinIO 后清理本地文件

---

## R5: 文档处理流水线架构

**Decision**: 使用 FastAPI `BackgroundTasks` 实现异步处理流水线，Document 表 status 字段追踪处理阶段。

**Rationale**:
- 文档处理（解析→分片→向量化→AI问题生成）耗时较长，不适合阻塞请求
- `BackgroundTasks` 是 FastAPI 内置机制，无需引入 Celery/RQ 等重型依赖
- Document status 字段（pending→parsing→chunking→embedding→ai_generating→completed/failed）支持前端轮询展示进度
- 已有 Redis 连接池可用于状态广播（如果需要实时推送）

**Alternatives considered**:
- Celery + Redis: 适合大规模分布式处理，但引入额外运维复杂度，当前规模不需要
- asyncio.create_task: 更轻量但缺乏任务持久化和重试机制

**失败处理**:
- 任一阶段失败 → 标记 status="failed"，清理已生成的 ES chunks 和 MinIO 文件
- 外部服务（MinerU/图片识别模型/大模型）不可用 → 整体失败，不进入后续阶段

---

## R6: Embedding 向量生成

**Decision**: 通过 LlmGateway 服务调用知识库配置的 Embedding 模型生成向量。

**Rationale**:
- 项目已有 LlmGateway 服务（`http://localhost:8003`），支持 Embedding 接口
- 每个知识库配置独立的 `embedding_model_id`，通过 LlmGateway 路由到对应模型
- Embedding 接口为同步非流式调用（已有记忆确认）

**Alternatives considered**:
- 直接调用 Embedding API: 绕过 LlmGateway 会破坏统一网关架构
- 本地 Embedding 推理: 增加 KnowledgeManage 服务的资源消耗

---

## R7: 图片 OCR 与 Caption 处理

**Decision**:
- OCR: 通过 MinerU API 的 `/file_parse` 接口处理图片文件
- Caption: 通过 LlmGateway 调用知识库配置的 `image_model_id`（视觉模型）

**Rationale**:
- MinerU 已支持图片解析（png/jpg/jpeg/bmp/webp/tiff），返回 OCR 结果
- 视觉模型通过 LlmGateway 统一调用，支持多模态模型（已有架构）
- 两种处理独立执行，任一失败则整体文档处理失败

**注意**: MinerU 图片解析需显式传递 `formula_enable=true` 和 `table_enable=true` 参数

---

## R8: AI 问题生成 Prompt 设计

**Decision**: 使用结构化 prompt 模板，通过 LlmGateway 调用知识库的 `llm_model_id`，输出 JSON 格式的问题列表。

**Rationale**:
- 需要为 text、image_ocr、table_row 三种 chunk 类型生成问题
- JSON 输出格式便于解析和存储
- 使用知识库配置的 LLM 模型，通过 LlmGateway 调用

**Prompt 模板要点**:
- 输入: chunk 的 content 文本
- 输出: N 个问题（N 为用户设置的数量，范围 1-10，默认 3）
- 问题应覆盖 chunk 的关键信息点，适合用于检索增强

---

## R9: 前端分片展示组件

**Decision**: 扩展现有 `DocumentDetailDrawer.vue` 组件，新增"文档分片"tab 页和"分块设置"/"AI问题生成"tab 页。

**Rationale**:
- 现有前端已有文档详情抽屉（`DocumentDetailDrawer.vue`），可在此基础上扩展
- 分片展示需要渲染 markdown 图片语法（`![](url)`）为图片
- 使用 `md-editor-v3`（已安装）渲染 markdown 内容
- 子 chunk（image_ocr/image_caption/ai_question）通过 `parent_chunk_id` 查询关联展示

**前端新增依赖**: 无额外依赖（现有组件库满足需求）
