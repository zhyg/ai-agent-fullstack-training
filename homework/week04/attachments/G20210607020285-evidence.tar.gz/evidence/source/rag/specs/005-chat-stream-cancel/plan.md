# Implementation Plan: 聊天流式生成取消与断线恢复

**Branch**: `005-chat-stream-cancel` | **Date**: 2026-10-30 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/005-chat-stream-cancel/spec.md`

## Summary

在现有聊天系统基础上实现三个核心能力：(1) 主动取消生成——前端取消按钮触发级联断开全链路 SSE 连接；(2) 页面离开后数据保持——后端脱离前端连接继续获取 LLM 数据并持久化；(3) 断线恢复——用户重新进入时回放已缓存内容并续传。核心技术方案是将 KnowledgeManage 的 `send_message_stream` 重构为"后台任务 + 观察者队列"模式，LLM Gateway 无需修改。

## Technical Context

**Language/Version**: Python 3.11 (后端), JavaScript ES2022 (前端)

**Primary Dependencies**: FastAPI 0.115, SQLAlchemy 2.0, httpx 0.28, redis 5.2 (后端) / Vue 3, Ant Design Vue 4.x (前端)

**Storage**: PostgreSQL (共享开发数据库，Schema 隔离)

**Testing**: pytest (后端单元测试), IsolatedAsyncioTestCase (异步测试)

**Target Platform**: Linux server (后端) / 现代浏览器 (前端)

**Project Type**: Web Service (微服务架构: UserManage + KnowledgeManage + LlmGateway + 前端)

**Performance Goals**: 取消响应 < 1s，全链路断开 < 3s，0 数据丢失

**Constraints**: SSE/HTTP Streaming 协议，单实例 KnowledgeManage（内存队列足够），Redis Pub/Sub 跨 Worker 取消

**Scale/Scope**: 单用户单会话单消息同时生成，无并发写入冲突

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution 文件尚未填写（仍为模板占位符），无约束可检查。跳过此 gate。

## Project Structure

### Documentation (this feature)

```text
specs/005-chat-stream-cancel/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/
│   └── api-contracts.md # Phase 1 output
└── tasks.md             # Phase 2 output (by /speckit-tasks)
```

### Source Code (repository root)

```text
# 修改涉及的服务
KnowledgeManage/
├── app/
│   ├── services/
│   │   └── chat_service.py      # 核心重构：后台生成 + 观察者队列
│   ├── routers/
│   │   └── chats.py             # 微调：send_message 路由适配新签名
│   └── main.py                  # 添加：lifespan 中调用 finish_generations
└── tests/
    ├── test_chat_background.py  # 已有：10 个后台生成测试
    └── test_chat_stream.py      # 已有：流式响应测试

frontend/
├── src/
│   ├── stores/
│   │   └── chat.js              # 修改：新增 cancelGeneration/resumeStream
│   ├── services/
│   │   └── chatApi.js           # 修改：sendMessage 支持 AbortSignal
│   ├── components/chat/
│   │   ├── MessageInput.vue     # 修改：取消按钮 UI
│   │   └── ChatArea.vue         # 微调：传递取消事件
│   └── views/
│       └── ChatManagement.vue   # 修改：集成取消流程

# 无需修改的服务
LlmGateway/                      # 现有机制已满足需求
UserManage/                      # 不涉及
```

**Structure Decision**: 修改集中在 KnowledgeManage 后端服务和前端 Vue 应用，LlmGateway 和 UserManage 无需修改。

## Complexity Tracking

无 Constitution 违规，此节留空。
