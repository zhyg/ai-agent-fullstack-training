# Quickstart: 知识库评测验证指南（014-knowledge-evaluation）

**Plan**: [plan.md](./plan.md) | **契约**: [contracts/evaluation-api.md](./contracts/evaluation-api.md) | **数据模型**: [data-model.md](./data-model.md)

本文档为端到端验证/运行指南，不含实现代码。实现任务见 tasks.md（/speckit-tasks 生成）。

## 1. 前置条件

- PostgreSQL / Redis / Elasticsearch 已启动（沿用项目既有环境）
- LlmGateway(8003) 已配置至少 1 个 category=chat 模型与 embedding/rerank 模型；UserManage(8001) 可登录
- 已有启用态智能体与至少 1 个含已解析文档的知识库
- 提示词管理中已配置本人召回率/准确度提示词（案例见仓库根 [quickstart.md](../../quickstart.md)「八、知识库评测提示词案例」，占位符约定必须一致）

## 2. 启动与迁移

```bash
# 后端（KnowledgeManage 目录）
alembic upgrade head          # 应用 4 张评测表迁移
uvicorn app.main:app --host 0.0.0.0 --port 8002

# 前端（frontend 目录）
npm run dev                   # 5173，代理已配置
```

预期：启动日志无错误；`\dt knowledge_manage.evaluation_*` 可见 4 表；侧栏"知识库"分组出现"知识库评测"菜单（与"智能体"同级）。

## 3. 自动化测试

```bash
# KnowledgeManage 目录（test 环境）
pytest tests/test_evaluation_settings.py tests/test_evaluation_test_sets.py \
       tests/test_evaluation_runs.py tests/test_evaluation_scoring.py \
       tests/test_evaluation_trace.py -v
pytest tests/ -q              # 全量回归
```

预期：新增用例全部通过；全量回归零新增失败（已知存量失败 `test_agents.py::test_three_presets_exist_with_correct_defaults` 依赖活库数据，与本特性无关）。

覆盖映射：
| 测试文件 | 规格覆盖 |
|----------|----------|
| test_evaluation_settings.py | US1-1/2/7、FR-002~004、锁定（FR-009） |
| test_evaluation_test_sets.py | US1-3/4/5/6、FR-005~009、边界 500 题/2MB/空数组 |
| test_evaluation_runs.py | US2 全部场景、FR-010~020（预检/并发/取消/重启/超时/锁定） |
| test_evaluation_scoring.py | FR-021~027、SC-005（核算公式/重试/空 key_points/JSON 落库/原始输出） |
| test_evaluation_trace.py | US4 全部场景、FR-035~038（归属/pending/expired/no_trace/503） |

## 4. 手工端到端场景

### 场景 A：首次评测闭环（US1+US2+US3，SC-001）
1. 登录 → 知识库评测 → 设置 tab：选择分析模型（仅见 chat 模型）、两个提示词（仅见本人，名称+版本）并保存
2. 上传 3 题合法测试集 → 列表可见；再传空数组/缺字段文件 → 拒绝并提示具体错误
3. 评测 tab：选 2 个知识库 + 1 智能体 + 该测试集 → 开始评测
4. **预期**：立即返回；进度条 SSE 实时推进（每题完成 2 秒内更新，SC-002）；跑完状态"已完成"
5. 列表展示开始时间/知识库/智能体/测试集名/平均召回率/平均准确度；点入详情逐题核对：问题、标准答案、上下文（文档名+内容+得分）、agent 答案、两项得分、两份分析 JSON
6. 人工复算：召回率=covered 数/总数、准确度=max(0,100−5×issues 数)，与展示一致（SC-005）

### 场景 B：执行控制（US2）
1. 20 题评测进行中再点"开始评测" → 置灰/409
2. 进行中尝试重新上传/删除选中测试集、保存设置 → 均被拒绝并提示锁定；任务结束后自动解锁
3. 第 5 题时点取消 → 当前题（含评分）完成后终止，状态"已取消"，前 5 题结果保留且照常展示平均分
4. 删除该已取消记录（二次确认）→ 记录与明细消失；对进行中任务直接删除 → 拒绝提示先取消

### 场景 C：失败与容错（US2，SC-003/006）
1. 测试集含一道模糊问题（如"它怎么样？"）→ 该题失败、failure_reason 为澄清原因、得分空，其余题照常
2. 预检：删除已选提示词后发起 → 400 一次性列出失效项，不创建任务
3. 评测进行中重启 KnowledgeManage → 1 分钟内任务状态"失败"（服务重启中断），已完成题目可查
4. 全题失败的测试集 → 任务仍"已完成"，平均分展示空

### 场景 D：trace（US4）
1. 已完成评测详情点某题 trace → 右侧宽幅抽屉（与会话页一致），时间线含 agent 链路 + `evaluation.recall`/`evaluation.accuracy` 子 span，后者带 prompt.name/version 属性
2. 用另一账号请求该 trace 接口 → 404
3. 将某题 created_at 手工改为 3 天前（模拟过期）→ 抽屉展示"轨迹已过期清理"，其余字段照常

### 场景 E：快照与隔离（SC-007/008）
1. 删除评测用过的测试集/知识库 → 历史列表与详情名称照常展示、内容完整
2. 重新上传覆盖测试集后查看历史评测 → 逐题问题/答案仍为旧快照
3. 另一账号登录 → 看不到本人设置/测试集/评测记录；直接调接口 → 404

## 5. 验证通过标准

- 上述场景 A–E 全部符合预期；SC-001~008 逐条对照 [spec.md](./spec.md) 成立
- 会话列表无评测产生的会话/消息（决策21）；ES 中评测 trace 根 span 为 `evaluation.item`
- 全量 pytest 零新增失败；`npm run build` 成功