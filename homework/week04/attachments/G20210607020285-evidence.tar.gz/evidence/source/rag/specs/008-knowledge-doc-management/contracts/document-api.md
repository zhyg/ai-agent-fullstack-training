# Document API Contract

**Base URL**: `/api/knowledge`  
**Auth**: Bearer JWT (所有接口均需要认证)  
**Feature**: 008-knowledge-doc-management

## Endpoints

### GET /folders/{folder_id}/documents

获取指定目录下的文档列表（分页）。

**Path Parameters**:
- `folder_id` (string, UUID) — 目录 ID

**Query Parameters**:
- `page` (int, default=1) — 页码
- `page_size` (int, default=20, max=100) — 每页数量

**Response** `200 OK`:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "report.docx",
      "description": "季度报告",
      "tags": ["重要", "Q4"],
      "file_size": 1048576,
      "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "extension": "docx",
      "status": "parsing",
      "folder_id": "uuid",
      "kb_id": "uuid",
      "created_at": "2026-11-16T10:00:00Z",
      "updated_at": "2026-11-16T10:00:00Z"
    }
  ],
  "total": 42,
  "page": 1,
  "page_size": 20
}
```

**Error Responses**:
- `404` — 目录不存在

---

### POST /folders/{folder_id}/documents/upload

上传文件到指定目录（multipart/form-data）。

**Path Parameters**:
- `folder_id` (string, UUID) — 目录 ID

**Request Body** (multipart/form-data):
- `file` (binary) — 上传的文件（必填）

**约束**:
- 单文件上限 500MB
- 一次只能上传一个文件
- 支持任意类型文件及 .zip .rar .7z .tar.gz 等 多种类型压缩包

**Response** `201 Created`:

普通文件:
```json
{
  "documents": [
    {
      "id": "uuid",
      "name": "report.docx",
      "status": "parsing",
      "file_size": 1048576
    }
  ],
  "message": "上传成功，正在解析..."
}
```

压缩包（解压后多个文档）:
```json
{
  "documents": [
    { "id": "uuid1", "name": "chapter1.docx", "status": "parsing", "file_size": 524288 },
    { "id": "uuid2", "name": "chapter2.pdf", "status": "parsing", "file_size": 1048576 }
  ],
  "message": "上传成功，正在解析..."
}
```

**Error Responses**:
- `404` — 目录不存在
- `413` — 文件大小超过 500MB 限制

---

### GET /documents/{document_id}

获取文档详情。

**Path Parameters**:
- `document_id` (string, UUID) — 文档 ID

**Response** `200 OK`: 完整的文档对象（同列表中的 item 结构）

**Error Responses**:
- `404` — 文档不存在

---

### PUT /documents/{document_id}

更新文档信息（描述、标签）。

**Path Parameters**:
- `document_id` (string, UUID) — 文档 ID

**Request Body**:
```json
{
  "description": "新的描述内容",
  "tags": ["标签1", "标签2"]
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| description | string \| null | 否 | max 1000 字符 | 文档描述 |
| tags | string[] | 否 | — | 完整标签列表（替换式更新） |

**Response** `200 OK`: 更新后的文档对象

**Error Responses**:
- `404` — 文档不存在

---

### PUT /documents/{document_id}/tags/add

为文档追加标签（增量操作）。

**Path Parameters**:
- `document_id` (string, UUID) — 文档 ID

**Request Body**:
```json
{
  "tags": ["新标签1", "新标签2"]
}
```

**Response** `200 OK`: 更新后的文档对象

**业务规则**:
- 自动去重（已有标签不重复添加）
- 自动去除标签首尾空白
- 过滤空字符串

---

### PUT /documents/{document_id}/tags/remove

从文档中移除指定标签。

**Path Parameters**:
- `document_id` (string, UUID) — 文档 ID

**Request Body**:
```json
{
  "tag": "要删除的标签"
}
```

**Response** `200 OK`: 更新后的文档对象

---

### DELETE /documents/{document_id}

删除单个文档（含 MinIO 对象清理）。

**Path Parameters**:
- `document_id` (string, UUID) — 文档 ID

**Response** `200 OK`:
```json
{
  "message": "文档已删除"
}
```

**Error Responses**:
- `404` — 文档不存在
- `409` — 文档正在解析中，禁止删除

---

### POST /documents/batch-delete

批量删除文档。

**Request Body**:
```json
{
  "document_ids": ["uuid1", "uuid2", "uuid3"]
}
```

**Response** `200 OK`:
```json
{
  "deleted": 2,
  "skipped": 1,
  "message": "已删除 2 篇；1 篇正在解析中已跳过"
}
```

**业务规则**:
- 解析中的文档自动跳过，不报错
- 返回实际删除数和跳过数

---

### GET /documents/{document_id}/file

获取文档原始文件的下载/预览 URL（MinIO presigned URL）。

**Path Parameters**:
- `document_id` (string, UUID) — 文档 ID

**Response** `200 OK`:
```json
{
  "url": "https://minio-host/myknowlege/kb-uuid/folder-uuid/doc-uuid/file.docx?signature=...",
  "expires_in": 3600
}
```

**Error Responses**:
- `404` — 文档不存在或文件已丢失
