# API Contract: 知识库管理

Base URL: `/api/knowledge`

所有接口均需 Bearer JWT Token 认证（`Authorization: Bearer <token>`）。

---

## GET /knowledge-bases

获取当前用户的知识库列表（分页）。

**Query Parameters**:

| 参数 | 类型 | 必填 | 默认 | 说明 |
|------|------|------|------|------|
| `page` | int | 否 | 1 | 页码 (≥1) |
| `page_size` | int | 否 | 20 | 每页条数 (1~100) |

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "我的知识库",
      "description": "描述文字",
      "user_id": "uuid",
      "llm_model_id": "uuid",
      "embedding_model_id": "uuid",
      "image_model_id": "uuid",
      "rerank_model_id": "uuid",
      "created_at": "2026-11-16T10:00:00",
      "updated_at": "2026-11-16T10:00:00"
    }
  ],
  "total": 5,
  "page": 1,
  "page_size": 20
}
```

---

## POST /knowledge-bases

创建知识库。

**Request Body**:
```json
{
  "name": "我的知识库",
  "description": "可选描述",
  "llm_model_id": "uuid",
  "embedding_model_id": "uuid",
  "image_model_id": "uuid",
  "rerank_model_id": "uuid"
}
```

**Response 201**: 返回 KnowledgeBaseResponse 对象

**Error 409**:
```json
{ "detail": "该名称已存在" }
```

---

## PUT /knowledge-bases/{kb_id}

更新知识库。

**Path Parameters**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `kb_id` | string | 知识库 ID |

**Request Body** (所有字段可选):
```json
{
  "name": "新名称",
  "description": "新描述",
  "llm_model_id": "uuid",
  "embedding_model_id": "uuid",
  "image_model_id": "uuid",
  "rerank_model_id": "uuid"
}
```

**Response 200**: 返回 KnowledgeBaseResponse 对象

**Error 404**:
```json
{ "detail": "知识库不存在或无权访问" }
```

**Error 409**:
```json
{ "detail": "该名称已存在" }
```

---

## DELETE /knowledge-bases/{kb_id}

删除知识库。

**Path Parameters**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `kb_id` | string | 知识库 ID |

**Response 200**:
```json
{ "message": "知识库删除成功" }
```

**Error 404**:
```json
{ "detail": "知识库不存在或无权访问" }
```

---

## 错误码汇总

| HTTP Status | 含义 |
|-------------|------|
| 200 | 成功 |
| 201 | 创建成功 |
| 400 | 请求参数校验失败 |
| 401 | 未认证 / Token 过期 |
| 404 | 知识库不存在或无权访问 |
| 409 | 名称冲突 |
