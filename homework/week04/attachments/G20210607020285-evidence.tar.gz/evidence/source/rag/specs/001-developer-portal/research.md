# Research: 开发者门户平台

**Feature**: 001-developer-portal | **Date**: 2026-10-27

## R-001: 后端框架选择

**Decision**: FastAPI

**Rationale**: FastAPI 原生支持异步、自动生成 OpenAPI 文档、Pydantic 数据校验，与 Python3 + RESTful API 的技术选型高度匹配。对于微服务架构，FastAPI 轻量、启动快、易于容器化部署。

**Alternatives considered**:
- Flask：成熟但缺少异步支持和自动文档生成，需额外插件
- Django：全栈框架过重，对于纯 API 微服务不必要

## R-002: 认证方案

**Decision**: JWT（JSON Web Token）认证

**Rationale**: 前后端分离架构下，JWT 是无状态认证的标准方案。Access Token 短期有效（如 30 分钟），Refresh Token 长期有效（如 7 天），支持跨微服务验证。UserManage 服务负责签发 Token，其他服务通过验证 Token 完成身份认证。

**Alternatives considered**:
- Session + Cookie：需要共享 Session 存储，增加微服务间耦合
- OAuth2：对于内部平台过于复杂，引入不必要的第三方依赖

## R-003: 密码安全存储

**Decision**: passlib + bcrypt 哈希

**Rationale**: 业界标准的密码哈希方案，bcrypt 内置盐值和工作因子，防彩虹表和暴力破解。passlib 提供统一的哈希接口，支持未来算法迁移。

**Alternatives considered**:
- 明文存储：严重安全隐患，不可接受
- MD5/SHA256：无盐值机制，易受彩虹表攻击

## R-004: 登录失败锁定策略实现

**Decision**: 数据库记录失败次数和锁定时间，应用层校验

**Rationale**: 在 User 表中增加 `login_fail_count` 和 `locked_until` 字段。连续 5 次失败后设置 `locked_until = now + 15min`，登录时检查是否已过期。简单可靠，无需引入 Redis 等额外依赖。

**Alternatives considered**:
- Redis 计数器：引入额外依赖，对于内部平台不必要
- IP 级别限流：内部平台用户可能共享 IP，误封风险高

## R-005: 前端状态管理

**Decision**: Pinia（Vue 3 官方推荐）

**Rationale**: Pinia 是 Vue 3 官方推荐的状态管理库，API 简洁、TypeScript 友好、支持 DevTools。相比 Vuex 4 更轻量，适合中等规模应用。每个功能模块对应一个 store。

**Alternatives considered**:
- Vuex 4：API 较复杂，Vue 官方已推荐迁移到 Pinia
- reactive stores（如 MyKnowledgeWebDemo）：无 DevTools 支持，不适合生产环境

## R-006: 微服务间认证传递

**Decision**: JWT Token 透传 + 各服务独立验证

**Rationale**: 前端请求携带 JWT Token，各微服务通过共享的 JWT Secret 独立验证 Token 有效性，无需服务间调用。KnowledgeManage 和 LlmGateway 通过 `dependencies.py` 中的 `get_current_user` 依赖注入获取当前用户信息。

**Alternatives considered**:
- API Gateway 统一认证：增加基础设施复杂度，内部平台不必要
- 服务间 gRPC 调用：RESTful 已满足需求，gRPC 增加不必要复杂度

## R-007: 数据库设计策略

**Decision**: 每个微服务独立数据库（Database-per-Service）

**Rationale**: 微服务最佳实践，各服务数据库物理隔离，避免数据耦合。UserManage 的 User/Role 表、KnowledgeManage 的 Prompt/Chat/Message 表、LlmGateway 的 Model 表分别存储在各自的数据库中。跨服务引用使用 ID（如 prompt.creator_id 引用 UserManage 的用户 ID）。

**Alternatives considered**:
- 共享数据库：违反微服务隔离原则，服务间数据耦合
- Schema 隔离：单数据库多 schema，运维复杂度增加

## R-008: API Key 安全存储

**Decision**: 数据库加密存储（Fernet 对称加密）

**Rationale**: LLM 模型的 API Key 是敏感信息，使用 cryptography 库的 Fernet 加密后存储到数据库。读取时解密使用，API 响应中不返回完整 Key（仅显示掩码如 `sk-****1234`）。

**Alternatives considered**:
- 明文存储：严重安全隐患
- 环境变量：不适合动态配置的模型 Key

## R-009: 前端 UI 组件库

**Decision**: Ant Design Vue 4.x

**Rationale**: 用户明确要求使用 ant-design-vue 4.x。MyKnowledgeWebDemo 已使用 4.2.6 版本，可直接复用组件模式和交互经验。主要使用组件：a-form/a-input（表单）、a-table（列表）、a-modal（确认/新建对话框）、a-drawer（编辑面板）、a-layout（布局）、a-menu（导航）。

**Alternatives considered**: 无（用户明确要求）

## R-010: 会话消息流式输出

**Decision**: SSE（Server-Sent Events）实现 LLM 对话流式输出

**Rationale**: LLM 对话通常需要流式返回（token by token），SSE 是 HTTP 协议原生支持的单向推送方案，比 WebSocket 更简单。FastAPI 支持 StreamingResponse，前端使用 EventSource API 或 fetch + ReadableStream。

**Alternatives considered**:
- WebSocket：双向通信，但对于 LLM 对话（单向流式输出）过于复杂
- 轮询：延迟高，资源浪费

## R-011: 接口参数校验规范（Pydantic Model）

**Decision**: 所有后端接口的入参和返回值统一使用 Pydantic Model 进行定义和校验

**Rationale**: Pydantic 是 FastAPI 的核心组件，通过 Model 定义可以实现：
- **必填/可选控制**：使用字段类型声明 + `Field()` 明确标记必填项和可选项
- **数据校验**：通过类型注解 + `constr()`、`conint()` 等约束类型自动校验
- **自动文档**：FastAPI 根据 Pydantic Model 自动生成 Swagger/OpenAPI 文档
- **分层清晰**：Request Schema（入参）、Response Schema（返回值）、DB Model（数据库）三层分离

**规范约定**：
- 每个路由模块对应一个 `schemas/` 文件，包含 `XxxCreate`、`XxxUpdate`、`XxxResponse`、`XxxList` 等 Model
- Request Schema 使用 `Field()` 标注 `description`、`min_length`、`max_length` 等约束
- Response Schema 使用 `model_config = ConfigDict(from_attributes=True)` 支持 ORM 对象转换
- 分页列表统一使用 `PaginatedResponse[T]` 泛型 Model
- 所有 ID 字段使用 `str` 类型（UUID 字符串）

**Pydantic Model 示例**（以提示词为例）：

```python
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime

class PromptCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="提示词名称（必填）")
    version: str = Field(..., min_length=1, max_length=20, description="版本号（必填）")
    description: str = Field("", description="描述")
    content: str = Field(..., min_length=1, description="提示词内容（必填）")

class PromptUpdate(BaseModel):
    description: Optional[str] = Field(None, description="描述")
    content: str = Field(..., min_length=1, description="提示词内容（必填）")

class PromptResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    version: str
    description: str
    content: str
    creator_id: str
    creator_name: Optional[str] = None  # 仅管理员视图
    created_at: datetime
    updated_at: datetime

# 分页泛型
from typing import TypeVar, Generic, List
T = TypeVar("T")
class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
```

**Alternatives considered**:
- Marshmallow：功能类似但不与 FastAPI 原生集成，需要额外适配
- 手动校验（if/else）：代码冗余，易遗漏边界情况，无自动文档生成

## R-012: 多环境配置管理（dev/test/prod）

**Decision**: 每个后端服务使用三份 YAML 配置文件（`config.dev.yaml`、`config.test.yaml`、`config.prod.yaml`），启动时通过 `APP_ENV` 环境变量指定当前环境

**开发环境数据库共享策略**:

开发环境为节省资源，三个后端服务共享同一个 PostgreSQL 数据库，通过 **PostgreSQL Schema** 进行逻辑隔离：

| 配置项 | 值 |
| ------ | --- |
| 地址 | 127.0.0.1:5432 |
| 数据库 | mydb |
| 用户名 | admin |
| 密码 | 123456 |
| Schema 分配 | user_manage / knowledge_manage / llm_gateway |

**Rationale**:
- 不同环境的数据库地址、用户名、密码、服务端口等配置不同，需要分环境管理
- 开发环境共享数据库 + Schema 隔离，节省资源同时保证各服务表互不干扰
- YAML 格式可读性好，适合人工编辑和版本控制
- 通过启动参数切换环境，无需修改代码，符合 12-Factor App 原则

**配置示例（UserManage 服务）**：

```yaml
# config.dev.yaml
server:
  host: "0.0.0.0"
  port: 8001

database:
  url: "postgresql://admin:[REDACTED]@127.0.0.1:5432/mydb"
  schema: "user_manage"   # 服务专属 Schema
  echo: true               # 开发环境打印 SQL

jwt:
  secret_key: "[REDACTED]"
  access_token_expire_minutes: 30
  refresh_token_expire_days: 7

encryption:
  fernet_key: "dev-fernet-key-base64"

services:
  user_manage: "http://localhost:8001"
  knowledge_manage: "http://localhost:8002"
  llm_gateway: "http://localhost:8003"

logging:
  level: "DEBUG"
```

```yaml
# config.test.yaml
server:
  host: "0.0.0.0"
  port: 8001

database:
  url: "postgresql://test_user:[REDACTED]@test-db:5432/user_manage_test"
  schema: "public"
  echo: false

jwt:
  secret_key: "[REDACTED]"
  access_token_expire_minutes: 30
  refresh_token_expire_days: 7

encryption:
  fernet_key: "test-fernet-key-base64"

services:
  user_manage: "http://test-user-manage:8001"
  knowledge_manage: "http://test-knowledge-manage:8002"
  llm_gateway: "http://test-llm-gateway:8003"

logging:
  level: "INFO"
```

```yaml
# config.prod.yaml
server:
  host: "0.0.0.0"
  port: 8001

database:
  url: "postgresql://prod_user:[REDACTED]@prod-db:5432/user_manage"
  schema: "public"
  echo: false

jwt:
  secret_key: "[REDACTED]"
  access_token_expire_minutes: 15
  refresh_token_expire_days: 7

encryption:
  fernet_key: "${FERNET_KEY}"

services:
  user_manage: "http://user-manage-svc:8001"
  knowledge_manage: "http://knowledge-manage-svc:8002"
  llm_gateway: "http://llm-gateway-svc:8003"

logging:
  level: "WARNING"
```

**开发环境 Schema 隔离实现**：

```python
# app/core/database.py
from sqlalchemy import create_engine, text
from app.core.config import settings

engine = create_engine(settings.database.url, echo=settings.database.echo)

# 启动时自动创建 Schema（如不存在）
def init_schema():
    schema = settings.database.schema
    if schema and schema != "public":
        with engine.connect() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))
            conn.commit()

# SQLAlchemy Model 中使用 schema
# app/models/user.py
class User(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": settings.database.schema}  # 自动绑定 Schema
    # ...
```

**启动方式**：

```bash
# 通过环境变量指定（默认 dev）
APP_ENV=dev uvicorn app.main:app
APP_ENV=prod uvicorn app.main:app
```

**配置加载逻辑**：

```python
# app/core/config.py
import yaml, os
from pydantic import BaseModel

class DatabaseConfig(BaseModel):
    url: str
    schema: str = "public"
    echo: bool = False

class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000

class Settings(BaseModel):
    server: ServerConfig
    database: DatabaseConfig
    jwt: dict
    encryption: dict
    services: dict
    logging: dict

def load_settings(env: str = None) -> Settings:
    env = env or os.getenv("APP_ENV", "dev")
    config_path = f"config.{env}.yaml"
    with open(config_path) as f:
        data = yaml.safe_load(f)
    return Settings(**data)

settings = load_settings()
```

**Alternatives considered**:
- 开发环境也用独立数据库：资源消耗大，本地开发需启动多个 PG 实例
- `.env` 文件 + python-dotenv：适合简单配置，但不支持嵌套结构，可读性差
- 环境变量直接注入：适合容器化部署，但本地开发不方便
- 单配置文件 + 环境分支：违反环境分离原则，代码中混杂环境逻辑

## R-013: 前端多环境配置（Vite .env 文件）

**Decision**: 前端使用 Vite 内置的多环境 `.env` 文件机制，通过 `VITE_` 前缀变量暴露后端服务地址给前端代码

**Rationale**:
- Vite 原生支持 `.env`、`.env.development`、`.env.production` 等环境文件，无需额外依赖
- 不同环境对应不同的后端微服务地址（UserManage、KnowledgeManage、LlmGateway）
- `VITE_` 前缀变量在构建时被静态替换，不暴露敏感信息到客户端
- 通过 `npm run dev`、`npm run build --mode test`、`npm run build` 自动加载对应环境配置

**配置文件结构**：

```
frontend/
├── .env                    # 所有环境共享的变量
├── .env.development        # 开发环境
├── .env.test               # 测试环境
└── .env.production         # 生产环境
```

```bash
# .env（共享变量）
VITE_APP_TITLE=开发者门户平台

# .env.development
VITE_USER_MANAGE_URL=http://localhost:8001/api/user
VITE_KNOWLEDGE_MANAGE_URL=http://localhost:8002/api/knowledge
VITE_LLM_GATEWAY_URL=http://localhost:8003/api/llm

# .env.test
VITE_USER_MANAGE_URL=http://test-server:8001/api/user
VITE_KNOWLEDGE_MANAGE_URL=http://test-server:8002/api/knowledge
VITE_LLM_GATEWAY_URL=http://test-server:8003/api/llm

# .env.production
VITE_USER_MANAGE_URL=https://api.example.com/user
VITE_KNOWLEDGE_MANAGE_URL=https://api.example.com/knowledge
VITE_LLM_GATEWAY_URL=https://api.example.com/llm
```

**使用方式**：

```javascript
// src/services/api.js
const USER_MANAGE_URL = import.meta.env.VITE_USER_MANAGE_URL
const KNOWLEDGE_MANAGE_URL = import.meta.env.VITE_KNOWLEDGE_MANAGE_URL
const LLM_GATEWAY_URL = import.meta.env.VITE_LLM_GATEWAY_URL
```

**启动命令**：

```bash
# 开发环境（默认加载 .env.development）
npm run dev

# 测试环境构建
npm run build --mode test

# 生产环境构建（默认加载 .env.production）
npm run build
```

**Alternatives considered**:
- 手动维护 config.js 文件：需自行实现环境切换逻辑，不如 Vite 内置机制简洁
- 构建时注入环境变量：需 CI/CD 配置支持，本地开发不便
- 运行时动态获取配置：增加复杂度，需额外的配置服务

## R-014: 更新操作必须携带 ID 定位记录

**Decision**: 所有更新（PUT）和删除（DELETE）操作必须通过 URL 路径参数携带资源 `id`，确保精确匹配到具体记录

**Rationale**:
- 通过 `id` 精确定位记录，避免误更新其他数据
- RESTful 标准规范：`PUT /resource/{id}` 中 `id` 为必填路径参数
- Pydantic Update Schema 中不包含 `id` 字段（因为 `id` 通过 URL 路径传入，不在 Request Body 中）
- FastAPI 通过 `@Path()` 注解对路径参数进行类型校验和文档生成

**约定规范**：

```python
# 路由定义示例
@router.put("/users/{user_id}")
async def update_user(
    user_id: str = Path(..., description="用户 ID（UUID）"),
    body: UserUpdateRequest = Body(...)
):
    # user_id 从 URL 路径获取，用于精确定位记录
    ...

# Pydantic Schema 中不包含 id（id 在 URL 路径中）
class UserUpdateRequest(BaseModel):
    uid: Optional[str] = Field(None, min_length=3, max_length=20)
    email: Optional[EmailStr] = None
    # 不包含 id 字段
```

**涉及的所有更新端点**：

| 服务 | 端点 | 路径参数 | 说明 |
| ---- | ---- | -------- | ---- |
| UserManage | `PUT /users/{user_id}` | `user_id` | 更新用户信息 |
| UserManage | `PUT /roles/{role_id}` | `role_id` | 更新角色信息 |
| KnowledgeManage | `PUT /prompts/{prompt_id}` | `prompt_id` | 更新提示词 |
| KnowledgeManage | `PUT /chats/{chat_id}` | `chat_id` | 更新会话 |
| LlmGateway | `PUT /models/{model_id}` | `model_id` | 更新模型配置 |

所有删除端点（DELETE）同样遵循此规范。
