# API Contracts: API Keys Management

**Feature**: 003-api-keys-management
**Base URL**: `/api/user`
**Auth**: JWT Bearer Token (except `/api-keys/verify` which uses internal service auth)

## Endpoints

### 1. 创建 API Key

```
POST /api-keys
Authorization: Bearer <access_token>
Content-Type: application/json
```

**Request Body**:
```json
{
  "name": "string (1-100 chars, trimmed non-empty)"
}
```

**Response 201 Created**:
```json
{
  "id": "uuid",
  "name": "My Key",
  "masked_key": "[REDACTED_API_TOKEN]...WxYz",
  "secret": "[REDACTED_API_TOKEN]",
  "created_at": "2026-10-28T12:00:00Z",
  "last_used_at": null
}
```

> `secret` 字段仅在此响应中返回一次，后续任何接口都不会再返回完整密钥。

**Error Responses**:
- `400` — 名称为空或超过100字符
- `400` — 当前用户 API Key 数量已达上限 (20)
- `401` — 未登录或 Token 无效

---

### 2. 获取 API Key 列表

```
GET /api-keys?page="[REDACTED]"
Authorization: Bearer <access_token>
```

**Response 200 OK**:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "My Key",
      "masked_key": "[REDACTED_API_TOKEN]...WxYz",
      "created_at": "2026-10-28T12:00:00Z",
      "last_used_at": null
    }
  ],
  "total": 5,
  "page": 1,
  "page_size": 10
}
```

> 列表不包含 `secret` 字段。

**Error Responses**:
- `401` — 未登录或 Token 无效

---

### 3. 编辑 API Key 名称

```
PUT /api-keys/{key_id}
Authorization: Bearer <access_token>
Content-Type: application/json
```

**Path Parameters**:
- `key_id` — API Key 的 UUID

**Request Body**:
```json
{
  "name": "string (1-100 chars, trimmed non-empty)"
}
```

**Response 200 OK**:
```json
{
  "id": "uuid",
  "name": "New Name",
  "masked_key": "[REDACTED_API_TOKEN]...WxYz",
  "created_at": "2026-10-28T12:00:00Z",
  "last_used_at": null
}
```

**Error Responses**:
- `400` — 名称为空或超过100字符
- `404` — Key 不存在或不属于当前用户
- `401` — 未登录或 Token 无效

---

### 4. 删除 API Key

```
DELETE /api-keys/{key_id}
Authorization: Bearer <access_token>
```

**Path Parameters**:
- `key_id` — API Key 的 UUID

**Response 200 OK**:
```json
{
  "message": "API key 已删除"
}
```

**Error Responses**:
- `404` — Key 不存在或不属于当前用户
- `401` — 未登录或 Token 无效

---

### 5. 验证 API Key（内部端点）

```
POST /api-keys/verify
Content-Type: application/json
```

> 此端点供 LLM Gateway 内部调用，不使用用户 JWT 认证，需配置服务间认证（如内部 API Key 或 mTLS）。

**Request Body**:
```json
{
  "key": "[REDACTED_API_TOKEN]"
}
```

**Response 200 OK (valid)**:
```json
{
  "valid": true,
  "key_id": "uuid",
  "user_id": "uuid"
}
```

**Response 200 OK (invalid)**:
```json
{
  "valid": false
}
```

---

## Pydantic Schema 定义

### 请求模型

```python
class ApiKeyCreateRequest(BaseModel):
    "[REDACTED]"

class ApiKeyUpdateRequest(BaseModel):
    "[REDACTED]"

class ApiKeyVerifyRequest(BaseModel):
    "[REDACTED]"
```

### 响应模型

```python
class ApiKeyCreateResponse(BaseModel):
    "[REDACTED]"
    name: str
    masked_key: str
    secret: str              # 仅创建时返回
    created_at: datetime
    last_used_at: datetime | None

class ApiKeyResponse(BaseModel):
    "[REDACTED]"
    name: str
    masked_key: str
    created_at: datetime
    last_used_at: datetime | None

class PaginatedApiKeyResponse(BaseModel):
    "[REDACTED]"
    total: int
    page: int
    page_size: int

class ApiKeyVerifyResponse(BaseModel):
    "[REDACTED]"
    key_id: str | None = None
    user_id: str | None = None
```
