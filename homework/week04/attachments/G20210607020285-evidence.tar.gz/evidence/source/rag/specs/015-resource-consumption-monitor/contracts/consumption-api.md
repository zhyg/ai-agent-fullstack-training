# API Contract: 资源消耗监控

**Base**: `/api/knowledge/consumption`（KnowledgeManage，main.py 注册 prefix="/api/knowledge"）
**Auth**: Bearer JWT（沿用 get_current_user）；前端经 vite `/api/knowledge` 代理
**Feature**: 015-resource-consumption-monitor

## 1. GET /consumption/options

筛选选项（决策7 / R-006）。每次进页拉取一次。

**请求**: 无参数。

**响应 200**:

```json
{
  "user_emails": ["admin@example.com", "user@example.com"],
  "models": ["deepseek-v4-pro-deepseek", "qwen-max"],
  "is_admin": true
}
```

- 管理员：user_emails 为指标中出现过的全部非空值；普通用户：仅本人 email
- models：全部非空模型名（升序）
- 来源：Prometheus label values（match[]=llm_tokens_total），排除空串

**错误**: 401 未认证；502 Prometheus 不可达（detail 含原因）

## 2. GET /consumption/series

消耗序列查询（FR-005~018）。

**查询参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| metric | string | 是 | `tokens` / `cost` |
| scope | string | 是 | `user_daily` / `user_monthly` / `all_monthly` |
| user_email | string | scope=user_* | 普通用户必须为本人，否则 403 |
| models | string | 否 | 逗号分隔；空/缺省=全部 |
| month | string | scope=user_daily | `YYYY-MM`，不得晚于当前月 |
| year | int | scope=*_monthly | 不得晚于当前年 |

**示例**: `GET /consumption/series?metric=tokens&scope=user_daily&user_email=admin@example.com&month=2026-11`

**响应 200**（当前月，截断至今天，无数据日补 0）:

```json
{
  "metric": "tokens",
  "scope": "user_daily",
  "buckets": ["2026-11-01", "2026-11-02", "...", "2026-11-25"],
  "series": [
    { "model": "deepseek-v4-pro-deepseek", "values": [0, 1282, 0, 871] }
  ],
  "out_of_retention": false
}
```

- buckets 升序、与 values 等长对齐；当月截至今天、当年截至本月（FR-018）
- token values 非负整数；cost values 非负浮点、服务端 round 6 位（FR-015）
- series 按模型名升序；补 0 模型范围仅限 models 参数**显式勾选**的模型（查询期间全 0 仍返回全 0 曲线）；全选（models 空/缺省）时仅返回区间内有数据的模型，不做额外 label values 查询
- 所有人视图（scope=all_monthly）values 为跨用户求和

**超保留期响应 200**:

```json
{ "metric": "tokens", "scope": "user_daily", "buckets": [], "series": [], "out_of_retention": true }
```

**错误**:

| 状态 | 场景 | detail 示例 |
|------|------|-------------|
| 400 | 参数缺失/格式非法/未来期间 | "month 格式须为 YYYY-MM" / "不可查询未来期间" |
| 401 | 未认证/令牌过期 | 沿用既有 |
| 403 | 普通用户查他人或 all_monthly | "无权查看其他用户的消耗数据" |
| 502 | Prometheus 不可达 / 用户身份解析失败 | "指标数据源不可用" / "无法解析当前用户身份" |

## 3. 后端 → Prometheus 内部契约（R-003/004）

逐桶瞬时查询（每桶一次，asyncio 并发 ≤8）：

```
GET {prometheus.url}/api/v1/query
  query = sum by (model) (increase(llm_tokens_total{type!="cached",user_email="X",model=~"a|b"}[86400s]))
  time  = <桶结束时刻 UTC epoch>
```

- 费用：`increase(llm_cost_estimate_total{...}[window])`（活体核验：counter 实际名带 _total 后缀）
- 所有人视图：省略 user_email 过滤
- 全选模型：省略 model 过滤
- partial 桶：window=已经过秒数，time=now
- label values：`GET /api/v1/label/{user_email|model}/values?match[]=llm_tokens_total`

## 4. 前端调用契约（monitorApi.js）

沿用 evaluationApi.js 模式：axios baseURL `${VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'}/consumption`，Bearer 拦截器，401 清 token 跳登录，错误提取 `response.data.detail`。

| 函数 | 对应接口 |
|------|----------|
| getMonitorOptions() | GET /options |
| getConsumptionSeries(params) | GET /series |