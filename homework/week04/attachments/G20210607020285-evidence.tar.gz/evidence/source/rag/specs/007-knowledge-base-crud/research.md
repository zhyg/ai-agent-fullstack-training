# Research: 知识库增删改查

## R-001: 跨服务模型数据获取策略

**Decision**: 前端直接从 LlmGateway 获取模型列表，在知识库创建/编辑表单中按 `category` 字段过滤显示

**Rationale**:
- 前端已有 `modelApi.js` 通过 `VITE_LLM_GATEWAY_URL` 调用 LlmGateway 模型 API
- 模型数据存储在 LlmGateway 的 `llm_gateway` schema 中，KnowledgeManage 不应直接访问
- 参考实现 MyKnowlegeWebDemo 也是前端获取模型列表后传给组件
- 前端 `fetchModels(1, 1000)` 已在 ModelManagement.vue 中使用，模式成熟

**Alternatives considered**:
- KnowledgeManage 后端代理调用 LlmGateway API → 增加后端耦合，前端已有直接通道
- 知识库后端存储模型名称快照 → 数据冗余，模型改名后不一致

**Category 映射**:
| 知识库选择器 | LlmGateway category | 说明 |
|------------|-------------------|------|
| LLM 模型 | `chat` | 对话类模型 |
| Embedding 模型 | `embedding` | 向量嵌入模型 |
| 图片识别模型 | `vision` | 视觉理解模型 |
| Rerank 模型 | `rerank` | 重排序模型 |

## R-002: 知识库名称唯一性实现

**Decision**: 后端使用数据库唯一约束 + 业务层预检查双重保护

**Rationale**:
- 参照 LlmGateway 模型管理中的 `UniqueConstraint('provider', 'name')` 模式
- KnowledgeBase 的唯一约束为 `(user_id, name)` —— 同一用户下名称唯一
- 数据库层：`UniqueConstraint('user_id', 'name', name='uq_kb_user_name')`
- 业务层：创建/更新前先查询是否重名，返回友好错误提示
- 参照 chat_service 中 `create_chat` 和 `update_chat` 的模式

**Alternatives considered**:
- 仅前端校验 → 并发场景下不可靠
- 仅数据库约束 → 错误提示不友好（500 而非 409）

## R-003: API 路由前缀与挂载

**Decision**: 知识库 router 使用 `/knowledge-bases` 前缀，挂载到 `/api/knowledge` 下

**Rationale**:
- 现有模式：`chats.router` 使用 `/chats` 前缀，挂载到 `app.include_router(chats.router, prefix="/api/knowledge")`
- 完整路径：`GET /api/knowledge/knowledge-bases`
- 避免与现有 `/api/knowledge/chats` 和 `/api/knowledge/prompts` 冲突

**Alternatives considered**:
- 使用 `/kbs` 缩写 → 不够直观
- 使用 `/knowledge-bases` 顶层路径 → 不符合现有 prefix 模式

## R-004: 前端组件架构

**Decision**: 采用 MyKnowlegeWebDemo 的组件拆分模式，在 `frontend/src/components/knowledge-base/` 下创建 5 个子组件

**Rationale**:
- 参考实现 KbList / KbCard / KbCreateModal / KbFormDrawer / EmptyKb 的分层清晰
- 与现有 `frontend/src/components/model/` 目录结构保持一致
- KnowledgeManagement.vue 作为页面容器，管理状态和协调子组件

**组件职责**:
| 组件 | 职责 |
|------|------|
| `KbList` | 列表容器，包含标题栏和空状态切换 |
| `KbCard` | 单个知识库卡片，展示名称/描述/模型/操作 |
| `KbCreateModal` | 新建弹窗，表单校验 |
| `KbFormDrawer` | 编辑抽屉，预填表单 |
| `EmptyKb` | 空状态引导 |

## R-005: 模型列表加载时机

**Decision**: 进入知识库页面时加载全量模型列表（`fetchModels(1, 1000)`），存入 Pinia store

**Rationale**:
- 与 ModelManagement.vue 的模式一致：`onMounted(() => modelStore.fetchModels(1, 1000))`
- 模型数据为全局共享，其他页面可能已加载过
- 模型数量预期 <100，全量加载无性能问题
- Pinia model store 已有缓存机制，无需重复请求

**Alternatives considered**:
- 按需懒加载各 category 模型 → 增加 API 调用复杂度
- 知识库后端缓存模型列表 → 跨服务数据同步问题
