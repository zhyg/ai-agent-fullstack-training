# Contract: Agent 管理 API（KnowledgeManage）

**Base URL**: `http://localhost:8002`（前端经 Vite 代理 `/api/knowledge`）
**Auth**: `Authorization: Bearer <UserManage 签发 JWT>`；读＝任意登录用户；写＝权限键 `permission_manage`（管理员）
**错误格式**: FastAPI 默认 `{"detail": "..."}`；校验错误 400 附字段级信息

## GET /agents

列出全部智能体（含停用），登录即可。

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "type": "quick_qa",
      "name": "快速问答",
      "icon": "thunderbolt",
      "description": "提供快速问答功能，用户输入问题，直接检索回答",
      "status": "enabled",
      "config": { "...": "见 data-model.md config 结构" },
      "created_at": "ISO8601",
      "updated_at": "ISO8601"
    }
  ]
}
```

## GET /agents/{agent_id}

详情（编辑弹窗回显数据源）。登录即可。

**Response 200**: 单个 Agent 对象（同上元素结构）
**Response 404**: `{"detail": "智能体不存在"}`

## PUT /agents/{agent_id}

整份更新基础信息 + config（弹窗“保存”）。**仅管理员**。

**Request Body**:
```json
{
  "name": "快速问答",
  "icon": "thunderbolt",
  "description": "提供快速问答功能，用户输入问题，直接检索回答",
  "config": {
    "prompts": { "clarify": "prompt-uuid", "rewrite": "prompt-uuid", "answer": "prompt-uuid", "compress": "prompt-uuid", "rerank": "prompt-uuid" },
    "retrieval": { "mode": "vector", "vector_top_k": 20, "keyword_top_k": 20, "hybrid_top_k": 20, "rerank_top_n": 15 },
    "models": { "analysis_model_id": "m-1", "max_tokens": 5000, "embedding_model_id": "m-2", "rerank_model_id": "m-3" }
  }
}
```

**Behavior**:
- 按 type 裁剪/校验 config（多余键忽略或 400，实现取忽略未知键、校验已知键）；范围与条件必填见 data-model.md 校验表
- 必填用途 prompt_id 不存在 → 400
- name 与其他智能体重名 → 409 `{"detail": "智能体名称已存在"}`
- 不修改 status/type（请求中即使携带也忽略）
- last-write-wins，无冲突检测

**Response 200**: 更新后的 Agent 对象
**Response 400**: 范围/必填/引用校验失败
**Response 403**: `{"detail": "无权访问：需要 permission_manage 权限"}`
**Response 404**: 智能体不存在
**Response 409**: 名称重复

## PATCH /agents/{agent_id}/status

停用/启用（卡片菜单操作）。**仅管理员**。

**Request Body**:
```json
{ "status": "disabled" }
```

**Behavior**: 仅变更 status（enabled/disabled 枚举校验），config 不变；幂等（同状态重复请求返回 200 当前对象）。

**Response 200**: 更新后的 Agent 对象
**Response 400**: status 非枚举值
**Response 403 / 404**: 同上

## 复用的既有接口（不在本期改动）

| 接口 | 服务 | 用途 |
|------|------|------|
| GET /prompts?page&page_size（≤100） | KnowledgeManage `/api/knowledge` | 提示词下拉选项（名称+版本），遵循现有可见性；前端循环翻页取全量 |
| GET /models（现有 modelApi 全量加载） | LlmGateway `/api/llm` | 模型下拉选项，按 category=chat/embedding/rerank 过滤 |

## 前端 UI 契约（要点）

- 卡片“...”菜单：管理员＋enabled → [编辑, 停用]；管理员＋disabled → [编辑, 启用]；普通用户 → 不渲染菜单操作项
- 编辑弹窗左侧菜单按 type：quick_qa 4 项 / reasoning_action 5 项 / planning_reasoning 6 项（FR-005）
- 检索策略条件显示：mode=vector→vector_top_k；keyword→keyword_top_k；hybrid→hybrid_top_k；rerank_top_n 恒显示（FR-008）
- 失效引用：下拉中已删除的 prompt/model 显示“已失效”tag；必填项失效时保存按钮校验拦截（FR-015）
- 取消/关闭弹窗丢弃未保存修改；左侧菜单切换保留未保存修改（FR-012/Assumptions）