# Feature Specification: API Keys Management

**Feature Branch**: `003-api-keys-management`

**Created**: 2026-01-28

**Status**: Draft

**Input**: User description: "在"AI"菜单下，新增"API keys"菜单，功能，用户可以新建key,删除key,编辑key的名称,页面效果参考MyKnowlegeWebDemo/src/views/ApiKeyManagement.vue,后端功能写在User Manage服务中"

## Clarifications

### Session 2026-10-28

- Q: API Key 的格式应该采用哪种方案？ → A: 前缀随机字符串格式，如 `[REDACTED_API_TOKEN]`（类似 OpenAI / Anthropic 风格），前缀为 `sk-`
- Q: UserManage 服务后端应该如何存储和验证 API Key 的密钥值？ → A: 存储密钥的哈希值（用于验证）和脱敏版本（用于展示），LLM Gateway 验证时需调用 UserManage 传入完整 Key 进行哈希比对
- Q: API Keys 列表是否需要支持按名称搜索或筛选？ → A: 需要搜索框，支持按名称关键字实时过滤列表
- Q: 删除 API Key 时应该采用物理删除还是软删除？ → A: 物理删除（硬删除），直接从数据库移除记录，删除后不可恢复，Key 立即彻底失效

## User Scenarios & Testing *(mandatory)*

### User Story 1 - 创建 API Key (Priority: P1)

用户登录系统后，进入"AI"菜单下的"API keys"页面，可以创建一个新的 API Key。创建时需输入 Key 名称（最多100个字符），系统生成完整的 Key 并仅在创建成功时一次性展示。用户必须在此时复制并保存完整 Key，关闭展示窗口后将无法再次查看。

**Why this priority**: API Key 的创建是核心功能，是使用 API 服务的前提条件，具有最高优先级。

**Independent Test**: 用户可以独立完成创建流程——输入名称、提交、看到完整 Key、复制保存，交付可用的 API Key。

**Acceptance Scenarios**:

1. **Given** 用户已登录且 API Key 数量未达上限, **When** 用户点击"创建 API key"按钮并输入合法名称后提交, **Then** 系统创建 Key 并弹出完整 Key 展示窗口，用户可一键复制
2. **Given** 用户已登录且 API Key 数量已达上限, **When** 用户尝试创建新 Key, **Then** "创建 API key"按钮置灰禁用，并显示当前数量/上限提示
3. **Given** Key 创建成功展示窗口已关闭, **When** 用户再次查看 Key 列表, **Then** 只能看到脱敏后的 Key（如前缀+星号），无法查看完整 Key

---

### User Story 2 - 删除 API Key (Priority: P1)

用户可以在 API Keys 列表中删除不再需要的 Key。删除前系统弹出确认对话框，防止误操作。

**Why this priority**: 删除是 Key 生命周期管理的基本操作，与安全直接相关，与创建同等重要。

**Independent Test**: 用户可以选中某个 Key 执行删除，确认后该 Key 从列表中消失，且后续请求无法再使用该 Key。

**Acceptance Scenarios**:

1. **Given** 用户有一个或多个 API Key, **When** 用户点击某个 Key 的"删除"按钮并确认, **Then** 该 Key 从列表中移除并从数据库中物理删除，页面显示删除成功提示
2. **Given** 删除确认弹窗已出现, **When** 用户点击"取消", **Then** 弹窗关闭，Key 保留不变
3. **Given** Key 已被删除, **When** 外部系统使用该 Key 发起 API 调用, **Then** 系统拒绝该请求（Key 无效）

---

### User Story 3 - 编辑 API Key 名称 (Priority: P2)

用户可以修改已有 API Key 的名称，以便更好地标识和管理不同用途的 Key。编辑仅修改名称，不改变 Key 本身。

**Why this priority**: 编辑名称属于管理辅助功能，不影响 Key 的可用性，优先级次于创建和删除。

**Independent Test**: 用户可以点击编辑按钮、修改名称并保存，列表中该 Key 名称立即更新。

**Acceptance Scenarios**:

1. **Given** 用户有一个 API Key, **When** 用户点击"编辑名称"按钮、输入新名称并保存, **Then** 列表中该 Key 的名称更新为新名称，显示保存成功提示
2. **Given** 编辑弹窗已打开, **When** 用户清空名称或输入超过100个字符后尝试保存, **Then** 表单验证阻止提交并显示错误提示
3. **Given** 编辑弹窗已打开, **When** 用户点击"取消"或关闭弹窗, **Then** 名称保持不变

---

### User Story 4 - 查看 API Keys 列表 (Priority: P2)

用户进入"API keys"页面后，可以看到自己所有 Key 的列表，包含名称、Tracking ID、脱敏 Key、创建日期和最后使用日期。

**Why this priority**: 列表展示是所有管理操作的基础视图，但本身不涉及数据变更，优先级略低。

**Independent Test**: 用户进入页面即可看到完整的 Key 列表及其关键信息，空状态有引导提示。

**Acceptance Scenarios**:

1. **Given** 用户已登录且有多个 API Key, **When** 用户进入"API keys"页面, **Then** 以表格形式展示所有 Key 的名称、Tracking ID、脱敏 Key、创建日期、最后使用日期
2. **Given** 用户没有任何 API Key, **When** 用户进入页面, **Then** 显示空状态提示，引导用户创建第一个 Key
3. **Given** 用户有超过10个 Key, **When** 查看列表, **Then** 表格支持分页，每页10条
4. **Given** 用户有多个 API Key, **When** 用户在搜索框中输入名称关键字, **Then** 列表实时过滤显示名称匹配的 Key

---

### Edge Cases

- 用户名称输入为纯空格时如何处理？系统应拒绝纯空格名称（前后空格需 trim 后校验非空）。
- 并发创建：用户在两个浏览器标签页同时创建 Key，是否可能导致超出上限？系统应在后端校验数量上限，超出时返回错误。
- 网络异常时创建/删除/编辑操作的反馈？系统应显示友好的错误提示，引导用户重试。
- Key 生成的唯一性保证？系统生成的 Key 必须全局唯一，不可重复。

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: 系统必须允许登录用户创建 API Key，创建时需提供 Key 名称（必填，1-100个字符，去除首尾空格后非空）
- **FR-002**: 系统必须在创建成功时一次性展示完整 API Key，关闭展示窗口后不再显示完整 Key
- **FR-003**: 系统必须对 API Key 设置数量上限，单个用户最多持有 20 个 Key
- **FR-004**: 系统必须允许用户删除已有的 API Key，删除前需二次确认
- **FR-005**: 系统必须允许用户编辑 API Key 的名称，编辑不影响 Key 本身的值
- **FR-006**: 系统必须在 API Keys 列表中展示以下信息：名称、Tracking ID、脱敏 Key、创建日期、最后使用日期
- **FR-007**: 系统必须保证生成的 API Key 全局唯一，格式为前缀随机字符串（前缀 `sk-` + 32位随机字符）
- **FR-008**: 系统必须在列表中以脱敏方式展示 Key（仅显示前缀和后缀，中间以星号替代）
- **FR-009**: 系统必须记录每个 Key 的创建时间和最后使用时间
- **FR-010**: "API keys"菜单必须位于"AI"一级菜单下，作为其子菜单项
- **FR-011**: API Key 的后端功能（创建、删除、编辑、查询）必须部署在 UserManage 服务中
- **FR-012**: 系统必须对 API Key 名称进行长度校验（最多100个字符），并拒绝纯空格名称
- **FR-013**: 系统必须在 API Keys 列表页面提供搜索框，支持按名称关键字实时过滤列表

### Key Entities

- **API Key**: 代表用户创建的 API 访问密钥。核心属性包括：唯一标识（ID/Tracking ID）、名称（用户自定义）、密钥哈希值（用于验证，不可逆）、脱敏密钥（列表展示用）、创建时间、最后使用时间、所属用户 ID。
- **用户**: 系统中已注册的登录用户，是 API Key 的拥有者。一个用户可拥有多个 API Key（上限20个）。

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 用户可以在3步以内（点击创建、输入名称、确认）完成一个 API Key 的创建
- **SC-002**: 用户在创建成功后能一键复制完整 Key，复制操作在1秒内完成反馈
- **SC-003**: 删除操作经二次确认后，Key 在用户视角下即时消失，整个过程不超过5秒
- **SC-004**: 编辑名称保存后，列表立即刷新展示新名称，操作响应在1秒内
- **SC-005**: API Keys 列表在 Key 数量超过10条时自动分页，页面加载在2秒内完成
- **SC-006**: 90% 的用户在首次使用时能成功完成至少一个 Key 的创建和复制
- **SC-007**: 搜索过滤操作响应即时，输入关键字后列表在1秒内完成过滤展示

## Assumptions

- 用户已完成登录认证，API Key 管理功能仅对登录用户开放
- API Key 的数量上限为每个用户最多20个（参考业界标准）
- API Key 生成采用安全的随机算法，保证全局唯一性和不可预测性
- 完整 API Key 仅在创建时展示一次，后端存储密钥的哈希值（用于验证）和脱敏版本（用于展示），不存储明文 Key
- 本功能的前端集成在现有前端项目中，复用现有的菜单导航和路由架构
- 后端 API Key 管理模块集成在 UserManage 服务中，复用现有的用户认证和鉴权机制
- 列表展示中脱敏 Key 格式为：显示 `sk-` 前缀 + 前8位随机字符 + "..." + 后4位字符
- 最后使用时间字段初始值为"尚未使用"，后续由 LLM Gateway 服务在 Key 被实际调用时更新
