# Quickstart: 智能体菜单功能完善（011-agent-settings）验证指南

**Date**: 2026-11-22 | **契约**: [contracts/agent-api.md](./contracts/agent-api.md) | **数据模型**: [data-model.md](./data-model.md)

本指南仅含可运行的验证场景与命令，不含实现代码。

## 前置条件

1. PostgreSQL 可达（`KnowledgeManage/config.dev.yaml`：127.0.0.1:5432/mydb，schema `knowledge_manage`）
2. UserManage(:8001)、KnowledgeManage(:8002)、LlmGateway(:8003) 已启动；frontend Vite dev server 已启动（代理 /api/knowledge、/api/llm、/api/user）
3. 至少一个管理员账号（permissions 含 `permission_manage`）与一个普通账号
4. 模型管理中已存在 chat/embedding/rerank 各 ≥1 个模型；提示词管理中已存在 ≥1 条提示词（用于下拉与引用校验场景）
5. Python 环境：`/Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python`

##  Setup

```bash
cd KnowledgeManage
alembic upgrade head          # 建 agents 表 + 注入三条预置数据（幂等）
```

获取令牌（管理员/普通用户各一）：

```bash
curl -s -X POST http://localhost:8001/api/user/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"uid":"<admin_uid>","password":"[REDACTED]"
```

## 后端自动化测试

```bash
cd KnowledgeManage
python -m pytest tests/test_agents.py -v
```

预期：全部通过（覆盖列表/详情/更新/状态/403/400/409/预置存在性）。

## 验证场景

### V-001 预置数据与卡片列表（US1 / FR-001 / FR-016）

```bash
curl -s http://localhost:8002/agents -H "Authorization: Bearer $ADMIN_TOKEN"
```

预期：items 恰 3 条，type 分别为 quick_qa/reasoning_action/planning_reasoning，status 均 enabled，description 与 FR-016 一致。
UI：登录进入“智能体”菜单，见三张卡片（名称/图标/描述/状态）。

### V-002 停用→刷新→启用→刷新（US1 / FR-002 / FR-003 / SC-001）

UI：管理员点卡片“...”→停用；卡片出现停用标识、菜单变“启用”；刷新页面状态保持；点“启用”恢复；再刷新保持。
接口核对：

```bash
curl -s -X PATCH http://localhost:8002/agents/<id>/status \
  -H "Authorization: Bearer $ADMIN_TOKEN" -H 'Content-Type: application/json' \
  -d '{"status":"disabled"}'
```

预期：200 且 status=disabled、config 与停用前完全一致；重复同状态请求仍 200（幂等）。

### V-003 普通用户只读与越权拦截（FR-004 / FR-017）

UI：普通用户登录见三张卡片但“...”无编辑/停用/启用项。
接口：

```bash
curl -s -o /dev/null -w '%{http_code}' -X PATCH http://localhost:8002/agents/<id>/status \
  -H "Authorization: Bearer $USER_TOKEN" -H 'Content-Type: application/json' -d '{"status":"disabled"}'
curl -s -o /dev/null -w '%{http_code}' -X PUT http://localhost:8002/agents/<id> \
  -H "Authorization: Bearer $USER_TOKEN" -H 'Content-Type: application/json' -d '{}'
```

预期：均 403；GET /agents 普通用户 200。

### V-004 编辑弹窗菜单与回显（US2–US4 / FR-005 / FR-012 / SC-002）

UI：管理员依次打开三个智能体编辑弹窗，核对左侧菜单 4/5/6 项；修改检索方式、召回数量、模型、提示词后保存；重开核对 100% 回显；修改后取消重开核对未污染。
预期：与 contracts/agent-api.md 前端 UI 契约一致。

### V-005 检索策略条件显示（FR-008 / SC-004）

UI：三个智能体 × 三种检索方式共 9 组合，核对仅显示对应召回数量项＋恒显重排数量；切换方式后切回，原数值保留。
预期：9/9 正确；默认 20/20/20/15。

### V-006 数值范围拦截（FR-013 / SC-003）

UI：召回/重排输入 0 与 101、循环输入 0 与 1001、max_tokens 输入 0 与 50001 → 保存被阻止并提示范围；边界 1/100/1000/50000 可保存。
接口：PUT 携带越界值预期 400。

### V-007 名称唯一（FR-018）

UI：将某智能体名称改为另一智能体名称 → 保存阻止并提示。
接口：PUT name 重名预期 409。

### V-008 基础信息编辑与图标（FR-006 / Q4）

UI：修改名称/描述、从内置图标库换图标 → 保存后卡片以新值展示；无上传入口。

### V-009 工具配置持久化（US4 / FR-011 / SC-006）

UI：规划推理工具配置默认 12 项全勾选；取消“SQL执行”“压缩”保存重开 → 保持未勾选其余勾选。
接口：GET 详情 config.tools 恰缺这两个 key。

### V-010 引用失效处理（FR-015）

准备：先在提示词管理删除某已被智能体引用的提示词（或模型管理删除被引用模型）。
UI：重开编辑弹窗对应下拉显示“已失效”；必填项失效时保存被拦截；重新选择有效项后可保存。
接口：PUT 携带不存在的必填 prompt_id 预期 400。

### V-011 无新建/删除入口（FR-014）

UI：智能页与卡片菜单均无新建/删除按钮；接口层无 POST /agents、DELETE /agents/{id}（405/404）。

## 完成判定

V-001–V-011 全部符合预期 + pytest 全绿 ⇒ 本期验收通过（对应 SC-001–SC-006）。