# Research: LLM Gateway 支持 Embedding、Rerank、视觉模型

**Feature**: 009-gateway-embedding-rerank-vision
**Date**: 2026-11-17

## R-001: Embedding API 协议选择

**Decision**: 采用 OpenAI `/v1/embeddings` 协议作为标准接口格式。

**Rationale**: OpenAI Embedding API 是业界事实标准，几乎所有向量模型供应商（OpenAI、Azure、SiliconFlow、阿里百炼、Jina）都兼容此协议。请求/响应格式简洁，支持单条和批量输入，返回标准向量数组。

**Alternatives considered**:
- Cohere Embed API：供应商覆盖少，不兼容 OpenAI 生态
- 自定义协议：增加调用方适配成本，无收益

## R-002: Rerank API 协议选择

**Decision**: 采用 Cohere Rerank 兼容协议，新增 `CohereRerankAdapter`。

**Rationale**: Cohere Rerank 协议已成为 Rerank 领域的事实标准。BGE-Reranker、Jina-Reranker、SiliconFlow Rerank 服务均兼容此协议（query + documents → scored results）。与 OpenAI 无 Rerank API 不同，Rerank 需要独立的适配器。

**Alternatives considered**:
- 将 rerank 放入 OpenAIAdapter：语义不清，OpenAI 不提供 rerank
- 自定义 Rerank 协议：增加调用方学习成本

## R-003: URL 构建策略

**Decision**: 数据库 `url` 字段统一存储 base URL（如 `https://api.openai.com/v1`），adapter 内部按调用类型自动拼接子路径。

**Rationale**: 
- 当前 `_normalize_url` 硬编码追加 `/chat/completions`，无法支持 `/embeddings` 等其他端点
- 存储 base URL 使同一供应商的不同端点共享同一配置，管理员只需填一次 URL
- 子路径拼接逻辑集中在 adapter 内部，职责清晰

**Alternatives considered**:
- 数据库存完整 URL：每个端点需要独立的模型记录，不合理
- embed() 方法内部单独构建 URL 不改现有逻辑：造成两套 URL 处理路径，维护成本高

## R-004: Vision 模型的 category 与路由策略

**Decision**: Vision 模型使用独立的 `category=vision`，Router 层 `chat/vision` 共用 Chat 链路。

**Rationale**:
- 现有 Schema 已定义 `vision` 为合法 category 值，保持一致
- Vision 与 Chat 协议完全相同（OpenAI 兼容格式），共用链路避免重复代码
- `supported_modalities` 字段区分纯文本模型和视觉模型的能力

**Alternatives considered**:
- `category=chat` + `supported_modalities` 区分：与已有 Schema 定义不一致
- 从枚举中删除 `vision`：破坏现有数据模型

## R-005: 消息序列化位置

**Decision**: 在 Gateway Service 层对 `list[ContentPart]` 做 `model_dump(exclude_none=True)` 转换。

**Rationale**:
- 当前 `LLMGatewayService` 用 `m.content` 直接构建 dict，Pydantic 对象无法直接 JSON 序列化
- Service 层是消息构建的统一入口，在此处理类型转换最自然
- Adapter 层只接收 `list[dict]`，保持简单

**Alternatives considered**:
- Adapter 层处理序列化：破坏 adapter 的协议纯性
- 透传原始数据不做类型转换：Pydantic 对象无法直接传给 httpx json 参数

## R-006: Prometheus 指标变更策略

**Decision**: 直接在现有 `llm_request_total` 等指标上新增 `category` label（破坏性变更）。

**Rationale**:
- 开发阶段可接受破坏性变更，无需维护两套指标
- 统一的 `category` 标签便于跨类型聚合分析
- 同步更新 Grafana Dashboard 和告警规则即可

**Alternatives considered**:
- 新建独立 metric `llm_request_by_category_total`：指标分裂，查询复杂
- 只通过专属指标区分：缺少统一的跨类型视图

## R-007: Embedding/Rerank 重试策略

**Decision**: Embedding/Rerank 复用现有 `execute_with_retry`，最多 3 次重试，无流式中断约束。

**Rationale**:
- 两者均为无状态同步请求，不存在"首 delta 后不可重试"的约束
- 重试逻辑与 Chat 非流式调用完全相同，可直接复用
- 限流（429）和网络抖动（5xx）的退避策略同样适用

**Alternatives considered**:
- 为 Embedding/Rerank 单独实现重试：代码重复，无收益
