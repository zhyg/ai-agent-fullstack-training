# Tasks: 文档解析与分片

**Input**: Design documents from `/specs/010-doc-parse-chunk/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/document-processing-api.md

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1-US7)
- Include exact file paths in descriptions

---

## Phase 1: Setup (共享基础设施)

**Purpose**: 安装新依赖、更新配置文件，为后续开发奠定基础

- [x] T001 在 `KnowledgeManage/requirements.txt` 中新增依赖: `elasticsearch[async]>=8.0`, `llama-index-core`, `openpyxl`
- [x] T002 [P] 在 `KnowledgeManage/config.dev.yaml` 中新增 `elasticsearch` 配置段 (`hosts: "http://localhost:9200"`, `username: "elastic"`, `password: "[REDACTED]"
- [x] T003 [P] 在 `KnowledgeManage/config.prod.yaml` 和 `config.test.yaml` 中同步新增 `elasticsearch` 和 `mineru` 配置段
- [x] T004 在 `KnowledgeManage/app/core/config.py` 中新增 `ElasticsearchConfig` Pydantic 模型 (字段: `hosts: str`, `username: str = "elastic"`, `password: "[REDACTED]"

---

## Phase 2: Foundational (阻塞性前置任务)

**Purpose**: 核心基础设施 — ES 客户端、Document 模型扩展、Chunk Schema、ES CRUD 服务。**所有 User Story 均依赖此阶段完成。**

**⚠️ CRITICAL**: 此阶段未完成前，不可开始任何 User Story 任务

- [x] T005 [P] 创建 `KnowledgeManage/app/core/es_client.py` — Elasticsearch 异步客户端单例封装: `get_async_client()` 返回 `AsyncElasticsearch` 实例，`ensure_index(kb_id, dims)` 按知识库创建索引 `knowledge_chunks_{kb_id}` (mapping 参照 data-model.md)，`close_client()` 清理连接
- [x] T006 [P] 修改 `KnowledgeManage/app/models/document.py` — Document 模型扩展: (1) status 字段 String(30) default "pending" 替换原 "parsing" (2) 新增 `md_path: String(1000) nullable` (MinIO markdown路径) (3) 新增 `chunk_config: Text nullable` (分块配置JSON) (4) 新增 `ai_question_count: Integer nullable default 3` (5) 新增 `skipped_files: Text nullable` (跳过的文件JSON) (6) 新增索引 `idx_document_kb_status(kb_id, status)`
- [x] T007 [P] 创建 `KnowledgeManage/app/schemas/chunk.py` — Chunk Pydantic 模型: `ChunkResponse`(chunk_id, document_id, chunk_type, content, image_url, parent_chunk_id, sqlite_url, chunk_index, created_at), `ChunkListResponse`(items, total, page, page_size), `ChunkChildResponse`
- [x] T008 生成 Alembic 迁移脚本 — 在 `KnowledgeManage/` 目录下执行 `alembic revision --autogenerate -m "extend_document_status_and_chunk_fields"` 并确认迁移包含 status/md_path/chunk_config/ai_question_count/skipped_files 字段变更及新索引
- [x] T009 创建 `KnowledgeManage/app/services/es_chunk_service.py` — ES Chunks CRUD 服务: `bulk_index_chunks(kb_id, chunks)` 批量写入, `query_chunks(kb_id, document_id, page, page_size, chunk_type)` 分页查询, `get_children(kb_id, chunk_id)` 查子chunks, `delete_by_document(kb_id, document_id)` 按文档删除所有chunks, `delete_index(kb_id)` 删除索引
- [x] T010 创建 `KnowledgeManage/app/routers/chunks.py` — Chunk 查询路由: `GET /documents/{document_id}/chunks` (分页+类型过滤), `GET /chunks/{chunk_id}/children` (查子chunks), `GET /chunks/{chunk_id}/table-data` (查SQLite数据, 需下载MinIO db文件执行SELECT)
- [x] T011 修改 `KnowledgeManage/app/main.py` — 注册 chunks 路由 (`app.include_router(chunks.router, prefix="/api/knowledge")`), 在 lifespan 中初始化 ES 客户端和关闭
- [x] T012 修改 `KnowledgeManage/app/routers/documents.py` — 新增 `POST /documents/{document_id}/reprocess` 接口 (接收 chunk_config 参数, 删除旧chunks, 触发重新处理), 修改上传接口支持 chunk_strategy/chunk_size/chunk_overlap/separators/ai_question_count form 参数

**Checkpoint**: ES 连接可用，Document 模型迁移完成，Chunk 查询 API 可工作（暂无数据），基础就绪

---

## Phase 3: User Story 1 — 单文档上传与自定义分片 (Priority: P1) 🎯 MVP

**Goal**: 用户上传 doc/docx/ppt/pptx/pdf/md 文件，系统自动解析、按用户选择的分块策略切分、生成向量、存入 ES

**Independent Test**: 上传一个 PDF 文件，设置"按标题切分"，验证 ES 中存在正确的 text chunks，前端可浏览分片内容

### Implementation for User Story 1

- [x] T013 [P] [US1] 创建 `KnowledgeManage/app/services/chunking_service.py` — 分块策略实现: (1) `chunk_by_heading(markdown_text, chunk_size=512, chunk_overlap=80)` 使用 LlamaIndex `MarkdownNodeParser` 按标题切分，大片段按分隔符二次切分 (2) `chunk_by_fixed(text, chunk_size=512, chunk_overlap=80, separators=[...])` 使用 LlamaIndex `SentenceSplitter` 按固定长度切分 (3) 每个 chunk 前缀添加 `[文件名: xxx]` (4) 表格行作为原子单元不拆分 (5) 分隔符优先级: `\n\n` > `\n` > `。` > `；` > `？` > `！` > `.` > `;` > `?` > `!`
- [x] T014 [P] [US1] 创建 `KnowledgeManage/app/services/parsing_service.py` — 文档解析服务: (1) `parse_document(file_path, extension, mineru_url)` 调用 MinerU `/file_parse` 接口将 doc/docx/ppt/pptx/pdf 转为 markdown，需传 `formula_enable=true`, `table_enable=true` (2) `parse_markdown(md_content)` 对 md 文件直接使用原始内容 (3) 解析结果中提取图片，将本地/嵌入式图片上传 MinIO 并替换链接为 MinIO 地址（外部URL保持原样） (4) 将转换后 markdown 上传 MinIO 并记录 md_path
- [x] T015 [P] [US1] 创建 `KnowledgeManage/app/services/embedding_service.py` — 向量生成服务: `generate_embeddings(texts, kb_id)` 通过 LlmGateway 调用知识库配置的 Embedding 模型 (`embedding_model_id`) 生成向量，返回 `List[List[float]]`，需先查询知识库配置获取模型ID
- [x] T016 [US1] 创建 `KnowledgeManage/app/services/document_pipeline.py` — 文档处理流水线编排: `process_document(db, document, kb_id, chunk_config, ai_question_count)` 异步函数，按阶段执行: (1) 更新 status→"parsing" 调用 parsing_service (2) status→"chunking" 调用 chunking_service (3) status→"embedding" 调用 embedding_service (4) status→"ai_generating" 调用 ai_question_service (5) status→"completed" (6) 任一阶段异常→status="failed" 调用 `es_chunk_service.delete_by_document()` 清理ES chunks + 清理MinIO中间文件 (7) 外部服务不可用时直接整体失败
- [x] T017 [US1] 修改 `KnowledgeManage/app/services/document_service.py` — 上传接口集成: (1) `upload_document()` 中设置 status="pending"，保存 chunk_config 和 ai_question_count 到 Document (2) 返回 documents 后，路由层使用 FastAPI `BackgroundTasks` 触发 `process_document()` (3) 实现同名文档覆盖替换逻辑 (FR-040): 查找同名旧文档→删除旧 chunks+MinIO 文件→重新处理
- [x] T018 [US1] 修改 `KnowledgeManage/app/routers/documents.py` — 上传路由注入 `BackgroundTasks`: 接收分块参数 form fields (chunk_strategy/chunk_size/chunk_overlap/separators/ai_question_count)，上传完成后调用 `background_tasks.add_task(process_document, ...)`
- [x] T019 [P] [US1] 创建 `frontend/src/components/knowledge/ChunkSettingTab.vue` — 分块设置 tab 组件: (1) 分块策略下拉框 ("按标题切分"/"按固定长度切分") (2) 分块大小数字框 (100-4000, 默认512, 描述: "每个分块的最大字符数...") (3) 分块重叠数字框 (0-500, 默认80, 描述: "相邻分块之间共享的字符数...") (4) 分隔符多选下拉框 (10种分隔符, 描述: "切分时优先使用的字符或字符串...")
- [x] T020 [US1] 修改 `frontend/src/components/knowledge/DocumentCreateModal.vue` — 集成 ChunkSettingTab: 单文件上传时显示"分块设置"tab，压缩包上传时隐藏；传递分块参数到上传 API
- [x] T021 [P] [US1] 修改 `frontend/src/services/documentApi.js` — 上传 API 新增 form 参数 (chunk_strategy, chunk_size, chunk_overlap, separators JSON, ai_question_count), 新增 `reprocessDocument(docId, config)` API
- [x] T022 [US1] 修改 `frontend/src/stores/document.js` — 新增 `chunkConfig` 响应式状态 (strategy/chunkSize/chunkOverlap/separators/aiQuestionCount)，上传时携带配置

**Checkpoint**: 上传 doc/docx/pdf/md 文件后，ES 中存在 text chunks，Document status 正常流转，前端可设置分块参数

---

## Phase 4: User Story 2 — 文档中图片的处理 (Priority: P2)

**Goal**: 文档中的图片保留在 text chunk 中，同时生成 image_ocr 和 image_caption 子 chunks

**Independent Test**: 上传包含图片的 docx 文档，验证 text chunk 含 `![](url)`，image_ocr 和 image_caption chunks 已生成并 parent_chunk_id 正确

### Implementation for User Story 2

- [x] T023 [P] [US2] 创建 `KnowledgeManage/app/services/image_service.py` — 图片处理服务: (1) `process_image_ocr(image_path, mineru_url)` 调用 MinerU `/file_parse` 处理图片获取 OCR 文本 (2) `process_image_caption(image_path, kb_id)` 通过 LlmGateway 调用知识库 `image_model_id` (视觉模型) 生成图片分析描述 (3) 两个方法均失败时抛异常触发整体失败
- [x] T024 [US2] 修改 `KnowledgeManage/app/services/parsing_service.py` — 添加文档图片提取逻辑: (1) 从 MinerU 解析结果中提取所有嵌入图片 (2) 将每张图片上传 MinIO (`{kb_id}/{doc_id}/images/{name}`) (3) 在 markdown 中将本地图片链接替换为 MinIO presigned URL (4) 返回 `(markdown_text, image_list)` 其中 image_list 为 `[{path, minio_url}]`
- [x] T025 [US2] 修改 `KnowledgeManage/app/services/chunking_service.py` — 分块时保留图片引用: (1) text chunk 的 content 中保留 `![](url)` 语法 (2) chunk 的 `image_url` 字段记录包含的所有图片地址列表 (3) 表格行 chunk 中的图片 URL 同样保留
- [x] T026 [US2] 修改 `KnowledgeManage/app/services/document_pipeline.py` — 在 chunking 阶段后调用 image_service: (1) 遍历所有 text/table_row chunks 的 image_url 列表 (2) 对每张图片调用 `process_image_ocr()` 和 `process_image_caption()` (3) 创建 image_ocr 和 image_caption chunks (parent_chunk_id 指向包含图片的 text/table_row chunk) (4) 将子 chunks 写入 ES

**Checkpoint**: 文档中的图片生成 image_ocr 和 image_caption 子 chunks，parent 关系正确

---

## Phase 5: User Story 3 — 文档中表格的处理 (Priority: P2)

**Goal**: 文档中的 HTML/Markdown 表格转为逐行文本格式，表格完整数据存储到 SQLite，行文本按分块大小动态切分

**Independent Test**: 上传包含表格的 docx 文档，验证 table_row chunks 行不拆分，SQLite db 在 MinIO 中可查询

### Implementation for User Story 3

- [x] T027 [P] [US3] 在 `KnowledgeManage/app/services/parsing_service.py` 中添加表格预处理方法: (1) `_convert_html_tables(md_text)` 将 HTML 表格转为 `<!-- TABLE_START:N -->\n列名: 值, 列名: 值\n...\n<!-- TABLE_END:N -->` 格式 (2) `_convert_md_tables(md_text)` 将 Markdown 管道表格转为同样格式 (3) 表格编号 N 用于区分不同表格
- [x] T028 [P] [US3] 创建 `KnowledgeManage/app/services/table_service.py` — 表格 SQLite 存储: (1) `create_sqlite_db(tables_data, kb_id, doc_id, table_names)` 在临时目录创建 SQLite db，按 sheet 动态建表 (2) 调用 LlmGateway 大模型将中文表名/列名转为英文（中文保留为 COMMENT） (3) 将 db 文件上传 MinIO (`{kb_id}/{doc_id}/tables/{table_name}.db`) (4) 返回 `sqlite_url` (5) 清理本地临时 db 文件
- [x] T029 [US3] 修改 `KnowledgeManage/app/services/chunking_service.py` — 添加表格行分块逻辑: (1) 解析 `TABLE_START/N...TABLE_END/N` 标记提取表格行文本 (2) 行文本累积达到 chunk_size 时切分到下一个 table_row chunk，但单行不拆分 (3) 每个 table_row chunk content 前部包含 `[表名: xxx, Sheet: yyy]` (4) 关联 sqlite_url
- [x] T030 [US3] 修改 `KnowledgeManage/app/services/document_pipeline.py` — 表格处理集成: (1) parsing 阶段调用表格预处理 (2) 提取表格数据调用 table_service 创建 SQLite db (3) chunking 阶段处理 table_row chunks (4) embedding 阶段为 table_row chunks 生成向量

**Checkpoint**: 文档中表格正确预处理、行不拆分、SQLite 数据完整可查询

---

## Phase 6: User Story 4 — 独立图片上传与处理 (Priority: P2)

**Goal**: 直接上传单张图片，生成 image + image_ocr + image_caption 三种 chunks

**Independent Test**: 上传单张 PNG 图片，验证三种 chunk 均正确生成，parent 关系正确，前端展示图片

### Implementation for User Story 4

- [x] T031 [US4] 在 `KnowledgeManage/app/services/document_pipeline.py` 中添加独立图片处理流程: `process_standalone_image(db, document, kb_id)` — (1) 从 MinIO 下载图片到临时文件 (2) 创建 image chunk (chunk_type="image", parent_chunk_id=null, content=`![](url)`, image_url=图片地址) (3) 调用 image_service 的 `process_image_ocr()` 生成 image_ocr chunk (parent→image chunk) (4) 调用 `process_image_caption()` 生成 image_caption chunk (parent→image chunk) (5) 为 image chunk 生成 embedding (6) 写入 ES (7) 清理临时文件
- [x] T032 [US4] 修改 `KnowledgeManage/app/services/document_pipeline.py` 的 `process_document()` — 添加文件类型判断: 当 extension 为图片类型 (png/jpg/jpeg/jp2/webp/gif/bmp) 时，调用 `process_standalone_image()` 而非文档解析流程
- [x] T033 [US4] 修改 `frontend/src/components/knowledge/DocumentDetailDrawer.vue` — 图片文档展示: 当文档为图片时，"原始内容"和"解析后Markdown"均展示图片预览（不展示 markdown 文件）

**Checkpoint**: 独立图片上传后三种 chunk 正确生成，前端正确展示

---

## Phase 7: User Story 5 — 独立表格文件上传 (Priority: P2)

**Goal**: 上传 xls/xlsx/csv 文件，校验格式，存储到 SQLite，按 sheet 切分为 table_row chunks

**Independent Test**: 上传 xlsx 文件（多 sheet），验证校验通过、SQLite 数据完整、table_row chunks 正确生成

### Implementation for User Story 5

- [x] T034 [US5] 在 `KnowledgeManage/app/services/table_service.py` 中添加表格文件处理: (1) `validate_spreadsheet(file_path)` 校验规则: 不能有合并单元格、表头必须在第一行、不能有空行 (2) `read_spreadsheet(file_path)` 使用 openpyxl 读取 xlsx/xls 所有 sheet，csv 使用 csv 模块 (3) 返回 `[{sheet_name, headers, rows}]`
- [x] T035 [US5] 在 `KnowledgeManage/app/services/document_pipeline.py` 中添加独立表格处理流程: `process_standalone_table(db, document, kb_id, chunk_config)` — (1) 校验表格格式 (2) 读取所有 sheet 数据 (3) 调用 table_service 创建 SQLite db (4) 按 sheet 切分为 table_row chunks (每个 chunk content 前部含 `[表名: xxx, Sheet: yyy]`) (5) 生成 embeddings (6) 写入 ES
- [x] T036 [US5] 修改 `KnowledgeManage/app/services/document_pipeline.py` 的 `process_document()` — 当 extension 为 xls/xlsx/csv 时，调用 `process_standalone_table()` 而非文档解析流程
- [x] T037 [US5] 修改 `frontend/src/components/knowledge/DocumentDetailDrawer.vue` — 表格文档展示: 当文档为表格时，"原始内容"和"解析后Markdown"均展示表格预览（不展示 markdown 文件）

**Checkpoint**: 独立表格上传后校验通过，SQLite 数据完整，table_row chunks 正确

---

## Phase 8: User Story 6 — AI 问题生成 (Priority: P3)

**Goal**: 为 text/image_ocr/table_row 类型的 chunk 调用大模型生成 AI 问题，存储为 ai_question chunks

**Independent Test**: 上传文档后设置 AI 问题数为 3，验证每个符合条件的 chunk 生成 3 个 ai_question chunks

### Implementation for User Story 6

- [x] T038 [P] [US6] 创建 `KnowledgeManage/app/services/ai_question_service.py` — AI 问题生成服务: `generate_questions(chunk_content, count, kb_id)` — (1) 构造 prompt: "根据以下内容生成 {count} 个用于检索的问题，以 JSON 数组格式返回" (2) 通过 LlmGateway 调用知识库 `llm_model_id` (3) 解析 JSON 返回问题列表 (4) 仅处理 text/image_ocr/table_row 类型的 chunk，跳过 image 和 image_caption
- [x] T039 [US6] 修改 `KnowledgeManage/app/services/document_pipeline.py` — 在 embedding 阶段后添加 ai_generating 阶段: (1) status→"ai_generating" (2) 遍历所有 text/image_ocr/table_row chunks (3) 对每个 chunk 调用 `generate_questions(content, ai_question_count, kb_id)` (4) 创建 ai_question chunks (parent_chunk_id 指向原始 chunk) (5) 为 ai_question chunks 生成 embeddings (6) 写入 ES
- [x] T040 [US6] 修改 `KnowledgeManage/app/routers/chunks.py` — 确保 `GET /chunks/{chunk_id}/children` 返回 ai_question 类型的子 chunks
- [x] T041 [P] [US6] 创建 `frontend/src/components/knowledge/AiQuestionTab.vue` — AI 问题生成配置组件: 数字框设置"AI生成问题数"(1-10, 默认3, 描述: "每个文档分块生成问题的数量...")
- [x] T042 [US6] 修改 `frontend/src/components/knowledge/DocumentCreateModal.vue` — 添加 "AI问题生成" tab 页，嵌入 AiQuestionTab 组件

**Checkpoint**: AI 问题正确生成，ai_question chunks 的 parent 关系正确，前端可查看

---

## Phase 9: User Story 7 — 压缩包批量上传 (Priority: P3)

**Goal**: 上传压缩包，系统解压后按文件类型自动应用默认分块策略，不支持的文件跳过并通知

**Independent Test**: 上传含 docx+xlsx+png+txt 的 zip 文件，验证各文件按默认策略处理，txt 被跳过并提示

### Implementation for User Story 7

- [x] T043 [US7] 修改 `KnowledgeManage/app/services/document_pipeline.py` — 添加压缩包文件类型判断: 每个文件按 extension 使用默认策略 (doc/docx/ppt/pptx/pdf/md → 按标题切分, xls/xlsx/csv → 表格行分片, 图片 → 图片chunk, 其他 → 跳过)
- [x] T044 [US7] 修改 `KnowledgeManage/app/services/document_service.py` — 压缩包上传时: (1) 不接收分块参数 (2) 将不支持的文件名记录到 Document 的 `skipped_files` 字段 (3) 上传响应中返回被跳过的文件列表
- [x] T045 [US7] 修改 `frontend/src/components/knowledge/DocumentCreateModal.vue` — 压缩包上传时隐藏"分块设置"和"AI问题生成"tab
- [x] T046 [US7] 修改 `frontend/src/components/knowledge/DocumentDetailDrawer.vue` — 处理完成后展示 skipped_files 提示（如果有文件被跳过）

**Checkpoint**: 压缩包中各类型文件正确分流，不支持文件被跳过并通知

---

## Phase 10: Polish & 跨切面关注点

**Purpose**: 前端分片展示完善、错误处理、进度展示

- [x] T047 [P] 创建 `frontend/src/components/knowledge/ChunkListPanel.vue` — 分片列表面板组件: 分页加载 chunks，按类型过滤，每个 chunk 渲染为 ChunkCard
- [x] T048 [P] 创建 `frontend/src/components/knowledge/ChunkCard.vue` — 分片卡片组件: (1) 展示 chunk_type 标签 (2) content 中的 `![](url)` 渲染为图片 (3) 使用 md-editor-v3 渲染 markdown 内容 (4) 右上角"AI问题"按钮查看子 ai_question chunks (5) 展示关联的 image_ocr/image_caption 子 chunks
- [x] T049 创建 `frontend/src/services/chunkApi.js` — Chunk API 封装: `getChunks(docId, params)`, `getChunkChildren(chunkId)`, `getTableData(chunkId, sql)`
- [x] T050 创建 `frontend/src/stores/chunk.js` — Chunk Pinia store: chunks 列表、分页、加载状态、当前选中 chunk 的子 chunks
- [x] T051 修改 `frontend/src/components/knowledge/DocumentDetailDrawer.vue` — 新增"文档分片"tab: (1) 嵌入 ChunkListPanel 组件 (2) 轮询 Document status 展示处理阶段（parsing/chunking/embedding/ai_generating/completed/failed） (3) failed 状态显示错误提示
- [x] T052 修改 `KnowledgeManage/app/services/document_pipeline.py` — 确保失败时完整清理: ES chunks + MinIO 中间文件 (markdown/图片/SQLite db)，参照 FR-039/FR-041
- [ ] T053 运行 `specs/010-doc-parse-chunk/quickstart.md` 中的验证场景 V1-V7

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，可立即开始
- **Foundational (Phase 2)**: 依赖 Setup 完成，**阻塞所有 User Stories**
- **US1 (Phase 3)**: 依赖 Foundational — 核心文档处理流水线
- **US2 (Phase 4)**: 依赖 US1 的 parsing_service 和 document_pipeline
- **US3 (Phase 5)**: 依赖 US1 的 chunking_service 和 document_pipeline
- **US4 (Phase 6)**: 依赖 US2 的 image_service
- **US5 (Phase 7)**: 依赖 US3 的 table_service
- **US6 (Phase 8)**: 依赖 US1 的 document_pipeline
- **US7 (Phase 9)**: 依赖 US1-US6 的各处理流程
- **Polish (Phase 10)**: 依赖所有 User Stories 完成

### User Story Dependencies

```
Setup → Foundational → US1 (MVP)
                          ├→ US2 (图片) ──→ US4 (独立图片)
                          ├→ US3 (表格) ──→ US5 (独立表格)
                          ├→ US6 (AI问题)
                          └→ US7 (压缩包, 依赖 US1-US6)
```

### Within Each User Story

- 后端 services 优先 (parsing → chunking → pipeline 集成)
- 后端 router 在 service 之后
- 前端组件可与后端并行开发（API 契约已定义）
- 每个 Story 完成后即可独立验证

### Parallel Opportunities

- T002/T003 (config files) 可并行
- T005/T006/T007 (ES client/model/schema) 可并行
- T013/T014/T015 (三大核心 service) 可并行
- T019/T021 (前端组件/API) 可并行
- T027/T028 (表格预处理/SQLite) 可并行
- T038/T041 (AI问题 service/前端) 可并行
- T047/T048/T049/T050 (前端 Polish 组件) 可并行

---

## Parallel Example: User Story 1

```
# 并行启动三大核心 service:
Task T013: chunking_service.py (分块策略)
Task T014: parsing_service.py (MinerU解析)
Task T015: embedding_service.py (向量生成)

# 并行启动前端:
Task T019: ChunkSettingTab.vue
Task T021: documentApi.js 更新
```

---

## Implementation Strategy

### MVP First (仅 User Story 1)

1. 完成 Phase 1: Setup
2. 完成 Phase 2: Foundational (**CRITICAL**)
3. 完成 Phase 3: US1 — 单文档上传与自定义分片
4. **STOP & VALIDATE**: 上传 PDF/DOCX 验证分片结果
5. 如就绪可部署/演示

### Incremental Delivery

1. Setup + Foundational → 基础就绪
2. + US1 → 文本文档分片 → **MVP 发布!**
3. + US2 + US3 → 图片/表格处理
4. + US4 + US5 → 独立图片/表格上传
5. + US6 → AI 问题生成
6. + US7 → 压缩包批量上传
7. Polish → 完善前端展示

### Suggested MVP Scope

**User Story 1** (单文档上传与自定义分片) 是核心 MVP，覆盖:
- 文档上传与存储
- MinerU 转换
- 按标题/固定长度分块
- Embedding 向量生成
- ES 存储与查询
- 前端分块设置 UI
- 处理状态展示

---

## Notes

- [P] = 不同文件无依赖，可并行执行
- [Story] 标签映射到 spec.md 中的 User Story
- 每个 User Story 应可独立完成和验证
- 提交频率: 每个 task 或逻辑组完成后 commit
- 失败处理: 遵循严格一致性 — 任一步骤失败则整体失败并清理
- 表格行原子性: 单行绝不从中间截断
