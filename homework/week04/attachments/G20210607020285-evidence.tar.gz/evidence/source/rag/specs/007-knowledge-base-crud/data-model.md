# Data Model: 知识库增删改查

## KnowledgeBase 实体

### 表名
`knowledge_bases`，schema: `knowledge_manage`

### 字段

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | String(36) | PK, UUID4 | 主键 |
| `name` | String(100) | NOT NULL | 知识库名称 |
| `description` | String(500) | NULLABLE | 描述 |
| `user_id` | String(36) | NOT NULL | 所属用户 ID |
| `llm_model_id` | String(36) | NOT NULL | LLM 模型 ID (category=chat) |
| `embedding_model_id` | String(36) | NOT NULL | Embedding 模型 ID (category=embedding) |
| `image_model_id` | String(36) | NOT NULL | 图片识别模型 ID (category=vision) |
| `rerank_model_id` | String(36) | NOT NULL | Rerank 模型 ID (category=rerank) |
| `created_at` | TIMESTAMP | NOT NULL, DEFAULT now() | 创建时间 |
| `updated_at` | TIMESTAMP | NOT NULL, DEFAULT now(), ON UPDATE | 更新时间 |

### 索引与约束

| 名称 | 类型 | 字段 | 说明 |
|------|------|------|------|
| `uq_kb_user_name` | UniqueConstraint | `(user_id, name)` | 同一用户名下知识库名称唯一 |
| `idx_kb_user` | Index | `user_id` | 加速用户维度查询 |

### 关联关系

```
KnowledgeBase.user_id → User.id (逻辑关联，无外键)
KnowledgeBase.llm_model_id → Model.id (逻辑关联，跨服务)
KnowledgeBase.embedding_model_id → Model.id (逻辑关联，跨服务)
KnowledgeBase.image_model_id → Model.id (逻辑关联，跨服务)
KnowledgeBase.rerank_model_id → Model.id (逻辑关联，跨服务)
```

> 注意：Model 数据存储在 LlmGateway 的 `llm_gateway` schema 中，KnowledgeBase 仅存储模型 ID，不建外键约束。显示时前端从 LlmGateway 获取模型名称。

## Pydantic Schemas

### KnowledgeBaseCreate
```python
name: str          # min_length=1, max_length=100, 必填
description: Optional[str]  # max_length=500, 选填
llm_model_id: str  # 必填
embedding_model_id: str  # 必填
image_model_id: str  # 必填
rerank_model_id: str  # 必填
```

### KnowledgeBaseUpdate
```python
name: Optional[str]          # min_length=1, max_length=100
description: Optional[str]   # max_length=500
llm_model_id: Optional[str]
embedding_model_id: Optional[str]
image_model_id: Optional[str]
rerank_model_id: Optional[str]
```

### KnowledgeBaseResponse
```python
id: str
name: str
description: Optional[str]
user_id: str
llm_model_id: str
embedding_model_id: str
image_model_id: str
rerank_model_id: str
created_at: datetime
updated_at: datetime
```

### PaginatedResponse[T]
```python
items: List[T]
total: int
page: int
page_size: int
```

## 前端数据流

```
┌─────────────────┐    fetchModels()     ┌──────────────┐
│  LlmGateway API  │ ◄────────────────── │ modelStore   │
│  /models          │                     │ (Pinia)      │
└─────────────────┘                     └──────┬───────┘
                                               │ models[] (按 category 过滤)
                                               ▼
┌─────────────────┐    CRUD operations   ┌──────────────┐
│  KnowledgeManage │ ◄────────────────── │ kbStore      │
│  /knowledge-bases │                     │ (Pinia)      │
└─────────────────┘                     └──────┬───────┘
                                               │ knowledgeBases[]
                                               ▼
                                        ┌──────────────┐
                                        │ Knowledge     │
                                        │ Management    │
                                        │ .vue          │
                                        └──────────────┘
```
