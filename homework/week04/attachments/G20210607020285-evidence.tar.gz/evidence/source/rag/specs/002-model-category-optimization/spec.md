# Feature Specification: 模型管理优化

**Feature Branch**: `002-model-category-optimization`

**Created**: 2026-10-28

**Status**: Draft

**Input**: User description: "模型管理优化PRD.md"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - 模型分类创建 (Priority: P1)

管理员在创建新模型时，需要选择模型的分类（对话模型、embedding 模型、ReRank 模型、视觉模型、语音模型），填写模型供应商（如 OpenAI、Anthropic）和显示名称，并使用 `context_tokens` 字段替代原来的 `max_tokens` 来设置上下文窗口大小。

**Why this priority**: 模型分类是整个优化的基础，所有后续的展示、筛选和会话中的模型选择都依赖分类信息。

**Independent Test**: 可以通过新建一个模型并验证所有新字段（分类、供应商、显示名称、context_tokens）被正确保存来独立测试。

**Acceptance Scenarios**:

1. **Given** 管理员在模型管理页面, **When** 点击"新建模型"并填写所有字段（包括选择分类为"对话模型"、供应商为"OpenAI"、显示名称为"GPT-4o"、context_tokens 为 128000）, **Then** 模型创建成功，新字段被正确保存
2. **Given** 管理员在模型管理页面, **When** 编辑已有模型并修改分类为"视觉模型", **Then** 模型分类更新成功，列表展示中该模型归属到"视觉模型"分类下
3. **Given** 管理员创建模型时未选择分类, **When** 提交表单, **Then** 系统提示分类为必填项
4. **Given** 管理员创建模型时, **When** 选择不同供应商, **Then** 供应商列表至少包含 OpenAI 和 Anthropic

---

### User Story 2 - 分类展示与筛选 (Priority: P2)

管理员在模型列表页面可以按模型分类查看模型，不同分类的模型分组或分标签展示，便于快速定位和管理。

**Why this priority**: 分类展示提升了模型管理的效率和体验，尤其在模型数量增多后，分类浏览比平铺列表更直观。

**Independent Test**: 可以通过在模型列表中切换到不同分类标签，验证每个分类下仅展示对应类型的模型。

**Acceptance Scenarios**:

1. **Given** 系统中存在多种分类的模型（如 3 个对话模型、2 个 embedding 模型）, **When** 管理员进入模型管理页面, **Then** 页面按分类标签（对话模型、embedding 模型、ReRank 模型、视觉模型、语音模型）分组展示，且默认激活"对话模型"标签页
2. **Given** 管理员在模型列表页面, **When** 点击"embedding 模型"分类标签, **Then** 仅展示分类为 embedding 的模型
3. **Given** 某个分类下没有模型, **When** 管理员切换到该分类标签, **Then** 展示空状态提示（如"暂无该分类模型"）
4. **Given** 管理员在模型列表页面, **When** 查看任意模型卡片, **Then** 可以看到该模型的分类、供应商和显示名称

---

### User Story 3 - 会话中选择分类模型 (Priority: P3)

用户在会话页面发送消息时，模型选择器按分类筛选模型，方便用户根据用途快速找到合适的模型（如对话选对话模型、图片理解选视觉模型）。

**Why this priority**: 分类筛选在会话场景中帮助用户更快找到目标模型，但不是核心功能——用户仍可通过完整列表选择。

**Independent Test**: 可以通过在会话页面的模型选择器中切换分类，验证下拉列表仅展示对应分类的模型。

**Acceptance Scenarios**:

1. **Given** 用户在会话页面, **When** 打开模型选择器, **Then** 模型按分类分组展示（对话模型、embedding 模型等）
2. **Given** 用户在会话页面, **When** 在模型选择器中筛选"视觉模型", **Then** 仅显示分类为视觉模型的选项
3. **Given** 用户在会话页面发送消息, **When** 选择一个对话模型, **Then** 系统使用该模型进行 SSE 流式对话

---

### Edge Cases

- 已有的旧模型（无分类字段）如何处理？——默认归为"对话模型"分类
- 模型供应商名称是否有预定义列表？——提供预设选项（OpenAI、Anthropic），但允许手动输入自定义供应商名称
- 字段重命名 `max_tokens` → `context_tokens` 后，已有数据如何迁移？——通过数据库迁移将列重命名，数据保持不变
- 某分类下所有模型被删除后，该分类标签是否仍显示？——仍显示，但内容为空状态

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: 系统 MUST 在模型创建和编辑时支持选择模型分类，分类包括：对话模型（chat）、embedding 模型（embedding）、ReRank 模型（rerank）、视觉模型（vision）、语音模型（speech）
- **FR-002**: 系统 MUST 在模型创建和编辑时支持填写模型供应商名称（如 OpenAI、Anthropic），提供预设选项并允许自定义输入
- **FR-003**: 系统 MUST 在模型创建和编辑时支持填写模型显示名称（display_name），用于在界面上友好展示模型
- **FR-004**: 系统 MUST 将原有的 `max_tokens`（上下文窗口）字段重命名为 `context_tokens`，语义和用途不变
- **FR-005**: 模型列表页面 MUST 按分类标签（tabs）分组展示模型，用户可切换不同分类查看对应模型；页面加载时默认激活"对话模型"标签页；每个分类内模型按创建时间倒序排列
- **FR-006**: 会话页面的模型选择器 MUST 支持按分类筛选或分组展示模型
- **FR-007**: 已有的无分类模型 MUST 默认归入"对话模型"分类
- **FR-008**: 模型卡片/列表项 MUST 展示模型的分类、供应商和显示名称信息
- **FR-009**: 模型分类和供应商字段 MUST 为必填项，显示名称为可选项（缺省时使用模型 name 字段展示）
- **FR-010**: 模型 name 字段 MUST 在同一供应商范围内唯一，不同供应商下允许存在相同 name

### Key Entities

- **Model（模型）**: 代表一个 LLM 模型配置。关键属性：name（API 模型标识，同一供应商下唯一）、display_name（显示名称）、category（分类）、provider（供应商）、context_tokens（上下文窗口大小）、url（API 端点）、api_key（加密存储）、rpm/tpm（速率限制）、价格字段

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 管理员可以在 2 分钟内完成一个包含分类、供应商、显示名称的新模型创建
- **SC-002**: 模型列表页面在切换分类标签时，100 个模型内切换响应时间不超过 1 秒
- **SC-003**: 已有模型在迁移后 100% 保留原有数据，并自动归入默认分类
- **SC-004**: 用户在会话中选择模型时，能通过分类筛选将可选模型数量缩小到目标范围

## Clarifications

### Session 2026-10-28

- Q: 模型列表页面的分类标签页默认应激活哪个分类？ → A: 默认选中"对话模型"标签页
- Q: 模型的 name 字段是否需要在系统内全局唯一？ → A: 同一供应商下唯一（不同供应商可有相同 name）
- Q: 分类标签页中模型的排列顺序是什么？ → A: 按创建时间倒序（最新的在前）

## Assumptions

- 模型分类为固定枚举值（对话、embedding、ReRank、视觉、语音），短期内不会新增分类类型
- 模型供应商以字符串存储，提供 OpenAI 和 Anthropic 作为预设选项，但不限制用户输入其他供应商名称
- `context_tokens` 字段与 `max_tokens` 语义完全相同，仅为重命名，不影响 LLM 调用逻辑
- 数据库迁移采用 Alembic，通过列重命名操作完成，不丢失已有数据
- 会话中的模型选择默认仅展示"对话模型"分类的模型（因为 SSE 对话场景使用对话模型），用户可手动切换到其他分类选择
- 显示名称为可选字段，当 display_name 为空时，前端使用 name 字段作为展示文本
