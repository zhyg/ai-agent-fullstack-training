# Implementation Plan: 智能体逻辑实现（三类智能体问答流程、工具运行时、停止与 Trace 展示）

**Branch**: `012-agent-logic-runtime` | **Date**: 2026-11-23 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/012-agent-logic-runtime/spec.md`

## Summary

将 KnowledgeManage 会话问答由"模型+提示词"直连模式升级为"知识库+智能体"驱动：在既有 `chat_service` 的后台生成 + Redis 取消/租约/跨实例流恢复骨架之上，新增基于 **langgraph StateGraph** 的三类智能体编排（快速问答单遍 / 推理行动多轮循环 / 规划推理自主规划+13 工具），所有模型调用经 httpx OpenAI 兼容客户端指向 LlmGateway（display_name 路由）；新建 ES 检索服务（BM25/kNN/RRF 混合，多库融合）与统一受控 Tool Runtime（请求级 plan、检索/rerank/压缩工具、sqlite 表格元数据与只读 SQL）；引用采用 cN 句柄 + 流式后处理展开；执行轨迹经 OpenTelemetry OTLP gRPC → Collector → ES `jaeger-span-YYYY-MM-DD`，`Message.trace_id` 关联，后端代理查询转换为 Jaeger UI 格式，前端移植 TraceViewer 三组件（时间线/详情/统计）到会话页右侧宽幅抽屉。停止复用既有 Pub/Sub 取消机制并扩展至循环与工具环节；断线经租约宽限后视同停止。

## Technical Context

**Language/Version**: 后端 Python 3.11（KnowledgeManage，conda myAiEnvNew）；前端 JavaScript ES2022 / Vue 3.5（frontend）

**Primary Dependencies**:
- 既有：FastAPI 0.115.6、SQLAlchemy 2.0.36、Pydantic 2.10.3、Alembic 1.14.0、httpx 0.28.1、redis 5.2.1、elasticsearch[async]≥8.0、minio 7.2.15、llama-index-core（已存在，本特性不强制使用）
- 新增（KnowledgeManage/requirements.txt）：`langgraph`（状态图编排）、`opentelemetry-sdk`、`opentelemetry-exporter-otlp-proto-grpc`（轨迹导出）、`tiktoken`（token 预算估算，cl100k_base 近似）
- 前端既有：ant-design-vue 4.2.6（Drawer/Modal/Select 等）、pinia 2.3.1、md-editor-v3（Markdown 渲染）、axios；无新增 npm 依赖（TraceViewer 组件为纯 Vue3 实现，移植为 JS）

**Storage**:
- PostgreSQL（schema 隔离，Alembic 迁移）：`chats` 增 agent_id/knowledge_base_ids 等字段；`messages` 增 trace_id/meta(JSONB)
- Elasticsearch：检索读 `knowledge_chunks_{kb_id}`（既有 mapping，含 dense_vector embeddings）；轨迹读 `jaeger-span-YYYY-MM-DD`（Collector 写入，只读代理查询）
- Redis：取消 Pub/Sub、生成事件 Stream、生成租约（复用既有键约定）
- MinIO：sqlite 表格文件下载（预签名）、图片预签名 URL（≥1 小时，默认 86400s）
- 本地文件系统：sqlite 下载缓存（地址哈希命名，TTL 清理）；plan 仅请求级内存，不落库

**Testing**: pytest（KnowledgeManage/tests，既有 asyncio 测试模式）；前端手工验证 + 既有 tests 目录脚本；契约验证以 quickstart.md 场景为准

**Target Platform**: Linux/macOS 服务端（uvicorn 8002）+ 现代浏览器 SPA；依赖 LlmGateway（OpenAI 兼容 /api/llm/v1/*）、OTel Collector（OTLP gRPC 4317）

**Project Type**: Web 应用（frontend SPA + KnowledgeManage FastAPI 后端，多服务仓库）

**Performance Goals**: SC-001 快速问答 90% 请求 15s 内首字流式输出；SC-005 停止后 3s 内终止且无新模型/工具调用；轨迹异步写入不阻塞主流程（BatchSpanProcessor + 结束时 force_flush）

**Constraints**:
- 所有模型调用必须经 LlmGateway display_name 路由，业务层不做传输层重试（JSON 校验业务重试最多 3 次，含首次共 4 次）
- token 预算 = 分析模型 context_tokens − max_output_tokens；超预算先截历史（默认 10 轮）再淘汰最早轮次片段，至少保留最新 1 条
- sqlExecute 仅只读 SELECT、sqlite_url 白名单限本次请求检索片段；工具串行执行；工具结果超限截断（默认 4000 tokens，可配）
- 问题非空 ≤2000 字符；知识库必选 ≥1；同会话上一轮未结束拒绝新提问
- 断线视同停止（经租约宽限窗口，默认 30s 内可重连续流，超时取消）；跨用户 trace 查询拒绝

**Scale/Scope**: 3 类智能体流程 + 13 个工具；后端新增 ~10 个模块（agent_runtime 包）、2 张表迁移、2 个新接口（trace 查询、引用 URL 刷新）+ 多个既有接口扩展；前端会话页改造 + 引用弹层 + trace 抽屉（3 个移植组件）；37 条 FR / 8 条 SC

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

`.specify/memory/constitution.md` 当前为**未填充的占位模板**（无已批准的原则条款），不存在可执行的门禁约束。

- **Pre-Phase 0 检查**: PASS（无门禁；遵循仓库既有惯例替代：schema 隔离 + Alembic 迁移、服务分层 routers/services/models/schemas、网关统一模型接入、pytest 覆盖新逻辑）
- **Post-Phase 1 复查**: PASS（设计未引入新服务/新存储引擎；复用既有 PG/ES/Redis/MinIO/Collector 基础设施；langgraph/otel 为进程内库依赖，不构成架构违例）

## Project Structure

### Documentation (this feature)

```text
specs/012-agent-logic-runtime/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command，含 FR-037 提示词推荐)
├── contracts/           # Phase 1 output (/speckit-plan command)
│   ├── chat-agent-api.md      # 会话/消息接口扩展 + SSE 事件协议
│   ├── trace-api.md           # 轨迹查询代理接口（Jaeger UI 格式）
│   └── tool-runtime.md        # 13 工具入参/出参契约 + 受控结果信封
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
KnowledgeManage/                          # 后端（Python 3.11 / FastAPI）
├── alembic/versions/
│   └── xxxx_agent_chat_trace.py          # 新增：chats/messages 字段迁移
├── app/
│   ├── core/
│   │   ├── config.py                     # 扩展：tracing / agent_runtime 配置段
│   │   └── es_client.py                  # 复用（索引 mapping 不改）
│   ├── models/
│   │   ├── chat.py                       # 扩展：agent_id、knowledge_base_ids、agent_type
│   │   └── message.py                    # 扩展：trace_id、meta(JSONB)
│   ├── schemas/
│   │   ├── chat.py                       # 扩展：ChatCreate/Update/Response、MessageResponse、trace 响应
│   │   └── agent_runtime.py              # 新增：SSE 事件、工具入参/结果、步骤输出 Pydantic 模型
│   ├── routers/
│   │   ├── chats.py                      # 扩展：agent 模式分支、trace 查询、引用 URL 刷新
│   │   └── agents.py                     # 微调：列表返回配置完整性标志（FR-002）
│   └── services/
│       ├── chat_service.py               # 扩展：agent 模式委托 agent_runtime；断线租约到期→取消；"[已停止]"标记
│       ├── agent_service.py              # 扩展：FR-020 保存期 max_output_tokens < context_tokens 校验
│       ├── retrieval_service.py          # 新增：BM25/kNN/RRF 混合检索，多库融合截断
│       ├── rerank_service.py             # 新增：网关 /v1/rerank 调用 + 失败降级
│       ├── trace_query_service.py        # 新增：按日期±1 查 jaeger-span 索引→Jaeger UI 格式
│       └── agent_runtime/                # 新增包：智能体编排核心
│           ├── __init__.py               # run_agent_generation 入口（对接 chat_service 后台 job）
│           ├── state.py                  # RequestRuntimeState / ContextChunk / Plan（内存态）
│           ├── snapshot.py               # 配置快照 + 开跑前全量预检（FR-003/004）
│           ├── llm_client.py             # 网关 OpenAI 兼容客户端（JSON 调用 + 流式），业务重试/JSON 容错
│           ├── steps.py                  # 澄清/重写/压缩/充足判断/答案生成共用步骤
│           ├── citation.py               # cN 句柄注入、<ref> 流式缓冲展开、图片预签名替换
│           ├── budget.py                 # tiktoken 估算、历史截断、片段淘汰（FR-019）
│           ├── tracing.py                # OTel TracerProvider、span 命名/属性、事件记录、force_flush
│           ├── flows/
│           │   ├── quick_qa.py           # langgraph：澄清→重写→检索→rerank→压缩→答案（单遍）
│           │   ├── reasoning_action.py   # langgraph：+充足判断循环、空转检测、强制收敛
│           │   └── planning_reasoning.py # langgraph：模型决策→工具执行→回传循环
│           └── tools/
│               ├── runtime.py            # 统一受控执行入口（校验/串行/取消/截断/trace 贯通）
│               ├── plan_tools.py         # createPlan/listPlan/getPlan/updatePlan/deletePlan
│               ├── knowledge_tools.py    # rewriteQuestion/bm25Search/vectorSearch/hybridSearch/rerank/zip
│               └── table_tools.py        # listTableMetaData/sqlExecute（下载缓存/只读校验/白名单）
└── tests/
    ├── test_agent_flows.py               # 新增：三类流程（mock 网关/ES）
    ├── test_tool_runtime.py              # 新增：入参校验/SQL 安全/白名单/截断/取消
    ├── test_retrieval_service.py         # 新增：三种检索 + RRF 融合
    ├── test_citation.py                  # 新增：流式 ref 缓冲/无效句柄/图片替换
    └── test_trace_query.py               # 新增：归属校验/日期容错/格式转换

frontend/                                 # 前端（Vue 3 + ant-design-vue + pinia）
├── src/
│   ├── views/ChatManagement.vue          # 改造：知识库多选+智能体选择替代模型+提示词；存量会话只读
│   ├── stores/chat.js                    # 扩展：agent/kb 选择、step 进度、references、stopped 标记
│   ├── services/
│   │   ├── chatApi.js                    # 扩展：SSE 新事件（step/references）、trace/刷新接口
│   │   └── traceApi.js                   # 新增：trace 查询代理调用
│   └── components/
│       ├── chat/                         # 扩展：引用标记渲染+弹层（查看文档链接）、步骤进度条、trace 按钮
│       └── trace/                        # 新增：TraceViewer 移植（JS 化）
│           ├── TraceDrawer.vue           # 右侧宽幅抽屉容器（a-drawer，不新增路由）
│           ├── TraceTimeline.vue         # 移植自 TraceViewer/src/components
│           ├── SpanDetail.vue            # 移植
│           └── StatisticsView.vue        # 移植

TraceViewer/                              # 只读参考，不改动
LlmGateway/                               # 不改动（复用 chat/embeddings/rerank 既有接口与传输层重试）
opentelemetryDemo/                        # 只读参考：OTLP gRPC 接入与 span 命名模式
```

**Structure Decision**: 沿用仓库既有多服务布局，不新建服务。后端全部落在 `KnowledgeManage/app/services/agent_runtime/` 新包 + 3 个新 service 模块，通过 `chat_service.send_message_stream` 的 agent 模式分支接入既有后台生成/取消/租约/流恢复骨架（旧"模型+提示词"路径原样保留，存量会话只读）。前端全部落在 `frontend/src/`（会话页改造 + chat 组件扩展 + trace 组件移植），trace 抽屉不新增路由。数据库变更走 Alembic 单迁移；ES/Redis/MinIO/Collector 复用既有基础设施与键/索引约定。

## Complexity Tracking

> 无 Constitution 违例（constitution 为未填充模板，无门禁），本节留空。

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| （无） | — | — |
