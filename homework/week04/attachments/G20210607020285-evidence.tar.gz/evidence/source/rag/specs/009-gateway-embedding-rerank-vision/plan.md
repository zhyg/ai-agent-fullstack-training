# Implementation Plan: LLM Gateway 支持 Embedding、Rerank、视觉模型

**Branch**: `009-gateway-embedding-rerank-vision` | **Date**: 2026-11-17 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `specs/009-gateway-embedding-rerank-vision/spec.md`
**Technical Design**: `mySpecs/010.llmgateway 支持embedding、rerank、视觉模型.md`

## Summary

扩展 LlmGateway 使其支持三类新能力：Embedding（文本向量化）、Rerank（搜索结果重排序）、Vision（图片理解）。核心思路是复用现有适配器模式与可观测性框架，新增 `/v1/embeddings` 和 `/v1/rerank` 两个端点，Vision 复用现有 Chat 链路仅扩展消息体格式。前端模型管理表单同步新增分类专属字段。

## Technical Context

**Language/Version**: Python 3.11

**Primary Dependencies**: FastAPI, Pydantic v2, SQLAlchemy, httpx, prometheus-client, alembic

**Storage**: PostgreSQL (schema 隔离), Redis (分布式限流)

**Testing**: pytest + httpx AsyncClient

**Target Platform**: Linux server (Docker 容器化部署)

**Project Type**: web-service (REST API 网关)

**Performance Goals**: Embedding 单条 <3s, 批量 100 条 <10s; Rerank 20 文档 <5s; Vision <15s

**Constraints**: 现有 Chat 接口 100% 向后兼容; Embedding/Rerank 仅同步非流式

**Scale/Scope**: 单服务 LlmGateway + 前端模型管理页面

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

本项目 constitution.md 为模板占位状态，无具体约束条款。Gate 自动通过。

## Project Structure

### Documentation (this feature)

```text
specs/009-gateway-embedding-rerank-vision/
├── plan.md              # 本文件
├── research.md          # Phase 0: 技术决策记录
├── data-model.md        # Phase 1: 数据模型定义
├── quickstart.md        # Phase 1: 验证指南
├── contracts/           # Phase 1: API 契约
│   ├── embedding-api.md
│   ├── rerank-api.md
│   └── vision-chat-api.md
└── tasks.md             # Phase 2 output (由 /speckit-tasks 生成)
```

### Source Code (repository root)

```text
LlmGateway/
├── app/
│   ├── adapters/
│   │   ├── base.py                          # 修改: ModelConfig 新增字段, BaseAdapter 新增 embed/rerank
│   │   ├── openai_adapter.py                # 修改: URL 重构 + embed() + Vision 消息处理
│   │   ├── anthropic_adapter.py             # 不变
│   │   └── cohere_rerank_adapter.py         # 新增: Cohere 兼容 Rerank 适配器
│   ├── core/
│   │   ├── config.py                        # 不变
│   │   ├── database.py                      # 不变
│   │   └── encryption.py                    # 不变
│   ├── gateway/
│   │   ├── errors.py                        # 不变
│   │   ├── json_repair.py                   # 不变
│   │   ├── observability.py                 # 修改: 指标新增 category 标签 + embedding/rerank 专属指标
│   │   ├── rate_limiter.py                  # 不变 (已有 check 方法可复用)
│   │   ├── registry.py                      # 修改: category 过滤 + 加载新字段
│   │   ├── retry.py                         # 不变
│   │   └── sse.py                           # 不变
│   ├── models/
│   │   └── model.py                         # 修改: 新增 dimensions, max_input_tokens, supported_modalities
│   ├── routers/
│   │   ├── models.py                        # 不变
│   │   ├── v1_chat.py                       # 修改: Vision 请求校验
│   │   ├── v1_embeddings.py                 # 新增: /v1/embeddings 端点
│   │   └── v1_rerank.py                     # 新增: /v1/rerank 端点
│   ├── schemas/
│   │   ├── chat_completion.py               # 修改: content 类型扩展为 Union[str, list[ContentPart]]
│   │   ├── embedding.py                     # 新增: Embedding 请求/响应 Schema
│   │   ├── model.py                         # 修改: ModelCreate/Update/Response 新增字段
│   │   └── rerank.py                        # 新增: Rerank 请求/响应 Schema
│   ├── services/
│   │   ├── llm_gateway_service.py           # 修改: 消息序列化 + process_embedding/rerank
│   │   └── model_service.py                 # 不变
│   ├── dependencies.py                      # 不变
│   └── main.py                              # 修改: 注册新 router + CohereRerankAdapter
├── alembic/
│   └── versions/
│       └── xxxx_add_multimodel_fields.py    # 新增: 数据库迁移
└── tests/
    ├── test_embedding_routes.py             # 新增
    ├── test_rerank_routes.py                # 新增
    └── test_vision_chat.py                  # 新增

frontend/ (MyKnowlegeWebDemo)
├── src/
│   ├── views/
│   │   └── ModelManage.vue                 # 修改: 表单新增分类专属字段
│   └── stores/
│       └── modelStore.js                    # 修改: 新增字段
```

**Structure Decision**: 复用现有单项目结构，新增文件遵循现有目录规范。

## Complexity Tracking

无 Constitution 违规项，此节留空。
