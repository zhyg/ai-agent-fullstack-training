# OpenAI Compatible API Contract

**Feature**: 004-llm-gateway-unified | **Base Path**: `/api/llm/v1`

## 认证

所有 `/v1` 端点使用 API Key Bearer Token 认证：

```
Authorization: Bearer [REDACTED_API_TOKEN]
```

Gateway 通过 API Key 调用 UserManage 服务获取用户身份（user_id, user_email）。

---

## POST /api/llm/v1/chat/completions

兼容 OpenAI Chat Completions API 的统一模型调用接口。

### 请求体

```json
{
  "model": "deepseek-v4-pro",
  "messages": [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "Hello"}
  ],
  "stream": false,
  "temperature": 0.7,
  "max_tokens": 4096,
  "response_format": {
    "type": "json_object",
    "schema": {
      "type": "object",
      "properties": {
        "answer": {"type": "string"}
      },
      "required": ["answer"]
    }
  },
  "prompt_name": "code-reviewer",
  "prompt_version": "1.0"
}
```

| 字段 | 类型 | 必填 | 说明                                     |
| ---- | ---- | ---- |----------------------------------------|
| model | string | 是 | 模型display_name名称，路由器据此到数据库中匹配provider供应商适配器    |
| messages | array | 是 | 消息列表，至少 1 条，每条含 role 和 content         |
| messages[].role | string | 是 | 枚举：`system` / `user` / `assistant`     |
| messages[].content | string | 是 | 消息内容                                   |
| stream | boolean | 否 | 默认 `false`，`true` 时以 SSE 格式流式返回        |
| temperature | number | 否 | 采样温度，默认 1.0                            |
| max_tokens | integer | 否 | 最大输出 token 数                           |
| response_format | object | 否 | 结构化输出约束                                |
| response_format.type | string | 否 | 枚举：`text`（默认）/ `json_object`           |
| response_format.schema | object | 否 | JSON Schema 定义（当 type=json_object 时有效） |
| prompt_name | string | 否 | 提示词模板名称                                |
| prompt_version | string | 否 | 提示词模板版本（prompt_name 存在时必填）             |

知识管理聊天调用会根据会话的 `prompt_id` 查询提示词，将对应的名称和版本作为
`prompt_name`、`prompt_version` 传入；未选择提示词时不传这两个字段。
已选择的提示词不存在时返回错误，不会静默忽略提示词继续调用模型。

Gateway 的 Prometheus 指标（请求数、token、延迟、成本、重试及保留的 fallback 指标）
均携带 `prompt_name`、`prompt_version` 标签，未使用提示词时标签值为空字符串。
提示词由 Gateway 按名称和版本解析并应用，无需在聊天消息中重复插入模板。
按名称和版本区分指标会增加时间序列数量，监控查询和面板需兼容新增标签。

### 响应（非流式，stream=false）

**成功 200**:

```json
{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1699999999,
  "model": "deepseek-v4-pro",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "Hello! How can I help you?"
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 12,
    "completion_tokens": 8,
    "total_tokens": 20,
    "cached_tokens": 0,
    "reasoning_tokens": 0
  }
}
```

### 响应（流式，stream=true）

**成功 200** — `Content-Type: text/event-stream`:

```
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1699999999,"model":"deepseek-v4-pro","choices":[{"index":0,"delta":{"role":"assistant","content":"Hello"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1699999999,"model":"deepseek-v4-pro","choices":[{"index":0,"delta":{"content":"!"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1699999999,"model":"deepseek-v4-pro","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":12,"completion_tokens":2,"total_tokens":14,"cached_tokens":0,"reasoning_tokens":0}}

data: [DONE]
```

SSE 事件类型:
- `delta`: 内容片段，含部分文本
- 最终 chunk: `finish_reason` 为 `stop`/`error`/`cancelled`，携带 `usage` 字段
- `[DONE]`: 流结束标记

### 错误响应

**401 Unauthorized** — API Key 无效或缺失:
```json
{
  "error": {
    "message": "Invalid API key",
    "type": "authentication_error",
    "code": "invalid_api_key"
  }
}
```

**404 Not Found** — 模型不存在:
```json
{
  "error": {
    "message": "Model 'xxx' not found",
    "type": "invalid_request_error",
    "code": "model_not_found"
  }
}
```

**422 Unprocessable Entity** — 请求参数无效:
```json
{
  "error": {
    "message": "Invalid request body: messages must not be empty",
    "type": "invalid_request_error",
    "code": "invalid_request"
  }
}
```

**429 Too Many Requests** — 超过限流:
```json
{
  "error": {
    "message": "Rate limit exceeded for model 'deepseek-v4-pro'. RPM: 100/100",
    "type": "rate_limit_error",
    "code": "rate_limit_exceeded"
  }
}
```

**502 Bad Gateway** — 供应商不可用:
```json
{
  "error": {
    "message": "All adapters unavailable for required capabilities",
    "type": "service_error",
    "code": "adapter_unavailable"
  }
}
```

**503 Service Unavailable** — 模板服务不可用:
```json
{
  "error": {
    "message": "Prompt template service unavailable",
    "type": "service_error",
    "code": "prompt_service_unavailable"
  }
}
```

**422 Unprocessable Entity** — JSON Schema 校验失败（修复耗尽后）:
```json
{
  "error": {
    "message": "Structured output validation failed after 3 repair attempts",
    "type": "validation_error",
    "code": "schema_validation_failed",
    "raw_output": "..."
  }
}
```

### 统一错误码

| HTTP 状态码 | error.code | 说明 | 可重试 |
| ----------- | ---------- | ---- | ------ |
| 401 | invalid_api_key | API Key 无效 | 否 |
| 403 | permission_denied | 无权限 | 否 |
| 404 | model_not_found | 模型不存在 | 否 |
| 422 | invalid_request | 请求参数无效 | 否 |
| 422 | prompt_not_found | 提示词模板不存在 | 否 |
| 422 | schema_validation_failed | JSON Schema 校验失败 | 否 |
| 429 | rate_limit_exceeded | 超过限流 | 是 |
| 502 | adapter_unavailable | 所有适配器不可用 | 是 |
| 502 | upstream_error | 供应商返回错误 | 是（有限） |
| 503 | prompt_service_unavailable | 模板服务不可用 | 是 |
| 504 | upstream_timeout | 供应商超时 | 是（有限） |
