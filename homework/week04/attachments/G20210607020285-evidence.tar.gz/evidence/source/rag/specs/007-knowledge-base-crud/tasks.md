# Tasks: 知识库增删改查

**Input**: Design documents from `specs/007-knowledge-base-crud/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/knowledge-base-api.md, quickstart.md

**Tests**: 未在规格中明确要求，跳过测试任务。

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup (项目初始化)

**Purpose**: 数据库迁移，建立 KnowledgeBase 表

- [X] T001 创建 Alembic 迁移脚本，在 `knowledge_manage` schema 下建立 `knowledge_bases` 表，字段包括：id (String(36) PK), name (String(100) NOT NULL), description (String(500) NULLABLE), user_id (String(36) NOT NULL), llm_model_id (String(36) NOT NULL), embedding_model_id (String(36) NOT NULL), image_model_id (String(36) NOT NULL), rerank_model_id (String(36) NOT NULL), created_at (TIMESTAMP NOT NULL), updated_at (TIMESTAMP NOT NULL)；索引 `idx_kb_user` on `user_id`；唯一约束 `uq_kb_user_name` on `(user_id, name)` in `KnowledgeManage/alembic/versions/xxx_create_knowledge_bases.py`
- [X] T002 执行迁移 `cd KnowledgeManage && alembic upgrade head`，确认 `knowledge_bases` 表已创建

---

## Phase 2: Foundational (阻塞性基础设施)

**Purpose**: 后端 ORM 模型、Pydantic Schema、CRUD Service、API Router — 所有用户故事依赖此阶段

**⚠️ CRITICAL**: 所有用户故事必须等待此阶段完成

- [X] T003 [P] 创建 KnowledgeBase ORM 模型，包含 `__tablename__ = "knowledge_bases"`、`__table_args__` 中设置 `UniqueConstraint('user_id', 'name', name='uq_kb_user_name')` 和 `Index("idx_kb_user", "user_id")`，schema 使用 `settings.database.db_schema`，参照 Chat 模型模式 in `KnowledgeManage/app/models/knowledge_base.py`
- [X] T004 [P] 创建 Pydantic Schemas：`KnowledgeBaseCreate`（name: str min_length=1 max_length=100, description: Optional[str] max_length=500, llm_model_id/embedding_model_id/image_model_id/rerank_model_id: str 均必填）、`KnowledgeBaseUpdate`（所有字段 Optional）、`KnowledgeBaseResponse`（ConfigDict from_attributes=True, 含 id/user_id/created_at/updated_at）、复用已有 `PaginatedResponse[T]` in `KnowledgeManage/app/schemas/knowledge_base.py`
- [X] T005 创建 CRUD Service，实现 `list_knowledge_bases(db, user_id, page, page_size)` 按 `updated_at desc` 排序、`create_knowledge_base(db, user_id, data)` 含名称唯一性预检查（查 `user_id + name` 是否已存在，存在则 raise ValueError("该名称已存在")）、`update_knowledge_base(db, kb_id, user_id, data)` 含唯一性预检查排除自身、`delete_knowledge_base(db, kb_id, user_id)`、`get_knowledge_base(db, kb_id, user_id)` 验证所有权 in `KnowledgeManage/app/services/knowledge_base_service.py`
- [X] T006 创建 API Router `prefix="/knowledge-bases"` tags=["知识库管理"]，实现 GET "" (分页列表)、POST "" (创建, 201)、PUT "/{kb_id}" (更新)、DELETE "/{kb_id}" (删除)，所有端点使用 `Depends(get_current_user)` 认证，ValueError 捕获后返回 409，不存在返回 404 in `KnowledgeManage/app/routers/knowledge_bases.py`
- [X] T007 在 main.py 中注册知识库 router：`app.include_router(knowledge_bases.router, prefix="/api/knowledge")` in `KnowledgeManage/app/main.py`

**Checkpoint**: 后端 API 可用，可通过 curl 测试 CRUD 操作

---

## Phase 3: US1 知识库列表 + US2 新建知识库 (Priority: P1) 🎯 MVP

**Goal**: 前端展示知识库卡片列表（含空状态），通过弹窗创建新知识库，模型选择器按类型过滤

**Independent Test**: 进入 `/knowledge` 页面看到空状态或卡片列表，点击"新建知识库"填写表单后创建成功

### Implementation for US1 + US2

- [X] T008 [P] [US1] 创建 API 客户端，参照 chatApi.js 模式，baseURL 使用 `VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'`，实现 `listKnowledgeBases(page, pageSize)` GET /knowledge-bases、`createKnowledgeBase(data)` POST /knowledge-bases、`updateKnowledgeBase(kbId, data)` PUT /knowledge-bases/{kbId}、`deleteKnowledgeBase(kbId)` DELETE /knowledge-bases/{kbId}，含 JWT 拦截器和 401 处理 in `frontend/src/services/knowledgeBaseApi.js`
- [X] T009 [P] [US1] 创建 Pinia Store `defineStore('knowledgeBase', ...)`，包含 `knowledgeBases` ref、`total` ref、`loading` ref、`fetchKnowledgeBases(page, ps)` 调用 API 获取列表、`createKb(data)` 调用 API 后刷新列表并返回 `{success, message}`、`updateKb(kbId, data)` 同理、`deleteKb(kbId)` 同理，错误处理使用 `extractErrorMessage` in `frontend/src/stores/knowledgeBase.js`
- [X] T010 [P] [US1] 创建空状态组件 EmptyKb，显示数据库图标 + "暂无知识库" + "新建知识库"按钮，emit `create` 事件，样式参照 MyKnowlegeWebDemo 的 EmptyKb.vue in `frontend/src/components/knowledge-base/EmptyKb.vue`
- [X] T011 [P] [US1] 创建 KbCard 卡片组件，props: `kb` (Object required) + `models` (Array required)；显示 DatabaseOutlined 图标、名称、描述、创建时间、四个模型标签（LLM/Embedding/图片识别/Rerank，通过 `models.find(m => m.id === kb.xxxModelId)` 获取名称，不存在显示"(已删除)"）、设置按钮 (EditOutlined) + 删除按钮 (DeleteOutlined)；整卡可点击进入 (emit `enter`)；操作按钮 `@click.stop` 阻止冒泡；emit `edit` 和 `delete` 事件；样式参照 MyKnowlegeWebDemo 的 KbCard.vue in `frontend/src/components/knowledge-base/KbCard.vue`
- [X] T012 [P] [US1] 创建 KbList 列表容器组件，props: `knowledgeBases` (Array) + `models` (Array)；标题栏"知识库管理" + "新建知识库"按钮；空列表时显示 EmptyKb，非空时渲染 KbCard 列表；emit `create`/`enter`/`edit`/`delete` 事件 in `frontend/src/components/knowledge-base/KbList.vue`
- [X] T013 [P] [US2] 创建 KbCreateModal 新建弹窗组件，props: `visible` (Boolean) + `models` (Array)；表单字段：名称 (a-input, required)、描述 (a-textarea, optional)、LLM 模型 (a-select, 过滤 `models.filter(m => m.category === 'chat')`)、Embedding 模型 (过滤 `category === 'embedding'`)、图片识别模型 (过滤 `category === 'vision'`)、Rerank 模型 (过滤 `category === 'rerank'`)；无模型时 placeholder 显示"请先创建模型"且禁用选择器和确认按钮；表单校验规则 name/四个模型 ID 均 required；visible 变 true 时重置表单；emit `close` + `submit` in `frontend/src/components/knowledge-base/KbCreateModal.vue`
- [X] T014 [US1] [US2] 重写 KnowledgeManagement.vue 页面容器：onMounted 时调用 `kbStore.fetchKnowledgeBases(1, 1000)` 和 `modelStore.fetchModels(1, 1000)`；组合 KbList + KbCreateModal；管理 `createModalVisible` 状态；实现 `handleCreateSubmit` (调用 `kbStore.createKb`，成功后 message.success + 关闭弹窗)、`handleDelete` (Modal.confirm 二次确认后调用 `kbStore.deleteKb`)、`handleEnter` (router.push 占位) in `frontend/src/views/KnowledgeManagement.vue`

**Checkpoint**: 知识库列表可展示，新建知识库功能可用，模型选择器按类型过滤

---

## Phase 4: US3 编辑知识库 + US4 删除知识库 (Priority: P2)

**Goal**: 通过抽屉编辑知识库配置（名称/描述/模型），通过确认对话框删除知识库

**Independent Test**: 点击"设置"编辑知识库配置后保存成功，点击"删除"经确认后知识库被移除

### Implementation for US3 + US4

- [X] T015 [US3] 创建 KbFormDrawer 编辑抽屉组件，props: `visible` (Boolean) + `kb` (Object) + `models` (Array)；标题"设置知识库"，宽度 480px；表单字段同 KbCreateModal（名称必填、描述选填、四个模型选择器按 category 过滤且必填）；visible 变 true 且 kb 非空时预填 `kb.name`/`kb.description`/`kb.llmModelId`/`kb.embeddingModelId`/`kb.imageModelId`/`kb.rerankModelId`；emit `close` + `submit`；样式参照 MyKnowlegeWebDemo 的 KbFormDrawer.vue in `frontend/src/components/knowledge-base/KbFormDrawer.vue`
- [X] T016 [US3] 在 KnowledgeManagement.vue 中集成 KbFormDrawer：导入组件并在模板中渲染，传递 `drawerVisible`/`editingKb`/`modelStore.models`；实现 `openEditDrawer(kb)` 设置编辑数据并打开抽屉、`handleEditSubmit(data)` 调用 `kbStore.updateKb(editingKb.id, data)` 成功后 message.success + 关闭抽屉 in `frontend/src/views/KnowledgeManagement.vue`
- [X] T017 [US4] 确认 KnowledgeManagement.vue 中 `handleDelete` 已正确实现：Modal.confirm 二次确认、调用 `kbStore.deleteKb(kb.id)`、成功后 message.success；错误时 message.error in `frontend/src/views/KnowledgeManagement.vue`

**Checkpoint**: 编辑和删除功能完整可用

---

## Phase 5: US5 进入知识库 (Priority: P3)

**Goal**: 点击知识库卡片导航进入知识库详情页面（当前为占位）

**Independent Test**: 点击卡片（非按钮区域）后页面跳转到知识库详情占位页

### Implementation for US5

- [X] T018 [US5] 在 KnowledgeManagement.vue 中完善 `handleEnter(kb)` 函数：当前阶段保持当前页面或 `router.push('/knowledge')`（占位跳转，后续迭代完善）；确保 KbCard 的整卡点击事件通过 `@click` 触发 `handleEnter`，操作按钮 `@click.stop` 不冒泡 in `frontend/src/views/KnowledgeManagement.vue`

**Checkpoint**: 点击卡片可导航，所有 5 个用户故事均已完成

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: 构建验证、回归测试

- [X] T019 运行前端构建验证：`cd frontend && npm run build`，确认无编译错误
- [ ] T020 按 quickstart.md 执行 V-001 至 V-009 验证场景（需启动后端和前端开发服务器）

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，首先执行数据库迁移
- **Foundational (Phase 2)**: 依赖 Setup 完成，阻塞所有用户故事
- **US1+US2 (Phase 3)**: 依赖 Foundational 完成，含列表和新建功能
- **US3+US4 (Phase 4)**: 依赖 Phase 3 完成（共享 KnowledgeManagement.vue 页面）
- **US5 (Phase 5)**: 依赖 Phase 3 完成（依赖 KbCard 整卡点击）
- **Polish (Phase 6)**: 依赖所有用户故事完成

### User Story Dependencies

- **US1 列表 + US2 新建 (P1)**: Phase 2 完成后可开始，MVP 范围
- **US3 编辑 + US4 删除 (P2)**: 依赖 US1+US2 页面框架
- **US5 进入知识库 (P3)**: 依赖 US1 卡片组件

### Within Each User Story

- API 客户端和 Store 可并行（不同文件）
- UI 子组件可并行（KbCard / KbList / KbCreateModal / EmptyKb）
- 页面容器 KnowledgeManagement.vue 最后编写（依赖所有子组件）

### Parallel Opportunities

- T003 和 T004 可并行（不同文件）
- T008 和 T009 可并行（不同文件）
- T010 / T011 / T012 / T013 可并行（四个独立组件文件）

---

## Parallel Example: Phase 3 US1 + US2

```bash
# 并行创建 API 客户端和 Store：
Task T008: "创建 API 客户端 in frontend/src/services/knowledgeBaseApi.js"
Task T009: "创建 Pinia Store in frontend/src/stores/knowledgeBase.js"

# 并行创建 UI 子组件：
Task T010: "创建 EmptyKb in frontend/src/components/knowledge-base/EmptyKb.vue"
Task T011: "创建 KbCard in frontend/src/components/knowledge-base/KbCard.vue"
Task T012: "创建 KbList in frontend/src/components/knowledge-base/KbList.vue"
Task T013: "创建 KbCreateModal in frontend/src/components/knowledge-base/KbCreateModal.vue"
```

---

## Implementation Strategy

### MVP First (US1 列表 + US2 新建)

1. Complete Phase 1: Setup（数据库迁移）
2. Complete Phase 2: Foundational（后端 CRUD API）
3. Complete Phase 3: US1 + US2（前端列表 + 新建）
4. **STOP and VALIDATE**: 按 quickstart V-001 ~ V-004 验证
5. Deploy/demo if ready

### Incremental Delivery

1. Setup + Foundational → 后端 API 可用
2. US1 + US2 → 列表 + 新建 → 验证 → MVP!
3. US3 + US4 → 编辑 + 删除 → 完整 CRUD
4. US5 → 进入知识库 → 全部完成
5. Polish → 构建验证

---

## Notes

- [P] tasks = 不同文件，无依赖，可并行执行
- [Story] label 映射到 spec.md 中的用户故事
- 所有 UI 组件参考 MyKnowlegeWebDemo 中的同名组件实现
- 模型选择器按 LlmGateway 的 `category` 字段过滤：chat→LLM, embedding→Embedding, vision→图片识别, rerank→Rerank
- 名称唯一性由后端 `(user_id, name)` 唯一约束 + 业务层预检查双重保障
