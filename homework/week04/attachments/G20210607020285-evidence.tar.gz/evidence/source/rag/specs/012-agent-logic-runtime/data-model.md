# Phase 1 Data Model: 智能体逻辑实现

**Feature**: 012-agent-logic-runtime | **Date**: 2026-11-23

依据 [spec.md](./spec.md) Key Entities 与 [research.md](./research.md) R6/R11/R13/R14 决策。分为**持久化实体**（PostgreSQL，Alembic 迁移）与**请求级内存实体**（不落库）两类。轨迹数据复用既有 ES `jaeger-span-YYYY-MM-DD` 存储，不新建表。

---

## 1. 持久化实体（PostgreSQL，schema = knowledge_manage）

### 1.1 Chat（既有表 `chats`，扩展）

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| id / title / user_id / status / generation_id / lease_owner / lease_expires_at / created_at / updated_at | — | 不变 | 既有字段全部保留 |
| model_id / model_name / prompt_id | — | 不变（nullable） | 旧模式字段保留，存量会话只读展示（FR-002） |
| **agent_id** | String(36) | nullable | 新增；关联 `agents.id`；NULL = 存量旧模式会话 |
| **agent_type** | String(30) | nullable | 新增；冗余快照 `quick_qa` / `reasoning_action` / `planning_reasoning`，便于列表展示与分支 |
| **knowledge_base_ids** | JSONB | nullable，默认 `[]` | 新增；所选知识库 id 列表（多选） |

**校验规则**：
- agent 模式提问前置：`knowledge_base_ids` 非空且全部属于当前用户（FR-001/005）；`agent_id` 指向启用且配置完整的智能体（FR-002/003）
- `agent_id` 非空时忽略 model_id/model_name/prompt_id（新模式不使用）
- 存量会话（agent_id IS NULL）：只读，不可按新模式续问；不可切换为 agent 模式（前端不提供入口，后端拒绝）

**状态机**（复用既有）：`idle → generating → completed | cancelled`；同会话 generating 且租约有效时新提问 409（FR-032）。

### 1.2 Message（既有表 `messages`，扩展）

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| id / chat_id / role / content / created_at | — | 不变 | role: user / assistant / system |
| **trace_id** | String(32) | nullable，index | 新增；OTel 128bit hex；同轮 user 与 assistant 消息写同一值（FR-034） |
| **meta** | JSONB | nullable | 新增；结构见下 |

**assistant 消息 meta 结构**：

```json
{
  "stopped": true,                      // 停止标记（content 尾部另附 "\n[已停止]"）
  "terminate_reason": "empty_retrieval | clarify_failed | forced_convergence | error | null",
  "references": [                       // 引用映射，回放弹层数据源（FR-013）
    {
      "handle": "c1",
      "chunk_id": "...",
      "document_id": "...",
      "kb_id": "...",
      "file_name": "产品手册.pdf",
      "content": "片段原文（图片已替换为预签名 URL）",
      "image_paths": ["minio/object/path.png"],   // 原始路径，供 refresh-urls 重签
      "score": 0.87
    }
  ],
  "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
  "error_code": "json_validation_failed | embedding_failed | config_invalid | ...",
  "raw_output": "模型原始输出（仅 JSON 校验最终失败时）",
  "forced_convergence": false
}
```

**user 消息 meta**：`{"question": "原始问题"}`（可选，content 已含问题；预留）。

**校验规则**：
- 澄清不通过：reason 作为 assistant 消息落库，`terminate_reason="clarify_failed"`（FR-006）
- 快速问答空检索：assistant 消息 content="检索结果为空…"，`terminate_reason="empty_retrieval"`（FR-016）
- 停止：部分 content + `"\n[已停止]"`，`stopped=true`（FR-031）
- trace_id 在生成开始（根 span 创建）后即写入 user 消息行；assistant 行落库时写入

### 1.3 既有依赖实体（只读，不改）

| 实体 | 表 | 本特性用途 |
|---|---|---|
| Agent | `agents`（config JSONB） | 快照来源：prompts 用途映射、models、retrieval、loop_count、tools、max_output_tokens；`agent_service` 仅新增 FR-020 保存校验 |
| Prompt | `prompts` | 预检存在性 + 冻结内容进快照 |
| KnowledgeBase | `knowledge_bases` | 归属校验（user_id）；ES 索引名推导 `knowledge_chunks_{kb_id}` |
| Model（跨 schema `llm_gateway.models`） | 只读 SQL | resolve `{COALESCE(display_name,name), context_tokens, category}`；无启用字段，存在即启用（R3） |

---

## 2. 请求级内存实体（`agent_runtime/state.py`，请求结束/停止即丢弃）

### 2.1 AgentConfigSnapshot（配置快照，FR-004）

| 字段 | 类型 | 说明 |
|---|---|---|
| agent_id / agent_type | str | 来源智能体 |
| prompts | dict[purpose, PromptSnapshot] | 各用途提示词冻结内容 `{prompt_id, name, version, content}`；purpose 按类型：clarify/rewrite/answer/compress（+sufficiency | +planning） |
| analysis_model / embedding_model / rerank_model | ModelRef | `{model_id, name(display_name), context_tokens}`；embedding 恒必需，rerank 视配置 |
| retrieval | RetrievalConfig | mode / vector_top_k / keyword_top_k / hybrid_top_k（1–100，默认 20）/ rerank_top_n（默认 15） |
| loop_count | int | 推理行动默认 10、规划推理默认 100，范围 1–1000 |
| tools | list[str] | 启用工具键（13 工具子集；仅 planning_reasoning 使用） |
| max_output_tokens | int | 默认 5000，范围 1–50000；保存期校验 < context_tokens（FR-020） |
| kb_ids | list[str] | 本次请求知识库（已过归属校验） |

**生成规则**：开跑前一次性构建（`snapshot.py`），全量预检失败即 SSE error 终止；构建后运行期不再读配置表。

### 2.2 RequestRuntimeState（问答请求运行态）

| 字段 | 类型 | 说明 |
|---|---|---|
| generation_id / chat_id / user_id / trace_id | str | 关联既有生成 job 与根 span |
| snapshot | AgentConfigSnapshot | 冻结配置 |
| question / current_question | str | 原始问题 / 当前轮重写问题 |
| loop | int | 当前循环轮次（计数口径见 FR-018/028） |
| chunks | OrderedDict[chunk_id, ContextChunk] | 去重累积，保留首次出现顺序（FR-019） |
| handle_map | dict[cN, chunk_id] | 引用句柄映射，cN 从 1 递增，答案生成前冻结 |
| plan | Plan \| None | 仅 planning_reasoning |
| sqlite_whitelist | set[str] | 本次请求检索片段出现过的 sqlite_url（FR-027 白名单） |
| history | list[Message] | 截取后的会话历史（默认最近 10 轮） |
| cancel_event | asyncio.Event | 取消信号（对接 Redis Pub/Sub 订阅） |
| messages_for_model | list[dict] | 规划推理的 OpenAI 消息累积（含 tool 消息） |
| events | list[dict] | 降级/收敛等事件（同步写 span event） |
| partial_answer | str | 已流式输出的部分答案（停止时落库） |

**状态转移**：`preflight → clarify → (rewrite → retrieve → rerank → compress → [sufficiency])* → answer → finalize`；任一检查点 cancel → finalize(stopped)；流程级异常 → finalize(error)。

### 2.3 ContextChunk（上下文片段）

| 字段 | 类型 | 说明 |
|---|---|---|
| chunk_id / document_id / kb_id / file_name | str | 来源标识（压缩后补充文档名，FR-010） |
| content | str | 片段内容（图片路径已替换预签名 URL） |
| chunk_type | str | text / table / image 等（既有索引字段） |
| sqlite_url | str \| None | 表格片段的对象存储地址 |
| score | float | 检索/rerank 分数 |
| first_loop | int | 首次出现轮次（淘汰依据：最早轮次先淘汰，至少保留最新 1 条） |
| handle | str \| None | cN 句柄（答案生成前分配） |

**去重规则**：按 chunk_id 去重，保留首次出现顺序与 first_loop（FR-019）。

### 2.4 Plan（计划，仅内存，FR-024）

| 字段 | 类型 | 说明 |
|---|---|---|
| plan_id | str(uuid) | 请求内唯一 |
| title / steps | str / list[PlanStep] | PlanStep: `{step_id, description, status: pending|in_progress|done}` |
| created_at / updated_at | datetime | 审计（trace 记录） |

**生命周期**：createPlan 创建 → list/get/update/delete 操作仅限本请求 state.plan → 请求结束/停止随 state 丢弃；不建表不落库。

### 2.5 ToolCallRecord（工具调用记录，FR-029）

| 字段 | 类型 | 说明 |
|---|---|---|
| call_id | str | 模型输出的 tool_call id，调用→执行→结果→trace 全程一致 |
| tool_name | str | 13 工具键之一 |
| args | dict | 模型入参（Pydantic 校验前原文也记 trace） |
| result | ToolResult | `{success: bool, code: str, content: str, artifact_path?: str}` |
| started_at / duration_ms | — | 写入 `agent.tool.{name}` span |

**结果码约定**：`ok` / `empty_result` / `invalid_args` / `execution_failed` / `forbidden_sql` / `url_not_allowed` / `cancelled` / `truncated`（截断附说明时 code 仍 ok，content 附"结果已截断，共 N 条"）。

---

## 3. 轨迹数据（既有 ES 存储，只读消费）

### 3.1 Span（ES `jaeger-span-YYYY-MM-DD`，Collector 写入）

本特性产出的 span 树约定（R11）：

```text
agent.run                          # 根；trace_id 落库 Message.trace_id
├── agent.preflight                # 配置预检
├── agent.clarify                  # 澄清（模型调用）
├── agent.rewrite        (loop=N)  # 重写
├── agent.retrieve.{mode}(loop=N)  # bm25 | vector | hybrid
├── agent.rerank         (loop=N)  # 含 rerank_degraded 事件
├── agent.compress       (loop=N)
├── agent.sufficiency    (loop=N)  # 仅推理行动
├── agent.plan_decision  (loop=N)  # 仅规划推理；模型决策调用（function calling），每次计一轮
├── agent.tool.{name}              # 仅规划推理；属性 tool.call_id
│   └── agent.rewrite / agent.compress 等  # 工具内模型调用（rewriteQuestion/zip）按对应步骤名产生子 span
└── agent.answer                   # 答案生成；invalid_ref_dropped 事件
```

规划推理每次模型决策调用产生 `agent.plan_decision` span（与 SSE step 事件的 plan_decision 对应）；工具内部的模型调用在 `agent.tool.{name}` 下按对应步骤名产生子 span，确保 FR-033"每次模型调用入轨迹"无遗漏。

关键属性：`agent.input` / `agent.output`（JSON 字符串，≤32KB 截断）、`agent.loop`、`tool.call_id`、`gen_ai.request.model`、`enduser.id`、`session.id`；事件：`rerank_degraded`、`forced_convergence`、`idle_loop_converged`、`invalid_ref_dropped`。

### 3.2 Message-Trace 关联

`Message.trace_id` ↔ ES `traceID` 字段；查询按 `message.created_at` 日期 ±1 天定位索引（FR-036）。无独立关联表。

---

## 4. 迁移与兼容

- 单个 Alembic 迁移（knowledge_manage schema）：`chats` +3 列、`messages` +2 列（含 trace_id 索引）；全部 nullable，无数据回填，存量行为不变
-  downgrade：删除新增列与索引
- ES/Redis/MinIO 无 schema 变更；`config.{env}.yaml` 新增 `tracing` / `agent_runtime` 段（见 R17 默认值）