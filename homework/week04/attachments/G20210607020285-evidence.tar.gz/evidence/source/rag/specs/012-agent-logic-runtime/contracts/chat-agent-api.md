# Contract: 会话/消息接口扩展与 SSE 事件协议

**Feature**: 012-agent-logic-runtime | 服务：KnowledgeManage（前缀 `/api/knowledge`，JWT Bearer）

既有接口行为除下述扩展外全部保持不变（旧"模型+提示词"模式兼容）。

---

## 1. 会话接口扩展

### POST /chats（创建）/ PUT /chats/{chat_id}（更新）

请求体新增字段（与既有 title/model_id/model_name/prompt_id 并存）：

```json
{
  "title": "新会话",
  "agent_id": "uuid",
  "knowledge_base_ids": ["kb-uuid-1", "kb-uuid-2"]
}
```

| 字段 | 校验 |
|---|---|
| agent_id | 可选；须为启用且配置完整的智能体，否则 400 并指明原因（FR-002） |
| knowledge_base_ids | agent_id 非空时必填且 ≥1，全部属于当前用户，否则 400/403（FR-001/005） |

- 存量会话（agent_id 为 NULL）：PUT 拒绝设置 agent_id（409，"存量会话不支持切换为智能体模式"）
- 响应体 `ChatResponse` 新增 `agent_id`、`agent_type`、`knowledge_base_ids`（agent_type 由后端按 agent 记录冗余填充）

### GET /agents（既有，微调）

列表项新增 `config_complete: bool` 与 `incomplete_reasons: string[]`（缺失的提示词/模型项），前端据此置灰问答入口（FR-002）。

### POST /chats/{chat_id}/cancel（既有，语义扩展）

不变。agent 模式下取消信号传播至循环与工具环节；部分答案保留并标记"已停止"（FR-031）。响应 `{id, status: "cancelled", message}`。

---

## 2. 消息接口扩展

### POST /chats/{chat_id}/messages（SSE）

请求体不变：`{"content": "问题"}`；空字符串 = reattach 恢复流（既有语义）。

**前置校验（agent 模式，失败即 JSON 错误响应，不开流）**：

| 条件 | 状态码 | detail |
|---|---|---|
| content 非空但为空串以外全空白 / >2000 字符 | 400 | "问题不能为空且不超过 2000 字符"（FR-005） |
| chat.knowledge_base_ids 为空 | 400 | "请先选择知识库"（FR-001） |
| 同会话生成中（租约有效） | 409 | "当前问答尚未结束，请稍候"（FR-032） |
| 智能体配置预检失败 | 200 开流后立即 `error` 事件 | 指明失效配置项（FR-003，流式错误） |

**断线语义（agent 模式）**：客户端断开 → 租约宽限（30s）内可空 content reattach 续流；超时无人认领 → 视同停止（R4）。

### GET /chats/{chat_id}/messages（分页，扩展响应）

`MessageResponse` 新增：

```json
{
  "id": "...", "chat_id": "...", "role": "assistant",
  "content": "答案文本，含 <ref id=\"c1\"/> 标签",
  "trace_id": "32位hex 或 null",
  "meta": { "stopped": false, "references": [...], "terminate_reason": null, "usage": {...} }
}
```

references 元素结构见 [data-model.md §1.2](../data-model.md)。

### POST /chats/{chat_id}/messages/{message_id}/refresh-urls（新增）

图片预签名过期后重签（FR-013）。校验消息归属当前用户会话。

响应 200：

```json
{
  "content": "重签后的答案文本",
  "references": [ { "handle": "c1", "content": "重签后片段内容", "...": "其余字段不变" } ]
}
```

错误：404 消息不存在；403 非本人会话。

---

## 3. SSE 事件协议（`data: {json}\n\n`，结束 `data: [DONE]`）

既有事件保持：`delta` / `usage` / `error` / `done` / `cancelled`。新增两类：

### 3.1 step（步骤进度，FR-015）

```json
{"type": "step", "step": "clarify|rewrite|retrieve|rerank|compress|sufficiency|plan_decision|tool|answer",
 "status": "start|end", "loop": 1, "tool_name": "bm25Search", "message": "第 2 轮检索中"}
```

- 不含中间步骤原始模型输出（US5-5）
- `loop` 仅循环步骤携带；`tool_name` 仅 step=tool 携带
- 事件进入既有 Redis Stream，reattach 时可回放

### 3.2 references（引用映射，答案流开始前一次性下发，FR-013）

```json
{"type": "references", "items": [
  {"handle": "c1", "document_id": "...", "kb_id": "...", "file_name": "产品手册.pdf",
   "content": "片段内容（图片为预签名 URL）", "score": 0.87}
]}
```

### 3.3 既有事件的 agent 模式语义

| 事件 | 格式 | agent 模式语义 |
|---|---|---|
| delta | `{"type":"delta","content":"..."}` | 答案流增量；`<ref id="cN"/>` 标签经缓冲校验后完整下发，无效句柄已丢弃 |
| done | `{"type":"done","message_id":"...","trace_id":"..."}` | 新增 trace_id；澄清不通过/空检索也走 done（reason/提示已作为消息落库） |
| error | `{"type":"error","code":"...","message":"...","raw_output":"..."}` | 新增 code/raw_output（JSON 校验最终失败时回传原始输出，FR-011）；流程级异常（embedding 失败/检索不可用/配置失效/运行中配置被删） |
| cancelled | `{"type":"cancelled","message_id":"...","partial_content":"..."}` | 用户停止或断线超时；部分答案已落库带"[已停止]" |
| usage | `{"type":"usage", ...}` | 不变（答案生成调用 usage） |

**错误码表**（error.code）：`config_invalid` / `clarify_json_failed` / `rewrite_json_failed` / `compress_json_failed` / `sufficiency_json_failed` / `embedding_failed` / `retrieval_unavailable` / `model_unavailable` / `internal_error`。

---

## 4. 前端渲染契约

- `<ref id="cN"/>` → 可点击上标标记；点击弹层（a-modal）展示 `file_name + content`，"查看文档"链接跳既有文档预览（document_id + kb_id）；文档已删除时提示"文档不存在或不可访问"
- meta.stopped=true → 消息尾部"已停止"徽标；消息右侧"trace"按钮仅 assistant 且 trace_id 非空时展示
- step 事件 → 输入框上方进度条文案；done/cancelled/error 后清除