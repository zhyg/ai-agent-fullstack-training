# Chat Sessions API Contract

**Feature**: 004-llm-gateway-unified | **Service**: KnowledgeManage | **Base Path**: `/api/knowledge/chats`

## 认证

所有端点使用 JWT Bearer Token 认证（现有 `get_current_user` 依赖）。

---

## POST /api/knowledge/chats

创建新会话。

### 请求体

```json
{
  "title": "代码审查对话",
  "model_name": "模型显示名称",
  "prompt_id": "uuid-of-prompt"
}
```

| 字段 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| title | string | 是 | 会话标题 |
| model_name | string | 否 | 模型显示名称，最多 200 字符；未设置显示名称时使用模型名称 |
| prompt_id | string | 否 | 使用的提示词 ID |

### 响应 201

```json
{
  "id": "uuid",
  "title": "代码审查对话",
  "user_id": "uuid",
  "model_name": "模型显示名称",
  "prompt_id": "uuid",
  "status": "idle",
  "created_at": "2026-10-28T10:00:00Z",
  "updated_at": "2026-10-28T10:00:00Z"
}
```

---

## POST /api/knowledge/chats/{chat_id}/messages

发送消息并获取模型流式响应。

### 请求体

```json
{
  "content": "帮我审查这段代码"
}
```

### 响应 200 — SSE (`text/event-stream`)

KnowledgeManage 内部调用 LlmGateway 的 `/api/llm/v1/chat/completions` 接口，将 SSE 流透传给前端。

会话创建和更新使用 `model_name`，不传模型 UUID。KnowledgeManage 将该值作为 Gateway 请求的 `model` 字段；Gateway 根据显示名称查找配置，使用配置中的真实模型名称、URL 和密钥调用供应商。旧会话的 `model_id` 仅用于前端匹配模型列表，发送消息前自动保存为 `model_name`。上线前在 KnowledgeManage 目录运行 `alembic upgrade head` 增加 `model_name` 列。

会话状态自动从 `idle` 转为 `generating`。

SSE 事件格式与 OpenAI Compatible API 流式响应一致。

流结束时，会话状态自动转为 `completed`。

---

## POST /api/knowledge/chats/{chat_id}/cancel

取消正在生成中的会话。

### 请求体

无。

### 响应 200

```json
{
  "id": "uuid",
  "status": "cancelled",
  "message": "Session cancelled"
}
```

### 行为

1. 会话状态从 `generating` 转为 `cancelled`
2. 通过 Redis Pub/Sub 发送取消信号到执行模型调用的 Worker
3. Worker 收到信号后中断模型生成流
4. 前端 SSE 连接收到取消事件后关闭

### 错误

- **404**: 会话不存在
- **409**: 会话不在 `generating` 状态，无法取消

---

## GET /api/knowledge/chats/{chat_id}/messages

获取会话的完整消息历史。

### 查询参数

| 参数 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| page | int | 否 | 页码，默认 1 |
| page_size | int | 否 | 每页条数，默认 50 |

### 响应 200

```json
{
  "items": [
    {
      "id": "uuid",
      "chat_id": "uuid",
      "role": "user",
      "content": "帮我审查这段代码",
      "created_at": "2026-10-28T10:00:00Z"
    },
    {
      "id": "uuid",
      "chat_id": "uuid",
      "role": "assistant",
      "content": "这段代码有以下问题...",
      "created_at": "2026-10-28T10:00:05Z"
    }
  ],
  "total": 2,
  "page": 1,
  "page_size": 50
}
```

---

## GET /api/knowledge/chats

获取当前用户的会话列表。

### 查询参数

| 参数 | 类型 | 必填 | 说明 |
| ---- | ---- | ---- | ---- |
| page | int | 否 | 页码，默认 1 |
| page_size | int | 否 | 每页条数，默认 20 |

### 响应 200

```json
{
  "items": [
    {
      "id": "uuid",
      "title": "代码审查对话",
      "status": "completed",
      "model_id": "uuid",
      "created_at": "2026-10-28T10:00:00Z",
      "updated_at": "2026-10-28T10:05:00Z"
    }
  ],
  "total": 1,
  "page": 1,
  "page_size": 20
}
```
