# API Contract: Vision Chat (扩展)

**Endpoint**: `POST /api/llm/v1/chat/completions`（现有接口，扩展消息格式）
**Auth**: Bearer Token (API Key)
**Protocol**: OpenAI Chat Completions 兼容（扩展 content 格式）

## 变更说明

本接口**不新增端点**，仅扩展 `messages[].content` 的类型：

- **原有**: `content: string`
- **新增**: `content: string | ContentPart[]`

## ContentPart 结构

```json
{
  "type": "text",
  "text": "描述这张图片"
}
```

或

```json
{
  "type": "image_url",
  "image_url": {
    "url": "https://example.com/image.jpg",
    "detail": "auto"
  }
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `"text"` \| `"image_url"` | Yes | 内容类型 |
| `text` | string | type=text 时必填 | 文本内容 |
| `image_url` | object | type=image_url 时必填 | 图片信息 |
| `image_url.url` | string | Yes | 图片 URL 或 Base64 Data URI |
| `image_url.detail` | `"auto"` \| `"low"` \| `"high"` | No | 图片处理精度（部分供应商忽略） |

## 图片输入方式

### URL 方式

```json
{"type": "image_url", "image_url": {"url": "https://example.com/photo.jpg"}}
```

### Base64 Data URI 方式

```json
{"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,/9j/4AAQ..."}}
```

### 约束

- 单张图片最大 20MB（Base64 编码后计算）
- 支持的格式：jpeg, jpg, png, webp, gif

## 请求示例

```json
{
  "model": "Qwen3-VL-8B",
  "messages": [
    {
      "role": "user",
      "content": [
        {"type": "text", "text": "描述这张图片的内容"},
        {"type": "image_url", "image_url": {"url": "https://example.com/photo.jpg"}}
      ]
    }
  ],
  "stream": false
}
```

## 校验规则

- 若 `content` 为 `ContentPart[]` 且包含 `image_url`：
  - `model` 对应的 `category` 必须为 `vision`；视觉模型默认支持文本和图片
  - 否则返回 400 `invalid_request`，提示该模型不支持图片输入
- 若 `content` 为纯文本（string 或仅含 `type=text` 的 ContentPart），走标准 Chat 链路
- Vision 模型收到纯文本请求时正常处理，不报错

## 响应

与现有 Chat Completions 响应格式完全一致，无变更。

## Error Responses（新增场景）

| Status | Code | Condition |
|---|---|---|
| 400 | `invalid_request` | 图片请求发给了不支持图片的模型 |
| 400 | `invalid_request` | 图片体积超过 20MB |
| 502 | `upstream_error` | 图片 URL 不可访问（透传供应商错误） |
