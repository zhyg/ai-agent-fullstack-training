# Data Model: 文档解析与分片

## 实体关系图

```
KnowledgeBase (1) ──── (N) Document (1) ──── (N) Chunk
                                                │
                                                ├── (N) Chunk (子 chunks, parent_chunk_id 关联)
                                                └── (0..1) SQLite Database (MinIO)
```

## Document（已有表，需扩展 status 字段）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK, UUID | 文档 ID |
| name | String(500) | NOT NULL | 文件名称（含扩展名） |
| description | String(1000) | NULLABLE | 文档描述 |
| tags | Text | NOT NULL, default "[]" | 标签列表 JSON 数组 |
| file_size | BigInteger | NOT NULL | 文件大小（字节） |
| mime_type | String(200) | NULLABLE | MIME 类型 |
| extension | String(50) | NULLABLE | 文件扩展名（不含点号） |
| **status** | **String(30)** | **NOT NULL, default "pending"** | **处理状态（扩展枚举值）** |
| storage_path | String(1000) | NOT NULL | MinIO 原始文件对象路径 |
| md_path | String(1000) | NULLABLE | **新增**: MinIO 转换后 markdown 文件路径 |
| chunk_config | Text | NULLABLE | **新增**: 分块配置 JSON（策略/大小/重叠/分隔符） |
| ai_question_count | Integer | NULLABLE, default 3 | **新增**: AI 问题生成数量 |
| skipped_files | Text | NULLABLE | **新增**: 压缩包中跳过的不支持文件列表 JSON |
| folder_id | String(36) | FK → folders.id | 所属目录 ID |
| kb_id | String(36) | FK → knowledge_bases.id | 所属知识库 ID |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**status 枚举值变更**: `parsing/success/failed` → `pending/parsing/chunking/embedding/ai_generating/completed/failed`

**新增索引**: `idx_document_kb_status (kb_id, status)`

---

## Chunk（存储在 Elasticsearch，非关系型表）

**索引名**: `knowledge_chunks_{kb_id}`（每个知识库独立索引）

### Mapping 定义

```json
{
  "mappings": {
    "properties": {
      "chunk_id": { "type": "keyword" },
      "document_id": { "type": "keyword" },
      "chunk_type": { "type": "keyword" },
      "content": { "type": "text", "analyzer": "standard" },
      "image_url": { "type": "keyword" },
      "parent_chunk_id": { "type": "keyword" },
      "embeddings": { "type": "dense_vector", "dims": 1024 },
      "sqlite_url": { "type": "keyword" },
      "chunk_index": { "type": "integer" },
      "file_name": { "type": "keyword" },
      "created_at": { "type": "date" }
    }
  }
}
```

**说明**:
- `embeddings.dims`: 根据知识库配置的 Embedding 模型动态确定（如 1024/768/1536），创建索引时需查询模型信息
- `image_url`: text/table_row chunk 为数组（多个图片），image 类型 chunk 为单个字符串；ES keyword 类型支持数组存储
- `chunk_index`: 分片在文档中的顺序索引，用于前端排序展示
- `parent_chunk_id`: 用于查询子 chunks（image_ocr/image_caption/ai_question）

---

## Chunk 类型与层级关系

| chunk_type | parent_chunk_id | 说明 |
|------------|-----------------|------|
| text | null | 文本分片（顶层），content 中可能包含 `![](url)` |
| image | null | 独立上传的图片（顶层），content 为 `![](url)` |
| image_ocr | text/table_row/image chunk | 图片 OCR 识别结果 |
| image_caption | text/table_row/image chunk | 图片视觉模型分析结果 |
| table_row | null | 表格行分片（顶层），关联 sqlite_url |
| ai_question | text/image_ocr/table_row chunk | AI 生成的问题 |

---

## chunk_config JSON 结构（Document 字段）

```json
{
  "strategy": "heading",
  "chunk_size": 512,
  "chunk_overlap": 80,
  "separators": ["\n\n", "\n", "。", "；", "？", "！", ".", ";", "?", "!"]
}
```

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| strategy | string | "heading" | 分块策略: "heading"（按标题）或 "fixed"（按固定长度） |
| chunk_size | int | 512 | 分块大小（字符数，100-4000） |
| chunk_overlap | int | 80 | 分块重叠（字符数，0-500） |
| separators | string[] | 全部10种 | 启用的分隔符列表 |

---

## SQLite 动态表结构

表格文件按 sheet 动态建表，表名和列名由 LLM 翻译为英文：

```sql
-- 示例：sheet "员工信息" → 表名 "employee_info"
CREATE TABLE employee_info (
    name TEXT,          -- 姓名
    department TEXT,    -- 部门
    level TEXT          -- 职级
);
```

**命名规则**:
- 表名: LLM 根据 sheet 名生成英文标识符
- 列名: LLM 根据表头生成英文标识符，中文原值作为列注释（description）
- 中文列名时: 列名英文，COMMENT 存储中文描述

---

## MinIO 存储路径规范

| 对象类型 | 路径模式 |
|---------|---------|
| 原始文件 | `{kb_id}/{folder_id}/{doc_id}/{filename}` |
| 转换后 markdown | `{kb_id}/{doc_id}/markdown/{filename}.md` |
| 文档中的图片 | `{kb_id}/{doc_id}/images/{image_name}` |
| SQLite db 文件 | `{kb_id}/{doc_id}/tables/{table_name}.db` |
| 独立上传图片 | `{kb_id}/{folder_id}/{doc_id}/{image_name}` |

---

## 配置文件变更

### config.*.yaml 新增段

```yaml
elasticsearch:
  hosts: "http://localhost:9200"
  username: "elastic"
  password: "[REDACTED]"

services:
  mineru: "http://localhost:8000"
```

### requirements.txt 新增依赖

```
elasticsearch[async]>=8.0
llama-index-core
openpyxl    # xlsx 文件读取
```
