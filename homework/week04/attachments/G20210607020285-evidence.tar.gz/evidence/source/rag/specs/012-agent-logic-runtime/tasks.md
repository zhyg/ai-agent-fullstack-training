# Tasks: 智能体逻辑实现（三类智能体问答流程、工具运行时、停止与 Trace 展示）

**Input**: Design documents from `/specs/012-agent-logic-runtime/`

**Prerequisites**: plan.md、spec.md、research.md、data-model.md、contracts/（chat-agent-api.md / trace-api.md / tool-runtime.md）、quickstart.md

**Tests**: 包含测试任务——plan.md 的 Project Structure 明确列出 5 个新 pytest 测试文件，且仓库惯例要求 pytest 覆盖新逻辑、既有会话测试零回归。

**Organization**: 按用户故事分组，每个故事可独立实现与验证；US1 为 MVP。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行（不同文件、无未完成依赖）
- **[Story]**: US1–US5 对应 spec.md 用户故事
- 路径约定：后端 `KnowledgeManage/`、前端 `frontend/`（多服务仓库，见 plan.md）

---

## Phase 1: Setup（共享基础设施）

**Purpose**: 依赖与配置就绪，新包骨架建立

- [X] T001 在 KnowledgeManage/requirements.txt 新增 `langgraph`、`opentelemetry-sdk`、`opentelemetry-exporter-otlp-proto-grpc`、`tiktoken` 并 `pip install -r requirements.txt`（conda myAiEnvNew；llama-index-core 保留不使用，见 research.md R1）
- [X] T002 [P] 扩展 KnowledgeManage/app/core/config.py 与 config.dev.yaml / config.test.yaml / config.prod.yaml：新增 `tracing` 段（enabled=true、otlp_endpoint="http://localhost:4317"、service_name="knowledge-manage-agent"）与 `agent_runtime` 段（tool_result_max_tokens=4000、history_rounds=10、similarity_threshold=0.9、sqlite_max_bytes=52428800、sqlite_download_timeout=30、sqlite_cache_ttl=3600、sql_max_rows=500、presign_expires=86400、rrf_k=60），全部有默认值、缺省可跑（research.md R17）
- [X] T003 [P] 创建 KnowledgeManage/app/services/agent_runtime/ 包骨架：`__init__.py`、`flows/__init__.py`、`tools/__init__.py`（空实现占位，模块清单见 plan.md Project Structure）

---

## Phase 2: Foundational（阻塞性前置）

**Purpose**: 数据迁移、模型接入、追踪、运行态与生成骨架扩展——所有用户故事的公共地基

**⚠️ CRITICAL**: 本阶段完成前任何用户故事不得开工

- [X] T004 [P] 扩展 KnowledgeManage/app/models/chat.py（+agent_id String(36) nullable、+agent_type String(30) nullable、+knowledge_base_ids JSONB nullable 默认 []）、app/models/message.py（+trace_id String(32) nullable 带索引、+meta JSONB nullable）、app/schemas/chat.py（ChatCreate/ChatUpdate 增 agent_id/knowledge_base_ids，ChatResponse/MessageResponse 增对应字段与 trace_id/meta；meta 结构按 data-model.md §1.2）；保留 model_id/model_name/prompt_id 不删
- [X] T005 新增 Alembic 迁移 KnowledgeManage/alembic/versions/xxxx_agent_chat_trace.py：chats +3 列、messages +2 列（含 trace_id 索引），全部 nullable 无回填，downgrade 删列删索引；执行 `alembic upgrade head` 验证（依赖 T004，data-model.md §4）
- [X] T006 [P] 新增 KnowledgeManage/app/schemas/agent_runtime.py：各步骤 Pydantic 输出模型 ClarifyResult{clear: bool, reason: str|None}、RewriteResult{rewritten_question: str}、CompressResult{kept_indexes: list[int]}（越界/重复/非整数校验失败，空数组合法）、SufficiencyResult{sufficient: bool, new_question: str|None（false 时必填）}；SSE 事件模型 StepEvent/ReferencesEvent 与 ToolResult{success, code, content, artifact_path?}（contracts/chat-agent-api.md §3、tool-runtime.md §1）
- [X] T007 [P] 新增 KnowledgeManage/app/services/agent_runtime/tracing.py：进程级单例 TracerProvider + BatchSpanProcessor + OTLPSpanExporter(gRPC, insecure)，Resource service.name 取配置；span 命名 agent.run/agent.{step}/agent.tool.{name}，属性 agent.input/agent.output（JSON 字符串 ≤32KB 截断）、agent.loop、tool.call_id、enduser.id、session.id；事件 rerank_degraded/forced_convergence/idle_loop_converged/invalid_ref_dropped；finalize 时 force_flush(5s)；enabled=false 用 NoOp Tracer；导出失败仅记日志（research.md R11，参考 opentelemetryDemo/demo.py；依赖 T002）
- [X] T008 [P] 新增 KnowledgeManage/app/services/agent_runtime/state.py：RequestRuntimeState / AgentConfigSnapshot / ContextChunk / Plan(PlanStep) / ToolCallRecord 数据类，字段与生命周期严格按 data-model.md §2（chunks 按 chunk_id 去重 OrderedDict 保留首次顺序；plan 仅内存不落库；sqlite_whitelist 集合；cancel_event: asyncio.Event）
- [X] T009 新增 KnowledgeManage/app/services/agent_runtime/llm_client.py：httpx AsyncClient 调网关 /api/llm/v1/chat/completions（JSON 非流式 + SSE 流式两种），Bearer [REDACTED]；扩展 embedding_service.resolve_model_name 模式为 resolve_model(model_id)→{name(COALESCE(display_name,name)), context_tokens, category}（跨 schema 只读 SQL + 缓存）；JSON 容错提取（剥代码围栏/去首尾空白/提取首个完整对象）→ model_validate_json，校验失败业务重试最多 3 次（含首次共 4 次），重试附上次输出与错误信息；传输层错误不重试直接上抛；每次调用输入输出记 trace（research.md R1/R2/R3，FR-011/012；依赖 T003、T007）
- [X] T010 新增 KnowledgeManage/app/services/agent_runtime/snapshot.py：开跑前一次性冻结提示词**内容**、模型 {id,name,context_tokens}、retrieval/loop_count/tools/max_output_tokens/kb_ids 进 AgentConfigSnapshot；全量预检（提示词存在、模型记录存在【网关无启用字段，存在即启用，R3】、知识库存在且属本人），失败返回指明配置项的错误；运行期不再读配置表（FR-003/004，research.md R16；依赖 T008、T009）
- [X] T011 扩展 KnowledgeManage/app/services/chat_service.py：send_message_stream 按 chat.agent_id 分支——非空委托 agent_runtime 入口（事件进同一 _GenerationJob 队列/Redis Stream，取消/reattach/落库骨架复用），为空走旧路径零改动；agent 模式取消落库标记 `content + "\n[已停止]"`（旧模式保留"\n[已取消]"）；断线启动租约宽限（LEASE_SECONDS=30），期内 reattach 续流、到期无人认领发布取消视同停止；finalize 写 Message.trace_id（user 与 assistant 两行同值）与 meta（stopped/terminate_reason/references/usage/error_code/raw_output）（research.md R4/R5/R6/R19；依赖 T004、T005、T008）

**Checkpoint**: 地基就绪——迁移完成、网关客户端/追踪/快照/生成骨架可用，用户故事可开工

---

## Phase 3: User Story 1 - 会话页选择知识库与智能体完成快速问答 (Priority: P1) 🎯 MVP

**Goal**: 会话页改为"知识库（多选必选）+智能体"，快速问答单遍流程（澄清→重写→检索→rerank→压缩→答案）流式输出带引用与图片的答案

**Independent Test**: quickstart.md V1——模糊问题收澄清提示、清晰问题收带可点击来源与图片的流式答案、空知识库/空检索收明确提示、配置失效开跑前拦截、存量会话只读

### Implementation for User Story 1

- [X] T012 [P] [US1] 新增 KnowledgeManage/app/services/retrieval_service.py：BM25（match on content，size=keyword_top_k）、向量（script_score cosineSimilarity+1.0，size=vector_top_k）、混合（两路 RRF 融合 score=Σ1/(60+rank) 按 chunk_id 去重截断 hybrid_top_k）；多库 ES 多索引查询 ignore_unavailable=True（索引不存在=空结果）；召回数量各 1–100 默认 20；向量化复用 embedding_service.generate_embeddings，失败抛流程级异常；ES 不可用/超时抛流程级异常（research.md R7，FR-008/012）
- [X] T013 [P] [US1] 新增 KnowledgeManage/app/services/rerank_service.py：POST 网关 /api/llm/v1/rerank（Cohere 兼容 query/documents/top_n/return_documents，已核查 LlmGateway/app/schemas/rerank.py），保留 rerank_top_n 条（默认 15，范围 1–100）；网关重试后仍失败降级按原始检索分截断并记 rerank_degraded 事件（FR-009，research.md R8）
- [X] T014 [P] [US1] 新增 KnowledgeManage/app/services/agent_runtime/budget.py：tiktoken cl100k_base 估算；预算=快照 analysis_model.context_tokens − max_output_tokens；核算系统提示词+会话历史（默认最近 10 轮）+片段+引用协议；超预算先截最早历史轮次、再按 first_loop 从早到晚淘汰片段、至少保留最新 1 条（FR-019，research.md R9）
- [X] T015 [P] [US1] 新增 KnowledgeManage/app/services/agent_runtime/citation.py：片段注入格式 `[cN] (文档名) 内容`（cN 从 1）；answer 提示词追加 PRD §2.1.8 的 Source handling protocol 系统文案；流式后处理状态机缓冲不完整 `<ref ...>` 前缀、完整标签校验 cN——有效原样下发、无效丢弃记 invalid_ref_dropped 事件；MinIO 图片路径统一替换预签名 URL（storage_service.get_presigned_url，expires=86400）；构建 references 映射（handle/document_id/kb_id/file_name/content/image_paths/score）（FR-013/014，research.md R13）
- [X] T016 [US1] 新增 KnowledgeManage/app/services/agent_runtime/steps.py：clarify/rewrite/compress/answer 共用步骤（用 T006 模型 + T009 客户端 + T007 span；提示词自动追加 model_json_schema；压缩后按 document_id 查 documents 表补文档名；answer 流式经 T015 后处理产出 delta；澄清 clear=false 时 reason 落库为 AI 消息 terminate_reason=clarify_failed 并结束）（FR-006/007/010/016，依赖 T006–T010、T015）
- [X] T017 [US1] 新增 KnowledgeManage/app/services/agent_runtime/flows/quick_qa.py：langgraph StateGraph 单遍"clarify→rewrite→retrieve→rerank→compress→answer"；检索为空/压缩 kept_indexes=[] 直接终止提示"检索结果为空"落库（terminate_reason=empty_retrieval）；每节点入口取消检查；每步发 StepEvent（不含中间原始输出）；JSON 最终失败发 error 事件含 code+raw_output（FR-016，contracts/chat-agent-api.md；依赖 T012–T016）
- [X] T018 [US1] 实现 KnowledgeManage/app/services/agent_runtime/__init__.py 的 run_agent_generation 入口：构建快照→按 agent_type 分发 flow→事件写入 chat_service 传入的 job 队列→finalize 落库 meta/trace_id + tracing force_flush；注册 quick_qa（依赖 T011、T017）
- [X] T019 [US1] 扩展 KnowledgeManage/app/routers/chats.py：ChatCreate/Update 接受 agent_id/knowledge_base_ids（agent_id 非空时 kb 必填 ≥1 且全部属本人，否则 400/403；存量会话 PUT 设 agent_id 返回 409）；POST messages agent 模式前置校验（问题非空且 ≤2000 字符→400、kb 空→400"请先选择知识库"、生成中→409"当前问答尚未结束"）；GET messages 返回 trace_id/meta；新增 POST /chats/{chat_id}/messages/{message_id}/refresh-urls（归属校验，重签 content 与 references 图片 URL）（contracts/chat-agent-api.md §1/§2，FR-001/002/005/013/032；依赖 T004、T018）
- [X] T020 [P] [US1] 扩展 KnowledgeManage/app/routers/agents.py：列表项新增 config_complete: bool 与 incomplete_reasons: string[]（缺失提示词/模型项），供前端置灰（FR-002，contracts/chat-agent-api.md §1）
- [X] T021 [P] [US1] 扩展 KnowledgeManage/app/services/agent_service.py：保存时校验 max_output_tokens < 分析模型 context_tokens（跨 schema 查 llm_gateway.models），不满足返回 400 指明两值（FR-020）
- [X] T022 [US1] 改造 frontend/src/views/ChatManagement.vue：配置区改为知识库多选（a-select multiple，必选 ≥1）+ 智能体选择（仅启用且 config_complete 可选，未完成配置置灰带提示）替代模型/提示词下拉；未选知识库提问按钮置灰提示"请先选择知识库"；存量会话（agent_id 空）只读展示旧模型+提示词、隐藏提问入口；发送前 updateChat(agent_id/knowledge_base_ids) 再 sendMessage（FR-001/002，依赖 T019、T020）
- [X] T023 [US1] 扩展 frontend/src/services/chatApi.js 与 frontend/src/stores/chat.js：SSE 解析新增 step/references 事件（旧 delta/usage/error/done/cancelled 兼容保留）；store 增 agent/kb 选择状态、stepProgress、references 映射、error.code/raw_output 展示、done.trace_id 保存、cancelled.partial_content 处理（contracts/chat-agent-api.md §3；依赖 T019）
- [X] T024 [US1] 扩展 frontend/src/components/chat/ 消息渲染组件：`<ref id="cN"/>` 渲染为可点击上标（用 references 映射），点击 a-modal 弹层展示文档名+片段内容+"查看文档"链接跳既有文档预览（文档已删提示"文档不存在或不可访问"）；图片 Markdown 渲染（md-editor-v3）；输入框上方 step 进度条（含轮次文案，不展示中间原始输出）；图片加载失败触发 refresh-urls 重签（FR-013/015，澄清 Q3；依赖 T023）
- [X] T025 [P] [US1] 扩展 frontend/src/utils/agent.js 的 validateAgentDraft：保存校验 max_output_tokens < 分析模型 context_tokens（FR-020 前端侧，与 T021 对应）
- [X] T026 [P] [US1] 新增 KnowledgeManage/tests/test_retrieval_service.py：三种检索 + RRF 融合去重截断 + 多库融合 + 索引不存在=空 + ES 异常分级（mock AsyncElasticsearch）
- [X] T027 [P] [US1] 新增 KnowledgeManage/tests/test_citation.py：ref 标签跨 chunk 缓冲、无效 cN 丢弃、图片路径替换、references 映射构建
- [X] T028 [US1] 新增 KnowledgeManage/tests/test_agent_flows.py：快速问答场景（mock 网关/ES）——澄清 false 落库、空检索终止、JSON 容错+重试 4 次上限+raw_output 回传、rerank 降级、embedding 失败终止、配置预检拦截、kept_indexes 越界重试/空数组合法（FR-006–016，依赖 T018）

**Checkpoint**: US1 独立可验证（quickstart V1 全过）——MVP 可交付

---

## Phase 4: User Story 2 - 推理行动智能体多轮循环问答 (Priority: P2)

**Goal**: 每轮压缩后充足判断，不充足携带 new_question 循环；片段去重累积、预算淘汰、强制收敛与空转检测

**Independent Test**: quickstart.md V2——loop_count=2 时观察 2 轮进度、达上限强制收敛出答案且 trace 含 forced_convergence、相同片段只保留一份

### Implementation for User Story 2

- [X] T029 [US2] 扩展 KnowledgeManage/app/services/agent_runtime/steps.py：新增 sufficiency 步骤（SufficiencyResult 校验：sufficient=false 时 new_question 必填、true 时为 null；JSON 容错+业务重试同共用规则；span agent.sufficiency 带 agent.loop）（FR-017，依赖 T016）
- [X] T030 [US2] 新增 KnowledgeManage/app/services/agent_runtime/flows/reasoning_action.py：langgraph 循环"rewrite→retrieve→rerank→compress→sufficiency"（一轮计 1，澄清/答案不计入，loop_count 默认 10 范围 1–1000）；检索为空/压缩空=不充足进下一轮；chunks 按 chunk_id 去重累积保留首次顺序（first_loop 标记）；每轮经 budget.py 核算淘汰；空转检测（归一化相同或 difflib.SequenceMatcher ≥0.9 提前收敛记 idle_loop_converged）；达上限强制收敛记 forced_convergence，上下文为空走"无资料"话术分支；注册进 run_agent_generation（FR-017–022，research.md R10，依赖 T014、T017、T029）
- [X] T031 [US2] 扩展 frontend/src/components/chat/ 进度组件与 frontend/src/stores/chat.js：循环轮次进度展示（"第 N 轮检索中"）、强制收敛/提前收敛的完成态文案（US2-1，依赖 T023、T030）
- [X] T032 [US2] 扩展 KnowledgeManage/tests/test_agent_flows.py：推理行动场景——2 轮循环、空检索进循环、去重累积、预算先截历史再淘汰片段且保底 1 条、达上限强制收敛、空上下文无资料话术、空转提前收敛（依赖 T030）

**Checkpoint**: US1+US2 均独立可验证（quickstart V1+V2）

---

## Phase 5: User Story 3 - 规划推理智能体自主规划与工具调用 (Priority: P3)

**Goal**: 澄清后模型基于启用工具自主决策循环（function calling），13 工具统一受控执行，plan 请求级内存，表格元数据与只读 SQL

**Independent Test**: quickstart.md V3——全工具启用时 trace 可见 createPlan/检索/listTableMetaData/sqlExecute 链路且 call_id 一致；关闭某工具后模型不再调用；非法 SQL/白名单外 URL 被拦截

### Implementation for User Story 3

- [X] T033 [P] [US3] 新增 KnowledgeManage/app/services/agent_runtime/tools/runtime.py：execute_tool(call_id, tool_name, args, ctx) 统一入口——取消检查→Pydantic 入参校验（失败 invalid_args 不抛异常）→执行（内部重试最多 3 次后 execution_failed）→串行逐个执行→content 超 tool_result_max_tokens=4000 截断附"结果已截断，共 N 条"→agent.tool.{name} span 携带 tool.call_id 全程一致；结果信封 {success, code, content, artifact_path?}，结果码 ok/empty_result/invalid_args/execution_failed/forbidden_sql/url_not_allowed/cancelled（FR-029/030，contracts/tool-runtime.md §1；依赖 T006、T008）
- [X] T034 [P] [US3] 新增 KnowledgeManage/app/services/agent_runtime/tools/plan_tools.py：createPlan（title+steps 1–50，单请求单 plan）/listPlan/getPlan/updatePlan/deletePlan，仅操作 ctx.plan（内存态，请求结束/停止丢弃），plan_id/step_id 不匹配返回 invalid_args（FR-024，contracts/tool-runtime.md §2；依据 contracts/tool-runtime.md §1 冻结信封开发，与 T033 无代码依赖）
- [X] T035 [P] [US3] 新增 KnowledgeManage/app/services/agent_runtime/tools/knowledge_tools.py：rewriteQuestion/bm25Search/vectorSearch/hybridSearch/rerank/zip 六工具，复用 retrieval_service/rerank_service/steps；空结果 code=empty_result 回传模型不终止；rerank 降级附 degraded:true；zip 输出 kept_chunk_ids；检索命中并入 ctx.chunks 去重累积、sqlite_url 加入 ctx.sqlite_whitelist；embedding 失败在工具内为 execution_failed 回传模型；工具内模型调用在 agent.tool.{name} 下按对应步骤名产生子 span（data-model.md §3.1）（FR-025，contracts/tool-runtime.md §3；依赖 T012、T013、T016）
- [X] T036 [P] [US3] 新增 KnowledgeManage/app/services/agent_runtime/tools/table_tools.py：listTableMetaData/sqlExecute——URL 白名单校验（ctx.sqlite_whitelist，否则 url_not_allowed）；预签名下载 ≤50MB/≤30s，缓存 /tmp/km_sqlite_cache/{sha256(url)}.db TTL 1h 定期清理；SQL 双保险只读（剥注释后 SELECT 开头+sqlite3.complete_statement 单语句+拒绝 DDL/DML/ATTACH/写 PRAGMA→forbidden_sql；连接 file:...?mode=ro uri=True）；元数据 sqlite_master+PRAGMA table_info；结果 ≤500 行超出截断（FR-026/027，SC-008，contracts/tool-runtime.md §4，research.md R15）
- [X] T037 [US3] 新增 KnowledgeManage/app/services/agent_runtime/flows/planning_reasoning.py：澄清后进入决策循环——启用工具映射 OpenAI function calling tools 声明（未启用对模型不可见）；planning 提示词+协议说明；每次决策调用计一轮（默认 100 范围 1–1000，一轮多工具不另计数）；tool_calls 经 runtime 串行执行、结果以 {"role":"tool","tool_call_id":...} 回传；无工具调用进答案生成；每次决策调用产生 agent.plan_decision span（带 agent.loop，data-model.md §3.1）；达上限强制收敛记 forced_convergence；上下文累积/预算与推理行动一致；注册进 run_agent_generation（FR-023/028，contracts/tool-runtime.md §5；依赖 T030、T033–T036）
- [X] T038 [P] [US3] 新增 KnowledgeManage/tests/test_tool_runtime.py：入参校验失败信封、执行重试 3 次、截断说明、取消传播、call_id 贯通、plan 工具生命周期、SQL 注入/多语句/ATTACH 拒绝、白名单外 URL 拒绝、只读连接写失败、下载大小/超时上限（SC-008，依赖 T033–T036）
- [X] T039 [US3] 扩展 KnowledgeManage/tests/test_agent_flows.py：规划推理场景——决策循环计数、工具禁用不可见、失败/空 tool result 回传继续、达上限强制收敛、表格复合问题链路（依赖 T037）

**Checkpoint**: US1+US2+US3 均独立可验证（quickstart V1–V3）

---

## Phase 6: User Story 4 - 问答停止 (Priority: P4)

**Goal**: 停止信号贯通循环与工具全部待执行环节，≤3s 终止；部分答案保留标记"已停止"；断线视同停止；同会话并发拒绝

**Independent Test**: quickstart.md V4——循环/工具/答案流式中停止均 ≤3s 终止且无新调用；关标签页 30s 后消息带 stopped；生成中再问 409

### Implementation for User Story 4

- [X] T040 [US4] 贯通取消检查点：KnowledgeManage/app/services/agent_runtime/flows/{quick_qa,reasoning_action,planning_reasoning}.py 每节点入口、llm_client.py 每次调用发起前与流式 delta 批间、tools/runtime.py 每工具执行前检查 ctx.cancel_event，命中抛 AgentCancelled 由 finalize 落库部分答案+"\n[已停止]"（meta.stopped=true）；已执行工具副作用不回滚、plan 随请求丢弃（FR-031/032，SC-005，research.md R5；依赖 T011、T030、T037）
- [X] T041 [US4] 扩展 frontend/src/stores/chat.js 与 frontend/src/components/chat/：停止按钮复用 cancelGeneration；cancelled 事件展示 partial_content+"已停止"徽标（meta.stopped 回放同样式）；409 响应提示"当前问答尚未结束，请稍候"；断线后 30s 内 resumeStream 续流验证（US4，contracts/chat-agent-api.md；依赖 T023、T040）
- [X] T042 [US4] 扩展 KnowledgeManage/tests/test_agent_flows.py 与回归 tests/test_chat_background.py：答案流中/循环中/工具队列中停止 ≤3s 无新调用、部分答案落库带标记、断线租约到期取消、期内 reattach 续流、同会话并发 409、旧模式取消行为零回归（依赖 T040）

**Checkpoint**: 停止能力对三类流程全覆盖（quickstart V4）

---

## Phase 7: User Story 5 - 查看问答执行轨迹（Trace） (Priority: P5)

**Goal**: AI 消息旁 trace 按钮→右侧宽幅抽屉展示完整轨迹（时间线/详情/统计），后端代理查询+归属校验，普通用户不脱敏

**Independent Test**: quickstart.md V5——时间线覆盖全部步骤、输入输出可查、写入中提示重试、他人消息 403

### Implementation for User Story 5

- [X] T043 [P] [US5] 新增 KnowledgeManage/app/services/trace_query_service.py：按 message.created_at UTC 日期构造 jaeger-span-{D-1},{D},{D+1} 索引（±1 天容错），term traceID 查询 ignore_unavailable=True；ES 文档→Jaeger UI 格式 {data:[{traceID,spans,processes}]}（微秒时间、CHILD_OF 规范化、process 去重、logs.fields 事件映射）；空结果返回 ready:false reason:pending；无 trace_id 返回 ready:false reason:no_trace（FR-036，contracts/trace-api.md，research.md R12）
- [X] T044 [US5] 扩展 KnowledgeManage/app/routers/chats.py：新增 GET /chats/{chat_id}/messages/{message_id}/trace——JWT 归属校验（非本人 403"无权查看该消息的轨迹"、消息不存在 404）→调 trace_query_service；ES 不可用 503；不脱敏返回完整 agent.input/output（澄清 Q1，contracts/trace-api.md；依赖 T043）
- [X] T045 [P] [US5] 新增 frontend/src/services/traceApi.js：调用 trace 代理接口（JWT 拦截器复用 chatApi 模式），处理 ready:false/403/503
- [X] T046 [P] [US5] 移植 TraceViewer/src/components/{TraceTimeline,SpanDetail,StatisticsView}.vue 与 api.ts 的 buildSpanTree（CHILD_OF 构树、微秒相对时间）为 JS 到 frontend/src/components/trace/（纯 Vue3 无新增 npm 依赖；SpanDetail 展示 agent.input/output 与 tool.call_id、事件 logs）
- [X] T047 [US5] 新增 frontend/src/components/trace/TraceDrawer.vue（a-drawer 右侧 width≈60%，不新增路由）并集成：消息组件（frontend/src/components/chat/）assistant 且 trace_id 非空时显示"trace"按钮；ready:false 展示"trace 写入中，稍后重试"+重试按钮；内嵌时间线/详情/统计三视图，关闭返回会话（FR-035，澄清 Q4；依赖 T044、T045、T046）
- [X] T048 [P] [US5] 新增 KnowledgeManage/tests/test_trace_query.py：归属校验 403/404、日期 ±1 容错索引构造、ES→Jaeger 格式转换（含事件/CHILD_OF/processes）、空结果 pending、no_trace（依赖 T043）

**Checkpoint**: 全部 5 个故事独立可验证（quickstart V1–V5）

---

## Phase 8: Polish & Cross-Cutting Concerns

- [X] T049 全量后端回归：`cd KnowledgeManage && pytest tests/ -v`——新增 5 个测试文件 + 既有 test_chat_stream/test_chat_background/test_agents 等全绿，旧"模型+提示词"模式零回归
- [X] T050 前端构建验证：`cd frontend && npm run build` 通过；会话页/智能体编辑页/文档预览跳转手工冒烟
- [X] T051 按 specs/012-agent-logic-runtime/quickstart.md §4 执行 V1–V5 端到端验证（含 Collector 链路：完成问答后 ES jaeger-span-* 可查到 agent.run 根 span 且 trace_id 与消息一致）；核对 SC-001–008（首字延迟/停止 3s/强制收敛/安全拦截）；SC-001 采样口径：连续发起 ≥20 次快速问答，记录请求发起到首个 SSE delta 的耗时，≥90% ≤15 秒；FR-037 已由 quickstart.md §5 交付，核对六类推荐文案与三类智能体用途映射无遗漏

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即可做（T002/T003 可并行）
- **Foundational (Phase 2)**: 依赖 Setup；**阻塞全部用户故事**。内部：T004→T005；T006/T007/T008 并行；T009 依赖 T003/T007；T010 依赖 T008/T009；T011 依赖 T004/T005/T008
- **US1 (Phase 3)**: 依赖 Foundational。内部：T012–T015 并行 → T016 → T017 → T018 → T019；T020/T021/T025/T026/T027 可穿插并行；前端 T022→T023→T024
- **US2 (Phase 4)**: 依赖 US1 的 steps/flow 基础（T016/T017）与 budget（T014）
- **US3 (Phase 5)**: 依赖 US1 的检索/rerank/steps（T012/T013/T016）与 US2 的累积收敛机制（T030）；T033–T036 四文件可并行
- **US4 (Phase 6)**: 依赖三类 flow 完成（T017/T030/T037）——停止检查点需贯通全部环节
- **US5 (Phase 7)**: 后端代理（T043/T044/T048）仅依赖 Foundational 的 trace_id 落库（T011），可与 US2–US4 并行；前端抽屉集成（T047）依赖消息组件（T024）
- **Polish (Phase 8)**: 依赖全部已交付故事

### User Story Dependencies（spec 优先级序）

```text
Setup → Foundational → US1(P1, MVP)
                        ├→ US2(P2) ─→ US3(P3) ─→ US4(P4)
                        └→ US5(P5, 后端可提前并行；前端集成需 US1 消息组件)
```

### Parallel Opportunities

- Setup：T002 ∥ T003
- Foundational：T004 ∥ T006 ∥ T007 ∥ T008
- US1：T012 ∥ T013 ∥ T014 ∥ T015 ∥ T020 ∥ T021 ∥ T025 ∥ T026 ∥ T027（9 项）
- US3：T033 ∥ T034 ∥ T035 ∥ T036 ∥ T038（工具四文件+测试）
- US5：T043 ∥ T045 ∥ T046 ∥ T048；且 US5 后端整体可与 US2/US3 并行
- 前端与后端：T022–T025 可在对应后端接口（T019/T020）契约冻结后并行开发

---

## Parallel Example: User Story 1

```bash
# 地基完成后，US1 四个独立服务模块同时开工：
Task: "T012 retrieval_service.py 三种检索+RRF"
Task: "T013 rerank_service.py 网关重排+降级"
Task: "T014 budget.py token 预算与淘汰"
Task: "T015 citation.py 引用协议与流式后处理"
# 测试并行：
Task: "T026 test_retrieval_service.py"
Task: "T027 test_citation.py"
```

---

## Implementation Strategy

### MVP First（仅 US1）

1. Phase 1 Setup → Phase 2 Foundational（关键阻塞段）
2. Phase 3 US1 → quickstart V1 独立验证 → **可交付 MVP**（会话页改造+快速问答完整链路）

### Incremental Delivery

1. US1 交付后依次叠加 US2（循环）→ US3（工具）→ US4（停止贯通）→ US5（trace 展示）
2. 每个故事交付均跑对应 quickstart 场景 + 既有回归，不破坏前序故事
3. US5 后端代理可提前并行开发以缩短总工期

### 关键风险提示

- T011 触及既有 chat_service 核心：改动必须以"agent_id 分支"隔离，旧路径零改动，T042/T049 回归兜底
- T030/T037 的强制收敛与 T040 的取消检查点是 SC-004/SC-005 的达标关键，测试先行覆盖
- 网关模型无启用/停用字段（R3）：预检口径为"存在即启用"，勿臆造状态字段

---

## Notes

- [P] = 不同文件、无未完成依赖；[US#] 标签映射 spec.md 用户故事
- 所有约束数值（1–100/默认 20、≤2000 字符、重试 3 次含首次 4 次、30s 租约、4000 tokens、500 行、50MB/30s、±1 天）已在任务描述中就地引用，实现时不得另行取舍
- 每任务或逻辑组完成后提交；每个 Checkpoint 可停下独立验证