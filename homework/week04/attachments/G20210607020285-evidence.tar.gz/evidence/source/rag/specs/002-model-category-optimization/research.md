# Research: 模型管理优化

**Feature**: 002-model-category-optimization | **Date**: 2026-10-28

## R-001: 数据库列重命名迁移策略（max_tokens → context_tokens）

**Decision**: 使用 Alembic `op.alter_column()` 的 `new_column_name` 参数完成列重命名，保留原有数据不丢失。

**Rationale**: SQLAlchemy/Alembic 原生支持列重命名操作，PostgreSQL 底层执行 `ALTER TABLE ... RENAME COLUMN`，是零数据丢失的安全操作。现有迁移基础设施（`LlmGateway/alembic/`）已就位，直接复用。

**Alternatives considered**:
- 新增列 + 数据复制 + 删除旧列：操作复杂，需要手动数据迁移，有丢失风险
- 仅修改 ORM 映射而保持列名不变：`Column('context_tokens', ..., name='max_tokens')` 方式虽然可行但会造成代码与数据库列名不一致，增加维护成本

## R-002: 模型分类的存储方式

**Decision**: 使用 String 类型列存储分类枚举值（`chat`/`embedding`/`rerank`/`vision`/`speech`），在应用层（Pydantic schema）通过 Literal 或 validator 约束合法值。

**Rationale**: 字符串枚举在 PostgreSQL 中便于查询和筛选，前端也易于映射展示标签。应用层校验比数据库 CHECK 约束更灵活——未来新增分类时无需数据库迁移。项目已有的类似模式（如 provider 字段为自由字符串）保持一致。

**Alternatives considered**:
- PostgreSQL ENUM 类型：添加/移除分类需要额外迁移，灵活性不足
- 整数编码 + 应用层映射：不直观，调试和直接 SQL 查询时难以理解
- 独立 Category 表：对固定 5 种分类过度设计

## R-003: name 字段唯一性约束实现

**Decision**: 在数据库层通过复合唯一约束 `(provider, name)` 实现，同时在 service 层创建/更新前进行预检查并返回友好错误信息。

**Rationale**: 数据库约束保证数据一致性（并发安全），service 层预检查提供清晰的 HTTP 409 错误响应，避免数据库层抛出难以解析的 IntegrityError。

**Alternatives considered**:
- 仅 service 层校验：存在并发竞争条件，两个相同请求可能同时通过检查
- 仅数据库约束：错误信息不够友好，需要解析 IntegrityError 再转换为 HTTP 响应

## R-004: 前端分类标签页 UI 方案

**Decision**: 参照 MyKnowlegeWebDemo 的 `ModelList.vue` 实现，使用 Ant Design Vue 的 `<a-tabs>` 组件实现分类标签页。每个标签显示分类名称和该分类下的模型计数，默认激活"对话模型"标签。

**Rationale**: Demo 已经验证了此交互模式的可行性，`<a-tabs>` 是 Ant Design Vue 的标准组件，与项目 UI 风格一致。标签页切换时通过前端内存筛选（非 API 请求）实现，满足 SC-002 的 1 秒响应要求。

**Alternatives considered**:
- 每个分类独立 API 请求：增加网络开销，切换时有加载延迟
- 侧边栏分类导航：占用更多页面空间，不适合模型管理场景

## R-005: 前端模型数据一次性加载 vs 分页

**Decision**: 模型列表 API 保持分页模式，但前端在模型管理页面一次性加载全部模型（设置足够大的 page_size，如 1000），分类筛选在前端内存中完成。

**Rationale**: 当前系统模型数量预计在数十到数百级别，全量加载不会有性能问题。前端内存筛选确保标签页切换即时响应（SC-002），且实现简单。当模型数量未来增长到上千级别时，可优化为后端分类筛选 + 分页。

**Alternatives considered**:
- 后端按分类筛选 + 分页：每次切换标签需要 API 请求，有网络延迟
- 前端逐分类缓存：实现复杂，增加状态管理难度

## R-006: 会话页模型选择器分类分组

**Decision**: 使用 Ant Design Vue `<a-select>` 的 `<a-select-opt-group>` 实现模型按分类分组展示，默认不限制分类（显示所有模型分组）。

**Rationale**: 现有 `MessageInput.vue` 使用扁平 `<a-select>`，改造为 opt-group 分组是最小化改动。分组展示让用户直观看到模型分类，同时保持选择所有分类模型的能力。

**Alternatives considered**:
- 先选分类再选模型（两级选择器）：增加操作步骤，降低效率
- 仅显示对话模型：限制用户选择范围，不符合需求（用户可手动切换到其他分类）

## R-007: 供应商（provider）字段预设与自定义输入

**Decision**: 前端使用 Ant Design Vue `<a-select>` 的 `mode="combobox"` 或 `showSearch` + 预设选项模式，提供 OpenAI 和 Anthropic 作为预设选项，同时允许用户输入自定义供应商名称。

**Rationale**: 预设选项覆盖主流供应商，自定义输入支持新兴供应商（如 Azure、Google、本地部署等），无需频繁更新前端选项列表。

**Alternatives considered**:
- 纯下拉选择：无法支持自定义供应商
- 纯文本输入：失去了预设选项的便利性，用户需手动输入常见供应商名称

## R-008: 前端 model.js 工具模块设计

**Decision**: 在 `frontend/src/utils/model.js` 中定义分类常量 `MODEL_CATEGORIES` 数组（含 value、label、formLabel），以及 `getModelCategory(model)` 辅助函数（对无分类旧模型默认返回 `'chat'`）。与 MyKnowlegeWebDemo 保持一致。

**Rationale**: 集中管理分类定义，避免在多个组件中硬编码。`getModelCategory()` 统一处理旧模型兼容逻辑。与 Demo 保持一致降低理解和迁移成本。

**Alternatives considered**:
- 从后端 API 获取分类列表：对固定枚举值过度设计，增加 API 复杂度
- 在每个组件内各自定义：重复代码，维护困难
