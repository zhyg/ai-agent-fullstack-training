# Research: 知识库中文档管理

**Date**: 2026-11-16 | **Feature**: 008-knowledge-doc-management

## R1: MinIO Python SDK 选型

**Decision**: 使用 `minio` 官方 Python SDK (`minio` PyPI 包)

**Rationale**:
- 官方维护，API 稳定，与 MinIO/RustFS S3 兼容存储完全兼容
- 支持 multipart upload（大文件分片上传）、presigned URL（预签名下载）
- 项目已有 MinIO 部署经验，团队熟悉 S3 兼容 API

**Alternatives considered**:
- `boto3` (AWS S3 SDK): 功能更丰富但体积大，对 MinIO 有额外兼容层
- 直接 HTTP 调用 S3 API: 需自行实现签名逻辑，维护成本高

## R2: MinIO 配置集成方式

**Decision**: 在 `config.py` Settings 中新增 `MinioConfig` 子类，`config.*.yaml` 中新增 `minio` 配置段

**Rationale**:
- 与项目现有配置模式一致（DatabaseConfig, RedisConfig 等均为 BaseModel 子类）
- 支持多环境（dev/prod/test）独立配置
- bucket 名称通过配置文件管理，满足 FR-030 要求

**配置结构**:
```yaml
minio:
  endpoint: "127.0.0.1:9000"
  access_key: "[REDACTED]"
  secret_key: "[REDACTED]"
  secure: false
  bucket: "myknowlege"
```

## R3: 文件在 MinIO 中的存储路径结构

**Decision**: 使用 `{kb_id}/{folder_id}/{document_id}/{filename}` 路径结构

**Rationale**:
- 按知识库→目录→文档三层组织，便于管理和清理
- document_id 保证路径唯一性，避免同名文件冲突
- 删除文档或目录时可按前缀批量删除 MinIO 对象

**Alternatives considered**:
- 扁平存储（`{document_id}/{filename}`）: 简单但无法按目录组织，清理困难
- 用户 ID 前缀（`{user_id}/{kb_id}/...`）: 增加隔离但路径过长，且 user_id 已在 kb 级别保证

## R4: 压缩包解压处理

**Decision**: 后端使用 Python `zipfile`、`tarfile`、`py7zr`、`rarfile` 处理 .zip、.tar.gz、.7z、.rar 压缩包，解压后按原始目录结构递归创建目录和文档记录

**Rationale**:
- `zipfile` 和 `tarfile` 为 Python 标准库，`py7zr` 和 `rarfile` 为轻量第三方库，覆盖主流压缩格式
- 解压后可获取每个文件的相对路径，据此创建对应的目录树结构
- 对每个解压出的文件调用与单文件上传相同的存储逻辑，代码复用度高

**支持的压缩格式**:
- `.zip` → `zipfile` (标准库)
- `.tar.gz` / `.tgz` → `tarfile` (标准库)
- `.7z` → `py7zr` (第三方库)
- `.rar` → `rarfile` (第三方库，需系统安装 unrar)

**处理流程**:
1. 接收上传文件，判断是否为压缩包（按扩展名）
2. 非压缩包 → 直接上传到 MinIO，创建单条文档记录
3. 压缩包 → 临时解压 → 遍历文件树 → 按需创建中间目录 → 每个文件上传 MinIO 并创建文档记录
4. 临时文件清理

## R5: 目录树数据结构

**Decision**: 使用邻接表模型（parent_id 自引用外键）+ order 字段排序

**Rationale**:
- 与项目现有 KnowledgeBase 模型风格一致
- 邻接表模型支持无限层级嵌套，查询父子关系简单
- order 字段用于同级目录排序，拖拽移动时只需更新受影响目录的 parent_id 和 order
- 构建树形结构在前端完成（已有 `buildTree` 工具函数可参考）

**Alternatives considered**:
- 物化路径（path 字段）: 查询后代节点高效，但移动目录需批量更新路径
- 嵌套集（left/right）: 范围查询高效，但插入/移动操作复杂度高

## R6: 前端文档渲染器选型

**Decision**: 复用 MyKnowlegeWebDemo 中已验证的渲染器方案

**Rationale**:
- Markdown: `md-editor-v3` 的 MdPreview 组件，轻量且功能完整
- Office 文档: `@vue-office/docx`, `@vue-office/excel`, `@vue-office/pptx`, `@vue-office/pdf`
- 这些库在 Demo 中已验证可用，且是 Vue 3 生态中最成熟的 Office 渲染方案
- 纯文本: 直接使用 `<pre>` 标签展示

**前端新增依赖**:
```
md-editor-v3
@vue-office/docx
@vue-office/excel
@vue-office/pptx
@vue-office/pdf
```

## R7: 目录同名校验策略

**Decision**: 后端在创建、重命名、移动目录时执行唯一性校验，同一父目录下不允许同名子目录

**Rationale**:
- 数据库层添加 `(kb_id, parent_id, name)` 联合唯一约束保证数据一致性
- 业务层预检查提供友好错误提示
- 拖拽移动时若目标位置存在同名目录，自动重命名（添加数字后缀）并提示用户
- 与项目已有"知识库名称唯一性约束"模式一致

## R8: 前端 Store 设计模式

**Decision**: 新增 `folderStore` 和 `documentStore` 两个 Pinia store，遵循现有 `knowledgeBase.js` 的模式

**Rationale**:
- 与现有 store 模式一致：defineStore + composition API、snake_case → camelCase 转换
- folderStore 管理目录数据（按 kbId 过滤）、选中状态、CRUD 操作
- documentStore 管理文档数据（按 folderId 过滤）、分页、标签操作、文件上传
- 每个 store 对应独立的 API service 文件

## R9: 文件上传方式

**Decision**: 使用 FastAPI 的 `UploadFile` 接收文件，后端流式传输到 MinIO

**Rationale**:
- FastAPI 原生支持 `UploadFile`，通过 `python-multipart` 解析 multipart/form-data
- 对于大文件（最大 500MB），使用流式传输避免内存溢出
- MinIO SDK 的 `put_object` 支持流式上传
- 前端文件大小校验在 `beforeUpload` 钩子中完成（500MB = 524288000 bytes）

**Alternatives considered**:
- 前端直传 MinIO（presigned URL）: 减少后端压力但增加前端复杂度，暂不采用
- 分片上传: 500MB 上限下单次流式上传可接受，分片上传留待后续优化
