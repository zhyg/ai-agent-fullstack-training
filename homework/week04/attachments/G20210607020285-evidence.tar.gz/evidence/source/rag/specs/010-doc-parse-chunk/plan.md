# Implementation Plan: 文档解析与分片

**Branch**: `010-doc-parse-chunk` | **Date**: 2026-11-18 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/010-doc-parse-chunk/spec.md`

## Summary

为知识库系统实现完整的文档解析与分片功能：支持多种文档格式（doc/docx/ppt/pptx/pdf/md/xls/xlsx/csv/图片）的智能解析、可配置的分块策略（按标题切分/按固定长度切分）、图片 OCR 与视觉分析、表格数据 SQLite 存储、AI 问题生成，以及前端分片预览与管理界面。

技术路线：基于 LlamaIndex 的 MarkdownNodeParser 实现分块，通过 MinerU API 进行文档转换和 OCR，通过 LlmGateway 统一调用大模型（Embedding/LLM/视觉模型），使用 Elasticsearch 存储 chunks 和向量，MinIO 存储文件。

## Technical Context

**Language/Version**: Python 3.11 (backend), JavaScript/ES Modules (frontend)

**Primary Dependencies**: FastAPI 0.115, SQLAlchemy 2.0, Pydantic 2.10, LlamaIndex Core, elasticsearch[async] 8.x, httpx 0.28, minio 7.2, Vue 3, Ant Design Vue 4.x, Pinia, md-editor-v3

**Storage**: PostgreSQL (documents 表), Elasticsearch (chunks 索引 `knowledge_chunks_{kb_id}`), MinIO (文件/图片/SQLite db), Redis (状态缓存)

**Testing**: pytest (backend), vitest (frontend)

**Target Platform**: Linux server (backend services), Web browser (frontend SPA)

**Project Type**: web-service (microservices architecture: KnowledgeManage + LlmGateway + MinerU + frontend)

**Performance Goals**: 100 页以内文档 5 分钟内完成全流程处理（解析→分片→向量化→AI问题生成）

**Constraints**: 外部服务不可用时整体失败（严格一致性），表格行原子性不可拆分

**Scale/Scope**: 单知识库数百文档级别，每个文档数百 chunks

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution 文件为模板状态（未填写具体原则），无实际约束门禁。

已确认的项目约定：
- 后端使用 FastAPI + Pydantic，前端使用 Vue3 + Ant Design Vue 4.x
- PostgreSQL schema 隔离架构（`knowledge_manage` schema）
- MinIO 作为对象存储（bucket: `myknowlege`）
- LlmGateway 统一调用大模型服务
- ES 地址配置在 yaml 配置文件中

## Project Structure

### Documentation (this feature)

```text
specs/010-doc-parse-chunk/
├── plan.md              # 本文件
├── research.md          # Phase 0: 技术研究
├── data-model.md        # Phase 1: 数据模型
├── quickstart.md        # Phase 1: 验证指南
├── contracts/           # Phase 1: 接口契约
│   └── document-processing-api.md
└── tasks.md             # Phase 2: 任务列表（/speckit-tasks 生成）
```

### Source Code (repository root)

```text
KnowledgeManage/
├── app/
│   ├── core/
│   │   ├── config.py            # 新增 ES、MinerU 配置
│   │   ├── database.py
│   │   ├── es_client.py         # 新增: Elasticsearch 异步客户端
│   │   ├── minio_client.py
│   │   └── security.py
│   ├── models/
│   │   ├── document.py          # 修改: 扩展 status 字段枚举值
│   │   └── ...
│   ├── schemas/
│   │   ├── document.py          # 修改: 新增 chunk 相关 schema
│   │   └── chunk.py             # 新增: Chunk 相关 Pydantic 模型
│   ├── services/
│   │   ├── document_service.py  # 修改: 上传触发处理流水线
│   │   ├── storage_service.py
│   │   ├── parsing_service.py   # 新增: 文档解析（MinerU 调用、表格预处理）
│   │   ├── chunking_service.py  # 新增: 分块策略实现
│   │   ├── embedding_service.py # 新增: 向量生成（LlmGateway 调用）
│   │   ├── image_service.py     # 新增: 图片 OCR/Caption 处理
│   │   ├── table_service.py     # 新增: 表格 SQLite 存储
│   │   ├── ai_question_service.py # 新增: AI 问题生成
│   │   └── es_chunk_service.py  # 新增: ES chunks CRUD
│   ├── routers/
│   │   ├── documents.py         # 修改: 新增分片查询/配置接口
│   │   └── chunks.py            # 新增: Chunk 查询路由
│   └── ...
├── alembic/versions/            # 新增: Document 表迁移
├── config.dev.yaml              # 修改: 新增 es、mineru 配置段
└── requirements.txt             # 修改: 新增依赖

frontend/
├── src/
│   ├── components/
│   │   └── knowledge/
│   │       ├── DocumentDetailDrawer.vue  # 修改: 新增分片/配置 tab
│   │       ├── ChunkListPanel.vue        # 新增: 分片列表面板
│   │       ├── ChunkSettingTab.vue       # 新增: 分块设置 tab
│   │       ├── AiQuestionTab.vue         # 新增: AI问题生成 tab
│   │       └── ChunkCard.vue             # 新增: 单个分片卡片
│   ├── services/
│   │   ├── documentApi.js       # 修改: 新增分片/配置相关 API
│   │   └── chunkApi.js          # 新增: Chunk 查询 API
│   ├── stores/
│   │   ├── document.js          # 修改: 新增分片状态管理
│   │   └── chunk.js             # 新增: Chunk store
│   └── ...
└── package.json                 # 无新增依赖
```

**Structure Decision**: Web application 架构，KnowledgeManage 服务处理后端逻辑（文档处理流水线、ES/MinIO 交互），frontend 处理前端交互（分块设置 UI、分片展示、AI问题查看）。

## Complexity Tracking

无 Constitution 违规项。
