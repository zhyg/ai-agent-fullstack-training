# Quickstart: LLM Gateway 支持 Embedding、Rerank、视觉模型

**Feature**: 009-gateway-embedding-rerank-vision

## 前置条件

1. LlmGateway 服务已启动（`docker-compose up` 或本地 `uvicorn`）
2. PostgreSQL 已完成迁移（执行 alembic upgrade）
3. 已在管理面板或通过 API 配置了以下模型：
   - 一个 Embedding 模型（如 `BAAI/bge-m3`，category=embedding）
   - 一个 Rerank 模型（如 `BAAI/bge-reranker-v2-m3`，category=rerank）
   - 一个 Vision 模型（如 `Qwen3-VL-8B`，`category=vision`，默认支持文本和图片）
4. 有效的 API Key（Bearer Token）

## 验证场景

### V-001: Embedding 单条文本

```bash
curl -X POST http://localhost:8003/api/llm/v1/embeddings \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "BAAI/bge-m3",
    "input": "你好世界"
  }'
```

**预期**: 返回 200，`data` 数组包含 1 个向量，`usage.prompt_tokens > 0`

### V-002: Embedding 批量文本

```bash
curl -X POST http://localhost:8003/api/llm/v1/embeddings \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "BAAI/bge-m3",
    "input": ["你好", "世界", "测试"]
  }'
```

**预期**: 返回 200，`data` 数组包含 3 个向量，索引 0/1/2 对应输入顺序

### V-003: Embedding 模型类型不匹配

```bash
curl -X POST http://localhost:8003/api/llm/v1/embeddings \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o",
    "input": "test"
  }'
```

**预期**: 返回 404，错误信息提示模型类型不匹配

### V-004: Rerank 基本调用

```bash
curl -X POST http://localhost:8003/api/llm/v1/rerank \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "BAAI/bge-reranker-v2-m3",
    "query": "什么是机器学习？",
    "documents": ["机器学习是一种AI技术", "深度学习是机器学习的子集", "NLP处理自然语言"],
    "top_n": 2,
    "return_documents": true
  }'
```

**预期**: 返回 200，`results` 数组最多 2 条，按 `relevance_score` 降序

### V-005: Rerank 文档列表为空

```bash
curl -X POST http://localhost:8003/api/llm/v1/rerank \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "BAAI/bge-reranker-v2-m3",
    "query": "test",
    "documents": []
  }'
```

**预期**: 返回 400，参数校验错误

### V-006: Vision 图片理解（URL）

注册表按「模型名或显示名 + 分类」查找。`/v1/chat/completions` 的图片请求优先使用 `vision`，纯文本请求优先使用 `chat`；若仅配置了另一分类，仍按其实际输入能力处理。Embedding 和 Rerank 只查找各自的分类。

```bash
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-VL-8B-Instruct",
    "messages": [
      {
        "role": "user",
        "content": [
          {"type": "text", "text": "描述这张图片"},
          {"type": "image_url", "image_url": {"url": "https://img1.baidu.com/it/u=1966616150,2146512490&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500"}}
        ]
      }
    ]
  }'
```

**预期**: 返回 200，模型返回对图片的文字描述

### V-007: 纯文本模型拒绝图片请求

```bash
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-VL-8B-Instruct",
    "messages": [
      {
        "role": "user",
        "content": [
          {"type": "text", "text": "描述这张图片"},
          {"type": "image_url", "image_url": {"url": "https://example.com/photo.jpg"}}
        ]
      }
    ]
  }'
```

```bash
# 下载图片并转 base64
BASE64=$(curl -sL "https://img1.baidu.com/it/u=1966616150,2146512490&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" | base64)

curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d "{
    \"model\": \"Qwen/Qwen3-VL-8B-Instruct\",
    \"messages\": [
      {
        \"role\": \"user\",
        \"content\": [
          {\"type\": \"text\", \"text\": \"描述这张图片\"},
          {\"type\": \"image_url\", \"image_url\": {\"url\": \"data:image/jpeg;base64,$BASE64\"}}
        ]
      }
    ]
  }"
```

**预期**: 返回 400，错误信息提示该模型不支持图片输入

### V-008: Vision 模型纯文本请求

```bash
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-VL-8B-Instruct",
    "messages": [
      {"role": "user", "content": "你好，请介绍一下自己"}
    ]
  }'
```

**预期**: 返回 200，模型正常回答（Vision 模型可以处理纯文本）

### V-009: 向后兼容性验证

```bash
curl -X POST http://localhost:8003/api/llm/v1/chat/completions \
  -H "Authorization: Bearer [REDACTED_API_TOKEN]" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-VL-8B-Instruct",
    "messages": [
      {"role": "system", "content": "你是一个助手"},
      {"role": "user", "content": "1+1等于几？"}
    ],
    "stream": false
  }'
```

**预期**: 返回 200，响应格式与升级前完全一致

### V-010: Prometheus 指标验证

```bash
# 执行若干 Embedding/Rerank 请求后
curl http://localhost:8003/metrics | grep "llm_request_total"
```

**预期**: 指标中包含 `category` 标签，值为对应的 `chat`/`embedding`/`rerank`

## 管理面板验证

### V-011: 添加 Embedding 模型

1. 登录管理面板 → 模型管理
2. 点击"添加模型"
3. 选择 category=embedding，填写 name、provider、url、api_key
4. 填写 dimensions=1536
5. 保存

**预期**: 保存成功，列表中显示新模型，dimensions 字段可见

### V-012: 表单动态字段

1. 在模型管理页面，切换 category 下拉框
2. 观察表单字段变化

**预期**:
- 选择 embedding 时，显示 dimensions 字段
- 选择 vision 时，无需配置输入模态
- 选择 chat/rerank 时，隐藏上述专属字段
