# API Contract: Embedding

**Endpoint**: `POST /api/llm/v1/embeddings`
**Auth**: Bearer Token (API Key)
**Protocol**: OpenAI Embeddings 兼容

## Request

### Headers

```
Authorization: Bearer <api_key>
Content-Type: application/json
```

### Body

```json
{
  "model": "text-embedding-3-small",
  "input": "你好世界",
  "dimensions": 1536
}
```

| Field | Type | Required | Constraints | Description |
|---|---|---|---|---|
| `model` | string | Yes | 已配置的 embedding 类型模型 | 模型 display name |
| `input` | string \| string[] | Yes | 最多 2048 条 | 输入文本 |
| `dimensions` | integer | No | 正整数 | 覆盖模型默认输出维度 |

### 校验规则

- `input` 为 list 时，最多 2048 条
- `input` 为 list 时，不能为空列表
- `model` 必须对应 `category=embedding` 的模型，否则返回 404
- 请求体不超过 1MB

## Response

### 200 OK

```json
{
  "object": "list",
  "data": [
    {
      "object": "embedding",
      "index": 0,
      "embedding": [0.1, 0.2, 0.3]
    }
  ],
  "model": "text-embedding-3-small",
  "usage": {
    "prompt_tokens": 5,
    "total_tokens": 5
  }
}
```

| Field | Type | Description |
|---|---|---|
| `object` | string | 固定 `"list"` |
| `data` | array | 向量数据列表，索引与输入一致 |
| `data[].object` | string | 固定 `"embedding"` |
| `data[].index` | integer | 对应输入文本的索引 |
| `data[].embedding` | float[] | 向量数组 |
| `model` | string | 实际使用的模型名 |
| `usage.prompt_tokens` | integer | 输入 token 数 |
| `usage.total_tokens` | integer | 总 token 数 |

### Error Responses

| Status | Code | Condition |
|---|---|---|
| 400 | `invalid_request` | input 为空或超过 2048 条 |
| 401 | `invalid_api_key` | API Key 无效 |
| 404 | `model_not_found` | 模型不存在或 category 不匹配 |
| 429 | `rate_limit_exceeded` | 超过模型 RPM/TPM 限制 |
| 502 | `upstream_error` | 供应商返回错误 |
| 504 | `upstream_timeout` | 供应商超时 |
