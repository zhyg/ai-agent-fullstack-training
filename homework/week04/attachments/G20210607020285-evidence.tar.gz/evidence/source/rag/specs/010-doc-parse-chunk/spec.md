# Feature Specification: 文档解析与分片

**Feature Branch**: `010-doc-parse-chunk`

**Created**: 2026-11-18

**Status**: Draft

**Input**: User description: "文档解析、分片策略 — 支持多种文档类型的智能解析、可配置分块策略、AI问题生成及数据持久化"

## Clarifications

### Session 2026-11-18

- Q: 文档多阶段处理中某一步骤失败时，系统应如何处理已生成的中间数据？ → A: 标记文档为"处理失败"，清理所有已生成的中间数据（chunks、文件），用户需重新上传
- Q: 用户重新上传一个已存在的同名文档时，系统应如何处理？ → A: 覆盖替换：删除旧文档及其所有关联数据（chunks、文件），用新文档重新处理
- Q: 处理过程中外部服务（MinerU、图片识别模型、大模型）不可用时，系统应如何处理？ → A: 整体失败：任一外部服务不可用则整个文档处理失败，不进入后续阶段
- Q: documents表中的文档处理状态应如何追踪？ → A: 细粒度状态：pending（待处理）、parsing（解析中）、chunking（分片中）、embedding（向量化中）、ai_generating（AI问题生成中）、completed（已完成）、failed（失败）
- Q: 压缩包中包含不支持的文件类型时，系统应如何处理？ → A: 跳过并通知：跳过不支持的文件，正常处理支持的文件，处理完成后提示用户哪些文件被跳过

## User Scenarios & Testing *(mandatory)*

### User Story 1 - 单文档上传与自定义分片 (Priority: P1)

用户上传单个文档（doc/docx/ppt/pptx/pdf/md）到知识库，系统自动解析文档内容，按用户选择的分块策略（按标题切分或按固定长度切分）进行分片，将分片数据和向量存储到ES中，原始文件和转换后的markdown存储到MinIO中。用户可在前端设置分块大小、分块重叠、分隔符等参数。

**Why this priority**: 这是知识库文档管理的核心功能，用户需要能够将文档导入知识库并进行智能分片，是后续检索和问答的基础。

**Independent Test**: 上传一个PDF文档，设置"按标题切分"策略，验证分片结果按标题层级正确切分，前端可浏览每个分片内容。

**Acceptance Scenarios**:

1. **Given** 用户在知识库文档上传页面, **When** 上传单个doc/docx/ppt/pptx/pdf文件并选择"按标题切分"策略, **Then** 系统将文档转换为markdown，按标题层级切分为多个text chunk，每个chunk前附带文件名，分片数据存入ES，原始文件和markdown存入MinIO
2. **Given** 用户上传单个文档, **When** 选择"按固定长度切分"策略并设置分块大小为1000、分块重叠为150, **Then** 系统按设置的参数将文档切分为固定长度片段，相邻片段间有150字符重叠
3. **Given** 用户上传单个md文件, **When** 系统处理该文件, **Then** 不调用MinerU转换（已是markdown），直接将md中的本地/嵌入式图片链接替换为MinIO地址，按标题切分进行分片
4. **Given** 用户在前端"分块设置"页面, **When** 查看分块参数, **Then** 可看到分块策略（下拉框）、分块大小（数字框100-4000，默认512）、分块重叠（数字框0-500，默认80）、分隔符（多选下拉框）及其说明信息
5. **Given** 文档解析处理完成, **When** 用户在前端查看文档, **Then** "原始内容"展示原始文档预览，"解析后Markdown"展示转换后的markdown，"文档分片"展示所有分片内容

---

### User Story 2 - 文档中图片的处理 (Priority: P2)

用户上传的文档中包含图片时，系统自动处理图片：图片的markdown引用保留在text/table_row chunk中，同时对每张图片调用MinerU进行OCR识别、调用知识库配置的图片识别模型进行分析，生成image_ocr和image_caption子chunk。

**Why this priority**: 文档中的图片承载重要信息，需要被正确解析和索引以支持后续检索，是完整文档理解的关键组成部分。

**Independent Test**: 上传包含图片的文档，验证图片的markdown引用保留在text chunk中，image_ocr和image_caption子chunk已生成并关联到正确的父chunk。

**Acceptance Scenarios**:

1. **Given** 用户上传的docx文档中包含3张图片, **When** 系统解析该文档, **Then** 图片的 `![](url)` 引用保留在所属text chunk的content中，text chunk的image_url字段记录所有图片地址列表
2. **Given** 文档中的某张图片被MinerU OCR识别, **When** OCR处理完成, **Then** 生成chunk_type为"image_ocr"的子chunk，其parent_chunk_id指向包含该图片的text chunk，image_url为该图片地址
3. **Given** 文档中的某张图片被图片识别模型分析, **When** 分析完成, **Then** 生成chunk_type为"image_caption"的子chunk，其parent_chunk_id指向包含该图片的text chunk
4. **Given** 前端展示文档分片, **When** 某个text chunk包含图片, **Then** content中的 `![](url)` 渲染为图片展示，同时展示该图片关联的image_ocr和image_caption结果

---

### User Story 3 - 文档中表格的处理 (Priority: P2)

文档中的表格经过预处理（HTML/Markdown转为逐行文本格式），表格行作为原子单元按分块大小动态分配到多个chunk中，每个表格的完整数据同时存储到SQLite数据库中，支持后续查询和分析。

**Why this priority**: 表格数据是结构化信息的重要载体，需要保证行的完整性和可查询性。

**Independent Test**: 上传包含HTML和Markdown表格的文档，验证表格行文本正确预处理、行不拆分、SQLite数据完整可查询。

**Acceptance Scenarios**:

1. **Given** 文档中包含HTML表格, **When** 系统预处理表格, **Then** HTML表格转换为"列名: 值, 列名: 值"格式的逐行文本，包裹在TABLE_START/TABLE_END标记中
2. **Given** 文档中包含Markdown管道表格, **When** 系统预处理表格, **Then** 管道表格同样转换为逐行文本格式
3. **Given** 表格某行超过分块大小上限, **When** 分块处理时, **Then** 该行作为原子单元保持完整，不从中间截断（允许该chunk超过分块大小限制）
4. **Given** 表格行文本被分配到多个chunk中, **When** 处理完成, **Then** 多个chunk关联同一个MinIO中的SQLite db文件，每个chunk的content前部包含表名和sheet名信息
5. **Given** 表格数据需要存储到SQLite, **When** 处理表格时, **Then** 按sheet动态建表，中文表名/列名转为英文（中文保留为描述信息），db文件存储在MinIO中，chunk的sqlite_url字段记录db地址
6. **Given** 表格行内包含图片, **When** 分块处理时, **Then** 图片URL信息保留在表格行chunk中

---

### User Story 4 - 独立图片上传与处理 (Priority: P2)

用户直接上传单张图片（png/jpg/jpeg/jp2/webp/gif/bmp）或包含图片的压缩包（.zip/.tar.gz/.rar/.7z），系统为每张图片生成image chunk、image_ocr chunk和image_caption chunk。

**Why this priority**: 图片是独立的知识点载体，需要被完整识别和索引。

**Independent Test**: 上传单张图片，验证image chunk、image_ocr chunk和image_caption chunk均正确生成，parent关系正确。

**Acceptance Scenarios**:

1. **Given** 用户上传单张图片, **When** 系统处理该图片, **Then** 图片存储到MinIO，生成chunk_type为"image"的chunk（parent_chunk_id为null），content使用 `![](url)` 语法，image_url为图片地址
2. **Given** 图片上传完成, **When** MinerU OCR识别完成, **Then** 生成image_ocr子chunk，parent_chunk_id指向image chunk
3. **Given** 图片上传完成, **When** 图片识别模型分析完成, **Then** 生成image_caption子chunk，parent_chunk_id指向image chunk
4. **Given** 用户上传压缩包且包含多张图片, **When** 解压处理, **Then** 压缩包中每张图片按独立图片处理流程处理
5. **Given** 前端展示单个图片文档, **When** 查看"原始内容"和"解析后Markdown", **Then** 两处均展示原始图片（不展示markdown文件）

---

### User Story 5 - 独立表格文件上传 (Priority: P2)

用户上传表格文件（xls/xlsx/csv），系统校验表格格式，将完整数据存储到SQLite中，按sheet将行数据切分为table_row chunk。

**Why this priority**: 表格文件是常见数据格式，需要支持独立上传和检索。

**Independent Test**: 上传xlsx文件，验证SQLite数据完整、table_row chunk正确生成、前端展示表格数据。

**Acceptance Scenarios**:

1. **Given** 用户上传xlsx文件, **When** 系统校验通过, **Then** 完整数据存储到SQLite（按sheet建表），db文件存入MinIO
2. **Given** 表格包含多个sheet, **When** 切分处理, **Then** 每个sheet的行按分块大小动态切分为table_row chunk，单行不拆分，每个chunk前部包含表名和sheet名
3. **Given** 表格有合并单元格, **When** 系统校验, **Then** 校验失败，提示"表格不能有合并单元格"
4. **Given** 表格表头不在第一行或存在空行, **When** 系统校验, **Then** 校验失败，提示相应错误信息
5. **Given** 前端展示表格文档, **When** 查看"原始内容"和"解析后Markdown", **Then** 两处均展示原始表格（不展示markdown文件）

---

### User Story 6 - AI问题生成 (Priority: P3)

文档分片完成后，系统根据用户设置的问题数量，为text、image_ocr、table_row类型的chunk调用大模型生成AI问题，问题作为独立的ai_question chunk存储。

**Why this priority**: AI问题生成增强检索效果（query expansion），提升知识库问答质量，属于增值功能。

**Independent Test**: 上传文档后设置AI问题数为3，验证每个text/image_ocr/table_row chunk生成3个ai_question子chunk。

**Acceptance Scenarios**:

1. **Given** 文档分片完成且用户设置AI问题数为3, **When** AI问题生成处理, **Then** 每个text、image_ocr、table_row类型的chunk生成3个ai_question chunk
2. **Given** AI问题生成完成, **When** 查看ai_question chunk, **Then** parent_chunk_id指向原始分片chunk，content存储生成的问题文本，embeddings字段包含向量数据
3. **Given** 存在image chunk和image_caption chunk, **When** AI问题生成处理, **Then** image和image_caption类型的chunk不参与AI问题生成
4. **Given** 前端展示文档分片, **When** 用户点击某个分片的右上角, **Then** 可查看该分片对应的AI问题列表

---

### User Story 7 - 压缩包批量上传 (Priority: P3)

用户上传压缩包（.zip/.tar.gz/.rar/.7z），系统解压后根据每个文件的类型自动应用对应的默认分块策略，用户不可自定义分片参数。

**Why this priority**: 批量上传提升效率，但使用默认策略，适用于快速导入场景。

**Independent Test**: 上传包含docx、xlsx、png的zip压缩包，验证各文件按自身类型使用默认策略处理。

**Acceptance Scenarios**:

1. **Given** 用户上传.zip压缩包, **When** 系统解压处理, **Then** 每个文件按自身类型使用默认分块策略（doc/docx/md → 按标题切分，xls/xlsx/csv → 表格行分片，图片 → 图片chunk）
2. **Given** 用户上传压缩包, **When** 在前端设置分片策略, **Then** 不显示分块设置选项（压缩包中文件类型多样，使用各自默认策略）
3. **Given** 压缩包中包含嵌套目录, **When** 解压处理, **Then** 递归处理所有目录中的文件

---

### Edge Cases

- 分块大小设置为最小值100时，系统能否正确处理大量小分片？
- 超大文档（如500页PDF）的处理是否分阶段进行，前端是否显示各阶段进度而非一直显示"处理中"？ → 已澄清：通过document表细粒度状态字段分阶段展示进度（见Key Entities - Document）
- 文档中仅包含图片无文本时，是否能正确处理？
- 表格行文本极长（超过10000字符）时，是否保持行完整性？
- MinerU服务不可用时，图片OCR和文档转换的降级处理？ → 已澄清：整体失败，不进入后续阶段（见FR-039、FR-041）
- 图片识别模型服务不可用时，image_caption chunk的降级处理？ → 已澄清：整体失败，不进入后续阶段（见FR-039、FR-041）
- 压缩包中包含不支持的文件类型时，是否跳过并提示用户？ → 已澄清：跳过不支持的文件，正常处理支持的文件，处理完成后提示用户哪些文件被跳过（见FR-042）
- 表名为中文时，SQLite表名转英文的准确性如何保证？
- 文档处理过程中用户取消操作，已生成的数据如何清理？ → 已澄清：标记为"处理失败"并清理所有中间数据（见FR-039）

## Requirements *(mandatory)*

### Functional Requirements

**文档上传与存储**

- **FR-001**: 系统 MUST 支持上传doc/docx/ppt/pptx/pdf/md/xls/xlsx/csv格式的单文件或压缩包（.zip/.tar.gz/.rar/.7z）
- **FR-002**: 系统 MUST 支持上传单张或压缩包中的图片（png/jpg/jpeg/jp2/webp/gif/bmp）
- **FR-003**: 系统 MUST 将原始文件存储到MinIO，并在documents表中记录文件信息用于前端预览

**文档解析**

- **FR-004**: 系统 MUST 对doc/docx/ppt/pptx/pdf文件调用MinerU API转换为markdown，并将转换后的markdown和图片存储到MinIO，md中的本地/嵌入式图片链接替换为MinIO地址（外部URL保持原样）
- **FR-005**: 系统 MUST 对md文件直接使用原始内容，不调用MinerU转换，仅将本地/嵌入式图片链接替换为MinIO地址
- **FR-006**: 系统 MUST 对HTML表格进行预处理，转换为"列名: 值, 列名: 值"格式的逐行文本
- **FR-007**: 系统 MUST 对Markdown管道表格进行预处理，转换为同样的逐行文本格式
- **FR-008**: 系统 MUST 对表格文件（xls/xlsx/csv）进行校验：不能有合并单元格、表头必须在第一行、不能有空行

**分块策略**

- **FR-009**: 系统 MUST 提供"按标题切分"策略，利用MarkdownNodeParser按标题层级（#/##/###）切分，大片段自动按分隔符二次切分
- **FR-010**: 系统 MUST 提供"按固定长度切分"策略，根据用户设置的分块大小、重叠、分隔符进行切分
- **FR-011**: 系统 MUST 支持用户配置分块大小（范围100-4000，默认512）
- **FR-012**: 系统 MUST 支持用户配置分块重叠（范围0-500，默认80）
- **FR-013**: 系统 MUST 支持用户配置分隔符（多选，优先级：双换行 > 单换行 > 中文句号 > 中文分号 > 中文问号 > 中文感叹号 > 英文句号 > 英文分号 > 英文问号 > 英文感叹号）
- **FR-014**: 系统 MUST 将表格行作为绝对原子单元，不从中间截断，即使单行超过分块大小上限也保持完整
- **FR-015**: 系统 MUST 在每个分块的最前面添加文件名，方便识别

**图片处理**

- **FR-016**: 系统 MUST 将文档中的图片的markdown引用 `![](url)` 保留在所属text/table_row chunk的content中，不提取为独立image chunk
- **FR-017**: 系统 MUST 对文档中的每张图片调用MinerU API进行OCR识别，生成image_ocr子chunk（parent_chunk_id指向包含图片的text/table_row chunk）
- **FR-018**: 系统 MUST 对文档中的每张图片调用知识库配置的图片识别模型进行分析，生成image_caption子chunk（parent_chunk_id指向包含图片的text/table_row chunk）
- **FR-019**: 系统 MUST 对独立上传的图片生成image chunk（parent_chunk_id为null），以及image_ocr和image_caption子chunk（parent_chunk_id指向image chunk）
- **FR-020**: 系统 MUST 将独立上传的图片存储到MinIO

**表格处理**

- **FR-021**: 系统 MUST 将每个表格的完整数据存储到SQLite数据库，按sheet动态建表
- **FR-022**: 系统 MUST 将中文表名和列名转换为英文（中文保留为描述信息），表名转换调用大模型生成英文表名
- **FR-023**: 系统 MUST 将SQLite db文件存储到MinIO，chunk的sqlite_url字段记录db地址
- **FR-024**: 系统 MUST 将表格行文本按分块大小动态分配到多个chunk（累积达到分块大小时切分，单行不拆分）
- **FR-025**: 同一表格的多个table_row chunk MUST 关联同一个MinIO中的SQLite db文件

**AI问题生成**

- **FR-026**: 系统 MUST 为text、image_ocr、table_row类型的chunk调用大模型生成AI问题
- **FR-027**: 系统 MUST 支持用户配置每个chunk生成的AI问题数量（范围1-10，默认3）
- **FR-028**: 系统 MUST 将生成的AI问题存储为独立的ai_question chunk，parent_chunk_id指向原始分片chunk
- **FR-029**: image chunk和image_caption chunk MUST NOT 参与AI问题生成

**数据存储**

- **FR-030**: 系统 MUST 将chunks数据存储在Elasticsearch的 `knowledge_chunks_{knowledge_id}` 索引中
- **FR-031**: 系统 MUST 为每个chunk生成embeddings向量数据
- **FR-032**: 系统 MUST 将原始文件、转换后的markdown、SQLite db文件、图片等存储在MinIO中

**前端交互**

- **FR-033**: 单文件上传时，系统 MUST 展示"分块设置"tab页，包含分块策略、分块大小、分块重叠、分隔符配置项及各自的说明信息
- **FR-034**: 系统 MUST 展示"AI问题生成"tab页，包含AI生成问题数配置项及说明信息
- **FR-035**: 压缩包上传时，系统 MUST NOT 展示分块设置选项
- **FR-036**: 文档分片展示中，text/table_row chunk中的 `![](url)` MUST 渲染为图片展示，同时展示关联的image_ocr和image_caption子chunk
- **FR-037**: 前端 MUST 支持点击分片右上角查看该分片对应的AI问题
- **FR-038**: 文档处理过程 MUST 分阶段展示进度，不能一直显示"处理中"
- **FR-039**: 文档多阶段处理中任一步骤失败时，系统 MUST 将文档标记为"处理失败"，清理所有已生成的中间数据（包括ES中的chunks、MinIO中的文件），用户需重新上传
- **FR-040**: 用户重新上传已存在的同名文档时，系统 MUST 覆盖替换：删除旧文档及其所有关联数据（ES chunks、MinIO文件、SQLite db），用新文档重新处理
- **FR-041**: 处理过程中任一外部服务（MinerU、图片识别模型、大模型）不可用或调用失败时，系统 MUST 终止处理并标记文档为"处理失败"，不进入后续阶段，按FR-039清理中间数据
- **FR-042**: 压缩包中包含不支持的文件类型时，系统 MUST 跳过不支持的文件，正常处理支持的文件，处理完成后提示用户哪些文件被跳过

### Key Entities

- **Chunk（分片）**: 文档的最小检索单元。关键属性：chunk_type（text/image/image_ocr/image_caption/table_row/ai_question）、content（文本内容）、image_url（图片地址，可为列表或单个）、parent_chunk_id（父级chunk引用）、embeddings（向量数据）、sqlite_url（关联的SQLite db地址）
- **Document（文档）**: 用户上传的原始文件实体。关联多个Chunk，存储在MinIO中，信息记录在documents表中。包含处理状态字段（status），取值为：pending、parsing、chunking、embedding、ai_generating、completed、failed
- **Knowledge Base（知识库）**: 文档的组织容器，每个知识库配置独立的向量模型，对应独立的ES索引
- **SQLite Database（表格数据库）**: 表格完整数据的存储载体，按sheet建表，存储在MinIO中，被table_row chunk引用

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 用户上传100页以内的文档后，5分钟内可在前端查看所有分片结果
- **SC-002**: 分片结果中，表格行完整性达到100%（无任何表格行被中间截断）
- **SC-003**: 文档中包含的图片100%生成对应的image_ocr和image_caption子chunk
- **SC-004**: 表格文件中的数据可通过SQLite完整查询，与原始表格数据一致
- **SC-005**: AI问题生成覆盖所有text、image_ocr、table_row类型的chunk，无遗漏
- **SC-006**: 前端可正确展示所有分片内容，包括图片渲染和子chunk关联展示
- **SC-007**: 用户自定义分块参数（大小、重叠、分隔符）后，分片结果准确反映用户设置
- **SC-008**: 文档处理过程分阶段展示，用户可了解当前处理阶段（如"解析中"、"分片中"、"生成向量中"、"AI问题生成中"）

## Assumptions

- 用户已配置好知识库及对应的向量模型（Embedding模型）
- MinerU服务已部署且可用，提供文档转换和OCR识别能力
- 知识库已配置图片识别模型（视觉模型），用于image_caption生成
- Elasticsearch和MinIO服务已部署且配置正确
- LlmGateway服务可用于AI问题生成（调用大模型）
- 文档中表格的中文表名/列名转英文依赖大模型能力，可能存在翻译不准确的情况
- 前端技术栈为Vue3 + Ant Design Vue 4.x
- 后端为KnowledgeManage服务（FastAPI），代码写在frontend和KnowledgeManage服务中
- ES地址为 http://localhost:9200，用户名/密码为 elastic/123456
