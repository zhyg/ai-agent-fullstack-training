# Implementation Plan: 知识库中文档管理

**Branch**: `008-knowledge-doc-management` | **Date**: 2026-11-16 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/008-knowledge-doc-management/spec.md`

## Summary

为知识库实现完整的文档管理功能：后端在 KnowledgeManage 服务中新增目录（Folder）和文档（Document）的 CRUD API、文件上传到 MinIO 对象存储、压缩包自动解压；前端在 frontend 模块中新增知识库详情页，包含目录树导航、文档列表表格、文档上传、文档详情预览等交互组件。

## Technical Context

**Language/Version**: Python 3.11 (后端), Node.js 26 + Vue 3.5 (前端)

**Primary Dependencies**:
- 后端: FastAPI 0.115.6, SQLAlchemy 2.0.36, Pydantic 2.10.3, minio-py (新增), python-multipart
- 前端: Vue 3.5.44, Vue Router 4.6.4, Pinia 2.3.1, Ant Design Vue 4.2.6, axios, md-editor-v3, @vue-office/docx|excel|pptx|pdf (新增)

**Storage**: PostgreSQL (schema: knowledge_manage) + MinIO 对象存储 (bucket: myknowlege)

**Testing**: pytest (后端), vitest (前端)

**Target Platform**: Linux server (后端), 浏览器 SPA (前端)

**Project Type**: web-service (微服务架构)

**Performance Goals**: 页面加载 <3s, 列表操作 <1s, 文件上传 50MB <1min

**Constraints**: 单文件上限 500MB, 一次仅上传一个文件

**Scale/Scope**: 单用户知识库级别管理, 文档解析功能暂不实现

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution 文件 (`.specify/memory/constitution.md`) 为未填写的模板，无强制约束。项目遵循以下既有约定：
- 后端使用 FastAPI + Pydantic V2 模式
- 前端使用 Vue 3 + Ant Design Vue 4.x
- API 参数校验通过 Pydantic Model
- 所有更新操作携带 ID 路径参数
- 前端组件优先使用 Ant Design Vue 组件

**Gate 结果**: PASS — 无违例

## Project Structure

### Documentation (this feature)

```text
specs/008-knowledge-doc-management/
├── plan.md              # This file
├── spec.md              # Feature specification
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   ├── folder-api.md
│   └── document-api.md
├── checklists/
│   └── requirements.md
└── tasks.md             # Phase 2 output (/speckit-tasks command)
```

### Source Code (repository root)

```text
KnowledgeManage/                    # 后端服务
├── alembic/
│   └── versions/                   # 数据库迁移脚本
│       └── xxx_add_folders_documents.py
├── app/
│   ├── core/
│   │   ├── config.py               # 新增 MinioConfig 配置类
│   │   └── minio_client.py         # [NEW] MinIO 客户端封装
│   ├── models/
│   │   ├── folder.py               # [NEW] Folder SQLAlchemy 模型
│   │   └── document.py             # [NEW] Document SQLAlchemy 模型
│   ├── routers/
│   │   ├── folders.py              # [NEW] 目录 CRUD 路由
│   │   └── documents.py            # [NEW] 文档 CRUD + 上传路由
│   ├── schemas/
│   │   ├── folder.py               # [NEW] 目录 Pydantic 模型
│   │   └── document.py             # [NEW] 文档 Pydantic 模型
│   ├── services/
│   │   ├── folder_service.py       # [NEW] 目录业务逻辑
│   │   ├── document_service.py     # [NEW] 文档业务逻辑
│   │   └── storage_service.py      # [NEW] MinIO 文件存储逻辑
│   ├── main.py                     # 注册新路由
│   └── dependencies.py             # 复用
├── config.dev.yaml                  # 新增 minio 配置段
├── config.prod.yaml
└── requirements.txt                 # 新增 minio 依赖

frontend/                           # 前端模块
├── src/
│   ├── components/
│   │   └── knowledge/              # [NEW] 知识库文档管理组件
│   │       ├── FolderTree.vue
│   │       ├── FolderActionModal.vue
│   │       ├── DocumentTable.vue
│   │       ├── DocumentCreateModal.vue
│   │       ├── DocumentDetailDrawer.vue
│   │       └── DocumentActionModal.vue
│   ├── stores/
│   │   ├── folder.js               # [NEW] 目录状态管理
│   │   └── document.js             # [NEW] 文档状态管理
│   ├── services/
│   │   └── documentApi.js          # [NEW] 文档/目录 API 服务
│   ├── views/
│   │   ├── KnowledgeManagement.vue # [NEW] 知识库详情页视图
│   │   └── KnowledgeBaseManagement.vue  # 修改 handleEnter 导航
│   ├── router/
│   │   └── index.js                # 新增知识库详情路由
│   └── utils/
│       └── file.js                 # [NEW] 文件大小格式化、渲染器类型判断
├── package.json                     # 新增 vue-office 等依赖
└── vite.config.js                   # pdfjs worker 配置(如需)
```

**Structure Decision**: Web application 模式 — 后端 KnowledgeManage 服务 + 前端 frontend 模块，遵循项目现有微服务架构

## Complexity Tracking

> 无违例需要说明
