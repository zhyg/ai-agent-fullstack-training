# Data Model: LLM Gateway 支持 Embedding、Rerank、视觉模型

**Feature**: 009-gateway-embedding-rerank-vision
**Date**: 2026-11-17

## Entity: Model (数据库表: models)

现有模型配置实体，新增 3 个 nullable 字段以支持多类型模型。

### 字段定义

| 字段 | 类型 | 约束 | 说明 | 变更 |
|---|---|---|---|---|
| `id` | `VARCHAR(36)` | PK, UUID | 主键 | 不变 |
| `name` | `VARCHAR(100)` | NOT NULL | 模型标识名称（供应商侧） | 不变 |
| `display_name` | `VARCHAR(200)` | nullable | 前端显示名称 | 不变 |
| `category` | `VARCHAR(20)` | NOT NULL, default='chat' | 模型分类：chat/embedding/rerank/vision/speech | 不变（已有字段，参与路由） |
| `provider` | `VARCHAR(100)` | NOT NULL | 供应商标识（openai/anthropic/cohere） | 不变 |
| `url` | `VARCHAR(500)` | NOT NULL | Base URL（如 `https://api.openai.com/v1`） | 语义调整：统一为 base URL |
| `api_key_encrypted` | `TEXT` | NOT NULL | Fernet 加密后的 API Key | 不变 |
| `context_tokens` | `INTEGER` | NOT NULL | 上下文窗口大小 | 不变 |
| `rpm` | `INTEGER` | NOT NULL | Rate Limit: Requests Per Minute | 不变 |
| `tpm` | `INTEGER` | NOT NULL | Rate Limit: Tokens Per Minute | 不变 |
| `input_per_million` | `NUMERIC(10,4)` | NOT NULL | 输入 token 价格/百万 | 不变 |
| `output_per_million` | `NUMERIC(10,4)` | NOT NULL | 输出 token 价格/百万（embedding/rerank 填 0） | 不变 |
| `cached_input_per_million` | `NUMERIC(10,4)` | NOT NULL | 缓存命中 token 价格/百万（embedding/rerank 填 0） | 不变 |
| **`dimensions`** | **`INTEGER`** | **nullable** | **Embedding 输出向量维度** | **新增** |
| **`max_input_tokens`** | **`INTEGER`** | **nullable** | **模型单次最大输入 tokens** | **新增** |
| `created_at` | `TIMESTAMP` | NOT NULL | 创建时间 | 不变 |
| `updated_at` | `TIMESTAMP` | NOT NULL | 更新时间 | 不变 |

### 约束

- **唯一约束**: `(provider, name)` — 同一供应商下模型名不重复
- **category 字段专属规则**:
  - `embedding` 模型应填写 `dimensions`
  - `embedding`/`rerank` 模型的 `output_per_million` 和 `cached_input_per_million` 填 0
  - `vision` 模型默认支持文本和图片，无需配置输入模态

### 索引建议

- 现有 `(provider, name)` 唯一约束保留
- 可选：为 `category` 添加普通索引（按类型查询模型列表时使用）

## Entity: EmbeddingRequest (Pydantic Schema)

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `model` | `str` | required | 模型 display name |
| `input` | `Union[str, list[str]]` | required, max 2048 items | 输入文本（单条或多条） |
| `dimensions` | `Optional[int]` | optional | 覆盖模型默认输出维度 |

## Entity: EmbeddingResponse (Pydantic Schema)

| 字段 | 类型 | 说明 |
|---|---|---|
| `object` | `str` | 固定值 `"list"` |
| `data` | `list[EmbeddingData]` | 向量数据列表 |
| `model` | `str` | 实际使用的模型名 |
| `usage` | `UsageInfo` | Token 用量 |

### EmbeddingData

| 字段 | 类型 | 说明 |
|---|---|---|
| `object` | `str` | 固定值 `"embedding"` |
| `index` | `int` | 对应输入文本的索引 |
| `embedding` | `list[float]` | 向量数组 |

## Entity: RerankRequest (Pydantic Schema)

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `model` | `str` | required | 模型 display name |
| `query` | `str` | required, max 10000 chars | 查询文本 |
| `documents` | `list[str]` | required, 1-500 items | 候选文档列表 |
| `top_n` | `Optional[int]` | optional, ge=1 | 返回前 N 条结果 |
| `return_documents` | `bool` | default=True | 是否在响应中返回原文 |

## Entity: RerankResponse (Pydantic Schema)

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | `str` | 请求唯一标识 |
| `results` | `list[RerankResult]` | 按分数降序排列的结果 |
| `model` | `str` | 实际使用的模型名 |
| `usage` | `UsageInfo` | Token 用量 |

### RerankResult

| 字段 | 类型 | 说明 |
|---|---|---|
| `index` | `int` | 原始文档列表中的索引 |
| `relevance_score` | `float` | 相关性分数（降序） |
| `document` | `Optional[dict]` | 文档原文（当 return_documents=True） |

## Entity: ContentPart (Pydantic Schema，扩展 Chat)

| 字段 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `type` | `Literal["text", "image_url"]` | required | 内容类型 |
| `text` | `Optional[str]` | type=text 时必填 | 文本内容 |
| `image_url` | `Optional[dict]` | type=image_url 时必填 | 图片信息 `{"url": "...", "detail": "auto\|low\|high"}` |

## Entity: ModelConfig (运行时 dataclass)

扩展现有 `ModelConfig` dataclass，新增以下字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `category` | `str` | 模型分类，默认 `"chat"` |
| `dimensions` | `Optional[int]` | Embedding 向量维度 |
| `max_input_tokens` | `Optional[int]` | 单次最大输入 tokens |

## 关系

```
Model (DB)  ──1:1──>  ModelConfig (Runtime)
ModelConfig  ──N:1──>  BaseAdapter (by provider)
```

- 每个 Model 记录在启动时加载为一个 ModelConfig
- ModelConfig 通过 provider 字段关联到对应的 BaseAdapter 实现
- 同一 provider 的多个 ModelConfig 共享同一个 Adapter 实例
