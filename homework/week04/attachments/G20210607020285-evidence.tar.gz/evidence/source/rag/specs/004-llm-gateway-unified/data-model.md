# Data Model: LLM 统一模型调用网关

**Feature**: 004-llm-gateway-unified | **Date**: 2026-10-28

## 变更概览

本功能涉及以下数据模型变更：
- **LlmGateway.Model 表扩展**：新增 `capabilities` 字段
- **KnowledgeManage.Chat 表扩展**：新增 `status` 字段
- **新增运行时实体**（内存/进程内，不持久化）：能力注册表、限流计数器、调用记录

## 持久化实体

### Model（LlmGateway 服务，扩展现有表）

**表名**: `llm_gateway.models`

**变更**: 新增 `capabilities` 字段

| 字段 | 类型 | 约束 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String(36) | PK | 模型 ID（UUID） |
| name | String(100) | NOT NULL | 模型名称 |
| display_name | String(200) | NULLABLE | 模型显示名称 |
| category | String(20) | NOT NULL, default='chat' | 模型分类 |
| provider | String(100) | NOT NULL | 供应商标识 |
| url | String(500) | NOT NULL | API 端点 URL |
| api_key_encrypted | Text | NOT NULL | Fernet 加密的 API Key |
| context_tokens | Integer | NOT NULL | 上下文窗口大小 |
| rpm | Integer | NOT NULL | 限流：每分钟请求数 |
| tpm | Integer | NOT NULL | 限流：每分钟 token 数 |
| input_per_million | Numeric(10,4) | NOT NULL | 输入 token 定价 |
| output_per_million | Numeric(10,4) | NOT NULL | 输出 token 定价 |
| cached_input_per_million | Numeric(10,4) | NOT NULL | 缓存命中定价 |
| **capabilities** | **JSON** | **NOT NULL, default=[]** | **模型能力列表，如 ["streaming", "structured_output"]** |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**唯一约束**: `(provider, name)`

**迁移**: 新增 `capabilities` 列，默认值 `[]`（空数组），所有现有模型需手动更新能力声明。

### Chat（KnowledgeManage 服务，扩展现有表）

**表名**: `knowledge_manage.chats`

**变更**: 新增 `status` 字段

| 字段 | 类型 | 约束 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String(36) | PK | 会话 ID（UUID） |
| title | String(200) | NOT NULL | 会话标题 |
| user_id | String(36) | NOT NULL, INDEX | 所属用户 ID |
| model_id | String(36) | NULLABLE | 当前使用的模型 ID |
| prompt_id | String(36) | NULLABLE | 当前使用的提示词 ID |
| **status** | **String(20)** | **NOT NULL, default='idle'** | **会话状态：idle/generating/completed/cancelled** |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**状态流转**:
```
idle → generating → completed
                  → cancelled
completed → idle (用户发送新消息时，会话复用)
cancelled → idle (用户发送新消息时，会话复用)
```

**迁移**: 新增 `status` 列，默认值 `'idle'`。

### Message（KnowledgeManage 服务，无变更）

**表名**: `knowledge_manage.messages`

| 字段 | 类型 | 约束 | 说明 |
| ---- | ---- | ---- | ---- |
| id | String(36) | PK | 消息 ID（UUID） |
| chat_id | String(36) | NOT NULL, INDEX | 所属会话 ID |
| role | String(20) | NOT NULL | 消息角色：user/assistant/system |
| content | Text | NOT NULL | 消息内容 |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |

## 运行时实体（进程内，不持久化）

### CapabilityRegistry（能力注册表）

内存数据结构，在 Gateway 启动时从数据库加载，缓存 Model 配置。

```
CapabilityRegistry:
  - adapters: Dict[str, Adapter]        # provider → Adapter 实例
  - models: Dict[str, ModelConfig]      # model_name → ModelConfig
  - capability_index: Dict[str, List[str]]  # capability → [model_name, ...]

Adapter:
  - provider: str
  - capabilities: List[str]  # ["streaming", "structured_output", "tool_calling"]
  - health_status: str  # "healthy" | "unhealthy"

ModelConfig:
  - name: str
  - provider: str
  - url: str
  - api_key: "[REDACTED]"
  - capabilities: List[str]
  - rpm: int
  - tpm: int
  - pricing: {input_per_million, output_per_million, cached_input_per_million}
```

### RateLimiter（限流器）

进程内限流器，每个 Model 独立实例。

```
RateLimiter:
  - model_name: str
  - rpm_limit: int
  - tpm_limit: int
  - request_window: SlidingWindow  # RPM 滑动窗口计数器
  - token_bucket: TokenBucket      # TPM 令牌桶
```

### InvocationRecord（调用记录）

每次模型调用的运行时记录，用于可观测性。不持久化到数据库，通过 Prometheus 指标和结构化日志输出。

```
InvocationRecord:
  - trace_id: str
  - call_id: str
  - user_email: str (from API Key)
  - model_name: str (requested)
  - resolved_model: str (actual)
  - provider: str
  - prompt_name: str | None
  - prompt_version: str | None
  - capabilities_required: List[str]
  - tokens: {input, output, cached, reasoning}
  - latency: {queue, route, ttft, generation, total}
  - retries: int
  - fallback_used: bool
  - finish_reason: str
  - error_code: str | None
  - estimated_cost: Decimal
  - timestamp: datetime
```

## 外部依赖实体（只读引用）

### API Key（UserManage 服务）

通过 HTTP 调用 UserManage 服务验证 API Key 并获取用户邮箱。

```
API Key Verification:
  - Input: api_key (Bearer Token)
  - Output: {user_id, user_email}
  - Endpoint: UserManage service
```

### Prompt Template（KnowledgeManage 服务）

通过 HTTP 调用 KnowledgeManage 服务获取提示词模板。

```
Prompt Template Fetch:
  - Input: prompt_name, version
  - Output: {id, name, version, content}
  - Endpoint: KnowledgeManage service
  - Failure: 拒绝请求，返回模板服务不可用错误
```
