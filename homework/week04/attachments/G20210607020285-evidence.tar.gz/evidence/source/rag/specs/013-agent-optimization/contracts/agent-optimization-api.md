# Contract: 配置 API / SSE 事件 / Trace 属性（agent-optimization-api）

**Feature**: 013-agent-optimization | **依据**: research.md R8、R12–R15；data-model.md §2/§4/§6

对外接口均为**既有端点的增量扩展**，无新增路由。

---

## 1. 智能体配置 API 扩展（既有 `/api/knowledge/agents`）

### 1.1 PUT `/api/knowledge/agents/{agent_id}`（保存配置）

请求体 `config` 新增键（三类智能体均适用）：

```json
{
  "config": {
    "history_retrieval": { "top_k": 10 }
  }
}
```

| 规则 | 行为 |
|---|---|
| top_k 范围 | int，1–100；越界 → 400（沿用现有手动 model_validate 捕获转 400 的模式） |
| 缺省 | 请求/存量 config 缺 `history_retrieval` → 默认 `{top_k: 10}` 生效（FR-005） |
| 裁剪 | 三类均保留；`extra="ignore"` 丢弃未知子键（如传入 mode/enabled 一律忽略，决策8：无模式选项无开关） |
| 保存校验文案（前端） | "检索召回数须为 1–100 的整数"（section=history） |

### 1.2 GET `/api/knowledge/agents` / `GET /api/knowledge/agents/{agent_id}`

响应 `config` 原样透传 JSON 列；存量智能体缺键时**响应不强补**（前端打开编辑弹窗时以默认值补齐草稿，运行侧由 Pydantic 默认兜底）。

### 1.3 前端配置页契约

- 左侧菜单新增"历史信息检索"（key=`history`），位置在"检索策略"之后、"模型配置"之前；三类智能体均显示。
- 区块内容：仅"检索召回数"数字输入框（a-input-number，min=1，max=100，默认 10）+ 说明文案"检索模式固定为混合检索（关键词+向量），无需选择"。
- 纳入保存前统一校验（validateAgentDraft）；校验失败定位到 history 区块（沿用现有错误定位机制）。

## 2. SSE 步骤事件扩展（既有问答流式端点）

`StepEvent.step` 枚举（后端 StepName Literal 与前端 STEP_LABELS 同步）新增：

| step | 前端标签 | 时机 | 携带 |
|---|---|---|---|
| `history_retrieve` | 历史信息检索 | 每次提问后、`clarify` start 之前；每请求恰好一次（含推理行动/规划推理） | status=start/end；降级时 end 携带 message="历史检索降级，使用最近历史" |

事件序列示例（快速问答）：

```text
step(history_retrieve,start) → step(history_retrieve,end)
→ step(clarify,start) → ...（既有流程不变）
```

既有事件（references/delta/usage/done/cancelled/error）契约零改动；`done` 事件 meta.events 可能新增 `plan_text_not_tool_call` 项（见 §3.3）。

## 3. Trace 属性/事件契约（trace 查询端点透传，前端抽屉展示）

### 3.1 提示词溯源属性（FR-001）

附着于所有渲染提示词的 span：

| span | prompt.purpose |
|---|---|
| agent.clarify | clarify |
| agent.rewrite（主流程 + rewriteQuestion 工具内） | rewrite |
| agent.compress（主流程 + zip 工具内） | compress |
| agent.sufficiency | sufficiency |
| agent.answer | answer |
| agent.plan_decision | planning |

属性：`prompt.name`（PromptSnapshot.name）、`prompt.version`（PromptSnapshot.version）、`prompt.purpose`（上表）。

前端：走 SpanDetail 既有 Tags 表格展示，无需新面板。

### 3.2 检索片段属性（FR-002）

附着于 `agent.retrieve.vector` / `agent.retrieve.hybrid` / `agent.retrieve.keyword`（主流程检索节点 + knowledge_tools 检索工具同名 span）：

- 属性名：`retrieval.chunks`
- 值：JSON 数组字符串，元素结构：

```json
[{ "chunk_id": "…", "score": 0.032, "file_name": "…", "content": "片段全文（不截断）" }]
```

- **不截断**：写入绕过 to_json_attr 的 32KB 截断（决策11）；空命中写空数组。
- 既有 `agent.output`（count/chunk_ids 摘要）保留不变。
- 前端：SpanDetail 新增"检索片段（retrieval.chunks）"美化 JSON 折叠面板（仿 agent.input/output）。

### 3.3 规划文本警告事件（FR-017）

- 事件名：`plan_text_not_tool_call`，附着 `agent.plan_decision` span。
- 触发：决策输出无 tool_calls 且 content 命中计划标记，正则覆盖 014 §3.1 两种问题形态：
  1. XML 形态：content 含 createPlan 或 updatePlan 的 XML 开标签（尖括号+标记名+尖括号，形如 014 示例一）；
  2. 标签包裹 JSON 形态：content 含 tool_call 开标签且其后文本出现 createPlan/updatePlan（形如 014 示例二）。
- 事件属性：`loop`（决策轮次）、`content_excerpt`（content 前 500 字符）。
- 同步写入 `rt.events`，随 done 事件 meta.events 下发并落库（与 forced_convergence 同模式）。
- **收敛行为不变**：无 tool_calls 仍进入答案生成（FR-016）；正常 tool_calls 输出不产生该事件。

### 3.4 历史检索相关 span/事件

| 名称 | 类型 | 契约 |
|---|---|---|
| `agent.history_retrieve` | span | 父 agent.run；agent.input={query, chat_id, top_k}；agent.output={count, round_ids, degraded} |
| `history_retrieve_degraded` | 事件 | reason ∈ timeout / unavailable / embedding_failed / empty_result / error |
| `agent.history_index` | span | 异步写入独立 span；属性 chat.id / session.id / origin.trace_id |
| `history_index_failed` | 事件 | error=异常摘要；仅日志+trace，不影响主流程 |
| `context_evicted`（扩展） | 事件 | 既有属性基础上新增 dropped_clarify_history 计数 |

### 3.5 PLANNING_PROTOCOL 文案约束（FR-015）

在现有协议文案基础上追加强约束（不删除既有内容）：

- 计划与所有工具操作必须通过 function calling（响应 tool_calls 字段）发起；
- 严禁在 content 中输出 createPlan/updatePlan 的 XML 标记、tool_call 标记或 JSON 计划体；
- content 仅用于自然语言说明；无需更多工具时不发起 tool_calls、直接文字说明（既有收敛口径不变）。

## 4. 验收映射

| 契约点 | spec |
|---|---|
| 配置项范围/默认/校验/菜单 | FR-004、FR-005 |
| 步骤事件与前端标签 | FR-006 |
| prompt 溯源全覆盖 | FR-001、SC-004 |
| 片段全文不截断 | FR-002、SC-004 |
| 抽屉现有方式呈现、无新路由 | FR-003 |
| 协议强化/收敛不变/警告事件 | FR-015、FR-016、FR-017、SC-003 |