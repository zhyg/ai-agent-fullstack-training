# Quickstart: 模型管理优化验证指南

**Feature**: 002-model-category-optimization | **Date**: 2026-10-28

## Prerequisites

- Python 3.11 + pip
- Node.js 26.x + npm
- PostgreSQL 数据库运行中
- LlmGateway 数据库 schema `llm_gateway` 已创建

## Step 1: 运行数据库迁移

```bash
cd LlmGateway
alembic upgrade head
```

**验证**: 检查 `llm_gateway.models` 表新增 `category`、`provider`、`display_name` 列，`max_tokens` 列已重命名为 `context_tokens`。

```sql
-- 验证列存在
SELECT column_name FROM information_schema.columns
WHERE table_schema = 'llm_gateway' AND table_name = 'models'
ORDER BY ordinal_position;

-- 验证旧数据已归入默认分类
SELECT name, category, provider FROM llm_gateway.models;
```

**预期**: 所有旧模型的 `category` 值为 `'chat'`，`provider` 值为 `'OpenAI'`。

## Step 2: 启动后端服务

```bash
cd LlmGateway
APP_ENV=dev uvicorn app.main:app --reload --port 8003
```

## Step 3: 验证后端 API

### 3.1 创建带分类的模型

```bash
curl -X POST http://localhost:8003/models \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "gpt-4o",
    "display_name": "GPT-4o",
    "category": "chat",
    "provider": "OpenAI",
    "url": "https://api.openai.com/v1/chat/completions",
    "api_key": "[REDACTED]"
    "context_tokens": 128000,
    "rpm": 500,
    "tpm": 30000,
    "input_per_million": 5.0,
    "output_per_million": 15.0,
    "cached_input_per_million": 1.25
  }'
```

**预期**: 201 Created，响应包含 `category`、`provider`、`display_name`、`context_tokens` 字段。

### 3.2 验证分类必填校验

```bash
curl -X POST http://localhost:8003/models \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "test-model",
    "url": "http://example.com",
    "api_key": "[REDACTED]"
    "context_tokens": 4096,
    "rpm": 0, "tpm": 0,
    "input_per_million": 0,
    "output_per_million": 0,
    "cached_input_per_million": 0
  }'
```

**预期**: 422 Validation Error，提示 `category` 和 `provider` 为必填。

### 3.3 验证同供应商下 name 唯一性

重复发送 3.1 中的请求。

**预期**: 409 Conflict，提示 "该供应商下已存在同名模型"。

### 3.4 验证分类筛选

```bash
# 获取全部模型
curl "http://localhost:8003/models?page_size=1000" \
  -H "Authorization: Bearer <token>"

# 按分类筛选
curl "http://localhost:8003/models?category=chat&page_size=1000" \
  -H "Authorization: Bearer <token>"
```

**预期**: 筛选后仅返回 `category=chat` 的模型。

## Step 4: 启动前端并验证 UI

```bash
cd frontend
npm run dev
```

### 4.1 模型列表分类标签页

1. 打开模型管理页面
2. **验证**: 页面顶部显示分类标签页（对话模型、Embedding、ReRank、视觉、语音）
3. **验证**: 默认激活"对话模型"标签页
4. **验证**: 每个标签显示对应分类的模型计数
5. **验证**: 切换标签页后仅显示对应分类的模型卡片

### 4.2 创建模型表单

1. 点击"新建模型"按钮
2. **验证**: 表单包含"模型分类"下拉框（5 个选项）
3. **验证**: 表单包含"模型供应商"下拉框（OpenAI、Anthropic 预设 + 自定义输入）
4. **验证**: 表单包含"模型显示名称"输入框
5. **验证**: 上下文窗口字段标签为"context_tokens"（或"上下文窗口"）
6. 填写所有必填字段并提交
7. **验证**: 创建成功后，模型出现在对应分类标签下

### 4.3 模型卡片展示

1. 查看模型列表中的任意模型卡片
2. **验证**: 卡片显示模型显示名称（或 name）、供应商、分类图标

### 4.4 会话页模型选择器

1. 打开会话页面
2. 点击模型选择器下拉框
3. **验证**: 模型按分类分组展示（opt-group）
4. **验证**: 选择模型后正常发送消息

## Step 5: 运行后端测试

```bash
cd LlmGateway
pytest tests/ -v
```

**预期**: 所有测试通过，包括：
- 创建模型（含新字段）
- 更新模型（含新字段）
- 分类筛选
- name 唯一性校验（同供应商）
- 不同供应商允许同名

## Known Edge Cases to Verify

- [ ] 旧模型（无分类）在 API 响应中 `category` 为 `'chat'`
- [ ] 空分类标签页显示空状态提示
- [ ] `display_name` 为空时前端显示 `name` 字段
- [ ] 更新模型时修改 `provider` + `name` 组合不与其他模型冲突
- [ ] 删除分类下最后一个模型后，标签页仍显示（计数为 0）
