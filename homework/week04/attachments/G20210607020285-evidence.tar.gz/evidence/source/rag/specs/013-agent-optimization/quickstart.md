# Quickstart: 智能体运行优化验证指南（013-agent-optimization）

**Feature**: 013-agent-optimization | **Plan**: [plan.md](./plan.md) | **Contracts**: [history-qa-es](./contracts/history-qa-es.md) / [agent-optimization-api](./contracts/agent-optimization-api.md)

本指南给出特性交付后的可运行验证场景；实现细节见 tasks.md（/speckit-tasks 生成）。

## 前置条件

| 依赖 | 要求 |
|---|---|
| Python 环境 | `/Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python`（3.11） |
| PostgreSQL / Redis | 开发环境已运行（config.dev.yaml） |
| Elasticsearch | 8.17.0 @ localhost:9200，**需 analysis-ik 插件**（`curl -u elastic:123456 localhost:9200/_cat/plugins` 应见 analysis-ik） |
| LlmGateway | localhost:8003，已配置分析/向量/ReRank 模型 |
| OTel Collector + Jaeger/ES | tracing.enabled=true（dev）；单测环境 test 配置为 false（NoOp） |
| 前端 | Node 26，`frontend/` 下 `npm install` 已完成 |

## 1. 自动化测试（单测，mock ES/网关）

```bash
cd /Volumes/MySSD/mycode/Ai/myKnowlege/KnowledgeManage
/Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python -m pytest tests/ -q
```

**预期**: 全量通过（既有 223+ 用例零回归），新增覆盖：

| 测试文件 | 验证点 |
|---|---|
| tests/test_history_qa.py（新） | 写入触发条件（done 写/cancelled/error 不写）、拼接向量化、_id 幂等、写失败仅日志；检索 chat_id 过滤/topk/RRF；组装去重/时间序/剔除当前问题/2 轮保底；超时/异常/零命中降级；预算淘汰 |
| tests/test_agent_flows.py（增） | history_retrieve 步骤事件先于 clarify 且每请求一次；clarify/rewrite 用组装历史、answer/planning 仍用最近 10 轮；循环重写复用同一份历史；plan_text_not_tool_call 两种形态触发/正常 tool_calls 不触发/收敛不变 |
| tests/test_agents.py（增） | history_retrieval 默认 10 兜底、1–100 校验、三类均保留、越界 400 |

前端构建：

```bash
cd /Volumes/MySSD/mycode/Ai/myKnowlege/frontend && npm run build
```

## 2. 端到端手工验证

启动后端（KnowledgeManage）与前端（`npm run dev`），登录管理端。

### 场景 A：配置菜单（US 前置，FR-004/005）

1. 智能体管理 → 编辑任一快速问答智能体 → 左侧菜单应出现"历史信息检索"（检索策略之后）。
2. 区块仅一个"检索召回数"输入框，默认 10；无模式选项、无开关。
3. 输入 0 或 101 → 保存被拦截，提示"检索召回数须为 1–100 的整数"；改为 5 保存成功。
4. 打开一个**存量**智能体（config 无 history_retrieval）→ 输入框显示默认 10，直接保存成功。

### 场景 B：长会话指代解析（US1，SC-001）

1. 选绑定知识库的智能体新建会话，先问"产品A是什么"并等待回答；再灌入 10+ 轮无关问答（使早期轮次跌出最近 10 轮窗口）。
2. 提问"A 的保修期多久"。
3. **预期**: 进度条先出现"历史信息检索"，再"问题澄清"；澄清判清晰；答案引用早期产品 A 背景。
4. ES 验证：`curl -u elastic:123456 'localhost:9200/chat_history_qa_*/_search?q=chat_id:<会话ID>&pretty'` 应见每轮一文档（question/answer/qa_text/embedding_model 齐全）。
5. 上一轮刚聊产品 B 时问"它的价格是多少" → 2 轮保底使"它"解析为 B。

### 场景 C：降级无损（US2，SC-002）

1. 停掉 ES（或改错 hosts）后提问 → 问答正常完成；trace 抽屉 `agent.history_retrieve` span 含 `history_retrieve_degraded` 事件；额外等待 ≤3 秒。
2. 新会话首轮提问（零命中）→ 同样降级事件（reason=empty_result），流程正常。
3. 恢复 ES，正常问答一轮后立刻再停 ES 提问 → 已完成轮次不受影响（写失败仅日志）。

### 场景 D：规划推理工具调用（US3，SC-003）

1. 规划推理智能体（启用检索工具）提问"张三的语文成绩是多少"。
2. **预期**: trace 中 `agent.plan_decision` 输出含 tool_calls（createPlan → hybridSearch 等），答案基于检索结果。
3. 换用不遵循 function calling 的模型（如 014 §3.1 现场模型）复测 → 仍收敛进答案生成（行为不变），但 span 出现 `plan_text_not_tool_call` 事件，done 事件 meta.events 含同名项。

### 场景 E：Trace 增强（US4，SC-004）

1. 完成一次问答 → 消息旁 trace 按钮打开抽屉。
2. 点开 clarify/rewrite/compress/sufficiency/answer/plan_decision 各节点 → Tags 含 prompt.name / prompt.version / prompt.purpose，值与所选提示词一致。
3. 点开 `agent.retrieve.*` 节点 → 出现"检索片段（retrieval.chunks）"折叠面板，每条含 chunk_id/score/file_name/content，content 为全文（构造 >32KB 命中验证不截断）。
4. 工具内检索/重写/压缩 span 同样含上述属性。

### 场景 F：不完整轮次不入库（SC-005）

1. 提问后点击"停止生成" → ES 查询该 chat_id 文档数不增加。
2. 断开网关使问答报错 → 同样不增加。

## 3. 验证通过标准

- [ ] 后端全量 pytest 通过、前端构建成功
- [ ] 场景 A–F 全部符合预期
- [ ] 既有问答（旧模式会话、三类智能体主流程）零回归