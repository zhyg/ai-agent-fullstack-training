# KnowledgeManage API Contract

**Service**: KnowledgeManage | **Base URL**: `/api/knowledge` | **Auth**: JWT (验证方，Secret 共享自 UserManage)

所有接口需要在 Header 中携带 `Authorization: Bearer <access_token>`。

> **Pydantic 规范**: 所有 Request Body 和 Response 均使用 Pydantic V2 Model 定义。详见 [research.md R-011](../research.md#r-011-接口参数校验规范pydantic-model)。

## Pydantic Schemas

```python
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from datetime import datetime

# --- Prompt ---
class PromptCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="提示词名称（必填）")
    version: str = Field(..., min_length=1, max_length=20, description="版本号（必填）")
    description: str = Field("", description="描述")
    content: str = Field(..., min_length=1, description="提示词内容（必填）")

class PromptUpdate(BaseModel):
    description: Optional[str] = Field(None, description="描述")
    content: str = Field(..., min_length=1, description="提示词内容（必填）")
    # name 和 version 不可修改，不出现在 Update Schema 中

class PromptResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    version: str
    description: str
    content: str
    creator_id: str
    creator_name: Optional[str] = None  # 仅管理员视图返回
    created_at: datetime
    updated_at: datetime

# --- Chat ---
class ChatCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200, description="会话标题")
    model_id: Optional[str] = Field(None, description="模型 ID")
    prompt_id: Optional[str] = Field(None, description="提示词 ID")

class ChatUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    model_id: Optional[str] = None
    prompt_id: Optional[str] = None

class ChatResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    user_id: str
    model_id: Optional[str] = None
    prompt_id: Optional[str] = None
    created_at: datetime
    updated_at: datetime

# --- Message ---
class MessageCreate(BaseModel):
    content: str = Field(..., min_length=1, description="消息内容")

class MessageResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    role: str  # user | assistant | system
    content: str
    created_at: datetime
```

---

## 提示词管理

### GET /prompts

获取提示词列表

**访问控制**:
- 普通用户: 仅返回 `creator_id = current_user_id` 的记录
- 管理员: 返回所有记录，每条记录附带 `creator_name` 字段

**Query Params**: `page` (int, default 1), `page_size` (int, default 20)

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "string",
      "version": "string",
      "description": "string",
      "content": "string",
      "creator_id": "uuid",
      "creator_name": "string (仅管理员可见，普通用户不返回此字段)",
      "created_at": "ISO8601",
      "updated_at": "ISO8601"
    }
  ],
  "total": 50,
  "page": 1,
  "page_size": 20
}
```

---

### POST /prompts

创建提示词

**Request Body**:
```json
{
  "name": "string (required, 不唯一)",
  "version": "string (required)",
  "description": "string (default '')",
  "content": "string (required)"
}
```

**Behavior**: `creator_id` 自动设置为当前登录用户 ID

**Response 201**:
```json
{
  "id": "uuid",
  "name": "string",
  "version": "string",
  "description": "string",
  "content": "string",
  "creator_id": "uuid",
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

---

### PUT /prompts/{prompt_id}

编辑提示词

**Path Parameter**: `prompt_id` (string, UUID, 必填) — 待更新的提示词 ID

**访问控制**:
- 普通用户: 仅能编辑 `creator_id = current_user_id` 的记录
- 管理员: 仅能编辑 `creator_id = current_user_id` 的记录（管理员不能编辑他人的提示词）

**Request Body**:
```json
{
  "description": "string (optional)",
  "content": "string (required)"
}
```

**约束**: `name` 和 `version` 不可修改

**Response 200**: 更新后的提示词对象

**Error 403**: `{ "detail": "无权编辑此提示词" }`
**Error 404**: `{ "detail": "提示词不存在" }`

---

### DELETE /prompts/{prompt_id}

删除提示词

**Path Parameter**: `prompt_id` (string, UUID, 必填) — 待删除的提示词 ID

**访问控制**:
- 普通用户: 仅能删除 `creator_id = current_user_id` 的记录
- 管理员: 可删除任意提示词

**Response 200**: `{ "message": "提示词删除成功" }`
**Error 403**: `{ "detail": "无权删除此提示词" }`

---

## 会话管理

### GET /chats

获取当前用户的会话列表

**Behavior**: 仅返回 `user_id = current_user_id` 的记录

**Query Params**: `page` (int, default 1), `page_size` (int, default 20)

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "title": "string",
      "model_id": "uuid | null",
      "prompt_id": "uuid | null",
      "created_at": "ISO8601",
      "updated_at": "ISO8601"
    }
  ],
  "total": 20,
  "page": 1,
  "page_size": 20
}
```

---

### POST /chats

创建新会话

**Request Body**:
```json
{
  "title": "string (required)",
  "model_id": "uuid (optional)",
  "prompt_id": "uuid (optional)"
}
```

**Behavior**: `user_id` 自动设置为当前登录用户 ID

**Response 201**:
```json
{
  "id": "uuid",
  "title": "string",
  "user_id": "uuid",
  "model_id": "uuid | null",
  "prompt_id": "uuid | null",
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

---

### PUT /chats/{chat_id}

更新会话（切换模型/提示词）

**Path Parameter**: `chat_id` (string, UUID, 必填) — 待更新的会话 ID

**Access**: 仅 `user_id = current_user_id`

**Request Body**:
```json
{
  "title": "string (optional)",
  "model_id": "uuid | null (optional)",
  "prompt_id": "uuid | null (optional)"
}
```

**Response 200**: 更新后的会话对象

---

### DELETE /chats/{chat_id}

删除会话及其所有消息

**Path Parameter**: `chat_id` (string, UUID, 必填) — 待删除的会话 ID

**Access**: 仅 `user_id = current_user_id`

**Response 200**: `{ "message": "会话删除成功" }`

---

### GET /chats/{chat_id}/messages

获取会话的消息列表

**Access**: 仅 `user_id = current_user_id`

**Query Params**: `page` (int, default 1), `page_size` (int, default 50)

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "role": "user | assistant | system",
      "content": "string",
      "created_at": "ISO8601"
    }
  ],
  "total": 30,
  "page": 1,
  "page_size": 50
}
```

---

### POST /chats/{chat_id}/messages

发送消息并获取 LLM 回复（流式 SSE）

**Request Body**:
```json
{
  "content": "string (required)"
}
```

**Behavior**:
1. 保存用户消息到 messages 表
2. 调用 LlmGateway 服务获取 LLM 回复（流式）
3. 以 SSE 格式逐 token 返回 assistant 回复
4. 完成后保存 assistant 消息到 messages 表

**Response**: `text/event-stream`

```text
data: {"role": "assistant", "content": "你"}

data: {"role": "assistant", "content": "好"}

data: {"role": "assistant", "content": "！"}

data: {"done": true, "message_id": "uuid"}
```

**Error 400**: `{ "detail": "请先选择模型" }` (chat.model_id 为空)
