# Research: 资源消耗监控

**Feature**: 015-resource-consumption-monitor | **Date**: 2026-11-25

所有 Technical Context 未知项均已通过代码库调研解决，无遗留 NEEDS CLARIFICATION。

## R-001 当前用户 → user_email 映射

- **Decision**: 后端通过 UserManage `GET /api/user/users/{uid}`（Bearer 透传当前 token）解析当前用户 email，复用 `prompt_service._resolve_user_names` 的既有模式（httpx，5s 超时）；每次 series 请求解析一次，结果用于"本人"强制绑定与越权比对。
- **Rationale**: KnowledgeManage 的 JWT payload 仅含 sub/uid/role_ids/permissions，**不含 email**（dependencies.py 已核实）；指标标签是 user_email，必须经 UserManage 桥接。该模式已在 prompt_service 生产使用。
- **Alternatives considered**: ① JWT 增加 email 字段——需改 UserManage 签发逻辑，影响面大，拒绝；② 前端传 email 由后端信任——可伪造，违反 FR-004，拒绝；③ 用 uid 匹配指标——指标无 uid 标签，不可行。
- **Failure mode**: UserManage 不可达或用户已删除 → 返回 502/明确错误"无法解析当前用户身份"，不降级为任意查询。

## R-002 管理员判定

- **Decision**: `"permission_manage" in current_user["permissions"]`，与 `prompt_service._is_admin`、前端 `userStore.isAdmin` 完全一致。
- **Rationale**: 项目既有统一判据，前后端已对齐，无需新增角色查询。
- **Alternatives considered**: role_ids 比对——需硬编码角色 ID，脆弱；新增权限键——需改 UserManage 权限种子，超出范围。

## R-003 日/月聚合算法（北京时间 + counter 重置 + 当期截断）

- **Decision**: **逐桶瞬时查询**。后端按北京时间（zoneinfo "Asia/Shanghai"）切出自然日/月桶；每桶执行一次 Prometheus `/api/v1/query`：`sum by (model) (increase(<metric>{<filters>}[<window>]))`，`time=<桶结束时刻的 UTC epoch>`，`window=<桶起止秒数>`。完整桶 window=86400（日）或当月实际秒数（月）；**最后一个进行中桶**的结束时刻取 now、window 取已经过秒数（实现"截至当前实时累计"与 X 轴截断）。各桶查询用 `asyncio.gather` 并发（信号量上限 8），单查询 httpx 超时 10s。
- **Rationale**: ① increase 原生处理 counter 重启归零（FR-013）；② 桶边界以北京时间午夜换算成 UTC epoch 传入，天然解决时区切分（FR-012）；③ 逐桶变长 window 是"当期部分桶"最简正确解；④ 月视图 ≤12 桶、日视图 ≤31 桶，本地 Prometheus 负载可忽略。
- **Alternatives considered**: ① 单条 query_range + step=1d——step 对齐 UTC 午夜，与北京时间差 8h，且无法表达当期部分桶，拒绝；② `offset -8h` 负偏移——Prometheus 版本兼容性风险且部分桶仍需特判，拒绝；③  recording rules 预聚合——需改 Prometheus 配置与回填历史，超出范围，拒绝。
- **Note**: increase 为外推估算，边界桶可能有微小外推误差；对"日消耗"展示场景可接受（与 Grafana 同口径）。

## R-004 PromQL 标签折叠与过滤

- **Decision**: 基础选择器 `llm_tokens_total{type!="cached"}`（token，FR-010）/ `llm_cost_estimate`（费用）；人视图加 `user_email="<email>"` 精确匹配，所有人视图不加 user_email 过滤（跨用户求和）；模型多选非空时加 `model=~"m1|m2|..."`（正则转义），全选/清空时不加 model 过滤；外层 `sum by (model)` 折叠 category/prompt_name/prompt_version/type 维度。
- **Rationale**: 指标含 prompt_name/prompt_version 等高基数标签（observability.py 已核实），必须 sum by (model) 折叠；type!="cached" 一条选择器即排除 cached 并纳入其余三类。
- **Alternatives considered**: 分别查 input/output/reasoning 再相加——3 倍查询量无收益，拒绝。

## R-005 保留期边界判定

- **Decision**: 配置项 `prometheus.retention_days`（默认 15，Prometheus 默认保留期）作为提示阈值：请求期间**整体**早于 `now - retention_days` 时，响应 `out_of_retention=true`、序列为空，前端提示"超出数据保留期"；其余情况一律补 0。
- **Rationale**: Prometheus 对超保留期与无数据均返回空结果，无法从响应区分；用配置阈值做确定性判定，简单可测。保留期按现状（决策8），阈值可随实际部署调整。
- **Alternatives considered**: 查询 `timestamp()` 探测最早样本——额外查询且语义复杂，拒绝；不区分直接补 0——违反 FR-017，拒绝。

## R-006 筛选选项来源

- **Decision**: 后端调 Prometheus `/api/v1/label/user_email/values` 与 `/api/v1/label/model/values`（带 `match[]=llm_tokens_total` 限定指标范围），排除空字符串；普通用户 options 仅返回本人 email + 全部模型，管理员返回全部 email + 全部模型。前端每次进页拉取一次。
- **Rationale**: 决策7 要求只列产生过数据的值；match[] 避免混入其他指标的同名标签值；权限裁剪在后端完成，前端无需判断。
- **Alternatives considered**: 从 UserManage/模型管理取全量——含从未调用的值，违反决策7，拒绝。

## R-007 ECharts 集成方式

- **Decision**: `npm i echarts`，按需引入 `echarts/core` + LineChart + GridComponent/TooltipComponent/LegendComponent + CanvasRenderer；ConsumptionChart.vue 内 `init/setOption/dispose`，ResizeObserver 自适应，`watch` 数据变更 setOption(notMerge)；图例原生支持点击隐藏曲线（FR-008）。费用序列 tooltip/Y 轴 `toFixed(6)`，token 取整。
- **Rationale**: 决策5 指定 ECharts 按需引入；项目无图表库与封装先例，直接 core API 最可控，避免 vue-echarts 额外依赖。
- **Alternatives considered**: vue-echarts 封装——多一层依赖收益小；全量引入 echarts——包体积 ~1MB，违反按需决策。

## R-008 前端请求竞态与错误处理

- **Decision**: monitorApi.js 沿用 evaluationApi.js 模式（axios 实例 + Bearer 拦截器 + 401 清 token 跳登录 + detailOf 错误提取）；页面维护自增请求序号，仅采纳最后一次请求结果（丢弃过期响应）；Prometheus 不可达后端返回 502 + detail，前端 message.error 展示，不影响其他页面。
- **Rationale**: 与项目既有 API 层一致；最新请求胜出是查询类页面标准做法（Assumptions 已记录）。
- **Alternatives considered**: AbortController 取消旧请求——可行但序号法更简单且覆盖乱序到达；忽略竞态——可能渲染旧数据，拒绝。

## 代码库事实清单（调研核实）

| 事实 | 位置 |
|------|------|
| JWT payload 无 email，含 sub/uid/role_ids/permissions/token | KnowledgeManage/app/dependencies.py |
| email 解析既有模式（UserManage GET /api/user/users/{uid}） | KnowledgeManage/app/services/prompt_service.py L22-60 |
| admin 判据 permission_manage | prompt_service.py L16-19；frontend/src/stores/user.js L13-16 |
| 配置加载 Settings + config.{env}.yaml，services dict | KnowledgeManage/app/core/config.py |
| router 注册 prefix=/api/knowledge | KnowledgeManage/app/main.py L84-92 |
| 指标标签：tokens(model,user_email,type,category,prompt_name,prompt_version)、cost(model,user_email,category,prompt_name,prompt_version) | LlmGateway/app/gateway/observability.py L43-60 |
| 前端代理 /api/knowledge→8002 已存在 | frontend/vite.config.js |
| 侧边栏菜单/路由映射位置 | frontend/src/components/layout/AppLayout.vue L107-122, L153-169, L200-203 |
| 测试模式：patch decode_token + admin_claims/user_claims | KnowledgeManage/tests/test_evaluation_settings.py 等 |