# Implementation Plan: 知识库评测

**Branch**: `014-knowledge-evaluation` | **Date**: 2026-11-24 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/014-knowledge-evaluation/spec.md`

## Summary

在 AI→知识库下新增"知识库评测"菜单（设置/评测两个 tab）：用户配置分析模型与召回率/准确度提示词、上传问答测试集（JSON），选择知识库+智能体+测试集发起异步评测。后端在 KnowledgeManage 新增评测模块：4 张 PG 表（设置/测试集/任务/题目明细）+ 评测服务（逐题串行、单题 10 分钟超时兜底、题间取消、重启标记失败）+ SSE 进度推送 + 评测 trace 查询接口。每题复用现有 agent_runtime 链路（新增无会话入口 `run_evaluation_question`，不产生会话数据），评分复用 `llm_client.call_json`（容错提取+业务重试 3 次），召回率/准确度由后端核算。前端新增评测页面与组件，trace 复用会话页 TraceDrawer（扩展 fetcher prop）。

技术决策详见 [research.md](./research.md)（R1–R14）；数据模型见 [data-model.md](./data-model.md)；接口契约见 [contracts/evaluation-api.md](./contracts/evaluation-api.md)；验证指南见 [quickstart.md](./quickstart.md)。

## Technical Context

**Language/Version**: Python 3.11（后端）；JavaScript / Vue 3（前端，Node 26）

**Primary Dependencies**: FastAPI、SQLAlchemy、Alembic、Pydantic v2、langgraph（agent 流程）、httpx（网关调用）、redis.asyncio、elasticsearch（trace 查询）；前端 Ant Design Vue、Vite、axios

**Storage**: PostgreSQL（`knowledge_manage` schema，新增 4 表）；trace 数据沿用 ES jaeger-span-* 索引（只读，不延长保留期）；测试集内容以 JSONB 存 PG（不依赖对象存储）

**Testing**: pytest（KnowledgeManage/tests，config.test.yaml 环境）；前端 `npm run build` 验证

**Target Platform**: Linux/macOS 服务器（uvicorn 单 worker，Dockerfile CMD 无 --workers）；桌面浏览器（移动端不在本期）

**Project Type**: Web 应用（FastAPI 微服务 + Vue SPA），本特性仅改 KnowledgeManage 与 frontend，LlmGateway/UserManage 零改动

**Performance Goals**: 每题完成后 2 秒内 SSE 进度可见（SC-002）；500 题测试集可完整跑完（SC-003）；重启后 1 分钟内任务状态正确呈现（SC-006）

**Constraints**: 逐题串行、单题固定 10 分钟超时兜底（澄清 Q2）；同用户仅 1 个进行中任务；测试集 ≤500 题/≤2MB；评分业务重试 ≤3 次（传输层归网关）；运行中锁定测试集与评测设置、全局资源不锁定（决策24）；不产生会话/消息数据

**Scale/Scope**: 单用户测试集 ≤500 题；新增后端 1 router + 2 service + 4 model + 1 schema + 1 alembic 迁移 + agent_runtime 1 个新入口；前端 1 视图 + 4 组件 + 1 api 模块 + TraceDrawer 小幅扩展

**未知项**: 无（全部 NEEDS CLARIFICATION 已在 research.md 解决）

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

`.specify/memory/constitution.md` 为未填充模板，无已批准的强制原则 → 无宪法门禁约束。以项目既有工程约定作为替代门禁（均来自现有代码核实）：

| 约定 | 本计划遵循情况 |
|------|----------------|
| PG schema 隔离（`settings.database.db_schema`），跨 schema 只读 SQL | ✅ 新表全部挂 knowledge_manage schema；模型解析复用 `llm_client.resolve_model` 只读 llm_gateway.models |
| 表结构变更走 Alembic 迁移 | ✅ 单个迁移文件新增 4 表（见 data-model.md §5） |
| JSON 输出容错提取 + 业务重试 3 次分层（传输层归网关） | ✅ 评分直接复用 `llm_client.call_json`，不新造重试逻辑（R4） |
| trace span 带 prompt.name/version/purpose 属性（014 规范） | ✅ 评分 span 调 `tracing.set_prompt_attrs`（R10） |
| 模型/服务/路由分层（models/schemas/services/routers） | ✅ 新增文件遵循既有目录分层 |
| 前端 API 模块复用认证拦截器模式 | ✅ evaluationApi.js 沿用 traceApi.js 模式 |

**Gate 结论**: PASS（无违例，Complexity Tracking 留空）。Phase 1 设计后复查：PASS（设计未引入新服务/新存储/新依赖）。

## Project Structure

### Documentation (this feature)

```text
specs/014-knowledge-evaluation/
├── plan.md              # 本文件
├── research.md          # Phase 0：R1–R14 技术决策
├── data-model.md        # Phase 1：4 表 + 状态机 + 校验规则
├── quickstart.md        # Phase 1：端到端验证指南
├── contracts/
│   └── evaluation-api.md  # Phase 1：REST + SSE 契约
└── tasks.md             # Phase 2（/speckit-tasks 生成，本命令不创建）
```

### Source Code (repository root)

```text
KnowledgeManage/
├── app/
│   ├── models/
│   │   ├── evaluation_setting.py      # 新增：EvaluationSetting
│   │   ├── evaluation_test_set.py     # 新增：EvaluationTestSet
│   │   ├── evaluation_run.py          # 新增：EvaluationRun
│   │   └── evaluation_item.py         # 新增：EvaluationItem
│   ├── schemas/
│   │   └── evaluation.py              # 新增：请求/响应/SSE 事件/评分 JSON 模型
│   ├── services/
│   │   ├── evaluation_service.py      # 新增：设置/测试集/任务 CRUD+预检+锁定+重启恢复
│   │   ├── evaluation_runner.py       # 新增：后台执行器（串行/超时/取消/SSE 事件总线）
│   │   └── agent_runtime/
│   │       └── evaluation.py          # 新增：run_evaluation_question 无会话入口（R1）
│   ├── routers/
│   │   └── evaluations.py             # 新增：/api/knowledge/evaluations/*
│   └── main.py                        # 修改：注册 router + lifespan 启动恢复/关闭取消
├── alembic/versions/
│   └── xxxx_add_evaluation_tables.py  # 新增：4 表迁移
└── tests/
    ├── test_evaluation_settings.py    # 新增：US1 设置
    ├── test_evaluation_test_sets.py   # 新增：US1 测试集校验/覆盖/下载/锁定
    ├── test_evaluation_runs.py        # 新增：US2 预检/并发/取消/重启/超时
    ├── test_evaluation_scoring.py     # 新增：评分核算/重试/空 key_points/JSON 落库
    └── test_evaluation_trace.py       # 新增：US4 归属校验/过期/评分子 span

frontend/
└── src/
    ├── views/
    │   └── EvaluationManagement.vue   # 新增：设置/评测两个 tab 容器
    ├── components/evaluation/
    │   ├── EvaluationSettings.vue     # 新增：三下拉 + 测试集管理面板
    │   ├── EvaluationPanel.vue        # 新增：评测选择/发起/进度/历史列表
    │   ├── EvaluationDetail.vue       # 新增：每题详情（含分析 JSON/trace 入口）
    │   └── TestSetUploadModal.vue     # 新增：上传/重新上传弹窗
    ├── components/trace/
    │   └── TraceDrawer.vue            # 修改：新增可选 fetcher prop + expired 提示（R11）
    ├── services/
    │   ├── evaluationApi.js           # 新增：评测 REST + SSE 封装
    │   └── traceApi.js                # 修改：新增 fetchEvaluationItemTrace
    ├── router/index.js                # 修改：/evaluation 路由
    └── components/layout/AppLayout.vue  # 修改：知识库侧栏新增"知识库评测"菜单
```

本期不新增前端测试目录（frontend/tests 不存在），前端验证以 `npm run build` 与会话页 trace 回归为准。

**Structure Decision**: 沿用 KnowledgeManage 既有 models/schemas/services/routers 分层与 frontend views/components/services 结构；评测执行器独立为 `evaluation_runner.py`（后台任务编排）与 `evaluation_service.py`（数据与规则），agent 无会话入口放 `agent_runtime/evaluation.py` 以复用包内 snapshot/flows/tracing。LlmGateway/UserManage 零改动。

## Complexity Tracking

无宪法违例，无需填写。