# Quickstart: 知识库增删改查验证

## 前置条件

1. PostgreSQL 已启动，`knowledge_manage` schema 存在
2. KnowledgeManage 后端服务已启动（`python -m uvicorn app.main:app --reload`）
3. LlmGateway 后端服务已启动（提供模型 API）
4. 前端开发服务器已启动（`cd frontend && npm run dev`）
5. 数据库中已有至少 4 个不同 category 的模型（chat / embedding / rerank / vision 各一个）

## 验证场景

### V-001: 知识库列表 - 空状态
- **操作**: 导航到 `/knowledge` 页面
- **预期**: 显示空状态引导和"新建知识库"按钮

### V-002: 新建知识库
- **操作**: 点击"新建知识库" → 填写名称、描述、选择四个模型 → 确认
- **预期**: 弹窗关闭，列表中出现新知识库卡片，显示名称/描述/模型名称

### V-003: 名称唯一性校验
- **操作**: 再次点击"新建知识库" → 输入与 V-002 相同的名称 → 确认
- **预期**: 显示错误提示"该名称已存在"，不提交

### V-004: 模型选择器按类型过滤
- **操作**: 打开新建或编辑表单
- **预期**: LLM 选择器仅显示 chat 类模型，Embedding 仅显示 embedding 类，图片识别仅显示 vision 类，Rerank 仅显示 rerank 类

### V-005: 编辑知识库
- **操作**: 点击卡片"设置"按钮 → 修改名称 → 保存
- **预期**: 抽屉关闭，卡片显示新名称

### V-006: 删除知识库
- **操作**: 点击卡片"删除"按钮 → 确认删除
- **预期**: 确认对话框显示知识库名称，确认后卡片消失，显示成功提示

### V-007: 进入知识库
- **操作**: 点击知识库卡片（非按钮区域）
- **预期**: 导航到知识库详情页面

### V-008: 前端构建验证
- **命令**: `cd frontend && npm run build`
- **预期**: 构建成功，无编译错误

### V-009: 后端 API 手动验证
```bash
# 列表
curl -H "Authorization: Bearer $TOKEN" http://localhost:8002/api/knowledge/knowledge-bases

# 创建
curl -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"test-kb","llm_model_id":"<id>","embedding_model_id":"<id>","image_model_id":"<id>","rerank_model_id":"<id>"}' \
  http://localhost:8002/api/knowledge/knowledge-bases

# 更新
curl -X PUT -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"renamed-kb"}' \
  http://localhost:8002/api/knowledge/knowledge-bases/<kb_id>

# 删除
curl -X DELETE -H "Authorization: Bearer $TOKEN" \
  http://localhost:8002/api/knowledge/knowledge-bases/<kb_id>
```

## 相关文档
- 数据模型: [data-model.md](data-model.md)
- API 契约: [contracts/knowledge-base-api.md](contracts/knowledge-base-api.md)
- 技术决策: [research.md](research.md)
