# UserManage API Contract

**Service**: UserManage | **Base URL**: `/api/user` | **Auth**: JWT (签发方)

> **Pydantic 规范**: 所有 Request Body 和 Response 均使用 Pydantic V2 Model 定义，通过 `Field()` 控制必填、长度约束、默认值等。详见 [research.md R-011](../research.md#r-011-接口参数校验规范pydantic-model)。

## Pydantic Schemas

```python
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import Optional, List
from datetime import datetime

# --- Auth ---
class RegisterRequest(BaseModel):
    uid: str = Field(..., min_length=3, max_length=20, description="用户名")
    email: EmailStr = Field(..., description="邮箱")
    password: "[REDACTED]"

class LoginRequest(BaseModel):
    uid: str = Field(..., description="用户名")
    password: "[REDACTED]"

class RefreshRequest(BaseModel):
    refresh_token: str = Field(..., description="刷新令牌")

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "bearer"

# --- User ---
class UserCreateRequest(BaseModel):
    uid: str = Field(..., min_length=3, max_length=20)
    email: EmailStr
    password: "[REDACTED]"
    role_ids: List[str] = Field(default_factory=list)

class UserUpdateRequest(BaseModel):
    uid: Optional[str] = Field(None, min_length=3, max_length=20)
    email: Optional[EmailStr] = None
    password: "[REDACTED]"
    role_ids: Optional[List[str]] = None

class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    uid: str
    email: str
    role_ids: List[str]
    is_active: bool = True
    created_at: datetime

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "bearer"
    user: UserResponse

# --- Role ---
class RoleCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    description: str = Field("", max_length=200)

class RoleUpdateRequest(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=50)
    description: Optional[str] = Field(None, max_length=200)

class RoleResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    description: str
    created_at: datetime
```

## 认证相关

### POST /auth/register

注册用户

**Request Body**:
```json
{
  "uid": "string (3-20 chars, required)",
  "email": "string (valid email, required)",
  "password": "[REDACTED]"
}
```

**Response 201**:
```json
{
  "id": "uuid",
  "uid": "string",
  "email": "string",
  "role_ids": ["string"],
  "created_at": "ISO8601"
}
```

**Error 400**: `{ "detail": "用户名已存在" | "邮箱已被注册" | "..." }`

---

### POST /auth/login

用户登录

**Request Body**:
```json
{
  "uid": "string (required)",
  "password": "[REDACTED]"
}
```

**Response 200**:
```json
{
  "access_token": "JWT string",
  "refresh_token": "JWT string",
  "token_type": "bearer",
  "user": {
    "id": "uuid",
    "uid": "string",
    "email": "string",
    "role_ids": ["string"],
    "permissions": ["string"]
  }
}
```

**Error 401**: `{ "detail": "用户名或密码错误" }`
**Error 423**: `{ "detail": "账户已锁定，请 {minutes} 分钟后再试" }`

---

### POST /auth/logout

退出登录（需要 Authorization header）

**Response 200**: `{ "message": "退出成功" }`

---

### POST /auth/refresh

刷新 Token

**Request Body**:
```json
{
  "refresh_token": "string (required)"
}
```

**Response 200**:
```json
{
  "access_token": "JWT string",
  "token_type": "bearer"
}
```

---

## 用户管理（需 permission_manage 权限）

### GET /users

获取用户列表

**Query Params**: `page` (int, default 1), `page_size` (int, default 20)

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "uid": "string",
      "email": "string",
      "role_ids": ["string"],
      "is_active": true,
      "created_at": "ISO8601"
    }
  ],
  "total": 50,
  "page": 1,
  "page_size": 20
}
```

---

### POST /users

创建用户（管理员操作）

**Request Body**: 同 `/auth/register`，额外可选 `role_ids`

**Response 201**: 同 `/auth/register` 响应

---

### PUT /users/{user_id}

修改用户信息

**Path Parameter**: `user_id` (string, UUID, 必填) — 待更新的用户 ID

**Request Body**:
```json
{
  "uid": "string (optional)",
  "email": "string (optional)",
  "password": "[REDACTED]"
  "role_ids": ["string (optional)"]
}
```

**Response 200**: 更新后的用户对象

---

### DELETE /users/{user_id}

删除用户

**Path Parameter**: `user_id` (string, UUID, 必填) — 待删除的用户 ID

**Response 200**: `{ "message": "用户删除成功" }`

**注意**: 删除用户后，其在 KnowledgeManage 中创建的提示词和会话保留，creator_id/user_id 保留原始值。

---

## 角色管理（需 permission_manage 权限）

### GET /roles

获取角色列表

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "string",
      "description": "string",
      "created_at": "ISO8601"
    }
  ]
}
```

---

### POST /roles

创建角色

**Request Body**:
```json
{
  "name": "string (1-50 chars, required)",
  "description": "string (max 200 chars, default '')"
}
```

**Response 201**: 创建后的角色对象

---

### PUT /roles/{role_id}

修改角色

**Path Parameter**: `role_id` (string, UUID, 必填) — 待更新的角色 ID

**Request Body**: 同 POST /roles

**Response 200**: 更新后的角色对象

---

### DELETE /roles/{role_id}

删除角色

**Path Parameter**: `role_id` (string, UUID, 必填) — 待删除的角色 ID

**Response 200**: `{ "message": "角色删除成功" }`
**Error 400**: `{ "detail": "该角色已分配给用户，请先解除关联后再删除" }`

---

## 公共

### GET /auth/me

获取当前登录用户信息

**Headers**: `Authorization: Bearer <access_token>`

**Response 200**:
```json
{
  "id": "uuid",
  "uid": "string",
  "email": "string",
  "role_ids": ["string"],
  "permissions": ["string"]
}
```

---

### GET /permissions

获取预定义权限项列表

**Response 200**:
```json
{
  "items": [
    { "key": "prompt_manage", "label": "提示词管理" },
    { "key": "chat_manage", "label": "会话管理" },
    { "key": "model_manage", "label": "模型管理" },
    { "key": "permission_manage", "label": "权限管理" }
  ]
}
```
