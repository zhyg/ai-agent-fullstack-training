# Data Model: 知识库中文档管理

**Date**: 2026-11-16 | **Feature**: 008-knowledge-doc-management

## Entity Relationship Overview

```
KnowledgeBase (已有)
  │
  ├── 1:N ── Folder (新增)
  │             │
  │             ├── 1:N ── Folder (自引用, 子目录)
  │             └── 1:N ── Document (新增)
  │
  └── 1:N ── Document (直接关联知识库)
```

## Folder (目录)

**表名**: `folders`  
**Schema**: 与 KnowledgeBase 相同 (`knowledge_manage`)

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK, UUID | 目录唯一标识 |
| name | String(200) | NOT NULL | 目录名称 |
| kb_id | String(36) | NOT NULL, FK → knowledge_bases.id | 所属知识库 |
| parent_id | String(36) | NULLABLE, FK → folders.id | 父目录（NULL 表示根目录） |
| order | Integer | NOT NULL, DEFAULT 0 | 同级排序序号 |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**索引与约束**:
- `UNIQUE(kb_id, parent_id, name)` — 同一父目录下目录名唯一（FR-011）
- `INDEX(kb_id)` — 按知识库查询目录
- `INDEX(parent_id)` — 按父目录查询子目录

**状态转换**: 无状态字段，目录为无状态实体

**级联规则**:
- 删除目录时，级联删除所有子目录和关联文档（FR-007）
- 删除知识库时，级联删除所有目录和文档

## Document (文档)

**表名**: `documents`  
**Schema**: 与 KnowledgeBase 相同 (`knowledge_manage`)

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK, UUID | 文档唯一标识 |
| name | String(500) | NOT NULL | 文件名称（含扩展名） |
| description | String(1000) | NULLABLE | 文档描述（详情抽屉中编辑） |
| tags | JSON/Text | DEFAULT '[]' | 标签列表（JSON 字符串数组） |
| file_size | BigInteger | NOT NULL | 文件大小（字节） |
| mime_type | String(200) | NULLABLE | MIME 类型 |
| extension | String(50) | NULLABLE | 文件扩展名（不含点号） |
| status | String(20) | NOT NULL, DEFAULT 'parsing' | 解析状态：parsing/success/failed |
| storage_path | String(1000) | NOT NULL | MinIO 中的对象路径 |
| folder_id | String(36) | NOT NULL, FK → folders.id | 所属目录 |
| kb_id | String(36) | NOT NULL, FK → knowledge_bases.id | 所属知识库 |
| created_at | TIMESTAMP | NOT NULL | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL | 更新时间 |

**索引与约束**:
- `INDEX(folder_id)` — 按目录查询文档
- `INDEX(kb_id)` — 按知识库查询文档
- `INDEX(status)` — 按状态过滤（如查找解析中的文档）

**状态转换**:
```
[parsing] ──(后端解析完成)──→ [success]
[parsing] ──(后端解析失败)──→ [failed]
```
> 注：当前阶段解析逻辑未实现，文档创建后状态固定为 `parsing`。状态转换由后续解析功能实现时触发。

**业务规则**:
- 解析中（parsing）状态的文档禁止删除（FR-023）
- 批量删除时跳过解析中的文档（FR-024）
- 标签以 JSON 数组存储，新增时自动去重和去除空白（FR-022）
- 文件大小以字节存储，前端展示时格式化为 KB/MB/GB（FR-020）

## 关系详情

### KnowledgeBase → Folder (1:N)
- 一个知识库包含多个目录
- 删除知识库时需级联清理所有目录

### Folder → Folder (自引用 1:N)
- parent_id 指向自身表的 id 字段
- parent_id 为 NULL 表示根目录
- 支持无限层级嵌套（FR-005）

### Folder → Document (1:N)
- 一个目录包含多个文档
- 删除目录时级联删除其下所有文档

### KnowledgeBase → Document (1:N)
- 文档同时关联知识库，便于跨目录查询

## MinIO 存储模型

**Bucket**: `myknowlege`（开发环境，通过配置文件管理）

**对象路径格式**: `{kb_id}/{folder_id}/{document_id}/{filename}`

**示例**:
```
myknowlege/
├── kb-uuid-1/
│   ├── folder-uuid-1/
│   │   ├── doc-uuid-1/report.docx
│   │   └── doc-uuid-2/data.xlsx
│   └── folder-uuid-2/
│       └── doc-uuid-3/notes.md
```

**清理策略**:
- 删除单个文档 → 删除对应 MinIO 对象
- 删除目录 → 按 `{kb_id}/{folder_id}/` 前缀批量删除
- 删除知识库 → 按 `{kb_id}/` 前缀批量删除

## 数据库迁移

新增 Alembic 迁移脚本 `xxx_add_folders_documents.py`:
1. 创建 `folders` 表
2. 创建 `documents` 表
3. 添加索引和约束
4. 回滚时按逆序删除
