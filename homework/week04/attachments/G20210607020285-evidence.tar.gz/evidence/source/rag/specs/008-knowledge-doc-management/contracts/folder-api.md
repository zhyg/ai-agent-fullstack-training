# Folder API Contract

**Base URL**: `/api/knowledge`  
**Auth**: Bearer JWT (所有接口均需要认证)  
**Feature**: 008-knowledge-doc-management

## Endpoints

### GET /knowledge-bases/{kb_id}/folders

获取知识库下的所有目录列表（扁平列表，前端构建树形结构）。

**Path Parameters**:
- `kb_id` (string, UUID) — 知识库 ID

**Response** `200 OK`:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "根目录",
      "kb_id": "uuid",
      "parent_id": null,
      "order": 0,
      "created_at": "2026-11-16T10:00:00Z",
      "updated_at": "2026-11-16T10:00:00Z"
    }
  ]
}
```

**Error Responses**:
- `404` — 知识库不存在或无权访问

---

### POST /knowledge-bases/{kb_id}/folders

创建新目录（根目录或子目录）。

**Path Parameters**:
- `kb_id` (string, UUID) — 知识库 ID

**Request Body**:
```json
{
  "name": "新目录",
  "parent_id": null
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| name | string | 是 | 1-200 字符 | 目录名称 |
| parent_id | string \| null | 否 | UUID 或 null | 父目录 ID，null 表示根目录 |

**Response** `201 Created`:
```json
{
  "id": "uuid",
  "name": "新目录",
  "kb_id": "uuid",
  "parent_id": null,
  "order": 0,
  "created_at": "...",
  "updated_at": "..."
}
```

**Error Responses**:
- `404` — 知识库不存在或父目录不存在
- `409` — 同一父目录下已存在同名目录

---

### PUT /folders/{folder_id}

更新目录（重命名或移动）。

**Path Parameters**:
- `folder_id` (string, UUID) — 目录 ID

**Request Body**:
```json
{
  "name": "新名称",
  "parent_id": "uuid",
  "order": 2
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| name | string | 否 | 1-200 字符 | 新名称 |
| parent_id | string \| null | 否 | UUID 或 null | 新父目录 |
| order | integer | 否 | ≥0 | 新排序位置 |

**Response** `200 OK`: 更新后的目录对象

**Error Responses**:
- `404` — 目录不存在
- `409` — 目标父目录下已存在同名目录
- `422` — 不能将目录移动到自身或其子孙目录下

---

### DELETE /folders/{folder_id}

删除目录及其所有子目录和关联文档。

**Path Parameters**:
- `folder_id` (string, UUID) — 目录 ID

**Response** `200 OK`:
```json
{
  "message": "目录删除成功",
  "deleted_folders": 3,
  "deleted_documents": 5
}
```

**Error Responses**:
- `404` — 目录不存在

---

### PUT /folders/{folder_id}/move

拖拽移动目录到新位置（专用接口，处理排序和同级重命名）。

**Path Parameters**:
- `folder_id` (string, UUID) — 被拖拽的目录 ID

**Request Body**:
```json
{
  "target_parent_id": null,
  "target_index": 2,
  "auto_rename": true
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| target_parent_id | string \| null | 是 | UUID 或 null | 目标父目录 |
| target_index | integer | 是 | ≥0 | 目标位置索引 |
| auto_rename | boolean | 否 | — | 同名时是否自动重命名（默认 true） |

**Response** `200 OK`:
```json
{
  "folder": { /* 更新后的目录对象 */ },
  "renamed": false,
  "original_name": null
}
```

**Error Responses**:
- `404` — 目录不存在
- `422` — 不能拖拽到自身或子孙目录下
