# Implementation Plan: LLM 统一模型调用网关

**Branch**: `004-llm-gateway-unified` | **Date**: 2026-10-28 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/004-llm-gateway-unified/spec.md`

## Summary

构建 LLM 统一模型调用网关，提供兼容 OpenAI Chat Completions 协议的统一 API，通过适配器模式封装多供应商协议（OpenAI Responses API + Anthropic Messages API），支持流式输出、结构化输出、提示词模板引用、韧性保障（重试/限流/Fallback）和可观测性。同时在 KnowledgeManage 服务中增强聊天会话管理功能（状态机、Redis 取消信号传播、浏览器断开后恢复）。

## Technical Context

**Language/Version**: Python 3.11

**Primary Dependencies**: FastAPI 0.115, Pydantic 2.10, SQLAlchemy 2.0, httpx 0.28, prometheus_client, redis

**Storage**: PostgreSQL（持久化：模型配置、会话、消息）、内存（运行时：能力注册表、限流器）、Redis（聊天会话取消信号传播）

**Testing**: pytest + httpx AsyncClient（单元/集成测试）

**Target Platform**: Linux 服务器（Docker 容器部署）

**Project Type**: Web service（微服务架构，LlmGateway 端口 8003，KnowledgeManage 端口 8002）

**Performance Goals**: 100 并发请求下 P95 TTFT < 2s，模型调用成功率 > 99%

**Constraints**: 指数退避重试最多 3 次，限流按模型独立 RPM/TPM，API Key 供应商密钥不暴露

**Scale/Scope**: 初期 2 个供应商适配器，内部服务调用为主

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution 文件（`.specify/memory/constitution.md`）当前为未填充的模板，无强制约束。跳过 gate 检查。

**Phase 1 复查**: 设计产物与现有代码架构一致（FastAPI + Pydantic + SQLAlchemy + PostgreSQL schema 隔离），无违反项。

## Project Structure

### Documentation (this feature)

```text
specs/004-llm-gateway-unified/
├── plan.md              # This file
├── research.md          # Phase 0: 技术研究与决策
├── data-model.md        # Phase 1: 数据模型设计
├── quickstart.md        # Phase 1: 验证指南
├── contracts/
│   ├── openai-compatible-api.md  # OpenAI Compatible API 合同
│   └── chat-sessions-api.md      # 聊天会话 API 合同
└── tasks.md             # Phase 2: 实现任务（/speckit-tasks 生成）
```

### Source Code (repository root)

```text
LlmGateway/
├── app/
│   ├── adapters/                    # [新增] 适配器层
│   │   ├── __init__.py
│   │   ├── base.py                  # Adapter 抽象基类
│   │   ├── openai_adapter.py        # OpenAI Responses API 适配器
│   │   └── anthropic_adapter.py     # Anthropic Messages API 适配器
│   ├── core/
│   │   ├── config.py                # [修改] 新增 redis 配置
│   │   └── ...
│   ├── gateway/                     # [新增] Gateway 核心层
│   │   ├── __init__.py
│   │   ├── registry.py              # 能力注册表（CapabilityRegistry）
│   │   ├── router.py                # 能力路由器（CapabilityRouter）
│   │   ├── rate_limiter.py          # 限流器（RPM 滑动窗口 + TPM 令牌桶）
│   │   ├── retry.py                 # 重试策略（指数退避 + jitter）
│   │   ├── observability.py         # 可观测性（Prometheus 指标 + 结构化日志）
│   │   └── json_repair.py           # JSON 修复器（有限次数修复）
│   ├── models/
│   │   └── model.py                 # [修改] 新增 capabilities 字段
│   ├── routers/
│   │   ├── chat.py                  # [重构] 替换为 OpenAI Compatible API
│   │   └── models.py                # [无变更]
│   ├── schemas/
│   │   ├── chat_completion.py       # [新增] OpenAI Compatible 请求/响应 Schema
│   │   └── model.py                 # [修改] 新增 capabilities 字段
│   ├── services/
│   │   ├── llm_gateway_service.py   # [新增] Gateway 服务（编排调用链）
│   │   ├── model_service.py         # [修改] 适配 capabilities
│   │   └── prompt_service.py        # [新增] 提示词模板获取（HTTP → KnowledgeManage）
│   ├── dependencies.py              # [修改] 新增 API Key 鉴权依赖
│   └── main.py                      # [修改] 注册新路由，初始化注册表
├── alembic/
│   └── versions/
│       └── xxx_add_capabilities.py  # [新增] 迁移脚本
└── requirements.txt                 # [修改] 新增 prometheus_client, redis

KnowledgeManage/
├── app/
│   ├── models/
│   │   └── chat.py                  # [修改] 新增 status 字段
│   ├── routers/
│   │   └── chats.py                 # [修改] 新增 cancel 端点，状态管理
│   ├── schemas/
│   │   └── chat.py                  # [修改] 新增 status 字段
│   └── services/
│       └── chat_service.py          # [修改] 状态机、Redis Pub/Sub 取消
├── alembic/
│   └── versions/
│       └── xxx_add_chat_status.py   # [新增] 迁移脚本
└── requirements.txt                 # [修改] 新增 redis
```

**Structure Decision**: 采用现有微服务架构，在 LlmGateway 服务内新增 `adapters/` 和 `gateway/` 两个包，分别负责适配器层和 Gateway 核心逻辑层。聊天会话增强在 KnowledgeManage 服务内完成。

## Complexity Tracking

无 Constitution 违反项，无需记录。
