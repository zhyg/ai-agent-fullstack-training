# Quickstart: API Keys Management

**Feature**: 003-api-keys-management
**Date**: 2026-10-28

## Prerequisites

- Python 3.11+ 环境（conda env: `myAiEnvNew`）
- Node.js 26+（nvm: v26.10.0）
- PostgreSQL 数据库运行中（`127.0.0.1:5432`）
- UserManage 服务配置文件 `config.dev.yaml` 已就绪

## Step 1: 数据库迁移

```bash
cd UserManage
alembic upgrade head
```

**Expected**: 迁移脚本 `002_add_api_keys` 在 `user_manage` schema 下创建 `api_keys` 表。

**Verify**:
```sql
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'user_manage' AND table_name = 'api_keys';
```

## Step 2: 启动 UserManage 后端服务

```bash
cd UserManage
APP_ENV=dev uvicorn app.main:app --reload --port 8001
```

**Expected**: 服务启动成功，无报错。

**Verify**:
```bash
curl http://localhost:8001/api/user/health
# Expected: {"status":"ok","service":"UserManage"}
```

## Step 3: 测试后端 API

### 3.1 登录获取 Token

```bash
# 先登录获取 access_token
curl -X POST http://localhost:8001/api/user/auth/login \
  -H "Content-Type: application/json" \
  -d '{"uid":"admin","password":"[REDACTED]"
```

记录响应中的 `access_token`。

### 3.2 创建 API Key

```bash
curl -X POST http://localhost:8001/api/user/api-keys \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{"name":"测试 Key"}'
```

**Expected**: 返回 201，包含 `id`、`name`、`masked_key`、`secret`（完整密钥）、`created_at`。

### 3.3 查询 API Key 列表

```bash
curl http://localhost:8001/api/user/api-keys \
  -H "Authorization: Bearer <access_token>"
```

**Expected**: 返回 200，`items` 数组包含刚创建的 Key（不含 `secret` 字段）。

### 3.4 编辑 API Key 名称

```bash
curl -X PUT http://localhost:8001/api/user/api-keys/<key_id> \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{"name":"重命名后的 Key"}'
```

**Expected**: 返回 200，`name` 字段更新为新名称。

### 3.5 删除 API Key

```bash
curl -X DELETE http://localhost:8001/api/user/api-keys/<key_id> \
  -H "Authorization: Bearer <access_token>"
```

**Expected**: 返回 200，`{"message":"API key 已删除"}`。

### 3.6 验证 API Key（内部端点）

```bash
curl -X POST http://localhost:8001/api/user/api-keys/verify \
  -H "Content-Type: application/json" \
  -d '{"key":"sk-<完整密钥>"}'
```

**Expected**: 返回 `{"valid":true,"key_id":"...","user_id":"..."}` 或 `{"valid":false}`。

## Step 4: 启动前端开发服务

```bash
cd frontend
npm run dev
```

**Expected**: Vite 开发服务器启动，默认 `http://localhost:5173`。

## Step 5: 前端端到端验证

1. 浏览器打开前端应用，使用 `admin / admin123` 登录
2. 点击顶部导航栏 **AI** 下拉菜单
3. **验证**: 菜单中包含 **"API keys"** 选项
4. 点击 **API keys** 进入管理页面
5. **验证**: 页面标题 "API keys"，空状态提示"暂无 API key"
6. 点击 **"创建 API key"** 按钮
7. 输入名称（如 "My First Key"），点击 **"创建"**
8. **验证**: 弹出完整密钥展示窗口，可点击"复制 key"
9. 关闭展示窗口
10. **验证**: 列表中显示该 Key，`masked_key` 列为脱敏格式（如 `[REDACTED_API_TOKEN]...WxYz`）
11. 点击编辑按钮，修改名称后保存
12. **验证**: 列表中名称已更新
13. 在搜索框输入关键字
14. **验证**: 列表实时过滤显示匹配项
15. 点击删除按钮，确认删除
16. **验证**: Key 从列表中消失，提示"API key 已删除"

## Step 6: 边界条件验证

- 创建 20 个 Key 后，第 21 个创建请求应返回 400 错误，按钮置灰
- 名称输入纯空格后提交，应被前端验证拦截
- 未登录用户访问 API Keys 页面，应被重定向到登录页
