# Contract: 轨迹查询代理接口

**Feature**: 012-agent-logic-runtime | 服务：KnowledgeManage（JWT Bearer）

前端不直连 ES/Jaeger；本接口为唯一轨迹查询入口（FR-036）。

---

## GET /chats/{chat_id}/messages/{message_id}/trace

### 鉴权与归属

1. JWT 解析当前用户
2. 校验 message 属于 chat_id 且 chat.user_id == 当前用户，否则 **403** `{"detail": "无权查看该消息的轨迹"}`（US5-7）
3. message 不存在或不属于该会话 → **404**

### 查询逻辑

- `message.trace_id` 为 NULL → 200 `{"ready": false, "reason": "no_trace"}`（旧模式消息/异常早期失败）
- 按 `message.created_at`（UTC 日期）构造索引列表 `jaeger-span-{D-1},jaeger-span-{D},jaeger-span-{D+1}`（±1 天容错），`term: {"traceID": trace_id}`，`ignore_unavailable=true`，size ≤ 10000
- 命中 0 条 → 200 `{"ready": false, "reason": "pending"}` → 前端提示"trace 写入中，稍后重试"（US5-4）
- ES 不可用 → 503 `{"detail": "轨迹服务暂不可用"}`

### 成功响应 200（Jaeger UI 格式，与 TraceViewer `api.ts` 消费格式一致）

```json
{
  "ready": true,
  "data": [{
    "traceID": "32位hex",
    "spans": [{
      "traceID": "...", "spanID": "16位hex",
      "operationName": "agent.retrieve.hybrid",
      "references": [{"refType": "CHILD_OF", "traceID": "...", "spanID": "父spanID"}],
      "startTime": 1732300000000000,
      "duration": 1250000,
      "tags": [
        {"key": "agent.loop", "type": "int64", "value": 2},
        {"key": "agent.input", "type": "string", "value": "{...完整输入JSON...}"},
        {"key": "agent.output", "type": "string", "value": "{...完整输出JSON...}"},
        {"key": "tool.call_id", "type": "string", "value": "call_abc"}
      ],
      "logs": [
        {"timestamp": 1732300000500000,
         "fields": [{"key": "event", "type": "string", "value": "rerank_degraded"}]}
      ],
      "processID": "p1"
    }],
    "processes": {"p1": {"serviceName": "knowledge-manage-agent", "tags": []}}
  }]
}
```

- 时间单位**微秒**（startTime=epoch μs，duration=μs），与 ES jaeger 文档一致
- 转换规则：ES 文档字段（traceID/spanID/operationName/references/startTime/duration/tags/process）映射为上述结构；`process` 去重合并为 processes 表；事件（span logs）映射为 logs.fields；CHILD_OF 引用规范化
- 不脱敏：`agent.input/agent.output` 含完整提示词与模型原始输出，普通用户与管理员所见一致（澄清 Q1 / US5-6）

### 前端消费契约

- `TraceDrawer.vue`（a-drawer，右侧，width≈60%）打开时调用本接口
- `ready:false` → 展示"trace 写入中，稍后重试"+ 重试按钮，不报错
- `ready:true` → `buildSpanTree`（移植自 TraceViewer）构树 → TraceTimeline（时间线/耗时）+ SpanDetail（点击步骤看 tags 中输入输出）+ StatisticsView（span 数/总耗时/各步骤耗时占比）
- 关闭抽屉返回会话，无路由变化（澄清 Q4）