# Quickstart & 验证指南: 智能体逻辑实现

**Feature**: 012-agent-logic-runtime | **Date**: 2026-11-23

本文档是端到端验证/运行指南（不含实现代码），并包含 **FR-037 要求的各智能体各用途提示词推荐文案**。接口细节见 [contracts/](./contracts/)，实体细节见 [data-model.md](./data-model.md)，技术决策见 [research.md](./research.md)。

---

## 1. 前置条件

| 依赖 | 要求 |
|---|---|
| Python | 3.11（conda myAiEnvNew） |
| PostgreSQL / Redis / Elasticsearch / MinIO | 既有开发环境已运行（config.dev.yaml 指向） |
| LlmGateway | 已运行，且模型管理中存在：chat 分析模型、embedding 模型、rerank 模型（display_name 已配置） |
| OTel Collector | OTLP gRPC 4317 监听，导出到 ES `jaeger-span-*`（参考 `opentelemetryDemo/otel-collector-config.yaml`）；无 Collector 时设 `tracing.enabled=false` 可跑通问答（trace 提示不可用） |
| 基础数据 | ≥1 个知识库已完成文档解析入库（specs/010 流程，含 ≥1 个表格片段用于 US3 验证）；三个预置智能体已完成提示词/模型配置（specs/011） |

## 2. 安装与启动

```bash
# 后端依赖与迁移
cd KnowledgeManage
pip install -r requirements.txt          # 新增 langgraph / opentelemetry-sdk / opentelemetry-exporter-otlp-proto-grpc / tiktoken
alembic upgrade head                     # chats +3 列、messages +2 列（见 data-model.md §4）

# 配置（config.dev.yaml 新增段，默认值见 research.md R17）
# tracing: {enabled: true, otlp_endpoint: "http://localhost:4317"}
# agent_runtime: {tool_result_max_tokens: 4000, history_rounds: 10, ...}

APP_ENV=dev uvicorn app.main:app --port 8002

# 前端
cd frontend && npm install && npm run dev
```

## 3. 自动化测试

```bash
cd KnowledgeManage
pytest tests/test_retrieval_service.py tests/test_citation.py \
       tests/test_tool_runtime.py tests/test_agent_flows.py tests/test_trace_query.py -v
# 回归：既有会话/取消/流恢复测试必须全绿
pytest tests/test_chat_stream.py tests/test_chat_background.py -v
```

预期：三类流程（mock 网关/ES）、SQL 安全/白名单/截断、引用缓冲/无效句柄、trace 归属校验/日期容错全部通过；旧模式行为无回归。

## 4. 端到端验证场景

### V1 会话页改造与快速问答（US1，P1）

1. 登录 → 会话页：配置区仅见"知识库（多选）+ 智能体"，无"模型/提示词"下拉；未完成配置的智能体置灰带提示
2. 不选知识库 → 提问按钮置灰提示"请先选择知识库"；`curl` 直发空知识库请求 → 400（[chat-agent-api.md §2](./contracts/chat-agent-api.md)）
3. 选知识库+快速问答，输入模糊问题（如"这个怎么弄"）→ 收到一条说明原因的 AI 消息，流结束；补充信息再问 → 结合历史重新澄清
4. 输入清晰问题 → step 进度事件依次可见（clarify→rewrite→retrieve→rerank→compress→answer），答案流式输出；每句结论后可点击来源 → 弹层展示文档名+片段内容+"查看文档"跳转；图片正常显示
5. 选一个无相关内容的知识库提问 → "检索结果为空"提示落库
6. 删除智能体引用的某提示词后提问 → 立即流式 error 指明失效项（SC-007）
7. 存量旧会话 → 只读展示旧模型+提示词，无提问入口

### V2 推理行动循环（US2，P2）

1. 将推理行动 loop_count 设为 2，提复合问题 → 观察 2 轮 step 进度；达上限强制收敛出答案，trace 含 `forced_convergence` 事件（SC-004）
2. 多轮命中相同片段 → trace 中压缩输出无重复 chunk_id
3. 构造与上一轮几乎相同的 new_question 场景（mock）→ `idle_loop_converged` 提前收敛

### V3 规划推理与工具（US3，P3）

1. 启用全部 13 工具，提"检索+表格统计"复合问题 → trace 可见 createPlan/检索/listTableMetaData/sqlExecute 调用链，call_id 全程一致（SC-006）
2. 关闭某工具再问 → trace 无该工具调用
3. 安全用例（pytest 已覆盖，可抽查 trace）：非 SELECT SQL → `forbidden_sql`；白名单外 sqlite_url → `url_not_allowed`；越界 kept_indexes → 业务重试（SC-008）

### V4 停止（US4，P4）

1. 长答案流式中点击停止 → ≤3s 终止；部分答案保留为消息带"[已停止]"；trace 无停止后的新模型/工具 span（SC-005）
2. 循环执行中停止 → 同上，plan 随请求丢弃
3. 关闭浏览器标签页 30s 后查库 → 该轮消息带 stopped 标记（断线视同停止，R4）；30s 内刷新页面 → 流恢复继续
4. 生成中再次提问 → 409"当前问答尚未结束"

### V5 Trace 展示（US5，P5）

1. 完成问答 → AI 消息右侧"trace"按钮 → 右侧宽幅抽屉：时间线覆盖全部步骤与耗时；点击步骤看输入/输出（含完整提示词与模型原始输出）；统计页正确
2. 问答刚结束立即点击（BatchSpanProcessor 未落盘窗口）→ "trace 写入中，稍后重试"，重试后正常
3. 普通用户看自己消息 trace → 与管理员一致（不脱敏）；用另一账号构造他人 message_id 请求 → 403（[trace-api.md](./contracts/trace-api.md)）
4. 降级场景（停掉 rerank 模型）→ 答案正常生成，trace 含 `rerank_degraded` 事件

---

## 5. 提示词推荐文案（FR-037）

供管理员在提示词管理中配置参考。占位符约定：`{question}` 当前问题、`{history}` 会话历史、`{chunks}` 编号片段列表、`{context}` 累积上下文。**所有 JSON 输出步骤的提示词末尾统一追加**：`只输出一个 JSON 对象，不要输出任何其他文字或代码围栏。`（后端另有容错提取与重试兜底，见 FR-011）

### 5.1 澄清（clarify，三类共用）

```text
你是知识库问答系统的问题澄清助手。根据用户问题与会话历史，判断问题是否清晰、可独立执行检索。
判断标准：问题有明确的对象与意图；代词（"这个/它"）能在会话历史中找到明确指代；不含无法解析的歧义。
会话历史：{history}
用户问题：{question}
输出 JSON：{"clear": true/false, "reason": "不清晰时说明具体原因与需要补充的信息，清晰时为 null"}
```

### 5.2 重写（rewrite，三类共用）

```text
你是检索问题重写助手。将用户问题改写为适合知识库检索的独立问题：补全历史中的指代、展开缩写与口语表达、保留关键实体与限定条件，不添加原问题没有的信息，不回答问题本身。
会话历史：{history}
用户问题：{question}
输出 JSON：{"rewritten_question": "改写后的检索问题"}
```

### 5.3 压缩（compress，三类共用；规划推理中为 zip 工具）

```text
你是上下文过滤助手。给定问题与编号片段列表，挑选对回答问题有实质帮助的片段，只做筛选、不改写内容。宁缺毋滥：无关或重复信息不保留；确无有用片段时返回空数组。
问题：{question}
片段列表：{chunks}
输出 JSON：{"kept_indexes": [保留片段的从 0 开始整数索引，不重复、不越界]}
```

### 5.4 充足判断（sufficiency，仅推理行动）

```text
你是上下文充足性判断助手。判断已累积的上下文能否完整回答问题（覆盖问题的全部子问题与关键限定）。不充足时给出一个聚焦缺失信息的新检索问题，且必须与上一轮问题有实质差异。
问题：{question}
上一轮检索问题：{last_question}
已累积上下文：{context}
输出 JSON：{"sufficient": true/false, "new_question": "不充足时必填新检索问题，充足时为 null"}
```

### 5.5 规划（planning，仅规划推理）

```text
你是知识库问答的规划推理助手。你可以调用提供的工具分步解决问题：
1. 复杂问题先用 createPlan 制定计划，随进展用 updatePlan 更新步骤状态；
2. 用检索工具（bm25Search/vectorSearch/hybridSearch）获取知识，用 rerank 精排、zip 压缩去噪；
3. 遇到表格片段先用 listTableMetaData 了解表结构，再用 sqlExecute 执行只读 SELECT 统计查询；
4. 工具失败或结果为空时，分析原因后改写问题、更换工具或调整计划，不要重复相同的失败调用；
5. 已掌握足够信息时，不再调用工具，直接说明将进入答案生成。
用户问题：{question}
```

### 5.6 答案生成（answer，三类共用）

```text
你是严谨的知识库问答助手。仅依据提供的上下文片段回答，不使用外部知识，不编造。
要求：
1. 每句结论后紧跟内联引用标记 <ref id="cN"/>，cN 必须是上下文里出现过的片段句柄；一句可引用多个；
2. 不暴露片段原文编号规则、知识库标识等内部信息；
3. 上下文中的图片链接可直接以 Markdown 图片语法引用；
4. 上下文不足以回答时明确说明"现有资料不足"，不猜测；
5. 用与用户问题相同的语言，结构化、简洁地作答。
用户问题：{question}
上下文片段：{context}
```

> 系统在 answer 提示词后自动追加来源处理协议（仅可引用出现过的句柄、引用内联于结论同句、禁止暴露原始片段/知识库标识，FR-013），管理员无需在文案中重复。

### 5.7 配置对照表

| 智能体类型 | 必需提示词用途 | 推荐文案 |
|---|---|---|
| quick_qa 快速问答 | clarify / rewrite / compress / answer | 5.1 / 5.2 / 5.3 / 5.6 |
| reasoning_action 推理行动 | clarify / rewrite / compress / sufficiency / answer | 5.1 / 5.2 / 5.3 / 5.4 / 5.6 |
| planning_reasoning 规划推理 | clarify / rewrite / compress / planning / answer | 5.1 / 5.2 / 5.3 / 5.5 / 5.6 |

保存智能体时须满足 `max_output_tokens < 分析模型 context_tokens`（FR-020，前后端均校验）。