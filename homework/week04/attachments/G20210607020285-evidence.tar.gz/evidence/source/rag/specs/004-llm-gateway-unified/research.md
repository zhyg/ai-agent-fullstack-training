# Research: LLM 统一模型调用网关

**Feature**: 004-llm-gateway-unified | **Date**: 2026-10-28

## R-001: 适配器模式架构设计

**Decision**: 采用策略模式（Strategy Pattern）+ 能力注册表（Capability Registry）实现多适配器架构

**Rationale**: 
- 现有 `llm_proxy.py` 仅硬编码了 OpenAI Responses API 的调用逻辑，无法支持多供应商
- 策略模式让每个适配器独立封装供应商协议差异，符合开闭原则
- 能力注册表让路由器按能力（streaming、structured output、tool calling）匹配而非按名称，扩展新供应商时无需修改路由逻辑

**Alternatives considered**:
- 工厂模式：只能根据名称创建适配器，无法实现能力匹配 Fallback
- 装饰器模式：适合功能叠加，不适合协议差异封装

## R-002: SSE 流式通信协议

**Decision**: Gateway 对外使用标准 SSE 协议（`text/event-stream`），事件类型包括 `delta`（内容片段）、`usage`（用量）、`error`（错误）、`done`（完成）

**Rationale**:
- 现有 `llm_proxy.py` 已使用 `StreamingResponse` + SSE 格式，但事件类型不完整（仅有 content 和 done）
- 需要增加 `error` 事件类型以支持流中错误传递
- 需要增加 `usage` 事件类型以在流结束前传递完整 token 用量
- SSE 是 Web 标准，所有主流浏览器和 HTTP 客户端原生支持

**Alternatives considered**:
- WebSocket：双向通信过重，模型调用是单向输出场景
- gRPC streaming：前端不直接支持，需额外网关转换

## R-003: 限流实现策略

**Decision**: 基于滑动窗口计数器实现 RPM 限流，基于令牌桶实现 TPM 限流，使用内存存储（进程内）

**Rationale**:
- 现有 Model 表已有 `rpm` 和 `tpm` 字段，限流配置从数据库加载
- 初期内部服务调用规模下，进程内限流足够，无需引入 Redis 分布式限流
- RPM 使用滑动窗口确保精确控制每分钟请求数
- TPM 使用令牌桶适合处理突发 token 请求

**Alternatives considered**:
- Redis 分布式限流：增加外部依赖，初期内部服务规模不需要
- 固定窗口计数器：在窗口边界可能出现突发流量

## R-004: 重试与 Fallback 策略

**Decision**: 指数退避重试（base=1s, max=3 次, jitter=full）+ 能力匹配 Fallback

**Rationale**:
- PRD 明确要求带 jitter 的指数退避，最多 3 次
- Fallback 采用能力匹配策略（已澄清）：路由器在所有具备所需能力的可用适配器中自动选择替代模型
- 流式重试边界：首 delta 前可重试/Fallback，首 delta 后终止流不重试

**Alternatives considered**:
- 固定间隔重试：无法适应不同延迟场景
- 线性退避：在高并发下退避不够充分

## R-005: 可观测性集成方案

**Decision**: 使用 prometheus_client 库暴露指标端点，使用结构化日志记录单次调用细节

**Rationale**:
- PRD 要求通过自定义 Exporter 集成到 Prometheus
- `prometheus_client` 是 Python 生态最成熟的 Prometheus 集成库
- 指标（Metrics）聚合趋势，日志（Logs）记录单次调用细节，分工明确
- 所有指标携带 `user_email` 标签（通过 API Key 关联 UserManage 服务）

**Alternatives considered**:
- OpenTelemetry：功能更全面但引入复杂度高，当前 Prometheus 足够
- 纯日志方案：无法高效聚合趋势指标

## R-006: JSON 结构化输出校验与修复

**Decision**: 两层保证 — 请求时携带 JSON Schema 传给供应商，返回后用 Pydantic 本地校验；JSON 修复使用有限次数的正则提取 + 重试

**Rationale**:
- 供应商的 Schema 保证不等于应用层安全，必须本地校验
- Pydantic 是项目已有依赖，适合 JSON Schema 校验
- 修复策略：先尝试正则提取 JSON 块，再用 Pydantic 校验，最多 3 次
- 流式 JSON 需增量解析，流结束后做最终 Schema 校验

**Alternatives considered**:
- jsonschema 库：纯 JSON Schema 校验，但与 Pydantic 模型集成不如直接使用 Pydantic
- 不修复直接返回：用户体验差，模型输出的 JSON 常有格式问题

## R-007: 聊天会话状态管理

**Decision**: 在 KnowledgeManage 服务的 Chat 模型中增加 `status` 字段（四状态：idle/generating/completed/cancelled），使用 Redis Pub/Sub 实现多 Worker 间取消信号传播

**Rationale**:
- 四状态模型已在澄清中确认：空闲 → 生成中 → 已完成/已取消
- 现有 Chat 模型缺少 status 字段，需新增
- PRD 要求浏览器关闭后端继续运行，只有用户主动取消才停止
- 多 Worker 场景下取消信号需通过 Redis Pub/Sub 传播

**Alternatives considered**:
- WebSocket 通知取消：不适合多 Worker 间通信
- 数据库轮询：延迟高，资源浪费

## R-008: 服务间通信方式

**Decision**: LlmGateway 通过 HTTP 调用 KnowledgeManage 获取提示词模板；KnowledgeManage 通过 HTTP 调用 LlmGateway 进行模型调用

**Rationale**:
- 现有架构中各服务已通过 HTTP 互相调用（config.yaml 中的 services 配置）
- 提示词模板获取：LlmGateway → KnowledgeManage（GET /api/knowledge/prompts?name=X&version=Y）
- 模型调用：KnowledgeManage → LlmGateway（POST /api/llm/v1/chat/completions）
- 初期内部服务调用，HTTP 同步通信足够

**Alternatives considered**:
- gRPC：性能更好但引入复杂度高，内部服务不需要
- 消息队列异步通信：模型调用需要实时响应，不适合异步

## R-009: API Key 鉴权方案

**Decision**: 新增 API Key 鉴权机制（Bearer Token），与现有 JWT 鉴权并存。OpenAI Compatible API 使用 API Key 鉴权，管理接口保持 JWT 鉴权

**Rationale**:
- PRD 要求调用方通过 API Key 调用模型，系统根据 API Key 到 UserManage 获取用户邮箱
- 现有 LlmGateway 使用 JWT 鉴权（用于管理接口），需新增 API Key 鉴权（用于模型调用接口）
- API Key 已在 003-api-keys-management 规格中定义，本功能复用其数据结构
- 预留外部扩展：API Key 机制天然支持外部开发者访问

**Alternatives considered**:
- 仅用 JWT：不适合服务间调用和 SDK 集成场景
- OAuth2：过重，初期内部服务不需要

## R-010: Model 模型扩展能力字段

**Decision**: 在现有 Model 表中增加 `capabilities` 字段（JSON 数组），声明模型支持的能力（streaming、structured_output、tool_calling）

**Rationale**:
- 现有 Model 表缺少能力声明字段
- 能力注册表需要从 Model 配置中读取每个模型的能力
- JSON 数组格式灵活，支持后续扩展新能力类型
- 路由器根据 capabilities 进行能力匹配路由和 Fallback

**Alternatives considered**:
- 多个布尔字段（is_streaming, is_structured_output...）：扩展性差，每增加一个能力需改表结构
- 独立能力表：增加复杂度，初期能力类型有限
