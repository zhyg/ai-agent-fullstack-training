# Implementation Plan: 模型管理优化

**Branch**: `002-model-category-optimization` | **Date**: 2026-10-28 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/002-model-category-optimization/spec.md`

## Summary

为 LlmGateway 模型管理系统新增模型分类（chat/embedding/rerank/vision/speech）、供应商（provider）和显示名称（display_name）三个维度。后端通过数据库迁移扩展 Model 实体、重命名 max_tokens 为 context_tokens，并新增分类筛选接口；前端参照 MyKnowlegeWebDemo 的 UI 设计，在模型列表页实现分类标签页展示、表单新增分类/供应商/显示名称字段、会话页模型选择器支持分类分组。

## Technical Context

**Language/Version**: Python 3.11（后端）、JavaScript ES2022（前端）

**Primary Dependencies**: FastAPI + Pydantic v2 + SQLAlchemy（后端）、Vue 3 + Pinia + Ant Design Vue 4.x + Vite（前端）

**Storage**: PostgreSQL（schema: `llm_gateway`），Alembic 管理迁移

**Testing**: pytest（后端）

**Target Platform**: Linux/macOS 服务端 + 现代浏览器（Chrome/Firefox/Safari/Edge）

**Project Type**: web-service（前后端分离微服务架构）

**Performance Goals**: 100 个模型内分类标签切换响应时间不超过 1 秒（SC-002）

**Constraints**: 数据迁移不丢失已有数据；分类枚举固定 5 种；name 在同一供应商下唯一

**Scale/Scope**: 单一 LlmGateway 后端服务 + 单一前端应用，影响约 10 个文件

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution 文件为模板状态（无实际原则约束），无 Gate 违规。

## Project Structure

### Documentation (this feature)

```text
specs/002-model-category-optimization/
├── plan.md              # 本文件
├── spec.md              # 功能规格
├── research.md          # Phase 0 研究产出
├── data-model.md        # Phase 1 数据模型
├── quickstart.md        # Phase 1 验证指南
├── contracts/           # Phase 1 API 接口契约
│   └── model-api.md
└── tasks.md             # Phase 2 任务清单（由 /speckit-tasks 生成）
```

### Source Code (repository root)

```text
# 后端 - LlmGateway 服务
LlmGateway/
├── alembic/versions/
│   └── <new>_add_category_provider_display_context.py  # 新增迁移
├── app/
│   ├── models/model.py           # Model ORM 实体（扩展字段）
│   ├── schemas/model.py          # Pydantic 请求/响应模型（扩展字段）
│   ├── routers/models.py         # API 路由（新增 category 查询参数）
│   └── services/model_service.py # 业务逻辑（唯一性校验、分类筛选）

# 前端 - 主应用
frontend/
├── src/
│   ├── components/
│   │   ├── model/
│   │   │   ├── ModelList.vue       # 分类标签页 + 网格布局
│   │   │   ├── ModelCard.vue       # 模型卡片（展示分类/供应商/显示名称）
│   │   │   └── ModelFormDrawer.vue # 创建/编辑表单（新增字段）
│   │   └── chat/
│   │       └── MessageInput.vue    # 会话模型选择器（分类分组）
│   ├── services/modelApi.js       # API 调用层（新增 category 参数）
│   ├── stores/model.js            # Pinia 状态管理
│   └── utils/
│       └── model.js               # 新增：分类常量 + 工具函数
└── tests/
```

**Structure Decision**: 采用 Option 2（Web application 前后端分离结构），后端 LlmGateway 微服务 + frontend 前端应用。
