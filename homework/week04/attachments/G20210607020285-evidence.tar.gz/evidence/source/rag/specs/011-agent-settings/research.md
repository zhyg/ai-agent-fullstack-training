# Research: 智能体菜单功能完善（011-agent-settings）

**Date**: 2026-11-22 | **Input**: spec.md Technical Context 与现有代码勘察

## R1: 智能体配置的存储形态

- **Decision**: KnowledgeManage PostgreSQL schema `knowledge_manage` 新增单表 `agents`，配置整体存 JSONB 列 `config`；不按配置子项拆表。
- **Rationale**: 固定 3 行数据、配置结构随类型差异（循环次数/工具配置仅部分类型有）、无按配置子项查询/聚合的需求；JSONB 单表最简且与“整份配置保存/回显”的交互一致。
- **Alternatives considered**: ① 规范化多表（agent_prompts/agent_retrieval/agent_models/agent_tools）——拒绝：1:1/1:N 子表对 3 行数据无收益，增加迁移与 join 复杂度；② 独立 agent_configs 表——拒绝：与 agents 恒 1:1，无独立生命周期。

## R2: 预置数据注入方式

- **Decision**: Alembic 数据迁移在建表同 revision 内插入三条预置记录（type 分别为 quick_qa/reasoning_action/planning_reasoning，含默认描述与默认配置），插入前按 type 判存保证幂等。
- **Rationale**: 项目所有结构/数据变更均走 Alembic（现有 versions 目录约定），可审计、可重放；避免应用启动 seed 的竞态与隐式副作用。
- **Alternatives considered**: 应用 lifespan 启动 seed——拒绝：绕过迁移审计、多实例启动竞态；前端本地常量兜底——拒绝：状态与配置必须服务端持久化（FR-003/FR-012）。

## R3: 管理员判定与写操作鉴权

- **Decision**: 复用现有权限键 `permission_manage`：后端写接口使用 `Depends(require_permission("permission_manage"))`（dependencies.py 已有工厂），读接口 `get_current_user`；前端用 `userStore.isAdmin`（stores/user.js 已实现，同权限键）控制菜单与按钮可见性。
- **Rationale**: 与提示词管理 `_is_admin` 判定完全一致（prompt_service.py L16-19），前后端同源，零新增权限概念。
- **Alternatives considered**: 新增 role 字段/新权限键——拒绝：引入权限体系改动且与现有判定分裂；仅前端隐藏——拒绝：违反 FR-017 后端必须拒绝非管理员写操作。

## R4: 提示词/模型引用的保存与失效处理

- **Decision**: config 中仅存引用标识：提示词存 `prompt_id`（同库 prompts.id），模型存模型标识字符串（LlmGateway 模型 id/name）。保存时后端校验必填用途的 prompt_id 在 prompts 表存在（不存在→400）；模型引用不做后端跨服务校验，失效标记由前端在打开弹窗时对照已拉取的提示词/模型列表计算（FR-015）。
- **Rationale**: 提示词同库校验成本极低且能兜底必填完整性；模型在 LlmGateway 独立库，后端跨服务校验引入耦合与失败模式，而前端本就需拉取模型列表渲染下拉，顺带失效检测最经济。
- **Alternatives considered**: ① 后端 httpx 调 LlmGateway 校验模型——拒绝：新增跨服务依赖与超时失败面；② 完全不校验——拒绝：必填提示词失效仍可保存会破坏 FR-015；③ 建跨库外键——拒绝：微服务库边界不允许。

## R5: 提示词/模型下拉选项的数据获取

- **Decision**: 提示词复用 `GET /api/knowledge/prompts`（page_size=100 循环翻页至 total，管理员可见全部，遵循现有可见性、不做用途过滤）；模型复用 frontend 现有 model store / modelApi（`/api/llm`）的全量加载方式（与模型管理页一致），按 category 过滤 chat/embedding/rerank。
- **Rationale**: 零新增后端接口、零提示词管理改动（澄清 Q3）；复用现有分页与分类过滤能力。
- **Alternatives considered**: 新增 /prompts/all、/agents/options 聚合接口——拒绝：超出本期最小范围且重复现有能力。

## R6: 图标来源与存储

- **Decision**: 内置图标库＝@ant-design/icons-vue 的固定子集（如 ThunderboltOutlined/BulbOutlined/PartitionOutlined 等，常量表维护于 frontend/src/utils/agent.js）；`agents.icon` 存图标 key 字符串；前端 key→组件映射渲染；预置三类型各给默认 key。
- **Rationale**: 澄清 Q4 选定内置图标库；复用现有依赖（ModelCard/PromptCard 已用该图标库），无上传/对象存储改动。
- **Alternatives considered**: 上传图片存 MinIO——拒绝：Q4 明确不支持；emoji 字符串——拒绝：与现有卡片视觉体系不一致。

## R7: 并发编辑冲突策略

- **Decision**: 最后保存者为准（last-write-wins），不加版本号/乐观锁。
- **Rationale**: spec Assumptions 明确本期不做冲突检测；3 行数据、管理员个位数，冲突概率与损失极低。
- **Alternatives considered**: updated_at 乐观锁/配置版本号——拒绝：超出本期范围，增加接口与 UI 复杂度。

## R8: 接口形态

- **Decision**: REST：`GET /agents`（列表）、`GET /agents/{id}`（详情）、`PUT /agents/{id}`（整份基础信息+config 更新）、`PATCH /agents/{id}/status`（仅状态切换）。名称唯一用 DB unique 约束 + 服务层预检（409）。
- **Rationale**: 卡片菜单的停用/启用是独立原子操作，独立 status 端点避免整份 PUT 的误覆盖；整份 PUT 与弹窗“保存”语义一致。
- **Alternatives considered**: 单一 PUT 含 status——拒绝：状态操作需携带整份配置，易误覆盖；GraphQL/RPC——拒绝：与现有 REST 约定不符。

## R9: 配置校验落点

- **Decision**: Pydantic v2 schema 承担范围校验（召回/重排 1–100、循环 1–1000、max_tokens 1–50000）与条件必填（分析模型必填；mode∈{vector,hybrid} 时 embedding 模型必填；rerank 模型必填；用途提示词按类型必填，规划推理中被取消勾选工具对应用途转可选）；前端 a-form 规则做同范围即时提示；名称唯一服务层预检 + DB 约束兜底。
- **Rationale**: 与现有 schemas/prompt.py 的 Field 约束风格一致；前后端双重校验保证 SC-003 的 100% 拦截。
- **Alternatives considered**: 仅前端校验——拒绝：接口可被绕过（FR-013/FR-017）；仅后端校验——拒绝：体验差且不符合现有表单交互惯例。

## R10: 测试策略

- **Decision**: 后端 pytest 新增 tests/test_agents.py（列表/详情/更新/状态/403/400/409/预置存在性），沿用现有 tests 的 client/db fixture 约定；前端按 quickstart.md 场景手动验收（仓库 frontend 无单测基建）。
- **Rationale**: 与 KnowledgeManage 现有测试组织一致；不引入新测试框架。
- **Alternatives considered**: 引入 vitest/playwright 基建——拒绝：超出本期范围。

## 未决项

无。Technical Context 无 NEEDS CLARIFICATION 残留（spec 澄清 Q1–Q4 已解决全部范围/权限/数据决策）。