# API Contract: 模型管理接口

**Feature**: 002-model-category-optimization | **Base URL**: `/api/llm` | **Date**: 2026-10-28

## Endpoints

### GET /models — 获取模型列表

**变更**: 新增 `category` 可选查询参数，支持按分类筛选。

**Request**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `page` | integer | 否 | 页码，默认 1，ge=1 |
| `page_size` | integer | 否 | 每页条数，默认 20，1~100 |
| `category` | string | 否 | 分类筛选，枚举值：chat/embedding/rerank/vision/speech；不传返回全部 |

**Response** `200 OK`:

```json
{
  "items": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "gpt-4o",
      "display_name": "GPT-4o",
      "category": "chat",
      "provider": "OpenAI",
      "url": "https://api.openai.com/v1/chat/completions",
      "api_key_masked": "[REDACTED]"
      "context_tokens": 128000,
      "rpm": 500,
      "tpm": 30000,
      "input_per_million": "5.0000",
      "output_per_million": "15.0000",
      "cached_input_per_million": "1.2500",
      "created_at": "2026-10-28T08:00:00",
      "updated_at": "2026-10-28T08:00:00"
    }
  ],
  "total": 1,
  "page": 1,
  "page_size": 20
}
```

**Authorization**: Bearer Token（需要 `model_manage` 权限）

---

### POST /models — 创建模型

**变更**: 请求体新增 `category`、`provider`、`display_name` 字段；`max_tokens` 更名为 `context_tokens`。

**Request Body**:

```json
{
  "name": "gpt-4o",
  "display_name": "GPT-4o",
  "category": "chat",
  "provider": "OpenAI",
  "url": "https://api.openai.com/v1/chat/completions",
  "api_key": "[REDACTED]"
  "context_tokens": 128000,
  "rpm": 500,
  "tpm": 30000,
  "input_per_million": 5.0,
  "output_per_million": 15.0,
  "cached_input_per_million": 1.25
}
```

| 字段 | 类型 | 必填 | 校验规则 | 说明 |
|------|------|------|---------|------|
| `name` | string | 是 | 1~100 字符 | 模型 API 标识 |
| `display_name` | string | 否 | max 200 字符 | 显示名称（缺省使用 name） |
| `category` | string | 是 | chat/embedding/rerank/vision/speech | 模型分类 |
| `provider` | string | 是 | 1~100 字符 | 供应商名称 |
| `url` | string | 是 | 非空 | API 端点 URL |
| `api_key` | string | 是 | 非空 | API Key（明文，服务端加密存储） |
| `context_tokens` | integer | 是 | ge=1 | 上下文窗口大小 |
| `rpm` | integer | 是 | ge=0 | 每分钟请求数 |
| `tpm` | integer | 是 | ge=0 | 每分钟 token 数 |
| `input_per_million` | decimal | 是 | ge=0, 4位小数 | 输入价格 |
| `output_per_million` | decimal | 是 | ge=0, 4位小数 | 输出价格 |
| `cached_input_per_million` | decimal | 是 | ge=0, 4位小数 | 缓存命中价格 |

**Response** `201 Created`: 返回 ModelResponse（同 GET 单个 item 格式）

**Error** `409 Conflict`:

```json
{
  "detail": "该供应商下已存在同名模型"
}
```

**Authorization**: Bearer Token（需要 `model_manage` 权限）

---

### PUT /models/{model_id} — 更新模型

**变更**: 请求体新增 `category`、`provider`、`display_name` 字段；`max_tokens` 更名为 `context_tokens`。

**Path Parameter**: `model_id` (string, UUID)

**Request Body**:

```json
{
  "name": "gpt-4o",
  "display_name": "GPT-4o（更新版）",
  "category": "chat",
  "provider": "OpenAI",
  "url": "https://api.openai.com/v1/chat/completions",
  "api_key": "[REDACTED]"
  "context_tokens": 128000,
  "rpm": 1000,
  "tpm": 60000,
  "input_per_million": 5.0,
  "output_per_million": 15.0,
  "cached_input_per_million": 1.25
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `name` | string | 是 | 模型名称 |
| `display_name` | string | 否 | 显示名称 |
| `category` | string | 是 | 分类 |
| `provider` | string | 是 | 供应商 |
| `url` | string | 是 | API 端点 |
| `api_key` | string | 否 | 留空/不传/null 保留原密钥 |
| `context_tokens` | integer | 是 | 上下文窗口 |
| `rpm` | integer | 是 | RPM |
| `tpm` | integer | 是 | TPM |
| `input_per_million` | decimal | 是 | 输入价格 |
| `output_per_million` | decimal | 是 | 输出价格 |
| `cached_input_per_million` | decimal | 是 | 缓存命中价格 |

**Response** `200 OK`: 返回 ModelResponse

**Error** `404 Not Found`: `{ "detail": "模型不存在" }`

**Error** `409 Conflict`: `{ "detail": "该供应商下已存在同名模型" }`

**Authorization**: Bearer Token（需要 `model_manage` 权限）

---

### DELETE /models/{model_id} — 删除模型

**无变更**，接口签名和行为与现有版本一致。

**Response** `200 OK`: `{ "message": "模型删除成功" }`

---

## ModelResponse 格式变更

**新增字段**:

| 字段 | 类型 | 说明 |
|------|------|------|
| `display_name` | string \| null | 模型显示名称 |
| `category` | string | 模型分类枚举值 |
| `provider` | string | 供应商名称 |

**重命名字段**:

| 旧字段 | 新字段 | 说明 |
|--------|--------|------|
| `max_tokens` | `context_tokens` | 上下文窗口大小，语义不变 |

**保留字段**: `id`, `name`, `url`, `api_key_masked`, `rpm`, `tpm`, `input_per_million`, `output_per_million`, `cached_input_per_million`, `created_at`, `updated_at`

---

## Backward Compatibility

- 旧版客户端发送 `max_tokens` 将被忽略（新 schema 不接受此字段），需同步升级前端
- 响应中不再包含 `max_tokens` 字段，前端需改用 `context_tokens`
- 旧模型的 `category` 字段由迁移脚本填充默认值 `'chat'`，API 响应中始终包含 `category`
