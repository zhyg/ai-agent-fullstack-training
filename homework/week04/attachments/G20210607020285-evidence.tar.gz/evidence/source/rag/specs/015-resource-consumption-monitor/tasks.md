# Tasks: 资源消耗监控

**Input**: Design documents from `/specs/015-resource-consumption-monitor/`

**Prerequisites**: plan.md、spec.md、research.md、data-model.md、contracts/consumption-api.md、quickstart.md

**Tests**: 计划与 quickstart 明确要求 pytest 覆盖（mock Prometheus/UserManage，沿用 `patch("app.dependencies.decode_token")` 模式）与前端 `npm run build` 验证，故包含测试任务（非 TDD 强制先行）。

**Organization**: 按用户故事分组，每个故事可独立实现、独立验证、增量交付。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行（不同文件、无未完成依赖）
- **[Story]**: 所属用户故事（US1/US2/US3）
- 路径为仓库根相对路径（Web app 双目录：`KnowledgeManage/` + `frontend/`）

## Path Conventions

- 后端：`KnowledgeManage/app/`（routers/schemas/services 三层）、`KnowledgeManage/tests/`
- 前端：`frontend/src/`（views/components/services/router）
- 决策依据：源文档 `mySpecs/016.资源消耗监控.md` §0 十三项决策 + spec.md Clarifications

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: 依赖与配置就绪

- [X] T001 [P] 新增 echarts 依赖至 frontend/package.json 并执行 npm install（按需引入 echarts/core + LineChart + Grid/Tooltip/LegendComponent + CanvasRenderer，不引入 vue-echarts，R-007/决策5）
- [X] T002 [P] 在 KnowledgeManage/app/core/config.py 新增 PrometheusConfig（url 默认 http://localhost:9091、timeout 默认 10.0、retention_days 默认 15，data-model §2.4），并向 KnowledgeManage/config.dev.yaml、config.test.yaml、config.prod.yaml 追加 prometheus 段；验证三环境 Settings 加载取值正确

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: 所有用户故事共用的 DTO、服务基础能力、路由骨架与前端 API/入口

**⚠️ CRITICAL**: 本阶段完成前不得开始任何用户故事

- [X] T003 [P] 创建 KnowledgeManage/app/schemas/consumption.py：ConsumptionQuery（metric 枚举 `tokens|cost`；scope 枚举 `user_daily|user_monthly|all_monthly`；user_email 在 scope=user_* 时必填非空；models 逗号分隔、"空/缺省 = 全部模型"；month 在 scope=user_daily 时必填、格式 `YYYY-MM`、"不得晚于当前月"；year 在 scope=*_monthly 时必填、范围 "2000–当前年"、"不得晚于当前年"）、SeriesOut（metric/scope 回显、buckets 升序字符串数组、series 为 {model, values} 且 values 与 buckets 等长对齐、out_of_retention 布尔）、OptionsOut（user_emails/models/is_admin），字段约束严格按 data-model.md §2
- [X] T004 创建 KnowledgeManage/app/services/consumption_service.py 基础能力：① 当前用户 email 解析——UserManage `GET /api/user/users/{uid}`（Bearer 透传当前 token，httpx 5s 超时，复用 prompt_service._resolve_user_names 模式），失败返回 502"无法解析当前用户身份"，不降级为任意查询（R-001）；② 管理员判定 `"permission_manage" in current_user["permissions"]`（R-002）；③ Prometheus httpx 异步客户端封装（settings.prometheus.url/timeout，连接失败/非 200 抛 502"指标数据源不可用"）
- [X] T005 创建 KnowledgeManage/app/routers/consumption.py 路由骨架（APIRouter prefix="/consumption"，依赖 get_current_user）并在 KnowledgeManage/app/main.py 注册（最终路径 /api/knowledge/consumption，contracts §1/§2）；依赖 T003/T004
- [X] T006 [P] 创建 frontend/src/services/monitorApi.js：沿用 evaluationApi.js 模式（axios baseURL `${VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'}/consumption`、Bearer 拦截器、401 清 token 跳登录、detailOf 错误提取），导出 getMonitorOptions() 与 getConsumptionSeries(params)（contracts §4）
- [X] T007 [P] 创建 frontend/src/views/ResourceMonitor.vue 页面骨架（标题+空容器），在 frontend/src/router/index.js 注册 /monitor 路由，在 frontend/src/components/layout/AppLayout.vue 新增"资源消耗监控"侧边栏菜单（与"智能体"同级、所有登录用户可见）及路由映射（FR-001，参考 L107-122/L153-169/L200-203 既有模式）

**Checkpoint**: 基础就绪——菜单可进入空页面，后端路由可访问（401 保护），可开始用户故事

---

## Phase 3: User Story 1 - 查看个人 token 消耗趋势 (Priority: P1) 🎯 MVP

**Goal**: 普通用户进入页面默认看到本人当月各模型每日 token 曲线；可切月份/人月视图/模型筛选后查询

**Independent Test**: 普通用户登录进页自动展示本人当月每日 token 曲线（每模型一条）；切上月查询补 0 连续；切人月选年查询 X 轴为月；清空模型等同全选；图例可隐藏曲线；当前月/年截断至今天/本月且选择器禁选未来（spec US1 场景 1-6）

### Implementation for User Story 1

- [X] T008 [US1] 在 KnowledgeManage/app/services/consumption_service.py 实现桶切分与 PromQL 拼装：zoneinfo "Asia/Shanghai" 自然日/月桶（日桶 label `YYYY-MM-DD`、月桶 `YYYY-MM`；完整日桶 window=86400、完整月桶为当月实际秒数；当前月截断至今天、当前年截断至本月，最后一个 partial 桶 end=now、window=已经过秒数，FR-012/018）；每桶 PromQL `sum by (model) (increase(llm_tokens_total{type!="cached",user_email="<email>",model=~"m1|m2"}[<window>s]))`（模型正则转义；全选/清空省略 model 过滤；折叠 category/prompt_name/prompt_version/type 维度，R-003/004）；asyncio.gather 并发（信号量上限 8）调 /api/v1/query（time=桶结束 UTC epoch）
- [X] T009 [US1] 在 KnowledgeManage/app/services/consumption_service.py 与 routers/consumption.py 实现 GET /consumption/series（metric=tokens，scope=user_daily/user_monthly）：参数校验非法/未来期间返回 400（"month 格式须为 YYYY-MM"/"不可查询未来期间"）；普通用户强制绑定本人 email（user_email≠本人且非管理员 → 403"无权查看其他用户的消耗数据"）；无数据桶补 0（仅限已经过桶）；token values 非负整数；series 按模型名升序；补 0 模型范围仅限 models 参数显式勾选的模型（查询期间全 0 仍返回全 0 曲线），全选（models 空/缺省）时仅返回区间内有数据的模型、不做额外 label values 查询；请求期间整体早于 now-retention_days → out_of_retention=true 且 buckets/series 为空（FR-013/014/017，contracts §2）；依赖 T008
- [X] T010 [US1] 在 KnowledgeManage/app/services/consumption_service.py 与 routers/consumption.py 实现 GET /consumption/options：调 Prometheus `/api/v1/label/{user_email|model}/values?match[]=llm_tokens_total`，排除空字符串、升序；user_emails 仅返回本人 email（管理员全量列表路径由 US3 T021 实现）；返回 is_admin 供前端渲染可见性（R-006，contracts §1）；依赖 T004
- [X] T011 [P] [US1] 创建 KnowledgeManage/tests/test_consumption.py（mock Prometheus HTTP 与 UserManage 解析，patch decode_token + admin_claims/user_claims 模式）：当前月桶数=今天日期且末桶 window<86400、历史月桶数=当月天数、未来期间 400；PromQL 含 type!="cached" 与 sum by (model)；无数据桶补 0 且与 buckets 等长；显式勾选模型区间无数据返回全 0 曲线、全选时不返回无数据模型；counter 重置增量非负；out_of_retention 判定；Prometheus 连接失败 502、email 解析失败 502；普通用户查他人 403（quickstart 场景 1）
- [X] T012 [P] [US1] 创建 frontend/src/components/monitor/ConsumptionChart.vue：echarts 按需引入封装（init/setOption(notMerge)/dispose、ResizeObserver 自适应、watch 数据变更重绘）；折线图每模型一条曲线按模型着色、tooltip 明细、图例点击隐藏/显示单条曲线（FR-008/011）；token 序列数值取整展示（R-007）
- [X] T013 [P] [US1] 创建 frontend/src/components/monitor/MonitorFilters.vue：user_email 单选（普通用户固定本人禁用）、模型多选（默认全选、清空等同全选、不设上限）、月份/年份选择器（disabledDate 禁选未来期间，FR-018）、"查询"按钮（loading 态）；筛选器随子视图变化（人日=月份、人月=年份，FR-005/006/007/008）
- [X] T014 [US1] 在 frontend/src/views/ResourceMonitor.vue 实现 token Tab 与人日/人月两个子视图（同一时刻只渲染一张图）：进页拉取 options 并按默认值（本人、全部模型、当前月/年）自动查询一次；此后仅点"查询"发请求；请求自增序号竞态保护（最新请求胜出，R-008）；out_of_retention 提示"超出数据保留期"、502 message.error 展示；接入 ConsumptionChart/MonitorFilters（FR-002/006/007/017）；依赖 T009/T010/T012/T013
- [X] T015 [US1] 验证 US1：运行 KnowledgeManage pytest tests/test_consumption.py 全绿 + frontend npm run build 通过；按 quickstart 场景 2/3 抽查默认视图 ≤5s 出图（SC-001）、补 0 连续（SC-006）、截断与禁选未来生效（自动化验证已过：24 用例全绿 + build 16.50s；活体抽查顺延至 T026：当前 Prometheus 不可达、8002 为旧进程）

**Checkpoint**: MVP 可交付——个人 token 消耗监控完整可用

---

## Phase 4: User Story 2 - 查看个人费用消耗趋势 (Priority: P2)

**Goal**: 费用 Tab 以与 token 一致的交互展示本人各模型每日/每月费用（人民币元，6 位小数）

**Independent Test**: 费用 Tab 选月份/年份与模型后查询展示费用曲线，0.000123 类小额不被舍入为 0（SC-005）；与 token Tab 切换互不干扰、筛选条件独立保留（spec US2 场景 1-3）

### Implementation for User Story 2

- [X] T016 [US2] 在 KnowledgeManage/app/services/consumption_service.py 与 routers/consumption.py 扩展 metric=cost：PromQL 改为 `increase(llm_cost_estimate{...}[window])`（无 type 过滤，其余过滤/折叠/桶逻辑复用）；cost values 非负浮点、服务端 round 6 位（FR-015，contracts §2）
- [X] T017 [P] [US2] 在 KnowledgeManage/tests/test_consumption.py 追加费用用例：PromQL 使用 llm_cost_estimate 且无 type 过滤；0.000123 不被舍入为 0；values round 6 位；人日/人月口径与 token 一致（quickstart 场景 1 精度项）
- [X] T018 [US2] 在 frontend/src/views/ResourceMonitor.vue 与 components/monitor/ConsumptionChart.vue 实现费用 Tab：顶部 2 Tab（token 消耗/费用消耗）切换、两 Tab 筛选条件独立保留；Y 轴"费用（元）"、tooltip 与数据点 toFixed(6)（FR-002/015，R-007）；复用 US1 子视图/查询/竞态框架
- [X] T019 [US2] 验证 US2：pytest tests/test_consumption.py 全绿 + npm run build 通过；按 quickstart 场景 3 验证费用 Tab 6 位小数可读、Tab 切换互不干扰（自动化验证已过：30 用例全绿含 6 项费用用例 + build 22.10s；活体抽查顺延至 T026）

**Checkpoint**: token 与费用两个 Tab 均独立可用

---

## Phase 5: User Story 3 - 管理员全局消耗视角 (Priority: P3)

**Goal**: 管理员任选用户查看消耗、进入"所有人月"视图查看跨用户汇总；普通用户界面不可见且接口 403

**Independent Test**: 管理员任选用户/所有人月查询成功（token 与费用均可）；普通用户直连接口查他人或 all_monthly 返回 403，界面无相应入口（spec US3 场景 1-4，SC-002）

### Implementation for User Story 3

- [X] T020 [US3] 在 KnowledgeManage/app/services/consumption_service.py 与 routers/consumption.py 实现 scope=all_monthly：仅管理员（permission_manage）可访问，PromQL 省略 user_email 过滤实现跨用户求和（含空 user_email 数据，Assumptions）；权限矩阵：scope=all_monthly 普通用户 → 403（user_* 越权 403 复用 T009 实现，仅需回归验证）；管理员任选 user_email 放行（FR-003/004/011）
- [X] T021 [US3] 在 KnowledgeManage/app/services/consumption_service.py 与 routers/consumption.py 实现 options 管理员路径：管理员请求时 user_emails 返回指标中全部非空 email（升序），is_admin=true；普通用户路径已在 T010 完成，本任务仅扩展管理员分支（R-006，contracts §1）
- [X] T022 [P] [US3] 在 KnowledgeManage/tests/test_consumption.py 追加权限用例（普通用户查他人 403 已在 T011 覆盖，此处扩展至 cost 与 all_monthly）：管理员任选用户放行、all_monthly PromQL 无 user_email 过滤且跨用户求和、普通用户 all_monthly 403（token 与 cost 两 metric 均覆盖，SC-002）
- [X] T023 [US3] 在 frontend/src/views/ResourceMonitor.vue 与 components/monitor/MonitorFilters.vue 实现管理员视角：user_email 下拉管理员可选他人（普通用户固定本人禁用）；"所有人月"子视图仅管理员可见（userStore.isAdmin 与 options.is_admin 双保险），筛选器仅模型多选+年份；token/费用两 Tab 均支持（FR-003/005）
- [X] T024 [US3] 验证 US3：pytest tests/test_consumption.py 全绿 + npm run build 通过；按 quickstart 场景 2/3 验证管理员任选用户与所有人月、普通用户 curl 越权 403、界面入口隐藏（自动化验证已过：35 用例全绿含 5 项权限用例双 metric 覆盖 + build 16.19s；活体抽查顺延至 T026）

**Checkpoint**: 三个用户故事均独立可用，权限隔离 100% 有效

---

## Phase 6: Polish & Cross-Cutting Concerns

- [X] T025 [P] 全量回归：KnowledgeManage pytest tests/ -q 既有用例无回归 + frontend npm run build 通过（quickstart 场景 4）（449 passed + 1 已知存量失败 test_agents 活库预置断言，零回归；build 15.94s；新增前端文件无 console.log/debugger）
- [ ] T026 按 quickstart.md 场景 2/3 活体端到端验证：与 Prometheus 控制台同口径抽查误差为 0（SC-003）、管理员 1 分钟内定位年度最高消耗模型（SC-004）、停 Prometheus 错误提示不影响其他页面、超保留期提示

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，T001/T002 可并行
- **Foundational (Phase 2)**: 依赖 Setup；T003/T006/T007 可并行，T004 依赖 T002，T005 依赖 T003/T004；**阻塞所有用户故事**
- **US1 (Phase 3)**: 依赖 Foundational；T008→T009→T010 同文件顺序执行，T011/T012/T013 可与之并行，T014 依赖 T009/T010/T012/T013，T015 收口
- **US2 (Phase 4)**: 依赖 US1 页面骨架与查询框架（spec 明确"依赖 US1 的页面骨架"）；T016→T018，T017 可并行
- **US3 (Phase 5)**: 依赖 US1/US2 视图与权限框架；T020→T021 同文件顺序，T022 可并行，T023 依赖 T020/T021，T024 收口
- **Polish (Phase 6)**: 依赖全部故事完成

### User Story Dependencies

- **US1 (P1)**: Foundational 后即可开始，不依赖其他故事 → MVP
- **US2 (P2)**: 复用 US1 的 series 框架与页面骨架（metric 参数化已在 US1 预留），后端增量极小
- **US3 (P3)**: 复用 US1/US2 的视图与权限判定，新增 all_monthly scope 与管理员 options 路径

### Within Each User Story

- 服务层（桶切分/PromQL）→ 路由端点 → 测试 → 前端组件 → 页面集成 → 验证
- 同一文件（consumption_service.py、routers/consumption.py、ResourceMonitor.vue、test_consumption.py）的任务严格顺序执行，不标 [P]

### Parallel Opportunities

- Setup：T001 ∥ T002
- Foundational：T003 ∥ T006 ∥ T007（T004/T005 顺序链）
- US1：T011（后端测试）∥ T012（图表组件）∥ T013（筛选器组件）∥ T008-T010（后端链）
- US2：T017 ∥ T016/T018；US3：T022 ∥ T020/T021/T023

---

## Parallel Example: User Story 1

```bash
# Foundational 完成后，以下任务可并行启动（不同文件）：
Task: "T008 桶切分与 PromQL 拼装（consumption_service.py，后端链起点）"
Task: "T011 US1 后端测试（tests/test_consumption.py）"
Task: "T012 ConsumptionChart.vue 图表封装"
Task: "T013 MonitorFilters.vue 筛选器"
# 后端链 T008→T009→T010 与前端组件完成后，T014 页面集成收口
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Phase 1 Setup（依赖+配置）
2. Phase 2 Foundational（DTO/服务基础/路由/前端 API/菜单入口）
3. Phase 3 US1 → **STOP & VALIDATE**：普通用户个人 token 监控独立可用
4. 可交付/演示 MVP

### Incremental Delivery

1. Setup + Foundational → 基础就绪
2. US1 → 独立验证 → 交付（MVP：个人 token 趋势）
3. US2 → 独立验证 → 交付（+费用趋势，6 位小数）
4. US3 → 独立验证 → 交付（+管理员全局视角与权限隔离）
5. Polish → 全量回归 + 活体端到端（SC-001~006 核验）

### Parallel Team Strategy

- 单人推荐顺序：T001-T002 → T003-T007 → US1 → US2 → US3 → Polish（同文件任务多，跨故事并行收益有限）
- 双人可拆：后端链（T004/T005/T008-T010/T016/T020/T021）∥ 前端链（T006/T007/T012-T014/T018/T023），测试随各自链落地

---

## Notes

- 十三项决策（mySpecs/016 §0）为唯一决策依据；费用 6 位小数为用户明确选择，不做估算标注
- LlmGateway 零改动；无数据库迁移；vite 代理零改动（/api/knowledge 已存在）
- 每完成一个任务或逻辑组提交一次；每个 Checkpoint 可停下独立验证
- 避免：同文件并行、跨故事强依赖、模糊任务描述