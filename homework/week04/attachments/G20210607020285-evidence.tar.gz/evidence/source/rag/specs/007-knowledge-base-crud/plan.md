# Implementation Plan: 知识库增删改查

**Branch**: `007-knowledge-base-crud` | **Date**: 2026-11-16 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `specs/007-knowledge-base-crud/spec.md`

## Summary

在 frontend 和 KnowledgeManage 后端服务中实现知识库的完整 CRUD 功能。后端新增 KnowledgeBase 实体（model/service/router/schema/migration），前端替换现有占位页面为卡片列表 + 创建弹窗 + 编辑抽屉 + 删除确认。模型选择器按 `category` 字段过滤（chat→LLM、embedding→Embedding、rerank→Rerank、vision→图片识别）。

## Technical Context

**Language/Version**: Python 3.11 (后端) / JavaScript ES2022+ (前端)

**Primary Dependencies**: FastAPI + SQLAlchemy + Pydantic (后端) / Vue 3 + Pinia + Ant Design Vue 4.x (前端)

**Storage**: PostgreSQL (schema: `knowledge_manage`)

**Testing**: pytest (后端) / Vitest (前端，仅构建验证)

**Target Platform**: Linux server (后端) / 现代浏览器 (前端)

**Project Type**: web-service + SPA frontend

**Performance Goals**: 列表 100 条内 1 秒加载，CRUD 操作 5 秒内完成

**Constraints**: JWT 认证、Schema 隔离、跨服务模型数据来自 LlmGateway

**Scale/Scope**: 单用户知识库数量预期 <100

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

constitution.md 为模板占位内容，无具体治理原则，自动通过。

## Project Structure

### Documentation (this feature)

```text
specs/007-knowledge-base-crud/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   └── knowledge-base-api.md
└── tasks.md             # Phase 2 output (/speckit-tasks)
```

### Source Code (repository root)

```text
KnowledgeManage/
├── app/
│   ├── models/
│   │   └── knowledge_base.py      # [NEW] KnowledgeBase ORM model
│   ├── schemas/
│   │   └── knowledge_base.py      # [NEW] Pydantic schemas
│   ├── services/
│   │   └── knowledge_base_service.py  # [NEW] CRUD service
│   ├── routers/
│   │   └── knowledge_bases.py     # [NEW] API router
│   └── main.py                    # [MODIFY] Register router
├── alembic/versions/
│   └── xxx_create_knowledge_bases.py  # [NEW] Migration

frontend/
├── src/
│   ├── services/
│   │   └── knowledgeBaseApi.js    # [NEW] API client
│   ├── stores/
│   │   └── knowledgeBase.js       # [NEW] Pinia store
│   ├── views/
│   │   └── KnowledgeManagement.vue # [REWRITE] Full CRUD page
│   └── components/
│       └── knowledge-base/
│           ├── KbList.vue         # [NEW]
│           ├── KbCard.vue         # [NEW]
│           ├── KbCreateModal.vue  # [NEW]
│           ├── KbFormDrawer.vue   # [NEW]
│           └── EmptyKb.vue        # [NEW]
```

**Structure Decision**: Web application pattern — backend (KnowledgeManage) + frontend (frontend/)，两个独立服务通过 HTTP API 通信

## Complexity Tracking

无宪法违规，无需记录。
