# Research: 聊天流式生成取消与断线恢复

**Feature**: 005-chat-stream-cancel | **Date**: 2026-10-30

## R-001: KnowledgeManage 后台生成与 SSE 分离架构

**Decision**: 将 `send_message_stream` 重构为"后台任务 + 观察者队列"模式。后台 asyncio.Task 负责从 LLM Gateway 读取流数据并持久化，SSE 生成器仅作为观察者从队列读取事件推送给前端。

**Rationale**:
- 当前实现中，SSE 生成器与 LLM Gateway 的读取逻辑耦合在同一个 async generator 中，前端断开连接会导致整个 generator 被取消（FastAPI StreamingResponse 在客户端断开时取消 async generator）
- 需要区分两种断开场景：前端主动取消（通过 Redis Pub/Sub 信号中断后台任务）vs 前端仅断开连接（页面离开，后台任务继续运行）
- 已有的测试文件 `test_chat_background.py` 定义了目标 API 契约：`_generations` dict、`_GenerationJob` (task/cancel/detached/done/_live)、`finish_generations()`

**Alternatives considered**:
- 使用 Redis Stream 替代内存队列：增加了外部依赖复杂度，且单实例部署下内存队列已足够
- 使用 WebSocket 双向通信：与现有 SSE 架构不兼容，改动范围过大

## R-002: _GenerationJob 数据结构设计

**Decision**: 使用 dataclass 定义 `_GenerationJob`，包含以下字段：
- `task: asyncio.Task` — 后台生成任务
- `cancel: asyncio.Event` — 取消信号（与 Redis Pub/Sub 联动）
- `detached: asyncio.Event` — 前端已断开标记
- `done: asyncio.Event` — 生成完成标记
- `_live: asyncio.Queue` — 事件分发队列（给已连接的 SSE 客户端）
- `content_buffer: str` — 已接收内容缓存（用于重新连接时回放）

**Rationale**:
- `asyncio.Event` 轻量且适合一次性信号，与 Redis cancel listener 配合使用
- `asyncio.Queue` 作为事件分发通道，支持后台任务写入、多个 SSE 客户端消费
- `content_buffer` 在内存中缓存已接收内容，避免重新连接时需要从数据库查询中间状态

**Alternatives considered**:
- 使用 `asyncio.Condition` 替代 Event + Queue：更复杂但无额外收益
- 将 content_buffer 持久化到 Redis：增加延迟和复杂度，单实例内存方案已满足需求

## R-003: 数据库会话生命周期管理

**Decision**: 后台任务使用独立的 `SessionLocal()` 数据库会话，而非请求作用域的 `db`。引入 `SessionLocal` 模块级引用供后台任务创建新会话。

**Rationale**:
- 请求作用域的 `db` 由 FastAPI 依赖注入管理，在请求结束时自动关闭
- 后台任务（detached 后）需要在请求结束后继续运行，必须拥有独立的数据库会话
- 已有测试 `test_chat_background.py` mock 了 `chat_service.SessionLocal`，确认了设计方向

**Alternatives considered**:
- 延长请求 db 生命周期到后台任务结束：违反 FastAPI 依赖注入模型，会导致连接泄漏
- 使用连接池的 scoped session：对于当前规模过于复杂

## R-004: 重新连接与内容回放机制

**Decision**: 用户重新进入会话页面时，通过现有 `GET /chats/{chat_id}/messages` 加载历史消息。如果会话状态为 `generating`，前端自动建立 SSE 连接，`send_message_stream` 检测到已有活跃 `_GenerationJob` 时直接附加（reattach），先回放 `_live` 队列中的缓冲事件，然后继续实时推送。

**Rationale**:
- 分离已持久化的消息（通过 REST API 获取）和正在生成中的内容（通过 SSE 获取）职责清晰
- `_GenerationJob` 的 `_live` 队列在后台任务持续运行期间会积累事件，新连接的客户端可以从中读取
- 已有测试 `test_duplicate_send_reattaches_to_active_job` 验证了此设计

**Alternatives considered**:
- 专门的"恢复"API 端点：增加 API 复杂度，复用现有 send_message_stream 更简洁
- 在 content_buffer 中保存完整内容并在重新连接时一次性返回：无法处理仍在生成中的情况

## R-005: 取消信号的双重传播

**Decision**: 保留现有 Redis Pub/Sub 取消机制，同时在 `_GenerationJob` 上设置 `cancel` Event。`cancel_chat` 同时更新数据库状态和发布 Redis 信号，后台任务的 Redis listener 收到信号后设置 `cancel` Event，后台任务在事件循环中检测到 cancel 后中断 LLM Gateway 连接。

**Rationale**:
- Redis Pub/Sub 支持跨 Worker 取消（多实例部署场景）
- `cancel` Event 在单进程内提供更快速的信号传递
- 已连接的 SSE 客户端可以实时收到 `cancelled` 事件，断开的客户端则通过数据库状态判断

**Alternatives considered**:
- 仅使用 Redis Pub/Sub：跨 Worker 必需但延迟较高，结合内存 Event 更优
- 仅使用内存 Event：不支持多 Worker 场景

## R-006: 前端取消按钮与 SSE 流控制

**Decision**: 前端使用 `AbortController` 管理 SSE 流。点击"取消"按钮时：(1) 调用 `POST /chats/{chat_id}/cancel` 触发后端取消流程，(2) 使用 `AbortController.abort()` 断开 fetch 连接。前端 chatStore 新增 `cancelGeneration` action 和 `isCancelling` 状态。

**Rationale**:
- `AbortController` 是 Fetch API 标准的请求取消机制，浏览器原生支持
- 先调用 cancel API 再断开连接，确保后端状态正确转换（cancelled 状态已写入数据库）
- `isCancelling` 状态防止用户重复点击取消按钮

**Alternatives considered**:
- 仅断开 SSE 连接而不发送 cancel API：后端无法区分"取消"和"页面离开"
- 仅发送 cancel API 而不断开 SSE：前端会继续收到 cancelled 事件，体验略差但可行

## R-007: LLM Gateway 客户端断开检测

**Decision**: LLM Gateway 无需修改。现有的 `StreamingResponse` + `aclosing(adapter.stream())` 机制已支持：当 KnowledgeManage 断开 HTTP 连接时，FastAPI 的 async generator 自动检测到连接关闭，`aclosing` 上下文管理器关闭上游供应商的流连接。

**Rationale**:
- 这是已有的架构决策（参见 memory: "LLM Gateway流式响应取消机制：通过HTTP断开传播"）
- FastAPI StreamingResponse 在客户端断开时取消 async generator，触发 `aclosing` 的 `__aexit__`
- `httpx.AsyncClient.stream` 的 context manager 在退出时关闭与供应商的连接

**Alternatives considered**: 无需替代方案，现有机制已满足需求。

## R-008: 服务优雅关闭

**Decision**: 实现 `finish_generations()` 函数，在 KnowledgeManage 服务关闭时：(1) 对所有活跃的 `_GenerationJob` 设置 cancel 信号，(2) 等待所有后台任务完成（带超时），(3) 确保已接收的内容被持久化到数据库。

**Rationale**:
- 防止服务关闭时丢失正在生成的内容
- 测试 `test_chat_background.py` 的 `asyncTearDown` 已使用 `finish_generations()`

**Alternatives considered**:
- 直接取消所有任务：可能导致内容丢失
- 不处理优雅关闭：依赖数据库最后保存的状态，用户体验差
