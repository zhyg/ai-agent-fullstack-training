# Research: 知识库管理页面重组

**Date**: 2026-11-16

## R-001: 侧边栏实现方案

**Decision**: 在 `AppLayout.vue` 中使用 `a-layout-sider` 组件实现条件性侧边栏，仅当用户处于知识库平台区域路由（`/chat`、`/knowledge`、`/agent`）时渲染。

**Rationale**: 参考 `MyKnowlegeWebDemo/src/components/layout/AppLayout.vue` 第 79-105 行的实现，该方案已被验证可行。使用 `v-if="showKnowledgeSidebar"` 控制侧边栏的条件渲染，通过 `computed` 属性根据当前路由路径判断是否显示。侧边栏使用 Ant Design Vue 的 `a-layout-sider` 组件，支持 `collapsible`、`breakpoint`、`width` 等属性。

**Alternatives considered**:
- 创建独立的 `KnowledgeLayout.vue` 布局组件 → 拒绝：增加组件层级复杂度，且当前 AppLayout 已足够承载
- 将侧边栏提取为独立 `KnowledgeSidebar.vue` 组件 → 拒绝：当前改动范围小，提取组件增加文件数量但收益不大

## R-002: 路由结构设计

**Decision**: 在现有根路由 `/` 的 `children` 中新增 `/knowledge` 和 `/agent` 两条路由，与 `/chat` 路由平级。

```
/ → AppLayout
├── /chat       → ChatManagement.vue（新会话）
├── /knowledge  → KnowledgeManagement.vue（知识库）
├── /agent      → AgentManagement.vue（智能体）
├── /prompts    → PromptManagement.vue
├── /models     → ModelManagement.vue
├── /api-keys   → ApiKeyManagement.vue
└── /permissions → PermissionManagement.vue
```

**Rationale**: 保持与现有路由结构一致，三个知识库子页面作为根路由的子路由，共享 AppLayout 布局。路由路径使用简洁的英文命名（`/knowledge`、`/agent`），遵循现有约定（`/chat`、`/models`、`/prompts`）。

**Alternatives considered**:
- 使用嵌套路由 `/knowledge-base/chat`、`/knowledge-base/knowledge`、`/knowledge-base/agent` → 拒绝：路径过深，且现有 `/chat` 路径已在使用中，改动影响范围大
- 使用 `/kb/*` 前缀统一命名空间 → 拒绝：过度设计，当前仅三个页面

## R-003: 顶部菜单"知识库管理"的跳转目标

**Decision**: 点击顶部"AI→知识库管理"时跳转到 `/chat`（即"新会话"页面），作为知识库平台的默认入口。

**Rationale**: 与现有行为一致——用户点击"会话管理"时进入 `/chat`。重命名后保持相同的路由目标，降低变更风险，且"新会话"是用户最常访问的子页面。

**Alternatives considered**:
- 跳转到 `/knowledge`（知识库管理页面） → 拒绝：该页面目前仅为占位，无法提供实际功能
- 记忆上次访问的子页面 → 拒绝：增加实现复杂度，当前阶段无必要

## R-004: 侧边栏导航状态管理

**Decision**: 使用 `computed` 属性基于 `route.path` 计算 `selectedKeys`，无需引入额外的 Pinia store 或状态管理。

**Rationale**: 导航状态完全可从路由推导，无需持久化。参考 MyKnowlegeWebDemo 中的 `routeToKey` 映射和 `selectedKeys` 计算属性实现。

**Alternatives considered**:
- 新增 Pinia store 管理导航状态 → 拒绝：过度设计，路由已包含所需全部信息
