# Tasks: 开发者门户平台

**Input**: Design documents from `/specs/001-developer-portal/`

**Prerequisites**: plan.md ✓, spec.md ✓, research.md ✓, data-model.md ✓, contracts/ ✓

**Tests**: Not explicitly requested — test tasks omitted per task generation rules.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup (项目初始化)

**Purpose**: 创建前端和 3 个后端微服务的目录结构、依赖配置和基础文件

- [x] T001 [P] Create frontend project directory structure with `package.json`, `vite.config.js`, `index.html`, `.env.development`, `.env.test`, `.env.production` in `frontend/`
- [x] T002 [P] Create UserManage service directory structure with `requirements.txt` (FastAPI, SQLAlchemy, passlib[bcrypt], PyJWT, Pydantic V2, pyyaml, cryptography, alembic, psycopg2-binary, email-validator), `Dockerfile` in `UserManage/`
- [x] T003 [P] Create KnowledgeManage service directory structure with `requirements.txt` (FastAPI, SQLAlchemy, Pydantic V2, pyyaml, alembic, psycopg2-binary, httpx), `Dockerfile` in `KnowledgeManage/`
- [x] T004 [P] Create LlmGateway service directory structure with `requirements.txt` (FastAPI, SQLAlchemy, Pydantic V2, pyyaml, cryptography, alembic, psycopg2-binary, httpx), `Dockerfile` in `LlmGateway/`
- [x] T005 [P] Create YAML config files (`config.dev.yaml`, `config.test.yaml`, `config.prod.yaml`) per research.md R-012 spec in `UserManage/`, `KnowledgeManage/`, `LlmGateway/`

---

## Phase 2: Foundational (阻塞性基础设施)

**Purpose**: 所有微服务共享的基础设施——数据库连接、配置加载、JWT 认证工具、API Key 加密、依赖注入框架

**⚠️ CRITICAL**: 此阶段完成前，任何用户故事均不可开始

- [x] T006 [P] Implement database connection module with PostgreSQL Schema isolation (`create_engine`, `init_schema()`, `get_db` session generator) in `UserManage/app/core/database.py`, `KnowledgeManage/app/core/database.py`, `LlmGateway/app/core/database.py`
- [x] T007 [P] Implement YAML config loader with `APP_ENV` environment variable support (Settings Pydantic model + `load_settings()`) in `UserManage/app/core/config.py`, `KnowledgeManage/app/core/config.py`, `LlmGateway/app/core/config.py`
- [x] T008 [P] Implement JWT token utilities (sign/verify access token + refresh token, shared JWT secret across services) in `UserManage/app/core/security.py`, `KnowledgeManage/app/core/security.py`, `LlmGateway/app/core/security.py`
- [x] T009 [P] Implement API Key Fernet encryption/decryption utility in `LlmGateway/app/core/encryption.py`
- [x] T010 [P] Implement `get_current_user` dependency injection (JWT token extraction + user info parsing from token payload) in `UserManage/app/dependencies.py`, `KnowledgeManage/app/dependencies.py`, `LlmGateway/app/dependencies.py`
- [x] T011 [P] Initialize Alembic migration framework (`alembic init`, `env.py` configured with app models and schema support) in `UserManage/alembic/`, `KnowledgeManage/alembic/`, `LlmGateway/alembic/`
- [x] T012 Create PostgreSQL schemas (`user_manage`, `knowledge_manage`, `llm_gateway`) and run initial migrations to verify database connectivity in all three services

**Checkpoint**: 基础框架就绪，可以开始用户故事实现

---

## Phase 3: User Story 1 - 用户认证与账户管理 (Priority: P1) 🎯 MVP

**Goal**: 用户可以完成注册→登录→退出的完整流程，包含登录失败锁定保护

**Independent Test**: 独立验证注册账户、登录系统、退出登录、连续 5 次错误密码后锁定 15 分钟的完整流程

### Backend - UserManage 服务

- [x] T013 [US1] Create User SQLAlchemy model (`users` table: id VARCHAR(36) PK, uid VARCHAR(50) UNIQUE NOT NULL, email VARCHAR(100) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL, role_ids JSON NOT NULL DEFAULT '[]', login_fail_count INTEGER NOT NULL DEFAULT 0, locked_until TIMESTAMP NULLABLE, is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMP, updated_at TIMESTAMP; indexes: "[REDACTED]"
- [x] T014 [US1] Create Role SQLAlchemy model (`roles` table: id VARCHAR(36) PK, name VARCHAR(50) UNIQUE NOT NULL, description VARCHAR(200) DEFAULT '', created_at TIMESTAMP, updated_at TIMESTAMP) in `UserManage/app/models/role.py`
- [x] T015 [US1] Create User and Role Pydantic schemas (RegisterRequest: uid 3-20 chars required, email EmailStr required, password min 6 required; LoginRequest: uid+password required; TokenResponse: access_token+refresh_token+token_type; UserCreateRequest: +role_ids optional list; UserUpdateRequest: all optional uid 3-20/email/password min 6/role_ids; UserResponse: "[REDACTED]"
- [x] T016 [US1] Implement user registration logic (bcrypt password hashing via passlib, check uid/email uniqueness, assign default 'user' role, return 201 with UserResponse) in `UserManage/app/services/user_service.py`
- [x] T017 [US1] Implement login authentication (verify password, generate JWT access token 30min + refresh token 7days, return LoginResponse with user info and permissions list) in `UserManage/app/services/auth_service.py`
- [x] T018 [US1] Implement login lockout logic (increment login_fail_count on failure, set locked_until = now + 15min when count >= 5, check locked status before auth attempt, reset count on success, return 423 when locked) in `UserManage/app/services/auth_service.py`
- [x] T019 [US1] Implement logout and token refresh endpoints in `UserManage/app/services/auth_service.py`
- [x] T020 [US1] Create auth router (`POST /auth/register`, `POST /auth/login`, `POST /auth/logout`, `POST /auth/refresh`, `GET /auth/me`) per user-manage-api.md contract in `UserManage/app/routers/auth.py`
- [x] T021 [US1] Create FastAPI app entry point with CORS middleware, router registration, startup schema init, and seed admin user + default roles (admin/user) in `UserManage/app/main.py`
- [x] T022 [US1] Generate Alembic migration for User and Role models, verify `alembic upgrade head` creates tables in `user_manage` schema in `UserManage/alembic/versions/`

### Frontend - 认证页面与布局

- [x] T023 [P] [US1] Create user API service layer (register, login, logout, refresh, getMe methods with JWT token handling) in `frontend/src/services/userApi.js`
- [x] T024 [P] [US1] Create user Pinia store (auth state, token persistence in localStorage, login/logout/register actions, isAuthenticated getter, currentUser) in `frontend/src/stores/user.js`
- [x] T025 [US1] Create Login.vue page (a-form with uid + password fields, submit calls login action, error message display, redirect to main page on success) per `MyKnowlegeWebDemo/src/views/Login.vue` reference in `frontend/src/views/Login.vue`
- [x] T026 [US1] Create Register.vue page (a-form with uid + email + password + confirm password fields, client-side validation, submit calls register action, redirect to login on success) per `MyKnowlegeWebDemo/src/views/Register.vue` reference in `frontend/src/views/Register.vue`
- [x] T027 [US1] Create AppLayout.vue with a-layout (a-sider with a-menu navigation, a-header with user info + logout button, a-content router-view slot) per `MyKnowlegeWebDemo/src/components/layout/AppLayout.vue` reference in `frontend/src/components/layout/AppLayout.vue`
- [x] T028 [US1] Create Vue Router configuration (routes: /login, /register, / with AppLayout guard requiring auth, navigation guard redirecting to /login when not authenticated) in `frontend/src/router/index.js`
- [x] T029 [US1] Create main.js entry point (createApp, install Pinia, install Router, install Ant Design Vue, mount App) and App.vue root component in `frontend/src/main.js`, `frontend/src/App.vue`

**Checkpoint**: 用户认证流程完整可用，可独立验证注册→登录→退出→锁定

---

## Phase 4: User Story 2 - 提示词管理 (Priority: P2)

**Goal**: 用户可以创建、查看、编辑和删除提示词；普通用户仅看自己的，管理员可看所有但只能编辑/删除自己的

**Independent Test**: 独立验证提示词 CRUD 操作、普通用户/管理员不同视角的访问控制

### Backend - KnowledgeManage 服务

- [x] T030 [US2] Create Prompt SQLAlchemy model (`prompts` table: id VARCHAR(36) PK, name VARCHAR(100) NOT NULL, version VARCHAR(20) NOT NULL, description TEXT DEFAULT '', content TEXT NOT NULL, creator_id VARCHAR(36) NOT NULL, created_at TIMESTAMP, updated_at TIMESTAMP; index: idx_prompts_creator) in `KnowledgeManage/app/models/prompt.py`
- [x] T031 [US2] Create Prompt Pydantic schemas (PromptCreate: name min 1 max 100 required, version min 1 max 20 required, description default '', content min 1 required; PromptUpdate: description optional, content min 1 required — name/version NOT included; PromptResponse: id+name+version+description+content+creator_id+creator_name optional+created_at+updated_at) in `KnowledgeManage/app/schemas/prompt.py`
- [x] T032 [US2] Implement prompt CRUD service (create with auto creator_id from current user, list with access control: regular user filters by creator_id, admin returns all with creator_name; update only when creator_id matches current user; delete: regular user own records only, admin can delete any) in `KnowledgeManage/app/services/prompt_service.py`
- [x] T033 [US2] Create prompt router (`GET /prompts`, `POST /prompts`, `PUT /prompts/{prompt_id}`, `DELETE /prompts/{prompt_id}`) per knowledge-manage-api.md contract in `KnowledgeManage/app/routers/prompts.py`
- [x] T034 [US2] Create KnowledgeManage FastAPI app entry point with CORS middleware, JWT auth dependency, router registration, startup schema init in `KnowledgeManage/app/main.py`
- [x] T035 [US2] Generate Alembic migration for Prompt model, verify tables created in `knowledge_manage` schema in `KnowledgeManage/alembic/versions/`

### Frontend - 提示词管理页面

- [x] T036 [P] [US2] Create prompt API service layer (list, create, update, delete methods with auth token) in `frontend/src/services/promptApi.js`
- [x] T037 [P] [US2] Create prompt Pinia store (prompts list, loading state, CRUD actions, admin-aware filtering) in `frontend/src/stores/prompt.js`
- [x] T038 [US2] Create PromptManagement.vue page (prompt list with a-table, "新建提示词" button, per-row "设置" and "删除" buttons, admin view shows creator_name column) per `MyKnowlegeWebDemo/src/views/PromptManagement.vue` reference in `frontend/src/views/PromptManagement.vue`
- [x] T039 [US2] Create PromptCreateModal.vue (a-modal with a-form: name required + version + description + content fields, submit calls create action) per `MyKnowlegeWebDemo/src/components/prompt/PromptCreateModal.vue` reference in `frontend/src/components/prompt/PromptCreateModal.vue`
- [x] T040 [US2] Create PromptFormDrawer.vue (a-drawer with a-form: name and version disabled/readonly, description + content editable, submit calls update action) per `MyKnowlegeWebDemo/src/components/prompt/PromptFormDrawer.vue` reference in `frontend/src/components/prompt/PromptFormDrawer.vue`
- [x] T041 [US2] Create PromptCard.vue component (display prompt summary with name, version, description) per `MyKnowlegeWebDemo/src/components/prompt/PromptCard.vue` reference in `frontend/src/components/prompt/PromptCard.vue`

**Checkpoint**: 提示词管理功能完整可用，普通用户和管理员视角均正确

---

## Phase 5: User Story 3 - 模型管理 LLM Gateway (Priority: P3)

**Goal**: 管理员可以创建、查看、编辑和删除 LLM 模型配置，API Key 加密存储且掩码显示，非管理员禁止访问

**Independent Test**: 独立验证模型 CRUD 操作、API Key 掩码显示、非管理员访问被拒绝

### Backend - LlmGateway 服务

- [x] T042 [US3] Create Model SQLAlchemy model (`models` table: id VARCHAR(36) PK, name VARCHAR(100) NOT NULL, url VARCHAR(500) NOT NULL, api_key_encrypted TEXT NOT NULL, max_tokens INTEGER NOT NULL, rpm INTEGER NOT NULL, tpm INTEGER NOT NULL, input_per_million DECIMAL(10,4) NOT NULL, output_per_million DECIMAL(10,4) NOT NULL, cached_input_per_million DECIMAL(10,4) NOT NULL, created_at TIMESTAMP, updated_at TIMESTAMP) in `LlmGateway/app/models/model.py`
- [x] T043 [US3] Create Model Pydantic schemas (ModelCreate: name 1-100 required, url required, api_key min 1 required, max_tokens ge 1 required, rpm ge 0 required, tpm ge 0 required, input_per_million ge 0 decimal 4 places required, output_per_million ge 0 decimal 4 places required, cached_input_per_million ge 0 decimal 4 places required; ModelUpdate: same as Create except api_key is optional, omitted/null/blank preserves the existing key; ModelResponse: "[REDACTED]"
- [x] T044 [US3] Implement model CRUD service (create with Fernet-encrypted api_key storage, list returning api_key_masked format: "[REDACTED]"
- [x] T045 [US3] Create model router (`GET /models`, `POST /models`, `PUT /models/{model_id}`, `DELETE /models/{model_id}`) with `model_manage` permission check per llm-gateway-api.md contract in `LlmGateway/app/routers/models.py`
- [x] T046 [US3] Create LlmGateway FastAPI app entry point with CORS middleware, JWT auth dependency, model_manage permission guard, router registration, startup schema init in `LlmGateway/app/main.py`
- [x] T047 [US3] Generate Alembic migration for Model model, verify tables created in `llm_gateway` schema in `LlmGateway/alembic/versions/`

### Frontend - 模型管理页面

- [x] T048 [P] [US3] Create model API service layer (list, create, update, delete methods with auth token) in `frontend/src/services/modelApi.js`
- [x] T049 [P] [US3] Create model Pinia store (models list, loading state, CRUD actions) in `frontend/src/stores/model.js`
- [x] T050 [US3] Create ModelManagement.vue page (model list with a-table showing name/url/api_key_masked/max_tokens/rpm/tpm/prices, "新建模型" button, per-row "设置" and "删除" buttons) per `MyKnowlegeWebDemo/src/views/ModelManagement.vue` reference in `frontend/src/views/ModelManagement.vue`
- [x] T051 [US3] Create ModelFormDrawer.vue (a-drawer with a-form: name required + url required + api_key required on create and optional on update + max_tokens + rpm + tpm + input_per_million + output_per_million + cached_input_per_million; blank update key is omitted, masked key is display-only) per `MyKnowlegeWebDemo/src/components/model/ModelFormDrawer.vue` reference in `frontend/src/components/model/ModelFormDrawer.vue`
- [x] T052 [US3] Create ModelCard.vue and ModelList.vue components (card display and list wrapper) per `MyKnowlegeWebDemo/src/components/model/` reference in `frontend/src/components/model/ModelCard.vue`, `frontend/src/components/model/ModelList.vue`

**Checkpoint**: 模型管理功能完整可用，仅管理员可访问

---

## Phase 6: User Story 4 - 会话管理 (Priority: P4)

**Goal**: 用户可以创建、查看和删除会话，在会话中选择模型和提示词与 LLM 进行流式对话

**Independent Test**: 独立验证会话 CRUD、选择模型/提示词、发送消息并接收 SSE 流式 LLM 回复

### Backend - KnowledgeManage 服务 (会话部分)

- [x] T053 [US4] Create Chat SQLAlchemy model (`chats` table: id VARCHAR(36) PK, title VARCHAR(200) NOT NULL, user_id VARCHAR(36) NOT NULL, model_id VARCHAR(36) NULLABLE, prompt_id VARCHAR(36) NULLABLE, created_at TIMESTAMP, updated_at TIMESTAMP; index: idx_chats_user) in `KnowledgeManage/app/models/chat.py`
- [x] T054 [US4] Create Message SQLAlchemy model (`messages` table: id VARCHAR(36) PK, chat_id VARCHAR(36) FK→chats.id NOT NULL, role VARCHAR(20) NOT NULL [user/assistant/system], content TEXT NOT NULL, created_at TIMESTAMP; indexes: idx_messages_chat, idx_messages_chat_created) in `KnowledgeManage/app/models/message.py`
- [x] T055 [US4] Create Chat and Message Pydantic schemas (ChatCreate: title 1-200 required, model_id optional, prompt_id optional; ChatUpdate: title/model_id/prompt_id all optional; ChatResponse: id+title+user_id+model_id+prompt_id+created_at+updated_at; MessageCreate: content min 1 required; MessageResponse: id+role+content+created_at) in `KnowledgeManage/app/schemas/chat.py`
- [x] T056 [US4] Implement chat CRUD service (create with auto user_id, list filtering by current user, update title/model_id/prompt_id, delete cascade messages) in `KnowledgeManage/app/services/chat_service.py`
- [x] T057 [US4] Implement message service (save user message, call LlmGateway POST /chat/completions with model_id + message history, stream SSE response, save assistant message after completion) in `KnowledgeManage/app/services/chat_service.py`
- [x] T058 [US4] Create chat router (`GET /chats`, `POST /chats`, `PUT /chats/{chat_id}`, `DELETE /chats/{chat_id}`, `GET /chats/{chat_id}/messages`, `POST /chats/{chat_id}/messages` SSE streaming) per knowledge-manage-api.md contract in `KnowledgeManage/app/routers/chats.py`
- [x] T059 [US4] Update KnowledgeManage main.py to register chat router and initialize Chat/Message models in `KnowledgeManage/app/main.py`
- [x] T060 [US4] Generate Alembic migration for Chat and Message models in `KnowledgeManage/alembic/versions/`

### Backend - LlmGateway 服务 (对话代理部分)

- [x] T061 [US4] Implement LLM proxy service (lookup model by model_id, decrypt API Key, call external LLM API at model url, stream response as SSE, handle errors with 502) in `LlmGateway/app/services/llm_proxy.py`
- [x] T062 [US4] Create chat completion router (`POST /chat/completions` accepting model_id + messages list, returning SSE text/event-stream) per llm-gateway-api.md contract in `LlmGateway/app/routers/chat.py`
- [x] T063 [US4] Update LlmGateway main.py to register chat completion router in `LlmGateway/app/main.py`

### Frontend - 会话管理页面

- [x] T064 [P] [US4] Create chat API service layer (list chats, create, update, delete, get messages, send message with SSE stream handling via EventSource/fetch ReadableStream) in `frontend/src/services/chatApi.js`
- [x] T065 [P] [US4] Create chat Pinia store (chats list, current chat, messages, model/prompt selection, CRUD actions, SSE message accumulation) in `frontend/src/stores/chat.js`
- [x] T066 [US4] Create ChatManagement.vue page (left panel: chat history list + "新建会话" button; right panel: chat area with model/prompt selector and message input) per `MyKnowlegeWebDemo/src/views/ChatManagement.vue` reference in `frontend/src/views/ChatManagement.vue`
- [x] T067 [US4] Create ChatList.vue component (sidebar list of historical chats, click to select, delete button per chat) per `MyKnowlegeWebDemo/src/components/chat/ChatList.vue` reference in `frontend/src/components/chat/ChatList.vue`
- [x] T068 [US4] Create ChatArea.vue component (message display area with role-based styling for user/assistant/system messages, auto-scroll, SSE streaming text accumulation) per `MyKnowlegeWebDemo/src/components/chat/ChatArea.vue` reference in `frontend/src/components/chat/ChatArea.vue`
- [x] T069 [US4] Create MessageInput.vue component (text input area + send button, model selector dropdown, prompt selector dropdown) per `MyKnowlegeWebDemo/src/components/chat/MessageInput.vue` reference in `frontend/src/components/chat/MessageInput.vue`

**Checkpoint**: 会话管理功能完整可用，支持模型/提示词选择和 SSE 流式对话

---

## Phase 7: User Story 5 - 权限管理 (Priority: P5)

**Goal**: 管理员可以管理平台用户（增删改）和角色（增删改、权限分配），实现 RBAC 访问控制

**Independent Test**: 独立验证用户管理 CRUD、角色管理 CRUD、权限分配后不同角色的访问控制生效

### Backend - UserManage 服务 (管理接口部分)

- [x] T070 [US5] Implement user management service (admin CRUD: list with pagination, create with role assignment, update user info/roles, delete user — preserve their prompts/chats in KnowledgeManage with creator_id retained) in `UserManage/app/services/user_service.py`
- [x] T071 [US5] Implement role management service (CRUD: list, create with name 1-50 + description max 200, update, delete with check for assigned users — reject if role has users) in `UserManage/app/services/role_service.py`
- [x] T072 [US5] Create permissions constants (predefined permission list: prompt_manage "提示词管理", chat_manage "会话管理", model_manage "模型管理", permission_manage "权限管理") and role-permission mapping logic in `UserManage/app/core/permissions.py`
- [x] T073 [US5] Create user management router (`GET /users`, `POST /users`, `PUT /users/{user_id}`, `DELETE /users/{user_id}`) with `permission_manage` permission guard per user-manage-api.md contract in `UserManage/app/routers/users.py`
- [x] T074 [US5] Create role management router (`GET /roles`, `POST /roles`, `PUT /roles/{role_id}`, `DELETE /roles/{role_id}`) with `permission_manage` permission guard per user-manage-api.md contract in `UserManage/app/routers/roles.py`
- [x] T075 [US5] Create permissions router (`GET /permissions` returning predefined permission items list) in `UserManage/app/routers/permissions.py`
- [x] T076 [US5] Update UserManage main.py to register users, roles, and permissions routers in `UserManage/app/main.py`

### Frontend - 权限管理页面

- [x] T077 [P] [US5] Create permission API service layer (users CRUD, roles CRUD, get permissions list methods) in `frontend/src/services/permissionApi.js`
- [x] T078 [P] [US5] Create permission Pinia store (users list, roles list, permissions list, CRUD actions for both users and roles) in `frontend/src/stores/permission.js`
- [x] T079 [US5] Create PermissionManagement.vue page (a-tabs with "用户管理" and "角色管理" tabs) per `MyKnowlegeWebDemo/src/views/PermissionManagement.vue` reference in `frontend/src/views/PermissionManagement.vue`
- [x] T080 [US5] Create UserTable.vue component (a-table with user list, add/edit/delete actions, role assignment column) in `frontend/src/components/permission/UserTable.vue`
- [x] T081 [US5] Create RoleTable.vue component (a-table with role list, add/edit/delete actions, permission display) in `frontend/src/components/permission/RoleTable.vue`
- [x] T082 [US5] Create RoleFormModal.vue component (a-modal with a-form: role name + description fields, a-checkbox-group for predefined permissions selection) in `frontend/src/components/permission/RoleFormModal.vue`

**Checkpoint**: 权限管理功能完整可用，RBAC 访问控制生效

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: 跨功能模块的统一优化和完善

- [x] T083 [P] Add global error handling and user-friendly error messages (network errors, API errors, auth expiration) across all frontend views in `frontend/src/utils/errorHandler.js`
- [x] T084 [P] Add loading states to all API-calling components (spinners during requests, disabled buttons during submission) in relevant `frontend/src/views/` and `frontend/src/components/` files
- [x] T085 [P] Add delete confirmation dialogs (a-modal confirm) to all delete operations (prompts, models, chats, users, roles) per FR-011 in relevant components
- [x] T086 Add frontend route guards for role-based access control (redirect non-admin users from model management and permission management pages) in `frontend/src/router/index.js`
- [x] T087 Verify end-to-end scenarios per quickstart.md (all 7 scenarios: register→login→logout, prompt CRUD as user, prompt as admin, model as admin, chat with SSE, permission management, login lockout)
- [x] T088 UI polish and styling consistency per MyKnowlegeWebDemo visual references across all pages

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup (Phase 1) — **BLOCKS all user stories**
- **US1 Auth (Phase 3)**: Depends on Foundational (Phase 2) — backend and frontend can partially overlap
- **US2 Prompts (Phase 4)**: Depends on Foundational (Phase 2) + US1 frontend auth (for JWT token)
- **US3 Models (Phase 5)**: Depends on Foundational (Phase 2) + US1 frontend auth
- **US4 Chats (Phase 6)**: Depends on US2 (prompt selection) + US3 (model selection) for full functionality
- **US5 Permissions (Phase 7)**: Depends on US1 backend (UserManage service exists)
- **Polish (Phase 8)**: Depends on all desired user stories being complete

### User Story Dependencies

- **US1 (P1)**: Can start after Phase 2 — No dependencies on other stories
- **US2 (P2)**: Can start after Phase 2 + US1 frontend auth — Needs JWT token for API calls
- **US3 (P3)**: Can start after Phase 2 + US1 frontend auth — Needs JWT token + admin role check
- **US4 (P4)**: Depends on US2 (prompt data) + US3 (model data) for selection in chats
- **US5 (P5)**: Can start after US1 backend is complete — Shares UserManage service

### Within Each User Story

- Backend models → schemas → services → routers (sequential)
- Frontend API services + stores can be built [P] in parallel with backend
- Frontend views depend on stores being ready
- Story complete before moving to next priority (unless parallel team)

### Parallel Opportunities

- Phase 1: T001-T005 all parallel (different repos)
- Phase 2: T006-T011 all parallel (different files)
- Within US1: T013-T014 parallel (different model files), T023-T024 parallel (API + store)
- Within US2: T036-T037 parallel (API + store)
- Within US3: T048-T049 parallel (API + store)
- Within US4: T064-T065 parallel (API + store)
- Within US5: T077-T078 parallel (API + store)
- Phase 8: T083-T085 parallel (cross-cutting)

---

## Parallel Example: Phase 1 Setup

```text
# All 5 setup tasks can run simultaneously:
Task T001: "Create frontend project structure in frontend/"
Task T002: "Create UserManage service structure in UserManage/"
Task T003: "Create KnowledgeManage service structure in KnowledgeManage/"
Task T004: "Create LlmGateway service structure in LlmGateway/"
Task T005: "Create YAML config files in all three services"
```

## Parallel Example: User Story 1 Backend

```text
# Models can be created in parallel:
Task T013: "Create User model in UserManage/app/models/user.py"
Task T014: "Create Role model in UserManage/app/models/role.py"

# Frontend API and store can be built in parallel:
Task T023: "Create user API service in frontend/src/services/userApi.js"
Task T024: "Create user Pinia store in frontend/src/stores/user.js"
```

## Parallel Example: User Story 2 Backend

```text
# Frontend API service and store in parallel:
Task T036: "Create prompt API service in frontend/src/services/promptApi.js"
Task T037: "Create prompt Pinia store in frontend/src/stores/prompt.js"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1 (Auth)
4. **STOP and VALIDATE**: Test register → login → logout → lockout independently
5. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add US1 (Auth) → Test independently → Deploy/Demo (MVP!)
3. Add US2 (Prompts) → Test independently → Deploy/Demo
4. Add US3 (Models) → Test independently → Deploy/Demo
5. Add US4 (Chats) → Test independently → Deploy/Demo
6. Add US5 (Permissions) → Test independently → Deploy/Demo
7. Each story adds value without breaking previous stories

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Once Foundational is done:
   - Developer A: US1 (Auth) → US4 (Chats, after US2+US3)
   - Developer B: US2 (Prompts) → US5 (Permissions)
   - Developer C: US3 (Models)
3. Stories complete and integrate independently

---

## Notes

- [P] tasks = different files/repos, no dependencies on incomplete tasks
- [Story] label maps task to specific user story for traceability
- Each user story is independently completable and testable
- All backend services use Pydantic V2 for request/response validation (research.md R-011)
- All update/delete operations use ID path parameters (research.md R-014)
- Multi-environment config via YAML (backend) and .env files (frontend) (research.md R-012, R-013)
- JWT shared secret enables cross-service authentication (research.md R-006)
- API Key Fernet encryption for LLM model keys (research.md R-008)
- Commit after each task or logical group
