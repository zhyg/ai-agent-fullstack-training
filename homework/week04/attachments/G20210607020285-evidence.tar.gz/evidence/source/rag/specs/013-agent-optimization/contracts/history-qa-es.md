# Contract: 历史问答 ES 存储与检索（history-qa-es）

**Feature**: 013-agent-optimization | **依据**: research.md R1–R7、R10；data-model.md §1

本契约约束新增模块 `KnowledgeManage/app/services/history_qa_service.py` 与 `es_client.ensure_history_index` 对外行为。调用方：`agent_runtime.run_agent_generation`（检索）、`chat_service._run_agent_generation`（写入）。

## 1. 索引契约

- **命名**: `chat_history_qa_{dims}`，dims 为向量实际维度（如 `chat_history_qa_1024`）。
- **创建**: `ensure_history_index(dims: int) -> str`，不存在则建，存在即返回（对齐 `ensure_index` 模式）；建索引失败上抛异常由调用方按各自降级策略处理。
- **mapping**:

```json
{
  "mappings": {
    "properties": {
      "chat_id":            { "type": "keyword" },
      "user_id":            { "type": "keyword" },
      "question":           { "type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart" },
      "answer":             { "type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart" },
      "qa_text":            { "type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart" },
      "created_at":         { "type": "date" },
      "embedding_model":    { "type": "keyword" },
      "embedding_model_id": { "type": "keyword" },
      "embeddings":         { "type": "dense_vector", "dims": "<dims>" }
    }
  }
}
```

- **前置依赖**: ES 安装 analysis-ik 插件（开发环境 8.17.0 已确认）；未装时建索引失败→写入失败仅记日志、检索异常→降级，主流程不受影响。

## 2. 写入契约

```python
async def index_qa_round(
    *, chat_id: str, user_id: str, question: str, answer: str,
    message_id: str, embedding_model_id: str, trace_id: str,
) -> None
```

| 项 | 约定 |
|---|---|
| 触发 | `_finalize_agent_generation` 返回 finalized=True 且非 cancelled、无 error_event、content 非空后，`asyncio.create_task`  fire-and-forget |
| 向量化 | `embedding_service.generate_embeddings([question + "\n" + answer], embedding_model_id)`，复用智能体向量模型（FR-014） |
| 索引选择 | `ensure_history_index(len(vector))` |
| 文档 `_id` | message_id（assistant 消息 id），index API 覆盖写，幂等 |
| 字段 | data-model.md §1 全字段；`embedding_model` 取 `embedding_service.resolve_model_name(embedding_model_id)`；created_at 为写入时刻 UTC |
| refresh | 默认（不用 wait_for） |
| 失败 | 捕获一切异常：`logger.warning` + 独立 span `agent.history_index` 记 `history_index_failed` 事件；**不重试、不上抛**（FR-013） |
| 成功 | span `agent.history_index` 记 agent.output={index, doc_id}；span 属性带 chat.id / session.id / origin.trace_id |
| 排除 | 取消/报错/停止轮次调用方不触发（FR-013）；clarify_failed / empty_retrieval 的 done 轮次正常写入（R6） |

## 3. 检索与组装契约

```python
async def retrieve_and_assemble(state: RequestRuntimeState, emit) -> None
    # 就地写 state.clarify_history；发 StepEvent；建 span agent.history_retrieve
```

| 项 | 约定 |
|---|---|
| 执行时机 | `run_agent_generation` 内 state 构建后、flow 分发前；**每请求恰好一次**（FR-009） |
| query | `state.question`（用户原问题，非重写后问题） |
| 过滤 | `term: chat_id = state.chat_id`（两路均带） |
| topk | `state.snapshot.history_top_k`（1–100，默认 10） |
| 混合口径 | BM25（match on qa_text）+ 向量（script_score cosineSimilarity+1.0，query 向量对 qa_text 向量）→ Python RRF（k=settings.agent_runtime.rrf_k=60）→ 截断 topk；与 retrieval_service 口径一致（R3） |
| 索引选择 | query 向量维度决定索引；`ignore_unavailable=True`（索引不存在=零命中） |
| 超时 | `asyncio.wait_for(..., settings.agent_runtime.history_retrieve_timeout)` 默认 3s，覆盖向量化+ES+RRF 全程（R10） |
| 组装 | 最近 2 个完整问答轮原文（入口 history 剔除当前问题后取尾部成对轮次）+ ES 命中轮次；去重键=question 原文；剔除当前问题；ES 命中 created_at 升序在前、保底 2 轮在后（FR-008） |
| 预算 | 组装后按 clarify/rewrite 提示词固定开销裁剪，头部逐轮淘汰（R11）；后续 enforce_budget 同步兼顾 |
| 降级 | 超时/ES 异常/embedding 失败/零命中/任何异常 → `state.clarify_history=None`（下游自动回退最近 10 轮），span 记 `history_retrieve_degraded`（reason=timeout/unavailable/embedding_failed/empty_result/error），**流程继续**（FR-010） |
| 事件 | StepEvent step=`history_retrieve` start/end（降级时 end 事件 message 提示"历史检索降级，使用最近历史"）；span agent.input={query, chat_id, top_k}、agent.output={count, round_ids, degraded} |
| 分数阈值 | 无（R4） |

## 4. 消费方契约（steps/工具）

- `steps.clarify_history_text(state)`：`clarify_history` 非 None → 渲染组装历史；None → 渲染 `state.history`（现有最近 10 轮）。
- 使用方：`run_clarify`、`run_rewrite`（含推理行动循环各轮）、`knowledge_tools._rewrite_question`。
- **禁止**使用方：`stream_answer`、`planning_reasoning._init_messages`（恒用 `history_text(state)`，FR-009）。

## 5. 验收映射

| 契约点 | spec |
|---|---|
| 每轮一文档、字段齐全、拼接向量化 | FR-012、SC-005 |
| 异步写、失败不影响主流程、不完整轮次不写 | FR-013、SC-005 |
| chat_id 过滤、topk 配置、混合口径 | FR-007、FR-014 |
| 2 轮保底+去重+时间序+剔除当前问题 | FR-008 |
| 仅澄清/重写替换、每请求一次 | FR-009 |
| 3s 超时/异常/零命中降级 | FR-010、SC-002 |
| 预算核算 | FR-011 |