# Implementation Plan: 智能体运行优化（Trace 增强 / 会话历史检索 / 规划推理工具调用）

**Branch**: `013-agent-optimization` | **Date**: 2026-11-24 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/013-agent-optimization/spec.md`（源需求：`mySpecs/014.agent优化.md`，12 项已澄清决策 + 4 项补充澄清）

## Summary

对三类智能体（快速问答/推理行动/规划推理）做三项增强：

1. **Trace 增强**：所有渲染提示词的 span（clarify/rewrite/compress/sufficiency/answer/plan_decision，含工具内 rewrite/zip）增加 `prompt.name/version/purpose` 属性（取自 PromptSnapshot）；`agent.retrieve.*` span 增加 `retrieval.chunks` 属性（JSON 数组 `[{chunk_id, score, file_name, content}]`，全文不截断，绕过现有 32KB 截断工具函数）；前端 SpanDetail 按现有折叠面板方式呈现。
2. **会话历史检索**：新增 ES 历史问答存储（每完整轮次一文档，问题+答案拼接向量化，复用智能体 embedding 模型）；问答终态落库后 asyncio 后台任务异步写入；统一入口 `run_agent_generation` 在分发 flow 前执行一次 `history_retrieve` 步骤（3 秒超时），以"最近 2 个完整问答轮原文 + ES 混合检索命中轮次"组装澄清/重写专用历史（按轮去重、时间序），异常/零命中降级回退现有最近 10 轮；配置页新增"历史信息检索"菜单（仅检索召回数，默认 10，1–100）。
3. **规划推理工具调用修复**：强化 PLANNING_PROTOCOL 强制 function calling、禁止 content 输出计划文本；收敛判定不变；无 tool_calls 且 content 含计划标记时记 `plan_text_not_tool_call` 警告事件。

技术路径：全部在 KnowledgeManage 后端 + frontend 前端现有模块内增量修改，新增 1 个服务模块 `history_qa_service.py`，无 PG 迁移、无新外部依赖（ES 8.17.0 已装 analysis-ik 插件，已实测确认）。

## Technical Context

**Language/Version**: Python 3.11（后端 KnowledgeManage）；JavaScript / Vue 3（frontend，Ant Design Vue）

**Primary Dependencies**: FastAPI、LangGraph（流程编排）、Pydantic v2、elasticsearch-py（AsyncElasticsearch）、httpx（LlmGateway 调用）、OpenTelemetry SDK（OTLP gRPC）、tiktoken（预算计数）；前端 Vue 3 + Ant Design Vue + Pinia

**Storage**: PostgreSQL（chats/messages/agents，既有，无 schema 变更——config 为 JSON 列）；Elasticsearch 8.17.0（新增历史问答索引 `chat_history_qa_{dims}`，analysis-ik 8.17.0 插件已安装）；Redis（取消信号，既有）

**Testing**: pytest（KnowledgeManage/tests，现有 223+ 用例；tracing.enabled=false 走 NoOp Tracer，ES/网关均 mock）；前端 `npm run build` 验证

**Target Platform**: macOS/Linux 服务器（Docker 部署），浏览器前端

**Project Type**: Web 应用（多服务单仓库：KnowledgeManage 后端 + frontend 前端）

**Performance Goals**: 历史检索（含 query 向量化 + ES 两路召回 + RRF）端到端 ≤3 秒，超时即降级（SC-002：异常时用户额外等待不超过 3 秒）；ES 写入异步执行，0 阻塞主流程

**Constraints**: 历史检索/写入失败不得中断问答主流程（FR-010/013）；`retrieval.chunks` 属性全文不截断（决策11，需绕过 `to_json_attr` 的 32KB 截断）；收敛判定逻辑不变（FR-016）；答案生成与 planning system 历史机制不变（FR-009）；存量智能体/存量会话零迁移（FR-005/014）

**Scale/Scope**: 3 类智能体流程、约 10 个后端文件修改 + 1 个新服务模块、约 6 个前端文件修改 + 1 个新配置区块组件；单会话历史检索按 chat_id 过滤，召回 1–100

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

`.specify/memory/constitution.md` 为未填写的模板（全部为 `[PRINCIPLE_*]` 占位符，无已批准原则），**无可执行门禁**。以项目既有工程惯例作为事实约束替代：

- 复用优先：混合检索口径、embedding 调用、trace 采集、配置校验/预检均复用现有实现 ✅（本计划不引入新检索引擎/新模型配置）
- 主流程健壮性：新增外部依赖（历史 ES）全部带降级/异步隔离 ✅（FR-010/013 设计内置）
- 前后端常量同步：`schemas/agent.py` ↔ `utils/agent.js` 注释明确约定同步修改 ✅（新增 history_retrieval 配置两侧同步）
- 可观测性：新步骤/降级/警告均记 trace 事件 ✅

**Gate 结论**: PASS（无宪法违规；Complexity Tracking 留空）。Phase 1 设计后复查：PASS（无新增跨服务接口、无 PG 迁移、无新依赖）。

## Project Structure

### Documentation (this feature)

```text
specs/013-agent-optimization/
├── spec.md              # 特性规格（已完成，含 4 项补充澄清）
├── plan.md              # 本文件
├── research.md          # Phase 0 输出（15 项技术决策）
├── data-model.md        # Phase 1 输出
├── quickstart.md        # Phase 1 输出
├── contracts/
│   ├── history-qa-es.md         # ES 历史问答索引/文档契约
│   └── agent-optimization-api.md # 配置 API / SSE 事件 / trace 属性契约
├── checklists/          # 既有
└── tasks.md             # Phase 2 输出（/speckit-tasks 生成，非本命令产物）
```

### Source Code (repository root)

```text
KnowledgeManage/
├── app/
│   ├── core/
│   │   ├── config.py                      # [改] AgentRuntimeConfig 增 history_retrieve_timeout: 3
│   │   └── es_client.py                   # [改] 增 ensure_history_index(dims)（ik 分词 mapping）
│   ├── schemas/
│   │   ├── agent.py                       # [改] AgentConfig 增 history_retrieval.top_k（默认10，1–100）
│   │   └── agent_runtime.py               # [改] StepName Literal 增 "history_retrieve"
│   ├── services/
│   │   ├── history_qa_service.py          # [新] 历史问答 ES 写入/混合检索/历史组装/降级
│   │   ├── chat_service.py                # [改] finalize 成功后 create_task 异步写入 ES
│   │   ├── agent_service.py               # [改] 保存校验/裁剪 history_retrieval（三类均保留）
│   │   └── agent_runtime/
│   │       ├── __init__.py                # [改] 入口执行 history_retrieve 步骤；结果带 embedding_model_id
│   │       ├── state.py                   # [改] 快照增 history_top_k；state 增 clarify_history
│   │       ├── snapshot.py                # [改] 冻结 history_top_k（缺省 10）
│   │       ├── steps.py                   # [改] prompt 溯源属性；clarify/rewrite 用组装历史
│   │       ├── tracing.py                 # [改] prompt.*/retrieval.chunks 常量与不截断写入助手
│   │       ├── budget.py                  # [改] enforce_budget 兼顾 clarify_history 淘汰
│   │       ├── flows/
│   │       │   ├── quick_qa.py            # [改] retrieve span 增 retrieval.chunks
│   │       │   ├── reasoning_action.py    # [改] 同上
│   │       │   └── planning_reasoning.py  # [改] PLANNING_PROTOCOL 强化 + plan_text_not_tool_call 检测
│   │       └── tools/
│   │           └── knowledge_tools.py     # [改] 工具内 rewrite/zip 溯源属性；检索 span retrieval.chunks；rewrite 用组装历史
│   └── ...（routers/models 无改动）
├── config.dev.yaml / config.prod.yaml / config.test.yaml   # [改] agent_runtime.history_retrieve_timeout: 3
└── tests/
    ├── test_history_qa.py                 # [新] 写入/检索/组装/降级/超时
    ├── test_agent_flows.py                # [改] 历史步骤/组装历史替换范围/预算回归
    ├── test_agents.py                     # [改] history_retrieval 配置校验
    └── test_trace_query.py                # [改] 新属性透传（如需）

frontend/
├── src/
│   ├── utils/agent.js                     # [改] MENU_SECTIONS 增 history；默认配置/校验
│   ├── components/agent/
│   │   ├── AgentEditModal.vue             # [改] 挂载 HistorySection
│   │   └── sections/HistorySection.vue    # [新] 历史信息检索区块（仅检索召回数）
│   ├── components/chat/ChatArea.vue       # [改] STEP_LABELS 增 history_retrieve: '历史信息检索'
│   └── components/trace/SpanDetail.vue    # [改] retrieval.chunks 美化 JSON 折叠面板
└── tests/                                 # 既有构建验证
```

**Structure Decision**: 沿用现有多服务单仓库结构。后端改动集中在 `KnowledgeManage/app/services/agent_runtime/`（步骤/流程/trace）与新增 `app/services/history_qa_service.py`（ES 写入+检索+组装，模式对齐 `retrieval_service.py`/`es_chunk_service.py`）；历史检索步骤放在统一入口 `run_agent_generation`（flow 分发前），不改三个 langgraph 图结构，天然保证"每请求仅执行一次"。前端新增一个配置区块组件并同步常量。无 PG 迁移（agent.config 为 JSON 列，Pydantic 默认值兜底存量）。

## Complexity Tracking

> 无宪法违规，无需填写。