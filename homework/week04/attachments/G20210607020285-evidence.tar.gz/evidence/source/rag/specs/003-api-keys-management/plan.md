# Implementation Plan: API Keys Management

**Branch**: `003-api-keys-management` | **Date**: "[REDACTED]"

**Input**: Feature specification from `/specs/003-api-keys-management/spec.md`

## Summary

在"AI"菜单下新增"API keys"子菜单，实现 API Key 的全生命周期管理（创建、查看、编辑名称、删除）。后端在 UserManage 服务中新增 `api_keys` 数据表和 REST API，前端在现有 Vue 3 项目中新增页面和路由。密钥采用 `sk-` 前缀 + 32位随机字符格式，后端仅存储哈希值和脱敏版本，完整密钥仅在创建时展示一次。

## Technical Context

**Language/Version**: Python 3.11 (后端), JavaScript ES2022+ (前端)

**Primary Dependencies**: FastAPI + SQLAlchemy + Pydantic (后端), Vue 3 + Ant Design Vue 4.x + Pinia (前端)

**Storage**: PostgreSQL（schema: `user_manage`）

**Testing**: pytest (后端), Vitest (前端)

**Target Platform**: Linux server (后端 Docker), SPA (前端 Vite 构建)

**Project Type**: Web service（微服务架构）

**Performance Goals**: 标准 Web 应用响应（页面操作 <1s 反馈）

**Constraints**: 单用户最多 20 个 API Key；密钥生成需密码学安全随机；完整密钥仅展示一次

**Scale/Scope**: 单用户上限 20 Key，分页每页 10 条；1 个新页面 + 4 个 API 端点 + 1 个内部验证端点

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

项目 constitution 为模板状态（未填写具体原则），无约束门禁。设计遵循现有项目惯例：
- 复用 SQLAlchemy ORM + Pydantic 参数校验模式
- 复用 JWT Bearer Token 认证
- 复用 axios 服务层 + Pinia Store 模式
- 遵循 schema 隔离架构

## Project Structure

### Documentation (this feature)

```text
specs/003-api-keys-management/
├── plan.md              # This file
├── spec.md              # Feature specification
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   └── api-keys-contracts.md
├── checklists/
│   └── requirements.md
└── tasks.md             # Phase 2 output (/speckit-tasks)
```

### Source Code (repository root)

```text
UserManage/
├── alembic/versions/
│   └── 002_add_api_keys.py          # 数据库迁移
├── app/
│   ├── models/
│   │   └── api_key.py               # API Key 数据模型
│   ├── schemas/
│   │   └── api_key.py               # Pydantic 请求/响应模型
│   ├── services/
│   │   └── api_key_service.py       # 业务逻辑层
│   ├── routers/
│   │   └── api_keys.py              # REST API 路由
│   ├── core/
│   │   └── security.py              # 新增 hash_api_key / generate_api_key 函数
│   └── main.py                      # 注册新路由
└── requirements.txt                 # 无需新增依赖

frontend/
├── src/
│   ├── services/
│   │   └── apiKeyApi.js             # API Key HTTP 服务
│   ├── stores/
│   │   └── apiKey.js                # Pinia Store
│   ├── views/
│   │   └── ApiKeyManagement.vue     # API Keys 管理页面
│   ├── router/
│   │   └── index.js                 # 新增路由
│   └── components/
│       └── layout/
│           └── AppLayout.vue        # AI 菜单新增 API keys 入口
```

**Structure Decision**: 采用 Web 应用架构（前端 + 后端微服务）。后端新增文件遵循 UserManage 现有的 models/schemas/services/routers 分层模式；前端新增文件遵循现有的 services/stores/views 模式。

## Complexity Tracking

无 Constitution 违规需要论证。
