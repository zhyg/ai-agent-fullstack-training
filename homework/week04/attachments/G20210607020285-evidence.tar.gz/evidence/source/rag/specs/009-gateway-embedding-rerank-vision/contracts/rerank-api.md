# API Contract: Rerank

**Endpoint**: `POST /api/llm/v1/rerank`
**Auth**: Bearer Token (API Key)
**Protocol**: Cohere Rerank 兼容

## Request

### Headers

```
Authorization: Bearer <api_key>
Content-Type: application/json
```

### Body

```json
{
  "model": "bge-reranker-v2-m3",
  "query": "什么是机器学习？",
  "documents": ["机器学习是...", "深度学习是...", "NLP是..."],
  "top_n": 3,
  "return_documents": true
}
```

| Field | Type | Required | Constraints | Description |
|---|---|---|---|---|
| `model` | string | Yes | 已配置的 rerank 类型模型 | 模型 display name |
| `query` | string | Yes | max 10000 chars | 查询文本 |
| `documents` | string[] | Yes | 1-500 items | 候选文档列表 |
| `top_n` | integer | No | ge=1, le=len(documents) | 返回前 N 条结果 |
| `return_documents` | boolean | No | default=true | 是否在响应中返回原文 |

### 校验规则

- `documents` 不能为空列表
- `documents` 最多 500 条
- `top_n` 若指定，必须 <= documents 长度
- `model` 必须对应 `category=rerank` 的模型，否则返回 404
- 请求体不超过 1MB

## Response

### 200 OK

```json
{
  "id": "rerank-a1b2c3d4",
  "results": [
    {
      "index": 0,
      "relevance_score": 0.95,
      "document": {"text": "机器学习是..."}
    },
    {
      "index": 2,
      "relevance_score": 0.72,
      "document": {"text": "NLP是..."}
    }
  ],
  "model": "bge-reranker-v2-m3",
  "usage": {
    "prompt_tokens": 120,
    "total_tokens": 120
  }
}
```

| Field | Type | Description |
|---|---|---|
| `id` | string | 请求唯一标识 |
| `results` | array | 按 relevance_score 降序排列 |
| `results[].index` | integer | 原始文档列表中的索引 |
| `results[].relevance_score` | float | 相关性分数 |
| `results[].document` | object \| null | 文档原文（当 return_documents=true） |
| `model` | string | 实际使用的模型名 |
| `usage.prompt_tokens` | integer | 输入 token 数（query + documents） |
| `usage.total_tokens` | integer | 总 token 数 |

### Error Responses

| Status | Code | Condition |
|---|---|---|
| 400 | `invalid_request` | documents 为空/超过 500 条，或 query 过长 |
| 401 | `invalid_api_key` | API Key 无效 |
| 404 | `model_not_found` | 模型不存在或 category 不匹配 |
| 429 | `rate_limit_exceeded` | 超过模型 RPM/TPM 限制 |
| 502 | `upstream_error` | 供应商返回错误 |
| 504 | `upstream_timeout` | 供应商超时 |
