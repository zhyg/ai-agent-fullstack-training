# Data Model: 智能体菜单功能完善（011-agent-settings）

**Date**: 2026-11-22 | **依据**: spec.md Key Entities / FR-001–FR-018；research.md R1/R2/R4/R9

## 实体: Agent（表 `knowledge_manage.agents`）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK，默认 uuid4 | 智能体标识 |
| type | String(20) | NOT NULL，UNIQUE | 枚举：`quick_qa` / `reasoning_action` / `planning_reasoning`；预置后不可变 |
| name | String(100) | NOT NULL，UNIQUE | 显示名称，可编辑，跨智能体唯一（FR-018） |
| icon | String(50) | NOT NULL | 内置图标库 key（如 `thunderbolt`），可编辑（FR-006） |
| description | Text | NOT NULL，默认 '' | 描述，可编辑；预置默认值见 FR-016 |
| status | String(10) | NOT NULL，默认 `enabled` | 枚举：`enabled` / `disabled`（FR-003） |
| config | JSONB | NOT NULL | 整份编辑配置，结构见下 |
| created_at | TIMESTAMP | NOT NULL，默认 utcnow | 创建时间 |
| updated_at | TIMESTAMP | NOT NULL，默认 utcnow，onupdate utcnow | 更新时间 |

索引/约束：`type` 唯一（保证预置幂等与固定三行）；`name` 唯一（FR-018）。无外键（提示词/模型为逻辑引用，见下）。

## config JSON 结构（按类型裁剪）

```json
{
  "prompts": {
    "clarify": "<prompt_id>",
    "rewrite": "<prompt_id>",
    "answer": "<prompt_id>",
    "compress": "<prompt_id>",
    "rerank": "<prompt_id>",
    "sufficiency": "<prompt_id>",
    "planning": "<prompt_id>"
  },
  "retrieval": {
    "mode": "vector | keyword | hybrid",
    "vector_top_k": 20,
    "keyword_top_k": 20,
    "hybrid_top_k": 20,
    "rerank_top_n": 15
  },
  "models": {
    "analysis_model_id": "<model id>",
    "max_tokens": 5000,
    "embedding_model_id": "<model id>",
    "rerank_model_id": "<model id>"
  },
  "loop_count": 10,
  "tools": ["createPlan", "listPlan", "getPlan", "updatePlan", "deletePlan",
            "rewriteQuestion", "bm25Search", "vectorSearch", "rerank", "zip",
            "listTableMetaData", "sqlExecute"]
}
```

类型裁剪规则：
- `quick_qa`：prompts 仅 clarify/rewrite/answer/compress/rerank；无 loop_count、无 tools。
- `reasoning_action`：prompts 含 sufficiency（不含 planning）；loop_count 默认 10；无 tools。
- `planning_reasoning`：prompts 含 planning（不含 sufficiency）；loop_count 默认 100；tools 默认全 12 项。
- 三种 retrieval 召回数量字段恒共存（独立持久化，切换 mode 不重置，spec Edge Cases）。

## 校验规则（Pydantic + 服务层）

| 规则 | 范围/条件 | 来源 |
|------|-----------|------|
| vector_top_k / keyword_top_k / hybrid_top_k / rerank_top_n | 整数 1–100；默认 20/20/20/15 | FR-008 |
| loop_count | 整数 1–1000；默认 10（reasoning_action）/100（planning_reasoning） | FR-010 |
| max_tokens | 整数 1–50000；默认 5000 | FR-009 |
| retrieval.mode | 枚举 vector/keyword/hybrid，单选 | FR-008 |
| models.analysis_model_id | 必填，非空字符串 | FR-013/Assumptions |
| models.embedding_model_id | mode∈{vector,hybrid} 必填；mode=keyword 可选 | FR-013/Assumptions |
| models.rerank_model_id | 必填 | FR-013/Assumptions |
| prompts 必填用途 | 按类型必需用途必填；planning_reasoning 中被取消勾选工具对应用途（rewrite/rerank/compress/检索类）转可选 | FR-013/Assumptions |
| prompts.* 引用存在性 | 必填用途的 prompt_id 必须存在于同库 prompts 表，否则 400 | FR-015/R4 |
| tools | 仅 planning_reasoning；元素限于 12 个固定 key；默认全选 | FR-011 |
| name | 1–100 字符；跨智能体唯一（服务层预检 409 + DB 约束兜底） | FR-018 |
| icon | 限于内置图标库 key 集合 | FR-006/R6 |
| status | 枚举 enabled/disabled；仅经 PATCH status 端点变更 | FR-003/R8 |

## 状态 transitions

```text
enabled --PATCH status{disabled}--> disabled
disabled --PATCH status{enabled}--> enabled
```

- 状态切换不触碰 config（停用保留全部配置，spec Edge Cases）。
- 无删除 transition（FR-014 预置不可删）。
- 并发更新：last-write-wins，无版本字段（R7）。

## 关系（逻辑引用，无物理外键）

- `config.prompts.*` → `knowledge_manage.prompts.id`（同库；删除后前端标“已失效”，必填项阻止保存，FR-015）。
- `config.models.*` → LlmGateway 模型配置标识（跨服务；仅存字符串；失效检测由前端对照模型列表完成，R4）。
- Agent 1:1 config（内嵌 JSONB，R1）。

## 预置数据（Alembic 数据迁移，幂等按 type 判存）

| type | name | icon（默认 key） | description | status |
|------|------|------------------|-------------|--------|
| quick_qa | 快速问答 | thunderbolt | 提供快速问答功能，用户输入问题，直接检索回答 | enabled |
| reasoning_action | 推理行动 | bulb | 提供react的多轮推理功能 | enabled |
| planning_reasoning | 规划推理 | partition | 提供plan+react的智能规划、多轮推理功能 | enabled |

预置 config：prompts 各用途为 null（待管理员配置）；retrieval 默认 mode=vector、20/20/20/15；models 各引用为 null、max_tokens=5000；loop_count 按类型默认；tools 全 12 项。