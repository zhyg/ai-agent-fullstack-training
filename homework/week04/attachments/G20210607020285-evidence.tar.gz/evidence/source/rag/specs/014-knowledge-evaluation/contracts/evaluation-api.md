# API Contract: 知识库评测（014-knowledge-evaluation）

**Base**: `/api/knowledge/evaluations`（KnowledgeManage:8002，注册方式同既有 router）
**Auth**: 全部接口 Bearer JWT（复用 `app.dependencies` 当前用户依赖）；资源仅创建者本人可访问，跨用户一律 404（不泄露存在性，模式同 chats）。
**错误格式**: `{"detail": "..."}`；状态码：400 校验失败 / 404 不存在或非本人 / 409 冲突（重名/并发/锁定/进行中删除）/ 503 ES 异常。

下拉数据源复用既有接口，不在本契约重复定义：模型 `GET /api/llm/models`（前端过滤 category=chat，R9）、提示词 `GET /api/knowledge/prompts`、智能体 `GET /api/knowledge/agents`、知识库 `GET /api/knowledge/knowledge-bases`。

## 1. 评测设置

### GET /settings
返回本人设置；无记录时返回空对象默认值。
```json
{"analysis_model_id": "uuid|null", "recall_prompt_id": "uuid|null", "accuracy_prompt_id": "uuid|null"}
```

### PUT /settings
请求体同上（三字段均可空，允许部分保存）。
- 200：保存后的设置。
- 409：本人存在 running 评测任务（FR-009 锁定），detail 指明"评测进行中，设置已锁定"。
- 400：引用的提示词非本人所有。

## 2. 测试集

### GET /test-sets
本人测试集列表（不分页，上限场景 ≤ 数十个）：
```json
{"items": [{"id": "uuid", "name": "回归集A", "item_count": 10, "created_at": "...", "updated_at": "..."}]}
```

### POST /test-sets
`multipart/form-data`：`name`（str）+ `file`（JSON 文件）。
- 201：`{"id", "name", "item_count"}`。
- 400：JSON 校验失败（FR-006），detail 指明具体错误（非数组/空数组/第 N 项 question 为空/超 500 题/超 2MB）。
- 409：同名已存在。

### GET /test-sets/{id}/download
- 200：`application/json` 附件（`Content-Disposition: attachment; filename="{name}.json"`），body 为标准 `[{question, answer}]` 数组（从库导出，决策13）。
- 404：不存在或非本人。

### PUT /test-sets/{id}
`multipart/form-data`：`file`。重新上传覆盖（名称/ID 不变），校验规则同 POST。
- 200：`{"id", "name", "item_count"}`。
- 400：校验失败；409：该测试集被 running 任务锁定（FR-009）。

### DELETE /test-sets/{id}
- 204：删除成功（历史评测快照不受影响）。
- 409：被 running 任务锁定。

## 3. 评测任务

### POST /runs
```json
{"knowledge_base_ids": ["uuid", "..."], "agent_id": "uuid", "test_set_id": "uuid"}
```
行为：全量预检（FR-011：设置三项齐备 + 模型存在且 category=chat + 两提示词存在且本人 + 智能体存在且启用 + 知识库全部存在且本人 + 测试集存在且本人）→ 并发检查（FR-012）→ 创建 run（ID+名称快照）+ 逐题预建 pending 明细 → 启动后台任务 → 立即返回。
- 201：`{"id", "status": "running", "total_items": 10}`。
- 400：预检失败，detail 一次性列出全部失效项（模式同 ConfigInvalidError）；knowledge_base_ids 为空。
- 409：本人已有 running 任务。

### GET /runs?page=1&page_size=20
本人历史列表（created_at 倒序），平均分实时聚合（R13）：
```json
{"items": [{"id": "uuid", "started_at": "...", "knowledge_base_names": ["库A", "库B"],
  "agent_name": "快速问答", "test_set_name": "回归集A",
  "avg_recall": 0.82, "avg_accuracy": 92.5, "status": "completed",
  "total_items": 10, "completed_items": 10}], "total": 3, "page": 1, "page_size": 20}
```
`avg_recall`/`avg_accuracy`：仅 success 题平均；无成功题为 null（前端展示空）。recall 为 0–1，accuracy 为 0–100。

### GET /runs/{id}
详情（含全部题目明细，按 seq 升序）：
```json
{"id": "uuid", "status": "completed", "started_at": "...", "finished_at": "...",
 "knowledge_base_ids": ["..."], "knowledge_base_names": ["..."],
 "agent_id": "...", "agent_name": "...", "test_set_id": "...", "test_set_name": "...",
 "total_items": 10, "completed_items": 10, "avg_recall": 0.82, "avg_accuracy": 92.5,
 "error_message": null,
 "items": [{"id": "uuid", "seq": 1, "question": "...", "standard_answer": "...",
   "status": "success", "agent_answer": "...",
   "context": [{"file_name": "手册.pdf", "content": "...", "score": 0.87, "chunk_id": "...", "document_id": "...", "kb_id": "..."}],
   "recall": 0.8, "accuracy": 95.0,
   "recall_analysis": {"key_points": [{"point": "...", "covered": true}], "recall": 0.8},
   "accuracy_analysis": {"issues": [{"type": "捏造", "content": "...", "evidence": "..."}]},
   "recall_raw_output": null, "accuracy_raw_output": null,
   "failure_reason": null, "trace_id": "32位hex|null"}]}
```
失败题：status=failed、failure_reason 必填、得分置空、已完成部分（如 agent_answer/context/单项分析 JSON）保留；评分失败题对应 raw_output 非空（决策14）。

### DELETE /runs/{id}
- 204：记录与明细级联删除（FK CASCADE），不可恢复。
- 409：status=running（须先取消，FR-033）。

### POST /runs/{id}/cancel
- 200：`{"id", "status": "running", "cancel_requested": true}`（异步生效：当前题含评分完成后终止，终态 cancelled 经 SSE/查询可见）。
- 404：非本人/不存在；409：任务已终态。

### GET /runs/{id}/events（SSE）
`StreamingResponse` `text/event-stream`；连接即发 snapshot，随后增量；终态 done 后服务端关闭。事件均为 `data: {JSON}\n\n`：
```json
{"type": "snapshot", "run_id": "...", "status": "running", "completed": 5, "total": 20}
{"type": "progress", "run_id": "...", "status": "running", "completed": 6, "total": 20,
 "last_item": {"id": "...", "seq": 6, "status": "success", "recall": 0.8, "accuracy": 95.0}}
{"type": "done", "run_id": "...", "status": "completed|cancelled|failed",
 "completed": 20, "total": 20, "avg_recall": 0.82, "avg_accuracy": 92.5, "error_message": null}
```
- 断线重连/页面刷新：重连即收 snapshot 恢复进度（R6）；已终态任务连接即发 done。
- 404：非本人/不存在。

## 4. 题目 trace（US4）

### GET /runs/{run_id}/items/{item_id}/trace
归属校验：run.user_id=当前用户 且 item.run_id=run_id（决策21，不校验会话）。
- 200 命中：`{"ready": true, "data": [{"traceID": "...", "spans": [...], "processes": {...}}]}`（Jaeger UI 格式，`trace_query_service.fetch_trace` 透传；含 agent 链路 span 与 `evaluation.recall`/`evaluation.accuracy` 子 span，后者带 prompt.name/version/purpose 属性）。
- 200 未命中：`{"ready": false, "reason": "pending"}`（created_at 距今 ≤48h，写入中）或 `{"ready": false, "reason": "expired"}`（>48h，超 ±1 天索引窗口，R11）；item.trace_id 为空 → `{"ready": false, "reason": "no_trace"}`。
- 404：run/item 不存在、非本人或 item 不属于该 run。
- 503：ES 异常（detail 透传，模式同 chats trace 路由）。

## 5. 前端消费约定

- `evaluationApi.js`：axios 实例 + Bearer 拦截器 + 401 跳登录（沿用 traceApi.js 模式）；SSE 接入方式对齐会话页既有做法。
- `traceApi.js` 新增 `fetchEvaluationItemTrace(runId, itemId)`，返回结构与 `fetchMessageTrace` 一致；`TraceDrawer` 经 `fetcher` prop 注入（R11），`expired` → 文案"轨迹已过期清理"。
- 展示口径：recall 渲染为百分比（×100）；accuracy 直接百分比；null 展示空；分析 JSON 格式化展示（决策14）。