# Data Model: 智能体运行优化（013-agent-optimization）

**Date**: 2026-11-24 | **Plan**: [plan.md](./plan.md) | **Research**: [research.md](./research.md)

本特性**无 PostgreSQL schema 变更、无 Alembic 迁移**。数据变化集中在：ES 新索引、agent.config JSON 新键、请求级内存态新字段、trace 属性/事件扩展。

---

## 1. HistoryQADocument（历史问答文档，ES）

对应 spec Key Entities"历史问答文档"；索引与 mapping 契约详见 [contracts/history-qa-es.md](./contracts/history-qa-es.md)。

| 字段 | 类型 | 说明 | 校验/约束 |
|---|---|---|---|
| `_id` | ES 文档主键 | assistant 消息 id（PG messages.id），幂等覆盖写（R7） | 非空 |
| `chat_id` | keyword | 会话 ID，检索过滤条件 | 非空 |
| `user_id` | keyword | 用户 ID（冗余存储，检索仅按 chat_id 过滤） | 非空 |
| `question` | text（ik） | 用户原问题原文 | 非空 |
| `answer` | text（ik） | 助手完整答案原文（含终止话术，R6） | 非空 |
| `qa_text` | text（ik_max_word / ik_smart） | `question + "\n" + answer` 拼接文本，BM25 主检索字段 | 非空 |
| `created_at` | date | 轮次完成时间（UTC ISO8601，取落库时刻） | 非空 |
| `embedding_model` | keyword | 所用向量模型名（网关 display_name，决策6） | 非空 |
| `embedding_model_id` | keyword | 向量模型 UUID（排查用） | 非空 |
| `embeddings` | dense_vector(dims) | qa_text 的整体向量（补充澄清：问题+答案拼接后向量化） | dims=len(向量)，决定索引名 |

**生命周期/状态**：
- 创建：问答 `done` 终态落库成功后异步写入（R5/R6）；取消/报错/停止轮次**不创建**。
- 更新：同 `_id` 重写即覆盖（幂等）；无业务更新路径。
- 删除：本特性不做会话删除联动清理（会话删除后文档残留但检索按 chat_id 过滤，不可达；留待后续特性）。
- 隔离：索引按 dims 分（`chat_history_qa_{dims}`），换向量模型后旧文档自然不可检索（R1，决策12容错）。

**关系**：HistoryQADocument N:1 Chat（chat_id）；1:1 Message（assistant 消息，_id）。

## 2. HistoryRetrievalConfig（历史信息检索配置，agent.config JSON 新键）

对应 spec Key Entities"历史信息检索配置"；API 契约详见 [contracts/agent-optimization-api.md](./contracts/agent-optimization-api.md) §1。

```jsonc
// agents.config 新增键（三类智能体均有）
{
  "history_retrieval": {
    "top_k": 10        // 检索召回数：int，1–100，默认 10
  }
}
```

| 规则 | 说明 |
|---|---|
| 默认兜底 | 存量 config 缺 `history_retrieval` 键 → Pydantic `default_factory` 补默认 `{top_k: 10}`（FR-005，零迁移） |
| 保存校验 | Pydantic `ge=1, le=100`；越界拒绝保存；前端 validateAgentDraft 同步校验 |
| 固定项 | 检索模式恒为混合（BM25+向量 RRF），**无** mode 字段、**无**启用开关（决策8） |
| 裁剪 | `agent_service.update_agent` 对三类均保留该键（不同于 loop_count/tools 的按类型裁剪） |
| 预检 | `build_snapshot` 冻结为 `AgentConfigSnapshot.history_top_k`；有默认值恒合法，不新增预检失败项 |

## 3. 请求级内存态扩展（RequestRuntimeState / AgentConfigSnapshot）

`KnowledgeManage/app/services/agent_runtime/state.py`，请求结束即丢弃，不落库。

| 载体 | 新字段 | 类型/默认 | 语义 |
|---|---|---|---|
| AgentConfigSnapshot | `history_top_k` | `int = 10` | 冻结的历史检索召回数 |
| RequestRuntimeState | `clarify_history` | `Optional[List[dict]] = None` | 澄清/重写专用组装历史 `[{role, content}]`；**None=降级/未组装**，下游回退 state.history（最近 10 轮） |

**clarify_history 组装状态机**（R9/R10/R11）：

```text
入口 state 构建（history=trim_history_rounds 最近10轮，保持不变）
        │
        ▼
history_retrieve 步骤（每请求一次，flow 分发前）
        │
        ├─ ES 命中非空 ──► clarify_history = ES命中轮次(created_at升序,去重)
        │                   + 最近2个完整问答轮原文（尾部保底）
        │                   ──► 预算裁剪（头部逐轮淘汰）
        │
        └─ 异常/超时(>3s)/零命中 ──► clarify_history 保持 None
                                     span 记 history_retrieve_degraded
        │
        ▼
clarify / rewrite（含循环后续重写、工具 rewriteQuestion）
   读 clarify_history（非 None）或 state.history（None 回退）
answer / planning _init_messages 恒读 state.history（口径不变）
```

**去重与排序规则**（FR-008）：
- 去重键 = question 原文精确匹配（ES 命中 vs 保底 2 轮 vs 当前问题）；
- 仅完整轮次（user+assistant 成对）；当前问题本身剔除（由 `{question}` 占位符单独提供）；
- 排序：ES 命中按 created_at 升序在前，保底 2 轮（必为最新）在后。

## 4. Trace 属性与事件扩展（Span Provenance / Plan Text Warning）

对应 spec Key Entities"轨迹节点溯源信息""规划文本警告事件"；契约详见 [contracts/agent-optimization-api.md](./contracts/agent-optimization-api.md) §3。

### 4.1 新属性

| 属性 | 类型 | 附着 span | 说明 |
|---|---|---|---|
| `prompt.name` | string | agent.clarify / agent.rewrite / agent.compress / agent.sufficiency / agent.answer / agent.plan_decision（含工具内同名 span） | 取自 PromptSnapshot.name |
| `prompt.version` | string | 同上 | 取自 PromptSnapshot.version |
| `prompt.purpose` | string | 同上 | clarify/rewrite/compress/sufficiency/answer/planning |
| `retrieval.chunks` | string（JSON 数组） | agent.retrieve.vector / agent.retrieve.hybrid / agent.retrieve.keyword（主流程+工具内） | `[{chunk_id, score, file_name, content}]`，content 全文**不截断**（不经 to_json_attr，R14） |

### 4.2 新 span

| span | 父 | 属性 | 说明 |
|---|---|---|---|
| `agent.history_retrieve` | agent.run | agent.input={query, chat_id, top_k}；agent.output={count, round_ids, degraded} | 历史检索步骤，每请求 1 个 |
| `agent.history_index` | 无（独立 trace，root span 已结束） | chat.id、session.id、origin.trace_id | 异步写入任务；失败记事件 |

### 4.3 新事件

| 事件 | 附着 span | 属性 | 触发 |
|---|---|---|---|
| `history_retrieve_degraded` | agent.history_retrieve | reason ∈ timeout/unavailable/embedding_failed/empty_result/error | 降级回退最近 10 轮（FR-010） |
| `history_index_failed` | agent.history_index | error（异常摘要） | ES 写入失败（FR-013，仅日志+trace） |
| `plan_text_not_tool_call` | agent.plan_decision | loop、content_excerpt（前 500 字符） | 无 tool_calls 且 content 含计划标记（FR-017）；同时写入 rt.events 随 meta 落库 |
| `context_evicted`（扩展） | 现有附着点 | 新增 `dropped_clarify_history` 计数 | 组装历史被预算淘汰（FR-011） |

## 5. 服务端配置扩展（config.*.yaml）

`AgentRuntimeConfig`（`app/core/config.py`）新增：

| 键 | 类型/默认 | 说明 |
|---|---|---|
| `agent_runtime.history_retrieve_timeout` | `float = 3`（秒） | 历史检索整体超时（含向量化+ES+RRF），超过即降级（R10） |

三个环境 yaml（dev/prod/test）同步添加。

## 6. 前端常量扩展（与后端同步）

| 文件 | 变更 |
|---|---|
| `utils/agent.js` | `MENU_SECTIONS.history='历史信息检索'`；`MENU_SECTIONS_BY_TYPE` 三类在 retrieval 后插入 history；`getDefaultConfig` 增 `history_retrieval:{top_k:10}`；`validateAgentDraft` 增 1–100 校验 |
| `components/chat/ChatArea.vue` | `STEP_LABELS.history_retrieve='历史信息检索'` |
| `components/trace/SpanDetail.vue` | retrieval.chunks 美化 JSON 折叠面板（prompt.* 走既有 Tags 表格，无需专门面板） |