# Quickstart: 聊天流式生成取消与断线恢复

**Feature**: 005-chat-stream-cancel | **Date**: 2026-10-30

## Prerequisites

- Python 3.11+ 环境
- Node.js 26+ 环境
- PostgreSQL 运行中（开发环境共享数据库）
- Redis 运行中
- LlmGateway 服务启动（默认 `http://localhost:8003`）
- KnowledgeManage 服务启动（默认 `http://localhost:8002`）
- 前端开发服务器启动（默认 `http://localhost:5173`）
- 至少一个已注册的 LLM 模型配置

## Validation Scenarios

### VS-001: 主动取消生成

**前置条件**: 登录用户，已创建会话并选择模型

1. 在会话页面发送一条消息（如"请写一篇 2000 字的文章"）
2. 等待 AI 开始流式输出
3. 点击输入区域的"取消"按钮
4. **验证**:
   - 前端立即停止内容更新（< 1 秒）
   - 已接收的内容保留显示
   - "取消"按钮恢复为"发送"按钮
   - 查看会话历史，已生成内容保存为消息（末尾含 `[已取消]`）
   - 会话状态显示为"已取消"

### VS-002: 页面离开后数据保持

**前置条件**: 登录用户，已创建会话并选择模型

1. 发送一条消息，等待 AI 开始流式输出
2. 在 AI 仍在生成时，关闭浏览器标签页（或导航到其他功能页面）
3. 等待 30 秒（假设生成需要约 20 秒）
4. 重新打开会话页面
5. **验证**:
   - AI 回复消息已完整保存
   - 会话状态为"已完成"
   - 回复内容与完整生成结果一致

### VS-003: 页面离开后重新连接（生成仍在进行）

**前置条件**: 登录用户，已创建会话并选择模型，使用较慢的模型

1. 发送一条消息，等待 AI 开始流式输出
2. 在 AI 仍在生成时，关闭浏览器标签页
3. 在 5 秒内重新打开会话页面（AI 仍在生成中）
4. **验证**:
   - 已接收的内容立即显示
   - 剩余内容继续流式推送
   - 生成完成后会话状态变为"已完成"

### VS-004: 取消按钮界面状态

**前置条件**: 登录用户，已创建会话并选择模型

1. 观察空闲状态的输入区域 → **验证**: 显示"发送"按钮
2. 发送消息 → **验证**: "发送"按钮变为"取消"按钮（loading 样式或不同颜色）
3. 等待生成完成 → **验证**: "取消"按钮恢复为"发送"按钮
4. 发送新消息，点击"取消" → **验证**: "取消"按钮立即恢复为"发送"按钮

### VS-005: 幂等取消

**前置条件**: 登录用户，AI 正在生成

1. 快速连续点击"取消"按钮 3 次
2. **验证**:
   - 仅第一次取消生效
   - 无错误提示或异常行为
   - 最终状态正确（已取消）

## Running Existing Tests

### Backend Unit Tests

```bash
cd KnowledgeManage

# 运行后台生成相关测试
python -m pytest tests/test_chat_background.py -v

# 运行流式响应相关测试
python -m pytest tests/test_chat_stream.py -v

# 运行全部测试
python -m pytest tests/ -v
```

### Expected Test Results

- `test_chat_background.py`: 10 个测试全部通过
  - `test_browser_close_continues_and_persists_full_response`
  - `test_cancel_after_browser_close_interrupts_idle_upstream`
  - `test_http_disconnect_does_not_cancel_generation`
  - `test_cancelling_sse_while_waiting_does_not_cancel_generation`
  - `test_connected_cancel_emits_cancelled_not_error`
  - `test_cancel_from_redis_interrupts_idle_upstream`
  - `test_cancel_next_generation_does_not_inherit_previous_signal`
  - `test_detaching_does_not_cancel_generation`
  - `test_duplicate_send_reattaches_to_active_job`

- `test_chat_stream.py`: 现有测试全部通过

## References

- API Contracts: [contracts/api-contracts.md](contracts/api-contracts.md)
- Data Model: [data-model.md](data-model.md)
- Research: [research.md](research.md)
- Spec: [spec.md](spec.md)
