# Research: 智能体运行优化（013-agent-optimization）

**Date**: 2026-11-24 | **Plan**: [plan.md](./plan.md)

本阶段解决 spec Assumptions 与 014 §0.3 留待规划的全部技术项。所有决策均以现有代码实测为依据（关键文件已通读），无遗留 NEEDS CLARIFICATION。

---

## R1. ES 索引名与向量维度策略（014 §0.3 第 1 项）

- **Decision**: 按向量维度分索引：`chat_history_qa_{dims}`（如 `chat_history_qa_1024`）。写入时以实际生成向量的 `len(vector)` 确定索引；检索时以 query 向量维度确定索引。索引创建走新增 `es_client.ensure_history_index(dims)`（模式对齐现有 `ensure_index`）。
- **Rationale**: 现有 `knowledge_chunks_{kb_id}` 即"一库一索引、dims 建索引时冻结"模式；`dense_vector.dims` 建后不可改，script_score 遇维度不匹配直接报错。按 dims 分索引后，智能体更换不同维度向量模型时新旧文档天然隔离——旧索引查不到（等同零命中→降级），完全符合决策12"由保底+降级天然容错"，且无需任何迁移/重算。query 向量在检索时本来就要生成，取 dims 零额外开销。
- **Alternatives considered**: ① 单索引固定 dims——换模型后 script_score 报维度错误，虽可捕获降级但同 dims 不同模型的脏向量仍会污染召回；② 单索引多向量字段（每模型一字段）——mapping 无限膨胀；③ 写入时记录 dims 字段+查询过滤——script_score 仍会对不匹配文档报错，需 script 内判长，复杂且慢。

## R2. 中文分词器选型（014 §0.3 第 1 项）

- **Decision**: 历史索引文本字段 `qa_text` 用 `ik_max_word`（索引）+ `ik_smart`（查询）；`question`/`answer` 原文字段同样配置 ik 以便 BM25 命中。已实测确认本机 ES 8.17.0 安装 `analysis-ik 8.17.0` 插件（`GET /_cat/plugins`）。
- **Rationale**: 现有 knowledge_chunks 用 standard（单字切分），中文 BM25 效果差；历史问答是纯中文短文本，ik 是既成可用资源，不引入新依赖。仅新索引使用 ik，不动存量 knowledge_chunks mapping。
- **Alternatives considered**: ① standard 与知识库保持一致——中文召回质量差，白白放着已装插件不用；② smartcn（需另装插件）——引入新运维依赖。
- **风险注记**: 生产 ES 若未装 ik，`ensure_history_index` 建索引失败→写入记日志失败、检索异常→降级，主流程不受影响（与 FR-010/013 一致）；部署清单需注明 ik 插件依赖（quickstart 已列）。

## R3. 混合检索实现口径（spec"BM25 + kNN"措辞落地）

- **Decision**: 复用 `retrieval_service.py` 的既有口径：BM25（match）+ 向量（`script_score` cosineSimilarity+1.0）两路召回 → Python RRF 融合（`Σ1/(k+rank)`，k 取 `settings.agent_runtime.rrf_k=60`）→ 截断 topk。在 `history_qa_service.py` 内实现同口径的轻量版本（融合对象是问答轮次而非 ContextChunk，不强行复用 `_rrf_fuse` 函数本体，但算法与参数一致）。两路查询均带 `term: chat_id` 过滤。
- **Rationale**: 014 §2.2.2 明确"复用现有 retrieval_service 的混合检索实现口径"；现有实现即 script_score 而非原生 kNN（兼容存量 mapping），历史索引沿用同一口径保证行为一致、代码模式可对照。单会话文档量小（每轮 1 文档），script_score 全量打分性能足够。
- **Alternatives considered**: ① ES 8.x 原生 kNN + RRF retriever——与现有口径不一致且需 `index:true` 的 HNSW mapping，收益在单会话小数据量下为零；② 直接 import `_rrf_fuse`——其签名绑定 ContextChunk，硬套需要伪造 chunk 对象，得不偿失。

## R4. 相关度分数阈值（014 §0.3 第 2 项）

- **Decision**: 不做阈值过滤，仅按 RRF 名次截断 topk（spec Assumptions 已确认"不引入阈值"）。
- **Rationale**: RRF 分数是名次函数（≈0.016–0.033），无绝对相关度语义，阈值无从标定；误杀相关轮次的代价高于多带入弱相关轮次（后者仅多占少量预算，且有 enforce_budget 兜底）。
- **Alternatives considered**: 按 BM25/cosine 原始分设阈值——跨路分数不可比（现有 `_rrf_fuse` 注释已言明），需双阈值调参，YAGNI。

## R5. 异步写入载体与重试（014 §0.3 第 3 项）

- **Decision**: `asyncio.create_task` 火忘式后台任务，不重试；失败仅 `logger.warning` + 独立 trace span `agent.history_index` 上记 `history_index_failed` 事件。触发点：`chat_service._run_agent_generation` 中 `_finalize_agent_generation` 返回 `finalized=True` 且非 cancelled、无 error_event、content 非空之后。写入所需 `embedding_model_id` 由 `run_agent_generation` 返回值新增顶层键携带（不进 meta，避免污染消息落库）。
- **Rationale**: 与现有 `_deferred_cleanup` 的 asyncio 后台任务模式一致；单文档写入失败概率低且下一轮问答会自然累积新数据，重试队列属过度设计（spec Assumptions 已确认"写失败不重试"）。root span 在写入时已 end，故事件记在独立 span（带 chat.id / session.id / 原 trace_id 属性便于关联检索）。
- **Alternatives considered**: ① Redis Stream 队列+消费者——新增运维面，违反"仅记日志"的既定决策；② 写入挂在 root span 存续期内同步等待——阻塞终态事件下发，违反 FR-013。

## R6. 写入范围口径（FR-013"完整轮次"边界）

- **Decision**: 凡走 `done` 终态（finalized 且非 cancelled、无 error）且 content 非空的轮次均写入，**包括** `terminate_reason=clarify_failed`（澄清反问）与 `empty_retrieval`（无资料话术）。取消/报错/停止（cancelled=True 或 error_event 非空）不写入。
- **Rationale**: 严格对齐决策7字面口径"取消/报错/停止的不完整轮次不写入"——澄清反问也是已完成的问答轮（用户下一轮回答会依赖该反问语境，检索命中它反而有助于指代解析）。
- **Alternatives considered**: 排除 clarify_failed/empty_retrieval——引入 meta.terminate_reason 白名单判断，超出已澄清决策范围；如后续发现噪声可再收紧。

## R7. ES 文档主键与幂等

- **Decision**: `_id` = assistant 消息 id（`_finalize_agent_generation` 返回的 message_id）。写入用 index API（同 id 覆盖），`refresh="wait_for"` 不采用（默认 refresh，1s 可见性延迟可接受——下一轮提问间隔远大于 1s）。
- **Rationale**: 消息 id 全局唯一且与 PG 落库一一对应，天然幂等（任务重复触发不产生重复轮次）；`es_chunk_service.bulk_index_chunks` 用 `wait_for` 是为解析后立即可查，历史写入无此需求，避免写入放大。
- **Alternatives considered**: uuid 新 id——重复写入产生重复轮次，破坏"按轮去重"前提。

## R8. 历史检索步骤位置与"每请求一次"保证

- **Decision**: 在 `agent_runtime.run_agent_generation` 内、`state` 构建后、`_get_runner` 分发前执行 `history_qa_service.retrieve_and_assemble(state, emit)`：发 StepEvent（step=`history_retrieve` start/end）、建 span `agent.history_retrieve`（父为 agent.run）。三个 langgraph 图**零改动**。
- **Decision（补充）**: `StepName` Literal 与前端 `STEP_LABELS` 增加 `history_retrieve`（"历史信息检索"）。
- **Rationale**: 三类 flow 共用入口，单点插入天然满足 FR-009"每请求仅执行一次"；推理行动循环的后续重写读同一份 `state.clarify_history`，无重复检索。放 flow 图内需改 3 个图且循环边界易误触发重查。
- **Alternatives considered**: 各 flow 增加 history 节点——3 处重复接线，langgraph recursion_limit 与条件边均需调整，风险大。

## R9. 组装历史的数据结构与替换机制（FR-008/009）

- **Decision**:
  - `RequestRuntimeState` 新增 `clarify_history: Optional[List[dict]] = None`（`[{role, content}]`，与 state.history 同构）。None=未启用/降级，此时澄清/重写沿用 `state.history`（最近 10 轮）。
  - 组装算法：① 从入口原始 history（含本轮问题）剔除末尾当前问题后，取最近 2 个完整问答轮（user+assistant 成对；落单的 user 消息不算完整轮）；② ES 命中轮次展开为 user/assistant 两条消息，剔除与保底轮次重复者（去重键=question 原文精确匹配）及等于当前问题者；③ ES 命中按 created_at 升序在前、保底 2 轮在后拼接（保底轮必为最新，时间序自然成立）。
  - `steps.py` 新增 `clarify_history_text(state)`：`state.clarify_history is not None` 时渲染它，否则回退 `history_text(state)`。`run_clarify`/`run_rewrite`/工具 `_rewrite_question` 三处改用该助手；`stream_answer` 与 planning `_init_messages` 保持 `history_text(state)` 不动。
- **Rationale**: 入口 history 仅 `{role, content}` 无消息 id/时间戳，轮次去重只能用 question 文本精确匹配（同一会话内重复提问概率低，误去重代价仅是少一条重复背景）；保底 2 轮天然是最新轮次，"ES 在前、保底在后"即时间序，无需为保底轮补查时间戳。
- **Alternatives considered**: ① 入口 history 改带 message_id/created_at——需动 chat_service 历史查询与旧路径共用逻辑，影响面大；② 直接替换 state.history——违反 FR-009 替换范围（答案生成/planning 会被波及）。

## R10. 3 秒超时与降级实现（FR-010，SC-002）

- **Decision**: `asyncio.wait_for(检索协程, timeout=settings.agent_runtime.history_retrieve_timeout)` 包裹**整个**"query 向量化 + 两路 ES 召回 + RRF"过程；新增配置项默认 3（三个 config yaml 同步）。捕获 `asyncio.TimeoutError`/`RetrievalUnavailableError`/`EmbeddingFailedError`/一切 Exception → `clarify_history=None`（回退最近 10 轮），span 记 `history_retrieve_degraded` 事件（reason=timeout/unavailable/embedding_failed/empty_result/error），流程继续。零命中同样记降级事件并回退。
- **Rationale**: 现有 ES client `request_timeout=30`、embedding httpx `timeout=120` 都远超 3s，必须在协程层整体限时才能兑现 SC-002"额外等待不超过 3 秒"；wait_for 超时会取消内部协程，httpx/ES 调用随之中断。降级=clarify_history 保持 None，下游助手自动回退，无需额外分支。
- **Alternatives considered**: 仅给 ES 调用设 3s request_timeout——embedding 网关慢时仍可能等待 120s，违反 SC-002。

## R11. 组装历史的预算核算（FR-011）

- **Decision**: 组装完成后立即做一次预算裁剪：固定开销取 clarify/rewrite 两提示词渲染模板的较大者 + 当前问题（近似口径，与现有"宁紧勿松"一致），超预算从 `clarify_history` 头部（最早 ES 轮次）逐轮淘汰；由于保底 2 轮位于尾部，"从头淘汰"天然最后才触及保底轮。此后 `enforce_budget` 现有逻辑不变（其核算对象 state.history 供答案生成用）；另在 `enforce_budget` 中当 `clarify_history` 非 None 时同步按相同"先历史后片段"顺序对其裁剪（复用同一 while 循环模式），保证推理行动多轮累积片段后组装历史仍受预算约束。淘汰明细记 `context_evicted` 事件（附 `dropped_clarify_history` 计数）。
- **Rationale**: FR-011 要求组装历史参与现有核算与淘汰；头部淘汰顺序与现有机制一致，实现最小。保底 2 轮在尾部即"最后被淘汰"，兼顾决策3保底意图与预算硬约束。
- **Alternatives considered**: 为保底 2 轮设"永不淘汰"硬保护——极端长回答下 2 轮本身即可超预算，硬保护会使预算失效。

## R12. 配置项建模与存量兜底（FR-004/005，014 §0.3 第 4 项）

- **Decision**:
  - 后端 `schemas/agent.py`：新增 `HistoryRetrievalConfig(top_k: int = Field(10, ge=1, le=100))`，`AgentConfig` 增 `history_retrieval: HistoryRetrievalConfig = Field(default_factory=...)`。存量 config JSON 缺该键时 Pydantic 默认值兜底=10，**无需 Alembic 迁移**。三类智能体均保留（不裁剪）。保存校验由 Pydantic 范围校验承担（越界 422/400），`agent_service.update_agent` 无额外条件必填。
  - 快照：`AgentConfigSnapshot` 增 `history_top_k: int = 10`，`build_snapshot` 从 `config.history_retrieval.top_k` 冻结。预检无需新增失败项（有默认值恒合法）。
  - 前端：`MENU_SECTIONS` 增 `history: '历史信息检索'`；`MENU_SECTIONS_BY_TYPE` 三类均在 `retrieval` 之后插入 `history`；新增 `HistorySection.vue`（单个 a-input-number，1–100，默认 10，说明文案"检索模式固定为混合检索"）；`getDefaultConfig` 增 `history_retrieval: { top_k: 10 }`；`validateAgentDraft` 增校验（文案"检索召回数须为 1–100 的整数"，section=history）；打开编辑弹窗时存量缺省配置以默认值补齐草稿。
- **Rationale**: 区块位置对齐现有"检索策略"之后（语义相邻）；校验文案复用现有"XX须为 1–100 的整数"句式；JSON 列+Pydantic 默认值是本项目处理配置演进的既有模式（loop_count 同法）。
- **Alternatives considered**: ① Alembic 批量回填存量 config——决策9精神（零迁移）下无必要；② 放"检索策略"区块内——014 明确"新增菜单"，独立区块。

## R13. prompt 溯源属性实现（FR-001，决策10）

- **Decision**: `tracing.py` 新增常量 `ATTR_PROMPT_NAME="prompt.name"` / `ATTR_PROMPT_VERSION="prompt.version"` / `ATTR_PROMPT_PURPOSE="prompt.purpose"` 与助手 `set_prompt_attrs(span, prompt_snapshot, purpose)`。调用点（7 处）：`steps.run_clarify/run_rewrite/run_sufficiency/run_compress/stream_answer`、`planning_reasoning._decision_node`（purpose="planning"，取 `prompts["planning"]`）、`knowledge_tools._rewrite_question/_zip`。属性值直接取自 PromptSnapshot（已含 name/version），无 DB 查询。
- **Rationale**: 决策10明确快照直取；`agent.retrieve.*` 与 `agent.history_retrieve` 不渲染提示词，不加 prompt 属性（014 §1.1"工具内部渲染提示词的检索 span"实指工具内 rewrite/zip 这类渲染提示词的 span）。
- **Alternatives considered**: 在 `llm_client.call_json` 统一注入——需改签名传快照，且 planning/answer 走 chat_completion/stream_chat 不经过 call_json，覆盖不全；步骤侧注入 7 处显式但完整。

## R14. retrieval.chunks 属性与不截断写入（FR-002，决策11）

- **Decision**: `tracing.py` 新增 `ATTR_RETRIEVAL_CHUNKS="retrieval.chunks"` 与助手 `set_retrieval_chunks(span, chunks)`：`span.set_attribute(ATTR_RETRIEVAL_CHUNKS, json.dumps([{chunk_id, score, file_name, content}...], ensure_ascii=False))` **不经 `to_json_attr`**（其 32KB 截断违反决策11）。调用点（3 处）：`quick_qa._retrieve_node`、`reasoning_action._retrieve_node`、`knowledge_tools._search_handler`，在现有 `set_output`（count/chunk_ids 摘要保留）之外追加。前端 `SpanDetail.vue` 仿照 agent.input/output 增加"检索片段（retrieval.chunks）"美化 JSON 折叠面板。
- **Rationale**: OTel SDK 默认无属性长度上限（未设 OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT），BatchSpanProcessor→Collector→ES 链路现有配置可承载大属性；单轮检索 topk≤100、片段均长数百字，量级可控。trace 查询侧 `convert_spans` 对 tags 原样透传（已确认 test_trace_query 模式），后端查询无需改动。
- **Alternatives considered**: ① 提高 to_json_attr 上限——影响 agent.input/output 既有 32KB 约定；② 分片多属性——前端拼装复杂，无必要。

## R15. PLANNING_PROTOCOL 强化与警告检测（FR-015/016/017）

- **Decision**:
  - 协议文案追加（保持既有内容，追加约束）：计划与所有工具操作**必须通过 function calling（tool_calls 字段）**发起；**严禁**在 content 中输出 `<createPlan>`、`<updatePlan>`、`<tool_call>` 等计划/调用标记文本或 JSON 计划体；content 仅用于自然语言说明。
  - 检测：`_decision_node` 中 `not tool_calls` 分支内，正则匹配 content：`<createPlan>|<updatePlan>` 或 `<tool_call>[\s\S]*?(createPlan|updatePlan)`。命中则 `tracing.add_event(span, "plan_text_not_tool_call", {loop, content_excerpt})`（excerpt 取前 500 字符），并 `rt.events.append(...)` 随 meta 落库（与 forced_convergence 同模式，便于前端终态感知）。收敛行为不变（仍 converged=True）。
  - `tracing.py` 增常量 `EVENT_PLAN_TEXT_NOT_TOOL_CALL`。
- **Rationale**: 两种问题形态（014 §3.1 示例一 XML、示例二 tool_call 标签包裹 JSON）均被正则覆盖；不做任何服务端解析/补救执行（决策1）；事件双写 span+rt.events 复用 `_record_convergence` 既有模式。
- **Alternatives considered**: ① 服务端解析 XML 并代为执行——决策1明确否决；② 检测到即强制模型重试——改变收敛判定，违反 FR-016。

---

## 决策覆盖核对

| 来源待澄清项 | 解决决策 |
|---|---|
| 014 §0.3 ES 索引名/mapping/分词器/维度 | R1、R2、R7（contracts/history-qa-es.md 细化） |
| 014 §0.3 相关度阈值 | R4（不设阈值） |
| 014 §0.3 异步写入载体与重试 | R5（asyncio task，不重试） |
| 014 §0.3 菜单位置与校验文案 | R12（检索策略后，history 区块） |
| spec Assumptions 混合检索口径 | R3（script_score + RRF，同现有口径） |
| 3 秒超时如何覆盖 embedding | R10（wait_for 整体限时） |
| 组装历史如何参与预算 | R11 |
| 每请求一次/循环复用 | R8、R9 |
| 换向量模型容错 | R1（dims 分索引天然隔离） |

**结论**: 无遗留 NEEDS CLARIFICATION，可进入 Phase 1。