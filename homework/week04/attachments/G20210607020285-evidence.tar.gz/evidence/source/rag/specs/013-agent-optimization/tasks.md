---

description: "Task list for 013-agent-optimization"
---

# Tasks: 智能体运行优化（Trace 增强 / 会话历史检索 / 规划推理工具调用）

**Input**: Design documents from `/specs/013-agent-optimization/`

**Prerequisites**: plan.md、spec.md、research.md（R1–R15）、data-model.md、contracts/（history-qa-es.md、agent-optimization-api.md）、quickstart.md

**Tests**: 包含测试任务——spec 各 User Story 均定义 Independent Test，quickstart.md §1 明确要求 pytest 覆盖与零回归（项目既有惯例：mock ES/网关，test 环境 tracing.enabled=false 走 NoOp Tracer）。

**Organization**: 按 User Story 分组；US1/US2 同属历史检索链路（US2 是 US1 的降级加固），US3/US4 完全独立。

## Format: `[ID] [P?] [Story] Description`

- **[P]**: 可并行（不同文件、无未完成依赖）
- **[Story]**: US1–US4，对应 spec.md 用户故事
- 路径均为仓库根相对路径；后端 `KnowledgeManage/`，前端 `frontend/`

## Path Conventions

- Web 应用单仓库：后端 `KnowledgeManage/app/`、测试 `KnowledgeManage/tests/`；前端 `frontend/src/`
- Python 解释器：`/Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python`

---

## Phase 1: Setup（共享配置）

**Purpose**: 新增服务端配置项，无新依赖、无 PG 迁移

- [X] T001 在 `KnowledgeManage/app/core/config.py` 的 AgentRuntimeConfig 新增 `history_retrieve_timeout: float = 3`（秒，历史检索整体超时，research R10）；同步在 `KnowledgeManage/config.dev.yaml`、`config.prod.yaml`、`config.test.yaml` 的 agent_runtime 段追加 `history_retrieve_timeout: 3`；验证三环境 Settings 加载成功

---

## Phase 2: Foundational（阻塞性前置）

**Purpose**: trace 常量与助手为 US1–US4 共用，必须先完成

**⚠️ CRITICAL**: 本阶段完成前任何 User Story 不得开工

- [X] T002 [P] 在 `KnowledgeManage/app/services/agent_runtime/tracing.py` 新增：属性常量 `ATTR_PROMPT_NAME="prompt.name"`、`ATTR_PROMPT_VERSION="prompt.version"`、`ATTR_PROMPT_PURPOSE="prompt.purpose"`、`ATTR_RETRIEVAL_CHUNKS="retrieval.chunks"`；事件常量 `EVENT_PLAN_TEXT_NOT_TOOL_CALL="plan_text_not_tool_call"`、`EVENT_HISTORY_RETRIEVE_DEGRADED="history_retrieve_degraded"`、`EVENT_HISTORY_INDEX_FAILED="history_index_failed"`；助手 `set_prompt_attrs(span, prompt_snapshot, purpose)`（取 PromptSnapshot.name/version，data-model §4.1）与 `set_retrieval_chunks(span, chunks)`（JSON 数组 `[{chunk_id, score, file_name, content}]`，**直接 span.set_attribute，不经 to_json_attr 的 32KB 截断**，research R14）；更新 `__all__`

**Checkpoint**: 基础就绪——US1、US3、US4 可并行开工（US2 需待 US1 服务模块建立）

---

## Phase 3: User Story 1 - 长会话下澄清/重写命中相关历史 (Priority: P1) 🎯 MVP

**Goal**: 完整问答轮次写入 ES；提问后、澄清前执行一次历史混合检索，以"最近 2 个完整问答轮原文 + ES 命中轮次"组装澄清/重写专用历史；配置页新增"历史信息检索"菜单（仅检索召回数）。

**Independent Test**: 构造超过 10 轮会话（早期讨论产品 A），提问"A 的保修期多久"→ 澄清判清晰、组装历史含早期轮次、答案引用早期背景；ES 中每轮一文档（quickstart 场景 A/B）。

### Tests for User Story 1 ⚠️（先写先失败）

- [X] T003 [P] [US1] 在 `KnowledgeManage/tests/test_agents.py` 新增配置用例：config 缺 history_retrieval 时默认 `{top_k: 10}` 生效；top_k 越界（0、101、非整数）保存返回 400；三类智能体保存后均保留该键；传入 mode/enabled 等未知子键被忽略（contracts/agent-optimization-api §1.1）
- [X] T004 [P] [US1] 新建 `KnowledgeManage/tests/test_history_qa.py`（mock ES client 与 embedding_service）：写入用例——文档含 chat_id/user_id/question/answer/qa_text/created_at/embedding_model/embedding_model_id/embeddings 全字段、向量化对象为 `question + "\n" + answer` 拼接文本、`_id`=assistant 消息 id 幂等覆盖、索引名 `chat_history_qa_{dims}` 按实际向量维度选择；检索用例——query 为用户原问题、两路均带 term chat_id 过滤、topk 取快照 history_top_k、RRF 融合口径（k=settings.agent_runtime.rrf_k）；组装用例——最近 2 个完整问答轮保底、按 question 原文去重、剔除当前问题、ES 命中 created_at 升序在前保底 2 轮在后、落单 user 消息不算完整轮（contracts/history-qa-es §2/§3，data-model §1/§3）
- [X] T005 [P] [US1] 在 `KnowledgeManage/tests/test_agent_flows.py` 新增流程用例：StepEvent `history_retrieve` start/end 先于 clarify 且每请求恰好一次（三类智能体各验一次）；clarify/rewrite（含推理行动循环后续重写、rewriteQuestion 工具）渲染组装历史且循环复用同一份不重复检索；stream_answer 与 planning `_init_messages` 仍渲染最近 10 轮 state.history（FR-009 替换范围）；组装历史超预算时从头部逐轮淘汰、保底 2 轮最后触及（FR-011，research R11）

### Implementation for User Story 1

- [X] T006 [P] [US1] 在 `KnowledgeManage/app/schemas/agent.py` 新增 `HistoryRetrievalConfig(BaseModel)`：`top_k: int = Field(10, ge=1, le=100)`，`model_config = ConfigDict(extra="ignore")`；AgentConfig 增 `history_retrieval: HistoryRetrievalConfig = Field(default_factory=HistoryRetrievalConfig)`（存量缺键默认兜底，零迁移，research R12）
- [X] T007 [US1] 在 `KnowledgeManage/app/services/agent_service.py` 的 update_agent：三类智能体均保留 history_retrieval 键（不做类型裁剪）；缺省时以 Pydantic 默认值落库；范围校验由 schema 承担（沿用手动 model_validate 捕获转 400 模式）
- [X] T008 [P] [US1] 在 `KnowledgeManage/app/services/agent_runtime/state.py`：AgentConfigSnapshot 增 `history_top_k: int = 10`，RequestRuntimeState 增 `clarify_history: Optional[List[dict]] = None`（None=降级/未组装语义，data-model §3）；在 `KnowledgeManage/app/services/agent_runtime/snapshot.py` 的 build_snapshot 冻结 `history_top_k=config.history_retrieval.top_k`（有默认值恒合法，不新增预检失败项）
- [X] T009 [P] [US1] 在 `KnowledgeManage/app/core/es_client.py` 新增 `ensure_history_index(dims: int) -> str`：索引名 `chat_history_qa_{dims}`，mapping 按 contracts/history-qa-es §1（question/answer/qa_text 用 ik_max_word 索引 + ik_smart 查询，chat_id/user_id/embedding_model/embedding_model_id 为 keyword，created_at 为 date，embeddings 为 dense_vector dims）；存在即返回，模式对齐现有 ensure_index
- [X] T010 [US1] 新建 `KnowledgeManage/app/services/history_qa_service.py` 实现 `index_qa_round(*, chat_id, user_id, question, answer, message_id, embedding_model_id, trace_id)`：generate_embeddings 拼接文本向量化 → ensure_history_index(len(vector)) → index API 覆盖写（_id=message_id，默认 refresh 不用 wait_for）；成功建独立 span `agent.history_index`（属性 chat.id/session.id/origin.trace_id，agent.output={index, doc_id}）；失败隔离在 US2 T023 加固（依赖 T002/T009）
- [X] T011 [US1] 在 `KnowledgeManage/app/services/history_qa_service.py` 实现 `retrieve_and_assemble(state, emit)` 主链路：query 原问题向量化 → 按向量维度选索引（ignore_unavailable=True）→ BM25(match qa_text) + script_score(cosineSimilarity+1.0) 两路均带 term chat_id → Python RRF（k=settings.agent_runtime.rrf_k）截断 topk → 组装（保底 2 完整轮 + ES 命中去重/时间序/剔除当前问题，算法见 data-model §3）→ 组装后按 clarify/rewrite 提示词固定开销做头部逐轮预算裁剪（research R11）→ 写 state.clarify_history；发 StepEvent history_retrieve start/end、建 span `agent.history_retrieve`（agent.input={query, chat_id, top_k}，agent.output={count, round_ids, degraded}）；超时/降级事件在 US2 T022 加固（依赖 T008/T009/T010）
- [X] T012 [US1] 在 `KnowledgeManage/app/schemas/agent_runtime.py` 的 StepName Literal 增加 `"history_retrieve"`（contracts/agent-optimization-api §2）
- [X] T013 [US1] 在 `KnowledgeManage/app/services/agent_runtime/__init__.py` 的 run_agent_generation：state 构建后、`_get_runner` 分发前调用 `history_qa_service.retrieve_and_assemble(state, emit)`（每请求一次，三个 langgraph 图零改动，research R8）；成功返回值新增顶层键 `embedding_model_id`（取 snapshot.embedding_model.model_id，**不进 meta**，供写入触发用，research R5）
- [X] T014 [US1] 在 `KnowledgeManage/app/services/agent_runtime/steps.py` 新增 `clarify_history_text(state)`（clarify_history 非 None 渲染组装历史，None 回退 history_text）；run_clarify/run_rewrite 的 history 占位符改用该助手；`KnowledgeManage/app/services/agent_runtime/tools/knowledge_tools.py` 的 `_rewrite_question` 同步改用；**stream_answer 与 planning _init_messages 保持 history_text 不动**（FR-009，contracts/history-qa-es §4）
- [X] T015 [US1] 在 `KnowledgeManage/app/services/agent_runtime/budget.py` 的 enforce_budget：clarify_history 非 None 时按相同"先历史后片段"顺序对其头部逐条裁剪，返回报告新增 `dropped_clarify_history` 计数（随 context_evicted 事件下发，research R11）
- [X] T016 [US1] 在 `KnowledgeManage/app/services/chat_service.py` 的 `_run_agent_generation`：`_finalize_agent_generation` 返回 finalized=True 且非 cancelled、error_event 为 None、content 非空时，`asyncio.create_task(history_qa_service.index_qa_round(...))` 异步写入（question/answer/message_id/trace_id/embedding_model_id 取自本轮结果；clarify_failed/empty_retrieval 的 done 轮次照常写入，取消/报错/停止不触发，research R5/R6）
- [X] T017 [P] [US1] 在 `frontend/src/utils/agent.js`：MENU_SECTIONS 增 `history: '历史信息检索'`；MENU_SECTIONS_BY_TYPE 三类均在 retrieval 后插入 history；getDefaultConfig 增 `history_retrieval: { top_k: 10 }`；validateAgentDraft 增校验（`Number.isInteger && 1–100`，文案"检索召回数须为 1–100 的整数"，section=history）
- [X] T018 [US1] 新建 `frontend/src/components/agent/sections/HistorySection.vue`（仅"检索召回数"a-input-number，min=1/max=100/默认 10，说明文案"检索模式固定为混合检索（关键词+向量），无需选择"，风格对齐 RetrievalSection.vue）；在 `frontend/src/components/agent/AgentEditModal.vue` 挂载该区块（菜单 key=history，位于检索策略后）；打开编辑弹窗时存量缺省 config 以默认值补齐草稿（依赖 T017）
- [X] T019 [P] [US1] 在 `frontend/src/components/chat/ChatArea.vue` 的 STEP_LABELS 增加 `history_retrieve: '历史信息检索'`

**Checkpoint**: US1 独立可验——quickstart 场景 A/B 通过；长会话指代解析生效，配置菜单可用（此时 ES 故障容错尚未加固，属 US2）

---

## Phase 4: User Story 2 - 历史检索不可用时无损降级 (Priority: P1)

**Goal**: 历史检索超时（>3s）/ES 异常/embedding 失败/零命中时回退最近 10 轮机制，流程 100% 继续并记降级事件；ES 写入失败仅日志+trace，不影响已完成问答。

**Independent Test**: 模拟超时/异常/零命中三种情形，问答正常完成、历史回退最近 10 轮、trace 含 `history_retrieve_degraded`；写入失败仅日志（quickstart 场景 C/F）。

**依赖**: US1 的 history_qa_service.py 与入口接线（同文件加固，不可与 US1 并行）

### Tests for User Story 2 ⚠️（先写先失败）

- [X] T020 [P] [US2] 在 `KnowledgeManage/tests/test_history_qa.py` 新增降级用例：检索协程耗时超过 history_retrieve_timeout → wait_for 超时、clarify_history 保持 None、span 记 history_retrieve_degraded(reason=timeout)；ES 抛 ApiError/TransportError → reason=unavailable；embedding 失败 → reason=embedding_failed；零命中 → reason=empty_result；任意异常 → reason=error 且不上抛；写入失败（ES 异常/embedding 异常）→ 仅 logger.warning + agent.history_index span 记 history_index_failed，不重试不上抛（contracts/history-qa-es §2/§3）
- [X] T021 [P] [US2] 在 `KnowledgeManage/tests/test_agent_flows.py` 新增流程级用例：历史检索降级时三类智能体问答仍完整走通（clarify 渲染最近 10 轮回退历史）、降级时 StepEvent end 携带 message="历史检索降级，使用最近历史"；cancelled/error 终态不触发 index_qa_round（SC-005）

### Implementation for User Story 2

- [X] T022 [US2] 在 `KnowledgeManage/app/services/history_qa_service.py` 的 retrieve_and_assemble：以 `asyncio.wait_for(..., settings.agent_runtime.history_retrieve_timeout)` 包裹**向量化+两路 ES 召回+RRF 全程**（research R10）；捕获 TimeoutError/RetrievalUnavailableError/EmbeddingFailedError/Exception 分类记 `history_retrieve_degraded` 事件（reason=timeout/unavailable/embedding_failed/empty_result/error），clarify_history 保持 None 流程继续；降级时 StepEvent end 携带降级 message；span agent.output 带 degraded=true
- [X] T023 [US2] 在 `KnowledgeManage/app/services/history_qa_service.py` 的 index_qa_round：捕获一切异常仅 `logger.warning` + `agent.history_index` span 记 `history_index_failed`（error=异常摘要），不重试不上抛（FR-013）；确认 chat_service 侧 create_task 火忘式不 await、任务异常绝不传播到主流程（依赖 T022，同文件顺序执行）

**Checkpoint**: US1+US2 独立可验——quickstart 场景 C/F 通过；ES 停机问答无损，SC-002/SC-005 达成

---

## Phase 5: User Story 3 - 规划推理正确发起工具调用 (Priority: P2)

**Goal**: 强化 PLANNING_PROTOCOL 强制 function calling、禁止 content 输出计划文本；收敛判定不变；不合规输出记 `plan_text_not_tool_call` 警告事件。

**Independent Test**: 规划推理提问需检索问题 → trace 出现 createPlan 与检索 tool_calls、答案基于检索结果；对不遵循模型 → 警告事件 100% 记录且仍收敛进答案生成（quickstart 场景 D）。

**依赖**: 仅 Foundational T002；与 US1/US2 完全独立（不同文件）

### Tests for User Story 3 ⚠️（先写先失败）

- [X] T024 [P] [US3] 在 `KnowledgeManage/tests/test_agent_flows.py` 新增规划推理用例：mock 决策输出无 tool_calls 且 content 含 createPlan/updatePlan 的 XML 开标签形态（014 §3.1 示例一）→ span 记 plan_text_not_tool_call（属性 loop/content_excerpt 前 500 字符）且 rt.events 含同名项、仍收敛进答案生成；content 含 tool_call 开标签后跟 createPlan 的包裹 JSON 形态（示例二）→ 同样触发；正常 tool_calls 输出 → 不产生该事件；纯文本无计划标记 → 不产生该事件；PLANNING_PROTOCOL 文案含 function calling 强制与禁止 content 计划标记约束（FR-015/016/017）

### Implementation for User Story 3

- [X] T025 [US3] 在 `KnowledgeManage/app/services/agent_runtime/flows/planning_reasoning.py`：PLANNING_PROTOCOL 追加约束（计划与工具操作必须经 tool_calls 字段发起；严禁在 content 输出 createPlan/updatePlan 的 XML 标记、tool_call 标记或 JSON 计划体；content 仅自然语言说明；保留既有文案与收敛口径）；`_decision_node` 的 `not tool_calls` 分支内正则检测两种形态（XML 开标签 / tool_call 开标签后出现 createPlan/updatePlan），命中则 `tracing.add_event(span, EVENT_PLAN_TEXT_NOT_TOOL_CALL, {loop, content_excerpt})` 并 rt.events.append 同名项；**不做服务端解析、不改收敛判定**（research R15）

**Checkpoint**: US3 独立可验——quickstart 场景 D 通过，SC-003 达成

---

## Phase 6: User Story 4 - 排查问答质量的轨迹增强 (Priority: P3)

**Goal**: 所有渲染提示词的 span 含 prompt.name/version/purpose；检索 span 含 retrieval.chunks 片段全文（不截断）；前端抽屉按现有方式呈现。

**Independent Test**: 完成一次问答打开 trace 抽屉，各步骤节点显示提示词名称/版本/用途，检索节点显示片段全文列表（含 >32KB 不截断验证，quickstart 场景 E）。

**依赖**: 仅 Foundational T002；与 US1/US2 共用 steps.py/knowledge_tools.py 文件但改不同函数——若与 US1 并行需注意同文件冲突，建议 US1 后执行

### Tests for User Story 4 ⚠️（先写先失败）

- [X] T026 [P] [US4] 在 `KnowledgeManage/tests/test_agent_flows.py` 与 `KnowledgeManage/tests/test_tool_runtime.py` 新增 trace 用例（用 InMemorySpanExporter 或 mock span 断言属性）：clarify/rewrite/compress/sufficiency/answer/plan_decision 及工具内 rewrite/zip span 均含 prompt.name/version/purpose 且值取自快照；quick_qa/reasoning_action 主流程与 knowledge_tools 检索 span 均含 retrieval.chunks（JSON 数组元素含 chunk_id/score/file_name/content）；构造 >32KB 片段验证 content 不截断、无"…[截断]"后缀；空命中写空数组；既有 agent.output 摘要保留（FR-001/002，contracts/agent-optimization-api §3.1/§3.2）

### Implementation for User Story 4

- [X] T027 [US4] 在 `KnowledgeManage/app/services/agent_runtime/steps.py` 的 run_clarify/run_rewrite/run_sufficiency/run_compress/stream_answer 五处 span 创建后调用 `tracing.set_prompt_attrs(span, state.snapshot.prompts[purpose], purpose)`（answer 步 purpose="answer"）
- [X] T028 [US4] 在 `KnowledgeManage/app/services/agent_runtime/flows/planning_reasoning.py` 的 `_decision_node` span 上调用 set_prompt_attrs（取 prompts["planning"]，purpose="planning"）
- [X] T029 [US4] 在 `KnowledgeManage/app/services/agent_runtime/tools/knowledge_tools.py`：`_rewrite_question`/`_zip` span 调用 set_prompt_attrs（purpose=rewrite/compress）；`_search_handler` 在既有 set_output 外追加 `tracing.set_retrieval_chunks(span, hits)`
- [X] T030 [US4] 在 `KnowledgeManage/app/services/agent_runtime/flows/quick_qa.py` 与 `KnowledgeManage/app/services/agent_runtime/flows/reasoning_action.py` 的 `_retrieve_node`：既有 set_output 外追加 `tracing.set_retrieval_chunks(span, hits)`（空命中写空数组）
- [X] T031 [P] [US4] 在 `frontend/src/components/trace/SpanDetail.vue` 仿照 agent.input/output 增加"检索片段（retrieval.chunks）"美化 JSON 折叠面板（prettyJson + a-collapse-panel，默认展开逻辑与现有一致）；prompt.* 属性走既有 Tags 表格无需改动

**Checkpoint**: 全部 User Story 独立可验——quickstart 场景 E 通过，SC-004 达成

---

## Phase 7: Polish & Cross-Cutting Concerns

- [X] T032 [P] 将规划阶段决策回填 `mySpecs/014.agent优化.md` §0.3（四项待澄清事项标注"已在 specs/013-agent-optimization/research.md R1/R2/R4/R5/R12 解决"及结论摘要，保持既有章节编号风格）
- [X] T033 全量回归：`cd KnowledgeManage && /Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python -m pytest tests/ -q` 全部通过（既有 223+ 用例零回归）；`cd frontend && npm run build` 构建成功
- [ ] T034 按 `specs/013-agent-optimization/quickstart.md` §2 执行手工场景 A–F 端到端验证（需 ES 8.17.0 + analysis-ik 插件、LlmGateway、Collector 运行），核对 §3 验证通过标准

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: 无依赖，立即可做
- **Foundational (Phase 2)**: 依赖 Setup；**阻塞所有 User Story**（T002 trace 助手为四个故事共用）
- **US1 (Phase 3)**: 依赖 Foundational
- **US2 (Phase 4)**: 依赖 **US1**（同文件 history_qa_service.py 加固，非独立并行故事）
- **US3 (Phase 5)**: 仅依赖 Foundational——可与 US1 并行（planning_reasoning.py 与 US1 无文件交集）
- **US4 (Phase 6)**: 仅依赖 Foundational——逻辑独立，但 steps.py/knowledge_tools.py 与 US1 同文件不同函数，建议 US1 完成后执行避免编辑冲突
- **Polish (Phase 7)**: 依赖全部故事完成

### Within Each User Story

- 测试先写并确认失败 → schema/模型 → 服务 → 入口接线 → 前端
- US1 内部关键链：T006/T008/T009（可并行）→ T010 → T011 → T013；T014/T015/T016 依赖 T011；T018 依赖 T017
- 同文件任务顺序执行：T010→T011→T022→T023（history_qa_service.py）；T005→T021→T024→T026（test_agent_flows.py）

### Parallel Opportunities

- Phase 2 后：US1 与 US3 可并行（不同文件）
- US1 内：T003/T004/T005 测试并行；T006/T008/T009 实现并行；T017/T019 前端并行
- US2 内：T020/T021 测试并行
- US4 内：T027/T028/T029/T030 各改不同文件可并行（T029/T030 依赖 T002 助手即可）；T031 前端独立并行

---

## Parallel Example: User Story 1

```bash
# 测试先行（三个不同测试文件）：
Task: "T003 配置校验用例 tests/test_agents.py"
Task: "T004 写入/检索/组装用例 tests/test_history_qa.py"
Task: "T005 流程集成用例 tests/test_agent_flows.py"

# 实现层并行（三个不同源文件）：
Task: "T006 HistoryRetrievalConfig schemas/agent.py"
Task: "T008 快照/运行态字段 state.py + snapshot.py"
Task: "T009 ensure_history_index core/es_client.py"
```

---

## Implementation Strategy

### MVP First（US1 = Phase 1+2+3）

1. T001 Setup → T002 Foundational
2. US1 全部任务（T003–T019）
3. **STOP & VALIDATE**: quickstart 场景 A/B——长会话指代解析 + 配置菜单
4. 注意：MVP 阶段 ES 故障容错未加固（US2），生产演示前建议连同 US2 一起交付（两者同为 P1）

### Incremental Delivery

1. Setup + Foundational → 基础就绪
2. US1 → 独立验证（MVP）
3. US2 → 降级加固验证（场景 C/F）→ **历史检索链路完整交付**
4. US3 → 规划推理修复验证（场景 D）
5. US4 → trace 增强验证（场景 E）
6. Polish：全量回归 + 文档回填 + A–F 全场景

### Parallel Team Strategy

- 开发者 A：US1 → US2（历史检索链路，同文件串行）
- 开发者 B：US3（独立）→ US4（待 A 的 steps.py/knowledge_tools.py 改动合入后）

---

## Notes

- 无新依赖、无 Alembic 迁移（config JSON 键由 Pydantic 默认兜底）；ES 需 analysis-ik 插件（开发环境已确认）
- 所有测试 mock ES/网关，test 环境 tracing.enabled=false（NoOp Tracer）；trace 属性断言用 mock span 或 InMemorySpanExporter
- 计划标记检测/协议文案中的 XML 标签形态以 014 §3.1 两个示例为准（XML 开标签形态、tool_call 开标签包裹 JSON 形态）
- 每任务或逻辑组完成后提交；任一 Checkpoint 可停下独立验证