# Quickstart: 资源消耗监控验证指南

**Feature**: 015-resource-consumption-monitor | **契约**: [contracts/consumption-api.md](./contracts/consumption-api.md) | **数据模型**: [data-model.md](./data-model.md)

## 前置条件

1. Prometheus 已运行于 `http://localhost:9091`，且抓取 LlmGateway `http://127.0.0.1:8003/metrics`（`up{job=...}` 可查）
2. LlmGateway（8003）、UserManage（8001）、KnowledgeManage（8002）已启动
3. 已通过网关产生若干调用（指标含 `llm_tokens_total` / `llm_cost_estimate`，带 user_email/model 标签）
4. KnowledgeManage `config.dev.yaml` 已含 `prometheus: {url: http://localhost:9091, timeout: 10, retention_days: 15}`
5. 前端 `npm install`（含新增 echarts 依赖）

## 场景 1：后端单元测试（不依赖活体服务）

```bash
cd KnowledgeManage
/Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python -m pytest tests/test_consumption.py -v
```

**预期覆盖**（mock Prometheus HTTP 与 UserManage 解析，沿用 patch decode_token 模式）：
- 权限：普通用户查他人 / all_monthly → 403；管理员放行（FR-003/004，SC-002）
- 口径：PromQL 含 `type!="cached"` 与 `sum by (model)`；费用无 type 过滤（FR-010）
- 时间：当前月桶数=今天日期、末桶 window<86400；历史月桶数=当月天数；未来期间 → 400（FR-012/018）
- 补 0：无数据桶 values=0 且与 buckets 等长（FR-014）
- 保留期：整体早于 now-retention_days → out_of_retention=true（FR-017）
- 故障：Prometheus 连接失败 → 502；email 解析失败 → 502（FR-017）
- 精度：cost values round 6 位（FR-015）

## 场景 2：接口手工验证

```bash
# 登录取 token（UserManage）
TOKEN=$(curl -s -X POST http://localhost:8001/api/user/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"uid":"admin","password":"[REDACTED]"

# 选项
curl -s http://localhost:8002/api/knowledge/consumption/options -H "Authorization: Bearer $TOKEN"

# 本人当月每日 token（默认视图）
curl -s "http://localhost:8002/api/knowledge/consumption/series?metric=tokens&scope=user_daily&user_email=admin@example.com&month=2026-11" \
  -H "Authorization: Bearer $TOKEN"

# 所有人月费用（仅管理员）
curl -s "http://localhost:8002/api/knowledge/consumption/series?metric=cost&scope=all_monthly&year=2026" \
  -H "Authorization: Bearer $TOKEN"
```

**预期**：
- options 返回非空 user_emails/models（与 Prometheus label values 一致，无空串）
- user_daily 当月 buckets 截至今天、无未来日；无数据日为 0；values 与 Prometheus 手算 increase 一致（SC-003）
- all_monthly 普通用户 token 请求 → 403
- 与 Grafana/Prometheus 控制台同口径抽查误差为 0（SC-003）

## 场景 3：前端端到端

```bash
cd frontend && npm run dev   # http://localhost:5173
```

登录后验证（对应 spec 验收场景）：

| 步骤 | 预期 |
|------|------|
| 侧边栏出现"资源消耗监控"（与智能体同级） | 点击进入，默认本人/全部模型/当前月，≤5s 出图（SC-001） |
| 普通用户查看页面 | user_email 固定本人；无"所有人月"子视图 |
| 切换上月 + 点查询 | 完整自然月曲线，无数据日补 0 连续（SC-006） |
| 切人月子视图选当前年 | X 轴 1 月至本月，无未来月；选择器未来期间禁用 |
| 清空模型多选 + 查询 | 等同全选 |
| 点击图例某模型 | 该曲线隐藏/恢复 |
| 切费用 Tab | Y 轴元、tooltip 6 位小数；0.000123 类小额可读（SC-005） |
| 管理员任选用户 / 所有人月 | 正常展示；管理员 1 分钟内可定位年度最高消耗模型（SC-004） |
| 停 Prometheus 后查询 | 错误提示，其他页面不受影响 |
| 查询很早的历史月份 | 提示"超出数据保留期" |

## 场景 4：构建回归

```bash
cd frontend && npm run build
cd ../KnowledgeManage && /Volumes/MySSD/software/miniconda3/envs/myAiEnvNew/bin/python -m pytest tests/ -q
```

**预期**：构建通过；既有测试无回归（新增模块不改动既有行为）。