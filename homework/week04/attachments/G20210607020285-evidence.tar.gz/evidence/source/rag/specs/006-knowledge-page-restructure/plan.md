# Implementation Plan: 知识库管理页面重组

**Branch**: `006-knowledge-page-restructure` | **Date**: 2026-11-16 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/006-knowledge-page-restructure/spec.md`

## Summary

将前端 `frontend/` 项目中顶部导航"AI→会话管理"重命名为"AI→知识库管理"，并在知识库平台区域引入左侧边栏（标题"知识库平台"），包含"新会话"、"知识库"、"智能体"三个子菜单。现有 `ChatManagement.vue` 保留为"新会话"页面，新增 `KnowledgeManagement.vue` 和 `AgentManagement.vue` 两个占位页面。布局参考 `MyKnowlegeWebDemo/src/components/layout/AppLayout.vue` 中的侧边栏实现。

## Technical Context

**Language/Version**: JavaScript (ES Module), Vue 3.5.x

**Primary Dependencies**: Vue Router 4.6, Pinia 2.3, Ant Design Vue 4.2, @ant-design/icons-vue 7.0

**Storage**: N/A（纯前端导航重组，无数据模型变更）

**Testing**: 手动验证（当前项目无前端自动化测试框架）

**Target Platform**: 浏览器（macOS/Windows 现代浏览器）

**Project Type**: Web 前端应用（开发者门户）

**Performance Goals**: 页面切换响应时间 ≤ 正常 SPA 路由导航时间（<100ms）

**Constraints**: 现有聊天功能（ChatManagement）零回归

**Scale/Scope**: 修改 2 个现有文件 + 新增 2 个 Vue 组件 + 修改路由配置

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution 文件尚为模板状态，未定义项目级约束原则。无 Gate 违规。

## Project Structure

### Documentation (this feature)

```text
specs/006-knowledge-page-restructure/
├── plan.md              # 本文件
├── research.md          # Phase 0 研究产物
├── data-model.md        # Phase 1 数据模型（导航结构）
├── quickstart.md        # Phase 1 验证指南
└── tasks.md             # Phase 2 任务清单（由 /speckit-tasks 生成）
```

### Source Code (repository root)

```text
frontend/
├── src/
│   ├── components/
│   │   └── layout/
│   │       └── AppLayout.vue          # 修改：顶部菜单重命名 + 侧边栏条件渲染
│   ├── views/
│   │   ├── ChatManagement.vue         # 不变（功能保留，仅作为"新会话"子路由）
│   │   ├── KnowledgeManagement.vue    # 新增：知识库占位页面
│   │   └── AgentManagement.vue        # 新增：智能体占位页面
│   └── router/
│       └── index.js                   # 修改：新增 /knowledge 和 /agent 路由
└── package.json                       # 不变
```

**Structure Decision**: 单前端项目（`frontend/`），变更集中在布局组件、视图组件和路由配置三层。
