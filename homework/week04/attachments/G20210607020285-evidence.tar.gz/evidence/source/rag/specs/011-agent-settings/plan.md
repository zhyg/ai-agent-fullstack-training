# Implementation Plan: 智能体菜单功能完善（智能体配置管理）

**Branch**: `011-agent-settings` | **Date**: 2026-11-22 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/011-agent-settings/spec.md`（源 PRD：`mySpecs/012.agent设置.md`）

## Summary

在智能体菜单页以卡片展示三个系统预置智能体（快速问答/推理行动/规划推理），支持管理员编辑配置（基础信息、提示词、检索策略、模型配置、循环次数、工具配置）与停用/启用，普通用户只读。后端在 KnowledgeManage 新增 `agents` 表（JSONB 配置列）与 REST 接口，预置数据经 Alembic 数据迁移注入；前端替换 AgentManagement 占位页，新增卡片组件与左菜单右配置区的编辑弹窗，提示词/模型下拉复用现有提示词管理与模型管理数据源。本期不实现智能体运行流程、不修改会话页面。

## Technical Context

**Language/Version**: Python 3.11（后端）；JavaScript（前端 Vue 3 SFC，Node 26 构建）

**Primary Dependencies**: 后端 FastAPI、SQLAlchemy（Column 声明式）、Alembic、Pydantic v2、PyJWT；前端 Vue 3、Ant Design Vue 4.x、Pinia、axios、@ant-design/icons-vue

**Storage**: PostgreSQL（schema `knowledge_manage`，新增 `agents` 表，配置存 JSONB）；提示词引用同库 `prompts` 表；模型引用跨服务指向 LlmGateway 模型配置（仅存标识，不建外键）

**Testing**: pytest（`KnowledgeManage/tests/`，沿用现有测试约定）；前端以 quickstart.md 手动验收场景为主

**Target Platform**: Linux/macOS 开发服务器（KnowledgeManage :8002）+ 现代浏览器（frontend Vite dev server）

**Project Type**: Web application（微服务后端 + SPA 前端）

**Performance Goals**: 智能体列表/详情/保存接口 p95 < 500ms（本地环境）；编辑弹窗打开到可交互 < 1s

**Constraints**: 本期不实现智能体运行流程；不修改会话页面；提示词管理零改动；写操作（编辑保存/停用/启用）仅管理员（权限键 `permission_manage`）；并发编辑最后保存者为准

**Scale/Scope**: 3 个预置智能体（固定数量、不可新建/删除）；管理员个位数；提示词/模型下拉选项量级 ≤ 数百条

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

`.specify/memory/constitution.md` 为未批准的空模板（仅占位符），无生效原则与治理约束 → **PASS**（无约束可违反）。

Post-Phase 1 复查：设计沿用现有微服务边界（后端仅 KnowledgeManage）、现有存储类型（PostgreSQL）、现有迁移约定（Alembic）、现有权限模型（permission_manage），未引入新服务/新存储/新框架 → **PASS**。

## Project Structure

### Documentation (this feature)

```text
specs/011-agent-settings/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
│   └── agent-api.md
├── checklists/
│   └── requirements.md
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
KnowledgeManage/
├── app/
│   ├── models/agent.py              # 新增：Agent 模型（agents 表，JSONB config）
│   ├── schemas/agent.py             # 新增：AgentResponse/AgentUpdate/StatusUpdate/Config 校验
│   ├── routers/agents.py            # 新增：GET /agents、GET/PUT /agents/{id}、PATCH /agents/{id}/status
│   ├── services/agent_service.py    # 新增：列表/详情/更新/状态切换/名称唯一/引用校验
│   ├── dependencies.py              # 复用：get_current_user、require_permission("permission_manage")
│   └── main.py                      # 修改：注册 agents router
├── alembic/versions/<rev>_add_agents.py   # 新增：建表 + 三条预置数据（幂等）
└── tests/test_agents.py             # 新增：接口与校验测试

frontend/
├── src/
│   ├── services/agentApi.js         # 新增：/api/knowledge/agents CRUD + status
│   ├── stores/agent.js              # 新增：智能体列表/当前编辑态 Pinia store
│   ├── utils/agent.js               # 新增：类型/提示词用途/工具清单/图标库/默认配置常量
│   ├── views/AgentManagement.vue    # 修改：替换占位页为卡片列表
│   └── components/agent/
│       ├── AgentCard.vue            # 新增：卡片 + “...”菜单（编辑/停用/启用，按角色与状态）
│       ├── AgentEditModal.vue       # 新增：a-Modal 左菜单右配置区容器
│       └── sections/                # 新增：BasicInfo/Prompts/Retrieval/Models/Loop/Tools 六个配置区组件
└── (router 不变：/agent 路由已存在，页面级登录守卫沿用；不加 requiresAdmin)
```

**Structure Decision**: 沿用仓库现有微服务布局。后端全部落在 KnowledgeManage（PRD 明确约定），按现有 models/schemas/routers/services 四层组织；前端落在 frontend SPA，按现有 services/stores/views/components 组织，编辑弹窗拆分为容器 + 六个配置区组件以对应左侧菜单。不新建服务、不新建存储。

## Complexity Tracking

无 Constitution 违反，无需记录。