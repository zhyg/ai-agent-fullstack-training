# Quickstart: 知识库中文档管理

**Feature**: 008-knowledge-doc-management  
**Date**: 2026-11-16

## Prerequisites

1. PostgreSQL 运行中，schema `knowledge_manage` 已创建
2. MinIO 运行中（endpoint: `127.0.0.1:9000`），bucket `myknowlege` 已创建
3. Redis 运行中
4. UserManage 服务运行中（JWT 签发）
5. Python 环境: `myAiEnvNew` conda env (Python 3.11)
6. Node.js 环境: v26+ with npm

## Setup

### 后端依赖安装

```bash
cd /Volumes/MySSD/mycode/Ai/myKnowlege/KnowledgeManage
pip install minio
```

### 前端依赖安装

```bash
cd /Volumes/MySSD/mycode/Ai/myKnowlege/frontend
npm install md-editor-v3 @vue-office/docx @vue-office/excel @vue-office/pptx @vue-office/pdf
```

### 数据库迁移

```bash
cd /Volumes/MySSD/mycode/Ai/myKnowlege/KnowledgeManage
alembic revision --autogenerate -m "add_folders_documents"
alembic upgrade head
```

## Validation Scenarios

### Scenario 1: 知识库详情页导航

1. 启动 KnowledgeManage 服务: `uvicorn app.main:app --reload --port 8002`
2. 启动前端: `npm run dev`
3. 登录系统，进入知识库列表页面
4. 点击某个知识库卡片
5. **Expected**: 跳转到知识库详情页，顶部显示返回按钮和知识库名称，左侧显示目录树区域，右侧显示文档列表区域
6. 访问不存在的知识库 ID
7. **Expected**: 显示 404 页面

### Scenario 2: 目录树 CRUD

1. 在知识库详情页，点击"新建根目录"
2. 输入目录名称并确认
3. **Expected**: 目录出现在左侧树中
4. 悬停目录节点，点击"⋯"→"新建目录"，输入子目录名称
5. **Expected**: 子目录出现在父目录下
6. 选择"修改目录名称"，输入新名称
7. **Expected**: 目录名称更新
8. 尝试在同一父目录下创建同名目录
9. **Expected**: 提示"目录下已存在同名子目录"

### Scenario 3: 目录拖拽排序

1. 创建多个根目录 A、B、C
2. 将 C 拖拽到 A 上方
3. **Expected**: 顺序变为 C、A、B
4. 将 A 拖拽到 B 节点上（作为 B 的子目录）
5. **Expected**: A 成为 B 的子目录
6. 尝试将 B 拖拽到 A 下（B 是 A 的祖先）
7. **Expected**: 拒绝操作，提示"不能将目录拖拽到自身或其子孙目录下"

### Scenario 4: 文档上传

1. 选中一个目录
2. 点击"新建知识"按钮
3. 选择一个 .docx 文件（<500MB）
4. 点击确认上传
5. **Expected**: 提示"上传成功，正在解析..."，文档出现在列表中，状态为"解析中"
6. 选择一个超过 500MB 的文件
7. **Expected**: 提示文件大小超出限制
8. 上传一个 .zip 压缩包（包含多个文件和子目录）
9. **Expected**: 系统解压后创建对应的目录结构和多个文档记录

### Scenario 5: 文档列表操作

1. 在有文档的目录下，查看文档列表
2. **Expected**: 表格显示名称、标签、大小、状态、创建时间、更新时间、操作列
3. 点击操作菜单→"新增标签"，输入标签名并确认
4. **Expected**: 标签添加到文档标签列表中
5. 点击标签的关闭按钮并确认
6. **Expected**: 标签被删除
7. 勾选多篇文档，点击"批量删除"
8. **Expected**: 非解析中文档被删除，解析中文档被跳过并提示

### Scenario 6: 文档详情预览

1. 点击文档行打开详情抽屉
2. **Expected**: 抽屉宽度 70vw，展示文档基础信息
3. 查看"原始内容"标签页
4. **Expected**: 根据文件类型选择对应渲染器展示内容
5. 切换到"解析后的 Markdown"标签页
6. **Expected**: 展示模拟 Markdown 内容
7. 切换到"文档分片"标签页
8. **Expected**: 展示模拟分片预览
9. 点击描述区域的编辑按钮，输入描述并保存
10. **Expected**: 描述更新成功并实时显示

## Reference

- Data Model: [data-model.md](./data-model.md)
- Folder API: [contracts/folder-api.md](./contracts/folder-api.md)
- Document API: [contracts/document-api.md](./contracts/document-api.md)
- Research Decisions: [research.md](./research.md)
- Demo Reference: `MyKnowlegeWebDemo/src/views/KnowledgeManagement.vue` 及相关组件
