# LlmGateway API Contract

**Service**: LlmGateway | **Base URL**: `/api/llm` | **Auth**: JWT (验证方，Secret 共享自 UserManage)

所有接口需要在 Header 中携带 `Authorization: Bearer <access_token>`。

> **Pydantic 规范**: 所有 Request Body 和 Response 均使用 Pydantic V2 Model 定义。详见 [research.md R-011](../research.md#r-011-接口参数校验规范pydantic-model)。

## Pydantic Schemas

```python
from pydantic import BaseModel, Field, ConfigDict, HttpUrl
from typing import Optional, List
from decimal import Decimal
from datetime import datetime

# --- Model ---
class ModelCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="模型名称（必填）")
    url: str = Field(..., description="LLM API 端点 URL（必填）")
    api_key: "[REDACTED]"
    max_tokens: int = Field(..., ge=1, description="上下文窗口大小（必填）")
    rpm: int = Field(..., ge=0, description="RPM，0=不限（必填）")
    tpm: int = Field(..., ge=0, description="TPM，0=不限（必填）")
    input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输入价格/百万 tokens（必填）")
    output_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输出价格/百万 tokens（必填）")
    cached_input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="缓存命中价格/百万 tokens（必填）")

class ModelUpdate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="模型名称（必填）")
    url: str = Field(..., description="LLM API 端点 URL（必填）")
    api_key: "[REDACTED]"
    max_tokens: int = Field(..., ge=1, description="上下文窗口大小（必填）")
    rpm: int = Field(..., ge=0, description="RPM，0=不限（必填）")
    tpm: int = Field(..., ge=0, description="TPM，0=不限（必填）")
    input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输入价格/百万 tokens（必填）")
    output_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输出价格/百万 tokens（必填）")
    cached_input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="缓存命中价格/百万 tokens（必填）")

class ModelResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    url: str
    api_key_masked: "[REDACTED]"
    max_tokens: int
    rpm: int
    tpm: int
    input_per_million: Decimal
    output_per_million: Decimal
    cached_input_per_million: Decimal
    created_at: datetime
    updated_at: datetime

# --- Chat Completion ---
class ChatMessage(BaseModel):
    role: str = Field(..., pattern="^(user|assistant|system)$")
    content: str = Field(..., min_length=1)

class ChatCompletionRequest(BaseModel):
    model_id: str = Field(..., description="模型 ID（必填）")
    messages: List[ChatMessage] = Field(..., min_length=1, description="消息列表")
```

---

## 模型管理（仅管理员可访问，需 model_manage 权限）

### GET /models

获取模型列表

**Access**: 仅 `model_manage` 权限

**Query Params**: `page` (int, default 1), `page_size` (int, default 20)

**Response 200**:
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "string",
      "url": "string",
      "api_key_masked": "[REDACTED]"
      "max_tokens": 4096,
      "rpm": 60,
      "tpm": 100000,
      "input_per_million": 2.5000,
      "output_per_million": 10.0000,
      "cached_input_per_million": 1.2500,
      "created_at": "ISO8601",
      "updated_at": "ISO8601"
    }
  ],
  "total": 5,
  "page": 1,
  "page_size": 20
}
```

**注意**: `api_key_masked` 仅显示掩码值（前3位 + **** + 后4位），不返回完整 Key。

---

### POST /models

创建模型配置

**Access**: 仅 `model_manage` 权限

**Request Body**:
```json
{
  "name": "string (required)",
  "url": "string (required, valid URL)",
  "api_key": "[REDACTED]"
  "max_tokens": "int (required, >= 1)",
  "rpm": "int (required, >= 0)",
  "tpm": "int (required, >= 0)",
  "input_per_million": "decimal (required, >= 0)",
  "output_per_million": "decimal (required, >= 0)",
  "cached_input_per_million": "decimal (required, >= 0)"
}
```

**Behavior**: `api_key` 使用 Fernet 加密后存储为 `api_key_encrypted`

**Response 201**:
```json
{
  "id": "uuid",
  "name": "string",
  "url": "string",
  "api_key_masked": "[REDACTED]"
  "max_tokens": 4096,
  "rpm": 0,
  "tpm": 0,
  "input_per_million": 0,
  "output_per_million": 0,
  "cached_input_per_million": 0,
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

---

### PUT /models/{model_id}

修改模型配置

**Path Parameter**: `model_id` (string, UUID, 必填) — 待更新的模型 ID

**Access**: 仅 `model_manage` 权限

**Request Body**:
```json
{
  "name": "string (required)",
  "url": "string (required, valid URL)",
  "api_key": "[REDACTED]"
  "max_tokens": "int (required, >= 1)",
  "rpm": "int (required, >= 0)",
  "tpm": "int (required, >= 0)",
  "input_per_million": "decimal (required, >= 0)",
  "output_per_million": "decimal (required, >= 0)",
  "cached_input_per_million": "decimal (required, >= 0)"
}
```

**Behavior**: 更新时 `api_key` 可选；不传、传 `null`、空字符串或纯空白字符串时保留原密钥，其他字段仍必填。提供非空新密钥时使用 Fernet 重新加密存储。`api_key_masked` 仅用于占位展示，前端不得将其作为 `api_key` 提交。新建时 `api_key` 仍必填。

**Response 200**: 更新后的模型对象（含 `api_key_masked`）

---

### DELETE /models/{model_id}

删除模型配置

**Path Parameter**: `model_id` (string, UUID, 必填) — 待删除的模型 ID

**Access**: 仅 `model_manage` 权限

**Response 200**: `{ "message": "模型删除成功" }`

---

## LLM 对话代理（内部服务调用 + 用户会话使用）

### POST /chat/completions

向 LLM 发送对话请求（流式返回）

**Access**: 任何已认证用户（通过 KnowledgeManage 服务内部调用或直接调用）

**Request Body**:
```json
{
  "model_id": "uuid (required)",
  "messages": [
    {
      "role": "user | assistant | system",
      "content": "string"
    }
  ]
}
```

**Behavior**:
1. 根据 `model_id` 查询模型配置，解密 API Key
2. 向模型配置的 `url` 发起 LLM API 调用
3. 以 SSE 流式返回 LLM 响应

**Response**: `text/event-stream`

```text
data: {"content": "你"}

data: {"content": "好"}

data: {"content": "！"}

data: {"done": true, "usage": {"prompt_tokens": 10, "completion_tokens": 3, "total_tokens": 13}}
```

**Error 400**: `{ "detail": "模型不存在" }`
**Error 502**: `{ "detail": "LLM 服务调用失败: {error_message}" }`
