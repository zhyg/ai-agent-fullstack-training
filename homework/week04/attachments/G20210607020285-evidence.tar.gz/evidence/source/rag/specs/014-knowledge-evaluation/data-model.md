# Data Model: 知识库评测（014-knowledge-evaluation）

**Plan**: [plan.md](./plan.md) | **Research**: [research.md](./research.md)

全部新表挂 `knowledge_manage` schema（`settings.database.db_schema`），约定沿用既有模型：String(36) UUID 主键（`default=lambda: str(uuid.uuid4())`）、JSONB、TIMESTAMP（UTC `datetime.now(timezone.utc)`）、表级 Index + `{"schema": ...}`。

## 1. evaluation_settings（评测设置，FR-002~004/009）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK | |
| user_id | String(36) | NOT NULL, UNIQUE | 每用户一行（upsert） |
| analysis_model_id | String(36) | NULL | 网关"对话"模型 UUID |
| recall_prompt_id | String(36) | NULL | 本人召回率提示词 UUID（含版本语义） |
| accuracy_prompt_id | String(36) | NULL | 本人准确度提示词 UUID |
| created_at / updated_at | TIMESTAMP | NOT NULL | updated_at onupdate |

- 索引：`uq_evaluation_settings_user`（user_id 唯一）。
- 校验：保存时三引用可空（允许部分保存），但开跑前预检要求三项齐备且有效（FR-011）；保存前校验本人无 running 任务（FR-009 锁定）。
- 关系：逻辑引用 llm_gateway.models / prompts，不建跨 schema 外键（沿用项目惯例）。

## 2. evaluation_test_sets（测试集，FR-005~009）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK | 重新上传覆盖时不变 |
| user_id | String(36) | NOT NULL | 归属 |
| name | String(100) | NOT NULL | 同一用户内唯一 |
| items | JSONB | NOT NULL | `[{question, answer}]`，1–500 项 |
| item_count | Integer | NOT NULL | 冗余题数（=len(items)，便于列表展示） |
| created_at / updated_at | TIMESTAMP | NOT NULL | |

- 索引：`uq_evaluation_test_sets_user_name`（user_id, name 唯一）、`idx_evaluation_test_sets_user`。
- 校验（FR-006，上传与重新上传同规则）：文件 ≤2MB；JSON 顶层数组；1 ≤ 题数 ≤ 500；每项 question/answer 均为非空字符串（strip 后非空）；失败返回具体错误（第几项/何字段）。
- 锁定（FR-009）：删除/重新上传前查 `evaluation_runs.status='running' AND test_set_id=本ID`，命中拒绝（409）。
- 下载：从 items 导出标准 JSON 数组文件（文件名 `{name}.json`）。

## 3. evaluation_runs（评测任务，FR-010~020/028~034）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK | |
| user_id | String(36) | NOT NULL | 创建者，仅本人可见 |
| knowledge_base_ids | JSONB | NOT NULL | ID 列表（≥1） |
| knowledge_base_names | JSONB | NOT NULL | 名称快照列表（与 IDs 同序，决策19） |
| agent_id | String(36) | NOT NULL | |
| agent_name | String(200) | NOT NULL | 名称快照 |
| test_set_id | String(36) | NOT NULL | |
| test_set_name | String(100) | NOT NULL | 名称快照 |
| status | String(20) | NOT NULL, default 'running' | running/completed/cancelled/failed |
| total_items | Integer | NOT NULL | 开跑时测试集题数 |
| completed_items | Integer | NOT NULL, default 0 | 已处理题数（含失败题） |
| cancel_requested | Boolean | NOT NULL, default False | 题间取消标记（R6） |
| error_message | Text | NULL | 任务级失败原因（服务重启中断/执行异常） |
| started_at | TIMESTAMP | NOT NULL | 列表"开始时间" |
| finished_at | TIMESTAMP | NULL | 终态时间 |
| created_at | TIMESTAMP | NOT NULL | |

- 索引：`idx_evaluation_runs_user_created`（user_id, created_at DESC）、`idx_evaluation_runs_status`（status，启动恢复用）、`idx_evaluation_runs_test_set`（test_set_id, status，锁定查询用）。
- 并发约束（FR-012）：创建前查本人 `status='running'` 存在即拒绝（409）；单 worker 下创建路径串行，无需 DB 部分唯一索引。
- 平均分：**不落库**，查询时对 items 聚合（R13）：`AVG(recall) / AVG(accuracy) FILTER (WHERE status='success')`；无成功题 → null。
- 状态机：

```text
running ──全部题目处理完──▶ completed   （含全题失败，决策25）
running ──题间命中取消标记──▶ cancelled  （当前题完成后，决策15）
running ──服务重启/任务级异常──▶ failed   （决策16/25，error_message 必填）
终态不可逆；completed_items/finished_at 随终态落定
```

## 4. evaluation_items（题目明细，FR-026~028/031/035）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | String(36) | PK | |
| run_id | String(36) | NOT NULL, FK→evaluation_runs.id ON DELETE CASCADE | 删除记录级联删明细（FR-033） |
| seq | Integer | NOT NULL | 题序（1 起），(run_id, seq) 唯一 |
| question | Text | NOT NULL | 开跑时逐题快照（决策13） |
| standard_answer | Text | NOT NULL | 同上 |
| status | String(20) | NOT NULL, default 'pending' | pending/success/failed |
| agent_answer | Text | NULL | agent 最终答案 |
| context | JSONB | NULL | meta.references 快照（R3：file_name/content/score/chunk_id/document_id/kb_id） |
| recall | Float | NULL | 0–1，后端核算（R5）；失败置空 |
| accuracy | Float | NULL | 0–100，后端核算；失败置空 |
| recall_analysis | JSONB | NULL | 最终采纳的合法召回率 JSON（决策14） |
| accuracy_analysis | JSONB | NULL | 最终采纳的合法准确度 JSON |
| recall_raw_output | Text | NULL | 召回率评分失败时最后一次原始输出 |
| accuracy_raw_output | Text | NULL | 准确度评分失败时最后一次原始输出 |
| failure_reason | Text | NULL | 澄清原因/执行失败/评分重试耗尽/执行超时 |
| trace_id | String(32) | NULL | 该题根 span trace ID（决策21） |
| created_at | TIMESTAMP | NOT NULL | trace 索引窗口基准（R11） |
| completed_at | TIMESTAMP | NULL | |

- 索引：`uq_evaluation_items_run_seq`（run_id, seq 唯一）、`idx_evaluation_items_run`（run_id, status，平均分聚合用）。
- 落库时机（FR-014）：开跑时按测试集逐题预建 pending 行（含 question/standard_answer 快照）；每题处理完 UPDATE 该行（逐题落库）。
- 评分 JSON 模型（`schemas/evaluation.py`，Pydantic，R4）：
  - `RecallResult`：`key_points: List[KeyPoint]`（`min_length=1`，空数组校验失败→重试，澄清 Q1）；`KeyPoint{point: str(min_length=1), covered: StrictBool}`；`recall: float`（仅参考，不采信）。
  - `AccuracyResult`：`issues: List[Issue]`（空数组合法=100 分）；`Issue{type: str, content: str, evidence: str}`。
- 单题状态机：`pending → success`（作答+两项评分均成功）/ `pending → failed`（澄清需澄清、agent 执行失败、任一评分重试耗尽/传输失败、执行超时；failure_reason 必填，得分与分析 JSON 按已完成部分保留）。

## 5. Alembic 迁移

- 单文件 `alembic/versions/<rev>_add_evaluation_tables.py`：创建上述 4 表与全部索引/唯一约束/FK；`down_revision` 指向当前 head（实现时 `alembic heads` 确认）；downgrade 逆序 drop。
- 不迁移存量数据；不改动既有表。

## 6. 实体关系

```text
User 1──1 EvaluationSetting
User 1──N EvaluationTestSet
User 1──N EvaluationRun 1──N EvaluationItem（CASCADE）
EvaluationRun ──逻辑引用──▶ KnowledgeBase[]/Agent/TestSet（ID+名称快照，无 FK，删除不阻断，决策19）
EvaluationItem.trace_id ──逻辑关联──▶ ES jaeger-span-*（保留期约束，决策23）
```