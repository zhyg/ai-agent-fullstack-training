# Feature Specification: LLM Gateway 支持 Embedding、Rerank、视觉模型

**Feature Branch**: `009-gateway-embedding-rerank-vision`

**Created**: 2026-11-17

**Status**: Draft

**Input**: User description: "llmgateway 支持embedding、rerank、视觉模型"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - 文本向量化（Embedding）(Priority: P1)

开发者通过 Gateway 统一的 API 调用 Embedding 模型，将文本转换为向量表示，用于知识库的语义检索。开发者发送一段或多段文本，Gateway 返回对应的向量数组，同时记录用量和成本。

**Why this priority**: 语义检索是知识库 RAG 流程的基础能力，Embedding 是构建向量索引的第一步，没有它知识库的语义搜索无法工作。

**Independent Test**: 可以通过向 `/v1/embeddings` 发送一段文本，验证返回的向量维度和格式是否正确，并确认用量已被记录。

**Acceptance Scenarios**:

1. **Given** 系统中已配置一个 Embedding 模型，**When** 开发者发送单段文本请求，**Then** 返回包含该文本对应向量的标准响应，且用量信息正确
2. **Given** 系统中已配置一个 Embedding 模型，**When** 开发者发送包含多段文本的批量请求（最多 2048 条），**Then** 返回所有文本对应的向量，索引顺序与输入一致
3. **Given** 开发者指定了输出维度参数，**When** 模型支持维度调整时，**Then** 返回的向量维度与指定值一致
4. **Given** 请求的模型名称对应的不是 Embedding 类型，**When** 开发者调用 Embedding 接口，**Then** 返回 404 错误并提示模型类型不匹配

---

### User Story 2 - 搜索结果重排序（Rerank）(Priority: P2)

开发者通过 Gateway 统一的 API 调用 Rerank 模型，对语义检索返回的候选文档进行相关性重排序。开发者发送一个查询和多段候选文档，Gateway 返回按相关性降序排列的结果，附带相关性分数。

**Why this priority**: Rerank 是 RAG 流程中提升检索精度的关键环节，但它依赖 Embedding 先完成初步检索，因此优先级略低于 Embedding。

**Independent Test**: 可以通过向 `/v1/rerank` 发送一个查询和若干候选文档，验证返回结果按相关性分数降序排列，且分数合理。

**Acceptance Scenarios**:

1. **Given** 系统中已配置一个 Rerank 模型，**When** 开发者发送查询和文档列表，**Then** 返回按相关性分数降序排列的结果，包含原始文档索引和分数
2. **Given** 开发者指定了 top_n 参数，**When** 调用 Rerank 接口，**Then** 仅返回分数最高的前 N 条结果
3. **Given** 开发者设置了 return_documents=true，**When** 调用 Rerank 接口，**Then** 响应结果中包含文档原文
4. **Given** 请求的模型名称对应的不是 Rerank 类型，**When** 开发者调用 Rerank 接口，**Then** 返回 404 错误并提示模型类型不匹配

---

### User Story 3 - 图片理解（Vision）(Priority: P2)

开发者通过现有的 Chat 接口发送包含图片的消息，让视觉模型理解图片内容并给出文字回答。消息格式与纯文本 Chat 保持一致，仅在 content 中嵌入图片信息（URL 或 Base64）。

**Why this priority**: 图片理解扩展了知识库的输入模态（文档中的图表、截图等），是知识库智能化的重要方向，但不影响核心文本检索流程。

**Independent Test**: 可以通过向 `/v1/chat/completions` 发送包含图片 URL 的消息，验证模型能正确理解图片并返回文字描述。

**Acceptance Scenarios**:

1. **Given** 系统中已配置一个支持图片的视觉模型，**When** 开发者发送包含图片 URL 的消息，**Then** 模型返回对图片内容的文字理解
2. **Given** 开发者发送了 Base64 编码的图片数据，**When** 调用 Chat 接口，**Then** 模型同样能正确理解并回答
3. **Given** 开发者向视觉模型发送纯文本消息（无图片），**When** 调用 Chat 接口，**Then** 模型正常处理文本并返回回答，不报错
4. **Given** 开发者向一个纯文本模型发送了包含图片的消息，**When** 调用 Chat 接口，**Then** 返回 400 错误提示该模型不支持图片输入

---

### User Story 4 - 管理员配置多类型模型 (Priority: P1)

管理员在模型管理面板中添加、编辑 Embedding、Rerank、Vision 类型的模型配置。每种类型的模型有各自的专属属性（如 Embedding 的向量维度、Vision 的支持模态等），前端表单根据所选模型类型动态显示对应字段，管理员可以灵活配置。

**Why this priority**: 模型配置是所有调用能力的前提，没有配置就无法使用任何模型能力。

**Independent Test**: 可以通过管理面板添加一个 Embedding 模型，验证其配置信息正确保存，并在模型列表中显示。

**Acceptance Scenarios**:

1. **Given** 管理员登录管理面板，**When** 添加一个 Embedding 模型并填写向量维度，**Then** 模型配置保存成功，列表中可见该模型
2. **Given** 管理员登录管理面板，**When** 添加一个 Rerank 模型，**Then** 模型配置保存成功
3. **Given** 管理员登录管理面板，**When** 添加一个 Vision 模型并标记支持图片模态，**Then** 模型配置保存成功
4. **Given** 现有 Chat 模型配置，**When** 管理员编辑时不修改任何新增字段，**Then** 配置保存成功，不影响现有功能

---

### User Story 5 - 多类型模型统一监控 (Priority: P3)

运维人员通过监控面板查看各类型模型（Chat、Embedding、Rerank、Vision）的调用量、Token 用量、成本和延迟情况，能够按模型类型维度进行筛选和聚合。

**Why this priority**: 监控是运维保障能力，在功能上线后可逐步完善，不影响核心业务。

**Independent Test**: 可以在调用若干 Embedding 请求后，验证监控指标中能看到对应的请求计数和 Token 用量。

**Acceptance Scenarios**:

1. **Given** 已产生 Embedding 调用，**When** 查看监控面板，**Then** 能看到 Embedding 类型的请求总数、文本条数和 Token 消耗
2. **Given** 已产生 Rerank 调用，**When** 查看监控面板，**Then** 能看到 Rerank 类型的请求总数和文档条数
3. **Given** 已产生各类型调用，**When** 查看成本统计，**Then** 各类型模型的成本分别正确计算

---

### Edge Cases

- 当 Embedding 请求中的某段文本超过模型最大输入限制时，系统应返回明确的错误信息而非静默截断
- 当 Rerank 请求的文档列表为空或超过 500 条时，系统应返回 400 参数校验错误
- 当 Vision 请求中的图片体积超过 20MB 时，系统应返回 400 错误并提示图片过大
- 当 Vision 请求中的图片 URL 不可访问（如 404）时，系统应透传供应商的错误信息
- 当所有模型都不可用时（如 API Key 过期），系统应对所有类型请求返回 401 认证错误
- 当 Embedding 批量请求中部分文本过长导致整体失败时，系统应返回明确的错误信息指出问题
- 当 Vision 请求包含多张图片时，系统应遵循供应商的多图限制并给出合理提示

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: 系统必须提供 Embedding 接口，接受单条或批量文本输入，返回对应的向量表示
- **FR-002**: 系统必须提供 Rerank 接口，接受查询和文档列表，返回按相关性排序的结果
- **FR-003**: 系统必须扩展现有 Chat 接口，支持在消息中嵌入图片（URL 或 Base64 格式）
- **FR-004**: 系统必须支持通过模型分类（category）区分不同类型的模型能力
- **FR-005**: 系统必须根据请求的接口类型校验模型分类是否匹配（如 Embedding 接口不能调用 Chat 模型）
- **FR-006**: 系统必须为 Embedding 模型记录向量维度属性
- **FR-007**: Vision 模型默认支持文本和图片，无需单独配置输入模态
- **FR-008**: 系统必须对所有类型请求进行统一的认证、限流和重试控制
- **FR-009**: 系统必须对所有类型请求记录用量（Token 数）、延迟和成本
- **FR-010**: 系统必须在监控指标中包含模型类型维度，支持按类型聚合分析
- **FR-011**: 系统必须保持现有 Chat 接口的完全向后兼容（纯文本请求不受任何影响）
- **FR-012**: 当纯文本模型收到图片请求时，系统必须返回明确的错误提示

### Key Entities

- **模型配置（Model Configuration）**: 描述一个可用模型的元信息，包含名称、供应商、接入地址、密钥、分类、限流参数、定价信息等。不同分类的模型有各自专属属性（如 Embedding 有向量维度，Vision 有支持模态列表）
- **Embedding 请求（Embedding Request）**: 包含模型名称和输入文本（单条或多条），可选指定输出维度
- **Embedding 响应（Embedding Response）**: 包含向量数组、模型名称和 Token 用量信息
- **Rerank 请求（Rerank Request）**: 包含模型名称、查询文本、候选文档列表，可选指定返回数量和是否包含原文
- **Rerank 响应（Rerank Response）**: 包含按相关性排序的结果列表（索引、分数、可选原文）和用量信息
- **多模态消息（Multimodal Message）**: Chat 消息中 content 可以是纯文本，也可以是包含文本和图片的复合结构

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 开发者通过 Embedding 接口提交单条文本后，在 3 秒内获得向量结果
- **SC-002**: 开发者通过 Embedding 接口批量提交 100 条文本后，在 10 秒内获得全部向量结果
- **SC-003**: 开发者通过 Rerank 接口提交查询和 20 条候选文档后，在 5 秒内获得排序结果
- **SC-004**: 开发者通过 Chat 接口发送含图片的消息后，在 15 秒内获得模型的文字回答
- **SC-005**: 100% 的现有纯文本 Chat 请求在升级后无需任何修改即可正常工作
- **SC-006**: 管理员可以在 2 分钟内完成一个新类型模型（Embedding/Rerank/Vision）的配置
- **SC-007**: 监控面板能区分至少 4 种模型类型（Chat、Embedding、Rerank、Vision）的调用指标
- **SC-008**: 所有类型请求的用量和成本统计准确率达到 100%

## Clarifications

### Session 2026-11-17

- Q: Embedding/Rerank 是否需要支持流式输出？ → A: 仅支持同步非流式调用
- Q: 前端管理面板是否同步修改？ → A: 后端 API + 前端表单同步新增字段
- Q: Rerank 单次请求最大文档数？ → A: 最多 500 条
- Q: Vision 单张图片最大体积？ → A: 20MB

## Assumptions

- 现有的 OpenAI 兼容协议和 Cohere 兼容协议在可预见的未来不会发生破坏性变更
- Embedding 和 Rerank 模型均为无状态调用，不涉及流式输出（已确认：仅同步非流式）
- 视觉模型通过现有 Chat 协议接入，不需要独立的 API 端点
- 图片输入以 URL（网络图片或 Base64 Data URI）方式传递，不涉及文件上传
- 现有的认证体系（API Key）和限流机制可直接复用，无需额外改造
- 管理员对模型分类（Chat/Embedding/Rerank/Vision）的概念有基本理解
- Embedding/Rerank 模型的定价仅涉及输入 Token 费用，输出费用填 0
- 数据库 URL 字段统一存储 base URL，由系统内部根据调用类型自动拼接子路径
