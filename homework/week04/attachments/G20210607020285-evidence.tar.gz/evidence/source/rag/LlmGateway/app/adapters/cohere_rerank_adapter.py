"""Cohere Rerank API adapter."""

import logging
from typing import Any, AsyncGenerator

import httpx

from app.adapters.base import BaseAdapter, ModelConfig
from app.gateway.errors import UpstreamError, UpstreamTimeoutError
from app.gateway.retry import is_retryable_http_status
from app.core.config import settings

logger = logging.getLogger(__name__)


def _build_url(base_url: str, sub_path: str) -> str:
    """Build full URL by joining base URL with a sub-path."""
    return base_url.rstrip("/") + "/" + sub_path.lstrip("/")


class CohereRerankAdapter(BaseAdapter):
    """Adapter for Cohere-compatible Rerank API.

    Only implements rerank(). complete()/stream()/embed() raise NotImplementedError.
    """

    _provider = "cohere_rerank"

    @property
    def provider(self) -> str:
        return self._provider

    def _build_headers(self, model_config: ModelConfig) -> dict:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {model_config.api_key}",
        }

    async def complete(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> dict:
        raise NotImplementedError("CohereRerankAdapter does not support chat completions")

    async def stream(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> AsyncGenerator[dict, None]:
        raise NotImplementedError("CohereRerankAdapter does not support streaming")
        # Make this an async generator (never yields)
        return
        yield  # pragma: no cover

    async def embed(
        self, model_config: ModelConfig, texts: list[str], **kwargs: Any
    ) -> dict:
        raise NotImplementedError("CohereRerankAdapter does not support embeddings")

    async def rerank(
        self,
        model_config: ModelConfig,
        query: str,
        documents: list[str],
        **kwargs: Any,
    ) -> dict:
        """Call Cohere-compatible rerank endpoint.

        Returns a dict with keys: results, usage.
        """
        headers = self._build_headers(model_config)
        payload: dict[str, Any] = {
            "model": model_config.name,
            "query": query,
            "documents": documents,
        }
        if kwargs.get("top_n") is not None:
            payload["top_n"] = kwargs["top_n"]
        if kwargs.get("return_documents") is not None:
            payload["return_documents"] = kwargs["return_documents"]

        url = _build_url(model_config.url, "rerank")

        try:
            async with httpx.AsyncClient(timeout=settings.provider_timeout) as client:
                response = await client.post(url, json=payload, headers=headers)
        except httpx.TimeoutException:
            raise UpstreamTimeoutError(f"Rerank API timeout: {url}")
        except httpx.ConnectError as e:
            raise UpstreamError(f"Rerank API connection failed: {e}")

        if response.status_code != 200:
            error_text = response.text
            logger.error(
                "Rerank API error %d: %s", response.status_code, error_text,
            )
            raise UpstreamError(
                f"Rerank API returned {response.status_code}: {error_text}",
                retryable=is_retryable_http_status(response.status_code),
            )

        body = response.json()
        logger.info(
            "provider_rerank model=%s status=%d results=%d",
            model_config.name,
            response.status_code,
            len(body.get("results", [])),
        )

        # Normalize to internal format
        # Cohere response: {"results": [{"index": 0, "relevance_score": 0.9, "document": {"text": "..."}}]}
        raw_results = body.get("results", [])
        results = []
        for r in raw_results:
            results.append({
                "index": r.get("index", 0),
                "relevance_score": r.get("relevance_score", 0.0),
                "document": r.get("document"),
            })

        # Estimate usage from input (Cohere may not return usage)
        usage_data = body.get("usage") or {}
        prompt_tokens = usage_data.get("prompt_tokens") or usage_data.get("search_units", 0)
        if not prompt_tokens:
            # Fallback: rough estimate (chars / 4)
            prompt_tokens = (len(query) + sum(len(d) for d in documents)) // 4

        return {
            "results": results,
            "usage": {
                "input": prompt_tokens,
                "output": 0,
                "cached": 0,
                "reasoning": 0,
            },
        }
