"""Remove the configurable input modalities from models."""

import sqlalchemy as sa
from alembic import op

revision = "f2a3b4c5d6e7"
down_revision = "c772db91cbaa"
branch_labels = None
depends_on = None

SCHEMA = "llm_gateway"


def upgrade() -> None:
    op.drop_column("models", "supported_modalities", schema=SCHEMA)


def downgrade() -> None:
    op.add_column(
        "models",
        sa.Column("supported_modalities", sa.JSON(), nullable=True, comment="支持的输入模态列表"),
        schema=SCHEMA,
    )
    op.execute(
        """UPDATE llm_gateway.models
        SET supported_modalities = '["text", "image"]'
        WHERE category = 'vision'"""
    )
