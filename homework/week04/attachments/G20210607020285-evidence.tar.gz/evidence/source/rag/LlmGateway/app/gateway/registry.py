"""Model registry: loads model configurations and provider adapters."""

import logging
from typing import Optional

from sqlalchemy.orm import Session

from app.adapters.base import ModelConfig, BaseAdapter
from app.models.model import Model
from app.core.encryption import decrypt_value

logger = logging.getLogger(__name__)


class ModelRegistry:
    """In-memory registry of adapters and model configurations.

    Loaded from the database at startup. Looks up models by name or display name.
    """

    def __init__(self):
        self.adapters: dict[str, BaseAdapter] = {}
        self.models: dict[tuple[str, str], ModelConfig] = {}

    def register_adapter(self, adapter: BaseAdapter):
        """Register an adapter instance for a provider."""
        self.adapters[adapter.provider] = adapter
        logger.info("Registered adapter: %s", adapter.provider)

    def get_adapter(self, provider: str) -> Optional[BaseAdapter]:
        """Get an adapter by provider name."""
        return self.adapters.get(provider)

    def get_model_config(self, model_name: str, category: str) -> Optional[ModelConfig]:
        """Look up a model name or display name within its category."""
        return self.models.get((model_name, category))

    def get_chat_model_config(self, model_name: str, *, has_images: bool) -> Optional[ModelConfig]:
        first, second = ("vision", "chat") if has_images else ("chat", "vision")
        return self.get_model_config(model_name, first) or self.get_model_config(model_name, second)

    def load_from_db(self, db: Session):
        """Load all model records from the database."""
        self.models.clear()

        models = db.query(Model).all()
        for model in models:
            try:
                api_key = "[REDACTED]"
            except Exception:
                logger.error(f"Failed to decrypt API key for model '{model.name}', skipping")
                continue

            config = ModelConfig(
                name=model.name,
                provider=model.provider.lower(),
                url=model.url,
                api_key="[REDACTED]"
                category=model.category,
                rpm=model.rpm,
                tpm=model.tpm,
                context_tokens=model.context_tokens,
                dimensions=model.dimensions,
                max_input_tokens=model.max_input_tokens,
                pricing={
                    "input_per_k": float(model.input_per_k),
                    "output_per_k": float(model.output_per_k),
                    "cached_input_per_k": float(model.cached_input_per_k),
                },
            )

            # Index by display_name if available, otherwise by name
            lookup_key = model.display_name or model.name
            self.models[(lookup_key, config.category)] = config
            # Also index by name if different from display_name
            if model.display_name and model.name != model.display_name:
                self.models[(model.name, config.category)] = config

        logger.info(
            f"ModelRegistry loaded: {len(self.models)} model configs, "
            f"{len(self.adapters)} adapters"
        )
