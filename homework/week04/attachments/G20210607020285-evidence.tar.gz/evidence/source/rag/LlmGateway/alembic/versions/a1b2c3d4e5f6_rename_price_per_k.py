"""Rename model price columns from per-million to per-K tokens.

计价单位修正：原字段按"每百万 tokens"命名/计算属设置错误，
实际录入值即"每 K tokens"单价，故仅改列名，数值原样保留；
费用计算除数由 1e6 改为 1e3（llm_gateway_service）。
"""

import sqlalchemy as sa
from alembic import op

revision = "e5f6a7b8c9d0"
down_revision = "f2a3b4c5d6e7"
branch_labels = None
depends_on = None

SCHEMA = "llm_gateway"

RENAMES = [
    ("input_per_million", "input_per_k", "输入 token 价格/K"),
    ("output_per_million", "output_per_k", "输出 token 价格/K"),
    ("cached_input_per_million", "cached_input_per_k", "缓存命中 token 价格/K"),
]


def upgrade() -> None:
    for old, new, comment in RENAMES:
        op.alter_column(
            "models", old,
            new_column_name=new,
            existing_type=sa.Numeric(precision=10, scale=4),
            existing_nullable=False,
            comment=comment,
            schema=SCHEMA,
        )


def downgrade() -> None:
    for old, new, _ in RENAMES:
        op.alter_column(
            "models", new,
            new_column_name=old,
            existing_type=sa.Numeric(precision=10, scale=4),
            existing_nullable=False,
            comment=old.replace("_per_million", "") + " token 价格/百万",
            schema=SCHEMA,
        )