"""change_unique_constraint_to_provider_category_name

Revision ID: c772db91cbaa
Revises: d1e2f3a4b5c6
Create Date: 2026-11-18 21:49:54.227662

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'c772db91cbaa'
down_revision: Union[str, None] = 'd1e2f3a4b5c6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_constraint('uq_models_provider_name', 'models', schema='llm_gateway', type_='unique')
    op.create_unique_constraint('uq_models_provider_category_name', 'models', ['provider', 'category', 'name'], schema='llm_gateway')


def downgrade() -> None:
    op.drop_constraint('uq_models_provider_category_name', 'models', schema='llm_gateway', type_='unique')
    op.create_unique_constraint('uq_models_provider_name', 'models', ['provider', 'name'], schema='llm_gateway')
