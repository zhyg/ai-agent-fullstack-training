import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from app.adapters.openai_adapter import OpenAIAdapter
from app.gateway.registry import ModelRegistry
from app.routers.v1_chat import _validate_vision
from app.schemas.chat_completion import ChatCompletionRequest
from app.services.llm_gateway_service import LLMGatewayService


class DisplayNameRoutingTests(unittest.TestCase):
    def test_display_name_resolves_provider_model_and_url(self):
        model = SimpleNamespace(
            name="provider-model",
            display_name="Friendly model",
            provider="openai",
            url="https://example.com/v1/chat/completions",
            api_key_encrypted="[REDACTED]"
            rpm=0,
            tpm=0,
            context_tokens=4096,
            input_per_k=0,
            output_per_k=0,
            cached_input_per_k=0,
            category="chat",
            dimensions=None,
            max_input_tokens=None,
        )
        db = MagicMock()
        db.query.return_value.all.return_value = [model]
        registry = ModelRegistry()
        adapter = OpenAIAdapter()
        registry.register_adapter(adapter)
        with patch("app.gateway.registry.decrypt_value", return_value="test-key"):
            registry.load_from_db(db)
        service = LLMGatewayService(registry, MagicMock())
        request = ChatCompletionRequest(
            model="Friendly model",
            messages=[{"role": "user", "content": "hello"}],
            stream=True,
        )
        config, resolved_name = service._resolve_model(request)
        self.assertEqual(resolved_name, "provider-model")
        self.assertEqual(config.url, model.url)
        self.assertEqual(config.api_key, "test-key")
        self.assertIs(service._get_adapter(config), adapter)
        self.assertEqual(
            adapter._build_payload(config, [], stream=True)["model"], "provider-model"
        )

    def test_same_name_routes_by_input_regardless_of_load_order(self):
        common = dict(
            name="provider-model", display_name="Friendly model", provider="openai",
            api_key_encrypted="[REDACTED]"
            context_tokens=4096, input_per_k=0, output_per_k=0,
            cached_input_per_k=0, dimensions=None, max_input_tokens=None,
        )
        chat = SimpleNamespace(
            **common, category="chat", url="https://example.com/chat",
        )
        vision = SimpleNamespace(
            **common, category="vision", url="https://example.com/vision",
        )
        db = MagicMock()
        registry = ModelRegistry()
        service = LLMGatewayService(registry, MagicMock())
        http_request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(registry=registry)))
        for rows in ([vision, chat], [chat, vision], [chat], [vision]):
            db.query.return_value.all.return_value = rows
            with patch("app.gateway.registry.decrypt_value", return_value="test-key"):
                registry.load_from_db(db)
            for name in (chat.name, chat.display_name):
                with self.subTest(categories=[row.category for row in rows], name=name):
                    image = ChatCompletionRequest(model=name, messages=[{
                        "role": "user",
                        "content": [{"type": "image_url", "image_url": {"url": "https://example.com/photo.png"}}],
                    }])
                    text = ChatCompletionRequest(model=name, messages=[{"role": "user", "content": "hello"}])
                    self.assertIsNone(registry.get_model_config(name, "embedding"))
                    self.assertEqual(service._resolve_model(text)[0].url, (chat if chat in rows else vision).url)
                    if vision in rows:
                        self.assertIsNone(_validate_vision(image, http_request))
                        config, upstream_name = service._resolve_model(image)
                        self.assertEqual(config.url, vision.url)
                        self.assertEqual(upstream_name, vision.name)
                    else:
                        self.assertEqual(_validate_vision(image, http_request).status_code, 400)
