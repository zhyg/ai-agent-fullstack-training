"""Function calling passthrough tests.

规划推理智能体依赖网关透传 tools 声明与 tool_calls 结果；
此前网关 schema/adapter 丢弃 tools 导致模型只能在 content 中输出计划文本。
"""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from app.adapters.base import ModelConfig
from app.adapters.openai_adapter import OpenAIAdapter
from app.schemas.chat_completion import (
    ChatCompletionRequest,
    build_completion_response,
)
from app.services.llm_gateway_service import (
    LLMGatewayService,
    _estimate_message_tokens,
    _serialize_messages,
)


TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "createPlan",
            "description": "制定计划",
            "parameters": {"type": "object", "properties": {"steps": {"type": "array"}}},
        },
    }
]

TOOL_CALLS = [
    {
        "id": "call_001",
        "type": "function",
        "function": {"name": "createPlan", "arguments": "{\"steps\": []}"},
    }
]


def _make_request(**overrides) -> ChatCompletionRequest:
    payload = {
        "model": "test-model",
        "messages": [
            {"role": "system", "content": "planning protocol"},
            {"role": "user", "content": "李四的语文成绩是多少"},
            {"role": "assistant", "content": None, "tool_calls": TOOL_CALLS},
            {"role": "tool", "tool_call_id": "call_001", "content": "{\"ok\": true}"},
        ],
        "tools": TOOLS,
        "tool_choice": "auto",
    }
    payload.update(overrides)
    return ChatCompletionRequest(**payload)


class ToolCallingSchemaTests(unittest.TestCase):
    def test_request_accepts_tools_and_tool_loop_messages(self):
        request = _make_request()
        self.assertEqual(request.tools, TOOLS)
        self.assertEqual(request.tool_choice, "auto")
        self.assertEqual(request.messages[2].tool_calls, TOOL_CALLS)
        self.assertIsNone(request.messages[2].content)
        self.assertEqual(request.messages[3].role, "tool")
        self.assertEqual(request.messages[3].tool_call_id, "call_001")

    def test_request_without_tools_keeps_defaults(self):
        request = ChatCompletionRequest(
            model="m", messages=[{"role": "user", "content": "hi"}]
        )
        self.assertIsNone(request.tools)
        self.assertIsNone(request.tool_choice)

    def test_serialize_messages_preserves_function_calling_fields(self):
        request = _make_request()
        serialized = _serialize_messages(request.messages)
        self.assertEqual(serialized[2]["tool_calls"], TOOL_CALLS)
        self.assertIsNone(serialized[2]["content"])
        self.assertEqual(serialized[3]["tool_call_id"], "call_001")
        self.assertEqual(serialized[3]["role"], "tool")
        # 普通消息不带多余字段
        self.assertNotIn("tool_calls", serialized[1])
        self.assertNotIn("tool_call_id", serialized[1])

    def test_estimate_tokens_handles_null_content_and_tool_calls(self):
        request = _make_request()
        self.assertGreater(_estimate_message_tokens(request.messages), 0)

    def test_build_completion_response_includes_tool_calls(self):
        response = build_completion_response(
            model="m",
            content="",
            usage={"input": 10, "output": 5},
            finish_reason="tool_calls",
            tool_calls=TOOL_CALLS,
        )
        message = response.choices[0].message
        self.assertEqual(message["tool_calls"], TOOL_CALLS)
        self.assertEqual(response.choices[0].finish_reason, "tool_calls")

    def test_build_completion_response_without_tool_calls_unchanged(self):
        response = build_completion_response(
            model="m", content="hello", usage={"input": 1, "output": 2}
        )
        self.assertNotIn("tool_calls", response.choices[0].message)


class AdapterKwargsTests(unittest.TestCase):
    def test_build_adapter_kwargs_forwards_tools_and_tool_choice(self):
        service = LLMGatewayService(registry=None, rate_limiter=None)
        kwargs = service._build_adapter_kwargs(_make_request())
        self.assertEqual(kwargs["tools"], TOOLS)
        self.assertEqual(kwargs["tool_choice"], "auto")

    def test_build_adapter_kwargs_omits_absent_tools(self):
        service = LLMGatewayService(registry=None, rate_limiter=None)
        request = ChatCompletionRequest(
            model="m", messages=[{"role": "user", "content": "hi"}]
        )
        kwargs = service._build_adapter_kwargs(request)
        self.assertNotIn("tools", kwargs)
        self.assertNotIn("tool_choice", kwargs)


class OpenAIAdapterToolCallingTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.adapter = OpenAIAdapter()
        self.model_config = ModelConfig(
            name="test-model", provider="openai",
            url="https://provider.example/v1", api_key="[REDACTED]"
        )

    def test_build_payload_forwards_tools_and_tool_choice(self):
        payload = self.adapter._build_payload(
            self.model_config,
            [{"role": "user", "content": "hi"}],
            tools=TOOLS,
            tool_choice="auto",
        )
        self.assertEqual(payload["tools"], TOOLS)
        self.assertEqual(payload["tool_choice"], "auto")

    def test_build_payload_without_tools_unchanged(self):
        payload = self.adapter._build_payload(
            self.model_config, [{"role": "user", "content": "hi"}]
        )
        self.assertNotIn("tools", payload)
        self.assertNotIn("tool_choice", payload)

    async def test_complete_returns_upstream_tool_calls(self):
        upstream = {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": TOOL_CALLS,
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "usage": {"prompt_tokens": 100, "completion_tokens": 20},
        }
        response = MagicMock(status_code=200)
        response.json.return_value = upstream
        client = MagicMock()
        client.post = AsyncMock(return_value=response)
        with patch(
            "app.adapters.openai_adapter.httpx.AsyncClient"
        ) as mock_client_cls:
            mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=client)
            mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            result = await self.adapter.complete(
                self.model_config,
                [{"role": "user", "content": "hi"}],
                tools=TOOLS,
            )
        self.assertEqual(result["tool_calls"], TOOL_CALLS)
        self.assertEqual(result["content"], "")
        self.assertEqual(result["finish_reason"], "tool_calls")
        # tools 声明确实发给了上游
        sent_payload = client.post.call_args.kwargs["json"]
        self.assertEqual(sent_payload["tools"], TOOLS)

    async def test_complete_without_tool_calls_has_no_extra_key(self):
        upstream = {
            "choices": [
                {"message": {"role": "assistant", "content": "hello"}, "finish_reason": "stop"}
            ],
            "usage": {},
        }
        response = MagicMock(status_code=200)
        response.json.return_value = upstream
        client = MagicMock()
        client.post = AsyncMock(return_value=response)
        with patch(
            "app.adapters.openai_adapter.httpx.AsyncClient"
        ) as mock_client_cls:
            mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=client)
            mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            result = await self.adapter.complete(
                self.model_config, [{"role": "user", "content": "hi"}]
            )
        self.assertNotIn("tool_calls", result)
        self.assertEqual(result["content"], "hello")


if __name__ == "__main__":
    unittest.main()