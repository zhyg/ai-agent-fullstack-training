import unittest

from app.adapters.base import ModelConfig
from app.adapters.openai_adapter import OpenAIAdapter


class OpenAIAdapterUsageTests(unittest.TestCase):
    def setUp(self):
        self.adapter = OpenAIAdapter()

    def test_parse_usage_reads_cached_and_reasoning_tokens_from_details(self):
        usage = self.adapter._parse_usage(
            {
                "prompt_tokens": 4776,
                "completion_tokens": 791,
                "total_tokens": 5567,
                "prompt_tokens_details": {"cached_tokens": 3840},
                "completion_tokens_details": {"reasoning_tokens": 110},
            }
        )

        self.assertEqual(
            usage,
            {"input": 4776, "output": 791, "cached": 3840, "reasoning": 110},
        )

    def test_parse_usage_handles_missing_details(self):
        usage = self.adapter._parse_usage({"prompt_tokens": 12, "completion_tokens": 3})

        self.assertEqual(
            usage, {"input": 12, "output": 3, "cached": 0, "reasoning": 0}
        )

    def test_stream_payload_requests_include_usage(self):
        config = ModelConfig(
            name="m", provider="openai", url="https://provider.example/v1", api_key="[REDACTED]"
        )
        messages = [{"role": "user", "content": "hi"}]

        stream_payload = self.adapter._build_payload(config, messages, stream=True)
        self.assertEqual(stream_payload["stream_options"], {"include_usage": True})

        non_stream_payload = self.adapter._build_payload(config, messages, stream=False)
        self.assertNotIn("stream_options", non_stream_payload)


if __name__ == "__main__":
    unittest.main()
