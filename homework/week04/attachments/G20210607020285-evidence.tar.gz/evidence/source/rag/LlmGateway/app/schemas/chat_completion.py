"""OpenAI Chat Completions compatible request/response schemas."""

import time
import uuid

from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Union


# --- Request ---


class ContentPart(BaseModel):
    """Multimodal content part for Vision messages."""
    type: Literal["text", "image_url"] = Field(..., description="Content part type")
    text: Optional[str] = Field(None, description="Text content (when type=text)")
    image_url: Optional[dict] = Field(None, description="Image URL info (when type=image_url)")


class ChatCompletionMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool"] = Field(
        ..., description="Message role"
    )
    content: Optional[Union[str, List[ContentPart]]] = Field(
        default=None,
        description="Message content: plain text or multimodal parts; "
                    "may be null for assistant messages with tool_calls",
    )
    tool_calls: Optional[List[dict]] = Field(
        default=None, description="Tool calls issued by the assistant (function calling)"
    )
    tool_call_id: Optional[str] = Field(
        default=None, description="Tool call id this message responds to (role=tool)"
    )


class ResponseFormat(BaseModel):
    type: Literal["text", "json_object"] = Field(
        default="text", description="Output format type"
    )
    schema_: Optional[dict] = Field(
        default=None, alias="schema", description="JSON Schema (when type=json_object)"
    )

    model_config = {"populate_by_name": True}


class ChatCompletionRequest(BaseModel):
    model: str = Field(..., description="Model display name")
    messages: List[ChatCompletionMessage] = Field(
        ..., min_length=1, max_length=1000,
        description="Message list (1-1000 messages; agent tool loops may exceed 100)"
    )
    stream: bool = Field(default=False, description="Enable streaming")
    temperature: float = Field(default=1.0, ge=0, le=2, description="Sampling temperature")
    max_tokens: Optional[int] = Field(default=None, ge=1, description="Max output tokens")
    response_format: Optional[ResponseFormat] = Field(
        default=None, description="Structured output constraint"
    )
    prompt_name: Optional[str] = Field(
        default=None, description="Prompt template name"
    )
    prompt_version: Optional[str] = Field(
        default=None, description="Prompt template version"
    )
    tools: Optional[List[dict]] = Field(
        default=None, description="OpenAI function calling tool declarations (passthrough)"
    )
    tool_choice: Optional[Union[str, dict]] = Field(
        default=None, description="Tool choice policy: auto/none/required or a specific function"
    )

    @property
    def has_images(self) -> bool:
        return any(
            part.type == "image_url" and bool(part.image_url)
            for message in self.messages if isinstance(message.content, list)
            for part in message.content
        )


# --- Response ---


class ChatCompletionChoice(BaseModel):
    index: int = 0
    message: dict  # {"role": "assistant", "content": "..."}
    finish_reason: str = "stop"


class UsageInfo(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0
    reasoning_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: UsageInfo


def build_completion_response(
    model: str,
    content: str,
    usage: dict,
    finish_reason: str = "stop",
    tool_calls: Optional[list] = None,
) -> ChatCompletionResponse:
    """Build a ChatCompletionResponse from adapter output."""
    message: dict = {"role": "assistant", "content": content}
    if tool_calls:
        message["tool_calls"] = tool_calls
    return ChatCompletionResponse(
        id=f"chatcmpl-{uuid.uuid4().hex[:12]}",
        object="chat.completion",
        created=int(time.time()),
        model=model,
        choices=[
            ChatCompletionChoice(
                index=0,
                message=message,
                finish_reason=finish_reason,
            )
        ],
        usage=UsageInfo(
            prompt_tokens=usage.get("input", 0),
            completion_tokens=usage.get("output", 0),
            total_tokens=usage.get("input", 0) + usage.get("output", 0),
            cached_tokens=usage.get("cached", 0),
            reasoning_tokens=usage.get("reasoning", 0),
        ),
    )
