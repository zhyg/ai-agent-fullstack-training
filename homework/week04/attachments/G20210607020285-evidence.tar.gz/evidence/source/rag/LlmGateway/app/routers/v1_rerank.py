"""Rerank API router: POST /v1/rerank."""

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_api_key_user
from app.schemas.rerank import RerankRequest
from app.services.llm_gateway_service import LLMGatewayService
from app.gateway.errors import GatewayError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1", tags=["Rerank"])

# Max request body size: 1MB
MAX_BODY_SIZE = 1 * 1024 * 1024


def _get_gateway_service(request: Request) -> LLMGatewayService:
    """Get the gateway service from app state."""
    return request.app.state.gateway_service


@router.post("/rerank")
async def rerank(
    body: RerankRequest,
    request: Request,
    user: dict = Depends(get_api_key_user),
    db: Session = Depends(get_db),
):
    """Cohere-compatible Rerank endpoint.

    Accepts a query and candidate documents, returns results sorted by relevance.
    Authentication: API Key Bearer Token.
    """
    # Request body size check
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_BODY_SIZE:
        return JSONResponse(
            status_code=413,
            content={
                "error": {
                    "message": f"Request body too large. Max {MAX_BODY_SIZE // 1024 // 1024}MB allowed.",
                    "type": "invalid_request_error",
                    "code": "request_too_large",
                }
            },
        )

    gateway_service = _get_gateway_service(request)

    try:
        response = await gateway_service.process_rerank_request(body, user, db)
        return response.model_dump()
    except GatewayError as e:
        return JSONResponse(
            status_code=e.http_status,
            content=e.to_dict(),
        )
    except Exception as e:
        logger.error(f"Unexpected error in rerank: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "message": "Internal server error",
                    "type": "internal_error",
                    "code": "internal_error",
                }
            },
        )
