"""Pydantic models for the Embeddings API (OpenAI-compatible)."""

from typing import List, Optional, Union

from pydantic import BaseModel, Field, field_validator


class EmbeddingRequest(BaseModel):
    """Request body for POST /v1/embeddings."""

    model: str = Field(
        ...,
        description="Name of the embedding model to use",
    )
    input: Union[str, List[str]] = Field(
        ...,
        description="Input text(s) to embed. A single string or a list of strings (max 2048).",
    )
    dimensions: Optional[int] = Field(
        None,
        gt=0,
        description="Override the default output dimensions of the model",
    )

    @field_validator("input")
    @classmethod
    def _validate_input(cls, v: Union[str, List[str]]) -> Union[str, List[str]]:
        if isinstance(v, list):
            if len(v) == 0:
                raise ValueError("input list must not be empty")
            if len(v) > 2048:
                raise ValueError("input list must not exceed 2048 items")
        return v


class EmbeddingData(BaseModel):
    """A single embedding vector in the response."""

    object: str = Field(
        "embedding",
        description="Fixed value: 'embedding'",
    )
    index: int = Field(
        ...,
        description="Index of the input text this embedding corresponds to",
    )
    embedding: List[float] = Field(
        ...,
        description="The embedding vector as a list of floats",
    )


class EmbeddingUsage(BaseModel):
    """Token usage for an embedding request."""

    prompt_tokens: int = Field(
        0,
        description="Number of tokens in the input",
    )
    total_tokens: int = Field(
        0,
        description="Total number of tokens used (equals prompt_tokens for embeddings)",
    )


class EmbeddingResponse(BaseModel):
    """Response body for POST /v1/embeddings (OpenAI-compatible)."""

    object: str = Field(
        "list",
        description="Fixed value: 'list'",
    )
    data: List[EmbeddingData] = Field(
        ...,
        description="List of embedding objects, one per input text",
    )
    model: str = Field(
        ...,
        description="The model used to generate the embeddings",
    )
    usage: EmbeddingUsage = Field(
        ...,
        description="Token usage statistics",
    )
