"""Pydantic models for the Rerank API (Cohere-compatible)."""

from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class RerankRequest(BaseModel):
    """Request body for POST /v1/rerank."""

    model: str = Field(
        ...,
        description="Name of the rerank model to use",
    )
    query: str = Field(
        ...,
        max_length=10000,
        description="Query text to rerank documents against",
    )
    documents: List[str] = Field(
        ...,
        min_length=1,
        max_length=500,
        description="List of candidate documents (1-500)",
    )
    top_n: Optional[int] = Field(
        None,
        ge=1,
        description="Return top N results. Must be <= len(documents)",
    )
    return_documents: bool = Field(
        True,
        description="Whether to return original document text in response",
    )


class RerankDocument(BaseModel):
    """Document object in rerank response (when return_documents=true)."""

    text: str = Field(
        ...,
        description="Original document text",
    )


class RerankResult(BaseModel):
    """A single reranking result."""

    index: int = Field(
        ...,
        description="Index of the document in the original input list",
    )
    relevance_score: float = Field(
        ...,
        description="Relevance score (higher = more relevant)",
    )
    document: Optional[RerankDocument] = Field(
        None,
        description="Original document text (when return_documents=true)",
    )


class RerankUsage(BaseModel):
    """Token usage for a rerank request."""

    prompt_tokens: int = Field(
        0,
        description="Number of tokens in the input (query + documents)",
    )
    total_tokens: int = Field(
        0,
        description="Total number of tokens used",
    )


class RerankResponse(BaseModel):
    """Response body for POST /v1/rerank (Cohere-compatible)."""

    id: str = Field(
        ...,
        description="Unique request identifier",
    )
    results: List[RerankResult] = Field(
        ...,
        description="Results sorted by relevance_score descending",
    )
    model: str = Field(
        ...,
        description="The model used for reranking",
    )
    usage: RerankUsage = Field(
        ...,
        description="Token usage statistics",
    )
