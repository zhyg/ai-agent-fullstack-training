"""Add multimodel fields: dimensions, max_input_tokens, supported_modalities.

Revision ID: d1e2f3a4b5c6
Revises: c8d9e0f1a2b3
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "d1e2f3a4b5c6"
down_revision: Union[str, None] = "c8d9e0f1a2b3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = "llm_gateway"


def upgrade() -> None:
    op.add_column(
        "models",
        sa.Column("dimensions", sa.Integer(), nullable=True, comment="Embedding 输出向量维度"),
        schema=SCHEMA,
    )
    op.add_column(
        "models",
        sa.Column("max_input_tokens", sa.Integer(), nullable=True, comment="模型单次最大输入 tokens"),
        schema=SCHEMA,
    )
    op.add_column(
        "models",
        sa.Column("supported_modalities", sa.JSON(), nullable=True, comment="支持的输入模态列表"),
        schema=SCHEMA,
    )


def downgrade() -> None:
    op.drop_column("models", "supported_modalities", schema=SCHEMA)
    op.drop_column("models", "max_input_tokens", schema=SCHEMA)
    op.drop_column("models", "dimensions", schema=SCHEMA)
