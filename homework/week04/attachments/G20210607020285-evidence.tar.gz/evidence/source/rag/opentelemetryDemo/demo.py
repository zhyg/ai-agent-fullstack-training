import json

from opentelemetry import trace
from opentelemetry.trace import StatusCode
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource

# 1. 注册服务资源信息
resource = Resource.create(attributes={"service.name": "financial-advisor-agent"})
provider = TracerProvider(resource=resource)

# 2. 配置 OTLP gRPC 导出器（发送至本地 OpenTelemetry Collector）
#    Collector 监听 4317 端口，再将数据转发到 Elasticsearch
otlp_exporter = OTLPSpanExporter(endpoint="http://localhost:4317", insecure=True)
provider.add_span_processor(BatchSpanProcessor(otlp_exporter))

# 3. 设置全局 Tracer
trace.set_tracer_provider(provider)
tracer = trace.get_tracer("agent.core", "1.0.0")


# 模拟工具执行函数：向量检索
def tool_vector_search(query: str, top_k: int = 3):
    with tracer.start_as_current_span("tool.vector_search") as span:
        span.set_attribute("gen_ai.tool.name", "vector_search")
        span.set_attribute("rag.retrieval.top_k", top_k)
        span.set_attribute("rag.query", query)

        # 模拟检索逻辑...
        mock_results = [{"doc_id": "doc_01", "score": 0.94, "content": "Q3 营收同比增长 15%..."}]

        span.set_attribute("rag.document.count", len(mock_results))
        return mock_results


# 核心 Agent 执行主循环
def run_financial_agent(user_id: str, session_id: str, user_prompt: str):
    # 根 Span：代表整个 Agent 执行会话
    with tracer.start_as_current_span("agent.run") as root_span:
        root_span.set_attribute("enduser.id", user_id)
        root_span.set_attribute("session.id", session_id)
        root_span.set_attribute("gen_ai.prompt", user_prompt)

        max_steps = 5
        current_step = 0

        while current_step < max_steps:
            current_step += 1

            # 子 Span 1：LLM 规划与思考阶段
            with tracer.start_as_current_span(f"agent.step_{current_step}.reasoning") as reason_span:
                reason_span.set_attribute("gen_ai.system", "openai")
                reason_span.set_attribute("gen_ai.request.model", "gpt-4o")
                reason_span.set_attribute("gen_ai.agent.step", current_step)

                # 模拟 LLM 响应与 Token 消耗
                input_tokens = 350 + (current_step * 50)
                output_tokens = 85
                reason_span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
                reason_span.set_attribute("gen_ai.usage.output_tokens", output_tokens)

                # 模拟模型输出：第一轮决定调用工具，第二轮生成最终结论
                if current_step == 1:
                    action = {"type": "call_tool", "tool": "vector_search", "args": {"query": "Q3 财务报表"}}
                else:
                    action = {"type": "finish", "response": "根据 Q3 财报，公司营收稳定增长..."}

                reason_span.add_event("llm_reasoning_decision", {"action_decision": json.dumps(action)})

            # 处理 Action
            if action["type"] == "call_tool":
                try:
                    # 子 Span 2：工具执行阶段
                    docs = tool_vector_search(**action["args"])
                except Exception as e:
                    root_span.record_exception(e)
                    root_span.set_status(StatusCode.ERROR, f"Tool execution failed: {str(e)}")
                    break
            elif action["type"] == "finish":
                root_span.set_attribute("gen_ai.completion", action["response"])
                root_span.set_status(StatusCode.OK)
                return action["response"]

        # 超出最大步数，记录警告与死循环风险
        root_span.set_status(StatusCode.ERROR, "Agent exceeded max reasoning steps.")
        return "很抱歉，处理您的请求超时。"


if __name__ == "__main__":
    result = run_financial_agent(
        user_id="user_001",
        session_id="session_abc",
        user_prompt="请分析 Q3 财务数据",
    )
    print(f"Agent 输出: {result}")
    # 等待 BatchSpanProcessor 将所有 span flush 到 Collector
    provider.force_flush(timeout_millis=10000)
    print("Trace 数据已发送至 OpenTelemetry Collector → Elasticsearch")


