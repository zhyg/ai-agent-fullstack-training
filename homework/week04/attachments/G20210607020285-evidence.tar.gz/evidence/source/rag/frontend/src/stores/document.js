import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as docApi from '../services/documentApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

/**
 * Convert API response (snake_case) to frontend format (camelCase).
 */
function toCamelCase(item) {
  return {
    id: item.id,
    name: item.name,
    description: item.description,
    tags: Array.isArray(item.tags) ? item.tags : [],
    fileSize: item.file_size,
    mimeType: item.mime_type,
    extension: item.extension,
    status: item.status,
    storagePath: item.storage_path,
    mdPath: item.md_path,
    chunkConfig: item.chunk_config,
    aiQuestionCount: item.ai_question_count,
    skippedFiles: item.skipped_files,
    errorMessage: item.error_message,
    folderId: item.folder_id,
    kbId: item.kb_id,
    createdAt: item.created_at,
    updatedAt: item.updated_at
  }
}

export const useDocumentStore = defineStore('document', () => {
  const documents = ref([])
  const total = ref(0)
  const loading = ref(false)
  let listRequestId = 0

  function clearDocuments() {
    listRequestId += 1
    documents.value = []
    total.value = 0
    loading.value = false
  }

  async function fetchDocuments(folderId, page = 1, pageSize = 20) {
    const requestId = ++listRequestId
    loading.value = true
    try {
      const data = await docApi.listDocuments(folderId, page, pageSize)
      if (requestId !== listRequestId) return
      documents.value = data.items.map(toCamelCase)
      total.value = data.total
    } catch (error) {
      console.error('Failed to fetch documents:', error)
    } finally {
      if (requestId === listRequestId) loading.value = false
    }
  }

  async function getDocument(docId) {
    try {
      const data = await docApi.getDocument(docId)
      return toCamelCase(data)
    } catch (error) {
      console.error('Failed to get document:', error)
      return null
    }
  }

  async function updateDocument(docId, data) {
    try {
      const result = await docApi.updateDocument(docId, data)
      const idx = documents.value.findIndex((d) => d.id === docId)
      if (idx !== -1) {
        documents.value[idx] = toCamelCase(result)
      }
      return { success: true }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function uploadDocument(folderId, file, chunkConfig = null, aiQuestionCount = 3) {
    try {
      const result = await docApi.uploadDocument(folderId, file, chunkConfig, aiQuestionCount)
      return { success: true, message: result.message }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function addTags(docId, tags) {
    try {
      const result = await docApi.addTags(docId, tags)
      const idx = documents.value.findIndex((d) => d.id === docId)
      if (idx !== -1) {
        documents.value[idx] = toCamelCase(result)
      }
      return { success: true }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function removeTag(docId, tag) {
    try {
      const result = await docApi.removeTag(docId, tag)
      const idx = documents.value.findIndex((d) => d.id === docId)
      if (idx !== -1) {
        documents.value[idx] = toCamelCase(result)
      }
      return { success: true }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function deleteDocument(docId) {
    try {
      await docApi.deleteDocument(docId)
      documents.value = documents.value.filter((d) => d.id !== docId)
      total.value = Math.max(0, total.value - 1)
      return { success: true }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function batchDeleteDocuments(docIds) {
    try {
      const result = await docApi.batchDeleteDocuments(docIds)
      // Remove deleted documents from local state
      const deletedIds = new Set(docIds)
      documents.value = documents.value.filter(
        (d) => !deletedIds.has(d.id)
      )
      total.value = Math.max(0, total.value - result.deleted)
      return { success: true, deleted: result.deleted, message: result.message }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function getDocumentFileUrl(docId) {
    try {
      const data = await docApi.getDocumentFileUrl(docId)
      return data.url
    } catch (error) {
      console.error('Failed to get document file URL:', error)
      return null
    }
  }

  async function getDocumentMarkdownPreview(docId, options) {
    const data = await docApi.getDocumentMarkdownPreview(docId, options)
    return data.content
  }

  function applyDocumentUpdate(data) {
    const updated = toCamelCase(data)
    const idx = documents.value.findIndex((doc) => doc.id === updated.id)
    if (idx !== -1) {
      documents.value[idx] = updated
    }
    return updated
  }

  function getDocumentById(docId) {
    return documents.value.find((d) => d.id === docId) || null
  }

  return {
    documents,
    total,
    loading,
    clearDocuments,
    fetchDocuments,
    getDocument,
    updateDocument,
    uploadDocument,
    addTags,
    removeTag,
    deleteDocument,
    batchDeleteDocuments,
    getDocumentFileUrl,
    getDocumentMarkdownPreview,
    getDocumentById,
    applyDocumentUpdate
  }
})
