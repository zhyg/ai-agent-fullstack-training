import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// ==================== Folder API ====================

export async function listFolders(kbId) {
  const res = await api.get(`/knowledge-bases/${kbId}/folders`)
  return res.data
}

export async function createFolder(kbId, data) {
  const res = await api.post(`/knowledge-bases/${kbId}/folders`, data)
  return res.data
}

export async function updateFolder(folderId, data) {
  const res = await api.put(`/folders/${folderId}`, data)
  return res.data
}

export async function deleteFolder(folderId) {
  const res = await api.delete(`/folders/${folderId}`)
  return res.data
}

export async function moveFolder(folderId, data) {
  const res = await api.put(`/folders/${folderId}/move`, data)
  return res.data
}

// ==================== Document API ====================

export async function listDocuments(folderId, page = 1, pageSize = 20) {
  const res = await api.get(`/folders/${folderId}/documents`, {
    params: { page, page_size: pageSize }
  })
  return res.data
}

export async function getDocument(docId) {
  const res = await api.get(`/documents/${docId}`)
  return res.data
}

export async function updateDocument(docId, data) {
  const res = await api.put(`/documents/${docId}`, data)
  return res.data
}

export async function uploadDocument(folderId, file, chunkConfig = null, aiQuestionCount = 3) {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('original_filename', file.name)
  const filenameBytes = new TextEncoder().encode(file.name)
  let filenameBinary = ''
  filenameBytes.forEach((byte) => {
    filenameBinary += String.fromCharCode(byte)
  })
  formData.append('original_filename_b64', btoa(filenameBinary))

  // Append chunk config if provided
  if (chunkConfig) {
    formData.append('chunk_strategy', chunkConfig.strategy || 'heading')
    formData.append('chunk_size', String(chunkConfig.chunkSize || 512))
    formData.append('chunk_overlap', String(chunkConfig.chunkOverlap || 80))
    if (chunkConfig.separators) {
      formData.append('separators', JSON.stringify(chunkConfig.separators))
    }
  }
  formData.append('ai_question_count', String(aiQuestionCount))

  const res = await api.post(`/folders/${folderId}/documents/upload`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 300000 // 5min for large uploads
  })
  return res.data
}

export async function reprocessDocument(docId, config) {
  const res = await api.post(`/documents/${docId}/reprocess`, {
    chunk_strategy: config.strategy || 'heading',
    chunk_size: config.chunkSize || 512,
    chunk_overlap: config.chunkOverlap || 80,
    separators: config.separators || null,
    ai_question_count: config.aiQuestionCount || 3,
  })
  return res.data
}

export async function addTags(docId, tags) {
  const res = await api.put(`/documents/${docId}/tags/add`, { tags })
  return res.data
}

export async function removeTag(docId, tag) {
  const res = await api.put(`/documents/${docId}/tags/remove`, { tag })
  return res.data
}

export async function deleteDocument(docId) {
  const res = await api.delete(`/documents/${docId}`)
  return res.data
}

export async function batchDeleteDocuments(documentIds) {
  const res = await api.post('/documents/batch-delete', { document_ids: documentIds })
  return res.data
}

export async function getDocumentFileUrl(docId) {
  const res = await api.get(`/documents/${docId}/file`)
  return res.data
}

export async function getDocumentMarkdownPreview(docId, { source = false } = {}) {
  const res = await api.get(`/documents/${docId}/markdown/preview`, { params: { source } })
  return res.data
}

export function connectDocumentStatus(docId) {
  const base = (api.defaults.baseURL || '/api/knowledge').replace(/\/+$/, '')
  const url = new URL(`${base}/documents/${encodeURIComponent(docId)}/status/ws`, window.location.href)
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
  return new WebSocket(url)
}

export default api
