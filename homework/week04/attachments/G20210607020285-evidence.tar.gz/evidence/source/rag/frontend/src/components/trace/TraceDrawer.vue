<template>
  <a-drawer
    :open="open"
    title="执行轨迹"
    placement="right"
    width="60%"
    :body-style="{ padding: '12px 16px' }"
    @close="$emit('update:open', false)"
  >
    <div v-if="loading" class="drawer-state">
      <a-spin tip="轨迹加载中..." />
    </div>

    <a-alert
      v-else-if="error"
      type="error"
      show-icon
      :message="error"
      class="drawer-state"
    >
      <template #action>
        <a-button size="small" @click="loadTrace">重试</a-button>
      </template>
    </a-alert>

    <a-alert
      v-else-if="notReadyReason"
      type="info"
      show-icon
      :message="notReadyMessage"
      class="drawer-state"
    >
      <template v-if="notReadyReason === 'pending'" #action>
        <a-button size="small" @click="loadTrace">重试</a-button>
      </template>
    </a-alert>

    <template v-else-if="flatSpans.length">
      <div class="trace-meta">
        <a-typography-text type="secondary" class="trace-id">TraceID: {{ traceId }}</a-typography-text>
        <a-button size="small" type="text" @click="loadTrace">
          <template #icon><ReloadOutlined /></template>
          刷新
        </a-button>
      </div>
      <a-tabs v-model:active-key="activeTab">
        <a-tab-pane key="timeline" tab="时间线">
          <TraceTimeline :spans="flatSpans" />
        </a-tab-pane>
        <a-tab-pane key="statistics" tab="统计">
          <StatisticsView :spans="flatSpans" />
        </a-tab-pane>
      </a-tabs>
    </template>
  </a-drawer>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { ReloadOutlined } from '@ant-design/icons-vue'
import { fetchMessageTrace } from '../../services/traceApi.js'
import { buildSpanTree } from './traceUtils.js'
import TraceTimeline from './TraceTimeline.vue'
import StatisticsView from './StatisticsView.vue'

const props = defineProps({
  open: { type: Boolean, default: false },
  chatId: { type: String, default: '' },
  message: { type: Object, default: null },
  // 可选注入（014 R11）：评测页传 () => fetchEvaluationItemTrace(runId, itemId)；
  // 缺省仍走 chatId/message 原逻辑，会话页零影响
  fetcher: { type: Function, default: null }
})

defineEmits(['update:open'])

const loading = ref(false)
const error = ref('')
const notReadyReason = ref('')
const flatSpans = ref([])
const traceId = ref('')
const activeTab = ref('timeline')

const notReadyMessage = computed(() => {
  if (notReadyReason.value === 'no_trace') return '该消息没有执行轨迹'
  if (notReadyReason.value === 'expired') return '轨迹已过期清理'
  return 'trace 写入中，稍后重试'
})

async function loadTrace() {
  if (!props.fetcher && (!props.chatId || !props.message?.id)) return
  loading.value = true
  error.value = ''
  notReadyReason.value = ''
  try {
    const result = props.fetcher
      ? await props.fetcher()
      : await fetchMessageTrace(props.chatId, props.message.id)
    if (!result.ready) {
      notReadyReason.value = result.reason || 'pending'
      flatSpans.value = []
      return
    }
    const trace = result.data?.[0]
    traceId.value = trace?.traceID || ''
    flatSpans.value = buildSpanTree(trace?.spans || [], trace?.processes || {})
  } catch (e) {
    error.value = e.message || '轨迹查询失败，请稍后重试'
    flatSpans.value = []
  } finally {
    loading.value = false
  }
}

// 打开抽屉时加载（每次打开重新查询，覆盖"写入中→重试"场景）；
// fetcher 变化（评测页切换题目）时同样重新加载
watch(
  () => [props.open, props.message?.id, props.fetcher],
  ([isOpen]) => {
    if (isOpen) {
      activeTab.value = 'timeline'
      loadTrace()
    }
  }
)
</script>

<style scoped>
.drawer-state { margin: 24px 0; }
.trace-meta { display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px; }
.trace-id { font-family: 'JetBrains Mono', 'SF Mono', monospace; font-size: 12px; }
</style>