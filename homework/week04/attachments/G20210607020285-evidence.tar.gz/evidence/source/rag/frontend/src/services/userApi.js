import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_USER_MANAGE_URL || '/api/user',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export async function register(data) {
  const res = await api.post('/auth/register', data)
  return res.data
}

export async function login(data) {
  const res = await api.post('/auth/login', data)
  return res.data
}

export async function logout() {
  const res = await api.post('/auth/logout')
  return res.data
}

export async function refreshToken(refreshToken) {
  const res = await api.post('/auth/refresh', { refresh_token: refreshToken })
  return res.data
}

export async function getMe() {
  const res = await api.get('/auth/me')
  return res.data
}

export default api
