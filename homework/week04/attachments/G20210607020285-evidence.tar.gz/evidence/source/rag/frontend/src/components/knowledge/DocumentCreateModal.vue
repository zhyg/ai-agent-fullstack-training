<template>
  <a-modal
    :open="visible"
    title="新建知识"
    ok-text="确认上传"
    cancel-text="取消"
    :confirm-loading="uploading"
    @ok="handleSubmit"
    @cancel="$emit('close')"
    :width="560"
  >
    <a-upload-dragger
      :before-upload="beforeUpload"
      :file-list="fileList"
      :max-count="1"
      @remove="handleRemove"
    >
      <p class="ant-upload-drag-icon">
        <InboxOutlined />
      </p>
      <p class="ant-upload-text">点击或拖拽文件到此处上传</p>
      <p class="ant-upload-hint">
        支持任意类型文件及 .zip .rar .7z .tar.gz 压缩包，单文件上限 500MB
      </p>
    </a-upload-dragger>

    <!-- 分块设置 tabs — 仅单文件上传时显示 -->
    <a-tabs
      v-if="fileList.length > 0 && !isCompressed"
      v-model:activeKey="activeTab"
      style="margin-top: 16px"
    >
      <a-tab-pane key="chunk" tab="分块设置">
        <ChunkSettingTab
          ref="chunkSettingRef"
          @update:config="onChunkConfigUpdate"
        />
      </a-tab-pane>
      <a-tab-pane key="ai" tab="AI问题生成">
        <AiQuestionTab v-model:count="aiQuestionCount" />
      </a-tab-pane>
    </a-tabs>
  </a-modal>
</template>

<script setup>
import { ref, watch, computed } from 'vue'
import { InboxOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import ChunkSettingTab from './ChunkSettingTab.vue'
import AiQuestionTab from './AiQuestionTab.vue'

const MAX_FILE_SIZE = 524288000 // 500MB
const COMPRESSED_EXTS = ['.zip', '.rar', '.7z', '.tar.gz', '.tgz']

const props = defineProps({
  visible: { type: Boolean, required: true },
  folderId: { type: String, default: null },
  kbId: { type: String, required: true }
})

const emit = defineEmits(['close', 'submit'])

const fileList = ref([])
const uploading = ref(false)
const activeTab = ref('chunk')
const chunkSettingRef = ref(null)
const chunkConfig = ref({
  strategy: 'heading',
  chunkSize: 512,
  chunkOverlap: 80,
  separators: null,
})
const aiQuestionCount = ref(3)

const isCompressed = computed(() => {
  if (fileList.value.length === 0) return false
  const name = fileList.value[0].name.toLowerCase()
  return COMPRESSED_EXTS.some((ext) => name.endsWith(ext))
})

watch(
  () => props.visible,
  (val) => {
    if (!val) {
      fileList.value = []
      activeTab.value = 'chunk'
      if (chunkSettingRef.value) {
        chunkSettingRef.value.reset()
      }
    }
  }
)

function beforeUpload(file) {
  if (file.size > MAX_FILE_SIZE) {
    message.error('文件大小超过 500MB 限制')
    return false
  }
  fileList.value = [file]
  return false // 不自动上传
}

function handleRemove() {
  fileList.value = []
}

function onChunkConfigUpdate(config) {
  chunkConfig.value = { ...config }
}

function handleSubmit() {
  if (!props.folderId) {
    message.warning('请先选择目录')
    return
  }
  if (fileList.value.length === 0) {
    message.warning('请先选择文件')
    return
  }
  emit('submit', {
    file: fileList.value[0],
    folderId: props.folderId,
    kbId: props.kbId,
    chunkConfig: isCompressed.value ? null : chunkConfig.value,
    aiQuestionCount: isCompressed.value ? 3 : aiQuestionCount.value,
  })
}
</script>
