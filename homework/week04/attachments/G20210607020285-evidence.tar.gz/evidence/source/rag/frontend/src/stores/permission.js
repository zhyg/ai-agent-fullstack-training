import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as permissionApi from '../services/permissionApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

export const usePermissionStore = defineStore('permission', () => {
  const users = ref([])
  const usersTotal = ref(0)
  const roles = ref([])
  const permissions = ref([])
  const loading = ref(false)

  async function fetchUsers(page = 1, pageSize = 20) {
    loading.value = true
    try {
      const data = await permissionApi.listUsers(page, pageSize)
      users.value = data.items || []
      usersTotal.value = data.total || 0
    } catch (e) {
      console.error('Failed to fetch users:', e)
      throw e
    } finally {
      loading.value = false
    }
  }

  async function createUser(userData) {
    try {
      const user = await permissionApi.createUser(userData)
      await fetchUsers()
      return user
    } catch (e) {
      throw e
    }
  }

  async function updateUser(userId, userData) {
    try {
      const user = await permissionApi.updateUser(userId, userData)
      await fetchUsers()
      return user
    } catch (e) {
      throw e
    }
  }

  async function deleteUser(userId) {
    try {
      await permissionApi.deleteUser(userId)
      await fetchUsers()
    } catch (e) {
      throw e
    }
  }

  async function fetchRoles() {
    try {
      const data = await permissionApi.listRoles()
      roles.value = data.items || []
    } catch (e) {
      console.error('Failed to fetch roles:', e)
      throw e
    }
  }

  async function createRole(roleData) {
    try {
      const role = await permissionApi.createRole(roleData)
      await fetchRoles()
      return role
    } catch (e) {
      throw e
    }
  }

  async function updateRole(roleId, roleData) {
    try {
      const role = await permissionApi.updateRole(roleId, roleData)
      await fetchRoles()
      return role
    } catch (e) {
      throw e
    }
  }

  async function deleteRole(roleId) {
    try {
      await permissionApi.deleteRole(roleId)
      await fetchRoles()
    } catch (e) {
      throw e
    }
  }

  async function fetchPermissions() {
    try {
      const data = await permissionApi.listPermissions()
      permissions.value = data.items || []
    } catch (e) {
      console.error('Failed to fetch permissions:', e)
    }
  }

  return {
    users, usersTotal, roles, permissions, loading,
    fetchUsers, createUser, updateUser, deleteUser,
    fetchRoles, createRole, updateRole, deleteRole,
    fetchPermissions
  }
})
