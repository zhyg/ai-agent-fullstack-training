<template>
  <div>
    <p class="tools-hint">勾选智能体可调用的工具；取消勾选后，对应提示词用途（问题重写/压缩）转为可选</p>
    <a-checkbox-group v-model:value="draft.config.tools" class="tools-grid">
      <a-checkbox v-for="tool in AGENT_TOOLS" :key="tool.key" :value="tool.key">
        {{ tool.label }}
      </a-checkbox>
    </a-checkbox-group>
  </div>
</template>

<script setup>
import { watch } from 'vue'
import { AGENT_TOOLS, TOOL_KEYS } from '../../../utils/agent.js'

const props = defineProps({
  draft: { type: Object, required: true }
})

// 默认全部勾选（FR-011），勾选集合持久化到 config.tools
watch(
  () => props.draft.config.tools,
  (v) => {
    if (v == null) props.draft.config.tools = [...TOOL_KEYS]
  },
  { immediate: true }
)
</script>

<style scoped>
.tools-hint {
  font-size: 12px;
  color: #8c8c8c;
  margin-bottom: 12px;
}

.tools-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px 8px;
}
</style>