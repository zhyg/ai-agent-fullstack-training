<template>
  <div>
    <a-spin :spinning="promptStore.loading">
      <PromptList
        :prompts="promptStore.prompts"
        @create="openCreateModal"
        @edit="openEditDrawer"
        @delete="handleDelete"
      />
    </a-spin>

    <!-- 新建提示词对话框 -->
    <PromptCreateModal
      :visible="createModalVisible"
      @close="closeCreateModal"
      @submit="handleCreateSubmit"
    />

    <!-- 设置提示词抽屉 -->
    <PromptFormDrawer
      :visible="editDrawerVisible"
      :prompt="editingPrompt"
      @close="closeEditDrawer"
      @submit="handleEditSubmit"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { Modal, message } from 'ant-design-vue'
import { usePromptStore } from '../stores/prompt.js'
import PromptList from '../components/prompt/PromptList.vue'
import PromptCreateModal from '../components/prompt/PromptCreateModal.vue'
import PromptFormDrawer from '../components/prompt/PromptFormDrawer.vue'

const promptStore = usePromptStore()

const createModalVisible = ref(false)
const editDrawerVisible = ref(false)
const editingPrompt = ref(null)

onMounted(() => {
  promptStore.fetchPrompts()
})

function openCreateModal() {
  createModalVisible.value = true
}

function closeCreateModal() {
  createModalVisible.value = false
}

function openEditDrawer(prompt) {
  editingPrompt.value = prompt
  editDrawerVisible.value = true
}

function closeEditDrawer() {
  editDrawerVisible.value = false
  editingPrompt.value = null
}

async function handleCreateSubmit(data) {
  const result = await promptStore.createPrompt(data)
  if (result.success) {
    closeCreateModal()
    message.success(result.message)
  } else {
    message.error(result.message)
  }
}

async function handleEditSubmit(data) {
  if (editingPrompt.value) {
    const result = await promptStore.updatePrompt(editingPrompt.value.id, data)
    if (result.success) {
      closeEditDrawer()
      message.success(result.message)
    } else {
      message.error(result.message)
    }
  }
}

function handleDelete(prompt) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除提示词 "${prompt.name}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    async onOk() {
      const result = await promptStore.deletePrompt(prompt.id)
      if (result.success) {
        message.success(result.message)
      } else {
        message.error(result.message)
      }
    }
  })
}
</script>
