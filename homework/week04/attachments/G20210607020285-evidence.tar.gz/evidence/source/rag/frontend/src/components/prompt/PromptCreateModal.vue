<template>
  <a-modal
    :title="'新建提示词'"
    :open="visible"
    @cancel="handleClose"
    @ok="handleSubmit"
    width="700px"
  >
    <a-form
      ref="formRef"
      :model="formState"
      :rules="rules"
      layout="vertical"
    >
      <a-form-item label="提示词名称" name="name">
        <a-input v-model:value="formState.name" placeholder="请输入提示词名称" />
      </a-form-item>
      <a-form-item label="版本" name="version">
        <a-input v-model:value="formState.version" placeholder="请输入版本号（可选，默认 1.0.0）" />
      </a-form-item>
      <a-form-item label="描述" name="description">
        <a-textarea
          v-model:value="formState.description"
          placeholder="请输入提示词描述"
          :rows="3"
        />
      </a-form-item>
      <a-form-item label="内容" name="content">
        <a-textarea
          v-model:value="formState.content"
          placeholder="请输入提示词内容"
          :rows="8"
        />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  }
})

const emit = defineEmits(['close', 'submit'])

const formRef = ref(null)
const formState = ref({
  name: '',
  version: '',
  description: '',
  content: ''
})

const rules = {
  name: [{ required: true, message: '请输入提示词名称' }],
  content: [{ required: true, message: '请输入提示词内容' }]
}

watch(() => props.visible, (val) => {
  if (val) {
    formState.value = {
      name: '',
      version: '',
      description: '',
      content: ''
    }
  }
})

function handleSubmit() {
  formRef.value.validate().then(() => {
    emit('submit', { ...formState.value })
    handleClose()
  })
}

function handleClose() {
  emit('close')
  formRef.value?.resetFields()
}
</script>
