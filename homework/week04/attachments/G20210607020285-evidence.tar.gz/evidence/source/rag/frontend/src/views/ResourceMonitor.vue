<template>
  <div class="monitor-page">
    <h2 class="page-title">资源消耗监控</h2>
    <p class="page-desc">按用户与时间周期查看各模型的 token 消耗与费用（北京时间，数据来自 Prometheus）</p>

    <!-- 分段式胶囊 Tab（全站视觉语言）：token/费用两 Tab 筛选状态独立（US2） -->
    <div class="capsule-tabs">
      <button
        v-for="tab in tabs"
        :key="tab.key"
        class="capsule-tab"
        :class="{ active: activeTab === tab.key }"
        @click="switchTab(tab.key)"
      >
        <component :is="tab.icon" />
        <span>{{ tab.label }}</span>
      </button>
    </div>

    <a-card :bordered="false" class="monitor-card">
      <div class="sub-view-bar">
        <a-radio-group :value="current.scope" button-style="solid" size="small" @change="onScopeChange">
          <a-radio-button value="user_daily">人日</a-radio-button>
          <a-radio-button value="user_monthly">人月</a-radio-button>
          <!-- 所有人月仅管理员可见（US3，双保险：store + 后端 options） -->
          <a-radio-button v-if="isAdmin" value="all_monthly">所有人月</a-radio-button>
        </a-radio-group>
      </div>

      <MonitorFilters
        :scope="current.scope"
        v-model:filters="current.filters"
        :options="options"
        :loading="loading"
        @query="doQuery(activeTab)"
      />

      <a-divider style="margin: 16px 0" />

      <div class="chart-area">
        <a-spin :spinning="loading">
          <a-alert
            v-if="current.data && current.data.out_of_retention"
            type="warning"
            show-icon
            message="请求期间超出指标数据保留期，暂无数据，请查询更近的时间段"
          />
          <a-empty
            v-else-if="!current.data || !current.data.series.length"
            :description="current.data ? '查询区间内无消耗数据' : '点击查询加载数据'"
          />
          <ConsumptionChart
            v-else
            :buckets="current.data.buckets"
            :series="current.data.series"
            :metric="activeTab"
          />
        </a-spin>
      </div>
    </a-card>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { message } from 'ant-design-vue'
import { BarChartOutlined, DollarOutlined } from '@ant-design/icons-vue'
import dayjs from 'dayjs'
import { useUserStore } from '../stores/user'
import { getMonitorOptions, getConsumptionSeries } from '../services/monitorApi'
import MonitorFilters from '../components/monitor/MonitorFilters.vue'
import ConsumptionChart from '../components/monitor/ConsumptionChart.vue'

// 015-resource-consumption-monitor T014/T018：token/费用双 Tab + 人日/人月子视图
// 查询触发：首次进页自动查；切换主 Tab/子视图自动刷新；筛选条件变更仍点"查询"；请求自增序号防竞态
const userStore = useUserStore()

const tabs = [
  { key: 'tokens', label: 'token 消耗', icon: BarChartOutlined },
  { key: 'cost', label: '费用消耗', icon: DollarOutlined },
]
const activeTab = ref('tokens')

function makeTabState() {
  return {
    scope: 'user_daily',
    filters: {
      user_email: '',
      models: [], // 空 = 全选（决策12）
      month: dayjs().format('YYYY-MM'),
      year: dayjs().year(),
    },
    data: null,
  }
}

// 各 Tab 独立筛选状态，切换互不干扰（spec US2 场景 1-3）
const tabState = reactive({ tokens: makeTabState(), cost: makeTabState() })
const current = computed(() => tabState[activeTab.value])

const options = ref({ user_emails: [], models: [], is_admin: false })
// 管理员判定双保险（US3 T023）：JWT permissions + 后端 options.is_admin
const isAdmin = computed(() => userStore.isAdmin || options.value.is_admin)
const loading = ref(false)
let reqSeq = 0

function buildParams(tabKey) {
  const st = tabState[tabKey]
  const params = { metric: tabKey, scope: st.scope }
  if (st.scope !== 'all_monthly') params.user_email = st.filters.user_email
  if (st.filters.models.length) params.models = st.filters.models.join(',')
  if (st.scope === 'user_daily') params.month = st.filters.month
  else params.year = st.filters.year
  return params
}

async function doQuery(tabKey) {
  const seq = ++reqSeq
  loading.value = true
  try {
    const data = await getConsumptionSeries(buildParams(tabKey))
    if (seq !== reqSeq) return // 已有更新的请求，丢弃过期响应
    tabState[tabKey].data = data
  } catch (e) {
    if (seq === reqSeq) message.error(e.message || '查询消耗数据失败，请稍后重试')
  } finally {
    if (seq === reqSeq) loading.value = false
  }
}

function switchTab(key) {
  if (activeTab.value === key) return
  activeTab.value = key
  doQuery(key) // 切换主 Tab 即刷新对应数据
}

function onScopeChange(e) {
  const scope = e.target.value
  if (scope === current.value.scope) return
  current.value.scope = scope
  doQuery(activeTab.value) // 切换子视图即刷新，无需再点"查询"
}

onMounted(async () => {
  try {
    options.value = await getMonitorOptions()
  } catch (e) {
    message.error(e.message || '加载筛选选项失败')
  }
  // 默认当前登录用户（决策7）；不在选项列表时回退首个
  const ownEmail = userStore.currentUser?.email
  const defaultEmail = options.value.user_emails.includes(ownEmail)
    ? ownEmail
    : options.value.user_emails[0] || ''
  Object.values(tabState).forEach((st) => { st.filters.user_email = defaultEmail })
  if (defaultEmail) doQuery(activeTab.value)
})
</script>

<style scoped>
.monitor-page {
  padding: 4px;
}
.page-title {
  margin: 0 0 4px;
  font-size: 20px;
  font-weight: 700;
  color: #1f2733;
}
.page-desc {
  margin: 0 0 16px;
  color: #7a8499;
  font-size: 13px;
}

/* 分段式胶囊 Tab：浅蓝灰分段容器 + 品牌蓝渐变选中胶囊 */
.capsule-tabs {
  display: inline-flex;
  gap: 4px;
  padding: 4px;
  margin-bottom: 16px;
  background: #e8edf6;
  border: 1px solid #d4dcec;
  border-radius: 999px;
}
.capsule-tab {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  padding: 0 20px;
  border: none;
  border-radius: 999px;
  background: transparent;
  color: #4a5568;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.25s ease;
}
.capsule-tab:hover {
  background: #fff;
  color: #1677ff;
}
.capsule-tab.active {
  background: linear-gradient(135deg, #1677ff, #4096ff);
  color: #fff;
  box-shadow: 0 2px 8px rgba(22, 119, 255, 0.4);
}

.monitor-card {
  border-radius: 12px;
  box-shadow: 0 1px 4px rgba(31, 39, 51, 0.06);
}
.sub-view-bar {
  margin-bottom: 14px;
}
.chart-area {
  min-height: 420px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.chart-area :deep(.ant-spin-nested-loading),
.chart-area :deep(.ant-spin-container) {
  width: 100%;
}
</style>