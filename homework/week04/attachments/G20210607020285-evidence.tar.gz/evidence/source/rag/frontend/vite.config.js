import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173,
    proxy: {
      '/api/user': {
        target: 'http://localhost:8001',
        changeOrigin: true
      },
      '/api/knowledge': {
        target: 'http://localhost:8002',
        changeOrigin: true,
        ws: true
      },
      '/api/llm': {
        target: 'http://localhost:8003',
        changeOrigin: true
      }
    }
  }
})
