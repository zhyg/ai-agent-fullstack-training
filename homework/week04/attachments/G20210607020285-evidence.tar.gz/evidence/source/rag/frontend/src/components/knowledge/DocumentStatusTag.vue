<template>
  <a-tag :color="presentation.color">{{ presentation.text }}</a-tag>
  <a-tooltip v-if="connectionError" :title="connectionError">
    <a-tag color="orange">{{ connectionError }}</a-tag>
  </a-tooltip>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  status: String,
  connectionError: String
})

const statuses = new Map([
  ['pending', { color: 'default', text: '等待处理' }],
  ['parsing', { color: 'processing', text: '解析中' }],
  ['chunking', { color: 'processing', text: '切分中' }],
  ['embedding', { color: 'processing', text: '向量化中' }],
  ['ai_generating', { color: 'processing', text: 'AI 生成中' }],
  ['completed', { color: 'success', text: '处理完成' }],
  ['success', { color: 'success', text: '解析完成' }],
  ['failed', { color: 'error', text: '处理失败' }]
])

const presentation = computed(() => statuses.get(props.status) || {
  color: 'default',
  text: '未知状态'
})
</script>
