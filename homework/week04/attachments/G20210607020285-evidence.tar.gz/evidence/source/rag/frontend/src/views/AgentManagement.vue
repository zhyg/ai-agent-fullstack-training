<template>
  <div class="agent-page">
    <div class="page-header">
      <h2>智能体</h2>
      <p class="page-subtitle">系统预置智能体，管理员可编辑配置与停用/启用</p>
    </div>
    <a-spin :spinning="agentStore.loading">
      <a-row :gutter="[16, 16]">
        <a-col v-for="agent in agentStore.agents" :key="agent.id" :xs="24" :md="12" :lg="8">
          <AgentCard
            :agent="agent"
            :is-admin="userStore.isAdmin"
            @edit="onEdit"
            @toggle-status="onToggleStatus"
          />
        </a-col>
      </a-row>
      <a-empty v-if="!agentStore.loading && agentStore.agents.length === 0" description="暂无智能体" />
    </a-spin>
    <AgentEditModal />
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { message } from 'ant-design-vue'
import AgentCard from '../components/agent/AgentCard.vue'
import AgentEditModal from '../components/agent/AgentEditModal.vue'
import { useAgentStore } from '../stores/agent.js'
import { useUserStore } from '../stores/user.js'

const agentStore = useAgentStore()
const userStore = useUserStore()

onMounted(() => {
  agentStore.fetchAgents()
})

async function onToggleStatus(agent, status) {
  const result = await agentStore.toggleStatus(agent.id, status)
  if (result.success) {
    message.success(result.message)
  } else {
    message.error(result.message)
  }
}

function onEdit(agent) {
  // 打开编辑弹窗（深拷贝草稿）；保存成功后 store 刷新列表，卡片自动回显新名称/图标/描述
  agentStore.openEdit(agent)
}
</script>

<style scoped>
.agent-page {
  padding: 8px 4px;
}

.page-header {
  margin-bottom: 20px;
}

.page-header h2 {
  font-size: 20px;
  font-weight: 600;
  color: #262626;
  margin: 0 0 4px;
}

.page-subtitle {
  font-size: 13px;
  color: #8c8c8c;
  margin: 0;
}
</style>