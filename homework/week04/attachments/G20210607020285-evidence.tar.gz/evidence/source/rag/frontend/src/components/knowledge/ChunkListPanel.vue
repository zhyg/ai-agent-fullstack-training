<template>
  <div class="chunk-list-panel">
    <!-- Filter bar -->
    <div class="filter-bar">
      <a-select
        v-model:value="selectedType"
        style="width: 160px"
        placeholder="所有类型"
        allow-clear
        @change="handleFilterChange"
      >
        <a-select-option value="text">文本</a-select-option>
        <a-select-option value="image">图片</a-select-option>
        <a-select-option value="table_row">表格行</a-select-option>
        <a-select-option value="ai_question">AI问题</a-select-option>
      </a-select>
      <span class="chunk-total">共 {{ chunkStore.total }} 个分片</span>
    </div>

    <!-- Chunk list -->
    <a-spin :spinning="chunkStore.loading">
      <div v-if="chunkStore.chunks.length > 0" class="chunk-list">
        <ChunkCard
          v-for="chunk in chunkStore.chunks"
          :key="chunk.chunk_id"
          :chunk="chunk"
          :has-children="true"
          @show-children="handleShowChildren"
        />
      </div>
      <a-empty v-else description="暂无分片数据" />
    </a-spin>

    <!-- Pagination -->
    <a-pagination
      v-if="chunkStore.total > pageSize"
      v-model:current="currentPage"
      :total="chunkStore.total"
      :page-size="pageSize"
      size="small"
      style="margin-top: 12px; text-align: right"
      @change="handlePageChange"
    />

    <!-- Children drawer -->
    <a-drawer
      :open="childrenDrawerVisible"
      title="子分片详情"
      :width="480"
      @close="childrenDrawerVisible = false"
    >
      <a-spin :spinning="chunkStore.childrenLoading">
        <div v-if="chunkStore.currentChildren.length > 0">
          <ChunkCard
            v-for="child in chunkStore.currentChildren"
            :key="child.chunk_id"
            :chunk="child"
          />
        </div>
        <a-empty v-else description="无子分片" />
      </a-spin>
    </a-drawer>
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'
import { useChunkStore } from '../../stores/chunk.js'
import ChunkCard from './ChunkCard.vue'

const props = defineProps({
  docId: { type: String, required: true },
  kbId: { type: String, required: true },
})

const chunkStore = useChunkStore()
const currentPage = ref(1)
const pageSize = 50
const selectedType = ref(null)
const childrenDrawerVisible = ref(false)

function loadChunks() {
  const params = {
    page: currentPage.value,
    page_size: pageSize,
  }
  if (selectedType.value) {
    params.chunk_type = selectedType.value
  }
  chunkStore.fetchChunks(props.docId, params)
}

function handleFilterChange() {
  currentPage.value = 1
  loadChunks()
}

function handlePageChange(page) {
  currentPage.value = page
  loadChunks()
}

function handleShowChildren(chunk) {
  childrenDrawerVisible.value = true
  chunkStore.fetchChunkChildren(chunk.chunk_id, props.kbId)
}

watch(() => props.docId, () => {
  currentPage.value = 1
  selectedType.value = null
  loadChunks()
})

onMounted(() => {
  loadChunks()
})
</script>

<style scoped>
.chunk-list-panel {
  padding: 8px 0;
}
.filter-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}
.chunk-total {
  font-size: 13px;
  color: #8c8c8c;
}
.chunk-list {
  max-height: 600px;
  overflow-y: auto;
}
</style>
