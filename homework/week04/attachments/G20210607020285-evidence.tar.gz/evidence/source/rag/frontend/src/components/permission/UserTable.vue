<template>
  <div class="user-table">
    <div class="table-toolbar">
      <a-button type="primary" @click="$emit('create')">
        <template #icon><PlusOutlined /></template>
        新增用户
      </a-button>
    </div>
    <a-table
      :columns="columns"
      :data-source="users"
      row-key="id"
      :pagination="{ current: page, pageSize: pageSize, total: total, showSizeChanger: true, showTotal: (t) => `共 ${t} 条` }"
      :loading="loading"
      @change="handleTableChange"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'roles'">
          <a-space :size="[4, 4]" wrap>
            <a-tag v-for="roleId in record.role_ids" :key="roleId" color="orange">
              {{ roleName(roleId) }}
            </a-tag>
            <span v-if="!record.role_ids?.length" style="color: #8c8c8c;">未分配</span>
          </a-space>
        </template>
        <template v-else-if="column.key === 'created_at'">
          {{ formatTime(record.created_at) }}
        </template>
        <template v-else-if="column.key === 'actions'">
          <a-space :size="4">
            <a-button type="text" title="编辑" @click="$emit('edit', record)">
              <template #icon><EditOutlined /></template>
            </a-button>
            <a-button type="text" danger title="删除" @click="confirmDelete(record)">
              <template #icon><DeleteOutlined /></template>
            </a-button>
          </a-space>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup>
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { Modal } from 'ant-design-vue'

const props = defineProps({
  users: { type: Array, default: () => [] },
  roles: { type: Array, default: () => [] },
  total: { type: Number, default: 0 },
  page: { type: Number, default: 1 },
  pageSize: { type: Number, default: 20 },
  loading: { type: Boolean, default: false }
})

const emit = defineEmits(['create', 'edit', 'delete', 'page-change'])

const columns = [
  { title: '用户名', dataIndex: 'uid', width: 150 },
  { title: '邮箱', dataIndex: 'email', width: 220 },
  { title: '角色', key: 'roles', width: 200 },
  { title: '创建时间', key: 'created_at', width: 180 },
  { title: '操作', key: 'actions', width: 120, align: 'center' }
]

function roleName(roleId) {
  const role = props.roles.find(r => r.id === roleId)
  return role ? role.name : '角色已删除'
}

function formatTime(timeStr) {
  if (!timeStr) return '—'
  return new Date(timeStr).toLocaleString('zh-CN', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false
  }).replaceAll('/', '-')
}

function confirmDelete(record) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除用户 "${record.uid}" 吗？其在知识库中的提示词和会话将保留。`,
    okText: '确认',
    okType: 'danger',
    cancelText: '取消',
    onOk() { emit('delete', record.id) }
  })
}

function handleTableChange(pagination) {
  emit('page-change', { page: pagination.current, pageSize: pagination.pageSize })
}
</script>

<style scoped>
.table-toolbar { display: flex; justify-content: flex-end; margin-bottom: 16px; }
</style>
