<template>
  <div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
      <h2 style="margin: 0;">提示词管理</h2>
      <a-button type="primary" @click="$emit('create')">新建提示词</a-button>
    </div>
    <a-empty v-if="prompts.length === 0" description="暂无提示词，点击右上角新建">
      <a-button type="primary" @click="$emit('create')">新建提示词</a-button>
    </a-empty>
    <div v-else>
      <PromptCard
        v-for="prompt in prompts"
        :key="prompt.id"
        :prompt="prompt"
        @edit="(p) => $emit('edit', p)"
        @delete="(p) => $emit('delete', p)"
      />
    </div>
  </div>
</template>

<script setup>
import PromptCard from './PromptCard.vue'

defineProps({
  prompts: {
    type: Array,
    required: true
  }
})

defineEmits(['create', 'edit', 'delete'])
</script>
