<template>
  <div class="permission-management">
    <a-tabs :activeKey="activeTab" @change="changeTab">
      <a-tab-pane key="users" tab="用户管理" />
      <a-tab-pane key="roles" tab="角色管理" />
    </a-tabs>

    <div v-show="activeTab === 'users'">
      <a-spin :spinning="permissionStore.loading">
        <UserTable
          :users="permissionStore.users"
          :roles="permissionStore.roles"
          :total="permissionStore.usersTotal"
          :page="userPage"
          :page-size="userPageSize"
          :loading="permissionStore.loading"
          @create="openCreateUser"
          @edit="openEditUser"
          @delete="handleDeleteUser"
          @page-change="handleUserPageChange"
        />
      </a-spin>
    </div>

    <div v-show="activeTab === 'roles'">
      <a-spin :spinning="permissionStore.loading">
        <RoleTable
          :roles="permissionStore.roles"
          :users="permissionStore.users"
          :loading="permissionStore.loading"
          @create="openCreateRole"
          @edit="openEditRole"
          @delete="handleDeleteRole"
        />
      </a-spin>
    </div>

    <UserFormModal
      :open="userModalOpen"
      :editing-id="editingUserId"
      :initial-uid="editingUserUid"
      :initial-email="editingUserEmail"
      :initial-role-ids="editingUserRoleIds"
      :roles="permissionStore.roles"
      @close="closeUserModal"
      @submit="handleSubmitUser"
    />

    <RoleFormModal
      :open="roleModalOpen"
      :editing-id="editingRoleId"
      :initial-name="editingRoleName"
      :initial-description="editingRoleDescription"
      @close="closeRoleModal"
      @submit="handleSubmitRole"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { usePermissionStore } from '../stores/permission.js'
import { extractErrorMessage } from '../utils/errorHandler.js'
import UserTable from '../components/permission/UserTable.vue'
import RoleTable from '../components/permission/RoleTable.vue'
import UserFormModal from '../components/permission/UserFormModal.vue'
import RoleFormModal from '../components/permission/RoleFormModal.vue'

const permissionStore = usePermissionStore()
const activeTab = ref('users')

// User pagination
const userPage = ref(1)
const userPageSize = ref(20)

// User modal state
const userModalOpen = ref(false)
const editingUserId = ref(null)
const editingUserUid = ref('')
const editingUserEmail = ref('')
const editingUserRoleIds = ref([])

// Role modal state
const roleModalOpen = ref(false)
const editingRoleId = ref(null)
const editingRoleName = ref('')
const editingRoleDescription = ref('')

onMounted(async () => {
  await Promise.all([
    permissionStore.fetchUsers(userPage.value, userPageSize.value),
    permissionStore.fetchRoles()
  ])
})

function changeTab(tab) {
  activeTab.value = tab
}

// --- User operations ---
function openCreateUser() {
  editingUserId.value = null
  editingUserUid.value = ''
  editingUserEmail.value = ''
  editingUserRoleIds.value = []
  userModalOpen.value = true
}

function openEditUser(record) {
  editingUserId.value = record.id
  editingUserUid.value = record.uid
  editingUserEmail.value = record.email
  editingUserRoleIds.value = [...(record.role_ids || [])]
  userModalOpen.value = true
}

function closeUserModal() {
  userModalOpen.value = false
}

async function handleSubmitUser(data) {
  try {
    if (editingUserId.value) {
      await permissionStore.updateUser(editingUserId.value, data)
      message.success('用户更新成功')
    } else {
      await permissionStore.createUser(data)
      message.success('用户创建成功')
    }
    closeUserModal()
    // Refresh roles too (user role_ids may have changed)
    await permissionStore.fetchRoles()
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}

async function handleDeleteUser(userId) {
  try {
    await permissionStore.deleteUser(userId)
    message.success('用户删除成功')
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}

function handleUserPageChange({ page, pageSize }) {
  userPage.value = page
  userPageSize.value = pageSize
  permissionStore.fetchUsers(page, pageSize)
}

// --- Role operations ---
function openCreateRole() {
  editingRoleId.value = null
  editingRoleName.value = ''
  editingRoleDescription.value = ''
  roleModalOpen.value = true
}

function openEditRole(record) {
  editingRoleId.value = record.id
  editingRoleName.value = record.name || ''
  editingRoleDescription.value = record.description || ''
  roleModalOpen.value = true
}

function closeRoleModal() {
  roleModalOpen.value = false
}

async function handleSubmitRole(data) {
  try {
    if (editingRoleId.value) {
      await permissionStore.updateRole(editingRoleId.value, data)
      message.success('角色更新成功')
    } else {
      await permissionStore.createRole(data)
      message.success('角色创建成功')
    }
    closeRoleModal()
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}

async function handleDeleteRole(roleId) {
  try {
    await permissionStore.deleteRole(roleId)
    message.success('角色删除成功')
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}
</script>

<style scoped>
.permission-management {
  min-height: calc(100vh - 72px);
  background: #fff;
  padding: 0 16px 16px;
}

.permission-management :deep(.ant-tabs-nav) {
  margin-bottom: 16px;
}

.permission-management :deep(.ant-tabs-tab) {
  padding: 14px 8px;
}

.permission-management :deep(.ant-table-thead > tr > th) {
  background: #fafafa;
  font-weight: 500;
}

.permission-management :deep(.ant-table-tbody > tr > td) {
  padding: 18px 16px;
  border-bottom-color: #f3f4f6;
  overflow-wrap: anywhere;
}

.permission-management :deep(.ant-tag) {
  margin-inline-end: 0;
}
</style>
