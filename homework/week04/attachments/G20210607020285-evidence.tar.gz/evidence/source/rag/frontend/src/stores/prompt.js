import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as promptApi from '../services/promptApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

export const usePromptStore = defineStore('prompt', () => {
  const prompts = ref([])
  const total = ref(0)
  const page = ref(1)
  const pageSize = ref(20)
  const loading = ref(false)

  async function fetchPrompts(p = 1, ps = 20) {
    loading.value = true
    try {
      const data = await promptApi.listPrompts(p, ps)
      prompts.value = data.items
      total.value = data.total
      page.value = data.page
      pageSize.value = data.page_size
    } catch (error) {
      console.error('Failed to fetch prompts:', error)
    } finally {
      loading.value = false
    }
  }

  async function createPrompt(promptData) {
    loading.value = true
    try {
      await promptApi.createPrompt(promptData)
      await fetchPrompts(page.value, pageSize.value)
      return { success: true, message: '提示词创建成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function updatePrompt(promptId, promptData) {
    loading.value = true
    try {
      await promptApi.updatePrompt(promptId, promptData)
      await fetchPrompts(page.value, pageSize.value)
      return { success: true, message: '提示词更新成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function deletePrompt(promptId) {
    loading.value = true
    try {
      await promptApi.deletePrompt(promptId)
      await fetchPrompts(page.value, pageSize.value)
      return { success: true, message: '提示词删除成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  return {
    prompts,
    total,
    page,
    pageSize,
    loading,
    fetchPrompts,
    createPrompt,
    updatePrompt,
    deletePrompt
  }
})
