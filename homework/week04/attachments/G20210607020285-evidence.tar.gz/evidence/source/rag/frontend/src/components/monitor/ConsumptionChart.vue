<template>
  <div ref="el" class="consumption-chart"></div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
import * as echarts from 'echarts/core'
import { LineChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, LegendComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

// 015-resource-consumption-monitor T012：ECharts 按需引入（决策5），
// 折线图封装：buckets 为 X 轴、每模型一条曲线，图例点击可隐藏（决策12）
echarts.use([LineChart, GridComponent, TooltipComponent, LegendComponent, CanvasRenderer])

const props = defineProps({
  buckets: { type: Array, default: () => [] },
  series: { type: Array, default: () => [] },
  metric: { type: String, default: 'tokens' },
})

const el = ref(null)
let chart = null
let resizeObserver = null

function formatValue(v) {
  // 费用统一 6 位小数（决策9）；token 整数千分位
  return props.metric === 'cost' ? Number(v).toFixed(6) : Math.round(Number(v)).toLocaleString()
}

function render() {
  if (!chart) return
  chart.setOption({
    tooltip: { trigger: 'axis', valueFormatter: formatValue },
    legend: { type: 'scroll', bottom: 0 },
    grid: { left: 80, right: 24, top: 36, bottom: 48 },
    xAxis: { type: 'category', data: props.buckets, boundaryGap: false },
    yAxis: {
      type: 'value',
      name: props.metric === 'cost' ? '费用（元）' : 'token',
      axisLabel: { formatter: (v) => formatValue(v) },
    },
    series: props.series.map((s) => ({
      name: s.model,
      type: 'line',
      data: s.values,
      symbolSize: 5,
      emphasis: { focus: 'series' },
    })),
  }, { notMerge: true })
}

onMounted(() => {
  chart = echarts.init(el.value)
  render()
  resizeObserver = new ResizeObserver(() => chart && chart.resize())
  resizeObserver.observe(el.value)
})

watch(() => [props.buckets, props.series, props.metric], render, { deep: true })

onBeforeUnmount(() => {
  if (resizeObserver) { resizeObserver.disconnect(); resizeObserver = null }
  if (chart) { chart.dispose(); chart = null }
})
</script>

<style scoped>
.consumption-chart {
  width: 100%;
  height: 420px;
}
</style>