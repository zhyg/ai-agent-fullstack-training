<template>
  <a-modal
    title="新建知识库"
    :open="visible"
    :footer="null"
    @cancel="handleClose"
    width="520px"
  >
    <a-form
      ref="formRef"
      :model="formState"
      :rules="rules"
      layout="vertical"
      @finish="handleSubmit"
    >
      <a-form-item label="知识库名称" name="name">
        <a-input v-model:value="formState.name" placeholder="请输入知识库名称" />
      </a-form-item>
      <a-form-item label="描述" name="description">
        <a-textarea v-model:value="formState.description" placeholder="请输入知识库描述" :rows="3" />
      </a-form-item>
      <a-form-item label="LLM 模型" name="llmModelId">
        <a-select
          v-model:value="formState.llmModelId"
          :placeholder="llmModels.length === 0 ? '请先创建模型' : '请选择 LLM 模型'"
          :disabled="llmModels.length === 0"
        >
          <a-select-option v-for="m in llmModels" :key="m.id" :value="m.id">{{ m.name }}</a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item label="Embedding 模型" name="embeddingModelId">
        <a-select
          v-model:value="formState.embeddingModelId"
          :placeholder="embeddingModels.length === 0 ? '请先创建模型' : '请选择 Embedding 模型'"
          :disabled="embeddingModels.length === 0"
        >
          <a-select-option v-for="m in embeddingModels" :key="m.id" :value="m.id">{{ m.name }}</a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item label="图片识别模型" name="imageModelId">
        <a-select
          v-model:value="formState.imageModelId"
          :placeholder="visionModels.length === 0 ? '请先创建模型' : '请选择图片识别模型'"
          :disabled="visionModels.length === 0"
        >
          <a-select-option v-for="m in visionModels" :key="m.id" :value="m.id">{{ m.name }}</a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item label="Rerank 模型" name="rerankModelId">
        <a-select
          v-model:value="formState.rerankModelId"
          :placeholder="rerankModels.length === 0 ? '请先创建模型' : '请选择 Rerank 模型'"
          :disabled="rerankModels.length === 0"
        >
          <a-select-option v-for="m in rerankModels" :key="m.id" :value="m.id">{{ m.name }}</a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item>
        <a-space>
          <a-button type="primary" html-type="submit" :disabled="hasNoModels">确认</a-button>
          <a-button @click="handleClose">取消</a-button>
        </a-space>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  models: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['close', 'submit'])

const formRef = ref(null)
const formState = ref({
  name: '',
  description: '',
  llmModelId: undefined,
  embeddingModelId: undefined,
  imageModelId: undefined,
  rerankModelId: undefined
})

const rules = {
  name: [{ required: true, message: '请输入知识库名称' }],
  llmModelId: [{ required: true, message: '请选择 LLM 模型' }],
  embeddingModelId: [{ required: true, message: '请选择 Embedding 模型' }],
  imageModelId: [{ required: true, message: '请选择图片识别模型' }],
  rerankModelId: [{ required: true, message: '请选择 Rerank 模型' }]
}

// Filter models by category
const llmModels = computed(() => props.models.filter(m => m.category === 'chat'))
const embeddingModels = computed(() => props.models.filter(m => m.category === 'embedding'))
const visionModels = computed(() => props.models.filter(m => m.category === 'vision'))
const rerankModels = computed(() => props.models.filter(m => m.category === 'rerank'))

const hasNoModels = computed(() =>
  llmModels.value.length === 0 ||
  embeddingModels.value.length === 0 ||
  visionModels.value.length === 0 ||
  rerankModels.value.length === 0
)

watch(() => props.visible, (val) => {
  if (val) {
    formState.value = {
      name: '',
      description: '',
      llmModelId: undefined,
      embeddingModelId: undefined,
      imageModelId: undefined,
      rerankModelId: undefined
    }
  }
})

function handleSubmit() {
  emit('submit', { ...formState.value })
}

function handleClose() {
  emit('close')
  formRef.value?.resetFields()
}
</script>
