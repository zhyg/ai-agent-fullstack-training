/**
 * 全局错误处理工具
 * 提供统一的 API 错误提取和用户友好消息生成
 */

/**
 * 从 axios 错误对象中提取用户友好的错误消息
 * @param {Error|object} error - axios 抛出的错误
 * @param {string} fallback - 兜底消息
 * @returns {string} 用户友好的错误消息
 */
export function extractErrorMessage(error, fallback = '操作失败，请稍后重试') {
  if (!error) return fallback

  // 服务端返回的业务错误
  if (error.response) {
    const { status, data } = error.response
    const detail = data?.detail

    // Gateway error format: { error: { message, type, code } }
    if (data?.error?.message) {
      return data.error.message
    }

    if (detail) {
      if (typeof detail === 'string') return detail
      if (Array.isArray(detail)) {
        // Pydantic validation errors
        return detail.map(e => e.msg || e.message || JSON.stringify(e)).join('; ')
      }
    }

    switch (status) {
      case 400: return '请求参数有误，请检查后重试'
      case 401: return '登录已过期，请重新登录'
      case 403: return '没有权限执行此操作'
      case 404: return '请求的资源不存在'
      case 409: return '数据冲突，请刷新后重试'
      case 422: return '数据格式不正确，请检查输入'
      case 423: return detail || '账户已锁定，请稍后再试'
      case 429: return '操作过于频繁，请稍后再试'
      case 500: return '服务器内部错误，请稍后重试'
      case 502: return '上游服务不可用，请稍后重试'
      case 503: return '服务暂时不可用，请稍后重试'
      default: return detail || fallback
    }
  }

  // 网络错误 / 超时
  if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
    return '请求超时，请检查网络后重试'
  }
  if (error.message === 'Network Error' || error.code === 'ERR_NETWORK') {
    return '网络连接失败，请检查网络'
  }

  return fallback
}
