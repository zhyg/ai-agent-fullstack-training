import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as docApi from '../services/documentApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

/**
 * Convert API response (snake_case) to frontend format (camelCase).
 */
function toCamelCase(item) {
  return {
    id: item.id,
    name: item.name,
    kbId: item.kb_id,
    parentId: item.parent_id,
    order: item.order,
    createdAt: item.created_at,
    updatedAt: item.updated_at
  }
}

/**
 * Convert frontend form data (camelCase) to API payload (snake_case).
 */
function toSnakeCase(data) {
  const payload = {}
  if (data.name !== undefined) payload.name = data.name
  if (data.parentId !== undefined) payload.parent_id = data.parentId
  if (data.order !== undefined) payload.order = data.order
  return payload
}

export const useFolderStore = defineStore('folder', () => {
  const folders = ref([])
  const loading = ref(false)

  async function fetchFolders(kbId) {
    loading.value = true
    try {
      const data = await docApi.listFolders(kbId)
      folders.value = (data.items || data).map(toCamelCase)
    } catch (error) {
      console.error('Failed to fetch folders:', error)
    } finally {
      loading.value = false
    }
  }

  async function createFolder(kbId, formData) {
    try {
      const result = await docApi.createFolder(kbId, {
        name: formData.name,
        parent_id: formData.parentId ?? null
      })
      const created = toCamelCase(result)
      folders.value.push(created)
      return { success: true, data: created }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function updateFolder(folderId, formData) {
    try {
      const result = await docApi.updateFolder(folderId, toSnakeCase(formData))
      const idx = folders.value.findIndex((f) => f.id === folderId)
      if (idx !== -1) {
        folders.value[idx] = toCamelCase(result)
      }
      return { success: true }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function deleteFolder(folderId) {
    try {
      await docApi.deleteFolder(folderId)
      // Remove the folder and all descendants from local state
      const descendantIds = new Set()
      function collectDescendants(id) {
        descendantIds.add(id)
        folders.value
          .filter((f) => f.parentId === id)
          .forEach((f) => collectDescendants(f.id))
      }
      collectDescendants(folderId)
      folders.value = folders.value.filter((f) => !descendantIds.has(f.id))
      return { success: true }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  async function moveFolder(folderId, data) {
    try {
      const result = await docApi.moveFolder(folderId, {
        target_parent_id: data.targetParentId,
        target_index: data.targetIndex,
        auto_rename: data.autoRename ?? true
      })
      // Refetch to get correct ordering after move
      const kbId = result.folder.kb_id
      await fetchFolders(kbId)
      return { success: true, renamed: result.renamed }
    } catch (error) {
      return { success: false, message: extractErrorMessage(error) }
    }
  }

  function getFolderById(folderId) {
    return folders.value.find((f) => f.id === folderId) || null
  }

  function getRootFolders(kbId) {
    return folders.value
      .filter((f) => f.kbId === kbId && f.parentId === null)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  }

  return {
    folders,
    loading,
    fetchFolders,
    createFolder,
    updateFolder,
    deleteFolder,
    moveFolder,
    getFolderById,
    getRootFolders
  }
})
