import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// Chunk API
export async function getDocumentChunks(docId, params = {}) {
  const res = await api.get(`/documents/${docId}/chunks`, { params })
  return res.data
}

export async function getChunkChildren(chunkId, kbId) {
  const res = await api.get(`/chunks/${chunkId}/children`, { params: { kb_id: kbId } })
  return res.data
}

export async function getChunkTableData(chunkId, kbId, sql = null, limit = 100) {
  const res = await api.get(`/chunks/${chunkId}/table-data`, {
    params: { kb_id: kbId, sql, limit }
  })
  return res.data
}
