<template>
  <div class="chat-management">
    <div class="chat-sidebar">
      <ChatList
        :chats="chatStore.chats"
        :current-chat-id="chatStore.currentChatId"
        @create="handleCreateChat"
        @select="handleSelectChat"
        @delete="handleDeleteChat"
        @update-title="handleUpdateTitle"
      />
    </div>
    <div class="chat-main">
      <a-spin :spinning="chatStore.loading" tip="加载中...">
        <ChatArea
        :current-chat="currentChat"
        :messages="chatStore.messages"
        :models="modelStore.models"
        :prompts="promptStore.prompts"
        :agents="agentStore.agents"
        :knowledge-bases="kbStore.knowledgeBases"
        :step-progress="chatStore.stepProgress"
        :is-streaming="chatStore.streaming"
        :is-cancelling="chatStore.isCancelling"
        @send-message="handleSendMessage"
        @cancel="handleCancelGeneration"
        @create-chat="handleCreateChat"
        @refresh-urls="handleRefreshUrls"
      />
      </a-spin>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { useChatStore } from '../stores/chat.js'
import { useModelStore } from '../stores/model.js'
import { usePromptStore } from '../stores/prompt.js'
import { useAgentStore } from '../stores/agent.js'
import { useKbStore } from '../stores/knowledgeBase.js'
import { extractErrorMessage } from '../utils/errorHandler.js'
import ChatList from '../components/chat/ChatList.vue'
import ChatArea from '../components/chat/ChatArea.vue'

const chatStore = useChatStore()
const modelStore = useModelStore()
const promptStore = usePromptStore()
const agentStore = useAgentStore()
const kbStore = useKbStore()

const currentChat = computed(() => {
  if (!chatStore.currentChatId) return null
  return chatStore.chats.find(c => c.id === chatStore.currentChatId) || null
})

onMounted(async () => {
  await Promise.all([
    chatStore.fetchChats(),
    modelStore.fetchModels(1, 1000),
    promptStore.fetchPrompts(),
    agentStore.fetchAgents(),
    kbStore.fetchKnowledgeBases(1, 1000)
  ])
})

async function handleCreateChat() {
  try {
    await chatStore.createChat('新会话')
    message.success('新会话已创建')
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}

async function handleSelectChat(chatId) {
  try {
    await chatStore.selectChat(chatId)
    // If the selected chat has an active generation, resume streaming
    const chat = chatStore.chats.find(c => c.id === chatId)
    if (chat && chat.status === 'generating') {
      chatStore.resumeStream(chatId)
    }
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}

async function handleDeleteChat(chatId) {
  const ok = await chatStore.deleteChat(chatId)
  if (ok) message.success('会话删除成功')
}

async function handleUpdateTitle(chatId, title) {
  try {
    await chatStore.updateChat(chatId, { title })
    message.success('会话标题已更新')
  } catch (error) {
    message.error(extractErrorMessage(error))
  }
}

async function handleSendMessage(data) {
  const { content, agentId, knowledgeBaseIds } = data
  const chatId = chatStore.currentChatId

  if (!chatId) {
    message.warning('请先选择或创建一个会话')
    return
  }
  if (!knowledgeBaseIds?.length) {
    message.warning('请先选择知识库')
    return
  }

  // 发送前持久化智能体与知识库绑定（FR-001/002）
  const updates = {}
  if (agentId && currentChat.value?.agent_id !== agentId) updates.agent_id = agentId
  const currentKbIds = currentChat.value?.knowledge_base_ids || []
  if (JSON.stringify(currentKbIds) !== JSON.stringify(knowledgeBaseIds)) {
    updates.knowledge_base_ids = knowledgeBaseIds
  }
  if (Object.keys(updates).length > 0) {
    const updated = await chatStore.updateChat(chatId, updates)
    if (!updated) {
      message.error('更新会话智能体或知识库失败')
      return
    }
  }

  const result = await chatStore.sendMessage(content)
  if (result && !result.success) {
    message.error(result.error || '消息发送失败')
  }
}

async function handleRefreshUrls(msg) {
  const chatId = chatStore.currentChatId
  if (!chatId || !msg?.id) return
  const data = await chatStore.refreshMessageUrls(chatId, msg.id)
  if (!data) message.warning('图片链接刷新失败，请稍后重试')
}

async function handleCancelGeneration() {
  await chatStore.cancelGeneration()
}
</script>

<style scoped>
.chat-management {
  display: flex;
  height: calc(100vh - 160px);
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
}
.chat-sidebar {
  width: 320px;
  border-right: 1px solid #f0f0f0;
  background: #fafafa;
}
.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}
.chat-main :deep(.ant-spin-nested-loading),
.chat-main :deep(.ant-spin-container) {
  height: 100%;
  min-height: 0;
}
</style>
