import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export async function listPrompts(page = 1, pageSize = 20) {
  const res = await api.get('/prompts', { params: { page, page_size: pageSize } })
  return res.data
}

export async function createPrompt(data) {
  const res = await api.post('/prompts', data)
  return res.data
}

export async function updatePrompt(promptId, data) {
  const res = await api.put(`/prompts/${promptId}`, data)
  return res.data
}

export async function deletePrompt(promptId) {
  const res = await api.delete(`/prompts/${promptId}`)
  return res.data
}

export default api
