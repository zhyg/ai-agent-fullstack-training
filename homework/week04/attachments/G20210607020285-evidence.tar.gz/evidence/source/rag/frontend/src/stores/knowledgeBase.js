import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as kbApi from '../services/knowledgeBaseApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

/**
 * Convert API response (snake_case) to frontend format (camelCase).
 */
function toCamelCase(item) {
  return {
    id: item.id,
    name: item.name,
    description: item.description,
    userId: item.user_id,
    llmModelId: item.llm_model_id,
    embeddingModelId: item.embedding_model_id,
    imageModelId: item.image_model_id,
    rerankModelId: item.rerank_model_id,
    createdAt: item.created_at,
    updatedAt: item.updated_at
  }
}

/**
 * Convert frontend form data (camelCase) to API payload (snake_case).
 */
function toSnakeCase(data) {
  const payload = {}
  if (data.name !== undefined) payload.name = data.name
  if (data.description !== undefined) payload.description = data.description
  if (data.llmModelId !== undefined) payload.llm_model_id = data.llmModelId
  if (data.embeddingModelId !== undefined) payload.embedding_model_id = data.embeddingModelId
  if (data.imageModelId !== undefined) payload.image_model_id = data.imageModelId
  if (data.rerankModelId !== undefined) payload.rerank_model_id = data.rerankModelId
  return payload
}

export const useKbStore = defineStore('knowledgeBase', () => {
  const knowledgeBases = ref([])
  const total = ref(0)
  const loading = ref(false)

  async function fetchKnowledgeBases(page = 1, pageSize = 1000) {
    loading.value = true
    try {
      const data = await kbApi.listKnowledgeBases(page, pageSize)
      knowledgeBases.value = data.items.map(toCamelCase)
      total.value = data.total
    } catch (error) {
      console.error('Failed to fetch knowledge bases:', error)
    } finally {
      loading.value = false
    }
  }

  async function createKb(formData) {
    loading.value = true
    try {
      await kbApi.createKnowledgeBase(toSnakeCase(formData))
      await fetchKnowledgeBases()
      return { success: true, message: '知识库创建成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function updateKb(kbId, formData) {
    loading.value = true
    try {
      await kbApi.updateKnowledgeBase(kbId, toSnakeCase(formData))
      await fetchKnowledgeBases()
      return { success: true, message: '知识库更新成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function deleteKb(kbId) {
    loading.value = true
    try {
      await kbApi.deleteKnowledgeBase(kbId)
      await fetchKnowledgeBases()
      return { success: true, message: '知识库删除成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  return {
    knowledgeBases,
    total,
    loading,
    fetchKnowledgeBases,
    createKb,
    updateKb,
    deleteKb
  }
})
