<template>
  <a-layout class="app-shell">
    <header class="platform-header">
      <div class="platform-header-inner">
        <div class="platform-brand">
          <div class="platform-logo" aria-hidden="true"><ApiOutlined /></div>
          <div class="platform-brand-copy">
            <div class="platform-title">开发者门户</div>
            <div class="platform-subtitle">Developer Portal Platform</div>
          </div>
        </div>
        <nav class="platform-nav" aria-label="平台导航">
          <a-dropdown
            v-model:open="aiToolsOpen"
            :trigger="['hover', 'click']"
            placement="bottomLeft"
          >
            <button
              type="button"
              :class="['platform-nav-item', { 'is-active': isAiRoute }]"
              aria-haspopup="menu"
              :aria-expanded="aiToolsOpen"
            >
              AI
            </button>
            <template #overlay>
              <a-menu
                class="ai-tools-menu"
                :selectedKeys="selectedMenuKeys"
                @click="handleMenuClick('ai')"
              >
                <a-menu-item key="prompts">
                  <router-link to="/prompts">提示词管理</router-link>
                </a-menu-item>
                <a-menu-item key="chat">
                  <router-link to="/chat">知识库管理</router-link>
                </a-menu-item>
                <a-menu-item key="models" v-if="userStore.isAdmin">
                  <router-link to="/models">模型管理</router-link>
                </a-menu-item>
                <a-menu-item key="api-keys">
                  <router-link to="/api-keys">API keys</router-link>
                </a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>

          <a-dropdown
            v-model:open="permToolsOpen"
            :trigger="['hover', 'click']"
            placement="bottomLeft"
            v-if="userStore.isAdmin"
          >
            <button
              type="button"
              :class="['platform-nav-item', { 'is-active': isPermRoute }]"
              aria-haspopup="menu"
              :aria-expanded="permToolsOpen"
            >
              权限
            </button>
            <template #overlay>
              <a-menu
                class="ai-tools-menu"
                :selectedKeys="selectedMenuKeys"
                @click="handleMenuClick('perm')"
              >
                <a-menu-item key="permissions">
                  <router-link to="/permissions">权限管理</router-link>
                </a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
        </nav>
        <div class="header-account">
          <div class="user-info" :title="userStore.currentUser?.email || username">
            <a-avatar :size="30" class="user-avatar">{{ userInitial }}</a-avatar>
            <span class="username" :title="username">{{ username }}</span>
          </div>
          <a-button danger class="logout-btn" @click="handleLogout">退出</a-button>
        </div>
      </div>
    </header>
    <a-layout class="workspace-layout">
      <a-layout-sider
        v-if="showKnowledgeSidebar"
        v-model:collapsed="collapsed"
        :trigger="null"
        collapsible
        breakpoint="lg"
        :width="280"
        theme="light"
        style="border-right: 1px solid #f0f0f0;"
      >
        <div class="sidebar-brand">
          <div class="sidebar-logo">
            <BookOutlined style="color: #fff; font-size: 18px;" />
          </div>
          <span v-if="!collapsed" class="sidebar-title">知识库平台</span>
        </div>
        <a-menu
          :selectedKeys="sidebarSelectedKeys"
          theme="light"
          mode="inline"
          @click="handleSidebarMenuClick"
        >
          <a-menu-item key="chat">
            <template #icon><MessageOutlined /></template>
            新会话
          </a-menu-item>
          <a-menu-item key="knowledge">
            <template #icon><BookOutlined /></template>
            知识库
          </a-menu-item>
          <a-menu-item key="agent">
            <template #icon><RobotOutlined /></template>
            智能体
          </a-menu-item>
          <a-menu-item key="evaluation">
            <template #icon><ExperimentOutlined /></template>
            知识库评测
          </a-menu-item>
          <a-menu-item key="monitor">
            <template #icon><LineChartOutlined /></template>
            资源消耗监控
          </a-menu-item>
        </a-menu>
      </a-layout-sider>
      <a-layout style="background: transparent;">
        <a-layout-content class="workspace-content">
          <div class="content-wrapper">
            <router-view />
          </div>
        </a-layout-content>
      </a-layout>
    </a-layout>
  </a-layout>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ApiOutlined, MessageOutlined, BookOutlined, RobotOutlined, ExperimentOutlined, LineChartOutlined } from '@ant-design/icons-vue'
import { Modal, message } from 'ant-design-vue'
import { useUserStore } from '../../stores/user.js'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const aiToolsOpen = ref(false)
const permToolsOpen = ref(false)
const collapsed = ref(false)

const username = computed(() => userStore.currentUser?.uid || '未登录')
const userInitial = computed(() => Array.from(username.value)[0]?.toUpperCase() || '?')

const aiRoutes = ['/prompts', '/chat', '/knowledge', '/agent', '/evaluation', '/monitor', '/models', '/api-keys']
const permRoutes = ['/permissions']
const knowledgeRoutes = ['/chat', '/knowledge', '/agent', '/evaluation', '/monitor']

const isAiRoute = computed(() => aiRoutes.includes(route.path))
const isPermRoute = computed(() => permRoutes.includes(route.path))

const routeToKey = {
  '/prompts': 'prompts',
  '/chat': 'chat',
  '/knowledge': 'knowledge',
  '/agent': 'agent',
  '/evaluation': 'evaluation',
  '/monitor': 'monitor',
  '/models': 'models',
  '/permissions': 'permissions',
  '/api-keys': "[REDACTED]"
}

const showKnowledgeSidebar = computed(() => knowledgeRoutes.includes(route.path))

const sidebarSelectedKeys = computed(() => {
  const key = routeToKey[route.path]
  return key ? [key] : []
})

const selectedMenuKeys = computed(() => {
  const key = routeToKey[route.path]
  return key ? [key] : []
})

watch([aiToolsOpen, permToolsOpen], ([aiOpen, permOpen], _, onCleanup) => {
  if (!aiOpen && !permOpen) return
  const closeOnEscape = (event) => {
    if (event.key === 'Escape') {
      aiToolsOpen.value = false
      permToolsOpen.value = false
    }
  }
  document.addEventListener('keydown', closeOnEscape)
  onCleanup(() => document.removeEventListener('keydown', closeOnEscape))
})

function handleMenuClick(group) {
  if (group === 'ai') aiToolsOpen.value = false
  if (group === 'perm') permToolsOpen.value = false
}

function handleSidebarMenuClick({ key }) {
  const routeMap = { chat: '/chat', knowledge: '/knowledge', agent: '/agent', evaluation: '/evaluation', monitor: '/monitor' }
  if (routeMap[key]) router.push(routeMap[key])
}

function handleLogout() {
  Modal.confirm({
    title: '确认退出',
    content: '确定要退出当前账号吗？',
    okText: '确认',
    cancelText: '取消',
    async onOk() {
      await userStore.logout()
      message.success('退出成功')
      router.push('/login')
    }
  })
}
</script>

<style scoped>
:global(body) {
  margin: 0;
  padding: 0;
}

.app-shell {
  min-height: 100vh;
  background: #f8faff;
}

.platform-header {
  position: sticky;
  top: 0;
  z-index: 20;
  flex-shrink: 0;
  background: #fff;
  border-bottom: 1px solid #edf0f5;
}

.platform-header-inner {
  max-width: 1280px;
  min-height: 72px;
  margin: 0 auto;
  padding: 0 24px;
  display: flex;
  align-items: center;
  gap: 28px;
}

.platform-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}

.platform-logo {
  width: 44px;
  height: 44px;
  display: grid;
  place-items: center;
  color: #189dff;
  background: #f5fbff;
  border: 1px solid #dceeff;
  border-radius: 12px;
  font-size: 24px;
}

.platform-title {
  color: #152038;
  font-size: 17px;
  font-weight: 600;
  letter-spacing: 1px;
}

.platform-subtitle {
  margin-top: 3px;
  color: #8190a8;
  font-size: 10px;
  white-space: nowrap;
}

.platform-nav {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}

.platform-nav-item {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 40px;
  padding: 0 14px;
  border: 0;
  border-radius: 22px;
  background: transparent;
  color: #46536b;
  font: inherit;
  font-size: 13px;
  white-space: nowrap;
  cursor: pointer;
}

.platform-nav-item.is-active {
  color: #476fff;
  background: #f0f4ff;
}

.ai-tools-menu {
  min-width: 220px;
  padding: 8px 0;
  border-radius: 4px;
}

.ai-tools-menu :deep(.ant-dropdown-menu-item) {
  min-height: 48px;
  padding: 12px 20px;
  border-radius: 0;
  font-size: 14px;
}

.header-account {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-shrink: 0;
}

.workspace-layout {
  flex: 1;
  min-width: 0;
  background: transparent;
}

.workspace-content {
  margin: 20px;
}

.content-wrapper {
  padding: 24px;
  background: #fff;
  min-height: 360px;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.user-avatar {
  flex-shrink: 0;
  background: #cf1322;
  font-size: 13px;
  font-weight: 600;
  box-shadow: 0 0 0 5px #f7f8fa;
}

.username {
  max-width: 120px;
  font-size: 13px;
  font-weight: 600;
  color: #152038;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.logout-btn {
  height: 30px;
  padding: 0 15px;
  border-color: #ffccc7;
  border-radius: 3px;
  font-size: 12px;
}

.sidebar-brand {
  height: 48px;
  margin: 16px;
  display: flex;
  align-items: center;
  padding: 0 12px;
}

.sidebar-logo {
  width: 32px;
  height: 32px;
  background: #1677ff;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  flex-shrink: 0;
}

.sidebar-title {
  color: #1f1f1f;
  font-size: 17px;
  font-weight: 600;
  white-space: nowrap;
}
</style>
