<template>
  <a-form layout="vertical">
    <a-form-item label="名称" required>
      <a-input
        v-model:value="draft.name"
        placeholder="请输入智能体名称（1–100 字符）"
        :maxlength="100"
        show-count
      />
    </a-form-item>
    <a-form-item label="描述">
      <a-textarea
        v-model:value="draft.description"
        placeholder="请输入智能体描述"
        :rows="3"
        :maxlength="500"
      />
    </a-form-item>
    <a-form-item label="图标">
      <div class="icon-grid">
        <div
          v-for="icon in AGENT_ICONS"
          :key="icon.key"
          class="icon-cell"
          :class="{ 'icon-cell-active': draft.icon === icon.key }"
          @click="draft.icon = icon.key"
        >
          <component :is="icon.component" class="icon-glyph" />
          <span class="icon-label">{{ icon.label }}</span>
        </div>
      </div>
    </a-form-item>
  </a-form>
</template>

<script setup>
import { AGENT_ICONS } from '../../../utils/agent.js'

defineProps({
  draft: { type: Object, required: true }
})
</script>

<style scoped>
.icon-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
}

.icon-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  padding: 10px 4px;
  border: 1px solid #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
}

.icon-cell:hover {
  border-color: #1677ff;
}

.icon-cell-active {
  border-color: #1677ff;
  background: #e6f4ff;
  color: #1677ff;
}

.icon-glyph {
  font-size: 20px;
}

.icon-label {
  font-size: 12px;
}
</style>