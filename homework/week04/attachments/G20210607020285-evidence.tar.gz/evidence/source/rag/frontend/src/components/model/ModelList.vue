<template>
  <section class="model-list" aria-label="模型管理">
    <div class="list-header">
      <h2>模型管理</h2>
      <a-button type="primary" @click="handleCreate">新建模型</a-button>
    </div>
    <a-tabs v-model:activeKey="activeCategory" class="category-tabs">
      <a-tab-pane
        v-for="cat in MODEL_CATEGORIES"
        :key="cat.value"
        :tab="`${cat.label}(${getCategoryCount(cat.value)})`"
      />
    </a-tabs>
    <div class="model-grid">
      <ModelCard
        v-for="model in filteredModels"
        :key="model.id"
        :model="model"
        @edit="(m) => $emit('edit', m)"
        @delete="(m) => $emit('delete', m)"
      />
      <button type="button" class="add-model-card" @click="handleCreate">
        <span class="add-icon" aria-hidden="true"><PlusOutlined /></span>
        <span>添加{{ activeCategoryLabel }}模型</span>
      </button>
    </div>
    <a-empty v-if="filteredModels.length === 0" description="暂无该分类模型" class="empty-state" />
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
import { MODEL_CATEGORIES, getModelCategory } from '../../utils/model.js'
import ModelCard from './ModelCard.vue'

const props = defineProps({
  models: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['create', 'edit', 'delete'])
const activeCategory = ref('chat')

const activeCategoryLabel = computed(() => {
  const cat = MODEL_CATEGORIES.find(c => c.value === activeCategory.value)
  return cat ? cat.formLabel : '模型'
})

const filteredModels = computed(() => {
  return props.models
    .filter(model => getModelCategory(model) === activeCategory.value)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
})

function getCategoryCount(categoryValue) {
  return props.models.filter(m => getModelCategory(m) === categoryValue).length
}

function handleCreate() {
  emit('create', activeCategory.value)
}
</script>

<style scoped>
.model-list {
  background: #fff;
  padding: 28px 32px 40px;
  border-radius: 12px;
  min-height: 480px;
}

.list-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
}

.list-header h2 {
  margin: 0;
  font-size: 22px;
  font-weight: 600;
}

.category-tabs :deep(.ant-tabs-tab) {
  padding: 16px 8px;
  font-size: 17px;
  color: #777;
}

.category-tabs :deep(.ant-tabs-tab-active .ant-tabs-tab-btn) {
  color: #16b364;
}

.category-tabs :deep(.ant-tabs-ink-bar) {
  background: #16b364;
  height: 3px;
  border-radius: 3px;
}

.category-tabs :deep(.ant-tabs-nav) {
  margin-bottom: 26px;
}

.model-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20px;
}

.add-model-card {
  min-height: 142px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  border: 1px dashed #dedede;
  border-radius: 16px;
  background: #fff;
  color: #8c8c8c;
  font: inherit;
  font-size: 16px;
  cursor: pointer;
  transition: border-color 0.2s, background 0.2s;
}

.add-icon {
  display: grid;
  place-items: center;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: #ecfaf2;
  color: #16b364;
  font-size: 26px;
}

.add-model-card:hover,
.add-model-card:focus-visible {
  border-color: #16b364;
  background: #fbfefc;
}

.empty-state {
  padding: 48px 0;
}

@media (max-width: 900px) {
  .model-grid { grid-template-columns: minmax(0, 1fr); }
  .model-list { padding: 20px 16px; }
}
</style>
