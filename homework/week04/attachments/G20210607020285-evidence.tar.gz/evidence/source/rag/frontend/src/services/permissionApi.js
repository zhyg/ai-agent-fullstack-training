import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_USER_MANAGE_URL || '/api/user',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// Users
export async function listUsers(page = 1, pageSize = 20) {
  const res = await api.get('/users', { params: { page, page_size: pageSize } })
  return res.data
}

export async function createUser(data) {
  const res = await api.post('/users', data)
  return res.data
}

export async function updateUser(userId, data) {
  const res = await api.put(`/users/${userId}`, data)
  return res.data
}

export async function deleteUser(userId) {
  const res = await api.delete(`/users/${userId}`)
  return res.data
}

// Roles
export async function listRoles() {
  const res = await api.get('/roles')
  return res.data
}

export async function createRole(data) {
  const res = await api.post('/roles', data)
  return res.data
}

export async function updateRole(roleId, data) {
  const res = await api.put(`/roles/${roleId}`, data)
  return res.data
}

export async function deleteRole(roleId) {
  const res = await api.delete(`/roles/${roleId}`)
  return res.data
}

// Permissions
export async function listPermissions() {
  const res = await api.get('/permissions')
  return res.data
}

export default api
