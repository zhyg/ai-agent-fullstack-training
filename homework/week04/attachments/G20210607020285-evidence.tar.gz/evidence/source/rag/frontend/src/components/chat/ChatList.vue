<template>
  <div class="chat-list-container">
    <div class="chat-list-header">
      <a-button type="primary" block @click="$emit('create')">
        <template #icon><PlusOutlined /></template>
        新建会话
      </a-button>
    </div>

    <div class="chat-list">
      <div
        v-for="chat in chats"
        :key="chat.id"
        :class="['chat-item', { active: chat.id === currentChatId }]"
        @click="$emit('select', chat.id)"
      >
        <div class="chat-item-content">
          <div class="chat-icon"><MessageOutlined /></div>
          <div class="chat-info">
            <div class="chat-title" v-if="!editingChatId || editingChatId !== chat.id">
              {{ chat.title }}
            </div>
            <a-input
              v-else
              v-model:value="editingTitle"
              size="small"
              @blur="handleSaveTitle(chat.id)"
              @pressEnter="handleSaveTitle(chat.id)"
              @click.stop
            />
            <div class="chat-time">{{ formatChatDateTime(chat.updated_at) }}</div>
          </div>
        </div>
        <div class="chat-actions" @click.stop>
          <a-button type="text" size="small" @click="handleEditTitle(chat)">
            <template #icon><EditOutlined /></template>
          </a-button>
          <a-button type="text" size="small" danger @click="handleDeleteChat(chat)">
            <template #icon><DeleteOutlined /></template>
          </a-button>
        </div>
      </div>
      <a-empty v-if="chats.length === 0" description="暂无会话" />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { PlusOutlined, MessageOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { Modal, message } from 'ant-design-vue'
import { formatChatDateTime } from '../../utils/chatDate.js'

const props = defineProps({
  chats: { type: Array, default: () => [] },
  currentChatId: { type: String, default: null }
})

const emit = defineEmits(['create', 'select', 'delete', 'update-title'])

const editingChatId = ref(null)
const editingTitle = ref('')

function handleDeleteChat(chat) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除会话 "${chat.title}" 吗？所有消息将被清除。`,
    okText: '确认',
    okType: 'danger',
    cancelText: '取消',
    onOk() {
      emit('delete', chat.id)
    }
  })
}

function handleEditTitle(chat) {
  editingChatId.value = chat.id
  editingTitle.value = chat.title
}

function handleSaveTitle(chatId) {
  if (editingTitle.value.trim()) {
    emit('update-title', chatId, editingTitle.value.trim())
  }
  editingChatId.value = null
  editingTitle.value = ''
}

</script>

<style scoped>
.chat-list-container { height: 100%; display: flex; flex-direction: column; background: #fafafa; }
.chat-list-header { padding: 16px; border-bottom: 1px solid #f0f0f0; background: #fff; }
.chat-list { flex: 1; overflow-y: auto; padding: 8px; }
.chat-item { display: flex; align-items: center; justify-content: space-between; padding: 12px; margin-bottom: 4px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
.chat-item:hover { background: #e6f7ff; }
.chat-item.active { background: #1890ff; color: #fff; }
.chat-item-content { display: flex; align-items: center; flex: 1; overflow: hidden; }
.chat-icon { width: 32px; height: 32px; border-radius: 6px; background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%); display: flex; align-items: center; justify-content: center; margin-right: 12px; flex-shrink: 0; color: #fff; font-size: 16px; }
.chat-item.active .chat-icon { background: rgba(255, 255, 255, 0.2); }
.chat-info { flex: 1; overflow: hidden; }
.chat-title { font-size: 14px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 4px; }
.chat-time { font-size: 12px; color: #8c8c8c; }
.chat-item.active .chat-time { color: rgba(255, 255, 255, 0.8); }
.chat-actions { display: flex; gap: 4px; opacity: 0; transition: opacity 0.2s; }
.chat-item:hover .chat-actions { opacity: 1; }
.chat-item.active .chat-actions :deep(.ant-btn) { color: rgba(255, 255, 255, 0.8); }
.chat-item.active .chat-actions :deep(.ant-btn:hover) { color: #fff; }
:deep(.ant-empty-description) { color: #8c8c8c; }
</style>
