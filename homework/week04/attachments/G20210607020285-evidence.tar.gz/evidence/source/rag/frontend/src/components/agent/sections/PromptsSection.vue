<template>
  <div>
    <a-alert
      v-if="!loading && prompts.length === 0"
      type="warning"
      show-icon
      message="暂无可用提示词，请先前往提示词管理配置"
      style="margin-bottom: 16px"
    />
    <a-form layout="vertical">
      <a-form-item
        v-for="purpose in purposes"
        :key="purpose"
        :required="requiredSet.has(purpose)"
      >
        <template #label>
          {{ PROMPT_PURPOSE_LABELS[purpose] }}
          <a-tag v-if="isInvalid(purpose)" color="red">已失效</a-tag>
        </template>
        <a-select
          v-model:value="draft.config.prompts[purpose]"
          placeholder="请选择提示词"
          allow-clear
          show-search
          option-filter-prop="label"
          :loading="loading"
          :options="promptOptions"
          style="width: 100%; max-width: 480px"
        />
      </a-form-item>
    </a-form>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import {
  PROMPT_PURPOSE_LABELS,
  PROMPT_PURPOSES_BY_TYPE,
  getRequiredPromptPurposes
} from '../../../utils/agent.js'

const props = defineProps({
  draft: { type: Object, required: true },
  agentType: { type: String, required: true },
  prompts: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false }
})

const purposes = computed(() => PROMPT_PURPOSES_BY_TYPE[props.agentType] || [])
const requiredSet = computed(
  () => new Set(getRequiredPromptPurposes(props.agentType, props.draft.config.tools))
)

// 展示名称＋版本，值为 prompt_id；遵循现有可见性、不做用途过滤（FR-007）
const promptOptions = computed(() =>
  props.prompts.map((p) => ({
    value: p.id,
    label: p.version ? `${p.name}（v${String(p.version).replace(/^v+/i, '')}）` : p.name
  }))
)

function isInvalid(purpose) {
  const id = props.draft.config.prompts[purpose]
  return !!id && !props.loading && !props.prompts.some((p) => p.id === id)
}
</script>