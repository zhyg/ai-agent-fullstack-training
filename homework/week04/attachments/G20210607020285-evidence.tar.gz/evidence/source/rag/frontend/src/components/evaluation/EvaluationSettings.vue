<template>
  <div class="evaluation-settings">
    <a-card title="评测配置" size="small" class="settings-card">
      <a-form layout="vertical">
        <a-row :gutter="16">
          <a-col :span="8">
            <a-form-item label="分析模型">
              <a-select
                v-model:value="form.analysis_model_id"
                :options="modelOptions"
                :loading="loadingModels"
                placeholder="选择对话模型"
                allow-clear
                show-search
                option-filter-prop="label"
              />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="召回率提示词">
              <a-select
                v-model:value="form.recall_prompt_id"
                :options="promptOptions"
                :loading="loadingPrompts"
                placeholder="选择本人提示词（名称+版本）"
                allow-clear
                show-search
                option-filter-prop="label"
              />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="准确度提示词">
              <a-select
                v-model:value="form.accuracy_prompt_id"
                :options="promptOptions"
                :loading="loadingPrompts"
                placeholder="选择本人提示词（名称+版本）"
                allow-clear
                show-search
                option-filter-prop="label"
              />
            </a-form-item>
          </a-col>
        </a-row>
        <a-button type="primary" :loading="saving" @click="handleSave">保存设置</a-button>
        <span class="save-tip">评测进行中设置将锁定，任务结束后可修改</span>
      </a-form>
    </a-card>

    <a-card title="测试集管理" size="small" class="settings-card">
      <template #extra>
        <a-button type="primary" size="small" @click="openUpload('create')">上传测试集</a-button>
      </template>
      <a-table
        :columns="columns"
        :data-source="testSets"
        :loading="loadingSets"
        row-key="id"
        size="small"
        :pagination="false"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'name'">
            <a @click="openPreview(record)">{{ record.name }}</a>
          </template>
          <template v-else-if="column.key === 'created_at'">
            {{ formatTime(record.created_at) }}
          </template>
          <template v-else-if="column.key === 'updated_at'">
            {{ formatTime(record.updated_at) }}
          </template>
          <template v-else-if="column.key === 'actions'">
            <a-space>
              <a @click="handleDownload(record)">下载</a>
              <a @click="openUpload('reupload', record)">重新上传</a>
              <a class="danger-link" @click="handleDelete(record)">删除</a>
            </a-space>
          </template>
        </template>
      </a-table>
    </a-card>

    <TestSetUploadModal
      v-model:open="uploadOpen"
      :mode="uploadMode"
      :test-set="activeTestSet"
      @success="loadTestSets"
    />

    <a-modal
      v-model:open="previewOpen"
      :title="`测试集详情 - ${previewSet?.name || ''}`"
      width="720px"
      :footer="null"
    >
      <div class="preview-meta">
        <a-tag color="blue">{{ previewSet?.item_count ?? '-' }} 题</a-tag>
        <span class="preview-time">更新于 {{ formatTime(previewSet?.updated_at) }}</span>
        <a-space class="preview-actions">
          <a-button size="small" :disabled="previewLoading || !previewJson" @click="handleCopy">复制 JSON</a-button>
          <a-button size="small" :disabled="previewLoading" @click="handleDownload(previewSet)">下载</a-button>
        </a-space>
      </div>
      <a-spin :spinning="previewLoading">
        <pre class="preview-json">{{ previewJson }}</pre>
      </a-spin>
    </a-modal>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { Modal, message } from 'ant-design-vue'
import { listModels } from '../../services/modelApi.js'
import { listPrompts } from '../../services/promptApi.js'
import {
  getSettings, saveSettings, listTestSets, getTestSetItems, downloadTestSet, deleteTestSet
} from '../../services/evaluationApi.js'
import { useUserStore } from '../../stores/user.js'
import TestSetUploadModal from './TestSetUploadModal.vue'

const userStore = useUserStore()

const form = reactive({
  analysis_model_id: null,
  recall_prompt_id: null,
  accuracy_prompt_id: null
})
const modelOptions = ref([])
const promptOptions = ref([])
const testSets = ref([])
const loadingModels = ref(false)
const loadingPrompts = ref(false)
const loadingSets = ref(false)
const saving = ref(false)

const uploadOpen = ref(false)
const uploadMode = ref('create')
const activeTestSet = ref(null)

const previewOpen = ref(false)
const previewLoading = ref(false)
const previewSet = ref(null)
const previewJson = ref('')

const columns = [
  { title: '名称', dataIndex: 'name', key: 'name' },
  { title: '题数', dataIndex: 'item_count', key: 'item_count', width: 80 },
  { title: '创建时间', key: 'created_at', width: 170 },
  { title: '更新时间', key: 'updated_at', width: 170 },
  { title: '操作', key: 'actions', width: 200 }
]

function formatTime(value) {
  return value ? new Date(value).toLocaleString() : '-'
}

// 分析模型：仅"对话"模型（R9：网关模型存在即启用，前端过滤 category=chat）
async function loadModels() {
  loadingModels.value = true
  try {
    const data = await listModels(1, 1000)
    modelOptions.value = (data.items || [])
      .filter((m) => m.category === 'chat')
      .map((m) => ({ value: m.id, label: m.display_name || m.name }))
  } catch {
    message.error('加载模型列表失败')
  } finally {
    loadingModels.value = false
  }
}

// 提示词：仅本人（决策11），展示名称+版本；后端 page_size 上限 100，分页拉全量
async function loadPrompts() {
  loadingPrompts.value = true
  try {
    const all = []
    let page = 1
    while (true) {
      const data = await listPrompts(page, 100)
      const items = data.items || []
      all.push(...items)
      if (all.length >= (data.total || 0) || items.length === 0) break
      page += 1
    }
    const myId = userStore.currentUser?.id
    promptOptions.value = all
      .filter((p) => !myId || p.creator_id === myId)
      .map((p) => ({ value: p.id, label: `${p.name}（v${p.version}）` }))
  } catch {
    message.error('加载提示词列表失败')
  } finally {
    loadingPrompts.value = false
  }
}

async function loadSettings() {
  try {
    const data = await getSettings()
    form.analysis_model_id = data.analysis_model_id
    form.recall_prompt_id = data.recall_prompt_id
    form.accuracy_prompt_id = data.accuracy_prompt_id
  } catch {
    message.error('加载评测设置失败')
  }
}

async function loadTestSets() {
  loadingSets.value = true
  try {
    testSets.value = await listTestSets()
  } catch {
    message.error('加载测试集列表失败')
  } finally {
    loadingSets.value = false
  }
}

async function handleSave() {
  saving.value = true
  try {
    await saveSettings({ ...form })
    message.success('设置已保存')
  } catch (e) {
    // 409：评测进行中，设置已锁定；400：提示词非本人
    message.error(e.message)
  } finally {
    saving.value = false
  }
}

function openUpload(mode, record = null) {
  uploadMode.value = mode
  activeTestSet.value = record
  uploadOpen.value = true
}

// 点击名称预览测试集 JSON 详情（复用库内导出接口，与下载内容一致）
async function openPreview(record) {
  previewSet.value = record
  previewJson.value = ''
  previewOpen.value = true
  previewLoading.value = true
  try {
    const items = await getTestSetItems(record.id)
    previewJson.value = JSON.stringify(items, null, 2)
  } catch (e) {
    message.error(e.message)
    previewOpen.value = false
  } finally {
    previewLoading.value = false
  }
}

async function handleCopy() {
  try {
    await navigator.clipboard.writeText(previewJson.value)
    message.success('JSON 已复制到剪贴板')
  } catch {
    message.error('复制失败，请手动选择复制')
  }
}

async function handleDownload(record) {
  try {
    const blob = await downloadTestSet(record.id)
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${record.name}.json`
    link.click()
    URL.revokeObjectURL(url)
  } catch (e) {
    message.error(e.message)
  }
}

function handleDelete(record) {
  Modal.confirm({
    title: '确认删除测试集',
    content: `删除「${record.name}」后不可恢复；历史评测记录保留名称快照，不受影响。`,
    okText: '删除',
    okType: 'danger',
    cancelText: '取消',
    async onOk() {
      try {
        await deleteTestSet(record.id)
        message.success('测试集已删除')
        await loadTestSets()
      } catch (e) {
        // 409：评测进行中，测试集已锁定
        message.error(e.message)
      }
    }
  })
}

onMounted(() => {
  loadSettings()
  loadModels()
  loadPrompts()
  loadTestSets()
})
</script>

<style scoped>
.evaluation-settings {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.settings-card :deep(.ant-card-head) {
  font-weight: 600;
}

.save-tip {
  margin-left: 12px;
  color: #8190a8;
  font-size: 12px;
}

.danger-link {
  color: #ff4d4f;
}

.preview-meta {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
}

.preview-time {
  color: #8190a8;
  font-size: 12px;
}

.preview-actions {
  margin-left: auto;
}

.preview-json {
  background: #f7f9fc;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 12px;
  min-height: 120px;
  max-height: 60vh;
  overflow: auto;
  white-space: pre-wrap;
  word-break: break-word;
  margin: 0;
}
</style>