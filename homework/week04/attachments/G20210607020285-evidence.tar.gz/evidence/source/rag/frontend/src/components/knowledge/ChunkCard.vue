<template>
  <div class="chunk-card" :class="`chunk-type-${chunk.chunk_type}`">
    <div class="chunk-header">
      <a-tag :color="typeColor">{{ typeLabel }}</a-tag>
      <span class="chunk-index">#{{ chunk.chunk_index }}</span>
      <a-button
        v-if="hasChildren"
        type="link"
        size="small"
        @click="$emit('show-children', chunk)"
      >
        <template #icon><QuestionCircleOutlined /></template>
        AI分析
      </a-button>
    </div>
    <div class="chunk-content">
      <div v-html="renderedContent" />
    </div>
    <div v-if="chunk.image_url && Array.isArray(chunk.image_url)" class="chunk-images">
      <a-image
        v-for="(url, idx) in chunk.image_url"
        :key="idx"
        :src="url"
        :width="120"
        style="margin-right: 8px"
      />
    </div>
    <div v-if="chunk.sqlite_url" class="chunk-footer">
      <a-tag color="blue">关联表格数据</a-tag>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { QuestionCircleOutlined } from '@ant-design/icons-vue'

const props = defineProps({
  chunk: { type: Object, required: true },
  hasChildren: { type: Boolean, default: false },
})

defineEmits(['show-children'])

const typeMap = {
  text: { label: '文本', color: 'blue' },
  image: { label: '图片', color: 'green' },
  image_ocr: { label: 'OCR', color: 'cyan' },
  image_caption: { label: '图片分析', color: 'purple' },
  table_row: { label: '表格行', color: 'orange' },
  ai_question: { label: 'AI问题', color: 'magenta' },
}

const typeLabel = computed(() => typeMap[props.chunk.chunk_type]?.label || props.chunk.chunk_type)
const typeColor = computed(() => typeMap[props.chunk.chunk_type]?.color || 'default')

const renderedContent = computed(() => {
  let content = props.chunk.content || ''
  // Render markdown images as actual images
  content = content.replace(
    /!\[.*?\]\((.*?)\)/g,
    '<img src="$1" style="max-width:100%;margin:8px 0;border-radius:4px;" />'
  )
  // Convert newlines to <br>
  content = content.replace(/\n/g, '<br/>')
  return content
})
</script>

<style scoped>
.chunk-card {
  border: 1px solid #f0f0f0;
  border-radius: 8px;
  padding: 12px 16px;
  margin-bottom: 12px;
  background: #fff;
  transition: box-shadow 0.2s;
}
.chunk-card:hover {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}
.chunk-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}
.chunk-index {
  font-size: 12px;
  color: #8c8c8c;
}
.chunk-content {
  font-size: 13px;
  line-height: 1.6;
  color: #333;
  max-height: 300px;
  overflow-y: auto;
  word-break: break-word;
}
.chunk-images {
  margin-top: 8px;
}
.chunk-footer {
  margin-top: 8px;
}
.chunk-type-text { border-left: 3px solid #1677ff; }
.chunk-type-image { border-left: 3px solid #52c41a; }
.chunk-type-table_row { border-left: 3px solid #fa8c16; }
.chunk-type-ai_question { border-left: 3px solid #eb2f96; }
</style>
