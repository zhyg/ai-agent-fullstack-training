import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// 智能体为系统预置（FR-014），仅提供读取/更新/状态切换，不提供 create/delete

export async function listAgents() {
  const res = await api.get('/agents')
  return res.data
}

export async function getAgent(agentId) {
  const res = await api.get(`/agents/${agentId}`)
  return res.data
}

export async function updateAgent(agentId, data) {
  const res = await api.put(`/agents/${agentId}`, data)
  return res.data
}

export async function updateAgentStatus(agentId, status) {
  const res = await api.patch(`/agents/${agentId}/status`, { status })
  return res.data
}

export default api