<template>
  <a-modal
    :open="open"
    :title="isReupload ? `重新上传 - ${testSet?.name || ''}` : '上传测试集'"
    :confirm-loading="submitting"
    ok-text="提交"
    cancel-text="取消"
    @ok="handleSubmit"
    @cancel="close"
  >
    <a-form layout="vertical">
      <a-form-item v-if="!isReupload" label="测试集名称" required>
        <a-input
          v-model:value="name"
          placeholder="同一用户内唯一，最长 100 字符"
          :maxlength="100"
        />
      </a-form-item>
      <a-form-item label="JSON 文件" required>
        <a-upload
          accept=".json,application/json"
          :max-count="1"
          :file-list="fileList"
          :before-upload="handleBeforeUpload"
          @remove="handleRemove"
        >
          <a-button>选择 JSON 文件</a-button>
        </a-upload>
        <div class="upload-tip">格式：[{"question": "...", "answer": "..."}]，1–500 题，文件 ≤2MB</div>
      </a-form-item>
      <a-alert v-if="errorText" type="error" :message="errorText" show-icon style="margin-top: 8px;" />
    </a-form>
  </a-modal>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { message } from 'ant-design-vue'
import { uploadTestSet, reuploadTestSet } from '../../services/evaluationApi.js'

const MAX_ITEMS = 500
const MAX_BYTES = 2 * 1024 * 1024

const props = defineProps({
  open: { type: Boolean, default: false },
  // create: 新上传（可设名称）；reupload: 覆盖原测试集（名称/ID 不变，隐藏名称输入）
  mode: { type: String, default: 'create' },
  testSet: { type: Object, default: null }
})
const emit = defineEmits(['update:open', 'success'])

const isReupload = computed(() => props.mode === 'reupload')
const name = ref('')
const rawFile = ref(null)
const fileList = ref([])
const errorText = ref('')
const submitting = ref(false)

watch(() => props.open, (opened) => {
  if (opened) {
    name.value = ''
    rawFile.value = null
    fileList.value = []
    errorText.value = ''
  }
})

// 前端预校验（与后端 FR-006 同规则），失败即时提示且不保留文件
async function handleBeforeUpload(file) {
  errorText.value = ''
  if (file.size > MAX_BYTES) {
    errorText.value = '文件大小超过 2MB 上限'
    return false
  }
  try {
    const data = JSON.parse(await file.text())
    if (!Array.isArray(data)) throw new Error('顶层必须为数组')
    if (data.length === 0) throw new Error('测试集至少 1 题，空数组拒绝上传')
    if (data.length > MAX_ITEMS) throw new Error(`题数超过上限 ${MAX_ITEMS}（当前 ${data.length} 题）`)
    for (let i = 0; i < data.length; i++) {
      const item = data[i]
      if (typeof item !== 'object' || item === null || Array.isArray(item)) {
        throw new Error(`第 ${i + 1} 项必须为对象`)
      }
      for (const field of ['question', 'answer']) {
        if (typeof item[field] !== 'string' || !item[field].trim()) {
          throw new Error(`第 ${i + 1} 项 ${field} 必须为非空字符串`)
        }
      }
    }
  } catch (e) {
    errorText.value = e instanceof SyntaxError ? 'JSON 解析失败：文件不是合法 JSON' : e.message
    return false
  }
  rawFile.value = file
  fileList.value = [file]
  return false
}

function handleRemove() {
  rawFile.value = null
  fileList.value = []
}

function close() {
  emit('update:open', false)
}

async function handleSubmit() {
  errorText.value = ''
  if (!isReupload.value && !name.value.trim()) {
    errorText.value = '测试集名称不能为空'
    return
  }
  if (!rawFile.value) {
    errorText.value = '请选择 JSON 文件'
    return
  }
  submitting.value = true
  try {
    if (isReupload.value) {
      await reuploadTestSet(props.testSet.id, rawFile.value)
      message.success('重新上传成功，测试集内容已覆盖')
    } else {
      await uploadTestSet(name.value.trim(), rawFile.value)
      message.success('测试集上传成功')
    }
    emit('success')
    close()
  } catch (e) {
    // 后端 detail：重名 409 / 锁定 409 / 校验 400
    errorText.value = e.message
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.upload-tip {
  margin-top: 6px;
  color: #8190a8;
  font-size: 12px;
}
</style>