<template>
  <div class="ai-question-tab">
    <a-form-item>
      <template #label>
        <span>AI生成问题数</span>
      </template>
      <a-input-number
        :value="count"
        @update:value="$emit('update:count', $event)"
        :min="1"
        :max="10"
        style="width: 100%"
      />
      <div class="field-description">
        每个文档分块生成问题的数量，范围 1-10，默认3。增加问题数可以提高问题的覆盖率。
      </div>
    </a-form-item>
  </div>
</template>

<script setup>
defineProps({
  count: { type: Number, default: 3 }
})
defineEmits(['update:count'])
</script>

<style scoped>
.ai-question-tab {
  padding: 8px 0;
}
.field-description {
  font-size: 12px;
  color: #8c8c8c;
  margin-top: 4px;
  line-height: 1.5;
}
</style>
