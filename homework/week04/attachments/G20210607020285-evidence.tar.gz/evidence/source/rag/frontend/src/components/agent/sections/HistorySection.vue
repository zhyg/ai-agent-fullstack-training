<template>
  <a-form layout="vertical">
    <!-- 013 决策8：仅检索召回数一项；检索模式固定混合，不提供模式选项与启用开关 -->
    <a-form-item label="检索召回数">
      <a-input-number
        v-model:value="draft.config.history_retrieval.top_k"
        :min="1"
        :max="100"
        :precision="0"
        style="width: 240px"
      />
      <span class="field-hint">范围 1–100，默认 10</span>
    </a-form-item>
    <p class="mode-hint">检索模式固定为混合检索（关键词+向量），无需选择</p>
  </a-form>
</template>

<script setup>
defineProps({
  draft: { type: Object, required: true }
})
</script>

<style scoped>
.field-hint {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}

.mode-hint {
  font-size: 12px;
  color: #8c8c8c;
}
</style>