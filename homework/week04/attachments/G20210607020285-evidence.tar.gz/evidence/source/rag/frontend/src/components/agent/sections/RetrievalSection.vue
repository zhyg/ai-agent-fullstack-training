<template>
  <a-form layout="vertical">
    <!-- 规划推理无检索方式配置，三个召回数量均可配置 -->
    <template v-if="isPlanning">
      <a-form-item v-for="mode in RETRIEVAL_MODES" :key="mode.value" :label="mode.topKLabel">
        <a-input-number
          v-model:value="draft.config.retrieval[mode.topKField]"
          :min="1"
          :max="100"
          :precision="0"
          style="width: 240px"
        />
        <span class="field-hint">范围 1–100，默认 20</span>
      </a-form-item>
    </template>
    <template v-else>
      <a-form-item label="检索方式">
        <a-select v-model:value="draft.config.retrieval.mode" style="width: 240px">
          <a-select-option v-for="mode in RETRIEVAL_MODES" :key="mode.value" :value="mode.value">
            {{ mode.label }}
          </a-select-option>
        </a-select>
      </a-form-item>
      <!-- 三个召回数量独立保存，切换检索方式不重置（FR-008） -->
      <a-form-item v-if="currentMode" :label="currentMode.topKLabel">
        <a-input-number
          v-model:value="draft.config.retrieval[currentMode.topKField]"
          :min="1"
          :max="100"
          :precision="0"
          style="width: 240px"
        />
        <span class="field-hint">范围 1–100，默认 20</span>
      </a-form-item>
    </template>
    <a-form-item label="重排数量">
      <a-input-number
        v-model:value="draft.config.retrieval.rerank_top_n"
        :min="1"
        :max="100"
        :precision="0"
        style="width: 240px"
      />
      <span class="field-hint">范围 1–100，默认 15</span>
    </a-form-item>
  </a-form>
</template>

<script setup>
import { computed } from 'vue'
import { RETRIEVAL_MODES } from '../../../utils/agent.js'

const props = defineProps({
  draft: { type: Object, required: true },
  agentType: { type: String, required: true }
})

const isPlanning = computed(() => props.agentType === 'planning_reasoning')

const currentMode = computed(() =>
  RETRIEVAL_MODES.find((m) => m.value === props.draft.config.retrieval.mode)
)
</script>

<style scoped>
.field-hint {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}
</style>