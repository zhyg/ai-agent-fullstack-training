import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import * as userApi from '../services/userApi.js'

export const useUserStore = defineStore('user', () => {
  const currentUser = ref(null)
  const accessToken = ref(localStorage.getItem('access_token') || null)
  const refreshTokenValue = ref(localStorage.getItem('refresh_token') || null)
  const permissions = ref(JSON.parse(localStorage.getItem('permissions') || '[]'))
  const loading = ref(false)

  const isAuthenticated = computed(() => !!accessToken.value)
  const isAdmin = computed(() => {
    // Admin has all permissions or check role_ids
    return permissions.value.includes('permission_manage')
  })

  async function login(uid, password) {
    loading.value = true
    try {
      const data = await userApi.login({ uid, password })
      accessToken.value = data.access_token
      refreshTokenValue.value = data.refresh_token
      localStorage.setItem('access_token', data.access_token)
      localStorage.setItem('refresh_token', data.refresh_token || '')
      currentUser.value = data.user
      permissions.value = data.permissions || []
      localStorage.setItem('permissions', JSON.stringify(data.permissions || []))
      return { success: true, message: '登录成功' }
    } catch (error) {
      const detail = error.response?.data?.detail || '登录失败'
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function register(userData) {
    loading.value = true
    try {
      await userApi.register(userData)
      return { success: true, message: '注册成功，请登录' }
    } catch (error) {
      const detail = error.response?.data?.detail || '注册失败'
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function logout() {
    try {
      await userApi.logout()
    } catch (e) {
      // Ignore logout API errors
    } finally {
      accessToken.value = null
      refreshTokenValue.value = null
      currentUser.value = null
      permissions.value = []
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
    }
  }

  async function fetchCurrentUser() {
    if (!accessToken.value) return
    try {
      const data = await userApi.getMe()
      currentUser.value = data
      // Extract permissions from JWT token payload
      try {
        const tokenParts = accessToken.value.split('.')
        const payload = JSON.parse(atob(tokenParts[1]))
        if (payload.permissions) {
          permissions.value = payload.permissions
          localStorage.setItem('permissions', JSON.stringify(payload.permissions))
        }
      } catch (e) {
        // Fallback: keep existing permissions from localStorage
      }
    } catch (e) {
      // Token invalid, clear auth
      await logout()
    }
  }

  // Initialize: restore session from localStorage
  if (accessToken.value && !currentUser.value) {
    fetchCurrentUser()
  }

  return {
    currentUser,
    accessToken,
    permissions,
    loading,
    isAuthenticated,
    isAdmin,
    login,
    register,
    logout,
    fetchCurrentUser
  }
})
