<template>
  <div class="evaluation-panel">
    <EvaluationDetail v-if="selectedRunId" :run-id="selectedRunId" @back="handleBack" />
    <template v-else>
    <a-card title="发起评测" size="small" class="panel-card">
      <a-form layout="vertical">
        <a-row :gutter="16">
          <a-col :span="10">
            <a-form-item label="知识库（多选，至少一个）" required>
              <a-select
                v-model:value="form.knowledge_base_ids"
                mode="multiple"
                :options="kbOptions"
                :loading="loadingKbs"
                placeholder="选择检索范围（全部题目共用）"
                :disabled="running"
                allow-clear
                show-search
                option-filter-prop="label"
              />
            </a-form-item>
          </a-col>
          <a-col :span="7">
            <a-form-item label="智能体（仅启用态）" required>
              <a-select
                v-model:value="form.agent_id"
                :options="agentOptions"
                :loading="loadingAgents"
                placeholder="选择智能体"
                :disabled="running"
                allow-clear
                show-search
                option-filter-prop="label"
              />
            </a-form-item>
          </a-col>
          <a-col :span="7">
            <a-form-item label="测试集（仅本人）" required>
              <a-select
                v-model:value="form.test_set_id"
                :options="testSetOptions"
                :loading="loadingSets"
                placeholder="选择测试集"
                :disabled="running"
                allow-clear
                show-search
                option-filter-prop="label"
              />
            </a-form-item>
          </a-col>
        </a-row>
        <a-space>
          <a-button
            type="primary"
            :loading="starting"
            :disabled="running || !canStart"
            @click="handleStart"
          >开始评测</a-button>
          <a-button v-if="running" danger :loading="cancelling" @click="handleCancel">
            {{ cancelRequested ? '取消中（当前题完成后终止）' : '取消评测' }}
          </a-button>
          <span v-if="running" class="panel-tip">评测进行中，设置与选中测试集已锁定</span>
          <span v-else-if="!canStart" class="panel-tip">请先选择知识库、智能体与测试集</span>
        </a-space>
        <a-alert
          v-if="precheckErrors.length"
          type="error"
          show-icon
          style="margin-top: 12px;"
          message="开跑前预检未通过，请修正后重试"
        >
          <template #description>
            <ul class="precheck-list">
              <li v-for="(reason, i) in precheckErrors" :key="i">{{ reason }}</li>
            </ul>
          </template>
        </a-alert>
      </a-form>
    </a-card>

    <a-card v-if="progress" title="执行进度" size="small" class="panel-card">
      <template #extra>
        <a-tag :color="statusColor">{{ statusLabel }}</a-tag>
      </template>
      <a-progress
        :percent="percent"
        :status="progressStatus"
        :format="() => `${progress.completed} / ${progress.total}`"
      />
      <div class="progress-meta">
        已完成 {{ progress.completed }} / 总数 {{ progress.total }}
        <template v-if="progress.last_item">
          ｜最近一题：第 {{ progress.last_item.seq }} 题
          <a-tag :color="progress.last_item.status === 'success' ? 'green' : 'red'" size="small">
            {{ progress.last_item.status === 'success' ? '成功' : '失败' }}
          </a-tag>
        </template>
      </div>
      <a-alert
        v-if="progress.status === 'failed' && progress.error_message"
        type="error"
        :message="progress.error_message"
        show-icon
        style="margin-top: 8px;"
      />
    </a-card>

    <a-card title="历史评测" size="small" class="panel-card">
      <template #extra>
        <a-button size="small" :loading="loadingRuns" @click="loadRuns">刷新</a-button>
      </template>
      <a-table
        :columns="runColumns"
        :data-source="runs"
        :loading="loadingRuns"
        row-key="id"
        size="small"
        :pagination="{
          current: page,
          pageSize: pageSize,
          total: total,
          showSizeChanger: false,
          showTotal: (t) => `共 ${t} 条`
        }"
        @change="handleTableChange"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'started_at'">{{ formatTime(record.started_at) }}</template>
          <template v-else-if="column.key === 'knowledge_base_names'">
            {{ (record.knowledge_base_names || []).join('、') }}
          </template>
          <template v-else-if="column.key === 'avg_recall'">{{ formatRecall(record.avg_recall) }}</template>
          <template v-else-if="column.key === 'avg_accuracy'">{{ formatAccuracy(record.avg_accuracy) }}</template>
          <template v-else-if="column.key === 'status'">
            <a-tag :color="STATUS_COLORS[record.status] || 'default'">
              {{ STATUS_LABELS[record.status] || record.status }}
            </a-tag>
          </template>
          <template v-else-if="column.key === 'actions'">
            <a-space>
              <a-button type="link" size="small" @click="handleView(record)">详情</a-button>
              <a-button type="link" size="small" danger @click="handleDelete(record)">删除</a-button>
            </a-space>
          </template>
        </template>
      </a-table>
    </a-card>
    </template>
  </div>
</template>

<script setup>
import { computed, onUnmounted, reactive, ref } from 'vue'
import { message, Modal } from 'ant-design-vue'
import { listKnowledgeBases } from '../../services/knowledgeBaseApi.js'
import { listAgents } from '../../services/agentApi.js'
import {
  listTestSets, createRun, cancelRun, subscribeRunEvents, listRuns, deleteRun
} from '../../services/evaluationApi.js'
import EvaluationDetail from './EvaluationDetail.vue'

const form = reactive({
  knowledge_base_ids: [],
  agent_id: null,
  test_set_id: null
})
const kbOptions = ref([])
const agentOptions = ref([])
const testSetOptions = ref([])
const loadingKbs = ref(false)
const loadingAgents = ref(false)
const loadingSets = ref(false)
const starting = ref(false)
const cancelling = ref(false)
const running = ref(false)
const cancelRequested = ref(false)
const precheckErrors = ref([])
const progress = ref(null)
let abortController = null

// US3（T034）：历史列表 + 详情入口
const runs = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const loadingRuns = ref(false)
const selectedRunId = ref(null)
const runColumns = [
  { title: '开始时间', key: 'started_at', width: 170 },
  { title: '知识库', key: 'knowledge_base_names', ellipsis: true },
  { title: '智能体', dataIndex: 'agent_name', key: 'agent_name', ellipsis: true, width: 130 },
  { title: '测试集', dataIndex: 'test_set_name', key: 'test_set_name', ellipsis: true, width: 130 },
  { title: '平均召回率', key: 'avg_recall', width: 100 },
  { title: '平均准确度', key: 'avg_accuracy', width: 100 },
  { title: '状态', key: 'status', width: 90 },
  { title: '操作', key: 'actions', width: 120 }
]

const canStart = computed(() =>
  form.knowledge_base_ids.length > 0 && form.agent_id && form.test_set_id
)
const percent = computed(() => {
  if (!progress.value || !progress.value.total) return 0
  return Math.round((progress.value.completed / progress.value.total) * 100)
})
const STATUS_LABELS = { running: '进行中', completed: '已完成', cancelled: '已取消', failed: '失败' }
const STATUS_COLORS = { running: 'blue', completed: 'green', cancelled: 'orange', failed: 'red' }
const statusLabel = computed(() => STATUS_LABELS[progress.value?.status] || progress.value?.status)
const statusColor = computed(() => STATUS_COLORS[progress.value?.status] || 'default')
const progressStatus = computed(() => {
  const s = progress.value?.status
  if (s === 'completed') return 'success'
  if (s === 'failed') return 'exception'
  if (s === 'cancelled') return 'normal'
  return 'active'
})

async function loadOptions() {
  loadingKbs.value = true
  loadingAgents.value = true
  loadingSets.value = true
  try {
    const data = await listKnowledgeBases(1, 1000)
    kbOptions.value = (data.items || []).map((kb) => ({ value: kb.id, label: kb.name }))
  } catch {
    message.error('加载知识库列表失败')
  } finally {
    loadingKbs.value = false
  }
  try {
    const data = await listAgents()
    agentOptions.value = (data.items || [])
      .filter((a) => a.status === 'enabled')
      .map((a) => ({ value: a.id, label: a.name }))
  } catch {
    message.error('加载智能体列表失败')
  } finally {
    loadingAgents.value = false
  }
  try {
    const sets = await listTestSets()
    testSetOptions.value = sets.map((s) => ({ value: s.id, label: `${s.name}（${s.item_count} 题）` }))
  } catch {
    message.error('加载测试集列表失败')
  } finally {
    loadingSets.value = false
  }
}

function handleEvent(event) {
  // snapshot/progress/done 统一刷新进度（断线重连靠 snapshot 恢复，R6）
  progress.value = { ...progress.value, ...event }
  if (event.type === 'done') {
    running.value = false
    cancelRequested.value = false
    if (event.status === 'completed') message.success('评测已完成')
    else if (event.status === 'cancelled') message.warning('评测已取消，已完成题目结果保留')
    else message.error(`评测失败：${event.error_message || '任务级异常'}`)
    loadRuns()
  }
}

async function handleStart() {
  precheckErrors.value = []
  starting.value = true
  try {
    const run = await createRun({ ...form })
    running.value = true
    cancelRequested.value = false
    progress.value = { run_id: run.id, status: run.status, completed: 0, total: run.total_items }
    abortController = new AbortController()
    subscribeRunEvents(
      run.id,
      handleEvent,
      (msg) => message.error(msg),
      abortController.signal
    ).catch((e) => {
      if (e.name !== 'AbortError') message.error('评测进度连接中断，刷新页面可恢复进度')
    })
  } catch (e) {
    // 409：已有进行中任务；400：预检失效项一次性展示
    if (e.message.includes('进行中')) {
      message.warning(e.message)
    } else {
      precheckErrors.value = e.message.split('；').filter(Boolean)
    }
  } finally {
    starting.value = false
  }
}

async function handleCancel() {
  cancelling.value = true
  try {
    await cancelRun(progress.value.run_id)
    cancelRequested.value = true
    message.info('已请求取消，当前题（含评分）完成后终止')
  } catch (e) {
    message.error(e.message)
  } finally {
    cancelling.value = false
  }
}

onUnmounted(() => {
  abortController?.abort()
})

// 契约 §3：recall 0–1 ×100 百分比；accuracy 0–100；null 展示空
function formatRecall(v) { return v == null ? '' : `${(v * 100).toFixed(1)}%` }
function formatAccuracy(v) { return v == null ? '' : v.toFixed(1) }
function formatTime(v) { return v ? new Date(v).toLocaleString() : '' }

async function loadRuns() {
  loadingRuns.value = true
  try {
    const data = await listRuns(page.value, pageSize.value)
    runs.value = data.items || []
    total.value = data.total || 0
  } catch {
    message.error('加载历史评测失败')
  } finally {
    loadingRuns.value = false
  }
}

function handleTableChange(pagination) {
  page.value = pagination.current
  loadRuns()
}

function handleView(record) {
  selectedRunId.value = record.id
}

function handleBack() {
  selectedRunId.value = null
  loadRuns()
}

function handleDelete(record) {
  if (record.status === 'running') {
    message.warning('评测进行中，请先取消后再删除')
    return
  }
  Modal.confirm({
    title: '删除评测记录',
    content: `确定删除「${record.test_set_name}」这次评测及其全部题目结果？删除后不可恢复。`,
    okText: '删除',
    okType: 'danger',
    cancelText: '取消',
    async onOk() {
      try {
        await deleteRun(record.id)
        message.success('评测记录已删除')
        loadRuns()
      } catch (e) {
        message.error(e.message)
      }
    }
  })
}

loadOptions()
loadRuns()
</script>

<style scoped>
.evaluation-panel {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.panel-card :deep(.ant-card-head) {
  font-weight: 600;
}

.panel-tip {
  color: #8190a8;
  font-size: 12px;
}

.precheck-list {
  margin: 0;
  padding-left: 18px;
}

.progress-meta {
  margin-top: 8px;
  color: #51607a;
  font-size: 13px;
}
</style>