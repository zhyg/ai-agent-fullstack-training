<template>
  <div class="agent-card" :class="{ 'agent-card-disabled': agent.status === 'disabled' }">
    <div class="card-header">
      <div class="card-icon">
        <component :is="iconComponent" />
      </div>
      <div class="card-title-area">
        <div class="card-title-row">
          <span class="card-title">{{ agent.name }}</span>
          <a-tag v-if="agent.status === 'disabled'" color="default">已停用</a-tag>
          <a-tag v-else color="green">启用中</a-tag>
        </div>
        <a-tooltip :title="agent.description">
          <span class="card-description">{{ agent.description || '暂无描述' }}</span>
        </a-tooltip>
      </div>
      <div v-if="isAdmin" class="card-actions">
        <a-dropdown :trigger="['click']">
          <a-button type="text" size="small" class="more-btn">
            <template #icon><MoreOutlined /></template>
          </a-button>
          <template #overlay>
            <a-menu @click="onMenuClick">
              <a-menu-item key="edit">
                <EditOutlined /> 编辑
              </a-menu-item>
              <a-menu-item v-if="agent.status === 'enabled'" key="disable">
                <StopOutlined /> 停用
              </a-menu-item>
              <a-menu-item v-else key="enable">
                <PlayCircleOutlined /> 启用
              </a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { MoreOutlined, EditOutlined, StopOutlined, PlayCircleOutlined } from '@ant-design/icons-vue'
import { getIconComponent } from '../../utils/agent.js'

const props = defineProps({
  agent: {
    type: Object,
    required: true
  },
  isAdmin: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['edit', 'toggle-status'])

const iconComponent = computed(() => getIconComponent(props.agent.icon))

function onMenuClick({ key }) {
  if (key === 'edit') {
    emit('edit', props.agent)
  } else if (key === 'disable') {
    emit('toggle-status', props.agent, 'disabled')
  } else if (key === 'enable') {
    emit('toggle-status', props.agent, 'enabled')
  }
}
</script>

<style scoped>
.agent-card {
  background: linear-gradient(135deg, #f0f7ff 0%, #e8f4fd 50%, #f5f0ff 100%);
  border: 1px solid #dce9f7;
  border-radius: 12px;
  padding: 20px 24px;
  transition: all 0.3s ease;
  cursor: default;
}

.agent-card:hover {
  background: linear-gradient(135deg, #e8f2fc 0%, #ddeefb 50%, #eee8fc 100%);
  border-color: #b8d4f0;
  box-shadow: 0 4px 12px rgba(0, 80, 180, 0.06);
  transform: translateY(-1px);
}

.agent-card-disabled {
  opacity: 0.65;
  filter: grayscale(0.4);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 16px;
}

.card-icon {
  width: 42px;
  height: 42px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 20px;
  flex-shrink: 0;
}

.card-title-area {
  flex: 1;
  min-width: 0;
}

.card-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #262626;
}

.card-description {
  display: block;
  font-size: 13px;
  color: #8c8c8c;
  margin-top: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-actions {
  flex-shrink: 0;
}

.more-btn {
  color: #8c8c8c;
}
</style>