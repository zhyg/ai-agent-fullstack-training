import axios from 'axios'

// 知识库评测 API（014-knowledge-evaluation，契约 contracts/evaluation-api.md）：
// 沿用 traceApi.js 的 axios 实例 + Bearer 拦截器 + 401 清 token 跳登录模式
const api = axios.create({
  baseURL: `${import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'}/evaluations`,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// US1（T015）: 设置与测试集（契约 §1/§2）

function detailOf(error, fallback) {
  const detail = error.response?.data?.detail
  return new Error(detail || fallback)
}

export async function getSettings() {
  const res = await api.get('/settings')
  return res.data
}

export async function saveSettings(data) {
  try {
    const res = await api.put('/settings', data)
    return res.data
  } catch (error) {
    throw detailOf(error, '保存设置失败，请稍后重试')
  }
}

export async function listTestSets() {
  const res = await api.get('/test-sets')
  return res.data.items
}

export async function uploadTestSet(name, file) {
  const form = new FormData()
  form.append('name', name)
  form.append('file', file)
  try {
    const res = await api.post('/test-sets', form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
    return res.data
  } catch (error) {
    throw detailOf(error, '上传测试集失败，请稍后重试')
  }
}

export async function reuploadTestSet(testSetId, file) {
  const form = new FormData()
  form.append('file', file)
  try {
    const res = await api.put(`/test-sets/${testSetId}`, form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
    return res.data
  } catch (error) {
    throw detailOf(error, '重新上传失败，请稍后重试')
  }
}

// 详情预览复用下载接口（库内导出标准 JSON 数组，axios 自动解析为对象）
export async function getTestSetItems(testSetId) {
  try {
    const res = await api.get(`/test-sets/${testSetId}/download`)
    return res.data
  } catch (error) {
    throw detailOf(error, '加载测试集详情失败，请稍后重试')
  }
}

export async function downloadTestSet(testSetId) {
  try {
    const res = await api.get(`/test-sets/${testSetId}/download`, { responseType: 'blob' })
    return res.data
  } catch (error) {
    throw detailOf(error, '下载测试集失败，请稍后重试')
  }
}

export async function deleteTestSet(testSetId) {
  try {
    await api.delete(`/test-sets/${testSetId}`)
  } catch (error) {
    throw detailOf(error, '删除测试集失败，请稍后重试')
  }
}

// US2（T027）: 发起/取消/进度订阅（契约 §3）

export async function createRun(data) {
  try {
    const res = await api.post('/runs', data)
    return res.data
  } catch (error) {
    // 400 预检失效项汇总 / 409 已有进行中任务
    throw detailOf(error, '发起评测失败，请稍后重试')
  }
}

export async function cancelRun(runId) {
  try {
    const res = await api.post(`/runs/${runId}/cancel`)
    return res.data
  } catch (error) {
    throw detailOf(error, '取消评测失败，请稍后重试')
  }
}

/**
 * SSE 进度订阅（R6/R14）：fetch + Authorization 头流式读取（沿用 chatApi.js 模式，
 * 不用原生 EventSource/token-query）；断线重连靠 snapshot 事件恢复进度。
 * @param {string} runId
 * @param {function} onEvent - snapshot/progress/done 事件回调
 * @param {function} onError - 错误回调（message）
 * @param {AbortSignal} [signal] - 组件卸载/重新发起时中断读流
 */
export async function subscribeRunEvents(runId, onEvent, onError, signal) {
  const baseURL = `${import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'}/evaluations`
  const token = localStorage.getItem('access_token')

  const response = await fetch(`${baseURL}/runs/${runId}/events`, {
    headers: { Authorization: `Bearer ${token}` },
    signal
  })

  if (!response.ok) {
    let detail = '订阅评测进度失败'
    try {
      detail = (await response.json()).detail || detail
    } catch { /* ignore */ }
    onError(detail)
    return
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue
      const payload = line.slice(6).trim()
      if (!payload) continue
      try {
        const event = JSON.parse(payload)
        onEvent(event)
        if (event.type === 'done') return
      } catch { /* ignore parse errors */ }
    }
  }
}

// US3（T032）: listRuns/getRun/deleteRun（契约 §3）

export async function listRuns(page = 1, pageSize = 20) {
  const res = await api.get('/runs', { params: { page, page_size: pageSize } })
  return res.data // { items, total, page, page_size }
}

export async function getRun(runId) {
  try {
    const res = await api.get(`/runs/${runId}`)
    return res.data
  } catch (error) {
    throw detailOf(error, '加载评测详情失败，请稍后重试')
  }
}

export async function deleteRun(runId) {
  try {
    await api.delete(`/runs/${runId}`)
  } catch (error) {
    // 409：评测进行中须先取消
    throw detailOf(error, '删除评测记录失败，请稍后重试')
  }
}

export { api }