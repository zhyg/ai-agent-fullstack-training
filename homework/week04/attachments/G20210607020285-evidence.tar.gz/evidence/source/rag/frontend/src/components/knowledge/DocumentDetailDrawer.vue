<template>
  <a-drawer
    :open="visible"
    :title="document?.name || '文档详情'"
    width="70vw"
    :destroy-on-close="true"
    @close="$emit('close')"
  >
    <template v-if="document">
      <!-- Basic info -->
      <a-descriptions :column="2" bordered size="small">
        <a-descriptions-item label="名称" :span="2">
          {{ document.name }}
        </a-descriptions-item>
        <a-descriptions-item label="描述" :span="2">
          <!-- T042: Inline description editing -->
          <template v-if="!descEditing">
            <span>{{ document.description || '—' }}</span>
            <a-button
              type="text"
              size="small"
              style="margin-left: 8px"
              @click="startDescEdit"
            >
              <template #icon><EditOutlined /></template>
            </a-button>
          </template>
          <template v-else>
            <div style="display: flex; gap: 8px; width: 100%;">
              <a-input
                v-model:value="descValue"
                :maxlength="1000"
                style="flex: 1;"
              />
              <a-button type="primary" size="small" @click="saveDescription">保存</a-button>
              <a-button size="small" @click="cancelDescEdit">取消</a-button>
            </div>
          </template>
        </a-descriptions-item>
        <a-descriptions-item label="标签" :span="2">
          <a-tag
            v-for="tag in document.tags"
            :key="tag"
            color="blue"
            closable
            style="margin-right: 4px"
            @close.prevent.stop="$emit('remove-tag', document, tag)"
          >
            {{ tag }}
          </a-tag>
          <span v-if="!document.tags || document.tags.length === 0">—</span>
          <a-button
            type="link"
            size="small"
            @click="$emit('add-tag', document)"
          >
            新增
          </a-button>
        </a-descriptions-item>
        <a-descriptions-item label="大小">
          {{ formatFileSize(document.fileSize) }}
        </a-descriptions-item>
        <a-descriptions-item label="状态">
          <DocumentStatusTag :status="document.status" :connection-error="statusConnectionError" />
        </a-descriptions-item>
        <a-descriptions-item v-if="document.status === 'failed' && document.errorMessage" label="失败原因" :span="2">
          <a-alert :message="document.errorMessage" type="error" show-icon />
        </a-descriptions-item>
        <a-descriptions-item label="创建时间">
          {{ formatDate(document.createdAt) }}
        </a-descriptions-item>
        <a-descriptions-item label="更新时间">
          {{ formatDate(document.updatedAt) }}
        </a-descriptions-item>
      </a-descriptions>

      <a-divider class="content-divider">文档内容</a-divider>

      <a-tabs v-model:activeKey="activeContentTab" class="content-tabs">
        <!-- Original Content Tab -->
        <a-tab-pane key="original">
          <template #tab>
            <span>原始内容</span>
            <span class="tab-caption">SOURCE</span>
          </template>
          <div class="doc-content">
            <template v-if="contentLoading">
              <div class="content-state"><a-spin tip="正在读取原文件..." /></div>
            </template>
            <template v-else-if="contentError">
              <a-alert :message="contentError" type="error" show-icon />
            </template>
            <template v-else-if="rendererType === 'image' && imageUrl">
              <div class="image-preview">
                <img :src="imageUrl" :alt="document.name" />
              </div>
            </template>
            <template v-else-if="rendererType === 'markdown'">
              <MdPreview
                :modelValue="originalContent || ''"
                style="background: transparent"
              />
            </template>
            <template v-else-if="rendererType === 'office-docx' && fileArrayBuffer">
              <VueOfficeDocx :src="fileArrayBuffer" @rendered="onRendered" />
            </template>
            <template v-else-if="rendererType === 'office-excel' && fileArrayBuffer">
              <VueOfficeExcel
                class="excel-viewer"
                :src="fileArrayBuffer"
                @rendered="onRendered"
              />
            </template>
            <template v-else-if="rendererType === 'office-pptx' && fileArrayBuffer">
              <VueOfficePptx :src="fileArrayBuffer" @rendered="onRendered" />
            </template>
            <template v-else-if="rendererType === 'office-pdf' && fileArrayBuffer">
              <VueOfficePdf
                class="pdf-viewer"
                :src="fileArrayBuffer"
                @rendered="onRendered"
              />
            </template>
            <template v-else-if="originalContent !== null">
              <pre class="plain-content">{{ originalContent }}</pre>
            </template>
            <template v-else>
              <a-empty description="暂不支持预览" />
            </template>
          </div>
        </a-tab-pane>

        <!-- Parsed Markdown Tab -->
        <a-tab-pane v-if="document.mdPath" key="markdown">
          <template #tab>
            <span>解析后的 Markdown</span>
            <span class="tab-caption">MARKDOWN</span>
          </template>
          <div class="result-panel">
            <div class="result-heading">
              <div>
                <div class="result-title">结构化文本</div>
                <div class="result-subtitle">文档解析后的 Markdown 内容</div>
              </div>
              <a-tag color="blue">Markdown</a-tag>
            </div>
            <template v-if="parsedMdLoading">
              <div class="content-state"><a-spin tip="正在加载解析结果..." /></div>
            </template>
            <template v-else-if="parsedMdError">
              <a-alert :message="parsedMdError" type="warning" show-icon style="margin: 16px" />
            </template>
            <template v-else>
              <MdPreview
                :modelValue="parsedMarkdown"
                class="parsed-markdown"
              />
            </template>
          </div>
        </a-tab-pane>

        <!-- Chunks Tab -->
        <a-tab-pane key="chunks">
          <template #tab>
            <span>文档分片</span>
            <span class="tab-caption">CHUNKS</span>
          </template>
          <div class="chunks-panel">
            <template v-if="isProcessing">
              <div class="processing-state">
                <a-spin :tip="processingTip" />
                <p class="processing-hint">文档正在处理中，完成后自动刷新</p>
              </div>
            </template>
            <template v-else-if="document?.skippedFiles && document.skippedFiles.length > 0">
              <a-alert
                type="warning"
                show-icon
                style="margin-bottom: 12px"
              >
                <template #message>
                  <span>以下文件被跳过（不支持的格式）：{{ document.skippedFiles.join('、') }}</span>
                </template>
              </a-alert>
              <ChunkListPanel
                v-if="document?.id && document?.kbId"
                :doc-id="document.id"
                :kb-id="document.kbId"
              />
            </template>
            <template v-else>
              <ChunkListPanel
                v-if="document?.id && document?.kbId"
                :doc-id="document.id"
                :kb-id="document.kbId"
              />
            </template>
          </div>
        </a-tab-pane>
      </a-tabs>
    </template>
  </a-drawer>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { message } from 'ant-design-vue'
import { EditOutlined } from '@ant-design/icons-vue'
import { MdPreview } from 'md-editor-v3'
import 'md-editor-v3/lib/preview.css'
import VueOfficeDocx from '@vue-office/docx'
import '@vue-office/docx/lib/index.css'
import VueOfficeExcel from '@vue-office/excel'
import '@vue-office/excel/lib/index.css'
import VueOfficePptx from '@vue-office/pptx'
import VueOfficePdf from '@vue-office/pdf'
import { formatFileSize, getRendererType } from '../../utils/file.js'
import { useDocumentStore } from '../../stores/document.js'
import DocumentStatusTag from './DocumentStatusTag.vue'
import ChunkListPanel from './ChunkListPanel.vue'
import axios from 'axios'

const props = defineProps({
  visible: { type: Boolean, required: true },
  document: { type: Object, default: null },
  statusConnectionError: { type: String, default: '' }
})

const emit = defineEmits(['close', 'add-tag', 'remove-tag'])

const documentStore = useDocumentStore()

// Content state
const originalContent = ref(null)
const parsedContent = ref('')
const fileArrayBuffer = ref(null)
const imageUrl = ref('')
const contentLoading = ref(false)
const contentError = ref('')
const activeContentTab = ref('original')

// T042: Description editing state
const descEditing = ref(false)
const descValue = ref('')

const rendererType = computed(() => {
  const extension =
    props.document?.extension || props.document?.name?.split('.').pop() || ''
  return getRendererType(extension)
})

// Parsed markdown state
const parsedMdLoading = ref(false)
const parsedMdError = ref('')

const parsedMarkdown = computed(() => {
  return parsedContent.value || '> 解析结果没有可显示的内容。'
})

const TERMINAL_STATUSES = new Set(['completed', 'failed', 'success'])
const PROCESSING_STATUSES = {
  pending: '等待处理...',
  parsing: '正在解析文档...',
  chunking: '正在切分文档...',
  embedding: '正在生成向量...',
  ai_generating: '正在生成 AI 问题...',
}

const isProcessing = computed(() => {
  const s = props.document?.status
  return s && !TERMINAL_STATUSES.has(s)
})

const processingTip = computed(() => {
  return PROCESSING_STATUSES[props.document?.status] || '处理中...'
})

// T042: Inline description editing
function startDescEdit() {
  descValue.value = props.document?.description || ''
  descEditing.value = true
}

function cancelDescEdit() {
  descEditing.value = false
}

async function saveDescription() {
  if (!props.document) return
  const result = await documentStore.updateDocument(props.document.id, {
    description: descValue.value
  })
  if (result.success) {
    message.success('描述已保存')
    descEditing.value = false
  } else {
    message.error(result.message || '保存失败')
  }
}

function formatDate(ts) {
  if (!ts) return '—'
  const d = new Date(ts)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`
}

function onRendered() {
  // placeholder callback
}

// T043: Watch and load file content when drawer opens
watch(
  () => [props.visible, props.document?.id],
  async ([visible, id], _, onCleanup) => {
    let cancelled = false
    let objectUrl = ''
    onCleanup(() => {
      cancelled = true
      if (objectUrl) URL.revokeObjectURL(objectUrl)
    })
    // Reset state
    originalContent.value = null
    parsedContent.value = ''
    fileArrayBuffer.value = null
    imageUrl.value = ''
    contentError.value = ''
    contentLoading.value = false
    activeContentTab.value = 'original'
    descEditing.value = false
    parsedMdLoading.value = false
    parsedMdError.value = ''
    if (!visible || !id) return
    contentLoading.value = true
    const type = rendererType.value
    try {
      if (type === 'markdown') {
        const content = await documentStore.getDocumentMarkdownPreview(id, { source: true })
        if (!cancelled) originalContent.value = content
        return
      }
      // Get presigned URL then fetch file blob
      const url = await documentStore.getDocumentFileUrl(id)
      if (cancelled) return
      if (!url) throw new Error('无法获取文件地址')

      // Presigned URL already includes auth signature, no extra headers needed
      const res = await axios.get(url, {
        responseType: 'blob'
      })
      if (cancelled) return

      const blob = res.data
      if (type === 'image') {
        objectUrl = URL.createObjectURL(blob)
        if (!cancelled) imageUrl.value = objectUrl
      } else if (type.startsWith('office-')) {
        const buffer = await blob.arrayBuffer()
        if (!cancelled) fileArrayBuffer.value = buffer
      } else {
        const text = await blob.text()
        if (!cancelled) originalContent.value = text
      }
    } catch (err) {
      if (cancelled) return
      contentError.value = err.message || '读取原文件失败'
      console.error('load document content failed', err)
    } finally {
      if (!cancelled) contentLoading.value = false
    }
  },
  { immediate: true }
)

watch(
  [() => props.visible, () => props.document?.id, () => props.document?.mdPath],
  ([visible, id, mdPath], _, onCleanup) => {
    if (!mdPath) {
      if (activeContentTab.value === 'markdown') activeContentTab.value = 'original'
      parsedContent.value = ''
      parsedMdError.value = ''
      parsedMdLoading.value = false
      return
    }
    if (!visible || !id) {
      parsedMdLoading.value = false
      return
    }
    let cancelled = false
    onCleanup(() => { cancelled = true })
    loadParsedMarkdown(id, () => !cancelled)
  },
  { immediate: true }
)

async function loadParsedMarkdown(id, isCurrent) {
  parsedMdLoading.value = true
  parsedMdError.value = ''
  try {
    const content = await documentStore.getDocumentMarkdownPreview(id)
    if (isCurrent()) parsedContent.value = content
  } catch (e) {
    if (!isCurrent()) return
    parsedMdError.value = e.response?.data?.detail || '加载解析结果失败'
    console.error('load parsed markdown failed', e)
  } finally {
    if (isCurrent()) parsedMdLoading.value = false
  }
}
</script>

<style scoped>
.content-divider {
  margin: 20px 0 12px;
  color: #202a35;
  font-weight: 600;
}

.content-tabs :deep(.ant-tabs-nav) {
  margin-bottom: 16px;
}

.content-tabs :deep(.ant-tabs-tab) {
  padding: 10px 2px;
}

.tab-caption {
  margin-left: 8px;
  color: #9aa4b2;
  font-size: 10px;
  letter-spacing: 0.07em;
}

.doc-content {
  min-height: 220px;
}

.image-preview {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 220px;
  max-height: 72vh;
  overflow: auto;
  padding: 16px;
  border: 1px solid #edf0f3;
  border-radius: 8px;
  background:
    linear-gradient(45deg, #f5f7f9 25%, transparent 25%),
    linear-gradient(-45deg, #f5f7f9 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #f5f7f9 75%),
    linear-gradient(-45deg, transparent 75%, #f5f7f9 75%);
  background-size: 20px 20px;
  background-position: 0 0, 0 10px, 10px -10px, -10px 0;
}

.image-preview img {
  display: block;
  max-width: 100%;
  max-height: calc(72vh - 34px);
  object-fit: contain;
}

.content-state {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 220px;
  border: 1px solid #edf0f3;
  border-radius: 8px;
  background: #fbfcfd;
}

.result-panel,
.chunks-panel {
  overflow: hidden;
  border: 1px solid #e9edf1;
  border-radius: 8px;
  background: #fff;
}

.result-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  padding: 17px 20px;
  border-bottom: 1px solid #edf0f3;
  background: #fbfcfd;
}

.result-title {
  color: #263340;
  font-size: 14px;
  font-weight: 600;
}

.result-subtitle {
  margin-top: 4px;
  color: #8994a2;
  font-size: 12px;
}

.parsed-markdown {
  min-height: 240px;
}

.parsed-markdown :deep(.md-editor-preview-wrapper) {
  padding: 20px 24px;
}

.chunks-panel {
  padding: 16px;
}

.processing-state {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 220px;
}

.processing-hint {
  margin-top: 12px;
  color: #8c8c8c;
  font-size: 13px;
}

.excel-viewer {
  width: 100%;
  height: 65vh;
  min-height: 520px;
  overflow: hidden;
  border: 1px solid #f0f0f0;
  border-radius: 6px;
}

.pdf-viewer {
  width: 100%;
  height: 75vh;
  min-height: 560px;
  overflow: auto;
  background: #f5f5f5;
  border: 1px solid #f0f0f0;
  border-radius: 6px;
}

.plain-content {
  background: #fafafa;
  padding: 16px;
  border-radius: 6px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: ui-monospace, 'SF Mono', Menlo, monospace;
  font-size: 13px;
  max-height: 60vh;
  overflow: auto;
}
</style>
