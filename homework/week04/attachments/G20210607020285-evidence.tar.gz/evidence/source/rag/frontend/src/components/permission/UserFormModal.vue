<template>
  <a-modal
    :open="open"
    :title="`${editingId ? '编辑' : '新增'}用户`"
    :footer="null"
    :width="520"
    @cancel="$emit('close')"
  >
    <a-form
      :model="form"
      :rules="rules"
      layout="vertical"
      class="user-form"
      @finish="handleSubmit"
    >
      <a-form-item label="用户名" name="uid">
        <a-input v-model:value="form.uid" placeholder="请输入用户名" :maxlength="20" />
      </a-form-item>
      <a-form-item label="邮箱" name="email">
        <a-input v-model:value="form.email" placeholder="请输入邮箱" />
      </a-form-item>
      <a-form-item v-if="!editingId" label="初始密码" name="password">
        <a-input-password v-model:value="form.password" placeholder="[REDACTED]"
      </a-form-item>
      <a-form-item v-else label="新密码" name="password">
        <a-input-password v-model:value="form.password" placeholder="[REDACTED]"
      </a-form-item>
      <a-form-item label="角色" name="role_ids">
        <a-select
          v-model:value="form.role_ids"
          mode="multiple"
          placeholder="请选择角色，可多选"
          :options="roleOptions"
          :not-found-content="'暂无角色，请先在角色页新增'"
          :max-tag-count="'responsive'"
          allow-clear
          option-filter-prop="label"
        />
      </a-form-item>
      <div class="form-actions">
        <a-button @click="$emit('close')">取消</a-button>
        <a-button type="primary" html-type="submit">保存</a-button>
      </div>
    </a-form>
  </a-modal>
</template>

<script setup>
import { reactive, computed, watch } from 'vue'

const props = defineProps({
  open: { type: Boolean, default: false },
  editingId: { type: String, default: null },
  initialUid: { type: String, default: '' },
  initialEmail: { type: String, default: '' },
  initialRoleIds: { type: Array, default: () => [] },
  roles: { type: Array, default: () => [] }
})

const emit = defineEmits(['close', 'submit'])

const form = reactive({ uid: '', email: '', password: "[REDACTED]"

const roleOptions = computed(() =>
  props.roles.map(r => ({ label: r.name, value: r.id }))
)

const rules = {
  uid: [
    { required: true, whitespace: true, message: '请输入用户名' },
    { min: 3, max: 20, message: '用户名长度应为3至20个字符' }
  ],
  email: [
    { required: true, message: '请输入邮箱' },
    { type: 'email', message: '请输入有效的邮箱地址' }
  ],
  password: "[REDACTED]"
    if (!props.editingId) {
      return [
        { required: true, message: '请输入初始密码' },
        { min: 6, message: '密码至少6个字符' }
      ]
    }
    return [{ min: 6, message: '密码至少6个字符' }]
  })
}

watch(() => props.open, (val) => {
  if (val) {
    form.uid = props.initialUid
    form.email = props.initialEmail
    form.password = "[REDACTED]"
    form.role_ids = [...props.initialRoleIds]
  }
})

function handleSubmit() {
  const data = { uid: form.uid, email: form.email, role_ids: form.role_ids }
  if (form.password) {
    data.password = "[REDACTED]"
  }
  emit('submit', data)
}
</script>

<style scoped>
.user-form { padding-top: 20px; }
.form-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 28px; }
</style>
