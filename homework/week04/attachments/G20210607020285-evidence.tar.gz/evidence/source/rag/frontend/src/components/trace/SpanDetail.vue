<template>
  <div class="span-detail">
    <div class="detail-header">
      <a-typography-title :level="5" style="margin: 0">{{ span.operationName }}</a-typography-title>
      <a-space>
        <a-tag v-if="callId" color="blue">call_id: {{ callId }}</a-tag>
        <a-typography-text code>{{ span.spanID }}</a-typography-text>
        <a-button type="text" size="small" @click.stop="copySpanID">
          <template #icon><CopyOutlined /></template>
        </a-button>
      </a-space>
    </div>

    <a-descriptions size="small" :column="4" style="margin: 12px 0">
      <a-descriptions-item label="Service">{{ span.serviceName }}</a-descriptions-item>
      <a-descriptions-item label="Duration">
        <a-typography-text strong>{{ formatDuration(span.duration) }}</a-typography-text>
      </a-descriptions-item>
      <a-descriptions-item label="Start Time">{{ formatDuration(span.relativeStart) }}</a-descriptions-item>
    </a-descriptions>

    <a-collapse :default-active-key="defaultActiveKeys" ghost>
      <!-- 输入/输出（agent.input / agent.output 完整 JSON，不脱敏） -->
      <a-collapse-panel v-if="agentInput" key="input" header="输入（agent.input）">
        <pre class="json-block">{{ agentInput }}</pre>
      </a-collapse-panel>
      <a-collapse-panel v-if="agentOutput" key="output" header="输出（agent.output）">
        <pre class="json-block">{{ agentOutput }}</pre>
      </a-collapse-panel>
      <!-- 检索片段全文（013 FR-002，不截断） -->
      <a-collapse-panel v-if="retrievalChunks" key="chunks" header="检索片段（retrieval.chunks）">
        <pre class="json-block">{{ retrievalChunks }}</pre>
      </a-collapse-panel>
      <!-- 历史检索命中轮次问答全文（history.rounds，不截断） -->
      <a-collapse-panel v-if="historyRounds" key="historyRounds" header="历史片段详情（history.rounds）">
        <pre class="json-block">{{ historyRounds }}</pre>
      </a-collapse-panel>

      <!-- Tags -->
      <a-collapse-panel v-if="span.tags?.length" key="tags" :header="`Tags (${span.tags.length})`">
        <a-table
          :columns="tagColumns"
          :data-source="span.tags.map(t => ({ key: t.key, value: formatTagValue(t.value) }))"
          size="small"
          :pagination="false"
          bordered
        />
      </a-collapse-panel>

      <!-- Process -->
      <a-collapse-panel v-if="span.process?.tags?.length" key="process" :header="`Process (${span.process.tags.length})`">
        <a-table
          :columns="tagColumns"
          :data-source="span.process.tags.map(t => ({ key: t.key, value: formatTagValue(t.value) }))"
          size="small"
          :pagination="false"
          bordered
        />
      </a-collapse-panel>

      <!-- Logs（事件：rerank_degraded / forced_convergence 等） -->
      <a-collapse-panel v-if="span.logs?.length" key="logs" :header="`Logs (${span.logs.length})`">
        <div v-for="(log, i) in span.logs" :key="i" class="log-entry">
          <a-typography-text type="secondary" class="log-timestamp">
            {{ formatDuration(log.timestamp - traceStart) }}
          </a-typography-text>
          <a-table
            :columns="tagColumns"
            :data-source="log.fields.map(f => ({ key: f.key, value: formatTagValue(f.value) }))"
            size="small"
            :pagination="false"
            bordered
            style="margin-top: 4px"
          />
        </div>
      </a-collapse-panel>
    </a-collapse>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { CopyOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { formatDuration } from './traceUtils.js'

const props = defineProps({
  span: { type: Object, required: true },
  traceStart: { type: Number, required: true }
})

const tagColumns = [
  { title: 'Key', dataIndex: 'key', key: 'key', width: 220, className: 'tag-key-col' },
  { title: 'Value', dataIndex: 'value', key: 'value', ellipsis: true }
]

function tagValue(key) {
  const tag = (props.span.tags || []).find(t => t.key === key)
  return tag ? String(tag.value) : ''
}

function prettyJson(raw) {
  if (!raw) return ''
  try {
    return JSON.stringify(JSON.parse(raw), null, 2)
  } catch {
    return raw
  }
}

const agentInput = computed(() => prettyJson(tagValue('agent.input')))
const agentOutput = computed(() => prettyJson(tagValue('agent.output')))
const retrievalChunks = computed(() => prettyJson(tagValue('retrieval.chunks')))
const historyRounds = computed(() => prettyJson(tagValue('history.rounds')))
const callId = computed(() => tagValue('tool.call_id'))

const defaultActiveKeys = computed(() => {
  const keys = []
  if (agentInput.value) keys.push('input')
  if (agentOutput.value) keys.push('output')
  if (retrievalChunks.value) keys.push('chunks')
  if (historyRounds.value) keys.push('historyRounds')
  if (!keys.length) keys.push('tags')
  return keys
})

function formatTagValue(val) {
  return String(val)
}

async function copySpanID() {
  try {
    await navigator.clipboard.writeText(props.span.spanID)
    message.success('SpanID 已复制')
  } catch {
    message.error('复制失败')
  }
}
</script>

<style scoped>
.span-detail { padding: 4px 0; }
.detail-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.log-entry { margin-bottom: 12px; }
.log-timestamp { font-family: 'JetBrains Mono', monospace; font-size: 11px; }
.json-block {
  margin: 0;
  padding: 12px;
  background: #fff;
  border: 1px solid #f0f0f0;
  border-radius: 6px;
  font-size: 12px;
  font-family: 'JetBrains Mono', 'SF Mono', monospace;
  white-space: pre-wrap;
  word-break: break-all;
  max-height: 360px;
  overflow: auto;
}
:deep(.tag-key-col) { font-family: 'JetBrains Mono', monospace; color: #165dff; font-weight: 500; }
:deep(.ant-collapse-header) { font-weight: 600 !important; padding: 8px 0 !important; }
:deep(.ant-collapse-content-box) { padding: 0 !important; }
</style>