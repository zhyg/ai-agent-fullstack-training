<template>
  <div class="register-container">
    <div class="register-card">
      <div class="register-header">
        <div class="logo">
          <ApiOutlined />
        </div>
        <h1>开发者门户</h1>
        <p>创建新账号</p>
      </div>
      
      <a-form
        :model="formState"
        :rules="rules"
        @finish="handleRegister"
        layout="vertical"
      >
        <a-form-item label="账号" name="uid">
          <a-input
            v-model:value="formState.uid"
            size="large"
            placeholder="请输入账号（3-20字符）"
          >
            <template #prefix>
              <UserOutlined />
            </template>
          </a-input>
        </a-form-item>

        <a-form-item label="邮箱" name="email">
          <a-input
            v-model:value="formState.email"
            size="large"
            placeholder="请输入邮箱"
          >
            <template #prefix>
              <MailOutlined />
            </template>
          </a-input>
        </a-form-item>

        <a-form-item label="密码" name="password">
          <a-input-password
            v-model:value="formState.password"
            size="large"
            placeholder="请输入密码（至少6位）"
          >
            <template #prefix>
              <LockOutlined />
            </template>
          </a-input-password>
        </a-form-item>

        <a-form-item label="确认密码" name="confirmPassword">
          <a-input-password
            v-model:value="formState.confirmPassword"
            size="large"
            placeholder="请再次输入密码"
          >
            <template #prefix>
              <LockOutlined />
            </template>
          </a-input-password>
        </a-form-item>

        <a-form-item>
          <a-button
            type="primary"
            html-type="submit"
            size="large"
            block
            :loading="loading"
          >
            注册
          </a-button>
        </a-form-item>

        <div class="register-footer">
          <span>已有账号？</span>
          <a-button type="link" @click="goToLogin" class="login-link">
            立即登录
          </a-button>
        </div>
      </a-form>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { UserOutlined, LockOutlined, ApiOutlined, MailOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { useUserStore } from '../stores/user.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

const router = useRouter()
const userStore = useUserStore()
const loading = ref(false)

const formState = reactive({
  uid: '',
  email: '',
  password: "[REDACTED]"
  confirmPassword: "[REDACTED]"
})

const validateConfirmPassword = "[REDACTED]"
  if (value && value !== formState.password) {
    return Promise.reject('两次输入的密码不一致')
  }
  return Promise.resolve()
}

const rules = {
  uid: [
    { required: true, message: '请输入账号', trigger: 'blur' },
    { min: 3, message: '账号至少3个字符', trigger: 'blur' },
    { max: 20, message: '账号最多20个字符', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入有效的邮箱地址', trigger: 'blur' }
  ],
  password: "[REDACTED]"
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少6个字符', trigger: 'blur' }
  ],
  confirmPassword: "[REDACTED]"
    { required: true, message: '请确认密码', trigger: 'blur' },
    { validator: validateConfirmPassword, trigger: "[REDACTED]"
  ]
}

async function handleRegister() {
  if (!formState.uid || !formState.email || !formState.password || !formState.confirmPassword) {
    message.warning('请填写完整的注册信息')
    return
  }

  loading.value = true
  
  try {
    const result = await userStore.register({
      uid: formState.uid,
      email: formState.email,
      password: "[REDACTED]"
    })
    
    if (result.success) {
      message.success(result.message)
      setTimeout(() => {
        router.push('/login')
      }, 1000)
    } else {
      message.error(result.message)
    }
  } catch (error) {
    message.error(extractErrorMessage(error, '注册失败，请稍后重试'))
  } finally {
    loading.value = false
  }
}

function goToLogin() {
  router.push('/login')
}
</script>

<style scoped>
.register-container {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #e0e7ff 0%, #ddd6fe 50%, #fae8ff 100%);
  padding: 20px;
}

.register-card {
  width: 100%;
  max-width: 420px;
  background: #fff;
  border-radius: 16px;
  padding: 48px 40px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.register-header {
  text-align: center;
  margin-bottom: 40px;
}

.logo {
  width: 64px;
  height: 64px;
  background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px;
  font-size: 32px;
  color: #fff;
}

.register-header h1 {
  font-size: 28px;
  font-weight: 600;
  color: #1f1f1f;
  margin: 0 0 8px 0;
}

.register-header p {
  font-size: 15px;
  color: #8c8c8c;
  margin: 0;
}

.register-footer {
  text-align: center;
  color: #8c8c8c;
  font-size: 14px;
}

.login-link {
  padding: 0;
  height: auto;
  font-size: 14px;
}

:deep(.ant-form-item-label > label) {
  font-weight: 500;
  color: #1f1f1f;
}

:deep(.ant-input-affix-wrapper) {
  border-radius: 8px;
}

:deep(.ant-btn) {
  border-radius: 8px;
  height: 44px;
  font-weight: 500;
}
</style>
