import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as agentApi from '../services/agentApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'
import { getDefaultConfig } from '../utils/agent.js'

export const useAgentStore = defineStore('agent', () => {
  const agents = ref([])
  const loading = ref(false)

  // 当前编辑态：打开弹窗时深拷贝草稿，取消/关闭丢弃，保存成功后刷新列表
  const editingAgent = ref(null)
  const editDraft = ref(null)

  async function fetchAgents() {
    loading.value = true
    try {
      const data = await agentApi.listAgents()
      agents.value = data.items
    } catch (error) {
      console.error('Failed to fetch agents:', error)
    } finally {
      loading.value = false
    }
  }

  async function toggleStatus(agentId, status) {
    loading.value = true
    try {
      const updated = await agentApi.updateAgentStatus(agentId, status)
      const idx = agents.value.findIndex((a) => a.id === agentId)
      if (idx !== -1) agents.value[idx] = updated
      return { success: true, message: status === 'disabled' ? '智能体已停用' : '智能体已启用' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  function openEdit(agent) {
    editingAgent.value = agent
    const config = JSON.parse(JSON.stringify(agent.config))
    // 存量配置缺历史信息检索键时以默认值补齐草稿（013 决策8，与后端 Pydantic 兜底同步）
    if (!config.history_retrieval) {
      config.history_retrieval = getDefaultConfig(agent.type).history_retrieval
    }
    editDraft.value = {
      name: agent.name,
      icon: agent.icon,
      description: agent.description,
      config
    }
  }

  function closeEdit() {
    editingAgent.value = null
    editDraft.value = null
  }

  async function saveEdit() {
    if (!editingAgent.value || !editDraft.value) {
      return { success: false, message: '无正在编辑的智能体' }
    }
    loading.value = true
    try {
      await agentApi.updateAgent(editingAgent.value.id, editDraft.value)
      await fetchAgents()
      closeEdit()
      return { success: true, message: '智能体配置保存成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  return {
    agents,
    loading,
    editingAgent,
    editDraft,
    fetchAgents,
    toggleStatus,
    openEdit,
    closeEdit,
    saveEdit
  }
})