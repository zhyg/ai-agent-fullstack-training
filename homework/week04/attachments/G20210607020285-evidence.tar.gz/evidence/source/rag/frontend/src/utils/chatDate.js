export function formatChatDateTime(value) {
  if (!value) return ''

  const timestamp = String(value)
  // The backend's timezone-naive TIMESTAMP values are stored as UTC.
  const normalized = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(timestamp)
    ? timestamp
    : `${timestamp}Z`
  const date = new Date(normalized)
  if (Number.isNaN(date.getTime())) return ''

  const pad = (part) => String(part).padStart(2, '0')
  return `${date.getFullYear()}年${pad(date.getMonth() + 1)}月${pad(date.getDate())}日 ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}
