<template>
  <div class="role-table">
    <div class="table-toolbar">
      <a-button type="primary" @click="$emit('create')">
        <template #icon><PlusOutlined /></template>
        新增角色
      </a-button>
    </div>
    <a-table
      :columns="columns"
      :data-source="roles"
      row-key="id"
      :pagination="false"
      :loading="loading"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'created_at'">
          {{ formatTime(record.created_at) }}
        </template>
        <template v-else-if="column.key === 'actions'">
          <a-space :size="4">
            <a-button type="text" title="编辑" @click="$emit('edit', record)">
              <template #icon><EditOutlined /></template>
            </a-button>
            <a-tooltip :title="isRoleAssigned(record.id) ? '该角色已分配给用户，请先解除关联' : '删除角色'">
              <span>
                <a-button type="text" danger title="删除" :disabled="isRoleAssigned(record.id)" @click="confirmDelete(record)">
                  <template #icon><DeleteOutlined /></template>
                </a-button>
              </span>
            </a-tooltip>
          </a-space>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup>
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { Modal } from 'ant-design-vue'

const props = defineProps({
  roles: { type: Array, default: () => [] },
  users: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false }
})

const emit = defineEmits(['create', 'edit', 'delete'])

const columns = [
  { title: '角色名', dataIndex: 'name', width: 200 },
  { title: '描述', dataIndex: 'description', width: 300 },
  { title: '创建时间', key: 'created_at', width: 200 },
  { title: '操作', key: 'actions', width: 120, align: 'center' }
]

function isRoleAssigned(roleId) {
  return props.users.some(u => (u.role_ids || []).includes(roleId))
}

function formatTime(timeStr) {
  if (!timeStr) return '—'
  return new Date(timeStr).toLocaleString('zh-CN', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false
  }).replaceAll('/', '-')
}

function confirmDelete(record) {
  Modal.confirm({
    title: '确认删除角色',
    content: `确定要删除角色 "${record.name}" 吗？删除后不可恢复。`,
    okText: '删除',
    okType: 'danger',
    cancelText: '取消',
    onOk() { emit('delete', record.id) }
  })
}
</script>

<style scoped>
.table-toolbar { display: flex; justify-content: flex-end; margin-bottom: 16px; }
</style>
