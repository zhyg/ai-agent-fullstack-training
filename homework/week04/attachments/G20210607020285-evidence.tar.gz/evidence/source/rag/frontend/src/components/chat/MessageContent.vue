<template>
  <div class="message-body" @click="handleClick" @error.capture="handleImgError">
    <MdPreview
      v-if="message.role === 'assistant'"
      :editor-id="`km-msg-${message.id}`"
      :model-value="renderedContent"
      class="md-body"
    />
    <div v-else class="plain-text">{{ message.content }}</div>

    <a-tag v-if="message.meta?.stopped" color="orange" class="stopped-tag">已停止</a-tag>
    <a-tag v-if="convergenceLabel" color="cyan" class="stopped-tag">{{ convergenceLabel }}</a-tag>

    <a-alert
      v-if="message.error"
      type="error"
      show-icon
      class="error-alert"
      :message="errorTitle"
    >
      <template #description>
        <div>{{ message.error.message }}</div>
        <a-collapse v-if="message.error.raw_output" ghost size="small">
          <a-collapse-panel key="raw" header="查看模型原始输出">
            <pre class="raw-output">{{ message.error.raw_output }}</pre>
          </a-collapse-panel>
        </a-collapse>
      </template>
    </a-alert>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { MdPreview } from 'md-editor-v3'
import 'md-editor-v3/lib/preview.css'

const props = defineProps({
  message: { type: Object, required: true }
})

const emit = defineEmits(['open-ref', 'image-error'])

const references = computed(() =>
  props.message.references || props.message.meta?.references || []
)

const errorTitle = computed(() =>
  props.message.error?.code ? `错误（${props.message.error.code}）` : '错误'
)

// 循环收敛完成态文案（US2：强制收敛/空转提前收敛，meta.events 随 done 事件/回放下发）
const convergenceLabel = computed(() => {
  const events = props.message.meta?.events || []
  if (events.some(e => e.event === 'forced_convergence')) return '已达最大循环轮次，基于已有资料收敛作答'
  if (events.some(e => e.event === 'idle_loop_converged')) return '检测到重复提问，已提前收敛作答'
  return ''
})

// <ref id="cN"/> → 可点击上标 [N]；未知句柄直接移除（后端已过滤，双保险）
const renderedContent = computed(() => {
  const valid = new Set(references.value.map(r => r.handle))
  return (props.message.content || '').replace(
    /<ref\s+id="(c\d+)"\s*\/>/g,
    (match, handle) => {
      if (!valid.has(handle)) return ''
      const num = handle.replace(/^c/, '')
      return `<sup class="km-ref" data-ref="${handle}">[${num}]</sup>`
    }
  )
})

function handleClick(e) {
  const mark = e.target.closest?.('.km-ref')
  if (!mark) return
  const ref = references.value.find(r => r.handle === mark.dataset.ref)
  if (ref) emit('open-ref', ref)
}

// 图片加载失败（预签名过期）→ 触发 refresh-urls 重签，每张图仅触发一次
function handleImgError(e) {
  if (e.target?.tagName === 'IMG' && !e.target.dataset.refreshed) {
    e.target.dataset.refreshed = '1'
    emit('image-error', props.message)
  }
}
</script>

<style scoped>
.message-body { min-width: 0; }
.plain-text { white-space: pre-wrap; word-wrap: break-word; }
.md-body { background: transparent; }
.md-body :deep(.md-editor-preview-wrapper) { padding: 0; }
.md-body :deep(.md-editor-preview) { font-size: 14px; line-height: 1.6; word-break: break-word; }
.md-body :deep(.md-editor-preview p) { margin: 0 0 8px; }
.md-body :deep(.md-editor-preview img) { max-width: 100%; }
.md-body :deep(.km-ref) {
  color: #1890ff;
  cursor: pointer;
  font-size: 11px;
  margin: 0 2px;
  user-select: none;
}
.md-body :deep(.km-ref:hover) { text-decoration: underline; }
.stopped-tag { margin-top: 8px; }
.error-alert { margin-top: 8px; }
.raw-output { white-space: pre-wrap; word-break: break-all; font-size: 12px; margin: 0; max-height: 240px; overflow: auto; }
</style>