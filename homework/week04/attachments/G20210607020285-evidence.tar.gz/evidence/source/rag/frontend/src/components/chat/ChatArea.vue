<template>
  <div class="chat-area-container">
    <div v-if="!currentChat" class="empty-state">
      <a-empty description="选择或创建一个会话开始聊天">
        <template #image>
          <div class="empty-icon"><MessageOutlined /></div>
        </template>
        <a-button type="primary" @click="$emit('create-chat')">
          <template #icon><PlusOutlined /></template>
          新建会话
        </a-button>
      </a-empty>
    </div>

    <div v-else class="chat-content">
      <div class="chat-header">
        <div class="chat-header-title">
          <MessageOutlined style="margin-right: 8px; color: #1890ff;" />
          {{ currentChat.title }}
        </div>
        <div class="chat-header-info">
          <a-tag v-if="currentChat.status === 'generating'" color="processing">
            <template #icon><LoadingOutlined /></template>
            生成中...
          </a-tag>
          <template v-if="currentChat.agent_id">
            <a-tag color="purple">
              <template #icon><RobotOutlined /></template>
              {{ agentName }}
            </a-tag>
            <a-tag color="blue">
              <template #icon><DatabaseOutlined /></template>
              知识库 × {{ (currentChat.knowledge_base_ids || []).length }}
            </a-tag>
          </template>
          <template v-else>
            <a-tag v-if="currentModelName" color="blue">
              <template #icon><ApiOutlined /></template>
              {{ currentModelName }}
            </a-tag>
            <a-tag v-if="currentChat.prompt_id" color="green">
              <template #icon><FileTextOutlined /></template>
              {{ getPromptName(currentChat.prompt_id) }}
            </a-tag>
          </template>
        </div>
      </div>

      <div class="messages-container" ref="messagesContainer" @scroll="handleMessagesScroll">
        <div v-if="messages.length === 0" class="messages-empty">
          <div class="welcome-message">
            <div class="welcome-icon"><RobotOutlined /></div>
            <h3>你好！我是 AI 助手</h3>
            <p>选择知识库与智能体，开始提问吧</p>
          </div>
        </div>

        <div
          v-for="msg in messages"
          :key="msg.id"
          :class="['message-item', msg.role]"
        >
          <div class="message-avatar">
            <a-avatar v-if="msg.role === 'user'" :size="36">
              <template #icon><UserOutlined /></template>
            </a-avatar>
            <a-avatar v-else :size="36" style="background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);">
              <template #icon><RobotOutlined /></template>
            </a-avatar>
          </div>
          <div class="message-content">
            <div class="message-header">
              {{ msg.role === 'user' ? '你' : 'AI 助手' }}
              <span class="message-time">{{ formatChatDateTime(msg.created_at) }}</span>
              <a-button
                v-if="msg.role === 'assistant' && msg.trace_id && !String(msg.id).startsWith('streaming-')"
                type="link"
                size="small"
                class="trace-btn"
                @click="openTrace(msg)"
              >
                <template #icon><PartitionOutlined /></template>
                trace
              </a-button>
            </div>
            <div class="message-text">
              <MessageContent
                :message="msg"
                @open-ref="openReference"
                @image-error="handleImageError"
              />
            </div>
          </div>
        </div>

        <div v-if="isStreaming && messages.length > 0 && !messages[messages.length - 1].content" class="message-item assistant">
          <div class="message-avatar">
            <a-avatar :size="36" style="background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);">
              <template #icon><RobotOutlined /></template>
            </a-avatar>
          </div>
          <div class="message-content">
            <div class="message-header">AI 助手</div>
            <div class="message-text typing"><span></span><span></span><span></span></div>
          </div>
        </div>
      </div>

      <div v-if="stepProgress" class="step-progress">
        <LoadingOutlined style="margin-right: 8px;" />
        {{ stepText }}
      </div>

      <MessageInput
        v-if="!isLegacyChat"
        :agents="agents"
        :knowledge-bases="knowledgeBases"
        :current-agent-id="currentChat.agent_id"
        :current-kb-ids="currentChat.knowledge_base_ids || []"
        :is-streaming="isStreaming"
        :is-cancelling="isCancelling"
        @send="handleSend"
        @cancel="$emit('cancel')"
        ref="messageInputRef"
      />
      <div v-else class="legacy-readonly">
        <AlertOutlined style="margin-right: 6px;" />
        存量会话（旧模型 + 提示词模式）仅供查看，不支持继续提问
      </div>
    </div>

    <!-- 引用来源弹层（澄清 Q3：文档名 + 片段内容 + 查看文档） -->
    <a-modal
      v-model:open="refModalVisible"
      :title="activeReference?.file_name || '引用来源'"
      :footer="null"
      width="640px"
    >
      <div v-if="activeReference" class="ref-modal-body">
        <MdPreview
          editor-id="km-ref-modal"
          :model-value="activeReference.content || ''"
          class="ref-md"
        />
        <div class="ref-modal-footer">
          <a-button type="link" @click="viewDocument">
            <template #icon><FileTextOutlined /></template>
            查看文档
          </a-button>
        </div>
      </div>
    </a-modal>

    <!-- 执行轨迹抽屉（澄清 Q4：右侧宽幅，不新增路由） -->
    <TraceDrawer
      v-model:open="traceDrawerOpen"
      :chat-id="currentChat?.id || ''"
      :message="traceMessage"
    />
  </div>
</template>

<script setup>
import { computed, ref, watch, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import {
  MessageOutlined, UserOutlined, RobotOutlined, PlusOutlined,
  ApiOutlined, FileTextOutlined, LoadingOutlined, DatabaseOutlined, AlertOutlined, PartitionOutlined
} from '@ant-design/icons-vue'
import { MdPreview } from 'md-editor-v3'
import 'md-editor-v3/lib/preview.css'
import MessageInput from './MessageInput.vue'
import MessageContent from './MessageContent.vue'
import TraceDrawer from '../trace/TraceDrawer.vue'
import { formatChatDateTime } from '../../utils/chatDate.js'
import { AGENT_TYPE_LABELS } from '../../utils/agent.js'

const props = defineProps({
  currentChat: { type: Object, default: null },
  messages: { type: Array, default: () => [] },
  models: { type: Array, default: () => [] },
  prompts: { type: Array, default: () => [] },
  agents: { type: Array, default: () => [] },
  knowledgeBases: { type: Array, default: () => [] },
  stepProgress: { type: Object, default: null },
  isStreaming: { type: Boolean, default: false },
  isCancelling: { type: Boolean, default: false }
})

const emit = defineEmits(['send-message', 'create-chat', 'cancel', 'refresh-urls'])

const router = useRouter()
const messagesContainer = ref(null)
const messageInputRef = ref(null)
const followLatestMessage = ref(true)

const refModalVisible = ref(false)
const activeReference = ref(null)

const traceDrawerOpen = ref(false)
const traceMessage = ref(null)

function openTrace(msg) {
  traceMessage.value = msg
  traceDrawerOpen.value = true
}

// 存量旧模式会话：未绑定智能体且已有消息历史 → 只读
const isLegacyChat = computed(() =>
  !props.currentChat?.agent_id && props.messages.length > 0
)

const agentName = computed(() => {
  const agent = props.agents.find(a => a.id === props.currentChat?.agent_id)
  if (agent) return agent.name
  const typeLabel = AGENT_TYPE_LABELS[props.currentChat?.agent_type]
  return typeLabel || '智能体'
})

const STEP_LABELS = {
  history_retrieve: '历史信息检索',
  clarify: '问题澄清',
  rewrite: '问题重写',
  retrieve: '知识检索',
  rerank: '重排精筛',
  compress: '上下文压缩',
  sufficiency: '充足判断',
  plan_decision: '规划决策',
  tool: '工具调用',
  answer: '答案生成'
}

const stepText = computed(() => {
  const sp = props.stepProgress
  if (!sp) return ''
  const label = STEP_LABELS[sp.step] || sp.step
  const loopText = sp.loop ? `第 ${sp.loop} 轮 · ` : ''
  const toolText = sp.tool_name ? `（${sp.tool_name}）` : ''
  const statusText = sp.status === 'start' ? '进行中' : '完成'
  return sp.message || `${loopText}${label}${toolText} ${statusText}`
})

function scrollToLatestMessage() {
  nextTick(() => {
    if (followLatestMessage.value && messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

function handleMessagesScroll() {
  const container = messagesContainer.value
  if (container) {
    followLatestMessage.value = container.scrollHeight - container.scrollTop - container.clientHeight <= 32
  }
}

watch(
  () => props.currentChat?.id,
  () => {
    followLatestMessage.value = true
    scrollToLatestMessage()
  }
)

watch(
  () => [props.messages.length, props.messages[props.messages.length - 1]?.content],
  scrollToLatestMessage
)

const currentModelName = computed(() => {
  if (props.currentChat?.model_name) return props.currentChat.model_name
  const found = props.models.find(m => m.id === props.currentChat?.model_id)
  return found ? (found.display_name || found.name) : null
})

function getPromptName(promptId) {
  const found = props.prompts.find(p => p.id === promptId)
  return found ? found.name : promptId
}

function handleSend(data) {
  followLatestMessage.value = true
  emit('send-message', data)
}

function openReference(refItem) {
  activeReference.value = refItem
  refModalVisible.value = true
}

function viewDocument() {
  const refItem = activeReference.value
  if (!refItem?.kb_id || !refItem?.document_id) return
  refModalVisible.value = false
  router.push(`/knowledge/${refItem.kb_id}?docId=${refItem.document_id}`)
}

// 图片预签名过期 → 重签（每消息节流，避免多图并发重复请求）
const refreshingMessages = new Set()
function handleImageError(msg) {
  if (!msg?.id || String(msg.id).startsWith('streaming-') || refreshingMessages.has(msg.id)) return
  refreshingMessages.add(msg.id)
  emit('refresh-urls', msg)
  setTimeout(() => refreshingMessages.delete(msg.id), 5000)
}
</script>

<style scoped>
.chat-area-container { height: 100%; min-height: 0; display: flex; flex-direction: column; background: #fff; }
.empty-state { flex: 1; display: flex; align-items: center; justify-content: center; }
.empty-icon { width: 80px; height: 80px; background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto; font-size: 36px; color: #fff; }
.chat-content { flex: 1; min-height: 0; display: flex; flex-direction: column; overflow: hidden; }
.chat-header { flex-shrink: 0; padding: 16px 24px; border-bottom: 1px solid #f0f0f0; background: #fafafa; display: flex; justify-content: space-between; align-items: center; }
.chat-header-title { font-size: 16px; font-weight: 600; color: #1f1f1f; }
.chat-header-info { display: flex; gap: 8px; }
.messages-container { flex: 1; min-height: 0; overflow-y: auto; padding: 24px; }
.chat-content :deep(.message-input-container) { flex-shrink: 0; }
.messages-empty { height: 100%; display: flex; align-items: center; justify-content: center; }
.welcome-message { text-align: center; }
.welcome-icon { width: 64px; height: 64px; background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 28px; color: #fff; }
.welcome-message h3 { font-size: 20px; font-weight: 600; color: #1f1f1f; margin: 0 0 8px 0; }
.welcome-message p { font-size: 14px; color: #8c8c8c; margin: 0; }
.message-item { display: flex; margin-bottom: 24px; }
.message-item.user { flex-direction: row-reverse; }
.message-avatar { margin: 0 12px; flex-shrink: 0; }
.message-content { max-width: 70%; min-width: 0; }
.message-header { font-size: 12px; color: #8c8c8c; margin-bottom: 4px; }
.message-time { margin-left: 8px; }
.trace-btn { padding: 0 4px; font-size: 12px; height: auto; margin-left: 4px; }
.message-text { padding: 12px 16px; border-radius: 12px; font-size: 14px; line-height: 1.6; word-wrap: break-word; }
.message-item.user .message-header { text-align: right; }
.message-item.user .message-text { background: #1890ff; color: #fff; border-top-right-radius: 4px; white-space: pre-wrap; }
.message-item.assistant .message-text { background: #f5f5f5; color: #1f1f1f; border-top-left-radius: 4px; }
.message-text.typing { display: flex; gap: 4px; padding: 16px; }
.message-text.typing span { width: 8px; height: 8px; background: #8c8c8c; border-radius: 50%; animation: typing 1.4s infinite ease-in-out; }
.message-text.typing span:nth-child(1) { animation-delay: 0s; }
.message-text.typing span:nth-child(2) { animation-delay: 0.2s; }
.message-text.typing span:nth-child(3) { animation-delay: 0.4s; }
@keyframes typing { 0%, 60%, 100% { transform: translateY(0); } 30% { transform: translateY(-10px); } }
.step-progress { flex-shrink: 0; padding: 8px 16px; border-top: 1px solid #f0f0f0; background: #f6ffed; color: #389e0d; font-size: 13px; display: flex; align-items: center; }
.legacy-readonly { flex-shrink: 0; padding: 14px 16px; border-top: 1px solid #f0f0f0; background: #fafafa; color: #8c8c8c; font-size: 13px; text-align: center; }
.ref-modal-body { max-height: 60vh; overflow: auto; }
.ref-md :deep(.md-editor-preview-wrapper) { padding: 0; }
.ref-md :deep(.md-editor-preview img) { max-width: 100%; }
.ref-modal-footer { display: flex; justify-content: flex-end; border-top: 1px solid #f0f0f0; margin-top: 12px; padding-top: 8px; }
</style>