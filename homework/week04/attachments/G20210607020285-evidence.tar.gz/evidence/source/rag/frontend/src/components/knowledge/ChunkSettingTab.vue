<template>
  <div class="chunk-setting-tab">
    <!-- 分块策略 -->
    <a-form-item label="分块策略">
      <a-select v-model:value="formState.strategy" style="width: 100%">
        <a-select-option value="heading">按标题切分</a-select-option>
        <a-select-option value="fixed">按固定长度切分</a-select-option>
      </a-select>
    </a-form-item>

    <!-- 分块大小 -->
    <a-form-item>
      <template #label>
        <span>分块大小</span>
      </template>
      <a-input-number
        v-model:value="formState.chunkSize"
        :min="100"
        :max="4000"
        style="width: 100%"
      />
      <div class="field-description">
        每个分块的最大字符数（100-4000）。默认 512 ≈ 中文 300 tokens / 英文 100-130 tokens。FAQ 用 200-400，叙述性长文档用 1000-2000。
      </div>
    </a-form-item>

    <!-- 分块重叠 -->
    <a-form-item>
      <template #label>
        <span>分块重叠</span>
      </template>
      <a-input-number
        v-model:value="formState.chunkOverlap"
        :min="0"
        :max="500"
        style="width: 100%"
      />
      <div class="field-description">
        相邻分块之间共享的字符数（0-500）。默认 80 ≈ 分块大小的 15%，符合当前研究推荐。FAQ/结构化数据用 0，长篇叙述用 150-200。
      </div>
    </a-form-item>

    <!-- 分隔符 -->
    <a-form-item>
      <template #label>
        <span>分隔符</span>
      </template>
      <a-select
        v-model:value="formState.separators"
        mode="multiple"
        style="width: 100%"
        placeholder="选择启用的分隔符"
      >
        <a-select-option
          v-for="sep in allSeparators"
          :key="sep.value"
          :value="sep.value"
        >
          {{ sep.label }}
        </a-select-option>
      </a-select>
      <div class="field-description">
        切分时优先使用的字符或字符串。优先级高的分隔符先尝试；默认顺序优先段落 → 句子 → 标点。
      </div>
    </a-form-item>
  </div>
</template>

<script setup>
import { reactive, watch } from 'vue'

const allSeparators = [
  { value: '\n\n', label: '双换行 \\n\\n' },
  { value: '\n', label: '单换行 \\n' },
  { value: '。', label: '中文句号 。' },
  { value: '；', label: '中文分号 ；' },
  { value: '？', label: '中文问号 ？' },
  { value: '！', label: '中文感叹号 ！' },
  { value: '.', label: '英文句号 .' },
  { value: ';', label: '英文分号 ;' },
  { value: '?', label: '英文问号 ?' },
  { value: '!', label: '英文感叹号 !' },
]

const defaultSeparators = allSeparators.map((s) => s.value)

const formState = reactive({
  strategy: 'heading',
  chunkSize: 512,
  chunkOverlap: 80,
  separators: [...defaultSeparators],
})

const emit = defineEmits(['update:config'])

watch(
  formState,
  (val) => {
    emit('update:config', { ...val })
  },
  { deep: true, immediate: true }
)

defineExpose({
  getConfig: () => ({ ...formState }),
  reset: () => {
    formState.strategy = 'heading'
    formState.chunkSize = 512
    formState.chunkOverlap = 80
    formState.separators = [...defaultSeparators]
  },
})
</script>

<style scoped>
.chunk-setting-tab {
  padding: 8px 0;
}
.field-description {
  font-size: 12px;
  color: #8c8c8c;
  margin-top: 4px;
  line-height: 1.5;
}
</style>
