/**
 * Build a-tree treeData from flat folder list.
 * @param {Array} folders - Flat array of folder objects (camelCase)
 * @param {string} kbId - Knowledge base ID to filter
 * @returns {Array} treeData for a-tree component
 */
export function buildTree(folders, kbId) {
  const kbFolders = folders
    .filter((f) => f.kbId === kbId)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))

  const map = new Map()
  const roots = []

  // First pass: create map entries
  for (const f of kbFolders) {
    map.set(f.id, {
      key: f.id,
      title: f.name,
      children: [],
      raw: f
    })
  }

  // Second pass: build tree
  for (const f of kbFolders) {
    const node = map.get(f.id)
    if (f.parentId && map.has(f.parentId)) {
      map.get(f.parentId).children.push(node)
    } else {
      roots.push(node)
    }
  }

  // Clean up empty children arrays for leaf nodes
  function cleanEmpty(node) {
    if (node.children.length === 0) {
      delete node.children
    } else {
      node.children.forEach(cleanEmpty)
    }
    return node
  }

  return roots.map(cleanEmpty)
}

/**
 * Check if targetId is a descendant of ancestorId.
 * @param {Array} folders - Flat folder list (camelCase)
 * @param {string} ancestorId - Potential ancestor folder ID
 * @param {string} targetId - Potential descendant folder ID
 * @returns {boolean}
 */
export function isDescendant(folders, ancestorId, targetId) {
  if (ancestorId === targetId) return true
  const children = folders.filter((f) => f.parentId === ancestorId)
  for (const child of children) {
    if (child.id === targetId) return true
    if (isDescendant(folders, child.id, targetId)) return true
  }
  return false
}
