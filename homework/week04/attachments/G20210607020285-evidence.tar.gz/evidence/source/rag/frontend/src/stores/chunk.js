import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as chunkApi from '../services/chunkApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

export const useChunkStore = defineStore('chunk', () => {
  const chunks = ref([])
  const total = ref(0)
  const loading = ref(false)
  const currentChildren = ref([])
  const childrenLoading = ref(false)

  async function fetchChunks(docId, params = {}) {
    loading.value = true
    try {
      const data = await chunkApi.getDocumentChunks(docId, params)
      chunks.value = data.items || []
      total.value = data.total || 0
    } catch (error) {
      console.error('Failed to fetch chunks:', error)
      chunks.value = []
      total.value = 0
    } finally {
      loading.value = false
    }
  }

  async function fetchChunkChildren(chunkId, kbId) {
    childrenLoading.value = true
    currentChildren.value = []
    try {
      const data = await chunkApi.getChunkChildren(chunkId, kbId)
      currentChildren.value = data.items || []
    } catch (error) {
      console.error('Failed to fetch chunk children:', error)
      currentChildren.value = []
    } finally {
      childrenLoading.value = false
    }
  }

  async function fetchTableData(chunkId, kbId, sql = null, limit = 100) {
    try {
      return await chunkApi.getChunkTableData(chunkId, kbId, sql, limit)
    } catch (error) {
      console.error('Failed to fetch table data:', error)
      return null
    }
  }

  function clearChunks() {
    chunks.value = []
    total.value = 0
    currentChildren.value = []
  }

  return {
    chunks,
    total,
    loading,
    currentChildren,
    childrenLoading,
    fetchChunks,
    fetchChunkChildren,
    fetchTableData,
    clearChunks,
  }
})
