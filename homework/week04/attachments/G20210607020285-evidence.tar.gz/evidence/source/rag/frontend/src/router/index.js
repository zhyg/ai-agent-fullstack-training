import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '../stores/user.js'
import { message } from 'ant-design-vue'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('../views/Register.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/',
    component: () => import('../components/layout/AppLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        redirect: '/prompts'
      },
      {
        path: 'prompts',
        name: 'PromptManagement',
        component: () => import('../views/PromptManagement.vue')
      },
      {
        path: 'models',
        name: 'ModelManagement',
        component: () => import('../views/ModelManagement.vue'),
        meta: { requiresAdmin: true }
      },
      {
        path: 'chat',
        name: 'ChatManagement',
        component: () => import('../views/ChatManagement.vue')
      },
      {
        path: 'knowledge',
        name: 'KnowledgeBaseManagement',
        component: () => import('../views/KnowledgeBaseManagement.vue')
      },
      {
        path: 'knowledge/:kbId',
        name: 'KnowledgeManagement',
        component: () => import('../views/KnowledgeManagement.vue')
      },
      {
        path: 'agent',
        name: 'AgentManagement',
        component: () => import('../views/AgentManagement.vue')
      },
      {
        path: 'evaluation',
        name: 'EvaluationManagement',
        component: () => import('../views/EvaluationManagement.vue')
      },
      {
        path: 'monitor',
        name: 'ResourceMonitor',
        component: () => import('../views/ResourceMonitor.vue')
      },
      {
        path: 'permissions',
        name: 'PermissionManagement',
        component: () => import('../views/PermissionManagement.vue'),
        meta: { requiresAdmin: true }
      },
      {
        path: 'api-keys',
        name: 'ApiKeyManagement',
        component: () => import('../views/ApiKeyManagement.vue')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Navigation guard
router.beforeEach(async (to, from, next) => {
  const userStore = useUserStore()

  // If route requires auth and user is not authenticated
  if (to.meta.requiresAuth !== false && !userStore.isAuthenticated) {
    return next('/login')
  }

  // If going to login/register while already authenticated
  if ((to.path === '/login' || to.path === '/register') && userStore.isAuthenticated) {
    return next('/')
  }

  // Ensure user info is loaded before checking admin routes
  if (userStore.isAuthenticated && !userStore.currentUser) {
    try {
      await userStore.fetchCurrentUser()
    } catch {
      return next('/login')
    }
  }

  // RBAC: redirect non-admin users from admin-only pages
  if (to.meta.requiresAdmin && !userStore.isAdmin) {
    message.warning('您没有权限访问该页面')
    return next('/')
  }

  next()
})

export default router
