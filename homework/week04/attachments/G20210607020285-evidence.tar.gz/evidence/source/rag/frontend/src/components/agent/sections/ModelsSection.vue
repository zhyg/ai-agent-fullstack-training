<template>
  <div>
    <a-alert
      v-if="!loading && models.length === 0"
      type="warning"
      show-icon
      message="暂无可用模型，请先前往模型管理配置"
      style="margin-bottom: 16px"
    />
    <a-form layout="vertical">
      <a-form-item required>
        <template #label>
          分析模型
          <a-tag v-if="isInvalid('analysis_model_id')" color="red">已失效</a-tag>
        </template>
        <a-select
          v-model:value="draft.config.models.analysis_model_id"
          placeholder="请选择分析模型"
          allow-clear
          show-search
          option-filter-prop="label"
          :loading="loading"
          :options="optionsByCategory('chat')"
          style="width: 100%; max-width: 480px"
        />
      </a-form-item>
      <a-form-item :required="needEmbedding">
        <template #label>
          向量模型
          <a-tag v-if="isInvalid('embedding_model_id')" color="red">已失效</a-tag>
        </template>
        <a-select
          v-model:value="draft.config.models.embedding_model_id"
          placeholder="请选择向量模型"
          allow-clear
          show-search
          option-filter-prop="label"
          :loading="loading"
          :options="optionsByCategory('embedding')"
          style="width: 100%; max-width: 480px"
        />
        <span class="field-hint">{{ isPlanning ? '规划推理智能体必填' : '检索方式为向量/混合时必填' }}</span>
      </a-form-item>
      <a-form-item required>
        <template #label>
          ReRank 模型
          <a-tag v-if="isInvalid('rerank_model_id')" color="red">已失效</a-tag>
        </template>
        <a-select
          v-model:value="draft.config.models.rerank_model_id"
          placeholder="请选择 ReRank 模型"
          allow-clear
          show-search
          option-filter-prop="label"
          :loading="loading"
          :options="optionsByCategory('rerank')"
          style="width: 100%; max-width: 480px"
        />
      </a-form-item>
      <a-form-item label="max_output_tokens" required>
        <a-input-number
          v-model:value="draft.config.models.max_output_tokens"
          :min="1"
          :max="50000"
          :precision="0"
          style="width: 240px"
        />
        <span class="field-hint">范围 1–50000，默认 5000</span>
      </a-form-item>
    </a-form>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { getModelCategory } from '../../../utils/model.js'

const props = defineProps({
  draft: { type: Object, required: true },
  agentType: { type: String, required: true },
  models: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false }
})

const isPlanning = computed(() => props.agentType === 'planning_reasoning')

// 规划推理无检索方式，向量模型恒必填；其余类型按检索方式条件必填
const needEmbedding = computed(() =>
  isPlanning.value || ['vector', 'hybrid'].includes(props.draft.config.retrieval.mode)
)

function optionsByCategory(category) {
  return props.models
    .filter((m) => getModelCategory(m) === category)
    .map((m) => ({ value: m.id, label: m.display_name || m.name }))
}

function isInvalid(field) {
  const id = props.draft.config.models[field]
  return !!id && !props.loading && !props.models.some((m) => m.id === id)
}
</script>

<style scoped>
.field-hint {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}
</style>