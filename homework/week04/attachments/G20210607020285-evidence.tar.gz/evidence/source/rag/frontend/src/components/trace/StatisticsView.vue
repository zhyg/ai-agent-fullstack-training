<template>
  <div class="statistics-view">
    <a-descriptions size="small" :column="3" style="margin-bottom: 16px">
      <a-descriptions-item label="Span 总数">{{ spans.length }}</a-descriptions-item>
      <a-descriptions-item label="轨迹总耗时">{{ formatDuration(traceDuration) }}</a-descriptions-item>
      <a-descriptions-item label="服务">{{ serviceNames }}</a-descriptions-item>
    </a-descriptions>

    <!-- 各步骤（operationName）耗时占比 -->
    <a-table
      :columns="columns"
      :data-source="stats"
      :pagination="false"
      size="middle"
      row-key="operation"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'percentage'">
          <a-progress
            :percent="Number(record.percentage)"
            :show-info="false"
            :stroke-color="'#165dff'"
            size="small"
            style="display: inline-flex; width: 120px; margin-right: 8px"
          />
          <span>{{ record.percentage }}%</span>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { formatDuration } from './traceUtils.js'

const props = defineProps({
  spans: { type: Array, required: true }
})

const columns = [
  { title: '步骤', dataIndex: 'operation', key: 'operation' },
  { title: 'Spans', dataIndex: 'spanCount', key: 'spanCount', width: 80 },
  { title: '总耗时', dataIndex: 'totalDurationText', key: 'duration', width: 150 },
  { title: '占比', dataIndex: 'percentage', key: 'percentage', width: 200 }
]

const traceDuration = computed(() => {
  if (!props.spans.length) return 0
  const start = Math.min(...props.spans.map(s => s.startTime))
  const end = Math.max(...props.spans.map(s => s.startTime + s.duration))
  return end - start
})

const serviceNames = computed(() =>
  [...new Set(props.spans.map(s => s.serviceName))].join(', ') || '-'
)

const stats = computed(() => {
  const map = new Map()
  for (const span of props.spans) {
    const stat = map.get(span.operationName) || { count: 0, totalDuration: 0 }
    stat.count++
    stat.totalDuration += span.duration
    map.set(span.operationName, stat)
  }
  const total = Array.from(map.values()).reduce((a, b) => a + b.totalDuration, 0)
  return Array.from(map.entries())
    .map(([operation, stat]) => ({
      operation,
      spanCount: stat.count,
      totalDuration: stat.totalDuration,
      totalDurationText: formatDuration(stat.totalDuration),
      percentage: total > 0 ? ((stat.totalDuration / total) * 100).toFixed(1) : '0'
    }))
    .sort((a, b) => b.totalDuration - a.totalDuration)
})
</script>

<style scoped>
.statistics-view { padding: 24px; }
</style>