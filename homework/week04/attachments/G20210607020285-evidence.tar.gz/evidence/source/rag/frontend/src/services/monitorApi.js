import axios from 'axios'

// 资源消耗监控 API（015-resource-consumption-monitor，契约 contracts/consumption-api.md §4）：
// 沿用 evaluationApi.js 的 axios 实例 + Bearer 拦截器 + 401 清 token 跳登录模式
const api = axios.create({
  baseURL: `${import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'}/consumption`,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

function detailOf(error, fallback) {
  const detail = error.response?.data?.detail
  return new Error(detail || fallback)
}

// 筛选选项（决策7）：每次进页拉取一次
export async function getMonitorOptions() {
  try {
    const res = await api.get('/options')
    return res.data // { user_emails, models, is_admin }
  } catch (error) {
    throw detailOf(error, '加载筛选选项失败，请稍后重试')
  }
}

// 消耗序列查询：params = { metric, scope, user_email?, models?, month?, year? }
export async function getConsumptionSeries(params) {
  try {
    const res = await api.get('/series', { params })
    return res.data // { metric, scope, buckets, series, out_of_retention }
  } catch (error) {
    throw detailOf(error, '查询消耗数据失败，请稍后重试')
  }
}