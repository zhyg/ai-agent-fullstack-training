// 智能体共享常量（与 KnowledgeManage/app/schemas/agent.py 保持同步）
import {
  ThunderboltOutlined,
  BulbOutlined,
  PartitionOutlined,
  RobotOutlined,
  MessageOutlined,
  SearchOutlined,
  ExperimentOutlined,
  CompassOutlined,
  RocketOutlined,
  ApiOutlined
} from '@ant-design/icons-vue'

// 智能体类型
export const AGENT_TYPE_LABELS = {
  quick_qa: '快速问答',
  reasoning_action: '推理行动',
  planning_reasoning: '规划推理'
}

// 内置图标库（FR-006：仅可从中选择，不支持上传）
export const AGENT_ICONS = [
  { key: 'thunderbolt', label: '闪电', component: ThunderboltOutlined },
  { key: 'bulb', label: '灯泡', component: BulbOutlined },
  { key: 'partition', label: '分支', component: PartitionOutlined },
  { key: 'robot', label: '机器人', component: RobotOutlined },
  { key: 'message', label: '消息', component: MessageOutlined },
  { key: 'search', label: '搜索', component: SearchOutlined },
  { key: 'experiment', label: '实验', component: ExperimentOutlined },
  { key: 'compass', label: '罗盘', component: CompassOutlined },
  { key: 'rocket', label: '火箭', component: RocketOutlined },
  { key: 'api', label: '接口', component: ApiOutlined }
]

export function getIconComponent(key) {
  return AGENT_ICONS.find((i) => i.key === key)?.component || RobotOutlined
}

// 提示词用途（FR-007）
export const PROMPT_PURPOSE_LABELS = {
  clarify: '问题澄清',
  rewrite: '问题重写',
  answer: '答案生成',
  compress: '上下文压缩',
  sufficiency: '资源充足判断',
  planning: '规划分析'
}

export const PROMPT_PURPOSES_BY_TYPE = {
  quick_qa: ['clarify', 'rewrite', 'answer', 'compress'],
  reasoning_action: ['clarify', 'rewrite', 'answer', 'compress', 'sufficiency'],
  planning_reasoning: ['clarify', 'rewrite', 'answer', 'compress', 'planning']
}

// 恒必填用途；规划推理的 rewrite/compress 随对应工具勾选联动
export const REQUIRED_PROMPT_PURPOSES_BY_TYPE = {
  quick_qa: ['clarify', 'rewrite', 'answer', 'compress'],
  reasoning_action: ['clarify', 'rewrite', 'answer', 'compress', 'sufficiency'],
  planning_reasoning: ['clarify', 'answer', 'planning']
}

// 工具 → 提示词用途联动映射（取消勾选该工具时对应用途转可选）
export const TOOL_TO_PROMPT_PURPOSE = {
  rewriteQuestion: 'rewrite',
  zip: 'compress'
}

export function getRequiredPromptPurposes(type, tools) {
  const base = new Set(REQUIRED_PROMPT_PURPOSES_BY_TYPE[type] || [])
  if (type === 'planning_reasoning') {
    const enabled = new Set(tools || TOOL_KEYS)
    Object.entries(TOOL_TO_PROMPT_PURPOSE).forEach(([tool, purpose]) => {
      if (enabled.has(tool)) base.add(purpose)
    })
  }
  return [...base]
}

// 规划推理 13 个工具（FR-011）
export const AGENT_TOOLS = [
  { key: 'createPlan', label: '制定规划' },
  { key: 'listPlan', label: '获取所有规划' },
  { key: 'getPlan', label: '获取某个规划' },
  { key: 'updatePlan', label: '更新规划' },
  { key: 'deletePlan', label: '删除规划' },
  { key: 'rewriteQuestion', label: '问题重写' },
  { key: 'bm25Search', label: '关键词检索' },
  { key: 'vectorSearch', label: '向量检索' },
  { key: 'hybridSearch', label: '混合检索' },
  { key: 'rerank', label: '重排' },
  { key: 'zip', label: '压缩' },
  { key: 'listTableMetaData', label: '获取表格元数据' },
  { key: 'sqlExecute', label: 'SQL执行' }
]

export const TOOL_KEYS = AGENT_TOOLS.map((t) => t.key)

// 检索方式（FR-008）
export const RETRIEVAL_MODES = [
  { value: 'vector', label: '向量检索', topKField: 'vector_top_k', topKLabel: '向量召回数量' },
  { value: 'keyword', label: '关键词检索', topKField: 'keyword_top_k', topKLabel: '关键词召回数量' },
  { value: 'hybrid', label: '混合检索', topKField: 'hybrid_top_k', topKLabel: '混合检索召回数量' }
]

// 编辑弹窗左侧菜单（FR-005：按类型 5/6/7 项；013 新增历史信息检索）
export const MENU_SECTIONS = {
  basic: '基础信息',
  prompts: '提示词',
  retrieval: '检索策略',
  history: '历史信息检索',
  models: '模型配置',
  loop: '循环次数',
  tools: '工具配置'
}

export const MENU_SECTIONS_BY_TYPE = {
  quick_qa: ['basic', 'prompts', 'retrieval', 'history', 'models'],
  reasoning_action: ['basic', 'prompts', 'retrieval', 'history', 'models', 'loop'],
  planning_reasoning: ['basic', 'prompts', 'retrieval', 'history', 'models', 'loop', 'tools']
}

// 保存前统一校验草稿，返回 [{section, message}]（空数组＝通过）
// prompts/models 为全量引用列表，用于检测已失效引用
export function validateAgentDraft(type, draft, prompts, models) {
  const errors = []
  const config = draft.config
  const name = (draft.name || '').trim()
  if (!name || name.length > 100) {
    errors.push({ section: 'basic', message: '名称必填，长度 1–100 字符' })
  }

  const promptIds = new Set(prompts.map((p) => p.id))
  const required = getRequiredPromptPurposes(type, config.tools)
  for (const purpose of required) {
    const id = config.prompts?.[purpose]
    const label = PROMPT_PURPOSE_LABELS[purpose]
    if (!id) {
      errors.push({ section: 'prompts', message: `提示词「${label}」为必填项` })
    } else if (!promptIds.has(id)) {
      errors.push({ section: 'prompts', message: `提示词「${label}」引用已失效，请重新选择` })
    }
  }

  const inRange = (v, min, max) => Number.isInteger(v) && v >= min && v <= max
  if (type === 'planning_reasoning') {
    // 规划推理无检索方式，三个召回数量均需校验
    for (const m of RETRIEVAL_MODES) {
      if (!inRange(config.retrieval?.[m.topKField], 1, 100)) {
        errors.push({ section: 'retrieval', message: `${m.topKLabel}须为 1–100 的整数` })
      }
    }
  } else {
    const mode = RETRIEVAL_MODES.find((m) => m.value === config.retrieval?.mode)
    if (mode) {
      const topK = config.retrieval[mode.topKField]
      if (!inRange(topK, 1, 100)) {
        errors.push({ section: 'retrieval', message: `${mode.topKLabel}须为 1–100 的整数` })
      }
    }
  }
  if (!inRange(config.retrieval?.rerank_top_n, 1, 100)) {
    errors.push({ section: 'retrieval', message: '重排数量须为 1–100 的整数' })
  }

  // 历史信息检索（013 决策8）：仅检索召回数，模式恒混合不可选
  if (!inRange(config.history_retrieval?.top_k, 1, 100)) {
    errors.push({ section: 'history', message: '检索召回数须为 1–100 的整数' })
  }

  const modelIds = new Set(models.map((m) => m.id))
  const checkModel = (id, label, isRequired) => {
    if (!id) {
      if (isRequired) errors.push({ section: 'models', message: `${label}为必填项` })
    } else if (!modelIds.has(id)) {
      errors.push({ section: 'models', message: `${label}引用已失效，请重新选择` })
    }
  }
  checkModel(config.models?.analysis_model_id, '分析模型', true)
  checkModel(config.models?.rerank_model_id, 'ReRank 模型', true)
  // 规划推理无检索方式，向量模型恒必填；其余类型按检索方式条件必填
  const needEmbedding = type === 'planning_reasoning' || ['vector', 'hybrid'].includes(config.retrieval?.mode)
  checkModel(config.models?.embedding_model_id, '向量模型', needEmbedding)
  if (!inRange(config.models?.max_output_tokens, 1, 50000)) {
    errors.push({ section: 'models', message: 'max_output_tokens 须为 1–50000 的整数' })
  }
  // FR-020：max_output_tokens < 分析模型上下文窗口（与后端保存校验对应）
  const analysisModel = models.find((m) => m.id === config.models?.analysis_model_id)
  const contextTokens = analysisModel?.context_tokens
  if (analysisModel && contextTokens && inRange(config.models?.max_output_tokens, 1, 50000)
    && config.models.max_output_tokens >= contextTokens) {
    errors.push({
      section: 'models',
      message: `最大输出 Token 数（${config.models.max_output_tokens}）必须小于分析模型上下文窗口（${contextTokens}）`
    })
  }

  if (type !== 'quick_qa' && !inRange(config.loop_count, 1, 1000)) {
    errors.push({ section: 'loop', message: '循环次数须为 1–1000 的整数' })
  }
  return errors
}

// 各类型默认配置（与 Alembic 预置数据一致）
export function getDefaultConfig(type) {
  const prompts = {}
  PROMPT_PURPOSES_BY_TYPE[type].forEach((p) => { prompts[p] = null })
  const config = {
    prompts,
    retrieval: { mode: 'vector', vector_top_k: 20, keyword_top_k: 20, hybrid_top_k: 20, rerank_top_n: 15 },
    history_retrieval: { top_k: 10 },
    models: { analysis_model_id: null, max_output_tokens: 5000, embedding_model_id: null, rerank_model_id: null }
  }
  if (type === 'reasoning_action') config.loop_count = 10
  if (type === 'planning_reasoning') {
    config.loop_count = 100
    config.tools = [...TOOL_KEYS]
  }
  return config
}