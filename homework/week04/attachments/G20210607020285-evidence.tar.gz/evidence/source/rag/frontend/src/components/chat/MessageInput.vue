<template>
  <div class="message-input-container">
    <div class="input-toolbar">
      <div class="toolbar-left">
        <a-select
          v-model:value="selectedKbIds"
          mode="multiple"
          placeholder="选择知识库（必选）"
          style="min-width: 240px; max-width: 420px;"
          :max-tag-count="2"
          allowClear
        >
          <a-select-option v-for="kb in knowledgeBases" :key="kb.id" :value="kb.id">
            <div style="display: flex; align-items: center;">
              <DatabaseOutlined style="margin-right: 8px; color: #1890ff;" />
              {{ kb.name }}
            </div>
          </a-select-option>
        </a-select>
        <a-select
          v-model:value="selectedAgentId"
          placeholder="选择智能体"
          style="width: 200px; margin-left: 8px;"
        >
          <a-select-option
            v-for="agent in agents"
            :key="agent.id"
            :value="agent.id"
            :disabled="agent.status !== 'enabled' || agent.config_complete === false"
            :title="agentOptionTip(agent)"
          >
            <div style="display: flex; align-items: center;">
              <component :is="getIconComponent(agent.icon)" style="margin-right: 8px; color: #722ed1;" />
              {{ agent.name }}
              <span v-if="agent.status !== 'enabled'" class="agent-disabled-tag">已停用</span>
              <span v-else-if="agent.config_complete === false" class="agent-disabled-tag">配置未完成</span>
            </div>
          </a-select-option>
        </a-select>
      </div>
    </div>
    <div class="input-area">
      <a-textarea
        v-model:value="inputMessage"
        :placeholder="placeholder"
        :auto-size="{ minRows: 3, maxRows: 6 }"
        :maxlength="2000"
        @pressEnter="handleSend"
      />
      <a-button
        v-if="isStreaming"
        danger
        :loading="isCancelling"
        :disabled="isCancelling"
        @click="$emit('cancel')"
        class="send-btn"
      >
        <template #icon><StopOutlined /></template>
        停止
      </a-button>
      <a-tooltip v-else :title="sendDisabledTip">
        <a-button
          type="primary"
          :disabled="sendDisabled"
          @click="handleSend"
          class="send-btn"
        >
          <template #icon><SendOutlined /></template>
          发送
        </a-button>
      </a-tooltip>
    </div>
    <div v-if="sendDisabledTip" class="input-tip">
      <AlertOutlined style="margin-right: 4px;" />
      {{ sendDisabledTip }}
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { DatabaseOutlined, SendOutlined, StopOutlined, AlertOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { getIconComponent } from '../../utils/agent.js'

const props = defineProps({
  agents: { type: Array, default: () => [] },
  knowledgeBases: { type: Array, default: () => [] },
  currentAgentId: { type: String, default: null },
  currentKbIds: { type: Array, default: () => [] },
  isStreaming: { type: Boolean, default: false },
  isCancelling: { type: Boolean, default: false }
})

const emit = defineEmits(['send', 'cancel'])

const inputMessage = ref('')
const selectedAgentId = ref(props.currentAgentId || null)
const selectedKbIds = ref([...(props.currentKbIds || [])])

watch(() => props.currentAgentId, (val) => { selectedAgentId.value = val || null })
watch(() => props.currentKbIds, (val) => { selectedKbIds.value = [...(val || [])] })

function agentOptionTip(agent) {
  if (agent.status !== 'enabled') return '智能体已停用'
  if (agent.config_complete === false) {
    return `配置未完成：${(agent.incomplete_reasons || []).join('；')}`
  }
  return ''
}

const sendDisabledTip = computed(() => {
  if (!selectedKbIds.value.length) return '请先选择知识库'
  if (!selectedAgentId.value) return '请选择智能体'
  if (!inputMessage.value.trim()) return ''
  return ''
})

const sendDisabled = computed(() =>
  !inputMessage.value.trim() || !selectedKbIds.value.length || !selectedAgentId.value
)

const placeholder = computed(() => {
  if (!selectedKbIds.value.length) return '请先选择知识库...'
  if (!selectedAgentId.value) return '请选择智能体...'
  return '输入问题，按 Enter 发送...'
})

function handleSend(e) {
  if (e && e.shiftKey) return
  if (e) e.preventDefault()
  if (!inputMessage.value.trim()) { message.warning('请输入问题内容'); return }
  if (!selectedKbIds.value.length) { message.warning('请先选择知识库'); return }
  if (!selectedAgentId.value) { message.warning('请选择智能体'); return }

  emit('send', {
    content: inputMessage.value.trim(),
    agentId: selectedAgentId.value,
    knowledgeBaseIds: [...selectedKbIds.value]
  })
  inputMessage.value = ''
}
</script>

<style scoped>
.message-input-container { border-top: 1px solid #f0f0f0; background: #fff; padding: 16px; }
.input-toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.toolbar-left { display: flex; align-items: center; flex-wrap: wrap; gap: 4px 0; }
.input-area { position: relative; }
.input-area :deep(.ant-input) { resize: none; padding-right: 80px; border-radius: 8px; }
.send-btn { position: absolute; right: 8px; bottom: 8px; border-radius: 6px; }
.input-tip { margin-top: 8px; font-size: 12px; color: #faad14; display: flex; align-items: center; }
.agent-disabled-tag { color: #bfbfbf; font-size: 12px; margin-left: 8px; }
:deep(.ant-select-selector) { border-radius: 6px !important; }
:deep(.ant-select-selection-item) { display: flex; align-items: center; }
</style>