<template>
  <a-modal
    :open="!!agentStore.editingAgent"
    :title="modalTitle"
    :width="920"
    ok-text="保存"
    cancel-text="取消"
    :confirm-loading="saving"
    :mask-closable="false"
    destroy-on-close
    @ok="onSave"
    @cancel="onCancel"
  >
    <div v-if="agentStore.editDraft" class="edit-layout">
      <a-menu
        v-model:selectedKeys="selectedKeys"
        mode="inline"
        class="edit-menu"
        :items="menuItems"
      />
      <div class="edit-content">
        <BasicInfoSection v-show="activeSection === 'basic'" :draft="agentStore.editDraft" />
        <PromptsSection
          v-show="activeSection === 'prompts'"
          :draft="agentStore.editDraft"
          :agent-type="agentType"
          :prompts="allPrompts"
          :loading="refsLoading"
        />
        <RetrievalSection
          v-show="activeSection === 'retrieval'"
          :draft="agentStore.editDraft"
          :agent-type="agentType"
        />
        <HistorySection
          v-show="activeSection === 'history'"
          :draft="agentStore.editDraft"
        />
        <ModelsSection
          v-show="activeSection === 'models'"
          :draft="agentStore.editDraft"
          :agent-type="agentType"
          :models="allModels"
          :loading="refsLoading"
        />
        <LoopSection
          v-show="activeSection === 'loop'"
          :draft="agentStore.editDraft"
          :agent-type="agentType"
        />
        <ToolsSection v-show="activeSection === 'tools'" :draft="agentStore.editDraft" />
      </div>
    </div>
  </a-modal>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { message } from 'ant-design-vue'
import BasicInfoSection from './sections/BasicInfoSection.vue'
import PromptsSection from './sections/PromptsSection.vue'
import RetrievalSection from './sections/RetrievalSection.vue'
import HistorySection from './sections/HistorySection.vue'
import ModelsSection from './sections/ModelsSection.vue'
import LoopSection from './sections/LoopSection.vue'
import ToolsSection from './sections/ToolsSection.vue'
import { useAgentStore } from '../../stores/agent.js'
import * as promptApi from '../../services/promptApi.js'
import * as modelApi from '../../services/modelApi.js'
import { extractErrorMessage } from '../../utils/errorHandler.js'
import {
  AGENT_TYPE_LABELS,
  MENU_SECTIONS,
  MENU_SECTIONS_BY_TYPE,
  validateAgentDraft
} from '../../utils/agent.js'

const emit = defineEmits(['saved'])

const agentStore = useAgentStore()

const selectedKeys = ref(['basic'])
const activeSection = computed(() => selectedKeys.value[0] || 'basic')
const saving = ref(false)
const refsLoading = ref(false)
const allPrompts = ref([])
const allModels = ref([])

const agentType = computed(() => agentStore.editingAgent?.type || 'quick_qa')
const modalTitle = computed(() => `编辑智能体 · ${AGENT_TYPE_LABELS[agentType.value]}`)
const menuItems = computed(() =>
  (MENU_SECTIONS_BY_TYPE[agentType.value] || []).map((key) => ({ key, label: MENU_SECTIONS[key] }))
)

// 打开弹窗时重置菜单并全量加载提示词/模型引用（page_size=100 循环翻页至 total）
watch(
  () => agentStore.editingAgent,
  (agent) => {
    if (agent) {
      selectedKeys.value = ['basic']
      loadRefs()
    }
  }
)

async function fetchAll(listFn) {
  const items = []
  let page = 1
  for (;;) {
    const data = await listFn(page, 100)
    items.push(...data.items)
    if (items.length >= data.total || data.items.length === 0) break
    page += 1
  }
  return items
}

async function loadRefs() {
  refsLoading.value = true
  try {
    const [prompts, models] = await Promise.all([
      fetchAll(promptApi.listPrompts),
      fetchAll(modelApi.listModels)
    ])
    allPrompts.value = prompts
    allModels.value = models
  } catch (error) {
    message.error(extractErrorMessage(error))
  } finally {
    refsLoading.value = false
  }
}

async function onSave() {
  if (refsLoading.value) {
    message.warning('提示词/模型列表加载中，请稍候')
    return
  }
  // 保存前统一校验：必填、范围、失效引用；定位到首个错误所在配置区
  const errors = validateAgentDraft(agentType.value, agentStore.editDraft, allPrompts.value, allModels.value)
  if (errors.length > 0) {
    selectedKeys.value = [errors[0].section]
    message.error(errors[0].message)
    return
  }
  saving.value = true
  const result = await agentStore.saveEdit()
  saving.value = false
  if (result.success) {
    message.success(result.message)
    emit('saved')
  } else {
    message.error(result.message)
  }
}

function onCancel() {
  agentStore.closeEdit()
}
</script>

<style scoped>
.edit-layout {
  display: flex;
  gap: 16px;
  min-height: 420px;
}

.edit-menu {
  width: 150px;
  flex-shrink: 0;
  border-inline-end: 1px solid #f0f0f0;
}

.edit-content {
  flex: 1;
  padding: 4px 8px;
  overflow-y: auto;
  max-height: 60vh;
}
</style>