<template>
  <div class="evaluation-detail">
    <a-card size="small" class="detail-card">
      <template #title>
        <a-space :size="12">
          <a-button class="back-btn" @click="$emit('back')">
            <template #icon><ArrowLeftOutlined /></template>
            返回评测列表
          </a-button>
          <span class="detail-title">评测详情</span>
          <a-tag v-if="detail" :color="statusColor(detail.status)">{{ statusLabel(detail.status) }}</a-tag>
        </a-space>
      </template>
      <a-spin :spinning="loading">
        <template v-if="detail">
          <a-descriptions :column="3" size="small">
            <a-descriptions-item label="知识库">{{ (detail.knowledge_base_names || []).join('、') }}</a-descriptions-item>
            <a-descriptions-item label="智能体">{{ detail.agent_name }}</a-descriptions-item>
            <a-descriptions-item label="测试集">{{ detail.test_set_name }}</a-descriptions-item>
            <a-descriptions-item label="开始时间">{{ formatTime(detail.started_at) }}</a-descriptions-item>
            <a-descriptions-item label="结束时间">{{ formatTime(detail.finished_at) }}</a-descriptions-item>
            <a-descriptions-item label="完成进度">{{ detail.completed_items }} / {{ detail.total_items }}</a-descriptions-item>
            <a-descriptions-item label="平均召回率">{{ formatRecall(detail.avg_recall) }}</a-descriptions-item>
            <a-descriptions-item label="平均准确度">{{ formatAccuracy(detail.avg_accuracy) }}</a-descriptions-item>
          </a-descriptions>
          <a-alert
            v-if="detail.error_message"
            type="error"
            :message="detail.error_message"
            show-icon
            style="margin-top: 8px;"
          />
        </template>
      </a-spin>
    </a-card>

    <a-card v-if="detail" title="逐题结果" size="small" class="detail-card">
      <a-collapse v-if="detail.items.length">
        <a-collapse-panel v-for="item in detail.items" :key="item.id">
          <template #header>
            <a-space>
              <span>第 {{ item.seq }} 题</span>
              <a-tag :color="item.status === 'success' ? 'green' : item.status === 'failed' ? 'red' : 'default'">
                {{ itemStatusLabel(item.status) }}
              </a-tag>
              <span class="item-score">召回率 {{ formatRecall(item.recall) }}</span>
              <span class="item-score">准确度 {{ formatAccuracy(item.accuracy) }}</span>
            </a-space>
          </template>
          <template #extra>
            <!-- US4（T038）: trace_id 非空显示，点击打开 TraceDrawer -->
            <a-button
              v-if="item.trace_id"
              size="small"
              @click.stop="openTrace(item)"
            >查看 Trace</a-button>
          </template>

          <div class="field-block">
            <div class="field-label">问题</div>
            <div class="field-value">{{ item.question }}</div>
          </div>
          <div class="field-block">
            <div class="field-label">标准答案</div>
            <div class="field-value">{{ item.standard_answer }}</div>
          </div>
          <div class="field-block">
            <div class="field-label">Agent 答案</div>
            <div class="field-value">{{ item.agent_answer || '' }}</div>
          </div>

          <div class="field-block">
            <div class="field-label">检索上下文（{{ (item.context || []).length }} 条）</div>
            <div v-if="(item.context || []).length" class="context-list">
              <div v-for="(ref, i) in item.context" :key="i" class="context-item">
                <div class="context-head">
                  [{{ i + 1 }}] {{ ref.file_name }}
                  <span v-if="ref.score != null" class="context-score">得分 {{ ref.score }}</span>
                </div>
                <div class="context-content">{{ ref.content }}</div>
              </div>
            </div>
            <div v-else class="field-value empty">（无）</div>
          </div>

          <a-alert
            v-if="item.status === 'failed' && item.failure_reason"
            type="error"
            :message="item.failure_reason"
            show-icon
            style="margin-bottom: 12px;"
          />

          <a-row :gutter="16">
            <a-col :span="12">
              <div class="field-label">召回率分析</div>
              <pre v-if="item.recall_analysis" class="analysis-json">{{ formatJson(item.recall_analysis) }}</pre>
              <div v-else class="field-value empty">（无）</div>
            </a-col>
            <a-col :span="12">
              <div class="field-label">准确度分析</div>
              <pre v-if="item.accuracy_analysis" class="analysis-json">{{ formatJson(item.accuracy_analysis) }}</pre>
              <div v-else class="field-value empty">（无）</div>
            </a-col>
          </a-row>

          <a-collapse
            v-if="item.recall_raw_output || item.accuracy_raw_output"
            ghost
            style="margin-top: 8px;"
          >
            <a-collapse-panel key="raw" header="评分模型最后一次原始输出（校验失败排查用）">
              <div v-if="item.recall_raw_output" class="field-block">
                <div class="field-label">召回率评分原始输出</div>
                <pre class="analysis-json">{{ item.recall_raw_output }}</pre>
              </div>
              <div v-if="item.accuracy_raw_output" class="field-block">
                <div class="field-label">准确度评分原始输出</div>
                <pre class="analysis-json">{{ item.accuracy_raw_output }}</pre>
              </div>
            </a-collapse-panel>
          </a-collapse>
        </a-collapse-panel>
      </a-collapse>
      <a-empty v-else description="暂无题目明细" />
    </a-card>

    <TraceDrawer v-model:open="traceOpen" :fetcher="traceFetcher" />
  </div>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { message } from 'ant-design-vue'
import { ArrowLeftOutlined } from '@ant-design/icons-vue'
import { getRun } from '../../services/evaluationApi.js'
import { fetchEvaluationItemTrace } from '../../services/traceApi.js'
import TraceDrawer from '../trace/TraceDrawer.vue'

const props = defineProps({
  runId: { type: String, required: true }
})
defineEmits(['back'])

const detail = ref(null)
const loading = ref(false)

// US4（T038）：题目级 trace 抽屉（复用会话页 TraceDrawer，fetcher 注入 R11）
const traceOpen = ref(false)
const traceItem = ref(null)
// computed 保证函数身份仅随题目变化，避免抽屉 watch 重复加载
const traceFetcher = computed(() =>
  traceItem.value ? () => fetchEvaluationItemTrace(props.runId, traceItem.value.id) : null
)

const STATUS_LABELS = { running: '进行中', completed: '已完成', cancelled: '已取消', failed: '失败' }
const STATUS_COLORS = { running: 'blue', completed: 'green', cancelled: 'orange', failed: 'red' }
const ITEM_STATUS_LABELS = { success: '成功', failed: '失败', pending: '待执行' }

function statusLabel(s) { return STATUS_LABELS[s] || s }
function statusColor(s) { return STATUS_COLORS[s] || 'default' }
function itemStatusLabel(s) { return ITEM_STATUS_LABELS[s] || s }

// 契约 §3：recall 0–1 前端 ×100 百分比；accuracy 0–100；null 展示空
function formatRecall(v) { return v == null ? '' : `${(v * 100).toFixed(1)}%` }
function formatAccuracy(v) { return v == null ? '' : v.toFixed(1) }
function formatJson(v) { return v == null ? '' : JSON.stringify(v, null, 2) }
function formatTime(v) { return v ? new Date(v).toLocaleString() : '' }

function openTrace(item) {
  traceItem.value = item
  traceOpen.value = true
}

async function load() {
  loading.value = true
  detail.value = null
  try {
    detail.value = await getRun(props.runId)
  } catch (e) {
    message.error(e.message)
  } finally {
    loading.value = false
  }
}

watch(() => props.runId, load, { immediate: true })
</script>

<style scoped>
.evaluation-detail {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.detail-card :deep(.ant-card-head) {
  font-weight: 600;
}

/* 醒目返回按钮：蓝底胶囊 + 图标，hover 渐变实心，与评测页 Tab 视觉语言一致 */
.back-btn.back-btn {
  display: inline-flex;
  align-items: center;
  height: 34px;
  padding: 0 18px;
  border-radius: 17px;
  border: 1px solid #91caff;
  background: #e8f1ff;
  color: #1677ff;
  font-size: 14px;
  font-weight: 600;
  box-shadow: 0 2px 6px rgba(22, 119, 255, 0.15);
  transition: all 0.25s ease;
}

.back-btn.back-btn:hover,
.back-btn.back-btn:focus {
  border-color: transparent;
  background: linear-gradient(135deg, #1677ff 0%, #4096ff 100%);
  color: #fff;
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.35);
}

.back-btn.back-btn:active {
  transform: translateX(-2px);
}

.back-btn :deep(.anticon) {
  font-size: 15px;
}

.detail-title {
  font-size: 16px;
  color: #152038;
}

.item-score {
  color: #51607a;
  font-size: 12px;
}

.field-block {
  margin-bottom: 12px;
}

.field-label {
  font-weight: 600;
  color: #51607a;
  font-size: 13px;
  margin-bottom: 4px;
}

.field-value {
  white-space: pre-wrap;
  word-break: break-word;
}

.field-value.empty {
  color: #8190a8;
}

.context-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.context-item {
  background: #f7f9fc;
  border-radius: 6px;
  padding: 8px 12px;
}

.context-head {
  font-weight: 600;
  font-size: 13px;
}

.context-score {
  color: #8190a8;
  font-weight: 400;
  margin-left: 8px;
  font-size: 12px;
}

.context-content {
  margin-top: 4px;
  color: #51607a;
  font-size: 13px;
  white-space: pre-wrap;
  word-break: break-word;
}

.analysis-json {
  background: #f7f9fc;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 12px;
  max-height: 320px;
  overflow: auto;
  white-space: pre-wrap;
  word-break: break-word;
  margin: 0;
}
</style>