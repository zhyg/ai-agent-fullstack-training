import axios from 'axios'

// 轨迹查询代理 API（T045，FR-036）：复用 chatApi 的 JWT 拦截器模式，前端不直连 ES/Jaeger
const api = axios.create({
  baseURL: import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

/**
 * 查询消息执行轨迹。
 * 返回 {ready:false, reason:'pending'|'no_trace'} 或 {ready:true, data:[{traceID,spans,processes}]}；
 * 403/404/503 抛出含后端 detail 的错误，由调用方展示。
 */
export async function fetchMessageTrace(chatId, messageId) {
  try {
    const res = await api.get(`/chats/${chatId}/messages/${messageId}/trace`)
    return res.data
  } catch (error) {
    const detail = error.response?.data?.detail
    throw new Error(detail || '轨迹查询失败，请稍后重试')
  }
}

/**
 * 查询评测题目执行轨迹（014 US4，契约 §4）：按评测记录归属校验，不校验会话。
 * 返回结构与 fetchMessageTrace 一致，reason 额外支持 'expired'（>48h 超索引窗口）。
 */
export async function fetchEvaluationItemTrace(runId, itemId) {
  try {
    const res = await api.get(`/evaluations/runs/${runId}/items/${itemId}/trace`)
    return res.data
  } catch (error) {
    const detail = error.response?.data?.detail
    throw new Error(detail || '轨迹查询失败，请稍后重试')
  }
}