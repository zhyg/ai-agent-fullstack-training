<template>
  <div class="evaluation-management">
    <div class="page-header">
      <h2 class="page-title">知识库评测</h2>
      <p class="page-desc">配置分析模型与评分提示词、管理测试集，发起评测并查看每题得分与执行轨迹</p>
    </div>
    <a-tabs v-model:activeKey="activeTab" class="evaluation-tabs">
      <a-tab-pane key="settings">
        <template #tab>
          <span class="tab-label"><SettingOutlined />设置</span>
        </template>
        <EvaluationSettings />
      </a-tab-pane>
      <a-tab-pane key="evaluation">
        <template #tab>
          <span class="tab-label"><ExperimentOutlined />评测</span>
        </template>
        <EvaluationPanel />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { SettingOutlined, ExperimentOutlined } from '@ant-design/icons-vue'
import EvaluationSettings from '../components/evaluation/EvaluationSettings.vue'
import EvaluationPanel from '../components/evaluation/EvaluationPanel.vue'

const activeTab = ref('settings')
</script>

<style scoped>
.evaluation-management {
  padding: 8px 4px;
}

.page-header {
  margin-bottom: 12px;
}

.page-title {
  margin: 0;
  color: #152038;
  font-size: 20px;
  font-weight: 600;
}

.page-desc {
  margin: 4px 0 0;
  color: #8190a8;
  font-size: 13px;
}

.evaluation-tabs :deep(.ant-tabs-nav) {
  margin-bottom: 16px;
}

/* 去掉默认下划线式导航，改为分段式胶囊 Tab，提升辨识度 */
.evaluation-tabs :deep(.ant-tabs-nav::before) {
  border-bottom: none;
}

.evaluation-tabs :deep(.ant-tabs-ink-bar) {
  display: none;
}

.evaluation-tabs :deep(.ant-tabs-nav-list) {
  background: #e8edf6;
  border: 1px solid #d9e2f1;
  border-radius: 12px;
  padding: 4px;
  gap: 4px;
}

.evaluation-tabs :deep(.ant-tabs-tab) {
  margin: 0 !important;
  padding: 9px 32px;
  border-radius: 9px;
  background: transparent;
  transition: background 0.25s ease, box-shadow 0.25s ease;
}

.evaluation-tabs :deep(.ant-tabs-tab .ant-tabs-tab-btn) {
  color: #51607a;
  font-size: 15px;
  font-weight: 600;
  transition: color 0.25s ease;
}

.evaluation-tabs :deep(.ant-tabs-tab:hover) {
  background: rgba(255, 255, 255, 0.85);
}

.evaluation-tabs :deep(.ant-tabs-tab:hover .ant-tabs-tab-btn) {
  color: #1677ff;
}

.evaluation-tabs :deep(.ant-tabs-tab.ant-tabs-tab-active) {
  background: linear-gradient(135deg, #1677ff 0%, #4096ff 100%);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.35);
}

.evaluation-tabs :deep(.ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn) {
  color: #fff;
}

.tab-label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.tab-label :deep(.anticon) {
  font-size: 16px;
}
</style>