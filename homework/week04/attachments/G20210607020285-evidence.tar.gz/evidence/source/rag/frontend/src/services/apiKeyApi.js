import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_USER_MANAGE_URL || '/api/user',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export async function listApiKeys(page = "[REDACTED]"
  const res = await api.get('/api-keys', { params: "[REDACTED]"
  return res.data
}

export async function createApiKey(name) {
  const res = await api.post('/api-keys', { name })
  return res.data
}

export async function updateApiKey(keyId, name) {
  const res = await api.put(`/api-keys/${keyId}`, { name })
  return res.data
}

export async function deleteApiKey(keyId) {
  const res = await api.delete(`/api-keys/${keyId}`)
  return res.data
}

export default api
