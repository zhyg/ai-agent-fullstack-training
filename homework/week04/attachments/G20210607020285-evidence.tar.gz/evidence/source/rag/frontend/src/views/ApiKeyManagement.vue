<template>
  <section class="api-keys-page" aria-label="[REDACTED]"
    <h1>API keys</h1>
    <p class="page-description">
      列表内是你的全部 API key。完整 API key 仅在创建时可见、可复制，请妥善保存，不要与他人分享或暴露在客户端代码中。
      单个账号最多可以保留 {{ MAX_API_KEYS }} 个 API key。
    </p>

    <div class="page-toolbar">
      <a-input-search
        v-model:value="searchQuery"
        placeholder="搜索 API key"
        allow-clear
        class="search-input"
      />
      <span class="key-count">{{ store.keyCount }} / {{ MAX_API_KEYS }}</span>
      <a-button
        type="primary"
        :disabled="store.keyCount >= MAX_API_KEYS"
        :loading="createLoading"
        @click="openCreate"
      >创建 API key</a-button>
    </div>

    <a-table
      class="keys-table"
      :columns="columns"
      :data-source="filteredKeys"
      row-key="id"
      :pagination="tablePagination"
      :scroll="{ x: 1000 }"
      :locale="{ emptyText: '暂无 API key，点击「创建 API key」开始' }"
      @change="handleTableChange"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'name'"><span class="key-name">{{ record.name }}</span></template>
        <template v-else-if="column.key === 'id'"><span class="tracking-id">{{ record.id }}</span></template>
        <template v-else-if="column.key === 'maskedKey'"><code>{{ record.masked_key }}</code></template>
        <template v-else-if="column.key === 'createdAt'">{{ formatDate(record.created_at) }}</template>
        <template v-else-if="column.key === 'lastUsedAt'">{{ record.last_used_at ? formatDate(record.last_used_at) : '尚未使用' }}</template>
        <template v-else-if="column.key === 'actions'">
          <a-space :size="4">
            <a-button type="text" :aria-label="`编辑 API key ${record.name}`" title="编辑名称" @click="openEdit(record)">
              <template #icon><EditOutlined /></template>
            </a-button>
            <a-button type="text" :aria-label="`删除 API key ${record.name}`" title="删除" @click="confirmDelete(record)">
              <template #icon><DeleteOutlined /></template>
            </a-button>
          </a-space>
        </template>
      </template>
    </a-table>

    <!-- 创建/编辑名称 模态框 -->
    <a-modal
      :open="editorOpen"
      :title="editingId ? '修改 API key' : '创建 API key'"
      :footer="null"
      :width="560"
      class="api-key-modal"
      @cancel="closeEditor"
    >
      <p v-if="!editingId" class="modal-description">单个账号最多可以保留 {{ MAX_API_KEYS }} 个 API key。</p>
      <a-form v-if="editorOpen" :model="form" layout="vertical" @finish="submit">
        <a-form-item label="名称" name="name" :rules="nameRules">
          <a-input v-model:value="form.name" placeholder="输入 API key 的名称" :maxlength="100" class="name-input" autofocus />
        </a-form-item>
        <div class="modal-actions">
          <a-button @click="closeEditor">取消</a-button>
          <a-button
            type="primary"
            html-type="submit"
            :disabled="!form.name.trim()"
            :loading="submitLoading"
          >{{ editingId ? '保存' : '创建' }}</a-button>
        </div>
      </a-form>
    </a-modal>

    <!-- 创建成功密钥展示 -->
    <a-modal
      :open="!!createdSecret"
      title="API key 已创建"
      :footer="null"
      :width="600"
      :mask-closable="false"
      class="api-key-modal"
      @cancel="closeSecret"
    >
      <p class="modal-description">请立即复制并妥善保存。关闭此窗口后，将无法再次查看完整 key。</p>
      <a-textarea :value="createdSecret" readonly aria-label="新建的完整 API key" :auto-size="{ minRows: 2, maxRows: 4 }" class="secret-input" />
      <div class="modal-actions">
        <a-button @click="copySecret"><template #icon><CopyOutlined /></template>复制 key</a-button>
        <a-button type="primary" @click="closeSecret">我已保存</a-button>
      </div>
    </a-modal>
  </section>
</template>

<script setup>
import { onMounted, onBeforeUnmount, reactive, ref, computed } from 'vue'
import { Modal, message } from 'ant-design-vue'
import { CopyOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons-vue'
import { MAX_API_KEYS, useApiKeyStore } from '../stores/apiKey.js'

const store = useApiKeyStore()
const editorOpen = ref(false)
const editingId = ref(null)
const createdSecret = ref('')
const form = reactive({ name: '' })
const searchQuery = ref('')
const createLoading = ref(false)
const submitLoading = ref(false)

const nameRules = [
  { required: true, whitespace: true, message: '请输入 API key 的名称' },
  { max: 100, message: '名称最多为 100 个字符' }
]

const columns = [
  { title: '名称', dataIndex: 'name', key: 'name', width: 180 },
  { title: 'Tracking ID', dataIndex: 'id', key: 'id', width: 350 },
  { title: 'Key', dataIndex: 'masked_key', key: 'maskedKey', width: 230 },
  { title: '创建日期', key: 'createdAt', width: 140 },
  { title: '最新使用日期', key: 'lastUsedAt', width: 150 },
  { title: '操作', key: 'actions', width: 100 }
]

const filteredKeys = computed(() => {
  const q = searchQuery.value.trim().toLowerCase()
  if (!q) return store.keys
  return store.keys.filter(k => k.name.toLowerCase().includes(q))
})

const tablePagination = computed(() => ({
  current: store.currentPage,
  pageSize: 10,
  total: searchQuery.value.trim() ? filteredKeys.value.length : store.total,
  hideOnSinglePage: true,
  showSizeChanger: false,
}))

function handleTableChange(pagination) {
  if (!searchQuery.value.trim()) {
    store.fetchKeys(pagination.current, 10)
  }
}

function formatDate(value) {
  return new Date(value).toLocaleDateString('sv-SE')
}

function openCreate() {
  editingId.value = null
  form.name = ''
  editorOpen.value = true
}

function openEdit(record) {
  editingId.value = record.id
  form.name = record.name
  editorOpen.value = true
}

function closeEditor() {
  editorOpen.value = false
  editingId.value = null
  form.name = ''
}

async function submit() {
  submitLoading.value = true
  try {
    const editing = !!editingId.value
    if (editing) {
      await store.updateKeyName(editingId.value, form.name)
      closeEditor()
      message.success('名称已保存')
    } else {
      const result = await store.createKey(form.name)
      closeEditor()
      createdSecret.value = result.secret
    }
  } catch (error) {
    const msg = error.response?.data?.detail || '保存失败，请重试'
    message.error(msg)
  } finally {
    submitLoading.value = false
  }
}

function confirmDelete(record) {
  Modal.confirm({
    title: '删除 API key',
    content: `确定删除「${record.name}」吗？此操作无法撤销。`,
    okText: '删除',
    okType: 'danger',
    cancelText: '取消',
    async onOk() {
      try {
        await store.deleteKey(record.id)
        message.success('API key 已删除')
      } catch (error) {
        const msg = error.response?.data?.detail || '删除失败，请重试'
        message.error(msg)
      }
    }
  })
}

async function copySecret() {
  try {
    await navigator.clipboard.writeText(createdSecret.value)
    message.success('已复制，请妥善保存')
  } catch {
    message.error('复制失败，请手动选中并复制 key')
  }
}

function closeSecret() {
  createdSecret.value = ''
}

onMounted(() => {
  store.fetchKeys(1, 10)
})

onBeforeUnmount(closeSecret)
</script>

<style scoped>
.api-keys-page { padding: "[REDACTED]"
h1 { margin: 0 0 18px; font-size: 36px; font-weight: 600; letter-spacing: -1px; }
.page-description { max-width: 1350px; margin: 0; color: #80858e; font-size: 17px; line-height: 1.9; }
.page-toolbar { display: flex; justify-content: flex-end; align-items: center; gap: 18px; margin: 40px 0 24px; }
.search-input { max-width: 260px; }
.key-count { color: #8a8e96; font-size: 13px; font-variant-numeric: tabular-nums; }
.page-toolbar .ant-btn, .modal-actions .ant-btn { height: 44px; padding: 0 24px; border-radius: 24px; font-size: 15px; }
.keys-table { background: #f8f9fa; border-radius: 16px; overflow: hidden; }
.keys-table :deep(.ant-table) { background: transparent; }
.keys-table :deep(.ant-table-thead > tr > th) { background: #f8f9fa; color: #656b73; font-weight: 500; font-size: 16px; padding: 22px 20px; }
.keys-table :deep(.ant-table-tbody > tr > td) { padding: 20px; border-bottom: none; font-size: 15px; }
.key-name { overflow-wrap: anywhere; }
.tracking-id, code { font-variant-numeric: tabular-nums; font-family: inherit; }
.modal-description { margin: 22px 0 18px; color: #777d85; font-size: 15px; line-height: 1.8; }
.name-input { border-radius: 26px; padding: 12px 18px; border-color: #26282c; }
.secret-input { font-family: monospace; padding: 14px; }
.modal-actions { display: flex; justify-content: flex-end; gap: 12px; margin-top: 28px; }
:global(.api-key-modal .ant-modal-content) { padding: "[REDACTED]"
:global(.api-key-modal .ant-modal-title) { font-size: "[REDACTED]"
:global(.api-key-modal .ant-modal-close) { top: "[REDACTED]"
@media (max-width: 600px) {
  h1 { font-size: 28px; }
  .page-description { font-size: 15px; }
  .page-toolbar { margin-top: 28px; }
  :global(.api-key-modal .ant-modal-content) { padding: "[REDACTED]"
}
</style>
