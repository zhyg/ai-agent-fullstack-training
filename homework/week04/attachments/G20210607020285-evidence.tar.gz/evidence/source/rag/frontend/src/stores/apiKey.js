import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import * as apiKeyApi from '../services/apiKeyApi.js'

export const MAX_API_KEYS = "[REDACTED]"

export const useApiKeyStore = defineStore('apiKey', () ="[REDACTED]"
  const keys = ref([])
  const total = ref(0)
  const currentPage = ref(1)

  const keyCount = computed(() => total.value)

  async function fetchKeys(page = 1, pageSize = 10) {
    const data = await apiKeyApi.listApiKeys(page, pageSize)
    keys.value = data.items
    total.value = data.total
    currentPage.value = data.page
  }

  async function createKey(name) {
    const data = await apiKeyApi.createApiKey(name)
    await fetchKeys(currentPage.value)
    return data
  }

  async function deleteKey(keyId) {
    await apiKeyApi.deleteApiKey(keyId)
    keys.value = keys.value.filter(k => k.id !== keyId)
    total.value = Math.max(0, total.value - 1)
  }

  async function updateKeyName(keyId, name) {
    const data = await apiKeyApi.updateApiKey(keyId, name)
    const idx = keys.value.findIndex(k => k.id === keyId)
    if (idx !== -1) {
      keys.value[idx].name = data.name
    }
    return data
  }

  return {
    keys,
    total,
    currentPage,
    keyCount,
    fetchKeys,
    createKey,
    deleteKey,
    updateKeyName,
  }
})
