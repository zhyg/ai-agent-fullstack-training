<template>
  <a-form layout="vertical">
    <a-form-item
      label="循环次数"
      required
      :validate-status="outOfRange ? 'error' : ''"
      :help="outOfRange ? '循环次数须为 1–1000 的整数' : ''"
    >
      <a-input-number
        v-model:value="draft.config.loop_count"
        :min="1"
        :max="1000"
        :precision="0"
        style="width: 240px"
      />
      <span class="field-hint">范围 1–1000，默认 {{ defaultLoop }}</span>
    </a-form-item>
  </a-form>
</template>

<script setup>
import { computed, watch } from 'vue'

const props = defineProps({
  draft: { type: Object, required: true },
  agentType: { type: String, required: true }
})

// 默认值按类型：推理行动 10、规划推理 100（FR-009）
const defaultLoop = computed(() => (props.agentType === 'planning_reasoning' ? 100 : 10))

watch(
  defaultLoop,
  (v) => {
    if (props.draft.config.loop_count == null) props.draft.config.loop_count = v
  },
  { immediate: true }
)

const outOfRange = computed(() => {
  const v = props.draft.config.loop_count
  return v != null && (!Number.isInteger(v) || v < 1 || v > 1000)
})
</script>

<style scoped>
.field-hint {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}
</style>