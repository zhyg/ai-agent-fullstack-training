<template>
  <a-modal
    :open="open"
    :title="`${editingId ? '编辑' : '新增'}角色`"
    :footer="null"
    :width="520"
    @cancel="$emit('close')"
  >
    <a-form
      :model="form"
      :rules="rules"
      layout="vertical"
      class="role-form"
      @finish="handleSubmit"
    >
      <a-form-item label="角色名" name="name">
        <a-input v-model:value="form.name" placeholder="请输入角色名" :maxlength="50" />
      </a-form-item>
      <a-form-item label="描述" name="description">
        <a-textarea v-model:value="form.description" placeholder="请输入角色描述" :rows="3" :maxlength="200" show-count />
      </a-form-item>
      <div class="form-actions">
        <a-button @click="$emit('close')">取消</a-button>
        <a-button type="primary" html-type="submit">保存</a-button>
      </div>
    </a-form>
  </a-modal>
</template>

<script setup>
import { reactive, watch } from 'vue'

const props = defineProps({
  open: { type: Boolean, default: false },
  editingId: { type: String, default: null },
  initialName: { type: String, default: '' },
  initialDescription: { type: String, default: '' }
})

const emit = defineEmits(['close', 'submit'])

const form = reactive({ name: '', description: '' })

const rules = {
  name: [
    { required: true, whitespace: true, message: '请输入角色名' },
    { max: 50, message: '角色名最多50个字符' }
  ],
  description: [{ max: 200, message: '角色描述最多200个字符' }]
}

watch(() => props.open, (val) => {
  if (val) {
    form.name = props.initialName
    form.description = props.initialDescription
  }
})

function handleSubmit() {
  emit('submit', { ...form })
}
</script>

<style scoped>
.role-form { padding-top: 20px; }
.form-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 28px; }
</style>
