import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor: attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      localStorage.removeItem('permissions')
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export async function listChats(page = 1, pageSize = 20) {
  const res = await api.get('/chats', { params: { page, page_size: pageSize } })
  return res.data
}

export async function createChat(data) {
  const res = await api.post('/chats', data)
  return res.data
}

export async function updateChat(chatId, data) {
  const res = await api.put(`/chats/${chatId}`, data)
  return res.data
}

export async function deleteChat(chatId) {
  const res = await api.delete(`/chats/${chatId}`)
  return res.data
}

/**
 * Cancel an active chat generation.
 * @param {string} chatId
 */
export async function cancelChat(chatId) {
  const res = await api.post(`/chats/${chatId}/cancel`)
  return res.data
}

export async function getMessages(chatId, page = 1, pageSize = 50) {
  const res = await api.get(`/chats/${chatId}/messages`, { params: { page, page_size: pageSize } })
  return res.data
}

/**
 * 图片预签名过期后重签（FR-013）：返回 { content, references }.
 */
export async function refreshMessageUrls(chatId, messageId) {
  const res = await api.post(`/chats/${chatId}/messages/${messageId}/refresh-urls`)
  return res.data
}

/**
 * Send a message and stream SSE response using fetch + ReadableStream.
 * @param {string} chatId
 * @param {string} content
 * @param {function} onChunk - called with each content chunk string
 * @param {function} onDone - called when stream is complete with { message_id, trace_id? }
 * @param {function} onError - called on error (message, event?)；event 携带 code/raw_output/cancelled 详情
 * @param {AbortSignal} [signal] - optional AbortSignal to cancel the SSE stream
 * @param {function} [onEvent] - agent 模式扩展事件（step/references/usage/cancelled）
 */
export async function sendMessage(chatId, content, onChunk, onDone, onError, signal, onEvent) {
  const baseURL = import.meta.env.VITE_KNOWLEDGE_MANAGE_URL || '/api/knowledge'
  const token = localStorage.getItem('access_token')

  const response = await fetch(`${baseURL}/chats/${chatId}/messages`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ content }),
    signal
  })

  if (!response.ok) {
    const errorBody = await response.text()
    let detail = '发送消息失败'
    try {
      detail = JSON.parse(errorBody).detail || detail
    } catch { /* ignore */ }
    console.error('[chatApi] SSE request rejected', {
      chatId,
      status: response.status,
      detail: Array.isArray(detail)
        ? detail.map(({ type, loc, msg }) => ({ type, location: loc, message: msg }))
        : detail
    })
    onError(formatErrorDetail(detail))
    return
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue
      const payload = line.slice(6).trim()
      if (!payload) continue

      try {
        const event = JSON.parse(payload)
        if (payload === '[DONE]') {
          onDone(event)
          return
        }
        // Error event: { type: 'error', message, code?, raw_output? } or legacy { error: '...' }
        if (event.type === 'error' || event.error) {
          onError(event.message || formatErrorDetail(event.error), event)
          return
        }
        if (event.type === 'done' || event.done) {
          onDone(event)
          return
        }
        if (event.type === 'cancelled') {
          // agent 模式：携带 message_id/partial_content，由 store 落定部分答案
          if (onEvent) onEvent(event)
          onError('会话已取消', event)
          return
        }
        // agent 模式扩展事件：step 进度 / references 引用映射 / usage 用量
        if (event.type === 'step' || event.type === 'references' || event.type === 'usage') {
          if (onEvent) onEvent(event)
          continue
        }
        // Delta event: { type: 'delta', content: '...' } or legacy { content: '...' }
        if (event.content || event.type === 'delta') {
          onChunk(event.content)
        }
      } catch { /* ignore parse errors */ }
    }
  }
}

function formatErrorDetail(detail) {
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) {
    return detail
      .map((item) => {
        if (typeof item === 'string') return item
        const location = Array.isArray(item?.loc) ? `${item.loc.join('.')}: ` : ''
        return `${location}${item?.msg || item?.message || JSON.stringify(item)}`
      })
      .join('; ')
  }
  if (detail && typeof detail === 'object') {
    return detail.message || JSON.stringify(detail)
  }
  return String(detail || '发送消息失败')
}

export default api
