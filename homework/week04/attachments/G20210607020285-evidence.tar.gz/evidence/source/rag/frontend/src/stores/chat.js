import { defineStore } from 'pinia'
import { reactive, ref } from 'vue'
import { message } from 'ant-design-vue'
import * as chatApi from '../services/chatApi.js'

export const useChatStore = defineStore('chat', () => {
  const chats = ref([])
  const total = ref(0)
  const currentChatId = ref(null)
  const messages = ref([])
  const loading = ref(false)
  const streaming = ref(false)
  const isCancelling = ref(false)
  // agent 模式：当前步骤进度（done/error/cancelled 后清除）
  const stepProgress = ref(null)

  // AbortController for the current SSE stream
  let currentAbortController = null

  async function fetchChats(page = 1, pageSize = 20) {
    loading.value = true
    try {
      const data = await chatApi.listChats(page, pageSize)
      chats.value = data.items || []
      total.value = data.total || 0
    } catch (e) {
      console.error('Failed to fetch chats:', e)
    } finally {
      loading.value = false
    }
  }

  async function createChat(title, modelName = null, promptId = null) {
    try {
      const chat = await chatApi.createChat({
        title: title || '新会话',
        model_name: modelName,
        prompt_id: promptId
      })
      chats.value.unshift(chat)
      total.value++
      currentChatId.value = chat.id
      messages.value = []
      return chat
    } catch (e) {
      console.error('Failed to create chat:', e)
      return null
    }
  }

  async function updateChat(chatId, data) {
    try {
      const updated = await chatApi.updateChat(chatId, data)
      const idx = chats.value.findIndex(c => c.id === chatId)
      if (idx !== -1) {
        chats.value[idx] = updated
      }
      return updated
    } catch (e) {
      console.error('Failed to update chat:', e)
      return null
    }
  }

  async function deleteChat(chatId) {
    try {
      await chatApi.deleteChat(chatId)
      chats.value = chats.value.filter(c => c.id !== chatId)
      total.value--
      if (currentChatId.value === chatId) {
        currentChatId.value = null
        messages.value = []
      }
      return true
    } catch (e) {
      console.error('Failed to delete chat:', e)
      return false
    }
  }

  async function selectChat(chatId) {
    currentChatId.value = chatId
    stepProgress.value = null
    await fetchMessages(chatId)
  }

  async function fetchMessages(chatId, page = 1, pageSize = 200) {
    try {
      const data = await chatApi.getMessages(chatId, page, pageSize)
      messages.value = data.items || []
    } catch (e) {
      console.error('Failed to fetch messages:', e)
      messages.value = []
    }
  }

  async function sendMessage(content) {
    const chatId = currentChatId.value
    if (!chatId) return

    // Add user message optimistically
    const userMsg = {
      id: `temp-${Date.now()}`,
      role: 'user',
      content,
      created_at: new Date().toISOString()
    }
    messages.value.push(userMsg)

    // Prepare streaming assistant message
    const assistantMsg = reactive({
      id: `streaming-${Date.now()}`,
      role: 'assistant',
      content: '',
      created_at: new Date().toISOString()
    })
    messages.value.push(assistantMsg)
    streaming.value = true

    // Create AbortController for this stream
    currentAbortController = new AbortController()
    const signal = currentAbortController.signal

    let streamError = null

    // agent 模式扩展事件：step 进度 / references 映射 / usage / cancelled 详情
    const handleEvent = (event) => {
      if (event.type === 'step') {
        stepProgress.value = event
      } else if (event.type === 'references') {
        assistantMsg.references = event.items || []
      } else if (event.type === 'usage') {
        const { type, ...usage } = event
        assistantMsg.usage = usage
      } else if (event.type === 'cancelled') {
        if (event.message_id) assistantMsg.id = event.message_id
        if (typeof event.partial_content === 'string') {
          assistantMsg.content = event.partial_content
        }
        assistantMsg.meta = { ...(assistantMsg.meta || {}), stopped: true }
        stepProgress.value = null
        const chat = chats.value.find(c => c.id === chatId)
        if (chat) chat.status = 'cancelled'
      }
    }

    try {
      await chatApi.sendMessage(
        chatId,
        content,
        // onChunk
        (chunk) => {
          assistantMsg.content += chunk
        },
        // onDone
        (event) => {
          assistantMsg.id = event.message_id || assistantMsg.id
          if (event.trace_id) assistantMsg.trace_id = event.trace_id
          if (event.meta) assistantMsg.meta = { ...(assistantMsg.meta || {}), ...event.meta }
          streaming.value = false
          currentAbortController = null
          stepProgress.value = null
          const chat = chats.value.find(c => c.id === chatId)
          if (chat) chat.status = 'completed'
        },
        // onError
        (error, event) => {
          if (error === '会话已取消') {
            streaming.value = false
            currentAbortController = null
            stepProgress.value = null
            return
          }
          if (error === '当前问答尚未结束，请稍候') {
            // 同会话并发拒绝（409）：toast 提示并回滚乐观消息，不留错误气泡
            message.warning(error)
            for (const msg of [userMsg, assistantMsg]) {
              const index = messages.value.indexOf(msg)
              if (index !== -1) messages.value.splice(index, 1)
            }
            streaming.value = false
            currentAbortController = null
            stepProgress.value = null
            streamError = error
            return
          }
          streamError = error
          assistantMsg.error = {
            code: event?.code || null,
            message: error,
            raw_output: event?.raw_output || null
          }
          streaming.value = false
          currentAbortController = null
          stepProgress.value = null
        },
        signal,
        handleEvent
      )
    } catch (e) {
      if (e.name === 'AbortError') {
        streaming.value = false
        currentAbortController = null
        stepProgress.value = null
        return { success: false, error: '已取消' }
      }
      streamError = e.message
      assistantMsg.error = { code: null, message: e.message, raw_output: null }
      streaming.value = false
      currentAbortController = null
      stepProgress.value = null
    }

    if (streamError) {
      return { success: false, error: streamError }
    }
    return { success: true }
  }

  async function cancelGeneration() {
    const chatId = currentChatId.value
    if (!chatId) return

    isCancelling.value = true
    try {
      await chatApi.cancelChat(chatId)
    } catch (e) {
      console.error('Failed to cancel generation:', e)
    }

    // Abort the SSE stream client-side
    if (currentAbortController) {
      currentAbortController.abort()
      currentAbortController = null
    }
    streaming.value = false
    isCancelling.value = false

    // Update chat status
    const chat = chats.value.find(c => c.id === chatId)
    if (chat) chat.status = 'cancelled'
  }

  /**
   * Resume streaming for a chat that has status === 'generating'.
   * Reattaches to the active backend generation job.
   */
  async function resumeStream(chatId) {
    if (!chatId) return

    // Create AbortController for this stream
    currentAbortController = new AbortController()
    const signal = currentAbortController.signal

    // Prepare streaming assistant message placeholder
    const assistantMsg = reactive({
      id: `streaming-${Date.now()}`,
      role: 'assistant',
      content: '',
      created_at: new Date().toISOString()
    })
    messages.value.push(assistantMsg)
    streaming.value = true

    const handleEvent = (event) => {
      if (event.type === 'step') {
        stepProgress.value = event
      } else if (event.type === 'references') {
        assistantMsg.references = event.items || []
      } else if (event.type === 'usage') {
        const { type, ...usage } = event
        assistantMsg.usage = usage
      } else if (event.type === 'cancelled') {
        if (event.message_id) assistantMsg.id = event.message_id
        if (typeof event.partial_content === 'string') {
          assistantMsg.content = event.partial_content
        }
        assistantMsg.meta = { ...(assistantMsg.meta || {}), stopped: true }
        stepProgress.value = null
      }
    }

    try {
      await chatApi.sendMessage(
        chatId,
        '',  // empty content to reattach
        // onChunk
        (chunk) => {
          assistantMsg.content += chunk
        },
        // onDone
        (event) => {
          assistantMsg.id = event.message_id || assistantMsg.id
          if (event.trace_id) assistantMsg.trace_id = event.trace_id
          if (event.meta) assistantMsg.meta = { ...(assistantMsg.meta || {}), ...event.meta }
          if (!assistantMsg.content && event.type === 'done') {
            const index = messages.value.indexOf(assistantMsg)
            if (index !== -1) messages.value.splice(index, 1)
          }
          streaming.value = false
          currentAbortController = null
          stepProgress.value = null
          const chat = chats.value.find(c => c.id === chatId)
          if (chat) chat.status = 'completed'
        },
        // onError
        (error, event) => {
          if (error === '会话已取消') {
            streaming.value = false
            currentAbortController = null
            stepProgress.value = null
            const chat = chats.value.find(c => c.id === chatId)
            if (chat) chat.status = 'cancelled'
            return
          }
          assistantMsg.error = {
            code: event?.code || null,
            message: error,
            raw_output: event?.raw_output || null
          }
          streaming.value = false
          currentAbortController = null
          stepProgress.value = null
        },
        signal,
        handleEvent
      )
    } catch (e) {
      if (e.name === 'AbortError') {
        streaming.value = false
        currentAbortController = null
        stepProgress.value = null
        return
      }
      assistantMsg.error = { code: null, message: e.message, raw_output: null }
      streaming.value = false
      currentAbortController = null
      stepProgress.value = null
    }
  }

  /**
   * 图片预签名过期重签（FR-013）：更新消息内容与 references 片段 URL.
   */
  async function refreshMessageUrls(chatId, messageId) {
    try {
      const data = await chatApi.refreshMessageUrls(chatId, messageId)
      const msg = messages.value.find(m => m.id === messageId)
      if (msg) {
        msg.content = data.content
        if (data.references?.length) {
          msg.references = data.references
          msg.meta = { ...(msg.meta || {}), references: data.references }
        }
      }
      return data
    } catch (e) {
      console.error('Failed to refresh message urls:', e)
      return null
    }
  }

  return {
    chats,
    total,
    currentChatId,
    messages,
    loading,
    streaming,
    isCancelling,
    stepProgress,
    fetchChats,
    createChat,
    updateChat,
    deleteChat,
    selectChat,
    fetchMessages,
    sendMessage,
    cancelGeneration,
    resumeStream,
    refreshMessageUrls
  }
})
