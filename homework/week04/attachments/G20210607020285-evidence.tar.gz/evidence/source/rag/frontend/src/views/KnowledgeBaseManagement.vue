<template>
  <div>
    <KbList
      :knowledgeBases="kbStore.knowledgeBases"
      :models="modelStore.models"
      @create="openCreateModal"
      @enter="handleEnter"
      @edit="openEditDrawer"
      @delete="handleDelete"
    />
    <KbCreateModal
      :visible="createModalVisible"
      :models="modelStore.models"
      @close="closeCreateModal"
      @submit="handleCreateSubmit"
    />
    <KbFormDrawer
      :visible="drawerVisible"
      :kb="editingKb"
      :models="modelStore.models"
      @close="closeDrawer"
      @submit="handleEditSubmit"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Modal, message } from 'ant-design-vue'
import { useKbStore } from '../stores/knowledgeBase.js'
import { useModelStore } from '../stores/model.js'
import KbList from '../components/knowledge-base/KbList.vue'
import KbCreateModal from '../components/knowledge-base/KbCreateModal.vue'
import KbFormDrawer from '../components/knowledge-base/KbFormDrawer.vue'

const kbStore = useKbStore()
const modelStore = useModelStore()
const router = useRouter()

const createModalVisible = ref(false)
const drawerVisible = ref(false)
const editingKb = ref(null)

onMounted(() => {
  kbStore.fetchKnowledgeBases(1, 1000)
  modelStore.fetchModels(1, 1000)
})

function openCreateModal() {
  createModalVisible.value = true
}

function closeCreateModal() {
  createModalVisible.value = false
}

async function handleCreateSubmit(data) {
  const result = await kbStore.createKb(data)
  if (result.success) {
    message.success(result.message)
    closeCreateModal()
  } else {
    message.error(result.message)
  }
}

function openEditDrawer(kb) {
  editingKb.value = kb
  drawerVisible.value = true
}

function closeDrawer() {
  drawerVisible.value = false
  editingKb.value = null
}

async function handleEditSubmit(data) {
  const result = await kbStore.updateKb(editingKb.value.id, data)
  if (result.success) {
    message.success(result.message)
    closeDrawer()
  } else {
    message.error(result.message)
  }
}

function handleEnter(kb) {
  router.push({ name: 'KnowledgeManagement', params: { kbId: kb.id } })
}

function handleDelete(kb) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除知识库 "${kb.name}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    async onOk() {
      const result = await kbStore.deleteKb(kb.id)
      if (result.success) {
        message.success(result.message)
      } else {
        message.error(result.message)
      }
    }
  })
}
</script>
