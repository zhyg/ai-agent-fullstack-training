import { connectDocumentStatus } from './documentApi.js'

export function subscribeDocumentStatus(id, { onUpdate, onConnectionError }) {
  let socket
  let retryTimer
  let retryDelay = 1000
  let stopped = false

  function retry() {
    onConnectionError('状态连接中断，正在重连')
    retryTimer = setTimeout(connect, retryDelay)
    retryDelay = Math.min(retryDelay * 2, 30000)
  }

  function connect() {
    if (stopped) return
    const token = localStorage.getItem('access_token')
    if (!token) {
      onConnectionError('请重新登录以接收状态更新')
      return
    }

    try {
      socket = connectDocumentStatus(id)
    } catch (error) {
      console.warn('无法连接文档状态服务', error)
      retry()
      return
    }
    socket.onopen = () => socket.send(token)
    socket.onmessage = ({ data }) => {
      let update
      try {
        update = JSON.parse(data)
      } catch (error) {
        console.warn('无法读取文档状态推送', error)
        onConnectionError('状态消息读取失败')
        return
      }
      if (update?.id !== id) {
        onConnectionError('收到不匹配的文档状态')
        return
      }
      retryDelay = 1000
      onConnectionError('')
      onUpdate(update)
    }
    socket.onclose = ({ code }) => {
      if (code === 4404) {
        onConnectionError('文档已不存在或无权访问')
      } else if (code === 4401 && token === localStorage.getItem('access_token')) {
        onConnectionError('请重新登录以接收状态更新')
      } else {
        retry()
      }
    }
  }

  connect()

  return () => {
    stopped = true
    clearTimeout(retryTimer)
    if (socket) {
      socket.onclose = null
      socket.onmessage = null
      socket.onopen = null
      if (socket.readyState < WebSocket.CLOSING) socket.close()
    }
  }
}
