<template>
  <div>
    <a-spin :spinning="modelStore.loading">
      <ModelList
        :models="modelStore.models"
        @create="openCreateDrawer"
        @edit="openEditDrawer"
        @delete="handleDelete"
      />
    </a-spin>
    <ModelFormDrawer
      :visible="drawerVisible"
      :model="editingModel"
      :category="creatingCategory"
      @close="closeDrawer"
      @submit="handleSubmit"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { Modal, message } from 'ant-design-vue'
import { useModelStore } from '../stores/model.js'
import ModelList from '../components/model/ModelList.vue'
import ModelFormDrawer from '../components/model/ModelFormDrawer.vue'

const modelStore = useModelStore()
const drawerVisible = ref(false)
const editingModel = ref(null)
const creatingCategory = ref('chat')

onMounted(() => {
  modelStore.fetchModels(1, 1000)
})

function openCreateDrawer(category = 'chat') {
  editingModel.value = null
  creatingCategory.value = category
  drawerVisible.value = true
}

function openEditDrawer(model) {
  editingModel.value = model
  drawerVisible.value = true
}

function closeDrawer() {
  drawerVisible.value = false
  editingModel.value = null
}

async function handleSubmit(data) {
  let result
  if (editingModel.value) {
    result = await modelStore.updateModel(editingModel.value.id, data)
  } else {
    result = await modelStore.createModel(data)
  }
  if (result.success) {
    closeDrawer()
    message.success(result.message)
  } else {
    message.error(result.message)
  }
}

function handleDelete(model) {
  Modal.confirm({
    title: '确认删除',
    content: `确定要删除模型 "${model.name}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    async onOk() {
      const result = await modelStore.deleteModel(model.id)
      if (result.success) {
        message.success(result.message)
      } else {
        message.error(result.message)
      }
    }
  })
}
</script>
