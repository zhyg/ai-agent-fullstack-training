<template>
  <div class="knowledge-management" v-if="currentKb">
    <div class="km-header">
      <a-button class="km-back-btn" @click="goBack">
        <template #icon><ArrowLeftOutlined /></template>
        返回知识库列表
      </a-button>
      <h2 style="margin: 0;">
        {{ currentKb.name }}
        <span class="km-subtitle">/ 知识管理</span>
      </h2>
    </div>

    <div class="km-body">
      <aside class="km-sidebar">
        <FolderTree
          :kb-id="currentKb.id"
          :selected-folder-id="currentFolderId"
          :loading="folderStore.loading"
          @select="handleFolderSelect"
          @create-root="openFolderAction('create-root', null)"
          @create-child="(parent) => openFolderAction('create-child', parent)"
          @rename="(folder) => openFolderAction('rename', folder)"
          @delete="(folder) => openFolderAction('delete', folder)"
          @drop="handleFolderDrop"
        />
      </aside>

      <section class="km-main">
        <DocumentTable
          :folder-id="currentFolderId"
          :folder-name="currentFolderName"
          :documents="visibleDocuments"
          :status-errors="documentStatusErrors"
          :selected-row-keys="selectedRowKeys"
          :loading="Boolean(currentFolderId) && documentStore.loading"
          :current-page="documentPage"
          :page-size="documentPageSize"
          :total="currentFolderId ? documentStore.total : 0"
          @select-change="(keys) => selectedRowKeys = keys"
          @pagination-change="handleDocumentPaginationChange"
          @row-click="openDocumentDetail"
          @create="openCreateDocModal"
          @batch-delete="handleBatchDelete"
          @delete="handleDeleteDocument"
          @add-tag="openTagModal"
          @remove-tag="handleRemoveTag"
        />
      </section>
    </div>

    <!-- 目录操作模态框 -->
    <FolderActionModal
      :visible="folderActionState.visible"
      :type="folderActionState.type"
      :folder="folderActionState.targetFolder"
      :kb-id="currentKb.id"
      @close="closeFolderAction"
      @submit="handleFolderActionSubmit"
    />

    <!-- 新建知识模态框 -->
    <DocumentCreateModal
      :visible="createDocModalVisible"
      :folder-id="currentFolderId"
      :kb-id="currentKb.id"
      @close="closeCreateDocModal"
      @submit="handleCreateDocument"
    />

    <!-- 标签新增模态框 -->
    <DocumentActionModal
      :visible="tagModalVisible"
      :document="tagModalDocument"
      @close="closeTagModal"
      @submit="handleAddTags"
    />

    <!-- 文档详情抽屉 -->
    <DocumentDetailDrawer
      :visible="detailDrawerVisible"
      :document="viewingDocument"
      :status-connection-error="documentStatusErrors[viewingDocument?.id]"
      @close="closeDocumentDetail"
      @add-tag="openTagModal"
      @remove-tag="handleRemoveTag"
    />
  </div>

  <a-result
    v-else-if="!kbLoading"
    status="404"
    title="知识库不存在"
    sub-title="您访问的知识库不存在或已被删除"
  >
    <template #extra>
      <a-button type="primary" @click="goBack">返回知识库列表</a-button>
    </template>
  </a-result>

  <div v-else style="text-align: center; padding: 80px 0;">
    <a-spin size="large" tip="加载中..." />
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { message, Modal } from 'ant-design-vue'
import { ArrowLeftOutlined } from '@ant-design/icons-vue'
import { useKbStore } from '../stores/knowledgeBase.js'
import { useFolderStore } from '../stores/folder.js'
import { useDocumentStore } from '../stores/document.js'
import { subscribeDocumentStatus } from '../services/documentStatus.js'
import FolderTree from '../components/knowledge/FolderTree.vue'
import FolderActionModal from '../components/knowledge/FolderActionModal.vue'
import DocumentCreateModal from '../components/knowledge/DocumentCreateModal.vue'
import DocumentTable from '../components/knowledge/DocumentTable.vue'
import DocumentActionModal from '../components/knowledge/DocumentActionModal.vue'
import DocumentDetailDrawer from '../components/knowledge/DocumentDetailDrawer.vue'

const route = useRoute()
const router = useRouter()
const kbStore = useKbStore()
const folderStore = useFolderStore()
const documentStore = useDocumentStore()

const kbLoading = ref(true)
const kbId = computed(() => route.params.kbId)
const currentKb = computed(() => {
  if (!kbId.value) return null
  return kbStore.knowledgeBases.find((kb) => kb.id === kbId.value) || null
})

const selectedFolderId = ref(null)
const currentFolder = computed(() => {
  const folder = folderStore.getFolderById(selectedFolderId.value)
  return folder?.kbId === kbId.value ? folder : null
})
const currentFolderId = computed(() => currentFolder.value?.id ?? null)
const currentFolderName = computed(() => currentFolder.value?.name ?? '')
const visibleDocuments = computed(() => currentFolderId.value
  ? documentStore.documents.filter((doc) => doc.folderId === currentFolderId.value)
  : [])

const documentPage = ref(1)
const documentPageSize = ref(20)
const selectedRowKeys = ref([])

// 目录操作状态
const folderActionState = ref({
  visible: false,
  type: 'create-root',
  targetFolder: null
})

// 文档创建模态框
const createDocModalVisible = ref(false)

// 标签模态框
const tagModalVisible = ref(false)
const tagModalDocument = ref(null)

// 文档详情抽屉
const detailDrawerVisible = ref(false)
const viewingDocument = ref(null)
const documentStatusErrors = ref({})
const statusSubscriptions = new Map()

const visibleDocumentIds = computed(() => {
  const ids = new Set(visibleDocuments.value.map((doc) => doc.id))
  if (detailDrawerVisible.value && viewingDocument.value?.id) {
    ids.add(viewingDocument.value.id)
  }
  return ids
})

watch(visibleDocumentIds, (ids) => {
  for (const [id, stop] of statusSubscriptions) {
    if (ids.has(id)) continue
    stop()
    statusSubscriptions.delete(id)
    delete documentStatusErrors.value[id]
  }
  for (const id of ids) {
    if (statusSubscriptions.has(id)) continue
    statusSubscriptions.set(id, subscribeDocumentStatus(id, {
      onUpdate(update) {
        const doc = documentStore.applyDocumentUpdate(update)
        if (viewingDocument.value?.id === doc.id) viewingDocument.value = doc
      },
      onConnectionError(error) {
        if (error) documentStatusErrors.value[id] = error
        else delete documentStatusErrors.value[id]
      }
    }))
  }
}, { immediate: true })

onUnmounted(() => {
  for (const stop of statusSubscriptions.values()) stop()
  documentStore.clearDocuments()
})

// Ensure knowledge bases are loaded
onMounted(async () => {
  if (kbStore.knowledgeBases.length === 0) {
    await kbStore.fetchKnowledgeBases(1, 1000)
  }
  kbLoading.value = false
  // 会话引用“查看文档”跳转：/knowledge/:kbId?docId=xxx 自动打开文档详情
  const docId = route.query.docId
  if (docId) {
    const doc = await documentStore.getDocument(docId)
    if (doc && doc.kbId === kbId.value) {
      openDocumentDetail(doc)
    } else {
      message.warning('文档不存在或不可访问')
    }
  }
})

// Watch kbId changes: reset state, fetch folders, auto-select first root
watch(
  kbId,
  async (newKbId) => {
    selectedFolderId.value = null
    selectedRowKeys.value = []

    if (!newKbId) return

    // Fetch folders for this kb
    await folderStore.fetchFolders(newKbId)
    if (newKbId !== kbId.value) return

    // Auto-select first root folder (sorted by order asc)
    const rootFolders = folderStore.folders
      .filter((f) => f.kbId === newKbId && (f.parentId ?? null) === null)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
    if (rootFolders.length > 0) {
      selectedFolderId.value = rootFolders[0].id
    }
  },
  { immediate: true }
)

// Watch folder changes: fetch documents for the selected folder
watch(
  currentFolderId,
  async (newFolderId) => {
    documentStore.clearDocuments()
    documentPage.value = 1
    selectedRowKeys.value = []
    closeDocumentDetail()
    closeTagModal()
    closeCreateDocModal()
    if (newFolderId) {
      await documentStore.fetchDocuments(
        newFolderId,
        documentPage.value,
        documentPageSize.value
      )
    }
  }
)

function goBack() {
  router.push({ name: 'KnowledgeBaseManagement' })
}

// ─── Folder handlers ──────────────────────────────────────

function handleFolderSelect(folder) {
  selectedFolderId.value = folder ? folder.id : null
  selectedRowKeys.value = []
}

function openFolderAction(type, folder) {
  folderActionState.value = { visible: true, type, targetFolder: folder }
}

function closeFolderAction() {
  folderActionState.value.visible = false
}

async function handleFolderActionSubmit(data) {
  const type = folderActionState.value.type
  try {
    if (type === 'create-root') {
      const result = await folderStore.createFolder(currentKb.value.id, {
        name: data.name,
        parentId: null
      })
      if (result.success) {
        message.success('根目录创建成功')
        if (result.data) selectedFolderId.value = result.data.id
      } else {
        message.error(result.message)
      }
    } else if (type === 'create-child') {
      const result = await folderStore.createFolder(currentKb.value.id, {
        name: data.name,
        parentId: folderActionState.value.targetFolder.id
      })
      if (result.success) {
        message.success('子目录创建成功')
      } else {
        message.error(result.message)
      }
    } else if (type === 'rename') {
      const result = await folderStore.updateFolder(data.id, {
        name: data.name
      })
      if (result.success) {
        message.success('目录重命名成功')
      } else {
        message.error(result.message)
      }
    } else if (type === 'delete') {
      const { id: targetId, name } = folderActionState.value.targetFolder
      Modal.confirm({
        title: '确认删除',
        content: `确定要删除目录 "${name}" 及其所有子目录与文档吗？`,
        okText: '确认',
        cancelText: '取消',
        okButtonProps: { danger: true },
        async onOk() {
          const result = await folderStore.deleteFolder(targetId)
          if (result.success) {
            if (!currentFolderId.value) selectedFolderId.value = null
            message.success('目录删除成功')
            closeFolderAction()
          } else {
            message.error(result.message)
          }
        }
      })
      return
    }
    closeFolderAction()
  } catch (err) {
    message.error(err.message || '操作失败')
  }
}

async function handleFolderDrop({ dragId, newParentId, newIndex }) {
  const result = await folderStore.moveFolder(dragId, {
    targetParentId: newParentId,
    targetIndex: newIndex,
    autoRename: true
  })
  if (result.success) {
    if (result.renamed) {
      const folder = folderStore.getFolderById(dragId)
      message.info(`目标位置存在同名目录，已自动重命名为"${folder?.name}"`)
    }
  } else {
    message.error(result.message || '拖拽失败')
  }
}

// ─── Document upload handlers ─────────────────────────────

function openCreateDocModal() {
  if (!currentFolderId.value) {
    message.warning('请先选择目录')
    return
  }
  createDocModalVisible.value = true
}

function closeCreateDocModal() {
  createDocModalVisible.value = false
}

async function handleCreateDocument({ file, folderId, chunkConfig, aiQuestionCount }) {
  const result = await documentStore.uploadDocument(folderId, file, chunkConfig, aiQuestionCount)
  if (result.success) {
    await Promise.all([
      folderStore.fetchFolders(currentKb.value.id),
      currentFolderId.value
        ? documentStore.fetchDocuments(
            currentFolderId.value,
            documentPage.value,
            documentPageSize.value
          )
        : Promise.resolve()
    ])
    message.success(result.message || '上传成功，正在处理...')
    closeCreateDocModal()
  } else {
    message.error(result.message || '上传失败')
  }
}

async function handleDocumentPaginationChange({ page, pageSize }) {
  const pageSizeChanged = pageSize !== documentPageSize.value
  documentPageSize.value = pageSize
  documentPage.value = pageSizeChanged ? 1 : page
  if (currentFolderId.value) {
    await documentStore.fetchDocuments(
      currentFolderId.value,
      documentPage.value,
      documentPageSize.value
    )
  }
}

// ─── Document action handlers ─────────────────────────────

function handleBatchDelete(docIds) {
  Modal.confirm({
    title: '批量删除',
    content: `确定要删除选中的 ${docIds.length} 篇文档吗？`,
    okText: '确认',
    cancelText: '取消',
    okButtonProps: { danger: true },
    async onOk() {
      const result = await documentStore.batchDeleteDocuments(docIds)
      if (result.success) {
        selectedRowKeys.value = []
        message.success(result.message || `已删除 ${result.deleted} 篇`)
      } else {
        message.error(result.message || '批量删除失败')
      }
    }
  })
}

async function handleDeleteDocument(doc) {
  const result = await documentStore.deleteDocument(doc.id)
  if (result.success) {
    message.success('文档已删除')
  } else {
    message.error(result.message || '删除失败')
  }
}

// ─── Tag handlers ─────────────────────────────────────────

function openTagModal(doc) {
  tagModalDocument.value = doc
  tagModalVisible.value = true
}

function closeTagModal() {
  tagModalVisible.value = false
  tagModalDocument.value = null
}

async function handleAddTags({ documentId, tags }) {
  const result = await documentStore.addTags(documentId, tags)
  if (result.success) {
    message.success('标签已添加')
    // Update viewing document if drawer is open
    if (viewingDocument.value && viewingDocument.value.id === documentId) {
      viewingDocument.value = documentStore.getDocumentById(documentId)
    }
    closeTagModal()
  } else {
    message.error(result.message || '添加标签失败')
  }
}

async function handleRemoveTag(doc, tag) {
  Modal.confirm({
    title: '移除标签',
    content: `确定要从 "${doc.name}" 中移除标签 "${tag}" 吗？`,
    okText: '确认',
    cancelText: '取消',
    async onOk() {
      const result = await documentStore.removeTag(doc.id, tag)
      if (result.success) {
        message.success('标签已移除')
        if (viewingDocument.value && viewingDocument.value.id === doc.id) {
          viewingDocument.value = documentStore.getDocumentById(doc.id)
        }
      } else {
        message.error(result.message || '移除标签失败')
      }
    }
  })
}

// ─── Document detail drawer ───────────────────────────────

function openDocumentDetail(doc) {
  viewingDocument.value = doc
  detailDrawerVisible.value = true
}

function closeDocumentDetail() {
  detailDrawerVisible.value = false
  viewingDocument.value = null
}

</script>

<style scoped>
.knowledge-management {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.km-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f0f0f0;
}

/* 醒目返回按钮：蓝底胶囊 + 图标，hover 渐变实心，与评测页返回按钮视觉语言一致 */
.km-back-btn.km-back-btn {
  display: inline-flex;
  align-items: center;
  height: 34px;
  padding: 0 18px;
  border-radius: 17px;
  border: 1px solid #91caff;
  background: #e8f1ff;
  color: #1677ff;
  font-size: 14px;
  font-weight: 600;
  box-shadow: 0 2px 6px rgba(22, 119, 255, 0.15);
  transition: all 0.25s ease;
}

.km-back-btn.km-back-btn:hover,
.km-back-btn.km-back-btn:focus {
  border-color: transparent;
  background: linear-gradient(135deg, #1677ff 0%, #4096ff 100%);
  color: #fff;
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.35);
}

.km-back-btn.km-back-btn:active {
  transform: translateX(-2px);
}

.km-back-btn :deep(.anticon) {
  font-size: 15px;
}

.km-subtitle {
  font-size: 14px;
  color: #8c8c8c;
  font-weight: 400;
  margin-left: 8px;
}

.km-body {
  display: flex;
  gap: 16px;
  padding-top: 16px;
  flex: 1;
  min-height: 0;
}

.km-sidebar {
  width: 280px;
  flex-shrink: 0;
  background: #fafafa;
  border-radius: 8px;
  border: 1px solid #f0f0f0;
  overflow: hidden;
}

.km-main {
  flex: 1;
  min-width: 0;
  overflow: auto;
}
</style>
