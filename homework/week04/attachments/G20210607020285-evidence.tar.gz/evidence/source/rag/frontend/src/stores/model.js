import { defineStore } from 'pinia'
import { ref } from 'vue'
import * as modelApi from '../services/modelApi.js'
import { extractErrorMessage } from '../utils/errorHandler.js'

export const useModelStore = defineStore('model', () => {
  const models = ref([])
  const total = ref(0)
  const page = ref(1)
  const pageSize = ref(20)
  const loading = ref(false)

  async function fetchModels(p = 1, ps = 20) {
    loading.value = true
    try {
      const data = await modelApi.listModels(p, ps)
      models.value = data.items
      total.value = data.total
      page.value = data.page
      pageSize.value = data.page_size
    } catch (error) {
      console.error('Failed to fetch models:', error)
    } finally {
      loading.value = false
    }
  }

  async function createModel(modelData) {
    loading.value = true
    try {
      await modelApi.createModel(modelData)
      await fetchModels(page.value, pageSize.value)
      return { success: true, message: '模型创建成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function updateModel(modelId, modelData) {
    loading.value = true
    try {
      await modelApi.updateModel(modelId, modelData)
      await fetchModels(page.value, pageSize.value)
      return { success: true, message: '模型更新成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  async function deleteModel(modelId) {
    loading.value = true
    try {
      await modelApi.deleteModel(modelId)
      await fetchModels(page.value, pageSize.value)
      return { success: true, message: '模型删除成功' }
    } catch (error) {
      const detail = extractErrorMessage(error)
      return { success: false, message: detail }
    } finally {
      loading.value = false
    }
  }

  return {
    models,
    total,
    page,
    pageSize,
    loading,
    fetchModels,
    createModel,
    updateModel,
    deleteModel
  }
})
