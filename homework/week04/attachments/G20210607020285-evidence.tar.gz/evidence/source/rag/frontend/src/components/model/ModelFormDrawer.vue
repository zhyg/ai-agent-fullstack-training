<template>
  <a-drawer
    :title="model ? '设置模型' : '新建模型'"
    :open="visible"
    width="70vw"
    @close="handleClose"
  >
    <a-form
      ref="formRef"
      :model="formState"
      :rules="rules"
      layout="vertical"
      scroll-to-first-error
      @finish="handleSubmit"
    >
      <a-form-item label="模型分类" name="category">
        <a-select
          v-model:value="formState.category"
          :options="categoryOptions"
          placeholder="请选择模型分类"
        />
      </a-form-item>
      <a-form-item label="模型名称" name="name">
        <a-input v-model:value="formState.name" placeholder="请输入模型名称" />
      </a-form-item>
      <a-form-item label="模型显示名称" name="display_name">
        <a-input v-model:value="formState.display_name" placeholder="请输入模型显示名称（可选）" />
      </a-form-item>
      <a-form-item label="模型供应商" name="provider">
        <a-select
          v-model:value="formState.provider"
          :options="providerOptions"
          show-search
          placeholder="请选择或输入模型供应商"
          :filter-option="filterOption"
        />
      </a-form-item>
      <a-form-item label="URL" name="url">
        <a-input v-model:value="formState.url" placeholder="请输入模型 URL" />
      </a-form-item>
      <a-form-item
        label="API Key"
        name="api_key"
        :extra="model ? '留空则保留原密钥，输入新密钥后替换' : undefined"
      >
        <a-input-password
          v-model:value="formState.api_key"
          :placeholder="model ? (model.api_key_masked || '已配置 API Key') : "[REDACTED]"
        />
      </a-form-item>

      <a-divider>模型参数</a-divider>

      <a-form-item label="上下文窗口（tokens）" name="context_tokens">
        <a-input-number
          v-model:value="formState.context_tokens"
          placeholder="请输入上下文窗口大小，例如 128000"
          style="width: 100%"
          :min="1"
          :max="Number.MAX_SAFE_INTEGER"
          :step="1"
        />
      </a-form-item>

      <!-- Category-specific fields -->
      <template v-if="formState.category === 'embedding'">
        <a-divider>Embedding 参数</a-divider>
        <a-form-item label="输出向量维度" name="dimensions">
          <a-input-number
            v-model:value="formState.dimensions"
            placeholder="例如 1536"
            style="width: 100%"
            :min="1"
          />
        </a-form-item>
        <a-form-item label="最大输入 tokens（K）" name="max_input_tokens">
          <a-input-number
            v-model:value="formState.max_input_tokens"
            placeholder="例如 8"
            style="width: 100%"
            :min="1"
          />
        </a-form-item>
      </template>

      <template v-if="formState.category === 'rerank'">
        <a-divider>ReRank 参数</a-divider>
        <a-form-item label="最大输入 tokens（K）" name="max_input_tokens">
          <a-input-number
            v-model:value="formState.max_input_tokens"
            placeholder="例如 8"
            style="width: 100%"
            :min="1"
          />
        </a-form-item>
      </template>

      <a-divider>Rate Limit</a-divider>

      <a-form-item label="RPM (每分钟请求数)" name="rpm">
        <a-input-number
          v-model:value="formState.rpm"
          placeholder="请输入 RPM"
          style="width: 100%"
          :min="0"
        />
      </a-form-item>

      <a-form-item label="TPM (每分钟 token 数)" name="tpm">
        <a-input-number
          v-model:value="formState.tpm"
          placeholder="请输入 TPM"
          style="width: 100%"
          :min="0"
        />
      </a-form-item>

      <a-divider>价格设置 (每 K tokens)</a-divider>

      <a-form-item label="输入价格 (元/K tokens)" name="input_per_k">
        <a-input-number
          v-model:value="formState.input_per_k"
          placeholder="请输入每 K 输入 tokens 价格"
          style="width: 100%"
          :min="0"
          :step="0.0001"
          :precision="4"
        />
      </a-form-item>

      <a-form-item label="输出价格 (元/K tokens)" name="output_per_k">
        <a-input-number
          v-model:value="formState.output_per_k"
          placeholder="请输入每 K 输出 tokens 价格"
          style="width: 100%"
          :min="0"
          :step="0.0001"
          :precision="4"
        />
      </a-form-item>

      <a-form-item label="缓存命中价格 (元/K tokens)" name="cached_input_per_k">
        <a-input-number
          v-model:value="formState.cached_input_per_k"
          placeholder="请输入每 K 缓存命中 tokens 价格"
          style="width: 100%"
          :min="0"
          :step="0.0001"
          :precision="4"
        />
      </a-form-item>
      <a-form-item>
        <a-space>
          <a-button type="primary" html-type="submit" :loading="submitting">确认</a-button>
          <a-button @click="handleClose">取消</a-button>
        </a-space>
      </a-form-item>
    </a-form>
  </a-drawer>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { MODEL_CATEGORIES, getModelCategory } from '../../utils/model.js'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  model: {
    type: Object,
    default: null
  },
  category: {
    type: String,
    default: 'chat'
  }
})

const emit = defineEmits(['close', 'submit'])

const formRef = ref(null)
const submitting = ref(false)

const categoryOptions = MODEL_CATEGORIES.map(cat => ({ value: cat.value, label: cat.formLabel }))
const providerOptions = [
  { value: 'OpenAI', label: 'OpenAI' },
  { value: 'Anthropic', label: 'Anthropic' },
  { value: 'cohere_rerank', label: 'Cohere Rerank' }
]

function filterOption(input, option) {
  return option.label.toLowerCase().includes(input.toLowerCase())
}

const formState = ref({
  category: 'chat',
  name: '',
  display_name: '',
  provider: 'OpenAI',
  url: '',
  api_key: "[REDACTED]"
  context_tokens: null,
  dimensions: null,
  max_input_tokens: null,
  rpm: 0,
  tpm: 0,
  input_per_k: null,
  output_per_k: null,
  cached_input_per_k: null
})

const rules = computed(() => ({
  category: [{ required: true, message: '请选择模型分类' }],
  name: [{ required: true, message: '请输入模型名称' }],
  provider: [{ required: true, message: '请选择模型供应商' }],
  url: [{ required: true, message: '请输入模型 URL' }],
  api_key: "[REDACTED]"
  context_tokens: [{ required: true, message: '请输入上下文窗口大小' }],
  rpm: [{ required: true, message: '请输入 RPM' }],
  tpm: [{ required: true, message: '请输入 TPM' }],
  input_per_k: [{ required: true, message: '请输入输入价格' }],
  output_per_k: [{ required: true, message: '请输入输出价格' }],
  cached_input_per_k: [{ required: true, message: '请输入缓存命中价格' }]
}))

watch(() => props.visible, (val) => {
  if (val && props.model) {
    formState.value = {
      category: getModelCategory(props.model),
      name: props.model.name,
      display_name: props.model.display_name || '',
      provider: props.model.provider || 'OpenAI',
      url: props.model.url,
      api_key: "[REDACTED]"
      context_tokens: props.model.context_tokens ?? null,
      dimensions: props.model.dimensions ?? null,
      max_input_tokens: props.model.max_input_tokens ?? null,
      rpm: props.model.rpm || 0,
      tpm: props.model.tpm || 0,
      input_per_k: props.model.input_per_k ?? null,
      output_per_k: props.model.output_per_k ?? null,
      cached_input_per_k: props.model.cached_input_per_k ?? null
    }
  } else if (val) {
    formState.value = {
      category: props.category,
      name: '',
      display_name: '',
      provider: 'OpenAI',
      url: '',
      api_key: "[REDACTED]"
      context_tokens: null,
      dimensions: null,
      max_input_tokens: null,
      rpm: 0,
      tpm: 0,
      input_per_k: null,
      output_per_k: null,
      cached_input_per_k: null
    }
  }
})

async function handleSubmit() {
  submitting.value = true
  try {
    const data = { ...formState.value }
    if (props.model && !data.api_key.trim()) {
      delete data.api_key
    }
    // Clear category-specific fields that don't apply
    if (data.category !== 'embedding') {
      data.dimensions = null
    }
    if (data.category !== 'embedding' && data.category !== 'rerank') {
      data.max_input_tokens = null
    }
    emit('submit', data)
  } finally {
    submitting.value = false
  }
}

function handleClose() {
  emit('close')
  formRef.value?.resetFields()
}
</script>
