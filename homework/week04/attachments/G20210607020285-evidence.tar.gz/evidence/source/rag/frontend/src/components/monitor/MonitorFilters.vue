<template>
  <div class="monitor-filters">
    <div v-if="scope !== 'all_monthly'" class="filter-item">
      <span class="filter-label">用户</span>
      <a-select
        :value="filters.user_email"
        :options="userOptions"
        :disabled="!options.is_admin"
        style="width: 220px"
        show-search
        @change="(v) => patch({ user_email: v })"
      />
    </div>
    <div class="filter-item">
      <span class="filter-label">模型</span>
      <a-select
        :value="filters.models"
        :options="modelOptions"
        mode="multiple"
        allow-clear
        placeholder="全部模型（默认）"
        :max-tag-count="2"
        style="min-width: 260px; max-width: 420px"
        @change="(v) => patch({ models: v || [] })"
      />
    </div>
    <div v-if="scope === 'user_daily'" class="filter-item">
      <span class="filter-label">月份</span>
      <a-date-picker
        picker="month"
        :value="monthValue"
        :allow-clear="false"
        :disabled-date="disabledMonth"
        @change="onMonthChange"
      />
    </div>
    <div v-else class="filter-item">
      <span class="filter-label">年份</span>
      <a-date-picker
        picker="year"
        :value="yearValue"
        :allow-clear="false"
        :disabled-date="disabledYear"
        @change="onYearChange"
      />
    </div>
    <a-button type="primary" shape="round" class="query-btn" :loading="loading" @click="$emit('query')">
      查询
    </a-button>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import dayjs from 'dayjs'
import customParseFormat from 'dayjs/plugin/customParseFormat'

dayjs.extend(customParseFormat)

// 015-resource-consumption-monitor T013：筛选器
// 决策7/12/13：默认当前用户/全部模型/当前月年；模型清空即全选；选择器禁选未来期间
const props = defineProps({
  scope: { type: String, required: true },
  filters: { type: Object, required: true },
  options: { type: Object, default: () => ({ user_emails: [], models: [], is_admin: false }) },
  loading: { type: Boolean, default: false },
})
const emit = defineEmits(['update:filters', 'query'])

function patch(partial) {
  emit('update:filters', { ...props.filters, ...partial })
}

const userOptions = computed(() => props.options.user_emails.map((e) => ({ label: e, value: e })))
const modelOptions = computed(() => props.options.models.map((m) => ({ label: m, value: m })))

const monthValue = computed(() => (props.filters.month ? dayjs(props.filters.month, 'YYYY-MM') : null))
const yearValue = computed(() => (props.filters.year ? dayjs(String(props.filters.year), 'YYYY') : null))

// 禁选未来月/年（决策13）
function disabledMonth(current) {
  return current && current.isAfter(dayjs(), 'month')
}
function disabledYear(current) {
  return current && current.isAfter(dayjs(), 'year')
}

function onMonthChange(v) {
  if (v) patch({ month: v.format('YYYY-MM') })
}
function onYearChange(v) {
  if (v) patch({ year: v.year() })
}
</script>

<style scoped>
.monitor-filters {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}
.filter-item {
  display: flex;
  align-items: center;
  gap: 8px;
}
.filter-label {
  color: #5a6478;
  font-size: 13px;
  font-weight: 600;
  white-space: nowrap;
}
/* 关键操作品牌蓝胶囊按钮（全站视觉语言） */
.query-btn {
  min-width: 88px;
  font-weight: 600;
  background: linear-gradient(135deg, #1677ff, #4096ff);
  border: none;
  box-shadow: 0 2px 8px rgba(22, 119, 255, 0.35);
}
.query-btn:hover {
  background: linear-gradient(135deg, #0958d9, #1677ff);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.45);
}
</style>