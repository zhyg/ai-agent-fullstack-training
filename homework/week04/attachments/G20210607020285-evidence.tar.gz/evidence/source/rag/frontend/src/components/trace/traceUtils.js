// 轨迹构树与格式化工具（T046，移植自 TraceViewer/src/api.ts，纯 JS 无新增依赖）

/**
 * CHILD_OF 构树 + DFS 展开为带 depth/relativeStart 的扁平列表（时间单位微秒）。
 * @param {Array} spans Jaeger UI 格式 spans
 * @param {Object} processes processID → {serviceName, tags}
 */
export function buildSpanTree(spans, processes) {
  const spanMap = new Map()
  const childrenMap = new Map()
  let rootSpanID = null

  for (const span of spans) {
    spanMap.set(span.spanID, span)
    const parentRef = (span.references || []).find(r => r.refType === 'CHILD_OF')
    if (parentRef) {
      const children = childrenMap.get(parentRef.spanID) || []
      children.push(span.spanID)
      childrenMap.set(parentRef.spanID, children)
    } else {
      rootSpanID = span.spanID
    }
  }

  if (!rootSpanID && spans.length > 0) {
    rootSpanID = spans[0].spanID
  }

  const traceStart = Math.min(...spans.map(s => s.startTime))

  function getServiceName(span) {
    if (span.process?.serviceName) return span.process.serviceName
    if (span.processID && processes[span.processID]?.serviceName) {
      return processes[span.processID].serviceName
    }
    return 'unknown'
  }

  const result = []
  function dfs(spanID, depth) {
    const span = spanMap.get(spanID)
    if (!span) return
    result.push({
      ...span,
      depth,
      serviceName: getServiceName(span),
      relativeStart: span.startTime - traceStart
    })
    const children = childrenMap.get(spanID) || []
    children.sort((a, b) => {
      const sa = spanMap.get(a)
      const sb = spanMap.get(b)
      return (sa?.startTime || 0) - (sb?.startTime || 0)
    })
    for (const childID of children) {
      dfs(childID, depth + 1)
    }
  }

  if (rootSpanID) dfs(rootSpanID, 0)
  return result
}

export function formatDuration(microseconds) {
  if (microseconds < 1000) return `${microseconds}μs`
  if (microseconds < 1000000) return `${(microseconds / 1000).toFixed(2)}ms`
  return `${(microseconds / 1000000).toFixed(2)}s`
}

export function formatTimestamp(microseconds) {
  const ms = Math.floor(microseconds / 1000)
  const date = new Date(ms)
  const pad = (n, len = 2) => String(n).padStart(len, '0')
  const y = date.getFullYear()
  const mo = pad(date.getMonth() + 1)
  const d = pad(date.getDate())
  const h = pad(date.getHours())
  const mi = pad(date.getMinutes())
  const s = pad(date.getSeconds())
  const msStr = pad(ms % 1000, 3)
  return `${y}-${mo}-${d} ${h}:${mi}:${s}.${msStr}`
}