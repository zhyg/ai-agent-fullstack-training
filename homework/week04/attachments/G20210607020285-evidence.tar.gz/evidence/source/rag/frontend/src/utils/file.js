/**
 * Format file size in bytes to human-readable string.
 * @param {number} bytes - File size in bytes
 * @returns {string} Formatted size string (e.g., "1.5 MB")
 */
export function formatFileSize(bytes) {
  if (bytes === null || bytes === undefined || bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const k = 1024
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  const size = (bytes / Math.pow(k, i)).toFixed(i === 0 ? 0 : 2)
  return `${size} ${units[i]}`
}

/**
 * Determine the renderer type based on file extension.
 * @param {string} extension - File extension without dot (e.g., 'docx', 'pdf')
 * @returns {string} Renderer type identifier
 */
export function getRendererType(extension) {
  if (!extension) return 'text'
  const ext = extension.toLowerCase()

  // Images
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'avif'].includes(ext)) {
    return 'image'
  }

  // Markdown
  if (['md', 'markdown'].includes(ext)) return 'markdown'

  // Office documents
  if (ext === 'docx' || ext === 'doc') return 'office-docx'
  if (ext === 'xlsx' || ext === 'xls') return 'office-excel'
  if (ext === 'pptx' || ext === 'ppt') return 'office-pptx'
  if (ext === 'pdf') return 'office-pdf'

  // Default: plain text
  return 'text'
}

/**
 * Check if a file extension represents a compressed archive.
 * @param {string} extension - File extension without dot
 * @returns {boolean} True if the file is a compressed archive
 */
export function isCompressedFile(extension) {
  if (!extension) return false
  const ext = extension.toLowerCase()
  return ['zip', 'rar', '7z', 'tar', 'gz', 'tgz'].includes(ext) ||
    ext.endsWith('.tar.gz')
}

/**
 * Check if a filename represents a compressed archive (handles compound extensions).
 * @param {string} filename - Full filename
 * @returns {boolean} True if the file is a compressed archive
 */
export function isCompressedFilename(filename) {
  if (!filename) return false
  const name = filename.toLowerCase()
  return name.endsWith('.zip') ||
    name.endsWith('.rar') ||
    name.endsWith('.7z') ||
    name.endsWith('.tar.gz') ||
    name.endsWith('.tgz')
}
