
<template>
  <div class="timeline-container">
    <!-- 列头 -->
    <div class="timeline-column-header">
      <div class="col-header-left">Service &amp; Operation</div>
      <div class="col-header-right">
        <div class="tick-labels">
          <span v-for="(t, i) in ticks" :key="i" class="tick-label">
            {{ formatDuration(Math.round(t)) }}
          </span>
        </div>
      </div>
    </div>

    <!-- Span 行 -->
    <div v-for="span in spans" :key="span.spanID" class="span-row-wrapper">
      <div
        class="span-row"
        :class="{ expanded: expandedSpanID === span.spanID }"
        @click="toggleExpand(span.spanID)"
      >
        <!-- 左侧 Span 名称 -->
        <div class="span-row-left">
          <span :style="{ width: span.depth * 18 + 'px' }" class="indent" />
          <span class="expand-icon">
            <DownOutlined v-if="expandedSpanID === span.spanID" />
            <RightOutlined v-else />
          </span>
          <a-typography-text type="secondary" class="span-service">{{ span.serviceName }}</a-typography-text>
          <span class="span-sep">:</span>
          <a-typography-text class="span-operation">{{ span.operationName }}</a-typography-text>
        </div>

        <!-- 右侧甘特图 -->
        <div class="span-row-right">
          <div v-for="(_, i) in ticks" :key="i" class="grid-line" :style="{ left: `${(i / TICK_COUNT) * 100}%` }" />
          <div
            class="gantt-bar"
            :style="getBarStyle(span)"
            :title="`${span.operationName} - ${formatDuration(span.duration)}`"
          />
        </div>
      </div>

      <!-- 展开详情 -->
      <div v-if="expandedSpanID === span.spanID" class="span-detail-row">
        <SpanDetail :span="span" :trace-start="traceStart" />
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ref, computed } from 'vue'
import { RightOutlined, DownOutlined } from '@ant-design/icons-vue'
import type { FlatSpan, SpanTag } from '../types'
import { formatDuration } from '../api'
import SpanDetail from './SpanDetail.vue'

const props = defineProps<{ spans: FlatSpan[] }>()

const expandedSpanID = ref<string | null>(null)

const traceStart = computed(() => Math.min(...props.spans.map(s => s.startTime)))
const traceDuration = computed(() => {
  const maxEnd = Math.max(...props.spans.map(s => s.relativeStart + s.duration))
  return maxEnd || 1
})

const TICK_COUNT = 5
const ticks = computed(() =>
  Array.from({ length: TICK_COUNT + 1 }, (_, i) => (traceDuration.value / TICK_COUNT) * i)
)

const SERVICE_COLORS = ['#165dff', '#f53f3f', '#00b42a', '#ff7d00', '#722ed1',
  '#0fc6c2', '#f77234', '#86909c', '#eb2f96', '#3491fa']

function getServiceColor(serviceName: string): string {
  const services = [...new Set(props.spans.map(s => s.serviceName))]
  const idx = services.indexOf(serviceName)
  return SERVICE_COLORS[idx % SERVICE_COLORS.length]
}

function getBarStyle(span: FlatSpan) {
  const left = (span.relativeStart / traceDuration.value) * 100
  const width = Math.max((span.duration / traceDuration.value) * 100, 0.3)
  return {
    left: `${left}%`,
    width: `${width}%`,
    backgroundColor: getServiceColor(span.serviceName),
  }
}

function toggleExpand(spanID: string) {
  expandedSpanID.value = expandedSpanID.value === spanID ? null : spanID
}
</script>

<style scoped>
.timeline-container {
  border-top: 1px solid #f0f0f0;
}

.timeline-column-header {
  display: flex;
  height: 36px;
  background: #fafafa;
  border-bottom: 1px solid #f0f0f0;
  align-items: center;
}

.col-header-left {
  width: 35%;
  min-width: 260px;
  padding: 0 16px;
  font-size: 12px;
  font-weight: 600;
  color: #86909c;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  border-right: 1px solid #f0f0f0;
}

.col-header-right {
  flex: 1;
  position: relative;
  padding: 0 8px;
}

.tick-labels {
  display: flex;
  justify-content: space-between;
  width: 100%;
}

.tick-label {
  font-size: 11px;
  color: #c0c4cc;
  font-family: 'JetBrains Mono', 'SF Mono', monospace;
}

.span-row-wrapper {
  border-bottom: 1px solid #f5f5f5;
}

.span-row {
  display: flex;
  height: 40px;
  cursor: pointer;
  transition: background 0.15s;
  align-items: center;
}

.span-row:hover {
  background: #f7f8fa;
}

.span-row.expanded {
  background: #f2f3f5;
}

.span-row-left {
  width: 35%;
  min-width: 260px;
  display: flex;
  align-items: center;
  padding: 0 12px;
  gap: 6px;
  border-right: 1px solid #f0f0f0;
  overflow: hidden;
  white-space: nowrap;
}

.indent {
  flex-shrink: 0;
  display: inline-block;
}

.expand-icon {
  font-size: 10px;
  color: #86909c;
  flex-shrink: 0;
  width: 14px;
  text-align: center;
}

.span-service {
  font-size: 12px;
  flex-shrink: 0;
}

.span-sep {
  color: #c9cdd4;
  font-size: 12px;
}

.span-operation {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
}

.span-row-right {
  flex: 1;
  position: relative;
  height: 100%;
  display: flex;
  align-items: center;
}

.grid-line {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: #f5f5f5;
}

.gantt-bar {
  position: absolute;
  height: 18px;
  border-radius: 3px;
  min-width: 3px;
  opacity: 0.85;
  transition: opacity 0.15s, box-shadow 0.15s;
}

.span-row:hover .gantt-bar {
  opacity: 1;
  box-shadow: 0 2px 8px rgba(22, 93, 255, 0.2);
}

.span-detail-row {
  background: #fafafa;
  border-top: 1px solid #f0f0f0;
  border-bottom: 1px solid #f0f0f0;
  padding: 16px 24px;
}
</style>
