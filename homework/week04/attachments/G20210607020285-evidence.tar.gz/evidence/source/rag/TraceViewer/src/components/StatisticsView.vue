

<template>
  <div class="statistics-view">
    <a-table
      :columns="columns"
      :data-source="stats"
      :pagination="false"
      size="middle"
      row-key="service"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'percentage'">
          <a-progress
            :percent="Number(record.percentage)"
            :show-info="false"
            :stroke-color="'#165dff'"
            size="small"
            style="display: inline-flex; width: 120px; margin-right: 8px"
          />
          <span>{{ record.percentage }}%</span>
        </template>
      </template>
    </a-table>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import type { FlatSpan } from '../types'
import { formatDuration } from '../api'

const props = defineProps<{ spans: FlatSpan[] }>()

interface ServiceStat {
  service: string
  spanCount: number
  totalDuration: number
  percentage: string
}

const columns = [
  { title: 'Service', dataIndex: 'service', key: 'service' },
  { title: 'Spans', dataIndex: 'spanCount', key: 'spanCount', width: 80 },
  { title: 'Total Duration', dataIndex: 'totalDurationText', key: 'duration', width: 150 },
  { title: 'Percentage', dataIndex: 'percentage', key: 'percentage', width: 200 },
]

const stats = computed<ServiceStat[]>(() => {
  const map = new Map<string, { count: number; totalDuration: number }>()
  for (const span of props.spans) {
    const stat = map.get(span.serviceName) || { count: 0, totalDuration: 0 }
    stat.count++
    stat.totalDuration += span.duration
    map.set(span.serviceName, stat)
  }

  const total = Array.from(map.values()).reduce((a, b) => a + b.totalDuration, 0)

  return Array.from(map.entries()).map(([service, stat]) => ({
    service,
    spanCount: stat.count,
    totalDuration: stat.totalDuration,
    totalDurationText: formatDuration(stat.totalDuration),
    percentage: total > 0 ? ((stat.totalDuration / total) * 100).toFixed(1) : '0',
  }))
})
</script>
<style scoped>
.statistics-view {
  padding: 24px;
}
</style>
