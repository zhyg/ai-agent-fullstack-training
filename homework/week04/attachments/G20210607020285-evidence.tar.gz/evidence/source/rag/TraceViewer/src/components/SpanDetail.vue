

<template>
  <div class="span-detail">
    <div class="detail-header">
      <a-typography-title :level="5" style="margin: 0">{{ span.operationName }}</a-typography-title>
      <a-space>
        <a-typography-text code>{{ span.spanID }}</a-typography-text>
        <a-button type="text" size="small" @click.stop="copySpanID">
          <template #icon><CopyOutlined /></template>
        </a-button>
      </a-space>
    </div>

    <a-descriptions size="small" :column="4" style="margin: 12px 0">
      <a-descriptions-item label="Service">{{ span.serviceName }}</a-descriptions-item>
      <a-descriptions-item label="Duration">
        <a-typography-text strong>{{ formatDuration(span.duration) }}</a-typography-text>
      </a-descriptions-item>
      <a-descriptions-item label="Start Time">{{ formatDuration(relativeStart()) }}</a-descriptions-item>
    </a-descriptions>

    <a-collapse :default-active-key="['tags']" ghost>
      <!-- Tags -->
      <a-collapse-panel v-if="span.tags?.length" key="tags" :header="`Tags (${span.tags.length})`">
        <a-table
          :columns="tagColumns"
          :data-source="span.tags.map(t => ({ key: t.key, value: formatTagValue(t.value) }))"
          size="small"
          :pagination="false"
          bordered
        />
      </a-collapse-panel>

      <!-- Process -->
      <a-collapse-panel v-if="span.process?.tags?.length" key="process" :header="`Process (${span.process.tags.length})`">
        <a-table
          :columns="tagColumns"
          :data-source="span.process.tags.map(t => ({ key: t.key, value: formatTagValue(t.value) }))"
          size="small"
          :pagination="false"
          bordered
        />
      </a-collapse-panel>

      <!-- Logs -->
      <a-collapse-panel v-if="span.logs?.length" key="logs" :header="`Logs (${span.logs.length})`">
        <div v-for="(log, i) in span.logs" :key="i" class="log-entry">
          <a-typography-text type="secondary" class="log-timestamp">
            {{ formatDuration(log.timestamp - traceStart) }}
          </a-typography-text>
          <a-table
            :columns="tagColumns"
            :data-source="log.fields.map(f => ({ key: f.key, value: formatTagValue(f.value) }))"
            size="small"
            :pagination="false"
            bordered
            style="margin-top: 4px"
          />
        </div>
      </a-collapse-panel>
    </a-collapse>
  </div>
</template>
<script setup lang="ts">
import type { FlatSpan } from '../types'
import { formatDuration } from '../api'
import { CopyOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'

const props = defineProps<{
  span: FlatSpan
  traceStart: number
}>()

const relativeStart = () => props.span.startTime - props.traceStart

const tagColumns = [
  { title: 'Key', dataIndex: 'key', key: 'key', width: 220, className: 'tag-key-col' },
  { title: 'Value', dataIndex: 'value', key: 'value', ellipsis: true },
]

function formatTagValue(val: string | number | boolean): string {
  return String(val)
}

async function copySpanID() {
  try {
    await navigator.clipboard.writeText(props.span.spanID)
    message.success('SpanID copied')
  } catch {
    message.error('Copy failed')
  }
}
</script>
<style scoped>
.span-detail {
  padding: 4px 0;
}

.detail-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.log-entry {
  margin-bottom: 12px;
}

.log-timestamp {
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px;
}

:deep(.tag-key-col) {
  font-family: 'JetBrains Mono', monospace;
  color: #165dff;
  font-weight: 500;
}

:deep(.ant-collapse-header) {
  font-weight: 600 !important;
  padding: 8px 0 !important;
}

:deep(.ant-collapse-content-box) {
  padding: 0 !important;
}
</style>
