import type { JaegerApiResponse, RawSpan, FlatSpan, SpanProcess } from './types'

export async function fetchTrace(): Promise<{ spans: RawSpan[]; processes: Record<string, SpanProcess> }> {
  const res = await fetch('/trace-data.json')
  if (!res.ok) throw new Error(`Failed to load trace data: ${res.status}`)
  const json: JaegerApiResponse = await res.json()
  if (!json.data || json.data.length === 0) throw new Error('Trace not found')
  return { spans: json.data[0].spans, processes: json.data[0].processes || {} }
}

export function buildSpanTree(spans: RawSpan[], processes: Record<string, SpanProcess>): FlatSpan[] {
  const spanMap = new Map<string, RawSpan>()
  const childrenMap = new Map<string, string[]>()
  let rootSpanID: string | null = null

  for (const span of spans) {
    spanMap.set(span.spanID, span)
    const parentRef = span.references.find(r => r.refType === 'CHILD_OF')
    if (parentRef) {
      const children = childrenMap.get(parentRef.spanID) || []
      children.push(span.spanID)
      childrenMap.set(parentRef.spanID, children)
    } else {
      rootSpanID = span.spanID
    }
  }

  if (!rootSpanID && spans.length > 0) {
    rootSpanID = spans[0].spanID
  }

  const traceStart = Math.min(...spans.map(s => s.startTime))

  function getServiceName(span: RawSpan): string {
    if (span.process?.serviceName) return span.process.serviceName
    if (span.processID && processes[span.processID]?.serviceName) {
      return processes[span.processID].serviceName
    }
    return 'unknown'
  }

  const result: FlatSpan[] = []
  function dfs(spanID: string, depth: number) {
    const span = spanMap.get(spanID)
    if (!span) return
    result.push({
      ...span,
      depth,
      serviceName: getServiceName(span),
      relativeStart: span.startTime - traceStart,
    })
    const children = childrenMap.get(spanID) || []
    children.sort((a, b) => {
      const sa = spanMap.get(a)
      const sb = spanMap.get(b)
      return (sa?.startTime || 0) - (sb?.startTime || 0)
    })
    for (const childID of children) {
      dfs(childID, depth + 1)
    }
  }

  if (rootSpanID) dfs(rootSpanID, 0)
  return result
}

export function formatDuration(microseconds: number): string {
  if (microseconds < 1000) return `${microseconds}μs`
  if (microseconds < 1_000_000) return `${(microseconds / 1000).toFixed(2)}ms`
  return `${(microseconds / 1_000_000).toFixed(2)}s`
}

export function formatTimestamp(microseconds: number): string {
  const ms = Math.floor(microseconds / 1000)
  const date = new Date(ms)
  const pad = (n: number, len = 2) => String(n).padStart(len, '0')
  const y = date.getFullYear()
  const mo = pad(date.getMonth() + 1)
  const d = pad(date.getDate())
  const h = pad(date.getHours())
  const mi = pad(date.getMinutes())
  const s = pad(date.getSeconds())
  const msStr = pad(ms % 1000, 3)
  return `${y}-${mo}-${d} ${h}:${mi}:${s}.${msStr}`
}
