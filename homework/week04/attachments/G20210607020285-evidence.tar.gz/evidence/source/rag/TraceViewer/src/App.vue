<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { SearchOutlined } from '@ant-design/icons-vue'
import type { FlatSpan } from './types'
import { fetchTrace, buildSpanTree, formatDuration, formatTimestamp } from './api'
import TraceTimeline from './components/TraceTimeline.vue'

const spans = ref<FlatSpan[]>([])
const traceID = ref('')
const loading = ref(false)
const error = ref<string | null>(null)
const filterText = ref('')

const filteredSpans = computed(() => {
  if (!filterText.value) return spans.value
  const keyword = filterText.value.toLowerCase()
  return spans.value.filter(s =>
    s.operationName.toLowerCase().includes(keyword) ||
    s.serviceName.toLowerCase().includes(keyword)
  )
})

const traceInfo = computed(() => {
  if (spans.value.length === 0) return null
  const root = spans.value[0]
  const duration = Math.max(...spans.value.map(s => s.relativeStart + s.duration))
  const services = new Set(spans.value.map(s => s.serviceName)).size
  const depth = Math.max(...spans.value.map(s => s.depth)) + 1
  return {
    serviceName: root.serviceName,
    operationName: root.operationName,
    startTime: formatTimestamp(root.startTime),
    duration: formatDuration(duration),
    services,
    depth,
    totalSpans: spans.value.length,
    traceIDShort: traceID.value.slice(0, 7),
  }
})

async function loadTrace() {
  loading.value = true
  error.value = null
  spans.value = []
  try {
    const { spans: rawSpans, processes } = await fetchTrace()
    traceID.value = rawSpans[0]?.traceID || ''
    spans.value = buildSpanTree(rawSpans, processes)
  } catch (err) {
    error.value = err instanceof Error ? err.message : 'Unknown error'
  } finally {
    loading.value = false
  }
}

onMounted(loadTrace)
</script>

<template>
  <a-layout class="app-layout">

    <!-- 错误提示 -->
    <a-alert v-if="error" type="error" :message="error" show-icon closable style="margin: 16px" />

    <!-- 加载中 -->
    <div v-if="loading" class="loading-wrapper">
      <a-spin size="large" tip="Loading trace data..." />
    </div>

    <!-- Trace 摘要头部 -->
    <div v-if="!loading && traceInfo" class="trace-header">
      <div class="trace-header-left">
        <h2 class="trace-title">
          <a-typography-text type="secondary">{{ traceInfo.serviceName }}</a-typography-text>
          <span class="trace-sep"> : </span>
          <span>{{ traceInfo.operationName }}</span>
        </h2>
        <a-tag>{{ traceInfo.traceIDShort }}</a-tag>
      </div>
      <a-descriptions :column="7" size="small" layout="horizontal" class="trace-stats">
        <a-descriptions-item label="Trace Start" :span="3">
          <span style="white-space: nowrap">{{ traceInfo.startTime }}</span>
        </a-descriptions-item>
        <a-descriptions-item label="Duration">
          <a-typography-text strong>{{ traceInfo.duration }}</a-typography-text>
        </a-descriptions-item>
        <a-descriptions-item label="Depth">{{ traceInfo.depth }}</a-descriptions-item>
        <a-descriptions-item label="Total Spans">
          <a-typography-text strong>{{ traceInfo.totalSpans }}</a-typography-text>
        </a-descriptions-item>
      </a-descriptions>
    </div>

    <!-- 主内容区 -->
    <a-layout-content v-if="!loading && spans.length > 0" class="app-content">
      <TraceTimeline :spans="filteredSpans" />
    </a-layout-content>

    <!-- 空状态 -->
    <a-empty v-if="!loading && spans.length === 0 && !error" description="No trace data loaded" class="empty-state" />
  </a-layout>
</template>

<style>
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.app-layout {
  min-height: 100vh;
  background: #f5f5f5;
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  padding: 0 24px;
  height: 48px;
  line-height: 48px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  z-index: 10;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-title {
  font-size: 16px;
  font-weight: 700;
  color: #1d2129;
}

.header-right {
  display: flex;
  align-items: center;
}

.loading-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 120px 0;
}

.trace-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 24px;
  background: #fff;
  border-bottom: 1px solid #f0f0f0;
}

.trace-header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.trace-title {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
  color: #1d2129;
}

.trace-sep {
  color: #c9cdd4;
}

.trace-stats {
  flex: 1;
  max-width: 800px;
}


.app-content {
  padding: 0;
  background: #fff;
  margin: 0;
}

.empty-state {
  padding: 120px 0;
}
</style>
