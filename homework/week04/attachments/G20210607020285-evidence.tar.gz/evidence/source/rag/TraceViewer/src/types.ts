export interface SpanTag {
  key: string
  type: string
  value: string | number | boolean
}

export interface SpanLog {
  timestamp: number
  fields: SpanTag[]
}

export interface SpanReference {
  refType: string
  traceID: string
  spanID: string
}

export interface SpanProcess {
  serviceName: string
  tags: SpanTag[]
}

export interface RawSpan {
  traceID: string
  spanID: string
  operationName: string
  references: SpanReference[]
  startTime: number
  startTimeMillis: number
  duration: number
  tags: SpanTag[]
  logs: SpanLog[]
  processID: string
  process: SpanProcess
}

export interface TraceData {
  traceID: string
  spans: RawSpan[]
  processes: Record<string, SpanProcess>
}

export interface JaegerApiResponse {
  data: TraceData[]
  total: number
  limit: number
  offset: number
  errors: unknown[]
}

export interface FlatSpan extends RawSpan {
  depth: number
  serviceName: string
  relativeStart: number
}
