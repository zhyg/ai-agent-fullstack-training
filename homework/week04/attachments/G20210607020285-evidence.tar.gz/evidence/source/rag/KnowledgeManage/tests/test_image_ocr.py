import re
import unittest
from unittest.mock import patch

import httpx

from app.services import image_service


class ImageOcrTests(unittest.IsolatedAsyncioTestCase):
    async def test_ocr_requests_hybrid_table_analysis_and_removes_crop_references(self):
        table = (
            "<details>\n<summary>bar</summary>\n\n"
            "| Category | Score |\n| --- | --- |\n| Group 1 | 90 |\n"
            "</details>"
        )
        markdown = (
            "Results  \n![](images/crop.jpg)\n\n"
            "![crop](./images/inline.jpg)Caption\n\n"
            + table
            + "\n\n![source](https://example.test/images/source.jpg)"
        )

        async def parse(request):
            self.assertEqual(request.url.path, "/file_parse")
            body = await request.aread()
            fields = {
                name.decode(): value.decode()
                for name, value in re.findall(rb'name="([^"]+)"\r\n\r\n([^\r\n]+)', body)
            }
            self.assertEqual(fields, {
                "backend": "hybrid-engine",
                "effort": "high",
                "image_analysis": "true",
                "return_md": "true",
                "return_middle_json": "false",
                "return_images": "true",
                "formula_enable": "true",
                "table_enable": "true",
            })
            self.assertIn(b'name="files"; filename="table.png"', body)
            return httpx.Response(200, json={"results": {"table": {"md_content": markdown}}})

        client = httpx.AsyncClient(transport=httpx.MockTransport(parse))
        with patch.object(image_service.httpx, "AsyncClient", return_value=client):
            content = await image_service.process_image_ocr(b"image bytes", "table.png")

        self.assertEqual(
            content,
            "Results  \n\nCaption\n\n" + table + "\n\n![source](https://example.test/images/source.jpg)",
        )
