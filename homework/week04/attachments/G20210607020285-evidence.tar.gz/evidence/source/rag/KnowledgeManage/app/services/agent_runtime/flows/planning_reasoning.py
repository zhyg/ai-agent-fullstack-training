"""规划推理流程（FR-023/028，contracts/tool-runtime.md §5）：clarify→(plan_decision)*→answer.

- 澄清后进入决策循环：启用工具映射 OpenAI function calling 声明（未启用对模型不可见）；
- 每次决策调用计一轮（默认 100 范围 1–1000，一轮多工具不另计数，FR-028）；
- tool_calls 经 runtime 串行执行，结果以 {"role":"tool","tool_call_id":...} 回传继续决策；
- 无工具调用 → 答案生成（决策/工具消息作为 extra_messages 参与作答与预算核算）；
- 每次决策产生 agent.plan_decision span（带 agent.loop）；达上限强制收敛记 forced_convergence；
- 上下文累积/淘汰与推理行动一致（检索命中即累积，每轮 budget 核算，FR-019）。
"""
import json
import logging
import re
from typing import Any, TypedDict

from langgraph.graph import END, StateGraph

from app.services.agent_runtime import budget, citation, llm_client, steps, tracing
from app.services.agent_runtime.flows.quick_qa import _after_clarify, _clarify_node
from app.services.agent_runtime.flows.reasoning_action import NO_MATERIAL_TEXT, _record_convergence
from app.services.agent_runtime.state import RequestRuntimeState
from app.services.agent_runtime.tools import runtime as tool_runtime

logger = logging.getLogger(__name__)

PLANNING_PROTOCOL = (
    "\n\n工具使用协议：可先用 createPlan 制定计划并按规划逐步推进，随进展用 updatePlan 更新步骤状态；"
    "工具失败或结果为空会以 tool 消息回传，请分析原因后改写问题、更换工具或调整计划，不要重复相同的失败调用；"
    "已掌握足够信息、无需更多工具时，不要发起工具调用，仅输出一句简短说明表示将进入答案生成；"
    "不要提前给出最终答案，最终答案由答案生成阶段统一输出。"
    # 013 决策1（FR-015/016）：强制 function calling，禁止 content 计划标记；开标签拼接构造避免字面量冲突
    "计划与所有工具操作必须通过 function calling（tool_calls 字段）发起；"
    "严禁在 content 中输出 " + "<" + "createPlan>、<updatePlan>、<tool_call> 等计划/调用标记文本或 JSON 计划体；"
    "content 仅用于自然语言说明。"
)

# 013 决策2（R15）：两种不合规形态——XML 开标签 / tool_call 开标签后出现 createPlan/updatePlan
_PLAN_TEXT_RE = re.compile(
    re.escape("<" + "createPlan>") + "|" + re.escape("<" + "updatePlan>")
    + "|" + re.escape("<" + "tool_call>") + r"[\s\S]*?(createPlan|updatePlan)"
)

# 答案请求尾部指令：收敛说明可能已含答案文本，若以 assistant 消息收尾，
# 答案模型会认为已作答而只补引用标记；追加 user 指令强制重新完整作答
ANSWER_INSTRUCTION = (
    "请基于上下文片段与以上工具执行结果，按引用协议正式、完整地回答用户问题。"
    "此前助手的文字仅为过程说明，不是最终答案，请勿只补充引用标记。"
)


class FlowState(TypedDict, total=False):
    rt: RequestRuntimeState
    emit: Any
    result: dict
    converged: bool
    base_msg_count: int     # 初始消息数（system+历史），答案侧据此截取决策/工具消息


def _init_messages(rt: RequestRuntimeState) -> None:
    """planning 提示词+协议说明为 system；历史沿用会话消息（含本轮问题）."""
    prompt = rt.snapshot.prompts["planning"].content
    system = steps.render_prompt(prompt, question=rt.question, history=steps.history_text(rt))
    rt.messages_for_model = [{"role": "system", "content": system + PLANNING_PROTOCOL}]
    rt.messages_for_model += [
        {"role": m.get("role", "user"), "content": m.get("content", "")}
        for m in rt.history
    ]
    if not rt.history:
        rt.messages_for_model.append({"role": "user", "content": rt.question})


def _tool_call_message(message: dict) -> dict:
    """模型 assistant 消息原样入列（保留 tool_calls 供后续 tool 消息配对）."""
    out = {"role": "assistant", "content": message.get("content") or ""}
    if message.get("tool_calls"):
        out["tool_calls"] = message["tool_calls"]
    return out


async def _decision_node(s: FlowState) -> dict:
    rt = s["rt"]
    emit = s["emit"]
    steps.check_cancel(rt)
    # 达上限强制收敛（FR-028）：不再发起决策调用，携带已有上下文进入答案生成
    if rt.loop >= rt.snapshot.loop_count:
        _record_convergence(rt, tracing.EVENT_FORCED_CONVERGENCE, {"loop": rt.loop})
        return {"converged": True}
    rt.loop += 1  # 每次决策调用计一轮（一轮多工具不另计数）
    if not rt.messages_for_model:
        _init_messages(rt)
    base_count = len(rt.messages_for_model) if rt.loop == 1 else s.get("base_msg_count", 0)

    await steps.emit_step(emit, "plan_decision", "start", loop=rt.loop)
    span = tracing.get_tracer().start_span("agent.plan_decision")
    span.set_attribute(tracing.ATTR_LOOP, rt.loop)
    tracing.set_prompt_attrs(span, rt.snapshot.prompts["planning"], "planning")
    converged = False
    try:
        declarations = tool_runtime.build_tool_declarations(rt.snapshot.tools)
        result = await llm_client.chat_completion(
            rt.snapshot.analysis_model.name,
            rt.messages_for_model,
            max_output_tokens=rt.snapshot.max_output_tokens,
            tools=declarations or None,
            cancel_event=rt.cancel_event,
            span=span,
        )
        message = (result.get("choices") or [{}])[0].get("message", {}) or {}
        tool_calls = message.get("tool_calls") or []
        rt.messages_for_model.append(_tool_call_message(message))
        if not tool_calls:
            converged = True  # 无工具调用 → 答案生成
            content = message.get("content") or ""
            if _PLAN_TEXT_RE.search(content):
                # 013 决策2（FR-017）：计划写在 content 而非 tool_calls——仅观测警告，
                # 不做服务端解析/补救，收敛判定不变；双写 span + rt.events（同 _record_convergence 模式）
                detail = {"loop": rt.loop, "content_excerpt": content[:500]}
                tracing.add_event(span, tracing.EVENT_PLAN_TEXT_NOT_TOOL_CALL, detail)
                rt.events.append({"event": tracing.EVENT_PLAN_TEXT_NOT_TOOL_CALL, **detail})
        else:
            # 串行逐个执行（FR-030），每个执行前重复取消检查
            for call in tool_calls:
                steps.check_cancel(rt)
                call_id = call.get("id") or ""
                name = (call.get("function") or {}).get("name") or ""
                raw_args = (call.get("function") or {}).get("arguments") or "{}"
                try:
                    args = json.loads(raw_args)
                except (ValueError, TypeError):
                    args = raw_args  # 非法 JSON 入参：保留原始值，runtime 非 dict 拒绝→invalid_args 信封回传
                await steps.emit_step(emit, "tool", "start", loop=rt.loop, tool_name=name)
                tool_result = await tool_runtime.execute_tool(call_id, name, args, rt)
                await steps.emit_step(
                    emit, "tool", "end", loop=rt.loop, tool_name=name,
                    message=f"{name}：{tool_result.code}",
                )
                rt.messages_for_model.append(tool_result.to_model_message(call_id))
            # 每轮预算核算淘汰（FR-019）：决策/工具消息计入固定开销
            fixed = [
                rt.snapshot.prompts["answer"].content + citation.SOURCE_PROTOCOL,
                json.dumps(rt.messages_for_model, ensure_ascii=False),
            ]
            report = budget.enforce_budget(rt, fixed)
            if report["dropped_history"] or report["dropped_chunks"] or report["dropped_clarify_history"]:
                tracing.add_event(tracing.trace.get_current_span(), "context_evicted", report)
        return {"converged": converged, "base_msg_count": base_count}
    finally:
        span.end()
        await steps.emit_step(emit, "plan_decision", "end", loop=rt.loop)


def _after_decision(s: FlowState) -> str:
    return "answer" if s.get("converged") else "decision"


async def _answer_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    base = s.get("base_msg_count") or len(rt.messages_for_model)
    extra_messages = rt.messages_for_model[base:]
    has_tool_output = any(m.get("role") == "tool" for m in extra_messages)
    if not rt.chunks and not has_tool_output:
        # 无任何检索片段且无工具产出：无资料话术分支（FR-021 口径一致）
        meta: dict = {"terminate_reason": "empty_retrieval"}
        if rt.events:
            meta["events"] = rt.events
        return {"result": {"content": NO_MATERIAL_TEXT, "meta": meta}}
    answer_extra = list(extra_messages)
    if answer_extra:
        answer_extra.append({"role": "user", "content": ANSWER_INSTRUCTION})
    answer = await steps.stream_answer(rt, s["emit"], extra_messages=answer_extra or None)
    meta = {"references": answer["references"]}
    if answer.get("usage"):
        meta["usage"] = answer["usage"]
    if rt.events:
        meta["events"] = rt.events
    return {"result": {"content": answer["content"], "meta": meta}}


def _build_graph():
    graph = StateGraph(FlowState)
    graph.add_node("clarify", _clarify_node)
    graph.add_node("decision", _decision_node)
    graph.add_node("answer", _answer_node)
    graph.set_entry_point("clarify")
    # quick_qa 澄清分支返回 "rewrite" 键，这里映射到决策循环入口
    graph.add_conditional_edges("clarify", _after_clarify, {"rewrite": "decision", "end": END})
    graph.add_conditional_edges("decision", _after_decision, {"answer": "answer", "decision": "decision"})
    graph.add_edge("answer", END)
    return graph.compile()


_graph = _build_graph()


async def run_planning_reasoning(state: RequestRuntimeState, emit) -> dict:
    """执行决策循环流程，返回 {content, meta}；异常（取消/流程级）上抛由入口统一处理."""
    # 每轮 1 决策节点 + 澄清/答案；loop_count 最大 1000，需抬高默认 recursion_limit=25
    recursion_limit = state.snapshot.loop_count * 2 + 10
    final = await _graph.ainvoke(
        {"rt": state, "emit": emit}, config={"recursion_limit": recursion_limit},
    )
    return final.get("result") or {"content": "", "meta": {}}