"""共用步骤：clarify / rewrite / compress / answer（FR-006/007/010/016）.

- 提示词占位符用 replace 渲染（提示词含 JSON 花括号，不能用 str.format）；
- JSON 步骤提示词自动追加输出 Schema 与"只输出一个 JSON 对象"约束（FR-037）；
- 每步创建 agent.{step} span（输入/输出含完整提示词与原始输出，不脱敏）；
- answer 流式经 citation.RefStreamFilter 后处理产出 delta，references 先行下发。
"""
import json
import logging
from typing import List, Optional

from app.schemas.agent_runtime import (
    ClarifyResult,
    CompressResult,
    ReferencesEvent,
    RewriteResult,
    StepEvent,
    SufficiencyResult,
)
from app.services.agent_runtime import budget, citation, llm_client, tracing
from app.services.agent_runtime.llm_client import AgentCancelled
from app.services.agent_runtime.state import ContextChunk, RequestRuntimeState

logger = logging.getLogger(__name__)

JSON_OUTPUT_SUFFIX = "只输出一个 JSON 对象，不要输出任何其他文字或代码围栏。"


def check_cancel(state: RequestRuntimeState) -> None:
    """节点入口/步骤发起前取消检查点（FR-031，research.md R5）."""
    if state.cancel_event is not None and state.cancel_event.is_set():
        raise AgentCancelled()


def sse(event: dict) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"


async def emit_step(
    emit, step: str, status: str, *,
    loop: Optional[int] = None, tool_name: Optional[str] = None,
    message: Optional[str] = None,
) -> None:
    """步骤进度事件（不含中间原始输出，US5-5）."""
    event = StepEvent(step=step, status=status, loop=loop, tool_name=tool_name, message=message)
    await emit(sse(event.model_dump(exclude_none=True)))


def render_prompt(template: str, **values: str) -> str:
    for key, value in values.items():
        template = template.replace("{" + key + "}", value)
    return template


def history_text(state: RequestRuntimeState) -> str:
    lines = [
        f"{'用户' if m.get('role') == 'user' else '助手'}: {m.get('content', '')}"
        for m in state.history
    ]
    return "\n".join(lines) or "（无）"


def clarify_history_text(state: RequestRuntimeState) -> str:
    """澄清/重写专用历史（013 FR-009）：组装历史非 None 时渲染它，否则回退最近 10 轮.

    仅限 run_clarify/run_rewrite/工具 _rewrite_question 使用；
    stream_answer 与 planning _init_messages 恒用 history_text。
    """
    if state.clarify_history is None:
        return history_text(state)
    lines = [
        f"{'用户' if m.get('role') == 'user' else '助手'}: {m.get('content', '')}"
        for m in state.clarify_history
    ]
    return "\n".join(lines) or "（无）"


def _json_prompt(content: str, result_model) -> str:
    schema = json.dumps(result_model.model_json_schema(), ensure_ascii=False)
    return f"{content}\n\n输出 JSON Schema：\n{schema}\n{JSON_OUTPUT_SUFFIX}"


def _step_span(name: str, state: RequestRuntimeState):
    span = tracing.get_tracer().start_span(f"agent.{name}")
    if state.loop:
        span.set_attribute(tracing.ATTR_LOOP, state.loop)
    return span


async def run_clarify(state: RequestRuntimeState, emit) -> ClarifyResult:
    """澄清：判断问题是否清晰可独立检索（FR-006）；clear=false 由流程落库 reason 结束."""
    check_cancel(state)
    await emit_step(emit, "clarify", "start")
    span = _step_span("clarify", state)
    tracing.set_prompt_attrs(span, state.snapshot.prompts["clarify"], "clarify")
    try:
        prompt = state.snapshot.prompts["clarify"].content
        rendered = render_prompt(prompt, question=state.question, history=clarify_history_text(state))
        result = await llm_client.call_json(
            state.snapshot.analysis_model.name,
            [{"role": "user", "content": _json_prompt(rendered, ClarifyResult)}],
            ClarifyResult,
            purpose="clarify",
            max_output_tokens=state.snapshot.max_output_tokens,
            cancel_event=state.cancel_event,
            span=span,
        )
        tracing.set_output(span, result.model_dump())
        return result
    finally:
        span.end()
        await emit_step(emit, "clarify", "end")


async def run_rewrite(
    state: RequestRuntimeState, emit, *, question: Optional[str] = None,
) -> RewriteResult:
    """重写：改写为适合检索的独立问题（FR-007），结果写入 state.current_question.

    循环轮次（推理行动）可以 sufficiency 给出的 new_question 作为输入。
    """
    check_cancel(state)
    await emit_step(emit, "rewrite", "start", loop=state.loop or None)
    span = _step_span("rewrite", state)
    tracing.set_prompt_attrs(span, state.snapshot.prompts["rewrite"], "rewrite")
    try:
        prompt = state.snapshot.prompts["rewrite"].content
        rendered = render_prompt(prompt, question=question or state.question, history=clarify_history_text(state))
        result = await llm_client.call_json(
            state.snapshot.analysis_model.name,
            [{"role": "user", "content": _json_prompt(rendered, RewriteResult)}],
            RewriteResult,
            purpose="rewrite",
            max_output_tokens=state.snapshot.max_output_tokens,
            cancel_event=state.cancel_event,
            span=span,
        )
        state.current_question = result.rewritten_question
        tracing.set_output(span, result.model_dump())
        return result
    finally:
        span.end()
        await emit_step(emit, "rewrite", "end", loop=state.loop or None)


async def run_sufficiency(
    state: RequestRuntimeState, emit, *, last_question: Optional[str] = None,
) -> SufficiencyResult:
    """充足判断（FR-017，仅推理行动）：已累积上下文能否完整回答问题.

    不充足时 new_question 必填（schema 校验）；上下文取 state.chunks 累积片段。
    """
    check_cancel(state)
    await emit_step(emit, "sufficiency", "start", loop=state.loop or None)
    span = _step_span("sufficiency", state)
    tracing.set_prompt_attrs(span, state.snapshot.prompts["sufficiency"], "sufficiency")
    try:
        prompt = state.snapshot.prompts["sufficiency"].content
        context = "\n\n".join(
            f"[{i}] ({c.file_name}) {c.content}" for i, c in enumerate(state.chunks.values())
        ) or "（无）"
        rendered = render_prompt(
            prompt, question=state.question,
            last_question=last_question or state.current_question or state.question,
            context=context,
        )
        result = await llm_client.call_json(
            state.snapshot.analysis_model.name,
            [{"role": "user", "content": _json_prompt(rendered, SufficiencyResult)}],
            SufficiencyResult,
            purpose="sufficiency",
            max_output_tokens=state.snapshot.max_output_tokens,
            cancel_event=state.cancel_event,
            span=span,
        )
        tracing.set_output(span, result.model_dump())
        return result
    finally:
        span.end()
        await emit_step(emit, "sufficiency", "end", loop=state.loop or None)


async def run_compress(
    state: RequestRuntimeState,
    chunks: List[ContextChunk],
    emit,
    *,
    question: Optional[str] = None,
) -> List[ContextChunk]:
    """压缩：筛选有用片段（FR-010）；kept_indexes 越界/重复/非整数业务重试，空数组合法."""
    check_cancel(state)
    if not chunks:
        return []
    await emit_step(emit, "compress", "start", loop=state.loop or None)
    span = _step_span("compress", state)
    tracing.set_prompt_attrs(span, state.snapshot.prompts["compress"], "compress")
    try:
        prompt = state.snapshot.prompts["compress"].content
        chunks_text = "\n\n".join(
            f"[{i}] ({c.file_name}) {c.content}" for i, c in enumerate(chunks)
        )
        rendered = render_prompt(
            prompt, question=question or state.current_question or state.question, chunks=chunks_text,
        )
        result = await llm_client.call_json(
            state.snapshot.analysis_model.name,
            [{"role": "user", "content": _json_prompt(rendered, CompressResult)}],
            CompressResult,
            purpose="compress",
            max_output_tokens=state.snapshot.max_output_tokens,
            extra_validator=lambda r: r.validate_bounds(len(chunks)),
            cancel_event=state.cancel_event,
            span=span,
        )
        kept = [chunks[i] for i in result.kept_indexes]
        tracing.set_output(span, {
            "kept_indexes": result.kept_indexes,
            "kept_chunk_ids": [c.chunk_id for c in kept],
        })
        return kept
    finally:
        span.end()
        await emit_step(emit, "compress", "end", loop=state.loop or None)


async def stream_answer(
    state: RequestRuntimeState, emit, *, extra_messages: Optional[List[dict]] = None,
) -> dict:
    """答案生成（FR-013/016）：预算裁剪→句柄分配→references 下发→流式 ref 过滤.

    上下文取 state.chunks（流程侧已并入保留片段）；返回 {content, usage, references}。
    extra_messages：规划推理的决策/工具结果消息（计入预算固定开销，追加在历史之后）。
    部分答案累积于 state.partial_answer（停止时落库）。
    """
    check_cancel(state)
    await emit_step(emit, "answer", "start", loop=state.loop or None)
    span = _step_span("answer", state)
    tracing.set_prompt_attrs(span, state.snapshot.prompts["answer"], "answer")
    try:
        prompt = state.snapshot.prompts["answer"].content
        # 预算核算：系统提示词+引用协议（+决策/工具消息）为固定开销，历史+片段就地裁剪（FR-019）
        fixed = [prompt + citation.SOURCE_PROTOCOL]
        if extra_messages:
            fixed.append(json.dumps(extra_messages, ensure_ascii=False))
        report = budget.enforce_budget(state, fixed)
        if report["dropped_history"] or report["dropped_chunks"] or report["dropped_clarify_history"]:
            tracing.add_event(span, "context_evicted", report)

        chunks = list(state.chunks.values())
        handle_map = citation.assign_handles(chunks)
        state.handle_map = {h: c.chunk_id for h, c in handle_map.items()}
        references = citation.build_references(chunks)
        await emit(sse(ReferencesEvent(items=references).model_dump()))

        context_text = citation.build_context_text(chunks)
        system_content = render_prompt(
            prompt, question=state.question, context=context_text, history=history_text(state),
        ) + citation.SOURCE_PROTOCOL
        messages = [{"role": "system", "content": system_content}]
        messages += [
            {"role": m.get("role", "user"), "content": m.get("content", "")}
            for m in state.history
        ]
        if not state.history:
            messages.append({"role": "user", "content": state.question})
        if extra_messages:
            messages += extra_messages

        def _on_invalid(handle: str) -> None:
            tracing.add_event(span, tracing.EVENT_INVALID_REF_DROPPED, {"handle": handle})
            state.events.append({"event": tracing.EVENT_INVALID_REF_DROPPED, "handle": handle})

        ref_filter = citation.RefStreamFilter(set(handle_map), on_invalid=_on_invalid)
        usage = None
        async for chunk in llm_client.stream_chat(
            state.snapshot.analysis_model.name, messages,
            max_output_tokens=state.snapshot.max_output_tokens,
            cancel_event=state.cancel_event,
            span=span,
        ):
            delta = (chunk.get("choices") or [{}])[0].get("delta", {})
            piece = delta.get("content")
            if piece:
                out = ref_filter.feed(piece)
                if out:
                    state.partial_answer += out
                    await emit(sse({"type": "delta", "content": out}))
            if chunk.get("usage"):
                usage = chunk["usage"]
                await emit(sse({"type": "usage", **usage}))
        tail = ref_filter.flush()
        if tail:
            state.partial_answer += tail
            await emit(sse({"type": "delta", "content": tail}))
        return {
            "content": state.partial_answer,
            "usage": usage,
            "references": [r.model_dump() for r in references],
        }
    finally:
        span.end()
        await emit_step(emit, "answer", "end", loop=state.loop or None)