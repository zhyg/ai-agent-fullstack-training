"""计划管理工具（FR-024，contracts/tool-runtime.md §2）：仅操作本次请求内存 plan.

单请求单 plan（createPlan 已存在时 invalid_args，需先 deletePlan）；
plan_id/step_id 不匹配返回 invalid_args；plan 不落库，请求结束/停止随 state 丢弃。
"""
import json
import uuid
from datetime import datetime, timezone
from typing import List, Literal, Optional

from pydantic import BaseModel, Field

from app.schemas.agent_runtime import ToolResult
from app.services.agent_runtime.state import Plan, PlanStep, RequestRuntimeState
from app.services.agent_runtime.tools.runtime import ToolFailure, ToolSpec


def _ok(payload: dict) -> ToolResult:
    return ToolResult(success=True, code="ok", content=json.dumps(payload, ensure_ascii=False))


def _plan_dict(plan: Plan) -> dict:
    return {
        "plan_id": plan.plan_id,
        "title": plan.title,
        "steps": [
            {"step_id": s.step_id, "description": s.description, "status": s.status}
            for s in plan.steps
        ],
        "created_at": plan.created_at.isoformat(),
        "updated_at": plan.updated_at.isoformat(),
    }


def _require_plan(ctx: RequestRuntimeState, plan_id: str) -> Plan:
    if ctx.plan is None or ctx.plan.plan_id != plan_id:
        raise ToolFailure("invalid_args", f"plan_id 不匹配：{plan_id}")
    return ctx.plan


def _touch(plan: Plan) -> None:
    plan.updated_at = datetime.now(timezone.utc)


# ---- 入参模型 ----

class PlanStepDesc(BaseModel):
    description: str = Field(..., min_length=1)


class CreatePlanArgs(BaseModel):
    title: str = Field(..., min_length=1)
    steps: List[PlanStepDesc] = Field(..., min_length=1, max_length=50)


class ListPlanArgs(BaseModel):
    pass


class GetPlanArgs(BaseModel):
    plan_id: str = Field(..., min_length=1)


class PlanStepUpdate(BaseModel):
    step_id: Optional[str] = None       # 缺省表示追加新步骤
    description: Optional[str] = None
    status: Optional[Literal["pending", "in_progress", "done"]] = None


class UpdatePlanArgs(BaseModel):
    plan_id: str = Field(..., min_length=1)
    title: Optional[str] = None
    steps: Optional[List[PlanStepUpdate]] = None


class DeletePlanArgs(BaseModel):
    plan_id: str = Field(..., min_length=1)


# ---- 处理器 ----

async def _create_plan(args: CreatePlanArgs, ctx: RequestRuntimeState) -> ToolResult:
    if ctx.plan is not None:
        raise ToolFailure("invalid_args", "本次请求已存在计划，请先 deletePlan 再创建")
    plan = Plan(
        title=args.title,
        steps=[PlanStep(step_id=str(uuid.uuid4()), description=s.description) for s in args.steps],
    )
    ctx.plan = plan
    return _ok(_plan_dict(plan))


async def _list_plan(args: ListPlanArgs, ctx: RequestRuntimeState) -> ToolResult:
    plans = []
    if ctx.plan is not None:
        plans.append({
            "plan_id": ctx.plan.plan_id,
            "title": ctx.plan.title,
            "step_count": len(ctx.plan.steps),
            "done_count": sum(1 for s in ctx.plan.steps if s.status == "done"),
        })
    return _ok({"plans": plans})


async def _get_plan(args: GetPlanArgs, ctx: RequestRuntimeState) -> ToolResult:
    return _ok(_plan_dict(_require_plan(ctx, args.plan_id)))


async def _update_plan(args: UpdatePlanArgs, ctx: RequestRuntimeState) -> ToolResult:
    plan = _require_plan(ctx, args.plan_id)
    if args.title is not None:
        if not args.title.strip():
            raise ToolFailure("invalid_args", "title 不能为空")
        plan.title = args.title
    for item in args.steps or []:
        if item.step_id is None:
            # 无 step_id：追加新步骤（description 必填）
            if not (item.description and item.description.strip()):
                raise ToolFailure("invalid_args", "追加步骤必须提供 description")
            plan.steps.append(PlanStep(
                step_id=str(uuid.uuid4()), description=item.description,
                status=item.status or "pending",
            ))
            continue
        target = next((s for s in plan.steps if s.step_id == item.step_id), None)
        if target is None:
            raise ToolFailure("invalid_args", f"step_id 不存在：{item.step_id}")
        if item.description is not None:
            target.description = item.description
        if item.status is not None:
            target.status = item.status
    _touch(plan)
    return _ok(_plan_dict(plan))


async def _delete_plan(args: DeletePlanArgs, ctx: RequestRuntimeState) -> ToolResult:
    _require_plan(ctx, args.plan_id)
    ctx.plan = None
    return _ok({"deleted": True})


TOOLS = [
    ToolSpec("createPlan", "制定本次问题的执行计划（标题+1–50 个步骤）；单请求仅一个计划，已存在时需先 deletePlan", CreatePlanArgs, _create_plan),
    ToolSpec("listPlan", "列出本次请求的计划概要（0 或 1 条，含步骤数与完成数）", ListPlanArgs, _list_plan),
    ToolSpec("getPlan", "按 plan_id 获取完整计划（含各步骤状态）", GetPlanArgs, _get_plan),
    ToolSpec("updatePlan", "更新计划标题/步骤描述/步骤状态（pending|in_progress|done）；步骤不带 step_id 表示追加", UpdatePlanArgs, _update_plan),
    ToolSpec("deletePlan", "按 plan_id 删除本次请求的计划", DeletePlanArgs, _delete_plan),
]