import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Text, TIMESTAMP
from sqlalchemy.dialects.postgresql import JSONB

from app.core.database import Base
from app.core.config import settings


class Agent(Base):
    __tablename__ = "agents"
    __table_args__ = (
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    type = Column(String(20), nullable=False, unique=True, comment="智能体类型：quick_qa/reasoning_action/planning_reasoning，预置后不可变")
    name = Column(String(100), nullable=False, unique=True, comment="显示名称，跨智能体唯一")
    icon = Column(String(50), nullable=False, comment="内置图标库 key")
    description = Column(Text, nullable=False, default="", comment="描述")
    status = Column(String(10), nullable=False, default="enabled", comment="启用状态：enabled/disabled")
    config = Column(JSONB, nullable=False, comment="整份编辑配置（提示词/检索策略/模型/循环次数/工具）")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )