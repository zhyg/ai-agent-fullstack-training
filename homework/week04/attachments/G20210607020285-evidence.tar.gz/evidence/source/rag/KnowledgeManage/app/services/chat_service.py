"""Chat service: background generation + observer queue + Redis Pub/Sub cancel.

State transitions:
  idle / completed / cancelled → generating (send_message)
  generating → completed (stream ends normally)
  generating → cancelled (cancel_chat via Redis Pub/Sub)
"""

import asyncio
import dataclasses
import json
import logging
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import AsyncGenerator, List, Optional, Tuple

import httpx
import redis.asyncio as aioredis
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.models.agent import Agent
from app.models.chat import Chat
from app.models.message import Message
from app.models.prompt import Prompt
from app.schemas.chat import ChatCreate, ChatUpdate
from app.core.config import settings
from app.core.database import SessionLocal

logger = logging.getLogger(__name__)

# Redis Pub/Sub cancel channel pattern
CANCEL_CHANNEL = "chat:{chat_id}:cancel"
GENERATION_STREAM = "chat:{chat_id}:generation:{generation_id}:events"
CANCEL_KEY = "chat:{chat_id}:generation:{generation_id}:cancel"
LEASE_SECONDS = 30
LEASE_RENEW_SECONDS = 5
EVENT_STREAM_TTL_SECONDS = 86400
EVENT_STREAM_MAXLEN = 5000
_instance_id = uuid.uuid4().hex

# Active generation jobs (in-memory, keyed by chat_id)
_generations: dict[str, "_GenerationJob"] = {}


@dataclasses.dataclass
class _GenerationJob:
    """Tracks a single background LLM generation task."""

    task: asyncio.Task
    cancel: asyncio.Event = dataclasses.field(default_factory=asyncio.Event)
    detached: asyncio.Event = dataclasses.field(default_factory=asyncio.Event)
    done: asyncio.Event = dataclasses.field(default_factory=asyncio.Event)
    _live: asyncio.Queue = dataclasses.field(default_factory=asyncio.Queue)
    _history: list[str] = dataclasses.field(default_factory=list)
    content_buffer: str = ""
    _stream_id: str = ""
    generation_id: str = ""
    stream_key: str = ""
    agent_mode: bool = False

    def _emit(self, event_str: str) -> None:
        """Store an SSE event for reconnect replay and notify attached observers."""
        sequence = len(self._history)
        self._history.append(event_str)
        self._live.put_nowait((sequence, event_str))


# ---------------------------------------------------------------------------
# Redis helpers
# ---------------------------------------------------------------------------

def _get_redis_pool() -> Optional[aioredis.Redis]:
    """Get Redis connection pool from app state (set in main.py lifespan)."""
    return getattr(_get_redis_pool, "_pool", None)


def set_redis_pool(pool: aioredis.Redis):
    """Store the Redis connection pool for later use."""
    _get_redis_pool._pool = pool  # type: ignore[attr-defined]


def _generation_stream_key(chat_id: str, generation_id: str) -> str:
    return GENERATION_STREAM.format(chat_id=chat_id, generation_id=generation_id)


def _rowcount(result) -> int:
    """Treat mocked update results as successful while honoring real DB row counts."""
    count = getattr(result, "rowcount", None)
    return count if isinstance(count, int) else 1


def _claim_generation(
    db: Session, chat: Chat, user_id: str, generation_id: str, *, recovery: bool
) -> bool:
    """Atomically claim a chat generation or take over an expired lease."""
    now = datetime.now(timezone.utc)
    expired_lease = or_(
        Chat.lease_expires_at.is_(None),
        Chat.lease_expires_at <= now,
    )
    eligibility = (
        (Chat.status == "generating") & expired_lease
        if recovery
        else or_(
            Chat.status.in_(("idle", "completed", "cancelled")),
            (Chat.status == "generating") & expired_lease,
        )
    )
    result = (
        db.query(Chat)
        .filter(Chat.id == chat.id, Chat.user_id == user_id, eligibility)
        .update(
            {
                Chat.status: "generating",
                Chat.generation_id: generation_id,
                Chat.lease_owner: _instance_id,
                Chat.lease_expires_at: now + timedelta(seconds=LEASE_SECONDS),
                Chat.updated_at: now,
            },
            synchronize_session=False,
        )
    )
    if _rowcount(result) != 1:
        db.rollback()
        return False
    db.commit()
    chat.status = "generating"
    chat.generation_id = generation_id
    chat.lease_owner = _instance_id
    chat.lease_expires_at = now + timedelta(seconds=LEASE_SECONDS)
    return True


def _renew_generation_lease(
    chat_id: str, generation_id: str, db: Optional[Session] = None
) -> bool:
    now = datetime.now(timezone.utc)

    def _renew(session: Session) -> bool:
        result = (
            session.query(Chat)
            .filter(
                Chat.id == chat_id,
                Chat.generation_id == generation_id,
                Chat.lease_owner == _instance_id,
                Chat.status == "generating",
            )
            .update(
                {
                    Chat.lease_expires_at: now + timedelta(seconds=LEASE_SECONDS),
                },
                synchronize_session=False,
            )
        )
        session.commit()
        return _rowcount(result) == 1

    if db is not None:
        return _renew(db)
    with SessionLocal() as session:
        return _renew(session)


def _finalize_generation(
    db: Session, chat_id: str, generation_id: str, content: str, cancelled: bool
) -> bool:
    """Persist the result and terminal state only while this job still owns the chat."""
    terminal_status = "cancelled" if cancelled else "completed"
    result = (
        db.query(Chat)
        .filter(
            Chat.id == chat_id,
            Chat.generation_id == generation_id,
            Chat.lease_owner == _instance_id,
            Chat.status.in_(("generating", "cancelled"))
            if cancelled
            else Chat.status == "generating",
        )
        .update(
            {
                Chat.status: terminal_status,
                Chat.lease_owner: None,
                Chat.lease_expires_at: None,
                Chat.updated_at: datetime.now(timezone.utc),
            },
            synchronize_session=False,
        )
    )
    if _rowcount(result) != 1:
        db.rollback()
        return False
    if content:
        saved_content = content + "\n[已取消]" if cancelled else content
        save_message(db, chat_id, "assistant", saved_content, commit=False)
    db.commit()
    return True


async def _emit_event(job: _GenerationJob, event_str: str) -> None:
    """Publish an SSE event locally and to the shared cross-instance event stream."""
    job._emit(event_str)
    pool = _get_redis_pool()
    if not pool or not job.stream_key:
        return
    try:
        await pool.xadd(
            job.stream_key,
            {"event": event_str, "done": "0"},
            maxlen=EVENT_STREAM_MAXLEN,
            approximate=True,
        )
        await pool.expire(job.stream_key, EVENT_STREAM_TTL_SECONDS)
    except Exception:
        logger.exception(
            "chat_stream event publish failed chat_id=%s generation_id=%s",
            job.stream_key.split(":")[1] if ":" in job.stream_key else "unknown",
            job.generation_id,
        )


async def _publish_generation_done(job: _GenerationJob) -> None:
    pool = _get_redis_pool()
    if not pool or not job.stream_key:
        return
    try:
        await pool.xadd(
            job.stream_key,
            {"event": "", "done": "1"},
            maxlen=EVENT_STREAM_MAXLEN,
            approximate=True,
        )
        await pool.expire(job.stream_key, EVENT_STREAM_TTL_SECONDS)
    except Exception:
        logger.exception(
            "chat_stream completion publish failed generation_id=%s",
            job.generation_id,
        )


async def _stream_shared_generation(
    chat_id: str, generation_id: str
) -> AsyncGenerator[str, None]:
    """Replay and follow another instance's Redis Stream for this generation."""
    pool = _get_redis_pool()
    if not pool:
        yield (
            f"data: {json.dumps({'type': 'error', 'message': '任务正在其他实例运行，暂时无法连接共享事件流'}, ensure_ascii=False)}\n\n"
        )
        yield "data: [DONE]\n\n"
        return

    stream_key = _generation_stream_key(chat_id, generation_id)
    last_id = "0-0"
    try:
        while True:
            response = await pool.xread({stream_key: last_id}, count=100, block=1000)
            saw_done = False
            for _, entries in response:
                for entry_id, fields in entries:
                    last_id = entry_id.decode() if isinstance(entry_id, bytes) else entry_id
                    event = fields.get("event", "")
                    done = fields.get("done", "0")
                    if isinstance(event, bytes):
                        event = event.decode()
                    if isinstance(done, bytes):
                        done = done.decode()
                    if event:
                        yield event
                    if done == "1":
                        saw_done = True
                        break
                if saw_done:
                    break
            if saw_done:
                return
            if not response:
                with SessionLocal() as db:
                    chat = db.query(Chat).filter(Chat.id == chat_id).first()
                    if not chat or chat.generation_id != generation_id:
                        return
                    if chat.status != "generating":
                        # The owner commits terminal state immediately before its done marker.
                        await asyncio.sleep(0.1)
                        final = await pool.xread({stream_key: last_id}, count=100, block=500)
                        if not final:
                            yield (
                                f"data: {json.dumps({'type': 'error', 'message': '生成事件已过期或不可用，无法恢复流'}, ensure_ascii=False)}\n\n"
                            )
                            yield "data: [DONE]\n\n"
                            return
                        for _, entries in final:
                            for entry_id, fields in entries:
                                last_id = entry_id.decode() if isinstance(entry_id, bytes) else entry_id
                                event = fields.get("event", "")
                                done = fields.get("done", "0")
                                if isinstance(event, bytes):
                                    event = event.decode()
                                if isinstance(done, bytes):
                                    done = done.decode()
                                if event:
                                    yield event
                                if done == "1":
                                    return
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception(
            "chat_stream shared event read failed chat_id=%s generation_id=%s",
            chat_id,
            generation_id,
        )
        yield (
            f"data: {json.dumps({'type': 'error', 'message': '读取共享生成事件失败'}, ensure_ascii=False)}\n\n"
        )
        yield "data: [DONE]\n\n"


# ---------------------------------------------------------------------------
# CRUD operations
# ---------------------------------------------------------------------------

def create_chat(db: Session, user_id: str, data: ChatCreate) -> Chat:
    """Create a new chat. Status defaults to 'idle'."""
    chat = Chat(
        id=str(uuid.uuid4()),
        title=data.title,
        user_id=user_id,
        model_id=data.model_id,
        model_name=data.model_name,
        prompt_id=data.prompt_id,
        agent_id=data.agent_id,
        knowledge_base_ids=data.knowledge_base_ids,
        status="idle",
    )
    if data.agent_id:
        agent = db.query(Agent).filter(Agent.id == data.agent_id).first()
        chat.agent_type = agent.type if agent else None
    db.add(chat)
    db.commit()
    db.refresh(chat)
    return chat


def list_chats(
    db: Session, user_id: str, page: int = 1, page_size: int = 20
) -> Tuple[List[Chat], int]:
    """List chats for the current user, ordered by updated_at desc."""
    query = db.query(Chat).filter(Chat.user_id == user_id)
    total = query.count()
    items = (
        query.order_by(Chat.updated_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return items, total


def update_chat(
    db: Session, chat_id: str, user_id: str, data: ChatUpdate
) -> Optional[Chat]:
    """Update a chat's title, model selection or prompt. Only owner can update."""
    chat = db.query(Chat).filter(
        Chat.id == chat_id, Chat.user_id == user_id
    ).first()
    if not chat:
        return None

    if data.title is not None:
        chat.title = data.title
    if data.model_id is not None:
        chat.model_id = data.model_id
    if data.model_name is not None:
        chat.model_name = data.model_name
    if data.prompt_id is not None:
        chat.prompt_id = data.prompt_id
    if data.agent_id is not None:
        chat.agent_id = data.agent_id
        agent = db.query(Agent).filter(Agent.id == data.agent_id).first()
        chat.agent_type = agent.type if agent else None
    if data.knowledge_base_ids is not None:
        chat.knowledge_base_ids = data.knowledge_base_ids

    chat.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(chat)
    return chat


def delete_chat(db: Session, chat_id: str, user_id: str) -> bool:
    """Delete a chat and all its messages. Only owner can delete."""
    chat = db.query(Chat).filter(
        Chat.id == chat_id, Chat.user_id == user_id
    ).first()
    if not chat:
        return False

    db.query(Message).filter(Message.chat_id == chat_id).delete()
    db.delete(chat)
    db.commit()
    return True


def get_chat(db: Session, chat_id: str, user_id: str) -> Optional[Chat]:
    """Get a single chat by ID, verify ownership."""
    return db.query(Chat).filter(
        Chat.id == chat_id, Chat.user_id == user_id
    ).first()


def list_messages(
    db: Session, chat_id: str, page: int = 1, page_size: int = 50
) -> Tuple[List[Message], int]:
    """List messages for a chat, ordered by created_at asc."""
    query = db.query(Message).filter(Message.chat_id == chat_id)
    total = query.count()
    items = (
        query.order_by(Message.created_at.asc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return items, total


def save_message(
    db: Session, chat_id: str, role: str, content: str, *, commit: bool = True,
    trace_id: Optional[str] = None, meta: Optional[dict] = None,
) -> Message:
    """Save a message to the database."""
    msg = Message(
        id=str(uuid.uuid4()),
        chat_id=chat_id,
        role=role,
        content=content,
        trace_id=trace_id,
        meta=meta,
    )
    db.add(msg)
    if commit:
        db.commit()
        db.refresh(msg)
    return msg


# ---------------------------------------------------------------------------
# Cancel via Redis Pub/Sub
# ---------------------------------------------------------------------------

async def cancel_chat(db: Session, chat_id: str, user_id: str) -> Optional[Chat]:
    """Cancel a generating chat and persist a generation-scoped cancellation signal.

    Returns the updated Chat or None if not found.
    Raises ValueError if chat is not in 'generating' state.
    """
    chat = get_chat(db, chat_id, user_id)
    if not chat:
        return None

    generation_id = getattr(chat, "generation_id", None)
    result = (
        db.query(Chat)
        .filter(
            Chat.id == chat_id,
            Chat.user_id == user_id,
            Chat.status == "generating",
        )
        .update(
            {
                Chat.status: "cancelled",
                Chat.updated_at: datetime.now(timezone.utc),
            },
            synchronize_session=False,
        )
    )
    if _rowcount(result) != 1:
        db.rollback()
        raise ValueError(
            f"Cannot cancel chat in '{chat.status}' state. "
            f"Only 'generating' chats can be cancelled."
        )

    db.commit()
    chat.status = "cancelled"

    # Persist the signal before publishing so a subscriber starting concurrently
    # can still observe cancellation after it subscribes.
    pool = _get_redis_pool()
    if pool and generation_id:
        cancel_key = CANCEL_KEY.format(chat_id=chat_id, generation_id=generation_id)
        channel = CANCEL_CHANNEL.format(chat_id=chat_id)
        try:
            await pool.set(cancel_key, "1", ex=EVENT_STREAM_TTL_SECONDS)
            await pool.publish(
                channel,
                json.dumps(
                    {"action": "cancel", "chat_id": chat_id, "generation_id": generation_id}
                ),
            )
            logger.info(f"Cancel signal published for chat {chat_id}")
        except Exception as e:
            logger.warning(f"Failed to publish cancel signal for chat {chat_id}: {e}")

    # Also set in-process cancel event for fast signal propagation
    job = _generations.get(chat_id)
    if job and (not generation_id or job.generation_id == generation_id) and not job.cancel.is_set():
        job.cancel.set()
        job.task.cancel()
        logger.info(
            "chat_stream_cancel chat_id=%s stream_id=%s",
            chat_id, getattr(job, '_stream_id', 'unknown'),
        )

    return chat


# ---------------------------------------------------------------------------
# Background generation task
# ---------------------------------------------------------------------------

async def _run_generation(
    job: _GenerationJob,
    chat_id: str,
    user_id: str,
    payload: dict,
    headers: dict,
    endpoint: str,
) -> None:
    """Background task: reads LLM Gateway stream, emits events to job queue.

    Uses its own DB session (SessionLocal) so it survives HTTP request scope.
    """
    full_content = ""
    cancelled = False
    stream_id = uuid.uuid4().hex[:12]
    job._stream_id = stream_id
    owns_chat = False
    started_at = time.monotonic()
    data_events = 0
    delta_events = 0
    invalid_events = 0
    unhandled_events = 0
    end_reason = "eof"

    logger.info(
        "chat_stream start stream_id=%s chat_id=%s endpoint=%s",
        stream_id, chat_id, endpoint,
    )

    # Own DB session for background persistence
    with SessionLocal() as db:
      redis_sub_task = None
      lease_task = None
      try:
        # The request-scoped ORM object is detached by the time this task runs.
        # Reload it in this session so completion status is actually persisted.
        chat = get_chat(db, chat_id, user_id)
        if not chat:
            logger.error("chat_stream chat missing in background session chat_id=%s", chat_id)
            await _emit_event(job,
                f"data: {json.dumps({'type': 'error', 'message': '会话不存在'}, ensure_ascii=False)}\n\n"
            )
            return
        owns_chat = True
        try:
            lease_valid = _renew_generation_lease(
                chat_id, job.generation_id, db=db
            )
        except Exception:
            logger.exception(
                "chat_stream initial lease check failed chat_id=%s generation_id=%s",
                chat_id,
                job.generation_id,
            )
            lease_valid = False
        if not lease_valid:
            job.cancel.set()
            cancelled = True
            end_reason = "lease_lost"
            return

        # --- Redis cancel listener setup ---
        pool = _get_redis_pool()
        if pool:
            async def _listen_cancel():
                pubsub = None
                channel = CANCEL_CHANNEL.format(chat_id=chat_id)
                try:
                    pubsub = pool.pubsub()
                    await pubsub.subscribe(channel)
                    cancel_key = CANCEL_KEY.format(
                        chat_id=chat_id, generation_id=job.generation_id
                    )
                    if await pool.get(cancel_key):
                        job.cancel.set()
                        job.task.cancel()
                        return
                    async for message in pubsub.listen():
                        if message["type"] == "message":
                            try:
                                signal = json.loads(message.get("data") or "{}")
                            except (TypeError, json.JSONDecodeError):
                                signal = {}
                            if (
                                signal.get("generation_id") == job.generation_id
                                and not job.cancel.is_set()
                            ):
                                job.cancel.set()
                                job.task.cancel()
                                logger.info("Cancel signal received for chat %s", chat_id)
                                break
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    logger.warning("Redis cancel listener error for chat %s: %s", chat_id, e)
                finally:
                    if pubsub:
                        try:
                            await pubsub.unsubscribe(channel)
                            await pubsub.aclose()
                        except Exception:
                            logger.warning(
                                "Redis cancel listener cleanup failed for chat %s", chat_id
                            )

            redis_sub_task = asyncio.create_task(_listen_cancel())

        async def _maintain_lease():
            while True:
                await asyncio.sleep(LEASE_RENEW_SECONDS)
                try:
                    renewed = await asyncio.to_thread(
                        _renew_generation_lease, chat_id, job.generation_id
                    )
                except Exception:
                    logger.exception(
                        "chat_stream lease renewal failed chat_id=%s generation_id=%s",
                        chat_id,
                        job.generation_id,
                    )
                    renewed = False
                if not renewed:
                    logger.warning(
                        "chat_stream lease lost chat_id=%s generation_id=%s",
                        chat_id,
                        job.generation_id,
                    )
                    job.cancel.set()
                    job.task.cancel()
                    return

        lease_task = asyncio.create_task(_maintain_lease())

        # --- Call LlmGateway ---
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                async with client.stream(
                    "POST", endpoint, json=payload, headers=headers,
                ) as response:
                    logger.info(
                        "chat_stream response stream_id=%s status=%d content_type=%s",
                        stream_id, response.status_code,
                        response.headers.get("content-type"),
                    )

                    if response.status_code != 200:
                        end_reason = "http_error"
                        body = await response.aread()
                        raw_body = body.decode("utf-8", errors="replace")
                        error_msg = raw_body
                        try:
                            err_json = json.loads(raw_body)
                            error_msg = err_json.get("error", {}).get("message", raw_body)
                        except (json.JSONDecodeError, AttributeError):
                            pass
                        await _emit_event(job,
                            f"data: {json.dumps({'type': 'error', 'message': error_msg}, ensure_ascii=False)}\n\n"
                        )
                        return

                    async for line in response.aiter_lines():
                        # Check cancel signal
                        if job.cancel.is_set():
                            cancelled = True
                            end_reason = "cancelled"
                            break

                        if not line.startswith("data: "):
                            continue

                        payload_str = line[6:]
                        data_events += 1

                        if payload_str == "[DONE]":
                            end_reason = "done_marker"
                            await _emit_event(job,
                                f"data: {json.dumps({'type': 'done'}, ensure_ascii=False)}\n\n"
                            )
                            await _emit_event(job, "data: [DONE]\n\n")
                            break

                        try:
                            event = json.loads(payload_str)
                        except json.JSONDecodeError:
                            invalid_events += 1
                            if invalid_events <= 3:
                                logger.warning(
                                    "chat_stream invalid JSON stream_id=%s event=%d",
                                    stream_id, data_events,
                                )
                            continue

                        event_type = event.get("type")
                        if data_events <= 3:
                            choices = event.get("choices") or []
                            delta = (choices[0].get("delta") or {}) if choices else {}
                            logger.info(
                                "chat_stream event stream_id=%s event=%d keys=%s type=%s",
                                stream_id, data_events, sorted(event), event_type,
                            )

                        if event_type == "delta":
                            chunk = event.get("content", "")
                            delta_events += 1
                            full_content += chunk
                            await _emit_event(job,
                                f"data: {json.dumps({'type': 'delta', 'content': chunk}, ensure_ascii=False)}\n\n"
                            )

                        elif event.get("choices"):
                            choice = event["choices"][0]
                            chunk = (choice.get("delta") or {}).get("content", "")
                            if isinstance(chunk, str) and chunk:
                                delta_events += 1
                                full_content += chunk
                                await _emit_event(job,
                                    f"data: {json.dumps({'type': 'delta', 'content': chunk}, ensure_ascii=False)}\n\n"
                                )
                            if event.get("usage"):
                                await _emit_event(job,
                                    f"data: {json.dumps({'type': 'usage', **event['usage']}, ensure_ascii=False)}\n\n"
                                )

                        elif event_type == "usage":
                            await _emit_event(job,
                                f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                            )

                        elif event_type == "error" or event.get("error"):
                            end_reason = "upstream_error"
                            error = event.get("error")
                            if isinstance(error, dict):
                                error_event = {
                                    "type": "error",
                                    "message": error.get("message", "Gateway error"),
                                    "error_code": error.get("code"),
                                }
                            elif error:
                                error_event = {"type": "error", "message": str(error)}
                            else:
                                error_event = event
                            error_code = error_event.get("error_code") if isinstance(error_event, dict) else None
                            if error_code:
                                logger.error(
                                    "chat_stream upstream error stream_id=%s error_code=%s",
                                    stream_id, error_code,
                                )
                            else:
                                logger.error(
                                    "chat_stream upstream error stream_id=%s", stream_id,
                                )
                            await _emit_event(job,
                                f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"
                            )
                            break

                        elif event_type == "done":
                            end_reason = "done_event"
                            await _emit_event(job,
                                f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                            )
                            await _emit_event(job, "data: [DONE]\n\n")
                            break
                        else:
                            unhandled_events += 1
                            if unhandled_events <= 3:
                                logger.warning(
                                    "chat_stream unhandled event stream_id=%s keys=%s",
                                    stream_id, sorted(event),
                                )

        except asyncio.CancelledError:
            # Task was cancelled (by cancel_chat or Redis listener)
            cancelled = True
            end_reason = "cancelled"
        except httpx.ConnectError as e:
            end_reason = "connection_error"
            logger.error("LLM Gateway connection failed: %s", e)
            await _emit_event(job,
                f"data: {json.dumps({'type': 'error', 'message': f'LLM 服务连接失败: {e}'}, ensure_ascii=False)}\n\n"
            )
        except Exception as e:
            end_reason = "exception"
            logger.exception("chat_stream failed stream_id=%s", stream_id)
            await _emit_event(job,
                f"data: {json.dumps({'type': 'error', 'message': f'LLM 服务调用失败: {e}'}, ensure_ascii=False)}\n\n"
            )

        # --- Post-stream: save message and update status ---
        if cancelled:
            await _emit_event(job,
                f"data: {json.dumps({'type': 'cancelled', 'chat_id': chat_id}, ensure_ascii=False)}\n\n"
            )
            await _emit_event(job, "data: [DONE]\n\n")

      finally:
        if lease_task and not lease_task.done():
            lease_task.cancel()
            try:
                await lease_task
            except asyncio.CancelledError:
                pass
        # Cleanup Redis subscriber
        if redis_sub_task and not redis_sub_task.done():
            redis_sub_task.cancel()
            try:
                await redis_sub_task
            except (asyncio.CancelledError, Exception):
                pass

        if owns_chat:
            try:
                finalized = _finalize_generation(
                    db, chat_id, job.generation_id, full_content,
                    cancelled or job.cancel.is_set(),
                )
                if finalized:
                    chat.status = "cancelled" if cancelled or job.cancel.is_set() else "completed"
            except Exception:
                db.rollback()
                logger.exception(
                    "chat_stream finalization failed chat_id=%s generation_id=%s",
                    chat_id,
                    job.generation_id,
                )

        await _publish_generation_done(job)

        # Emit sentinel to wake up any attached observer generators
        job._live.put_nowait(None)

        # Mark job as done
        job.done.set()
        job.content_buffer = full_content

        # Do NOT drain the queue when detached — a reattaching observer
        # may still need the buffered events.

        # Only remove from _generations if an observer is still attached.
        # Detached jobs stay in the dict so a reconnecting client can
        # reattach and replay buffered events.
        if not job.detached.is_set():
            if _generations.get(chat_id) is job:
                del _generations[chat_id]
        else:
            # Schedule deferred cleanup for detached jobs (30s grace period)
            async def _deferred_cleanup(_chat_id=chat_id, _job=job):
                await asyncio.sleep(30)
                if _generations.get(_chat_id) is _job:
                    del _generations[_chat_id]
            asyncio.ensure_future(_deferred_cleanup())

        log_fn = logger.info if full_content or cancelled else logger.warning
        log_fn(
            "chat_stream summary stream_id=%s end=%s data_events=%d delta_events=%d "
            "content_chars=%d invalid_events=%d unhandled_events=%d elapsed_ms=%.0f",
            stream_id, end_reason, data_events, delta_events, len(full_content),
            invalid_events, unhandled_events, (time.monotonic() - started_at) * 1000,
        )


# ---------------------------------------------------------------------------
# Agent-mode background generation (agent_id 分支，旧路径零改动)
# ---------------------------------------------------------------------------

def _finalize_agent_generation(
    db: Session,
    chat_id: str,
    generation_id: str,
    *,
    content: str,
    meta: dict,
    trace_id: str,
    cancelled: bool,
    user_message_id: Optional[str] = None,
) -> Tuple[bool, Optional[str]]:
    """Agent 模式落库：同轮 user/assistant 写同一 trace_id，assistant 带 meta.

    停止标记为 "\n[已停止]"（旧模式保留 "\n[已取消]"）。返回 (是否落库, assistant 消息 id)。
    """
    terminal_status = "cancelled" if cancelled else "completed"
    result = (
        db.query(Chat)
        .filter(
            Chat.id == chat_id,
            Chat.generation_id == generation_id,
            Chat.lease_owner == _instance_id,
            Chat.status.in_(("generating", "cancelled"))
            if cancelled
            else Chat.status == "generating",
        )
        .update(
            {
                Chat.status: terminal_status,
                Chat.lease_owner: None,
                Chat.lease_expires_at: None,
                Chat.updated_at: datetime.now(timezone.utc),
            },
            synchronize_session=False,
        )
    )
    if _rowcount(result) != 1:
        db.rollback()
        return False, None
    if trace_id and user_message_id:
        db.query(Message).filter(
            Message.id == user_message_id, Message.chat_id == chat_id
        ).update({Message.trace_id: trace_id}, synchronize_session=False)
    message_id = None
    if content:
        saved_content = content + "\n[已停止]" if cancelled else content
        msg = save_message(
            db, chat_id, "assistant", saved_content, commit=False,
            trace_id=trace_id or None, meta=meta or None,
        )
        message_id = msg.id
    db.commit()
    return True, message_id


async def _run_agent_generation(
    job: _GenerationJob,
    chat_id: str,
    user_id: str,
    question: str,
    user_message_id: Optional[str],
    history: List[dict],
) -> None:
    """Agent 模式后台任务：委托 agent_runtime 入口，复用租约/取消/落库骨架.

    事件经同一 _GenerationJob 队列/Redis Stream 下发（reattach 可回放）；
    终止事件（done/cancelled/error）在 finalize 后发出以携带 message_id/trace_id。
    """
    from app.services import agent_runtime

    cancelled = False
    owns_chat = False
    content = ""
    meta: dict = {}
    trace_id = ""
    error_event: Optional[dict] = None
    message_id: Optional[str] = None
    embedding_model_id = ""

    with SessionLocal() as db:
      redis_sub_task = None
      lease_task = None
      try:
        chat = get_chat(db, chat_id, user_id)
        if not chat:
            logger.error("agent_generation chat missing chat_id=%s", chat_id)
            error_event = {"type": "error", "code": "internal_error", "message": "会话不存在"}
            return
        owns_chat = True
        try:
            lease_valid = _renew_generation_lease(chat_id, job.generation_id, db=db)
        except Exception:
            logger.exception(
                "agent_generation initial lease check failed chat_id=%s generation_id=%s",
                chat_id, job.generation_id,
            )
            lease_valid = False
        if not lease_valid:
            job.cancel.set()
            cancelled = True
            return

        # --- Redis cancel listener（与旧路径同机制） ---
        pool = _get_redis_pool()
        if pool:
            async def _listen_cancel():
                pubsub = None
                channel = CANCEL_CHANNEL.format(chat_id=chat_id)
                try:
                    pubsub = pool.pubsub()
                    await pubsub.subscribe(channel)
                    cancel_key = CANCEL_KEY.format(
                        chat_id=chat_id, generation_id=job.generation_id
                    )
                    if await pool.get(cancel_key):
                        job.cancel.set()
                        job.task.cancel()
                        return
                    async for message in pubsub.listen():
                        if message["type"] == "message":
                            try:
                                signal = json.loads(message.get("data") or "{}")
                            except (TypeError, json.JSONDecodeError):
                                signal = {}
                            if (
                                signal.get("generation_id") == job.generation_id
                                and not job.cancel.is_set()
                            ):
                                job.cancel.set()
                                job.task.cancel()
                                logger.info("Agent cancel signal received for chat %s", chat_id)
                                break
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    logger.warning("Redis cancel listener error for chat %s: %s", chat_id, e)
                finally:
                    if pubsub:
                        try:
                            await pubsub.unsubscribe(channel)
                            await pubsub.aclose()
                        except Exception:
                            logger.warning(
                                "Redis cancel listener cleanup failed for chat %s", chat_id
                            )

            redis_sub_task = asyncio.create_task(_listen_cancel())

        async def _maintain_lease():
            while True:
                await asyncio.sleep(LEASE_RENEW_SECONDS)
                try:
                    renewed = await asyncio.to_thread(
                        _renew_generation_lease, chat_id, job.generation_id
                    )
                except Exception:
                    logger.exception(
                        "agent_generation lease renewal failed chat_id=%s generation_id=%s",
                        chat_id, job.generation_id,
                    )
                    renewed = False
                if not renewed:
                    logger.warning(
                        "agent_generation lease lost chat_id=%s generation_id=%s",
                        chat_id, job.generation_id,
                    )
                    job.cancel.set()
                    job.task.cancel()
                    return

        lease_task = asyncio.create_task(_maintain_lease())

        # --- 委托 agent_runtime 入口（T018 实现流程分发） ---
        try:
            result = await agent_runtime.run_agent_generation(
                chat_id=chat_id,
                user_id=user_id,
                question=question,
                history=history,
                generation_id=job.generation_id,
                cancel_event=job.cancel,
                emit=lambda event_str: _emit_event(job, event_str),
            )
            content = result.get("content") or ""
            meta = dict(result.get("meta") or {})
            trace_id = result.get("trace_id") or ""
            cancelled = bool(result.get("cancelled"))
            embedding_model_id = result.get("embedding_model_id") or ""
            if result.get("error"):
                err = result["error"]
                error_event = {
                    "type": "error",
                    "code": err.get("code") or "internal_error",
                    "message": err.get("message") or "智能体运行失败",
                }
                if err.get("raw_output"):
                    error_event["raw_output"] = err["raw_output"]
                meta.setdefault("error_code", error_event["code"])
                if err.get("raw_output"):
                    meta.setdefault("raw_output", err["raw_output"])
        except asyncio.CancelledError:
            cancelled = True
        except Exception as e:
            logger.exception("agent_generation failed chat_id=%s", chat_id)
            error_event = {
                "type": "error", "code": "internal_error",
                "message": f"智能体运行失败: {e}",
            }
            meta.setdefault("error_code", "internal_error")

        cancelled = cancelled or job.cancel.is_set()
        if cancelled:
            meta["stopped"] = True

      finally:
        if lease_task and not lease_task.done():
            lease_task.cancel()
            try:
                await lease_task
            except asyncio.CancelledError:
                pass
        if redis_sub_task and not redis_sub_task.done():
            redis_sub_task.cancel()
            try:
                await redis_sub_task
            except (asyncio.CancelledError, Exception):
                pass

        if owns_chat:
            try:
                finalized, message_id = _finalize_agent_generation(
                    db, chat_id, job.generation_id,
                    content=content, meta=meta, trace_id=trace_id,
                    cancelled=cancelled, user_message_id=user_message_id,
                )
                if finalized:
                    chat.status = "cancelled" if cancelled else "completed"
                    # 013 R5/R6：done 终态落库后异步写入历史问答（含 clarify_failed/empty_retrieval）；
                    # 取消/报错/停止不触发；火忘式不 await，失败隔离在 index_qa_round 内部
                    if not cancelled and error_event is None and content and message_id and embedding_model_id:
                        from app.services import history_qa_service
                        asyncio.create_task(history_qa_service.index_qa_round(
                            chat_id=chat_id, user_id=user_id, question=question,
                            answer=content, message_id=message_id,
                            embedding_model_id=embedding_model_id, trace_id=trace_id,
                        ))
            except Exception:
                db.rollback()
                logger.exception(
                    "agent_generation finalization failed chat_id=%s generation_id=%s",
                    chat_id, job.generation_id,
                )

        # 终止事件（finalize 后发出，携带 message_id/trace_id）
        if error_event is not None:
            await _emit_event(job, f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n")
        elif cancelled:
            await _emit_event(job,
                f"data: {json.dumps({'type': 'cancelled', 'message_id': message_id, 'partial_content': content}, ensure_ascii=False)}\n\n"
            )
        else:
            # 非流式终止分支（clarify_failed/empty_retrieval 等，携 terminate_reason）：
            # 内容未经 delta 下发，终态前补发一条 delta，否则前端消息气泡为空
            if content and meta.get("terminate_reason"):
                await _emit_event(
                    job,
                    f"data: {json.dumps({'type': 'delta', 'content': content}, ensure_ascii=False)}\n\n",
                )
            done_event = {"type": "done", "message_id": message_id, "trace_id": trace_id}
            # 收敛/降级等事件随终态下发（US2 完成态文案）；references 已经独立事件下发，不重复
            slim_meta = {k: v for k, v in (meta or {}).items() if k != "references"}
            if slim_meta:
                done_event["meta"] = slim_meta
            await _emit_event(job, f"data: {json.dumps(done_event, ensure_ascii=False)}\n\n")
        await _emit_event(job, "data: [DONE]\n\n")
        await _publish_generation_done(job)

        job._live.put_nowait(None)
        job.done.set()
        job.content_buffer = content

        if not job.detached.is_set():
            if _generations.get(chat_id) is job:
                del _generations[chat_id]
        else:
            async def _deferred_cleanup(_chat_id=chat_id, _job=job):
                await asyncio.sleep(LEASE_SECONDS)
                if _generations.get(_chat_id) is _job:
                    del _generations[_chat_id]
            asyncio.ensure_future(_deferred_cleanup())

        logger.info(
            "agent_generation summary chat_id=%s cancelled=%s content_chars=%d trace_id=%s",
            chat_id, cancelled, len(content), trace_id or "-",
        )


# ---------------------------------------------------------------------------
# Streaming: send_message with observer queue pattern
# ---------------------------------------------------------------------------

async def send_message_stream(
    chat_id: str,
    user_content: str,
    user_id: str,
) -> AsyncGenerator[str, None]:
    """Send user message and stream LLM response via background task + observer.

    - Creates a _GenerationJob with a background asyncio.Task
    - Yields SSE events from the job's _live queue to the connected client
    - On client disconnect (GeneratorExit): marks job.detached, background continues
    - On reattach: if an active job exists, yields from its queue

    Signature: 3 args (chat_id, user_content, user_id) — no db parameter.
    Uses own SessionLocal() session for DB operations.
    """
    # --- Reattach to existing job (active OR completed with buffered events) ---
    existing_job = _generations.get(chat_id)
    if existing_job:
        logger.info(
            "chat_stream_reattach chat_id=%s stream_id=%s done=%s",
            chat_id,
            getattr(existing_job, '_stream_id', 'unknown'),
            existing_job.done.is_set(),
        )
        if existing_job.agent_mode:
            # 宽限期内 reattach：解除断线倒计时（R4）
            existing_job.detached.clear()
        # Replay all events already received, then ignore their queued copies.
        cursor = len(existing_job._history)
        for event in existing_job._history[:cursor]:
            yield event

        # Drain events emitted while the replay was being delivered.
        while not existing_job._live.empty():
            queued = existing_job._live.get_nowait()
            if queued is None:
                return
            sequence, event = queued
            if sequence < cursor:
                continue
            cursor = sequence + 1
            yield event

        # If already done, no more events will arrive
        if existing_job.done.is_set():
            return

        # Continue reading live events until done
        while not existing_job.done.is_set():
            try:
                queued = await asyncio.wait_for(existing_job._live.get(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            if queued is None:
                return
            sequence, event = queued
            if sequence < cursor:
                continue
            cursor = sequence + 1
            yield event

        # Final drain after done flag is set
        while not existing_job._live.empty():
            queued = existing_job._live.get_nowait()
            if queued is None:
                return
            sequence, event = queued
            if sequence < cursor:
                continue
            cursor = sequence + 1
            yield event
        return

    # --- Find an active shared generation or claim a new lease ---
    recovering_generation = user_content == ""
    job = None
    db = SessionLocal()
    try:
        chat = get_chat(db, chat_id, user_id)
        if not chat:
            yield f"data: {json.dumps({'error': 'Chat not found'}, ensure_ascii=False)}\n\n"
            return

        agent_mode = bool(getattr(chat, "agent_id", None))

        if not agent_mode and not chat.model_name:
            yield f"data: {json.dumps({'error': 'No model selected for this chat'}, ensure_ascii=False)}\n\n"
            return

        generation_id = getattr(chat, "generation_id", None)
        lease_expires_at = getattr(chat, "lease_expires_at", None)
        lease_is_active = (
            chat.status == "generating"
            and lease_expires_at is not None
            and lease_expires_at > datetime.now(timezone.utc)
        )

        # A non-expired lease means another process owns the upstream request.
        # Never launch a second request; follow its shared event stream instead.
        if lease_is_active and generation_id:
            db.close()
            async for event in _stream_shared_generation(chat_id, generation_id):
                yield event
            return

        # A completed stream can still be replayed after its worker removed the
        # in-memory job, as long as its Redis event stream remains available.
        if (
            recovering_generation
            and chat.status in ("completed", "cancelled")
            and generation_id
        ):
            db.close()
            async for event in _stream_shared_generation(chat_id, generation_id):
                yield event
            return

        resume_generation = recovering_generation or chat.status == "generating"
        if recovering_generation and chat.status != "generating":
            yield (
                f"data: {json.dumps({'type': 'error', 'message': '没有正在生成的回复可恢复'}, ensure_ascii=False)}\n\n"
            )
            yield "data: [DONE]\n\n"
            return

        # Validate prompt before saving user message
        prompt = None
        if not agent_mode and chat.prompt_id:
            prompt = db.query(Prompt).filter(Prompt.id == chat.prompt_id).first()
            if not prompt:
                logger.warning("Chat prompt not found chat_id=%s prompt_id=%s", chat_id, chat.prompt_id)
                yield f"data: {json.dumps({'type': 'error', 'message': 'Prompt not found'}, ensure_ascii=False)}\n\n"
                yield "data: [DONE]\n\n"
                return

        generation_id = str(uuid.uuid4())
        if not _claim_generation(
            db, chat, user_id, generation_id, recovery=resume_generation
        ):
            # Another instance claimed it between our read and conditional update.
            db.refresh(chat)
            active_generation_id = getattr(chat, "generation_id", None)
            if chat.status == "generating" and active_generation_id:
                db.close()
                async for event in _stream_shared_generation(
                    chat_id, active_generation_id
                ):
                    yield event
                return
            yield (
                f"data: {json.dumps({'type': 'error', 'message': f'Chat is in {chat.status} state, cannot start generating'}, ensure_ascii=False)}\n\n"
            )
            yield "data: [DONE]\n\n"
            return

        # A recovery/takeover reuses the already persisted user message.
        user_message_id = None
        if not resume_generation:
            user_msg = save_message(db, chat_id, "user", user_content)
            user_message_id = user_msg.id

        # Build message history
        messages = (
            db.query(Message)
            .filter(Message.chat_id == chat_id)
            .order_by(Message.created_at.asc())
            .all()
        )
        if resume_generation and (
            not messages or messages[-1].role != "user"
        ):
            if _finalize_generation(db, chat_id, generation_id, "", False):
                chat.status = "completed"
            logger.info("chat_stream_reconcile_completed chat_id=%s", chat_id)
            yield f"data: {json.dumps({'type': 'done'}, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"
            return
        history = [{"role": m.role, "content": m.content} for m in messages]

        agent_question = user_content
        payload: dict = {}
        headers: dict = {}
        endpoint = ""
        if agent_mode:
            # 恢复/接管：问题与 user 消息 id 取自最近一条已落库 user 消息
            if resume_generation and messages:
                last_user = next((m for m in reversed(messages) if m.role == "user"), None)
                if last_user is not None:
                    agent_question = last_user.content
                    user_message_id = last_user.id
        else:
            # Build LLM Gateway payload
            payload = {
                "model": chat.model_name,
                "stream": True,
                "messages": history,
            }
            if prompt:
                payload["prompt_name"] = prompt.name
                payload["prompt_version"] = prompt.version

            # Build headers
            if settings.llm_api_key:
                "[REDACTED]"

            # LLM Gateway endpoint
            llm_url = settings.services.get("llm_gateway", "http://localhost:8003")
            endpoint = f"{llm_url}/api/llm/v1/chat/completions"

        job = _GenerationJob(
            task=asyncio.Task(asyncio.sleep(0)),
            generation_id=generation_id,
            stream_key=_generation_stream_key(chat_id, generation_id),
            agent_mode=agent_mode,
        )
    finally:
        db.close()

    # --- Create background job ---
    assert job is not None
    if agent_mode:
        real_task = asyncio.create_task(
            _run_agent_generation(
                job, chat_id, user_id, agent_question, user_message_id, history
            )
        )
    else:
        real_task = asyncio.create_task(
            _run_generation(job, chat_id, user_id, payload, headers, endpoint)
        )
    job.task = real_task
    _generations[chat_id] = job

    # --- Observer: yield events from queue ---
    try:
        while not job.done.is_set():
            try:
                queued = await asyncio.wait_for(job._live.get(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            if queued is None:
                break
            _, event = queued
            yield event

        # Final drain after done
        while not job._live.empty():
            queued = job._live.get_nowait()
            if queued is None:
                break
            _, event = queued
            yield event
    finally:
        # Client disconnected — mark as detached but do NOT cancel background task
        if not job.done.is_set():
            job.detached.set()
            logger.info(
                "chat_stream_detach chat_id=%s stream_id=%s",
                chat_id, getattr(job, '_stream_id', 'unknown'),
            )
            if job.agent_mode:
                # agent 模式断线宽限（R4）：LEASE_SECONDS 内无人 reattach 视同停止
                async def _disconnect_grace(_job=job, _chat_id=chat_id):
                    await asyncio.sleep(LEASE_SECONDS)
                    if (
                        _job.detached.is_set()
                        and not _job.done.is_set()
                        and not _job.cancel.is_set()
                    ):
                        logger.info(
                            "chat_stream disconnect grace expired chat_id=%s", _chat_id
                        )
                        _job.cancel.set()
                asyncio.ensure_future(_disconnect_grace())


# ---------------------------------------------------------------------------
# Graceful shutdown
# ---------------------------------------------------------------------------

async def finish_generations() -> None:
    """Cancel all active generation jobs and wait for them to finish.

    Also cleans up any detached-but-completed jobs from _generations.
    """
    for chat_id, job in list(_generations.items()):
        if not job.cancel.is_set():
            job.cancel.set()
    for chat_id, job in list(_generations.items()):
        try:
            await asyncio.wait_for(job.task, timeout=5.0)
        except (asyncio.TimeoutError, Exception):
            logger.warning("Generation job for chat %s did not finish in time", chat_id)
    # Clean up all remaining jobs (including detached ones awaiting reattach)
    _generations.clear()
