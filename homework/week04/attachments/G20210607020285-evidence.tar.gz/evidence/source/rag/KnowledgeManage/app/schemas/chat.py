from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Dict, Any, TypeVar, Generic
from datetime import datetime


# --- Chat ---
class ChatCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200, description="会话标题")
    model_id: Optional[str] = Field(None, description="模型 ID")
    model_name: Optional[str] = Field(None, min_length=1, max_length=200, description="模型显示名称")
    prompt_id: Optional[str] = Field(None, description="提示词 ID")
    agent_id: Optional[str] = Field(None, description="智能体 ID；非空时 knowledge_base_ids 必填 ≥1")
    knowledge_base_ids: Optional[List[str]] = Field(None, description="智能体模式绑定的知识库 ID 列表")


class ChatUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    model_id: Optional[str] = None
    model_name: Optional[str] = Field(None, min_length=1, max_length=200)
    prompt_id: Optional[str] = None
    agent_id: Optional[str] = None
    knowledge_base_ids: Optional[List[str]] = None


class ChatResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    user_id: str
    model_id: Optional[str] = None
    model_name: Optional[str] = None
    prompt_id: Optional[str] = None
    agent_id: Optional[str] = None
    agent_type: Optional[str] = None
    knowledge_base_ids: Optional[List[str]] = None
    status: str = "idle"
    created_at: datetime
    updated_at: datetime


# --- Message ---
class MessageCreate(BaseModel):
    content: str = Field(
        ..., min_length=0, description="消息内容；空字符串用于恢复正在生成的回复"
    )


class MessageResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    chat_id: str
    role: str  # user | assistant | system
    content: str
    trace_id: Optional[str] = None
    meta: Optional[Dict[str, Any]] = None
    created_at: datetime


# --- Cancel ---
class ChatCancelResponse(BaseModel):
    id: str
    status: str
    message: str = "会话已取消"


# --- Paginated ---
T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
