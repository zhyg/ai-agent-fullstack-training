import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
from urllib.parse import quote

from app.routers import chunks


class ChunkImageURLTests(unittest.IsolatedAsyncioTestCase):
    async def test_standalone_image_uses_original_storage_key(self):
        source_key = "kb/folder/doc/图片.jpg"
        image = {
            "chunk_id": "image",
            "chunk_type": "image",
            "document_id": "doc",
            "content": f"![]({source_key})",
            "image_url": source_key,
        }
        db = Mock()
        db.query.return_value.filter.return_value.first.side_effect = [
            SimpleNamespace(kb_id="kb", storage_path=source_key),
            SimpleNamespace(id="kb"),
        ]
        signed_url = f"https://minio.test/{quote(source_key)}?signature=example"
        with (
            patch.object(chunks.es_chunk_service, "query_chunks", return_value=([image], 1)),
            patch.object(chunks.markdown_attachments, "shared_assets", return_value={}),
            patch.object(chunks.storage_service, "get_presigned_url", return_value=signed_url) as sign,
        ):
            result = await chunks.list_document_chunks("doc", 1, 50, None, {"id": "owner"}, db)

        self.assertEqual(result.items[0].image_url, signed_url)
        self.assertEqual(result.items[0].content, f"![]({signed_url})")
        self.assertTrue(sign.call_args_list)
        for call in sign.call_args_list:
            self.assertEqual(call.args[0], source_key)

    def test_embedded_image_still_uses_document_images_prefix(self):
        with patch.object(chunks.storage_service, "get_presigned_url") as sign:
            chunks._resolve_chunk_image_urls(
                {"image_url": "./images/chart.png"}, "kb", "doc", source_key="kb/folder/doc/report.md",
            )
        sign.assert_called_once_with("kb/doc/images/chart.png", expires=86400)
