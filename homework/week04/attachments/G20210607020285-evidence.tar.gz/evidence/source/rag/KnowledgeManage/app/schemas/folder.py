from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime


# --- Folder ---
class FolderCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200, description="目录名称")
    parent_id: Optional[str] = Field(None, description="父目录 ID，null 表示根目录")


class FolderUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    parent_id: Optional[str] = None
    order: Optional[int] = Field(None, ge=0)


class FolderMoveRequest(BaseModel):
    target_parent_id: Optional[str] = Field(..., description="目标父目录 ID")
    target_index: int = Field(..., ge=0, description="目标位置索引")
    auto_rename: bool = Field(True, description="同名时是否自动重命名")


class FolderResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    kb_id: str
    parent_id: Optional[str] = None
    order: int
    created_at: datetime
    updated_at: datetime


class FolderMoveResponse(BaseModel):
    folder: FolderResponse
    renamed: bool = False
    original_name: Optional[str] = None


class FolderDeleteResponse(BaseModel):
    message: str
    deleted_folders: int
    deleted_documents: int
