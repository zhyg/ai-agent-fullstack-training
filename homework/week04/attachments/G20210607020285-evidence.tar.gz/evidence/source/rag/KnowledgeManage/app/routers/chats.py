from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import StreamingResponse
from elasticsearch import ApiError, TransportError
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.models.agent import Agent
from app.models.knowledge_base import KnowledgeBase
from app.models.message import Message
from app.schemas.chat import (
    ChatCreate,
    ChatUpdate,
    ChatResponse,
    MessageCreate,
    MessageResponse,
    ChatCancelResponse,
    PaginatedResponse,
)
from app.services import agent_service, chat_service, trace_query_service
from app.services.agent_runtime import citation

router = APIRouter(prefix="/chats", tags=["会话管理"])


def _validate_kb_ids(db: Session, user_id: str, kb_ids: Optional[List[str]]) -> None:
    """知识库必选 ≥1、全部存在且属本人（FR-001/005）."""
    if not kb_ids:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="请先选择知识库")
    for kb_id in kb_ids:
        kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
        if kb is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"知识库不存在或已删除（{kb_id}）",
            )
        if kb.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"知识库不属于当前用户（{kb_id}）",
            )


def _validate_agent_binding(db: Session, user_id: str, agent_id: str, kb_ids: Optional[List[str]]) -> None:
    """智能体绑定校验：存在、启用、配置完整（FR-002）+ 知识库校验."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if agent is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="智能体不存在或已删除")
    if agent.status != "enabled":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"智能体「{agent.name}」已停用",
        )
    reasons = agent_service.config_incomplete_reasons(db, agent)
    if reasons:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="智能体配置不完整：" + "；".join(reasons),
        )
    _validate_kb_ids(db, user_id, kb_ids)


@router.get("", response_model=PaginatedResponse[ChatResponse])
async def list_chats(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取当前用户的会话列表"""
    items, total = chat_service.list_chats(db, current_user["id"], page, page_size)
    return {
        "items": [ChatResponse.model_validate(c) for c in items],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("", response_model=ChatResponse, status_code=status.HTTP_201_CREATED)
async def create_chat(
    body: ChatCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """创建新会话；agent_id 非空时校验智能体与知识库绑定（FR-001/002）."""
    if body.agent_id:
        _validate_agent_binding(db, current_user["id"], body.agent_id, body.knowledge_base_ids)
    chat = chat_service.create_chat(db, current_user["id"], body)
    return ChatResponse.model_validate(chat)


@router.put("/{chat_id}", response_model=ChatResponse)
async def update_chat(
    chat_id: str,
    body: ChatUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """更新会话（标题/模型/提示词/智能体与知识库）."""
    existing = chat_service.get_chat(db, chat_id, current_user["id"])
    if not existing:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")
    if body.agent_id is not None:
        if not existing.agent_id:
            # 存量旧模式会话（已有消息历史）拒绝切换；空白新会话允许首次绑定
            has_history = (
                db.query(Message).filter(Message.chat_id == chat_id).first() is not None
            )
            if has_history:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="存量会话不支持切换为智能体模式",
                )
        kb_ids = body.knowledge_base_ids if body.knowledge_base_ids is not None else existing.knowledge_base_ids
        _validate_agent_binding(db, current_user["id"], body.agent_id, kb_ids)
    elif body.knowledge_base_ids is not None and existing.agent_id:
        _validate_kb_ids(db, current_user["id"], body.knowledge_base_ids)
    chat = chat_service.update_chat(db, chat_id, current_user["id"], body)
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")
    return ChatResponse.model_validate(chat)


@router.delete("/{chat_id}")
async def delete_chat(
    chat_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除会话及其所有消息"""
    ok = chat_service.delete_chat(db, chat_id, current_user["id"])
    if not ok:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")
    return {"message": "会话删除成功"}


@router.get("/{chat_id}/messages", response_model=PaginatedResponse[MessageResponse])
async def list_messages(
    chat_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取会话消息列表"""
    chat = chat_service.get_chat(db, chat_id, current_user["id"])
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")

    items, total = chat_service.list_messages(db, chat_id, page, page_size)
    return {
        "items": [MessageResponse.model_validate(m) for m in items],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("/{chat_id}/messages")
async def send_message(
    chat_id: str,
    body: MessageCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """发送消息并获取流式回复（SSE）；旧模式走网关直连，agent 模式走智能体运行时."""
    chat = chat_service.get_chat(db, chat_id, current_user["id"])
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")

    if chat.agent_id:
        # agent 模式前置校验（空字符串 = reattach 恢复流，跳过）
        if body.content != "":
            if not body.content.strip() or len(body.content) > 2000:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="问题不能为空且不超过 2000 字符",
                )
            if not chat.knowledge_base_ids:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="请先选择知识库")
            now = datetime.now(timezone.utc)
            if (
                chat.status == "generating"
                and chat.lease_expires_at is not None
                and chat.lease_expires_at > now
            ):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="当前问答尚未结束，请稍候",
                )
    elif not chat.model_name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="请先选择模型")

    return StreamingResponse(
        chat_service.send_message_stream(
            chat_id, body.content, current_user["id"]
        ),
        media_type="text/event-stream",
    )


@router.post("/{chat_id}/cancel", response_model=ChatCancelResponse)
async def cancel_chat(
    chat_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """取消正在生成中的会话，通过 Redis Pub/Sub 发送取消信号"""
    try:
        chat = await chat_service.cancel_chat(db, chat_id, current_user["id"])
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))

    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")

    return ChatCancelResponse(id=chat.id, status=chat.status, message="Session cancelled")


@router.post("/{chat_id}/messages/{message_id}/refresh-urls")
async def refresh_message_urls(
    chat_id: str,
    message_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """图片预签名过期后重签（FR-013）：重签答案内容与 references 片段中的图片 URL."""
    chat = chat_service.get_chat(db, chat_id, current_user["id"])
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")
    message = (
        db.query(Message)
        .filter(Message.id == message_id, Message.chat_id == chat_id)
        .first()
    )
    if message is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="消息不存在")

    content = citation.refresh_signed_urls(message.content or "")
    meta = dict(message.meta or {})
    references = []
    for ref in meta.get("references") or []:
        ref = dict(ref)
        ref["content"] = citation.refresh_signed_urls(ref.get("content", ""))
        references.append(ref)
    if references:
        meta["references"] = references
    message.content = content
    message.meta = meta
    db.commit()
    return {"content": content, "references": references}


@router.get("/{chat_id}/messages/{message_id}/trace")
async def get_message_trace(
    chat_id: str,
    message_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """轨迹查询代理（FR-036，澄清 Q1）：归属校验后查 ES jaeger 索引，不脱敏."""
    chat = chat_service.get_chat(db, chat_id, current_user["id"])
    if not chat:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权查看该消息的轨迹")
    message = (
        db.query(Message)
        .filter(Message.id == message_id, Message.chat_id == chat_id)
        .first()
    )
    if message is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="消息不存在")
    if not message.trace_id:
        return {"ready": False, "reason": "no_trace"}
    try:
        return await trace_query_service.fetch_trace(message.trace_id, message.created_at)
    except (ApiError, TransportError):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="轨迹服务暂不可用"
        )
