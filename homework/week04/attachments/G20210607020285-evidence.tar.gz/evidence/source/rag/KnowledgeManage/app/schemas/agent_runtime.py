"""智能体运行时 Pydantic 模型：步骤 JSON 输出、SSE 事件、工具结果信封.

契约来源：contracts/chat-agent-api.md §3、contracts/tool-runtime.md §1、data-model.md §1.2/§2.5。
JSON 输出模型用于 model_validate_json 校验，校验失败进入业务重试（最多 3 次，含首次共 4 次）。
"""
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, StrictBool, StrictInt, field_validator, model_validator


# --- 步骤 JSON 输出模型 ---
class ClarifyResult(BaseModel):
    """澄清步骤输出（FR-006）."""
    clear: StrictBool
    reason: Optional[str] = None


class RewriteResult(BaseModel):
    """问题重写步骤输出（FR-007）."""
    rewritten_question: str = Field(..., min_length=1)


class CompressResult(BaseModel):
    """压缩步骤输出（FR-010）：kept_indexes 为片段列表下标；空数组合法（无相关片段）.

    越界校验依赖片段数量，运行期调用 validate_bounds()；重复/非整数在此直接校验失败。
    """
    kept_indexes: List[StrictInt]

    @field_validator("kept_indexes")
    @classmethod
    def _no_duplicates(cls, v: List[int]) -> List[int]:
        if len(v) != len(set(v)):
            raise ValueError("kept_indexes 存在重复索引")
        return v

    def validate_bounds(self, chunk_count: int) -> None:
        """越界视为校验失败（进入业务重试）；空数组合法."""
        for idx in self.kept_indexes:
            if idx < 0 or idx >= chunk_count:
                raise ValueError(f"kept_indexes 索引越界: {idx}（片段数 {chunk_count}）")


class SufficiencyResult(BaseModel):
    """充足判断步骤输出（FR-017）：不充足时 new_question 必填，充足时为 null."""
    sufficient: StrictBool
    new_question: Optional[str] = None

    @model_validator(mode="after")
    def _check_new_question(self) -> "SufficiencyResult":
        if not self.sufficient and not (self.new_question and self.new_question.strip()):
            raise ValueError("sufficient=false 时 new_question 必填")
        if self.sufficient and self.new_question is not None:
            if self.new_question.strip():
                raise ValueError("sufficient=true 时 new_question 必须为 null")
            self.new_question = None  # 空串归一化为 null，避免无谓重试
        return self


# --- SSE 事件模型（contracts/chat-agent-api.md §3） ---
StepName = Literal[
    "history_retrieve", "clarify", "rewrite", "retrieve", "rerank", "compress",
    "sufficiency", "plan_decision", "tool", "answer",
]


class StepEvent(BaseModel):
    """步骤进度事件；不含中间步骤原始模型输出（US5-5）."""
    type: Literal["step"] = "step"
    step: StepName
    status: Literal["start", "end"]
    loop: Optional[int] = None          # 仅循环步骤携带
    tool_name: Optional[str] = None     # 仅 step=tool 携带
    message: Optional[str] = None       # 进度文案，如"第 2 轮检索中"


class ReferenceItem(BaseModel):
    """引用映射元素（data-model.md §1.2 meta.references）."""
    handle: str                         # cN，从 1 递增
    chunk_id: Optional[str] = None
    document_id: str
    kb_id: str
    file_name: str
    content: str                        # 图片已替换为预签名 URL
    image_paths: List[str] = Field(default_factory=list)  # 原始路径，供 refresh-urls 重签
    score: Optional[float] = None


class ReferencesEvent(BaseModel):
    """引用映射事件：答案流开始前一次性下发（FR-013）."""
    type: Literal["references"] = "references"
    items: List[ReferenceItem] = Field(default_factory=list)


# --- 工具结果信封（contracts/tool-runtime.md §1） ---
ToolResultCode = Literal[
    "ok", "empty_result", "invalid_args", "execution_failed",
    "forbidden_sql", "url_not_allowed", "cancelled",
]


class ToolResult(BaseModel):
    """统一工具结果信封；失败/空结果一律回传模型继续决策（FR-025）."""
    success: bool
    code: ToolResultCode
    content: str
    artifact_path: Optional[str] = None

    def to_model_message(self, call_id: str) -> Dict[str, Any]:
        """回传模型的 OpenAI tool 消息."""
        return {
            "role": "tool",
            "tool_call_id": call_id,
            "content": self.model_dump_json(),
        }