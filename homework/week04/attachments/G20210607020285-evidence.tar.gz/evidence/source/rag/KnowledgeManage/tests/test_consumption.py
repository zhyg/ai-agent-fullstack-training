import re
import unittest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, patch

import httpx
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.routers import consumption as consumption_router
from app.schemas.consumption import BJ_TZ
from app.services import consumption_service as svc

# 015-resource-consumption-monitor US1 测试（T011，quickstart 场景 1）：
# mock Prometheus HTTP（prom_get）与 UserManage email 解析，沿用 patch decode_token 模式


def admin_claims():
    return {"type": "access", "sub": "u-admin", "uid": "admin", "permissions": ["permission_manage"]}


def user_claims():
    return {"type": "access", "sub": "u-1", "uid": "user", "permissions": []}


def prev_month():
    """上一个完整自然月（YYYY-MM），与运行日期无关。"""
    now = datetime.now(BJ_TZ)
    return (now.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")


def next_month():
    now = datetime.now(BJ_TZ)
    return (now.replace(day=28) + timedelta(days=7)).strftime("%Y-%m")


class PromRecorder:
    """prom_get 替身：记录调用并按 handler 返回数据。"""

    def __init__(self, handler=None):
        self.calls = []
        self.handler = handler or (lambda path, params: {"result": []})

    async def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        return self.handler(path, params)

    @property
    def queries(self):
        return [p["query"] for path, p in self.calls if path == "/api/v1/query"]


def window_of(query):
    return int(re.search(r"\[(\d+)s\]", query).group(1))


class ConsumptionTestBase(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(consumption_router.router)
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=admin_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)
        self.email = patch.object(svc, "resolve_current_email",
                                  new=AsyncMock(return_value="admin@example.com"))
        self.email.start()
        self.addCleanup(self.email.stop)

    def set_normal_user(self, email="user@example.com"):
        self.auth.stop()
        self.auth = patch("app.dependencies.decode_token", return_value=user_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)
        self.email.stop()
        self.email = patch.object(svc, "resolve_current_email", new=AsyncMock(return_value=email))
        self.email.start()
        self.addCleanup(self.email.stop)  # 新 patcher 必须重新注册清理，避免泄漏到后续用例

    def use_prom(self, handler=None):
        rec = PromRecorder(handler)
        p = patch.object(svc, "prom_get", new=rec)
        p.start()
        self.addCleanup(p.stop)
        return rec

    def get_series(self, **params):
        # 默认当前月：上一完整月可能整体超出保留期（R-005）
        base = dict(metric="tokens", scope="user_daily",
                    user_email="admin@example.com", month=datetime.now(BJ_TZ).strftime("%Y-%m"))
        base.update(params)
        return self.client.get("/consumption/series", params=base, headers=self.headers)


class SeriesAuthTests(ConsumptionTestBase):
    def test_requires_auth(self):
        res = self.client.get("/consumption/series", params={
            "metric": "tokens", "scope": "user_daily",
            "user_email": "admin@example.com", "month": prev_month()})
        self.assertIn(res.status_code, (401, 403))

    def test_normal_user_other_email_403(self):
        self.set_normal_user()
        self.use_prom()
        res = self.get_series(user_email="other@example.com")
        self.assertEqual(res.status_code, 403)
        self.assertEqual(res.json()["detail"], "无权查看其他用户的消耗数据")

    def test_normal_user_own_email_ok(self):
        self.set_normal_user()
        self.use_prom()
        res = self.get_series(user_email="user@example.com")
        self.assertEqual(res.status_code, 200)

    def test_normal_user_all_monthly_403(self):
        self.set_normal_user()
        self.use_prom()
        res = self.get_series(scope="all_monthly", user_email=None,
                              month=None, year=datetime.now(BJ_TZ).year)
        self.assertEqual(res.status_code, 403)


class SeriesValidationTests(ConsumptionTestBase):
    def test_future_month_400(self):
        self.use_prom()
        res = self.get_series(month=next_month())
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json()["detail"], "不可查询未来期间")

    def test_bad_month_format_400(self):
        self.use_prom()
        res = self.get_series(month="2026-13")
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json()["detail"], "month 格式须为 YYYY-MM")

    def test_future_year_400(self):
        self.use_prom()
        res = self.get_series(scope="user_monthly", month=None,
                              year=datetime.now(BJ_TZ).year + 1)
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json()["detail"], "不可查询未来期间")

    def test_missing_user_email_400(self):
        self.use_prom()
        res = self.get_series(user_email=None)
        self.assertEqual(res.status_code, 400)


class SeriesBucketTests(ConsumptionTestBase):
    def test_current_month_truncated_to_today(self):
        rec = self.use_prom()
        now = datetime.now(BJ_TZ)
        res = self.get_series(month=now.strftime("%Y-%m"))
        self.assertEqual(res.status_code, 200)
        buckets = res.json()["buckets"]
        self.assertEqual(len(buckets), now.day)
        self.assertEqual(buckets[-1], now.strftime("%Y-%m-%d"))
        windows = [window_of(q) for q in rec.queries]
        self.assertEqual(len(windows), now.day)
        self.assertTrue(all(w == 86400 for w in windows[:-1]))
        self.assertLess(windows[-1], 86400)  # 末桶 partial：截至当前

    def test_past_month_full_days(self):
        # 直接验证切桶（完整历史月可能超保留期，不经 HTTP 路径）
        month = prev_month()
        buckets = svc.build_buckets("user_daily", month=month)
        first = datetime.strptime(month, "%Y-%m")
        nxt = (first.replace(year=first.year + 1, month=1) if first.month == 12
               else first.replace(month=first.month + 1))
        days = (nxt - first).days
        self.assertEqual(len(buckets), days)
        self.assertTrue(all(b.window_seconds == 86400 and not b.partial for b in buckets))

    def test_current_year_truncated_to_month(self):
        self.use_prom()
        now = datetime.now(BJ_TZ)
        res = self.get_series(scope="user_monthly", month=None, year=now.year)
        buckets = res.json()["buckets"]
        self.assertEqual(len(buckets), now.month)
        self.assertEqual(buckets[-1], now.strftime("%Y-%m"))

    def test_past_year_12_months(self):
        buckets = svc.build_buckets("user_monthly", year=datetime.now(BJ_TZ).year - 1)
        self.assertEqual(len(buckets), 12)
        self.assertTrue(all(not b.partial for b in buckets))

    def test_out_of_retention(self):
        rec = self.use_prom()
        res = self.get_series(month="2020-01")
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertTrue(body["out_of_retention"])
        self.assertEqual(body["buckets"], [])
        self.assertEqual(body["series"], [])
        self.assertEqual(rec.calls, [])  # 超保留期不发 Prometheus 查询


class SeriesPromQLTests(ConsumptionTestBase):
    def test_token_promql_filters_and_fold(self):
        rec = self.use_prom()
        self.get_series(models="m1,m2")
        q = rec.queries[0]
        self.assertIn("llm_tokens_total", q)
        self.assertIn('type!="cached"', q)
        self.assertIn("sum by (model)", q)
        self.assertIn('user_email="admin@example.com"', q)
        self.assertIn('model=~"m1|m2"', q)

    def test_all_select_omits_model_filter(self):
        rec = self.use_prom()
        self.get_series(models="")
        self.assertNotIn("model=~", rec.queries[0])

    def test_zero_fill_alignment(self):
        month = datetime.now(BJ_TZ).strftime("%Y-%m")
        # 首桶 end=次日零点，确定性时间戳（末桶 partial 随 now 漂移，不用）
        ends = [b.end.timestamp() for b in svc.build_buckets("user_daily", month=month)]

        def handler(path, params):
            if params["time"] == ends[0]:
                return {"result": [{"metric": {"model": "m1"}, "value": [params["time"], "100"]}]}
            return {"result": []}

        self.use_prom(handler)
        res = self.get_series(month=month, models="m1")
        body = res.json()
        self.assertEqual(len(body["series"]), 1)
        values = body["series"][0]["values"]
        self.assertEqual(len(values), len(body["buckets"]))
        self.assertEqual(values[0], 100)
        self.assertTrue(all(v == 0 for v in values[1:]))

    def test_explicit_model_zero_curve_returned(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "5"]}]})
        res = self.get_series(models="m1,m2")
        series = {s["model"]: s["values"] for s in res.json()["series"]}
        self.assertEqual(sorted(series), ["m1", "m2"])
        self.assertTrue(all(v == 0 for v in series["m2"]))

    def test_all_select_only_seen_models(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "5"]}]})
        res = self.get_series()
        self.assertEqual([s["model"] for s in res.json()["series"]], ["m1"])

    def test_negative_clamped_to_zero(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "-5"]}]})
        res = self.get_series(models="m1")
        self.assertTrue(all(v == 0 for v in res.json()["series"][0]["values"]))

    def test_model_name_dash_not_escaped(self):
        # 回归：re.escape 会把 '-' 转成 \-，PromQL 报 unknown escape sequence U+002D
        q = svc.build_query("tokens", None, ["sgm-deepseek-v-flash", "BAAI/bge-m3"], 3600)
        self.assertIn('model=~"sgm-deepseek-v-flash|BAAI/bge-m3"', q)
        self.assertNotIn("\\", q)

    def test_model_name_regex_metachar_escaped(self):
        # '.' 是 RE2 元字符：正则层转义后再经 PromQL 字符串层双写反斜杠
        q = svc.build_query("tokens", None, ["gpt-4.1"], 3600)
        self.assertIn('model=~"gpt-4\\\\.1"', q)


class CostMetricTests(ConsumptionTestBase):
    """US2 T017：费用口径（FR-015，quickstart 场景 1 精度项）。"""

    def test_cost_promql_no_type_filter(self):
        rec = self.use_prom()
        self.get_series(metric="cost", models="m1")
        q = rec.queries[0]
        self.assertIn("llm_cost_estimate_total", q)  # 活体核验：counter 实际名带 _total 后缀
        self.assertNotIn("llm_tokens_total", q)
        self.assertNotIn("type!=", q)  # cost 指标无 type 标签
        self.assertIn("sum by (model)", q)
        self.assertIn('user_email="admin@example.com"', q)
        self.assertIn('model=~"m1"', q)

    def test_cost_small_value_not_rounded_to_zero(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "0.000123"]}]})
        res = self.get_series(metric="cost", models="m1")
        values = res.json()["series"][0]["values"]
        self.assertTrue(all(v == 0.000123 for v in values))  # SC-005 小额不舍入为 0

    def test_cost_round_6_decimals(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "0.0001234567"]}]})
        res = self.get_series(metric="cost", models="m1")
        self.assertTrue(all(v == 0.000123 for v in res.json()["series"][0]["values"]))

    def test_cost_negative_clamped(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "-0.5"]}]})
        res = self.get_series(metric="cost", models="m1")
        self.assertTrue(all(v == 0 for v in res.json()["series"][0]["values"]))

    def test_cost_monthly_buckets_same_as_tokens(self):
        self.use_prom()
        now = datetime.now(BJ_TZ)
        res = self.get_series(metric="cost", scope="user_monthly", month=None, year=now.year)
        buckets = res.json()["buckets"]
        self.assertEqual(len(buckets), now.month)  # 人月口径与 token 一致
        self.assertEqual(buckets[-1], now.strftime("%Y-%m"))

    def test_cost_zero_fill_explicit_model(self):
        self.use_prom(lambda path, params: {
            "result": [{"metric": {"model": "m1"}, "value": [params["time"], "0.5"]}]})
        res = self.get_series(metric="cost", models="m1,m2")
        series = {s["model"]: s["values"] for s in res.json()["series"]}
        self.assertEqual(sorted(series), ["m1", "m2"])
        self.assertTrue(all(v == 0 for v in series["m2"]))


class AdminPermissionTests(ConsumptionTestBase):
    """US3 T022：权限矩阵扩展至 cost 与 all_monthly（SC-002，FR-003/004/011）。"""

    def test_admin_any_user_allowed_both_metrics(self):
        for metric in ("tokens", "cost"):
            rec = self.use_prom()
            res = self.get_series(metric=metric, user_email="other@example.com")
            self.assertEqual(res.status_code, 200)
            self.assertIn('user_email="other@example.com"', rec.queries[0])

    def test_admin_all_monthly_no_email_filter_both_metrics(self):
        now = datetime.now(BJ_TZ)
        for metric in ("tokens", "cost"):
            rec = self.use_prom()
            res = self.get_series(metric=metric, scope="all_monthly", user_email=None,
                                  month=None, year=now.year)
            self.assertEqual(res.status_code, 200)
            self.assertEqual(len(res.json()["buckets"]), now.month)
            for q in rec.queries:
                self.assertNotIn("user_email", q)  # 跨用户求和（含空 email 数据）
                self.assertIn("sum by (model)", q)

    def test_admin_all_monthly_ignores_user_email_param(self):
        rec = self.use_prom()
        res = self.get_series(scope="all_monthly", user_email="other@example.com",
                              month=None, year=datetime.now(BJ_TZ).year)
        self.assertEqual(res.status_code, 200)
        self.assertNotIn("user_email", rec.queries[0])

    def test_normal_user_all_monthly_403_both_metrics(self):
        self.set_normal_user()
        self.use_prom()
        for metric in ("tokens", "cost"):
            res = self.get_series(metric=metric, scope="all_monthly", user_email=None,
                                  month=None, year=datetime.now(BJ_TZ).year)
            self.assertEqual(res.status_code, 403)
            self.assertEqual(res.json()["detail"], "无权查看全员消耗数据")

    def test_normal_user_other_email_cost_403(self):
        self.set_normal_user()
        self.use_prom()
        res = self.get_series(metric="cost", user_email="other@example.com")
        self.assertEqual(res.status_code, 403)
        self.assertEqual(res.json()["detail"], "无权查看其他用户的消耗数据")


class SeriesFailureTests(ConsumptionTestBase):
    def test_prometheus_down_502(self):
        with patch.object(httpx.AsyncClient, "get",
                          new=AsyncMock(side_effect=httpx.ConnectError("down"))):
            res = self.get_series()
        self.assertEqual(res.status_code, 502)
        self.assertEqual(res.json()["detail"], "指标数据源不可用")

    def test_email_resolve_fail_502(self):
        self.email.stop()
        with patch.object(httpx.AsyncClient, "get",
                          new=AsyncMock(side_effect=httpx.ConnectError("down"))):
            res = self.get_series()
        self.assertEqual(res.status_code, 502)
        self.assertEqual(res.json()["detail"], "无法解析当前用户身份")


class OptionsTests(ConsumptionTestBase):
    def label_handler(self, path, params):
        if path == "/api/v1/label/model/values":
            return ["m2", "m1", ""]
        if path == "/api/v1/label/user_email/values":
            return ["b@example.com", "a@example.com", ""]
        raise AssertionError(f"unexpected path {path}")

    def test_regular_user_only_own_email(self):
        self.set_normal_user()
        rec = self.use_prom(self.label_handler)
        res = self.client.get("/consumption/options", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertEqual(body["user_emails"], ["user@example.com"])
        self.assertEqual(body["models"], ["m1", "m2"])  # 排除空串、升序
        self.assertFalse(body["is_admin"])
        self.assertFalse(any("user_email/values" in p for p, _ in rec.calls))

    def test_admin_all_emails(self):
        self.use_prom(self.label_handler)
        res = self.client.get("/consumption/options", headers=self.headers)
        body = res.json()
        self.assertEqual(body["user_emails"], ["a@example.com", "b@example.com"])
        self.assertTrue(body["is_admin"])

    def test_options_prometheus_down_502(self):
        with patch.object(httpx.AsyncClient, "get",
                          new=AsyncMock(side_effect=httpx.ConnectError("down"))):
            res = self.client.get("/consumption/options", headers=self.headers)
        self.assertEqual(res.status_code, 502)


if __name__ == "__main__":
    unittest.main()