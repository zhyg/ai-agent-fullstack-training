"""AI question generation service — generate search questions from chunk content."""

import json
import logging
from typing import List

import httpx

from app.core.config import settings
from app.services.embedding_service import resolve_model_name

logger = logging.getLogger(__name__)

# Chunk types eligible for AI question generation
ELIGIBLE_CHUNK_TYPES = {"text", "image_ocr", "table_row"}


async def generate_questions(
    chunk_content: str,
    count: int,
    llm_model_id: str,
    api_key: "[REDACTED]"
) -> List[str]:
    """Generate AI questions from chunk content using LLM.

    Args:
        chunk_content: The text content of the chunk
        count: Number of questions to generate (1-10)
        llm_model_id: LLM model ID from knowledge base config
        api_key: "[REDACTED]"

    Returns:
        List of generated question strings
    """
    if not chunk_content.strip():
        return []

    gateway_url = settings.services.get("llm_gateway", "http://localhost:8003")
    llm_api_key = "[REDACTED]"

    prompt = f"""根据以下内容生成 {count} 个用于检索的问题。这些问题应该能够帮助用户找到这段内容。
请直接返回 JSON 数组格式，例如：["问题1", "问题2", "问题3"]

内容：
{chunk_content[:2000]}

请以 JSON 数组格式返回 {count} 个问题："""

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{gateway_url}/api/llm/v1/chat/completions",
                json={
                    "model": resolve_model_name(llm_model_id),
                    "messages": [
                        {"role": "user", "content": prompt},
                    ],
                    "stream": False,
                },
                headers={
                    "Authorization": f"Bearer {llm_api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
    except httpx.HTTPError as e:
        logger.error("AI question generation API call failed: %s", e)
        raise RuntimeError(f"AI 问题生成服务不可用: {e}") from e

    result = resp.json()
    choices = result.get("choices", [])
    if not choices:
        return []

    response_text = choices[0].get("message", {}).get("content", "").strip()

    # Parse JSON array from response
    questions = _parse_questions_json(response_text)
    return questions[:count]


def _parse_questions_json(text: str) -> List[str]:
    """Parse questions from LLM response, handling various formats."""
    # Try direct JSON parse
    try:
        result = json.loads(text)
        if isinstance(result, list):
            return [str(q).strip() for q in result if str(q).strip()]
    except (json.JSONDecodeError, TypeError):
        pass

    # Try to find JSON array in the text
    import re
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        try:
            result = json.loads(match.group())
            if isinstance(result, list):
                return [str(q).strip() for q in result if str(q).strip()]
        except (json.JSONDecodeError, TypeError):
            pass

    # Fallback: split by newlines or numbered items
    lines = text.strip().split("\n")
    questions = []
    for line in lines:
        line = line.strip()
        # Remove numbering prefixes like "1.", "1)", "-", etc.
        cleaned = re.sub(r"^\d+[\.\)\uff0e\u3001]\s*", "", line)
        cleaned = cleaned.strip("- \u2022")
        if cleaned and len(cleaned) > 5:
            questions.append(cleaned)

    return questions


def is_eligible_for_questions(chunk_type: str) -> bool:
    """Check if a chunk type is eligible for AI question generation."""
    return chunk_type in ELIGIBLE_CHUNK_TYPES
