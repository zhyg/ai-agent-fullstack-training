"""MinIO client singleton wrapper."""

import logging

from minio import Minio

from app.core.config import settings

logger = logging.getLogger(__name__)

_client: Minio | None = None


def get_client() -> Minio:
    """Return the singleton MinIO client, creating it on first call."""
    global _client
    if _client is None:
        cfg = settings.minio
        _client = Minio(
            endpoint=cfg.endpoint,
            access_key="[REDACTED]"
            secret_key="[REDACTED]"
            secure=cfg.secure,
        )
        logger.info("MinIO client initialized (endpoint=%s)", cfg.endpoint)
    return _client


def get_bucket() -> str:
    """Return the configured bucket name."""
    return settings.minio.bucket


def ensure_bucket_exists() -> None:
    """Create the bucket if it does not exist."""
    client = get_client()
    bucket = get_bucket()
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
        logger.info("MinIO bucket '%s' created", bucket)
