import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, BigInteger, Text, TIMESTAMP, Index, ForeignKey

from app.core.database import Base
from app.core.config import settings


class Document(Base):
    __tablename__ = "documents"
    __table_args__ = (
        Index("idx_document_folder", "folder_id"),
        Index("idx_document_kb", "kb_id"),
        Index("idx_document_status", "status"),
        Index("idx_document_kb_status", "kb_id", "status"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(500), nullable=False, comment="文件名称（含扩展名）")
    description = Column(String(1000), nullable=True, comment="文档描述")
    tags = Column(Text, nullable=False, default="[]", comment="标签列表 JSON 数组")
    file_size = Column(BigInteger, nullable=False, comment="文件大小（字节）")
    mime_type = Column(String(200), nullable=True, comment="MIME 类型")
    extension = Column(String(50), nullable=True, comment="文件扩展名（不含点号）")
    status = Column(
        String(30), nullable=False, default="pending",
        comment="处理状态: pending/parsing/chunking/embedding/ai_generating/completed/failed",
    )
    storage_path = Column(String(1000), nullable=False, comment="MinIO 对象路径")
    md_path = Column(String(1000), nullable=True, comment="MinIO 转换后 markdown 文件路径")
    chunk_config = Column(Text, nullable=True, comment="分块配置 JSON（策略/大小/重叠/分隔符）")
    ai_question_count = Column(
        Integer, nullable=True, default=3,
        comment="AI 问题生成数量",
    )
    skipped_files = Column(
        Text, nullable=True,
        comment="压缩包中跳过的不支持文件列表 JSON",
    )
    error_message = Column(
        Text, nullable=True,
        comment="处理失败时的错误信息",
    )
    folder_id = Column(
        String(36),
        ForeignKey(f"{settings.database.db_schema}.folders.id", ondelete="CASCADE"),
        nullable=False,
        comment="所属目录 ID",
    )
    kb_id = Column(
        String(36),
        ForeignKey(f"{settings.database.db_schema}.knowledge_bases.id", ondelete="CASCADE"),
        nullable=False,
        comment="所属知识库 ID",
    )
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
