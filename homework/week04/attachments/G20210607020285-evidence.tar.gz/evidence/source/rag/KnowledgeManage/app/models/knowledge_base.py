import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, TIMESTAMP, Index, UniqueConstraint

from app.core.database import Base
from app.core.config import settings


class KnowledgeBase(Base):
    __tablename__ = "knowledge_bases"
    __table_args__ = (
        UniqueConstraint('user_id', 'name', name='uq_kb_user_name'),
        Index("idx_kb_user", "user_id"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False, comment="知识库名称")
    description = Column(String(500), nullable=True, comment="知识库描述")
    user_id = Column(String(36), nullable=False, comment="所属用户 ID")
    llm_model_id = Column(String(36), nullable=False, comment="LLM 模型 ID")
    embedding_model_id = Column(String(36), nullable=False, comment="Embedding 模型 ID")
    image_model_id = Column(String(36), nullable=False, comment="图片识别模型 ID")
    rerank_model_id = Column(String(36), nullable=False, comment="Rerank 模型 ID")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )
