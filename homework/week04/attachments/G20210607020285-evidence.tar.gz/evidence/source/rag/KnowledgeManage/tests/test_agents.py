import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import ValidationError

from app.core.database import get_db
from app.models.agent import Agent
from app.models.prompt import Prompt
from app.routers import agents as agents_router
from app.schemas.agent import AgentConfig, AgentUpdate, PROMPT_PURPOSES_BY_TYPE, TOOL_KEYS
from app.services import agent_service
from app.services.agent_service import NameConflictError


NOW = datetime(2026, 11, 22, tzinfo=timezone.utc)

PRESET_DESCRIPTIONS = {
    "quick_qa": "提供快速问答功能，用户输入问题，直接检索回答",
    "reasoning_action": "提供react的多轮推理功能",
    "planning_reasoning": "提供plan+react的智能规划、多轮推理功能",
}


def make_agent(**overrides):
    base = dict(
        id="agent-1", type="quick_qa", name="快速问答", icon="thunderbolt",
        description=PRESET_DESCRIPTIONS["quick_qa"], status="enabled",
        config={"prompts": {}, "retrieval": {"mode": "vector"}, "models": {}},
        created_at=NOW, updated_at=NOW,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def admin_claims():
    return {"type": "access", "sub": "u-admin", "uid": "admin", "permissions": ["permission_manage"]}


def user_claims():
    return {"type": "access", "sub": "u-1", "uid": "user", "permissions": []}


class AgentRouterTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(agents_router.router)
        self.db = MagicMock()
        app.dependency_overrides[get_db] = lambda: self.db
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=admin_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)

    def set_normal_user(self):
        self.auth.stop()
        self.auth = patch("app.dependencies.decode_token", return_value=user_claims())
        self.auth.start()

    def test_list_agents_returns_all_items(self):
        fakes = [
            make_agent(),
            make_agent(id="agent-2", type="reasoning_action", name="推理行动", icon="bulb"),
            make_agent(id="agent-3", type="planning_reasoning", name="规划推理", icon="partition", status="disabled"),
        ]
        with patch.object(agent_service, "list_agents", return_value=fakes):
            res = self.client.get("/agents", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        items = res.json()["items"]
        self.assertEqual(len(items), 3)
        self.assertEqual(items[2]["status"], "disabled")
        self.assertEqual(items[0]["name"], "快速问答")

    def test_get_agent_detail(self):
        with patch.object(agent_service, "get_agent", return_value=make_agent()):
            res = self.client.get("/agents/agent-1", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["id"], "agent-1")

    def test_get_agent_not_found(self):
        with patch.object(agent_service, "get_agent", return_value=None):
            res = self.client.get("/agents/missing", headers=self.headers)
        self.assertEqual(res.status_code, 404)
        self.assertEqual(res.json()["detail"], "智能体不存在")

    def test_patch_status_disable_then_enable(self):
        disabled = make_agent(status="disabled")
        enabled = make_agent(status="enabled")
        with patch.object(agent_service, "set_status", side_effect=[disabled, enabled]) as mock_set:
            res1 = self.client.patch("/agents/agent-1/status", json={"status": "disabled"}, headers=self.headers)
            res2 = self.client.patch("/agents/agent-1/status", json={"status": "enabled"}, headers=self.headers)
        self.assertEqual(res1.status_code, 200)
        self.assertEqual(res1.json()["status"], "disabled")
        self.assertEqual(res2.json()["status"], "enabled")
        self.assertEqual(mock_set.call_count, 2)

    def test_patch_status_idempotent(self):
        disabled = make_agent(status="disabled")
        with patch.object(agent_service, "set_status", return_value=disabled):
            res1 = self.client.patch("/agents/agent-1/status", json={"status": "disabled"}, headers=self.headers)
            res2 = self.client.patch("/agents/agent-1/status", json={"status": "disabled"}, headers=self.headers)
        self.assertEqual(res1.status_code, 200)
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res1.json(), res2.json())

    def test_patch_status_invalid_value_400(self):
        res = self.client.patch("/agents/agent-1/status", json={"status": "paused"}, headers=self.headers)
        self.assertEqual(res.status_code, 400)

    def test_patch_status_not_found_404(self):
        with patch.object(agent_service, "set_status", return_value=None):
            res = self.client.patch("/agents/missing/status", json={"status": "disabled"}, headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_normal_user_read_ok_write_forbidden(self):
        self.set_normal_user()
        with patch.object(agent_service, "list_agents", return_value=[make_agent()]):
            res_get = self.client.get("/agents", headers=self.headers)
        res_patch = self.client.patch("/agents/agent-1/status", json={"status": "disabled"}, headers=self.headers)
        self.assertEqual(res_get.status_code, 200)
        self.assertEqual(res_patch.status_code, 403)
        self.assertIn("permission_manage", res_patch.json()["detail"])

    def test_no_create_or_delete_endpoints(self):
        res_post = self.client.post("/agents", json={}, headers=self.headers)
        res_delete = self.client.delete("/agents/agent-1", headers=self.headers)
        self.assertEqual(res_post.status_code, 405)
        self.assertEqual(res_delete.status_code, 405)


class AgentServiceTests(unittest.TestCase):
    def setUp(self):
        self.db = MagicMock()
        self.agent = make_agent()
        self.db.query.return_value.filter.return_value.first.return_value = self.agent

    def test_set_status_changes_status_and_keeps_config(self):
        original_config = self.agent.config
        result = agent_service.set_status(self.db, "agent-1", "disabled")
        self.assertEqual(result.status, "disabled")
        self.assertIs(result.config, original_config)
        self.db.commit.assert_called_once()

    def test_set_status_same_status_is_idempotent_no_commit(self):
        result = agent_service.set_status(self.db, "agent-1", "enabled")
        self.assertEqual(result.status, "enabled")
        self.db.commit.assert_not_called()

    def test_set_status_invalid_value_raises(self):
        with self.assertRaises(ValueError):
            agent_service.set_status(self.db, "agent-1", "paused")

    def test_set_status_missing_agent_returns_none(self):
        self.db.query.return_value.filter.return_value.first.return_value = None
        self.assertIsNone(agent_service.set_status(self.db, "missing", "disabled"))

    def test_get_agent_missing_returns_none(self):
        self.db.query.return_value.filter.return_value.first.return_value = None
        self.assertIsNone(agent_service.get_agent(self.db, "missing"))

    def test_list_agents_fixed_type_order(self):
        shuffled = [
            make_agent(id="agent-2", type="reasoning_action", name="推理行动", icon="bulb"),
            make_agent(id="agent-3", type="planning_reasoning", name="规划推理", icon="partition"),
            make_agent(),
        ]
        self.db.query.return_value.all.return_value = shuffled
        result = agent_service.list_agents(self.db)
        self.assertEqual(
            [a.type for a in result],
            ["quick_qa", "reasoning_action", "planning_reasoning"],
        )


def _db_available():
    try:
        from app.core.database import engine
        from sqlalchemy import text
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False


@unittest.skipUnless(_db_available(), "PostgreSQL 不可达，跳过预置数据核验")
class AgentPresetTests(unittest.TestCase):
    def test_three_presets_exist_with_correct_defaults(self):
        from app.core.database import SessionLocal
        db = SessionLocal()
        try:
            rows = db.query(Agent).all()
            self.assertEqual(len(rows), 3)
            by_type = {a.type: a for a in rows}
            self.assertEqual(set(by_type), set(PRESET_DESCRIPTIONS))
            for agent_type, agent in by_type.items():
                self.assertEqual(agent.description, PRESET_DESCRIPTIONS[agent_type])
                self.assertEqual(agent.status, "enabled")
                cfg = agent.config
                self.assertEqual(cfg["retrieval"], {
                    "mode": "vector", "vector_top_k": 20, "keyword_top_k": 20,
                    "hybrid_top_k": 20, "rerank_top_n": 15,
                })
                self.assertEqual(cfg["models"]["max_output_tokens"], 5000)
            self.assertNotIn("loop_count", by_type["quick_qa"].config)
            self.assertEqual(by_type["reasoning_action"].config["loop_count"], 10)
            self.assertEqual(by_type["planning_reasoning"].config["loop_count"], 100)
            self.assertEqual(len(by_type["planning_reasoning"].config["tools"]), 13)
        finally:
            db.close()


def valid_payload(agent_type="quick_qa", **overrides):
    prompts = {p: f"prompt-{p}" for p in PROMPT_PURPOSES_BY_TYPE[agent_type]}
    config = {
        "prompts": prompts,
        "retrieval": {"mode": "vector", "vector_top_k": 20, "keyword_top_k": 20, "hybrid_top_k": 20, "rerank_top_n": 15},
        "models": {"analysis_model_id": "m-1", "max_output_tokens": 5000, "embedding_model_id": "m-2", "rerank_model_id": "m-3"},
    }
    if agent_type == "reasoning_action":
        config["loop_count"] = 10
    if agent_type == "planning_reasoning":
        config["loop_count"] = 100
        config["tools"] = list(TOOL_KEYS)
    payload = {"name": "快速问答", "icon": "thunderbolt", "description": "desc", "config": config}
    payload.update(overrides)
    return payload


class AgentUpdateSchemaTests(unittest.TestCase):
    def test_out_of_range_values_rejected(self):
        for field, bad_values in [
            ("vector_top_k", [0, 101]),
            ("keyword_top_k", [0, 101]),
            ("hybrid_top_k", [0, 101]),
            ("rerank_top_n", [0, 101]),
        ]:
            for value in bad_values:
                payload = valid_payload()
                payload["config"]["retrieval"][field] = value
                with self.assertRaises(ValidationError, msg=f"{field}={value}"):
                    AgentUpdate.model_validate(payload)
        for value in [0, 50001]:
            payload = valid_payload()
            payload["config"]["models"]["max_output_tokens"] = value
            with self.assertRaises(ValidationError):
                AgentUpdate.model_validate(payload)
        for value in [0, 1001]:
            payload = valid_payload("reasoning_action")
            payload["config"]["loop_count"] = value
            with self.assertRaises(ValidationError):
                AgentUpdate.model_validate(payload)

    def test_boundary_values_accepted(self):
        payload = valid_payload()
        payload["config"]["retrieval"].update(vector_top_k=1, keyword_top_k=100, hybrid_top_k=1, rerank_top_n=100)
        payload["config"]["models"]["max_output_tokens"] = 50000
        data = AgentUpdate.model_validate(payload)
        self.assertEqual(data.config.retrieval.vector_top_k, 1)
        payload = valid_payload("reasoning_action")
        payload["config"]["loop_count"] = 1000
        self.assertEqual(AgentUpdate.model_validate(payload).config.loop_count, 1000)

    def test_status_and_type_ignored(self):
        payload = valid_payload()
        payload["status"] = "disabled"
        payload["type"] = "planning_reasoning"
        data = AgentUpdate.model_validate(payload)
        self.assertFalse(hasattr(data, "status"))
        self.assertFalse(hasattr(data, "type"))

    def test_invalid_tool_key_rejected(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["tools"] = ["notATool"]
        with self.assertRaises(ValidationError):
            AgentUpdate.model_validate(payload)

    def test_invalid_icon_rejected(self):
        with self.assertRaises(ValidationError):
            AgentUpdate.model_validate(valid_payload(icon="uploaded-image"))


class AgentUpdateServiceTests(unittest.TestCase):
    def setUp(self):
        self.db = MagicMock()
        self.agent = make_agent()
        self.get_patcher = patch.object(agent_service, "get_agent", return_value=self.agent)
        self.get_patcher.start()
        self.addCleanup(self.get_patcher.stop)
        # FR-020 保存校验依赖跨 schema 模型解析，单测 mock 掉
        self.resolve_patcher = patch(
            "app.services.agent_runtime.llm_client.resolve_model",
            return_value={"name": "gpt-test", "context_tokens": 128000, "category": "chat"},
        )
        self.resolve_patcher.start()
        self.addCleanup(self.resolve_patcher.stop)

        def query(model):
            q = MagicMock()
            if model is Agent:
                q.filter.return_value.first.return_value = None  # 无重名
            elif model is Prompt:
                q.filter.return_value.first.return_value = SimpleNamespace(id="p")
            return q

        self.db.query.side_effect = query

    def test_valid_update_persists_and_trims_quick_qa(self):
        payload = valid_payload()
        payload["config"]["loop_count"] = 99
        payload["config"]["tools"] = list(TOOL_KEYS)
        data = AgentUpdate.model_validate(payload)
        result = agent_service.update_agent(self.db, "agent-1", data)
        self.assertEqual(result.name, "快速问答")
        self.assertNotIn("loop_count", result.config)
        self.assertNotIn("tools", result.config)
        self.assertEqual(set(result.config["prompts"]), set(PROMPT_PURPOSES_BY_TYPE["quick_qa"]))
        self.db.commit.assert_called_once()

    def test_duplicate_name_raises_conflict(self):
        self.agent.name = "旧名称"
        q = MagicMock()
        q.filter.return_value.first.return_value = make_agent(id="agent-2", name="快速问答")
        self.db.query.side_effect = lambda model: q if model is Agent else MagicMock()
        with self.assertRaises(NameConflictError):
            agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(valid_payload()))

    def test_missing_required_prompt_raises(self):
        payload = valid_payload()
        payload["config"]["prompts"]["clarify"] = None
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))

    def test_invalid_prompt_reference_raises(self):
        def query(model):
            q = MagicMock()
            q.filter.return_value.first.return_value = None  # 提示词不存在
            return q
        self.db.query.side_effect = query
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(valid_payload()))

    def test_missing_analysis_model_raises(self):
        payload = valid_payload()
        payload["config"]["models"]["analysis_model_id"] = None
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))

    def test_embedding_required_for_vector_optional_for_keyword(self):
        payload = valid_payload()
        payload["config"]["models"]["embedding_model_id"] = None
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))
        payload["config"]["retrieval"]["mode"] = "keyword"
        result = agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))
        self.assertIsNone(result.config["models"]["embedding_model_id"])

    def test_reasoning_action_keeps_loop_strips_tools(self):
        self.agent.type = "reasoning_action"
        payload = valid_payload("reasoning_action")
        payload["config"]["tools"] = list(TOOL_KEYS)
        result = agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))
        self.assertEqual(result.config["loop_count"], 10)
        self.assertNotIn("tools", result.config)
        self.assertIn("sufficiency", result.config["prompts"])

    def test_planning_unchecked_tool_makes_prompt_optional(self):
        self.agent.type = "planning_reasoning"
        payload = valid_payload("planning_reasoning")
        payload["config"]["tools"] = [k for k in TOOL_KEYS if k not in ("zip", "sqlExecute")]
        payload["config"]["prompts"]["compress"] = None
        result = agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))
        self.assertIsNone(result.config["prompts"]["compress"])
        self.assertEqual(len(result.config["tools"]), 11)

    def test_missing_agent_returns_none(self):
        self.get_patcher.stop()
        with patch.object(agent_service, "get_agent", return_value=None):
            self.assertIsNone(agent_service.update_agent(self.db, "missing", AgentUpdate.model_validate(valid_payload())))
        self.get_patcher.start()


class HistoryRetrievalConfigTests(unittest.TestCase):
    """013 T003：历史信息检索配置（默认兜底 / 1–100 校验 / 三类均保留 / 未知子键忽略）"""

    def test_missing_key_defaults_to_top_k_10(self):
        cfg = AgentConfig.model_validate({})
        self.assertEqual(cfg.history_retrieval.top_k, 10)
        self.assertEqual(cfg.model_dump()["history_retrieval"], {"top_k": 10})

    def test_out_of_range_or_non_integer_rejected(self):
        for value in (0, 101, "abc", 1.5):
            payload = valid_payload()
            payload["config"]["history_retrieval"] = {"top_k": value}
            with self.assertRaises(ValidationError, msg=f"top_k={value}"):
                AgentUpdate.model_validate(payload)

    def test_boundary_values_accepted(self):
        for value in (1, 100):
            payload = valid_payload()
            payload["config"]["history_retrieval"] = {"top_k": value}
            data = AgentUpdate.model_validate(payload)
            self.assertEqual(data.config.history_retrieval.top_k, value)

    def test_unknown_subkeys_ignored(self):
        payload = valid_payload()
        payload["config"]["history_retrieval"] = {"top_k": 5, "mode": "hybrid", "enabled": True}
        data = AgentUpdate.model_validate(payload)
        self.assertEqual(data.config.history_retrieval.model_dump(), {"top_k": 5})

    def test_router_invalid_top_k_returns_400(self):
        app = FastAPI()
        app.include_router(agents_router.router)
        app.dependency_overrides[get_db] = lambda: MagicMock()
        client = TestClient(app)
        with patch("app.dependencies.decode_token", return_value=admin_claims()):
            payload = valid_payload()
            payload["config"]["history_retrieval"] = {"top_k": 0}
            res = client.put("/agents/agent-1", json=payload, headers={"Authorization": "Bearer t"})
        self.assertEqual(res.status_code, 400)


class HistoryRetrievalUpdateTests(unittest.TestCase):
    """013 T003/T007：update_agent 三类均保留 history_retrieval，缺省以默认值落库"""

    def setUp(self):
        self.db = MagicMock()
        self.agent = make_agent()
        self.get_patcher = patch.object(agent_service, "get_agent", return_value=self.agent)
        self.get_patcher.start()
        self.addCleanup(self.get_patcher.stop)
        self.resolve_patcher = patch(
            "app.services.agent_runtime.llm_client.resolve_model",
            return_value={"name": "gpt-test", "context_tokens": 128000, "category": "chat"},
        )
        self.resolve_patcher.start()
        self.addCleanup(self.resolve_patcher.stop)

        def query(model):
            q = MagicMock()
            if model is Agent:
                q.filter.return_value.first.return_value = None
            elif model is Prompt:
                q.filter.return_value.first.return_value = SimpleNamespace(id="p")
            return q

        self.db.query.side_effect = query

    def test_all_three_types_keep_history_retrieval(self):
        for agent_type in ("quick_qa", "reasoning_action", "planning_reasoning"):
            self.agent.type = agent_type
            payload = valid_payload(agent_type)
            payload["config"]["history_retrieval"] = {"top_k": 25}
            result = agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))
            self.assertEqual(result.config["history_retrieval"], {"top_k": 25}, agent_type)

    def test_missing_key_persisted_with_default(self):
        payload = valid_payload()  # 不含 history_retrieval 键
        result = agent_service.update_agent(self.db, "agent-1", AgentUpdate.model_validate(payload))
        self.assertEqual(result.config["history_retrieval"], {"top_k": 10})


class ReasoningActionTests(unittest.TestCase):
    """US3：推理行动类型规则（loop_count 默认 10/边界 1–1000、sufficiency 必填、tools 被忽略）"""

    def setUp(self):
        self.db = MagicMock()
        self.agent = make_agent(id="agent-2", type="reasoning_action", name="推理行动", icon="bulb")
        self.get_patcher = patch.object(agent_service, "get_agent", return_value=self.agent)
        self.get_patcher.start()
        self.addCleanup(self.get_patcher.stop)
        self.resolve_patcher = patch(
            "app.services.agent_runtime.llm_client.resolve_model",
            return_value={"name": "gpt-test", "context_tokens": 128000, "category": "chat"},
        )
        self.resolve_patcher.start()
        self.addCleanup(self.resolve_patcher.stop)

        def query(model):
            q = MagicMock()
            if model is Agent:
                q.filter.return_value.first.return_value = None  # 无重名
            elif model is Prompt:
                q.filter.return_value.first.return_value = SimpleNamespace(id="p")
            return q

        self.db.query.side_effect = query

    def test_loop_count_default_10_when_omitted(self):
        payload = valid_payload("reasoning_action")
        del payload["config"]["loop_count"]
        result = agent_service.update_agent(self.db, "agent-2", AgentUpdate.model_validate(payload))
        self.assertEqual(result.config["loop_count"], 10)

    def test_loop_count_boundary_1_and_1000_saved(self):
        for value in (1, 1000):
            payload = valid_payload("reasoning_action")
            payload["config"]["loop_count"] = value
            result = agent_service.update_agent(self.db, "agent-2", AgentUpdate.model_validate(payload))
            self.assertEqual(result.config["loop_count"], value)

    def test_sufficiency_required_missing_raises(self):
        payload = valid_payload("reasoning_action")
        payload["config"]["prompts"]["sufficiency"] = None
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-2", AgentUpdate.model_validate(payload))

    def test_tools_ignored_and_sufficiency_kept(self):
        payload = valid_payload("reasoning_action")
        payload["config"]["tools"] = list(TOOL_KEYS)
        result = agent_service.update_agent(self.db, "agent-2", AgentUpdate.model_validate(payload))
        self.assertNotIn("tools", result.config)
        self.assertIn("sufficiency", result.config["prompts"])
        self.assertNotIn("planning", result.config["prompts"])


class PlanningReasoningTests(unittest.TestCase):
    """US4：规划推理类型规则（tools 默认全选/裁剪持久化、planning 用途、loop 默认 100、工具联动必填）"""

    def setUp(self):
        self.db = MagicMock()
        self.agent = make_agent(id="agent-3", type="planning_reasoning", name="规划推理", icon="partition")
        self.get_patcher = patch.object(agent_service, "get_agent", return_value=self.agent)
        self.get_patcher.start()
        self.addCleanup(self.get_patcher.stop)
        self.resolve_patcher = patch(
            "app.services.agent_runtime.llm_client.resolve_model",
            return_value={"name": "gpt-test", "context_tokens": 128000, "category": "chat"},
        )
        self.resolve_patcher.start()
        self.addCleanup(self.resolve_patcher.stop)

        def query(model):
            q = MagicMock()
            if model is Agent:
                q.filter.return_value.first.return_value = None  # 无重名
            elif model is Prompt:
                q.filter.return_value.first.return_value = SimpleNamespace(id="p")
            return q

        self.db.query.side_effect = query

    def test_tools_default_all_13_when_omitted(self):
        payload = valid_payload("planning_reasoning")
        del payload["config"]["tools"]
        result = agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))
        self.assertEqual(set(result.config["tools"]), set(TOOL_KEYS))
        self.assertEqual(len(result.config["tools"]), 13)
        self.assertIn("hybridSearch", result.config["tools"])

    def test_uncheck_two_tools_persisted_exactly(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["tools"] = [k for k in TOOL_KEYS if k not in ("zip", "sqlExecute")]
        result = agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))
        self.assertEqual(len(result.config["tools"]), 11)
        self.assertNotIn("zip", result.config["tools"])
        self.assertNotIn("sqlExecute", result.config["tools"])

    def test_unchecked_tools_make_linked_prompts_optional(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["tools"] = [k for k in TOOL_KEYS if k not in ("rewriteQuestion", "zip")]
        for purpose in ("rewrite", "compress"):
            payload["config"]["prompts"][purpose] = None
        result = agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))
        for purpose in ("rewrite", "compress"):
            self.assertIsNone(result.config["prompts"][purpose])
        self.assertNotIn("rerank", result.config["prompts"])

    def test_checked_tool_keeps_linked_prompt_required(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["prompts"]["compress"] = None  # zip 仍勾选
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))

    def test_loop_count_default_100_when_omitted(self):
        payload = valid_payload("planning_reasoning")
        del payload["config"]["loop_count"]
        result = agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))
        self.assertEqual(result.config["loop_count"], 100)

    def test_retrieval_mode_stripped_and_three_top_k_kept(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["retrieval"].update(vector_top_k=10, keyword_top_k=30, hybrid_top_k=40)
        result = agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))
        retrieval = result.config["retrieval"]
        self.assertNotIn("mode", retrieval)
        self.assertEqual(retrieval["vector_top_k"], 10)
        self.assertEqual(retrieval["keyword_top_k"], 30)
        self.assertEqual(retrieval["hybrid_top_k"], 40)

    def test_embedding_required_regardless_of_mode(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["retrieval"]["mode"] = "keyword"
        payload["config"]["models"]["embedding_model_id"] = None
        with self.assertRaises(ValueError):
            agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))

    def test_sufficiency_ignored_planning_kept(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["prompts"]["sufficiency"] = "prompt-extra"
        result = agent_service.update_agent(self.db, "agent-3", AgentUpdate.model_validate(payload))
        self.assertNotIn("sufficiency", result.config["prompts"])
        self.assertIn("planning", result.config["prompts"])


class AgentUpdateRouterTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(agents_router.router)
        self.db = MagicMock()
        app.dependency_overrides[get_db] = lambda: self.db
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=admin_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)

    def test_put_success(self):
        with patch.object(agent_service, "update_agent", return_value=make_agent(name="新名称")):
            res = self.client.put("/agents/agent-1", json=valid_payload(), headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["name"], "新名称")

    def test_put_out_of_range_400(self):
        payload = valid_payload()
        payload["config"]["retrieval"]["vector_top_k"] = 101
        res = self.client.put("/agents/agent-1", json=payload, headers=self.headers)
        self.assertEqual(res.status_code, 400)

    def test_put_reasoning_loop_out_of_range_400(self):
        for value in (0, 1001):
            payload = valid_payload("reasoning_action")
            payload["config"]["loop_count"] = value
            res = self.client.put("/agents/agent-2", json=payload, headers=self.headers)
            self.assertEqual(res.status_code, 400, msg=f"loop_count={value}")

    def test_put_invalid_tool_key_400(self):
        payload = valid_payload("planning_reasoning")
        payload["config"]["tools"] = ["notATool"]
        res = self.client.put("/agents/agent-3", json=payload, headers=self.headers)
        self.assertEqual(res.status_code, 400)

    def test_put_duplicate_name_409(self):
        with patch.object(agent_service, "update_agent", side_effect=NameConflictError("智能体名称已存在")):
            res = self.client.put("/agents/agent-1", json=valid_payload(), headers=self.headers)
        self.assertEqual(res.status_code, 409)
        self.assertEqual(res.json()["detail"], "智能体名称已存在")

    def test_put_validation_error_400(self):
        with patch.object(agent_service, "update_agent", side_effect=ValueError("分析模型为必填项")):
            res = self.client.put("/agents/agent-1", json=valid_payload(), headers=self.headers)
        self.assertEqual(res.status_code, 400)

    def test_put_not_found_404(self):
        with patch.object(agent_service, "update_agent", return_value=None):
            res = self.client.put("/agents/missing", json=valid_payload(), headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_put_normal_user_403(self):
        self.auth.stop()
        with patch("app.dependencies.decode_token", return_value=user_claims()):
            res = self.client.put("/agents/agent-1", json=valid_payload(), headers=self.headers)
        self.assertEqual(res.status_code, 403)


if __name__ == "__main__":
    unittest.main()