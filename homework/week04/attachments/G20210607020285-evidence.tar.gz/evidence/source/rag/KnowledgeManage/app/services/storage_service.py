"""MinIO object storage service."""

import io
import logging
from datetime import datetime, timezone
from typing import Optional

from fastapi import HTTPException

from app.core import minio_client

logger = logging.getLogger(__name__)


class StorageError(Exception):
    """Raised when a MinIO storage operation fails."""


def _handle_storage_error(action: str, error: Exception) -> None:
    """Log the error and raise a user-friendly HTTPException."""
    logger.error("MinIO %s failed: %s", action, error)
    raise HTTPException(
        status_code=503,
        detail=f"文件存储服务暂时不可用（{action}），请稍后重试",
    )


def upload_file(
    object_path: str,
    data: bytes | io.BytesIO,
    length: int,
    content_type: str = "application/octet-stream",
) -> str:
    """Upload a file to MinIO and return the object path.

    Args:
        object_path: Object key path, e.g. {kb_id}/{folder_id}/{doc_id}/{filename}
        data: File content as bytes or BytesIO stream
        length: Content length in bytes
        content_type: MIME type of the file

    Returns:
        The object path that was uploaded
    """
    try:
        client = minio_client.get_client()
        bucket = minio_client.get_bucket()

        if isinstance(data, bytes):
            data = io.BytesIO(data)

        client.put_object(
            bucket_name=bucket,
            object_name=object_path,
            data=data,
            length=length,
            content_type=content_type,
        )
        logger.info("Uploaded object: %s/%s (%d bytes)", bucket, object_path, length)
        return object_path
    except HTTPException:
        raise
    except Exception as e:
        _handle_storage_error("上传", e)


def download_file(object_path: str) -> bytes:
    """Download a file from MinIO and return its content as bytes.

    Args:
        object_path: Object key path, e.g. {kb_id}/{doc_id}/images/{filename}

    Returns:
        File content as bytes

    Raises:
        StorageError: If the download fails
    """
    try:
        client = minio_client.get_client()
        bucket = minio_client.get_bucket()

        response = client.get_object(
            bucket_name=bucket,
            object_name=object_path,
        )
        data = response.read()
        response.close()
        response.release_conn()
        logger.info("Downloaded object: %s/%s (%d bytes)", bucket, object_path, len(data))
        return data
    except Exception as e:
        logger.error("Failed to download object %s: %s", object_path, e)
        raise StorageError(f"Failed to download file: {object_path}") from e


def get_presigned_url(
    object_path: str,
    expires: int = 3600,
    *,
    request_date: datetime | None = None,
) -> str:
    """Generate a presigned GET URL for an object.

    Args:
        object_path: Object key path
        expires: URL expiration in seconds (default 1 hour)

    Returns:
        Presigned URL string
    """
    from datetime import timedelta

    try:
        client = minio_client.get_client()
        bucket = minio_client.get_bucket()

        url = client.presigned_get_object(
            bucket_name=bucket,
            object_name=object_path,
            expires=timedelta(seconds=expires),
            request_date=request_date,
        )
        return url
    except HTTPException:
        raise
    except Exception as e:
        _handle_storage_error("获取文件地址", e)
        return ""  # unreachable, satisfies type checker


def get_shared_image_url(object_path: str) -> str:
    now = datetime.now(timezone.utc)
    window = now.replace(minute=0, second=0, microsecond=0)
    return get_presigned_url(object_path, expires=7200, request_date=window)


def delete_object(object_path: str) -> None:
    """Delete a single object from MinIO.

    Args:
        object_path: Object key path to delete
    """
    try:
        client = minio_client.get_client()
        bucket = minio_client.get_bucket()

        client.remove_object(
            bucket_name=bucket,
            object_name=object_path,
        )
        logger.info("Deleted object: %s/%s", bucket, object_path)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Failed to delete object %s: %s", object_path, e)


def list_object_keys(prefix: str) -> set[str]:
    try:
        client = minio_client.get_client()
        bucket = minio_client.get_bucket()
        return {obj.object_name for obj in client.list_objects(bucket, prefix=prefix, recursive=True)}
    except Exception as exc:
        raise StorageError(f"Failed to list objects: {prefix}") from exc


def delete_objects_by_prefix(prefix: str) -> int:
    """Delete all objects matching a prefix.

    Args:
        prefix: Object key prefix, e.g. {kb_id}/{folder_id}/

    Returns:
        Number of objects deleted
    """
    try:
        client = minio_client.get_client()
        bucket = minio_client.get_bucket()

        objects = client.list_objects(bucket, prefix=prefix, recursive=True)
        count = 0
        for obj in objects:
            client.remove_object(bucket_name=bucket, object_name=obj.object_name)
            count += 1

        if count > 0:
            logger.info("Deleted %d objects with prefix: %s/%s", count, bucket, prefix)
        return count
    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Failed to delete objects with prefix %s: %s", prefix, e)
        return 0
