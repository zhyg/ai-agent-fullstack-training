import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Text, TIMESTAMP, Index
from sqlalchemy.dialects.postgresql import JSONB

from app.core.database import Base
from app.core.config import settings


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (
        Index("idx_messages_chat", "chat_id"),
        Index("idx_messages_chat_created", "chat_id", "created_at"),
        Index("idx_messages_trace", "trace_id"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    chat_id = Column(String(36), nullable=False, comment="所属会话 ID")
    role = Column(String(20), nullable=False, comment="消息角色: user/assistant/system")
    content = Column(Text, nullable=False, comment="消息内容")
    trace_id = Column(String(32), nullable=True, comment="智能体问答轨迹 ID；同轮 user/assistant 两行同值")
    meta = Column(JSONB, nullable=True, comment="智能体消息元数据: stopped/terminate_reason/references/usage/error_code/raw_output")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
