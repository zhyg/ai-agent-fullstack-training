import json
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, TypeVar, Generic
from datetime import datetime


# --- Document ---
class DocumentUpdate(BaseModel):
    description: Optional[str] = Field(None, max_length=1000, description="文档描述")
    tags: Optional[List[str]] = Field(None, description="完整标签列表（替换式更新）")


class DocumentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: Optional[str] = None
    tags: List[str] = []
    file_size: int
    mime_type: Optional[str] = None
    extension: Optional[str] = None
    status: str
    storage_path: str
    md_path: Optional[str] = None
    chunk_config: Optional[str] = None
    ai_question_count: Optional[int] = None
    skipped_files: Optional[str] = None
    error_message: Optional[str] = None
    folder_id: str
    kb_id: str
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_orm_model(cls, obj) -> "DocumentResponse":
        """Convert ORM model to response, deserializing JSON fields."""
        data = {c.name: getattr(obj, c.name) for c in obj.__table__.columns}
        # Deserialize tags from JSON string to list
        if isinstance(data.get("tags"), str):
            try:
                data["tags"] = json.loads(data["tags"])
            except (json.JSONDecodeError, TypeError):
                data["tags"] = []
        # Deserialize skipped_files from JSON string to list
        if isinstance(data.get("skipped_files"), str):
            try:
                data["skipped_files"] = json.loads(data["skipped_files"])
            except (json.JSONDecodeError, TypeError):
                data["skipped_files"] = None
        return cls(**data)


class DocumentUploadItem(BaseModel):
    id: str
    name: str
    status: str
    file_size: int


class DocumentUploadResponse(BaseModel):
    documents: List[DocumentUploadItem]
    message: str


class TagAddRequest(BaseModel):
    tags: List[str] = Field(..., min_length=1, description="要追加的标签列表")


class TagRemoveRequest(BaseModel):
    tag: str = Field(..., min_length=1, description="要删除的标签")


class BatchDeleteRequest(BaseModel):
    document_ids: List[str] = Field(..., min_length=1, description="要删除的文档 ID 列表")


class BatchDeleteResponse(BaseModel):
    deleted: int
    message: str


class DocumentFileResponse(BaseModel):
    url: str
    expires_in: int


class DocumentMarkdownPreviewResponse(BaseModel):
    content: str


# --- Paginated (reuse if not already defined) ---
T = TypeVar("T")


class DocumentPaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
