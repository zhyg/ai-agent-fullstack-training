"""引用协议：句柄分配 / 上下文注入 / references 映射 / 流式 ref 过滤（FR-013/014，research.md R13）.

- 上下文注入格式：`[cN] (文档名) 内容`，cN 从 1 递增；
- 答案提示词尾部追加来源处理协议；
- 流式后处理：缓冲疑似不完整 <ref ...> 前缀，完整标签校验句柄——有效原样下发，无效丢弃记 trace 事件；
- 片段内容与 references 中的 MinIO 图片路径替换为预签名 URL（expires=86400，与 chunks 路由一致）。
"""
import logging
import re
from typing import Callable, Dict, List, Optional, Set

from app.core.config import settings
from app.schemas.agent_runtime import ReferenceItem
from app.services import storage_service
from app.services.agent_runtime.state import ContextChunk
from app.services.markdown_preview import rewrite_image_urls

logger = logging.getLogger(__name__)

SOURCE_PROTOCOL = (
    "\n\n来源处理协议（必须遵守）：\n"
    "1. 只能引用上下文片段中出现过的句柄 cN，禁止编造不存在的句柄；\n"
    '2. 引用标记 <ref id="cN"/> 必须内联于对应结论的同一句末尾，一句可引用多个；\n'
    "3. 禁止在答案中暴露片段原文、编号规则、知识库标识等内部信息；\n"
    "4. 引用标记中的引号必须使用英文双引号，禁止使用中文弯引号。"
)

# 兼容模型输出的中文弯引号形态，下发前统一归一化为英文双引号
_REF_TAG_RE = re.compile(r'<ref\s+id=["“](c\d+)["”]\s*/>')
_MD_IMAGE_RE = re.compile(r'!\[[^\]]*\]\(([^)\s]+)')
_TAG_TEMPLATE = '<ref id="'
_MAX_PENDING = 48  # 疑似不完整标签的最大缓冲长度


def assign_handles(chunks: List[ContextChunk]) -> Dict[str, ContextChunk]:
    """为片段分配 cN 句柄（从 1 递增，按传入顺序），返回 handle → chunk 映射."""
    handle_map: Dict[str, ContextChunk] = {}
    for i, chunk in enumerate(chunks, start=1):
        chunk.handle = f"c{i}"
        handle_map[chunk.handle] = chunk
    return handle_map


def presign_image(path: str) -> str:
    """MinIO 对象路径 → 预签名 URL（默认 86400s）；已是 URL 原样返回，失败保留原路径."""
    if not path or path.startswith(("http://", "https://", "data:")):
        return path
    try:
        return storage_service.get_presigned_url(path, expires=settings.agent_runtime.presign_expires)
    except Exception as e:
        logger.warning("Failed to presign image %s: %s", path, e)
        return path


def presign_content(content: str) -> str:
    """替换 Markdown 图片语法中的 MinIO 路径为预签名 URL."""
    return rewrite_image_urls(content, presign_image)


def refresh_signed_urls(content: str) -> str:
    """重签内容中已过期的预签名图片 URL（refresh-urls 接口，FR-013）.

    从 URL path 提取对象键（去 bucket 前缀）重新签发；裸对象路径直接签发；
    提取/签发失败保留原值。
    """
    from urllib.parse import unquote, urlsplit

    from app.core import minio_client

    def resolve(url: str) -> str:
        if not url.startswith(("http://", "https://")):
            return presign_image(url)
        try:
            path = urlsplit(url).path.lstrip("/")
            bucket = minio_client.get_bucket()
            key = path[len(bucket) + 1:] if path.startswith(bucket + "/") else path
            return storage_service.get_presigned_url(
                unquote(key), expires=settings.agent_runtime.presign_expires,
            )
        except Exception as e:
            logger.warning("Failed to refresh signed url %s: %s", url[:120], e)
            return url

    return rewrite_image_urls(content, resolve)


def extract_image_paths(content: str) -> List[str]:
    """提取片段内容中的原始图片对象路径（不含已是 URL 的）."""
    return [p for p in _MD_IMAGE_RE.findall(content or "") if not p.startswith(("http://", "https://", "data:"))]


def build_context_text(chunks: List[ContextChunk]) -> str:
    """上下文注入：[cN] (文档名) 内容；图片路径已替换为预签名 URL."""
    parts = []
    for chunk in chunks:
        parts.append(f"[{chunk.handle}] ({chunk.file_name}) {presign_content(chunk.content)}")
    return "\n\n".join(parts)


def build_references(chunks: List[ContextChunk]) -> List[ReferenceItem]:
    """构建 references 事件 / meta.references 数据（content 含预签名 URL，image_paths 存原始路径供重签）."""
    return [
        ReferenceItem(
            handle=chunk.handle,
            chunk_id=chunk.chunk_id,
            document_id=chunk.document_id,
            kb_id=chunk.kb_id,
            file_name=chunk.file_name,
            content=presign_content(chunk.content),
            image_paths=extract_image_paths(chunk.content),
            score=chunk.score,
        )
        for chunk in chunks
    ]


def _is_partial_ref(tail: str) -> bool:
    """tail 以 '<' 开头：是否可能是尚未输出完整的 <ref id="cN"/> 前缀."""
    tail = tail.replace("“", '"').replace("”", '"')  # 弯引号形态归一化后再判前缀
    if len(tail) > _MAX_PENDING:
        return False
    if len(tail) <= len(_TAG_TEMPLATE):
        return _TAG_TEMPLATE.startswith(tail)
    if not tail.startswith(_TAG_TEMPLATE):
        return False
    rest = tail[len(_TAG_TEMPLATE):]
    m = re.match(r"^c\d*", rest)
    if not m:
        return False
    return '"/>'.startswith(rest[m.end():])


class RefStreamFilter:
    """流式引用标签过滤器：跨 delta 缓冲不完整标签，校验句柄有效性.

    feed(delta) 返回可安全下发的文本；flush() 返回流结束时剩余文本。
    无效句柄丢弃并回调 on_invalid(handle)（调用方记 trace 事件）。
    """

    def __init__(self, valid_handles: Set[str], on_invalid: Optional[Callable[[str], None]] = None):
        self._valid = valid_handles
        self._on_invalid = on_invalid
        self._buf = ""

    def _emit_tag(self, tag: str, handle: str) -> str:
        if handle in self._valid:
            # 弯引号归一化为英文双引号，保证前端引用解析一致
            return tag.replace("“", '"').replace("”", '"')
        if self._on_invalid:
            self._on_invalid(handle)
        return ""

    def feed(self, delta: str) -> str:
        self._buf += delta
        out: List[str] = []
        pos = 0
        while True:
            m = _REF_TAG_RE.search(self._buf, pos)
            if m:
                out.append(self._buf[pos:m.start()])
                out.append(self._emit_tag(m.group(0), m.group(1)))
                pos = m.end()
                continue
            idx = self._buf.find("<", pos)
            if idx == -1:
                out.append(self._buf[pos:])
                self._buf = ""
                return "".join(out)
            tail = self._buf[idx:]
            if ">" not in tail and _is_partial_ref(tail):
                # 疑似不完整标签：留存缓冲等待后续 delta
                out.append(self._buf[pos:idx])
                self._buf = tail
                return "".join(out)
            # 非 ref 起始的 '<'：原样放行继续扫描
            out.append(self._buf[pos:idx + 1])
            pos = idx + 1

    def flush(self) -> str:
        """流结束：完整标签校验后下发；残留不完整标签视为无效丢弃."""
        buf, self._buf = self._buf, ""
        out: List[str] = []
        pos = 0
        for m in _REF_TAG_RE.finditer(buf):
            out.append(buf[pos:m.start()])
            out.append(self._emit_tag(m.group(0), m.group(1)))
            pos = m.end()
        tail = buf[pos:]
        if tail:
            idx = tail.find("<")
            if idx != -1 and _is_partial_ref(tail[idx:]):
                if self._on_invalid:
                    self._on_invalid(tail[idx:])
                tail = tail[:idx]
            out.append(tail)
        return "".join(out)