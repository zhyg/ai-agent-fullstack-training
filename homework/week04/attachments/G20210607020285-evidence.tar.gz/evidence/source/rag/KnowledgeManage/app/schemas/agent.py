from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import Optional, List, Literal
from datetime import datetime


# ---- 常量（与 frontend/src/utils/agent.js 保持同步） ----

AGENT_TYPES = ("quick_qa", "reasoning_action", "planning_reasoning")

# 内置图标库 key 白名单（FR-006，仅可从该集合选择，不支持上传）
AGENT_ICON_KEYS = (
    "thunderbolt", "bulb", "partition", "robot", "message",
    "search", "experiment", "compass", "rocket", "api",
)

# 规划推理 13 个固定工具 key（FR-011）
TOOL_KEYS = (
    "createPlan", "listPlan", "getPlan", "updatePlan", "deletePlan",
    "rewriteQuestion", "bm25Search", "vectorSearch", "hybridSearch", "rerank", "zip",
    "listTableMetaData", "sqlExecute",
)

# 各类型提示词用途（FR-007）
PROMPT_PURPOSES_BY_TYPE = {
    "quick_qa": ("clarify", "rewrite", "answer", "compress"),
    "reasoning_action": ("clarify", "rewrite", "answer", "compress", "sufficiency"),
    "planning_reasoning": ("clarify", "rewrite", "answer", "compress", "planning"),
}

# 恒必填用途；规划推理的 rewrite/compress 随对应工具勾选联动（FR-013/Assumptions）
REQUIRED_PROMPT_PURPOSES_BY_TYPE = {
    "quick_qa": ("clarify", "rewrite", "answer", "compress"),
    "reasoning_action": ("clarify", "rewrite", "answer", "compress", "sufficiency"),
    "planning_reasoning": ("clarify", "answer", "planning"),
}

# 工具 → 提示词用途联动映射（取消勾选该工具时对应用途转可选）
TOOL_TO_PROMPT_PURPOSE = {
    "rewriteQuestion": "rewrite",
    "zip": "compress",
}


def required_prompt_purposes(agent_type: str, tools: Optional[List[str]] = None) -> tuple:
    """按类型与工具勾选状态计算必填提示词用途集合（供服务层校验使用）"""
    base = set(REQUIRED_PROMPT_PURPOSES_BY_TYPE.get(agent_type, ()))
    if agent_type == "planning_reasoning":
        enabled = set(tools if tools is not None else TOOL_KEYS)
        for tool, purpose in TOOL_TO_PROMPT_PURPOSE.items():
            if tool in enabled:
                base.add(purpose)
    return tuple(base)


# ---- Config 嵌套模型（范围校验 FR-008/009/010；条件必填由服务层校验） ----

class PromptRefs(BaseModel):
    model_config = ConfigDict(extra="ignore")
    clarify: Optional[str] = Field(None, description="问题澄清提示词 ID")
    rewrite: Optional[str] = Field(None, description="问题重写提示词 ID")
    answer: Optional[str] = Field(None, description="答案生成提示词 ID")
    compress: Optional[str] = Field(None, description="上下文压缩提示词 ID")
    sufficiency: Optional[str] = Field(None, description="资源充足判断提示词 ID（仅 reasoning_action）")
    planning: Optional[str] = Field(None, description="规划分析提示词 ID（仅 planning_reasoning）")


class RetrievalConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    mode: Literal["vector", "keyword", "hybrid"] = Field("vector", description="检索方式（单选；planning_reasoning 无此配置，保存时裁剪）")
    vector_top_k: int = Field(20, ge=1, le=100, description="向量召回数量")
    keyword_top_k: int = Field(20, ge=1, le=100, description="关键词召回数量")
    hybrid_top_k: int = Field(20, ge=1, le=100, description="混合检索召回数量")
    rerank_top_n: int = Field(15, ge=1, le=100, description="重排数量")


class ModelConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    analysis_model_id: Optional[str] = Field(None, description="分析模型 ID（必填，服务层校验）")
    max_output_tokens: int = Field(5000, ge=1, le=50000, description="最大输出 Token 数")
    embedding_model_id: Optional[str] = Field(None, description="向量模型 ID（mode=vector/hybrid 时必填，服务层校验）")
    rerank_model_id: Optional[str] = Field(None, description="ReRank 模型 ID（必填，服务层校验）")


class HistoryRetrievalConfig(BaseModel):
    """历史信息检索（013 决策8）：仅检索召回数；模式恒混合、无开关，三类均保留"""
    model_config = ConfigDict(extra="ignore")
    top_k: int = Field(10, ge=1, le=100, description="检索召回数")


class AgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    prompts: PromptRefs = Field(default_factory=PromptRefs)
    retrieval: RetrievalConfig = Field(default_factory=RetrievalConfig)
    models: ModelConfig = Field(default_factory=ModelConfig)
    history_retrieval: HistoryRetrievalConfig = Field(default_factory=HistoryRetrievalConfig)  # 存量缺键默认兜底，零迁移
    loop_count: Optional[int] = Field(None, ge=1, le=1000, description="循环次数（仅 reasoning_action/planning_reasoning）")
    tools: Optional[List[str]] = Field(None, description="启用工具清单（仅 planning_reasoning）")

    @field_validator("tools")
    @classmethod
    def validate_tools(cls, v):
        if v is None:
            return v
        invalid = [k for k in v if k not in TOOL_KEYS]
        if invalid:
            raise ValueError(f"非法工具 key: {invalid}")
        if len(set(v)) != len(v):
            raise ValueError("工具 key 不得重复")
        return v


# ---- 请求/响应 Schema ----

class AgentUpdate(BaseModel):
    """整份更新基础信息 + config（PUT）；status/type 即使携带也忽略（extra='ignore'）"""
    model_config = ConfigDict(extra="ignore")
    name: str = Field(..., min_length=1, max_length=100, description="显示名称（跨智能体唯一）")
    icon: str = Field(..., description="内置图标库 key")
    description: str = Field("", description="描述")
    config: AgentConfig

    @field_validator("icon")
    @classmethod
    def validate_icon(cls, v):
        if v not in AGENT_ICON_KEYS:
            raise ValueError(f"图标必须为内置图标库 key: {AGENT_ICON_KEYS}")
        return v


class StatusUpdate(BaseModel):
    status: Literal["enabled", "disabled"] = Field(..., description="目标状态")


class AgentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    type: str
    name: str
    icon: str
    description: str
    status: str
    config: dict
    config_complete: bool = True
    incomplete_reasons: List[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class AgentListResponse(BaseModel):
    items: List[AgentResponse]