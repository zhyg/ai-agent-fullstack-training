import unittest
from types import SimpleNamespace
from unittest.mock import call, patch

from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

from app.routers import documents


class MarkdownPreviewTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(documents.router)
        app.dependency_overrides[documents.get_db] = lambda: None
        app.dependency_overrides[documents.get_current_user] = lambda: {"id": "owner"}
        self.client = TestClient(app)
        self.url = "/documents/doc/markdown/preview"

    def test_preview_signs_only_this_documents_images(self):
        original = (
            "# 文档\n"
            "![PNG](images/a.png)\n"
            "![same](./images/a.png)\n"
            "![JPG](kb/doc/images/b.jpg)\n"
            "![external](https://example.test/a.png)\n"
            "![other](kb/other/images/a.png)\n"
            "![not an image key](kb/doc/source.pdf)"
        )
        doc = SimpleNamespace(kb_id="kb", md_path="kb/doc/markdown/test.md", extension="docx")
        with (
            patch.object(documents.document_service, "get_document", return_value=doc) as lookup,
            patch.object(documents.storage_service, "download_file", return_value=original.encode()) as download,
            patch.object(
                documents.storage_service, "get_presigned_url",
                side_effect=["https://minio.test/a.png?signature=1", "https://minio.test/b.jpg?signature=2"],
            ) as sign,
        ):
            response = self.client.get(self.url)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["content"], original
                         .replace("(images/a.png)", "(https://minio.test/a.png?signature=1)")
                         .replace("(./images/a.png)", "(https://minio.test/a.png?signature=1)")
                         .replace("(kb/doc/images/b.jpg)", "(https://minio.test/b.jpg?signature=2)"))
        lookup.assert_called_once_with(None, "doc", "owner")
        download.assert_called_once_with(doc.md_path)
        self.assertEqual(sign.call_args_list, [
            call("kb/doc/images/a.png", expires=3600),
            call("kb/doc/images/b.jpg", expires=3600),
        ])

    def test_preview_does_not_read_storage_when_access_is_denied(self):
        with (
            patch.object(documents.document_service, "get_document", side_effect=HTTPException(404)),
            patch.object(documents.storage_service, "download_file") as download,
        ):
            self.assertEqual(self.client.get(self.url).status_code, 404)
        download.assert_not_called()
