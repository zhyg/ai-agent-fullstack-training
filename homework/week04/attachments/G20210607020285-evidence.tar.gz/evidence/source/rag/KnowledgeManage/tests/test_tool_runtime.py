"""统一 Tool Runtime 与 13 工具单测（T038）：信封/重试/截断/取消/call_id/plan 生命周期/SQL 安全（mock 外部依赖）."""
import json
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from app.schemas.agent import TOOL_KEYS
from app.schemas.agent_runtime import CompressResult, RewriteResult, ToolResult
from app.services.agent_runtime import budget, llm_client, tracing
from app.services.agent_runtime.llm_client import (
    AgentCancelled,
    JsonValidationFailed,
    ModelUnavailableError,
)
from app.services.agent_runtime.state import PromptSnapshot
from app.services.agent_runtime.tools import knowledge_tools, plan_tools, runtime, table_tools
from app.services.agent_runtime.tools.runtime import ToolFailure
from app.services.retrieval_service import EmbeddingFailedError
from tests.test_agent_flows import make_chunk, make_snapshot, make_state


def make_planning_snapshot(tools=None, loop_count=100):
    snap = make_snapshot(agent_type="planning_reasoning", loop_count=loop_count)
    snap.tools = list(tools if tools is not None else TOOL_KEYS)
    snap.prompts["planning"] = PromptSnapshot(
        prompt_id="p-planning", name="planning", version="v1",
        content="planning 提示词：{question} {history}",
    )
    return snap


def make_planning_state(tools=None, loop_count=100):
    return make_state(make_planning_snapshot(tools, loop_count))


def ok_result(content="ok"):
    return ToolResult(success=True, code="ok", content=content)


class RuntimeEnvelopeTests(unittest.IsolatedAsyncioTestCase):
    async def test_invalid_args_envelope_no_raise(self):
        ctx = make_planning_state()
        result = await runtime.execute_tool("c1", "createPlan", {"title": "t"}, ctx)  # 缺 steps
        self.assertFalse(result.success)
        self.assertEqual(result.code, "invalid_args")
        self.assertIn("入参校验失败", result.content)

    async def test_disabled_tool_rejected(self):
        ctx = make_planning_state(tools=["createPlan"])
        result = await runtime.execute_tool("c1", "bm25Search", {"query": "q"}, ctx)
        self.assertEqual(result.code, "invalid_args")
        self.assertIn("未启用", result.content)

    async def test_unknown_tool_rejected(self):
        ctx = make_planning_state()
        result = await runtime.execute_tool("c1", "noSuchTool", {}, ctx)
        self.assertEqual(result.code, "invalid_args")

    async def test_cancelled_before_execution(self):
        ctx = make_planning_state()
        ctx.cancel_event.set()
        spec = runtime._get_registry()["listPlan"]
        handler = AsyncMock()
        with patch.object(spec, "handler", new=handler):
            result = await runtime.execute_tool("c1", "listPlan", {}, ctx)
        self.assertEqual(result.code, "cancelled")
        self.assertFalse(result.success)
        handler.assert_not_awaited()

    async def test_retry_then_success_four_attempts(self):
        ctx = make_planning_state()
        spec = runtime._get_registry()["listPlan"]
        handler = AsyncMock(side_effect=[RuntimeError("x"), RuntimeError("x"), RuntimeError("x"), ok_result('{"plans": []}')])
        with patch.object(spec, "handler", new=handler):
            result = await runtime.execute_tool("c1", "listPlan", {}, ctx)
        self.assertTrue(result.success)
        self.assertEqual(handler.await_count, 4)  # 首次 + 重试 3 次

    async def test_retry_exhausted_execution_failed(self):
        ctx = make_planning_state()
        spec = runtime._get_registry()["listPlan"]
        handler = AsyncMock(side_effect=RuntimeError("boom"))
        with patch.object(spec, "handler", new=handler):
            result = await runtime.execute_tool("c1", "listPlan", {}, ctx)
        self.assertEqual(result.code, "execution_failed")
        self.assertIn("已重试 3 次", result.content)
        self.assertEqual(handler.await_count, 4)

    async def test_tool_failure_no_retry(self):
        ctx = make_planning_state()
        spec = runtime._get_registry()["listPlan"]
        handler = AsyncMock(side_effect=ToolFailure("forbidden_sql", "nope"))
        with patch.object(spec, "handler", new=handler):
            result = await runtime.execute_tool("c1", "listPlan", {}, ctx)
        self.assertEqual(result.code, "forbidden_sql")
        self.assertEqual(handler.await_count, 1)

    async def test_truncation_with_item_count(self):
        ctx = make_planning_state()
        big = json.dumps({"rows": [["x" * 50] for _ in range(6000)]}, ensure_ascii=False)
        spec = runtime._get_registry()["listPlan"]
        with patch.object(spec, "handler", new=AsyncMock(return_value=ok_result(big))):
            result = await runtime.execute_tool("c1", "listPlan", {}, ctx)
        self.assertIn("[结果已截断，共 6000 条]", result.content)
        limit = 4000
        self.assertLessEqual(budget.count_tokens(result.content), limit + 30)  # 截断体+说明后缀

    async def test_call_id_span_attribute(self):
        ctx = make_planning_state()
        tracer = MagicMock()
        span = tracer.start_as_current_span.return_value.__enter__.return_value
        with patch.object(runtime.tracing, "get_tracer", return_value=tracer):
            await runtime.execute_tool("call-abc", "listPlan", {}, ctx)
        tracer.start_as_current_span.assert_called_once_with("agent.tool.listPlan")
        attrs = [c.args for c in span.set_attribute.call_args_list]
        self.assertIn((tracing.ATTR_TOOL_CALL_ID, "call-abc"), attrs)

    async def test_model_unavailable_propagates(self):
        ctx = make_planning_state()
        spec = runtime._get_registry()["listPlan"]
        with patch.object(spec, "handler", new=AsyncMock(side_effect=ModelUnavailableError("down"))):
            with self.assertRaises(ModelUnavailableError):
                await runtime.execute_tool("c1", "listPlan", {}, ctx)

    async def test_cancel_mid_execution_propagates(self):
        ctx = make_planning_state()
        spec = runtime._get_registry()["listPlan"]

        async def _handler(args, c):
            c.cancel_event.set()
            raise RuntimeError("interrupted")

        with patch.object(spec, "handler", new=_handler):
            with self.assertRaises(AgentCancelled):
                await runtime.execute_tool("c1", "listPlan", {}, ctx)

    async def test_tool_message_call_id_roundtrip(self):
        ctx = make_planning_state()
        result = await runtime.execute_tool("call-9", "listPlan", {}, ctx)
        msg = result.to_model_message("call-9")
        self.assertEqual(msg["role"], "tool")
        self.assertEqual(msg["tool_call_id"], "call-9")
        self.assertEqual(json.loads(msg["content"])["code"], "ok")


class PlanToolTests(unittest.IsolatedAsyncioTestCase):
    async def _create(self, ctx, steps=2):
        result = await runtime.execute_tool("c1", "createPlan", {
            "title": "分析计划",
            "steps": [{"description": f"步骤{i}"} for i in range(steps)],
        }, ctx)
        self.assertTrue(result.success)
        return json.loads(result.content)

    async def test_plan_lifecycle(self):
        ctx = make_planning_state()
        plan = await self._create(ctx)
        self.assertEqual(len(plan["steps"]), 2)
        self.assertTrue(all(s["status"] == "pending" for s in plan["steps"]))

        listed = json.loads((await runtime.execute_tool("c2", "listPlan", {}, ctx)).content)
        self.assertEqual(listed["plans"][0]["step_count"], 2)
        self.assertEqual(listed["plans"][0]["done_count"], 0)

        got = json.loads((await runtime.execute_tool("c3", "getPlan", {"plan_id": plan["plan_id"]}, ctx)).content)
        self.assertEqual(got["title"], "分析计划")

        updated = json.loads((await runtime.execute_tool("c4", "updatePlan", {
            "plan_id": plan["plan_id"],
            "steps": [
                {"step_id": plan["steps"][0]["step_id"], "status": "done"},
                {"description": "追加步骤"},
            ],
        }, ctx)).content)
        self.assertEqual(updated["steps"][0]["status"], "done")
        self.assertEqual(len(updated["steps"]), 3)

        deleted = json.loads((await runtime.execute_tool("c5", "deletePlan", {"plan_id": plan["plan_id"]}, ctx)).content)
        self.assertTrue(deleted["deleted"])
        self.assertIsNone(ctx.plan)
        listed = json.loads((await runtime.execute_tool("c6", "listPlan", {}, ctx)).content)
        self.assertEqual(listed["plans"], [])

    async def test_single_plan_per_request(self):
        ctx = make_planning_state()
        await self._create(ctx)
        again = await runtime.execute_tool("c2", "createPlan", {
            "title": "第二个", "steps": [{"description": "s"}],
        }, ctx)
        self.assertEqual(again.code, "invalid_args")

    async def test_plan_id_mismatch(self):
        ctx = make_planning_state()
        await self._create(ctx)
        for tool, args in (
            ("getPlan", {"plan_id": "wrong"}),
            ("updatePlan", {"plan_id": "wrong", "title": "x"}),
            ("deletePlan", {"plan_id": "wrong"}),
        ):
            result = await runtime.execute_tool("c", tool, args, ctx)
            self.assertEqual(result.code, "invalid_args", tool)

    async def test_update_unknown_step_id(self):
        ctx = make_planning_state()
        plan = await self._create(ctx)
        result = await runtime.execute_tool("c2", "updatePlan", {
            "plan_id": plan["plan_id"], "steps": [{"step_id": "nope", "status": "done"}],
        }, ctx)
        self.assertEqual(result.code, "invalid_args")

    async def test_steps_bounds(self):
        ctx = make_planning_state()
        empty = await runtime.execute_tool("c1", "createPlan", {"title": "t", "steps": []}, ctx)
        self.assertEqual(empty.code, "invalid_args")
        too_many = await runtime.execute_tool("c2", "createPlan", {
            "title": "t", "steps": [{"description": "s"}] * 51,
        }, ctx)
        self.assertEqual(too_many.code, "invalid_args")


class KnowledgeToolTests(unittest.IsolatedAsyncioTestCase):
    async def test_bm25_hits_merged_and_whitelisted(self):
        ctx = make_planning_state()
        chunk = make_chunk("r1")
        chunk.sqlite_url = "kb1/doc-r1/table.db"
        retrieve = AsyncMock(return_value=[chunk])
        with patch.object(knowledge_tools.retrieval_service, "retrieve", new=retrieve):
            result = await runtime.execute_tool("c1", "bm25Search", {"query": "q"}, ctx)
        self.assertTrue(result.success)
        payload = json.loads(result.content)
        self.assertEqual(payload["chunks"][0]["chunk_id"], "r1")
        self.assertEqual(payload["chunks"][0]["sqlite_url"], chunk.sqlite_url)
        self.assertIn("r1", ctx.chunks)
        self.assertIn(chunk.sqlite_url, ctx.sqlite_whitelist)

    async def test_bm25_empty_result(self):
        ctx = make_planning_state()
        with patch.object(knowledge_tools.retrieval_service, "retrieve", new=AsyncMock(return_value=[])):
            result = await runtime.execute_tool("c1", "bm25Search", {"query": "q"}, ctx)
        self.assertTrue(result.success)
        self.assertEqual(result.code, "empty_result")
        self.assertEqual(json.loads(result.content), {"chunks": []})

    async def test_top_k_override(self):
        ctx = make_planning_state()
        retrieve = AsyncMock(return_value=[])
        with patch.object(knowledge_tools.retrieval_service, "retrieve", new=retrieve):
            await runtime.execute_tool("c1", "bm25Search", {"query": "q", "top_k": 5}, ctx)
        self.assertEqual(retrieve.call_args.kwargs["keyword_top_k"], 5)
        self.assertEqual(retrieve.call_args.args[0], "bm25")

    async def test_embedding_failed_execution_failed(self):
        ctx = make_planning_state()
        retrieve = AsyncMock(side_effect=EmbeddingFailedError("emb down"))
        with patch.object(knowledge_tools.retrieval_service, "retrieve", new=retrieve):
            result = await runtime.execute_tool("c1", "vectorSearch", {"query": "q"}, ctx)
        self.assertEqual(result.code, "execution_failed")
        self.assertEqual(retrieve.await_count, 1)  # 受控失败不重试

    async def test_rerank_unknown_chunk_id(self):
        ctx = make_planning_state()
        result = await runtime.execute_tool("c1", "rerank", {"query": "q", "chunk_ids": ["nope"]}, ctx)
        self.assertEqual(result.code, "invalid_args")

    async def test_rerank_degraded_flag(self):
        ctx = make_planning_state()
        chunk = make_chunk("r1")
        ctx.merge_chunks([chunk])
        rerank = AsyncMock(return_value=([chunk], True))
        with patch.object(knowledge_tools.rerank_service, "rerank", new=rerank):
            result = await runtime.execute_tool("c1", "rerank", {"query": "q", "chunk_ids": ["r1"]}, ctx)
        self.assertTrue(result.success)
        self.assertTrue(json.loads(result.content)["degraded"])
        self.assertIn({"event": tracing.EVENT_RERANK_DEGRADED, "loop": 0}, ctx.events)

    async def test_zip_kept_chunk_ids(self):
        ctx = make_planning_state()
        ctx.merge_chunks([make_chunk("r1"), make_chunk("r2")])
        call_json = AsyncMock(return_value=CompressResult(kept_indexes=[1]))
        with patch.object(llm_client, "call_json", new=call_json):
            result = await runtime.execute_tool("c1", "zip", {"question": "q", "chunk_ids": ["r1", "r2"]}, ctx)
        self.assertEqual(json.loads(result.content), {"kept_chunk_ids": ["r2"]})
        self.assertEqual(call_json.call_args.kwargs["purpose"], "compress")

    async def test_zip_empty_indexes_empty_result(self):
        ctx = make_planning_state()
        ctx.merge_chunks([make_chunk("r1")])
        with patch.object(llm_client, "call_json", new=AsyncMock(return_value=CompressResult(kept_indexes=[]))):
            result = await runtime.execute_tool("c1", "zip", {"question": "q", "chunk_ids": ["r1"]}, ctx)
        self.assertEqual(result.code, "empty_result")

    async def test_zip_json_failed_execution_failed(self):
        ctx = make_planning_state()
        ctx.merge_chunks([make_chunk("r1")])
        err = JsonValidationFailed("compress", "bad", "kept_indexes 存在重复索引")
        with patch.object(llm_client, "call_json", new=AsyncMock(side_effect=err)):
            result = await runtime.execute_tool("c1", "zip", {"question": "q", "chunk_ids": ["r1"]}, ctx)
        self.assertEqual(result.code, "execution_failed")

    async def test_rewrite_question_tool(self):
        ctx = make_planning_state()
        call_json = AsyncMock(return_value=RewriteResult(rewritten_question="改写后问题"))
        with patch.object(llm_client, "call_json", new=call_json):
            result = await runtime.execute_tool("c1", "rewriteQuestion", {"question": "原问题"}, ctx)
        self.assertEqual(json.loads(result.content), {"rewritten_question": "改写后问题"})
        self.assertEqual(call_json.call_args.kwargs["purpose"], "rewrite")


class ToolTraceEnhancementTests(unittest.IsolatedAsyncioTestCase):
    """013 T026：工具内 rewrite/zip prompt 溯源 + 检索工具片段全文（FR-001/002）."""

    def setUp(self):
        self.spans = {}
        tracer = MagicMock()
        tracer.start_span.side_effect = lambda name: self.spans.setdefault(name, MagicMock())
        p = patch.object(tracing, "get_tracer", return_value=tracer)
        p.start(); self.addCleanup(p.stop)

    def _attrs(self, span_name):
        return dict(c.args for c in self.spans[span_name].set_attribute.call_args_list)

    async def test_rewrite_tool_span_prompt_attrs(self):
        ctx = make_planning_state()
        with patch.object(llm_client, "call_json",
                          new=AsyncMock(return_value=RewriteResult(rewritten_question="q"))):
            await runtime.execute_tool("c1", "rewriteQuestion", {"question": "原问题"}, ctx)
        attrs = self._attrs("agent.rewrite")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_NAME], "rewrite")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_VERSION], "v1")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_PURPOSE], "rewrite")

    async def test_zip_tool_span_prompt_attrs(self):
        ctx = make_planning_state()
        ctx.merge_chunks([make_chunk("r1")])
        with patch.object(llm_client, "call_json",
                          new=AsyncMock(return_value=CompressResult(kept_indexes=[0]))):
            await runtime.execute_tool("c1", "zip", {"question": "q", "chunk_ids": ["r1"]}, ctx)
        attrs = self._attrs("agent.compress")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_NAME], "compress")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_VERSION], "v1")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_PURPOSE], "compress")

    async def test_search_tool_span_chunks_and_output_summary(self):
        ctx = make_planning_state()
        chunk = make_chunk("r1")
        chunk.score = 0.25
        with patch.object(knowledge_tools.retrieval_service, "retrieve",
                          new=AsyncMock(return_value=[chunk])):
            await runtime.execute_tool("c1", "hybridSearch", {"query": "q"}, ctx)
        attrs = self._attrs("agent.retrieve.hybrid")
        chunks = json.loads(attrs[tracing.ATTR_RETRIEVAL_CHUNKS])
        self.assertEqual(chunks, [{"chunk_id": "r1", "score": 0.25, "file_name": "r1.pdf", "content": "正文"}])
        output = json.loads(attrs[tracing.ATTR_OUTPUT])
        self.assertEqual(output["count"], 1)  # 既有摘要保留

    async def test_search_tool_large_content_not_truncated(self):
        ctx = make_planning_state()
        big = "字" * 20000  # 超 32KB 截断阈值
        with patch.object(knowledge_tools.retrieval_service, "retrieve",
                          new=AsyncMock(return_value=[make_chunk("big", content=big)])):
            await runtime.execute_tool("c1", "bm25Search", {"query": "q"}, ctx)
        raw = self._attrs("agent.retrieve.bm25")[tracing.ATTR_RETRIEVAL_CHUNKS]
        self.assertNotIn("…[截断]", raw)
        self.assertEqual(json.loads(raw)[0]["content"], big)

    async def test_search_tool_empty_hits_empty_array(self):
        ctx = make_planning_state()
        with patch.object(knowledge_tools.retrieval_service, "retrieve",
                          new=AsyncMock(return_value=[])):
            await runtime.execute_tool("c1", "vectorSearch", {"query": "q"}, ctx)
        self.assertEqual(self._attrs("agent.retrieve.vector")[tracing.ATTR_RETRIEVAL_CHUNKS], "[]")


class TableToolTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.ctx = make_planning_state()
        self.url = "kb1/doc-x/sales.db"
        self.ctx.sqlite_whitelist.add(self.url)
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.db_path = Path(self._tmp.name) / "sales.db"
        conn = sqlite3.connect(self.db_path)
        conn.execute("CREATE TABLE sales (region TEXT, amount INTEGER)")
        conn.executemany("INSERT INTO sales VALUES (?, ?)", [(f"r{i}", i) for i in range(600)])
        conn.commit()
        conn.close()

    async def test_url_not_allowed(self):
        ctx = make_planning_state()  # 白名单为空
        for tool, args in (
            ("listTableMetaData", {"sqlite_url": self.url}),
            ("sqlExecute", {"sqlite_url": self.url, "sql_query": "SELECT 1"}),
        ):
            result = await runtime.execute_tool("c1", tool, args, ctx)
            self.assertEqual(result.code, "url_not_allowed", tool)

    async def test_forbidden_sql_rejected_before_download(self):
        forbidden = [
            "DROP TABLE sales",
            "SELECT 1; DELETE FROM sales",
            "/*c*/ ATTACH DATABASE 'a' AS b",
            "PRAGMA journal_mode=DELETE",
            "UPDATE sales SET amount=1",
            "SELECT 1; SELECT 2",
            "-- comment\nDELETE FROM sales",
            "INSERT INTO sales VALUES ('x', 1)",
        ]
        ensure = AsyncMock(side_effect=AssertionError("校验应先于下载"))
        with patch.object(table_tools, "_ensure_local_file", new=ensure):
            for sql in forbidden:
                result = await runtime.execute_tool("c1", "sqlExecute", {"sqlite_url": self.url, "sql_query": sql}, self.ctx)
                self.assertEqual(result.code, "forbidden_sql", sql)
        ensure.assert_not_awaited()

    def test_validate_sql_normalizes_comments(self):
        self.assertEqual(table_tools._validate_sql("/*c*/ SELECT 1; -- tail"), "SELECT 1")
        self.assertEqual(table_tools._validate_sql("  select count(*) from sales  "), "select count(*) from sales")

    def test_readonly_connection_write_fails(self):
        conn = table_tools._connect_ro(self.db_path)
        try:
            with self.assertRaises(sqlite3.OperationalError):
                conn.execute("INSERT INTO sales VALUES ('x', 1)")
        finally:
            conn.close()

    async def test_metadata_and_query_and_truncation(self):
        with patch.object(table_tools, "_ensure_local_file", new=AsyncMock(return_value=self.db_path)):
            meta = await runtime.execute_tool("c1", "listTableMetaData", {"sqlite_url": self.url}, self.ctx)
            tables = json.loads(meta.content)["tables"]
            self.assertEqual(tables[0]["name"], "sales")
            self.assertEqual([c["name"] for c in tables[0]["columns"]], ["region", "amount"])

            counted = await runtime.execute_tool("c2", "sqlExecute", {
                "sqlite_url": self.url, "sql_query": "SELECT COUNT(*) AS n FROM sales",
            }, self.ctx)
            payload = json.loads(counted.content)
            self.assertEqual(payload["columns"], ["n"])
            self.assertEqual(payload["rows"], [[600]])

            limited = await runtime.execute_tool("c3", "sqlExecute", {
                "sqlite_url": self.url, "sql_query": "SELECT region, amount FROM sales",
            }, self.ctx)
            payload = json.loads(limited.content)
            self.assertEqual(payload["row_count"], 500)
            self.assertTrue(payload["truncated"])
            self.assertIn("500", payload["note"])

    async def test_sql_syntax_error_execution_failed(self):
        with patch.object(table_tools, "_ensure_local_file", new=AsyncMock(return_value=self.db_path)):
            result = await runtime.execute_tool("c1", "sqlExecute", {
                "sqlite_url": self.url, "sql_query": "SELECT * FROM missing_table",
            }, self.ctx)
        self.assertEqual(result.code, "execution_failed")

    async def test_download_size_limit(self):
        url = "kb1/oversize.db"

        class _Resp:
            headers = {"content-length": str(60 * 1024 * 1024)}

            def raise_for_status(self):
                pass

        class _StreamCM:
            async def __aenter__(self):
                return _Resp()

            async def __aexit__(self, *a):
                return False

        class _Client:
            def __init__(self, *a, **k):
                pass

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                return False

            def stream(self, *a, **k):
                return _StreamCM()

        with patch.object(table_tools.storage_service, "get_presigned_url", return_value="http://minio/f.db"), \
             patch.object(table_tools.httpx, "AsyncClient", _Client):
            with self.assertRaises(ToolFailure) as cm:
                await table_tools._ensure_local_file(url)
        self.assertEqual(cm.exception.code, "execution_failed")
        self.assertIn("大小上限", cm.exception.content)

    async def test_download_timeout_propagates_for_retry(self):
        url = "kb1/timeout.db"

        class _StreamCM:
            async def __aenter__(self):
                raise httpx.TimeoutException("timeout")

            async def __aexit__(self, *a):
                return False

        class _Client:
            def __init__(self, *a, **k):
                pass

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                return False

            def stream(self, *a, **k):
                return _StreamCM()

        with patch.object(table_tools.storage_service, "get_presigned_url", return_value="http://minio/f.db"), \
             patch.object(table_tools.httpx, "AsyncClient", _Client):
            with self.assertRaises(httpx.TimeoutException):
                await table_tools._ensure_local_file(url)

    async def test_cache_hit_skips_download(self):
        url = "kb1/cached.db"
        path = table_tools._cache_path(url)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"cached")
        self.addCleanup(lambda: path.unlink(missing_ok=True))
        presign = MagicMock(side_effect=AssertionError("缓存命中不应下载"))
        with patch.object(table_tools.storage_service, "get_presigned_url", new=presign):
            got = await table_tools._ensure_local_file(url)
        self.assertEqual(got, path)
        presign.assert_not_called()

    def test_cache_cleanup_expired(self):
        expired = table_tools.CACHE_DIR / "expired_test.db"
        expired.parent.mkdir(parents=True, exist_ok=True)
        expired.write_bytes(b"x")
        import os
        old = time.time() - 7200
        os.utime(expired, (old, old))
        table_tools._cleanup_cache()
        self.assertFalse(expired.exists())


if __name__ == "__main__":
    unittest.main()