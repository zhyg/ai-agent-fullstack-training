"""检索服务单测（T026）：三种检索 + RRF 融合去重截断 + 多库 + 异常分级（mock ES/网关）."""
import unittest
from unittest.mock import AsyncMock, patch

from elasticsearch import TransportError

from app.services import retrieval_service
from app.services.retrieval_service import EmbeddingFailedError, RetrievalUnavailableError


def make_hit(chunk_id, index="knowledge_chunks_kb1", score=1.0, **extra):
    src = {
        "chunk_id": chunk_id,
        "document_id": f"doc-{chunk_id}",
        "content": f"content of {chunk_id}",
        "chunk_type": "text",
        "file_name": f"{chunk_id}.pdf",
        **extra,
    }
    return {"_id": chunk_id, "_index": index, "_score": score, "_source": src}


def mock_es(hits=None, side_effect=None):
    client = AsyncMock()
    if side_effect is not None:
        client.search.side_effect = side_effect
    else:
        client.search.return_value = {"hits": {"hits": hits or []}}
    return client


class Bm25Tests(unittest.IsolatedAsyncioTestCase):
    async def test_bm25_match_query_and_mapping(self):
        client = mock_es([make_hit("c1", score=3.2), make_hit("c2", index="knowledge_chunks_kb2", score=1.1)])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)):
            chunks = await retrieval_service.retrieve("bm25", "问题", ["kb1", "kb2"], keyword_top_k=7)
        kwargs = client.search.call_args.kwargs
        self.assertEqual(kwargs["index"], "knowledge_chunks_kb1,knowledge_chunks_kb2")
        self.assertTrue(kwargs["ignore_unavailable"])
        self.assertEqual(kwargs["body"]["query"], {"match": {"content": "问题"}})
        self.assertEqual(kwargs["body"]["size"], 7)
        self.assertEqual([c.chunk_id for c in chunks], ["c1", "c2"])
        self.assertEqual(chunks[0].kb_id, "kb1")
        self.assertEqual(chunks[1].kb_id, "kb2")
        self.assertEqual(chunks[0].score, 3.2)

    async def test_keyword_alias_maps_to_bm25(self):
        client = mock_es([make_hit("c1")])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)):
            await retrieval_service.retrieve("keyword", "问题", ["kb1"])
        self.assertIn("match", client.search.call_args.kwargs["body"]["query"])

    async def test_missing_index_returns_empty(self):
        client = mock_es([])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)):
            chunks = await retrieval_service.retrieve("bm25", "问题", ["kb-missing"])
        self.assertEqual(chunks, [])

    async def test_empty_kb_ids_short_circuit(self):
        chunks = await retrieval_service.retrieve("hybrid", "问题", [])
        self.assertEqual(chunks, [])

    async def test_es_error_raises_flow_level(self):
        client = mock_es(side_effect=TransportError("connection refused"))
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)):
            with self.assertRaises(RetrievalUnavailableError):
                await retrieval_service.retrieve("bm25", "问题", ["kb1"])


class VectorTests(unittest.IsolatedAsyncioTestCase):
    async def test_vector_script_score_and_embedding(self):
        client = mock_es([make_hit("c1", score=1.8)])
        embed = AsyncMock(return_value=[[0.1] * 4])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)), \
             patch.object(retrieval_service.embedding_service, "generate_embeddings", new=embed):
            chunks = await retrieval_service.retrieve(
                "vector", "问题", ["kb1"], vector_top_k=5, embedding_model_id="emb-1",
            )
        embed.assert_awaited_once_with(["问题"], "emb-1")
        body = client.search.call_args.kwargs["body"]
        script = body["query"]["script_score"]["script"]
        self.assertIn("cosineSimilarity", script["source"])
        self.assertEqual(script["params"]["qv"], [0.1] * 4)
        self.assertEqual(body["size"], 5)
        self.assertEqual(chunks[0].chunk_id, "c1")

    async def test_embedding_failure_raises_flow_level(self):
        client = mock_es([])
        embed = AsyncMock(side_effect=RuntimeError("gateway down"))
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)), \
             patch.object(retrieval_service.embedding_service, "generate_embeddings", new=embed):
            with self.assertRaises(EmbeddingFailedError):
                await retrieval_service.retrieve("vector", "问题", ["kb1"], embedding_model_id="emb-1")
        client.search.assert_not_awaited()

    async def test_vector_without_embedding_model_raises(self):
        with self.assertRaises(EmbeddingFailedError):
            await retrieval_service.retrieve("vector", "问题", ["kb1"])


class HybridRrfTests(unittest.IsolatedAsyncioTestCase):
    async def test_rrf_fusion_dedup_and_order(self):
        # bm25: A B C；vector: B D A → B=1/62+1/61, A=1/61+1/63, D=1/62, C=1/63
        bm25 = [make_hit("A", score=9), make_hit("B", score=5), make_hit("C", score=1)]
        vector = [make_hit("B", score=1.9), make_hit("D", score=1.5), make_hit("A", score=1.2)]
        client = AsyncMock()
        client.search.side_effect = [
            {"hits": {"hits": bm25}},
            {"hits": {"hits": vector}},
        ]
        embed = AsyncMock(return_value=[[0.2] * 4])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)), \
             patch.object(retrieval_service.embedding_service, "generate_embeddings", new=embed):
            chunks = await retrieval_service.retrieve(
                "hybrid", "问题", ["kb1"], hybrid_top_k=10, embedding_model_id="emb-1",
            )
        self.assertEqual([c.chunk_id for c in chunks], ["B", "A", "D", "C"])
        scores = {c.chunk_id: c.score for c in chunks}
        self.assertAlmostEqual(scores["B"], 1 / 62 + 1 / 61)
        self.assertAlmostEqual(scores["A"], 1 / 61 + 1 / 63)
        self.assertAlmostEqual(scores["D"], 1 / 62)
        self.assertEqual(len(chunks), 4)  # 去重：B/A 两路命中仅一条

    async def test_rrf_truncates_to_hybrid_top_k(self):
        bm25 = [make_hit(f"b{i}") for i in range(5)]
        vector = [make_hit(f"v{i}") for i in range(5)]
        client = AsyncMock()
        client.search.side_effect = [
            {"hits": {"hits": bm25}},
            {"hits": {"hits": vector}},
        ]
        embed = AsyncMock(return_value=[[0.2] * 4])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)), \
             patch.object(retrieval_service.embedding_service, "generate_embeddings", new=embed):
            chunks = await retrieval_service.retrieve(
                "hybrid", "问题", ["kb1"], hybrid_top_k=3, embedding_model_id="emb-1",
            )
        self.assertEqual(len(chunks), 3)
        # 两路第一名并列融合分最高
        self.assertEqual({c.chunk_id for c in chunks[:2]}, {"b0", "v0"})

    async def test_rrf_k_configurable(self):
        bm25 = [make_hit("A")]
        vector = [make_hit("A")]
        client = AsyncMock()
        client.search.side_effect = [
            {"hits": {"hits": bm25}},
            {"hits": {"hits": vector}},
        ]
        embed = AsyncMock(return_value=[[0.2] * 4])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)), \
             patch.object(retrieval_service.embedding_service, "generate_embeddings", new=embed):
            chunks = await retrieval_service.retrieve(
                "hybrid", "问题", ["kb1"], embedding_model_id="emb-1", rrf_k=10,
            )
        self.assertAlmostEqual(chunks[0].score, 1 / 11 + 1 / 11)

    async def test_sqlite_url_collected(self):
        hit = make_hit("t1", sqlite_url="kb1/doc1/tables/t1.sqlite")
        client = mock_es([hit])
        with patch.object(retrieval_service.es_client, "get_async_client", new=AsyncMock(return_value=client)):
            chunks = await retrieval_service.retrieve("bm25", "问题", ["kb1"])
        self.assertEqual(chunks[0].sqlite_url, "kb1/doc1/tables/t1.sqlite")


if __name__ == "__main__":
    unittest.main()