"""Share Markdown image assets within an archive."""

import sqlalchemy as sa
from alembic import op

revision = "f49b738a2c01"
down_revision = "c0c998f74bab"
branch_labels = None
depends_on = None
SCHEMA = "knowledge_manage"


def upgrade():
    op.create_table(
        "archive_images",
        sa.Column("key", sa.String(300), primary_key=True),
        sa.Column("kb_id", sa.String(36), sa.ForeignKey(f"{SCHEMA}.knowledge_bases.id", ondelete="CASCADE"), nullable=False),
        sa.Column("analysis", sa.JSON()),
        schema=SCHEMA,
    )
    op.create_table(
        "archive_image_references",
        sa.Column("document_id", sa.String(36), sa.ForeignKey(f"{SCHEMA}.documents.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("path_hash", sa.String(64), primary_key=True),
        sa.Column("image_key", sa.String(300), sa.ForeignKey(f"{SCHEMA}.archive_images.key", ondelete="CASCADE"), nullable=False),
        schema=SCHEMA,
    )
    op.create_index("ix_archive_image_references_image_key", "archive_image_references", ["image_key"], schema=SCHEMA)


def downgrade():
    op.drop_table("archive_image_references", schema=SCHEMA)
    op.drop_table("archive_images", schema=SCHEMA)
