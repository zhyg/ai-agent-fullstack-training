import os
import yaml
from pydantic import BaseModel, Field
from typing import Optional


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8002


class DatabaseConfig(BaseModel):
    url: str
    db_schema: str = Field(default="public", validation_alias="schema")
    echo: bool = False


class JwtConfig(BaseModel):
    secret_key: "[REDACTED]"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7


class LoggingConfig(BaseModel):
    level: str = "INFO"


class RedisConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 6379
    db: int = 0
    password: "[REDACTED]"

    @property
    def url(self) -> str:
        auth = f":{self.password}@" if self.password else ""
        return f"redis://{auth}{self.host}:{self.port}/{self.db}"


class MinioConfig(BaseModel):
    endpoint: str = "127.0.0.1:9000"
    access_key: "[REDACTED]"
    secret_key: "[REDACTED]"
    secure: bool = False
    bucket: str = "myknowlege"


class ElasticsearchConfig(BaseModel):
    hosts: str = "http://localhost:9200"
    username: str = "elastic"
    password: "[REDACTED]"


class TracingConfig(BaseModel):
    enabled: bool = True
    otlp_endpoint: str = "http://localhost:4317"
    service_name: str = "knowledge-manage-agent"


class AgentRuntimeConfig(BaseModel):
    tool_result_max_tokens: int = 4000
    history_rounds: int = 10
    similarity_threshold: float = 0.9
    sqlite_max_bytes: int = 52428800
    sqlite_download_timeout: int = 30
    sqlite_cache_ttl: int = 3600
    sql_max_rows: int = 500
    presign_expires: int = 86400
    rrf_k: int = 60
    history_retrieve_timeout: float = 3


class PrometheusConfig(BaseModel):
    url: str = "http://localhost:9091"
    timeout: float = 10.0
    retention_days: int = 15


class Settings(BaseModel):
    server: ServerConfig
    database: DatabaseConfig
    jwt: JwtConfig
    redis: RedisConfig = RedisConfig()
    minio: MinioConfig = MinioConfig()
    elasticsearch: ElasticsearchConfig = ElasticsearchConfig()
    services: dict = {}
    llm_api_key: "[REDACTED]"
    logging: LoggingConfig = LoggingConfig()
    tracing: TracingConfig = TracingConfig()
    agent_runtime: AgentRuntimeConfig = AgentRuntimeConfig()
    prometheus: PrometheusConfig = PrometheusConfig()


def load_settings(env: Optional[str] = None) -> Settings:
    env = env or os.getenv("APP_ENV", "dev")
    config_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        f"config.{env}.yaml"
    )
    with open(config_path) as f:
        data = yaml.safe_load(f)
    return Settings(**data)


settings = load_settings()
