import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, TIMESTAMP, Index, UniqueConstraint, ForeignKey

from app.core.database import Base
from app.core.config import settings


class Folder(Base):
    __tablename__ = "folders"
    __table_args__ = (
        UniqueConstraint('kb_id', 'parent_id', 'name', name='uq_folder_parent_name'),
        Index("idx_folder_kb", "kb_id"),
        Index("idx_folder_parent", "parent_id"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(200), nullable=False, comment="目录名称")
    kb_id = Column(
        String(36),
        ForeignKey(f"{settings.database.db_schema}.knowledge_bases.id", ondelete="CASCADE"),
        nullable=False,
        comment="所属知识库 ID",
    )
    parent_id = Column(
        String(36),
        ForeignKey(f"{settings.database.db_schema}.folders.id", ondelete="CASCADE"),
        nullable=True,
        comment="父目录 ID，NULL 表示根目录",
    )
    order = Column(Integer, nullable=False, default=0, comment="同级排序序号")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
