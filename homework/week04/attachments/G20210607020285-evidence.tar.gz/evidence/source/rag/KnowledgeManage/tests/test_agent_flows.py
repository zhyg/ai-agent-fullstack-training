"""三类智能体流程单测（T028/T032/T039/T042）：流程分支 / JSON 容错重试 / 压缩校验 / 入口错误映射 / 规划决策循环 / 停止检查点（mock 网关/ES）."""
import asyncio
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import app.services.agent_runtime as runtime
from app.schemas.agent import TOOL_KEYS
from app.schemas.agent_runtime import ClarifyResult, CompressResult, RewriteResult, SufficiencyResult, ToolResult
from app.services.agent_runtime import budget, citation, llm_client, steps, tracing
from app.services.agent_runtime.flows import planning_reasoning, quick_qa, reasoning_action
from app.services.agent_runtime.tools import table_tools
from app.services.agent_runtime.llm_client import (
    AgentCancelled,
    JsonValidationFailed,
    ModelUnavailableError,
)
from app.services.agent_runtime.snapshot import ConfigInvalidError
from app.services.agent_runtime.state import (
    AgentConfigSnapshot,
    ContextChunk,
    ModelRef,
    PromptSnapshot,
    RequestRuntimeState,
    RetrievalConfig,
)
from app.services.retrieval_service import EmbeddingFailedError, RetrievalUnavailableError


def make_snapshot(agent_type="quick_qa", loop_count=10, context_tokens=128000):
    prompts = {
        p: PromptSnapshot(prompt_id=f"p-{p}", name=p, version="v1",
                          content=f"{p} 提示词：{{question}} {{history}} {{chunks}} {{context}} {{last_question}}")
        for p in ("clarify", "rewrite", "compress", "answer", "sufficiency")
    }
    return AgentConfigSnapshot(
        agent_id="a1", agent_type=agent_type, prompts=prompts,
        analysis_model=ModelRef("m1", "gpt-test", context_tokens),
        embedding_model=ModelRef("m2", "emb-test", 0),
        rerank_model=ModelRef("m3", "rerank-test", 0),
        retrieval=RetrievalConfig(mode="hybrid"),
        loop_count=loop_count,
        kb_ids=["kb1"],
    )


def make_state(snapshot=None, question="原始问题"):
    return RequestRuntimeState(
        generation_id="g1", chat_id="c1", user_id="u1",
        snapshot=snapshot or make_snapshot(), question=question,
        history=[{"role": "user", "content": question}],
    )


def make_chunk(chunk_id, content="正文"):
    return ContextChunk(chunk_id=chunk_id, document_id=f"doc-{chunk_id}", kb_id="kb1",
                        file_name=f"{chunk_id}.pdf", content=content)


class Collector:
    def __init__(self):
        self.events = []

    async def __call__(self, sse_str):
        self.events.append(json.loads(sse_str.removeprefix("data: ").strip()))


def json_router(results):
    """按 purpose 分发 call_json 结果；值为 Exception 时抛出."""
    async def _call(model, messages, result_model, *, purpose, **kwargs):
        r = results[purpose]
        if isinstance(r, Exception):
            raise r
        return r
    return AsyncMock(side_effect=_call)


def seq_router(script):
    """按 purpose 分发多轮结果序列（耗尽后重复末项）；用于循环流程逐轮不同输出."""
    seqs = {p: list(v) for p, v in script.items()}

    async def _call(model, messages, result_model, *, purpose, **kwargs):
        seq = seqs[purpose]
        r = seq.pop(0) if len(seq) > 1 else seq[0]
        if isinstance(r, Exception):
            raise r
        return r
    return AsyncMock(side_effect=_call)


def stream_mock(chunks):
    async def _stream(*args, **kwargs):
        for c in chunks:
            yield c
    return MagicMock(side_effect=_stream)


def delta(content):
    return {"choices": [{"delta": {"content": content}}]}


def resp(content):
    return {"choices": [{"message": {"content": content}}]}


def tool_resp(calls):
    """规划决策响应：calls 为 (call_id, tool_name, args) 列表."""
    return {"choices": [{"message": {
        "role": "assistant", "content": "",
        "tool_calls": [
            {"id": cid, "type": "function",
             "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}}
            for cid, name, args in calls
        ],
    }}]}


def finish_resp(text="信息已足够，进入答案生成。"):
    return {"choices": [{"message": {"role": "assistant", "content": text}}]}


def make_planning_snapshot(tools=None, loop_count=100):
    snap = make_snapshot(agent_type="planning_reasoning", loop_count=loop_count)
    snap.tools = list(tools if tools is not None else TOOL_KEYS)
    snap.prompts["planning"] = PromptSnapshot(
        prompt_id="p-planning", name="planning", version="v1",
        content="planning 提示词：{question} {history}",
    )
    return snap


class QuickQaFlowTests(unittest.IsolatedAsyncioTestCase):
    async def test_full_flow_with_references_and_usage(self):
        state = make_state()
        emit = Collector()
        hits = [make_chunk("r1"), make_chunk("r2"), make_chunk("r3")]
        ranked = [hits[1], hits[0], hits[2]]
        call_json = json_router({
            "clarify": ClarifyResult(clear=True),
            "rewrite": RewriteResult(rewritten_question="重写问题"),
            "compress": CompressResult(kept_indexes=[0, 2]),  # 保留 r2/r3
        })
        retrieve = AsyncMock(return_value=hits)
        rerank = AsyncMock(return_value=(ranked, False))
        stream = stream_mock([
            delta('结论<ref id="c'), delta('1"/>；'),
            delta('另一结论<ref id="c9"/>。'),  # c9 无效句柄 → 丢弃
            {"choices": [{"delta": {}}], "usage": {"prompt_tokens": 10, "completion_tokens": 5}},
        ])
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=stream), \
             patch.object(quick_qa.retrieval_service, "retrieve", new=retrieve), \
             patch.object(quick_qa.rerank_service, "rerank", new=rerank):
            result = await quick_qa.run_quick_qa(state, emit)

        self.assertEqual(result["content"], '结论<ref id="c1"/>；另一结论。')
        self.assertEqual(state.current_question, "重写问题")
        self.assertEqual(retrieve.call_args.args[1], "重写问题")  # 检索用重写问题
        refs = result["meta"]["references"]
        self.assertEqual([r["handle"] for r in refs], ["c1", "c2"])
        self.assertEqual([r["chunk_id"] for r in refs], ["r2", "r3"])
        self.assertEqual(result["meta"]["usage"], {"prompt_tokens": 10, "completion_tokens": 5})
        # 无效句柄记事件；references 先于首个 delta 下发
        self.assertIn({"event": tracing.EVENT_INVALID_REF_DROPPED, "handle": "c9"}, result["meta"]["events"])
        types = [e["type"] for e in emit.events]
        self.assertLess(types.index("references"), types.index("delta"))
        self.assertEqual(state.partial_answer, result["content"])

    async def test_clarify_false_terminates_with_reason(self):
        state = make_state()
        call_json = json_router({"clarify": ClarifyResult(clear=False, reason="请补充产品型号")})
        retrieve = AsyncMock()
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(quick_qa.retrieval_service, "retrieve", new=retrieve):
            result = await quick_qa.run_quick_qa(state, Collector())
        self.assertEqual(result["content"], "请补充产品型号")
        self.assertEqual(result["meta"]["terminate_reason"], "clarify_failed")
        retrieve.assert_not_awaited()

    async def test_clarify_false_without_reason_uses_fallback(self):
        state = make_state()
        call_json = json_router({"clarify": ClarifyResult(clear=False)})
        with patch.object(llm_client, "call_json", new=call_json):
            result = await quick_qa.run_quick_qa(state, Collector())
        self.assertEqual(result["content"], quick_qa.UNCLEAR_FALLBACK_TEXT)

    async def test_empty_retrieval_terminates(self):
        state = make_state()
        call_json = json_router({
            "clarify": ClarifyResult(clear=True),
            "rewrite": RewriteResult(rewritten_question="q"),
        })
        retrieve = AsyncMock(return_value=[])
        rerank = AsyncMock()
        stream = stream_mock([])
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=stream), \
             patch.object(quick_qa.retrieval_service, "retrieve", new=retrieve), \
             patch.object(quick_qa.rerank_service, "rerank", new=rerank):
            result = await quick_qa.run_quick_qa(state, Collector())
        self.assertEqual(result["content"], quick_qa.EMPTY_RETRIEVAL_TEXT)
        self.assertEqual(result["meta"]["terminate_reason"], "empty_retrieval")
        rerank.assert_not_awaited()  # 空召回跳过重排
        self.assertEqual(call_json.await_count, 2)  # compress 空列表跳过模型调用
        stream.assert_not_called()

    async def test_compress_empty_indexes_terminates(self):
        state = make_state()
        call_json = json_router({
            "clarify": ClarifyResult(clear=True),
            "rewrite": RewriteResult(rewritten_question="q"),
            "compress": CompressResult(kept_indexes=[]),  # 空数组合法 → 无相关片段
        })
        stream = stream_mock([])
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=stream), \
             patch.object(quick_qa.retrieval_service, "retrieve", new=AsyncMock(return_value=[make_chunk("r1")])), \
             patch.object(quick_qa.rerank_service, "rerank", new=AsyncMock(side_effect=lambda q, h, m, **k: (h, False))):
            result = await quick_qa.run_quick_qa(state, Collector())
        self.assertEqual(result["meta"]["terminate_reason"], "empty_retrieval")
        stream.assert_not_called()

    async def test_rerank_degraded_recorded_in_meta_events(self):
        state = make_state()
        hits = [make_chunk("r1")]
        call_json = json_router({
            "clarify": ClarifyResult(clear=True),
            "rewrite": RewriteResult(rewritten_question="q"),
            "compress": CompressResult(kept_indexes=[0]),
        })
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=stream_mock([delta("答案")])), \
             patch.object(quick_qa.retrieval_service, "retrieve", new=AsyncMock(return_value=hits)), \
             patch.object(quick_qa.rerank_service, "rerank", new=AsyncMock(return_value=(hits, True))):
            result = await quick_qa.run_quick_qa(state, Collector())
        self.assertEqual(result["content"], "答案")
        self.assertIn({"event": tracing.EVENT_RERANK_DEGRADED}, result["meta"]["events"])

    async def test_flow_level_errors_propagate_to_entry(self):
        for exc in (EmbeddingFailedError("向量化失败"), RetrievalUnavailableError("ES 挂了")):
            state = make_state()
            call_json = json_router({
                "clarify": ClarifyResult(clear=True),
                "rewrite": RewriteResult(rewritten_question="q"),
            })
            with patch.object(llm_client, "call_json", new=call_json), \
                 patch.object(quick_qa.retrieval_service, "retrieve", new=AsyncMock(side_effect=exc)):
                with self.assertRaises(type(exc)):
                    await quick_qa.run_quick_qa(state, Collector())

    async def test_cancel_before_start_skips_model_calls(self):
        state = make_state()
        state.cancel_event.set()
        call_json = AsyncMock()
        with patch.object(llm_client, "call_json", new=call_json):
            with self.assertRaises(AgentCancelled):
                await quick_qa.run_quick_qa(state, Collector())
        call_json.assert_not_awaited()


class JsonRetryTests(unittest.IsolatedAsyncioTestCase):
    async def _call(self, messages=None):
        return await llm_client.call_json(
            "gpt-test", messages or [{"role": "user", "content": "q"}],
            ClarifyResult, purpose="clarify",
        )

    async def test_code_fence_and_embedded_json_tolerated(self):
        for raw in ('```json\n{"clear": true}\n```', '前置说明 {"clear": true} 后记'):
            chat = AsyncMock(return_value=resp(raw))
            with patch.object(llm_client, "chat_completion", new=chat):
                result = await self._call()
            self.assertTrue(result.clear)
            self.assertEqual(chat.await_count, 1)

    async def test_retry_limit_4_and_raw_output(self):
        chat = AsyncMock(return_value=resp("完全不是JSON"))
        with patch.object(llm_client, "chat_completion", new=chat):
            with self.assertRaises(JsonValidationFailed) as ctx:
                await self._call()
        self.assertEqual(chat.await_count, 4)  # 首次 + 3 次重试
        self.assertEqual(ctx.exception.code, "clarify_json_failed")
        self.assertEqual(ctx.exception.raw_output, "完全不是JSON")

    async def test_retry_messages_include_last_output_and_error(self):
        chat = AsyncMock(side_effect=[resp("bad"), resp('{"clear": false, "reason": "补充"}')])
        with patch.object(llm_client, "chat_completion", new=chat):
            result = await self._call()
        self.assertFalse(result.clear)
        retry_convo = chat.call_args_list[1].args[1]
        self.assertEqual(retry_convo[0], {"role": "user", "content": "q"})
        self.assertEqual(retry_convo[1], {"role": "assistant", "content": "bad"})
        self.assertIn("未通过校验", retry_convo[2]["content"])

    async def test_transport_error_no_business_retry(self):
        chat = AsyncMock(side_effect=ModelUnavailableError("gateway down"))
        with patch.object(llm_client, "chat_completion", new=chat):
            with self.assertRaises(ModelUnavailableError):
                await self._call()
        self.assertEqual(chat.await_count, 1)


class CompressValidationTests(unittest.IsolatedAsyncioTestCase):
    async def test_out_of_bounds_retried_then_success(self):
        state = make_state()
        chunks = [make_chunk("r1"), make_chunk("r2")]
        chat = AsyncMock(side_effect=[resp('{"kept_indexes": [5]}'), resp('{"kept_indexes": [1]}')])
        with patch.object(llm_client, "chat_completion", new=chat):
            kept = await steps.run_compress(state, chunks, Collector())
        self.assertEqual([c.chunk_id for c in kept], ["r2"])
        self.assertEqual(chat.await_count, 2)

    async def test_duplicate_indexes_retried(self):
        state = make_state()
        chunks = [make_chunk("r1"), make_chunk("r2")]
        chat = AsyncMock(side_effect=[resp('{"kept_indexes": [0, 0]}'), resp('{"kept_indexes": [0]}')])
        with patch.object(llm_client, "chat_completion", new=chat):
            kept = await steps.run_compress(state, chunks, Collector())
        self.assertEqual([c.chunk_id for c in kept], ["r1"])
        self.assertEqual(chat.await_count, 2)

    async def test_empty_indexes_valid_without_retry(self):
        state = make_state()
        chat = AsyncMock(return_value=resp('{"kept_indexes": []}'))
        with patch.object(llm_client, "chat_completion", new=chat):
            kept = await steps.run_compress(state, [make_chunk("r1")], Collector())
        self.assertEqual(kept, [])
        self.assertEqual(chat.await_count, 1)

    async def test_empty_chunks_skip_model_call(self):
        chat = AsyncMock()
        with patch.object(llm_client, "chat_completion", new=chat):
            kept = await steps.run_compress(make_state(), [], Collector())
        self.assertEqual(kept, [])
        chat.assert_not_awaited()


class EntryErrorMappingTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.db = MagicMock()
        self.chat = SimpleNamespace(agent_id="a1", knowledge_base_ids=["kb1"])
        self.db.query.return_value.filter.return_value.first.return_value = self.chat
        self.snapshot = make_snapshot(agent_type="entry_test")
        db_patcher = patch("app.core.database.SessionLocal", return_value=self.db)
        snap_patcher = patch("app.services.agent_runtime.snapshot.build_snapshot", return_value=self.snapshot)
        hist_patcher = patch("app.services.history_qa_service.retrieve_and_assemble", new=AsyncMock())
        db_patcher.start(); self.addCleanup(db_patcher.stop)
        snap_patcher.start(); self.addCleanup(snap_patcher.stop)
        hist_patcher.start(); self.addCleanup(hist_patcher.stop)
        self.addCleanup(runtime._FLOW_RUNNERS.pop, "entry_test", None)

    def _register(self, runner):
        runtime.register_flow("entry_test", runner)

    async def _run(self):
        import asyncio
        return await runtime.run_agent_generation(
            chat_id="c1", user_id="u1", question="q",
            history=[{"role": "user", "content": "q"}],
            generation_id="g1", cancel_event=asyncio.Event(), emit=AsyncMock(),
        )

    async def test_success_result_contract(self):
        async def runner(state, emit):
            return {"content": "答案", "meta": {"references": []}}
        self._register(runner)
        result = await self._run()
        self.assertEqual(result["content"], "答案")
        self.assertFalse(result["cancelled"])
        self.assertIn("trace_id", result)
        self.assertNotIn("error", result)
        self.db.close.assert_called_once()

    async def test_json_failed_maps_code_and_raw_output(self):
        async def runner(state, emit):
            raise JsonValidationFailed("clarify", "原始输出", "字段缺失")
        self._register(runner)
        result = await self._run()
        self.assertEqual(result["error"]["code"], "clarify_json_failed")
        self.assertEqual(result["error"]["raw_output"], "原始输出")

    async def test_flow_level_error_codes(self):
        cases = [
            (EmbeddingFailedError("emb down"), "embedding_failed"),
            (RetrievalUnavailableError("es down"), "retrieval_unavailable"),
            (ModelUnavailableError("gw down"), "model_unavailable"),
            (RuntimeError("boom"), "internal_error"),
        ]
        for exc, code in cases:
            async def runner(state, emit, _exc=exc):
                raise _exc
            self._register(runner)
            result = await self._run()
            self.assertEqual(result["error"]["code"], code)
            self.assertFalse(result["cancelled"])

    async def test_cancelled_returns_partial_answer(self):
        async def runner(state, emit):
            state.partial_answer = "部分答案"
            raise AgentCancelled()
        self._register(runner)
        result = await self._run()
        self.assertTrue(result["cancelled"])
        self.assertEqual(result["content"], "部分答案")
        self.assertEqual(result["meta"], {"stopped": True})

    async def test_snapshot_preflight_config_invalid(self):
        async def runner(state, emit):
            return {"content": "", "meta": {}}
        self._register(runner)
        with patch("app.services.agent_runtime.snapshot.build_snapshot",
                   side_effect=ConfigInvalidError(["分析模型不存在或已删除"])):
            result = await self._run()
        self.assertEqual(result["error"]["code"], "config_invalid")
        self.assertIn("分析模型不存在", result["error"]["message"])

    async def test_chat_missing_or_unbound_config_invalid(self):
        self.db.query.return_value.filter.return_value.first.return_value = None
        result = await self._run()
        self.assertEqual(result["error"]["code"], "config_invalid")

    async def test_unregistered_agent_type_config_invalid(self):
        self.snapshot.agent_type = "unknown_type"
        result = await self._run()
        self.assertEqual(result["error"]["code"], "config_invalid")
        self.assertIn("暂不支持", result["error"]["message"])


class SufficiencySchemaTests(unittest.TestCase):
    def test_false_requires_new_question(self):
        with self.assertRaises(ValueError):
            SufficiencyResult(sufficient=False)
        with self.assertRaises(ValueError):
            SufficiencyResult(sufficient=False, new_question="  ")

    def test_true_rejects_non_null_new_question(self):
        with self.assertRaises(ValueError):
            SufficiencyResult(sufficient=True, new_question="多余问题")

    def test_true_empty_string_normalized_to_none(self):
        r = SufficiencyResult(sufficient=True, new_question=" ")
        self.assertIsNone(r.new_question)


class BudgetEvictionTests(unittest.TestCase):
    def test_history_dropped_first_then_oldest_chunks_keep_one(self):
        # 预算极小：历史先截光、片段淘汰到仅剩最新 1 条
        state = make_state(make_snapshot(context_tokens=60))
        state.snapshot.max_output_tokens = 10  # budget = 50
        state.history = [{"role": "user", "content": "历史问题" * 20}]
        for cid in ("old", "mid", "new"):
            state.merge_chunks([make_chunk(cid, content="片段内容" * 30)])
        report = budget.enforce_budget(state, ["固定开销"])
        self.assertEqual(report["dropped_history"], 1)
        self.assertEqual(state.history, [])
        self.assertEqual(report["dropped_chunks"], ["old", "mid"])
        self.assertEqual(list(state.chunks), ["new"])  # 保底最新 1 条

    def test_within_budget_no_eviction(self):
        state = make_state()
        state.merge_chunks([make_chunk("r1")])
        report = budget.enforce_budget(state, ["固定开销"])
        self.assertEqual(report["dropped_history"], 0)
        self.assertEqual(report["dropped_chunks"], [])
        self.assertLessEqual(report["used"], report["budget"])


class ReasoningActionTests(unittest.IsolatedAsyncioTestCase):
    def _state(self, loop_count=10):
        return make_state(make_snapshot(agent_type="reasoning_action", loop_count=loop_count))

    def _patches(self, call_json, retrieve, stream, rerank=None):
        if rerank is None:
            async def _rerank(q, hits, model, **k):
                return hits, False
            rerank = AsyncMock(side_effect=_rerank)
        return (
            patch.object(llm_client, "call_json", new=call_json),
            patch.object(llm_client, "stream_chat", new=stream),
            patch.object(reasoning_action.retrieval_service, "retrieve", new=retrieve),
            patch.object(reasoning_action.rerank_service, "rerank", new=rerank),
        )

    async def test_two_loops_then_forced_convergence(self):
        state = self._state(loop_count=2)
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="问题一"), RewriteResult(rewritten_question="问题二")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [
                SufficiencyResult(sufficient=False, new_question="补充甲方向的新问题"),
                SufficiencyResult(sufficient=False, new_question="补充乙方向的另一问题"),
            ],
        })
        retrieve = AsyncMock(side_effect=[[make_chunk("a")], [make_chunk("b")]])
        stream = stream_mock([delta("最终答案")])
        patches = self._patches(call_json, retrieve, stream)
        with patches[0], patches[1], patches[2], patches[3]:
            result = await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(result["content"], "最终答案")
        self.assertEqual(state.loop, 2)
        self.assertIn({"event": tracing.EVENT_FORCED_CONVERGENCE, "loop": 2}, result["meta"]["events"])
        self.assertEqual(list(state.chunks), ["a", "b"])  # 去重累积保留首次顺序
        self.assertEqual([c.first_loop for c in state.chunks.values()], [1, 2])
        # 第二轮重写输入为 sufficiency 的 new_question；检索用当轮重写问题
        rewrite_calls = [c for c in call_json.call_args_list if c.kwargs["purpose"] == "rewrite"]
        self.assertEqual(len(rewrite_calls), 2)
        self.assertIn("补充甲方向的新问题", rewrite_calls[1].args[1][0]["content"])
        self.assertEqual([c.args[1] for c in retrieve.call_args_list], ["问题一", "问题二"])

    async def test_empty_retrieval_loops_instead_of_terminating(self):
        state = self._state(loop_count=3)
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="q1"), RewriteResult(rewritten_question="q2")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [SufficiencyResult(sufficient=True)],
        })
        retrieve = AsyncMock(side_effect=[[], [make_chunk("a")]])
        stream = stream_mock([delta("答案")])
        patches = self._patches(call_json, retrieve, stream)
        with patches[0], patches[1], patches[2], patches[3]:
            result = await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(result["content"], "答案")
        self.assertNotIn("terminate_reason", result["meta"])
        sufficiency_calls = [c for c in call_json.call_args_list if c.kwargs["purpose"] == "sufficiency"]
        self.assertEqual(len(sufficiency_calls), 1)  # 空检索轮跳过充足判断模型调用
        self.assertEqual(state.loop, 2)

    async def test_duplicate_chunks_kept_once_with_first_loop(self):
        state = self._state(loop_count=3)
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="q1"), RewriteResult(rewritten_question="q2")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [
                SufficiencyResult(sufficient=False, new_question="差异很大的新问题"),
                SufficiencyResult(sufficient=True),
            ],
        })
        retrieve = AsyncMock(side_effect=[[make_chunk("same")], [make_chunk("same", content="重复命中")]])
        stream = stream_mock([delta("答案")])
        patches = self._patches(call_json, retrieve, stream)
        with patches[0], patches[1], patches[2], patches[3]:
            result = await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(list(state.chunks), ["same"])
        self.assertEqual(state.chunks["same"].first_loop, 1)
        self.assertEqual(len(result["meta"]["references"]), 1)

    async def test_idle_loop_converges_early(self):
        state = self._state(loop_count=10)
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="产品的价格是多少")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [SufficiencyResult(sufficient=False, new_question="产品的价格是多少？")],
        })
        retrieve = AsyncMock(return_value=[make_chunk("a")])
        stream = stream_mock([delta("提前收敛答案")])
        patches = self._patches(call_json, retrieve, stream)
        with patches[0], patches[1], patches[2], patches[3]:
            result = await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(result["content"], "提前收敛答案")
        self.assertEqual(state.loop, 1)  # 未进第二轮
        events = [e["event"] for e in result["meta"]["events"]]
        self.assertIn(tracing.EVENT_IDLE_LOOP_CONVERGED, events)
        self.assertNotIn(tracing.EVENT_FORCED_CONVERGENCE, events)

    async def test_forced_convergence_empty_context_no_material(self):
        state = self._state(loop_count=1)
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="q")],
        })
        retrieve = AsyncMock(return_value=[])
        stream = stream_mock([delta("不应出现")])
        patches = self._patches(call_json, retrieve, stream)
        with patches[0], patches[1], patches[2], patches[3]:
            result = await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(result["content"], reasoning_action.NO_MATERIAL_TEXT)
        self.assertEqual(result["meta"]["terminate_reason"], "empty_retrieval")
        self.assertIn({"event": tracing.EVENT_FORCED_CONVERGENCE, "loop": 1}, result["meta"]["events"])
        stream.assert_not_called()  # 无资料分支不调模型

    async def test_sufficient_first_round_answers_without_convergence_events(self):
        state = self._state()
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="q")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [SufficiencyResult(sufficient=True)],
        })
        retrieve = AsyncMock(return_value=[make_chunk("a")])
        stream = stream_mock([delta('答案<ref id="c1"/>')])
        patches = self._patches(call_json, retrieve, stream)
        with patches[0], patches[1], patches[2], patches[3]:
            result = await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(result["content"], '答案<ref id="c1"/>')
        self.assertEqual(state.loop, 1)
        self.assertNotIn("events", result["meta"])

    async def test_cancel_before_start_skips_model_calls(self):
        state = self._state()
        state.cancel_event.set()
        call_json = AsyncMock()
        with patch.object(llm_client, "call_json", new=call_json):
            with self.assertRaises(AgentCancelled):
                await reasoning_action.run_reasoning_action(state, Collector())
        call_json.assert_not_awaited()

    def test_registered_in_entry(self):
        runner = runtime._get_runner("reasoning_action")
        self.assertIs(runner, reasoning_action.run_reasoning_action)
        self.addCleanup(runtime._FLOW_RUNNERS.pop, "reasoning_action", None)


class PlanningReasoningTests(unittest.IsolatedAsyncioTestCase):
    """规划推理（T039）：决策循环计数 / 工具可见性 / 失败空结果回传 / 强制收敛 / 表格链路."""

    def _state(self, tools=None, loop_count=100):
        return make_state(make_planning_snapshot(tools, loop_count))

    def _patches(self, decisions, clarify=None, stream=None):
        return [
            patch.object(llm_client, "call_json", new=json_router({
                "clarify": clarify or ClarifyResult(clear=True),
            })),
            patch.object(llm_client, "chat_completion", new=AsyncMock(side_effect=list(decisions))),
            patch.object(llm_client, "stream_chat", new=stream or stream_mock([delta("答案")])),
        ]

    async def test_decision_loop_count_and_serial_tools(self):
        state = self._state()
        emit = Collector()
        decisions = [
            tool_resp([
                ("c1", "createPlan", {"title": "计划", "steps": [{"description": "检索"}]}),
                ("c2", "listPlan", {}),
            ]),
            finish_resp(),
        ]
        patches = self._patches(decisions)
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, emit)
        self.assertEqual(result["content"], "答案")
        self.assertEqual(state.loop, 2)  # 每次决策计一轮，一轮多工具不另计数
        tool_msgs = [m for m in state.messages_for_model if m["role"] == "tool"]
        self.assertEqual([m["tool_call_id"] for m in tool_msgs], ["c1", "c2"])  # 串行且 call_id 透传
        self.assertIsNotNone(state.plan)
        steps_seen = [(e.get("step"), e.get("tool_name"), e.get("loop")) for e in emit.events if e["type"] == "step"]
        self.assertIn(("plan_decision", None, 1), steps_seen)
        self.assertIn(("tool", "createPlan", 1), steps_seen)
        self.assertIn(("tool", "listPlan", 1), steps_seen)
        self.assertIn(("plan_decision", None, 2), steps_seen)

    async def test_disabled_tools_invisible_to_model(self):
        state = self._state(tools=["createPlan"])
        patches = self._patches([finish_resp()])
        with patches[0], patches[1], patches[2]:
            await planning_reasoning.run_planning_reasoning(state, Collector())
        completion = patches[1].new
        declared = [d["function"]["name"] for d in completion.call_args.kwargs["tools"]]
        self.assertEqual(declared, ["createPlan"])

    async def test_empty_tool_result_returned_and_flow_continues(self):
        state = self._state()
        decisions = [tool_resp([("c1", "bm25Search", {"query": "q"})]), finish_resp()]
        retrieve = AsyncMock(return_value=[])
        patches = self._patches(decisions)
        with patches[0], patches[1], patches[2], \
             patch("app.services.retrieval_service.retrieve", new=retrieve):
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        tool_msg = next(m for m in state.messages_for_model if m["role"] == "tool")
        self.assertEqual(json.loads(tool_msg["content"])["code"], "empty_result")
        self.assertEqual(result["content"], "答案")  # 空结果不终止流程

    async def test_invalid_json_args_envelope_returned(self):
        state = self._state()
        bad = {"choices": [{"message": {"role": "assistant", "content": "", "tool_calls": [
            {"id": "c1", "type": "function", "function": {"name": "listPlan", "arguments": "not-json"}},
        ]}}]}
        patches = self._patches([bad, finish_resp()])
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        tool_msg = next(m for m in state.messages_for_model if m["role"] == "tool")
        self.assertEqual(json.loads(tool_msg["content"])["code"], "invalid_args")
        self.assertEqual(result["content"], "答案")

    async def test_forced_convergence_at_loop_limit(self):
        state = self._state(loop_count=1)
        decisions = [tool_resp([("c1", "listPlan", {})])]  # 第二轮入口不再调模型
        patches = self._patches(decisions)
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        self.assertEqual(patches[1].new.await_count, 1)
        self.assertEqual(state.loop, 1)
        self.assertIn({"event": tracing.EVENT_FORCED_CONVERGENCE, "loop": 1}, result["meta"]["events"])
        self.assertEqual(result["content"], "答案")  # 有工具产出，携带上下文作答

    async def test_no_chunks_no_tool_output_no_material(self):
        state = self._state()
        stream = stream_mock([delta("不应出现")])
        patches = self._patches([finish_resp()], stream=stream)
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        self.assertEqual(result["content"], planning_reasoning.NO_MATERIAL_TEXT)
        self.assertEqual(result["meta"]["terminate_reason"], "empty_retrieval")
        stream.assert_not_called()

    async def test_clarify_false_terminates_before_decision(self):
        state = self._state()
        patches = self._patches([], clarify=ClarifyResult(clear=False, reason="请补充范围"))
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        self.assertEqual(result["content"], "请补充范围")
        patches[1].new.assert_not_awaited()

    async def test_table_composite_chain(self):
        state = self._state()
        url = "kb1/doc-x/sales.db"
        chunk = make_chunk("t1", content="销售表格")
        chunk.sqlite_url = url
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sales.db"
            conn = sqlite3.connect(db_path)
            conn.execute("CREATE TABLE sales (region TEXT, amount INTEGER)")
            conn.executemany("INSERT INTO sales VALUES (?, ?)", [("华东", 10), ("华北", 20), ("华南", 30)])
            conn.commit()
            conn.close()
            decisions = [
                tool_resp([("c1", "bm25Search", {"query": "销售"})]),
                tool_resp([("c2", "listTableMetaData", {"sqlite_url": url})]),
                tool_resp([("c3", "sqlExecute", {"sqlite_url": url, "sql_query": "SELECT SUM(amount) AS total FROM sales"})]),
                finish_resp(),
            ]
            patches = self._patches(decisions)
            with patches[0], patches[1], patches[2], \
                 patch("app.services.retrieval_service.retrieve", new=AsyncMock(return_value=[chunk])), \
                 patch.object(table_tools, "_ensure_local_file", new=AsyncMock(return_value=db_path)):
                result = await planning_reasoning.run_planning_reasoning(state, Collector())
        self.assertEqual(result["content"], "答案")
        self.assertEqual(state.loop, 4)
        self.assertIn(url, state.sqlite_whitelist)  # 检索命中入白名单
        tool_msgs = {m["tool_call_id"]: json.loads(m["content"]) for m in state.messages_for_model if m["role"] == "tool"}
        meta_payload = json.loads(tool_msgs["c2"]["content"])
        self.assertEqual(meta_payload["tables"][0]["name"], "sales")
        sql_payload = json.loads(tool_msgs["c3"]["content"])
        self.assertEqual(sql_payload["rows"], [[60]])
        self.assertEqual(len(result["meta"]["references"]), 1)  # 表格片段可引用

    async def test_forbidden_sql_returned_to_model(self):
        state = self._state()
        url = "kb1/doc-x/sales.db"
        state.sqlite_whitelist.add(url)
        decisions = [
            tool_resp([("c1", "sqlExecute", {"sqlite_url": url, "sql_query": "DROP TABLE sales"})]),
            finish_resp(),
        ]
        patches = self._patches(decisions)
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        tool_msg = next(m for m in state.messages_for_model if m["role"] == "tool")
        self.assertEqual(json.loads(tool_msg["content"])["code"], "forbidden_sql")
        self.assertEqual(result["content"], "答案")

    async def test_cancel_between_tools_stops_flow(self):
        state = self._state()
        decisions = [tool_resp([("c1", "listPlan", {}), ("c2", "listPlan", {})])]

        async def _first_then_cancel(call_id, name, args, ctx):
            ctx.cancel_event.set()
            return ToolResult(success=True, code="ok", content='{"plans": []}')

        execute = AsyncMock(side_effect=_first_then_cancel)
        patches = self._patches(decisions)
        with patches[0], patches[1], patches[2], \
             patch.object(planning_reasoning.tool_runtime, "execute_tool", new=execute):
            with self.assertRaises(AgentCancelled):
                await planning_reasoning.run_planning_reasoning(state, Collector())
        self.assertEqual(execute.await_count, 1)  # 第二个工具执行前命中取消检查点

    def test_registered_in_entry(self):
        runner = runtime._get_runner("planning_reasoning")
        self.assertIs(runner, planning_reasoning.run_planning_reasoning)
        self.addCleanup(runtime._FLOW_RUNNERS.pop, "planning_reasoning", None)

    async def test_cancel_before_start_skips_decision_calls(self):
        state = self._state()
        state.cancel_event.set()
        completion = AsyncMock()
        with patch.object(llm_client, "chat_completion", new=completion):
            with self.assertRaises(AgentCancelled):
                await planning_reasoning.run_planning_reasoning(state, Collector())
        completion.assert_not_awaited()

    async def test_answer_request_ends_with_user_instruction(self):
        # 收敛说明已含答案文本时，答案请求必须以 user 指令收尾，避免模型只补引用标记
        state = self._state()
        decisions = [
            tool_resp([("c1", "listPlan", {})]),
            finish_resp("信息已足够，李四的语文成绩是 85 分。"),
        ]
        stream = stream_mock([delta("答案")])
        patches = self._patches(decisions, stream=stream)
        with patches[0], patches[1], patches[2]:
            await planning_reasoning.run_planning_reasoning(state, Collector())
        messages = stream.call_args.args[1]
        self.assertEqual(messages[-1]["role"], "user")
        self.assertEqual(messages[-1]["content"], planning_reasoning.ANSWER_INSTRUCTION)
        self.assertEqual(messages[-2]["role"], "assistant")  # 收敛说明保留在指令之前
        # 指令仅用于答案请求，不污染决策消息序列
        self.assertEqual(state.messages_for_model[-1]["role"], "assistant")


class StopGenerationTests(unittest.IsolatedAsyncioTestCase):
    """停止检查点（T040/T042，SC-005）：答案流中/循环轮间停止无新调用，部分答案保留."""

    async def test_quick_qa_cancel_mid_answer_keeps_partial(self):
        state = make_state()
        call_json = json_router({
            "clarify": ClarifyResult(clear=True),
            "rewrite": RewriteResult(rewritten_question="q"),
            "compress": CompressResult(kept_indexes=[0]),
        })

        async def _interrupted_stream(*args, **kwargs):
            yield delta("部分答案")
            raise AgentCancelled()  # 模拟 delta 批间命中取消检查点

        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=MagicMock(side_effect=_interrupted_stream)), \
             patch.object(quick_qa.retrieval_service, "retrieve", new=AsyncMock(return_value=[make_chunk("r1")])), \
             patch.object(quick_qa.rerank_service, "rerank", new=AsyncMock(side_effect=lambda q, h, m, **k: (h, False))):
            with self.assertRaises(AgentCancelled):
                await quick_qa.run_quick_qa(state, Collector())
        self.assertEqual(state.partial_answer, "部分答案")  # 入口据此落库+"\n[已停止]"

    async def test_reasoning_cancel_between_rounds_no_new_calls(self):
        state = make_state(make_snapshot(agent_type="reasoning_action", loop_count=5))
        base = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="q1")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [SufficiencyResult(sufficient=False, new_question="完全不同的新问题")],
        })

        async def _cancel_after_sufficiency(model, messages, result_model, *, purpose, **kwargs):
            result = await base(model, messages, result_model, purpose=purpose, **kwargs)
            if purpose == "sufficiency":
                state.cancel_event.set()  # 第一轮结束后停止
            return result

        call_json = AsyncMock(side_effect=_cancel_after_sufficiency)
        retrieve = AsyncMock(return_value=[make_chunk("a")])
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(reasoning_action.retrieval_service, "retrieve", new=retrieve), \
             patch.object(reasoning_action.rerank_service, "rerank", new=AsyncMock(side_effect=lambda q, h, m, **k: (h, False))):
            with self.assertRaises(AgentCancelled):
                await reasoning_action.run_reasoning_action(state, Collector())
        self.assertEqual(call_json.await_count, 4)  # clarify/rewrite/compress/sufficiency 各 1，第二轮未发起
        self.assertEqual(retrieve.await_count, 1)
        self.assertEqual(state.loop, 1)

    async def test_stream_chat_cancel_between_delta_batches(self):
        """llm_client 真实流式实现：delta 批间检查点命中后不再消费上游."""
        cancel = asyncio.Event()
        consumed = []

        async def _lines():
            consumed.append(1)
            yield 'data: {"choices": [{"delta": {"content": "a"}}]}'
            consumed.append(2)
            yield 'data: {"choices": [{"delta": {"content": "b"}}]}'

        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        resp.aiter_lines = _lines
        stream_cm = AsyncMock()
        stream_cm.__aenter__.return_value = resp
        client = MagicMock()
        client.stream.return_value = stream_cm
        client_cm = AsyncMock()
        client_cm.__aenter__.return_value = client
        with patch.object(llm_client.httpx, "AsyncClient", return_value=client_cm):
            gen = llm_client.stream_chat(
                "m", [{"role": "user", "content": "q"}], cancel_event=cancel,
            )
            first = await gen.__anext__()
            self.assertEqual(first["choices"][0]["delta"]["content"], "a")
            cancel.set()  # 下游消费首批 delta 期间用户停止，拉取下一批前命中检查点
            with self.assertRaises(AgentCancelled):
                await gen.__anext__()
        self.assertEqual(consumed, [1])  # 第二批未消费，无新上游读取


class HistoryRetrieveEntryTests(unittest.IsolatedAsyncioTestCase):
    """013 T005：history_retrieve 入口接线——每请求一次、先于 clarify、三类共用（FR-009）."""

    def setUp(self):
        self.db = MagicMock()
        self.chat = SimpleNamespace(agent_id="a1", knowledge_base_ids=["kb1"])
        self.db.query.return_value.filter.return_value.first.return_value = self.chat
        db_patcher = patch("app.core.database.SessionLocal", return_value=self.db)
        db_patcher.start(); self.addCleanup(db_patcher.stop)

    async def _run_entry(self, snapshot, emit, runner=None):
        if runner is not None:
            runtime.register_flow(snapshot.agent_type, runner)
            self.addCleanup(runtime._FLOW_RUNNERS.pop, snapshot.agent_type, None)
        client = MagicMock()
        hit = {"_id": "h1", "_score": 1.0, "_source": {
            "question": "早期问题", "answer": "早期答案",
            "created_at": "2026-01-01T00:00:00+00:00",
        }}
        client.search = AsyncMock(side_effect=[
            {"hits": {"hits": [hit]}}, {"hits": {"hits": []}},
        ])
        with patch("app.services.agent_runtime.snapshot.build_snapshot", return_value=snapshot), \
             patch("app.services.history_qa_service.embedding_service.generate_embeddings",
                   new=AsyncMock(return_value=[[0.1] * 4])), \
             patch("app.services.history_qa_service.es_client.get_async_client",
                   new=AsyncMock(return_value=client)):
            return await runtime.run_agent_generation(
                chat_id="c1", user_id="u1", question="当前问题",
                history=[
                    {"role": "user", "content": "早期问题"},
                    {"role": "assistant", "content": "早期答案"},
                    {"role": "user", "content": "当前问题"},
                ],
                generation_id="g1", cancel_event=asyncio.Event(), emit=emit,
            )

    async def test_once_before_clarify_for_all_three_types(self):
        for agent_type in ("quick_qa", "reasoning_action", "planning_reasoning"):
            seen = {}

            async def runner(state, emit):
                seen["clarify_history"] = state.clarify_history
                await steps.emit_step(emit, "clarify", "start")
                await steps.emit_step(emit, "clarify", "end")
                return {"content": "答案", "meta": {}}

            emit = Collector()
            result = await self._run_entry(make_snapshot(agent_type=agent_type), emit, runner)
            self.assertNotIn("error", result, agent_type)
            hist_starts = [e for e in emit.events
                           if e.get("step") == "history_retrieve" and e["status"] == "start"]
            self.assertEqual(len(hist_starts), 1, agent_type)  # 每请求恰好一次
            clarify_idx = next(i for i, e in enumerate(emit.events) if e.get("step") == "clarify")
            hist_idx = next(i for i, e in enumerate(emit.events) if e.get("step") == "history_retrieve")
            self.assertLess(hist_idx, clarify_idx, agent_type)  # 先于澄清
            self.assertIsNotNone(seen["clarify_history"], agent_type)
            self.assertEqual(result["embedding_model_id"], "m2")  # 顶层键供写入触发，不进 meta
            self.assertNotIn("embedding_model_id", result["meta"])

    async def test_reasoning_loop_reuses_single_assembled_history(self):
        # 真实推理行动 flow（2 轮）：入口检索一次，循环后续重写复用同一份组装历史
        snapshot = make_snapshot(agent_type="reasoning_action", loop_count=2)
        call_json = seq_router({
            "clarify": [ClarifyResult(clear=True)],
            "rewrite": [RewriteResult(rewritten_question="问题一"), RewriteResult(rewritten_question="问题二")],
            "compress": [CompressResult(kept_indexes=[0])],
            "sufficiency": [
                SufficiencyResult(sufficient=False, new_question="补充新问题"),
                SufficiencyResult(sufficient=False, new_question="另一新问题"),
            ],
        })

        async def _assemble(state, emit):
            state.clarify_history = [
                {"role": "user", "content": "组装历史标记问题"},
                {"role": "assistant", "content": "组装历史标记答案"},
            ]

        hist_mock = AsyncMock(side_effect=_assemble)
        retrieve = AsyncMock(side_effect=[[make_chunk("a")], [make_chunk("b")]])
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=stream_mock([delta("答案")])), \
             patch.object(reasoning_action.retrieval_service, "retrieve", new=retrieve), \
             patch.object(reasoning_action.rerank_service, "rerank",
                          new=AsyncMock(side_effect=lambda q, h, m, **k: (h, False))), \
             patch("app.services.history_qa_service.retrieve_and_assemble", new=hist_mock):
            result = await self._run_entry(snapshot, Collector())
        self.assertEqual(result["content"], "答案")
        self.assertEqual(hist_mock.await_count, 1)  # 循环不重复检索
        rewrite_calls = [c for c in call_json.call_args_list if c.kwargs["purpose"] == "rewrite"]
        self.assertEqual(len(rewrite_calls), 2)
        for c in rewrite_calls:
            self.assertIn("组装历史标记问题", c.args[1][0]["content"])


class ClarifyHistoryRenderingTests(unittest.IsolatedAsyncioTestCase):
    """013 T005：替换范围（FR-009）——clarify/rewrite/工具重写用组装历史；answer/planning 不动."""

    def _state(self, snapshot=None):
        state = make_state(snapshot)
        state.history = [
            {"role": "user", "content": "最近历史问题"},
            {"role": "assistant", "content": "最近历史答案"},
        ]
        state.clarify_history = [
            {"role": "user", "content": "组装历史标记问题"},
            {"role": "assistant", "content": "组装历史标记答案"},
        ]
        return state

    async def test_clarify_renders_assembled_history(self):
        state = self._state()
        call_json = json_router({"clarify": ClarifyResult(clear=True)})
        with patch.object(llm_client, "call_json", new=call_json):
            await steps.run_clarify(state, Collector())
        content = call_json.call_args.args[1][0]["content"]
        self.assertIn("组装历史标记问题", content)
        self.assertNotIn("最近历史问题", content)

    async def test_rewrite_renders_assembled_history(self):
        state = self._state()
        call_json = json_router({"rewrite": RewriteResult(rewritten_question="q")})
        with patch.object(llm_client, "call_json", new=call_json):
            await steps.run_rewrite(state, Collector())
        content = call_json.call_args.args[1][0]["content"]
        self.assertIn("组装历史标记问题", content)
        self.assertNotIn("最近历史问题", content)

    async def test_none_falls_back_to_recent_history(self):
        state = self._state()
        state.clarify_history = None  # 降级/未组装 → 回退最近 10 轮
        call_json = json_router({"clarify": ClarifyResult(clear=True)})
        with patch.object(llm_client, "call_json", new=call_json):
            await steps.run_clarify(state, Collector())
        content = call_json.call_args.args[1][0]["content"]
        self.assertIn("最近历史问题", content)
        self.assertNotIn("组装历史标记问题", content)

    async def test_tool_rewrite_question_uses_assembled_history(self):
        from app.services.agent_runtime.tools import knowledge_tools
        state = self._state()
        call_json = json_router({"rewrite": RewriteResult(rewritten_question="q")})
        with patch.object(llm_client, "call_json", new=call_json):
            await knowledge_tools._rewrite_question(
                knowledge_tools.RewriteQuestionArgs(question="工具问题"), state)
        content = call_json.call_args.args[1][0]["content"]
        self.assertIn("组装历史标记问题", content)
        self.assertNotIn("最近历史问题", content)

    async def test_stream_answer_keeps_recent_history(self):
        state = self._state()
        stream = stream_mock([delta("答案")])
        with patch.object(llm_client, "stream_chat", new=stream):
            await steps.stream_answer(state, Collector())
        system = stream.call_args.args[1][0]["content"]
        self.assertIn("最近历史问题", system)
        self.assertNotIn("组装历史标记问题", system)

    async def test_planning_init_messages_keeps_recent_history(self):
        state = self._state(make_planning_snapshot())
        planning_reasoning._init_messages(state)
        system = state.messages_for_model[0]["content"]
        self.assertIn("最近历史问题", system)
        self.assertNotIn("组装历史标记问题", system)


class ClarifyHistoryBudgetTests(unittest.TestCase):
    """013 T005：组装历史参与 enforce_budget（FR-011，R11）——头部逐条裁剪、保底尾部最后触及."""

    def test_enforce_budget_trims_clarify_history_head_first(self):
        state = make_state(make_snapshot(context_tokens=120))
        state.snapshot.max_output_tokens = 10  # budget = 110
        state.history = []
        state.clarify_history = [
            {"role": "user", "content": "早期问题"},
            {"role": "assistant", "content": "长答案" * 50},
            {"role": "user", "content": "保底问题"},
            {"role": "assistant", "content": "保底答案"},
        ]
        state.merge_chunks([make_chunk("r1", content="片段")])
        report = budget.enforce_budget(state, ["固定开销"])
        self.assertEqual(report["dropped_clarify_history"], 2)  # 头部早期轮被淘汰
        self.assertEqual([m["content"] for m in state.clarify_history], ["保底问题", "保底答案"])

    def test_no_clarify_history_reports_zero(self):
        state = make_state()
        report = budget.enforce_budget(state, ["固定开销"])
        self.assertEqual(report["dropped_clarify_history"], 0)


class HistoryDegradeFlowTests(unittest.IsolatedAsyncioTestCase):
    """013 T021：历史检索降级时三类问答仍完整走通，clarify 回退最近历史（FR-010，SC-002/005）."""

    def setUp(self):
        self.db = MagicMock()
        self.chat = SimpleNamespace(agent_id="a1", knowledge_base_ids=["kb1"])
        self.db.query.return_value.filter.return_value.first.return_value = self.chat
        db_patcher = patch("app.core.database.SessionLocal", return_value=self.db)
        db_patcher.start(); self.addCleanup(db_patcher.stop)

    async def _run_entry(self, snapshot, emit, runner):
        runtime.register_flow(snapshot.agent_type, runner)
        self.addCleanup(runtime._FLOW_RUNNERS.pop, snapshot.agent_type, None)
        # embedding 失败 → 降级（不上抛），流程继续
        with patch("app.services.agent_runtime.snapshot.build_snapshot", return_value=snapshot), \
             patch("app.services.history_qa_service.embedding_service.generate_embeddings",
                   new=AsyncMock(side_effect=RuntimeError("embedding down"))):
            return await runtime.run_agent_generation(
                chat_id="c1", user_id="u1", question="当前问题",
                history=[
                    {"role": "user", "content": "最近历史问题"},
                    {"role": "assistant", "content": "最近历史答案"},
                    {"role": "user", "content": "当前问题"},
                ],
                generation_id="g1", cancel_event=asyncio.Event(), emit=emit,
            )

    async def test_degraded_flow_completes_with_fallback_history_for_all_types(self):
        for agent_type in ("quick_qa", "reasoning_action", "planning_reasoning"):
            seen = {}
            call_json = json_router({"clarify": ClarifyResult(clear=True)})

            async def runner(state, emit):
                seen["clarify_history"] = state.clarify_history
                await steps.run_clarify(state, emit)
                return {"content": "答案", "meta": {}}

            emit = Collector()
            with patch.object(llm_client, "call_json", new=call_json):
                result = await self._run_entry(make_snapshot(agent_type=agent_type), emit, runner)
            self.assertNotIn("error", result, agent_type)  # 降级不阻断主流程
            self.assertEqual(result["content"], "答案", agent_type)
            self.assertIsNone(seen["clarify_history"], agent_type)
            content = call_json.call_args.args[1][0]["content"]
            self.assertIn("最近历史问题", content, agent_type)  # clarify 回退最近历史
            end_events = [e for e in emit.events
                          if e.get("step") == "history_retrieve" and e["status"] == "end"]
            self.assertEqual(end_events[0].get("message"), "历史检索降级，使用最近历史", agent_type)

    async def test_cancelled_and_error_results_carry_no_embedding_model_id(self):
        # SC-005：cancelled/error 终态不触发写入——入口返回值不携带 embedding_model_id
        async def cancel_runner(state, emit):
            raise AgentCancelled()

        result = await self._run_entry(make_snapshot(), Collector(), cancel_runner)
        self.assertTrue(result["cancelled"])
        self.assertFalse(result.get("embedding_model_id"))

        async def error_runner(state, emit):
            raise RetrievalUnavailableError("es down")

        result = await self._run_entry(make_snapshot(), Collector(), error_runner)
        self.assertEqual(result["error"]["code"], "retrieval_unavailable")
        self.assertFalse(result.get("embedding_model_id"))


class PlanTextNotToolCallTests(unittest.IsolatedAsyncioTestCase):
    """013 T024：计划文本未走 tool_calls → plan_text_not_tool_call 警告（FR-015/016/017，R15）."""

    def setUp(self):
        self.span = MagicMock()
        tracer = MagicMock()
        tracer.start_span.return_value = self.span
        p = patch.object(tracing, "get_tracer", return_value=tracer)
        p.start(); self.addCleanup(p.stop)

    def _plan_events(self):
        return [c for c in self.span.add_event.call_args_list
                if c.args[0] == tracing.EVENT_PLAN_TEXT_NOT_TOOL_CALL]

    async def _run(self, decisions):
        state = make_state(make_planning_snapshot())
        patches = [
            patch.object(llm_client, "call_json", new=json_router({"clarify": ClarifyResult(clear=True)})),
            patch.object(llm_client, "chat_completion", new=AsyncMock(side_effect=list(decisions))),
            patch.object(llm_client, "stream_chat", new=stream_mock([delta("答案")])),
        ]
        with patches[0], patches[1], patches[2]:
            result = await planning_reasoning.run_planning_reasoning(state, Collector())
        return state, result, patches[1].new

    async def test_xml_plan_text_records_event_and_still_converges(self):
        # 014 §3.1 示例一形态：XML 开标签计划写在 content（无 tool_calls）
        content = "我先制定一个简短计划，然后检索相关信息。\n\n<createPlan>\n步骤一：检索记录\n步骤二：汇总结果"
        state, result, completion = await self._run([finish_resp(content)])
        events = self._plan_events()
        self.assertEqual(len(events), 1)
        attrs = events[0].kwargs["attributes"]
        self.assertEqual(attrs["loop"], "1")
        self.assertEqual(attrs["content_excerpt"], content[:500])
        self.assertIn(
            {"event": tracing.EVENT_PLAN_TEXT_NOT_TOOL_CALL, "loop": 1, "content_excerpt": content[:500]},
            result["meta"]["events"],
        )
        # 收敛判定不变：不解析不重试，仍进答案生成（无资料分支）
        self.assertEqual(completion.await_count, 1)
        self.assertEqual(result["content"], planning_reasoning.NO_MATERIAL_TEXT)
        self.assertEqual(result["meta"]["terminate_reason"], "empty_retrieval")

    async def test_tool_call_wrapped_json_form_records_event(self):
        # 014 §3.1 示例二形态：tool_call 开标签后跟 createPlan 的包裹 JSON（闭合标记拼接构造）
        body = json.dumps({"steps": ["明确查询实体与属性", "使用混合检索查找相关记录"]}, ensure_ascii=False)
        content = "\n\n<tool_call>createPlan\n" + body + "\n<" + "/tool_call>"
        _, result, _ = await self._run([finish_resp(content)])
        self.assertEqual(len(self._plan_events()), 1)
        self.assertIn(
            {"event": tracing.EVENT_PLAN_TEXT_NOT_TOOL_CALL, "loop": 1, "content_excerpt": content[:500]},
            result["meta"]["events"],
        )

    async def test_excerpt_truncated_to_first_500_chars(self):
        content = "<createPlan>" + "长" * 600
        await self._run([finish_resp(content)])
        attrs = self._plan_events()[0].kwargs["attributes"]
        self.assertEqual(len(attrs["content_excerpt"]), 500)
        self.assertEqual(attrs["content_excerpt"], content[:500])

    async def test_normal_tool_calls_produce_no_event(self):
        decisions = [tool_resp([("c1", "listPlan", {})]), finish_resp()]
        _, result, _ = await self._run(decisions)
        self.assertEqual(self._plan_events(), [])
        self.assertEqual(result["content"], "答案")

    async def test_plain_text_without_plan_markers_produces_no_event(self):
        _, result, _ = await self._run([finish_resp()])
        self.assertEqual(self._plan_events(), [])
        self.assertNotIn("events", result["meta"])

    def test_protocol_enforces_function_calling_and_forbids_content_markers(self):
        proto = planning_reasoning.PLANNING_PROTOCOL
        self.assertIn("function calling", proto)
        self.assertIn("tool_calls", proto)
        self.assertIn("严禁", proto)
        self.assertIn("<createPlan>", proto)
        self.assertIn("<updatePlan>", proto)
        self.assertIn("<tool_call>", proto)
        self.assertIn("createPlan 制定计划", proto)  # 既有文案保留
        self.assertIn("不要提前给出最终答案", proto)  # 收敛说明禁止预答


class TraceEnhancementTests(unittest.IsolatedAsyncioTestCase):
    """013 T026：prompt 溯源属性 + 检索片段全文不截断（FR-001/002，R13/R14）."""

    def setUp(self):
        self.spans = {}
        tracer = MagicMock()
        tracer.start_span.side_effect = lambda name: self.spans.setdefault(name, MagicMock())
        p = patch.object(tracing, "get_tracer", return_value=tracer)
        p.start(); self.addCleanup(p.stop)

    def _attrs(self, span_name):
        return dict(c.args for c in self.spans[span_name].set_attribute.call_args_list)

    async def test_step_spans_carry_prompt_attrs_from_snapshot(self):
        state = make_state()
        call_json = json_router({
            "clarify": ClarifyResult(clear=True),
            "rewrite": RewriteResult(rewritten_question="q"),
            "sufficiency": SufficiencyResult(sufficient=True),
            "compress": CompressResult(kept_indexes=[0]),
        })
        with patch.object(llm_client, "call_json", new=call_json), \
             patch.object(llm_client, "stream_chat", new=stream_mock([delta("答案")])):
            await steps.run_clarify(state, Collector())
            await steps.run_rewrite(state, Collector())
            await steps.run_sufficiency(state, Collector())
            await steps.run_compress(state, [make_chunk("r1")], Collector())
            state.merge_chunks([make_chunk("r1")])
            await steps.stream_answer(state, Collector())
        for step in ("clarify", "rewrite", "sufficiency", "compress", "answer"):
            attrs = self._attrs(f"agent.{step}")
            self.assertEqual(attrs[tracing.ATTR_PROMPT_NAME], step, step)  # 快照 name
            self.assertEqual(attrs[tracing.ATTR_PROMPT_VERSION], "v1", step)
            self.assertEqual(attrs[tracing.ATTR_PROMPT_PURPOSE], step, step)

    async def test_plan_decision_span_carry_planning_prompt_attrs(self):
        state = make_state(make_planning_snapshot())
        with patch.object(llm_client, "call_json", new=json_router({"clarify": ClarifyResult(clear=True)})), \
             patch.object(llm_client, "chat_completion", new=AsyncMock(side_effect=[finish_resp()])), \
             patch.object(llm_client, "stream_chat", new=stream_mock([delta("答案")])):
            await planning_reasoning.run_planning_reasoning(state, Collector())
        attrs = self._attrs("agent.plan_decision")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_NAME], "planning")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_VERSION], "v1")
        self.assertEqual(attrs[tracing.ATTR_PROMPT_PURPOSE], "planning")

    async def test_retrieve_nodes_write_full_chunks_and_keep_output(self):
        for mod in (quick_qa, reasoning_action):
            self.spans.clear()
            state = make_state()
            hits = [make_chunk("r1"), make_chunk("r2")]
            hits[0].score = 0.5
            with patch.object(mod.retrieval_service, "retrieve", new=AsyncMock(return_value=hits)):
                await mod._retrieve_node({"rt": state, "emit": Collector()})
            attrs = self._attrs("agent.retrieve.hybrid")
            chunks = json.loads(attrs[tracing.ATTR_RETRIEVAL_CHUNKS])
            self.assertEqual([c["chunk_id"] for c in chunks], ["r1", "r2"])
            self.assertEqual(chunks[0]["score"], 0.5)
            self.assertEqual(chunks[0]["file_name"], "r1.pdf")
            self.assertEqual(chunks[0]["content"], "正文")
            output = json.loads(attrs[tracing.ATTR_OUTPUT])
            self.assertEqual(output["count"], 2)  # 既有摘要保留
            self.assertEqual(output["chunk_ids"], ["r1", "r2"])

    async def test_large_chunk_content_not_truncated(self):
        state = make_state()
        big = "字" * 20000  # UTF-8 约 60KB，超 32KB 截断阈值
        with patch.object(quick_qa.retrieval_service, "retrieve",
                          new=AsyncMock(return_value=[make_chunk("big", content=big)])):
            await quick_qa._retrieve_node({"rt": state, "emit": Collector()})
        raw = self._attrs("agent.retrieve.hybrid")[tracing.ATTR_RETRIEVAL_CHUNKS]
        self.assertNotIn("…[截断]", raw)
        self.assertEqual(json.loads(raw)[0]["content"], big)

    async def test_empty_hits_write_empty_array(self):
        state = make_state()
        with patch.object(quick_qa.retrieval_service, "retrieve", new=AsyncMock(return_value=[])):
            await quick_qa._retrieve_node({"rt": state, "emit": Collector()})
        self.assertEqual(self._attrs("agent.retrieve.hybrid")[tracing.ATTR_RETRIEVAL_CHUNKS], "[]")


if __name__ == "__main__":
    unittest.main()