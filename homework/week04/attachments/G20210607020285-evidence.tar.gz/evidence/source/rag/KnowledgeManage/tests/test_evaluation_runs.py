"""014-knowledge-evaluation US2：发起评测与执行控制（T018，FR-010~020）。

模式沿用 tests/test_agents.py：MagicMock db + patch decode_token + TestClient；
执行器用例直接 await _execute_run，patch SessionLocal/run_evaluation_question/评分协程。
"""
import asyncio
import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.database import get_db
from app.models.agent import Agent
from app.models.chat import Chat
from app.models.evaluation_item import EvaluationItem
from app.models.evaluation_run import EvaluationRun
from app.models.evaluation_setting import EvaluationSetting
from app.models.evaluation_test_set import EvaluationTestSet
from app.models.knowledge_base import KnowledgeBase
from app.models.message import Message
from app.models.prompt import Prompt
from app.routers import evaluations as evaluations_router
from app.schemas.evaluation import RunCreate
from app.services import evaluation_runner, evaluation_service
from app.services.evaluation_service import (
    EvaluationLockedError,
    EvaluationPrecheckError,
)


def user_claims(sub="u-1"):
    return {"type": "access", "sub": sub, "uid": "user", "permissions": []}


def make_run(**overrides):
    base = dict(
        id="run-1", user_id="u-1",
        knowledge_base_ids=["kb-1"], knowledge_base_names=["库A"],
        agent_id="agent-1", agent_name="快速问答",
        test_set_id="ts-1", test_set_name="回归集A",
        status="running", total_items=3, completed_items=0,
        cancel_requested=False, error_message=None, finished_at=None,
    )
    base.update(overrides)
    return EvaluationRun(**base)


def make_items(n=3, run_id="run-1"):
    return [
        EvaluationItem(
            id=f"item-{i}", run_id=run_id, seq=i,
            question=f"问题{i}", standard_answer=f"标准答案{i}", status="pending",
        )
        for i in range(1, n + 1)
    ]


def mock_executor_db(run, items):
    """执行器专用 mock db：按 model 分发真实模型实例（可原地断言字段）."""
    db = MagicMock()

    def query(model):
        q = MagicMock()
        if model is EvaluationRun:
            q.filter.return_value.first.return_value = run
        elif model is EvaluationItem:
            q.filter.return_value.order_by.return_value.all.return_value = items
            q.filter.return_value.all.return_value = items
        elif model is EvaluationSetting:
            q.filter.return_value.first.return_value = SimpleNamespace(
                analysis_model_id="m-1", recall_prompt_id="p-1", accuracy_prompt_id="p-2",
            )
        elif model is Prompt:
            q.filter.return_value.first.return_value = SimpleNamespace(
                id="p-1", name="评分提示词", version="v1",
                content="Q:{question}\nC:{context}\nS:{standard_answer}\nA:{agent_answer}",
            )
        return q

    db.query.side_effect = query
    return db


def success_answer(**overrides):
    base = dict(
        content="agent 答案",
        meta={"references": [
            {"file_name": "手册.pdf", "content": "片段内容", "score": 0.87,
             "chunk_id": "c1", "document_id": "d1", "kb_id": "kb-1"},
        ]},
        trace_id="a" * 32, cancelled=False,
    )
    base.update(overrides)
    return base


async def fake_question_success(**kwargs):
    """模拟无会话入口：在根 span 内调用 score_hook（与真实入口契约一致）."""
    result = success_answer()
    hook = kwargs.get("score_hook")
    if hook is not None:
        result.update(await hook(result))
    return result


def score_ok(score):
    return {"score": score, "analysis": {"ok": True}, "raw_output": None, "failure_reason": None}


class RunRouterTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(evaluations_router.router)
        self.db = MagicMock()
        app.dependency_overrides[get_db] = lambda: self.db
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=user_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)
        self.body = {"knowledge_base_ids": ["kb-1"], "agent_id": "agent-1", "test_set_id": "ts-1"}

    def test_create_run_returns_201_immediately(self):
        run = make_run()
        with patch.object(evaluation_service, "create_run", return_value=run) as mock_create:
            res = self.client.post("/evaluations/runs", json=self.body, headers=self.headers)
        self.assertEqual(res.status_code, 201)
        self.assertEqual(res.json(), {"id": "run-1", "status": "running", "total_items": 3})
        self.assertEqual(mock_create.call_args[0][1], "u-1")

    def test_create_run_precheck_400_lists_all_reasons(self):
        with patch.object(evaluation_service, "create_run", side_effect=EvaluationPrecheckError(
            ["分析模型不存在或已删除（m-1）", "智能体「快速问答」已停用"],
        )):
            res = self.client.post("/evaluations/runs", json=self.body, headers=self.headers)
        self.assertEqual(res.status_code, 400)
        self.assertIn("分析模型不存在", res.json()["detail"])
        self.assertIn("已停用", res.json()["detail"])

    def test_create_run_empty_kb_ids_400(self):
        with patch.object(evaluation_service, "create_run", side_effect=EvaluationPrecheckError(["未选择知识库"])):
            res = self.client.post("/evaluations/runs", json={
                "knowledge_base_ids": [], "agent_id": "agent-1", "test_set_id": "ts-1",
            }, headers=self.headers)
        self.assertEqual(res.status_code, 400)
        self.assertIn("知识库", res.json()["detail"])

    def test_create_run_concurrent_409(self):
        with patch.object(evaluation_service, "create_run", side_effect=EvaluationLockedError("已有进行中的评测任务")):
            res = self.client.post("/evaluations/runs", json=self.body, headers=self.headers)
        self.assertEqual(res.status_code, 409)

    def test_cancel_run_success(self):
        run = make_run(cancel_requested=True)
        with patch.object(evaluation_service, "cancel_run", return_value=run) as mock_cancel:
            res = self.client.post("/evaluations/runs/run-1/cancel", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json(), {"id": "run-1", "status": "running", "cancel_requested": True})
        self.assertEqual(mock_cancel.call_args[0][1], "u-1")

    def test_cancel_run_not_found_404(self):
        with patch.object(evaluation_service, "cancel_run", return_value=None):
            res = self.client.post("/evaluations/runs/missing/cancel", headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_cancel_run_terminal_409(self):
        with patch.object(evaluation_service, "cancel_run", side_effect=EvaluationLockedError("任务已结束，无法取消")):
            res = self.client.post("/evaluations/runs/run-1/cancel", headers=self.headers)
        self.assertEqual(res.status_code, 409)

    def test_events_not_found_404(self):
        with patch.object(evaluation_service, "get_run", return_value=None):
            res = self.client.get("/evaluations/runs/missing/events", headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_events_streams_sse(self):
        async def fake_stream(run_id):
            yield 'data: {"type": "snapshot", "run_id": "run-1", "status": "running", "completed": 0, "total": 3}\n\n'
            yield 'data: {"type": "done", "run_id": "run-1", "status": "completed", "completed": 3, "total": 3}\n\n'

        with patch.object(evaluation_service, "get_run", return_value=make_run()):
            with patch.object(evaluation_runner, "event_stream", side_effect=fake_stream):
                res = self.client.get("/evaluations/runs/run-1/events", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertIn("text/event-stream", res.headers["content-type"])
        self.assertIn('"type": "snapshot"', res.text)
        self.assertIn('"type": "done"', res.text)


class RunServiceTests(unittest.TestCase):
    """create_run 预检/快照/预建明细；cancel_run；recover；delete_run."""

    def setUp(self):
        self.db = MagicMock()
        self.setting = SimpleNamespace(
            analysis_model_id="m-1", recall_prompt_id="p-1", accuracy_prompt_id="p-2",
        )
        self.prompt = SimpleNamespace(id="p-1", name="评分提示词", version="v1", content="x", creator_id="u-1")
        self.agent = SimpleNamespace(id="agent-1", name="快速问答", status="enabled")
        self.kb = SimpleNamespace(id="kb-1", name="库A", user_id="u-1")
        self.test_set = SimpleNamespace(
            id="ts-1", name="回归集A", user_id="u-1",
            items=[{"question": "问1", "answer": "答1"}, {"question": "问2", "answer": "答2"}],
            item_count=2,
        )
        self.running_run = None
        self._query()
        self.resolve = patch(
            "app.services.evaluation_service.llm_client.resolve_model",
            return_value={"name": "gpt", "context_tokens": 8000, "category": "chat"},
        )
        self.resolve.start()
        self.addCleanup(self.resolve.stop)
        self.start = patch.object(evaluation_runner, "start_run")
        self.start_mock = self.start.start()
        self.addCleanup(self.start.stop)

    def _query(self):
        def query(model):
            q = MagicMock()
            if model is EvaluationSetting:
                q.filter.return_value.first.return_value = self.setting
            elif model is Prompt:
                q.filter.return_value.first.return_value = self.prompt
            elif model is Agent:
                q.filter.return_value.first.return_value = self.agent
            elif model is KnowledgeBase:
                q.filter.return_value.first.return_value = self.kb
            elif model is EvaluationTestSet:
                q.filter.return_value.first.return_value = self.test_set
            elif model is EvaluationRun:
                q.filter.return_value.first.return_value = self.running_run
            return q
        self.db.query.side_effect = query

    def _create(self, kb_ids=None):
        return evaluation_service.create_run(self.db, "u-1", RunCreate(
            knowledge_base_ids=kb_ids if kb_ids is not None else ["kb-1"],
            agent_id="agent-1", test_set_id="ts-1",
        ))

    def test_precheck_aggregates_all_failures(self):
        self.setting = None
        self.agent = SimpleNamespace(id="agent-1", name="快速问答", status="disabled")
        self.kb = None
        self.test_set = None
        self._query()
        with self.assertRaises(EvaluationPrecheckError) as ctx:
            self._create()
        message = str(ctx.exception)
        self.assertIn("分析模型", message)
        self.assertIn("召回率提示词", message)
        self.assertIn("准确度提示词", message)
        self.assertIn("已停用", message)
        self.assertIn("知识库不存在", message)
        self.assertIn("测试集不存在", message)
        self.db.add.assert_not_called()
        self.start_mock.assert_not_called()

    def test_precheck_model_missing_and_not_chat(self):
        with patch("app.services.evaluation_service.llm_client.resolve_model", return_value=None):
            with self.assertRaises(EvaluationPrecheckError) as ctx:
                self._create()
        self.assertIn("分析模型不存在", str(ctx.exception))
        with patch("app.services.evaluation_service.llm_client.resolve_model",
                   return_value={"name": "emb", "context_tokens": 8000, "category": "embedding"}):
            with self.assertRaises(EvaluationPrecheckError) as ctx:
                self._create()
        self.assertIn("对话模型", str(ctx.exception))

    def test_precheck_prompt_not_owned(self):
        self.prompt = SimpleNamespace(id="p-1", name="他人提示词", version="v1", content="x", creator_id="u-2")
        self._query()
        with self.assertRaises(EvaluationPrecheckError) as ctx:
            self._create()
        self.assertIn("非本人", str(ctx.exception))

    def test_precheck_empty_kb_ids(self):
        with self.assertRaises(EvaluationPrecheckError) as ctx:
            self._create(kb_ids=[])
        self.assertIn("未选择知识库", str(ctx.exception))

    def test_concurrent_running_409(self):
        self.running_run = make_run()
        self._query()
        with self.assertRaises(EvaluationLockedError):
            self._create()
        self.db.add.assert_not_called()

    def test_create_run_snapshots_and_pending_items(self):
        run = self._create()
        self.assertEqual(run.status, "running")
        self.assertEqual(run.knowledge_base_names, ["库A"])
        self.assertEqual(run.agent_name, "快速问答")
        self.assertEqual(run.test_set_name, "回归集A")
        self.assertEqual(run.total_items, 2)
        added = [c.args[0] for c in self.db.add.call_args_list]
        items = [a for a in added if isinstance(a, EvaluationItem)]
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0].seq, 1)
        self.assertEqual(items[0].question, "问1")
        self.assertEqual(items[0].standard_answer, "答1")
        self.assertEqual(items[0].status, "pending")
        self.db.commit.assert_called()
        self.start_mock.assert_called_once_with(run.id)

    def test_cancel_run_sets_flag_and_event(self):
        run = make_run()
        self.running_run = run
        self._query()
        with patch.object(evaluation_runner, "request_cancel") as mock_request:
            result = evaluation_service.cancel_run(self.db, "u-1", "run-1")
        self.assertIs(result, run)
        self.assertTrue(run.cancel_requested)
        self.db.commit.assert_called_once()
        mock_request.assert_called_once_with("run-1")

    def test_cancel_run_terminal_raises(self):
        self.running_run = make_run(status="completed")
        self._query()
        with self.assertRaises(EvaluationLockedError):
            evaluation_service.cancel_run(self.db, "u-1", "run-1")

    def test_cancel_run_missing_returns_none(self):
        self.assertIsNone(evaluation_service.cancel_run(self.db, "u-1", "missing"))

    def test_recover_interrupted_runs_marks_failed(self):
        db = MagicMock()
        with patch("app.services.evaluation_service.SessionLocal", return_value=db):
            evaluation_service.recover_interrupted_runs()
        update_args = db.query.return_value.filter.return_value.update.call_args
        values = update_args.args[0]
        self.assertEqual(values["status"], "failed")
        self.assertEqual(values["error_message"], "服务重启中断")
        self.assertIsNotNone(values["finished_at"])
        db.commit.assert_called_once()
        db.close.assert_called_once()

    def test_delete_run_running_raises(self):
        self.running_run = make_run()
        self._query()
        with self.assertRaises(EvaluationLockedError):
            evaluation_service.delete_run(self.db, "u-1", "run-1")
        self.db.delete.assert_not_called()

    def test_delete_run_missing_returns_none(self):
        self.assertIsNone(evaluation_service.delete_run(self.db, "u-1", "missing"))

    def test_delete_run_cascades(self):
        run = make_run(status="completed")
        self.running_run = run
        self._query()
        self.assertTrue(evaluation_service.delete_run(self.db, "u-1", "run-1"))
        self.db.delete.assert_called_once_with(run)
        self.db.commit.assert_called_once()


class RunExecutorTests(unittest.IsolatedAsyncioTestCase):
    """执行器：逐题落库/事件/取消/全失败仍 completed/任务级异常 failed/FR-020."""

    def setUp(self):
        self.run = make_run()
        self.items = make_items(3)
        self.db = mock_executor_db(self.run, self.items)
        patches = [
            patch.object(evaluation_runner, "SessionLocal", return_value=self.db),
            patch.object(evaluation_runner.llm_client, "resolve_model",
                         return_value={"name": "gpt", "context_tokens": 8000, "category": "chat"}),
            patch.object(evaluation_runner, "score_recall", AsyncMock(return_value=score_ok(0.8))),
            patch.object(evaluation_runner, "score_accuracy", AsyncMock(return_value=score_ok(90.0))),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        self.question = patch.object(
            evaluation_runner, "run_evaluation_question", side_effect=fake_question_success,
        )
        self.question_mock = self.question.start()
        self.addCleanup(self.question.stop)
        self.queue = evaluation_runner.subscribe("run-1")
        self.addCleanup(evaluation_runner.unsubscribe, "run-1", self.queue)

    def _drain_events(self):
        events = []
        while not self.queue.empty():
            events.append(self.queue.get_nowait())
        return events

    async def test_success_flow_persists_and_publishes(self):
        await evaluation_runner._execute_run("run-1")
        self.assertEqual(self.run.status, "completed")
        self.assertEqual(self.run.completed_items, 3)
        self.assertIsNotNone(self.run.finished_at)
        for item in self.items:
            self.assertEqual(item.status, "success")
            self.assertEqual(item.agent_answer, "agent 答案")
            self.assertEqual(item.recall, 0.8)
            self.assertEqual(item.accuracy, 90.0)
            self.assertEqual(item.context[0]["file_name"], "手册.pdf")
            self.assertEqual(item.trace_id, "a" * 32)
            self.assertIsNotNone(item.completed_at)
        events = self._drain_events()
        progress = [e for e in events if e["type"] == "progress"]
        self.assertEqual(len(progress), 3)
        self.assertEqual(progress[-1]["completed"], 3)
        self.assertEqual(progress[-1]["last_item"]["seq"], 3)
        done = events[-1]
        self.assertEqual(done["type"], "done")
        self.assertEqual(done["status"], "completed")
        self.assertAlmostEqual(done["avg_recall"], 0.8)
        self.assertAlmostEqual(done["avg_accuracy"], 90.0)
        self.assertIsNone(done["error_message"])

    async def test_cancel_between_items_keeps_finished(self):
        async def cancel_after_first(**kwargs):
            result = await fake_question_success(**kwargs)
            self.run.cancel_requested = True  # 当前题（含评分）完成后命中题间标记
            return result

        self.question_mock.side_effect = cancel_after_first
        await evaluation_runner._execute_run("run-1")
        self.assertEqual(self.run.status, "cancelled")
        self.assertEqual(self.run.completed_items, 1)
        self.assertEqual(self.items[0].status, "success")
        self.assertEqual(self.items[1].status, "pending")
        self.assertEqual(self.items[2].status, "pending")
        done = self._drain_events()[-1]
        self.assertEqual(done["status"], "cancelled")
        self.assertEqual(done["completed"], 1)

    async def test_all_items_failed_still_completed(self):
        async def always_error(**kwargs):
            return {"content": "", "meta": {}, "trace_id": "b" * 32, "cancelled": False,
                    "error": {"code": "model_unavailable", "message": "模型服务不可用"}}

        self.question_mock.side_effect = always_error
        await evaluation_runner._execute_run("run-1")
        self.assertEqual(self.run.status, "completed")
        for item in self.items:
            self.assertEqual(item.status, "failed")
            self.assertIn("模型服务不可用", item.failure_reason)
            self.assertIsNone(item.recall)
            self.assertIsNone(item.accuracy)
        done = self._drain_events()[-1]
        self.assertEqual(done["status"], "completed")
        self.assertIsNone(done["avg_recall"])
        self.assertIsNone(done["avg_accuracy"])

    async def test_fr020_question_entry_called_per_item(self):
        # 每题独立调用无会话入口（入口内部每题重建 build_snapshot，决策24 实时生效）
        await evaluation_runner._execute_run("run-1")
        self.assertEqual(self.question_mock.call_count, 3)
        seqs = [c.kwargs["seq"] for c in self.question_mock.call_args_list]
        self.assertEqual(seqs, [1, 2, 3])

    async def test_task_level_exception_marks_failed(self):
        self.db.commit.side_effect = RuntimeError("db down")
        await evaluation_runner._execute_run("run-1")
        self.assertEqual(self.run.status, "failed")
        self.assertIn("db down", self.run.error_message)
        done = self._drain_events()[-1]
        self.assertEqual(done["type"], "done")
        self.assertEqual(done["status"], "failed")


class QuestionEntryTests(unittest.IsolatedAsyncioTestCase):
    """无会话入口（T021）：每题重建快照、不创建 Chat/Message、history 为空."""

    async def test_rebuilds_snapshot_each_call_and_no_chat(self):
        from app.services.agent_runtime import evaluation as entry

        db = MagicMock()
        snapshot = SimpleNamespace(agent_id="agent-1", agent_type="quick_qa")
        captured = []

        async def fake_runner(state, emit):
            captured.append(state)
            return {"content": "答案", "meta": {"references": []}}

        with patch.object(entry, "SessionLocal", return_value=db), \
                patch.object(entry, "build_snapshot", return_value=snapshot) as mock_build, \
                patch.object(entry, "_get_runner", return_value=fake_runner):
            for _ in range(2):
                result = await entry.run_evaluation_question(
                    agent_id="agent-1", kb_ids=["kb-1"], user_id="u-1",
                    question="问题", cancel_event=asyncio.Event(),
                    emit=AsyncMock(), run_id="run-1", seq=1,
                )
        self.assertEqual(mock_build.call_count, 2)
        self.assertEqual(result["content"], "答案")
        self.assertEqual(captured[0].history, [])
        self.assertEqual(captured[0].chat_id, "")
        for call in db.query.call_args_list:
            self.assertNotIn(call.args[0], (Chat, Message))


class RunResultRouterTests(unittest.TestCase):
    """US3（T029）：列表/详情/删除路由，契约 §3。"""

    def setUp(self):
        app = FastAPI()
        app.include_router(evaluations_router.router)
        self.db = MagicMock()
        app.dependency_overrides[get_db] = lambda: self.db
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=user_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)

    def test_list_runs_pagination_and_fields(self):
        row = {
            "id": "run-1", "started_at": "2026-11-24T00:00:00",
            "knowledge_base_names": ["库A"], "agent_name": "快速问答",
            "test_set_name": "回归集A", "avg_recall": 0.8, "avg_accuracy": 92.5,
            "status": "completed", "total_items": 10, "completed_items": 10,
        }
        with patch.object(evaluation_service, "list_runs", return_value=([row], 3)) as mock_list:
            res = self.client.get("/evaluations/runs?page=2&page_size=5", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertEqual(body["total"], 3)
        self.assertEqual(body["page"], 2)
        self.assertEqual(body["page_size"], 5)
        self.assertEqual(body["items"][0]["avg_recall"], 0.8)
        self.assertEqual(mock_list.call_args.args[1:], ("u-1", 2, 5))

    def test_get_run_detail_ok(self):
        detail = {"id": "run-1", "status": "completed", "items": []}
        with patch.object(evaluation_service, "get_run_detail", return_value=detail) as mock_detail:
            res = self.client.get("/evaluations/runs/run-1", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["id"], "run-1")
        self.assertEqual(mock_detail.call_args.args[1:], ("u-1", "run-1"))

    def test_get_run_detail_not_found_404(self):
        with patch.object(evaluation_service, "get_run_detail", return_value=None):
            res = self.client.get("/evaluations/runs/missing", headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_delete_run_204(self):
        with patch.object(evaluation_service, "delete_run", return_value=True) as mock_delete:
            res = self.client.delete("/evaluations/runs/run-1", headers=self.headers)
        self.assertEqual(res.status_code, 204)
        self.assertEqual(mock_delete.call_args.args[1:], ("u-1", "run-1"))

    def test_delete_run_running_409(self):
        with patch.object(evaluation_service, "delete_run", side_effect=EvaluationLockedError("评测进行中，请先取消后再删除")):
            res = self.client.delete("/evaluations/runs/run-1", headers=self.headers)
        self.assertEqual(res.status_code, 409)
        self.assertIn("取消", res.json()["detail"])

    def test_delete_run_not_found_404(self):
        with patch.object(evaluation_service, "delete_run", return_value=None):
            res = self.client.delete("/evaluations/runs/missing", headers=self.headers)
        self.assertEqual(res.status_code, 404)


class RunResultServiceTests(unittest.TestCase):
    """US3（T029）：平均分仅 success 题口径/分页/详情全字段/快照展示（R13）。"""

    NOW = datetime(2026, 11, 24, tzinfo=timezone.utc)

    def setUp(self):
        self.db = MagicMock()
        self.runs = []
        self.rows = []  # (run_id, status, recall, accuracy) 投影行
        self.items = []
        self.total = 0
        self.run = None
        self._query()

    def _query(self):
        runs_q = MagicMock()
        ordered = MagicMock()
        runs_q.filter.return_value.order_by.return_value = ordered
        runs_q.filter.return_value.first.return_value = self.run
        ordered.count.return_value = self.total
        ordered.offset.return_value.limit.return_value.all.return_value = self.runs

        def query(*args):
            if args[0] is EvaluationRun:
                return runs_q
            if args[0] is EvaluationItem:
                q = MagicMock()
                q.filter.return_value.order_by.return_value.all.return_value = self.items
                return q
            # 列投影查询（run_id, status, recall, accuracy）
            q = MagicMock()
            q.filter.return_value.all.return_value = self.rows
            return q

        self.db.query.side_effect = query
        self.runs_q = runs_q
        self.ordered = ordered

    def _make_run(self, **overrides):
        base = dict(
            id="run-1", user_id="u-1",
            knowledge_base_ids=["kb-1"], knowledge_base_names=["库A"],
            agent_id="agent-1", agent_name="快速问答",
            test_set_id="ts-1", test_set_name="回归集A",
            status="completed", total_items=10, completed_items=10,
            cancel_requested=False, error_message=None,
            started_at=self.NOW, finished_at=self.NOW,
        )
        base.update(overrides)
        return EvaluationRun(**base)

    def test_list_runs_pagination_and_snapshot_fields(self):
        self.runs = [self._make_run(), self._make_run(id="run-2", status="cancelled", completed_items=4)]
        self.total = 7
        self._query()
        items, total = evaluation_service.list_runs(self.db, "u-1", page=2, page_size=5)
        self.assertEqual(total, 7)
        self.ordered.offset.assert_called_once_with(5)
        self.ordered.offset.return_value.limit.assert_called_once_with(5)
        self.assertEqual(len(items), 2)
        first = items[0]
        for field in ("id", "started_at", "knowledge_base_names", "agent_name",
                      "test_set_name", "avg_recall", "avg_accuracy", "status",
                      "total_items", "completed_items"):
            self.assertIn(field, first)
        self.assertEqual(first["knowledge_base_names"], ["库A"])
        self.assertEqual(items[1]["status"], "cancelled")

    def test_avg_counts_success_items_only(self):
        # 10 题 8 成功 2 失败：失败行即使带值也不计入（仅 status='success'）
        self.runs = [self._make_run()]
        self.total = 1
        self.rows = (
            [("run-1", "success", 1.0, 100.0)] * 8
            + [("run-1", "failed", 0.0, 0.0)] * 2
        )
        self._query()
        items, _ = evaluation_service.list_runs(self.db, "u-1")
        self.assertAlmostEqual(items[0]["avg_recall"], 1.0)
        self.assertAlmostEqual(items[0]["avg_accuracy"], 100.0)

    def test_cancelled_run_avg_shown_normally(self):
        self.runs = [self._make_run(status="cancelled", completed_items=2)]
        self.total = 1
        self.rows = [("run-1", "success", 0.5, 80.0), ("run-1", "success", 0.7, 90.0)]
        self._query()
        items, _ = evaluation_service.list_runs(self.db, "u-1")
        self.assertAlmostEqual(items[0]["avg_recall"], 0.6)
        self.assertAlmostEqual(items[0]["avg_accuracy"], 85.0)

    def test_no_success_items_returns_null(self):
        self.runs = [self._make_run()]
        self.total = 1
        self.rows = [("run-1", "failed", None, None)] * 10
        self._query()
        items, _ = evaluation_service.list_runs(self.db, "u-1")
        self.assertIsNone(items[0]["avg_recall"])
        self.assertIsNone(items[0]["avg_accuracy"])

    def test_detail_items_seq_order_and_full_fields(self):
        self.run = self._make_run()
        success = make_items(1)[0]
        success.status = "success"
        success.agent_answer = "agent 答案"
        success.context = [{"file_name": "手册.pdf", "content": "片段", "score": 0.87}]
        success.recall = 0.8
        success.accuracy = 90.0
        success.recall_analysis = {"key_points": [{"point": "p", "covered": True}], "recall": 0.8}
        success.accuracy_analysis = {"issues": []}
        success.trace_id = "a" * 32
        failed = make_items(2)[1]
        failed.status = "failed"
        failed.failure_reason = "召回率评分输出校验失败：x"
        failed.recall_raw_output = "最后一次原始输出"
        self.items = [success, failed]
        self._query()
        detail = evaluation_service.get_run_detail(self.db, "u-1", "run-1")
        self.assertEqual(detail["id"], "run-1")
        self.assertEqual(detail["knowledge_base_names"], ["库A"])
        self.assertAlmostEqual(detail["avg_recall"], 0.8)
        self.assertAlmostEqual(detail["avg_accuracy"], 90.0)
        self.assertEqual([i["seq"] for i in detail["items"]], [1, 2])
        first = detail["items"][0]
        for field in ("id", "seq", "question", "standard_answer", "status", "agent_answer",
                      "context", "recall", "accuracy", "recall_analysis", "accuracy_analysis",
                      "recall_raw_output", "accuracy_raw_output", "failure_reason", "trace_id"):
            self.assertIn(field, first)
        self.assertEqual(first["context"][0]["file_name"], "手册.pdf")
        second = detail["items"][1]
        self.assertEqual(second["failure_reason"], "召回率评分输出校验失败：x")
        self.assertEqual(second["recall_raw_output"], "最后一次原始输出")
        self.assertIsNone(second["recall"])

    def test_detail_uses_snapshots_without_asset_queries(self):
        # 测试集/知识库/智能体删除后快照照常：详情不查资产表
        self.run = self._make_run()
        self.items = make_items(1)
        self._query()
        detail = evaluation_service.get_run_detail(self.db, "u-1", "run-1")
        self.assertEqual(detail["test_set_name"], "回归集A")
        self.assertEqual(detail["agent_name"], "快速问答")
        for call in self.db.query.call_args_list:
            self.assertNotIn(call.args[0], (KnowledgeBase, Agent, EvaluationTestSet))

    def test_detail_missing_returns_none(self):
        self.run = None
        self._query()
        self.assertIsNone(evaluation_service.get_run_detail(self.db, "u-1", "missing"))


if __name__ == "__main__":
    unittest.main()