import asyncio
import io
import unittest
import zipfile
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from starlette.datastructures import UploadFile

from app.routers import chunks, documents
from app.models.archive_image import ArchiveImageReference
from app.services import document_service, document_status, image_service, markdown_attachments, parsing_service, storage_service


class MarkdownArchiveTests(unittest.TestCase):
    def test_zip_attachments_render_in_source_parsed_markdown_and_chunks(self):
        markdown = (
            "# Report\n"
            "![chart](images/chart.png)\n"
            "![chart again](./images/chart.png)\n"
            "![different chart](../shared/chart.png)\n"
            "![missing](images/missing.png)\n"
            "![remote](https://example.test/chart.png)\n"
        )
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w") as zf:
            zf.writestr("auto/report.md", markdown)
            zf.writestr("auto/images/chart.png", b"first image")
            zf.writestr("shared/chart.png", b"second image")
            zf.writestr("other/another.md", "![](../auto/images/chart.png)")
            zf.writestr("auto/images/standalone.png", b"independent image")
        archive.seek(0)
        objects = {}

        def upload(object_path, data, **kwargs):
            self.assertNotIn(object_path, objects)
            objects[object_path] = data if isinstance(data, bytes) else data.read()
            return object_path

        def sign(key, expires):
            return f"https://minio.test/{key}"

        with (
            patch.object(document_service, "_verify_folder_ownership", return_value=SimpleNamespace(kb_id="kb")),
            patch.object(document_service, "_ensure_folder_path", side_effect=lambda *args: args[-1]),
            patch.object(storage_service, "upload_file", side_effect=upload),
            patch.object(storage_service, "download_file", side_effect=objects.__getitem__),
            patch.object(storage_service, "list_object_keys", side_effect=lambda prefix: {
                key for key in objects if key.startswith(prefix)
            }),
            patch.object(storage_service, "get_presigned_url", side_effect=sign),
            patch.object(storage_service, "get_shared_image_url", side_effect=lambda key: sign(key, 3600)),
        ):
            db = Mock()
            imported = document_service.upload_document(
                db, "folder", "owner", UploadFile(archive, filename="report.zip"),
            )
            self.assertEqual({doc.name for doc in imported}, {"report.md", "another.md", "standalone.png"})
            doc = next(doc for doc in imported if doc.name == "report.md")
            other = next(doc for doc in imported if doc.name == "another.md")
            refs = [c.args[0] for c in db.add.call_args_list if isinstance(c.args[0], ArchiveImageReference)]
            assets = {r.path_hash: r.image_key for r in refs if r.document_id == doc.id}
            other_assets = {r.path_hash: r.image_key for r in refs if r.document_id == other.id}
            raw = objects[doc.storage_path]
            self.assertEqual(raw.decode(), markdown)
            parsed = asyncio.run(parsing_service.parse_document(
                raw, doc.name, doc.extension, doc.kb_id, doc.id, archive_assets=assets,
            ))
            doc.md_path = parsed["md_path"]
            keys = [image["minio_path"] for image in parsed["images"]]
            self.assertEqual([objects[key] for key in keys], [b"first image", b"second image"])
            self.assertEqual(set(other_assets.values()), {keys[0]})
            self.assertTrue(all(key.startswith("kb/archive-images/") for key in keys))
            self.assertEqual(len([key for key in objects if key.startswith("kb/archive-images/")]), 2)

            with (
                patch.object(document_service, "get_document", return_value=doc),
                patch.object(markdown_attachments, "shared_assets", return_value=assets),
            ):
                for source in (True, False):
                    preview = documents.get_document_markdown_preview(doc.id, source, {"id": "owner"}, None)
                    self.assertEqual(preview.content.count(sign(keys[0], 3600)), 2)
                    self.assertIn(sign(keys[1], 3600), preview.content)
                    self.assertIn("![missing](images/missing.png)", preview.content)
                    self.assertIn("![remote](https://example.test/chart.png)", preview.content)

            chunk = chunks._resolve_chunk_image_urls(
                {"content": f"![]({keys[0]})", "image_url": keys}, doc.kb_id, doc.id,
                shared_keys=frozenset(keys),
            )
            self.assertEqual(chunk["image_url"], [sign(key, 86400) for key in keys])
            self.assertEqual(chunk["content"], f"![]({sign(keys[0], 86400)})")

    def test_analysis_fragments_have_the_same_ids_for_each_parent(self):
        key = "kb/archive-images/archive/chart.png"
        db = Mock()
        db.scalars.return_value = [SimpleNamespace(key=key, analysis={"image_ocr": "OCR", "image_caption": "Caption"})]
        first = markdown_attachments.shared_children(
            db, {"document_id": "doc1", "chunk_id": "parent1", "image_url": [key, key]}, {key},
        )
        second = markdown_attachments.shared_children(
            db, {"document_id": "doc2", "chunk_id": "parent2", "image_url": [key]}, {key},
        )
        self.assertEqual(len(first), 2)
        self.assertEqual([(c["chunk_id"], c["content"]) for c in first],
                         [(c["chunk_id"], c["content"]) for c in second])

    def test_asset_is_removed_only_when_no_reference_remains(self):
        db = Mock()
        image = SimpleNamespace(key="shared-image")
        db.scalars.return_value = [image]
        db.scalar.side_effect = [True, False]
        self.assertEqual(markdown_attachments.remove_unreferenced_images(db, {image.key}), [])
        db.delete.assert_not_called()
        self.assertEqual(markdown_attachments.remove_unreferenced_images(db, {image.key}), [image.key])
        db.delete.assert_called_once_with(image)


class SharedImageAnalysisTests(unittest.IsolatedAsyncioTestCase):
    async def test_parallel_references_analyze_the_image_only_once(self):
        class Lock:
            def __init__(self):
                self.lock = asyncio.Lock()

            def __call__(self, *args, **kwargs):
                return self.lock

        saved = {}
        key = "kb/archive-images/archive/chart.png"
        with (
            patch.object(document_status, "redis_pool", SimpleNamespace(lock=Lock())),
            patch.object(markdown_attachments, "_read_analysis", side_effect=lambda _: (True, saved.copy())),
            patch.object(markdown_attachments, "_save_analysis", side_effect=lambda _, values: saved.update(values)),
            patch.object(storage_service, "download_file", return_value=b"chart") as download,
            patch.object(image_service, "process_image_ocr", new=AsyncMock(return_value="ocr")) as ocr,
            patch.object(image_service, "process_image_caption", new=AsyncMock(return_value="caption")) as caption,
        ):
            await asyncio.gather(
                markdown_attachments.analyze_shared_image(key, "model"),
                markdown_attachments.analyze_shared_image(key, "model"),
            )
        self.assertEqual(saved, {"image_ocr": "ocr", "image_caption": "caption"})
        download.assert_called_once_with(key)
        ocr.assert_awaited_once()
        caption.assert_awaited_once()
