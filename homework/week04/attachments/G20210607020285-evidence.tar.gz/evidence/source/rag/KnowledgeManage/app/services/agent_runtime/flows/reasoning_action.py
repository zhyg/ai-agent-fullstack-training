"""推理行动流程（FR-017–022）：langgraph 循环 clarify→(rewrite→retrieve→rerank→compress→sufficiency)*→answer.

- 一轮＝重写→检索→rerank→压缩→充足判断（loop_count 默认 10，澄清/答案不计入，FR-018）；
- 检索为空/压缩空＝不充足进下一轮（跳过充足判断模型调用，沿用当前问题重查）；
- 压缩后片段按 chunk_id 去重累积（first_loop 标记），每轮经 budget 核算淘汰（FR-019）；
- 空转检测：new_question 归一化相同或 difflib ≥0.9 提前收敛记 idle_loop_converged（R10）；
- 达上限强制收敛记 forced_convergence；上下文为空走"无资料"话术分支（FR-021）。
"""
import difflib
import logging
import re
from typing import Any, List, TypedDict

from langgraph.graph import END, StateGraph

from app.services import retrieval_service, rerank_service
from app.services.agent_runtime import budget, citation, steps, tracing
from app.services.agent_runtime.flows.quick_qa import _after_clarify, _clarify_node
from app.services.agent_runtime.state import ContextChunk, RequestRuntimeState

logger = logging.getLogger(__name__)

NO_MATERIAL_TEXT = "未在知识库中找到相关资料，无法回答该问题。"
IDLE_SIMILARITY_THRESHOLD = 0.9  # research.md R10


class FlowState(TypedDict, total=False):
    rt: RequestRuntimeState
    emit: Any
    result: dict
    next_question: str          # sufficiency 给出的下一轮检索问题
    retrieved: List[ContextChunk]
    reranked: List[ContextChunk]
    kept: List[ContextChunk]
    converged: bool             # 充足/空转/强制收敛 → 进入答案生成


def _normalize(text: str) -> str:
    """空转比较归一化：去空白/标点、小写（保留中英文字词）."""
    return re.sub(r"[\W_]+", "", (text or "").lower())


def _is_idle(new_question: str, last_question: str) -> bool:
    a, b = _normalize(new_question), _normalize(last_question)
    if not a or not b:
        return False
    if a == b:
        return True
    return difflib.SequenceMatcher(None, a, b).ratio() >= IDLE_SIMILARITY_THRESHOLD


def _record_convergence(rt: RequestRuntimeState, event: str, detail: dict) -> None:
    """收敛事件：写根 span（agent.run 为 current）+ rt.events（随 meta 落库/下发）."""
    tracing.add_event(tracing.trace.get_current_span(), event, detail)
    rt.events.append({"event": event, **detail})


async def _rewrite_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    rt.loop += 1  # 一轮从重写开始计数（FR-018）
    await steps.run_rewrite(rt, s["emit"], question=s.get("next_question") or None)
    return {}


async def _retrieve_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    snap = rt.snapshot
    rc = snap.retrieval
    await steps.emit_step(
        s["emit"], "retrieve", "start", loop=rt.loop,
        message=f"第 {rt.loop} 轮检索中（{rc.mode}）",
    )
    span = tracing.get_tracer().start_span(f"agent.retrieve.{rc.mode}")
    span.set_attribute(tracing.ATTR_LOOP, rt.loop)
    try:
        tracing.set_input(span, {
            "mode": rc.mode, "question": rt.current_question or rt.question,
            "kb_ids": snap.kb_ids,
        })
        hits = await retrieval_service.retrieve(
            rc.mode,
            rt.current_question or rt.question,
            snap.kb_ids,
            vector_top_k=rc.vector_top_k,
            keyword_top_k=rc.keyword_top_k,
            hybrid_top_k=rc.hybrid_top_k,
            embedding_model_id=snap.embedding_model.model_id if snap.embedding_model else None,
        )
        # 检索命中不直接累积：压缩保留后才并入（FR-019 累积压缩片段）
        tracing.set_output(span, {
            "count": len(hits),
            "chunk_ids": [c.chunk_id for c in hits],
        })
        tracing.set_retrieval_chunks(span, hits)  # 片段全文不截断（013 FR-002）
        return {"retrieved": hits}
    finally:
        span.end()
        await steps.emit_step(s["emit"], "retrieve", "end", loop=rt.loop)


async def _rerank_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    hits = s.get("retrieved") or []
    if not hits:
        return {"reranked": []}
    await steps.emit_step(s["emit"], "rerank", "start", loop=rt.loop)
    span = tracing.get_tracer().start_span("agent.rerank")
    span.set_attribute(tracing.ATTR_LOOP, rt.loop)
    degraded = False
    try:
        ranked, degraded = await rerank_service.rerank(
            rt.current_question or rt.question,
            hits,
            rt.snapshot.rerank_model.name,
            top_n=rt.snapshot.retrieval.rerank_top_n,
            span=span,
        )
        if degraded:
            rt.events.append({"event": tracing.EVENT_RERANK_DEGRADED, "loop": rt.loop})
        return {"reranked": ranked}
    finally:
        span.end()
        await steps.emit_step(
            s["emit"], "rerank", "end", loop=rt.loop,
            message="重排服务降级，按检索分数保留" if degraded else None,
        )


async def _compress_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    kept = await steps.run_compress(rt, s.get("reranked") or [], s["emit"])
    rt.merge_chunks(kept)  # 按 chunk_id 去重累积，first_loop 标记首次轮次
    # 每轮预算核算淘汰（FR-019）：先截最早历史、再按 first_loop 淘汰片段保底 1 条
    fixed = [rt.snapshot.prompts["answer"].content + citation.SOURCE_PROTOCOL]
    report = budget.enforce_budget(rt, fixed)
    if report["dropped_history"] or report["dropped_chunks"] or report["dropped_clarify_history"]:
        tracing.add_event(tracing.trace.get_current_span(), "context_evicted", report)
    return {"kept": kept}


async def _sufficiency_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    if not s.get("kept"):
        # 检索为空/压缩空＝不充足（FR-017）：跳过模型调用，沿用当前问题进下一轮
        new_question = rt.current_question or rt.question
    else:
        result = await steps.run_sufficiency(rt, s["emit"], last_question=rt.current_question)
        if result.sufficient:
            return {"converged": True}
        new_question = result.new_question
        # 空转检测（FR-022，R10）：与上一轮检索问题相同/高度相似 → 提前收敛
        if _is_idle(new_question, rt.current_question):
            _record_convergence(rt, tracing.EVENT_IDLE_LOOP_CONVERGED, {
                "loop": rt.loop, "new_question": new_question,
            })
            return {"converged": True}
    if rt.loop >= rt.snapshot.loop_count:
        # 达上限强制收敛（FR-021）：携带已有上下文进入答案生成
        _record_convergence(rt, tracing.EVENT_FORCED_CONVERGENCE, {"loop": rt.loop})
        return {"converged": True}
    return {"next_question": new_question}


def _after_sufficiency(s: FlowState) -> str:
    return "answer" if s.get("converged") else "rewrite"


async def _answer_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    if not rt.chunks:
        # 强制收敛且上下文为空：无资料话术分支，不让模型无依据作答（FR-021）
        meta: dict = {"terminate_reason": "empty_retrieval"}
        if rt.events:
            meta["events"] = rt.events
        return {"result": {"content": NO_MATERIAL_TEXT, "meta": meta}}
    answer = await steps.stream_answer(rt, s["emit"])
    meta = {"references": answer["references"]}
    if answer.get("usage"):
        meta["usage"] = answer["usage"]
    if rt.events:
        meta["events"] = rt.events
    return {"result": {"content": answer["content"], "meta": meta}}


def _build_graph():
    graph = StateGraph(FlowState)
    graph.add_node("clarify", _clarify_node)
    graph.add_node("rewrite", _rewrite_node)
    graph.add_node("retrieve", _retrieve_node)
    graph.add_node("rerank", _rerank_node)
    graph.add_node("compress", _compress_node)
    graph.add_node("sufficiency", _sufficiency_node)
    graph.add_node("answer", _answer_node)
    graph.set_entry_point("clarify")
    graph.add_conditional_edges("clarify", _after_clarify, {"rewrite": "rewrite", "end": END})
    graph.add_edge("rewrite", "retrieve")
    graph.add_edge("retrieve", "rerank")
    graph.add_edge("rerank", "compress")
    graph.add_edge("compress", "sufficiency")
    graph.add_conditional_edges("sufficiency", _after_sufficiency, {"answer": "answer", "rewrite": "rewrite"})
    graph.add_edge("answer", END)
    return graph.compile()


_graph = _build_graph()


async def run_reasoning_action(state: RequestRuntimeState, emit) -> dict:
    """执行循环流程，返回 {content, meta}；异常（取消/JSON 失败/流程级）上抛由入口统一处理."""
    # 每轮 5 节点 + 澄清/答案；loop_count 最大 1000，需抬高默认 recursion_limit=25
    recursion_limit = state.snapshot.loop_count * 5 + 10
    final = await _graph.ainvoke(
        {"rt": state, "emit": emit}, config={"recursion_limit": recursion_limit},
    )
    return final.get("result") or {"content": "", "meta": {}}