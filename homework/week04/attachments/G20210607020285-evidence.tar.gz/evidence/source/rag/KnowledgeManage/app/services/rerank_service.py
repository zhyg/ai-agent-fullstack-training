"""Rerank 服务：经 LlmGateway /api/llm/v1/rerank 精排（FR-009，research.md R8）.

Cohere 兼容 schema（已核查 LlmGateway/app/schemas/rerank.py）：
query ≤10000 字符、documents 1–500、top_n、return_documents。
网关重试后仍失败 → 降级按原始检索分截断 rerank_top_n，trace 记 rerank_degraded 事件。
"""
import logging
from typing import List, Tuple

import httpx

from app.core.config import settings
from app.services.agent_runtime import tracing
from app.services.agent_runtime.llm_client import get_llm_gateway_url
from app.services.agent_runtime.state import ContextChunk

logger = logging.getLogger(__name__)

_MAX_DOCUMENTS = 500
_MAX_QUERY_CHARS = 10000


def _degrade(chunks: List[ContextChunk], top_n: int, span, reason: str) -> Tuple[List[ContextChunk], bool]:
    logger.warning("Rerank degraded to original scores: %s", reason)
    tracing.add_event(span, tracing.EVENT_RERANK_DEGRADED, {"reason": reason})
    ordered = sorted(chunks, key=lambda c: c.score, reverse=True)
    return ordered[:top_n], True


async def rerank(
    question: str,
    chunks: List[ContextChunk],
    rerank_model_name: str,
    *,
    top_n: int = 15,
    span=None,
) -> Tuple[List[ContextChunk], bool]:
    """精排保留 top_n 条（默认 15，范围 1–100）；返回 (排序后片段, 是否降级)."""
    span = span if span is not None else tracing.trace.get_current_span()
    if not chunks:
        return [], False
    # 网关 documents 上限 500：超出按原始分先截断
    candidates = sorted(chunks, key=lambda c: c.score, reverse=True)[:_MAX_DOCUMENTS]
    payload = {
        "model": rerank_model_name,
        "query": question[:_MAX_QUERY_CHARS],
        "documents": [c.content for c in candidates],
        "top_n": min(top_n, len(candidates)),
        "return_documents": False,
    }
    tracing.set_input(span, {"query": payload["query"], "document_count": len(candidates), "top_n": payload["top_n"]})
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{get_llm_gateway_url()}/api/llm/v1/rerank",
                json=payload,
                headers={
                    "Authorization": f"Bearer {settings.llm_api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
            result = resp.json()
    except httpx.HTTPError as e:
        return _degrade(chunks, top_n, span, str(e))
    if not isinstance(result, dict) or result.get("error") or "results" not in result:
        return _degrade(chunks, top_n, span, f"unexpected response: {str(result)[:200]}")

    ranked: List[ContextChunk] = []
    try:
        for item in sorted(result["results"], key=lambda r: r.get("relevance_score", 0.0), reverse=True):
            idx = item["index"]
            chunk = candidates[idx]
            chunk.score = float(item.get("relevance_score", chunk.score))
            ranked.append(chunk)
    except (KeyError, IndexError, TypeError) as e:
        return _degrade(chunks, top_n, span, f"invalid results: {e}")
    ranked = ranked[:top_n]
    tracing.set_output(span, {
        "kept": [{"chunk_id": c.chunk_id, "score": c.score} for c in ranked],
        "degraded": False,
    })
    return ranked, False