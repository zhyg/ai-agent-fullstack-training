"""Chunk Pydantic schemas for ES chunk data."""

from pydantic import BaseModel, Field
from typing import Optional, List, Any
from datetime import datetime


class ChunkResponse(BaseModel):
    """单个 chunk 的响应模型。"""
    chunk_id: str
    document_id: str
    chunk_type: str = Field(..., description="text/image/image_ocr/image_caption/table_row/ai_question")
    content: str = ""
    image_url: Optional[Any] = Field(None, description="图片地址: text/table_row 为数组, image 为字符串, 其他为 null")
    parent_chunk_id: Optional[str] = None
    sqlite_url: Optional[str] = None
    chunk_index: int = 0
    created_at: Optional[datetime] = None


class ChunkListResponse(BaseModel):
    """chunk 列表分页响应。"""
    items: List[ChunkResponse]
    total: int
    page: int
    page_size: int


class ChunkChildResponse(BaseModel):
    """子 chunks 列表响应（image_ocr/image_caption/ai_question）。"""
    items: List[ChunkResponse]


class ReprocessRequest(BaseModel):
    """重新处理文档的请求模型。"""
    chunk_strategy: str = Field("heading", description="分块策略: heading / fixed")
    chunk_size: int = Field(512, ge=100, le=4000, description="分块大小")
    chunk_overlap: int = Field(80, ge=0, le=500, description="分块重叠")
    separators: Optional[List[str]] = Field(None, description="启用的分隔符列表")
    ai_question_count: int = Field(3, ge=1, le=10, description="AI 问题生成数")


class TableDataResponse(BaseModel):
    """表格数据查询响应。"""
    table_name: str
    columns: List[str]
    rows: List[List[Any]]
    total: int
