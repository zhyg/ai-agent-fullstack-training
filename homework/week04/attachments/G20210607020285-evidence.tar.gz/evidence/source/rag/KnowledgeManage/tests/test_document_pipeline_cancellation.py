import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from app.services import document_pipeline as pipeline


class DocumentPipelineCancellationTests(unittest.IsolatedAsyncioTestCase):
    async def test_deletion_cancels_active_parser_and_skips_later_stages(self):
        parsing = asyncio.Event()
        cancelled = asyncio.Event()
        doc = SimpleNamespace(
            id="doc", kb_id="kb", name="example.docx", extension="docx",
            storage_path="original", chunk_config=None,
        )
        db = Mock()
        db.query.return_value.filter.return_value.first.side_effect = [doc, Mock()]

        async def parse(**kwargs):
            parsing.set()
            try:
                await asyncio.Future()
            finally:
                cancelled.set()

        async def cleanup(kb_id, doc_id):
            self.assertTrue(cancelled.is_set())
            db.close.assert_called_once()

        with (
            patch.object(pipeline, "SessionLocal", return_value=db),
            patch.object(pipeline, "DELETION_CHECK_INTERVAL", 0.001),
            patch.object(pipeline, "_document_exists", side_effect=lambda _: not parsing.is_set()),
            patch.object(pipeline, "_download_from_minio", new=AsyncMock(return_value=b"docx")),
            patch.object(pipeline, "parse_document", new=AsyncMock(side_effect=parse)),
            patch.object(pipeline, "_set_status", new=AsyncMock()) as status,
            patch.object(pipeline, "generate_embeddings", new=AsyncMock()) as embed,
            patch.object(pipeline, "_cleanup_processing_artifacts", new=AsyncMock(side_effect=cleanup)) as clean,
        ):
            await asyncio.wait_for(pipeline.process_document("doc", "kb"), timeout=2)

        status.assert_awaited_once_with(db, doc, pipeline.STATUS_PARSING)
        embed.assert_not_awaited()
        clean.assert_awaited_once_with("kb", "doc")

    async def test_cleanup_waits_for_in_flight_index_write(self):
        writing = asyncio.Event()
        allow_write = asyncio.Event()
        completed_write = asyncio.Event()
        deletion_checked = asyncio.Event()

        async def bulk_index(*args):
            writing.set()
            await allow_write.wait()
            completed_write.set()

        async def run(*args):
            await pipeline._index_chunks("kb", [{"document_id": "doc"}])
            self.fail("Pipeline continued after document deletion")

        def deleted(_):
            if not writing.is_set():
                return True
            loop.call_soon_threadsafe(deletion_checked.set)
            return False

        async def cleanup(*args):
            self.assertTrue(completed_write.is_set())

        loop = asyncio.get_running_loop()
        with (
            patch.object(pipeline, "DELETION_CHECK_INTERVAL", 0.001),
            patch.object(pipeline, "_run_pipeline", new=AsyncMock(side_effect=run)),
            patch.object(pipeline, "_document_exists", side_effect=deleted),
            patch.object(pipeline.es_chunk_service, "bulk_index_chunks", new=AsyncMock(side_effect=bulk_index)),
            patch.object(pipeline, "_cleanup_processing_artifacts", new=AsyncMock(side_effect=cleanup)) as clean,
        ):
            task = asyncio.create_task(pipeline.process_document("doc", "kb"))
            try:
                await asyncio.wait_for(deletion_checked.wait(), timeout=2)
                with self.assertRaises(TimeoutError):
                    await asyncio.wait_for(asyncio.shield(task), timeout=0.05)
                clean.assert_not_awaited()
            finally:
                allow_write.set()
                await asyncio.wait_for(task, timeout=2)

        clean.assert_awaited_once_with("kb", "doc")
