"""Add agent binding to chats and trace/meta to messages (012-agent-logic-runtime)."""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

revision = "f1a2b3c4d5e6"
down_revision = "e2f3a4b5c6d7"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "chats",
        sa.Column("agent_id", sa.String(36), nullable=True),
        schema="knowledge_manage",
    )
    op.add_column(
        "chats",
        sa.Column("agent_type", sa.String(30), nullable=True),
        schema="knowledge_manage",
    )
    op.add_column(
        "chats",
        sa.Column("knowledge_base_ids", JSONB, nullable=True),
        schema="knowledge_manage",
    )
    op.add_column(
        "messages",
        sa.Column("trace_id", sa.String(32), nullable=True),
        schema="knowledge_manage",
    )
    op.add_column(
        "messages",
        sa.Column("meta", JSONB, nullable=True),
        schema="knowledge_manage",
    )
    op.create_index(
        "idx_messages_trace",
        "messages",
        ["trace_id"],
        schema="knowledge_manage",
    )


def downgrade() -> None:
    op.drop_index("idx_messages_trace", table_name="messages", schema="knowledge_manage")
    op.drop_column("messages", "meta", schema="knowledge_manage")
    op.drop_column("messages", "trace_id", schema="knowledge_manage")
    op.drop_column("chats", "knowledge_base_ids", schema="knowledge_manage")
    op.drop_column("chats", "agent_type", schema="knowledge_manage")
    op.drop_column("chats", "agent_id", schema="knowledge_manage")