"""Trace 查询代理（T043，FR-036，research.md R12）.

按消息 created_at UTC 日期构造 jaeger-span-{D-1},{D},{D+1} 索引（±1 天容错），
term traceID 查询后将 ES 文档转换为 Jaeger UI 格式 {data:[{traceID,spans,processes}]}
（时间单位微秒，与 TraceViewer api.ts 消费格式一致）。前端不直连 ES/Jaeger。
"""
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import List

from app.core.es_client import get_async_client

logger = logging.getLogger(__name__)

SPAN_INDEX_PREFIX = "jaeger-span-"
MAX_SPANS = 10000


def span_indices(created_at: datetime) -> List[str]:
    """±1 天容错索引列表；naive datetime 视为 UTC（DB 统一存 UTC）."""
    day = (
        created_at.astimezone(timezone.utc).date()
        if created_at.tzinfo is not None
        else created_at.date()
    )
    return [
        f"{SPAN_INDEX_PREFIX}{(day + timedelta(days=offset)).isoformat()}"
        for offset in (-1, 0, 1)
    ]


def convert_spans(docs: List[dict]) -> dict:
    """ES jaeger 文档 → Jaeger UI trace 结构：CHILD_OF 规范化 + processes 去重合并."""
    processes: dict = {}
    process_ids: dict = {}
    spans = []
    for doc in docs:
        process = doc.get("process") or {}
        pkey = json.dumps(process, sort_keys=True, ensure_ascii=False)
        pid = process_ids.get(pkey)
        if pid is None:
            pid = f"p{len(processes) + 1}"
            process_ids[pkey] = pid
            processes[pid] = {
                "serviceName": process.get("serviceName") or "unknown",
                "tags": process.get("tags") or [],
            }
        references = [
            {
                "refType": ref.get("refType") or "CHILD_OF",
                "traceID": ref.get("traceID") or doc.get("traceID"),
                "spanID": ref.get("spanID"),
            }
            for ref in doc.get("references") or []
            if ref.get("spanID")
        ]
        start_time = doc.get("startTime") or 0
        spans.append({
            "traceID": doc.get("traceID"),
            "spanID": doc.get("spanID"),
            "operationName": doc.get("operationName"),
            "references": references,
            "startTime": start_time,
            "startTimeMillis": doc.get("startTimeMillis") or start_time // 1000,
            "duration": doc.get("duration") or 0,
            "tags": doc.get("tags") or [],
            "logs": doc.get("logs") or [],
            "processID": pid,
            "process": processes[pid],
        })
    spans.sort(key=lambda s: s["startTime"])
    return {
        "traceID": spans[0]["traceID"] if spans else "",
        "spans": spans,
        "processes": processes,
    }


async def fetch_trace(trace_id: str, created_at: datetime) -> dict:
    """查询轨迹：命中 0 条 → ready:false pending（写入中）；ES 异常上抛由路由映射 503."""
    client = await get_async_client()
    resp = await client.search(
        index=",".join(span_indices(created_at)),
        query={"term": {"traceID": trace_id}},
        size=MAX_SPANS,
        ignore_unavailable=True,
    )
    docs = [hit["_source"] for hit in resp["hits"]["hits"]]
    if not docs:
        return {"ready": False, "reason": "pending"}
    return {"ready": True, "data": [convert_spans(docs)]}