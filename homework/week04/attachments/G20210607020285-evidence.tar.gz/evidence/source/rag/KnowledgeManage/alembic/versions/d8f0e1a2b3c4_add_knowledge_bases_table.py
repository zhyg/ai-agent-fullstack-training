"""add_knowledge_bases_table

Revision ID: d8f0e1a2b3c4
Revises: c7e9f1a2b3d4
Create Date: 2026-11-16 14:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'd8f0e1a2b3c4'
down_revision: Union[str, None] = 'c7e9f1a2b3d4'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('knowledge_bases',
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('name', sa.String(length=100), nullable=False, comment='知识库名称'),
    sa.Column('description', sa.String(length=500), nullable=True, comment='知识库描述'),
    sa.Column('user_id', sa.String(length=36), nullable=False, comment='所属用户 ID'),
    sa.Column('llm_model_id', sa.String(length=36), nullable=False, comment='LLM 模型 ID'),
    sa.Column('embedding_model_id', sa.String(length=36), nullable=False, comment='Embedding 模型 ID'),
    sa.Column('image_model_id', sa.String(length=36), nullable=False, comment='图片识别模型 ID'),
    sa.Column('rerank_model_id', sa.String(length=36), nullable=False, comment='Rerank 模型 ID'),
    sa.Column('created_at', sa.TIMESTAMP(), nullable=False),
    sa.Column('updated_at', sa.TIMESTAMP(), nullable=False),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('user_id', 'name', name='uq_kb_user_name'),
    schema='knowledge_manage'
    )
    op.create_index('idx_kb_user', 'knowledge_bases', ['user_id'], unique=False, schema='knowledge_manage')


def downgrade() -> None:
    op.drop_index('idx_kb_user', table_name='knowledge_bases', schema='knowledge_manage')
    op.drop_table('knowledge_bases', schema='knowledge_manage')
