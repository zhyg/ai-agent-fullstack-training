from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import ValidationError

from app.dependencies import get_current_user
from app.schemas.consumption import ConsumptionQuery, OptionsOut, SeriesOut
from app.services import consumption_service

# 资源消耗监控路由（015-resource-consumption-monitor，contracts/consumption-api.md）
router = APIRouter(prefix="/consumption", tags=["consumption"])


@router.get("/options", response_model=OptionsOut)
async def get_options(current_user: dict = Depends(get_current_user)):
    """筛选选项（决策7/R-006）：label values 排除空串，普通用户仅本人 email。"""
    return await consumption_service.get_options(current_user)


@router.get("/series", response_model=SeriesOut)
async def get_series(
    metric: str,
    scope: str,
    user_email: Optional[str] = None,
    models: Optional[str] = None,
    month: Optional[str] = None,
    year: Optional[int] = None,
    current_user: dict = Depends(get_current_user),
):
    """消耗序列查询（FR-005~018）：参数校验失败转 400（沿用 agents.py 惯例）。"""
    try:
        query = ConsumptionQuery(
            metric=metric, scope=scope, user_email=user_email,
            models=models, month=month, year=year,
        )
    except ValidationError as e:
        err = e.errors()[0]
        msg = err.get("msg", "参数校验失败")
        # 去掉 pydantic "Value error, " 前缀，保留契约文案
        raise HTTPException(status_code=400, detail=msg.split(", ", 1)[-1])
    return await consumption_service.query_series(query, current_user)