import asyncio
import json
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from app.routers import chats
from app.schemas.chat import MessageCreate
from app.services import chat_service


class ChatBackgroundTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.release = asyncio.Event()
        self.waiting = asyncio.Event()
        self.chat = SimpleNamespace(
            id="background-chat", model_name="test-model", status="idle", prompt_id=None,
        )
        self.db = MagicMock()
        self.db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        self.response = MagicMock(status_code=200)
        self.response.headers = {"content-type": "text/event-stream"}
        self.response.aiter_lines = self.lines
        self.stream_context = AsyncMock()
        self.stream_context.__aenter__.return_value = self.response
        client = MagicMock()
        client.stream.return_value = self.stream_context
        client_context = AsyncMock()
        client_context.__aenter__.return_value = client
        self.patches = [
            patch.object(chat_service, "get_chat", return_value=self.chat),
            patch.object(chat_service, "_get_redis_pool", return_value=None),
            patch.object(chat_service, "SessionLocal"),
            patch.object(chat_service, "save_message"),
            patch.object(chat_service.httpx, "AsyncClient", return_value=client_context),
        ]
        mocks = [self.enterContext(patcher) for patcher in self.patches]
        self.sessions, self.save = mocks[2:4]
        self.sessions.return_value.__enter__.return_value = self.db

    async def lines(self):
        yield 'data: {"type": "delta", "content": "first"}'
        self.waiting.set()
        await self.release.wait()
        yield 'data: {"type": "delta", "content": "-last"}'
        yield "data: [DONE]"

    async def asyncTearDown(self):
        self.release.set()
        await asyncio.wait_for(chat_service.finish_generations(), timeout=2)

    async def start(self):
        stream = chat_service.send_message_stream(
            self.chat.id, "question", "test-user"
        )
        event = await asyncio.wait_for(anext(stream), timeout=2)
        self.assertEqual(json.loads(event[6:])["content"], "first")
        await asyncio.wait_for(self.waiting.wait(), timeout=2)
        return stream

    async def test_browser_close_continues_and_persists_full_response(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        self.assertFalse(job.task.done())
        self.assertEqual(self.chat.status, "generating")
        self.sessions.return_value.__exit__.assert_not_called()
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        self.assertEqual(self.chat.status, "completed")
        self.sessions.return_value.__exit__.assert_called_once()

    async def test_cancel_after_browser_close_interrupts_idle_upstream(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        result = await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        self.assertEqual(result.status, "cancelled")
        await asyncio.wait_for(job.task, timeout=2)
        self.assertFalse(self.release.is_set())
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first\n[已取消]"))
        self.stream_context.__aexit__.assert_awaited_once()
        self.assertEqual(self.chat.status, "cancelled")

    async def test_http_disconnect_does_not_cancel_generation(self):
        disconnected = asyncio.Event()
        stream = chat_service.send_message_stream(self.chat.id, "question", "test-user")

        async def receive():
            await disconnected.wait()
            return {"type": "http.disconnect"}

        async def send(message):
            if message["type"] == "http.response.body" and message.get("body"):
                disconnected.set()

        await asyncio.wait_for(
            StreamingResponse(stream, media_type="text/event-stream")(
                {"type": "http", "asgi": {"spec_version": "2.0"}}, receive, send,
            ),
            timeout=2,
        )
        job = chat_service._generations[self.chat.id]
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.task.done())
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        self.assertEqual(self.chat.status, "completed")

    async def test_cancelling_sse_while_waiting_does_not_cancel_generation(self):
        stream = await self.start()
        observer = asyncio.create_task(anext(stream))
        await asyncio.sleep(0)
        observer.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await observer
        job = chat_service._generations[self.chat.id]
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.cancel.is_set())
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(self.chat.status, "completed")

    async def test_connected_cancel_emits_cancelled_not_error(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        events = [event async for event in stream]
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(json.loads(events[0][6:])["type"], "cancelled")
        self.assertEqual(events[-1], "data: [DONE]\n\n")

    async def test_cancel_from_redis_interrupts_idle_upstream(self):
        messages = asyncio.Queue()
        pubsub = MagicMock()
        pubsub.subscribe = AsyncMock()
        pubsub.unsubscribe = AsyncMock()
        pubsub.aclose = AsyncMock()

        async def listen():
            yield await messages.get()

        pubsub.listen = listen
        pool = MagicMock()
        pool.pubsub.return_value = pubsub
        pool.get = AsyncMock(return_value=None)
        pool.xadd = AsyncMock(return_value="1-0")
        pool.expire = AsyncMock(return_value=True)
        with patch.object(chat_service, "_get_redis_pool", return_value=pool):
            stream = await self.start()
            job = chat_service._generations[self.chat.id]
            self.chat.status = "cancelled"
            messages.put_nowait({
                "type": "message",
                "data": json.dumps({
                    "action": "cancel",
                    "generation_id": job.generation_id,
                }),
            })
            events = [event async for event in stream]
            await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(json.loads(events[0][6:])["type"], "cancelled")
        self.assertFalse(self.release.is_set())
        pubsub.unsubscribe.assert_awaited_once()
        pubsub.aclose.assert_awaited_once()

    async def test_shared_generation_replays_stream_and_stops_at_done_marker(self):
        events = [
            "data: {\"type\": \"delta\", \"content\": \"shared\"}\n\n",
            "data: [DONE]\n\n",
        ]
        pool = MagicMock()
        pool.xread = AsyncMock(return_value=[(
            "shared-stream",
            [
                ("1-0", {"event": events[0], "done": "0"}),
                ("2-0", {"event": events[1], "done": "0"}),
                ("3-0", {"event": "", "done": "1"}),
            ],
        )])
        with patch.object(chat_service, "_get_redis_pool", return_value=pool):
            replayed = [
                event async for event in chat_service._stream_shared_generation(
                    self.chat.id, "shared-generation"
                )
            ]

        self.assertEqual(replayed, events)
        pool.xread.assert_awaited_once_with(
            {chat_service._generation_stream_key(self.chat.id, "shared-generation"): "0-0"},
            count=100,
            block=1000,
        )

    async def test_cancel_next_generation_does_not_inherit_previous_signal(self):
        stream = await self.start()
        first_job = chat_service._generations[self.chat.id]
        await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        _ = [event async for event in stream]
        await first_job.task
        second = await self.start()
        second_job = chat_service._generations[self.chat.id]
        self.assertFalse(second_job.cancel.is_set())
        await second.aclose()
        self.release.set()
        await asyncio.wait_for(second_job.task, timeout=2)
        self.assertEqual(self.chat.status, "completed")

    async def test_detaching_does_not_cancel_generation(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.cancel.is_set())
        self.assertFalse(job.task.done())
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertTrue(job.done.is_set())
        self.assertEqual(self.chat.status, "completed")

    async def test_duplicate_send_reattaches_to_active_job(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        duplicate = chat_service.send_message_stream(self.chat.id, "duplicate", "test-user")
        # Release must happen BEFORE consuming the duplicate stream,
        # otherwise the background task blocks on release.wait() and
        # the async for deadlocks waiting for events.
        self.release.set()
        events = [event async for event in duplicate]
        self.assertEqual(json.loads(events[0][6:])["type"], "delta")
        self.assertEqual(events[-1], "data: [DONE]\n\n")
        # Job stays in _generations when detached, allowing reattach
        self.assertIs(chat_service._generations.get(self.chat.id), job)
        # save_message called twice: user message (send_message_stream) + assistant message (_run_generation)
        self.assertEqual(self.save.call_count, 2)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        await asyncio.wait_for(job.task, timeout=2)
        self.assertTrue(job.done.is_set())

    async def test_reconnect_replays_events_received_before_disconnect(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()

        reconnect = chat_service.send_message_stream(
            self.chat.id, "", "test-user"
        )
        replayed = await asyncio.wait_for(anext(reconnect), timeout=2)
        self.assertEqual(json.loads(replayed[6:])["content"], "first")

        self.release.set()
        remaining = [event async for event in reconnect]
        self.assertEqual(
            [json.loads(event[6:]).get("content") for event in remaining[:-1]],
            ["-last", None],
        )
        self.assertEqual(remaining[-1], "data: [DONE]\n\n")
        await asyncio.wait_for(job.task, timeout=2)

    async def test_empty_message_without_generating_chat_is_rejected(self):
        events = [
            event async for event in chat_service.send_message_stream(
                self.chat.id, "", "test-user"
            )
        ]

        self.assertEqual(
            json.loads(events[0][6:])["message"], "没有正在生成的回复可恢复"
        )
        self.assertEqual(events[-1], "data: [DONE]\n\n")
        self.sessions.assert_called_once()
        self.save.assert_not_called()

    async def test_completed_chat_with_stale_generating_status_is_reconciled(self):
        self.chat.status = "generating"
        self.sessions.return_value.query.return_value.filter.return_value.order_by.return_value.all.return_value = [
            SimpleNamespace(role="user", content="question"),
            SimpleNamespace(role="assistant", content="completed answer"),
        ]

        events = [
            event async for event in chat_service.send_message_stream(
                self.chat.id, "", "test-user"
            )
        ]

        self.assertEqual(self.chat.status, "completed")
        self.sessions.return_value.commit.assert_called()
        self.assertEqual(json.loads(events[0][6:])["type"], "done")
        self.assertEqual(events[-1], "data: [DONE]\n\n")
        self.sessions.assert_called_once()
        self.save.assert_not_called()

    async def test_missing_job_restarts_from_persisted_conversation(self):
        self.chat.status = "generating"
        self.sessions.return_value.query.return_value.filter.return_value.order_by.return_value.all.return_value = [
            SimpleNamespace(role="user", content="original question")
        ]
        self.save.reset_mock()

        stream = chat_service.send_message_stream(
            self.chat.id, "", "test-user"
        )
        first_event = await asyncio.wait_for(anext(stream), timeout=2)
        self.assertEqual(json.loads(first_event[6:])["content"], "first")
        job = chat_service._generations[self.chat.id]
        await asyncio.wait_for(self.waiting.wait(), timeout=2)

        self.release.set()
        events = [first_event, *[event async for event in stream]]
        await asyncio.wait_for(job.task, timeout=2)

        self.assertEqual(self.save.call_count, 1)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        self.assertEqual(self.chat.status, "completed")


class AgentStopGenerationTests(unittest.IsolatedAsyncioTestCase):
    """Agent 模式停止（T042，FR-031/032，R4/R5）：部分答案落库带标记 / 断线宽限 / 期内续流."""

    async def asyncSetUp(self):
        self.chat = SimpleNamespace(
            id="agent-chat", model_name=None, status="idle", prompt_id=None,
            agent_id="agent-1", knowledge_base_ids=["kb-1"],
            generation_id=None, lease_expires_at=None, lease_owner=None,
        )
        self.db = MagicMock()
        self.db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        self.finish = asyncio.Event()
        self.started = asyncio.Event()

        async def fake_run(**kwargs):
            # 模拟 agent_runtime 入口：先发 delta，再轮询取消/完成信号；
            # 硬取消（task.cancel）被转换为部分答案结果（与入口 AgentCancelled 映射一致）
            cancel = kwargs["cancel_event"]
            await kwargs["emit"]('data: {"type": "delta", "content": "部分答案"}\n\n')
            self.started.set()
            try:
                while not self.finish.is_set() and not cancel.is_set():
                    await asyncio.sleep(0.01)
            except asyncio.CancelledError:
                return {"content": "部分答案", "meta": {}, "trace_id": "trace-1", "cancelled": True}
            if cancel.is_set():
                return {"content": "部分答案", "meta": {}, "trace_id": "trace-1", "cancelled": True}
            return {
                "content": "完整答案", "meta": {"usage": {"total_tokens": 5}},
                "trace_id": "trace-1", "cancelled": False,
            }

        self.save = MagicMock()
        self.save.return_value = SimpleNamespace(id="msg-1")
        self.patches = [
            patch.object(chat_service, "get_chat", return_value=self.chat),
            patch.object(chat_service, "_get_redis_pool", return_value=None),
            patch.object(chat_service, "SessionLocal"),
            patch.object(chat_service, "save_message", new=self.save),
            patch.object(chat_service, "LEASE_SECONDS", 0.05),
            patch("app.services.agent_runtime.run_agent_generation", new=AsyncMock(side_effect=fake_run)),
        ]
        mocks = [self.enterContext(p) for p in self.patches]
        self.sessions = mocks[2]
        self.sessions.return_value.__enter__.return_value = self.db

    async def asyncTearDown(self):
        self.finish.set()
        await asyncio.wait_for(chat_service.finish_generations(), timeout=2)

    async def start(self):
        stream = chat_service.send_message_stream(self.chat.id, "question", "test-user")
        event = await asyncio.wait_for(anext(stream), timeout=2)
        self.assertEqual(json.loads(event[6:])["content"], "部分答案")
        await asyncio.wait_for(self.started.wait(), timeout=2)
        return stream

    async def test_stop_persists_partial_answer_with_stopped_marker(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        events = [json.loads(e[6:]) for e in [event async for event in stream] if e != "data: [DONE]\n\n"]
        await asyncio.wait_for(job.task, timeout=2)
        terminal = events[-1]
        self.assertEqual(terminal["type"], "cancelled")
        self.assertEqual(terminal["partial_content"], "部分答案")
        self.assertEqual(terminal["message_id"], "msg-1")
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "部分答案\n[已停止]"))
        self.assertTrue(self.save.call_args.kwargs["meta"]["stopped"])
        self.assertEqual(self.save.call_args.kwargs["trace_id"], "trace-1")
        self.assertEqual(self.chat.status, "cancelled")

    async def test_disconnect_grace_expiry_cancels_generation(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.cancel.is_set())  # 宽限期内不立即取消
        await asyncio.wait_for(job.task, timeout=2)  # LEASE_SECONDS=0.05 到期后视同停止
        self.assertTrue(job.cancel.is_set())
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "部分答案\n[已停止]"))
        self.assertTrue(self.save.call_args.kwargs["meta"]["stopped"])
        self.assertEqual(self.chat.status, "cancelled")

    async def test_reattach_within_grace_resumes_and_completes(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        reconnect = chat_service.send_message_stream(self.chat.id, "", "test-user")
        replayed = await asyncio.wait_for(anext(reconnect), timeout=2)
        self.assertEqual(json.loads(replayed[6:])["content"], "部分答案")
        self.assertFalse(job.detached.is_set())  # 宽限倒计时已解除
        self.finish.set()
        remaining = [event async for event in reconnect]
        await asyncio.wait_for(job.task, timeout=2)
        terminal = json.loads(remaining[-2][6:])
        self.assertEqual(terminal["type"], "done")
        self.assertEqual(terminal["trace_id"], "trace-1")
        self.assertEqual(remaining[-1], "data: [DONE]\n\n")
        await asyncio.sleep(0.1)  # 超过宽限窗口后仍不应被取消
        self.assertFalse(job.cancel.is_set())
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "完整答案"))
        self.assertEqual(self.chat.status, "completed")


class AgentHistoryIndexTriggerTests(unittest.IsolatedAsyncioTestCase):
    """013 T021/T023：done 终态触发历史写入；cancelled/error/无向量模型不触发（SC-005，FR-013）."""

    async def asyncSetUp(self):
        self.chat = SimpleNamespace(
            id="agent-chat", model_name=None, status="idle", prompt_id=None,
            agent_id="agent-1", knowledge_base_ids=["kb-1"],
            generation_id=None, lease_expires_at=None, lease_owner=None,
        )
        self.db = MagicMock()
        self.db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        self.save = MagicMock(return_value=SimpleNamespace(id="msg-1"))
        self.index_mock = AsyncMock()
        self.patches = [
            patch.object(chat_service, "get_chat", return_value=self.chat),
            patch.object(chat_service, "_get_redis_pool", return_value=None),
            patch.object(chat_service, "SessionLocal"),
            patch.object(chat_service, "save_message", new=self.save),
            patch("app.services.history_qa_service.index_qa_round", new=self.index_mock),
        ]
        mocks = [self.enterContext(p) for p in self.patches]
        self.sessions = mocks[2]
        self.sessions.return_value.__enter__.return_value = self.db

    async def asyncTearDown(self):
        await asyncio.wait_for(chat_service.finish_generations(), timeout=2)

    async def _run(self, result):
        with patch("app.services.agent_runtime.run_agent_generation",
                   new=AsyncMock(return_value=result)):
            events = [
                json.loads(e[6:]) async for e in
                chat_service.send_message_stream(self.chat.id, "question", "test-user")
                if e != "data: [DONE]\n\n"
            ]
        await asyncio.sleep(0.01)  # 让火忘式写入 task 得以执行
        return events

    async def test_done_triggers_index_with_round_fields(self):
        events = await self._run({
            "content": "完整答案", "meta": {}, "trace_id": "trace-1",
            "cancelled": False, "embedding_model_id": "emb-1",
        })
        self.assertEqual(events[-1]["type"], "done")
        self.index_mock.assert_awaited_once()
        kwargs = self.index_mock.await_args.kwargs
        self.assertEqual(kwargs["question"], "question")
        self.assertEqual(kwargs["answer"], "完整答案")
        self.assertEqual(kwargs["message_id"], "msg-1")
        self.assertEqual(kwargs["embedding_model_id"], "emb-1")
        self.assertEqual(kwargs["trace_id"], "trace-1")

    async def test_cancelled_does_not_trigger_index(self):
        events = await self._run({
            "content": "部分答案", "meta": {"stopped": True}, "trace_id": "trace-1",
            "cancelled": True, "embedding_model_id": "emb-1",
        })
        self.assertEqual(events[-1]["type"], "cancelled")
        self.index_mock.assert_not_awaited()

    async def test_error_does_not_trigger_index(self):
        events = await self._run({
            "content": "", "meta": {}, "trace_id": "trace-1", "cancelled": False,
            "error": {"code": "model_unavailable", "message": "模型不可用"},
            "embedding_model_id": "emb-1",
        })
        self.assertEqual(events[-1]["type"], "error")
        self.index_mock.assert_not_awaited()

    async def test_done_without_embedding_model_does_not_trigger_index(self):
        events = await self._run({
            "content": "完整答案", "meta": {}, "trace_id": "trace-1", "cancelled": False,
        })
        self.assertEqual(events[-1]["type"], "done")
        self.index_mock.assert_not_awaited()


class AgentTerminationDeltaTests(unittest.IsolatedAsyncioTestCase):
    """非流式终止分支（clarify_failed/empty_retrieval）：终态前补发 delta，前端可见 reason."""

    async def asyncSetUp(self):
        self.chat = SimpleNamespace(
            id="agent-chat", model_name=None, status="idle", prompt_id=None,
            agent_id="agent-1", knowledge_base_ids=["kb-1"],
            generation_id=None, lease_expires_at=None, lease_owner=None,
        )
        self.db = MagicMock()
        self.db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        self.save = MagicMock(return_value=SimpleNamespace(id="msg-1"))
        self.patches = [
            patch.object(chat_service, "get_chat", return_value=self.chat),
            patch.object(chat_service, "_get_redis_pool", return_value=None),
            patch.object(chat_service, "SessionLocal"),
            patch.object(chat_service, "save_message", new=self.save),
        ]
        mocks = [self.enterContext(p) for p in self.patches]
        self.sessions = mocks[2]
        self.sessions.return_value.__enter__.return_value = self.db

    async def asyncTearDown(self):
        await asyncio.wait_for(chat_service.finish_generations(), timeout=2)

    async def _run(self, result):
        with patch("app.services.agent_runtime.run_agent_generation",
                   new=AsyncMock(return_value=result)):
            return [
                json.loads(e[6:]) async for e in
                chat_service.send_message_stream(self.chat.id, "question", "test-user")
                if e != "data: [DONE]\n\n"
            ]

    async def test_clarify_failed_reason_emitted_as_delta_before_done(self):
        reason = "问题中的代词“他”指代不明，请明确要查询哪位学生的数学成绩。"
        events = await self._run({
            "content": reason, "meta": {"terminate_reason": "clarify_failed"},
            "trace_id": "trace-1", "cancelled": False,
        })
        self.assertEqual(events[-1]["type"], "done")
        deltas = [e for e in events if e.get("type") == "delta"]
        self.assertEqual(len(deltas), 1)
        self.assertEqual(deltas[0]["content"], reason)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", reason))

    async def test_empty_retrieval_text_emitted_as_delta(self):
        events = await self._run({
            "content": "检索结果为空，未找到与问题相关的资料。",
            "meta": {"terminate_reason": "empty_retrieval"},
            "trace_id": "trace-1", "cancelled": False,
        })
        deltas = [e for e in events if e.get("type") == "delta"]
        self.assertEqual(len(deltas), 1)
        self.assertEqual(events[-1]["type"], "done")

    async def test_streamed_answer_not_double_emitted(self):
        # 正常答案已经流式 delta 下发（无 terminate_reason），终态前不重复补发
        events = await self._run({
            "content": "完整答案", "meta": {"usage": {"total_tokens": 5}},
            "trace_id": "trace-1", "cancelled": False,
        })
        self.assertEqual([e for e in events if e.get("type") == "delta"], [])
        self.assertEqual(events[-1]["type"], "done")


class AgentConcurrentRejectTests(unittest.IsolatedAsyncioTestCase):
    """同会话并发拒绝（T042，FR-032，R19）：活跃租约期内新问题 409，reattach/过期租约放行."""

    def _chat(self, *, agent_id="agent-1", status="generating", lease_seconds=30):
        return SimpleNamespace(
            id="c1", agent_id=agent_id, model_name="m", status=status,
            knowledge_base_ids=["kb-1"], prompt_id=None,
            generation_id="g1",
            lease_expires_at=datetime.now(timezone.utc) + timedelta(seconds=lease_seconds),
        )

    async def _send(self, chat, content):
        with patch.object(chats.chat_service, "get_chat", return_value=chat), \
             patch.object(chats.chat_service, "send_message_stream", return_value=MagicMock()):
            return await chats.send_message(
                "c1", MessageCreate(content=content),
                current_user={"id": "u"}, db=MagicMock(),
            )

    async def test_active_lease_new_question_returns_409(self):
        with self.assertRaises(HTTPException) as ctx:
            await self._send(self._chat(), "新问题")
        self.assertEqual(ctx.exception.status_code, 409)
        self.assertEqual(ctx.exception.detail, "当前问答尚未结束，请稍候")

    async def test_expired_lease_allows_new_question(self):
        resp = await self._send(self._chat(lease_seconds=-1), "新问题")
        self.assertIsInstance(resp, StreamingResponse)

    async def test_empty_content_reattach_skips_409(self):
        resp = await self._send(self._chat(), "")
        self.assertIsInstance(resp, StreamingResponse)

    async def test_legacy_mode_generating_not_rejected_at_router(self):
        # 旧模式无 409 前置拦截（由 send_message_stream 内部 reattach/共享流处理），零回归
        resp = await self._send(self._chat(agent_id=None), "新问题")
        self.assertIsInstance(resp, StreamingResponse)

