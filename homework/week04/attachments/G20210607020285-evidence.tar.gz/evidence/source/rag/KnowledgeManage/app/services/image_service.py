"""Image processing service — OCR and caption generation for images."""

import base64
import logging
import os
import re
from typing import Dict, Any

import httpx

from app.core.config import settings
from app.services.embedding_service import resolve_model_name
from app.services.parsing_service import build_mineru_parse_form, get_mineru_url

logger = logging.getLogger(__name__)

_OCR_CROP_REF = r"!\[[^\]\r\n]*\]\((?:\./)?images/[^)\r\n]+\)"
_OCR_CROP_PATTERN = re.compile(
    rf"^[ \t]*{_OCR_CROP_REF}[ \t]*(?:\r?\n|$)|{_OCR_CROP_REF}", re.MULTILINE
)


async def process_image_ocr(image_bytes: bytes, image_name: str) -> str:
    """Process an image through MinerU OCR API.

    Args:
        image_bytes: Raw image file bytes
        image_name: Filename for the image

    Returns:
        OCR Markdown without references to MinerU's generated image crops
    """
    mineru_url = get_mineru_url()

    # Determine MIME type from filename
    ext = os.path.splitext(image_name)[1].lower()
    mime_map = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".gif": "image/gif",
        ".webp": "image/webp", ".bmp": "image/bmp", ".tiff": "image/tiff",
        ".pdf": "application/pdf",
    }
    mime_type = mime_map.get(ext, "image/png")

    try:
        async with httpx.AsyncClient(timeout=300) as client:
            # MinerU expects "files" as an array field, use list-of-tuples
            files = [("files", (image_name, image_bytes, mime_type))]
            resp = await client.post(
                f"{mineru_url}/file_parse",
                files=files,
                data=build_mineru_parse_form(),
            )
            resp.raise_for_status()
    except httpx.HTTPError as e:
        logger.error("MinerU OCR API call failed for %s: %s", image_name, e)
        raise RuntimeError(f"OCR 服务不可用: {e}") from e

    # Parse response — MinerU returns nested structure:
    # {"results": {"filename": {"md_content": "..."}}}
    result = resp.json() if "json" in resp.headers.get("content-type", "") else {}
    ocr_text = ""
    if isinstance(result, dict):
        # Try nested results structure first
        results = result.get("results")
        if isinstance(results, dict):
            for _name, file_data in results.items():
                if isinstance(file_data, dict):
                    ocr_text = (
                        file_data.get("md_content", "")
                        or file_data.get("content", "")
                        or file_data.get("text", "")
                    )
                    if ocr_text:
                        break
        # Fallback to top-level keys
        if not ocr_text:
            ocr_text = (
                result.get("md_content", "")
                or result.get("content", "")
                or result.get("text", "")
            )
    if not ocr_text:
        ocr_text = resp.text

    return _OCR_CROP_PATTERN.sub("", ocr_text).strip()


async def process_image_caption(
    image_bytes: bytes,
    image_name: str,
    image_model_id: str,
    api_key: "[REDACTED]"
) -> str:
    """Generate a caption/description for an image using a vision model.

    Uses LlmGateway to call the knowledge base's configured image_model_id
    (vision model) to analyze the image content.

    Args:
        image_bytes: Raw image file bytes
        image_name: Filename for the image
        image_model_id: Vision model ID from knowledge base config
        api_key: "[REDACTED]"

    Returns:
        Generated image caption/analysis text
    """
    gateway_url = settings.services.get("llm_gateway", "http://localhost:8003")
    llm_api_key = "[REDACTED]"

    # Encode image as base64 for vision model
    b64_image = base64.b64encode(image_bytes).decode("utf-8")

    # Determine MIME type from extension
    ext = image_name.rsplit(".", 1)[-1].lower() if "." in image_name else "png"
    mime_map = {
        "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "png": "image/png", "gif": "image/gif",
        "webp": "image/webp", "bmp": "image/bmp",
    }
    mime_type = mime_map.get(ext, "image/png")

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{gateway_url}/api/llm/v1/chat/completions",
                json={
                    "model": resolve_model_name(image_model_id),
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:{mime_type};base64,{b64_image}"
                                    },
                                },
                                {
                                    "type": "text",
                                    "text": "请详细描述这张图片的内容。",
                                },
                            ],
                        }
                    ],
                    "stream": False,
                },
                headers={
                    "Authorization": f"Bearer {llm_api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
    except httpx.HTTPError as e:
        logger.error("Vision model API call failed for %s: %s", image_name, e)
        raise RuntimeError(f"图片分析服务不可用: {e}") from e

    result = resp.json()
    # Parse OpenAI-compatible response
    choices = result.get("choices", [])
    if choices:
        return choices[0].get("message", {}).get("content", "").strip()

    return "图片分析结果暂不可用"
