"""014-knowledge-evaluation US4：题目 trace 查询（T035，FR-035~038，契约 §4，R11）。

模式沿用 tests/test_trace_query.py：直接 await 路由函数 + MagicMock db + patch fetch_trace；
归属校验按评测记录（run.user_id + item.run_id），不校验会话（决策21）。
"""
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from elasticsearch import ApiError, TransportError
from fastapi import HTTPException

from app.models.evaluation_item import EvaluationItem
from app.routers import evaluations as evaluations_router
from app.services import evaluation_service, trace_query_service


def make_run(**overrides):
    base = dict(id="run-1", user_id="u-1", status="completed")
    base.update(overrides)
    return SimpleNamespace(**base)


def make_item(*, trace_id="t" * 32, created_at=None, run_id="run-1"):
    return EvaluationItem(
        id="item-1", run_id=run_id, seq=1,
        question="问题1", standard_answer="标准答案1", status="success",
        trace_id=trace_id,
        created_at=created_at or datetime.now(timezone.utc),
    )


def mock_db(item):
    db = MagicMock()
    db.query.return_value.filter.return_value.first.return_value = item
    return db


class ItemTraceRouterTests(unittest.IsolatedAsyncioTestCase):
    async def _call(self, *, run, item, fetch=None):
        with patch.object(evaluation_service, "get_run", return_value=run):
            with patch.object(
                evaluations_router.trace_query_service, "fetch_trace",
                new=fetch if fetch is not None else AsyncMock(),
            ):
                return await evaluations_router.get_item_trace(
                    "run-1", "item-1", current_user={"id": "u-1"}, db=mock_db(item),
                )

    async def test_cross_user_run_returns_404(self):
        # get_run 按 user_id 过滤，他人 run 视同不存在
        with self.assertRaises(HTTPException) as ctx:
            await self._call(run=None, item=make_item())
        self.assertEqual(ctx.exception.status_code, 404)

    async def test_item_not_found_returns_404(self):
        with self.assertRaises(HTTPException) as ctx:
            await self._call(run=make_run(), item=None)
        self.assertEqual(ctx.exception.status_code, 404)

    async def test_item_not_belonging_to_run_returns_404(self):
        with self.assertRaises(HTTPException) as ctx:
            await self._call(run=make_run(), item=make_item(run_id="other-run"))
        self.assertEqual(ctx.exception.status_code, 404)

    async def test_empty_trace_id_returns_no_trace(self):
        fetch = AsyncMock()
        result = await self._call(run=make_run(), item=make_item(trace_id=None), fetch=fetch)
        self.assertEqual(result, {"ready": False, "reason": "no_trace"})
        fetch.assert_not_awaited()

    async def test_hit_passes_through_jaeger_format(self):
        payload = {"ready": True, "data": [{"traceID": "t" * 32, "spans": [], "processes": {}}]}
        fetch = AsyncMock(return_value=payload)
        item = make_item()
        result = await self._call(run=make_run(), item=item, fetch=fetch)
        self.assertEqual(result, payload)  # 透传不脱敏
        fetch.assert_awaited_once_with("t" * 32, item.created_at)

    async def test_miss_within_48h_returns_pending(self):
        fetch = AsyncMock(return_value={"ready": False, "reason": "pending"})
        item = make_item(created_at=datetime.now(timezone.utc) - timedelta(hours=1))
        result = await self._call(run=make_run(), item=item, fetch=fetch)
        self.assertEqual(result, {"ready": False, "reason": "pending"})

    async def test_miss_over_48h_returns_expired(self):
        fetch = AsyncMock(return_value={"ready": False, "reason": "pending"})
        item = make_item(created_at=datetime.now(timezone.utc) - timedelta(hours=49))
        result = await self._call(run=make_run(), item=item, fetch=fetch)
        self.assertEqual(result, {"ready": False, "reason": "expired"})

    async def test_miss_exactly_48h_returns_pending(self):
        # 边界：≤48h pending，>48h expired（R11）；固定时钟避免构造/判定时差
        fetch = AsyncMock(return_value={"ready": False, "reason": "pending"})
        now = datetime(2026, 11, 24, 12, 0, tzinfo=timezone.utc)
        item = make_item(created_at=now - timedelta(hours=48))
        fake_dt = MagicMock()
        fake_dt.now.return_value = now
        with patch.object(evaluations_router, "datetime", fake_dt):
            result = await self._call(run=make_run(), item=item, fetch=fetch)
        self.assertEqual(result, {"ready": False, "reason": "pending"})

    async def test_naive_created_at_treated_as_utc(self):
        fetch = AsyncMock(return_value={"ready": False, "reason": "pending"})
        item = make_item(created_at=datetime.utcnow() - timedelta(hours=49))
        result = await self._call(run=make_run(), item=item, fetch=fetch)
        self.assertEqual(result, {"ready": False, "reason": "expired"})

    async def test_es_transport_error_returns_503(self):
        fetch = AsyncMock(side_effect=TransportError("connection refused"))
        with self.assertRaises(HTTPException) as ctx:
            await self._call(run=make_run(), item=make_item(), fetch=fetch)
        self.assertEqual(ctx.exception.status_code, 503)
        self.assertEqual(ctx.exception.detail, "轨迹服务暂不可用")

    async def test_es_api_error_returns_503(self):
        fetch = AsyncMock(side_effect=ApiError("index missing", meta=None, body={}))
        with self.assertRaises(HTTPException) as ctx:
            await self._call(run=make_run(), item=make_item(), fetch=fetch)
        self.assertEqual(ctx.exception.status_code, 503)


class ItemTraceQueryTests(unittest.IsolatedAsyncioTestCase):
    """路由查询链路：item 按 id+run_id 双条件过滤；fetch_trace 复用 ±1 天索引。"""

    async def test_item_query_filters_by_id_and_run_id(self):
        db = MagicMock()
        db.query.return_value.filter.return_value.first.return_value = make_item()
        fetch = AsyncMock(return_value={"ready": True, "data": []})
        with patch.object(evaluation_service, "get_run", return_value=make_run()):
            with patch.object(evaluations_router.trace_query_service, "fetch_trace", new=fetch):
                await evaluations_router.get_item_trace(
                    "run-1", "item-1", current_user={"id": "u-1"}, db=db,
                )
        # filter 收到两个条件（id 与 run_id），而非仅 id
        self.assertEqual(db.query.return_value.filter.call_args.args.__len__(), 2)

    async def test_fetch_trace_uses_item_created_at_for_indices(self):
        created = datetime(2026, 11, 23, 10, 0, tzinfo=timezone.utc)
        client = MagicMock()
        client.search = AsyncMock(return_value={"hits": {"hits": []}})
        item = make_item(created_at=created)
        with patch.object(evaluation_service, "get_run", return_value=make_run()):
            with patch.object(trace_query_service, "get_async_client", new=AsyncMock(return_value=client)):
                await evaluations_router.get_item_trace(
                    "run-1", "item-1", current_user={"id": "u-1"}, db=mock_db(item),
                )
        kwargs = client.search.call_args.kwargs
        self.assertEqual(kwargs["index"], "jaeger-span-2026-11-22,jaeger-span-2026-11-23,jaeger-span-2026-11-24")
        self.assertEqual(kwargs["query"], {"term": {"traceID": "t" * 32}})


if __name__ == "__main__":
    unittest.main()