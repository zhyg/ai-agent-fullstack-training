"""Document service — upload, list, tags, delete and related operations."""

import base64
import binascii
import io
import os
import uuid
import json
import shutil
import logging
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Optional, Tuple, Dict

from fastapi import UploadFile, HTTPException
from sqlalchemy.orm import Session

from app.models.document import Document
from app.models.folder import Folder
from app.core import minio_client
from app.services import markdown_attachments, storage_service

from app.services.parsing_service import is_document_type, is_markdown_type, is_image_type, is_spreadsheet_type

logger = logging.getLogger(__name__)

MAX_FILE_SIZE = 524288000  # 500MB

COMPRESSED_EXTENSIONS = {".zip", ".rar", ".7z", ".tar.gz", ".tgz"}

# Supported file types for document processing
SUPPORTED_PROCESSING_EXTENSIONS = {
    ".doc", ".docx", ".ppt", ".pptx", ".pdf",
    ".md", ".markdown",
    ".xls", ".xlsx", ".csv",
    ".png", ".jpg", ".jpeg", ".jp2", ".webp", ".gif", ".bmp",
}

# T047: All known archive extensions (including unsupported)
ALL_ARCHIVE_EXTENSIONS = {
    ".zip", ".rar", ".7z", ".tar.gz", ".tgz",
    ".tar.bz2", ".bz2", ".tar.xz", ".xz", ".tar", ".gz", ".lz", ".lzma",
}

SUPPORTED_ARCHIVE_HINT = "支持的压缩格式: .zip, .rar, .7z, .tar.gz, .tgz"


def _fix_upload_filename(filename: str) -> str:
    """Fix filename encoding from python-multipart.

    python-multipart decodes multipart header fields as latin-1 by default,
    but browsers send filenames as UTF-8.  Re-decode to restore Chinese / CJK
    characters.
    """
    if not filename:
        return filename
    try:
        return filename.encode('latin-1').decode('utf-8')
    except (UnicodeDecodeError, UnicodeEncodeError):
        return filename


def _decode_original_filename(encoded_filename: str) -> str:
    """Decode a UTF-8 filename transported as ASCII-safe base64 form data."""
    try:
        return base64.b64decode(encoded_filename, validate=True).decode("utf-8")
    except (binascii.Error, UnicodeDecodeError) as exc:
        raise HTTPException(status_code=400, detail="文件名编码无效") from exc


def _decode_zip_member_name(info) -> str:
    """Restore Chinese names from unflagged UTF-8 or GBK ZIP entries."""
    if info.flag_bits & 0x800:
        return info.filename

    try:
        raw_name = info.filename.encode("cp437")
    except UnicodeEncodeError:
        return info.filename

    for encoding in ("utf-8", "gbk"):
        try:
            decoded_name = raw_name.decode(encoding)
        except UnicodeDecodeError:
            continue
        if any("\u4e00" <= char <= "\u9fff" for char in decoded_name):
            return decoded_name

    return info.filename


def _verify_folder_ownership(db: Session, folder_id: str, user_id: str) -> Folder:
    """Verify folder exists and belongs to the user's knowledge base."""
    folder = db.query(Folder).filter(Folder.id == folder_id).first()
    if not folder:
        raise HTTPException(status_code=404, detail="目录不存在")

    from app.models.knowledge_base import KnowledgeBase
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == folder.kb_id, KnowledgeBase.user_id == user_id
    ).first()
    if not kb:
        raise HTTPException(status_code=404, detail="无权访问")
    return folder


def _is_compressed(filename: str) -> bool:
    """Check if filename represents a supported compressed archive."""
    lower = filename.lower()
    return (
        lower.endswith(".zip")
        or lower.endswith(".rar")
        or lower.endswith(".7z")
        or lower.endswith(".tar.gz")
        or lower.endswith(".tgz")
    )


def _is_unsupported_archive(filename: str) -> bool:
    """Check if filename looks like an archive but is NOT in the supported list."""
    lower = filename.lower()
    if _is_compressed(lower):
        return False  # it's supported, so not unsupported
    return any(lower.endswith(ext) for ext in ALL_ARCHIVE_EXTENSIONS)


def _get_extension(filename: str) -> str:
    """Extract file extension without dot."""
    lower = filename.lower()
    if lower.endswith(".tar.gz"):
        return "tar.gz"
    _, ext = os.path.splitext(filename)
    return ext.lstrip(".")


def upload_document(
    db: Session,
    folder_id: str,
    user_id: str,
    file: UploadFile,
    original_filename: Optional[str] = None,
    original_filename_b64: Optional[str] = None,
    chunk_strategy: str = "heading",
    chunk_size: int = 512,
    chunk_overlap: int = 80,
    separators: Optional[str] = None,
    ai_question_count: int = 3,
) -> List[Document]:
    """Upload a file (plain or compressed) and create document records.

    For plain files: store directly to MinIO.
    For compressed files: extract, create intermediate folders, store each file.
    """
    folder = _verify_folder_ownership(db, folder_id, user_id)

    # Validate file size
    content = file.file.read()
    file_size = len(content)
    if file_size > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413, detail=f"文件大小超过 500MB 限制（当前 {file_size} 字节）"
        )

    if original_filename_b64:
        filename = _decode_original_filename(original_filename_b64)
    else:
        filename = _fix_upload_filename(original_filename or file.filename)
    filename = filename or "untitled"
    filename = os.path.basename(filename.replace("\\", "/"))

    # T047: Reject unsupported archive formats with clear error
    if _is_unsupported_archive(filename):
        raise HTTPException(
            status_code=400,
            detail=f"不支持的压缩格式: {filename}。{SUPPORTED_ARCHIVE_HINT}",
        )

    bucket = minio_client.get_bucket()

    if not _is_compressed(filename):
        # ── Plain file: single document ──
        doc_id = str(uuid.uuid4())
        storage_path = f"{folder.kb_id}/{folder_id}/{doc_id}/{filename}"
        storage_service.upload_file(
            object_path=storage_path,
            data=io.BytesIO(content),
            length=file_size,
            content_type=file.content_type or "application/octet-stream",
        )

        # Build chunk_config JSON
        chunk_config_dict = {
            "strategy": chunk_strategy,
            "chunk_size": chunk_size,
            "chunk_overlap": chunk_overlap,
            "separators": json.loads(separators) if separators else [
                "\n\n", "\n", "\u3002", "\uff1b", "\uff1f", "\uff01",
                ".", ";", "?", "!"
            ],
        }

        doc = Document(
            id=doc_id,
            name=filename,
            file_size=file_size,
            mime_type=file.content_type,
            extension=_get_extension(filename),
            status="pending",
            storage_path=storage_path,
            chunk_config=json.dumps(chunk_config_dict, ensure_ascii=False),
            ai_question_count=ai_question_count,
            folder_id=folder_id,
            kb_id=folder.kb_id,
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        return [doc]

    # ── Compressed file: extract and create documents ──
    documents: List[Document] = []
    skipped_files: List[str] = []
    tmp_dir = tempfile.mkdtemp(prefix="upload_")
    uploaded_assets: dict[Path, str] = {}
    committed = False

    try:
        # Write uploaded content to temp file
        tmp_path = os.path.join(tmp_dir, filename)
        with open(tmp_path, "wb") as f:
            f.write(content)

        # Extract based on format
        extract_dir = os.path.join(tmp_dir, "extracted")
        os.makedirs(extract_dir, exist_ok=True)
        _extract_archive(tmp_path, filename, extract_dir)

        archive_root = Path(extract_dir).resolve()
        members = []
        for root, dirs, files in os.walk(extract_dir):
            dirs[:] = [d for d in dirs if not d.startswith("__")]
            for fname in files:
                path = Path(root) / fname
                if not fname.startswith(".") and not path.is_symlink() and path.is_file():
                    members.append(path.resolve())

        member_set = set(members)
        references = {
            path: markdown_attachments.find_archive_images(
                path.read_text(encoding="utf-8", errors="replace"), path, archive_root, member_set,
            )
            for path in members if is_markdown_type(_get_extension(path.name))
        }
        asset_paths = {image for refs in references.values() for image in refs.values()}
        asset_prefix = f"{folder.kb_id}/archive-images/{uuid.uuid4()}/"
        for image in sorted(asset_paths):
            uploaded_assets[image] = markdown_attachments.store_shared_image(db, asset_prefix, archive_root, image)
        if uploaded_assets:
            db.flush()
        for path in members:
            if path in asset_paths:
                continue
            fname = path.name
            extension = _get_extension(fname)
            if f".{extension}" not in SUPPORTED_PROCESSING_EXTENSIONS:
                skipped_files.append(fname)
                continue

            target_folder_id = folder_id
            rel_dir = os.path.dirname(os.path.relpath(path, archive_root))
            if rel_dir:
                target_folder_id = _ensure_folder_path(db, folder.kb_id, folder_id, rel_dir)

            file_content = path.read_bytes()
            doc_id = str(uuid.uuid4())
            storage_path = f"{folder.kb_id}/{target_folder_id}/{doc_id}/{fname}"
            storage_service.upload_file(
                object_path=storage_path,
                data=io.BytesIO(file_content),
                length=len(file_content),
            )
            doc = Document(
                id=doc_id,
                name=fname,
                file_size=len(file_content),
                mime_type=None,
                extension=extension,
                status="pending",
                storage_path=storage_path,
                chunk_config=None,
                ai_question_count=ai_question_count,
                skipped_files=json.dumps(skipped_files, ensure_ascii=False) if skipped_files else None,
                folder_id=target_folder_id,
                kb_id=folder.kb_id,
            )
            db.add(doc)
            documents.append(doc)
            if refs := references.get(path):
                db.flush()
                for relative, image in refs.items():
                    markdown_attachments.link_image(
                        db, doc_id, relative, uploaded_assets[image],
                    )

        db.commit()
        committed = True
        for doc in documents:
            db.refresh(doc)

    except Exception:
        if not committed:
            db.rollback()
            markdown_attachments.cleanup_removed_images(list(uploaded_assets.values()))
        raise
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    return documents


def _extract_archive(archive_path: str, filename: str, extract_dir: str) -> None:
    """Extract a compressed archive to extract_dir."""
    lower = filename.lower()

    if lower.endswith(".zip"):
        import zipfile
        with zipfile.ZipFile(archive_path, "r") as zf:
            for info in zf.infolist():
                info.filename = _decode_zip_member_name(info)
            zf.NameToInfo = {info.filename: info for info in zf.filelist}
            zf.extractall(extract_dir)

    elif lower.endswith(".tar.gz") or lower.endswith(".tgz"):
        import tarfile
        with tarfile.open(archive_path, "r:gz") as tf:
            tf.extractall(extract_dir)

    elif lower.endswith(".7z"):
        import py7zr
        with py7zr.SevenZipFile(archive_path, "r") as sz:
            sz.extractall(extract_dir)

    elif lower.endswith(".rar"):
        import rarfile
        with rarfile.RarFile(archive_path, "r") as rf:
            rf.extractall(extract_dir)

    else:
        raise HTTPException(status_code=400, detail=f"不支持的压缩格式: {filename}")


def _ensure_folder_path(
    db: Session, kb_id: str, root_folder_id: str, rel_dir: str
) -> str:
    """Create intermediate folders for a relative path, return the leaf folder ID.

    E.g. rel_dir = "chapter1/section2" creates:
      root_folder -> chapter1 -> section2
    Returns the ID of 'section2' folder.
    """
    parts = [p for p in rel_dir.split(os.sep) if p]
    current_parent_id = root_folder_id

    for part in parts:
        # Check if folder already exists under current parent
        existing = (
            db.query(Folder)
            .filter(
                Folder.kb_id == kb_id,
                Folder.parent_id == current_parent_id,
                Folder.name == part,
            )
            .first()
        )
        if existing:
            current_parent_id = existing.id
        else:
            # Create new folder
            max_order = (
                db.query(Folder)
                .filter(Folder.kb_id == kb_id, Folder.parent_id == current_parent_id)
                .count()
            )
            new_folder = Folder(
                id=str(uuid.uuid4()),
                name=part,
                kb_id=kb_id,
                parent_id=current_parent_id,
                order=max_order,
            )
            db.add(new_folder)
            db.flush()  # get the ID without committing
            current_parent_id = new_folder.id

    return current_parent_id


# ────────────────────────────────────────────────────────────
# T032: list_documents / get_document
# ────────────────────────────────────────────────────────────

def list_documents(
    db: Session,
    folder_id: str,
    user_id: str,
    page: int = 1,
    page_size: int = 20,
) -> Tuple[List[Document], int]:
    """List documents in a folder with pagination.

    Returns (items, total).
    """
    _verify_folder_ownership(db, folder_id, user_id)

    query = db.query(Document).filter(Document.folder_id == folder_id)
    total = query.count()
    items = (
        query
        .order_by(Document.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return items, total


def get_document(db: Session, document_id: str, user_id: str) -> Document:
    """Get a single document, verifying ownership."""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="文档不存在")

    from app.models.knowledge_base import KnowledgeBase
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == doc.kb_id, KnowledgeBase.user_id == user_id
    ).first()
    if not kb:
        raise HTTPException(status_code=404, detail="无权访问")
    return doc


def _verify_doc_ownership(db: Session, document_id: str, user_id: str) -> Document:
    """Internal helper — same as get_document."""
    return get_document(db, document_id, user_id)


# ────────────────────────────────────────────────────────────
# T033: add_tags / remove_tag
# ────────────────────────────────────────────────────────────

def _parse_tags(raw) -> List[str]:
    """Deserialize tags from JSON string or return list as-is.

    Handles edge cases: None, non-list JSON, non-string items,
    unicode, special characters.
    """
    if raw is None:
        return []
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
    else:
        parsed = raw

    if not isinstance(parsed, list):
        return []

    # Ensure every item is a string, strip whitespace, filter empty
    result = []
    for item in parsed:
        if item is None:
            continue
        s = str(item).strip()
        if s:
            result.append(s)
    return result


def _serialize_tags(tags: List[str]) -> str:
    """Serialize tags list to JSON string.

    Handles edge cases: empty list, unicode, special characters.
    """
    if not tags:
        return "[]"
    # Ensure all items are non-None strings
    cleaned = [str(t) for t in tags if t is not None]
    return json.dumps(cleaned, ensure_ascii=False)


def add_tags(db: Session, doc_id: str, user_id: str, new_tags: List[str]) -> Document:
    """Append tags to a document (dedup + trim + filter empty)."""
    doc = _verify_doc_ownership(db, doc_id, user_id)
    existing = _parse_tags(doc.tags)
    cleaned = [t.strip() for t in new_tags if t.strip()]
    merged = list(dict.fromkeys(existing + cleaned))  # dedup, preserve order
    doc.tags = _serialize_tags(merged)
    doc.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(doc)
    return doc


def remove_tag(db: Session, doc_id: str, user_id: str, tag: str) -> Document:
    """Remove a specific tag from a document."""
    doc = _verify_doc_ownership(db, doc_id, user_id)
    existing = _parse_tags(doc.tags)
    filtered = [t for t in existing if t != tag]
    doc.tags = _serialize_tags(filtered)
    doc.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(doc)
    return doc


# ────────────────────────────────────────────────────────────
# T034: delete_document / batch_delete_documents
# ────────────────────────────────────────────────────────────

def delete_document(db: Session, doc_id: str, user_id: str) -> Dict[str, str]:
    """Delete a single document (DB record + MinIO object).

    Returns doc info (kb_id, doc_id) for async ES/MinIO cleanup by the router.
    """
    doc = _verify_doc_ownership(db, doc_id, user_id)
    kb_id = doc.kb_id
    image_keys = markdown_attachments.image_keys_for_documents(db, [doc_id])

    # Delete MinIO original object
    try:
        storage_service.delete_object(doc.storage_path)
    except Exception as e:
        logger.warning("Failed to delete MinIO object %s: %s", doc.storage_path, e)

    db.delete(doc)
    if image_keys:
        db.flush()
    removed_images = markdown_attachments.remove_unreferenced_images(db, image_keys)
    db.commit()
    markdown_attachments.cleanup_removed_images(removed_images)
    return {"kb_id": kb_id, "doc_id": doc_id}


def batch_delete_documents(
    db: Session, doc_ids: List[str], user_id: str
) -> Dict[str, object]:
    """Batch delete documents (including parsing ones).

    Returns {"deleted": N, "deleted_docs": [(kb_id, doc_id), ...]} for async cleanup.
    """
    deleted = 0
    deleted_docs: List[tuple] = []
    for doc_id in doc_ids:
        doc = db.query(Document).filter(Document.id == doc_id).first()
        if not doc:
            continue
        # Verify ownership
        from app.models.knowledge_base import KnowledgeBase
        kb = db.query(KnowledgeBase).filter(
            KnowledgeBase.id == doc.kb_id, KnowledgeBase.user_id == user_id
        ).first()
        if not kb:
            continue
        # Delete MinIO object
        try:
            storage_service.delete_object(doc.storage_path)
        except Exception as e:
            logger.warning("Failed to delete MinIO object %s: %s", doc.storage_path, e)
        deleted_docs.append((doc.kb_id, doc.id))
        db.delete(doc)
        deleted += 1

    image_keys = markdown_attachments.image_keys_for_documents(db, [doc_id for _, doc_id in deleted_docs])
    if image_keys:
        db.flush()
    removed_images = markdown_attachments.remove_unreferenced_images(db, image_keys)
    db.commit()
    markdown_attachments.cleanup_removed_images(removed_images)
    return {"deleted": deleted, "deleted_docs": deleted_docs}


# ────────────────────────────────────────────────────────────
# T039: get_document_file_url
# ────────────────────────────────────────────────────────────

def get_document_file_url(
    db: Session, doc_id: str, user_id: str, expires: int = 3600
) -> Dict[str, object]:
    """Generate a presigned URL for downloading/previewing a document file.

    Returns {"url": str, "expires_in": int}.
    """
    doc = _verify_doc_ownership(db, doc_id, user_id)
    url = storage_service.get_presigned_url(doc.storage_path, expires=expires)
    return {"url": url, "expires_in": expires}


def update_document(
    db: Session, doc_id: str, user_id: str, data: dict
) -> Document:
    """Update document description and/or tags."""
    doc = _verify_doc_ownership(db, doc_id, user_id)
    if "description" in data and data["description"] is not None:
        doc.description = data["description"]
    if "tags" in data and data["tags"] is not None:
        cleaned = [t.strip() for t in data["tags"] if t.strip()]
        doc.tags = _serialize_tags(list(dict.fromkeys(cleaned)))
    doc.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(doc)
    return doc


def reprocess_document(
    db: Session,
    doc_id: str,
    user_id: str,
    reprocess_config,
) -> Document:
    """Prepare a document for reprocessing with new chunk parameters.

    Resets status to 'pending' and updates chunk_config.
    The actual reprocessing (delete old chunks + re-run pipeline)
    is done by the background task.
    """
    doc = _verify_doc_ownership(db, doc_id, user_id)

    # Update chunk_config with new parameters
    chunk_config_dict = {
        "strategy": reprocess_config.chunk_strategy,
        "chunk_size": reprocess_config.chunk_size,
        "chunk_overlap": reprocess_config.chunk_overlap,
        "separators": reprocess_config.separators or [
            "\n\n", "\n", "\u3002", "\uff1b", "\uff1f", "\uff01",
            ".", ";", "?", "!"
        ],
    }
    doc.chunk_config = json.dumps(chunk_config_dict, ensure_ascii=False)
    doc.ai_question_count = reprocess_config.ai_question_count
    doc.status = "pending"
    doc.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(doc)
    return doc
