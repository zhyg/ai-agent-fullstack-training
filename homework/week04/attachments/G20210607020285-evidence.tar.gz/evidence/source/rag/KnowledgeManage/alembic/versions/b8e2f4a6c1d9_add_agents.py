"""add agents table with preset data

Revision ID: b8e2f4a6c1d9
Revises: f49b738a2c01
Create Date: 2026-11-22 10:00:00.000000

"""
from typing import Sequence, Union
import json
import uuid
from datetime import datetime, timezone

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

# revision identifiers, used by Alembic.
revision: str = 'b8e2f4a6c1d9'
down_revision: Union[str, None] = 'f49b738a2c01'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


TOOL_KEYS = [
    "createPlan", "listPlan", "getPlan", "updatePlan", "deletePlan",
    "rewriteQuestion", "bm25Search", "vectorSearch", "rerank", "zip",
    "listTableMetaData", "sqlExecute",
]


def _default_config(agent_type: str) -> dict:
    purposes = ["clarify", "rewrite", "answer", "compress", "rerank"]
    if agent_type == "reasoning_action":
        purposes.append("sufficiency")
    if agent_type == "planning_reasoning":
        purposes.append("planning")
    config = {
        "prompts": {p: None for p in purposes},
        "retrieval": {"mode": "vector", "vector_top_k": 20, "keyword_top_k": 20, "hybrid_top_k": 20, "rerank_top_n": 15},
        "models": {"analysis_model_id": None, "max_tokens": 5000, "embedding_model_id": None, "rerank_model_id": None},
    }
    if agent_type == "reasoning_action":
        config["loop_count"] = 10
    if agent_type == "planning_reasoning":
        config["loop_count"] = 100
        config["tools"] = list(TOOL_KEYS)
    return config


PRESETS = [
    {"type": "quick_qa", "name": "快速问答", "icon": "thunderbolt",
     "description": "提供快速问答功能，用户输入问题，直接检索回答"},
    {"type": "reasoning_action", "name": "推理行动", "icon": "bulb",
     "description": "提供react的多轮推理功能"},
    {"type": "planning_reasoning", "name": "规划推理", "icon": "partition",
     "description": "提供plan+react的智能规划、多轮推理功能"},
]


def upgrade() -> None:
    op.create_table(
        'agents',
        sa.Column('id', sa.String(length=36), nullable=False),
        sa.Column('type', sa.String(length=20), nullable=False, comment='智能体类型：quick_qa/reasoning_action/planning_reasoning，预置后不可变'),
        sa.Column('name', sa.String(length=100), nullable=False, comment='显示名称，跨智能体唯一'),
        sa.Column('icon', sa.String(length=50), nullable=False, comment='内置图标库 key'),
        sa.Column('description', sa.Text(), nullable=False, comment='描述'),
        sa.Column('status', sa.String(length=10), nullable=False, comment='启用状态：enabled/disabled'),
        sa.Column('config', JSONB(), nullable=False, comment='整份编辑配置（提示词/检索策略/模型/循环次数/工具）'),
        sa.Column('created_at', sa.TIMESTAMP(), nullable=False),
        sa.Column('updated_at', sa.TIMESTAMP(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('type', name='uq_agents_type'),
        sa.UniqueConstraint('name', name='uq_agents_name'),
        schema='knowledge_manage'
    )

    # 预置三条系统智能体（按 type 判存保证幂等，FR-014/FR-016）
    bind = op.get_bind()
    now = datetime.now(timezone.utc)
    for preset in PRESETS:
        exists = bind.execute(
            sa.text("SELECT 1 FROM knowledge_manage.agents WHERE type = :type"),
            {"type": preset["type"]},
        ).first()
        if exists:
            continue
        bind.execute(
            sa.text(
                "INSERT INTO knowledge_manage.agents "
                "(id, type, name, icon, description, status, config, created_at, updated_at) "
                "VALUES (:id, :type, :name, :icon, :description, 'enabled', CAST(:config AS jsonb), :now, :now)"
            ),
            {
                "id": str(uuid.uuid4()),
                "type": preset["type"],
                "name": preset["name"],
                "icon": preset["icon"],
                "description": preset["description"],
                "config": json.dumps(_default_config(preset["type"]), ensure_ascii=False),
                "now": now,
            },
        )


def downgrade() -> None:
    op.drop_table('agents', schema='knowledge_manage')