"""Add evaluation tables (014-knowledge-evaluation).

Revision ID: b7c8d9e0f1a2
Revises: f1a2b3c4d5e6
Create Date: 2026-11-24

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

# revision identifiers, used by Alembic.
revision: str = 'b7c8d9e0f1a2'
down_revision: Union[str, None] = 'f1a2b3c4d5e6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('evaluation_settings',
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('user_id', sa.String(length=36), nullable=False, comment='归属用户，每用户一行（upsert）'),
    sa.Column('analysis_model_id', sa.String(length=36), nullable=True, comment='网关对话模型 ID（逻辑引用，无跨 schema FK）'),
    sa.Column('recall_prompt_id', sa.String(length=36), nullable=True, comment='本人召回率提示词 ID'),
    sa.Column('accuracy_prompt_id', sa.String(length=36), nullable=True, comment='本人准确度提示词 ID'),
    sa.Column('created_at', sa.TIMESTAMP(), nullable=False),
    sa.Column('updated_at', sa.TIMESTAMP(), nullable=False),
    sa.PrimaryKeyConstraint('id'),
    schema='knowledge_manage'
    )
    op.create_index('uq_evaluation_settings_user', 'evaluation_settings', ['user_id'], unique=True, schema='knowledge_manage')

    op.create_table('evaluation_test_sets',
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('user_id', sa.String(length=36), nullable=False, comment='归属用户'),
    sa.Column('name', sa.String(length=100), nullable=False, comment='测试集名称，同一用户内唯一'),
    sa.Column('items', JSONB, nullable=False, comment='[{question, answer}]，1–500 项'),
    sa.Column('item_count', sa.Integer(), nullable=False, comment='冗余题数（=len(items)，便于列表展示）'),
    sa.Column('created_at', sa.TIMESTAMP(), nullable=False),
    sa.Column('updated_at', sa.TIMESTAMP(), nullable=False),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('user_id', 'name', name='uq_evaluation_test_sets_user_name'),
    schema='knowledge_manage'
    )
    op.create_index('idx_evaluation_test_sets_user', 'evaluation_test_sets', ['user_id'], unique=False, schema='knowledge_manage')

    op.create_table('evaluation_runs',
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('user_id', sa.String(length=36), nullable=False, comment='创建者，仅本人可见'),
    sa.Column('knowledge_base_ids', JSONB, nullable=False, comment='知识库 ID 列表（≥1）'),
    sa.Column('knowledge_base_names', JSONB, nullable=False, comment='名称快照列表（与 IDs 同序，决策19）'),
    sa.Column('agent_id', sa.String(length=36), nullable=False, comment='智能体 ID'),
    sa.Column('agent_name', sa.String(length=200), nullable=False, comment='智能体名称快照'),
    sa.Column('test_set_id', sa.String(length=36), nullable=False, comment='测试集 ID'),
    sa.Column('test_set_name', sa.String(length=100), nullable=False, comment='测试集名称快照'),
    sa.Column('status', sa.String(length=20), nullable=False, comment='running/completed/cancelled/failed'),
    sa.Column('total_items', sa.Integer(), nullable=False, comment='开跑时测试集题数'),
    sa.Column('completed_items', sa.Integer(), nullable=False, comment='已处理题数（含失败题）'),
    sa.Column('cancel_requested', sa.Boolean(), nullable=False, comment='题间取消标记（R6）'),
    sa.Column('error_message', sa.Text(), nullable=True, comment='任务级失败原因（服务重启中断/执行异常）'),
    sa.Column('started_at', sa.TIMESTAMP(), nullable=False, comment='列表开始时间'),
    sa.Column('finished_at', sa.TIMESTAMP(), nullable=True, comment='终态时间'),
    sa.Column('created_at', sa.TIMESTAMP(), nullable=False),
    sa.PrimaryKeyConstraint('id'),
    schema='knowledge_manage'
    )
    op.create_index('idx_evaluation_runs_user_created', 'evaluation_runs', ['user_id', sa.text('created_at DESC')], unique=False, schema='knowledge_manage')
    op.create_index('idx_evaluation_runs_status', 'evaluation_runs', ['status'], unique=False, schema='knowledge_manage')
    op.create_index('idx_evaluation_runs_test_set', 'evaluation_runs', ['test_set_id', 'status'], unique=False, schema='knowledge_manage')

    op.create_table('evaluation_items',
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=False, comment='所属评测任务，删除记录级联删明细（FR-033）'),
    sa.Column('seq', sa.Integer(), nullable=False, comment='题序（1 起），(run_id, seq) 唯一'),
    sa.Column('question', sa.Text(), nullable=False, comment='开跑时逐题快照（决策13）'),
    sa.Column('standard_answer', sa.Text(), nullable=False, comment='标准答案快照'),
    sa.Column('status', sa.String(length=20), nullable=False, comment='pending/success/failed'),
    sa.Column('agent_answer', sa.Text(), nullable=True, comment='agent 最终答案'),
    sa.Column('context', JSONB, nullable=True, comment='meta.references 快照（R3：file_name/content/score 等）'),
    sa.Column('recall', sa.Float(), nullable=True, comment='召回率 0–1，后端核算（R5）；失败置空'),
    sa.Column('accuracy', sa.Float(), nullable=True, comment='准确度 0–100，后端核算；失败置空'),
    sa.Column('recall_analysis', JSONB, nullable=True, comment='最终采纳的合法召回率 JSON（决策14）'),
    sa.Column('accuracy_analysis', JSONB, nullable=True, comment='最终采纳的合法准确度 JSON'),
    sa.Column('recall_raw_output', sa.Text(), nullable=True, comment='召回率评分失败时最后一次原始输出'),
    sa.Column('accuracy_raw_output', sa.Text(), nullable=True, comment='准确度评分失败时最后一次原始输出'),
    sa.Column('failure_reason', sa.Text(), nullable=True, comment='澄清原因/执行失败/评分重试耗尽/执行超时'),
    sa.Column('trace_id', sa.String(length=32), nullable=True, comment='该题根 span trace ID（决策21）'),
    sa.Column('created_at', sa.TIMESTAMP(), nullable=False, comment='trace 索引窗口基准（R11）'),
    sa.Column('completed_at', sa.TIMESTAMP(), nullable=True),
    sa.ForeignKeyConstraint(['run_id'], ['knowledge_manage.evaluation_runs.id'], ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('run_id', 'seq', name='uq_evaluation_items_run_seq'),
    schema='knowledge_manage'
    )
    op.create_index('idx_evaluation_items_run', 'evaluation_items', ['run_id', 'status'], unique=False, schema='knowledge_manage')


def downgrade() -> None:
    op.drop_index('idx_evaluation_items_run', table_name='evaluation_items', schema='knowledge_manage')
    op.drop_table('evaluation_items', schema='knowledge_manage')
    op.drop_index('idx_evaluation_runs_test_set', table_name='evaluation_runs', schema='knowledge_manage')
    op.drop_index('idx_evaluation_runs_status', table_name='evaluation_runs', schema='knowledge_manage')
    op.drop_index('idx_evaluation_runs_user_created', table_name='evaluation_runs', schema='knowledge_manage')
    op.drop_table('evaluation_runs', schema='knowledge_manage')
    op.drop_index('idx_evaluation_test_sets_user', table_name='evaluation_test_sets', schema='knowledge_manage')
    op.drop_table('evaluation_test_sets', schema='knowledge_manage')
    op.drop_index('uq_evaluation_settings_user', table_name='evaluation_settings', schema='knowledge_manage')
    op.drop_table('evaluation_settings', schema='knowledge_manage')