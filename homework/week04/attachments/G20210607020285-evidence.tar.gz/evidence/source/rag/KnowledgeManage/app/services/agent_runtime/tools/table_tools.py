"""表格工具（FR-026/027，SC-008，contracts/tool-runtime.md §4，research.md R15）.

- URL 白名单：仅接受本次请求检索片段出现过的 sqlite_url（ctx.sqlite_whitelist）；
- 下载：预签名 ≤50MB/≤30s，本地缓存 /tmp/km_sqlite_cache/{sha256(url)}.db TTL 1h 定期清理；
- SQL 双保险只读：① 剥注释后 SELECT 开头 + complete_statement 单语句 + 拒绝
  DDL/DML/ATTACH/写 PRAGMA → forbidden_sql；② 连接 file:...?mode=ro uri=True；
- 元数据 sqlite_master + PRAGMA table_info；查询结果 ≤500 行超出截断附说明。
"""
import asyncio
import hashlib
import json
import logging
import re
import sqlite3
import time
from pathlib import Path
from typing import List

import httpx
from pydantic import BaseModel, Field

from app.core.config import settings
from app.schemas.agent_runtime import ToolResult
from app.services import storage_service
from app.services.agent_runtime.state import RequestRuntimeState
from app.services.agent_runtime.tools.runtime import ToolFailure, ToolSpec

logger = logging.getLogger(__name__)

CACHE_DIR = Path("/tmp/km_sqlite_cache")

# 只读语句黑名单（词边界匹配；连接级 mode=ro 为第二道保险）
_FORBIDDEN_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|REPLACE|ATTACH|DETACH|PRAGMA|VACUUM|REINDEX|TRUNCATE)\b",
    re.IGNORECASE,
)
_LINE_COMMENT = re.compile(r"--[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)


def _ok(payload: dict) -> ToolResult:
    return ToolResult(success=True, code="ok", content=json.dumps(payload, ensure_ascii=False))


def _check_whitelist(ctx: RequestRuntimeState, url: str) -> None:
    if url not in ctx.sqlite_whitelist:
        raise ToolFailure("url_not_allowed", f"sqlite_url 不在本次请求检索片段白名单内：{url}")


def _cache_path(url: str) -> Path:
    return CACHE_DIR / f"{hashlib.sha256(url.encode('utf-8')).hexdigest()}.db"


def _cleanup_cache() -> None:
    """定期清理过期缓存（TTL 1h）；失败仅记日志不影响主流程."""
    ttl = settings.agent_runtime.sqlite_cache_ttl
    now = time.time()
    try:
        if not CACHE_DIR.exists():
            return
        for f in CACHE_DIR.glob("*.db"):
            try:
                if now - f.stat().st_mtime > ttl:
                    f.unlink()
            except OSError:
                continue
    except OSError:
        logger.warning("sqlite cache cleanup failed", exc_info=True)


async def _ensure_local_file(url: str) -> Path:
    """缓存命中复用；否则预签名下载（≤50MB/≤30s）落盘缓存."""
    path = _cache_path(url)
    ttl = settings.agent_runtime.sqlite_cache_ttl
    if path.exists() and time.time() - path.stat().st_mtime <= ttl:
        return path
    _cleanup_cache()
    download_url = url if url.startswith(("http://", "https://")) else storage_service.get_presigned_url(url)
    max_bytes = settings.agent_runtime.sqlite_max_bytes
    timeout = settings.agent_runtime.sqlite_download_timeout
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(".part")
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("GET", download_url) as resp:
                resp.raise_for_status()
                length = resp.headers.get("content-length")
                if length and int(length) > max_bytes:
                    raise ToolFailure("execution_failed", f"sqlite 文件超过大小上限 {max_bytes} 字节")
                size = 0
                with open(tmp_path, "wb") as f:
                    async for piece in resp.aiter_bytes():
                        size += len(piece)
                        if size > max_bytes:
                            raise ToolFailure("execution_failed", f"sqlite 文件超过大小上限 {max_bytes} 字节")
                        f.write(piece)
        tmp_path.replace(path)
        return path
    finally:
        tmp_path.unlink(missing_ok=True)


def _connect_ro(path: Path) -> sqlite3.Connection:
    """连接级只读（双保险之二）：写操作在引擎层必然失败."""
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True)


def _validate_sql(sql: str) -> str:
    """语句级只读校验（双保险之一）；返回规范化后的单条 SELECT."""
    stripped = _BLOCK_COMMENT.sub(" ", sql or "")
    stripped = _LINE_COMMENT.sub(" ", stripped).strip()
    if not stripped.upper().startswith("SELECT"):
        raise ToolFailure("forbidden_sql", "仅允许 SELECT 查询语句")
    if not sqlite3.complete_statement(stripped if stripped.endswith(";") else stripped + ";"):
        raise ToolFailure("forbidden_sql", "SQL 语句不完整")
    core = stripped.rstrip(";").strip()
    if ";" in core:
        raise ToolFailure("forbidden_sql", "仅允许单条语句，禁止多语句执行")
    if _FORBIDDEN_KEYWORDS.search(core):
        raise ToolFailure("forbidden_sql", "语句包含禁止的写操作/DDL/ATTACH/PRAGMA 关键字")
    return core


def _read_metadata(path: Path) -> List[dict]:
    conn = _connect_ro(path)
    try:
        names = [
            row[0] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
        ]
        tables = []
        for name in names:
            columns = [
                {"name": row[1], "type": row[2]}
                for row in conn.execute(f'PRAGMA table_info("{name}")')
            ]
            tables.append({"name": name, "description": "", "columns": columns})
        return tables
    finally:
        conn.close()


def _run_query(path: Path, sql: str) -> dict:
    max_rows = settings.agent_runtime.sql_max_rows
    conn = _connect_ro(path)
    try:
        cur = conn.execute(sql)
        columns = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchmany(max_rows + 1)
        truncated = len(rows) > max_rows
        rows = [list(r) for r in rows[:max_rows]]
        payload = {"columns": columns, "rows": rows, "row_count": len(rows)}
        if truncated:
            payload["truncated"] = True
            payload["note"] = f"结果已截断，最多返回 {max_rows} 行"
        return payload
    finally:
        conn.close()


# ---- 入参模型 ----

class ListTableMetaDataArgs(BaseModel):
    sqlite_url: str = Field(..., min_length=1)


class SqlExecuteArgs(BaseModel):
    sqlite_url: str = Field(..., min_length=1)
    sql_query: str = Field(..., min_length=1)


# ---- 处理器 ----

async def _list_table_metadata(args: ListTableMetaDataArgs, ctx: RequestRuntimeState) -> ToolResult:
    _check_whitelist(ctx, args.sqlite_url)
    path = await _ensure_local_file(args.sqlite_url)
    tables = await asyncio.to_thread(_read_metadata, path)
    return _ok({"tables": tables})


async def _sql_execute(args: SqlExecuteArgs, ctx: RequestRuntimeState) -> ToolResult:
    _check_whitelist(ctx, args.sqlite_url)
    sql = _validate_sql(args.sql_query)  # 校验先于下载，注入语句零开销拒绝
    path = await _ensure_local_file(args.sqlite_url)
    try:
        payload = await asyncio.to_thread(_run_query, path, sql)
    except sqlite3.Error as e:
        raise RuntimeError(f"SQL 执行失败：{e}") from e  # 交由 runtime 重试→execution_failed
    return _ok(payload)


TOOLS = [
    ToolSpec(
        "listTableMetaData",
        "查看表格片段的 sqlite 表结构（表名/列名/类型）；sqlite_url 限本次检索片段中出现过的地址",
        ListTableMetaDataArgs, _list_table_metadata,
    ),
    ToolSpec(
        "sqlExecute",
        "对表格片段的 sqlite 库执行只读 SELECT 统计查询（单语句，最多返回 500 行）",
        SqlExecuteArgs, _sql_execute,
    ),
]