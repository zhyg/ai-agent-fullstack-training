"""Store archive images as durable attachments of their Markdown document."""

import hashlib
import logging
import mimetypes
import posixpath
import uuid
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit

from fastapi import HTTPException
from sqlalchemy import exists, select
from starlette.concurrency import run_in_threadpool

from app.core.database import SessionLocal
from app.models.archive_image import ArchiveImage, ArchiveImageReference
from app.services import document_status, storage_service
from app.services.markdown_preview import rewrite_image_urls

_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".jp2", ".tif", ".tiff", ".avif"}
logger = logging.getLogger(__name__)


def _relative_image_path(target: str) -> str | None:
    try:
        url = urlsplit(target)
    except ValueError:
        return None
    path = unquote(url.path)
    if url.scheme or url.netloc or not path or path.startswith("/") or "\\" in path or "\0" in path:
        return None
    path = posixpath.normpath(path)
    return path if PurePosixPath(path).suffix.lower() in _IMAGE_SUFFIXES else None


def _object_key(prefix: str, relative_path: str) -> str:
    digest = hashlib.sha256(relative_path.encode("utf-8")).hexdigest()
    return f"{prefix}{digest}{PurePosixPath(relative_path).suffix.lower()}"


def find_archive_images(markdown: str, source: Path, archive_root: Path, members: set[Path]) -> dict[str, Path]:
    root = archive_root.resolve()
    images: dict[str, Path] = {}

    def collect(target: str) -> str:
        relative = _relative_image_path(target)
        if relative is not None:
            image = (source.parent / relative).resolve()
            if image.is_relative_to(root) and image in members:
                images[relative] = image
        return target

    rewrite_image_urls(markdown, collect)
    return images


def store_shared_image(db, prefix: str, root: Path, image: Path) -> str:
    relative = image.relative_to(root).as_posix()
    key = _object_key(prefix, relative)
    with image.open("rb") as stream:
        storage_service.upload_file(
            object_path=key, data=stream, length=image.stat().st_size,
            content_type=mimetypes.guess_type(relative)[0] or "application/octet-stream",
        )
    db.add(ArchiveImage(key=key, kb_id=prefix.split("/", 1)[0]))
    return key


def link_image(db, doc_id: str, relative: str, key: str) -> None:
    db.add(ArchiveImageReference(
        document_id=doc_id, path_hash=hashlib.sha256(relative.encode("utf-8")).hexdigest(), image_key=key,
    ))


def shared_assets(db, doc_id: str) -> dict[str, str]:
    return dict(db.execute(select(ArchiveImageReference.path_hash, ArchiveImageReference.image_key)
                           .where(ArchiveImageReference.document_id == doc_id)).all())


def image_keys_for_documents(db, doc_ids: list[str]) -> set[str]:
    if not doc_ids:
        return set()
    return set(db.scalars(select(ArchiveImageReference.image_key)
                          .where(ArchiveImageReference.document_id.in_(doc_ids))))


def remove_unreferenced_images(db, keys: set[str]) -> list[str]:
    if not keys:
        return []
    locked = list(db.scalars(select(ArchiveImage).where(ArchiveImage.key.in_(keys))
                             .order_by(ArchiveImage.key).with_for_update()))
    removed = []
    for image in locked:
        if not db.scalar(select(exists().where(ArchiveImageReference.image_key == image.key))):
            db.delete(image)
            removed.append(image.key)
    return removed


def cleanup_removed_images(keys: list[str]) -> None:
    for key in keys:
        try:
            storage_service.delete_object(key)
        except HTTPException:
            logger.exception("Could not remove shared archive image %s", key)


def _read_analysis(key: str) -> tuple[bool, dict[str, str]]:
    with SessionLocal() as db:
        image = db.get(ArchiveImage, key)
        return (True, image.analysis or {}) if image else (False, {})


def _save_analysis(key: str, analysis: dict[str, str]) -> None:
    with SessionLocal() as db:
        image = db.get(ArchiveImage, key, with_for_update=True)
        if image is not None:
            image.analysis = analysis
            db.commit()


async def analyze_shared_image(key: str, image_model_id: str) -> None:
    from app.services.image_service import process_image_caption, process_image_ocr

    redis = document_status.redis_pool
    if redis is None:
        raise RuntimeError("Shared image analysis requires Redis")
    async with redis.lock(f"knowledge:archive-image:{key}", timeout=900, blocking_timeout=900):
        exists, analysis = await run_in_threadpool(_read_analysis, key)
        if not exists or {"image_ocr", "image_caption"} <= analysis.keys():
            return
        image = await run_in_threadpool(storage_service.download_file, key)
        filename = PurePosixPath(key).name
        for kind, analyze, args in (
            ("image_ocr", process_image_ocr, (image, filename)),
            ("image_caption", process_image_caption, (image, filename, image_model_id)),
        ):
            if kind in analysis:
                continue
            try:
                analysis[kind] = await analyze(*args)
            except RuntimeError as exc:
                logger.warning("Shared image %s failed for %s: %s", kind, key, exc)
                continue
            await run_in_threadpool(_save_analysis, key, analysis)


def shared_children(db, parent: dict, keys: set[str]) -> list[dict]:
    urls = parent.get("image_url") or []
    urls = [urls] if isinstance(urls, str) else urls
    requested = keys.intersection(urls)
    if not requested:
        return []
    result = []
    for image in db.scalars(select(ArchiveImage).where(ArchiveImage.key.in_(requested)).order_by(ArchiveImage.key)):
        for chunk_type, content in (image.analysis or {}).items():
            if not content:
                continue
            result.append({
                "chunk_id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"{image.key}:{chunk_type}")),
                "document_id": parent["document_id"],
                "parent_chunk_id": parent["chunk_id"],
                "chunk_type": chunk_type,
                "content": content,
                "image_url": image.key,
                "chunk_index": len(result),
            })
    return result


def resolve_archive_images(
    markdown: str, kb_id: str, doc_id: str, *, signed: bool = False, assets: dict[str, str] | None = None,
) -> tuple[str, list[str]]:
    prefix = f"{kb_id}/{doc_id}/attachments/"
    objects: set[str] | None = None
    matched: dict[str, str] = {}

    def resolve(target: str) -> str:
        nonlocal objects
        relative = _relative_image_path(target)
        if relative is None:
            return target
        key = (assets or {}).get(hashlib.sha256(relative.encode("utf-8")).hexdigest())
        if key is None:
            if objects is None:
                objects = storage_service.list_object_keys(prefix)
            key = _object_key(prefix, relative)
            if key not in objects:
                return target
        if key not in matched:
            matched[key] = sign_image(key) if signed else key
        return matched[key]

    return rewrite_image_urls(markdown, resolve), list(matched)


def sign_image(key: str) -> str:
    if "/archive-images/" in key:
        return storage_service.get_shared_image_url(key)
    return storage_service.get_presigned_url(key, expires=3600)
