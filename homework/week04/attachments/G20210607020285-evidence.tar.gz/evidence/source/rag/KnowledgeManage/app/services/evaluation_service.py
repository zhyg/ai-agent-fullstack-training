"""评测数据与规则服务（014-knowledge-evaluation）。

契约来源: specs/014-knowledge-evaluation/contracts/evaluation-api.md。
职责（research R6/R8/R12/R13）:
- US1（T013）: 设置 upsert / 测试集 CRUD，running 锁定（409），全部查询按 user_id 隔离
- US2（T024）: create_run 全量预检 + 并发检查 + ID/名称快照 + 逐题预建 pending 行；
  cancel_run（DB 标记 + 进程内 Event）；recover_interrupted_runs（重启 running→failed）
- US3（T030）: list_runs 平均分实时聚合（仅 success 题）、get_run_detail、delete_run
- US4（T036）: 题目 trace 归属校验与过期判定（复用 trace_query_service）
"""
import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.models.agent import Agent
from app.models.evaluation_item import EvaluationItem
from app.models.evaluation_run import EvaluationRun
from app.models.evaluation_setting import EvaluationSetting
from app.models.evaluation_test_set import EvaluationTestSet
from app.models.knowledge_base import KnowledgeBase
from app.models.prompt import Prompt
from app.schemas.evaluation import RunCreate, SettingsUpdate
from app.services import evaluation_runner
from app.services.agent_runtime import llm_client

logger = logging.getLogger(__name__)


class EvaluationLockedError(Exception):
    """运行中锁定/并发冲突（FR-009/012/033，决策24）：router 映射 409。"""


class EvaluationPrecheckError(Exception):
    """开跑前全量预检失败（FR-011）：reasons 一次性列出全部失效项，router 映射 400。"""

    def __init__(self, reasons):
        self.reasons = reasons
        super().__init__("；".join(reasons))


class TestSetNameConflictError(Exception):
    """测试集名称同一用户内唯一（FR-005）：router 映射 409。"""

    __test__ = False  # 避免 pytest 误收集 Test 前缀类


# ---------------------------------------------------------------------------
# 评测设置（US1，FR-002~004/009）
# ---------------------------------------------------------------------------

def get_settings(db: Session, user_id: str):
    return (
        db.query(EvaluationSetting)
        .filter(EvaluationSetting.user_id == user_id)
        .first()
    )


def upsert_settings(db: Session, user_id: str, data: SettingsUpdate):
    # 锁定：本人存在 running 任务时禁止保存（FR-009）
    running = (
        db.query(EvaluationRun)
        .filter(EvaluationRun.user_id == user_id, EvaluationRun.status == "running")
        .first()
    )
    if running:
        raise EvaluationLockedError("评测进行中，设置已锁定")
    # 提示词归属校验：仅本人（FR-003）；模型存在性由开跑前预检拦截（FR-011）
    for prompt_id in (data.recall_prompt_id, data.accuracy_prompt_id):
        if prompt_id:
            prompt = (
                db.query(Prompt)
                .filter(Prompt.id == prompt_id, Prompt.creator_id == user_id)
                .first()
            )
            if not prompt:
                raise ValueError("提示词不存在或非本人所有")
    setting = get_settings(db, user_id)
    if setting is None:
        setting = EvaluationSetting(user_id=user_id, **data.model_dump())
        db.add(setting)
    else:
        for key, value in data.model_dump().items():
            setattr(setting, key, value)
    db.commit()
    return setting


# ---------------------------------------------------------------------------
# 测试集（US1，FR-005~009）
# ---------------------------------------------------------------------------

def list_test_sets(db: Session, user_id: str):
    return (
        db.query(EvaluationTestSet)
        .filter(EvaluationTestSet.user_id == user_id)
        .order_by(EvaluationTestSet.created_at.desc())
        .all()
    )


def get_test_set(db: Session, user_id: str, test_set_id: str):
    return (
        db.query(EvaluationTestSet)
        .filter(EvaluationTestSet.id == test_set_id, EvaluationTestSet.user_id == user_id)
        .first()
    )


def _ensure_test_set_not_locked(db: Session, test_set_id: str):
    running = (
        db.query(EvaluationRun)
        .filter(EvaluationRun.test_set_id == test_set_id, EvaluationRun.status == "running")
        .first()
    )
    if running:
        raise EvaluationLockedError("评测进行中，测试集已锁定")


def create_test_set(db: Session, user_id: str, name: str, items: list):
    duplicate = (
        db.query(EvaluationTestSet)
        .filter(EvaluationTestSet.user_id == user_id, EvaluationTestSet.name == name)
        .first()
    )
    if duplicate:
        raise TestSetNameConflictError(f"测试集名称 '{name}' 已存在")
    test_set = EvaluationTestSet(
        user_id=user_id, name=name, items=items, item_count=len(items)
    )
    db.add(test_set)
    db.commit()
    return test_set


def reupload_test_set(db: Session, user_id: str, test_set_id: str, items: list):
    """重新上传覆盖（决策13）：名称/ID 不变，历史评测逐题快照不受影响。"""
    test_set = get_test_set(db, user_id, test_set_id)
    if test_set is None:
        return None
    _ensure_test_set_not_locked(db, test_set_id)
    test_set.items = items
    test_set.item_count = len(items)
    db.commit()
    return test_set


def delete_test_set(db: Session, user_id: str, test_set_id: str):
    test_set = get_test_set(db, user_id, test_set_id)
    if test_set is None:
        return None
    _ensure_test_set_not_locked(db, test_set_id)
    db.delete(test_set)
    db.commit()
    return True


# ---------------------------------------------------------------------------
# 评测任务（US2，FR-010~020，T024）
# ---------------------------------------------------------------------------

def get_run(db: Session, user_id: str, run_id: str):
    """按归属查任务（跨用户一律视同不存在，契约 Auth 约定）。"""
    return (
        db.query(EvaluationRun)
        .filter(EvaluationRun.id == run_id, EvaluationRun.user_id == user_id)
        .first()
    )


def create_run(db: Session, user_id: str, data: RunCreate):
    """全量预检（FR-011）→并发检查（FR-012）→ID+名称快照→逐题预建 pending→启动执行器。"""
    reasons = []

    setting = get_settings(db, user_id)
    if setting is None or not setting.analysis_model_id:
        reasons.append("缺少分析模型配置")
    else:
        info = llm_client.resolve_model(setting.analysis_model_id)
        if info is None:
            reasons.append(f"分析模型不存在或已删除（{setting.analysis_model_id}）")
        elif info["category"] != "chat":
            reasons.append("分析模型不是对话模型")

    for prompt_id, label in (
        (getattr(setting, "recall_prompt_id", None), "召回率提示词"),
        (getattr(setting, "accuracy_prompt_id", None), "准确度提示词"),
    ):
        if not prompt_id:
            reasons.append(f"缺少{label}配置")
            continue
        prompt = db.query(Prompt).filter(Prompt.id == prompt_id).first()
        if prompt is None:
            reasons.append(f"{label}不存在或已删除（{prompt_id}）")
        elif prompt.creator_id != user_id:
            reasons.append(f"{label}非本人所有（{prompt_id}）")

    agent = db.query(Agent).filter(Agent.id == data.agent_id).first()
    if agent is None:
        reasons.append(f"智能体不存在或已删除（{data.agent_id}）")
    elif agent.status != "enabled":
        reasons.append(f"智能体「{agent.name}」已停用")

    kbs = []
    if not data.knowledge_base_ids:
        reasons.append("未选择知识库")
    for kb_id in data.knowledge_base_ids:
        kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
        if kb is None:
            reasons.append(f"知识库不存在或已删除（{kb_id}）")
        elif kb.user_id != user_id:
            reasons.append(f"知识库不属于当前用户（{kb_id}）")
        else:
            kbs.append(kb)

    test_set = get_test_set(db, user_id, data.test_set_id)
    if test_set is None:
        reasons.append(f"测试集不存在或非本人（{data.test_set_id}）")

    if reasons:
        raise EvaluationPrecheckError(reasons)

    running = (
        db.query(EvaluationRun)
        .filter(EvaluationRun.user_id == user_id, EvaluationRun.status == "running")
        .first()
    )
    if running:
        raise EvaluationLockedError("已有进行中的评测任务，请等待完成或先取消")

    run = EvaluationRun(
        user_id=user_id,
        knowledge_base_ids=list(data.knowledge_base_ids),
        knowledge_base_names=[kb.name for kb in kbs],
        agent_id=agent.id,
        agent_name=agent.name,
        test_set_id=test_set.id,
        test_set_name=test_set.name,
        status="running",
        total_items=len(test_set.items),
        completed_items=0,
    )
    db.add(run)
    db.flush()  # 取 run.id 供明细 FK
    for seq, item in enumerate(test_set.items, start=1):
        db.add(EvaluationItem(
            run_id=run.id, seq=seq,
            question=item["question"], standard_answer=item["answer"],
            status="pending",
        ))
    db.commit()
    evaluation_runner.start_run(run.id)
    return run


def cancel_run(db: Session, user_id: str, run_id: str):
    """题间取消（FR-017）：写 DB 标记 + set 进程内 Event；终态 409，不存在/非本人 None。"""
    run = get_run(db, user_id, run_id)
    if run is None:
        return None
    if run.status != "running":
        raise EvaluationLockedError("任务已结束，无法取消")
    run.cancel_requested = True
    db.commit()
    evaluation_runner.request_cancel(run_id)
    return run


def recover_interrupted_runs():
    """启动容错（FR-018，SC-006）：running 统一标 failed，已完成题目保留可查。"""
    db = SessionLocal()
    try:
        updated = (
            db.query(EvaluationRun)
            .filter(EvaluationRun.status == "running")
            .update(
                {
                    "status": "failed",
                    "error_message": "服务重启中断",
                    "finished_at": datetime.now(timezone.utc),
                },
                synchronize_session=False,
            )
        )
        db.commit()
        if updated:
            logger.info("Recovered %d interrupted evaluation runs", updated)
    finally:
        db.close()


def delete_run(db: Session, user_id: str, run_id: str):
    """删除记录（FR-033）：running 409 须先取消；FK CASCADE 级联删明细。"""
    run = get_run(db, user_id, run_id)
    if run is None:
        return None
    if run.status == "running":
        raise EvaluationLockedError("评测进行中，请先取消后再删除")
    db.delete(run)
    db.commit()
    return True


# ---------------------------------------------------------------------------
# 评测结果（US3，FR-028~033，T030）
# ---------------------------------------------------------------------------

def _avg_of_items(items):
    """平均分口径（R13/FR-030）：仅 status='success' 题参与，无成功题返回 (None, None)。"""
    success = [i for i in items if i.status == "success"]
    if not success:
        return None, None
    return (
        sum(i.recall for i in success) / len(success),
        sum(i.accuracy for i in success) / len(success),
    )


def list_runs(db: Session, user_id: str, page: int = 1, page_size: int = 20):
    """历史列表（FR-028/029）：created_at 倒序分页；平均分实时聚合不冗余存储。

    聚合实现：单次列投影查询取本页 run 的 (run_id, status, recall, accuracy)，
    进程内仅对 success 行求均（与 AVG FILTER WHERE status='success' 口径等价）。
    """
    q = (
        db.query(EvaluationRun)
        .filter(EvaluationRun.user_id == user_id)
        .order_by(EvaluationRun.created_at.desc())
    )
    total = q.count()
    runs = q.offset((page - 1) * page_size).limit(page_size).all()

    grouped = {}
    if runs:
        rows = (
            db.query(
                EvaluationItem.run_id, EvaluationItem.status,
                EvaluationItem.recall, EvaluationItem.accuracy,
            )
            .filter(EvaluationItem.run_id.in_([r.id for r in runs]))
            .all()
        )
        for run_id, status, recall, accuracy in rows:
            if status == "success":
                grouped.setdefault(run_id, []).append((recall, accuracy))

    items = []
    for run in runs:
        scores = grouped.get(run.id)
        items.append({
            "id": run.id,
            "started_at": run.started_at,
            "knowledge_base_names": run.knowledge_base_names,
            "agent_name": run.agent_name,
            "test_set_name": run.test_set_name,
            "avg_recall": sum(r for r, _ in scores) / len(scores) if scores else None,
            "avg_accuracy": sum(a for _, a in scores) / len(scores) if scores else None,
            "status": run.status,
            "total_items": run.total_items,
            "completed_items": run.completed_items,
        })
    return items, total


def get_run_detail(db: Session, user_id: str, run_id: str):
    """详情（FR-031/032）：逐题快照按 seq 升序全字段；资产删除后名称快照照常展示。"""
    run = get_run(db, user_id, run_id)
    if run is None:
        return None
    items = (
        db.query(EvaluationItem)
        .filter(EvaluationItem.run_id == run_id)
        .order_by(EvaluationItem.seq.asc())
        .all()
    )
    avg_recall, avg_accuracy = _avg_of_items(items)
    return {
        "id": run.id,
        "status": run.status,
        "started_at": run.started_at,
        "finished_at": run.finished_at,
        "knowledge_base_ids": run.knowledge_base_ids,
        "knowledge_base_names": run.knowledge_base_names,
        "agent_id": run.agent_id,
        "agent_name": run.agent_name,
        "test_set_id": run.test_set_id,
        "test_set_name": run.test_set_name,
        "total_items": run.total_items,
        "completed_items": run.completed_items,
        "avg_recall": avg_recall,
        "avg_accuracy": avg_accuracy,
        "error_message": run.error_message,
        "items": [
            {
                "id": item.id,
                "seq": item.seq,
                "question": item.question,
                "standard_answer": item.standard_answer,
                "status": item.status,
                "agent_answer": item.agent_answer,
                "context": item.context,
                "recall": item.recall,
                "accuracy": item.accuracy,
                "recall_analysis": item.recall_analysis,
                "accuracy_analysis": item.accuracy_analysis,
                "recall_raw_output": item.recall_raw_output,
                "accuracy_raw_output": item.accuracy_raw_output,
                "failure_reason": item.failure_reason,
                "trace_id": item.trace_id,
            }
            for item in items
        ],
    }