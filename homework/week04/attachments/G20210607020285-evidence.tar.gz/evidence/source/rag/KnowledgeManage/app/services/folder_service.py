"""Folder CRUD service."""

import uuid
import logging
from datetime import datetime, timezone
from typing import List, Optional, Tuple

from sqlalchemy.orm import Session

from app.models.folder import Folder
from app.models.document import Document
from app.schemas.folder import FolderCreate, FolderUpdate, FolderMoveRequest
from app.services import markdown_attachments, storage_service

logger = logging.getLogger(__name__)


def _verify_kb_ownership(db: Session, kb_id: str, user_id: str) -> bool:
    """Verify the knowledge base exists and belongs to the user."""
    from app.models.knowledge_base import KnowledgeBase
    return db.query(KnowledgeBase).filter(
        KnowledgeBase.id == kb_id, KnowledgeBase.user_id == user_id
    ).first() is not None


def list_folders(db: Session, kb_id: str, user_id: str) -> List[Folder]:
    """List all folders for a knowledge base, ordered by parent_id and order."""
    if not _verify_kb_ownership(db, kb_id, user_id):
        raise ValueError("知识库不存在或无权访问")
    return (
        db.query(Folder)
        .filter(Folder.kb_id == kb_id)
        .order_by(Folder.parent_id.nullsfirst(), Folder.order)
        .all()
    )


def create_folder(
    db: Session, kb_id: str, user_id: str, data: FolderCreate
) -> Folder:
    """Create a new folder. Raises ValueError on same-name conflict."""
    if not _verify_kb_ownership(db, kb_id, user_id):
        raise ValueError("知识库不存在或无权访问")

    # Validate parent exists and belongs to the same kb
    if data.parent_id is not None:
        parent = db.query(Folder).filter(
            Folder.id == data.parent_id, Folder.kb_id == kb_id
        ).first()
        if not parent:
            raise ValueError("父目录不存在")

    # Same-name check under the same parent
    existing = (
        db.query(Folder)
        .filter(
            Folder.kb_id == kb_id,
            Folder.parent_id == data.parent_id,
            Folder.name == data.name,
        )
        .first()
    )
    if existing:
        raise ValueError(f"同一目录下已存在名为 \"{data.name}\" 的目录")

    # Calculate order: max sibling order + 1
    max_order = (
        db.query(Folder)
        .filter(Folder.kb_id == kb_id, Folder.parent_id == data.parent_id)
        .count()
    )

    folder = Folder(
        id=str(uuid.uuid4()),
        name=data.name,
        kb_id=kb_id,
        parent_id=data.parent_id,
        order=max_order,
    )
    db.add(folder)
    db.commit()
    db.refresh(folder)
    return folder


def update_folder(
    db: Session, folder_id: str, user_id: str, data: FolderUpdate
) -> Folder:
    """Update folder name/parent/order. Raises ValueError on conflict."""
    folder = db.query(Folder).filter(Folder.id == folder_id).first()
    if not folder:
        raise ValueError("目录不存在")
    if not _verify_kb_ownership(db, folder.kb_id, user_id):
        raise ValueError("无权访问")

    # Name change — check uniqueness under same parent
    if data.name is not None and data.name != folder.name:
        conflict = (
            db.query(Folder)
            .filter(
                Folder.kb_id == folder.kb_id,
                Folder.parent_id == folder.parent_id,
                Folder.name == data.name,
                Folder.id != folder_id,
            )
            .first()
        )
        if conflict:
            raise ValueError(f"同一目录下已存在名为 \"{data.name}\" 的目录")
        folder.name = data.name

    # Parent change — validate no self-descendant move
    if data.parent_id is not None and data.parent_id != folder.parent_id:
        if _is_descendant(db, folder.id, data.parent_id):
            raise ValueError("不能将目录移动到自身或其子孙目录下")
        folder.parent_id = data.parent_id

    if data.order is not None:
        folder.order = data.order

    folder.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(folder)
    return folder


def delete_folder(
    db: Session, folder_id: str, user_id: str
) -> dict:
    """Delete a folder and all descendants + documents.

    Returns deletion counts and deleted_docs list for async ES/MinIO cleanup.
    """
    folder = db.query(Folder).filter(Folder.id == folder_id).first()
    if not folder:
        raise ValueError("目录不存在")
    if not _verify_kb_ownership(db, folder.kb_id, user_id):
        raise ValueError("无权访问")

    # Collect all descendant folder IDs (including self)
    all_folder_ids = _collect_descendant_ids(db, folder.id)

    # Collect all documents under those folders
    docs = db.query(Document).filter(Document.folder_id.in_(all_folder_ids)).all()
    deleted_doc_count = len(docs)

    # Collect (kb_id, doc_id) pairs for async ES cleanup
    deleted_docs = [(doc.kb_id, doc.id) for doc in docs]
    image_keys = markdown_attachments.image_keys_for_documents(db, [doc.id for doc in docs])

    # Delete MinIO objects for each document
    for doc in docs:
        try:
            storage_service.delete_object(doc.storage_path)
        except Exception as e:
            logger.warning("Failed to delete MinIO object %s: %s", doc.storage_path, e)

    # Delete documents from DB
    db.query(Document).filter(Document.folder_id.in_(all_folder_ids)).delete(
        synchronize_session=False
    )

    # Delete folders from DB
    deleted_folder_count = len(all_folder_ids)
    db.query(Folder).filter(Folder.id.in_(all_folder_ids)).delete(
        synchronize_session=False
    )

    removed_images = markdown_attachments.remove_unreferenced_images(db, image_keys)
    db.commit()
    markdown_attachments.cleanup_removed_images(removed_images)
    return {
        "deleted_folders": deleted_folder_count,
        "deleted_documents": deleted_doc_count,
        "deleted_docs": deleted_docs,
    }


def move_folder(
    db: Session, folder_id: str, user_id: str, data: FolderMoveRequest
) -> dict:
    """Move folder to a new position. Handles auto-rename on conflict."""
    folder = db.query(Folder).filter(Folder.id == folder_id).first()
    if not folder:
        raise ValueError("目录不存在")
    if not _verify_kb_ownership(db, folder.kb_id, user_id):
        raise ValueError("无权访问")

    # Validate no self-descendant move
    if data.target_parent_id is not None:
        if _is_descendant(db, folder.id, data.target_parent_id):
            raise ValueError("不能将目录移动到自身或其子孙目录下")

    renamed = False
    original_name = None

    # Check same-name conflict at target location
    if data.target_parent_id != folder.parent_id or True:
        conflict = (
            db.query(Folder)
            .filter(
                Folder.kb_id == folder.kb_id,
                Folder.parent_id == data.target_parent_id,
                Folder.name == folder.name,
                Folder.id != folder_id,
            )
            .first()
        )
        if conflict:
            if data.auto_rename:
                original_name = folder.name
                folder.name = _generate_unique_name(
                    db, folder.kb_id, data.target_parent_id, folder.name, folder_id
                )
                renamed = True
            else:
                raise ValueError(f"目标位置已存在名为 \"{folder.name}\" 的目录")

    # Update parent
    folder.parent_id = data.target_parent_id

    # Recalculate order for siblings at target
    siblings = (
        db.query(Folder)
        .filter(
            Folder.kb_id == folder.kb_id,
            Folder.parent_id == data.target_parent_id,
            Folder.id != folder_id,
        )
        .order_by(Folder.order)
        .all()
    )

    # Insert at target_index
    insert_idx = min(data.target_index, len(siblings))
    reordered = siblings[:insert_idx] + [folder] + siblings[insert_idx:]
    for idx, f in enumerate(reordered):
        f.order = idx

    folder.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(folder)

    return {"folder": folder, "renamed": renamed, "original_name": original_name}


# ─── Helpers ────────────────────────────────────────────────────────


def _is_descendant(db: Session, ancestor_id: str, target_id: str) -> bool:
    """Check if target_id is a descendant of ancestor_id."""
    if ancestor_id == target_id:
        return True
    current_id = target_id
    visited = set()
    while current_id:
        if current_id in visited:
            break
        visited.add(current_id)
        if current_id == ancestor_id:
            return True
        parent = db.query(Folder.parent_id).filter(Folder.id == current_id).scalar()
        current_id = parent
    return False


def _collect_descendant_ids(db: Session, folder_id: str) -> List[str]:
    """Recursively collect all descendant folder IDs including self."""
    result = [folder_id]
    children = db.query(Folder.id).filter(Folder.parent_id == folder_id).all()
    for (child_id,) in children:
        result.extend(_collect_descendant_ids(db, child_id))
    return result


def _generate_unique_name(
    db: Session, kb_id: str, parent_id: Optional[str], base_name: str, exclude_id: str
) -> str:
    """Generate a unique folder name by appending (2), (3), etc."""
    for suffix in range(2, 100):
        candidate = f"{base_name} ({suffix})"
        exists = (
            db.query(Folder)
            .filter(
                Folder.kb_id == kb_id,
                Folder.parent_id == parent_id,
                Folder.name == candidate,
                Folder.id != exclude_id,
            )
            .first()
        )
        if not exists:
            return candidate
    raise ValueError("无法生成唯一目录名称")
