import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, TIMESTAMP, Index, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB

from app.core.database import Base
from app.core.config import settings


class EvaluationTestSet(Base):
    __tablename__ = "evaluation_test_sets"
    __table_args__ = (
        UniqueConstraint("user_id", "name", name="uq_evaluation_test_sets_user_name"),
        Index("idx_evaluation_test_sets_user", "user_id"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), nullable=False, comment="归属用户")
    name = Column(String(100), nullable=False, comment="测试集名称，同一用户内唯一")
    items = Column(JSONB, nullable=False, comment="[{question, answer}]，1–500 项")
    item_count = Column(Integer, nullable=False, comment="冗余题数（=len(items)，便于列表展示）")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )