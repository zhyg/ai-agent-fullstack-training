import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, TIMESTAMP, Index
from sqlalchemy.dialects.postgresql import JSONB

from app.core.database import Base
from app.core.config import settings


class Chat(Base):
    __tablename__ = "chats"
    __table_args__ = (
        Index("idx_chats_user", "user_id"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(200), nullable=False, comment="会话标题")
    user_id = Column(String(36), nullable=False, comment="所属用户 ID")
    model_id = Column(String(36), nullable=True, comment="当前使用的模型 ID")
    model_name = Column(String(200), nullable=True, comment="模型显示名称")
    prompt_id = Column(String(36), nullable=True, comment="当前使用的提示词 ID")
    agent_id = Column(String(36), nullable=True, comment="智能体 ID；非空表示智能体模式")
    agent_type = Column(String(30), nullable=True, comment="智能体类型快照: quick_qa/reasoning_action/planning_reasoning")
    knowledge_base_ids = Column(JSONB, nullable=True, comment="智能体模式绑定的知识库 ID 列表")
    status = Column(
        String(20), nullable=False, default="idle",
        comment="会话状态: idle/generating/completed/cancelled"
    )
    generation_id = Column(String(36), nullable=True, comment="当前生成任务 ID")
    lease_owner = Column(String(36), nullable=True, comment="生成任务持有实例 ID")
    lease_expires_at = Column(TIMESTAMP(timezone=True), nullable=True, comment="生成任务租约过期时间")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )
