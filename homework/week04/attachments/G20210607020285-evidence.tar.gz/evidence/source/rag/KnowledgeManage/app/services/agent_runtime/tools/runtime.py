"""统一受控 Tool Runtime（FR-029/030，contracts/tool-runtime.md §1，research.md R14）.

- execute_tool: 取消检查→Pydantic 入参校验（invalid_args 不抛异常）→执行（内部重试
  最多 3 次，含首次共 4 次调用）→content 超 tool_result_max_tokens 截断附说明；
- 结果信封 ToolResult{success, code, content, artifact_path?}，失败/空结果回传模型继续决策；
- 每次执行包 agent.tool.{name} span（start_as_current_span，工具内步骤 span 为其子级），
  tool.call_id 从模型输出→执行→tool result 消息→trace 全程透传；
- 串行执行由流程侧保证（一轮决策内多个 tool_calls 按序逐个调用本入口）；
- 未启用工具不进入模型 tools 列表（build_tool_declarations 按快照启用清单过滤）。
"""
import json
import logging
from dataclasses import dataclass
from typing import Awaitable, Callable, Dict, List, Optional, Type

from pydantic import BaseModel, ValidationError

from app.core.config import settings
from app.schemas.agent_runtime import ToolResult
from app.services.agent_runtime import budget, tracing
from app.services.agent_runtime.llm_client import AgentCancelled, ModelUnavailableError
from app.services.agent_runtime.state import RequestRuntimeState

logger = logging.getLogger(__name__)

# 执行异常内部重试上限：最多重试 3 次（含首次共 4 次调用）
MAX_TOOL_RETRIES = 3


class ToolFailure(Exception):
    """工具内受控失败（语义校验不通过等）：直接返回对应结果码，不重试."""

    def __init__(self, code: str, content: str):
        self.code = code
        self.content = content
        super().__init__(f"{code}: {content}")


@dataclass
class ToolSpec:
    """工具注册项：入参 Pydantic 模型 + 异步处理器 + 模型侧中文用途说明."""
    name: str
    description: str
    args_model: Type[BaseModel]
    handler: Callable[[BaseModel, RequestRuntimeState], Awaitable[ToolResult]]


_registry: Optional[Dict[str, ToolSpec]] = None


def _get_registry() -> Dict[str, ToolSpec]:
    """惰性聚合三组工具（避免模块级循环导入）；键与 schemas/agent.py::TOOL_KEYS 一致."""
    global _registry
    if _registry is None:
        from app.services.agent_runtime.tools import knowledge_tools, plan_tools, table_tools
        merged: Dict[str, ToolSpec] = {}
        for module in (plan_tools, knowledge_tools, table_tools):
            for spec in module.TOOLS:
                merged[spec.name] = spec
        _registry = merged
    return _registry


def build_tool_declarations(enabled_tools: List[str]) -> List[dict]:
    """启用工具 → OpenAI function calling 声明（未启用对模型不可见，FR-023）."""
    registry = _get_registry()
    declarations = []
    for name in enabled_tools:
        spec = registry.get(name)
        if spec is None:
            continue
        declarations.append({
            "type": "function",
            "function": {
                "name": spec.name,
                "description": spec.description,
                "parameters": spec.args_model.model_json_schema(),
            },
        })
    return declarations


def _item_count(content: str) -> int:
    """截断说明中的"共 N 条"：JSON 内容取首个列表长度，否则取原始 token 数."""
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            for value in parsed.values():
                if isinstance(value, list):
                    return len(value)
        elif isinstance(parsed, list):
            return len(parsed)
    except (ValueError, TypeError):
        pass
    return budget.count_tokens(content)


def _truncate(content: str) -> str:
    """content 超 tool_result_max_tokens（默认 4000）按 token 截断并附说明."""
    limit = settings.agent_runtime.tool_result_max_tokens
    encoding = budget._get_encoding()
    tokens = encoding.encode(content)
    if len(tokens) <= limit:
        return content
    total = _item_count(content)
    kept = encoding.decode(tokens[:limit])
    return f"{kept}\n[结果已截断，共 {total} 条]"


def _envelope(success: bool, code: str, content: str) -> ToolResult:
    return ToolResult(success=success, code=code, content=content)


async def execute_tool(
    call_id: str,
    tool_name: str,
    args: Optional[dict],
    ctx: RequestRuntimeState,
) -> ToolResult:
    """统一执行入口：任何失败都以信封回传（不抛异常），仅取消信号上抛终止流程."""
    tracer = tracing.get_tracer()
    with tracer.start_as_current_span(f"agent.tool.{tool_name}") as span:
        span.set_attribute(tracing.ATTR_TOOL_CALL_ID, call_id)
        if ctx.loop:
            span.set_attribute(tracing.ATTR_LOOP, ctx.loop)
        tracing.set_input(span, {"tool": tool_name, "args": args})
        result = await _execute(call_id, tool_name, args, ctx, span)
        tracing.set_output(span, result.model_dump())
        return result


async def _execute(
    call_id: str,
    tool_name: str,
    args: Optional[dict],
    ctx: RequestRuntimeState,
    span,
) -> ToolResult:
    # 1. 取消检查：已置位不执行（FR-031）
    if ctx.cancel_event is not None and ctx.cancel_event.is_set():
        return _envelope(False, "cancelled", "生成已停止，工具未执行")

    # 2. 工具存在且启用（未启用工具正常情况下对模型不可见，此处兜底）
    spec = _get_registry().get(tool_name)
    if spec is None or tool_name not in ctx.snapshot.tools:
        return _envelope(False, "invalid_args", f"工具不存在或未启用：{tool_name}")

    # 3. 入参校验：失败直接返回 invalid_args，不抛异常、不重试（非 dict 入参同样拒绝）
    if args is not None and not isinstance(args, dict):
        return _envelope(False, "invalid_args", "入参必须为 JSON 对象")
    try:
        parsed = spec.args_model.model_validate(args if args is not None else {})
    except ValidationError as e:
        return _envelope(False, "invalid_args", f"入参校验失败：{str(e)[:500]}")

    # 4. 执行：内部异常最多重试 3 次（含首次共 4 次）；受控失败不重试
    last_error = ""
    for attempt in range(MAX_TOOL_RETRIES + 1):
        if ctx.cancel_event is not None and ctx.cancel_event.is_set():
            raise AgentCancelled()
        try:
            result = await spec.handler(parsed, ctx)
            result.content = _truncate(result.content)
            return result
        except ToolFailure as f:
            return _envelope(False, f.code, f.content)
        except AgentCancelled:
            raise  # 执行中命中取消：上抛终止流程（部分答案由入口落库）
        except ModelUnavailableError:
            raise  # 网关重试后仍不可用：流程级异常（FR-012），不在工具内降级
        except Exception as e:
            last_error = str(e)
            logger.warning(
                "Tool execution failed tool=%s call_id=%s attempt=%d: %s",
                tool_name, call_id, attempt + 1, last_error,
            )
            tracing.add_event(span, "tool_execution_retry", {
                "tool": tool_name, "attempt": attempt + 1, "error": last_error,
            })
    return _envelope(False, "execution_failed", f"工具执行失败（已重试 {MAX_TOOL_RETRIES} 次）：{last_error[:500]}")