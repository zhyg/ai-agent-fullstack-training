"""Parsing service — MinerU document conversion and image extraction."""

import base64
import io
import os
import re
import uuid
import logging
import tempfile
from typing import Dict, Any, List, Optional, Tuple

import httpx

from app.core.config import settings
from app.services import markdown_attachments, storage_service

logger = logging.getLogger(__name__)

# Image extensions
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".jp2", ".webp", ".gif", ".bmp"}

# Document extensions that need MinerU conversion
MINERU_EXTENSIONS = {".doc", ".docx", ".ppt", ".pptx", ".pdf"}

# Markdown extensions
MARKDOWN_EXTENSIONS = {".md", ".markdown"}

# MIME types for MinerU upload
_MIME_TYPES = {
    ".pdf": "application/pdf",
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".ppt": "application/vnd.ms-powerpoint",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".xls": "application/vnd.ms-excel",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".bmp": "image/bmp",
    ".webp": "image/webp",
    ".tiff": "image/tiff",
}


def get_mineru_url() -> str:
    """Get MinerU service URL from config."""
    return settings.services.get("mineru", "http://localhost:8000")


def build_mineru_parse_form() -> dict[str, str]:
    return {
        "backend": "hybrid-engine",
        "effort": "high",
        "image_analysis": "true",
        "return_md": "true",
        "return_middle_json": "false",
        "return_images": "true",
        "formula_enable": "true",
        "table_enable": "true",
    }


async def parse_document(
    file_bytes: bytes,
    filename: str,
    extension: str,
    kb_id: str,
    doc_id: str,
    *,
    archive_assets: dict[str, str] | None = None,
) -> Dict[str, Any]:
    """Parse a document using MinerU and return structured result.

    Returns:
        {
            "markdown_text": str,
            "md_path": str,  # MinIO path of converted markdown
            "images": [{"local_path": str, "minio_url": str}],
            "tables": [...],
        }
    """
    ext = extension.lower()
    # Normalize: ensure dot prefix for comparison
    if not ext.startswith("."):
        ext = f".{ext}"

    if ext in MARKDOWN_EXTENSIONS:
        return await _parse_markdown(file_bytes, filename, kb_id, doc_id, archive_assets=archive_assets)
    elif ext in MINERU_EXTENSIONS:
        return await _parse_with_mineru(file_bytes, filename, kb_id, doc_id)
    else:
        raise ValueError(f"Unsupported file type for parsing: {ext}")


async def _parse_markdown(
    file_bytes: bytes,
    filename: str,
    kb_id: str,
    doc_id: str,
    *,
    archive_assets: dict[str, str] | None = None,
) -> Dict[str, Any]:
    """Store parsed Markdown with references to its uploaded attachments."""
    md_text = file_bytes.decode("utf-8", errors="replace")

    md_text, image_keys = markdown_attachments.resolve_archive_images(md_text, kb_id, doc_id, assets=archive_assets)

    # Upload the markdown to MinIO
    md_filename = f"{filename}.md" if not filename.endswith(".md") else filename
    md_path = f"{kb_id}/{doc_id}/markdown/{md_filename}"
    md_bytes = md_text.encode("utf-8")
    storage_service.upload_file(
        object_path=md_path,
        data=io.BytesIO(md_bytes),
        length=len(md_bytes),
        content_type="text/markdown",
    )

    return {
        "markdown_text": md_text,
        "md_path": md_path,
        "images": [{"minio_path": key} for key in image_keys],
        "tables": [],
    }


async def _parse_with_mineru(
    file_bytes: bytes,
    filename: str,
    kb_id: str,
    doc_id: str,
) -> Dict[str, Any]:
    """Parse document using MinerU /file_parse API.

    IMPORTANT: Must explicitly pass formula_enable=true and table_enable=true
    in form data, otherwise MinerU may skip table/formula parsing.
    """
    mineru_url = get_mineru_url()

    # Determine MIME type
    ext = os.path.splitext(filename)[1].lower()
    mime_type = _MIME_TYPES.get(ext, "application/octet-stream")

    try:
        async with httpx.AsyncClient(timeout=300) as client:
            # Build multipart form data — "files" is an array field,
            # so we must use list-of-tuples (not dict) for httpx.
            files = [("files", (filename, file_bytes, mime_type))]
            resp = await client.post(
                f"{mineru_url}/file_parse",
                files=files,
                data=build_mineru_parse_form(),
            )
            resp.raise_for_status()
    except httpx.HTTPError as e:
        logger.error("MinerU API call failed: %s", e)
        raise RuntimeError(f"文档解析服务不可用: {e}") from e

    # Parse MinerU response
    result_data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}

    # Extract markdown text from various possible response structures
    md_text = _extract_md_from_response(result_data)
    if not md_text:
        # Fallback: treat response as plain text
        md_text = resp.text

    # Extract images from MinerU response (base64 encoded)
    mineru_images = _extract_images_from_response(result_data)

    # Upload images to MinIO and replace local paths in markdown with MinIO object paths.
    # We store MinIO object paths (not presigned URLs) so content never expires.
    # Presigned URLs are generated on-the-fly when serving to the frontend.
    images = []
    # Build lookup: local_variant -> minio_path for regex-based replacement
    _variant_map: dict[str, str] = {}
    for img_name, img_bytes in mineru_images.items():
        # Flatten to basename — MinerU may return keys with path prefix (e.g. "images/xxx.png")
        img_basename = os.path.basename(img_name)
        minio_path = f"{kb_id}/{doc_id}/images/{img_basename}"
        storage_service.upload_file(
            object_path=minio_path,
            data=io.BytesIO(img_bytes),
            length=len(img_bytes),
            content_type="image/jpeg" if img_basename.lower().endswith((".jpg", ".jpeg")) else "image/png",
        )
        images.append({
            "local_variants": [
                f"images/{img_basename}",
                f"./images/{img_basename}",
                img_name,  # original key from MinerU response
                img_basename,  # bare filename
            ],
            "minio_path": minio_path,
        })
        for v in (f"images/{img_basename}", f"./images/{img_basename}", img_name, img_basename):
            if v:
                _variant_map[v] = minio_path

    # Replace local image paths inside markdown image syntax ![](path) only.
    # Using regex ensures we never accidentally match bare filenames in prose text
    # or corrupt already-replaced paths.
    _img_md_pattern = re.compile(r"(!\[[^\]]*\])\(([^)]+)\)")
    # Sort variants longest-first so more specific paths match before shorter ones
    _sorted_variants = sorted(_variant_map.keys(), key=len, reverse=True)

    def _replace_md_img(match):
        prefix = match.group(1)  # ![alt]
        img_path = match.group(2)  # the path inside (...)
        for variant in _sorted_variants:
            if img_path == variant:
                return f"{prefix}({_variant_map[variant]})"
        return match.group(0)  # no match, leave unchanged

    md_text = _img_md_pattern.sub(_replace_md_img, md_text)

    # Upload converted markdown to MinIO
    md_filename = f"{os.path.splitext(filename)[0]}.md"
    md_path = f"{kb_id}/{doc_id}/markdown/{md_filename}"
    md_bytes = md_text.encode("utf-8")
    storage_service.upload_file(
        object_path=md_path,
        data=io.BytesIO(md_bytes),
        length=len(md_bytes),
        content_type="text/markdown",
    )

    return {
        "markdown_text": md_text,
        "md_path": md_path,
        "images": images,
        "tables": [],
    }


def _extract_images_from_response(result_data: dict) -> Dict[str, bytes]:
    """Decode MinerU images returned as bare Base64 or image data URIs.

    Returns: {image_filename: image_bytes}
    """
    images = {}
    if not isinstance(result_data, dict):
        return images

    results = result_data.get("results")
    if isinstance(results, dict):
        for _name, file_data in results.items():
            if isinstance(file_data, dict):
                img_dict = file_data.get("images")
                if isinstance(img_dict, dict):
                    for img_name, payload in img_dict.items():
                        try:
                            if not isinstance(payload, str):
                                raise ValueError("Expected an image string")
                            if payload.startswith("data:"):
                                header, separator, payload = payload.partition(",")
                                if not separator or not re.fullmatch(
                                    r"data:image/[\w.+-]+;base64", header
                                ):
                                    raise ValueError("Invalid image data URI")
                            img_bytes = base64.b64decode(payload, validate=True)
                            if not img_bytes:
                                raise ValueError("Empty image payload")
                            images[img_name] = img_bytes
                        except ValueError as e:
                            logger.warning(
                                "Failed to decode base64 image %s: %s",
                                img_name, e,
                            )

    return images


async def upload_image_to_minio(
    image_bytes: bytes,
    image_name: str,
    kb_id: str,
    doc_id: str,
) -> str:
    """Upload an image to MinIO and return the MinIO path."""
    minio_path = f"{kb_id}/{doc_id}/images/{image_name}"
    storage_service.upload_file(
        object_path=minio_path,
        data=io.BytesIO(image_bytes),
        length=len(image_bytes),
        content_type="image/png",
    )
    return minio_path


def get_presigned_url(object_path: str, expires: int = 3600) -> str:
    """Generate a presigned URL for a MinIO object."""
    return storage_service.get_presigned_url(object_path, expires=expires)


def is_document_type(extension: str) -> bool:
    """Check if extension is a document type that needs MinerU parsing."""
    return f".{extension.lower()}" in MINERU_EXTENSIONS


def is_markdown_type(extension: str) -> bool:
    """Check if extension is a markdown type."""
    return f".{extension.lower()}" in MARKDOWN_EXTENSIONS


def is_image_type(extension: str) -> bool:
    """Check if extension is an image type."""
    return f".{extension.lower()}" in IMAGE_EXTENSIONS


def _extract_md_from_response(result_data: Any) -> str:
    """Extract markdown text from MinerU response data.

    Handles multiple response structures:
    - Top-level: {"md_content": "..."}
    - Nested results dict: {"results": {"filename": {"md_content": "..."}}}
    - Nested results list: {"results": [{"md_content": "..."}]}
    """
    if not isinstance(result_data, dict):
        return ""

    # 1. Check nested "results" structure (MinerU v2)
    results = result_data.get("results")
    if isinstance(results, dict):
        parts = []
        for _name, file_data in results.items():
            if isinstance(file_data, dict):
                md = (
                    file_data.get("md_content", "")
                    or file_data.get("md", "")
                    or file_data.get("markdown", "")
                )
                if md:
                    parts.append(md)
        if parts:
            return "\n\n".join(parts)

    if isinstance(results, list):
        parts = []
        for item in results:
            if isinstance(item, dict):
                md = (
                    item.get("md_content", "")
                    or item.get("md", "")
                    or item.get("markdown", "")
                )
                if md:
                    parts.append(md)
        if parts:
            return "\n\n".join(parts)

    # 2. Top-level keys
    for key in ("md_content", "content", "markdown", "text"):
        val = result_data.get(key, "")
        if val:
            return val

    return ""


def is_spreadsheet_type(extension: str) -> bool:
    """Check if extension is a spreadsheet type."""
    return f".{extension.lower()}" in {".xls", ".xlsx", ".csv"}
