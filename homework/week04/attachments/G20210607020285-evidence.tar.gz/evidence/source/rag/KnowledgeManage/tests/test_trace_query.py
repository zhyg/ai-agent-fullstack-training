"""Trace 查询代理单测（T048，FR-036，contracts/trace-api.md）：归属校验 / 索引容错 / 格式转换 / pending / no_trace / 503."""
import contextlib
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from elasticsearch import TransportError
from fastapi import HTTPException

from app.routers import chats
from app.services import trace_query_service


def make_doc(span_id, *, parent=None, start=1000, process=None, logs=None, tags=None):
    return {
        "traceID": "t" * 32,
        "spanID": span_id,
        "operationName": f"agent.step.{span_id}",
        "references": [{"refType": "CHILD_OF", "spanID": parent}] if parent else [],
        "startTime": start,
        "duration": 500,
        "tags": tags or [],
        "logs": logs or [],
        "process": process or {"serviceName": "knowledge-manage-agent", "tags": []},
    }


class SpanIndicesTests(unittest.TestCase):
    def test_naive_utc_date_builds_three_indices(self):
        self.assertEqual(
            trace_query_service.span_indices(datetime(2026, 11, 23, 10, 0)),
            ["jaeger-span-2026-11-22", "jaeger-span-2026-11-23", "jaeger-span-2026-11-24"],
        )

    def test_aware_datetime_converted_to_utc_before_date(self):
        # +08:00 的 11-23 02:00 → UTC 11-22，索引以 UTC 日期为中心
        created = datetime(2026, 11, 23, 2, 0, tzinfo=timezone(timedelta(hours=8)))
        self.assertEqual(
            trace_query_service.span_indices(created),
            ["jaeger-span-2026-11-21", "jaeger-span-2026-11-22", "jaeger-span-2026-11-23"],
        )

    def test_month_boundary(self):
        self.assertEqual(
            trace_query_service.span_indices(datetime(2026, 12, 1)),
            ["jaeger-span-2026-11-30", "jaeger-span-2026-12-01", "jaeger-span-2026-12-02"],
        )


class ConvertSpansTests(unittest.TestCase):
    def test_process_dedup_and_child_of_normalization(self):
        docs = [
            make_doc("child", parent="root", start=2000),
            make_doc("root", start=1000),
            make_doc("other", start=3000, process={"serviceName": "another-service", "tags": []}),
        ]
        trace = trace_query_service.convert_spans(docs)
        self.assertEqual(trace["traceID"], "t" * 32)
        # 按 startTime 排序：root 在前
        self.assertEqual([s["spanID"] for s in trace["spans"]], ["root", "child", "other"])
        # 相同 process 去重为 p1，不同 process 分配 p2
        self.assertEqual(trace["spans"][0]["processID"], "p1")
        self.assertEqual(trace["spans"][1]["processID"], "p1")
        self.assertEqual(trace["spans"][2]["processID"], "p2")
        self.assertEqual(set(trace["processes"]), {"p1", "p2"})
        self.assertEqual(trace["processes"]["p1"]["serviceName"], "knowledge-manage-agent")
        # CHILD_OF 引用补齐 traceID
        ref = trace["spans"][1]["references"][0]
        self.assertEqual(ref, {"refType": "CHILD_OF", "traceID": "t" * 32, "spanID": "root"})
        self.assertEqual(trace["spans"][0]["references"], [])

    def test_tags_logs_preserved_without_masking(self):
        tags = [
            {"key": "agent.input", "type": "string", "value": '{"prompt": "完整提示词"}'},
            {"key": "agent.output", "type": "string", "value": '{"content": "原始输出"}'},
            {"key": "tool.call_id", "type": "string", "value": "call_abc"},
            {"key": "agent.loop", "type": "int64", "value": "2"},
        ]
        logs = [{"timestamp": 1500, "fields": [{"key": "event", "type": "string", "value": "rerank_degraded"}]}]
        trace = trace_query_service.convert_spans([make_doc("s1", tags=tags, logs=logs)])
        span = trace["spans"][0]
        self.assertEqual(span["tags"], tags)  # 不脱敏，原样透传
        self.assertEqual(span["logs"], logs)
        self.assertEqual(span["startTimeMillis"], 1)  # 缺失时由 startTime//1000 兜底

    def test_missing_ref_type_defaults_child_of(self):
        doc = make_doc("s2", parent="s1")
        doc["references"] = [{"spanID": "s1"}]
        trace = trace_query_service.convert_spans([doc])
        self.assertEqual(trace["spans"][0]["references"][0]["refType"], "CHILD_OF")


class FetchTraceTests(unittest.IsolatedAsyncioTestCase):
    async def test_empty_hits_returns_pending(self):
        client = MagicMock()
        client.search = AsyncMock(return_value={"hits": {"hits": []}})
        with patch.object(trace_query_service, "get_async_client", new=AsyncMock(return_value=client)):
            result = await trace_query_service.fetch_trace("t" * 32, datetime(2026, 11, 23))
        self.assertEqual(result, {"ready": False, "reason": "pending"})
        kwargs = client.search.call_args.kwargs
        self.assertEqual(kwargs["index"], "jaeger-span-2026-11-22,jaeger-span-2026-11-23,jaeger-span-2026-11-24")
        self.assertEqual(kwargs["query"], {"term": {"traceID": "t" * 32}})
        self.assertEqual(kwargs["size"], 10000)
        self.assertTrue(kwargs["ignore_unavailable"])

    async def test_hits_converted_to_jaeger_ui_format(self):
        client = MagicMock()
        client.search = AsyncMock(return_value={"hits": {"hits": [
            {"_source": make_doc("root", start=1000)},
            {"_source": make_doc("child", parent="root", start=2000)},
        ]}})
        with patch.object(trace_query_service, "get_async_client", new=AsyncMock(return_value=client)):
            result = await trace_query_service.fetch_trace("t" * 32, datetime(2026, 11, 23))
        self.assertTrue(result["ready"])
        self.assertEqual(len(result["data"]), 1)
        self.assertEqual(len(result["data"][0]["spans"]), 2)
        self.assertIn("p1", result["data"][0]["processes"])


class TraceRouterTests(unittest.IsolatedAsyncioTestCase):
    def _message(self, trace_id="t" * 32):
        return SimpleNamespace(
            id="m1", chat_id="c1", trace_id=trace_id,
            created_at=datetime(2026, 11, 23, 10, 0),
        )

    async def _call(self, *, chat, message, fetch=None):
        db = MagicMock()
        db.query.return_value.filter.return_value.first.return_value = message
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(chats.chat_service, "get_chat", return_value=chat))
            if fetch is not None:
                stack.enter_context(patch.object(chats.trace_query_service, "fetch_trace", new=fetch))
            return await chats.get_message_trace(
                "c1", "m1", current_user={"id": "u1"}, db=db,
            )

    async def test_cross_user_returns_403(self):
        with self.assertRaises(HTTPException) as ctx:
            await self._call(chat=None, message=self._message())
        self.assertEqual(ctx.exception.status_code, 403)
        self.assertEqual(ctx.exception.detail, "无权查看该消息的轨迹")

    async def test_message_not_found_returns_404(self):
        with self.assertRaises(HTTPException) as ctx:
            await self._call(chat=SimpleNamespace(id="c1"), message=None)
        self.assertEqual(ctx.exception.status_code, 404)

    async def test_no_trace_id_returns_no_trace(self):
        fetch = AsyncMock()
        result = await self._call(chat=SimpleNamespace(id="c1"), message=self._message(trace_id=None), fetch=fetch)
        self.assertEqual(result, {"ready": False, "reason": "no_trace"})
        fetch.assert_not_awaited()

    async def test_success_passes_through_unmasked(self):
        payload = {"ready": True, "data": [trace_query_service.convert_spans([
            make_doc("root", tags=[{"key": "agent.input", "type": "string", "value": "完整提示词"}]),
        ])]}
        fetch = AsyncMock(return_value=payload)
        message = self._message()
        result = await self._call(chat=SimpleNamespace(id="c1"), message=message, fetch=fetch)
        self.assertEqual(result, payload)  # 不脱敏原样透传
        fetch.assert_awaited_once_with("t" * 32, message.created_at)

    async def test_es_unavailable_returns_503(self):
        fetch = AsyncMock(side_effect=TransportError("connection refused"))
        with self.assertRaises(HTTPException) as ctx:
            await self._call(chat=SimpleNamespace(id="c1"), message=self._message(), fetch=fetch)
        self.assertEqual(ctx.exception.status_code, 503)
        self.assertEqual(ctx.exception.detail, "轨迹服务暂不可用")


if __name__ == "__main__":
    unittest.main()