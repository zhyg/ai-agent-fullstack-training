import logging
from typing import Optional, List

from sqlalchemy.orm import Session

from app.models.agent import Agent
from app.models.prompt import Prompt
from app.schemas.agent import (
    AgentConfig,
    AgentUpdate,
    AGENT_TYPES,
    PROMPT_PURPOSES_BY_TYPE,
    TOOL_KEYS,
    required_prompt_purposes,
)

logger = logging.getLogger(__name__)

VALID_STATUSES = ("enabled", "disabled")


class NameConflictError(Exception):
    """智能体名称与其他智能体重复（FR-018，路由层转 409）。"""


def list_agents(db: Session) -> List[Agent]:
    """列出全部智能体（含停用），按类型固定顺序：快速问答→推理行动→规划推理。"""
    order = {t: i for i, t in enumerate(AGENT_TYPES)}
    agents = db.query(Agent).all()
    return sorted(agents, key=lambda a: order.get(a.type, len(order)))


def get_agent(db: Session, agent_id: str) -> Optional[Agent]:
    """按 ID 获取智能体，不存在返回 None。"""
    return db.query(Agent).filter(Agent.id == agent_id).first()


def config_incomplete_reasons(db: Session, agent: Agent) -> List[str]:
    """配置完整性检查（FR-002，与运行期快照预检同口径，不含知识库）.

    返回缺失/失效项文案列表；空列表即配置完整。供会话绑定校验与列表置灰。
    """
    from app.services.agent_runtime import llm_client

    reasons: List[str] = []
    config = AgentConfig.model_validate(agent.config or {})
    tools = config.tools if config.tools is not None else (
        list(TOOL_KEYS) if agent.type == "planning_reasoning" else []
    )
    for purpose in required_prompt_purposes(agent.type, tools):
        prompt_id = getattr(config.prompts, purpose, None)
        if not prompt_id:
            reasons.append(f"缺少{purpose}提示词配置")
        elif db.query(Prompt).filter(Prompt.id == prompt_id).first() is None:
            reasons.append(f"{purpose}提示词不存在或已删除")

    analysis_info = None
    if not config.models.analysis_model_id:
        reasons.append("缺少分析模型配置")
    else:
        analysis_info = llm_client.resolve_model(config.models.analysis_model_id)
        if analysis_info is None:
            reasons.append("分析模型不存在或已删除")
    if not config.models.embedding_model_id:
        reasons.append("缺少向量模型配置")
    elif llm_client.resolve_model(config.models.embedding_model_id) is None:
        reasons.append("向量模型不存在或已删除")
    rerank_required = agent.type != "planning_reasoning" or "rerank" in tools
    if config.models.rerank_model_id:
        if llm_client.resolve_model(config.models.rerank_model_id) is None:
            reasons.append("ReRank 模型不存在或已删除")
    elif rerank_required:
        reasons.append("缺少 ReRank 模型配置")

    if analysis_info is not None and config.models.max_output_tokens >= analysis_info["context_tokens"]:
        reasons.append(
            f"最大输出 Token 数（{config.models.max_output_tokens}）"
            f"必须小于分析模型上下文窗口（{analysis_info['context_tokens']}）"
        )
    return reasons


def set_status(db: Session, agent_id: str, status: str) -> Optional[Agent]:
    """停用/启用：仅变更 status，不触碰 config；同状态重复请求幂等。

    智能体不存在返回 None；status 非枚举值抛 ValueError。
    """
    if status not in VALID_STATUSES:
        raise ValueError(f"非法状态值: {status}，仅支持 enabled/disabled")
    agent = get_agent(db, agent_id)
    if agent is None:
        return None
    if agent.status != status:
        agent.status = status
        db.commit()
        db.refresh(agent)
        logger.info("Agent %s status changed to %s", agent_id, status)
    return agent


def update_agent(db: Session, agent_id: str, data: AgentUpdate) -> Optional[Agent]:
    """整份更新基础信息 + config（弹窗“保存”）。

    - name 跨智能体唯一：预检重名抛 NameConflictError，DB unique 约束兑底
    - 按 type 裁剪 config（忽略未知键/不属于该类型的字段）
    - 必填用途 prompt_id 存在性校验（不存在/失效抛 ValueError → 400）
    - 条件必填：分析模型必填；向量模型在 mode∈{vector,hybrid} 时必填（规划推理无 mode，恒必填）；ReRank 必填
    - 不修改 status/type；last-write-wins 无冲突检测
    智能体不存在返回 None。
    """
    agent = get_agent(db, agent_id)
    if agent is None:
        return None

    if data.name != agent.name:
        conflict = (
            db.query(Agent)
            .filter(Agent.name == data.name, Agent.id != agent_id)
            .first()
        )
        if conflict is not None:
            raise NameConflictError("智能体名称已存在")

    cfg = data.config.model_dump()

    # 按类型裁剪提示词用途
    purposes = PROMPT_PURPOSES_BY_TYPE[agent.type]
    prompts = {p: cfg["prompts"].get(p) for p in purposes}
    required = required_prompt_purposes(agent.type, cfg.get("tools"))
    for purpose in required:
        prompt_id = prompts.get(purpose)
        if not prompt_id:
            raise ValueError(f"提示词用途 {purpose} 为必填项，请选择有效提示词")
        exists = db.query(Prompt).filter(Prompt.id == prompt_id).first()
        if exists is None:
            raise ValueError(f"提示词用途 {purpose} 引用的提示词已失效，请重新选择")
    cfg["prompts"] = prompts

    # 模型条件必填
    models = cfg["models"]
    if not models.get("analysis_model_id"):
        raise ValueError("分析模型为必填项")
    if not models.get("rerank_model_id"):
        raise ValueError("ReRank 模型为必填项")
    # 规划推理无检索方式配置，向量模型恒必填；其余类型按检索方式条件必填
    if agent.type == "planning_reasoning":
        if not models.get("embedding_model_id"):
            raise ValueError("向量模型为必填项")
    elif cfg["retrieval"]["mode"] in ("vector", "hybrid") and not models.get("embedding_model_id"):
        raise ValueError("当前检索方式下向量模型为必填项")

    # FR-020：max_output_tokens < 分析模型 context_tokens（跨 schema 查网关模型）
    from app.services.agent_runtime import llm_client

    analysis_info = llm_client.resolve_model(models["analysis_model_id"])
    if analysis_info is None:
        raise ValueError("分析模型不存在或已删除，请重新选择")
    if models["max_output_tokens"] >= analysis_info["context_tokens"]:
        raise ValueError(
            f"最大输出 Token 数（{models['max_output_tokens']}）"
            f"必须小于分析模型上下文窗口（{analysis_info['context_tokens']}）"
        )

    # 按类型裁剪 loop_count/tools（history_retrieval 三类均保留，缺省由 Pydantic 默认值落库，013 决策8）
    if agent.type == "quick_qa":
        cfg.pop("loop_count", None)
        cfg.pop("tools", None)
    elif agent.type == "reasoning_action":
        cfg.pop("tools", None)
        if cfg.get("loop_count") is None:
            cfg["loop_count"] = 10
    else:  # planning_reasoning
        cfg["retrieval"].pop("mode", None)  # 规划推理不保留检索方式，三个召回数量均可配置
        if cfg.get("loop_count") is None:
            cfg["loop_count"] = 100
        if cfg.get("tools") is None:
            cfg["tools"] = list(TOOL_KEYS)

    agent.name = data.name
    agent.icon = data.icon
    agent.description = data.description
    agent.config = cfg
    db.commit()
    db.refresh(agent)
    logger.info("Agent %s config updated", agent_id)
    return agent