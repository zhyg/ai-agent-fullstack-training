import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, TIMESTAMP, Index

from app.core.database import Base
from app.core.config import settings


class EvaluationSetting(Base):
    __tablename__ = "evaluation_settings"
    __table_args__ = (
        Index("uq_evaluation_settings_user", "user_id", unique=True),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), nullable=False, comment="归属用户，每用户一行（upsert）")
    analysis_model_id = Column(String(36), nullable=True, comment="网关对话模型 ID（逻辑引用，无跨 schema FK）")
    recall_prompt_id = Column(String(36), nullable=True, comment="本人召回率提示词 ID")
    accuracy_prompt_id = Column(String(36), nullable=True, comment="本人准确度提示词 ID")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )