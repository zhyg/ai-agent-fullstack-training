import logging
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import init_schema
from app.core.config import settings
from app.core import es_client
from app.routers import prompts, chats, knowledge_bases, folders, documents, chunks, agents, evaluations, consumption, document_status as status_router
from app.services.chat_service import set_redis_pool
from app.services import chat_service, document_status, evaluation_runner, evaluation_service

logging.basicConfig(
    level=settings.logging.level,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown lifecycle."""
    logger.info("Initializing KnowledgeManage service...")
    init_schema()

    # 评测重启容错（014 FR-018/SC-006）：running 统一标 failed，已完成题目保留
    evaluation_service.recover_interrupted_runs()

    # Initialize Redis connection pool
    redis_pool = aioredis.Redis(
        host=settings.redis.host,
        port=settings.redis.port,
        db=settings.redis.db,
        password="[REDACTED]"
        decode_responses=True,
    )
    set_redis_pool(redis_pool)
    app.state.redis = redis_pool
    document_status.redis_pool = redis_pool
    logger.info("Redis connection pool initialized")

    # Initialize Elasticsearch async client
    await es_client.get_async_client()
    logger.info("Elasticsearch async client initialized")

    logger.info("KnowledgeManage service started")
    yield

    # Gracefully finish any active generation jobs
    await chat_service.finish_generations()

    # 评测执行器收尾（014 R12）：set 取消信号并等待任务结束
    await evaluation_runner.shutdown()

    # Cleanup ES client
    await es_client.close_client()
    logger.info("Elasticsearch async client closed")

    # Cleanup Redis pool
    document_status.redis_pool = None
    await redis_pool.aclose()
    logger.info("KnowledgeManage service shutting down")


app = FastAPI(
    title="KnowledgeManage Service",
    description="知识管理服务 - 开发者门户平台",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(prompts.router, prefix="/api/knowledge")
app.include_router(chats.router, prefix="/api/knowledge")
app.include_router(knowledge_bases.router, prefix="/api/knowledge")
app.include_router(folders.router, prefix="/api/knowledge")
app.include_router(documents.router, prefix="/api/knowledge")
app.include_router(status_router.router, prefix="/api/knowledge")
app.include_router(chunks.router, prefix="/api/knowledge")
app.include_router(agents.router, prefix="/api/knowledge")
app.include_router(evaluations.router, prefix="/api/knowledge")
app.include_router(consumption.router, prefix="/api/knowledge")


@app.get("/api/knowledge/health")
async def health_check():
    return {"status": "ok", "service": "KnowledgeManage"}
