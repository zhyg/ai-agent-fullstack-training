"""配置快照与开跑前全量预检（FR-003/004，research.md R16）.

一次性冻结提示词内容、模型 {id,name,context_tokens}、retrieval/loop_count/tools/
max_output_tokens/kb_ids 进 AgentConfigSnapshot；预检失败抛 ConfigInvalidError
（指明失效配置项，SSE error code=config_invalid）。构建后运行期不再读配置表。
网关模型无启用字段：存在即启用、查不到即失效（R3）。
"""
import logging
from typing import List, Optional

from app.models.agent import Agent
from app.models.knowledge_base import KnowledgeBase
from app.models.prompt import Prompt
from app.schemas.agent import (
    AgentConfig,
    PROMPT_PURPOSES_BY_TYPE,
    TOOL_KEYS,
    required_prompt_purposes,
)
from app.services.agent_runtime import llm_client
from app.services.agent_runtime.state import (
    AgentConfigSnapshot,
    ModelRef,
    PromptSnapshot,
    RetrievalConfig,
)

logger = logging.getLogger(__name__)

DEFAULT_LOOP_COUNT = {"reasoning_action": 10, "planning_reasoning": 100}


class ConfigInvalidError(Exception):
    """预检失败：reasons 指明全部失效配置项（一次性全量检查，非逐项短路）."""

    def __init__(self, reasons: List[str]):
        self.code = "config_invalid"
        self.reasons = reasons
        super().__init__("；".join(reasons))


def _resolve_model_ref(model_id: Optional[str], label: str, reasons: List[str]) -> Optional[ModelRef]:
    if not model_id:
        reasons.append(f"缺少{label}配置")
        return None
    info = llm_client.resolve_model(model_id)
    if info is None:
        reasons.append(f"{label}不存在或已删除（{model_id}）")
        return None
    return ModelRef(model_id=model_id, name=info["name"], context_tokens=info["context_tokens"])


def build_snapshot(db, agent_id: str, kb_ids: List[str], user_id: str) -> AgentConfigSnapshot:
    """全量预检 + 冻结快照；任一配置项失效即抛 ConfigInvalidError.

    Args:
        db: 请求侧 SQLAlchemy Session（knowledge_manage schema）
        agent_id: 会话绑定的智能体 ID
        kb_ids: 会话绑定的知识库 ID 列表
        user_id: 当前用户（知识库归属校验）
    """
    reasons: List[str] = []

    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if agent is None:
        raise ConfigInvalidError([f"智能体不存在或已删除（{agent_id}）"])
    if agent.status != "enabled":
        reasons.append(f"智能体「{agent.name}」已停用")

    config = AgentConfig.model_validate(agent.config or {})
    agent_type = agent.type
    tools = config.tools if config.tools is not None else (
        list(TOOL_KEYS) if agent_type == "planning_reasoning" else []
    )

    # 提示词：必填用途缺失/被删即失败；可选用途存在则冻结、缺失跳过（对应工具未启用）
    required = set(required_prompt_purposes(agent_type, tools))
    prompts = {}
    for purpose in PROMPT_PURPOSES_BY_TYPE.get(agent_type, ()):
        prompt_id = getattr(config.prompts, purpose, None)
        if not prompt_id:
            if purpose in required:
                reasons.append(f"缺少{purpose}提示词配置")
            continue
        prompt = db.query(Prompt).filter(Prompt.id == prompt_id).first()
        if prompt is None:
            if purpose in required:
                reasons.append(f"{purpose}提示词不存在或已删除（{prompt_id}）")
            continue
        prompts[purpose] = PromptSnapshot(
            prompt_id=prompt.id, name=prompt.name,
            version=prompt.version, content=prompt.content,
        )

    # 模型：分析/向量恒必需；rerank 快速问答/推理行动必需，规划推理随 rerank 工具启用
    analysis = _resolve_model_ref(config.models.analysis_model_id, "分析模型", reasons)
    embedding = _resolve_model_ref(config.models.embedding_model_id, "向量模型", reasons)
    rerank_required = agent_type != "planning_reasoning" or "rerank" in tools
    rerank = None
    if config.models.rerank_model_id:
        rerank = _resolve_model_ref(config.models.rerank_model_id, "ReRank 模型", reasons)
    elif rerank_required:
        reasons.append("缺少 ReRank 模型配置")

    # FR-020 运行期复核：max_output_tokens < 分析模型 context_tokens
    if analysis is not None and config.models.max_output_tokens >= analysis.context_tokens:
        reasons.append(
            f"最大输出 Token 数（{config.models.max_output_tokens}）"
            f"必须小于分析模型上下文窗口（{analysis.context_tokens}）"
        )

    # 知识库：非空且全部存在、属本人
    if not kb_ids:
        reasons.append("未选择知识库")
    for kb_id in kb_ids or []:
        kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
        if kb is None:
            reasons.append(f"知识库不存在或已删除（{kb_id}）")
        elif kb.user_id != user_id:
            reasons.append(f"知识库不属于当前用户（{kb_id}）")

    if reasons:
        raise ConfigInvalidError(reasons)

    retrieval = RetrievalConfig(
        mode=config.retrieval.mode,
        vector_top_k=config.retrieval.vector_top_k,
        keyword_top_k=config.retrieval.keyword_top_k,
        hybrid_top_k=config.retrieval.hybrid_top_k,
        rerank_top_n=config.retrieval.rerank_top_n,
    )
    snapshot = AgentConfigSnapshot(
        agent_id=agent.id,
        agent_type=agent_type,
        prompts=prompts,
        analysis_model=analysis,
        embedding_model=embedding,
        rerank_model=rerank,
        retrieval=retrieval,
        loop_count=config.loop_count or DEFAULT_LOOP_COUNT.get(agent_type, 1),
        tools=tools,
        max_output_tokens=config.models.max_output_tokens,
        kb_ids=list(kb_ids),
        history_top_k=config.history_retrieval.top_k,  # 有默认值恒合法，不新增预检失败项（013 R12）
    )
    logger.info(
        "Agent snapshot built agent_id=%s type=%s prompts=%d kb=%d",
        agent.id, agent_type, len(prompts), len(kb_ids),
    )
    return snapshot