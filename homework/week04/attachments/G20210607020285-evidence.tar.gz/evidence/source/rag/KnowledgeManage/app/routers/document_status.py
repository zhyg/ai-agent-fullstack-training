"""WebSocket for document status snapshots and change notifications."""

import asyncio
import logging
import time

import jwt
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from redis.exceptions import RedisError
from starlette.concurrency import run_in_threadpool

from app.core.database import SessionLocal
from app.core.security import decode_token
from app.schemas.document import DocumentResponse
from app.services import document_service, document_status

router = APIRouter()
logger = logging.getLogger(__name__)


def _snapshot(document_id: str, user_id: str) -> dict:
    with SessionLocal() as db:
        doc = document_service.get_document(db, document_id, user_id)
        return DocumentResponse.from_orm_model(doc).model_dump(mode="json")


async def _stream(websocket: WebSocket, document_id: str, user_id: str) -> None:
    await run_in_threadpool(_snapshot, document_id, user_id)
    async with websocket.app.state.redis.pubsub() as pubsub:
        await asyncio.wait_for(pubsub.subscribe(document_status.channel(document_id)), timeout=5)
        messages = pubsub.listen()
        await asyncio.wait_for(anext(messages), timeout=5)
        # Refresh after the subscription acknowledgement so no commit is missed.
        snapshot = await run_in_threadpool(_snapshot, document_id, user_id)
        await websocket.send_json(snapshot)
        async for message in messages:
            if message["type"] not in {"message", "subscribe"}:
                continue
            updated = await run_in_threadpool(_snapshot, document_id, user_id)
            if updated != snapshot:
                await websocket.send_json(updated)
                snapshot = updated


async def _wait_for_disconnect(websocket: WebSocket) -> None:
    while (await websocket.receive())["type"] != "websocket.disconnect":
        pass


@router.websocket("/documents/{document_id}/status/ws")
async def document_status_socket(websocket: WebSocket, document_id: str) -> None:
    await websocket.accept()
    try:
        token = await asyncio.wait_for(websocket.receive_text(), timeout=5)
        claims = decode_token(token)
        if claims.get("type") != "access" or not claims.get("sub"):
            await websocket.close(code=4401)
            return
        expires_in = float(int(claims["exp"])) - time.time()
    except (jwt.PyJWTError, KeyError, TypeError, ValueError, OverflowError, TimeoutError):
        await websocket.close(code=4401)
        return
    except WebSocketDisconnect:
        return

    stream = asyncio.create_task(_stream(websocket, document_id, claims["sub"]))
    disconnect = asyncio.create_task(_wait_for_disconnect(websocket))
    close_code = 4401
    try:
        done, _ = await asyncio.wait(
            (stream, disconnect),
            timeout=max(0, expires_in),
            return_when=asyncio.FIRST_COMPLETED,
        )
        if disconnect in done:
            return
        if stream in done:
            stream.result()
            close_code = 1013
    except HTTPException:
        close_code = 4404
    except (RedisError, TimeoutError):
        logger.warning("Document status subscription unavailable for %s", document_id, exc_info=True)
        close_code = 1013
    except WebSocketDisconnect:
        return
    finally:
        stream.cancel()
        disconnect.cancel()
        await asyncio.gather(stream, disconnect, return_exceptions=True)
    await websocket.close(code=close_code)
