"""Redis notifications for committed document processing updates."""

import asyncio
import logging

from redis.asyncio import Redis
from redis.exceptions import RedisError

logger = logging.getLogger(__name__)
redis_pool: Redis | None = None


def channel(document_id: str) -> str:
    return f"knowledge:document-status:{document_id}"


async def notify(document_id: str) -> None:
    if redis_pool is None:
        return
    try:
        await asyncio.wait_for(redis_pool.publish(channel(document_id), "updated"), timeout=2)
    except (RedisError, TimeoutError):
        logger.warning("Could not publish status for document %s", document_id, exc_info=True)
