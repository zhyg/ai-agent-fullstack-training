"""Resolve image references for Markdown previews without changing stored content."""

import re
from collections.abc import Callable

from app.services import storage_service

_MD_IMAGE_PATTERN = re.compile(r"(!\[[^\]]*\]\()([^)]+)(\))")


def rewrite_image_urls(markdown: str, resolve: Callable[[str], str]) -> str:
    return _MD_IMAGE_PATTERN.sub(
        lambda match: f"{match[1]}{resolve(match[2])}{match[3]}", markdown
    )


def resolve_document_images(
    markdown: str, kb_id: str, doc_id: str, *, resolve_relative: bool = True,
    shared_keys: frozenset[str] = frozenset(),
) -> str:
    prefix = f"{kb_id}/{doc_id}/images/"
    attachment_prefix = f"{kb_id}/{doc_id}/attachments/"
    prefixes = (prefix, attachment_prefix)
    if resolve_relative:
        prefixes += ("images/", "./images/")
    signed_urls: dict[str, str] = {}

    def resolve(path: str) -> str:
        if path in shared_keys:
            if path not in signed_urls:
                signed_urls[path] = storage_service.get_shared_image_url(path)
            return signed_urls[path]
        for image_prefix in prefixes:
            if path.startswith(image_prefix):
                filename = path.removeprefix(image_prefix)
                break
        else:
            return path

        if not filename or filename in {".", ".."} or "/" in filename or "\\" in filename:
            return path
        key = path if image_prefix == attachment_prefix else f"{prefix}{filename}"
        if key not in signed_urls:
            signed_urls[key] = storage_service.get_presigned_url(key, expires=3600)
        return signed_urls[key]

    return rewrite_image_urls(markdown, resolve)
