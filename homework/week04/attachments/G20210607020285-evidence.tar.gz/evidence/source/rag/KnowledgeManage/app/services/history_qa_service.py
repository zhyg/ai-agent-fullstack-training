"""历史问答 ES 存储与检索组装（013，contracts/history-qa-es.md）.

- 写入：done 终态落库后由 chat_service 以 asyncio task 火忘式调用 index_qa_round；
  问题+答案拼接向量化（2026-11-24 澄清），按向量维度分索引 chat_history_qa_{dims}，
  _id=assistant 消息 id 幂等覆盖写；失败仅日志+trace，不重试不上抛（FR-013）。
- 检索：retrieve_and_assemble 每请求一次（run_agent_generation 入口、澄清前接线），
  BM25(match qa_text) + script_score(cosineSimilarity+1.0) 两路均带 term chat_id →
  Python RRF（与 retrieval_service 同口径，k=settings.agent_runtime.rrf_k）→
  组装"ES 命中时间序在前 + 最近 2 个完整问答轮保底在后"→ 预算裁剪 → state.clarify_history。
- 降级（FR-010，R10）：wait_for 整体限时（默认 3s，覆盖向量化+ES+RRF 全程）；
  超时/ES 异常/embedding 失败/零命中/任意异常 → clarify_history 保持 None（下游回退
  最近 10 轮），span 记 history_retrieve_degraded(reason)，流程继续不上抛。
"""
import asyncio
import logging
from datetime import datetime, timezone
from typing import List

from elasticsearch import ApiError, TransportError

from app.core import es_client
from app.core.config import settings
from app.services import embedding_service
from app.services.agent_runtime import budget, tracing
from app.services.agent_runtime.state import RequestRuntimeState
from app.services.retrieval_service import EmbeddingFailedError, RetrievalUnavailableError

logger = logging.getLogger(__name__)

_INDEX_PREFIX = "chat_history_qa_"


async def index_qa_round(
    *, chat_id: str, user_id: str, question: str, answer: str,
    message_id: str, embedding_model_id: str, trace_id: str,
) -> None:
    """单轮问答写入 ES（FR-012/013）：独立 span agent.history_index，失败隔离不影响主流程."""
    tracer = tracing.get_tracer()
    with tracer.start_as_current_span("agent.history_index") as span:
        span.set_attribute("chat.id", chat_id)
        span.set_attribute(tracing.ATTR_SESSION, chat_id)
        span.set_attribute("origin.trace_id", trace_id)
        try:
            qa_text = question + "\n" + answer
            vectors = await embedding_service.generate_embeddings([qa_text], embedding_model_id)
            vector = vectors[0] if vectors else None
            if not vector:
                raise RuntimeError("历史问答向量化失败: 空向量")
            index = await es_client.ensure_history_index(len(vector))
            client = await es_client.get_async_client()
            await client.index(
                index=index,
                id=message_id,  # 同 id 覆盖写，幂等（R7）；默认 refresh 不用 wait_for
                document={
                    "chat_id": chat_id,
                    "user_id": user_id,
                    "question": question,
                    "answer": answer,
                    "qa_text": qa_text,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "embedding_model": embedding_service.resolve_model_name(embedding_model_id),
                    "embedding_model_id": embedding_model_id,
                    "embeddings": vector,
                },
            )
            tracing.set_output(span, {"index": index, "doc_id": message_id})
        except Exception as e:
            logger.warning(
                "History QA index failed chat_id=%s message_id=%s: %s", chat_id, message_id, e
            )
            tracing.add_event(span, tracing.EVENT_HISTORY_INDEX_FAILED, {"error": str(e)})


async def retrieve_and_assemble(state: RequestRuntimeState, emit) -> None:
    """历史混合检索+组装（FR-007/008/010）：就地写 state.clarify_history；降级保持 None 回退."""
    from app.services.agent_runtime import steps

    await steps.emit_step(emit, "history_retrieve", "start")
    span = tracing.get_tracer().start_span("agent.history_retrieve")
    hits: List[dict] = []
    reason = None
    try:
        top_k = state.snapshot.history_top_k
        tracing.set_input(span, {"query": state.question, "chat_id": state.chat_id, "top_k": top_k})
        try:
            # R10：整体限时覆盖向量化+两路 ES 召回+RRF（ES/httpx 自身超时远超 3s）
            hits = await asyncio.wait_for(
                _retrieve_rounds(state, top_k),
                timeout=settings.agent_runtime.history_retrieve_timeout,
            )
        except asyncio.TimeoutError:
            reason = "timeout"
        except RetrievalUnavailableError as e:
            reason = "unavailable"
            logger.warning("History retrieve unavailable chat_id=%s: %s", state.chat_id, e)
        except EmbeddingFailedError as e:
            reason = "embedding_failed"
            logger.warning("History retrieve embedding failed chat_id=%s: %s", state.chat_id, e)
        except Exception as e:
            reason = "error"
            logger.warning("History retrieve failed chat_id=%s: %s", state.chat_id, e)
        if reason is None and not hits:
            reason = "empty_result"
        if reason is None:
            assembled = assemble_history(state, hits)
            _trim_to_budget(state, assembled)
            state.clarify_history = assembled
            # 命中轮次问答全文（与 retrieval.chunks 同口径，不截断）
            tracing.set_history_rounds(span, hits)
        else:
            tracing.add_event(span, tracing.EVENT_HISTORY_RETRIEVE_DEGRADED, {"reason": reason})
        tracing.set_output(span, {
            "count": len(hits),
            "round_ids": [h.get("_id", "") for h in hits],
            "degraded": reason is not None,
        })
    finally:
        span.end()
        await steps.emit_step(
            emit, "history_retrieve", "end",
            message="历史检索降级，使用最近历史" if reason is not None else None,
        )


async def _search(client, index: str, body: dict) -> List[dict]:
    try:
        resp = await client.search(index=index, body=body, ignore_unavailable=True)
    except (ApiError, TransportError) as e:
        raise RetrievalUnavailableError(f"历史检索服务不可用: {e}") from e
    return (resp.get("hits") or {}).get("hits") or []


async def _retrieve_rounds(state: RequestRuntimeState, top_k: int) -> List[dict]:
    """query 原问题向量化 → 按维度选索引 → BM25+向量两路（均带 chat_id 过滤）→ RRF 截断."""
    try:
        vectors = await embedding_service.generate_embeddings(
            [state.question], state.snapshot.embedding_model.model_id
        )
    except Exception as e:
        raise EmbeddingFailedError(f"历史检索向量化失败: {e}") from e
    if not vectors or not vectors[0]:
        raise EmbeddingFailedError("历史检索向量化失败: 空向量")
    qv = vectors[0]
    index = f"{_INDEX_PREFIX}{len(qv)}"  # 索引不存在=零命中（ignore_unavailable）
    client = await es_client.get_async_client()
    chat_filter = {"term": {"chat_id": state.chat_id}}
    bm25_hits = await _search(client, index, {
        "query": {"bool": {
            "must": [{"match": {"qa_text": state.question}}],
            "filter": [chat_filter],
        }},
        "size": top_k,
        "_source": {"excludes": ["embeddings"]},
    })
    vector_hits = await _search(client, index, {
        "query": {"script_score": {
            "query": chat_filter,
            "script": {
                "source": "cosineSimilarity(params.qv, 'embeddings') + 1.0",
                "params": {"qv": qv},
            },
        }},
        "size": top_k,
        "_source": {"excludes": ["embeddings"]},
    })
    return _rrf_fuse_rounds(bm25_hits, vector_hits, top_k, settings.agent_runtime.rrf_k)


def _rrf_fuse_rounds(
    bm25_hits: List[dict], vector_hits: List[dict], top_k: int, rrf_k: int
) -> List[dict]:
    """RRF 融合（R3，与 retrieval_service._rrf_fuse 同算法）：按名次而非原始分，_id 去重."""
    fused = {}
    scores = {}
    for hits in (bm25_hits, vector_hits):
        for rank, hit in enumerate(hits, start=1):
            doc_id = hit.get("_id", "")
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (rrf_k + rank)
            if doc_id not in fused:
                fused[doc_id] = hit
    ordered = sorted(fused.values(), key=lambda h: scores[h.get("_id", "")], reverse=True)
    return ordered[:top_k]


def _recent_complete_rounds(
    history: List[dict], current_question: str, limit: int = 2
) -> List[List[dict]]:
    """剔除末尾当前问题后取最近 N 个完整问答轮（user+assistant 成对；落单 user 不算）."""
    msgs = list(history)
    if msgs and msgs[-1].get("role") == "user" and msgs[-1].get("content") == current_question:
        msgs.pop()
    rounds: List[List[dict]] = []
    i = len(msgs) - 1
    while i >= 1 and len(rounds) < limit:
        if msgs[i].get("role") == "assistant" and msgs[i - 1].get("role") == "user":
            rounds.append([msgs[i - 1], msgs[i]])
            i -= 2
        else:
            i -= 1
    rounds.reverse()
    return rounds


def assemble_history(state: RequestRuntimeState, hits: List[dict]) -> List[dict]:
    """组装澄清/重写专用历史（FR-008，R9）：ES 命中 created_at 升序在前 + 保底 2 轮在后.

    去重键=question 原文精确匹配（入口 history 无消息 id/时间戳）；剔除当前问题本身。
    """
    base_rounds = _recent_complete_rounds(state.history, state.question)
    seen = {r[0].get("content", "") for r in base_rounds}
    seen.add(state.question)
    es_msgs: List[dict] = []
    for hit in sorted(hits, key=lambda h: (h.get("_source") or {}).get("created_at", "")):
        src = hit.get("_source") or {}
        question = src.get("question", "")
        if not question or question in seen:
            continue
        seen.add(question)
        es_msgs.append({"role": "user", "content": question})
        es_msgs.append({"role": "assistant", "content": src.get("answer", "")})
    return es_msgs + [m for r in base_rounds for m in r]


def _trim_to_budget(state: RequestRuntimeState, assembled: List[dict]) -> None:
    """组装后立即预算裁剪（R11）：clarify/rewrite 提示词较大者+当前问题为固定开销.

    头部逐轮淘汰（最早 ES 轮次先出）；保底 2 轮位于尾部，天然最后触及。
    """
    snapshot = state.snapshot
    limit = snapshot.analysis_model.context_tokens - snapshot.max_output_tokens
    fixed = max(
        budget.count_tokens(snapshot.prompts[p].content) if p in snapshot.prompts else 0
        for p in ("clarify", "rewrite")
    ) + budget.count_tokens(state.question)
    while assembled and fixed + sum(
        budget.count_tokens(m.get("content", "")) for m in assembled
    ) > limit:
        assembled.pop(0)
        if assembled and assembled[0].get("role") == "assistant":
            assembled.pop(0)  # 逐轮淘汰（user+assistant 成对）