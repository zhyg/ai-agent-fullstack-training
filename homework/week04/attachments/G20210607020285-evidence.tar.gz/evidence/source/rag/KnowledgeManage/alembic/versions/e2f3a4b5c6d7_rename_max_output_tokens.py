"""rename agent config models.max_tokens to max_output_tokens

Revision ID: e2f3a4b5c6d7
Revises: d9e1f2a3b4c5
Create Date: 2026-11-23 12:00:00.000000

"""
from typing import Sequence, Union
import json
from datetime import datetime, timezone

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'e2f3a4b5c6d7'
down_revision: Union[str, None] = 'd9e1f2a3b4c5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _rename_key(old: str, new: str) -> None:
    bind = op.get_bind()
    rows = bind.execute(sa.text("SELECT id, config FROM knowledge_manage.agents")).all()
    now = datetime.now(timezone.utc)
    for row in rows:
        models = row.config.get("models") or {}
        if old not in models:
            continue
        models[new] = models.pop(old)
        row.config["models"] = models
        bind.execute(
            sa.text(
                "UPDATE knowledge_manage.agents "
                "SET config = CAST(:config AS jsonb), updated_at = :now WHERE id = :id"
            ),
            {
                "id": row.id,
                "config": json.dumps(row.config, ensure_ascii=False),
                "now": now,
            },
        )


def upgrade() -> None:
    _rename_key("max_tokens", "max_output_tokens")


def downgrade() -> None:
    _rename_key("max_output_tokens", "max_tokens")