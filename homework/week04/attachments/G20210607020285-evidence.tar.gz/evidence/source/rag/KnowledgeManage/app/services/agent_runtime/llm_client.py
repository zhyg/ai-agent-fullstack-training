"""LlmGateway OpenAI 兼容客户端（research.md R1/R2/R3，FR-011/012）.

- resolve_model: 跨 schema 只读 SQL 解析模型 {name, context_tokens, category}（带缓存）；
  网关 models 表无启用字段，存在即启用、查不到即失效（R3）。
- call_json: JSON 非流式调用 + 容错提取 + Pydantic 校验；校验失败业务重试最多 3 次
  （含首次共 4 次），重试附上次输出与错误信息；传输层错误不重试直接上抛（网关自身重试）。
- stream_chat: SSE 流式调用，逐 chunk 产出 OpenAI delta JSON；取消检查在调用发起前与 delta 批间。
- 每次调用输入输出记 trace（span 由步骤侧创建，这里写属性/重试事件）。
"""
import json
import logging
from typing import Any, AsyncIterator, Callable, Dict, List, Optional, Type, TypeVar

import httpx
from pydantic import BaseModel
from sqlalchemy import text

from app.core.config import settings
from app.core.database import SessionLocal
from app.services.agent_runtime import tracing

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

# 业务重试上限：校验失败最多重试 3 次（含首次共 4 次调用）
MAX_JSON_RETRIES = 3

_model_cache: Dict[str, Dict[str, Any]] = {}


class AgentCancelled(Exception):
    """取消信号命中（检查点：调用发起前 / 流式 delta 批间 / 节点入口 / 工具执行前）."""


class ModelUnavailableError(Exception):
    """网关传输层错误 / 模型不可用（不业务重试，流程级异常）."""


class JsonValidationFailed(Exception):
    """JSON 校验最终失败（4 次用尽）；code 形如 clarify_json_failed，raw_output 回传前端."""

    def __init__(self, purpose: str, raw_output: str, detail: str):
        self.purpose = purpose
        self.code = f"{purpose}_json_failed"
        self.raw_output = raw_output
        self.detail = detail
        super().__init__(f"{self.code}: {detail}")


def get_llm_gateway_url() -> str:
    return settings.services.get("llm_gateway", "http://localhost:8003")


def resolve_model(model_id: str) -> Optional[Dict[str, Any]]:
    """解析模型 UUID → {name(COALESCE(display_name,name)), context_tokens, category}.

    跨 schema 只读查询 + 内存缓存（模式同 embedding_service.resolve_model_name）。
    记录不存在返回 None（预检口径：存在即启用，R3）。
    """
    if model_id in _model_cache:
        return _model_cache[model_id]
    db = SessionLocal()
    try:
        row = db.execute(
            text(
                "SELECT COALESCE(display_name, name), context_tokens, category "
                "FROM llm_gateway.models WHERE id = :mid"
            ),
            {"mid": model_id},
        ).first()
    finally:
        db.close()
    if row is None:
        return None
    info = {"name": row[0], "context_tokens": row[1], "category": row[2]}
    _model_cache[model_id] = info
    return info


def extract_json_object(raw: str) -> str:
    """容错提取：剥 ```json 代码围栏 / 去首尾空白 / 提取首个完整 JSON 对象.

    提取失败抛 ValueError（计入一次校验失败进入业务重试）。
    """
    text_ = (raw or "").strip()
    if text_.startswith("```"):
        # 剥离开头围栏（```json / ```）与结尾围栏
        first_newline = text_.find("\n")
        if first_newline != -1:
            text_ = text_[first_newline + 1:]
        if text_.rstrip().endswith("```"):
            text_ = text_.rstrip()[:-3]
        text_ = text_.strip()
    start = text_.find("{")
    if start == -1:
        raise ValueError("输出中未找到 JSON 对象")
    depth = 0
    in_string = False
    escaped = False
    for i in range(start, len(text_)):
        ch = text_[i]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text_[start:i + 1]
    raise ValueError("JSON 对象不完整（花括号未闭合）")


def _check_cancel(cancel_event) -> None:
    if cancel_event is not None and cancel_event.is_set():
        raise AgentCancelled()


def _headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {settings.llm_api_key}",
        "Content-Type": "application/json",
    }


async def chat_completion(
    model: str,
    messages: List[dict],
    *,
    max_output_tokens: Optional[int] = None,
    tools: Optional[List[dict]] = None,
    cancel_event=None,
    span=None,
) -> dict:
    """非流式调用，返回完整响应 JSON（含 choices[0].message / usage）.

    传输层错误（网络异常/5xx/限流）不重试直接上抛 ModelUnavailableError。
    """
    _check_cancel(cancel_event)
    payload: Dict[str, Any] = {"model": model, "messages": messages, "stream": False}
    if max_output_tokens is not None:
        payload["max_tokens"] = max_output_tokens
    if tools:
        payload["tools"] = tools
    span = span if span is not None else tracing.trace.get_current_span()
    span.set_attribute(tracing.ATTR_MODEL, model)
    tracing.set_input(span, {"messages": messages, "tools": tools})
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{get_llm_gateway_url()}/api/llm/v1/chat/completions",
                json=payload,
                headers=_headers(),
            )
            resp.raise_for_status()
            result = resp.json()
    except httpx.HTTPError as e:
        logger.error("Gateway chat completion failed: %s", e)
        raise ModelUnavailableError(f"模型服务不可用: {e}") from e
    if isinstance(result, dict) and result.get("error"):
        raise ModelUnavailableError(f"模型服务错误: {result['error']}")
    tracing.set_output(span, result)
    return result


async def call_json(
    model: str,
    messages: List[dict],
    result_model: Type[T],
    *,
    purpose: str,
    max_output_tokens: Optional[int] = None,
    extra_validator: Optional[Callable[[T], None]] = None,
    cancel_event=None,
    span=None,
) -> T:
    """JSON 步骤调用：容错提取 → model_validate_json → 可选附加校验（如索引越界）.

    校验失败业务重试最多 3 次（含首次共 4 次），重试消息附上次输出与错误信息；
    最终失败抛 JsonValidationFailed（携带 raw_output，FR-011）。
    """
    span = span if span is not None else tracing.trace.get_current_span()
    convo = list(messages)
    raw_output = ""
    last_error = ""
    for attempt in range(MAX_JSON_RETRIES + 1):
        result = await chat_completion(
            model, convo,
            max_output_tokens=max_output_tokens,
            cancel_event=cancel_event,
            span=span,
        )
        raw_output = (result.get("choices") or [{}])[0].get("message", {}).get("content") or ""
        try:
            parsed = result_model.model_validate_json(extract_json_object(raw_output))
            if extra_validator is not None:
                extra_validator(parsed)
            return parsed
        except (ValueError, TypeError) as e:
            last_error = str(e)
            logger.warning(
                "JSON validation failed purpose=%s attempt=%d: %s",
                purpose, attempt + 1, last_error,
            )
            tracing.add_event(span, "json_validation_retry", {
                "purpose": purpose, "attempt": attempt + 1, "error": last_error,
            })
            if attempt >= MAX_JSON_RETRIES:
                break
            # 重试：附上上次输出与错误信息帮助模型纠正
            convo = list(messages) + [
                {"role": "assistant", "content": raw_output},
                {"role": "user", "content": (
                    f"你上一次的输出未通过校验：{last_error}。"
                    "请修正后重新只输出一个 JSON 对象，不要输出任何其他内容。"
                )},
            ]
    raise JsonValidationFailed(purpose, raw_output, last_error)


async def stream_chat(
    model: str,
    messages: List[dict],
    *,
    max_output_tokens: Optional[int] = None,
    cancel_event=None,
    span=None,
) -> AsyncIterator[dict]:
    """SSE 流式调用：逐条产出 OpenAI chunk JSON（choices[0].delta / usage）.

    取消检查：调用发起前 + 每个 delta 批间（SC-005）；命中抛 AgentCancelled。
    传输层错误不重试直接上抛。
    """
    _check_cancel(cancel_event)
    payload: Dict[str, Any] = {"model": model, "messages": messages, "stream": True}
    if max_output_tokens is not None:
        payload["max_tokens"] = max_output_tokens
    span = span if span is not None else tracing.trace.get_current_span()
    span.set_attribute(tracing.ATTR_MODEL, model)
    tracing.set_input(span, {"messages": messages, "stream": True})
    collected: List[str] = []
    usage: Optional[dict] = None
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(300, connect=10)) as client:
            async with client.stream(
                "POST",
                f"{get_llm_gateway_url()}/api/llm/v1/chat/completions",
                json=payload,
                headers=_headers(),
            ) as resp:
                resp.raise_for_status()
                lines = resp.aiter_lines().__aiter__()
                while True:
                    _check_cancel(cancel_event)  # 拉取下一批前检查，取消后不再消费上游
                    try:
                        line = await lines.__anext__()
                    except StopAsyncIteration:
                        break
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        logger.warning("Invalid SSE chunk from gateway skipped")
                        continue
                    if isinstance(chunk, dict) and chunk.get("error"):
                        raise ModelUnavailableError(f"模型服务错误: {chunk['error']}")
                    delta = (chunk.get("choices") or [{}])[0].get("delta", {})
                    if delta.get("content"):
                        collected.append(delta["content"])
                    if chunk.get("usage"):
                        usage = chunk["usage"]
                    yield chunk
    except httpx.HTTPError as e:
        logger.error("Gateway stream failed: %s", e)
        raise ModelUnavailableError(f"模型服务不可用: {e}") from e
    finally:
        tracing.set_output(span, {"content": "".join(collected), "usage": usage})