"""Document processing pipeline — orchestration of parse, chunk, embed, store."""

import asyncio
import json
import logging
from datetime import datetime, timezone

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm.exc import ObjectDeletedError, StaleDataError
from starlette.concurrency import run_in_threadpool

from app.core.database import SessionLocal
from app.core import es_client
from app.models.document import Document
from app.models.knowledge_base import KnowledgeBase
from app.services import storage_service, es_chunk_service, document_status, markdown_attachments
from app.services.parsing_service import (
    parse_document,
    upload_image_to_minio,
    is_document_type,
    is_markdown_type,
    is_image_type,
    is_spreadsheet_type,
)
from app.services.chunking_service import chunk_by_heading, chunk_by_fixed, chunk_table_rows
from app.services.embedded_tables import extract_embedded_tables
from app.services.markdown_preview import rewrite_image_urls
from app.services.embedding_service import generate_embeddings, get_embedding_dims
from app.services.image_service import process_image_ocr, process_image_caption
from app.services.table_service import (
    generate_embedded_table_name,
    validate_spreadsheet,
    read_spreadsheet,
    create_sqlite_db,
    table_rows_to_text,
)
from app.services.ai_question_service import generate_questions, is_eligible_for_questions

logger = logging.getLogger(__name__)

# Status values for the document processing pipeline
STATUS_PENDING = "pending"
STATUS_PARSING = "parsing"
STATUS_CHUNKING = "chunking"
STATUS_EMBEDDING = "embedding"
STATUS_AI_GENERATING = "ai_generating"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"
DELETION_CHECK_INTERVAL = 1.0


async def process_document(doc_id: str, kb_id: str) -> None:
    """Run the pipeline until it finishes or the document is deleted."""
    task = asyncio.create_task(_run_pipeline(doc_id, kb_id))
    try:
        while not task.done():
            done, _ = await asyncio.wait((task,), timeout=DELETION_CHECK_INTERVAL)
            if done:
                break
            try:
                exists = await run_in_threadpool(_document_exists, doc_id)
            except SQLAlchemyError:
                logger.warning("Could not check whether document %s was deleted", doc_id, exc_info=True)
                continue
            if not exists:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
                logger.info("Stopped processing deleted document %s", doc_id)
                await _cleanup_processing_artifacts(kb_id, doc_id)
                return
        await task
    finally:
        if not task.done():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)


def _document_exists(doc_id: str) -> bool:
    with SessionLocal() as db:
        return db.query(Document.id).filter(Document.id == doc_id).scalar() is not None


async def _run_pipeline(doc_id: str, kb_id: str) -> None:
    db = SessionLocal()
    try:
        doc = db.query(Document).filter(Document.id == doc_id).first()
        if not doc:
            logger.info("Skipping processing because document %s no longer exists", doc_id)
            return

        kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
        if not kb:
            logger.error("KnowledgeBase %s not found", kb_id)
            await _set_status(db, doc, STATUS_FAILED, "知识库不存在")
            return

        # Parse chunk_config
        chunk_config = _parse_chunk_config(doc.chunk_config)

        # Download original file from MinIO
        file_bytes = await _download_from_minio(doc.storage_path)
        if file_bytes is None:
            await _set_status(db, doc, STATUS_FAILED, "无法从存储下载原始文件")
            return

        extension = (doc.extension or "").lower()

        # Route to appropriate processor based on file type
        if is_image_type(extension):
            await _process_standalone_image(db, doc, kb, file_bytes)
        elif is_spreadsheet_type(extension):
            await _process_standalone_table(db, doc, kb, chunk_config)
        elif is_document_type(extension) or is_markdown_type(extension):
            await _process_document(db, doc, kb, file_bytes, chunk_config)
        else:
            # Unsupported file type — skip and mark as failed
            logger.warning("Unsupported file type '%s' for document %s", extension, doc.id)
            await _set_status(db, doc, STATUS_FAILED, f"不支持的文件类型: {extension}")

    except Exception as e:
        db.rollback()
        doc = db.query(Document).filter(Document.id == doc_id).first()
        try:
            if doc is None:
                logger.info("Stopped processing deleted document %s", doc_id)
            else:
                logger.exception("Pipeline failed for document %s: %s", doc_id, e)
                await _set_status(db, doc, STATUS_FAILED, str(e))
        except (ObjectDeletedError, StaleDataError):
            db.rollback()
            logger.info("Document %s was removed before its failure status could be saved", doc_id)
        finally:
            await _cleanup_processing_artifacts(kb_id, doc_id)
    finally:
        db.close()


async def _process_document(
    db,
    doc: Document,
    kb: KnowledgeBase,
    file_bytes: bytes,
    chunk_config: dict,
) -> None:
    """Process a document file (doc/docx/ppt/pptx/pdf/md)."""
    # Stage 1: Parsing
    await _set_status(db, doc, STATUS_PARSING)
    assets = markdown_attachments.shared_assets(db, doc.id) if is_markdown_type(doc.extension) else {}
    parse_result = await parse_document(
        file_bytes=file_bytes,
        filename=doc.name,
        extension=doc.extension,
        kb_id=doc.kb_id,
        doc_id=doc.id,
        archive_assets=assets,
    )
    doc.md_path = parse_result.get("md_path")
    db.commit()

    markdown_text = parse_result["markdown_text"]
    if not markdown_text.strip():
        logger.warning("Empty markdown output for document %s", doc.id)
        await _set_status(db, doc, STATUS_FAILED, "解析结果为空，文档可能无文本内容")
        return

    # Stage 2: Chunking
    await _set_status(db, doc, STATUS_CHUNKING)
    strategy = chunk_config.get("strategy", "heading")
    chunk_size = chunk_config.get("chunk_size", 512)
    chunk_overlap = chunk_config.get("chunk_overlap", 80)
    separators = chunk_config.get("separators")

    tables = extract_embedded_tables(markdown_text)
    if tables:
        image_paths = {
            variant: image["minio_path"]
            for image in parse_result.get("images", [])
            for variant in image.get("local_variants", [])
        }
        for index, table in enumerate(tables, start=1):
            for row in table.rows:
                for col, cell in enumerate(row):
                    row[col] = rewrite_image_urls(cell, lambda path: image_paths.get(path, path))
            fallback = f"table_{index}"
            name = await generate_embedded_table_name(
                table.headers, fallback, kb.llm_model_id, caption=table.caption,
            )
            table.sqlite_url = await create_sqlite_db(
                [{"sheet_name": name, "headers": table.headers, "rows": table.rows}],
                doc.kb_id, doc.id, fallback,
            )

    chunk_document = chunk_by_heading if strategy == "heading" else chunk_by_fixed
    chunks = chunk_document(
        markdown_text,
        file_name=doc.name,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=separators,
        tables=tables,
    )

    if not chunks:
        logger.warning("No chunks generated for document %s", doc.id)
        await _set_status(db, doc, STATUS_FAILED, "分块结果为空，请检查文档内容或分块参数")
        return

    # Stage 3: Embedding
    await _set_status(db, doc, STATUS_EMBEDDING)

    # Ensure ES index exists with correct dims
    dims = await get_embedding_dims(kb.embedding_model_id)
    await es_client.ensure_index(doc.kb_id, dims)

    # Generate embeddings in batches (avoid overwhelming the API)
    EMBED_BATCH = 50
    texts = [c["content"] for c in chunks]
    all_embeddings = []
    for i in range(0, len(texts), EMBED_BATCH):
        batch_texts = texts[i:i + EMBED_BATCH]
        batch_embeddings = await generate_embeddings(batch_texts, kb.embedding_model_id)
        all_embeddings.extend(batch_embeddings)

    # Attach embeddings to chunks
    for chunk, emb in zip(chunks, all_embeddings):
        chunk["embeddings"] = emb
        chunk["document_id"] = doc.id

    # Write to ES
    await _index_chunks(doc.kb_id, chunks)

    # Stage 3.5: Image processing (OCR + Caption for images in chunks)
    shared_keys = set(assets.values())
    for key in sorted(shared_keys):
        await markdown_attachments.analyze_shared_image(key, kb.image_model_id)
    parse_result["images"] = [
        image for image in parse_result.get("images", []) if image.get("minio_path") not in shared_keys
    ]
    image_chunks = await _process_chunk_images(chunks, doc, kb, file_bytes, parse_result)
    if image_chunks:
        # Generate embeddings for image sub-chunks
        img_texts = [c["content"] for c in image_chunks]
        img_embeddings = await generate_embeddings(img_texts, kb.embedding_model_id)
        for c, emb in zip(image_chunks, img_embeddings):
            c["embeddings"] = emb
        await _index_chunks(doc.kb_id, image_chunks)

    # Stage 4: AI question generation
    await _set_status(db, doc, STATUS_AI_GENERATING)
    ai_question_count = doc.ai_question_count or 3
    if ai_question_count > 0:
        ai_chunks = await _generate_ai_questions(
            chunks, doc, kb, ai_question_count
        )
        if ai_chunks:
            ai_texts = [c["content"] for c in ai_chunks]
            ai_embeddings = await generate_embeddings(ai_texts, kb.embedding_model_id)
            for c, emb in zip(ai_chunks, ai_embeddings):
                c["embeddings"] = emb
            await _index_chunks(doc.kb_id, ai_chunks)

    # Done
    await _set_status(db, doc, STATUS_COMPLETED)
    logger.info("Document %s processing completed: %d chunks", doc.id, len(chunks))


async def _process_standalone_image(db, doc, kb, file_bytes):
    """Process a standalone image upload — creates image + image_ocr + image_caption chunks."""
    import uuid

    # Use MinIO object path (not presigned URL) — presigned URLs are generated
    # on-the-fly by the API layer when serving to the frontend.
    image_minio_path = doc.storage_path

    # Ensure ES index exists
    dims = await get_embedding_dims(kb.embedding_model_id)
    await es_client.ensure_index(doc.kb_id, dims)

    # Create image chunk (top-level)
    image_chunk_id = str(uuid.uuid4())
    image_chunk = {
        "chunk_id": image_chunk_id,
        "chunk_type": "image",
        "content": f"[文件名: {doc.name}]\n![]({image_minio_path})",
        "image_url": image_minio_path,
        "parent_chunk_id": None,
        "sqlite_url": None,
        "chunk_index": 0,
        "document_id": doc.id,
        "file_name": doc.name,
    }

    sub_chunks = []

    # Process OCR
    try:
        ocr_text = await process_image_ocr(file_bytes, doc.name)
        if ocr_text:
            sub_chunks.append({
                "chunk_id": str(uuid.uuid4()),
                "chunk_type": "image_ocr",
                "content": ocr_text,
                "image_url": image_minio_path,
                "parent_chunk_id": image_chunk_id,
                "sqlite_url": None,
                "chunk_index": 1,
                "document_id": doc.id,
                "file_name": doc.name,
            })
    except Exception as e:
        logger.warning("OCR processing failed for %s: %s", doc.name, e)

    # Process Caption
    try:
        caption_text = await process_image_caption(
            file_bytes, doc.name, kb.image_model_id
        )
        if caption_text:
            sub_chunks.append({
                "chunk_id": str(uuid.uuid4()),
                "chunk_type": "image_caption",
                "content": caption_text,
                "image_url": image_minio_path,
                "parent_chunk_id": image_chunk_id,
                "sqlite_url": None,
                "chunk_index": 2,
                "document_id": doc.id,
                "file_name": doc.name,
            })
    except Exception as e:
        logger.warning("Image caption processing failed for %s: %s", doc.name, e)

    # Generate embeddings
    all_texts = [image_chunk["content"]] + [c["content"] for c in sub_chunks]
    all_embeddings = await generate_embeddings(all_texts, kb.embedding_model_id)

    image_chunk["embeddings"] = all_embeddings[0]
    for sc, emb in zip(sub_chunks, all_embeddings[1:]):
        sc["embeddings"] = emb

    # Write all to ES
    all_chunks = [image_chunk] + sub_chunks
    await _index_chunks(doc.kb_id, all_chunks)

    await _set_status(db, doc, STATUS_COMPLETED)
    logger.info("Standalone image %s processed: %d chunks", doc.id, len(all_chunks))


async def _process_chunk_images(chunks, doc, kb, file_bytes, parse_result):
    """Process images found within document chunks — generate OCR and caption sub-chunks.

    Downloads each image from MinIO (using parse_result image metadata),
    then passes the actual image bytes to OCR and caption services.
    """
    import uuid
    import os

    # Build lookup: minio_path -> metadata (for downloading)
    image_lookup = {}
    for img_info in parse_result.get("images", []):
        minio_path = img_info.get("minio_path", "")
        if minio_path:
            image_lookup[minio_path] = {
                "minio_path": minio_path,
                "filename": os.path.basename(minio_path),
            }

    sub_chunks = []
    for chunk in chunks:
        image_urls = chunk.get("image_url")
        if not image_urls or not isinstance(image_urls, list):
            continue

        for img_url in image_urls:
            # image_url in chunks is now a MinIO object path
            # Skip external URLs that are not MinIO paths
            if img_url.startswith(("http://", "https://")):
                continue

            # Find image metadata
            img_info = image_lookup.get(img_url)
            if not img_info:
                logger.debug(
                    "No image metadata found for URL in document %s",
                    doc.id,
                )
                continue

            # Download image bytes from MinIO
            try:
                img_bytes = storage_service.download_file(img_info["minio_path"])
            except Exception as e:
                logger.warning(
                    "Failed to download image %s from MinIO: %s",
                    img_info["filename"], e,
                )
                continue

            parent_chunk_id = chunk.get("chunk_id")
            img_filename = img_info["filename"]

            # Process OCR
            try:
                ocr_text = await process_image_ocr(img_bytes, img_filename)
                if ocr_text:
                    sub_chunks.append({
                        "chunk_id": str(uuid.uuid4()),
                        "chunk_type": "image_ocr",
                        "content": ocr_text,
                        "image_url": img_url,
                        "parent_chunk_id": parent_chunk_id,
                        "sqlite_url": None,
                        "chunk_index": len(sub_chunks),
                        "document_id": doc.id,
                        "file_name": doc.name,
                    })
            except Exception as e:
                logger.warning("OCR for image %s failed: %s", img_filename, e)

            # Process Caption
            try:
                caption_text = await process_image_caption(
                    img_bytes, img_filename, kb.image_model_id
                )
                if caption_text:
                    sub_chunks.append({
                        "chunk_id": str(uuid.uuid4()),
                        "chunk_type": "image_caption",
                        "content": caption_text,
                        "image_url": img_url,
                        "parent_chunk_id": parent_chunk_id,
                        "sqlite_url": None,
                        "chunk_index": len(sub_chunks),
                        "document_id": doc.id,
                        "file_name": doc.name,
                    })
            except Exception as e:
                logger.warning("Caption for image %s failed: %s", img_filename, e)

    if sub_chunks:
        logger.info(
            "Generated %d image sub-chunks for document %s",
            len(sub_chunks), doc.id,
        )
    return sub_chunks


async def _generate_ai_questions(chunks, doc, kb, question_count):
    """Generate AI question chunks from eligible parent chunks."""
    import uuid

    ai_chunks = []
    for chunk in chunks:
        chunk_type = chunk.get("chunk_type", "")
        if not is_eligible_for_questions(chunk_type):
            continue

        content = chunk.get("content", "")
        parent_chunk_id = chunk.get("chunk_id")

        try:
            questions = await generate_questions(
                content, question_count, kb.llm_model_id
            )
            for q in questions:
                ai_chunks.append({
                    "chunk_id": str(uuid.uuid4()),
                    "chunk_type": "ai_question",
                    "content": q,
                    "image_url": None,
                    "parent_chunk_id": parent_chunk_id,
                    "sqlite_url": None,
                    "chunk_index": len(ai_chunks),
                    "document_id": doc.id,
                    "file_name": doc.name,
                })
        except Exception as e:
            logger.warning("AI question generation failed for chunk %s: %s", parent_chunk_id, e)

    return ai_chunks


async def _process_standalone_table(db, doc, kb, chunk_config):
    """Process a standalone table file (xls/xlsx/csv)."""
    # Download file to temp location
    tmp_dir = __import__('tempfile').mkdtemp(prefix="table_")
    tmp_path = __import__('os').path.join(tmp_dir, doc.name)

    try:
        # Write file bytes to temp path
        with open(tmp_path, "wb") as f:
            f.write(await _download_from_minio(doc.storage_path))

        # Validate
        is_valid, error_msg = validate_spreadsheet(tmp_path)
        if not is_valid:
            logger.error("Table validation failed for %s: %s", doc.id, error_msg)
            await _set_status(db, doc, STATUS_FAILED, f"表格校验失败: {error_msg}")
            return

        # Read sheets
        sheets_data = read_spreadsheet(tmp_path)
        if not sheets_data:
            await _set_status(db, doc, STATUS_FAILED, "表格文件无有效数据")
            return

        # Create SQLite db
        table_name = __import__('os').path.splitext(doc.name)[0]
        sqlite_url = await create_sqlite_db(sheets_data, doc.kb_id, doc.id, table_name)

        # Ensure ES index
        dims = await get_embedding_dims(kb.embedding_model_id)
        await es_client.ensure_index(doc.kb_id, dims)

        # Create table_row chunks
        chunk_size = chunk_config.get("chunk_size", 512) if chunk_config else 512
        all_chunks = []
        chunk_idx = 0
        for sheet in sheets_data:
            row_texts = table_rows_to_text(sheet["headers"], sheet["rows"])
            sheet_chunks = chunk_table_rows(
                row_texts,
                table_name=table_name,
                sheet_name=sheet["sheet_name"],
                sqlite_url=sqlite_url,
                file_name=doc.name,
                chunk_size=chunk_size,
            )
            for sc in sheet_chunks:
                sc["chunk_index"] = chunk_idx
                sc["document_id"] = doc.id
                chunk_idx += 1
            all_chunks.extend(sheet_chunks)

        # Generate embeddings
        if all_chunks:
            texts = [c["content"] for c in all_chunks]
            EMBED_BATCH = 50
            all_embeddings = []
            for i in range(0, len(texts), EMBED_BATCH):
                batch = texts[i:i + EMBED_BATCH]
                batch_emb = await generate_embeddings(batch, kb.embedding_model_id)
                all_embeddings.extend(batch_emb)
            for c, emb in zip(all_chunks, all_embeddings):
                c["embeddings"] = emb
            await _index_chunks(doc.kb_id, all_chunks)

        await _set_status(db, doc, STATUS_COMPLETED)
        logger.info("Standalone table %s processed: %d chunks", doc.id, len(all_chunks))

    finally:
        # Cleanup temp files
        import shutil
        shutil.rmtree(tmp_dir, ignore_errors=True)


# ─────────────────── Helpers ───────────────────


async def _index_chunks(kb_id: str, chunks: list[dict]) -> None:
    # Let an in-flight write settle before deletion cleanup removes its results.
    write = asyncio.create_task(es_chunk_service.bulk_index_chunks(kb_id, chunks))
    try:
        await asyncio.shield(write)
    except asyncio.CancelledError:
        try:
            await write
        except Exception:
            logger.warning("Index write failed during document cancellation", exc_info=True)
        raise


async def _cleanup_processing_artifacts(kb_id: str, doc_id: str) -> None:
    try:
        await es_chunk_service.delete_by_document(kb_id, doc_id)
    except Exception:
        logger.warning("Could not clean up ES chunks for document %s", doc_id, exc_info=True)
    try:
        await run_in_threadpool(_cleanup_minio_intermediates, kb_id, doc_id)
    except Exception:
        logger.warning("Could not clean up MinIO intermediates for document %s", doc_id, exc_info=True)


async def _set_status(db, doc: Document, status: str, error_message: str | None = None) -> None:
    """Update document status and commit.

    Args:
        error_message: When status is 'failed', provide the failure reason.
                       Set to empty string to clear previous error on success.
    """
    doc.status = status
    doc.updated_at = datetime.now(timezone.utc)
    if status == STATUS_COMPLETED:
        doc.error_message = None
    elif error_message is not None:
        doc.error_message = error_message
    document_id = doc.id
    db.commit()
    await document_status.notify(document_id)


def _parse_chunk_config(chunk_config_json: str | None) -> dict:
    """Parse chunk_config JSON string to dict."""
    if not chunk_config_json:
        return {
            "strategy": "heading",
            "chunk_size": 512,
            "chunk_overlap": 80,
            "separators": None,
        }
    try:
        return json.loads(chunk_config_json)
    except (json.JSONDecodeError, TypeError):
        return {
            "strategy": "heading",
            "chunk_size": 512,
            "chunk_overlap": 80,
            "separators": None,
        }


async def _download_from_minio(storage_path: str) -> bytes | None:
    """Download a file from MinIO by its storage path."""
    try:
        url = storage_service.get_presigned_url(storage_path, expires=300)
        import httpx
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            return resp.content
    except Exception as e:
        logger.error("Failed to download file from MinIO (%s): %s", storage_path, e)
        return None


def _cleanup_minio_intermediates(kb_id: str, doc_id: str) -> None:
    """Clean up intermediate MinIO files (markdown, images, tables) on failure."""
    prefixes = [
        f"{kb_id}/{doc_id}/markdown/",
        f"{kb_id}/{doc_id}/images/",
        f"{kb_id}/{doc_id}/tables/",
    ]
    for prefix in prefixes:
        count = storage_service.delete_objects_by_prefix(prefix)
        if count:
            logger.info("Cleaned up %d objects with prefix %s", count, prefix)
