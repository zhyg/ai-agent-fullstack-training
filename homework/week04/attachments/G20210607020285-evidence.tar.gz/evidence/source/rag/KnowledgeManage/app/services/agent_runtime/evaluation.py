"""评测专用无会话问答入口（014-knowledge-evaluation T021，research R1，决策21）.

与 run_agent_generation 的差异：
- 不依赖 Chat 表：agent_id/kb_ids 由调用方直传，不创建 Chat/Message；
- 根 span 为 evaluation.item（属性 evaluation.run_id/item.seq/enduser.id），
  flow 内部 span 经 OTel 当前上下文自动挂到根下（决策22 同一 trace）；
- history=[]、chat_id=""，跳过 history_qa_service（每题独立单轮，FR-015）；
- 每题调用重新 build_snapshot（决策24：运行中变更实时生效，R8）；
- 可选 score_hook：在根 span 上下文内执行评分（评分子 span 同 trace，R10），
  返回值合并进结果 dict；异常映射模式同 run_agent_generation。
"""
import logging
import uuid
from typing import Awaitable, Callable, List, Optional

logger = logging.getLogger(__name__)

from app.core.database import SessionLocal
from app.services.agent_runtime import _get_runner, tracing
from app.services.agent_runtime.llm_client import (
    AgentCancelled,
    JsonValidationFailed,
    ModelUnavailableError,
)
from app.services.agent_runtime.snapshot import ConfigInvalidError, build_snapshot
from app.services.agent_runtime.state import RequestRuntimeState
from app.services.retrieval_service import EmbeddingFailedError, RetrievalUnavailableError


async def run_evaluation_question(
    *,
    agent_id: str,
    kb_ids: List[str],
    user_id: str,
    question: str,
    cancel_event,
    emit: Callable[[str], Awaitable[None]],
    run_id: str = "",
    seq: int = 0,
    score_hook: Optional[Callable[[dict], Awaitable[dict]]] = None,
) -> dict:
    """单题独立单轮问答：快照→flow 分发→（可选）根 span 内评分→异常映射.

    Returns:
        {content, meta, trace_id, cancelled, error?}；score_hook 返回值并入结果。
        内部捕获 AgentCancelled 返回部分答案（cancelled=True），不向调用方抛出。
    """
    tracer = tracing.get_tracer()
    state = None
    trace_id = ""

    def _error(code: str, message: str, raw_output: str = "") -> dict:
        err = {"code": code, "message": message}
        if raw_output:
            err["raw_output"] = raw_output
        return {"content": "", "meta": {}, "trace_id": trace_id, "cancelled": False, "error": err}

    with tracer.start_as_current_span("evaluation.item") as root:
        root.set_attribute("evaluation.run_id", run_id)
        root.set_attribute("item.seq", seq)
        root.set_attribute(tracing.ATTR_USER, user_id)
        trace_id = tracing.trace_id_hex(root)
        db = SessionLocal()
        try:
            snapshot = build_snapshot(db, agent_id, kb_ids, user_id)
            root.set_attribute("agent.id", snapshot.agent_id)
            root.set_attribute("agent.type", snapshot.agent_type)

            state = RequestRuntimeState(
                generation_id=str(uuid.uuid4()),
                chat_id="",
                user_id=user_id,
                snapshot=snapshot,
                question=question,
                history=[],
                cancel_event=cancel_event,
            )
            state.trace_id = trace_id

            runner = _get_runner(snapshot.agent_type)
            result = await runner(state, emit)
            final = {
                "content": result.get("content") or "",
                "meta": dict(result.get("meta") or {}),
                "trace_id": trace_id,
                "cancelled": False,
            }
            # 评分在根 span 上下文内执行，evaluation.recall/accuracy 子 span 同 trace（R10）
            if score_hook is not None:
                final.update(await score_hook(final))
            return final
        except AgentCancelled:
            tracing.add_event(root, "agent_cancelled", {"partial_chars": len(state.partial_answer) if state else 0})
            return {
                "content": state.partial_answer if state else "",
                "meta": {"stopped": True},
                "trace_id": trace_id,
                "cancelled": True,
            }
        except ConfigInvalidError as e:
            tracing.add_event(root, "flow_error", {"code": e.code, "message": str(e)})
            return _error(e.code, str(e))
        except JsonValidationFailed as e:
            tracing.add_event(root, "flow_error", {"code": e.code, "message": e.detail})
            return _error(e.code, f"模型输出格式校验失败：{e.detail}", e.raw_output)
        except EmbeddingFailedError as e:
            tracing.add_event(root, "flow_error", {"code": "embedding_failed", "message": str(e)})
            return _error("embedding_failed", str(e))
        except RetrievalUnavailableError as e:
            tracing.add_event(root, "flow_error", {"code": "retrieval_unavailable", "message": str(e)})
            return _error("retrieval_unavailable", str(e))
        except ModelUnavailableError as e:
            tracing.add_event(root, "flow_error", {"code": "model_unavailable", "message": str(e)})
            return _error("model_unavailable", str(e))
        except Exception as e:
            logger.exception("evaluation_question internal error run_id=%s seq=%s", run_id, seq)
            tracing.add_event(root, "flow_error", {"code": "internal_error", "message": str(e)})
            return _error("internal_error", f"智能体运行失败: {e}")
        finally:
            db.close()
            tracing.finalize_tracing()