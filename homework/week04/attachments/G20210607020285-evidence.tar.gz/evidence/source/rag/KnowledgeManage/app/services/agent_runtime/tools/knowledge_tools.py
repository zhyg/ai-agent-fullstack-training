"""知识工具（FR-025，contracts/tool-runtime.md §3）：行为与共用步骤一致.

- rewriteQuestion/zip 复用提示词快照与 call_json（JSON 容错+业务重试 3 次），
  最终校验失败 → execution_failed 回传模型；
- 检索类工具命中即并入 ctx.chunks（去重累积）、sqlite_url 加入白名单；
  空结果 code=empty_result；embedding 失败工具内 execution_failed（不终止流程）；
- rerank 网关失败降级按原始分截断（code=ok，content 附 degraded:true）；
- 工具内模型调用在 agent.tool.{name}（current）下按对应步骤名产生子 span。
"""
import json
import logging
from typing import List, Optional

from pydantic import BaseModel, Field

from app.schemas.agent_runtime import CompressResult, RewriteResult, ToolResult
from app.services import retrieval_service, rerank_service
from app.services.agent_runtime import llm_client, steps, tracing
from app.services.agent_runtime.llm_client import JsonValidationFailed
from app.services.agent_runtime.state import ContextChunk, RequestRuntimeState
from app.services.agent_runtime.tools.runtime import ToolFailure, ToolSpec
from app.services.retrieval_service import EmbeddingFailedError

logger = logging.getLogger(__name__)


def _ok(payload: dict) -> ToolResult:
    return ToolResult(success=True, code="ok", content=json.dumps(payload, ensure_ascii=False))


def _chunk_payload(chunks: List[ContextChunk]) -> List[dict]:
    items = []
    for c in chunks:
        item = {
            "chunk_id": c.chunk_id,
            "document_id": c.document_id,
            "file_name": c.file_name,
            "content": c.content,
            "score": c.score,
        }
        if c.sqlite_url:
            item["sqlite_url"] = c.sqlite_url
        items.append(item)
    return items


def _resolve_chunks(ctx: RequestRuntimeState, chunk_ids: List[str]) -> List[ContextChunk]:
    """chunk_ids 限本次已检索片段；未知 id → invalid_args."""
    unknown = [cid for cid in chunk_ids if cid not in ctx.chunks]
    if unknown:
        raise ToolFailure("invalid_args", f"未知 chunk_id（限本次已检索片段）：{unknown}")
    return [ctx.chunks[cid] for cid in chunk_ids]


# ---- 入参模型 ----

class RewriteQuestionArgs(BaseModel):
    question: str = Field(..., min_length=1)


class SearchArgs(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: Optional[int] = Field(None, ge=1, le=100)


class RerankArgs(BaseModel):
    query: str = Field(..., min_length=1)
    chunk_ids: List[str] = Field(..., min_length=1)
    top_n: Optional[int] = Field(None, ge=1, le=100)


class ZipArgs(BaseModel):
    question: str = Field(..., min_length=1)
    chunk_ids: List[str] = Field(..., min_length=1)


# ---- 处理器 ----

async def _rewrite_question(args: RewriteQuestionArgs, ctx: RequestRuntimeState) -> ToolResult:
    span = tracing.get_tracer().start_span("agent.rewrite")
    tracing.set_prompt_attrs(span, ctx.snapshot.prompts["rewrite"], "rewrite")
    try:
        prompt = ctx.snapshot.prompts["rewrite"].content
        rendered = steps.render_prompt(prompt, question=args.question, history=steps.clarify_history_text(ctx))
        result = await llm_client.call_json(
            ctx.snapshot.analysis_model.name,
            [{"role": "user", "content": steps._json_prompt(rendered, RewriteResult)}],
            RewriteResult,
            purpose="rewrite",
            max_output_tokens=ctx.snapshot.max_output_tokens,
            cancel_event=ctx.cancel_event,
            span=span,
        )
        tracing.set_output(span, result.model_dump())
        return _ok({"rewritten_question": result.rewritten_question})
    except JsonValidationFailed as e:
        raise ToolFailure("execution_failed", f"重写输出校验失败：{e.detail}") from e
    finally:
        span.end()


def _search_handler(mode: str):
    async def _search(args: SearchArgs, ctx: RequestRuntimeState) -> ToolResult:
        snap = ctx.snapshot
        rc = snap.retrieval
        span = tracing.get_tracer().start_span(f"agent.retrieve.{mode}")
        try:
            tracing.set_input(span, {"mode": mode, "query": args.query, "kb_ids": snap.kb_ids})
            kwargs = {
                "vector_top_k": rc.vector_top_k,
                "keyword_top_k": rc.keyword_top_k,
                "hybrid_top_k": rc.hybrid_top_k,
                "embedding_model_id": snap.embedding_model.model_id if snap.embedding_model else None,
            }
            if args.top_k is not None:
                key = {"bm25": "keyword_top_k", "vector": "vector_top_k", "hybrid": "hybrid_top_k"}[mode]
                kwargs[key] = args.top_k
            try:
                hits = await retrieval_service.retrieve(mode, args.query, snap.kb_ids, **kwargs)
            except EmbeddingFailedError as e:
                # embedding 失败在工具内为 execution_failed 回传模型（FR-025）
                raise ToolFailure("execution_failed", f"向量检索失败：{e}") from e
            ctx.merge_chunks(hits)  # 去重累积 + sqlite_url 白名单
            tracing.set_output(span, {"count": len(hits), "chunk_ids": [c.chunk_id for c in hits]})
            tracing.set_retrieval_chunks(span, hits)  # 片段全文不截断（013 FR-002）
            if not hits:
                return ToolResult(success=True, code="empty_result", content='{"chunks": []}')
            return _ok({"chunks": _chunk_payload(hits)})
        finally:
            span.end()
    return _search


async def _rerank(args: RerankArgs, ctx: RequestRuntimeState) -> ToolResult:
    chunks = _resolve_chunks(ctx, args.chunk_ids)
    if ctx.snapshot.rerank_model is None:
        raise ToolFailure("execution_failed", "缺少 ReRank 模型配置")
    span = tracing.get_tracer().start_span("agent.rerank")
    try:
        ranked, degraded = await rerank_service.rerank(
            args.query, chunks, ctx.snapshot.rerank_model.name,
            top_n=args.top_n or ctx.snapshot.retrieval.rerank_top_n,
            span=span,
        )
        payload = {"chunks": _chunk_payload(ranked)}
        if degraded:
            payload["degraded"] = True
            ctx.events.append({"event": tracing.EVENT_RERANK_DEGRADED, "loop": ctx.loop})
        return _ok(payload)
    finally:
        span.end()


async def _zip(args: ZipArgs, ctx: RequestRuntimeState) -> ToolResult:
    chunks = _resolve_chunks(ctx, args.chunk_ids)
    span = tracing.get_tracer().start_span("agent.compress")
    tracing.set_prompt_attrs(span, ctx.snapshot.prompts["compress"], "compress")
    try:
        prompt = ctx.snapshot.prompts["compress"].content
        chunks_text = "\n\n".join(
            f"[{i}] ({c.file_name}) {c.content}" for i, c in enumerate(chunks)
        )
        rendered = steps.render_prompt(prompt, question=args.question, chunks=chunks_text)
        result = await llm_client.call_json(
            ctx.snapshot.analysis_model.name,
            [{"role": "user", "content": steps._json_prompt(rendered, CompressResult)}],
            CompressResult,
            purpose="compress",
            max_output_tokens=ctx.snapshot.max_output_tokens,
            extra_validator=lambda r: r.validate_bounds(len(chunks)),
            cancel_event=ctx.cancel_event,
            span=span,
        )
        kept_ids = [chunks[i].chunk_id for i in result.kept_indexes]
        tracing.set_output(span, {"kept_indexes": result.kept_indexes, "kept_chunk_ids": kept_ids})
        if not kept_ids:
            return ToolResult(success=True, code="empty_result", content='{"kept_chunk_ids": []}')
        return _ok({"kept_chunk_ids": kept_ids})
    except JsonValidationFailed as e:
        raise ToolFailure("execution_failed", f"压缩输出校验失败：{e.detail}") from e
    finally:
        span.end()


TOOLS = [
    ToolSpec("rewriteQuestion", "将问题改写为更适合检索的独立问题", RewriteQuestionArgs, _rewrite_question),
    ToolSpec("bm25Search", "关键词（BM25）检索知识库片段", SearchArgs, _search_handler("bm25")),
    ToolSpec("vectorSearch", "向量语义检索知识库片段", SearchArgs, _search_handler("vector")),
    ToolSpec("hybridSearch", "关键词+向量混合检索（RRF 融合）知识库片段", SearchArgs, _search_handler("hybrid")),
    ToolSpec("rerank", "对已检索片段按问题相关性精排（chunk_ids 限本次已检索片段）", RerankArgs, _rerank),
    ToolSpec("zip", "过滤式压缩：从已检索片段中筛选与问题相关的片段，返回 kept_chunk_ids", ZipArgs, _zip),
]