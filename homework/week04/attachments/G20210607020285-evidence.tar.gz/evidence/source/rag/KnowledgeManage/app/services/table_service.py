"""Table service — SQLite storage for spreadsheet data and standalone table processing."""

import io
import os
import csv
import json
import re
import sqlite3
import logging
import tempfile
from typing import List, Dict, Any, Optional, Tuple

import httpx

from app.core.config import settings
from app.services import storage_service
from app.services.embedding_service import resolve_model_name

logger = logging.getLogger(__name__)


# ─────────────────── SQLite Storage ───────────────────

async def generate_embedded_table_name(
    headers: list[str], fallback: str, model_id: str, *, caption: str = "",
) -> str:
    gateway = settings.services.get("llm_gateway", "http://localhost:8003")
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.post(
                f"{gateway}/api/llm/v1/chat/completions",
                headers={"Authorization": f"Bearer {settings.llm_api_key}"},
                json={
                    "model": resolve_model_name(model_id),
                    "stream": False,
                    "messages": [
                        {"role": "system", "content": "Return one English snake_case SQL table name, with no explanation."},
                        {"role": "user", "content": json.dumps({"caption": caption, "columns": headers}, ensure_ascii=False)},
                    ],
                },
            )
            response.raise_for_status()
            name = response.json()["choices"][0]["message"]["content"]
            if isinstance(name, str) and re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]{0,62}", name.strip()):
                name = name.strip().lower()
                if not name.startswith("sqlite_"):
                    return name
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError) as error:
        logger.warning("Table naming failed; using %s: %s", fallback, error)
        return fallback
    logger.warning("Model returned an invalid table name; using %s", fallback)
    return fallback


async def create_sqlite_db(
    sheets_data: List[Dict[str, Any]],
    kb_id: str,
    doc_id: str,
    table_name: str = "data",
) -> str:
    """Create a SQLite database from sheet data and upload to MinIO.

    Args:
        sheets_data: List of {"sheet_name": str, "headers": List[str], "rows": List[List[str]]}
        kb_id: Knowledge base ID
        doc_id: Document ID
        table_name: Base name for the table

    Returns:
        MinIO path of the uploaded SQLite db file
    """
    tmp_dir = tempfile.mkdtemp(prefix="sqlite_")
    db_filename = f"{table_name}.db"
    db_path = os.path.join(tmp_dir, db_filename)

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        column_descriptions = []
        used_tables = {"_column_descriptions"}
        for index, sheet in enumerate(sheets_data):
            sheet_name = sheet["sheet_name"]
            headers = sheet["headers"]
            rows = sheet["rows"]

            # Generate English table name (use sheet name as-is if already English)
            eng_table_name = _unique_identifier(sheet_name, f"sheet_{index}", used_tables)
            used_columns: set[str] = set()
            eng_headers = [
                _unique_identifier(header, f"col_{i}", used_columns)
                for i, header in enumerate(headers)
            ]
            column_descriptions.extend(
                (eng_table_name, name, header)
                for name, header in zip(eng_headers, headers)
                if re.search(r"[\u4e00-\u9fff]", header)
            )

            # Create table
            columns_def = ", ".join([f'"{h}" TEXT' for h in eng_headers])
            cursor.execute(f'CREATE TABLE IF NOT EXISTS "{eng_table_name}" ({columns_def})')

            # Insert rows
            if rows:
                placeholders = ", ".join(["?" for _ in headers])
                insert_sql = f'INSERT INTO "{eng_table_name}" VALUES ({placeholders})'
                cursor.executemany(insert_sql, [
                    [str(cell) if cell is not None else "" for cell in row]
                    for row in rows
                ])

        if column_descriptions:
            cursor.execute("CREATE TABLE _column_descriptions (table_name TEXT, column_name TEXT, description TEXT)")
            cursor.executemany("INSERT INTO _column_descriptions VALUES (?, ?, ?)", column_descriptions)
        conn.commit()
        conn.close()

        # Upload to MinIO
        with open(db_path, "rb") as f:
            db_bytes = f.read()

        minio_path = f"{kb_id}/{doc_id}/tables/{db_filename}"
        storage_service.upload_file(
            object_path=minio_path,
            data=io.BytesIO(db_bytes),
            length=len(db_bytes),
            content_type="application/x-sqlite3",
        )

        logger.info("Created SQLite db for doc %s: %s (%d bytes)", doc_id, minio_path, len(db_bytes))
        return minio_path

    finally:
        # Cleanup temp files
        if os.path.exists(db_path):
            os.unlink(db_path)
        if os.path.exists(tmp_dir):
            os.rmdir(tmp_dir)


# ─────────────────── Spreadsheet Processing ───────────────────


def validate_spreadsheet(file_path: str) -> Tuple[bool, str]:
    """Validate a spreadsheet file.

    Rules:
    - No merged cells
    - Headers must be in the first row
    - No empty rows

    Returns (is_valid, error_message).
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".csv":
        return _validate_csv(file_path)
    elif ext in (".xlsx", ".xls"):
        return _validate_xlsx(file_path)
    else:
        return False, f"不支持的文件类型: {ext}"


def read_spreadsheet(file_path: str) -> List[Dict[str, Any]]:
    """Read a spreadsheet file and return sheet data.

    Returns list of {"sheet_name": str, "headers": List[str], "rows": List[List[str]]}.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".csv":
        return _read_csv(file_path)
    elif ext in (".xlsx", ".xls"):
        return _read_xlsx(file_path)
    else:
        raise ValueError(f"不支持的文件类型: {ext}")


def table_rows_to_text(headers: List[str], rows: List[List[str]]) -> List[str]:
    """Convert table rows to preprocessed text format.

    Each row becomes: "Col1: val1, Col2: val2, ..."
    """
    result = []
    for row in rows:
        parts = []
        for h, v in zip(headers, row):
            val = str(v) if v is not None else ""
            parts.append(f"{h}: {val}")
        result.append(", ".join(parts))
    return result


# ─────────────────── Internal Helpers ───────────────────


def _to_english_identifier(name: str, fallback: str = "data") -> str:
    """Convert a string to a valid English identifier.

    If the name contains Chinese characters, use the fallback.
    Otherwise, sanitize the name.
    """
    if not name:
        return fallback

    # Check if name is already a valid English identifier
    sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", name.strip())
    sanitized = sanitized.strip("_")

    # If it starts with a digit, prefix with underscore
    if sanitized and sanitized[0].isdigit():
        sanitized = f"_{sanitized}"

    # If name contains Chinese characters, use fallback
    if any("\u4e00" <= c <= "\u9fff" for c in name):
        return fallback

    return sanitized or fallback


def _unique_identifier(name: str, fallback: str, used: set[str]) -> str:
    base = _to_english_identifier(name, fallback)
    if base.lower().startswith("sqlite_"):
        base = fallback
    candidate = base
    suffix = 2
    while candidate.lower() in used:
        candidate = f"{base}_{suffix}"
        suffix += 1
    used.add(candidate.lower())
    return candidate


def _validate_csv(file_path: str) -> Tuple[bool, str]:
    """Validate a CSV file."""
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            row_count = 0
            header_cols = 0
            for row in reader:
                row_count += 1
                if row_count == 1:
                    header_cols = len(row)
                    if not row or all(not cell.strip() for cell in row):
                        return False, "表头（第一行）不能为空"
                else:
                    # Check for empty rows
                    if not row or all(not cell.strip() for cell in row):
                        return False, f"第 {row_count} 行为空行"
        return True, ""
    except Exception as e:
        return False, f"CSV 读取失败: {e}"


def _validate_xlsx(file_path: str) -> Tuple[bool, str]:
    """Validate an Excel file."""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(file_path, data_only=True)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            # Check for merged cells
            if ws.merged_cells.ranges:
                return False, f"Sheet '{sheet_name}' 包含合并单元格"
            # Check first row has data
            first_row = [cell.value for cell in ws[1]]
            if not any(first_row):
                return False, f"Sheet '{sheet_name}' 表头为空"
            # Check for empty rows
            for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
                if row and all(cell is None or str(cell).strip() == "" for cell in row):
                    return False, f"Sheet '{sheet_name}' 第 {row_idx} 行为空行"
        wb.close()
        return True, ""
    except Exception as e:
        return False, f"Excel 读取失败: {e}"


def _read_csv(file_path: str) -> List[Dict[str, Any]]:
    """Read CSV file as a single sheet."""
    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        rows = list(reader)

    if not rows:
        return []

    headers = rows[0]
    data_rows = rows[1:]
    sheet_name = os.path.splitext(os.path.basename(file_path))[0]

    return [{
        "sheet_name": sheet_name,
        "headers": headers,
        "rows": data_rows,
    }]


def _read_xlsx(file_path: str) -> List[Dict[str, Any]]:
    """Read Excel file with multiple sheets."""
    import openpyxl
    wb = openpyxl.load_workbook(file_path, data_only=True)
    result = []

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows = []
        headers = []
        for row_idx, row in enumerate(ws.iter_rows(values_only=True)):
            if row_idx == 0:
                headers = [str(cell) if cell is not None else "" for cell in row]
            else:
                rows.append([str(cell) if cell is not None else "" for cell in row])

        if headers:
            result.append({
                "sheet_name": sheet_name,
                "headers": headers,
                "rows": rows,
            })

    wb.close()
    return result
