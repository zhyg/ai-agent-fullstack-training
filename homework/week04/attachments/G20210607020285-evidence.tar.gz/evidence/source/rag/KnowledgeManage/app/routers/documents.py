"""Document management router."""

import logging

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, Query, UploadFile, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.schemas.document import (
    DocumentResponse,
    DocumentUploadResponse,
    DocumentUploadItem,
    DocumentUpdate,
    DocumentPaginatedResponse,
    DocumentFileResponse,
    DocumentMarkdownPreviewResponse,
    TagAddRequest,
    TagRemoveRequest,
    BatchDeleteRequest,
    BatchDeleteResponse,
)
from app.schemas.chunk import ReprocessRequest
from app.services import document_service, document_status, markdown_attachments, markdown_preview, storage_service

logger = logging.getLogger(__name__)

router = APIRouter(tags=["文档管理"])


# ── Upload ──────────────────────────────────────────────────

@router.post(
    "/folders/{folder_id}/documents/upload",
    response_model=DocumentUploadResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload_document(
    folder_id: str,
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    original_filename: str | None = Form(None),
    original_filename_b64: str | None = Form(None),
    chunk_strategy: str = Form("heading"),
    chunk_size: int = Form(512),
    chunk_overlap: int = Form(80),
    separators: str | None = Form(None),
    ai_question_count: int = Form(3),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """上传文件到指定目录（支持普通文件和压缩包）。

    分块参数:
    - chunk_strategy: heading (按标题) / fixed (按固定长度)
    - chunk_size: 100-4000, 默认 512
    - chunk_overlap: 0-500, 默认 80
    - separators: 分隔符 JSON 数组
    - ai_question_count: AI 问题生成数 1-10
    """
    documents = document_service.upload_document(
        db,
        folder_id,
        current_user["id"],
        file,
        original_filename=original_filename,
        original_filename_b64=original_filename_b64,
        chunk_strategy=chunk_strategy,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=separators,
        ai_question_count=ai_question_count,
    )

    # Trigger background processing for each document
    for doc in documents:
        from app.services.document_pipeline import process_document
        background_tasks.add_task(
            process_document,
            doc_id=doc.id,
            kb_id=doc.kb_id,
        )

    return DocumentUploadResponse(
        documents=[
            DocumentUploadItem(
                id=doc.id,
                name=doc.name,
                status=doc.status,
                file_size=doc.file_size,
            )
            for doc in documents
        ],
        message="上传成功，正在处理...",
    )


# ── List ────────────────────────────────────────────────────

@router.get(
    "/folders/{folder_id}/documents",
    response_model=DocumentPaginatedResponse[DocumentResponse],
)
async def list_documents(
    folder_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取指定目录下的文档列表（分页）。"""
    items, total = document_service.list_documents(
        db, folder_id, current_user["id"], page, page_size
    )
    return DocumentPaginatedResponse[DocumentResponse](
        items=[DocumentResponse.from_orm_model(doc) for doc in items],
        total=total,
        page=page,
        page_size=page_size,
    )


# ── Detail ──────────────────────────────────────────────────

@router.get(
    "/documents/{document_id}",
    response_model=DocumentResponse,
)
async def get_document(
    document_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取文档详情。"""
    doc = document_service.get_document(db, document_id, current_user["id"])
    return DocumentResponse.from_orm_model(doc)


# ── Update ──────────────────────────────────────────────────

@router.put(
    "/documents/{document_id}",
    response_model=DocumentResponse,
)
async def update_document(
    document_id: str,
    data: DocumentUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """更新文档信息（描述、标签）。"""
    doc = document_service.update_document(
        db, document_id, current_user["id"], data.model_dump(exclude_unset=True)
    )
    return DocumentResponse.from_orm_model(doc)


# ── Tags ────────────────────────────────────────────────────

@router.put(
    "/documents/{document_id}/tags/add",
    response_model=DocumentResponse,
)
async def add_tags(
    document_id: str,
    data: TagAddRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """为文档追加标签（增量操作）。"""
    doc = document_service.add_tags(db, document_id, current_user["id"], data.tags)
    return DocumentResponse.from_orm_model(doc)


@router.put(
    "/documents/{document_id}/tags/remove",
    response_model=DocumentResponse,
)
async def remove_tag(
    document_id: str,
    data: TagRemoveRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """从文档中移除指定标签。"""
    doc = document_service.remove_tag(db, document_id, current_user["id"], data.tag)
    return DocumentResponse.from_orm_model(doc)


# ── Delete ──────────────────────────────────────────────────

async def _cleanup_doc_resources(kb_id: str, doc_id: str) -> None:
    """Async cleanup of ES chunks + MinIO intermediate files for a deleted document."""
    from app.services import es_chunk_service
    from app.services.storage_service import delete_objects_by_prefix
    try:
        await es_chunk_service.delete_by_document(kb_id, doc_id)
    except Exception as e:
        logger.warning("Failed to delete ES chunks for doc %s: %s", doc_id, e)
    for kind in ("markdown", "images", "tables", "attachments"):
        prefix = f"{kb_id}/{doc_id}/{kind}/"
        try:
            delete_objects_by_prefix(prefix)
        except Exception as e:
            logger.warning("Failed to clean MinIO prefix %s: %s", prefix, e)


@router.delete("/documents/{document_id}")
async def delete_document(
    document_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除单个文档（含 MinIO 对象 + ES chunks + 中间文件清理）。"""
    info = document_service.delete_document(db, document_id, current_user["id"])
    await _cleanup_doc_resources(info["kb_id"], info["doc_id"])
    return {"message": "文档已删除"}


@router.post(
    "/documents/batch-delete",
    response_model=BatchDeleteResponse,
)
async def batch_delete_documents(
    data: BatchDeleteRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """批量删除文档（含 ES chunks + 中间文件清理）。"""
    result = document_service.batch_delete_documents(
        db, data.document_ids, current_user["id"]
    )
    for kb_id, doc_id in result.get("deleted_docs", []):
        await _cleanup_doc_resources(kb_id, doc_id)
    return BatchDeleteResponse(
        deleted=result["deleted"],
        message=f"已删除 {result['deleted']} 篇",
    )


# ── File URL ────────────────────────────────────────────────

@router.get(
    "/documents/{document_id}/file",
    response_model=DocumentFileResponse,
)
async def get_document_file_url(
    document_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取文档原始文件的下载/预览 URL（MinIO presigned URL）。"""
    result = document_service.get_document_file_url(
        db, document_id, current_user["id"]
    )
    return DocumentFileResponse(url=result["url"], expires_in=result["expires_in"])


# ── Markdown URL ────────────────────────────────────────────

@router.get(
    "/documents/{document_id}/markdown",
    response_model=DocumentFileResponse,
)
async def get_document_markdown_url(
    document_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取文档解析后 Markdown 文件的预览 URL（MinIO presigned URL）。"""
    from app.services.storage_service import get_presigned_url

    doc = document_service.get_document(db, document_id, current_user["id"])
    if not doc.md_path:
        raise HTTPException(status_code=404, detail="Markdown 文件不存在")
    url = get_presigned_url(doc.md_path, expires=3600)
    return DocumentFileResponse(url=url, expires_in=3600)


@router.get(
    "/documents/{document_id}/markdown/preview",
    response_model=DocumentMarkdownPreviewResponse,
)
def get_document_markdown_preview(
    document_id: str,
    source: bool = False,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取 Markdown 预览内容，文档内图片使用临时签名地址。"""
    doc = document_service.get_document(db, document_id, current_user["id"])
    is_markdown = (doc.extension or "").lower() in {"md", "markdown"}
    if source and not is_markdown:
        raise HTTPException(status_code=404, detail="原文件不是 Markdown")
    path = doc.storage_path if source else doc.md_path
    if not path:
        raise HTTPException(status_code=404, detail="Markdown 文件不存在")
    try:
        markdown = storage_service.download_file(path).decode("utf-8")
        assets = markdown_attachments.shared_assets(db, document_id) if is_markdown else {}
        if source:
            markdown, _ = markdown_attachments.resolve_archive_images(
                markdown, doc.kb_id, document_id, signed=True, assets=assets,
            )
        else:
            markdown = markdown_preview.resolve_document_images(
                markdown, doc.kb_id, document_id, resolve_relative=not is_markdown,
                shared_keys=frozenset(assets.values()),
            )
    except storage_service.StorageError as exc:
        raise HTTPException(status_code=503, detail="暂时无法读取 Markdown 文件") from exc
    except UnicodeDecodeError as exc:
        logger.exception("Invalid UTF-8 in Markdown for document %s", document_id)
        raise HTTPException(status_code=500, detail="Markdown 文件编码无效") from exc
    return DocumentMarkdownPreviewResponse(content=markdown)


# ── Reprocess ──────────────────────────────────────────────

@router.post(
    "/documents/{document_id}/reprocess",
    response_model=DocumentResponse,
)
async def reprocess_document(
    document_id: str,
    background_tasks: BackgroundTasks,
    data: ReprocessRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """用新的分块参数重新处理已完成的文档。"""
    doc = document_service.reprocess_document(
        db, document_id, current_user["id"], data
    )
    await document_status.notify(document_id)

    # Trigger background reprocessing
    from app.services.document_pipeline import process_document
    background_tasks.add_task(
        process_document,
        doc_id=doc.id,
        kb_id=doc.kb_id,
    )

    return DocumentResponse.from_orm_model(doc)
