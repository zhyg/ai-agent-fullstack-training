"""知识库检索服务：BM25 / 向量 / 混合 RRF（research.md R7，FR-008/012）.

- BM25：match on content，size=keyword_top_k；
- 向量：script_score cosineSimilarity+1.0（兼容存量 dense_vector mapping），size=vector_top_k；
- 混合：两路召回后 Python RRF 融合（score=Σ1/(k+rank)，k 默认 60），按 chunk_id 去重截断 hybrid_top_k；
- 多知识库：ES 多索引查询 ignore_unavailable=True（索引不存在=空结果）；
- 向量化复用 embedding_service.generate_embeddings，失败抛流程级异常；ES 不可用/超时抛流程级异常。
"""
import logging
from typing import Dict, List, Optional

from elasticsearch import ApiError, TransportError

from app.core import es_client
from app.core.config import settings
from app.services import embedding_service
from app.services.agent_runtime.state import ContextChunk

logger = logging.getLogger(__name__)

_INDEX_PREFIX = "knowledge_chunks_"


class RetrievalUnavailableError(Exception):
    """ES 不可用/超时（流程级异常，终止流程报错前端）."""


class EmbeddingFailedError(Exception):
    """问题向量化经网关重试后仍失败（流程级异常，终止流程报错前端）."""


def _index_names(kb_ids: List[str]) -> str:
    return ",".join(f"{_INDEX_PREFIX}{kb_id}" for kb_id in kb_ids)


def _hit_to_chunk(hit: dict) -> ContextChunk:
    src = hit.get("_source") or {}
    index = hit.get("_index", "")
    kb_id = index[len(_INDEX_PREFIX):] if index.startswith(_INDEX_PREFIX) else ""
    return ContextChunk(
        chunk_id=src.get("chunk_id") or hit.get("_id", ""),
        document_id=src.get("document_id", ""),
        kb_id=kb_id,
        file_name=src.get("file_name", ""),
        content=src.get("content", ""),
        chunk_type=src.get("chunk_type", "text"),
        sqlite_url=src.get("sqlite_url") or None,
        score=float(hit.get("_score") or 0.0),
    )


async def _search(client, indices: str, body: dict) -> List[dict]:
    try:
        resp = await client.search(
            index=indices,
            body=body,
            ignore_unavailable=True,
        )
    except (ApiError, TransportError) as e:
        logger.error("ES search failed: %s", e)
        raise RetrievalUnavailableError(f"检索服务不可用: {e}") from e
    return (resp.get("hits") or {}).get("hits") or []


async def _bm25_hits(client, indices: str, question: str, top_k: int) -> List[dict]:
    return await _search(client, indices, {
        "query": {"match": {"content": question}},
        "size": top_k,
        "_source": {"excludes": ["embeddings"]},
    })


async def _vector_hits(
    client, indices: str, question: str, top_k: int, embedding_model_id: str
) -> List[dict]:
    try:
        vectors = await embedding_service.generate_embeddings([question], embedding_model_id)
    except Exception as e:
        logger.error("Question embedding failed: %s", e)
        raise EmbeddingFailedError(f"问题向量化失败: {e}") from e
    if not vectors or not vectors[0]:
        raise EmbeddingFailedError("问题向量化失败: 空向量")
    return await _search(client, indices, {
        "query": {
            "script_score": {
                "query": {"match_all": {}},
                "script": {
                    "source": "cosineSimilarity(params.qv, 'embeddings') + 1.0",
                    "params": {"qv": vectors[0]},
                },
            }
        },
        "size": top_k,
        "_source": {"excludes": ["embeddings"]},
    })


def _rrf_fuse(
    bm25_chunks: List[ContextChunk],
    vector_chunks: List[ContextChunk],
    top_k: int,
    rrf_k: int,
) -> List[ContextChunk]:
    """RRF 融合：按名次而非原始分（规避 BM25 跨索引分数不可比），chunk_id 去重."""
    fused: Dict[str, ContextChunk] = {}
    scores: Dict[str, float] = {}
    for hits in (bm25_chunks, vector_chunks):
        for rank, chunk in enumerate(hits, start=1):
            scores[chunk.chunk_id] = scores.get(chunk.chunk_id, 0.0) + 1.0 / (rrf_k + rank)
            if chunk.chunk_id not in fused:
                fused[chunk.chunk_id] = chunk
    ordered = sorted(fused.values(), key=lambda c: scores[c.chunk_id], reverse=True)
    for chunk in ordered:
        chunk.score = scores[chunk.chunk_id]
    return ordered[:top_k]


async def retrieve(
    mode: str,
    question: str,
    kb_ids: List[str],
    *,
    vector_top_k: int = 20,
    keyword_top_k: int = 20,
    hybrid_top_k: int = 20,
    embedding_model_id: Optional[str] = None,
    rrf_k: Optional[int] = None,
) -> List[ContextChunk]:
    """按检索方式召回片段；mode: bm25/keyword/vector/hybrid（keyword 为配置侧别名）.

    召回数量各 1–100（快照已校验）；索引不存在等同空结果。
    """
    if not kb_ids:
        return []
    rrf_k = rrf_k if rrf_k is not None else settings.agent_runtime.rrf_k
    client = await es_client.get_async_client()
    indices = _index_names(kb_ids)
    mode = "bm25" if mode == "keyword" else mode

    if mode == "bm25":
        hits = await _bm25_hits(client, indices, question, keyword_top_k)
        return [_hit_to_chunk(h) for h in hits]

    if mode == "vector":
        if not embedding_model_id:
            raise EmbeddingFailedError("向量检索缺少向量模型配置")
        hits = await _vector_hits(client, indices, question, vector_top_k, embedding_model_id)
        return [_hit_to_chunk(h) for h in hits]

    if mode == "hybrid":
        if not embedding_model_id:
            raise EmbeddingFailedError("混合检索缺少向量模型配置")
        bm25_hits, vector_hits = (
            await _bm25_hits(client, indices, question, keyword_top_k),
            await _vector_hits(client, indices, question, vector_top_k, embedding_model_id),
        )
        return _rrf_fuse(
            [_hit_to_chunk(h) for h in bm25_hits],
            [_hit_to_chunk(h) for h in vector_hits],
            hybrid_top_k,
            rrf_k,
        )

    raise ValueError(f"未知检索方式: {mode}")