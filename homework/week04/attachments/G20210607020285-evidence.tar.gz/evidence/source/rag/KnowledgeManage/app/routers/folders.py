"""Folder management router."""

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.schemas.folder import (
    FolderCreate,
    FolderUpdate,
    FolderResponse,
    FolderMoveRequest,
    FolderMoveResponse,
    FolderDeleteResponse,
)
from app.services import folder_service

logger = logging.getLogger(__name__)

router = APIRouter(tags=["目录管理"])


@router.get(
    "/knowledge-bases/{kb_id}/folders",
    response_model=dict,
)
async def list_folders(
    kb_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取知识库下的所有目录列表。"""
    try:
        folders = folder_service.list_folders(db, kb_id, current_user["id"])
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    return {
        "items": [FolderResponse.model_validate(f) for f in folders],
    }


@router.post(
    "/knowledge-bases/{kb_id}/folders",
    response_model=FolderResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_folder(
    kb_id: str,
    body: FolderCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """创建新目录（根目录或子目录）。"""
    try:
        folder = folder_service.create_folder(db, kb_id, current_user["id"], body)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    return FolderResponse.model_validate(folder)


@router.put("/folders/{folder_id}", response_model=FolderResponse)
async def update_folder(
    folder_id: str,
    body: FolderUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """更新目录（重命名或移动）。"""
    try:
        folder = folder_service.update_folder(db, folder_id, current_user["id"], body)
    except ValueError as exc:
        detail = str(exc)
        if "子孙目录" in detail:
            raise HTTPException(
                status_code=status.HTTP_UNPROCESSABLE_ENTITY, detail=detail
            )
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=detail)
    return FolderResponse.model_validate(folder)


@router.delete("/folders/{folder_id}", response_model=FolderDeleteResponse)
async def delete_folder(
    folder_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除目录及其所有子目录和关联文档（含 ES chunks + 中间文件清理）。"""
    try:
        counts = folder_service.delete_folder(db, folder_id, current_user["id"])
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))

    # Async cleanup of ES chunks + MinIO intermediate files for all deleted docs
    from app.services import es_chunk_service
    from app.services.storage_service import delete_objects_by_prefix
    for kb_id, doc_id in counts.get("deleted_docs", []):
        try:
            await es_chunk_service.delete_by_document(kb_id, doc_id)
        except Exception as e:
            logger.warning("Failed to delete ES chunks for doc %s: %s", doc_id, e)
        for kind in ("markdown", "images", "tables", "attachments"):
            prefix = f"{kb_id}/{doc_id}/{kind}/"
            try:
                delete_objects_by_prefix(prefix)
            except Exception as e:
                logger.warning("Failed to clean MinIO prefix %s: %s", prefix, e)

    return FolderDeleteResponse(
        message="目录删除成功",
        deleted_folders=counts["deleted_folders"],
        deleted_documents=counts["deleted_documents"],
    )


@router.put("/folders/{folder_id}/move", response_model=FolderMoveResponse)
async def move_folder(
    folder_id: str,
    body: FolderMoveRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """拖拽移动目录到新位置。"""
    try:
        result = folder_service.move_folder(db, folder_id, current_user["id"], body)
    except ValueError as exc:
        detail = str(exc)
        if "子孙目录" in detail:
            raise HTTPException(
                status_code=status.HTTP_UNPROCESSABLE_ENTITY, detail=detail
            )
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=detail)
    return FolderMoveResponse(
        folder=FolderResponse.model_validate(result["folder"]),
        renamed=result["renamed"],
        original_name=result["original_name"],
    )
