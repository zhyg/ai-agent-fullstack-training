"""引用协议单测（T027）：句柄分配 / 上下文注入 / references / 图片重签 / 流式 ref 过滤."""
import unittest
from unittest.mock import patch

from app.services.agent_runtime import citation
from app.services.agent_runtime.citation import RefStreamFilter
from app.services.agent_runtime.state import ContextChunk


def make_chunk(chunk_id="ch1", content="正文", file_name="a.pdf", **extra):
    return ContextChunk(
        chunk_id=chunk_id, document_id=f"doc-{chunk_id}", kb_id="kb1",
        file_name=file_name, content=content, **extra,
    )


class HandleAndContextTests(unittest.TestCase):
    def test_assign_handles_sequential(self):
        chunks = [make_chunk("a"), make_chunk("b"), make_chunk("c")]
        handle_map = citation.assign_handles(chunks)
        self.assertEqual([c.handle for c in chunks], ["c1", "c2", "c3"])
        self.assertIs(handle_map["c2"], chunks[1])

    def test_build_context_text_format_and_presign(self):
        chunks = [make_chunk("a", content="见 ![图](kb1/doc-a/images/x.png)"), make_chunk("b", file_name="b.docx")]
        citation.assign_handles(chunks)
        with patch.object(citation.storage_service, "get_presigned_url", return_value="http://signed/x.png") as presign:
            text = citation.build_context_text(chunks)
        presign.assert_called_once_with("kb1/doc-a/images/x.png", expires=citation.settings.agent_runtime.presign_expires)
        self.assertIn("[c1] (a.pdf) 见 ![图](http://signed/x.png)", text)
        self.assertIn("[c2] (b.docx) 正文", text)
        self.assertIn("\n\n", text)

    def test_build_references_keeps_raw_image_paths(self):
        chunk = make_chunk("a", content="![图](kb1/doc-a/images/x.png) 与 ![外](https://cdn/y.png)", score=0.7)
        citation.assign_handles([chunk])
        with patch.object(citation.storage_service, "get_presigned_url", return_value="http://signed/x.png"):
            refs = citation.build_references([chunk])
        self.assertEqual(len(refs), 1)
        ref = refs[0]
        self.assertEqual(ref.handle, "c1")
        self.assertEqual(ref.chunk_id, "a")
        self.assertEqual(ref.kb_id, "kb1")
        self.assertIn("http://signed/x.png", ref.content)
        self.assertEqual(ref.image_paths, ["kb1/doc-a/images/x.png"])  # 原始路径供重签
        self.assertEqual(ref.score, 0.7)

    def test_extract_image_paths_skips_urls(self):
        content = "![a](kb1/d/images/a.png) ![b](http://x/b.png) ![c](data:image/png;base64,xx)"
        self.assertEqual(citation.extract_image_paths(content), ["kb1/d/images/a.png"])


class PresignTests(unittest.TestCase):
    def test_presign_image_passthrough_urls(self):
        for url in ("http://x/a.png", "https://x/a.png", "data:image/png;base64,xx"):
            self.assertEqual(citation.presign_image(url), url)

    def test_presign_image_failure_keeps_path(self):
        with patch.object(citation.storage_service, "get_presigned_url", side_effect=RuntimeError("minio down")):
            self.assertEqual(citation.presign_image("kb1/d/images/a.png"), "kb1/d/images/a.png")

    def test_refresh_signed_urls_extracts_key_and_resigns(self):
        content = "![图](http://minio:9000/km-bucket/kb1/d/images/a%20b.png?X-Amz-Expires=86400&sig=old)"
        with patch("app.core.minio_client.get_bucket", return_value="km-bucket"), \
             patch.object(citation.storage_service, "get_presigned_url", return_value="http://minio:9000/new?sig=new") as presign:
            refreshed = citation.refresh_signed_urls(content)
        presign.assert_called_once_with("kb1/d/images/a b.png", expires=citation.settings.agent_runtime.presign_expires)
        self.assertEqual(refreshed, "![图](http://minio:9000/new?sig=new)")

    def test_refresh_signed_urls_raw_path_and_failure(self):
        with patch.object(citation.storage_service, "get_presigned_url", return_value="http://signed/a.png"):
            self.assertEqual(citation.refresh_signed_urls("![图](kb1/d/images/a.png)"), "![图](http://signed/a.png)")
        old = "![图](http://minio:9000/km-bucket/kb1/d/images/a.png?sig=old)"
        with patch("app.core.minio_client.get_bucket", side_effect=RuntimeError("down")):
            self.assertEqual(citation.refresh_signed_urls(old), old)  # 失败保留原值


class RefStreamFilterTests(unittest.TestCase):
    def test_valid_tag_passthrough(self):
        f = RefStreamFilter({"c1", "c2"})
        out = f.feed('结论<ref id="c1"/><ref id="c2"/>。')
        self.assertEqual(out + f.flush(), '结论<ref id="c1"/><ref id="c2"/>。')

    def test_invalid_handle_dropped_with_callback(self):
        invalid = []
        f = RefStreamFilter({"c1"}, on_invalid=invalid.append)
        out = f.feed('x<ref id="c99"/>y') + f.flush()
        self.assertEqual(out, "xy")
        self.assertEqual(invalid, ["c99"])

    def test_tag_split_across_deltas(self):
        f = RefStreamFilter({"c1"})
        out = f.feed("答案<re")
        out += f.feed('f id="c')
        out += f.feed('1"/')
        out += f.feed(">后续")
        out += f.flush()
        self.assertEqual(out, '答案<ref id="c1"/>后续')

    def test_whitespace_variant_tag(self):
        f = RefStreamFilter({"c1"})
        out = f.feed('<ref  id="c1" />') + f.flush()
        self.assertEqual(out, '<ref  id="c1" />')

    def test_non_ref_angle_bracket_passthrough(self):
        f = RefStreamFilter({"c1"})
        out = f.feed("a < b 且 <div>文本</div> 1<2") + f.flush()
        self.assertEqual(out, "a < b 且 <div>文本</div> 1<2")

    def test_flush_drops_incomplete_tail(self):
        invalid = []
        f = RefStreamFilter({"c1"}, on_invalid=invalid.append)
        out = f.feed('正文<ref id="c1')
        self.assertEqual(out, "正文")  # 疑似不完整前缀被缓冲
        self.assertEqual(f.flush(), "")  # 流结束仍不完整 → 丢弃
        self.assertEqual(invalid, ['<ref id="c1'])

    def test_overlong_pending_not_buffered(self):
        f = RefStreamFilter({"c1"})
        long_tail = '<ref id="' + "9" * 60
        out = f.feed(long_tail) + f.flush()
        self.assertEqual(out, long_tail)  # 超 48 字符不再视为疑似标签，原样放行

    def test_curly_quote_tag_normalized_to_straight(self):
        f = RefStreamFilter({"c1", "c2"})
        out = f.feed('结论<ref id=“c1”/><ref id=“c2”/>。') + f.flush()
        self.assertEqual(out, '结论<ref id="c1"/><ref id="c2"/>。')

    def test_curly_quote_tag_split_across_deltas(self):
        f = RefStreamFilter({"c1"})
        out = f.feed("答案<re")
        out += f.feed('f id=“c')
        out += f.feed('1”/')
        out += f.feed(">后续")
        out += f.flush()
        self.assertEqual(out, '答案<ref id="c1"/>后续')

    def test_curly_quote_invalid_handle_dropped(self):
        invalid = []
        f = RefStreamFilter({"c1"}, on_invalid=invalid.append)
        out = f.feed('x<ref id=“c9”/>y') + f.flush()
        self.assertEqual(out, "xy")
        self.assertEqual(invalid, ["c9"])


if __name__ == "__main__":
    unittest.main()