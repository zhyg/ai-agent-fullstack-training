import base64
import unittest
from unittest.mock import patch

import httpx

from app.services import parsing_service


class MineruImageTests(unittest.IsolatedAsyncioTestCase):
    async def test_docx_uploads_both_data_uri_images_without_prefix_bytes(self):
        png = b"\x89PNG\r\n\x1a\npng bytes"
        jpeg = b"\xff\xd8\xffjpeg bytes"
        payload = {
            "results": {
                "sample": {
                    "md_content": "![](images/a.png)\n![](images/b.jpg)",
                    "images": {
                        "a.png": "data:image/png;base64," + base64.b64encode(png).decode(),
                        "b.jpg": "data:image/jpeg;base64," + base64.b64encode(jpeg).decode(),
                    },
                },
            },
        }
        transport = httpx.MockTransport(lambda request: httpx.Response(200, json=payload))
        client = httpx.AsyncClient(transport=transport)

        with patch.object(parsing_service.httpx, "AsyncClient", return_value=client), \
                patch.object(parsing_service.storage_service, "upload_file") as upload:
            result = await parsing_service._parse_with_mineru(
                b"docx", "sample.docx", "kb", "doc",
            )

        image_uploads = {
            call.kwargs["object_path"]: (
                call.kwargs["data"].getvalue(),
                call.kwargs["length"],
                call.kwargs["content_type"],
            )
            for call in upload.call_args_list
            if call.kwargs["content_type"].startswith("image/")
        }
        self.assertEqual(image_uploads, {
            "kb/doc/images/a.png": (png, len(png), "image/png"),
            "kb/doc/images/b.jpg": (jpeg, len(jpeg), "image/jpeg"),
        })
        self.assertEqual(
            result["markdown_text"],
            "![](kb/doc/images/a.png)\n![](kb/doc/images/b.jpg)",
        )

    def test_bare_base64_is_supported_and_invalid_payloads_are_logged(self):
        payload = {"results": {"sample": {"images": {
            "bare.png": "aW1hZ2U=",
            "invalid.png": "data:image/png;base64,%%%",
            "bad_header.png": "data:image/png,aW1hZ2U=",
        }}}}

        with self.assertLogs(parsing_service.logger, level="WARNING") as logs:
            images = parsing_service._extract_images_from_response(payload)

        self.assertEqual(images, {"bare.png": b"image"})
        self.assertIn("invalid.png", logs.output[0])
        self.assertIn("bad_header.png", logs.output[1])
