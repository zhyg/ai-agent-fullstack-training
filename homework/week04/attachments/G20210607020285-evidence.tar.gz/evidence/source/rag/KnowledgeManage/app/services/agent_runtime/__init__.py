"""Agent runtime package: 三类智能体问答流程编排（specs/012-agent-logic-runtime）.

模块清单（见 plan.md Project Structure）：
- state: 请求级内存运行态（RequestRuntimeState / ContextChunk / Plan）
- snapshot: 配置快照与开跑前全量预检
- llm_client: LlmGateway OpenAI 兼容客户端（JSON 调用 + 流式）
- steps: 澄清/重写/压缩/充足判断/答案生成共用步骤
- citation: cN 引用协议与流式后处理
- budget: token 预算估算与淘汰
- tracing: OpenTelemetry 轨迹采集
- flows: quick_qa / reasoning_action / planning_reasoning
- tools: 统一受控 Tool Runtime 与 13 工具

run_agent_generation 为统一入口（T018）：快照预检→按 agent_type 分发 flow→
异常映射为 error 契约；终态落库与终止事件由 chat_service 骨架完成。
"""
import logging
from typing import Awaitable, Callable, Dict, List

logger = logging.getLogger(__name__)

# agent_type → flow runner（各 flow 实现后注册；未注册类型视为配置失效）
_FLOW_RUNNERS: Dict[str, Callable] = {}


def register_flow(agent_type: str, runner: Callable) -> None:
    _FLOW_RUNNERS[agent_type] = runner


def _get_runner(agent_type: str) -> Callable:
    if agent_type == "quick_qa" and agent_type not in _FLOW_RUNNERS:
        from app.services.agent_runtime.flows import quick_qa
        register_flow("quick_qa", quick_qa.run_quick_qa)
    if agent_type == "reasoning_action" and agent_type not in _FLOW_RUNNERS:
        from app.services.agent_runtime.flows import reasoning_action
        register_flow("reasoning_action", reasoning_action.run_reasoning_action)
    if agent_type == "planning_reasoning" and agent_type not in _FLOW_RUNNERS:
        from app.services.agent_runtime.flows import planning_reasoning
        register_flow("planning_reasoning", planning_reasoning.run_planning_reasoning)
    runner = _FLOW_RUNNERS.get(agent_type)
    if runner is None:
        from app.services.agent_runtime.snapshot import ConfigInvalidError
        raise ConfigInvalidError([f"暂不支持的智能体类型：{agent_type}"])
    return runner


async def run_agent_generation(
    *,
    chat_id: str,
    user_id: str,
    question: str,
    history: List[dict],
    generation_id: str,
    cancel_event,
    emit: Callable[[str], Awaitable[None]],
) -> dict:
    """智能体问答统一入口：快照→按 agent_type 分发 flow→异常映射.

    Args:
        question: 本轮用户问题（恢复/接管时取自已落库 user 消息）
        history: 会话历史 [{role, content}]（含本轮问题）
        cancel_event: asyncio.Event，chat_service 取消信号（Redis/停止/断线宽限）
        emit: 异步回调，将 SSE 事件字符串写入 _GenerationJob 队列/Redis Stream

    Returns:
        {content, meta, trace_id, cancelled, error?}；由 chat_service 终态落库与
        终止事件（done/cancelled/error）下发。内部捕获 AgentCancelled 返回部分答案
        （cancelled=True），不向调用方抛出。
    """
    from app.core.database import SessionLocal
    from app.models.chat import Chat
    from app.services.agent_runtime import budget, tracing
    from app.services.agent_runtime.llm_client import (
        AgentCancelled,
        JsonValidationFailed,
        ModelUnavailableError,
    )
    from app.services.agent_runtime.snapshot import ConfigInvalidError, build_snapshot
    from app.services.agent_runtime.state import RequestRuntimeState
    from app.services.retrieval_service import EmbeddingFailedError, RetrievalUnavailableError

    tracer = tracing.get_tracer()
    state = None
    trace_id = ""

    def _error(code: str, message: str, raw_output: str = "") -> dict:
        err = {"code": code, "message": message}
        if raw_output:
            err["raw_output"] = raw_output
        return {"content": "", "meta": {}, "trace_id": trace_id, "cancelled": False, "error": err}

    with tracer.start_as_current_span("agent.run") as root:
        root.set_attribute("chat.id", chat_id)
        root.set_attribute("agent.generation_id", generation_id)
        root.set_attribute(tracing.ATTR_USER, user_id)
        root.set_attribute(tracing.ATTR_SESSION, chat_id)
        trace_id = tracing.trace_id_hex(root)
        db = SessionLocal()
        try:
            chat = db.query(Chat).filter(Chat.id == chat_id).first()
            if chat is None or not chat.agent_id:
                return _error("config_invalid", "会话不存在或未绑定智能体")
            snapshot = build_snapshot(db, chat.agent_id, chat.knowledge_base_ids or [], user_id)
            root.set_attribute("agent.id", snapshot.agent_id)
            root.set_attribute("agent.type", snapshot.agent_type)

            state = RequestRuntimeState(
                generation_id=generation_id,
                chat_id=chat_id,
                user_id=user_id,
                snapshot=snapshot,
                question=question,
                history=budget.trim_history_rounds(history),
                cancel_event=cancel_event,
            )
            state.trace_id = trace_id

            # 013 R8：历史检索每请求一次，flow 分发前执行（三个 langgraph 图零改动）
            from app.services import history_qa_service
            await history_qa_service.retrieve_and_assemble(state, emit)

            runner = _get_runner(snapshot.agent_type)
            result = await runner(state, emit)
            return {
                "content": result.get("content") or "",
                "meta": dict(result.get("meta") or {}),
                "trace_id": trace_id,
                "cancelled": False,
                # 013 R5：供 chat_service 异步写入触发用，不进 meta（避免污染消息落库）
                "embedding_model_id": snapshot.embedding_model.model_id if snapshot.embedding_model else "",
            }
        except AgentCancelled:
            tracing.add_event(root, "agent_cancelled", {"partial_chars": len(state.partial_answer) if state else 0})
            return {
                "content": state.partial_answer if state else "",
                "meta": {"stopped": True},
                "trace_id": trace_id,
                "cancelled": True,
            }
        except ConfigInvalidError as e:
            tracing.add_event(root, "flow_error", {"code": e.code, "message": str(e)})
            return _error(e.code, str(e))
        except JsonValidationFailed as e:
            tracing.add_event(root, "flow_error", {"code": e.code, "message": e.detail})
            return _error(e.code, f"模型输出格式校验失败：{e.detail}", e.raw_output)
        except EmbeddingFailedError as e:
            tracing.add_event(root, "flow_error", {"code": "embedding_failed", "message": str(e)})
            return _error("embedding_failed", str(e))
        except RetrievalUnavailableError as e:
            tracing.add_event(root, "flow_error", {"code": "retrieval_unavailable", "message": str(e)})
            return _error("retrieval_unavailable", str(e))
        except ModelUnavailableError as e:
            tracing.add_event(root, "flow_error", {"code": "model_unavailable", "message": str(e)})
            return _error("model_unavailable", str(e))
        except Exception as e:
            logger.exception("agent_generation internal error chat_id=%s", chat_id)
            tracing.add_event(root, "flow_error", {"code": "internal_error", "message": str(e)})
            return _error("internal_error", f"智能体运行失败: {e}")
        finally:
            db.close()
            # 缩短 BatchSpanProcessor 落盘窗口（FR-033）；导出失败仅记日志
            tracing.finalize_tracing()