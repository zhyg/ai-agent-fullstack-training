"""Chunk query router."""

import io
import os
import re
import sqlite3
import tempfile
import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.models.document import Document
from app.models.knowledge_base import KnowledgeBase
from app.schemas.chunk import (
    ChunkResponse,
    ChunkListResponse,
    ChunkChildResponse,
    TableDataResponse,
)
from app.services import es_chunk_service, markdown_attachments, storage_service
from app.services.markdown_preview import rewrite_image_urls

logger = logging.getLogger(__name__)

# Relative path pattern: matches paths like "images/xxx.png" or "./images/xxx.png"
# that are missing the kb_id/doc_id prefix.
_RELATIVE_IMAGE_RE = re.compile(r"^(?:\./)?images/[\w\-.]+$")

# Detects a deeply-nested MinIO path where kb_id/doc_id/images/ repeats
# (caused by legacy bug where MinerU image key contained path separators).
# Captures the final image filename.
_NESTED_IMAGE_RE = re.compile(
    r"(?:[0-9a-f-]+/[0-9a-f-]+/images/){2,}([\w\-.]+)$"
)


def _is_minio_path(path: str) -> bool:
    """Check if a string looks like a MinIO object path (not a URL)."""
    return bool(path) and not path.startswith(("http://", "https://", "data:"))


def _normalize_image_path(path: str, kb_id: str = "", doc_id: str = "") -> str:
    """Normalize any image path variant to the canonical MinIO object path.

    Handles:
    - URLs (http/https/data:) — returned as-is
    - Canonical MinIO path ``{kb_id}/{doc_id}/images/{filename}`` — returned as-is
    - Legacy nested paths where ``kb_id/doc_id/images/`` repeats multiple times
      — flattened to canonical form
    - Relative paths like ``images/xxx.png`` — prepended with ``{kb_id}/{doc_id}/``
    """
    if not path:
        return path
    # Already a URL
    if path.startswith(("http://", "https://", "data:")):
        return path

    parts = path.split("/")
    if len(parts) >= 3 and parts[2] == "attachments":
        if len(parts) == 4 and parts[:2] == [kb_id, doc_id] and parts[3] not in {"", ".", ".."}:
            return path
        return ""

    # Extract the final image filename (works for both / and \ separators)
    filename = path.rsplit("/", 1)[-1] if "/" in path else path.rsplit("\\", 1)[-1]

    # Canonical path: kb_id/doc_id/images/filename — exactly 4 segments
    canonical_prefix = f"{kb_id}/{doc_id}/images/" if kb_id and doc_id else ""

    # 1. Already a clean canonical path
    if canonical_prefix and path == f"{canonical_prefix}{filename}":
        return path

    # 2. Nested legacy path: kb_id/doc_id/images/kb_id/doc_id/images/.../filename
    if kb_id and path.startswith(f"{kb_id}/"):
        if canonical_prefix:
            return f"{canonical_prefix}{filename}"
        return path

    # 3. Relative path like "images/xxx.png" or "./images/xxx.png"
    if _RELATIVE_IMAGE_RE.match(path):
        if canonical_prefix:
            return f"{canonical_prefix}{filename}"

    # 4. Any other non-URL path that looks like it contains images/
    if "/images/" in path or path.startswith("images/"):
        if canonical_prefix:
            return f"{canonical_prefix}{filename}"

    return path


def _resolve_presigned_url(path: str, expires: int = 86400) -> str:
    """Convert a MinIO object path to a presigned URL, or return as-is if already a URL."""
    if _is_minio_path(path):
        try:
            return storage_service.get_presigned_url(path, expires=expires)
        except Exception as e:
            logger.warning("Failed to generate presigned URL for %s: %s", path, e)
            return path
    return path


def _resolve_chunk_image_urls(
    chunk: dict,
    kb_id: str = "",
    doc_id: str = "",
    *,
    source_key: str | None = None,
    shared_keys: frozenset[str] = frozenset(),
) -> dict:
    """Post-process a chunk dict: convert MinIO paths to presigned URLs in content and image_url.

    Preserve the current document's original storage key; normalize legacy
    embedded image paths (e.g. ``images/xxx.png``) separately.
    """
    def resolve(path: str) -> str:
        if path in shared_keys:
            return storage_service.get_shared_image_url(path)
        if not path.startswith(("http://", "https://", "data:")) and path.split("/", 2)[1:2] == ["archive-images"]:
            return ""
        if path == source_key:
            return _resolve_presigned_url(path)
        return _resolve_presigned_url(_normalize_image_path(path, kb_id, doc_id))

    # Resolve image_url field
    img_url = chunk.get("image_url")
    if isinstance(img_url, str) and img_url:
        chunk["image_url"] = resolve(img_url)
    elif isinstance(img_url, list):
        resolved = []
        for u in img_url:
            if u:
                url = resolve(u)
                if url:
                    resolved.append(url)
        chunk["image_url"] = resolved

    # Resolve MinIO paths in content (markdown image syntax)
    content = chunk.get("content", "")
    if content:
        chunk["content"] = rewrite_image_urls(
            content,
            resolve,
        )

    return chunk

router = APIRouter(tags=["文档分片"])


# ── Chunk List ─────────────────────────────────────────────

@router.get(
    "/documents/{document_id}/chunks",
    response_model=ChunkListResponse,
)
async def list_document_chunks(
    document_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    chunk_type: str | None = Query(None, description="过滤类型: text/image/table_row/ai_question"),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取文档的分片列表（仅顶层 chunks，不含子 chunks）。"""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="文档不存在")

    # Verify ownership
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == doc.kb_id, KnowledgeBase.user_id == current_user["id"]
    ).first()
    if not kb:
        raise HTTPException(status_code=404, detail="无权访问")

    items, total = await es_chunk_service.query_chunks(
        kb_id=doc.kb_id,
        document_id=document_id,
        page=page,
        page_size=page_size,
        chunk_type=chunk_type,
    )
    # Convert MinIO paths to presigned URLs for frontend display
    keys = frozenset(markdown_attachments.shared_assets(db, document_id).values())
    items = [
        _resolve_chunk_image_urls(item, doc.kb_id, document_id, source_key=doc.storage_path, shared_keys=keys)
        for item in items
    ]
    return ChunkListResponse(
        items=[ChunkResponse(**item) for item in items],
        total=total,
        page=page,
        page_size=page_size,
    )


# ── Chunk Children ─────────────────────────────────────────

@router.get(
    "/chunks/{chunk_id}/children",
    response_model=ChunkChildResponse,
)
async def get_chunk_children(
    chunk_id: str,
    kb_id: str = Query(..., description="知识库 ID"),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取指定 chunk 的所有子 chunks（image_ocr/image_caption/ai_question）。"""
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == kb_id, KnowledgeBase.user_id == current_user["id"]
    ).first()
    if not kb:
        raise HTTPException(status_code=404, detail="无权访问")

    children = await es_chunk_service.get_children(kb_id=kb_id, chunk_id=chunk_id)
    parent = await es_chunk_service.get_chunk_by_id(kb_id, chunk_id)
    child_doc_id = parent["document_id"] if parent else children[0]["document_id"] if children else ""
    keys = frozenset(markdown_attachments.shared_assets(db, child_doc_id).values()) if child_doc_id else frozenset()
    if parent and keys:
        children.extend(markdown_attachments.shared_children(db, parent, keys))
    doc = None
    if child_doc_id and children:
        doc = db.query(Document).filter(Document.id == child_doc_id, Document.kb_id == kb_id).first()
    # Convert MinIO paths to presigned URLs for frontend display
    source_key = doc.storage_path if doc else None
    children = [
        _resolve_chunk_image_urls(c, kb_id, child_doc_id, source_key=source_key, shared_keys=keys)
        for c in children
    ]
    return ChunkChildResponse(
        items=[ChunkResponse(**child) for child in children],
    )


# ── Table Data ─────────────────────────────────────────────

@router.get(
    "/chunks/{chunk_id}/table-data",
    response_model=TableDataResponse,
)
async def get_chunk_table_data(
    chunk_id: str,
    kb_id: str = Query(..., description="知识库 ID"),
    sql: str | None = Query(None, description="自定义 SQL（仅允许 SELECT）"),
    limit: int = Query(100, ge=1, le=1000),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """下载并查询 chunk 关联的 SQLite db 文件中的数据。"""
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == kb_id, KnowledgeBase.user_id == current_user["id"]
    ).first()
    if not kb:
        raise HTTPException(status_code=404, detail="无权访问")

    # Get the chunk to find sqlite_url
    chunk_data = await es_chunk_service.get_chunk_by_id(kb_id=kb_id, chunk_id=chunk_id)
    if not chunk_data or not chunk_data.get("sqlite_url"):
        raise HTTPException(status_code=404, detail="该 chunk 无关联的表格数据")

    sqlite_url = chunk_data["sqlite_url"]

    # Download SQLite db from MinIO
    try:
        presigned_url = storage_service.get_presigned_url(sqlite_url, expires=300)
        # Download using httpx
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.get(presigned_url)
            resp.raise_for_status()
            db_bytes = resp.content
    except Exception as e:
        logger.error("Failed to download SQLite db: %s", e)
        raise HTTPException(status_code=503, detail="无法下载表格数据文件")

    # Write to temp file and query
    tmp_file = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    try:
        tmp_file.write(db_bytes)
        tmp_file.close()

        conn = sqlite3.connect(tmp_file.name)
        cursor = conn.cursor()

        # Validate SQL - only SELECT allowed
        if sql:
            sql_stripped = sql.strip().upper()
            if not sql_stripped.startswith("SELECT"):
                raise HTTPException(status_code=400, detail="仅允许 SELECT 查询")
        else:
            # Default: get first table, all rows
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            if not tables:
                raise HTTPException(status_code=404, detail="SQLite 文件中无表格")
            table_name = tables[0][0]
            sql = f'SELECT * FROM "{table_name}"'

        # Execute query
        cursor.execute(f"{sql} LIMIT {limit}")
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description] if cursor.description else []

        # Get table name from the SQL or chunk
        table_name = chunk_data.get("file_name", "unknown")

        conn.close()
        return TableDataResponse(
            table_name=table_name,
            columns=columns,
            rows=[list(row) for row in rows],
            total=len(rows),
        )
    finally:
        os.unlink(tmp_file.name)
