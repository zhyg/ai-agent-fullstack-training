"""Token 预算估算与淘汰（FR-019，research.md R9）.

tiktoken cl100k_base 近似计数；预算 = 分析模型 context_tokens − max_output_tokens。
核算对象：系统提示词 + 会话历史（默认最近 10 轮）+ 累积片段 + 引用协议文案。
超预算先截最早历史轮次，再按 first_loop 从早到晚淘汰片段，至少保留最新 1 条。
"""
import logging
from typing import List

import tiktoken

from app.core.config import settings
from app.services.agent_runtime.state import RequestRuntimeState

logger = logging.getLogger(__name__)

_encoding = None


def _get_encoding():
    global _encoding
    if _encoding is None:
        _encoding = tiktoken.get_encoding("cl100k_base")
    return _encoding


def count_tokens(text: str) -> int:
    """cl100k_base 近似计数（中文偏多计，预算宁紧勿松）."""
    if not text:
        return 0
    return len(_get_encoding().encode(text))


def trim_history_rounds(history: List[dict], rounds: int = None) -> List[dict]:
    """截取最近 N 轮会话历史（一轮 = 一条 user 及其后续回复）."""
    rounds = rounds if rounds is not None else settings.agent_runtime.history_rounds
    user_indexes = [i for i, m in enumerate(history) if m.get("role") == "user"]
    if len(user_indexes) <= rounds:
        return list(history)
    return list(history[user_indexes[-rounds]:])


def enforce_budget(state: RequestRuntimeState, fixed_texts: List[str]) -> dict:
    """就地裁剪 state.history 与 state.chunks 使总量不超预算.

    Args:
        fixed_texts: 固定开销文本（系统提示词、引用协议等）

    Returns:
        {budget, used, dropped_history, dropped_chunks, dropped_clarify_history}（淘汰明细供 trace）
    """
    snapshot = state.snapshot
    budget = snapshot.analysis_model.context_tokens - snapshot.max_output_tokens
    fixed = sum(count_tokens(t) for t in fixed_texts)

    def history_tokens() -> int:
        return sum(count_tokens(m.get("content", "")) for m in state.history)

    def chunk_tokens() -> int:
        return sum(count_tokens(c.content) + count_tokens(c.file_name) + 8 for c in state.chunks.values())

    dropped_history = 0
    dropped_chunks: List[str] = []

    # 1) 先截最早历史轮次（从头部逐条丢弃）
    while state.history and fixed + history_tokens() + chunk_tokens() > budget:
        state.history.pop(0)
        dropped_history += 1

    # 1.5) 组装历史同步裁剪（013 FR-011，R11）：与累积片段共受预算约束，头部逐条淘汰；
    # 保底 2 轮位于尾部天然最后触及；其供澄清/重写提示词用，不计入答案侧 used
    dropped_clarify_history = 0
    if state.clarify_history is not None:
        def clarify_tokens() -> int:
            return sum(count_tokens(m.get("content", "")) for m in state.clarify_history)

        while state.clarify_history and fixed + clarify_tokens() + chunk_tokens() > budget:
            state.clarify_history.pop(0)
            dropped_clarify_history += 1

    # 2) 再按 first_loop 从早到晚淘汰片段（OrderedDict 首序即首次出现序），至少保留最新 1 条
    while len(state.chunks) > 1 and fixed + history_tokens() + chunk_tokens() > budget:
        oldest_id = next(iter(state.chunks))
        state.chunks.pop(oldest_id)
        dropped_chunks.append(oldest_id)

    used = fixed + history_tokens() + chunk_tokens()
    if used > budget:
        logger.warning(
            "Context still over budget after eviction chat_id=%s used=%d budget=%d",
            state.chat_id, used, budget,
        )
    return {
        "budget": budget,
        "used": used,
        "dropped_history": dropped_history,
        "dropped_chunks": dropped_chunks,
        "dropped_clarify_history": dropped_clarify_history,
    }