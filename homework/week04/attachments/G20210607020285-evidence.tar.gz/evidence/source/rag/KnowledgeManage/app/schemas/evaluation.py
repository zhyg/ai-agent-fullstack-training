"""知识库评测 Pydantic schemas（014-knowledge-evaluation）。

契约来源: specs/014-knowledge-evaluation/contracts/evaluation-api.md。
- US1（T012）: SettingsOut/SettingsUpdate、TestSetOut/TestSetListOut 与 validate_test_set_payload
- US2（T020）: RecallResult/AccuracyResult 评分 JSON 模型、RunCreate、SSE 事件模型（snapshot/progress/done）
"""
import json
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, StrictBool

# FR-006 逐字约束：单个测试集上限 500 题、文件上限 2MB
MAX_TEST_SET_ITEMS = 500
MAX_TEST_SET_BYTES = 2 * 1024 * 1024


class SettingsOut(BaseModel):
    """评测设置（契约 §1）：三引用均可空，无记录时返回空默认值。"""

    analysis_model_id: Optional[str] = None
    recall_prompt_id: Optional[str] = None
    accuracy_prompt_id: Optional[str] = None


class SettingsUpdate(SettingsOut):
    """PUT /settings 请求体：允许部分保存（缺省字段置空），开跑前预检要求三项齐备。"""


class TestSetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    item_count: int
    created_at: datetime
    updated_at: datetime


class TestSetListOut(BaseModel):
    items: List[TestSetOut]


def validate_test_set_payload(raw: bytes) -> list:
    """校验测试集 JSON 文件（FR-006，上传与重新上传同规则）。

    规则：文件 ≤2MB；顶层数组；1 ≤ 题数 ≤ 500；每项 question/answer 均为
    strip 后非空字符串。失败抛 ValueError，错误信息含第 N 项/何字段。
    """
    if len(raw) > MAX_TEST_SET_BYTES:
        raise ValueError("文件大小超过 2MB 上限")
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ValueError("JSON 解析失败：文件不是合法 JSON")
    if not isinstance(data, list):
        raise ValueError("顶层必须为数组")
    if len(data) == 0:
        raise ValueError("测试集至少 1 题，空数组拒绝上传")
    if len(data) > MAX_TEST_SET_ITEMS:
        raise ValueError(f"题数超过上限 500（当前 {len(data)} 题）")
    for i, item in enumerate(data, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"第 {i} 项必须为对象")
        for field in ("question", "answer"):
            value = item.get(field)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"第 {i} 项 {field} 必须为非空字符串")
    return data


# ---------------------------------------------------------------------------
# US2（T020）：评分 JSON 模型（R4，FR-021/022/024）
# ---------------------------------------------------------------------------

class KeyPoint(BaseModel):
    point: str = Field(min_length=1)
    covered: StrictBool


class RecallResult(BaseModel):
    """召回率评分输出：key_points 空数组视为校验失败进入重试（澄清 Q1）；
    recall 为模型自报值，最终得分以后端核算为准（R5，决策6）。"""

    key_points: List[KeyPoint] = Field(min_length=1)
    recall: float


class Issue(BaseModel):
    type: str
    content: str
    evidence: str


class AccuracyResult(BaseModel):
    """准确度评分输出：空数组合法 = 100 分（R4）。"""

    issues: List[Issue] = Field(default_factory=list)


class RunCreate(BaseModel):
    """POST /runs 请求体（契约 §3）；kb_ids 非空校验在 service 预检中做（400 而非 422）。"""

    knowledge_base_ids: List[str]
    agent_id: str
    test_set_id: str


# ---------------------------------------------------------------------------
# SSE 事件模型（契约 §3，R6）：均为 data: {JSON}\n\n
# ---------------------------------------------------------------------------

class RunSnapshotEvent(BaseModel):
    """连接即发：当前进度/状态（断线重连恢复，R6）。"""

    type: str = "snapshot"
    run_id: str
    status: str
    completed: int
    total: int


class RunProgressEvent(RunSnapshotEvent):
    type: str = "progress"
    last_item: Optional[dict] = None


class RunDoneEvent(RunSnapshotEvent):
    type: str = "done"
    avg_recall: Optional[float] = None
    avg_accuracy: Optional[float] = None
    error_message: Optional[str] = None