from sqlalchemy import JSON, Column, ForeignKey, Index, String

from app.core.config import settings
from app.core.database import Base

SCHEMA = settings.database.db_schema


class ArchiveImage(Base):
    __tablename__ = "archive_images"
    __table_args__ = {"schema": SCHEMA}

    key = Column(String(300), primary_key=True)
    kb_id = Column(String(36), ForeignKey(f"{SCHEMA}.knowledge_bases.id", ondelete="CASCADE"), nullable=False)
    analysis = Column(JSON, nullable=True)


class ArchiveImageReference(Base):
    __tablename__ = "archive_image_references"
    __table_args__ = (Index("ix_archive_image_references_image_key", "image_key"), {"schema": SCHEMA})

    document_id = Column(String(36), ForeignKey(f"{SCHEMA}.documents.id", ondelete="CASCADE"), primary_key=True)
    path_hash = Column(String(64), primary_key=True)
    image_key = Column(String(300), ForeignKey(f"{SCHEMA}.archive_images.key", ondelete="CASCADE"), nullable=False)
