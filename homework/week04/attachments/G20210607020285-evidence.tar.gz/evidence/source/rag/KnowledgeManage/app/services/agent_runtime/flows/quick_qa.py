"""快速问答流程（FR-016）：langgraph 单遍 clarify→rewrite→retrieve→rerank→compress→answer.

- 澄清 clear=false：reason 落库为 AI 消息，terminate_reason=clarify_failed；
- 检索为空 / 压缩 kept_indexes=[]：终止提示"检索结果为空"，terminate_reason=empty_retrieval；
- 每节点入口取消检查；每步发 StepEvent；JSON 最终失败由入口转 error 事件（code+raw_output）。
"""
import logging
from typing import Any, List, TypedDict

from langgraph.graph import END, StateGraph

from app.schemas.agent_runtime import ClarifyResult
from app.services import retrieval_service, rerank_service
from app.services.agent_runtime import steps, tracing
from app.services.agent_runtime.state import ContextChunk, RequestRuntimeState

logger = logging.getLogger(__name__)

EMPTY_RETRIEVAL_TEXT = "检索结果为空，未找到与问题相关的资料。"
UNCLEAR_FALLBACK_TEXT = "问题不够清晰，请补充更多信息后重试。"


class FlowState(TypedDict, total=False):
    rt: RequestRuntimeState
    emit: Any
    clarify: ClarifyResult
    retrieved: List[ContextChunk]
    reranked: List[ContextChunk]
    kept: List[ContextChunk]
    result: dict


async def _clarify_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    result = await steps.run_clarify(rt, s["emit"])
    if not result.clear:
        return {
            "clarify": result,
            "result": {
                "content": result.reason or UNCLEAR_FALLBACK_TEXT,
                "meta": {"terminate_reason": "clarify_failed"},
            },
        }
    return {"clarify": result}


def _after_clarify(s: FlowState) -> str:
    return "end" if s.get("result") else "rewrite"


async def _rewrite_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    await steps.run_rewrite(rt, s["emit"])
    return {}


async def _retrieve_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    snap = rt.snapshot
    rc = snap.retrieval
    await steps.emit_step(s["emit"], "retrieve", "start", message=f"检索中（{rc.mode}）")
    span = tracing.get_tracer().start_span(f"agent.retrieve.{rc.mode}")
    try:
        tracing.set_input(span, {
            "mode": rc.mode, "question": rt.current_question or rt.question,
            "kb_ids": snap.kb_ids,
        })
        hits = await retrieval_service.retrieve(
            rc.mode,
            rt.current_question or rt.question,
            snap.kb_ids,
            vector_top_k=rc.vector_top_k,
            keyword_top_k=rc.keyword_top_k,
            hybrid_top_k=rc.hybrid_top_k,
            embedding_model_id=snap.embedding_model.model_id if snap.embedding_model else None,
        )
        rt.merge_chunks(hits)
        tracing.set_output(span, {
            "count": len(hits),
            "chunk_ids": [c.chunk_id for c in hits],
        })
        tracing.set_retrieval_chunks(span, hits)  # 片段全文不截断（013 FR-002）
        return {"retrieved": hits}
    finally:
        span.end()
        await steps.emit_step(s["emit"], "retrieve", "end")


async def _rerank_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    hits = s.get("retrieved") or []
    if not hits:
        return {"reranked": []}
    await steps.emit_step(s["emit"], "rerank", "start")
    span = tracing.get_tracer().start_span("agent.rerank")
    degraded = False
    try:
        ranked, degraded = await rerank_service.rerank(
            rt.current_question or rt.question,
            hits,
            rt.snapshot.rerank_model.name,
            top_n=rt.snapshot.retrieval.rerank_top_n,
            span=span,
        )
        if degraded:
            rt.events.append({"event": tracing.EVENT_RERANK_DEGRADED})
        return {"reranked": ranked}
    finally:
        span.end()
        await steps.emit_step(
            s["emit"], "rerank", "end",
            message="重排服务降级，按检索分数保留" if degraded else None,
        )


async def _compress_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    kept = await steps.run_compress(rt, s.get("reranked") or [], s["emit"])
    if not kept:
        return {
            "kept": [],
            "result": {
                "content": EMPTY_RETRIEVAL_TEXT,
                "meta": {"terminate_reason": "empty_retrieval"},
            },
        }
    return {"kept": kept}


def _after_compress(s: FlowState) -> str:
    return "end" if s.get("result") else "answer"


async def _answer_node(s: FlowState) -> dict:
    rt = s["rt"]
    steps.check_cancel(rt)
    # 答案上下文仅保留压缩后片段（单遍流程无跨轮累积）
    rt.chunks.clear()
    rt.merge_chunks(s.get("kept") or [])
    answer = await steps.stream_answer(rt, s["emit"])
    meta: dict = {"references": answer["references"]}
    if answer.get("usage"):
        meta["usage"] = answer["usage"]
    if rt.events:
        meta["events"] = rt.events
    return {"result": {"content": answer["content"], "meta": meta}}


def _build_graph():
    graph = StateGraph(FlowState)
    graph.add_node("clarify", _clarify_node)
    graph.add_node("rewrite", _rewrite_node)
    graph.add_node("retrieve", _retrieve_node)
    graph.add_node("rerank", _rerank_node)
    graph.add_node("compress", _compress_node)
    graph.add_node("answer", _answer_node)
    graph.set_entry_point("clarify")
    graph.add_conditional_edges("clarify", _after_clarify, {"rewrite": "rewrite", "end": END})
    graph.add_edge("rewrite", "retrieve")
    graph.add_edge("retrieve", "rerank")
    graph.add_edge("rerank", "compress")
    graph.add_conditional_edges("compress", _after_compress, {"answer": "answer", "end": END})
    graph.add_edge("answer", END)
    return graph.compile()


_graph = _build_graph()


async def run_quick_qa(state: RequestRuntimeState, emit) -> dict:
    """执行单遍流程，返回 {content, meta}；异常（取消/JSON 失败/流程级）上抛由入口统一处理."""
    final = await _graph.ainvoke({"rt": state, "emit": emit})
    return final.get("result") or {"content": "", "meta": {}}