"""014-knowledge-evaluation US1：测试集管理（T011，FR-005~009、决策20）。

上传校验走真实 validate_test_set_payload；CRUD/锁定在 router 层 mock service，
service 层用 MagicMock db 验证重名/锁定/覆盖语义（模式沿用 tests/test_agents.py）。
"""
import io
import json
import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.database import get_db
from app.models.evaluation_run import EvaluationRun
from app.models.evaluation_test_set import EvaluationTestSet
from app.routers import evaluations as evaluations_router
from app.schemas.evaluation import validate_test_set_payload, MAX_TEST_SET_BYTES
from app.services import evaluation_service
from app.services.evaluation_service import EvaluationLockedError, TestSetNameConflictError


NOW = datetime(2026, 11, 24, tzinfo=timezone.utc)


def user_claims(sub="u-1"):
    return {"type": "access", "sub": sub, "uid": "user", "permissions": []}


def make_items(n):
    return [{"question": f"问题{i}", "answer": f"答案{i}"} for i in range(1, n + 1)]


def make_test_set(**overrides):
    base = dict(
        id="ts-1", user_id="u-1", name="回归集A",
        items=make_items(10), item_count=10, created_at=NOW, updated_at=NOW,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def upload_files(payload_bytes, name="回归集A"):
    return (
        {"name": name},
        {"file": ("set.json", io.BytesIO(payload_bytes), "application/json")},
    )


class TestSetValidationTests(unittest.TestCase):
    """FR-006 逐字约束：≤2MB；顶层数组；1≤题数≤500；question/answer strip 后非空字符串。"""

    def test_valid_10_items_accepted(self):
        items = validate_test_set_payload(json.dumps(make_items(10)).encode("utf-8"))
        self.assertEqual(len(items), 10)
        self.assertEqual(items[0]["question"], "问题1")

    def test_invalid_json_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(b"{not json")
        self.assertIn("JSON", str(ctx.exception))

    def test_top_level_not_array_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(json.dumps({"question": "q", "answer": "a"}).encode())
        self.assertIn("数组", str(ctx.exception))

    def test_empty_array_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(b"[]")
        self.assertIn("至少 1 题", str(ctx.exception))

    def test_missing_field_rejected_with_index(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(json.dumps([{"question": "q"}]).encode())
        self.assertIn("第 1 项", str(ctx.exception))
        self.assertIn("answer", str(ctx.exception))

    def test_blank_question_or_answer_rejected_with_index(self):
        for bad in ({"question": "  ", "answer": "a"}, {"question": "q", "answer": ""}):
            with self.assertRaises(ValueError) as ctx:
                validate_test_set_payload(json.dumps([{"question": "q", "answer": "a"}, bad]).encode())
            self.assertIn("第 2 项", str(ctx.exception))

    def test_non_string_field_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(json.dumps([{"question": 123, "answer": "a"}]).encode())
        self.assertIn("question", str(ctx.exception))

    def test_non_object_item_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(json.dumps(["q1"]).encode())
        self.assertIn("第 1 项", str(ctx.exception))

    def test_501_items_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(json.dumps(make_items(501)).encode())
        self.assertIn("500", str(ctx.exception))

    def test_exactly_500_items_accepted(self):
        items = validate_test_set_payload(json.dumps(make_items(500)).encode())
        self.assertEqual(len(items), 500)

    def test_exactly_2mb_accepted(self):
        payload = json.dumps(make_items(10)).encode()
        padded = payload + b" " * (MAX_TEST_SET_BYTES - len(payload))
        self.assertEqual(len(padded), MAX_TEST_SET_BYTES)
        self.assertEqual(len(validate_test_set_payload(padded)), 10)

    def test_2mb_plus_one_byte_rejected(self):
        payload = json.dumps(make_items(10)).encode()
        padded = payload + b" " * (MAX_TEST_SET_BYTES + 1 - len(payload))
        with self.assertRaises(ValueError) as ctx:
            validate_test_set_payload(padded)
        self.assertIn("2MB", str(ctx.exception))


class TestSetRouterTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(evaluations_router.router)
        self.db = MagicMock()
        app.dependency_overrides[get_db] = lambda: self.db
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=user_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)

    def _upload(self, payload_bytes, name="回归集A"):
        data, files = upload_files(payload_bytes, name)
        return self.client.post("/evaluations/test-sets", data=data, files=files, headers=self.headers)

    def test_list_test_sets(self):
        with patch.object(evaluation_service, "list_test_sets", return_value=[make_test_set()]) as mock_list:
            res = self.client.get("/evaluations/test-sets", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        items = res.json()["items"]
        self.assertEqual(items[0]["name"], "回归集A")
        self.assertEqual(items[0]["item_count"], 10)
        self.assertNotIn("items_json", items[0])
        self.assertEqual(mock_list.call_args[0][1], "u-1")

    def test_upload_valid_10_items_201(self):
        with patch.object(evaluation_service, "create_test_set", return_value=make_test_set()) as mock_create:
            res = self._upload(json.dumps(make_items(10)).encode())
        self.assertEqual(res.status_code, 201)
        body = res.json()
        self.assertEqual(body["id"], "ts-1")
        self.assertEqual(body["name"], "回归集A")
        self.assertEqual(body["item_count"], 10)
        self.assertEqual(mock_create.call_args[0][1], "u-1")

    def test_upload_empty_array_400(self):
        res = self._upload(b"[]")
        self.assertEqual(res.status_code, 400)
        self.assertIn("至少 1 题", res.json()["detail"])

    def test_upload_top_level_not_array_400(self):
        res = self._upload(json.dumps({"question": "q", "answer": "a"}).encode())
        self.assertEqual(res.status_code, 400)
        self.assertIn("数组", res.json()["detail"])

    def test_upload_missing_field_400_with_index(self):
        res = self._upload(json.dumps([{"question": "q"}]).encode())
        self.assertEqual(res.status_code, 400)
        self.assertIn("第 1 项", res.json()["detail"])

    def test_upload_501_items_400(self):
        res = self._upload(json.dumps(make_items(501)).encode())
        self.assertEqual(res.status_code, 400)
        self.assertIn("500", res.json()["detail"])

    def test_upload_2mb_plus_one_400(self):
        payload = json.dumps(make_items(10)).encode()
        res = self._upload(payload + b" " * (MAX_TEST_SET_BYTES + 1 - len(payload)))
        self.assertEqual(res.status_code, 400)
        self.assertIn("2MB", res.json()["detail"])

    def test_upload_exactly_500_items_201(self):
        with patch.object(evaluation_service, "create_test_set", return_value=make_test_set(item_count=500)):
            res = self._upload(json.dumps(make_items(500)).encode())
        self.assertEqual(res.status_code, 201)
        self.assertEqual(res.json()["item_count"], 500)

    def test_upload_duplicate_name_409(self):
        with patch.object(evaluation_service, "create_test_set", side_effect=TestSetNameConflictError("测试集名称已存在")):
            res = self._upload(json.dumps(make_items(10)).encode())
        self.assertEqual(res.status_code, 409)

    def test_download_exports_standard_json(self):
        ts = make_test_set()
        with patch.object(evaluation_service, "get_test_set", return_value=ts):
            res = self.client.get("/evaluations/test-sets/ts-1/download", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertIn("attachment", res.headers["content-disposition"])
        self.assertEqual(res.json(), ts.items)

    def test_download_not_found_or_cross_user_404(self):
        with patch.object(evaluation_service, "get_test_set", return_value=None):
            res = self.client.get("/evaluations/test-sets/ts-other/download", headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_reupload_overwrites_keeps_id_and_name(self):
        new_items = make_items(3)
        with patch.object(evaluation_service, "reupload_test_set", return_value=make_test_set(items=new_items, item_count=3)) as mock_re:
            data_files = {"file": ("set.json", io.BytesIO(json.dumps(new_items).encode()), "application/json")}
            res = self.client.put("/evaluations/test-sets/ts-1", files=data_files, headers=self.headers)
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertEqual(body["id"], "ts-1")
        self.assertEqual(body["name"], "回归集A")
        self.assertEqual(body["item_count"], 3)
        self.assertEqual(mock_re.call_args[0][2], "ts-1")

    def test_reupload_invalid_json_400(self):
        data_files = {"file": ("set.json", io.BytesIO(b"[]"), "application/json")}
        res = self.client.put("/evaluations/test-sets/ts-1", files=data_files, headers=self.headers)
        self.assertEqual(res.status_code, 400)

    def test_reupload_locked_409(self):
        with patch.object(evaluation_service, "reupload_test_set", side_effect=EvaluationLockedError("评测进行中，测试集已锁定")):
            data_files = {"file": ("set.json", io.BytesIO(json.dumps(make_items(2)).encode()), "application/json")}
            res = self.client.put("/evaluations/test-sets/ts-1", files=data_files, headers=self.headers)
        self.assertEqual(res.status_code, 409)
        self.assertIn("锁定", res.json()["detail"])

    def test_reupload_not_found_404(self):
        with patch.object(evaluation_service, "reupload_test_set", return_value=None):
            data_files = {"file": ("set.json", io.BytesIO(json.dumps(make_items(2)).encode()), "application/json")}
            res = self.client.put("/evaluations/test-sets/ts-other", files=data_files, headers=self.headers)
        self.assertEqual(res.status_code, 404)

    def test_delete_204(self):
        with patch.object(evaluation_service, "delete_test_set", return_value=True):
            res = self.client.delete("/evaluations/test-sets/ts-1", headers=self.headers)
        self.assertEqual(res.status_code, 204)

    def test_delete_locked_409(self):
        with patch.object(evaluation_service, "delete_test_set", side_effect=EvaluationLockedError("评测进行中，测试集已锁定")):
            res = self.client.delete("/evaluations/test-sets/ts-1", headers=self.headers)
        self.assertEqual(res.status_code, 409)

    def test_delete_not_found_or_cross_user_404(self):
        with patch.object(evaluation_service, "delete_test_set", return_value=None):
            res = self.client.delete("/evaluations/test-sets/ts-other", headers=self.headers)
        self.assertEqual(res.status_code, 404)


class TestSetServiceTests(unittest.TestCase):
    def setUp(self):
        self.db = MagicMock()

    def _query(self, test_set=None, duplicate=None, running_run=None):
        def query(model):
            q = MagicMock()
            if model is EvaluationTestSet:
                # create 重名检查与 get 按 ID 查询共用 filter().first()：
                # 用调用顺序区分——第一次为重名检查，之后为按 ID 查询
                q.filter.return_value.first.side_effect = None
                q.filter.return_value.first.return_value = duplicate if duplicate is not None else test_set
            elif model is EvaluationRun:
                q.filter.return_value.first.return_value = running_run
            return q
        self.db.query.side_effect = query

    def test_create_duplicate_name_raises_conflict(self):
        self._query(duplicate=make_test_set())
        with self.assertRaises(TestSetNameConflictError):
            evaluation_service.create_test_set(self.db, "u-1", "回归集A", make_items(10))
        self.db.commit.assert_not_called()

    def test_create_persists_items_and_count(self):
        self._query(test_set=None)
        result = evaluation_service.create_test_set(self.db, "u-1", "新集", make_items(10))
        self.assertEqual(result.name, "新集")
        self.assertEqual(result.item_count, 10)
        self.assertEqual(len(result.items), 10)
        self.db.add.assert_called_once()
        self.db.commit.assert_called_once()

    def test_delete_locked_raises(self):
        self._query(test_set=make_test_set(), running_run=SimpleNamespace(id="run-1", status="running"))
        with self.assertRaises(EvaluationLockedError):
            evaluation_service.delete_test_set(self.db, "u-1", "ts-1")
        self.db.delete.assert_not_called()

    def test_delete_missing_returns_none(self):
        self._query(test_set=None)
        self.assertIsNone(evaluation_service.delete_test_set(self.db, "u-1", "ts-missing"))

    def test_delete_success(self):
        ts = make_test_set()
        self._query(test_set=ts)
        self.assertTrue(evaluation_service.delete_test_set(self.db, "u-1", "ts-1"))
        self.db.delete.assert_called_once_with(ts)
        self.db.commit.assert_called_once()

    def test_reupload_locked_raises(self):
        self._query(test_set=make_test_set(), running_run=SimpleNamespace(id="run-1", status="running"))
        with self.assertRaises(EvaluationLockedError):
            evaluation_service.reupload_test_set(self.db, "u-1", "ts-1", make_items(3))
        self.db.commit.assert_not_called()

    def test_reupload_overwrites_items_keeps_id_name(self):
        ts = make_test_set()
        self._query(test_set=ts)
        result = evaluation_service.reupload_test_set(self.db, "u-1", "ts-1", make_items(3))
        self.assertIs(result, ts)
        self.assertEqual(result.id, "ts-1")
        self.assertEqual(result.name, "回归集A")
        self.assertEqual(result.item_count, 3)
        self.db.commit.assert_called_once()

    def test_reupload_missing_returns_none(self):
        self._query(test_set=None)
        self.assertIsNone(evaluation_service.reupload_test_set(self.db, "u-1", "ts-missing", make_items(3)))


if __name__ == "__main__":
    unittest.main()