from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.schemas.knowledge_base import (
    KnowledgeBaseCreate,
    KnowledgeBaseUpdate,
    KnowledgeBaseResponse,
    PaginatedResponse,
)
from app.services import knowledge_base_service, storage_service

router = APIRouter(prefix="/knowledge-bases", tags=["知识库管理"])


@router.get("", response_model=PaginatedResponse[KnowledgeBaseResponse])
async def list_knowledge_bases(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=1000),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取当前用户的知识库列表"""
    items, total = knowledge_base_service.list_knowledge_bases(
        db, current_user["id"], page, page_size
    )
    return {
        "items": [KnowledgeBaseResponse.model_validate(kb) for kb in items],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("", response_model=KnowledgeBaseResponse, status_code=status.HTTP_201_CREATED)
async def create_knowledge_base(
    body: KnowledgeBaseCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """创建新知识库"""
    try:
        kb = knowledge_base_service.create_knowledge_base(db, current_user["id"], body)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    return KnowledgeBaseResponse.model_validate(kb)


@router.put("/{kb_id}", response_model=KnowledgeBaseResponse)
async def update_knowledge_base(
    kb_id: str,
    body: KnowledgeBaseUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """更新知识库"""
    try:
        kb = knowledge_base_service.update_knowledge_base(
            db, kb_id, current_user["id"], body
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    if not kb:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="知识库不存在或无权访问"
        )
    return KnowledgeBaseResponse.model_validate(kb)


@router.delete("/{kb_id}")
async def delete_knowledge_base(
    kb_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除知识库"""
    ok = knowledge_base_service.delete_knowledge_base(db, kb_id, current_user["id"])
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="知识库不存在或无权访问"
        )
    storage_service.delete_objects_by_prefix(f"{kb_id}/archive-images/")
    return {"message": "知识库删除成功"}
