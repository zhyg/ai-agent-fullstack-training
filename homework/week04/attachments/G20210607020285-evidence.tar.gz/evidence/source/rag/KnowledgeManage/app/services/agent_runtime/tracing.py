"""OpenTelemetry 轨迹采集（research.md R11，data-model.md §3.1）.

进程级单例 TracerProvider + BatchSpanProcessor + OTLP gRPC 导出（Collector 4317 → ES）。
span 命名：agent.run / agent.{step} / agent.tool.{name}；
属性：agent.input / agent.output（JSON 字符串 ≤32KB 截断）、agent.loop、tool.call_id、enduser.id、session.id；
事件：rerank_degraded / forced_convergence / idle_loop_converged / invalid_ref_dropped。
tracing.enabled=false 时使用 NoOp Tracer（单测环境）；导出失败仅记日志，不影响问答主流程。
"""
import json
import logging
import threading
from typing import Any, Optional

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.trace import NoOpTracer, Span

from app.core.config import settings

logger = logging.getLogger(__name__)

# 属性/事件常量（与 trace 查询侧、前端 SpanDetail 约定一致）
ATTR_INPUT = "agent.input"
ATTR_OUTPUT = "agent.output"
ATTR_LOOP = "agent.loop"
ATTR_TOOL_CALL_ID = "tool.call_id"
ATTR_MODEL = "gen_ai.request.model"
ATTR_USER = "enduser.id"
ATTR_SESSION = "session.id"
# 提示词溯源（013 决策10）：所有渲染提示词的 span 均携带，取自 PromptSnapshot
ATTR_PROMPT_NAME = "prompt.name"
ATTR_PROMPT_VERSION = "prompt.version"
ATTR_PROMPT_PURPOSE = "prompt.purpose"
# 检索片段全文（013 决策11）：JSON 数组，不截断
ATTR_RETRIEVAL_CHUNKS = "retrieval.chunks"
# 历史检索命中轮次全文：JSON 数组 [{round_id, question, answer, created_at}]，不截断
ATTR_HISTORY_ROUNDS = "history.rounds"

EVENT_RERANK_DEGRADED = "rerank_degraded"
EVENT_FORCED_CONVERGENCE = "forced_convergence"
EVENT_IDLE_LOOP_CONVERGED = "idle_loop_converged"
EVENT_INVALID_REF_DROPPED = "invalid_ref_dropped"
EVENT_PLAN_TEXT_NOT_TOOL_CALL = "plan_text_not_tool_call"
EVENT_HISTORY_RETRIEVE_DEGRADED = "history_retrieve_degraded"
EVENT_HISTORY_INDEX_FAILED = "history_index_failed"

_MAX_ATTR_BYTES = 32 * 1024  # agent.input/output 上限 32KB

_provider: Optional[TracerProvider] = None
_tracer: Optional[Any] = None
_lock = threading.Lock()


def _build_tracer():
    """按配置构建单例 tracer；enabled=false 走 NoOp（不导出不建连接）."""
    cfg = settings.tracing
    if not cfg.enabled:
        logger.info("Agent tracing disabled, using NoOp tracer")
        return None, NoOpTracer()
    resource = Resource.create(attributes={"service.name": cfg.service_name})
    provider = TracerProvider(resource=resource)
    exporter = OTLPSpanExporter(endpoint=cfg.otlp_endpoint, insecure=True)
    provider.add_span_processor(BatchSpanProcessor(exporter))
    # 不设全局 provider，避免影响进程内其他组件；父子关系经 context 传播仍成立
    return provider, provider.get_tracer("agent.runtime", "1.0.0")


def get_tracer():
    """进程级单例 tracer（惰性初始化，线程安全）."""
    global _provider, _tracer
    if _tracer is None:
        with _lock:
            if _tracer is None:
                _provider, _tracer = _build_tracer()
    return _tracer


def to_json_attr(value: Any) -> str:
    """序列化为 JSON 字符串并按 32KB 截断（FR-033 输入输出可查且不撑爆存储）."""
    try:
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        text = str(value)
    if len(text.encode("utf-8")) > _MAX_ATTR_BYTES:
        # 按字节截断后修复可能的半截多字节字符
        text = text.encode("utf-8")[:_MAX_ATTR_BYTES].decode("utf-8", errors="ignore") + "…[截断]"
    return text


def set_input(span: Span, value: Any) -> None:
    span.set_attribute(ATTR_INPUT, to_json_attr(value))


def set_output(span: Span, value: Any) -> None:
    span.set_attribute(ATTR_OUTPUT, to_json_attr(value))


def set_prompt_attrs(span: Span, prompt_snapshot: Any, purpose: str) -> None:
    """提示词溯源属性（FR-001）：name/version 直取冻结快照，不查库."""
    span.set_attribute(ATTR_PROMPT_NAME, prompt_snapshot.name)
    span.set_attribute(ATTR_PROMPT_VERSION, prompt_snapshot.version)
    span.set_attribute(ATTR_PROMPT_PURPOSE, purpose)


def set_retrieval_chunks(span: Span, chunks: Any) -> None:
    """检索片段全文（FR-002）：JSON 数组 [{chunk_id, score, file_name, content}].

    决策11 要求全文不截断，故不经 to_json_attr（其 32KB 截断仅约束 input/output）。
    """
    items = [
        {"chunk_id": c.chunk_id, "score": c.score, "file_name": c.file_name, "content": c.content}
        for c in chunks
    ]
    span.set_attribute(ATTR_RETRIEVAL_CHUNKS, json.dumps(items, ensure_ascii=False))


def set_history_rounds(span: Span, hits: Any) -> None:
    """历史检索命中轮次全文：JSON 数组 [{round_id, question, answer, created_at}].

    与 retrieval.chunks 同口径：问答内容全文不截断，不经 to_json_attr。
    """
    items = []
    for h in hits:
        src = h.get("_source") or {}
        items.append({
            "round_id": h.get("_id", ""),
            "question": src.get("question", ""),
            "answer": src.get("answer", ""),
            "created_at": src.get("created_at", ""),
        })
    span.set_attribute(ATTR_HISTORY_ROUNDS, json.dumps(items, ensure_ascii=False))


def add_event(span: Span, name: str, attributes: Optional[dict] = None) -> None:
    """记录命名事件（rerank_degraded 等），属性值统一 JSON 字符串化."""
    span.add_event(
        name,
        attributes={k: to_json_attr(v) for k, v in (attributes or {}).items()},
    )


def trace_id_hex(span: Span) -> str:
    """根 span 的 128bit trace_id → 32 位 hex（落库 Message.trace_id）."""
    return format(span.get_span_context().trace_id, "032x")


def finalize_tracing() -> None:
    """问答收尾强制 flush（5s 超时）；导出失败仅记日志不上抛."""
    if _provider is None:
        return
    try:
        _provider.force_flush(timeout_millis=5000)
    except Exception:
        logger.warning("Agent trace force_flush failed", exc_info=True)


__all__ = [
    "get_tracer", "set_input", "set_output", "add_event", "trace_id_hex",
    "finalize_tracing", "to_json_attr", "trace",
    "set_prompt_attrs", "set_retrieval_chunks", "set_history_rounds",
    "ATTR_INPUT", "ATTR_OUTPUT", "ATTR_LOOP", "ATTR_TOOL_CALL_ID",
    "ATTR_MODEL", "ATTR_USER", "ATTR_SESSION",
    "ATTR_PROMPT_NAME", "ATTR_PROMPT_VERSION", "ATTR_PROMPT_PURPOSE",
    "ATTR_RETRIEVAL_CHUNKS", "ATTR_HISTORY_ROUNDS",
    "EVENT_RERANK_DEGRADED", "EVENT_FORCED_CONVERGENCE",
    "EVENT_IDLE_LOOP_CONVERGED", "EVENT_INVALID_REF_DROPPED",
    "EVENT_PLAN_TEXT_NOT_TOOL_CALL", "EVENT_HISTORY_RETRIEVE_DEGRADED",
    "EVENT_HISTORY_INDEX_FAILED",
]