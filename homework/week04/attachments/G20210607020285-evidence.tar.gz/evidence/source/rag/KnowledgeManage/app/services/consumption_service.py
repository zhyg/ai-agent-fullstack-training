import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional
from zoneinfo import ZoneInfo

import httpx
from fastapi import HTTPException

from app.core.config import settings
from app.schemas.consumption import ConsumptionQuery, OptionsOut, SeriesItem, SeriesOut

logger = logging.getLogger(__name__)

BJ_TZ = ZoneInfo("Asia/Shanghai")

# 资源消耗监控服务（015-resource-consumption-monitor）
# 基础能力（T004）：管理员判定 / 当前用户 email 解析 / Prometheus HTTP 封装
# 桶切分与 PromQL 聚合（T008-T010，R-003/004/005/006）


def is_admin(user: dict) -> bool:
    """管理员判据与 prompt_service._is_admin / 前端 userStore.isAdmin 一致（R-002）。"""
    return "permission_manage" in user.get("permissions", [])


async def resolve_current_email(current_user: dict) -> str:
    """JWT payload 不含 email，经 UserManage 桥接解析当前用户 email（R-001）。

    复用 prompt_service._resolve_user_names 的 httpx 模式（5s 超时，Bearer 透传）；
    解析失败抛 502，不降级为任意查询。
    """
    user_manage_url = settings.services.get("user_manage", "http://localhost:8001")
    uid = current_user["id"]
    token = current_user.get("token", "")
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(
                f"{user_manage_url}/api/user/users/{uid}",
                headers={"Authorization": f"Bearer {token}"},
            )
        if resp.status_code == 200:
            email = resp.json().get("email")
            if email:
                return email
        logger.warning(f"Resolve email failed: uid={uid}, status={resp.status_code}")
    except Exception as e:
        logger.warning(f"Resolve email error: uid={uid}, {e}")
    raise HTTPException(status_code=502, detail="无法解析当前用户身份")


async def prom_get(path: str, params: dict) -> dict:
    """Prometheus HTTP API GET 封装（R-003/R-006）。

    连接失败 / 非 200 / status!=success 统一抛 502"指标数据源不可用"，
    前端展示错误提示且不影响其他页面（FR-017）。
    """
    url = settings.prometheus.url.rstrip("/") + path
    try:
        async with httpx.AsyncClient(timeout=settings.prometheus.timeout) as client:
            resp = await client.get(url, params=params)
    except Exception as e:
        logger.warning(f"Prometheus request failed: {url}, {e}")
        raise HTTPException(status_code=502, detail="指标数据源不可用")
    if resp.status_code != 200:
        logger.warning(f"Prometheus bad status: {url}, {resp.status_code}, body={resp.text[:200]}")
        raise HTTPException(status_code=502, detail="指标数据源不可用")
    data = resp.json()
    if data.get("status") != "success":
        logger.warning(f"Prometheus query error: {url}, {data.get('error')}")
        raise HTTPException(status_code=502, detail="指标数据源不可用")
    return data.get("data")


@dataclass
class Bucket:
    """北京时间自然日/月桶（data-model §1.1）；end 不含，partial 桶 end=now。"""
    label: str
    start: datetime
    end: datetime
    partial: bool = False

    @property
    def window_seconds(self) -> int:
        return int((self.end - self.start).total_seconds())


def build_buckets(scope: str, month: Optional[str] = None, year: Optional[int] = None,
                  now: Optional[datetime] = None) -> List[Bucket]:
    """切桶（FR-012/018）：当前月截断至今天、当前年截断至本月，末桶 partial。"""
    now = now or datetime.now(BJ_TZ)
    buckets: List[Bucket] = []
    if scope == "user_daily":
        first = datetime.strptime(month, "%Y-%m").replace(tzinfo=BJ_TZ)
        next_month = (first.replace(year=first.year + 1, month=1) if first.month == 12
                      else first.replace(month=first.month + 1))
        days = (next_month - first).days
        is_current = first.strftime("%Y-%m") == now.strftime("%Y-%m")
        count = now.day if is_current else days
        for d in range(count):
            start = first + timedelta(days=d)
            end = start + timedelta(days=1)
            partial = is_current and d == count - 1
            buckets.append(Bucket(start.strftime("%Y-%m-%d"), start, now if partial else end, partial))
    else:
        is_current = year == now.year
        count = now.month if is_current else 12
        for m in range(1, count + 1):
            start = datetime(year, m, 1, tzinfo=BJ_TZ)
            end = (datetime(year + 1, 1, 1, tzinfo=BJ_TZ) if m == 12
                   else datetime(year, m + 1, 1, tzinfo=BJ_TZ))
            partial = is_current and m == count
            buckets.append(Bucket(start.strftime("%Y-%m"), start, now if partial else end, partial))
    return buckets


def _escape_label(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _escape_regex(value: str) -> str:
    # PromQL 正则为 RE2 语法：仅转义其元字符。不能用 re.escape——它会把 '-' 等
    # 转成 \-，PromQL 字符串解析报 unknown escape sequence（如 sgm-deepseek-v-flash）
    return re.sub(r"[\\.^$|?*+()\[\]{}]", lambda m: "\\" + m.group(0), value)


def build_query(metric: str, user_email: Optional[str], models: List[str], window_seconds: int) -> str:
    """逐桶瞬时查询 PromQL（R-004）：sum by (model) 折叠高基数标签；
    token 排除 cached；人视图精确匹配 user_email，所有人视图省略；全选省略 model 过滤。"""
    name = "llm_tokens_total" if metric == "tokens" else "llm_cost_estimate_total"
    filters = []
    if metric == "tokens":
        filters.append('type!="cached"')
    if user_email:
        filters.append(f'user_email="{_escape_label(user_email)}"')
    if models:
        pattern = "|".join(_escape_regex(m) for m in models)
        filters.append(f'model=~"{_escape_label(pattern)}"')
    selector = name + ("{" + ",".join(filters) + "}" if filters else "")
    return f"sum by (model) (increase({selector}[{window_seconds}s]))"


async def _query_buckets(q: ConsumptionQuery, user_email: Optional[str], buckets: List[Bucket]) -> List[dict]:
    """asyncio 并发逐桶查询（信号量上限 8，R-003），每桶返回 {model: 增量值}。"""
    sem = asyncio.Semaphore(8)

    async def run(bucket: Bucket) -> dict:
        async with sem:
            window = max(1, bucket.window_seconds)  # 避免午夜整点 window=0
            query = build_query(q.metric.value, user_email, q.model_list, window)
            data = await prom_get("/api/v1/query", {"query": query, "time": bucket.end.timestamp()})
            out = {}
            for item in data.get("result", []):
                model = item.get("metric", {}).get("model")
                if not model:
                    continue
                try:
                    out[model] = float(item["value"][1])
                except (KeyError, TypeError, ValueError):
                    continue
            return out

    return await asyncio.gather(*(run(b) for b in buckets))


async def query_series(q: ConsumptionQuery, current_user: dict) -> SeriesOut:
    """消耗序列查询（FR-003/004/013/014/017/018，contracts §2）。"""
    admin = is_admin(current_user)
    if q.scope.value == "all_monthly":
        if not admin:
            raise HTTPException(status_code=403, detail="无权查看全员消耗数据")
        target_email = None  # 跨用户求和（含空 user_email 数据）
    else:
        own_email = await resolve_current_email(current_user)
        if not admin and q.user_email != own_email:
            raise HTTPException(status_code=403, detail="无权查看其他用户的消耗数据")
        target_email = q.user_email if admin else own_email

    buckets = build_buckets(q.scope.value, month=q.month, year=q.year)
    now = datetime.now(BJ_TZ)
    horizon = now - timedelta(days=settings.prometheus.retention_days)
    if buckets and buckets[-1].end <= horizon:
        # 请求期间整体早于保留期阈值（R-005）：空序列 + 提示标记
        return SeriesOut(metric=q.metric.value, scope=q.scope.value, buckets=[], series=[],
                         out_of_retention=True)

    per_bucket = await _query_buckets(q, target_email, buckets)
    seen = set()
    for d in per_bucket:
        seen.update(d.keys())
    explicit = q.model_list
    # 补 0 模型范围：显式勾选的模型全 0 仍返回；全选时仅返回区间内有数据的模型（U1）
    models = sorted(explicit) if explicit else sorted(seen)

    series = []
    for model in models:
        values = []
        for d in per_bucket:
            v = max(0.0, d.get(model, 0.0))  # FR-013 非负保护
            values.append(int(round(v)) if q.metric.value == "tokens" else round(v, 6))
        series.append(SeriesItem(model=model, values=values))

    return SeriesOut(metric=q.metric.value, scope=q.scope.value,
                     buckets=[b.label for b in buckets], series=series)


async def get_options(current_user: dict) -> OptionsOut:
    """筛选选项（R-006，contracts §1）：label values 排除空串、升序；
    普通用户 user_emails 仅本人（管理员全量列表路径 US3 T021）。"""
    admin = is_admin(current_user)
    if admin:
        model_vals, email_vals = await asyncio.gather(
            prom_get("/api/v1/label/model/values", {"match[]": "llm_tokens_total"}),
            prom_get("/api/v1/label/user_email/values", {"match[]": "llm_tokens_total"}),
        )
        emails = sorted(v for v in email_vals if v)
    else:
        own_email = await resolve_current_email(current_user)
        model_vals = await prom_get("/api/v1/label/model/values", {"match[]": "llm_tokens_total"})
        emails = [own_email]
    models = sorted(v for v in model_vals if v)
    return OptionsOut(user_emails=emails, models=models, is_admin=admin)