import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, Boolean, Text, TIMESTAMP, Index, text
from sqlalchemy.dialects.postgresql import JSONB

from app.core.database import Base
from app.core.config import settings


class EvaluationRun(Base):
    __tablename__ = "evaluation_runs"
    __table_args__ = (
        Index("idx_evaluation_runs_user_created", "user_id", text("created_at DESC")),
        Index("idx_evaluation_runs_status", "status"),
        Index("idx_evaluation_runs_test_set", "test_set_id", "status"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), nullable=False, comment="创建者，仅本人可见")
    knowledge_base_ids = Column(JSONB, nullable=False, comment="知识库 ID 列表（≥1）")
    knowledge_base_names = Column(JSONB, nullable=False, comment="名称快照列表（与 IDs 同序，决策19）")
    agent_id = Column(String(36), nullable=False, comment="智能体 ID")
    agent_name = Column(String(200), nullable=False, comment="智能体名称快照")
    test_set_id = Column(String(36), nullable=False, comment="测试集 ID")
    test_set_name = Column(String(100), nullable=False, comment="测试集名称快照")
    status = Column(String(20), nullable=False, default="running", comment="running/completed/cancelled/failed")
    total_items = Column(Integer, nullable=False, comment="开跑时测试集题数")
    completed_items = Column(Integer, nullable=False, default=0, comment="已处理题数（含失败题）")
    cancel_requested = Column(Boolean, nullable=False, default=False, comment="题间取消标记（R6）")
    error_message = Column(Text, nullable=True, comment="任务级失败原因（服务重启中断/执行异常）")
    started_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc),
        comment="列表开始时间",
    )
    finished_at = Column(TIMESTAMP, nullable=True, comment="终态时间")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )