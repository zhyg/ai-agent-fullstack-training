"""add hybridSearch tool to planning_reasoning preset

Revision ID: d9e1f2a3b4c5
Revises: b8e2f4a6c1d9
Create Date: 2026-11-23 10:00:00.000000

"""
from typing import Sequence, Union
import json
from datetime import datetime, timezone

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'd9e1f2a3b4c5'
down_revision: Union[str, None] = 'b8e2f4a6c1d9'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _update_tools(remove: bool = False) -> None:
    bind = op.get_bind()
    row = bind.execute(
        sa.text("SELECT id, config FROM knowledge_manage.agents WHERE type = 'planning_reasoning'")
    ).first()
    if row is None:
        return
    config = row.config
    tools = config.get("tools")
    if tools is None:
        return
    if remove:
        if "hybridSearch" not in tools:
            return
        tools = [k for k in tools if k != "hybridSearch"]
    else:
        if "hybridSearch" in tools:
            return
        # 与 TOOL_KEYS 顺序一致：插在 vectorSearch 之后
        idx = tools.index("vectorSearch") + 1 if "vectorSearch" in tools else len(tools)
        tools.insert(idx, "hybridSearch")
    config["tools"] = tools
    bind.execute(
        sa.text(
            "UPDATE knowledge_manage.agents "
            "SET config = CAST(:config AS jsonb), updated_at = :now WHERE id = :id"
        ),
        {
            "id": row.id,
            "config": json.dumps(config, ensure_ascii=False),
            "now": datetime.now(timezone.utc),
        },
    )


def upgrade() -> None:
    _update_tools()


def downgrade() -> None:
    _update_tools(remove=True)