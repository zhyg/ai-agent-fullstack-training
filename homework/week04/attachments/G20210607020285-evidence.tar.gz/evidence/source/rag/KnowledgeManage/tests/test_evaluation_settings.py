"""014-knowledge-evaluation US1：评测设置（T010，FR-002~004/009）。

模式沿用 tests/test_agents.py：MagicMock db + patch decode_token + TestClient。
"""
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.database import get_db
from app.models.evaluation_setting import EvaluationSetting
from app.models.evaluation_run import EvaluationRun
from app.models.prompt import Prompt
from app.routers import evaluations as evaluations_router
from app.schemas.evaluation import SettingsUpdate
from app.services import evaluation_service
from app.services.evaluation_service import EvaluationLockedError


def user_claims(sub="u-1"):
    return {"type": "access", "sub": sub, "uid": "user", "permissions": []}


def make_setting(**overrides):
    base = dict(
        id="es-1", user_id="u-1",
        analysis_model_id="m-1", recall_prompt_id="p-1", accuracy_prompt_id="p-2",
    )
    base.update(overrides)
    return SimpleNamespace(**base)


class SettingsRouterTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(evaluations_router.router)
        self.db = MagicMock()
        app.dependency_overrides[get_db] = lambda: self.db
        self.client = TestClient(app)
        self.headers = {"Authorization": "Bearer test-token"}
        self.auth = patch("app.dependencies.decode_token", return_value=user_claims())
        self.auth.start()
        self.addCleanup(self.auth.stop)

    def test_get_settings_empty_defaults(self):
        with patch.object(evaluation_service, "get_settings", return_value=None):
            res = self.client.get("/evaluations/settings", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json(), {
            "analysis_model_id": None, "recall_prompt_id": None, "accuracy_prompt_id": None,
        })

    def test_get_settings_saved_values(self):
        with patch.object(evaluation_service, "get_settings", return_value=make_setting()):
            res = self.client.get("/evaluations/settings", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["analysis_model_id"], "m-1")
        self.assertEqual(res.json()["recall_prompt_id"], "p-1")
        self.assertEqual(res.json()["accuracy_prompt_id"], "p-2")

    def test_put_settings_upsert_success(self):
        with patch.object(evaluation_service, "upsert_settings", return_value=make_setting()) as mock_upsert:
            res = self.client.put("/evaluations/settings", json={
                "analysis_model_id": "m-1", "recall_prompt_id": "p-1", "accuracy_prompt_id": "p-2",
            }, headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["analysis_model_id"], "m-1")
        # 用户隔离：router 必须把当前用户 ID 传入 service
        self.assertEqual(mock_upsert.call_args[0][1], "u-1")

    def test_put_settings_partial_save_allowed(self):
        with patch.object(evaluation_service, "upsert_settings", return_value=make_setting(
            analysis_model_id=None, accuracy_prompt_id=None,
        )):
            res = self.client.put("/evaluations/settings", json={"recall_prompt_id": "p-1"}, headers=self.headers)
        self.assertEqual(res.status_code, 200)
        self.assertIsNone(res.json()["analysis_model_id"])

    def test_put_settings_prompt_not_owned_400(self):
        with patch.object(evaluation_service, "upsert_settings", side_effect=ValueError("提示词不存在或非本人所有")):
            res = self.client.put("/evaluations/settings", json={"recall_prompt_id": "p-other"}, headers=self.headers)
        self.assertEqual(res.status_code, 400)
        self.assertIn("提示词", res.json()["detail"])

    def test_put_settings_running_lock_409(self):
        with patch.object(evaluation_service, "upsert_settings", side_effect=EvaluationLockedError("评测进行中，设置已锁定")):
            res = self.client.put("/evaluations/settings", json={"recall_prompt_id": "p-1"}, headers=self.headers)
        self.assertEqual(res.status_code, 409)
        self.assertIn("锁定", res.json()["detail"])

    def test_settings_scoped_to_current_user(self):
        self.auth.stop()
        with patch("app.dependencies.decode_token", return_value=user_claims(sub="u-2")):
            with patch.object(evaluation_service, "get_settings", return_value=None) as mock_get:
                self.client.get("/evaluations/settings", headers=self.headers)
        self.assertEqual(mock_get.call_args[0][1], "u-2")


class SettingsServiceTests(unittest.TestCase):
    def setUp(self):
        self.db = MagicMock()

    def _query(self, setting=None, running_run=None, prompt=SimpleNamespace(id="p-1")):
        def query(model):
            q = MagicMock()
            if model is EvaluationSetting:
                q.filter.return_value.first.return_value = setting
            elif model is EvaluationRun:
                q.filter.return_value.first.return_value = running_run
            elif model is Prompt:
                q.filter.return_value.first.return_value = prompt
            return q
        self.db.query.side_effect = query

    def test_get_settings_missing_returns_none(self):
        self._query(setting=None)
        self.assertIsNone(evaluation_service.get_settings(self.db, "u-1"))

    def test_upsert_creates_row_when_absent(self):
        self._query(setting=None)
        data = SettingsUpdate(analysis_model_id="m-1", recall_prompt_id="p-1", accuracy_prompt_id=None)
        result = evaluation_service.upsert_settings(self.db, "u-1", data)
        self.assertEqual(result.user_id, "u-1")
        self.assertEqual(result.analysis_model_id, "m-1")
        self.assertIsNone(result.accuracy_prompt_id)
        self.db.add.assert_called_once()
        self.db.commit.assert_called_once()

    def test_upsert_updates_existing_row(self):
        existing = make_setting()
        self._query(setting=existing)
        data = SettingsUpdate(analysis_model_id="m-9", recall_prompt_id="p-1", accuracy_prompt_id="p-2")
        result = evaluation_service.upsert_settings(self.db, "u-1", data)
        self.assertIs(result, existing)
        self.assertEqual(existing.analysis_model_id, "m-9")
        self.db.add.assert_not_called()
        self.db.commit.assert_called_once()

    def test_upsert_running_run_raises_locked(self):
        self._query(setting=None, running_run=SimpleNamespace(id="run-1", status="running"))
        with self.assertRaises(EvaluationLockedError):
            evaluation_service.upsert_settings(self.db, "u-1", SettingsUpdate())
        self.db.commit.assert_not_called()

    def test_upsert_prompt_not_owned_raises(self):
        self._query(setting=None, prompt=None)
        with self.assertRaises(ValueError):
            evaluation_service.upsert_settings(self.db, "u-1", SettingsUpdate(recall_prompt_id="p-other"))
        self.db.commit.assert_not_called()

    def test_upsert_null_prompts_skip_ownership_check(self):
        self._query(setting=None, prompt=None)
        result = evaluation_service.upsert_settings(self.db, "u-1", SettingsUpdate())
        self.assertIsNone(result.recall_prompt_id)
        self.db.commit.assert_called_once()


if __name__ == "__main__":
    unittest.main()