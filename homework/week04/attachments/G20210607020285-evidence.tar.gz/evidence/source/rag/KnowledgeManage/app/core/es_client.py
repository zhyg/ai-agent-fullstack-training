"""Elasticsearch async client singleton wrapper."""

import logging

from elasticsearch import AsyncElasticsearch

from app.core.config import settings

logger = logging.getLogger(__name__)

_client: AsyncElasticsearch | None = None


async def get_async_client() -> AsyncElasticsearch:
    """Return the singleton AsyncElasticsearch client, creating it on first call."""
    global _client
    if _client is None:
        cfg = settings.elasticsearch
        _client = AsyncElasticsearch(
            hosts=cfg.hosts,
            basic_auth=(cfg.username, cfg.password),
            request_timeout=30,
        )
        logger.info("Elasticsearch async client initialized (hosts=%s)", cfg.hosts)
    return _client


async def ensure_index(kb_id: str, dims: int = 1024) -> str:
    """Ensure the knowledge chunks index exists for the given knowledge base.

    Creates the index with the correct mapping if it does not already exist.
    Returns the index name.
    """
    index_name = f"knowledge_chunks_{kb_id}"
    client = await get_async_client()

    exists = await client.indices.exists(index=index_name)
    if not exists:
        mapping = {
            "mappings": {
                "properties": {
                    "chunk_id": {"type": "keyword"},
                    "document_id": {"type": "keyword"},
                    "chunk_type": {"type": "keyword"},
                    "content": {"type": "text", "analyzer": "standard"},
                    "image_url": {"type": "keyword"},
                    "parent_chunk_id": {"type": "keyword"},
                    "embeddings": {"type": "dense_vector", "dims": dims},
                    "sqlite_url": {"type": "keyword"},
                    "chunk_index": {"type": "integer"},
                    "file_name": {"type": "keyword"},
                    "created_at": {"type": "date"},
                }
            }
        }
        await client.indices.create(index=index_name, body=mapping)
        logger.info("Created ES index: %s (dims=%d)", index_name, dims)
    return index_name


async def ensure_history_index(dims: int) -> str:
    """Ensure the chat history QA index exists for the given vector dims (013 R1/R2).

    索引按向量维度分（chat_history_qa_{dims}）：dense_vector.dims 建后不可改，
    换向量模型后新旧文档天然隔离；文本字段 ik_max_word 索引 + ik_smart 查询。
    """
    index_name = f"chat_history_qa_{dims}"
    client = await get_async_client()

    exists = await client.indices.exists(index=index_name)
    if not exists:
        ik_text = {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"}
        mapping = {
            "mappings": {
                "properties": {
                    "chat_id": {"type": "keyword"},
                    "user_id": {"type": "keyword"},
                    "question": ik_text,
                    "answer": ik_text,
                    "qa_text": ik_text,
                    "created_at": {"type": "date"},
                    "embedding_model": {"type": "keyword"},
                    "embedding_model_id": {"type": "keyword"},
                    "embeddings": {"type": "dense_vector", "dims": dims},
                }
            }
        }
        await client.indices.create(index=index_name, body=mapping)
        logger.info("Created ES history index: %s", index_name)
    return index_name


async def close_client() -> None:
    """Close the singleton ES client gracefully."""
    global _client
    if _client is not None:
        await _client.close()
        _client = None
        logger.info("Elasticsearch async client closed")
