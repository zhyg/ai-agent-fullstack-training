import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Column, String, Integer, Float, Text, TIMESTAMP, Index, UniqueConstraint, ForeignKey,
)
from sqlalchemy.dialects.postgresql import JSONB

from app.core.database import Base
from app.core.config import settings


class EvaluationItem(Base):
    __tablename__ = "evaluation_items"
    __table_args__ = (
        UniqueConstraint("run_id", "seq", name="uq_evaluation_items_run_seq"),
        Index("idx_evaluation_items_run", "run_id", "status"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    run_id = Column(
        String(36),
        ForeignKey(f"{settings.database.db_schema}.evaluation_runs.id", ondelete="CASCADE"),
        nullable=False,
        comment="所属评测任务，删除记录级联删明细（FR-033）",
    )
    seq = Column(Integer, nullable=False, comment="题序（1 起），(run_id, seq) 唯一")
    question = Column(Text, nullable=False, comment="开跑时逐题快照（决策13）")
    standard_answer = Column(Text, nullable=False, comment="标准答案快照")
    status = Column(String(20), nullable=False, default="pending", comment="pending/success/failed")
    agent_answer = Column(Text, nullable=True, comment="agent 最终答案")
    context = Column(JSONB, nullable=True, comment="meta.references 快照（R3：file_name/content/score 等）")
    recall = Column(Float, nullable=True, comment="召回率 0–1，后端核算（R5）；失败置空")
    accuracy = Column(Float, nullable=True, comment="准确度 0–100，后端核算；失败置空")
    recall_analysis = Column(JSONB, nullable=True, comment="最终采纳的合法召回率 JSON（决策14）")
    accuracy_analysis = Column(JSONB, nullable=True, comment="最终采纳的合法准确度 JSON")
    recall_raw_output = Column(Text, nullable=True, comment="召回率评分失败时最后一次原始输出")
    accuracy_raw_output = Column(Text, nullable=True, comment="准确度评分失败时最后一次原始输出")
    failure_reason = Column(Text, nullable=True, comment="澄清原因/执行失败/评分重试耗尽/执行超时")
    trace_id = Column(String(32), nullable=True, comment="该题根 span trace ID（决策21）")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc),
        comment="trace 索引窗口基准（R11）",
    )
    completed_at = Column(TIMESTAMP, nullable=True)