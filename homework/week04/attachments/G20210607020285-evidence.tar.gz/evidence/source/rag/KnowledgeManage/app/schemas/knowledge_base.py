from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, TypeVar, Generic
from datetime import datetime


# --- KnowledgeBase ---
class KnowledgeBaseCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="知识库名称")
    description: Optional[str] = Field(None, max_length=500, description="知识库描述")
    llm_model_id: str = Field(..., description="LLM 模型 ID")
    embedding_model_id: str = Field(..., description="Embedding 模型 ID")
    image_model_id: str = Field(..., description="图片识别模型 ID")
    rerank_model_id: str = Field(..., description="Rerank 模型 ID")


class KnowledgeBaseUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    llm_model_id: Optional[str] = None
    embedding_model_id: Optional[str] = None
    image_model_id: Optional[str] = None
    rerank_model_id: Optional[str] = None


class KnowledgeBaseResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: Optional[str] = None
    user_id: str
    llm_model_id: str
    embedding_model_id: str
    image_model_id: str
    rerank_model_id: str
    created_at: datetime
    updated_at: datetime


# --- Paginated ---
T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
