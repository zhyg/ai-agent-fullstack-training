"""Embedding service — generate vectors via LlmGateway."""

import logging
from typing import Dict, List

import httpx
from sqlalchemy import text

from app.core.config import settings
from app.core.database import SessionLocal

logger = logging.getLogger(__name__)

# In-memory cache: model_id (UUID) -> display_name
_model_name_cache: Dict[str, str] = {}


def get_llm_gateway_url() -> str:
    """Get LlmGateway service URL from config."""
    return settings.services.get("llm_gateway", "http://localhost:8003")


def resolve_model_name(model_id: str) -> str:
    """Resolve a model UUID to its display_name via LlmGateway's models table.

    Results are cached in memory to avoid repeated DB queries.
    Falls back to the original model_id if lookup fails.
    """
    if model_id in _model_name_cache:
        return _model_name_cache[model_id]

    try:
        db = SessionLocal()
        row = db.execute(
            text(
                "SELECT COALESCE(display_name, name) "
                "FROM llm_gateway.models WHERE id = :mid"
            ),
            {"mid": model_id},
        ).scalar()
        db.close()
        if row:
            _model_name_cache[model_id] = row
            return row
    except Exception as e:
        logger.warning("Failed to resolve model name for %s: %s", model_id, e)

    return model_id


async def generate_embeddings(
    texts: List[str],
    embedding_model_id: str,
    api_key: "[REDACTED]"
) -> List[List[float]]:
    """Generate embedding vectors for a list of texts via LlmGateway.

    Calls the LlmGateway /embeddings endpoint synchronously.

    Args:
        texts: List of text strings to embed
        embedding_model_id: The embedding model ID configured in the knowledge base
        api_key: "[REDACTED]"

    Returns:
        List of embedding vectors (each is a list of floats)
    """
    if not texts:
        return []

    gateway_url = get_llm_gateway_url()
    llm_api_key = "[REDACTED]"

    # Resolve UUID to model display name for LlmGateway
    model_name = resolve_model_name(embedding_model_id)

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{gateway_url}/api/llm/v1/embeddings",
                json={
                    "model": model_name,
                    "input": texts,
                },
                headers={
                    "Authorization": f"Bearer {llm_api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
    except httpx.HTTPError as e:
        logger.error("Embedding API call failed: %s", e)
        raise RuntimeError(f"Embedding 服务不可用: {e}") from e

    result = resp.json()

    # Parse response — expect OpenAI-compatible format
    # {"data": [{"embedding": [...], "index": 0}, ...]}
    if "data" in result:
        # Sort by index to ensure correct order
        sorted_data = sorted(result["data"], key=lambda x: x.get("index", 0))
        return [item["embedding"] for item in sorted_data]
    elif "embeddings" in result:
        return result["embeddings"]
    elif isinstance(result, list):
        return result
    else:
        raise RuntimeError(f"Unexpected embedding response format: {type(result)}")


async def get_embedding_dims(embedding_model_id: str, api_key: "[REDACTED]"
    """Get the dimension of the embedding model by generating a test vector.

    Returns the dimension count (e.g., 1024, 768, 1536).
    """
    try:
        vectors = await generate_embeddings(["test"], embedding_model_id, api_key)
        if vectors and vectors[0]:
            return len(vectors[0])
    except Exception as e:
        logger.warning("Failed to detect embedding dims, using default 1024: %s", e)

    return 1024  # Default fallback
