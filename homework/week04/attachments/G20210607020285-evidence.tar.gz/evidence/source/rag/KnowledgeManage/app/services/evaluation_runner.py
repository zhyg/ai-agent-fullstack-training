"""评测后台执行器（014-knowledge-evaluation）。

契约来源: specs/014-knowledge-evaluation/contracts/evaluation-api.md（§3 SSE 事件）。
职责（research R6/R7/R10/R12）:
- T022: 评分协程——占位符渲染、evaluation.recall/accuracy 子 span + set_prompt_attrs、
  llm_client.call_json（禁止新造重试循环）、后端核算得分、raw_output 落库
- T023: 逐题串行执行——题间查 cancel_requested、每题重新 build_snapshot（决策24）、
  整题 wait_for 超时兜底、每题完成即 UPDATE 明细并发布 progress、终态发布 done、
  事件订阅表 dict[run_id, set[Queue]]、shutdown() 收尾

单 worker 部署（Dockerfile CMD 无 --workers），进程内 asyncio.create_task + 订阅队列，
不复用 chat 的 Redis Stream/租约（R6）。
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set

from app.core.database import SessionLocal
from app.models.evaluation_item import EvaluationItem
from app.models.evaluation_run import EvaluationRun
from app.models.evaluation_setting import EvaluationSetting
from app.models.prompt import Prompt
from app.schemas.evaluation import (
    AccuracyResult,
    RecallResult,
    RunDoneEvent,
    RunProgressEvent,
    RunSnapshotEvent,
)
from app.services.agent_runtime import llm_client, steps, tracing
from app.services.agent_runtime.evaluation import run_evaluation_question
from app.services.agent_runtime.llm_client import JsonValidationFailed, ModelUnavailableError
from app.services.agent_runtime.state import PromptSnapshot

logger = logging.getLogger(__name__)

# 单题超时兜底（澄清 Q2）：含作答与两次评分，超时记失败继续下一题；固定常量不做配置项
ITEM_TIMEOUT_SECONDS = 600

# 进程内事件订阅表与任务注册（R6）
_subscribers: Dict[str, Set[asyncio.Queue]] = {}
_tasks: Dict[str, asyncio.Task] = {}
_cancel_flags: Dict[str, asyncio.Event] = {}
_item_cancel_events: Dict[str, asyncio.Event] = {}
_shutdown_flag = asyncio.Event()


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# T022: 评分协程（R4/R5/R10，FR-021~026/037）
# ---------------------------------------------------------------------------

def _json_prompt(content: str, result_model) -> str:
    schema = json.dumps(result_model.model_json_schema(), ensure_ascii=False)
    return f"{content}\n\n输出 JSON Schema：\n{schema}\n{steps.JSON_OUTPUT_SUFFIX}"


def _render_context(context) -> str:
    """{context} 仅渲染文档名+片段内容，不含得分（决策5/8）."""
    parts = []
    for i, ref in enumerate(context or []):
        if isinstance(ref, dict):
            file_name, content = ref.get("file_name", ""), ref.get("content", "")
        else:
            file_name, content = getattr(ref, "file_name", ""), getattr(ref, "content", "")
        parts.append(f"[{i}] ({file_name}) {content}")
    return "\n\n".join(parts) or "（无）"


def _score_failure(reason: str, raw_output: Optional[str] = None) -> dict:
    return {"score": None, "analysis": None, "raw_output": raw_output, "failure_reason": reason}


async def score_recall(
    *, model_name: str, prompt: PromptSnapshot,
    question: str, standard_answer: str, agent_answer: str,
    max_output_tokens=None, cancel_event=None,
) -> dict:
    """召回率评分：后端核算 covered/总数，忽略模型自报 recall（R5，决策6）.

    Returns:
        {score, analysis, raw_output, failure_reason}；失败时 score/analysis 为 None。
    """
    rendered = steps.render_prompt(
        prompt.content, question=question, standard_answer=standard_answer, agent_answer=agent_answer,
    )
    span = tracing.get_tracer().start_span("evaluation.recall")
    tracing.set_prompt_attrs(span, prompt, "evaluation_recall")
    try:
        parsed = await llm_client.call_json(
            model_name,
            [{"role": "user", "content": _json_prompt(rendered, RecallResult)}],
            RecallResult,
            purpose="evaluation_recall",
            max_output_tokens=max_output_tokens,
            cancel_event=cancel_event,
            span=span,
        )
        covered = sum(1 for kp in parsed.key_points if kp.covered)
        score = covered / len(parsed.key_points)
        tracing.set_output(span, parsed.model_dump())
        return {"score": score, "analysis": parsed.model_dump(), "raw_output": None, "failure_reason": None}
    except JsonValidationFailed as e:
        return _score_failure(f"召回率评分输出校验失败：{e.detail}", e.raw_output)
    except ModelUnavailableError as e:
        return _score_failure(f"召回率评分模型不可用：{e}")
    finally:
        span.end()


async def score_accuracy(
    *, model_name: str, prompt: PromptSnapshot,
    question: str, context, standard_answer: str, agent_answer: str,
    max_output_tokens=None, cancel_event=None,
) -> dict:
    """准确度评分：max(0, 100 − 5×问题数)，空清单合法 = 100 分（R5，决策7）."""
    rendered = steps.render_prompt(
        prompt.content, question=question, context=_render_context(context),
        standard_answer=standard_answer, agent_answer=agent_answer,
    )
    span = tracing.get_tracer().start_span("evaluation.accuracy")
    tracing.set_prompt_attrs(span, prompt, "evaluation_accuracy")
    try:
        parsed = await llm_client.call_json(
            model_name,
            [{"role": "user", "content": _json_prompt(rendered, AccuracyResult)}],
            AccuracyResult,
            purpose="evaluation_accuracy",
            max_output_tokens=max_output_tokens,
            cancel_event=cancel_event,
            span=span,
        )
        score = float(max(0, 100 - 5 * len(parsed.issues)))
        tracing.set_output(span, parsed.model_dump())
        return {"score": score, "analysis": parsed.model_dump(), "raw_output": None, "failure_reason": None}
    except JsonValidationFailed as e:
        return _score_failure(f"准确度评分输出校验失败：{e.detail}", e.raw_output)
    except ModelUnavailableError as e:
        return _score_failure(f"准确度评分模型不可用：{e}")
    finally:
        span.end()


# ---------------------------------------------------------------------------
# T023: 事件订阅与执行器（R6/R7/R12）
# ---------------------------------------------------------------------------

def subscribe(run_id: str) -> asyncio.Queue:
    queue: asyncio.Queue = asyncio.Queue()
    _subscribers.setdefault(run_id, set()).add(queue)
    return queue


def unsubscribe(run_id: str, queue: asyncio.Queue) -> None:
    queues = _subscribers.get(run_id)
    if queues is not None:
        queues.discard(queue)
        if not queues:
            _subscribers.pop(run_id, None)


def publish(run_id: str, event: dict) -> None:
    for queue in _subscribers.get(run_id, ()):
        queue.put_nowait(event)


def start_run(run_id: str) -> None:
    """启动后台执行任务（须在事件循环内调用，POST /runs 为 async 端点）."""
    _cancel_flags[run_id] = asyncio.Event()
    task = asyncio.create_task(_execute_run(run_id))
    _tasks[run_id] = task
    task.add_done_callback(lambda t: _tasks.pop(run_id, None))


def request_cancel(run_id: str) -> None:
    """用户取消的进程内快路径；DB cancel_requested 为权威标记（R6）."""
    flag = _cancel_flags.get(run_id)
    if flag is not None:
        flag.set()


async def shutdown() -> None:
    """优雅关闭（R12）：set 全部取消信号并等待任务收尾，模式同 chat_service.finish_generations."""
    _shutdown_flag.set()
    for event in _item_cancel_events.values():
        event.set()
    tasks = list(_tasks.values())
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _shutdown_flag.clear()


def _prompt_snapshot(db, prompt_id: str) -> PromptSnapshot:
    row = db.query(Prompt).filter(Prompt.id == prompt_id).first()
    return PromptSnapshot(prompt_id=row.id, name=row.name, version=row.version, content=row.content)


def _done_event(run, items: List[EvaluationItem]) -> dict:
    """终态事件：平均分仅 success 题（R13 同口径），无成功题为 null."""
    success = [i for i in items if i.status == "success"]
    avg_recall = sum(i.recall for i in success) / len(success) if success else None
    avg_accuracy = sum(i.accuracy for i in success) / len(success) if success else None
    return RunDoneEvent(
        run_id=run.id, status=run.status,
        completed=run.completed_items or 0, total=run.total_items,
        avg_recall=avg_recall, avg_accuracy=avg_accuracy,
        error_message=run.error_message,
    ).model_dump()


async def _process_item(
    db, run, item, *, model_name: str,
    recall_prompt: PromptSnapshot, accuracy_prompt: PromptSnapshot, cancel_event,
) -> None:
    """单题：无会话入口作答 + 根 span 内评分 → 原地写明细字段（落库由调用方 commit）."""

    async def _noop_emit(_chunk):
        pass

    async def _score_hook(result: dict) -> dict:
        meta = result.get("meta") or {}
        # 执行失败/取消/需澄清不评分（R2）；empty_retrieval 视为正常答案照常评分
        if result.get("error") or result.get("cancelled"):
            return {}
        if meta.get("terminate_reason") == "clarify_failed":
            return {}
        references = meta.get("references") or []
        answer = result.get("content") or ""
        recall_res = await score_recall(
            model_name=model_name, prompt=recall_prompt,
            question=item.question, standard_answer=item.standard_answer,
            agent_answer=answer, cancel_event=cancel_event,
        )
        accuracy_res = await score_accuracy(
            model_name=model_name, prompt=accuracy_prompt,
            question=item.question, context=references, standard_answer=item.standard_answer,
            agent_answer=answer, cancel_event=cancel_event,
        )
        return {"recall_result": recall_res, "accuracy_result": accuracy_res}

    result = await run_evaluation_question(
        agent_id=run.agent_id, kb_ids=run.knowledge_base_ids or [], user_id=run.user_id,
        question=item.question, cancel_event=cancel_event, emit=_noop_emit,
        run_id=run.id, seq=item.seq, score_hook=_score_hook,
    )
    item.trace_id = result.get("trace_id") or None
    item.completed_at = _now()
    meta = result.get("meta") or {}
    if result.get("error"):
        item.status = "failed"
        item.failure_reason = result["error"].get("message") or "执行失败"
        return
    if result.get("cancelled"):
        item.status = "failed"
        item.failure_reason = "执行已取消"
        return
    item.agent_answer = result.get("content") or ""
    references = meta.get("references") or []
    item.context = [r if isinstance(r, dict) else r.model_dump() for r in references]
    if meta.get("terminate_reason") == "clarify_failed":
        # 澄清原因即 content（R2），两项得分置空
        item.status = "failed"
        item.failure_reason = item.agent_answer or "问题需澄清"
        return
    recall_res = result.get("recall_result") or _score_failure("召回率评分未执行")
    accuracy_res = result.get("accuracy_result") or _score_failure("准确度评分未执行")
    item.recall_analysis = recall_res.get("analysis")
    item.accuracy_analysis = accuracy_res.get("analysis")
    item.recall_raw_output = recall_res.get("raw_output")
    item.accuracy_raw_output = accuracy_res.get("raw_output")
    reasons = [r for r in (recall_res.get("failure_reason"), accuracy_res.get("failure_reason")) if r]
    if reasons:
        # 失败题得分置空，已完成部分（答案/上下文/单项分析 JSON）保留（契约 §3，FR-025/026）
        item.status = "failed"
        item.failure_reason = "；".join(reasons)
        item.recall = None
        item.accuracy = None
    else:
        item.status = "success"
        item.recall = recall_res["score"]
        item.accuracy = accuracy_res["score"]


async def _execute_run(run_id: str) -> None:
    """逐题串行执行器：题间取消/每题实时快照/整题超时/逐题落库+progress/终态 done."""
    db = SessionLocal()
    run = None
    items: List[EvaluationItem] = []
    try:
        run = db.query(EvaluationRun).filter(EvaluationRun.id == run_id).first()
        if run is None:
            return
        # 评测设置任务期内锁定（R8），开跑读取一次；智能体配置每题重建快照（决策24）
        setting = db.query(EvaluationSetting).filter(EvaluationSetting.user_id == run.user_id).first()
        model_info = llm_client.resolve_model(setting.analysis_model_id)
        model_name = model_info["name"]
        recall_prompt = _prompt_snapshot(db, setting.recall_prompt_id)
        accuracy_prompt = _prompt_snapshot(db, setting.accuracy_prompt_id)
        items = (
            db.query(EvaluationItem)
            .filter(EvaluationItem.run_id == run_id)
            .order_by(EvaluationItem.seq)
            .all()
        )
        flag = _cancel_flags.get(run_id)
        for item in items:
            if _shutdown_flag.is_set():
                run.status = "failed"
                run.error_message = "服务重启中断"
                break
            # 题间取消：DB 标记为权威（R6），进程内 Event 为快路径
            db.refresh(run)
            if run.cancel_requested or (flag is not None and flag.is_set()):
                run.status = "cancelled"
                break
            item_cancel = asyncio.Event()
            _item_cancel_events[run_id] = item_cancel
            try:
                await asyncio.wait_for(
                    _process_item(
                        db, run, item, model_name=model_name,
                        recall_prompt=recall_prompt, accuracy_prompt=accuracy_prompt,
                        cancel_event=item_cancel,
                    ),
                    timeout=ITEM_TIMEOUT_SECONDS,
                )
            except asyncio.TimeoutError:
                # 超时先 set 该题 cancel_event 终止内部模型调用，再记失败继续（R7）
                item_cancel.set()
                item.status = "failed"
                item.failure_reason = "执行超时"
                item.completed_at = _now()
            except Exception as e:
                logger.exception("evaluation item error run_id=%s seq=%s", run_id, item.seq)
                item.status = "failed"
                item.failure_reason = f"执行异常：{e}"
                item.completed_at = _now()
            run.completed_items = (run.completed_items or 0) + 1
            db.commit()
            publish(run_id, RunProgressEvent(
                run_id=run_id, status=run.status,
                completed=run.completed_items, total=run.total_items,
                last_item={"id": item.id, "seq": item.seq, "status": item.status,
                           "recall": item.recall, "accuracy": item.accuracy},
            ).model_dump())
        else:
            # 全题失败仍 completed（FR-019，决策25）
            run.status = "completed"
    except Exception as e:
        logger.exception("evaluation run failed run_id=%s", run_id)
        if run is not None:
            run.status = "failed"
            run.error_message = f"任务执行异常：{e}"
    finally:
        if run is not None:
            run.finished_at = _now()
            try:
                db.commit()
            except Exception:
                logger.warning("evaluation run final commit failed run_id=%s", run_id, exc_info=True)
            publish(run_id, _done_event(run, items))
        _item_cancel_events.pop(run_id, None)
        _cancel_flags.pop(run_id, None)
        db.close()


# ---------------------------------------------------------------------------
# SSE 事件流（契约 §3，R6）：连接即发 snapshot，终态 done 后关闭
# ---------------------------------------------------------------------------

def _load_run(run_id: str):
    db = SessionLocal()
    try:
        return db.query(EvaluationRun).filter(EvaluationRun.id == run_id).first()
    finally:
        db.close()


def _done_event_from_db(run) -> dict:
    db = SessionLocal()
    try:
        items = db.query(EvaluationItem).filter(EvaluationItem.run_id == run.id).all()
        return _done_event(run, items)
    finally:
        db.close()


async def event_stream(run_id: str):
    """归属校验由 router 完成；断线重连/刷新靠 snapshot 恢复进度（R6）."""
    queue = subscribe(run_id)
    try:
        run = _load_run(run_id)
        if run is None:
            return
        yield steps.sse(RunSnapshotEvent(
            run_id=run.id, status=run.status,
            completed=run.completed_items or 0, total=run.total_items,
        ).model_dump())
        if run.status != "running":
            yield steps.sse(_done_event_from_db(run))
            return
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=30)
            except asyncio.TimeoutError:
                # 兜底：执行器异常退出未发 done 时按 DB 终态收尾；否则发 keepalive 注释行
                fresh = _load_run(run_id)
                if fresh is not None and fresh.status != "running":
                    yield steps.sse(_done_event_from_db(fresh))
                    return
                yield ": keepalive\n\n"
                continue
            yield steps.sse(event)
            if event.get("type") == "done":
                return
    finally:
        unsubscribe(run_id, queue)