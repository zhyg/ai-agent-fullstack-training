from datetime import datetime
from enum import Enum
from typing import List, Optional, Union
from zoneinfo import ZoneInfo

from pydantic import BaseModel, model_validator

# 资源消耗监控 DTO（015-resource-consumption-monitor，data-model.md §2）
# 日/月切分统一按北京时间（决策4）
BJ_TZ = ZoneInfo("Asia/Shanghai")


class MetricType(str, Enum):
    tokens = "tokens"
    cost = "cost"


class ScopeType(str, Enum):
    user_daily = "user_daily"
    user_monthly = "user_monthly"
    all_monthly = "all_monthly"


class ConsumptionQuery(BaseModel):
    """GET /consumption/series 查询参数（contracts §2）。

    校验失败由路由层捕获 ValidationError 转 400（沿用 agents.py 惯例）。
    """
    metric: MetricType
    scope: ScopeType
    user_email: Optional[str] = None
    models: Optional[str] = None  # 逗号分隔；空/缺省 = 全部模型
    month: Optional[str] = None   # YYYY-MM，scope=user_daily 必填
    year: Optional[int] = None    # scope=*_monthly 必填

    @model_validator(mode="after")
    def _check_conditions(self):
        now = datetime.now(BJ_TZ)
        if self.scope in (ScopeType.user_daily, ScopeType.user_monthly):
            if not self.user_email or not self.user_email.strip():
                raise ValueError("scope=user_* 时 user_email 必填")
        if self.scope == ScopeType.user_daily:
            if not self.month:
                raise ValueError("scope=user_daily 时 month 必填")
            try:
                datetime.strptime(self.month, "%Y-%m")
            except ValueError:
                raise ValueError("month 格式须为 YYYY-MM")
            if self.month > now.strftime("%Y-%m"):
                raise ValueError("不可查询未来期间")
        if self.scope in (ScopeType.user_monthly, ScopeType.all_monthly):
            if self.year is None:
                raise ValueError("scope=*_monthly 时 year 必填")
            if self.year > now.year:
                raise ValueError("不可查询未来期间")
            if self.year < 2000:
                raise ValueError("year 范围为 2000 至当前年")
        return self

    @property
    def model_list(self) -> List[str]:
        """解析后的模型列表；空列表 = 全选（不加 model 过滤）。"""
        if not self.models:
            return []
        return [m.strip() for m in self.models.split(",") if m.strip()]


class SeriesItem(BaseModel):
    model: str
    values: List[Union[int, float]]  # 与 buckets 等长对齐；token 非负整数，费用非负浮点（6 位小数）


class SeriesOut(BaseModel):
    metric: str
    scope: str
    buckets: List[str]  # 升序；日 YYYY-MM-DD / 月 YYYY-MM
    series: List[SeriesItem]
    out_of_retention: bool = False


class OptionsOut(BaseModel):
    user_emails: List[str]
    models: List[str]
    is_admin: bool