"""Extract embedded tables without changing the saved Markdown."""

import re
from dataclasses import dataclass
from html.parser import HTMLParser

from markdown_it import MarkdownIt


_MARKDOWN = MarkdownIt("commonmark").enable("table")
_HTML_TABLE = re.compile(r"<table\b[^>]*>.*?</table\s*>", re.IGNORECASE | re.DOTALL)


@dataclass
class EmbeddedTable:
    start: int
    end: int
    headings: tuple[str, ...]
    headers: list[str]
    rows: list[list[str]]
    caption: str = ""
    sqlite_url: str | None = None


class _HTMLRows(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows: list[list[tuple[str, int, int]]] = []
        self.row: list[tuple[str, int, int]] | None = None
        self.cell: list[str] | None = None
        self.span = (1, 1)
        self.in_caption = False
        self.caption: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.row = []
        elif tag in {"td", "th"} and self.row is not None:
            self.cell = []
            attributes = dict(attrs)
            self.span = tuple(self._span(attributes.get(key)) for key in ("rowspan", "colspan"))
        elif tag == "caption":
            self.in_caption = True
        elif self.cell is not None:
            if tag == "img" and (src := dict(attrs).get("src")):
                self.cell.append(f"![]({src})")
            elif tag in {"p", "br", "div", "li"}:
                self.cell.append(" ")

    def handle_endtag(self, tag):
        if tag in {"td", "th"} and self.cell is not None and self.row is not None:
            self.row.append(("".join(self.cell).strip(), *self.span))
            self.cell = None
        elif tag == "tr" and self.row is not None:
            if self.row:
                self.rows.append(self.row)
            self.row = None
        elif tag == "caption":
            self.in_caption = False
        elif tag in {"p", "div", "li"} and self.cell is not None:
            self.cell.append(" ")

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)
        elif self.in_caption:
            self.caption.append(data)

    @staticmethod
    def _span(value):
        return min(1000, int(value)) if value and re.fullmatch(r"[1-9][0-9]{0,3}", value) else 1

    def grid(self):
        pending: dict[int, tuple[int, str]] = {}
        for row_index, cells in enumerate(self.rows):
            row = {col: value for col, (until, value) in pending.items() if until > row_index}
            pending = {col: entry for col, entry in pending.items() if entry[0] > row_index}
            col = 0
            for value, height, width in cells:
                while any(offset in row for offset in range(col, col + width)):
                    col += 1
                for offset in range(col, col + width):
                    row[offset] = value
                    if height > 1:
                        pending[offset] = (row_index + height, value)
                col += width
            yield [row.get(col, "") for col in range(max(row, default=-1) + 1)]


def extract_embedded_tables(text: str) -> list[EmbeddedTable]:
    offsets = [0]
    for line in re.finditer(r"\r\n|\r|\n", text):
        offsets.append(line.end())
    if offsets[-1] < len(text):
        offsets.append(len(text))

    tokens = _MARKDOWN.parse(text)
    headings: list[tuple[int, str]] = []
    tables = []

    def add_table(start, end, rows, caption=""):
        if not rows or not rows[0]:
            return
        width = max(map(len, rows))
        headers = [
            (rows[0][i].strip() if i < len(rows[0]) else "") or f"Column {i + 1}"
            for i in range(width)
        ]
        data_rows = [row + [""] * (width - len(row)) for row in rows[1:]]
        tables.append(EmbeddedTable(start, end, tuple(title for _, title in headings), headers, data_rows, caption))

    for i, token in enumerate(tokens):
        if token.type == "heading_open":
            level = int(token.tag[1:])
            while headings and headings[-1][0] >= level:
                headings.pop()
            headings.append((level, f"{'#' * level} {tokens[i + 1].content}"))
        elif token.type == "html_block" and token.map:
            start, end = (offsets[line] for line in token.map)
            for match in _HTML_TABLE.finditer(text, start, end):
                parser = _HTMLRows()
                parser.feed(match.group())
                parser.close()
                add_table(match.start(), match.end(), list(parser.grid()), "".join(parser.caption).strip())
        elif token.type == "table_open" and token.map:
            start, end = (offsets[line] for line in token.map)
            rows = []
            for item in tokens[i + 1:]:
                if item.type == "table_close":
                    break
                if item.type == "tr_open":
                    rows.append([])
                elif item.type == "inline":
                    rows[-1].append(item.content)
            add_table(start, end, rows)

    return tables
