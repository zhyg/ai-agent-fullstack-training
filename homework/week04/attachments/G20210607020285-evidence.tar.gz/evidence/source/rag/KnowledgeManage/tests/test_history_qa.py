"""历史问答 ES 写入/检索/组装单测（013 T004/T020，contracts/history-qa-es §2/§3；mock ES 与 embedding）."""
import asyncio
import json
import unittest
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from elasticsearch import ApiError, TransportError

from app.services import history_qa_service as hqs
from app.services.agent_runtime.state import (
    AgentConfigSnapshot,
    ModelRef,
    PromptSnapshot,
    RequestRuntimeState,
)


def make_snapshot(context_tokens=128000, history_top_k=10):
    prompts = {
        p: PromptSnapshot(prompt_id=f"p-{p}", name=p, version="v1",
                          content=f"{p} 提示词：{{question}} {{history}}")
        for p in ("clarify", "rewrite", "answer")
    }
    snap = AgentConfigSnapshot(
        agent_id="a1", agent_type="quick_qa", prompts=prompts,
        analysis_model=ModelRef("m1", "gpt-test", context_tokens),
        embedding_model=ModelRef("emb-1", "emb-test", 0),
        kb_ids=["kb1"],
    )
    snap.history_top_k = history_top_k
    return snap


def make_state(history=None, question="当前问题", snapshot=None):
    return RequestRuntimeState(
        generation_id="g1", chat_id="c1", user_id="u1",
        snapshot=snapshot or make_snapshot(), question=question,
        history=history if history is not None else [
            {"role": "user", "content": "q1"}, {"role": "assistant", "content": "a1"},
            {"role": "user", "content": "q2"}, {"role": "assistant", "content": "a2"},
            {"role": "user", "content": "q3"}, {"role": "assistant", "content": "a3"},
            {"role": "user", "content": question},
        ],
    )


def qa_hit(doc_id, question, answer, created_at, score=1.0):
    return {
        "_id": doc_id, "_score": score,
        "_source": {
            "chat_id": "c1", "question": question, "answer": answer,
            "qa_text": question + "\n" + answer, "created_at": created_at,
        },
    }


def resp(hits):
    return {"hits": {"hits": hits}}


class Collector:
    def __init__(self):
        self.events = []

    async def __call__(self, sse_str):
        self.events.append(json.loads(sse_str.removeprefix("data: ").strip()))


class IndexQaRoundTests(unittest.IsolatedAsyncioTestCase):
    """写入契约（contracts/history-qa-es §2）：全字段 / 拼接向量化 / dims 分索引 / _id 幂等."""

    def setUp(self):
        self.client = MagicMock()
        self.client.index = AsyncMock()
        self.embed = AsyncMock(return_value=[[0.1] * 4])
        self.ensure = AsyncMock(side_effect=lambda dims: f"chat_history_qa_{dims}")
        for p in (
            patch.object(hqs.embedding_service, "generate_embeddings", new=self.embed),
            patch.object(hqs.embedding_service, "resolve_model_name", return_value="emb-display"),
            patch.object(hqs.es_client, "get_async_client", new=AsyncMock(return_value=self.client)),
            patch.object(hqs.es_client, "ensure_history_index", new=self.ensure),
        ):
            p.start()
            self.addCleanup(p.stop)

    async def _index(self, message_id="msg-1"):
        await hqs.index_qa_round(
            chat_id="c1", user_id="u1", question="问题", answer="答案",
            message_id=message_id, embedding_model_id="emb-1", trace_id="trace-1",
        )

    async def test_document_full_fields_and_concat_embedding(self):
        await self._index()
        # 向量化对象为 question + "\n" + answer 拼接文本（2026-11-24 澄清）
        self.embed.assert_awaited_once_with(["问题\n答案"], "emb-1")
        kwargs = self.client.index.await_args.kwargs
        self.assertEqual(kwargs["index"], "chat_history_qa_4")
        self.assertEqual(kwargs["id"], "msg-1")  # _id = assistant 消息 id
        doc = kwargs["document"]
        for field in ("chat_id", "user_id", "question", "answer", "qa_text",
                      "created_at", "embedding_model", "embedding_model_id", "embeddings"):
            self.assertIn(field, doc)
        self.assertEqual(doc["chat_id"], "c1")
        self.assertEqual(doc["user_id"], "u1")
        self.assertEqual(doc["question"], "问题")
        self.assertEqual(doc["answer"], "答案")
        self.assertEqual(doc["qa_text"], "问题\n答案")
        self.assertEqual(doc["embedding_model"], "emb-display")
        self.assertEqual(doc["embedding_model_id"], "emb-1")
        self.assertEqual(doc["embeddings"], [0.1] * 4)
        datetime.fromisoformat(doc["created_at"])  # UTC ISO8601 可解析

    async def test_index_selected_by_actual_vector_dims(self):
        self.embed.return_value = [[0.2] * 7]
        await self._index()
        self.ensure.assert_awaited_once_with(7)
        self.assertEqual(self.client.index.await_args.kwargs["index"], "chat_history_qa_7")

    async def test_same_message_id_overwrites_idempotently(self):
        await self._index()
        await self._index()
        ids = [c.kwargs["id"] for c in self.client.index.await_args_list]
        self.assertEqual(ids, ["msg-1", "msg-1"])  # index API 覆盖写，不产生重复轮次


class RetrieveAndAssembleTests(unittest.IsolatedAsyncioTestCase):
    """检索契约（contracts/history-qa-es §3）：原问题 query / chat_id 过滤 / topk / RRF / 组装."""

    def setUp(self):
        self.client = MagicMock()
        self.embed = AsyncMock(return_value=[[0.2] * 8])
        for p in (
            patch.object(hqs.embedding_service, "generate_embeddings", new=self.embed),
            patch.object(hqs.es_client, "get_async_client", new=AsyncMock(return_value=self.client)),
        ):
            p.start()
            self.addCleanup(p.stop)

    def _search(self, bm25_hits, vector_hits):
        self.client.search = AsyncMock(side_effect=[resp(bm25_hits), resp(vector_hits)])

    async def test_query_filters_topk_and_script_score(self):
        state = make_state(snapshot=make_snapshot(history_top_k=7))
        self._search([qa_hit("h1", "早期问题", "早期答案", "2026-01-01T00:00:00+00:00")], [])
        await hqs.retrieve_and_assemble(state, Collector())
        self.embed.assert_awaited_once_with(["当前问题"], "emb-1")  # query 为用户原问题
        self.assertEqual(self.client.search.await_count, 2)
        for call in self.client.search.await_args_list:
            self.assertEqual(call.kwargs["index"], "chat_history_qa_8")  # 按 query 向量维度选索引
            self.assertTrue(call.kwargs["ignore_unavailable"])
            self.assertEqual(call.kwargs["body"]["size"], 7)  # topk 取快照 history_top_k
        bm25_body = self.client.search.await_args_list[0].kwargs["body"]
        must = bm25_body["query"]["bool"]["must"]
        self.assertEqual(must[0]["match"]["qa_text"], "当前问题")
        filt = bm25_body["query"]["bool"]["filter"]
        self.assertIn({"term": {"chat_id": "c1"}}, filt)
        vec_body = self.client.search.await_args_list[1].kwargs["body"]
        script = vec_body["query"]["script_score"]
        self.assertEqual(script["query"], {"term": {"chat_id": "c1"}})  # 两路均带过滤
        self.assertIn("cosineSimilarity(params.qv, 'embeddings') + 1.0", script["script"]["source"])
        self.assertEqual(script["script"]["params"]["qv"], [0.2] * 8)

    async def test_rrf_fusion_rank_order_and_truncation(self):
        h1 = qa_hit("d1", "q1", "a1", "2026-01-01T00:00:00+00:00")
        h2 = qa_hit("d2", "q2", "a2", "2026-01-02T00:00:00+00:00")
        h3 = qa_hit("d3", "q3", "a3", "2026-01-03T00:00:00+00:00")
        fused = hqs._rrf_fuse_rounds([h1, h2], [h2, h3], top_k=2, rrf_k=60)
        # d2 双路命中（1/62+1/61）> d1（1/61）> d3（1/62），截断 top_k=2
        self.assertEqual([h["_id"] for h in fused], ["d2", "d1"])

    async def test_assemble_order_dedup_and_current_excluded(self):
        state = make_state()
        early = qa_hit("e1", "早期问题", "早期答案", "2026-01-01T00:00:00+00:00")
        late = qa_hit("e2", "较晚问题", "较晚答案", "2026-02-01T00:00:00+00:00")
        dup_base = qa_hit("e3", "q2", "ES里的a2", "2026-03-01T00:00:00+00:00")
        dup_current = qa_hit("e4", "当前问题", "旧答案", "2026-03-02T00:00:00+00:00")
        # BM25 名次序与时间序故意不一致，验证组装按 created_at 升序
        self._search([late, dup_base, early], [dup_current, early])
        await hqs.retrieve_and_assemble(state, Collector())
        self.assertEqual(
            [(m["role"], m["content"]) for m in state.clarify_history],
            [
                ("user", "早期问题"), ("assistant", "早期答案"),   # ES 命中 created_at 升序在前
                ("user", "较晚问题"), ("assistant", "较晚答案"),
                ("user", "q2"), ("assistant", "a2"),               # 保底 2 轮原文在后（去重取原文）
                ("user", "q3"), ("assistant", "a3"),
            ],
        )

    async def test_lone_user_message_not_a_complete_round(self):
        state = make_state(history=[
            {"role": "user", "content": "q1"}, {"role": "assistant", "content": "a1"},
            {"role": "user", "content": "落单问题"},
            {"role": "user", "content": "当前问题"},
        ])
        self._search([], [])
        await hqs.retrieve_and_assemble(state, Collector())
        # 零命中降级：clarify_history 保持 None（回退最近 10 轮）
        self.assertIsNone(state.clarify_history)
        assembled = hqs.assemble_history(state, [])
        self.assertEqual([m["content"] for m in assembled], ["q1", "a1"])  # 落单 user 不算完整轮

    async def test_step_events_start_end_emitted(self):
        state = make_state()
        self._search([qa_hit("h1", "早期问题", "早期答案", "2026-01-01T00:00:00+00:00")], [])
        emit = Collector()
        await hqs.retrieve_and_assemble(state, emit)
        step_events = [e for e in emit.events if e.get("step") == "history_retrieve"]
        self.assertEqual([e["status"] for e in step_events], ["start", "end"])

    async def test_history_rounds_full_content_recorded_on_span(self):
        # 命中轮次除 output 摘要 round_ids 外，另记 history.rounds 问答全文
        state = make_state()
        self._search([qa_hit("h1", "早期问题", "早期答案", "2026-01-01T00:00:00+00:00")], [])
        span = MagicMock()
        tracer = MagicMock()
        tracer.start_span.return_value = span
        with patch.object(hqs.tracing, "get_tracer", return_value=tracer):
            await hqs.retrieve_and_assemble(state, Collector())
        rounds_attrs = [json.loads(c.args[1]) for c in span.set_attribute.call_args_list
                        if c.args[0] == hqs.tracing.ATTR_HISTORY_ROUNDS]
        self.assertEqual(len(rounds_attrs), 1)
        self.assertEqual(rounds_attrs[0], [{
            "round_id": "h1", "question": "早期问题", "answer": "早期答案",
            "created_at": "2026-01-01T00:00:00+00:00",
        }])

    async def test_history_rounds_not_truncated_over_32kb(self):
        # 与 retrieval.chunks 同口径：全文不经 to_json_attr 32KB 截断
        state = make_state(snapshot=make_snapshot(context_tokens=1000000))
        long_answer = "长" * 20000  # UTF-8 约 60KB
        self._search([qa_hit("big", "长问题", long_answer, "2026-01-01T00:00:00+00:00")], [])
        span = MagicMock()
        tracer = MagicMock()
        tracer.start_span.return_value = span
        with patch.object(hqs.tracing, "get_tracer", return_value=tracer):
            await hqs.retrieve_and_assemble(state, Collector())
        raw = [c.args[1] for c in span.set_attribute.call_args_list
               if c.args[0] == hqs.tracing.ATTR_HISTORY_ROUNDS][0]
        self.assertNotIn("截断", raw)
        self.assertEqual(json.loads(raw)[0]["answer"], long_answer)

    async def test_budget_trim_drops_head_keeps_guaranteed_tail(self):
        # 预算 50 token：ES 命中长答案超预算 → 头部逐轮淘汰，保底 2 轮（尾部）保留
        state = make_state(snapshot=make_snapshot(context_tokens=60))
        state.snapshot.max_output_tokens = 10
        long_hit = qa_hit("big", "超长问题", "长" * 300, "2026-01-01T00:00:00+00:00")
        self._search([long_hit], [])
        await hqs.retrieve_and_assemble(state, Collector())
        contents = [m["content"] for m in state.clarify_history]
        self.assertNotIn("长" * 300, contents)
        self.assertEqual(contents, ["q2", "a2", "q3", "a3"])


class RetrieveDegradeTests(unittest.IsolatedAsyncioTestCase):
    """013 T020：超时/ES 异常/embedding 失败/零命中/任意异常 → 降级不上抛（FR-010，R10）."""

    def setUp(self):
        self.client = MagicMock()
        self.embed = AsyncMock(return_value=[[0.2] * 8])
        self.span = MagicMock()
        tracer = MagicMock()
        tracer.start_span.return_value = self.span
        for p in (
            patch.object(hqs.embedding_service, "generate_embeddings", new=self.embed),
            patch.object(hqs.es_client, "get_async_client", new=AsyncMock(return_value=self.client)),
            patch.object(hqs.tracing, "get_tracer", return_value=tracer),
        ):
            p.start()
            self.addCleanup(p.stop)

    def _search(self, bm25_hits, vector_hits):
        self.client.search = AsyncMock(side_effect=[resp(bm25_hits), resp(vector_hits)])

    def _degraded_attrs(self):
        """取 span 上 history_retrieve_degraded 事件属性（to_json_attr 对字符串原样保留）."""
        for call in self.span.add_event.call_args_list:
            if call.args[0] == hqs.tracing.EVENT_HISTORY_RETRIEVE_DEGRADED:
                return call.kwargs["attributes"]
        return None

    async def _run_degraded(self, reason):
        """公共断言：clarify_history 保持 None、span 记 reason、end 事件带降级 message."""
        state = make_state()
        emit = Collector()
        await hqs.retrieve_and_assemble(state, emit)  # 不上抛
        self.assertIsNone(state.clarify_history)
        attrs = self._degraded_attrs()
        self.assertIsNotNone(attrs, "缺少 history_retrieve_degraded 事件")
        self.assertEqual(attrs["reason"], reason)
        end_events = [e for e in emit.events
                      if e.get("step") == "history_retrieve" and e["status"] == "end"]
        self.assertEqual(len(end_events), 1)
        self.assertEqual(end_events[0].get("message"), "历史检索降级，使用最近历史")
        outputs = [json.loads(c.args[1]) for c in self.span.set_attribute.call_args_list
                   if c.args[0] == hqs.tracing.ATTR_OUTPUT]
        self.assertTrue(outputs[-1]["degraded"])
        # 降级时不记 history.rounds 全文
        self.assertFalse(any(c.args[0] == hqs.tracing.ATTR_HISTORY_ROUNDS
                             for c in self.span.set_attribute.call_args_list))

    async def test_timeout_wraps_whole_retrieval(self):
        async def slow_embed(*args, **kwargs):
            await asyncio.sleep(0.5)
            return [[0.2] * 8]
        self.embed.side_effect = slow_embed
        with patch.object(hqs.settings.agent_runtime, "history_retrieve_timeout", 0.05):
            await self._run_degraded("timeout")
        self.client.search.assert_not_called()  # 向量化阶段即被限时取消

    async def test_es_transport_error_degrades_unavailable(self):
        self.client.search = AsyncMock(side_effect=TransportError("es down"))
        await self._run_degraded("unavailable")

    async def test_es_api_error_degrades_unavailable(self):
        self.client.search = AsyncMock(
            side_effect=ApiError("bad", meta=SimpleNamespace(status=500), body={}))
        await self._run_degraded("unavailable")

    async def test_embedding_exception_degrades_embedding_failed(self):
        self.embed.side_effect = RuntimeError("gateway down")
        await self._run_degraded("embedding_failed")

    async def test_embedding_empty_vector_degrades_embedding_failed(self):
        self.embed.return_value = [[]]
        await self._run_degraded("embedding_failed")

    async def test_zero_hits_degrades_empty_result(self):
        self._search([], [])
        await self._run_degraded("empty_result")

    async def test_arbitrary_exception_degrades_error_without_raise(self):
        self.client.search = AsyncMock(side_effect=ValueError("boom"))
        await self._run_degraded("error")


class IndexFailureIsolationTests(unittest.IsolatedAsyncioTestCase):
    """013 T020：写入失败仅 logger.warning + span 记 history_index_failed，不重试不上抛（FR-013）."""

    def setUp(self):
        self.client = MagicMock()
        self.client.index = AsyncMock()
        self.embed = AsyncMock(return_value=[[0.1] * 4])
        self.span = MagicMock()
        tracer = MagicMock()
        tracer.start_as_current_span.return_value.__enter__.return_value = self.span
        for p in (
            patch.object(hqs.embedding_service, "generate_embeddings", new=self.embed),
            patch.object(hqs.embedding_service, "resolve_model_name", return_value="emb-display"),
            patch.object(hqs.es_client, "get_async_client", new=AsyncMock(return_value=self.client)),
            patch.object(hqs.es_client, "ensure_history_index",
                         new=AsyncMock(side_effect=lambda dims: f"chat_history_qa_{dims}")),
            patch.object(hqs.tracing, "get_tracer", return_value=tracer),
        ):
            p.start()
            self.addCleanup(p.stop)

    async def _index(self):
        await hqs.index_qa_round(
            chat_id="c1", user_id="u1", question="问题", answer="答案",
            message_id="msg-1", embedding_model_id="emb-1", trace_id="trace-1",
        )

    def _assert_failed_event(self):
        names = [c.args[0] for c in self.span.add_event.call_args_list]
        self.assertIn(hqs.tracing.EVENT_HISTORY_INDEX_FAILED, names)

    async def test_embedding_failure_logs_and_records_event_only(self):
        self.embed.side_effect = RuntimeError("embedding down")
        with self.assertLogs("app.services.history_qa_service", level="WARNING") as logs:
            await self._index()  # 不上抛
        self.assertTrue(any("msg-1" in line for line in logs.output))
        self._assert_failed_event()
        self.client.index.assert_not_awaited()

    async def test_es_index_failure_logs_and_records_event_only(self):
        self.client.index.side_effect = TransportError("es down")
        with self.assertLogs("app.services.history_qa_service", level="WARNING"):
            await self._index()
        self._assert_failed_event()
        self.assertEqual(self.client.index.await_count, 1)  # 不重试


if __name__ == "__main__":
    unittest.main()