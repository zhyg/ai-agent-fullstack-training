import logging

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user, require_permission
from app.schemas.agent import AgentResponse, AgentListResponse, AgentUpdate, StatusUpdate
from app.services import agent_service
from app.services.agent_service import NameConflictError

logger = logging.getLogger(__name__)

router = APIRouter(tags=["agents"])


def _validation_detail(e: ValidationError):
    """将 Pydantic 校验错误转为字段级 400 详情（契约约定 400 而非 422）。"""
    return [
        {"field": ".".join(str(loc) for loc in err["loc"]), "message": err["msg"]}
        for err in e.errors()
    ]


def _with_completeness(db: Session, agent) -> AgentResponse:
    """填充 config_complete/incomplete_reasons（FR-002，前端据此置灰问答入口）."""
    reasons = agent_service.config_incomplete_reasons(db, agent)
    item = AgentResponse.model_validate(agent)
    item.config_complete = not reasons
    item.incomplete_reasons = reasons
    return item


@router.get("/agents", response_model=AgentListResponse)
def list_agents(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """列出全部智能体（含停用），登录即可；附配置完整性供前端置灰。"""
    return {"items": [_with_completeness(db, a) for a in agent_service.list_agents(db)]}


@router.get("/agents/{agent_id}", response_model=AgentResponse)
def get_agent(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """智能体详情（编辑弹窗回显数据源），登录即可。"""
    agent = agent_service.get_agent(db, agent_id)
    if agent is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="智能体不存在",
        )
    return _with_completeness(db, agent)


@router.put("/agents/{agent_id}", response_model=AgentResponse)
def update_agent(
    agent_id: str,
    payload: dict = Body(...),
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """整份更新基础信息 + config，仅管理员；不修改 status/type。"""
    try:
        data = AgentUpdate.model_validate(payload)
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=_validation_detail(e),
        )
    try:
        agent = agent_service.update_agent(db, agent_id, data)
    except NameConflictError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e),
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    if agent is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="智能体不存在",
        )
    return agent


@router.patch("/agents/{agent_id}/status", response_model=AgentResponse)
def update_agent_status(
    agent_id: str,
    payload: dict = Body(...),
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """停用/启用，仅管理员；仅变更 status，config 不变，幂等。"""
    try:
        data = StatusUpdate.model_validate(payload)
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=_validation_detail(e),
        )
    try:
        agent = agent_service.set_status(db, agent_id, data.status)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    if agent is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="智能体不存在",
        )
    return agent