import sqlite3
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from app.services import document_pipeline as pipeline
from app.services import storage_service
from app.services.chunking_service import chunk_by_fixed, chunk_by_heading
from app.services.embedded_tables import extract_embedded_tables


HTML = """<table><tr><td><p>Name</p></td><td>Number</td><td>Description</td></tr>
<tr><td>WM_UNSPECIFIED</td><td>0</td><td>This value should not be used.</td></tr>
<tr><td>WM_POWER_MODE</td><td>1</td><td>Power sliding door is in power mode.</td></tr>
<tr><td>WM_MANUAL_MODE</td><td>2</td><td>Power sliding door is in manual mode.</td></tr></table>"""
PIPE = "| 类别 | Score |\n| --- | --- |\n| a\\|b | 98 |\n"


class EmbeddedTableTests(unittest.TestCase):
    def test_extracts_html_and_pipe_tables_but_ignores_code_examples(self):
        markdown = f"## Controls\n\n{HTML}\n\n{PIPE}\n```html\n{HTML}\n```\n"

        html, pipe = extract_embedded_tables(markdown)
        self.assertEqual(html.headers, ["Name", "Number", "Description"])
        self.assertEqual(html.rows[0], ["WM_UNSPECIFIED", "0", "This value should not be used."])
        self.assertEqual(html.headings, ("## Controls",))
        self.assertEqual(pipe.rows, [["a|b", "98"]])

    def test_both_strategies_group_rows_in_order_and_keep_long_rows_and_images(self):
        long_text = "long " * 80 + "![](images/row.png)"
        markdown = f"## Controls\n\nIntro\n\n{HTML}\n\nEnd of controls.\n\n| Description |\n| --- |\n| {long_text} |\n"
        for split in (chunk_by_heading, chunk_by_fixed):
            with self.subTest(strategy=split.__name__):
                tables = extract_embedded_tables(markdown)
                tables[0].sqlite_url = "kb/doc/tables/table_1.db"
                tables[1].sqlite_url = "kb/doc/tables/table_2.db"
                chunks = split(markdown, "example.docx", chunk_size=198, tables=tables)
                self.assertEqual([c["chunk_type"] for c in chunks], ["table_row", "table_row", "text", "table_row"])
                self.assertIn("Intro\nName: WM_UNSPECIFIED, Number: 0", chunks[0]["content"])
                self.assertIn("Name: WM_MANUAL_MODE, Number: 2", chunks[1]["content"])
                self.assertEqual([c["sqlite_url"] for c in chunks[:2]], [tables[0].sqlite_url] * 2)
                self.assertTrue(all(len(c["content"]) <= 198 for c in chunks[:2]))
                self.assertIn("End of controls.", chunks[2]["content"])
                self.assertIn(f"Description: {long_text}", chunks[3]["content"])
                self.assertEqual(chunks[3]["image_url"], ["images/row.png"])
                self.assertEqual(chunks[3]["sqlite_url"], tables[1].sqlite_url)


class EmbeddedTablePipelineTests(unittest.IsolatedAsyncioTestCase):
    async def test_uploaded_sqlite_contains_all_rows_and_chunks_link_to_the_same_db(self):
        markdown = f"{HTML}\n\n{PIPE}"
        doc = SimpleNamespace(id="doc", kb_id="kb", name="example.docx", extension="docx", ai_question_count=1)
        kb = SimpleNamespace(embedding_model_id="embedding", llm_model_id="llm")
        objects = {}

        def upload(**kwargs):
            objects[kwargs["object_path"]] = kwargs["data"].read()

        with (
            patch.object(pipeline, "_set_status"),
            patch.object(pipeline, "parse_document", return_value={"markdown_text": markdown, "md_path": "converted.md"}),
            patch.object(pipeline, "generate_embedded_table_name", side_effect=["door_modes", "scores"]) as name,
            patch.object(storage_service, "upload_file", side_effect=upload),
            patch.object(pipeline, "get_embedding_dims", return_value=2),
            patch.object(pipeline.es_client, "ensure_index"),
            patch.object(pipeline, "generate_embeddings", new=AsyncMock(side_effect=lambda texts, _: [[0, 0]] * len(texts))),
            patch.object(pipeline, "_index_chunks") as index,
            patch.object(pipeline, "_process_chunk_images", return_value=[]),
            patch.object(pipeline, "_generate_ai_questions", return_value=[]),
        ):
            await pipeline._process_document(Mock(), doc, kb, b"", {"chunk_size": 110})

        self.assertEqual(doc.md_path, "converted.md")
        self.assertEqual(name.await_count, 2)
        chunks = index.await_args.args[1]
        self.assertEqual(
            [c["sqlite_url"] for c in chunks],
            ["kb/doc/tables/table_1.db"] * 3 + ["kb/doc/tables/table_2.db"],
        )
        self.assertTrue(all(c["chunk_type"] == "table_row" and c["document_id"] == "doc" for c in chunks))
        with sqlite3.connect(":memory:") as conn:
            conn.deserialize(objects["kb/doc/tables/table_1.db"])
            self.assertEqual(conn.execute("SELECT Number FROM door_modes").fetchall(), [("0",), ("1",), ("2",)])
            conn.deserialize(objects["kb/doc/tables/table_2.db"])
            self.assertEqual(conn.execute("SELECT * FROM scores").fetchall(), [("a|b", "98")])
            self.assertEqual(conn.execute("SELECT description FROM _column_descriptions").fetchall(), [("类别",)])
