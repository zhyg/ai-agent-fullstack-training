"""知识库评测 REST + SSE 路由（014-knowledge-evaluation）。

契约来源: specs/014-knowledge-evaluation/contracts/evaluation-api.md。
Base 路径 /api/knowledge/evaluations（main.py 注册 prefix="/api/knowledge"），Bearer JWT，
跨用户访问一律 404。
- US1（T014）: GET/PUT /settings；GET/POST /test-sets；download/PUT/DELETE /test-sets/{id}
- US2（T025）: POST /runs；POST /runs/{id}/cancel；GET /runs/{id}/events（SSE）
- US3（T031）: GET /runs；GET/DELETE /runs/{id}
- US4（T036）: GET /runs/{run_id}/items/{item_id}/trace
"""
import json
import logging
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

from elasticsearch import ApiError, TransportError
from fastapi import APIRouter, Depends, File, Form, HTTPException, Response, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.models.evaluation_item import EvaluationItem
from app.schemas.evaluation import (
    RunCreate,
    SettingsOut,
    SettingsUpdate,
    TestSetListOut,
    validate_test_set_payload,
)
from app.services import evaluation_runner, evaluation_service, trace_query_service
from app.services.evaluation_service import (
    EvaluationLockedError,
    EvaluationPrecheckError,
    TestSetNameConflictError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/evaluations", tags=["evaluations"])


# ---------------------------------------------------------------------------
# 评测设置（契约 §1，US1）
# ---------------------------------------------------------------------------

@router.get("/settings", response_model=SettingsOut)
def get_settings(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """返回本人设置；无记录时返回空对象默认值。"""
    setting = evaluation_service.get_settings(db, current_user["id"])
    if setting is None:
        return SettingsOut()
    return SettingsOut(
        analysis_model_id=setting.analysis_model_id,
        recall_prompt_id=setting.recall_prompt_id,
        accuracy_prompt_id=setting.accuracy_prompt_id,
    )


@router.put("/settings", response_model=SettingsOut)
def save_settings(
    data: SettingsUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """保存设置（upsert）；running 锁定 409，提示词非本人 400。"""
    try:
        setting = evaluation_service.upsert_settings(db, current_user["id"], data)
    except EvaluationLockedError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    return SettingsOut(
        analysis_model_id=setting.analysis_model_id,
        recall_prompt_id=setting.recall_prompt_id,
        accuracy_prompt_id=setting.accuracy_prompt_id,
    )


# ---------------------------------------------------------------------------
# 测试集（契约 §2，US1）
# ---------------------------------------------------------------------------

@router.get("/test-sets", response_model=TestSetListOut)
def list_test_sets(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """本人测试集列表（不分页）。"""
    items = evaluation_service.list_test_sets(db, current_user["id"])
    return {"items": items}


@router.post("/test-sets", status_code=status.HTTP_201_CREATED)
async def create_test_set(
    name: str = Form(..., description="测试集名称，同一用户内唯一"),
    file: UploadFile = File(..., description="JSON 文件：[{question, answer}]"),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """上传测试集；校验失败 400（含具体错误），重名 409。"""
    name = name.strip()
    if not name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="测试集名称不能为空")
    raw = await file.read()
    try:
        items = validate_test_set_payload(raw)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    try:
        test_set = evaluation_service.create_test_set(db, current_user["id"], name, items)
    except TestSetNameConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    return {"id": test_set.id, "name": test_set.name, "item_count": test_set.item_count}


@router.get("/test-sets/{test_set_id}/download")
def download_test_set(
    test_set_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """从库导出标准 JSON 数组文件（决策13）。"""
    test_set = evaluation_service.get_test_set(db, current_user["id"], test_set_id)
    if test_set is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="测试集不存在")
    content = json.dumps(test_set.items, ensure_ascii=False, indent=2)
    # 中文名称用 RFC 5987 filename*，ASCII 回退名兼容旧客户端
    filename = quote(f"{test_set.name}.json")
    return Response(
        content=content,
        media_type="application/json",
        headers={
            "Content-Disposition": f"attachment; filename=\"testset.json\"; filename*=UTF-8''{filename}"
        },
    )


@router.put("/test-sets/{test_set_id}")
async def reupload_test_set(
    test_set_id: str,
    file: UploadFile = File(..., description="JSON 文件，校验规则同上传"),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """重新上传覆盖（名称/ID 不变）；锁定 409，校验失败 400。"""
    raw = await file.read()
    try:
        items = validate_test_set_payload(raw)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    try:
        test_set = evaluation_service.reupload_test_set(db, current_user["id"], test_set_id, items)
    except EvaluationLockedError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    if test_set is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="测试集不存在")
    return {"id": test_set.id, "name": test_set.name, "item_count": test_set.item_count}


@router.delete("/test-sets/{test_set_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_test_set(
    test_set_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除测试集（历史评测快照不受影响）；锁定 409。"""
    try:
        deleted = evaluation_service.delete_test_set(db, current_user["id"], test_set_id)
    except EvaluationLockedError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    if deleted is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="测试集不存在")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---------------------------------------------------------------------------
# 评测任务（契约 §3，US2）
# ---------------------------------------------------------------------------

@router.post("/runs", status_code=status.HTTP_201_CREATED)
async def create_run(
    data: RunCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """发起评测：全量预检 400（一次性列全部失效项），并发 409；创建即返 201。

    async 端点：service 内 asyncio.create_task 需运行中事件循环（R6）。
    """
    try:
        run = evaluation_service.create_run(db, current_user["id"], data)
    except EvaluationPrecheckError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except EvaluationLockedError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    return {"id": run.id, "status": run.status, "total_items": run.total_items}


@router.post("/runs/{run_id}/cancel")
def cancel_run(
    run_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """取消评测（异步生效：当前题含评分完成后终止）；终态 409，非本人 404。"""
    try:
        run = evaluation_service.cancel_run(db, current_user["id"], run_id)
    except EvaluationLockedError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评测任务不存在")
    return {"id": run.id, "status": run.status, "cancel_requested": run.cancel_requested}


@router.get("/runs/{run_id}/events")
async def run_events(
    run_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """SSE 进度（契约 §3）：连接即发 snapshot，增量 progress，终态 done 后关闭。"""
    run = evaluation_service.get_run(db, current_user["id"], run_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评测任务不存在")
    return StreamingResponse(
        evaluation_runner.event_stream(run_id),
        media_type="text/event-stream",
    )


# ---------------------------------------------------------------------------
# 评测结果（契约 §3，US3，T031）
# ---------------------------------------------------------------------------

@router.get("/runs")
def list_runs(
    page: int = 1,
    page_size: int = 20,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """历史列表：created_at 倒序分页；平均分实时聚合（仅 success 题）。"""
    items, total = evaluation_service.list_runs(db, current_user["id"], page, page_size)
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/runs/{run_id}")
def get_run_detail(
    run_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """详情：逐题快照按 seq 升序全字段；非本人 404。"""
    detail = evaluation_service.get_run_detail(db, current_user["id"], run_id)
    if detail is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评测任务不存在")
    return detail


@router.delete("/runs/{run_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_run(
    run_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除记录（级联删明细）；running 409 须先取消，非本人 404。"""
    try:
        deleted = evaluation_service.delete_run(db, current_user["id"], run_id)
    except EvaluationLockedError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    if deleted is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评测任务不存在")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---------------------------------------------------------------------------
# 题目 trace（契约 §4，US4，T036）
# ---------------------------------------------------------------------------

TRACE_EXPIRE_HOURS = 48  # R11：与 fetch_trace ±1 天索引窗口一致的确定性过期判据


@router.get("/runs/{run_id}/items/{item_id}/trace")
async def get_item_trace(
    run_id: str,
    item_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """题目轨迹（决策21）：按评测记录归属校验，不校验会话；命中透传 Jaeger 格式。"""
    run = evaluation_service.get_run(db, current_user["id"], run_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评测任务不存在")
    item = (
        db.query(EvaluationItem)
        .filter(EvaluationItem.id == item_id, EvaluationItem.run_id == run_id)
        .first()
    )
    if item is None or item.run_id != run_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评测题目不存在")
    if not item.trace_id:
        return {"ready": False, "reason": "no_trace"}
    try:
        result = await trace_query_service.fetch_trace(item.trace_id, item.created_at)
    except (ApiError, TransportError):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="轨迹服务暂不可用"
        )
    if not result.get("ready"):
        # 未命中：>48h 超索引窗口必然查不到 → expired，否则写入中 pending（R11）
        created_at = item.created_at
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - created_at > timedelta(hours=TRACE_EXPIRE_HOURS):
            return {"ready": False, "reason": "expired"}
    return result