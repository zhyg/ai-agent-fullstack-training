"""Chunking service — heading-based and fixed-length chunking strategies."""

import re
import uuid
import logging
from typing import List, Dict, Any, Optional

from llama_index.core.schema import Document as LIDocument
from llama_index.core.node_parser import MarkdownNodeParser

from app.services.embedded_tables import EmbeddedTable, extract_embedded_tables
from app.services.table_service import table_rows_to_text

logger = logging.getLogger(__name__)

# Default separators in priority order
DEFAULT_SEPARATORS = [
    "\n\n", "\n", "\u3002", "\uff1b", "\uff1f", "\uff01",
    ".", ";", "?", "!"
]

def chunk_by_heading(
    markdown_text: str,
    file_name: str,
    chunk_size: int = 512,
    chunk_overlap: int = 80,
    separators: Optional[List[str]] = None,
    *,
    tables: list[EmbeddedTable] | None = None,
) -> List[Dict[str, Any]]:
    """Chunk markdown by heading hierarchy using LlamaIndex MarkdownNodeParser.

    Large fragments are further split by separators to avoid oversized chunks.
    Table rows are treated as atomic units — single rows are never split.
    """
    if separators is None:
        separators = DEFAULT_SEPARATORS

    def split_prose(text):
        nodes = MarkdownNodeParser().get_nodes_from_documents([LIDocument(text=text)])
        return [
            part for node in nodes
            for part in _split_by_separators(node.text, chunk_size, chunk_overlap, separators)
        ]

    return _chunk_document(markdown_text, file_name, chunk_size, tables, split_prose)


def chunk_by_fixed(
    text: str,
    file_name: str,
    chunk_size: int = 512,
    chunk_overlap: int = 80,
    separators: Optional[List[str]] = None,
    *,
    tables: list[EmbeddedTable] | None = None,
) -> List[Dict[str, Any]]:
    """Chunk text by character length and configured separators.

    Table rows are treated as atomic units.
    """
    if separators is None:
        separators = DEFAULT_SEPARATORS

    return _chunk_document(
        text, file_name, chunk_size, tables,
        lambda prose: _split_by_separators(prose, chunk_size, chunk_overlap, separators),
    )


def chunk_table_rows(
    table_rows: List[str],
    table_name: str,
    sheet_name: str,
    sqlite_url: str,
    file_name: str,
    chunk_size: int = 512,
) -> List[Dict[str, Any]]:
    """Chunk table rows into table_row chunks.

    Each row is an atomic unit — never split mid-row.
    Rows are accumulated until chunk_size is reached, then a new chunk starts.
    """
    prefix = f"[文件名: {file_name}]\n[表名: {table_name}, Sheet: {sheet_name}]\n"
    chunks = []
    current_rows = []
    current_len = len(prefix)

    for row_text in table_rows:
        row_len = len(row_text) + 1  # +1 for newline
        if current_len + row_len > chunk_size and current_rows:
            # Flush current chunk
            content = prefix + "\n".join(current_rows)
            chunks.append(content)
            current_rows = []
            current_len = len(prefix)

        current_rows.append(row_text)
        current_len += row_len

    # Flush remaining
    if current_rows:
        content = prefix + "\n".join(current_rows)
        chunks.append(content)

    result = []
    for idx, chunk_content in enumerate(chunks):
        image_urls = _extract_image_urls(chunk_content)
        result.append({
            "chunk_id": str(uuid.uuid4()),
            "chunk_type": "table_row",
            "content": chunk_content,
            "image_url": image_urls if image_urls else None,
            "parent_chunk_id": None,
            "sqlite_url": sqlite_url,
            "chunk_index": idx,
            "file_name": file_name,
        })

    return result


# ─────────────────── Internal Helpers ───────────────────


def _chunk_document(text, file_name, chunk_size, tables, split_prose):
    if tables is None:
        tables = extract_embedded_tables(text)
    prefix = f"[文件名: {file_name}]\n"
    chunks = []

    def append(content, table=None):
        chunks.append({
            "chunk_id": str(uuid.uuid4()),
            "chunk_type": "table_row" if table else "text",
            "content": prefix + content,
            "image_url": _extract_image_urls(content) or None,
            "parent_chunk_id": None,
            "sqlite_url": table.sqlite_url if table else None,
            "chunk_index": len(chunks),
            "file_name": file_name,
        })

    def prose_parts(start, end):
        prose = text[start:end].strip()
        return [part for part in split_prose(prose) if part.strip()] if prose else []

    start = 0
    for table in tables:
        prose = prose_parts(start, table.start)
        context = "\n".join(table.headings)
        if table.caption:
            context = "\n".join(filter(None, (context, table.caption)))
        rows = table_rows_to_text(table.headers, table.rows) or [", ".join(table.headers)]
        if prose and len(prefix) + len(prose[-1]) + 1 + len(rows[0]) <= chunk_size:
            current = prose.pop()
        else:
            current = context
        for part in prose:
            append(part)
        has_rows = False
        for row in rows:
            if has_rows and len(prefix) + len(current) + 1 + len(row) > chunk_size:
                append(current, table)
                current = context
                has_rows = False
            # Context is optional when it would be the only cause of an oversized chunk.
            if not has_rows and len(prefix) + len(current) + 1 + len(row) > chunk_size:
                current = ""
            current = f"{current}\n{row}" if current else row
            has_rows = True
        append(current, table)
        start = table.end
    for part in prose_parts(start, len(text)):
        append(part)
    return chunks


def _split_by_separators(text: str, chunk_size: int, chunk_overlap: int, separators: List[str]):
    """Split text by separators, respecting priority order.

    Prefer the last occurrence of the highest-priority separator in each window.
    """
    chunk_size = max(1, chunk_size)
    chunk_overlap = min(max(0, chunk_overlap), chunk_size - 1)
    parts = []
    start = 0
    while start + chunk_size < len(text):
        end = start + chunk_size
        for separator in separators:
            if not separator:
                continue
            boundary = text.rfind(separator, start, end)
            if boundary >= start and boundary + len(separator) - start > chunk_overlap:
                end = boundary + len(separator)
                break
        parts.append(text[start:end])
        start = end - chunk_overlap
    if start < len(text):
        parts.append(text[start:])
    return parts


def _extract_image_urls(content: str) -> List[str]:
    """Extract all image URLs from markdown content."""
    pattern = re.compile(r"!\[.*?\]\((.*?)\)")
    return pattern.findall(content)
