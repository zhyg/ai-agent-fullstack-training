"""Elasticsearch chunks CRUD service."""

import uuid
import logging
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any, Tuple

from app.core import es_client

logger = logging.getLogger(__name__)


async def bulk_index_chunks(kb_id: str, chunks: List[Dict[str, Any]]) -> int:
    """Bulk index chunks into ES.

    Each chunk dict should contain: chunk_id, document_id, chunk_type, content,
    image_url, parent_chunk_id, embeddings, sqlite_url, chunk_index, file_name.
    Returns the number of chunks indexed.
    """
    if not chunks:
        return 0

    index_name = f"knowledge_chunks_{kb_id}"
    client = await es_client.get_async_client()

    actions = []
    for chunk in chunks:
        # Ensure chunk_id exists
        if "chunk_id" not in chunk:
            chunk["chunk_id"] = str(uuid.uuid4())
        # Add created_at if missing
        if "created_at" not in chunk:
            chunk["created_at"] = datetime.now(timezone.utc).isoformat()

        actions.append({"index": {"_index": index_name, "_id": chunk["chunk_id"]}})
        actions.append(chunk)

    resp = await client.bulk(body=actions, refresh="wait_for")
    if resp["errors"]:
        error_items = [
            item for item in resp["items"] if "error" in item.get("index", {})
        ]
        logger.error(
            "Bulk index had errors: %d/%d failed",
            len(error_items),
            len(chunks),
        )
        for item in error_items[:3]:
            logger.error("  Error: %s", item.get("index", {}).get("error"))
    else:
        logger.info("Bulk indexed %d chunks to %s", len(chunks), index_name)

    return len(chunks)


async def query_chunks(
    kb_id: str,
    document_id: str,
    page: int = 1,
    page_size: int = 50,
    chunk_type: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], int]:
    """Query chunks for a document with pagination and optional type filter.

    Returns (items, total).
    """
    index_name = f"knowledge_chunks_{kb_id}"
    client = await es_client.get_async_client()

    must_clauses = [
        {"term": {"document_id": document_id}},
    ]
    if chunk_type:
        must_clauses.append({"term": {"chunk_type": chunk_type}})

    body = {
        "query": {
            "bool": {
                "must": must_clauses,
                "must_not": [{"exists": {"field": "parent_chunk_id"}}],
            }
        },
        "sort": [{"chunk_index": "asc"}],
        "from": (page - 1) * page_size,
        "size": page_size,
    }

    try:
        resp = await client.search(index=index_name, body=body)
    except Exception:
        # Index may not exist yet
        return [], 0

    total = resp["hits"]["total"]["value"]
    items = [_hit_to_chunk(hit) for hit in resp["hits"]["hits"]]
    return items, total


async def get_children(kb_id: str, chunk_id: str) -> List[Dict[str, Any]]:
    """Get all child chunks of a given parent chunk.

    Used for image_ocr, image_caption, ai_question sub-chunks.
    """
    index_name = f"knowledge_chunks_{kb_id}"
    client = await es_client.get_async_client()

    body = {
        "query": {"term": {"parent_chunk_id": chunk_id}},
        "sort": [{"chunk_type": "asc"}],
        "size": 1000,
    }

    try:
        resp = await client.search(index=index_name, body=body)
    except Exception:
        return []

    return [_hit_to_chunk(hit) for hit in resp["hits"]["hits"]]


async def delete_by_document(kb_id: str, document_id: str) -> int:
    """Delete all chunks belonging to a document.

    Returns the number of chunks deleted.
    """
    index_name = f"knowledge_chunks_{kb_id}"
    client = await es_client.get_async_client()

    body = {"query": {"term": {"document_id": document_id}}}

    try:
        resp = await client.delete_by_query(
            index=index_name, body=body, refresh=True
        )
        deleted = resp.get("deleted", 0)
        if deleted > 0:
            logger.info("Deleted %d chunks for document %s", deleted, document_id)
        return deleted
    except Exception as e:
        logger.warning("Failed to delete chunks for document %s: %s", document_id, e)
        return 0


async def delete_index(kb_id: str) -> bool:
    """Delete the entire chunks index for a knowledge base."""
    index_name = f"knowledge_chunks_{kb_id}"
    client = await es_client.get_async_client()

    try:
        exists = await client.indices.exists(index=index_name)
        if exists:
            await client.indices.delete(index=index_name)
            logger.info("Deleted ES index: %s", index_name)
            return True
    except Exception as e:
        logger.warning("Failed to delete index %s: %s", index_name, e)
    return False


async def get_chunk_by_id(kb_id: str, chunk_id: str) -> Optional[Dict[str, Any]]:
    """Get a single chunk by its ID."""
    index_name = f"knowledge_chunks_{kb_id}"
    client = await es_client.get_async_client()

    try:
        resp = await client.get(index=index_name, id=chunk_id)
        return _hit_to_chunk({"_id": resp["_id"], "_source": resp["_source"]})
    except Exception:
        return None


def _hit_to_chunk(hit: Dict[str, Any]) -> Dict[str, Any]:
    """Convert an ES hit to a chunk dict."""
    source = hit.get("_source", {})
    return {
        "chunk_id": source.get("chunk_id", hit.get("_id", "")),
        "document_id": source.get("document_id", ""),
        "chunk_type": source.get("chunk_type", ""),
        "content": source.get("content", ""),
        "image_url": source.get("image_url"),
        "parent_chunk_id": source.get("parent_chunk_id"),
        "sqlite_url": source.get("sqlite_url"),
        "chunk_index": source.get("chunk_index", 0),
        "file_name": source.get("file_name", ""),
        "created_at": source.get("created_at"),
    }
