import asyncio
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from fastapi import FastAPI, HTTPException, WebSocketDisconnect
from fastapi.testclient import TestClient

from app.routers import document_status
from app.services import document_pipeline


class Subscription:
    async def __aenter__(self):
        self.notifications = asyncio.Queue()
        return self

    async def __aexit__(self, *exc):
        pass

    async def subscribe(self, channel):
        self.channel = channel

    async def listen(self):
        yield {"type": "subscribe"}
        while True:
            yield await self.notifications.get()


class DocumentStatusTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(document_status.router)
        self.subscription = Subscription()
        app.state.redis = SimpleNamespace(pubsub=Mock(return_value=self.subscription))
        self.redis = app.state.redis
        self.client = TestClient(app)
        self.path = "/documents/doc/status/ws"
        self.claims = {"type": "access", "sub": "owner", "exp": int(time.time()) + 60}

    def test_sends_current_snapshot_then_pushes_committed_update(self):
        old = {"id": "doc", "status": "parsing"}
        current = {"id": "doc", "status": "completed"}
        with (
            patch.object(document_status, "decode_token", return_value=self.claims),
            patch.object(
                document_status, "_snapshot", side_effect=[old, old, current, HTTPException(404)]
            ) as snapshot,
            self.client as client,
            client.websocket_connect(self.path) as socket,
        ):
            socket.send_text("test-token")
            self.assertEqual(socket.receive_json(), old)
            self.assertEqual(self.subscription.channel, "knowledge:document-status:doc")
            client.portal.call(self.subscription.notifications.put, {"type": "message"})
            self.assertEqual(socket.receive_json(), current)
            snapshot.assert_called_with("doc", "owner")
            client.portal.call(self.subscription.notifications.put, {"type": "message"})
            with self.assertRaises(WebSocketDisconnect) as error:
                socket.receive_json()
            self.assertEqual(error.exception.code, 4404)

    def test_does_not_subscribe_for_unauthorized_document(self):
        with (
            patch.object(document_status, "decode_token", return_value=self.claims),
            patch.object(document_status, "_snapshot", side_effect=HTTPException(404)),
            self.client.websocket_connect(self.path) as socket,
        ):
            socket.send_text("test-token")
            with self.assertRaises(WebSocketDisconnect) as error:
                socket.receive_json()
        self.assertEqual(error.exception.code, 4404)
        self.redis.pubsub.assert_not_called()


class StatusCommitTests(unittest.IsolatedAsyncioTestCase):
    async def test_notifies_only_after_commit(self):
        db = Mock()
        doc = SimpleNamespace(id="doc", status="parsing", error_message=None)

        async def verify_committed(document_id):
            db.commit.assert_called_once()
            self.assertEqual(document_id, "doc")
            self.assertEqual(doc.status, "completed")

        notify = AsyncMock(side_effect=verify_committed)
        with patch.object(document_pipeline.document_status, "notify", notify):
            await document_pipeline._set_status(db, doc, "completed")
        notify.assert_awaited_once()
