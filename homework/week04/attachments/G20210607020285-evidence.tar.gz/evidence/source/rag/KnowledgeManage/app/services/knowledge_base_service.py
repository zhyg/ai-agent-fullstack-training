"""Knowledge Base CRUD service."""

import uuid
from datetime import datetime, timezone
from typing import List, Optional, Tuple

from sqlalchemy.orm import Session

from app.models.knowledge_base import KnowledgeBase
from app.schemas.knowledge_base import KnowledgeBaseCreate, KnowledgeBaseUpdate


def list_knowledge_bases(
    db: Session, user_id: str, page: int = 1, page_size: int = 20
) -> Tuple[List[KnowledgeBase], int]:
    """List knowledge bases for the current user, ordered by updated_at desc."""
    query = db.query(KnowledgeBase).filter(KnowledgeBase.user_id == user_id)
    total = query.count()
    items = (
        query.order_by(KnowledgeBase.updated_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return items, total


def get_knowledge_base(
    db: Session, kb_id: str, user_id: str
) -> Optional[KnowledgeBase]:
    """Get a single knowledge base by ID, verify ownership."""
    return db.query(KnowledgeBase).filter(
        KnowledgeBase.id == kb_id, KnowledgeBase.user_id == user_id
    ).first()


def create_knowledge_base(
    db: Session, user_id: str, data: KnowledgeBaseCreate
) -> KnowledgeBase:
    """Create a new knowledge base. Raises ValueError if name already exists."""
    # Uniqueness pre-check
    existing = (
        db.query(KnowledgeBase)
        .filter(KnowledgeBase.user_id == user_id, KnowledgeBase.name == data.name)
        .first()
    )
    if existing:
        raise ValueError("该名称已存在")

    kb = KnowledgeBase(
        id=str(uuid.uuid4()),
        name=data.name,
        description=data.description,
        user_id=user_id,
        llm_model_id=data.llm_model_id,
        embedding_model_id=data.embedding_model_id,
        image_model_id=data.image_model_id,
        rerank_model_id=data.rerank_model_id,
    )
    db.add(kb)
    db.commit()
    db.refresh(kb)
    return kb


def update_knowledge_base(
    db: Session, kb_id: str, user_id: str, data: KnowledgeBaseUpdate
) -> Optional[KnowledgeBase]:
    """Update a knowledge base. Only owner can update. Raises ValueError on name conflict."""
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == kb_id, KnowledgeBase.user_id == user_id
    ).first()
    if not kb:
        return None

    # Name uniqueness pre-check (exclude self)
    if data.name is not None and data.name != kb.name:
        existing = (
            db.query(KnowledgeBase)
            .filter(
                KnowledgeBase.user_id == user_id,
                KnowledgeBase.name == data.name,
                KnowledgeBase.id != kb_id,
            )
            .first()
        )
        if existing:
            raise ValueError("该名称已存在")

    if data.name is not None:
        kb.name = data.name
    if data.description is not None:
        kb.description = data.description
    if data.llm_model_id is not None:
        kb.llm_model_id = data.llm_model_id
    if data.embedding_model_id is not None:
        kb.embedding_model_id = data.embedding_model_id
    if data.image_model_id is not None:
        kb.image_model_id = data.image_model_id
    if data.rerank_model_id is not None:
        kb.rerank_model_id = data.rerank_model_id

    kb.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(kb)
    return kb


def delete_knowledge_base(
    db: Session, kb_id: str, user_id: str
) -> bool:
    """Delete a knowledge base. Only owner can delete."""
    kb = db.query(KnowledgeBase).filter(
        KnowledgeBase.id == kb_id, KnowledgeBase.user_id == user_id
    ).first()
    if not kb:
        return False

    db.delete(kb)
    db.commit()
    return True
