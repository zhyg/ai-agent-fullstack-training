"""014-knowledge-evaluation US2：评分协程与容错（T019，FR-021~027/037，R2/R4/R5/R7/R10）。

- 得分核算/落库口径直接断言 score_recall/score_accuracy 返回值；
- 重试/围栏容错走真实 llm_client.call_json（仅 mock chat_completion）；
- span 名与 prompt 属性用 InMemorySpanExporter 断言（属性为直写字符串，容错解析）。
"""
import asyncio
import json
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from pydantic import ValidationError

from app.schemas.evaluation import AccuracyResult, KeyPoint, RecallResult
from app.services import evaluation_runner
from app.services.agent_runtime import llm_client
from app.services.agent_runtime.llm_client import JsonValidationFailed, ModelUnavailableError
from app.services.agent_runtime.state import PromptSnapshot
from tests.test_evaluation_runs import (
    fake_question_success,
    make_items,
    make_run,
    mock_executor_db,
    score_ok,
    success_answer,
)

RECALL_PROMPT = PromptSnapshot(
    prompt_id="p-1", name="召回提示词", version="v2",
    content="问题：{question}\n标准答案：{standard_answer}\nagent答案：{agent_answer}",
)
ACCURACY_PROMPT = PromptSnapshot(
    prompt_id="p-2", name="准确度提示词", version="v3",
    content="问题：{question}\n上下文：{context}\n标准答案：{standard_answer}\nagent答案：{agent_answer}",
)
REFERENCES = [
    {"file_name": "手册.pdf", "content": "片段正文", "score": 0.87,
     "chunk_id": "c1", "document_id": "d1", "kb_id": "kb-1"},
]


def recall_json(covered_flags, self_report=0.99):
    return json.dumps({
        "key_points": [
            {"point": f"要点{i}", "covered": flag} for i, flag in enumerate(covered_flags)
        ],
        "recall": self_report,
    }, ensure_ascii=False)


def accuracy_json(n_issues):
    return json.dumps({
        "issues": [
            {"type": "捏造", "content": f"语句{i}", "evidence": f"依据{i}"} for i in range(n_issues)
        ],
    }, ensure_ascii=False)


def completion(raw):
    return {"choices": [{"message": {"content": raw}}]}


class ScoringSchemaTests(unittest.TestCase):
    def test_recall_empty_key_points_rejected(self):
        with self.assertRaises(ValidationError):
            RecallResult.model_validate_json('{"key_points": [], "recall": 0}')

    def test_recall_covered_must_be_strict_bool(self):
        with self.assertRaises(ValidationError):
            KeyPoint.model_validate({"point": "要点", "covered": "true"})

    def test_key_point_empty_point_rejected(self):
        with self.assertRaises(ValidationError):
            KeyPoint.model_validate({"point": "", "covered": True})

    def test_accuracy_empty_issues_valid(self):
        parsed = AccuracyResult.model_validate_json('{"issues": []}')
        self.assertEqual(parsed.issues, [])


class ScoreComputationTests(unittest.IsolatedAsyncioTestCase):
    """后端核算（R5）：忽略模型自报 recall；准确度 max(0, 100−5×n)."""

    async def test_recall_computed_from_covered_ratio(self):
        parsed = RecallResult.model_validate_json(recall_json([True, True, False], self_report=0.99))
        with patch.object(llm_client, "call_json", AsyncMock(return_value=parsed)):
            result = await evaluation_runner.score_recall(
                model_name="gpt", prompt=RECALL_PROMPT,
                question="问", standard_answer="标答", agent_answer="agent答",
            )
        self.assertAlmostEqual(result["score"], 2 / 3)
        self.assertEqual(result["analysis"], parsed.model_dump())
        self.assertIsNone(result["failure_reason"])
        self.assertIsNone(result["raw_output"])

    async def test_accuracy_deducts_5_per_issue(self):
        parsed = AccuracyResult.model_validate_json(accuracy_json(3))
        with patch.object(llm_client, "call_json", AsyncMock(return_value=parsed)):
            result = await evaluation_runner.score_accuracy(
                model_name="gpt", prompt=ACCURACY_PROMPT,
                question="问", context=REFERENCES, standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(result["score"], 85.0)
        self.assertEqual(result["analysis"], parsed.model_dump())

    async def test_accuracy_floor_zero(self):
        parsed = AccuracyResult.model_validate_json(accuracy_json(25))
        with patch.object(llm_client, "call_json", AsyncMock(return_value=parsed)):
            result = await evaluation_runner.score_accuracy(
                model_name="gpt", prompt=ACCURACY_PROMPT,
                question="问", context=REFERENCES, standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(result["score"], 0.0)

    async def test_accuracy_empty_issues_full_score(self):
        parsed = AccuracyResult.model_validate_json(accuracy_json(0))
        with patch.object(llm_client, "call_json", AsyncMock(return_value=parsed)):
            result = await evaluation_runner.score_accuracy(
                model_name="gpt", prompt=ACCURACY_PROMPT,
                question="问", context=[], standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(result["score"], 100.0)

    async def test_placeholders_rendered_without_score_in_context(self):
        mock_call = AsyncMock(return_value=AccuracyResult.model_validate_json(accuracy_json(0)))
        with patch.object(llm_client, "call_json", mock_call):
            await evaluation_runner.score_accuracy(
                model_name="gpt", prompt=ACCURACY_PROMPT,
                question="问X", context=REFERENCES, standard_answer="标答Y", agent_answer="agent答Z",
            )
        rendered = mock_call.call_args.args[1][0]["content"]
        self.assertIn("问X", rendered)
        self.assertIn("标答Y", rendered)
        self.assertIn("agent答Z", rendered)
        self.assertIn("手册.pdf", rendered)
        self.assertIn("片段正文", rendered)
        self.assertNotIn("0.87", rendered)  # 决策5/8：得分不进评分提示词
        self.assertEqual(mock_call.call_args.kwargs["purpose"], "evaluation_accuracy")

    async def test_recall_placeholders_and_purpose(self):
        mock_call = AsyncMock(return_value=RecallResult.model_validate_json(recall_json([True])))
        with patch.object(llm_client, "call_json", mock_call):
            await evaluation_runner.score_recall(
                model_name="gpt", prompt=RECALL_PROMPT,
                question="问X", standard_answer="标答Y", agent_answer="agent答Z",
            )
        rendered = mock_call.call_args.args[1][0]["content"]
        for token in ("问X", "标答Y", "agent答Z"):
            self.assertIn(token, rendered)
        self.assertEqual(mock_call.call_args.kwargs["purpose"], "evaluation_recall")


class ScoringRetryTests(unittest.IsolatedAsyncioTestCase):
    """真实 call_json 集成（R4）：围栏容错/重试附上次输出/耗尽留 raw_output/传输层不重试."""

    async def test_fenced_json_extracted(self):
        raw = "```json\n" + recall_json([True, False]) + "\n```"
        with patch.object(llm_client, "chat_completion", AsyncMock(return_value=completion(raw))) as mock_chat:
            result = await evaluation_runner.score_recall(
                model_name="gpt", prompt=RECALL_PROMPT,
                question="问", standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(mock_chat.call_count, 1)
        self.assertAlmostEqual(result["score"], 0.5)

    async def test_empty_key_points_retries_then_succeeds(self):
        bad = completion('{"key_points": [], "recall": 0}')
        good = completion(recall_json([True, True]))
        with patch.object(llm_client, "chat_completion", AsyncMock(side_effect=[bad, good])) as mock_chat:
            result = await evaluation_runner.score_recall(
                model_name="gpt", prompt=RECALL_PROMPT,
                question="问", standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(mock_chat.call_count, 2)
        self.assertAlmostEqual(result["score"], 1.0)
        retry_messages = mock_chat.call_args_list[1].args[1]
        self.assertEqual(retry_messages[-2]["role"], "assistant")
        self.assertIn("未通过校验", retry_messages[-1]["content"])

    async def test_retry_exhausted_keeps_raw_output(self):
        bad = completion("不是 JSON 的输出")
        with patch.object(llm_client, "chat_completion", AsyncMock(return_value=bad)) as mock_chat:
            result = await evaluation_runner.score_recall(
                model_name="gpt", prompt=RECALL_PROMPT,
                question="问", standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(mock_chat.call_count, llm_client.MAX_JSON_RETRIES + 1)
        self.assertIsNone(result["score"])
        self.assertIsNone(result["analysis"])
        self.assertEqual(result["raw_output"], "不是 JSON 的输出")
        self.assertIn("校验失败", result["failure_reason"])

    async def test_final_adopted_json_is_last_success(self):
        seq = [completion("bad1"), completion("bad2"), completion(recall_json([True, False, True]))]
        with patch.object(llm_client, "chat_completion", AsyncMock(side_effect=seq)):
            result = await evaluation_runner.score_recall(
                model_name="gpt", prompt=RECALL_PROMPT,
                question="问", standard_answer="标答", agent_answer="agent答",
            )
        self.assertAlmostEqual(result["score"], 2 / 3)
        self.assertEqual(len(result["analysis"]["key_points"]), 3)

    async def test_model_unavailable_no_business_retry(self):
        with patch.object(llm_client, "call_json", AsyncMock(side_effect=ModelUnavailableError("网关不可用"))) as mock_call:
            result = await evaluation_runner.score_accuracy(
                model_name="gpt", prompt=ACCURACY_PROMPT,
                question="问", context=REFERENCES, standard_answer="标答", agent_answer="agent答",
            )
        self.assertEqual(mock_call.call_count, 1)
        self.assertIsNone(result["score"])
        self.assertIn("模型", result["failure_reason"])

    async def test_json_failed_exception_keeps_raw_output(self):
        err = JsonValidationFailed("evaluation_accuracy", "最后一次原始输出", "issues 字段缺失")
        with patch.object(llm_client, "call_json", AsyncMock(side_effect=err)):
            result = await evaluation_runner.score_accuracy(
                model_name="gpt", prompt=ACCURACY_PROMPT,
                question="问", context=REFERENCES, standard_answer="标答", agent_answer="agent答",
            )
        self.assertIsNone(result["score"])
        self.assertEqual(result["raw_output"], "最后一次原始输出")


class ScoringSpanTests(unittest.IsolatedAsyncioTestCase):
    """FR-037/R10：评分子 span 名与 prompt.name/version/purpose 属性、同 trace 父子关系."""

    def setUp(self):
        self.exporter = InMemorySpanExporter()
        provider = TracerProvider()
        provider.add_span_processor(SimpleSpanProcessor(self.exporter))
        self.tracer = provider.get_tracer("evaluation-test")
        patcher = patch.object(evaluation_runner.tracing, "get_tracer", return_value=self.tracer)
        patcher.start()
        self.addCleanup(patcher.stop)

    def _attr(self, span, key):
        value = span.attributes.get(key)
        # 容错解析：属性可能为 JSON 字符串或裸值（to_json_attr 已知坑）
        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, ValueError):
                return value
        return value

    async def test_recall_span_name_and_prompt_attrs(self):
        parsed = RecallResult.model_validate_json(recall_json([True]))
        with patch.object(llm_client, "call_json", AsyncMock(return_value=parsed)):
            with self.tracer.start_as_current_span("evaluation.item") as root:
                root_trace_id = root.get_span_context().trace_id
                await evaluation_runner.score_recall(
                    model_name="gpt", prompt=RECALL_PROMPT,
                    question="问", standard_answer="标答", agent_answer="agent答",
                )
        spans = {s.name: s for s in self.exporter.get_finished_spans()}
        self.assertIn("evaluation.recall", spans)
        span = spans["evaluation.recall"]
        self.assertEqual(span.get_span_context().trace_id, root_trace_id)
        self.assertEqual(span.parent.span_id, root.get_span_context().span_id)
        self.assertEqual(self._attr(span, "prompt.name"), "召回提示词")
        self.assertEqual(self._attr(span, "prompt.version"), "v2")
        self.assertEqual(self._attr(span, "prompt.purpose"), "evaluation_recall")

    async def test_accuracy_span_name_and_prompt_attrs(self):
        parsed = AccuracyResult.model_validate_json(accuracy_json(1))
        with patch.object(llm_client, "call_json", AsyncMock(return_value=parsed)):
            with self.tracer.start_as_current_span("evaluation.item"):
                await evaluation_runner.score_accuracy(
                    model_name="gpt", prompt=ACCURACY_PROMPT,
                    question="问", context=REFERENCES, standard_answer="标答", agent_answer="agent答",
                )
        spans = {s.name: s for s in self.exporter.get_finished_spans()}
        self.assertIn("evaluation.accuracy", spans)
        span = spans["evaluation.accuracy"]
        self.assertEqual(self._attr(span, "prompt.name"), "准确度提示词")
        self.assertEqual(self._attr(span, "prompt.version"), "v3")
        self.assertEqual(self._attr(span, "prompt.purpose"), "evaluation_accuracy")


class ExecutorScoringSemanticsTests(unittest.IsolatedAsyncioTestCase):
    """R2/R7：clarify_failed 记失败、empty_retrieval 照常评分、单题超时失败继续."""

    def setUp(self):
        self.run = make_run()
        self.items = make_items(3)
        self.db = mock_executor_db(self.run, self.items)
        patches = [
            patch.object(evaluation_runner, "SessionLocal", return_value=self.db),
            patch.object(evaluation_runner.llm_client, "resolve_model",
                         return_value={"name": "gpt", "context_tokens": 8000, "category": "chat"}),
            patch.object(evaluation_runner, "score_recall", AsyncMock(return_value=score_ok(0.2))),
            patch.object(evaluation_runner, "score_accuracy", AsyncMock(return_value=score_ok(60.0))),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        self.queue = evaluation_runner.subscribe("run-1")
        self.addCleanup(evaluation_runner.unsubscribe, "run-1", self.queue)

    async def test_clarify_failed_item_failed_with_reason(self):
        async def clarify_failed(**kwargs):
            return success_answer(content="问题中的“它”指代不明", meta={"terminate_reason": "clarify_failed"})

        with patch.object(evaluation_runner, "run_evaluation_question", side_effect=clarify_failed):
            with patch.object(evaluation_runner, "score_recall") as mock_recall:
                await evaluation_runner._execute_run("run-1")
                mock_recall.assert_not_called()
        for item in self.items:
            self.assertEqual(item.status, "failed")
            self.assertEqual(item.failure_reason, "问题中的“它”指代不明")
            self.assertIsNone(item.recall)
            self.assertIsNone(item.accuracy)
        self.assertEqual(self.run.status, "completed")

    async def test_empty_retrieval_scored_normally(self):
        async def empty_retrieval(**kwargs):
            result = success_answer(
                content="检索结果为空，未找到与问题相关的资料。",
                meta={"terminate_reason": "empty_retrieval", "references": []},
            )
            hook = kwargs.get("score_hook")
            if hook is not None:
                result.update(await hook(result))
            return result

        with patch.object(evaluation_runner, "run_evaluation_question", side_effect=empty_retrieval):
            await evaluation_runner._execute_run("run-1")
        for item in self.items:
            self.assertEqual(item.status, "success")
            self.assertEqual(item.recall, 0.2)
            self.assertEqual(item.accuracy, 60.0)

    async def test_item_timeout_fails_and_continues(self):
        captured_events = []

        async def slow_then_fast(**kwargs):
            captured_events.append(kwargs["cancel_event"])
            if len(captured_events) == 1:
                await asyncio.sleep(1)
            return await fake_question_success(**kwargs)

        with patch.object(evaluation_runner, "ITEM_TIMEOUT_SECONDS", 0.05):
            with patch.object(evaluation_runner, "run_evaluation_question", side_effect=slow_then_fast):
                await evaluation_runner._execute_run("run-1")
        self.assertEqual(self.items[0].status, "failed")
        self.assertEqual(self.items[0].failure_reason, "执行超时")
        self.assertTrue(captured_events[0].is_set())  # 超时先 set 该题 cancel_event（R7）
        self.assertEqual(self.items[1].status, "success")
        self.assertEqual(self.items[2].status, "success")
        self.assertEqual(self.run.status, "completed")
        self.assertEqual(self.run.completed_items, 3)

    async def test_partial_scoring_failure_keeps_successful_analysis(self):
        failed_recall = {"score": None, "analysis": None,
                         "raw_output": "坏的输出", "failure_reason": "召回率评分输出校验失败：x"}
        with patch.object(evaluation_runner, "run_evaluation_question", side_effect=fake_question_success):
            with patch.object(evaluation_runner, "score_recall", AsyncMock(return_value=failed_recall)):
                await evaluation_runner._execute_run("run-1")
        item = self.items[0]
        self.assertEqual(item.status, "failed")
        self.assertIn("召回率评分", item.failure_reason)
        self.assertIsNone(item.recall)
        self.assertIsNone(item.accuracy)
        self.assertEqual(item.recall_raw_output, "坏的输出")
        self.assertEqual(item.accuracy_analysis, {"ok": True})  # 成功单项分析保留（契约 §3）
        self.assertEqual(item.agent_answer, "agent 答案")


if __name__ == "__main__":
    unittest.main()