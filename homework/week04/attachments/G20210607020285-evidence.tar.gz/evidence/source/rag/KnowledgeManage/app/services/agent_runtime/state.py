"""请求级内存运行态（data-model.md §2）：请求结束/停止即丢弃，不落库.

- AgentConfigSnapshot: 开跑前一次性冻结的配置（FR-004，snapshot.py 构建）
- RequestRuntimeState: 问答请求运行态（chunks 去重累积 / plan / 白名单 / 取消信号）
- ContextChunk / Plan(PlanStep) / ToolCallRecord
"""
import asyncio
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class PromptSnapshot:
    """冻结的提示词内容（运行期不再读 prompts 表）."""
    prompt_id: str
    name: str
    version: str
    content: str


@dataclass
class ModelRef:
    """冻结的模型引用；name 为网关 display_name（COALESCE(display_name, name)）."""
    model_id: str
    name: str
    context_tokens: int


@dataclass
class RetrievalConfig:
    mode: str = "hybrid"            # bm25 | vector | hybrid（规划推理不使用 mode）
    vector_top_k: int = 20          # 1–100
    keyword_top_k: int = 20
    hybrid_top_k: int = 20
    rerank_top_n: int = 15          # 1–100


@dataclass
class AgentConfigSnapshot:
    """配置快照（FR-003/004）：全量预检通过后冻结，运行期不再读配置表."""
    agent_id: str
    agent_type: str                 # quick_qa | reasoning_action | planning_reasoning
    prompts: Dict[str, PromptSnapshot] = field(default_factory=dict)  # purpose → 内容
    analysis_model: Optional[ModelRef] = None
    embedding_model: Optional[ModelRef] = None
    rerank_model: Optional[ModelRef] = None
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    loop_count: int = 10            # 推理行动默认 10、规划推理默认 100，范围 1–1000
    tools: List[str] = field(default_factory=list)  # 启用工具键（仅 planning_reasoning）
    max_output_tokens: int = 5000
    kb_ids: List[str] = field(default_factory=list)
    history_top_k: int = 10         # 历史信息检索召回数（013 决策8，1–100）


@dataclass
class ContextChunk:
    """上下文片段；按 chunk_id 去重，保留首次出现顺序与 first_loop（FR-019）."""
    chunk_id: str
    document_id: str
    kb_id: str
    file_name: str = ""
    content: str = ""
    chunk_type: str = "text"
    sqlite_url: Optional[str] = None
    score: float = 0.0
    first_loop: int = 0             # 首次出现轮次（淘汰依据）
    handle: Optional[str] = None    # cN 句柄（答案生成前分配）


@dataclass
class PlanStep:
    step_id: str
    description: str
    status: str = "pending"         # pending | in_progress | done


@dataclass
class Plan:
    """计划（FR-024）：仅内存，单请求单 plan，请求结束/停止随 state 丢弃."""
    plan_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    steps: List[PlanStep] = field(default_factory=list)
    created_at: datetime = field(default_factory=_utcnow)
    updated_at: datetime = field(default_factory=_utcnow)


@dataclass
class ToolCallRecord:
    """工具调用记录（FR-029）：call_id 调用→执行→结果→trace 全程一致."""
    call_id: str
    tool_name: str
    args: Dict[str, Any] = field(default_factory=dict)
    result: Optional[Any] = None    # schemas.agent_runtime.ToolResult
    started_at: datetime = field(default_factory=_utcnow)
    duration_ms: float = 0.0


@dataclass
class RequestRuntimeState:
    """问答请求运行态；状态转移见 data-model.md §2.2."""
    generation_id: str
    chat_id: str
    user_id: str
    snapshot: AgentConfigSnapshot
    question: str                   # 原始问题
    trace_id: str = ""              # 根 span 创建后填充
    current_question: str = ""      # 当前轮重写问题
    loop: int = 0
    chunks: "OrderedDict[str, ContextChunk]" = field(default_factory=OrderedDict)
    handle_map: Dict[str, str] = field(default_factory=dict)  # cN → chunk_id
    plan: Optional[Plan] = None
    sqlite_whitelist: set = field(default_factory=set)
    history: List[Any] = field(default_factory=list)  # 截取后的会话历史（默认最近 10 轮）
    clarify_history: Optional[List[dict]] = None  # 澄清/重写专用组装历史；None=降级/未组装（013 FR-008/010）
    cancel_event: asyncio.Event = field(default_factory=asyncio.Event)
    messages_for_model: List[dict] = field(default_factory=list)  # 规划推理 OpenAI 消息累积
    events: List[dict] = field(default_factory=list)  # 降级/收敛等事件（同步写 span event）
    partial_answer: str = ""        # 已流式输出的部分答案（停止时落库）

    def merge_chunks(self, new_chunks: List[ContextChunk]) -> List[ContextChunk]:
        """检索命中并入累积：按 chunk_id 去重，保留首次顺序与 first_loop；返回新增片段."""
        added = []
        for chunk in new_chunks:
            if chunk.chunk_id not in self.chunks:
                chunk.first_loop = self.loop
                self.chunks[chunk.chunk_id] = chunk
                added.append(chunk)
            if chunk.sqlite_url:
                self.sqlite_whitelist.add(chunk.sqlite_url)
        return added