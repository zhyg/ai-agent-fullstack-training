"""login_demo 的会话测试（Python 驱动 node 直调 dist/ 纯逻辑模块）。

为什么这样做：本项目的质量门槛是 `npm run build` 的类型检查，没有测试框架；
token / password / database 三个模块是纯逻辑，可以在进程外用 node require dist/ 直调，
不需要监听端口，也不依赖 ts-node（环境中 ts-node 依赖损坏，见 docs/TESTING.md）。

运行命令（在 login_demo 目录下）：
    .venv/bin/python -m pytest tests/auth -v
"""

import json
import subprocess
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DIST = PROJECT_ROOT / "dist"


@pytest.fixture(scope="session")
def dist_ready() -> Path:
    """先跑一次 npm run build，保证 dist/ 与 src/ 一致；这也是本项目的类型检查门槛。"""
    build = subprocess.run(
        ["npm", "run", "build", "--silent"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    assert build.returncode == 0, f"npm run build 失败:\n{build.stdout}\n{build.stderr}"
    assert DIST.joinpath("utils/token.js").exists(), "dist/utils/token.js 缺失"
    return DIST


def run_node(script: str) -> dict:
    result = subprocess.run(
        ["node", "-e", script],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"node 探针失败:\n{result.stderr}"
    return json.loads(result.stdout)


def test_token_roundtrip(dist_ready):
    """登录签发的 token 能被中间件用的解析函数还原出同一载荷。"""
    out = run_node(
        "const {issueAccessToken, parseAccessToken} = require('./dist/utils/token');"
        "const token = issueAccessToken({userId:'u_1001', role:'member'});"
        "console.log(JSON.stringify({token, parsed: parseAccessToken(token)}));"
    )
    assert out["token"].startswith("demo-token.")
    assert out["parsed"] == {"userId": "u_1001", "role": "member"}


def test_parse_rejects_bad_tokens(dist_ready):
    out = run_node(
        "const {parseAccessToken} = require('./dist/utils/token');"
        "console.log(JSON.stringify({"
        "no_prefix: parseAccessToken('nonsense'),"
        "bad_body: parseAccessToken('demo-token.!!!not-base64!!!'),"
        "empty: parseAccessToken('demo-token.')"
        "}));"
    )
    assert out["no_prefix"] is None
    assert out["bad_body"] is None
    assert out["empty"] is None


def test_verify_password(dist_ready):
    out = run_node(
        "const {verifyPassword} = require('./dist/utils/password');"
        "(async () => {"
        "const ok = await verifyPassword('demo123', 'hash:demo123');"
        "const bad = await verifyPassword('wrong', 'hash:demo123');"
        "console.log(JSON.stringify({ok, bad}));"
        "})();"
    )
    assert out["ok"] is True
    assert out["bad"] is False


def test_users_table_lookup(dist_ready):
    """会话背后查的必须是 users 表。"""
    out = run_node(
        "const {queryOne} = require('./dist/db/database');"
        "(async () => {"
        "const hit = await queryOne('users', {email:'demo@example.com'});"
        "const miss = await queryOne('users', {email:'nobody@example.com'});"
        "console.log(JSON.stringify({hit, miss: miss ?? null}));"
        "})();"
    )
    assert out["hit"]["id"] == "u_1001"
    assert out["miss"] is None
