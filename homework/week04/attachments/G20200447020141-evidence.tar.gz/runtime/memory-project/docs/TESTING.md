# 测试说明（login_demo）

## 会话测试入口

| 项 | 值 |
|---|---|
| 测试文件 | `tests/auth/test_session.py` |
| 运行命令（项目根目录执行） | `.venv/bin/python -m pytest tests/auth -v` |
| 被测对象 | `dist/utils/token.js`、`dist/utils/password.js`、`dist/db/database.js` |
| 来源 | `src/utils/token.ts`、`src/utils/password.ts`、`src/db/database.ts`；环境限制记录见本文件下节 |

## 为什么用 Python + node 直调

- 本项目没有测试框架（无 jest/vitest/mocha，无 `test` script），唯一的自动化质量门槛是 `npm run build`（strict 类型检查）。
- 环境中 `ts-node` 依赖损坏（`Cannot find module './util'`），`npm run dev` 不可用；端口监听被拒时 HTTP 冒烟也无法进行。
- 因此会话测试绕过 HTTP 层与 ts-node，用 pytest 驱动 `node -e` 探针直调 `dist/` 下的纯逻辑模块；测试 fixture 会先执行 `npm run build` 保证 dist 与 src 一致。

## 覆盖点

1. `issueAccessToken` → `parseAccessToken` 往返（`demo-token.<base64url>`）。
2. `parseAccessToken` 对缺前缀 / 非法 body / 空 body 的三种拒绝。
3. `verifyPassword` 正确 / 错误两条分支。
4. `queryOne("users", ...)` 命中与未命中（确认会话背后查的是 users 表）。

## 环境准备

```
python3 -m venv .venv
.venv/bin/pip install pytest
npm install   # 依赖 node_modules（本仓库已提交 package-lock.json）
```
