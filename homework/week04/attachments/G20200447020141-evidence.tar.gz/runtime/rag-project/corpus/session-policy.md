# 登录会话策略

本文件说明 login_demo 的登录会话（access token）在业务上的有效期与失效行为，是排查「登录后多久需要重新登录」这类问题的依据。

## 1. 会话有效期

- 登录会话有效期为 **20 分钟**。
- 计时起点：`POST /api/login` 成功返回 `accessToken` 的时刻。
- 有效期覆盖从签发到过期之间的全部受保护接口调用，不区分接口类型。

## 2. 有效期内与过期后的行为

- 有效期内：`Authorization: Bearer <accessToken>` 可以访问 `GET /api/profile` 等受保护接口。
- 过期后：服务端拒绝该 token，受保护接口返回 `401 Invalid token`，客户端需要重新调用 `POST /api/login` 获取新 token。

## 3. 续期规则

- 本项目不提供 refresh token，也不做滑动续期。
- 每次重新登录都会签发新的 `accessToken`，有效期重新从签发时刻计算 20 分钟。

## 4. 与 token 结构的关系

- `accessToken` 形如 `demo-token.<base64url>`，载荷包含 `userId` 与 `role`。
- 载荷本身不携带过期时间字段，有效期由服务端会话策略统一约束，因此排查过期问题时以本文件为准。

## 5. 相关文件

- 登录调用链：`artifacts/login-flow.md`
- token 编解码：`src/utils/token.ts`
- 认证中间件：`src/middleware/auth-middleware.ts`
