# 需求二 · 建库结果
Embedding 模型：智谱 embedding-3（https://open.bigmodel.cn/api/paas/v4）
分块参数：Markdown 按标题切小节 → SentenceSplitter(chunk_size=260, chunk_overlap=40)
资料目录：corpus

## 索引概览
节点数量：23（login-flow.md=16，login-readme.md=1，session-policy.md=6）
向量索引已保存：storage/vector
节点清单已保存：storage/nodes.json（BM25 与更新核对共用）
检索器：向量（embedding-3）+ BM25（中文 bigram 分词）+ RRF 融合

## 一条带来源的分块样例
node=12908d0839339629
来源=login-flow.md › 1. 登录入口
文件=corpus/login-flow.md | chunk_no=1

## 1. 登录入口

- 服务启动入口：`src/server.ts`
  - `createApp()` 创建 Express 应用。
  - `app.listen(3001)` 启动 HTTP 服务。
- 路由挂载入口：`src/app.ts`
  - `app.use("/api", loginRouter)` 挂载登录路由。
  - 因此登录接口的完整路径是 `POST /api/login`。
- 实际登录处理函数：`src/routes/login.ts`
  - `loginRouter.post("/login", ...)` 是代码中的登录入口。

## 全部分块清单（来源 + 内容摘要）
- login-flow.md › 1. 登录入口 | chunk=1 | 287 字
  ## 1. 登录入口 - 服务启动入口：`src/server.ts` - `createApp()` 创建 Express 应用。 - `app.listen(3001)` 启动…
- login-flow.md › 2.1 路由层 | chunk=1 | 188 字
  ### 2.1 路由层 `src/routes/login.ts` - 从 `request.body` 中读取 `email` 和 `password`。 - 若任一字段缺失，直…
- login-flow.md › 2.2 Service 层 | chunk=1 | 293 字
  ### 2.2 Service 层 `src/services/auth-service.ts` - 调用 `userRepository.findByEmail(email)` …
- login-flow.md › 2.3 Repository 层 | chunk=1 | 147 字
  ### 2.3 Repository 层 `src/repositories/user-repository.ts` - `findByEmail(email)` 只负责“按邮箱查…
- login-flow.md › 2.4 数据库访问层 | chunk=1 | 252 字
  ### 2.4 数据库访问层 `src/db/database.ts` - 这里不是外部数据库，而是内存中的 `usersTable` 数组。 - `queryOne(table,…
- login-flow.md › 2.5 密码工具 | chunk=1 | 160 字
  ### 2.5 密码工具 `src/utils/password.ts` - `verifyPassword` 的逻辑非常直接： - 判断数据库中的 `passwordHash` …
- login-flow.md › 2.6 Token 工具 | chunk=1 | 234 字
  ### 2.6 Token 工具 `src/utils/token.ts` - `issueAccessToken(payload)` 会把 `{ userId, role }` …
- login-flow.md › 2.7 认证中间件 | chunk=1 | 280 字
  ### 2.7 认证中间件 `src/middleware/auth-middleware.ts` - 该中间件不参与“登录”本身，而是用于“登录后访问受保护接口”。 - 它从 `…
- login-flow.md › 2.8 受保护路由 | chunk=1 | 188 字
  ### 2.8 受保护路由 `src/routes/profile.ts` - `GET /api/profile` 使用了 `authMiddleware`。 - 只要 toke…
- login-flow.md › 3.1 登录成功链路 | chunk=1 | 529 字
  ### 3.1 登录成功链路 1. 客户端请求 `POST /api/login` 2. `src/server.ts` 启动的服务收到请求 3. `src/app.ts` 将 `…
- login-flow.md › 3.1 登录成功链路 | chunk=2 | 411 字
  `src/utils/password.ts` 校验密码是否匹配 11. 校验通过后，`src/services/auth-service.ts` 调用 `issueAccessT…
- login-flow.md › 情况 A：缺少参数 | chunk=1 | 101 字
  #### 情况 A：缺少参数 `src/routes/login.ts` 在路由层直接返回： - `400 { error: "email and password are req…
- login-flow.md › 情况 B：用户不存在 | chunk=1 | 137 字
  #### 情况 B：用户不存在 调用链进入 Service 后： - `userRepository.findByEmail(email)` 查不到用户 - `authServic…
- login-flow.md › 情况 C：密码错误 | chunk=1 | 124 字
  #### 情况 C：密码错误 调用链进入密码校验后： - `verifyPassword(...)` 返回 `false` - `authService.login` 抛出 `In…
- login-flow.md › 4. 登录后的鉴权调用链 | chunk=1 | 494 字
  ## 4. 登录后的鉴权调用链 登录接口返回的 `accessToken` 会被后续受保护接口使用，例如 `GET /api/profile`。 调用链如下： 1. 客户端把登录得…
- login-flow.md › 5. 结论 | chunk=1 | 331 字
  ## 5. 结论 这个 demo 的分层很清楚： - `server/app` 负责启动与挂载 - `route` 负责 HTTP 入参和响应 - `service` 负责登录业务…
- login-readme.md › 关键文件 | chunk=1 | 303 字
  ## 关键文件 - `src/routes/login.ts`: 登录入口，`POST /api/login` - `src/services/auth-service.ts`: …
- session-policy.md › 登录会话策略 | chunk=1 | 84 字
  # 登录会话策略 本文件说明 login_demo 的登录会话（access token）在业务上的有效期与失效行为，是排查「登录后多久需要重新登录」这类问题的依据。
- session-policy.md › 1. 会话有效期 | chunk=1 | 118 字
  ## 1. 会话有效期 - 登录会话有效期为 **30 分钟**。 - 计时起点：`POST /api/login` 成功返回 `accessToken` 的时刻。 - 有效期覆盖…
- session-policy.md › 2. 有效期内与过期后的行为 | chunk=1 | 181 字
  ## 2. 有效期内与过期后的行为 - 有效期内：`Authorization: Bearer <accessToken>` 可以访问 `GET /api/profile` 等受保…
- session-policy.md › 3. 续期规则 | chunk=1 | 92 字
  ## 3. 续期规则 - 本项目不提供 refresh token，也不做滑动续期。 - 每次重新登录都会签发新的 `accessToken`，有效期重新从签发时刻计算 30 分钟…
- session-policy.md › 4. 与 token 结构的关系 | chunk=1 | 137 字
  ## 4. 与 token 结构的关系 - `accessToken` 形如 `demo-token.<base64url>`，载荷包含 `userId` 与 `role`。 - …
- session-policy.md › 5. 相关文件 | chunk=1 | 122 字
  ## 5. 相关文件 - 登录调用链：`artifacts/login-flow.md` - token 编解码：`src/utils/token.ts` - 认证中间件：`src…
