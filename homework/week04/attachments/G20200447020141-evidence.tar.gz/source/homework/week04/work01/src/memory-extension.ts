/**
 * pi 的项目长期记忆扩展。
 *
 * 用法：pi --extension <本文件路径>
 * 动作：memory_write / memory_find / memory_read / memory_update / memory_delete，
 * 覆盖作业要求的写入、按项目查找并读取、更新、删除四个动作（read 是 find 的按 id 精读补充）。
 *
 * 记忆按项目隔离：以 pi 的 cwd 为项目根，落盘到 <项目根>/.project-memory/memory.json。
 * 不接向量库，查找用关键词 + 标签匹配。
 */
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import {
  memoryDelete,
  memoryFind,
  memoryRead,
  memoryUpdate,
  memoryWrite,
  memoryFilePath,
  resolveProjectRoot,
  type MemoryMutation,
} from "./memory-store.js";

const tagsParam = {
  type: "array" as const,
  items: { type: "string" as const },
  description: "标签，用于按项目归类检索，例如 [\"login_demo\", \"测试\"]",
};

function toResult(mutation: MemoryMutation) {
  const payload: Record<string, unknown> = {
    ok: mutation.ok,
    action: mutation.action,
    file: mutation.file,
    message: mutation.message,
  };
  if (mutation.id) payload.id = mutation.id;
  if (mutation.record) payload.record = mutation.record;
  if (mutation.records) payload.records = mutation.records;
  return {
    content: [{ type: "text" as const, text: JSON.stringify(payload, null, 2) }],
    details: payload,
    isError: !mutation.ok,
  };
}

export default function projectMemoryExtension(pi: ExtensionAPI): void {
  pi.registerFlag("memory-root", {
    description: "项目长期记忆的根目录（默认取 pi 的 cwd）",
    type: "string",
  });

  let projectRoot = process.cwd();

  pi.on("session_start", async (_event, ctx) => {
    const flagRoot = pi.getFlag("memory-root");
    projectRoot = resolveProjectRoot(flagRoot === undefined ? undefined : String(flagRoot));
    const file = memoryFilePath(projectRoot);
    const opened = await memoryFind(projectRoot, {});
    ctx.ui.notify(
      `[长期记忆] 项目=${projectRoot} · 库文件=${file} · 已存 ${opened.records?.length ?? 0} 条记忆；` +
        `写入/查读/更新/删除请用 memory_write / memory_find / memory_read / memory_update / memory_delete`,
      "info",
    );
  });

  pi.registerTool({
    name: "memory_write",
    label: "长期记忆·写入",
    description:
      "把一条事实写入当前项目的长期记忆（持久化 JSON）。适合保存测试入口、运行命令、关键结论等跨会话要复用的信息。返回记忆 id 与实际保存路径。",
    promptSnippet: "memory_write（写入长期记忆）",
    promptGuidelines: [
      "保存长期记忆时必须带 source（来源文件路径或执行记录），方便后续核对。",
      "同一条事实已有旧记忆时，优先用 memory_update 更新，不要重复写入新条目。",
    ],
    parameters: {
      type: "object",
      required: ["title", "content"],
      properties: {
        title: { type: "string", description: "一句话标题，例如「会话测试入口与运行命令」" },
        content: { type: "string", description: "记忆正文：路径、命令、结论等" },
        tags: tagsParam,
        source: { type: "string", description: "来源：得出这条记忆的文件或执行记录" },
      },
    },
    async execute(_toolCallId, params) {
      return toResult(
        memoryWrite(projectRoot, params as { title: string; content: string; tags?: string[]; source?: string }),
      );
    },
  });

  pi.registerTool({
    name: "memory_find",
    label: "长期记忆·查找",
    description: "在当前项目的长期记忆里按关键词和标签查找记忆条目，返回命中的 id、标题、正文与来源。",
    promptSnippet: "memory_find（查找长期记忆）",
    promptGuidelines: ["回答跨会话的问题前先查记忆；引用记忆时把 source 一起报出来。"],
    parameters: {
      type: "object",
      properties: {
        query: { type: "string", description: "关键词，多个词用空格分隔（都命中才算）" },
        tags: tagsParam,
        limit: { type: "number", description: "最多返回条数，默认 20" },
      },
    },
    async execute(_toolCallId, params) {
      return toResult(memoryFind(projectRoot, params as { query?: string; tags?: string[]; limit?: number }));
    },
  });

  pi.registerTool({
    name: "memory_read",
    label: "长期记忆·精读",
    description: "按 id 读取一条长期记忆的完整内容。",
    promptSnippet: "memory_read（按 id 精读记忆）",
    parameters: {
      type: "object",
      required: ["id"],
      properties: { id: { type: "string", description: "memory_write / memory_find 返回的记忆 id" } },
    },
    async execute(_toolCallId, params) {
      return toResult(memoryRead(projectRoot, (params as { id: string }).id));
    },
  });

  pi.registerTool({
    name: "memory_update",
    label: "长期记忆·更新",
    description:
      "更新一条已有长期记忆（按 id）。项目发生变化导致旧记录失效时用它，可整段替换或追加正文，updatedAt 会刷新。",
    promptSnippet: "memory_update（更新长期记忆）",
    promptGuidelines: ["更新后若来源也变了，同步更新 source 字段。"],
    parameters: {
      type: "object",
      required: ["id"],
      properties: {
        id: { type: "string", description: "要更新的记忆 id" },
        title: { type: "string", description: "新标题（可选）" },
        content: { type: "string", description: "新正文（可选）；配合 append=true 则是追加" },
        append: { type: "boolean", description: "true 时把 content 追加到原正文末尾" },
        tags: tagsParam,
        source: { type: "string", description: "新来源（可选）" },
      },
    },
    async execute(_toolCallId, params) {
      return toResult(memoryUpdate(projectRoot, params as { id: string } & Record<string, unknown>));
    },
  });

  pi.registerTool({
    name: "memory_delete",
    label: "长期记忆·删除",
    description: "按 id 删除一条长期记忆。只删确实过时或写错的记录，删除前建议先 memory_read 确认。",
    promptSnippet: "memory_delete（删除长期记忆）",
    parameters: {
      type: "object",
      required: ["id"],
      properties: { id: { type: "string", description: "要删除的记忆 id" } },
    },
    async execute(_toolCallId, params) {
      return toResult(memoryDelete(projectRoot, (params as { id: string }).id));
    },
  });
}
