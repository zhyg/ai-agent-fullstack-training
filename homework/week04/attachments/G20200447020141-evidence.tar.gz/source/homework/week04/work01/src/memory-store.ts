/**
 * 项目长期记忆的存储层。
 *
 * 设计约定：
 * - 每个项目的记忆互相隔离：存储文件放在「项目根目录」下的 .project-memory/memory.json，
 *   项目根目录 = 记忆打开时所在仓库的根（由调用方传入，pi 场景下取 pi 的 cwd）。
 * - 不接向量库：查找就是大小写不敏感的关键词/标签匹配，足够覆盖「按项目查找并读取」。
 * - 写入是原子操作（先写临时文件再 rename），崩溃也不会留下半截 JSON。
 */
import { mkdirSync, readFileSync, renameSync, writeFileSync, existsSync, rmSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { randomUUID } from "node:crypto";

export interface MemoryRecord {
  id: string;
  title: string;
  content: string;
  tags: string[];
  /** 记录来源：哪个文件/哪次执行得出了这条记忆，用于核对。 */
  source: string;
  createdAt: string;
  updatedAt: string;
}

export interface MemoryFile {
  version: 1;
  project: string;
  records: MemoryRecord[];
}

export type MemoryAction = "write" | "find" | "read" | "update" | "delete";

export interface MemoryMutation {
  ok: boolean;
  action: MemoryAction;
  id?: string;
  file: string;
  message: string;
  record?: MemoryRecord;
  records?: MemoryRecord[];
}

export function memoryDir(projectRoot: string): string {
  return join(resolve(projectRoot), ".project-memory");
}

export function memoryFilePath(projectRoot: string): string {
  return join(memoryDir(projectRoot), "memory.json");
}

export function loadMemory(projectRoot: string): MemoryFile {
  const file = memoryFilePath(projectRoot);
  if (!existsSync(file)) {
    return { version: 1, project: resolve(projectRoot), records: [] };
  }
  const parsed = JSON.parse(readFileSync(file, "utf8")) as MemoryFile;
  if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.records)) {
    throw new Error(`MEMORY_CORRUPT: ${file} 不是合法的记忆库文件`);
  }
  return parsed;
}

function saveMemory(projectRoot: string, data: MemoryFile): string {
  const dir = memoryDir(projectRoot);
  mkdirSync(dir, { recursive: true });
  const file = memoryFilePath(projectRoot);
  const tmp = join(dir, `.memory.${process.pid}.tmp`);
  writeFileSync(tmp, JSON.stringify(data, null, 2) + "\n", "utf8");
  renameSync(tmp, file);
  return file;
}

function normalizeTags(tags?: string[] | string): string[] {
  if (!tags) return [];
  const list = Array.isArray(tags) ? tags : [tags];
  return [...new Set(list.map((t) => String(t).trim()).filter(Boolean))];
}

function nowIso(): string {
  return new Date().toISOString();
}

export function memoryWrite(
  projectRoot: string,
  input: { title: string; content: string; tags?: string[] | string; source?: string },
): MemoryMutation {
  if (!input?.title?.trim() || !input?.content?.trim()) {
    return { ok: false, action: "write", file: memoryFilePath(projectRoot), message: "title 与 content 均为必填" };
  }
  const data = loadMemory(projectRoot);
  const stamp = nowIso();
  const record: MemoryRecord = {
    id: `mem_${randomUUID().slice(0, 8)}`,
    title: input.title.trim(),
    content: input.content.trim(),
    tags: normalizeTags(input.tags),
    source: (input.source ?? "").trim(),
    createdAt: stamp,
    updatedAt: stamp,
  };
  data.records.push(record);
  const file = saveMemory(projectRoot, data);
  return { ok: true, action: "write", id: record.id, file, message: `已写入记忆 ${record.id}`, record };
}

export function memoryFind(
  projectRoot: string,
  input: { query?: string; tags?: string[] | string; limit?: number },
): MemoryMutation {
  const data = loadMemory(projectRoot);
  const tagFilter = normalizeTags(input.tags).map((t) => t.toLowerCase());
  const query = (input.query ?? "").trim().toLowerCase();
  const hits = data.records.filter((record) => {
    const tagHit =
      tagFilter.length === 0 ||
      tagFilter.every((t) => record.tags.some((rt) => rt.toLowerCase().includes(t)));
    const text = `${record.title}\n${record.content}\n${record.source}\n${record.tags.join(",")}`.toLowerCase();
    const queryHit = query === "" || query.split(/\s+/).every((word) => text.includes(word));
    return tagHit && queryHit;
  });
  const limit = Math.max(1, Math.min(Number(input.limit) || 20, 100));
  return {
    ok: true,
    action: "find",
    file: memoryFilePath(projectRoot),
    message: `命中 ${hits.length} 条（共 ${data.records.length} 条）`,
    records: hits.slice(0, limit),
  };
}

export function memoryRead(projectRoot: string, id: string): MemoryMutation {
  const data = loadMemory(projectRoot);
  const record = data.records.find((r) => r.id === id);
  if (!record) {
    return { ok: false, action: "read", id, file: memoryFilePath(projectRoot), message: `未找到 id=${id} 的记忆` };
  }
  return { ok: true, action: "read", id, file: memoryFilePath(projectRoot), message: `已读取 ${id}`, record };
}

export function memoryUpdate(
  projectRoot: string,
  input: {
    id: string;
    title?: string;
    content?: string;
    /** append=true 时把 content 追加到原文末尾，而不是整段替换。 */
    append?: boolean;
    tags?: string[] | string;
    source?: string;
  },
): MemoryMutation {
  if (!input?.id?.trim()) {
    return { ok: false, action: "update", file: memoryFilePath(projectRoot), message: "id 为必填" };
  }
  const data = loadMemory(projectRoot);
  const record = data.records.find((r) => r.id === input.id);
  if (!record) {
    return { ok: false, action: "update", id: input.id, file: memoryFilePath(projectRoot), message: `未找到 id=${input.id} 的记忆，无法更新` };
  }
  if (typeof input.title === "string" && input.title.trim()) record.title = input.title.trim();
  if (typeof input.content === "string" && input.content.trim()) {
    record.content = input.append ? `${record.content}\n${input.content.trim()}` : input.content.trim();
  }
  if (input.tags !== undefined) record.tags = normalizeTags(input.tags);
  if (typeof input.source === "string" && input.source.trim()) record.source = input.source.trim();
  record.updatedAt = nowIso();
  const file = saveMemory(projectRoot, data);
  return { ok: true, action: "update", id: record.id, file, message: `已更新记忆 ${record.id}（updatedAt=${record.updatedAt}）`, record };
}

export function memoryDelete(projectRoot: string, id: string): MemoryMutation {
  if (!id?.trim()) {
    return { ok: false, action: "delete", file: memoryFilePath(projectRoot), message: "id 为必填" };
  }
  const data = loadMemory(projectRoot);
  const before = data.records.length;
  const record = data.records.find((r) => r.id === id);
  data.records = data.records.filter((r) => r.id !== id);
  if (data.records.length === before) {
    return { ok: false, action: "delete", id, file: memoryFilePath(projectRoot), message: `未找到 id=${id} 的记忆，无法删除` };
  }
  const file = saveMemory(projectRoot, data);
  // 库清空时顺带把空文件清掉，避免留下只有壳的目录。
  if (data.records.length === 0) {
    try {
      rmSync(file);
      rmSync(memoryDir(projectRoot), { recursive: true, force: true });
    } catch {
      // 清理失败不影响删除结果
    }
    return { ok: true, action: "delete", id, file, message: `已删除记忆 ${id}，记忆库已清空`, record };
  }
  return { ok: true, action: "delete", id, file, message: `已删除记忆 ${id}`, record };
}

/** 供 CLI / 测试使用：保证不把调用方工作目录之外的路径写花。 */
export function resolveProjectRoot(root?: string): string {
  return resolve(root ?? process.cwd());
}
