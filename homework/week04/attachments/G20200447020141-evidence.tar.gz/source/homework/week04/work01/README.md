# week04 work01：为 pi 增加项目长期记忆

对应作业：`homework/week04/work01.md`。演示项目沿用 `demo-view/week04/4-3/login_demo`。

## 实现内容

- `src/memory-store.ts`：长期记忆存储层。每个项目一个库，落盘到
  `<项目根>/.project-memory/memory.json`（先写临时文件再 rename，原子写入）。
  查找为大小写不敏感的关键词 + 标签匹配，不接向量数据库。
- `src/memory-extension.ts`：pi 扩展，注册五个工具，覆盖作业要求的四个动作：

  | 动作 | 工具 |
  |---|---|
  | 写入 | `memory_write` |
  | 按项目查找并读取 | `memory_find`（关键词/标签检索）+ `memory_read`（按 id 精读） |
  | 更新 | `memory_update`（可整段替换或追加，刷新 updatedAt） |
  | 删除 | `memory_delete` |

- `src/cli.ts`：不依赖 pi 会话的手动验证入口，与扩展共用同一存储层。

## 安装与构建

```
cd homework/week04/work01
npm install
npm run build        # 产物在 dist/，pi 加载扩展直接用 TS 源文件，build 仅做类型检查
```

## 演示项目准备（login_demo）

login_demo 原本没有任何测试（见其 `docs/TESTING.md` 的取证记录），为让作业的
"读取会话测试文件 → 存入记忆 → 迁移测试 → 更新记忆" 走得通，已补齐初始状态：

- `tests/session/test_session.py`：pytest 驱动 node 直调 `dist/` 纯逻辑模块（不监听端口、不依赖 ts-node）。
- `docs/TESTING.md`：测试说明（入口、运行命令、来源、覆盖点）。

```
cd demo-view/week04/4-3/login_demo
npm install
python3 -m venv .venv && .venv/bin/pip install pytest
.venv/bin/python -m pytest tests/session -v   # 4 passed
```

## 三个验证步骤（截图对应）

统一在 login_demo 目录下启动 pi：

```
cd demo-view/week04/4-3/login_demo
pi --extension /Users/huangke/Desktop/workspace/agent-training/homework/week04/work01/src/memory-extension.ts
```

### 步骤 1 · 写入（截图一：建库结果）

对 pi 说：

> 读取当前项目的会话测试文件和测试说明（tests/ 目录与 docs/TESTING.md），把测试路径和运行命令保存到项目长期记忆，附上来源。告诉我实际保存路径。

预期：pi 调用 `memory_write`，返回记忆 id 与实际保存路径
`<login_demo>/.project-memory/memory.json`。截图应包含工具调用参数与返回的 `file` 字段。

### 步骤 2 · 全新会话读取核对（截图二：查询对比与回答）

退出 pi，重新执行上面的 `pi --extension ...` 启动全新会话（会话横幅会显示已存记忆条数），对 pi 说：

> 从当前项目长期记忆中查找会话测试入口，核对测试文件是否真的存在，并回答：测试路径、运行命令、来源各是什么？

预期：pi 调用 `memory_find`（命中上一步写入的记录，含 source），再核对文件存在后回答。

### 步骤 3 · 项目变化后更新旧记录（截图三：更新后的回答）

对 pi 说：

> 把会话测试迁移到 tests/auth/test_session.py，同步修改 docs/TESTING.md，运行新测试命令，并根据实际结果更新原来的长期记忆。

预期：pi 迁移测试文件、更新说明、运行 `.venv/bin/python -m pytest tests/auth/test_session.py -v`，
然后调用 `memory_update` 把测试路径与运行命令改为 `tests/auth/test_session.py`（updatedAt 刷新，
source 改为迁移后的文件），最后回答新入口。截图应包含迁移 diff、新测试通过输出与 `memory_update` 结果。

## 不依赖 pi 的四动作快验（可选）

```
M=/Users/huangke/Desktop/workspace/agent-training/homework/week04/work01
cd demo-view/week04/4-3/login_demo
node $M/dist/cli.js . write --title "会话测试入口" --content "tests/session/test_session.py" --source "docs/TESTING.md" --tags "login_demo,测试"
node $M/dist/cli.js . find --query "会话测试"
node $M/dist/cli.js . update --id <上一步返回的id> --content "tests/auth/test_session.py"
node $M/dist/cli.js . delete --id <上一步返回的id>
```

## 提交物

- 可运行代码：本目录（扩展 + 存储层 + CLI）、login_demo 的 `tests/` 与 `docs/TESTING.md`。
- 三张截图：按上面步骤 1/2/3 分别截取（pi 会话界面，含工具调用与最终回答）。
