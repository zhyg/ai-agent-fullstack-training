/**
 * 长期记忆的手动验证入口（不依赖 pi 会话，直接驱动同一个存储层）。
 *
 * 用法：
 *   node dist/cli.js <projectRoot> write   --title "..." --content "..." --source "..." --tags a,b
 *   node dist/cli.js <projectRoot> find    [--query "关键词"] [--tags a,b]
 *   node dist/cli.js <projectRoot> read    --id mem_xxxxxxxx
 *   node dist/cli.js <projectRoot> update  --id mem_xxxxxxxx [--content "..."] [--append] [--source "..."]
 *   node dist/cli.js <projectRoot> delete  --id mem_xxxxxxxx
 */
import { memoryDelete, memoryFind, memoryRead, memoryUpdate, memoryWrite, resolveProjectRoot } from "./memory-store.js";

interface ParsedArgs {
  action: string;
  root: string;
  flags: Record<string, string | boolean>;
}

function parseArgs(argv: string[]): ParsedArgs {
  const [root = process.cwd(), action = "find", ...rest] = argv;
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < rest.length; i += 1) {
    const item = rest[i];
    if (!item.startsWith("--")) continue;
    const key = item.slice(2);
    if (i + 1 < rest.length && !rest[i + 1].startsWith("--") && key !== "append") {
      flags[key] = rest[i + 1];
      i += 1;
    } else {
      flags[key] = true;
    }
  }
  return { action, root, flags };
}

function parseTags(raw: string | boolean | undefined): string[] | undefined {
  if (typeof raw !== "string") return undefined;
  const tags = raw.split(",").map((t) => t.trim()).filter(Boolean);
  return tags.length ? tags : undefined;
}

function main(): void {
  const { action, root, flags } = parseArgs(process.argv.slice(2));
  const projectRoot = resolveProjectRoot(root);
  const tags = parseTags(flags.tags);

  let mutation;
  switch (action) {
    case "write":
      mutation = memoryWrite(projectRoot, {
        title: String(flags.title ?? ""),
        content: String(flags.content ?? ""),
        source: flags.source === undefined ? undefined : String(flags.source),
        tags,
      });
      break;
    case "find":
      mutation = memoryFind(projectRoot, {
        query: flags.query === undefined ? undefined : String(flags.query),
        tags,
        limit: flags.limit === undefined ? undefined : Number(flags.limit),
      });
      break;
    case "read":
      mutation = memoryRead(projectRoot, String(flags.id ?? ""));
      break;
    case "update":
      mutation = memoryUpdate(projectRoot, {
        id: String(flags.id ?? ""),
        title: flags.title === undefined ? undefined : String(flags.title),
        content: flags.content === undefined ? undefined : String(flags.content),
        append: flags.append === true,
        source: flags.source === undefined ? undefined : String(flags.source),
        tags,
      });
      break;
    case "delete":
      mutation = memoryDelete(projectRoot, String(flags.id ?? ""));
      break;
    default:
      throw new Error(`未知动作: ${action}（支持 write/find/read/update/delete）`);
  }
  console.log(JSON.stringify(mutation, null, 2));
  if (!mutation.ok) process.exitCode = 1;
}

main();
