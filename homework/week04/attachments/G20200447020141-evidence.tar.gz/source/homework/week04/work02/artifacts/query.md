# 需求二 · 三路查询对比与回答
生成模型：智谱 glm-4-plus
索引节点数：23
问题：登录会话的有效期是多少分钟？

### 向量检索 Top5 结果
1. 分数=0.5875 | 来源=session-policy.md › 1. 会话有效期 | node=5dd52621f4ad8086
   ## 1. 会话有效期 - 登录会话有效期为 **30 分钟**。 - 计时起点：`POST /api/login` 成功返回 `accessToken` 的时刻。 - 有效期覆盖从签发到过期之间的全部受保护接口调用，不区分接口类型。
2. 分数=0.4831 | 来源=session-policy.md › 登录会话策略 | node=6a3a65cb5e873514
   # 登录会话策略 本文件说明 login_demo 的登录会话（access token）在业务上的有效期与失效行为，是排查「登录后多久需要重新登录」这类问题的依据。
3. 分数=0.4786 | 来源=session-policy.md › 2. 有效期内与过期后的行为 | node=5cd43c38fde2709a
   ## 2. 有效期内与过期后的行为 - 有效期内：`Authorization: Bearer <accessToken>` 可以访问 `GET /api/profile` 等受保护接口。 - 过期后：服务端拒绝该 token，受保护接口返回 `401 Invalid token`，客户端需要重新调用 `POST /a…
4. 分数=0.4671 | 来源=session-policy.md › 3. 续期规则 | node=0a36b981fe423f81
   ## 3. 续期规则 - 本项目不提供 refresh token，也不做滑动续期。 - 每次重新登录都会签发新的 `accessToken`，有效期重新从签发时刻计算 30 分钟。
5. 分数=0.4222 | 来源=session-policy.md › 4. 与 token 结构的关系 | node=c9c2e959292fc54e
   ## 4. 与 token 结构的关系 - `accessToken` 形如 `demo-token.<base64url>`，载荷包含 `userId` 与 `role`。 - 载荷本身不携带过期时间字段，有效期由服务端会话策略统一约束，因此排查过期问题时以本文件为准。

### BM25 检索 Top5 结果
1. 分数=12.1891 | 来源=session-policy.md › 登录会话策略 | node=6a3a65cb5e873514
   # 登录会话策略 本文件说明 login_demo 的登录会话（access token）在业务上的有效期与失效行为，是排查「登录后多久需要重新登录」这类问题的依据。
2. 分数=11.4483 | 来源=session-policy.md › 1. 会话有效期 | node=5dd52621f4ad8086
   ## 1. 会话有效期 - 登录会话有效期为 **30 分钟**。 - 计时起点：`POST /api/login` 成功返回 `accessToken` 的时刻。 - 有效期覆盖从签发到过期之间的全部受保护接口调用，不区分接口类型。
3. 分数=5.5410 | 来源=session-policy.md › 3. 续期规则 | node=0a36b981fe423f81
   ## 3. 续期规则 - 本项目不提供 refresh token，也不做滑动续期。 - 每次重新登录都会签发新的 `accessToken`，有效期重新从签发时刻计算 30 分钟。
4. 分数=4.2190 | 来源=session-policy.md › 4. 与 token 结构的关系 | node=c9c2e959292fc54e
   ## 4. 与 token 结构的关系 - `accessToken` 形如 `demo-token.<base64url>`，载荷包含 `userId` 与 `role`。 - 载荷本身不携带过期时间字段，有效期由服务端会话策略统一约束，因此排查过期问题时以本文件为准。
5. 分数=3.4617 | 来源=session-policy.md › 2. 有效期内与过期后的行为 | node=5cd43c38fde2709a
   ## 2. 有效期内与过期后的行为 - 有效期内：`Authorization: Bearer <accessToken>` 可以访问 `GET /api/profile` 等受保护接口。 - 过期后：服务端拒绝该 token，受保护接口返回 `401 Invalid token`，客户端需要重新调用 `POST /a…

### RRF 混合检索 Top5 结果
1. 分数=0.0331 | 来源=session-policy.md › 1. 会话有效期 | node=5dd52621f4ad8086
   ## 1. 会话有效期 - 登录会话有效期为 **30 分钟**。 - 计时起点：`POST /api/login` 成功返回 `accessToken` 的时刻。 - 有效期覆盖从签发到过期之间的全部受保护接口调用，不区分接口类型。
2. 分数=0.0331 | 来源=session-policy.md › 登录会话策略 | node=6a3a65cb5e873514
   # 登录会话策略 本文件说明 login_demo 的登录会话（access token）在业务上的有效期与失效行为，是排查「登录后多久需要重新登录」这类问题的依据。
3. 分数=0.0320 | 来源=session-policy.md › 3. 续期规则 | node=0a36b981fe423f81
   ## 3. 续期规则 - 本项目不提供 refresh token，也不做滑动续期。 - 每次重新登录都会签发新的 `accessToken`，有效期重新从签发时刻计算 30 分钟。
4. 分数=0.0318 | 来源=session-policy.md › 2. 有效期内与过期后的行为 | node=5cd43c38fde2709a
   ## 2. 有效期内与过期后的行为 - 有效期内：`Authorization: Bearer <accessToken>` 可以访问 `GET /api/profile` 等受保护接口。 - 过期后：服务端拒绝该 token，受保护接口返回 `401 Invalid token`，客户端需要重新调用 `POST /a…
5. 分数=0.0315 | 来源=session-policy.md › 4. 与 token 结构的关系 | node=c9c2e959292fc54e
   ## 4. 与 token 结构的关系 - `accessToken` 形如 `demo-token.<base64url>`，载荷包含 `userId` 与 `role`。 - 载荷本身不携带过期时间字段，有效期由服务端会话策略统一约束，因此排查过期问题时以本文件为准。

## 混合检索证据 → 模型回答
### 引用来源
[1] session-policy.md › 1. 会话有效期 | 文件=corpus/session-policy.md | chunk=1
[2] session-policy.md › 登录会话策略 | 文件=corpus/session-policy.md | chunk=1
[3] session-policy.md › 3. 续期规则 | 文件=corpus/session-policy.md | chunk=1
[4] session-policy.md › 2. 有效期内与过期后的行为 | 文件=corpus/session-policy.md | chunk=1
[5] session-policy.md › 4. 与 token 结构的关系 | 文件=corpus/session-policy.md | chunk=1

登录会话的有效期是 30 分钟 [1]。  
依据：证据 [1] 明确说明登录会话有效期为 30 分钟，计时起点为成功返回 `accessToken` 的时刻 [1]。
