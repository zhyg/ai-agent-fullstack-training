"""建库与加载：同一批节点上建立向量索引和 BM25 索引，并把索引落盘。

落盘内容：
- storage/vector/  ：LlamaIndex 向量索引（含 embedding 向量与节点文本）
- storage/nodes.json：同一批节点（BM25 与「旧分块是否退出」的核对都以它为准）
"""

from __future__ import annotations

import shutil

from llama_index.core import StorageContext, VectorStoreIndex, load_index_from_storage
from llama_index.core.schema import TextNode

from . import config


def build_index(nodes: list[TextNode]) -> VectorStoreIndex:
    if config.VECTOR_DIR.exists():
        shutil.rmtree(config.VECTOR_DIR)
    index = VectorStoreIndex(nodes, embed_model=config.embed_model(), show_progress=False)
    index.storage_context.persist(persist_dir=str(config.VECTOR_DIR))
    return index


def load_index() -> VectorStoreIndex:
    if not config.VECTOR_DIR.exists():
        raise SystemExit(f"找不到向量索引 {config.VECTOR_DIR}，请先运行 build")
    storage_context = StorageContext.from_defaults(persist_dir=str(config.VECTOR_DIR))
    return load_index_from_storage(storage_context, embed_model=config.embed_model())
