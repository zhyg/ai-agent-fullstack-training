"""BM25 关键词检索，跑在与向量索引相同的那批 LlamaIndex 节点上。

中文没有空格，直接用默认分词会把整句当成一个词，因此这里自己分词：
英文/数字按词切，中文按二元组（bigram）切。
"""

from __future__ import annotations

import re
from typing import List

from llama_index.core.bridge.pydantic import PrivateAttr
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import BaseNode, NodeWithScore, QueryBundle
from rank_bm25 import BM25Okapi

_ASCII_WORD = re.compile(r"[a-z0-9_]+")
_CJK_RUN = re.compile(r"[\u4e00-\u9fff]+")


def tokenize(text: str) -> list[str]:
    lowered = text.lower()
    tokens = _ASCII_WORD.findall(lowered)
    for run in _CJK_RUN.findall(lowered):
        if len(run) == 1:
            tokens.append(run)
        else:
            tokens.extend(run[i : i + 2] for i in range(len(run) - 1))
    return tokens


class ChineseBM25Retriever(BaseRetriever):
    """基于 rank_bm25 的检索器，可直接和其他 LlamaIndex retriever 一起融合。"""

    _nodes: List[BaseNode] = PrivateAttr()
    _bm25: BM25Okapi = PrivateAttr()
    _top_k: int = PrivateAttr()

    def __init__(self, nodes: List[BaseNode], similarity_top_k: int = 5) -> None:
        super().__init__()
        self._nodes = nodes
        self._bm25 = BM25Okapi([tokenize(node.get_content()) for node in nodes])
        self._top_k = similarity_top_k

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        scores = self._bm25.get_scores(tokenize(query_bundle.query_str))
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
        return [
            NodeWithScore(node=self._nodes[i], score=float(scores[i]))
            for i in ranked[: self._top_k]
            if scores[i] > 0
        ]

    @property
    def avg_doc_len(self) -> float:
        return float(self._bm25.avgdl)
