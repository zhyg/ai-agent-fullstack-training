"""三路检索（向量 / BM25 / RRF 混合）与带来源引用的回答。"""

from __future__ import annotations

from typing import Iterable, List

from llama_index.core.retrievers import QueryFusionRetriever
from llama_index.core.schema import NodeWithScore
from llama_index.core.retrievers import BaseRetriever

from . import config
from .bm25 import ChineseBM25Retriever
from .corpus import preview

ANSWER_PROMPT = """你是登录服务的资料助手。只能依据下面给出的证据回答，不要使用证据之外的知识。

问题：{question}

证据：
{evidence}

要求：
1. 用中文回答，先给结论，再给一句依据说明。
2. 每个结论后面必须带上证据编号，格式如 [1]、[2]。
3. 如果证据不足以回答，直接说“资料中没有相关信息”，不要猜测。
"""


def build_retrievers(index, nodes) -> dict[str, BaseRetriever]:
    vector = index.as_retriever(similarity_top_k=config.TOP_K)
    bm25 = ChineseBM25Retriever(nodes=nodes, similarity_top_k=config.TOP_K)
    hybrid = QueryFusionRetriever(
        [vector, bm25],
        similarity_top_k=config.TOP_K,
        num_queries=1,
        mode="reciprocal_rerank",
        use_async=False,
        retriever_weights=[0.5, 0.5],
        # num_queries=1 时不会真的改写查询，但 QueryFusionRetriever 仍要求可用的 llm。
        llm=config.llm(),
        verbose=False,
    )
    return {"向量检索": vector, "BM25 检索": bm25, "RRF 混合检索": hybrid}


def format_hits(title: str, hits: Iterable[NodeWithScore]) -> str:
    lines = [f"### {title} Top5 结果"]
    any_hit = False
    for rank, hit in enumerate(hits, start=1):
        any_hit = True
        meta = hit.node.metadata
        score = "n/a" if hit.score is None else f"{hit.score:.4f}"
        lines.append(
            f"{rank}. 分数={score} | 来源={meta.get('source')} | node={hit.node.node_id}\n"
            f"   {preview(hit.node.get_content())}"
        )
    if not any_hit:
        lines.append("(无命中)")
    return "\n".join(lines)


def format_evidence(hits: List[NodeWithScore]) -> str:
    blocks = []
    for i, hit in enumerate(hits, start=1):
        meta = hit.node.metadata
        blocks.append(f"[{i}] 来源：{meta.get('source')}\n{hit.node.get_content()}")
    return "\n\n".join(blocks)


def format_citations(hits: List[NodeWithScore]) -> str:
    lines = ["### 引用来源"]
    for i, hit in enumerate(hits, start=1):
        meta = hit.node.metadata
        lines.append(
            f"[{i}] {meta.get('source')} | 文件={meta.get('file_path')} | chunk={meta.get('chunk_no')}"
        )
    return "\n".join(lines)


def answer(question: str, hits: List[NodeWithScore]) -> str:
    if not hits:
        return "资料中没有相关信息。"
    prompt = ANSWER_PROMPT.format(question=question, evidence=format_evidence(hits))
    response = config.llm().complete(prompt)
    return str(response).strip()
