"""路径与模型配置。

Embedding 与生成模型都走智谱 AI 的 OpenAI 兼容接口：
- Embedding: embedding-3
- 生成模型: glm-4-plus
API key 从环境变量读取（ZAI_API_KEY / ZHIPU_API_KEY / ZHIPUAI_API_KEY 任一）。
"""

from __future__ import annotations

import os
from pathlib import Path

from llama_index.embeddings.openai_like import OpenAILikeEmbedding
from llama_index.llms.openai_like import OpenAILike

ROOT = Path(__file__).resolve().parents[1]
CORPUS_DIR = ROOT / "corpus"
STORAGE_DIR = ROOT / "storage"
VECTOR_DIR = STORAGE_DIR / "vector"
NODES_PATH = STORAGE_DIR / "nodes.json"
ARTIFACTS_DIR = ROOT / "artifacts"

# 资料副本的原始出处（login_demo 项目），reset 时从这里重新复制，保证可以反复演示。
PROJECT_DIR = ROOT.parent / "login_demo"
CORPUS_SOURCES = {
    "login-readme.md": PROJECT_DIR / "README.md",
    "login-flow.md": PROJECT_DIR / "artifacts" / "login-flow.md",
    "session-policy.md": PROJECT_DIR / "docs" / "session-policy.md",
}

ZHIPU_BASE_URL = "https://open.bigmodel.cn/api/paas/v4"
EMBED_MODEL = "embedding-3"
LLM_MODEL = "glm-4-plus"

# 分块参数：Markdown 先按标题切小节，再按句子切到约 260 token，留 40 token 重叠。
CHUNK_SIZE = 260
CHUNK_OVERLAP = 40

TOP_K = 5


def zhipu_api_key() -> str:
    for name in ("ZAI_API_KEY", "ZHIPU_API_KEY", "ZHIPUAI_API_KEY"):
        value = os.getenv(name)
        if value:
            return value
    raise SystemExit("缺少智谱 API key：请设置环境变量 ZAI_API_KEY（或 ZHIPU_API_KEY）")


def embed_model() -> OpenAILikeEmbedding:
    # 智谱的 embedding-3 不在 OpenAI 官方模型枚举里，用 OpenAILike 走同一套兼容协议。
    return OpenAILikeEmbedding(
        model_name=EMBED_MODEL,
        api_base=ZHIPU_BASE_URL,
        api_key=zhipu_api_key(),
        embed_batch_size=16,
        timeout=120,
        max_retries=3,
    )


def llm() -> OpenAILike:
    return OpenAILike(
        model=LLM_MODEL,
        api_base=ZHIPU_BASE_URL,
        api_key=zhipu_api_key(),
        is_chat_model=True,
        context_window=8192,
        max_tokens=1024,
        temperature=0.1,
        timeout=180,
    )
