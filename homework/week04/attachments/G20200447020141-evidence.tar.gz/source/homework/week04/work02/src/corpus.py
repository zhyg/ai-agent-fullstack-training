"""读取登录资料副本并分块。

分块策略：先用 MarkdownNodeParser 按标题切小节（保留标题路径），再用 SentenceSplitter
在小节内切到固定长度。每个 chunk 都带上 file/section/chunk_no 元数据，回答时能回溯来源。
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from llama_index.core import Document
from llama_index.core.node_parser import MarkdownNodeParser, SentenceSplitter
from llama_index.core.schema import TextNode

from . import config

_HEADING_LINE = re.compile(r"(?m)^#+\s*.*$")

# 纯标题、没有正文的小节对检索没有价值，直接丢掉。
MIN_BODY_CHARS = 35


def _heading_of(text: str) -> str | None:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped.lstrip("#").strip()
    return None


def _section_label(metadata: dict, text: str) -> str:
    """节点正文以标题开头时用该标题；否则回退到 MarkdownNodeParser 的 header_path。"""
    heading = _heading_of(text)
    if heading:
        return heading
    parts = [part for part in str(metadata.get("header_path", "")).split("/") if part]
    return parts[-1] if parts else "(正文)"


def _stable_id(file_name: str, section: str, text: str) -> str:
    digest = hashlib.sha1(f"{file_name}|{section}|{text}".encode("utf-8")).hexdigest()
    return digest[:16]


def load_documents() -> list[Document]:
    docs: list[Document] = []
    for path in sorted(config.CORPUS_DIR.glob("*.md")):
        docs.append(
            Document(
                text=path.read_text(encoding="utf-8"),
                metadata={
                    "file_name": path.name,
                    "file_path": str(path.relative_to(config.ROOT)),
                },
            )
        )
    if not docs:
        raise SystemExit(f"corpus 目录为空：{config.CORPUS_DIR}")
    return docs


def build_nodes() -> list[TextNode]:
    md_parser = MarkdownNodeParser()
    splitter = SentenceSplitter(chunk_size=config.CHUNK_SIZE, chunk_overlap=config.CHUNK_OVERLAP)
    nodes: list[TextNode] = []

    for doc in load_documents():
        file_name = doc.metadata["file_name"]
        for section_node in md_parser.get_nodes_from_documents([doc]):
            section = _section_label(section_node.metadata, section_node.get_content())
            for chunk_no, chunk in enumerate(splitter.get_nodes_from_documents([section_node]), start=1):
                text = chunk.get_content().strip()
                body = _HEADING_LINE.sub("", text).strip()
                if len(body) < MIN_BODY_CHARS:
                    continue
                nodes.append(
                    TextNode(
                        id_=_stable_id(file_name, section, text),
                        text=text,
                        metadata={
                            "file_name": file_name,
                            "file_path": doc.metadata["file_path"],
                            "section": section,
                            "chunk_no": chunk_no,
                            "source": f"{file_name} › {section}",
                        },
                    )
                )
    return nodes


def save_nodes(nodes: list[TextNode], path: Path = config.NODES_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = [
        {"id": node.node_id, "text": node.get_content(), "metadata": node.metadata} for node in nodes
    ]
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_nodes(path: Path = config.NODES_PATH) -> list[TextNode]:
    if not path.exists():
        raise SystemExit(f"找不到节点文件 {path}，请先运行 build")
    payload = json.loads(path.read_text(encoding="utf-8"))
    return [
        TextNode(id_=item["id"], text=item["text"], metadata=item["metadata"]) for item in payload
    ]


def preview(text: str, limit: int = 160) -> str:
    compact = " ".join(text.split())
    return compact if len(compact) <= limit else compact[:limit] + "…"
