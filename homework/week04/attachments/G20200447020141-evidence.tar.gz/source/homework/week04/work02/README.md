# week04 work02：LlamaIndex 向量 + 关键词混合检索 RAG

对应作业 `homework/week04/work01.md` 需求二。资料取自 `homework/week04/login_demo` 的登录资料副本。

## 设计

| 环节 | 实现 |
|---|---|
| 资料 | `corpus/`：`login-readme.md`、`login-flow.md`、`session-policy.md`（均为 login_demo 资料的副本） |
| 分块 | `MarkdownNodeParser` 按标题切小节 → `SentenceSplitter(chunk_size=260, chunk_overlap=40)`；每个节点带 `file_name / file_path / section / chunk_no / source` |
| 向量索引 | 智谱 `embedding-3`（OpenAI 兼容接口 `https://open.bigmodel.cn/api/paas/v4`），`VectorStoreIndex` 持久化到 `storage/vector/` |
| 关键词索引 | `rank_bm25.BM25Okapi`，跑在**同一批节点**上；中文用 bigram 分词（`src/bm25.py`），并封装成 LlamaIndex `BaseRetriever` |
| 混合检索 | `QueryFusionRetriever(mode="reciprocal_rerank")`，对向量与 BM25 两路做 RRF 融合 |
| 生成 | 智谱 `glm-4-plus`，只依据混合检索证据作答，要求用 `[n]` 标注引用 |

> 说明：原始 `login_demo` 的文档没有记录会话有效期，而为完成「有效期是多少分钟」的检索，需要一条可核对的依据，因此在资料副本中补充了 `session-policy.md`（内容取自项目源码与登录流程，有效期 30 分钟）。`src/cli.py reset` 会从 `homework/week04/login_demo` 重新复制全部资料，保证可以反复演示。

## 运行

```bash
cd homework/week04/work02
pip install -r requirements.txt
export ZAI_API_KEY=<智谱 API key>        # 也支持 ZHIPU_API_KEY / ZHIPUAI_API_KEY

python -m src.cli build                  # ① 建库：分块 + 两路索引 + 落盘，输出节点数与分块样例
python -m src.cli query                  # ② 三路检索 Top5 对比 + 混合证据生成带引用回答
python -m src.cli update --old 30 --new 20   # ③ 改资料有效期 → 重建两路索引 → 重新查询
```

`reset` 可把资料副本恢复成 30 分钟版本（重复演示前执行）：

```bash
python -m src.cli reset && python -m src.cli build
```

运行输出同时写入 `artifacts/`：

- `artifacts/build.md`：建库结果（节点数、保存路径、一条带来源的分块样例、全部分块清单）
- `artifacts/query.md`：三路检索各 Top5 + 引用来源 + 模型回答
- `artifacts/update.md`：资料 diff、旧分块退出核对、更新后三路检索与回答

## 文件

```
work02/
├── corpus/           # 登录资料副本（RAG 的唯一数据源）
├── src/
│   ├── config.py     # 路径、智谱 embedding-3 / glm-4-plus 客户端
│   ├── corpus.py     # 读取资料、分块、节点持久化
│   ├── bm25.py       # 中文分词 + BM25 检索器
│   ├── indexer.py    # 向量索引构建/加载
│   ├── query.py      # 三路检索、证据拼装、带引用回答
│   └── cli.py        # reset / build / query / update
├── storage/          # 向量索引与节点清单（生成物，已 gitignore）
└── artifacts/        # 三次运行的记录（截图对应文本）
```
