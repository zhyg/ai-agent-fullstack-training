"""命令行入口：build / query / update。

用法（在 homework/week04/work02 下）：
    python -m src.cli build
    python -m src.cli query --question "登录会话的有效期是多少分钟？"
    python -m src.cli update --old 30 --new 20
每次运行都会把终端输出同时写到 artifacts/ 下对应文件，便于截图与复核。
"""

from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path
from typing import List

from llama_index.core.schema import NodeWithScore, TextNode

from . import config
from .corpus import build_nodes, load_nodes, preview, save_nodes
from .indexer import build_index, load_index
from .query import answer, build_retrievers, format_citations, format_hits

DEFAULT_QUESTION = "登录会话的有效期是多少分钟？"


class Tee:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._file = path.open("w", encoding="utf-8")

    def write(self, text: str = "") -> None:
        print(text)
        self._file.write(text + "\n")

    def rule(self, title: str) -> None:
        self.write("")
        self.write(f"## {title}")

    def close(self) -> None:
        self._file.close()


def _mentions_minutes(text: str, minutes: str) -> bool:
    """精确判断「N 分钟」，避免 30 误中 3001、20 误中 200。"""
    return f"{minutes} 分钟" in text or f"{minutes}分钟" in text


def _node_counts(nodes: List[TextNode]) -> str:
    counts = Counter(node.metadata["file_name"] for node in nodes)
    return "，".join(f"{name}={count}" for name, count in sorted(counts.items()))


def _print_three_retrievers(out: Tee, retrievers: dict, question: str) -> List[NodeWithScore]:
    out.write(f"问题：{question}")
    hybrid_hits: List[NodeWithScore] = []
    for label, retriever in retrievers.items():
        hits = retriever.retrieve(question)
        out.write("")
        out.write(format_hits(label, hits))
        if label == "RRF 混合检索":
            hybrid_hits = hits
    return hybrid_hits


def cmd_reset(args: argparse.Namespace) -> None:
    """把 corpus 恢复成 login_demo 里的原始资料，便于反复演示 update。"""
    config.CORPUS_DIR.mkdir(parents=True, exist_ok=True)
    for name, source in config.CORPUS_SOURCES.items():
        if not source.exists():
            raise SystemExit(f"找不到原始资料 {source}")
        (config.CORPUS_DIR / name).write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"已恢复 corpus/{name} ← {source.relative_to(config.ROOT.parent)}")


def cmd_build(args: argparse.Namespace) -> None:
    out = Tee(config.ARTIFACTS_DIR / "build.md")
    out.write("# 需求二 · 建库结果")
    out.write(f"Embedding 模型：智谱 {config.EMBED_MODEL}（{config.ZHIPU_BASE_URL}）")
    out.write(
        f"分块参数：Markdown 按标题切小节 → SentenceSplitter(chunk_size={config.CHUNK_SIZE}, "
        f"chunk_overlap={config.CHUNK_OVERLAP})"
    )
    out.write(f"资料目录：{config.CORPUS_DIR.relative_to(config.ROOT)}")

    nodes = build_nodes()
    index = build_index(nodes)
    save_nodes(nodes)

    out.rule("索引概览")
    out.write(f"节点数量：{len(nodes)}（{_node_counts(nodes)}）")
    out.write(f"向量索引已保存：{config.VECTOR_DIR.relative_to(config.ROOT)}")
    out.write(f"节点清单已保存：{config.NODES_PATH.relative_to(config.ROOT)}（BM25 与更新核对共用）")
    out.write(f"检索器：向量（{config.EMBED_MODEL}）+ BM25（中文 bigram 分词）+ RRF 融合")

    sample = nodes[0]
    out.rule("一条带来源的分块样例")
    out.write(f"node={sample.node_id}")
    out.write(f"来源={sample.metadata['source']}")
    out.write(f"文件={sample.metadata['file_path']} | chunk_no={sample.metadata['chunk_no']}")
    out.write("")
    out.write(sample.get_content())

    out.rule("全部分块清单（来源 + 内容摘要）")
    for node in nodes:
        out.write(
            f"- {node.metadata['source']} | chunk={node.metadata['chunk_no']} | "
            f"{len(node.get_content())} 字\n  {preview(node.get_content(), 90)}"
        )

    del index  # 建库阶段只关心落盘结果
    out.close()


def cmd_query(args: argparse.Namespace) -> None:
    question = args.question or DEFAULT_QUESTION
    out = Tee(config.ARTIFACTS_DIR / "query.md")
    out.write("# 需求二 · 三路查询对比与回答")
    out.write(f"生成模型：智谱 {config.LLM_MODEL}")

    index = load_index()
    nodes = load_nodes()
    retrievers = build_retrievers(index, nodes)
    out.write(f"索引节点数：{len(nodes)}")

    hybrid_hits = _print_three_retrievers(out, retrievers, question)

    out.rule("混合检索证据 → 模型回答")
    out.write(format_citations(hybrid_hits))
    out.write("")
    out.write(answer(question, hybrid_hits))
    out.close()


def cmd_update(args: argparse.Namespace) -> None:
    old_term, new_term = str(args.old), str(args.new)
    question = args.question or DEFAULT_QUESTION
    out = Tee(config.ARTIFACTS_DIR / "update.md")
    out.write("# 需求二 · 更新验证")
    out.write(f"资料副本：corpus/session-policy.md 中的有效期 {old_term} 分钟 → {new_term} 分钟")

    target = config.CORPUS_DIR / "session-policy.md"
    original = target.read_text(encoding="utf-8")
    updated = original.replace(f"{old_term} 分钟", f"{new_term} 分钟").replace(
        f"{old_term}分钟", f"{new_term}分钟"
    )
    if updated == original:
        raise SystemExit(f"未在 {target} 中找到「{old_term} 分钟」，无法更新")
    target.write_text(updated, encoding="utf-8")

    changed = [
        (before, after)
        for before, after in zip(original.splitlines(), updated.splitlines())
        if before != after
    ]
    out.rule("资料变更")
    for before, after in changed:
        out.write(f"- 旧：{before.strip()}")
        out.write(f"- 新：{after.strip()}")

    old_nodes = load_nodes() if config.NODES_PATH.exists() else []
    old_expiry_ids = {
        node.node_id for node in old_nodes if _mentions_minutes(node.get_content(), old_term)
    }

    nodes = build_nodes()
    build_index(nodes)
    save_nodes(nodes)

    new_ids = {node.node_id for node in nodes}
    leaked = [node for node in nodes if _mentions_minutes(node.get_content(), old_term)]
    retired = old_expiry_ids - new_ids
    new_hits = [node.metadata["source"] for node in nodes if _mentions_minutes(node.get_content(), new_term)]

    out.rule("两路索引更新结果")
    out.write(f"节点数量：更新前 {len(old_nodes)} → 更新后 {len(nodes)}")
    out.write(f"含「{old_term} 分钟」的旧分块：{len(old_expiry_ids)} 个，已退出 {len(retired)} 个")
    out.write(f"旧分块 id：{sorted(old_expiry_ids)}")
    out.write(f"重建后仍含「{old_term} 分钟」的节点：{len(leaked)} 个（应为 0）")
    out.write(f"命中新有效期「{new_term} 分钟」的分块：{new_hits}")

    index = load_index()
    retrievers = build_retrievers(index, nodes)
    out.rule("更新后重新查询")
    hybrid_hits = _print_three_retrievers(out, retrievers, question)

    out.rule("更新后的回答")
    out.write(format_citations(hybrid_hits))
    out.write("")
    out.write(answer(question, hybrid_hits))
    out.close()


def main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="work02-rag", description="LlamaIndex 向量 + BM25 混合检索")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("reset", help="把 corpus 资料副本恢复成 login_demo 中的原始版本")
    sub.add_parser("build", help="读取 corpus、分块、建立并保存两路索引")

    query_parser = sub.add_parser("query", help="三路检索对比并用混合证据生成回答")
    query_parser.add_argument("--question", default=DEFAULT_QUESTION)

    update_parser = sub.add_parser("update", help="修改资料有效期并重建两路索引、重新查询")
    update_parser.add_argument("--old", default="30")
    update_parser.add_argument("--new", default="20")
    update_parser.add_argument("--question", default=DEFAULT_QUESTION)

    args = parser.parse_args(argv)
    {"reset": cmd_reset, "build": cmd_build, "query": cmd_query, "update": cmd_update}[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
