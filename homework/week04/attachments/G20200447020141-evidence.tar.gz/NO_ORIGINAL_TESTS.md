第四周题目无附带原始测试。source/homework/week04/login_demo/tests/auth/test_session.py 是学员自带测试，不是课程可信原测；4 collected / 4 passed, exit 0。教师副本迁移前后各复跑同一组4项，不改变断言。
