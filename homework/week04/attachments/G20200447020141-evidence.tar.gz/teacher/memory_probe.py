import json
import os
import shutil
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent
STUDENT = BASE / 'student/homework/week04'
PROJECT = BASE / 'memory-project'
CLI = STUDENT / 'work01/dist/cli.js'
PYTHON = BASE / 'venv/bin/python'
shutil.copytree(STUDENT / 'login_demo', PROJECT, ignore=shutil.ignore_patterns('node_modules', '.pytest_cache', '__pycache__'), dirs_exist_ok=True)
(PROJECT / 'node_modules').symlink_to(STUDENT / 'login_demo/node_modules', target_is_directory=True)
(PROJECT / 'tests/session').mkdir(parents=True, exist_ok=True)
shutil.move(PROJECT / 'tests/auth/test_session.py', PROJECT / 'tests/session/test_session.py')
docs = PROJECT / 'docs/TESTING.md'
docs.write_text(docs.read_text().replace('tests/auth', 'tests/session'))
print('PREPARE: copied final submission to initial tests/session location; no assertions changed', flush=True)

def run(args, cwd=PROJECT, expected=0):
    args = [str(a) for a in args]
    print('COMMAND', json.dumps(args, ensure_ascii=False), 'CWD', str(cwd), flush=True)
    p = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    print(p.stdout, p.stderr, 'EXIT', p.returncode, flush=True)
    assert p.returncode == expected
    return p.stdout

def cli(action, *flags, root=PROJECT, expected=0):
    return json.loads(run(['node', CLI, root, action, *flags], expected=expected))

test_path = 'tests/session/test_session.py'
command = f'{PYTHON} -m pytest tests/session -v'
source = 'docs/TESTING.md; tests/session/test_session.py; teacher initial pytest command'
initial_test = run([PYTHON, '-m', 'pytest', 'tests/session', '-v'])
w = cli('write', '--title', '会话测试入口', '--content', f'{test_path}\n{command}', '--source', source)
mid = w['id']
stored = json.loads(Path(w['file']).read_text())
assert stored['records'][0]['id'] == mid
assert source == stored['records'][0]['source']
print('M1 PASS persistent path', w['file'], flush=True)
f = cli('find', '--query', '会话测试入口')
r = cli('read', '--id', mid)
assert f['records'][0]['id'] == mid and r['record']['content'] == w['record']['content']
print('M2 PASS new node process per invocation; no conversation history', flush=True)
other = BASE / 'other-project'
other.mkdir(exist_ok=True)
assert cli('find', '--query', '会话测试入口', root=other)['records'] == []
cli('read', '--id', mid, root=other, expected=1)
print('M3 PASS isolated second project', flush=True)
exists = (PROJECT / test_path).exists()
assert exists
print('M4 CHECK', test_path, 'exists=', exists, 'read source=', r['record']['source'], flush=True)
(PROJECT / 'tests/auth').mkdir(exist_ok=True)
shutil.move(PROJECT / test_path, PROJECT / 'tests/auth/test_session.py')
docs.write_text(docs.read_text().replace('tests/session', 'tests/auth'))
new_run = run([PYTHON, '-m', 'pytest', 'tests/auth/test_session.py', '-v'])
assert '4 passed' in new_run
u = cli('update', '--id', mid, '--content', f'tests/auth/test_session.py\n{PYTHON} -m pytest tests/auth/test_session.py -v', '--source', 'docs/TESTING.md; tests/auth/test_session.py; teacher pytest: 4 passed, exit 0')
after = cli('read', '--id', mid)
records = json.loads(Path(u['file']).read_text())['records']
assert len(records) == 1 and records[0]['id'] == mid
assert 'tests/session' not in after['record']['content']
assert 'tests/auth' in docs.read_text() and not (PROJECT / test_path).exists()
print('M5 PASS same id, source updated, actual new test run, no stale current path', flush=True)
cli('delete', '--id', mid)
assert cli('find', '--query', '会话测试入口')['records'] == []
cli('read', '--id', mid, expected=1)
print('M6 PASS new process find empty and read exit 1; deleted record not returned', flush=True)
print('MEMORY SUMMARY 6/6 verification scenarios complete', flush=True)
