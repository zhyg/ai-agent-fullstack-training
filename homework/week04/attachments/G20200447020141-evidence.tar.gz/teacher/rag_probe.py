import argparse
import hashlib
import importlib.metadata
import inspect
import json
import os
import re
import shutil
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
WORK = BASE / 'student/homework/week04/work02'
ROOT = BASE / 'rag-project'
sys.path.insert(0, str(WORK))
from src import config

mode = sys.argv[1]
print('COMMAND rag_probe.py', mode, flush=True)
print('IMPORT config', config.__file__, flush=True)
if mode == 'original':
    for key in ('ZAI_API_KEY', 'ZHIPU_API_KEY', 'ZHIPUAI_API_KEY'):
        os.environ.pop(key, None)
    config.ARTIFACTS_DIR = BASE / 'original-attempt-artifacts'
    from src import cli
    cli.main(['build'])
    raise SystemExit()

ROOT.mkdir(exist_ok=True)
config.ROOT = ROOT
config.CORPUS_DIR = ROOT / 'corpus'
config.STORAGE_DIR = ROOT / 'storage'
config.VECTOR_DIR = config.STORAGE_DIR / 'vector'
config.NODES_PATH = config.STORAGE_DIR / 'nodes.json'
config.ARTIFACTS_DIR = ROOT / 'artifacts'
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.llms.openai_like import OpenAILike
embedding = HuggingFaceEmbedding(model_name='BAAI/bge-small-zh-v1.5', device='cpu', cache_folder=str(BASE / 'model-cache'))
config.embed_model = lambda: embedding
config.llm = lambda: OpenAILike(model='deepseek-chat', api_base='https://api.deepseek.com/v1', api_key=os.environ['DEEPSEEK_API_KEY'], is_chat_model=True, context_window=64000, max_tokens=700, temperature=0, timeout=120, max_retries=0)
print('TEACHER CONFIG ONLY: real BAAI/bge-small-zh-v1.5 CPU 512D; DeepSeek official deepseek-chat; student business modules unchanged', flush=True)
from src import cli, corpus, indexer, query
from llama_index.core.retrievers import QueryFusionRetriever
for mod in (cli, corpus, indexer, query):
    print('IMPORT', mod.__name__, mod.__file__, flush=True)

def persisted_check(label):
    nodes = corpus.load_nodes()
    vectors = json.loads((config.VECTOR_DIR / 'default__vector_store.json').read_text())['embedding_dict']
    ids = {n.node_id for n in nodes}
    assert ids == set(vectors)
    dims = {len(v) for v in vectors.values()}
    assert dims == {512}
    assert all(any(v) for v in vectors.values())
    index = indexer.load_index()
    retrievers = query.build_retrievers(index, nodes)
    # Compare the public results and actual implementation's per-rank scores independently.
    q = cli.DEFAULT_QUESTION
    hits = {label: ret.retrieve(q) for label, ret in retrievers.items()}
    for name, values in hits.items():
        print(label, name, 'COUNT', len(values), flush=True)
        assert len(values) >= 3
        print(query.format_hits(name, values), flush=True)
    expected = {}
    for name in ('向量检索', 'BM25 检索'):
        for rank, hit in enumerate(hits[name]):
            key = hit.node.hash
            expected[key] = expected.get(key, 0) + 1 / (60 + rank)
    for h in hits['RRF 混合检索']:
        assert abs(h.score - expected[h.node.hash]) < 1e-10
    print(label, 'RRF independent reciprocal rank check PASS; k=60 zero-based rank; no score addition', flush=True)
    print(label, 'R2 ids identical', len(ids), 'dimensions', dims, 'BM25 restored from persisted nodes in new process', flush=True)
    (ROOT / f'{label}-hits.json').write_text(json.dumps({name: [{'id': h.node.node_id, 'score': h.score, 'text': h.node.get_content(), 'source': h.node.metadata['source']} for h in hs] for name, hs in hits.items()}, ensure_ascii=False, indent=2))
    return nodes, hits

if mode == 'build':
    cli.main(['reset'])
    cli.main(['build'])
    print('R1 PASS build persisted; originals remain 30 minutes', flush=True)
elif mode == 'query':
    nodes, hits = persisted_check('before')
    cli.main(['query'])
    print('R3/R4 query command complete; answer citation verification requires report inspection', flush=True)
elif mode == 'update':
    old = corpus.load_nodes()
    old_current = {n.node_id for n in old if re.search(r'30\s*分钟', n.get_content())}
    originals = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in config.CORPUS_SOURCES.values()}
    cli.main(['update', '--old', '30', '--new', '20'])
    nodes, hits = persisted_check('after')
    new_ids = {n.node_id for n in nodes}
    assert not (old_current & new_ids)
    assert not [n for n in nodes if re.search(r'30\s*分钟', n.get_content())]
    for label, hs in hits.items():
        assert not [h for h in hs if re.search(r'30\s*分钟', h.node.get_content())]
    assert originals == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in config.CORPUS_SOURCES.values()}
    # Full current corpus scan, not merely the top-k question's results.
    current30 = [(str(p), i, line) for p in config.CORPUS_DIR.glob('*.md') for i, line in enumerate(p.read_text().splitlines(), 1) if re.search(r'30\s*分钟', line)]
    assert current30 == []
    print('R5 PASS all indexed current 30-minute facts removed, old ids retired', sorted(old_current), 'originals unchanged', flush=True)
    (ROOT / 'original-hashes.json').write_text(json.dumps(originals, indent=2))
elif mode == 'verify-new':
    nodes, hits = persisted_check('after-restart')
    assert all('30 分钟' not in n.get_content() for n in nodes)
    print('R5 NEW PROCESS PASS: persisted two-route update retained', flush=True)
else:
    raise ValueError(mode)
print('EXIT 0', flush=True)
