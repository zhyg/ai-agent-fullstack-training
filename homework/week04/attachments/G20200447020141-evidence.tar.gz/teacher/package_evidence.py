import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tarfile
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[3]
OUT = REPO / '.amp/in/week-grading'
NAME = 'G20200447020141-19442'
STAGE = BASE / 'evidence-stage'
STAGE.mkdir(exist_ok=True)
score = sum(map(Decimal, ['24', '20', '18', '20', '16', '1.5'])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
assert str(score) == '99.50'
feedback = (OUT / f'{NAME}-feedback.md').read_text()
evaluation = (OUT / f'{NAME}-evaluation.md').read_text()
assert '99.50' in feedback and '99.50' in evaluation
for section, number in [('优点', 2), ('不足', 3), ('改进方案', 4)]:
    body = feedback.split(f'**{number}. ')[1].split('**', 1)[1].split('\n**', 1)[0].strip()
    assert len(body) <= 500, (section, len(body))
    assert not any(word in body for word in ('扣分', '评分子项', '评分标准'))
    print('FEEDBACK SECTION', section, 'characters', len(body))
for kind in ('feedback', 'evaluation'):
    shutil.copy2(OUT / f'{NAME}-{kind}.md', STAGE / f'{NAME}-{kind}.md')
score_info = {'student': 'Kevin', 'student_id': 'G20200447020141', 'submission_id': 19442, 'score_items': ['24', '20', '18', '20', '16', '1.5'], 'total': str(score), 'rounding': 'ROUND_HALF_UP', 'grade': '优秀', 'conclusion': '通过，需修复', 'pending_points': '0.00', 'deductions': [{'item': '提交记录/第一题', 'points': '0.50', 'reason': 'image-1 write mem_4c436d0c differs from image-2/3 mem_90dacbbf'}]}
(STAGE / 'score.json').write_text(json.dumps(score_info, ensure_ascii=False, indent=2) + '\n')
paths = ['homework/week04/login_demo', 'homework/week04/work01', 'homework/week04/work02', 'homework/week04/work01.md']
commit = '7ae1e19c1663f984219a379dc2c12d43d45af795'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=BASE / 'student', text=True).strip() == commit
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=BASE / 'student', text=True) == ''
raw = subprocess.check_output(['git', 'archive', '--format=tar', '--prefix=source/', commit, *paths], cwd=BASE / 'student')
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    t.extractall(STAGE, filter='data')
for directory in ('teacher', 'standard', 'logs', 'runtime'):
    (STAGE / directory).mkdir(exist_ok=True)
for name in ('memory_probe.py', 'rag_probe.py', 'answer_audit.py', 'package_evidence.py'):
    shutil.copy2(BASE / name, STAGE / 'teacher' / name)
shutil.copytree(BASE / 'logs', STAGE / 'logs', dirs_exist_ok=True)
for path in ('hw-guide/week04/第四周作业评分标准.md', 'hw-guide/week04/AI Agent 全栈工程师训练营-作业四.md', 'hw-guide/学员作业反馈报告模板与要求.md'):
    shutil.copy2(REPO / path, STAGE / 'standard' / Path(path).name)
shutil.copytree(BASE / 'rag-project', STAGE / 'runtime/rag-project', dirs_exist_ok=True)
shutil.copytree(BASE / 'memory-project', STAGE / 'runtime/memory-project', ignore=shutil.ignore_patterns('node_modules', '__pycache__', '.pytest_cache', '.venv'), dirs_exist_ok=True)
(STAGE / 'NO_ORIGINAL_TESTS.md').write_text('第四周题目无附带原始测试。source/homework/week04/login_demo/tests/auth/test_session.py 是学员自带测试，不是课程可信原测；4 collected / 4 passed, exit 0。教师副本迁移前后各复跑同一组4项，不改变断言。\n')
model = BASE / 'model-cache/models--BAAI--bge-small-zh-v1.5/snapshots'
snapshots = [p.name for p in model.iterdir()] if model.exists() else []
provenance = {'course_repository': 'zhyg/ai-agent-fullstack-training', 'course_local_branch': 'feat/guide', 'course_commit': 'f0385588d59b84c2053da7f3ba0168866e493bf7', 'student_repository': 'https://gitee.com/huangke0802/agent-training.git', 'student_branch_at_clone': 'master', 'student_commit': commit, 'student_worktree_clean': True, 'model': 'BAAI/bge-small-zh-v1.5', 'model_snapshots': snapshots, 'dimension': 512, 'llm_request': 'deepseek-chat', 'llm_audit_response_model': 'deepseek-flash', 'official_endpoint': 'https://api.deepseek.com/v1/chat/completions', 'runtime_configuration_only': True}
(STAGE / 'provenance.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
(STAGE / 'CHECKLIST.md').write_text('''# 交付校验清单

- 学号 G20200447020141；平台记录19442；固定学员提交7ae1e19c1663f984219a379dc2c12d43d45af795。
- 总分99.50，优秀，验收结论：通过，需修复；待定0.00。
- 六项24/20/18/20/16/1.50，唯一扣分为第一题记录ID断链0.50，功能不重复扣分。
- 包内feedback/evaluation与外部逐字一致，由打包程序断言验证。
- M1–M6、R1–R5、S1证据见报告与日志；学员4项测试通过；本周无课程原测。
- 原智谱接口受凭据阻断，不算代码缺陷；外部模型工厂配置使用真实BGE512D和DeepSeek官方接口，源代码未改。
- 当前所有被索引30分钟事实均退出，新进程重载双索引一致；原件哈希不变。
- 无密钥、.env、venv、node_modules、site-packages、模型权重、依赖目录或符号链接。
- SHA256SUMS校验包内全部文件（自身除外）；重新解包后使用sha256sum -c SHA256SUMS。
''')
files = sorted(p for p in STAGE.rglob('*') if p.is_file() and p.name != 'SHA256SUMS')
secret = os.environ.get('DEEPSEEK_API_KEY', '').encode()
for p in files:
    assert not p.is_symlink()
    assert not set(p.relative_to(STAGE).parts) & {'.venv', 'venv', 'node_modules', 'site-packages', '__pycache__', '.env', 'model-cache'}
    assert not p.name.startswith('.env')
    if secret:
        assert secret not in p.read_bytes(), 'Secret value found; refusing package'
checks = ''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(STAGE)}\n' for p in files)
(STAGE / 'SHA256SUMS').write_text(checks)
tarpath = OUT / f'{NAME}-evidence.tar.gz'
with tarfile.open(tarpath, 'w:gz') as t:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file():
            t.add(p, arcname=str(p.relative_to(STAGE)), recursive=False)
with tarfile.open(tarpath) as t:
    for kind in ('feedback', 'evaluation'):
        filename = f'{NAME}-{kind}.md'
        assert t.extractfile(filename).read() == (OUT / filename).read_bytes()
    for line in checks.splitlines():
        digest, filename = line.split('  ', 1)
        assert hashlib.sha256(t.extractfile(filename).read()).hexdigest() == digest
print('SCORE 99.50 / 优秀 / 通过，需修复 / pending 0.00')
print('PASS source unchanged; report identity; score sum; feedback lengths; secret/exclusion scan; archive all checksums')
print('ARCHIVE_FILES', len(files) + 1, 'ARCHIVE_BYTES', tarpath.stat().st_size)
for p in OUT.glob(f'{NAME}-*'):
    print(p, hashlib.sha256(p.read_bytes()).hexdigest())
