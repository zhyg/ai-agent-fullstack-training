import json
import os
import re
import runpy
import sys
from pathlib import Path

import httpx
from llama_index.llms.openai_like import OpenAILike

BASE = Path(__file__).resolve().parent
sys.argv = ['rag_probe.py', 'verify-new']
scope = runpy.run_path(str(BASE / 'rag_probe.py'))
config, corpus, indexer, query = [scope[k] for k in ('config', 'corpus', 'indexer', 'query')]
responses = []

def on_response(response):
    response.read()
    assert response.request.url.host == 'api.deepseek.com'
    data = response.json()
    audit = {'url': str(response.request.url), 'status': response.status_code, 'id': data.get('id'), 'model': data.get('model'), 'usage': data.get('usage')}
    responses.append(audit)
    print('OFFICIAL_API_RESPONSE', json.dumps(audit, ensure_ascii=False), flush=True)

client = httpx.Client(event_hooks={'response': [on_response]})
config.llm = lambda: OpenAILike(model='deepseek-chat', api_base='https://api.deepseek.com/v1', api_key=os.environ['DEEPSEEK_API_KEY'], is_chat_model=True, context_window=64000, max_tokens=700, temperature=0, timeout=120, max_retries=0, http_client=client)
nodes = corpus.load_nodes()
retrievers = query.build_retrievers(indexer.load_index(), nodes)
question = '登录会话的有效期是多少分钟？'
hits = retrievers['RRF 混合检索'].retrieve(question)
print('EXACT_CURRENT_EVIDENCE\n' + query.format_evidence(hits), flush=True)
answer = query.answer(question, hits)
print('ANSWER\n' + answer, flush=True)
refs = [int(x) for x in re.findall(r'\[(\d+)\]', answer)]
assert refs and all(1 <= x <= len(hits) for x in refs)
assert '20' in answer and any('20 分钟' in hits[x - 1].node.get_content() for x in refs)
assert len(responses) == 1 and responses[0]['status'] == 200
assert responses[0]['usage']['total_tokens'] > 0
(BASE / 'rag-project/official-api-audit.json').write_text(json.dumps({'responses': responses, 'answer': answer, 'references': refs, 'sources': [h.node.metadata for h in hits]}, ensure_ascii=False, indent=2))
print('R4/R5 OFFICIAL API AND CURRENT CITATION AUDIT PASS; EXIT 0', flush=True)
