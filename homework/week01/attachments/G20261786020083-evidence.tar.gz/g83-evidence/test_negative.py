"""Run an unchanged student assertion against deliberately invalid upstream output."""
import importlib.util
import httpx
import pytest
from llm_gateway_api.mock_upstream import fixture

spec = importlib.util.spec_from_file_location('student_features', '/tmp/G20261786020083-gateway/tests/acceptance/test_features.py')
student = importlib.util.module_from_spec(spec)
spec.loader.exec_module(student)

@pytest.mark.asyncio
async def test_student_detects_failure(client, upstream):
    async def invalid(req, payload):
        body = fixture('openai_chat', payload)
        body['choices'][0]['message']['content'] = 'not-json'
        return httpx.Response(200, json=body)
    upstream.override = invalid
    await student.test_response_format_returns_valid_json(client, 'glm')
