# G20261786020083 evidence runbook

Repository: https://github.com/TomYang1024/gateway, main, 3bee822e769be4ff7ef7003407753659affa89fd.
Run directory: /tmp/G20261786020083-gateway. Evidence directory: /tmp/g83-evidence.
Assessment timestamp: 2026-11-08 Asia/Singapore; logs UTC 2026-11-07.

Commands actually executed:

1. `uv sync --frozen --all-packages` (success); `uv run --frozen python scripts/dev_setup.py` (success).
2. `docker compose up -d --build` (Compose unavailable); `make verify` (exit125). No environment score penalty.
3. Installed PostgreSQL15/Redis7 with apt; initdb private /tmp/g83-pg; supervised services g83-postgres port55432 and g83-redis port56379. Local-only disposable databases; no remote state changes.
4. `uv run --frozen python scripts/test_setup.py`; `uv run --frozen pytest tests/unit tests/adapter_contract -q` (96 passed).
5. `uv run --frozen pytest tests/acceptance tests/integration -q --junitxml=/tmp/g83-evidence/student.xml` (66 passed; same submitted feature suite as make verify, local dependency alternative).
6. Copy student tests/conftest.py unchanged into evidence directory. `uv run --frozen pytest /tmp/g83-evidence/test_teacher.py -q -s --asyncio-mode=auto --junitxml=/tmp/g83-evidence/teacher-final.xml` (28 observation assertions before later snapshot additions). Includes real 60.2s sleep for rate window recovery.
7. `uv run --frozen pytest /tmp/g83-evidence/test_teacher.py -q -s -k snapshots --asyncio-mode=auto --junitxml=/tmp/g83-evidence/token.xml` (3 passed). Initial teacher Messages fixture accidentally sent10 while expecting19; corrected transmitted mock data, retained original failed log, no student code defect or deduction.
8. `uv run --frozen pytest /tmp/g83-evidence/test_negative.py -q --asyncio-mode=auto` (expected exit1, one failed student JSON assertion after upstream corruption). This is a sensitivity test, not a student failure on normal data.
9. `uv run --frozen python /tmp/g83-evidence/live.py` (6 paid requests, only official DeepSeek key from environment). `LIVE_ALIASES=glm LIVE_CASES=json LIVE_OUTPUT=live-json-recheck.json uv run --frozen python /tmp/g83-evidence/live.py` (one bounded follow-up). No more paid requests required for reproduction without separate authorization. All success/failed bodies kept honestly. First Chat JSON and follow-up correctly rejected; no successful Chat real JSON claim.
10. Fresh g83_migration_test: original alembic upgrade head exit0. http_server.py starts unchanged create_app on18080, original mock_upstream on18081. Three README curl POSTs HTTP200, ready200. HTTP config bootstrap differs only base/DB/Redis/ports from Compose, Fernet ephemeral and excluded.
11. Student git diff exit0. Stop all four assessment supervised services. Scan full actual API key values in report and archive; never output values.

Do not interpret observation-test pass count as rubric pass count: backoff_cap and stream-limit observations assert the defect is reproducible. Deduct exactly1 point in retry and1 in model limiting.

The copied conftest masks GLM/DeepSeek/Kimi env credentials only inside offline test fixtures with test-only-secret; live.py runs in a separate process and reads the original DeepSeek environment. Captured wire excludes authentication headers. No actual provider credential is saved. All pricing in development snapshots is explicitly mock and must not be cited as a real bill.
