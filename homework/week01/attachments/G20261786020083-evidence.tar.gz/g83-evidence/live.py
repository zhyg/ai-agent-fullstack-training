"""Teacher real calls: only official DeepSeek; credentials read from environment, never persisted."""
import asyncio
import json
import os
import time
from pathlib import Path

import asyncpg
import httpx
from asgi_lifespan import LifespanManager
from cryptography.fernet import Fernet
from llm_gateway_api.app import create_app
from llm_gateway_api.development import development_snapshot
from llm_gateway_infrastructure.settings import Settings
from llm_gateway_infrastructure.storage import Database, metadata

OUT = Path('/tmp/g83-evidence')
URL = 'postgresql+asyncpg://gateway:gateway@127.0.0.1:55432/g83_live_test'

class Capture(httpx.AsyncBaseTransport):
    def __init__(self):
        self.inner = httpx.AsyncHTTPTransport(retries=0)
        self.requests = []
    async def handle_async_request(self, request):
        row = {'url': str(request.url), 'payload': json.loads(request.content)}
        self.requests.append(row)
        start = time.monotonic()
        try:
            r = await self.inner.handle_async_request(request)
            row['status'] = r.status_code
            if not row['payload'].get('stream'):
                row['response_body'] = (await r.aread()).decode()
            return r
        except Exception as e:
            row['exception_type'] = type(e).__name__
            raise
        finally:
            row['headers_ms'] = (time.monotonic()-start)*1000
    async def aclose(self):
        await self.inner.aclose()

async def main():
    c = await asyncpg.connect('postgresql://gateway:gateway@127.0.0.1:55432/postgres')
    if not await c.fetchval("select 1 from pg_database where datname='g83_live_test'"):
        await c.execute('CREATE DATABASE g83_live_test')
    await c.close()
    snapshot = development_snapshot()
    for alias, protocol, model in [('glm', 'openai_chat', 'deepseek-flash'), ('deepseek', 'openai_responses', 'deepseek-v4-pro')]:
        p = snapshot.providers[alias]
        p.vendor, p.protocol, p.base_url = 'deepseek', protocol, 'https://api.deepseek.com'
        p.secret_ref, p.auth_type = 'env:DEEPSEEK_API_KEY', 'bearer'
        p.read_idle_timeout_s = p.first_content_timeout_s = 20
        p.extension_parameters = ['thinking']
        snapshot.models[alias].upstream_model = model
        snapshot.models[alias].defaults = {'max_output_tokens': 128}
        snapshot.models[alias].capabilities.structured_output_modes = ['json_object', 'json_schema']
        snapshot.models[alias].capabilities.reasoning_levels = ['none']
        snapshot.routes[alias].max_retries_per_candidate = 0
        snapshot.routes[alias].max_switches = 0
    snapshot.providers['kimi'].enabled = False
    (OUT/'live-config.json').write_text(snapshot.model_dump_json(indent=2))
    db = Database(URL)
    async with db.engine.begin() as conn:
        await conn.run_sync(metadata.create_all)
    await db.bootstrap(snapshot)
    await db.engine.dispose()
    transport = Capture()
    settings = Settings(database_url=URL, redis_url='redis://127.0.0.1:56379/14', continuation_key=Fernet.generate_key().decode(), spool_dir='/tmp/g83-live-spool', policy_poll_s=30)
    app = create_app(settings, transport=transport)
    results = []
    async with LifespanManager(app):
        assert app.state.ready
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://gateway', headers={'Authorization':'Bearer dev-app-key'}) as client:
            for alias in os.getenv('LIVE_ALIASES', 'glm,deepseek').split(','):
                for kind in os.getenv('LIVE_CASES', 'normal,stream,json').split(','):
                    payload = {'model': alias, 'messages': [{'role':'user','content':[{'type':'text','text':'Reply only with {"ok":true} as JSON.'}]}], 'execution': {'max_total_attempts':1, 'total_timeout_s':25.0}}
                    if alias == 'glm': payload['extensions'] = {'deepseek': {'thinking': {'type':'disabled'}}}
                    else: payload['requirements'] = {'reasoning_level':'none'}
                    if kind == 'stream': payload['stream'] = True
                    if kind == 'json': payload['response_format'] = {'type':'json_object'}
                    started = time.monotonic()
                    response = await client.post('/v1/generate', json=payload)
                    row = {'alias':alias,'kind':kind, 'http_status':response.status_code,'elapsed_ms':(time.monotonic()-started)*1000,'body':response.text}
                    if kind == 'stream' and response.status_code == 200:
                        events = [json.loads(s[5:]) for s in response.text.splitlines() if s.startswith('data:')]
                        call_id = events[-1]['call_id']
                        row['success'] = events[-1]['data']['status'] == 'completed' and any(e['type']=='delta' for e in events)
                    else:
                        body = response.json()
                        call_id = body.get('call_id') or body.get('error',{}).get('call_id')
                        row['success'] = response.status_code == 200 and bool(body.get('content'))
                        if kind == 'json' and row['success']: json.loads(body['content'])
                    row['call_id'] = call_id
                    if call_id:
                        row['ledger'] = (await client.get('/v1/calls/'+call_id)).json()
                    results.append(row)
                    (OUT/os.getenv('LIVE_OUTPUT', 'live-results.json')).write_text(json.dumps({'results':results,'wire_requests':transport.requests},ensure_ascii=False,indent=2))
                    print(alias, kind, response.status_code, row['success'], round(row['elapsed_ms']), call_id, flush=True)
                    if not row['success'] and response.status_code >= 500:
                        print('Bounded upstream failure: remaining cases for this alias unverified', flush=True)
                        break

asyncio.run(main())
