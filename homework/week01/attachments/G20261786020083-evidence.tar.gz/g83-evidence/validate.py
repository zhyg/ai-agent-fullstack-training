"""Validate rubric arithmetic, concise report format, exact secret exclusion and tar contents."""
import os
import re
import tarfile
from pathlib import Path

ROOT = Path('/home/user/workspace/repo/homework/week01')
EVIDENCE = Path('/tmp/g83-evidence')
REPORT = ROOT/'G20261786020083.md'
ATTACH = ROOT/'attachments/G20261786020083.md'
ARCHIVE = ROOT/'attachments/G20261786020083-evidence.tar.gz'

feedback = REPORT.read_text()
for title in ['2. 作业优点','3. 作业不足','4. 改进方案']:
    section = feedback.split('**'+title+'**')[1].split('\n**')[0]
    bullets = re.findall(r'^- .+',section,re.M)
    assert 3 <= len(bullets) <= 5
    assert len(section) <= 500
    print(title,'items',len(bullets),'characters',len(section))
assessment = ATTACH.read_text()
scores = [int(x) for x in re.findall(r'^\| [^|]+ \| (\d+)/(?:15|10) \|',assessment,re.M)]
assert len(scores)==8 and sum(scores)==98, scores
assert '优秀（98分）' in feedback and '98/100' in assessment
assert all('## '+x+'.' in assessment for x in 'ABCDEF')
secrets = [v.encode() for k,v in os.environ.items() if k.endswith('API_KEY') and len(v)>=8]
assert os.environ.get('DEEPSEEK_API_KEY'), 'Required key not available to compare'
files = [p for p in EVIDENCE.iterdir() if p.is_file()] + [REPORT,ATTACH]
for path in files:
    data = path.read_bytes()
    assert all(s not in data for s in secrets), 'Secret match in '+path.name
scan = 'Exact actual API key byte scan: PASS; values never printed.\nReport format and eight-item arithmetic: PASS (98/100).\nNo .env, database, virtualenv, pycache or authentication headers included.\n'
(EVIDENCE/'security-scan.txt').write_text(scan)
with tarfile.open(ARCHIVE,'w:gz') as tar:
    for path in sorted(EVIDENCE.iterdir()):
        if path.is_file(): tar.add(path,arcname='g83-evidence/'+path.name)
with tarfile.open(ARCHIVE,'r:gz') as tar:
    members = tar.getmembers()
    for member in members:
        assert member.isfile() and not member.name.endswith('.env')
        data = tar.extractfile(member).read()
        assert all(s not in data for s in secrets), 'Secret match in archive member'
print('Archive exact-secret decompressed scan PASS;',len(members),'files;',ARCHIVE.stat().st_size,'bytes')
print('Total score 98/100, deductions 2; all checks PASS')
