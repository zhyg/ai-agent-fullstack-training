import asyncio
import copy
import json
import shutil
import time
from pathlib import Path

import httpx
import pytest
from llm_gateway_api.mock_upstream import fixture, stream_fixture

pytestmark = pytest.mark.asyncio
MODELS = ['glm', 'deepseek', 'kimi']
PROTOCOLS = dict(zip(MODELS, ['openai_chat', 'openai_responses', 'anthropic_messages']))
MESSAGES = [{'role': 'user', 'content': [{'type': 'text', 'text': 'teacher asymmetric probe'}]}]
FORMAT = {'type': 'json_schema', 'json_schema': {'schema': {'type': 'object', 'properties': {'order_no': {'type': 'string'}}, 'required': ['order_no']}}}

async def publish(client, mutate):
    current = (await client.get('/admin/v1/policies/current', headers={'Authorization': 'Bearer dev-admin-key'})).json()
    mutate(current['snapshot'])
    r = await client.post('/admin/v1/policies', headers={'Authorization': 'Bearer dev-admin-key'}, json={'base_version': current['version'], 'snapshot': current['snapshot'], 'reason': 'teacher'})
    assert r.status_code == 200, r.text

def events(r):
    return [json.loads(s[5:]) for s in r.text.splitlines() if s.startswith('data:')]

@pytest.mark.parametrize('model', MODELS)
async def test_A03_wire_and_parse(client, upstream, model):
    r = await client.post('/v1/generate', json={'model': model, 'messages': MESSAGES, 'response_format': FORMAT})
    assert r.status_code == 200 and r.json()['structured_data'] == {'order_no': 'R123'}
    req, payload = upstream.requests[-1]
    if model == 'glm':
        assert req.url.path.endswith('/chat/completions') and payload['messages'][0]['content'] == 'teacher asymmetric probe'
        assert payload['response_format']['type'] == 'json_schema'
    elif model == 'deepseek':
        assert req.url.path.endswith('/responses') and payload['input'][0]['content'][0]['type'] == 'input_text'
        assert payload['text']['format']['type'] == 'json_schema'
    else:
        assert req.url.path.endswith('/messages') and payload['messages'][0]['content'][0]['type'] == 'text'
        assert payload['output_config']['format']['type'] == 'json_schema'
    print('WIRE', model, req.url.path, payload, r.json()['structured_data'])

async def test_A04_unknown(client, upstream):
    r = await client.post('/v1/generate', json={'model': 'not-a-model', 'messages': MESSAGES})
    assert r.status_code >= 400 and 'error' in r.json() and not upstream.requests
    print('A04', r.status_code, r.json())

@pytest.mark.parametrize('model', MODELS)
@pytest.mark.parametrize('kind', ['illegal', 'empty', 'truncated', 'schema'])
async def test_F04_json(client, upstream, model, kind):
    async def override(req, payload):
        body = fixture(PROTOCOLS[model], payload)
        value = {'illegal': 'no-json', 'empty': '', 'truncated': '{"order_no":', 'schema': '{"order_no":123}'}[kind]
        if model == 'glm':
            body['choices'][0]['message']['content'] = value
            if kind == 'truncated': body['choices'][0]['finish_reason'] = 'length'
        elif model == 'deepseek':
            body['output'][0]['content'][0]['text'] = value
            if kind == 'truncated': body['status'] = 'incomplete'
        else:
            body['content'][0]['text'] = value
            if kind == 'truncated': body['stop_reason'] = 'max_tokens'
        return httpx.Response(200, json=body)
    upstream.override = override
    r = await client.post('/v1/generate', json={'model': model, 'messages': MESSAGES, 'response_format': FORMAT, 'execution': {'max_total_attempts': 1}})
    assert r.status_code >= 400 and 'error' in r.json(), r.text
    print('F04', model, kind, r.status_code, r.json()['error']['code'])

async def test_F05_F06_versions(client, upstream, tmp_path):
    store = client.app.state.gateway.prompts
    root = tmp_path / 'bundles'
    shutil.copytree(store.root, root)
    v2 = root / 'extract_order/1.0.1'
    shutil.copytree(root / 'extract_order/1.0.0', v2)
    p = v2 / 'manifest.yaml'
    p.write_text(p.read_text().replace('1.0.0', '1.0.1'))
    (v2 / 'user.jinja2').write_text('VERSION_TWO {{ order_text }}')
    index = json.loads(store.index.read_text())
    store.root = root
    _, digest = store.bundle_bytes('extract_order/1.0.1')
    index.append({**index[0], 'artifact': 'extract_order/1.0.1', 'hash': digest})
    store.index = tmp_path / 'index.json'
    store.index.write_text(json.dumps(index))
    store.refresh()
    for version in ['1.0.1', '1.0.0']:
        r = await client.post('/v1/generate', json={'model': 'order_extraction', 'prompt': {'name': 'extract_order', 'version': version, 'variables': {'order_text': 'TEACHER_984'}}})
        assert r.status_code == 200, r.text
        wire = json.dumps(upstream.requests[-1][1])
        assert 'TEACHER_984' in wire and ('VERSION_TWO' in wire) == (version == '1.0.1')
    for name, version, variables in [('missing', '1.0.0', {}), ('extract_order', '9.0.0', {}), ('extract_order', '1.0.0', {})]:
        n = len(upstream.requests)
        r = await client.post('/v1/generate', json={'model': 'order_extraction', 'prompt': {'name': name, 'version': version, 'variables': variables}})
        assert r.status_code >= 400 and len(upstream.requests) == n
        print('F06', name, version, r.status_code, r.json()['error']['code'])

class Gated(httpx.AsyncByteStream):
    def __init__(self, model, release, broken):
        self.model, self.release, self.broken = model, release, broken
    async def __aiter__(self):
        yield b': heartbeat\n\n'
        await asyncio.sleep(0.05)
        body = fixture(PROTOCOLS[self.model], {})
        seq = list(stream_fixture(PROTOCOLS[self.model], body))
        gated = False
        for event, data in seq:
            yield f'event: {event}\ndata: {json.dumps(data)}\n\n'.encode()
            text = data.get('delta', '')
            is_text = (self.model == 'glm' and data.get('choices', [{}])[0].get('delta', {}).get('content')) or (self.model == 'deepseek' and event == 'response.output_text.delta') or (self.model == 'kimi' and isinstance(text, dict) and text.get('type') == 'text_delta')
            if is_text and not gated:
                gated = True
                await self.release.wait()
                if self.broken: raise httpx.ReadError('teacher forced disconnect')
    async def aclose(self): pass

@pytest.mark.parametrize('model', MODELS)
@pytest.mark.parametrize('broken', [False, True])
async def test_F01_F02_gate(client, upstream, model, broken):
    release, got_delta = asyncio.Event(), asyncio.Event()
    async def override(req, payload):
        return httpx.Response(200, stream=Gated(model, release, broken), headers={'content-type': 'text/event-stream'})
    upstream.override = override
    body = json.dumps({'model': model, 'messages': MESSAGES, 'stream': True}).encode()
    scope = {'type': 'http', 'asgi': {'version': '3.0'}, 'http_version': '1.1', 'method': 'POST', 'scheme': 'http', 'path': '/v1/generate', 'raw_path': b'/v1/generate', 'query_string': b'', 'headers': [(b'authorization', b'Bearer dev-app-key'), (b'content-type', b'application/json')], 'client': ('127.0.0.1', 1234), 'server': ('gateway', 80)}
    sent = False
    out = []
    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {'type': 'http.request', 'body': body, 'more_body': False}
        await asyncio.Event().wait()
    async def send(message):
        out.append(message)
        if message['type'] == 'http.response.body' and b'event: delta' in message.get('body', b''):
            got_delta.set()
    task = asyncio.create_task(client.app(scope, receive, send))
    try:
        await asyncio.wait_for(got_delta.wait(), 5)
        assert not task.done() and not release.is_set()
        print('GATE', model, 'downstream delta received while upstream terminal blocked')
    finally:
        release.set()
        await asyncio.wait_for(task, 5)
    text = b''.join(x.get('body', b'') for x in out).decode()
    ev = [json.loads(s[5:]) for s in text.splitlines() if s.startswith('data:')]
    assert ev[-1]['data']['status'] == ('failed' if broken else 'completed')
    assert len(upstream.requests) == 1
    call = (await client.get('/v1/calls/' + ev[-1]['call_id'])).json()
    assert call['attempts'][0]['ttft_ms'] >= 40
    assert call['payload']['status'] == ('failed' if broken else 'completed')
    print('STREAM', model, broken, ev[-1], call['attempts'][0]['ttft_ms'])

async def test_F07_usage(client, upstream):
    async def override(req, payload):
        body = fixture('openai_chat', payload)
        body['usage'] = {'prompt_tokens': 37, 'completion_tokens': 19, 'total_tokens': 56, 'prompt_tokens_details': {'cached_tokens': 11}, 'completion_tokens_details': {'reasoning_tokens': 7}}
        return httpx.Response(200, json=body)
    upstream.override = override
    r = await client.post('/v1/generate', json={'model': 'glm', 'messages': MESSAGES})
    call = (await client.get('/v1/calls/' + r.json()['call_id'])).json()
    u = call['payload']['usage']
    assert (u['input_tokens'], u['output_tokens'], u['cached_input_tokens'], u['reasoning_tokens']) == (37, 19, 11, 7)
    assert call['payload']['total_ms'] > 0 and call['attempts'][0]['ttft_ms'] is None
    print('USAGE', u)

async def test_F08_F09_attempts(client, upstream, monkeypatch):
    await publish(client, lambda s: s['routes']['glm'].update(initial_delay_s=0.01))
    monkeypatch.setattr('llm_gateway_core.execution.random.uniform', lambda a, b: 1.0)
    times = []
    async def override(req, payload):
        times.append(time.monotonic())
        return httpx.Response(503) if len(times) < 3 else None
    upstream.override = override
    r = await client.post('/v1/generate', json={'model': 'glm', 'messages': MESSAGES})
    assert r.status_code == 200 and len(times) == 3
    print('F08 request intervals', [round(b-a, 4) for a,b in zip(times, times[1:])])
    for code, expected in [(503, 4), (401, 1), (400, 1)]:
        upstream.requests.clear()
        async def fail(req, payload): return httpx.Response(code)
        upstream.override = fail
        r = await client.post('/v1/generate', json={'model': 'glm', 'messages': MESSAGES})
        assert r.status_code >= 400 and len(upstream.requests) == expected
        call = (await client.get('/v1/calls/' + r.json()['error']['call_id'])).json()
        assert call['payload']['status'] == 'failed' and len(call['attempts']) == expected
        print('F09', code, expected, r.status_code, r.json()['error']['code'])

async def test_F10_F11_limit(client, upstream):
    await publish(client, lambda s: s['models']['glm'].update(rpm=1))
    payload = {'model': 'glm', 'messages': MESSAGES}
    assert (await client.post('/v1/generate', json=payload)).status_code == 200
    r = await client.post('/v1/generate', json=payload)
    assert r.status_code == 429
    assert (await client.post('/v1/generate', json={'model': 'deepseek', 'messages': MESSAGES})).status_code == 200
    streaming = await client.post('/v1/generate', json={**payload, 'stream': True})
    assert events(streaming)[-1]['data']['error']['code'] == 'GATEWAY_RATE_LIMITED'
    print('F10 stream HTTP', streaming.status_code, events(streaming)[-1])
    await asyncio.sleep(60.2)
    recovered = await client.post('/v1/generate', json=payload)
    assert recovered.status_code == 200, recovered.text
    print('F11 real elapsed 60.2s recovery', recovered.status_code)

async def test_backoff_cap_observation(client, upstream, monkeypatch):
    await publish(client, lambda s: s['routes']['glm'].update(initial_delay_s=0.02, max_delay_s=0.02))
    monkeypatch.setattr('llm_gateway_core.execution.random.uniform', lambda a, b: 1.5)
    original = asyncio.sleep
    delays = []
    async def spy(delay, *args):
        if abs(delay - 0.03) < 0.00001: delays.append(delay)
        return await original(delay, *args)
    monkeypatch.setattr('llm_gateway_core.execution.asyncio.sleep', spy)
    async def failed(req, payload): return httpx.Response(503)
    upstream.override = failed
    r = await client.post('/v1/generate', json={'model':'glm','messages':MESSAGES})
    assert len(upstream.requests) == 4 and delays == [0.03, 0.03, 0.03]
    print('DEFECT backoff configured cap=0.02 actual waits=', delays, 'HTTP',r.status_code)

async def test_repair_still_invalid(client, upstream):
    await publish(client, lambda s: s['routes']['glm'].update(allow_model_repair=True))
    async def bad(req, payload):
        body = fixture('openai_chat', payload)
        body['choices'][0]['message']['content'] = 'not JSON even after repair'
        return httpx.Response(200, json=body)
    upstream.override = bad
    r = await client.post('/v1/generate', json={'model':'glm','messages':MESSAGES,'response_format':FORMAT,'execution':{'model_repair':True}})
    assert r.status_code >= 400 and len(upstream.requests) == 2, r.text
    print('F04 repair invalid',r.status_code,r.json()['error']['code'],len(upstream.requests))

@pytest.mark.parametrize('model', MODELS)
async def test_F07_stream_snapshots(client, upstream, model):
    from conftest import Chunks, sse_bytes
    raws = {
        'glm': {'prompt_tokens':37, 'completion_tokens':19, 'total_tokens':56, 'prompt_tokens_details':{'cached_tokens':11}, 'completion_tokens_details':{'reasoning_tokens':7}},
        'deepseek': {'input_tokens':43, 'output_tokens':17, 'total_tokens':60, 'input_tokens_details':{'cached_tokens':13}, 'output_tokens_details':{'reasoning_tokens':5}},
        'kimi': {'input_tokens':13, 'output_tokens':19, 'cache_read_input_tokens':11, 'cache_creation_input_tokens':5},
    }
    async def override(req, payload):
        body = fixture(PROTOCOLS[model],payload)
        body['usage'] = raws[model]
        seq = list(stream_fixture(PROTOCOLS[model],body))
        if model == 'glm':
            seq.insert(0, ('message',{'choices':[], 'usage':{**raws[model], 'completion_tokens':6}}))
        if model == 'kimi':
            seq[0][1]['message']['usage'] = {k:v for k,v in raws[model].items() if k != 'output_tokens'}
            for event, data in seq:
                if event == 'message_delta': data['usage'] = {'output_tokens':19}
        return httpx.Response(200,stream=Chunks(sse_bytes(seq)),headers={'content-type':'text/event-stream'})
    upstream.override = override
    r = await client.post('/v1/generate',json={'model':model,'messages':MESSAGES,'stream':True})
    ev = events(r)
    assert ev[-1]['data']['status']=='completed'
    call = (await client.get('/v1/calls/'+ev[-1]['call_id'])).json()
    u = call['payload']['usage']
    expected = {'glm':(37,19,11,0,7), 'deepseek':(43,17,13,0,5), 'kimi':(29,19,11,5,None)}[model]
    assert tuple(u[k] for k in ['input_tokens','output_tokens','cached_input_tokens','cache_write_tokens','reasoning_tokens']) == expected
    print('F07 snapshots',model,u,'total derived',u['input_tokens']+u['output_tokens'])
