"""Original student app, separate bootstrap artifact and local PG/Redis; no source edits."""
import asyncio
import json
import os
from pathlib import Path
import asyncpg
import uvicorn
from cryptography.fernet import Fernet
from llm_gateway_api.app import create_app
from llm_gateway_api.development import development_snapshot
from llm_gateway_infrastructure.settings import Settings
from llm_gateway_infrastructure.storage import Database, metadata

async def setup():
    c = await asyncpg.connect('postgresql://gateway:gateway@127.0.0.1:55432/postgres')
    if not await c.fetchval("select 1 from pg_database where datname='g83_http_test'"):
        await c.execute('CREATE DATABASE g83_http_test')
    await c.close()
    url = 'postgresql+asyncpg://gateway:gateway@127.0.0.1:55432/g83_http_test'
    snapshot = development_snapshot('http://127.0.0.1:18081')
    Path('/tmp/g83-evidence/http-config.json').write_text(snapshot.model_dump_json(indent=2))
    db = Database(url)
    async with db.engine.begin() as c: await c.run_sync(metadata.create_all)
    await db.bootstrap(snapshot)
    await db.engine.dispose()
    return Settings(database_url=url, redis_url='redis://127.0.0.1:56379/13', bootstrap_path='/tmp/g83-evidence/http-config.json', continuation_key=Fernet.generate_key().decode(), spool_dir='/tmp/g83-http-spool')

if __name__ == '__main__':
    for name in ['GLM_API_KEY','DEEPSEEK_API_KEY','KIMI_API_KEY']:
        os.environ[name] = 'teacher-local-mock-only'
    settings = asyncio.run(setup())
    uvicorn.run(create_app(settings), host='127.0.0.1',port=18080)
