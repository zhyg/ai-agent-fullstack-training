"""OpenAI-compatible streaming adapter."""
import asyncio
import json
from typing import AsyncIterator
import httpx
from app.events import ReasoningDelta, ContentDelta, ToolCallDelta, Finish, ModelEvent
from app.models.base import ModelError


class OpenAICompatibleAdapter:
    def __init__(self, name: str, base_url: str, api_key: str, default_model: str):
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.default_model = default_model

    async def stream(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        *,
        cancel: asyncio.Event | None = None,
        request_id: str = "",
    ) -> AsyncIterator[ModelEvent]:
        if not self.api_key:
            raise ModelError("missing_key", f"{self.name} API key is not configured")

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        payload = {
            "model": self.default_model,
            "messages": messages,
            "stream": True,
        }
        if tools:
            payload["tools"] = tools

        # 超时设置：连接10s，总长300s
        timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream(
                    "POST", f"{self.base_url}/chat/completions",
                    json=payload, headers=headers
                ) as response:
                    if response.status_code != 200:
                        body = await response.aread()
                        raise ModelError("api_error", f"HTTP {response.status_code}: {body[:200]}")

                    async for line in response.aiter_lines():
                        if cancel and cancel.is_set():
                            raise asyncio.CancelledError()

                        if not line.startswith("data: "):
                            continue
                        data_str = line[6:].strip()
                        if data_str == "[DONE]":
                            break
                        if not data_str:
                            continue

                        try:
                            chunk = json.loads(data_str)
                        except json.JSONDecodeError:
                            continue

                        choices = chunk.get("choices", [])
                        if not choices:
                            continue
                        
                        delta = choices[0].get("delta", {})
                        finish_reason = choices[0].get("finish_reason")

                        if "reasoning_content" in delta and delta["reasoning_content"]:
                            yield ReasoningDelta(delta["reasoning_content"])

                        if "content" in delta and delta["content"]:
                            yield ContentDelta(delta["content"])

                        if "tool_calls" in delta:
                            for tc in delta["tool_calls"]:
                                idx = tc.get("index", 0)
                                tc_id = tc.get("id")
                                fn = tc.get("function", {})
                                name = fn.get("name")
                                args = fn.get("arguments")
                                if tc_id or name or args:
                                    yield ToolCallDelta(index=idx, id=tc_id, name=name, args_delta=args)

                        if finish_reason:
                            yield Finish(finish_reason=finish_reason, usage=chunk.get("usage"))
                            return

        except httpx.TimeoutException as e:
            raise ModelError("timeout", f"Model request timed out: {str(e)}", retryable=True)
        except httpx.RequestError as e:
            raise ModelError("network_error", str(e), retryable=True)
        except asyncio.CancelledError:
            raise
