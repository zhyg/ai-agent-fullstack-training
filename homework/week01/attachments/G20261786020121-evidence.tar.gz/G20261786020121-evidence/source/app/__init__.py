"""Streaming Agent Gateway."""
