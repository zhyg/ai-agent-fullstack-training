import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import tarfile

root = Path('/home/user/workspace/repo')
work = Path('/tmp/wangfang-grade')
stage = work/'evidence'
stage.mkdir(exist_ok=True)
source = stage/'source'
source.mkdir(exist_ok=True)
archive = subprocess.check_output(['git','archive','HEAD','app','tests','README.md','pyproject.toml','.env.example'],cwd=work/'student')
with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
    tf.extractall(source, filter='data')
files = ['upstream.py','launch.py','teacher.py','check_results.py','failure_plugin.py',
         'commands.md','package_evidence.py','clone.log','install.log','student-tests.log',
         'student-injected-failure.log','teacher.log','check-results.log','teacher-results.json',
         'upstream-calls.json','openapi.json','dependencies.txt','source-files.txt',
         'student-worktree.txt','commit.txt','feature-search.txt','official-models.json','real-results.json']
for name in files:
    shutil.copyfile(work/name,stage/name)
report = root/'homework/week01/G20261786020121.md'
attachment = root/'homework/week01/attachments/G20261786020121.md'
shutil.copyfile(report,stage/'feedback.md')
shutil.copyfile(attachment,stage/'assessment.md')
sections = re.split(r'\*\*[234]\. [^\n]+\*\*',report.read_text())[1:]
fmt = []
for section in sections:
    entries = re.findall(r'^- (.+)$', section, re.M)
    size = sum(len(e) for e in entries)
    assert 3 <= len(entries) <= 5 and size <= 500, (len(entries),size)
    fmt.append({'items':len(entries),'characters':size})
rows = re.findall(r'^\| (?!合计)([^|]+) \| (\d+)/(\d+) \|',attachment.read_text(),re.M)
assert len(rows)==8 and sum(int(r[1]) for r in rows)==50
assert '不及格（50分）' in report.read_text()
assert subprocess.check_output(['git','status','--porcelain'],cwd=work/'student') == b''
service_status = subprocess.check_output(['amp','orb','service','list'],cwd=root).decode()
assert 'No orb services are running.' in service_status
for port in [18121,18122,18123]:
    with socket.socket() as s:
        assert s.connect_ex(('127.0.0.1',port)) != 0
(stage/'shutdown.log').write_text('Three stop calls succeeded from course repository.\n'+service_status+'Ports 18121,18122,18123 closed.\nStudent worktree clean.\n')
secrets = [v.encode() for k,v in os.environ.items()
           if re.search(r'(?:KEY|TOKEN|SECRET|PASSWORD)$',k,re.I) and len(v)>=8]
assert os.environ.get('DEEPSEEK_API_KEY')
def scan(paths):
    for file in paths:
        data=file.read_bytes()
        assert all(secret not in data for secret in secrets), 'Actual environment secret found in '+str(file)
        assert not re.search(rb'\bsk-[A-Za-z0-9_-]{16,}\b',data), 'Key-like value found in '+str(file)
scan(p for p in stage.rglob('*') if p.is_file())
validation={'score':50,'max_score':100,'grade':'不及格','eight_item_score_sum':50,
            'feedback_sections':fmt,'actual_environment_secret_scan':'PASS including DEEPSEEK_API_KEY; values not printed',
            'key_pattern_scan':'PASS; short sk-123 is student test placeholder',
            'student_worktree':'clean','services':'stopped','ports':'closed',
            'real_generation_requests':2,'archive_members':'source snapshot, allowlisted scripts/logs/results only; no .env/.git/venv',
            'source_commit':'f1b6f13d56bb0109faf945d44a03703605840a3c'}
(stage/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
hashes = {str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.rglob('*') if p.is_file()}
(stage/'sha256-manifest.json').write_text(json.dumps(hashes,indent=2))
target = root/'homework/week01/attachments/G20261786020121-evidence.tar.gz'
with tarfile.open(target,'w:gz') as tf:
    tf.add(stage,arcname='G20261786020121-evidence')
scan([report,attachment])
with tarfile.open(target) as tf:
    for member in tf.getmembers():
        assert not any(part in ['.env','.git','venv','.venv','__pycache__'] for part in Path(member.name).parts)
        if member.isfile():
            data=tf.extractfile(member).read()
            assert all(secret not in data for secret in secrets)
            assert not re.search(rb'\bsk-[A-Za-z0-9_-]{16,}\b',data)
print(json.dumps(validation,ensure_ascii=False,indent=2))
print('Archive SHA256',hashlib.sha256(target.read_bytes()).hexdigest(),'bytes',target.stat().st_size)
