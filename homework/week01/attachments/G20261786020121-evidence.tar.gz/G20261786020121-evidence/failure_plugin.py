"""Teacher-only corrupted upstream fixture; student source is not edited."""
import httpx
import pytest

@pytest.fixture(autouse=True)
def corrupted_upstream(monkeypatch):
    original = httpx.MockTransport
    def replacement(handler):
        def corrupt(request):
            return httpx.Response(200, content=b'data: {"choices":[{"delta":{"content":"wrong upstream fixture"},"finish_reason":"stop"}]}\n\n')
        return original(corrupt)
    monkeypatch.setattr(httpx, 'MockTransport', replacement)
