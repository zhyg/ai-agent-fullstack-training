import collections
import json
from pathlib import Path

p = Path('/tmp/wangfang-grade')
results = json.loads((p/'teacher-results.json').read_text())
calls = json.loads((p/'upstream-calls.json').read_text())
bycase = {r['case']: r for r in results}
counts = collections.Counter(c['body']['messages'][0]['content'] for c in calls)

def texts(result):
    return ''.join(e['data']['choices'][0]['delta'].get('content', '') for e in result['events']
                   if e.get('event') == 'message.delta' and isinstance(e.get('data'), dict))

for model in ['deepseek', 'qwen']:
    gated = bycase['gate:'+model]['result']
    assert gated['status']['status'] == 'completed'
    assert texts(gated) == 'first-second'
    assert counts['gate:'+model] == 1
    print('PASS F01', model, 'first content caused gate release; exact text first-second; one upstream request')
    for mode in ['drop', 'error_event']:
        r = bycase[mode+':'+model]['result']
        assert r['status']['status'] == 'failed'
        assert counts[mode+':'+model] == 1
        assert texts(r) == 'first'
        assert any(e.get('event') == 'error' and isinstance(e.get('data'), dict) for e in r['events'])
        print('PASS F02', mode, model, 'failure visible; no restart or duplicated content')
    for mode in ['invalid', 'empty', 'truncated']:
        r = bycase[mode+':'+model]['result']
        assert r['status']['status'] == 'completed'
        try:
            json.loads(texts(r))
        except json.JSONDecodeError:
            print('FAIL F04', model, mode, 'invalid JSON reported completed', repr(texts(r)))
        else:
            raise AssertionError('Fixture unexpectedly legal')
    for mode in ['retry', 'fail500', 'fail400']:
        assert counts[mode+':'+model] == 1
        assert bycase[mode+':'+model]['result']['status']['status'] == 'failed'
    print('FAIL F08', model, 'first retryable 500 ends run; 1 actual request, 0 waits; HTTPX only, no SDK')
    print('PASS F09', model, 'persistent500=1 attempt, bad400=1 attempt; no unbounded loop')
    tail = bycase['usage_tail:'+model]['result']
    assert all(e['data'].get('usage') is None for e in tail['events'] if e.get('event') == 'run.completed' and isinstance(e.get('data'), dict))
    print('FAIL F07', model, 'usage-only trailing chunk lost; no TTFT/elapsed metric in public record')

assert set(c['path'] for c in calls) == {'/chat/completions'}
assert {c['body']['model'] for c in calls} == {'controlled-A', 'controlled-B'}
assert all(c['body']['stream'] is True for c in calls)
assert all('response_format' not in c['body'] for c in calls)
print('FAIL A03: both adapters same path/body/parse protocol; FAIL F03: response_format ignored')
assert bycase['A04']['result']['status']['status'] == 'completed'
print('FAIL A04: unknown model silently runs Mock')
assert all('{{name}}' in c['body']['messages'][0]['content'] for c in calls if c['body']['messages'][0]['content'].startswith('literal'))
print('FAIL F05/F06: template management absent; missing references ignored; literal placeholder reaches upstream')
lim = bycase['F10/F11']
assert lim['burst_statuses'] == [200]*30 and lim['burst_terminal'] == ['completed']*30
print('FAIL F10: 30/30 accepted; source has no limiter/config; F11 NOT APPLICABLE: absent quota cannot recover')
real = json.loads((p/'real-results.json').read_text())
for item in real:
    r = item['result']
    assert r['status']['status'] == 'completed' and texts(r) == 'OK'
    usage = next(e['data']['usage'] for e in r['events'] if e.get('event') == 'run.completed' and isinstance(e.get('data'),dict))
    assert usage['prompt_tokens'] + usage['completion_tokens'] == usage['total_tokens']
    first_text = next(e['elapsed'] for e in r['events'] if e.get('event') == 'message.delta')
    first_reasoning = next(e['elapsed'] for e in r['events'] if e.get('event') == 'reasoning.delta')
    print('PASS REAL', item['alias'], item['upstream_model'], r['run_id'], usage, 'teacher first body',first_text,'first reasoning',first_reasoning,'total',r['elapsed'])
print('OBSERVATION CHECKS PASSED; contract FAIL labels above remain grading defects, not test passes')
