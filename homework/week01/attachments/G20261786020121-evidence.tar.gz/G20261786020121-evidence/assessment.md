# 第一周作业评测附件

- 学员：王方，G20261786020121。
- 仓库：https://github.com/king2fang/streaming-agent-gateway.git
- 固定分支与提交：main，`f1b6f13d56bb0109faf945d44a03703605840a3c`（以证据包 commit.txt 为准）。
- 评测日期：2026-11-08，Asia/Singapore；原测试在 11-08 凌晨完成，续评约 10:10–10:20。
- 总分：50/100；作业等级：不及格。
- 验收结论：未通过。源码完整可启动，但仅一种真实协议，多项必需功能未实现。非环境扣分，无额外封顶。
- 学生源码未修改；独立 orb 亲自验收，未另开线程、未提交或推送。三个教师服务均已停止。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 9/15 | 接口3、路由2/4、双协议0/4、统一结果4。D1 双协议缺失扣4；D2 未知模型静默回退扣2。 |
| 流式输出 | 15/15 | 两个适配器 SSE5、门控真实增量5、终止错误3、输出后不重试2。双协议根因不再在本项重复扣分。 |
| 结构化输出 | 0/10 | D3 无约束映射、解析校验或失败处理，三个子项0/4、0/3、0/3；不是仅缺 Schema。 |
| 提示词版本管理 | 0/10 | D4 无存储、替换、版本引用、缺项策略，四子项均缺失。 |
| 可观测性 | 9/15 | 用量3/5（D5尾帧丢失扣2）、延迟0/4（D6扣4）、关联查询3、失败记录3。 |
| 统一错误与重试 | 10/15 | 错误结构4、退避0/4、实际次数上限3、不可重试3、重试过程0/1；D7 缺少重试与退避合计扣5，不因“一次就停”再扣次数上限。 |
| 按模型独立限流 | 0/10 | D8 整项未实现：独立计数0/4、429为0/3、恢复0/2、阈值0/1；隔离/恢复不重复叠扣。 |
| 源码、README 与验证脚本 | 7/10 | 源码2、安装3、curl示例2；D9 脚本验收覆盖0/3，现有断言有效，但未覆盖题目六项；不按业务缺陷逐项追加回归扣分。 |
| 合计 | 50/100 | 9+15+0+0+9+10+0+7=50；扣分共50。 |

## 环境、配置与复现入口

证据包解压后的 `source/` 为固定提交源码快照，`teacher.py`、`upstream.py`、`launch.py`、`check_results.py`、`failure_plugin.py` 为教师外置脚本，不属于学生交付。Python3.11，依赖版本见 dependencies.txt。真实密钥仅从已有 DEEPSEEK_API_KEY 继承，不落文件、不归档。

实际执行命令（工作目录 `/tmp/wangfang-grade/student`，教师服务启动与停止在课程仓库目录执行）：

```bash
git clone https://github.com/king2fang/streaming-agent-gateway.git /tmp/wangfang-grade/student
git rev-parse HEAD
python3 -m venv /tmp/wangfang-grade/venv
/tmp/wangfang-grade/venv/bin/python -m pip install -e '.[dev]'
/tmp/wangfang-grade/venv/bin/python -m pytest -q
# 服务由 amp orb service start 管理；完整启动/停止命令见 commands.md
/tmp/wangfang-grade/venv/bin/python -u /tmp/wangfang-grade/teacher.py
/tmp/wangfang-grade/venv/bin/python /tmp/wangfang-grade/check_results.py
PYTHONPATH=/tmp/wangfang-grade /tmp/wangfang-grade/venv/bin/python -m pytest -q tests/test_s4.py -p failure_plugin
```

- 受控配置：两个 Base URL 均指向本机教师上游，假密钥，模型 controlled-A/controlled-B；记录实际 HTTP 路径、body、鉴权方案和次数，不记录 Authorization 值。
- 真实配置：DeepSeek 官方 `https://api.deepseek.com`，deepseek→deepseek-flash，qwen→deepseek-v4-pro，DASHSCOPE_API_KEY 在进程内引用已有 DeepSeek 密钥。与 README 的 deepseek-chat、DashScope/qwen-plus 不同；这是公开配置能力的替代验收，不证明 DashScope 可用，也不凭改别名伪造双协议。
- 仅2次真实生成请求，各一次；`GET /models` 确认当前官方模型标识。每次教师绝对期限60秒，读超时45秒，超时取消运行；此次均成功，无需重试真实上游。学生未暴露 max_tokens 配置，使用极短提示“Reply only OK. Do not explain.”控制费用。
- 原 pytest PID5523 已无进程，最终日志为 `28 passed, 1 warning in 4.67s`。安装兼容性警告不扣分。

## A01–A04 / F01–F12 结果

| 编号 | 结论 | 实测与证据 |
| --- | --- | --- |
| A01 | 通过 | README editable/dev安装成功；`/healthz`返回ok；install.log、student-tests.log、teacher-results.json。未修改源码，端口18121/18123为隔离差异。 |
| A02 | 配置替代通过；原组合未验证 | 两个别名真实成功，见下表；非原DashScope模型与端点，不能声称原组合通过；环境差异不扣分。 |
| A03 | 失败 | 57条受控请求全部 `POST /chat/completions`，`model/messages/stream:true`，Bearer鉴权，同一choices/delta解析。只有模型字段不同。 |
| A04 | 失败 | not-a-model返回HTTP200并completed，正文“Hello, I am a Mock Model!”；未返回bad_model。 |
| F01 | 通过 | 两适配器先发first、阻塞终态；教师客户端读到正文才释放门控，再收到-second与DONE。不是时间差推断或完整缓冲伪流。 |
| F02 | 通过 | 两适配器正文后EOF/错误事件均failed，error包含stream_interrupted，DONE不掩盖错误；每场景上游仅1次，无重复正文。错误事件细节被归为中断，建议优化但不追加扣分。 |
| F03 | 失败 | 统一入口忽略response_format，合法JSON只是受控上游恰好返回合法文本；上游body无该约束，源码亦无其他结构化入口。 |
| F04 | 失败 | 两适配器not JSON、空正文、`{"x":`+length均completed，JSON解析均失败。无修复实现，不虚构“修复后”通过。 |
| F05 | 失败 | OpenAPI无模板接口/字段，源码无模板实现；发布v1/v2诊断请求均405。不是强制要求某个URL，而是入口清单与全源码共同证明缺失。 |
| F06 | 失败（与F05同根因） | 诊断性template引用missing模板/版本/缺变量均被忽略；literal {{name}}原样进入上游。未把教师自拟字段当学生已承诺接口。 |
| F07 | 部分通过 | 同结束帧的11输入/7输出/18总量、缓存3/8、推理2完整保留；独立尾usage帧被丢弃。成功、失败run_id与状态可查；无总延迟/TTFT字段。 |
| F08 | 失败 | 前两次500、第三次成功的上游规则下，每模型实际只收到1次，立即failed；等待次数0，没有指数退避。 |
| F09 | 次数/不可重试通过；重试策略缺失 | 持续500与400各实际1次。使用httpx，无OpenAI/Anthropic SDK，没有隐藏SDK重试或嵌套次数；不把零重试当完整重试通过。 |
| F10 | 失败 | A并发30次全HTTP200且completed，B也成功；无配额/窗口配置、无本地计数或429路径。B成功不能单独证明隔离。 |
| F11 | 无功能可验，非环境阻塞 | 1秒后A仍成功，但从未进入受限状态，不能算恢复通过；源码无限流器，归D8，不额外扣分。 |
| F12 | 部分通过 | 原28测试通过；教师仅损坏MockTransport上游fixture，原test_s4断言明确失败（2!=5），退出码1。缺双协议/结构化/模板/用量延迟/退避/限流验收，不把测试数或退出码当评分门槛。 |

`check-results.log` 的 PASS 是对应窄范围行为，FAIL 为验收缺陷；最后“OBSERVATION CHECKS PASSED”仅表示教师对保存数据的事实校验成立，不代表作业通过。`teacher-results.json`保留完整SSE与接收时间，`upstream-calls.json`为真实网络受控上游收包记录。

## 真实调用记录与限制

两次路径均为官方 `POST /chat/completions`，请求`stream:true`，正文均为OK，结束stop。下列首正文/首推理/总耗时由教师客户端从POST创建前计时，包含创建和订阅开销，不是学生服务已经实现的TTFT账本。

| 别名→实际模型 | 协议 | 关联ID | 输入/输出/总Token | 缓存命中/未命中；推理 | 首正文/首推理/总耗时（秒） | 结果 |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek→deepseek-flash | Chat Completions | run-07145a27fb5d / chatcmpl-run-07145a27fb5d | 38/11/49 | 0/38；9（输出子集） | 1.3145/1.1155/1.3296 | completed，OK |
| qwen→deepseek-v4-pro | Chat Completions | run-cca1549a7e28 / chatcmpl-run-cca1549a7e28 | 91/24/115 | 0/91；22（输出子集） | 1.0896/0.7439/1.1399 | completed，OK |

上游原生请求/响应ID没有被学生适配器保留，表中是网关生成的关联ID，不能冒称DeepSeek原生ID；未因此额外扣分。用量来自上游结束帧，未叠加message.completed和run.completed重复展示的同份usage；缓存、推理为子集，不重复加总。原DashScope凭据未使用/未验证；真实第二种协议不存在，不能用外部配置凭空补齐。

## 扣分复现与固定源码定位

以下行号全部针对固定提交快照，证据包 source/ 可离线复核；统一复现入口为上述teacher.py及check_results.py，场景名与JSON记录case一致。

1. **D1，适配器−4**：分别调用deepseek/qwen，预期不同协议路径/体/解析，实际均Chat Completions。`upstream-calls.json`两个模型均`/chat/completions`；`app/models/deepseek.py:4–11`、`qwen.py:4–11`继承同一适配器，`openai_compat.py:33–48,71–95`同一序列化/解析。不是凭类名判定。
2. **D2，路由−2**：A04传not-a-model，预期统一明确错误，实际HTTP200/Mock成功。teacher-results.json的A04（run-2fcfbad468c2）；`app/models/registry.py:9–15`的else直接Mock，`app/api/runs.py:33–42`未拒绝。保留已知模型动态路由得分。
3. **D3，结构化−10**：F03/F04请求response_format=json_object，预期约束并校验成功内容，实际字段被忽略，非法/空/截断均completed；例如invalid:deepseek（run-444177ca2982）。`app/api/runs.py:19–23,38`无字段/传递；`openai_compat.py:33–39`无映射；`app/agent/loop.py:43–63`只看finish_reason，无JSON解析。同根因三个输入、两个适配器只计一组，不在流式项再扣。
4. **D4，模板−10**：F05发布v1/v2、F06缺项，预期存储、替换、显式版本保留或明确错误，实际无入口/字段，诊断引用忽略，`{{name}}`原样传出。openapi.json、source-files.txt、feature-search.txt与upstream-calls.json互证；`app/api/runs.py:19–42`仅messages/tools/metadata，`openai_compat.py:33–36`直接转发messages。功能缺失不另按三个缺项重复扣。
5. **D5，用量−2**：usage_tail两模型上游在finish后发送choices=[]的usage，预期已知用量进入运行记录，实际usage=null；`openai_compat.py:71–73,94–96`跳过空choices且finish后return。常规同帧用量和分类保留的3分不扣，未知值未编造。
6. **D6，延迟−4**：查询成功、流式、失败记录和SSE，预期总延迟及首有效Token延迟，实际仅创建时间/seq和状态/事件，无延迟指标；`app/api/runs.py:44–56`、`app/store.py:25–39`、`app/agent/loop.py:13–31,63–70`。事件内部ts是时间戳，不是服务已计算并记录的总延迟/TTFT；教师计时不代替学生实现。
7. **D7，重试−5**：retry:*上游前两次500后成功，预期3次请求并发生退避，实际1次即api_error/failed，0等待。upstream-calls.json计数可复核；`openai_compat.py:45–52`单请求，`app/agent/loop.py:67–70`直接失败；`base.py:8–11`retryable仅存储无人消费。工具循环的attempt是turn，不是网络重试。不再扣次数上限，400不重试有分。
8. **D8，限流−10**：F10/F11，预期模型独立配额、耗尽A得到HTTP429、B不受影响并恢复；实际没有任何限流配置/计数/429判断。30次全放行只作运行印证，主要缺失证据为`app/config.py:3–19`完整配置、`app/api/runs.py:25–42`创建路径和feature-search.txt。无法配置窗口，1秒后成功不当恢复证据；整项只扣一次。
9. **D9，验证交付−3**：运行README指定pytest成功，但检查tests/test_s1.py、test_s2.py、test_s3.py、test_s4.py:6–39、test_s5.py、test_s8.py发现其为事件/生命周期/工具/单协议解析/取消/Mock故障，缺必要六项验收；不因退出码建议或业务缺陷逐项缺回归追加分。注入损坏上游证明原断言有效，不否定已有测试价值。

## 补交要求与证据包

- 必须修复：未知模型回退，增加第二协议、JSON约束/校验、模板版本管理、可观测延迟与完整用量收集、有限退避重试、按模型独立限流。
- 必须补充：两种实际协议、两个真实模型的运行证据；上述能力的有效断言脚本，保留门控/中断不重试表现。
- 复验条件：A01–A04及F01–F12按标准逐项可复现；原通义或其他模型若受凭据阻塞明确未验证，不扣环境分、不用Mock冒充。
- `G20261786020121-evidence.tar.gz`：脱敏配置启动脚本、教师请求/响应与断言、原测试和注入失败日志、固定源码、依赖、提交与完整性记录。无真实.env或密钥文件，无虚构上游ID；最终格式、实际密钥精确扫描、包成员检查与服务停止结果见包内validation.json及shutdown.log。
