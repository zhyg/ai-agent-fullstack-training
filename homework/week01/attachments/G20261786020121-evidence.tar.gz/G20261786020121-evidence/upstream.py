import asyncio
import json
import time
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse

app = FastAPI()
calls = []
gates = {}
usage = {"prompt_tokens": 11, "completion_tokens": 7, "total_tokens": 18,
         "prompt_cache_hit_tokens": 3, "prompt_cache_miss_tokens": 8,
         "completion_tokens_details": {"reasoning_tokens": 2}}

@app.get('/calls')
async def get_calls():
    return calls

@app.post('/release/{tag}')
async def release(tag: str):
    gates.setdefault(tag, asyncio.Event()).set()
    return {"released": tag}

@app.post('/{path:path}')
async def upstream(path: str, req: Request):
    body = await req.json()
    tag = body.get('messages', [{}])[0].get('content', 'normal')
    calls.append({"path": '/' + path, "body": body, "time": time.time(),
                  "auth_scheme": req.headers.get('authorization', '').split(' ')[0]})
    n = sum(c['body']['messages'][0]['content'] == tag for c in calls)
    if tag.startswith('fail500') or (tag.startswith('retry') and n <= 2):
        return JSONResponse({"error": {"message": "controlled temporary failure"}}, status_code=500)
    if tag.startswith('fail400'):
        return JSONResponse({"error": {"message": "controlled bad request"}}, status_code=400)
    async def stream():
        def frame(delta, finish=None, u=None):
            return 'data: ' + json.dumps({"id": "controlled-request", "choices": [{"index": 0, "delta": delta, "finish_reason": finish}], "usage": u}) + '\n\n'
        yield ': heartbeat\n\n'
        await asyncio.sleep(0.12)
        text = {"invalid": "not JSON", "empty": "", "truncated": '{"x":', "valid": '{"x":1}'}.get(tag.split(':')[0], 'first')
        yield frame({"content": text})
        if tag.startswith('gate'):
            await asyncio.wait_for(gates.setdefault(tag, asyncio.Event()).wait(), 10)
            yield frame({"content": '-second'})
        if tag.startswith('drop'):
            return
        if tag.startswith('error_event'):
            yield 'data: {"error":{"code":"upstream_failure","message":"controlled midstream failure"}}\n\n'
            return
        yield frame({}, 'length' if tag.startswith('truncated') else 'stop', None if tag.startswith('usage_tail') else usage)
        if tag.startswith('usage_tail'):
            yield 'data: ' + json.dumps({"choices": [], "usage": usage}) + '\n\n'
        yield 'data: [DONE]\n\n'
    return StreamingResponse(stream(), media_type='text/event-stream')
