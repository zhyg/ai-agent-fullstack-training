import os
import sys
import uvicorn

mode = sys.argv[1]
if mode == 'controlled':
    os.environ.update(DEEPSEEK_API_KEY='teacher-placeholder', DASHSCOPE_API_KEY='teacher-placeholder',
                      DEEPSEEK_BASE_URL='http://127.0.0.1:18122', QWEN_BASE_URL='http://127.0.0.1:18122',
                      DEEPSEEK_MODEL='controlled-A', QWEN_MODEL='controlled-B')
else:
    os.environ.update(DASHSCOPE_API_KEY=os.environ['DEEPSEEK_API_KEY'],
                      DEEPSEEK_BASE_URL='https://api.deepseek.com', QWEN_BASE_URL='https://api.deepseek.com',
                      DEEPSEEK_MODEL='deepseek-flash', QWEN_MODEL='deepseek-v4-pro')
os.chdir('/tmp/wangfang-grade/student')
sys.path.insert(0, os.getcwd())
uvicorn.run('app.main:app', host='127.0.0.1', port=18121 if mode == 'controlled' else 18123, log_level='warning')
