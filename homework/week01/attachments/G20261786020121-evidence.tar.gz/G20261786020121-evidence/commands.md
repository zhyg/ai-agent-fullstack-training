# 教师执行与复现记录

学生仓库固定 f1b6f13d56bb0109faf945d44a03703605840a3c，main。无业务源码修改。
脚本使用 /tmp/wangfang-grade 绝对路径；复现时将 source 复制为该目录下 student，并在此目录创建 venv，教师脚本放 /tmp/wangfang-grade。

学生目录执行：
```bash
python3 -m venv /tmp/wangfang-grade/venv
/tmp/wangfang-grade/venv/bin/python -m pip install -e '.[dev]'
/tmp/wangfang-grade/venv/bin/python -m pytest -q
```

课程仓库目录执行（监督服务的启动/停止须在同一工作目录）：
```bash
amp orb service start wang-upstream --command '/tmp/wangfang-grade/venv/bin/python -m uvicorn upstream:app --app-dir /tmp/wangfang-grade --host 127.0.0.1 --port 18122 --log-level warning' --port 18122
amp orb service start wang-controlled --command '/tmp/wangfang-grade/venv/bin/python /tmp/wangfang-grade/launch.py controlled' --port 18121
amp orb service start wang-real --command '/tmp/wangfang-grade/venv/bin/python /tmp/wangfang-grade/launch.py real' --port 18123
```

教师验收：
```bash
/tmp/wangfang-grade/venv/bin/python -u /tmp/wangfang-grade/teacher.py
/tmp/wangfang-grade/venv/bin/python /tmp/wangfang-grade/check_results.py
# 在学生目录运行；预期故障注入后1 failed，退出码1
PYTHONPATH=/tmp/wangfang-grade /tmp/wangfang-grade/venv/bin/python -m pytest -q tests/test_s4.py -p failure_plugin
```

真实服务只使用环境中已有 DEEPSEEK_API_KEY，launch.py 不保存值，不访问原DashScope。/models元数据取自DeepSeek官方GET接口；未含认证头。

课程仓库目录停服务：
```bash
amp orb service stop wang-real
amp orb service stop wang-controlled
amp orb service stop wang-upstream
amp orb service list
```

说明：曾从学生目录尝试stop，工具提示服务属于课程目录且未执行；随后已从正确目录停掉三项，shutdown.log保存最终状态。该环境操作不影响学生评分。
