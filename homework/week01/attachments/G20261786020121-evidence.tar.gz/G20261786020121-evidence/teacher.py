import asyncio
import json
import pathlib
import time
import httpx

OUT = pathlib.Path('/tmp/wangfang-grade')
results = []

async def run(c, model, tag, **extra):
    start = time.monotonic()
    r = await c.post('/v1/runs', json={"model": model, "messages": [{"role": "user", "content": tag}], **extra})
    if r.status_code != 200:
        return {"http": r.status_code, "response": r.json()}
    rid = r.json()['run_id']
    events = []
    try:
        async with c.stream('GET', r.json()['stream_url']) as s:
            event = None
            async for line in s.aiter_lines():
                if line.startswith('event: '):
                    event = line[7:]
                if line.startswith('data: '):
                    raw = line[6:]
                    data = raw if raw == '[DONE]' else json.loads(raw)
                    events.append({"event": event, "data": data, "elapsed": round(time.monotonic()-start, 4)})
                    if tag.startswith('gate') and event == 'message.delta':
                        async with httpx.AsyncClient() as admin:
                            await admin.post('http://127.0.0.1:18122/release/' + tag)
    except httpx.TimeoutException:
        await c.post(f'/v1/runs/{rid}/cancel')
        events.append({"teacher_timeout_seconds": 45})
    status = (await c.get(f'/v1/runs/{rid}')).json()
    return {"http": r.status_code, "run_id": rid, "status": status, "events": events,
            "elapsed": round(time.monotonic()-start, 4)}

async def main():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18121', timeout=12) as c:
        results.append({"case": "A01", "health": (await c.get('/healthz')).json()})
        for model in ['deepseek', 'qwen']:
            for tag in ['gate:'+model, 'drop:'+model, 'error_event:'+model, 'valid:'+model,
                        'invalid:'+model, 'empty:'+model, 'truncated:'+model, 'usage_tail:'+model,
                        'retry:'+model, 'fail500:'+model, 'fail400:'+model]:
                extra = {"response_format": {"type": "json_object"}} if tag.split(':')[0] in ['valid','invalid','empty','truncated'] else {}
                results.append({"case": tag, "model": model, "result": await run(c, model, tag, **extra)})
        results.append({"case": "A04", "result": await run(c, 'not-a-model', 'unknown')})
        for template in [{"id": "missing", "version": "v1", "variables": {}},
                         {"id": "test", "version": "missing", "variables": {}},
                         {"id": "test", "version": "v1", "variables": {}}]:
            results.append({"case": "F06", "template": template, "result": await run(c, 'deepseek', 'literal {{name}}', template=template)})
        schema = (await c.get('/openapi.json')).json()
        (OUT/'openapi.json').write_text(json.dumps(schema, ensure_ascii=False, indent=2))
        for method, path, body in [('POST','/v1/templates',{"id":"test","version":"v1","content":"Hello {{name}}"}),
                                   ('POST','/v1/templates',{"id":"test","version":"v2","content":"Bye {{name}}"})]:
            r = await c.request(method, path, json=body)
            results.append({"case":"F05", "method":method, "path":path, "http":r.status_code, "body":r.text})
        burst = await asyncio.gather(*(run(c, 'deepseek', 'limit:'+str(i)) for i in range(30)))
        other = await run(c, 'qwen', 'limit:B')
        await asyncio.sleep(1)
        recovered = await run(c, 'deepseek', 'limit:after')
        results.append({"case":"F10/F11", "burst_statuses":[x['http'] for x in burst], "burst_terminal":[x['status']['status'] for x in burst], "other":other, "after_1s":recovered,
                        "limitation":"No declared quota/window/configuration; cannot test recovery from an absent limiter"})
    (OUT/'teacher-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
    async with httpx.AsyncClient() as c:
        calls = (await c.get('http://127.0.0.1:18122/calls')).json()
        (OUT/'upstream-calls.json').write_text(json.dumps(calls, ensure_ascii=False, indent=2))
    for item in results:
        r = item.get('result', {})
        print(item['case'], r.get('http'), r.get('status',{}).get('status'), r.get('elapsed'))
    real = []
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18123', timeout=45) as c:
        for model in ['deepseek', 'qwen']:
            try:
                r = await asyncio.wait_for(run(c, model, 'Reply only OK. Do not explain.'), 60)
            except asyncio.TimeoutError:
                runs = (await c.get('/v1/runs')).json()['runs']
                for item in runs:
                    if item['status'] in ['pending', 'running']:
                        await c.post('/v1/runs/' + item['run_id'] + '/cancel')
                r = {"status": {"status": "teacher_deadline"}, "elapsed": 60, "runs": runs}
            real.append({"alias":model, "upstream_model":'deepseek-flash' if model=='deepseek' else 'deepseek-v4-pro',
                         "protocol":"Chat Completions", "base_url":"https://api.deepseek.com", "result":r})
            (OUT/'real-results.json').write_text(json.dumps(real, ensure_ascii=False, indent=2))
            print('REAL', model, r['status']['status'], r['elapsed'], flush=True)

asyncio.run(main())
