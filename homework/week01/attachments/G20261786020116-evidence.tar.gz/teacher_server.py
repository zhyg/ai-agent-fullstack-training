"""Teacher-only transport fixtures. Imports the unmodified student application."""
import asyncio
import json
import time
import httpx
from gateway.app import Model, create_app

audit = []
release = {}
models = {p: Model(p, 'https://teacher.invalid/v1', 'teacher-dummy', 'fixture-'+p, 1000)
          for p in ('responses', 'messages')}
models.update({p+'-limit': Model(p, 'https://teacher.invalid/v1', 'teacher-dummy', 'fixture-'+p, 1)
               for p in ('responses', 'messages')})

def frame(x):
    return ('data: '+json.dumps(x)+'\n\n').encode()

def events(protocol, text):
    if protocol == 'responses':
        return [dict(type='response.output_text.delta', delta=text),
                dict(type='response.completed', response={'usage': {'input_tokens': 17, 'output_tokens': 5,
                     'total_tokens': 22, 'input_tokens_details': {'cached_tokens': 3},
                     'output_tokens_details': {'reasoning_tokens': 2}}})]
    return [dict(type='message_start', message={'usage': {'input_tokens': 17, 'cache_read_input_tokens': 3,
                                                         'cache_creation_input_tokens': 2}}),
            dict(type='content_block_delta', delta={'type':'text_delta', 'text':text}),
            dict(type='message_delta', delta={'stop_reason':'end_turn'}, usage={'output_tokens':5}),
            dict(type='message_stop')]

class Stream(httpx.AsyncByteStream):
    def __init__(self, protocol, scenario, text):
        self.protocol, self.scenario, self.text = protocol, scenario, text
    async def __aiter__(self):
        ev = events(self.protocol, self.text)
        yield b': heartbeat\n\n'
        await asyncio.sleep(.08)
        if self.protocol == 'messages':
            yield frame(ev.pop(0))
        yield frame(ev.pop(0))
        if self.scenario.startswith('gate'):
            release[self.scenario] = False
            while not release[self.scenario]:
                await asyncio.sleep(.01)
        if self.scenario.startswith('interrupt'):
            raise httpx.ReadError('teacher controlled disconnect')
        for e in ev:
            yield frame(e)

async def handler(req):
    b = json.loads(req.content)
    protocol = 'responses' if req.url.path.endswith('/responses') else 'messages'
    msgs = b.get('input', b.get('messages'))
    scenario = msgs[-1]['content']
    audit.append({'path':req.url.path, 'body': b, 'auth_kind': 'Bearer' if 'authorization' in req.headers else 'x-api-key',
                  'scenario': scenario, 'at': time.monotonic()})
    count = sum(a['scenario'] == scenario for a in audit)
    if scenario.startswith('retry') and count <= 2 or scenario.startswith('always503'):
        return httpx.Response(503)
    if scenario.startswith('bad400'):
        return httpx.Response(400, json={'error': {'message':'unsupported json_schema'}})
    if scenario.startswith('auth401'):
        return httpx.Response(401)
    if scenario.startswith('network') and count < 3:
        raise httpx.ConnectError('teacher connection failure', request=req)
    text = {'invalid':'not json', 'empty':'', 'truncated':'{"ok":', 'schema':'{"ok":9}'}.get(scenario.split(':')[0], '{"ok":"yes"}')
    if b['stream']:
        return httpx.Response(200, stream=Stream(protocol, scenario, text), headers={'content-type':'text/event-stream'})
    if protocol == 'responses':
        result = {'status':'completed','output':[{'content':[{'type':'output_text','text':text}]}],
                  'usage':{'input_tokens':17,'output_tokens':5,'total_tokens':22,
                           'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}}
    else:
        result = {'stop_reason':'end_turn','content':[{'type':'text','text':text}],
                  'usage':{'input_tokens':17,'output_tokens':5,'cache_read_input_tokens':3,'cache_creation_input_tokens':2}}
    return httpx.Response(200, json=result)

app = create_app(models, '/tmp/parker-eval/teacher.sqlite', httpx.AsyncClient(transport=httpx.MockTransport(handler)))

@app.get('/teacher/audit')
async def get_audit():
    return audit

@app.post('/teacher/release/{scenario}')
async def unlock(scenario: str):
    release[scenario] = True
    return {'released':scenario}
