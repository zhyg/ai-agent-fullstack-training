"""Teacher pytest plugin: upstream outage, without modifying submitted files."""
import httpx
import pytest

@pytest.fixture(autouse=True)
def outage(monkeypatch):
    original=httpx.MockTransport.__init__
    def init(self, handler):
        original(self, lambda request: httpx.Response(503))
    monkeypatch.setattr(httpx.MockTransport,'__init__',init)
