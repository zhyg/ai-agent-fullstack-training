# 第一周作业评测附件

- 学员：帕克，G20261786020116。
- 仓库：https://github.com/JeromyFarkas/myAI.git
- 实际作业目录：仓库根目录（README、gateway、scripts、tests 均在根目录），非课程仓库的同名教学代码。
- 分支与固定提交：main，592ab1ab5148b397ab9ec11a0d08ac70760021bf。
- 评测日期：2026-11-07（Asia/Singapore）。在本独立 orb 亲自完成，未委托其他线程。
- 总分：**97/100（暂评）**。
- 作业等级：**优秀**，仅按总分确定。
- 验收结论：**证据不完整**。Flash 的两协议真实普通与 JSON 调用成功；Pro 有效成功响应、真实 SSE 成功终态尚未验证，不将环境阻塞扣为代码分。
- 固定方式：clone 后 git archive HEAD 保存完整已跟踪提交；最终 git diff 与 status 均为空。未改学生业务源码，未提交推送。
- 评分依据：课程评分标准 v1.1、作业原文、反馈模板 v1.0。
- 证据包：同目录 `G20261786020116-evidence.tar.gz`；下文文件名均指包内文件。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 同一入口动态路由；双协议路径、鉴权类型、请求及解析经教师捕获验证；未知模型明确 404。不同实际模型真实成功仍待补证，不因环境扣分。 |
| 流式输出 | 15/15 | 双协议真实 HTTP 门控增量、终态、断流错误及输出后不重试通过；真实上游流式成功未验证，不以离线通过代替。 |
| 结构化输出 | 10/10 | 两协议合法 JSON/Schema 通过；非法、空、截断、不符 Schema 在普通及流式均明确失败。格式拒绝状态映射仅在错误项扣一次。 |
| 提示词版本管理 | 10/10 | v1/v2 发布后均可引用，捕获上游 OLD/NEW 内容；缺模板/版本 404、缺变量 422；学生用例覆盖不可覆盖 409。 |
| 可观测性 | 14/15 | 输入输出、缓存/推理分类、请求关联、成功失败记录、总延迟及正文 TTFT 可查；缺 total_tokens 扣 1（D1）。 |
| 统一错误与重试 | 13/15 | 统一错误结构；前两次失败后第三次成功；持续失败四次即停、401 不重试、无 SDK 隐藏重试。上游 400→502 扣 1（D2）；HTTP 抖动超指数上界扣 1（D3）。 |
| 按模型独立限流 | 10/10 | A 配额 1：200→429，B 同时 200；实际等待 60.1 秒后 A 200。模型 rpm 可由配置对象控制。 |
| 源码、README 与验证脚本 | 10/10 | README 安装启动、curl 入口与依赖完整；学生脚本 14 passed；教师制造上游故障后原脚本明确失败并退出 1。覆盖六功能，不因边界回归不足重复扣分。 |
| **合计** | **97/100** | 15+15+10+10+14+13+10+10=97；只扣三个独立根因，不按测试通过率换分。 |

建议拆分对应：观测 Token 子项 4/5，其余满分；错误映射 3/4、指数退避 3/4、尝试上限 3/3、不可重试 3/3、可验证性 1/1。其余评分项各子项满分。

## 环境、启动与配置差异

1. `git clone https://github.com/JeromyFarkas/myAI.git /tmp/parker-eval/myAI` 成功；无需只读替代获取。`student-source.tar` 包含全部跟踪文件（含 README、依赖锁、CI、脚本）。
2. 按 README：`python3 -m venv .venv`、`.venv/bin/pip install -e '.[test]'`、`cp .env.example .env`。安装日志与实际依赖分别为 `install.log`、`dependencies.txt`。复制的 .env 未填真实凭据。
3. 用原入口 `uvicorn gateway.main:app` 在回环端口 8316 启动，独立 SQLite；`GET /health` 实际返回 `{"status":"ok"}`。与 README 仅端口、独立路径及供应商环境配置不同，服务受 orb supervisor 管理。
4. 原配置：responses-model→`https://api.openai.com/v1`、gpt-4.1-mini；messages-model→`https://api.anthropic.com/v1`、claude-sonnet-4-5。原示例密钥均为空，未向这两个供应商发请求。
5. 主真实配置：responses-model→`https://api.deepseek.com`、deepseek-v4-pro；messages-model→`https://api.deepseek.com/anthropic/v1`、deepseek-flash。密钥只读已有环境变量。真实调用脚本使用原 create_app 与独立 Model 配置，不转换或改写业务请求。
6. 补测配置：Responses 改映射 deepseek-flash，Messages 另测 deepseek-v4-pro。Flash 在两协议均成功，但不冒充两个不同实际模型均通过。`real_bounded.py` 每项设教师侧 45 秒墙钟期限；达到期限是未验证，不是学生超时缺陷。
7. 主脚本 `real_checks.py` 用响应钩子读取非流式响应以记录上游 ID/用量；流式不预读，真实 TTFT 取学生记录。此钩子的读失败可能进入发送重试，因此不使用其实际次数判重试分。补测采用透明流 tee，不预读；其 gzip 原始响应误按 UTF-8 展示的文本仅作诊断，不用于 JSON 结论，成功依据为网关解析结果及指标。
8. 教师异常服务器端口 8317 通过学生公开 create_app 注入 MockTransport、独立数据库与模型 rpm；仅替换上游数据，不改解析、重试、校验、记录或限流逻辑。SSE 门控经真实 HTTP 客户端，不使用会缓冲整个响应的 TestClient 判定增量。

## A01–A04 / F01–F12 结果

| 编号 | 结果 | 可复现证据与范围 |
| --- | --- | --- |
| A01 | 通过 | README 安装成功，原入口启动、health=ok；install.log、startup-check.json。 |
| A02 | 部分通过/未验证 | 两协议各完成 Flash 真实普通与 JSON 调用；Pro 未获得有效成功响应，两个不同实际模型成功不能确认。详见真实调用表。 |
| A03 | 通过 | 教师审计捕获 `/v1/responses` input/max_output_tokens/text.format/Bearer，与 `/v1/messages` messages/system/max_tokens/x-api-key；分别解析 Responses output/事件与 Messages content/事件。真实路径分别 `/responses` 和 `/anthropic/v1/messages`。 |
| A04 | 通过 | absent→404 MODEL_NOT_FOUND，没有默认模型上游请求。teacher-results.json。 |
| F01 | 受控通过，真实未验证 | gate-responses 与 gate-messages：先心跳，80ms 后正文；下游收到正文才发 release，随后才能发送终态。两协议均 done，TTFT 非心跳时间。真实流未成功完成。 |
| F02 | 受控通过 | 两协议输出正文后模拟 ReadError：delta→error、无 done，上游次数均 1；teacher-results.json、teacher-upstream-audit.json。 |
| F03 | 通过（含状态映射缺陷） | 两协议教师 json_schema 合法结果 parsed={ok:yes}；官方 Flash 两协议 json_object 成功。上游格式拒绝 400→502，D2 仅在错误项扣。 |
| F04 | 通过 | 双协议 × 普通/流式 × 非法/空/截断/Schema 类型错误；普通 INVALID_OUTPUT 502，流式 error 无 done。不含修复机制，故不额外要求修复路径。 |
| F05 | 通过 | 保存 v1=OLD {{name}}、v2=NEW {{name}}，更新后分别引用；审计上游确为 OLD Park、NEW Park；不可覆盖由学生脚本验证。 |
| F06 | 通过 | 不存在模板/版本→404，缺变量→422 MISSING_VARIABLE；未将占位符发往上游。 |
| F07 | 部分通过 | 37 条教师记录含成功失败及请求 ID、attempts、分类、总延迟；门控流 TTFT≥80ms，普通为空。成功已知 input=17/output=5/cache=3/推理=2，但总量 22 丢失（D1）。 |
| F08 | 部分通过 | HTTP 503 前两次失败→第 3 次成功，间隔约 0.293/0.530s；连接错误间隔约 0.253/0.502s。精确 sleep 观察证实抖动超本轮上界（D3）。 |
| F09 | 通过（次数及不可重试范围） | 持续 503 实收 4 次；两协议确定性补测均 4 次。401、400 各 1 次。使用 httpx，无模型 SDK；默认 HTTPTransport 无额外自动重试，不存在 SDK 层叠加。400 状态问题见 D2。 |
| F10 | 通过 | A=responses-limit rpm1：200、429 RATE_LIMITED；B=messages-limit 独立 rpm1：200。 |
| F11 | 通过 | 未注入时钟，实际等待 60.1s 后 A 再次 200；teacher.log。 |
| F12 | 通过 | `./scripts/verify.sh`：14 passed；教师 pytest 插件替换上游为 503 后运行原脚本，assert 502==200 清晰失败，退出 1。不是修改学生脚本或业务源码制造结果。 |

`teacher-results.json` 的 F08/F09 retry-http “passed”指最终状态与次数断言通过，不包含等待上界；该上界的正式结论来自 `retry-probe.json` 的 within_caps=false，不把前者混称完全通过。

## 扣分问题与固定源码行号

以下行号均基于固定提交，不是教师脚本行号。复现均在 `/tmp/parker-eval/myAI`，环境为本次安装依赖；归档 README 给出启动与完整命令。

### D1：总 Token 用量未记录（可观测性，扣 1 分）

- 触发：上游 Responses 明确返回 input_tokens=17、output_tokens=5、total_tokens=22，以及缓存/推理子类。
- 期望：调用记录可查询总量 22，并保留分类，避免将缓存/推理再次相加。
- 实际：统一响应与 `/v1/metrics` 只含 input/output/cached/cache_creation/reasoning 五项，无 total_tokens。
- 固定源码：`gateway/adapters.py:72–77`，usage() 构造时丢弃总量；`gateway/app.py:221、255` 使用同一构造结果。
- 复现命令：先按归档 README 启动 teacher_server，再 `PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/teacher_checks.py`。
- 证据：teacher-results.json → F07:total-tokens（passed=false）；teacher-metrics.json；A03/F03 responses 捕获上游 total_tokens=22。两协议同根因仅扣一次。

### D2：上游格式拒绝被映射成服务故障（统一错误与重试，扣 1 分）

- 触发：统一 response_format 请求 json_schema，上游返回 400（unsupported json_schema）。
- 期望：统一错误体且为明确 4xx，或合法降级；不将不可支持的格式误报成服务端故障。
- 实际：HTTP 502，`{"error":{"code":"UPSTREAM_ERROR","message":"Provider rejected request"}}`；上游仅请求一次，不存在此错误重复请求。
- 固定源码：`gateway/app.py:189–193`，除 429 外全部上游错误强制 502。
- 复现命令：教师服务器运行时，`curl -s -i http://127.0.0.1:8317/v1/generate -H 'Content-Type: application/json' -d '{"model":"responses","messages":[{"role":"user","content":"bad400-schema"}],"response_format":{"type":"json_schema","schema":{"type":"object"}}}'`。
- 证据：teacher-results.json → F08/F09:bad400-schema；真实 Pro json_object 也见上游 400、网关 502，但不据该环境能力差异追加扣分。结构化评分不再次扣同根因。

### D3：HTTP 抖动超过本轮指数上界（统一错误与重试，扣 1 分）

- 触发：默认 retry_base=0.25，持续 503，固定 random.seed(0)；教师仅观察 sleep 参数且照常执行原等待。
- 期望：评分标准 F08 的本轮上界依次 0.25、0.5、1 秒，抖动应在本轮上界内。
- 实际：两协议精确等待均为 0.2844421852、0.5515908806、0.9682286323 秒；前两项超界。仍按指数增长且只有四次实际请求，因此只扣此子项 1 分，不扣尝试上限。
- 固定源码：`gateway/app.py:184–188`，`random.uniform(0.8,1.2)` 可将本轮等待放大到 1.2 倍；网络错误等待 `195–198` 正常。
- 复现命令：`PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/retry_probe.py`。
- 证据：retry-probe.json → requested_waits、rubric_caps、within_caps=false；actual_requests=4，metrics.attempts=4。观察器按调用文件过滤框架零秒让出调度，未将其当成重试等待。

## 真实调用记录

所有网络模型调用仅至 `api.deepseek.com`，未向 OpenAI、Anthropic 或第三方转发。下面 request_id 为官方 `x-ds-trace-id`，不是自行虚构；另在 JSON 保留成功上游 body.id、学生 gateway id。延迟单位 ms；输入/输出为学生可见成功用量，不包括无法确认的失败尝试，未知用量写未知，不能把日志的默认 0 当真实计费。

### 主配置（real-responses-results.json / real-messages-results.json）

| 协议/实际模型/模式 | 结果 | 官方 request_id（末次） | 输入/输出；推理 | 学生总延迟 / TTFT |
| --- | --- | --- | --- | --- |
| Responses / deepseek-v4-pro / 普通 | 上游 200 但 JSON null，学生适配器 AttributeError；无有效模型成功 | 65a056c6981f8b8c01ca5d6ca3899129 | 未知 | 未记录；教师耗时 33496.571 / 未知 |
| Responses / deepseek-v4-pro / 流式 | HTTP200、SSE error UPSTREAM_TRUNCATED，无 done | ee802f46367948b70bc9391cd13ec421 | 未知 | 33671.254 / null |
| Responses / deepseek-v4-pro / JSON | 上游400→网关502 | 75ff4503fa57a8d561898abfef9a654b | 未知 | 271.425 / null |
| Responses / deepseek-v4-pro / 模板 | 上游200 JSON null、AttributeError | 69115053dc1359f6eb64ce70dcbac7eb | 未知 | 未记录；教师耗时 38026.815 / 未知 |
| Messages / deepseek-flash / 普通 | 成功200，正文合法JSON | 1e9ff33db41f92f006d0284e7ffd7e82 | 43/20；未提供 | 861.996 / null |
| Messages / deepseek-flash / 流式 | 未成功，status=error，无有效首正文 | e260c2c22774a540b9c67409e8bf7fad | 仅已知输入43，输出未知 | 102939.892 / null |
| Messages / deepseek-flash / JSON | 成功200、parsed合法；第3次成功 | 0cf31838bcf6502f5b4d41f80ac45457 | 50/21；未提供 | 32232.482 / null |
| Messages / deepseek-flash / 模板 | 成功200；第4次成功 | e3d8075ba9c7ca3e21b062753d1b27fc | 43/16；未提供 | 48066.008 / null |

普通 Messages 的上游 body.id 为 `ecc15c8e-d55b-4c97-bd11-8837ec6ed5ce`；学生 id 为 `f073e68d-46f3-438a-b45e-2ab87635a797`。JSON 和模板上游 body.id 分别为 `0a924dda-f576-491c-a4c9-282e7db09a07`、`9def6328-264f-4621-9a8a-4eb7b98c6543`。主脚本各次失败重试的官方 trace 与 HTTP500 均保留在 JSON，不隐去失败仅报告最后成功。

### 补测配置（real-bounded-results.json）

| 协议/模型/模式 | 结果 | 官方 request_id（末次） | 输入/输出；推理 | 学生总延迟 / TTFT |
| --- | --- | --- | --- | --- |
| Responses / deepseek-flash / 普通 | 成功200，第3次成功 | 21cae259ae2e9ea0bb3d8db1948b77a8 | 40/20；14 | 33477.340 / null |
| Responses / deepseek-flash / JSON | 成功200，parsed合法，第2次成功 | 0fe546ce480aad808af6c1e8cd07ab63 | 62/20；14 | 16317.078 / null |
| Responses / deepseek-flash / 流式 | 教师45秒期限取消，未验证成功 | bf2abeb93af6dcf7e47101c5f7b30e56 | 未知 | 44931.723，cancelled / null |
| Messages / deepseek-flash / JSON | 成功200，parsed合法，第2次成功 | 153579b6ca46afa882da4f49049a9ea3 | 47/30；未提供 | 16482.260 / null |
| Messages / deepseek-flash / 模板 | 成功200，第3次成功 | 610dafd7894c90da515c1fb376d3e46f | 37/15；未提供 | 39504.850 / null |
| Messages / deepseek-v4-pro / 普通 | 45秒取消，未获得成功正文 | 5a2726af64354afbd13d6125d50d8656 | 未知 | 教师45002.249；学生记录未形成 / 未知 |

以上补测均没有为通过而注入正文、关闭推理、修改协议或绕过校验；仅使用独立配置映射模型。主配置 Pro 的 null 和补测取消时未形成记录属于观察到的健壮性现象，本次未据上游异常额外扩展扣分。原供应商凭据缺失且禁止请求该供应商，因此原 gpt/claude 模型未验证。

## 未验证、补交与最终检查

- 未验证：Pro 有效成功调用；两种不同实际模型均成功的完整前提；真实 SSE 正文增量与成功终态；原 OpenAI/Anthropic 模型。受控 SSE/异常用例只证明本地实现，不替代这些证据。
- 必须修复：D1 总用量、D2 状态映射、D3 等待上界；分别以已知用量、上游格式400、固定种子与实际请求数复验。不得为修复而重复扣已关联的分项。
- 必须补证：上游可用时两个实际模型的普通/流式成功，附官方 request_id、正文/终态、已知分类用量、总延迟与首正文 TTFT。不是要求 Redis、分布式、更多协议或额外 JSON 修复机制。
- 证据归档不含 .env、真实凭据或服务进程环境；actual-key-scan 逐文件及嵌套 tar 内容比对实际环境密钥，结果见 final-checks.json。
- 学生源码摘要及工作树未修改检查、服务健康检查、评分合计、反馈格式和评测服务停止状态均留在 evidence 包。最终服务只停止本次 parker-real、parker-teacher，不影响其他工作。
