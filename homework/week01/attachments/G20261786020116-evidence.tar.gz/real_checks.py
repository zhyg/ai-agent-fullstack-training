"""Only DeepSeek official may receive network traffic. No credentials are logged."""
import json
import os
import time
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from gateway.app import create_app, Model

traces=[]
async def trace(response):
    assert response.request.url.host=='api.deepseek.com'
    body=json.loads(response.request.content)
    entry={'url':str(response.request.url),'request':body,'http_status':response.status_code,
           'request_id_headers':{k:v for k,v in response.headers.items() if 'request-id' in k or 'trace-id' in k}}
    traces.append(entry)
    if not body.get('stream'):
        await response.aread()
        try:
            raw=response.json()
            if isinstance(raw, dict):
                entry['upstream_id']=raw.get('id')
                entry['upstream_model']=raw.get('model')
                entry['usage']=raw.get('usage')
                entry['stop']=raw.get('stop_reason',raw.get('status'))
            else:
                entry['body_parse']=type(raw).__name__
        except ValueError:
            entry['body_parse']='not-json'

key=os.environ['DEEPSEEK_API_KEY']
models={'responses-model':Model('responses','https://api.deepseek.com',key,'deepseek-v4-pro'),
        'messages-model':Model('messages','https://api.deepseek.com/anthropic/v1',key,'deepseek-flash')}
protocol=os.environ['REAL_PROTOCOL']
client=httpx.AsyncClient(timeout=60,event_hooks={'response':[trace]})
results=[]
with TestClient(create_app(models,'/tmp/parker-eval/real-'+protocol+'.sqlite',client)) as c:
    for p in [protocol+'-model']:
        for mode in ('normal','stream','json','template'):
            payload={'model':p,'messages':[{'role':'user','content':'Reply only with {"ok":"yes"}. Do not explain.'}],'max_tokens':2048}
            if mode=='stream': payload['stream']=True
            if mode=='json': payload['response_format']={'type':'json_object'}
            if mode=='template':
                c.put('/v1/prompts/real/v1',json={'content':'Reply only with {{answer}}. Do not explain.'})
                payload.pop('messages')
                payload['prompt']={'name':'real','version':'v1','variables':{'answer':'{"ok":"yes"}'}}
            start=time.monotonic()
            try:
                r=c.post('/v1/generate',json=payload)
                metric=c.get('/v1/metrics').json()['calls'][0]
                results.append({'alias':p,'mode':mode,'http_status':r.status_code,'elapsed_ms':round((time.monotonic()-start)*1000,3),'body':r.text,'metric':metric})
                print(p,mode,r.status_code,'metric',json.dumps(metric),flush=True)
            except Exception as exc:
                results.append({'alias':p,'mode':mode,'error_type':type(exc).__name__,'elapsed_ms':round((time.monotonic()-start)*1000,3)})
                print(p,mode,type(exc).__name__,flush=True)
            Path('/tmp/parker-eval/evidence/real-'+protocol+'-results.json').write_text(json.dumps({'traces':traces,'results':results},indent=2,ensure_ascii=False))
