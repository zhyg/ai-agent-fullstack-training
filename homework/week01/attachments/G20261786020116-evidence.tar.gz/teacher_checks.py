import json
import time
from pathlib import Path
import httpx

BASE = 'http://127.0.0.1:8317'
c = httpx.Client(base_url=BASE, timeout=90)
results = []

def note(case, ok, **data):
    results.append(dict(case=case, passed=bool(ok), **data))
    Path('/tmp/parker-eval/evidence/teacher-results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False))
    print(case, 'PASS' if ok else 'FINDING', json.dumps(data, ensure_ascii=False), flush=True)

def call(model, scenario, **kw):
    return c.post('/v1/generate', json={'model':model,'messages':[{'role':'user','content':scenario}], **kw})

def audit(scenario):
    return [a for a in c.get('/teacher/audit').json() if a['scenario']==scenario]

schema={'type':'object','properties':{'ok':{'type':'string'}},'required':['ok']}
for p in ('responses','messages'):
    r=call(p,'normal:'+p,response_format={'type':'json_schema','schema':schema})
    a=audit('normal:'+p)[0]
    expected_path='/v1/'+p
    mapping = a['body'].get('text',{}).get('format',{}).get('schema')==schema if p=='responses' else 'JSON Schema' in a['body']['system']
    note('A03/F03:'+p,r.status_code==200 and r.json()['parsed']=={'ok':'yes'} and a['path']==expected_path and mapping,response=r.json(),upstream=a)
    for kind in ('invalid','empty','truncated','schema'):
        for stream in (False,True):
            r=call(p,kind+':'+p,response_format={'type':'json_schema','schema':schema},stream=stream)
            ok = ('event: error' in r.text and 'event: done' not in r.text) if stream else r.status_code==502 and r.json()['error']['code']=='INVALID_OUTPUT'
            note('F04:'+p+':'+kind+':'+str(stream),ok,status=r.status_code,body=r.text)
    # The terminator is not released until the real HTTP client observes a delta.
    scenario='gate-'+p
    t=time.monotonic()
    with c.stream('POST','/v1/generate',json={'model':p,'messages':[{'role':'user','content':scenario}],'stream':True}) as r:
        chunks=[]
        observed=False
        for line in r.iter_lines():
            chunks.append(line)
            if line.startswith('data:') and '"text"' in line and not observed:
                observed=True
                delta_ms=(time.monotonic()-t)*1000
                assert not any('event: done' in x for x in chunks)
                c.post('/teacher/release/'+scenario)
        note('F01:gate:'+p,observed and 'event: done' in chunks,delta_ms=delta_ms,body='\n'.join(chunks))
    scenario='interrupt-'+p
    r=call(p,scenario,stream=True)
    note('F02:'+p,'event: delta' in r.text and 'event: error' in r.text and 'event: done' not in r.text and len(audit(scenario))==1,attempts=len(audit(scenario)),body=r.text)

r=call('absent','unknown')
note('A04',r.status_code==404 and r.json()['error']['code']=='MODEL_NOT_FOUND',response=r.json())
for version,content in [('v1','OLD {{name}}'),('v2','NEW {{name}}')]:
    assert c.put('/v1/prompts/teacher/'+version,json={'content':content}).status_code==201
for v in ('v1','v2'):
    r=c.post('/v1/generate',json={'model':'responses','prompt':{'name':'teacher','version':v,'variables':{'name':'Park'}}})
    expected=('OLD' if v=='v1' else 'NEW')+' Park'
    note('F05:'+v,r.status_code==200 and bool(audit(expected)),upstream=audit(expected))
for name,v,variables,status in [('absent','v1',{},404),('teacher','absent',{},404),('teacher','v1',{},422)]:
    r=c.post('/v1/generate',json={'model':'responses','prompt':{'name':name,'version':v,'variables':variables}})
    note('F06:'+name+':'+v,r.status_code==status,status=r.status_code,response=r.json())
for scenario,expected,n in [('retry-http',200,3),('network-two',200,3),('always503-teacher',502,4),('auth401-teacher',502,1),('bad400-schema',400,1)]:
    r=call('responses',scenario,response_format={'type':'json_schema','schema':schema})
    a=audit(scenario)
    waits=[round(a[i+1]['at']-a[i]['at'],4) for i in range(len(a)-1)]
    note('F08/F09:'+scenario,r.status_code==expected and len(a)==n,status=r.status_code,attempts=len(a),intervals_s=waits,response=r.json())
# Actual 60-second sliding-window recovery, not a patched clock.
r1=call('responses-limit','limit-A-first'); r2=call('responses-limit','limit-A-second'); rb=call('messages-limit','limit-B')
note('F10',r1.status_code==200 and r2.status_code==429 and rb.status_code==200,statuses=[r1.status_code,r2.status_code,rb.status_code],error=r2.json())
print('Waiting actual 60.1s window',flush=True)
time.sleep(60.1)
r=call('responses-limit','limit-A-recovered')
note('F11',r.status_code==200,status=r.status_code)
records=c.get('/v1/metrics').json()['calls']
Path('/tmp/parker-eval/evidence/teacher-metrics.json').write_text(json.dumps(records,indent=2))
note('F07:failure-and-ttft',any(x['status']=='error' and x['attempts']==1 for x in records) and any(x['first_token_ms'] is not None and x['first_token_ms']>=75 for x in records),records=len(records))
note('F07:total-tokens',all('total_tokens' in x['usage'] for x in records),sample=records[-1])
Path('/tmp/parker-eval/evidence/teacher-upstream-audit.json').write_text(json.dumps(c.get('/teacher/audit').json(),indent=2))
