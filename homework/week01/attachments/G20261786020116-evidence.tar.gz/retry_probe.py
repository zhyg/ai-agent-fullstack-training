"""Observe requested sleeps without skipping or changing them; fixed RNG seed."""
import asyncio
import inspect
import json
import random
from unittest.mock import patch
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from gateway.app import Model, create_app

original_sleep=asyncio.sleep
results=[]
for protocol in ('responses','messages'):
    waits=[]
    requests=[]
    async def observe(delay):
        caller=inspect.currentframe().f_back
        if caller.f_code.co_filename.endswith('/gateway/app.py'):
            waits.append(delay)
        await original_sleep(delay)
    def handler(req):
        requests.append({'url':str(req.url),'body':json.loads(req.content)})
        return httpx.Response(503)
    random.seed(0)
    app=create_app({'A':Model(protocol,'https://teacher.invalid/v1','dummy','fixture')}, ':memory:',
                   httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    with patch('gateway.app.asyncio.sleep',observe), TestClient(app) as c:
        r=c.post('/v1/generate',json={'model':'A','messages':[{'role':'user','content':'fail'}]})
        metric=c.get('/v1/metrics').json()['calls'][0]
    caps=[.25,.5,1.0]
    entry={'protocol':protocol,'status':r.status_code,'actual_requests':len(requests),'metric':metric,
           'requested_waits':waits,'rubric_caps':caps,'within_caps':all(w<=cap for w,cap in zip(waits,caps)),
           'requests':requests,'sdk':'No model SDK; httpx MockTransport receives each actual send, no inner retries'}
    results.append(entry)
    print(json.dumps(entry),flush=True)
Path('/tmp/parker-eval/evidence/retry-probe.json').write_text(json.dumps(results,indent=2))
