"""Bounded diagnostic: unchanged app, transparent response tee, 45s wall clock/call."""
import asyncio
import json
import os
import time
from pathlib import Path
import httpx
from gateway.app import Model, create_app

OUT=Path('/tmp/parker-eval/evidence/real-bounded-results.json')
traces=[]
results=[]
key=os.environ['DEEPSEEK_API_KEY']
def save():
    text=json.dumps({'traces':traces,'results':results},ensure_ascii=False,indent=2)
    OUT.write_text(text.replace(key,'[REDACTED]'))

class Tee(httpx.AsyncByteStream):
    def __init__(self, source, entry):
        self.source,self.entry=source,entry
    async def __aiter__(self):
        data=[]
        try:
            async for b in self.source:
                data.append(b)
                yield b
        finally:
            self.entry['response_body']=b''.join(data).decode(errors='replace')
            save()
    async def aclose(self):
        await self.source.aclose()

async def hook(r):
    entry={'url':str(r.request.url),'body':json.loads(r.request.content),'http_status':r.status_code,
           'request_ids':{k:v for k,v in r.headers.items() if 'trace-id' in k or 'request-id' in k}}
    traces.append(entry)
    r.stream=Tee(r.stream,entry)
    save()

async def run(protocol,model,mode):
    alias=protocol+'-'+model+'-'+mode
    upstream=httpx.AsyncClient(timeout=60,event_hooks={'response':[hook]})
    url='https://api.deepseek.com' if protocol=='responses' else 'https://api.deepseek.com/anthropic/v1'
    app=create_app({alias:Model(protocol,url,key,model)},':memory:',upstream)
    c=httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://teacher-local')
    payload={'model':alias,'messages':[{'role':'user','content':'Return only this JSON: {"ok":"yes"}'}],'max_tokens':1024}
    if mode=='stream': payload['stream']=True
    if mode=='json': payload['response_format']={'type':'json_object'}
    if mode=='template':
        await c.put('/v1/prompts/check/v1',json={'content':'Return only {{answer}}'})
        payload.pop('messages')
        payload['prompt']={'name':'check','version':'v1','variables':{'answer':'{"ok":"yes"}'}}
    start=time.monotonic()
    entry={'protocol':protocol,'upstream_model':model,'mode':mode,'limit_s':45}
    try:
        r=await asyncio.wait_for(c.post('/v1/generate',json=payload),45)
        entry.update(http_status=r.status_code,body=r.text)
    except TimeoutError:
        entry['outcome']='UNVERIFIED: 45s wall-clock deadline; upstream cancelled'
    except Exception as exc:
        entry['error_type']=type(exc).__name__
    entry['elapsed_ms']=round((time.monotonic()-start)*1000,3)
    entry['metrics']=(await c.get('/v1/metrics')).json()['calls']
    results.append(entry)
    save()
    print(json.dumps(entry,ensure_ascii=False),flush=True)
    await c.aclose()
    await upstream.aclose()
    app.state.store.db.close()

async def main():
    await asyncio.gather(*(run(p,m,mode) for p,m,mode in [
        ('messages','deepseek-flash','json'),('messages','deepseek-flash','template'),
        ('responses','deepseek-flash','normal'),('responses','deepseek-flash','stream'),
        ('responses','deepseek-flash','json'),('messages','deepseek-v4-pro','normal')]))

asyncio.run(main())
