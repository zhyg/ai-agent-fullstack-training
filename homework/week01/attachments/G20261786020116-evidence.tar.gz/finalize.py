"""Validate grading outputs, fixed source, stopped services and secret-free archive."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tarfile

ROOT=Path('/home/user/workspace/repo')
E=Path('/tmp/parker-eval/evidence')
STUDENT=Path('/tmp/parker-eval/myAI')
feedback=ROOT/'homework/week01/G20261786020116.md'
assessment=ROOT/'homework/week01/attachments/G20261786020116.md'
archive=assessment.with_name('G20261786020116-evidence.tar.gz')
f=feedback.read_text()
a=assessment.read_text()
checks={}
checks['scores']=[int(x) for x in re.findall(r'^\| (?:统一接口与适配器|流式输出|结构化输出|提示词版本管理|可观测性|统一错误与重试|按模型独立限流|源码、README 与验证脚本) \| (\d+)/\d+ \|',a,re.M)]
assert len(checks['scores'])==8 and sum(checks['scores'])==97
checks['score_sum']=97
assert '作业等级：优秀（97分）' in f and '暂评' in f
sections=re.split(r'\*\*[234]\. [^\n]+\*\*\n',f)[1:]
assert len(sections)==3
checks['feedback_sections']=[]
for section in sections:
    lines=[x for x in section.splitlines() if x.startswith('- ')]
    length=sum(len(x[2:]) for x in lines)
    assert 3<=len(lines)<=5 and length<=500
    assert section.startswith('\n')
    checks['feedback_sections'].append({'bullets':len(lines),'characters':length})
checks['fixed_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=STUDENT,text=True).strip()
assert checks['fixed_commit']=='592ab1ab5148b397ab9ec11a0d08ac70760021bf'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=STUDENT)
checks['student_worktree_unchanged']=True
with tarfile.open(E/'student-source.tar') as tf:
    for member in tf.getmembers():
        if member.isfile():
            assert tf.extractfile(member).read()==(STUDENT/member.name).read_bytes()
checks['complete_snapshot_matches_worktree']=True
for port in (8316,8317):
    with socket.socket() as s:
        s.settimeout(.5)
        assert s.connect_ex(('127.0.0.1',port))!=0
checks['evaluation_ports_closed']=[8316,8317]
assert 'No orb services are running.' in (E/'services-after.txt').read_text()
checks['evaluation_services_stopped']=True
key=os.environ['DEEPSEEK_API_KEY'].encode()
assert key
scanned=[]
def scan(data,name):
    assert key not in data, 'Actual key detected in '+name
    scanned.append(name)
    if name.endswith('.tar'):
        with tarfile.open(fileobj=io.BytesIO(data)) as tf:
            for m in tf.getmembers():
                if m.isfile(): scan(tf.extractfile(m).read(),name+'/'+m.name)

(E/'feedback.md').write_text(f)
(E/'assessment.md').write_text(a)
for p in E.iterdir():
    if p.is_file(): scan(p.read_bytes(),p.name)
checks['actual_key_scan']='PASS: exact secret absent, including nested source tar and reports'
checks['scanned_file_count']=len(scanned)
checks['no_env_file_archived']=True
checks['archive_name']=archive.name
(E/'final-checks.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False))
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(E.iterdir()):
        if p.is_file():
            assert p.name!='.env'
            tf.add(p,arcname=p.name)
with tarfile.open(archive) as tf:
    for m in tf.getmembers():
        if m.isfile(): scan(tf.extractfile(m).read(),m.name)
print(json.dumps(checks,ensure_ascii=False,indent=2))
print('archive_sha256',hashlib.sha256(archive.read_bytes()).hexdigest())
