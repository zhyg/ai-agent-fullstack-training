# G20261786020116 独立评测证据

固定提交：592ab1ab5148b397ab9ec11a0d08ac70760021bf，main，仓库根目录。完整跟踪源码见 student-source.tar；未包含 .git/.venv/.env/运行数据库或凭据。全部学生业务源码未改动。

## 安装与复现

本次使用路径 /tmp/parker-eval/myAI 与 /tmp/parker-eval/evidence；脚本写结果的路径固定在后者。将本包解开到后者，student-source.tar 解到前者，即可使用相同命令。

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[test]'
cp .env.example .env
./scripts/verify.sh
```

原 README 启动入口在8316、独立数据库，按 Model 环境配置替换为 DeepSeek 官方。凭据仅从 DEEPSEEK_API_KEY 环境读取，不在本包内。

教师受控服务器与检查（不用任何真实密钥，所有请求由 MockTransport 返回）：

```bash
amp orb service start parker-teacher --command 'env PYTHONPATH=/tmp/parker-eval/myAI:/tmp/parker-eval/evidence /tmp/parker-eval/myAI/.venv/bin/uvicorn teacher_server:app --host 127.0.0.1 --port 8317' --port 8317
PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/teacher_checks.py
PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/retry_probe.py
PYTHONPATH=/tmp/parker-eval/evidence:/tmp/parker-eval/myAI PYTEST_ADDOPTS='-p forced_failure -x -k test_protocols' ./scripts/verify.sh
```

第二个检查会实际等待60.1秒。最后的原学生脚本应故意失败并退出1，不是正常评分脚本失败。复跑前停止旧教师服务并清除教师 SQLite 可避免固定模板版本的重复创建冲突；仅清理本评测可丢弃数据。

真实脚本（会产生少量真实调用费用，仅请求 DeepSeek 官方）：

```bash
REAL_PROTOCOL=responses PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/real_checks.py
REAL_PROTOCOL=messages PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/real_checks.py
PYTHONPATH=/tmp/parker-eval/myAI .venv/bin/python /tmp/parker-eval/evidence/real_bounded.py
```

主配置 Responses→Pro，Messages→Flash；补测 Responses→Flash，Messages→Pro（另保留Flash的JSON/模板控制）。main原入口默认OpenAI/Anthropic配置未发真实请求。完整差异、限制、请求ID与用量在内部评测附件。

## 结果索引

- student-tests.log：原脚本14 passed；student-forced-failure.log：故障注入后清晰失败，exit_code=1。
- teacher-results.json、teacher.log、teacher-upstream-audit.json、teacher-metrics.json：A/F逐项受控观测，门控SSE通过真实HTTP读取。
- retry-probe.json/log：固定种子、准确sleep实参（仍实际等待）、双协议实收四次；within_caps=false为扣分证据。
- real-responses-results.json、real-messages-results.json 与对应日志：主配置实际结果、官方trace-id、上游body.id及已知用量。
- real-bounded-results.json/log：45秒教师期限下的透明tee补测；其 response_body 是gzip原始字节的错误UTF-8展示，不将该字段用于JSON内容判定；以results.body、metrics、HTTP状态及trace-id为有效证据。
- real.log：最初诊断脚本钩子遇null的异常，已由主脚本健壮捕获及后续结果取代，不作为额外评分依据。
- install.log、dependencies.txt、startup-check.json、source-integrity.txt、final-checks.json：安装、启动、固定源码、格式/合计/实际密钥扫描及停止服务检查。

## 判分摘要

97分暂评、优秀、证据不完整。三项独立扣分：总Token缺字段1分、上游400映射502扣1分、重试抖动越指数上界1分。Pro与真实SSE未成功不因环境扣代码分。两协议同为Flash的真实成功不能冒充两个不同实际模型均成功。
