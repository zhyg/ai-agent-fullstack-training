# 固定提交复验说明

本归档是评测证据，不是修复后的项目。业务源码来自固定提交，配置、受控上游和探测脚本是教师侧独立文件。仅默认内置模拟与独立受控上游的结果不能替代真实模型接入证据。

## 安装与默认脚本

1. `git clone https://gitee.com/beyondor/my-mini-llm-gateway.git student`
2. `git -C student checkout --detach 235eb491b239bffe856932e92951986c3d6b6a56`
3. 安装官方 Temurin JDK17：https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse 。本次解压到 `/tmp/jdk17`。
4. 安装官方 PowerShell Linux x64 7.7.0：https://github.com/PowerShell/PowerShell/releases/download/v7.7.0/powershell-7.7.0-linux-x64.tar.gz 。本次解压到 `/tmp/pwsh`，使 pwsh 可执行。
5. 在 student 中运行 `JAVA_HOME=/tmp/jdk17 PATH=/tmp/jdk17/bin:$PATH sh ./mvnw -DskipTests package`。
6. 使用 orb supervised service 启动 `/tmp/jdk17/bin/java -jar <student绝对路径>/target/my-mini-llm-gateway-1.0.0.jar`，端口8080。
7. 在 student 中运行 `/tmp/pwsh/pwsh -NoProfile -File test/verify.ps1`，实际 exit=0，10/10通过，详见 verify-default.log。

## 独立受控验证

1. 将本归档解压至单独目录，以下命令在该目录执行。上游18081、受控网关18080互不混用默认8080服务。
2. 使用 supervised service 启动 `python <本目录绝对路径>/upstream.py`，端口18081。
3. 使用 supervised service 启动 `/tmp/jdk17/bin/java -jar <student绝对路径>/target/my-mini-llm-gateway-1.0.0.jar --spring.config.additional-location=file:<本目录绝对路径>/controlled.properties`，端口18080。
4. 服务启动后执行 `python probe.py > controlled-run.log 2>&1`，随后 `python checks.py > assertions.log`。
5. probe.py 的 case 名与报告对应；重试实际计数来自 upstream.jsonl，而不是 gateway.attempts。时间来自上游收到请求的 monotonic timestamp，0.5/1秒以外的小量开销为HTTP处理时间。
6. 门控先发中文正文再等待 release；客户端必须看到非空正文才发 `/release`。gates.jsonl 的 released=true 排除等8秒超时后伪通过。
7. 制造学生脚本失败：向 `http://127.0.0.1:18081/control` POST `{"text":""}`，然后 `/tmp/pwsh/pwsh -NoProfile -File <student绝对路径>/test/verify.ps1 -BaseUrl http://127.0.0.1:18080`。实际两个普通调用 FAIL，流式空文本仍 PASS，结构化502使脚本exit=1。完成后向 /control POST `{}` 恢复。
8. 归档中的历史 JSONL 供复核。重新运行会追加 JSONL，请先把历史数据复制到另一目录保留，或在全新解压目录运行；不要把新运行结果覆盖唯一历史副本。

## 真实调用

1. 只在私密进程环境中设置 secret `DEEPSEEK_API_KEY`，不要把值写进 properties、命令参数、shell历史或归档。
2. 使用 supervised service 启动同一 jar，附 `--spring.config.additional-location=file:<本目录绝对路径>/real.properties`，端口8082。配置只替换别名对应的官方模型、端点、凭据来源，不改业务逻辑。
3. 运行 `python real_probe.py > real-run.log 2>&1`，每模型普通、流式、json各一次，max_tokens=768。
4. 首次Pro结构化请求因提示没有JSON单词被拒绝，故追加运行 `python json_supplement.py > real-json-run.log 2>&1`，明确写JSON单词。Pro成功，Flash仍因默认thinking与指定tool_choice冲突失败。共8次网关请求、5成功3错误，详见原始请求响应及账本。
5. 原 gpt-4o-mini 和 claude-3-5-sonnet 真实供应商配置未验证。Flash JSON不宣称通过。没有直连其他供应商，没有绕过网关添加thinking字段，没有修改业务逻辑。

## 归档与收尾

归档仅白名单收集教师脚本、无实际凭据的配置、日志、脱敏请求响应、关键源码带行号摘录、校验结果，不含.env、真实密钥、鉴权头转储、Java构建产物或整个工作目录。运行脚本的前置条件是能访问固定学员提交和安装JDK17/PowerShell。

本次四个服务在取日志后均已停止。复验结束请停止自己创建的网关和上游服务；不要停止占用其他端口的无关进程。
