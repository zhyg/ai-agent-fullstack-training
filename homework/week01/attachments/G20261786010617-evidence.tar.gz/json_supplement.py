import json,time,urllib.request,urllib.error
from pathlib import Path
results=[]
for alias in ['openai','anthropic']:
    body={'model':alias,'max_tokens':768,'messages':[{'role':'user','content':'Return a JSON object only: {"answer":"ok"}. Keep reasoning short.'}],'response_format':{'type':'json_object'}}
    req=urllib.request.Request('http://127.0.0.1:8082/v1/chat/completions',json.dumps(body).encode(),{'Content-Type':'application/json'})
    t=time.monotonic()
    try: r=urllib.request.urlopen(req,timeout=150)
    except urllib.error.HTTPError as e: r=e
    data=json.load(r)
    results.append({'alias':alias,'request':body,'http':r.status,'elapsed_s':time.monotonic()-t,'response':data})
    print(alias,r.status,json.dumps(data,ensure_ascii=False),flush=True)
Path(__file__).with_name('real-json-supplement.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
with urllib.request.urlopen('http://127.0.0.1:8082/v1/requests?limit=200') as r:
    Path(__file__).with_name('real-records.json').write_text(json.dumps(json.load(r),ensure_ascii=False,indent=2))
