"""Validate reports and build a whitelist archive without exposing secret values."""
import hashlib,json,os,re,tarfile
from pathlib import Path
root=Path(__file__).parent
repo=root.parents[3]
short=repo/'homework/week01/G20261786010617.md'
detail=repo/'homework/week01/attachments/G20261786010617.md'
target=detail.with_name('G20261786010617-evidence.tar.gz')
names=['metadata.txt','clone.log','build-summary.log','java-version.txt','powershell-version.txt','controlled.properties','real.properties','upstream.py','probe.py','checks.py','real_probe.py','json_supplement.py','controlled-run.log','controlled-results.json','upstream.jsonl','gates.jsonl','assertions.json','assertions.log','verify-default.log','verify-forced-failure.log','real-results.json','real-json-supplement.json','real-records.json','real-run.log','real-json-run.log','source-evidence.txt','reproduce.md','service-status.txt','fengjian-default.log','fengjian-controlled.log','fengjian-real.log','fengjian-upstream.log','validate_archive.py']
sections={}
text=short.read_text()
for heading in ['**2. 作业优点**','**3. 作业不足**','**4. 改进方案**']:
    section=text.split(heading)[1].split('\n**')[0].strip()
    count=sum(line.startswith('- ') for line in section.splitlines())
    assert 3<=count<=5 and len(section)<=500
    assert text.split(heading)[1].startswith('\n\n')
    sections[heading]={'items':count,'characters_including_markup':len(section)}
assert all(s not in text for s in ['扣分','评分依据','验收结论：','【','】'])
body=detail.read_text()
scores=[(int(a),int(b)) for a,b in re.findall(r'^\| [^|]+ \| (\d+)/(\d+) \|',body,re.M)]
assert len(scores)==8 and sum(a for a,b in scores)==88 and sum(b for a,b in scores)==100
assert '优秀（88分）' in text and '**88/100**' in body
assert all(code in body for code in ['A01','A02','A03','A04']+[f'F{i:02}' for i in range(1,13)]+[f'D{i:02}' for i in range(1,10)])
secret_values=[v.encode() for k,v in os.environ.items() if len(v)>=12 and any(s in k.upper() for s in ['API_KEY','TOKEN','PASSWORD','PRIVATE_KEY']) and k!='AMP_SECRET_ENV_NAMES']
assert os.environ.get('DEEPSEEK_API_KEY'), 'Expected configured secret unavailable for scan'
paths=[root/n for n in names]+[short,detail]
for path in paths:
    data=path.read_bytes()
    assert not any(s in data for s in secret_values), 'Secret detected; do not print matching content'
    assert not re.search(rb'sk-[A-Za-z0-9_-]{20,}',data), 'Credential-like token detected'
    assert not re.search(rb'(?i)(authorization|x-api-key)\s*:\s*(bearer\s+)?[A-Za-z0-9_-]{12,}',data), 'Auth header value detected'
    assert path.name!='.env' and not path.name.startswith('.env.')
scan={'secret_exact_value_matches':0,'credential_pattern_matches':0,'auth_header_value_matches':0,'files_scanned':len(paths),'feedback_sections':sections,'score_sum':88,'max_score_sum':100,'all_A_F_cases_present':True,'no_env_files':True,'student_tracked_changes':0,'services_stopped':(root/'service-status.txt').read_text().strip()=='No orb services are running.'}
assert scan['services_stopped']
(root/'secret-scan.json').write_text(json.dumps(scan,ensure_ascii=False,indent=2))
names+=['secret-scan.json']
manifest=''.join(hashlib.sha256((root/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names)
(root/'SHA256SUMS').write_text(manifest)
names+=['SHA256SUMS']
with target.open('xb') as output:
    with tarfile.open(fileobj=output,mode='w:gz') as tar:
        for name in names: tar.add(root/name,arcname=name,recursive=False)
with tarfile.open(target) as tar:
    assert set(tar.getnames())==set(names)
    for member in tar:
        data=tar.extractfile(member).read()
        assert not any(s in data for s in secret_values)
print(json.dumps({'archive_files':len(names),'archive_bytes':target.stat().st_size,'format_and_score':'PASS','secret_scan':'PASS','sections':sections},ensure_ascii=False,indent=2))
