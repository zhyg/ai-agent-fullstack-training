"""Run against unmodified student jar with independent configuration."""
import json, time, threading, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18080'
def post(url, body):
    req=urllib.request.Request(url,json.dumps(body).encode(),{'Content-Type':'application/json'})
    try:
        r=urllib.request.urlopen(req,timeout=150)
    except urllib.error.HTTPError as e:
        r=e
    data=r.read().decode()
    try: data=json.loads(data)
    except ValueError: pass
    return r.status,data
def control(**kw): return post('http://127.0.0.1:18081/control',kw)
def call(model='openai',**kw):
    return post(BASE+'/v1/chat/completions',{'model':model,'messages':[{'role':'system','content':'system-check'},{'role':'user','content':'short JSON please'}],**kw})
def rows():
    p=ROOT/'upstream.jsonl'
    return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
out=[]
def save(name,status,data,extra=None):
    record={'case':name,'http':status,'response':data,'extra':extra}
    out.append(record)
    (ROOT/'controlled-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(name,status, json.dumps(extra or {},ensure_ascii=False),flush=True)
def streaming(model,mode):
    control(mode=mode,text='中文-FIRST')
    n=len(rows()); chunks=[]; start=time.monotonic(); released=None
    req=urllib.request.Request(BASE+'/v1/chat/completions',json.dumps({'model':model,'stream':True,'messages':[{'role':'user','content':'hi'}]}).encode(),{'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as r:
        for line in r:
            line=line.decode().strip()
            if not line: continue
            chunks.append({'elapsed':round(time.monotonic()-start,4),'line':line})
            if mode=='gate' and '中文-FIRST' in line and released is None:
                released=time.monotonic()-start
                post('http://127.0.0.1:18081/release',{})
    save('stream-'+model+'-'+mode,200,chunks,{'requests':len(rows())-n,'release_after_content':released})
for m in ['openai','anthropic']:
    control(); s,d=call(m); save('normal-'+m,s,d)
    for mode in ['gate','event_error','eof','empty_delta']:
        streaming(m,mode)
    fmt={'type':'json_schema','json_schema':{'name':'answer','schema':{'type':'object','properties':{'answer':{'type':'string'}},'required':['answer']}}}
    for name,text in [('valid','{"answer":"ok"}'),('invalid','not json'),('empty',''),('truncated','{"answer":'),('schema-mismatch','{"answer":12}'),('trailing','{"answer":"ok"} garbage')]:
        control(text=text,mode='truncated' if name=='truncated' else 'normal')
        s,d=call(m,response_format=fmt); save('json-'+m+'-'+name,s,d)
    for failures,status in [(2,500),(9,500),(9,429),(9,400),(9,401)]:
        control(fail=failures,status=status); n=len(rows()); s,d=call(m)
        times=[r['at'] for r in rows()[n:]]
        save('retry-'+m+'-'+str(status)+'-'+str(failures),s,d,{'actual_requests':len(times),'intervals':[round(b-a,4) for a,b in zip(times,times[1:])]})
    control(fail=1,status=400); s,d=call(m,response_format={'type':'json_schema','json_schema':{'schema':{}}}); save('unsupported-format-'+m,s,d)
control()
s,d=call('does-not-exist'); save('unknown-model',s,d)
for v in [1,2]:
    s,d=post(BASE+'/v1/prompts',{'id':'teacher','content':f'v{v} says {{{{name}}}}','variables':['name']}); save('prompt-create-'+str(v),s,d)
for m in ['openai','anthropic']:
    for v in [1,2]:
        n=len(rows()); s,d=call(m,prompt='teacher@'+str(v),variables={'name':'Alice$\\'}); save('prompt-'+m+'-'+str(v),s,d,{'upstream':rows()[n:]})
for prompt,variables in [('missing@1',{}),('teacher@99',{}),('teacher@2',{})]:
    n=len(rows()); s,d=call(prompt=prompt,variables=variables); save('prompt-missing-'+prompt,s,d,{'upstream_requests':len(rows())-n})
control(); s,d=call('throttle-demo'); save('limit-first',s,d)
s,d=call('throttle-demo'); save('limit-second',s,d)
s,d=call('anthropic'); save('limit-other-model',s,d)
time.sleep(.6); s,d=call('throttle-demo'); save('limit-restored',s,d)
time.sleep(.1)
for path in ['/v1/requests?limit=200','/v1/stats']:
    with urllib.request.urlopen(BASE+path) as r: data=json.load(r)
    save(path,200,data)
