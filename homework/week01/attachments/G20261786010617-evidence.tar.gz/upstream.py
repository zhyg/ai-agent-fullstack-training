"""Independent controlled upstream. No authentication values are read or stored."""
import json, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).parent
state = {}
gate = threading.Event()
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def reply(self, obj, status=200):
        data = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))) or b'{}')
        if self.path == '/control':
            state.clear(); state.update(body); gate.clear()
            return self.reply({'ok':True})
        if self.path == '/release':
            gate.set(); return self.reply({'ok':True})
        row = {'at':time.monotonic(), 'path':self.path,'body':body}
        with (ROOT/'upstream.jsonl').open('a') as f:
            f.write(json.dumps(row,ensure_ascii=False)+'\n')
        fail = state.get('fail',0)
        if fail:
            state['fail'] = fail-1
            return self.reply({'error':{'message':'controlled rejection'}},state.get('status',500))
        mode = state.get('mode','normal')
        text = state.get('text','{"answer":"ok"}')
        isr = self.path.endswith('/responses')
        ru = {'input_tokens':11,'output_tokens':7,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}
        au = {'input_tokens':11,'output_tokens':7,'cache_read_input_tokens':3,'cache_creation_input_tokens':2}
        if not body.get('stream'):
            if isr:
                return self.reply({'status':'incomplete' if mode=='truncated' else 'completed','output':[{'type':'message','content':[{'type':'output_text','text':text}]}], 'usage':ru})
            return self.reply({'content':[{'type':'text','text':text}],'stop_reason':'max_tokens' if mode=='truncated' else 'end_turn','usage':au})
        self.send_response(200)
        self.send_header('Content-Type','text/event-stream')
        self.end_headers()
        def event(kind, data):
            data = {'type':kind, **data}
            self.wfile.write(('event: '+kind+'\ndata: '+json.dumps(data)+'\n\n').encode()); self.wfile.flush()
        try:
            event('response.created' if isr else 'message_start',{'response':{}} if isr else {'message':{'usage':au}})
            if mode=='empty_delta':
                event('response.output_text.delta' if isr else 'content_block_delta',{'delta':''} if isr else {'delta':{'type':'text_delta','text':''}})
                time.sleep(.25)
            event('response.output_text.delta' if isr else 'content_block_delta',{'delta':text} if isr else {'delta':{'type':'text_delta','text':text}})
            if mode=='gate':
                released=gate.wait(8)
                with (ROOT/'gates.jsonl').open('a') as f:
                    f.write(json.dumps({'path':self.path,'released':released,'at':time.monotonic()})+'\n')
            if mode=='eof':
                return
            if mode=='event_error':
                event('response.failed' if isr else 'error',{'response':{'error':{'message':'controlled interruption'}}} if isr else {'error':{'message':'controlled interruption'}})
                return
            if isr:
                event('response.completed',{'response':{'usage':ru}})
            else:
                event('message_delta',{'delta':{'stop_reason':'end_turn'},'usage':au})
                event('message_stop',{})
        except (BrokenPipeError,ConnectionResetError):
            pass

ThreadingHTTPServer(('127.0.0.1',18081), Handler).serve_forever()
