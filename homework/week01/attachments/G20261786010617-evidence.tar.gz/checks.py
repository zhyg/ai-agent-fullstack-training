"""Behavior assertions over captured public HTTP outputs, no private helper tests."""
import json
from pathlib import Path
root=Path(__file__).parent
data={x['case']:x for x in json.loads((root/'controlled-results.json').read_text())}
checks=[]
def check(name,ok,detail):
    checks.append({'name':name,'pass':bool(ok),'detail':detail})
def frames(name):
    return [json.loads(x['line'][5:]) for x in data[name]['response'] if x['line'].startswith('data:') and '[DONE]' not in x['line']]
for m in ['openai','anthropic']:
    check(m+' normal',data['normal-'+m]['http']==200,'unified successful HTTP response')
    gate=data['stream-'+m+'-gate']['extra']
    check(m+' gated increment',gate['release_after_content'] is not None and gate['release_after_content']<8,gate)
    error=frames('stream-'+m+'-event_error')
    check(m+' explicit stream error',any('error' in f for f in error) and data['stream-'+m+'-event_error']['extra']['requests']==1,'error surfaced, one actual upstream request')
    eof=frames('stream-'+m+'-eof')
    check(m+' EOF must fail',any('error' in f for f in eof),'actual final finish_reason='+str(eof[-1].get('choices')))
    for case in ['invalid','empty','truncated']:
        r=data['json-'+m+'-'+case]
        check(m+' reject '+case,r['http']==502 and r['response']['error']['code']=='invalid_json_output',r['http'])
    for case in ['trailing','schema-mismatch']:
        r=data['json-'+m+'-'+case]
        check(m+' reject '+case,r['http']!=200,r['response']['choices'][0]['message']['content'])
    retry=data['retry-'+m+'-500-2']['extra']
    check(m+' retry count and backoff',retry['actual_requests']==3 and .48<retry['intervals'][0]<.8 and .98<retry['intervals'][1]<1.3,retry)
    for status,count in [(500,3),(429,3),(400,1),(401,1)]:
        r=data[f'retry-{m}-{status}-9']
        check(m+' retry cap '+str(status),r['extra']['actual_requests']==count,r['extra'])
    r=data['unsupported-format-'+m]
    check(m+' unsupported format is 4xx',400<=r['http']<500,{'actual_http':r['http']})
    rows=data['stream-'+m+'-empty_delta']['response']
    fs=frames('stream-'+m+'-empty_delta')
    first_content=next(x['elapsed'] for x in rows if '中文-FIRST' in x['line'])
    measured=fs[-1]['gateway']['timings']['first_token_ms']/1000
    check(m+' TTFT excludes empty delta',measured>=.20,{'reported_s':measured,'client_first_content_s':first_content})
records=data['/v1/requests?limit=200']['response']
rid=data['unknown-model']['response']['gateway']['request_id']
check('unknown model logged',any(x['requestId']==rid for x in records),rid)
for m in ['openai','anthropic']:
    rid=data['json-'+m+'-invalid']['response']['gateway']['request_id']
    rec=next(x for x in records if x['requestId']==rid)
    check(m+' known failure usage kept',rec['promptTokens']>0 and rec['completionTokens']==7,rec)
u=data['normal-openai']['response']['usage']
check('Responses cache category retained',u.get('prompt_tokens_details')=={'cached_tokens':3},u)
u=data['normal-anthropic']['response']['usage']
check('Messages cache input normalization',u['prompt_tokens']==16 and u['completion_tokens']==7 and u['total_tokens']==23,u)
for case,http in [('limit-first',200),('limit-second',429),('limit-other-model',200),('limit-restored',200)]:
    check(case,data[case]['http']==http,data[case]['http'])
for m in ['openai','anthropic']:
    for v in [1,2]:
        req=data[f'prompt-{m}-{v}']['extra']['upstream'][0]['body']
        actual=req.get('instructions',req.get('system'))
        check(f'{m} prompt v{v}',actual.startswith(f'v{v} says Alice$\\'),actual)
for name in ['prompt-missing-missing@1','prompt-missing-teacher@99','prompt-missing-teacher@2']:
    check(name,data[name]['http'] in [400,404] and data[name]['extra']['upstream_requests']==0,data[name]['http'])
(root/'assertions.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
for row in checks:
    print(('PASS' if row['pass'] else 'FAIL')+' '+row['name'])
print(f"Assertions: {sum(x['pass'] for x in checks)}/{len(checks)}. Failures are grading findings, not a score formula.")
