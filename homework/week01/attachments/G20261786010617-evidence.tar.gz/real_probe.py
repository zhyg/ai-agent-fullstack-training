"""Six bounded calls through student's adapters; never print credentials or headers."""
import json,time,urllib.request,urllib.error
from pathlib import Path
root=Path(__file__).parent
results=[]
for model in ['openai','anthropic']:
    for mode in ['normal','stream','json']:
        body={'model':model,'max_tokens':768,'messages':[{'role':'user','content':'Return only {"answer":"ok"}. Keep reasoning short.'}]}
        if mode=='stream': body['stream']=True
        if mode=='json': body['response_format']={'type':'json_object'}
        start=time.monotonic()
        req=urllib.request.Request('http://127.0.0.1:8082/v1/chat/completions',json.dumps(body).encode(),{'Content-Type':'application/json'})
        try:
            try: r=urllib.request.urlopen(req,timeout=160)
            except urllib.error.HTTPError as e: r=e
            data=r.read().decode()
            try: data=json.loads(data)
            except ValueError: pass
            row={'alias':model,'mode':mode,'request':body,'status':r.status,'elapsed_s':round(time.monotonic()-start,3),'response':data}
        except Exception as e:
            row={'alias':model,'mode':mode,'request':body,'error':str(e),'elapsed_s':round(time.monotonic()-start,3)}
        results.append(row)
        (root/'real-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
        print(model,mode,row.get('status'),row['elapsed_s'],flush=True)
with urllib.request.urlopen('http://127.0.0.1:8082/v1/requests?limit=200') as r:
    (root/'real-records.json').write_text(json.dumps(json.load(r),ensure_ascii=False,indent=2))
