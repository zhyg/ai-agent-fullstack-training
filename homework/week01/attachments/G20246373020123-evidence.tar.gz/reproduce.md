# 教师验证说明

固定对象：Gitee sdwazhian/ai-agent，master，7845c16eac9106d528999a5038433db703c54119。
本目录 source 为该提交源码导出，source-blobs.txt 可核验 Git blob，未改学生逻辑。

执行 cwd=/tmp/wzw-eval/student（固定版本仓库），证据目录=/tmp/wzw-eval/evidence。
依赖 Java 17、Maven、Python 3；个人 DEEPSEEK_API_KEY 已通过环境注入，不放入本包。

本次启动使用受监督服务，命令如下；不需要公开 portal：

```bash
amp orb service start wzw-upstream --command 'python3 /tmp/wzw-eval/evidence/mock.py' --port 18082
amp orb service start wzw-mock --command 'java -jar /tmp/wzw-eval/student/target/springai-0.0.1-SNAPSHOT.jar --spring.config.additional-location=file:/tmp/wzw-eval/evidence/mock.yaml' --port 18080
amp orb service start wzw-real --command 'java -jar /tmp/wzw-eval/student/target/springai-0.0.1-SNAPSHOT.jar --spring.config.additional-location=file:/tmp/wzw-eval/evidence/real.yaml' --port 18081
BASE=http://127.0.0.1:18080 bash scripts/verify.sh
python3 /tmp/wzw-eval/evidence/teacher.py
jshell --class-path target/classes /tmp/wzw-eval/evidence/retry-probe.jsh
```

teacher.py 无参数只调用本地网关和模拟上游，不消耗真实模型；--real 才请求 18081 官方配置网关。
真实验证已经执行一次，结果在 real-results.json、real-records.json，不要为重建报告重跑。
模拟控制状态与每个场景的请求均保存在 teacher-results.json；upstream.json 只是最后一个场景的快照，不能替代完整结果。
teacher.py 将协议对照中的 Schema 错误两协议均报告 FAIL，但评分只对 Messages 无原生约束也无本地验证扣一次。
失败断言用于发现缺陷，不是测试工具运行故障；最终教师脚本退出码为 0，仅表示完成全部场景，并不表示全部断言通过。
学生 verify.sh 原样首项退出，未修改以便跑通，也未用教师脚本冒充学生脚本验收。

真实网关只改一次尝试、20s 超时、端口和模板路径；没有替换 endpoint 或 upstream 模型。
受控配置使用虚拟 key；请求捕获只保存鉴权头名称，不保存值。
retry-probe.jsh 直接运行原编译类，不修改策略；随机值每次不同，封顶函数越界可由原源码直接核验。
mock 模板文件位于 /tmp/wzw-eval/mock-templates.json，与学生默认 data、真实服务文件相互隔离。

收尾停止 wzw-upstream、wzw-mock、wzw-real，检测 18080–18082 不监听；见 closeout.txt。
最终报告与本目录各文件做个人 key 精确字节、长 sk-key 模式扫描，且对最终 tar 解压成员再次扫描。
