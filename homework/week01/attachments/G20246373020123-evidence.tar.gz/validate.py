import os,re,hashlib,json,tarfile
from pathlib import Path
root=Path('/tmp/wzw-eval/evidence')
repo=Path('/home/user/workspace/repo')
feedback=repo/'homework/week01/G20246373020123.md'
detail=repo/'homework/week01/attachments/G20246373020123.md'
text=feedback.read_text()
for n in [2,3,4]:
 section=text.split('**'+str(n)+'. ')[1].split('\n**')[0]
 bullets=[s for s in section.splitlines() if s.startswith('- ')]
 chars=sum(len(s[2:]) for s in bullets)
 assert 3<=len(bullets)<=5 and chars<=500
 print(f'Section {n}: bullets={len(bullets)}, chars={chars}, PASS')
scores=[int(x) for x in re.findall(r'^\| (?!合计)[^|]+ \| (\d+)/\d+ \|',detail.read_text(),re.M)]
assert len(scores)==8 and sum(scores)==81
assert '优秀（81分）' in text
assert not re.search(r'【|待填写|TODO',text)
print('Eight scores:',scores,'total=',sum(scores),'PASS')
checked=0
for line in (root/'source-blobs.txt').read_text().splitlines():
 meta,name=line.split('\t',1); mode,typ,oid=meta.split(); b=(root/'source'/name).read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert actual==oid,name
 checked+=1
print('Fixed Git blob verification:',checked,'PASS')
key=os.environ.get('DEEPSEEK_API_KEY','').encode()
assert key,'Credential must be present for exact-value scan, but is never printed'
def scan(name,b):
 assert key not in b,'Exact credential leak in '+name
 assert not re.search(rb'sk-[A-Za-z0-9_-]{20,}',b),'Potential credential pattern in '+name
files=[f for f in root.rglob('*') if f.is_file()]+[feedback,detail]
for f in files: scan(str(f),f.read_bytes())
print('Evidence and report credential scan:',len(files),'files, zero matches, PASS')
archive=repo/'homework/week01/attachments/G20246373020123-evidence.tar.gz'
if archive.exists():
 with tarfile.open(archive) as t:
  members=[m for m in t.getmembers() if m.isfile()]
  for m in members: scan(m.name,t.extractfile(m).read())
 print('Final archive credential scan:',len(members),'members, zero matches, PASS')
r=json.loads((root/'real-results.json').read_text())
assert len(r)==2 and all(x['passed'] for x in r)
assert all(x['response']['body']['data']['attempts']==1 for x in r)
cases=json.loads((root/'teacher-results.json').read_text())
print('Controlled cases:',len(cases),'pass=',sum(x['passed'] for x in cases),'fail=',sum(not x['passed'] for x in cases))
print('Real protocol calls:',len(r),'each attempts=1, PASS')
