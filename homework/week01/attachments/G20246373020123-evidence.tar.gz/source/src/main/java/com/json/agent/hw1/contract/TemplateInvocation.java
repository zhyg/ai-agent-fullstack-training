package com.json.agent.hw1.contract;

import java.util.Map;

/**
 * 提示词模板引用。version 为 null 时取最新版本。
 */
public record TemplateInvocation(String name, Integer version, Map<String, Object> variables) {

    public String ref() {
        return version == null ? name : name + "@" + version;
    }
}
