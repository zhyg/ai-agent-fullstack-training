package com.json.agent.hw1.adapter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.agent.hw1.contract.ChatMessage;
import com.json.agent.hw1.contract.ChatRole;
import com.json.agent.hw1.contract.ResponseFormat;
import com.json.agent.hw1.contract.Timings;
import com.json.agent.hw1.contract.TokenUsage;
import com.json.agent.hw1.contract.UnifiedResponse;
import com.json.agent.hw1.resilience.ErrorCode;
import com.json.agent.hw1.resilience.LlmException;

import java.net.http.HttpClient;

/**
 * Anthropic Messages 协议适配器（deepseek-v4-flash）。
 *
 * <p>协议特征（与 Responses 的差异全部在这里被吃掉）：
 * <ul>
 *   <li>鉴权：x-api-key + anthropic-version，不是 Bearer</li>
 *   <li>请求体：system 是独立字段，max_tokens 必填，messages 只接受 user/assistant</li>
 *   <li>无 response_format 参数 → 结构化输出靠「schema 注入 system + 响应提取」等价实现</li>
 *   <li>响应：content[] 里混有 thinking 块，只取 type=text</li>
 *   <li>usage：input_tokens / output_tokens / cache_read_input_tokens</li>
 * </ul>
 */
@Component("anthropic-messages")
public class AnthropicMessagesAdapter extends AbstractHttpAdapter {

    private static final String ANTHROPIC_VERSION = "2023-06-01";
    private static final int DEFAULT_MAX_TOKENS = 1024;

    public AnthropicMessagesAdapter(HttpClient httpClient, ObjectMapper mapper) {
        super(httpClient, mapper);
    }

    @Override
    public String name() {
        return "anthropic-messages";
    }

    @Override
    public String protocol() {
        return "Anthropic Messages API (POST /anthropic/v1/messages, x-api-key 鉴权, 无 response_format)";
    }

    // ------------------------------------------------------------------ 非流式

    @Override
    public UnifiedResponse call(AdapterContext ctx) {
        long start = System.currentTimeMillis();
        String raw = post(ctx, buildBody(ctx, false), headers(ctx));
        JsonNode root = readTree(raw);
        if (root == null) {
            throw new LlmException(ErrorCode.UPSTREAM_BAD_RESPONSE,
                    "上游返回不是合法 JSON: " + abbreviate(raw));
        }
        String text = extractText(root);
        TokenUsage usage = extractUsage(root);
        JsonNode json = null;
        if (ctx.responseFormat() != null && ctx.responseFormat().isJson()) {
            json = parseJsonStrictly(text);
        }
        long total = System.currentTimeMillis() - start;
        return new UnifiedResponse(
                ctx.requestId(),
                ctx.model(),
                name(),
                text,
                json,
                usage,
                new Timings(start, 0, Timings.NA, total),
                1,
                ctx.templateRef());
    }

    // ------------------------------------------------------------------ 流式

    @Override
    public void stream(AdapterContext ctx, StreamSink sink) {
        Map<String, Object> body = buildBody(ctx, true);
        final int[] promptTokens = {0};
        final int[] completionTokens = {0};
        final int[] cachedTokens = {0};
        final StringBuilder buffer = new StringBuilder();
        try {
            postStream(ctx, body, headers(ctx), (event, data) -> {
                if (data == null || data.isBlank() || "[DONE]".equals(data.trim())) {
                    return;
                }
                JsonNode node = readTree(data);
                if (node == null || !node.isObject()) {
                    return;
                }
                String type = node.path("type").asText("");
                switch (type) {
                    case "message_start" -> {
                        JsonNode u = node.path("message").path("usage");
                        promptTokens[0] = u.path("input_tokens").asInt();
                        cachedTokens[0] = u.path("cache_read_input_tokens").asInt();
                    }
                    case "content_block_delta" -> {
                        JsonNode delta = node.path("delta");
                        String deltaType = delta.path("type").asText("");
                        if ("text_delta".equals(deltaType)) {
                            String t = delta.path("text").asText("");
                            if (!t.isEmpty()) {
                                buffer.append(t);
                                sink.onDelta(t);
                            }
                        }
                        // thinking_delta / signature_delta 直接忽略
                    }
                    case "message_delta" -> {
                        JsonNode u = node.path("usage");
                        completionTokens[0] = Math.max(completionTokens[0], u.path("output_tokens").asInt());
                    }
                    case "message_stop" -> {
                        // 结束事件，usage 已在 message_delta 拿到
                    }
                    case "error" -> sink.onError(ErrorCode.UPSTREAM_SERVER_ERROR,
                            "上游流式返回错误: " + abbreviate(node.path("error").toString()));
                    default -> {
                        // 宽松兜底：只要带 text_delta 结构就吐内容，兼容事件名微调
                        if ("text_delta".equals(node.path("delta").path("type").asText(""))) {
                            String t = node.path("delta").path("text").asText("");
                            if (!t.isEmpty()) {
                                buffer.append(t);
                                sink.onDelta(t);
                            }
                        }
                    }
                }
            });
            if (ctx.responseFormat() != null && ctx.responseFormat().isJson()) {
                parseJsonStrictly(buffer.toString());
            }
            sink.onDone(new TokenUsage(promptTokens[0], completionTokens[0], 0, cachedTokens[0], 0));
        } catch (LlmException e) {
            log.warn("[hw1][{}] 流式调用失败: {}", name(), e.getMessage());
            sink.onError(e.errorCode(), e.getMessage());
        } catch (RuntimeException e) {
            log.warn("[hw1][{}] 流式调用异常: {}", name(), e.getMessage(), e);
            sink.onError(ErrorCode.UNKNOWN, e.getMessage());
        }
    }

    // ------------------------------------------------------------------ 报文构造

    private Map<String, String> headers(AdapterContext ctx) {
        return Map.of(
                "x-api-key", ctx.apiKey(),
                "anthropic-version", ANTHROPIC_VERSION);
    }

    private Map<String, Object> buildBody(AdapterContext ctx, boolean stream) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", ctx.upstreamModel());
        body.put("stream", stream);

        StringBuilder system = new StringBuilder(ctx.systemOrEmpty());
        for (ChatMessage m : ctx.messages()) {
            if (m.role() == ChatRole.SYSTEM) {
                if (system.length() > 0) {
                    system.append('\n');
                }
                system.append(m.content());
            }
        }
        ResponseFormat format = ctx.responseFormat();
        if (format != null && format.isJson()) {
            system.append(jsonInstruction(format));
        }
        if (system.length() > 0) {
            body.put("system", system.toString());
        }

        List<Map<String, Object>> messages = new ArrayList<>();
        for (ChatMessage m : ctx.messages()) {
            if (m.role() == ChatRole.SYSTEM) {
                continue; // Anthropic 的 system 不在 messages 里
            }
            messages.add(Map.of("role", m.role().value(), "content", m.content()));
        }
        body.put("messages", messages);
        body.put("max_tokens", ctx.maxTokens() == null || ctx.maxTokens() <= 0
                ? DEFAULT_MAX_TOKENS
                : ctx.maxTokens());

        if (ctx.temperature() != null) {
            body.put("temperature", ctx.temperature());
        }
        return body;
    }

    // ------------------------------------------------------------------ 解析

    /** content[] 里只取 type=text，跳过 thinking 块。 */
    protected String extractText(JsonNode root) {
        StringBuilder sb = new StringBuilder();
        JsonNode content = root.path("content");
        if (content.isArray()) {
            for (JsonNode block : content) {
                if ("text".equals(block.path("type").asText())) {
                    sb.append(block.path("text").asText(""));
                }
            }
        }
        return sb.toString();
    }

    protected TokenUsage extractUsage(JsonNode root) {
        JsonNode u = root.path("usage");
        int prompt = u.path("input_tokens").asInt();
        int completion = u.path("output_tokens").asInt();
        int cached = u.path("cache_read_input_tokens").asInt()
                + u.path("cache_creation_input_tokens").asInt();
        return new TokenUsage(prompt, completion, 0, cached, 0);
    }

    private JsonNode readTree(String raw) {
        try {
            return mapper.readTree(raw);
        } catch (Exception e) {
            return null;
        }
    }
}
