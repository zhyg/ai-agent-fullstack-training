package com.json.agent.hw1.prompt;

/**
 * 模板引用解析：支持 "name" 与 "name@2" 两种写法。
 */
public record TemplateRef(String name, Integer version) {

    public static TemplateRef parse(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new IllegalArgumentException("模板引用不能为空");
        }
        String s = raw.trim();
        int at = s.lastIndexOf('@');
        if (at <= 0 || at == s.length() - 1) {
            return new TemplateRef(s, null);
        }
        String versionPart = s.substring(at + 1);
        try {
            return new TemplateRef(s.substring(0, at), Integer.parseInt(versionPart));
        } catch (NumberFormatException e) {
            // 名字里本身带 @ 的情况，整体当名字
            return new TemplateRef(s, null);
        }
    }
}
