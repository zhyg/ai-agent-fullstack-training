package com.json.agent.hw1.observe;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.atomic.LongAdder;

import org.springframework.stereotype.Component;

import com.json.agent.hw1.config.LlmProperties;
import com.json.agent.hw1.resilience.RateLimiterRegistry;

/**
 * 可观测性采集器：内存聚合 + 最近 N 条明细。
 *
 * <p>聚合维度：全局 + 按 model，指标含 Token 分类（prompt/completion/total/cached/reasoning）
 * 与延迟（平均端到端 + 平均首 Token 延迟）。
 */
@Component
public class MetricsCollector {

    private final ConcurrentLinkedDeque<CallRecord> records = new ConcurrentLinkedDeque<>();
    private final Map<String, ModelAgg> byModel = new ConcurrentHashMap<>();
    private final GlobalAgg global = new GlobalAgg();
    private final int retention;
    private final RateLimiterRegistry rateLimiterRegistry;

    public MetricsCollector(LlmProperties properties, RateLimiterRegistry rateLimiterRegistry) {
        this.retention = properties.metricsRetention() <= 0 ? 200 : properties.metricsRetention();
        this.rateLimiterRegistry = rateLimiterRegistry;
    }

    public void record(CallRecord record) {
        records.addFirst(record);
        while (records.size() > retention) {
            records.pollLast();
        }
        global.accept(record);
        byModel.computeIfAbsent(record.model(), k -> new ModelAgg(record.adapter())).accept(record);
    }

    public MetricsSnapshot snapshot() {
        Map<String, ModelStats> stats = new LinkedHashMap<>();
        byModel.forEach((model, agg) -> stats.put(model, agg.toStats(model)));

        long calls = global.calls.sum();
        double avgLatency = calls == 0 ? 0 : global.latencySum.sum() * 1.0d / calls;
        double avgTtft = global.ttftCount.sum() == 0
                ? 0
                : global.ttftSum.sum() * 1.0d / global.ttftCount.sum();

        return new MetricsSnapshot(
                calls,
                global.success.sum(),
                global.failures.sum(),
                global.promptTokens.sum(),
                global.completionTokens.sum(),
                global.totalTokens.sum(),
                global.cachedTokens.sum(),
                global.reasoningTokens.sum(),
                round(avgLatency),
                round(avgTtft),
                stats,
                records.size(),
                rateLimiterRegistry.snapshot());
    }

    public List<CallRecord> recent(int limit) {
        int n = limit <= 0 ? 20 : limit;
        List<CallRecord> out = new ArrayList<>(n);
        for (CallRecord r : records) {
            out.add(r);
            if (out.size() >= n) {
                break;
            }
        }
        return out;
    }

    public void reset() {
        records.clear();
        byModel.clear();
        global.reset();
    }

    public int retention() {
        return retention;
    }

    private static double round(double v) {
        return Math.round(v * 100.0d) / 100.0d;
    }

    /** 聚合累加器 */
    private static final class GlobalAgg {
        final LongAdder calls = new LongAdder();
        final LongAdder success = new LongAdder();
        final LongAdder failures = new LongAdder();
        final LongAdder promptTokens = new LongAdder();
        final LongAdder completionTokens = new LongAdder();
        final LongAdder totalTokens = new LongAdder();
        final LongAdder cachedTokens = new LongAdder();
        final LongAdder reasoningTokens = new LongAdder();
        final LongAdder latencySum = new LongAdder();
        final LongAdder ttftSum = new LongAdder();
        final LongAdder ttftCount = new LongAdder();

        void accept(CallRecord r) {
            calls.increment();
            if (r.success()) {
                success.increment();
            } else {
                failures.increment();
            }
            if (r.usage() != null) {
                promptTokens.add(r.usage().promptTokens());
                completionTokens.add(r.usage().completionTokens());
                totalTokens.add(r.usage().totalTokens());
                cachedTokens.add(r.usage().cachedTokens());
                reasoningTokens.add(r.usage().reasoningTokens());
            }
            if (r.timings() != null) {
                latencySum.add(Math.max(0, r.timings().totalMs()));
                if (r.timings().hasTtft()) {
                    ttftSum.add(r.timings().ttftMs());
                    ttftCount.increment();
                }
            }
        }

        void reset() {
            calls.reset();
            success.reset();
            failures.reset();
            promptTokens.reset();
            completionTokens.reset();
            totalTokens.reset();
            cachedTokens.reset();
            reasoningTokens.reset();
            latencySum.reset();
            ttftSum.reset();
            ttftCount.reset();
        }
    }

    /** 按模型聚合累加器 */
    private static final class ModelAgg {
        final GlobalAgg agg = new GlobalAgg();
        final LongAdder streamCalls = new LongAdder();
        volatile long maxLatencyMs;
        volatile long lastTtftMs = -1;
        volatile String adapter;

        ModelAgg(String adapter) {
            this.adapter = adapter;
        }

        synchronized void accept(CallRecord r) {
            agg.accept(r);
            if (r.stream()) {
                streamCalls.increment();
            }
            if (r.timings() != null) {
                maxLatencyMs = Math.max(maxLatencyMs, r.timings().totalMs());
                if (r.timings().hasTtft()) {
                    lastTtftMs = r.timings().ttftMs();
                }
            }
            if (r.adapter() != null) {
                adapter = r.adapter();
            }
        }

        ModelStats toStats(String model) {
            long calls = agg.calls.sum();
            double avgLatency = calls == 0 ? 0 : agg.latencySum.sum() * 1.0d / calls;
            double avgTtft = agg.ttftCount.sum() == 0 ? 0 : agg.ttftSum.sum() * 1.0d / agg.ttftCount.sum();
            return new ModelStats(
                    model,
                    adapter,
                    calls,
                    agg.success.sum(),
                    agg.failures.sum(),
                    agg.promptTokens.sum(),
                    agg.completionTokens.sum(),
                    agg.totalTokens.sum(),
                    agg.cachedTokens.sum(),
                    agg.reasoningTokens.sum(),
                    streamCalls.sum(),
                    MetricsCollector.round(avgLatency),
                    MetricsCollector.round(avgTtft),
                    maxLatencyMs,
                    lastTtftMs);
        }
    }
}
