package com.json.agent.hw1.contract;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 统一消息角色。对外只暴露 system / user / assistant 三种，
 * 由各适配器按目标协议自行转换（Anthropic 的 system 是独立字段，不在 messages 里）。
 */
public enum ChatRole {

    SYSTEM("system"),
    USER("user"),
    ASSISTANT("assistant");

    private final String value;

    ChatRole(String value) {
        this.value = value;
    }

    @JsonValue
    public String value() {
        return value;
    }

    @JsonCreator
    public static ChatRole of(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new IllegalArgumentException("role 不能为空");
        }
        String v = raw.trim();
        for (ChatRole role : values()) {
            if (role.value.equalsIgnoreCase(v)) {
                return role;
            }
        }
        throw new IllegalArgumentException("不支持的 role: " + raw + "（仅支持 system/user/assistant）");
    }
}
