package com.json.agent.hw1.resilience;

import java.util.Random;

import com.json.agent.hw1.config.LlmProperties;

/**
 * 指数退避重试策略：base * multiplier^(n-1)，加抖动，上限 maxBackoffMs。
 * 上游给了 Retry-After 时优先听上游的。
 */
public class RetryPolicy {

    private static final Random RANDOM = new Random();

    private final int maxAttempts;
    private final long initialBackoffMs;
    private final double multiplier;
    private final long maxBackoffMs;
    private final double jitterRatio;

    public RetryPolicy(LlmProperties.RetryConfig cfg) {
        this.maxAttempts = cfg == null || cfg.maxAttempts() <= 0 ? 3 : cfg.maxAttempts();
        this.initialBackoffMs = cfg == null ? 500L : cfg.initialBackoffMs();
        this.multiplier = cfg == null || cfg.multiplier() <= 1 ? 2.0d : cfg.multiplier();
        this.maxBackoffMs = cfg == null ? 8_000L : cfg.maxBackoffMs();
        this.jitterRatio = cfg == null ? 0.2d : cfg.jitterRatio();
    }

    public int maxAttempts() {
        return maxAttempts;
    }

    /**
     * @param attempt 当前是第几次尝试（从 1 开始）
     */
    public long backoffMs(int attempt, Long retryAfterMs) {
        if (retryAfterMs != null && retryAfterMs > 0) {
            return Math.min(retryAfterMs, maxBackoffMs * 2);
        }
        long raw = (long) (initialBackoffMs * Math.pow(multiplier, Math.max(0, attempt - 1)));
        long capped = Math.min(raw, maxBackoffMs);
        long jitter = (long) (capped * jitterRatio * RANDOM.nextDouble());
        return capped + jitter;
    }

    public void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
