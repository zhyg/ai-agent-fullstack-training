package com.json.agent.hw1.adapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.agent.hw1.contract.ResponseFormat;
import com.json.agent.hw1.resilience.ErrorCode;
import com.json.agent.hw1.resilience.LlmException;

/**
 * 适配器的 HTTP 公共能力：发报文、读 SSE、状态码归一成错误码。
 */
public abstract class AbstractHttpAdapter implements LlmAdapter {

    protected final Logger log = LoggerFactory.getLogger(getClass());

    protected final HttpClient httpClient;
    protected final ObjectMapper mapper;

    protected AbstractHttpAdapter(HttpClient httpClient, ObjectMapper mapper) {
        this.httpClient = httpClient;
        this.mapper = mapper;
    }

    // ------------------------------------------------------------------ 发送

    /** 非流式：POST 并返回响应体字符串。 */
    protected String post(AdapterContext ctx, Map<String, Object> body, Map<String, String> headers) {
        HttpRequest request = build(ctx, body, headers);
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            checkStatus(response.statusCode(), response.body(), response.headers());
            return response.body();
        } catch (LlmException e) {
            throw e;
        } catch (java.net.http.HttpTimeoutException e) {
            throw new LlmException(ErrorCode.UPSTREAM_TIMEOUT, "请求上游超时: " + ctx.endpoint(), e);
        } catch (IOException e) {
            throw new LlmException(ErrorCode.NETWORK_ERROR, "调用上游网络异常: " + ctx.endpoint(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new LlmException(ErrorCode.NETWORK_ERROR, "调用上游被中断", e);
        }
    }

    /** 流式：POST 并逐行解析 SSE，每个事件回调 (eventName, data)。 */
    protected void postStream(AdapterContext ctx, Map<String, Object> body, Map<String, String> headers,
                              BiConsumer<String, String> eventHandler) {
        HttpRequest request = build(ctx, body, headers);
        try {
            HttpResponse<InputStream> response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
            if (response.statusCode() >= 300) {
                String errBody;
                try (InputStream err = response.body()) {
                    errBody = new String(err.readAllBytes(), StandardCharsets.UTF_8);
                }
                checkStatus(response.statusCode(), errBody, response.headers());
            }
            readSse(response.body(), eventHandler);
        } catch (LlmException e) {
            throw e;
        } catch (java.net.http.HttpTimeoutException e) {
            throw new LlmException(ErrorCode.UPSTREAM_TIMEOUT, "流式请求上游超时: " + ctx.endpoint(), e);
        } catch (IOException e) {
            throw new LlmException(ErrorCode.NETWORK_ERROR, "流式调用网络异常: " + ctx.endpoint(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new LlmException(ErrorCode.NETWORK_ERROR, "流式调用被中断", e);
        }
    }

    private HttpRequest build(AdapterContext ctx, Map<String, Object> body, Map<String, String> headers) {
        try {
            HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(ctx.endpoint()))
                    .timeout(ctx.requestTimeout() == null ? Duration.ofSeconds(120) : ctx.requestTimeout())
                    .header("Content-Type", "application/json")
                    .header("Accept", ctx.stream() ? "text/event-stream" : "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            mapper.writeValueAsString(body), StandardCharsets.UTF_8));
            if (headers != null) {
                headers.forEach(builder::header);
            }
            return builder.build();
        } catch (IOException e) {
            throw new LlmException(ErrorCode.BAD_REQUEST, "请求体序列化失败", e);
        }
    }

    private void checkStatus(int status, String body, java.net.http.HttpHeaders headers) {
        if (status >= 200 && status < 300) {
            return;
        }
        String snippet = body == null ? "" : abbreviate(body);
        Long retryAfter = parseRetryAfter(headers);
        ErrorCode code;
        String msg;
        switch (status) {
            case 401, 403 -> {
                code = ErrorCode.UPSTREAM_AUTH;
                msg = "上游鉴权失败(" + status + ")，检查 api-key: " + snippet;
            }
            case 429 -> {
                code = ErrorCode.UPSTREAM_RATE_LIMIT;
                msg = "上游限流(429): " + snippet;
            }
            case 408, 504, 524 -> {
                code = ErrorCode.UPSTREAM_TIMEOUT;
                msg = "上游超时(" + status + "): " + snippet;
            }
            case 400, 404, 422 -> {
                code = ErrorCode.BAD_REQUEST;
                msg = "上游拒绝请求(" + status + "): " + snippet;
            }
            default -> {
                code = status >= 500 ? ErrorCode.UPSTREAM_SERVER_ERROR : ErrorCode.UPSTREAM_BAD_RESPONSE;
                msg = "上游异常(" + status + "): " + snippet;
            }
        }
        throw new LlmException(code, msg, retryAfter, null);
    }

    private Long parseRetryAfter(java.net.http.HttpHeaders headers) {
        if (headers == null) {
            return null;
        }
        Optional<String> v = headers.firstValue("Retry-After");
        if (v.isEmpty()) {
            return null;
        }
        try {
            return (long) (Double.parseDouble(v.get().trim()) * 1000);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** 标准 SSE 解析：event 行 + 多行 data 拼接，空行触发回调。 */
    private void readSse(InputStream in, BiConsumer<String, String> eventHandler) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            String event = null;
            StringBuilder data = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) {
                    if (data.length() > 0) {
                        if (log.isDebugEnabled()) {
                            log.debug("[hw1] SSE event={} data={}", event, data);
                        }
                        eventHandler.accept(event, data.toString());
                    }
                    event = null;
                    data.setLength(0);
                    continue;
                }
                if (line.startsWith(":")) {
                    continue; // 心跳注释
                }
                if (line.startsWith("event:")) {
                    event = line.substring("event:".length()).trim();
                } else if (line.startsWith("data:")) {
                    if (data.length() > 0) {
                        data.append('\n');
                    }
                    data.append(line.substring("data:".length()).trim());
                }
            }
            if (data.length() > 0) {
                eventHandler.accept(event, data.toString());
            }
        }
    }

    protected static String abbreviate(String s) {
        String flat = s.replaceAll("\\s+", " ").trim();
        return flat.length() > 300 ? flat.substring(0, 300) + "..." : flat;
    }

    /** 把模型输出解析为合法 JSON；失败抛 INVALID_JSON_OUTPUT（可重试）。 */
    protected JsonNode parseJsonStrictly(String raw) {
        String candidate = stripCodeFence(raw);
        try {
            return mapper.readTree(candidate);
        } catch (IOException first) {
            int start = candidate.indexOf('{');
            int end = candidate.lastIndexOf('}');
            if (start >= 0 && end > start) {
                try {
                    return mapper.readTree(candidate.substring(start, end + 1));
                } catch (IOException ignored) {
                    // fall through
                }
            }
            throw new LlmException(ErrorCode.INVALID_JSON_OUTPUT,
                    "模型输出不是合法 JSON: " + abbreviate(raw));
        }
    }

    protected static String stripCodeFence(String raw) {
        if (raw == null) {
            return "";
        }
        String s = raw.trim();
        if (s.startsWith("```")) {
            int firstNewline = s.indexOf('\n');
            if (firstNewline > 0) {
                s = s.substring(firstNewline + 1);
            }
            if (s.endsWith("```")) {
                s = s.substring(0, s.length() - 3);
            }
            return s.trim();
        }
        return s;
    }

    /** Anthropic 没有 response_format，用提示词约束等价实现。 */
    protected String jsonInstruction(ResponseFormat format) {
        if (format == null || !format.isJson()) {
            return "";
        }
        StringBuilder sb = new StringBuilder()
                .append("\n\n[输出格式强制要求]\n")
                .append("你必须只输出一个合法的 JSON 对象，不要输出任何解释、前后缀或 Markdown 代码块。\n")
                .append("不要使用 ```json 包裹。\n");
        if (format.isJsonSchema()) {
            try {
                sb.append("JSON Schema 如下，字段名、类型必须严格匹配：\n")
                        .append(mapper.writeValueAsString(format.schema()))
                        .append('\n');
            } catch (IOException e) {
                sb.append("JSON Schema: ").append(format.schema()).append('\n');
            }
        }
        return sb.toString();
    }

}
