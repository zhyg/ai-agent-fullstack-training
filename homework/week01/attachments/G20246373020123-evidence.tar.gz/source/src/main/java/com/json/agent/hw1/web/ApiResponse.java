package com.json.agent.hw1.web;

import com.json.agent.hw1.resilience.ErrorCode;

/**
 * 统一响应包装。错误场景一律走这套结构，code 取 ErrorCode。
 */
public record ApiResponse<T>(int code, String message, String requestId, T data) {

    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(ErrorCode.OK.code(), "ok", null, data);
    }

    public static <T> ApiResponse<T> ok(T data, String requestId) {
        return new ApiResponse<>(ErrorCode.OK.code(), "ok", requestId, data);
    }

    public static ApiResponse<Void> fail(ErrorCode errorCode, String message) {
        return new ApiResponse<>(errorCode.code(), message == null ? errorCode.message() : message, null, null);
    }
}
