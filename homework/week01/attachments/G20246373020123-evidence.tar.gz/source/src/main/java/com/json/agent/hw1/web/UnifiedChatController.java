package com.json.agent.hw1.web;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.agent.hw1.LlmGatewayService;
import com.json.agent.hw1.adapter.AdapterRouter;
import com.json.agent.hw1.adapter.StreamSink;
import com.json.agent.hw1.contract.StreamEvent;
import com.json.agent.hw1.contract.TokenUsage;
import com.json.agent.hw1.contract.UnifiedRequest;
import com.json.agent.hw1.contract.UnifiedResponse;
import com.json.agent.hw1.resilience.ErrorCode;
import com.json.agent.hw1.resilience.LlmException;

/**
 * 统一调用入口。同一个请求体、同一个接口，只靠 model 字段决定走哪种协议。
 */
@RestController
@RequestMapping("/v1")
public class UnifiedChatController {

    private final LlmGatewayService gateway;
    private final AdapterRouter router;
    private final ObjectMapper mapper;
    private final TaskExecutor sseExecutor;

    public UnifiedChatController(LlmGatewayService gateway,
                                 AdapterRouter router,
                                 ObjectMapper mapper,
                                 @Qualifier("hw1SseExecutor") TaskExecutor sseExecutor) {
        this.gateway = gateway;
        this.router = router;
        this.mapper = mapper;
        this.sseExecutor = sseExecutor;
    }

    /** 非流式统一调用 */
    @PostMapping("/chat")
    public ApiResponse<UnifiedResponse> chat(@RequestBody UnifiedRequest request) {
        UnifiedResponse response = gateway.chat(request);
        return ApiResponse.ok(response, response.requestId());
    }

    /** 流式统一调用：SSE 逐块返回 */
    @PostMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestBody UnifiedRequest request) {
        SseEmitter emitter = new SseEmitter(180_000L);
        SseSink sink = new SseSink(emitter);
        sseExecutor.execute(() -> {
            try {
                gateway.stream(request, sink);
            } catch (LlmException e) {
                sink.onError(e.errorCode(), e.getMessage());
            } catch (Exception e) {
                sink.onError(ErrorCode.UNKNOWN, String.valueOf(e.getMessage()));
            }
        });
        return emitter;
    }

    /** 列出模型 → 适配器/协议 的映射，用于验证路由 */
    @GetMapping("/models")
    public ApiResponse<Map<String, Object>> models() {
        return ApiResponse.ok(router.describe());
    }

    private final class SseSink implements StreamSink {

        private final SseEmitter emitter;

        SseSink(SseEmitter emitter) {
            this.emitter = emitter;
        }

        @Override
        public void onDelta(String text) {
            send(StreamEvent.delta(text));
        }

        @Override
        public void onDone(TokenUsage usage) {
            send(StreamEvent.done(usage));
            send("[DONE]");
            emitter.complete();
        }

        @Override
        public void onError(ErrorCode errorCode, String message) {
            send(StreamEvent.error(errorCode.name(), message));
            send("[DONE]");
            emitter.complete();
        }

        private void send(Object payload) {
            try {
                String data = payload instanceof String s ? s : mapper.writeValueAsString(payload);
                emitter.send(SseEmitter.event().data(data));
            } catch (IOException | IllegalStateException e) {
                emitter.completeWithError(e);
            }
        }
    }
}
