package com.json.agent.hw1.adapter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.json.agent.hw1.config.LlmProperties;
import com.json.agent.hw1.resilience.ErrorCode;
import com.json.agent.hw1.resilience.LlmException;

/**
 * 按请求里的 model 字段动态路由到对应适配器。新增一种协议 = 新增一个 LlmAdapter + 一行配置。
 */
@Component
public class AdapterRouter {

    private final Map<String, LlmAdapter> adapters;
    private final LlmProperties properties;

    public AdapterRouter(List<LlmAdapter> adapterList, LlmProperties properties) {
        this.properties = properties;
        this.adapters = adapterList.stream()
                .collect(Collectors.toMap(LlmAdapter::name, Function.identity(), (a, b) -> a, LinkedHashMap::new));
    }

    public record Resolved(String model, LlmAdapter adapter, LlmProperties.ModelConfig config) {
    }

    public Resolved resolve(String model) {
        if (model == null || model.isBlank()) {
            throw new LlmException(ErrorCode.BAD_REQUEST, "model 不能为空");
        }
        LlmProperties.ModelConfig config = properties.model(model.trim());
        if (config == null) {
            throw new LlmException(ErrorCode.MODEL_NOT_SUPPORTED,
                    "不支持的 model: " + model + "，当前支持 " + properties.modelsOrEmpty().keySet());
        }
        LlmAdapter adapter = adapters.get(config.adapter());
        if (adapter == null) {
            throw new LlmException(ErrorCode.MODEL_NOT_CONFIGURED,
                    "model [" + model + "] 配置的适配器 [" + config.adapter() + "] 不存在，"
                            + "当前可用适配器 " + adapters.keySet());
        }
        return new Resolved(model.trim(), adapter, config);
    }

    /** /v1/models 的输出：把"模型 → 协议"的映射暴露出来，便于验证路由。 */
    public Map<String, Object> describe() {
        Map<String, Object> view = new LinkedHashMap<>();
        properties.modelsOrEmpty().forEach((model, cfg) -> {
            LlmAdapter adapter = adapters.get(cfg.adapter());
            Map<String, Object> one = new LinkedHashMap<>();
            one.put("adapter", cfg.adapter());
            one.put("protocol", cfg.protocol() != null ? cfg.protocol()
                    : (adapter == null ? "unknown" : adapter.protocol()));
            one.put("upstreamModel", cfg.upstream());
            one.put("endpoint", cfg.endpoint());
            view.put(model, one);
        });
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("models", view);
        result.put("adapters", adapters.keySet());
        return result;
    }
}
