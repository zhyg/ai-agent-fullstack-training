package com.json.agent.hw1.resilience;

/**
 * 归一的业务异常。retryAfterMs 来自上游 Retry-After 头，用于限流退避。
 */
public class LlmException extends RuntimeException {

    private final ErrorCode errorCode;
    private final Long retryAfterMs;

    public LlmException(ErrorCode errorCode, String message) {
        this(errorCode, message, null, null);
    }

    public LlmException(ErrorCode errorCode, String message, Throwable cause) {
        this(errorCode, message, null, cause);
    }

    public LlmException(ErrorCode errorCode, String message, Long retryAfterMs, Throwable cause) {
        super(message == null ? errorCode.message() : message, cause);
        this.errorCode = errorCode;
        this.retryAfterMs = retryAfterMs;
    }

    public ErrorCode errorCode() {
        return errorCode;
    }

    public Long retryAfterMs() {
        return retryAfterMs;
    }
}
