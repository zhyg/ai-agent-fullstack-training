package com.json.agent.hw1.contract;

/**
 * 统一 Token 消耗，含分类统计：
 *
 * <ul>
 *   <li>promptTokens —— 输入 token（Responses: usage.input_tokens / Anthropic: usage.input_tokens）</li>
 *   <li>completionTokens —— 输出 token（Responses: usage.output_tokens / Anthropic: usage.output_tokens）</li>
 *   <li>cachedTokens —— 命中提示缓存的 token（Responses: input_tokens_details.cached_tokens / Anthropic: cache_read_input_tokens）</li>
 *   <li>reasoningTokens —— 思维链消耗（Responses: output_tokens_details.reasoning_tokens / Anthropic: thinking 块估算）</li>
 * </ul>
 */
public record TokenUsage(int promptTokens, int completionTokens, int totalTokens,
                         int cachedTokens, int reasoningTokens) {

    public static final TokenUsage EMPTY = new TokenUsage(0, 0, 0, 0, 0);

    public TokenUsage {
        if (totalTokens <= 0) {
            totalTokens = promptTokens + completionTokens;
        }
    }

    public static TokenUsage of(int promptTokens, int completionTokens) {
        return new TokenUsage(promptTokens, completionTokens, 0, 0, 0);
    }

    public static TokenUsage full(int promptTokens, int completionTokens,
                                  int cachedTokens, int reasoningTokens) {
        return new TokenUsage(promptTokens, completionTokens, 0, cachedTokens, reasoningTokens);
    }

    public TokenUsage plus(TokenUsage other) {
        if (other == null) {
            return this;
        }
        return new TokenUsage(
                this.promptTokens + other.promptTokens,
                this.completionTokens + other.completionTokens,
                this.totalTokens + other.totalTokens,
                this.cachedTokens + other.cachedTokens,
                this.reasoningTokens + other.reasoningTokens);
    }
}
