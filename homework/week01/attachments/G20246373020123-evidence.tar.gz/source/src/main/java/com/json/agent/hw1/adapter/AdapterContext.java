package com.json.agent.hw1.adapter;

import java.time.Duration;
import java.util.List;

import com.json.agent.hw1.contract.ChatMessage;
import com.json.agent.hw1.contract.ResponseFormat;

/**
 * 传给适配器的上下文：与协议无关，适配器负责翻译成各自协议的报文。
 */
public record AdapterContext(
        String requestId,
        String model,
        String upstreamModel,
        String endpoint,
        String apiKey,
        Duration requestTimeout,
        String system,
        List<ChatMessage> messages,
        ResponseFormat responseFormat,
        Double temperature,
        Integer maxTokens,
        boolean stream,
        String templateRef
) {

    public String systemOrEmpty() {
        return system == null ? "" : system;
    }
}
