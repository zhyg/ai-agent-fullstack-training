package com.json.agent.hw1.contract;

/**
 * 统一流式事件。两个适配器的 SSE 事件名完全不同，由适配器转换为这三种：
 * delta（内容分片） / done（结束并带 usage） / error（错误码）。
 */
public record StreamEvent(String type, String delta, TokenUsage usage, String errorCode, String message) {

    public static final String DELTA = "delta";
    public static final String DONE = "done";
    public static final String ERROR = "error";

    public static StreamEvent delta(String text) {
        return new StreamEvent(DELTA, text, null, null, null);
    }

    public static StreamEvent done(TokenUsage usage) {
        return new StreamEvent(DONE, null, usage, null, null);
    }

    public static StreamEvent error(String errorCode, String message) {
        return new StreamEvent(ERROR, null, null, errorCode, message);
    }
}
