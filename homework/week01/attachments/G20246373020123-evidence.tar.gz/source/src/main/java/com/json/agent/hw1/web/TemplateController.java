package com.json.agent.hw1.web;

import java.util.List;
import java.util.Map;

import com.json.agent.hw1.prompt.PromptTemplate;
import com.json.agent.hw1.resilience.ErrorCode;
import com.json.agent.hw1.resilience.LlmException;
import org.springframework.web.bind.annotation.*;

/**
 * 提示词模板的版本管理：存储、变量替换、按 name / name@version 引用。
 */
@RestController
@RequestMapping("/v1/templates")
public class TemplateController {

    private final com.json.agent.hw1.prompt.TemplateStore store;

    public TemplateController(com.json.agent.hw1.prompt.TemplateStore store) {
        this.store = store;
    }

    public record CreateRequest(String name, String content, List<String> variables, String description) {
    }

    @GetMapping
    public ApiResponse<Map<String, Object>> list() {
        return ApiResponse.ok(Map.of(
                "file", store.file().toAbsolutePath().toString(),
                "latestVersions", store.latestVersions(),
                "templates", store.list()));
    }

    /** 保存即升版本 */
    @PostMapping
    public ApiResponse<PromptTemplate> create(@RequestBody CreateRequest request) {
        if (request == null || request.name() == null || request.content() == null) {
            throw new LlmException(ErrorCode.BAD_REQUEST, "name 与 content 必填");
        }
        PromptTemplate template = store.create(request.name(), request.content(),
                request.variables(), request.description());
        return ApiResponse.ok(template);
    }

    @GetMapping("/{name}")
    public ApiResponse<PromptTemplate> latest(@PathVariable String name) {
        return ApiResponse.ok(store.getLatest(name)
                .orElseThrow(() -> new LlmException(ErrorCode.TEMPLATE_NOT_FOUND, "模板不存在: " + name)));
    }

    @GetMapping("/{name}/{version}")
    public ApiResponse<PromptTemplate> byVersion(@PathVariable String name, @PathVariable int version) {
        return ApiResponse.ok(store.get(name, version)
                .orElseThrow(() -> new LlmException(ErrorCode.TEMPLATE_NOT_FOUND,
                        "模板不存在: " + name + "@" + version)));
    }
}
