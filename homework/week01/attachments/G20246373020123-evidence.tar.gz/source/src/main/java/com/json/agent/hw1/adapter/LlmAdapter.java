package com.json.agent.hw1.adapter;

import com.json.agent.hw1.contract.UnifiedResponse;

/**
 * 适配器接口：把统一契约翻译成某种上游协议，并把上游响应翻译回统一契约。
 *
 * <p>要屏蔽的三类差异：
 * <ol>
 *   <li>鉴权：Bearer vs x-api-key + anthropic-version</li>
 *   <li>请求体：instructions+input[] vs system+max_tokens+messages[]</li>
 *   <li>返回解析：output[].content[].text + usage.input_tokens vs content[].text + usage.input_tokens</li>
 * </ol>
 */
public interface LlmAdapter {

    /** 协议标识，如 openai-responses / anthropic-messages */
    String name();

    /** 人类可读的协议说明，用于 /v1/models 展示 */
    String protocol();

    UnifiedResponse call(AdapterContext context);

    void stream(AdapterContext context, StreamSink sink);
}
