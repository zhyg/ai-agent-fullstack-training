package com.json.agent.hw1.web;

import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.json.agent.hw1.resilience.ChaosConfig;
import com.json.agent.hw1.resilience.RateLimiterRegistry;

/**
 * 验证用运维端点：故障注入（验证重试）与限流桶复位。
 * 仅本地作业环境使用。
 */
@RestController
@RequestMapping("/v1/admin")
public class AdminController {

    private final ChaosConfig chaosConfig;
    private final RateLimiterRegistry rateLimiterRegistry;

    public AdminController(ChaosConfig chaosConfig, RateLimiterRegistry rateLimiterRegistry) {
        this.chaosConfig = chaosConfig;
        this.rateLimiterRegistry = rateLimiterRegistry;
    }

    public record ChaosRequest(String mode, Integer failTimes, String targetModel) {
    }

    @PostMapping("/chaos")
    public ApiResponse<Map<String, Object>> enable(@RequestBody(required = false) ChaosRequest request) {
        String mode = request == null || request.mode() == null ? ChaosConfig.SERVER_ERROR : request.mode();
        int failTimes = request == null || request.failTimes() == null ? 2 : request.failTimes();
        String target = request == null ? null : request.targetModel();
        chaosConfig.enable(mode, failTimes, target);
        return ApiResponse.ok(Map.of(
                "mode", chaosConfig.mode(),
                "failTimes", chaosConfig.failTimes(),
                "targetModel", chaosConfig.targetModel()));
    }

    @DeleteMapping("/chaos")
    public ApiResponse<Map<String, Object>> disable() {
        chaosConfig.disable();
        return ApiResponse.ok(Map.of("mode", chaosConfig.mode()));
    }

    @GetMapping("/chaos")
    public ApiResponse<Map<String, Object>> status() {
        return ApiResponse.ok(Map.of(
                "mode", chaosConfig.mode(),
                "failTimes", chaosConfig.failTimes(),
                "targetModel", chaosConfig.targetModel(),
                "triggered", chaosConfig.triggered()));
    }

    /** 把限流桶灌满，方便反复演示 429 */
    @PostMapping("/rate-limit/refill")
    public ApiResponse<Map<String, Object>> refill() {
        rateLimiterRegistry.refillAll();
        return ApiResponse.ok(Map.of("refilled", true, "buckets", rateLimiterRegistry.snapshot()));
    }

    @GetMapping("/rate-limit")
    public ApiResponse<Map<String, Object>> rateLimit() {
        return ApiResponse.ok(rateLimiterRegistry.snapshot());
    }
}
