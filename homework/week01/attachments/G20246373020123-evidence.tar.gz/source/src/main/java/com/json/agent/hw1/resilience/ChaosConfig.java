package com.json.agent.hw1.resilience;

import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

/**
 * 故障注入开关（仅用于验证重试策略，默认关闭）。
 *
 * <p>真实上游不会按我们的意愿挂掉，所以提供一个可运行时开启的注入点：
 * 让指定 model 的前 N 次调用按指定模式失败，从而可复现地观测退避重试。
 */
@Component
public class ChaosConfig {

    public static final String OFF = "off";
    public static final String TIMEOUT = "timeout";
    public static final String SERVER_ERROR = "server_error";
    public static final String RATE_LIMIT = "rate_limit";
    public static final String BAD_JSON = "bad_json";
    public static final String NETWORK = "network";

    private volatile String mode = OFF;
    private volatile int failTimes = 0;
    private volatile String targetModel = "*";
    private final AtomicInteger triggered = new AtomicInteger();

    /**
     * 判断本次调用是否要注入失败。命中时计数 +1，用完 failTimes 次后自动停止注入。
     */
    public boolean shouldFail(String model) {
        String m = mode;
        if (OFF.equalsIgnoreCase(m) || failTimes <= 0) {
            return false;
        }
        if (!"*".equals(targetModel) && !targetModel.equalsIgnoreCase(model)) {
            return false;
        }
        if (triggered.getAndIncrement() < failTimes) {
            return true;
        }
        return false;
    }

    public LlmException exceptionFor(String model) {
        String detail = "chaos 注入失败（model=" + model + ", mode=" + mode + "）";
        return switch (mode == null ? OFF : mode.toLowerCase()) {
            case TIMEOUT -> new LlmException(ErrorCode.UPSTREAM_TIMEOUT, detail);
            case SERVER_ERROR -> new LlmException(ErrorCode.UPSTREAM_SERVER_ERROR, detail);
            case RATE_LIMIT -> new LlmException(ErrorCode.UPSTREAM_RATE_LIMIT, detail, 300L, null);
            case BAD_JSON -> new LlmException(ErrorCode.INVALID_JSON_OUTPUT, detail);
            case NETWORK -> new LlmException(ErrorCode.NETWORK_ERROR, detail);
            default -> new LlmException(ErrorCode.UNKNOWN, detail);
        };
    }

    public synchronized void enable(String mode, int failTimes, String targetModel) {
        this.mode = mode == null ? OFF : mode;
        this.failTimes = Math.max(0, failTimes);
        this.targetModel = targetModel == null || targetModel.isBlank() ? "*" : targetModel;
        this.triggered.set(0);
    }

    public synchronized void disable() {
        this.mode = OFF;
        this.failTimes = 0;
        this.targetModel = "*";
        this.triggered.set(0);
    }

    public synchronized String mode() {
        return mode;
    }

    public synchronized int failTimes() {
        return failTimes;
    }

    public synchronized String targetModel() {
        return targetModel;
    }

    public int triggered() {
        return triggered.get();
    }
}
