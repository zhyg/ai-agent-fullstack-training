package com.json.agent.hw1.prompt;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 极简模板引擎：{{var}} 变量替换 + 变量提取。
 */
public final class TemplateRenderer {

    private static final Pattern VAR = Pattern.compile("\\{\\{\\s*([A-Za-z0-9_.-]+)\\s*\\}\\}");

    private TemplateRenderer() {
    }

    /** 提取模板里出现过的所有变量名（去重、保序）。 */
    public static Set<String> extractVariables(String template) {
        Set<String> vars = new LinkedHashSet<>();
        if (template == null) {
            return vars;
        }
        Matcher m = VAR.matcher(template);
        while (m.find()) {
            vars.add(m.group(1));
        }
        return vars;
    }

    /**
     * 渲染。strict=true 时，缺失变量直接报错（快速失败，别把 {{xxx}} 原样发给模型）。
     */
    public static String render(String template, Map<String, Object> variables, boolean strict) {
        if (template == null) {
            return "";
        }
        Map<String, Object> vars = variables == null ? Map.of() : variables;
        Matcher m = VAR.matcher(template);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String name = m.group(1);
            Object value = vars.get(name);
            if (value == null) {
                if (strict) {
                    throw new IllegalArgumentException("模板变量缺失: " + name);
                }
                value = "";
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf(value)));
        }
        m.appendTail(sb);
        return sb.toString();
    }
}
