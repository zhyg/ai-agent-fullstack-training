package com.json.agent.hw1.observe;

import com.json.agent.hw1.contract.Timings;
import com.json.agent.hw1.contract.TokenUsage;

/**
 * 单次调用的全量留痕，可观测性的最小事实单元（对应课件里的 Event Store 雏形）。
 */
public record CallRecord(
        String requestId,
        long timestamp,
        String model,
        String adapter,
        boolean stream,
        boolean structured,
        String templateRef,
        TokenUsage usage,
        Timings timings,
        boolean success,
        String errorCode,
        int attempts,
        long backoffMs
) {
}
