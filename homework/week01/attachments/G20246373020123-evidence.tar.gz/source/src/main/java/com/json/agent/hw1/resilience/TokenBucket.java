package com.json.agent.hw1.resilience;

/**
 * 自研令牌桶（零依赖）。按模型独立实例，因此互不限流。
 */
public final class TokenBucket {

    private final double capacity;
    private final double refillPerSecond;
    private double tokens;
    private long lastRefillNanos;

    public TokenBucket(double capacity, double refillPerSecond) {
        this(capacity, refillPerSecond, capacity);
    }

    public TokenBucket(double capacity, double refillPerSecond, double initialTokens) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("capacity 必须 > 0");
        }
        this.capacity = capacity;
        this.refillPerSecond = Math.max(0, refillPerSecond);
        this.tokens = Math.min(initialTokens, capacity);
        this.lastRefillNanos = System.nanoTime();
    }

    /** 非阻塞取一个令牌，取不到立即返回 false（调用方据此返回 429）。 */
    public synchronized boolean tryAcquire() {
        refill();
        if (tokens >= 1.0d) {
            tokens -= 1.0d;
            return true;
        }
        return false;
    }

    public synchronized double available() {
        refill();
        return tokens;
    }

    public synchronized void refillToFull() {
        tokens = capacity;
        lastRefillNanos = System.nanoTime();
    }

    public double capacity() {
        return capacity;
    }

    public double refillPerSecond() {
        return refillPerSecond;
    }

    private void refill() {
        long now = System.nanoTime();
        long elapsedNanos = now - lastRefillNanos;
        if (elapsedNanos <= 0) {
            return;
        }
        double add = elapsedNanos / 1_000_000_000.0d * refillPerSecond;
        if (add > 0) {
            tokens = Math.min(capacity, tokens + add);
            lastRefillNanos = now;
        }
    }
}
