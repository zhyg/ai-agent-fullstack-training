package com.json.agent.hw1.config;

import java.net.http.HttpClient;
import java.time.Duration;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * 作业相关 Bean 装配。
 */
@Configuration
@EnableConfigurationProperties(LlmProperties.class)
public class AppConfig {

    @Bean
    public HttpClient hw1HttpClient(LlmProperties properties) {
        return HttpClient.newBuilder()
                .connectTimeout(properties.connectTimeout() == null
                        ? Duration.ofSeconds(10)
                        : properties.connectTimeout())
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    /** SSE 需要异步线程，不能占用 Tomcat 的 worker 线程。 */
    @Bean("hw1SseExecutor")
    public TaskExecutor hw1SseExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(8);
        executor.setMaxPoolSize(32);
        executor.setQueueCapacity(256);
        executor.setThreadNamePrefix("hw1-sse-");
        executor.initialize();
        return executor;
    }
}
