package com.json.agent.hw1.adapter;

import java.net.http.HttpClient;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.agent.hw1.contract.ChatMessage;
import com.json.agent.hw1.contract.ChatRole;
import com.json.agent.hw1.contract.ResponseFormat;
import com.json.agent.hw1.contract.Timings;
import com.json.agent.hw1.contract.TokenUsage;
import com.json.agent.hw1.contract.UnifiedResponse;
import com.json.agent.hw1.resilience.ErrorCode;

/**
 * OpenAI Responses 协议适配器（deepseek-v4-pro）。
 *
 * <p>协议特征：
 * <ul>
 *   <li>鉴权：Authorization: Bearer</li>
 *   <li>请求体：instructions（≈system） + input[] + text.format（结构化原生支持）</li>
 *   <li>响应：output[] 里混有 reasoning / message 块，只取 message 下的 output_text</li>
 *   <li>usage：input_tokens / output_tokens / total_tokens + input_tokens_details.cached_tokens
 *            + output_tokens_details.reasoning_tokens</li>
 * </ul>
 */
@Component("openai-responses")
public class OpenAiResponsesAdapter extends AbstractHttpAdapter {

    public OpenAiResponsesAdapter(HttpClient httpClient, ObjectMapper mapper) {
        super(httpClient, mapper);
    }

    @Override
    public String name() {
        return "openai-responses";
    }

    @Override
    public String protocol() {
        return "OpenAI Responses API (POST /responses, Bearer 鉴权, text.format 原生结构化)";
    }

    // ------------------------------------------------------------------ 非流式

    @Override
    public UnifiedResponse call(AdapterContext ctx) {
        long start = System.currentTimeMillis();
        String raw = post(ctx, buildBody(ctx, false), headers(ctx));
        JsonNode root = readTree(raw);
        if (root == null) {
            throw new com.json.agent.hw1.resilience.LlmException(
                    ErrorCode.UPSTREAM_BAD_RESPONSE, "上游返回不是合法 JSON: " + abbreviate(raw));
        }
        String text = extractText(root);
        TokenUsage usage = extractUsage(root);
        if (ctx.responseFormat() != null && ctx.responseFormat().isJson()) {
            parseJsonStrictly(text); // 结构化输出契约校验，不合法直接抛 INVALID_JSON_OUTPUT
        }
        long total = System.currentTimeMillis() - start;
        return new UnifiedResponse(
                ctx.requestId(),
                ctx.model(),
                name(),
                text,
                ctx.responseFormat() != null && ctx.responseFormat().isJson() ? parseJsonStrictly(text) : null,
                usage,
                new Timings(start, 0, Timings.NA, total),
                1,
                ctx.templateRef());
    }

    // ------------------------------------------------------------------ 流式

    @Override
    public void stream(AdapterContext ctx, StreamSink sink) {
        Map<String, Object> body = buildBody(ctx, true);
        final TokenUsage[] finalUsage = new TokenUsage[]{null};
        final StringBuilder deltaBuffer = new StringBuilder();
        try {
            postStream(ctx, body, headers(ctx), (event, data) -> {
                if (data == null || data.isBlank() || "[DONE]".equals(data.trim())) {
                    return;
                }
                JsonNode node = readTree(data);
                if (node == null || !node.isObject()) {
                    return;
                }
                String type = node.path("type").asText("");
                if (type.endsWith(".delta") && !type.contains("reasoning")) {
                    String delta = node.path("delta").asText("");
                    if (!delta.isEmpty()) {
                        deltaBuffer.append(delta);
                        sink.onDelta(delta);
                    }
                } else if ("response.completed".equals(type) || "response.done".equals(type)) {
                    JsonNode resp = node.path("response");
                    finalUsage[0] = extractUsage(resp.isMissingNode() ? node : resp);
                } else if (type.contains("failed") || "error".equals(type)) {
                    JsonNode err = node.path("error");
                    sink.onError(ErrorCode.UPSTREAM_SERVER_ERROR,
                            "上游流式返回错误: " + abbreviate(err.isMissingNode() ? node.toString() : err.toString()));
                }
            });
            TokenUsage usage = finalUsage[0] == null ? TokenUsage.EMPTY : finalUsage[0];
            if (ctx.responseFormat() != null && ctx.responseFormat().isJson()) {
                parseJsonStrictly(deltaBuffer.toString());
            }
            sink.onDone(usage);
        } catch (com.json.agent.hw1.resilience.LlmException e) {
            log.warn("[hw1][{}] 流式调用失败: {}", name(), e.getMessage());
            sink.onError(e.errorCode(), e.getMessage());
        } catch (RuntimeException e) {
            log.warn("[hw1][{}] 流式调用异常: {}", name(), e.getMessage(), e);
            sink.onError(ErrorCode.UNKNOWN, e.getMessage());
        }
    }

    // ------------------------------------------------------------------ 报文构造

    private Map<String, String> headers(AdapterContext ctx) {
        return Map.of("Authorization", "Bearer " + ctx.apiKey());
    }

    private Map<String, Object> buildBody(AdapterContext ctx, boolean stream) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", ctx.upstreamModel());
        body.put("stream", stream);

        String instructions = ctx.systemOrEmpty();
        ResponseFormat format = ctx.responseFormat();
        if (format != null && format.isJson()) {
            instructions = instructions + jsonInstruction(format);
        }
        if (!instructions.isBlank()) {
            body.put("instructions", instructions);
        }

        List<Map<String, Object>> input = new ArrayList<>();
        for (ChatMessage m : ctx.messages()) {
            if (m.role() == ChatRole.SYSTEM) {
                continue; // system 已进 instructions
            }
            input.add(Map.of("role", m.role().value(), "content", m.content()));
        }
        body.put("input", input);

        if (ctx.temperature() != null) {
            body.put("temperature", ctx.temperature());
        }
        if (ctx.maxTokens() != null && ctx.maxTokens() > 0) {
            body.put("max_output_tokens", ctx.maxTokens());
        }
        if (format != null && format.isJson()) {
            Map<String, Object> fmt = new LinkedHashMap<>();
            if (format.isJsonSchema()) {
                fmt.put("type", ResponseFormat.JSON_SCHEMA);
                fmt.put("name", format.name() == null ? "structured_output" : format.name());
                fmt.put("schema", format.schema());
            } else {
                fmt.put("type", ResponseFormat.JSON_OBJECT);
            }
            body.put("text", Map.of("format", fmt));
        }
        return body;
    }

    // ------------------------------------------------------------------ 解析

    /** output[].content[] 里只取 type=message 下的 output_text，跳过 reasoning 块。 */
    protected String extractText(JsonNode root) {
        StringBuilder sb = new StringBuilder();
        JsonNode output = root.path("output");
        if (output.isArray()) {
            for (JsonNode item : output) {
                if (!"message".equals(item.path("type").asText())) {
                    continue;
                }
                for (JsonNode part : item.path("content")) {
                    if ("output_text".equals(part.path("type").asText())) {
                        sb.append(part.path("text").asText(""));
                    }
                }
            }
        }
        if (sb.length() == 0) {
            sb.append(root.path("output_text").asText(""));
        }
        return sb.toString();
    }

    protected TokenUsage extractUsage(JsonNode root) {
        JsonNode u = root.path("usage");
        int prompt = u.path("input_tokens").asInt();
        int completion = u.path("output_tokens").asInt();
        int total = u.path("total_tokens").asInt();
        int cached = u.path("input_tokens_details").path("cached_tokens").asInt();
        int reasoning = u.path("output_tokens_details").path("reasoning_tokens").asInt();
        return new TokenUsage(prompt, completion, total, cached, reasoning);
    }

    private JsonNode readTree(String raw) {
        try {
            return mapper.readTree(raw);
        } catch (Exception e) {
            return null;
        }
    }
}
