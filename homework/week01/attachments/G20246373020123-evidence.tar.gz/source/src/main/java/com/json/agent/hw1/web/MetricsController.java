package com.json.agent.hw1.web;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.json.agent.hw1.observe.CallRecord;
import com.json.agent.hw1.observe.MetricsCollector;
import com.json.agent.hw1.observe.MetricsSnapshot;

/**
 * 可观测性出口：Token 分类统计 + 延迟（含首 Token 延迟）。
 */
@RestController
@RequestMapping("/v1/metrics")
public class MetricsController {

    private final MetricsCollector collector;

    public MetricsController(MetricsCollector collector) {
        this.collector = collector;
    }

    @GetMapping
    public ApiResponse<MetricsSnapshot> snapshot() {
        return ApiResponse.ok(collector.snapshot());
    }

    /** 最近 N 条调用明细，每条含 token 分类、TTFT、总耗时、重试次数 */
    @GetMapping("/records")
    public ApiResponse<Map<String, Object>> records(@RequestParam(defaultValue = "20") int limit) {
        List<CallRecord> recent = collector.recent(limit);
        return ApiResponse.ok(Map.of("count", recent.size(), "records", recent));
    }

    @PostMapping("/reset")
    public ApiResponse<Map<String, Object>> reset() {
        collector.reset();
        return ApiResponse.ok(Map.of("reset", true));
    }
}
