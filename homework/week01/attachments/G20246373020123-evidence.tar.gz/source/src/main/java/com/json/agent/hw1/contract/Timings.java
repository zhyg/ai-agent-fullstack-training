package com.json.agent.hw1.contract;

/**
 * 延迟数据。
 *
 * <ul>
 *   <li>ttftMs —— 首 Token 延迟（Time To First Token）：从发起请求到收到第一个内容分片</li>
 *   <li>totalMs —— 端到端总耗时</li>
 * </ul>
 * 非流式调用没有中间分片，ttftMs 记为 -1（不参与平均 TTFT 统计）。
 */
public record Timings(long startEpochMs, long queueMs, long ttftMs, long totalMs) {

    public static final long NA = -1L;

    public boolean hasTtft() {
        return ttftMs >= 0;
    }
}
