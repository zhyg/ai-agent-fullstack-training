package com.json.agent.hw1.prompt;

import java.util.List;

/**
 * 提示词模板。同名模板可有多版本，version 单调递增。
 */
public record PromptTemplate(
        String name,
        int version,
        String content,
        List<String> variables,
        String description,
        long updatedAt
) {

    public PromptTemplate {
        if (variables == null) {
            variables = List.of();
        }
    }

    public String key() {
        return key(name, version);
    }

    public static String key(String name, int version) {
        return name + "@" + version;
    }
}
