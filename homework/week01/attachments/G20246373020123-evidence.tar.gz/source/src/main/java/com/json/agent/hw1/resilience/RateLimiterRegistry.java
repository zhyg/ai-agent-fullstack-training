package com.json.agent.hw1.resilience;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

import com.json.agent.hw1.config.LlmProperties;

/**
 * 按模型独立限流：每个 model 一个令牌桶，A 打满不会影响 B。
 */
@Component
public class RateLimiterRegistry {

    private final Map<String, TokenBucket> buckets = new ConcurrentHashMap<>();
    private final LlmProperties.RateLimitConfig defaultConfig;

    public RateLimiterRegistry(LlmProperties properties) {
        LlmProperties.RateLimitConfig cfg = properties.rateLimit();
        this.defaultConfig = cfg == null ? new LlmProperties.RateLimitConfig(10, 1.0d) : cfg;
        // 预热：配置里的模型先建桶，避免首次请求才初始化
        properties.modelsOrEmpty().forEach((model, mc) -> bucketFor(model, mc));
    }

    public TokenBucket bucketFor(String model, LlmProperties.ModelConfig modelConfig) {
        return buckets.computeIfAbsent(model, key -> {
            LlmProperties.RateLimitConfig cfg = modelConfig != null && modelConfig.rateLimit() != null
                    ? modelConfig.rateLimit()
                    : defaultConfig;
            return new TokenBucket(cfg.capacity(), cfg.refillPerSecond());
        });
    }

    /**
     * @throws LlmException RATE_LIMITED(429) 当该模型令牌不足
     */
    public void acquire(String model, LlmProperties.ModelConfig modelConfig) {
        TokenBucket bucket = bucketFor(model, modelConfig);
        if (!bucket.tryAcquire()) {
            throw new LlmException(ErrorCode.RATE_LIMITED,
                    "模型 [" + model + "] 触发本地限流：容量 " + bucket.capacity()
                            + "，补充速率 " + bucket.refillPerSecond() + "/s");
        }
    }

    public Map<String, Object> snapshot() {
        Map<String, Object> view = new LinkedHashMap<>();
        buckets.forEach((model, bucket) -> {
            Map<String, Object> one = new LinkedHashMap<>();
            one.put("availableTokens", Math.round(bucket.available() * 100.0d) / 100.0d);
            one.put("capacity", bucket.capacity());
            one.put("refillPerSecond", bucket.refillPerSecond());
            view.put(model, one);
        });
        return view;
    }

    public void refillAll() {
        buckets.values().forEach(TokenBucket::refillToFull);
    }
}
