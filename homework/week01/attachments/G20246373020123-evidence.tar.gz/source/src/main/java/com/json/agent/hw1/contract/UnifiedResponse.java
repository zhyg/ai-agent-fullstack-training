package com.json.agent.hw1.contract;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * 统一调用响应。调用方拿到的结构与上游协议无关。
 */
public record UnifiedResponse(
        String requestId,
        String model,
        String adapter,
        String text,
        JsonNode json,
        TokenUsage usage,
        Timings timings,
        int attempts,
        String templateRef
) {

    public UnifiedResponse withAttempts(int attempts) {
        return new UnifiedResponse(requestId, model, adapter, text, json, usage, timings, attempts, templateRef);
    }

    public UnifiedResponse withTimings(Timings timings) {
        return new UnifiedResponse(requestId, model, adapter, text, json, usage, timings, attempts, templateRef);
    }
}
