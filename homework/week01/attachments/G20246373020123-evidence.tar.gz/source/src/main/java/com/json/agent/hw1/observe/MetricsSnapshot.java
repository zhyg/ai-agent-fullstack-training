package com.json.agent.hw1.observe;

import java.util.Map;

/**
 * 全局指标快照。
 */
public record MetricsSnapshot(
        long totalCalls,
        long totalSuccess,
        long totalFailures,
        long promptTokens,
        long completionTokens,
        long totalTokens,
        long cachedTokens,
        long reasoningTokens,
        double avgLatencyMs,
        double avgTtftMs,
        Map<String, ModelStats> byModel,
        int retainedRecords,
        Map<String, Object> rateLimiters
) {
}
