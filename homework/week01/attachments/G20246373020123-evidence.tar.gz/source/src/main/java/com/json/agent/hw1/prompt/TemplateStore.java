package com.json.agent.hw1.prompt;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.json.agent.hw1.config.LlmProperties;

/**
 * 模板存储：内存为主 + JSON 文件持久化。同名模板保存即升版本，历史版本可按 name@version 引用。
 */
@Component
public class TemplateStore {

    private static final Logger log = LoggerFactory.getLogger(TemplateStore.class);

    private final Map<String, PromptTemplate> store = new ConcurrentHashMap<>();
    private final Map<String, Integer> latestVersion = new ConcurrentHashMap<>();
    private final Path file;
    private final ObjectMapper mapper = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT);

    public TemplateStore(LlmProperties properties) {
        String configured = properties.templateFile();
        this.file = Paths.get(configured == null || configured.isBlank()
                ? "./data/hw1-templates.json"
                : configured);
        load();
        if (store.isEmpty()) {
            seed();
        }
    }

    /** 保存即升版本，返回新版本模板。 */
    public synchronized PromptTemplate create(String name, String content, List<String> variables,
                                              String description) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("模板名不能为空");
        }
        if (content == null || content.isBlank()) {
            throw new IllegalArgumentException("模板内容不能为空");
        }
        int version = latestVersion.getOrDefault(name, 0) + 1;
        List<String> vars = variables == null || variables.isEmpty()
                ? new ArrayList<>(TemplateRenderer.extractVariables(content))
                : variables;
        PromptTemplate template = new PromptTemplate(name, version, content, vars,
                description, System.currentTimeMillis());
        store.put(template.key(), template);
        latestVersion.put(name, version);
        save();
        return template;
    }

    public Optional<PromptTemplate> get(String name, int version) {
        return Optional.ofNullable(store.get(PromptTemplate.key(name, version)));
    }

    public Optional<PromptTemplate> getLatest(String name) {
        Integer v = latestVersion.get(name);
        return v == null ? Optional.empty() : get(name, v);
    }

    public Optional<PromptTemplate> resolve(TemplateRef ref) {
        return ref.version() == null ? getLatest(ref.name()) : get(ref.name(), ref.version());
    }

    public List<PromptTemplate> list() {
        return store.values().stream()
                .sorted(Comparator.comparing(PromptTemplate::name).thenComparing(PromptTemplate::version))
                .toList();
    }

    public Map<String, Integer> latestVersions() {
        return Map.copyOf(latestVersion);
    }

    public Path file() {
        return file;
    }

    public synchronized void reload() {
        store.clear();
        latestVersion.clear();
        load();
    }

    private void load() {
        if (!Files.exists(file)) {
            return;
        }
        try {
            String json = Files.readString(file, StandardCharsets.UTF_8);
            if (json.isBlank()) {
                return;
            }
            List<PromptTemplate> templates = mapper.readValue(json, new TypeReference<>() {
            });
            for (PromptTemplate t : templates) {
                store.put(t.key(), t);
                latestVersion.merge(t.name(), t.version(), Math::max);
            }
            log.info("[hw1] 已加载 {} 个提示词模板: {}", store.size(), file.toAbsolutePath());
        } catch (IOException e) {
            throw new UncheckedIOException("加载模板文件失败: " + file.toAbsolutePath(), e);
        }
    }

    private void save() {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(file, mapper.writeValueAsString(list()), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("保存模板文件失败: " + file.toAbsolutePath(), e);
        }
    }

    /** 首次启动没有模板文件时，内置两个示例模板，保证开箱可演示。 */
    private void seed() {
        create("code-review",
                "你是资深 Java 代码评审专家。\n请评审以下代码，只输出 JSON，不要任何解释文字。\n\n"
                        + "语言：{{language}}\n关注点：{{focus}}\n\n代码：\n```\n{{code}}\n```\n",
                List.of("language", "focus", "code"),
                "代码评审模板（v1：三字段 + JSON 输出）");
        create("translate",
                "把下面的内容翻译成 {{target_lang}}，保持技术术语原文不变：\n\n{{text}}",
                List.of("target_lang", "text"),
                "翻译模板");
        log.info("[hw1] 已初始化内置模板");
    }
}
