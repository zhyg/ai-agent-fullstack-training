package com.json.agent.hw1.observe;

/**
 * 按模型维度的聚合统计（含 Token 分类统计与延迟统计）。
 */
public record ModelStats(
        String model,
        String adapter,
        long calls,
        long success,
        long failures,
        long promptTokens,
        long completionTokens,
        long totalTokens,
        long cachedTokens,
        long reasoningTokens,
        long streamCalls,
        double avgLatencyMs,
        double avgTtftMs,
        long maxLatencyMs,
        long lastTtftMs
) {
}
