package com.json.agent.hw1.adapter;

import com.json.agent.hw1.contract.TokenUsage;

/**
 * 流式回调。适配器把各自协议的 SSE 事件翻译成这三个回调，
 * 上层不感知 event 名差异。
 */
public interface StreamSink {

    void onDelta(String text);

    void onDone(TokenUsage usage);

    void onError(com.json.agent.hw1.resilience.ErrorCode errorCode, String message);
}
