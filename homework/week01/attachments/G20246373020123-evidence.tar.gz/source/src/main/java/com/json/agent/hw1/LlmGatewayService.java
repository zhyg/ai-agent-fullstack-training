package com.json.agent.hw1;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.json.agent.hw1.adapter.AdapterContext;
import com.json.agent.hw1.adapter.AdapterRouter;
import com.json.agent.hw1.adapter.LlmAdapter;
import com.json.agent.hw1.adapter.StreamSink;
import com.json.agent.hw1.config.LlmProperties;
import com.json.agent.hw1.contract.ChatMessage;
import com.json.agent.hw1.contract.ChatRole;
import com.json.agent.hw1.contract.ResponseFormat;
import com.json.agent.hw1.contract.Timings;
import com.json.agent.hw1.contract.TokenUsage;
import com.json.agent.hw1.contract.UnifiedRequest;
import com.json.agent.hw1.contract.UnifiedResponse;
import com.json.agent.hw1.observe.CallRecord;
import com.json.agent.hw1.observe.MetricsCollector;
import com.json.agent.hw1.prompt.PromptTemplate;
import com.json.agent.hw1.prompt.TemplateRef;
import com.json.agent.hw1.prompt.TemplateRenderer;
import com.json.agent.hw1.prompt.TemplateStore;
import com.json.agent.hw1.resilience.ChaosConfig;
import com.json.agent.hw1.resilience.ErrorCode;
import com.json.agent.hw1.resilience.LlmException;
import com.json.agent.hw1.resilience.RateLimiterRegistry;
import com.json.agent.hw1.resilience.RetryPolicy;

/**
 * 统一网关：一次调用的编排在这里闭环。
 *
 * <pre>
 *   模板渲染 → 路由 → 限流 → [重试 × N] → 适配器 → 契约校验 → 埋点
 * </pre>
 *
 * 调用方只见 {@link UnifiedRequest} / {@link UnifiedResponse}，不见任何协议细节。
 */
@Service
public class LlmGatewayService {

    private static final Logger log = LoggerFactory.getLogger(LlmGatewayService.class);

    private final AdapterRouter router;
    private final RateLimiterRegistry rateLimiterRegistry;
    private final RetryPolicy retryPolicy;
    private final ChaosConfig chaosConfig;
    private final MetricsCollector metrics;
    private final TemplateStore templateStore;
    private final LlmProperties properties;

    public LlmGatewayService(AdapterRouter router,
                             RateLimiterRegistry rateLimiterRegistry,
                             LlmProperties properties,
                             MetricsCollector metrics,
                             TemplateStore templateStore,
                             ChaosConfig chaosConfig) {
        this.router = router;
        this.rateLimiterRegistry = rateLimiterRegistry;
        this.properties = properties;
        this.metrics = metrics;
        this.templateStore = templateStore;
        this.chaosConfig = chaosConfig;
        this.retryPolicy = new RetryPolicy(properties.retry());
    }

    public RetryPolicy retryPolicy() {
        return retryPolicy;
    }

    // ------------------------------------------------------------------ 非流式

    public UnifiedResponse chat(UnifiedRequest request) {
        CallCtx ctx = new CallCtx();
        ctx.requestId = requestId(request);
        ctx.model = request.model();
        ctx.startNanos = System.nanoTime();

        try {
            Prepared prepared = prepare(request, ctx);
            AdapterRouter.Resolved resolved = prepared.resolved();
            ctx.adapter = resolved.adapter().name();
            ctx.templateRef = prepared.templateRef();
            ctx.structured = prepared.structured();

            // 1) 按模型独立限流（一次请求取一个令牌，重试不重复取）
            rateLimiterRegistry.acquire(resolved.model(), resolved.config());

            LlmException last = null;
            int max = retryPolicy.maxAttempts();
            for (int attempt = 1; attempt <= max; attempt++) {
                ctx.attempts = attempt;
                try {
                    // 2) 故障注入（仅验证用）
                    if (chaosConfig.shouldFail(resolved.model())) {
                        throw chaosConfig.exceptionFor(resolved.model());
                    }
                    long callStart = System.currentTimeMillis();
                    UnifiedResponse response = resolved.adapter().call(buildContext(request, prepared, false));
                    long total = System.currentTimeMillis() - callStart;
                    UnifiedResponse result = response
                            .withAttempts(attempt)
                            .withTimings(new Timings(callStart, 0, Timings.NA, total));
                    record(ctx, result.usage(), true, ErrorCode.OK, result.timings().totalMs());
                    return result;
                } catch (LlmException e) {
                    last = e;
                    if (!e.errorCode().retryable() || attempt >= max) {
                        break;
                    }
                    long backoff = retryPolicy.backoffMs(attempt, e.retryAfterMs());
                    ctx.backoffMs += backoff;
                    log.warn("[hw1] 调用失败 model={} attempt={}/{} code={} 退避{}ms 原因={}",
                            resolved.model(), attempt, max, e.errorCode(), backoff, e.getMessage());
                    retryPolicy.sleepQuietly(backoff);
                }
            }
            record(ctx, TokenUsage.EMPTY, false,
                    last == null ? ErrorCode.UNKNOWN : last.errorCode(), elapsedMs(ctx.startNanos));
            throw last == null ? new LlmException(ErrorCode.UNKNOWN, "调用失败") : last;
        } catch (LlmException e) {
            if (ctx.attempts == 0) {
                ctx.attempts = 1;
            }
            if (ctx.adapter == null) {
                ctx.adapter = "unresolved";
            }
            record(ctx, TokenUsage.EMPTY, false, e.errorCode(), elapsedMs(ctx.startNanos));
            throw e;
        } catch (IllegalArgumentException e) {
            record(ctx, TokenUsage.EMPTY, false, ErrorCode.BAD_REQUEST, elapsedMs(ctx.startNanos));
            throw new LlmException(ErrorCode.BAD_REQUEST, e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------------ 流式

    /**
     * 流式调用。重试只在"还没吐出任何内容"时发生——一旦已经有分片发给客户端，
     * 重试会造成内容重复，此时直接报错终止。
     */
    public void stream(UnifiedRequest request, StreamSink out) {
        CallCtx ctx = new CallCtx();
        ctx.requestId = requestId(request);
        ctx.model = request.model();
        ctx.stream = true;
        ctx.startNanos = System.nanoTime();

        try {
            Prepared prepared = prepare(request, ctx);
            AdapterRouter.Resolved resolved = prepared.resolved();
            ctx.adapter = resolved.adapter().name();
            ctx.templateRef = prepared.templateRef();
            ctx.structured = prepared.structured();

            rateLimiterRegistry.acquire(resolved.model(), resolved.config());

            int max = retryPolicy.maxAttempts();
            for (int attempt = 1; attempt <= max; attempt++) {
                ctx.attempts = attempt;
                AttemptSink attemptSink = new AttemptSink(out, ctx);

                if (chaosConfig.shouldFail(resolved.model())) {
                    LlmException injected = chaosConfig.exceptionFor(resolved.model());
                    attemptSink.error = injected.errorCode();
                    attemptSink.message = injected.getMessage();
                    attemptSink.retryAfterMs = injected.retryAfterMs();
                } else {
                    resolved.adapter().stream(buildContext(request, prepared, true), attemptSink);
                }

                if (attemptSink.error == null) {
                    TokenUsage usage = attemptSink.usage == null ? TokenUsage.EMPTY : attemptSink.usage;
                    out.onDone(usage);
                    record(ctx, usage, true, ErrorCode.OK, elapsedMs(ctx.startNanos));
                    return;
                }

                boolean canRetry = !attemptSink.emitted
                        && attemptSink.error.retryable()
                        && attempt < max;
                if (!canRetry) {
                    out.onError(attemptSink.error, attemptSink.message);
                    record(ctx, TokenUsage.EMPTY, false, attemptSink.error, elapsedMs(ctx.startNanos));
                    return;
                }
                long backoff = retryPolicy.backoffMs(attempt, attemptSink.retryAfterMs);
                ctx.backoffMs += backoff;
                log.warn("[hw1] 流式失败 model={} attempt={}/{} code={} 退避{}ms 原因={}",
                        resolved.model(), attempt, max, attemptSink.error, backoff, attemptSink.message);
                retryPolicy.sleepQuietly(backoff);
            }
            out.onError(ErrorCode.UNKNOWN, "流式调用失败");
            record(ctx, TokenUsage.EMPTY, false, ErrorCode.UNKNOWN, elapsedMs(ctx.startNanos));
        } catch (LlmException e) {
            if (ctx.attempts == 0) {
                ctx.attempts = 1;
            }
            if (ctx.adapter == null) {
                ctx.adapter = "unresolved";
            }
            record(ctx, TokenUsage.EMPTY, false, e.errorCode(), elapsedMs(ctx.startNanos));
            throw e;
        } catch (IllegalArgumentException e) {
            record(ctx, TokenUsage.EMPTY, false, ErrorCode.BAD_REQUEST, elapsedMs(ctx.startNanos));
            throw new LlmException(ErrorCode.BAD_REQUEST, e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------------ 准备阶段

    private Prepared prepare(UnifiedRequest request, CallCtx ctx) {
        AdapterRouter.Resolved resolved = router.resolve(request.model());
        ctx.model = resolved.model();

        StringBuilder systemFromMessages = new StringBuilder();
        List<ChatMessage> conversation = new ArrayList<>();
        for (ChatMessage m : request.messagesOrEmpty()) {
            if (m.role() == ChatRole.SYSTEM) {
                if (systemFromMessages.length() > 0) {
                    systemFromMessages.append('\n');
                }
                systemFromMessages.append(m.content());
            } else {
                conversation.add(m);
            }
        }

        String templateRef = null;
        String system = systemFromMessages.toString();

        if (request.template() != null) {
            String name = request.template().name();
            Integer version = request.template().version();
            if (version == null) {
                TemplateRef parsed = TemplateRef.parse(name);
                name = parsed.name();
                version = parsed.version();
            }
            PromptTemplate template = version == null
                    ? templateStore.getLatest(name).orElse(null)
                    : templateStore.get(name, version).orElse(null);
            if (template == null) {
                throw new LlmException(ErrorCode.TEMPLATE_NOT_FOUND,
                        "提示词模板不存在: " + name + (version == null ? "" : "@" + version));
            }
            String rendered;
            try {
                rendered = TemplateRenderer.render(template.content(), request.template().variables(), true);
            } catch (IllegalArgumentException e) {
                throw new LlmException(ErrorCode.TEMPLATE_VAR_MISSING, e.getMessage(), e);
            }
            system = rendered + (system.isBlank() ? "" : "\n" + system);
            templateRef = name + "@" + template.version();
        }

        if (conversation.isEmpty() && templateRef == null) {
            throw new LlmException(ErrorCode.EMPTY_MESSAGE, "messages 与 template 不能同时为空");
        }
        if (conversation.isEmpty()) {
            conversation.add(ChatMessage.user("请按上述要求执行。"));
        }

        ResponseFormat format = request.formatOrText();
        return new Prepared(resolved, system, List.copyOf(conversation), templateRef, format.isJson(), format);
    }

    private AdapterContext buildContext(UnifiedRequest request, Prepared prepared, boolean stream) {
        AdapterRouter.Resolved resolved = prepared.resolved();
        LlmProperties.ModelConfig config = resolved.config();
        String upstream = config.upstream() == null || config.upstream().isBlank()
                ? resolved.model()
                : config.upstream();
        Integer maxTokens = request.maxTokens() != null && request.maxTokens() > 0
                ? request.maxTokens()
                : config.defaultMaxTokens();
        Duration timeout = properties.requestTimeout() == null
                ? Duration.ofSeconds(120)
                : properties.requestTimeout();
        return new AdapterContext(
                prepared.resolved().model() + "-" + UUID.randomUUID().toString().substring(0, 8),
                resolved.model(),
                upstream,
                config.endpoint(),
                properties.apiKey(),
                timeout,
                prepared.system(),
                prepared.messages(),
                prepared.format(),
                request.temperature(),
                maxTokens,
                stream,
                prepared.templateRef());
    }

    // ------------------------------------------------------------------ 埋点

    private void record(CallCtx ctx, TokenUsage usage, boolean success, ErrorCode code, long totalMs) {
        metrics.record(new CallRecord(
                ctx.requestId,
                System.currentTimeMillis(),
                ctx.model,
                ctx.adapter == null ? "unresolved" : ctx.adapter,
                ctx.stream,
                ctx.structured,
                ctx.templateRef,
                usage,
                new Timings(System.currentTimeMillis(), 0, ctx.ttftMs, totalMs),
                success,
                code.name(),
                ctx.attempts == 0 ? 1 : ctx.attempts,
                ctx.backoffMs));
    }

    private static long elapsedMs(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000L;
    }

    private String requestId(UnifiedRequest request) {
        return request.requestId() == null || request.requestId().isBlank()
                ? "req-" + UUID.randomUUID().toString().substring(0, 8)
                : request.requestId();
    }

    // ------------------------------------------------------------------ 内部类型

    private record Prepared(AdapterRouter.Resolved resolved, String system, List<ChatMessage> messages,
                            String templateRef, boolean structured, ResponseFormat format) {
    }

    private static final class CallCtx {
        String requestId;
        String model;
        String adapter;
        String templateRef;
        boolean stream;
        boolean structured;
        int attempts;
        long backoffMs;
        long startNanos;
        long ttftMs = Timings.NA;
    }

    /** 单次尝试的 sink：记录是否已吐出内容（决定能否重试）与首 Token 延迟。 */
    private static final class AttemptSink implements StreamSink {
        private final StreamSink out;
        private final CallCtx ctx;
        volatile boolean emitted;
        volatile ErrorCode error;
        volatile String message;
        volatile Long retryAfterMs;
        volatile TokenUsage usage;

        AttemptSink(StreamSink out, CallCtx ctx) {
            this.out = out;
            this.ctx = ctx;
        }

        @Override
        public void onDelta(String text) {
            if (!emitted) {
                emitted = true;
                ctx.ttftMs = elapsedMs(ctx.startNanos);
            }
            out.onDelta(text);
        }

        @Override
        public void onDone(TokenUsage u) {
            usage = u;
        }

        @Override
        public void onError(ErrorCode errorCode, String msg) {
            error = errorCode;
            message = msg;
        }
    }
}
