package com.json.agent.hw1.config;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 作业配置。model -> 适配器 + 上游端点 的映射全部外置，换协议不改代码。
 */
@ConfigurationProperties(prefix = "hw1")
public record LlmProperties(
        String apiKey,
        Duration connectTimeout,
        Duration requestTimeout,
        RetryConfig retry,
        RateLimitConfig rateLimit,
        Map<String, ModelConfig> models,
        String templateFile,
        int metricsRetention
) {

    public record RetryConfig(
            int maxAttempts,
            long initialBackoffMs,
            double multiplier,
            long maxBackoffMs,
            double jitterRatio
    ) {
    }

    public record RateLimitConfig(
            int capacity,
            double refillPerSecond
    ) {
    }

    public record ModelConfig(
            String adapter,
            String upstream,
            String endpoint,
            String protocol,
            Integer defaultMaxTokens,
            RateLimitConfig rateLimit
    ) {
    }

    public ModelConfig model(String model) {
        if (models == null) {
            return null;
        }
        return models.get(model);
    }

    public Map<String, ModelConfig> modelsOrEmpty() {
        return models == null ? new LinkedHashMap<>() : models;
    }
}
