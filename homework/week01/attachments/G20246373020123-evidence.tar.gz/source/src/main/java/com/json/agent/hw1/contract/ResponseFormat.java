package com.json.agent.hw1.contract;

import java.util.Map;

/**
 * 结构化输出约束（统一契约）。
 *
 * <p>两种协议的实现方式不同，这正是适配器要屏蔽的差异：
 * <ul>
 *   <li>OpenAI Responses：原生参数 {@code text.format = {type: json_object | json_schema}}</li>
 *   <li>Anthropic Messages：无此参数，适配器把 JSON Schema 注入 system 提示词并在返回后做 JSON 提取/校验</li>
 * </ul>
 */
public record ResponseFormat(String type, String name, Map<String, Object> schema) {

    public static final String TEXT = "text";
    public static final String JSON_OBJECT = "json_object";
    public static final String JSON_SCHEMA = "json_schema";

    public static ResponseFormat text() {
        return new ResponseFormat(TEXT, null, null);
    }

    public static ResponseFormat jsonObject() {
        return new ResponseFormat(JSON_OBJECT, null, null);
    }

    public boolean isJson() {
        return JSON_OBJECT.equalsIgnoreCase(type) || JSON_SCHEMA.equalsIgnoreCase(type);
    }

    public boolean isJsonSchema() {
        return JSON_SCHEMA.equalsIgnoreCase(type) && schema != null && !schema.isEmpty();
    }
}
