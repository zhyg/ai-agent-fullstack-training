package com.json.agent.hw1.resilience;

/**
 * 统一错误码。所有上游异常在这里被归一，调用方永远只看到这一套码。
 *
 * <p>号段约定：
 * <ul>
 *   <li>4xxxx —— 调用方问题（不重试）</li>
 *   <li>5xxxx —— 上游/网络问题（可重试）</li>
 *   <li>429xx —— 限流（上游限流重试，本地限流不重试）</li>
 * </ul>
 */
public enum ErrorCode {

    OK(0, 200, "ok"),

    /* ---------- 调用方问题：不重试 ---------- */
    BAD_REQUEST(40000, 400, "请求参数错误"),
    MODEL_NOT_SUPPORTED(40001, 400, "不支持的 model，请检查 /v1/models"),
    MODEL_NOT_CONFIGURED(40002, 400, "model 未配置适配器映射"),
    TEMPLATE_NOT_FOUND(40003, 404, "提示词模板不存在"),
    TEMPLATE_VAR_MISSING(40004, 400, "模板变量缺失"),
    EMPTY_MESSAGE(40005, 400, "messages 与 template 不能同时为空"),

    /* ---------- 输出契约问题：可重试（换个采样也许能吐对格式） ---------- */
    INVALID_JSON_OUTPUT(40010, 502, "模型输出不是合法 JSON"),

    /* ---------- 鉴权 ---------- */
    UPSTREAM_AUTH(40100, 401, "上游鉴权失败，检查 api-key"),

    /* ---------- 限流 ---------- */
    RATE_LIMITED(42900, 429, "本地限流：该模型速率超限"),
    UPSTREAM_RATE_LIMIT(42901, 429, "上游限流"),

    /* ---------- 上游/网络：可重试 ---------- */
    UPSTREAM_TIMEOUT(50400, 504, "上游请求超时"),
    UPSTREAM_SERVER_ERROR(50200, 502, "上游服务错误"),
    UPSTREAM_BAD_RESPONSE(50201, 502, "上游响应无法解析"),
    NETWORK_ERROR(50300, 503, "网络异常"),

    UNKNOWN(50000, 500, "未知错误");

    private final int code;
    private final int httpStatus;
    private final String message;

    ErrorCode(int code, int httpStatus, String message) {
        this.code = code;
        this.httpStatus = httpStatus;
        this.message = message;
    }

    public int code() {
        return code;
    }

    public int httpStatus() {
        return httpStatus;
    }

    public String message() {
        return message;
    }

    /**
     * 失败分类处置：超时 / 限流 / 服务端错 / 网络错 / 格式错 → 指数退避重试；
     * 参数类、鉴权类、本地限流 → 快速失败。
     */
    public boolean retryable() {
        return this == UPSTREAM_TIMEOUT
                || this == UPSTREAM_RATE_LIMIT
                || this == UPSTREAM_SERVER_ERROR
                || this == UPSTREAM_BAD_RESPONSE
                || this == NETWORK_ERROR
                || this == INVALID_JSON_OUTPUT;
    }
}
