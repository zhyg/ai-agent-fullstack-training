package com.json.agent.hw1.contract;

import java.util.List;

/**
 * 统一调用请求。调用方只认识这一个结构，不认识任何上游协议。
 */
public record UnifiedRequest(
        String model,
        List<ChatMessage> messages,
        TemplateInvocation template,
        Boolean stream,
        ResponseFormat responseFormat,
        Double temperature,
        Integer maxTokens,
        String requestId
) {

    public boolean isStream() {
        return Boolean.TRUE.equals(stream);
    }

    public List<ChatMessage> messagesOrEmpty() {
        return messages == null ? List.of() : messages;
    }

    public ResponseFormat formatOrText() {
        return responseFormat == null ? ResponseFormat.text() : responseFormat;
    }
}
