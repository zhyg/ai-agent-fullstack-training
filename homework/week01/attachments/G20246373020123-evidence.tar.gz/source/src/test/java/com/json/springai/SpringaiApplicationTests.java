package com.json.springai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.json.agent.SpringaiApplication;

// 启动类在 com.json.agent 包，与本测试包不同，需显式指定
@SpringBootTest(classes = SpringaiApplication.class)
class SpringaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
