package com.json.agent.hw1.resilience;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.json.agent.hw1.config.LlmProperties;

class ResilienceTest {

    @Test
    void tokenBucketExhaustsThenRefills() throws Exception {
        TokenBucket bucket = new TokenBucket(2, 10.0d);
        assertTrue(bucket.tryAcquire());
        assertTrue(bucket.tryAcquire());
        assertFalse(bucket.tryAcquire(), "容量为 2 的桶第三次必须取不到（→ 429）");

        Thread.sleep(250);
        assertTrue(bucket.tryAcquire(), "按 10/s 补充，250ms 后应恢复 1 个令牌");
    }

    @Test
    void backoffGrowsExponentiallyAndIsCapped() {
        RetryPolicy policy = new RetryPolicy(new LlmProperties.RetryConfig(3, 500L, 2.0d, 2000L, 0.0d));
        assertEquals(500L, policy.backoffMs(1, null));
        assertEquals(1000L, policy.backoffMs(2, null));
        assertEquals(2000L, policy.backoffMs(3, null), "超过 maxBackoffMs 后封顶");
        assertEquals(3, policy.maxAttempts());
    }

    @Test
    void upstreamRetryAfterHeaderWins() {
        RetryPolicy policy = new RetryPolicy(new LlmProperties.RetryConfig(3, 500L, 2.0d, 2000L, 0.0d));
        assertEquals(3000L, policy.backoffMs(1, 3000L));
    }

    @Test
    void failureClassification() {
        assertTrue(ErrorCode.UPSTREAM_TIMEOUT.retryable(), "超时 → 重试");
        assertTrue(ErrorCode.UPSTREAM_RATE_LIMIT.retryable(), "限流 → 重试");
        assertTrue(ErrorCode.INVALID_JSON_OUTPUT.retryable(), "格式错 → 重试");
        assertTrue(ErrorCode.UPSTREAM_SERVER_ERROR.retryable(), "5xx → 重试");
        assertFalse(ErrorCode.BAD_REQUEST.retryable(), "参数错 → 不重试");
        assertFalse(ErrorCode.UPSTREAM_AUTH.retryable(), "鉴权错 → 不重试");
        assertFalse(ErrorCode.RATE_LIMITED.retryable(), "本地限流 → 不重试");
        assertEquals(429, ErrorCode.RATE_LIMITED.httpStatus());
    }
}
