package com.json.agent.hw1.adapter;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.http.HttpClient;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.agent.hw1.contract.TokenUsage;

/**
 * 用真实上游报文验证两个适配器的解析逻辑（不联网）。
 * 这是"屏蔽返回格式差异"的硬证据：同一段业务代码，两种报文结构都能解出统一契约。
 */
class ProtocolParsingTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private final OpenAiResponsesAdapter responses =
            new OpenAiResponsesAdapter(HttpClient.newHttpClient(), mapper);
    private final AnthropicMessagesAdapter messages =
            new AnthropicMessagesAdapter(HttpClient.newHttpClient(), mapper);

    /** deepseek-v4-pro（Responses 协议）真实响应，output[] 里混有 reasoning 块 */
    private static final String PRO_RESPONSE = """
            {
              "id": "9a38f6a5-dc7a-4671-94ae-7949930cdf27",
              "object": "response",
              "status": "completed",
              "model": "deepseek-v4-pro",
              "output": [
                {"type": "reasoning", "id": "d299", "status": "completed",
                 "content": [{"type": "reasoning_text", "text": "需要以中文回应"}]},
                {"type": "message", "id": "6eed", "status": "completed", "role": "assistant",
                 "content": [{"type": "output_text", "annotations": [], "text": "你好！有什么我可以帮你的吗？"}]}
              ],
              "usage": {
                "input_tokens": 86,
                "input_tokens_details": {"cached_tokens": 7},
                "output_tokens": 45,
                "output_tokens_details": {"reasoning_tokens": 36},
                "total_tokens": 131
              }
            }
            """;

    /** deepseek-v4-flash（Anthropic 协议）真实响应，content[] 里混有 thinking 块 */
    private static final String FLASH_RESPONSE = """
            {
              "id": "2683ad0c-28a9-480e-b2bc-e60e219fe8d2",
              "type": "message",
              "role": "assistant",
              "model": "deepseek-v4-flash",
              "content": [
                {"type": "thinking", "thinking": "用户发来了一句简单的问候", "signature": "2683"},
                {"type": "text", "text": "你好！有什么我可以帮你的吗？"}
              ],
              "stop_reason": "end_turn",
              "usage": {"input_tokens": 33, "cache_creation_input_tokens": 0,
                        "cache_read_input_tokens": 11, "output_tokens": 109}
            }
            """;

    @Test
    void responsesAdapter_skipsReasoningBlockAndReadsUsageDetails() throws Exception {
        JsonNode root = mapper.readTree(PRO_RESPONSE);
        String text = responses.extractText(root);
        TokenUsage usage = responses.extractUsage(root);

        assertEquals("你好！有什么我可以帮你的吗？", text, "必须跳过 reasoning 块，只取 message/output_text");
        assertEquals(86, usage.promptTokens());
        assertEquals(45, usage.completionTokens());
        assertEquals(131, usage.totalTokens());
        assertEquals(7, usage.cachedTokens(), "cached 来自 input_tokens_details.cached_tokens");
        assertEquals(36, usage.reasoningTokens(), "reasoning 来自 output_tokens_details.reasoning_tokens");
    }

    @Test
    void anthropicAdapter_skipsThinkingBlockAndReadsCacheTokens() throws Exception {
        JsonNode root = mapper.readTree(FLASH_RESPONSE);
        String text = messages.extractText(root);
        TokenUsage usage = messages.extractUsage(root);

        assertEquals("你好！有什么我可以帮你的吗？", text, "必须跳过 thinking 块，只取 text 块");
        assertEquals(33, usage.promptTokens());
        assertEquals(109, usage.completionTokens());
        assertEquals(33 + 109, usage.totalTokens(), "Anthropic 无 total 字段，自动补全");
        assertEquals(11, usage.cachedTokens(), "cached 来自 cache_read_input_tokens");
    }

    @Test
    void routeIsDrivenByModelName() {
        assertEquals("openai-responses", responses.name());
        assertEquals("anthropic-messages", messages.name());
    }
}
