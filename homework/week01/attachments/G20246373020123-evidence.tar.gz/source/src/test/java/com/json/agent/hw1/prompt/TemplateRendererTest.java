package com.json.agent.hw1.prompt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;

class TemplateRendererTest {

    @Test
    void extractsVariables() {
        Set<String> vars = TemplateRenderer.extractVariables("语言：{{language}}\n代码：{{code}}\n{{language}}");
        assertEquals(Set.of("language", "code"), vars);
    }

    @Test
    void rendersVariables() {
        String out = TemplateRenderer.render("翻译成 {{target_lang}}：{{text}}",
                Map.of("target_lang", "English", "text", "你好"), true);
        assertEquals("翻译成 English：你好", out);
    }

    @Test
    void strictModeFailsOnMissingVariable() {
        assertThrows(IllegalArgumentException.class,
                () -> TemplateRenderer.render("需要 {{missing}}", Map.of("other", "x"), true));
    }

    @Test
    void nonStrictRendersEmptyForMissing() {
        assertEquals("需要 ", TemplateRenderer.render("需要 {{missing}}", Map.of(), false));
    }

    @Test
    void parsesRefWithAndWithoutVersion() {
        assertEquals("code-review", TemplateRef.parse("code-review").name());
        assertEquals(null, TemplateRef.parse("code-review").version());
        assertEquals("code-review", TemplateRef.parse("code-review@2").name());
        assertEquals(2, TemplateRef.parse("code-review@2").version());
    }

    @Test
    void templateKeyIsNameAtVersion() {
        PromptTemplate t = new PromptTemplate("code-review", 3, "c", null, null, 0L);
        assertEquals("code-review@3", t.key());
        assertTrue(t.variables().isEmpty());
    }
}
