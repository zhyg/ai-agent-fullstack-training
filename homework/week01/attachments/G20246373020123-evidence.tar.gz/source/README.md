# LLM 统一模型调用服务

> Java 17 + Spring Boot 3.5.6，**零新增依赖**（HTTP 用 JDK `java.net.http.HttpClient`，限流/重试自研）。
> 一个 API Key 跑通**两种不同协议**：OpenAI Responses 与 Anthropic Messages。

---

## 1. 它解决什么问题

同一个接口、同一份请求体，**只靠 `model` 字段**决定走哪套协议。调用方看不到鉴权头、请求体结构、返回结构的差异。

```
POST /v1/chat   { "model": "deepseek-v4-pro"   }  →  OpenAI Responses 协议
POST /v1/chat   { "model": "deepseek-v4-flash" }  →  Anthropic Messages 协议
```

## 2. 选型与协议差异

| 逻辑模型 | 上游端点 | 协议 | 鉴权 |
|---|---|---|---|
| `deepseek-v4-pro` | `POST https://api.deepseek.com/responses` | OpenAI Responses API | `Authorization: Bearer` |
| `deepseek-v4-flash` | `POST https://api.deepseek.com/anthropic/v1/messages` | Anthropic Messages API | `x-api-key` + `anthropic-version: 2023-06-01` |

**被适配器吃掉的差异（这是作业核心）**

| 差异点 | OpenAI Responses | Anthropic Messages |
|---|---|---|
| 鉴权头 | `Authorization: Bearer sk-xxx` | `x-api-key: sk-xxx` + `anthropic-version` |
| system 放哪 | `instructions` 字段 | 独立 `system` 字段，且 `messages` 只接受 user/assistant |
| 长度参数 | `max_output_tokens`（可选） | `max_tokens`（**必填**） |
| 结构化输出 | 原生 `text.format = {type: json_object\|json_schema}` | **无此参数** → 适配器把 JSON Schema 注入 system + 响应后提取校验 |
| 正文路径 | `output[]` 中 `type=message` → `content[]` 中 `type=output_text` → `text`（须跳过 `reasoning` 块） | `content[]` 中 `type=text` → `text`（须跳过 `thinking` 块） |
| usage 字段 | `input_tokens` / `output_tokens` / `total_tokens` | `input_tokens` / `output_tokens`（无 total，适配器自动补） |
| 缓存分类 | `input_tokens_details.cached_tokens` | `cache_read_input_tokens` + `cache_creation_input_tokens` |
| 推理分类 | `output_tokens_details.reasoning_tokens` | —（记 0） |
| 流式事件 | `response.output_text.delta` → `delta` 是**字符串** | `content_block_delta` → `delta.text`（`delta` 是**对象**） |

## 3. 目录结构

```
src/main/java/com/json/agent/hw1/
├── LlmGatewayService.java    编排：模板渲染 → 路由 → 限流 → 重试 → 契约校验 → 埋点
├── contract/                 统一契约（请求/响应/消息/输出格式/Token/延迟/流式事件）
├── adapter/
│   ├── LlmAdapter.java       适配器接口
│   ├── AdapterRouter.java    按 model 动态路由
│   ├── AbstractHttpAdapter.java  发报文 / SSE 解析 / 状态码归一
│   ├── OpenAiResponsesAdapter.java
│   └── AnthropicMessagesAdapter.java
├── prompt/                   模板存储 + 版本 + {{变量}} 替换 + name@version 引用
├── observe/                  调用留痕 + 按模型聚合统计
├── resilience/               统一错误码 + 指数退避重试 + 按模型令牌桶限流 + 故障注入
├── web/                      统一入口 / 模板 / 指标 / 运维端点
└── config/                   配置绑定
```

## 4. 启动

### 方式 A：IDEA 直接运行（最省事，推荐）

右键 `SpringaiApplication` → **Run 'SpringaiApplication'**。
前提：Run/Debug Configurations 里配好环境变量 `DEEPSEEK_API_KEY=sk-xxxxxxxx`。

### 方式 B：命令行（Windows PowerShell）

```powershell
# 1) 配置 Key（不要写进代码或提交到 git；仅当前终端有效）
$env:DEEPSEEK_API_KEY = "sk-xxxxxxxx"

# 2) 如果 mvn 不在 PATH（报"无法将 mvn 识别为 cmdlet"），先加进当前终端
$env:Path += ";D:\apache-maven\apache-maven-3.9.6\bin"   # 改成你自己的 Maven 目录
mvn -v                                                   # 能打出版本号就说明好了

# 3) 启动
mvn spring-boot:run

# 或者不想动 PATH，直接用完整路径
& 'D:\apache-maven\apache-maven-3.9.6\bin\mvn.cmd' spring-boot:run

# 4) 健康检查（PowerShell 里请写 curl.exe，避免命中 Invoke-WebRequest 别名）
curl.exe -s http://localhost:8080/v1/models
```

**让 mvn 永久生效**（可选，重开终端即生效）：

```powershell
[Environment]::SetEnvironmentVariable(
  'Path',
  [Environment]::GetEnvironmentVariable('Path','User') + ';D:\apache-maven\apache-maven-3.9.6\bin',
  'User')
```

### 方式 C：打包后跑

```powershell
mvn clean package -DskipTests
java -jar target/springai-0.0.1-SNAPSHOT.jar
```

---

**常见启动失败**

| 报错 | 原因 | 处理 |
|---|---|---|
| `无法将"mvn"项识别为 cmdlet` | Maven 没进 PATH | 按上面方式 B 第 2 步加 PATH，或用完整路径 |
| `Could not resolve placeholder 'DEEPSEEK_API_KEY'` | 环境变量没设 | 先 `$env:DEEPSEEK_API_KEY="sk-..."` 再启动 |
| `Port 8080 was already in use` | 端口被占 | 停掉旧进程：`Stop-Process -Name java -Force` |
| PowerShell 里 curl 报参数错 | `curl` 是 `Invoke-WebRequest` 的别名 | 改用 `curl.exe`，或直接用 IDEA 的 `hw1-api-test.http` |

启动成功后首次运行会在 `./data/hw1-templates.json` 生成两个内置模板（`code-review`、`translate`）。

> 下面第 5 节的 curl 示例是 bash 写法。Windows 用 Git Bash 直接跑；PowerShell 请把单引号 JSON 里的
> 内容改成双引号转义，或直接用 `src/main/resources/hw1-api-test.http`（IDEA → 点绿色箭头）。

## 5. 三大能力 curl 示例

### 5.1 两个模型各调一次（验证路由）

```bash
curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' -d '{
  "model": "deepseek-v4-pro",
  "messages": [{"role":"user","content":"用一句话解释什么叫适配器模式"}]
}'

curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' -d '{
  "model": "deepseek-v4-flash",
  "messages": [{"role":"user","content":"用一句话解释什么叫适配器模式"}]
}'
```

返回中 `adapter` 字段分别为 `openai-responses` / `anthropic-messages`，`usage` 是**统一**的五类统计。

### 5.2 流式输出（SSE，stream=true）

```bash
curl -N http://localhost:8080/v1/chat/stream -H 'Content-Type: application/json' -d '{
  "model": "deepseek-v4-pro",
  "stream": true,
  "messages": [{"role":"user","content":"从 1 数到 5"}]
}'
```

输出形如：

```
data: {"type":"delta","delta":"1"}
data: {"type":"delta","delta":", "}
...
data: {"type":"done","usage":{"promptTokens":86,"completionTokens":45,"totalTokens":131,"cachedTokens":0,"reasoningTokens":36}}
data: [DONE]
```

两个模型的 SSE 事件名完全不同，但对外吐出的是同一套 `delta / done / error`。

### 5.3 结构化输出（response_format）

```bash
curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' -d '{
  "model": "deepseek-v4-pro",
  "responseFormat": {"type":"json_schema","name":"review","schema":{
      "type":"object",
      "properties":{"action":{"type":"string"},"risk":{"type":"string"},"score":{"type":"integer"}},
      "required":["action","risk","score"]}},
  "messages": [{"role":"user","content":"评审这段代码：String s=null; s.length();"}]
}'
```

同一个请求把 `model` 换成 `deepseek-v4-flash`，返回结构完全一致（`data.json` 可直接反序列化）。
注意：pro 走原生 `text.format`，flash **没有**这个参数，靠适配器注入 Schema + 提取校验实现等价能力。

### 5.4 提示词模板版本管理

```bash
# 建 v1
curl -s -X POST http://localhost:8080/v1/templates -H 'Content-Type: application/json' -d '{
  "name":"code-review","content":"评审以下 {{language}} 代码，关注 {{focus}}。只输出 JSON。\n{{code}}",
  "description":"代码评审 v1"}'

# 同名再建 → 自动升到 v2
curl -s -X POST http://localhost:8080/v1/templates -H 'Content-Type: application/json' -d '{
  "name":"code-review","content":"评审以下 {{language}} 代码，关注 {{focus}}，并给出修复建议。只输出 JSON。\n{{code}}",
  "description":"代码评审 v2：多了修复建议"}'

# 按版本引用（不写版本 = 取最新版）
curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' -d '{
  "model": "deepseek-v4-pro",
  "template": {"name":"code-review","version":1,
               "variables":{"language":"Java","focus":"空指针","code":"String s=null; s.length();"}},
  "messages": [{"role":"user","content":"开始"}]
}'
```

响应里 `templateRef` 会回显 `code-review@1`，把 `version` 改成 2 即可对比两版提示词的效果差异。
变量缺失会直接返回 `40004 TEMPLATE_VAR_MISSING`，不会把 `{{xxx}}` 原样发给模型。

## 6. 可观测性

```bash
curl -s http://localhost:8080/v1/metrics              # 全局 + 按模型聚合
curl -s 'http://localhost:8080/v1/metrics/records?limit=5'   # 最近 5 条明细
curl -s -X POST http://localhost:8080/v1/metrics/reset
```

统计项：
- **Token 分类**：`promptTokens` / `completionTokens` / `totalTokens` / `cachedTokens`（缓存命中）/ `reasoningTokens`（思维链）
- **延迟**：`avgLatencyMs`（端到端）、`avgTtftMs`（首 Token 延迟，只统计流式）、`maxLatencyMs`
- 按模型维度独立聚合，另含 `attempts`（实际尝试次数）与 `backoffMs`（累计退避时长）

## 7. 韧性

### 7.1 统一错误码

| code | 名称 | HTTP | 是否重试 |
|---|---|---|---|
| 40001 | MODEL_NOT_SUPPORTED | 400 | 否 |
| 40003 | TEMPLATE_NOT_FOUND | 404 | 否 |
| 40004 | TEMPLATE_VAR_MISSING | 400 | 否 |
| 40010 | INVALID_JSON_OUTPUT（格式错） | 502 | **是** |
| 40100 | UPSTREAM_AUTH | 401 | 否 |
| 42900 | RATE_LIMITED（本地限流） | 429 | 否 |
| 42901 | UPSTREAM_RATE_LIMIT（上游限流） | 429 | **是** |
| 50400 | UPSTREAM_TIMEOUT（超时） | 504 | **是** |
| 50200 | UPSTREAM_SERVER_ERROR（5xx） | 502 | **是** |
| 50300 | NETWORK_ERROR | 503 | **是** |

失败分类处置：超时 / 限流 / 格式错 / 5xx / 网络错 → 指数退避重试；参数错 / 鉴权错 / 本地限流 → 立即失败。

### 7.2 指数退避重试（最多 3 次）

`base=500ms, multiplier=2, max=8000ms, jitter=20%`；上游给 `Retry-After` 时听上游的。
**总次数 = 3**（1 次原始 + 2 次重试）。

> 流式调用只在"还没吐出任何分片"时重试——一旦已经有内容发给客户端，重试会造成内容重复，直接报错终止。

真实上游不会按我们的意愿挂掉，所以内置了故障注入来可复现地验证：

```bash
# 让前 2 次调用失败 → 第 3 次成功
curl -s -X POST http://localhost:8080/v1/admin/chaos -H 'Content-Type: application/json' \
  -d '{"mode":"server_error","failTimes":2,"targetModel":"deepseek-v4-pro"}'

curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"hi"}]}'
# → 返回 attempts=3，日志里有 2 次 "退避xxxms"

# 让 5 次都失败 → 证明最多只试 3 次
curl -s -X POST http://localhost:8080/v1/admin/chaos -H 'Content-Type: application/json' \
  -d '{"mode":"server_error","failTimes":5,"targetModel":"deepseek-v4-pro"}'
curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"hi"}]}'
# → code=50200，日志里恰好 3 次尝试

curl -s -X DELETE http://localhost:8080/v1/admin/chaos   # 关掉注入
```

`mode` 可选：`timeout` / `server_error` / `rate_limit` / `bad_json` / `network`。

### 7.3 按模型独立限流

每个 model 一个令牌桶，互不影响。`deepseek-v4-pro` 打满不影响 `deepseek-v4-flash`。

```bash
# 连打 10 次触发 429
for i in $(seq 1 10); do
  curl -s -o /dev/null -w "%{http_code} " http://localhost:8080/v1/chat \
    -H 'Content-Type: application/json' \
    -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"hi"}]}'
done
# → 200 200 200 200 200 429 429 429 429 429

curl -s http://localhost:8080/v1/admin/rate-limit          # 看各模型剩余令牌
curl -s -X POST http://localhost:8080/v1/admin/rate-limit/refill
```

限流默认 `capacity=5, refill=0.5/s`（见 `application.yaml` 的 `hw1.models.*.rate-limit`）。

## 8. 验证脚本

```powershell
# Windows PowerShell（推荐）
powershell -ExecutionPolicy Bypass -File .\scripts\verify.ps1

# 或 Git Bash / WSL
bash scripts/verify.sh
```

脚本覆盖 16 项检查，逐项输出 `PASS/FAIL` 并在结尾给出汇总。

**实际验收结果（DeepSeek v4-pro / v4-flash，2026-11-01）**

```
[PASS] [01] 模型路由表        2 模型 [deepseek-v4-pro,deepseek-v4-flash] / 2 适配器 [anthropic-messages,openai-responses]
[PASS] [02] pro 非流式调用    adapter=openai-responses tokens=265 cached=0 reasoning=149
[PASS] [03] flash 非流式调用  adapter=anthropic-messages tokens=125 cached=0
[PASS] [04] pro 流式 SSE      15 个 delta 分片, 含[DONE]=True
[PASS] [05] flash 流式 SSE    16 个 delta 分片, 含[DONE]=True
[PASS] [06] pro 结构化输出    json 合法, action/risk/score 三字段齐全, score=90
[PASS] [07] flash 结构化输出  json 合法, action/risk/score 三字段齐全, score=95
[PASS] [08] 模板版本管理      v1 与 v2 内容不同=True
[PASS] [09] 模板引用调用      templateRef=code-review@1
[PASS] [09b] 模板变量缺失     code=40004 (期望 40004)
[PASS] [10] 可观测数据        calls=32 tokens=5004 models=2 avgLatency=1740.59ms avgTtft=1201.4ms
[PASS] [10b] 首Token延迟留痕  最近流式记录 ttft=1134ms total=1216ms tokens=120
[PASS] [11] 重试(退避后成功)  注入2次失败后第3次成功, attempts=3
[PASS] [11b] 重试上限3次      code=50200, attempts=3（最多只试 3 次）
[PASS] [12] 按模型限流(429)   12 次并发中 3 次返回 42900 RATE_LIMITED
[PASS] [12b] 限流按模型隔离    pro 剩余令牌=5.0（flash 被打满时 pro 不受影响）
=================================================
 16 PASSED / 0 FAILED
```

> **Windows PowerShell 5.1 用户注意**：它读无 BOM 的 UTF-8 脚本会按 GBK 解析，中文乱码会破坏脚本语法
> （表现为 `表达式或语句中包含意外的标记`）。先转成 UTF-8 with BOM 再跑：
>
> ```powershell
> $p = "d:\AI_Project\springai\scripts\verify.ps1"
> $c = Get-Content $p -Raw -Encoding UTF8
> [System.IO.File]::WriteAllText($p, $c, (New-Object System.Text.UTF8Encoding($true)))
> ```
>
> PowerShell 7（`pwsh`）无此问题。

## 9. 单元测试（不联网）

```bash
mvn test
```

- `ProtocolParsingTest`（3 个）—— 用**真实上游报文**验证两个适配器解析正确（跳过 reasoning / thinking 块、usage 分类映射）
- `TemplateRendererTest`（6 个）—— 变量提取、替换、严格模式、版本引用解析
- `ResilienceTest`（4 个）—— 令牌桶耗尽与恢复、退避增长与封顶、失败分类是否可重试

实际结果：`Tests run: 14, Failures: 0, Errors: 0` → `BUILD SUCCESS`（全程不联网）。

## 10. 已知边界

- 模板与指标存内存 + JSON 文件，重启后指标清空、模板保留（`./data/hw1-templates.json`）。
- Anthropic 协议没有独立的思维链 token 数，`reasoningTokens` 恒为 0。
- 非流式调用没有中间分片，`ttftMs = -1`；平均 TTFT 只统计流式调用。
- `/v1/admin/*` 是验证用的故障注入端点，生产环境必须移除。
