#!/usr/bin/env bash
# 第一周作业验收脚本（Git Bash / WSL / macOS / Linux）
#   bash scripts/verify.sh
#   BASE=http://localhost:9090 bash scripts/verify.sh
set -u
BASE=${BASE:-http://localhost:8080}
PASS=0
FAIL=0
TMPDIR_V=$(mktemp -d)
trap 'rm -rf "$TMPDIR_V"' EXIT

report() { # name ok detail
  if [ "$2" = "1" ]; then
    PASS=$((PASS + 1)); printf '[PASS] %-26s %s\n' "$1" "$3"
  else
    FAIL=$((FAIL + 1)); printf '[FAIL] %-26s %s\n' "$1" "$3"
  fi
}

# 返回 body 到 stdout，HTTP 状态码写入全局 HTTP_CODE
api() { # method path [body]
  local method=$1 path=$2 body=${3:-}
  local out
  if [ -n "$body" ]; then
    out=$(curl -s -w $'\n%{http_code}' -X "$method" "$BASE$path" -H 'Content-Type: application/json' -d "$body")
  else
    out=$(curl -s -w $'\n%{http_code}' -X "$method" "$BASE$path")
  fi
  HTTP_CODE=$(printf '%s' "$out" | tail -n1)
  printf '%s' "$out" | sed '$d'
}

sse() { # body
  local body=$1 file="$TMPDIR_V/sse.json"
  printf '%s' "$body" > "$file"
  curl -s -N --max-time 90 -X POST "$BASE/v1/chat/stream" \
       -H 'Content-Type: application/json' --data-binary "@$file"
}

has() { printf '%s' "$1" | grep -q "$2"; }
num() { printf '%s' "$1" | grep -o "\"$2\":-\?[0-9.]*" | head -1 | sed 's/.*://'; }
str() { printf '%s' "$1" | grep -o "\"$2\":\"[^\"]*\"" | head -1 | sed "s/.*\":\"//;s/\"$//"; }

echo "=============================================================="
echo " 第一周作业验收 · 目标服务 $BASE"
echo "=============================================================="

# ------------------------------------------------------------ [01] 路由表
body=$(api GET /v1/models)
if [ "$HTTP_CODE" = "200" ] && has "$body" '"openai-responses"' && has "$body" '"anthropic-messages"'; then
  report "[01] 模型路由表" 1 "两个协议适配器均已注册"
else
  report "[01] 模型路由表" 0 "HTTP $HTTP_CODE（服务未启动？）"
  echo "服务未启动，后续检查全部跳过"; exit 1
fi

# ------------------------------------------------------------ [02][03] 非流式
chat_body() {
  printf '{"model":"%s","messages":[{"role":"user","content":"%s"}],"maxTokens":256}' "$1" "$2"
}
body=$(api POST /v1/chat "$(chat_body deepseek-v4-pro '用一句话解释适配器模式')")
adapter=$(str "$body" adapter); total=$(num "$body" totalTokens)
if [ "$HTTP_CODE" = "200" ] && [ "$adapter" = "openai-responses" ] && [ "${total:-0}" -gt 0 ] 2>/dev/null; then
  report "[02] pro 非流式调用" 1 "adapter=$adapter totalTokens=$total cached=$(num "$body" cachedTokens) reasoning=$(num "$body" reasoningTokens)"
else
  report "[02] pro 非流式调用" 0 "HTTP $HTTP_CODE adapter=$adapter"
fi

body=$(api POST /v1/chat "$(chat_body deepseek-v4-flash '用一句话解释适配器模式')")
adapter=$(str "$body" adapter); total=$(num "$body" totalTokens)
if [ "$HTTP_CODE" = "200" ] && [ "$adapter" = "anthropic-messages" ] && [ "${total:-0}" -gt 0 ] 2>/dev/null; then
  report "[03] flash 非流式调用" 1 "adapter=$adapter totalTokens=$total"
else
  report "[03] flash 非流式调用" 0 "HTTP $HTTP_CODE adapter=$adapter"
fi

# ------------------------------------------------------------ [04][05] 流式
for pair in "deepseek-v4-pro:04" "deepseek-v4-flash:05"; do
  model=${pair%%:*}; idx=${pair##*:}
  out=$(sse "$(printf '{"model":"%s","stream":true,"messages":[{"role":"user","content":"从 1 数到 8"}]}' "$model")")
  n=$(printf '%s\n' "$out" | grep -c '"type":"delta"')
  done_ok=$(printf '%s\n' "$out" | grep -c '\[DONE\]')
  if [ "${n:-0}" -ge 3 ] && [ "${done_ok:-0}" -ge 1 ]; then
    report "[$idx] $model 流式 SSE" 1 "$n 个 delta 分片, 含 [DONE]"
  else
    report "[$idx] $model 流式 SSE" 0 "delta=$n done=$done_ok"
  fi
done

# ------------------------------------------------------------ [06][07] 结构化输出
SCHEMA='{"type":"object","properties":{"action":{"type":"string"},"risk":{"type":"string"},"score":{"type":"integer"}},"required":["action","risk","score"]}'
for pair in "deepseek-v4-pro:06" "deepseek-v4-flash:07"; do
  model=${pair%%:*}; idx=${pair##*:}
  body=$(api POST /v1/chat "$(printf '{"model":"%s","messages":[{"role":"user","content":"评审这段代码：String s=null; s.length();"}],"responseFormat":{"type":"json_schema","name":"review","schema":%s}}' "$model" "$SCHEMA")")
  if [ "$HTTP_CODE" = "200" ] && has "$body" '"json":{"' ; then
    report "[$idx] $model 结构化输出" 1 "$(printf '%s' "$body" | grep -o '"json":{[^}]*}' | head -1 | cut -c1-70)"
  else
    report "[$idx] $model 结构化输出" 0 "HTTP $HTTP_CODE 未返回合法 json 字段"
  fi
done

# ------------------------------------------------------------ [08] 模板版本
api POST /v1/templates '{"name":"code-review","content":"评审以下 {{language}} 代码，关注 {{focus}}，并给出修复建议。只输出 JSON。\n{{code}}","description":"verify 改进版"}' > /dev/null
v1=$(api GET /v1/templates/code-review/1)
v2=$(api GET /v1/templates/code-review/2)
c1=$(str "$v1" content); c2=$(str "$v2" content)
if [ "$HTTP_CODE" = "200" ] && [ -n "$c1" ] && [ -n "$c2" ] && [ "$c1" != "$c2" ]; then
  report "[08] 模板版本管理" 1 "code-review v1 与 v2 内容不同"
else
  report "[08] 模板版本管理" 0 "v1/v2 相同或缺失 (HTTP $HTTP_CODE)"
fi

# ------------------------------------------------------------ [09] 模板引用
body=$(api POST /v1/chat '{"model":"deepseek-v4-pro","template":{"name":"code-review","version":1,"variables":{"language":"Java","focus":"空指针","code":"String s=null; s.length();"}},"messages":[{"role":"user","content":"开始"}]}')
ref=$(str "$body" templateRef)
[ "$ref" = "code-review@1" ] && report "[09] 模板引用调用" 1 "templateRef=$ref" \
                             || report "[09] 模板引用调用" 0 "templateRef=$ref (期望 code-review@1)"

body=$(api POST /v1/chat '{"model":"deepseek-v4-flash","template":{"name":"code-review","version":1,"variables":{"language":"Java"}},"messages":[{"role":"user","content":"开始"}]}')
code=$(num "$body" code)
[ "$code" = "40004" ] && report "[09b] 模板变量缺失" 1 "code=$code TEMPLATE_VAR_MISSING" \
                       || report "[09b] 模板变量缺失" 0 "code=$code (期望 40004)"

# ------------------------------------------------------------ [10] 可观测
body=$(api GET /v1/metrics)
calls=$(num "$body" totalCalls); tokens=$(num "$body" totalTokens); ttft=$(num "$body" avgTtftMs)
if [ "${calls:-0}" -gt 0 ] 2>/dev/null && [ "${tokens:-0}" -gt 0 ] 2>/dev/null; then
  report "[10] 可观测数据" 1 "calls=$calls tokens=$tokens avgLatency=$(num "$body" avgLatencyMs)ms avgTtft=${ttft}ms"
else
  report "[10] 可观测数据" 0 "calls=$calls tokens=$tokens"
fi

body=$(api GET "/v1/metrics/records?limit=5")
if has "$body" '"stream":true' && has "$body" '"ttftMs"'; then
  report "[10b] 首Token延迟留痕" 1 "流式记录含 ttftMs 字段"
else
  report "[10b] 首Token延迟留痕" 0 "未找到流式记录或 ttftMs"
fi

# ------------------------------------------------------------ [11] 重试
api POST /v1/admin/chaos '{"mode":"server_error","failTimes":2,"targetModel":"deepseek-v4-pro"}' > /dev/null
body=$(api POST /v1/chat "$(chat_body deepseek-v4-pro 'hi')")
att=$(num "$body" attempts)
[ "$att" = "3" ] && report "[11] 重试(退避后成功)" 1 "注入2次失败后第3次成功, attempts=$att" \
                 || report "[11] 重试(退避后成功)" 0 "attempts=$att (期望 3)"

api POST /v1/admin/chaos '{"mode":"server_error","failTimes":5,"targetModel":"deepseek-v4-pro"}' > /dev/null
body=$(api POST /v1/chat "$(chat_body deepseek-v4-pro 'hi')")
code=$(num "$body" code)
body=$(api GET "/v1/metrics/records?limit=1")
att=$(num "$body" attempts)
if [ "$code" = "50200" ] && [ "$att" = "3" ]; then
  report "[11b] 重试上限3次" 1 "code=$code, attempts=$att（最多只试 3 次）"
else
  report "[11b] 重试上限3次" 0 "code=$code attempts=$att (期望 50200/3)"
fi
api DELETE /v1/admin/chaos > /dev/null

# ------------------------------------------------------------ [12] 限流
api POST /v1/admin/rate-limit/refill > /dev/null
for i in $(seq 1 12); do
  ( curl -s -o "$TMPDIR_V/r$i.txt" -X POST "$BASE/v1/chat" -H 'Content-Type: application/json' \
      -d "$(chat_body deepseek-v4-flash 'hi')" ) &
done
wait
limited=0
for i in $(seq 1 12); do
  if grep -q '"code":42900' "$TMPDIR_V/r$i.txt" 2>/dev/null; then limited=$((limited + 1)); fi
done
[ "$limited" -ge 1 ] && report "[12] 按模型限流(429)" 1 "12 次并发中 $limited 次返回 42900" \
                      || report "[12] 按模型限流(429)" 0 "未触发限流（调小 capacity 或提高并发）"

body=$(api GET /v1/admin/rate-limit)
pro_left=$(printf '%s' "$body" | grep -o '"deepseek-v4-pro":{[^}]*}' | grep -o '"availableTokens":[0-9.]*' | sed 's/.*://')
[ -n "$pro_left" ] && report "[12b] 限流按模型隔离" 1 "pro 剩余令牌=$pro_left（flash 打满时 pro 不受影响）" \
                   || report "[12b] 限流按模型隔离" 0 "未读到 pro 令牌桶"

echo "=============================================================="
echo " $PASS PASSED / $FAIL FAILED"
echo "=============================================================="
[ "$FAIL" -gt 0 ] && exit 1
exit 0
