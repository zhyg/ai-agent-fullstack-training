﻿<#
.SYNOPSIS
第一周作业验收脚本：逐项验证六大功能点。

.USAGE
  powershell -ExecutionPolicy Bypass -File .\scripts\verify.ps1
  .\scripts\verify.ps1 -Base http://localhost:8080
#>
param(
    [string]$Base = "http://localhost:8080"
)

$ErrorActionPreference = "Continue"
$script:Pass = 0
$script:Fail = 0

function Report {
    param([string]$Name, [bool]$Ok, [string]$Detail)
    if ($Ok) {
        $script:Pass++
        Write-Host ("[PASS] {0,-24} {1}" -f $Name, $Detail) -ForegroundColor Green
    } else {
        $script:Fail++
        Write-Host ("[FAIL] {0,-24} {1}" -f $Name, $Detail) -ForegroundColor Red
    }
}

function To-Json {
    param($Obj)
    return $Obj | ConvertTo-Json -Depth 20 -Compress
}

function Invoke-Api {
    param([string]$Method, [string]$Path, $BodyObj)
    $json = if ($null -ne $BodyObj) { To-Json $BodyObj } else { $null }
    try {
        # 用 splatting：无 body 时不要传 -Body/-ContentType，避免 PS 5.1 绑定 null 报错
        $params = @{
            Uri           = ($Base + $Path)
            Method        = $Method
            UseBasicParsing = $true
            TimeoutSec    = 180
        }
        if ($json) {
            $params['Body'] = [System.Text.Encoding]::UTF8.GetBytes($json)
            $params['ContentType'] = "application/json; charset=utf-8"
        }
        $resp = Invoke-WebRequest @params
        return [pscustomobject]@{ Status = [int]$resp.StatusCode; Body = $resp.Content }
    } catch {
        $r = $_.Exception.Response
        if ($r) {
            $stream = $r.GetResponseStream()
            $reader = [System.IO.StreamReader]::new($stream)
            $content = $reader.ReadToEnd()
            return [pscustomobject]@{ Status = [int]$r.StatusCode; Body = $content }
        }
        return [pscustomobject]@{ Status = 0; Body = $_.Exception.Message }
    }
}

function Invoke-Sse {
    param($BodyObj)
    $json = To-Json $BodyObj
    $tmp = [System.IO.Path]::GetTempFileName()
    [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
    try {
        $out = & curl.exe -s -N --max-time 90 -X POST "$Base/v1/chat/stream" `
            -H "Content-Type: application/json" --data-binary "@$tmp"
        return ($out -join "`n")
    } finally {
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Chat {
    param([string]$Model, [string]$Content, $Extra = @{})
    $body = @{
        model    = $Model
        messages = @(@{ role = "user"; content = $Content })
    }
    foreach ($k in $Extra.Keys) { $body[$k] = $Extra[$k] }
    return Invoke-Api "POST" "/v1/chat" $body
}

Write-Host "=============================================================="
Write-Host " 第一周作业验收 · 目标服务 $Base"
Write-Host "=============================================================="

# ---------------------------------------------------------------- [01] 路由表
$r = Invoke-Api "GET" "/v1/models" $null
$ok = $false; $detail = "服务不可达"
if ($r.Status -eq 200) {
    $o = $r.Body | ConvertFrom-Json
    $models = @($o.data.models.PSObject.Properties.Name)
    $adapters = @($o.data.adapters)
    $ok = ($models.Count -ge 2) -and ($adapters.Count -ge 2)
    $detail = "$($models.Count) 模型 [$($models -join ',')] / $($adapters.Count) 适配器 [$($adapters -join ',')]"
}
Report "[01] 模型路由表" $ok $detail
if (-not $ok) { Write-Host "服务未启动，后续检查全部跳过"; exit 1 }

# ---------------------------------------------------------------- [02] pro 非流式
$r = Chat "deepseek-v4-pro" "用一句话解释适配器模式"
$ok = $false; $detail = "HTTP $($r.Status)"
if ($r.Status -eq 200) {
    $o = $r.Body | ConvertFrom-Json
    $d = $o.data
    $ok = ($d.adapter -eq "openai-responses") -and ($d.text.Length -gt 0) -and ($d.usage.totalTokens -gt 0)
    $detail = "adapter=$($d.adapter) tokens=$($d.usage.totalTokens) cached=$($d.usage.cachedTokens) reasoning=$($d.usage.reasoningTokens)"
}
Report "[02] pro 非流式调用" $ok $detail

# ---------------------------------------------------------------- [03] flash 非流式
$r = Chat "deepseek-v4-flash" "用一句话解释适配器模式"
$ok = $false; $detail = "HTTP $($r.Status)"
if ($r.Status -eq 200) {
    $o = $r.Body | ConvertFrom-Json
    $d = $o.data
    $ok = ($d.adapter -eq "anthropic-messages") -and ($d.text.Length -gt 0) -and ($d.usage.totalTokens -gt 0)
    $detail = "adapter=$($d.adapter) tokens=$($d.usage.totalTokens) cached=$($d.usage.cachedTokens)"
}
Report "[03] flash 非流式调用" $ok $detail

# ---------------------------------------------------------------- [04] pro 流式
$body = @{ model = "deepseek-v4-pro"; stream = $true; messages = @(@{ role = "user"; content = "从 1 数到 8" }) }
$sse = Invoke-Sse $body
$deltaCount = ([regex]::Matches($sse, '(?m)^\s*data:\s*.*"type":"delta"')).Count
$hasDone = $sse -match '\[DONE\]'
$ok = ($deltaCount -ge 3) -and $hasDone
Report "[04] pro 流式 SSE" $ok "$deltaCount 个 delta 分片, 含[DONE]=$hasDone"

# ---------------------------------------------------------------- [05] flash 流式
$body = @{ model = "deepseek-v4-flash"; stream = $true; messages = @(@{ role = "user"; content = "从 1 数到 8" }) }
$sse = Invoke-Sse $body
$deltaCount2 = ([regex]::Matches($sse, '(?m)^\s*data:\s*.*"type":"delta"')).Count
$hasDone2 = $sse -match '\[DONE\]'
$ok = ($deltaCount2 -ge 3) -and $hasDone2
Report "[05] flash 流式 SSE" $ok "$deltaCount2 个 delta 分片, 含[DONE]=$hasDone2"

# ---------------------------------------------------------------- [06][07] 结构化输出
$schema = @{
    type       = "object"
    properties = @{
        action = @{ type = "string" }
        risk   = @{ type = "string" }
        score  = @{ type = "integer" }
    }
    required   = @("action", "risk", "score")
}
foreach ($m in @("deepseek-v4-pro", "deepseek-v4-flash")) {
    $fmt = @{ type = "json_schema"; name = "review"; schema = $schema }
    $r = Chat $m "评审这段代码：String s=null; s.length();" @{ responseFormat = $fmt }
    $ok = $false; $detail = "HTTP $($r.Status)"
    if ($r.Status -eq 200) {
        $d = ($r.Body | ConvertFrom-Json).data
        $j = $d.json
        $ok = ($null -ne $j) -and ($null -ne $j.action) -and ($null -ne $j.risk) -and ($null -ne $j.score)
        $detail = "json 合法, action/risk/score 三字段齐全, score=$($j.score)"
    }
    if ($m -eq "deepseek-v4-pro") { $idx = 6; $short = "pro" } else { $idx = 7; $short = "flash" }
    Report ("[0{0}] {1} 结构化输出" -f $idx, $short) $ok $detail
}

# ---------------------------------------------------------------- [08] 模板版本
$null = Invoke-Api "POST" "/v1/templates" @{
    name    = "code-review"
    content = "评审以下 {{language}} 代码，关注 {{focus}}，并给出修复建议。只输出 JSON。\n{{code}}"
    description = "verify: 代码评审改进版"
}
$tpls = (Invoke-Api "GET" "/v1/templates" $null).Body | ConvertFrom-Json
$v1 = (Invoke-Api "GET" "/v1/templates/code-review/1" $null)
$v2 = (Invoke-Api "GET" "/v1/templates/code-review/2" $null)
$ok = ($v1.Status -eq 200) -and ($v2.Status -eq 200)
$detail = "code-review 最新 v=$($tpls.data.latestVersions.'code-review')"
if ($ok) {
    $c1 = ($v1.Body | ConvertFrom-Json).data.content
    $c2 = ($v2.Body | ConvertFrom-Json).data.content
    $ok = $c1 -ne $c2
    $detail = "v1 与 v2 内容不同=$($c1 -ne $c2)"
}
Report "[08] 模板版本管理" $ok $detail

# ---------------------------------------------------------------- [09] 模板引用调用
$body = @{
    model    = "deepseek-v4-pro"
    template = @{
        name      = "code-review"
        version   = 1
        variables = @{ language = "Java"; focus = "空指针"; code = "String s=null; s.length();" }
    }
    messages = @(@{ role = "user"; content = "开始" })
}
$r = Invoke-Api "POST" "/v1/chat" $body
$ok = $false; $detail = "HTTP $($r.Status)"
if ($r.Status -eq 200) {
    $d = ($r.Body | ConvertFrom-Json).data
    $ok = ($d.templateRef -eq "code-review@1")
    $detail = "templateRef=$($d.templateRef)"
}
Report "[09] 模板引用调用" $ok $detail

# 变量缺失应报 40004
$body2 = @{
    model    = "deepseek-v4-flash"
    template = @{ name = "code-review"; version = 1; variables = @{ language = "Java" } }
    messages = @(@{ role = "user"; content = "开始" })
}
$r = Invoke-Api "POST" "/v1/chat" $body2
$code = if ($r.Status -eq 200) { 0 } else { (($r.Body | ConvertFrom-Json).code) }
Report "[09b] 模板变量缺失" ($code -eq 40004) "code=$code (期望 40004)"

# ---------------------------------------------------------------- [10] 可观测
$m = (Invoke-Api "GET" "/v1/metrics" $null).Body | ConvertFrom-Json
$d = $m.data
$byModel = @($d.byModel.PSObject.Properties.Name)
$ok = ($d.totalCalls -gt 0) -and ($d.totalTokens -gt 0) -and ($byModel.Count -ge 2) -and ($d.avgTtftMs -gt 0)
$detail = "calls=$($d.totalCalls) tokens=$($d.totalTokens) models=$($byModel.Count) avgLatency=$($d.avgLatencyMs)ms avgTtft=$($d.avgTtftMs)ms"
Report "[10] 可观测数据" $ok $detail

$recs = (Invoke-Api "GET" "/v1/metrics/records?limit=20" $null).Body | ConvertFrom-Json
$streamRec = @($recs.data.records | Where-Object { $_.stream -eq $true })[0]
$ok = ($null -ne $streamRec) -and ($streamRec.timings.ttftMs -ge 0) -and ($streamRec.usage.totalTokens -gt 0)
$detail = if ($null -ne $streamRec) { "最近流式记录 ttft=$($streamRec.timings.ttftMs)ms total=$($streamRec.timings.totalMs)ms tokens=$($streamRec.usage.totalTokens)" } else { "无流式记录" }
Report "[10b] 首Token延迟留痕" $ok $detail

# ---------------------------------------------------------------- [11] 重试
$null = Invoke-Api "POST" "/v1/admin/chaos" @{ mode = "server_error"; failTimes = 2; targetModel = "deepseek-v4-pro" }
$r = Chat "deepseek-v4-pro" "hi"
$ok = $false; $detail = "HTTP $($r.Status)"
if ($r.Status -eq 200) {
    $d = ($r.Body | ConvertFrom-Json).data
    $ok = ($d.attempts -eq 3)
    $detail = "注入2次失败后第3次成功, attempts=$($d.attempts)"
}
Report "[11] 重试(退避后成功)" $ok $detail

$null = Invoke-Api "POST" "/v1/admin/chaos" @{ mode = "server_error"; failTimes = 5; targetModel = "deepseek-v4-pro" }
$r = Chat "deepseek-v4-pro" "hi"
$code = if ($r.Status -eq 200) { 0 } else { (($r.Body | ConvertFrom-Json).code) }
$recs = (Invoke-Api "GET" "/v1/metrics/records?limit=1" $null).Body | ConvertFrom-Json
$attempts = $recs.data.records[0].attempts
$ok = ($code -eq 50200) -and ($attempts -eq 3)
Report "[11b] 重试上限3次" $ok "code=$code (期望50200), attempts=$attempts (期望3)"
$null = Invoke-Api "DELETE" "/v1/admin/chaos" $null

# ---------------------------------------------------------------- [12] 限流
$null = Invoke-Api "POST" "/v1/admin/rate-limit/refill" $null
$json = To-Json @{ model = "deepseek-v4-flash"; messages = @(@{ role = "user"; content = "hi" }); maxTokens = 16 }
$scriptBlock = {
    param($base, $json)
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
        $resp = Invoke-WebRequest -Uri ($base + "/v1/chat") -Method Post `
            -ContentType "application/json; charset=utf-8" -Body $bytes -UseBasicParsing -TimeoutSec 120
        return "OK|" + $resp.Content
    } catch {
        $r = $_.Exception.Response
        if ($r) {
            $reader = [System.IO.StreamReader]::new($r.GetResponseStream())
            return "LIMITED|" + $reader.ReadToEnd()
        }
        return "ERR|" + $_.Exception.Message
    }
}
$jobs = @()
1..12 | ForEach-Object { $jobs += Start-Job -ScriptBlock $scriptBlock -ArgumentList $Base, $json }
$results = $jobs | Wait-Job | Receive-Job
$jobs | Remove-Job -Force

$limited = 0
foreach ($line in $results) {
    if ($line -like "LIMITED|*") {
        $payload = $line.Substring(8) | ConvertFrom-Json
        if ($payload.code -eq 42900) { $limited++ }
    }
}
Report "[12] 按模型限流(429)" ($limited -ge 1) "12 次并发中 $limited 次返回 42900 RATE_LIMITED"

# pro 的桶应该没被打满（证明按模型独立）
$rl = (Invoke-Api "GET" "/v1/admin/rate-limit" $null).Body | ConvertFrom-Json
$proLeft = $rl.data.'deepseek-v4-pro'.availableTokens
Report "[12b] 限流按模型隔离" ($proLeft -gt 0) "pro 剩余令牌=$proLeft（flash 被打满时 pro 不受影响）"

Write-Host "=============================================================="
Write-Host (" {0} PASSED / {1} FAILED" -f $script:Pass, $script:Fail)
Write-Host "=============================================================="
if ($script:Fail -gt 0) { exit 1 }
