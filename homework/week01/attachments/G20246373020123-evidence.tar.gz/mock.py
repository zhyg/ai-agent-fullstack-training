import json, time, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
ROOT=Path('/tmp/wzw-eval/evidence')
state={'mode':'normal','count':0,'requests':[]}
gate=threading.Event()
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args): pass
 def do_GET(self):
  if self.path=='/release': gate.set()
  self.send_response(200); self.end_headers(); self.wfile.write(json.dumps(state).encode())
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  if self.path=='/control':
   state.update(mode=body['mode'],count=0,requests=[]); gate.clear()
   self.send_response(200); self.end_headers(); self.wfile.write(b'{}'); return
  state['count']+=1
  state['requests'].append({'path':self.path,'body':body,'time':time.time(),'header_names':list(self.headers.keys())})
  (ROOT/'upstream.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
  mode=state['mode']; pro=self.path=='/responses'
  code=500 if mode=='fail' or (mode=='retry' and state['count']<3) else 401 if mode=='auth' else 400 if mode=='badrequest' else 200
  self.send_response(code)
  self.send_header('Content-Type','text/event-stream' if body.get('stream') else 'application/json')
  self.end_headers()
  if code!=200: self.wfile.write(b'{"error":{"message":"teacher controlled"}}'); return
  usage={'input_tokens':11,'output_tokens':7,'total_tokens':18,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}
  au={'input_tokens':11,'output_tokens':7,'cache_read_input_tokens':3,'cache_creation_input_tokens':2}
  text={'invalid':'not json','empty':'','truncated':'{"a":','trailing':'{"ok":true} garbage','schema':'{"score":"wrong"}'}.get(mode,'{"action":"fix","risk":"null","score":90}' if ('text' in body or '[输出格式' in body.get('system','')) else 'hello')
  if body.get('stream'):
   def event(obj):
    self.wfile.write(('data: '+json.dumps(obj)+'\n\n').encode()); self.wfile.flush()
   event({'type':'response.created'} if pro else {'type':'message_start','message':{'usage':au}})
   time.sleep(.15)
   for t in ['hel','lo','!']:
    event({'type':'response.output_text.delta','delta':t} if pro else {'type':'content_block_delta','delta':{'type':'text_delta','text':t}})
   if mode=='gate': gate.wait(8)
   if mode=='error': event({'type':'error','error':{'message':'after text'}}); return
   if mode=='eof': return
   if pro: event({'type':'response.completed','response':{'usage':usage}})
   else:
    event({'type':'message_delta','usage':{'output_tokens':7}})
    event({'type':'message_stop'})
   return
  obj={'id':'mock-resp','status':'incomplete' if mode=='truncated' else 'completed','output':[{'type':'reasoning','content':[{'type':'output_text','text':'SHOULD_SKIP'}]},{'type':'message','content':[{'type':'output_text','text':text}]}],'usage':usage} if pro else {'id':'mock-msg','stop_reason':'max_tokens' if mode=='truncated' else 'end_turn','content':[{'type':'thinking','thinking':'SHOULD_SKIP'},{'type':'text','text':text}],'usage':au}
  self.wfile.write(json.dumps(obj).encode())
ThreadingHTTPServer(('127.0.0.1',18082),Handler).serve_forever()
