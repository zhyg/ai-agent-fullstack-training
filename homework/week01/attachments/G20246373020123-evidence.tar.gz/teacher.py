import json,time,urllib.request,urllib.error,threading,sys
from pathlib import Path
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18080'
UP='http://127.0.0.1:18082'
models=['deepseek-v4-pro','deepseek-v4-flash']
results=[]
def http(path,body=None,base=None):
 if base is None: base=BASE
 req=urllib.request.Request(base+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'})
 start=time.monotonic()
 try:
  with urllib.request.urlopen(req,timeout=30) as r: code=r.status; raw=r.read().decode()
 except urllib.error.HTTPError as e: code=e.code; raw=e.read().decode()
 try: parsed=json.loads(raw)
 except Exception: parsed=raw
 return {'status':code,'body':parsed,'elapsed_ms':round((time.monotonic()-start)*1000,2)}
def control(mode):
 http('/control',{'mode':mode},UP); http('/v1/admin/rate-limit/refill',{})
def state(): return http('/',base=UP)['body']
def chat(m,**kw): return http('/v1/chat',dict(model=m,messages=[{'role':'system','content':'teacher-system'},{'role':'user','content':'hello'}],**kw))
def save(name,passed,**evidence):
 results.append(dict(case=name,passed=bool(passed),**evidence)); (ROOT/('real-results.json' if '--real' in sys.argv else 'teacher-results.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2)); print(name,'PASS' if passed else 'FAIL',flush=True)
def stream(m):
 data=json.dumps({'model':m,'stream':True,'messages':[{'role':'user','content':'hi'}]}).encode()
 start=time.monotonic(); events=[]
 with urllib.request.urlopen(urllib.request.Request(BASE+'/v1/chat/stream',data=data,headers={'Content-Type':'application/json'}),timeout=20) as r:
  for line in r:
   s=line.decode().strip()
   if s: events.append({'ms':round((time.monotonic()-start)*1000,2),'line':s})
 return events
if '--real' in sys.argv:
 BASE='http://127.0.0.1:18081'
 for m in models:
  r=chat(m,maxTokens=128,requestId='teacher-real-'+m)
  save('A02-real-'+m,r['status']==200 and bool(r['body'].get('data',{}).get('text')),response=r)
 (ROOT/'real-records.json').write_text(json.dumps(http('/v1/metrics/records?limit=20'),ensure_ascii=False,indent=2))
 sys.exit()
save('A01-models',http('/v1/models')['status']==200,response=http('/v1/models'))
save('A04-unknown',chat('not-a-model')['status']==400,response=chat('not-a-model'))
for m in models:
 control('normal'); r=chat(m); s=state()
 b=s['requests'][0]['body']; pro=m==models[0]
 save('A03-'+m,r['status']==200 and r['body']['data']['text']=='hello' and ('input' in b if pro else 'messages' in b) and ('instructions' in b if pro else 'system' in b),response=r,upstream=s)
 control('gate'); out=[]
 t=threading.Thread(target=lambda:out.extend(stream(m))); t.start()
 # Examine downstream while upstream is explicitly blocked before terminal event.
 time.sleep(.7)
 # stream() accumulates only on return; use separate streaming observer below for a true gate assertion.
 http('/release',base=UP); t.join()
 control('gate'); seen=threading.Event(); live=[]
 def observe():
  req=urllib.request.Request(BASE+'/v1/chat/stream',data=json.dumps({'model':m,'messages':[{'role':'user','content':'hi'}]}).encode(),headers={'Content-Type':'application/json'})
  start=time.monotonic()
  with urllib.request.urlopen(req,timeout=15) as resp:
   for line in resp:
    text=line.decode().strip()
    if text:
     live.append({'ms':round((time.monotonic()-start)*1000,2),'line':text})
     if '"type":"delta"' in text: seen.set()
 t=threading.Thread(target=observe); t.start(); before=seen.wait(3); pre=list(live); http('/release',base=UP); t.join()
 save('F01-gated-'+m,before and not any('done' in x['line'] for x in pre),before_release=pre,events=live,upstream=state())
 for mode in ['error','eof']:
  control(mode); events=stream(m); s=state()
  save('F02-'+mode+'-'+m,any('"type":"error"' in x['line'] for x in events) and s['count']==1,events=events,upstream=s)
 control('normal'); r=chat(m,responseFormat={'type':'json_object'})
 save('F03-'+m,r['status']==200 and r['body']['data']['json']['score']==90,response=r,upstream=state())
 for mode in ['invalid','empty','truncated','trailing','schema']:
  control(mode)
  fmt={'type':'json_schema','schema':{'type':'object','properties':{'score':{'type':'integer'}},'required':['score']}} if mode=='schema' else {'type':'json_object'}
  r=chat(m,responseFormat=fmt); save('F04-'+mode+'-'+m,r['status']!=200,response=r,upstream=state())
 # Literal assignment uses the homework field name, not the README camelCase spelling.
 control('invalid'); r=chat(m,response_format={'type':'json_object'})
 save('F03-snake-field-'+m,r['status']!=200,response=r,upstream=state())
control('normal')
for content in ['v1 {{who}}','v2 {{who}}']: http('/v1/templates',{'name':'teacher','content':content})
refs=[]
for v in [1,2]:
 r=chat(models[0],template={'name':'teacher','version':v,'variables':{'who':'WZW'}}); refs.append(r)
s=state(); save('F05-versions',[x['body']['data']['templateRef'] for x in refs]==['teacher@1','teacher@2'] and [x['body']['instructions'] for x in s['requests']]==['v1 WZW\nteacher-system','v2 WZW\nteacher-system'],responses=refs,upstream=s)
for template in [{'name':'missing'},{'name':'teacher','version':99},{'name':'teacher','version':1,'variables':{}}]:
 control('normal'); r=chat(models[0],template=template); save('F06-'+str(template),r['status'] in [400,404] and state()['count']==0,response=r,upstream=state())
for mode in ['retry','fail','auth','badrequest']:
 control(mode); http('/v1/metrics/reset',{}); r=chat(models[0],requestId='teacher-'+mode); s=state(); rec=http('/v1/metrics/records?limit=20'); times=[q['time'] for q in s['requests']]; gaps=[round((b-a)*1000,2) for a,b in zip(times,times[1:])]
 save(('F08-' if mode=='retry' else 'F09-')+mode,s['count']==(3 if mode in ['retry','fail'] else 1),response=r,upstream=s,gaps_ms=gaps,records=rec)
 if mode=='retry': save('F07-retry-total-latency',r['body']['data']['timings']['totalMs']>=300,response=r,records=rec)
 if mode=='fail': save('F07-one-failure-record',len(rec['body']['data']['records'])==1,records=rec)
control('normal'); http('/v1/metrics/reset',{}); ordinary=chat(models[1]); events=stream(models[1]); rec=http('/v1/metrics/records?limit=20')
save('F07-token-ttft',rec['body']['data']['records'][0]['usage']['cachedTokens']==5 and rec['body']['data']['records'][0]['timings']['ttftMs']>=140,ordinary=ordinary,events=events,records=rec)
control('normal'); rows=[chat(models[0]) for _ in range(6)]; other=chat(models[1]); save('F10-model-isolation',rows[-1]['status']==429 and other['status']==200,responses=rows,other=other)
time.sleep(2.1); recovered=chat(models[0]); save('F11-recovery',recovered['status']==200,response=recovered)
(ROOT/'final-records.json').write_text(json.dumps(http('/v1/metrics/records?limit=200'),ensure_ascii=False,indent=2))
