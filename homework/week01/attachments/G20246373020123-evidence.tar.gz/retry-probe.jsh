import com.json.agent.hw1.config.LlmProperties;
import com.json.agent.hw1.resilience.RetryPolicy;
var retry = new RetryPolicy(new LlmProperties.RetryConfig(3,500,2.0,8000,0.2));
for(int n : new int[]{1,2,6}) { long bound=Math.min(8000,500*(1L<<(n-1))); long wait=retry.backoffMs(n,null); System.out.println("attempt="+n+" bound="+bound+" wait="+wait+" exceeded="+(wait>bound)); }
/exit
