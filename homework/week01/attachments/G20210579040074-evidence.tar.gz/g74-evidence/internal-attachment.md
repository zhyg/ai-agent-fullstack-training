# 第一周作业评测附件

- 学员：白宇，G20210579040074。
- 仓库：https://github.com/Jason-Bai/ai-agent-training；评测范围 `llm-gateway/`。
- 分支与固定完整提交：`main`，`b8698c1448b1f9ca90d7d837fcfae2b2cfdbc6cc`，与克隆时 `origin/main` 一致。
- 评测日期：2026-11-07，Asia/Singapore；日志原始数据库时间使用 UTC。
- 总分：**89/100（暂评）**。
- 作业等级：**优秀**，仅按总分分段，不以验收结论改等级。
- 验收结论：**未通过**（按模型独立限流未完成）；另有原配置真实接入及普通真实调用未验证项，补证前暂评。
- 基准：课程第一周作业原文、评分标准 v1.1、学员反馈模板 v1.0。没有按测试通过率换算分数，没有因环境或额外基础设施要求扣分。
- 评测方式：本 orb 亲自克隆、安装、运行学生测试和教师受控 HTTP/SDK/SSE 用例；没有创建其他线程，没有修改学生业务源码，没有提交或推送。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 同一普通入口按 model 路由；真实 HTTP 直连与 SDK 分别发送 Chat Completions、Responses；未知模型统一 400；结果抽象一致。真实接入限制不扣代码分。 |
| 流式输出 | 13/15 | 双协议 SSE、门控增量、结束/中断、不重复生成均通过；题目要求的 `stream=true` 不被统一入口接受，D2 扣 2 分，保留已有流式能力的主要分数。 |
| 结构化输出 | 8/10 | 通过 `response_schema` 可完成双协议约束、JSON/Schema 校验和有限修复；统一 `response_format` 不接受，D3 在正常入口兼容部分扣 2 分，不把底层已通过能力清零。 |
| 提示词版本管理 | 10/10 | 内置版本化存储、变量替换、旧版本回引、缺模板/版本/变量明确 400；不要求动态模板发布 HTTP API。 |
| 可观测性 | 15/15 | 17 输入/3 输出/20 总量及 7 缓存分类准确入库，普通/流式/失败请求可关联；未知用量保留 null；正文 TTFT 有记录，异步诊断后补已复核。 |
| 统一错误与重试 | 15/15 | 503 有限恢复，401 不重试；实际直连和 SDK 请求次数核对，SDK max_retries=0；全抖动指数上限及实际等待有证据。 |
| 按模型独立限流 | 3/10 | 现有并发保护确实返回 HTTP 429，保留该 3 分；缺模型独立计数 4 分、模型配额恢复 2 分、可验证模型阈值 1 分，D1 合计扣 7 分。 |
| 源码、README 与验证脚本 | 10/10 | 锁文件安装、Compose/Alembic/Uvicorn 启动复现；curl 示例齐备；学生 pytest 包含六类功能，注入错误正文会断言失败。未因同一契约/限流根因再次扣脚本分。 |
| **合计** | **89/100** | 15 + 13 + 8 + 10 + 15 + 15 + 3 + 10 = 89；扣分 7 + 2 + 2 = 11。 |

## 固定对象、环境与配置差异

实际 `git clone` 成功，不需要只读替代获取。完整学生提交固定在独立克隆中；归档 `source-tree.txt` 保存固定提交下整个 llm-gateway 树的 Git blob 标识，`fixed-source.tar.gz` 保存运行所需源码、测试、资源、配置、迁移、锁文件及 README（不含历史文档图片）。最终学生受跟踪文件与 HEAD 无差异。

执行 `uv sync --python 3.12 --locked` 成功。orb 起初无 Docker daemon 和 Compose 插件，安装插件并以监督服务启动 Docker 后，原 `docker compose up -d --wait` 成功，PostgreSQL 18.6 健康。原 Alembic 迁移及 README 的 Uvicorn factory 命令均执行，`/healthz` 返回 `success:true, code:ok`。这些是环境准备，不扣分。README 的工作目录文字是 `projects/llm-gateway`，本仓库实际为 `llm-gateway`，进入实际目录即可，不另扣分。

| 配置 | 原提交/示例 | 教师独立替代 |
| --- | --- | --- |
| 配置证据 | `original-gateway.yaml` 为实际跟踪配置，`original-gateway.example.yaml` 为 README 示例 | `controlled-config.yaml`、`live-config.yaml`，实际私密文件位于归档外临时目录 |
| 真实供应商 | 原 light/general/analysis 是百炼 Responses，qwen3.8-flash/qwen3.7-plus/qwen3.8-max | 仅 DeepSeek 官方 `https://api.deepseek.com/v1`；没有真实请求发往百炼或其他供应商 |
| 双协议 | general-primary/general-backup 原为 Mock 的 Chat/Responses，不能当真实接入 | A 使用现有 DeepSeekProvider；B 使用现有 OpenAICompatibleProvider；均映射 `deepseek-flash`，思考关闭，保持现有计数器支持范围 |
| 模型含义 | 原三款百炼真实模型没有本次可用凭据 | 两个公开别名、两个实际协议，但同一上游型号；不宣称验证了两款不同物理模型 |
| 重试 | 实际配置未设置 recovery 时采用默认总 3、单端点 2 | 同样总 3、单端点 2；base 从默认 0.1 调为 0.2 秒以便测量；cap 1 秒；retry 组为 Chat 后 Responses |
| 并发 | 全局 20、单 Agent 5 | 均降低为 1，暴露跨模型共享限制；没有加入学生不存在的限流逻辑 |
| 价格与余额 | 原真实供应商价格配置 | 独立 teacher 测试价和教师余额，仅满足账务准入；不当作官方费用、不改变 Token 结果 |
| 密钥 | 不复制或公开任何实际凭据 | 从现有环境变量写入权限 0600 的归档外文件；受控上游仅用假标记；归档不含 credentials.yaml 或数据库密码 |

工厂启动烟测短暂使用教师配置并在结束后还原实际跟踪配置；教师功能测试均显式指定独立 `config_dir`，没有修改适配器、路由、恢复或校验逻辑。使用固定随机采样值验证退避仅是教师时间控制，不算默认随机运行结果。

## A01–A04、F01–F12 验证结果

下列文件名均位于同目录的 `G20210579040074-evidence.tar.gz` 内。`teacher.py` 是教师独立受控上游与真实 Uvicorn TCP 调用脚本，不是重用学生 passed 报告。

| 用例 | 结论 | 实际结果与证据 |
| --- | --- | --- |
| A01 | 通过（替代配置） | 安装、Compose、迁移和 README factory 启动，健康检查成功；`startup-*.log/json`。原百炼凭据条件未满足，不把替代配置说成原模型真实通过。 |
| A02 | 部分验证/原配置未验证 | 两协议真实 JSON 和 SSE 成功；普通非流式多次遇到官方 500 或超时；原百炼模型未调用。见真实调用表。 |
| A03 | 通过 | 受控请求分别 `/v1/chat/completions` + messages/max_tokens/response_format 与 `/v1/responses` + input/max_output_tokens/text.format，鉴权存在；17/3/20 两种响应正确解析；`controlled-results.json`、`controlled-upstream-calls.json`。 |
| A04 | 通过 | 不存在的 model 返回统一 400 unknown_model，上游调用 0 次；`unknown-model.json`。 |
| F01 | 能力通过，入口差异 | A/B 均在终态 gate 未释放时收到 GATED 正文，最终 completed；官方双协议 SSE 成功。`stream-A/B.json`、`real-stream-A/B.json`。但 `/v1/llm` 携带 stream=true 返回 422：`stream-flag-A/B.json`，D2。 |
| F02 | 通过 | 正文后关闭上游连接，A/B 均 response.failed，单个上游实际仅收到 1 次调用；没有从头重试。`interrupt-A/B.json`、controlled-results 中 F02。 |
| F03 | 能力通过，必需字段失败 | `response_schema` 下双协议合法 JSON 均解析成功，官方也成功；统一 response_format 被 422 invalid_request 拒绝，D3。 |
| F04 | 通过 | 非法 not-json、空字符串、截断 JSON/length/incomplete、字段 answer 为数字均失败；非法及类型错误经一次修复仍坏时停止，未以 200 成功。`json-{illegal,empty,truncated,schema}-A/B.json`，实际请求体和次数见 controlled-results。 |
| F05 | 通过 | 依次引用 context_answer 1.0.0→1.1.0→1.0.0；版本变化增加示例，再引用旧版请求完全一致；context 已替换且进入真正上游请求。`prompt-*.json`、controlled-results F05。 |
| F06 | 通过 | 缺模板、版本或 context 均统一 400，无上游请求；没有未替换占位符外发。`missing-*.json`。 |
| F07 | 通过 | 普通记录准确 17/3/20，账单缓存 7，失败 401 记录 failed、未知 usage=null；门控前心跳 150ms 不计作正文 TTFT；快终态 TTFT 1.2 秒后重查均非空；`observability.json`、`fast-stream-timing.json`、`supplement-results.json`。真实 A 流式即时查询 TTFT 暂空，后查 965.922ms，不作为缺失扣分。 |
| F08 | 通过（含 fallback） | 前两次 503、第三次成功，实际上游请求 Chat×2、Responses×1。固定 jitter=1 时首次间隔 216.221ms，对应 base=200ms 加 HTTP/DB 开销；换端点不要求沿用同端点退避。策略直接检查上限为 0.2、0.4 秒；单端点 cap=2，第二级等待不会在同端点第三次请求前发生。`retry-deterministic.json`、supplement-results。 |
| F09 | 通过 | 持续 503 的组共 3 次后停止；SDK 单端点实际 2 次，401 两协议各 1 次；没有 SDK 隐藏重试叠加。`retry-always503-*.json`、`retry-401-*.json`、`sdk-deterministic.json`。 |
| F10 | 失败 | A 顺序调用 4 次均 200；挂起 A 后再次 A=429、B=429，错误 concurrency_limited；不是按模型独立限流，D1。`limit-A/B.json`、controlled-results F10。 |
| F11 | 不满足目标 | 释放 A 后 B 返回 200，只能证明并发许可释放；没有模型窗口/令牌配额可等待恢复。与 F10 同根因，合并 D1，不重复扣分。`limit-restored-B.json`。 |
| F12 | 已运行，断言有效，非全绿 | 默认全量 2866 passed、104 skipped、2 failed；失败复查 1 failed、1 passed，详见下节。外部插件只改变受控上游正文，学生 direct/SDK 原断言均报 TEST_REPLY 与错误正文不匹配，2 failed、退出码 1。`student-injected-failure.log`、`inject_failure.py`。 |

## 学生验证脚本执行

执行命令：

```bash
uv run --python 3.12 python -W error -m pytest -q
PYTHONPATH=src:/tmp/g74-evidence uv run python -W error -m pytest -q tests/protocol/test_providers.py::test_real_transport_mapping_and_success -p inject_failure
```

默认全量结果：**`2 failed, 2866 passed, 104 skipped in 1440.88s (0:24:00)`**，pytest 退出码 **1**，见 `student-tests.log`。104 项 live 跳过不是通过，真实调用以教师独立记录为准。未修改测试或过滤失败制造全绿。

两个失败均实际复查，命令如下，结果 **`1 failed, 1 passed in 11.64s`**，退出码 1，见 `student-failure-recheck.log`：

```bash
uv run --python 3.12 python -W error -m pytest -q tests/integration/test_f5o1_http.py::test_heartbeats_are_not_persisted_or_allocated_sequence 'tests/integration/test_f7_deadline.py::test_f7_preparation_and_attempt_save_share_deadline[prepare]'
```

- 心跳用例重复失败：`tests/integration/test_f5o1_http.py:560`，期望 Mock 的 `stream_close_calls==1`，断言时实际 0，伴随订阅 internal_error 日志。其前面的数据库正文/终态事件、序号及 completed 状态断言已通过。尚未确定此内部关闭计数失败的完整根因，不把它虚构为已证实的真实上游泄漏或流式缺失。
- 总期限用例全量中失败：`tests/integration/test_f7_deadline.py:49`，响应已是预期 504 request_timeout，但实测 1.768 秒，超过测试自设 1.25 秒上限；复查通过。不能仅凭复查认定根因必为环境，也不把未复现的时间门槛当作题目额外扣分项。
- 两项均作为回归稳定性补交建议保存；不按失败数量或比例扣分，不对内部 Mock 调用次数和作业未规定的总超时阈值追加扣分。核心 SSE/断流/可观测行为另有教师 TCP 用例证据。

故障注入结果已确认：`2 failed in 0.34s`，退出码 1，失败断言位于固定源码 `tests/protocol/test_providers.py:98`。只改变教师替身服务器输出，没有修改学生文件。

## 扣分证据（固定提交相对 llm-gateway 的行号）

### D1：按模型独立限流缺失，扣 7 分

- 所属项：按模型独立限流 10 分中的独立计数 4、模型配额恢复 2、模型阈值 1；已有真实 HTTP 429 保留 3 分。
- 触发：教师将既有 global/agent 并发阈值降为 1，A 的流式请求在上游门控处占用许可，再调用 A 和 B；另顺序调用 A 四次。
- 期望：具备 A/B 独立的模型配额；A 耗尽后本地 HTTP 429，B 仍成功；等待声明的窗口或补充规则后 A 恢复。
- 实际：A 四次顺序调用均 200；占用 A 后 A/B 均 429 concurrency_limited；释放 A 后 B=200。结合固定源码可确定仅有并发限制，不能将许可释放冒充配额恢复。
- 固定源码：`src/services/concurrency.py:44–85` 的计数键仅 request_id/agent_id；`src/services/models.py:32–40` 仅定义全局和 Agent 并发配置；普通调用获取许可处 `src/services/gateway.py:145` 不传 model。
- 复现：从固定源码目录执行 `PYTHONPATH=src uv run python /tmp/g74-evidence/teacher.py`，查看 F10/F11、`limit-A.json`、`limit-B.json`、`limit-restored-B.json` 和 `sequential-A-*.json`。
- 同根因边界：F10/F11 合并扣分；不再从统一错误、脚本覆盖或可观测性机械扣分。

### D2：统一入口不接受 stream=true，扣 2 分

- 所属项：流式输出的双模型 SSE/入口支持部分；保留门控增量、双协议解析、终止与中断不重试等 13 分。
- 触发：向已有 `/v1/llm` 请求加入 `"stream":true`，model 分别 A/B。
- 期望：题目要求的统一流式入参可用，并返回 SSE。
- 实际：HTTP 422、统一 invalid_request，调用上游 0 次。文档要求先 POST `/v1/llm/stream` 再 GET events，替代流程能力已验证但不能代替原字段要求。
- 固定源码：`src/contracts.py:17–18,44–64` 的严格请求未声明 stream；`src/api/routes.py:44–82` 将普通与流式创建分离。
- 复现：`PYTHONPATH=src:/tmp/g74-evidence uv run python /tmp/g74-evidence/supplement.py`；`stream-flag-A/B.json`、supplement-results 的 F01-required-flag。

### D3：统一入口不接受 response_format，扣 2 分

- 所属项：结构化输出的双协议正常入口 4 分部分扣 2；已有 response_schema 和服务端最终校验保留其余 8 分。
- 触发：向 `/v1/llm` 传入 `"response_format":{"type":"json_object"}`，model 分别 A/B。
- 期望：接受统一 response_format 并映射为协议适配器支持的约束；不要求上游同名字段，也不额外要求 Schema 扩展。
- 实际：HTTP 422 invalid_request；同一模板经学生 response_schema 则双协议 200、parsed.answer=OK。
- 固定源码：`src/contracts.py:17–18,44–64` 只声明 response_schema；`src/providers/deepseek.py:21–31` 实际具备 JSON mode 映射；`src/providers/openai_compatible.py:20–34` 具备 text.format 映射，缺陷限于对外字段兼容。
- 复现：`PYTHONPATH=src uv run python /tmp/g74-evidence/teacher.py`，查看 `response-format-A/B.json` 与 `json-valid-A/B.json` 对照。
- 评分边界：D2/D3 是两项题目明确字段各自缺失，按受影响能力少量扣分；没有再从统一接口或文档重复扣分。

## DeepSeek 官方真实调用

真实连接仅 `https://api.deepseek.com/v1`。A=Chat Completions（DeepSeekProvider），B=Responses（OpenAI SDK，max_retries=0）；两者实际模型都是 `deepseek-flash`。下表 request_id 为网关可查询的 ID，输入/输出/总量来自实际 Usage，不使用本地预估冒充。

| 场景/协议 | request_id | 状态 | 输入/输出/总 Token | 请求总延迟 ms / 正文 TTFT ms |
| --- | --- | --- | --- | --- |
| A 普通，Chat | f0a8cf1d-8e50-4e43-ad0e-88a2dc2b0e24 | HTTP 504；后查 failed | 未知 | 后查 30976.849 / 不适用 |
| A JSON，Chat | 4364fd3f-7cb3-4b30-b2ee-9a721f64a8e2 | HTTP 200，parsed.answer=OK；2 次尝试 | 已知小计 461/5/466，首次失败用量未知 | 11654.042 / 不适用 |
| A SSE，Chat | fc886a13-43ff-4c0d-b616-b81267b472b4 | completed | 411/1/412 | 934.180 / 后补 965.922 |
| B 普通，Responses | e93eca47-2796-485a-b9a0-8f2e16634fe9 | HTTP 503 provider_unavailable，2 次尝试 | 未知 | 19995.725 / 不适用 |
| B JSON，Responses | 0ad3cbca-9594-4b31-a52d-a7dc00fab59a | HTTP 200，parsed.answer=OK | 457/6/463 | 820.236 / 不适用 |
| B SSE，Responses | 2ab20629-90bb-45a8-b2c3-ad34a91d45fe | completed | 411/1/412 | 3970.213 / 3957.546 |
| A 普通短句复验，Chat | 7cbe3363-f5a1-4cda-96ca-d1931cce0d41 | HTTP 503；观察到官方 HTTP 500×2 | 未知 | 30673.680 / 不适用 |
| B 普通短句复验，Responses | f18f5271-8e53-4db0-be51-4322af7c36c1 | HTTP 503；观察到官方 HTTP 500×2 | 未知 | 30951.641 / 不适用 |

补充解释：A SSE 的总耗时是生成请求结束口径，TTFT 是正文实际送到订阅者口径，后者可略晚于生成完成；不能机械要求两种不同结束点相减为正。首次查询的 TTFT=null 已用 `real-refreshed-traces.json` 复核持久化后值，不据此误扣分。A JSON 含未知用量尝试时外层 usage=null，而 Trace 报已知小计与 unknown_attempts，属于如实标明计量不完整。

上游安全响应头观察见 `real-upstream-safe-headers.json`；四个 500 响应均未提供 x-request-id/request-id，故上游 request_id 记为未知，不虚构。原始成功调用未额外采集上游 response id，记录的是网关 request_id。普通调用的暂时不可用仅能确认到官方 HTTP 500/超时层，未判定为学生代码缺陷，不扣分。

## 未验证、补交与复验条件

- 原三款百炼模型缺凭据且真实请求范围只授权 DeepSeek，因此没有访问百炼；不能凭学生历史报告宣称通过。
- 两个不同物理模型的当前真实调用未验证：替代配置两个协议都用现有 tokenizer 支持的 deepseek-flash，不修改计数逻辑去适配其他型号。
- 普通真实非流式调用未取得成功；已记录官方 500/超时，恢复后补验。结构化和流式的真实成功不等同所有普通请求通过。
- 学生全量测试的两个失败与针对性复查结果如实留存；建议修复或澄清心跳关闭计数断言，并稳定总期限用例。没有将内部测试计数直接换成代码分。
- 没有测试未要求的分布式限流、Redis、多实例等；没有对 NaN 等建议边界另设扣分门槛。
- 必须修复：统一 stream/response_format 字段兼容、按模型独立配额。补充模型 A 超限/B 隔离/A 恢复的回归断言，以及原模型/正式替代映射的真实请求证据。
- 复验：按 README 启动，A01–A04/F01–F12 对应要求可复现；普通、流式、结构化、失败的模型/协议/request_id/用量/延迟均有证据。分数按实际修复与补证重新核定。

## 归档与完成检查

证据包：`G20210579040074-evidence.tar.gz`。包含教师脚本、故障注入插件、脱敏替代配置、原公开配置、固定源码及 blob 树、学生日志、逐用例 HTTP/Trace/账单结果、官方真实记录及复现说明。不包含实际密钥、私密凭据文件或数据库密码。

完成检查已执行：八项合计 89；简明报告优点/不足/改进各 4 条、分别 275/284/258 字符（含 Markdown 标记仍小于 500）；原始证据、报告和内嵌源码包逐文件扫描实际 DEEPSEEK_API_KEY 字节未发现泄漏。只归档公开密码示例，不归档实际凭据或运行数据库密码文件；归档外临时密钥配置已删除。

全量 pytest 已结束并保留退出码 1 的失败事实；学生业务源码及实际跟踪配置与固定 HEAD 无差异。评测 Uvicorn 已停止，本次 Compose 数据库及测试数据卷已移除，Docker 监督服务已停止；`stop-services.log` 最终为 **No orb services are running.**。格式/总分/源码/脱敏复核见 `delivery-check.json`，未提交、未推送。
