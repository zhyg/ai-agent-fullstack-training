"""One short follow-up per protocol after transient official upstream errors.
Observe only safe upstream headers, never authorization or credentials.
"""
import time
import teacher as t


directory=t.PRIVATE/'live'
token=t.prepare(directory)
headers=[]
with t.gateway(directory,token) as (c,app):
    for name,provider in app.state.providers.items():
        client=provider.client if name=='chat' else provider.client._client
        async def observe(response, name=name):
            headers.append(dict(provider=name,path=response.request.url.path,status=response.status_code,
                                request_id=response.headers.get('x-request-id'),
                                request_id_alt=response.headers.get('request-id')))
        client.event_hooks['response'].append(observe)
    for model in ('A','B'):
        p=t.body(model)
        p['prompt']={'name':'basic_text','version':'1.0.0'}
        p['messages']=[{'role':'user','content':'Say OK only.'}]
        p['timeout_seconds']=60
        d=t.invoke(c,'real-followup-'+model,p)
        print(model,d['status'],d['request_id'],flush=True)
    # Reload the initially incomplete snapshots after terminal diagnostics settle.
    old=[]
    for filename in ('real-ordinary-A','real-stream-A'):
        import json
        prior=json.loads((t.OUT/(filename+'.json')).read_text())
        rid=prior['request_id']
        old.append(dict(source=filename,request_id=rid,trace=c.get('/v1/traces/'+rid).json()))
    t.save('real-refreshed-traces.json',old)
t.save('real-upstream-safe-headers.json',headers)
