"""F12: alter only the controlled server fixture, not student source."""
def pytest_runtest_call(item):
    if item.name.startswith('test_real_transport_mapping_and_success'):
        server = item.funcargs['server']
        server.body['choices'][0]['message']['content'] = 'TEACHER_INJECTED_WRONG_REPLY'
