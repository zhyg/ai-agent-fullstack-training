"""Teacher-controlled HTTP checks; run from llm-gateway with PYTHONPATH=src.
No student business code is changed. All real traffic goes to api.deepseek.com.
"""
import asyncio
from contextlib import contextmanager
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time

import httpx
import uvicorn
import yaml

OUT = Path(__file__).parent
ROOT = Path.cwd()
PRIVATE = Path('/tmp/g74-private')
PRIVATE.mkdir(exist_ok=True, mode=0o700)
RESULTS = []
SCHEMA = {'type':'object','properties':{'answer':{'type':'string'}},'required':['answer'],'additionalProperties':False}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str))


def record(name, ok, **details):
    item = dict(case=name, passed=bool(ok), **details)
    RESULTS.append(item)
    filename = ('supplement-results.json' if Path(sys.argv[0]).name == 'supplement.py'
                else 'teacher-live-results.json' if '--live' in sys.argv else 'teacher-results.json')
    save(filename, RESULTS)
    print(json.dumps(item, ensure_ascii=False, default=str), flush=True)


def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        return s.getsockname()[1]


def body(model='A', structured=False):
    result = dict(model=model, prompt=dict(name='context_answer',version='1.2.0',variables={'context':'answer is OK'}),
                  messages=[{'role':'user','content':'Return answer OK briefly.'}],max_output_tokens=128,timeout_seconds=30)
    if structured:
        result['response_schema'] = SCHEMA
    return result


def wire(path, text='OK', truncated=False):
    if path.endswith('responses'):
        return {'id':'teacher-response','object':'response','model':'deepseek-flash',
                'status':'incomplete' if truncated else 'completed','error':None,
                'incomplete_details':{'reason':'max_output_tokens'} if truncated else None,
                'output':[{'type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':text}]}],
                'usage':{'input_tokens':17,'output_tokens':3,'total_tokens':20,'input_tokens_details':{'cached_tokens':7}}}
    return {'id':'teacher-chat','object':'chat.completion','created':0,'model':'deepseek-flash',
            'choices':[{'index':0,'message':{'role':'assistant','content':text},'finish_reason':'length' if truncated else 'stop'}],
            'usage':{'prompt_tokens':17,'completion_tokens':3,'total_tokens':20,'prompt_cache_hit_tokens':7,'prompt_cache_miss_tokens':10}}


class Upstream:
    def __init__(self):
        self.calls=[]
        self.mode='ok'
        self.text='OK'
        self.count=0
        self.gate=threading.Event()
        self.got_content=threading.Event()
        self.sent_first=0
        self.released=0
        state=self
        class Handler(BaseHTTPRequestHandler):
            protocol_version='HTTP/1.1'
            def log_message(self,*args): pass
            def do_POST(self):
                raw=json.loads(self.rfile.read(int(self.headers['content-length'])))
                state.calls.append({'path':self.path,'body':raw,'at':time.monotonic(),
                                    'authorization_present':bool(self.headers.get('Authorization'))})
                state.count += 1
                status=503 if state.mode=='always503' or (state.mode=='twice503' and state.count <= 2) else (401 if state.mode=='401' else 200)
                try:
                    if raw.get('stream') and status==200:
                        self.send_response(200); self.send_header('Content-Type','text/event-stream');self.send_header('Connection','close');self.end_headers()
                        def send(obj):
                            self.wfile.write(('data: '+(obj if isinstance(obj,str) else json.dumps(obj))+'\n\n').encode());self.wfile.flush()
                        # Heartbeat is deliberately before text and must not set TTFT.
                        self.wfile.write(b': heartbeat\n\n');self.wfile.flush();time.sleep(.15)
                        if self.path.endswith('responses'):
                            send({'type':'response.output_text.delta','delta':'GATED'})
                        else:
                            send({'object':'chat.completion.chunk','model':'deepseek-flash','choices':[{'index':0,'delta':{'content':'GATED'},'finish_reason':None}]})
                        state.sent_first=time.monotonic()
                        state.got_content.set()
                        state.gate.wait(10)
                        state.released=time.monotonic()
                        if state.mode!='interrupt':
                            if self.path.endswith('responses'):
                                send({'type':'response.completed','response':wire(self.path,'GATED')})
                            else:
                                send({'object':'chat.completion.chunk','model':'deepseek-flash','choices':[{'index':0,'delta':{},'finish_reason':'stop'}], 'usage':{'prompt_tokens':17,'completion_tokens':3,'total_tokens':20}})
                                send('[DONE]')
                        self.close_connection=True
                        return
                    data=json.dumps(wire(self.path,state.text,state.mode=='truncated') if status==200 else {'error':{'message':'teacher fault'}}).encode()
                    self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
                except (BrokenPipeError,ConnectionResetError): pass
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads=True
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}/v1'

    def reset(self,mode='ok',text='OK'):
        self.mode=mode;self.text=text;self.count=0;self.gate.clear();self.got_content.clear();self.sent_first=0;self.released=0
        return len(self.calls)

    def close(self):
        self.gate.set();self.server.shutdown();self.server.server_close();self.thread.join()


def make_config(live=False, url=None):
    config=yaml.safe_load((ROOT/'config/gateway.example.yaml').read_text())
    config.pop('auto_routes',None)
    config['database']['password_file']=str(ROOT/'config/postgres.password')
    config['providers']={
        'chat':dict(adapter='deepseek',api_protocol='chat_completions',base_url='https://api.deepseek.com/v1' if live else url,credential_ref='teacher'),
        'responses':dict(adapter='openai_compatible',api_protocol='responses',base_url='https://api.deepseek.com/v1' if live else url,credential_ref='teacher')}
    ep=deepcopy(config['endpoints']['primary-chat'])
    ep.update(provider='chat',model_id='deepseek-flash',structured_output_mode='json_object')
    config['endpoints']={'chat':ep,'responses':dict(ep,provider='responses',structured_output_mode='json_schema')}
    group=dict(default_output_tokens=128,max_output_tokens=4096,default_timeout_seconds=30,max_timeout_seconds=120)
    config['model_groups']={'A':dict(group,candidates=['chat']), 'B':dict(group,candidates=['responses']),
                            'retry':dict(group,candidates=['chat','responses'])}
    config['concurrency']=dict(max_requests=1,max_requests_per_agent=1)
    config['recovery']=dict(max_attempts=3,max_attempts_per_endpoint=2,base_delay_seconds=.2,max_delay_seconds=1.)
    rates=dict(hit='0.1',miss='0.1',output='0.1')
    config['pricing']=dict(bindings={'chat':'teacher','responses':'teacher'},versions=[dict(supplier='teacher',model='deepseek-flash',version='teacher-not-official-billing',effective_from='2026-01-01T00:00:00+00:00',peak=rates,off_peak=rates)])
    directory=PRIVATE/('live' if live else 'controlled');directory.mkdir(exist_ok=True)
    (directory/'gateway.yaml').write_text(yaml.safe_dump(config))
    key=os.environ.get('DEEPSEEK_API_KEY') if live else 'TEACHER_FAKE_KEY'
    if not key:
        raise RuntimeError('DeepSeek key unavailable')
    path=directory/'credentials.yaml';path.write_text(yaml.safe_dump({'credentials':{'teacher':{'api_key':key}}}));path.chmod(0o600)
    # Config has no credentials, but password pathname is replaced for portability.
    sanitized=deepcopy(config);sanitized['database']['password_file']='<PRIVATE_POSTGRES_PASSWORD_FILE>'
    (OUT/('live-config.yaml' if live else 'controlled-config.yaml')).write_text(yaml.safe_dump(sanitized))
    return directory


def prepare(directory):
    from alembic import command
    from alembic.config import Config
    cfg=Config(str(ROOT/'alembic.ini'));cfg.attributes['config_dir']=directory
    command.upgrade(cfg,'head')
    from admin import run,command_line
    parser=command_line()
    async def setup():
        try: await run(parser.parse_args(['--config-dir',str(directory),'create-agent','teacher74','Teacher']))
        except Exception: pass
        await run(parser.parse_args(['--config-dir',str(directory),'deposit','teacher74','100','--operation-id','teacher74-initial']))
        return await run(parser.parse_args(['--config-dir',str(directory),'issue','teacher74']))
    return asyncio.run(setup())


@contextmanager
def gateway(directory, token):
    from main import create_app
    app=create_app(config_dir=directory)
    port=free_port()
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='error'))
    thread=threading.Thread(target=server.run,daemon=True);thread.start()
    for _ in range(200):
        if server.started: break
        if not thread.is_alive():raise RuntimeError('Gateway startup failed')
        time.sleep(.05)
    try:
        with httpx.Client(base_url=f'http://127.0.0.1:{port}',headers={'Authorization':f'Bearer {token}'},timeout=45,trust_env=False) as client:
            yield client,app
    finally:
        server.should_exit=True;thread.join(15)


def invoke(client, label, payload):
    start=time.monotonic();r=client.post('/v1/llm',json=payload)
    data=dict(status=r.status_code,response=r.json(),request_id=r.headers.get('x-request-id'),elapsed_ms=(time.monotonic()-start)*1000)
    if data['request_id']:
        trace=client.get('/v1/traces/'+data['request_id'])
        data['trace']=trace.json()
    save(label+'.json',data)
    return data


def stream(client, upstream, model, interrupt=False, live=False):
    r=client.post('/v1/llm/stream',json=body(model));created=r.json()
    rid=created.get('data',{}).get('request_id')
    if not rid:return dict(create_status=r.status_code,created=created)
    events=[];first=threading.Event();errors=[]
    def read():
        try:
            with client.stream('GET',f'/v1/llm/stream/{rid}/events') as response:
                for line in response.iter_lines():
                    events.append({'at':time.monotonic(),'line':line})
                    if 'GATED' in line or (live and 'response.output_text.delta' in line):first.set()
        except Exception as e:errors.append(type(e).__name__)
    t=threading.Thread(target=read);t.start()
    before=False
    if not live:
        first.wait(5)
        before=first.is_set() and upstream.released==0
        upstream.gate.set()
    t.join(45)
    trace=client.get('/v1/traces/'+rid).json()
    return dict(request_id=rid,events=events,gate_received_before_release=before,trace=trace,errors=errors,reader_alive=t.is_alive())


def controlled():
    upstream=Upstream()
    try:
        directory=make_config(url=upstream.url);token=prepare(directory)
        with gateway(directory,token) as (c,app):
            record('A01',c.get('/healthz').status_code==200,environment='README uv sync locked; Docker Compose PostgreSQL; Alembic; isolated config; Uvicorn factory')
            for model,path,key in [('A','/v1/chat/completions','messages'),('B','/v1/responses','input')]:
                n=upstream.reset();d=invoke(c,'ordinary-'+model,body(model))
                calls=upstream.calls[n:]
                record('A03-'+model,d['status']==200 and len(calls)==1 and calls[0]['path']==path and key in calls[0]['body'],observed=d['response'],calls=calls)
            n=upstream.reset();d=invoke(c,'unknown-model',body('missing'))
            record('A04',d['status']==400 and d['response']['code']=='unknown_model' and len(upstream.calls)==n,result=d)
            for model in ('A','B'):
                n=upstream.reset();d=stream(c,upstream,model);save('stream-'+model+'.json',d)
                record('F01-'+model,d['gate_received_before_release'] and d['trace'].get('data',{}).get('status')=='completed',result=d,calls=upstream.calls[n:])
                n=upstream.reset('interrupt');d=stream(c,upstream,model,True);save('interrupt-'+model+'.json',d)
                record('F02-'+model,d['gate_received_before_release'] and d['trace'].get('data',{}).get('status')=='failed' and len(upstream.calls[n:])==1,result=d,calls=upstream.calls[n:])
                upstream.reset(text='{"answer":"OK"}')
                d=invoke(c,'json-valid-'+model,body(model,True))
                record('F03-schema-'+model,d['status']==200 and d['response'].get('data',{}).get('parsed')=={'answer':'OK'},result=d)
                p=body(model);p['response_format']={'type':'json_object'}
                d=invoke(c,'response-format-'+model,p)
                record('F03-required-field-'+model,d['status']==200,result=d)
                for name,text,mode in [('illegal','not-json','ok'),('empty','','ok'),('truncated','{"answer":','truncated'),('schema','{"answer":7}','ok')]:
                    n=upstream.reset(mode,text);d=invoke(c,'json-'+name+'-'+model,body(model,True))
                    record('F04-'+name+'-'+model,d['status']>=400 and not d['response'].get('success'),result=d,calls=upstream.calls[n:])
            upstream.reset()
            sent=[]
            for version in ('1.0.0','1.1.0','1.0.0'):
                p=body();p['prompt']['version']=version
                n=len(upstream.calls);d=invoke(c,'prompt-'+version+'-'+str(len(sent)),p)
                sent.append({'version':version,'status':d['status'],'messages':upstream.calls[n:][0]['body']['messages'] if len(upstream.calls)>n else []})
            record('F05',all(x['status']==200 for x in sent) and sent[0]['messages']==sent[2]['messages'] and sent[0]['messages']!=sent[1]['messages'] and 'answer is OK' in sent[0]['messages'][-1]['content'],sent=sent)
            for name in ('missing-template','missing-version','missing-variable'):
                p=body()
                if name=='missing-template':p['prompt']['name']='missing'
                elif name=='missing-version':p['prompt']['version']='99.0.0'
                else:p['prompt']['variables']={}
                n=len(upstream.calls);d=invoke(c,name,p)
                record('F06-'+name,400<=d['status']<500 and len(upstream.calls)==n,result=d)
            for mode,model,expected in [('twice503','retry',3),('always503','retry',3),('always503','B',2),('401','A',1),('401','B',1)]:
                n=upstream.reset(mode);d=invoke(c,'retry-'+mode+'-'+model,body(model));calls=upstream.calls[n:]
                deltas=[calls[i]['at']-calls[i-1]['at'] for i in range(1,len(calls))]
                record(('F08' if mode=='twice503' else 'F09')+'-'+mode+'-'+model,len(calls)==expected and (d['status']==200 if mode=='twice503' else d['status']>=400),result=d,calls=calls,actual_intervals_seconds=deltas)
            # Sequential completions never exhaust a rate quota. Occupy A to expose shared concurrency rejection of B.
            upstream.reset();sequential=[invoke(c,'sequential-A-'+str(i),body())['status'] for i in range(4)]
            upstream.reset();r=c.post('/v1/llm/stream',json=body());rid=r.json()['data']['request_id']
            reader=threading.Thread(target=lambda:c.get('/v1/llm/stream/'+rid+'/events'));reader.start();upstream.got_content.wait(5)
            a=invoke(c,'limit-A',body());b=invoke(c,'limit-B',body('B'))
            upstream.gate.set();reader.join(15)
            restored=invoke(c,'limit-restored-B',body('B'))
            record('F10',a['status']==429 and b['status']==200,sequential_A_status=sequential,A=a,B=b,note='Only global/agent concurrency exists; no model or time-window quota')
            record('F11',False,after_release_status=restored['status'],note='Concurrency release works; required model quota replenishment is absent')
            save('controlled-upstream-calls.json',upstream.calls)
    finally:upstream.close()


def live():
    directory=make_config(live=True);token=prepare(directory)
    with gateway(directory,token) as (c,app):
        for model in ('A','B'):
            d=invoke(c,'real-ordinary-'+model,body(model));record('A02-real-'+model,d['status']==200,result=d)
            d=invoke(c,'real-json-'+model,body(model,True));record('F03-real-'+model,d['status']==200,result=d)
            d=stream(c,None,model,live=True);save('real-stream-'+model+'.json',d)
            record('F01-real-'+model,d.get('trace',{}).get('data',{}).get('status')=='completed',result=d)


if __name__=='__main__':
    if '--live' in sys.argv:live()
    else:controlled()
