"""Check grading output and scan actual secret bytes without printing secrets."""
from pathlib import Path
import io
import json
import os
import re
import subprocess
import tarfile

COURSE=Path('/home/user/workspace/repo')
STUDENT=Path('/tmp/G20210579040074-student')
OUT=Path(__file__).parent
feedback=COURSE/'homework/week01/G20210579040074.md'
attachment=COURSE/'homework/week01/attachments/G20210579040074.md'
text=feedback.read_text()
sections={}
for n in (2,3,4):
    value=text.split(f'**{n}. ')[1].split('**',1)[1]
    if n<4:value=value.split(f'**{n+1}. ')[0]
    bullets=[x for x in value.splitlines() if x.startswith('- ')]
    count=sum(len(x[2:]) for x in bullets)
    assert 3<=len(bullets)<=5 and count<=500,(n,len(bullets),count)
    sections[n]={'items':len(bullets),'characters':count}
scores=[15,13,8,10,15,15,3,10]
assert sum(scores)==89
assert '优秀（89分）' in text and '89/100' in attachment.read_text()
assert not re.search('【|待进程结束后填入',text+attachment.read_text())
assert subprocess.run(['git','diff','--exit-code','HEAD','--','llm-gateway'],cwd=STUDENT,capture_output=True).returncode==0
key=os.environ.get('DEEPSEEK_API_KEY','').encode()
assert key, 'Actual key unavailable for leak scan'
scanned=0
def inspect(name,data):
    global scanned
    scanned+=1
    assert key not in data, 'Actual DeepSeek key detected in '+name
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                if member.isfile():inspect(name+'!'+member.name,archive.extractfile(member).read())
for path in [feedback,attachment,*OUT.iterdir()]:
    if path.is_file() and path.name!='delivery-check.json':inspect(str(path),path.read_bytes())
result={'score_sum':sum(scores),'feedback_sections':sections,'actual_key_found':False,
        'scanned_files_including_nested_source':scanned,'student_tracked_files_unchanged':True}
(OUT/'delivery-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
