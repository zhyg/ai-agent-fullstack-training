# G20210579040074 评测证据复现

固定仓库 https://github.com/Jason-Bai/ai-agent-training ，main 提交
`b8698c1448b1f9ca90d7d837fcfae2b2cfdbc6cc`；范围 llm-gateway。
`fixed-source.tar.gz` 为此提交的运行源码、测试、资源、配置和依赖快照；
`source-tree.txt` 还列出了原 llm-gateway 完整树的 Git blob 标识。
历史文档图片不纳入源码子包，原仓库完整克隆仍可按固定 SHA 获取。

## 环境准备

需要 Python 3.12、uv、Docker daemon、Docker Compose 插件。
本次 orb 自备 daemon，PostgreSQL 使用学生原 compose.yaml 的 18.6 镜像。
在 llm-gateway 中执行 README 安装与建库命令：

```bash
uv sync --python 3.12 --locked
cp -n config/postgres.password.example config/postgres.password
docker compose up -d --wait
```

不要将真实 Provider Key 放入证据目录。实际 DeepSeek Key 由进程环境
`DEEPSEEK_API_KEY` 提供，不在命令行参数或日志中输出。
teacher.py 自动生成归档外 /tmp/g74-private/{controlled,live} 独立配置、迁移数据库、
创建教师 Agent、拨款及签发随机短期 Gateway 凭据；凭据只在内存中使用。
脚本将数据库测试密码路径设为本次克隆 config/postgres.password。
测试 Uvicorn 和受控上游只在脚本存活期运行，脚本退出时关闭。

## 执行

将本目录解压到 /tmp/g74-evidence；当前目录设为固定提交的 llm-gateway。

```bash
uv run --python 3.12 python -W error -m pytest -q
PYTHONPATH=src uv run python /tmp/g74-evidence/teacher.py
PYTHONPATH=src:/tmp/g74-evidence uv run python /tmp/g74-evidence/supplement.py
PYTHONPATH=src uv run python /tmp/g74-evidence/teacher.py --live
PYTHONPATH=src:/tmp/g74-evidence uv run python /tmp/g74-evidence/live_followup.py
PYTHONPATH=src:/tmp/g74-evidence uv run python -W error -m pytest -q tests/protocol/test_providers.py::test_real_transport_mapping_and_success -p inject_failure
```

最后一条故意制造错误正文，应报告两条断言失败并返回 1；不是学生默认测试结果。
默认 pytest 不启用学生 live：避免隐式访问其他供应商和读取维护者凭据。
teacher.py --live 只使用学生现有 DeepSeek 和 Responses 适配器，目标固定为 DeepSeek 官方。
重新运行会更新输出；本次原始回执由归档保留，比较时应另解压一份运行。

## 配置差异与证据口径

- original-gateway.yaml 是固定提交的实际跟踪配置，original-gateway.example.yaml 是 README 示例。
- A、B 两个教师别名分别为 Chat Completions 和 Responses；都映射 deepseek-flash。
  这证明两种真实协议，但不证明两个不同物理型号；没有将原百炼模型标为真实通过。
- controlled-config.yaml/live-config.yaml 已脱敏，只保留私密密码文件路径占位。
  teacher.py 会自动生成可用的临时私密文件，归档不包含 credentials.yaml。
- teacher 的价格是测试准入价，不是官方账单；Token、请求延迟是实际记录，不来自价格推算。
- controlled-results.json/teacher-results.json 是原教师完整受控评测；supplement-results.json 是补测；
  teacher-live-results.json 保留包括失败在内的真实调用；real-refreshed-traces.json 是晚到诊断重查。
- 门控先发心跳、150ms 后发正文，只有下游观察正文后才允许上游释放终态，排除一次性缓冲假流式。
- 固定 jitter 验证使用 services.recovery.random=1 的教师进程内时间控制，测试完恢复；
  没有修改业务源码、请求计数或 SDK 重试配置。正常随机回执也单独保留。
- 各 JSON 中的 Gateway request_id 能对应 attempts/usage/timing/billing。
  follow-up 观察到的官方 500 响应没有 request-id 头，未知值如实保存为 null。

完成后停止本次创建的服务并清理归档外私密目录；不把数据库密码或凭据打包。
