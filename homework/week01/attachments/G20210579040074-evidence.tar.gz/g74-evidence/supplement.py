"""Additional teacher observations; no changes to student production code."""
from copy import deepcopy
import json
import time

import teacher as t


def main():
    u=t.Upstream()
    try:
        directory=t.make_config(url=u.url);token=t.prepare(directory)
        with t.gateway(directory,token) as (c,app):
            # Required stream flag is a separate contract from the student's two-step API.
            for model in ('A','B'):
                p=t.body(model);p['stream']=True
                n=u.reset();d=t.invoke(c,'stream-flag-'+model,p)
                t.record('F01-required-flag-'+model,d['status']==200,result=d,calls=u.calls[n:])
            # A successful stream can finalize before the consumer sends its first delta.
            # Check persistent diagnostics again, not merely the immediate trace snapshot.
            fast=[]
            for i in range(3):
                u.reset();u.gate.set()
                r=c.post('/v1/llm/stream',json=t.body('A'));rid=r.json()['data']['request_id']
                received=c.get('/v1/llm/stream/'+rid+'/events').text
                immediate=c.get('/v1/traces/'+rid).json()
                time.sleep(1.2)
                late=c.get('/v1/traces/'+rid).json()
                fast.append(dict(request_id=rid,events=received,immediate=immediate,late=late))
            t.save('fast-stream-timing.json',fast)
            # Delay and SDK retry evidence with deterministic jitter, not altered policy.
            import services.recovery as recovery
            old=recovery.random;recovery.random=lambda:1.0
            try:
                n=u.reset('twice503');d=t.invoke(c,'retry-deterministic',t.body('retry'))
                calls=u.calls[n:]
                t.record('F08-deterministic',d['status']==200 and len(calls)==3,result=d,calls=calls,
                         intervals=[calls[i]['at']-calls[i-1]['at'] for i in range(1,len(calls))])
                # Same SDK endpoint gets exactly two wire requests, not 2 x SDK-default attempts.
                n=u.reset('always503');d=t.invoke(c,'sdk-deterministic',t.body('B'))
                calls=u.calls[n:]
                t.record('F09-sdk-deterministic',len(calls)==2,result=d,calls=calls)
                s=recovery.RecoveryState(app.state.model_registry.recovery,128,128)
                s.start('chat');first=s.delay(type('E',(),{})(),'chat')
                s.start('chat');second=s.delay(type('E',(),{})(),'chat')
                t.record('F08-policy-ceilings',first==.2 and second==.4,first=first,second=second,
                         note='Second ceiling is inspected via policy only; per-endpoint cap prevents a third call to the same endpoint')
            finally:recovery.random=old
            # Independently assert F07 values from asymmetric upstream fixture counts.
            observations=[]
            for model in ('A','B'):
                u.reset();d=t.invoke(c,'observability-'+model,t.body(model))
                rid=d['request_id'];billing=c.get('/v1/billing/requests/'+rid).json()
                observations.append(dict(model=model,result=d,billing=billing))
            u.reset('401');failed=t.invoke(c,'observability-failed',t.body())
            t.save('observability.json',dict(success=observations,failure=failed))
            t.record('F07',all(x['result']['trace']['data']['usage']['known_subtotal']==dict(input_tokens=17,output_tokens=3,total_tokens=20) for x in observations)
                     and failed['trace']['data']['status']=='failed'
                     and all(x['late']['data']['timing']['ttft_ms'] is not None for x in fast),
                     normal_usage=[x['result']['trace']['data']['usage'] for x in observations],
                     fast_stream_ttft=[x['late']['data']['timing']['ttft_ms'] for x in fast],failure_trace=failed['trace'])
    finally:u.close()


if __name__=='__main__':
    t.RESULTS=[]
    main()
    t.save('supplement-results.json',t.RESULTS)
