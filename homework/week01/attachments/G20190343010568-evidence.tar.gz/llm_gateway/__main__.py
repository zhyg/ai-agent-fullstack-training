"""以 `python -m llm_gateway` 启动本地服务。"""

from __future__ import annotations

import uvicorn

from llm_gateway.app.main import app


def main() -> None:
    """只监听本机。密钥通过环境变量注入，不写进命令行。"""
    uvicorn.run(app, host="127.0.0.1", port=8000)


if __name__ == "__main__":
    main()
