"""纯函数和不依赖上游的策略测试。"""

from __future__ import annotations

import pytest

from llm_gateway.app.adapters.base import CallContext
from llm_gateway.app.adapters.messages import build_messages_payload, events_from_messages
from llm_gateway.app.adapters.responses import build_responses_payload, events_from_responses
from llm_gateway.app.config import Settings
from llm_gateway.app.errors import GatewayError
from llm_gateway.app.prompts.render import render_template
from llm_gateway.app.prompts.store import PromptStore
from llm_gateway.app.ratelimit import SlidingWindowLimiter
from llm_gateway.app.retry import retry_async
from llm_gateway.app.routing import resolve_model
from llm_gateway.app.schemas import ChatMessage, JsonSchemaBody, ResponseFormat
from llm_gateway.app.usage import usage_from_messages, usage_from_responses
from llm_gateway.app.config import ModelConfig


def _settings() -> Settings:
    return Settings(
        models={
            "deepseek-v4-pro": ModelConfig(
                "deepseek-v4-pro", "responses", "deepseek-v4-pro", "https://api.deepseek.com", 60
            )
        },
        prompts_dir=__import__("pathlib").Path("."),
    )


def _ctx(protocol: str = "responses") -> CallContext:
    return CallContext(
        request_id="req_test",
        public_model="deepseek-v4-pro" if protocol == "responses" else "deepseek-v4-flash",
        protocol=protocol,
        upstream_model="deepseek-v4-pro" if protocol == "responses" else "deepseek-flash",
        base_url="https://api.deepseek.com",
        api_key="secret",
        messages=[
            ChatMessage(role="system", content="be brief"),
            ChatMessage(role="user", content="hi"),
        ],
        response_format=ResponseFormat(
            type="json_schema",
            json_schema=JsonSchemaBody.model_validate(
                {"name": "Answer", "schema": {"type": "object", "properties": {"a": {"type": "string"}}}}
            ),
        ),
        max_tokens=128,
        temperature=0,
    )


def test_resolve_unknown_model() -> None:
    with pytest.raises(GatewayError) as caught:
        resolve_model(_settings(), "missing")
    assert caught.value.code == "model_not_found"
    assert caught.value.status_code == 404


def test_render_replaces_variables_and_reports_missing() -> None:
    assert render_template("你好 {{ name }}", {"name": "Ada"}) == "你好 Ada"
    with pytest.raises(GatewayError) as caught:
        render_template("{{text}}", {})
    assert caught.value.code == "invalid_request"


def test_prompt_store_rejects_path_traversal(tmp_path) -> None:
    store = PromptStore(tmp_path)
    with pytest.raises(GatewayError) as caught:
        store.put("../evil", "1", "x", "")
    assert caught.value.code == "invalid_request"
    saved = store.put("extract", "1.0.0", "hello {{text}}", "demo")
    assert store.get("extract", "1.0.0")["template"] == saved["template"]


@pytest.mark.asyncio
async def test_rate_limit_is_per_model_and_window() -> None:
    now = {"value": 0.0}
    limiter = SlidingWindowLimiter(clock=lambda: now["value"], window_seconds=60)
    await limiter.consume("pro", 2)
    await limiter.consume("pro", 2)
    with pytest.raises(GatewayError) as caught:
        await limiter.consume("pro", 2)
    assert caught.value.code == "rate_limited"
    await limiter.consume("flash", 2)
    now["value"] = 60
    await limiter.consume("pro", 2)


@pytest.mark.asyncio
async def test_retry_stops_at_three_and_skips_non_retryable() -> None:
    settings = _settings()
    calls = {"n": 0}

    async def flaky() -> str:
        calls["n"] += 1
        if calls["n"] < 3:
            raise GatewayError("upstream_error", "busy", 502, retryable=True)
        return "ok"

    value, attempts = await retry_async(flaky, settings)
    assert value == "ok"
    assert attempts == 3

    async def rejected() -> str:
        calls["n"] += 1
        raise GatewayError("upstream_error", "bad", 502, retryable=False)

    calls["n"] = 0
    with pytest.raises(GatewayError) as caught:
        await retry_async(rejected, settings)
    assert calls["n"] == 1
    assert caught.value.attempts == 1


def test_usage_categories_follow_each_protocol() -> None:
    responses = usage_from_responses(
        {
            "input_tokens": 11,
            "output_tokens": 7,
            "total_tokens": 18,
            "input_tokens_details": {"cached_tokens": 4},
            "output_tokens_details": {"reasoning_tokens": 2},
        }
    )
    assert responses.as_dict() == {
        "input_tokens": 11,
        "output_tokens": 7,
        "total_tokens": 18,
        "cached_tokens": 4,
        "reasoning_tokens": 2,
    }
    messages = usage_from_messages(
        {
            "input_tokens": 5,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 3,
            "output_tokens": 9,
            "output_tokens_details": {"thinking_tokens": 6},
        }
    )
    assert messages.input_tokens == 8
    assert messages.cached_tokens == 3
    assert messages.reasoning_tokens == 6
    assert messages.total_tokens == 17


def test_adapters_emit_different_protocols() -> None:
    responses = build_responses_payload(_ctx("responses"), stream=True)
    assert responses["model"] == "deepseek-v4-pro"
    assert responses["instructions"] == "be brief"
    assert responses["input"][0]["role"] == "user"
    assert responses["reasoning"] == {"effort": "none"}
    assert responses["text"]["format"]["type"] == "json_schema"
    assert "messages" not in responses

    messages = build_messages_payload(_ctx("messages"), stream=False)
    assert messages["model"] == "deepseek-flash"
    assert messages["thinking"] == {"type": "disabled"}
    assert messages["output_config"]["effort"] == "none"
    assert messages["output_config"]["format"]["type"] == "json_schema"
    assert "JSON Schema" in messages["system"]
    assert messages["messages"][0]["role"] == "user"
    assert "input" not in messages


def test_sse_parsers_ignore_reasoning_and_keep_usage() -> None:
    deltas = events_from_responses(
        "response.output_text.delta",
        {"type": "response.output_text.delta", "delta": "Hi"},
    )
    assert deltas[0].text == "Hi"
    done = events_from_responses(
        "response.completed",
        {
            "type": "response.completed",
            "response": {
                "status": "completed",
                "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2},
            },
        },
    )
    assert done[0].usage.total_tokens == 2
    assert events_from_messages(
        "content_block_delta",
        {"type": "content_block_delta", "delta": {"type": "thinking_delta", "thinking": "secret"}},
    ) == []
    text = events_from_messages(
        "content_block_delta",
        {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "yo"}},
    )
    assert text[0].text == "yo"
