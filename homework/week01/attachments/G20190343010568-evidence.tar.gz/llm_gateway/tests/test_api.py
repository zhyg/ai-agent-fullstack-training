"""通过 ASGI 覆盖聊天、流式、JSON、模板、重试和限流。"""

from __future__ import annotations

import json

import httpx
import pytest

from llm_gateway.app.config import PACKAGE_ROOT, ModelConfig, Settings
from llm_gateway.app.main import create_app


def _settings(base_url: str, prompts, rpm: int = 60) -> Settings:
    return Settings(
        models={
            "deepseek-v4-pro": ModelConfig(
                "deepseek-v4-pro", "responses", "deepseek-v4-pro", base_url, rpm
            ),
            "deepseek-v4-flash": ModelConfig(
                "deepseek-v4-flash", "messages", "deepseek-flash", base_url + "/anthropic", rpm
            ),
        },
        prompts_dir=prompts,
        retry_base_seconds=0,
        retry_max_seconds=0,
        request_timeout_seconds=5,
    )


def _responses_body(text: str) -> dict:
    return {
        "status": "completed",
        "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}],
        "usage": {
            "input_tokens": 11,
            "output_tokens": 7,
            "total_tokens": 18,
            "input_tokens_details": {"cached_tokens": 4},
            "output_tokens_details": {"reasoning_tokens": 2},
        },
    }


def _messages_body(text: str) -> dict:
    return {
        "content": [{"type": "text", "text": text}],
        "usage": {
            "input_tokens": 5,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 3,
            "output_tokens": 9,
            "output_tokens_details": {"thinking_tokens": 6},
        },
    }


def _responses_sse() -> bytes:
    completed = {
        "type": "response.completed",
        "response": {
            "status": "completed",
            "output": [],
            "usage": _responses_body("")["usage"],
        },
    }
    return (
        "event: response.output_text.delta\n"
        'data: {"type":"response.output_text.delta","delta":"Hi"}\n\n'
        "event: response.completed\n"
        f"data: {json.dumps(completed)}\n\n"
    ).encode()


def _messages_sse() -> bytes:
    delta = {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Yo"}}
    usage = {
        "type": "message_delta",
        "delta": {"stop_reason": "end_turn"},
        "usage": _messages_body("")["usage"],
    }
    return (
        "event: content_block_delta\n"
        f"data: {json.dumps(delta)}\n\n"
        "event: message_delta\n"
        f"data: {json.dumps(usage)}\n\n"
        "event: message_stop\n"
        'data: {"type":"message_stop"}\n\n'
    ).encode()


def parse_sse(text: str) -> list[tuple[str, dict]]:
    """把测试里读到的 SSE 正文还原成事件。"""
    events: list[tuple[str, dict]] = []
    event = "message"
    data: list[str] = []
    for line in text.splitlines():
        if line == "":
            if data:
                events.append((event, json.loads("\n".join(data))))
            event = "message"
            data = []
            continue
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
    if data:
        events.append((event, json.loads("\n".join(data))))
    return events


@pytest.fixture
def api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")


@pytest.mark.asyncio
async def test_chat_routes_protocols_stream_json_template_and_retry(api_key, tmp_path) -> None:
    seen: list[httpx.Request] = []
    state = {"failures": 2, "bad_json": 2}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        body = json.loads(request.content.decode())
        path = request.url.path
        if path == "/responses":
            assert request.headers["authorization"] == "Bearer test-key"
            if body.get("stream"):
                return httpx.Response(200, content=_responses_sse())
            if body.get("text"):
                state["bad_json"] -= 1
                text = "NOPE" if state["bad_json"] >= 0 else '{"a": 1}'
            elif state["failures"] > 0:
                state["failures"] -= 1
                return httpx.Response(503, json={"error": {"message": "busy"}})
            else:
                text = "Hello"
            return httpx.Response(200, json=_responses_body(text))
        assert path == "/anthropic/v1/messages"
        assert request.headers["x-api-key"] == "test-key"
        assert "authorization" not in request.headers
        if body.get("stream"):
            return httpx.Response(200, content=_messages_sse())
        return httpx.Response(200, json=_messages_body("flash-ok"))

    settings = _settings("http://upstream.test", PACKAGE_ROOT / "prompts")
    app = create_app(settings, httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://gateway") as client:
        health = await client.get("/health")
        assert health.status_code == 200
        models = await client.get("/v1/models")
        assert {item["id"] for item in models.json()["data"]} == {"deepseek-v4-pro", "deepseek-v4-flash"}

        missing = await client.post(
            "/v1/chat/completions",
            json={"model": "nope", "messages": [{"role": "user", "content": "hi"}]},
        )
        assert missing.status_code == 404
        assert missing.json()["error"]["code"] == "model_not_found"

        retried = await client.post(
            "/v1/chat/completions",
            json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}]},
        )
        assert retried.status_code == 200
        assert retried.json()["attempts"] == 3
        assert retried.json()["content"] == "Hello"
        assert retried.json()["protocol"] == "responses"
        assert retried.json()["ttft_ms"] == retried.json()["latency_ms"]
        assert retried.json()["usage"]["cached_tokens"] == 4

        structured = await client.post(
            "/v1/chat/completions",
            json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "json"}],
                "response_format": {"type": "json_object"},
            },
        )
        assert structured.status_code == 200
        assert structured.json()["parsed"] == {"a": 1}
        assert structured.json()["attempts"] == 3

        templated = await client.post(
            "/v1/chat/completions",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "抽取"}],
                "prompt_ref": {"id": "extract", "version": "1.0.0", "variables": {"text": "TOKEN-ADA-42"}},
            },
        )
        assert templated.status_code == 200
        assert templated.json()["protocol"] == "messages"
        assert templated.json()["usage"]["input_tokens"] == 8
        assert templated.json()["usage"]["reasoning_tokens"] == 6
        upstream = json.loads(seen[-1].content.decode())
        assert "TOKEN-ADA-42" in upstream["system"]
        assert "{{text}}" not in upstream["system"]

        missing_var = await client.post(
            "/v1/chat/completions",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "抽取"}],
                "prompt_ref": {"id": "extract", "version": "1.0.0", "variables": {}},
            },
        )
        assert missing_var.status_code == 400
        assert missing_var.json()["error"]["code"] == "invalid_request"

        streamed = await client.post(
            "/v1/chat/completions",
            json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}], "stream": True},
        )
        frames = parse_sse(streamed.text)
        assert [name for name, _ in frames] == ["meta", "delta", "done"]
        assert frames[1][1]["text"] == "Hi"
        assert frames[2][1]["usage"]["reasoning_tokens"] == 2
        assert frames[2][1]["ttft_ms"] <= frames[2][1]["latency_ms"]

        flash_stream = await client.post(
            "/v1/chat/completions",
            json={"model": "deepseek-v4-flash", "messages": [{"role": "user", "content": "hi"}], "stream": True},
        )
        flash_frames = parse_sse(flash_stream.text)
        assert flash_frames[0][1]["protocol"] == "messages"
        assert flash_frames[2][1]["usage"]["cached_tokens"] == 3

        metrics = await client.get("/v1/metrics/calls")
        assert metrics.status_code == 200
        assert any(item["usage"]["cached_tokens"] == 4 and item["ttft_ms"] is not None for item in metrics.json()["data"])

    response_bodies = [json.loads(item.content.decode()) for item in seen if item.url.path == "/responses"]
    assert any(item.get("reasoning") == {"effort": "none"} for item in response_bodies)
    message_bodies = [json.loads(item.content.decode()) for item in seen if item.url.path == "/anthropic/v1/messages"]
    assert any(item.get("thinking") == {"type": "disabled"} for item in message_bodies)


@pytest.mark.asyncio
async def test_rate_limit_returns_429_without_calling_upstream(api_key, tmp_path) -> None:
    seen: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request.url.path)
        return httpx.Response(200, json=_responses_body("ok"))

    app = create_app(
        _settings("http://upstream.test", tmp_path, rpm=2),
        httpx.AsyncClient(transport=httpx.MockTransport(handler)),
    )
    payload = {"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}]}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://gateway") as client:
        assert (await client.post("/v1/chat/completions", json=payload)).status_code == 200
        assert (await client.post("/v1/chat/completions", json=payload)).status_code == 200
        blocked = await client.post("/v1/chat/completions", json=payload)
    assert blocked.status_code == 429
    assert blocked.json()["error"]["code"] == "rate_limited"
    assert blocked.json()["error"]["retryable"] is False
    assert len(seen) == 2
