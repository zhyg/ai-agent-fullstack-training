# LLM 统一模型调用服务

对外只有一套聊天接口。`model` 决定适配器：

- `deepseek-v4-pro` 走 OpenAI Responses API，`POST https://api.deepseek.com/responses`，`Authorization: Bearer`
- `deepseek-v4-flash` 走 Anthropic Messages API，`POST https://api.deepseek.com/anthropic/v1/messages`，`x-api-key`。上游模型名是 `deepseek-flash`

两个适配器都关闭思考模式，并把用量收成同一组字段：`input_tokens`、`output_tokens`、`total_tokens`、`cached_tokens`、`reasoning_tokens`。`cached_tokens` 是输入的子集，`reasoning_tokens` 是输出的子集。

Messages 上游会忽略 `output_config.format`。网关仍按 Anthropic 字段发送 schema，同时把约束写进 system，并在本地校验 JSON。不合法时按可重试错误处理。

## 启动

在仓库根目录执行。密钥只放在环境变量里。

```powershell
cd d:\ai\AI_Agent
python -m venv .venv
.venv\Scripts\activate
pip install -r llm_gateway\requirements.txt
$env:DEEPSEEK_API_KEY = "sk-..."
python -m llm_gateway
```

服务监听 `127.0.0.1:8000`。配置在 `llm_gateway/config.yaml`，每个模型默认每分钟 60 次。连接失败以及上游 429/500/502/503/504/529 会指数退避，最多 3 次请求。

Windows 上请用 `curl.exe`。`curl` 是 `Invoke-WebRequest` 的别名。

## 调用示例

健康检查和模型列表：

```powershell
curl.exe http://127.0.0.1:8000/health
curl.exe http://127.0.0.1:8000/v1/models
```

Responses 协议，非流式：

```powershell
curl.exe http://127.0.0.1:8000/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"deepseek-v4-pro\",\"messages\":[{\"role\":\"user\",\"content\":\"用一句话介绍你自己\"}]}"
```

Messages 协议，流式。事件依次是 `meta`、`delta`、`done`：

```powershell
curl.exe -N http://127.0.0.1:8000/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"deepseek-v4-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"数到三\"}],\"stream\":true}"
```

结构化输出。`done` 或 JSON 响应里的 `parsed` 是校验后的对象：

```powershell
curl.exe http://127.0.0.1:8000/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"deepseek-v4-pro\",\"messages\":[{\"role\":\"user\",\"content\":\"最长的河是尼罗河\"}],\"response_format\":{\"type\":\"json_schema\",\"json_schema\":{\"name\":\"Extract\",\"schema\":{\"type\":\"object\",\"properties\":{\"question\":{\"type\":\"string\"},\"answer\":{\"type\":\"string\"}},\"required\":[\"question\",\"answer\"],\"additionalProperties\":false}}}}"
```

提示词版本。仓库自带 `extract/1.0.0`，模板使用 `{{text}}`：

```powershell
curl.exe http://127.0.0.1:8000/v1/prompts/extract/versions/1.0.0
curl.exe http://127.0.0.1:8000/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"deepseek-v4-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"请抽取\"}],\"prompt_ref\":{\"id\":\"extract\",\"version\":\"1.0.0\",\"variables\":{\"text\":\"最长的河是尼罗河\"}}}"
```

写入新版本：

```powershell
curl.exe -X PUT http://127.0.0.1:8000/v1/prompts/extract/versions/1.1.0 -H "Content-Type: application/json" -d "{\"template\":\"只输出 JSON。文本：{{text}}\",\"description\":\"更短的抽取模板\"}"
```

观测最近调用，包含分类 token、总延迟和首 token 延迟：

```powershell
curl.exe http://127.0.0.1:8000/v1/metrics/calls?limit=10
```

非流式响应的 `ttft_ms` 与 `latency_ms` 相同。流式响应的 `ttft_ms` 是从开始到第一个正文增量的时间。

## 错误码

错误体形如 `{"error":{"code":"...","message":"...","retryable":false}}`。

- `invalid_request`：请求体、schema 或模板变量不合法，HTTP 400
- `template_not_found`：提示词版本不存在，HTTP 404
- `model_not_found`：模型未配置，HTTP 404
- `rate_limited`：该模型超过每分钟配额，HTTP 429，不访问上游
- `invalid_json`：模型输出不是合法 JSON 或不匹配 schema，重试耗尽后 HTTP 502
- `upstream_error` / `upstream_timeout`：上游失败或超时，HTTP 502 / 504

## 验证

```powershell
python llm_gateway\scripts\verify.py
pytest llm_gateway
```

`verify.py` 会启动本地双协议 mock，并打印 JSON 报告，覆盖两种协议、流式、结构化输出、模板替换、用量和首 token 延迟、3 次重试、按模型 429。未设置 `DEEPSEEK_API_KEY` 时跳过真实调用。设置之后会再各请求一次两个模型。

`pytest` 在 `llm_gateway` 目录下也可以直接运行，配置已经把上一级目录加进 `pythonpath`。
