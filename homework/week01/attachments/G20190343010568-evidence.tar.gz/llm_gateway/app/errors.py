"""统一错误码。

业务异常都收敛成 GatewayError，HTTP 层只负责把它写成同一种 JSON。
"""

from __future__ import annotations


class GatewayError(Exception):
    """可映射到 HTTP 响应的网关错误。"""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int,
        *,
        retryable: bool = False,
        upstream_status: int | None = None,
        request_id: str | None = None,
        attempts: int | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retryable = retryable
        self.upstream_status = upstream_status
        self.request_id = request_id
        self.attempts = attempts

    def public(self) -> dict:
        """返回给调用方的错误体，不包含堆栈或上游原文。"""
        error: dict = {
            "code": self.code,
            "message": self.message,
            "retryable": self.retryable,
        }
        if self.upstream_status is not None:
            error["upstream_status"] = self.upstream_status
        if self.request_id is not None:
            error["request_id"] = self.request_id
        if self.attempts is not None:
            error["attempts"] = self.attempts
        return {"error": error}
