"""内存环形缓冲，保存最近若干次调用的用量和延迟。"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from llm_gateway.app.usage import Usage


@dataclass
class CallRecord:
    """一次对调用方可见的观测记录。不含提示词和模型正文。"""

    request_id: str
    model: str
    protocol: str
    status: str
    attempts: int
    latency_ms: float
    ttft_ms: float | None
    usage: Usage
    error_code: str | None = None
    created_at: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "model": self.model,
            "protocol": self.protocol,
            "status": self.status,
            "attempts": self.attempts,
            "latency_ms": round(self.latency_ms, 3),
            "ttft_ms": None if self.ttft_ms is None else round(self.ttft_ms, 3),
            "usage": self.usage.as_dict(),
            "error_code": self.error_code,
            "created_at": self.created_at,
        }

    def __post_init__(self) -> None:
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()


class MetricsStore:
    """固定容量的调用记录。超出后丢弃最旧的一条。"""

    def __init__(self, capacity: int) -> None:
        self._records: deque[CallRecord] = deque(maxlen=max(1, capacity))

    def record(self, item: CallRecord) -> None:
        self._records.append(item)

    def latest(self, limit: int) -> list[dict[str, Any]]:
        if limit < 1:
            return []
        chosen = list(self._records)[-limit:]
        return [item.as_dict() for item in reversed(chosen)]
