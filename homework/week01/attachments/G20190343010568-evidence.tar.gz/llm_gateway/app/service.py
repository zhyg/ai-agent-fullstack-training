"""编排模板、限流、重试、适配器和观测。路由只做 HTTP 转换。"""

from __future__ import annotations

import logging
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx

from llm_gateway.app.adapters.base import CallContext, Completion, StreamDone, TextDelta
from llm_gateway.app.adapters.messages import MessagesAdapter
from llm_gateway.app.adapters.responses import ResponsesAdapter
from llm_gateway.app.config import Settings
from llm_gateway.app.errors import GatewayError
from llm_gateway.app.json_output import assert_schema, ensure_json
from llm_gateway.app.metrics import CallRecord, MetricsStore
from llm_gateway.app.prompts.render import render_template
from llm_gateway.app.prompts.store import PromptStore
from llm_gateway.app.ratelimit import SlidingWindowLimiter
from llm_gateway.app.retry import retry_async
from llm_gateway.app.routing import resolve_model
from llm_gateway.app.schemas import ChatMessage, ChatRequest
from llm_gateway.app.sse import encode_sse
from llm_gateway.app.usage import Usage

logger = logging.getLogger("llm_gateway")


class ChatService:
    """一次聊天请求的完整生命周期。"""

    def __init__(
        self,
        settings: Settings,
        http: httpx.AsyncClient,
        limiter: SlidingWindowLimiter,
        metrics: MetricsStore,
        prompts: PromptStore,
    ) -> None:
        self.settings = settings
        self.http = http
        self.limiter = limiter
        self.metrics = metrics
        self.prompts = prompts

    async def complete(self, payload: ChatRequest) -> dict[str, Any]:
        """非流式调用。非法 JSON 会占用重试次数。"""
        ctx = self._prepare(payload)
        started = time.perf_counter()

        async def once() -> tuple[Completion, Any]:
            result = await self._adapter(ctx).complete(ctx)
            parsed = None
            if ctx.response_format is not None:
                parsed = ensure_json(result.content, ctx.response_format)
            return result, parsed

        try:
            await self._consume_quota(ctx)
            (result, parsed), attempts = await retry_async(once, self.settings)
        except GatewayError as exc:
            self._finish(ctx, "error", exc.attempts or 1, started, started, Usage(), exc.code)
            exc.request_id = exc.request_id or ctx.request_id
            raise
        latency = _elapsed_ms(started)
        self._finish(ctx, "ok", attempts, started, started, result.usage, None, latency)
        return {
            "id": ctx.request_id,
            "model": ctx.public_model,
            "protocol": ctx.protocol,
            "content": result.content,
            "parsed": parsed,
            "usage": result.usage.as_dict(),
            "latency_ms": round(latency, 3),
            "ttft_ms": round(latency, 3),
            "attempts": attempts,
        }

    async def open_stream(self, payload: ChatRequest) -> AsyncIterator[str]:
        """建立上游流。在产出第一帧之前失败会抛 GatewayError，调用方返回 JSON。"""
        ctx = self._prepare(payload)
        started = time.perf_counter()
        ttft: list[float | None] = [None]
        try:
            iterator, attempts = await self._connect(ctx, started, ttft)
        except GatewayError as exc:
            self._finish(ctx, "error", exc.attempts or 1, started, started, Usage(), exc.code)
            exc.request_id = exc.request_id or ctx.request_id
            raise

        async def frames() -> AsyncIterator[str]:
            parts: list[str] = []
            usage = Usage()
            final_text = ""
            status = "ok"
            error_code = None
            completed = False
            try:
                yield encode_sse(
                    "meta",
                    {
                        "request_id": ctx.request_id,
                        "model": ctx.public_model,
                        "protocol": ctx.protocol,
                    },
                )
                async for event in iterator:
                    if isinstance(event, TextDelta):
                        parts.append(event.text)
                        yield encode_sse("delta", {"text": event.text})
                    elif isinstance(event, StreamDone):
                        usage = event.usage
                        final_text = event.content
                content = "".join(parts) if parts else final_text
                parsed = None
                if ctx.response_format is not None:
                    parsed = ensure_json(content, ctx.response_format)
                latency = _elapsed_ms(started)
                first_token = ttft[0] if ttft[0] is not None else latency
                yield encode_sse(
                    "done",
                    {
                        "request_id": ctx.request_id,
                        "content": content,
                        "parsed": parsed,
                        "usage": usage.as_dict(),
                        "latency_ms": round(latency, 3),
                        "ttft_ms": round(first_token, 3),
                        "attempts": attempts,
                    },
                )
                completed = True
            except GatewayError as exc:
                status = "error"
                error_code = exc.code
                exc.request_id = ctx.request_id
                yield encode_sse("error", exc.public()["error"])
            except BaseException:
                status = "error"
                error_code = "cancelled"
                raise
            finally:
                if not completed and status == "ok":
                    status = "error"
                    error_code = error_code or "incomplete"
                self._finish(ctx, status, attempts, started, started, usage, error_code, ttft[0])

        return frames()

    def _prepare(self, payload: ChatRequest) -> CallContext:
        request_id = "req_" + uuid.uuid4().hex
        try:
            model = resolve_model(self.settings, payload.model)
            messages = list(payload.messages)
            if payload.prompt_ref is not None:
                ref = payload.prompt_ref
                stored = self.prompts.get(ref.id, ref.version)
                rendered = render_template(str(stored["template"]), ref.variables)
                messages.insert(0, ChatMessage(role="system", content=rendered))
            if not any(message.role == "user" for message in messages):
                raise GatewayError("invalid_request", "at least one user message is required", 400)
            assert_schema(payload.response_format)
            api_key = self.settings.api_key()
            if not api_key:
                raise GatewayError(
                    "invalid_request",
                    f"{self.settings.api_key_env} is not set",
                    400,
                )
            return CallContext(
                request_id=request_id,
                public_model=model.name,
                protocol=model.protocol,
                upstream_model=model.upstream_model,
                base_url=model.base_url,
                api_key=api_key,
                messages=messages,
                response_format=payload.response_format,
                max_tokens=payload.max_tokens,
                temperature=payload.temperature,
            )
        except GatewayError as exc:
            exc.request_id = request_id
            raise

    async def _consume_quota(self, ctx: CallContext) -> None:
        model = self.settings.models[ctx.public_model]
        try:
            await self.limiter.consume(model.name, model.rpm)
        except GatewayError as exc:
            exc.request_id = ctx.request_id
            raise

    async def _connect(
        self,
        ctx: CallContext,
        started: float,
        ttft: list[float | None],
    ) -> tuple[AsyncIterator[TextDelta | StreamDone], int]:
        await self._consume_quota(ctx)
        attempt = 0
        while True:
            attempt += 1
            agen = self._adapter(ctx).stream(ctx)
            primed: list[TextDelta | StreamDone] = []
            try:
                iterator = agen.__aiter__()
                while True:
                    try:
                        event = await iterator.__anext__()
                    except StopAsyncIteration:
                        return _resume(iterator, primed), attempt
                    if isinstance(event, TextDelta):
                        if ttft[0] is None:
                            ttft[0] = _elapsed_ms(started)
                        primed.append(event)
                        return _resume(iterator, primed), attempt
                    primed.append(event)
            except GatewayError as exc:
                await _aclose(agen)
                if not exc.retryable or attempt >= self.settings.retry_max_attempts:
                    exc.attempts = attempt
                    raise
                await _backoff(self.settings.retry_base_seconds * (2 ** (attempt - 1)), self.settings)

    def _adapter(self, ctx: CallContext) -> ResponsesAdapter | MessagesAdapter:
        if ctx.protocol == "responses":
            return ResponsesAdapter(self.http)
        return MessagesAdapter(self.http)

    def _finish(
        self,
        ctx: CallContext,
        status: str,
        attempts: int,
        started: float,
        _ttft_started: float,
        usage: Usage,
        error_code: str | None,
        ttft_ms: float | None = None,
    ) -> None:
        latency = _elapsed_ms(started)
        first = latency if ttft_ms is None else ttft_ms
        record = CallRecord(
            request_id=ctx.request_id,
            model=ctx.public_model,
            protocol=ctx.protocol,
            status=status,
            attempts=attempts,
            latency_ms=latency,
            ttft_ms=first,
            usage=usage,
            error_code=error_code,
        )
        self.metrics.record(record)
        logger.info(
            "request_id=%s model=%s protocol=%s status=%s attempts=%s latency_ms=%.3f ttft_ms=%.3f "
            "input_tokens=%s output_tokens=%s cached_tokens=%s reasoning_tokens=%s error_code=%s",
            ctx.request_id,
            ctx.public_model,
            ctx.protocol,
            status,
            attempts,
            latency,
            first,
            usage.input_tokens,
            usage.output_tokens,
            usage.cached_tokens,
            usage.reasoning_tokens,
            error_code or "",
        )


async def _resume(
    iterator: AsyncIterator[TextDelta | StreamDone],
    primed: list[TextDelta | StreamDone],
) -> AsyncIterator[TextDelta | StreamDone]:
    for event in primed:
        yield event
    while True:
        try:
            event = await iterator.__anext__()
        except StopAsyncIteration:
            return
        yield event


async def _aclose(agen: AsyncIterator[Any]) -> None:
    close = getattr(agen, "aclose", None)
    if close is None:
        return
    try:
        await close()
    except RuntimeError:
        return


async def _backoff(delay: float, settings: Settings) -> None:
    import asyncio

    wait = min(delay, settings.retry_max_seconds)
    if wait > 0:
        await asyncio.sleep(wait)


def _elapsed_ms(started: float) -> float:
    return (time.perf_counter() - started) * 1000
