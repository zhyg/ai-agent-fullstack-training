"""对外请求体和归一化后的内部调用参数。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ChatMessage(BaseModel):
    """一条对话消息。content 只接受纯文本。"""

    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=100_000)


class JsonSchemaBody(BaseModel):
    """response_format.type=json_schema 时携带的 schema。"""

    model_config = ConfigDict(populate_by_name=True)

    name: str = Field(default="response", min_length=1, max_length=64)
    schema_def: dict[str, Any] = Field(alias="schema")


class ResponseFormat(BaseModel):
    """统一的结构化输出约束。适配器再翻译成各自协议的字段。"""

    type: Literal["json_object", "json_schema"]
    json_schema: JsonSchemaBody | None = None

    @model_validator(mode="after")
    def require_schema(self) -> ResponseFormat:
        if self.type == "json_schema" and self.json_schema is None:
            raise ValueError("json_schema is required when type is json_schema")
        return self


class PromptRef(BaseModel):
    """按 id 和版本引用已存储的提示词，并用 variables 替换 {{var}}。"""

    id: str = Field(min_length=1, max_length=64)
    version: str = Field(min_length=1, max_length=64)
    variables: dict[str, Any] = Field(default_factory=dict)


class ChatRequest(BaseModel):
    """POST /v1/chat/completions 的请求体。"""

    model: str = Field(min_length=1, max_length=128)
    messages: list[ChatMessage] = Field(default_factory=list)
    stream: bool = False
    response_format: ResponseFormat | None = None
    prompt_ref: PromptRef | None = None
    max_tokens: int | None = Field(default=None, ge=1, le=393_216)
    temperature: float | None = Field(default=None, ge=0, le=2)


class PromptWrite(BaseModel):
    """写入一个提示词版本。"""

    template: str = Field(min_length=1, max_length=100_000)
    description: str = Field(default="", max_length=2_000)
