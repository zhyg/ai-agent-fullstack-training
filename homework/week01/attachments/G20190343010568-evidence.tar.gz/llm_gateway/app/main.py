"""FastAPI 入口。"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from llm_gateway.app.config import Settings, load_settings
from llm_gateway.app.errors import GatewayError
from llm_gateway.app.metrics import MetricsStore
from llm_gateway.app.prompts.store import PromptStore
from llm_gateway.app.ratelimit import SlidingWindowLimiter
from llm_gateway.app.routes.chat import router as chat_router
from llm_gateway.app.routes.meta import router as meta_router
from llm_gateway.app.routes.prompts import router as prompt_router

logger = logging.getLogger("llm_gateway")


def create_app(
    settings: Settings | None = None,
    http_client: httpx.AsyncClient | None = None,
) -> FastAPI:
    """创建应用。测试可以注入 Settings 和 httpx 客户端。"""
    settings = settings or load_settings()
    if not logger.handlers:
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if app.state.http is None:
            timeout = httpx.Timeout(app.state.settings.request_timeout_seconds)
            app.state.http = httpx.AsyncClient(timeout=timeout)
            app.state.owns_http = True
        else:
            app.state.owns_http = False
        try:
            yield
        finally:
            if app.state.owns_http:
                await app.state.http.aclose()

    app = FastAPI(title="LLM Gateway", lifespan=lifespan)
    app.state.settings = settings
    app.state.http = http_client
    app.state.limiter = SlidingWindowLimiter()
    app.state.metrics = MetricsStore(settings.metrics_capacity)
    app.state.prompts = PromptStore(settings.prompts_dir)
    app.include_router(meta_router)
    app.include_router(chat_router)
    app.include_router(prompt_router)
    app.add_exception_handler(GatewayError, _gateway_error)
    app.add_exception_handler(RequestValidationError, _validation_error)
    return app


async def _gateway_error(_request, exc: GatewayError) -> JSONResponse:
    response = JSONResponse(status_code=exc.status_code, content=exc.public())
    if exc.request_id:
        response.headers["X-Request-Id"] = exc.request_id
    return response


async def _validation_error(_request, exc: RequestValidationError) -> JSONResponse:
    errors = exc.errors()
    message = "request body is invalid"
    if errors:
        loc = ".".join(str(part) for part in errors[0].get("loc", []))
        message = f"{loc}: {errors[0].get('msg')}"
    return JSONResponse(
        status_code=400,
        content={"error": {"code": "invalid_request", "message": message, "retryable": False}},
    )


app = create_app()
