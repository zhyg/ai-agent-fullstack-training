"""从 YAML 加载网关配置，密钥只从环境变量读取。"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml

PACKAGE_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class ModelConfig:
    """一个对外模型名对应的上游协议和地址。"""

    name: str
    protocol: str
    upstream_model: str
    base_url: str
    rpm: int


@dataclass(frozen=True)
class Settings:
    """进程内不可变配置。"""

    models: dict[str, ModelConfig]
    prompts_dir: Path
    retry_max_attempts: int = 3
    retry_base_seconds: float = 0.5
    retry_max_seconds: float = 8.0
    request_timeout_seconds: float = 120.0
    metrics_capacity: int = 200
    api_key_env: str = "DEEPSEEK_API_KEY"

    def api_key(self) -> str:
        """当前进程里的上游密钥。空字符串表示尚未配置。"""
        return os.environ.get(self.api_key_env, "").strip()


def load_settings(path: Path | None = None) -> Settings:
    """读取配置文件。相对路径相对包根目录解析。"""
    config_path = path or _default_config_path()
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    models: dict[str, ModelConfig] = {}
    for name, item in (raw.get("models") or {}).items():
        protocol = str(item["protocol"])
        if protocol not in {"responses", "messages"}:
            raise ValueError(f"unsupported protocol for {name}: {protocol}")
        rpm = int(item.get("rpm") or raw.get("default_rpm") or 60)
        if rpm < 1:
            raise ValueError(f"rpm for {name} must be >= 1")
        models[str(name)] = ModelConfig(
            name=str(name),
            protocol=protocol,
            upstream_model=str(item["upstream_model"]),
            base_url=str(item["base_url"]).rstrip("/"),
            rpm=rpm,
        )
    if not models:
        raise ValueError("config must declare at least one model")
    prompts_dir = Path(raw.get("prompts_dir") or "prompts")
    if not prompts_dir.is_absolute():
        prompts_dir = PACKAGE_ROOT / prompts_dir
    base_seconds = float(raw.get("retry_base_seconds", 0.5))
    if override := os.environ.get("LLM_GATEWAY_RETRY_BASE_SECONDS"):
        base_seconds = float(override)
    return Settings(
        models=models,
        prompts_dir=prompts_dir,
        retry_max_attempts=int(raw.get("retry_max_attempts", 3)),
        retry_base_seconds=base_seconds,
        retry_max_seconds=float(raw.get("retry_max_seconds", 8)),
        request_timeout_seconds=float(raw.get("request_timeout_seconds", 120)),
        metrics_capacity=int(raw.get("metrics_capacity", 200)),
        api_key_env=str(raw.get("api_key_env") or "DEEPSEEK_API_KEY"),
    )


def _default_config_path() -> Path:
    env_path = os.environ.get("LLM_GATEWAY_CONFIG")
    if env_path:
        return Path(env_path)
    primary = PACKAGE_ROOT / "config.yaml"
    if primary.exists():
        return primary
    return PACKAGE_ROOT / "config.example.yaml"
