"""指数退避。最多发起 retry_max_attempts 次请求，其中包含第一次。"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

from llm_gateway.app.config import Settings
from llm_gateway.app.errors import GatewayError

T = TypeVar("T")


async def retry_async(operation: Callable[[], Awaitable[T]], settings: Settings) -> tuple[T, int]:
    """执行异步操作。仅对 GatewayError.retryable 为真的失败重试。"""
    attempt = 0
    while True:
        attempt += 1
        try:
            return await operation(), attempt
        except GatewayError as exc:
            if not exc.retryable or attempt >= settings.retry_max_attempts:
                exc.attempts = attempt
                raise
            delay = min(
                settings.retry_base_seconds * (2 ** (attempt - 1)),
                settings.retry_max_seconds,
            )
            if delay > 0:
                await asyncio.sleep(delay)
