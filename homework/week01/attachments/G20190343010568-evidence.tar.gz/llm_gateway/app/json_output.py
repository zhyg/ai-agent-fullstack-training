"""校验模型输出是合法 JSON，并在给出 schema 时检查结构。"""

from __future__ import annotations

import json
from typing import Any

import jsonschema
from jsonschema import Draft202012Validator

from llm_gateway.app.errors import GatewayError
from llm_gateway.app.schemas import ResponseFormat


def assert_schema(fmt: ResponseFormat | None) -> None:
    """在访问上游之前拒绝非法 schema，避免把坏约束重试三遍。"""
    if fmt is None or fmt.type != "json_schema" or fmt.json_schema is None:
        return
    try:
        Draft202012Validator.check_schema(fmt.json_schema.schema_def)
    except jsonschema.SchemaError as exc:
        raise GatewayError("invalid_request", f"json schema is invalid: {exc.message}", 400) from exc


def ensure_json(text: str, fmt: ResponseFormat) -> Any:
    """解析正文。不是合法 JSON 或不匹配 schema 时可以重试。"""
    try:
        value = json.loads(text.strip())
    except json.JSONDecodeError as exc:
        raise GatewayError(
            "invalid_json",
            f"model output is not valid JSON: {exc.msg}",
            502,
            retryable=True,
        ) from exc
    if fmt.type == "json_schema" and fmt.json_schema is not None:
        try:
            jsonschema.validate(value, fmt.json_schema.schema_def)
        except jsonschema.ValidationError as exc:
            raise GatewayError(
                "invalid_json",
                f"JSON does not match schema: {exc.message}",
                502,
                retryable=True,
            ) from exc
    return value
