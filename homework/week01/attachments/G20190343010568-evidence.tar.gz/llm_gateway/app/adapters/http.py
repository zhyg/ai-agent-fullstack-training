"""上游 HTTP 状态到统一错误码的映射。"""

from __future__ import annotations

import json

from llm_gateway.app.errors import GatewayError

_RETRYABLE_STATUS = {429, 500, 502, 503, 504, 529}


def raise_for_upstream(status: int, raw: bytes) -> None:
    """把上游 HTTP 错误转成 GatewayError。可重试的状态不会直接变成调用方的 429。"""
    message = _message(raw)
    if status in _RETRYABLE_STATUS:
        code = "upstream_timeout" if status in {504, 529} else "upstream_error"
        http_status = 504 if code == "upstream_timeout" else 502
        raise GatewayError(
            code,
            message,
            http_status,
            retryable=True,
            upstream_status=status,
        )
    raise GatewayError(
        "upstream_error",
        message,
        502,
        retryable=False,
        upstream_status=status,
    )


def _message(raw: bytes) -> str:
    text = raw.decode("utf-8", errors="replace")[:500]
    try:
        data = json.loads(text) if text else {}
    except json.JSONDecodeError:
        return text or "upstream request failed"
    if isinstance(data, dict):
        error = data.get("error")
        if isinstance(error, dict):
            return str(error.get("message") or error.get("type") or "upstream request failed")[:500]
        if isinstance(error, str):
            return error[:500]
    return text or "upstream request failed"
