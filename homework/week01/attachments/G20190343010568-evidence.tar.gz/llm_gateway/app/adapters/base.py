"""适配器共用的调用上下文和流式事件。"""

from __future__ import annotations

from dataclasses import dataclass

from llm_gateway.app.schemas import ChatMessage, ResponseFormat
from llm_gateway.app.usage import Usage


@dataclass
class CallContext:
    """已经完成路由、模板渲染和鉴权检查的一次调用。"""

    request_id: str
    public_model: str
    protocol: str
    upstream_model: str
    base_url: str
    api_key: str
    messages: list[ChatMessage]
    response_format: ResponseFormat | None
    max_tokens: int | None
    temperature: float | None


@dataclass
class Completion:
    """非流式适配结果。content 是给调用方看的正文。"""

    content: str
    usage: Usage


@dataclass
class TextDelta:
    """增量正文。思维链不会以这个事件出现。"""

    text: str


@dataclass
class StreamDone:
    """流正常结束。content 仅在上游没有增量、只在最终事件给出全文时使用。"""

    usage: Usage
    content: str = ""
