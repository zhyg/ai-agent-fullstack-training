"""OpenAI Responses API 适配器，对应 deepseek-v4-pro。"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from llm_gateway.app.adapters.base import CallContext, Completion, StreamDone, TextDelta
from llm_gateway.app.adapters.http import raise_for_upstream
from llm_gateway.app.errors import GatewayError
from llm_gateway.app.schemas import ResponseFormat
from llm_gateway.app.sse import iter_sse, parse_sse_json
from llm_gateway.app.usage import Usage, usage_from_responses

StreamEvent = TextDelta | StreamDone


def build_responses_payload(ctx: CallContext, *, stream: bool) -> dict[str, Any]:
    """把统一消息翻译成 Responses 的 instructions 和 input。"""
    instructions: list[str] = []
    items: list[dict[str, Any]] = []
    for message in ctx.messages:
        if message.role == "system":
            instructions.append(message.content)
            continue
        items.append({"type": "message", "role": message.role, "content": message.content})
    payload: dict[str, Any] = {
        "model": ctx.upstream_model,
        "stream": stream,
        "reasoning": {"effort": "none"},
    }
    if instructions:
        payload["instructions"] = "\n\n".join(instructions)
    payload["input"] = items or ""
    if ctx.max_tokens is not None:
        payload["max_output_tokens"] = ctx.max_tokens
    if ctx.temperature is not None:
        payload["temperature"] = ctx.temperature
    if ctx.response_format is not None:
        payload["text"] = {"format": responses_format(ctx.response_format)}
    return payload


def responses_format(fmt: ResponseFormat) -> dict[str, Any]:
    """统一 response_format 对应 Responses 的 text.format。"""
    if fmt.type == "json_object":
        return {"type": "json_object"}
    spec = fmt.json_schema
    if spec is None:
        raise GatewayError("invalid_request", "json_schema is required", 400)
    return {"type": "json_schema", "name": spec.name, "schema": spec.schema_def}


def extract_output_text(data: dict[str, Any]) -> str:
    """只拼接最终回答，跳过 reasoning 块。"""
    parts: list[str] = []
    for item in data.get("output") or []:
        if not isinstance(item, dict) or item.get("type") != "message":
            continue
        content = item.get("content")
        if isinstance(content, str):
            parts.append(content)
            continue
        for block in content or []:
            if isinstance(block, dict) and block.get("type") in {"output_text", "text"}:
                parts.append(str(block.get("text") or ""))
    if parts:
        return "".join(parts)
    output_text = data.get("output_text")
    return output_text if isinstance(output_text, str) else ""


def events_from_responses(event_name: str, payload: dict[str, Any]) -> list[StreamEvent]:
    """把一个 Responses SSE 事件收成正文增量或结束事件。"""
    kind = str(payload.get("type") or event_name)
    if kind == "response.output_text.delta":
        text = payload.get("delta")
        if isinstance(text, dict):
            text = text.get("text")
        if isinstance(text, str) and text:
            return [TextDelta(text)]
        return []
    if kind in {"response.completed", "response.incomplete", "response.failed"}:
        response = payload.get("response") if isinstance(payload.get("response"), dict) else {}
        if kind == "response.failed" or response.get("status") == "failed":
            raise GatewayError("upstream_error", _failure_message(response, payload), 502, retryable=False)
        return [StreamDone(usage_from_responses(response.get("usage")), extract_output_text(response))]
    return []


def _failure_message(response: dict[str, Any], payload: dict[str, Any]) -> str:
    error = response.get("error") or payload.get("error")
    if isinstance(error, dict) and error.get("message"):
        return str(error["message"])[:500]
    return "upstream response failed"


class ResponsesAdapter:
    """调用 POST {base_url}/responses。鉴权使用 Bearer。"""

    def __init__(self, client: httpx.AsyncClient) -> None:
        self.client = client

    async def complete(self, ctx: CallContext) -> Completion:
        data = await _post_json(
            self.client,
            f"{ctx.base_url}/responses",
            _headers(ctx.api_key),
            build_responses_payload(ctx, stream=False),
        )
        return Completion(extract_output_text(data), usage_from_responses(data.get("usage")))

    async def stream(self, ctx: CallContext) -> AsyncIterator[StreamEvent]:
        """逐个产出正文增量。最终事件里的 usage 是累计值。"""
        try:
            async with self.client.stream(
                "POST",
                f"{ctx.base_url}/responses",
                headers=_headers(ctx.api_key),
                json=build_responses_payload(ctx, stream=True),
            ) as response:
                if response.status_code >= 400:
                    raise_for_upstream(response.status_code, await response.aread())
                saw_done = False
                async for event_name, data in iter_sse(response.aiter_lines()):
                    payload = _payload(data)
                    if payload is None:
                        continue
                    for event in events_from_responses(event_name, payload):
                        if isinstance(event, StreamDone):
                            saw_done = True
                        yield event
                if not saw_done:
                    raise GatewayError(
                        "upstream_error",
                        "upstream stream ended before response.completed",
                        502,
                        retryable=True,
                    )
        except GatewayError:
            raise
        except httpx.TimeoutException as exc:
            raise GatewayError("upstream_timeout", "upstream timed out", 504, retryable=True) from exc
        except httpx.HTTPError as exc:
            raise GatewayError("upstream_error", "upstream connection failed", 502, retryable=True) from exc


def _headers(api_key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}


def _payload(data: str) -> dict[str, Any] | None:
    try:
        return parse_sse_json(data)
    except json.JSONDecodeError as exc:
        raise GatewayError("upstream_error", "upstream sent an invalid SSE payload", 502, retryable=True) from exc


async def _post_json(
    client: httpx.AsyncClient,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any],
) -> dict[str, Any]:
    try:
        response = await client.post(url, headers=headers, json=body)
    except httpx.TimeoutException as exc:
        raise GatewayError("upstream_timeout", "upstream timed out", 504, retryable=True) from exc
    except httpx.HTTPError as exc:
        raise GatewayError("upstream_error", "upstream connection failed", 502, retryable=True) from exc
    if response.status_code >= 400:
        raise_for_upstream(response.status_code, response.content)
    try:
        data = response.json()
    except json.JSONDecodeError as exc:
        raise GatewayError("upstream_error", "upstream returned non-JSON", 502, retryable=True) from exc
    if not isinstance(data, dict):
        raise GatewayError("upstream_error", "upstream returned an unexpected body", 502, retryable=True)
    return data
