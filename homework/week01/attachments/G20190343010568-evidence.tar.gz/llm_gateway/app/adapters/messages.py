"""Anthropic Messages API 适配器，对应 deepseek-v4-flash。"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from llm_gateway.app.adapters.base import CallContext, Completion, StreamDone, TextDelta
from llm_gateway.app.adapters.http import raise_for_upstream
from llm_gateway.app.errors import GatewayError
from llm_gateway.app.schemas import ResponseFormat
from llm_gateway.app.sse import iter_sse, parse_sse_json
from llm_gateway.app.usage import Usage, usage_from_messages

StreamEvent = TextDelta | StreamDone
_RETRYABLE_EVENT = {"overloaded_error", "api_error", "timeout_error", "rate_limit_error"}


def build_messages_payload(ctx: CallContext, *, stream: bool) -> dict[str, Any]:
    """把统一消息翻译成 Anthropic 的 system 和 messages。

    DeepSeek 会忽略 output_config.format，因此 schema 同时写进 system，由网关再校验。
    """
    system_parts: list[str] = []
    messages: list[dict[str, str]] = []
    for message in ctx.messages:
        if message.role == "system":
            system_parts.append(message.content)
        else:
            messages.append({"role": message.role, "content": message.content})
    output_config: dict[str, Any] = {"effort": "none"}
    if ctx.response_format is not None:
        system_parts.append(json_instruction(ctx.response_format))
        output_config["format"] = {"type": "json_schema", "schema": schema_for(ctx.response_format)}
    payload: dict[str, Any] = {
        "model": ctx.upstream_model,
        "max_tokens": ctx.max_tokens or 1024,
        "messages": messages,
        "stream": stream,
        "thinking": {"type": "disabled"},
        "output_config": output_config,
    }
    if system_parts:
        payload["system"] = "\n\n".join(system_parts)
    if ctx.temperature is not None:
        payload["temperature"] = ctx.temperature
    return payload


def schema_for(fmt: ResponseFormat) -> dict[str, Any]:
    """json_object 用一个开放 object schema 占位，json_schema 用调用方的 schema。"""
    if fmt.type == "json_schema" and fmt.json_schema is not None:
        return fmt.json_schema.schema_def
    return {"type": "object"}


def json_instruction(fmt: ResponseFormat) -> str:
    """写进 system 的 JSON 约束。Messages 上游不保证执行 format 字段。"""
    if fmt.type == "json_object" or fmt.json_schema is None:
        return "只输出一个合法 JSON 值，不要 Markdown，不要额外说明。"
    encoded = json.dumps(fmt.json_schema.schema_def, ensure_ascii=False)
    return f"只输出一个符合下列 JSON Schema 的 JSON 值，不要 Markdown，不要额外说明。\n{encoded}"


def extract_message_text(data: dict[str, Any]) -> str:
    """只拼接 type=text 的内容块。"""
    parts: list[str] = []
    for block in data.get("content") or []:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(str(block.get("text") or ""))
    return "".join(parts)


def events_from_messages(event_name: str, payload: dict[str, Any]) -> list[TextDelta | Usage]:
    """解析一条 Messages SSE。message_stop 由适配器收尾，这里只返回增量和用量。"""
    kind = str(payload.get("type") or event_name)
    if kind == "content_block_delta":
        delta = payload.get("delta") if isinstance(payload.get("delta"), dict) else {}
        text = delta.get("text")
        if delta.get("type") == "text_delta" and isinstance(text, str) and text:
            return [TextDelta(text)]
        return []
    if kind == "message_delta":
        return [usage_from_messages(payload.get("usage") if isinstance(payload.get("usage"), dict) else None)]
    if kind == "error":
        error = payload.get("error") if isinstance(payload.get("error"), dict) else {}
        error_type = str(error.get("type") or "")
        retryable = error_type in _RETRYABLE_EVENT
        code = "upstream_timeout" if retryable else "upstream_error"
        status = 504 if code == "upstream_timeout" else 502
        message = str(error.get("message") or error_type or "upstream stream error")[:500]
        raise GatewayError(code, message, status, retryable=retryable)
    return []


class MessagesAdapter:
    """调用 POST {base_url}/v1/messages。鉴权使用 x-api-key。"""

    def __init__(self, client: httpx.AsyncClient) -> None:
        self.client = client

    async def complete(self, ctx: CallContext) -> Completion:
        data = await _post_json(
            self.client,
            f"{ctx.base_url}/v1/messages",
            _headers(ctx.api_key),
            build_messages_payload(ctx, stream=False),
        )
        return Completion(extract_message_text(data), usage_from_messages(data.get("usage")))

    async def stream(self, ctx: CallContext) -> AsyncIterator[StreamEvent]:
        """忽略 thinking 增量。用量以最后一条 message_delta 为准。"""
        try:
            async with self.client.stream(
                "POST",
                f"{ctx.base_url}/v1/messages",
                headers=_headers(ctx.api_key),
                json=build_messages_payload(ctx, stream=True),
            ) as response:
                if response.status_code >= 400:
                    raise_for_upstream(response.status_code, await response.aread())
                usage = Usage()
                saw_stop = False
                async for event_name, data in iter_sse(response.aiter_lines()):
                    payload = _payload(data)
                    if payload is None:
                        continue
                    kind = str(payload.get("type") or event_name)
                    if kind == "message_stop":
                        saw_stop = True
                        yield StreamDone(usage)
                        continue
                    for event in events_from_messages(event_name, payload):
                        if isinstance(event, Usage):
                            usage = event
                        else:
                            yield event
                if not saw_stop:
                    raise GatewayError(
                        "upstream_error",
                        "upstream stream ended before message_stop",
                        502,
                        retryable=True,
                    )
        except GatewayError:
            raise
        except httpx.TimeoutException as exc:
            raise GatewayError("upstream_timeout", "upstream timed out", 504, retryable=True) from exc
        except httpx.HTTPError as exc:
            raise GatewayError("upstream_error", "upstream connection failed", 502, retryable=True) from exc


def _headers(api_key: str) -> dict[str, str]:
    return {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }


def _payload(data: str) -> dict[str, Any] | None:
    try:
        return parse_sse_json(data)
    except json.JSONDecodeError as exc:
        raise GatewayError("upstream_error", "upstream sent an invalid SSE payload", 502, retryable=True) from exc


async def _post_json(
    client: httpx.AsyncClient,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any],
) -> dict[str, Any]:
    try:
        response = await client.post(url, headers=headers, json=body)
    except httpx.TimeoutException as exc:
        raise GatewayError("upstream_timeout", "upstream timed out", 504, retryable=True) from exc
    except httpx.HTTPError as exc:
        raise GatewayError("upstream_error", "upstream connection failed", 502, retryable=True) from exc
    if response.status_code >= 400:
        raise_for_upstream(response.status_code, response.content)
    try:
        data = response.json()
    except json.JSONDecodeError as exc:
        raise GatewayError("upstream_error", "upstream returned non-JSON", 502, retryable=True) from exc
    if not isinstance(data, dict):
        raise GatewayError("upstream_error", "upstream returned an unexpected body", 502, retryable=True)
    return data
