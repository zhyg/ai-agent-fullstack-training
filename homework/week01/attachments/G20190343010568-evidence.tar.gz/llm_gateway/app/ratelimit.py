"""每个模型一个滑动窗口，超限直接拒绝，不访问上游。"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict, deque
from collections.abc import Callable

from llm_gateway.app.errors import GatewayError


class SlidingWindowLimiter:
    """按模型名计数的进程内限流器。"""

    def __init__(
        self,
        *,
        clock: Callable[[], float] = time.monotonic,
        window_seconds: float = 60.0,
    ) -> None:
        self._clock = clock
        self._window = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = asyncio.Lock()

    async def consume(self, model: str, rpm: int) -> None:
        """占用一次配额。窗口内已达 rpm 时抛出 rate_limited。"""
        now = self._clock()
        async with self._lock:
            hits = self._hits[model]
            while hits and now - hits[0] >= self._window:
                hits.popleft()
            if len(hits) >= rpm:
                raise GatewayError(
                    "rate_limited",
                    f"model {model} exceeded {rpm} requests per {self._window:g} seconds",
                    429,
                    retryable=False,
                )
            hits.append(now)
