"""把 {{var}} 替换成调用方传入的变量。不使用 str.format，避免模板里的花括号被执行。"""

from __future__ import annotations

import json
import re
from typing import Any

from llm_gateway.app.errors import GatewayError

_VAR = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")


def render_template(template: str, variables: dict[str, Any]) -> str:
    """替换模板变量。缺少任一变量时返回 400，不把半成品提示词发给上游。"""
    missing: list[str] = []

    def replace(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in variables:
            missing.append(key)
            return match.group(0)
        value = variables[key]
        if isinstance(value, str):
            return value
        return json.dumps(value, ensure_ascii=False)

    rendered = _VAR.sub(replace, template)
    if missing:
        names = ", ".join(sorted(set(missing)))
        raise GatewayError("invalid_request", f"missing template variables: {names}", 400)
    return rendered
