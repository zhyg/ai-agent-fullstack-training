"""提示词版本存在本地 JSON 文件里，路径只允许安全的 id 和版本号。"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from llm_gateway.app.errors import GatewayError

_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class PromptStore:
    """一个 id 一个目录，一个版本一个文件。"""

    def __init__(self, root: Path) -> None:
        self.root = root

    def get(self, prompt_id: str, version: str) -> dict[str, Any]:
        path = self._path(prompt_id, version)
        if not path.is_file():
            raise GatewayError(
                "template_not_found",
                f"prompt {prompt_id}@{version} was not found",
                404,
            )
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise GatewayError("invalid_request", f"prompt file is corrupt: {exc}", 400) from exc
        if not isinstance(data, dict) or not isinstance(data.get("template"), str):
            raise GatewayError("invalid_request", "prompt file is missing template", 400)
        return data

    def put(self, prompt_id: str, version: str, template: str, description: str) -> dict[str, Any]:
        path = self._path(prompt_id, version)
        path.parent.mkdir(parents=True, exist_ok=True)
        document = {
            "id": prompt_id,
            "version": version,
            "description": description,
            "template": template,
        }
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(document, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)
        return document

    def versions(self, prompt_id: str) -> list[str]:
        self._check(prompt_id)
        directory = (self.root / prompt_id).resolve()
        if not directory.is_dir() or not directory.is_relative_to(self.root.resolve()):
            raise GatewayError("template_not_found", f"prompt {prompt_id} was not found", 404)
        return sorted(path.stem for path in directory.glob("*.json"))

    def _path(self, prompt_id: str, version: str) -> Path:
        self._check(prompt_id)
        self._check(version)
        path = (self.root / prompt_id / f"{version}.json").resolve()
        if not path.is_relative_to(self.root.resolve()):
            raise GatewayError("invalid_request", "prompt path is not allowed", 400)
        return path

    @staticmethod
    def _check(value: str) -> None:
        if _SAFE.fullmatch(value) is None:
            raise GatewayError("invalid_request", f"illegal prompt id or version: {value!r}", 400)
