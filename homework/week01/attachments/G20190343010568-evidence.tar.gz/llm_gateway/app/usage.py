"""把两套协议的用量字段收成同一种统计。"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class Usage:
    """一次调用的 token 分类统计。

    cached_tokens 是 input_tokens 的子集，reasoning_tokens 是 output_tokens 的子集。
    """

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0
    reasoning_tokens: int = 0

    def as_dict(self) -> dict[str, int]:
        return asdict(self)


def _int(value: Any) -> int:
    if value is None:
        return 0
    return int(value)


def usage_from_responses(raw: dict[str, Any] | None) -> Usage:
    """OpenAI Responses 的 usage。input_tokens 已包含 cached。"""
    raw = raw or {}
    input_tokens = _int(raw.get("input_tokens"))
    output_tokens = _int(raw.get("output_tokens"))
    cached = _int((raw.get("input_tokens_details") or {}).get("cached_tokens"))
    reasoning = _int((raw.get("output_tokens_details") or {}).get("reasoning_tokens"))
    total = _int(raw.get("total_tokens")) or input_tokens + output_tokens
    return Usage(input_tokens, output_tokens, total, cached, reasoning)


def usage_from_messages(raw: dict[str, Any] | None) -> Usage:
    """Anthropic Messages 的 usage。

    该协议的 input_tokens 不含缓存读，这里把 cache_read 和 cache_creation 加回去。
    """
    raw = raw or {}
    uncached = _int(raw.get("input_tokens"))
    cache_read = _int(raw.get("cache_read_input_tokens"))
    cache_create = _int(raw.get("cache_creation_input_tokens"))
    output_tokens = _int(raw.get("output_tokens"))
    reasoning = _int((raw.get("output_tokens_details") or {}).get("thinking_tokens"))
    input_tokens = uncached + cache_read + cache_create
    return Usage(
        input_tokens,
        output_tokens,
        input_tokens + output_tokens,
        cache_read,
        reasoning,
    )
