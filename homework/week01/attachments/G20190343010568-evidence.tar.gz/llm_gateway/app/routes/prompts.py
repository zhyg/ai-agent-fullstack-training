"""提示词的保存、读取和版本列表。"""

from __future__ import annotations

from fastapi import APIRouter, Request

from llm_gateway.app.schemas import PromptWrite

router = APIRouter()


@router.put("/v1/prompts/{prompt_id}/versions/{version}")
def put_prompt(prompt_id: str, version: str, payload: PromptWrite, request: Request) -> dict:
    """创建或覆盖一个提示词版本。"""
    return request.app.state.prompts.put(prompt_id, version, payload.template, payload.description)


@router.get("/v1/prompts/{prompt_id}/versions/{version}")
def get_prompt(prompt_id: str, version: str, request: Request) -> dict:
    """读取一个提示词版本。"""
    return request.app.state.prompts.get(prompt_id, version)


@router.get("/v1/prompts/{prompt_id}")
def list_versions(prompt_id: str, request: Request) -> dict:
    """列出某个提示词已有的版本。"""
    return {"id": prompt_id, "versions": request.app.state.prompts.versions(prompt_id)}
