"""健康检查、模型列表和调用观测。"""

from __future__ import annotations

from fastapi import APIRouter, Query, Request

router = APIRouter()


@router.get("/health")
def health() -> dict:
    """进程存活检查。不访问上游。"""
    return {"status": "ok"}


@router.get("/v1/models")
def models(request: Request) -> dict:
    """返回已配置的对外模型及其协议。"""
    data = [
        {
            "id": model.name,
            "protocol": model.protocol,
            "upstream_model": model.upstream_model,
        }
        for model in request.app.state.settings.models.values()
    ]
    return {"data": data}


@router.get("/v1/metrics/calls")
def calls(request: Request, limit: int = Query(default=50, ge=1, le=200)) -> dict:
    """返回最近的调用记录，新的在前。"""
    return {"data": request.app.state.metrics.latest(limit)}
