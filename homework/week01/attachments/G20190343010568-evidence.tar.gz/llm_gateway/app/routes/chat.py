"""聊天补全。流式在第一帧之前的失败仍返回 JSON，而不是空的 SSE。"""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from llm_gateway.app.errors import GatewayError
from llm_gateway.app.schemas import ChatRequest
from llm_gateway.app.service import ChatService

router = APIRouter()


def get_service(request: Request) -> ChatService:
    """用应用状态组装一次请求所需的依赖。"""
    return ChatService(
        settings=request.app.state.settings,
        http=request.app.state.http,
        limiter=request.app.state.limiter,
        metrics=request.app.state.metrics,
        prompts=request.app.state.prompts,
    )


@router.post("/v1/chat/completions", response_model=None)
async def chat_completions(payload: ChatRequest, request: Request) -> JSONResponse | StreamingResponse:
    """按 model 路由到对应协议适配器。"""
    service = get_service(request)
    if payload.stream:
        try:
            frames = await service.open_stream(payload)
        except GatewayError as exc:
            response = JSONResponse(status_code=exc.status_code, content=exc.public())
            if exc.request_id:
                response.headers["X-Request-Id"] = exc.request_id
            return response
        return StreamingResponse(
            frames,
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    body = await service.complete(payload)
    response = JSONResponse(content=body)
    response.headers["X-Request-Id"] = body["id"]
    return response
