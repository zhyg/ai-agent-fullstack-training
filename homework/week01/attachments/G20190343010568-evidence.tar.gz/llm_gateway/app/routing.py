"""按请求里的 model 选择适配器，不接受调用方指定上游地址。"""

from __future__ import annotations

from llm_gateway.app.config import ModelConfig, Settings
from llm_gateway.app.errors import GatewayError


def resolve_model(settings: Settings, name: str) -> ModelConfig:
    """返回已配置的模型。未知名称是 404，而不是打到任意 URL。"""
    model = settings.models.get(name)
    if model is None:
        known = ", ".join(sorted(settings.models))
        raise GatewayError(
            "model_not_found",
            f"unknown model {name!r}. configured models: {known}",
            404,
        )
    return model
