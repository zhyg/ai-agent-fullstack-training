"""解析和编码 Server-Sent Events。"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any


def encode_sse(event: str, payload: dict[str, Any]) -> str:
    """编码成一条 SSE 帧。payload 不转义非 ASCII 字符。"""
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    return f"event: {event}\ndata: {data}\n\n"


async def iter_sse(lines: AsyncIterator[str]) -> AsyncIterator[tuple[str, str]]:
    """把文本行还原成 (event, data)。忽略注释行，并刷新末尾没有空行的事件。"""
    event = "message"
    data: list[str] = []
    async for raw in lines:
        line = raw[:-1] if raw.endswith("\r") else raw
        if line == "":
            if data:
                yield event, "\n".join(data)
            event = "message"
            data = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip(" "))
    if data:
        yield event, "\n".join(data)


def parse_sse_json(data: str) -> dict[str, Any] | None:
    """解析事件 data。空串和 [DONE] 返回 None。"""
    if not data or data == "[DONE]":
        return None
    value = json.loads(data)
    if isinstance(value, dict):
        return value
    return {"value": value}
