"""起一个双协议 mock 和网关，打印六项功能的证据。

有 DEEPSEEK_API_KEY 时，再各打一次真实的 deepseek-v4-pro 和 deepseek-v4-flash。
"""

from __future__ import annotations

import asyncio
import json
import os
import socket
import sys
import threading
import time
from pathlib import Path
from typing import Any

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from llm_gateway.app.config import PACKAGE_ROOT, ModelConfig, Settings  # noqa: E402
from llm_gateway.app.main import create_app  # noqa: E402

SCHEMA = {
    "type": "object",
    "properties": {"question": {"type": "string"}, "answer": {"type": "string"}},
    "required": ["question", "answer"],
    "additionalProperties": False,
}
JSON_TEXT = '{"question":"q","answer":"a"}'


class QuietServer(uvicorn.Server):
    """后台线程里启动时不注册信号处理器。"""

    def install_signal_handlers(self) -> None:
        return


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def start_server(app: FastAPI, port: int) -> tuple[QuietServer, threading.Thread]:
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", access_log=False)
    server = QuietServer(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    return server, thread


def wait_until_ready(port: int) -> None:
    deadline = time.time() + 10
    last_error = "not started"
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return
        except OSError as exc:
            last_error = str(exc)
            time.sleep(0.05)
    raise RuntimeError(f"server on {port} did not start: {last_error}")


def build_mock() -> FastAPI:
    """同时实现 Responses 和 Messages 的最小上游。"""
    app = FastAPI()
    app.state.calls = []
    app.state.fail = {"responses": 0, "messages": 0}
    lock = threading.Lock()

    def record(path: str, request: Request, body: dict[str, Any]) -> None:
        with lock:
            app.state.calls.append(
                {
                    "path": path,
                    "bearer": request.headers.get("authorization", "").lower().startswith("bearer "),
                    "x_api_key": bool(request.headers.get("x-api-key")),
                    "body": body,
                }
            )

    def take_failure(slot: str) -> bool:
        with lock:
            if app.state.fail[slot] > 0:
                app.state.fail[slot] -= 1
                return True
        return False

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/_admin/fail")
    async def arm_failure(request: Request) -> dict[str, bool]:
        payload = await request.json()
        with lock:
            app.state.fail[str(payload["slot"])] = int(payload["times"])
        return {"ok": True}

    @app.get("/_admin/calls")
    def calls() -> dict[str, list]:
        with lock:
            return {"data": list(app.state.calls)}

    @app.post("/responses", response_model=None)
    async def responses(request: Request) -> JSONResponse | StreamingResponse:
        body = await request.json()
        record("/responses", request, body)
        if take_failure("responses"):
            return JSONResponse({"error": {"message": "injected"}}, status_code=503)
        wants_json = (body.get("text") or {}).get("format", {}).get("type") in {"json_object", "json_schema"}
        text = JSON_TEXT if wants_json else "pro-ok"
        if body.get("stream"):
            return StreamingResponse(_responses_sse(), media_type="text/event-stream")
        return JSONResponse(_response_json(text))

    @app.post("/anthropic/v1/messages", response_model=None)
    async def messages(request: Request) -> JSONResponse | StreamingResponse:
        body = await request.json()
        record("/anthropic/v1/messages", request, body)
        if take_failure("messages"):
            return JSONResponse({"error": {"message": "injected"}}, status_code=503)
        wants_json = "format" in (body.get("output_config") or {})
        text = JSON_TEXT if wants_json else "flash-ok"
        if body.get("stream"):
            return StreamingResponse(_messages_sse(), media_type="text/event-stream")
        return JSONResponse(_message_json(text))

    return app


def _response_json(text: str) -> dict[str, Any]:
    return {
        "status": "completed",
        "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}],
        "usage": {
            "input_tokens": 11,
            "output_tokens": 7,
            "total_tokens": 18,
            "input_tokens_details": {"cached_tokens": 4},
            "output_tokens_details": {"reasoning_tokens": 2},
        },
    }


def _message_json(text: str) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": text}],
        "usage": {
            "input_tokens": 5,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 3,
            "output_tokens": 9,
            "output_tokens_details": {"thinking_tokens": 6},
        },
    }


async def _responses_sse():
    yield (
        "event: response.output_text.delta\n"
        'data: {"type":"response.output_text.delta","delta":"Hi"}\n\n'
    )
    await asyncio.sleep(0.2)
    payload = {"type": "response.completed", "response": {**_response_json(""), "output": []}}
    yield f"event: response.completed\ndata: {json.dumps(payload)}\n\n"


async def _messages_sse():
    delta = {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "Yo"}}
    yield f"event: content_block_delta\ndata: {json.dumps(delta)}\n\n"
    await asyncio.sleep(0.2)
    usage = {"type": "message_delta", "usage": _message_json("")["usage"]}
    yield f"event: message_delta\ndata: {json.dumps(usage)}\n\n"
    yield 'event: message_stop\ndata: {"type":"message_stop"}\n\n'


def gateway_settings(mock_port: int, rpm: int) -> Settings:
    base = f"http://127.0.0.1:{mock_port}"
    return Settings(
        models={
            "deepseek-v4-pro": ModelConfig(
                "deepseek-v4-pro", "responses", "deepseek-v4-pro", base, rpm
            ),
            "deepseek-v4-flash": ModelConfig(
                "deepseek-v4-flash", "messages", "deepseek-flash", base + "/anthropic", rpm
            ),
        },
        prompts_dir=PACKAGE_ROOT / "prompts",
        retry_base_seconds=0.01,
        retry_max_seconds=0.05,
        request_timeout_seconds=10,
    )


def live_settings() -> Settings:
    return Settings(
        models={
            "deepseek-v4-pro": ModelConfig(
                "deepseek-v4-pro",
                "responses",
                "deepseek-v4-pro",
                "https://api.deepseek.com",
                60,
            ),
            "deepseek-v4-flash": ModelConfig(
                "deepseek-v4-flash",
                "messages",
                "deepseek-flash",
                "https://api.deepseek.com/anthropic",
                60,
            ),
        },
        prompts_dir=PACKAGE_ROOT / "prompts",
        retry_base_seconds=0.5,
        request_timeout_seconds=90,
    )


def parse_sse(text: str) -> list[tuple[str, dict]]:
    events: list[tuple[str, dict]] = []
    event = "message"
    data: list[str] = []
    for line in text.splitlines():
        if line == "":
            if data:
                events.append((event, json.loads("\n".join(data))))
            event = "message"
            data = []
            continue
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
    if data:
        events.append((event, json.loads("\n".join(data))))
    return events


def check(name: str, ok: bool, evidence: Any, checks: list[dict[str, Any]]) -> None:
    checks.append({"name": name, "ok": bool(ok), "evidence": evidence})


def main() -> int:
    original_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not original_key:
        os.environ["DEEPSEEK_API_KEY"] = "test-key"
    checks: list[dict[str, Any]] = []
    servers: list[tuple[QuietServer, threading.Thread]] = []
    try:
        mock_port = free_port()
        gateway_port = free_port()
        limit_port = free_port()
        mock = build_mock()
        gateway = create_app(gateway_settings(mock_port, rpm=60))
        limiter = create_app(gateway_settings(mock_port, rpm=2))
        servers = [
            start_server(mock, mock_port),
            start_server(gateway, gateway_port),
            start_server(limiter, limit_port),
        ]
        for port in (mock_port, gateway_port, limit_port):
            wait_until_ready(port)
        with httpx.Client(timeout=20) as client:
            _run_mock_checks(client, mock_port, gateway_port, limit_port, checks)
        if original_key:
            _run_live_checks(checks)
        else:
            check("live_deepseek", True, {"skipped": True, "reason": "DEEPSEEK_API_KEY is not set"}, checks)
    except Exception as exc:  # noqa: BLE001 - 验证脚本要把异常写进报告
        check("harness", False, {"error": str(exc)}, checks)
    finally:
        for server, thread in servers:
            server.should_exit = True
            thread.join(timeout=3)
    passed = all(item["ok"] for item in checks)
    print(json.dumps({"passed": passed, "checks": checks}, ensure_ascii=False, indent=2))
    return 0 if passed else 1


def _run_mock_checks(
    client: httpx.Client,
    mock_port: int,
    gateway_port: int,
    limit_port: int,
    checks: list[dict[str, Any]],
) -> None:
    gateway = f"http://127.0.0.1:{gateway_port}"
    templated = client.post(
        f"{gateway}/v1/chat/completions",
        json={
            "model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "抽取"}],
            "prompt_ref": {"id": "extract", "version": "1.0.0", "variables": {"text": "TOKEN-ADA-42"}},
            "response_format": {
                "type": "json_schema",
                "json_schema": {"name": "Extract", "schema": SCHEMA},
            },
        },
    )
    body = templated.json()
    captured = client.get(f"http://127.0.0.1:{mock_port}/_admin/calls").json()["data"]
    flash_call = next(item for item in captured if item["path"] == "/anthropic/v1/messages")
    check(
        "template_and_messages_protocol",
        templated.status_code == 200
        and body["parsed"] == {"question": "q", "answer": "a"}
        and "TOKEN-ADA-42" in flash_call["body"]["system"]
        and "{{text}}" not in flash_call["body"]["system"]
        and flash_call["x_api_key"]
        and flash_call["body"]["thinking"] == {"type": "disabled"}
        and flash_call["body"]["model"] == "deepseek-flash",
        {
            "status": templated.status_code,
            "protocol": body.get("protocol"),
            "parsed": body.get("parsed"),
            "upstream_model": flash_call["body"].get("model"),
            "has_x_api_key": flash_call["x_api_key"],
            "system_has_token": "TOKEN-ADA-42" in flash_call["body"].get("system", ""),
        },
        checks,
    )
    check(
        "messages_usage",
        body.get("usage") == {
            "input_tokens": 8,
            "output_tokens": 9,
            "total_tokens": 17,
            "cached_tokens": 3,
            "reasoning_tokens": 6,
        },
        body.get("usage"),
        checks,
    )

    structured = client.post(
        f"{gateway}/v1/chat/completions",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "返回 JSON"}],
            "response_format": {"type": "json_schema", "json_schema": {"name": "Extract", "schema": SCHEMA}},
        },
    )
    structured_body = structured.json()
    captured = client.get(f"http://127.0.0.1:{mock_port}/_admin/calls").json()["data"]
    pro_call = next(item for item in reversed(captured) if item["path"] == "/responses")
    check(
        "structured_output_responses",
        structured.status_code == 200
        and structured_body["parsed"] == {"question": "q", "answer": "a"}
        and pro_call["bearer"]
        and pro_call["body"]["text"]["format"]["type"] == "json_schema"
        and pro_call["body"]["reasoning"] == {"effort": "none"}
        and "messages" not in pro_call["body"],
        {
            "status": structured.status_code,
            "protocol": structured_body.get("protocol"),
            "parsed": structured_body.get("parsed"),
            "format": pro_call["body"].get("text", {}).get("format", {}).get("type"),
            "bearer": pro_call["bearer"],
        },
        checks,
    )

    for model, protocol, delta in (
        ("deepseek-v4-pro", "responses", "Hi"),
        ("deepseek-v4-flash", "messages", "Yo"),
    ):
        response = client.post(
            f"{gateway}/v1/chat/completions",
            json={"model": model, "messages": [{"role": "user", "content": "hi"}], "stream": True},
        )
        frames = parse_sse(response.text)
        done = frames[-1][1] if frames else {}
        check(
            f"stream_{protocol}",
            response.status_code == 200
            and [name for name, _ in frames[:3]] == ["meta", "delta", "done"]
            and frames[1][1].get("text") == delta
            and frames[0][1].get("protocol") == protocol
            and done.get("latency_ms", 0) > done.get("ttft_ms", 0)
            and "usage" in done,
            {
                "events": [name for name, _ in frames],
                "delta": frames[1][1].get("text") if len(frames) > 1 else None,
                "ttft_ms": done.get("ttft_ms"),
                "latency_ms": done.get("latency_ms"),
                "usage": done.get("usage"),
            },
            checks,
        )

    metrics = client.get(f"{gateway}/v1/metrics/calls").json()["data"]
    check(
        "metrics",
        any(item["protocol"] == "responses" and item["usage"]["cached_tokens"] == 4 for item in metrics)
        and any(item["protocol"] == "messages" and item["usage"]["reasoning_tokens"] == 6 for item in metrics)
        and any(item["ttft_ms"] is not None and item["latency_ms"] >= item["ttft_ms"] for item in metrics),
        {"sample": metrics[0] if metrics else None, "count": len(metrics)},
        checks,
    )

    before = len(client.get(f"http://127.0.0.1:{mock_port}/_admin/calls").json()["data"])
    client.post(f"http://127.0.0.1:{mock_port}/_admin/fail", json={"slot": "responses", "times": 2})
    retried = client.post(
        f"{gateway}/v1/chat/completions",
        json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "retry"}]},
    )
    after = len(client.get(f"http://127.0.0.1:{mock_port}/_admin/calls").json()["data"])
    retried_body = retried.json()
    check(
        "retry",
        retried.status_code == 200 and retried_body.get("attempts") == 3 and after - before == 3,
        {"status": retried.status_code, "attempts": retried_body.get("attempts"), "upstream_calls": after - before},
        checks,
    )

    payload = {"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "limit"}]}
    limit = f"http://127.0.0.1:{limit_port}"
    first = client.post(f"{limit}/v1/chat/completions", json=payload)
    second = client.post(f"{limit}/v1/chat/completions", json=payload)
    third = client.post(f"{limit}/v1/chat/completions", json=payload)
    check(
        "rate_limit",
        first.status_code == 200
        and second.status_code == 200
        and third.status_code == 429
        and third.json()["error"]["code"] == "rate_limited",
        {"statuses": [first.status_code, second.status_code, third.status_code], "error": third.json().get("error")},
        checks,
    )


def _run_live_checks(checks: list[dict[str, Any]]) -> None:
    port = free_port()
    server, thread = start_server(create_app(live_settings()), port)
    try:
        wait_until_ready(port)
        with httpx.Client(timeout=90) as client:
            for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
                response = client.post(
                    f"http://127.0.0.1:{port}/v1/chat/completions",
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": "Reply with the single word pong."}],
                        "max_tokens": 64,
                    },
                )
                body = response.json()
                check(
                    f"live_{model}",
                    response.status_code == 200 and bool(body.get("content")) and body.get("usage", {}).get("total_tokens", 0) > 0,
                    {
                        "status": response.status_code,
                        "protocol": body.get("protocol"),
                        "content": body.get("content", body.get("error")),
                        "usage": body.get("usage"),
                        "latency_ms": body.get("latency_ms"),
                    },
                    checks,
                )
    finally:
        server.should_exit = True
        thread.join(timeout=3)


if __name__ == "__main__":
    raise SystemExit(main())
