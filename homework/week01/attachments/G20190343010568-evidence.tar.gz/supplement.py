import asyncio
import json
import os
import sys
import time
from dataclasses import replace
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent))
from llm_gateway.app.config import ModelConfig, Settings
from llm_gateway.app.main import create_app
from llm_gateway.app.ratelimit import SlidingWindowLimiter
from llm_gateway.scripts.verify import _response_json, _message_json, live_settings, parse_sse

ROOT = Path(__file__).resolve().parent
URL = '/v1/chat/completions'
MODELS = ['deepseek-v4-pro', 'deepseek-v4-flash']
def emit(name, **data):
    print(json.dumps({'case': name, **data}, ensure_ascii=False), flush=True)

def payload(model=MODELS[0], **extra):
    return {'model': model, 'messages': [{'role':'user','content':'Return JSON: {"a":7}'}], **extra}

def settings():
    return Settings(models={
        MODELS[0]: ModelConfig(MODELS[0], 'responses', MODELS[0], 'http://controlled', 100),
        MODELS[1]: ModelConfig(MODELS[1], 'messages', 'deepseek-flash', 'http://controlled/anthropic', 100),
    }, prompts_dir=ROOT/'test-prompts', retry_base_seconds=.01, retry_max_seconds=.1)

async def ordinary():
    os.environ['DEEPSEEK_API_KEY'] = 'controlled-dummy-key'
    state = {'text':'{"a":7}', 'status':200, 'count':0, 'times':[]}
    captured = []
    def handler(req):
        state['count'] += 1
        state['times'].append(time.perf_counter())
        captured.append({'path':req.url.path,'body':json.loads(req.content)})
        if state['status'] != 200:
            return httpx.Response(state['status'], json={'error':{'message':'controlled rejection'}})
        make = _response_json if req.url.path == '/responses' else _message_json
        return httpx.Response(200, json=make(state['text']))
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as upstream:
        app = create_app(settings(), upstream)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app, raise_app_exceptions=False), base_url='http://gateway') as c:
            for model in MODELS:
                for text in ['{"a":7}', 'not-json', '', '{"a":']:
                    state.update(text=text, count=0)
                    r=await c.post(URL, json=payload(model,response_format={'type':'json_object'}))
                    emit('json-validation',model=model,text=text,status=r.status_code,body=r.json(),upstream_calls=state['count'])
            state.update(text='{"a":7}',status=400,count=0)
            r=await c.post(URL,json=payload())
            emit('upstream-400',status=r.status_code,body=r.json(),upstream_calls=state['count'])
            state.update(status=503,count=0,times=[])
            r=await c.post(URL,json=payload())
            emit('persistent-503',status=r.status_code,body=r.json(),upstream_calls=state['count'],intervals=[b-a for a,b in zip(state['times'],state['times'][1:])])
            state.update(status=200,count=0)
            schema={'type':'json_schema','json_schema':{'schema':{'$ref':'#/$defs/missing'}}}
            r=await c.post(URL,json=payload(response_format=schema))
            emit('unresolved-schema-ref',status=r.status_code,body=r.text,upstream_calls=state['count'])
            schema={'type':'json_schema','json_schema':{'schema':{'$ref':'#/$defs/good','$defs':{'good':{'type':'object','required':['a'],'properties':{'a':{'type':'integer'}}}}}}}
            r=await c.post(URL,json=payload(response_format=schema))
            emit('resolved-schema-ref-control',status=r.status_code,body=r.json())
            before=len(app.state.metrics.latest(200))
            r=await c.post(URL,json=payload('does-not-exist'))
            after=len(app.state.metrics.latest(200))
            emit('prepare-failure-metrics',status=r.status_code,body=r.json(),records_before=before,records_after=after)
            for v in ['v1','v2']:
                await c.put('/v1/prompts/probe/versions/'+v,json={'template':v+' {{name}}'})
            for v in ['v1','v2','missing']:
                r=await c.post(URL,json=payload(prompt_ref={'id':'probe','version':v,'variables':{'name':'ASYMMETRIC'}}))
                emit('template-version',version=v,status=r.status_code,request=captured[-1])
            now=[0.]
            app.state.limiter=SlidingWindowLimiter(clock=lambda:now[0],window_seconds=60)
            app.state.settings=replace(settings(),models={k:replace(v,rpm=1) for k,v in settings().models.items()})
            statuses=[]
            for model in [MODELS[0],MODELS[0],MODELS[1]]:
                statuses.append((await c.post(URL,json=payload(model))).status_code)
            now[0]=60
            statuses.append((await c.post(URL,json=payload())).status_code)
            emit('independent-limit-recovery',statuses=statuses)
            emit('metrics-sample',records=app.state.metrics.latest(200))
            emit('protocol-request-capture',requests=captured[:4]+[x for x in captured if x['path'].endswith('/messages')][:2])

async def streams():
    # Exercise actual ASGI send, not buffered ASGITransport. Upstream cannot finish
    # until the gateway has sent a downstream delta: this proves incrementality.
    for model in MODELS:
        for eof in [False,True]:
            released=asyncio.Event()
            seen=[]
            class Wire(httpx.AsyncByteStream):
                async def __aiter__(self):
                    if model==MODELS[0]:
                        yield b'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"FIRST"}\n\n'
                        await asyncio.wait_for(released.wait(),3)
                        if not eof:
                            yield b'event: response.completed\ndata: {"type":"response.completed","response":{"usage":{"input_tokens":13,"output_tokens":5,"total_tokens":18},"output":[]}}\n\n'
                    else:
                        yield b'event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":13,"cache_read_input_tokens":3,"output_tokens":0}}}\n\n'
                        yield b'event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"type":"text_delta","text":"FIRST"}}\n\n'
                        await asyncio.wait_for(released.wait(),3)
                        if not eof:
                            yield b'event: message_delta\ndata: {"type":"message_delta","usage":{"output_tokens":5}}\n\nevent: message_stop\ndata: {"type":"message_stop"}\n\n'
            def handler(req):
                seen.append({'path':req.url.path,'body':json.loads(req.content)})
                return httpx.Response(200,stream=Wire())
            async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as up:
                app=create_app(settings(),up)
                frames=[]
                async def send(message):
                    if message['type']=='http.response.body':
                        text=message.get('body',b'').decode()
                        frames.append(text)
                        if 'event: delta' in text:
                            released.set()
                sent=False
                async def receive():
                    nonlocal sent
                    if not sent:
                        sent=True
                        return {'type':'http.request','body':json.dumps(payload(model,stream=True)).encode(),'more_body':False}
                    await asyncio.Event().wait()
                await asyncio.wait_for(app({'type':'http','asgi':{'version':'3.0','spec_version':'2.4'},'http_version':'1.1','method':'POST','scheme':'http','path':URL,'raw_path':URL.encode(),'query_string':b'','headers':[(b'content-type',b'application/json')],'server':('gateway',80),'client':('caller',1)},receive,send),5)
                emit('gated-stream',model=model,eof=eof,downstream_delta_released_terminal=released.is_set(),requests=seen,frames=parse_sse(''.join(frames)),metrics=app.state.metrics.latest(1))

async def usage_retry():
    n=[0]
    def handler(req):
        n[0]+=1
        return httpx.Response(200,json=_response_json('invalid' if n[0]<3 else '{"a":7}'))
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as up:
        app=create_app(settings(),up)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://gateway') as c:
            r=await c.post(URL,json=payload(response_format={'type':'json_object'}))
            emit('known-usage-retries',response=r.json(),actual_known_total_tokens=54,records=app.state.metrics.latest(1))

async def live():
    if not os.getenv('DEEPSEEK_API_KEY'):
        emit('live-unverified',reason='missing personal credential')
        return
    capture=[]
    async def request_hook(req):
        capture.append({'method':req.method,'url':str(req.url),'body':json.loads(req.content)})
    async with httpx.AsyncClient(timeout=90,event_hooks={'request':[request_hook]}) as up:
        app=create_app(live_settings(),up)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://gateway') as c:
            for model in MODELS:
                for stream in [False,True]:
                    r=await c.post(URL,json=payload(model,stream=stream,max_tokens=128,**({} if stream else {'response_format':{'type':'json_object'}})))
                    emit('official-live',model=model,stream=stream,status=r.status_code,request=capture[-1],body=parse_sse(r.text) if stream and r.status_code==200 else r.json(),records=app.state.metrics.latest(1))

async def main():
    if '--live' in sys.argv:
        await live()
    else:
        await ordinary()
        await streams()
        await usage_retry()

asyncio.run(main())
