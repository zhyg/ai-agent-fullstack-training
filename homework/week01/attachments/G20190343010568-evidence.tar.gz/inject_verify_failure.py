"""Perturb only the upstream fixture; keep all original verification assertions."""
import os
from llm_gateway.scripts import verify

os.environ.pop('DEEPSEEK_API_KEY', None)
original = verify._response_json
def changed(text):
    result = original(text)
    result['usage']['input_tokens_details']['cached_tokens'] = 999
    return result
verify._response_json = changed
raise SystemExit(verify.main())
