"""Bounded real calls. Only the official DeepSeek host is in live.yaml."""
import asyncio
import json
import time
from pathlib import Path
import httpx

ROOT = Path(__file__).parent

async def main():
    records = []
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8918', timeout=125) as c:
        for model in ['ds-flash-responses', 'ds-pro-chat']:
            for mode in ['ordinary', 'json', 'stream']:
                body = {'model': model, 'input': 'Reply with just the JSON object {"ok":true}. No explanation.', 'max_output_tokens': 512, 'reasoning': {'effort': 'low'}}
                if mode == 'json':
                    body['response_format'] = {'type': 'json_object'}
                if mode == 'stream':
                    body['stream'] = True
                started = time.monotonic()
                try:
                    async with c.stream('POST', '/v1/responses', json=body, headers={'Authorization': 'Bearer teacher-local'}) as r:
                        parts, times = [], []
                        async for part in r.aiter_text():
                            parts.append(part)
                            times.append(round((time.monotonic()-started)*1000, 2))
                        record = {'alias': model, 'mode': mode, 'http': r.status_code, 'request_id': r.headers.get('x-request-id'), 'elapsed_ms': round((time.monotonic()-started)*1000, 2), 'receive_times_ms': times, 'body': ''.join(parts)}
                except Exception as e:
                    record = {'alias': model, 'mode': mode, 'exception': type(e).__name__, 'message': str(e)}
                records.append(record)
                (ROOT/'live-results.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
                print(model, mode, record.get('http'), record.get('elapsed_ms'), record.get('body', '')[:250], flush=True)
        usage = await c.get('/admin/usage', headers={'Authorization': 'Bearer teacher-admin'})
        (ROOT/'live-ledger.json').write_text(json.dumps(usage.json(), ensure_ascii=False, indent=2))

asyncio.run(main())
