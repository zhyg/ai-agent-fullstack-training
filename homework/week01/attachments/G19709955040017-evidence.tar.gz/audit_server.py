"""Teacher-controlled upstream only. Student source is imported unchanged."""
import asyncio
import json
import sys
from pathlib import Path
import httpx
from fastapi import Request

ROOT = Path(__file__).parent
sys.path[:0] = [str(ROOT / 'student/src'), str(ROOT / 'student')]
from gateway.main import create_app
from tests.gateway.helpers import make_config, json_schema_response

calls = []
counts = {}
gates = {}
finished = {}

def sse(obj, event=None):
    return ((f'event: {event}\n' if event else '') + 'data: ' + json.dumps(obj) + '\n\n').encode()

class Stream(httpx.AsyncByteStream):
    def __init__(self, case, protocol):
        self.case, self.protocol = case, protocol

    async def __aiter__(self):
        case, protocol = self.case, self.protocol
        if protocol == 'chat':
            yield sse({'choices': [{'delta': {'role': 'assistant'}}]})
        else:
            yield sse({'type': 'response.created', 'response': {'id': 'r'}})
        await asyncio.sleep(.15)
        if protocol == 'chat':
            yield sse({'choices': [{'delta': {'content': 'FIRST'}}]})
        else:
            yield sse({'type': 'response.output_text.delta', 'delta': 'FIRST'})
        await gates[case].wait()
        if 'disconnect' in case:
            raise httpx.ReadError('controlled disconnect')
        if 'error-event' in case:
            yield sse({'type': 'error', 'error': {'code': 'server_error', 'message': 'controlled failure'}}, 'error')
        elif 'truncated' not in case:
            if protocol == 'chat':
                yield sse({'choices': [{'delta': {}, 'finish_reason': 'stop'}], 'usage': {'prompt_tokens': 17, 'completion_tokens': 9, 'total_tokens': 26, 'prompt_cache_hit_tokens': 5, 'completion_tokens_details': {'reasoning_tokens': 4}}})
                yield b'data: [DONE]\n\n'
            else:
                yield sse({'type': 'response.completed', 'response': {'status': 'completed', 'usage': {'input_tokens': 17, 'output_tokens': 9, 'input_tokens_details': {'cached_tokens': 5}, 'output_tokens_details': {'reasoning_tokens': 4}}}})
        finished[case] = True

async def handler(req):
    body = json.loads(req.content)
    protocol = 'responses' if req.url.path.endswith('/responses') else 'chat'
    raw = json.dumps(body)
    case = next((x for x in ['retry-success', 'retry-always', 'bad400', 'bad401', 'disconnect-chat', 'disconnect-responses', 'error-event-chat', 'error-event-responses', 'truncated-chat', 'truncated-responses', 'gate-chat', 'gate-responses', 'invalid', 'empty', 'cutjson', 'wrongtype', 'fenced'] if x in raw), 'normal')
    counts[case] = counts.get(case, 0) + 1
    calls.append({'path': req.url.path, 'body': body, 'case': case, 'at': asyncio.get_running_loop().time()})
    if case == 'retry-always' or (case == 'retry-success' and counts[case] <= 2):
        return httpx.Response(500, json={'error': {'message': 'controlled 500'}})
    if case in ('bad400', 'bad401'):
        return httpx.Response(int(case[3:]), json={'error': {'message': 'controlled error'}})
    if body.get('stream'):
        gates[case] = asyncio.Event()
        finished[case] = False
        return httpx.Response(200, headers={'content-type': 'text/event-stream'}, stream=Stream(case, protocol))
    content = {'invalid': 'not json', 'empty': '', 'cutjson': '{"ok":', 'wrongtype': '{"ok":"wrong"}', 'fenced': '```json\n{"ok":true}\n```'}.get(case, '{"ok":true}')
    await asyncio.sleep(.02)
    if protocol == 'chat':
        payload = json_schema_response(content)
        payload['usage'] = {'prompt_tokens': 17, 'completion_tokens': 9, 'total_tokens': 26, 'prompt_cache_hit_tokens': 5, 'completion_tokens_details': {'reasoning_tokens': 4}}
    else:
        payload = {'id': 'r', 'model': 'responses-model', 'status': 'completed', 'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': content}]}], 'usage': {'input_tokens': 17, 'output_tokens': 9, 'input_tokens_details': {'cached_tokens': 5}, 'output_tokens_details': {'reasoning_tokens': 4}}}
    return httpx.Response(200, json=payload)

cfg = make_config(database_url=str(ROOT / 'controlled.db'), overrides={
    'models': {'smart': {'routes': [{'provider': 'primary', 'model': 'primary-model', 'api': 'both'}]}},
    'resilience': {'retry': {'max_retries_per_route': 3, 'base_delay_seconds': .01, 'max_delay_seconds': .04}, 'breaker': {'enabled': False}},
    'limits': {'rate_limit': {'enabled': True, 'scope': 'model', 'requests_per_minute': 6000, 'burst': 1}},
})
app = create_app(cfg, http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))

@app.get('/audit/state')
async def state():
    return {'calls': calls, 'counts': counts, 'finished': finished}

@app.post('/audit/release/{case}')
async def release(case: str):
    gates[case].set()
    return {'released': case}

@app.post('/audit/rate/{rpm}')
async def rate(rpm: int):
    from gateway.limits.rate_limit import RateLimiter
    from gateway.config.schema import RateLimitConfig
    app.state.rate_limiter = RateLimiter(RateLimitConfig(enabled=True, scope='model', requests_per_minute=rpm, burst=1))
    return {'rpm': rpm}
