import asyncio
import json
from pathlib import Path
import httpx

ROOT = Path(__file__).parent
H = {'Authorization': 'Bearer test-key'}
A = {'Authorization': 'Bearer admin-key'}
records = []

async def main():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8917', timeout=15) as c:
        async def post(body, endpoint='responses'):
            await asyncio.sleep(.025)
            r = await c.post('/v1/' + endpoint, json=body, headers=H)
            records.append({'kind': 'request', 'input': body, 'http': r.status_code, 'request_id': r.headers.get('x-request-id'), 'result': r.json()})
            return r
        for model in ['smart', 'smart-responses', 'missing-model']:
            await post({'model': model, 'input': 'normal'})
        schema = {'type': 'json_schema', 'json_schema': {'name': 'check', 'schema': {'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok']}}}
        for model in ['smart', 'smart-responses']:
            for fmt in [{'type': 'json_object'}, schema]:
                for case in ['normal', 'invalid', 'empty', 'cutjson', 'wrongtype', 'fenced']:
                    await post({'model': model, 'input': case, 'response_format': fmt})
        for case in ['retry-success', 'retry-always', 'bad400', 'bad401']:
            await post({'model': 'smart', 'input': case})
        pid = 'teacher-' + str(__import__('time').time_ns())
        for version in [1, 2]:
            r = await c.post('/admin/prompts', headers=A, json={'prompt_id': pid, 'name': 'test', 'role': 'system', 'content': f'v{version} Hello {{{{ name }}}}', 'variables': {'type': 'object', 'properties': {'name': {'type': 'string'}}, 'required': ['name']}})
            records.append({'kind': 'prompt-create', 'http': r.status_code, 'result': r.json()})
        for ref in [{'id': pid, 'version': 1, 'variables': {'name': 'Alice'}}, {'id': pid, 'version': 2, 'variables': {'name': 'Bob'}}, {'id': 'missing'}, {'id': pid, 'version': 99}, {'id': pid, 'version': 1}]:
            await post({'model': 'smart', 'input': 'normal', 'gateway_prompt': ref})
        for model, proto in [('smart', 'chat'), ('smart-responses', 'responses')]:
            for mode in ['gate', 'disconnect', 'error-event', 'truncated']:
                case = f'{mode}-{proto}'
                await asyncio.sleep(.025)
                before = asyncio.get_running_loop().time()
                async with c.stream('POST', '/v1/responses', headers=H, json={'model': model, 'input': case, 'stream': True}) as r:
                    text = ''
                    released = False
                    first_ms = None
                    async for chunk in r.aiter_text():
                        text += chunk
                        if 'FIRST' in text and not released:
                            first_ms = (asyncio.get_running_loop().time() - before)*1000
                            state = (await c.get('/audit/state')).json()
                            pending = state['finished'][case] is False
                            await c.post('/audit/release/' + case)
                            released = True
                    records.append({'kind': 'stream', 'case': case, 'http': r.status_code, 'request_id': r.headers.get('x-request-id'), 'first_ms': first_ms, 'received_before_upstream_finished': pending, 'body': text})
        await c.post('/audit/rate/60')
        rate_results = []
        for model in ['smart', 'smart', 'smart-responses']:
            r = await c.post('/v1/responses', headers=H, json={'model': model, 'input': 'normal'})
            rate_results.append({'model': model, 'status': r.status_code, 'request_id': r.headers.get('x-request-id')})
        await asyncio.sleep(1.05)
        r = await c.post('/v1/responses', headers=H, json={'model': 'smart', 'input': 'normal'})
        rate_results.append({'model': 'smart-after-refill', 'status': r.status_code})
        records.append({'kind': 'rate', 'results': rate_results})
        records.append({'kind': 'upstream-state', 'result': (await c.get('/audit/state')).json()})
        records.append({'kind': 'ledger', 'result': (await c.get('/admin/usage?limit=200', headers=A)).json()})
    (ROOT / 'controlled-results.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
    for x in records:
        if x['kind'] == 'request':
            print(x['input']['model'], x['input']['input'], x['input'].get('response_format', {}).get('type'), x['http'])
        elif x['kind'] in ('stream', 'rate'):
            print(json.dumps(x, ensure_ascii=False))

asyncio.run(main())
