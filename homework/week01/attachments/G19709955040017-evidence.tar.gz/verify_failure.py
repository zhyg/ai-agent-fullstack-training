"""F12: change only the evaluator's in-memory fixture, not any student file."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / 'student/scripts'))
import verify_gateway as v

v._sse_fixture = lambda: 'data: {"choices":[{"delta":{"content":"only-one"}}]}\n\ndata: [DONE]\n\n'
raise SystemExit(v.main())
