"""Recheck saved evidence, expected failures are reported rather than hidden."""
import json
from pathlib import Path

root = Path(__file__).parent
r = json.loads((root/'controlled-results.json').read_text())
requests = [x for x in r if x['kind'] == 'request']
streams = [x for x in r if x['kind'] == 'stream']
state = next(x['result'] for x in r if x['kind'] == 'upstream-state')
rows = next(x['result']['data'] for x in r if x['kind'] == 'ledger')
by_id = {x['request_id']: x for x in rows}
checks = []
def check(name, value, detail):
    checks.append({'name': name, 'status': 'PASS' if value else 'FAIL', 'detail': detail})
def content(x):
    return x['result'].get('output_text', '')
def valid(s):
    try:
        json.loads(s)
        return True
    except (ValueError, TypeError):
        return False

check('A03 dual upstream protocol', {'/v1/chat/completions', '/v1/responses'} <= {x['path'] for x in state['calls']}, 'distinct paths, messages vs input bodies saved')
unknown = next(x for x in requests if x['input']['model'] == 'missing-model')
check('A04 unknown model', unknown['http'] == 404 and unknown['result']['error']['code'] == 'model_not_found', unknown['result'])
for model in ['smart', 'smart-responses']:
    chosen = [x for x in requests if x['input']['model'] == model and 'response_format' in x['input']]
    check(f'F03 {model} valid JSON normal', all(x['http'] == 200 and valid(content(x)) for x in chosen if x['input']['input'] == 'normal'), 'both json_object/json_schema')
    check(f'F04 {model} rejects invalid json_object', all(x['http'] >= 400 for x in chosen if x['input']['response_format']['type'] == 'json_object' and x['input']['input'] in ['invalid', 'empty', 'cutjson']), 'actual HTTP 200 for all three')
    check(f'F04 {model} rejects invalid/schema mismatch after repair', all(x['http'] == 422 for x in chosen if x['input']['response_format']['type'] == 'json_schema' and x['input']['input'] in ['invalid', 'empty', 'cutjson', 'wrongtype']), '2 upstream attempts each; no false success')
    check(f'F04 {model} successful schema content is JSON', all(valid(content(x)) for x in chosen if x['http'] == 200 and x['input']['response_format']['type'] == 'json_schema'), 'fenced content is returned unchanged')
for x in streams:
    case = x['case']
    check('F01 gated increment '+case, x['received_before_upstream_finished'], x['first_ms'])
    check('F02 no retry '+case, state['counts'][case] == 1, state['counts'][case])
    if 'disconnect' in case or 'error-event' in case:
        check('F02 client sees error '+case, 'error' in x['body'], x['request_id'])
        check('F07 failure ledger '+case, by_id[x['request_id']]['status'] == 'error', by_id[x['request_id']]['status'])
    if 'truncated' in case:
        check('F02 no-terminal EOF identified '+case, 'error' in x['body'], x['body'])
    if case == 'gate-chat':
        check('A02 unified Responses SSE shape', 'response.output_text.delta' in x['body'], 'Chat chunks returned from /v1/responses')
    if case.startswith('gate'):
        row = by_id[x['request_id']]
        check('F07 token totals/cache '+case, (row['total_input_tokens'], row['output_tokens'], row['cache_read_tokens']) == (17,9,5), row['request_id'])
        check('F07 reasoning classification '+case, row['reasoning_tokens'] == 4, row['reasoning_tokens'])
        check('F07 content-only TTFT '+case, row['time_to_first_chunk_ms'] >= 140, row['time_to_first_chunk_ms'])
check('F08 fail twice then success', state['counts']['retry-success'] == 3, state['counts']['retry-success'])
check('F09 max attempts', state['counts']['retry-always'] == 4, state['counts']['retry-always'])
check('F09 400/401 not retried', state['counts']['bad400'] == state['counts']['bad401'] == 1, 'one actual call each; raw httpx without SDK retry')
rate = next(x['results'] for x in r if x['kind'] == 'rate')
check('F10/F11 model independence/refill', [x['status'] for x in rate] == [200,429,200,200], rate)
limited = next(x for x in rate if x['status'] == 429)
check('F07 local limit failed request recorded', limited['request_id'] in by_id, limited['request_id'])
prompt_calls = [x['body'] for x in state['calls'] if 'v1 Hello Alice' in json.dumps(x['body']) or 'v2 Hello Bob' in json.dumps(x['body'])]
check('F05 old/new versions reach upstream', len(prompt_calls) == 2, prompt_calls)
missing = [x for x in requests if 'gateway_prompt' in x['input'] and x['http'] != 200]
check('F06 prompt/version/variable errors', [x['http'] for x in missing] == [404,404,422], [x['http'] for x in missing])
for case in ['retry-always','bad400','bad401']:
    x = next(x for x in requests if x['input']['input'] == case)
    check('F07 ordinary failure log '+case, by_id[x['request_id']]['status'] == 'error', by_id[x['request_id']]['attempts_total'])
live = json.loads((root/'live-results.json').read_text())
for x in live:
    check('REAL '+x['alias']+' '+x['mode'], x.get('http') == 200 and (len(x['receive_times_ms']) > 1 if x['mode'] == 'stream' else valid(json.loads(x['body'])['output_text'])), {'request_id': x.get('request_id'), 'elapsed_ms': x.get('elapsed_ms'), 'chunks': len(x.get('receive_times_ms', []))})
out = {'scope': 'Controlled and official live checks, NOT score by pass rate', 'passed': sum(x['status']=='PASS' for x in checks), 'failed': sum(x['status']=='FAIL' for x in checks), 'checks': checks}
(root/'assertions.json').write_text(json.dumps(out, ensure_ascii=False, indent=2))
for x in checks:
    print(x['status'], x['name'], str(x['detail'])[:170])
print(f"{out['passed']} PASS, {out['failed']} FAIL")
raise SystemExit(bool(out['failed']))
