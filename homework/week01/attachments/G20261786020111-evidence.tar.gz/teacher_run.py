"""HTTP-only acceptance against the unchanged student gateway and teacher fixture."""
import asyncio
import json
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).parent
results = []

def record(case, ok, **details):
    results.append({"case": case, "pass": bool(ok), **details})
    print(case, "PASS" if ok else "FAIL", flush=True)

def request(protocol="chat", model=None, **extra):
    model = model or ("model-b" if protocol == "anthropic" else "model-a")
    if protocol == "chat":
        return "/v1/chat/completions", {"model": model, "messages": [{"role": "user", "content": "teacher input"}], **extra}
    if protocol == "anthropic":
        return "/v1/messages", {"model": model, "max_tokens": 128, "messages": [{"role": "user", "content": "teacher input"}], **extra}
    return "/v1/responses", {"model": model, "input": "teacher input", **extra}

async def main():
    async with httpx.AsyncClient(base_url="http://127.0.0.1:18111", timeout=15) as client:
        async def mode(name):
            await client.post("/teacher/control", json={"mode": name})
        async def send(protocol="chat", model=None, **extra):
            path, body = request(protocol, model, **extra)
            return await client.post(path, json=body)
        async def state():
            return (await client.get("/teacher/state")).json()
        async def ledger():
            return (await client.get("/admin/usage?limit=1000")).json()["data"]
        record("A01", (await client.get("/healthz")).status_code == 200 and (await client.get("/readyz")).status_code == 200)
        await mode("normal")
        for protocol in ["chat", "anthropic", "responses"]:
            r = await send(protocol)
            record("A03-" + protocol, r.status_code == 200, response=r.json(), upstream=(await state())["calls"][-1])
        # Only model-b has an Anthropic route: the same Chat endpoint cannot reach it.
        r = await send(model="model-b")
        record("A02-unified-model-routing", r.status_code == 200, status=r.status_code, response=r.json())
        r = await send(model="does-not-exist")
        record("A04", r.status_code == 404 and r.json()["error"]["code"] == "model_not_found", response=r.json())
        for protocol in ["chat", "anthropic", "responses"]:
            await mode("gate")
            path, body = request(protocol, stream=True)
            received = []
            before_release = False
            saw_text = False
            started = time.monotonic()
            async with client.stream("POST", path, json=body) as r:
                async for line in r.aiter_lines():
                    received.append(line)
                    if "GATE-TEXT" in line and not saw_text:
                        saw_text = True
                        before_release = not (await state())["released"]
                        await client.post("/teacher/release")
            rows = await ledger()
            row = next(x for x in rows if x["request_id"] == r.headers["x-request-id"])
            terminal = "[DONE]" if protocol == "chat" else "message_stop" if protocol == "anthropic" else "response.completed"
            record("F01-" + protocol, before_release and terminal in "\n".join(received),
                   received_before_release=before_release, elapsed=time.monotonic()-started, sse=received, ledger=row)
            expected = (18, 7, 25) if protocol == "anthropic" else (17, 9, 26)
            actual = (row["input_tokens"], row["output_tokens"], row["total_tokens"])
            categories_ok = row["cached_input_tokens"] == 5 and row["cache_creation_input_tokens"] == (2 if protocol == "anthropic" else 0) and row["reasoning_tokens"] == (0 if protocol == "anthropic" else 3)
            record("F07-stream-" + protocol, actual == expected and categories_ok and row["first_token_ms"] >= 100,
                   expected=expected, actual=actual, ledger=row)
        for failure in ["broken", "error_event", "eof"]:
            for protocol in ["chat", "anthropic", "responses"]:
                await mode(failure)
                r = await send(protocol, stream=True)
                calls = (await state())["calls"]
                rows = await ledger()
                row = next(x for x in rows if x["request_id"] == r.headers["x-request-id"])
                events = [json.loads(line[5:]) for line in r.text.splitlines()
                          if line.startswith("data:") and line[5:].strip() != "[DONE]"]
                has_error = any(isinstance(p.get("error"), dict) or p.get("type") in ["error", "response.failed"] for p in events)
                record("F02-" + failure + "-" + protocol, has_error and len(calls) == 1,
                       calls=len(calls), sse=r.text, ledger=row,
                       scope="EOF without terminal is advisory only" if failure == "eof" else "scored")
                if failure != "eof":
                    record("F07-" + failure + "-" + protocol, row["status"] == "error", ledger=row)
        schema = {"type": "json_schema", "json_schema": {"name": "teacher", "schema": {
            "type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"]}}}
        for protocol in ["chat", "anthropic", "responses"]:
            for value in ["normal", "invalid", "empty", "truncated", "wrong_type", "fenced"]:
                await mode(value)
                if protocol == "responses":
                    extra = {"text": {"format": {"type": "json_schema", "name": "teacher", "schema": schema["json_schema"]["schema"]}}}
                else:
                    extra = {"response_format": schema}
                r = await send(protocol, **extra)
                body = r.json()
                if r.status_code == 200:
                    content = body["choices"][0]["message"]["content"] if protocol == "chat" else body["content"][0]["text"] if protocol == "anthropic" else body["output"][0]["content"][0]["text"]
                    try:
                        parsed = json.loads(content)
                        ok = parsed == {"x": 7}
                    except ValueError:
                        ok = False
                else:
                    ok = r.status_code == 422 and value != "normal"
                record(("F03-" if value == "normal" else "F04-") + value + "-" + protocol,
                       ok, status=r.status_code, response=body, upstream=(await state())["calls"])
        await mode("normal")
        for version in [1, 2]:
            r = await client.post("/v1/prompts", json={"id": "teacher-version", "name": "teacher", "content": f"v{version}: {{{{ name }}}}", "activate": True})
            assert r.status_code == 201, r.text
        for version in [1, 2]:
            r = await send(gateway_prompt={"id": "teacher-version", "version": version, "variables": {"name": "ASYMMETRIC"}})
            up = (await state())["calls"][-1]
            record("F05-v" + str(version), up["body"]["messages"][0]["content"] == f"v{version}: ASYMMETRIC",
                   upstream=up, response=r.json())
        for label, ref in [("template", {"id": "absent"}), ("version", {"id": "teacher-version", "version": 999}), ("variable", {"id": "teacher-version", "variables": {}})]:
            await mode("normal")
            before = len(await ledger())
            r = await send(gateway_prompt=ref)
            after = len(await ledger())
            record("F06-" + label, r.status_code in [404, 422] and not (await state())["calls"], status=r.status_code, response=r.json())
            record("F07-early-" + label, after == before + 1, before=before, after=after, status=r.status_code)
        for name, expected_calls, status in [("retry", 3, 200), ("always503", 3, 502), ("bad400", 1, 400)]:
            await mode(name)
            r = await send()
            calls = (await state())["calls"]
            gaps = [b["time"]-a["time"] for a,b in zip(calls,calls[1:])]
            record("F08" if name == "retry" else "F09-" + name,
                   len(calls) == expected_calls and r.status_code == status and (not gaps or gaps[0] >= .075 and gaps[1] >= .155),
                   calls=len(calls), gaps=gaps, status=r.status_code, response=r.json(), upstream=calls)
            rows = await ledger()
            row = rows[0]
            record("F07-" + name, row["attempts"] == expected_calls and row["status"] == ("success" if status == 200 else "error"), ledger=row)
        await mode("normal")
        r1 = await send(model="limited-a")
        before = len(await ledger())
        r2 = await send(model="limited-a")
        after = len(await ledger())
        r3 = await send(model="limited-b")
        record("F10", [r1.status_code,r2.status_code,r3.status_code] == [200,429,200],
               statuses=[r1.status_code,r2.status_code,r3.status_code], response=r2.json())
        record("F07-local429", after == before + 1, before=before, after=after)
        await asyncio.sleep(.6)
        r4 = await send(model="limited-a")
        record("F11", r4.status_code == 200, status=r4.status_code)
        (ROOT / "ledger.json").write_text(json.dumps(await ledger(), ensure_ascii=False, indent=2))
    (ROOT / "teacher-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))

asyncio.run(main())
