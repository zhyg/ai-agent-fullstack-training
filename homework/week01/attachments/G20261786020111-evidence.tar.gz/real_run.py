"""Bounded official-only calls through student code. Secrets remain in memory."""
import asyncio
import json
import os
import time
from pathlib import Path

import httpx
from app.config import GatewayConfig
from app.main import create_app

ROOT = Path(__file__).parent

async def main():
    key = os.environ.get("DEEPSEEK_API_KEY")
    if not key:
        (ROOT / "real-results.json").write_text(json.dumps({"status": "unverified", "reason": "no credential"}))
        return
    config = {
        "database_path": "/tmp/grade-20111/real.db", "seed_prompts": False,
        "api_keys": [], "structured_output_retries": 0,
        "retry": {"max_attempts": 1}, "rate_limit": {"enabled": False},
        "providers": {"official": {"base_url": "https://api.deepseek.com", "api_key": key,
                                      "paths": {"anthropic": "/anthropic/v1/messages"},
                                      "timeout_seconds": 18, "connect_timeout_seconds": 5}},
        "models": {
            "official-flash": {"routes": [{"provider": "official", "model": "deepseek-v4-flash", "api": "chat",
                                            "capabilities": ["chat", "streaming", "json_object"]}]},
            "official-pro": {"routes": [{"provider": "official", "model": "deepseek-v4-pro", "api": "anthropic",
                                          "capabilities": ["chat", "streaming", "json_object"]}]},
        },
    }
    safe_config = json.loads(json.dumps(config))
    safe_config["providers"]["official"]["api_key"] = "${DEEPSEEK_API_KEY}"
    (ROOT / "real-config.json").write_text(json.dumps(safe_config, indent=2))
    wires = []
    async def observe_request(req):
        assert req.url.host == "api.deepseek.com" and req.url.scheme == "https"
        wires.append({"url": str(req.url), "body": json.loads(req.content),
                      "auth_scheme": "bearer" if "authorization" in req.headers else "x-api-key",
                      "anthropic_version": req.headers.get("anthropic-version")})
    async def observe_response(resp):
        wires[-1]["status"] = resp.status_code
        wires[-1]["headers"] = {k:v for k,v in resp.headers.items() if k.lower() in ["x-request-id", "request-id", "date"]}
    results = []
    async with httpx.AsyncClient(event_hooks={"request": [observe_request], "response": [observe_response]}) as upstream:
        app = create_app(GatewayConfig.model_validate(config), http_client=upstream)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://teacher-local") as client:
                cases = [
                    ("/v1/chat/completions", {"model": "official-flash", "messages": [{"role": "user", "content": "Reply only OK."}],
                                              "max_tokens": 32, "thinking": {"type": "disabled"}}),
                    ("/v1/messages", {"model": "official-pro", "messages": [{"role": "user", "content": "Reply only OK."}], "max_tokens": 128}),
                ]
                for path, body in cases:
                    t = time.monotonic()
                    r = await client.post(path, json=body)
                    results.append({"endpoint": path, "status": r.status_code, "latency_ms": round((time.monotonic()-t)*1000,3),
                                    "request_id": r.headers.get("x-request-id"), "response": r.json()})
                    print(path, r.status_code, results[-1]["latency_ms"], flush=True)
                ledger = (await client.get("/admin/usage")).json()
    raw = json.dumps({"calls": results, "upstream": wires, "ledger": ledger}, ensure_ascii=False, indent=2)
    assert key not in raw, "Refusing to persist credential-containing results"
    (ROOT / "real-results.json").write_text(raw)

asyncio.run(main())
