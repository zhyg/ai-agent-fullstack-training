"""Final format, arithmetic, provenance and credential audit; never print secrets."""
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path(__file__).parent
REPO = Path("/home/user/workspace/repo")
feedback = REPO / "homework/week01/G20261786020111.md"
attachment = REPO / "homework/week01/attachments/G20261786020111.md"
text = feedback.read_text()
detail = attachment.read_text()
sections = {}
for index, label in [(2, "作业优点"), (3, "作业不足"), (4, "改进方案")]:
    body = text.split(f"**{index}. {label}**\n\n", 1)[1].split("\n**", 1)[0].strip()
    lines = body.splitlines()
    assert all(line.startswith("- ") for line in lines)
    assert 3 <= len(lines) <= 5
    chars = len(body)
    assert chars <= 500
    sections[label] = {"items": len(lines), "chars_including_markdown": chars}
scores = [(int(a), int(b)) for a,b in re.findall(r"^\| [^|]+ \| (\d+)/(\d+) \|", detail, re.M)]
assert len(scores) == 8 and sum(x[0] for x in scores) == 92 and sum(x[1] for x in scores) == 100
assert "优秀（92分）" in text and "92/100" in detail
assert "【" not in text and "】" not in text
for case in [f"A{i:02}" for i in range(1,5)] + [f"F{i:02}" for i in range(1,13)]:
    assert re.search(r"^\| " + case + r" \|", detail, re.M)
real = json.loads((ROOT / "real-results.json").read_text())
assert len(real["calls"]) == len(real["upstream"]) == 2
assert all(x["status"] == 200 for x in real["calls"])
assert len({x["response"]["id"] for x in real["calls"]}) == 2
assert all(x["url"].startswith("https://api.deepseek.com/") for x in real["upstream"])
assert "54 passed" in (ROOT / "student-pytest.log").read_text()
assert "1 failed" in (ROOT / "student-injected-failure.log").read_text()
assert "TEACHER_INTENTIONAL_WRONG_TEXT" in (ROOT / "student-injected-failure.log").read_text()
manifest = (ROOT / "source-manifest.txt").read_text().splitlines()
assert manifest[1:3] == ["homework-llmgateway", "6bc3fb6400bb160bb35f7a2b18262aed492e1274"]
student = Path("/tmp/student-20111")
if student.exists():
    subprocess.run(["git", "-C", str(student), "diff", "--exit-code"], check=True, capture_output=True)
services = subprocess.check_output(["amp", "orb", "service", "list"], text=True).strip()
assert "No orb services are running" in services

# Amp's name-list metadata contains variable NAMES, not their secret values.
secret_values = [v.encode() for k,v in os.environ.items()
                 if k != "AMP_SECRET_ENV_NAMES"
                 and re.search(r"KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL", k, re.I) and len(v) >= 8]
patterns = [rb"sk-[A-Za-z0-9_-]{16,}", rb"gh[pousr]_[A-Za-z0-9]{20,}", rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"]
def scan(data):
    assert not any(value in data for value in secret_values), "Actual environment secret detected; value suppressed"
    assert not any(re.search(p, data) for p in patterns), "Credential-like pattern detected; value suppressed"

files = [p for p in ROOT.iterdir() if p.is_file()] + [feedback, attachment]
for p in files:
    scan(p.read_bytes())
archive = attachment.with_name("G20261786020111-evidence.tar.gz")
members = 0
if archive.exists():
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar.getmembers():
            assert not Path(member.name).is_absolute() and ".." not in Path(member.name).parts
            if member.isfile():
                scan(tar.extractfile(member).read())
                members += 1
report = {"format": sections, "scores": scores, "total": 92,
          "actual_secret_matches": 0, "credential_pattern_matches": 0,
          "evidence_files_scanned": len(files), "archive_members_scanned": members,
          "official_requests": 2, "student_source_unchanged": True, "services": services}
print(json.dumps(report, ensure_ascii=False, indent=2))
(ROOT / "audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
