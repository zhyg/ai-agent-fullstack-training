"""Deliberately corrupt ONLY the student's mock response fixture for F12."""
def pytest_runtest_setup(item):
    original = item.module.chat_payload
    def wrong_payload(*args, **kwargs):
        payload = original(*args, **kwargs)
        payload["choices"][0]["message"]["content"] = "TEACHER_INTENTIONAL_WRONG_TEXT"
        return payload
    item.module.chat_payload = wrong_payload
