"""Teacher-only upstream fixture; no student logic is modified. Bind loopback only."""
import asyncio
import json
import time
from pathlib import Path

from fastapi import Request
from fastapi.responses import JSONResponse, StreamingResponse
from app.config import GatewayConfig
from app.main import create_app

ROOT = Path(__file__).parent
config = {
    "database_path": "/tmp/grade-20111/teacher.db", "seed_prompts": False,
    "api_keys": [], "structured_output_retries": 1,
    "retry": {"max_attempts": 3, "base_delay_seconds": .08,
              "max_delay_seconds": .5, "jitter_ratio": 0},
    "circuit_breaker": {"failure_threshold": 100, "cooldown_seconds": 1},
    "rate_limit": {"enabled": False},
    "providers": {"fixture": {"base_url": "http://127.0.0.1:18111/fixture",
                                "api_key": "fixture-not-a-real-key", "timeout_seconds": 5}},
    "models": {
        "model-a": {"routes": [{"provider": "fixture", "model": "wire-a", "api": "all",
                                "capabilities": ["chat", "streaming", "json_object"]}]},
        "model-b": {"routes": [{"provider": "fixture", "model": "wire-b", "api": "anthropic",
                                "capabilities": ["chat", "streaming", "json_object"]}]},
        "limited-a": {"rate_limit": {"enabled": True, "requests_per_minute": 120, "burst": 1},
                      "routes": [{"provider": "fixture", "model": "wire-a", "api": "chat",
                                  "capabilities": ["chat", "streaming", "json_object"]}]},
        "limited-b": {"rate_limit": {"enabled": True, "requests_per_minute": 120, "burst": 1},
                      "routes": [{"provider": "fixture", "model": "wire-b", "api": "chat",
                                  "capabilities": ["chat", "streaming", "json_object"]}]},
    },
}
(ROOT / "teacher-config.json").write_text(json.dumps(config, indent=2))
app = create_app(GatewayConfig.model_validate(config))
state = {"mode": "normal", "calls": []}
gate = asyncio.Event()

@app.post("/teacher/control")
async def control(request: Request):
    data = await request.json()
    state.update(mode=data["mode"], calls=[])
    gate.clear()
    return {"ok": True}

@app.post("/teacher/release")
async def release():
    gate.set()
    return {"ok": True}

@app.get("/teacher/state")
async def get_state():
    return {**state, "released": gate.is_set()}

def event(data, name=None):
    return ((f"event: {name}\n" if name else "") + "data: " +
            (data if isinstance(data, str) else json.dumps(data)) + "\n\n").encode()

def chunk(text="", usage=None):
    data = {"id": "fixture-chat", "choices": [{"index": 0, "delta": {"content": text},
                                              "finish_reason": None}]}
    if usage is not None:
        data["usage"] = usage
    return data

CHAT_USAGE = {"prompt_tokens": 17, "completion_tokens": 9, "total_tokens": 26,
              "prompt_tokens_details": {"cached_tokens": 5},
              "completion_tokens_details": {"reasoning_tokens": 3}}
ANTH_USAGE = {"input_tokens": 11, "cache_read_input_tokens": 5,
              "cache_creation_input_tokens": 2, "output_tokens": 7}
RESP_USAGE = {"input_tokens": 17, "output_tokens": 9, "total_tokens": 26,
              "input_tokens_details": {"cached_tokens": 5},
              "output_tokens_details": {"reasoning_tokens": 3}}

@app.post("/fixture/v1/{path:path}")
async def upstream(path: str, request: Request):
    body = await request.json()
    mode = state["mode"]
    state["calls"].append({"path": request.url.path, "body": body,
                           "time": time.monotonic(),
                           "auth": "bearer" if "authorization" in request.headers else "x-api-key",
                           "anthropic_version": request.headers.get("anthropic-version")})
    count = len(state["calls"])
    if mode == "always503" or (mode == "retry" and count < 3):
        return JSONResponse({"error": {"message": "teacher temporary failure"}}, status_code=503)
    if mode == "bad400":
        return JSONResponse({"error": {"message": "teacher rejected request"}}, status_code=400)
    protocol = "chat" if path == "chat/completions" else "anthropic" if path == "messages" else "responses"
    content = {"invalid": "not json", "empty": "", "truncated": '{"x":',
               "fenced": '```json\n{"x":7}\n```', "wrong_type": '{"x":"seven"}'}.get(mode, '{"x":7}')
    if body.get("stream"):
        async def generate():
            # Metadata/empty delta must not be treated as TTFT.
            if protocol == "chat":
                yield event(chunk())
            elif protocol == "anthropic":
                yield event({"type": "message_start", "message": {"id": "fixture-msg", "usage": ANTH_USAGE}}, "message_start")
            else:
                yield event({"type": "response.created", "response": {"id": "fixture-resp", "status": "in_progress"}}, "response.created")
            await asyncio.sleep(.12)
            if protocol == "chat":
                yield event(chunk("GATE-TEXT"))
            elif protocol == "anthropic":
                yield event({"type": "content_block_delta", "index": 0,
                             "delta": {"type": "text_delta", "text": "GATE-TEXT"}}, "content_block_delta")
            else:
                yield event({"type": "response.output_text.delta", "delta": "GATE-TEXT"}, "response.output_text.delta")
            if mode == "gate":
                await asyncio.wait_for(gate.wait(), 8)
            if mode == "broken":
                raise RuntimeError("teacher intentional transport abort after content")
            if mode == "error_event":
                if protocol == "chat":
                    yield event({"error": {"message": "teacher stream failure", "code": "fixture_error"}})
                else:
                    yield event({"type": "error", "error": {"message": "teacher stream failure"}}, "error")
                return
            if mode == "eof":
                return
            if protocol == "chat":
                yield event(chunk(usage={"prompt_tokens": 10, "completion_tokens": 2, "total_tokens": 12}))
                yield event(chunk(usage=CHAT_USAGE))
                yield event("[DONE]")
            elif protocol == "anthropic":
                yield event({"type": "message_delta", "delta": {"stop_reason": "end_turn"},
                             "usage": {"output_tokens": 7}}, "message_delta")
                yield event({"type": "message_stop"}, "message_stop")
            else:
                yield event({"type": "response.completed", "response": {"status": "completed", "usage": RESP_USAGE}}, "response.completed")
        return StreamingResponse(generate(), media_type="text/event-stream")
    if protocol == "chat":
        payload = {"id": "fixture-chat", "object": "chat.completion", "model": body["model"],
                   "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
                   "usage": CHAT_USAGE}
    elif protocol == "anthropic":
        payload = {"id": "fixture-msg", "type": "message", "role": "assistant", "model": body["model"],
                   "content": [{"type": "text", "text": content}], "stop_reason": "end_turn", "usage": ANTH_USAGE}
    else:
        payload = {"id": "fixture-resp", "status": "completed", "model": body["model"],
                   "output": [{"type": "message", "content": [{"type": "output_text", "text": content}]}], "usage": RESP_USAGE}
    return JSONResponse(payload)
