# G20261786020111 受控评测重放

评测源码固定为 Gitee `kk375/ai_coding_1` 的 `homework-llmgateway` 分支提交 `6bc3fb6400bb160bb35f7a2b18262aed492e1274`。所有 teacher 文件都是外置夹具，不是学生交付，也不修改学生逻辑。

## 准备

将本证据包解压至 `/tmp/grade-20111/evidence`。示例路径是可丢弃的评测目录；若已有现场，不要覆盖其源码或数据库。

```bash
git clone --branch homework-llmgateway --single-branch https://gitee.com/kk375/ai_coding_1.git /tmp/student-20111
git -C /tmp/student-20111 checkout --detach 6bc3fb6400bb160bb35f7a2b18262aed492e1274
python -m venv /tmp/grade-20111/venv
/tmp/grade-20111/venv/bin/pip install -r /tmp/student-20111/requirements-dev.txt
```

在学生目录运行 README 的 `python -m pytest -q`，本次 54 passed。README 直接启动使用 `GATEWAY_CONFIG=gateway.example.yaml uvicorn app.main:app`，评测仅换成独立端口 18112，未对该服务发上游调用。

## 教师全部受控用例（不访问外网，不需要真实密钥）

在学生目录运行：

```bash
amp orb service start grade20111 --command 'PYTHONPATH=/tmp/student-20111:/tmp/grade-20111/evidence /tmp/grade-20111/venv/bin/uvicorn teacher_app:app --host 127.0.0.1 --port 18111' --port 18111
curl --fail http://127.0.0.1:18111/readyz
/tmp/grade-20111/venv/bin/python /tmp/grade-20111/evidence/teacher_run.py
amp orb service stop grade20111
```

服务启动是异步的；确认 readyz 成功后才运行脚本。首次建议用空的、专用于本评测的 `/tmp/grade-20111/teacher.db`。脚本输出 PASS/FAIL 是对所测契约的判断，不是按通过率换算分数；`F02-eof-*` 是不扣分的建议项。

单项 D1：普通 Chat 请求 model-b；D2：先设置模式 fenced，再发送 response_format；D3：错误模板调用前后比较 admin/usage，或 error_event 模式下请求 Chat stream 后按响应 X-Request-ID 查询账本。所有请求正文、断言和配置均在 teacher_run.py / teacher_app.py，无测试替换学生业务方法。

## 学生脚本失败检测（仅污染 Mock 响应）

```bash
PYTHONPATH=/tmp/grade-20111/evidence:/tmp/student-20111 /tmp/grade-20111/venv/bin/python -m pytest -q -p failure_injection tests/test_gateway.py::test_normal_call_records_categorized_usage_and_latency
```

从学生目录运行，预期 exit 1，并显示 hello 与 TEACHER_INTENTIONAL_WRONG_TEXT 的正文断言差异。该插件只在进程内修改学生测试生成的模拟上游正文，不修改源码或实际网关实现。

## 真实调用（不默认重放）

`real-results.json` 已包含两个官方模型的成功证据，**不要为重放扣分自动再次执行 real_run.py**。若后续协议修复确需复验，由环境注入个人 DEEPSEEK_API_KEY，绝不能将其写入文件或日志；脚本只允许 api.deepseek.com、每模型一次、无 fallback/修复轮。real-config.json 中的变量名是占位符，未含真实密钥。

## 证据说明

- source-manifest.txt / source-lines.txt：固定 HEAD、Git blob 清单、关键源文件行号。
- install.log / dependencies.txt / readme-*.log：依赖和 README 启动。
- student-pytest.log / student-injected-failure.log：原测试结果与故意失败对照。
- teacher-results.json / teacher-run.log / ledger.json / teacher-service.log：最终受控断言、请求、响应、账本与服务日志；账本/日志可能包含多轮离线复核，按最终 JSON 的 request_id 对照。
- real-results.json / real-run.log / real-config.json：恰好两条官方真实调用、无明文凭据配置。
- audit.json / closure.log：收尾核查，无实际凭据值；MANIFEST.sha256：包内文件完整性校验。
