"""拆开的故障补测。限流用独立进程，避免和重试共用窗口。"""

from __future__ import annotations

import json
import time

import httpx

GW = "http://127.0.0.1:8767"
UP = "http://127.0.0.1:8766"
PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"
SCHEMA = {
    "type": "object",
    "properties": {"word": {"type": "string"}},
    "required": ["word"],
    "additionalProperties": False,
}


def calls(up: httpx.Client) -> list[dict]:
    return up.get("/_log").json()["calls"]


def arm(up: httpx.Client, scenario: str, protocol: str) -> None:
    model_field = "pro_model" if protocol == "openai" else "flash_model"
    up.post("/_reset")
    httpx.post(
        f"{GW}/v1/runtime/upstream",
        json={model_field: f"scenario-{scenario}"},
        timeout=10.0,
    )


def disarm(protocol: str) -> None:
    model_field = "pro_model" if protocol == "openai" else "flash_model"
    value = "deepseek-v4-pro" if protocol == "openai" else "deepseek-flash"
    httpx.post(f"{GW}/v1/runtime/upstream", json={model_field: value}, timeout=10.0)


def main() -> None:
    gw = httpx.Client(base_url=GW, timeout=30.0)
    up = httpx.Client(base_url=UP, timeout=10.0)
    report = {}

    arm(up, "invalid-json-body", "openai")
    bad = gw.post(
        "/v1/invoke",
        json={
            "model": PRO,
            "messages": [{"role": "user", "content": "json"}],
            "response_format": {"type": "json_object", "schema": SCHEMA, "strict": False},
        },
    )
    report["invalid_json"] = {
        "status": bad.status_code,
        "error": bad.json().get("error"),
        "output": bad.json().get("output"),
        "calls": len(calls(up)),
    }
    disarm("openai")

    arm(up, "empty-text", "openai")
    empty = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "empty-text"},
        json={
            "model": PRO,
            "messages": [{"role": "user", "content": "json"}],
            "response_format": {"type": "json_object", "schema": SCHEMA, "strict": False},
        },
    )
    report["empty_json"] = {
        "status": empty.status_code,
        "error": (empty.json().get("error") or {}).get("code"),
        "output": empty.json().get("output"),
        "finish": empty.json().get("finish_reason"),
        "calls": len(calls(up)),
    }
    disarm("openai")

    arm(up, "fail-2", "openai")
    started = time.perf_counter()
    recovered = gw.post(
        "/v1/invoke",
        json={"model": PRO, "messages": [{"role": "user", "content": "retry"}]},
    )
    report["retry_recover"] = {
        "status": recovered.status_code,
        "attempts": recovered.json().get("attempts"),
        "text": (recovered.json().get("output") or {}).get("text"),
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 1),
        "calls": len(calls(up)),
        "statuses_seen": [item["model"] for item in calls(up)],
    }
    disarm("openai")

    arm(up, "fail-always", "anthropic")
    exhausted = gw.post(
        "/v1/invoke",
        json={"model": FLASH, "messages": [{"role": "user", "content": "retry"}]},
    )
    report["retry_exhausted"] = {
        "status": exhausted.status_code,
        "error": exhausted.json().get("error"),
        "calls": len(calls(up)),
    }
    disarm("anthropic")

    arm(up, "status-401", "openai")
    auth = gw.post(
        "/v1/invoke",
        json={"model": PRO, "messages": [{"role": "user", "content": "auth"}]},
    )
    disarm("openai")
    arm(up, "status-400", "anthropic")
    bad_req = gw.post(
        "/v1/invoke",
        json={"model": FLASH, "messages": [{"role": "user", "content": "bad"}]},
    )
    disarm("anthropic")
    report["non_retryable"] = {
        "auth": {"status": auth.status_code, "error": auth.json().get("error")},
        "bad": {"status": bad_req.status_code, "error": bad_req.json().get("error")},
        "calls": len(calls(up)),
    }

    arm(up, "error-after-delta", "openai")
    events = []
    chunks = []
    with gw.stream(
        "POST",
        "/v1/invoke",
        json={"model": PRO, "stream": True, "messages": [{"role": "user", "content": "stream"}]},
    ) as response:
        event = None
        status = response.status_code
        for line in response.iter_lines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                events.append(event)
            elif line.startswith("data:") and event in {"delta", "error", "done", "usage"}:
                chunks.append((event, line.split(":", 1)[1].strip()[:220]))
    report["stream_error_after_delta"] = {
        "status": status,
        "events": events,
        "chunks": chunks,
        "calls": len(calls(up)),
    }
    disarm("openai")

    arm(up, "drop-after-delta", "anthropic")
    events = []
    with gw.stream(
        "POST",
        "/v1/invoke",
        json={"model": FLASH, "stream": True, "messages": [{"role": "user", "content": "stream"}]},
    ) as response:
        event = None
        for line in response.iter_lines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                events.append(event)
    logs = gw.get("/v1/logs", params={"limit": 5}).json()["data"]
    report["stream_drop"] = {
        "events": events,
        "calls": len(calls(up)),
        "latest_log": logs[0] if logs else None,
    }
    disarm("anthropic")

    # jitter upper bound with a fresh policy object cannot be tested through HTTP
    # without changing student code. Record gateway retry delays from logs if present.
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
