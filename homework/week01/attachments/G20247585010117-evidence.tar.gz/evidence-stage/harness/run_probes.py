"""对学员网关做受控补测。密钥只从环境读取，日志不写密钥。"""

from __future__ import annotations

import json
import os
import time
from typing import Any

import httpx

BASE = os.environ["GATEWAY_URL"]
OUT = os.environ["PROBE_OUT"]
PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"
SCHEMA = {
    "type": "object",
    "properties": {"word": {"type": "string"}},
    "required": ["word"],
    "additionalProperties": False,
}


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: ("<redacted>" if "key" in key.lower() or "authorization" in key.lower() else redact(item)) for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, str) and value.startswith("sk-"):
        return "<redacted>"
    return value


def main() -> None:
    client = httpx.Client(base_url=BASE, timeout=90.0)
    report: dict[str, Any] = {"cases": []}

    def record(name: str, **fields: Any) -> None:
        item = {"name": name, **fields}
        report["cases"].append(item)
        print(name, json.dumps(redact(fields), ensure_ascii=False)[:500])

    health = client.get("/health")
    record("health", status=health.status_code, body=health.json())

    runtime = client.get("/v1/runtime")
    record("runtime", status=runtime.status_code, body=redact(runtime.json()))

    for model in (PRO, FLASH):
        started = time.perf_counter()
        response = client.post(
            "/v1/invoke",
            json={
                "model": model,
                "max_tokens": 32,
                "messages": [{"role": "user", "content": "Reply with the single word pong."}],
            },
        )
        elapsed = round((time.perf_counter() - started) * 1000, 1)
        body = response.json()
        record(
            f"live-complete-{model}",
            status=response.status_code,
            elapsed_ms=elapsed,
            provider=body.get("provider"),
            mode=body.get("mode"),
            text=(body.get("output") or {}).get("text"),
            usage=body.get("usage"),
            latency=body.get("latency"),
            attempts=body.get("attempts"),
            finish_reason=body.get("finish_reason"),
            error=body.get("error"),
        )

    for model in (PRO, FLASH):
        times: list[float] = []
        events: list[str] = []
        texts: list[str] = []
        started = time.perf_counter()
        with client.stream(
            "POST",
            "/v1/invoke",
            json={
                "model": model,
                "stream": True,
                "max_tokens": 32,
                "messages": [{"role": "user", "content": "Reply with the single word pong."}],
            },
        ) as response:
            status = response.status_code
            ctype = response.headers.get("content-type")
            event = None
            for line in response.iter_lines():
                now = round((time.perf_counter() - started) * 1000, 1)
                if line.startswith("event:"):
                    event = line.split(":", 1)[1].strip()
                    events.append(event)
                    times.append(now)
                elif line.startswith("data:") and event == "delta":
                    payload = json.loads(line.split(":", 1)[1])
                    texts.append(payload.get("text") or "")
        record(
            f"live-stream-{model}",
            status=status,
            content_type=ctype,
            events=events,
            delta_count=events.count("delta"),
            first_event_ms=times[0] if times else None,
            last_event_ms=times[-1] if times else None,
            text="".join(texts)[:80],
        )

    for model in (PRO, FLASH):
        response = client.post(
            "/v1/invoke",
            json={
                "model": model,
                "max_tokens": 64,
                "messages": [{"role": "user", "content": "Return JSON with word set to pong."}],
                "response_format": {"type": "json_object", "schema": SCHEMA, "strict": True},
            },
        )
        body = response.json()
        record(
            f"live-structured-{model}",
            status=response.status_code,
            provider=body.get("provider"),
            output=body.get("output"),
            error=(body.get("error") or {}).get("code"),
            message=(body.get("error") or {}).get("message", "")[:180],
            finish_reason=body.get("finish_reason"),
        )

    unknown = client.post(
        "/v1/invoke",
        json={"model": "no-such-model", "messages": [{"role": "user", "content": "hi"}]},
    )
    record("unknown-model", status=unknown.status_code, body=unknown.json())

    created = client.post(
        "/v1/prompts",
        json={"name": "grade-reply", "template": "v1 {{name}}"},
    )
    v2 = client.post("/v1/prompts/grade-reply/versions", json={"template": "v2 {{name}}"})
    pinned = client.post(
        "/v1/invoke",
        json={"model": PRO, "max_tokens": 32, "prompt": {"name": "grade-reply", "version": 1, "variables": {"name": "Ada"}}},
    )
    missing = client.post(
        "/v1/invoke",
        json={"model": PRO, "prompt": {"name": "grade-reply", "variables": {}}},
    )
    absent = client.post(
        "/v1/invoke",
        json={"model": PRO, "prompt": {"name": "missing-template", "variables": {}}},
    )
    record(
        "templates",
        created=created.status_code,
        v2=v2.status_code,
        pinned_status=pinned.status_code,
        pinned_text=(pinned.json().get("output") or {}).get("text", "")[:120],
        missing=missing.status_code,
        missing_code=(missing.json().get("error") or {}).get("code"),
        absent=absent.status_code,
        absent_code=(absent.json().get("error") or {}).get("code"),
    )

    logs = client.get("/v1/logs", params={"limit": 20})
    metrics = client.get("/v1/metrics")
    log_rows = logs.json().get("data", [])
    record(
        "observability",
        logs_status=logs.status_code,
        log_count=len(log_rows),
        models=sorted({row.get("model") for row in log_rows}),
        failed=sum(1 for row in log_rows if not row.get("ok")),
        metrics_calls=metrics.json().get("totals", {}).get("calls"),
    )

    with open(OUT, "w", encoding="utf-8") as handle:
        json.dump(redact(report), handle, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
