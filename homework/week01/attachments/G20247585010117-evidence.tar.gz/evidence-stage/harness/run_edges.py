"""边界补测：心跳 TTFT、抖动上界、限流隔离、流式增量、fence JSON、4xx 映射。"""

from __future__ import annotations

import json
import time

import httpx

GW = "http://127.0.0.1:8767"
UP = "http://127.0.0.1:8766"


def arm(scenario: str) -> None:
    httpx.post(f"{UP}/_reset", timeout=5)
    httpx.post(f"{GW}/v1/runtime/upstream", json={"pro_model": f"scenario-{scenario}"}, timeout=5)


def disarm() -> None:
    httpx.post(f"{GW}/v1/runtime/upstream", json={"pro_model": "deepseek-v4-pro"}, timeout=5)


def main() -> None:
    gw = httpx.Client(base_url=GW, timeout=20)
    report = {}

    arm("heartbeat-then-text")
    events = []
    started = time.perf_counter()
    stamps = []
    with gw.stream(
        "POST",
        "/v1/invoke",
        json={"model": "deepseek-v4-pro", "stream": True, "messages": [{"role": "user", "content": "x"}]},
    ) as response:
        event = None
        for line in response.iter_lines():
            now = round((time.perf_counter() - started) * 1000, 1)
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                events.append(event)
                stamps.append((event, now))
            elif line.startswith("data:") and event == "delta":
                stamps.append(("delta-data " + line[5:].strip(), now))
    logs = gw.get("/v1/logs", params={"limit": 1}).json()["data"]
    report["heartbeat"] = {"events": events, "stamps": stamps, "log": logs[0]["latency"] if logs else None, "ok": logs[0]["ok"] if logs else None}
    disarm()

    # jitter: call RetryPolicy directly from student code, no gateway change
    from app.domain.retry import RetryPolicy
    policy = RetryPolicy(base_delay_ms=1000, max_delay_ms=8000, jitter=0.2)
    samples = [policy.delay_ms(1) for _ in range(200)]
    report["jitter"] = {
        "min": min(samples),
        "max": max(samples),
        "bound": 1000,
        "over_bound": sum(1 for item in samples if item > 1000),
    }

    # fenced JSON through normalizer
    from app.application.output_normalizer import OutputNormalizer
    from app.application.dto import ResponseFormatCommand
    from app.domain.models import ProviderResult, Usage
    from app.domain.errors import GatewayError
    normalizer = OutputNormalizer()
    fmt = ResponseFormatCommand(type="json_object", schema={"type": "object"}, strict=False)
    try:
        text, structured = normalizer.normalize(fmt, ProviderResult(text='```json\n{"a": 1}\n```', usage=Usage()))
        report["fence"] = {"ok": True, "text": text, "structured": structured}
    except GatewayError as exc:
        report["fence"] = {"ok": False, "code": exc.code}

    # rate limit isolation on a dedicated gateway is done by caller if env says so
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
