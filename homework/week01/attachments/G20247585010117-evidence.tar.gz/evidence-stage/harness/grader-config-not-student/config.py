"""评测补齐模块，不是学员提交。

提交 f1000d0a5f6ef03970d6a34ea532adac79ca50a0 的 W1 引用
app.infrastructure.config，但该文件不在仓库中。本文件只按源码已调用的
字段名和 README 公布的环境变量默认值补齐，供导入与运行时验收。
不改变适配器、路由、重试、限流或校验逻辑。
"""

from __future__ import annotations

import os
from functools import lru_cache

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.domain.models import ModelRoute


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")

    use_mock: bool = True
    openai_base_url: str = "https://api.openai.com/v1"
    anthropic_base_url: str = "https://api.anthropic.com"
    openai_api_key: SecretStr | None = None
    anthropic_api_key: SecretStr | None = None
    pro_upstream_model: str = "deepseek-v4-pro"
    flash_upstream_model: str = "deepseek-v4-flash"
    http_timeout_seconds: float = 60
    http_connect_timeout_seconds: float = 15
    retry_max_attempts: int = 3
    retry_base_delay_ms: int = 200
    retry_max_delay_ms: int = 2000
    retry_jitter: float = 0.2
    rate_limit_per_minute: int = 20
    log_level: str = "INFO"
    redaction_mode: str = "mixed"
    hash_salt: str = "local-default-salt"
    extra_redaction_patterns: list[str] = []
    auth_enabled: bool = False
    api_key_list: list[str] = []
    max_request_bytes: int = 1_000_000
    environment: str = "local"
    version: str = "0.1.0"

    def openai_key(self) -> str:
        return self.openai_api_key.get_secret_value() if self.openai_api_key else ""

    def anthropic_key(self) -> str:
        return self.anthropic_api_key.get_secret_value() if self.anthropic_api_key else ""

    def model_routes(self) -> dict[str, ModelRoute]:
        limit = self.rate_limit_per_minute
        return {
            "deepseek-v4-pro": ModelRoute(
                name="deepseek-v4-pro",
                protocol="openai-responses",
                upstream_model=self.pro_upstream_model,
                timeout_seconds=self.http_timeout_seconds,
                rate_limit_limit=limit,
            ),
            "deepseek-v4-flash": ModelRoute(
                name="deepseek-v4-flash",
                protocol="anthropic-messages",
                upstream_model=self.flash_upstream_model,
                timeout_seconds=self.http_timeout_seconds,
                rate_limit_limit=limit,
            ),
        }


@lru_cache
def get_settings() -> Settings:
    extra = os.getenv("REDACTION_EXTRA_PATTERNS", "")
    patterns = [item for item in extra.split("||") if item] if extra else []
    keys = os.getenv("GATEWAY_API_KEYS", "")
    return Settings(
        use_mock=_bool("GATEWAY_USE_MOCK", True),
        openai_base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        anthropic_base_url=os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com"),
        openai_api_key=SecretStr(os.environ["OPENAI_API_KEY"]) if os.getenv("OPENAI_API_KEY") else None,
        anthropic_api_key=SecretStr(os.environ["ANTHROPIC_API_KEY"]) if os.getenv("ANTHROPIC_API_KEY") else None,
        pro_upstream_model=os.getenv("MODEL_PRO_UPSTREAM", "deepseek-v4-pro"),
        flash_upstream_model=os.getenv("MODEL_FLASH_UPSTREAM", "deepseek-v4-flash"),
        http_timeout_seconds=float(os.getenv("HTTP_TIMEOUT_SECONDS", "60")),
        http_connect_timeout_seconds=float(os.getenv("HTTP_CONNECT_TIMEOUT_SECONDS", "15")),
        retry_max_attempts=int(os.getenv("RETRY_MAX_ATTEMPTS", "3")),
        retry_base_delay_ms=int(os.getenv("RETRY_BASE_DELAY_MS", "200")),
        retry_max_delay_ms=int(os.getenv("RETRY_MAX_DELAY_MS", "2000")),
        retry_jitter=float(os.getenv("RETRY_JITTER", "0.2")),
        rate_limit_per_minute=int(os.getenv("RATE_LIMIT_PER_MINUTE", "20")),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
        redaction_mode=os.getenv("REDACTION_MODE", "mixed"),
        hash_salt=os.getenv("REDACTION_HASH_SALT", "local-default-salt"),
        extra_redaction_patterns=patterns,
        auth_enabled=_bool("GATEWAY_AUTH_ENABLED", False),
        api_key_list=[item.strip() for item in keys.split(",") if item.strip()],
        max_request_bytes=int(os.getenv("MAX_REQUEST_BYTES", "1000000")),
        environment=os.getenv("APP_ENV", "local"),
        version=os.getenv("APP_VERSION", "0.1.0"),
    )
