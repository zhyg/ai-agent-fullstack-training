"""受控上游补测：协议差异、重试、限流、非法 JSON、断流。不调用真实模型。"""

from __future__ import annotations

import json
import time
from typing import Any

import httpx

GW = "http://127.0.0.1:8767"
UP = "http://127.0.0.1:8766"
PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"
SCHEMA = {
    "type": "object",
    "properties": {"word": {"type": "string"}},
    "required": ["word"],
    "additionalProperties": False,
}


def main() -> None:
    gw = httpx.Client(base_url=GW, timeout=30.0)
    up = httpx.Client(base_url=UP, timeout=10.0)
    report: dict[str, Any] = {}

    def reset() -> None:
        up.post("/_reset")

    def calls() -> list[dict[str, Any]]:
        return up.get("/_log").json()["calls"]

    reset()
    pro = gw.post("/v1/invoke", json={"model": PRO, "max_tokens": 16, "messages": [{"role": "user", "content": "hi"}]})
    flash = gw.post("/v1/invoke", json={"model": FLASH, "max_tokens": 16, "messages": [{"role": "user", "content": "hi"}]})
    report["protocol_complete"] = {
        "pro_status": pro.status_code,
        "pro_provider": pro.json().get("provider"),
        "pro_text": pro.json().get("output", {}).get("text"),
        "flash_status": flash.status_code,
        "flash_provider": flash.json().get("provider"),
        "flash_text": flash.json().get("output", {}).get("text"),
        "upstream": calls(),
    }

    reset()
    structured = {}
    for model in (PRO, FLASH):
        response = gw.post(
            "/v1/invoke",
            json={
                "model": model,
                "max_tokens": 32,
                "messages": [{"role": "user", "content": "json"}],
                "response_format": {"type": "json_object", "schema": SCHEMA, "strict": True},
            },
        )
        body = response.json()
        structured[model] = {
            "status": response.status_code,
            "json": (body.get("output") or {}).get("json"),
            "error": (body.get("error") or {}).get("code"),
        }
    structured["upstream"] = calls()
    report["protocol_structured"] = structured

    reset()
    gw.post(
        "/v1/prompts",
        json={"name": "trace-tpl", "template": "MARKER_V1 {{name}}"},
    )
    gw.post("/v1/prompts/trace-tpl/versions", json={"template": "MARKER_V2 {{name}}"})
    pinned = gw.post(
        "/v1/invoke",
        json={
            "model": PRO,
            "max_tokens": 16,
            "prompt": {"name": "trace-tpl", "version": 1, "variables": {"name": "Ada"}},
        },
    )
    latest = gw.post(
        "/v1/invoke",
        json={
            "model": FLASH,
            "max_tokens": 16,
            "prompt": {"name": "trace-tpl", "variables": {"name": "Ada"}},
        },
    )
    report["template_upstream"] = {
        "pinned_status": pinned.status_code,
        "latest_status": latest.status_code,
        "upstream_inputs": [
            {
                "path": item["path"],
                "model": item["model"],
                "input": item.get("captured_input"),
                "system": item.get("captured_system"),
                "messages": item.get("captured_messages"),
            }
            for item in calls()
        ],
    }

    reset()
    bad = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "invalid-json-body"},
        json={
            "model": PRO,
            "max_tokens": 16,
            "messages": [{"role": "user", "content": "json"}],
            "response_format": {"type": "json_object", "schema": SCHEMA, "strict": False},
        },
    )
    report["invalid_json"] = {
        "status": bad.status_code,
        "body": bad.json(),
        "upstream_calls": len(calls()),
    }

    reset()
    empty = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "empty-text"},
        json={
            "model": PRO,
            "messages": [{"role": "user", "content": "json"}],
            "response_format": {"type": "json_object", "schema": SCHEMA, "strict": False},
        },
    )
    report["empty_json"] = {"status": empty.status_code, "code": (empty.json().get("error") or {}).get("code"), "calls": len(calls())}

    reset()
    started = time.perf_counter()
    recovered = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "fail-2"},
        json={"model": PRO, "messages": [{"role": "user", "content": "retry"}]},
    )
    report["retry_recover"] = {
        "status": recovered.status_code,
        "attempts": recovered.json().get("attempts"),
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 1),
        "upstream_calls": len(calls()),
        "paths": [item["path"] for item in calls()],
    }

    reset()
    exhausted = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "fail-always"},
        json={"model": FLASH, "messages": [{"role": "user", "content": "retry"}]},
    )
    report["retry_exhausted"] = {
        "status": exhausted.status_code,
        "body": exhausted.json(),
        "upstream_calls": len(calls()),
    }

    reset()
    auth = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "status-401"},
        json={"model": PRO, "messages": [{"role": "user", "content": "auth"}]},
    )
    bad_req = gw.post(
        "/v1/invoke",
        headers={"X-Scenario": "status-400"},
        json={"model": FLASH, "messages": [{"role": "user", "content": "bad"}]},
    )
    report["non_retryable"] = {
        "auth_status": auth.status_code,
        "auth_code": auth.json().get("error", {}).get("code"),
        "auth_calls": None,
        "bad_status": bad_req.status_code,
        "bad_code": bad_req.json().get("error", {}).get("code"),
        "upstream_calls": len(calls()),
        "upstream": calls(),
    }

    reset()
    events = []
    with gw.stream(
        "POST",
        "/v1/invoke",
        headers={"X-Scenario": "error-after-delta"},
        json={"model": PRO, "stream": True, "messages": [{"role": "user", "content": "stream"}]},
    ) as response:
        event = None
        chunks = []
        for line in response.iter_lines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                events.append(event)
            elif line.startswith("data:") and event in {"delta", "error", "done"}:
                chunks.append((event, line.split(":", 1)[1].strip()[:180]))
    report["stream_error_after_delta"] = {
        "events": events,
        "chunks": chunks,
        "upstream_calls": len(calls()),
    }

    reset()
    events = []
    with gw.stream(
        "POST",
        "/v1/invoke",
        headers={"X-Scenario": "drop-after-delta"},
        json={"model": FLASH, "stream": True, "messages": [{"role": "user", "content": "stream"}]},
    ) as response:
        event = None
        for line in response.iter_lines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                events.append(event)
    report["stream_drop"] = {"events": events, "upstream_calls": len(calls())}

    # rate limit: fresh process already has prior calls. Use remaining window.
    statuses = []
    for index in range(8):
        response = gw.post(
            "/v1/invoke",
            json={"model": PRO, "messages": [{"role": "user", "content": f"limit {index}"}]},
        )
        statuses.append(response.status_code)
        if response.status_code == 429:
            report["rate_limit_hit"] = {
                "statuses": statuses,
                "code": response.json().get("error", {}).get("code"),
                "retry_after": response.headers.get("retry-after"),
            }
            break
    other = gw.post("/v1/invoke", json={"model": FLASH, "messages": [{"role": "user", "content": "other"}]})
    report["rate_limit_other"] = {"status": other.status_code, "provider": other.json().get("provider")}

    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
