"""评测用上游：记录请求路径和协议字段，并可注入 5xx、4xx、非法 JSON、断流。"""

from __future__ import annotations

import json
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI()
LOG: list[dict[str, Any]] = []


def _record(path: str, body: dict[str, Any], headers: dict[str, str]) -> dict[str, Any]:
    item = {
        "path": path,
        "model": body.get("model"),
        "keys": sorted(body.keys()),
        "has_input": "input" in body,
        "has_text_format": isinstance(body.get("text"), dict),
        "text_format_type": ((body.get("text") or {}).get("format") or {}).get("type") if isinstance(body.get("text"), dict) else None,
        "has_messages": "messages" in body,
        "has_tools": "tools" in body,
        "tool_choice": body.get("tool_choice"),
        "stream": body.get("stream"),
        "auth": "bearer" if headers.get("authorization", "").lower().startswith("bearer ") else "",
        "x_api_key": bool(headers.get("x-api-key")),
        "anthropic_version": headers.get("anthropic-version"),
        "scenario": headers.get("x-scenario", ""),
        "captured_input": body.get("input"),
        "captured_system": body.get("system"),
        "captured_messages": body.get("messages"),
        "max_output_tokens": body.get("max_output_tokens"),
        "max_tokens": body.get("max_tokens"),
    }
    LOG.append(item)
    return item


@app.get("/_log")
async def get_log() -> dict[str, Any]:
    return {"calls": LOG, "count": len(LOG)}


@app.post("/_reset")
async def reset() -> dict[str, str]:
    LOG.clear()
    return {"ok": "1"}


def _scenario(request: Request, body: dict[str, Any] | None = None) -> str:
    header = request.headers.get("x-scenario", "")
    if header:
        return header
    model = (body or {}).get("model") or ""
    if model.startswith("scenario-"):
        return model.removeprefix("scenario-")
    return ""


FAILS = {"n": 0}


@app.post("/v1/responses")
@app.post("/responses")
async def responses(request: Request) -> Any:
    body = await request.json()
    item = _record(request.url.path, body, dict(request.headers))
    scenario = _scenario(request, body)
    if scenario == "fail-2":
        FAILS["n"] += 1
        if FAILS["n"] <= 2:
            return JSONResponse(status_code=503, content={"error": {"message": "temporary"}})
    if scenario == "fail-always":
        return JSONResponse(status_code=503, content={"error": {"message": "down"}})
    if scenario == "empty-text":
        return {
            "status": "incomplete",
            "incomplete_details": {"reason": "max_output_tokens"},
            "output_text": "",
            "output": [{"type": "message", "content": [{"type": "output_text", "text": ""}]}],
            "usage": {"input_tokens": 3, "output_tokens": 8},
        }
    if scenario == "status-400":
        return JSONResponse(status_code=400, content={"error": {"message": "bad schema"}})
    if scenario == "status-401":
        return JSONResponse(status_code=401, content={"error": {"message": "bad key"}})
    if scenario == "status-500":
        return JSONResponse(status_code=500, content={"error": {"message": "upstream down"}})
    if scenario == "invalid-json-body":
        return JSONResponse(
            {
                "status": "completed",
                "output_text": "not-json",
                "output": [{"type": "message", "content": [{"type": "output_text", "text": "not-json"}]}],
                "usage": {"input_tokens": 3, "output_tokens": 1},
            }
        )
    if body.get("stream"):
        async def events():
            if scenario == "drop-after-delta":
                yield 'data: {"type":"response.output_text.delta","delta":"hello"}\n\n'
                return
            if scenario == "heartbeat-then-text":
                yield "event: ping\ndata: {}\n\n"
                yield 'data: {"type":"response.output_text.delta","delta":""}\n\n'
                yield 'data: {"type":"response.output_text.delta","delta":"pong"}\n\n'
                yield 'data: {"type":"response.completed","response":{"usage":{"input_tokens":4,"output_tokens":1},"status":"completed"}}\n\n'
                return
            if scenario == "error-after-delta":
                yield 'data: {"type":"response.output_text.delta","delta":"hello"}\n\n'
                yield 'data: {"type":"error","error":"boom"}\n\n'
                return
            yield 'data: {"type":"response.output_text.delta","delta":"po"}\n\n'
            yield 'data: {"type":"response.output_text.delta","delta":"ng"}\n\n'
            yield 'data: {"type":"response.completed","response":{"usage":{"input_tokens":4,"output_tokens":2},"status":"completed"}}\n\n'
        return StreamingResponse(events(), media_type="text/event-stream")
    return {
        "status": "completed",
        "output_text": '{"word":"pong"}' if item["has_text_format"] else "pong",
        "output": [
            {
                "type": "message",
                "content": [
                    {
                        "type": "output_text",
                        "text": '{"word":"pong"}' if item["has_text_format"] else "pong",
                    }
                ],
            }
        ],
        "usage": {"input_tokens": 4, "output_tokens": 2, "input_tokens_details": {"cached_tokens": 0}},
    }


@app.post("/v1/messages")
async def messages(request: Request) -> Any:
    body = await request.json()
    item = _record(request.url.path, body, dict(request.headers))
    scenario = _scenario(request, body)
    if scenario == "fail-always":
        return JSONResponse(status_code=503, content={"error": {"message": "down"}})
    if scenario == "fail-2":
        FAILS["n"] += 1
        if FAILS["n"] <= 2:
            return JSONResponse(status_code=503, content={"error": {"message": "temporary"}})
    if scenario == "status-400":
        return JSONResponse(
            status_code=400,
            content={"error": {"type": "invalid_request_error", "message": "tool_choice rejected"}},
        )
    if scenario == "status-401":
        return JSONResponse(status_code=401, content={"error": {"message": "bad key"}})
    if scenario == "status-500":
        return JSONResponse(status_code=500, content={"error": {"message": "upstream down"}})
    if body.get("stream"):
        async def events():
            if scenario == "drop-after-delta":
                yield 'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"hello"}}\n\n'
                return
            if scenario == "error-event":
                yield 'data: {"type":"error","error":{"message":"stream failed"}}\n\n'
                return
            yield 'data: {"type":"message_start","message":{"usage":{"input_tokens":5,"output_tokens":0}}}\n\n'
            yield 'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"po"}}\n\n'
            yield 'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"ng"}}\n\n'
            yield 'data: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":2}}\n\n'
        return StreamingResponse(events(), media_type="text/event-stream")
    if item["has_tools"]:
        return {
            "content": [{"type": "tool_use", "name": "structured_output", "input": {"word": "pong"}}],
            "stop_reason": "tool_use",
            "usage": {"input_tokens": 6, "output_tokens": 3, "cache_read_input_tokens": 0},
        }
    return {
        "content": [{"type": "text", "text": "pong"}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 5, "output_tokens": 2, "cache_read_input_tokens": 1},
    }
