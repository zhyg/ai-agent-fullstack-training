# 统一 LLM API 网关设计说明

适用代码：`W1/`（阶段 1 已落地）。技术栈 Python 3.11+、FastAPI、httpx、pydantic v2。本文只记设计取舍和实现约定，功能清单见 README。

---

## 1. 边界

网关负责协议转换、调用编排和横切治理，不承担计费、内容审核和 Agent 编排。

默认实现是单进程内存存储，多副本部署时限流和计数需要换成 Redis 之类的共享存储，端口不变，见 7.4。

---

## 2. 程序结构

```
api ──▶ application ──▶ domain ◀── infrastructure
```

| 层 | 目录 | 职责 | 边界 |
| --- | --- | --- | --- |
| 接入 | `app/api/` | 参数校验、鉴权、路由、SSE 输出、错误转响应 | 不编排业务，不直接调上游 |
| 应用 | `app/application/` | 模板渲染 → 限流 → 重试调用 → 归一化 → 记指标 | 不 import FastAPI、httpx、pydantic |
| 领域 | `app/domain/` | 数据模型、端口协议、错误码、重试策略、脱敏规则 | 不依赖任何框架 |
| 基础设施 | `app/infrastructure/` | 适配器、配置、日志、内存存储、鉴权 | 不反向依赖 application |

组合根是 `main.py` + `container.py`：`main.py` 读配置、装日志、挂中间件和路由；`container.py` 把各类实现装进 `Container`，路由通过依赖取出，`app.state.container` 是唯一全局句柄。

端口与实现的对应：

| 端口 | 实现 |
| --- | --- |
| `LLMProvider` | `adapters/openai_responses.py`、`adapters/anthropic_messages.py`、`adapters/mock.py` |
| `ProviderRegistry` | `adapters/registry.py` |
| `PromptRepository` | `repo_memory.py` |
| `MetricsRecorder` | `metrics.py` |
| `RateLimiter` | `ratelimit_memory.py` |
| `Redactor` | `domain/redaction.py`（纯逻辑，直接注入） |

常见改动落在哪：加模型改 `Settings.model_routes()`；加协议写一个适配器并在 `registry.py` 注册；换存储替换 `container.py` 里的实例。三种情况都不动 `application`。

判断是否越层看 import：`application` 只引 `domain` 和自身，例外是 `infrastructure.logging.log_event`（纯 stdlib 的日志助手）；`domain` 只引标准库；`infrastructure` 可引 `domain`；`api` 可引 `application`、`domain`。除这个例外，出现反向 import 就是边界破了。

## 3. 全局约定

- `request_id` 沿用入站 `X-Request-Id` 或新生成，写入 contextvar，日志、错误响应、调用记录共用。
- 对外错误统一为 `{code, message, provider, retryable, details, request_id}`，内部保留原始异常。
- 脱敏只作用于日志、错误响应和查询接口，发往上游的正文不动。
- 密钥用 `SecretStr`，只从环境变量或 `config.py` 读，配置对象不整体打印。
- mock / live 是运行时状态：`AdapterRegistry` 按当前模式懒加载并分别缓存适配器，切换只改模式，不重建容器。live 需要两边的上游密钥，缺失时切换返回 400。
- 上游地址、密钥与模型名可在运行时通过 `POST /v1/runtime/upstream` 覆盖，只写入进程内存的 `Settings`；变更会刷新路由表并关闭、重建 live 适配器，Key 不回显、不落日志，重启回到环境变量或 `config.py` 的值。

---

## 4. 总体架构

```
┌──────────────────────────────────────────────────────────────────────────┐
│ 接入层  api/                                                             │
│  middleware: request_id → 体积限制 → 访问日志                            │
│  routes: /v1/invoke | /v1/prompts | /v1/metrics | /v1/logs | /v1/runtime     │
│  deps: 入站鉴权（API Key）                                                │
│  error_handlers: GatewayError → 统一错误体（出站脱敏）                    │
├──────────────────────────────────────────────────────────────────────────┤
│ 应用层  application/                                                     │
│  InvocationService: 模板渲染 → 限流 → 重试调用 → 归一化 → 指标/日志      │
│  PromptService / OutputNormalizer / RetryExecutor                        │
├──────────────────────────────────────────────────────────────────────────┤
│ 领域层  domain/                                                          │
│  models: ModelRoute / ProviderRequest / Usage / ProviderResult           │
│  ports (Protocol): LLMProvider / ProviderRegistry / PromptRepository /   │
│                    RateLimiter / MetricsRecorder / Redactor              │
│  retry: RetryPolicy（纯策略，可单测）                                     │
├──────────────────────────────────────────────────────────────────────────┤
│ 基础设施层  infrastructure/                                              │
│  adapters: openai_responses | anthropic_messages | mock                  │
│  repo_memory / metrics / ratelimit_memory / auth / logging / config      │
└──────────────────────────────────────────────────────────────────────────┘
```

### 4.1 目录结构

```
W1/
├── app/
│   ├── main.py                    # 入口：读取配置、装日志、挂路由与中间件、lifespan
│   ├── container.py               # 组装所有实现并注入
│   ├── static/console.html        # 浏览器控制台，GET /console 直接返回
│   ├── api/
│   │   ├── routes_invoke.py       # POST /v1/invoke（JSON / SSE 分发）
│   │   ├── routes_prompts.py      # 模板 CRUD
│   │   ├── routes_metrics.py      # JSON 指标与调用日志查询
│   │   ├── routes_runtime.py      # mock / live 运行时切换
│   │   ├── middleware.py          # request_id、访问日志、体积限制
│   │   ├── deps.py                # 容器获取 + API Key 依赖
│   │   ├── error_handlers.py      # 统一异常 → 错误体（出站脱敏）
│   │   └── schemas.py             # 对外请求模型，映射为应用层命令
│   ├── application/
│   │   ├── dto.py                 # 命令对象
│   │   ├── invocation_service.py  # 编排
│   │   ├── prompt_service.py
│   │   ├── output_normalizer.py   # JSON 解析 + schema 校验
│   │   └── resilience.py          # 重试执行器，包裹 Provider 调用
│   ├── domain/
│   │   ├── models.py              # ModelRoute / Usage / ProviderRequest
│   │   ├── ports.py               # 所有 Protocol 端口
│   │   ├── errors.py              # ErrorCode + GatewayError / UpstreamError
│   │   ├── retry.py               # RetryPolicy（纯策略：是否重试、退避时长）
│   │   └── redaction.py           # 脱敏规则与策略（纯函数）
│   └── infrastructure/
│       ├── config.py              # pydantic-settings，SecretStr，启动校验
│       ├── logging.py             # JSON Formatter + contextvars + RedactionFilter
│       ├── auth.py                # 入站 API Key 校验
│       ├── adapters/
│       │   ├── registry.py
│       │   ├── openai_responses.py
│       │   ├── anthropic_messages.py
│       │   └── mock.py
│       ├── repo_memory.py         # PromptRepository 内存实现
│       ├── metrics.py             # MetricsRecorder 内存实现
│       └── ratelimit_memory.py    # 单进程滑动窗口
├── tests/
│   ├── unit/                      # retry / redaction / normalizer / auth
│   └── integration/               # TestClient 接口与日志脱敏断言
├── scripts/verify.py              # 端到端验证
└── docs/architecture.md
```

---

## 5. 请求处理链路

### 5.1 非流式

```
Client
  → Middleware(request_id, 体积限制, 访问日志)
  → 路由依赖 require_api_key（可选，401 在此抛出）
  → InvocationService.invoke(dto)
      → PromptService.render()（若引用模板）
      → RateLimiter.acquire(model)              # 429 在此抛出
      → RetryExecutor.run(provider.complete)    # 退避重试
          → Adapter: 协议映射 → 鉴权头 → HTTP → 归一化
      → OutputNormalizer（JSON 解析 + schema 校验）
      → MetricsRecorder.record(...)
      → log_event("invocation.finished", ...)   # 经脱敏 Filter
  → 统一响应 / 统一错误体
```

### 5.2 流式

- `prepare_stream()` 在返回 `StreamingResponse` 之前完成校验、路由、模板渲染、限流，保证这些错误以正常 HTTP 状态码返回。
- 重试**只允许发生在首个 token 之前**；一旦输出 delta，后续失败只能以 `event: error` 结束，避免重复内容。
- 流结束统一发 `usage`（含 TTFT）与 `done`；指标与日志在生成器结束时记录。

---

## 6. 核心契约

```python
class LLMProvider(Protocol):
    protocol: str          # openai-responses / anthropic-messages / mock
    mode: str              # mock / live
    async def complete(self, request: ProviderRequest) -> ProviderResult: ...
    def stream(self, request: ProviderRequest) -> AsyncIterator[StreamChunk]: ...
    async def aclose(self) -> None: ...
```

`ProviderRequest` 是适配器能看到的唯一请求形态，两种上游的字段差异都在这里消化。`StreamChunk` 只带 `text`、`usage`、`finish_reason`，SSE 帧由应用层拼。

其余端口定义在 `domain/ports.py`：`ProviderRegistry.resolve/provider`、`PromptRepository`（增改查 + `render`）、`RateLimiter.acquire`、`MetricsRecorder.record/snapshot/logs`、`Redactor.text/prompt/mapping`。实现对应见第 2 节。

### 6.1 关键领域模型

| 模型 | 字段 |
| --- | --- |
| `ModelRoute` | `name`、`protocol`、`upstream_model`、`timeout_seconds`、`rate_limit_limit`、`rate_limit_window_seconds` |
| `ProviderRequest` | `request_id`、`route`、`messages`、`temperature`、`max_tokens`、`response_format`、`mock_controls` |
| `Usage` | `input_tokens`、`output_tokens`、`cached_tokens`，`total_tokens` 由前两者相加 |
| `ProviderResult` | `text`、`structured`、`usage`、`finish_reason` |

---

## 7. 弹性设计

### 7.1 错误分类

| 场景 | 错误码 | HTTP | retryable | 重试策略 |
| --- | --- | --- | --- | --- |
| 请求体/字段非法 | `invalid_request` | 400 | 否 | — |
| 模型未注册 | `unsupported_model` | 400 | 否 | — |
| 模板变量缺失 | `missing_variable` | 400 | 否 | — |
| 网关自身限流 | `rate_limited` | 429 | 否 | 客户端按 `Retry-After` 重试 |
| 上游 401/403 | `upstream_auth_error` | 502 | 否 | 不重试，告警 |
| 上游 429 / 5xx | `upstream_unavailable` | 502 | 是 | 指数退避；不读上游 `Retry-After` |
| 连接失败 / 读超时 | `upstream_timeout` / `upstream_unavailable` | 504/502 | 是 | 指数退避 |
| 上游返回非法 JSON | `upstream_invalid_json` | 502 | 否 | 不重试 |
| 重试耗尽 | `retry_exhausted` | 502 | 否 | 附带 `attempts`、`last_error` |
| 熔断打开（阶段 2） | `circuit_open` | 503 | 否 | 快速失败，带恢复时间 |

### 7.2 重试策略

```python
@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 3          # 含首次调用
    base_delay_ms: int = 200
    factor: float = 2.0
    max_delay_ms: int = 2000
    jitter: float = 0.2            # 在退避值上下浮动，避免同时重试

    def should_retry(self, error: UpstreamError, attempt: int) -> bool:
        return error.retryable and attempt < self.max_attempts

    def delay_ms(self, attempt: int, rng: random.Random | None = None) -> int: ...
```

规则：

- 只重试 `retryable=True` 的错误（连接失败、超时、上游 5xx/429）；其余 4xx 直接返回。
- 退避 `min(base * factor^(n-1), max)`，再乘抖动系数，上限 2 秒。
- 流式只在首个 token 前重试，重试时发 `event: retry`；已输出内容不回滚。
- 每次尝试写一条 `upstream.retry` 日志，最终指标里的 `retries` 为 `attempts - 1` 累加。
- LLM 补全无副作用，重试安全；若以后接有副作用的工具调用，需要在 `ProviderRequest` 加幂等键。

### 7.3 超时

连接和读超时分开：`HTTP_CONNECT_TIMEOUT_SECONDS`（默认 15 秒）管建连，`HTTP_TIMEOUT_SECONDS`（默认 60 秒）管读。网络不可达时每次尝试 15 秒内失败，配合 3 次重试约 48 秒返回 `retry_exhausted`，不会一直挂住。连接超时设为 15 秒是为了兼顾国内网络到境外/边缘节点的 TLS 握手抖动（5 秒在空闲连接复用失败后首建连偶发不够）。重试的等待时间不单独计预算；如果要限制整次请求的总耗时，需要在接入层加 deadline，目前没做。

### 7.4 限流

| 维度 | 键 | 默认 | 实现 |
| --- | --- | --- | --- |
| 按模型 | `model` | 20 次 / 60s | 滑动窗口（内存） |
| 按调用方 | `api_key_id + model` | — | 未实现 |
| 上游限流 | `model + provider` | 由上游决定 | 收到 429 后短暂熔断（阶段 2） |

- 超限返回 429 + `Retry-After`，不消耗重试次数。
- 多进程部署时限流需替换为 Redis 实现（Lua 保证原子性），端口保持不变。
- 熔断（阶段 2）按 `model + provider` 统计失败率，Open 期间直接返回 `503 circuit_open`，不复用重试与上游配额。

---

## 8. 日志与指标

### 8.1 日志分类

| 类型 | 内容 | 去向 |
| --- | --- | --- |
| 访问日志 | 每请求一行：`method`、`path`、`status`、`duration_ms`、`client_ip` | stdout(JSON) |
| 应用日志 | `invocation.finished`、`invocation.failed`、`upstream.retry`、启动停止 | stdout(JSON) |
| 调用记录 | 最近 200 条，含 usage、延迟、attempts，供 `/v1/logs` 查询 | 进程内存 |

只有 stdout 一个 `StreamHandler`，一行一个 JSON（`ensure_ascii=False`）。`/health` 不记访问日志；不做采样和聚合；`httpx`、`httpcore`、`uvicorn.access` 压到 WARNING 避免重复。文件轮转、审计文件和采集端配置都不在网关里，转储与保留交给部署环境。

### 8.2 结构化字段规范

```json
{
  "ts": "2026-11-16T12:00:00.123Z",
  "level": "INFO",
  "logger": "gateway",
  "event": "invocation.finished",
  "request_id": "req_2f6d9b0c",
  "model": "deepseek-v4-pro",
  "protocol": "openai-responses",
  "mode": "mock",
  "stream": false,
  "status": "ok",
  "attempts": 1,
  "latency_ms": 26.0,
  "ttft_ms": null,
  "usage": {"input_tokens": 21, "output_tokens": 58, "cached_tokens": 0, "total_tokens": 79},
  "metadata": {"case": "pro-basic"}
}
```

约定：

- `event` 用点分层级命名，日志检索和告警规则都按它匹配。
- token 与延迟字段在指标和日志中共用同一份 `InvocationMetric`，字段名固定。
- `invocation.failed` 追加 `error_code`、`retryable`、`provider_error`（上游原始错误码）。
- 引用模板时追加 `template.name/version` 和 `prompt_variables_hash`；模板变量只以 hash 出现。
- 提示词正文和模型输出不进 INFO 日志。

### 8.3 上下文传递

- 中间件生成 `request_id`（或沿用入站 `X-Request-Id`），写入 contextvar，并回写响应头 `X-Request-Id`。
- `JsonFormatter` 先取 `record` 上的字段，再取 contextvar；调用日志在 fields 里显式带 `request_id`，不依赖它是否能传到异步生成器。
- `trace_id` 的 contextvar 已预留，但没接链路追踪，日志里不会出现。

### 8.4 指标

`/v1/metrics` 返回进程内快照：

| 字段 | 内容 |
| --- | --- |
| `totals` | 累计 calls、errors、retries；input/output/cached/total token；延迟与 TTFT 的均值和最大值 |
| `models` | 按模型名分组的同一结构 |
| `recent_errors` | 最近 10 条失败调用 |
| `rate_limit` | 各模型当前窗口内的计数 |
| `started_at`、`uptime_seconds` | 进程启动时间和运行时长 |

延迟只有 avg 和 max，没有分位；计数在进程内存，重启归零，多 worker 之间不共享。Prometheus 文本输出和 `/metrics` 端点属阶段 2。

---

## 9. 脱敏设计

### 9.1 数据分类

| 类别 | 示例 | 默认策略 |
| --- | --- | --- |
| 凭据 | `Authorization: Bearer sk-...`、`x-api-key`、`sk-` 开头的 key | `mask`（留前 4 后 3） |
| PII - 手机号 | `13812345678` | `mask` → `138****5678` |
| PII - 邮箱 | `alice@example.com` | `mask` → `a***@example.com` |
| PII - 身份证 | 18 位身份证号 | `mask` → `110123********1234` |
| PII - 银行卡 | 16-19 位卡号 | `mask` → `**** **** **** 1234` |
| 提示词正文 | `messages[].content` | 不写日志；模板变量整体已 hash |
| 模型输出 | `output.text` | 不写日志；上游错误正文截断 300 字符后 `mask` |
| 自定义敏感字段 | `metadata.token`、业务单号 | 配置 `hash` / `drop` |

### 9.2 模式

`REDACTION_MODE` 取 `mixed`（默认）、`mask`、`hash`、`drop`、`off`。`mixed` 是普通文本打码、提示词正文和模板变量哈希；`mask` 全部打码；`hash` 全部 HMAC-SHA256；`drop` 整值替换为 `[redacted]`；`off` 原样输出，仅限本地调试。

`Redactor.text()` 处理普通字段，`prompt()` 处理提示词正文，两者对 `mixed` 的解释不同。`mapping()` 遇到键名含 `authorization`、`api_key`、`access_key`、`secret`、`token`、`password` 时按凭据处理，其余递归，嵌套超过 6 层截断。

### 9.3 执行点

1. **日志层**：`RedactionFilter` 挂在唯一的 stdout handler 上，处理 `record.msg`、`record.fields` 和异常堆栈。调用方误传敏感值也会被兜底。
2. **错误出站层**：`error_handlers` 返回客户端前处理上游 `message`，避免把上游密钥、内网地址带给调用方。
3. **查询接口**：`/v1/logs` 与 `/v1/metrics` 返回前对 `metadata` 再跑一遍 `mapping()`，不假设写入时已经干净。

发往上游的业务正文不脱敏，否则会改模型输入；上游密钥只放在请求头，不进入业务 payload。

### 9.4 规则实现

- 一组有序正则依次替换：凭据 → 身份证 → 银行卡 → 手机号 → 邮箱 → IP。长数字在前，避免银行卡被手机号规则截断；数字类规则前后加 `(?<!\d)` / `(?!\d)`。
- 自定义规则 `REDACTION_EXTRA_PATTERNS` 先执行，命中整体替换为 `[redacted]`，多条用 `||` 分隔。
- 已打码的文本再处理一次不会变，掩码引入的 `*` 不在任何规则的可匹配字符集里。
- `hash_text` 输出 `sha256:` 加前 16 位十六进制，盐来自 `REDACTION_HASH_SALT`，默认值只适合本地。
- 单测覆盖各类型样例、边界和幂等性；没做 1MB 性能基准，也没有字段级 allowlist。

---

## 10. 配置与密钥

- `pydantic-settings`，优先级环境变量 > `.env` > 默认值，字段用 `validation_alias` 绑定大写环境变量名（如 `GATEWAY_USE_MOCK`、`RETRY_MAX_ATTEMPTS`）。
- 启动即校验：`GATEWAY_AUTH_ENABLED=1` 必须配 `GATEWAY_API_KEYS`；关闭 Mock 必须有两个上游密钥；`RETRY_JITTER` 必须在 [0,1]；`REDACTION_MODE` 必须是已知枚举。
- 密钥字段是 `SecretStr`，只在构造适配器时取明文，日志和 `repr` 都看不到。
- 兼容项目根目录原有的 `config.py`：只按正则读 `key=...`，不 import 也不执行。
- 模型路由写死在 `Settings.model_routes()`：两个模型、协议、上游名、超时和限流额度都来自环境变量。新增模型需要改代码；YAML 配置和热加载属阶段 2。

---

## 11. 安全

| 风险 | 措施 | 状态 |
| --- | --- | --- |
| 匿名滥用 | 可选 API Key（`Authorization: Bearer` 或 `X-API-Key`），`hmac.compare_digest` 比较，失败 401 并返回 `request_id` | 已实现，默认关闭 |
| 密钥泄露 | `SecretStr` + 环境变量；日志、错误出站均脱敏 | 已实现 |
| 大请求 | `Content-Length` 超过 `MAX_REQUEST_BYTES`（默认 1MB）直接 413 | 已实现 |
| 慢请求 | 上游单层总超时 60s；并发上限未做 | 部分 |
| SSRF | `base_url` 白名单、私有网段拦截 | 未实现，靠部署网络策略 |
| 模板注入 | 变量用 `{{ name }}` 正则替换，不求值；变量长度未限制 | 部分 |
| 日志注入 | JSON 序列化，换行和控制字符被转义 | 已实现 |
| 跨域 | 默认不挂 CORS 中间件 | 默认关闭 |

`/docs` 和 `/v1/metrics` 没有单独的开关，需要时用反向代理拦截。

---

## 12. 测试

| 层级 | 覆盖 | 位置 |
| --- | --- | --- |
| 单元 | `RetryPolicy` 的次数/退避/参数校验、`Redactor` 各模式与幂等、`OutputNormalizer`、`ApiKeyAuthenticator` | `tests/unit/` |
| 集成 | TestClient 跑双协议、流式与重试事件、模板版本、限流 429、错误体、日志脱敏 | `tests/integration/` |
| 端到端 | `scripts/verify.py` 对真实进程断言 24 项 | 仓库根 |
| 未覆盖 | 适配器契约测试、压测、覆盖率门禁 | 阶段 2 |

本机运行曾遇到第三方 pytest 插件 DLL 被系统策略拦截，需要 `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`，命令见 README。

---

## 13. 运行

- `uvicorn app.main:app --port 8000`。多 worker 时各进程的限流和指标互不可见。
- 健康检查 `/health`，没有 `/ready`。浏览器打开 `/console` 使用控制台页面，静态文件由 `main.py` 用 `FileResponse` 返回。
- 控制台的「脱敏显示」是前端行为，只改页面文字；接口返回和发往上游的正文都不动，后端脱敏边界见 9.1。
- 停机走 lifespan，关闭 registry 里所有适配器的 `httpx.AsyncClient`。
- 容器侧建议非 root、只读根文件系统、SIGTERM 退出；这些是部署要求，代码里没有对应实现。

---

## 14. 范围与后续

### 阶段 1：分层、日志、脱敏（已完成）

1. 按 4.1 拆目录，行为不变（`verify.py` 24 项、pytest 41 项通过）。
2. `pydantic-settings` 配置、`SecretStr`、启动校验。
3. stdout JSON 日志、`request_id` contextvar、访问日志。
4. `Redactor` + 日志 Filter + 错误出站脱敏 + 查询接口二次脱敏。
5. `RetryPolicy` 抽成纯函数并补单测。
6. 可选入站 API Key 鉴权。

### 阶段 2

7. Prometheus `/metrics` 与看板。
8. 调用记录落盘（JSONL / SQLite）和审计日志。
9. 熔断、上游 429 感知、调用方维度限流。
10. 适配器契约测试。

### 阶段 3

11. Redis 限流、OpenTelemetry 链路追踪。
12. 模板持久化、模型配置热加载。

### 阶段 1 的文件迁移

| 迁移前 | 迁移后 |
| --- | --- |
| `app/main.py` | `api/routes_*.py` + `api/error_handlers.py` + `main.py`（只做组装） |
| `app/service.py` | `application/invocation_service.py` + `application/resilience.py` |
| `app/schemas.py` | `api/schemas.py` + `domain/models.py` |
| `app/prompts.py` | `application/prompt_service.py` + `infrastructure/repo_memory.py` |
| `app/metrics.py` | `infrastructure/metrics.py` |
| `app/ratelimit.py` | `infrastructure/ratelimit_memory.py` |
| `app/retry.py` | `domain/retry.py`（策略）+ `application/resilience.py`（执行） |
| `app/errors.py` | `domain/errors.py` |
| `app/settings.py` | `infrastructure/config.py` |
| `app/registry.py` + `app/adapters/*` | `infrastructure/adapters/*` |
| — | `infrastructure/logging.py`、`domain/redaction.py`、`api/middleware.py` |

---

## 15. 取舍

| 取舍 | 原因 |
| --- | --- |
| 内存存储 | 换实现成本低，单机开箱即用；多副本要换 Redis/SQLite |
| 结构化输出靠 prompt 或工具约束 | 上游不保证合法 JSON，网关只做解析和 schema 校验，失败返回明确错误码，不静默修复 |
| 流式只在首 token 前重试 | 已输出内容无法回滚，宁可报错也不重复输出 |
| 不记正文 | 牺牲部分排障便利换合规，需要时临时调高日志级别 |
| 正则脱敏 | 覆盖常见格式，不能替代上游的数据分级，缺口靠自定义规则补 |
