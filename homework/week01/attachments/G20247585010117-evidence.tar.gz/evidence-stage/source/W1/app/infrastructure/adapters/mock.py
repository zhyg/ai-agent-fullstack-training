"""内置 Mock 上游：无需真实密钥即可验证全部网关能力。

支持通过请求头注入：
- X-Mock-Fail-Times: 前 N 次调用失败（503，可重试），用于验证退避重试
- X-Mock-Total-Ms / X-Mock-Ttft-Ms / X-Mock-Chunk-Delay-Ms: 控制延迟
- X-Mock-Cached-Tokens: 指定 cached token 数
"""

from __future__ import annotations

import asyncio
import json
import math
from collections import defaultdict
from typing import Any, AsyncIterator

from app.domain.errors import ErrorCode, UpstreamError
from app.domain.models import ProviderRequest, ProviderResult, StreamChunk, Usage
from app.infrastructure.config import Settings


def _estimate_tokens(text: str) -> int:
    return max(1, math.ceil(len(text) / 4))


def _gen_from_schema(schema: dict[str, Any]) -> Any:
    if not isinstance(schema, dict):
        return "mock"
    if schema.get("examples"):
        return schema["examples"][0]
    if "default" in schema:
        return schema["default"]
    if schema.get("enum"):
        return schema["enum"][0]

    schema_type = schema.get("type")
    if schema_type == "object" or "properties" in schema:
        return {
            key: _gen_from_schema(value)
            for key, value in (schema.get("properties") or {}).items()
        }
    if schema_type == "array":
        return [_gen_from_schema(schema.get("items") or {"type": "string"})]
    if schema_type == "integer":
        return 1
    if schema_type == "number":
        return 1.5
    if schema_type == "boolean":
        return True
    if schema_type == "null":
        return None
    return "mock"


class MockAdapter:
    mode = "mock"

    def __init__(self, settings: Settings, protocol: str) -> None:
        self.settings = settings
        self.protocol = protocol
        self._call_counts: dict[str, int] = defaultdict(int)

    # ---- 故障注入 ----
    def _fail_times(self, request: ProviderRequest) -> int:
        try:
            return max(0, int(request.mock_controls.get("fail_times", 0)))
        except (TypeError, ValueError):
            return 0

    def _gate(self, request: ProviderRequest) -> None:
        self._call_counts[request.request_id] += 1
        call_index = self._call_counts[request.request_id]
        if call_index <= self._fail_times(request):
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"mock 上游注入临时故障（第 {call_index} 次调用）",
                status_code=503,
                provider=self.protocol,
                retryable=True,
                details={"injected": True, "call_index": call_index},
            )

    def _generate(self, request: ProviderRequest) -> tuple[str, dict[str, Any] | None]:
        response_format = request.response_format or {}
        if response_format.get("type") == "json_object":
            data = _gen_from_schema(response_format.get("schema") or {})
            if isinstance(data, str):
                data = {"result": data}
            return json.dumps(data, ensure_ascii=False), data

        last_user = ""
        for message in reversed(request.messages):
            if message.get("role") == "user":
                last_user = message.get("content", "")
                break
        system_text = "".join(
            message.get("content", "")
            for message in request.messages
            if message.get("role") == "system"
        )
        reply = f"【mock/{self.protocol}】已收到 {len(request.messages)} 条消息。"
        if system_text:
            reply += f"系统提示：{system_text[:120]}。"
        reply += (
            f"最后一条用户输入：{last_user[:80]}。"
            f"这是 {request.route.name} 的模拟回复，用于验证统一抽象层、流式输出与可观测性。"
        )
        return reply, None

    def _usage(self, request: ProviderRequest, text: str) -> Usage:
        input_text = "".join(message.get("content", "") for message in request.messages)
        if request.response_format:
            input_text += json.dumps(
                request.response_format.get("schema") or {}, ensure_ascii=False
            )
        input_tokens = _estimate_tokens(input_text)
        output_tokens = _estimate_tokens(text)
        try:
            cached = int(request.mock_controls.get("cached_tokens", 0))
        except (TypeError, ValueError):
            cached = 0
        return Usage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_tokens=max(0, min(cached, input_tokens)),
        )

    @staticmethod
    def _int_control(request: ProviderRequest, key: str, default: int) -> int:
        try:
            return max(0, int(request.mock_controls.get(key, default)))
        except (TypeError, ValueError):
            return default

    async def complete(self, request: ProviderRequest) -> ProviderResult:
        self._gate(request)
        await asyncio.sleep(self._int_control(request, "total_ms", 20) / 1000)
        text, structured = self._generate(request)
        return ProviderResult(
            text=text,
            usage=self._usage(request, text),
            finish_reason="stop",
            structured=structured,
        )

    async def stream(self, request: ProviderRequest) -> AsyncIterator[StreamChunk]:
        self._gate(request)
        await asyncio.sleep(self._int_control(request, "ttft_ms", 15) / 1000)
        text, _ = self._generate(request)
        chunk_delay = self._int_control(request, "chunk_delay_ms", 10) / 1000
        step = 8
        for index in range(0, len(text), step):
            yield StreamChunk(text=text[index : index + step])
            await asyncio.sleep(chunk_delay)
        yield StreamChunk(usage=self._usage(request, text), finish_reason="stop")

    async def aclose(self) -> None:
        return None
