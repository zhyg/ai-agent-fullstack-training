"""输出归一化：JSON 解析 + JSON Schema 严格校验。"""

from __future__ import annotations

import json
from typing import Any

import jsonschema

from app.application.dto import ResponseFormatCommand
from app.domain.errors import ErrorCode, GatewayError
from app.domain.models import ProviderResult


class OutputNormalizer:
    def normalize(
        self,
        response_format: ResponseFormatCommand | None,
        result: ProviderResult,
    ) -> tuple[str, dict[str, Any] | None]:
        text = result.text
        structured = result.structured
        if response_format is None or response_format.type != "json_object":
            return text, structured

        if structured is None:
            try:
                parsed = json.loads(text)
            except ValueError as exc:
                raise GatewayError(
                    ErrorCode.UPSTREAM_INVALID_JSON,
                    "上游返回内容不是合法 JSON",
                    status_code=502,
                    details={"preview": text[:200]},
                ) from exc
            if not isinstance(parsed, dict):
                raise GatewayError(
                    ErrorCode.UPSTREAM_INVALID_JSON,
                    "结构化输出必须是 JSON 对象",
                    status_code=502,
                    details={"preview": text[:200]},
                )
            structured = parsed

        if response_format.strict and response_format.schema:
            try:
                jsonschema.validate(instance=structured, schema=response_format.schema)
            except jsonschema.ValidationError as exc:
                raise GatewayError(
                    ErrorCode.UPSTREAM_INVALID_JSON,
                    f"上游 JSON 不符合 schema: {exc.message}",
                    status_code=502,
                    details={"path": list(exc.absolute_path)},
                ) from exc

        return json.dumps(structured, ensure_ascii=False), structured
