"""运行时开关：查看与切换 mock / live 上游。"""

from __future__ import annotations

import logging
from typing import Any, Literal

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field, SecretStr, field_validator

from app.api.deps import get_container, require_api_key
from app.infrastructure.config import Settings

router = APIRouter(prefix="/v1/runtime", dependencies=[Depends(require_api_key)])
logger = logging.getLogger("gateway.runtime")


class ModeUpdate(BaseModel):
    mode: Literal["mock", "live"]


class UpstreamUpdate(BaseModel):
    openai_base_url: str | None = None
    anthropic_base_url: str | None = None
    openai_api_key: str | None = Field(default=None, min_length=1)
    anthropic_api_key: str | None = Field(default=None, min_length=1)
    pro_model: str | None = Field(default=None, min_length=1)
    flash_model: str | None = Field(default=None, min_length=1)

    @field_validator("openai_base_url", "anthropic_base_url")
    @classmethod
    def _check_base_url(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        normalized = value.strip().rstrip("/")
        if not normalized.startswith(("http://", "https://")):
            raise ValueError("上游地址必须以 http:// 或 https:// 开头")
        return normalized


def _keys_configured(settings: Settings) -> dict[str, bool]:
    return {
        "openai": bool(settings.openai_key()),
        "anthropic": bool(settings.anthropic_key()),
    }


def _base_urls(settings: Settings) -> dict[str, str]:
    return {
        "openai": settings.openai_base_url,
        "anthropic": settings.anthropic_base_url,
    }


def _models(settings: Settings) -> dict[str, str]:
    return {
        "pro": settings.pro_upstream_model,
        "flash": settings.flash_upstream_model,
    }


@router.get("")
async def get_runtime(request: Request) -> dict[str, Any]:
    container = get_container(request)
    return {
        "mode": container.registry.mode,
        "default_mode": "mock" if container.settings.use_mock else "live",
        "live_configured": container.registry.live_configured,
        "keys_configured": _keys_configured(container.settings),
        "base_urls": _base_urls(container.settings),
        "models": _models(container.settings),
    }


@router.post("/mode")
async def update_mode(payload: ModeUpdate, request: Request) -> dict[str, Any]:
    container = get_container(request)
    previous = container.registry.mode
    container.registry.set_mode(payload.mode)
    if previous != payload.mode:
        logger.info(
            "runtime.mode_changed",
            extra={
                "event": "runtime.mode_changed",
                "fields": {"from": previous, "to": payload.mode},
            },
        )
    return {"mode": container.registry.mode}


@router.post("/upstream")
async def update_upstream(payload: UpstreamUpdate, request: Request) -> dict[str, Any]:
    container = get_container(request)
    settings = container.settings
    updated: list[str] = []
    if payload.openai_base_url:
        settings.openai_base_url = payload.openai_base_url
        updated.append("openai_base_url")
    if payload.anthropic_base_url:
        settings.anthropic_base_url = payload.anthropic_base_url
        updated.append("anthropic_base_url")
    if payload.openai_api_key:
        settings.openai_api_key = SecretStr(payload.openai_api_key)
        updated.append("openai_api_key")
    if payload.anthropic_api_key:
        settings.anthropic_api_key = SecretStr(payload.anthropic_api_key)
        updated.append("anthropic_api_key")
    if payload.pro_model:
        settings.pro_upstream_model = payload.pro_model
        updated.append("pro_model")
    if payload.flash_model:
        settings.flash_upstream_model = payload.flash_model
        updated.append("flash_model")
    if updated:
        container.registry.refresh_routes()
        await container.registry.reset_live()
        logger.info(
            "runtime.upstream_updated",
            extra={
                "event": "runtime.upstream_updated",
                "fields": {"changed": updated},
            },
        )
    return {
        "updated": updated,
        "keys_configured": _keys_configured(settings),
        "base_urls": _base_urls(settings),
        "models": _models(settings),
        "live_configured": container.registry.live_configured,
    }
