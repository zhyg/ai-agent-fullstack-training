"""应用层编排：路由 → 模板 → 限流 → 重试调用 → 归一化 → 指标与日志。"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator
from typing import Any

from app.application.dto import InvocationCommand
from app.application.output_normalizer import OutputNormalizer
from app.application.prompt_service import PromptService
from app.application.resilience import RetryExecutor
from app.domain.errors import ErrorCode, GatewayError, UpstreamError
from app.domain.models import (
    InvocationMetric,
    ModelRoute,
    ProviderRequest,
    ProviderResult,
    Usage,
)
from app.domain.ports import LLMProvider, MetricsRecorder, ProviderRegistry, RateLimiter, Redactor
from app.infrastructure.logging import log_event


def sse_frame(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


class InvocationService:
    def __init__(
        self,
        registry: ProviderRegistry,
        prompts: PromptService,
        normalizer: OutputNormalizer,
        metrics: MetricsRecorder,
        limiter: RateLimiter,
        retry: RetryExecutor,
        redactor: Redactor,
        logger: logging.Logger,
    ) -> None:
        self._registry = registry
        self._prompts = prompts
        self._normalizer = normalizer
        self._metrics = metrics
        self._limiter = limiter
        self._retry = retry
        self._redactor = redactor
        self._logger = logger

    # ---------- 非流式 ----------
    async def invoke(
        self,
        command: InvocationCommand,
        request_id: str,
        controls: dict[str, Any],
        client_key_id: str | None = None,
    ) -> dict[str, Any]:
        route = self._registry.resolve(command.model)
        provider = self._registry.provider(route)
        messages = self._render_messages(command)
        self._limiter.acquire(route.name)
        provider_request = self._build_request(command, route, messages, request_id, controls)

        started = time.perf_counter()
        attempts = 1
        try:
            result, attempts = await self._retry.run(
                lambda: provider.complete(provider_request),
                on_retry=lambda attempt, error, delay_ms: self._log_retry(
                    request_id, route, attempt, error, delay_ms
                ),
            )
            total_ms = round((time.perf_counter() - started) * 1000, 2)
            text, structured = self._normalizer.normalize(command.response_format, result)
        except UpstreamError as exc:
            total_ms = round((time.perf_counter() - started) * 1000, 2)
            error = self._finalize_error(exc)
            self._record(
                request_id=request_id,
                route=route,
                provider=provider,
                command=command,
                ok=False,
                error_code=error.code,
                usage={},
                total_ms=total_ms,
                ttft_ms=None,
                attempts=exc.attempts,
            )
            self._log_failed(
                request_id, route, provider, command, error, exc.attempts, total_ms, client_key_id
            )
            raise error
        except GatewayError as exc:
            total_ms = round((time.perf_counter() - started) * 1000, 2)
            self._record(
                request_id=request_id,
                route=route,
                provider=provider,
                command=command,
                ok=False,
                error_code=exc.code,
                usage={},
                total_ms=total_ms,
                ttft_ms=None,
                attempts=attempts,
            )
            self._log_failed(
                request_id, route, provider, command, exc, attempts, total_ms, client_key_id
            )
            raise

        self._record(
            request_id=request_id,
            route=route,
            provider=provider,
            command=command,
            ok=True,
            error_code=None,
            usage=result.usage.as_dict(),
            total_ms=total_ms,
            ttft_ms=None,
            attempts=attempts,
        )
        self._log_finished(
            request_id,
            route,
            provider,
            command,
            result.usage,
            total_ms,
            attempts,
            client_key_id,
        )
        return {
            "id": request_id,
            "object": "gateway.response",
            "created": int(time.time()),
            "model": command.model,
            "provider": route.protocol,
            "mode": provider.mode,
            "output": {"text": text, "json": structured},
            "usage": result.usage.as_dict(),
            "latency": {"total_ms": total_ms, "ttft_ms": None},
            "attempts": attempts,
            "finish_reason": result.finish_reason,
        }

    # ---------- 流式 ----------
    def prepare_stream(
        self,
        command: InvocationCommand,
        request_id: str,
        controls: dict[str, Any],
        client_key_id: str | None = None,
    ) -> AsyncIterator[str]:
        """返回生成器之前完成校验/路由/模板/限流，保证错误可返回正常 HTTP 状态码。"""
        route = self._registry.resolve(command.model)
        provider = self._registry.provider(route)
        messages = self._render_messages(command)
        self._limiter.acquire(route.name)
        provider_request = self._build_request(command, route, messages, request_id, controls)
        return self._stream_events(
            command, route, provider, provider_request, request_id, client_key_id
        )

    async def _stream_events(
        self,
        command: InvocationCommand,
        route: ModelRoute,
        provider: LLMProvider,
        provider_request: ProviderRequest,
        request_id: str,
        client_key_id: str | None,
    ) -> AsyncIterator[str]:
        started = time.perf_counter()
        yield sse_frame(
            "start",
            {
                "id": request_id,
                "object": "gateway.stream.start",
                "created": int(time.time()),
                "model": command.model,
                "provider": route.protocol,
                "mode": provider.mode,
            },
        )

        usage = Usage()
        finish_reason = "stop"
        parts: list[str] = []
        ttft_ms: float | None = None
        attempts = 0
        error: GatewayError | None = None

        for attempt in range(1, self._retry.policy.max_attempts + 1):
            attempts = attempt
            try:
                async for chunk in provider.stream(provider_request):
                    if chunk.text:
                        if ttft_ms is None:
                            ttft_ms = round((time.perf_counter() - started) * 1000, 2)
                        parts.append(chunk.text)
                        yield sse_frame("delta", {"text": chunk.text})
                    if chunk.usage is not None:
                        usage = chunk.usage
                    if chunk.finish_reason:
                        finish_reason = chunk.finish_reason
                error = None
                break
            except UpstreamError as exc:
                exc.attempts = attempt
                can_retry = (
                    self._retry.policy.should_retry(exc, attempt) and ttft_ms is None
                )
                if not can_retry:
                    error = self._finalize_error(exc)
                    break
                delay_ms = self._retry.policy.delay_ms(attempt)
                self._log_retry(request_id, route, attempt, exc, delay_ms)
                await asyncio.sleep(delay_ms / 1000)
                yield sse_frame(
                    "retry",
                    {"attempt": attempt, "code": exc.code, "delay_ms": delay_ms},
                )

        total_ms = round((time.perf_counter() - started) * 1000, 2)
        text = "".join(parts)

        if error is None:
            try:
                text, _ = self._normalizer.normalize(
                    command.response_format,
                    ProviderResult(
                        text=text,
                        usage=usage,
                        finish_reason=finish_reason,
                    ),
                )
            except GatewayError as exc:
                error = exc

        if error is not None:
            self._record(
                request_id=request_id,
                route=route,
                provider=provider,
                command=command,
                ok=False,
                error_code=error.code,
                usage=usage.as_dict(),
                total_ms=total_ms,
                ttft_ms=ttft_ms,
                attempts=attempts,
            )
            self._log_failed(
                request_id, route, provider, command, error, attempts, total_ms, client_key_id
            )
            yield sse_frame("error", error.payload(request_id))
            return

        self._record(
            request_id=request_id,
            route=route,
            provider=provider,
            command=command,
            ok=True,
            error_code=None,
            usage=usage.as_dict(),
            total_ms=total_ms,
            ttft_ms=ttft_ms,
            attempts=attempts,
        )
        self._log_finished(
            request_id, route, provider, command, usage, total_ms, attempts, client_key_id, ttft_ms
        )
        yield sse_frame(
            "usage",
            {
                "usage": usage.as_dict(),
                "latency": {"total_ms": total_ms, "ttft_ms": ttft_ms},
            },
        )
        yield sse_frame(
            "done",
            {
                "finish_reason": finish_reason,
                "attempts": attempts,
                "text_length": len(text),
            },
        )

    # ---------- 内部 ----------
    def _render_messages(self, command: InvocationCommand) -> list[dict[str, str]]:
        messages = [dict(message) for message in command.messages]
        if command.prompt is not None:
            rendered = self._prompts.render(
                command.prompt.name,
                command.prompt.version,
                command.prompt.variables,
            )
            messages.insert(0, {"role": "system", "content": rendered})
        return messages

    def _build_request(
        self,
        command: InvocationCommand,
        route: ModelRoute,
        messages: list[dict[str, str]],
        request_id: str,
        controls: dict[str, Any],
    ) -> ProviderRequest:
        response_format: dict[str, Any] | None = None
        if command.response_format is not None and command.response_format.type == "json_object":
            response_format = {
                "type": "json_object",
                "schema": command.response_format.schema,
                "strict": command.response_format.strict,
            }
        return ProviderRequest(
            request_id=request_id,
            route=route,
            messages=messages,
            temperature=command.temperature,
            max_tokens=command.max_tokens,
            response_format=response_format,
            mock_controls=controls,
        )

    def _finalize_error(self, exc: UpstreamError) -> GatewayError:
        if exc.retryable and exc.attempts >= self._retry.policy.max_attempts:
            return GatewayError(
                ErrorCode.RETRY_EXHAUSTED,
                f"上游在 {exc.attempts} 次尝试后仍失败：{exc.message}",
                status_code=502,
                provider=exc.provider,
                retryable=False,
                details={**exc.details, "attempts": exc.attempts, "last_error": exc.code},
            )
        return exc

    def _record(
        self,
        *,
        request_id: str,
        route: ModelRoute,
        provider: LLMProvider,
        command: InvocationCommand,
        ok: bool,
        error_code: str | None,
        usage: dict[str, int],
        total_ms: float,
        ttft_ms: float | None,
        attempts: int,
    ) -> None:
        self._metrics.record(
            InvocationMetric(
                request_id=request_id,
                trace_id=None,
                model=route.name,
                protocol=route.protocol,
                mode=provider.mode,
                stream=command.stream,
                ok=ok,
                error_code=error_code,
                usage=usage,
                total_ms=total_ms,
                ttft_ms=ttft_ms,
                attempts=attempts,
                metadata=command.metadata,
            )
        )

    def _base_fields(
        self,
        request_id: str,
        route: ModelRoute,
        provider: LLMProvider,
        command: InvocationCommand,
        client_key_id: str | None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {
            "request_id": request_id,
            "model": route.name,
            "protocol": route.protocol,
            "mode": provider.mode,
            "stream": command.stream,
        }
        if client_key_id:
            fields["client_api_key_id"] = client_key_id
        if command.prompt is not None:
            fields["template"] = {
                "name": command.prompt.name,
                "version": command.prompt.version,
            }
            if command.prompt.variables:
                fields["prompt_variables_hash"] = self._redactor.prompt(
                    json.dumps(command.prompt.variables, ensure_ascii=False, sort_keys=True)
                )
        return fields

    def _log_finished(
        self,
        request_id: str,
        route: ModelRoute,
        provider: LLMProvider,
        command: InvocationCommand,
        usage: Usage,
        total_ms: float,
        attempts: int,
        client_key_id: str | None,
        ttft_ms: float | None = None,
    ) -> None:
        fields = self._base_fields(request_id, route, provider, command, client_key_id)
        fields.update(
            {
                "status": "ok",
                "attempts": attempts,
                "latency_ms": total_ms,
                "ttft_ms": ttft_ms,
                "usage": usage.as_dict(),
                "metadata": command.metadata,
            }
        )
        log_event(self._logger, logging.INFO, "invocation.finished", **fields)

    def _log_failed(
        self,
        request_id: str,
        route: ModelRoute,
        provider: LLMProvider,
        command: InvocationCommand,
        error: GatewayError,
        attempts: int,
        total_ms: float,
        client_key_id: str | None,
    ) -> None:
        fields = self._base_fields(request_id, route, provider, command, client_key_id)
        fields.update(
            {
                "status": "error",
                "error_code": error.code,
                "retryable": error.retryable,
                "attempts": attempts,
                "latency_ms": total_ms,
                "provider_error": error.provider,
                "metadata": command.metadata,
            }
        )
        level = logging.WARNING if error.status_code < 500 else logging.ERROR
        log_event(self._logger, level, "invocation.failed", **fields)

    def _log_retry(
        self,
        request_id: str,
        route: ModelRoute,
        attempt: int,
        error: UpstreamError,
        delay_ms: int,
    ) -> None:
        log_event(
            self._logger,
            logging.WARNING,
            "upstream.retry",
            request_id=request_id,
            model=route.name,
            protocol=route.protocol,
            attempt=attempt,
            error_code=error.code,
            delay_ms=delay_ms,
        )
