"""统一异常处理：错误出站脱敏 + 结构化错误日志。"""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.api.deps import get_container
from app.domain.errors import ErrorCode, GatewayError
from app.infrastructure.logging import log_event

logger = logging.getLogger("gateway.error")


def _request_id(request: Request) -> str | None:
    return getattr(request.state, "request_id", None)


def _gateway_response(request: Request, exc: GatewayError) -> JSONResponse:
    container = get_container(request)
    request_id = _request_id(request)
    payload = {
        "error": {
            "code": exc.code,
            "message": container.redactor.text(exc.message),
            "provider": exc.provider,
            "retryable": exc.retryable,
            "details": container.redactor.mapping(exc.details),
            "request_id": request_id,
        }
    }
    level = logging.WARNING if exc.status_code < 500 else logging.ERROR
    log_event(
        logger,
        level,
        "request.failed",
        code=exc.code,
        status=exc.status_code,
        retryable=exc.retryable,
        provider=exc.provider,
    )
    return JSONResponse(status_code=exc.status_code, content=payload, headers=exc.headers)


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(GatewayError)
    async def _handle_gateway_error(request: Request, exc: GatewayError) -> JSONResponse:
        return _gateway_response(request, exc)

    @app.exception_handler(RequestValidationError)
    async def _handle_validation_error(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        error = GatewayError(
            ErrorCode.INVALID_REQUEST,
            "请求参数校验失败",
            status_code=400,
            details={
                "errors": [
                    {
                        "loc": [str(part) for part in item.get("loc", [])],
                        "msg": item.get("msg", ""),
                        "type": item.get("type", ""),
                    }
                    for item in exc.errors()
                ]
            },
        )
        return _gateway_response(request, error)

    @app.exception_handler(Exception)
    async def _handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
        logger.exception(
            "unhandled exception",
            extra={"event": "request.unhandled", "fields": {"error_type": type(exc).__name__}},
        )
        error = GatewayError(ErrorCode.INTERNAL_ERROR, "网关内部错误", status_code=500)
        return _gateway_response(request, error)
