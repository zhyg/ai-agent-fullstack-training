"""组装根：创建并持有全部依赖（依赖注入容器）。"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from app.application.invocation_service import InvocationService
from app.application.output_normalizer import OutputNormalizer
from app.application.prompt_service import PromptService
from app.application.resilience import RetryExecutor
from app.domain.redaction import Redactor
from app.domain.retry import RetryPolicy
from app.infrastructure.adapters.registry import AdapterRegistry
from app.infrastructure.auth import ApiKeyAuthenticator
from app.infrastructure.config import Settings
from app.infrastructure.metrics import InMemoryMetrics
from app.infrastructure.ratelimit_memory import InMemoryRateLimiter
from app.infrastructure.repo_memory import InMemoryPromptRepository


@dataclass
class Container:
    settings: Settings
    redactor: Redactor
    registry: AdapterRegistry
    prompts: PromptService
    metrics: InMemoryMetrics
    limiter: InMemoryRateLimiter
    auth: ApiKeyAuthenticator
    service: InvocationService


def build_container(
    settings: Settings,
    redactor: Redactor,
    logger: logging.Logger | None = None,
) -> Container:
    registry = AdapterRegistry(settings)
    prompt_repository = InMemoryPromptRepository()
    prompts = PromptService(prompt_repository)
    metrics = InMemoryMetrics()
    limiter = InMemoryRateLimiter(settings.rate_limit_per_minute)
    policy = RetryPolicy(
        max_attempts=settings.retry_max_attempts,
        base_delay_ms=settings.retry_base_delay_ms,
        max_delay_ms=settings.retry_max_delay_ms,
        jitter=settings.retry_jitter,
    )
    service = InvocationService(
        registry=registry,
        prompts=prompts,
        normalizer=OutputNormalizer(),
        metrics=metrics,
        limiter=limiter,
        retry=RetryExecutor(policy),
        redactor=redactor,
        logger=logger or logging.getLogger("gateway.invocation"),
    )
    auth = ApiKeyAuthenticator(settings.auth_enabled, settings.api_key_list)
    return Container(
        settings=settings,
        redactor=redactor,
        registry=registry,
        prompts=prompts,
        metrics=metrics,
        limiter=limiter,
        auth=auth,
        service=service,
    )
