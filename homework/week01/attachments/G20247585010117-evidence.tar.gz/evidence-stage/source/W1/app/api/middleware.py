"""接入层中间件：request_id 上下文、请求体限制、访问日志。"""

from __future__ import annotations

import logging
import time
import uuid

from fastapi import Request
from fastapi.responses import JSONResponse

from app.domain.errors import ErrorCode, GatewayError
from app.infrastructure.logging import log_event, request_id_var

access_logger = logging.getLogger("gateway.access")


async def request_context_middleware(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or f"req_{uuid.uuid4().hex[:16]}"
    request.state.request_id = request_id
    token = request_id_var.set(request_id)
    container = request.app.state.container

    content_length = request.headers.get("content-length")
    if content_length:
        try:
            too_large = int(content_length) > container.settings.max_request_bytes
        except ValueError:
            too_large = False
        if too_large:
            error = GatewayError(
                ErrorCode.INVALID_REQUEST,
                "请求体超过大小限制",
                status_code=413,
                details={"max_request_bytes": container.settings.max_request_bytes},
            )
            response = JSONResponse(status_code=413, content=error.payload(request_id))
            response.headers["X-Request-Id"] = request_id
            request_id_var.reset(token)
            return response

    started = time.perf_counter()
    status_code = 500
    try:
        response = await call_next(request)
        status_code = response.status_code
    finally:
        if request.url.path != "/health":
            log_event(
                access_logger,
                logging.INFO,
                "http.request",
                method=request.method,
                path=request.url.path,
                status=status_code,
                duration_ms=round((time.perf_counter() - started) * 1000, 2),
                client_ip=request.client.host if request.client else None,
            )

    response.headers["X-Request-Id"] = request_id
    request_id_var.reset(token)
    return response
