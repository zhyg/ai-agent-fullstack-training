"""内存提示词仓储：实现 PromptRepository 端口（阶段 2 可替换为 SQLite/Redis）。"""

from __future__ import annotations

import re
import threading
from datetime import datetime, timezone
from typing import Any

from app.domain.errors import ErrorCode, GatewayError
from app.domain.models import PromptVersion

_VAR_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class InMemoryPromptRepository:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._items: dict[str, list[PromptVersion]] = {}

    def create(self, name: str, template: str, description: str | None) -> PromptVersion:
        with self._lock:
            if name in self._items:
                raise GatewayError(
                    ErrorCode.PROMPT_EXISTS,
                    f"模板已存在: {name}，请新增版本或换个名字",
                    status_code=409,
                    details={"name": name, "latest_version": len(self._items[name])},
                )
            version = PromptVersion(name, 1, template, description, _now())
            self._items[name] = [version]
            return version

    def add_version(self, name: str, template: str, description: str | None) -> PromptVersion:
        with self._lock:
            versions = self._items.get(name)
            if not versions:
                raise GatewayError(
                    ErrorCode.PROMPT_NOT_FOUND,
                    f"模板不存在: {name}",
                    status_code=404,
                    details={"name": name},
                )
            version = PromptVersion(name, len(versions) + 1, template, description, _now())
            versions.append(version)
            return version

    def get(self, name: str, version: int | None) -> PromptVersion:
        with self._lock:
            versions = self._items.get(name)
            if not versions:
                raise GatewayError(
                    ErrorCode.PROMPT_NOT_FOUND,
                    f"模板不存在: {name}",
                    status_code=404,
                    details={"name": name, "available_templates": sorted(self._items)},
                )
            if version is None:
                return versions[-1]
            for item in versions:
                if item.version == version:
                    return item
            raise GatewayError(
                ErrorCode.PROMPT_NOT_FOUND,
                f"模板 {name} 不存在版本 {version}",
                status_code=404,
                details={
                    "name": name,
                    "requested_version": version,
                    "available_versions": [item.version for item in versions],
                },
            )

    def total_versions(self, name: str) -> int:
        with self._lock:
            return len(self._items.get(name, []))

    def list(self) -> list[dict[str, Any]]:
        with self._lock:
            return [
                {
                    "name": name,
                    "latest_version": len(versions),
                    "versions": [
                        {
                            "version": item.version,
                            "description": item.description,
                            "created_at": item.created_at,
                        }
                        for item in versions
                    ],
                }
                for name, versions in sorted(self._items.items())
            ]

    @staticmethod
    def render(version: PromptVersion, variables: dict[str, str]) -> str:
        missing: set[str] = set()

        def replace(match: re.Match[str]) -> str:
            key = match.group(1)
            if key in variables:
                return str(variables[key])
            missing.add(key)
            return ""

        rendered = _VAR_PATTERN.sub(replace, version.template)
        if missing:
            raise GatewayError(
                ErrorCode.MISSING_VARIABLE,
                f"缺少模板变量: {', '.join(sorted(missing))}",
                status_code=400,
                details={
                    "template": version.name,
                    "version": version.version,
                    "missing_variables": sorted(missing),
                },
            )
        return rendered
