"""内存滑动窗口限流：实现 RateLimiter 端口，超限抛 429 + Retry-After。"""

from __future__ import annotations

import math
import threading
import time
from collections import defaultdict, deque
from typing import Any

from app.domain.errors import ErrorCode, GatewayError


class InMemoryRateLimiter:
    def __init__(self, limit_per_minute: int, window_seconds: int = 60) -> None:
        self.limit = limit_per_minute
        self.window = window_seconds
        self._lock = threading.Lock()
        self._buckets: dict[str, deque[float]] = defaultdict(deque)

    def _prune(self, bucket: deque[float], now: float) -> None:
        while bucket and now - bucket[0] >= self.window:
            bucket.popleft()

    def acquire(self, key: str) -> None:
        if self.limit <= 0:
            return
        now = time.monotonic()
        with self._lock:
            bucket = self._buckets[key]
            self._prune(bucket, now)
            if len(bucket) >= self.limit:
                retry_after = max(1, math.ceil(self.window - (now - bucket[0])))
                raise GatewayError(
                    ErrorCode.RATE_LIMITED,
                    f"模型 {key} 触发限流：每 {self.window} 秒最多 {self.limit} 次调用",
                    status_code=429,
                    details={
                        "model": key,
                        "limit_per_window": self.limit,
                        "window_seconds": self.window,
                        "retry_after_seconds": retry_after,
                    },
                    headers={"Retry-After": str(retry_after)},
                )
            bucket.append(now)

    def snapshot(self) -> dict[str, Any]:
        now = time.monotonic()
        with self._lock:
            active: dict[str, int] = {}
            for key, bucket in self._buckets.items():
                self._prune(bucket, now)
                active[key] = len(bucket)
            return {
                "limit_per_window": self.limit,
                "window_seconds": self.window,
                "active_requests": active,
            }
