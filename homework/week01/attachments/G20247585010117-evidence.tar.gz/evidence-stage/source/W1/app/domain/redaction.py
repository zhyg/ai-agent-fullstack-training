"""脱敏规则与策略（纯函数，可独立单测）。

策略：
- MASK：保留可读性，凭据/PII 打码（默认用于日志）
- HASH：HMAC-SHA256，保留同值关联能力，不可逆（默认用于提示词正文）
- MIXED：凭据/PII 走 MASK，提示词正文走 HASH
- DROP：整值替换为 [redacted]
- OFF：仅本地调试，生产禁用
"""

from __future__ import annotations

import hashlib
import hmac
import re
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable


class RedactionMode(str, Enum):
    OFF = "off"
    MASK = "mask"
    HASH = "hash"
    DROP = "drop"
    MIXED = "mixed"


_SENSITIVE_KEY_MARKERS = (
    "authorization",
    "api_key",
    "apikey",
    "access_key",
    "secret",
    "token",
    "password",
)


def _mask_secret(value: str) -> str:
    if len(value) <= 8:
        return "***"
    return f"{value[:4]}***{value[-3:]}"


def _mask_phone(match: re.Match[str]) -> str:
    return f"{match.group(1)}****{match.group(2)}"


def _mask_email(match: re.Match[str]) -> str:
    return f"{match.group(1)}***@{match.group(2)}"


def _mask_id_card(match: re.Match[str]) -> str:
    return f"{match.group(1)}********{match.group(2)}"


def _mask_bank_card(match: re.Match[str]) -> str:
    return f"**** **** **** {match.group(4)}"


def _mask_ip(match: re.Match[str]) -> str:
    return f"{match.group(1)}.***"


# 顺序：先凭据，再长数字（身份证 > 银行卡），最后手机号/邮箱/IP，避免交叉匹配
_MASK_RULES: tuple[tuple[re.Pattern[str], Callable[[re.Match[str]], str] | str], ...] = (
    (
        re.compile(r"(?i)(bearer\s+)([A-Za-z0-9._\-]{6,})"),
        lambda m: m.group(1) + _mask_secret(m.group(2)),
    ),
    (
        re.compile(r"(?i)(x-api-key\s*[:=]\s*)(\S+)"),
        lambda m: m.group(1) + _mask_secret(m.group(2)),
    ),
    (
        re.compile(r"(?i)((?:api[_-]?key|access[_-]?key|secret|token)\s*[:=]\s*[\"']?)([A-Za-z0-9._\-]{6,})"),
        lambda m: m.group(1) + _mask_secret(m.group(2)),
    ),
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{6,}\b"), lambda m: _mask_secret(m.group(0))),
    (re.compile(r"(?<!\d)(\d{6})\d{8}(\d{3}[\dXx])(?!\d)"), _mask_id_card),
    (
        re.compile(r"(?<!\d)(\d{4})[\s-]?(\d{4})[\s-]?(\d{4})[\s-]?(\d{4})(?!\d)"),
        _mask_bank_card,
    ),
    (re.compile(r"(?<!\d)(1[3-9]\d)\d{4}(\d{4})(?!\d)"), _mask_phone),
    (
        re.compile(r"([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})"),
        _mask_email,
    ),
    (re.compile(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3})\.\d{1,3}\b"), _mask_ip),
)

_MAX_DEPTH = 6


@dataclass(frozen=True)
class RedactionPolicy:
    mode: str = "mixed"
    hash_salt: str = "gateway-local-salt"
    extra_patterns: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        try:
            RedactionMode(self.mode)
        except ValueError as exc:
            raise ValueError(f"未知脱敏模式: {self.mode}") from exc


class Redactor:
    """日志/错误/审计统一脱敏器。"""

    def __init__(self, policy: RedactionPolicy | None = None) -> None:
        self.policy = policy or RedactionPolicy()
        self._mode = RedactionMode(self.policy.mode)
        self._salt = self.policy.hash_salt.encode("utf-8")
        self._extra = tuple(re.compile(pattern) for pattern in self.policy.extra_patterns)

    @property
    def mode(self) -> RedactionMode:
        return self._mode

    def mask_text(self, value: str) -> str:
        result = value
        for pattern in self._extra:
            result = pattern.sub("[redacted]", result)
        for pattern, replacement in _MASK_RULES:
            result = pattern.sub(replacement, result)
        return result

    def hash_text(self, value: str) -> str:
        digest = hmac.new(self._salt, value.encode("utf-8"), hashlib.sha256).hexdigest()
        return f"sha256:{digest[:16]}"

    def text(self, value: str) -> str:
        """普通日志文本：按全局模式处理（MIXED 等价 MASK）。"""
        if not value:
            return value
        if self._mode is RedactionMode.OFF:
            return value
        if self._mode is RedactionMode.HASH:
            return self.hash_text(value)
        if self._mode is RedactionMode.DROP:
            return "[redacted]"
        return self.mask_text(value)

    def prompt(self, value: str) -> str:
        """提示词正文：MIXED/HASH 走哈希，MASK 走打码，避免正文落日志。"""
        if not value:
            return value
        if self._mode is RedactionMode.OFF:
            return value
        if self._mode is RedactionMode.MASK:
            return self.mask_text(value)
        if self._mode is RedactionMode.DROP:
            return "[redacted]"
        return self.hash_text(value)

    def _sensitive_value(self, value: str) -> str:
        if self._mode is RedactionMode.OFF:
            return value
        if self._mode is RedactionMode.DROP:
            return "[redacted]"
        if self._mode is RedactionMode.HASH:
            return self.hash_text(value)
        return _mask_secret(value)

    def _value(self, value: Any, depth: int) -> Any:
        if isinstance(value, str):
            return self.text(value)
        if isinstance(value, Mapping):
            return self.mapping(value, depth + 1)
        if isinstance(value, (list, tuple)):
            return [self._value(item, depth + 1) for item in value]
        return value

    def mapping(self, data: Mapping[str, Any] | None, depth: int = 0) -> dict[str, Any]:
        if not data:
            return {}
        if depth > _MAX_DEPTH:
            return {"_truncated": True}
        result: dict[str, Any] = {}
        for key, value in data.items():
            normalized = str(key).lower().replace("-", "_")
            sensitive = any(marker in normalized for marker in _SENSITIVE_KEY_MARKERS)
            if isinstance(value, str) and sensitive:
                result[key] = self._sensitive_value(value)
            else:
                result[key] = self._value(value, depth)
        return result
