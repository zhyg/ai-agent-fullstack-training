"""统一调用入口：POST /v1/invoke（JSON / SSE）。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import ValidationError

from app.api.deps import get_container, require_api_key
from app.api.schemas import InvokeRequest
from app.domain.errors import ErrorCode, GatewayError

router = APIRouter()

_MOCK_HEADER_MAP = {
    "x-mock-fail-times": "fail_times",
    "x-mock-total-ms": "total_ms",
    "x-mock-ttft-ms": "ttft_ms",
    "x-mock-chunk-delay-ms": "chunk_delay_ms",
    "x-mock-cached-tokens": "cached_tokens",
}


def _mock_controls(request: Request) -> dict[str, Any]:
    controls: dict[str, Any] = {}
    for header, key in _MOCK_HEADER_MAP.items():
        raw = request.headers.get(header)
        if raw is None:
            continue
        try:
            controls[key] = int(raw)
        except ValueError:
            continue
    return controls


def _validation_details(exc: ValidationError) -> dict[str, Any]:
    return {
        "errors": [
            {
                "loc": [str(part) for part in item.get("loc", [])],
                "msg": item.get("msg", ""),
                "type": item.get("type", ""),
            }
            for item in exc.errors()
        ]
    }


@router.post("/v1/invoke")
async def invoke(
    request: Request,
    client_key_id: str | None = Depends(require_api_key),
):
    container = get_container(request)
    request_id = request.state.request_id

    try:
        body = await request.json()
    except ValueError as exc:
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            "请求体必须是合法 JSON",
            status_code=400,
            details={"error": str(exc)},
        ) from exc

    try:
        payload = InvokeRequest.model_validate(body)
    except ValidationError as exc:
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            "请求体校验失败",
            status_code=400,
            details=_validation_details(exc),
        ) from exc

    command = payload.to_command()
    controls = _mock_controls(request)

    if command.stream:
        events = container.service.prepare_stream(
            command, request_id, controls, client_key_id
        )
        return StreamingResponse(
            events,
            media_type="text/event-stream",
            headers={
                "X-Request-Id": request_id,
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    result = await container.service.invoke(command, request_id, controls, client_key_id)
    return JSONResponse(content=result, headers={"X-Request-Id": request_id})
