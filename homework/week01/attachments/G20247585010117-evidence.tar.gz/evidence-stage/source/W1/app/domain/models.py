"""领域模型：不依赖 FastAPI、httpx 或任何具体协议。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ModelRoute:
    """一个统一模型名到上游协议的路由规则。"""

    name: str
    protocol: str
    upstream_model: str
    timeout_seconds: float = 60.0
    rate_limit_limit: int = 20
    rate_limit_window_seconds: int = 60


@dataclass
class InvocationContext:
    request_id: str
    model: str
    protocol: str
    mode: str
    stream: bool
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def as_dict(self) -> dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cached_tokens": self.cached_tokens,
            "total_tokens": self.total_tokens,
        }


@dataclass
class ProviderRequest:
    """适配器唯一能看到的请求形态。"""

    request_id: str
    route: ModelRoute
    messages: list[dict[str, str]]
    temperature: float
    max_tokens: int
    response_format: dict[str, Any] | None = None
    mock_controls: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProviderResult:
    text: str
    usage: Usage
    finish_reason: str = "stop"
    structured: dict[str, Any] | None = None


@dataclass
class StreamChunk:
    text: str = ""
    usage: Usage | None = None
    finish_reason: str | None = None


@dataclass(frozen=True)
class PromptVersion:
    name: str
    version: int
    template: str
    description: str | None
    created_at: str

    def as_dict(self, total_versions: int | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "version": self.version,
            "template": self.template,
            "description": self.description,
            "created_at": self.created_at,
        }
        if total_versions is not None:
            payload["total_versions"] = total_versions
        return payload


@dataclass
class InvocationMetric:
    request_id: str
    trace_id: str | None
    model: str
    protocol: str
    mode: str
    stream: bool
    ok: bool
    error_code: str | None
    usage: dict[str, int]
    total_ms: float
    ttft_ms: float | None
    attempts: int
    metadata: dict[str, Any] = field(default_factory=dict)
