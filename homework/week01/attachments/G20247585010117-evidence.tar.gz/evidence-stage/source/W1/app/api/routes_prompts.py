"""提示词模板管理接口。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request

from app.api.deps import get_container, require_api_key
from app.api.schemas import PromptCreate, PromptVersionCreate

router = APIRouter(prefix="/v1/prompts", tags=["prompts"], dependencies=[Depends(require_api_key)])


@router.post("", status_code=201)
async def create_prompt(body: PromptCreate, request: Request) -> dict[str, Any]:
    return get_container(request).prompts.create(body.name, body.template, body.description)


@router.post("/{name}/versions", status_code=201)
async def create_prompt_version(
    name: str, body: PromptVersionCreate, request: Request
) -> dict[str, Any]:
    return get_container(request).prompts.add_version(name, body.template, body.description)


@router.get("")
async def list_prompts(request: Request) -> dict[str, Any]:
    return {"data": get_container(request).prompts.list()}


@router.get("/{name}")
async def get_prompt(request: Request, name: str, version: int | None = None) -> dict[str, Any]:
    return get_container(request).prompts.get_payload(name, version)
