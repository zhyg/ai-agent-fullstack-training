"""FastAPI 入口：唯一组装点（配置 → 日志 → 容器 → 路由）。"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.responses import FileResponse

from app.api.error_handlers import register_error_handlers
from app.api.middleware import request_context_middleware
from app.api.routes_invoke import router as invoke_router
from app.api.routes_metrics import router as metrics_router
from app.api.routes_prompts import router as prompts_router
from app.api.routes_runtime import router as runtime_router
from app.container import Container, build_container
from app.domain.redaction import RedactionPolicy, Redactor
from app.infrastructure.config import Settings, get_settings
from app.infrastructure.logging import configure_logging

settings: Settings = get_settings()
redactor = Redactor(
    RedactionPolicy(
        mode=settings.redaction_mode,
        hash_salt=settings.hash_salt,
        extra_patterns=settings.extra_redaction_patterns,
    )
)
configure_logging(settings, redactor)
logger = logging.getLogger("gateway")
container: Container = build_container(settings, redactor, logger)
STATIC_DIR = Path(__file__).resolve().parent / "static"


@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info(
        "gateway.started",
        extra={
            "event": "gateway.started",
            "fields": {
                "mode": "mock" if settings.use_mock else "live",
                "environment": settings.environment,
                "version": settings.version,
                "auth_enabled": settings.auth_enabled,
                "redaction_mode": settings.redaction_mode,
            },
        },
    )
    yield
    await container.registry.aclose()
    logger.info("gateway.stopped", extra={"event": "gateway.stopped"})


app = FastAPI(
    title="Unified LLM Gateway",
    version=settings.version,
    description="统一抽象层 + 多协议适配器（OpenAI Responses / Anthropic Messages）",
    lifespan=lifespan,
)
app.state.container = container
app.middleware("http")(request_context_middleware)
register_error_handlers(app)
app.include_router(invoke_router)
app.include_router(prompts_router)
app.include_router(metrics_router)
app.include_router(runtime_router)


@app.get("/")
async def root() -> dict[str, Any]:
    return {
        "name": "Unified LLM Gateway",
        "version": settings.version,
        "mode": container.registry.mode,
        "docs": "/docs",
        "console": "/console",
        "endpoints": [
            "POST /v1/invoke",
            "GET /v1/models",
            "POST /v1/prompts",
            "POST /v1/prompts/{name}/versions",
            "GET /v1/prompts",
            "GET /v1/prompts/{name}",
            "GET /v1/metrics",
            "GET /v1/logs",
            "GET /v1/runtime",
            "POST /v1/runtime/mode",
            "POST /v1/runtime/upstream",
            "GET /health",
            "GET /console",
        ],
    }


@app.get("/console", include_in_schema=False)
async def console() -> FileResponse:
    return FileResponse(STATIC_DIR / "console.html")


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "version": settings.version,
        "mode": container.registry.mode,
    }


@app.get("/v1/models")
async def list_models() -> dict[str, Any]:
    return {"data": container.registry.list_models()}
