"""领域端口：应用层只依赖这些 Protocol，实现由基础设施层注入。"""

from __future__ import annotations

from collections.abc import AsyncIterator, Mapping
from typing import Any, Protocol

from app.domain.models import (
    InvocationMetric,
    ModelRoute,
    PromptVersion,
    ProviderRequest,
    ProviderResult,
    StreamChunk,
)


class LLMProvider(Protocol):
    protocol: str
    mode: str

    async def complete(self, request: ProviderRequest) -> ProviderResult: ...

    def stream(self, request: ProviderRequest) -> AsyncIterator[StreamChunk]: ...

    async def aclose(self) -> None: ...


class ProviderRegistry(Protocol):
    def resolve(self, model: str) -> ModelRoute: ...

    def provider(self, route: ModelRoute) -> LLMProvider: ...

    def list_models(self) -> list[dict[str, str]]: ...

    async def aclose(self) -> None: ...


class PromptRepository(Protocol):
    def create(self, name: str, template: str, description: str | None) -> PromptVersion: ...

    def add_version(self, name: str, template: str, description: str | None) -> PromptVersion: ...

    def get(self, name: str, version: int | None) -> PromptVersion: ...

    def render(self, prompt: PromptVersion, variables: dict[str, str]) -> str: ...

    def list(self) -> list[dict[str, Any]]: ...


class RateLimiter(Protocol):
    def acquire(self, key: str) -> None: ...

    def snapshot(self) -> dict[str, Any]: ...


class MetricsRecorder(Protocol):
    def record(self, metric: InvocationMetric) -> None: ...

    def snapshot(self) -> dict[str, Any]: ...

    def logs(self, limit: int = 20, model: str | None = None) -> list[dict[str, Any]]: ...


class Redactor(Protocol):
    def text(self, value: str) -> str: ...

    def prompt(self, value: str) -> str: ...

    def mapping(self, data: Mapping[str, Any] | None, depth: int = 0) -> dict[str, Any]: ...
