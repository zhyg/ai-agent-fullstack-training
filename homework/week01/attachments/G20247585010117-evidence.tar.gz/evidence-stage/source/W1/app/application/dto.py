"""应用层 DTO：API 层校验后映射为命令对象，避免应用层依赖 pydantic/FastAPI。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class PromptRefCommand:
    name: str
    version: int | None = None
    variables: dict[str, str] = field(default_factory=dict)


@dataclass
class ResponseFormatCommand:
    type: str
    schema: dict[str, Any] | None = None
    strict: bool = False


@dataclass
class InvocationCommand:
    model: str
    messages: list[dict[str, str]]
    prompt: PromptRefCommand | None
    stream: bool
    response_format: ResponseFormatCommand | None
    temperature: float
    max_tokens: int
    metadata: dict[str, Any] = field(default_factory=dict)
