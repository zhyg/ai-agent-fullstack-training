"""对外请求/响应模型（pydantic），负责校验并映射为应用层命令。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.application.dto import InvocationCommand, PromptRefCommand, ResponseFormatCommand

Role = Literal["system", "user", "assistant"]


class ChatMessage(BaseModel):
    role: Role
    content: str


class PromptRef(BaseModel):
    name: str
    version: int | None = None
    variables: dict[str, str] = Field(default_factory=dict)


class ResponseFormat(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    type: Literal["text", "json_object"] = "text"
    schema_: dict[str, Any] | None = Field(default=None, alias="schema")
    strict: bool = False


class InvokeRequest(BaseModel):
    model: str
    messages: list[ChatMessage] = Field(default_factory=list)
    prompt: PromptRef | None = None
    stream: bool = False
    response_format: ResponseFormat | None = None
    temperature: float = 0.7
    max_tokens: int = 1024
    metadata: dict[str, Any] | None = None

    @model_validator(mode="after")
    def _require_input(self) -> "InvokeRequest":
        if not self.messages and self.prompt is None:
            raise ValueError("messages 与 prompt 至少提供一个")
        if (
            self.response_format
            and self.response_format.type == "json_object"
            and not self.response_format.schema_
        ):
            raise ValueError("response_format.type=json_object 时必须提供 schema")
        if self.max_tokens <= 0:
            raise ValueError("max_tokens 必须为正整数")
        return self

    def to_command(self) -> InvocationCommand:
        prompt = None
        if self.prompt is not None:
            prompt = PromptRefCommand(
                name=self.prompt.name,
                version=self.prompt.version,
                variables=self.prompt.variables,
            )
        response_format = None
        if self.response_format is not None:
            response_format = ResponseFormatCommand(
                type=self.response_format.type,
                schema=self.response_format.schema_,
                strict=self.response_format.strict,
            )
        return InvocationCommand(
            model=self.model,
            messages=[message.model_dump() for message in self.messages],
            prompt=prompt,
            stream=self.stream,
            response_format=response_format,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            metadata=self.metadata or {},
        )


class PromptCreate(BaseModel):
    name: str = Field(pattern=r"^[A-Za-z0-9_-]{1,64}$")
    template: str = Field(min_length=1)
    description: str | None = None


class PromptVersionCreate(BaseModel):
    template: str = Field(min_length=1)
    description: str | None = None
