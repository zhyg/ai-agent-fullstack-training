"""API 层依赖：容器获取与入站鉴权。"""

from __future__ import annotations

from fastapi import Request

from app.container import Container


def get_container(request: Request) -> Container:
    return request.app.state.container


def require_api_key(request: Request) -> str | None:
    container = get_container(request)
    return container.auth.authenticate(
        request.headers.get("authorization"),
        request.headers.get("x-api-key"),
    )
