"""适配器注册表：统一模型名 -> ModelRoute -> 协议适配器。"""

from __future__ import annotations

from app.domain.errors import ErrorCode, GatewayError
from app.domain.models import ModelRoute
from app.domain.ports import LLMProvider
from app.infrastructure.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.infrastructure.adapters.mock import MockAdapter
from app.infrastructure.adapters.openai_responses import OpenAIResponsesAdapter
from app.infrastructure.config import Settings


class AdapterRegistry:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._routes: dict[str, ModelRoute] = settings.model_routes()
        self._providers: dict[tuple[str, str], LLMProvider] = {}
        self._mode = "mock" if settings.use_mock else "live"

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def live_configured(self) -> bool:
        return bool(self.settings.openai_api_key and self.settings.anthropic_api_key)

    def set_mode(self, mode: str) -> None:
        if mode not in {"mock", "live"}:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                f"未知模式: {mode}",
                status_code=400,
                details={"allowed": ["mock", "live"]},
            )
        if mode == "live" and not self.live_configured:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                "切换到 live 需要配置 OPENAI_API_KEY 和 ANTHROPIC_API_KEY",
                status_code=400,
            )
        self._mode = mode

    def resolve(self, model: str) -> ModelRoute:
        route = self._routes.get(model)
        if route is None:
            raise GatewayError(
                ErrorCode.UNSUPPORTED_MODEL,
                f"不支持的模型: {model}",
                status_code=400,
                details={"supported_models": sorted(self._routes)},
            )
        return route

    def provider(self, route: ModelRoute) -> LLMProvider:
        key = (self._mode, route.protocol)
        if key not in self._providers:
            self._providers[key] = self._build(route.protocol)
        return self._providers[key]

    async def reset_live(self) -> None:
        """上游地址或密钥变更后丢弃 live 适配器，下次请求按新配置重建。"""
        stale = [key for key in self._providers if key[0] == "live"]
        for key in stale:
            await self._providers.pop(key).aclose()

    def refresh_routes(self) -> None:
        """上游模型名变更后重建路由表。"""
        self._routes = self.settings.model_routes()

    def _build(self, protocol: str) -> LLMProvider:
        if self._mode == "mock":
            return MockAdapter(self.settings, protocol)
        if protocol == "openai-responses":
            return OpenAIResponsesAdapter(self.settings)
        if protocol == "anthropic-messages":
            return AnthropicMessagesAdapter(self.settings)
        raise GatewayError(
            ErrorCode.INTERNAL_ERROR,
            f"未实现的协议: {protocol}",
            status_code=500,
        )

    def list_models(self) -> list[dict[str, str]]:
        return [
            {
                "id": route.name,
                "provider": route.protocol,
                "upstream_model": route.upstream_model,
                "mode": self._mode,
            }
            for route in self._routes.values()
        ]

    async def aclose(self) -> None:
        for provider in self._providers.values():
            await provider.aclose()
