"""提示词应用服务：仓储读写 + 变量渲染。"""

from __future__ import annotations

from typing import Any

from app.domain.models import PromptVersion
from app.domain.ports import PromptRepository


class PromptService:
    def __init__(self, repository: PromptRepository) -> None:
        self._repository = repository

    def create(self, name: str, template: str, description: str | None) -> dict[str, Any]:
        version = self._repository.create(name, template, description)
        return version.as_dict(total_versions=1)

    def add_version(self, name: str, template: str, description: str | None) -> dict[str, Any]:
        version = self._repository.add_version(name, template, description)
        return version.as_dict(total_versions=self._total_versions(name))

    def get_payload(self, name: str, version: int | None) -> dict[str, Any]:
        prompt = self._repository.get(name, version)
        return prompt.as_dict(total_versions=self._total_versions(name))

    def list(self) -> list[dict[str, Any]]:
        return self._repository.list()

    def render(self, name: str, version: int | None, variables: dict[str, str]) -> str:
        prompt: PromptVersion = self._repository.get(name, version)
        return self._repository.render(prompt, variables)

    def _total_versions(self, name: str) -> int:
        for item in self._repository.list():
            if item["name"] == name:
                return int(item["latest_version"])
        return 1
