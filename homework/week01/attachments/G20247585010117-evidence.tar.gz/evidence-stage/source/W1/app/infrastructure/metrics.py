"""内存指标与调用日志：实现 MetricsRecorder 端口。"""

from __future__ import annotations

import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from app.domain.models import InvocationMetric


@dataclass
class Bucket:
    calls: int = 0
    errors: int = 0
    retries: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0
    total_tokens: int = 0
    sum_total_ms: float = 0.0
    max_total_ms: float = 0.0
    ttft_samples: int = 0
    sum_ttft_ms: float = 0.0
    max_ttft_ms: float = 0.0

    def add(self, metric: InvocationMetric) -> None:
        self.calls += 1
        if not metric.ok:
            self.errors += 1
        self.retries += max(0, metric.attempts - 1)
        self.input_tokens += int(metric.usage.get("input_tokens") or 0)
        self.output_tokens += int(metric.usage.get("output_tokens") or 0)
        self.cached_tokens += int(metric.usage.get("cached_tokens") or 0)
        self.total_tokens += int(metric.usage.get("total_tokens") or 0)
        self.sum_total_ms += metric.total_ms
        self.max_total_ms = max(self.max_total_ms, metric.total_ms)
        if metric.ttft_ms is not None:
            self.ttft_samples += 1
            self.sum_ttft_ms += metric.ttft_ms
            self.max_ttft_ms = max(self.max_ttft_ms, metric.ttft_ms)

    def snapshot(self) -> dict[str, Any]:
        return {
            "calls": self.calls,
            "errors": self.errors,
            "retries": self.retries,
            "tokens": {
                "input_tokens": self.input_tokens,
                "output_tokens": self.output_tokens,
                "cached_tokens": self.cached_tokens,
                "total_tokens": self.total_tokens,
            },
            "latency_ms": {
                "avg_total_ms": round(self.sum_total_ms / self.calls, 2) if self.calls else None,
                "max_total_ms": round(self.max_total_ms, 2) if self.calls else None,
                "avg_ttft_ms": round(self.sum_ttft_ms / self.ttft_samples, 2)
                if self.ttft_samples
                else None,
                "max_ttft_ms": round(self.max_ttft_ms, 2) if self.ttft_samples else None,
                "ttft_samples": self.ttft_samples,
            },
        }


@dataclass
class CallRecord:
    request_id: str
    timestamp: str
    model: str
    provider: str
    mode: str
    stream: bool
    ok: bool
    error_code: str | None
    usage: dict[str, int]
    total_ms: float
    ttft_ms: float | None
    attempts: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "timestamp": self.timestamp,
            "model": self.model,
            "provider": self.provider,
            "mode": self.mode,
            "stream": self.stream,
            "ok": self.ok,
            "error_code": self.error_code,
            "usage": self.usage,
            "latency": {"total_ms": self.total_ms, "ttft_ms": self.ttft_ms},
            "attempts": self.attempts,
            "metadata": self.metadata,
        }


class InMemoryMetrics:
    def __init__(self, max_logs: int = 200) -> None:
        self._lock = threading.Lock()
        self._started_at = datetime.now(timezone.utc)
        self._totals = Bucket()
        self._models: dict[str, Bucket] = defaultdict(Bucket)
        self._logs: deque[CallRecord] = deque(maxlen=max_logs)

    def record(self, metric: InvocationMetric) -> None:
        usage = {
            "input_tokens": int(metric.usage.get("input_tokens") or 0),
            "output_tokens": int(metric.usage.get("output_tokens") or 0),
            "cached_tokens": int(metric.usage.get("cached_tokens") or 0),
            "total_tokens": int(metric.usage.get("total_tokens") or 0),
        }
        normalized = InvocationMetric(
            request_id=metric.request_id,
            trace_id=metric.trace_id,
            model=metric.model,
            protocol=metric.protocol,
            mode=metric.mode,
            stream=metric.stream,
            ok=metric.ok,
            error_code=metric.error_code,
            usage=usage,
            total_ms=metric.total_ms,
            ttft_ms=metric.ttft_ms,
            attempts=metric.attempts,
            metadata=metric.metadata,
        )
        record = CallRecord(
            request_id=metric.request_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            model=metric.model,
            provider=metric.protocol,
            mode=metric.mode,
            stream=metric.stream,
            ok=metric.ok,
            error_code=metric.error_code,
            usage=usage,
            total_ms=metric.total_ms,
            ttft_ms=metric.ttft_ms,
            attempts=metric.attempts,
            metadata=metric.metadata,
        )
        with self._lock:
            self._totals.add(normalized)
            self._models[metric.model].add(normalized)
            self._logs.append(record)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            now = datetime.now(timezone.utc)
            return {
                "started_at": self._started_at.isoformat(),
                "uptime_seconds": round((now - self._started_at).total_seconds(), 2),
                "totals": self._totals.snapshot(),
                "models": {
                    name: bucket.snapshot() for name, bucket in sorted(self._models.items())
                },
                "recent_errors": [
                    record.as_dict() for record in list(self._logs) if not record.ok
                ][-10:][::-1],
            }

    def logs(self, limit: int = 20, model: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            records = list(self._logs)
        if model:
            records = [record for record in records if record.model == model]
        return [record.as_dict() for record in records[::-1][:limit]]
