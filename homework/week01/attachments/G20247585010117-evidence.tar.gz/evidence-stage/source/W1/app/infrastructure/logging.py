"""结构化日志：JSON 输出到 stdout，request_id 通过 contextvar 自动注入。"""

from __future__ import annotations

import json
import logging
import sys
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any

from app.domain.redaction import Redactor
from app.infrastructure.config import Settings

request_id_var: ContextVar[str | None] = ContextVar("gateway_request_id", default=None)
trace_id_var: ContextVar[str | None] = ContextVar("gateway_trace_id", default=None)

_HANDLER_FLAG = "_gateway_handler"


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, timezone.utc)
            .isoformat(timespec="milliseconds")
            .replace("+00:00", "Z"),
            "level": record.levelname,
            "logger": record.name,
            "event": getattr(record, "event", record.getMessage()),
        }
        request_id = getattr(record, "request_id", None) or request_id_var.get()
        if request_id:
            payload["request_id"] = request_id
        trace_id = getattr(record, "trace_id", None) or trace_id_var.get()
        if trace_id:
            payload["trace_id"] = trace_id

        fields = getattr(record, "fields", None)
        if isinstance(fields, dict):
            payload.update(fields)

        message = record.getMessage()
        if message and message != payload["event"]:
            payload["message"] = message

        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, default=str)


class RedactionFilter(logging.Filter):
    """日志兜底脱敏：调用方即使误传敏感内容也会被处理。"""

    def __init__(self, redactor: Redactor) -> None:
        super().__init__()
        self.redactor = redactor

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = self.redactor.text(record.msg)
        fields = getattr(record, "fields", None)
        if isinstance(fields, dict):
            record.fields = self.redactor.mapping(fields)
        if record.exc_info and not record.exc_text:
            record.exc_text = logging.Formatter().formatException(record.exc_info)
        if record.exc_text:
            record.exc_text = self.redactor.text(record.exc_text)
        return True


def configure_logging(settings: Settings, redactor: Redactor) -> None:
    root = logging.getLogger()
    for handler in list(root.handlers):
        if getattr(handler, _HANDLER_FLAG, False):
            root.removeHandler(handler)

    handler = logging.StreamHandler(stream=sys.stdout)
    setattr(handler, _HANDLER_FLAG, True)
    handler.setFormatter(JsonFormatter())
    handler.addFilter(RedactionFilter(redactor))
    root.addHandler(handler)
    root.setLevel(settings.log_level.upper())

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


def log_event(
    logger: logging.Logger,
    level: int,
    event: str,
    **fields: Any,
) -> None:
    logger.log(level, event, extra={"event": event, "fields": fields})
