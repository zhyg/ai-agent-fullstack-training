"""入站 API Key 鉴权：常量时间比较，默认关闭。"""

from __future__ import annotations

import hashlib
import hmac

from app.domain.errors import ErrorCode, GatewayError


class ApiKeyAuthenticator:
    def __init__(self, enabled: bool, keys: list[str]) -> None:
        self.enabled = enabled
        self._keys = [key for key in keys if key]
        self._key_ids = {
            key: f"key_{hashlib.sha256(key.encode('utf-8')).hexdigest()[:8]}"
            for key in self._keys
        }

    def authenticate(self, authorization: str | None, api_key: str | None) -> str | None:
        """成功返回脱敏 key_id（用于日志），失败抛 401。"""
        if not self.enabled:
            return None

        presented = (api_key or "").strip()
        if not presented and authorization:
            scheme, _, token = authorization.partition(" ")
            if scheme.lower() == "bearer":
                presented = token.strip()

        if not presented:
            raise self._unauthorized("缺少 API Key")

        for key in self._keys:
            if hmac.compare_digest(presented, key):
                return self._key_ids[key]
        raise self._unauthorized("API Key 无效")

    @staticmethod
    def _unauthorized(reason: str) -> GatewayError:
        return GatewayError(
            ErrorCode.UNAUTHORIZED,
            reason,
            status_code=401,
            headers={"WWW-Authenticate": "Bearer"},
        )
