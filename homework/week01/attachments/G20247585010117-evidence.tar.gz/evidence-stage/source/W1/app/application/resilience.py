"""重试执行器：把纯策略 RetryPolicy 应用到异步调用上。"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

from app.domain.errors import UpstreamError
from app.domain.retry import RetryPolicy

T = TypeVar("T")

RetryHook = Callable[[int, UpstreamError, int], None]


class RetryExecutor:
    def __init__(self, policy: RetryPolicy) -> None:
        self.policy = policy

    async def run(
        self,
        call: Callable[[], Awaitable[T]],
        *,
        on_retry: RetryHook | None = None,
    ) -> tuple[T, int]:
        """返回 (结果, 实际尝试次数)；仅在可重试错误上退避重试。"""
        for attempt in range(1, self.policy.max_attempts + 1):
            try:
                return await call(), attempt
            except UpstreamError as exc:
                exc.attempts = attempt
                if not self.policy.should_retry(exc, attempt):
                    raise
                delay_ms = self.policy.delay_ms(attempt)
                if on_retry is not None:
                    on_retry(attempt, exc, delay_ms)
                await asyncio.sleep(delay_ms / 1000)
        raise AssertionError("unreachable")
