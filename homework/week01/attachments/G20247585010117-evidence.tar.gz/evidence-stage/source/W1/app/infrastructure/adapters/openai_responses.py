"""OpenAI Responses API 适配器。

屏蔽点：Bearer 鉴权、input 结构、text.format 结构化输出、usage 字段、
SSE 事件（response.output_text.delta / response.completed）。
"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator

import httpx

from app.domain.errors import ErrorCode, UpstreamError
from app.domain.models import ProviderRequest, ProviderResult, StreamChunk, Usage
from app.infrastructure.config import Settings


def _parse_usage(raw: dict[str, Any] | None) -> Usage:
    raw = raw or {}
    cached = (raw.get("input_tokens_details") or {}).get("cached_tokens") or 0
    return Usage(
        input_tokens=int(raw.get("input_tokens") or 0),
        output_tokens=int(raw.get("output_tokens") or 0),
        cached_tokens=int(cached),
    )


class OpenAIResponsesAdapter:
    protocol = "openai-responses"
    mode = "live"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._client = httpx.AsyncClient(
            base_url=settings.openai_base_url,
            timeout=httpx.Timeout(
                settings.http_timeout_seconds,
                connect=settings.http_connect_timeout_seconds,
            ),
        )

    def _headers(self) -> dict[str, str]:
        key = self.settings.openai_key()
        if not key:
            raise UpstreamError(
                ErrorCode.UPSTREAM_AUTH_ERROR,
                "缺少 OPENAI_API_KEY（或 config.py 中的 key）",
                status_code=502,
                provider=self.protocol,
                retryable=False,
            )
        return {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

    def _payload(self, request: ProviderRequest, stream: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": request.route.upstream_model,
            "input": [
                {"role": message["role"], "content": message["content"]}
                for message in request.messages
            ],
            "temperature": request.temperature,
            "max_output_tokens": request.max_tokens,
            "stream": stream,
        }
        response_format = request.response_format
        if response_format and response_format.get("type") == "json_object":
            payload["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": "structured_output",
                    "schema": response_format.get("schema"),
                    "strict": bool(response_format.get("strict")),
                }
            }
        return payload

    def _raise_for_response(self, response: httpx.Response) -> None:
        if response.status_code < 400:
            return
        body: dict[str, Any] = {}
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                body = parsed
        except ValueError:
            pass
        message = ""
        if isinstance(body.get("error"), dict):
            message = str(body["error"].get("message") or "")
        message = message or response.text[:300] or "上游返回错误"

        if response.status_code in (401, 403):
            raise UpstreamError(
                ErrorCode.UPSTREAM_AUTH_ERROR,
                f"上游鉴权失败（HTTP {response.status_code}）：{message}",
                status_code=502,
                provider=self.protocol,
                retryable=False,
                details={"upstream_status": response.status_code},
            )
        if response.status_code == 429 or response.status_code >= 500:
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"上游暂不可用（HTTP {response.status_code}）：{message}",
                status_code=502,
                provider=self.protocol,
                retryable=True,
                details={"upstream_status": response.status_code},
            )
        raise UpstreamError(
            ErrorCode.UPSTREAM_ERROR,
            f"上游拒绝请求（HTTP {response.status_code}）：{message}",
            status_code=502,
            provider=self.protocol,
            retryable=False,
            details={"upstream_status": response.status_code},
        )

    async def complete(self, request: ProviderRequest) -> ProviderResult:
        payload = self._payload(request, stream=False)
        try:
            response = await self._client.post(
                "/responses", json=payload, headers=self._headers()
            )
        except httpx.TimeoutException as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_TIMEOUT,
                f"上游请求超时（{type(exc).__name__}）：{exc}",
                status_code=504,
                provider=self.protocol,
                retryable=True,
            ) from exc
        except httpx.RequestError as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"无法连接上游：{exc}",
                status_code=502,
                provider=self.protocol,
                retryable=True,
            ) from exc

        self._raise_for_response(response)
        data = response.json()

        texts: list[str] = []
        for item in data.get("output") or []:
            if item.get("type") != "message":
                continue
            for block in item.get("content") or []:
                if block.get("type") == "output_text":
                    texts.append(block.get("text") or "")
        text = data.get("output_text") or "".join(texts)

        finish_reason = "stop"
        if data.get("status") == "incomplete":
            finish_reason = (data.get("incomplete_details") or {}).get("reason") or "length"

        return ProviderResult(
            text=text,
            usage=_parse_usage(data.get("usage")),
            finish_reason=finish_reason,
        )

    async def stream(self, request: ProviderRequest) -> AsyncIterator[StreamChunk]:
        payload = self._payload(request, stream=True)
        try:
            async with self._client.stream(
                "POST", "/responses", json=payload, headers=self._headers()
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    self._raise_for_response(response)
                async for line in response.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    raw = line[5:].strip()
                    if not raw or raw == "[DONE]":
                        continue
                    try:
                        event = json.loads(raw)
                    except ValueError:
                        continue
                    event_type = event.get("type")
                    if event_type == "response.output_text.delta":
                        yield StreamChunk(text=event.get("delta") or "")
                    elif event_type == "response.completed":
                        completed = event.get("response") or {}
                        yield StreamChunk(
                            usage=_parse_usage(completed.get("usage")),
                            finish_reason="stop",
                        )
                    elif event_type in ("response.failed", "error"):
                        message = str(event.get("error") or event.get("response") or event)
                        raise UpstreamError(
                            ErrorCode.UPSTREAM_ERROR,
                            f"上游流式调用失败：{message[:300]}",
                            status_code=502,
                            provider=self.protocol,
                            retryable=False,
                        )
        except httpx.TimeoutException as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_TIMEOUT,
                f"上游流式请求超时（{type(exc).__name__}）：{exc}",
                status_code=504,
                provider=self.protocol,
                retryable=True,
            ) from exc
        except httpx.RequestError as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"无法连接上游：{exc}",
                status_code=502,
                provider=self.protocol,
                retryable=True,
            ) from exc

    async def aclose(self) -> None:
        await self._client.aclose()
