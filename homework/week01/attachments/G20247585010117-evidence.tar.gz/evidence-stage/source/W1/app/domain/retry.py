"""重试策略（纯函数，可独立单测）。"""

from __future__ import annotations

import random
from dataclasses import dataclass

from app.domain.errors import UpstreamError


@dataclass(frozen=True)
class RetryPolicy:
    """指数退避 + 抖动；max_attempts 含首次调用。"""

    max_attempts: int = 3
    base_delay_ms: int = 200
    factor: float = 2.0
    max_delay_ms: int = 2000
    jitter: float = 0.2

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts 必须 >= 1")
        if self.base_delay_ms < 0 or self.max_delay_ms < 0:
            raise ValueError("延迟不能为负数")
        if not 0.0 <= self.jitter <= 1.0:
            raise ValueError("jitter 必须在 [0, 1] 区间")

    def should_retry(self, error: UpstreamError, attempt: int) -> bool:
        return error.retryable and attempt < self.max_attempts

    def delay_ms(self, attempt: int, rng: random.Random | None = None) -> int:
        """第 attempt 次失败后的等待时长（attempt 从 1 开始）。"""
        raw = min(self.base_delay_ms * (self.factor ** (attempt - 1)), self.max_delay_ms)
        if self.jitter:
            generator = rng or random
            raw *= 1 + generator.uniform(-self.jitter, self.jitter)
        return max(0, int(raw))
