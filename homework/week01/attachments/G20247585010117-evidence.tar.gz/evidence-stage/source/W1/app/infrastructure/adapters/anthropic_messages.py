"""Anthropic Messages API 适配器。

屏蔽点：x-api-key + anthropic-version 鉴权、system 独立字段、max_tokens 必填、
结构化输出用 tool + tool_choice 强制、SSE 事件（content_block_delta / message_delta）。
"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator

import httpx

from app.domain.errors import ErrorCode, UpstreamError
from app.domain.models import ProviderRequest, ProviderResult, StreamChunk, Usage
from app.infrastructure.config import Settings

STOP_REASON_MAP = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "tool_use": "stop",
    "max_tokens": "length",
    "pause_turn": "stop",
}


def _parse_usage(raw: dict[str, Any] | None) -> Usage:
    raw = raw or {}
    return Usage(
        input_tokens=int(raw.get("input_tokens") or 0),
        output_tokens=int(raw.get("output_tokens") or 0),
        cached_tokens=int(raw.get("cache_read_input_tokens") or 0),
    )


class AnthropicMessagesAdapter:
    protocol = "anthropic-messages"
    mode = "live"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._client = httpx.AsyncClient(
            base_url=settings.anthropic_base_url,
            timeout=httpx.Timeout(
                settings.http_timeout_seconds,
                connect=settings.http_connect_timeout_seconds,
            ),
        )

    def _headers(self) -> dict[str, str]:
        key = self.settings.anthropic_key()
        if not key:
            raise UpstreamError(
                ErrorCode.UPSTREAM_AUTH_ERROR,
                "缺少 ANTHROPIC_API_KEY（或 config.py 中的 key）",
                status_code=502,
                provider=self.protocol,
                retryable=False,
            )
        return {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

    @staticmethod
    def _split_messages(
        messages: list[dict[str, str]],
    ) -> tuple[str, list[dict[str, str]]]:
        system_parts = [message["content"] for message in messages if message["role"] == "system"]
        merged: list[dict[str, str]] = []
        for message in messages:
            if message["role"] == "system":
                continue
            if merged and merged[-1]["role"] == message["role"]:
                merged[-1]["content"] += "\n\n" + message["content"]
            else:
                merged.append({"role": message["role"], "content": message["content"]})
        return "\n\n".join(system_parts), merged

    def _payload(self, request: ProviderRequest, stream: bool) -> dict[str, Any]:
        system, messages = self._split_messages(request.messages)
        payload: dict[str, Any] = {
            "model": request.route.upstream_model,
            "max_tokens": request.max_tokens,
            "messages": messages,
            "temperature": request.temperature,
            "stream": stream,
        }
        if system:
            payload["system"] = system
        response_format = request.response_format
        if response_format and response_format.get("type") == "json_object":
            payload["tools"] = [
                {
                    "name": "structured_output",
                    "description": "Return the final answer as a single JSON object matching the schema.",
                    "input_schema": response_format.get("schema") or {"type": "object"},
                }
            ]
            payload["tool_choice"] = {"type": "tool", "name": "structured_output"}
        return payload

    def _raise_for_response(self, response: httpx.Response) -> None:
        if response.status_code < 400:
            return
        body: dict[str, Any] = {}
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                body = parsed
        except ValueError:
            pass
        message = ""
        if isinstance(body.get("error"), dict):
            message = str(body["error"].get("message") or "")
        message = message or response.text[:300] or "上游返回错误"

        if response.status_code in (401, 403):
            raise UpstreamError(
                ErrorCode.UPSTREAM_AUTH_ERROR,
                f"上游鉴权失败（HTTP {response.status_code}）：{message}",
                status_code=502,
                provider=self.protocol,
                retryable=False,
                details={"upstream_status": response.status_code},
            )
        if response.status_code == 429 or response.status_code >= 500:
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"上游暂不可用（HTTP {response.status_code}）：{message}",
                status_code=502,
                provider=self.protocol,
                retryable=True,
                details={"upstream_status": response.status_code},
            )
        raise UpstreamError(
            ErrorCode.UPSTREAM_ERROR,
            f"上游拒绝请求（HTTP {response.status_code}）：{message}",
            status_code=502,
            provider=self.protocol,
            retryable=False,
            details={"upstream_status": response.status_code},
        )

    async def complete(self, request: ProviderRequest) -> ProviderResult:
        payload = self._payload(request, stream=False)
        try:
            response = await self._client.post(
                "/v1/messages", json=payload, headers=self._headers()
            )
        except httpx.TimeoutException as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_TIMEOUT,
                f"上游请求超时（{type(exc).__name__}）：{exc}",
                status_code=504,
                provider=self.protocol,
                retryable=True,
            ) from exc
        except httpx.RequestError as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"无法连接上游：{exc}",
                status_code=502,
                provider=self.protocol,
                retryable=True,
            ) from exc

        self._raise_for_response(response)
        data = response.json()

        texts: list[str] = []
        structured: dict[str, Any] | None = None
        for block in data.get("content") or []:
            if block.get("type") == "text":
                texts.append(block.get("text") or "")
            elif block.get("type") == "tool_use" and block.get("name") == "structured_output":
                value = block.get("input")
                if isinstance(value, dict):
                    structured = value
                    texts.append(json.dumps(value, ensure_ascii=False))

        return ProviderResult(
            text="".join(texts),
            usage=_parse_usage(data.get("usage")),
            finish_reason=STOP_REASON_MAP.get(data.get("stop_reason") or "", "stop"),
            structured=structured,
        )

    async def stream(self, request: ProviderRequest) -> AsyncIterator[StreamChunk]:
        payload = self._payload(request, stream=True)
        usage = Usage()
        tool_parts: list[str] = []
        stop_reason = "stop"
        try:
            async with self._client.stream(
                "POST", "/v1/messages", json=payload, headers=self._headers()
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    self._raise_for_response(response)
                async for line in response.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    raw = line[5:].strip()
                    if not raw or raw == "[DONE]":
                        continue
                    try:
                        event = json.loads(raw)
                    except ValueError:
                        continue
                    event_type = event.get("type")
                    if event_type == "message_start":
                        usage = _parse_usage((event.get("message") or {}).get("usage"))
                    elif event_type == "content_block_delta":
                        delta = event.get("delta") or {}
                        if delta.get("type") == "text_delta":
                            yield StreamChunk(text=delta.get("text") or "")
                        elif delta.get("type") == "input_json_delta":
                            tool_parts.append(delta.get("partial_json") or "")
                    elif event_type == "message_delta":
                        delta_usage = event.get("usage") or {}
                        usage.output_tokens = int(
                            delta_usage.get("output_tokens") or usage.output_tokens
                        )
                        stop_reason = STOP_REASON_MAP.get(
                            (event.get("delta") or {}).get("stop_reason") or "", "stop"
                        )
                    elif event_type == "error":
                        message = str((event.get("error") or {}).get("message") or event)
                        raise UpstreamError(
                            ErrorCode.UPSTREAM_ERROR,
                            f"上游流式调用失败：{message[:300]}",
                            status_code=502,
                            provider=self.protocol,
                            retryable=False,
                        )
        except httpx.TimeoutException as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_TIMEOUT,
                f"上游流式请求超时（{type(exc).__name__}）：{exc}",
                status_code=504,
                provider=self.protocol,
                retryable=True,
            ) from exc
        except httpx.RequestError as exc:
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"无法连接上游：{exc}",
                status_code=502,
                provider=self.protocol,
                retryable=True,
            ) from exc

        if tool_parts:
            text = "".join(tool_parts)
            try:
                json.loads(text)
            except ValueError:
                raise UpstreamError(
                    ErrorCode.UPSTREAM_INVALID_JSON,
                    "上游结构化输出不是合法 JSON",
                    status_code=502,
                    provider=self.protocol,
                    retryable=False,
                )
            yield StreamChunk(text=text)

        yield StreamChunk(usage=usage, finish_reason=stop_reason)

    async def aclose(self) -> None:
        await self._client.aclose()
