"""统一错误模型：对外只暴露一套稳定错误码，屏蔽底层协议差异。"""

from __future__ import annotations

from typing import Any


class ErrorCode:
    INVALID_REQUEST = "invalid_request"
    UNAUTHORIZED = "unauthorized"
    UNSUPPORTED_MODEL = "unsupported_model"
    PROMPT_NOT_FOUND = "prompt_not_found"
    PROMPT_EXISTS = "prompt_exists"
    MISSING_VARIABLE = "missing_variable"
    RATE_LIMITED = "rate_limited"
    UPSTREAM_TIMEOUT = "upstream_timeout"
    UPSTREAM_UNAVAILABLE = "upstream_unavailable"
    UPSTREAM_AUTH_ERROR = "upstream_auth_error"
    UPSTREAM_ERROR = "upstream_error"
    UPSTREAM_INVALID_JSON = "upstream_invalid_json"
    RETRY_EXHAUSTED = "retry_exhausted"
    INTERNAL_ERROR = "internal_error"


class GatewayError(Exception):
    """网关统一异常，携带 HTTP 状态码与可重试标记。"""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status_code: int = 400,
        provider: str | None = None,
        retryable: bool = False,
        details: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.provider = provider
        self.retryable = retryable
        self.details = details or {}
        self.headers = headers or {}

    def payload(self, request_id: str | None = None) -> dict[str, Any]:
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "provider": self.provider,
                "retryable": self.retryable,
                "details": self.details,
                "request_id": request_id,
            }
        }


class UpstreamError(GatewayError):
    """上游调用异常；attempts 由重试执行器回填。"""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status_code: int = 502,
        provider: str | None = None,
        retryable: bool = False,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            code,
            message,
            status_code=status_code,
            provider=provider,
            retryable=retryable,
            details=details,
        )
        self.attempts = 1
