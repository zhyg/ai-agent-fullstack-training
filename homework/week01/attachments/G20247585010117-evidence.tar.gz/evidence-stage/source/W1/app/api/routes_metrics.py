"""可观测性查询接口（JSON 调试视图，日志与错误在此再次脱敏）。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request

from app.api.deps import get_container, require_api_key

router = APIRouter(dependencies=[Depends(require_api_key)])


def _redact_records(container, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {**record, "metadata": container.redactor.mapping(record.get("metadata"))}
        for record in records
    ]


@router.get("/v1/metrics")
async def get_metrics(request: Request) -> dict[str, Any]:
    container = get_container(request)
    snapshot = container.metrics.snapshot()
    snapshot["mode"] = container.registry.mode
    snapshot["rate_limit"] = container.limiter.snapshot()
    snapshot["recent_errors"] = _redact_records(container, snapshot.get("recent_errors", []))
    return snapshot


@router.get("/v1/logs")
async def get_logs(request: Request, limit: int = 20, model: str | None = None) -> dict[str, Any]:
    container = get_container(request)
    records = container.metrics.logs(max(1, min(limit, 200)), model)
    return {"data": _redact_records(container, records)}
