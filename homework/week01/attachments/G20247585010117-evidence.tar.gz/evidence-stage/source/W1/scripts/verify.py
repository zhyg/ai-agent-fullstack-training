"""端到端验证脚本：逐项覆盖两个模型、流式、结构化输出、模板引用、可观测性、重试、限流。

用法：
    1) 先启动网关（默认 Mock 上游，无需真实密钥）：
       uvicorn app.main:app --port 8000
    2) 再运行：
       python scripts/verify.py
环境变量：
    GATEWAY_URL  默认 http://127.0.0.1:8000
"""

from __future__ import annotations

import json
import os
import sys

import httpx

BASE_URL = os.getenv("GATEWAY_URL", "http://127.0.0.1:8000")
API_KEY = os.getenv("GATEWAY_API_KEY")
PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"

client = httpx.Client(
    base_url=BASE_URL,
    timeout=60.0,
    headers={"Authorization": f"Bearer {API_KEY}"} if API_KEY else {},
)
results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, evidence: str = "") -> None:
    results.append((name, bool(ok), evidence))
    print(("PASS  " if ok else "FAIL  ") + name + (f"  |  {evidence}" if evidence else ""))


def invoke(payload: dict, headers: dict[str, str] | None = None) -> httpx.Response:
    return client.post("/v1/invoke", json=payload, headers=headers or {})


def user_message(model: str, content: str, **extra) -> dict:
    payload = {"model": model, "messages": [{"role": "user", "content": content}]}
    payload.update(extra)
    return payload


def main() -> int:
    print(f"网关地址: {BASE_URL}\n")

    # ---------- 1. 健康检查 / 模型列表 ----------
    try:
        health = client.get("/health").json()
    except httpx.HTTPError as exc:
        print(f"无法连接网关: {exc}")
        return 2
    check("健康检查", health.get("status") == "ok", f"mode={health.get('mode')}")

    models = client.get("/v1/models").json()["data"]
    providers = {item["id"]: item["provider"] for item in models}
    check(
        "模型 -> 协议路由表",
        providers.get(PRO) == "openai-responses" and providers.get(FLASH) == "anthropic-messages",
        json.dumps(providers, ensure_ascii=False),
    )

    # ---------- 2. 统一错误封装 ----------
    bad = invoke(user_message("gpt-4o", "hi"))
    bad_body = bad.json()
    check(
        "未知模型返回统一 400 错误",
        bad.status_code == 400 and bad_body.get("error", {}).get("code") == "unsupported_model",
        f"status={bad.status_code} code={bad_body.get('error', {}).get('code')}",
    )

    # ---------- 3. 两个模型非流式调用 ----------
    pro = invoke(user_message(PRO, "请用一句话介绍统一 LLM 网关", metadata={"case": "pro-basic"}))
    pro_body = pro.json()
    check(
        "V4 pro 非流式调用（OpenAI Responses 适配器）",
        pro.status_code == 200
        and pro_body.get("provider") == "openai-responses"
        and bool(pro_body.get("output", {}).get("text"))
        and pro_body.get("usage", {}).get("input_tokens", 0) > 0
        and pro_body.get("usage", {}).get("output_tokens", 0) > 0
        and pro_body.get("latency", {}).get("total_ms", 0) > 0,
        f"provider={pro_body.get('provider')} latency={pro_body.get('latency')}",
    )

    flash = invoke(user_message(FLASH, "请用一句话介绍适配器模式"))
    flash_body = flash.json()
    check(
        "V4 flash 非流式调用（Anthropic Messages 适配器）",
        flash.status_code == 200
        and flash_body.get("provider") == "anthropic-messages"
        and bool(flash_body.get("output", {}).get("text")),
        f"provider={flash_body.get('provider')}",
    )

    # ---------- 4. SSE 流式输出 + 首 Token 延迟 ----------
    events: list[tuple[str | None, dict]] = []
    with client.stream("POST", "/v1/invoke", json=user_message(PRO, "流式输出测试", stream=True)) as resp:
        stream_status = resp.status_code
        event_name: str | None = None
        for line in resp.iter_lines():
            line = line.strip()
            if line.startswith("event:"):
                event_name = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                events.append((event_name, json.loads(line.split(":", 1)[1].strip())))

    deltas = [data["text"] for name, data in events if name == "delta"]
    usage_event = next((data for name, data in events if name == "usage"), None)
    done_event = next((data for name, data in events if name == "done"), None)
    stream_text = "".join(deltas)
    check(
        "SSE 流式输出（start/delta/usage/done）",
        stream_status == 200
        and len(deltas) >= 3
        and bool(stream_text)
        and usage_event is not None
        and usage_event["usage"]["output_tokens"] > 0
        and done_event is not None,
        f"deltas={len(deltas)} chars={len(stream_text)}",
    )
    check(
        "流式记录首 Token 延迟（TTFT）",
        usage_event is not None
        and usage_event["latency"]["ttft_ms"] is not None
        and usage_event["latency"]["ttft_ms"] <= usage_event["latency"]["total_ms"],
        f"ttft={usage_event['latency']['ttft_ms'] if usage_event else None}ms "
        f"total={usage_event['latency']['total_ms'] if usage_event else None}ms",
    )
    check(
        "流式 start 事件携带协议信息",
        any(name == "start" and data.get("provider") == "openai-responses" for name, data in events),
    )

    # ---------- 5. 结构化输出 ----------
    schema = {
        "type": "object",
        "properties": {
            "summary": {"type": "string"},
            "score": {"type": "integer"},
            "tags": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["summary", "score", "tags"],
        "additionalProperties": False,
    }
    structured = invoke(
        user_message(
            PRO,
            "请输出结构化结果",
            response_format={"type": "json_object", "schema": schema, "strict": True},
        )
    )
    structured_body = structured.json()
    structured_json = structured_body.get("output", {}).get("json")
    check(
        "结构化输出（JSON Schema 校验）",
        structured.status_code == 200
        and isinstance(structured_json, dict)
        and set(schema["required"]) <= set(structured_json),
        json.dumps(structured_json, ensure_ascii=False)[:160],
    )

    # ---------- 6. 提示词模板：存储 / 变量替换 / 版本引用 ----------
    created = client.post(
        "/v1/prompts",
        json={
            "name": "support-reply",
            "template": "你好 {{name}}，请回答这个问题：{{question}}",
            "description": "客服回复模板",
        },
    )
    check(
        "模板创建（v1）",
        created.status_code == 201 and created.json().get("version") == 1,
        f"status={created.status_code}",
    )

    def template_invoke(version: int | None) -> httpx.Response:
        prompt = {"name": "support-reply", "variables": {"name": "小明", "question": "退款流程"}}
        if version is not None:
            prompt["version"] = version
        return invoke({"model": PRO, "prompt": prompt, "messages": [{"role": "user", "content": "请处理"}]})

    v1 = template_invoke(1)
    check(
        "模板变量替换（v1）",
        v1.status_code == 200 and "你好 小明" in v1.json()["output"]["text"],
        v1.json().get("output", {}).get("text", "")[:80],
    )

    v2_created = client.post(
        "/v1/prompts/support-reply/versions",
        json={"template": "您好 {{name}}，问题：{{question}}", "description": "更正式的语气"},
    )
    check(
        "模板追加版本（v2）",
        v2_created.status_code == 201 and v2_created.json().get("version") == 2,
        f"status={v2_created.status_code}",
    )

    pinned = template_invoke(1)
    latest = template_invoke(None)
    check(
        "版本引用锁定（version=1 仍走旧模板）",
        pinned.status_code == 200 and "你好 小明" in pinned.json()["output"]["text"],
    )
    check(
        "默认引用最新版本（v2）",
        latest.status_code == 200 and "您好 小明" in latest.json()["output"]["text"],
    )

    missing = invoke(
        {
            "model": PRO,
            "prompt": {"name": "support-reply", "variables": {"name": "小明"}},
        }
    )
    check(
        "缺少模板变量返回 400",
        missing.status_code == 400
        and missing.json().get("error", {}).get("code") == "missing_variable",
        f"status={missing.status_code}",
    )

    # ---------- 7. 可观测性 ----------
    cached = invoke(
        user_message(
            PRO,
            "这是一段用于验证 cached token 分类统计的较长文本，"
            "请忽略具体内容，只需要确认网关能够正确记录输入、输出与缓存命中的 token 数量。"
            "为了提高输入 token 数量以便观察缓存命中比例，这里继续补充一些与业务无关的说明文字，"
            "包括网关如何屏蔽底层鉴权、如何归一化响应结构、如何统计每次调用的首 token 延迟等细节。",
        ),
        headers={"X-Mock-Cached-Tokens": "32"},
    )
    cached_usage = cached.json().get("usage", {})
    check(
        "Token 分类统计（含 cached_tokens）",
        cached.status_code == 200 and cached_usage.get("cached_tokens") == 32,
        f"usage={json.dumps(cached_usage, ensure_ascii=False)}",
    )

    metrics = client.get("/v1/metrics").json()
    totals = metrics["totals"]
    model_stats = metrics["models"]
    sum_total_tokens = sum(item["tokens"]["total_tokens"] for item in model_stats.values())
    check(
        "按模型聚合 Token 统计",
        totals["tokens"]["input_tokens"] > 0
        and totals["tokens"]["cached_tokens"] >= 32
        and PRO in model_stats
        and FLASH in model_stats
        and totals["tokens"]["total_tokens"] == sum_total_tokens,
        f"models={list(model_stats)} total_tokens={totals['tokens']['total_tokens']}",
    )
    check(
        "延迟统计（平均 / 最大 / 首 Token）",
        totals["latency_ms"]["avg_total_ms"] is not None
        and totals["latency_ms"]["max_total_ms"] is not None
        and totals["latency_ms"]["avg_ttft_ms"] is not None,
        json.dumps(totals["latency_ms"], ensure_ascii=False),
    )
    logs = client.get("/v1/logs", params={"limit": 100}).json()["data"]
    check(
        "调用日志可查询",
        len(logs) >= 8 and any(item["stream"] for item in logs),
        f"logs={len(logs)}",
    )

    # ---------- 8. 重试 ----------
    recovered = invoke(user_message(PRO, "重试测试"), headers={"X-Mock-Fail-Times": "2"})
    check(
        "可重试错误自动恢复（第 3 次成功）",
        recovered.status_code == 200 and recovered.json().get("attempts") == 3,
        f"status={recovered.status_code} attempts={recovered.json().get('attempts')}",
    )
    exhausted = invoke(user_message(PRO, "重试耗尽测试"), headers={"X-Mock-Fail-Times": "9"})
    exhausted_body = exhausted.json()
    check(
        "重试耗尽返回统一错误（retry_exhausted）",
        exhausted.status_code == 502
        and exhausted_body.get("error", {}).get("code") == "retry_exhausted"
        and exhausted_body.get("error", {}).get("details", {}).get("attempts") == 3,
        f"status={exhausted.status_code} details={json.dumps(exhausted_body.get('error', {}).get('details'), ensure_ascii=False)}",
    )
    metrics_after_retry = client.get("/v1/metrics").json()
    check(
        "重试次数记录到指标",
        metrics_after_retry["totals"]["retries"] >= 2,
        f"retries={metrics_after_retry['totals']['retries']}",
    )

    # ---------- 9. 按模型限流 ----------
    rate_info = metrics_after_retry["rate_limit"]
    limit = rate_info["limit_per_window"]
    if limit <= 0:
        check("按模型限流", True, "已通过 RATE_LIMIT_PER_MINUTE=0 关闭，跳过")
    else:
        active = rate_info["active_requests"].get(FLASH, 0)
        statuses: list[int] = []
        rate_body: dict = {}
        retry_after = None
        for _ in range(max(1, limit - active + 3)):
            response = invoke(user_message(FLASH, "限流测试"))
            statuses.append(response.status_code)
            if response.status_code == 429:
                rate_body = response.json()
                retry_after = response.headers.get("retry-after")
                break
        check(
            "按模型限流返回 429（含 Retry-After）",
            429 in statuses
            and rate_body.get("error", {}).get("code") == "rate_limited"
            and retry_after is not None,
            f"limit={limit}/{rate_info['window_seconds']}s sent={len(statuses)} retry_after={retry_after}",
        )
        other_model = invoke(user_message(PRO, "限流隔离验证"))
        check(
            "限流按模型独立（另一模型不受影响）",
            other_model.status_code == 200,
            f"status={other_model.status_code}",
        )

    # ---------- 汇总 ----------
    failed = [name for name, ok, _ in results if not ok]
    print(f"\n{'=' * 60}\n{len(results) - len(failed)}/{len(results)} 项通过")
    if failed:
        print("失败项：")
        for name in failed:
            print(f"  - {name}")
        return 1
    print("全部验证通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
