# 统一 LLM API 网关

对调用方暴露一套接口，对内按上游协议拆分适配器。默认启动内置 Mock 上游，不需要密钥。

## 启动

```powershell
cd d:\WORK\AGGENT\W1
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

启动后可访问 `/docs`、`/health`；浏览器控制台见下一节。先发一次请求（`model` 可选 `deepseek-v4-pro`（OpenAI Responses）或 `deepseek-v4-flash`（Anthropic Messages），无默认值）：

```powershell
'{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"你好"}]}' | curl.exe -s http://127.0.0.1:8000/v1/invoke -H "Content-Type: application/json" --data-binary "@-"
```

返回：

```json
{
  "id": "req_2f6d9b0c1a4e8f30",
  "model": "deepseek-v4-pro",
  "provider": "openai-responses",
  "mode": "mock",
  "output": { "text": "...", "json": null },
  "usage": { "input_tokens": 21, "output_tokens": 58, "cached_tokens": 0, "total_tokens": 79 },
  "latency": { "total_ms": 26.01, "ttft_ms": null },
  "attempts": 1,
  "finish_reason": "stop"
}
```

另开终端跑验证与测试：

```powershell
python scripts/verify.py        # 24 项端到端检查
python -m pytest tests -q       # 41 项单元/集成测试
```

本机若因第三方 pytest 插件（如 langsmith）加载失败，先执行 `$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD="1"`。

连接真实上游：

```powershell
$env:GATEWAY_USE_MOCK = "0"
$env:OPENAI_BASE_URL = "https://api.openai.com/v1"
$env:ANTHROPIC_BASE_URL = "https://api.anthropic.com"
$env:OPENAI_API_KEY = "sk-..."
$env:ANTHROPIC_API_KEY = "sk-..."
```

未设置密钥时会读取 `config.py` 里的 `key`。live 模式缺密钥、开启鉴权但没配 Key，启动会直接失败。

## 控制台

服务启动后，浏览器打开：

```
http://127.0.0.1:8000/console
```

页面有四个页签：

- 调用：选模型、增删消息、引用模板、流式输出、JSON Schema 结构化；流式过程中可暂停/继续（只停页面刷新，请求继续接收）或停止；结果区展示输入/输出/缓存/合计 token、总耗时、TTFT、attempts 和事件流，并累计本页消耗
- 模板：查看列表、新建模板、追加版本
- 指标：全局与分模型的调用数、错误数、重试数、token、平均耗时
- 日志：按条数和模型过滤调用记录，列出耗时、TTFT、输入/输出 token，点行看完整 JSON

顶部网关地址是下拉框（当前站点或常用端口），选「自定义」可填其他地址。顶部「网关 Key」只用于入站鉴权，不是上游模型密钥；上游地址与 Key 在「参数 → OpenAI 地址 / Anthropic 地址 / 对应 Key」里填写后保存，地址支持中转或代理，配置只存在进程内存、重启失效，Key 不回显。

左上角 **Mock** 开关运行时切换 mock / live，立即生效，等价接口：

```powershell
'{"mode":"live"}' | curl.exe -s http://127.0.0.1:8000/v1/runtime/mode -H "Content-Type: application/json" --data-binary "@-"
```

切到 live 需要 `OPENAI_API_KEY` 和 `ANTHROPIC_API_KEY`，缺失时接口返回 400，开关自动回弹。若顶部 Mock 开关是灰的，说明后端进程较旧、没有运行时接口，重启 uvicorn 即可。

结果区右上角的「脱敏显示」默认开启，遮蔽手机号、身份证、银行卡、邮箱和密钥，只影响页面展示，接口返回仍是原文，方便对照排查。关闭后显示原文。

页面由网关自身提供（`app/static/console.html`），不要直接用 `file://` 打开，否则请求不到接口。服务跑在远程或容器时，把地址换成实际主机和端口，并让 uvicorn 监听 `0.0.0.0`。

## 调用

`POST /v1/invoke`，请求字段：

| 字段 | 可选值 | 默认 |
| --- | --- | --- |
| `model` | `deepseek-v4-pro`（OpenAI Responses）/ `deepseek-v4-flash`（Anthropic Messages） | 无，必填 |
| `messages` | `{role, content}` 数组，`role` 取 `system` / `user` / `assistant` | `[]` |
| `prompt` | 可选，`{name, version?, variables}`，渲染后作为 system 消息插到最前；`version` 取已有版本号，`variables` 的键对应模板占位符 | 不传；`version` 缺省最新，`variables` 缺省 `{}` |
| `stream` | `true`（SSE）/ `false`（一次性返回） | `false` |
| `response_format.type` | `text` / `json_object`（必须同时给 `schema`） | `text` |
| `response_format.strict` | `true`（再用 schema 校验一次）/ `false`（只解析 JSON） | `false` |
| `temperature` | 浮点数 | `0.7` |
| `max_tokens` | 正整数 | `1024` |
| `metadata` | 任意键值，落日志前脱敏 | `{}` |

示例均为单行命令，可直接复制执行；JSON 通过管道传给 curl，避免 PowerShell 丢引号。Git Bash / macOS 把 `curl.exe` 换成 `curl`，把管道改成 `-d '<json>'`。

非流式返回结构见上一节。流式事件：`start` → `delta`（多次）→ `usage` → `done`。首 token 前发生可重试错误时会先插入 `retry`；失败则发 `error` 结束。`stream` 设为 `true`，`-N` 关闭客户端缓冲：

```powershell
'{"model":"deepseek-v4-flash","stream":true,"messages":[{"role":"user","content":"流式输出"}]}' | curl.exe -N -s http://127.0.0.1:8000/v1/invoke -H "Content-Type: application/json" --data-binary "@-"
```

结构化输出把 schema 放进 `response_format`，`strict: true` 时网关会用 JSON Schema 再校验一次：

```powershell
'{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"输出摘要"}],"response_format":{"type":"json_object","schema":{"type":"object","properties":{"summary":{"type":"string"},"score":{"type":"integer"}},"required":["summary","score"]},"strict":true}}' | curl.exe -s http://127.0.0.1:8000/v1/invoke -H "Content-Type: application/json" --data-binary "@-"
```

新建模板：`name` 必填（字母/数字/下划线/短横线，最长 64），`description` 可选，`template` 用 `{{变量名}}` 占位：

```powershell
'{"name":"support-reply","template":"你好 {{name}}，请回答：{{question}}"}' | curl.exe -s http://127.0.0.1:8000/v1/prompts -H "Content-Type: application/json" --data-binary "@-"
```

追加版本：`name` 必须是已存在的模板，`description` 可选：

```powershell
'{"template":"您好 {{name}}，问题：{{question}}"}' | curl.exe -s http://127.0.0.1:8000/v1/prompts/support-reply/versions -H "Content-Type: application/json" --data-binary "@-"
```

调用模板：`prompt.version` 不传用最新版本，`variables` 需覆盖模板占位符，缺变量返回 `400 missing_variable`：

```powershell
'{"model":"deepseek-v4-pro","prompt":{"name":"support-reply","version":1,"variables":{"name":"小明","question":"怎么退货"}}}' | curl.exe -s http://127.0.0.1:8000/v1/invoke -H "Content-Type: application/json" --data-binary "@-"
```

指标与日志：`GET /v1/metrics`（全局与分模型 token、延迟、TTFT、重试次数）、`GET /v1/logs?limit=20&model=...`。

## 模型与路由

| 模型 | 上游协议 | 适配器 |
| --- | --- | --- |
| `deepseek-v4-pro` | OpenAI Responses | `app/infrastructure/adapters/openai_responses.py` |
| `deepseek-v4-flash` | Anthropic Messages | `app/infrastructure/adapters/anthropic_messages.py` |

设置 `GATEWAY_USE_MOCK=0` 后走真实 HTTP。代码分 `api` / `application` / `domain` / `infrastructure` 四层，端口在 `app/domain/ports.py`，实例在 `app/container.py` 组装；分层职责与常见改动落点见 [docs/architecture.md](docs/architecture.md)。

## 日志与脱敏

日志以 JSON 打到 stdout，`request_id` 由中间件写入 contextvar，业务代码不用逐层传参：

```json
{"ts":"2026-11-16T12:23:09.552Z","level":"WARNING","logger":"gateway","event":"upstream.retry","request_id":"req_113fb85e16344d44","model":"deepseek-v4-pro","protocol":"openai-responses","attempt":1,"error_code":"upstream_unavailable","delay_ms":192}
```

脱敏默认 `mixed`：凭据和 PII 打码，提示词正文与模板变量做 HMAC 哈希。日志写入层有统一 Filter 兜底，错误响应、`/v1/logs` 和 `/v1/metrics` 返回前也会再处理一次。

| 数据 | 处理结果 |
| --- | --- |
| `sk-...`、`Bearer ...`、`x-api-key` | `sk-e***4f5` |
| 手机号 / 邮箱 / 身份证 / 银行卡 / IP | `138****5678`、`a***@x.com`、`10.0.3.***` |
| 提示词正文、模板变量 | `sha256:867f239bba99a2f2` |

`REDACTION_MODE` 可选 `mixed`、`mask`、`hash`、`drop`、`off`。生产环境要设置 `REDACTION_HASH_SALT`，否则使用默认盐。额外规则用 `REDACTION_EXTRA_PATTERNS` 追加，多条以 `||` 分隔。

需要限制调用方时开启鉴权：

```powershell
$env:GATEWAY_AUTH_ENABLED = "1"
$env:GATEWAY_API_KEYS = "sk-client-a,sk-client-b"
```

请求带 `X-API-Key: sk-client-a` 或 `Authorization: Bearer sk-client-a`。`/health`、`/v1/models` 不校验。验证脚本支持 `$env:GATEWAY_API_KEY`。

## 错误码

| code | HTTP | 说明 |
| --- | --- | --- |
| `invalid_request` | 400 / 413 | JSON、字段或体积不合法 |
| `unauthorized` | 401 | 缺少或错误的 API Key |
| `unsupported_model` | 400 | 模型未注册 |
| `missing_variable` | 400 | 模板变量缺失 |
| `prompt_not_found` / `prompt_exists` | 404 / 409 | 模板不存在 / 重名 |
| `rate_limited` | 429 | 触发按模型限流，带 `Retry-After` |
| `upstream_timeout` | 504 | 上游超时 |
| `upstream_unavailable` | 502 | 上游 5xx / 429 / 连接失败 |
| `upstream_auth_error` | 502 | 上游鉴权失败 |
| `upstream_error` | 502 | 其他上游错误 |
| `upstream_invalid_json` | 502 | 结构化输出非法或不符合 schema |
| `retry_exhausted` | 502 | 重试次数用尽，`details.attempts` 为尝试次数 |
| `internal_error` | 500 | 未预期异常 |

错误体：

```json
{"error":{"code":"retry_exhausted","message":"...","provider":"openai-responses","retryable":false,"details":{"attempts":3},"request_id":"req_..."}}
```

重试只针对 `retryable` 为 true 的情况（超时、5xx、连接失败），退避为 `base * 2^(n-1)` 加抖动，默认 3 次尝试，上限 2 秒。流式请求只在首 token 前重试，避免重复输出。限流按模型滑动窗口，默认每分钟 20 次，超限不占用重试次数。

## 配置

| 环境变量 | 默认值 | 说明 |
| --- | --- | --- |
| `GATEWAY_USE_MOCK` | `1` | `0` 时走真实上游 |
| `OPENAI_BASE_URL` | `https://api.openai.com/v1` | Responses API 地址 |
| `ANTHROPIC_BASE_URL` | `https://api.anthropic.com` | Messages API 地址 |
| `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` | 读 `config.py` | 上游密钥，启动日志不会输出 |
| `MODEL_PRO_UPSTREAM` / `MODEL_FLASH_UPSTREAM` | `deepseek-v4-pro` / `deepseek-v4-flash` | 上游模型名 |
| `HTTP_TIMEOUT_SECONDS` | `60` | 上游读超时 |
| `HTTP_CONNECT_TIMEOUT_SECONDS` | `15` | 上游连接超时，网络不可达时快速失败 |
| `RETRY_MAX_ATTEMPTS` | `3` | 含首次调用 |
| `RETRY_BASE_DELAY_MS` / `RETRY_MAX_DELAY_MS` | `200` / `2000` | 退避参数 |
| `RETRY_JITTER` | `0.2` | 抖动比例 |
| `RATE_LIMIT_PER_MINUTE` | `20` | 每模型每分钟上限，`0` 关闭 |
| `LOG_LEVEL` | `INFO` | 日志级别 |
| `REDACTION_MODE` | `mixed` | 脱敏模式 |
| `REDACTION_HASH_SALT` | 本地默认值 | 哈希加盐 |
| `REDACTION_EXTRA_PATTERNS` | 空 | 自定义正则，`||` 分隔 |
| `GATEWAY_AUTH_ENABLED` / `GATEWAY_API_KEYS` | `0` / 空 | 入站鉴权 |
| `MAX_REQUEST_BYTES` | `1000000` | 请求体上限 |
| `APP_ENV` | `local` | 环境标识 |

Mock 模式下可用请求头模拟异常：`X-Mock-Fail-Times`（前 N 次返回 503）、`X-Mock-Total-Ms`、`X-Mock-Ttft-Ms`、`X-Mock-Chunk-Delay-Ms`、`X-Mock-Cached-Tokens`。

`GATEWAY_USE_MOCK` 只决定启动时的默认模式；运行中可通过控制台开关或 `POST /v1/runtime/mode` 切换，重启后回到默认。

切到 live 后请求会真正发往 base URL。默认 `api.openai.com` 在部分网络下不可达，可把「OpenAI 地址」改为可达的中转地址（OpenAI Responses 兼容，通常以 `/v1` 结尾）；地址或 Key 保存后立即生效，不需要重启。

上游配置也可以直接调接口，四个字段都可选：

```powershell
'{"openai_base_url":"https://your-relay.example/v1","openai_api_key":"sk-..."}' | curl.exe -s http://127.0.0.1:8000/v1/runtime/upstream -H "Content-Type: application/json" --data-binary "@-"
```

### 内地可直连的 Anthropic 兼容协议

`deepseek-v4-flash` 走 Anthropic Messages 协议，DeepSeek 提供内地直连的兼容端点：

| 配置项 | 值 |
| --- | --- |
| Anthropic 地址 | `https://api.deepseek.com/anthropic` |
| Anthropic 模型名 | `deepseek-chat` |
| Key | DeepSeek 的 `sk-...` |

实测非流式、SSE 流式、JSON Schema 结构化输出均可用，短回答延迟约 1 秒。

OpenAI Responses 协议国内支持较少，`deepseek-v4-pro` 仍需可达的中转地址；国内多数厂商只提供 Chat Completions，若要直连需要新增适配器（当前未实现）。

## 测试

`scripts/verify.py` 对运行中的服务做六类检查：双模型调用、SSE 与 TTFT、JSON Schema 输出、模板版本、指标与日志、重试与限流，当前 24/24 通过。

`tests/` 覆盖重试策略、脱敏规则与幂等、输出归一化、API Key 鉴权，以及通过 TestClient 触发的模板渲染、重试与限流、运行时模式切换、错误体、日志脱敏断言，当前 41 项通过。`tests/conftest.py` 固定 Mock 上游、关闭鉴权并缩短退避，不受本机环境变量影响。

指标、模板、调用日志都在内存里，重启即清空；验证脚本建议在新进程上跑，避免上一轮请求占用限流窗口。Prometheus 指标、持久化、熔断在阶段 2 处理。
