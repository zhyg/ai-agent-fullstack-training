from __future__ import annotations

import asyncio

import pytest

from app.application.resilience import RetryExecutor
from app.domain.errors import ErrorCode, UpstreamError
from app.domain.retry import RetryPolicy


def _retryable() -> UpstreamError:
    return UpstreamError(
        ErrorCode.UPSTREAM_UNAVAILABLE,
        "boom",
        status_code=503,
        retryable=True,
    )


def test_should_retry_only_retryable_and_before_limit() -> None:
    policy = RetryPolicy(max_attempts=3)
    assert policy.should_retry(_retryable(), attempt=1) is True
    assert policy.should_retry(_retryable(), attempt=2) is True
    assert policy.should_retry(_retryable(), attempt=3) is False

    fatal = UpstreamError(ErrorCode.UPSTREAM_AUTH_ERROR, "401", retryable=False)
    assert policy.should_retry(fatal, attempt=1) is False


def test_delay_is_exponential_and_capped() -> None:
    policy = RetryPolicy(max_attempts=6, base_delay_ms=200, max_delay_ms=2000, jitter=0)
    assert [policy.delay_ms(attempt) for attempt in range(1, 6)] == [
        200,
        400,
        800,
        1600,
        2000,
    ]


def test_delay_jitter_stays_in_range() -> None:
    policy = RetryPolicy(base_delay_ms=1000, max_delay_ms=1000, jitter=0.5)
    for _ in range(50):
        delay = policy.delay_ms(1)
        assert 500 <= delay <= 1500


def test_invalid_policy_rejected() -> None:
    with pytest.raises(ValueError):
        RetryPolicy(max_attempts=0)
    with pytest.raises(ValueError):
        RetryPolicy(jitter=1.5)


def test_executor_retries_until_success() -> None:
    attempts = {"count": 0}
    hooks: list[tuple[int, int]] = []

    async def flaky() -> str:
        attempts["count"] += 1
        if attempts["count"] < 3:
            raise _retryable()
        return "ok"

    executor = RetryExecutor(RetryPolicy(base_delay_ms=1, max_delay_ms=2, jitter=0))
    result, used = asyncio.run(
        executor.run(flaky, on_retry=lambda attempt, error, delay: hooks.append((attempt, delay)))
    )
    assert (result, used) == ("ok", 3)
    assert attempts["count"] == 3
    assert [attempt for attempt, _ in hooks] == [1, 2]


def test_executor_does_not_retry_fatal_error() -> None:
    attempts = {"count": 0}

    async def fatal() -> str:
        attempts["count"] += 1
        raise UpstreamError(ErrorCode.UPSTREAM_AUTH_ERROR, "401", retryable=False)

    executor = RetryExecutor(RetryPolicy(base_delay_ms=1, jitter=0))
    with pytest.raises(UpstreamError) as info:
        asyncio.run(executor.run(fatal))
    assert info.value.attempts == 1
    assert attempts["count"] == 1
