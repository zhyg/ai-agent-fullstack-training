"""固定测试环境：Mock 上游、关闭鉴权、缩短重试退避，避免受外部环境变量影响。"""

from __future__ import annotations

import os

os.environ["GATEWAY_USE_MOCK"] = "1"
os.environ["GATEWAY_AUTH_ENABLED"] = "0"
os.environ["RETRY_BASE_DELAY_MS"] = "1"
os.environ["RETRY_MAX_DELAY_MS"] = "2"
os.environ["RETRY_JITTER"] = "0"
os.environ["RATE_LIMIT_PER_MINUTE"] = "20"
os.environ["REDACTION_MODE"] = "mixed"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture()
def client():
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture(autouse=True)
def reset_runtime_state():
    container = app.state.container
    container.registry.set_mode("mock")
    with container.limiter._lock:
        container.limiter._buckets.clear()
    yield
