from __future__ import annotations

import pytest

from app.application.dto import ResponseFormatCommand
from app.application.output_normalizer import OutputNormalizer
from app.domain.errors import ErrorCode, GatewayError
from app.domain.models import ProviderResult, Usage

SCHEMA = {
    "type": "object",
    "properties": {"summary": {"type": "string"}, "score": {"type": "integer"}},
    "required": ["summary", "score"],
}


def _result(text: str, structured=None) -> ProviderResult:
    return ProviderResult(text=text, usage=Usage(), structured=structured)


def test_text_mode_passthrough() -> None:
    text, structured = OutputNormalizer().normalize(None, _result("hello"))
    assert (text, structured) == ("hello", None)


def test_json_object_parses_and_validates() -> None:
    normalizer = OutputNormalizer()
    text, structured = normalizer.normalize(
        ResponseFormatCommand(type="json_object", schema=SCHEMA, strict=True),
        _result('{"summary": "ok", "score": 1}'),
    )
    assert structured == {"summary": "ok", "score": 1}
    assert text == '{"summary": "ok", "score": 1}'


def test_adapter_structured_result_preferred() -> None:
    _, structured = OutputNormalizer().normalize(
        ResponseFormatCommand(type="json_object", schema=SCHEMA, strict=True),
        _result("ignored", structured={"summary": "s", "score": 2}),
    )
    assert structured == {"summary": "s", "score": 2}


def test_invalid_json_raises_unified_error() -> None:
    with pytest.raises(GatewayError) as info:
        OutputNormalizer().normalize(
            ResponseFormatCommand(type="json_object", schema=SCHEMA, strict=False),
            _result("not-json"),
        )
    assert info.value.code == ErrorCode.UPSTREAM_INVALID_JSON


def test_schema_violation_raises_unified_error() -> None:
    with pytest.raises(GatewayError) as info:
        OutputNormalizer().normalize(
            ResponseFormatCommand(type="json_object", schema=SCHEMA, strict=True),
            _result('{"summary": "missing score"}'),
        )
    assert info.value.code == ErrorCode.UPSTREAM_INVALID_JSON
