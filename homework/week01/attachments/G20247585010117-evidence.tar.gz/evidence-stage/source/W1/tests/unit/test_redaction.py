from __future__ import annotations

from app.domain.redaction import RedactionPolicy, Redactor


def _redactor(mode: str = "mask", salt: str = "test-salt") -> Redactor:
    return Redactor(RedactionPolicy(mode=mode, hash_salt=salt))


def test_masks_bearer_and_api_key() -> None:
    redactor = _redactor()
    output = redactor.text("Authorization: Bearer sk-abcdef1234567890")
    assert "sk-abcdef1234567890" not in output
    assert "***" in output

    header = redactor.text("x-api-key: abcdef1234567890")
    assert "abcdef1234567890" not in header


def test_masks_pii() -> None:
    redactor = _redactor()
    assert redactor.text("联系 13812345678") == "联系 138****5678"
    assert redactor.text("邮箱 alice@example.com") == "邮箱 a***@example.com"
    assert redactor.text("身份证 110101199003071234") == "身份证 110101********1234"
    assert redactor.text("卡号 6222021234567890") == "卡号 **** **** **** 7890"
    assert redactor.text("来源 10.0.3.15") == "来源 10.0.3.***"


def test_masking_is_idempotent() -> None:
    redactor = _redactor()
    text = "Bearer sk-abcdef1234567890 13812345678 alice@example.com"
    once = redactor.text(text)
    assert redactor.text(once) == once


def test_mapping_masks_sensitive_keys() -> None:
    redactor = _redactor()
    result = redactor.mapping(
        {"api_key": "abcdef1234567890", "case": "pro-basic", "nested": {"token": "t" * 12}}
    )
    assert result["api_key"] == "abcd***890"
    assert result["case"] == "pro-basic"
    assert result["nested"]["token"] == "tttt***ttt"


def test_mixed_mode_hashes_prompt_but_masks_credentials() -> None:
    redactor = _redactor("mixed")
    hashed = redactor.prompt("你好 小明，手机号 13812345678")
    assert hashed.startswith("sha256:")
    assert "小明" not in hashed
    assert "13812345678" not in hashed
    assert "138****5678" in redactor.text("手机号 13812345678")


def test_hash_is_deterministic_and_salt_dependent() -> None:
    first = _redactor("hash", "salt-a").hash_text("same-value")
    second = _redactor("hash", "salt-a").hash_text("same-value")
    other = _redactor("hash", "salt-b").hash_text("same-value")
    assert first == second
    assert first != other
    assert "same-value" not in first


def test_off_mode_keeps_text() -> None:
    redactor = _redactor("off")
    text = "Bearer sk-abcdef1234567890 13812345678"
    assert redactor.text(text) == text
    assert redactor.prompt(text) == text


def test_drop_mode_replaces_values() -> None:
    redactor = _redactor("drop")
    assert redactor.text("secret") == "[redacted]"
    assert redactor.mapping({"api_key": "abc"})["api_key"] == "[redacted]"


def test_recursive_mapping_handles_lists_and_depth() -> None:
    redactor = _redactor()
    result = redactor.mapping({"items": [{"phone": "13812345678"}]})
    assert result["items"][0]["phone"] == "138****5678"

    deep: dict = {}
    cursor = deep
    for _ in range(8):
        child: dict = {}
        cursor["next"] = child
        cursor = child
    assert redactor.mapping(deep)["next"]["next"]["next"]["next"]["next"]["next"]["next"] == {
        "_truncated": True
    }
