from __future__ import annotations

import hashlib

import pytest

from app.domain.errors import ErrorCode, GatewayError
from app.infrastructure.auth import ApiKeyAuthenticator

KEYS = ["sk-alpha-123456", "sk-beta-654321"]


def test_disabled_auth_allows_all() -> None:
    authenticator = ApiKeyAuthenticator(enabled=False, keys=[])
    assert authenticator.authenticate(None, None) is None


def test_missing_key_rejected() -> None:
    authenticator = ApiKeyAuthenticator(enabled=True, keys=KEYS)
    with pytest.raises(GatewayError) as info:
        authenticator.authenticate(None, None)
    assert info.value.status_code == 401
    assert info.value.code == ErrorCode.UNAUTHORIZED
    assert info.value.headers["WWW-Authenticate"] == "Bearer"


def test_bearer_and_api_key_header_accepted() -> None:
    authenticator = ApiKeyAuthenticator(enabled=True, keys=KEYS)
    expected_id = "key_" + hashlib.sha256(b"sk-alpha-123456").hexdigest()[:8]
    assert authenticator.authenticate("Bearer sk-alpha-123456", None) == expected_id
    assert authenticator.authenticate(None, "sk-beta-654321").startswith("key_")


def test_wrong_key_rejected() -> None:
    authenticator = ApiKeyAuthenticator(enabled=True, keys=KEYS)
    with pytest.raises(GatewayError):
        authenticator.authenticate("Bearer wrong-key", None)
