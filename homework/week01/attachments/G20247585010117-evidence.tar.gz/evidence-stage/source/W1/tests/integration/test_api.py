from __future__ import annotations

import json

import httpx
from fastapi.testclient import TestClient

PRO_MODEL = "deepseek-v4-pro"
FLASH_MODEL = "deepseek-v4-flash"


def _message(content: str = "hi") -> list[dict[str, str]]:
    return [{"role": "user", "content": content}]


def _invoke(
    client: TestClient,
    model: str = PRO_MODEL,
    headers: dict[str, str] | None = None,
    **overrides,
) -> httpx.Response:
    payload = {"model": model, "messages": _message(), **overrides}
    return client.post("/v1/invoke", json=payload, headers=headers or {})


def _stream_events(client: TestClient, headers: dict[str, str] | None = None) -> list[str]:
    names: list[str] = []
    with client.stream(
        "POST",
        "/v1/invoke",
        headers=headers or {},
        json={"model": FLASH_MODEL, "stream": True, "messages": _message()},
    ) as response:
        assert response.status_code == 200
        for line in response.iter_lines():
            if line.startswith("event:"):
                names.append(line.split(":", 1)[1].strip())
    return names


def test_health_and_models(client: TestClient) -> None:
    health = client.get("/health").json()
    assert health["status"] == "ok"

    models = {item["id"]: item["provider"] for item in client.get("/v1/models").json()["data"]}
    assert models == {
        "deepseek-v4-pro": "openai-responses",
        "deepseek-v4-flash": "anthropic-messages",
    }


def test_invoke_both_protocols(client: TestClient) -> None:
    pro = client.post(
        "/v1/invoke",
        json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert pro.status_code == 200
    assert pro.json()["provider"] == "openai-responses"

    flash = client.post(
        "/v1/invoke",
        json={"model": "deepseek-v4-flash", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert flash.status_code == 200
    assert flash.json()["provider"] == "anthropic-messages"


def test_unsupported_model_uses_unified_error(client: TestClient) -> None:
    response = client.post(
        "/v1/invoke",
        json={"model": "unknown", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "unsupported_model"
    assert response.json()["error"]["request_id"]


def test_streaming_events(client: TestClient) -> None:
    events: list[tuple[str, dict]] = []
    with client.stream(
        "POST",
        "/v1/invoke",
        json={
            "model": "deepseek-v4-pro",
            "stream": True,
            "messages": [{"role": "user", "content": "hi"}],
        },
    ) as response:
        assert response.status_code == 200
        event = None
        for line in response.iter_lines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                events.append((event, json.loads(line.split(":", 1)[1])))

    names = [name for name, _ in events]
    assert names[0] == "start"
    assert names[-2:] == ["usage", "done"]
    assert len([1 for name in names if name == "delta"]) >= 3


def test_logs_endpoint_redacts_metadata(client: TestClient) -> None:
    response = client.post(
        "/v1/invoke",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "hi"}],
            "metadata": {"api_key": "sk-verysecret123456", "case": "redaction"},
        },
    )
    assert response.status_code == 200

    logs = client.get("/v1/logs", params={"limit": 50}).json()["data"]
    record = next(item for item in logs if item["metadata"].get("case") == "redaction")
    assert record["metadata"]["api_key"] != "sk-verysecret123456"
    assert "***" in record["metadata"]["api_key"]


def test_prompt_template_rendering_and_version(client: TestClient) -> None:
    created = client.post(
        "/v1/prompts",
        json={"name": "review-reply", "template": "V1 主题：{{topic}}"},
    )
    assert created.status_code == 201
    versioned = client.post(
        "/v1/prompts/review-reply/versions",
        json={"template": "V2 主题：{{topic}}"},
    )
    assert versioned.status_code == 201

    pinned = _invoke(
        client,
        prompt={"name": "review-reply", "version": 1, "variables": {"topic": "限流"}},
    )
    assert pinned.status_code == 200
    assert "V1 主题：限流" in pinned.json()["output"]["text"]

    latest = _invoke(client, prompt={"name": "review-reply", "variables": {"topic": "重试"}})
    assert latest.status_code == 200
    assert "V2 主题：重试" in latest.json()["output"]["text"]


def test_missing_template_variable_returns_400(client: TestClient) -> None:
    client.post("/v1/prompts", json={"name": "needs-topic", "template": "主题：{{topic}}"})
    response = _invoke(client, prompt={"name": "needs-topic", "variables": {}})
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "missing_variable"


def test_retry_then_success_records_attempts(client: TestClient) -> None:
    response = client.post(
        "/v1/invoke",
        headers={"X-Mock-Fail-Times": "2", "X-Mock-Total-Ms": "0"},
        json={"model": PRO_MODEL, "messages": _message()},
    )
    assert response.status_code == 200
    assert response.json()["attempts"] == 3


def test_retry_exhausted_returns_502(client: TestClient) -> None:
    response = client.post(
        "/v1/invoke",
        headers={"X-Mock-Fail-Times": "3", "X-Mock-Total-Ms": "0"},
        json={"model": PRO_MODEL, "messages": _message()},
    )
    assert response.status_code == 502
    error = response.json()["error"]
    assert error["code"] == "retry_exhausted"
    assert error["retryable"] is False
    assert error["details"]["attempts"] == 3


def test_stream_emits_retry_before_first_token(client: TestClient) -> None:
    names = _stream_events(
        client,
        headers={"X-Mock-Fail-Times": "1", "X-Mock-Ttft-Ms": "0", "X-Mock-Chunk-Delay-Ms": "0"},
    )
    assert names[0] == "start"
    assert names[1] == "retry"
    assert "delta" in names
    assert names[-2:] == ["usage", "done"]


def test_rate_limit_returns_429_with_retry_after(client: TestClient) -> None:
    for _ in range(20):
        response = _invoke(client, headers={"X-Mock-Total-Ms": "0"})
        assert response.status_code == 200

    rejected = client.post(
        "/v1/invoke",
        headers={"X-Mock-Total-Ms": "0"},
        json={"model": PRO_MODEL, "messages": _message()},
    )
    assert rejected.status_code == 429
    assert rejected.json()["error"]["code"] == "rate_limited"
    assert int(rejected.headers["Retry-After"]) >= 1


def test_runtime_mode_defaults_to_mock(client: TestClient) -> None:
    runtime = client.get("/v1/runtime").json()
    assert runtime["mode"] == "mock"
    assert runtime["default_mode"] == "mock"
    assert isinstance(runtime["live_configured"], bool)
    assert client.get("/health").json()["mode"] == "mock"


def test_runtime_upstream_updates_keys_without_echo(client: TestClient) -> None:
    response = client.post(
        "/v1/runtime/upstream",
        json={"anthropic_api_key": "sk-ant-test-only-123456"},
    )
    assert response.status_code == 200
    body = response.json()
    assert "anthropic_api_key" in body["updated"]
    assert body["keys_configured"]["anthropic"] is True
    assert "sk-ant-test-only-123456" not in json.dumps(body)

    runtime = client.get("/v1/runtime").json()
    assert runtime["keys_configured"]["anthropic"] is True
    assert "sk-ant-test-only-123456" not in json.dumps(runtime)


def test_runtime_upstream_applies_base_url(client: TestClient) -> None:
    original = client.get("/v1/runtime").json()["base_urls"]["openai"]
    response = client.post(
        "/v1/runtime/upstream",
        json={"openai_base_url": "http://127.0.0.1:9/v1/"},
    )
    assert response.status_code == 200
    assert response.json()["base_urls"]["openai"] == "http://127.0.0.1:9/v1"
    assert response.json()["updated"] == ["openai_base_url"]

    client.post("/v1/runtime/upstream", json={"openai_base_url": original})
    assert client.get("/v1/runtime").json()["base_urls"]["openai"] == original


def test_runtime_upstream_rejects_invalid_base_url(client: TestClient) -> None:
    response = client.post(
        "/v1/runtime/upstream",
        json={"openai_base_url": "ftp://relay.example"},
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "invalid_request"


def test_runtime_upstream_applies_model_names(client: TestClient) -> None:
    original = client.get("/v1/runtime").json()["models"]
    response = client.post(
        "/v1/runtime/upstream",
        json={"flash_model": "deepseek-chat"},
    )
    assert response.status_code == 200
    assert response.json()["models"]["flash"] == "deepseek-chat"
    assert client.get("/v1/runtime").json()["models"]["flash"] == "deepseek-chat"

    client.post("/v1/runtime/upstream", json={"flash_model": original["flash"]})
    assert client.get("/v1/runtime").json()["models"]["flash"] == original["flash"]


def test_runtime_live_switch_requires_keys(client: TestClient) -> None:
    live_configured = client.get("/v1/runtime").json()["live_configured"]
    response = client.post("/v1/runtime/mode", json={"mode": "live"})
    if live_configured:
        assert response.status_code == 200
        assert client.get("/health").json()["mode"] == "live"
        client.post("/v1/runtime/mode", json={"mode": "mock"})
    else:
        assert response.status_code == 400
        assert response.json()["error"]["code"] == "invalid_request"
        assert client.get("/health").json()["mode"] == "mock"
