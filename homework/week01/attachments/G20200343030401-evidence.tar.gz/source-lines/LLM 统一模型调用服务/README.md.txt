    1	# 第一周作业：LLM 统一模型调用服务
    2	
    3	Python 3.11+ / FastAPI / httpx。统一入口 `POST /v1/generate` 根据 `model` 路由到两种协议适配器：
    4	
    5	- `deepseek-v4-pro` → OpenAI **Responses** 协议：Bearer 鉴权、`input`、`max_output_tokens`、`text.format`、`response.output_text.delta`。
    6	- `deepseek/deepseek-flash` → Anthropic **Messages** 协议：`x-api-key`、`anthropic-version`、独立 `system`、`messages`、`max_tokens`、`content_block_delta`。
    7	
    8	这两个模型 ID 与本项目的腾讯 TokenHub 配置一致；可分别用 `PRO_UPSTREAM_MODEL` / `FLASH_UPSTREAM_MODEL` 覆盖上游 ID。原接口名 `deepseek-v4-flash` 保留为 Flash 的兼容别名，与新 ID 共用限流额度。`GET /v1/models` 返回实际模型 ID、协议和别名；调用结果包含 `upstream_model` 和 `requested_model`。**必须使用实际支持对应协议的上游端点或网关**，模型名称不代表协议支持。
    9	
   10	## 当前网关集成
   11	
   12	两个模型共用 `https://tokenhub.tencentmaas.com/v1` 和一个 `GATEWAY_API_KEY`；服务自动拼接 Pro 的 `/responses` 与 Flash 的 `/messages`。私有密钥仅保存在被 Git 忽略的 `.env`，样例配置、源码与验收记录不包含真实密钥。当前本地 `.env` 已设置 `APP_MODE=live`、`PORT=8765`，可直接使用现有虚拟环境运行 `python -m app`。
   13	
   14	最新真实验收中，Pro 的普通调用、结构化输出、模板引用、流式输出、流式结构化五项均已通过，5 次调用均有对应的持久观测记录。Flash 返回 HTTP 402、上游错误码 `401008`：免费额度耗尽且未开通后付费。服务将其封装为 `UPSTREAM_QUOTA_EXHAUSTED`，保留 402，不自动重试。需由账号所有者在 [腾讯 TokenHub 在线推理控制台](https://console.cloud.tencent.com/tokenhub/inference) 恢复额度或处理计费后，才能完成 Flash 真实验收。
   15	
   16	## 启动
   17	
   18	首次安装时，在项目根目录执行以下命令。已有 `.env` 配置时保留原文件，跳过复制步骤。
   19	
   20	```powershell
   21	python -m venv .venv
   22	.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
   23	Copy-Item .env.example .env
   24	.\.venv\Scripts\python.exe -m app
   25	```
   26	
   27	`requirements-lock.txt` 保存本次验证使用的完整依赖版本。需要复现相同环境时，将安装命令改为 `pip install -r requirements-lock.txt`（锁文件包含测试依赖）。
   28	
   29	macOS / Linux：
   30	
   31	```bash
   32	python3 -m venv .venv
   33	.venv/bin/python -m pip install -r requirements-dev.txt
   34	cp .env.example .env
   35	.venv/bin/python -m app
   36	```
   37	
   38	默认 `APP_MODE=mock`，无需密钥，完整经过协议序列化、模拟 HTTP 上游、协议解析和服务逻辑；返回值明确带 `mode: mock`。在浏览器打开 [接口文档](http://127.0.0.1:8000/docs)。启动配置从当前目录 `.env` 读取，已有环境变量优先。
   39	
   40	如果 8000 端口已占用，PowerShell 可先执行 `$env:PORT='8765'`，再启动，访问 `http://127.0.0.1:8765/docs`。验证脚本相应传入 `--base-url http://127.0.0.1:8765`。
   41	
   42	真实调用：编辑 `.env` 设置 `APP_MODE=live`、`GATEWAY_BASE_URL` 和共用 `GATEWAY_API_KEY`，然后重启。也可分别填写 `PRO_RESPONSES_URL` / `PRO_API_KEY`、`FLASH_MESSAGES_URL` / `FLASH_API_KEY`，非空的模型独立配置优先于共用配置。独立 URL 填完整 HTTPS 接口路径；提供方须支持 Responses 的 JSON 格式和 Messages 的强制工具调用。缺失 live 配置时启动失败。
   43	
   44	## curl 示例
   45	
   46	以下为 Bash / Git Bash 写法。PowerShell 7.3+ 可使用 `curl.exe`，将续行 `\` 改为反引号，或合成一行；也可将 JSON 保存为 UTF-8 文件，使用 `curl.exe -H "Content-Type: application/json" --data-binary "@request.json" http://127.0.0.1:8000/v1/generate`。
   47	
   48	普通调用；将 `model` 换为 `deepseek/deepseek-flash` 即切换协议。以下示例使用默认端口 8000，当前本地 live 服务请替换为 8765：
   49	
   50	```bash
   51	curl -sS http://127.0.0.1:8000/v1/generate \
   52	  -H 'Content-Type: application/json' \
   53	  -d '{"model":"deepseek-v4-pro","messages":[{"role":"system","content":"请用中文回答。"},{"role":"user","content":"解释适配器模式"}],"max_output_tokens":512}'
   54	```
   55	
   56	SSE 流式输出，`-N` 关闭 curl 缓冲：
   57	
   58	```bash
   59	curl -N http://127.0.0.1:8000/v1/generate \
   60	  -H 'Content-Type: application/json' \
   61	  -d '{"model":"deepseek/deepseek-flash","messages":[{"role":"user","content":"解释适配器模式"}],"stream":true}'
   62	```
   63	
   64	每块为 `event: delta` + `data: {"request_id":"...","delta":"..."}`，正常结束为 `event: completed`，包含完整正文、usage、延迟和尝试次数。首块发出前的失败保留 HTTP 错误码；已开始输出后的失败为终止 `event: error`，此时 HTTP 状态已是 200。客户端必须以 `completed` 判断成功，不能仅检查 HTTP 状态。
   65	
   66	JSON Schema 结构化输出，两种适配器均已实现；Flash 真实调用目前受额度限制：
   67	
   68	```bash
   69	curl -sS http://127.0.0.1:8000/v1/generate \
   70	  -H 'Content-Type: application/json' \
   71	  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"请返回一个简短回答，并标注你的模型"}],"response_format":{"type":"json_schema","name":"answer","schema":{"type":"object","properties":{"answer":{"type":"string"},"model":{"type":"string"}},"required":["answer","model"],"additionalProperties":false}}}'
   72	```
   73	
   74	也支持 `"response_format":{"type":"json_object"}`。Responses 使用 `text.format` 并同时在系统提示词中传入完整 Schema，以兼容接受格式参数却未完整转发约束的网关；Messages 使用强制 `structured_output` 工具，将工具参数映射为 JSON。Schema 在服务端检查，并在生成后验证结果。Messages 的顶层 Schema 须为 `type: object`。远程 `$ref` / `$dynamicRef` 被拒绝，避免解析时访问网络。
   75	
   76	结构化输出可以与 `stream:true` 组合：delta 为 JSON 片段，完成后解析并校验；**单个片段不保证是合法 JSON，只有 completed 表示整体通过校验**。非流式响应在通过校验后才返回 200；校验失败返回 `INVALID_STRUCTURED_OUTPUT`。
   77	
   78	模板引用与变量替换：
   79	
   80	```bash
   81	curl -sS http://127.0.0.1:8000/v1/generate \
   82	  -H 'Content-Type: application/json' \
   83	  -d '{"model":"deepseek/deepseek-flash","prompt":{"name":"explain","version":"v1","variables":{"language":"中文","topic":"适配器模式"}}}'
   84	curl -sS http://127.0.0.1:8000/v1/prompts
   85	```
   86	
   87	`prompts/<name>/<version>.json` 存储有 role/content 的 messages。使用 `{{variable}}` 单次替换，拒绝缺少或多余变量，变量中的模板语法不会被递归展开。版本必须明确指定；发布新版本时新增文件，保留旧文件。已有 `explain/v1`、`explain/v2`。同时传入 `prompt` 和 `messages` 时，模板消息在前，显式消息追加在后。当前通过文件管理版本，运行期只读，不提供模板写入 API；版本文件的历史由版本控制保存。
   88	
   89	可观测数据：
   90	
   91	```bash
   92	curl -sS http://127.0.0.1:8000/v1/models
   93	curl -sS 'http://127.0.0.1:8000/v1/metrics/calls?limit=20'
   94	curl -sS http://127.0.0.1:8000/v1/metrics/summary
   95	```
   96	
   97	## 统计口径与韧性
   98	
   99	- 每个通过请求体校验的逻辑调用产生一个 SQLite 持久记录和一条 JSON 日志，包含请求 ID、模型、模板版本、状态、各次尝试、usage、总延迟、TTFT。未知模型、本地限流、上游失败和取消也记录。请求体 422、路由不存在等 HTTP 层错误只有统一错误响应和请求 ID，不计入模型调用统计。
  100	- `input_tokens` 为含缓存的全部输入，`output_tokens` 包含提供方计入输出的推理 Token，`total_tokens = input_tokens + output_tokens`。缓存读、缓存写、推理为子分类，不能重复加到总数。Anthropic 的普通输入不含缓存，适配器会加上缓存读写；Responses 输入已含缓存。未提供的分类填 0，表示没有已知报告值。Messages 不估算推理 Token。
  101	- Token 只采用上游报告，不按字数估算。流式 usage 是快照，更新而非重复累加；逻辑调用合计各次尝试已知 usage。`reported` 表示至少一次获得上游统计，`usage_complete` 表示所有尝试均有报告。故障或中断可能已经计费却未返回 usage，此时不能把已知计数当作完整账单。
  102	- `latency_ms` 使用单调时钟，从服务处理调用至结束，包含等待上游和退避。`ttft_ms` 仅流式请求记录从处理开始至首个非空正文片段，包含退避；非流式为 null，避免将整段耗时冒充 TTFT。该时间不含到客户端的网络传输。mock ASGI 上游会缓冲响应，其 TTFT 只用于功能验证，真实延迟请用 live 模式测量。
  103	- 首次调用 + **最多 3 次重试（最多 4 次尝试）**。仅网络连接错误、超时、HTTP 408/429/5xx 重试。指数退避为 `base * 2^(n-1)` + 0–20% 抖动，默认 base=0.5s。支持秒数和 HTTP 日期的 `Retry-After`，上游提示最多等待 30s。401/403/参数错误不重试，流开始发出正文后不重试。重试可能发生重复计费，流前超时也无法保证上游从未执行。
  104	- 按模型独立的每分钟滑动窗口，`PRO_RPM`、`FLASH_RPM` 分别控制；并发原子检查。每个获准的逻辑请求消耗一次额度，重试不重复扣本地额度。超限返回 HTTP 429、`RATE_LIMITED` 和 `Retry-After`。限流为进程内实现，运行单 worker；多副本需要共享限流存储。
  105	- 上游 HTTP 402 映射为 `UPSTREAM_QUOTA_EXHAUSTED` (402)，用于提示额度或计费限制，不重试。
  106	- 统一错误体为 `{"error":{"code":"...","message":"...","request_id":"...","retryable":false}}`。主要错误码：`INVALID_REQUEST` (422)、`MODEL_NOT_FOUND` (404)、`PROMPT_NOT_FOUND` (404)、`PROMPT_VARIABLE_ERROR` (400)、`RATE_LIMITED` (429)、`UPSTREAM_RATE_LIMITED` (429)、`UPSTREAM_AUTH_ERROR` (502)、`UPSTREAM_TIMEOUT` (504)、`UPSTREAM_UNAVAILABLE` / `UPSTREAM_ERROR` / `UPSTREAM_PROTOCOL_ERROR` / `UPSTREAM_INCOMPLETE` / `INVALID_STRUCTURED_OUTPUT` (502)。`retryable` 表示故障类型是否暂时性，不表示服务还会继续自动重试。
  107	
  108	默认只监听本机。该作业服务没有调用方鉴权；密钥只在后端配置，不写日志或返回前端。指标保存在 `data/metrics.sqlite3`，重启保留。清理历史指标可在停止服务后备份并移走数据库及同名 WAL/SHM 文件。公开部署前需增加鉴权、请求体大小限制和共享限流；SQLite 全量汇总适合本作业规模。
  109	
  110	## 验证与验收证据
  111	
  112	无需启动服务、无需真实密钥的一键验证：
  113	
  114	```powershell
  115	.\.venv\Scripts\python.exe scripts/verify.py
  116	```
  117	
  118	脚本运行所有 pytest 用例，失败时返回非零退出码，生成：
  119	
  120	- `artifacts/verification.xml`：每个用例的 JUnit 结果。
  121	- `artifacts/mock-evidence.json`：两种模型的正文/SSE/模板引用/Token 分类/延迟/重试轨迹/429 证据，明确标记为 mock。
  122	
  123	覆盖两个协议的鉴权和请求体差异、普通调用、流式、JSON Object/Schema、流式 JSON、模板版本、缺失变量、调用指标、503/429/连接失败/超时后三次重试、重试耗尽、永久错误不重试、断流无 completed 且不重试、非法 JSON、Schema 不匹配、并发独立限流、窗口恢复、取消释放资源。所有退避测试注入等待函数并断言真实计算的等待值，测试本身不需要等退避时间。
  124	
  125	对已启动服务做真实 HTTP 检查（默认拒绝 mock 模式）：
  126	
  127	```powershell
  128	.\.venv\Scripts\python.exe scripts/smoke_live.py
  129	```
  130	
  131	脚本默认连接本机 8765，可用 `--base-url` 覆盖；模型列表从 `GET /v1/models` 读取。可加 `--models deepseek-v4-pro` 仅验证 Pro。额度阻塞时保留已通过的证据，跳过该模型后续调用；修复额度后重新执行即可。
  132	
  133	它会实际调用两个模型，每个模型 5 次：普通、结构化、模板、流式、流式结构化，并核对每次请求的持久记录。**会消耗上游额度**。结果写入 `artifacts/live-evidence.json`；失败也写出已完成证据并返回非零退出码。真实验收需提供两个协议的有效 URL / API Key；只有 live 脚本通过才能证明真实模型可用。重试和限流用 mock 故障注入证据验收，不依赖真实上游故障。
  134	
  135	本地 HTTP 冒烟可用：
  136	
  137	```powershell
  138	.\.venv\Scripts\python.exe scripts/smoke_live.py --allow-mock --output artifacts/http-mock-evidence.json
  139	```
  140	
  141	本次回归：54 个自动化用例通过，包含共用密钥配置、模型别名共用限流、完整 Schema 提示和 402 不重试。历史 mock HTTP 验证记录位于 `artifacts/http-mock-evidence.json`；当前真实调用结果位于 `artifacts/live-evidence.json`，接口级探测结果位于 `artifacts/upstream-probe.json`。真实探测可运行 `python scripts/probe_upstream.py`，每个端点仅请求一次，不打印密钥。
  142	
  143	手工复现本地 429：设置 `PRO_RPM=1` 后重启，一分钟内连续两次调用 pro，第二次 429；此时首次调用 flash 仍成功。手工模拟重试耗尽：在 mock 模式将用户消息设为 `[always-503]`，从调用记录检查 4 次尝试；`[truncated]` 配合 stream 模拟断流，`[invalid-json]` 配合 response_format 模拟无效结构化结果。这些标记仅在 mock fixture 生效，live 模式按原始文本发送。
  144	
  145	## 代码组织
  146	
  147	- `app/main.py`：HTTP API、统一错误、SSE 生命周期。
  148	- `app/service.py`：路由、重试、校验、调用记录编排。
  149	- `app/adapters.py`：适配器接口与 Responses / Messages 实现。
  150	- `app/schemas.py`、`app/sse.py`：统一数据模型和 SSE 编解码。
  151	- `app/prompts.py`、`prompts/`：模板存储与版本引用。
  152	- `app/observability.py`：限流与持久观测记录。
  153	- `app/mock_upstream.py`、`tests/`、`scripts/`：协议 fixture 与可重复验证。
  154	
  155	Responses 字段和流事件参考 [OpenAI 官方 Responses API 文档](https://developers.openai.com/api/reference/resources/responses/methods/create)。Messages 格式参考 [Anthropic Messages 文档](https://docs.anthropic.com/en/api/messages)。真实第三方网关兼容性须以上游实际支持为准。
