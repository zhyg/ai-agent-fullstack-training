# 第一周作业评测附件

- 学员：Y-Tracy / G20200343030401
- 仓库：https://gitee.com/byTracyYe/geektime-ai-agent-camp
- 分支与提交号：master，`a99612279d9a85ae9d5d266f4a3cb21d1e193c72`
- 目录：`LLM 统一模型调用服务/`；clone 实际成功，无 API 快照替代；评测前后 tracked diff 均为空。
- 评测日期：2026-11-07（Asia/Singapore）
- 总分：**暂评 99/100**
- 作业等级：优秀
- 验收结论：**证据不完整**。双协议真实普通调用已通过；官方 Messages 结构化被不兼容工具选择拒绝，未声称全功能真实通过。另有已复现的状态映射缺陷。
- 标准：本课程仓库评分标准 v1.1 与反馈模板 v1.0。环境超时与官方格式兼容性不另扣代码分。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 同一 `/v1/generate` 按 model 路由；两种真实协议；未知模型明确 404；统一结果与请求关联。 |
| 流式输出 | 15/15 | 两协议真实 SSE 成功；教师双协议门控经真实 HTTP 首块先到，断流后 error、无 completed、上游各仅一次。 |
| 结构化输出 | 10/10 | Responses 真实 Schema 成功；双协议受控 JSON/Schema 校验、非法空截断拒绝。官方 Messages 强制工具选择不兼容未另扣，400 状态映射只在统一错误项扣分。 |
| 提示词版本管理 | 10/10 | 两模型 v1→v2→v1 实际请求内容正确；缺模板、缺版本、缺变量不请求上游。 |
| 可观测性 | 15/15 | SQLite 请求关联、成功/失败/取消记录；Token 分类、累计快照、正文 TTFT、重试完整性标识；教师独立非对称计数与门控延迟核对。 |
| 统一错误与重试 | 14/15 | 4xx 格式拒绝包装为 502，扣 1；其余统一错误、指数抖动、可重试三次成功/四次耗尽、永久错误一次停止均通过。 |
| 按模型独立限流 | 10/10 | A 耗尽 429，B 200；159.99 秒仍拒绝、160 秒恢复；学生还测别名共用配额及并发原子检查。 |
| 源码、README 与验证脚本 | 10/10 | 干净 venv 按 README 安装、启动；curl 示例对应实际 API；54 测试覆盖六项功能，HTTP 冒烟 10/10 mock、制造失败清晰报告并退出 1。 |
| **合计** | **99/100** | **15+15+10+10+15+14+10+10=99；仅一个扣分根因。** |

以上未因“不用某框架”、未提供分布式限流、未提供模板写 API、未采用教师偏好的抖动形式、非流式 TTFT 为 null 等额外设门槛。

## 环境、命令与证据索引

证据包：`G20200343030401-evidence.tar.gz`；以下路径均相对于包根目录。`source/` 是固定提交目标目录的 tracked 文件，`source-manifest.json` 记录 Git blob 与 SHA256；不含 `.env`、Git 凭据或虚拟环境。`scripts/` 为教师外置脚本，未修改学生逻辑。

执行位置：`/tmp/tracy-grade/student/LLM 统一模型调用服务`。复现可将源码按此位置解包，创建相同 venv；教师脚本保留原绝对路径以对应原始命令。

```bash
git clone --branch master --single-branch https://gitee.com/byTracyYe/geektime-ai-agent-camp /tmp/tracy-grade/student
git -C /tmp/tracy-grade/student checkout a99612279d9a85ae9d5d266f4a3cb21d1e193c72
python3 -m venv /tmp/tracy-grade/venv
/tmp/tracy-grade/venv/bin/pip install -r requirements-dev.txt
cp .env.example .env
# APP_MODE=mock PORT=8766 METRICS_DB=/tmp/tracy-grade/http-mock.sqlite3
/tmp/tracy-grade/venv/bin/python -m app
/tmp/tracy-grade/venv/bin/python scripts/verify.py
/tmp/tracy-grade/venv/bin/python scripts/smoke_live.py --allow-mock --base-url http://127.0.0.1:8766 --output /tmp/tracy-grade/student-http-mock.json
/tmp/tracy-grade/venv/bin/python /tmp/tracy-grade/teacher.py
/tmp/tracy-grade/venv/bin/python scripts/smoke_live.py --allow-mock --base-url http://127.0.0.1:8766 --models nonexistent-model --output /tmp/tracy-grade/student-manufactured-failure.json
```

- 实际服务通过 `amp orb service start tracy-mock --command 'APP_MODE=mock PORT=8766 METRICS_DB=/tmp/tracy-grade/http-mock.sqlite3 /tmp/tracy-grade/venv/bin/python -m app' --port 8766` 启动；非后台裸进程。
- live 服务命令：`amp orb service start tracy-live --command '/tmp/tracy-grade/venv/bin/python /tmp/tracy-grade/live_server.py' --port 8765`。
- 初测：`/tmp/tracy-grade/venv/bin/python /tmp/tracy-grade/live_probe.py`；真实学生脚本：`/tmp/tracy-grade/venv/bin/python scripts/smoke_live.py --base-url http://127.0.0.1:8765 --output /tmp/tracy-grade/student-live.json`。
- 诊断：`/tmp/tracy-grade/venv/bin/python /tmp/tracy-grade/diagnose_format.py`，仅一次直接官方请求，使用学生原样 payload。
- live_server 仅外部配置与 httpx transport 审计包装，调用学生 `create_app`；不替换适配器、JSON 校验、重试或限流逻辑。上游 key 只从进程 `DEEPSEEK_API_KEY` 读取，没有文件落盘。
- 安装、验证、HTTP 冒烟及教师结果分别见 `logs/`、`results/`；实际依赖版本见 `installed.txt`。

### 原配置与本次映射差异

| 项目 | 学生原配置 | 教师外部配置 |
| --- | --- | --- |
| 模式 | `.env.example` mock | 真实验证为 live |
| Responses | 腾讯 `/v1/responses`，deepseek-v4-pro | `https://api.deepseek.com/responses`，deepseek-v4-pro |
| Messages | 腾讯 `/v1/messages`，deepseek/deepseek-flash | `https://api.deepseek.com/anthropic/v1/messages`，deepseek-flash |
| Key | 网关共用或模型单独 key | 仅官方个人 `DEEPSEEK_API_KEY` 注入共用配置，独立 key 清空；归档不含值 |
| 超时/退避 | 60s / base 0.5s | 25s / base 0.2s，有限至四次尝试；受控测试 base 0.01s、等待注入记录 |
| 指标/端口 | data/metrics.sqlite3 / 8000 | 独立临时 SQLite / mock 8766、live 8765、门控 8767 |

官方模型说明：`https://api-docs.deepseek.com/` 将 deepseek-flash 映射为 DeepSeek-V4.1-Flash-1017；本报告记录请求模型 ID，不声称精确验证了服务端权重。配置没有加入 thinking 参数或改变工具选择逻辑。

## A01–A04 / F01–F12 结果

| 编号 | 结果 | 实际证据与范围 |
| --- | --- | --- |
| A01 | 通过 | clone、README Linux 安装与原 `python -m app` 启动；学生验证 54 passed in 1.49s。 |
| A02 | 通过 | 两公开模型同一接口真实普通请求 200；初测与学生 live 冒烟均有成功。 |
| A03 | 通过 | 真实线上请求审计：Responses `/responses` 使用 input/max_output_tokens/text.format/Bearer；Messages `/anthropic/v1/messages` 使用 messages/system/max_tokens/tools/tool_choice/x-api-key/anthropic-version。受控请求进一步核对模板与完整字段。 |
| A04 | 通过 | 不存在 model 返回 404/MODEL_NOT_FOUND，教师断言上游收到请求数不变；失败记录存在。 |
| F01 | 通过 | 双协议真实普通 SSE；双协议门控以 asyncio.Event 暂扣终态，经 localhost HTTP 客户端确认“中文首块”先到，之后才放行；非 ASGI 缓冲假流式。 |
| F02 | 通过 | 两协议首块后注入 ReadError，HTTP 200 的 SSE 以 error 终止，无 completed，无重放，实际上游一次；另有学生输出后 ReadTimeout 测试。 |
| F03 | 部分失败/未完整验证 | Responses 真实 Schema 普通/流式成功；双协议受控 Schema 成功。Messages 官方结构化 400（thinking 不支持强制 tool_choice），服务却 502；该映射扣分，官方成功结果未验证。 |
| F04 | 通过 | 独立受控测试非法 JSON、空正文、incomplete/max_tokens、字段类型不符均 502，无成功正文；学生另覆盖双协议流式非法结构。无修复循环，因此“修复后仍不合法”分支不适用。 |
| F05 | 通过 | 两模型 v1→v2→v1，捕获实际上游 payload，检查 v2 的生活类比提示、变量与旧版恢复。文件式版本管理按文档验收，不强求写 API。 |
| F06 | 通过 | 缺模板/版本 404，缺变量 400；无未替换占位符发送；错误均无上游请求。 |
| F07 | 通过 | 真实成功与超时、400 均持久记录；独立注入 input=13/output=7/cache=3，Responses total=20；Messages 另 cache_write=2，input=18/total=25；流累计快照不重复加，心跳不计 TTFT。 |
| F08 | 通过 | 两协议 503/429 前两次失败后第三次成功，transport 实收 3 请求；sleep 注入等待在 base×2^n 的 100–120% 内。 |
| F09 | 通过 | 持续 503 各 4 次停止；401/400 各 1 次，无 SDK 叠加重试（httpx transport retries=0）；学生另测连接、超时及 408。 |
| F10 | 通过 | rpm=1，A 请求序列 200/429，B 200，实际上游仅允许的请求到达。 |
| F11 | 通过 | 注入单调时钟，经 HTTP 接口：初始100、159.99拒绝、160恢复；状态序列 [200,429,200,429,200]，未改窗口业务逻辑。 |
| F12 | 通过 | 学生 verify 54/54、mock HTTP 10/10；smoke_live 指定不存在模型制造失败，五项均明确 FAIL/404，退出1。真实脚本 8/10、退出1，如实留存。 |

教师 `teacher-results.json` 汇总为 6 个执行组 PASS、1 个行为 FAIL；其中 `F03-400-probe` 的 PASS 仅表示复现执行成功，独立 `F03-upstream-format-400` 才是行为失败，不能将两者混淆。不按测试通过率换算分数。

## 真实调用明细

所有 Token 均为已知上游报告，不是估算；下表用输入/输出/总量表示。TTFT 口径为首个非空正文，不计推理与心跳，非流式 null。完整 SSE、分类、每次尝试及持久记录见 `results/student-live.json`、`results/live-initial.json` 与 `results/live-records.json`。

| 模型/协议 | 用例 | 网关 request_id | HTTP | Token 输入/输出/总量 | 延迟/TTFT(ms) |
| --- | --- | --- | ---: | --- | --- |
| deepseek-v4-pro / Responses | 初始普通 | req_272c5e8a8c4b47cba07dd343f4a81860 | 200 | 90/30/120 | 1482.900/null |
| deepseek-flash / Messages | 初始普通 | req_524c878ee5a340f5bc3bf19291f64a8a | 200 | 37/11/48 | 60632.904/null |
| deepseek-v4-pro / Responses | 普通 | req_f1ce1cd817cd41418305a391a5cbecdc | 200 | 90/140/230 | 6367.931/null |
| 同上 | Schema | req_681372a0fd3f4f8f8fe96207c41f65eb | 200 | 187/105/292 | 6649.065/null |
| 同上 | 模板 | req_00794fe3de2c4ff988f87e758dfd95a4 | 200 | 101/161/262 | 7211.754/null |
| 同上 | SSE | req_a3f8796627c14653a8755bc2ecc8e1e8 | 200 | 90/105/195 | 6819.038/6382.431 |
| 同上 | SSE Schema | req_e4bdb38cfc75436cb89cd026fe3c105f | 200 | 187/141/328 | 6287.131/5941.999 |
| deepseek-flash / Messages | 普通 | req_67e435ec406548d383fcfa18dcf93a98 | 200 | 37/167/204 | 2587.534/null |
| 同上 | Schema | req_8adbe20ac75d42ef9f1e31e11871121b | 502 | 未报告 | 722.435/null |
| 同上 | 模板 | req_4510dbd6a9f54815868f28f0edb62054 | 200 | 48/236/284 | 37355.699/null |
| 同上 | SSE | req_2be641ef33484d2bb194f66edcff43b3 | 200 | 37/192/229 | 2213.277/1622.588 |
| 同上 | SSE Schema | req_12e05d76afe440d6b4b82203ae84786b | 502 | 未报告 | 400.388/null |

- 初始 Flash 有两次超时后第三次成功；模板有一次超时后第二次成功。`usage_complete=false` 正确提示失败尝试计费未知，不把已知用量当完整账单；未因超时扣分。其余上表成功请求均一次尝试。
- Responses 普通/SSE/Schema/SSE Schema 的已知 reasoning_output_tokens 分别 43/55/65/91；SSE Schema cached=128，包含在 input=187 内，不重复相加。Messages 未提供推理分类则按 README 的“0=未报告”处理。
- 普通成功请求的 provider request_id 未由适配器透出，审计筛选的响应头也未见；不伪造 ID。以上网关 ID 可关联账本。直接格式诊断真实 provider request_id 为 `55a6b5f1-f6da-46aa-a94c-5cf6cac90221`，响应明确 `Thinking mode does not support this tool_choice`，见 `official-format-diagnostic.json`。
- 审计 transport 原始普通响应可能为压缩字节，无法从有损 UTF-8 捕获还原，因此证据包 `live-wire.jsonl` 删除这类正文并明确标注；请求 URL/JSON、状态与时间仍真实保留。网关解码后的成功正文、SSE 和账本由学生脚本完整记录。上游 HTTP 错误分支在读正文前结束，transport 不保证留存该类响应；以直接诊断与网关失败账本补证，不伪称 wire 日志完整。

## 待修复问题及扣分依据

1. **D01：不支持结构化格式的上游 400 被包装为 502（统一错误与重试，扣 1 分）。**
   - 触发：调用统一接口携带 response_format，上游返回 HTTP 400；受控返回 `unsupported format`，真实 Messages 则拒绝默认 thinking 下的强制工具选择。
   - 预期：按评分标准5.2返回统一结构的明确4xx，参数/格式拒绝不重试。
   - 实际：HTTP502，`UPSTREAM_ERROR`，message=`Upstream returned HTTP 400`，retryable=false；次数为1。错误结构与不重试正确，仅状态映射错误。
   - 固定源码：`LLM 统一模型调用服务/app/adapters.py:25-46`，尤其43-44把其余状态统一变502；84-89调用该映射。`MessagesAdapter.payload` 的强制工具选择位于同文件197-200，归档附带行号源码。
   - 复现命令：`/tmp/tracy-grade/venv/bin/python /tmp/tracy-grade/teacher.py`，定位结果 `F03-upstream-format-400`；真实学生脚本定位 Schema 的两个失败请求；`diagnose_format.py` 用原适配器 payload 一次直接请求复核上游错误。
   - 证据：`results/teacher-results.json`、`results/student-live.json`、`results/official-format-diagnostic.json`；完整失败记录与请求ID见上表。
   - 影响范围：同一状态映射根因只扣1分；不再扣结构化分、双协议分、脚本分；不因腾讯网关额度声明或官方 thinking 兼容性额外扣分。

## 关键源码与限制

- JSON：`app/schemas.py:62-70` 解析并验证，`app/service.py:73-78` 检查终态、空正文和结果；没有修复循环，不构造不存在的重试修复分支。
- 重试/TTFT：`app/service.py:48-104`，最多4次，输出后 parts 非空立即停止；抖动按 README 的0–20%检查，不把随机单次延迟不严格递增判失败。实测退避数组在教师结果中完整保留；测试注入 sleep，未实际等待这些秒数，不能当实际墙钟等待证据。
- 模板：`app/prompts.py:19-39`；限流：`app/observability.py:16-33`。窗口用注入时钟验证，并非声称真的等待一分钟。
- 学生 `tests/test_service.py` 的 `test_retry_then_success` 只断言各退避值下界，教师补测同时核对上界；建议增强学生断言，不另扣分。
- 官方 Messages 真实结构化成功仍待补证；本次没有更换学生工具调用逻辑、增加 thinking 参数或改用其他 secret 规避该限制。没有持续重打已知400，也没有用500/超时反复压测真实账号。

## 补交要求

- 必须修复：D01，保留统一错误体并正确区分不支持格式的4xx；受控测试断言响应状态与实际上游仅请求一次。
- 必须补充：兼容 Messages 的真实普通/流式结构化成功（或明确不支持并以统一4xx拒绝），附模型映射、请求ID、合法JSON、Token与账本；不得把mock结果写成真实结果。
- 复验条件：双协议真实基本调用保持成功，D01回归通过，结构化兼容性限制按公开能力明确处理；现有54项与门控、断流、失败记录、限流隔离恢复不回退。

## 归档与安全检查

最终归档包含脱敏配置、外置验证脚本、固定源码及行号、原始测试日志和JSON结果；不包含 `.env`、SQLite 二进制、缓存或密钥值。对文本及解包 tar 成员逐一按本次真实 `DEEPSEEK_API_KEY` 原值与常见编码变体执行实际匹配扫描，另扫描 credential 模式；结果记录于包内 `security-scan.json`。报告合计、列表条数和字数由最终检查命令核对。服务 tracy-live、tracy-mock 已停止，8767 门控临时服务退出；未提交、未推送。
