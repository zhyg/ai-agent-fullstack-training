import json
import re
from pathlib import Path

from app.errors import ServiceError
from app.schemas import Message, PromptRef

VARIABLE = re.compile(r"{{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*}}")


class PromptStore:
    """Read-only, explicit versions: editing a template means adding a new file."""

    def __init__(self, root: Path):
        self.root = root.resolve()

    def render(self, ref: PromptRef) -> list[Message]:
        path = (self.root / ref.name / f"{ref.version}.json").resolve()
        if not path.is_relative_to(self.root) or not path.is_file():
            raise ServiceError("PROMPT_NOT_FOUND", "Prompt name/version does not exist", 404)
        try:
            template = json.loads(path.read_text(encoding="utf-8"))
            messages = [Message.model_validate(item) for item in template["messages"]]
            if not messages:
                raise ValueError("Empty template")
        except (ValueError, KeyError, TypeError):
            raise ServiceError("INVALID_PROMPT_TEMPLATE", "Invalid stored prompt template", 500) from None
        names = {name for msg in messages for name in VARIABLE.findall(msg.content)}
        missing, extra = names - ref.variables.keys(), ref.variables.keys() - names
        if missing or extra:
            raise ServiceError("PROMPT_VARIABLE_ERROR", f"Missing variables: {sorted(missing)}; unknown variables: {sorted(extra)}")
        # Callable substitution is single-pass, preserving user strings literally.
        return [Message(role=msg.role, content=VARIABLE.sub(lambda m: ref.variables[m[1]], msg.content)) for msg in messages]

    def list_versions(self):
        return [{"name": path.parent.name, "version": path.stem}
                for path in sorted(self.root.glob("*/*.json"))]
