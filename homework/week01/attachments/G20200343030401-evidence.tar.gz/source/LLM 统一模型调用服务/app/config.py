import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv

MODEL_ALIASES = {"deepseek-v4-flash": "deepseek/deepseek-flash"}


@dataclass(frozen=True)
class ModelConfig:
    name: str
    protocol: str
    url: str
    api_key: str
    upstream_model: str
    rpm: int = 60


@dataclass(frozen=True)
class Settings:
    mode: str
    models: dict[str, ModelConfig]
    metrics_db: Path = Path("data/metrics.sqlite3")
    prompts_dir: Path = Path("prompts")
    timeout_seconds: float = 60
    retry_base_seconds: float = 0.5

    @classmethod
    def from_env(cls):
        load_dotenv()
        mode = os.getenv("APP_MODE", "mock")
        if mode not in {"mock", "live"}:
            raise ValueError("APP_MODE must be mock or live")
        gateway_url = os.getenv("GATEWAY_BASE_URL", "https://mock.local/v1").rstrip("/")
        gateway_key = os.getenv("GATEWAY_API_KEY", "")
        models = {}
        for prefix, name, protocol, url_key, path in [
            ("PRO", "deepseek-v4-pro", "responses", "PRO_RESPONSES_URL", "responses"),
            ("FLASH", "deepseek/deepseek-flash", "messages", "FLASH_MESSAGES_URL", "messages"),
        ]:
            url = os.getenv(url_key) or f"{gateway_url}/{path}"
            key = os.getenv(f"{prefix}_API_KEY") or gateway_key
            rpm = int(os.getenv(f"{prefix}_RPM", "60"))
            if rpm < 1:
                raise ValueError(f"{prefix}_RPM must be positive")
            if mode == "live":
                parsed = urlparse(url)
                if not key or parsed.scheme != "https" or not parsed.hostname or parsed.hostname.endswith((".example", ".local")):
                    raise ValueError(f"live mode requires {url_key} (HTTPS) and {prefix}_API_KEY")
            models[name] = ModelConfig(name, protocol, url, key, os.getenv(f"{prefix}_UPSTREAM_MODEL", name), rpm)
        timeout = float(os.getenv("UPSTREAM_TIMEOUT_SECONDS", "60"))
        base = float(os.getenv("RETRY_BASE_SECONDS", "0.5"))
        if timeout <= 0 or base < 0:
            raise ValueError("Timeout must be positive and retry delay nonnegative")
        return cls(mode, models, Path(os.getenv("METRICS_DB", "data/metrics.sqlite3")),
                   Path(os.getenv("PROMPTS_DIR", "prompts")), timeout, base)
