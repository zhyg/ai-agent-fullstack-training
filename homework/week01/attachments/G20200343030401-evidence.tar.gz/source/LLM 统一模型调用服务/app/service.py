import asyncio
import logging
import random
import time
from contextlib import aclosing
from datetime import datetime, timezone

from app.adapters import ADAPTERS, Delta, Finished
from app.config import MODEL_ALIASES, Settings
from app.errors import ServiceError
from app.observability import MetricsStore, RateLimiter
from app.prompts import PromptStore
from app.schemas import GenerateRequest, Usage

logger = logging.getLogger("llm.service")


class LLMService:
    def __init__(self, settings: Settings, client, *, sleep=asyncio.sleep):
        self.settings = settings
        self.adapters = {name: ADAPTERS[config.protocol](config, client) for name, config in settings.models.items()}
        self.prompts = PromptStore(settings.prompts_dir)
        self.metrics = MetricsStore(settings.metrics_db)
        self.limiter = RateLimiter()
        self.sleep = sleep

    async def generate(self, request: GenerateRequest, request_id: str):
        started = time.perf_counter()
        ttft = None
        status, error_code = "error", None
        attempts, parts = [], []
        output_length = 0
        total_usage = Usage()
        usage_complete = True
        model_id = request.model
        try:
            if model_id not in self.settings.models:
                model_id = MODEL_ALIASES.get(model_id, model_id)
            config = self.settings.models.get(model_id)
            if config is None:
                raise ServiceError("MODEL_NOT_FOUND", "Unknown model; see GET /v1/models", 404)
            messages = (self.prompts.render(request.prompt) if request.prompt else []) + request.messages
            if len(messages) > 100 or sum(len(m.content) for m in messages) > 200_000:
                raise ServiceError("INVALID_REQUEST", "Rendered messages exceed input limits", 422)
            # Validate protocol constraints before consuming a rate-limit slot.
            self.adapters[model_id].payload(request, messages)
            await self.limiter.acquire(model_id, config.rpm)
            for number in range(1, 5):
                attempt = {"number": number, "status": "running", "usage": Usage().public()}
                attempts.append(attempt)
                attempt_usage = Usage()
                attempt_started = time.perf_counter()
                retry_error = None
                try:
                    finished = None
                    async with aclosing(self.adapters[model_id].events(request, messages)) as events:
                        async for event in events:
                            if isinstance(event, Usage):
                                attempt_usage = event
                            elif isinstance(event, Delta) and event.text:
                                if not isinstance(event.text, str):
                                    raise ServiceError("UPSTREAM_PROTOCOL_ERROR", "Expected text delta", 502)
                                if request.stream and ttft is None:
                                    ttft = (time.perf_counter() - started) * 1000
                                parts.append(event.text)
                                output_length += len(event.text)
                                if output_length > 2_000_000:
                                    raise ServiceError("OUTPUT_TOO_LARGE", "Output exceeds service limit", 502)
                                if request.stream:
                                    yield "delta", {"request_id": request_id, "delta": event.text}
                            elif isinstance(event, Finished):
                                finished = event.reason
                    if not finished:
                        raise ServiceError("UPSTREAM_INCOMPLETE", "Missing completion marker", 502)
                    text = "".join(parts)
                    if not text:
                        raise ServiceError("EMPTY_OUTPUT", "Upstream returned no text", 502)
                    structured = request.response_format.validate_output(text) if request.response_format else None
                    attempt["status"] = "ok"
                except ServiceError as error:
                    attempt.update(status="error", error_code=error.code)
                    if not error.retryable or parts or number == 4:
                        raise
                    retry_error = error
                except (asyncio.CancelledError, GeneratorExit):
                    attempt.update(status="cancelled", error_code="CLIENT_DISCONNECTED")
                    raise
                finally:
                    attempt["usage"] = attempt_usage.public()
                    attempt["latency_ms"] = round((time.perf_counter() - attempt_started) * 1000, 3)
                    usage_complete = usage_complete and attempt_usage.reported
                    for field in Usage.model_fields:
                        if field != "reported":
                            setattr(total_usage, field, getattr(total_usage, field) + getattr(attempt_usage, field))
                    total_usage.reported = total_usage.reported or attempt_usage.reported
                if retry_error:
                    delay = self.settings.retry_base_seconds * 2 ** (number - 1)
                    delay += random.uniform(0, delay * 0.2)
                    if retry_error.retry_after is not None:
                        delay = max(delay, retry_error.retry_after)
                    attempt["retry_delay_seconds"] = round(delay, 4)
                    await self.sleep(delay)
                    continue
                break
            status = "ok"
            result = {"request_id": request_id, "model": model_id, "upstream_model": config.upstream_model,
                      "requested_model": request.model, "mode": self.settings.mode,
                      "output_text": "".join(parts), "structured_output": structured,
                      "finish_reason": finished, "usage": total_usage.public(), "usage_complete": usage_complete,
                      "latency_ms": round((time.perf_counter() - started) * 1000, 3),
                      "ttft_ms": round(ttft, 3) if ttft is not None else None,
                      "attempts": len(attempts),
                      "prompt": {"name": request.prompt.name, "version": request.prompt.version} if request.prompt else None}
        except ServiceError as error:
            error_code = error.code
            raise
        except (asyncio.CancelledError, GeneratorExit):
            status, error_code = "cancelled", "CLIENT_DISCONNECTED"
            raise
        finally:
            record = {"request_id": request_id, "timestamp": datetime.now(timezone.utc).isoformat(),
                      "model": model_id, "requested_model": request.model,
                      "mode": self.settings.mode, "stream": request.stream,
                      "status": status, "error_code": error_code, "attempts": attempts,
                      "latency_ms": round((time.perf_counter() - started) * 1000, 3),
                      "ttft_ms": round(ttft, 3) if ttft is not None else None,
                      "usage": total_usage.public(), "usage_complete": usage_complete and bool(attempts),
                      "prompt": {"name": request.prompt.name, "version": request.prompt.version} if request.prompt else None}
            self.metrics.record(record)
        # Persist the record before emitting the successful terminal event.
        yield "completed", result
