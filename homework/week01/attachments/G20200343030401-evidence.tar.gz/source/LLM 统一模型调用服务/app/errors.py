class ServiceError(Exception):
    def __init__(self, code: str, message: str, status: int = 400, *, retryable: bool = False,
                 retry_after: float | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
        self.retryable = retryable
        self.retry_after = retry_after

    def body(self, request_id: str):
        return {"error": {"code": self.code, "message": self.message, "request_id": request_id,
                          "retryable": self.retryable}}
