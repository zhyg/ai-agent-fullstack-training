import json
from collections.abc import AsyncIterator

from app.errors import ServiceError


async def parse_sse(lines: AsyncIterator[str]):
    """Parse UTF-8 SSE through httpx.aiter_lines (handles CRLF and byte boundaries)."""
    data = []
    size = 0
    async for line in lines:
        if not line:
            if data:
                yield decode(data)
            data, size = [], 0
        elif line.startswith("data:"):
            value = line[5:].removeprefix(" ")
            data.append(value)
            size += len(value)
            if size > 2_000_000:
                raise ServiceError("UPSTREAM_PROTOCOL_ERROR", "Upstream SSE event is too large", 502)
    if data:
        yield decode(data)


def decode(parts):
    raw = "\n".join(parts)
    if raw == "[DONE]":
        return {"type": "transport_done"}
    try:
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise ValueError()
        return result
    except ValueError:
        raise ServiceError("UPSTREAM_PROTOCOL_ERROR", "Invalid upstream SSE JSON", 502) from None


def encode(event: str, value: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(value, ensure_ascii=False, allow_nan=False)}\n\n"
