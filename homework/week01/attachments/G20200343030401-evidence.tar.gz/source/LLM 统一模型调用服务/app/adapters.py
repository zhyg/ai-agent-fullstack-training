import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import httpx

from app.config import ModelConfig
from app.errors import ServiceError
from app.schemas import GenerateRequest, Message, Usage
from app.sse import parse_sse


@dataclass
class Delta:
    text: str


@dataclass
class Finished:
    reason: str


def upstream_error(status: int, retry_after: str | None = None):
    delay = None
    if retry_after:
        try:
            delay = float(retry_after)
        except ValueError:
            try:
                delay = (parsedate_to_datetime(retry_after) - datetime.now(timezone.utc)).total_seconds()
            except (ValueError, TypeError, OverflowError):
                pass
    retryable = status in {408, 429} or 500 <= status <= 599
    if status in {401, 403}:
        code, message, public_status = "UPSTREAM_AUTH_ERROR", "Upstream authentication failed", 502
    elif status == 402:
        code, message, public_status = ("UPSTREAM_QUOTA_EXHAUSTED",
            "Upstream quota exhausted or billing is not enabled; check the provider console", 402)
    elif status == 429:
        code, message, public_status = "UPSTREAM_RATE_LIMITED", "Upstream rate limit exceeded", 429
    else:
        code, message, public_status = "UPSTREAM_ERROR", f"Upstream returned HTTP {status}", 502
    return ServiceError(code, message, public_status, retryable=retryable,
                        retry_after=max(0, min(delay, 30)) if delay is not None else None)


def responses_usage(raw: dict) -> Usage:
    return Usage(input_tokens=raw.get("input_tokens", 0), output_tokens=raw.get("output_tokens", 0),
                 cache_read_input_tokens=(raw.get("input_tokens_details") or {}).get("cached_tokens", 0),
                 reasoning_output_tokens=(raw.get("output_tokens_details") or {}).get("reasoning_tokens", 0),
                 reported=bool(raw))


def messages_usage(raw: dict) -> Usage:
    read, write = raw.get("cache_read_input_tokens", 0), raw.get("cache_creation_input_tokens", 0)
    # Anthropic input_tokens excludes cache reads/writes; unified input_tokens includes them.
    return Usage(input_tokens=raw.get("input_tokens", 0) + read + write,
                 output_tokens=raw.get("output_tokens", 0), cache_read_input_tokens=read,
                 cache_write_input_tokens=write, reported=bool(raw))


class Adapter(ABC):
    def __init__(self, config: ModelConfig, client: httpx.AsyncClient):
        self.config, self.client = config, client

    @abstractmethod
    def payload(self, request: GenerateRequest, messages: list[Message]) -> dict:
        raise NotImplementedError

    @abstractmethod
    def headers(self) -> dict:
        raise NotImplementedError

    @abstractmethod
    def decode_response(self, body: dict, structured: bool):
        raise NotImplementedError

    @abstractmethod
    async def decode_stream(self, response: httpx.Response, structured: bool):
        yield  # pragma: no cover

    async def events(self, request: GenerateRequest, messages: list[Message]):
        try:
            async with self.client.stream("POST", self.config.url, headers=self.headers(),
                                          json=self.payload(request, messages)) as response:
                if response.status_code >= 400:
                    raise upstream_error(response.status_code, response.headers.get("retry-after"))
                if request.stream:
                    if "text/event-stream" not in response.headers.get("content-type", ""):
                        raise ServiceError("UPSTREAM_PROTOCOL_ERROR", "Expected upstream SSE response", 502)
                    async for event in self.decode_stream(response, bool(request.response_format)):
                        yield event
                else:
                    try:
                        body = json.loads(await response.aread())
                    except ValueError:
                        raise ServiceError("UPSTREAM_PROTOCOL_ERROR", "Invalid upstream JSON", 502) from None
                    for event in self.decode_response(body, bool(request.response_format)):
                        yield event
        except httpx.TimeoutException:
            raise ServiceError("UPSTREAM_TIMEOUT", "Upstream timed out", 504, retryable=True) from None
        except httpx.TransportError:
            raise ServiceError("UPSTREAM_UNAVAILABLE", "Could not reach upstream", 502, retryable=True) from None
        except (KeyError, TypeError, ValueError, AttributeError):
            raise ServiceError("UPSTREAM_PROTOCOL_ERROR", "Malformed upstream response", 502) from None


class ResponsesAdapter(Adapter):
    def headers(self):
        return {"Authorization": f"Bearer {self.config.api_key}", "Content-Type": "application/json"}

    def payload(self, request, messages):
        body = {"model": self.config.upstream_model, "input": [m.model_dump() for m in messages],
                "stream": request.stream, "max_output_tokens": request.max_output_tokens}
        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.response_format:
            fmt = request.response_format
            body["text"] = {"format": {"type": fmt.type}}
            if fmt.type == "json_schema":
                body["text"]["format"].update(name=fmt.name, schema=fmt.schema_, strict=True)
            # Some compatible gateways accept text.format but do not forward its
            # schema constraint. Include it in the context as well; validation at
            # the service boundary remains mandatory for every result.
            instruction = "Return only valid JSON without markdown fences or commentary."
            if fmt.type == "json_schema":
                instruction += " The complete result MUST satisfy this JSON Schema: " + json.dumps(fmt.schema_, ensure_ascii=False)
            else:
                instruction += " The result must be a JSON object."
            body["input"].insert(0, {"role": "system", "content": instruction})
        return body

    def decode_response(self, body, structured=False):
        if body.get("usage"):
            yield responses_usage(body["usage"])
        for item in body.get("output", []):
            for block in item.get("content", []):
                if block.get("type") == "refusal":
                    raise ServiceError("MODEL_REFUSAL", "Model refused the request", 422)
                if block.get("type") == "output_text":
                    yield Delta(block["text"])
        if body.get("status") != "completed":
            raise ServiceError("UPSTREAM_INCOMPLETE", "Response did not complete", 502)
        yield Finished("stop")

    async def decode_stream(self, response, structured=False):
        async for event in parse_sse(response.aiter_lines()):
            kind = event.get("type")
            if kind == "response.output_text.delta":
                yield Delta(event["delta"])
            elif kind == "response.refusal.delta":
                raise ServiceError("MODEL_REFUSAL", "Model refused the request", 422)
            elif kind == "response.completed":
                body = event["response"]
                if body.get("usage"):
                    yield responses_usage(body["usage"])
                if body.get("status") != "completed":
                    raise ServiceError("UPSTREAM_INCOMPLETE", "Response did not complete", 502)
                yield Finished("stop")
                return
            elif kind in {"error", "response.failed", "response.incomplete"}:
                body = event.get("response", {})
                if body.get("usage"):
                    yield responses_usage(body["usage"])
                raise ServiceError("UPSTREAM_INCOMPLETE", "Upstream stream failed or was incomplete", 502)
        raise ServiceError("UPSTREAM_INCOMPLETE", "Upstream stream ended without response.completed", 502)


class MessagesAdapter(Adapter):
    def headers(self):
        return {"x-api-key": self.config.api_key, "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"}

    def payload(self, request, messages):
        system, conversation = [], []
        for message in messages:
            if message.role == "system":
                system.append(message.content)
            elif conversation and conversation[-1]["role"] == message.role:
                conversation[-1]["content"] += "\n" + message.content
            else:
                conversation.append(message.model_dump())
        if not conversation or conversation[0]["role"] != "user":
            raise ServiceError("INVALID_MESSAGES", "Messages protocol requires the first non-system message to be user")
        body = {"model": self.config.upstream_model, "messages": conversation,
                "max_tokens": request.max_output_tokens, "stream": request.stream}
        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.response_format:
            # Forced tool use is broadly supported by Messages-compatible gateways.
            # Tool arguments are the structured result; server still validates schema.
            fmt = request.response_format
            if fmt.effective_schema().get("type") != "object":
                raise ServiceError("UNSUPPORTED_SCHEMA", "Messages tool schema requires top-level type object")
            body["tools"] = [{"name": "structured_output", "description": "Return the requested structured result",
                              "input_schema": fmt.effective_schema()}]
            body["tool_choice"] = {"type": "tool", "name": "structured_output"}
            system.append("Use structured_output to return the result. Do not include explanatory text.")
        if system:
            body["system"] = "\n\n".join(system)
        return body

    def decode_response(self, body, structured=False):
        if body.get("usage"):
            yield messages_usage(body["usage"])
        for block in body["content"]:
            if block.get("type") == "text" and not structured:
                yield Delta(block["text"])
            elif block.get("type") == "tool_use" and block.get("name") == "structured_output":
                yield Delta(json.dumps(block["input"], ensure_ascii=False))
        reason = body.get("stop_reason")
        if reason not in {"end_turn", "stop_sequence", "tool_use"}:
            raise ServiceError("UPSTREAM_INCOMPLETE", "Messages response did not complete", 502)
        yield Finished(reason)

    async def decode_stream(self, response, structured=False):
        raw_usage, stop_reason = {}, None
        blocks = {}
        async for event in parse_sse(response.aiter_lines()):
            kind = event.get("type")
            if kind == "message_start":
                raw_usage.update(event["message"].get("usage", {}))
                yield messages_usage(raw_usage)
            elif kind == "content_block_start":
                blocks[event["index"]] = event["content_block"]
            elif kind == "content_block_delta":
                delta = event["delta"]
                block = blocks.get(event["index"], {})
                if delta["type"] == "text_delta" and not structured:
                    yield Delta(delta["text"])
                elif delta["type"] == "input_json_delta" and block.get("name") == "structured_output":
                    yield Delta(delta["partial_json"])
            elif kind == "message_delta":
                raw_usage.update(event.get("usage", {}))
                yield messages_usage(raw_usage)
                stop_reason = event.get("delta", {}).get("stop_reason") or stop_reason
            elif kind == "message_stop":
                if stop_reason not in {"end_turn", "stop_sequence", "tool_use"}:
                    raise ServiceError("UPSTREAM_INCOMPLETE", "Messages stream did not complete", 502)
                yield Finished(stop_reason)
                return
            elif kind == "error":
                transient = event.get("error", {}).get("type") in {"overloaded_error", "rate_limit_error", "api_error"}
                raise ServiceError("UPSTREAM_ERROR", "Messages stream returned an error", 502, retryable=transient)
        raise ServiceError("UPSTREAM_INCOMPLETE", "Upstream stream ended without message_stop", 502)


ADAPTERS = {"responses": ResponsesAdapter, "messages": MessagesAdapter}
