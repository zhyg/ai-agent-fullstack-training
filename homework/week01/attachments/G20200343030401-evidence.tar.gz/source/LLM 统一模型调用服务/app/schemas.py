import json
from typing import Any, Literal

from jsonschema import Draft202012Validator, exceptions
from pydantic import BaseModel, ConfigDict, Field, model_validator
from referencing.exceptions import Unresolvable

from app.errors import ServiceError


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Message(StrictModel):
    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=100_000)


class PromptRef(StrictModel):
    name: str = Field(pattern=r"^[a-zA-Z0-9_-]{1,64}$")
    version: str = Field(pattern=r"^[a-zA-Z0-9_.-]{1,64}$")
    variables: dict[str, str] = Field(default_factory=dict, max_length=50)


def reject_remote_refs(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"$ref", "$dynamicRef"} and (not isinstance(item, str) or not item.startswith("#")):
                raise ValueError("JSON Schema only allows local # references")
            reject_remote_refs(item)
    elif isinstance(value, list):
        for item in value:
            reject_remote_refs(item)


class ResponseFormat(StrictModel):
    type: Literal["json_object", "json_schema"]
    name: str = Field(default="result", pattern=r"^[a-zA-Z0-9_-]{1,64}$")
    # schema_ avoids shadowing BaseModel.schema; the public field is schema.
    schema_: dict[str, Any] | None = Field(default=None, alias="schema")

    @model_validator(mode="after")
    def check_schema(self):
        if self.type == "json_schema" and self.schema_ is None:
            raise ValueError("json_schema requires schema")
        if self.type == "json_object" and self.schema_ is not None:
            raise ValueError("Use json_schema when supplying a schema")
        if self.schema_ is not None:
            if len(json.dumps(self.schema_)) > 32_768:
                raise ValueError("Schema is too large")
            reject_remote_refs(self.schema_)
            try:
                Draft202012Validator.check_schema(self.schema_)
            except exceptions.SchemaError:
                raise ValueError("Invalid JSON Schema") from None
        return self

    def effective_schema(self):
        return self.schema_ if self.type == "json_schema" else {"type": "object"}

    def validate_output(self, text: str):
        try:
            def invalid_constant(value):
                raise ValueError(value)
            value = json.loads(text, parse_constant=invalid_constant)
            Draft202012Validator(self.effective_schema()).validate(value)
            return value
        except (ValueError, exceptions.ValidationError, exceptions.SchemaError, Unresolvable, RecursionError):
            raise ServiceError("INVALID_STRUCTURED_OUTPUT", "Model output is not valid JSON matching response_format", 502) from None


class GenerateRequest(StrictModel):
    model: str = Field(min_length=1, max_length=128)
    messages: list[Message] = Field(default_factory=list, max_length=100)
    prompt: PromptRef | None = None
    stream: bool = False
    response_format: ResponseFormat | None = None
    max_output_tokens: int = Field(default=1024, ge=1, le=32_768)
    temperature: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def has_input(self):
        if not self.messages and not self.prompt:
            raise ValueError("messages or prompt is required")
        if sum(len(message.content) for message in self.messages) > 200_000:
            raise ValueError("Combined messages exceed 200000 characters")
        return self


class Usage(BaseModel):
    input_tokens: int = Field(default=0, ge=0)
    output_tokens: int = Field(default=0, ge=0)
    cache_read_input_tokens: int = Field(default=0, ge=0)
    cache_write_input_tokens: int = Field(default=0, ge=0)
    reasoning_output_tokens: int = Field(default=0, ge=0)
    reported: bool = False

    @property
    def total_tokens(self):
        return self.input_tokens + self.output_tokens

    def public(self):
        return {**self.model_dump(), "total_tokens": self.total_tokens}
