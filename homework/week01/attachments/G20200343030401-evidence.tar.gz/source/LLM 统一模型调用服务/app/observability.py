import asyncio
import json
import logging
import math
import sqlite3
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from pathlib import Path

from app.errors import ServiceError

logger = logging.getLogger("llm.calls")


class RateLimiter:
    """Per-process sliding window; one accepted logical call consumes one slot."""

    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.windows = defaultdict(deque)
        self.lock = asyncio.Lock()

    async def acquire(self, model: str, rpm: int):
        async with self.lock:
            now = self.clock()
            window = self.windows[model]
            while window and now - window[0] >= 60:
                window.popleft()
            if len(window) >= rpm:
                raise ServiceError("RATE_LIMITED", "Model request limit exceeded", 429,
                                   retry_after=math.ceil(60 - (now - window[0])))
            window.append(now)


class MetricsStore:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self.connect() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("CREATE TABLE IF NOT EXISTS calls (request_id TEXT PRIMARY KEY, data TEXT NOT NULL)")

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.path, timeout=10)
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def record(self, value: dict):
        with self.connect() as connection:
            connection.execute("INSERT INTO calls VALUES (?, ?)", (value["request_id"], json.dumps(value, ensure_ascii=False)))
        logger.info(json.dumps(value, ensure_ascii=False))

    def recent(self, limit=50):
        with self.connect() as connection:
            return [json.loads(row[0]) for row in connection.execute("SELECT data FROM calls ORDER BY rowid DESC LIMIT ?", (limit,))]

    def summary(self):
        result = {}
        with self.connect() as connection:
            for row in connection.execute("SELECT data FROM calls"):
                value = json.loads(row[0])
                item = result.setdefault(value["model"], {"calls": 0, "errors": 0, "attempts": 0,
                    "input_tokens": 0, "output_tokens": 0, "total_tokens": 0, "cache_read_input_tokens": 0,
                    "cache_write_input_tokens": 0, "reasoning_output_tokens": 0, "latency_ms_sum": 0,
                    "ttft_ms_sum": 0, "ttft_samples": 0})
                item["calls"] += 1
                item["errors"] += value["status"] != "ok"
                item["attempts"] += len(value["attempts"])
                item["latency_ms_sum"] += value["latency_ms"]
                if value["ttft_ms"] is not None:
                    item["ttft_ms_sum"] += value["ttft_ms"]
                    item["ttft_samples"] += 1
                for key in value["usage"]:
                    if key in item and key != "reported":
                        item[key] += value["usage"][key]
        for item in result.values():
            item["avg_latency_ms"] = round(item["latency_ms_sum"] / item["calls"], 3)
            item["avg_ttft_ms"] = round(item["ttft_ms_sum"] / item["ttft_samples"], 3) if item["ttft_samples"] else None
        return result
