"""Deterministic HTTP protocol fixture. Imported only in explicit mock mode/tests."""
import asyncio
import json

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

from app.sse import encode

mock_app = FastAPI()


def fixture(body, protocol):
    messages = body.get("input", body.get("messages", []))
    prompt = " ".join(m["content"] for m in messages)
    structured = bool(body.get("text") or body.get("tools"))
    if "[invalid-json]" in prompt:
        text = "not JSON"
    elif structured:
        text = json.dumps({"answer": "统一调用成功", "model": body["model"]}, ensure_ascii=False)
    else:
        text = f"模拟回答（{protocol}）：{messages[-1]['content']}"
    return prompt, text, structured


@mock_app.post("/v1/responses")
async def responses(request: Request):
    body = await request.json()
    if not request.headers.get("authorization", "").startswith("Bearer "):
        return JSONResponse({}, 401)
    assert "input" in body and "max_output_tokens" in body and "messages" not in body
    prompt, text, structured = fixture(body, "responses")
    if "[always-503]" in prompt:
        return JSONResponse({}, 503)
    response = {"id": "resp_mock", "object": "response", "status": "completed",
                "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}],
                "usage": {"input_tokens": 20, "output_tokens": 12,
                          "input_tokens_details": {"cached_tokens": 4},
                          "output_tokens_details": {"reasoning_tokens": 3}}}
    if not body.get("stream"):
        return response

    async def stream():
        yield ": keep-alive\n\n"
        yield encode("response.created", {"type": "response.created", "response": {"id": "resp_mock"}})
        for index in range(0, len(text), 4):
            await asyncio.sleep(0.005)
            yield encode("response.output_text.delta", {"type": "response.output_text.delta", "delta": text[index:index + 4]})
        if "[truncated]" in prompt:
            return
        yield encode("response.completed", {"type": "response.completed", "response": response})
    return StreamingResponse(stream(), media_type="text/event-stream")


@mock_app.post("/v1/messages")
async def messages(request: Request):
    body = await request.json()
    if "x-api-key" not in request.headers or request.headers.get("anthropic-version") != "2023-06-01":
        return JSONResponse({}, 401)
    assert "messages" in body and "max_tokens" in body and "input" not in body
    assert all(m["role"] != "system" for m in body["messages"])
    prompt, text, structured = fixture(body, "messages")
    if "[always-503]" in prompt:
        return JSONResponse({}, 503)
    usage = {"input_tokens": 16, "output_tokens": 12, "cache_read_input_tokens": 4, "cache_creation_input_tokens": 2}
    reason = "tool_use" if structured else "end_turn"
    block = {"type": "text", "text": text}
    if structured:
        block = {"type": "tool_use", "id": "tool_mock", "name": "structured_output",
                 "input": text if "[invalid-json]" in prompt else json.loads(text)}
    response = {"id": "msg_mock", "type": "message", "role": "assistant", "content": [block],
                "stop_reason": reason, "usage": usage}
    if not body.get("stream"):
        return response

    async def stream():
        yield encode("message_start", {"type": "message_start", "message": {"id": "msg_mock", "usage": {**usage, "output_tokens": 0}}})
        yield encode("content_block_start", {"type": "content_block_start", "index": 0,
                    "content_block": {"type": "tool_use", "name": "structured_output", "id": "tool_mock", "input": {}} if structured else {"type": "text", "text": ""}})
        for index in range(0, len(text), 4):
            await asyncio.sleep(0.005)
            delta = {"type": "input_json_delta", "partial_json": text[index:index + 4]} if structured else {"type": "text_delta", "text": text[index:index + 4]}
            yield encode("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": delta})
        if "[truncated]" in prompt:
            return
        yield encode("content_block_stop", {"type": "content_block_stop", "index": 0})
        yield encode("message_delta", {"type": "message_delta", "delta": {"stop_reason": reason}, "usage": {"output_tokens": 12}})
        yield encode("message_stop", {"type": "message_stop"})
    return StreamingResponse(stream(), media_type="text/event-stream")
