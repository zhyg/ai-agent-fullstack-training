import logging
import math
from contextlib import aclosing, asynccontextmanager
from uuid import uuid4

import httpx
from fastapi import FastAPI, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.exceptions import HTTPException

from app.config import MODEL_ALIASES, Settings
from app.errors import ServiceError
from app.schemas import GenerateRequest
from app.service import LLMService
from app.sse import encode


def create_app(settings: Settings | None = None, *, transport=None, sleep=None):
    @asynccontextmanager
    async def lifespan(app):
        config = settings or Settings.from_env()
        upstream_transport = transport
        if upstream_transport is None and config.mode == "mock":
            from app.mock_upstream import mock_app
            upstream_transport = httpx.ASGITransport(app=mock_app)
        async with httpx.AsyncClient(transport=upstream_transport, timeout=config.timeout_seconds,
                                     follow_redirects=False) as client:
            app.state.settings = config
            app.state.service = LLMService(config, client, **({"sleep": sleep} if sleep else {}))
            yield

    app = FastAPI(title="LLM 统一模型调用服务", version="1.0.0", lifespan=lifespan)

    @app.middleware("http")
    async def request_id_middleware(request: Request, call_next):
        request.state.request_id = f"req_{uuid4().hex}"
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    @app.exception_handler(ServiceError)
    async def service_error(request, error):
        headers = {}
        if error.retry_after is not None:
            headers["Retry-After"] = str(math.ceil(error.retry_after))
        return JSONResponse(error.body(request.state.request_id), status_code=error.status, headers=headers)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, error):
        # Avoid returning raw request content / credentials in validation errors.
        return JSONResponse(ServiceError("INVALID_REQUEST", "Invalid request; check fields and JSON Schema", 422)
                            .body(request.state.request_id), status_code=422)

    @app.exception_handler(HTTPException)
    async def http_error(request, error):
        return JSONResponse(ServiceError("HTTP_ERROR", str(error.detail), error.status_code)
                            .body(request.state.request_id), status_code=error.status_code)

    @app.exception_handler(Exception)
    async def unexpected_error(request, error):
        logging.getLogger("llm.errors").exception("Unexpected failure request_id=%s", request.state.request_id)
        return JSONResponse(ServiceError("INTERNAL_ERROR", "Internal service error", 500)
                            .body(request.state.request_id), status_code=500)

    @app.get("/health")
    async def health():
        return {"status": "ok", "mode": app.state.settings.mode}

    @app.get("/v1/models")
    async def models():
        return {"mode": app.state.settings.mode, "models": [{"id": model.name, "protocol": model.protocol,
                "upstream_model": model.upstream_model,
                "aliases": [alias for alias, target in MODEL_ALIASES.items() if target == model.name],
                "rpm": model.rpm} for model in app.state.settings.models.values()]}

    @app.get("/v1/prompts")
    async def prompts():
        return {"prompts": app.state.service.prompts.list_versions()}

    @app.get("/v1/metrics/calls")
    async def calls(limit: int = Query(default=50, ge=1, le=1000)):
        return {"calls": app.state.service.metrics.recent(limit)}

    @app.get("/v1/metrics/summary")
    async def summary():
        return {"models": app.state.service.metrics.summary()}

    @app.post("/v1/generate")
    async def generate(body: GenerateRequest, request: Request):
        events = app.state.service.generate(body, request.state.request_id)
        if not body.stream:
            async with aclosing(events):
                async for kind, value in events:
                    if kind == "completed":
                        return value
        # Prime before sending HTTP headers so pre-output failures retain HTTP status.
        try:
            first_kind, first_value = await anext(events)
        except BaseException:
            await events.aclose()
            raise

        async def stream():
            try:
                async with aclosing(events):
                    yield encode(first_kind, first_value)
                    async for kind, value in events:
                        yield encode(kind, value)
            except ServiceError as error:
                # HTTP headers already sent; terminal SSE error replaces completed.
                yield encode("error", error.body(request.state.request_id))
            except Exception:
                logging.getLogger("llm.errors").exception("Streaming failure request_id=%s", request.state.request_id)
                yield encode("error", ServiceError("INTERNAL_ERROR", "Internal service error", 500).body(request.state.request_id))
        return StreamingResponse(stream(), media_type="text/event-stream", headers={
            "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    return app


app = create_app()
