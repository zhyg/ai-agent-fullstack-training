import asyncio
import json

import httpx
import pytest

from app.observability import RateLimiter
from app.errors import ServiceError
from app.mock_upstream import mock_app
from app.schemas import GenerateRequest
from app.sse import parse_sse
from tests.conftest import MODELS

FORMAT = {"type": "json_schema", "schema": {"type": "object", "properties": {
    "answer": {"type": "string"}, "model": {"type": "string"}}, "required": ["answer", "model"], "additionalProperties": False}}


def payload(model=MODELS[0], **kwargs):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **kwargs}


def sse_events(response):
    events = []
    for block in response.text.strip().split("\n\n"):
        lines = block.splitlines()
        events.append((lines[0].removeprefix("event: "), json.loads(lines[1].removeprefix("data: "))))
    return events


@pytest.mark.parametrize("model", MODELS)
async def test_blocking_routing_usage_and_metrics(app_factory, evidence, model):
    async with app_factory() as (client, app):
        response = await client.post("/v1/generate", json=payload(model))
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["model"] == model and body["output_text"] and body["mode"] == "mock"
        assert body["ttft_ms"] is None and body["latency_ms"] > 0 and body["attempts"] == 1
        assert body["request_id"] == response.headers["x-request-id"]
        assert body["usage"]["input_tokens"] == (20 if model == MODELS[0] else 22)
        assert body["usage"]["total_tokens"] == (32 if model == MODELS[0] else 34)
        assert body["usage"]["cache_read_input_tokens"] == 4 and body["usage_complete"]
        assert body["usage"]["reasoning_output_tokens"] == (3 if model == MODELS[0] else 0)
        assert body["usage"]["cache_write_input_tokens"] == (0 if model == MODELS[0] else 2)
        calls = (await client.get("/v1/metrics/calls")).json()["calls"]
        assert calls[0]["status"] == "ok" and calls[0]["usage"] == body["usage"]
        summary = (await client.get("/v1/metrics/summary")).json()["models"][model]
        assert summary["total_tokens"] == body["usage"]["total_tokens"]
        assert "test-secret" not in json.dumps(calls)
        evidence[f"blocking:{model}"] = {"response": body, "record": calls[0], "summary": summary}


@pytest.mark.parametrize("model", MODELS)
@pytest.mark.parametrize("structured", [False, True])
async def test_streaming(app_factory, evidence, model, structured):
    async with app_factory() as (client, app):
        extra = {"response_format": FORMAT} if structured else {}
        response = await client.post("/v1/generate", json=payload(model, stream=True, **extra))
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/event-stream")
        events = sse_events(response)
        assert len(events) > 2 and events[-1][0] == "completed"
        assert all(kind == "delta" for kind, _ in events[:-1])
        completed = events[-1][1]
        assert "".join(value["delta"] for _, value in events[:-1]) == completed["output_text"]
        assert completed["ttft_ms"] is not None and 0 < completed["ttft_ms"] <= completed["latency_ms"]
        assert completed["usage_complete"]
        if structured:
            assert completed["structured_output"]["answer"] == "统一调用成功"
        evidence[f"stream:{model}:structured={structured}"] = {"sse": response.text, "response": completed}


@pytest.mark.parametrize("model", MODELS)
@pytest.mark.parametrize("fmt", [FORMAT, {"type": "json_object"}])
async def test_structured_output(app_factory, model, fmt):
    async with app_factory() as (client, app):
        response = await client.post("/v1/generate", json=payload(model, response_format=fmt))
        assert response.status_code == 200, response.text
        assert response.json()["structured_output"] == json.loads(response.json()["output_text"])


@pytest.mark.parametrize("model", MODELS)
async def test_prompt_versions(app_factory, evidence, model):
    async with app_factory() as (client, app):
        results = []
        for version in ["v1", "v2"]:
            request = {"model": model, "prompt": {"name": "explain", "version": version,
                       "variables": {"language": "中文", "topic": "适配器模式"}}}
            response = await client.post("/v1/generate", json=request)
            assert response.status_code == 200
            assert "适配器模式" in response.json()["output_text"]
            assert response.json()["prompt"]["version"] == version
            results.append(response.json())
        assert results[0]["output_text"] != results[1]["output_text"]
        evidence[f"templates:{model}"] = results


async def test_template_errors_and_literal_substitution(app_factory):
    async with app_factory() as (client, app):
        for ref, code, status in [
            ({"name": "explain", "version": "missing", "variables": {}}, "PROMPT_NOT_FOUND", 404),
            ({"name": "explain", "version": "v1", "variables": {}}, "PROMPT_VARIABLE_ERROR", 400),
            ({"name": "../escape", "version": "v1"}, "INVALID_REQUEST", 422),
        ]:
            result = await client.post("/v1/generate", json={"model": MODELS[0], "prompt": ref})
            assert result.status_code == status and result.json()["error"]["code"] == code
        result = await client.post("/v1/generate", json={"model": MODELS[0], "prompt": {
            "name": "explain", "version": "v1", "variables": {"language": "中文", "topic": r"{{language}}\1"}}})
        assert r"{{language}}\1" in result.json()["output_text"]


async def test_independent_rate_limits_and_concurrency(app_factory, evidence):
    async with app_factory(rpm=1) as (client, app):
        responses = await asyncio.gather(*[client.post("/v1/generate", json=payload()) for _ in range(4)])
        assert sorted(result.status_code for result in responses) == [200, 429, 429, 429]
        limited = next(result for result in responses if result.status_code == 429)
        assert limited.json()["error"]["code"] == "RATE_LIMITED"
        assert 1 <= int(limited.headers["retry-after"]) <= 60
        other = await client.post("/v1/generate", json=payload(MODELS[1]))
        assert other.status_code == 200
        evidence["rate_limit"] = {"concurrent_statuses": [r.status_code for r in responses],
                                  "limited": limited.json(), "retry_after": limited.headers["retry-after"],
                                  "other_model_status": other.status_code}


async def test_sliding_window_expires():
    now = [100.0]
    limiter = RateLimiter(clock=lambda: now[0])
    await limiter.acquire("pro", 1)
    now[0] = 159.9
    with pytest.raises(ServiceError):
        await limiter.acquire("pro", 1)
    now[0] = 160
    await limiter.acquire("pro", 1)


@pytest.mark.parametrize("model", MODELS)
@pytest.mark.parametrize("failure", [503, 408, 429, "timeout", "connect"])
async def test_retry_then_success(app_factory, evidence, model, failure):
    count, delays = 0, []
    fixture_transport = httpx.ASGITransport(mock_app)

    async def handler(request):
        nonlocal count
        count += 1
        if count <= 3:
            if failure == "timeout":
                raise httpx.ReadTimeout("fixture timeout")
            if failure == "connect":
                raise httpx.ConnectError("fixture disconnect")
            return httpx.Response(failure, headers={"Retry-After": "0.4"} if failure == 429 else {})
        return await fixture_transport.handle_async_request(request)

    async def sleep(delay):
        delays.append(delay)

    async with app_factory(transport=httpx.MockTransport(handler), sleep=sleep, base=0.1) as (client, app):
        response = await client.post("/v1/generate", json=payload(model, stream=True))
        assert response.status_code == 200, response.text
        completed = sse_events(response)[-1][1]
        assert completed["attempts"] == count == 4
        assert len(delays) == 3
        assert all(delay >= base for delay, base in zip(delays, [0.1, 0.2, 0.4]))
        if failure == 429:
            assert all(delay >= 0.4 for delay in delays)
        record = (await client.get("/v1/metrics/calls")).json()["calls"][0]
        assert len(record["attempts"]) == 4 and not record["usage_complete"]
        evidence[f"retry:{model}:{failure}"] = {"delays": delays, "record": record}


@pytest.mark.parametrize("model", MODELS)
async def test_retry_exhausted(app_factory, evidence, model):
    async with app_factory() as (client, app):
        result = await client.post("/v1/generate", json=payload(model, messages=[{"role": "user", "content": "[always-503]"}], stream=True))
        assert result.status_code == 502 and result.json()["error"]["code"] == "UPSTREAM_ERROR"
        record = (await client.get("/v1/metrics/calls")).json()["calls"][0]
        assert len(record["attempts"]) == 4 and record["status"] == "error"
        evidence[f"retry_exhausted:{model}"] = {"response": result.json(), "record": record}


@pytest.mark.parametrize("status", [400, 401, 403, 404])
async def test_permanent_errors_not_retried(app_factory, status):
    count = 0

    def handler(request):
        nonlocal count
        count += 1
        return httpx.Response(status, json={"error": "secret upstream body"})

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        result = await client.post("/v1/generate", json=payload())
        assert result.status_code == 502 and count == 1
        assert "secret upstream body" not in result.text


@pytest.mark.parametrize("model", MODELS)
async def test_truncated_stream_no_retry_or_false_success(app_factory, evidence, model):
    async with app_factory() as (client, app):
        result = await client.post("/v1/generate", json=payload(model, stream=True,
                                   messages=[{"role": "user", "content": "[truncated]"}]))
        events = sse_events(result)
        assert result.status_code == 200 and events[-1][0] == "error"
        assert events[-1][1]["error"]["code"] == "UPSTREAM_INCOMPLETE"
        assert not any(kind == "completed" for kind, _ in events)
        record = (await client.get("/v1/metrics/calls")).json()["calls"][0]
        assert len(record["attempts"]) == 1 and record["status"] == "error"
        evidence[f"truncated:{model}"] = {"sse": result.text, "record": record}


@pytest.mark.parametrize("model", MODELS)
@pytest.mark.parametrize("stream", [False, True])
async def test_invalid_structured_output(app_factory, model, stream):
    async with app_factory() as (client, app):
        result = await client.post("/v1/generate", json=payload(model, response_format=FORMAT, stream=stream,
                                   messages=[{"role": "user", "content": "[invalid-json]"}]))
        if stream:
            assert sse_events(result)[-1][1]["error"]["code"] == "INVALID_STRUCTURED_OUTPUT"
        else:
            assert result.status_code == 502 and result.json()["error"]["code"] == "INVALID_STRUCTURED_OUTPUT"


async def test_schema_mismatch_and_remote_refs(app_factory):
    async with app_factory() as (client, app):
        wrong = {"type": "json_schema", "schema": {"type": "object", "required": ["missing"]}}
        result = await client.post("/v1/generate", json=payload(response_format=wrong))
        assert result.status_code == 502 and result.json()["error"]["code"] == "INVALID_STRUCTURED_OUTPUT"
        for schema in [{"$ref": "https://example.com/schema"}, {"type": "invalid-type"}]:
            result = await client.post("/v1/generate", json=payload(response_format={"type": "json_schema", "schema": schema}))
            assert result.status_code == 422


async def test_validation_and_unknown_model(app_factory):
    async with app_factory() as (client, app):
        for body in [{"model": MODELS[0]}, payload(stream="true", extra="forbidden"),
                     payload(max_output_tokens=0), payload(messages=[{"role": "tool", "content": "x"}])]:
            result = await client.post("/v1/generate", json=body)
            assert result.status_code == 422
        result = await client.post("/v1/generate", json=payload("missing"))
        assert result.status_code == 404 and result.json()["error"]["code"] == "MODEL_NOT_FOUND"
        result = await client.post("/v1/generate", content="{")
        assert result.status_code == 422
        assert (await client.get("/v1/models")).json()["models"][0]["protocol"] == "responses"
        assert len((await client.get("/v1/prompts")).json()["prompts"]) == 2


async def test_protocol_payloads_and_auth(app_factory):
    seen = []
    transport = httpx.ASGITransport(mock_app)

    async def handler(request):
        seen.append((dict(request.headers), json.loads(request.content)))
        return await transport.handle_async_request(request)

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        for model in MODELS:
            response = await client.post("/v1/generate", json=payload(model, response_format=FORMAT,
                messages=[{"role": "system", "content": "be helpful"}, {"role": "user", "content": "hi"}]))
            assert response.status_code == 200
    pro_headers, pro_body = seen[0]
    flash_headers, flash_body = seen[1]
    assert pro_headers["authorization"] == "Bearer test-secret" and "x-api-key" not in pro_headers
    assert pro_body["text"]["format"]["strict"] is True and "response_format" not in pro_body
    assert flash_headers["x-api-key"] == "test-secret" and "authorization" not in flash_headers
    assert flash_headers["anthropic-version"] == "2023-06-01" and "be helpful" in flash_body["system"]
    assert flash_body["tool_choice"]["name"] == "structured_output"


async def test_sse_comments_multiline_and_crlf():
    async def lines():
        for line in [": ping", "event: x", 'data: {"type":', 'data: "test"}', "", "data: [DONE]"]:
            yield line
    assert [event async for event in parse_sse(lines())] == [{"type": "test"}, {"type": "transport_done"}]


async def test_cancellation_closes_upstream_and_records_call(app_factory):
    closed = []

    class Bytes(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield b'data: {"type":"response.output_text.delta","delta":"hello"}\n\n'
            await asyncio.sleep(10)

        async def aclose(self):
            closed.append(True)

    async with app_factory(transport=httpx.MockTransport(lambda request: httpx.Response(200,
        headers={"content-type": "text/event-stream"}, stream=Bytes()))) as (client, app):
        events = app.state.service.generate(GenerateRequest.model_validate(payload(stream=True)), "req_cancel")
        assert (await anext(events))[0] == "delta"
        await events.aclose()
        record = app.state.service.metrics.recent()[0]
        assert record["status"] == "cancelled" and closed
        assert record["attempts"][0]["status"] == "cancelled"


async def test_first_delta_arrives_before_upstream_finishes(app_factory):
    """A gated upstream proves the service does not collect the whole stream first."""
    release = asyncio.Event()
    closed = []

    class Bytes(httpx.AsyncByteStream):
        async def __aiter__(self):
            text = 'data: {"type":"response.output_text.delta","delta":"中文"}\r\n\r\n'.encode()
            # Deliberately split within multibyte Chinese characters and SSE fields.
            for byte in text:
                yield bytes([byte])
            await release.wait()
            yield b'data: {"type":"response.completed","response":{"status":"completed","usage":{"input_tokens":2,"output_tokens":1}}}\n\n'

        async def aclose(self):
            closed.append(True)

    async with app_factory(transport=httpx.MockTransport(lambda request: httpx.Response(200,
        headers={"content-type": "text/event-stream"}, stream=Bytes()))) as (client, app):
        events = app.state.service.generate(GenerateRequest.model_validate(payload(stream=True)), "req_gated")
        try:
            kind, value = await asyncio.wait_for(anext(events), timeout=2)
            assert kind == "delta" and value["delta"] == "中文" and not release.is_set()
            release.set()
            kind, value = await anext(events)
            assert kind == "completed" and value["usage"]["total_tokens"] == 3
        finally:
            await events.aclose()
        assert closed


async def test_metrics_persist_and_missing_usage_is_explicit(app_factory):
    from app.observability import MetricsStore

    def handler(request):
        return httpx.Response(200, json={"status": "completed", "output": [
            {"content": [{"type": "output_text", "text": "answer"}]}]})

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        result = await client.post("/v1/generate", json=payload())
        assert result.status_code == 200
        assert not result.json()["usage_complete"] and not result.json()["usage"]["reported"]
        reopened = MetricsStore(app.state.settings.metrics_db)
        assert reopened.recent()[0]["request_id"] == result.json()["request_id"]


async def test_live_config_requires_real_urls_and_credentials(monkeypatch):
    from app.config import Settings

    monkeypatch.setenv("APP_MODE", "live")
    monkeypatch.setenv("PRO_API_KEY", "")
    monkeypatch.setenv("GATEWAY_API_KEY", "")
    with pytest.raises(ValueError, match="live mode requires"):
        Settings.from_env()


@pytest.mark.parametrize("model", MODELS)
async def test_timeout_exhaustion_has_http_504(app_factory, model):
    def handler(request):
        raise httpx.ReadTimeout("timeout")

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        result = await client.post("/v1/generate", json=payload(model, stream=True))
        assert result.status_code == 504
        assert result.json()["error"]["code"] == "UPSTREAM_TIMEOUT"
        assert len(app.state.service.metrics.recent()[0]["attempts"]) == 4


async def test_unknown_local_schema_ref_is_a_controlled_failure(app_factory):
    async with app_factory() as (client, app):
        result = await client.post("/v1/generate", json=payload(response_format={
            "type": "json_schema", "schema": {"$ref": "#/$defs/missing"}}))
        assert result.status_code == 502
        assert result.json()["error"]["code"] == "INVALID_STRUCTURED_OUTPUT"


async def test_messages_stream_error_retries_only_before_text(app_factory):
    count = 0
    transport = httpx.ASGITransport(mock_app)

    async def handler(request):
        nonlocal count
        count += 1
        if count == 1:
            return httpx.Response(200, headers={"content-type": "text/event-stream"},
                content=b'data: {"type":"error","error":{"type":"overloaded_error"}}\n\n')
        return await transport.handle_async_request(request)

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        result = await client.post("/v1/generate", json=payload(MODELS[1], stream=True))
        assert sse_events(result)[-1][0] == "completed" and count == 2


async def test_transient_error_after_first_text_is_not_retried(app_factory):
    count = 0

    class Bytes(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield b'data: {"type":"response.output_text.delta","delta":"first"}\n\n'
            raise httpx.ReadTimeout("timeout after text")

    def handler(request):
        nonlocal count
        count += 1
        return httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=Bytes())

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        result = await client.post("/v1/generate", json=payload(stream=True))
        events = sse_events(result)
        assert events[0][1]["delta"] == "first"
        assert events[-1][0] == "error" and events[-1][1]["error"]["code"] == "UPSTREAM_TIMEOUT"
        assert count == 1
