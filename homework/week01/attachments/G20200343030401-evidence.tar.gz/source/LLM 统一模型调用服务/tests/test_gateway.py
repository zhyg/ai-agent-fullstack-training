import httpx

from app.config import ModelConfig, Settings
from app.main import create_app


def test_tokenhub_shared_config_and_model_ids(monkeypatch):
    for variable in ["PRO_RESPONSES_URL", "FLASH_MESSAGES_URL", "PRO_API_KEY", "FLASH_API_KEY",
                     "PRO_UPSTREAM_MODEL", "FLASH_UPSTREAM_MODEL"]:
        monkeypatch.setenv(variable, "")
    # Explicit values also isolate this test from the user's private .env.
    monkeypatch.setenv("PRO_UPSTREAM_MODEL", "deepseek-v4-pro")
    monkeypatch.setenv("FLASH_UPSTREAM_MODEL", "deepseek/deepseek-flash")
    monkeypatch.setenv("APP_MODE", "live")
    monkeypatch.setenv("GATEWAY_BASE_URL", "https://tokenhub.tencentmaas.com/v1/")
    monkeypatch.setenv("GATEWAY_API_KEY", "fixture-shared-key")
    settings = Settings.from_env()
    pro = settings.models["deepseek-v4-pro"]
    flash = settings.models["deepseek/deepseek-flash"]
    assert pro.url == "https://tokenhub.tencentmaas.com/v1/responses"
    assert flash.url == "https://tokenhub.tencentmaas.com/v1/messages"
    assert pro.api_key == flash.api_key == "fixture-shared-key"
    assert pro.upstream_model == "deepseek-v4-pro"
    assert flash.upstream_model == "deepseek/deepseek-flash"
    monkeypatch.setenv("PRO_API_KEY", "fixture-pro-override")
    monkeypatch.setenv("PRO_RESPONSES_URL", "https://override.example.org/responses")
    settings = Settings.from_env()
    assert settings.models[pro.name].api_key == "fixture-pro-override"
    assert settings.models[pro.name].url == "https://override.example.org/responses"
    assert settings.models[flash.name].api_key == "fixture-shared-key"


async def test_flash_alias_shares_model_rate_limit(tmp_path):
    from app.mock_upstream import mock_app

    name = "deepseek/deepseek-flash"
    settings = Settings("mock", {name: ModelConfig(name, "messages", "https://mock.local/v1/messages",
        "fixture-key", name, rpm=1)}, tmp_path / "metrics.sqlite3")
    app = create_app(settings, transport=httpx.ASGITransport(mock_app))
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://service") as client:
            body = {"messages": [{"role": "user", "content": "hello"}]}
            response = await client.post("/v1/generate", json={**body, "model": "deepseek-v4-flash"})
            assert response.status_code == 200
            assert response.json()["model"] == response.json()["upstream_model"] == name
            assert response.json()["requested_model"] == "deepseek-v4-flash"
            response = await client.post("/v1/generate", json={**body, "model": name})
            assert response.status_code == 429
            models = (await client.get("/v1/models")).json()["models"]
            assert models[0]["aliases"] == ["deepseek-v4-flash"]


async def test_quota_exhaustion_is_actionable_and_not_retried(app_factory, evidence):
    attempts = []

    def handler(request):
        attempts.append(1)
        return httpx.Response(402, json={"error": {"code": "401008", "message": "fixture quota exhausted"}})

    async with app_factory(transport=httpx.MockTransport(handler)) as (client, app):
        response = await client.post("/v1/generate", json={"model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "hello"}]})
        assert response.status_code == 402
        assert response.json()["error"]["code"] == "UPSTREAM_QUOTA_EXHAUSTED"
        assert not response.json()["error"]["retryable"] and len(attempts) == 1
        evidence["quota_exhaustion"] = {"response": response.json(), "attempts": len(attempts)}


def test_responses_includes_schema_instruction_for_compatible_gateways():
    import json
    from app.adapters import ResponsesAdapter
    from app.schemas import GenerateRequest

    schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
    request = GenerateRequest(model="deepseek-v4-pro", messages=[{"role": "user", "content": "hi"}],
                              response_format={"type": "json_schema", "schema": schema})
    config = ModelConfig("deepseek-v4-pro", "responses", "https://gateway.example.org/responses",
                         "fixture-key", "deepseek-v4-pro")
    adapter = ResponsesAdapter(config, None)
    body = adapter.payload(request, request.messages)
    assert json.dumps(schema) in body["input"][0]["content"]
    assert body["text"]["format"]["schema"] == schema
