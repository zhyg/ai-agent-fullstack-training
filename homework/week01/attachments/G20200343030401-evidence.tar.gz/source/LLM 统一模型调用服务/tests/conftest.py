import json
import os
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import pytest

from app.config import ModelConfig, Settings
from app.main import create_app

ROOT = Path(__file__).resolve().parents[1]
MODELS = ["deepseek-v4-pro", "deepseek-v4-flash"]


@pytest.fixture
def app_factory(tmp_path):
    counter = 0

    @asynccontextmanager
    async def factory(*, transport=None, rpm=100, sleep=None, base=0):
        nonlocal counter
        counter += 1
        settings = Settings("mock", {
            name: ModelConfig(name, protocol, f"https://mock.local/v1/{protocol}", "test-secret", name, rpm)
            for name, protocol in zip(MODELS, ["responses", "messages"])
        }, tmp_path / f"metrics-{counter}.sqlite3", ROOT / "prompts", retry_base_seconds=base)
        app = create_app(settings, transport=transport, sleep=sleep)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://service") as client:
                yield client, app
    return factory


@pytest.fixture(scope="session")
def evidence():
    records = {}
    yield records
    filename = os.getenv("EVIDENCE_FILE")
    if filename:
        path = Path(filename)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"mode": "mock", "notice": "Protocol fixtures; not evidence of live model availability",
                                    "evidence": records}, ensure_ascii=False, indent=2), encoding="utf-8")
