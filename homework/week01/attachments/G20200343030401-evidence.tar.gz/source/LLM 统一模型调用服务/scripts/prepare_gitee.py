"""Build and scan a source-only Git checkout for publishing to Gitee.

The original worktree and private .env are left in place. No network requests.
"""
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[1]
PUBLISH = ROOT / ".publish"
CHECKOUT = PUBLISH / "geektime-ai-agent-bootcamp"
PROJECT_NAME = "LLM 统一模型调用服务"


def run(*args):
    return subprocess.run(args, cwd=CHECKOUT, check=True, capture_output=True,
                          encoding="utf-8", errors="replace").stdout.strip()


def main():
    if (CHECKOUT / ".git").exists():
        head = subprocess.run(["git", "rev-parse", "--verify", "HEAD"], cwd=CHECKOUT, capture_output=True)
        if head.returncode == 0:
            raise SystemExit("Publish checkout already has a commit; inspect it before preparing again.")
    project = CHECKOUT / PROJECT_NAME
    project.mkdir(parents=True, exist_ok=True)
    for directory in ["app", "prompts", "scripts", "tests"]:
        shutil.copytree(ROOT / directory, project / directory,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"), dirs_exist_ok=True)
    for filename in [".gitignore", ".env.example", "README.md", "pytest.ini",
                     "requirements.txt", "requirements-dev.txt", "requirements-lock.txt"]:
        shutil.copy2(ROOT / filename, project / filename)
    (CHECKOUT / ".gitignore").write_text(
        ".env\n.env.*\n!.env.example\n.gitee-token*\n.venv/\n__pycache__/\n*.pyc\n"
        ".pytest_cache/\ndata/\nartifacts/\n.publish/\n", encoding="utf-8")
    (CHECKOUT / "README.md").write_text(
        "# 极客时间-AI Agent训练营\n\n"
        "## 第一周：LLM 统一模型调用服务\n\n"
        "源码、启动指南、curl 示例和验证脚本位于 [LLM 统一模型调用服务](LLM%20统一模型调用服务/README.md)。\n\n"
        "支持 Responses / Messages 两种协议、SSE、结构化输出、提示词版本、可观测性、重试与独立限流。\n\n"
        "仓库仅提供空密钥 `.env.example`，真实 API Key、数据库、调用记录及虚拟环境不上传。\n",
        encoding="utf-8")
    configured_secrets = [value for name, value in dotenv_values(ROOT / ".env").items()
                          if value and any(word in name.upper() for word in ("KEY", "TOKEN", "SECRET", "PASSWORD"))]
    errors = []
    files = [path for path in CHECKOUT.rglob("*") if path.is_file() and ".git" not in path.relative_to(CHECKOUT).parts]
    for path in files:
        relative = path.relative_to(CHECKOUT)
        text = path.read_text(encoding="utf-8-sig")
        if any(secret in text for secret in configured_secrets):
            errors.append(f"Configured secret found: {relative}")
        if re.search(r"\bsk-[A-Za-z0-9_-]{16,}", text):
            errors.append(f"Credential-like string found: {relative}")
        if path.name.startswith(".env") and path.name != ".env.example":
            errors.append(f"Private environment file: {relative}")
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".sqlite3", ".png"}:
            errors.append(f"Runtime/private file: {relative}")
    for key, value in dotenv_values(project / ".env.example").items():
        if value and any(word in key.upper() for word in ("API_KEY", "TOKEN", "SECRET", "PASSWORD")):
            errors.append(f"Nonempty secret in example: {key}")
    if errors:
        raise SystemExit("\n".join(errors))
    run("git", "init", "-b", "main")
    run("git", "config", "core.quotepath", "false")
    run("git", "add", "--all")
    run("git", "diff", "--cached", "--check")
    run("git", "commit", "-m", "Add week 1 unified LLM calling service")
    run("git", "remote", "add", "origin", "https://gitee.com/byTracyYe/geektime-ai-agent-bootcamp.git")
    archive = PUBLISH / "geektime-ai-agent-bootcamp-source.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
        for path in files:
            output.write(path, path.relative_to(CHECKOUT).as_posix())
    report = {"repository_name": "极客时间-AI Agent训练营", "repository_path": "geektime-ai-agent-bootcamp",
              "visibility": "private", "directory": PROJECT_NAME, "files": len(files),
              "secret_scan": "passed", "commit": run("git", "rev-parse", "HEAD"),
              "source_archive": str(archive), "checkout": str(CHECKOUT),
              "excluded": [".env", ".venv", "data", "artifacts", "__pycache__", ".pytest_cache"]}
    (PUBLISH / "publish-manifest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
