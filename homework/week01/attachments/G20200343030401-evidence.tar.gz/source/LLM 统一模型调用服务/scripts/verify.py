"""Run all deterministic acceptance checks and save machine-readable evidence."""
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
output = root / "artifacts"
output.mkdir(exist_ok=True)
environment = {**os.environ, "EVIDENCE_FILE": str(output / "mock-evidence.json")}
result = subprocess.run([sys.executable, "-m", "pytest", "-v", "--junitxml", str(output / "verification.xml")],
                        cwd=root, env=environment)
print(f"\nMock evidence: {output / 'mock-evidence.json'}\nJUnit: {output / 'verification.xml'}")
raise SystemExit(result.returncode)
