"""Exercise a running service and retain partial evidence when one model is blocked."""
import argparse
import asyncio
import json
from pathlib import Path
import sys
import time

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.sse import parse_sse


async def verify(args):
    evidence = {"base_url": args.base_url, "checks": [], "status": "running"}
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    failed = False
    try:
        async with httpx.AsyncClient(base_url=args.base_url, timeout=180) as client:
            health = await client.get("/health")
            health.raise_for_status()
            evidence["mode"] = health.json()["mode"]
            if evidence["mode"] != "live" and not args.allow_mock:
                raise RuntimeError("Service is in mock mode. Configure APP_MODE=live, or use --allow-mock for a local smoke check.")
            models_response = await client.get("/v1/models")
            models_response.raise_for_status()
            models = args.models or [model["id"] for model in models_response.json()["models"]]
            request_ids = []
            for model in models:
                basic = {"model": model, "messages": [{"role": "user", "content": "请简短解释适配器模式。"}]}
                schema = {"type": "object", "properties": {"answer": {"type": "string"}},
                          "required": ["answer"], "additionalProperties": False}
                if evidence["mode"] == "mock":
                    schema["properties"]["model"] = {"type": "string"}
                    schema["required"].append("model")
                structured_body = {**basic, "response_format": {"type": "json_schema", "schema": schema}}
                cases = [
                    ("blocking", basic),
                    ("structured", structured_body),
                    ("template", {"model": model, "prompt": {"name": "explain", "version": "v1",
                        "variables": {"language": "中文", "topic": "适配器模式"}}}),
                    ("stream", {**basic, "stream": True}),
                    ("stream_structured", {**structured_body, "stream": True}),
                ]
                for name, body in cases:
                    check = {"model": model, "check": name}
                    try:
                        if body.get("stream"):
                            events = []
                            check["events"] = events
                            started = time.perf_counter()
                            first_delta_ms = None
                            async with client.stream("POST", "/v1/generate", json=body) as result:
                                check["http_status"] = result.status_code
                                if result.is_error:
                                    await result.aread()
                                result.raise_for_status()
                                assert "text/event-stream" in result.headers["content-type"]
                                async for event in parse_sse(result.aiter_lines()):
                                    events.append(event)
                                    if "delta" in event and first_delta_ms is None:
                                        first_delta_ms = (time.perf_counter() - started) * 1000
                            assert events and "error" not in events[-1] and "output_text" in events[-1], "Missing successful completion"
                            value = events[-1]
                            assert "".join(e.get("delta", "") for e in events[:-1]) == value["output_text"]
                            assert first_delta_ms is not None and value["ttft_ms"] is not None
                            check["client_first_delta_ms"] = first_delta_ms
                        else:
                            result = await client.post("/v1/generate", json=body)
                            check["http_status"] = result.status_code
                            result.raise_for_status()
                            value = result.json()
                        check["response"] = value
                        request_ids.append(value["request_id"])
                        assert value["output_text"] and value["usage"]["reported"]
                        if body.get("response_format"):
                            assert isinstance(value["structured_output"]["answer"], str)
                        if name == "template":
                            assert value["prompt"] == {"name": "explain", "version": "v1"}
                        check["status"] = "passed"
                        print(f"PASS {model} {name}")
                    except Exception as error:
                        failed = True
                        check.update(status="failed", error_type=type(error).__name__)
                        if isinstance(error, httpx.HTTPStatusError):
                            try:
                                check["error"] = error.response.json()
                            except ValueError:
                                check["error"] = "Non-JSON error response"
                        else:
                            check["error"] = str(error)
                        print(f"FAIL {model} {name}: {check.get('http_status', check['error_type'])}")
                    evidence["checks"].append(check)
                    if check.get("http_status") in {401, 402, 403}:
                        check["remaining_checks_skipped"] = True
                        break
            calls = await client.get("/v1/metrics/calls", params={"limit": 1000})
            calls.raise_for_status()
            records = {r["request_id"]: r for r in calls.json()["calls"]}
            assert all(rid in records for rid in request_ids), "Missing persisted request records"
            evidence["records"] = [records[rid] for rid in request_ids]
            evidence["failed_records"] = [r for r in records.values() if r["status"] != "ok"][:20]
            summary = await client.get("/v1/metrics/summary")
            summary.raise_for_status()
            evidence["summary"] = summary.json()
            evidence["status"] = "failed" if failed else "passed"
            print(f"Observability: {len(request_ids)} matching persisted request records")
    except Exception as error:
        evidence.update(status="failed", error=str(error))
        raise
    finally:
        output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Evidence saved: {output.resolve()}")
    return 1 if failed else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8765")
    parser.add_argument("--models", nargs="+", help="Model IDs to check; defaults to GET /v1/models")
    parser.add_argument("--output", default="artifacts/live-evidence.json")
    parser.add_argument("--allow-mock", action="store_true")
    raise SystemExit(asyncio.run(verify(parser.parse_args())))
