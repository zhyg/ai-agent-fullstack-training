"""Check the configured protocol endpoints once each, without retries or printing keys."""
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.adapters import ADAPTERS
from app.config import Settings
from app.schemas import GenerateRequest


async def main():
    settings = Settings.from_env()
    if settings.mode != "live":
        raise RuntimeError("Set APP_MODE=live before probing real upstreams")
    results = []
    async with httpx.AsyncClient(timeout=settings.timeout_seconds) as client:
        for config in settings.models.values():
            result = {"model": config.name, "upstream_model": config.upstream_model,
                      "protocol": config.protocol, "url": config.url}
            adapter = ADAPTERS[config.protocol](config, client)
            request = GenerateRequest(model=config.name, messages=[{"role": "user", "content": "请仅回答：连接成功"}])
            try:
                response = await client.post(config.url, headers=adapter.headers(),
                                             json=adapter.payload(request, request.messages))
                result["http_status"] = response.status_code
                # Redact credentials even if an upstream unexpectedly echoes them.
                result["response_preview"] = response.text.replace(config.api_key, "[REDACTED]")[:4000]
                result["ok"] = response.is_success
            except httpx.HTTPError as error:
                result.update(ok=False, error_type=type(error).__name__)
            results.append(result)
            print(json.dumps(result, ensure_ascii=True))
    path = Path("artifacts/upstream-probe.json")
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps({"mode": "live", "timestamp": datetime.now(timezone.utc).isoformat(),
                                "results": results}, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if all(result["ok"] for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
