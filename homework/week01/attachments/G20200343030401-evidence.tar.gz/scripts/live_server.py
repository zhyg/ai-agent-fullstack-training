import os
import sys
import json
import time
from pathlib import Path
import httpx
import uvicorn

ROOT = Path('/tmp/tracy-grade/student/LLM 统一模型调用服务')
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
os.environ.update(APP_MODE='live', PRO_RESPONSES_URL='https://api.deepseek.com/responses',
    FLASH_MESSAGES_URL='https://api.deepseek.com/anthropic/v1/messages',
    PRO_UPSTREAM_MODEL='deepseek-v4-pro', FLASH_UPSTREAM_MODEL='deepseek-flash',
    GATEWAY_API_KEY=os.environ['DEEPSEEK_API_KEY'], PRO_API_KEY='', FLASH_API_KEY='',
    METRICS_DB='/tmp/tracy-grade/live.sqlite3', UPSTREAM_TIMEOUT_SECONDS='25', RETRY_BASE_SECONDS='0.2')
from app.main import create_app

class Audit(httpx.AsyncHTTPTransport):
    async def handle_async_request(self, request):
        item = {'url': str(request.url), 'body': json.loads(request.content),
                'auth_header_names': [k for k in request.headers if k in ['authorization','x-api-key','anthropic-version']],
                'started': time.time()}
        try:
            response = await super().handle_async_request(request)
            item.update(status=response.status_code, headers={k:v for k,v in response.headers.items()
                if k.lower() in ['x-request-id','request-id','content-type','x-ds-request-id']})
            original = response.stream
            class Capture(httpx.AsyncByteStream):
                async def __aiter__(self):
                    chunks = []
                    try:
                        async for chunk in original:
                            chunks.append(chunk)
                            yield chunk
                    finally:
                        item['response_body'] = b''.join(chunks).decode('utf-8', errors='replace')
                        item['elapsed_ms'] = round((time.time()-item['started'])*1000,3)
                        with open('/tmp/tracy-grade/live-wire.jsonl','a') as f:
                            f.write(json.dumps(item, ensure_ascii=False)+'\n')
                async def aclose(self):
                    await original.aclose()
            response.stream = Capture()
            return response
        except Exception as e:
            item.update(error=type(e).__name__, elapsed_ms=round((time.time()-item['started'])*1000,3))
            with open('/tmp/tracy-grade/live-wire.jsonl','a') as f:
                f.write(json.dumps(item, ensure_ascii=False)+'\n')
            raise

uvicorn.run(create_app(transport=Audit(retries=0)), host='127.0.0.1', port=8765)
