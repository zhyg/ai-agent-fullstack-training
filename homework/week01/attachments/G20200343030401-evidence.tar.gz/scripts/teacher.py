import asyncio
import json
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path
import httpx
import uvicorn

ROOT=Path('/tmp/tracy-grade/student/LLM 统一模型调用服务')
sys.path.insert(0,str(ROOT))
from app.config import ModelConfig, Settings
from app.main import create_app
from app.mock_upstream import mock_app

OUT=Path('/tmp/tracy-grade')
MODELS=['deepseek-v4-pro','deepseek/deepseek-flash']
results=[]
serial=0

def payload(model, **extra):
    return dict(model=model,messages=[{'role':'system','content':'system-marker'},
        {'role':'user','content':'teacher-marker'}],**extra)

@asynccontextmanager
async def fixture(handler=None, rpm=100, base=0.01):
    global serial
    serial+=1
    seen=[]
    delays=[]
    upstream=httpx.ASGITransport(mock_app)
    async def route(req):
        seen.append({'url':str(req.url),'body':json.loads(req.content),
            'auth_header_names':[k for k in req.headers if k in ['authorization','x-api-key','anthropic-version']],
            'time':time.monotonic()})
        return await handler(req,len(seen)) if handler else await upstream.handle_async_request(req)
    async def sleep(delay):
        delays.append(delay)
    settings=Settings('mock',{m:ModelConfig(m,p,'https://mock.local/v1/'+p,'fixture-key',m,rpm)
        for m,p in zip(MODELS,['responses','messages'])},OUT/f'teacher-{serial}.sqlite3',ROOT/'prompts',retry_base_seconds=base)
    app=create_app(settings,transport=httpx.MockTransport(route),sleep=sleep)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://gateway') as c:
            yield c,app,seen,delays

async def check(name, fn):
    try:
        details=await fn()
        results.append({'case':name,'status':'PASS','details':details})
        print('PASS',name,flush=True)
    except Exception as e:
        results.append({'case':name,'status':'FAIL','error':type(e).__name__+': '+str(e)})
        print('FAIL',name,repr(e),flush=True)

async def routing_templates():
    async with fixture() as (c,app,seen,delays):
        bodies=[]
        for m in MODELS:
            for v in ['v1','v2','v1']:
                r=await c.post('/v1/generate',json={'model':m,'prompt':{'name':'explain','version':v,
                    'variables':{'language':'中文','topic':'隔离标记'}}})
                assert r.status_code==200,r.text
                bodies.append(r.json())
                wire=seen[-1]['body']
                assert '隔离标记' in json.dumps(wire,ensure_ascii=False)
                assert '{{' not in json.dumps(wire)
                assert ('生活中的类比' in json.dumps(wire,ensure_ascii=False))==(v=='v2')
        before=len(seen)
        errors=[]
        for ref in [{'name':'absent','version':'v1'},{'name':'explain','version':'absent'},
                    {'name':'explain','version':'v1','variables':{'language':'中文'}}]:
            r=await c.post('/v1/generate',json={'model':MODELS[0],'prompt':ref})
            assert r.status_code in [400,404],r.text
            errors.append(r.json())
        r=await c.post('/v1/generate',json=payload('absent'))
        assert r.status_code==404 and len(seen)==before
        return {'responses':bodies,'errors':errors+[r.json()],'wire':seen,'records':app.state.service.metrics.recent()}

def response_body(protocol,text,terminal=True):
    if protocol=='responses':
        return {'status':'completed' if terminal else 'incomplete','output':[{'content':[{'type':'output_text','text':text}]}],
            'usage':{'input_tokens':13,'output_tokens':7,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}}
    return {'content':[] if text=='' else [{'type':'tool_use','name':'structured_output','input':json.loads(text)}],
        'stop_reason':'tool_use' if terminal else 'max_tokens','usage':{'input_tokens':13,'output_tokens':7,'cache_read_input_tokens':3,'cache_creation_input_tokens':2}}

async def json_cases():
    reports=[]
    for model,protocol in zip(MODELS,['responses','messages']):
        scenarios=['valid','illegal','empty','truncated','schema_mismatch']
        for scenario in scenarios:
            async def handler(req,n):
                if scenario=='illegal' and protocol=='messages':
                    body={'content':[{'type':'text','text':'not JSON'}],'stop_reason':'end_turn'}
                else:
                    text={'valid':'{"answer":"yes"}','illegal':'{"answer":','empty':'',
                        'truncated':'{"answer":"yes"}','schema_mismatch':'{"answer":42}'}[scenario]
                    body=response_body(protocol,text,scenario!='truncated')
                return httpx.Response(200,json=body)
            async with fixture(handler) as (c,app,seen,delays):
                r=await c.post('/v1/generate',json=payload(model,response_format={'type':'json_schema','schema':{
                    'type':'object','properties':{'answer':{'type':'string'}},'required':['answer']}}))
                assert r.status_code==(200 if scenario=='valid' else 502),r.text
                if scenario=='valid':
                    assert r.json()['structured_output']=={'answer':'yes'}
                    usage=r.json()['usage']
                    assert usage['total_tokens']==(20 if protocol=='responses' else 25)
                    assert usage['input_tokens']==(13 if protocol=='responses' else 18)
                    assert usage['cache_read_input_tokens']==3
                assert len(seen)==1
                reports.append({'model':model,'scenario':scenario,'status':r.status_code,'response':r.json(),
                    'wire':seen,'record':app.state.service.metrics.recent()[0]})
    return reports

async def retries():
    reports=[]
    for m in MODELS:
        for fail_status,count_fail,expected in [(503,2,3),(503,99,4),(429,2,3),(401,99,1),(400,99,1)]:
            upstream=httpx.ASGITransport(mock_app)
            async def handler(req,n):
                return httpx.Response(fail_status,json={'error':'teacher injected'}) if n<=count_fail else await upstream.handle_async_request(req)
            async with fixture(handler) as (c,app,seen,delays):
                r=await c.post('/v1/generate',json=payload(m))
                assert len(seen)==expected,(len(seen),expected)
                assert len(delays)==expected-1
                for i,d in enumerate(delays):
                    assert .01*2**i<=d<=.012*2**i
                assert r.status_code==(200 if count_fail==2 else 502),r.text
                record=app.state.service.metrics.recent()[0]
                assert len(record['attempts'])==expected
                reports.append({'model':m,'injected':fail_status,'fail_count':count_fail,'actual_calls':len(seen),
                    'delays':delays,'response_status':r.status_code,'response':r.json(),'record':record})
    return reports

async def error_400():
    async def handler(req,n):
        return httpx.Response(400,json={'error':{'message':'unsupported format'}})
    async with fixture(handler) as (c,app,seen,delays):
        r=await c.post('/v1/generate',json=payload(MODELS[0],response_format={'type':'json_object'}))
        observed={'expected':'unified 4xx','actual_status':r.status_code,'body':r.json(),'wire':seen}
        # Record a behavioral failure, rather than changing student logic.
        results.append({'case':'F03-upstream-format-400','status':'FAIL' if r.status_code>=500 else 'PASS','details':observed})
        return observed

async def limits():
    async with fixture(rpm=1) as (c,app,seen,delays):
        now=[100.0]
        app.state.service.limiter.clock=lambda:now[0]
        status=[]
        for m in [MODELS[0],MODELS[0],MODELS[1]]:
            r=await c.post('/v1/generate',json=payload(m)); status.append(r.status_code)
        now[0]=159.99
        r=await c.post('/v1/generate',json=payload(MODELS[0])); status.append(r.status_code)
        now[0]=160.0
        r=await c.post('/v1/generate',json=payload(MODELS[0])); status.append(r.status_code)
        assert status==[200,429,200,429,200],status
        assert len(seen)==3
        return {'statuses':status,'clock':[100,159.99,160],'records':app.state.service.metrics.recent()}

async def gates():
    reports=[]
    for m,p in zip(MODELS,['responses','messages']):
        for failure in [False,True]:
            release=asyncio.Event()
            closed=[]
            count=[]
            class Bytes(httpx.AsyncByteStream):
                async def __aiter__(self):
                    if p=='responses':
                        events=[{'type':'response.output_text.delta','delta':'中文首块'}]
                        end=[{'type':'response.completed','response':{'status':'completed','usage':{'input_tokens':13,'output_tokens':7}}}]
                    else:
                        events=[{'type':'message_start','message':{'usage':{'input_tokens':13,'output_tokens':0}}},
                            {'type':'content_block_start','index':0,'content_block':{'type':'text','text':''}},
                            {'type':'content_block_delta','index':0,'delta':{'type':'text_delta','text':'中文首块'}}]
                        end=[{'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':7}}, {'type':'message_stop'}]
                    yield b': heartbeat\r\n\r\n'
                    await asyncio.sleep(.04)
                    for e in events:
                        raw=('data: '+json.dumps(e,ensure_ascii=False)+'\r\n\r\n').encode()
                        for b in raw: yield bytes([b])
                    await release.wait()
                    if failure: raise httpx.ReadError('teacher disconnect after content')
                    for e in end: yield ('data: '+json.dumps(e)+'\n\n').encode()
                async def aclose(self): closed.append(True)
            async def handler(req,n):
                count.append(1)
                return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Bytes())
            async with fixture(handler) as (_,app,seen,delays):
                server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=8767,lifespan='off',log_level='error'))
                task=asyncio.create_task(server.serve())
                while not server.started: await asyncio.sleep(.01)
                try:
                    async with httpx.AsyncClient(timeout=3) as c:
                        async with c.stream('POST','http://127.0.0.1:8767/v1/generate',json=payload(m,stream=True)) as r:
                            lines=r.aiter_lines()
                            first=[]
                            while True:
                                line=await asyncio.wait_for(anext(lines),1)
                                first.append(line)
                                if line.startswith('data: '): break
                            assert '中文首块' in first[-1] and not release.is_set(),first
                            first_received=time.monotonic()
                            await asyncio.sleep(.04)
                            release.set()
                            rest=[line async for line in lines]
                            assert any(line=='event: '+('error' if failure else 'completed') for line in rest),rest
                            if failure: assert 'event: completed' not in rest
                        records=(await c.get('http://127.0.0.1:8767/v1/metrics/calls')).json()['calls']
                        record=records[0]
                        assert record['status']==('error' if failure else 'ok')
                        assert record['ttft_ms']>=35 and len(count)==1
                        assert record['latency_ms']>record['ttft_ms']+30
                        if not failure: assert record['usage']['total_tokens']==20
                        reports.append({'model':m,'failure':failure,'gate_received_before_release':True,
                            'first_lines':first,'terminal_lines':rest,'upstream_calls':len(count),'record':record})
                finally:
                    release.set(); server.should_exit=True; await task
    return reports

async def main():
    for name,fn in [('A03-A04-F05-F06',routing_templates),('F03-F04-F07-json',json_cases),
                    ('F08-F09',retries),('F03-400-probe',error_400),('F10-F11',limits),('F01-F02-F07-gated-HTTP',gates)]:
        await check(name,fn)
    (OUT/'teacher-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print('RESULT',sum(r['status']=='PASS' for r in results),'pass',sum(r['status']=='FAIL' for r in results),'fail')

asyncio.run(main())
