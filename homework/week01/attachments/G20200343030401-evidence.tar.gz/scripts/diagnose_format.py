import asyncio
import json
import os
import sys
from pathlib import Path
import httpx

sys.path.insert(0,'/tmp/tracy-grade/student/LLM 统一模型调用服务')
from app.adapters import MessagesAdapter
from app.config import ModelConfig
from app.schemas import GenerateRequest

async def main():
    config=ModelConfig('deepseek/deepseek-flash','messages','https://api.deepseek.com/anthropic/v1/messages',
        os.environ['DEEPSEEK_API_KEY'],'deepseek-flash')
    adapter=MessagesAdapter(config,None)
    request=GenerateRequest(model=config.name,messages=[{'role':'user','content':'Return JSON with answer OK.'}],
        response_format={'type':'json_object'},max_output_tokens=1024)
    body=adapter.payload(request,request.messages)
    async with httpx.AsyncClient(timeout=30) as c:
        response=await c.post(config.url,headers=adapter.headers(),json=body)
    result={'notice':'Direct diagnostic using unchanged student adapter payload; no success inferred for gateway',
        'url':config.url,'body':body,'status':response.status_code,'response':response.json(),
        'headers':{k:v for k,v in response.headers.items() if 'request' in k.lower() or k.lower()=='content-type'}}
    Path('/tmp/tracy-grade/official-format-diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

asyncio.run(main())
