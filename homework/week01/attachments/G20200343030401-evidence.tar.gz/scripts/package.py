import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import tarfile
from urllib.parse import quote

WORK=Path('/tmp/tracy-grade')
STUDENT=WORK/'student'
TARGET='LLM 统一模型调用服务'
REPO=Path('/home/user/workspace/repo')
PACKAGE=WORK/'package'
PACKAGE.mkdir(exist_ok=True)
for name in ['source','source-lines','scripts','logs','results','reports']:
    (PACKAGE/name).mkdir(exist_ok=True)
manifest=[]
for entry in subprocess.check_output(['git','ls-tree','-rz','HEAD','--',TARGET],cwd=STUDENT).split(b'\0'):
    if not entry: continue
    meta,path=entry.split(b'\t',1)
    mode,kind,blob=meta.split()
    path=path.decode()
    content=subprocess.check_output(['git','cat-file','blob',blob.decode()],cwd=STUDENT)
    dest=PACKAGE/'source'/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(content)
    manifest.append({'path':path,'git_blob':blob.decode(),'sha256':hashlib.sha256(content).hexdigest()})
    if path.endswith(('.py','.md','.json')):
        dest=PACKAGE/'source-lines'/(path+'.txt')
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(''.join(f'{i:5}\t{line}\n' for i,line in enumerate(content.decode().splitlines(),1)))
(PACKAGE/'source-manifest.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=STUDENT).decode().strip(),
    'tracked_diff_empty':not subprocess.check_output(['git','diff','HEAD'],cwd=STUDENT),'files':manifest},ensure_ascii=False,indent=2))
for name in ['teacher.py','live_server.py','live_probe.py','diagnose_format.py','package.py']:
    shutil.copyfile(WORK/name,PACKAGE/'scripts'/name)
for path in WORK.glob('*.log'):
    shutil.copyfile(path,PACKAGE/'logs'/path.name)
for name in ['teacher-results.json','live-initial.json','student-http-mock.json','student-live.json',
             'student-manufactured-failure.json','official-format-diagnostic.json']:
    shutil.copyfile(WORK/name,PACKAGE/'results'/name)
for name in ['mock-evidence.json','verification.xml']:
    shutil.copyfile(STUDENT/TARGET/'artifacts'/name,PACKAGE/'results'/name)
records=[json.loads(r[0]) for r in sqlite3.connect(WORK/'live.sqlite3').execute('select data from calls')]
(PACKAGE/'results'/'live-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
wire=[]
for line in (WORK/'live-wire.jsonl').read_text().splitlines():
    item=json.loads(line)
    body=item.get('response_body','')
    if '\ufffd' in body or any(ord(ch)<32 and ch not in '\r\n\t' for ch in body):
        item.pop('response_body',None)
        item['response_capture_limitation']='Compressed or undecodable raw bytes discarded; decoded gateway results retained separately.'
    wire.append(item)
(PACKAGE/'results'/'live-wire.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in wire))
shutil.copyfile(WORK/'installed.txt',PACKAGE/'installed.txt')
for name in ['G20200343030401.md','attachments/G20200343030401.md']:
    src=REPO/'homework/week01'/name
    shutil.copyfile(src,PACKAGE/'reports'/('feedback.md' if '/' not in name else 'assessment.md'))
(PACKAGE/'config-redacted.json').write_text(json.dumps({'APP_MODE':'live','PRO_RESPONSES_URL':'https://api.deepseek.com/responses',
    'FLASH_MESSAGES_URL':'https://api.deepseek.com/anthropic/v1/messages','PRO_UPSTREAM_MODEL':'deepseek-v4-pro',
    'FLASH_UPSTREAM_MODEL':'deepseek-flash','key_source':'DEEPSEEK_API_KEY environment only; value never stored',
    'UPSTREAM_TIMEOUT_SECONDS':25,'RETRY_BASE_SECONDS':0.2,'ports':[8765,8766,8767]},indent=2))
feedback=(REPO/'homework/week01/G20200343030401.md').read_text()
counts=[]
for number in [2,3,4]:
    section=feedback.split(f'**{number}. ')[1].split('**',1)[1].split('\n**',1)[0]
    count=sum(line.startswith('- ') for line in section.splitlines())
    chars=len(re.sub(r'\s','',section))
    assert 3<=count<=5 and chars<=500,(number,count,chars)
    counts.append({'section':number,'items':count,'nonwhitespace_chars':chars})
assessment=(REPO/'homework/week01/attachments/G20200343030401.md').read_text()
scores=[int(x) for x in re.findall(r'^\| (?:统一接口与适配器|流式输出|结构化输出|提示词版本管理|可观测性|统一错误与重试|按模型独立限流|源码、README 与验证脚本) \| (\d+)/',assessment,re.M)]
assert len(scores)==8 and sum(scores)==99,scores
assert '优秀（99分）' in feedback
(PACKAGE/'format-check.json').write_text(json.dumps({'sections':counts,'scores':scores,'sum':sum(scores),'grade':'优秀','passed':True},ensure_ascii=False,indent=2))
variants=set()
key=os.environ['DEEPSEEK_API_KEY']
assert len(key)>12
for value in [key,*[v for k,v in os.environ.items() if k!='AMP_SECRET_ENV_NAMES' and re.search(r'(KEY|TOKEN|SECRET|PASSWORD)',k) and len(v)>=16]]:
    variants.update([value.encode(),quote(value,safe='').encode(),base64.b64encode(value.encode())])
hits=[]
patterns=[rb'sk-[A-Za-z0-9_-]{20,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
files=[p for p in PACKAGE.rglob('*') if p.is_file()]
for p in files:
    data=p.read_bytes()
    if any(v in data for v in variants) or any(re.search(pat,data) for pat in patterns):
        hits.append(str(p.relative_to(PACKAGE)))
assert not hits,{'credential_match_files':hits}
(PACKAGE/'security-scan.json').write_text(json.dumps({'actual_environment_secret_values_and_urlencoded_base64_variants_checked':True,
    'credential_patterns_checked':True,'files_scanned':len(files),'matches':[], 'secret_values_not_printed':True},indent=2))
archive=REPO/'homework/week01/attachments/G20200343030401-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(PACKAGE.rglob('*')):
        if p.is_file(): tar.add(p,arcname=str(p.relative_to(PACKAGE)))
with tarfile.open(archive) as tar:
    members=[m for m in tar if m.isfile()]
    for member in members:
        data=tar.extractfile(member).read()
        assert not any(v in data for v in variants),member.name
        assert not any(re.search(pat,data) for pat in patterns),member.name
print(json.dumps({'format_checks':counts,'score_sum':sum(scores),'archive_files':len(members),
    'archive_bytes':archive.stat().st_size,'actual_secret_scan':'PASS','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
