import asyncio
import json
from pathlib import Path
import httpx

async def main():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8765', timeout=160) as c:
        async def call(model):
            r = await c.post('/v1/generate', json={'model':model,'messages':[{'role':'user','content':'只回复OK，不要解释。'}], 'max_output_tokens':1024})
            return {'model':model,'http_status':r.status_code,'body':r.json()}
        results = await asyncio.gather(*[call(m) for m in ['deepseek-v4-pro','deepseek/deepseek-flash']])
        records = (await c.get('/v1/metrics/calls')).json()
        Path('/tmp/tracy-grade/live-initial.json').write_text(json.dumps({'results':results,'records':records},ensure_ascii=False,indent=2))
        for r in results:
            print(r['model'], r['http_status'], r['body'])

asyncio.run(main())
