# G20261786020108 独立验收复现

固定学生提交：main / 645f5de1b25852715c0ae316a0496b9bcd445663。
学生 clone `/home/user/evaluations/G20261786020108`；本目录为独立评测目录，不是学生业务源码。

## 原始安装和执行

```bash
git clone https://github.com/chenguox/llm-gateway /home/user/evaluations/G20261786020108
# 新环境需核对 HEAD 为上述固定提交，否则 checkout 此提交再验收。
uv sync --locked
E=/home/user/evaluations/G20261786020108-eval
uv run --locked python scripts/verify.py --report-dir "$E/student-verification"
```

上述 uv 命令在学生 clone 根目录执行。独立配置保存的是地址和密钥变量名，不包含真实凭据；保留的 controlled-key 只是回环模拟用占位值。
真实请求只使用原配置中的 api.deepseek.com。Schema 配置只把 flash-chat 的结构化开关设为 true、modes 设为 json_schema，其余真实配置不变。

## 启动监督服务

均从学生 clone 根目录执行；只在支持 Amp orb service 的评测 orb 使用。DEEPSEEK_API_KEY 必须已有环境注入，不要打印或写入文件。

```bash
amp orb service start student-g20261786020108 --command 'GENERAL_CHAT_API_KEY="$DEEPSEEK_API_KEY" CODING_ASSISTANT_API_KEY="$DEEPSEEK_API_KEY" FLASH_CHAT_API_KEY="$DEEPSEEK_API_KEY" CALL_RECORDS_PATH=/home/user/evaluations/G20261786020108-eval/real-calls.sqlite3 uv run uvicorn app.main:app --host 127.0.0.1 --port 8018' --port 8018
amp orb service start eval-mock-g20261786020108 --command 'python /home/user/evaluations/G20261786020108-eval/mock_server.py' --port 18018
amp orb service start eval-gateway-g20261786020108 --command 'GENERAL_CHAT_API_KEY=controlled-key CODING_ASSISTANT_API_KEY=controlled-key FLASH_CHAT_API_KEY=controlled-key MODELS_CONFIG_PATH=/home/user/evaluations/G20261786020108-eval/mock-models.json CALL_RECORDS_PATH=/home/user/evaluations/G20261786020108-eval/mock-calls.sqlite3 uv run uvicorn app.main:app --host 127.0.0.1 --port 8019' --port 8019
amp orb service start eval-schema-real-g20261786020108 --command 'GENERAL_CHAT_API_KEY="$DEEPSEEK_API_KEY" CODING_ASSISTANT_API_KEY="$DEEPSEEK_API_KEY" FLASH_CHAT_API_KEY="$DEEPSEEK_API_KEY" MODELS_CONFIG_PATH=/home/user/evaluations/G20261786020108-eval/real-schema-models.json CALL_RECORDS_PATH=/home/user/evaluations/G20261786020108-eval/real-schema-calls.sqlite3 uv run uvicorn app.main:app --host 127.0.0.1 --port 8020' --port 8020
amp orb service start eval-schema-mock-g20261786020108 --command 'GENERAL_CHAT_API_KEY=controlled-key CODING_ASSISTANT_API_KEY=controlled-key FLASH_CHAT_API_KEY=controlled-key MODELS_CONFIG_PATH=/home/user/evaluations/G20261786020108-eval/mock-schema-models.json CALL_RECORDS_PATH=/home/user/evaluations/G20261786020108-eval/mock-schema-calls.sqlite3 uv run uvicorn app.main:app --host 127.0.0.1 --port 8021' --port 8021
```

## 验收命令和退出码

不要并行执行 controlled_check 和 schema_check，模拟上游状态由单一 /control 控制。

```bash
E=/home/user/evaluations/G20261786020108-eval
.venv/bin/python "$E/real_check.py"       # 本次 exit 0；保存真实结果，不用它的退出码代替业务断言
.venv/bin/python "$E/controlled_check.py" # 本次 exit 0；已验证行为有断言，业务缺陷按结果逐项判分
.venv/bin/python "$E/schema_check.py"     # 本次 exit 0；真实响应另核对 parsed，模拟非法/截断有断言
.venv/bin/python "$E/failure_probe.py"    # 本次预期 exit 1，实际 pytest 断言失败后 runner 报告 FAILED
```

预算额外探测：对模拟 /control 置 invalid，统一入口请求 json_object + max_retries=3，实际 502、上游 4 次，见 retry-budget.json。
失败注入只在评测进程导入 verify.py 后替换传给 pytest 的测试路径；不修改学生脚本或测试。验证的是学生报告汇总/失败传递机制，不是伪造真实供应商故障。

README curl 的 Linux 等价实测（在本 orb 内执行，非供外部浏览器使用）：

```bash
curl -sS http://127.0.0.1:8018/health
curl -sS -H 'Content-Type: application/json' --data '{"scenario":"ok"}' http://127.0.0.1:18018/control
curl -sS -N -H 'Content-Type: application/json' --data '{"model":"general-chat","messages":[{"role":"user","content":"Hello"}],"stream":true}' http://127.0.0.1:8019/v1/chat/completions
```

## 留存与边界

- 账本 JSON 是 SQLite 的 calls/attempts.payload 原值导出，学生有意不保存正文/认证信息；受控 HTTP 请求证据只保存路径、正文、时间，不保存认证头。
- 首次控制程序立即查库导致读取瞬态 in_progress，后修正等待终态，不改学生代码；最终 controlled-check.log 对应完整通过后的脚本。
- 模拟器是门控：先发送正文，等待下游脚本收到正文才通过 /release 允许发送终态，而非人为 sleep 后推断增量。
- 停止服务：`amp orb service stop <上面的服务名>`。本次报告生成后已停止全部五个服务。
- 检查源码未改：`git status --porcelain` 无输出；`git diff --exit-code` 返回 0。
