"""Inject an independent failing test path into verify's pytest subprocess only."""
import importlib.util
from pathlib import Path

root=Path('/home/user/evaluations/G20261786020108')
out=Path(__file__).parent
probe=out/'failure-fixture'/'test_health.py'
probe.parent.mkdir(exist_ok=True)
probe.write_text('def test_deliberate_failure():\n    assert 200 == 429, "controlled missing rate-limit failure"\n')
spec=importlib.util.spec_from_file_location('student_verify',root/'scripts/verify.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
original=mod.run_step
def inject(name,args,report):
    if name=='tests':
        args=[str(probe) if x=='tests/test_health.py' else x for x in args]
    return original(name,args,report)
mod.run_step=inject
raise SystemExit(mod.main(['--group','health','--tests-only','--report-dir',str(out/'failure-verification')]))
