"""Exercise unchanged gateway over real loopback HTTP, with controlled upstream."""
import json
import sqlite3
import time
from pathlib import Path
import httpx2 as httpx

OUT = Path(__file__).parent
BASE = 'http://127.0.0.1:8019'
MOCK = 'http://127.0.0.1:18018'
client = httpx.Client(timeout=25)
results = []
def control(scenario):
    client.post(MOCK+'/control', json={'scenario': scenario}).raise_for_status()
def snapshot():
    return client.get(MOCK+'/snapshot').json()
def payload(model='general-chat', **kw):
    return {'model': model, 'messages': [{'role': 'user', 'content': 'controlled task JSON'}], **kw}
def post(data):
    return client.post(BASE+'/v1/chat/completions', json=data)
def save(case, result, **kw):
    results.append({'case': case, **result, **kw})
    (OUT/'controlled-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
    print(case, json.dumps(result, ensure_ascii=False), flush=True)
def record(response):
    rid = response.headers['x-request-id']
    for _ in range(100):
        with sqlite3.connect(OUT/'mock-calls.sqlite3') as db:
            rec = json.loads(db.execute('select payload from calls where request_id=?', (rid,)).fetchone()[0])
        if rec['result']['status'] != 'in_progress':
            return rec
        time.sleep(0.01)
    return rec

control('ok')
r=post(payload('missing-model'))
assert r.status_code == 404 and snapshot()['calls'] == []
save('A04', {'status':r.status_code, 'response':r.json(), 'record':record(r)})
for model in ['general-chat', 'flash-chat']:
    for scenario in ['gate','interrupt']:
        control(scenario)
        start=time.monotonic()
        events=[]
        released=False
        with client.stream('POST', BASE+'/v1/chat/completions', json=payload(model, stream=True)) as r:
            assert r.status_code == 200
            for line in r.iter_lines():
                if not line.startswith('data: '):
                    continue
                e=json.loads(line[6:])
                events.append({'seconds':round(time.monotonic()-start,4), 'event':e})
                if e['type']=='delta' and e.get('delta',{}).get('content') and scenario=='gate':
                    # Upstream terminal is blocked until this client sees useful text.
                    assert not released
                    time.sleep(0.2)
                    client.get(MOCK+'/release').raise_for_status()
                    released=True
        calls=snapshot()['calls']
        assert len(calls)==1
        assert events[-1]['event']['type'] == ('completed' if scenario=='gate' else 'failed')
        assert any(e['event']['type']=='delta' for e in events)
        rec=record(r)
        assert rec['result']['status'] == ('completed' if scenario=='gate' else 'failed')
        assert rec['timing']['first_content_ms'] >= 140
        save('F01/F02 '+model+' '+scenario, {'status':r.status_code,'gate_released_after_content':released,'upstream_calls':len(calls),'events':events,'record':rec}, upstream=calls)

schema={'type':'json_schema','json_schema':{'name':'test','schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}}
for scenario in ['ok','invalid','empty','truncated','wrong-schema','repair']:
    control(scenario)
    r=post(payload(response_format=schema,max_retries=1))
    n=len(snapshot()['calls'])
    expected=200 if scenario in ['ok','repair'] else 502
    assert r.status_code==expected
    if expected==200:
        assert r.json()['choices'][0]['message']['parsed']=={'ok':True}
    rec=record(r)
    if n==2:
        assert rec['usage']['input_tokens']==14 and rec['usage']['output_tokens']==6
    save('F03/F04 '+scenario, {'status':r.status_code, 'upstream_calls':n, 'response':r.json(),'record':rec}, upstream=snapshot()['calls'])
control('ok')
r=post(payload('flash-chat',response_format={'type':'json_object'}))
assert r.status_code==422 and len(snapshot()['calls'])==0
save('F03 flash default',{'status':r.status_code,'response':r.json(),'upstream_calls':0})

for version in ['1.0.0','2.0.0','1.0.0']:
    control('ok')
    r=post(payload(system_prompt={'name':'assistant','version':version,'parameters':{'role':'测试助理','language':'英语'}}))
    assert r.status_code==200
    text=snapshot()['calls'][0]['body']['messages'][0]['content']
    assert '${' not in text and '英语' in text
    assert ('表达风格' in text)==(version=='2.0.0')
    save('F05 '+version,{'status':r.status_code,'rendered_system':text},upstream=snapshot()['calls'])
for template in [{'name':'missing','version':'1.0.0'},{'name':'assistant','version':'missing'},{'name':'customer_support','version':'1.0.0','parameters':{}}]:
    control('ok')
    r=post(payload(system_prompt=template))
    assert r.status_code in [404,422] and snapshot()['calls']==[]
    save('F06',{'input':template,'status':r.status_code,'response':r.json(),'upstream_calls':0})

for scenario in ['recover','500','429','400','401']:
    control(scenario)
    start=time.monotonic()
    r=post(payload())
    save('F08/F09 '+scenario,{'status':r.status_code,'upstream_calls':len(snapshot()['calls']),'duration_seconds':round(time.monotonic()-start,4),'response':r.json(),'record':record(r)},upstream=snapshot()['calls'])
control('400')
r=post(payload(response_format={'type':'json_object'}))
save('F03 upstream unsupported format',{'status':r.status_code,'response':r.json(),'upstream_calls':len(snapshot()['calls'])})

control('ok')
statuses=[post(payload()).status_code for _ in range(65)]
b=post(payload('flash-chat'))
time.sleep(1.1)
after=post(payload())
save('F10/F11',{'A_status_counts':{str(s):statuses.count(s) for s in set(statuses)},'B_status':b.status_code,'A_after_wait_status':after.status_code,'upstream_calls':len(snapshot()['calls']),'note':'No local quota/threshold/window exists in source or public configuration; cannot prove quota exhaustion or recovery by these 200s.'})
client.close()
