import json
import time
from pathlib import Path
import httpx2 as httpx

out=Path(__file__).parent
fmt={'type':'json_schema','json_schema':{'name':'answer','schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}}
payload={'model':'flash-chat','messages':[{'role':'user','content':'Return only JSON {"ok":true}.'}],'response_format':fmt,'max_tokens':1024,'max_retries':0}
results=[]
with httpx.Client(timeout=90) as c:
    for base,scenario in [('http://127.0.0.1:8020','real'), *[('http://127.0.0.1:8021',s) for s in ['ok','invalid','empty','truncated','wrong-schema','repair']]]:
        if scenario != 'real':
            c.post('http://127.0.0.1:18018/control',json={'scenario':scenario}).raise_for_status()
        start=time.monotonic()
        p={**payload,'max_retries':1 if scenario=='repair' else 0}
        r=c.post(base+'/v1/chat/completions',json=p)
        row={'scenario':scenario,'status':r.status_code,'request_id':r.headers.get('x-request-id'),'response':r.json(),'duration_seconds':round(time.monotonic()-start,4),'configuration':'external config only: flash structured_output supported=true, modes=[json_schema]'}
        if scenario!='real':
            row['upstream']=c.get('http://127.0.0.1:18018/snapshot').json()['calls']
            assert r.status_code==(200 if scenario in ['ok','repair'] else 502)
        results.append(row)
        (out/'schema-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
        print(scenario,r.status_code,flush=True)
