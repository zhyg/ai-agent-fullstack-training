import json
import time
from pathlib import Path
import httpx2 as httpx

OUT = Path(__file__).parent
base = 'http://127.0.0.1:8018'
results = []
with httpx.Client(timeout=150) as client:
    results.append({'case': 'A01', 'status': client.get(base+'/health').status_code})
    for model in ['general-chat', 'flash-chat']:
        for mode in ['plain', 'stream', 'json']:
            payload = {'model': model, 'messages': [{'role': 'user', 'content': 'Return only JSON {"ok":true}. No explanation.'}], 'max_tokens': 1024}
            if mode == 'stream':
                payload['stream'] = True
            if mode == 'json':
                payload['response_format'] = {'type': 'json_object'}
                payload['max_retries'] = 0
            start = time.monotonic()
            try:
                with client.stream('POST', base+'/v1/chat/completions', json=payload) as response:
                    chunks = []
                    for line in response.iter_lines():
                        if line:
                            chunks.append({'seconds': round(time.monotonic()-start, 4), 'line': line})
                    results.append({'model': model, 'mode': mode, 'status': response.status_code, 'request_id': response.headers.get('x-request-id'), 'content_type': response.headers.get('content-type'), 'duration_seconds': round(time.monotonic()-start, 4), 'chunks': chunks})
            except Exception as exc:
                results.append({'model': model, 'mode': mode, 'exception': type(exc).__name__})
            (OUT/'real-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
            print(model, mode, results[-1].get('status'), results[-1].get('duration_seconds'), flush=True)
