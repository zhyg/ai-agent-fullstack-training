def test_deliberate_failure():
    assert 200 == 429, "controlled missing rate-limit failure"
