"""Local-only controlled upstream; never forwards traffic or stores auth headers."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

state = {'scenario': 'ok', 'calls': []}
gate = threading.Event()

def event(data, name=None):
    return ((f'event: {name}\n' if name else '')+'data: '+(data if isinstance(data, str) else json.dumps(data))+'\n\n').encode()

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *args):
        pass
    def reply(self, obj, status=200):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        if self.path == '/snapshot':
            self.reply(state)
        elif self.path == '/release':
            gate.set()
            self.reply({'released': True})
        else:
            self.reply({'ok': True})
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get('content-length', '0'))))
        if self.path == '/control':
            state.update(scenario=body['scenario'], calls=[])
            gate.clear()
            return self.reply({'ok': True})
        state['calls'].append({'path': self.path, 'body': body, 'time': time.monotonic()})
        scenario = state['scenario']
        count = len(state['calls'])
        if scenario in ['500', '400', '401', '429'] or (scenario == 'recover' and count <= 2):
            return self.reply({'error': {'message': 'controlled upstream error'}}, int(scenario) if scenario.isdigit() else 500)
        anthropic = self.path.endswith('/messages')
        if body.get('stream'):
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.close_connection = True
            def send(data, name=None):
                self.wfile.write(event(data, name))
                self.wfile.flush()
            def frame(content=None, finish=None, usage=None):
                return {'id': 'mock', 'object': 'chat.completion.chunk', 'created': 1700000000, 'model': body['model'], 'choices': [{'index': 0, 'delta': {} if content is None else {'content': content}, 'finish_reason': finish}], 'usage': usage}
            self.wfile.write(b': heartbeat\n\n')
            self.wfile.flush()
            time.sleep(0.15)
            if anthropic:
                send({'type': 'message_start', 'message': {'id': 'mock', 'type': 'message', 'role': 'assistant', 'model': body['model'], 'content': [], 'stop_reason': None, 'stop_sequence': None, 'usage': {'input_tokens': 7, 'output_tokens': 0}}}, 'message_start')
                send({'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'text', 'text': ''}}, 'content_block_start')
                send({'type': 'content_block_delta', 'index': 0, 'delta': {'type': 'text_delta', 'text': '早到内容'}}, 'content_block_delta')
            else:
                send(frame('早到内容'))
            if scenario == 'interrupt':
                return
            if scenario == 'gate':
                if not gate.wait(15):
                    return
            if anthropic:
                send({'type': 'content_block_stop', 'index': 0}, 'content_block_stop')
                send({'type': 'message_delta', 'delta': {'stop_reason': 'end_turn', 'stop_sequence': None}, 'usage': {'output_tokens': 3}}, 'message_delta')
                send({'type': 'message_stop'}, 'message_stop')
            else:
                send(frame(finish='stop'))
                send({'id': 'mock', 'object': 'chat.completion.chunk', 'created': 1700000000, 'model': body['model'], 'choices': [], 'usage': {'prompt_tokens': 7, 'completion_tokens': 3}})
                send('[DONE]')
            return
        text = {'invalid': 'not JSON', 'empty': '', 'truncated': '{"ok":true}', 'wrong-schema': '{"ok":"wrong"}', 'repair': 'not JSON' if count == 1 else '{"ok":true}'}.get(scenario, '{"ok":true}')
        reason = 'length' if scenario == 'truncated' else 'stop'
        if anthropic:
            return self.reply({'id': 'mock', 'type': 'message', 'role': 'assistant', 'model': body['model'], 'content': [{'type': 'text', 'text': text}], 'stop_reason': 'max_tokens' if reason == 'length' else 'end_turn', 'stop_sequence': None, 'usage': {'input_tokens': 7, 'output_tokens': 3}})
        self.reply({'id': 'mock', 'object': 'chat.completion', 'created': 1700000000, 'model': body['model'], 'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': text}, 'finish_reason': reason}], 'usage': {'prompt_tokens': 7, 'completion_tokens': 3, 'prompt_tokens_details': {'cached_tokens': 2}, 'completion_tokens_details': {'reasoning_tokens': 1}}})

ThreadingHTTPServer(('127.0.0.1', 18018), Handler).serve_forever()
