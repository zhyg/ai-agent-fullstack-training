"""Extra controlled checks against unmodified business code and real SDK."""
import asyncio
import json
import os
from dataclasses import replace
from pathlib import Path

import httpx

from app.config import load_config
from app.main import create_app

ROOT = Path(__file__).resolve().parent


async def main():
    os.environ['GRADING_DUMMY_KEY'] = 'controlled-placeholder'
    cfg = load_config(str(ROOT/'mock.yaml'))
    cfg = replace(cfg, trace_file=str(ROOT/'extra-traces.jsonl'), database_path=str(ROOT/'extra.db'),
                  models={**cfg.models, 'general-primary': replace(cfg.models['general-primary'], fallback=('general-backup',))})
    app = create_app(cfg)
    out = []
    async with httpx.AsyncClient(timeout=20) as up, httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://test') as c:
        async def mode(m):
            await up.post('http://127.0.0.1:18761/control', json={'mode': m})
        await mode('break')
        await up.post('http://127.0.0.1:18761/release')
        r = await c.post('/v1/chat/completions', json={'model': 'general-primary', 'stream': True, 'messages': [{'role': 'user', 'content': 'test'}]})
        out.append({'name': 'fallback-after-content', 'status': r.status_code, 'text': r.text,
                    'upstream': (await up.get('http://127.0.0.1:18761/state')).json()})
        await mode('invalid')
        r = await c.post('/v1/responses', json={'model': 'general-primary', 'input': 'JSON please',
                        'response_format': {'type': 'json_object'}, 'text': {'format': {'type': 'json_object'}}})
        out.append({'name': 'responses-json-invalid', 'status': r.status_code, 'body': r.json(),
                    'upstream': (await up.get('http://127.0.0.1:18761/state')).json()})
        for m in ('always429', 'always400'):
            await mode(m)
            r = await c.post('/v1/chat/completions', json={'model': 'general-primary', 'messages': [{'role': 'user', 'content': 'test'}]})
            out.append({'name': 'fallback-'+m, 'status': r.status_code, 'body': r.json(),
                        'upstream': (await up.get('http://127.0.0.1:18761/state')).json()})
        for client in app.state.ctx.provider._clients.values():
            await client.close()
        # Network client (not ASGITransport) is required for incremental arrival proof.
        for m in ('gate', 'break', 'eof'):
            await mode(m)
            received = asyncio.Event()
            lines = []
            async def consume():
                async with up.stream('POST', 'http://127.0.0.1:18762/v1/responses', json={'model': 'general-primary', 'input': 'test', 'stream': True}) as r:
                    async for line in r.aiter_lines():
                        lines.append(line)
                        if 'delta' in line and 'data:' in line:
                            received.set()
            task = asyncio.create_task(consume())
            await asyncio.wait_for(received.wait(), 5)
            before = list(lines)
            await up.post('http://127.0.0.1:18761/release')
            await task
            out.append({'name': 'responses-stream-'+m, 'before_release': before, 'lines': lines,
                        'upstream': (await up.get('http://127.0.0.1:18761/state')).json()})
    (ROOT/'supplement-results.json').write_text(json.dumps({'cases': out, 'traces': [t.model_dump(mode='json') for t in app.state.ctx.traces.list()]}, ensure_ascii=False, indent=2))
    for row in out:
        print(json.dumps(row, ensure_ascii=False))


if __name__ == '__main__':
    asyncio.run(main())
