"""config 模块单元测试：.env 自动加载与环境变量优先级。"""

import os

from app.config import _load_dotenv, load_config


class TestLoadDotenv:
    def test_fills_missing_vars_and_skips_noise(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text(
            "# 注释行\n"
            "\n"
            "DEEPSEEK_API_KEY=sk-plain-key\n"
            'QUOTED_KEY="sk-quoted-key"\n'
            "EMPTY_KEY=\n"
            "NO_EQUALS_LINE\n",
            encoding="utf-8",
        )
        for name in ("DEEPSEEK_API_KEY", "QUOTED_KEY", "EMPTY_KEY"):
            monkeypatch.delenv(name, raising=False)

        _load_dotenv(str(env_file))

        assert os.environ["DEEPSEEK_API_KEY"] == "sk-plain-key"
        assert os.environ["QUOTED_KEY"] == "sk-quoted-key"
        assert os.environ["EMPTY_KEY"] == ""
        assert "NO_EQUALS_LINE" not in os.environ

    def test_system_env_takes_priority(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("DEEPSEEK_API_KEY=sk-from-file\n", encoding="utf-8")
        monkeypatch.setenv("DEEPSEEK_API_KEY", "sk-from-system")

        _load_dotenv(str(env_file))

        assert os.environ["DEEPSEEK_API_KEY"] == "sk-from-system"

    def test_missing_file_is_noop(self, tmp_path, monkeypatch):
        monkeypatch.delenv("NONEXISTENT_KEY", raising=False)

        _load_dotenv(str(tmp_path / "absent.env"))

        assert "NONEXISTENT_KEY" not in os.environ


class TestLoadConfigWithDotenv:
    def test_resolves_placeholders_from_dotenv(self, tmp_path, monkeypatch):
        (tmp_path / "config.yaml").write_text(
            "models:\n"
            "  general-primary:\n"
            "    provider_model: ${PRIMARY_PROVIDER_MODEL}\n"
            "    base_url: ${PRIMARY_BASE_URL}\n"
            "    api_key_env: DEEPSEEK_API_KEY\n",
            encoding="utf-8",
        )
        (tmp_path / ".env").write_text(
            "PRIMARY_PROVIDER_MODEL=deepseek-chat\nPRIMARY_BASE_URL=https://api.deepseek.com\n",
            encoding="utf-8",
        )
        for name in ("PRIMARY_PROVIDER_MODEL", "PRIMARY_BASE_URL", "GATEWAY_CONFIG_FILE"):
            monkeypatch.delenv(name, raising=False)
        monkeypatch.chdir(tmp_path)

        config = load_config()

        model = config.models["general-primary"]
        assert model.provider_model == "deepseek-chat"
        assert model.base_url == "https://api.deepseek.com"

    def test_system_env_beats_dotenv(self, tmp_path, monkeypatch):
        (tmp_path / "config.yaml").write_text(
            "models:\n"
            "  m:\n"
            "    provider_model: ${PRIMARY_PROVIDER_MODEL}\n"
            "    base_url: https://x\n"
            "    api_key_env: DEEPSEEK_API_KEY\n",
            encoding="utf-8",
        )
        (tmp_path / ".env").write_text("PRIMARY_PROVIDER_MODEL=from-file\n", encoding="utf-8")
        monkeypatch.setenv("PRIMARY_PROVIDER_MODEL", "from-system")
        monkeypatch.delenv("GATEWAY_CONFIG_FILE", raising=False)
        monkeypatch.chdir(tmp_path)

        config = load_config()

        assert config.models["m"].provider_model == "from-system"
