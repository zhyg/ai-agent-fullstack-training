"""#1 SDK 异常下沉：适配层归一化为网关自有异常，gateway 只判自有类型。

验收不变量：#1「把 SDK 异常归类下沉到 Provider 适配层，归一化为网关自有异常类型，
gateway 只判自己的类型」。
"""

from pathlib import Path

import httpx
from openai import APIConnectionError, APITimeoutError, RateLimitError

from app.errors import (
    GatewayError,
    ProviderError,
    UpstreamConnectionError,
    UpstreamRateLimitedError,
    UpstreamTimeoutError,
)
from app.main import create_app
from app.services.gateway import _error_code, is_retryable
from app.services.provider import normalize_upstream_error
from tests.conftest import AUTH_KEY, FakeProvider, make_config


def _request() -> httpx.Request:
    return httpx.Request("POST", "https://upstream.invalid/v1/chat/completions")


def test_normalize_rate_limit_error():
    response = httpx.Response(429, request=_request())
    normalized = normalize_upstream_error(RateLimitError("rate limited", response=response, body=None))
    assert isinstance(normalized, UpstreamRateLimitedError)
    assert normalized.retryable is True
    assert normalized.code == "upstream_rate_limited"


def test_normalize_timeout_error():
    normalized = normalize_upstream_error(APITimeoutError(request=_request()))
    assert isinstance(normalized, UpstreamTimeoutError)
    assert normalized.retryable is True
    assert normalized.code == "timeout"


def test_normalize_connection_error():
    normalized = normalize_upstream_error(APIConnectionError(request=_request()))
    assert isinstance(normalized, UpstreamConnectionError)
    assert normalized.retryable is True
    assert normalized.code == "connection_error"


def test_normalize_unknown_error_is_generic_transport():
    # BadRequest / InternalServer / 未知异常 → 通用传输错误，不可重试
    normalized = normalize_upstream_error(ValueError("boom"))
    assert type(normalized) is ProviderError
    assert normalized.retryable is False
    assert normalized.code == "transport_error"


def test_is_retryable_only_native_types():
    assert is_retryable(UpstreamTimeoutError("t")) is True
    assert is_retryable(UpstreamRateLimitedError("r")) is True
    assert is_retryable(UpstreamConnectionError("c")) is True
    assert is_retryable(ProviderError("generic")) is False
    # 非自有类型不再隐式可重试：适配层必须显式归一化
    assert is_retryable(TimeoutError("stdlib timeout")) is False
    assert is_retryable(ValueError("boom")) is False


def test_error_code_normalization():
    assert _error_code(GatewayError("circuit_open", "熔断", 503)) == "circuit_open"
    assert _error_code(UpstreamTimeoutError("t")) == "timeout"
    assert _error_code(UpstreamRateLimitedError("r")) == "upstream_rate_limited"
    assert _error_code(ValueError("boom")) == "transport_error"


def test_gateway_module_does_not_import_vendor_sdk():
    # 结构不变量：供应商 SDK 只允许出现在 Provider 适配层，gateway 不得导入
    project_root = Path(__file__).resolve().parents[1]
    gateway_src = (project_root / "app/services/gateway.py").read_text(encoding="utf-8")
    provider_src = (project_root / "app/services/provider.py").read_text(encoding="utf-8")
    assert "openai" not in gateway_src
    assert "openai" in provider_src


async def test_provider_error_retries_then_falls_back(tmp_path):
    # 归一化后的可重试错误保持原有重试+切换语义：主模型 1 次 + 重试 1 次 + 备用 1 次
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(failures=2)
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    assert provider.complete_calls == ["primary-model", "primary-model", "backup-model"]
    trace = app.state.ctx.traces.list()[-1]
    assert trace.routing_reason == "timeout"
