"""OpenAI 兼容路径 response_format 接入本地 JSON 校验：非法输出不再以成功返回。"""

import json

from app.schemas import Usage
from tests.conftest import FakeProvider

GOOD_JSON = json.dumps({"answer": "ok"})
SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}


class SequenceProvider(FakeProvider):
    """按顺序返回预设内容；同一模型连续调用依次取下一个。"""

    def __init__(self, primary_replies: list[str], backup_replies: list[str]) -> None:
        super().__init__()
        self.primary_replies = list(primary_replies)
        self.backup_replies = list(backup_replies)
        self.complete_calls: list[str] = []

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        replies = self.primary_replies if config.provider_model == "primary-model" else self.backup_replies
        return replies.pop(0), Usage(input_tokens=11, output_tokens=7)


async def test_json_object_valid_output_passes(client, app):
    app.state.ctx.provider = FakeProvider(content=GOOD_JSON)
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "response_format": {"type": "json_object"},
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["choices"][0]["message"]["content"] == GOOD_JSON
    # 网关返回 OpenAI 兼容错误/成功体，无内部字段泄漏
    assert body["object"] == "chat.completion"


async def test_json_object_invalid_triggers_repair_on_same_model(client, app):
    # 声明 json_object 后返回非法 JSON：本地校验失败 → 喂回同一模型修复，不切备用
    provider = SequenceProvider(["不是JSON", GOOD_JSON], [])
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "response_format": {"type": "json_object"},
        },
    )
    assert response.status_code == 200, response.text
    assert response.json()["choices"][0]["message"]["content"] == GOOD_JSON
    assert provider.complete_calls == ["primary-model", "primary-model"]


async def test_json_object_repair_exhausted_falls_back(client, app):
    # 修复耗尽（默认 2 次）后切备用模型，全程不把非法 JSON 当成功返回
    provider = SequenceProvider(["不是JSON", "也不是JSON", "还不是JSON"], [GOOD_JSON])
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "response_format": {"type": "json_object"},
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    # OpenAI 兼容响应 model 为请求模型名（客户端视角），实际模型在审计里
    assert body["choices"][0]["message"]["content"] == GOOD_JSON
    assert provider.complete_calls == ["primary-model"] * 3 + ["backup-model"]


async def test_json_schema_mismatch_triggers_schema_repair(client, app):
    # json_schema 类型：合法 JSON 但不符合 Schema 同样触发自修复
    provider = SequenceProvider([json.dumps({"answer": 123}), GOOD_JSON], [])
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "response_format": {"type": "json_schema", "json_schema": {"name": "a", "schema": SCHEMA}},
        },
    )
    assert response.status_code == 200, response.text
    assert response.json()["choices"][0]["message"]["content"] == GOOD_JSON
    assert provider.complete_calls == ["primary-model", "primary-model"]


async def test_json_schema_missing_schema_400(client):
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "response_format": {"type": "json_schema", "json_schema": {"name": "a"}},
        },
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "invalid_response_format"


async def test_stream_with_response_format_400(client):
    # 流式下无法在发送前完成整体 JSON 校验，与 /v1/llm/stream 组合语义一致
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "stream": True,
            "response_format": {"type": "json_object"},
        },
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "unsupported_combination"


async def test_no_response_format_keeps_passthrough(client, app):
    # 回归保护：未声明 response_format 时不做本地校验，行为与迁移前一致
    app.state.ctx.provider = FakeProvider(content="正常结果")
    response = await client.post(
        "/v1/chat/completions",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
    )
    assert response.status_code == 200
    assert response.json()["choices"][0]["message"]["content"] == "正常结果"
