"""SQLite 用量账本：TTFT、缓存 Token、Key 指纹、失败状态码与查询 API。

双写约定：JSONL（traces.jsonl）是不可变审计流水，SQLite 是查询投影；
账本行不含消息内容与原始 API Key，只含指纹。
"""

import httpx
import pytest

from app.core.security import key_fingerprint
from app.errors import UpstreamTimeoutError
from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config


async def test_ledger_records_success_row(client, fake, app):
    response = await client.post(
        "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert response.status_code == 200
    rows = app.state.ctx.ledger.recent()
    assert len(rows) == 1
    row = rows[0]
    assert row["request_id"] == response.json()["request_id"]
    assert row["requested_model"] == "general-primary"
    assert row["actual_model"] == "general-primary"
    assert row["input_tokens"] == 11
    assert row["output_tokens"] == 7
    assert row["cached_tokens"] == 0
    assert row["cost_usd"] == pytest.approx((11 * 1.0 + 7 * 4.0) / 1_000_000)
    assert row["status"] == "success"
    assert row["status_code"] == 200
    assert row["stream"] == 0
    assert row["attempts"] == 1
    assert row["api_key_hash"] == key_fingerprint(AUTH_KEY)
    # JSONL 审计与 SQLite 双写：两条链路都落盘
    assert len(app.state.ctx.traces.list()) == 1


async def test_ledger_records_stream_row_with_ttft(client, fake, app):
    await client.post(
        "/v1/llm/stream", json={"model": "general-primary", "messages": [{"role": "user", "content": "s"}]}
    )
    row = app.state.ctx.ledger.recent()[0]
    assert row["stream"] == 1
    assert row["first_token_ms"] is not None
    assert row["first_token_ms"] >= 0
    assert row["input_tokens"] == 9
    assert row["output_tokens"] == 4
    assert row["status"] == "success"


async def test_ledger_records_cached_tokens(client, app):
    app.state.ctx.provider = FakeProvider(cached_tokens=5)
    await client.post(
        "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert app.state.ctx.ledger.recent()[0]["cached_tokens"] == 5


async def test_ledger_records_failed_row_with_status_code(client, app):
    app.state.ctx.provider = FakeProvider(error=UpstreamTimeoutError("down"))
    response = await client.post(
        "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert response.status_code == 502
    row = app.state.ctx.ledger.recent()[0]
    assert row["status"] == "failed"
    assert row["error_code"] == "model_unavailable"
    assert row["status_code"] == 502
    assert row["input_tokens"] == 0
    assert row["api_key_hash"] == key_fingerprint(AUTH_KEY)


async def test_ledger_stream_failure_http_stays_200(client, app):
    # 流式 HTTP 状态码已锁定 200，失败通过流内 error 事件传递；账本如实记录
    app.state.ctx.provider = FakeProvider(stream_failures=10)
    response = await client.post(
        "/v1/llm/stream", json={"model": "general-primary", "messages": [{"role": "user", "content": "s"}]}
    )
    assert response.status_code == 200
    row = app.state.ctx.ledger.recent()[0]
    assert row["status"] == "failed"
    assert row["error_code"] == "upstream_stream_failed"
    assert row["status_code"] == 200
    assert row["stream"] == 1


async def test_admin_usage_endpoint(client):
    await client.post(
        "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    response = await client.get("/admin/usage")
    assert response.status_code == 200
    body = response.json()
    assert len(body["data"]) == 1
    assert body["data"][0]["requested_model"] == "general-primary"
    # 账本只含指纹，不含原始 Key
    assert AUTH_KEY not in str(body)


async def test_ledger_survives_restart(tmp_path):
    config = make_config(tmp_path)
    app = create_app(config)
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
        assert response.status_code == 200
        request_id = response.json()["request_id"]
    # 模拟重启：同一 SQLite 文件路径重建应用后仍可查到历史
    app2 = create_app(config)
    rows = app2.state.ctx.ledger.recent()
    assert len(rows) == 1
    assert rows[0]["request_id"] == request_id
