"""Responses API：透传、能力开关、fallback/重试、SSE 事件流与 SDK 直连。"""

from dataclasses import replace

import httpx
from openai import AsyncOpenAI

from app.errors import UpstreamRateLimitedError
from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config


async def test_responses_non_stream_passthrough(client, fake):
    response = await client.post("/v1/responses", json={"model": "general-primary", "input": "你好"})
    assert response.status_code == 200
    body = response.json()
    assert body["object"] == "response"
    assert body["output"][0]["content"][0]["text"] == "正常结果"
    # 不向调用方泄漏供应商模型名：payload.model 重写为虚拟模型名
    assert body["model"] == "general-primary"


async def test_responses_usage_recorded_in_ledger(client, fake, app):
    response = await client.post("/v1/responses", json={"model": "general-primary", "input": "你好"})
    assert response.status_code == 200
    row = app.state.ctx.ledger.recent()[0]
    assert row["requested_model"] == "general-primary"
    assert row["input_tokens"] == 11
    assert row["output_tokens"] == 7
    assert row["stream"] == 0
    assert row["status"] == "success"
    # JSONL 审计同样落盘
    assert len(app.state.ctx.traces.list()) == 1


async def test_responses_model_without_capability_400(tmp_path):
    config = make_config(tmp_path)
    config = replace(
        config,
        models={name: replace(model, supports_responses=False) for name, model in config.models.items()},
    )
    app = create_app(config)
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/responses", json={"model": "general-primary", "input": "hi"})
        assert response.status_code == 400
        assert response.json()["error"]["code"] == "responses_unsupported"


class PrimaryRateLimitedResponses(FakeProvider):
    """主模型 Responses 调用恒定 429，备用模型正常。"""

    async def responses(self, config, input_data, timeout_seconds):
        if config.provider_model == "primary-model":
            self.responses_calls.append(config.provider_model)
            raise UpstreamRateLimitedError("rate limited")
        return await super().responses(config, input_data, timeout_seconds)


async def test_responses_rate_limit_retries_then_falls_back(client, app):
    app.state.ctx.provider = PrimaryRateLimitedResponses()
    response = await client.post("/v1/responses", json={"model": "general-primary", "input": "hi"})
    assert response.status_code == 200
    # 429 可重试：主模型重试 1 次后切换备用模型
    assert app.state.ctx.provider.responses_calls == ["primary-model", "primary-model", "backup-model"]
    row = app.state.ctx.ledger.recent()[0]
    assert row["actual_model"] == "general-backup"
    assert row["attempts"] == 3


async def test_responses_stream_sse_events(client, fake, app):
    response = await client.post(
        "/v1/responses", json={"model": "general-primary", "input": "hi", "stream": True}
    )
    assert response.status_code == 200
    text = response.text
    assert "event: response.output_text.delta" in text
    assert '"delta": "第"' in text
    assert '"delta": "一块"' in text
    assert "event: response.completed" in text
    # 完成事件里的 model 重写为虚拟模型名
    assert '"model": "general-primary"' in text
    row = app.state.ctx.ledger.recent()[0]
    assert row["stream"] == 1
    assert row["first_token_ms"] is not None
    assert row["input_tokens"] == 9
    assert row["status"] == "success"


async def test_responses_stream_failure_emits_error_event(client, app):
    app.state.ctx.provider = FakeProvider(stream_failures=10)
    response = await client.post(
        "/v1/responses", json={"model": "general-primary", "input": "hi", "stream": True}
    )
    assert response.status_code == 200
    assert "event: error" in response.text
    assert '"code": "upstream_stream_failed"' in response.text
    assert "event: response.completed" not in response.text
    row = app.state.ctx.ledger.recent()[0]
    assert row["status"] == "failed"
    assert row["error_code"] == "upstream_stream_failed"
    assert row["status_code"] == 200


async def test_responses_sdk_direct(app):
    # 真实 SDK 直连网关：非流式与流式都能解析（协议兼容性 e2e）
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test/v1") as http_client:
        client = AsyncOpenAI(base_url="http://test/v1", api_key=AUTH_KEY, http_client=http_client)
        response = await client.responses.create(model="general-primary", input="hi")
        assert response.output_text == "正常结果"

        stream = await client.responses.create(model="general-primary", input="hi", stream=True)
        deltas = []
        async for event in stream:
            if event.type == "response.output_text.delta":
                deltas.append(event.delta)
        assert "".join(deltas) == "第一块"
