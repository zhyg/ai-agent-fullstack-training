"""P2 Run 级总预算：重试、自修复与备用切换共用同一计数，超限直接终态。

验收不变量：#14「重试、Fallback 和修复调用都受同一个 Run 预算约束」。
"""

import httpx

from app.config import _parse
from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config


async def _budget_client(tmp_path, run_budget, provider):
    app = create_app(make_config(tmp_path, run_budget=run_budget))
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    client = httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    )
    return app, client


async def test_run_budget_stops_retries_and_fallback(tmp_path):
    # 预算 3：主模型 1 次 + 重试 1 次 + 备用 1 次后耗尽，不再调用剩余模型
    app, client = await _budget_client(tmp_path, run_budget=3, provider=FakeProvider(failures=99))
    async with client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 502
    assert response.json()["detail"]["code"] == "run_budget_exhausted"
    assert len(app.state.ctx.provider.complete_calls) == 3
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "run_budget_exhausted"
    assert trace.attempts == 3


async def test_run_budget_counts_repairs(tmp_path):
    # 自修复同样消耗 Run 预算：预算 2 时两次校验失败后直接终态，不切备用
    provider = FakeProvider(content="不是 JSON")
    app, client = await _budget_client(tmp_path, run_budget=2, provider=provider)
    async with client:
        response = await client.post(
            "/v1/llm",
            json={
                "model": "general-primary",
                "messages": [{"role": "user", "content": "x"}],
                "response_schema": {"type": "object"},
            },
        )
    assert response.status_code == 502
    assert response.json()["detail"]["code"] == "run_budget_exhausted"
    # 两次尝试都在主模型上（初始 + 1 次自修复），备用模型从未被调用
    assert provider.complete_calls == ["primary-model", "primary-model"]
    trace = app.state.ctx.traces.list()[-1]
    assert trace.attempts == 2


async def test_run_budget_stream_terminal_event(tmp_path):
    # 流式：预算耗尽产生 failed 终态事件，trace 记录 run_budget_exhausted
    app, client = await _budget_client(tmp_path, run_budget=1, provider=FakeProvider(stream_failures=99))
    async with client:
        response = await client.post(
            "/v1/llm/stream",
            json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
        )
    assert response.status_code == 200  # 流式状态码锁定，失败走流内事件
    assert '"run_budget_exhausted"' in response.text
    assert len(app.state.ctx.provider.stream_calls) == 1
    trace = app.state.ctx.traces.list()[-1]
    assert trace.error_code == "run_budget_exhausted"
    assert trace.attempts == 1


async def test_run_budget_responses_path(tmp_path):
    # Responses 路径同样受 Run 预算约束：预算 1 时主模型失败即终态，不再切备用
    app, client = await _budget_client(
        tmp_path, run_budget=1, provider=FakeProvider(error=ValueError("boom"))
    )
    async with client:
        response = await client.post("/v1/responses", json={"model": "general-primary", "input": "hi"})
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "run_budget_exhausted"
    assert len(app.state.ctx.provider.responses_calls) == 1


async def test_budget_sufficient_does_not_trigger(tmp_path):
    # 预算充足时正常路径不受影响：主模型重试后切换备用成功
    app, client = await _budget_client(tmp_path, run_budget=12, provider=FakeProvider(failures=2))
    async with client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    assert response.json()["model"] == "general-backup"
    assert response.json()["attempts"] == 3


def test_config_parse_run_budget():
    assert _parse({}).run_budget == 12
    assert _parse({"run_budget": 7}).run_budget == 7
