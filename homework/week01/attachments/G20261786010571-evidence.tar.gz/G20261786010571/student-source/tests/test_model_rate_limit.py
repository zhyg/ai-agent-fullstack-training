"""按模型独立限流：模型 A 打满不影响模型 B，配额拒绝返回 429 且带审计。"""

from dataclasses import replace

import httpx

from app.config import RateLimitConfig
from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config


def make_limited_config(tmp_path, primary_capacity, backup_capacity=None):
    config = make_config(tmp_path)
    primary = replace(
        config.models["general-primary"],
        rate_limit=RateLimitConfig(capacity=primary_capacity, refill_per_second=0.001),
    )
    backup = config.models["general-backup"]
    if backup_capacity is not None:
        backup = replace(
            backup, rate_limit=RateLimitConfig(capacity=backup_capacity, refill_per_second=0.001)
        )
    return replace(config, models={"general-primary": primary, "general-backup": backup})


async def test_model_rate_limit_rejects_only_saturated_model(tmp_path):
    # primary 配额 2：前两次成功，第三次 429；未配置限流的 backup 不受影响
    app = create_app(make_limited_config(tmp_path, primary_capacity=2))
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        assert (await client.post("/v1/llm", json=payload)).status_code == 200
        assert (await client.post("/v1/llm", json=payload)).status_code == 200
        response = await client.post("/v1/llm", json=payload)
        assert response.status_code == 429
        assert response.json()["detail"]["code"] == "rate_limit_exceeded"
        # backup 独立配额：不受 primary 饱和影响
        response = await client.post(
            "/v1/llm", json={"model": "general-backup", "messages": [{"role": "user", "content": "x"}]}
        )
        assert response.status_code == 200


async def test_model_rate_limit_rejection_is_audited(tmp_path):
    # 429 拒绝也落审计：error_code=rate_limit_exceeded、status_code=429
    app = create_app(make_limited_config(tmp_path, primary_capacity=1))
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        assert (await client.post("/v1/llm", json=payload)).status_code == 200
        assert (await client.post("/v1/llm", json=payload)).status_code == 429

    rejected = [t for t in app.state.ctx.traces.list() if t.error_code == "rate_limit_exceeded"]
    assert len(rejected) == 1
    assert rejected[0].status == "failed"
    assert rejected[0].status_code == 429
    row = app.state.ctx.ledger.recent()[0]
    assert row["error_code"] == "rate_limit_exceeded"
    assert row["status_code"] == 429


class PrimaryOnlyFails(FakeProvider):
    """只让主模型恒定不可重试失败，备用模型正常。"""

    async def complete(self, config, messages, timeout_seconds, response_schema):
        if config.provider_model == "primary-model":
            raise ValueError("non-retryable boom")
        return await super().complete(config, messages, timeout_seconds, response_schema)


async def test_fallback_model_quota_enforced(tmp_path):
    # 备用模型有独立配额：primary 恒定不可重试失败 → 切 backup；backup 配额耗尽后 429
    app = create_app(make_limited_config(tmp_path, primary_capacity=100, backup_capacity=1))
    app.state.ctx.provider = PrimaryOnlyFails()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        # 第一次：primary 失败切 backup，backup 配额 1 消耗
        assert (await client.post("/v1/llm", json=payload)).status_code == 200
        # 第二次：primary 仍失败，backup 配额耗尽 → 429
        response = await client.post("/v1/llm", json=payload)
        assert response.status_code == 429
        assert response.json()["detail"]["code"] == "rate_limit_exceeded"


async def test_stream_rate_limit_rejected_with_429(tmp_path):
    # 流式限流拒绝必须前置：返回 429 状态码而非 200 + 中断流
    app = create_app(make_limited_config(tmp_path, primary_capacity=1))
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        first = await client.post("/v1/llm/stream", json=payload)
        assert first.status_code == 200
        assert "content.delta" in first.text
        second = await client.post("/v1/llm/stream", json=payload)
        assert second.status_code == 429
        assert second.json()["detail"]["code"] == "rate_limit_exceeded"
