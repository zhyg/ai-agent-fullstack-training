"""P1 未支持参数语义：语义参数 400（指名参数与原因），抽样参数丢弃但响应头+审计标记。

验收不变量：#3「未支持的字段和能力在模型调用前明确失败」。
语义参数（n>1 / tools / 消息内 tool_calls）会改变调用方预期行为 → 400；
抽样参数（temperature 等）与未知参数不转发，但通过 X-Gateway-Dropped-Params
响应头与 trace.dropped_params 显式披露；strict_params 验收模式下一律 400。
"""

import httpx

from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config

PAYLOAD = {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}


async def test_n_greater_than_one_rejected(client):
    response = await client.post("/v1/chat/completions", json={**PAYLOAD, "n": 2})
    assert response.status_code == 400
    err = response.json()["error"]
    assert err["code"] == "unsupported_param"
    assert err["param"] == "n"
    assert "n=1" in err["message"]


async def test_tools_rejected(client):
    response = await client.post(
        "/v1/chat/completions",
        json={**PAYLOAD, "tools": [{"type": "function", "function": {"name": "f"}}]},
    )
    assert response.status_code == 400
    err = response.json()["error"]
    assert err["code"] == "unsupported_param"
    assert err["param"] == "tools"
    assert "工具调用" in err["message"]


async def test_message_tool_calls_rejected(client):
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [
                {"role": "assistant", "content": "h", "tool_calls": [{"id": "1", "type": "function"}]},
                {"role": "user", "content": "x"},
            ],
        },
    )
    assert response.status_code == 400
    assert response.json()["error"]["param"] == "messages[].tool_calls"


async def test_sampling_params_dropped_and_marked(client, app, fake):
    response = await client.post(
        "/v1/chat/completions",
        json={**PAYLOAD, "temperature": 0.3, "top_p": 0.8, "max_tokens": 100},
    )
    assert response.status_code == 200
    dropped = response.headers.get("x-gateway-dropped-params", "")
    assert dropped.split(", ") == ["temperature", "top_p", "max_tokens"]
    # 审计记录同样携带丢弃参数，网关日志 llm_call_trace 随 CallTrace 一并输出
    trace = app.state.ctx.traces.list()[-1]
    assert trace.dropped_params == ["temperature", "top_p", "max_tokens"]


async def test_stream_sampling_params_marked(client, fake):
    response = await client.post(
        "/v1/chat/completions",
        json={**PAYLOAD, "stream": True, "temperature": 0.5},
    )
    assert response.status_code == 200
    assert response.headers.get("x-gateway-dropped-params") == "temperature"


async def test_n_one_marked_not_rejected(client, fake):
    # n=1 与网关行为一致，不拒绝，但标记丢弃
    response = await client.post("/v1/chat/completions", json={**PAYLOAD, "n": 1})
    assert response.status_code == 200
    assert response.headers.get("x-gateway-dropped-params") == "n"


async def test_unknown_param_marked_by_default(client, fake):
    # 未知字段默认丢弃并标记（容忍未来 SDK 新参数），而非静默吞掉
    response = await client.post("/v1/chat/completions", json={**PAYLOAD, "foo": 1})
    assert response.status_code == 200
    assert response.headers.get("x-gateway-dropped-params") == "foo"


async def test_no_extra_params_no_header(client, fake):
    response = await client.post("/v1/chat/completions", json=PAYLOAD)
    assert response.status_code == 200
    assert "x-gateway-dropped-params" not in response.headers


def _strict_client(tmp_path):
    app = create_app(make_config(tmp_path, strict_params=True))
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    return app, httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    )


async def test_strict_params_rejects_sampling(tmp_path):
    app, client = _strict_client(tmp_path)
    async with client:
        response = await client.post("/v1/chat/completions", json={**PAYLOAD, "temperature": 0.3})
    assert response.status_code == 400
    err = response.json()["error"]
    assert err["code"] == "unsupported_param"
    assert err["param"] == "temperature"


async def test_strict_params_rejects_unknown(tmp_path):
    app, client = _strict_client(tmp_path)
    async with client:
        response = await client.post("/v1/chat/completions", json={**PAYLOAD, "foo": 1})
    assert response.status_code == 400
    assert response.json()["error"]["param"] == "foo"


async def test_strict_params_keeps_semantic_rejection(tmp_path):
    app, client = _strict_client(tmp_path)
    async with client:
        response = await client.post("/v1/chat/completions", json={**PAYLOAD, "n": 2})
    assert response.status_code == 400
    assert response.json()["error"]["param"] == "n"
