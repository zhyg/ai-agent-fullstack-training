"""结构化自修复：本地校验失败 → 把校验错误喂回同一模型重试 → 仍失败再切备用模型。"""

import json

import httpx

from app.main import create_app
from app.schemas import Usage
from tests.conftest import AUTH_KEY, FakeProvider, make_config

SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}


class SequenceProvider(FakeProvider):
    """按顺序返回预设内容；同一模型连续调用依次取下一个。"""

    def __init__(self, primary_replies: list[str], backup_replies: list[str]) -> None:
        super().__init__()
        self.primary_replies = list(primary_replies)
        self.backup_replies = list(backup_replies)
        self.complete_calls: list[str] = []
        self.messages_seen: list[list] = []

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        self.messages_seen.append(list(messages))
        replies = self.primary_replies if config.provider_model == "primary-model" else self.backup_replies
        content = replies.pop(0)
        return content, Usage(input_tokens=11, output_tokens=7)


async def test_repair_recovers_on_same_model(client, app):
    # 第一次返回非法 JSON，第二次修复成功：不切备用模型
    provider = SequenceProvider(["不是JSON", json.dumps({"answer": "ok"})], [])
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "response_schema": SCHEMA,
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model"] == "general-primary"
    assert body["parsed"] == {"answer": "ok"}
    assert body["attempts"] == 2
    assert provider.complete_calls == ["primary-model", "primary-model"]
    # 修复消息包含失败输出与校验错误说明
    repair_request = provider.messages_seen[1]
    assert repair_request[-2].role == "assistant"
    assert repair_request[-2].content == "不是JSON"
    assert "JSON Schema" in repair_request[-1].content


async def test_repair_fixes_schema_mismatch(client, app):
    # 合法 JSON 但不符合 Schema → schema_validation_failed 同样触发自修复
    provider = SequenceProvider([json.dumps({"answer": 123}), json.dumps({"answer": "ok"})], [])
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "response_schema": SCHEMA,
        },
    )
    assert response.status_code == 200, response.text
    assert response.json()["parsed"] == {"answer": "ok"}
    assert provider.complete_calls == ["primary-model", "primary-model"]
    # 修复提示中携带了 jsonschema 的校验错误细节
    assert "123" in provider.messages_seen[1][-1].content


async def test_repair_exhausted_falls_back_to_backup(client, app):
    # 修复重试耗尽（默认 2 次）后切换到备用模型
    provider = SequenceProvider(["不是JSON", "也不是JSON", "还不是JSON"], [json.dumps({"answer": "backup"})])
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "response_schema": SCHEMA,
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model"] == "general-backup"
    assert body["parsed"] == {"answer": "backup"}
    # 主模型：初始 1 次 + 修复 2 次；备用模型 1 次
    assert provider.complete_calls == ["primary-model"] * 3 + ["backup-model"]
    assert body["attempts"] == 4


async def test_repair_disabled_by_config_falls_back_immediately(tmp_path):
    config = make_config(tmp_path, structured_output_repair_attempts=0)
    app = create_app(config)
    provider = SequenceProvider(["不是JSON", "也不是JSON"], [json.dumps({"answer": "backup"})])
    app.state.ctx.provider = provider

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm",
            json={
                "model": "general-primary",
                "messages": [{"role": "user", "content": "hello"}],
                "response_schema": SCHEMA,
            },
        )
        assert response.status_code == 200, response.text
        assert response.json()["model"] == "general-backup"
        # 修复次数为 0：主模型只调用一次即切备用
        assert provider.complete_calls == ["primary-model", "backup-model"]
