"""流式客户端断开检测：终止上游流、释放连接、审计记录 client_disconnected。"""

from app.main import create_app
from app.schemas import LLMRequest, Message, OpenAIResponsesRequest
from app.services.gateway import responses_stream_with_fallback, stream_with_fallback
from tests.conftest import FakeProvider, make_config


class DisconnectAfterFirst:
    """第一次检查返回 False（客户端仍在），之后返回 True（已断开）。"""

    def __init__(self) -> None:
        self.calls = 0

    async def __call__(self) -> bool:
        self.calls += 1
        return self.calls > 1


async def test_chat_stream_stops_and_closes_upstream_on_disconnect(tmp_path):
    config = make_config(tmp_path)
    app = create_app(config)
    provider = FakeProvider()
    app.state.ctx.provider = provider
    ctx = app.state.ctx
    request = LLMRequest(model="general-primary", messages=[Message(role="user", content="x")])

    events = []
    async for kind, _payload in stream_with_fallback(
        request, ctx, "req-disconnect-1", None, disconnected=DisconnectAfterFirst()
    ):
        events.append(kind)

    # 只发出第一块增量即终止，不再发 completed
    assert events == ["delta"]
    # 上游流被关闭（adapter finally 清理路径执行）
    assert provider.stream_closed == 1
    # 审计记录 client_disconnected，HTTP 状态码保持 200（流已开始无法改码）
    trace = ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "client_disconnected"
    assert trace.status_code == 200
    assert trace.stream is True


async def test_responses_stream_stops_and_closes_upstream_on_disconnect(tmp_path):
    config = make_config(tmp_path)
    app = create_app(config)
    provider = FakeProvider()
    app.state.ctx.provider = provider
    ctx = app.state.ctx
    request = OpenAIResponsesRequest(model="general-primary", input="hi", stream=True)

    events = []
    async for kind, _payload in responses_stream_with_fallback(
        request, ctx, "req-disconnect-2", None, disconnected=DisconnectAfterFirst()
    ):
        events.append(kind)

    assert events == ["sse_event"]
    assert provider.responses_stream_closed == 1
    trace = ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "client_disconnected"
    assert trace.stream is True


async def test_stream_without_disconnect_completes_normally(tmp_path):
    # 回归保护：不传断开检测时行为不变（正常完成 + success 审计）
    config = make_config(tmp_path)
    app = create_app(config)
    provider = FakeProvider()
    app.state.ctx.provider = provider
    ctx = app.state.ctx
    request = LLMRequest(model="general-primary", messages=[Message(role="user", content="x")])

    kinds = []
    async for kind, _payload in stream_with_fallback(request, ctx, "req-normal-1"):
        kinds.append(kind)

    assert kinds == ["delta", "delta", "completed"]
    trace = ctx.traces.list()[-1]
    assert trace.status == "success"
    assert trace.error_code is None
