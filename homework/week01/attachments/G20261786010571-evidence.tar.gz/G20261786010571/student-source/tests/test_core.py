"""核心组件单元测试：熔断器半开探测语义。"""

from app.core.circuit_breaker import CircuitBreaker


def test_half_open_allows_single_probe():
    # 半开状态同一时刻只放行一个探测请求，成功即恢复 closed
    breaker = CircuitBreaker(failure_threshold=1, cooldown_seconds=0)
    assert breaker.allow_request()  # closed 放行
    breaker.record_failure()  # 达到阈值 → open
    assert breaker.state == "open"
    assert breaker.allow_request()  # 冷却期已过 → half_open 放行探测
    assert not breaker.allow_request()  # 探测在途，拒绝并发请求
    assert not breaker.allow_request()
    breaker.record_success()  # 探测成功 → closed
    assert breaker.state == "closed"
    assert breaker.allow_request()


def test_half_open_probe_failure_reopens():
    breaker = CircuitBreaker(failure_threshold=1, cooldown_seconds=0)
    breaker.allow_request()
    breaker.record_failure()  # open
    assert breaker.allow_request()  # 放行探测
    breaker.record_failure()  # 探测失败 → 重新 open
    assert breaker.state == "open"
    assert breaker.probe_in_flight is False


def test_release_probe_keeps_half_open():
    # 探测以不可重试错误结束时仅释放占位，断路器保持 half_open 等待下一次探测
    breaker = CircuitBreaker(failure_threshold=1, cooldown_seconds=0)
    breaker.allow_request()
    breaker.record_failure()  # open
    assert breaker.allow_request()  # 放行探测
    breaker.release_probe()
    assert breaker.state == "half_open"
    assert breaker.allow_request()  # 占位已释放，可再次探测
