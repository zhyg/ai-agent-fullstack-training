"""#4/#11 CallTrace 补充字段：routing_reason、Schema 摘要与价格快照。

验收不变量：#4「指定逻辑模型后，可以从 Trace 看到最终端点和路由理由」；
#11「每次调用可以定位 Prompt、Schema、路由、模型、价格版本和尝试次数」。
"""

import hashlib
import json
from dataclasses import replace

import httpx

from app.errors import GatewayError, UpstreamTimeoutError
from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config


def _make_client(tmp_path, provider):
    app = create_app(make_config(tmp_path))
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    client = httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    )
    return app, client


def _schema_hash(schema: dict) -> str:
    canonical = json.dumps(schema, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


async def test_fallback_success_records_routing_reason(tmp_path):
    # 主模型超时 2 次（初试 + 重试）后切备用：Trace 记最终端点与路由理由
    provider = FakeProvider(failures=2)
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "timeout"
    assert trace.price_snapshot == {"input": 0.8, "output": 3.2}  # 成本口径 = 备用模型价格
    assert provider.complete_calls == ["primary-model", "primary-model", "backup-model"]


async def test_primary_serves_without_routing_reason(tmp_path):
    provider = FakeProvider()
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-primary"
    assert trace.routing_reason is None
    assert trace.price_snapshot == {"input": 1.0, "output": 4.0}


async def test_schema_hash_recorded_and_stable(tmp_path):
    schema = {"type": "object", "properties": {"answer": {"type": "integer"}}, "required": ["answer"]}
    provider = FakeProvider(content='{"answer": 2}')
    app, client = _make_client(tmp_path, provider)
    async with client:
        first = await client.post(
            "/v1/llm",
            json={
                "model": "general-primary",
                "messages": [{"role": "user", "content": "x"}],
                "response_schema": schema,
            },
        )
        second = await client.post(
            "/v1/llm",
            json={
                "model": "general-primary",
                "messages": [{"role": "user", "content": "x"}],
                "response_schema": schema,
            },
        )
    assert first.status_code == 200
    assert second.status_code == 200
    traces = app.state.ctx.traces.list()
    assert traces[-1].schema_hash == _schema_hash(schema)
    assert traces[-2].schema_hash == _schema_hash(schema)  # 同一 Schema 摘要稳定可定位


async def test_no_schema_hash_without_schema(tmp_path):
    provider = FakeProvider()
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.schema_hash is None


async def test_total_failure_records_routing_reason_and_price_snapshot(tmp_path):
    # 主备全部失败：失败 Trace 同样带路由理由，价格快照取主模型价格版本，成本为 0
    provider = FakeProvider(failures=10)
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 502
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "model_unavailable"
    assert trace.routing_reason == "timeout"
    assert trace.price_snapshot == {"input": 1.0, "output": 4.0}
    assert trace.cost_usd == 0


async def test_circuit_open_routing_reason(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider()
    app.state.ctx.provider = provider
    for _ in range(3):  # 主模型熔断阈值 3：触发 open 后请求直接切备用
        app.state.ctx.breakers["general-primary"].record_failure()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "circuit_open"


async def test_first_switch_code_kept_across_chain(tmp_path):
    # 三级链：primary 超时 → mid 熔断 → backup 成功。routing_reason 保留首次切换的错误码
    config = make_config(tmp_path)
    primary = config.models["general-primary"]
    backup = config.models["general-backup"]
    # fallback_chain 只展开主模型的一级 fallback 列表，三级链直接列在 primary 上
    mid = replace(backup, provider_model="mid-model")
    primary3 = replace(primary, fallback=("general-mid", "general-backup"))
    config = replace(
        config, models={"general-primary": primary3, "general-mid": mid, "general-backup": backup}
    )
    app = create_app(config)
    provider = FakeProvider(
        errors={
            "primary-model": UpstreamTimeoutError("primary timeout"),
            "mid-model": GatewayError("circuit_open", "mid 熔断", 503),
        }
    )
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "timeout"  # 首次切换原因不被后续 mid 的 circuit_open 覆盖
    assert provider.complete_calls == [
        "primary-model",
        "primary-model",
        "mid-model",
        "backup-model",
    ]


async def test_stream_fallback_records_routing_reason(tmp_path):
    provider = FakeProvider(stream_failures=2)
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post(
            "/v1/llm/stream",
            json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "timeout"
    assert provider.stream_calls == ["primary-model", "primary-model", "backup-model"]


async def test_responses_fallback_records_routing_reason(tmp_path):
    provider = FakeProvider(failures=2)
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post("/v1/responses", json={"model": "general-primary", "input": "x"})
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "timeout"


async def test_responses_stream_fallback_records_routing_reason(tmp_path):
    provider = FakeProvider(stream_failures=2)
    app, client = _make_client(tmp_path, provider)
    async with client:
        response = await client.post(
            "/v1/responses", json={"model": "general-primary", "input": "x", "stream": True}
        )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "timeout"
