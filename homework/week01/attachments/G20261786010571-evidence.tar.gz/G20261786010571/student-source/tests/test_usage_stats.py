"""#13 用量聚合：按租户、模型、Prompt 版本聚合 Token、成本、TTFT 与延迟。

验收不变量：#13「Token、Cost、TTFT 和总延迟可以按租户、模型和 Prompt 版本聚合」。
"""

import httpx
import pytest

from app.core.security import key_fingerprint
from app.main import create_app
from tests.conftest import AUTH_KEY, FakeProvider, make_config


def _make_client(app, key: str = AUTH_KEY) -> httpx.AsyncClient:
    transport = httpx.ASGITransport(app=app)
    return httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {key}"}
    )


async def test_aggregate_by_model(tmp_path):
    app = create_app(make_config(tmp_path))
    app.state.ctx.provider = FakeProvider()
    async with _make_client(app) as client:
        for _ in range(2):
            await client.post(
                "/v1/llm",
                json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
            )
        await client.post(
            "/v1/llm", json={"model": "general-backup", "messages": [{"role": "user", "content": "x"}]}
        )
    rows = app.state.ctx.ledger.aggregate("model")
    by_model = {row["model"]: row for row in rows}
    assert by_model["general-primary"]["calls"] == 2
    assert by_model["general-primary"]["input_tokens"] == 22
    assert by_model["general-primary"]["output_tokens"] == 14
    assert by_model["general-primary"]["cost_usd"] == pytest.approx((22 * 1.0 + 14 * 4.0) / 1_000_000)
    assert by_model["general-backup"]["calls"] == 1
    assert by_model["general-backup"]["cost_usd"] == pytest.approx((11 * 0.8 + 7 * 3.2) / 1_000_000)


async def test_aggregate_by_tenant(tmp_path):
    config = make_config(tmp_path, auth_keys=(AUTH_KEY, "sk-tenant-b"))
    app = create_app(config)
    app.state.ctx.provider = FakeProvider()
    async with _make_client(app) as client_a:
        await client_a.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    async with _make_client(app, key="sk-tenant-b") as client_b:
        for _ in range(2):
            await client_b.post(
                "/v1/llm",
                json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
            )
    rows = app.state.ctx.ledger.aggregate("tenant")
    by_tenant = {row["tenant"]: row for row in rows}
    assert by_tenant[key_fingerprint(AUTH_KEY)]["calls"] == 1
    assert by_tenant[key_fingerprint("sk-tenant-b")]["calls"] == 2
    # 聚合输出只含 Key 指纹，不含原始 Key
    assert AUTH_KEY not in str(rows) and "sk-tenant-b" not in str(rows)


async def test_aggregate_by_prompt_version(tmp_path):
    app = create_app(make_config(tmp_path))
    app.state.ctx.provider = FakeProvider()
    async with _make_client(app) as client:
        for _ in range(2):
            await client.post(
                "/v1/llm",
                json={
                    "model": "general-primary",
                    "messages": [{"role": "user", "content": "x"}],
                    "prompt": {
                        "name": "knowledge_decision",
                        "version": "v1",
                        "variables": {"product_name": "测试助手"},
                    },
                },
            )
        # 无 Prompt 的调用不属于该聚合维度
        await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    rows = app.state.ctx.ledger.aggregate("prompt_version")
    assert len(rows) == 1
    assert rows[0]["prompt_name"] == "knowledge_decision"
    assert rows[0]["prompt_version"] == "v1"
    assert rows[0]["calls"] == 2


async def test_aggregate_ttft_only_over_stream_rows(tmp_path):
    app = create_app(make_config(tmp_path))
    app.state.ctx.provider = FakeProvider()
    async with _make_client(app) as client:
        await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
        await client.post(
            "/v1/llm/stream",
            json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
        )
    row = app.state.ctx.ledger.aggregate("model")[0]
    assert row["calls"] == 2
    assert row["avg_ttft_ms"] is not None and row["avg_ttft_ms"] >= 0
    assert row["total_latency_ms"] >= 0


async def test_aggregate_ttft_none_without_stream(tmp_path):
    app = create_app(make_config(tmp_path))
    app.state.ctx.provider = FakeProvider()
    async with _make_client(app) as client:
        await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
    row = app.state.ctx.ledger.aggregate("model")[0]
    assert row["calls"] == 1
    assert row["avg_ttft_ms"] is None  # 非流式调用没有首块时间，不参与 TTFT 平均


async def test_usage_stats_endpoint(client, fake):
    await client.post(
        "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    # 缺省维度为 model
    default_response = await client.get("/admin/usage/stats")
    assert default_response.status_code == 200
    assert default_response.json()["group_by"] == "model"
    response = await client.get("/admin/usage/stats", params={"group_by": "tenant"})
    assert response.status_code == 200
    body = response.json()
    assert body["group_by"] == "tenant"
    assert body["data"][0]["tenant"] == key_fingerprint(AUTH_KEY)
    assert body["data"][0]["calls"] == 1


async def test_usage_stats_invalid_group_by_400(client):
    response = await client.get("/admin/usage/stats", params={"group_by": "bogus"})
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "invalid_group_by"


async def test_usage_stats_empty_ledger(tmp_path):
    app = create_app(make_config(tmp_path))
    assert app.state.ctx.ledger.aggregate("model") == []
