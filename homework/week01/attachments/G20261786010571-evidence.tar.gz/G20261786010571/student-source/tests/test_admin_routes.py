"""P2 /admin/routes：熔断状态与路由配置的运营可视化快照。"""

import time


async def test_admin_routes_reports_all_models_closed(client, app):
    response = await client.get("/admin/routes")
    assert response.status_code == 200
    rows = {row["model"]: row for row in response.json()["data"]}
    assert set(rows) == {"general-primary", "general-backup"}

    primary = rows["general-primary"]
    # 默认全关：健康状态与静态路由配置一目了然
    assert primary["state"] == "closed"
    assert primary["consecutive_failures"] == 0
    assert primary["probe_in_flight"] is False
    assert primary["failure_threshold"] == 3
    assert primary["cooldown_remaining_seconds"] == 0.0
    assert primary["fallback"] == ["general-backup"]
    assert primary["supports_structured_output"] is True
    assert primary["supports_responses"] is True
    # 备用模型没有下一跳
    assert rows["general-backup"]["fallback"] == []


async def test_admin_routes_shows_open_breaker_with_cooldown(client, app):
    breaker = app.state.ctx.breakers["general-primary"]
    # 连续失败达阈值 3 次触发熔断
    for _ in range(3):
        breaker.record_failure()

    response = await client.get("/admin/routes", params={"model": "general-primary"})
    assert response.status_code == 200
    row = response.json()["data"][0]
    assert row["state"] == "open"
    assert row["consecutive_failures"] == 3
    # 冷却期刚开始：剩余时间应为正值且不超过总冷却时长
    assert 0 < row["cooldown_remaining_seconds"] <= row["cooldown_total_seconds"] == 30.0


async def test_admin_routes_snapshot_does_not_migrate_state(client, app):
    # 运营查询必须无副作用：冷却已过但未放行探测时，快照仍报 open（不触发半开迁移）
    breaker = app.state.ctx.breakers["general-primary"]
    for _ in range(3):
        breaker.record_failure()
    breaker.opened_at = time.monotonic() - 31.0  # 模拟冷却期已流逝

    response = await client.get("/admin/routes", params={"model": "general-primary"})
    row = response.json()["data"][0]
    assert row["state"] == "open"
    assert row["cooldown_remaining_seconds"] == 0.0
    # 真正的状态迁移只发生在放行请求时
    assert breaker.allow_request() is True
    assert breaker.state == "half_open"


async def test_admin_routes_unknown_model_404(client):
    response = await client.get("/admin/routes", params={"model": "ghost-model"})
    assert response.status_code == 404
    assert response.json()["detail"]["code"] == "unknown_model"
