"""鉴权、限流、健康检查、指标与审计持久化。"""

import hashlib

import httpx

from app.core.security import key_fingerprint
from app.main import create_app
from app.services.traces import TraceStore
from tests.conftest import AUTH_KEY, FakeProvider, make_config


async def test_no_key_401_on_all_endpoints(app):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        cases = [
            ("POST", "/v1/llm", {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}),
            ("GET", "/v1/traces", None),
            (
                "POST",
                "/v1/chat/completions",
                {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]},
            ),
            ("GET", "/v1/models", None),
            ("POST", "/v1/responses", {"model": "general-primary", "input": "x"}),
            ("GET", "/metrics", None),
        ]
        for method, path, payload in cases:
            response = await client.request(method, path, json=payload)
            assert response.status_code == 401, f"{method} {path} -> {response.status_code}"
            assert response.json()["error"]["code"] == "unauthorized"


async def test_wrong_key_rejected(app):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": "Bearer wrong-key"}
    ) as client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
        assert response.status_code == 401


def test_key_fingerprint_is_deterministic_and_does_not_leak_key():
    # 指纹 = sha256 前 16 位：稳定、不可逆、不含明文，仅用于审计关联
    first = key_fingerprint(AUTH_KEY)
    assert first == key_fingerprint(AUTH_KEY)
    assert len(first) == 16
    assert AUTH_KEY not in first
    assert first == hashlib.sha256(AUTH_KEY.encode("utf-8")).hexdigest()[:16]
    assert key_fingerprint("another-key") != first


async def test_healthz_open_without_key(app):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/healthz")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}


async def test_rate_limit_429(tmp_path):
    config = make_config(tmp_path, rate_limit_capacity=2.0, rate_limit_refill_per_second=0.0)
    app = create_app(config)
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        first = await client.post("/v1/llm", json=payload)
        second = await client.post("/v1/llm", json=payload)
        third = await client.post("/v1/llm", json=payload)
        assert first.status_code == 200
        assert second.status_code == 200
        assert third.status_code == 429
        assert third.json()["error"]["code"] == "rate_limit_exceeded"


async def test_metrics_traces_and_request_id(client, fake):
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "prompt": {"name": "knowledge_decision", "version": "v1", "variables": {"product_name": "测试"}},
        },
    )
    assert response.status_code == 200
    request_id = response.json()["request_id"]
    # X-Request-Id 响应头与响应体、审计记录的 request_id 一致
    assert response.headers.get("x-request-id") == request_id

    traces_response = await client.get("/v1/traces")
    assert traces_response.status_code == 200
    traces = traces_response.json()
    assert any(item["request_id"] == request_id and item["status"] == "success" for item in traces)
    assert all("content" not in item for item in traces)
    assert any(item["prompt_name"] == "knowledge_decision" for item in traces)

    metrics_response = await client.get("/metrics")
    assert metrics_response.status_code == 200
    assert "llm_requests_total" in metrics_response.text
    assert 'status="success"' in metrics_response.text


async def test_stream_trace_uses_same_request_id(client, fake):
    response = await client.post(
        "/v1/llm/stream",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "stream"}]},
    )
    assert response.status_code == 200
    assert response.headers.get("x-request-id")
    traces = (await client.get("/v1/traces")).json()
    stream_traces = [item for item in traces if item["actual_model"] == "general-primary"]
    assert len(stream_traces) == 1
    assert stream_traces[0]["status"] == "success"
    assert stream_traces[0]["request_id"]
    # 流式成功 trace 记录上游 include_usage 返回的 token 用量
    assert stream_traces[0]["input_tokens"] == 9
    assert stream_traces[0]["output_tokens"] == 4


async def test_traces_survive_restart(tmp_path):
    config = make_config(tmp_path)
    app = create_app(config)
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
        )
        assert response.status_code == 200
        request_id = response.json()["request_id"]
    # 模拟重启：用同一路径新建 TraceStore 读取历史审计
    traces = TraceStore(config.trace_file).list()
    assert len(traces) == 1
    assert traces[0].request_id == request_id
    assert traces[0].status == "success"
