"""P2 推理 token 分类：reasoning_tokens 提取入审计与账本，老库缺列自动迁移。"""

import sqlite3

from app.services.ledger import UsageLedger
from tests.conftest import FakeProvider


async def test_chat_non_stream_records_reasoning_tokens(client, app):
    app.state.ctx.provider = FakeProvider(reasoning_tokens=42)
    response = await client.post(
        "/v1/llm", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert response.status_code == 200
    trace = app.state.ctx.traces.list()[-1]
    assert trace.reasoning_tokens == 42
    row = app.state.ctx.ledger.recent()[0]
    assert row["reasoning_tokens"] == 42


async def test_chat_stream_records_reasoning_tokens(client, app):
    app.state.ctx.provider = FakeProvider(reasoning_tokens=7)
    response = await client.post(
        "/v1/llm/stream", json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert response.status_code == 200
    assert "response.completed" in response.text
    row = app.state.ctx.ledger.recent()[0]
    assert row["reasoning_tokens"] == 7
    assert row["stream"] == 1


async def test_responses_records_reasoning_tokens(client, app):
    app.state.ctx.provider = FakeProvider(reasoning_tokens=3)
    response = await client.post("/v1/responses", json={"model": "general-primary", "input": "hi"})
    assert response.status_code == 200
    row = app.state.ctx.ledger.recent()[0]
    assert row["reasoning_tokens"] == 3


def test_ledger_migrates_old_schema_without_column(tmp_path):
    # 模拟升级前的老账本：无 reasoning_tokens 列；initialize 后补列且读写正常
    db_path = tmp_path / "old.db"
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE usage_events (
                request_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
                api_key_hash TEXT, requested_model TEXT NOT NULL, actual_model TEXT,
                prompt_name TEXT, prompt_version TEXT, stream INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL, status_code INTEGER NOT NULL,
                input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL,
                cached_tokens INTEGER NOT NULL DEFAULT 0,
                cost_usd REAL NOT NULL, latency_ms INTEGER NOT NULL,
                first_token_ms INTEGER, attempts INTEGER NOT NULL, error_code TEXT
            )
            """
        )
        conn.execute(
            "INSERT INTO usage_events (request_id, created_at, requested_model, stream, status,"
            " status_code, input_tokens, output_tokens, cost_usd, latency_ms, attempts)"
            " VALUES ('old-1', '2026-01-01T00:00:00Z', 'general-primary', 0, 'success', 200, 1, 2, 0.0, 3, 1)"
        )

    ledger = UsageLedger(str(db_path))
    ledger.initialize()
    with sqlite3.connect(db_path) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(usage_events)")}
    assert "reasoning_tokens" in columns
    # 历史行回填默认值 0，新写入可携带 reasoning_tokens
    assert ledger.recent()[0]["reasoning_tokens"] == 0
