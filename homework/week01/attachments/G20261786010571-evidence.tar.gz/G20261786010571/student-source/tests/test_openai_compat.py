"""OpenAI 兼容入口：非流式、流式、错误格式与 OpenAI SDK 直连。"""

import httpx
import pytest
from openai import APIError, AsyncOpenAI

from app.errors import UpstreamTimeoutError
from tests.conftest import AUTH_KEY, FakeProvider


class FailingStreamProvider:
    """上游流式立即失败，用于验证流内错误事件编码。"""

    async def complete(self, config, messages, timeout_seconds, response_schema):
        raise UpstreamTimeoutError("upstream down")

    async def stream(self, config, messages, timeout_seconds):
        raise UpstreamTimeoutError("upstream down")
        yield  # pragma: no cover


async def test_non_stream_openai_format(client, fake):
    response = await client.post(
        "/v1/chat/completions",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["object"] == "chat.completion"
    assert body["id"].startswith("chatcmpl-")
    assert body["choices"][0]["message"]["content"] == "正常结果"
    assert body["choices"][0]["finish_reason"] == "stop"
    assert body["usage"]["prompt_tokens"] == 11
    assert body["usage"]["completion_tokens"] == 7
    assert body["request_id"]


async def test_stream_openai_format(client, fake):
    response = await client.post(
        "/v1/chat/completions",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "stream"}],
            "stream": True,
        },
    )
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert '"object": "chat.completion.chunk"' in response.text
    assert "data: [DONE]" in response.text


async def test_openai_error_format(client, fake):
    response = await client.post(
        "/v1/chat/completions",
        json={"model": "not-allowed", "messages": [{"role": "user", "content": "x"}]},
    )
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "unknown_model"
    assert body["error"]["type"] == "unknown_model"


async def test_openai_sdk_direct(app):
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test/v1") as http_client:
        client = AsyncOpenAI(base_url="http://test/v1", api_key=AUTH_KEY, http_client=http_client)
        completion = await client.chat.completions.create(
            model="general-primary", messages=[{"role": "user", "content": "hi"}]
        )
        assert completion.choices[0].message.content == "正常结果"
        assert completion.model == "general-primary"


async def test_openai_sdk_stream(app):
    app.state.ctx.provider = FakeProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test/v1") as http_client:
        client = AsyncOpenAI(base_url="http://test/v1", api_key=AUTH_KEY, http_client=http_client)
        stream = await client.chat.completions.create(
            model="general-primary", messages=[{"role": "user", "content": "hi"}], stream=True
        )
        chunks = [chunk async for chunk in stream]
        text = "".join(chunk.choices[0].delta.content or "" for chunk in chunks if chunk.choices)
        assert text == "第一块"


async def test_openai_stream_error_event(client, app):
    # 流式失败时发送 {"error": ...} 事件而非 finish_reason="error"，且不再发 [DONE]
    app.state.ctx.provider = FailingStreamProvider()
    response = await client.post(
        "/v1/chat/completions",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "x"}], "stream": True},
    )
    assert response.status_code == 200
    assert '"error"' in response.text
    assert "upstream_stream_failed" in response.text
    assert 'finish_reason": "error"' not in response.text
    assert "data: [DONE]" not in response.text


async def test_openai_sdk_raises_on_stream_error(app):
    # SDK 客户端解析到 error 事件时应抛出 APIError，而不是静默结束
    app.state.ctx.provider = FailingStreamProvider()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test/v1") as http_client:
        client = AsyncOpenAI(base_url="http://test/v1", api_key=AUTH_KEY, http_client=http_client)
        stream = await client.chat.completions.create(
            model="general-primary", messages=[{"role": "user", "content": "hi"}], stream=True
        )
        with pytest.raises(APIError):
            async for _ in stream:
                pass


async def test_list_models_exposes_only_allowlist(client):
    # /v1/models 只暴露白名单模型名，不泄漏上游真实 provider_model
    response = await client.get("/v1/models")
    assert response.status_code == 200
    body = response.json()
    assert body["object"] == "list"
    ids = {item["id"] for item in body["data"]}
    assert ids == {"general-primary", "general-backup"}
    assert all(item["object"] == "model" for item in body["data"])
