"""Prompt 资产管理：CRUD、整数版本、激活切换、Jinja2 沙箱渲染与请求链路集成。"""

import httpx

from app.main import create_app
from tests.conftest import AUTH_KEY, make_config


async def test_prompt_create_and_get(client, app):
    response = await client.post(
        "/v1/prompts",
        json={"id": "qa", "content": "你是{{product}}的知识库助手。", "description": "客服问答"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["id"] == "qa"
    assert body["version"] == 1
    assert body["active"] is True

    got = await client.get("/v1/prompts/qa")
    assert got.status_code == 200
    assert got.json()["content"] == "你是{{product}}的知识库助手。"
    assert got.json()["version"] == 1

    listed = await client.get("/v1/prompts")
    assert listed.status_code == 200
    items = listed.json()["data"]
    assert len(items) == 1
    assert items[0]["id"] == "qa"
    assert "content" not in items[0]


async def test_prompt_version_activation(client):
    await client.post("/v1/prompts", json={"id": "qa", "content": "版本一 {{x}}"})
    await client.post("/v1/prompts", json={"id": "qa", "content": "版本二 {{x}}"})
    # 缺省取激活版本（最新）
    active = await client.get("/v1/prompts/qa")
    assert active.json()["version"] == 2
    assert active.json()["content"] == "版本二 {{x}}"
    # 显式指定旧版本仍可取
    old = await client.get("/v1/prompts/qa", params={"version": 1})
    assert old.status_code == 200
    assert old.json()["content"] == "版本一 {{x}}"
    # 激活版本唯一
    listed = (await client.get("/v1/prompts")).json()["data"]
    assert [item["active"] for item in listed] == [0, 1]


async def test_prompt_render_endpoint(client):
    await client.post("/v1/prompts", json={"id": "qa", "content": "你是{{product}}助手"})
    response = await client.post("/v1/prompts/qa/render", json={"variables": {"product": "客服"}})
    assert response.status_code == 200
    assert response.json()["rendered"] == "你是客服助手"


async def test_missing_variable_fails_on_render(client):
    await client.post("/v1/prompts", json={"id": "qa", "content": "你好{{name}}"})
    response = await client.post("/v1/prompts/qa/render", json={"variables": {}})
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "missing_prompt_variable"


async def test_sandbox_blocks_attribute_probing(client):
    # 沙箱禁止属性探测与任意对象访问，模板注入不可读进程环境
    await client.post("/v1/prompts", json={"id": "evil", "content": "{{ ''.__class__.__mro__ }}"})
    response = await client.post("/v1/prompts/evil/render", json={"variables": {}})
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "invalid_prompt_template"


async def test_request_uses_db_prompt(client, fake):
    await client.post(
        "/v1/prompts", json={"id": "qa", "content": "你是{{product}}的决策器。资料不足时搜索。"}
    )
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "prompt": {"name": "qa", "version": "1", "variables": {"product": "报销"}},
        },
    )
    assert response.status_code == 200
    # 系统消息由 SQLite 资产库渲染并注入调用上下文
    assert fake.last_messages[0].role == "system"
    assert fake.last_messages[0].content == "你是报销的决策器。资料不足时搜索。"


async def test_db_prompt_takes_precedence_over_yaml(client, fake):
    # 同名字段同时存在于 SQLite 与 YAML 时，资产库优先（升级后的资产是权威）
    await client.post(
        "/v1/prompts", json={"id": "knowledge_decision", "content": "数据库版本{{product_name}}"}
    )
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "prompt": {"name": "knowledge_decision", "version": "v1", "variables": {"product_name": "测试"}},
        },
    )
    assert response.status_code == 200
    assert fake.last_messages[0].content == "数据库版本测试"


async def test_prompt_store_survives_restart(tmp_path):
    config = make_config(tmp_path)
    app = create_app(config)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/prompts", json={"id": "qa", "content": "你好{{name}}"})
        assert response.status_code == 200
    # 模拟重启：同一数据库文件重建应用后资产仍在
    app2 = create_app(config)
    rows = app2.state.ctx.prompt_store.list_all()
    assert len(rows) == 1
    assert rows[0]["id"] == "qa"
