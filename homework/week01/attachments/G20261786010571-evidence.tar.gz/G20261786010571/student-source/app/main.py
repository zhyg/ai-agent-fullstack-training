"""应用装配入口：加载配置、组装中间件与路由。

中间件顺序（由外到内）：HttpMetrics → ApiKey → RateLimit，
保证鉴权先于限流、指标覆盖全部请求（含 401/429）。
"""

import logging

from fastapi import FastAPI

from app.api import openai as openai_routes
from app.api import routes
from app.config import GatewayConfig, load_config
from app.context import GatewayContext
from app.core.circuit_breaker import CircuitBreaker
from app.core.metrics import HttpMetricsMiddleware, MetricsRegistry
from app.core.rate_limit import RateLimiter, RateLimitMiddleware
from app.core.security import ApiKeyMiddleware
from app.services.ledger import UsageLedger
from app.services.prompt_store import PromptStore
from app.services.provider import OpenAICompatibleProvider
from app.services.traces import TraceStore

logging.basicConfig(level=logging.INFO)


def create_app(config: GatewayConfig | None = None) -> FastAPI:
    config = config or load_config()
    ledger = UsageLedger(config.database_path)
    ledger.initialize()
    prompt_store = PromptStore(config.database_path)
    prompt_store.initialize()
    ctx = GatewayContext(
        config=config,
        provider=OpenAICompatibleProvider(),
        traces=TraceStore(config.trace_file),
        ledger=ledger,
        prompt_store=prompt_store,
        metrics=MetricsRegistry(),
        breakers={
            name: CircuitBreaker(
                model.circuit_breaker.failure_threshold, model.circuit_breaker.cooldown_seconds
            )
            for name, model in config.models.items()
        },
        model_limiters={
            name: RateLimiter(model.rate_limit.capacity, model.rate_limit.refill_per_second)
            for name, model in config.models.items()
            if model.rate_limit is not None
        },
        limiter=RateLimiter(config.rate_limit_capacity, config.rate_limit_refill_per_second),
    )
    app = FastAPI(title="Agent LLM Gateway", version="1.0.0")
    app.state.ctx = ctx
    app.add_middleware(RateLimitMiddleware, limiter=ctx.limiter)
    app.add_middleware(ApiKeyMiddleware, keys=frozenset(config.auth_keys), enabled=config.auth_enabled)
    app.add_middleware(HttpMetricsMiddleware, metrics=ctx.metrics)
    app.include_router(routes.router)
    app.include_router(openai_routes.router)
    return app


app = create_app()
