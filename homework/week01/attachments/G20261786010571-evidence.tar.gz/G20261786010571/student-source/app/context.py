"""运行期上下文：把配置、Provider、存储与治理组件装配到一起。"""

from dataclasses import dataclass

from app.config import GatewayConfig
from app.core.circuit_breaker import CircuitBreaker
from app.core.metrics import MetricsRegistry
from app.core.rate_limit import RateLimiter
from app.services.ledger import UsageLedger
from app.services.prompt_store import PromptStore
from app.services.provider import Provider
from app.services.traces import TraceStore


@dataclass
class GatewayContext:
    config: GatewayConfig
    provider: Provider
    traces: TraceStore
    ledger: UsageLedger
    prompt_store: PromptStore
    metrics: MetricsRegistry
    breakers: dict[str, CircuitBreaker]
    model_limiters: dict[str, RateLimiter]
    limiter: RateLimiter
