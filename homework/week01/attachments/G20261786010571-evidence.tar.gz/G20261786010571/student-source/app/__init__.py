"""mini-llm-gateway 应用包。"""
