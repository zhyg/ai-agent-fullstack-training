"""按模型维度的熔断器：连续失败达阈值打开，冷却期后放行半开探测，成功即恢复。"""

import time
from typing import Any, Literal

State = Literal["closed", "open", "half_open"]


class CircuitBreaker:
    def __init__(self, failure_threshold: int, cooldown_seconds: float) -> None:
        self.failure_threshold = failure_threshold
        self.cooldown_seconds = cooldown_seconds
        self.state: State = "closed"
        self.consecutive_failures = 0
        self.opened_at: float | None = None
        self.probe_in_flight = False

    def allow_request(self) -> bool:
        if self.state == "closed":
            return True
        if self.state == "open":
            if self.opened_at is None:
                return True
            if time.monotonic() - self.opened_at >= self.cooldown_seconds:
                self.state = "half_open"
            else:
                return False
        # half_open：同一时刻只放行一个探测请求，避免并发探测风暴
        if self.probe_in_flight:
            return False
        self.probe_in_flight = True
        return True

    def record_failure(self) -> None:
        self.probe_in_flight = False
        if self.state == "half_open":
            self.state = "open"
            self.opened_at = time.monotonic()
            self.consecutive_failures = 1
            return
        self.consecutive_failures += 1
        if self.consecutive_failures >= self.failure_threshold:
            self.state = "open"
            self.opened_at = time.monotonic()

    def record_success(self) -> None:
        self.state = "closed"
        self.consecutive_failures = 0
        self.opened_at = None
        self.probe_in_flight = False

    def release_probe(self) -> None:
        """探测以不可重试错误结束时，仅释放探测占位，不计入失败。"""
        self.probe_in_flight = False

    def snapshot(self) -> dict[str, Any]:
        """运营只读快照：不迁移状态（open→half_open 的转换仍只发生在 allow_request）。"""
        cooldown_remaining = 0.0
        if self.state == "open" and self.opened_at is not None:
            cooldown_remaining = max(0.0, self.cooldown_seconds - (time.monotonic() - self.opened_at))
        return {
            "state": self.state,
            "consecutive_failures": self.consecutive_failures,
            "failure_threshold": self.failure_threshold,
            "probe_in_flight": self.probe_in_flight,
            "cooldown_total_seconds": self.cooldown_seconds,
            "cooldown_remaining_seconds": round(cooldown_remaining, 2),
        }
