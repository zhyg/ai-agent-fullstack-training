"""按 API Key 维度的令牌桶限流，超限返回 429 + OpenAI 兼容错误体。"""

import threading
import time

from starlette.responses import JSONResponse

from app.core.security import OPEN_PATHS, extract_api_key


class TokenBucket:
    def __init__(self, capacity: float, refill_per_second: float) -> None:
        self.capacity = capacity
        self.refill = refill_per_second
        self.tokens = capacity
        self.updated = time.monotonic()

    def try_consume(self, amount: float = 1.0) -> bool:
        now = time.monotonic()
        self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.refill)
        self.updated = now
        if self.tokens >= amount:
            self.tokens -= amount
            return True
        return False


class RateLimiter:
    def __init__(self, capacity: float, refill_per_second: float) -> None:
        self.capacity = capacity
        self.refill = refill_per_second
        self._buckets: dict[str, TokenBucket] = {}
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                bucket = self._buckets[key] = TokenBucket(self.capacity, self.refill)
        return bucket.try_consume()


class RateLimitMiddleware:
    def __init__(self, app, limiter: RateLimiter) -> None:
        self.app = app
        self.limiter = limiter

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http" or scope.get("path") in OPEN_PATHS:
            await self.app(scope, receive, send)
            return
        key = extract_api_key(scope.get("headers") or [])
        if key and not self.limiter.allow(key):
            response = JSONResponse(
                {
                    "error": {
                        "message": "请求过于频繁",
                        "type": "rate_limit_exceeded",
                        "code": "rate_limit_exceeded",
                    }
                },
                status_code=429,
                headers={"Retry-After": "1"},
            )
            await response(scope, receive, send)
            return
        await self.app(scope, receive, send)
