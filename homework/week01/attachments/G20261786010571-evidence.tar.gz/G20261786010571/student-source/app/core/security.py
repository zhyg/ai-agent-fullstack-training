"""网关自身 API Key 鉴权：除 /healthz 外所有端点均需有效 Key，无 Key 返回 401。

Key 比较使用 hmac.compare_digest 恒定时间比较，避免时序侧信道；
通过指纹（sha256 前 16 位）入审计账本，账本不落原始 Key。
"""

import hashlib
import hmac

from starlette.responses import JSONResponse

OPEN_PATHS = frozenset({"/healthz"})


def key_fingerprint(api_key: str) -> str:
    # 指纹不可逆，仅供审计关联同一调用方，不用于鉴权比较。
    return hashlib.sha256(api_key.encode("utf-8")).hexdigest()[:16]


def extract_api_key(headers: list[tuple[bytes, bytes]]) -> str | None:
    # 优先 Bearer；Authorization 存在但格式非法时，继续回退检查 x-api-key
    for name, value in headers:
        if name.lower() == b"authorization":
            text = value.decode("latin-1")
            if text.lower().startswith("bearer "):
                return text[7:].strip()
    for name, value in headers:
        if name.lower() == b"x-api-key":
            return value.decode("latin-1").strip()
    return None


class ApiKeyMiddleware:
    def __init__(self, app, keys: frozenset[str], enabled: bool = True) -> None:
        self.app = app
        self.keys = keys
        self.enabled = enabled

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http" or not self.enabled or scope.get("path") in OPEN_PATHS:
            await self.app(scope, receive, send)
            return
        key = extract_api_key(scope.get("headers") or [])
        if key and any(hmac.compare_digest(key, known) for known in self.keys):
            scope.setdefault("state", {})["api_key_hash"] = key_fingerprint(key)
            await self.app(scope, receive, send)
            return
        response = JSONResponse(
            {"error": {"message": "未提供有效 API Key", "type": "unauthorized", "code": "unauthorized"}},
            status_code=401,
        )
        await response(scope, receive, send)
