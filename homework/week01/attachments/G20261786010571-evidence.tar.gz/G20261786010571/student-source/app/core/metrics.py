"""Prometheus 文本格式指标：LLM 请求数、延迟直方图、Token 用量与 HTTP 请求数。"""

from collections import Counter
from uuid import uuid4

LATENCY_BUCKETS = (0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0)


class MetricsRegistry:
    def __init__(self) -> None:
        self.requests: Counter[tuple[str, str]] = Counter()
        self.tokens: Counter[tuple[str, str]] = Counter()
        self.http: Counter[tuple[str, str, str]] = Counter()
        # 直方图按累计桶计数维护：O(1) 记录、内存有界，不随调用次数增长
        self.latency_buckets = [0] * len(LATENCY_BUCKETS)
        self.latency_sum = 0.0
        self.latency_count = 0

    def record_llm(
        self,
        model: str,
        status: str,
        latency_seconds: float,
        input_tokens: int,
        output_tokens: int,
    ) -> None:
        self.requests[(model, status)] += 1
        self.tokens[("input", model)] += input_tokens
        self.tokens[("output", model)] += output_tokens
        for index, upper in enumerate(LATENCY_BUCKETS):
            if latency_seconds <= upper:
                self.latency_buckets[index] += 1
        self.latency_sum += latency_seconds
        self.latency_count += 1

    def record_http(self, method: str, path: str, status: int) -> None:
        self.http[(method, path, str(status))] += 1

    def render(self) -> str:
        lines = [
            "# HELP llm_requests_total 网关处理的 LLM 请求总数",
            "# TYPE llm_requests_total counter",
        ]
        for (model, status), count in sorted(self.requests.items()):
            lines.append(f'llm_requests_total{{model="{model}",status="{status}"}} {count}')
        lines += [
            "# HELP llm_tokens_total LLM 输入输出 Token 总数",
            "# TYPE llm_tokens_total counter",
        ]
        for (direction, model), count in sorted(self.tokens.items()):
            lines.append(f'llm_tokens_total{{model="{model}",direction="{direction}"}} {count}')
        lines += [
            "# HELP llm_latency_seconds LLM 调用耗时（秒）",
            "# TYPE llm_latency_seconds histogram",
        ]
        for bucket, count in zip(LATENCY_BUCKETS, self.latency_buckets, strict=True):
            lines.append(f'llm_latency_seconds_bucket{{le="{bucket}"}} {count}')
        lines.append(f'llm_latency_seconds_bucket{{le="+Inf"}} {self.latency_count}')
        lines.append(f"llm_latency_seconds_sum {self.latency_sum:.6f}")
        lines.append(f"llm_latency_seconds_count {self.latency_count}")
        lines += [
            "# HELP http_requests_total HTTP 请求总数",
            "# TYPE http_requests_total counter",
        ]
        for (method, path, status), count in sorted(self.http.items()):
            lines.append(f'http_requests_total{{method="{method}",path="{path}",status="{status}"}} {count}')
        return "\n".join(lines) + "\n"


class HttpMetricsMiddleware:
    """最外层中间件：统计全部 HTTP 请求，生成 request_id 并写入 X-Request-Id 响应头。

    request_id 同时写入 scope["state"]，业务层复用同一 ID 写入响应体与审计记录，
    保证响应头、响应体、审计三者一致。
    """

    def __init__(self, app, metrics: MetricsRegistry) -> None:
        self.app = app
        self.metrics = metrics

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        request_id = uuid4().hex
        scope.setdefault("state", {})["request_id"] = request_id
        status_holder: dict[str, int] = {}

        async def send_wrapper(message) -> None:
            if message["type"] == "http.response.start":
                status_holder["status"] = message["status"]
                headers = message.setdefault("headers", [])
                headers.append((b"x-request-id", request_id.encode("ascii")))
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            path = scope.get("path", "")
            if path != "/metrics":
                self.metrics.record_http(scope.get("method", ""), path, status_holder.get("status", 500))
