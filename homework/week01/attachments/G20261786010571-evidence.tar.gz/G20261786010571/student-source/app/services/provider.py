"""供应商 Adapter：业务流程只依赖本协议，不依赖具体 SDK。"""

import json
import os
from collections.abc import AsyncIterator
from typing import Any, Protocol

from openai import APIConnectionError, APITimeoutError, AsyncOpenAI, RateLimitError

from app.config import ModelConfig
from app.errors import (
    GatewayError,
    ProviderError,
    UpstreamConnectionError,
    UpstreamRateLimitedError,
    UpstreamTimeoutError,
)
from app.schemas import Message, Usage


def normalize_upstream_error(exc: Exception) -> ProviderError:
    """把供应商 SDK 异常归一化为网关自有异常类型（gateway 只判自有类型）。

    按 SDK 继承关系从具体到一般匹配：限流 → 超时 → 连接；其余（BadRequest、
    InternalServer、未知异常等）归入不可重试的通用传输错误。
    """
    if isinstance(exc, RateLimitError):
        return UpstreamRateLimitedError("上游限流（rate limit）")
    if isinstance(exc, APITimeoutError):
        return UpstreamTimeoutError("上游请求超时")
    if isinstance(exc, APIConnectionError):
        return UpstreamConnectionError("上游连接失败")
    return ProviderError(f"上游调用失败：{type(exc).__name__}")


def _cached_tokens(usage: Any) -> int:
    # 提取提示词缓存命中 token 数；老上游不带 details 时按 0 计。
    details = getattr(usage, "prompt_tokens_details", None) if usage else None
    cached = getattr(details, "cached_tokens", None)
    return int(cached or 0)


def _reasoning_tokens(usage: Any) -> int:
    # 提取推理模型思维链 token 数（completion_tokens_details）；老上游不带 details 时按 0 计。
    details = getattr(usage, "completion_tokens_details", None) if usage else None
    reasoning = getattr(details, "reasoning_tokens", None)
    return int(reasoning or 0)


def _responses_usage(raw: Any) -> Usage:
    # Responses API 用量结构：usage.input_tokens_details.cached_tokens。
    if not raw:
        return Usage(input_tokens=0, output_tokens=0)
    details = raw.get("input_tokens_details") or {}
    output_details = raw.get("output_tokens_details") or {}
    return Usage(
        input_tokens=int(raw.get("input_tokens") or 0),
        output_tokens=int(raw.get("output_tokens") or 0),
        cached_tokens=int(details.get("cached_tokens") or 0),
        reasoning_tokens=int(output_details.get("reasoning_tokens") or 0),
    )


class Provider(Protocol):
    async def complete(
        self,
        config: ModelConfig,
        messages: list[Message],
        timeout_seconds: float,
        response_schema: dict[str, Any] | None,
    ) -> tuple[str, Usage]: ...

    async def stream(
        self,
        config: ModelConfig,
        messages: list[Message],
        timeout_seconds: float,
    ) -> AsyncIterator[tuple[str, Usage | None]]: ...

    async def responses(
        self, config: ModelConfig, input_data: Any, timeout_seconds: float
    ) -> tuple[dict[str, Any], Usage]: ...

    async def responses_stream(
        self, config: ModelConfig, input_data: Any, timeout_seconds: float
    ) -> AsyncIterator[tuple[str, dict[str, Any], Usage | None]]: ...


class OpenAICompatibleProvider:
    # 实现 OpenAI Compatible Adapter，集中处理供应商协议与认证细节。
    # API Key 只保留在 Gateway 进程内，调用方无需接触供应商密钥。
    def __init__(self) -> None:
        # 按 base_url + key 复用客户端连接池，避免每次调用重建
        self._clients: dict[tuple[str, str], AsyncOpenAI] = {}

    def create_client(self, config: ModelConfig) -> AsyncOpenAI:
        api_key = os.getenv(config.api_key_env)
        if not api_key:
            raise GatewayError("gateway_misconfigured", "Gateway 模型凭据未配置", 503)
        cache_key = (config.base_url, api_key)
        client = self._clients.get(cache_key)
        if client is None:
            client = self._clients[cache_key] = AsyncOpenAI(
                api_key=api_key, base_url=config.base_url, max_retries=0
            )
        return client

    async def complete(
        self,
        config: ModelConfig,
        messages: list[Message],
        timeout_seconds: float,
        response_schema: dict[str, Any] | None,
    ) -> tuple[str, Usage]:
        # 将统一请求转换为 OpenAI Compatible 调用，隔离厂商协议差异。
        request_data: dict[str, Any] = {
            "model": config.provider_model,
            "messages": [message.model_dump() for message in messages],
            "timeout": timeout_seconds,
        }
        if response_schema is not None:
            if config.structured_output_mode == "json_schema":
                request_data["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "agent_response",
                        "strict": True,
                        "schema": response_schema,
                    },
                }
            else:
                request_data["response_format"] = {"type": "json_object"}
                request_data["messages"] = [
                    {
                        "role": "system",
                        "content": (
                            "只返回一个合法 JSON 对象，必须严格符合下列 JSON Schema，"
                            "不要返回 Markdown 或额外文字："
                            f"{json.dumps(response_schema, ensure_ascii=False)}"
                        ),
                    },
                    *request_data["messages"],
                ]
        client = self.create_client(config)  # 凭据缺失等确定性错误（GatewayError）原样抛出
        try:
            completion = await client.chat.completions.create(**request_data)
        except Exception as exc:
            raise normalize_upstream_error(exc) from exc
        content = completion.choices[0].message.content or ""
        usage = completion.usage
        return content, Usage(
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
            cached_tokens=_cached_tokens(usage),
            reasoning_tokens=_reasoning_tokens(usage),
        )

    async def stream(
        self,
        config: ModelConfig,
        messages: list[Message],
        timeout_seconds: float,
    ) -> AsyncIterator[tuple[str, Usage | None]]:
        # 逐块读取上游响应；开启 include_usage 让最终块携带 token 用量用于审计。
        client = self.create_client(config)
        try:
            response = await client.chat.completions.create(
                model=config.provider_model,
                messages=[message.model_dump() for message in messages],
                stream=True,
                stream_options={"include_usage": True},
                timeout=timeout_seconds,
            )
        except Exception as exc:
            raise normalize_upstream_error(exc) from exc
        usage: Usage | None = None
        try:
            async for chunk in response:
                if chunk.usage is not None:
                    usage = Usage(
                        input_tokens=chunk.usage.prompt_tokens,
                        output_tokens=chunk.usage.completion_tokens,
                        cached_tokens=_cached_tokens(chunk.usage),
                        reasoning_tokens=_reasoning_tokens(chunk.usage),
                    )
                choice = chunk.choices[0] if chunk.choices else None
                if choice and choice.delta.content:
                    yield choice.delta.content, usage
            if usage is not None:
                # 上游未在内容块中附带用量时，补发一个仅携带用量的结束块
                yield "", usage
        except Exception as exc:
            # 流中途的 SDK 异常同样归一化（如首块后的超时/断连）
            raise normalize_upstream_error(exc) from exc
        finally:
            # 客户端提前断开时也要释放上游连接，避免白烧 token
            await response.close()

    async def responses(
        self, config: ModelConfig, input_data: Any, timeout_seconds: float
    ) -> tuple[dict[str, Any], Usage]:
        # Responses API 透传：上游响应原样回传，仅抽取用量入审计。
        client = self.create_client(config)
        try:
            response = await client.responses.create(
                model=config.provider_model, input=input_data, timeout=timeout_seconds
            )
        except Exception as exc:
            raise normalize_upstream_error(exc) from exc
        payload = response.model_dump(exclude_unset=True)
        return payload, _responses_usage(payload.get("usage"))

    async def responses_stream(
        self, config: ModelConfig, input_data: Any, timeout_seconds: float
    ) -> AsyncIterator[tuple[str, dict[str, Any], Usage | None]]:
        # 事件透传：(event_type, payload, usage)；usage 随 response.completed 事件附带。
        client = self.create_client(config)
        try:
            stream = await client.responses.create(
                model=config.provider_model, input=input_data, stream=True, timeout=timeout_seconds
            )
        except Exception as exc:
            raise normalize_upstream_error(exc) from exc
        usage: Usage | None = None
        try:
            async for event in stream:
                payload = event.model_dump(exclude_unset=True)
                if event.type == "response.completed":
                    usage = _responses_usage(payload.get("response", {}).get("usage"))
                yield event.type, payload, usage
        except Exception as exc:
            # 流中途的 SDK 异常同样归一化
            raise normalize_upstream_error(exc) from exc
        finally:
            await stream.close()
