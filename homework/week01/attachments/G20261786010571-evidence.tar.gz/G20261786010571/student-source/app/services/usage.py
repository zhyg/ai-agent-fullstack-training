"""按模型价格与 Token 用量计算调用成本。"""

from app.config import ModelConfig
from app.schemas import Usage


def calculate_cost(config: ModelConfig, usage: Usage) -> float:
    return (usage.input_tokens * config.price_input + usage.output_tokens * config.price_output) / 1_000_000
