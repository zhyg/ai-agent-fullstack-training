"""网关核心业务流程：fallback 链、指数退避重试、熔断、结构化校验、统一审计。

流式事件约定：generator 产出 (kind, payload) 二元组，kind ∈ {delta, completed, failed}；
delta 的 payload 为增量文本，completed 的 payload 为 {"model", "usage"} 字典，
failed 的 payload 为错误码。由 API 层编码为 SSE 或 OpenAI chunk 格式，保证业务与协议解耦。
"""

import asyncio
import json
import logging
import random
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import Any
from uuid import uuid4

from jsonschema import ValidationError as JsonSchemaError
from jsonschema import validate

from app.config import GatewayConfig, ModelConfig
from app.context import GatewayContext
from app.errors import GatewayError, ProviderError
from app.schemas import CallTrace, LLMRequest, LLMResponse, Message, OpenAIResponsesRequest, Usage
from app.services.prompts import build_messages
from app.services.traces import build_trace

logger = logging.getLogger("llm_gateway")

_REPAIRABLE_CODES = frozenset({"invalid_json", "schema_validation_failed"})
DisconnectCheck = Callable[[], Awaitable[bool]]


def is_retryable(exc: Exception) -> bool:
    # 只判网关自有异常类型：供应商 SDK 异常已在 Provider 适配层归一化为 ProviderError。
    return isinstance(exc, ProviderError) and exc.retryable


def _error_code(exc: Exception) -> str:
    # 归一化为稳定错误码，供 Trace.routing_reason 记录首次切换原因。
    if isinstance(exc, GatewayError):
        return exc.code
    if isinstance(exc, ProviderError):
        return exc.code
    return "transport_error"


def repair_messages(messages: list[Message], failed_content: str, exc: GatewayError) -> list[Message]:
    # 把失败输出与校验错误喂回同一模型：只要求重产 JSON，不允许模型带偏话题。
    detail = exc.detail or exc.message
    return [
        *messages,
        Message(role="assistant", content=failed_content),
        Message(
            role="user",
            content=(
                "你上一次输出未通过 JSON Schema 校验，请重新生成：只输出一个符合校验要求的 "
                f"JSON 对象，不要输出 Markdown、解释或多余文字。\n校验错误：{detail}"
            ),
        ),
    ]


def fallback_chain(requested: str, config: GatewayConfig) -> list[str]:
    chain = [requested]
    model = config.models.get(requested)
    if model is not None:
        chain.extend(model.fallback)
    return list(dict.fromkeys(chain))


def backoff_delay(attempt: int, config: ModelConfig) -> float:
    retry = config.retry
    return retry.backoff_base * (2**attempt) + random.uniform(0, retry.jitter)


def record_trace(ctx: GatewayContext, trace: CallTrace) -> None:
    ctx.traces.append(trace)
    ctx.ledger.record(trace)
    ctx.metrics.record_llm(
        model=trace.requested_model,
        status=trace.status,
        latency_seconds=trace.latency_ms / 1000,
        input_tokens=trace.input_tokens,
        output_tokens=trace.output_tokens,
    )
    logger.info("llm_call_trace=%s", trace.model_dump_json())


def _empty_usage() -> Usage:
    return Usage(input_tokens=0, output_tokens=0)


def enforce_model_quota(
    ctx: GatewayContext,
    model_name: str,
    trace_request: LLMRequest,
    request_id: str | None,
    api_key_hash: str | None,
) -> None:
    # 模型级配额：超限直接 429，不切备用（避免把过载传导给备用模型）。
    limiter = ctx.model_limiters.get(model_name)
    if limiter is None or limiter.allow(model_name):
        return
    record_trace(
        ctx,
        build_trace(
            trace_request,
            request_id,
            None,
            _empty_usage(),
            time.perf_counter(),
            0,
            "failed",
            error_code="rate_limit_exceeded",
            status_code=429,
            api_key_hash=api_key_hash,
            model_config=ctx.config.models.get(model_name),
        ),
    )
    raise GatewayError("rate_limit_exceeded", f"模型 {model_name} 请求过于频繁", 429)


def _budget_exhausted(budget: int) -> GatewayError:
    # Run 级总预算：重试、自修复与备用切换消耗同一个计数，超限直接终态。
    return GatewayError(
        "run_budget_exhausted",
        f"Run 预算耗尽：单次请求最多 {budget} 次上游尝试（重试/修复/切换共用）",
        502,
    )


def validate_entry(model_name: str, request: LLMRequest, ctx: GatewayContext) -> ModelConfig | GatewayError:
    # 校验模型白名单与结构化输出能力；返回配置或可安全跳过的错误。
    model_config = ctx.config.models.get(model_name)
    if model_config is None:
        return GatewayError("unknown_model", "模型不在 Gateway 允许列表中", 400)
    if request.response_schema is not None and not model_config.supports_structured_output:
        return GatewayError("structured_output_unsupported", "模型不支持 Structured Output", 400)
    return model_config


async def call_with_fallback(
    request: LLMRequest, ctx: GatewayContext, request_id: str | None = None, api_key_hash: str | None = None
) -> LLMResponse:
    # request_id 由 HTTP 中间件生成并透传，保证响应头、响应体与审计三者一致。
    requested_model = request.model
    request_id = request_id or str(uuid4())
    started = time.perf_counter()
    attempts = 0
    last_error: Exception | None = None
    routing_reason: str | None = None
    messages = build_messages(request, ctx.config.prompts, ctx.prompt_store)
    for model_name in fallback_chain(requested_model, ctx.config):
        # Run 预算在模型循环入口也检查：避免剩余模型徒耗熔断半开探测等副作用
        if attempts >= ctx.config.run_budget:
            last_error = _budget_exhausted(ctx.config.run_budget)
            break
        if model_name != requested_model and routing_reason is None and last_error is not None:
            # 首次切换备用模型：记录触发切换的错误码作为路由理由
            routing_reason = _error_code(last_error)
        entry = validate_entry(model_name, request, ctx)
        if isinstance(entry, GatewayError):
            if model_name == requested_model:
                raise entry
            last_error = entry
            continue
        model_config: ModelConfig = entry
        if model_name != requested_model:
            enforce_model_quota(ctx, model_name, request, request_id, api_key_hash)
        breaker = ctx.breakers.get(model_name)
        if breaker is not None and not breaker.allow_request():
            last_error = GatewayError("circuit_open", f"模型 {model_name} 处于熔断状态", 503)
            continue
        transport_attempt = 0
        repair_used = 0
        while True:
            # 重试、自修复与备用切换共用同一个 Run 预算，超限直接终态
            if attempts >= ctx.config.run_budget:
                last_error = _budget_exhausted(ctx.config.run_budget)
                break
            attempts += 1
            content: str | None = None
            try:
                content, usage = await ctx.provider.complete(
                    model_config, messages, request.timeout_seconds, request.response_schema
                )
                parsed: dict[str, Any] | list[Any] | None = None
                if request.response_schema is not None:
                    try:
                        parsed = json.loads(content)
                        validate(instance=parsed, schema=request.response_schema)
                    except json.JSONDecodeError as exc:
                        raise GatewayError("invalid_json", "模型没有返回合法 JSON", detail=str(exc)) from exc
                    except JsonSchemaError as exc:
                        raise GatewayError(
                            "schema_validation_failed", "模型结果不符合 response_schema", detail=exc.message
                        ) from exc
                if breaker is not None:
                    breaker.record_success()
                record_trace(
                    ctx,
                    build_trace(
                        request,
                        request_id,
                        model_name,
                        usage,
                        started,
                        attempts,
                        "success",
                        routing_reason=routing_reason,
                        model_config=model_config,
                        api_key_hash=api_key_hash,
                    ),
                )
                return LLMResponse(
                    request_id=request_id,
                    model=model_name,
                    content=content,
                    parsed=parsed,
                    usage=usage,
                    latency_ms=int((time.perf_counter() - started) * 1000),
                    attempts=attempts,
                )
            except GatewayError as exc:
                # 结构化校验/凭据缺失等确定性错误：不重试，直接切换下一个备用模型
                last_error = exc
                if breaker is not None:
                    breaker.release_probe()
                if (
                    content is not None
                    and request.response_schema is not None
                    and exc.code in _REPAIRABLE_CODES
                    and repair_used < ctx.config.structured_output_repair_attempts
                ):
                    # 校验失败是确定性结果问题：把错误喂回同一模型重试，不消耗传输重试预算
                    repair_used += 1
                    messages = repair_messages(messages, content, exc)
                    continue
                break
            except Exception as exc:
                last_error = exc
                if breaker is not None:
                    if is_retryable(exc):
                        breaker.record_failure()
                    else:
                        breaker.release_probe()
                if is_retryable(exc) and transport_attempt < model_config.retry.max_retries:
                    transport_attempt += 1
                    await asyncio.sleep(backoff_delay(transport_attempt - 1, model_config))
                    continue
                break
    if isinstance(last_error, GatewayError):
        # 链上所有模型均失败时，保留最具体的一次错误码（如 invalid_json / circuit_open）
        record_trace(
            ctx,
            build_trace(
                request,
                request_id,
                None,
                _empty_usage(),
                started,
                attempts,
                "failed",
                error_code=last_error.code,
                routing_reason=routing_reason,
                model_config=ctx.config.models.get(requested_model),
                status_code=last_error.status_code,
                api_key_hash=api_key_hash,
            ),
        )
        raise last_error
    record_trace(
        ctx,
        build_trace(
            request,
            request_id,
            None,
            _empty_usage(),
            started,
            attempts,
            "failed",
            error_code="model_unavailable",
            routing_reason=routing_reason,
            model_config=ctx.config.models.get(requested_model),
            status_code=502,
            api_key_hash=api_key_hash,
        ),
    )
    raise GatewayError("model_unavailable", "主模型和备用模型均不可用") from last_error


async def stream_with_fallback(
    request: LLMRequest,
    ctx: GatewayContext,
    request_id: str | None = None,
    api_key_hash: str | None = None,
    disconnected: DisconnectCheck | None = None,
) -> AsyncIterator[tuple[str, Any]]:
    # 上游首块前按重试配置退避重试并可切备用模型；首块后仅发送流内错误，避免文本重复。
    messages = build_messages(request, ctx.config.prompts, ctx.prompt_store)
    request_id = request_id or str(uuid4())
    started = time.perf_counter()
    attempts = 0
    first_token_ts: float | None = None
    last_error: Exception | None = None
    routing_reason: str | None = None
    for model_name in fallback_chain(request.model, ctx.config):
        # Run 预算在模型循环入口也检查：避免剩余模型徒耗熔断半开探测等副作用
        if attempts >= ctx.config.run_budget:
            last_error = _budget_exhausted(ctx.config.run_budget)
            break
        if model_name != request.model and routing_reason is None and last_error is not None:
            routing_reason = _error_code(last_error)
        entry = validate_entry(model_name, request, ctx)
        if isinstance(entry, GatewayError):
            if model_name == request.model:
                raise entry
            continue
        model_config: ModelConfig = entry
        if model_name != request.model:
            enforce_model_quota(ctx, model_name, request, request_id, api_key_hash)
        breaker = ctx.breakers.get(model_name)
        if breaker is not None and not breaker.allow_request():
            last_error = GatewayError("circuit_open", f"模型 {model_name} 处于熔断状态", 503)
            continue
        usage = _empty_usage()
        transport_attempt = 0
        while True:
            # 重试与备用切换共用同一个 Run 预算，超限直接终态
            if attempts >= ctx.config.run_budget:
                last_error = _budget_exhausted(ctx.config.run_budget)
                break
            attempts += 1
            emitted = False
            upstream_iter = None
            try:
                upstream_iter = ctx.provider.stream(model_config, messages, request.timeout_seconds)
                async for delta, chunk_usage in upstream_iter:
                    if chunk_usage is not None:
                        usage = chunk_usage
                    if delta:
                        if disconnected is not None and await disconnected():
                            # 客户端已断开：不再产出增量，显式关闭上游流防止白烧 token
                            if breaker is not None:
                                breaker.release_probe()
                            record_trace(
                                ctx,
                                build_trace(
                                    request,
                                    request_id,
                                    model_name,
                                    usage,
                                    started,
                                    attempts,
                                    "failed",
                                    error_code="client_disconnected",
                                    routing_reason=routing_reason,
                                    status_code=200,
                                    api_key_hash=api_key_hash,
                                    stream=True,
                                ),
                            )
                            return
                        if first_token_ts is None:
                            first_token_ts = time.perf_counter()
                        emitted = True
                        yield "delta", delta
                if breaker is not None:
                    breaker.record_success()
                first_token_ms = (
                    int((first_token_ts - started) * 1000) if first_token_ts is not None else None
                )
                record_trace(
                    ctx,
                    build_trace(
                        request,
                        request_id,
                        model_name,
                        usage,
                        started,
                        attempts,
                        "success",
                        routing_reason=routing_reason,
                        model_config=model_config,
                        first_token_ms=first_token_ms,
                        api_key_hash=api_key_hash,
                        stream=True,
                    ),
                )
                yield "completed", {"model": model_name, "usage": usage}
                return
            except Exception as exc:
                last_error = exc
                if breaker is not None:
                    if is_retryable(exc):
                        breaker.record_failure()
                    else:
                        breaker.release_probe()
                if emitted or not is_retryable(exc) or transport_attempt >= model_config.retry.max_retries:
                    break
                await asyncio.sleep(backoff_delay(transport_attempt, model_config))
                transport_attempt += 1
            finally:
                # 显式关闭上游流：async-for 提前退出不会自动 aclose，断开/异常/GeneratorExit 都走这里
                if upstream_iter is not None:
                    await upstream_iter.aclose()
    logger.exception("upstream stream failed", exc_info=last_error)
    # 流式 HTTP 状态码已锁定为 200，失败只能通过流内 error 事件传递
    final_code = (
        "run_budget_exhausted"
        if isinstance(last_error, GatewayError) and last_error.code == "run_budget_exhausted"
        else "upstream_stream_failed"
    )
    record_trace(
        ctx,
        build_trace(
            request,
            request_id,
            None,
            _empty_usage(),
            started,
            attempts,
            "failed",
            error_code=final_code,
            routing_reason=routing_reason,
            model_config=ctx.config.models.get(request.model),
            status_code=200,
            api_key_hash=api_key_hash,
            stream=True,
        ),
    )
    yield "failed", final_code


def _validate_responses_entry(
    model_name: str, request: OpenAIResponsesRequest, ctx: GatewayContext
) -> ModelConfig | GatewayError:
    # Responses 能力开关：请求模型必须声明 supports_responses；备用链只取同样声明的模型。
    model_config = ctx.config.models.get(model_name)
    if model_config is None:
        return GatewayError("unknown_model", "模型不在 Gateway 允许列表中", 400)
    if not model_config.supports_responses:
        return GatewayError("responses_unsupported", f"模型 {model_name} 未启用 Responses API", 400)
    return model_config


def _responses_trace_request(request: OpenAIResponsesRequest) -> LLMRequest:
    # Responses 请求不含 messages/prompt，构造只携带模型名的占位请求入审计（不记录内容）。
    return LLMRequest(model=request.model, messages=[Message(role="user", content="responses-api")])


async def responses_with_fallback(
    request: OpenAIResponsesRequest,
    ctx: GatewayContext,
    request_id: str | None = None,
    api_key_hash: str | None = None,
) -> tuple[dict[str, Any], Usage]:
    # 与 chat 路径同构的 fallback/重试/熔断循环；上游 JSON 透传，只重写 model 为虚拟模型名。
    trace_request = _responses_trace_request(request)
    request_id = request_id or str(uuid4())
    started = time.perf_counter()
    attempts = 0
    last_error: Exception | None = None
    routing_reason: str | None = None
    for model_name in fallback_chain(request.model, ctx.config):
        # Run 预算在模型循环入口也检查：避免剩余模型徒耗熔断半开探测等副作用
        if attempts >= ctx.config.run_budget:
            last_error = _budget_exhausted(ctx.config.run_budget)
            break
        if model_name != request.model and routing_reason is None and last_error is not None:
            routing_reason = _error_code(last_error)
        entry = _validate_responses_entry(model_name, request, ctx)
        if isinstance(entry, GatewayError):
            if model_name == request.model:
                raise entry
            last_error = entry
            continue
        model_config: ModelConfig = entry
        if model_name != request.model:
            enforce_model_quota(ctx, model_name, trace_request, request_id, api_key_hash)
        breaker = ctx.breakers.get(model_name)
        if breaker is not None and not breaker.allow_request():
            last_error = GatewayError("circuit_open", f"模型 {model_name} 处于熔断状态", 503)
            continue
        transport_attempt = 0
        while True:
            # 重试与备用切换共用同一个 Run 预算，超限直接终态
            if attempts >= ctx.config.run_budget:
                last_error = _budget_exhausted(ctx.config.run_budget)
                break
            attempts += 1
            try:
                payload, usage = await ctx.provider.responses(
                    model_config, request.input, request.timeout_seconds
                )
                if breaker is not None:
                    breaker.record_success()
                record_trace(
                    ctx,
                    build_trace(
                        trace_request,
                        request_id,
                        model_name,
                        usage,
                        started,
                        attempts,
                        "success",
                        routing_reason=routing_reason,
                        model_config=model_config,
                        api_key_hash=api_key_hash,
                    ),
                )
                payload["model"] = request.model  # 不向调用方泄漏供应商模型名
                return payload, usage
            except GatewayError as exc:
                last_error = exc
                if breaker is not None:
                    breaker.release_probe()
                break
            except Exception as exc:
                last_error = exc
                if breaker is not None:
                    if is_retryable(exc):
                        breaker.record_failure()
                    else:
                        breaker.release_probe()
                if is_retryable(exc) and transport_attempt < model_config.retry.max_retries:
                    await asyncio.sleep(backoff_delay(transport_attempt, model_config))
                    transport_attempt += 1
                    continue
                break
    if isinstance(last_error, GatewayError):
        record_trace(
            ctx,
            build_trace(
                trace_request,
                request_id,
                None,
                _empty_usage(),
                started,
                attempts,
                "failed",
                error_code=last_error.code,
                routing_reason=routing_reason,
                model_config=ctx.config.models.get(request.model),
                status_code=last_error.status_code,
                api_key_hash=api_key_hash,
            ),
        )
        raise last_error
    record_trace(
        ctx,
        build_trace(
            trace_request,
            request_id,
            None,
            _empty_usage(),
            started,
            attempts,
            "failed",
            error_code="model_unavailable",
            routing_reason=routing_reason,
            model_config=ctx.config.models.get(request.model),
            status_code=502,
            api_key_hash=api_key_hash,
        ),
    )
    raise GatewayError("model_unavailable", "主模型和备用模型均不可用") from last_error


async def responses_stream_with_fallback(
    request: OpenAIResponsesRequest,
    ctx: GatewayContext,
    request_id: str | None = None,
    api_key_hash: str | None = None,
    disconnected: DisconnectCheck | None = None,
) -> AsyncIterator[tuple[str, Any]]:
    # 事件透传：(sse_event, (event_type, payload))；首事件前可按重试配置退避重试并切备用。
    trace_request = _responses_trace_request(request)
    request_id = request_id or str(uuid4())
    started = time.perf_counter()
    attempts = 0
    first_token_ts: float | None = None
    last_error: Exception | None = None
    routing_reason: str | None = None
    for model_name in fallback_chain(request.model, ctx.config):
        # Run 预算在模型循环入口也检查：避免剩余模型徒耗熔断半开探测等副作用
        if attempts >= ctx.config.run_budget:
            last_error = _budget_exhausted(ctx.config.run_budget)
            break
        if model_name != request.model and routing_reason is None and last_error is not None:
            routing_reason = _error_code(last_error)
        entry = _validate_responses_entry(model_name, request, ctx)
        if isinstance(entry, GatewayError):
            if model_name == request.model:
                raise entry
            continue
        model_config: ModelConfig = entry
        if model_name != request.model:
            enforce_model_quota(ctx, model_name, trace_request, request_id, api_key_hash)
        breaker = ctx.breakers.get(model_name)
        if breaker is not None and not breaker.allow_request():
            last_error = GatewayError("circuit_open", f"模型 {model_name} 处于熔断状态", 503)
            continue
        usage = _empty_usage()
        transport_attempt = 0
        while True:
            # 重试与备用切换共用同一个 Run 预算，超限直接终态
            if attempts >= ctx.config.run_budget:
                last_error = _budget_exhausted(ctx.config.run_budget)
                break
            attempts += 1
            emitted = False
            upstream_iter = None
            try:
                upstream_iter = ctx.provider.responses_stream(
                    model_config, request.input, request.timeout_seconds
                )
                async for event_type, payload, chunk_usage in upstream_iter:
                    if disconnected is not None and await disconnected():
                        # 客户端已断开：不再产出事件，显式关闭上游流避免继续生成白烧 token
                        if breaker is not None:
                            breaker.release_probe()
                        record_trace(
                            ctx,
                            build_trace(
                                trace_request,
                                request_id,
                                model_name,
                                usage,
                                started,
                                attempts,
                                "failed",
                                error_code="client_disconnected",
                                routing_reason=routing_reason,
                                status_code=200,
                                api_key_hash=api_key_hash,
                                stream=True,
                            ),
                        )
                        return
                    if chunk_usage is not None:
                        usage = chunk_usage
                    if first_token_ts is None and event_type.endswith("delta"):
                        first_token_ts = time.perf_counter()
                    if event_type == "response.completed":
                        payload.setdefault("response", {})["model"] = request.model
                    emitted = True
                    yield "sse_event", (event_type, payload)
                if breaker is not None:
                    breaker.record_success()
                first_token_ms = (
                    int((first_token_ts - started) * 1000) if first_token_ts is not None else None
                )
                record_trace(
                    ctx,
                    build_trace(
                        trace_request,
                        request_id,
                        model_name,
                        usage,
                        started,
                        attempts,
                        "success",
                        routing_reason=routing_reason,
                        model_config=model_config,
                        first_token_ms=first_token_ms,
                        api_key_hash=api_key_hash,
                        stream=True,
                    ),
                )
                return
            except Exception as exc:
                last_error = exc
                if breaker is not None:
                    if is_retryable(exc):
                        breaker.record_failure()
                    else:
                        breaker.release_probe()
                if emitted or not is_retryable(exc) or transport_attempt >= model_config.retry.max_retries:
                    break
                await asyncio.sleep(backoff_delay(transport_attempt, model_config))
                transport_attempt += 1
            finally:
                # 显式关闭上游流：async-for 提前退出不会自动 aclose，断开/异常/GeneratorExit 都走这里
                if upstream_iter is not None:
                    await upstream_iter.aclose()
    logger.exception("upstream responses stream failed", exc_info=last_error)
    final_code = (
        "run_budget_exhausted"
        if isinstance(last_error, GatewayError) and last_error.code == "run_budget_exhausted"
        else "upstream_stream_failed"
    )
    record_trace(
        ctx,
        build_trace(
            trace_request,
            request_id,
            None,
            _empty_usage(),
            started,
            attempts,
            "failed",
            error_code=final_code,
            routing_reason=routing_reason,
            model_config=ctx.config.models.get(request.model),
            status_code=200,
            api_key_hash=api_key_hash,
            stream=True,
        ),
    )
    yield "failed", final_code
