"""SQLite Prompt 资产库：模板 CRUD、整数版本、激活切换与 Jinja2 沙箱渲染。

版本语义：同一 id 下版本号单调递增；activate 时自动将同 id 其他版本置为非激活。
渲染走 Jinja2 SandboxedEnvironment + StrictUndefined：禁止属性探测（{{ ''.__class__ }}），
缺失变量立即报错而不是静默输出空串。
"""

import logging
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jinja2 import StrictUndefined, TemplateSyntaxError, UndefinedError
from jinja2.sandbox import SandboxedEnvironment, SecurityError

from app.errors import GatewayError

logger = logging.getLogger("llm_gateway")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS prompts (
    id          TEXT NOT NULL,
    version     INTEGER NOT NULL,
    description TEXT,
    content     TEXT NOT NULL,
    active      INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL,
    PRIMARY KEY (id, version)
);
CREATE INDEX IF NOT EXISTS idx_prompts_active ON prompts(id, active);
"""

_ENV = SandboxedEnvironment(undefined=StrictUndefined, autoescape=False)


def render_db_prompt(content: str, variables: dict[str, str]) -> str:
    # 沙箱渲染：缺失变量与不安全表达式都转成网关错误码，而不是 500。
    try:
        template = _ENV.from_string(content)
        return template.render(**variables)
    except UndefinedError as exc:
        raise GatewayError("missing_prompt_variable", f"缺少 Prompt 变量: {exc}", 400) from exc
    except (SecurityError, TemplateSyntaxError) as exc:
        raise GatewayError("invalid_prompt_template", f"Prompt 模板不安全或语法非法: {exc}", 400) from exc
    except TypeError as exc:
        raise GatewayError("invalid_prompt_variables", f"变量名非法: {exc}", 400) from exc


class PromptStore:
    def __init__(self, path: str) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()

    def initialize(self) -> None:
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(self._path) as conn:
                conn.executescript(_SCHEMA)

    def create(
        self, prompt_id: str, content: str, description: str = "", activate: bool = True
    ) -> dict[str, Any]:
        # 同 id 下版本号单调递增；激活新版本时自动停用同 id 旧版本。
        with self._lock:
            with sqlite3.connect(self._path) as conn:
                conn.execute("BEGIN IMMEDIATE")
                version = conn.execute(
                    "SELECT COALESCE(MAX(version), 0) + 1 FROM prompts WHERE id = ?", (prompt_id,)
                ).fetchone()[0]
                if activate:
                    conn.execute("UPDATE prompts SET active = 0 WHERE id = ?", (prompt_id,))
                created_at = datetime.now(timezone.utc).isoformat()
                conn.execute(
                    "INSERT INTO prompts (id, version, description, content, active, created_at)"
                    " VALUES (?, ?, ?, ?, ?, ?)",
                    (prompt_id, version, description, content, 1 if activate else 0, created_at),
                )
        return {
            "id": prompt_id,
            "version": version,
            "description": description,
            "active": activate,
            "created_at": created_at,
        }

    def get(self, prompt_id: str, version: int | None = None) -> dict[str, Any] | None:
        # version 为空时取当前激活版本。
        with self._lock:
            with sqlite3.connect(self._path) as conn:
                conn.row_factory = sqlite3.Row
                if version is not None:
                    row = conn.execute(
                        "SELECT * FROM prompts WHERE id = ? AND version = ?", (prompt_id, version)
                    ).fetchone()
                else:
                    row = conn.execute(
                        "SELECT * FROM prompts WHERE id = ? AND active = 1 ORDER BY version DESC LIMIT 1",
                        (prompt_id,),
                    ).fetchone()
        return dict(row) if row else None

    def list_all(self) -> list[dict[str, Any]]:
        with self._lock:
            with sqlite3.connect(self._path) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    "SELECT id, version, description, active, created_at FROM prompts ORDER BY id, version"
                ).fetchall()
        return [dict(row) for row in rows]
