"""调用审计：JSONL 追加写持久化（重启不丢失）与审计记录构造。"""

import hashlib
import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from app.config import ModelConfig
from app.schemas import CallTrace, LLMRequest, Usage
from app.services.usage import calculate_cost


def _schema_hash(response_schema: dict[str, Any] | None) -> str | None:
    # Schema 定位摘要：规范化 JSON 的 sha256 前 16 位，不记录 Schema 内容。
    if response_schema is None:
        return None
    canonical = json.dumps(response_schema, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def build_trace(
    request: LLMRequest,
    request_id: str,
    actual_model: str | None,
    usage: Usage,
    started: float,
    attempts: int,
    status: Literal["success", "failed"],
    error_code: str | None = None,
    routing_reason: str | None = None,
    model_config: ModelConfig | None = None,
    status_code: int = 200,
    first_token_ms: int | None = None,
    api_key_hash: str | None = None,
    stream: bool = False,
) -> CallTrace:
    # 审计只记录元数据（模型、Token、成本、延迟、状态），不记录消息内容。
    return CallTrace(
        request_id=request_id,
        timestamp=datetime.now(timezone.utc),
        requested_model=request.model,
        actual_model=actual_model,
        prompt_name=request.prompt.name if request.prompt else None,
        prompt_version=request.prompt.version if request.prompt else None,
        input_tokens=usage.input_tokens,
        output_tokens=usage.output_tokens,
        cached_tokens=usage.cached_tokens,
        reasoning_tokens=usage.reasoning_tokens,
        cost_usd=calculate_cost(model_config, usage) if model_config else 0,
        latency_ms=int((time.perf_counter() - started) * 1000),
        first_token_ms=first_token_ms,
        attempts=attempts,
        status=status,
        status_code=status_code,
        error_code=error_code,
        routing_reason=routing_reason,
        schema_hash=_schema_hash(request.response_schema),
        price_snapshot=(
            {"input": model_config.price_input, "output": model_config.price_output}
            if model_config is not None
            else None
        ),
        api_key_hash=api_key_hash,
        stream=stream,
        dropped_params=request.dropped_params or None,
    )


class TraceStore:
    def __init__(self, path: str) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()

    def append(self, trace: CallTrace) -> None:
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with self._path.open("a", encoding="utf-8") as fh:
                fh.write(trace.model_dump_json() + "\n")

    def list(self, limit: int = 1000) -> list[CallTrace]:
        if not self._path.exists():
            return []
        traces: list[CallTrace] = []
        with self._path.open(encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    traces.append(CallTrace.model_validate_json(line))
        return traces[-limit:]
