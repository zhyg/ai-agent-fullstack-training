"""受控 Prompt 模板渲染：调用方只能传版本与变量，不能上传模板正文。

解析顺序（自推导约定）：SQLite 资产库优先（数字版本号精确匹配，非数字版本号取
当前激活版本）；库中不存在时回退 YAML 静态模板，兼容既有调用方。
"""

from string import Template

from app.config import PromptTemplate
from app.errors import GatewayError
from app.schemas import LLMRequest, Message, PromptSelection
from app.services.prompt_store import PromptStore, render_db_prompt


def _render_db(selection: PromptSelection, store: PromptStore) -> Message | None:
    # 数字版本 → 精确版本；非数字版本 → 激活版本。库中无此 id 时返回 None 走 YAML 兜底。
    if selection.version.isdigit():
        row = store.get(selection.name, int(selection.version))
    else:
        row = store.get(selection.name)
    if row is None:
        return None
    return Message(role="system", content=render_db_prompt(row["content"], selection.variables))


def render_prompt(
    selection: PromptSelection,
    templates: dict[tuple[str, str], PromptTemplate],
    store: PromptStore | None = None,
) -> Message:
    if store is not None:
        db_message = _render_db(selection, store)
        if db_message is not None:
            return db_message
    template = templates.get((selection.name, selection.version))
    if template is None:
        raise GatewayError("unknown_prompt_template", "Prompt 模板不存在", 400)
    try:
        content = Template(template.system_template).substitute(selection.variables)
    except KeyError as exc:
        raise GatewayError("missing_prompt_variable", f"缺少 Prompt 变量: {exc.args[0]}", 400) from exc
    return Message(role="system", content=content)


def build_messages(
    request: LLMRequest,
    templates: dict[tuple[str, str], PromptTemplate],
    store: PromptStore | None = None,
) -> list[Message]:
    # 将模板系统消息统一注入调用上下文，避免 Prompt 分散在各个 Agent 中。
    if request.prompt is None:
        return request.messages
    return [render_prompt(request.prompt, templates, store), *request.messages]
