"""跨模型统一请求/响应协议与 OpenAI 兼容入口协议。"""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Message(BaseModel):
    # 跨模型通用的单条对话消息，隔离供应商消息格式差异。
    model_config = ConfigDict(extra="forbid")

    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=20_000)


class PromptSelection(BaseModel):
    # 只允许调用方选择受控模板及变量，不能提交或覆盖模板正文。
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=100)
    version: str = Field(min_length=1, max_length=50)
    variables: dict[str, str] = Field(default_factory=dict)


class LLMRequest(BaseModel):
    # 统一 Gateway 请求协议，并在 HTTP 入口拦截不合法组合和字段。
    model_config = ConfigDict(extra="forbid")

    model: str = Field(min_length=1, max_length=100)
    messages: list[Message] = Field(min_length=1, max_length=100)
    stream: bool = False
    response_schema: dict[str, Any] | None = None
    timeout_seconds: float = Field(default=30, gt=0, le=120)
    prompt: PromptSelection | None = None
    # OpenAI 兼容入口丢弃并标记的参数（不转发上游，供响应头与审计记录）
    dropped_params: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def check_supported_combination(self) -> "LLMRequest":
        if self.stream and self.response_schema is not None:
            raise ValueError("stream 与 response_schema 不能同时使用")
        return self


class Usage(BaseModel):
    # 统一输入与输出 Token 统计口径，用于成本和用量治理。
    model_config = ConfigDict(extra="forbid")

    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    cached_tokens: int = Field(default=0, ge=0)
    reasoning_tokens: int = Field(default=0, ge=0)


class LLMResponse(BaseModel):
    # 统一模型调用结果，并作为 FastAPI 响应出口的 Pydantic 校验契约。
    model_config = ConfigDict(extra="forbid")

    request_id: str
    model: str
    content: str
    parsed: dict[str, Any] | list[Any] | None = None
    usage: Usage
    latency_ms: int = Field(ge=0)
    attempts: int = Field(ge=1)


class PromptTemplate(BaseModel):
    # Gateway 发布和版本化管理的系统 Prompt 模板资产。
    model_config = ConfigDict(extra="forbid")

    name: str
    version: str
    system_template: str


class CallTrace(BaseModel):
    # 保存单次调用的模型、Token、成本、延迟与状态，默认不记录文本内容。
    model_config = ConfigDict(extra="forbid")

    request_id: str
    timestamp: datetime
    requested_model: str
    actual_model: str | None = None
    prompt_name: str | None = None
    prompt_version: str | None = None
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    cached_tokens: int = Field(default=0, ge=0)
    reasoning_tokens: int = Field(default=0, ge=0)
    cost_usd: float = Field(ge=0)
    latency_ms: int = Field(ge=0)
    first_token_ms: int | None = Field(default=None, ge=0)
    attempts: int = Field(ge=0)
    status: Literal["success", "failed"]
    status_code: int = Field(default=200)
    error_code: str | None = None
    api_key_hash: str | None = None
    stream: bool = False
    dropped_params: list[str] | None = Field(default=None)
    # 首次从主模型切换到备用模型时的错误码；主模型直接服务时为 None
    routing_reason: str | None = Field(default=None)
    # response_schema 规范化 JSON 的 sha256 摘要（前 16 位），定位 Schema 而不记录内容
    schema_hash: str | None = Field(default=None)
    # 成本计算所依据的价格快照 {"input": 美元/百万 Token, "output": 美元/百万 Token}
    price_snapshot: dict[str, float] | None = Field(default=None)


class OpenAIMessage(BaseModel):
    # OpenAI 兼容入口的消息结构；SDK 附带的额外字段一律放行。
    model_config = ConfigDict(extra="allow")

    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=20_000)


class PromptCreate(BaseModel):
    # 新建 Prompt 版本：同一 id 下版本号由服务端单调递增，调用方不能指定。
    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1, max_length=100)
    content: str = Field(min_length=1, max_length=20_000)
    description: str = Field(default="", max_length=500)
    activate: bool = True


class PromptRenderRequest(BaseModel):
    # 指定版本渲染（缺省用激活版本）；变量只能是字符串键值对。
    model_config = ConfigDict(extra="forbid")

    version: int | None = Field(default=None, ge=1)
    variables: dict[str, str] = Field(default_factory=dict)


class OpenAIChatRequest(BaseModel):
    # OpenAI 兼容入口的请求结构；SDK 附加参数（temperature 等）一律放行。
    model_config = ConfigDict(extra="allow")

    model: str = Field(min_length=1, max_length=100)
    messages: list[OpenAIMessage] = Field(min_length=1, max_length=100)
    stream: bool = False
    # 声明即接入本地校验：json_object 校验 JSON 对象，json_schema 校验携带的 Schema
    response_format: dict[str, Any] | None = None


class OpenAIResponsesRequest(BaseModel):
    # OpenAI Responses API 入口：input 为字符串或消息列表，其余参数透传。
    model_config = ConfigDict(extra="allow")

    model: str = Field(min_length=1, max_length=100)
    input: str | list[Any]
    stream: bool = False
    timeout_seconds: float = Field(default=30, gt=0, le=120)
