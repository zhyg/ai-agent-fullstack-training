"""Bounded grading harness; no real credential is sent to the local upstream.
Run from student with PYTHONPATH=.. .venv/bin/python ../harness.py [prepare|mock|real].
Serve mock: PYTHONPATH=.. .venv/bin/uvicorn harness:upstream --port 18761
"""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

import httpx
import yaml
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

ROOT = Path(__file__).resolve().parent
upstream = FastAPI()
state = {"mode": "good", "calls": [], "released": False}


@upstream.post('/control')
async def control(req: Request):
    state.update(await req.json())
    state['calls'] = []
    state['released'] = False
    return {'ok': True}


@upstream.post('/release')
async def release():
    state['released'] = True
    return {'ok': True}


@upstream.get('/state')
async def inspect():
    return state


def usage():
    return {'prompt_tokens': 19, 'completion_tokens': 7, 'total_tokens': 26,
            'prompt_tokens_details': {'cached_tokens': 5},
            'completion_tokens_details': {'reasoning_tokens': 3}}


@upstream.post('/v1/{path:path}')
async def model(req: Request, path: str):
    body = await req.json()
    state['calls'].append({'path': path, 'body': body, 'time': time.monotonic()})
    mode = state['mode']
    n = len(state['calls'])
    status = 429 if mode in ('retry', 'always429') and (mode == 'always429' or n < 3) else 200
    if mode in ('always500', 'always400', 'always401'):
        status = int(mode[-3:])
    if status != 200:
        return JSONResponse({'error': {'message': 'controlled', 'type': 'controlled', 'code': 'controlled'}}, status_code=status)
    text = {'invalid': 'not json', 'empty': '', 'truncated': '{"answer":',
            'mismatch': '{"answer":7}', 'repair': 'not json' if n == 1 else '{"answer":"ok"}'}.get(mode, '{"answer":"ok"}')
    if path == 'responses':
        payload = {'id': 'resp_test', 'object': 'response', 'status': 'completed', 'model': body['model'],
                   'output': [{'type': 'message', 'id': 'msg_test', 'role': 'assistant', 'status': 'completed',
                               'content': [{'type': 'output_text', 'text': text, 'annotations': []}]}],
                   'usage': {'input_tokens': 19, 'output_tokens': 7, 'total_tokens': 26,
                             'input_tokens_details': {'cached_tokens': 5}, 'output_tokens_details': {'reasoning_tokens': 3}}}
        if not body.get('stream'):
            return payload
        async def response_events():
            yield 'event: response.output_text.delta\ndata: '+json.dumps({'type': 'response.output_text.delta', 'delta': '片段'})+'\n\n'
            while not state['released']:
                await asyncio.sleep(.01)
            if mode == 'break':
                raise RuntimeError('controlled Responses disconnect')
            if mode == 'eof':
                return
            yield 'event: response.completed\ndata: '+json.dumps({'type': 'response.completed', 'response': payload})+'\n\n'
        return StreamingResponse(response_events(), media_type='text/event-stream')
    if not body.get('stream'):
        return {'id': 'chatcmpl_test', 'object': 'chat.completion', 'created': 1, 'model': body['model'],
                'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': text},
                             'finish_reason': 'length' if mode == 'truncated' else 'stop'}], 'usage': usage()}
    async def events():
        def chunk(delta, finish=None, u=None):
            return 'data: '+json.dumps({'id': 'chatcmpl_test', 'object': 'chat.completion.chunk', 'created': 1,
                    'model': body['model'], 'choices': [{'index': 0, 'delta': {'content': delta}, 'finish_reason': finish}],
                    'usage': u}, ensure_ascii=False)+'\n\n'
        yield chunk('')
        yield chunk('片段')
        while mode in ('gate', 'break', 'eof') and not state['released']:
            await asyncio.sleep(.01)
        if mode == 'break':
            raise RuntimeError('controlled disconnect after content')
        if mode == 'eof':
            return
        yield chunk('完成', 'stop', usage())
        yield 'data: [DONE]\n\n'
    return StreamingResponse(events(), media_type='text/event-stream')


def prepare():
    common = {'auth': {'enabled': False}, 'rate_limit': {'capacity': 10000, 'refill_per_second': 10000},
              'structured_output': {'repair_attempts': 2}, 'run_budget': 12}
    for kind in ('mock', 'real'):
        cfg = dict(common)
        cfg.update({'traces': {'file': str(ROOT / (kind+'-traces.jsonl'))},
                    'storage': {'database': str(ROOT / (kind+'.db'))}})
        cfg['models'] = {}
        for alias, actual in [('general-primary', 'deepseek-v4-pro'), ('general-backup', 'deepseek-flash')]:
            cfg['models'][alias] = {'provider_model': actual,
                'base_url': 'https://api.deepseek.com' if kind == 'real' else 'http://127.0.0.1:18761/v1',
                'api_key_env': 'DEEPSEEK_API_KEY' if kind == 'real' else 'GRADING_DUMMY_KEY',
                'structured_output_mode': 'json_object', 'supports_responses': True,
                'fallback': [], 'retry': {'max_retries': 0 if kind == 'real' else 2, 'backoff_base': .1, 'jitter': 0},
                'circuit_breaker': {'failure_threshold': 1000, 'cooldown_seconds': .1}}
        if kind == 'mock':
            cfg['models']['limited-a'] = dict(cfg['models']['general-primary'], rate_limit={'capacity': 1, 'refill_per_second': 2})
            cfg['models']['limited-b'] = dict(cfg['models']['general-backup'], rate_limit={'capacity': 1, 'refill_per_second': 2})
        (ROOT/(kind+'.yaml')).write_text(yaml.safe_dump(cfg, allow_unicode=True))


async def mock_tests():
    results = []
    # A student unhandled 500 closes keepalive; isolate subsequent observations.
    async with httpx.AsyncClient(timeout=20, headers={'Connection': 'close'}) as c:
        async def mode(m):
            await c.post('http://127.0.0.1:18761/control', json={'mode': m})
        async def snapshot():
            return (await c.get('http://127.0.0.1:18761/state')).json()
        async def post(body, path='/v1/chat/completions'):
            r = await c.post('http://127.0.0.1:18762'+path, json=body)
            try:
                payload = r.json()
            except ValueError:
                payload = r.text
            return {'status': r.status_code, 'request_id': r.headers.get('x-request-id'), 'body': payload}
        def body(model='general-primary', **kw):
            return {'model': model, 'messages': [{'role': 'user', 'content': 'test'}], **kw}
        async def add(name, result):
            results.append({'name': name, 'result': result, 'upstream': await snapshot()})
            print(name, json.dumps(result, ensure_ascii=False), flush=True)
        await mode('good')
        for a in ('general-primary', 'general-backup'):
            await add('normal-'+a, await post(body(a)))
        await add('unknown-model', await post(body('unknown')))
        for m in ('invalid', 'empty', 'truncated', 'mismatch', 'repair'):
            await mode(m)
            fmt = {'type': 'json_schema', 'json_schema': {'name': 'answer', 'schema': {'type': 'object', 'properties': {'answer': {'type': 'string'}}, 'required': ['answer']}}}
            await add('json-'+m, await post(body(response_format=fmt)))
        for m in ('retry', 'always429', 'always500', 'always400', 'always401'):
            await mode(m)
            await add(m, await post(body()))
        await mode('good')
        for v in (1, 2):
            await add('publish-'+str(v), await post({'id': 'grade', 'content': 'version'+str(v)+' {{who}}', 'activate': True}, '/v1/prompts'))
        for v in ('1', '2', '99'):
            await add('template-'+v, await post(body(prompt={'name': 'grade', 'version': v, 'variables': {'who': 'Ada'}}), '/v1/llm'))
        await add('missing-variable', await post(body(prompt={'name': 'grade', 'version': '1', 'variables': {}}), '/v1/llm'))
        await add('missing-template', await post(body(prompt={'name': 'absent', 'version': '1', 'variables': {}}), '/v1/llm'))
        await mode('good')
        for a in ('limited-a', 'limited-a', 'limited-b'):
            await add('quota-'+a, await post(body(a)))
        await asyncio.sleep(.55)
        await add('quota-restored', await post(body('limited-a')))
        for alias in ('general-primary', 'general-backup'):
            for m in ('gate', 'break', 'eof'):
                await mode(m)
                got = asyncio.Event()
                lines = []
                async def consume():
                    async with c.stream('POST', 'http://127.0.0.1:18762/v1/chat/completions', json=body(alias, stream=True)) as r:
                        async for line in r.aiter_lines():
                            lines.append(line)
                            if '片段' in line:
                                got.set()
                task = asyncio.create_task(consume())
                await asyncio.wait_for(got.wait(), 5)
                pre = list(lines)
                await c.post('http://127.0.0.1:18761/release')
                await task
                await add('stream-'+m+'-'+alias, {'content_before_release': bool(pre), 'before_release': pre, 'lines': lines})
        await mode('good')
        await add('responses-protocol', await post({'model': 'general-primary', 'input': 'test'}, '/v1/responses'))
        await add('responses-format-ignored', await post({'model': 'general-primary', 'input': 'test', 'text': {'format': {'type': 'json_object'}}}, '/v1/responses'))
        traces = (await c.get('http://127.0.0.1:18762/v1/traces')).json()
        ledger = (await c.get('http://127.0.0.1:18762/admin/usage')).json()
        (ROOT/'mock-results.json').write_text(json.dumps({'cases': results, 'traces': traces, 'ledger': ledger}, ensure_ascii=False, indent=2))


async def real_tests():
    results = []
    async with httpx.AsyncClient(timeout=100) as c:
        for alias in ('general-primary', 'general-backup'):
            for kind in ('normal', 'stream', 'json'):
                body = {'model': alias, 'messages': [{'role': 'user', 'content': '只输出 JSON 对象 {"ok":true}，不要其他文字。' if kind == 'json' else '只输出OK。'}], 'max_tokens': 128}
                if kind == 'stream':
                    body['stream'] = True
                if kind == 'json':
                    body['response_format'] = {'type': 'json_object'}
                t = time.monotonic()
                try:
                    r = await c.post('http://127.0.0.1:18763/v1/chat/completions', json=body)
                    try:
                        payload = r.json()
                    except ValueError:
                        payload = r.text
                    result = {'alias': alias, 'kind': kind, 'status': r.status_code, 'request_id': r.headers.get('x-request-id'),
                              'dropped_params': r.headers.get('x-gateway-dropped-params'), 'elapsed': time.monotonic()-t, 'body': payload}
                except Exception as e:
                    result = {'alias': alias, 'kind': kind, 'error': type(e).__name__, 'elapsed': time.monotonic()-t}
                results.append(result)
                print(json.dumps(result, ensure_ascii=False), flush=True)
                (ROOT/'real-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
        # Test actual second protocol on official endpoint; no supplier substitution.
        for stream in (False, True):
            r = await c.post('http://127.0.0.1:18763/v1/responses', json={'model': 'general-primary', 'input': '只输出OK。', 'stream': stream, 'max_output_tokens': 128})
            result = {'kind': 'responses', 'stream': stream, 'status': r.status_code, 'body': r.text, 'request_id': r.headers.get('x-request-id')}
            results.append(result)
            print(json.dumps(result, ensure_ascii=False), flush=True)
        (ROOT/'real-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    else:
        asyncio.run(mock_tests() if sys.argv[1] == 'mock' else real_tests())
