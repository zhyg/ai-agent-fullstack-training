# 第一周作业评测附件

- 学员：小目标大成就 G20261786010571，第一次提交。
- 仓库：https://gitee.com/libuzuan/mini-llm-gateway
- 分支与提交号：克隆时 `master`，固定并 detached checkout `b667e7cf4ee2c4fda6107a8e776600ca65c8c18a`（提交时间 2026-11-11 15:51:07 +0800）。
- 评测日期：2026-11-14，Asia/Singapore（运行日志使用 UTC）。
- 总分：83/100。
- 作业等级：优秀（按 80/60 分界，不封顶、不改变等级）。
- 验收结论：未通过。两个上游协议各自可真实调用，但没有实现作业要求的“统一入口按 model 选择不同协议适配器”；Responses 的结构化约束也未落实。不是“只写了一个协议”，也不是凭据不足导致的未验证。
- 评测方式：本线程新 orb 独立实际 git clone、安装、启动、真实调用和受控测试；没有新建线程或委托评测。学生业务源码无修改，`git status --porcelain` 为空。
- 文件冲突检查：三个目标文件原先均不存在，使用原名，没有覆盖其他提交。
- 评分来源：完整阅读 `hw-guide/week01/第一周作业.md`、`第一周作业评分标准.md` v1.1 和 `hw-guide/学员作业反馈报告模板与要求.md` v1.0。
- 证据包：`G20261786010571-evidence.tar.gz`。下文的日志、脚本、JSON 路径均相对于包内目录。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 11/15 | 有 model 白名单、正确模型路由、统一 Chat 结果和独立 Responses 实现；但协议由 HTTP 入口而非模型适配决定，调用方仍需了解两套协议。D1 合并扣 4。 |
| 流式输出 | 12/15 | 双模型门控验证内容先于终态到达；单模型硬断流发送错误；备用链输出后仍切换并重复文本扣 2，无终态 EOF 被视为成功扣 1（D2）。 |
| 结构化输出 | 6/10 | Chat 双模型真实 JSON 成功，非法和截断 JSON、Schema 类型错误可校验并有限修复；Responses 忽略格式约束扣 3（D3），空正文修复抛未处理 500 扣 1（D4）。 |
| 提示词版本管理 | 10/10 | SQLite 发布 1、2 版，旧版、新版实际进入上游；缺失版本、模板及变量明确 400。 |
| 可观测性 | 10/15 | 正常用量输入/输出/缓存/推理及 TTFT、延迟、request_id、JSONL/SQLite 可查；修复及校验失败丢失已知用量扣 3（D5），入口失败未审计扣 2（D6）。 |
| 统一错误与重试 | 14/15 | 上游 429 前两次失败后第三次成功，0.1/0.2 秒退避，持续失败每上游 3 次，SDK max_retries=0；400/401 单上游不重试。上游错误原因及状态被统一抹成 model_unavailable/502 扣 1（D7）。 |
| 按模型独立限流 | 10/10 | A 配额耗尽返回 HTTP 429，B 仍成功；0.55 秒后 A 恢复，拒绝有审计；容量和补充速率可配置。 |
| 源码、README 与验证脚本 | 10/10 | uv 安装启动可复现；README 有 curl、配置说明和真实验收清单；132 项离线断言覆盖六项功能，人为注入错误后原测试失败；ruff 通过。未因同一业务缺陷缺少回归测试再次扣分。 |
| 合计 | 83/100 | 11 + 12 + 6 + 10 + 10 + 14 + 10 + 10 = 83；按功能影响计分，不按通过率换算。 |

## 评测配置与真实调用范围

安装命令为 `uv sync --extra dev`，学生脚本入口 `uv run pytest -v`、`uv run ruff check app/ tests/`；分别得到 `132 passed in 5.28s`、`All checks passed!`。使用学生实际 FastAPI/uvicorn、OpenAI SDK，不替换业务 Provider 来证明真实调用。环境版本见 `environment.json`。

只使用已连接的 `DEEPSEEK_API_KEY` secret 和 `https://api.deepseek.com`。先访问官方 `/models` 确认可用模型是 `deepseek-v4-pro` 和 `deepseek-flash`（官方名称 DeepSeek-V4.1-Flash）。没有访问其他模型供应商。

配置替代（`real.yaml`）：`general-primary → deepseek-v4-pro`、`general-backup → deepseek-flash`；均读取同一个 `DEEPSEEK_API_KEY`。Chat 入口实际发往 `/chat/completions`，Responses 入口实际发往 `/responses`。原配置使用环境变量及第二个密钥名，本次仅替换模型、地址、密钥变量引用、存储、重试和限流配置；不改业务逻辑。两个模型本次都关闭 fallback，避免将备用成功误记为请求模型成功。模型协议不是 YAML 可配置项，正是 D1 的范围。

真实请求使用“只输出OK。”或只要求 `{"ok":true}` 的短 prompt，并申请 `max_tokens=128`；学生代码明确丢弃该字段且响应头披露 `max_tokens`，Responses 也未转发 `max_output_tokens`。因此**没有声称硬输出预算已生效**；保留学生行为，使用短 prompt、30 秒学生默认超时、真实重试 0 来控制费用。全部调用迅速结束，Chat 输出用量 11–49 Token，Responses 输出 29/47 Token；没有为实现预算而修改业务逻辑。

### 真实调用记录

`real-results.json` 保存外层返回、正文及 SSE；`real-traces.jsonl` 保存用量、分类、处理延迟和关联 ID。普通与 JSON 均明确检查模型正文，非只检查 HTTP 200；流式检查正文及 `[DONE]`，增量性质另由门控测试证明。

| 模型别名 / 上游 | 模式 / 协议 | 结果 | request_id | 输入/输出/推理 Token | 延迟 ms / TTFT ms |
| --- | --- | --- | --- | --- | --- |
| general-primary / deepseek-v4-pro | 普通 Chat | 200，OK | d5789aff22df4e73a342eadc601a112a | 87/49/47 | 2199 / — |
| general-primary / deepseek-v4-pro | 流式 Chat | 200，OK、DONE | ac3d7ebf4b8c4e65b71d107dbe7318ce | 87/43/41 | 1777 / 1775 |
| general-primary / deepseek-v4-pro | JSON Chat | 200，合法对象 | 350e52340ba54318905b9f99d294f9ab | 149/27/21 | 1549 / — |
| general-backup / deepseek-flash | 普通 Chat | 200，OK | 0a5b3f84fbe54b96ae8faee2695a7756 | 34/15/13 | 849 / — |
| general-backup / deepseek-flash | 流式 Chat | 200，OK、DONE | a9aeae0011da4c3ebdf2c1d4b1f06e71 | 34/11/9 | 846 / 845 |
| general-backup / deepseek-flash | JSON Chat | 200，合法对象 | 6d3958a509be474280cd3b153084c7f0 | 98/26/20 | 1176 / — |
| general-primary / deepseek-v4-pro | 普通 Responses | 200，output_text 为 OK | 95e7eb14adf542498004e115c153b7cf | 87/29/27 | 1458 / — |
| general-primary / deepseek-v4-pro | 流式 Responses | 200，文本增量、completed | ab7b6b5879a34dc09a0524db096ecd9b | 87/47/45 | 1603 / 928 |

推理 Token 是输出 Token 的子集，不再次加到总数。上述缓存分类均为 0；受控测试另验证非零缓存 5 和推理 3。成本价格在评测替代配置中未设定，账本 cost=0 不是本次实际费用声明。

## A01–A04 / F01–F12 验证结果

| 编号 | 方式与入口 | 实际结果与证据 |
| --- | --- | --- |
| A01 | 实际 uv 安装、uvicorn 启动、healthz | 成功；`install.log`、环境清单、网关日志。使用隔离评测配置，无 .env 或隐藏本机文件依赖。 |
| A02 | 同一 `/v1/chat/completions`，两个 model | 两个真实模型分别普通成功；见真实调用表。 |
| A03 | 源码 + 实收请求 + 两协议真实调用 | Chat/Responses 两种底层协议确实存在，但统一入口不按 model 选择协议；`normal-*` 捕获 messages/path，`responses-protocol` 捕获 input/path。D1，不把另一个接口的存在误判为按模型双协议适配完成。 |
| A04 | unknown model | 400 `unknown_model`，上游请求计数没有增加；但无审计，见 D6。 |
| F01 | 双模型真实流 + TCP HTTP 门控 | 两模型 Chat 在释放终态前已经收到“片段”；随后才得到“完成”和 DONE。Responses 也执行门控成功。`stream-gate-*`、`responses-stream-gate`。 |
| F02 | 文本后硬断流、有/无备用链；无终态 EOF | 无备用链发 error 且仅 1 次请求；有备用链实收 2 次并重复文本。干净 EOF 被误判完成。`stream-break-*`、`stream-eof-*`、`fallback-after-content`，D2。 |
| F03 | 双模型真实 response_format=json_object；Responses 受控格式 | Chat 两模型正文均为合法 JSON；Responses 丢弃 response_format/text.format，非法文本仍 200，D3。 |
| F04 | 非法、空、截断 JSON、Schema 不符、修复成功/失败 | 非法/截断/类型不符均最多 3 次结构修复尝试后 502；一次修复后合法则成功；空正文 500。`json-*`、D4。 |
| F05 | 发布 grade 版本 1、2，再经 `/v1/llm` 调模型 | 实收 system 分别为 `version1 Ada`、`version2 Ada`；发布新版后仍保留旧版。 |
| F06 | version=99、缺 who、未知模板 | 全部明确 400，不发未替换占位符；上游累计计数不增加。`template-99`、`missing-variable`、`missing-template`。 |
| F07 | 普通、流式、修复、最终失败及入口错误后查询 | 正常 19/7/缓存5/推理3，TTFT 非空、延迟覆盖调用；失败记录缺项和用量丢失见 D5、D6；JSONL/SQLite 均已采集。 |
| F08 | HTTP 429 前两次失败、第三次成功 | 实收恰好 3 次；请求间隔约 0.105、0.205 秒，符合 0.1、0.2 退避加网络开销；无 SDK 隐含重试。 |
| F09 | 持续429、上游400/401；另测500 | 持续429每上游 3 次（含 SDK），主备共6次但每个模型都未超限；400/401每上游1次。500按学生声明不重试，作为建议不追加扣分。错误原因丢失见 D7。 |
| F10 | 模型限额 capacity=1、refill=2；耗尽 A 后调 B | 状态序列 200、429、200；拒绝在首字节前返回，拒绝有审计。 |
| F11 | 等待0.55秒再次调用 A | 200，真实上游计数增加，证明配额恢复。 |
| F12 | 学生 pytest 全量 + 注入一次错误内容 | 132 项通过；`inject_failure.py` 临时内存改变测试夹具输出，原有内容断言失败，退出1。并非新增一个必败测试，也未改学生源码。 |

`verify.py` 对保存的请求数、退避间隔、正文、模板渲染、门控前后、限流和真实调用做独立断言，输出 `Evidence assertions PASS`。该 PASS 表示证据与已观察到的成功/缺陷一致，不代表学生全部功能通过。

## 待修复问题与扣分复现

### D1：协议选择没有收敛到统一模型入口（统一接口与适配器，扣4分）

- 触发：同一 `/v1/llm` 或 `/v1/chat/completions`，仅替换两个公开模型别名，即使 `supports_responses=true`，仍始终走 Chat；必须调用者改 URL 和请求体为 `/v1/responses` + input 才走 Responses。
- 预期：公开 model 配置决定协议适配器，调用者使用统一入口和统一结果；实际只在不同端点中选择 provider.complete / provider.responses。
- 源码：`app/services/provider.py:108–156,199–211`；`app/config.py:37–54` 无协议路由字段；`app/api/openai.py:199–231,308–337`。
- 证据：`mock-results.json` 的 `normal-general-primary`、`normal-general-backup`、`responses-protocol`；真实两协议均已调用成功，保留已实现的部分分。两入口响应外形不同是此根因的表现，不另扣。

### D2：流输出后仍跨模型生成；无成功终态被认作成功（流式，合计扣3分）

- 硬断流复现：`supplement.py` 只把主模型配置的 fallback 设为备用，用真实 SDK 连接受控 HTTP 上游；上游先给“片段”再断开。预期已有内容后直接失败，实际主备各收1请求，正文“片段”出现两次，最后才 error。证据 `supplement-results.json/cases[name=fallback-after-content]`，扣“输出后避免重试重复”2分。
- 源码：`app/services/gateway.py:399–406` 的 break 只退出内层重试 while，仍继续外层模型循环；不是按源代码注释所说的首块后直接终止。
- EOF 复现：`stream-eof-*` 上游只输出内容后干净结束，无 finish_reason/成功终态/DONE。预期识别失败；实际网关新造 stop、DONE 并写 success。Responses EOF 虽不伪造 completed，也会按成功审计。`app/services/provider.py:176–191` 未检查终态，`gateway.py` 迭代结束直接 success；终止判断扣1分。
- 无备用链硬断流、正常门控和结束事件保留得分；两个模型重复复现不再各扣一次。普通 length 截断不单独扣分。

### D3：Responses 结构化约束被忽略（结构化输出，扣3分）

- 触发：向 `/v1/responses` 请求加入统一 response_format=json_object 以及协议原生 text.format=json_object，上游返回 `not json`。
- 预期：映射结构约束并解析校验，或对不支持的格式明确4xx；实际 HTTP200、status=completed、模型正文 `not json`。
- 证据：`supplement-results.json/cases[name=responses-json-invalid]`；实收 body 只有 model/input，没有格式字段。`mock-results.json/responses-format-ignored` 为正常对照。
- 源码：`app/schemas.py` 的 OpenAIResponsesRequest 允许 extra，但 `app/services/provider.py:205–206` 仅传 model/input/timeout；返回路径未做 JSON 解析。Chat 的正常 JSON、校验及修复已经成立，不清零本项。
- 本项只评结构化契约丢失，与 D1 的模型路由缺口是不同的可独立修复问题；不在统一错误项再扣这一格式被吞的问题。

### D4：空正文修复触发未处理500（结构化输出，扣1分）

- 触发：Chat + response_format，受控上游返回空字符串，默认 repair_attempts=2。
- 预期：空内容不能成功，并应统一失败或安全修复；实际 `json-empty` 为裸 `Internal Server Error`，无关联响应头。
- 源码：`app/services/gateway.py:47–52,229–237` 将空 failed_content 构造为 `Message(content='')`，与 `app/schemas.py:14` 的 min_length=1 冲突；异常发生在 except 分支内部，跳出统一处理。
- 证据：`gateway-mock.log` 末段 `ValidationError: String should have at least 1 character`；`mock-results.json/json-empty`。未把空内容当成功，但失败处理不完整，故仅扣1；不再因这次同源500缺审计而扣第二次。

### D5：多次已知用量未累计，已知失败用量记零（可观测性，扣3分）

- 触发：每次 HTTP 成功返回输入19、输出7、缓存5、推理3，但正文非法需要重产。
- 预期：两次已知调用应记录输入38/输出14（分类按子集保留），三次已知调用最终失败仍应保留57/21或明确另存尝试账本；实际 json-repair attempts=2 只记19/7，json-invalid attempts=3 记0/0，未提供丢弃计量的未知标记或尝试账本。
- 证据：`mock-results.json` 的请求捕获、对应 traces 和 ledger；`mock-traces.jsonl`；数据都是受控用量，不是估算真实费用。
- 源码：`gateway.py:193–220` 直接记录最后一次 usage，`252–260` 最终错误强制 `_empty_usage()`；两个现象合并为一个用量汇总根因扣分。正常缓存/推理分类、累计快照取最后值正确，保留得分。

### D6：入口失败未写调用记录（可观测性，扣2分）

- 触发：未知模型，或模板/版本不存在、模板变量缺失。
- 预期：与正常调用一样可按 request_id 查询失败记录，即使 attempts=0、用量未知；实际 HTTP 返回明确400且有 request_id，但 traces 与 ledger 均找不到对应 ID。
- 证据：`mock-results.json` 的 `unknown-model`、`missing-variable`、`missing-template`、`template-99` 及其最终账本快照；`verify.py` 明确断言该缺失。
- 源码：`gateway.py:152` build_messages 早于记账异常处理，`161–164` 未知模型直接抛；`api/openai.py:204–217` 入口检查错误直接返回，未审计。
- 上游持续失败、本地模型限流拒绝确实有失败记录，因此保留失败记录子项的部分得分。不重复计 D4 空正文缺记录或 D2 EOF 状态问题。

### D7：上游原因被抹成相同错误（统一错误与重试，扣1分）

- 触发：分别注入持续429、400参数错误和401鉴权错误，且无备用或备用均失败。
- 预期：统一结构保留稳定且可区分的错误码；参数不支持场景应是明确4xx，本地429也应能与上游限流区分。
- 实际：三个情况最终均 `502 model_unavailable`，调用者无法判断是限流、请求不合法还是凭据问题。400/401不在同一个模型反复重试本身正确。
- 源码：`provider.py:20–37` 抹平其他 SDK 错误，`gateway.py:272–289` 最终再统一成 model_unavailable；证据 `mock-results.json/always429,always400,always401`。
- 单上游持续429实际3次，SDK 内置0次；备用链6次按每上游分别计算，不误扣次数超限。500不重试与学生文档一致，只建议完善暂时性5xx范围，不另扣。

## 不扣分的限制与建议

- 没有修改学生业务代码来添加 max_tokens 或 thinking 参数。输出上限被丢弃是文档已披露的能力边界，原题不强制此参数，本次不扣分，但建议成本控制时转发预算。
- Responses 的 TTFT 由首个 delta（可能推理）触发，Chat 测正文首增量。原题允许两种口径；建议文档明确区别，本次不因口径偏好扣分。
- 缺失缓存/推理 details 按代码注释记0视为未提供；不将缓存和推理子集重复相加。NaN等未扩展成额外扣分项。
- 未运行 Docker、多副本、生产压测，不属于本周强制要求。未尝试 Anthropic 协议，因为学生没有该适配器且禁止访问其他供应商；Chat + Responses 已是真实两协议。
- Responses 的真实 JSON约束没有宣称通过；其本地受控失败已足以证明格式被吞。没有把模拟通过写成真实成功，没有环境阻塞未验证项被扣成代码分。

## 复现入口及证据目录

包中 `REPRODUCE.md` 给出从固定提交重建环境、启动受控服务、运行学生脚本、教师门控测试和真实调用的命令。主要文件：

- `harness.py`：受控 HTTP 上游、隔离配置生成、双模型正常/JSON/模板/重试/配额/门控脚本；不记录请求头。
- `supplement.py`：带备用链断流、Responses 格式被吞、两协议门控及实际请求数。
- `inject_failure.py`：只在该测试进程的夹具内注入错误内容，确认学生断言失败。
- `verify.py`：对证据做可复现断言，包含明确已发现的缺陷断言。
- `mock.yaml`、`real.yaml`：只含环境变量名、假密钥变量引用、地址和非敏感配置，无实际凭据。
- `*-results.json`、`*-traces.jsonl`、`*-run.log`、`gateway-*.log`、`upstream.log`：脱敏请求体、响应、日志、最终审计；数据库另导出为 JSON，不需要上传数据库文件。
- `student-source/`、`source-blobs.txt`、`SHA256SUMS`：固定提交的源码/测试/依赖与文件校验。未保存学生或教师 `.env`，未保存运行鉴权头。
- `verification.log`、`report-check.json`、`secret-scan.json`、`services-stopped.log`：证据断言、报告字数及总分检查、安全检查和服务停止确认。

初次 mock 测试的空内容500关闭连接使测试客户端下一次复用连接报 ReadError；保留 `mock-initial.log`，随后教师客户端改为 Connection: close 隔离每次观测。该修改只在评测工具，不在学生业务；重跑所得 `mock-results.json` 是完整正式结果。服务启动后先探活再执行，避免启动竞态误判学生失败。

## 补交要求

- 必须修复：统一入口按模型选择协议、Responses 结构约束与空正文处理、输出后的跨模型重复生成、成功终态识别、已知用量汇总及入口失败记录、上游错误可识别性。
- 必须补充证据：同一入口只改 model 即发两协议的实收请求；两模型普通/流式/JSON真实记录；主备流中断不重发；空JSON和多次修复失败返回统一错误；每次已知消耗能核对到账本，入口失败能按ID查询。
- 复验通过条件：上列失败用例回归通过，原有测试仍通过；不得以 Mock 替代真实模型证据。等级仍按总分，验收结论不另作封顶。
- 交付状态：本次仅新增反馈、附件和脱敏证据包；没有提交或推送，没有修改共享外部服务。评测服务结束后停止。
