# G20261786010571 第一次提交复现说明

评测固定提交：`b667e7cf4ee2c4fda6107a8e776600ca65c8c18a`，仓库 `https://gitee.com/libuzuan/mini-llm-gateway`，日期 2026-11-14 Asia/Singapore。真实 git clone 成功，不是网页快照。证据源文件 SHA256 在 SHA256SUMS，学生 Git blob 清单在 source-blobs.txt。student-source 保留 app、tests、依赖及非敏感配置；不复制 .env。README 的 Git blob 在清单中，本包不复制含示例鉴权头的 README 文本。学生源码未改。

## 从源码重建

把证据包解压到一个目录，脚本在目录顶层。在其中重新克隆 student；student-source 用于源码复核，完整安装所需 README 从固定仓库取得。以下命令在 orb 的终端运行；只读证据验证不需要服务或密钥。

```bash
git clone https://gitee.com/libuzuan/mini-llm-gateway.git student
git -C student checkout --detach b667e7cf4ee2c4fda6107a8e776600ca65c8c18a
cd student
uv sync --extra dev
uv run pytest -v
uv run ruff check app/ tests/
uv run python ../harness.py prepare
```

prepare 会重新生成 mock.yaml 和 real.yaml 中的绝对存储路径，其他评测参数一致。为完全重跑，可在停止旧评测服务后删除该证据目录下生成的 mock.db、extra.db、mock-traces.jsonl、extra-traces.jsonl；切勿删除其他目录数据。学生模板发布版本由1起，所以重跑 mock 时应使用新目录/新数据库。

## 启动受控上游与真实学生网关

以下命令在 student 工作目录运行；受控上游只收到 GRADING_DUMMY_KEY 假值，不读取或记录真实密钥。mock.yaml/real.yaml 均由 prepare 生成，无密钥值。不要启用 HTTP debug 请求头日志。

```bash
ROOT=$(realpath ..)
amp orb service start grade-10571-upstream --port 18761 --command "PYTHONPATH=$ROOT $PWD/.venv/bin/uvicorn harness:upstream --host 127.0.0.1 --port 18761"
amp orb service start grade-10571-mock --port 18762 --command "GATEWAY_CONFIG_FILE=$ROOT/mock.yaml GRADING_DUMMY_KEY=controlled-placeholder $PWD/.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 18762"
curl --fail http://127.0.0.1:18762/healthz
uv run python ../harness.py mock
PYTHONPATH="$PWD" uv run python ../supplement.py
uv run python ../inject_failure.py
```

若探活暂时连接失败，等待服务就绪后再执行脚本，不把启动竞态当学生错误。inject_failure.py 的预期结果是原学生测试1项内容断言失败、退出1，其他脚本正常完成并写 JSON。supplement.py 使用真实 OpenAI SDK 向受控上游发 HTTP，请求数包含 SDK 实收，非 FakeProvider 次数。

## 真实调用（消耗真实配额，复验者自行决定是否重跑）

只在进程环境已安全注入 DEEPSEEK_API_KEY secret 时运行，不向文件写密钥，不打印环境值，不创建 .env。仅 https://api.deepseek.com，模型 general-primary→deepseek-v4-pro，general-backup→deepseek-flash。普通/流式/JSON均走Chat；另测pro的Responses普通和流式。

```bash
amp orb service start grade-10571-real --port 18763 --command "GATEWAY_CONFIG_FILE=$ROOT/real.yaml $PWD/.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 18763"
curl --fail http://127.0.0.1:18763/healthz
uv run python ../harness.py real
uv run python ../verify.py
```

注意：脚本申请128输出Token，但学生丢弃预算参数，无法通过配置设置硬输出上限；评测没有修改业务逻辑绕过这一限制。原次实际调用均很短，输出11–49Token，重试配置为0；未来真实调用费用和耗时不能保证相同。若上游不可用，应标未验证，不将环境失败认定为代码错误。

verify.py 可直接对原证据执行，无需重跑任何收费请求。它断言已观察到的缺陷仍存在，所以输出 PASS 不是功能全通过声明。若学生修复了缺陷，这些“缺陷存在”断言应该失败，应另写验收新期望。

## 停止服务

```bash
amp orb service stop grade-10571-upstream
amp orb service stop grade-10571-mock
amp orb service stop grade-10571-real
```

本次已停止服务，见 services-stopped.log。所有请求头均不进入证据；日志只含短测试输入、模型输出、关联ID及用量。secret-scan.json 记录归档成员/真实环境密钥字节/常见凭据模式扫描结果，不记录任何密钥值。
