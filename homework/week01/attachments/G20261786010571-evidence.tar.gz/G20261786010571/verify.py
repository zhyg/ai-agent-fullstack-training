"""Assert recorded evidence, including defects (not a student pass-rate score)."""
import json
from pathlib import Path

R = Path(__file__).resolve().parent
mock = json.loads((R/'mock-results.json').read_text())
cases = {x['name']: x for x in mock['cases']}
trace = {t['request_id']: t for t in mock['traces']}
for alias in ('general-primary', 'general-backup'):
    assert cases['normal-'+alias]['result']['status'] == 200
    g = cases['stream-gate-'+alias]
    assert g['result']['content_before_release'] and len(g['upstream']['calls']) == 1
    assert '[DONE]' not in ''.join(g['result']['before_release'])
    assert '[DONE]' in ''.join(g['result']['lines'])
    b = cases['stream-break-'+alias]
    assert 'upstream_stream_failed' in ''.join(b['result']['lines']) and len(b['upstream']['calls']) == 1
    assert '[DONE]' not in ''.join(b['result']['lines'])
    assert '[DONE]' in ''.join(cases['stream-eof-'+alias]['result']['lines'])
for name in ('invalid', 'truncated', 'mismatch'):
    x = cases['json-'+name]
    assert x['result']['status'] == 502 and len(x['upstream']['calls']) == 3
    assert trace[x['result']['request_id']]['input_tokens'] == 0  # observed known-usage loss
assert cases['json-empty']['result']['status'] == 500
assert cases['json-repair']['result']['status'] == 200
assert trace[cases['json-repair']['result']['request_id']]['input_tokens'] == 19  # not 38
for name in ('retry', 'always429'):
    calls = cases[name]['upstream']['calls']
    assert len(calls) == 3
    waits = [calls[i]['time']-calls[i-1]['time'] for i in (1, 2)]
    assert .09 <= waits[0] < .18 and .19 <= waits[1] < .3
for name in ('always400', 'always401', 'always500'):
    assert len(cases[name]['upstream']['calls']) == 1
assert cases['unknown-model']['result']['status'] == 400
assert cases['unknown-model']['result']['request_id'] not in trace
assert cases['missing-variable']['result']['request_id'] not in trace
assert cases['template-1']['upstream']['calls'][-1]['body']['messages'][0]['content'] == 'version1 Ada'
assert cases['template-2']['upstream']['calls'][-1]['body']['messages'][0]['content'] == 'version2 Ada'
for n in ('template-99', 'missing-variable', 'missing-template'):
    assert cases[n]['result']['status'] == 400
quota = [x['result']['status'] for x in mock['cases'] if x['name'].startswith('quota-')]
assert quota == [200, 429, 200, 200]
gtrace = [t for t in mock['traces'] if t['stream'] and t['input_tokens'] == 19][0]
assert (gtrace['cached_tokens'], gtrace['reasoning_tokens'], gtrace['output_tokens']) == (5, 3, 7)
assert gtrace['first_token_ms'] is not None
extra = {x['name']: x for x in json.loads((R/'supplement-results.json').read_text())['cases']}
assert extra['fallback-after-content']['text'].count('片段') == 2
assert len(extra['fallback-after-content']['upstream']['calls']) == 2
assert extra['responses-json-invalid']['status'] == 200
assert extra['responses-json-invalid']['body']['output'][0]['content'][0]['text'] == 'not json'
assert 'text' not in extra['responses-json-invalid']['upstream']['calls'][0]['body']
assert len(extra['fallback-always429']['upstream']['calls']) == 6
assert len(extra['fallback-always400']['upstream']['calls']) == 2
for m in ('gate', 'break', 'eof'):
    x = extra['responses-stream-'+m]
    assert 'delta' in ''.join(x['before_release'])
    assert len(x['upstream']['calls']) == 1
assert 'response.completed' in ''.join(extra['responses-stream-gate']['lines'])
assert 'event: error' in ''.join(extra['responses-stream-break']['lines'])
assert 'response.completed' not in ''.join(extra['responses-stream-eof']['lines'])
real = json.loads((R/'real-results.json').read_text())
assert len(real) == 8 and all(x['status'] == 200 for x in real)
for x in real[:6]:
    if x['kind'] == 'json':
        assert json.loads(x['body']['choices'][0]['message']['content']) == {'ok': True}
    elif x['kind'] == 'normal':
        assert x['body']['choices'][0]['message']['content'] == 'OK'
    else:
        assert '[DONE]' in x['body'] and 'OK' in x['body']
print('Evidence assertions PASS: 8 real calls; gated streams; retry wire counts; quotas; templates; reproduced defects.')
