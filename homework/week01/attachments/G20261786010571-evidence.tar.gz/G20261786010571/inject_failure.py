"""Verify the student's existing assertion detects a bad response, without editing it."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent/'student'))
from tests.conftest import FakeProvider

original = FakeProvider.complete


async def faulty(self, *args, **kwargs):
    text, usage = await original(self, *args, **kwargs)
    return 'CONTROLLED_WRONG_CONTENT', usage


FakeProvider.complete = faulty
raise SystemExit(pytest.main(['-v', 'tests/test_gateway.py::test_non_stream_with_prompt_template']))
