"""Finite socket-level teacher tests; only adapter connection config is replaced."""
import asyncio, json, os, sys, time
from pathlib import Path
sys.path.insert(0, '/tmp/grade-yun/student')
import httpx, uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse
from gateway import server
from gateway.adapter import Model, StreamingModelAdapter
from gateway.agent import Agent
from gateway.run_store import create_run_store

OUT = Path(__file__).parent
mock = FastAPI()
mode = 'normal'
calls = []
gate = asyncio.Event()

@mock.post('/v1/chat/completions')
async def upstream(request: Request):
    body = await request.json()
    calls.append({'path':request.url.path, 'body':body, 'at':time.monotonic()})
    if mode in ('503','400','retry'):
        status = 503 if mode != '400' else 400
        if mode != 'retry' or len(calls) < 3:
            return JSONResponse({'error':{'message':'controlled failure'}}, status_code=status)
    async def chunks():
        def event(delta, finish=None, usage=None):
            return 'data: '+json.dumps({'choices':[{'delta':delta,'finish_reason':finish}], 'usage':usage})+'\n\n'
        yield event({})
        await asyncio.sleep(.12)
        text = {'illegal':'not-json','empty':'','truncated':'{"x":'}.get(mode,'{"x":7}')
        yield event({'content':text})
        if mode == 'gate':
            await gate.wait()
        if mode == 'broken':
            yield 'data: {bad\n\n'
            return
        if mode == 'eof':
            return
        usage = {'prompt_tokens':11,'completion_tokens':7,'total_tokens':18,
                 'prompt_cache_hit_tokens':3,'completion_tokens_details':{'reasoning_tokens':2}}
        yield event({}, 'length' if mode == 'truncated' else 'stop', usage)
        yield 'data: [DONE]\n\n'
    return StreamingResponse(chunks(), media_type='text/event-stream')

factory = StreamingModelAdapter()
server.adapter.create = lambda model: factory.create(model, api_url='http://127.0.0.1:18765/v1', api_key='teacher-placeholder')
results = []
def save(case, **data):
    row={'case':case, **data}; results.append(row)
    print(json.dumps(row,ensure_ascii=False),flush=True)

async def main():
    global mode
    services = [uvicorn.Server(uvicorn.Config(app, host='127.0.0.1',port=port,log_level='critical'))
                for app,port in [(mock,18765),(server.app,18766)]]
    tasks=[asyncio.create_task(s.serve()) for s in services]
    while not all(s.started for s in services): await asyncio.sleep(.03)
    try:
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18766',timeout=8) as client:
            save('A01', root=(await client.get('/')).status_code, openapi=(await client.get('/openapi.json')).json())
            r=await client.post('/chat/stream',data={'model':'unknown','message':'hi'})
            save('A04',status=r.status_code,body=r.text)
            for alias in ['openai','deepseek']:
                mode='gate'; calls.clear(); gate.clear(); received=[]
                async with client.stream('POST','/chat/stream',data={'model':alias,'message':'json please','stream':'true'}) as r:
                    async for line in r.aiter_lines():
                        if not line.startswith('data:'): continue
                        ev=json.loads(line[5:]); received.append(ev)
                        if ev.get('output') and not gate.is_set():
                            save('A03/F01',alias=alias,status=r.status_code,before_release=True,first=ev,upstream=calls.copy())
                            gate.set()
                save('F01-terminal',alias=alias,terminal=received[-1])
            for scenario in ['broken','eof','illegal','empty','truncated','retry','503','400']:
                mode=scenario; calls.clear()
                r=await client.post('/chat/stream',data={'model':'deepseek','message':'return json','response_format':'{"type":"json_object"}'})
                events=[json.loads(line[5:]) for line in r.text.splitlines() if line.startswith('data:')]
                save('F02/F03/F04/F08/F09',scenario=scenario,status=r.status_code,terminal=events[-1],attempts=len(calls),upstream=calls.copy())
            mode='normal'
            for version in ['v1','v2','missing']:
                calls.clear()
                r=await client.post('/chat/stream',data={'model':'deepseek','message':'Hello {{name}}','template_id':'greet','template_version':version})
                save('F05/F06',version=version,status=r.status_code,upstream=calls.copy())
            calls.clear()
            statuses=[]
            for i in range(12):
                statuses.append((await client.post('/chat/stream',data={'model':'deepseek','message':'hi'})).status_code)
            other=(await client.post('/chat/stream',data={'model':'openai','message':'hi'})).status_code
            await asyncio.sleep(.3)
            recovered=(await client.post('/chat/stream',data={'model':'deepseek','message':'hi'})).status_code
            save('F10/F11',a_statuses=statuses,b_status=other,after_wait=recovered,upstream_count=len(calls),note='No quota/window configuration exists; recovery cannot be demonstrated without exhaustion')
            records=await server.store.list(limit=100)
            save('F07',records=[r.model_dump(mode='json') for r in records])
            # Direct unified Python interface: response_format forwards, but no content validation.
            for alias in Model:
                for scenario in ['normal','illegal','empty','truncated']:
                    mode=scenario; calls.clear()
                    agent=Agent(factory.create(alias,api_url='http://127.0.0.1:18765/v1',api_key='teacher-placeholder'),create_run_store(), tools=[])
                    last=None
                    async for ev in agent.execute(3,[{'role':'user','content':'json'}],response_format={'type':'json_object'}): last=ev
                    save('F03/F04-python',alias=alias.value,scenario=scenario,terminal=last.model_dump(mode='json'),upstream=calls.copy())
    finally:
        for s in services:s.should_exit=True
        await asyncio.gather(*tasks)
        (OUT/'teacher-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

asyncio.run(main())
