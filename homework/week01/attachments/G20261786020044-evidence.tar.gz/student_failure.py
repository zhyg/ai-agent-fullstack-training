"""F12: connection-layer fixture returns 400; student assertions unchanged."""
import sys,runpy,httpx
sys.path.insert(0,'/tmp/grade-yun/student')
original=httpx.AsyncClient
class Client(original):
    def __init__(self,*args,**kwargs):
        kwargs['transport']=httpx.MockTransport(lambda request:httpx.Response(400,json={'error':{'message':'teacher induced invalid request'}},request=request))
        super().__init__(*args,**kwargs)
httpx.AsyncClient=Client
runpy.run_path('/tmp/grade-yun/student/tests/test_agent.py',run_name='__main__')
