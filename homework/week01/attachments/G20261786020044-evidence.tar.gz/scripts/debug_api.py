import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio
import json

import httpx


async def main() -> None:
    key = os.getenv("DEEPSEEK_API_KEY", "")
    url = "https://api.deepseek.com/chat/completions"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

    # 模拟第一轮: 模型请求了工具
    messages = [
        {"role": "user", "content": "帮我算一下 (1+2)*4"},
    ]
    # 第二轮: assistant tool_calls + tool 结果
    payload = {
        "model": "deepseek-chat",
        "messages": messages
        + [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_abc",
                        "type": "function",
                        "function": {"name": "calculator", "arguments": '{"expression": "(1+2)*4"}'},
                    }
                ],
            },
            {"role": "tool", "tool_call_id": "call_abc", "content": "12"},
        ],
        "stream": False,
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(url, json=payload, headers=headers)
        print("status:", resp.status_code)
        print(resp.text[:2000])


if __name__ == "__main__":
    asyncio.run(main())