import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio

from gateway.adapter import Model, StreamingModelAdapter
from gateway.agentloop import AgentLoop
from gateway.models import RunEvent, RunStatus
from gateway.run_store import create_run_store


async def main() -> None:
    store = create_run_store()
    model = StreamingModelAdapter().create(Model.DEEPSEEK)
    loop = AgentLoop(model=model, store=store)

    messages = [{"role": "user", "content": "请用一句话简单介绍你自己。并且调用我的天气工具，查询北京的天气。"}]
    count = 0
    async for ev in loop.execute(user_id=7, messages=messages, temperature=0.3):
        count += 1
        last = ev

    print("=" * 40)
    print("total chunks:", count)
    print("last.status:", last.run_status.value)
    print("last.stop_reason:", last.stop_reason)
    print("last.user_id:", last.user_id)
    print("stored count for user 7:", await store.count(user_id=7))

    history = await store.list(user_id=7)
    print("history size:", len(history))
    persisted = history[0]
    print("persisted run_id:", persisted.run_id)
    print("persisted output:", persisted.agent_output)
    print("persisted status:", persisted.run_status.value)
    print("e2e OK!" if persisted.run_status == RunStatus.COMPLETED else "e2e FAILED")


if __name__ == "__main__":
    asyncio.run(main())