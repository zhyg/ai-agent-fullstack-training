import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio

from gateway.adapter import Model, StreamingModelAdapter
from gateway.agent import Agent
from gateway.models import RunEvent, RunStatus
from gateway.run_store import create_run_store


async def main() -> None:
    store = create_run_store()
    model = StreamingModelAdapter().create(Model.DEEPSEEK)
    agent = Agent(model=model, store=store)

    # ---------- 场景1: 普通对话, 不需要工具 ----------
    print("=" * 50)
    print("场景1: 普通对话(不需要工具)")
    messages = [{"role": "user", "content": "你好，我是一名it工程师，正在学习agent开发，你能给我一些学习建议么？。"}]
    count = 0
    async for ev in agent.execute(user_id=1, messages=messages, temperature=0.3):
        count += 1
        last = ev

    print(f"  chunks: {count}")
    print(f"  status: {last.run_status.value}")
    print(f"  stop_reason: {last.stop_reason}")
    print(f"  output: {last.agent_output}")
    assert last.run_status == RunStatus.COMPLETED, f"期望 COMPLETED, 实际 {last.run_status.value}"

    # ---------- 场景2: 需要工具调用 ----------
    print()
    print("=" * 50)
    print("场景2: 需要工具调用(查询时间)")
    messages = [{"role": "user", "content": "现在北京几点了? 请通过调用工具获取准确时间。"}]
    count = 0
    tool_calls_seen = False
    async for ev in agent.execute(user_id=2, messages=messages, temperature=0.3):
        count += 1
        last = ev
        if ev.tool_calls:
            tool_calls_seen = True
            for tc in ev.tool_calls:
                print(f"  [tool-request] {tc.name}({tc.arguments}) status={tc.status}")

    print(f"  chunks: {count}")
    print(f"  status: {last.run_status.value}")
    print(f"  stop_reason: {last.stop_reason}")
    print(f"  tool_calls_seen: {tool_calls_seen}")
    print(f"  output: {last.agent_output}")

    # ---------- 场景3: 模型明确 stop, 不调工具 ----------
    print()
    print("=" * 50)
    print("场景3: 模型直接回答(不调工具)")
    messages = [{"role": "user", "content": "1+1等于几? 直接回答, 不要调用计算器工具。"}]
    count = 0
    async for ev in agent.execute(user_id=3, messages=messages, temperature=0.3):
        count += 1
        last = ev

    print(f"  chunks: {count}")
    print(f"  status: {last.run_status.value}")
    print(f"  stop_reason: {last.stop_reason}")
    print(f"  output: {last.agent_output}")
    assert last.stop_reason == "stop", f"期望 stop, 实际 {last.stop_reason}"

    # ---------- 验证 Store ----------
    print()
    print("=" * 50)
    print("Store 验证")
    for uid in [1, 2, 3]:
        n = await store.count(user_id=uid)
        print(f"  user_id={uid}: {n} 条记录")
        assert n > 0, f"user_id={uid} 无记录"

    print()
    print("ALL PASSED!")


if __name__ == "__main__":
    asyncio.run(main())