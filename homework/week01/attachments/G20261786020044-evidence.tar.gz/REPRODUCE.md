# Teacher grading evidence

Student: G20261786020044, じ☆v云影寒
Repository: https://gitee.com/yunyinghan/agent_stream_gateway
Branch: master
Commit: f3950bb078a008428cf82598651c6c5139056f73
Assessment date: 2026-11-08 Asia/Singapore

No student business logic changed. Source tree and blob IDs: source-tree.txt.
Dependencies inferred because README and dependency manifests are absent.

Commands run:

    uv venv /tmp/grade-yun/venv
    uv pip install --python /tmp/grade-yun/venv/bin/python fastapi uvicorn python-multipart httpx
    /tmp/grade-yun/venv/bin/python /tmp/grade-yun/evidence/teacher.py
    timeout 65 /tmp/grade-yun/venv/bin/python -u tests/test_agent.py
    timeout 65 /tmp/grade-yun/venv/bin/python -u tests/test_agent_loop.py
    timeout 65 /tmp/grade-yun/venv/bin/python -u scripts/debug_api.py
    /tmp/grade-yun/venv/bin/python /tmp/grade-yun/evidence/student_failure.py
    /tmp/grade-yun/venv/bin/python /tmp/grade-yun/evidence/real.py

Student commands use student root as cwd. Teacher scripts contain absolute source
paths for this orb: replace these paths when reproducing from an unpacked archive.
real.py and student real scripts require existing DEEPSEEK_API_KEY in the environment.
No credentials are embedded or archived. real.py OpenAI class is explicitly
configured to DeepSeek official URL and model; this is NOT a second-model or
second-protocol proof. Only observed upstream IDs, usage, responses and timings
are retained. No request authorization headers are logged.

Exit codes: teacher 0, student scripts 0/0/0, induced failure 1, real 0.
Teacher completion exit 0 is not a feature-pass assertion; consult case results.
Teacher servers run only for finite test duration and shut down in finally.
Full grading decisions, per-case outcomes, limitations and deductions are in the
accompanying G20261786020044.md assessment attachment.
