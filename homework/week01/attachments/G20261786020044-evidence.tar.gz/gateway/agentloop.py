import json
import time
import traceback
import uuid
from typing import Any, AsyncGenerator, Dict, List, Optional

from .adapter import StreamingModel
from .models import RunEvent, RunStatus, RunType, ToolCall
from .run_store import RunStore
from .tools import Tool, build_schemas, find_tool, DEFAULT_TOOLS


class AgentLoop:
    """Agent 主循环(支持多轮工具调用)。

    职责:
      1. 为一次执行生成 run_id(可外部指定);
      2. 循环调用流式模型:
         - 模型若请求工具, 则执行对应工具、把结果追加回对话, 再进入下一轮;
         - 模型若直接作答, 则结束本轮回复;
      3. 将产出的每个 RunEvent 逐步保存到 RunStore 并转发给上层。
    """

    def __init__(self, model: StreamingModel, store: RunStore,
                 tools: Optional[List[Tool]] = None, max_iterations: int = 8):
        self.model = model
        self.store = store
        self.tools: List[Tool] = tools if tools is not None else DEFAULT_TOOLS
        self.max_iterations = max_iterations

    async def execute(
        self,
        user_id: int,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        run_id: Optional[str] = None,
        **kwargs,
    ) -> AsyncGenerator[RunEvent, None]:
        rid = run_id or uuid.uuid4().hex
        turns: int = 0
        try:
            while turns < self.max_iterations:
                print(f"    [Agent] 第 {turns} 轮调用")
                print(f"    [Agent] 输入: {messages}")
                turns += 1
                # 一轮模型调用(流式逐个产出事件)
                last: Optional[RunEvent] = None
                async for ev in self.model.call_model(
                    rid, user_id, messages, temperature,
                    tools=build_schemas(self.tools), **kwargs,
                ):
                    last = ev
                    yield ev

               
                # 根据模型返回的 finish_reason 决定下一步
                # - tool_calls: 执行工具, 进入下一轮
                # - stop:       模型完成, 退出循环
                # - 其他/None:  模型未明确通知, 也退出循环(兜底)
                # - max_iterations: 安全上限, 达到后强制退出
                if last is not None and last.stop_reason == "tool_calls" and last.tool_calls:
                    print(f"    [Agent] 模型请求工具: {[tc.name for tc in last.tool_calls]}")
                    await self._execute_tools(last.tool_calls, messages)
                    continue

                if last is not None and last.stop_reason == "stop":
                    await self.store.save(last)
                    return

                # stop_reason 为 None / "length" / "content_filter": 兜底退出
                if last is not None:
                    await self.store.save(last)
                return
        except Exception as exc:
            error_ev = self._build_trace_event(
                rid, user_id, messages, RunStatus.FAILED,
                message=str(exc), error=traceback.format_exc(),
            )
            await self.store.save(error_ev)
            yield error_ev

    async def _execute_tools(
        self,
        tool_calls: List[ToolCall],
        messages: List[Dict[str, Any]],
    ) -> None:
        """按顺序执行所有工具调用, 把结果以 tool 消息追加进对话。"""
        assistant_tool_calls = []
        tool_result_messages = []
        for idx, tc in enumerate(tool_calls):
            # 确保每个工具调用都有稳定的 id(模型未给时自动生成)
            if not tc.id:
                tc.id = f"call_{uuid.uuid4().hex[:12]}"

            tool = find_tool(tc.name, self.tools)
            if tool is None:
                tc.status = "error"
                tc.result = f"工具 {tc.name} 不存在"
                tool_result_messages.append(
                    {"role": "tool", "tool_call_id": tc.id, "content": tc.result}
                )
                assistant_tool_calls.append({
                    "id": tc.id, "type": "function",
                    "function": {"name": tc.name, "arguments": "{}"},
                })
                continue

            started = time.perf_counter()
            try:
                result = tool.call(**tc.arguments)
                tc.status = "success"
                tc.result = result
            except Exception as exc:
                tc.status = "error"
                tc.result = f"执行错误: {exc}"
            tc.duration_ms = round((time.perf_counter() - started) * 1000, 2)

            assistant_tool_calls.append({
                "id": tc.id,
                "type": "function",
                "function": {"name": tc.name, "arguments": json.dumps(tc.arguments, ensure_ascii=False)},
            })
            tool_result_messages.append(
                {"role": "tool", "tool_call_id": tc.id, "content": tc.result}
            )

        # assistant 的工具调用声明必须放在 tool 结果消息之前
        messages.append({
            "role": "assistant",
            "content": None,
            "tool_calls": assistant_tool_calls,
        })
        messages.extend(tool_result_messages)

    def _build_trace_event(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        status: RunStatus,
        message: str = "",
        error: Optional[str] = None,
    ) -> RunEvent:
        return RunEvent(
            run_id=run_id,
            user_id=user_id,
            run_type=RunType.STREAM,
            run_status=status,
            user_input=self._last_user_message(messages),
            run_message=message,
            error=error,
            model_name=self.model.model_name,
        )

    @staticmethod
    def _last_user_message(messages: List[Dict[str, Any]]) -> str:
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content")
                if isinstance(content, str):
                    return content
                return str(content)
        return ""