"""内置工具集合: 北京时间、计算器、天气。"""
from __future__ import annotations

import ast
import operator
import random
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional


class Tool:
    """一个可被模型调用的工具。"""

    def __init__(self, name: str, description: str, parameters: Dict[str, Any],
                 func: Callable[..., Any]):
        self.name = name
        self.description = description
        self.parameters = parameters
        self.func = func

    def schema(self) -> Dict[str, Any]:
        """返回 OpenAI 兼容的工具声明。"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    def call(self, **kwargs) -> str:
        """执行工具并返回字符串结果。"""
        return str(self.func(**kwargs))


class BeijingTimeTool(Tool):
    def __init__(self):
        super().__init__(
            name="get_beijing_time",
            description="获取当前北京时间(UTC+8)",
            parameters={
                "type": "object",
                "properties": {},
                "required": [],
            },
            func=lambda: self._now(),
        )

    @staticmethod
    def _now() -> str:
        bj = timezone(timedelta(hours=8))
        return datetime.now(bj).strftime("%Y-%m-%d %H:%M:%S")


def _safe_eval(expr: str) -> str:
    """安全地求值四则运算表达式。"""
    node = ast.parse(expr, mode="eval").body
    ops = {
        ast.Add: operator.add, ast.Sub: operator.sub,
        ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod,
    }

    def walk(n: ast.AST) -> float:
        if isinstance(n, ast.Constant):
            # 若是字符串常量(如带引号的表达式), 则去除引号后再次求值
            if isinstance(n.value, str):
                return walk(ast.parse(n.value.strip("'\""), mode="eval").body)
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in ops:
            return ops[type(n.op)](walk(n.left), walk(n.right))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            v = walk(n.operand)
            return v if isinstance(n.op, ast.UAdd) else -v
        raise ValueError(f"不支持的表达片段: {type(n).__name__}")

    result = walk(node)
    if isinstance(result, float):
        return f"{result:.4f}".rstrip("0").rstrip(".")
    return str(result)


class CalculatorTool(Tool):
    def __init__(self):
        super().__init__(
            name="calculator",
            description="计算四则运算表达式, 如 (1+2)*3",
            parameters={
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "要计算的算术表达式"},
                },
                "required": ["expression"],
            },
            func=lambda expression: _safe_eval(expression),
        )


class WeatherTool(Tool):
    """模拟天气工具, 便于本地演示。"""

    def __init__(self):
        super().__init__(
            name="get_weather",
            description="查询指定城市的天气",
            parameters={
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "城市名"},
                },
                "required": ["city"],
            },
            func=self._weather,
        )

    @staticmethod
    def _weather(city: str) -> str:
        cond = random.choice(["晴", "多云", "阴", "小雨", "中雨"])
        temp = random.randint(-5, 35)
        print(f"    {city} 天气: {cond}, {temp}°C")
        return f"{city} 天气: {cond}, {temp}°C"


DEFAULT_TOOLS: List[Tool] = [
    BeijingTimeTool(),
    CalculatorTool(),
    WeatherTool(),
]


def build_schemas(tools: Optional[List[Tool]] = None) -> List[Dict[str, Any]]:
    """把 Tool 列表转成模型入参的 tools schema。"""
    return [t.schema() for t in (tools if tools is not None else DEFAULT_TOOLS)]


def find_tool(name: str, tools: Optional[List[Tool]] = None) -> Optional[Tool]:
    for t in (tools if tools is not None else DEFAULT_TOOLS):
        if t.name == name:
            return t
    return None