from abc import ABC, abstractmethod
from typing import Any, List, Optional

from .models import RunEvent, RunStatus


class RunStore(ABC):
    """运行记录存储抽象接口。

    负责持久化每次 Agent 执行产生的 RunEvent,
    上层(agent loop 等)只依赖本抽象, 便于替换为数据库实现。
    """

    @abstractmethod
    async def save(self, run: RunEvent) -> None:
        """新增或覆盖一次运行记录。"""
        raise NotImplementedError

    @abstractmethod
    async def get(self, run_id: str) -> Optional[RunEvent]:
        """按运行 id 查询单条记录, 不存在返回 None。"""
        raise NotImplementedError

    @abstractmethod
    async def list(
        self,
        user_id: Optional[int] = None,
        status: Optional[RunStatus] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[RunEvent]:
        """分页列出运行记录, 支持按用户与状态过滤。"""
        raise NotImplementedError

    @abstractmethod
    async def count(
        self,
        user_id: Optional[int] = None,
        status: Optional[RunStatus] = None,
    ) -> int:
        """统计运行记录数量, 可用于分页。"""
        raise NotImplementedError

    @abstractmethod
    async def delete(self, run_id: str) -> bool:
        """删除一条运行记录, 存在并删除返回 True。"""
        raise NotImplementedError

    @abstractmethod
    async def clear(self) -> None:
        """清空全部运行记录。"""
        raise NotImplementedError

    @abstractmethod
    async def close(self) -> None:
        """释放底层资源(如数据库连接)。"""
        raise NotImplementedError


class InMemoryRunStore(RunStore):
    """基于内存字典的线程安全实现, 供开发与联调使用。"""

    def __init__(self) -> None:
        self._store: dict[str, RunEvent] = {}
        self._lock: Any = None
        try:
            import asyncio
            self._lock = asyncio.Lock()
        except Exception:
            import threading
            self._lock = threading.Lock()

    async def save(self, run: RunEvent) -> None:
        async with self._lock:
            self._store[run.run_id] = run

    async def get(self, run_id: str) -> Optional[RunEvent]:
        async with self._lock:
            return self._store.get(run_id)

    def _filter(
        self,
        items: List[RunEvent],
        user_id: Optional[int] = None,
        status: Optional[RunStatus] = None,
    ) -> List[RunEvent]:
        if user_id is not None:
            items = [r for r in items if r.user_id == user_id]
        if status is not None:
            items = [r for r in items if r.run_status == status]
        return items

    async def list(
        self,
        user_id: Optional[int] = None,
        status: Optional[RunStatus] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[RunEvent]:
        async with self._lock:
            items = list(self._store.values())
        items = self._filter(items, user_id=user_id, status=status)
        items.sort(key=lambda r: r.started_at, reverse=True)
        return items[offset:offset + limit]

    async def count(
        self,
        user_id: Optional[int] = None,
        status: Optional[RunStatus] = None,
    ) -> int:
        async with self._lock:
            items = list(self._store.values())
        return len(self._filter(items, user_id=user_id, status=status))

    async def delete(self, run_id: str) -> bool:
        async with self._lock:
            return self._store.pop(run_id, None) is not None

    async def clear(self) -> None:
        async with self._lock:
            self._store.clear()

    async def close(self) -> None:
        async with self._lock:
            self._store.clear()


def create_run_store(backend: str = "memory", **kwargs) -> RunStore:
    """工厂方法: 根据 backend 创建对应实现, 现仅支持 memory。"""
    if backend == "memory":
        return InMemoryRunStore(**kwargs)
    raise ValueError(f"不支持的存储后端: {backend}")