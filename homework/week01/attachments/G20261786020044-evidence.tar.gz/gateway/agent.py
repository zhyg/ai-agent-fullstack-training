import json
import time
import traceback
import uuid
from typing import Any, AsyncGenerator, Dict, List, Optional

from .adapter import StreamingModel
from .models import RunEvent, RunStatus, RunType, ToolCall
from .run_store import RunStore
from .tools import Tool, build_schemas, find_tool, DEFAULT_TOOLS


class Agent:
    """单次 Agent 调用(不做循环)。

    职责:
      1. 为一次执行生成 run_id(可外部指定);
      2. 调用一次流式模型, 产出 RunEvent;
      3. 如果模型请求工具(stop_reason="tool_calls"), 执行工具并把结果作为最终输出返回;
      4. 如果模型直接作答(stop_reason="stop"), 直接返回模型输出。
    """

    def __init__(self, model: StreamingModel, store: RunStore,
                 tools: Optional[List[Tool]] = None):
        self.model = model
        self.store = store
        self.tools: List[Tool] = tools if tools is not None else DEFAULT_TOOLS

    async def execute(
        self,
        user_id: int,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        run_id: Optional[str] = None,
        **kwargs,
    ) -> AsyncGenerator[RunEvent, None]:
        """单次模型调用。模型请求工具时执行工具, 返回工具结果。"""
        rid = run_id or uuid.uuid4().hex

        try:
            last: Optional[RunEvent] = None
            async for ev in self.model.call_model(
                rid, user_id, messages, temperature,
                tools=build_schemas(self.tools), **kwargs,
            ):
                last = ev
                yield ev

            # 保存最终事件(一次对话一条 RunEvent)
            if last is not None:
                if last.stop_reason == "tool_calls" and last.tool_calls:
                    print(f"    [Agent] 模型请求工具: {[tc.name for tc in last.tool_calls]}")
                    result_ev = await self._execute_and_respond(
                        rid, user_id, messages, last.tool_calls,
                    )
                    await self.store.save(result_ev)
                    yield result_ev
                else:
                    await self.store.save(last)

        except Exception as exc:
            error_ev = self._build_trace_event(
                rid, user_id, messages, RunStatus.FAILED,
                message=str(exc), error=traceback.format_exc(),
            )
            await self.store.save(error_ev)
            yield error_ev

    async def _execute_and_respond(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        tool_calls: List[ToolCall],
    ) -> RunEvent:
        """执行工具调用, 将工具结果以 RunEvent 返回。"""
        results: List[Dict[str, str]] = []
        for tc in tool_calls:
            if not tc.id:
                tc.id = f"call_{uuid.uuid4().hex[:12]}"

            tool = find_tool(tc.name, self.tools)
            started = time.perf_counter()
            if tool is None:
                tc.status = "error"
                tc.result = f"工具 {tc.name} 不存在"
            else:
                try:
                    tc.result = tool.call(**tc.arguments)
                    tc.status = "success"
                except Exception as exc:
                    tc.status = "error"
                    tc.result = f"执行错误: {exc}"
            tc.duration_ms = round((time.perf_counter() - started) * 1000, 2)

            results.append({
                "tool_call_id": tc.id,
                "name": tc.name,
                "arguments": json.dumps(tc.arguments, ensure_ascii=False),
                "result": tc.result,
                "status": tc.status,
            })

        event = RunEvent(
            run_id=run_id,
            user_id=user_id,
            run_type=RunType.TOOL,
            run_status=RunStatus.COMPLETED,
            user_input=self._last_user_message(messages),
            tool_calls=tool_calls,
            agent_output=json.dumps(results, ensure_ascii=False),
            model_name=self.model.model_name,
        )
        event.finish(message="工具执行完成")
        return event

    def _build_trace_event(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        status: RunStatus,
        message: str = "",
        error: Optional[str] = None,
    ) -> RunEvent:
        return RunEvent(
            run_id=run_id,
            user_id=user_id,
            run_type=RunType.STREAM,
            run_status=status,
            user_input=self._last_user_message(messages),
            run_message=message,
            error=error,
            model_name=self.model.model_name,
        )

    @staticmethod
    def _last_user_message(messages: List[Dict[str, Any]]) -> str:
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content")
                if isinstance(content, str):
                    return content
                return str(content)
        return ""