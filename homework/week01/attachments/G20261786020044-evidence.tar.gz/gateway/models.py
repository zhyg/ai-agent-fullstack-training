import traceback
from datetime import datetime
from enum import StrEnum
from typing import Any, Optional

from pydantic import BaseModel, Field


class ToolCall(BaseModel):
    """一次工具调用记录。"""
    id: Optional[str] = Field(None, description="工具调用ID(回传给模型用)")
    name: str = Field(description="工具名称")
    arguments: dict[str, Any] = Field(default_factory=dict, description="调用入参")
    result: Optional[str] = Field(None, description="工具返回结果")
    duration_ms: Optional[float] = Field(None, description="工具执行耗时(毫秒)")
    status: str = Field("success", description="调用状态: success / error")

class RunType(StrEnum):
    """运行类型。"""
    TEXT = "text"
    STREAM = "stream"
    TOOL = "tool"
    RETRY = "retry"
    CANCEL = "cancel"
    ERROR = "error"

class RunStatus(StrEnum):
    """运行状态。"""
    PENDING = "pending"
    RUNNING = "running"
    CANCELLED = "cancelled"
    FAILED = "failed"
    COMPLETED = "completed"
    TOOL_CALLS = "tool_calls"

class RunEvent(BaseModel):
    """Agent 单次执行的完整记录。

    覆盖从输入、模型调用、工具调用到输出、用量与异常的完整生命周期，
    便于后续统计、追踪与问题排查。
    """
    # 用户信息
    user_id: int = Field(description="用户ID(唯一标识一个用户)")

    # 运行信息
    run_id: str = Field(description="运行ID(唯一标识一次执行)")
    run_type: RunType = Field(description="运行类型, 如 text / stream / tool / retry")
    run_status: RunStatus = Field(description="运行状态: running / success / error / timeout")
    run_message: str = Field(default="", description="运行消息, 成功时的结果摘要或错误提示")

    # 本轮输入 / 输出
    user_input: str = Field(description="用户输入")
    agent_output: Optional[str] = Field(None, description="Agent 最终输出")

    # 模型信息
    model_name: Optional[str] = Field(None, description="使用的模型名称")
    model_kwargs: dict[str, Any] = Field(default_factory=dict, description="模型调用参数")
    usage: dict[str, int] = Field(
        default_factory=dict, description="Token 用量, 如 {prompt_tokens, completion_tokens, total_tokens}"
    )

    # 工具调用
    tool_calls: list[ToolCall] = Field(default_factory=list, description="本次执行的工具调用列表")

    # 模型停止原因
    stop_reason: Optional[str] = Field(None, description="模型停止原因: stop / tool_calls / length / content_filter")

    # 异常与元数据
    error: Optional[str] = Field(None, description="异常信息 / 堆栈")
    metadata: dict[str, Any] = Field(default_factory=dict, description="附加元数据")

    # 时间信息
    started_at: datetime = Field(default_factory=datetime.now, description="开始时间(创建时自动填充)")
    finished_at: Optional[datetime] = Field(None, description="结束时间")
    duration_ms: Optional[float] = Field(None, description="总耗时(毫秒)")

    @property
    def total_tokens(self) -> int:
        """便捷访问总 token 用量。"""
        return self.usage.get("total_tokens", 0)

    def finish(self, status: RunStatus = RunStatus.COMPLETED, message: str = "",
               error: Optional[str] = None) -> "RunEvent":
        """结束本次执行: 自动填充结束时间与耗时。"""
        self.finished_at = datetime.now()
        self.duration_ms = (self.finished_at - self.started_at).total_seconds() * 1000
        self.run_status = status
        self.run_message = message or self.run_message
        if error:
            self.error = error
            if self.run_status != RunStatus.FAILED:
                self.run_status = RunStatus.FAILED
        return self

    def __enter__(self) -> "RunEvent":
        """配合 with 使用, 进入时已自动填充 started_at。"""
        return self

    def __exit__(self, exc_type, exc_val, _exc_tb) -> None:
        """退出 with 块时自动填充结束时间与耗时。"""
        if exc_type is None:
            self.finish()
        else:
            self.finish(status=RunStatus.FAILED, message=str(exc_val), error=traceback.format_exc())