import json
import os
import traceback
from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Any, AsyncGenerator, Dict, List, Optional

from .models import RunEvent, RunStatus, RunType, ToolCall

# 常见的流式返回数据切分项
_DATA_PREFIX = "data:"
_DONE_FLAG = "[DONE]"


def _last_user_message(messages: List[Dict[str, Any]]) -> str:
    """从消息列表中取最后一条用户输入。"""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content")
            return content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)
    return ""


def _delta_text(data: dict) -> str:
    """从 OpenAI 兼容流式数据块中取出增量文本。"""
    for choice in data.get("choices", []):
        return choice.get("delta", {}).get("content") or ""
    return ""


def _delta_tool_calls(data: dict) -> List[dict]:
    """从流式数据块中取出工具调用增量(可能跨多个块分片返回)。"""
    result: List[dict] = []
    for choice in data.get("choices", []):
        for tc in choice.get("delta", {}).get("tool_calls") or []:
            fn = tc.get("function", {}) or {}
            if tc.get("id") or fn.get("name") or fn.get("arguments"):
                result.append({
                    "index": tc.get("index", 0),
                    "id": tc.get("id"),
                    "name": fn.get("name"),
                    "arguments": fn.get("arguments"),
                })
    return result


def _usage(data: dict) -> dict:
    """从数据块中取出 token 用量(若有)。"""
    return data.get("usage") or {}


def _finish_reason(data: dict) -> Optional[str]:
    """从流式数据块中取出 finish_reason(stop / tool_calls / length / content_filter)。"""
    for choice in data.get("choices", []):
        fr = choice.get("finish_reason")
        if fr:
            return fr
    return None


class Model(StrEnum):
    """模型类型。"""
    OPENAI = "openai"
    DEEPSEEK = "deepseek"


class StreamingModel(ABC):
    """流式模型统一基类, 默认初始化公用的连接信息。"""

    def __init__(self, api_url: str, api_key: str):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key

    @property
    def model_name(self) -> str:
        """默认模型名, 子类必须覆盖。"""
        raise NotImplementedError

    async def _stream_chat(
        self,
        messages: List[Dict[str, Any]],
        temperature: float,
        **kwargs,
    ) -> AsyncGenerator[dict, None]:
        """向 OpenAI 兼容的 /chat/completions 发起流式请求, 逐条产出原始数据块。

        OpenAI 与 DeepSeek 均遵循该协议, 故由基类统一实现。
        """
        import httpx

        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": kwargs.pop("model", self.model_name),
            "messages": messages,
            "temperature": temperature,
            "stream": True,
            **kwargs,
        }
        url = f"{self.api_url}/chat/completions"
        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream("POST", url, json=payload, headers=headers) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    line = line.strip()
                    if not line.startswith(_DATA_PREFIX) or line == _DATA_PREFIX + " " + _DONE_FLAG:
                        continue
                    yield json.loads(line[len(_DATA_PREFIX):])

    async def _call_stream(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        temperature: float,
        **kwargs,
    ) -> AsyncGenerator[RunEvent, None]:
        """通用流式调用骨架: 组装 RunEvent, 逐步产出增量事件。"""
        event = RunEvent(
            run_id=run_id,
            user_id=user_id,
            run_type=RunType.STREAM,
            run_status=RunStatus.RUNNING,
            user_input=_last_user_message(messages),
            model_name=kwargs.get("model", self.model_name),
        )
        # 累积分片的工具调用: index -> {id, name, arguments}
        tool_buffers: Dict[int, Dict[str, str]] = {}
        collected: str = ""
        finish_reason: Optional[str] = None
        try:
            async for data in self._stream_chat(messages, temperature, **kwargs):
                usage = _usage(data)
                if usage:
                    event.usage = usage
                fr = _finish_reason(data)
                if fr:
                    finish_reason = fr
                text = _delta_text(data)
                if text:
                    collected += text
                    event.agent_output = collected
                for tc in _delta_tool_calls(data):
                    buf = tool_buffers.setdefault(tc["index"], {"id": "", "name": "", "arguments": ""})
                    if tc["id"]:
                        buf["id"] = tc["id"]
                    if tc["name"]:
                        buf["name"] += tc["name"]
                    if tc["arguments"]:
                        buf["arguments"] += tc["arguments"]
                yield event
            event.tool_calls = [
                ToolCall(id=b["id"] or None, name=b["name"],
                         arguments=json.loads(b["arguments"]) if b["arguments"] else {})
                for b in sorted(tool_buffers.values(), key=lambda x: x["id"])
            ]
            event.stop_reason = finish_reason
            if finish_reason == "tool_calls":
                event.finish(status=RunStatus.TOOL_CALLS, message="模型请求工具调用")
            elif finish_reason == "stop":
                event.finish(message="流式输出完成")
            elif finish_reason == "length":
                event.finish(status=RunStatus.FAILED, message="达到最大 token 限制")
            else:
                event.finish(message="流式输出完成")
            yield event
        except Exception as exc:
            event.finish(status=RunStatus.FAILED, message=str(exc), error=traceback.format_exc())
            yield event

    @abstractmethod
    async def call_model(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        temperature: float,
        **kwargs,
    ) -> AsyncGenerator[RunEvent, None]:
        """调用模型, 返回流式输出。"""
        ...


class OpenAIStreamingModel(StreamingModel):
    """OpenAI 流式模型适配器。"""

    def __init__(self, api_url: str, api_key: Optional[str] = None):
        super().__init__(api_url=api_url, api_key=api_key or os.getenv("OPENAI_API_KEY") or "")

    @property
    def model_name(self) -> str:
        return "gpt-4o-mini"

    async def call_model(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        temperature: float,
        **kwargs,
    ) -> AsyncGenerator[RunEvent, None]:
        """调用 OpenAI 流式模型。"""
        async for event in self._call_stream(run_id, user_id, messages, temperature, **kwargs):
            yield event


class DeepSeekStreamingModel(StreamingModel):
    """DeepSeek 流式模型适配器。"""

    def __init__(self, api_url: str, api_key: Optional[str] = None):
        super().__init__(api_url=api_url, api_key=api_key or os.getenv("DEEPSEEK_API_KEY") or "")

    @property
    def model_name(self) -> str:
        return "deepseek-chat"

    async def call_model(
        self,
        run_id: str,
        user_id: int,
        messages: List[Dict[str, Any]],
        temperature: float,
        **kwargs,
    ) -> AsyncGenerator[RunEvent, None]:
        """调用 DeepSeek 流式模型。"""
        async for event in self._call_stream(run_id, user_id, messages, temperature, **kwargs):
            yield event


class StreamingModelAdapter:
    """根据模型类型创建对应的流式模型实例。

    各模型自行从对应环境变量读取 api_key:
      - OpenAI:  OPENAI_API_KEY
      - DeepSeek: DEEPSEEK_API_KEY
    """

    def create(self, model: Model, **kwargs) -> StreamingModel:
        api_url = kwargs.pop("api_url", f"https://api.{model.value}.com/v1")
        if model is Model.OPENAI:
            return OpenAIStreamingModel(api_url=api_url, **kwargs)
        if model is Model.DEEPSEEK:
            return DeepSeekStreamingModel(api_url=api_url, **kwargs)
        raise ValueError(f"不支持的模型类型: {model}")