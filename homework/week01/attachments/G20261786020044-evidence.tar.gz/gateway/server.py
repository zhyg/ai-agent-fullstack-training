import json
import uuid
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, StreamingResponse

from gateway.adapter import Model, StreamingModelAdapter
from gateway.agent import Agent
from gateway.run_store import create_run_store

app = FastAPI(title="Agent Gateway")

adapter = StreamingModelAdapter()
store = create_run_store()

HTML = (Path(__file__).parent / "index.html").read_text(encoding="utf-8")


@app.get("/", response_class=HTMLResponse)
async def index():
    return HTML


@app.post("/chat/stream")
async def chat_stream(
    request: Request,
    model: str = Form(...),
    message: str = Form(...),
    history: str = Form(default="[]"),
    file: Optional[UploadFile] = None,
):
    model_enum = Model(model)
    llm = adapter.create(model_enum)

    messages = json.loads(history) if isinstance(history, str) else history or []
    user_content = message

    if file and file.filename:
        content = (await file.read()).decode("utf-8", errors="replace")
        user_content = f"[文件: {file.filename}]\n{content}\n\n{message}" if message.strip() else f"[文件: {file.filename}]\n{content}"

    messages.append({"role": "user", "content": user_content})

    async def event_stream():
        rid = uuid.uuid4().hex
        agent = Agent(model=llm, store=store)
        try:
            async for ev in agent.execute(
                user_id=0, messages=messages, temperature=0.7, run_id=rid,
            ):
                if await request.is_disconnected():
                    break
                payload = {
                    "run_id": ev.run_id,
                    "status": ev.run_status.value,
                    "output": ev.agent_output or "",
                    "stop_reason": ev.stop_reason,
                    "tool_calls": [
                        {"name": tc.name, "arguments": tc.arguments, "result": tc.result, "status": tc.status}
                        for tc in (ev.tool_calls or [])
                    ],
                    "usage": ev.usage,
                    "error": ev.error,
                }
                yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
        except Exception as exc:
            yield f"data: {json.dumps({'status': 'failed', 'error': str(exc)}, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import uvicorn
    uvicorn.run("gateway.server:app", host="0.0.0.0", port=8000, reload=True)