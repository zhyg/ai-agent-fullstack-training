import asyncio, json, sys, time
from pathlib import Path
sys.path.insert(0,'/tmp/grade-yun/student')
from gateway.adapter import DeepSeekStreamingModel, OpenAIStreamingModel
from gateway.agent import Agent
from gateway.run_store import create_run_store
import os

async def main():
    results=[]
    for cls in [DeepSeekStreamingModel, OpenAIStreamingModel]:
        model=cls('https://api.deepseek.com/v1',api_key=os.environ['DEEPSEEK_API_KEY'])
        original=model._stream_chat
        chunks=[]
        async def traced(*args,**kwargs):
            async for data in original(*args,**kwargs):
                chunks.append(data)
                yield data
        model._stream_chat=traced
        start=time.monotonic(); first=None; last=None
        async def invoke():
            nonlocal first,last
            async for ev in Agent(model,create_run_store(),tools=[]).execute(1,[{'role':'user','content':'Return only JSON: {"ok":true}'}],model='deepseek-chat',max_tokens=64,thinking={'type':'disabled'},response_format={'type':'json_object'},stream_options={'include_usage':True}):
                if ev.agent_output and first is None:first=(time.monotonic()-start)*1000
                last=ev.model_dump(mode='json')
        try:
            await asyncio.wait_for(invoke(),45)
            results.append({'adapter':cls.__name__,'url':'https://api.deepseek.com/v1/chat/completions','protocol':'Chat Completions','requested_model':'deepseek-chat','upstream_ids':list(dict.fromkeys(x.get('id') for x in chunks if x.get('id'))),'actual_models':list(dict.fromkeys(x.get('model') for x in chunks if x.get('model'))),'usage':[x['usage'] for x in chunks if x.get('usage')],'observed_content_ttft_ms':first,'elapsed_ms':(time.monotonic()-start)*1000,'terminal':last,'configuration_note':'OpenAI adapter uses official DeepSeek connection and model override; not an independent model or second protocol proof'})
        except asyncio.TimeoutError:
            results.append({'adapter':cls.__name__,'status':'unverified_timeout_45s'})
    Path(__file__).with_name('real-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps(results,ensure_ascii=False,indent=2))
asyncio.run(main())
