"""F12: inject an upstream outage, without editing student files."""
import httpx

def pytest_runtest_call(item):
    if item.name == 'test_chat_completion_end_to_end':
        def broken(request, payload):
            return httpx.Response(503, json={'error':{'message':'teacher injected outage'}}, request=request)
        item.module.json_response = broken
