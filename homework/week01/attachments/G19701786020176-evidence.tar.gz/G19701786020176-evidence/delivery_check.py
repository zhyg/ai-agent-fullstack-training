"""Validate grading output and scan plaintext evidence without printing secrets."""
import os
import re
import sys
from pathlib import Path

root=Path(sys.argv[1])
feedback=root/'homework/week01/G19701786020176.md'
attachment=root/'homework/week01/attachments/G19701786020176.md'
evidence=Path(sys.argv[2])
text=feedback.read_text()
sections=re.split(r'\*\*[234]\. [^\n]+\*\*\n\n',text)[1:]
assert len(sections)==3
for title,section in zip(['优点','不足','方案'],sections):
    lines=[l for l in section.splitlines() if l.startswith('- ')]
    length=sum(len(l[2:]) for l in lines)
    assert 3<=len(lines)<=5 and length<=500
    assert all(not any(word in l for word in ['扣分','评分标准','验收结论']) for l in lines)
    print(f'{title}: {len(lines)}条, {length}字符 <=500 PASS')
assert '作业等级：良好（79分）' in text
detail=attachment.read_text()
table=detail.split('## 评分明细',1)[1].split('## 环境',1)[0]
scores=[int(x) for x in re.findall(r'\| (\d+)/(?:15|10) \|',table)]
assert len(scores)==8 and sum(scores)==79
print(f'8项合计: {scores} =79; 等级良好 PASS')
for case in ['A01','A02','A03','A04']+[f'F{i:02}' for i in range(1,13)]:
    assert case in detail
print('A01-A04/F01-F12 覆盖记录 PASS')
secret=os.environ.get('DEEPSEEK_API_KEY','')
assert len(secret)>8, 'Required secret absent from scan environment'
for p in [feedback,attachment,*evidence.rglob('*')]:
    if not p.is_file(): continue
    assert not p.name.startswith('.env') and p.suffix not in ['.db','.sqlite','.sqlite3']
    data=p.read_bytes()
    assert secret.encode() not in data, f'Sensitive value detected in {p.name}'
    s=data.decode('utf-8')
    assert not re.search(r'(?i)authorization\s*[\x22\x27]?\s*:',s), f'Header detected in {p.name}'
    assert not re.search(r'\bsk-[A-Za-z0-9_-]{16,}',s), f'Key-like value detected in {p.name}'
print('Plaintext evidence: no .env/database, no authentication header, no actual secret or sk-style key PASS')
print('No existing output overwritten; archive target checked separately before create; no commit or push performed')
