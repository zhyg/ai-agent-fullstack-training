import asyncio
import json
import time
from pathlib import Path
import httpx

ROOT = Path(__file__).parent
OUT = []
M = 'http://127.0.0.1:18791'
G = 'http://127.0.0.1:18792'

def record(case, **data):
    OUT.append({'case': case, **data})
    print(json.dumps(OUT[-1], ensure_ascii=False), flush=True)

def body(api='chat', alias='smart', **extra):
    return {'model': alias, **({'messages': [{'role': 'user', 'content': 'Return JSON {"ok":true}'}]} if api == 'chat' else {'input': 'Return JSON {"ok":true}'}), **extra}

def path(api):
    return '/v1/chat/completions' if api == 'chat' else '/v1/responses'

async def main():
    async with httpx.AsyncClient(timeout=15) as c:
        async def control(mode):
            await c.post(M+'/control', json={'mode': mode})
        async def calls():
            return (await c.get(M+'/calls')).json()
        async def post(api, b):
            return await c.post(G+path(api), json=b)
        async def trace(r):
            items = (await c.get(G+'/admin/usage?limit=1000')).json()['data']
            return next((x for x in items if x['request_id'] == r.headers.get('x-request-id')), None)
        record('A01', health=(await c.get('http://127.0.0.1:18790/healthz')).json(), ready=(await c.get('http://127.0.0.1:18790/readyz')).json())
        for api in ['chat', 'responses']:
            await control('ok')
            r = await post(api, body(api))
            record('A03-'+api, status=r.status_code, response=r.json(), received=await calls(), trace=await trace(r))
        r = await post('chat', body(alias='unknown'))
        record('A04', status=r.status_code, response=r.json())
        for api in ['chat', 'responses']:
            for mode in ['gate', 'drop', 'heartbeat', 'event_error', 'no_end']:
                await control(mode)
                start = time.monotonic()
                events=[]
                async with c.stream('POST', G+path(api), json=body(api, stream=True)) as r:
                    async for line in r.aiter_lines():
                        if not line:
                            continue
                        events.append({'ms': round((time.monotonic()-start)*1000), 'line': line})
                        if 'partial' in line and mode in ['gate', 'drop']:
                            # The upstream cannot finish before the downstream has received content.
                            await asyncio.sleep(.2)
                            await c.post(M+'/release')
                await asyncio.sleep(.02)
                record('F01-F02-'+api+'-'+mode, status=r.status_code, events=events, received=await calls(), trace=await trace(r))
        for api in ['chat', 'responses']:
            for mode in ['ok', 'bad', 'empty', 'truncated', 'fenced', 'wrong_schema']:
                await control(mode)
                fmt = {'type': 'json_object'}
                if mode == 'wrong_schema':
                    fmt = {'type':'json_schema', 'json_schema': {'name':'ok', 'schema': {'type':'object', 'properties':{'ok':{'type':'boolean'}}, 'required':['ok']}}} if api == 'chat' else {'type':'json_schema', 'name':'ok', 'schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok']}}
                b = body(api, **({'response_format':fmt} if api=='chat' else {'text':{'format':fmt}}))
                r = await post(api, b)
                record('F03-F04-'+api+'-'+mode, status=r.status_code, response=r.json(), received=await calls(), trace=await trace(r))
        # A unified response_format on Responses is passed through, not mapped or validated.
        await control('bad')
        r = await post('responses', body('responses', response_format={'type':'json_object'}))
        record('F03-unified-field', status=r.status_code, response=r.json(), received=await calls())
        await control('ok')
        for v in [1,2]:
            r = await c.post(G+'/v1/prompts', json={'id':'teacher', 'name':'teacher', 'content':f'V{v} {{{{who}}}}'})
            record('F05-create', status=r.status_code, response=r.json())
        for api in ['chat','responses']:
            for v in [1,2]:
                await control('ok')
                r=await post(api, body(api,gateway_prompt={'id':'teacher','version':v,'variables':{'who':'Ada'}}))
                record('F05-'+api+str(v), status=r.status_code, received=await calls(), trace=await trace(r))
        for ref in [{'id':'missing'}, {'id':'teacher','version':999}, {'id':'teacher','version':1}]:
            await control('ok')
            r=await post('chat',body(gateway_prompt=ref))
            record('F06', ref=ref,status=r.status_code,response=r.json(),received=await calls())
        for mode in ['retry','503','429','400','401']:
            await control(mode)
            r=await post('chat',body())
            seen=await calls()
            record('F08-F09-'+mode,status=r.status_code,response=r.json(),received=seen, intervals=[round(seen[i]['time']-seen[i-1]['time'],3) for i in range(1,len(seen))])
        await control('ok')
        limited='http://127.0.0.1:18793'
        statuses=[]
        for alias in ['smart','smart','fast']:
            r=await c.post(limited+path('chat'),json=body(alias=alias))
            statuses.append({'model':alias,'status':r.status_code,'body':r.json()})
        await asyncio.sleep(1.1)
        r=await c.post(limited+path('chat'),json=body(alias='fast'))
        record('F10-F11',sequence=statuses,recovered_status=r.status_code,received=await calls())
        # Unknown, prompt and local-limit failures bypass parts of the audit path.
        record('F07-all-traces', controlled=(await c.get(G+'/admin/usage?limit=1000')).json(), limited=(await c.get(limited+'/admin/usage')).json())
    (ROOT/'controlled-results.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    asyncio.run(main())
