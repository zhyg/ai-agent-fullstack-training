import asyncio
import json
import random
from pathlib import Path
from unittest.mock import patch
import httpx
from app.main import create_app
from app.core.config import GatewayConfig

ROOT=Path(__file__).parent

async def main():
    config=json.loads((ROOT/'controlled-config.json').read_text())
    config['database_path']=':memory:'
    config['retry']['base_delay_seconds']=.2
    config['retry']['jitter_ratio']=.25
    app=create_app(GatewayConfig.model_validate(config))
    waits=[]
    async def capture(seconds): waits.append(seconds)
    random.seed(0)
    with patch('app.services.gateway.asyncio.sleep',capture):
        await app.state.gateway._backoff(0)
        await app.state.gateway._backoff(1)
    await app.state.upstream.close()
    out={'default_backoff': {'seed':0,'base':.2,'jitter_ratio':.25,'waits':waits,'caps':[.2,.4]}}
    async with httpx.AsyncClient() as c:
        await asyncio.sleep(1.1)
        out['limited_traces']=(await c.get('http://127.0.0.1:18793/admin/usage')).json()
        before=(await c.get('http://127.0.0.1:18792/admin/usage?limit=1000')).json()['data']
        failure=await c.post('http://127.0.0.1:18792/v1/chat/completions',json={'model':'smart','messages':[{'role':'user','content':'hi'}],'gateway_prompt':{'id':'audit-missing-template'}})
        after=(await c.get('http://127.0.0.1:18792/admin/usage?limit=1000')).json()['data']
        out['preparation_failure_audit']={'status':failure.status_code,'body':failure.json(),'before_count':len(before),'after_count':len(after)}
        # Real HTTP check of stream + JSON: implemented combination must not silently succeed with invalid content.
        await c.post('http://127.0.0.1:18791/control',json={'mode':'ok'})
        r=await c.post('http://127.0.0.1:18792/v1/chat/completions',json={'model':'smart','messages':[{'role':'user','content':'JSON'}],'stream':True,'response_format':{'type':'json_object'}})
        out['stream_json']={'status':r.status_code,'body':r.text}
    (ROOT/'extra-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps(out,ensure_ascii=False))

asyncio.run(main())
