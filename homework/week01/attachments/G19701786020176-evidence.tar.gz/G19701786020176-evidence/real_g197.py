import asyncio
import json
import time
from pathlib import Path
import httpx

ROOT=Path(__file__).parent

async def main():
    out=[]
    async with httpx.AsyncClient(timeout=80) as c:
        for alias in ['smart','fast']:
            for api in ['chat','responses']:
                for kind in ['normal','stream','json']:
                    b={'model':alias, 'thinking':{'type':'disabled'}}
                    prompt='Reply OK only.' if kind!='json' else 'Return JSON only: {"ok":true}'
                    if api=='chat':
                        b.update(messages=[{'role':'user','content':prompt}],max_tokens=128)
                    else:
                        b.update(input=prompt,max_output_tokens=128)
                    if kind=='json':
                        if api=='chat': b['response_format']={'type':'json_object'}
                        else: b['text']={'format':{'type':'json_object'}}
                    if kind=='stream':
                        b['stream']=True
                        if api=='chat': b['stream_options']={'include_usage':True}
                    url='http://127.0.0.1:18794/v1/'+('chat/completions' if api=='chat' else 'responses')
                    start=time.monotonic()
                    record={'alias':alias,'upstream_model':'deepseek-v4-pro' if alias=='smart' else 'deepseek-flash','api':api,'kind':kind,'request':b}
                    try:
                        async with c.stream('POST',url,json=b) as r:
                            record.update(status=r.status_code,request_id=r.headers.get('x-request-id'))
                            chunks=[]
                            async for chunk in r.aiter_text():
                                chunks.append({'ms':round((time.monotonic()-start)*1000),'text':chunk})
                            record['chunks']=chunks
                    except Exception as e:
                        record['transport_error']=type(e).__name__
                    record['elapsed_ms']=round((time.monotonic()-start)*1000)
                    out.append(record)
                    (ROOT/'real-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
                    print(json.dumps(record,ensure_ascii=False),flush=True)
        r=await c.get('http://127.0.0.1:18794/admin/usage?limit=1000')
        (ROOT/'real-traces.json').write_text(json.dumps(r.json(),ensure_ascii=False,indent=2))

if __name__=='__main__': asyncio.run(main())
