import json
from pathlib import Path

ROOT=Path(__file__).parent
rows=json.loads((ROOT/'controlled-results.json').read_text())
by={x['case']:x for x in rows}
assert by['A04']['status']==404
for api in ['chat','responses']:
    gate=by[f'F01-F02-{api}-gate']
    assert len(gate['received'])==1
    assert 'partial' in gate['events'][0]['line']
    assert gate['events'][-1]['ms']-gate['events'][0]['ms']>=190
    drop=by[f'F01-F02-{api}-drop']
    assert len(drop['received'])==1 and drop['trace']['status']=='failed'
    assert any('"error"' in x['line'] for x in drop['events'])
    for mode in ['bad','empty','truncated','wrong_schema']:
        row=by[f'F03-F04-{api}-{mode}']
        assert row['status']==422 and len(row['received'])==3
    row=by[f'F03-F04-{api}-fenced']
    content=row['response']['choices'][0]['message']['content'] if api=='chat' else row['response']['output'][0]['content'][0]['text']
    try:
        json.loads(content)
    except json.JSONDecodeError:
        pass
    else:
        raise AssertionError('expected reproduced non-JSON success')
assert len(by['F08-F09-retry']['received'])==3
assert len(by['F08-F09-503']['received'])==3
assert len(by['F08-F09-400']['received'])==1
assert [x['status'] for x in by['F10-F11']['sequence']]==[200,429,429]
assert by['F10-F11']['recovered_status']==200
real=json.loads((ROOT/'real-results.json').read_text())
assert len(real)==12
summary=[]
for r in real:
    assert r['status']==200 and 'transport_error' not in r
    text=''.join(c['text'] for c in r['chunks'])
    if r['kind']=='stream':
        events=[]
        for line in text.splitlines():
            if line.startswith('data: ') and line[6:]!='[DONE]': events.append(json.loads(line[6:]))
        assert not any(e.get('error') or e.get('type') in ['error','response.failed'] for e in events)
        if r['api']=='responses':
            d=next(e['response'] for e in events if e.get('type')=='response.completed')
            assert d['status']=='completed'
        else:
            assert '[DONE]' in text
            d=next(e for e in events if e.get('usage'))
    else:
        d=json.loads(text)
        if r['api']=='responses': assert d['status']=='completed' and d['error'] is None
        if r['kind']=='json':
            s=d['choices'][0]['message']['content'] if r['api']=='chat' else next(c['text'] for o in d['output'] for c in o.get('content',[]) if c['type']=='output_text')
            assert json.loads(s)=={'ok':True}
    assert d['model']==r['upstream_model']
    summary.append({'alias':r['alias'],'model':d['model'],'api':r['api'],'kind':r['kind'],'request_id':r['request_id'],'elapsed_ms':r['elapsed_ms'],'usage':d.get('usage')})
(ROOT/'real-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('Evidence consistency PASS: 12 real requests / two distinct returned model IDs / two protocols; controlled gates, failures, retries, isolation defect and JSON defect confirmed.')
