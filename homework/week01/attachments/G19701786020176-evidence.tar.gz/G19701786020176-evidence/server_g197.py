import asyncio
import json
import os
import time
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from app.main import create_app
from app.core.config import GatewayConfig

ROOT = Path(__file__).parent
state = {"mode": "ok", "calls": [], "gate": asyncio.Event()}
mock = FastAPI()

@mock.post('/control')
async def control(r: Request):
    state.update(mode=(await r.json())['mode'], calls=[], gate=asyncio.Event())
    return {"ok": True}

@mock.post('/release')
async def release():
    state['gate'].set()
    return {"ok": True}

@mock.get('/calls')
async def calls():
    return state['calls']

@mock.post('/v1/{path:path}')
async def upstream(path: str, r: Request):
    body = await r.json()
    state['calls'].append({"path": r.url.path, "body": body, "time": time.monotonic()})
    mode = state['mode']
    n = len(state['calls'])
    if mode in ('503', '400', '401', '429') or mode == 'retry' and n < 3:
        return JSONResponse({"error": {"message": "controlled"}}, status_code=503 if mode == 'retry' else int(mode))
    responses = path == 'responses'
    content = {'bad': 'not json', 'empty': '', 'truncated': '{"ok":', 'fenced': '```json\n{"ok":true}\n```', 'wrong_schema': '{"ok":"wrong"}'}.get(mode, '{"ok":true}')
    usage = {"input_tokens": 17, "output_tokens": 9, "total_tokens": 26, "input_tokens_details": {"cached_tokens": 7}, "output_tokens_details": {"reasoning_tokens": 4}} if responses else {"prompt_tokens": 17, "completion_tokens": 9, "total_tokens": 26, "prompt_cache_hit_tokens": 7, "prompt_cache_miss_tokens": 10, "completion_tokens_details": {"reasoning_tokens": 4}}
    if body.get('stream'):
        async def stream():
            if mode == 'heartbeat':
                yield b': ping\n\n'
                await asyncio.sleep(.35)
            delta = {"type": "response.output_text.delta", "delta": "partial"} if responses else {"choices": [{"delta": {"content": "partial"}, "finish_reason": None}]}
            yield ('data: ' + json.dumps(delta) + '\n\n').encode()
            if mode in ('gate', 'drop'):
                await state['gate'].wait()
            if mode == 'drop':
                raise RuntimeError('controlled transport interruption')
            if mode == 'event_error':
                yield b'data: {"type":"error","error":{"message":"controlled event error"}}\n\n'
                return
            if mode == 'no_end':
                return
            if responses:
                end = {"type": "response.completed", "response": {"status": "completed", "usage": usage}}
            else:
                end = {"choices": [{"delta": {}, "finish_reason": "stop"}], "usage": usage}
            yield ('data: ' + json.dumps(end) + '\n\ndata: [DONE]\n\n').encode()
        return StreamingResponse(stream(), media_type='text/event-stream')
    if responses:
        result = {"id": "resp-controlled", "object": "response", "status": "completed", "model": body['model'], "output": [{"type": "message", "content": [{"type": "output_text", "text": content}]}], "usage": usage}
    else:
        result = {"id": "chat-controlled", "object": "chat.completion", "model": body['model'], "choices": [{"message": {"role": "assistant", "content": content}, "finish_reason": "length" if mode == 'truncated' else "stop"}], "usage": usage}
    return result

def config(name, real=False, limited=False):
    provider = {"base_url": "https://api.deepseek.com" if real else "http://127.0.0.1:18791", "api_key_env": "DEEPSEEK_API_KEY" if real else "GRADING_UNUSED_SECRET", "structured_output": "json_object", "timeout_seconds": 60}
    cfg = {"database_path": str(ROOT / (name + '.db')), "auth": {"api_key_env": "GRADING_UNUSED_AUTH"}, "rate_limit": {"enabled": limited, "requests_per_minute": 60, "burst": 1}, "retry": {"max_attempts_per_candidate": 3, "base_delay_seconds": .1, "max_delay_seconds": 1, "jitter_ratio": 0}, "circuit_breaker": {"failure_threshold": 100, "cooldown_seconds": 1}, "providers": {"official" if real else "controlled": provider}, "models": {alias: {"routes": [{"provider": "official" if real else "controlled", "model": model, "api": "both"}]} for alias, model in [('smart', 'deepseek-v4-pro' if real else 'mock-A'), ('fast', 'deepseek-flash' if real else 'mock-B')]}}
    (ROOT / (name + '-config.json')).write_text(json.dumps(cfg, indent=2))
    return GatewayConfig.model_validate(cfg)

async def main():
    apps = [(mock, 18791), (create_app(config('controlled')), 18792), (create_app(config('limited', limited=True)), 18793), (create_app(config('real', real=True)), 18794)]
    await asyncio.gather(*(uvicorn.Server(uvicorn.Config(a, host='127.0.0.1', port=p, log_level='warning')).serve() for a,p in apps))

if __name__ == '__main__':
    asyncio.run(main())
