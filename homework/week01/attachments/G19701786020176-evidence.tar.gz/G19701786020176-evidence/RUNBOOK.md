# G19701786020176 第一次提交独立评测复现

对象：https://github.com/Newbeeffy/llm-gateway.git

固定 main commit：dd8b9fea66341457996427d87e2c871e328fe1ce。教师工具均在学生仓库外，不修改业务逻辑。

## 安装和学生测试

```bash
git clone https://github.com/Newbeeffy/llm-gateway.git student
git -C student checkout --detach dd8b9fea66341457996427d87e2c871e328fe1ce
python3 -m venv venv
venv/bin/pip install ./student pytest pytest-asyncio
(cd student && ../venv/bin/python -m pytest -q)
```

预期原套件 86 passed。环境依赖版本见 dependencies.txt。安装日志 install.log。

## 启动受控实例与真实实例

将解包证据放在单独 evidence 目录。以下用绝对路径替换示例路径；服务启动目录不要求与学生仓库一致。

```bash
amp orb service start grading-g197 --command 'env GRADING_UNUSED_SECRET=controlled-placeholder LLM_GATEWAY_CONFIG=/absolute/student/gateway.yaml PYTHONPATH=/absolute/student /absolute/venv/bin/python /absolute/evidence/server_g197.py'
amp orb service start grading-g197-readme --command 'env LLM_GATEWAY_CONFIG=/absolute/student/gateway.yaml /absolute/venv/bin/uvicorn app.main:app --app-dir /absolute/student --host 127.0.0.1 --port 18790'
```

等待 /healthz 返回后再测试；启动命令返回不代表 uvicorn 已就绪。server_g197.py 会生成外部配置和独立数据库；GRADING_UNUSED_SECRET 是模拟器占位字符串，不是真实凭据，不能误传真实值。GRADING_UNUSED_AUTH 不设置，利用学生文档声明的开发免鉴权模式。要重跑模板创建测试，应停止服务并删除此工具自己生成的 controlled.db、limited.db 后重新启动；不要删除其他数据库。

```bash
venv/bin/python evidence/verify_g197.py
env PYTHONPATH=/absolute/student LLM_GATEWAY_CONFIG=/absolute/student/gateway.yaml venv/bin/python evidence/extra_g197.py
```

verify_g197.py 记录观察结果，不把所有观察当通过；最终判断见评测附件。其门控先等下游收到内容再释放上游，不使用仅时间差推测是否增量。

额外 F12 故障注入（应返回 1，且 1 failed）：

```bash
(cd student && PYTHONPATH=/absolute/evidence ../venv/bin/python -m pytest -q -p failure_plugin tests/test_api.py::test_chat_completion_end_to_end)
```

原 tests/myTest.py 另已实际执行：先以同 controlled-config.json 在 8000 启动学生 app，受控上游设 ok，再执行该文件，打印 JSON 和 partial；它只示范普通/流式，无完整验收断言。脚本原文不入证据包，避免携带其示例鉴权字符串。

## 可选真实调用（会消耗少量额度）

仅安全提供环境 secret DEEPSEEK_API_KEY；不要把值写进命令、配置、报告或归档。启动服务时应继承该环境。核对 real-config.json 仅使用官方 https://api.deepseek.com，无原智谱候选，再执行：

```bash
venv/bin/python evidence/real_g197.py
python3 evidence/check_evidence.py
```

smart→deepseek-v4-pro，fast→deepseek-flash，两模型都走 Chat Completions 和 Responses；普通、流式、JSON 共12次，每次输出预算128。模型返回 ID、JSON 正文和终态都有实际断言，不能仅检查HTTP200；Responses 的 error:null 不是错误。

旧别名轮次记录为 real-legacy-*，只用于说明两个不同别名并不一定代表不同模型；最终 real-* 才用于确认双模型。原 GLM 未访问、未验证。受控故障不消耗真实模型额度。

## 清理

```bash
amp orb service stop grading-g197
amp orb service stop grading-g197-readme
amp orb service stop grading-g197-student
ss -ltnp
git -C student status --porcelain
```

原评测交付只含白名单文本证据，未包含 .env、鉴权头、任何密钥值或 SQLite 文件。source-integrity.txt 给出固定源码哈希；delivery-check.log 给出报告字数/评分/敏感检查结果。cleanup-check.log 记录服务停止后的业务监听状态；平台内部透明代理如仍占用链路端口，不是学生进程或学生服务。
