# LLM Gateway 大模型网关

统一模型调用服务：一个入口屏蔽多种上游 API 协议差异，内置流式输出、结构化输出、Prompt 版本管理、可观测性与韧性基础。

## 模型与协议路由

| 网关模型名 | 上游协议 | 鉴权方式 | 上游端点 |
|---|---|---|---|
| `deepseek-v4-pro` | OpenAI Responses API | `Authorization: Bearer` | `POST {base}/v1/responses` |
| `deepseek-v4-flash` | Anthropic Messages API | `x-api-key` + `anthropic-version` | `POST {base}/anthropic/v1/messages` |

请求中的 `model` 字段决定路由到哪个适配器（`gateway/adapters/`）。适配器负责：请求体翻译、鉴权头注入、响应/流式事件归一化、usage 分类统计归一化。上层接口与返回格式完全一致。

## 功能清单

- **统一抽象层**：`POST /v1/llm` 单一入口，适配器模式 + 模型注册表动态路由
- **流式输出**：`stream=true` 返回 SSE（`content.delta` 逐块 + `response.completed` 收尾）
- **结构化输出**：`response_format` 支持 `json_object` / `json_schema`；Responses 协议走原生 `text.format`，Anthropic 协议走 Schema 指令注入，网关出口统一做 JSON 解析 + jsonschema 校验
- **Prompt 版本管理**：模板存储（JSON 持久化）、同名自动递增版本 `v1/v2/...`、`{{变量}}` 严格替换、调用时按 `name@version` 引用（缺省用最新版）
- **可观测性**：每次调用记录 token 分类（input / output / total / reasoning / cached_input）、总延迟、首 token 延迟、重试历史；`GET /v1/traces` 明细 + `GET /v1/metrics` 按模型聚合，另持久化到 `data/traces.jsonl`
- **韧性**：统一错误码封装；可重试错误（超时/连接失败/上游 429/5xx/JSON 不合法）指数退避重试最多 3 次（0.5s → 1s → 2s，共 4 次尝试）；按模型独立令牌桶限流，超限立即返回 429

## 快速启动（conda geek 环境）

```bash
cd homework

# 依赖（geek 环境已具备；如需补装）
/opt/homebrew/Caskroom/miniconda/base/envs/geek/bin/pip install -r requirements.txt

# 设置上游密钥
export DEEPSEEK_API_KEY=<redacted>

# 启动服务
/opt/homebrew/Caskroom/miniconda/base/envs/geek/bin/python -m uvicorn gateway.main:app --host 0.0.0.0 --port 8000
```

可选环境变量：

| 变量 | 默认值 | 说明 |
|---|---|---|
| `DEEPSEEK_API_KEY` | 必填 | 上游 API 密钥 |
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com` | 上游地址 |
| `RATE_LIMIT_RPM` / `RATE_LIMIT_BURST` | `60` / `5` | 每模型限流（每分钟请求数 / 突发容量） |
| `RETRY_MAX_RETRIES` | `3` | 最大重试次数 |
| `RETRY_BASE_DELAY` / `RETRY_MAX_DELAY` | `0.5` / `8` | 指数退避基数 / 上限（秒） |
| `UPSTREAM_TIMEOUT` | `120` | 上游超时（秒） |
| `GATEWAY_DATA_DIR` | `./data` | 模板与审计数据目录 |

## curl 示例

### 1. 基础调用（两个模型同一接口）

```bash
curl http://localhost:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "只回复 PONG"}], "max_tokens": 2000}'

curl http://localhost:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-flash", "messages": [{"role": "user", "content": "只回复 PONG"}], "max_tokens": 100}'
```

返回含 `content`、`usage`（token 分类）、`latency_ms`、`attempts`、`adapter` 等统一字段。

### 2. 流式输出（SSE）

```bash
curl -N http://localhost:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-flash", "stream": true, "max_tokens": 300,
       "messages": [{"role": "user", "content": "从 1 数到 5，每个数字一行"}]}'
```

输出形如：

```
event: delta
data: {"type": "content.delta", "request_id": "...", "text": "1\n"}

event: done
data: {"type": "response.completed", "usage": {...}, "latency_ms": 800.1, "first_token_ms": 320.5, "attempts": 1, ...}
```

### 3. 结构化输出

```bash
curl http://localhost:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "中国的首都是哪里？"}],
    "max_tokens": 3000,
    "response_format": {
      "type": "json_schema",
      "json_schema": {"name": "geo", "schema": {
        "type": "object",
        "properties": {"city": {"type": "string"}, "country": {"type": "string"}},
        "required": ["city", "country"], "additionalProperties": false}}
    }
  }'
```

返回的 `parsed` 字段为已通过 Schema 校验的 JSON 对象；`json_object` 模式只保证合法 JSON。

### 4. Prompt 模板：存储 → 版本 → 引用

```bash
# 创建 v1
curl http://localhost:8000/v1/prompts -H 'Content-Type: application/json' \
  -d '{"name": "intro", "template": "你是{{product}}的客服，请用一句话介绍{{product}}。"}'

# 再次创建同名模板 → 自动成为 v2
curl http://localhost:8000/v1/prompts -H 'Content-Type: application/json' \
  -d '{"name": "intro", "template": "你是{{product}}的资深客服，语气活泼，用一句话介绍{{product}}。"}'

# 查看版本列表
curl http://localhost:8000/v1/prompts

# 调用时引用固定版本 + 变量替换（渲染结果作为 system 消息注入）
curl http://localhost:8000/v1/llm -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-flash", "max_tokens": 300,
       "messages": [{"role": "user", "content": "开始介绍"}],
       "prompt": {"name": "intro", "version": "v1", "variables": {"product": "极客网关"}}}'
```

缺少变量返回 `400 missing_prompt_variable`；不传 `version` 使用最新版。

### 5. 可观测性

```bash
curl 'http://localhost:8000/v1/traces?limit=20'   # 每次调用明细（不存模型正文）
curl http://localhost:8000/v1/metrics             # 按模型聚合：token 分类总量、平均延迟、平均首token延迟、限流拒绝数
```

### 6. 限流演示（429）

```bash
# 把 flash 限到 burst=1
curl -X PUT http://localhost:8000/v1/admin/rate-limits/deepseek-v4-flash \
  -H 'Content-Type: application/json' -d '{"rpm": 6, "burst": 1}'

# 连续快速调用两次，第二次返回 429 {"error": {"code": "rate_limited", ...}}
# pro 模型不受影响（按模型独立令牌桶）

# 恢复
curl -X PUT http://localhost:8000/v1/admin/rate-limits/deepseek-v4-flash \
  -H 'Content-Type: application/json' -d '{"rpm": 60, "burst": 5}'
```

### 7. 重试演示（故障注入）

```bash
# 把 pro 上游指向不可达地址
curl -X PUT http://localhost:8000/v1/admin/models/deepseek-v4-pro \
  -H 'Content-Type: application/json' -d '{"base_url": "http://127.0.0.1:9"}'

curl http://localhost:8000/v1/llm -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}]}'
# → 502，error.details.attempts=4，attempt_history 退避序列 [0.5, 1.0, 2.0] 秒

# 恢复
curl -X PUT http://localhost:8000/v1/admin/models/deepseek-v4-pro \
  -H 'Content-Type: application/json' -d '{"base_url": "https://api.deepseek.com"}'
```

## 统一错误码

所有错误返回 `{"error": {"code", "message", "details?"}}`：

| code | HTTP | 可重试 | 说明 |
|---|---|---|---|
| `invalid_request` | 400 | 否 | 请求体校验失败 |
| `missing_prompt_variable` | 400 | 否 | 模板变量缺失 |
| `stream_structured_conflict` | 400 | 否 | 流式与 JSON 结构化混用 |
| `unknown_model` | 404 | 否 | 模型未注册 |
| `prompt_not_found` / `prompt_version_not_found` | 404 | 否 | 模板/版本不存在 |
| `rate_limited` | 429 | 客户端稍后 | 网关侧按模型限流 |
| `upstream_auth` | 502 | 否 | 上游鉴权失败 |
| `upstream_bad_request` / `upstream_model_not_found` | 502 | 否 | 上游 4xx |
| `upstream_unreachable` / `upstream_error` / `upstream_rate_limited` | 502 | 是 | 连接失败 / 上游 5xx / 上游限流 |
| `upstream_timeout` | 504 | 是 | 上游超时 |
| `invalid_json` / `schema_violation` | 502 | 是 | 结构化输出不合法 |

重试耗尽后错误 `details` 中携带 `attempts` 与 `attempt_history`（每次失败的错误码与退避时长）。流式请求在首块发出前可重试；已开始输出后失败则发送 `event: error`。

## 验证脚本

```bash
cd homework
/opt/homebrew/Caskroom/miniconda/base/envs/geek/bin/python tests/verify.py
```

脚本自动拉起服务（端口 8010），对两个模型逐项验证：基础调用、流式 SSE、json_schema/json_object 结构化、模板版本与变量替换、可观测数据、429 限流、指数退避重试、统一错误码，共 20 项断言，全部通过后生成 `verification_report.md` 证据报告。也可 `--base-url http://127.0.0.1:8000` 指向已运行实例。

## 目录结构

按分层架构组织：API 接口层 / 业务服务层 / 协议适配层 / 核心基础设施。

```
homework/
├── gateway/                      # 应用主包
│   ├── main.py                   # FastAPI 装配 + lifespan + 统一错误处理
│   ├── api/                      # ── HTTP 接口层 ──
│   │   ├── schemas.py            # Pydantic 请求模型
│   │   ├── deps.py               # 服务实例依赖注入
│   │   └── routes/
│   │       ├── llm.py            # POST /v1/llm、GET /v1/models、/healthz
│   │       ├── prompts.py        # /v1/prompts 模板管理
│   │       ├── observability.py  # /v1/traces、/v1/metrics
│   │       └── admin.py          # /v1/admin 限流调整 / 故障演练
│   ├── services/                 # ── 业务编排层 ──
│   │   ├── gateway.py            # 编排：路由→限流→模板→重试→结构化校验→审计
│   │   ├── prompts.py            # 模板存储 / 版本 / 变量替换
│   │   └── observability.py      # 调用审计与聚合指标
│   ├── adapters/                 # ── 协议适配层 ──
│   │   ├── base.py               # 公共类型 / SSE 解析 / 错误映射
│   │   ├── openai_responses.py   # OpenAI Responses 适配器
│   │   └── anthropic_messages.py # Anthropic Messages 适配器
│   └── core/                     # ── 核心基础设施 ──
│       ├── config.py             # 模型注册表与环境配置
│       ├── errors.py             # 统一错误码
│       ├── retry.py              # 指数退避重试
│       └── ratelimit.py          # 按模型令牌桶
├── tests/
│   └── verify.py                 # 端到端验证脚本
├── requirements.txt
└── data/                         # 运行时生成：prompts.json / traces.jsonl
```