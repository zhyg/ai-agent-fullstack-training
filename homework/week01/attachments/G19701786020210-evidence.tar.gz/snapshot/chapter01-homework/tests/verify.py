"""LLM Gateway 端到端验证脚本。

默认自动拉起 uvicorn 子进程（端口 8010），逐项验证六大功能并输出证据，
最后生成 verification_report.md。也可用 --base-url 指向已运行的服务。

用法（conda geek 环境，在 homework 根目录执行）：
    python tests/verify.py
    python tests/verify.py --base-url http://127.0.0.1:8000
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
import jsonschema

HOMEWORK_DIR = Path(__file__).resolve().parent.parent
MODELS = ["deepseek-v4-pro", "deepseek-v4-flash"]
GEO_SCHEMA = {
    "type": "object",
    "properties": {"city": {"type": "string"}, "country": {"type": "string"}},
    "required": ["city", "country"],
    "additionalProperties": False,
}

RESULTS: list[dict] = []


def record(name: str, passed: bool, evidence: str) -> None:
    RESULTS.append({"name": name, "passed": passed, "evidence": evidence})
    mark = "PASS" if passed else "FAIL"
    print(f"[{mark}] {name}\n       证据: {evidence}")


def parse_sse(text: str) -> list[tuple[str, dict]]:
    events = []
    event = ""
    for line in text.splitlines():
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            events.append((event, json.loads(line[5:].strip())))
    return events


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--port", type=int, default=8010)
    args = parser.parse_args()

    if not os.getenv("DEEPSEEK_API_KEY"):
        print("缺少环境变量 DEEPSEEK_API_KEY")
        return 2

    proc = None
    base_url = args.base_url
    if not base_url:
        base_url = f"http://127.0.0.1:{args.port}"
        proc = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "gateway.main:app",
             "--host", "127.0.0.1", "--port", str(args.port), "--log-level", "warning"],
            cwd=HOMEWORK_DIR,
            env={**os.environ, "GATEWAY_DATA_DIR": tempfile.mkdtemp(prefix="gw-verify-")},
        )
        deadline = time.time() + 30
        while time.time() < deadline:
            try:
                httpx.get(f"{base_url}/healthz", timeout=2, trust_env=False)
                break
            except httpx.HTTPError:
                time.sleep(0.3)
        else:
            print("服务启动超时")
            proc.kill()
            return 2

    client = httpx.Client(base_url=base_url, timeout=180, trust_env=False)
    try:
        run_tests(client)
    finally:
        client.close()
        if proc:
            proc.terminate()
            proc.wait(timeout=10)

    passed = sum(1 for r in RESULTS if r["passed"])
    total = len(RESULTS)
    print(f"\n===== 验证汇总: {passed}/{total} 通过 =====")
    write_report(passed, total)
    return 0 if passed == total else 1


def run_tests(client: httpx.Client) -> None:
    # ---------- 0. 模型注册与路由 ----------
    models = client.get("/v1/models").json()
    by_name = {m["model"]: m for m in models}
    ok = (
        by_name.get("deepseek-v4-pro", {}).get("adapter") == "openai_responses"
        and by_name.get("deepseek-v4-flash", {}).get("adapter") == "anthropic_messages"
    )
    record("统一抽象层：model 字段路由到不同协议适配器", ok,
           f"pro→{by_name.get('deepseek-v4-pro', {}).get('adapter')}, "
           f"flash→{by_name.get('deepseek-v4-flash', {}).get('adapter')}")

    # ---------- 1. 两个模型基础调用 ----------
    for model in MODELS:
        r = client.post("/v1/llm", json={
            "model": model,
            "messages": [{"role": "user", "content": "只回复 PONG，不要解释。"}],
            "max_tokens": 2000,
        })
        body = r.json()
        ok = (
            r.status_code == 200
            and "PONG" in body.get("content", "")
            and body["usage"]["total_tokens"] > 0
            and body["latency_ms"] > 0
        )
        record(f"基础调用：{model}", ok,
               f"HTTP {r.status_code}, content={body.get('content')!r}, "
               f"usage={body.get('usage')}, latency_ms={body.get('latency_ms')}, "
               f"adapter={body.get('adapter')}")

    # ---------- 2. 流式输出（SSE） ----------
    for model in MODELS:
        start = time.monotonic()
        first_delta_at = None
        deltas: list[str] = []
        done = None
        with client.stream("POST", "/v1/llm", json={
            "model": model,
            "messages": [{"role": "user", "content": "从 1 数到 5，每个数字一行，不要其他内容。"}],
            "stream": True,
            "max_tokens": 2000,
        }) as resp:
            ctype = resp.headers.get("content-type", "")
            event = ""
            for line in resp.iter_lines():
                if line.startswith("event:"):
                    event = line[6:].strip()
                elif line.startswith("data:"):
                    data = json.loads(line[5:].strip())
                    if data.get("type") == "content.delta":
                        if first_delta_at is None:
                            first_delta_at = time.monotonic()
                        deltas.append(data["text"])
                    elif data.get("type") == "response.completed":
                        done = data
        wall_first_ms = round((first_delta_at - start) * 1000, 1) if first_delta_at else None
        ok = (
            ctype.startswith("text/event-stream")
            and len(deltas) >= 2
            and done is not None
            and done["usage"]["total_tokens"] > 0
            and done["first_token_ms"] is not None
            and done["first_token_ms"] > 0
        )
        record(f"流式输出：{model}", ok,
               f"content-type={ctype}, delta 块数={len(deltas)}, "
               f"拼接结果={''.join(deltas)!r}, 首token延迟={done and done['first_token_ms']}ms"
               f"(客户端实测 {wall_first_ms}ms), 总延迟={done and done['latency_ms']}ms, "
               f"usage={done and done['usage']}")

    # ---------- 3. 结构化输出 ----------
    for model in MODELS:
        r = client.post("/v1/llm", json={
            "model": model,
            "messages": [{"role": "user", "content": "中国的首都是哪里？"}],
            "max_tokens": 3000,
            "response_format": {
                "type": "json_schema",
                "json_schema": {"name": "geo", "schema": GEO_SCHEMA},
            },
        })
        body = r.json()
        parsed = body.get("parsed")
        schema_ok = False
        if parsed is not None:
            try:
                jsonschema.validate(parsed, GEO_SCHEMA)
                schema_ok = True
            except jsonschema.ValidationError:
                pass
        ok = r.status_code == 200 and schema_ok
        record(f"结构化输出 json_schema：{model}", ok,
               f"HTTP {r.status_code}, parsed={parsed}, 独立 jsonschema 校验={'通过' if schema_ok else '失败'}")

    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "输出一个 JSON 对象，包含字段 ok，值为 true。"}],
        "max_tokens": 500,
        "response_format": {"type": "json_object"},
    })
    body = r.json()
    ok = r.status_code == 200 and isinstance(body.get("parsed"), dict)
    record("结构化输出 json_object：deepseek-v4-flash", ok,
           f"HTTP {r.status_code}, parsed={body.get('parsed')}")

    # ---------- 4. Prompt 模板：存储 / 版本 / 变量替换 / 引用 ----------
    tpl_v1 = "请只输出这句话，不要添加任何其他内容：{{product}} 测试成功，暗号 {{code}}。"
    tpl_v2 = "请只输出这句话，不要添加任何其他内容：{{product}} 第二版模板，暗号 {{code}}。"
    r1 = client.post("/v1/prompts", json={"name": "echo_test", "template": tpl_v1})
    r2 = client.post("/v1/prompts", json={"name": "echo_test", "template": tpl_v2})
    listing = client.get("/v1/prompts").json()
    entry = next((p for p in listing if p["name"] == "echo_test"), {})
    ok = (
        r1.status_code == 200 and r1.json()["version"] == "v1"
        and r2.status_code == 200 and r2.json()["version"] == "v2"
        and entry.get("versions") == ["v1", "v2"]
    )
    record("Prompt 模板存储与版本递增", ok,
           f"创建返回 v1={r1.json().get('version')}, v2={r2.json().get('version')}, 列表={entry}")

    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "执行系统指令。"}],
        "max_tokens": 300,
        "temperature": 0,
        "prompt": {"name": "echo_test", "version": "v1",
                   "variables": {"product": "网关作业", "code": "ALPHA-42"}},
    })
    body = r.json()
    compact = "".join(body.get("content", "").split())
    ok = (
        r.status_code == 200
        and "ALPHA-42" in compact
        and "第二版" not in compact
        and body.get("prompt", {}).get("version") == "v1"
    )
    record("Prompt 版本引用 + 变量替换（固定 v1）", ok,
           f"HTTP {r.status_code}, content={body.get('content')!r}, prompt={body.get('prompt')}")

    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "执行系统指令。"}],
        "max_tokens": 300,
        "temperature": 0,
        "prompt": {"name": "echo_test",
                   "variables": {"product": "网关作业", "code": "BETA-7"}},
    })
    body = r.json()
    compact = "".join(body.get("content", "").split())
    ok = (
        r.status_code == 200
        and body.get("prompt", {}).get("version") == "v2"
        and "BETA-7" in compact
    )
    record("Prompt 缺省引用最新版本（v2）", ok,
           f"HTTP {r.status_code}, 解析版本={body.get('prompt', {}).get('version')}, "
           f"content={body.get('content')!r}")

    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "hi"}],
        "prompt": {"name": "echo_test", "version": "v1", "variables": {"product": "x"}},
    })
    ok = r.status_code == 400 and r.json()["error"]["code"] == "missing_prompt_variable"
    record("Prompt 缺失变量被拦截（统一错误码）", ok,
           f"HTTP {r.status_code}, error={r.json().get('error')}")

    # ---------- 5. 可观测性 ----------
    traces = client.get("/v1/traces?limit=200").json()
    metrics = client.get("/v1/metrics").json()
    stream_traces = [t for t in traces if t["stream"] and t["status"] == "success"]
    token_keys = {"input_tokens", "output_tokens", "total_tokens", "reasoning_tokens", "cached_input_tokens"}
    ok = (
        len(traces) >= 8
        and all(token_keys <= set(t["usage"]) for t in traces if t["usage"])
        and all(t["latency_ms"] > 0 for t in traces if t["status"] == "success")
        and len(stream_traces) >= 2
        and all(t["first_token_ms"] is not None and t["first_token_ms"] > 0 for t in stream_traces)
        and metrics["models"]["deepseek-v4-pro"]["tokens"]["total_tokens"] > 0
        and metrics["models"]["deepseek-v4-flash"]["tokens"]["total_tokens"] > 0
    )
    pro_m = metrics["models"]["deepseek-v4-pro"]
    flash_m = metrics["models"]["deepseek-v4-flash"]
    record("可观测性：token 分类统计 + 延迟 + 首token延迟", ok,
           f"traces 条数={len(traces)}, 流式记录首token延迟样例="
           f"{[t['first_token_ms'] for t in stream_traces[:2]]}, "
           f"pro 汇总 tokens={pro_m['tokens']}, avg_latency={pro_m['avg_latency_ms']}ms, "
           f"flash 汇总 tokens={flash_m['tokens']}, avg_first_token={flash_m['avg_first_token_ms']}ms")

    # ---------- 6. 限流（按模型独立，429） ----------
    client.put("/v1/admin/rate-limits/deepseek-v4-flash", json={"rpm": 6, "burst": 1})
    statuses = []
    bodies = []
    for _ in range(3):
        r = client.post("/v1/llm", json={
            "model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "只回复 OK。"}],
            "max_tokens": 50,
        })
        statuses.append(r.status_code)
        bodies.append(r.json())
    client.put("/v1/admin/rate-limits/deepseek-v4-flash", json={"rpm": 60, "burst": 5})
    rejected = [b for s, b in zip(statuses, bodies) if s == 429]
    pro_unaffected = client.post("/v1/llm", json={
        "model": "deepseek-v4-pro",
        "messages": [{"role": "user", "content": "只回复 OK。"}],
        "max_tokens": 2000,
    })
    ok = (
        429 in statuses
        and all(b["error"]["code"] == "rate_limited" for b in rejected)
        and pro_unaffected.status_code == 200
    )
    record("按模型独立限流：超限 429，其他模型不受影响", ok,
           f"flash 连续3次状态码={statuses}, 429 响应={rejected[:1]}, "
           f"同期 pro 调用 HTTP {pro_unaffected.status_code}")

    # ---------- 7. 重试（指数退避，最多3次） ----------
    original = by_name["deepseek-v4-pro"]["base_url"]
    client.put("/v1/admin/models/deepseek-v4-pro", json={"base_url": "http://127.0.0.1:9"})
    start = time.monotonic()
    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-pro",
        "messages": [{"role": "user", "content": "hi"}],
        "max_tokens": 100,
    })
    elapsed = round(time.monotonic() - start, 2)
    body = r.json()
    err = body.get("error", {})
    details = err.get("details", {})
    history = details.get("attempt_history", [])
    backoffs = [h["backoff_seconds"] for h in history]
    ok = (
        r.status_code == 502
        and err.get("code") == "upstream_unreachable"
        and details.get("attempts") == 4
        and backoffs == [0.5, 1.0, 2.0]
        and elapsed >= 3.4
    )
    record("指数退避重试：上游不可达时重试3次后统一报错", ok,
           f"HTTP {r.status_code}, code={err.get('code')}, attempts={details.get('attempts')}, "
           f"退避序列={backoffs}s, 总耗时={elapsed}s, attempt_history={history}")

    error_trace = next(
        (t for t in client.get("/v1/traces?limit=10").json()
         if t["status"] == "error" and t["model"] == "deepseek-v4-pro"),
        None,
    )
    ok = error_trace is not None and error_trace["attempts"] == 4 and error_trace["error_code"] == "upstream_unreachable"
    record("重试过程写入审计记录", ok,
           f"trace: attempts={error_trace and error_trace['attempts']}, "
           f"error_code={error_trace and error_trace['error_code']}, "
           f"history={error_trace and error_trace['attempt_history']}")

    client.put("/v1/admin/models/deepseek-v4-pro", json={"base_url": original})
    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-pro",
        "messages": [{"role": "user", "content": "只回复 RECOVERED。"}],
        "max_tokens": 2000,
    })
    ok = r.status_code == 200 and "RECOVERED" in r.json().get("content", "")
    record("故障恢复后调用正常", ok, f"HTTP {r.status_code}, content={r.json().get('content')!r}")

    # ---------- 8. 统一错误码 ----------
    r = client.post("/v1/llm", json={
        "model": "not-exist", "messages": [{"role": "user", "content": "hi"}],
    })
    ok = r.status_code == 404 and r.json()["error"]["code"] == "unknown_model"
    record("统一错误码：未知模型", ok, f"HTTP {r.status_code}, error={r.json().get('error')}")

    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "hi"}],
        "unknown_field": True,
    })
    ok = r.status_code == 400 and r.json()["error"]["code"] == "invalid_request"
    record("统一错误码：非法请求体", ok, f"HTTP {r.status_code}, code={r.json().get('error', {}).get('code')}")

    r = client.post("/v1/llm", json={
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "hi"}],
        "stream": True,
        "response_format": {"type": "json_object"},
    })
    ok = r.status_code == 400 and r.json()["error"]["code"] == "stream_structured_conflict"
    record("统一错误码：流式与结构化混用拦截", ok,
           f"HTTP {r.status_code}, code={r.json().get('error', {}).get('code')}")


def write_report(passed: int, total: int) -> None:
    lines = [
        "# LLM Gateway 验证报告",
        "",
        f"- 时间：{time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- 结果：**{passed}/{total} 通过**",
        f"- 模型：deepseek-v4-pro（OpenAI Responses API）、deepseek-v4-flash（Anthropic Messages API）",
        "",
        "| # | 功能点 | 结果 | 证据 |",
        "|---|--------|------|------|",
    ]
    for i, r in enumerate(RESULTS, 1):
        mark = "✅" if r["passed"] else "❌"
        evidence = r["evidence"].replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {i} | {r['name']} | {mark} | {evidence} |")
    report = HOMEWORK_DIR / "verification_report.md"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"报告已写入: {report}")


if __name__ == "__main__":
    sys.exit(main())