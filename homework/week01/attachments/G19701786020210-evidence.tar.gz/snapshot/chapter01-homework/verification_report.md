# LLM Gateway 验证报告

- 时间：2026-11-18 17:11:12
- 结果：**20/20 通过**
- 模型：deepseek-v4-pro（OpenAI Responses API）、deepseek-v4-flash（Anthropic Messages API）

| # | 功能点 | 结果 | 证据 |
|---|--------|------|------|
| 1 | 统一抽象层：model 字段路由到不同协议适配器 | ✅ | pro→openai_responses, flash→anthropic_messages |
| 2 | 基础调用：deepseek-v4-pro | ✅ | HTTP 200, content='PONG', usage={'input_tokens': 91, 'output_tokens': 36, 'total_tokens': 127, 'reasoning_tokens': 33, 'cached_input_tokens': 0}, latency_ms=1780.7, adapter=openai_responses |
| 3 | 基础调用：deepseek-v4-flash | ✅ | HTTP 200, content='PONG', usage={'input_tokens': 12, 'output_tokens': 2, 'total_tokens': 14, 'reasoning_tokens': 0, 'cached_input_tokens': 0}, latency_ms=323.4, adapter=anthropic_messages |
| 4 | 流式输出：deepseek-v4-pro | ✅ | content-type=text/event-stream; charset=utf-8, delta 块数=9, 拼接结果='1\n2\n3\n4\n5', 首token延迟=2246.1ms(客户端实测 2247.1ms), 总延迟=2293.6ms, usage={'input_tokens': 100, 'output_tokens': 73, 'total_tokens': 173, 'reasoning_tokens': 63, 'cached_input_tokens': 0} |
| 5 | 流式输出：deepseek-v4-flash | ✅ | content-type=text/event-stream; charset=utf-8, delta 块数=9, 拼接结果='1\n2\n3\n4\n5', 首token延迟=664.0ms(客户端实测 665.4ms), 总延迟=815.0ms, usage={'input_tokens': 21, 'output_tokens': 9, 'total_tokens': 30, 'reasoning_tokens': 0, 'cached_input_tokens': 0} |
| 6 | 结构化输出 json_schema：deepseek-v4-pro | ✅ | HTTP 200, parsed={'city': '北京', 'country': '中国'}, 独立 jsonschema 校验=通过 |
| 7 | 结构化输出 json_schema：deepseek-v4-flash | ✅ | HTTP 200, parsed={'city': '北京', 'country': '中国'}, 独立 jsonschema 校验=通过 |
| 8 | 结构化输出 json_object：deepseek-v4-flash | ✅ | HTTP 200, parsed={'ok': True} |
| 9 | Prompt 模板存储与版本递增 | ✅ | 创建返回 v1=v1, v2=v2, 列表={'name': 'echo_test', 'latest': 'v2', 'versions': ['v1', 'v2']} |
| 10 | Prompt 版本引用 + 变量替换（固定 v1） | ✅ | HTTP 200, content='网关作业 测试成功，暗号 ALPHA-42。', prompt={'name': 'echo_test', 'version': 'v1'} |
| 11 | Prompt 缺省引用最新版本（v2） | ✅ | HTTP 200, 解析版本=v2, content='网关作业 第二第二版模板，暗号 BETA-7。' |
| 12 | Prompt 缺失变量被拦截（统一错误码） | ✅ | HTTP 400, error={'code': 'missing_prompt_variable', 'message': '模板 echo_test@v1 缺少变量: code', 'details': {'missing': ['code']}} |
| 13 | 可观测性：token 分类统计 + 延迟 + 首token延迟 | ✅ | traces 条数=9, 流式记录首token延迟样例=[2246.1, 664.0], pro 汇总 tokens={'input_tokens': 337, 'output_tokens': 214, 'total_tokens': 551, 'reasoning_tokens': 188, 'cached_input_tokens': 128}, avg_latency=2185.6ms, flash 汇总 tokens={'input_tokens': 239, 'output_tokens': 57, 'total_tokens': 296, 'reasoning_tokens': 0, 'cached_input_tokens': 0}, avg_first_token=664.0ms |
| 14 | 按模型独立限流：超限 429，其他模型不受影响 | ✅ | flash 连续3次状态码=[200, 429, 429], 429 响应=[{'error': {'code': 'rate_limited', 'message': '模型 deepseek-v4-flash 触发限流，请稍后重试', 'details': {'retry_after_seconds': 9.14}}}], 同期 pro 调用 HTTP 200 |
| 15 | 指数退避重试：上游不可达时重试3次后统一报错 | ✅ | HTTP 502, code=upstream_unreachable, attempts=4, 退避序列=[0.5, 1.0, 2.0]s, 总耗时=3.51s, attempt_history=[{'attempt': 1, 'error_code': 'upstream_unreachable', 'elapsed_ms': 0.6, 'backoff_seconds': 0.5}, {'attempt': 2, 'error_code': 'upstream_unreachable', 'elapsed_ms': 2.1, 'backoff_seconds': 1.0}, {'attempt': 3, 'error_code': 'upstream_unreachable', 'elapsed_ms': 1.5, 'backoff_seconds': 2.0}] |
| 16 | 重试过程写入审计记录 | ✅ | trace: attempts=4, error_code=upstream_unreachable, history=[{'attempt': 1, 'error_code': 'upstream_unreachable', 'elapsed_ms': 0.6, 'backoff_seconds': 0.5}, {'attempt': 2, 'error_code': 'upstream_unreachable', 'elapsed_ms': 2.1, 'backoff_seconds': 1.0}, {'attempt': 3, 'error_code': 'upstream_unreachable', 'elapsed_ms': 1.5, 'backoff_seconds': 2.0}] |
| 17 | 故障恢复后调用正常 | ✅ | HTTP 200, content='RECOVERED' |
| 18 | 统一错误码：未知模型 | ✅ | HTTP 404, error={'code': 'unknown_model', 'message': '未注册的模型: not-exist', 'details': {'available': ['deepseek-v4-flash', 'deepseek-v4-pro']}} |
| 19 | 统一错误码：非法请求体 | ✅ | HTTP 400, code=invalid_request |
| 20 | 统一错误码：流式与结构化混用拦截 | ✅ | HTTP 400, code=stream_structured_conflict |
