"""协议适配层：按协议名注册适配器，供编排层按模型路由选用。"""

from .anthropic_messages import AnthropicMessagesAdapter
from .base import AdapterRequest, BaseAdapter, Completion, Usage
from .openai_responses import OpenAIResponsesAdapter

ADAPTERS: dict[str, type[BaseAdapter]] = {
    OpenAIResponsesAdapter.protocol: OpenAIResponsesAdapter,
    AnthropicMessagesAdapter.protocol: AnthropicMessagesAdapter,
}

__all__ = [
    "ADAPTERS",
    "AdapterRequest",
    "BaseAdapter",
    "Completion",
    "Usage",
    "OpenAIResponsesAdapter",
    "AnthropicMessagesAdapter",
]