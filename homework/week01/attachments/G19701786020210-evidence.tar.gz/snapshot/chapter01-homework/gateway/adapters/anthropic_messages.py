"""Anthropic Messages API 适配器（POST /anthropic/v1/messages，x-api-key 鉴权）。"""

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from ..core.config import UPSTREAM_TIMEOUT
from ..core.errors import GatewayError, upstream_error_from_status
from .base import (
    AdapterRequest,
    BaseAdapter,
    Completion,
    Usage,
    iter_sse,
    wrap_transport_error,
)


class AnthropicMessagesAdapter(BaseAdapter):
    protocol = "anthropic_messages"

    def _build_body(self, req: AdapterRequest, stream: bool) -> dict[str, Any]:
        system = req.system_text()
        rf = req.response_format
        if rf:
            schema = (
                json.dumps(rf["json_schema"]["schema"], ensure_ascii=False)
                if rf["type"] == "json_schema"
                else "一个合法的 JSON 对象"
            )
            system += (
                "\n\n你必须只输出一个合法 JSON 对象，不要输出任何解释、前后缀或 Markdown 代码块。"
                f"\n输出必须符合以下 JSON Schema：\n{schema}"
            )
        body: dict[str, Any] = {
            "model": self.route.upstream_model,
            "max_tokens": req.max_tokens,
            "messages": req.chat_messages(),
            "stream": stream,
            "thinking": {"type": "disabled"},
        }
        if system:
            body["system"] = system
        if req.temperature is not None:
            body["temperature"] = req.temperature
        return body

    def _headers(self) -> dict[str, str]:
        return {"x-api-key": self._api_key(), "anthropic-version": "2023-06-01"}

    @staticmethod
    def _parse_usage(raw: dict | None) -> Usage:
        raw = raw or {}
        return Usage(
            input_tokens=raw.get("input_tokens", 0),
            output_tokens=raw.get("output_tokens", 0),
            reasoning_tokens=(raw.get("output_tokens_details") or {}).get("thinking_tokens", 0),
            cached_input_tokens=raw.get("cache_read_input_tokens", 0),
        )

    async def complete(self, req: AdapterRequest) -> Completion:
        url = f"{self.route.base_url}/anthropic/v1/messages"
        try:
            resp = await self.client.post(
                url, headers=self._headers(), json=self._build_body(req, False),
                timeout=UPSTREAM_TIMEOUT,
            )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc) from exc
        if resp.status_code != 200:
            raise upstream_error_from_status(resp.status_code, resp.text)
        data = resp.json()
        content = "".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        )
        return Completion(
            content=content,
            usage=self._parse_usage(data.get("usage")),
            finish_reason=data.get("stop_reason", ""),
        )

    async def stream(self, req: AdapterRequest) -> AsyncIterator[dict]:
        url = f"{self.route.base_url}/anthropic/v1/messages"
        usage = Usage()
        finish_reason = ""
        try:
            async with self.client.stream(
                "POST", url, headers=self._headers(),
                json=self._build_body(req, True), timeout=UPSTREAM_TIMEOUT,
            ) as resp:
                if resp.status_code != 200:
                    body = (await resp.aread()).decode(errors="replace")
                    raise upstream_error_from_status(resp.status_code, body)
                async for _event, data in iter_sse(resp):
                    etype = data.get("type", "")
                    if etype == "message_start":
                        usage = self._parse_usage(data.get("message", {}).get("usage"))
                    elif etype == "content_block_delta":
                        delta = data.get("delta", {})
                        if delta.get("type") == "text_delta" and delta.get("text"):
                            yield {"type": "delta", "text": delta["text"]}
                    elif etype == "message_delta":
                        delta_usage = data.get("usage", {})
                        usage.output_tokens = delta_usage.get("output_tokens", usage.output_tokens)
                        details = delta_usage.get("output_tokens_details") or {}
                        usage.reasoning_tokens = details.get("thinking_tokens", usage.reasoning_tokens)
                        finish_reason = data.get("delta", {}).get("stop_reason", "") or finish_reason
                    elif etype == "message_stop":
                        yield {"type": "usage", "usage": usage, "finish_reason": finish_reason}
                        return
                    elif etype == "error":
                        raise GatewayError(
                            "upstream_error",
                            f"上游流式失败: {json.dumps(data, ensure_ascii=False)[:300]}",
                            502,
                            retryable=True,
                        )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc) from exc