"""OpenAI Responses API 适配器（POST /v1/responses，Bearer 鉴权）。"""

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from ..core.config import UPSTREAM_TIMEOUT
from ..core.errors import GatewayError, upstream_error_from_status
from .base import (
    AdapterRequest,
    BaseAdapter,
    Completion,
    Usage,
    iter_sse,
    wrap_transport_error,
)


class OpenAIResponsesAdapter(BaseAdapter):
    protocol = "openai_responses"

    def _build_body(self, req: AdapterRequest, stream: bool) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self.route.upstream_model,
            "input": req.chat_messages(),
            "max_output_tokens": req.max_tokens,
            "stream": stream,
        }
        system = req.system_text()
        if system:
            body["instructions"] = system
        if req.temperature is not None:
            body["temperature"] = req.temperature
        rf = req.response_format
        if rf:
            if rf["type"] == "json_schema":
                spec = rf["json_schema"]
                body["text"] = {
                    "format": {
                        "type": "json_schema",
                        "name": spec.get("name", "response"),
                        "strict": True,
                        "schema": spec["schema"],
                    }
                }
            elif rf["type"] == "json_object":
                body["text"] = {"format": {"type": "json_object"}}
        return body

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._api_key()}"}

    @staticmethod
    def _parse_usage(raw: dict | None) -> Usage:
        raw = raw or {}
        return Usage(
            input_tokens=raw.get("input_tokens", 0),
            output_tokens=raw.get("output_tokens", 0),
            reasoning_tokens=(raw.get("output_tokens_details") or {}).get("reasoning_tokens", 0),
            cached_input_tokens=(raw.get("input_tokens_details") or {}).get("cached_tokens", 0),
        )

    async def complete(self, req: AdapterRequest) -> Completion:
        url = f"{self.route.base_url}/v1/responses"
        try:
            resp = await self.client.post(
                url, headers=self._headers(), json=self._build_body(req, False),
                timeout=UPSTREAM_TIMEOUT,
            )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc) from exc
        if resp.status_code != 200:
            raise upstream_error_from_status(resp.status_code, resp.text)
        data = resp.json()
        if data.get("status") != "completed":
            raise GatewayError(
                "upstream_incomplete",
                f"Responses 状态异常: {data.get('status')} {data.get('error')}",
                502,
                retryable=True,
            )
        parts: list[str] = []
        for item in data.get("output", []):
            if item.get("type") == "message":
                for block in item.get("content", []):
                    if block.get("type") == "output_text":
                        parts.append(block.get("text", ""))
        return Completion(
            content="".join(parts),
            usage=self._parse_usage(data.get("usage")),
            finish_reason=data.get("status", ""),
        )

    async def stream(self, req: AdapterRequest) -> AsyncIterator[dict]:
        url = f"{self.route.base_url}/v1/responses"
        try:
            async with self.client.stream(
                "POST", url, headers=self._headers(),
                json=self._build_body(req, True), timeout=UPSTREAM_TIMEOUT,
            ) as resp:
                if resp.status_code != 200:
                    body = (await resp.aread()).decode(errors="replace")
                    raise upstream_error_from_status(resp.status_code, body)
                async for event, data in iter_sse(resp):
                    etype = data.get("type", event)
                    if etype == "response.output_text.delta":
                        text = data.get("delta", "")
                        if text:
                            yield {"type": "delta", "text": text}
                    elif etype == "response.completed":
                        response = data.get("response", {})
                        yield {
                            "type": "usage",
                            "usage": self._parse_usage(response.get("usage")),
                            "finish_reason": response.get("status", "completed"),
                        }
                        return
                    elif etype in ("response.failed", "response.incomplete", "error"):
                        raise GatewayError(
                            "upstream_error",
                            f"上游流式失败: {json.dumps(data, ensure_ascii=False)[:300]}",
                            502,
                            retryable=True,
                        )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc) from exc