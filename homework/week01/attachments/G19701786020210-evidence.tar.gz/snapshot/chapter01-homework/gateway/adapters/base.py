"""适配器公共类型与工具：统一请求/用量模型、SSE 解析、传输错误映射。

统一内部约定：
- complete() 返回 Completion(content, usage, finish_reason)
- stream() 逐块产出 {"type": "delta", "text": str}，结束时产出
  {"type": "usage", "usage": Usage, "finish_reason": str}
"""

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

import httpx

from ..core.config import ModelRoute
from ..core.errors import GatewayError


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cached_input_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def to_dict(self) -> dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "cached_input_tokens": self.cached_input_tokens,
        }


@dataclass
class Completion:
    content: str
    usage: Usage
    finish_reason: str = ""


@dataclass
class AdapterRequest:
    messages: list[dict[str, str]]
    max_tokens: int = 2048
    temperature: float | None = None
    response_format: dict[str, Any] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def system_text(self) -> str:
        return "\n".join(m["content"] for m in self.messages if m["role"] == "system")

    def chat_messages(self) -> list[dict[str, str]]:
        return [m for m in self.messages if m["role"] != "system"]


def wrap_transport_error(exc: Exception) -> GatewayError:
    if isinstance(exc, httpx.TimeoutException):
        return GatewayError("upstream_timeout", f"上游超时: {exc}", 504, retryable=True)
    return GatewayError("upstream_unreachable", f"上游连接失败: {exc}", 502, retryable=True)


async def iter_sse(response: httpx.Response) -> AsyncIterator[tuple[str, dict]]:
    event = ""
    data_lines: list[str] = []
    async for line in response.aiter_lines():
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].strip())
        elif line == "":
            if data_lines:
                raw = "\n".join(data_lines)
                if raw == "[DONE]":
                    return
                try:
                    yield event, json.loads(raw)
                except json.JSONDecodeError:
                    pass
            event = ""
            data_lines = []


class BaseAdapter:
    protocol = "base"

    def __init__(self, route: ModelRoute, client: httpx.AsyncClient) -> None:
        self.route = route
        self.client = client

    def _api_key(self) -> str:
        key = self.route.api_key()
        if not key:
            raise GatewayError(
                "missing_api_key",
                f"环境变量 {self.route.api_key_env} 未设置",
                500,
            )
        return key

    async def complete(self, req: AdapterRequest) -> Completion:
        raise NotImplementedError

    async def stream(self, req: AdapterRequest) -> AsyncIterator[dict]:
        raise NotImplementedError
        yield {}