"""可观测性：每次调用的 token 分类统计、延迟、首 token 延迟、重试历史。

内存保留最近 1000 条，同时追加写入 JSONL 文件便于离线审计。
"""

import json
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any


class TraceStore:
    def __init__(self, jsonl_path: Path) -> None:
        self.jsonl_path = jsonl_path
        self._lock = threading.Lock()
        self._traces: deque[dict[str, Any]] = deque(maxlen=1000)
        self.rate_limited_counts: dict[str, int] = {}

    def record(self, trace: dict[str, Any]) -> None:
        trace = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **trace}
        with self._lock:
            self._traces.append(trace)
            self.jsonl_path.parent.mkdir(parents=True, exist_ok=True)
            with self.jsonl_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(trace, ensure_ascii=False) + "\n")

    def count_rate_limited(self, model: str) -> None:
        with self._lock:
            self.rate_limited_counts[model] = self.rate_limited_counts.get(model, 0) + 1

    def list(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._traces)[-limit:]

    def metrics(self) -> dict[str, Any]:
        with self._lock:
            traces = list(self._traces)
        per_model: dict[str, Any] = {}
        for t in traces:
            m = per_model.setdefault(t["model"], {
                "calls": 0,
                "success": 0,
                "errors": 0,
                "tokens": {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "reasoning_tokens": 0,
                    "cached_input_tokens": 0,
                },
                "latency_ms_sum": 0.0,
                "first_token_ms_samples": [],
                "retries": 0,
            })
            m["calls"] += 1
            if t["status"] == "success":
                m["success"] += 1
            else:
                m["errors"] += 1
            for key, value in (t.get("usage") or {}).items():
                if key in m["tokens"]:
                    m["tokens"][key] += value
            m["latency_ms_sum"] += t.get("latency_ms") or 0
            if t.get("first_token_ms") is not None:
                m["first_token_ms_samples"].append(t["first_token_ms"])
            m["retries"] += max(0, (t.get("attempts") or 1) - 1)
        for name, m in per_model.items():
            calls = m["calls"]
            m["avg_latency_ms"] = round(m.pop("latency_ms_sum") / calls, 1) if calls else 0
            samples = m.pop("first_token_ms_samples")
            m["avg_first_token_ms"] = round(sum(samples) / len(samples), 1) if samples else None
            m["rate_limited_rejections"] = self.rate_limited_counts.get(name, 0)
        return {"models": per_model, "total_calls": len(traces)}