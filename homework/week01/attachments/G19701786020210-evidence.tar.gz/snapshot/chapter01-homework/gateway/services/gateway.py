"""网关编排：路由 → 限流 → Prompt 渲染 → 重试调用 → 结构化校验 → 记录审计。"""

import asyncio
import json
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx
import jsonschema

from ..adapters import ADAPTERS, AdapterRequest, BaseAdapter, Usage
from ..core.config import (
    DATA_DIR,
    RETRY_BASE_DELAY,
    RETRY_MAX_DELAY,
    RETRY_MAX_RETRIES,
    ModelRoute,
    default_routes,
)
from ..core.errors import GatewayError
from ..core.ratelimit import RateLimiter
from ..core.retry import run_with_retry
from .observability import TraceStore
from .prompts import PromptStore


def _parse_json_content(content: str) -> Any:
    text = content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    return json.loads(text.strip())


def validate_structured(content: str, response_format: dict) -> Any:
    try:
        parsed = _parse_json_content(content)
    except json.JSONDecodeError as exc:
        raise GatewayError(
            "invalid_json",
            f"模型输出不是合法 JSON: {exc}",
            502,
            retryable=True,
            details={"content_preview": content[:200]},
        ) from exc
    if response_format["type"] == "json_schema":
        schema = response_format["json_schema"]["schema"]
        try:
            jsonschema.validate(parsed, schema)
        except jsonschema.ValidationError as exc:
            raise GatewayError(
                "schema_violation",
                f"模型输出不符合 JSON Schema: {exc.message}",
                502,
                retryable=True,
                details={"content_preview": content[:200]},
            ) from exc
    return parsed


class GatewayService:
    def __init__(self) -> None:
        self.routes: dict[str, ModelRoute] = default_routes()
        self.client = httpx.AsyncClient(trust_env=False)
        self.adapters: dict[str, BaseAdapter] = {
            name: ADAPTERS[route.adapter](route, self.client)
            for name, route in self.routes.items()
        }
        self.prompts = PromptStore(DATA_DIR / "prompts.json")
        self.limiter = RateLimiter(self.routes)
        self.traces = TraceStore(DATA_DIR / "traces.jsonl")

    async def aclose(self) -> None:
        await self.client.aclose()

    def resolve(self, model: str) -> tuple[ModelRoute, BaseAdapter]:
        route = self.routes.get(model)
        if not route:
            raise GatewayError(
                "unknown_model",
                f"未注册的模型: {model}",
                404,
                details={"available": sorted(self.routes)},
            )
        return route, self.adapters[model]

    def _prepare(self, payload: dict) -> tuple[ModelRoute, BaseAdapter, AdapterRequest, dict | None]:
        route, adapter = self.resolve(payload["model"])
        self.limiter.acquire(route.name)

        messages = [dict(m) for m in payload.get("messages", [])]
        prompt_meta = None
        prompt_ref = payload.get("prompt")
        if prompt_ref:
            rendered, version = self.prompts.render(
                prompt_ref["name"], prompt_ref.get("version"), prompt_ref.get("variables", {})
            )
            messages.insert(0, {"role": "system", "content": rendered})
            prompt_meta = {"name": prompt_ref["name"], "version": version}

        response_format = payload.get("response_format")
        if payload.get("stream") and response_format and response_format.get("type") != "text":
            raise GatewayError(
                "stream_structured_conflict",
                "stream=true 不能与 JSON 结构化输出同时使用",
                400,
            )
        req = AdapterRequest(
            messages=messages,
            max_tokens=payload.get("max_tokens", 2048),
            temperature=payload.get("temperature"),
            response_format=response_format,
        )
        return route, adapter, req, prompt_meta

    async def call(self, payload: dict) -> dict:
        request_id = uuid.uuid4().hex[:16]
        route, adapter, req, prompt_meta = self._prepare(payload)
        started = time.monotonic()
        trace: dict[str, Any] = {
            "request_id": request_id,
            "model": route.name,
            "adapter": adapter.protocol,
            "upstream_model": route.upstream_model,
            "stream": False,
            "prompt": prompt_meta,
        }
        try:
            completion, history = await run_with_retry(lambda: adapter.complete(req))
            parsed = None
            rf = req.response_format
            if rf and rf.get("type") in ("json_object", "json_schema"):
                parsed = validate_structured(completion.content, rf)
            latency_ms = round((time.monotonic() - started) * 1000, 1)
            trace.update({
                "status": "success",
                "attempts": len(history) + 1,
                "attempt_history": history,
                "usage": completion.usage.to_dict(),
                "latency_ms": latency_ms,
                "first_token_ms": None,
            })
            return {
                "request_id": request_id,
                "model": route.name,
                "adapter": adapter.protocol,
                "content": completion.content,
                "parsed": parsed,
                "finish_reason": completion.finish_reason,
                "usage": completion.usage.to_dict(),
                "latency_ms": latency_ms,
                "first_token_ms": None,
                "attempts": len(history) + 1,
                "attempt_history": history,
                "prompt": prompt_meta,
            }
        except GatewayError as exc:
            trace.update({
                "status": "error",
                "error_code": exc.code,
                "attempts": exc.details.get("attempts", 1),
                "attempt_history": exc.details.get("attempt_history", []),
                "usage": None,
                "latency_ms": round((time.monotonic() - started) * 1000, 1),
                "first_token_ms": None,
            })
            raise
        finally:
            self.traces.record(trace)

    def prepare_stream(self, payload: dict) -> dict:
        """在返回 SSE 响应前完成路由/限流/模板渲染，错误以普通 JSON 返回。"""
        route, adapter, req, prompt_meta = self._prepare(payload)
        return {
            "request_id": uuid.uuid4().hex[:16],
            "route": route,
            "adapter": adapter,
            "req": req,
            "prompt_meta": prompt_meta,
            "started": time.monotonic(),
        }

    async def stream_events(self, ctx: dict) -> AsyncIterator[str]:
        request_id = ctx["request_id"]
        route: ModelRoute = ctx["route"]
        adapter: BaseAdapter = ctx["adapter"]
        req: AdapterRequest = ctx["req"]
        prompt_meta = ctx["prompt_meta"]
        started = ctx["started"]
        first_token_ms: float | None = None
        usage = Usage()
        finish_reason = ""
        history: list[dict] = []
        trace: dict[str, Any] = {
            "request_id": request_id,
            "model": route.name,
            "adapter": adapter.protocol,
            "upstream_model": route.upstream_model,
            "stream": True,
            "prompt": prompt_meta,
        }

        def sse(event: str, data: dict) -> str:
            return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"

        try:
            attempt = 0
            while True:
                attempt += 1
                emitted = False
                try:
                    async for event in adapter.stream(req):
                        if event["type"] == "delta":
                            if first_token_ms is None:
                                first_token_ms = round((time.monotonic() - started) * 1000, 1)
                            emitted = True
                            yield sse("delta", {
                                "type": "content.delta",
                                "request_id": request_id,
                                "text": event["text"],
                            })
                        elif event["type"] == "usage":
                            usage = event["usage"]
                            finish_reason = event.get("finish_reason", "")
                    break
                except GatewayError as exc:
                    if emitted or not exc.retryable or attempt > RETRY_MAX_RETRIES:
                        raise
                    delay = min(RETRY_BASE_DELAY * (2 ** (attempt - 1)), RETRY_MAX_DELAY)
                    history.append({
                        "attempt": attempt,
                        "error_code": exc.code,
                        "backoff_seconds": round(delay, 3),
                    })
                    await asyncio.sleep(delay)

            latency_ms = round((time.monotonic() - started) * 1000, 1)
            trace.update({
                "status": "success",
                "attempts": attempt,
                "attempt_history": history,
                "usage": usage.to_dict(),
                "latency_ms": latency_ms,
                "first_token_ms": first_token_ms,
            })
            yield sse("done", {
                "type": "response.completed",
                "request_id": request_id,
                "model": route.name,
                "adapter": adapter.protocol,
                "finish_reason": finish_reason,
                "usage": usage.to_dict(),
                "latency_ms": latency_ms,
                "first_token_ms": first_token_ms,
                "attempts": attempt,
                "prompt": prompt_meta,
            })
        except GatewayError as exc:
            trace.update({
                "status": "error",
                "error_code": exc.code,
                "attempts": exc.details.get("attempts", attempt),
                "attempt_history": exc.details.get("attempt_history", history),
                "usage": None,
                "latency_ms": round((time.monotonic() - started) * 1000, 1),
                "first_token_ms": first_token_ms,
            })
            yield sse("error", {"type": "error", **exc.envelope(request_id)})
        finally:
            self.traces.record(trace)