"""Prompt 模板存储：版本管理 + {{变量}} 严格替换，JSON 文件持久化。"""

import json
import re
import threading
import time
from pathlib import Path
from typing import Any

from ..core.errors import GatewayError

_VAR_RE = re.compile(r"{{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*}}")


class PromptStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._data: dict[str, dict[str, Any]] = {}
        if path.exists():
            self._data = json.loads(path.read_text(encoding="utf-8"))

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def create(self, name: str, template: str) -> dict[str, Any]:
        with self._lock:
            entry = self._data.setdefault(name, {"versions": []})
            version = f"v{len(entry['versions']) + 1}"
            record = {
                "version": version,
                "template": template,
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            }
            entry["versions"].append(record)
            entry["latest"] = version
            self._save()
            return {"name": name, **record}

    def get(self, name: str, version: str | None = None) -> dict[str, Any]:
        entry = self._data.get(name)
        if not entry:
            raise GatewayError("prompt_not_found", f"Prompt 模板不存在: {name}", 404)
        wanted = version or entry["latest"]
        for record in entry["versions"]:
            if record["version"] == wanted:
                return {"name": name, **record}
        raise GatewayError(
            "prompt_version_not_found",
            f"Prompt 版本不存在: {name}@{wanted}",
            404,
            details={"available": [r["version"] for r in entry["versions"]]},
        )

    def list(self) -> list[dict[str, Any]]:
        return [
            {
                "name": name,
                "latest": entry["latest"],
                "versions": [r["version"] for r in entry["versions"]],
            }
            for name, entry in self._data.items()
        ]

    def render(self, name: str, version: str | None, variables: dict[str, str]) -> tuple[str, str]:
        record = self.get(name, version)
        template = record["template"]
        required = set(_VAR_RE.findall(template))
        missing = sorted(required - set(variables))
        if missing:
            raise GatewayError(
                "missing_prompt_variable",
                f"模板 {name}@{record['version']} 缺少变量: {', '.join(missing)}",
                400,
                details={"missing": missing},
            )
        rendered = _VAR_RE.sub(lambda m: str(variables[m.group(1)]), template)
        return rendered, record["version"]