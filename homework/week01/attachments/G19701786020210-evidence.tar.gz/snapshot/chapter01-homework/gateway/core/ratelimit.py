"""按模型独立的令牌桶限流，超限立即拒绝（429）。"""

import time

from .config import ModelRoute
from .errors import GatewayError


class TokenBucket:
    def __init__(self, rpm: float, burst: int) -> None:
        self.capacity = float(burst)
        self.tokens = float(burst)
        self.refill_per_second = rpm / 60.0
        self.updated = time.monotonic()

    def reconfigure(self, rpm: float, burst: int) -> None:
        self.capacity = float(burst)
        self.tokens = float(burst)
        self.refill_per_second = rpm / 60.0
        self.updated = time.monotonic()

    def try_acquire(self) -> tuple[bool, float]:
        now = time.monotonic()
        self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.refill_per_second)
        self.updated = now
        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True, 0.0
        deficit = 1.0 - self.tokens
        retry_after = deficit / self.refill_per_second if self.refill_per_second > 0 else float("inf")
        return False, retry_after


class RateLimiter:
    def __init__(self, routes: dict[str, ModelRoute]) -> None:
        self.buckets = {name: TokenBucket(r.rpm, r.burst) for name, r in routes.items()}

    def ensure_model(self, route: ModelRoute) -> None:
        if route.name not in self.buckets:
            self.buckets[route.name] = TokenBucket(route.rpm, route.burst)

    def acquire(self, model: str) -> None:
        bucket = self.buckets[model]
        ok, retry_after = bucket.try_acquire()
        if not ok:
            raise GatewayError(
                "rate_limited",
                f"模型 {model} 触发限流，请稍后重试",
                429,
                details={"retry_after_seconds": round(retry_after, 2)},
            )

    def reconfigure(self, model: str, rpm: float, burst: int) -> None:
        self.buckets[model].reconfigure(rpm, burst)