"""指数退避重试：仅对可重试错误生效，最多 RETRY_MAX_RETRIES 次重试。"""

import asyncio
import time
from collections.abc import Awaitable, Callable
from typing import TypeVar

from .config import RETRY_BASE_DELAY, RETRY_MAX_DELAY, RETRY_MAX_RETRIES
from .errors import GatewayError

T = TypeVar("T")


async def run_with_retry(
    fn: Callable[[], Awaitable[T]],
    max_retries: int = RETRY_MAX_RETRIES,
    base_delay: float = RETRY_BASE_DELAY,
    max_delay: float = RETRY_MAX_DELAY,
) -> tuple[T, list[dict]]:
    """返回 (结果, 尝试历史)。尝试历史含每次失败的错误码与退避时长。"""
    history: list[dict] = []
    attempt = 0
    while True:
        attempt += 1
        started = time.monotonic()
        try:
            result = await fn()
            return result, history
        except GatewayError as exc:
            elapsed_ms = round((time.monotonic() - started) * 1000, 1)
            if not exc.retryable or attempt > max_retries:
                exc.details = {
                    **exc.details,
                    "attempts": attempt,
                    "attempt_history": history,
                }
                raise
            delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
            history.append({
                "attempt": attempt,
                "error_code": exc.code,
                "elapsed_ms": elapsed_ms,
                "backoff_seconds": round(delay, 3),
            })
            await asyncio.sleep(delay)