from typing import Any


class GatewayError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        http_status: int = 500,
        retryable: bool = False,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.http_status = http_status
        self.retryable = retryable
        self.details = details or {}

    def envelope(self, request_id: str = "") -> dict[str, Any]:
        err: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.details:
            err["details"] = self.details
        if request_id:
            err["request_id"] = request_id
        return {"error": err}


def upstream_error_from_status(status: int, body: str) -> GatewayError:
    message = f"upstream HTTP {status}: {body[:300]}"
    if status in (401, 403):
        return GatewayError("upstream_auth", message, 502)
    if status == 404:
        return GatewayError("upstream_model_not_found", message, 502)
    if status == 429:
        return GatewayError("upstream_rate_limited", message, 502, retryable=True)
    if status >= 500:
        return GatewayError("upstream_error", message, 502, retryable=True)
    return GatewayError("upstream_bad_request", message, 502)