import os
from dataclasses import dataclass
from pathlib import Path

DATA_DIR = Path(os.getenv("GATEWAY_DATA_DIR", str(Path(__file__).resolve().parent.parent.parent / "data")))

RETRY_MAX_RETRIES = int(os.getenv("RETRY_MAX_RETRIES", "3"))
RETRY_BASE_DELAY = float(os.getenv("RETRY_BASE_DELAY", "0.5"))
RETRY_MAX_DELAY = float(os.getenv("RETRY_MAX_DELAY", "8"))
UPSTREAM_TIMEOUT = float(os.getenv("UPSTREAM_TIMEOUT", "120"))


@dataclass
class ModelRoute:
    name: str
    adapter: str
    base_url: str
    api_key_env: str
    upstream_model: str
    rpm: float = 60.0
    burst: int = 5

    def api_key(self) -> str:
        return os.getenv(self.api_key_env, "")


def default_routes() -> dict[str, ModelRoute]:
    base = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
    rpm = float(os.getenv("RATE_LIMIT_RPM", "60"))
    burst = int(os.getenv("RATE_LIMIT_BURST", "5"))
    return {
        "deepseek-v4-pro": ModelRoute(
            name="deepseek-v4-pro",
            adapter="openai_responses",
            base_url=base,
            api_key_env="DEEPSEEK_API_KEY",
            upstream_model="deepseek-v4-pro",
            rpm=rpm,
            burst=burst,
        ),
        "deepseek-v4-flash": ModelRoute(
            name="deepseek-v4-flash",
            adapter="anthropic_messages",
            base_url=base,
            api_key_env="DEEPSEEK_API_KEY",
            upstream_model="deepseek-v4-flash",
            rpm=rpm,
            burst=burst,
        ),
    }