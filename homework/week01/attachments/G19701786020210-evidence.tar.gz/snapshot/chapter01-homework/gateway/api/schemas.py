"""Pydantic 请求模型：入口参数校验与未知字段拦截。"""

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class Message(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class PromptRef(BaseModel):
    name: str
    version: str | None = None
    variables: dict[str, str] = Field(default_factory=dict)


class JsonSchemaSpec(BaseModel):
    name: str = "response"
    schema_: dict[str, Any] = Field(alias="schema")

    model_config = {"populate_by_name": True}


class ResponseFormat(BaseModel):
    type: Literal["text", "json_object", "json_schema"]
    json_schema: JsonSchemaSpec | None = None

    @model_validator(mode="after")
    def check_schema(self):
        if self.type == "json_schema" and self.json_schema is None:
            raise ValueError("type=json_schema 时必须提供 json_schema")
        return self


class LLMRequest(BaseModel):
    model_config = {"extra": "forbid"}

    model: str
    messages: list[Message] = Field(default_factory=list)
    stream: bool = False
    max_tokens: int = Field(default=2048, ge=1, le=65536)
    temperature: float | None = Field(default=None, ge=0, le=2)
    response_format: ResponseFormat | None = None
    prompt: PromptRef | None = None

    @model_validator(mode="after")
    def check_messages(self):
        if not self.messages and not self.prompt:
            raise ValueError("messages 与 prompt 至少提供一个")
        return self


class PromptCreate(BaseModel):
    model_config = {"extra": "forbid"}

    name: str = Field(min_length=1)
    template: str = Field(min_length=1)


class RateLimitUpdate(BaseModel):
    model_config = {"extra": "forbid"}

    rpm: float = Field(gt=0)
    burst: int = Field(ge=1)


class ModelOverride(BaseModel):
    model_config = {"extra": "forbid"}

    base_url: str | None = None