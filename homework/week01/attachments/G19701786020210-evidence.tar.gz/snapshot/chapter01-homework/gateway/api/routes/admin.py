"""运维接口：运行时调整限流参数 / 故障演练修改上游地址。"""

from fastapi import APIRouter, Request

from ..deps import service
from ..schemas import ModelOverride, RateLimitUpdate

router = APIRouter(prefix="/v1/admin")


@router.put("/rate-limits/{model}")
async def update_rate_limit(request: Request, model: str, body: RateLimitUpdate):
    svc = service(request)
    svc.resolve(model)
    svc.limiter.reconfigure(model, body.rpm, body.burst)
    return {"model": model, "rpm": body.rpm, "burst": body.burst}


@router.put("/models/{model}")
async def override_model(request: Request, model: str, body: ModelOverride):
    """运维/故障演练：临时修改模型上游地址（如指向不可达端口验证重试）。"""
    svc = service(request)
    route, _adapter = svc.resolve(model)
    if body.base_url is not None:
        route.base_url = body.base_url.rstrip("/")
    return {"model": model, "base_url": route.base_url}