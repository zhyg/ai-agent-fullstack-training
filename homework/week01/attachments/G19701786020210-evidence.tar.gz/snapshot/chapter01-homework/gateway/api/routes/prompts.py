"""Prompt 模板管理：创建新版本 / 列表 / 按版本查询。"""

from fastapi import APIRouter, Query, Request

from ..deps import service
from ..schemas import PromptCreate

router = APIRouter(prefix="/v1/prompts")


@router.post("")
async def create_prompt(request: Request, body: PromptCreate):
    return service(request).prompts.create(body.name, body.template)


@router.get("")
async def list_prompts(request: Request):
    return service(request).prompts.list()


@router.get("/{name}")
async def get_prompt(request: Request, name: str, version: str | None = Query(default=None)):
    return service(request).prompts.get(name, version)