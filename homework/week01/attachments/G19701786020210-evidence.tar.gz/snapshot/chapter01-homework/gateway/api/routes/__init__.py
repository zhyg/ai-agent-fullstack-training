"""路由汇总：按职责分文件，统一挂载。"""

from fastapi import APIRouter

from . import admin, llm, observability, prompts

api_router = APIRouter()
api_router.include_router(llm.router)
api_router.include_router(prompts.router)
api_router.include_router(observability.router)
api_router.include_router(admin.router)