"""统一模型调用入口与健康检查、模型列表。"""

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from ...core.errors import GatewayError
from ..deps import service
from ..schemas import LLMRequest

router = APIRouter()


@router.get("/healthz")
async def healthz():
    return {"status": "ok"}


@router.get("/v1/models")
async def list_models(request: Request):
    svc = service(request)
    return [
        {
            "model": name,
            "adapter": route.adapter,
            "upstream_model": route.upstream_model,
            "base_url": route.base_url,
            "rate_limit": {"rpm": route.rpm, "burst": route.burst},
        }
        for name, route in svc.routes.items()
    ]


@router.post("/v1/llm")
async def llm(request: Request, body: LLMRequest):
    svc = service(request)
    payload = body.model_dump(by_alias=False)
    if body.response_format and body.response_format.json_schema:
        payload["response_format"]["json_schema"] = (
            body.response_format.json_schema.model_dump(by_alias=True)
        )
    try:
        if body.stream:
            ctx = svc.prepare_stream(payload)
            return StreamingResponse(
                svc.stream_events(ctx),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )
        return await svc.call(payload)
    except GatewayError as exc:
        if exc.code == "rate_limited":
            svc.traces.count_rate_limited(body.model)
        raise