"""路由依赖：从应用状态取网关服务实例。"""

from fastapi import Request

from ..services.gateway import GatewayService


def service(request: Request) -> GatewayService:
    return request.app.state.service