"""可观测查询：调用审计明细与按模型聚合指标。"""

from fastapi import APIRouter, Query, Request

from ..deps import service

router = APIRouter()


@router.get("/v1/traces")
async def list_traces(request: Request, limit: int = Query(default=50, ge=1, le=1000)):
    return service(request).traces.list(limit)


@router.get("/v1/metrics")
async def metrics(request: Request):
    return service(request).traces.metrics()