"""FastAPI 装配：lifespan、统一错误处理、路由挂载。"""

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from .api.routes import api_router
from .core.errors import GatewayError
from .services.gateway import GatewayService


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.service = GatewayService()
    yield
    await app.state.service.aclose()


app = FastAPI(title="LLM Gateway", version="1.0.0", lifespan=lifespan)
app.include_router(api_router)


@app.exception_handler(GatewayError)
async def gateway_error_handler(request: Request, exc: GatewayError):
    return JSONResponse(status_code=exc.http_status, content=exc.envelope())


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=400, content={
        "error": {
            "code": "invalid_request",
            "message": "请求参数校验失败",
            "details": {"errors": exc.errors()[:5]},
        }
    })