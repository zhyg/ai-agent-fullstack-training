"""Teacher probes against a running student gateway. Does not modify student code.

Usage:
  1. Start probes/mock_upstream.py
  2. Start the student app with DEEPSEEK_BASE_URL=http://127.0.0.1:8799/ok
  3. python run_probes.py --base-url http://127.0.0.1:8022

Real-protocol calls are not in this script. Those were sent through a recording
proxy to https://api.deepseek.com and saved in logs/protocol-capture.jsonl.
"""

import argparse
import json
import time

import httpx


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:8022")
    parser.add_argument("--mock", default="http://127.0.0.1:8799")
    args = parser.parse_args()
    client = httpx.Client(base_url=args.base_url, timeout=20, trust_env=False)

    def override(model, scenario):
        client.put(f"/v1/admin/models/{model}", json={"base_url": f"{args.mock}/{scenario}"})

    def call(model, extra=None):
        payload = {"model": model, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 16}
        if extra:
            payload.update(extra)
        response = client.post("/v1/llm", json=payload)
        try:
            body = response.json()
        except json.JSONDecodeError:
            body = {"raw": response.text[:200]}
        error = body.get("error") or {}
        print(model, response.status_code, error.get("code"), "attempts", (error.get("details") or {}).get("attempts"), "parsed", body.get("parsed"))
        return response

    client.put("/v1/admin/rate-limits/deepseek-v4-pro", json={"rpm": 6000, "burst": 30})
    client.put("/v1/admin/rate-limits/deepseek-v4-flash", json={"rpm": 6000, "burst": 30})

    print("-- 400/401 no retry --")
    override("deepseek-v4-pro", "fail400")
    call("deepseek-v4-pro")
    override("deepseek-v4-pro", "fail401")
    call("deepseek-v4-pro")

    print("-- 500 retries --")
    override("deepseek-v4-pro", "fail500")
    started = time.monotonic()
    call("deepseek-v4-pro")
    print("elapsed", round(time.monotonic() - started, 2))

    print("-- twice then ok --")
    override("deepseek-v4-flash", "twice-then-ok")
    call("deepseek-v4-flash", {"response_format": {"type": "json_object"}})

    print("-- bad/truncated/empty/fenced json --")
    for scenario in ("bad-json", "truncated-json", "empty-json", "fenced-json"):
        override("deepseek-v4-pro", scenario)
        call("deepseek-v4-pro", {"response_format": {"type": "json_object"}})

    print("-- stream error event --")
    override("deepseek-v4-pro", "error-event")
    events = []
    with client.stream("POST", "/v1/llm", json={"model": "deepseek-v4-pro", "stream": True, "max_tokens": 16, "messages": [{"role": "user", "content": "hi"}]}) as resp:
        event = ""
        for line in resp.iter_lines():
            if line.startswith("event:"):
                event = line[6:].strip()
            elif line.startswith("data:"):
                events.append((event, json.loads(line[5:]).get("type")))
    print(events)

    print("-- eof without terminal --")
    override("deepseek-v4-flash", "always-hang-after-delta")
    events = []
    with client.stream("POST", "/v1/llm", json={"model": "deepseek-v4-flash", "stream": True, "max_tokens": 16, "messages": [{"role": "user", "content": "hi"}]}) as resp:
        event = ""
        for line in resp.iter_lines():
            if line.startswith("event:"):
                event = line[6:].strip()
            elif line.startswith("data:"):
                events.append((event, json.loads(line[5:]).get("type")))
    print(events)

    print("-- independent rate limit --")
    override("deepseek-v4-pro", "ok")
    override("deepseek-v4-flash", "ok")
    client.put("/v1/admin/rate-limits/deepseek-v4-pro", json={"rpm": 60, "burst": 1})
    statuses = [client.post("/v1/llm", json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8}).status_code for _ in range(3)]
    other = client.post("/v1/llm", json={"model": "deepseek-v4-flash", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 8}).status_code
    print("A", statuses, "B", other)


if __name__ == "__main__":
    main()
