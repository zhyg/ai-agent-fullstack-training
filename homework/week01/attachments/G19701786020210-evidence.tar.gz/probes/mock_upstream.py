"""Local upstream mock for retry, rate-limit independence, JSON and stream failure cases.

Scenario is the first path segment. The student gateway appends /v1/responses or
/anthropic/v1/messages, so point a model base_url at http://127.0.0.1:8799/<scenario>.
Does not call the real DeepSeek API.
"""

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = 8799
LOG = "/tmp/gw-capture/mock.log"
STATE = {"calls": []}


def log(obj):
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(obj, ensure_ascii=False) + "\n")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(n) if n else b""
        parts = self.path.split("/")
        scenario = parts[1] if len(parts) > 1 else "ok"
        rest = "/" + "/".join(parts[2:])
        STATE["calls"].append({"scenario": scenario, "path": rest})
        log({"scenario": scenario, "path": rest, "body": raw.decode()[:500]})
        count = sum(1 for c in STATE["calls"] if c["scenario"] == scenario and c["path"] == rest)

        def send(code, body, ctype="application/json"):
            data = body if isinstance(body, bytes) else body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        if scenario == "fail500":
            send(500, json.dumps({"error": {"message": "boom"}}))
            return
        if scenario == "fail400":
            send(400, json.dumps({"error": {"message": "bad param"}}))
            return
        if scenario == "fail401":
            send(401, json.dumps({"error": {"message": "nope"}}))
            return
        if scenario == "fail429":
            send(429, json.dumps({"error": {"message": "slow down"}}))
            return
        if scenario == "twice-then-ok" and count < 3:
            send(503, json.dumps({"error": {"message": "temp"}}))
            return
        if scenario == "always-hang-after-delta":
            if rest.endswith("/responses"):
                payload = (
                    "event: response.output_text.delta\n"
                    'data: {"type":"response.output_text.delta","delta":"HELLO"}\n\n'
                )
            else:
                payload = (
                    "event: content_block_delta\n"
                    'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"HELLO"}}\n\n'
                )
            send(200, payload, "text/event-stream")
            return
        if scenario == "error-event":
            if rest.endswith("/responses"):
                payload = (
                    "event: response.output_text.delta\n"
                    'data: {"type":"response.output_text.delta","delta":"HELLO"}\n\n'
                    "event: error\n"
                    'data: {"type":"error","error":{"message":"midstream"}}\n\n'
                )
            else:
                payload = (
                    "event: content_block_delta\n"
                    'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"HELLO"}}\n\n'
                    "event: error\n"
                    'data: {"type":"error","error":{"message":"midstream"}}\n\n'
                )
            send(200, payload, "text/event-stream")
            return
        text = {
            "bad-json": "not json at all",
            "fenced-json": "```json\n{\"city\":\"北京\"}\n```",
            "truncated-json": "{\"city\":\"北",
            "empty-json": "",
            "nan-json": "{\"city\": NaN}",
        }.get(scenario, "{\"city\":\"北京\"}")
        if "/v1/responses" in rest:
            body = {
                "id": "mock",
                "status": "completed",
                "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}],
                "usage": {
                    "input_tokens": 3,
                    "output_tokens": 2,
                    "output_tokens_details": {"reasoning_tokens": 1},
                    "input_tokens_details": {"cached_tokens": 0},
                },
            }
            send(200, json.dumps(body))
            return
        body = {
            "id": "mock",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": text}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 3, "output_tokens": 2, "cache_read_input_tokens": 0},
        }
        send(200, json.dumps(body))

    def log_message(self, fmt, *args):
        return


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
