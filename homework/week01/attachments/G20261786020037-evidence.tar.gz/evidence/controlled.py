import asyncio
import json
import time
from pathlib import Path
import httpx

BASE='http://127.0.0.1:18920'
results=[]
async def main():
    async with httpx.AsyncClient(base_url=BASE,timeout=15) as c:
        async def reset(mode='normal',failures=0,**kw):
            await c.post('/teacher/reset',json=dict(mode=mode,failures=failures,**kw))
        async def chat(model='deepseek-v4-pro',**kw):
            data=dict(model=model,messages=[{'role':'system','content':'teacher system'},{'role':'user','content':'teacher input'}],max_tokens=64)
            data.update(kw)
            if 'prompt' in kw: data.pop('messages')
            r=await c.post('/v1/chat',json=data)
            return {'http':r.status_code,'body':r.json() if not kw.get('stream') else r.text,'request_id':r.headers.get('x-request-id')}
        async def record(name,value):
            state=(await c.get('/teacher/state')).json()
            results.append({'case':name,'result':value,'upstream':state['calls']})
        await reset()
        for model in ('deepseek-v4-pro','deepseek-flash'):
            await reset()
            r=await chat(model)
            assert r['http']==200
            usage=r['body']['usage']
            assert usage['input_tokens']==(17 if model=='deepseek-v4-pro' else 18)
            assert usage['total_tokens']==(26 if model=='deepseek-v4-pro' else 27)
            await record('A02-A03/F07-'+model,r)
        await reset()
        r=await chat('unknown')
        assert r['http']==404
        await record('A04',r)
        for model in ('deepseek-v4-pro','deepseek-flash'):
            await reset('gate')
            chunks=[]
            t=time.monotonic()
            async with c.stream('POST','/v1/chat',json={'model':model,'messages':[{'role':'user','content':'gate'}],'stream':True}) as r:
                async for line in r.aiter_lines():
                    chunks.append({'elapsed':time.monotonic()-t,'line':line})
                    if '门控OK' in line:
                        s=(await c.get('/teacher/state')).json()
                        assert s['released'] is False
                        await c.post('/teacher/release')
            raw='\n'.join(x['line'] for x in chunks)
            assert 'event: done' in raw and 'event: error' not in raw
            await record('F01-gate-'+model,chunks)
            for mode in ('interrupt','event_error'):
                await reset(mode)
                r=await chat(model,stream=True)
                assert 'event: error' in r['body'] and 'event: done\n' not in r['body']
                assert len((await c.get('/teacher/state')).json()['calls'])==1
                await record('F02-'+mode+'-'+model,r)
            for mode in ('normal','invalid','empty','truncated','schema_bad'):
                await reset(mode)
                fmt={'type':'json_schema','json_schema':{'name':'answer','schema':{'type':'object','properties':{'answer':{'type':'string'}},'required':['answer']}}}
                r=await chat(model,response_format=fmt)
                assert r['http']==(200 if mode=='normal' else 502)
                await record('F03-F04-'+mode+'-'+model,r)
            for mode,n in (('retry',2),('retry',99),('error400',99),('error401',99),('error429',2)):
                await reset(mode,n)
                r=await chat(model)
                count=len((await c.get('/teacher/state')).json()['calls'])
                assert count==(3 if n==2 else 4 if mode=='retry' else 1)
                if mode=='retry' and n==2:
                    assert [x.get('backoff_ms') for x in r['body']['attempts'][:2]]==[50,100]
                await record('F08-F09-'+mode+'-'+str(n)+'-'+model,r)
        await reset()
        name='teacher_versions'
        a=await c.post('/v1/prompts',json={'name':name,'template':'OLD {{word}}'})
        b=await c.post('/v1/prompts/'+name+'/versions',json={'template':'NEW {{word}}!'})
        assert a.status_code==201 and b.status_code==201
        for version in (1,2):
            await reset()
            r=await chat(prompt={'name':name,'version':version,'variables':{'word':'ASYMMETRIC'}})
            state=(await c.get('/teacher/state')).json()
            assert state['calls'][0]['body']['input'][0]['content']==('OLD ASYMMETRIC' if version==1 else 'NEW ASYMMETRIC!')
            await record('F05-v'+str(version),r)
        for prompt in ({'name':'missing','version':1,'variables':{}},{'name':name,'version':99,'variables':{'word':'X'}},{'name':name,'version':1,'variables':{}}):
            await reset()
            r=await chat(prompt=prompt)
            assert r['http'] in (404,422)
            assert not (await c.get('/teacher/state')).json()['calls']
            await record('F06-'+str(prompt),r)
        await reset('retry',99)
        failed=await chat()
        lookup=await c.get('/v1/metrics/calls/'+failed['request_id'])
        assert lookup.status_code==200 and lookup.json()['status']=='error'
        await record('F07-failure-ledger',lookup.json())
        # Pre-upstream failures are also calls under the published criterion.
        r=await chat('unknown')
        lookup=await c.get('/v1/metrics/calls/'+r['request_id'])
        await record('F07-unknown-ledger',{'original':r,'lookup_http':lookup.status_code,'lookup':lookup.json()})
        await reset(limits=True)
        a=await chat('deepseek-flash')
        b=await chat('deepseek-flash')
        d=await chat('deepseek-v4-pro')
        assert [a['http'],b['http'],d['http']]==[200,429,200]
        await asyncio.sleep(.6)
        e=await chat('deepseek-flash')
        assert e['http']==200
        await record('F10-F11',{'statuses':[a['http'],b['http'],d['http'],e['http']]})
        recent=await c.get('/v1/metrics/recent',params={'limit':200})
        Path('/tmp/grade-892920/controlled-metrics.json').write_text(json.dumps(recent.json(),ensure_ascii=False,indent=2))
    Path('/tmp/grade-892920/controlled-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print('CONTROLLED COMPLETE:',len(results),'cases; assertions passed; unknown-ledger recorded separately')
asyncio.run(main())
