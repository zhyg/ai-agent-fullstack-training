import json
from pathlib import Path
root=Path('/tmp/grade-892920')
rows=json.loads((root/'controlled-results.json').read_text())
metrics=json.loads((root/'controlled-metrics.json').read_text())['records']
out=[]
for row in rows:
    case=row['case']
    if case.startswith('F01'):
        done=next(json.loads(x['line'][6:]) for x in row['result'] if x['line'].startswith('data: {') and 'first_text_ms' in x['line'])
        assert done['latency']['ttft_ms']>=100
        assert done['usage']['output_tokens']==9
        assert done['usage']['cached_input_tokens']==5
        assert done['usage']['input_tokens']==(17 if case.endswith('pro') else 18)
        out.append({'case':case,'checked_latency':done['latency'],'usage':done['usage']})
    if case.startswith('F08-F09-retry-2'):
        times=[x['time'] for x in row['upstream']]
        intervals=[round(times[i+1]-times[i],4) for i in range(2)]
        assert intervals[0]>=.045 and intervals[1]>=.095
        out.append({'case':case,'actual_upstream_intervals_seconds':intervals})
record=next(x for x in metrics if x['model']=='deepseek-flash' and x['error_code']=='UPSTREAM_STREAM_INTERRUPTED')
assert record['usage']['input_tokens']==0
source=next(x for x in rows if x['case']=='F02-interrupt-deepseek-flash')['upstream'][0]
out.append({'case':'F07-known-usage-lost','expected_known_input_tokens':18,'actual_input_tokens':0,
    'request_id':record['request_id'],'basis':'message_start usage: input=11, cache_read=5, cache_creation=2; stream terminated after text',
    'status':record['status'],'ttft_ms':record['latency']['ttft_ms']})
(root/'checked-evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('Evidence cross-check passed: token categories, cumulative snapshots, TTFT after start/ping, actual 50/100ms backoff; confirmed lost known usage')
