import asyncio
import json
import sys
from pathlib import Path
sys.path.insert(0,'/tmp/grade-892920/student')
import httpx
from app.config import Settings
from app.services.llm_client import LLMService
from app.services.metrics import MetricsStore
from app.prompts.registry import PromptRegistry
from app.models.schemas import ChatRequest
from app.core.errors import ServiceError

async def main():
    out=[]
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18920') as c:
        for model in ('deepseek-v4-pro','deepseek-flash'):
            await c.post('/teacher/reset',json={'mode':'timeout','failures':99})
            settings=Settings(_env_file=None,deepseek_api_key='teacher-dummy-not-secret',
                deepseek_responses_base_url='http://127.0.0.1:18920/mock/v1',
                deepseek_anthropic_base_url='http://127.0.0.1:18920/mock/anthropic',request_timeout=.05,
                llm_retry_base_delay=.01,llm_retry_jitter=0)
            metrics=MetricsStore()
            service=LLMService(settings,PromptRegistry('/tmp/grade-892920/student/prompts','/tmp/grade-892920/timeout-prompts'),metrics)
            try:
                prepared=await service.prepare(ChatRequest(model=model,messages=[{'role':'user','content':'timeout'}]))
                await service.complete(prepared)
                raise AssertionError('Expected timeout')
            except ServiceError as exc:
                state=(await c.get('/teacher/state')).json()
                assert exc.status_code==504 and len(state['calls'])==4
                out.append({'case':'F09-actual-read-timeout-'+model,'code':exc.code.value,'status':exc.status_code,'calls':state['calls'],'details':exc.details})
            finally:
                await service.aclose()
    Path('/tmp/grade-892920/timeout-results.json').write_text(json.dumps(out,indent=2))
    print('READ TIMEOUT: both protocols 504, exactly 4 actual upstream attempts each')
asyncio.run(main())
