import importlib.util
import json
from pathlib import Path
import httpx
spec=importlib.util.spec_from_file_location('student_verify','/tmp/grade-892920/student/scripts/verify.py')
verify=importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)
with httpx.Client(base_url='http://127.0.0.1:18920') as c:
    c.post('/teacher/reset',json={'mode':'invalid'})
    results=[]
    verify.run_check(results,'teacher_forced_wrong_model_content',lambda:verify.check_non_stream(c))
    assert results[0]['ok'] is False
    Path('/tmp/grade-892920/script-forced-failure.json').write_text(json.dumps(results,indent=2))
    print('Student assertion detected wrong model content; no live API used')
