"""Official DeepSeek only. Diagnostic import shim, no source changes."""
import json
import os
import sys
import time
import types
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0,'/tmp/grade-892920/student')
shim=types.ModuleType('pi_ai')
for name in ('stream','Context','UserMessage','Model','StreamOptions'):
    setattr(shim,name,None)
sys.modules['pi_ai']=shim
from app.main import create_app
from app.config import Settings
from fastapi.testclient import TestClient

out=[]
wire=[]
settings=Settings(_env_file=None, deepseek_api_key=os.environ['DEEPSEEK_API_KEY'],
    deepseek_base_url='https://api.deepseek.com',deepseek_responses_base_url='https://api.deepseek.com/v1',
    deepseek_anthropic_base_url='https://api.deepseek.com/anthropic', request_timeout=20,connect_timeout=8,
    llm_max_retries=1,llm_retry_base_delay=.1,llm_retry_jitter=0,
    prompt_seed_dir='/tmp/grade-892920/student/prompts',prompt_store_dir='/tmp/grade-892920/real-prompts',
    observability_log_path='/tmp/grade-892920/real-metrics.jsonl',log_level='WARNING')
async def on_request(req):
    body=json.loads(req.content)
    wire.append({'url':str(req.url),'model':body['model'],'body_keys':sorted(body),
        'stream':body.get('stream',False),'time_utc':datetime.now(timezone.utc).isoformat()})
async def on_response(resp):
    wire[-1].update(status=resp.status_code,upstream_request_id=resp.headers.get('x-request-id') or resp.headers.get('request-id'),
        upstream_model_header=resp.headers.get('x-ds-model'))

app=create_app(settings)
with TestClient(app) as c:
    for adapter in app.state.llm_service._adapters.values():
        adapter._client.event_hooks={'request':[on_request],'response':[on_response]}
    for model in ('deepseek-v4-pro','deepseek-flash'):
        for mode in ('normal','stream','json'):
            payload={'model':model,'messages':[{'role':'user','content':'Return JSON object {"ok":true} only.' if mode=='json' else 'Reply exactly OK.'}],'max_tokens':256}
            if mode=='stream': payload['stream']=True
            if mode=='json': payload['response_format']={'type':'json_object'}
            start=time.monotonic()
            r=c.post('/v1/chat',json=payload)
            body=r.text if mode=='stream' else r.json()
            out.append({'alias':model,'configured_upstream_model':model,'protocol':'openai-responses' if model.endswith('pro') else 'anthropic-messages',
                'mode':mode,'http':r.status_code,'request_id':r.headers.get('x-request-id'),'elapsed_ms':round((time.monotonic()-start)*1000,2),'body':body})
            print(model,mode,r.status_code,'elapsed_ms',out[-1]['elapsed_ms'],flush=True)
            Path('/tmp/grade-892920/real-results.json').write_text(json.dumps({'calls':out,'wire':wire},ensure_ascii=False,indent=2))
            if r.status_code>=500:
                print('Bounded upstream failure: skipping remaining modes for this model',flush=True)
                break
