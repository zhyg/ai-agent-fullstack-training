import sys
import types
sys.path.insert(0,'/tmp/grade-892920/student')
shim=types.ModuleType('pi_ai')
for name in ('stream','Context','UserMessage','Model','StreamOptions'):
    setattr(shim,name,None)
sys.modules['pi_ai']=shim
import pytest
raise SystemExit(pytest.main(['-q','/tmp/grade-892920/student/tests']))
