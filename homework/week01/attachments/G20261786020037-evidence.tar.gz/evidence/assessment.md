# 第一周作业评测附件

- 学员：Geek_892920 / G20261786020037。
- 仓库：`https://gitee.com/huilinkf/ai-agent`，成功执行真实 `git clone`，不是 API 恢复或镜像替代。
- 固定对象：`master@fb9d420b46ced97a3372aa2a2e9e0a9f24ea9422`；克隆后未切换版本、未修改学生业务源码，`git diff --exit-code` 为 0。
- 评测日期：2026-11-07，Asia/Singapore（约 15:37–15:47）；本独立 orb 亲自执行，未创建其他线程。
- 总分：**93/100，暂评分**；作业等级：**优秀**。
- 验收结论：**未通过**（固定提交不能按 README 启动）；另有真实调用证据不完整。诊断绕过后的通过不改变原始交付结论。
- 依据：课程第一周作业、评分标准 v1.1、反馈模板 v1.0；不设封顶、不因环境扣分、不重复处罚同根因。
- 证据包：同目录 `G20261786020037-evidence.tar.gz`。下述路径以压缩包内 `evidence/` 为根；源码行号全部针对上述固定提交。

## A. 八项评分与扣分复现

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 同一 `/v1/chat` 动态路由；实际 HTTP 请求证明 Responses 与 Messages 双协议，A04 未知模型 404。真实成功未验证，保留暂评。 |
| 流式输出 | 15/15 | F01 双模型门控前已收到正文；F02 断流/错误事件明确失败且各只发一次上游请求，无成功 done 事件。 |
| 结构化输出 | 10/10 | F03 两协议映射不同；F04 非法、空、截断及类型错误均返回 502；有本地 JSON/Schema 校验。 |
| 提示词版本管理 | 10/10 | F05 v1/v2 不同渲染确实进入上游请求；F06 缺模板/版本/变量均明确拒绝且无上游请求。 |
| 可观测性 | 13/15 | 正常 Token 分类、累计快照、总延迟、TTFT 和失败状态可核对；已知流式用量在中断时丢失，扣 2 分。 |
| 统一错误与重试 | 15/15 | 503/429 两败一成实际 3 请求；持续 503、真实读超时均最多 4 请求；400/401 各 1 请求。50/100/200ms 有限指数退避，无 SDK 叠加。 |
| 按模型独立限流 | 10/10 | F10–F11 A 成功、A 超限 429、B 成功、等待后 A 恢复，实测 200/429/200/200。 |
| 源码、README 与验证脚本 | 5/10 | 未声明且未使用的 `pi_ai` 导入阻塞干净启动，依赖完整性 0/2、启动可复现 0/3；文档示例 2/2、脚本覆盖及有效断言 3/3。同根因只在本项扣 5 分。 |
| 合计 | **93/100** | 15+15+10+10+13+15+10+5=93；真实上游超时不扣分。 |

### D1：启动阻塞（扣 5 分，仅交付项）

- 触发：全新 venv 安装 `requirements-dev.txt`（包含生产依赖），按 README 执行 uvicorn。
- 预期：无需隐藏依赖即可启动、原始验证脚本可运行。
- 实际：`ModuleNotFoundError: No module named 'pi_ai'`，启动退出 1，原始脚本退出 1（harness 失败），pytest 收集退出 2。
- 固定源码：`app/main.py:24`；`requirements.txt:1-7` 未声明该包；全文检索确认五个导入名仅出现在该导入行。
- 证据/复现：`start.log`、`student-verify.log`、`pytest.log`，命令见 C。其他七项不再因入口阻塞重复扣分。

### D2：流式已知用量丢失（扣 2 分，仅可观测性）

- 触发：Anthropic `message_start` 提供 input=11、cache_read=5、cache_creation=2（归一输入应为 18），随后正文增量，未发送 `message_stop` 即结束。
- 预期：账目保留已知输入 18 及缓存分类；未知后续消耗另作不完整标注，不重试。
- 实际：错误和 TTFT 留存、上游仅 1 请求，但输入/缓存均记为 0；不是“上游未提供”。
- 请求：`req_44832e161c9e43aaa1742cc8c76e81a0`。`controlled-results.json` 的 `F02-interrupt-deepseek-flash`、`controlled-metrics.json` 同请求记录、`checked-evidence.json` 的 `F07-known-usage-lost`。
- 固定源码：`app/adapters/anthropic_messages.py:205-212,287-327` 在适配器内部保存用量，仅 finish 时传出；`app/services/llm_client.py:358,419-421,592-615` 在异常前没有获得该用量。
- 复现：C 的受控命令及 `check_evidence.py`。只扣此根因一次，不再次扣 SSE 或重试。

## B. A01–A04 / F01–F12 验证矩阵

| 用例 | 结果与证据 | 固定源码位置 |
| --- | --- | --- |
| A01 | **失败**：README 安装成功，原始启动被 D1 阻塞；`install.log/start.log`。 | `README.md` 启动节；`app/main.py:24` |
| A02 | **受控通过、真实未验证**：双模型统一入口 HTTP 200；官方两模型各两次正文超时，见 E。 | `app/services/llm_client.py:84-168,196-346` |
| A03 | **受控及真实发出请求结构确认**：`/mock/v1/responses` 使用 input/instructions/max_output_tokens/text.format；`/mock/anthropic/v1/messages` 使用 messages/system/max_tokens/tools/tool_choice/thinking。分别 Bearer 与 x-api-key+anthropic-version，仅归档头名称。不能将发出请求等同完整成功。 | `app/adapters/openai_responses.py:43-123`；`app/adapters/anthropic_messages.py:44-132` |
| A04 | **通过**：未知 model 返回统一 404 `MODEL_NOT_FOUND`，没有上游请求。 | `app/services/llm_client.py:94-108` |
| F01 | **受控通过**：两个真实 TCP SSE 链路先发 start/ping，120ms 后正文，终态被教师门控；客户端确认收到正文且 released=false 才释放终态。TTFT 122.00/123.62ms，不按 start/ping 计；有 done/[DONE]。 | `app/routers/chat.py:59-74`；`app/services/llm_client.py:355-538` |
| F02 | **受控通过**：两协议分别 EOF 断流和 error 事件；都有 error、无成功 done，传输结束 [DONE] 不覆盖错误，各上游请求 1 次。 | `app/services/llm_client.py:437-453,547-615` |
| F03 | **受控通过、真实未验证**：统一 json_schema 请求，Responses text.format、Messages 强制工具（关闭 thinking）；正常正文 JSON/字段匹配。非流式普通请求未通过真实上游后，未追加真实 JSON 请求。 | `app/services/structured.py:17-111`；两适配器 payload |
| F04 | **受控通过**：两协议分别非法文本、空正文、不闭合 JSON+length/incomplete、字段类型错误，均统一 502；无修复逻辑，不存在修复后未经校验放行。 | `app/services/llm_client.py:283-307`；`app/services/structured.py:67-111` |
| F05 | **通过**：创建 v1 `OLD {{word}}`、v2 `NEW {{word}}!`，显式引用得到不同上游 input，旧版本仍保留。 | `app/prompts/registry.py:188-255,257-360` |
| F06 | **通过**：缺模板 404、缺版本 404、缺变量 422，均无上游请求/未替换变量外发。 | `app/prompts/registry.py:188-255` |
| F07 | **部分通过**：Responses 17/9/26，cache=5、reasoning=4；Messages 18/9/27，cache_read=5、creation=2；累计 output=9 快照重复不累加。正常/上游失败/限流可记录查询，断流已知用量 D2 缺陷。 | `app/adapters/anthropic_messages.py:371-405`；`app/services/metrics.py:32-118` |
| F08 | **通过**：每协议上游真实收到 503、503、200 三次；记录退避 50/100ms，实测间隔 Responses 52.4/102.9ms，Messages 52.3/103.2ms。 | `app/services/llm_client.py:202-255,726-735` |
| F09 | **通过**：持续 503 实际 4 次、退避 50/100/200ms；持续实际 HTTP 读超时每协议 4 次后 504；400/401 各一次，429 两败一成三次。使用原生 httpx，无模型 SDK 内置重试叠加，实际收件计数已覆盖。 | `app/adapters/base.py:136-149,175-269`；`app/services/llm_client.py:202-255` |
| F10 | **通过**：容量 1、补充 2/s；flash 200、flash 429、pro 200；本地超限不请求上游。 | `app/core/rate_limit.py:146-189` |
| F11 | **通过**：等待 0.6s 后 flash 200；真实时钟补充，未改业务逻辑。 | `app/core/rate_limit.py` TokenBucket 及 153-167 |
| F12 | **原始失败 / 隔离受控通过**：原始脚本启动失败；仅教师导入绕过+模拟上游后原脚本 10/10、离线测试 18/18；将模型正文强制改成 `not json`，原 check_non_stream 明确输出 FAIL。 | `scripts/verify.py:207-257,290-777,779-919` |

证据定位：上述受控场景分别以用例前缀保存在 `controlled-results.json`（37 条），账目在 `controlled-metrics.json`；真实超时补测在 `timeout-results.json`（2 条），交叉断言在 `checked-evidence.json`。全部均明确为模拟，不能当成真实模型成功。

## C. 命令与独立配置

原始执行，目录 `/tmp/grade-892920/student`：

```bash
git clone https://gitee.com/huilinkf/ai-agent /tmp/grade-892920/student
git rev-parse HEAD
python -m venv /tmp/grade-892920/venv
/tmp/grade-892920/venv/bin/pip install -r requirements-dev.txt
/tmp/grade-892920/venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 18920
/tmp/grade-892920/venv/bin/python scripts/verify.py
/tmp/grade-892920/venv/bin/python -m pytest -q
```

教师诊断（脚本在包内；从 evidence 复制到 `/tmp/grade-892920`，源码快照放到 student；重新按上述命令创建 venv）：

```bash
amp orb service start grade892920 --command 'cd /tmp/grade-892920 && /tmp/grade-892920/venv/bin/python -m uvicorn teacher_app:app --host 127.0.0.1 --port 18920 --log-level warning' --port 18920
# 等待 GET /health 为 200，再执行：
/tmp/grade-892920/venv/bin/python /tmp/grade-892920/controlled.py
/tmp/grade-892920/venv/bin/python /tmp/grade-892920/check_evidence.py
/tmp/grade-892920/venv/bin/python /tmp/grade-892920/timeout_case.py
/tmp/grade-892920/venv/bin/python /tmp/grade-892920/shim_tests.py
```

- `teacher_app.py` 只在教师进程的 `sys.modules` 为未使用的五个导入名提供空占位，不实现 pi_ai、不改变学生函数；因此所有补测属于诊断结果，而非证明干净交付可启动。
- Mock Key 是字面量 `teacher-dummy-not-secret`；mock 端点仅在本 orb 回环，记录实际路径、body、头名称和收件时间，不记录任何真实鉴权值。
- 门控 120ms 内容延迟；重试配置基数 .05s、jitter=0、max_retries=3；限流配置容量 1、补充 2/s。读超时补测 request_timeout=.05s、base=.01s，仅教师配置可变项。
- 学生脚本隔离运行：先 `POST /teacher/reset {"mode":"student_script"}`，再执行下列命令；记录 `student-verify-controlled.log`、`student-generated/verification-20261107-074303-6d5e99.json`。其自启子进程由原脚本 finally 停止，无遗留常驻服务。

```bash
PYTHONPATH=/tmp/grade-892920 DEEPSEEK_API_KEY=teacher-dummy-not-secret DEEPSEEK_RESPONSES_BASE_URL=http://127.0.0.1:18920/mock/v1 DEEPSEEK_ANTHROPIC_BASE_URL=http://127.0.0.1:18920/mock/anthropic /tmp/grade-892920/venv/bin/python /tmp/grade-892920/student/scripts/verify.py
PYTHONPATH=/tmp/grade-892920/student /tmp/grade-892920/venv/bin/python /tmp/grade-892920/script_failure.py
# 真实调用只从已有环境读取 Key，不把值写入命令、配置或归档：
/tmp/grade-892920/venv/bin/python /tmp/grade-892920/real_calls.py
amp orb service stop grade892920
```

## D. 源码固定与证据边界

- `source-commit.txt`、`source-blobs.txt` 固定提交和 Git blob；包内 `source/` 取自该提交的 `git archive`，不含 `.git`、密钥文件和学生历史证据。
- 第一周定位依据：仓库根 README 明确“LLM 统一模型调用服务”，六项功能与本周题目对应；未把其他周作业当成本次对象。
- 原始失败留存，不将 shim 误称安装成功；诊断是为了隔离 D1 并评价已有业务实现，不改源码替学生修复。
- 未对非标准 NaN、分布式限流、JSON 修复、所有扩展组合等额外设门槛。普通截断不扣分；本次结构化截断用不闭合 JSON 判失败。
- 未知模型账本查询 404 的补测留存，但中间件已有 request_id/status/elapsed 日志，不再把“未进入账本”单独扣分；未知用量按学生文档的 0=未提供解释。D2 只处罚**已提供**用量丢失。

## E. 真实 DeepSeek 调用元数据与限制

独立 Settings 直接指向官方域名，未经第三方网关，未替换上游模型：公开 `deepseek-v4-pro` → 同名上游、Responses；公开 `deepseek-flash` → 同名上游、Anthropic Messages。与学生默认的区别仅为绝对目录隔离、request_timeout=20s/connect=8s、最多重试 1 次、基数 .1s、jitter=0，以及教师导入 shim；不把短超时导致的未完成当作学生缺陷。

| 公开模型 / 协议 | 官方请求 URL | 实际尝试 | 网关结果 | 关联请求 / 总耗时 |
| --- | --- | ---: | --- | --- |
| deepseek-v4-pro / Responses | `https://api.deepseek.com/v1/responses` | 2 | 504 UPSTREAM_TIMEOUT | `req_b9655a0aa3314b769d8006446baba269` / 46844.36ms |
| deepseek-flash / Messages | `https://api.deepseek.com/anthropic/v1/messages` | 2 | 504 UPSTREAM_TIMEOUT | `req_ff4caebd2f0d4de386f1ad862a931b9c` / 40861.94ms |

- 调用窗口 UTC 07:40:49–07:42:16（新加坡 15:40:49–15:42:16）；每次响应头曾为 200，但正文读取超时，**不视为成功调用**。
- 上游 request-id/model 响应头均未提供，完整正文 response id、真实 usage、TTFT 均未知；`real-metrics.jsonl` 的 0 按项目约定为未提供，不是零消耗证明。
- `real-results.json` 含每次官方发件时刻、路径、模型、请求字段集合、响应头状态、统一错误和耗时；`real.log/real-metrics.jsonl` 可关联复核。没有记录鉴权值。
- 每模型两次超时后停止，未继续真实 stream/JSON，也未为打分消耗真实额度触发限流；这些真实能力均未验证。受控结果不能弥补真实成功证据。
- 官方文档 `https://api-docs.deepseek.com/api/create_response` 本次返回入门页，列出两个模型及 Anthropic 基址；本文不据此宣称 Responses 已真实调用成功，也未做独立别名重映射。

## F. 补交、检查与收尾

- 必须修复 D1，在干净环境启动、原始脚本/测试无需 shim；必须修复 D2，复测“收到 usage 后断流”，已知用量与失败状态保留。
- 上游恢复后补交两模型普通、流式、结构化成功证据，包含公开别名、实际模型、协议、请求标识、usage 和 latency；当前不因环境暂不可用扣分。
- 简明反馈三节各 3–4 条、各≤500字；分数及等级与此表一致；没有将受控或跳过写成真实通过。
- 归档前逐文件及解包内容核查真实环境 Key 不出现、常见密钥模式不出现；真实 Key 不打印、不保存、不归档。仅保留 dummy 字面量和环境变量名称。
- 学生源码 diff 为零；教师服务及学生脚本子进程已停止；不提交、不推送。执行验证结果见包内 `final-checks.json`、`service-stop.log`、`source-clean.log`。
