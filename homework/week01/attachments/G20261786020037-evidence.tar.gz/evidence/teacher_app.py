"""Diagnostic only: unused pi_ai import shim; student source untouched."""
import asyncio
import json
import sys
import time
import types
sys.path.insert(0, '/tmp/grade-892920/student')
shim = types.ModuleType('pi_ai')
for name in ('stream', 'Context', 'UserMessage', 'Model', 'StreamOptions'):
    setattr(shim, name, None)
sys.modules['pi_ai'] = shim
from app.main import create_app
from app.config import Settings
from fastapi import Request
from fastapi.responses import JSONResponse, StreamingResponse

app = create_app(Settings(_env_file=None, deepseek_api_key='teacher-dummy-not-secret',
    deepseek_responses_base_url='http://127.0.0.1:18920/mock/v1',
    deepseek_anthropic_base_url='http://127.0.0.1:18920/mock/anthropic',
    prompt_seed_dir='/tmp/grade-892920/student/prompts',
    prompt_store_dir='/tmp/grade-892920/prompts',
    observability_log_path='/tmp/grade-892920/metrics.jsonl',
    llm_retry_base_delay=.05, llm_retry_jitter=0, log_level='WARNING',
    rate_limit_default_capacity=10000, rate_limit_default_refill_per_second=10000))
state = {'mode': 'normal', 'calls': [], 'released': False, 'failures': 0}

@app.post('/teacher/reset')
async def reset(request: Request):
    data = await request.json()
    state.update(mode=data.get('mode', 'normal'), calls=[], released=False, failures=data.get('failures',0))
    if data.get('limits'):
        from app.core.rate_limit import ModelRateLimiter
        app.state.llm_service._limiter = ModelRateLimiter.from_settings(Settings(_env_file=None,
            rate_limit_default_capacity=1, rate_limit_default_refill_per_second=2))
    return {'ok': True}

@app.get('/teacher/state')
async def get_state():
    return state

@app.post('/teacher/release')
async def release():
    state['released'] = True
    return {'ok': True}

@app.post('/mock/v1/responses')
@app.post('/mock/anthropic/v1/messages')
async def upstream(request: Request):
    body = await request.json()
    anth = 'messages' in request.url.path
    state['calls'].append({'path':request.url.path, 'body':body, 'time':time.monotonic(),
        'auth_header_names':[x for x in ('authorization','x-api-key','anthropic-version') if x in request.headers]})
    mode = state['mode']
    if mode in ('retry','error400','error401','error429','timeout') and (len(state['calls'])<=state['failures'] or state['failures']==99):
        if mode=='timeout':
            await asyncio.sleep(.2)
        status = {'error400':400,'error401':401,'error429':429}.get(mode,503)
        return JSONResponse({'error':{'message':'controlled upstream fault'}},status_code=status)
    text = {'invalid':'not json', 'empty':'', 'truncated':'{"answer":', 'schema_bad':'{"answer":3}'}.get(mode, '{"answer":"OK"}' if 'text' in body or 'tools' in body else 'OK')
    if mode == 'student_script':
        import re
        prompt = json.dumps(body.get('input', body.get('messages', [])),ensure_ascii=False)
        match = re.search(r'(?:exactly: |exactly the word )([A-Z_]+)',prompt)
        text = match.group(1) if match else 'OK'
        if 'tools' in body or 'text' in body:
            text = '{"sentiment":"positive","confidence":0.9}'
    ru = {'input_tokens':17,'output_tokens':9,'total_tokens':26,
        'input_tokens_details':{'cached_tokens':5},'output_tokens_details':{'reasoning_tokens':4}}
    au = {'input_tokens':11,'cache_read_input_tokens':5,'cache_creation_input_tokens':2,'output_tokens':9}
    if not body.get('stream'):
        if anth:
            return {'id':'teacher-msg','type':'message','content':[{'type':'text','text':text}], 'stop_reason':'max_tokens' if mode=='truncated' else 'end_turn','usage':au}
        return {'id':'teacher-resp','status':'incomplete' if mode=='truncated' else 'completed',
            'incomplete_details':{'reason':'max_output_tokens'},'output':[{'type':'message','content':[{'type':'output_text','text':text}]}],'usage':ru}
    async def generate():
        def event(data):
            return 'data: '+json.dumps(data)+'\n\n'
        if anth:
            yield event({'type':'message_start','message':{'id':'teacher-msg','usage':au}})
            yield event({'type':'ping'})
        else:
            yield event({'type':'response.created','response':{'id':'teacher-resp'}})
        await asyncio.sleep(.12)
        if anth:
            yield event({'type':'content_block_delta','index':0,'delta':{'type':'text_delta','text':'门控OK'}})
        else:
            yield event({'type':'response.output_text.delta','delta':'门控OK'})
        if mode=='interrupt':
            return
        if mode=='event_error':
            yield event({'type':'error','error':{'message':'controlled stream error'}})
            return
        if mode=='gate':
            for _ in range(500):
                if state['released']:
                    break
                await asyncio.sleep(.01)
        if anth:
            yield event({'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':9}})
            yield event({'type':'message_delta','delta':{},'usage':{'output_tokens':9}})
            yield event({'type':'message_stop'})
        else:
            yield event({'type':'response.completed','response':{'status':'completed','usage':ru}})
    return StreamingResponse(generate(),media_type='text/event-stream')
