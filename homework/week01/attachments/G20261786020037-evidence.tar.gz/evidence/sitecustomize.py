"""Diagnostic-only shim for the single unused import; not a pi_ai implementation."""
import sys
import types
shim=types.ModuleType('pi_ai')
for name in ('stream','Context','UserMessage','Model','StreamOptions'):
    setattr(shim,name,None)
sys.modules['pi_ai']=shim
