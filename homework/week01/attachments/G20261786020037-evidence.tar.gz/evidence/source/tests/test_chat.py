"""HTTP-level tests that never call an upstream model."""
from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import create_app


def make_client(settings):
    return TestClient(create_app(settings))


def test_discovery_health_and_models(test_settings):
    with make_client(test_settings) as client:
        health = client.get("/health")
        assert health.status_code == 200
        assert health.json()["api_key_configured"] is True
        assert health.json()["models_available"] == 2

        models = client.get("/v1/models")
        assert models.status_code == 200
        payload = models.json()
        assert payload["total"] == 2
        assert payload["default"] == "deepseek-v4-pro"
        assert {model["protocol"] for model in payload["models"]} == {
            "openai-responses",
            "anthropic-messages",
        }

        assert client.get("/v1/models/deepseek-flash").status_code == 200
        assert client.get("/v1/models/nope").status_code == 404

        limits = client.get("/v1/rate-limits")
        assert limits.status_code == 200
        assert {row["model"] for row in limits.json()["limits"]} == {
            "deepseek-v4-pro",
            "deepseek-flash",
        }

        summary = client.get("/v1/metrics/summary")
        assert summary.status_code == 200
        assert summary.json()["total_calls"] == 0


def test_unified_validation_errors(test_settings):
    with make_client(test_settings) as client:
        unknown = client.post(
            "/v1/chat",
            json={
                "model": "missing",
                "messages": [{"role": "user", "content": "hi"}],
            },
        )
        assert unknown.status_code == 404
        assert unknown.json()["error"]["code"] == "MODEL_NOT_FOUND"

        invalid = client.post("/v1/chat", json={"model": "deepseek-v4-pro"})
        assert invalid.status_code == 422
        assert invalid.json()["error"]["code"] == "VALIDATION_ERROR"

        bad_format = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "hi"}],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"name": "x"},
                },
            },
        )
        assert bad_format.status_code == 400
        assert bad_format.json()["error"]["code"] == "INVALID_RESPONSE_FORMAT"

        missing_prompt = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-flash",
                "prompt": {"name": "does-not-exist", "variables": {}},
            },
        )
        assert missing_prompt.status_code == 404
        assert missing_prompt.json()["error"]["code"] == "PROMPT_NOT_FOUND"

        assert client.get("/v1/metrics/calls/req_missing").status_code == 404

        # Request IDs are propagated even on errors.
        assert unknown.headers.get("X-Request-Id")
        assert unknown.json()["error"]["request_id"] == unknown.headers[
            "X-Request-Id"
        ]


def test_prompt_management_api(test_settings):
    with make_client(test_settings) as client:
        seed = client.get("/v1/prompts/sentiment?version=2")
        assert seed.status_code == 200
        assert seed.json()["version"] == 2

        latest = client.get("/v1/prompts/sentiment?version=latest")
        assert latest.status_code == 200
        assert latest.json()["version"] == 2
        assert client.get("/v1/prompts/sentiment?version=0").status_code == 422

        created = client.post(
            "/v1/prompts",
            json={
                "name": "api_demo",
                "template": "Hello {{name}}",
                "description": "api test",
            },
        )
        assert created.status_code == 201

        second = client.post(
            "/v1/prompts/api_demo/versions",
            json={"template": "Hello {{name}}!"},
        )
        assert second.status_code == 201
        assert second.json()["version"] == 2

        rendered = client.post(
            "/v1/prompts/api_demo/render",
            json={"version": 1, "variables": {"name": "Ada"}},
        )
        assert rendered.status_code == 200
        assert rendered.json()["rendered"] == "Hello Ada"

        missing = client.post(
            "/v1/prompts/api_demo/render",
            json={"version": 2, "variables": {}},
        )
        assert missing.status_code == 422
        assert missing.json()["error"]["code"] == "TEMPLATE_VARIABLE_MISSING"

        versions = client.get("/v1/prompts/api_demo/versions")
        assert versions.status_code == 200
        assert [row["version"] for row in versions.json()["versions"]] == [1, 2]

        conflict = client.post(
            "/v1/prompts",
            json={"name": "api_demo", "template": "again"},
        )
        assert conflict.status_code == 409
        assert conflict.json()["error"]["code"] == "PROMPT_CONFLICT"
