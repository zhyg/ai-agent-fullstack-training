"""Adapter wire-format tests using httpx.MockTransport."""
from __future__ import annotations

import json

import httpx

from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.base import (
    AdapterMessage,
    AdapterRequest,
    StructuredFormat,
)
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.config import Settings
from app.core.model_catalog import resolve_model

PRO = resolve_model("deepseek-v4-pro")
FLASH = resolve_model("deepseek-flash")
SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}


def text_request() -> AdapterRequest:
    return AdapterRequest(
        messages=[
            AdapterMessage("system", "be terse"),
            AdapterMessage("user", "say OK"),
        ],
        temperature=0.2,
        max_tokens=128,
    )


def structured_request() -> AdapterRequest:
    return AdapterRequest(
        messages=[AdapterMessage("user", "return JSON")],
        temperature=0.2,
        max_tokens=128,
        response_format=StructuredFormat(
            kind="json_schema",
            name="answer",
            schema=SCHEMA,
            strict=True,
        ),
    )


async def test_responses_adapter_non_stream():
    seen: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["path"] = request.url.path
        seen["auth"] = request.headers.get("authorization")
        seen["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "id": "resp_1",
                "status": "completed",
                "output": [
                    {
                        "type": "reasoning",
                        "content": [
                            {"type": "reasoning_text", "text": "thinking"}
                        ],
                    },
                    {
                        "type": "message",
                        "content": [
                            {"type": "output_text", "text": "OK"}
                        ],
                    },
                ],
                "usage": {
                    "input_tokens": 12,
                    "output_tokens": 5,
                    "total_tokens": 17,
                    "input_tokens_details": {"cached_tokens": 2},
                    "output_tokens_details": {"reasoning_tokens": 3},
                },
            },
        )

    transport = httpx.MockTransport(handler)
    async with httpx.AsyncClient(transport=transport) as client:
        adapter = OpenAIResponsesAdapter(
            PRO,
            Settings(deepseek_api_key="test-key"),
            client=client,
        )
        result = await adapter.complete(text_request())

    assert seen["path"] == "/v1/responses"
    assert seen["auth"] == "Bearer test-key"
    assert seen["payload"]["instructions"] == "be terse"
    assert seen["payload"]["input"] == [{"role": "user", "content": "say OK"}]
    assert result.content == "OK"
    assert result.reasoning == "thinking"
    assert result.usage.input_tokens == 12
    assert result.usage.reasoning_tokens == 3
    assert result.usage.cached_input_tokens == 2
    assert result.usage.total_tokens == 17
    assert result.finish_reason == "stop"


async def test_responses_adapter_stream():
    body = "\n\n".join(
        [
            'event: response.created\ndata: {"type":"response.created","response":{"id":"resp_s"}}',
            'event: response.reasoning_text.delta\ndata: {"type":"response.reasoning_text.delta","delta":"think"}',
            'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"O"}',
            'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"K"}',
            'event: response.completed\ndata: {"type":"response.completed","response":{"id":"resp_s","status":"completed","usage":{"input_tokens":7,"output_tokens":4,"total_tokens":11,"output_tokens_details":{"reasoning_tokens":1}}}}',
        ]
    )

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=body.encode(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    async with httpx.AsyncClient(transport=transport) as client:
        adapter = OpenAIResponsesAdapter(
            PRO,
            Settings(deepseek_api_key="test-key"),
            client=client,
        )
        events = [
            event async for event in adapter.stream(text_request())
        ]

    types = [event.type for event in events]
    assert types[0] == "start"
    assert "reasoning_delta" in types
    assert types.count("text_delta") == 2
    finish = events[-1]
    assert finish.type == "finish"
    assert finish.data["finish_reason"] == "stop"
    assert finish.data["usage"].output_tokens == 4
    assert finish.data["usage"].reasoning_tokens == 1


async def test_anthropic_adapter_structured_uses_forced_tool():
    seen: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["path"] = request.url.path
        seen["api_key"] = request.headers.get("x-api-key")
        seen["version"] = request.headers.get("anthropic-version")
        seen["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "id": "msg_1",
                "type": "message",
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "id": "tool_1",
                        "name": "structured_output",
                        "input": {"answer": "HI"},
                    }
                ],
                "stop_reason": "tool_use",
                "usage": {
                    "input_tokens": 10,
                    "output_tokens": 6,
                    "cache_read_input_tokens": 4,
                    "cache_creation_input_tokens": 1,
                },
            },
        )

    transport = httpx.MockTransport(handler)
    async with httpx.AsyncClient(transport=transport) as client:
        adapter = AnthropicMessagesAdapter(
            FLASH,
            Settings(deepseek_api_key="test-key"),
            client=client,
        )
        result = await adapter.complete(structured_request())

    payload = seen["payload"]
    assert seen["path"] == "/anthropic/v1/messages"
    assert seen["api_key"] == "test-key"
    assert seen["version"] == "2023-06-01"
    assert payload["tools"][0]["name"] == "structured_output"
    assert payload["tool_choice"] == {
        "type": "tool",
        "name": "structured_output",
    }
    assert payload["thinking"] == {"type": "disabled"}
    assert json.loads(result.content) == {"answer": "HI"}
    assert result.finish_reason == "tool_use"
    assert result.usage.input_tokens == 15
    assert result.usage.output_tokens == 6
    assert result.usage.cached_input_tokens == 4
    assert result.usage.cache_creation_input_tokens == 1


async def test_anthropic_adapter_stream():
    body = "\n\n".join(
        [
            'event: message_start\ndata: {"type":"message_start","message":{"id":"msg_s","usage":{"input_tokens":8,"cache_read_input_tokens":2,"cache_creation_input_tokens":0,"output_tokens":0}}}',
            'event: content_block_start\ndata: {"type":"content_block_start","index":0,"content_block":{"type":"thinking","thinking":""}}',
            'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"thinking_delta","thinking":"plan"}}',
            'event: content_block_stop\ndata: {"type":"content_block_stop","index":0}',
            'event: content_block_start\ndata: {"type":"content_block_start","index":1,"content_block":{"type":"text","text":""}}',
            'event: content_block_delta\ndata: {"type":"content_block_delta","index":1,"delta":{"type":"text_delta","text":"OK"}}',
            'event: content_block_stop\ndata: {"type":"content_block_stop","index":1}',
            'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":3}}',
            'event: message_stop\ndata: {"type":"message_stop"}',
        ]
    )

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=body.encode(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    async with httpx.AsyncClient(transport=transport) as client:
        adapter = AnthropicMessagesAdapter(
            FLASH,
            Settings(deepseek_api_key="test-key"),
            client=client,
        )
        events = [
            event async for event in adapter.stream(text_request())
        ]

    types = [event.type for event in events]
    assert types[0] == "start"
    assert "reasoning_delta" in types
    assert "text_delta" in types
    finish = events[-1]
    assert finish.type == "finish"
    assert finish.data["finish_reason"] == "stop"
    assert finish.data["usage"].input_tokens == 10
    assert finish.data["usage"].output_tokens == 3
    assert finish.data["usage"].cached_input_tokens == 2
