"""Test doubles for adapters and a small service factory."""
from __future__ import annotations

from typing import Any

from app.adapters.base import (
    AdapterRequest,
    AdapterResponse,
    StreamEvent,
    Usage,
)
from app.config import Settings
from app.prompts.registry import PromptRegistry
from app.services.llm_client import LLMService
from app.services.metrics import MetricsStore


class FakeAdapter:
    def __init__(
        self,
        *,
        complete_outcomes: list[Any] | None = None,
        stream_outcomes: list[Any] | None = None,
    ) -> None:
        self.complete_outcomes = list(complete_outcomes or [])
        self.stream_outcomes = list(stream_outcomes or [])
        self.complete_calls = 0
        self.stream_calls = 0
        self.last_request: AdapterRequest | None = None

    async def complete(self, request: AdapterRequest) -> AdapterResponse:
        self.complete_calls += 1
        self.last_request = request
        outcome = self.complete_outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    async def stream(self, request: AdapterRequest):
        self.stream_calls += 1
        self.last_request = request
        outcome = self.stream_outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        for event in outcome:
            yield event

    async def aclose(self) -> None:
        return None


def response(
    content: str = "OK",
    *,
    input_tokens: int = 10,
    output_tokens: int = 5,
    reasoning_tokens: int = 0,
    finish_reason: str = "stop",
) -> AdapterResponse:
    return AdapterResponse(
        id="fake-response-id",
        content=content,
        finish_reason=finish_reason,
        upstream_finish_reason=finish_reason,
        usage=Usage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            reasoning_tokens=reasoning_tokens,
        ).finalize(),
    )


def finish_event(
    *,
    input_tokens: int = 10,
    output_tokens: int = 5,
    finish_reason: str = "stop",
) -> StreamEvent:
    return StreamEvent(
        "finish",
        {
            "id": "fake-stream-id",
            "finish_reason": finish_reason,
            "upstream_finish_reason": finish_reason,
            "usage": Usage(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=input_tokens + output_tokens,
            ).finalize(),
        },
    )


def make_service(
    settings: Settings,
    prompts: PromptRegistry,
    metrics: MetricsStore,
    adapters: dict[str, FakeAdapter],
    sleeps: list[float] | None = None,
) -> LLMService:
    sleeps = sleeps if sleeps is not None else []

    async def fake_sleep(delay: float) -> None:
        sleeps.append(delay)

    return LLMService(
        settings,
        prompts,
        metrics,
        adapters=adapters,  # type: ignore[arg-type]
        sleep=fake_sleep,
    )
