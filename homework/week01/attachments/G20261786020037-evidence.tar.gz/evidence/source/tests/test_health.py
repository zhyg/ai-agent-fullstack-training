"""Prompt registry, token bucket and structured-output validation."""
from __future__ import annotations

import pytest

from app.adapters.base import StructuredFormat
from app.core.errors import ErrorCode, ServiceError
from app.core.rate_limit import ModelRateLimiter, RateLimitConfig
from app.models.schemas import ResponseFormat
from app.services.structured import normalize_response_format, parse_and_validate

SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}


def test_seed_templates_are_versioned(prompt_registry):
    assert prompt_registry.get("sentiment", "latest").version == 2
    assert prompt_registry.get("sentiment", 1).version == 1
    assert len(prompt_registry.list_versions("sentiment")) == 2
    assert prompt_registry.list_prompts()


def test_prompt_render_and_missing_variable(prompt_registry):
    rendered = prompt_registry.render(
        "sentiment",
        1,
        {"text": "I love it"},
    )
    assert "I love it" in rendered.text
    assert rendered.prompt.version == 1
    assert rendered.reference()["sha256"] == rendered.prompt.sha256

    with pytest.raises(ServiceError) as exc_info:
        prompt_registry.render("sentiment", 1, {})
    assert exc_info.value.code == ErrorCode.TEMPLATE_VARIABLE_MISSING
    assert exc_info.value.details["missing"] == ["text"]


def test_prompt_create_add_version_and_conflict(prompt_registry):
    created = prompt_registry.create(
        "unit_demo",
        "Say {{word}}",
        "unit test",
    )
    assert created.version == 1

    second = prompt_registry.add_version(
        "unit_demo",
        "Say {{word}}!",
        "unit test v2",
    )
    assert second.version == 2
    assert second.sha256 != created.sha256
    assert prompt_registry.render(
        "unit_demo",
        2,
        {"word": "hi"},
    ).text == "Say hi!"

    with pytest.raises(ServiceError) as exc_info:
        prompt_registry.create("unit_demo", "another")
    assert exc_info.value.code == ErrorCode.PROMPT_CONFLICT


def test_token_buckets_are_independent_per_model():
    now = [100.0]
    limiter = ModelRateLimiter(
        RateLimitConfig(capacity=2, refill_per_second=1.0),
        {"flash": RateLimitConfig(capacity=1, refill_per_second=1.0)},
        clock=lambda: now[0],
    )

    assert limiter.acquire("pro").allowed is True
    assert limiter.acquire("pro").allowed is True
    denied = limiter.acquire("pro")
    assert denied.allowed is False
    assert denied.retry_after == pytest.approx(1.0)
    # The flash bucket is untouched.
    assert limiter.acquire("flash").allowed is True
    assert limiter.acquire("flash").allowed is False
    # One second later both buckets refill by one token.
    now[0] += 1.0
    assert limiter.acquire("pro").allowed is True
    assert limiter.acquire("flash").allowed is True


def test_rate_limit_enforce_raises_429_with_headers():
    limiter = ModelRateLimiter(
        RateLimitConfig(capacity=1, refill_per_second=0.01),
        clock=lambda: 5.0,
    )
    limiter.acquire("deepseek-flash")
    with pytest.raises(ServiceError) as exc_info:
        limiter.enforce("deepseek-flash")
    error = exc_info.value
    assert error.status_code == 429
    assert error.code == ErrorCode.RATE_LIMITED
    assert error.headers["Retry-After"] == "100"


def test_structured_output_normalization_and_validation():
    fmt = normalize_response_format(
        ResponseFormat(
            type="json_schema",
            json_schema={"name": "answer", "strict": True, "schema": SCHEMA},
        )
    )
    assert isinstance(fmt, StructuredFormat)
    assert parse_and_validate('{"answer": "hi"}', fmt) == {"answer": "hi"}

    with pytest.raises(ServiceError) as invalid_json:
        parse_and_validate("not-json", fmt)
    assert invalid_json.value.code == ErrorCode.STRUCTURED_OUTPUT_INVALID

    with pytest.raises(ServiceError) as invalid_schema:
        parse_and_validate('{"answer": 1}', fmt)
    assert invalid_schema.value.code == ErrorCode.STRUCTURED_OUTPUT_INVALID

    with pytest.raises(ServiceError) as bad_format:
        normalize_response_format(
            ResponseFormat(type="json_schema", json_schema={"name": "x"})
        )
    assert bad_format.value.code == ErrorCode.INVALID_RESPONSE_FORMAT


def test_json_object_mode_requires_object():
    fmt = normalize_response_format(ResponseFormat(type="json_object"))
    assert parse_and_validate('{"a": 1}', fmt) == {"a": 1}
    with pytest.raises(ServiceError):
        parse_and_validate("[1, 2]", fmt)
