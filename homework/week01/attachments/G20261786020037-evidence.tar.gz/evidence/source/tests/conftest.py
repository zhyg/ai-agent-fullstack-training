# tests/conftest.py
"""Shared pytest fixtures."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest

from app.config import Settings
from app.prompts.registry import PromptRegistry
from app.services.metrics import MetricsStore


@pytest.fixture
def test_settings(tmp_path: Path) -> Settings:
    return Settings(
        environment="test",
        deepseek_api_key="test-key",
        prompt_seed_dir=str(ROOT / "prompts"),
        prompt_store_dir=str(tmp_path / "prompt-store"),
        observability_log_path="",
        llm_retry_base_delay=0.0,
        llm_retry_max_delay=0.05,
        llm_retry_jitter=0.0,
        rate_limit_default_capacity=100,
        rate_limit_default_refill_per_second=100.0,
        enable_debug_faults=True,
    )


@pytest.fixture
def prompt_registry(test_settings: Settings) -> PromptRegistry:
    return PromptRegistry(
        test_settings.prompt_seed_dir,
        test_settings.prompt_store_dir,
    )


@pytest.fixture
def metrics_store() -> MetricsStore:
    return MetricsStore()
