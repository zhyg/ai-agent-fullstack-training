"""Unified service: retry policy, streaming orchestration and metrics."""
from __future__ import annotations

import pytest

from app.adapters.base import StreamEvent
from app.core.errors import ErrorCode, ServiceError, UpstreamError
from app.models.schemas import ChatRequest
from tests.helpers import FakeAdapter, finish_event, make_service, response


def chat_request(*, stream: bool = False) -> ChatRequest:
    return ChatRequest(
        model="deepseek-v4-pro",
        messages=[{"role": "user", "content": "hello"}],
        max_tokens=64,
        stream=stream,
    )


def upstream_error(
    status: int = 503,
    *,
    retryable: bool = True,
    code: ErrorCode = ErrorCode.UPSTREAM_UNAVAILABLE,
    client_status: int = 502,
) -> UpstreamError:
    return UpstreamError(
        code,
        f"upstream {status}",
        status_code=client_status,
        retryable=retryable,
        upstream_status=status,
    )


async def test_complete_retries_then_succeeds(
    metrics_store,
    prompt_registry,
    test_settings,
):
    adapter = FakeAdapter(
        complete_outcomes=[
            upstream_error(503),
            upstream_error(503),
            response("RETRY_OK", input_tokens=20, output_tokens=7),
        ]
    )
    sleeps: list[float] = []
    service = make_service(
        test_settings,
        prompt_registry,
        metrics_store,
        {"deepseek-v4-pro": adapter},
        sleeps,
    )

    prepared = await service.prepare(chat_request())
    result = await service.complete(prepared)

    assert result["retry_count"] == 2
    assert [attempt["outcome"] for attempt in result["attempts"]] == [
        "error",
        "error",
        "success",
    ]
    assert result["attempts"][0]["upstream_status"] == 503
    assert result["choices"][0]["message"]["content"] == "RETRY_OK"
    assert sleeps == [0.0, 0.0]
    assert adapter.complete_calls == 3

    summary = metrics_store.summary()
    assert summary["total_calls"] == 1
    assert summary["total_retries"] == 2
    assert summary["usage"]["output_tokens"] == 7


async def test_complete_does_not_retry_client_errors(
    metrics_store,
    prompt_registry,
    test_settings,
):
    adapter = FakeAdapter(
        complete_outcomes=[
            upstream_error(
                400,
                retryable=False,
                code=ErrorCode.UPSTREAM_BAD_REQUEST,
                client_status=400,
            )
        ]
    )
    sleeps: list[float] = []
    service = make_service(
        test_settings,
        prompt_registry,
        metrics_store,
        {"deepseek-v4-pro": adapter},
        sleeps,
    )
    prepared = await service.prepare(chat_request())

    with pytest.raises(ServiceError) as exc_info:
        await service.complete(prepared)

    assert exc_info.value.code == ErrorCode.UPSTREAM_BAD_REQUEST
    assert adapter.complete_calls == 1
    assert sleeps == []
    assert metrics_store.summary()["error"] == 1


async def test_stream_emits_sse_events_and_metrics(
    metrics_store,
    prompt_registry,
    test_settings,
):
    adapter = FakeAdapter(
        stream_outcomes=[
            [
                StreamEvent("start", {"id": "stream-id"}),
                StreamEvent("text_delta", {"delta": "hel"}),
                StreamEvent("text_delta", {"delta": "lo"}),
                finish_event(input_tokens=9, output_tokens=2),
            ]
        ]
    )
    service = make_service(
        test_settings,
        prompt_registry,
        metrics_store,
        {"deepseek-v4-pro": adapter},
    )
    prepared = await service.prepare(chat_request(stream=True))

    events = [event async for event in service.stream(prepared)]
    names = [event.event for event in events]

    assert names[0] == "start"
    assert names.count("delta") == 2
    assert "usage" in names
    assert names[-1] == "done"
    assert (
        "".join(
            event.data["delta"]
            for event in events
            if event.event == "delta"
        )
        == "hello"
    )
    done = events[-1].data
    assert done["usage"]["output_tokens"] == 2
    assert done["retry_count"] == 0
    assert done["latency"]["ttft_ms"] is not None

    summary = metrics_store.summary()
    assert summary["total_calls"] == 1
    assert summary["stream_calls"] == 1
    assert summary["by_model"]["deepseek-v4-pro"]["success"] == 1
    record = metrics_store.recent(limit=1)[0]
    assert record["latency"]["ttft_ms"] is not None
    assert record["latency"]["first_text_ms"] is not None
    assert record["latency"]["first_text_ms"] >= record["latency"]["ttft_ms"]


async def test_stream_retries_before_start(
    metrics_store,
    prompt_registry,
    test_settings,
):
    adapter = FakeAdapter(
        stream_outcomes=[
            upstream_error(503),
            [
                StreamEvent("start", {"id": "stream-id"}),
                StreamEvent("text_delta", {"delta": "ok"}),
                finish_event(output_tokens=1),
            ],
        ]
    )
    sleeps: list[float] = []
    service = make_service(
        test_settings,
        prompt_registry,
        metrics_store,
        {"deepseek-v4-pro": adapter},
        sleeps,
    )
    prepared = await service.prepare(chat_request(stream=True))

    events = [event async for event in service.stream(prepared)]
    done = events[-1].data

    assert done["retry_count"] == 1
    assert adapter.stream_calls == 2
    assert sleeps == [0.0]
    assert events[0].event == "start"
