# LLM 统一模型调用服务（Unified LLM Gateway）

一个 FastAPI 服务：**同一套请求/响应接口**，内部用适配器模式同时接入两种真实不同的 API 协议：

| 模型 | API 协议 | 上游路径 | 鉴权方式 |
| --- | --- | --- | --- |
| `deepseek-v4-pro` | OpenAI Responses API | `POST https://api.deepseek.com/v1/responses` | `Authorization: Bearer ...` |
| `deepseek-flash` | Anthropic Messages API | `POST https://api.deepseek.com/anthropic/v1/messages` | `x-api-key` + `anthropic-version` |

`deepseek-v4-flash` 作为 `deepseek-flash` 的兼容别名也可用；响应中的 `model` 始终返回规范 id。

服务按请求中的 `model` 字段动态路由，统一处理流式输出、结构化输出、提示词版本、Token/延迟观测、错误码、指数退避重试和按模型独立限流。

---

## 1. 能力与验收证据

| 要求 | 实现 | 验证检查 |
| --- | --- | --- |
| 统一抽象 + 适配器 + 动态路由 | `BaseAdapter` + 两个协议适配器 + `MODEL_CATALOG` 路由表 | `discovery`、`non_stream_both_protocols` |
| 流式输出（SSE） | `POST /v1/chat` 且 `stream=true`，逐块 SSE | `stream_both_protocols` |
| 结构化输出 | `response_format`（`json_schema` / `json_object`），JSON Schema 校验 | `structured_output_both` |
| 提示词版本管理 | 文件存储、`v1/v2` 版本、`{{var}}` 替换、按版本引用、SHA-256 | `prompt_versions` |
| 可观测性 | Token 分类统计、总延迟、首 Token 延迟（TTFT）、首文本延迟、重试明细 | `observability` |
| 错误码 + 重试 | 统一错误信封；429/5xx/超时/连接错误指数退避，最多 3 次重试 | `retry_backoff`、`retry_exhaustion`、`unified_errors` |
| 按模型限流 | 每模型独立令牌桶，超限立即 429 + `Retry-After` | `rate_limit_isolation` |

最近一次真实上游验证：**10/10 通过**，报告见
[`evidence/verification-20261029-212447-c34549.json`](evidence/verification-20261029-212447-c34549.json)。

---

## 2. 架构

```text
Client
  │  POST /v1/chat  { model, messages | prompt, stream, response_format }
  ▼
FastAPI router
  ├─ Request-ID / 统一错误处理 / SSE 编码
  ├─ PromptRegistry ──────── 版本模板 + {{变量}} 渲染
  └─ LLMService
       ├─ 模型路由（model → adapter）
       ├─ 每模型令牌桶（429）
       ├─ 重试器（指数退避 + Retry-After，最多 3 次）
       ├─ 结构化输出校验（jsonschema）
       ├─ 指标记录（Token 分类 / 总延迟 / TTFT / retry）
       ├─ DeepSeekV4ProAdapter ──→ OpenAI Responses API
       └─ DeepSeekV4FlashAdapter ─→ Anthropic Messages API
```

目录：

```text
app/
  adapters/
    base.py                  # 统一适配器契约、Usage、StreamEvent
    openai_responses.py      # Responses API 协议适配器
    anthropic_messages.py    # Anthropic Messages 协议适配器
    deepseek_adapter.py      # 模型 → 协议适配器绑定
  core/
    errors.py                # 统一错误码 / 错误信封
    model_catalog.py         # 模型与协议路由表
    rate_limit.py            # 按模型令牌桶
    sse.py                   # SSE 编码
    logging_config.py
  prompts/registry.py        # 版本化模板存储/渲染
  services/
    llm_client.py            # 统一服务：路由、重试、流式、指标
    metrics.py               # 观测记录与聚合
    structured.py            # response_format 规范化 + JSON Schema 校验
  routers/                   # chat / prompts / models / metrics / health
  models/schemas.py          # HTTP 请求响应模型
  main.py                    # 应用工厂、生命周期、统一异常处理
prompts/                     # 随代码提交的种子模板
scripts/verify.py            # 端到端验证脚本
evidence/                    # 验证报告与服务器日志
tests/                       # 单元/接口测试
```

### 两种协议的差异在哪里

| 维度 | OpenAI Responses API | Anthropic Messages API |
| --- | --- | --- |
| 鉴权 | `Authorization: Bearer` | `x-api-key` + `anthropic-version: 2023-06-01` |
| 系统提示 | 顶层 `instructions` | 顶层 `system` 字符串 |
| 消息体 | `input` 角色数组 | `messages` 数组，需角色交替 |
| 最大输出 | `max_output_tokens` | 必填 `max_tokens` |
| 结构化输出 | `text.format = json_schema` | 强制工具调用 `tool_choice`（并关闭 thinking） |
| 流式事件 | `response.output_text.delta` 等 | `content_block_delta.text_delta` 等 |
| 用量字段 | 嵌套 `input_tokens_details` / `output_tokens_details` | `input_tokens` + cache 字段，无独立 reasoning |
| 结束原因 | `status` / `incomplete_details` | `stop_reason` |

这些差异全部封装在 `app/adapters/` 内；`LLMService` 和路由层只看到 `AdapterRequest` / `AdapterResponse` / `StreamEvent`。

---

## 3. 启动

要求 Python 3.11+（本项目在 3.13.9 上验证）。

```powershell
cd D:\PythonCode\ai-chat-api

python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

Copy-Item .env.example .env
# 编辑 .env，填入真实的 DEEPSEEK_API_KEY

uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Linux / macOS：

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

检查：

```powershell
curl.exe -s http://127.0.0.1:8000/health
curl.exe -s http://127.0.0.1:8000/v1/models
```

Swagger 文档：<http://127.0.0.1:8000/docs>（`ENVIRONMENT=development` 时开启）。

### 环境变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `DEEPSEEK_API_KEY` | 空 | 必填；两个模型共用 |
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com` | 基础地址 |
| `DEEPSEEK_RESPONSES_BASE_URL` | `{base}/v1` | 可单独覆盖 Responses 端点 |
| `DEEPSEEK_ANTHROPIC_BASE_URL` | `{base}/anthropic` | 可单独覆盖 Anthropic 端点 |
| `LLM_MAX_RETRIES` | `3` | 最多 3 次重试（共 4 次尝试），上限强制为 3 |
| `LLM_RETRY_BASE_DELAY` | `0.5` | 指数退避基数（秒） |
| `LLM_RETRY_MAX_DELAY` | `8` | 单次退避上限（秒） |
| `LLM_RETRY_JITTER` | `0.2` | 抖动比例 |
| `RATE_LIMIT_DEFAULT_CAPACITY` | `60` | 每模型令牌桶容量 |
| `RATE_LIMIT_DEFAULT_REFILL_PER_SECOND` | `1` | 每秒补充令牌数 |
| `RATE_LIMIT_OVERRIDES` | 空 | JSON，按模型覆盖，例如 `{"deepseek-flash":{"capacity":2,"refill_per_second":0.001}}` |
| `PROMPT_SEED_DIR` | `prompts` | 只读种子模板目录 |
| `PROMPT_STORE_DIR` | `data/prompts` | API 创建的模板目录 |
| `OBSERVABILITY_LOG_PATH` | `data/observability.jsonl` | 指标 JSONL；置空则只保留内存 |
| `ENABLE_DEBUG_FAULTS` | `false` | 仅本地验证用：允许故障注入头 |

---

## 4. API 与 curl 示例

### 4.1 非流式（两个模型）

```powershell
# DeepSeek V4 Pro -> OpenAI Responses API
curl.exe -s http://127.0.0.1:8000/v1/chat `
  -H "Content-Type: application/json" `
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"Reply with exactly: OK"}],"max_tokens":256}'

# DeepSeek V4 Flash -> Anthropic Messages API
curl.exe -s http://127.0.0.1:8000/v1/chat `
  -H "Content-Type: application/json" `
  -d '{"model":"deepseek-flash","messages":[{"role":"user","content":"Reply with exactly: OK"}],"max_tokens":256}'
```

响应（节选）：

```json
{
  "id": "4ccf6c1e-...",
  "model": "deepseek-v4-pro",
  "protocol": "openai-responses",
  "choices": [{"message": {"role": "assistant", "content": "OK"}, "finish_reason": "stop"}],
  "usage": {
    "input_tokens": 88,
    "output_tokens": 15,
    "total_tokens": 103,
    "reasoning_tokens": 13,
    "cached_input_tokens": 0,
    "cache_creation_input_tokens": 0
  },
  "latency": {"total_ms": 1133.94, "ttft_ms": null, "first_text_ms": null},
  "retry_count": 0,
  "request_id": "req_...",
  "prompt": null,
  "structured": false
}
```

`X-Request-Id`、`X-RateLimit-Limit`、`X-RateLimit-Remaining`、`X-RateLimit-Reset`、`X-RateLimit-Model` 会出现在响应头。

### 4.2 流式（SSE）

```powershell
curl.exe -N -s http://127.0.0.1:8000/v1/chat `
  -H "Content-Type: application/json" `
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"Count from 1 to 6, comma separated."}],"max_tokens":512,"stream":true,"include_reasoning":true}'
```

事件顺序：

| event | data 主要内容 |
| --- | --- |
| `start` | `id`、`model`、`protocol`、`request_id`、`prompt` |
| `reasoning` | `delta`（仅 `include_reasoning=true`） |
| `delta` | `delta` |
| `usage` | `usage`、`ttft_ms`、`retry_count` |
| `done` | `finish_reason`、`usage`、`latency`（`ttft_ms`/`first_text_ms`）、`attempts`、`parsed`（结构化时） |
| 结束标记 | `data: [DONE]` |

`stream=true` 时错误也会以 `event: error` 发送（HTTP 头已经发出，无法再改状态码）；参数/限流等前置错误仍返回正常 HTTP 4xx JSON。

### 4.3 结构化输出

```powershell
curl.exe -s http://127.0.0.1:8000/v1/chat `
  -H "Content-Type: application/json" `
  -d '{
    "model": "deepseek-flash",
    "messages": [{"role":"user","content":"Classify: I love this product."}],
    "max_tokens": 512,
    "response_format": {
      "type": "json_schema",
      "json_schema": {
        "name": "sentiment",
        "strict": true,
        "schema": {
          "type": "object",
          "properties": {
            "sentiment": {"type":"string","enum":["positive","negative","neutral"]},
            "confidence": {"type":"number"}
          },
          "required": ["sentiment","confidence"],
          "additionalProperties": false
        }
      }
    }
  }'
```

- Responses：直接使用 `text.format` 的 `json_schema`。
- Anthropic：适配器把同一份 schema 转成唯一工具 `structured_output`，使用 `tool_choice` 强制调用；因为强制工具与 thinking 不兼容，结构化请求会关闭 thinking。
- 服务端用 `jsonschema` 再校验一次；不合法返回 `STRUCTURED_OUTPUT_INVALID`（502），并在响应中给出 `parsed`（合法时）。

### 4.4 提示词版本

```powershell
# 创建 v1
curl.exe -s -X POST http://127.0.0.1:8000/v1/prompts `
  -H "Content-Type: application/json" `
  -d '{"name":"support_reply_demo","template":"Reply with exactly: {{word}}","description":"demo v1"}'

# 创建 v2
curl.exe -s -X POST http://127.0.0.1:8000/v1/prompts/support_reply_demo/versions `
  -H "Content-Type: application/json" `
  -d '{"template":"Reply with exactly: {{word}}!","description":"demo v2"}'

# 列出所有版本
curl.exe -s http://127.0.0.1:8000/v1/prompts/support_reply_demo/versions

# 渲染指定版本（不调用模型）
curl.exe -s -X POST http://127.0.0.1:8000/v1/prompts/support_reply_demo/render `
  -H "Content-Type: application/json" `
  -d '{"version":1,"variables":{"word":"BANANA"}}'

# 在聊天中引用 v1
curl.exe -s http://127.0.0.1:8000/v1/chat `
  -H "Content-Type: application/json" `
  -d '{"model":"deepseek-flash","prompt":{"name":"support_reply_demo","version":1,"variables":{"word":"BANANA"}},"max_tokens":256}'
```

- 模板占位符：`{{ variable }}`（允许空格）。
- 缺变量返回 422 `TEMPLATE_VARIABLE_MISSING`，不会静默替换为空串。
- 响应中的 `prompt` 字段带 `name`、`version`、`sha256`，可用于审计/回放。
- 种子模板：`prompts/sentiment/v1.json`、`v2.json`、`prompts/support_reply/v1.json`。
- API 创建的版本写入 `PROMPT_STORE_DIR`；同 name/version 时 store 覆盖 seed。
- `GET /v1/prompts/{name}?version=latest` 或整数版本均可。

### 4.5 观测数据

```powershell
curl.exe -s http://127.0.0.1:8000/v1/metrics/summary
curl.exe -s "http://127.0.0.1:8000/v1/metrics/recent?limit=20&model=deepseek-flash"
curl.exe -s http://127.0.0.1:8000/v1/metrics/calls/req_xxx
curl.exe -s http://127.0.0.1:8000/v1/rate-limits
```

`summary` 包含：总调用数、成功/失败/被限流/取消数、Token 六项分类合计、延迟与 TTFT 的 avg/p50/p95、按模型/按协议聚合、重试次数、时间窗口。每条 record 同时写入 `data/observability.jsonl`。

### 4.6 重试验证（仅本地）

```powershell
# 启动时设置 ENABLE_DEBUG_FAULTS=true
$env:ENABLE_DEBUG_FAULTS="true"

curl.exe -s http://127.0.0.1:8000/v1/chat `
  -H "Content-Type: application/json" `
  -H "X-Debug-Fail-Times: 2" `
  -H "X-Debug-Fail-Status: 503" `
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"Reply with exactly: RETRY_OK"}],"max_tokens":256}'
```

响应中的 `retry_count` 为 2，`attempts` 会显示前两次 503 和 50ms/100ms 退避（验证脚本把基数设为 0.05s），第三次成功。头只在 `ENABLE_DEBUG_FAULTS=true` 时生效；生产环境保持 `false`。

### 4.7 限流验证（按模型独立）

```powershell
$env:RATE_LIMIT_OVERRIDES='{"deepseek-flash":{"capacity":2,"refill_per_second":0.001}}'
uvicorn app.main:app --port 8001
```

连续三次调用 `deepseek-flash`，前两次 200，第三次 429：

```json
{"error":{"code":"RATE_LIMITED","message":"Rate limit exceeded for model 'deepseek-flash'; retry in 999s","type":"rate_limit_error","retryable":true,"details":{"model":"deepseek-flash","limit":2,"remaining":0,"retry_after_seconds":999},"request_id":"req_..."}}
```

同时调用 `deepseek-v4-pro` 仍为 200，因为两个桶互不影响。响应头带 `Retry-After`、`X-RateLimit-*`。

---

## 5. 统一错误码

所有错误（包括 FastAPI 校验错误）统一为：

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "...",
    "type": "rate_limit_error",
    "retryable": true,
    "details": {},
    "request_id": "req_..."
  }
}
```

| code | HTTP | 说明 |
| --- | --- | --- |
| `VALIDATION_ERROR` | 422 | 请求体校验失败 |
| `MODEL_NOT_FOUND` | 404 | 模型不存在 |
| `MODEL_NOT_CONFIGURED` | 503 | 缺少 API Key / 适配器 |
| `INVALID_RESPONSE_FORMAT` | 400 | schema 结构非法 |
| `STRUCTURED_OUTPUT_INVALID` | 502 | 上游输出不是合法 JSON 或不匹配 schema |
| `PROMPT_NOT_FOUND` | 404 | 模板不存在 |
| `PROMPT_VERSION_NOT_FOUND` | 404 | 版本不存在 |
| `PROMPT_CONFLICT` | 409 | 同名模板已存在 |
| `TEMPLATE_VARIABLE_MISSING` | 422 | 缺少模板变量 |
| `RATE_LIMITED` | 429 | 本服务按模型限流 |
| `UPSTREAM_RATE_LIMITED` | 429 | 上游 429（重试后仍失败） |
| `UPSTREAM_TIMEOUT` | 504 | 上游超时 |
| `UPSTREAM_CONNECTION_ERROR` | 502 | 连接失败 |
| `UPSTREAM_AUTH_ERROR` | 502 | 上游鉴权失败 |
| `UPSTREAM_BAD_REQUEST` | 400 | 上游 400/422 |
| `UPSTREAM_UNAVAILABLE` | 502 | 上游 5xx（重试后仍失败） |
| `UPSTREAM_BAD_RESPONSE` | 502 | 上游响应无法解析 |
| `UPSTREAM_STREAM_INTERRUPTED` | 502 | 流在结束事件前中断 |
| `INTERNAL_ERROR` | 500 | 未预期内部错误 |

重试规则：仅对 429、5xx、408、超时、连接错误、流未开始时的中断重试；400/401/403/404/422 不重试。最多 3 次重试，退避为 `base * 2^attempt` 加抖动，并尊重上游 `Retry-After`。流式请求只有在 `start` 事件发出前才会重试。

---

## 6. 验证

### 6.1 端到端验证脚本

前置：已安装 `requirements.txt`（包含 `jsonschema`），`.env` 有真实 Key。

```powershell
.\.venv\Scripts\python.exe scripts\verify.py
```

脚本会自动：

1. 启动真实 `uvicorn`（端口随机）；
2. 覆盖两个模型的非流式调用；
3. 覆盖两个模型的 SSE 流式调用；
4. 覆盖两个模型的结构化输出；
5. 创建 v1/v2 模板、渲染、缺变量、按版本引用；
6. 注入 2 次 503，验证指数退避与 `retry_count=2`；
7. 注入 9 次 503，验证最多 3 次重试后返回 502；
8. 校验统一错误码；
9. 校验 metrics 中的 Token 分类、总延迟、TTFT、first_text_ms、重试记录；
10. 启动第二个低限流实例，验证 flash 第 3 次 429、pro 仍 200；
11. 写入 `evidence/verification-<run_id>.json` 和服务器日志。

本次结果：**10/10 通过**。可直接查看
[`evidence/verification-20261029-212447-c34549.json`](evidence/verification-20261029-212447-c34549.json)：

```json
"summary": {"total": 10, "passed": 10, "failed": 0}
```

报告里每项都含 `request_id`、usage、latency、attempts 等可复查数据。

### 6.2 自动化测试

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

测试不访问真实上游：适配器用 `httpx.MockTransport`，服务层用假适配器；覆盖 HTTP/SSE 协议解析、重试、限流、模板版本、结构化校验和统一错误码。当前 **18 个测试全部通过**（`18 passed`）。

---

## 7. 设计说明与边界

- **Token 语义**：`input_tokens` 已包含缓存输入；`cached_input_tokens`、`reasoning_tokens` 是子集；`total_tokens = input_tokens + output_tokens`。Anthropic 不单独报告 reasoning token，因此该字段为 0（其思考 token 已含在 `output_tokens` 中）。
- **首 Token 延迟**：从收到请求到上游第一个内容增量（含 reasoning/thinking）的时间。响应另给 `first_text_ms`，表示第一个可见文本增量；两者都进入流式 `done` 事件和 metrics record。
- **可观测性存储**：内存环形缓冲 + JSONL 追加写。多进程/多 worker 时每个进程各自统计；生产可替换为 Prometheus/OTel。
- **限流**：单进程内存令牌桶；多实例部署需要 Redis 等共享存储。当前按“每个 HTTP 请求消耗 1 token”计数，重试不重复消耗。
- **结构化输出**：Anthropic 采用强制工具调用并关闭 thinking，这是该协议下获得严格 schema 的可靠方式；Responses 使用原生 `text.format`。
- **流式错误**：一旦 `start` 已发送，HTTP 状态无法回退为 4xx/5xx，错误通过 `event: error` 传递；这是 SSE 的固有限制。
- **模板存储**：种子模板只读，API 创建版本写入 `data/prompts`；没有数据库依赖。模板名限制为小写字母/数字/`_`/`-`。
- **安全**：不记录 API Key；不把用户的 Authorization 转发给上游；故障注入默认关闭，仅用于本地验证。

---

## 8. 交付物清单

- 完整源码：`app/`、`prompts/`、`scripts/`、`tests/`
- 启动指南与 curl 示例：本 README
- 验证脚本：`scripts/verify.py`（覆盖六大功能点，输出 JSON 证据）
- 验证证据：`evidence/verification-*.json`、`evidence/server-*.log`
- 依赖：`requirements.txt`、`requirements-dev.txt`
- 容器：`Dockerfile`
