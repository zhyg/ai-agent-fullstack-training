# app/main.py
"""FastAPI application factory and unified error handling."""
from __future__ import annotations

import re
import time
import uuid
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import Settings, get_settings
from app.core.context import get_request_id, set_request_id
from app.core.errors import ErrorCode, ServiceError
from app.core.logging_config import setup_logging
from app.prompts.registry import PromptRegistry
from app.routers import chat, health, metrics, models, prompts
from app.services.llm_client import LLMService
from app.services.metrics import MetricsStore
from pi_ai import stream, Context, UserMessage, Model, StreamOptions

logger = structlog.get_logger()
_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    setup_logging(settings.log_level, settings.is_development)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        prompt_registry = PromptRegistry(
            settings.prompt_seed_dir,
            settings.prompt_store_dir,
        )
        metrics_store = MetricsStore(
            log_path=settings.observability_log_path,
            max_records=settings.observability_max_records,
        )
        service = LLMService(settings, prompt_registry, metrics_store)

        app.state.settings = settings
        app.state.prompt_registry = prompt_registry
        app.state.metrics = metrics_store
        app.state.llm_service = service

        logger.info(
            "app.startup",
            environment=settings.environment,
            version=settings.app_version,
            models=[model["id"] for model in service.get_available_models()],
            prompt_templates=len(prompt_registry.list_prompts()),
            api_key_configured=settings.api_key_configured,
            responses_endpoint=settings.responses_base_url,
            anthropic_endpoint=settings.anthropic_base_url,
            debug_faults=settings.enable_debug_faults,
        )
        try:
            yield
        finally:
            await service.aclose()
            metrics_store.close()
            logger.info("app.shutdown")

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description=(
            "One interface, two API protocols: DeepSeek V4 Pro over the "
            "OpenAI Responses API and DeepSeek V4 Flash over the Anthropic "
            "Messages API. Streaming, structured output, versioned prompts, "
            "observability, retries and per-model rate limits."
        ),
        docs_url="/docs" if settings.is_development else None,
        redoc_url="/redoc" if settings.is_development else None,
        lifespan=lifespan,
    )
    app.state.settings = settings

    # ------------------------------------------------------------------
    # Middleware
    # ------------------------------------------------------------------
    @app.middleware("http")
    async def request_context(request: Request, call_next):
        incoming = request.headers.get("X-Request-Id", "")
        request_id = (
            incoming if _REQUEST_ID_RE.match(incoming)
            else f"req_{uuid.uuid4().hex}"
        )
        request.state.request_id = request_id
        set_request_id(request_id)
        structlog.contextvars.bind_contextvars(request_id=request_id)
        started = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            logger.exception(
                "request.failed",
                method=request.method,
                path=request.url.path,
                elapsed_ms=round((time.perf_counter() - started) * 1000, 2),
            )
            raise
        else:
            elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
            response.headers["X-Request-Id"] = request_id
            response.headers["X-Elapsed-Ms"] = f"{elapsed_ms:.2f}"
            logger.info(
                "request.completed",
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                elapsed_ms=elapsed_ms,
            )
            return response
        finally:
            structlog.contextvars.clear_contextvars()

    if settings.is_development:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

    # ------------------------------------------------------------------
    # Unified error handlers
    # ------------------------------------------------------------------
    @app.exception_handler(ServiceError)
    async def service_error_handler(
        request: Request,
        exc: ServiceError,
    ) -> JSONResponse:
        request_id = get_request_id() or getattr(
            request.state, "request_id", None
        )
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.to_payload(request_id),
            headers=exc.headers,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request,
        exc: RequestValidationError,
    ) -> JSONResponse:
        request_id = get_request_id() or getattr(
            request.state, "request_id", None
        )
        details = [
            {
                "loc": list(error.get("loc", [])),
                "msg": error.get("msg", ""),
                "type": error.get("type", ""),
            }
            for error in exc.errors()
        ]
        return JSONResponse(
            status_code=422,
            content={
                "error": {
                    "code": ErrorCode.VALIDATION_ERROR.value,
                    "message": "Request validation failed",
                    "type": "invalid_request_error",
                    "retryable": False,
                    "details": {"errors": details},
                    "request_id": request_id,
                }
            },
        )

    @app.exception_handler(HTTPException)
    async def http_error_handler(
        request: Request,
        exc: HTTPException,
    ) -> JSONResponse:
        request_id = get_request_id() or getattr(
            request.state, "request_id", None
        )
        code = (
            ErrorCode.NOT_FOUND
            if exc.status_code == 404
            else ErrorCode.HTTP_ERROR
        )
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": code.value,
                    "message": str(exc.detail),
                    "type": "invalid_request_error",
                    "retryable": False,
                    "details": {},
                    "request_id": request_id,
                }
            },
            headers=exc.headers,
        )

    @app.exception_handler(Exception)
    async def unhandled_error_handler(
        request: Request,
        exc: Exception,
    ) -> JSONResponse:
        logger.exception(
            "app.unhandled_error",
            path=request.url.path,
            error_type=type(exc).__name__,
        )
        request_id = get_request_id() or getattr(
            request.state, "request_id", None
        )
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": ErrorCode.INTERNAL_ERROR.value,
                    "message": "Internal gateway error",
                    "type": "internal_error",
                    "retryable": False,
                    "details": {},
                    "request_id": request_id,
                }
            },
        )

    # ------------------------------------------------------------------
    # Routes
    # ------------------------------------------------------------------
    app.include_router(chat.router)
    app.include_router(models.router)
    app.include_router(prompts.router)
    app.include_router(metrics.router)
    app.include_router(health.router)

    @app.get("/", tags=["Discovery"])
    async def root(request: Request) -> dict:
        current: Settings = request.app.state.settings
        service: LLMService = request.app.state.llm_service
        return {
            "name": current.app_name,
            "version": current.app_version,
            "environment": current.environment,
            "protocols": ["openai-responses", "anthropic-messages"],
            "models": [model["id"] for model in service.get_available_models()],
            "endpoints": {
                "chat": "POST /v1/chat",
                "models": "GET /v1/models",
                "prompts": "GET/POST /v1/prompts",
                "metrics": "GET /v1/metrics/summary",
                "rate_limits": "GET /v1/rate-limits",
                "health": "GET /health",
                "docs": "/docs" if current.is_development else "disabled",
            },
        }

    return app

app = create_app()
