# app/config.py
"""Application configuration.

Every value can be supplied through the environment or a local ``.env`` file.
The two upstream protocols share one DeepSeek API key but use independent
base URLs, so either endpoint can be pointed at a proxy or a mock server.
"""
from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------
    app_name: str = "LLM Unified Gateway"
    app_version: str = "1.0.0"
    environment: str = "development"
    log_level: str = "INFO"

    # ------------------------------------------------------------------
    # Upstream credentials and endpoints
    # ------------------------------------------------------------------
    deepseek_api_key: str = ""
    deepseek_base_url: str = "https://api.deepseek.com"

    # Optional explicit overrides. Empty means "derive from deepseek_base_url":
    #   responses -> {base}/v1
    #   anthropic -> {base}/anthropic
    deepseek_responses_base_url: str = ""
    deepseek_anthropic_base_url: str = ""

    connect_timeout: float = Field(default=10.0, gt=0)
    request_timeout: float = Field(default=120.0, gt=0)
    max_tokens_default: int = Field(default=2048, ge=1)
    max_tokens_limit: int = Field(default=32768, ge=1)

    # ------------------------------------------------------------------
    # Resilience
    # ------------------------------------------------------------------
    # "At most 3 retries" is part of the contract, so the upper bound is 3.
    llm_max_retries: int = Field(default=3, ge=0, le=3)
    llm_retry_base_delay: float = Field(default=0.5, ge=0)
    llm_retry_max_delay: float = Field(default=8.0, gt=0)
    llm_retry_jitter: float = Field(default=0.2, ge=0, le=1)

    # Token bucket, one independent bucket per model.
    rate_limit_default_capacity: int = Field(default=60, ge=1)
    rate_limit_default_refill_per_second: float = Field(default=1.0, gt=0)
    # JSON: {"deepseek-flash": {"capacity": 2, "refill_per_second": 0.01}}
    rate_limit_overrides: str = ""

    # ------------------------------------------------------------------
    # Prompt version store
    # ------------------------------------------------------------------
    prompt_seed_dir: str = "prompts"
    prompt_store_dir: str = "data/prompts"

    # ------------------------------------------------------------------
    # Observability
    # ------------------------------------------------------------------
    observability_log_path: str = "data/observability.jsonl"
    observability_max_records: int = Field(default=5000, ge=100)

    # Test-only fault injection. Keep disabled outside local verification.
    enable_debug_faults: bool = False

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @property
    def is_development(self) -> bool:
        return self.environment.lower() == "development"

    @property
    def api_key_configured(self) -> bool:
        return bool(self.deepseek_api_key.strip())

    @property
    def responses_base_url(self) -> str:
        if self.deepseek_responses_base_url:
            return self.deepseek_responses_base_url.rstrip("/")
        return f"{self.deepseek_base_url.rstrip('/')}/v1"

    @property
    def anthropic_base_url(self) -> str:
        if self.deepseek_anthropic_base_url:
            return self.deepseek_anthropic_base_url.rstrip("/")
        return f"{self.deepseek_base_url.rstrip('/')}/anthropic"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
