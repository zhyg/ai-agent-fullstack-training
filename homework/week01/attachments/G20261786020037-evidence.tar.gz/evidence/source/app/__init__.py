"""Unified LLM gateway application package."""

__version__ = "1.0.0"
