"""Versioned prompt template registry."""
