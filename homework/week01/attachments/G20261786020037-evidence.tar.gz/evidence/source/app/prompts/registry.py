# app/prompts/registry.py
"""Filesystem-backed, versioned prompt templates.

Layout (the store shadows the bundled seed on the same name/version):

    prompts/sentiment/v1.json          # committed seed
    prompts/sentiment/v2.json
    data/prompts/sentiment/v3.json     # created through the API

A template is a JSON document::

    {"name": "sentiment", "version": 1, "description": "...",
     "template": "Classify: {{text}}", "variables": ["text"],
     "sha256": "...", "created_at": "..."}

Variables use ``{{ name }}`` placeholders. Missing values are rejected with
``TEMPLATE_VARIABLE_MISSING`` instead of silently rendering an empty string.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

from app.core.errors import ErrorCode, ServiceError

logger = structlog.get_logger()

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
_VAR_RE = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")


def template_variables(template: str) -> list[str]:
    return sorted(set(_VAR_RE.findall(template)))


def template_sha256(template: str) -> str:
    return hashlib.sha256(template.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class PromptVersion:
    name: str
    version: int
    description: str
    template: str
    variables: tuple[str, ...]
    sha256: str
    created_at: str

    def to_dict(self, *, include_template: bool = True) -> dict[str, Any]:
        data: dict[str, Any] = {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "variables": list(self.variables),
            "sha256": self.sha256,
            "created_at": self.created_at,
        }
        if include_template:
            data["template"] = self.template
        return data

    def to_summary(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "latest_version": self.version,
            "description": self.description,
            "variables": list(self.variables),
            "sha256": self.sha256,
            "updated_at": self.created_at,
        }


@dataclass(frozen=True)
class RenderedPrompt:
    text: str
    prompt: PromptVersion

    def reference(self) -> dict[str, Any]:
        return {
            "name": self.prompt.name,
            "version": self.prompt.version,
            "sha256": self.prompt.sha256,
        }


class PromptRegistry:
    def __init__(self, seed_dir: str | Path, store_dir: str | Path) -> None:
        self.seed_dir = Path(seed_dir)
        self.store_dir = Path(store_dir)
        self._lock = threading.RLock()
        self.store_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------
    def _read_file(self, path: Path) -> PromptVersion | None:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            name = str(data["name"])
            version = int(data["version"])
            template = str(data["template"])
            if not _NAME_RE.match(name):
                raise ValueError(f"invalid template name {name!r}")
            if version < 1:
                raise ValueError("version must be >= 1")
            if not template.strip():
                raise ValueError("template must not be empty")
            description = str(data.get("description", ""))
            # Derive both from the template itself so a hand-edited file
            # cannot leave a stale variable list or hash behind.
            variables = tuple(template_variables(template))
            sha256 = template_sha256(template)
            created_at = str(data.get("created_at") or "")
            return PromptVersion(
                name=name,
                version=version,
                description=description,
                template=template,
                variables=variables,
                sha256=sha256,
                created_at=created_at,
            )
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
            logger.warning(
                "prompts.invalid_file",
                path=str(path),
                error=str(exc),
            )
            return None

    def _scan(self) -> dict[tuple[str, int], PromptVersion]:
        found: dict[tuple[str, int], PromptVersion] = {}
        # Seed first, store second, so the store wins on a collision.
        for root in (self.seed_dir, self.store_dir):
            if not root.exists():
                continue
            for path in sorted(root.glob("*/*.json")):
                prompt = self._read_file(path)
                if prompt is not None:
                    found[(prompt.name, prompt.version)] = prompt
        return found

    def list_prompts(self) -> list[dict[str, Any]]:
        found = self._scan()
        latest: dict[str, PromptVersion] = {}
        counts: dict[str, int] = {}
        for prompt in found.values():
            counts[prompt.name] = counts.get(prompt.name, 0) + 1
            current = latest.get(prompt.name)
            if current is None or prompt.version > current.version:
                latest[prompt.name] = prompt
        rows = []
        for name in sorted(latest):
            row = latest[name].to_summary()
            row["version_count"] = counts[name]
            rows.append(row)
        return rows

    def list_versions(self, name: str) -> list[dict[str, Any]]:
        found = self._scan()
        versions = [
            prompt
            for (prompt_name, _), prompt in found.items()
            if prompt_name == name
        ]
        if not versions:
            raise ServiceError(
                ErrorCode.PROMPT_NOT_FOUND,
                f"Prompt template {name!r} was not found",
                status_code=404,
                details={"name": name},
            )
        return [
            prompt.to_dict()
            for prompt in sorted(versions, key=lambda item: item.version)
        ]

    def get(self, name: str, version: int | str = "latest") -> PromptVersion:
        found = self._scan()
        versions = [key for key in found if key[0] == name]
        if not versions:
            raise ServiceError(
                ErrorCode.PROMPT_NOT_FOUND,
                f"Prompt template {name!r} was not found",
                status_code=404,
                details={"name": name},
            )
        if version == "latest":
            chosen = max(key[1] for key in versions)
        else:
            try:
                chosen = int(version)
            except (TypeError, ValueError) as exc:
                raise ServiceError(
                    ErrorCode.VALIDATION_ERROR,
                    "Prompt version must be an integer or 'latest'",
                    status_code=422,
                    details={"version": version},
                ) from exc
        prompt = found.get((name, chosen))
        if prompt is None:
            raise ServiceError(
                ErrorCode.PROMPT_VERSION_NOT_FOUND,
                f"Prompt template {name!r} has no version {chosen}",
                status_code=404,
                details={
                    "name": name,
                    "version": chosen,
                    "available_versions": sorted(key[1] for key in versions),
                },
            )
        return prompt

    def render(
        self,
        name: str,
        version: int | str,
        variables: dict[str, Any] | None,
    ) -> RenderedPrompt:
        prompt = self.get(name, version)
        values = {key: _stringify(value) for key, value in (variables or {}).items()}
        missing = [var for var in prompt.variables if var not in values]

        def replace(match: re.Match[str]) -> str:
            key = match.group(1)
            if key not in values:
                return match.group(0)
            return values[key]

        if missing:
            raise ServiceError(
                ErrorCode.TEMPLATE_VARIABLE_MISSING,
                f"Missing template variable(s): {', '.join(missing)}",
                status_code=422,
                details={
                    "name": name,
                    "version": prompt.version,
                    "missing": missing,
                    "provided": sorted(values),
                },
            )
        return RenderedPrompt(text=_VAR_RE.sub(replace, prompt.template), prompt=prompt)

    # ------------------------------------------------------------------
    # Writing
    # ------------------------------------------------------------------
    def create(
        self,
        name: str,
        template: str,
        description: str = "",
    ) -> PromptVersion:
        if not _NAME_RE.match(name):
            raise ServiceError(
                ErrorCode.VALIDATION_ERROR,
                "Template name must match ^[a-z0-9][a-z0-9_-]{0,63}$",
                status_code=422,
                details={"name": name},
            )
        self._validate_template(template)
        with self._lock:
            existing = [key for key in self._scan() if key[0] == name]
            if existing:
                raise ServiceError(
                    ErrorCode.PROMPT_CONFLICT,
                    f"Prompt template {name!r} already exists; add a new version instead",
                    status_code=409,
                    details={
                        "name": name,
                        "versions": sorted(key[1] for key in existing),
                    },
                )
            return self._write(name, 1, template, description)

    def add_version(
        self,
        name: str,
        template: str,
        description: str = "",
    ) -> PromptVersion:
        if not _NAME_RE.match(name):
            raise ServiceError(
                ErrorCode.VALIDATION_ERROR,
                "Template name must match ^[a-z0-9][a-z0-9_-]{0,63}$",
                status_code=422,
                details={"name": name},
            )
        self._validate_template(template)
        with self._lock:
            existing = [key for key in self._scan() if key[0] == name]
            if not existing:
                raise ServiceError(
                    ErrorCode.PROMPT_NOT_FOUND,
                    f"Prompt template {name!r} was not found",
                    status_code=404,
                    details={"name": name},
                )
            next_version = max(key[1] for key in existing) + 1
            return self._write(name, next_version, template, description)

    def _validate_template(self, template: str) -> None:
        if not template or not template.strip():
            raise ServiceError(
                ErrorCode.VALIDATION_ERROR,
                "Template must not be empty",
                status_code=422,
            )

    def _write(
        self,
        name: str,
        version: int,
        template: str,
        description: str,
    ) -> PromptVersion:
        prompt = PromptVersion(
            name=name,
            version=version,
            description=description,
            template=template,
            variables=tuple(template_variables(template)),
            sha256=template_sha256(template),
            created_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
        directory = self.store_dir / name
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"v{version}.json"
        tmp = path.with_suffix(".json.tmp")
        payload = {
            "name": prompt.name,
            "version": prompt.version,
            "description": prompt.description,
            "template": prompt.template,
            "variables": list(prompt.variables),
            "sha256": prompt.sha256,
            "created_at": prompt.created_at,
        }
        tmp.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(tmp, path)
        logger.info(
            "prompts.saved",
            name=name,
            version=version,
            path=str(path),
        )
        return prompt


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)
    return json.dumps(value, ensure_ascii=False)
