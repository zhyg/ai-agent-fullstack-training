# app/core/sse.py
"""Server-Sent Events helpers."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SseEvent:
    event: str
    data: dict[str, Any]


def encode_sse(event: SseEvent) -> str:
    payload = json.dumps(event.data, ensure_ascii=False, separators=(",", ":"))
    return f"event: {event.event}\ndata: {payload}\n\n"


SSE_DONE = "data: [DONE]\n\n"
