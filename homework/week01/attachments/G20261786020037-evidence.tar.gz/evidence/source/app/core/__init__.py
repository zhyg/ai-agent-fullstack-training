"""Cross-cutting concerns: errors, rate limiting, logging, SSE, request context."""
