# app/core/rate_limit.py
"""Per-model token-bucket rate limiting.

One bucket per canonical model id means a burst against ``deepseek-flash``
can never consume ``deepseek-v4-pro`` capacity. A denied request immediately
returns 429 (plus ``Retry-After``); requests are never queued.
"""
from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass

import structlog

from app.config import Settings
from app.core.errors import ErrorCode, ServiceError

logger = structlog.get_logger()


@dataclass(frozen=True)
class RateLimitConfig:
    capacity: int
    refill_per_second: float


@dataclass(frozen=True)
class RateLimitDecision:
    allowed: bool
    model: str
    limit: int
    remaining: int
    retry_after: float
    reset_after: float

    def headers(self) -> dict[str, str]:
        headers = {
            "X-RateLimit-Limit": str(self.limit),
            "X-RateLimit-Remaining": str(max(self.remaining, 0)),
            "X-RateLimit-Reset": str(max(1, math.ceil(self.reset_after))),
            "X-RateLimit-Model": self.model,
        }
        if not self.allowed:
            headers["Retry-After"] = str(max(1, math.ceil(self.retry_after)))
        return headers


class TokenBucket:
    def __init__(self, config: RateLimitConfig, *, clock=time.monotonic) -> None:
        if config.capacity < 1:
            raise ValueError("rate limit capacity must be >= 1")
        if config.refill_per_second <= 0:
            raise ValueError("rate limit refill_per_second must be > 0")
        self._config = config
        self._tokens = float(config.capacity)
        self._updated = clock()
        self._clock = clock

    def _refill(self) -> None:
        now = self._clock()
        elapsed = max(0.0, now - self._updated)
        self._updated = now
        self._tokens = min(
            float(self._config.capacity),
            self._tokens + elapsed * self._config.refill_per_second,
        )

    def acquire(self) -> tuple[bool, float, float]:
        """Consume one token. Returns (allowed, remaining, retry_after)."""
        self._refill()
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            return True, self._tokens, 0.0
        missing = 1.0 - self._tokens
        retry_after = missing / self._config.refill_per_second
        return False, self._tokens, retry_after

    def snapshot(self) -> tuple[int, float, float]:
        self._refill()
        reset_after = (
            self._config.capacity - self._tokens
        ) / self._config.refill_per_second
        return int(self._tokens), self._tokens, max(0.0, reset_after)


class ModelRateLimiter:
    def __init__(
        self,
        default: RateLimitConfig,
        overrides: dict[str, RateLimitConfig] | None = None,
        *,
        clock=time.monotonic,
    ) -> None:
        self._default = default
        self._overrides = overrides or {}
        self._buckets: dict[str, TokenBucket] = {}
        self._clock = clock

    @classmethod
    def from_settings(cls, settings: Settings) -> "ModelRateLimiter":
        default = RateLimitConfig(
            capacity=settings.rate_limit_default_capacity,
            refill_per_second=settings.rate_limit_default_refill_per_second,
        )
        overrides: dict[str, RateLimitConfig] = {}
        raw = (settings.rate_limit_overrides or "").strip()
        if raw:
            try:
                data = json.loads(raw)
                if not isinstance(data, dict):
                    raise ValueError("rate limit overrides must be a JSON object")
                for model, value in data.items():
                    if not isinstance(value, dict):
                        raise ValueError(f"override for {model!r} must be an object")
                    config = RateLimitConfig(
                        capacity=int(value.get("capacity", default.capacity)),
                        refill_per_second=float(
                            value.get(
                                "refill_per_second",
                                default.refill_per_second,
                            )
                        ),
                    )
                    if config.capacity < 1:
                        raise ValueError(
                            f"override for {model!r} has capacity < 1"
                        )
                    if config.refill_per_second <= 0:
                        raise ValueError(
                            f"override for {model!r} has refill_per_second <= 0"
                        )
                    overrides[str(model)] = config
                logger.info(
                    "rate_limit.overrides_loaded",
                    models=sorted(overrides),
                )
            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                raise ValueError(f"invalid RATE_LIMIT_OVERRIDES: {exc}") from exc
        return cls(default, overrides, clock=time.monotonic)

    def _config_for(self, model: str) -> RateLimitConfig:
        return self._overrides.get(model, self._default)

    def _bucket_for(self, model: str) -> TokenBucket:
        bucket = self._buckets.get(model)
        if bucket is None:
            bucket = TokenBucket(self._config_for(model), clock=self._clock)
            self._buckets[model] = bucket
        return bucket

    def acquire(self, model: str) -> RateLimitDecision:
        bucket = self._bucket_for(model)
        allowed, remaining, retry_after = bucket.acquire()
        config = self._config_for(model)
        reset_after = (
            config.capacity - remaining
        ) / config.refill_per_second
        return RateLimitDecision(
            allowed=allowed,
            model=model,
            limit=config.capacity,
            remaining=max(0, int(remaining)),
            retry_after=retry_after,
            reset_after=max(0.0, reset_after),
        )

    def ensure(self, model: str) -> None:
        """Create the bucket for a model without consuming a token."""
        self._bucket_for(model)

    def enforce(self, model: str) -> RateLimitDecision:
        decision = self.acquire(model)
        if decision.allowed:
            return decision
        retry_after = max(1, math.ceil(decision.retry_after))
        raise ServiceError(
            ErrorCode.RATE_LIMITED,
            f"Rate limit exceeded for model {model!r}; retry in {retry_after}s",
            status_code=429,
            retryable=True,
            details={
                "model": model,
                "limit": decision.limit,
                "remaining": decision.remaining,
                "retry_after_seconds": retry_after,
            },
            headers=decision.headers(),
        )

    def snapshot(self) -> list[dict]:
        rows = []
        for model in sorted(self._buckets):
            tokens, raw_tokens, reset_after = self._buckets[model].snapshot()
            config = self._config_for(model)
            rows.append(
                {
                    "model": model,
                    "capacity": config.capacity,
                    "refill_per_second": config.refill_per_second,
                    "tokens": round(raw_tokens, 3),
                    "remaining_requests": tokens,
                    "reset_after_seconds": round(reset_after, 3),
                }
            )
        return rows
