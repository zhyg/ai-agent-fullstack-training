# app/core/errors.py
"""Unified error codes and exceptions.

Every failure surfaced by the gateway uses the same envelope:

    {"error": {"code": ..., "message": ..., "type": ..., "retryable": ...,
               "details": ..., "request_id": ...}}

Adapters translate protocol-specific failures into :class:`UpstreamError`, so
the HTTP layer and the client only ever see gateway error codes.
"""
from __future__ import annotations

from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    # Client / request errors
    INVALID_REQUEST = "INVALID_REQUEST"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    MODEL_NOT_FOUND = "MODEL_NOT_FOUND"
    MODEL_NOT_CONFIGURED = "MODEL_NOT_CONFIGURED"
    INVALID_RESPONSE_FORMAT = "INVALID_RESPONSE_FORMAT"
    STRUCTURED_OUTPUT_INVALID = "STRUCTURED_OUTPUT_INVALID"
    PROMPT_NOT_FOUND = "PROMPT_NOT_FOUND"
    PROMPT_VERSION_NOT_FOUND = "PROMPT_VERSION_NOT_FOUND"
    PROMPT_CONFLICT = "PROMPT_CONFLICT"
    TEMPLATE_VARIABLE_MISSING = "TEMPLATE_VARIABLE_MISSING"
    UNKNOWN_JOB = "UNKNOWN_JOB"
    NOT_FOUND = "NOT_FOUND"
    HTTP_ERROR = "HTTP_ERROR"

    # Gateway rate limiting
    RATE_LIMITED = "RATE_LIMITED"

    # Upstream failures
    UPSTREAM_RATE_LIMITED = "UPSTREAM_RATE_LIMITED"
    UPSTREAM_TIMEOUT = "UPSTREAM_TIMEOUT"
    UPSTREAM_CONNECTION_ERROR = "UPSTREAM_CONNECTION_ERROR"
    UPSTREAM_AUTH_ERROR = "UPSTREAM_AUTH_ERROR"
    UPSTREAM_BAD_REQUEST = "UPSTREAM_BAD_REQUEST"
    UPSTREAM_MODEL_NOT_FOUND = "UPSTREAM_MODEL_NOT_FOUND"
    UPSTREAM_UNAVAILABLE = "UPSTREAM_UNAVAILABLE"
    UPSTREAM_BAD_RESPONSE = "UPSTREAM_BAD_RESPONSE"
    UPSTREAM_STREAM_INTERRUPTED = "UPSTREAM_STREAM_INTERRUPTED"

    # Fallback
    INTERNAL_ERROR = "INTERNAL_ERROR"


_ERROR_TYPES: dict[ErrorCode, str] = {
    ErrorCode.INVALID_REQUEST: "invalid_request_error",
    ErrorCode.VALIDATION_ERROR: "invalid_request_error",
    ErrorCode.MODEL_NOT_FOUND: "invalid_request_error",
    ErrorCode.MODEL_NOT_CONFIGURED: "configuration_error",
    ErrorCode.INVALID_RESPONSE_FORMAT: "invalid_request_error",
    ErrorCode.STRUCTURED_OUTPUT_INVALID: "upstream_error",
    ErrorCode.PROMPT_NOT_FOUND: "invalid_request_error",
    ErrorCode.PROMPT_VERSION_NOT_FOUND: "invalid_request_error",
    ErrorCode.PROMPT_CONFLICT: "invalid_request_error",
    ErrorCode.TEMPLATE_VARIABLE_MISSING: "invalid_request_error",
    ErrorCode.NOT_FOUND: "invalid_request_error",
    ErrorCode.HTTP_ERROR: "invalid_request_error",
    ErrorCode.RATE_LIMITED: "rate_limit_error",
    ErrorCode.UPSTREAM_RATE_LIMITED: "rate_limit_error",
    ErrorCode.UPSTREAM_TIMEOUT: "upstream_error",
    ErrorCode.UPSTREAM_CONNECTION_ERROR: "upstream_error",
    ErrorCode.UPSTREAM_AUTH_ERROR: "upstream_error",
    ErrorCode.UPSTREAM_BAD_REQUEST: "upstream_error",
    ErrorCode.UPSTREAM_MODEL_NOT_FOUND: "upstream_error",
    ErrorCode.UPSTREAM_UNAVAILABLE: "upstream_error",
    ErrorCode.UPSTREAM_BAD_RESPONSE: "upstream_error",
    ErrorCode.UPSTREAM_STREAM_INTERRUPTED: "upstream_error",
    ErrorCode.INTERNAL_ERROR: "internal_error",
}


def error_type(code: ErrorCode) -> str:
    return _ERROR_TYPES.get(code, "internal_error")


class ServiceError(Exception):
    """A failure that can be rendered as the unified error envelope."""

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        *,
        status_code: int = 400,
        retryable: bool = False,
        details: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retryable = retryable
        self.details = details or {}
        self.headers = headers or {}

    def to_payload(self, request_id: str | None = None) -> dict[str, Any]:
        return {
            "error": {
                "code": self.code.value,
                "message": self.message,
                "type": error_type(self.code),
                "retryable": self.retryable,
                "details": self.details,
                "request_id": request_id,
            }
        }

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return (
            f"{type(self).__name__}(code={self.code.value!r}, "
            f"status={self.status_code}, retryable={self.retryable})"
        )


class UpstreamError(ServiceError):
    """An error returned by (or while talking to) an upstream protocol."""

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        *,
        status_code: int = 502,
        retryable: bool = False,
        upstream_status: int | None = None,
        retry_after: float | None = None,
        details: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        merged = dict(details or {})
        if upstream_status is not None:
            merged.setdefault("upstream_status", upstream_status)
        super().__init__(
            code,
            message,
            status_code=status_code,
            retryable=retryable,
            details=merged,
            headers=headers,
        )
        self.upstream_status = upstream_status
        self.retry_after = retry_after
