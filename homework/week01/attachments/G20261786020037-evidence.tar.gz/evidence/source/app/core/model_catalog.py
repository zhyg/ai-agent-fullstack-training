# app/core/model_catalog.py
"""Static catalogue of the models exposed by the gateway.

The catalogue is intentionally code (not configuration): it maps a public
model id to the *protocol* used to call the upstream. This is the routing
table the unified layer uses, and the only place that knows both protocols
exist.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Protocol(str, Enum):
    OPENAI_RESPONSES = "openai-responses"
    ANTHROPIC_MESSAGES = "anthropic-messages"


@dataclass(frozen=True)
class ModelSpec:
    id: str
    display_name: str
    upstream_model: str
    protocol: Protocol
    description: str
    context_window: int
    max_output_tokens: int
    aliases: tuple[str, ...] = ()

    def to_public_dict(self) -> dict:
        return {
            "id": self.id,
            "object": "model",
            "name": self.display_name,
            "provider": "DeepSeek",
            "protocol": self.protocol.value,
            "upstream_model": self.upstream_model,
            "description": self.description,
            "context_window": self.context_window,
            "max_output_tokens": self.max_output_tokens,
        }


MODEL_CATALOG: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="deepseek-v4-pro",
        display_name="DeepSeek V4 Pro",
        upstream_model="deepseek-v4-pro",
        protocol=Protocol.OPENAI_RESPONSES,
        description="DeepSeek V4 Pro, called through the OpenAI Responses API.",
        context_window=1_048_576,
        max_output_tokens=393_216,
        aliases=("deepseek-v4-pro-latest",),
    ),
    ModelSpec(
        id="deepseek-flash",
        display_name="DeepSeek V4 Flash",
        upstream_model="deepseek-flash",
        protocol=Protocol.ANTHROPIC_MESSAGES,
        description="DeepSeek V4 Flash, called through the Anthropic Messages API.",
        context_window=1_048_576,
        max_output_tokens=393_216,
        aliases=("deepseek-v4-flash", "deepseek-v4.1-flash"),
    ),
)

_BY_ID: dict[str, ModelSpec] = {}
for _spec in MODEL_CATALOG:
    _BY_ID[_spec.id] = _spec
    for _alias in _spec.aliases:
        _BY_ID[_alias] = _spec


def resolve_model(model: str) -> ModelSpec | None:
    return _BY_ID.get(model)


def all_models() -> tuple[ModelSpec, ...]:
    return MODEL_CATALOG
