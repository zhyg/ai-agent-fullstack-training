# app/routers/models.py
"""Model discovery."""
from __future__ import annotations

from fastapi import APIRouter, Query, Request

from app.core.errors import ErrorCode, ServiceError
from app.core.model_catalog import resolve_model
from app.models.schemas import ModelInfo, ModelListResponse
from app.services.llm_client import LLMService

router = APIRouter(prefix="/v1", tags=["Models"])


@router.get("/models", response_model=ModelListResponse)
async def list_models(
    request: Request,
    protocol: str | None = Query(
        default=None,
        description="Filter by protocol: openai-responses or anthropic-messages",
    ),
) -> ModelListResponse:
    service: LLMService = request.app.state.llm_service
    rows = service.get_available_models()
    if protocol:
        rows = [row for row in rows if row["protocol"] == protocol]
    models = [ModelInfo(**row) for row in rows]
    return ModelListResponse(
        models=models,
        total=len(models),
        default=models[0].id if models else "none",
    )


@router.get("/models/{model_id}", response_model=ModelInfo)
async def get_model(model_id: str) -> ModelInfo:
    spec = resolve_model(model_id)
    if spec is None:
        raise ServiceError(
            ErrorCode.MODEL_NOT_FOUND,
            f"Unknown model {model_id!r}",
            status_code=404,
            details={"model": model_id},
        )
    return ModelInfo(**spec.to_public_dict())
