# app/routers/chat.py
"""Unified chat endpoint: one shape for both protocols and both modes."""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Header, Request, Response
from fastapi.responses import StreamingResponse

from app.core.context import get_request_id
from app.core.sse import SSE_DONE, encode_sse
from app.models.schemas import ChatRequest
from app.services.llm_client import LLMService

router = APIRouter(prefix="/v1", tags=["Chat"])


@router.post("/chat")
async def chat(
    payload: ChatRequest,
    request: Request,
    response: Response,
    x_debug_fail_times: Annotated[
        int | None, Header(alias="X-Debug-Fail-Times")
    ] = None,
    x_debug_fail_status: Annotated[
        int | None, Header(alias="X-Debug-Fail-Status")
    ] = None,
) -> Any:
    """Run a chat completion.

    ``stream=false`` returns one JSON body. ``stream=true`` returns
    ``text/event-stream`` with ``start`` / ``delta`` / ``reasoning`` /
    ``usage`` / ``done`` / ``error`` events and a final ``data: [DONE]``.
    """
    service: LLMService = request.app.state.llm_service
    request_id = get_request_id() or request.state.request_id
    prepared = await service.prepare(
        payload,
        request_id=request_id,
        debug_fail_times=x_debug_fail_times or 0,
        debug_fail_status=x_debug_fail_status or 503,
    )

    common_headers = {
        **prepared.rate_decision.headers(),
        "X-Request-Id": request_id,
    }

    if payload.stream:
        async def event_stream():
            async for event in service.stream(prepared):
                yield encode_sse(event)
            yield SSE_DONE

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                **common_headers,
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    result = await service.complete(prepared)
    for key, value in common_headers.items():
        response.headers[key] = value
    return result
