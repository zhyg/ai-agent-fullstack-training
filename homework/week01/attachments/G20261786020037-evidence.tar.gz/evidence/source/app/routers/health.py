# app/routers/health.py
"""Health and readiness endpoints."""
from __future__ import annotations

import time

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from app.models.schemas import HealthResponse
from app.services.llm_client import LLMService

router = APIRouter(tags=["Health"])
START_TIME = time.monotonic()


@router.get("/health", response_model=HealthResponse)
async def health(request: Request) -> HealthResponse:
    settings = request.app.state.settings
    service: LLMService = request.app.state.llm_service
    models = service.get_available_models()
    return HealthResponse(
        status="healthy" if settings.api_key_configured else "degraded",
        version=settings.app_version,
        environment=settings.environment,
        models_available=len(models),
        api_key_configured=settings.api_key_configured,
        uptime_seconds=int(time.monotonic() - START_TIME),
    )


@router.get("/health/live")
async def liveness() -> dict[str, str]:
    return {"status": "alive"}


@router.get("/health/ready")
async def readiness(request: Request):
    settings = request.app.state.settings
    service: LLMService = request.app.state.llm_service
    models = service.get_available_models()
    if not settings.api_key_configured:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "reason": "DEEPSEEK_API_KEY is not configured",
            },
        )
    return {
        "status": "ready",
        "models": [model["id"] for model in models],
    }
