# app/routers/prompts.py
"""Prompt template version management."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query, Request

from app.models.schemas import (
    AddPromptVersionRequest,
    CreatePromptRequest,
    RenderPromptRequest,
)
from app.prompts.registry import PromptRegistry

router = APIRouter(prefix="/v1/prompts", tags=["Prompts"])


def _registry(request: Request) -> PromptRegistry:
    return request.app.state.prompt_registry


@router.get("")
async def list_prompts(request: Request) -> dict[str, Any]:
    prompts = _registry(request).list_prompts()
    return {
        "object": "list",
        "prompts": prompts,
        "total": len(prompts),
    }


@router.post("", status_code=201)
async def create_prompt(
    body: CreatePromptRequest,
    request: Request,
) -> dict[str, Any]:
    prompt = _registry(request).create(
        body.name,
        body.template,
        body.description,
    )
    return prompt.to_dict()


@router.get("/{name}")
async def get_prompt(
    name: str,
    request: Request,
    version: str | None = Query(
        default=None,
        pattern=r"^(latest|[1-9][0-9]*)$",
        description="Integer version or 'latest' (default).",
    ),
) -> dict[str, Any]:
    prompt = _registry(request).get(
        name,
        version if version is not None else "latest",
    )
    return prompt.to_dict()


@router.get("/{name}/versions")
async def list_prompt_versions(
    name: str,
    request: Request,
) -> dict[str, Any]:
    versions = _registry(request).list_versions(name)
    return {
        "name": name,
        "versions": [
            {
                "version": item["version"],
                "sha256": item["sha256"],
                "created_at": item["created_at"],
                "description": item["description"],
                "variables": item["variables"],
            }
            for item in versions
        ],
        "total": len(versions),
    }


@router.post("/{name}/versions", status_code=201)
async def add_prompt_version(
    name: str,
    body: AddPromptVersionRequest,
    request: Request,
) -> dict[str, Any]:
    prompt = _registry(request).add_version(
        name,
        body.template,
        body.description,
    )
    return prompt.to_dict()


@router.post("/{name}/render")
async def render_prompt(
    name: str,
    body: RenderPromptRequest,
    request: Request,
) -> dict[str, Any]:
    rendered = _registry(request).render(
        name,
        body.version,
        body.variables,
    )
    return {
        "name": rendered.prompt.name,
        "version": rendered.prompt.version,
        "sha256": rendered.prompt.sha256,
        "variables": list(rendered.prompt.variables),
        "rendered": rendered.text,
    }
