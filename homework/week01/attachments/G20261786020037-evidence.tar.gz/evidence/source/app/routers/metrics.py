# app/routers/metrics.py
"""Observability endpoints."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query, Request

from app.core.errors import ErrorCode, ServiceError
from app.services.metrics import MetricsStore

router = APIRouter(prefix="/v1", tags=["Observability"])


def _metrics(request: Request) -> MetricsStore:
    return request.app.state.metrics


@router.get("/metrics/summary")
async def metrics_summary(request: Request) -> dict[str, Any]:
    return _metrics(request).summary()


@router.get("/metrics/recent")
async def metrics_recent(
    request: Request,
    limit: int = Query(default=50, ge=1, le=500),
    model: str | None = Query(default=None),
) -> dict[str, Any]:
    records = _metrics(request).recent(limit=limit, model=model)
    return {
        "records": records,
        "total": len(records),
        "limit": limit,
    }


@router.get("/metrics/calls/{request_id}")
async def metrics_call(request_id: str, request: Request) -> dict[str, Any]:
    record = _metrics(request).get(request_id)
    if record is None:
        raise ServiceError(
            ErrorCode.NOT_FOUND,
            f"Call record {request_id!r} was not found",
            status_code=404,
            details={"request_id": request_id},
        )
    return record


@router.get("/rate-limits")
async def rate_limits(request: Request) -> dict[str, Any]:
    service = request.app.state.llm_service
    limits = service.rate_limit_snapshot()
    return {
        "object": "list",
        "limits": limits,
        "total": len(limits),
    }
