# app/deps.py
"""FastAPI dependencies backed by app.state."""
from __future__ import annotations

from fastapi import Request

from app.config import Settings
from app.prompts.registry import PromptRegistry
from app.services.llm_client import LLMService
from app.services.metrics import MetricsStore


def get_settings(request: Request) -> Settings:
    return request.app.state.settings


def get_service(request: Request) -> LLMService:
    return request.app.state.llm_service


def get_prompts(request: Request) -> PromptRegistry:
    return request.app.state.prompt_registry


def get_metrics(request: Request) -> MetricsStore:
    return request.app.state.metrics
