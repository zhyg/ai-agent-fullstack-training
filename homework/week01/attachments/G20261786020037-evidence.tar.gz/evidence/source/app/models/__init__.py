"""Pydantic request/response models."""
