# app/models/schemas.py
"""HTTP request/response models."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"] = Field(
        ..., description="Message role."
    )
    content: str = Field(..., min_length=1, description="Message text.")


class PromptRef(BaseModel):
    """Reference a stored template version and its variables."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=1, description="Template name.")
    version: int | Literal["latest"] = Field(
        default="latest",
        description="Explicit integer version or 'latest'.",
    )
    variables: dict[str, Any] = Field(
        default_factory=dict,
        description="Values substituted into {{ variable }} placeholders.",
    )


class ResponseFormat(BaseModel):
    """OpenAI-style structured-output constraint."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["text", "json_object", "json_schema"] = Field(
        default="text",
        description="text (default), json_object, or json_schema.",
    )
    json_schema: dict[str, Any] | None = Field(
        default=None,
        description=(
            "When type=json_schema: {name, schema, strict}. "
            "schema is a JSON Schema object."
        ),
    )


class ChatRequest(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "model": "deepseek-v4-pro",
                    "messages": [
                        {"role": "user", "content": "Reply with exactly: OK"}
                    ],
                    "stream": False,
                    "response_format": {
                        "type": "json_schema",
                        "json_schema": {
                            "name": "answer",
                            "strict": True,
                            "schema": {
                                "type": "object",
                                "properties": {
                                    "answer": {"type": "string"}
                                },
                                "required": ["answer"],
                                "additionalProperties": False,
                            },
                        },
                    },
                }
            ]
        },
    )

    model: str = Field(
        ...,
        min_length=1,
        description="Public model id, e.g. deepseek-v4-pro or deepseek-flash.",
    )
    messages: list[ChatMessage] | None = Field(
        default=None,
        max_length=100,
        description="Chat messages; mutually exclusive with prompt.",
    )
    prompt: PromptRef | None = Field(
        default=None,
        description="Stored template reference; mutually exclusive with messages.",
    )
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=2048, ge=1, le=32768)
    stream: bool = Field(default=False, description="Return SSE when true.")
    response_format: ResponseFormat | None = Field(
        default=None,
        description="Structured-output constraint.",
    )
    include_reasoning: bool = Field(
        default=False,
        description="Include reasoning/thinking deltas and text in the result.",
    )

    @model_validator(mode="after")
    def validate_input(self) -> "ChatRequest":
        if (self.messages is None) == (self.prompt is None):
            raise ValueError("Provide exactly one of 'messages' or 'prompt'")
        if self.messages is not None:
            if not self.messages:
                raise ValueError("'messages' must contain at least one message")
            if not any(
                message.role != "system" for message in self.messages
            ):
                raise ValueError(
                    "'messages' must contain at least one user or assistant message"
                )
        return self


# ----------------------------------------------------------------------
# Prompt management
# ----------------------------------------------------------------------
class CreatePromptRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(
        ...,
        pattern=r"^[a-z0-9][a-z0-9_-]{0,63}$",
        description="Lower-case template name.",
    )
    template: str = Field(..., min_length=1)
    description: str = ""


class AddPromptVersionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    template: str = Field(..., min_length=1)
    description: str = ""


class RenderPromptRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: int | Literal["latest"] = "latest"
    variables: dict[str, Any] = Field(default_factory=dict)


# ----------------------------------------------------------------------
# Discovery / health
# ----------------------------------------------------------------------
class ModelInfo(BaseModel):
    id: str
    object: str = "model"
    name: str
    provider: str
    protocol: str
    upstream_model: str
    description: str
    context_window: int
    max_output_tokens: int


class ModelListResponse(BaseModel):
    object: str = "list"
    models: list[ModelInfo]
    total: int
    default: str


class HealthResponse(BaseModel):
    status: Literal["healthy", "degraded"]
    version: str
    environment: str
    models_available: int
    api_key_configured: bool
    uptime_seconds: int
