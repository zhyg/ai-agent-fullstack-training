# app/adapters/base.py
"""Common adapter contract and protocol-independent data structures.

Adapters are responsible for exactly three things:

1. translating the unified request into the upstream wire format,
2. translating the upstream response/SSE stream back into ``AdapterResponse``
   or ``StreamEvent`` objects, and
3. translating upstream failures into :class:`UpstreamError`.

Routing, retries, rate limits, prompt rendering, structured-output validation
and metrics all live above this layer.
"""
from __future__ import annotations

import json
import math
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, Literal

import httpx

from app.config import Settings
from app.core.errors import ErrorCode, UpstreamError
from app.core.model_catalog import ModelSpec, Protocol


@dataclass(frozen=True)
class AdapterMessage:
    role: Literal["system", "user", "assistant"]
    content: str


@dataclass(frozen=True)
class StructuredFormat:
    kind: Literal["json_object", "json_schema"]
    name: str = "response"
    schema: dict[str, Any] | None = None
    strict: bool = True


@dataclass(frozen=True)
class AdapterRequest:
    messages: list[AdapterMessage]
    temperature: float
    max_tokens: int
    response_format: StructuredFormat | None = None
    include_reasoning: bool = False


@dataclass
class Usage:
    """Token usage normalized across both protocols.

    ``input_tokens`` always includes cached input, so
    ``total_tokens == input_tokens + output_tokens``. ``cached_input_tokens``
    and ``reasoning_tokens`` are *subsets* of those totals and are reported
    separately for cost analysis. Providers that do not report a category
    leave it at zero.
    """

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    reasoning_tokens: int = 0
    cached_input_tokens: int = 0
    cache_creation_input_tokens: int = 0

    def finalize(self) -> "Usage":
        self.input_tokens = max(0, int(self.input_tokens))
        self.output_tokens = max(0, int(self.output_tokens))
        self.reasoning_tokens = max(0, int(self.reasoning_tokens))
        self.cached_input_tokens = max(0, int(self.cached_input_tokens))
        self.cache_creation_input_tokens = max(
            0, int(self.cache_creation_input_tokens)
        )
        if not self.total_tokens:
            self.total_tokens = self.input_tokens + self.output_tokens
        return self

    def to_dict(self) -> dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "cached_input_tokens": self.cached_input_tokens,
            "cache_creation_input_tokens": self.cache_creation_input_tokens,
        }

    @classmethod
    def zero(cls) -> "Usage":
        return cls()


@dataclass
class AdapterResponse:
    id: str
    content: str
    finish_reason: str
    usage: Usage
    reasoning: str = ""
    upstream_finish_reason: str | None = None


@dataclass(frozen=True)
class StreamEvent:
    # start | text_delta | reasoning_delta | finish
    type: str
    data: dict[str, Any] = field(default_factory=dict)


class BaseAdapter(ABC):
    protocol: Protocol
    path: str

    def __init__(
        self,
        spec: ModelSpec,
        settings: Settings,
        *,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.spec = spec
        self.settings = settings
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(
            timeout=httpx.Timeout(
                settings.request_timeout,
                connect=settings.connect_timeout,
            ),
            limits=httpx.Limits(
                max_connections=20,
                max_keepalive_connections=10,
            ),
        )

    @property
    @abstractmethod
    def url(self) -> str: ...

    @abstractmethod
    def headers(self, *, stream: bool) -> dict[str, str]: ...

    @abstractmethod
    def payload(
        self,
        request: AdapterRequest,
        *,
        stream: bool,
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def complete(self, request: AdapterRequest) -> AdapterResponse: ...

    @abstractmethod
    def stream(
        self,
        request: AdapterRequest,
    ) -> AsyncIterator[StreamEvent]: ...

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------
    def _upstream_error(
        self,
        status_code: int,
        body: bytes | str,
        response_headers: httpx.Headers | dict[str, str] | None = None,
    ) -> UpstreamError:
        message = _extract_error_message(body)
        headers = response_headers or {}
        retry_after = _parse_retry_after(headers)
        details = {"upstream_protocol": self.protocol.value}

        if status_code in (401, 403):
            code = ErrorCode.UPSTREAM_AUTH_ERROR
            client_status = 502
            retryable = False
        elif status_code == 429:
            code = ErrorCode.UPSTREAM_RATE_LIMITED
            client_status = 429
            retryable = True
        elif status_code in (400, 422):
            code = ErrorCode.UPSTREAM_BAD_REQUEST
            client_status = 400
            retryable = False
        elif status_code == 404:
            code = ErrorCode.UPSTREAM_MODEL_NOT_FOUND
            client_status = 502
            retryable = False
        elif status_code == 408:
            code = ErrorCode.UPSTREAM_TIMEOUT
            client_status = 504
            retryable = True
        elif 500 <= status_code <= 599:
            code = ErrorCode.UPSTREAM_UNAVAILABLE
            client_status = 502
            retryable = True
        else:
            code = ErrorCode.UPSTREAM_BAD_RESPONSE
            client_status = 502
            retryable = False

        return UpstreamError(
            code,
            f"Upstream {self.protocol.value} returned {status_code}: {message}",
            status_code=client_status,
            retryable=retryable,
            upstream_status=status_code,
            retry_after=retry_after,
            details=details,
            headers=(
                {"Retry-After": str(max(1, math.ceil(retry_after)))}
                if retry_after is not None
                else None
            ),
        )

    def _transport_error(self, exc: Exception) -> UpstreamError:
        if isinstance(exc, httpx.TimeoutException):
            return UpstreamError(
                ErrorCode.UPSTREAM_TIMEOUT,
                f"Upstream {self.protocol.value} timed out: {exc}",
                status_code=504,
                retryable=True,
                details={"upstream_protocol": self.protocol.value},
            )
        return UpstreamError(
            ErrorCode.UPSTREAM_CONNECTION_ERROR,
            f"Could not reach upstream {self.protocol.value}: {exc}",
            status_code=502,
            retryable=True,
            details={"upstream_protocol": self.protocol.value},
        )


def _extract_error_message(body: bytes | str) -> str:
    if isinstance(body, bytes):
        text = body.decode("utf-8", errors="replace")
    else:
        text = body
    text = text.strip()
    if not text:
        return "empty error body"
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text[:500]
    if isinstance(data, dict):
        error = data.get("error")
        if isinstance(error, dict):
            message = error.get("message") or error.get("code")
            if message:
                return str(message)[:500]
        if isinstance(error, str):
            return error[:500]
        message = data.get("message")
        if message:
            return str(message)[:500]
    return text[:500]


def _parse_retry_after(headers: httpx.Headers | dict[str, str]) -> float | None:
    try:
        value = headers.get("Retry-After") or headers.get("retry-after")
    except AttributeError:
        value = None
    if not value:
        return None
    try:
        seconds = float(value)
        if math.isfinite(seconds):
            return max(0.0, seconds)
    except (TypeError, ValueError):
        pass
    try:
        retry_at = parsedate_to_datetime(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if retry_at.tzinfo is None:
        retry_at = retry_at.replace(tzinfo=timezone.utc)
    return max(0.0, (retry_at - datetime.now(timezone.utc)).total_seconds())


async def iter_sse_data(response: httpx.Response) -> AsyncIterator[str]:
    """Yield the payload of each ``data:`` line in an SSE response."""
    async for line in response.aiter_lines():
        if line.startswith("data:"):
            payload = line[5:].strip()
            if payload:
                yield payload
