# app/adapters/deepseek_adapter.py
"""DeepSeek model adapters.

Both models are served by DeepSeek, but through deliberately different
protocols:

* ``deepseek-v4-pro``  -> OpenAI Responses API
* ``deepseek-flash``   -> Anthropic Messages API

The two wire protocols are implemented in :mod:`app.adapters.openai_responses`
and :mod:`app.adapters.anthropic_messages`. This module binds each model id to
its protocol adapter and is the only place that constructs them.
"""
from __future__ import annotations

import httpx

from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.base import BaseAdapter
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.config import Settings
from app.core.model_catalog import ModelSpec, all_models


class DeepSeekV4ProAdapter(OpenAIResponsesAdapter):
    """DeepSeek V4 Pro over the OpenAI Responses API."""


class DeepSeekV4FlashAdapter(AnthropicMessagesAdapter):
    """DeepSeek V4 Flash over the Anthropic Messages API."""


_ADAPTER_CLASSES: dict[str, type[BaseAdapter]] = {
    "deepseek-v4-pro": DeepSeekV4ProAdapter,
    "deepseek-flash": DeepSeekV4FlashAdapter,
}


def build_adapters(
    settings: Settings,
    *,
    clients: dict[str, httpx.AsyncClient] | None = None,
) -> dict[str, BaseAdapter]:
    adapters: dict[str, BaseAdapter] = {}
    for spec in all_models():
        adapter_cls = _ADAPTER_CLASSES.get(spec.id)
        if adapter_cls is None:
            continue
        adapters[spec.id] = adapter_cls(
            spec,
            settings,
            client=(clients or {}).get(spec.id),
        )
    return adapters


def adapter_for(spec: ModelSpec, settings: Settings) -> BaseAdapter:
    adapter_cls = _ADAPTER_CLASSES[spec.id]
    return adapter_cls(spec, settings)


# Kept for callers that imported the old name during the migration.
DeepSeekChatAdapter = DeepSeekV4ProAdapter

__all__ = [
    "DeepSeekChatAdapter",
    "DeepSeekV4FlashAdapter",
    "DeepSeekV4ProAdapter",
    "adapter_for",
    "build_adapters",
]
