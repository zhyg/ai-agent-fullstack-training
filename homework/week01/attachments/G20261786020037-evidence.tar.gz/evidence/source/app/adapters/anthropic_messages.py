# app/adapters/anthropic_messages.py
"""Adapter for the Anthropic Messages API.

Wire-format highlights handled here:

* auth: ``x-api-key`` + ``anthropic-version`` (not a bearer token)
* system prompt is a top-level ``system`` string, not a message
* ``max_tokens`` is required; ``temperature`` is capped at 1.0
* content is an array of typed blocks (``thinking`` / ``text`` / ``tool_use``)
* structured output is expressed as a forced tool call. Thinking mode must be
  disabled for a forced ``tool_choice``, so the adapter opts out of thinking
  only when a response format is requested.
* streaming is a named SSE event stream (``content_block_delta`` ...)
"""
from __future__ import annotations

import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx

from app.adapters.base import (
    AdapterMessage,
    AdapterRequest,
    AdapterResponse,
    BaseAdapter,
    StreamEvent,
    Usage,
    iter_sse_data,
)
from app.core.errors import ErrorCode, UpstreamError
from app.core.model_catalog import Protocol

STRUCTURED_TOOL = "structured_output"


class AnthropicMessagesAdapter(BaseAdapter):
    protocol = Protocol.ANTHROPIC_MESSAGES
    path = "/v1/messages"

    @property
    def url(self) -> str:
        return f"{self.settings.anthropic_base_url}{self.path}"

    def headers(self, *, stream: bool) -> dict[str, str]:
        return {
            "x-api-key": self.settings.deepseek_api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
            "User-Agent": "unified-llm-gateway/1.0",
        }

    def payload(
        self,
        request: AdapterRequest,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        system = "\n\n".join(
            message.content
            for message in request.messages
            if message.role == "system"
        ).strip()
        messages = _merge_messages(
            [
                message
                for message in request.messages
                if message.role != "system"
            ]
        )
        payload: dict[str, Any] = {
            "model": self.spec.upstream_model,
            "max_tokens": request.max_tokens,
            "messages": messages,
            "temperature": min(1.0, max(0.0, request.temperature)),
        }
        if system:
            payload["system"] = system
        if request.response_format is not None:
            schema = request.response_format.schema or {
                "type": "object",
                "additionalProperties": True,
            }
            payload["tools"] = [
                {
                    "name": STRUCTURED_TOOL,
                    "description": (
                        "Return the final answer as a JSON value that conforms "
                        "to the input schema. Do not return any prose."
                    ),
                    "input_schema": schema,
                }
            ]
            payload["tool_choice"] = {
                "type": "tool",
                "name": STRUCTURED_TOOL,
            }
            # A forced tool_choice is rejected while thinking is enabled.
            payload["thinking"] = {"type": "disabled"}
        if stream:
            payload["stream"] = True
        return payload

    # ------------------------------------------------------------------
    # Non-streaming
    # ------------------------------------------------------------------
    async def complete(self, request: AdapterRequest) -> AdapterResponse:
        try:
            response = await self._client.post(
                self.url,
                headers=self.headers(stream=False),
                json=self.payload(request, stream=False),
            )
        except httpx.HTTPError as exc:
            raise self._transport_error(exc) from exc

        if response.status_code != 200:
            raise self._upstream_error(
                response.status_code,
                response.content,
                response.headers,
            )

        try:
            data = response.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise _bad_response("Anthropic API returned non-JSON content") from exc

        if not isinstance(data, dict):
            raise _bad_response("Anthropic API returned a non-object body")
        if data.get("type") == "error":
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"Anthropic API returned an error object: {_event_error(data)}",
                status_code=502,
                retryable=False,
                details={"upstream_protocol": self.protocol.value},
            )

        content, reasoning = _extract_blocks(
            data.get("content"),
            structured=request.response_format is not None,
        )
        usage = _parse_usage(data.get("usage"))
        finish_reason, raw_finish = _finish_reason(data.get("stop_reason"))
        return AdapterResponse(
            id=str(data.get("id") or f"msg_{uuid.uuid4().hex}"),
            content=content,
            reasoning=reasoning,
            finish_reason=finish_reason,
            upstream_finish_reason=raw_finish,
            usage=usage,
        )

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------
    async def stream(
        self,
        request: AdapterRequest,
    ) -> AsyncIterator[StreamEvent]:
        started = False
        response_id = f"msg_{uuid.uuid4().hex}"
        usage = Usage()
        finish_reason: str | None = None
        upstream_finish: str | None = None
        stop_reason: str | None = None
        blocks: dict[int, dict[str, Any]] = {}
        saw_message_stop = False
        structured = request.response_format is not None

        try:
            async with self._client.stream(
                "POST",
                self.url,
                headers=self.headers(stream=True),
                json=self.payload(request, stream=True),
            ) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise self._upstream_error(
                        response.status_code,
                        body,
                        response.headers,
                    )

                async for raw in iter_sse_data(response):
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError as exc:
                        raise _bad_response(
                            f"Invalid SSE JSON from Anthropic API: {raw[:200]}"
                        ) from exc

                    event_type = event.get("type")

                    if event_type == "message_start":
                        message = event.get("message") or {}
                        response_id = str(
                            message.get("id") or response_id
                        )
                        usage = _parse_usage(message.get("usage"))
                        if not started:
                            started = True
                            yield StreamEvent(
                                "start",
                                {"id": response_id, "model": self.spec.id},
                            )
                        continue

                    if not started:
                        started = True
                        yield StreamEvent(
                            "start",
                            {"id": response_id, "model": self.spec.id},
                        )

                    if event_type == "content_block_start":
                        index = int(event.get("index") or 0)
                        block = event.get("content_block") or {}
                        block_type = block.get("type")
                        blocks[index] = {
                            "type": block_type,
                            "json": "",
                            "initial": block.get("input"),
                        }
                        if block_type == "text" and block.get("text"):
                            yield StreamEvent(
                                "text_delta", {"delta": block["text"]}
                            )
                        elif block_type == "thinking" and block.get("thinking"):
                            yield StreamEvent(
                                "reasoning_delta",
                                {"delta": block["thinking"]},
                            )
                    elif event_type == "content_block_delta":
                        index = int(event.get("index") or 0)
                        delta = event.get("delta") or {}
                        delta_type = delta.get("type")
                        if delta_type == "text_delta":
                            text = delta.get("text") or ""
                            if text:
                                yield StreamEvent(
                                    "text_delta", {"delta": text}
                                )
                        elif delta_type == "thinking_delta":
                            thinking = delta.get("thinking") or ""
                            if thinking:
                                yield StreamEvent(
                                    "reasoning_delta",
                                    {"delta": thinking},
                                )
                        elif delta_type == "input_json_delta":
                            partial = delta.get("partial_json") or ""
                            if partial:
                                blocks.setdefault(
                                    index, {"type": "tool_use", "json": ""}
                                )["json"] += partial
                                # The concatenation is valid JSON at the end;
                                # forwarding it gives clients streaming JSON.
                                yield StreamEvent(
                                    "text_delta", {"delta": partial}
                                )
                    elif event_type == "content_block_stop":
                        index = int(event.get("index") or 0)
                        block = blocks.get(index) or {}
                        if (
                            block.get("type") == "tool_use"
                            and not block.get("json")
                            and block.get("initial")
                        ):
                            text = json.dumps(
                                block["initial"],
                                ensure_ascii=False,
                                separators=(",", ":"),
                            )
                            block["json"] = text
                            yield StreamEvent(
                                "text_delta", {"delta": text}
                            )
                    elif event_type == "message_delta":
                        delta = event.get("delta") or {}
                        stop_reason = delta.get("stop_reason") or stop_reason
                        _merge_usage(usage, event.get("usage"))
                    elif event_type == "message_stop":
                        saw_message_stop = True
                    elif event_type == "error":
                        raise UpstreamError(
                            ErrorCode.UPSTREAM_UNAVAILABLE,
                            f"Anthropic API stream error: {_event_error(event)}",
                            status_code=502,
                            retryable=False,
                            details={"upstream_protocol": self.protocol.value},
                        )

        except httpx.HTTPError as exc:
            raise self._transport_error(exc) from exc

        if not started:
            yield StreamEvent(
                "start",
                {"id": response_id, "model": self.spec.id},
            )
        if not saw_message_stop:
            raise UpstreamError(
                ErrorCode.UPSTREAM_STREAM_INTERRUPTED,
                "Anthropic API stream ended before message_stop",
                status_code=502,
                retryable=True,
                details={"upstream_protocol": self.protocol.value},
            )

        finish_reason, upstream_finish = _finish_reason(
            stop_reason or ("tool_use" if structured else "end_turn")
        )
        yield StreamEvent(
            "finish",
            {
                "id": response_id,
                "finish_reason": finish_reason,
                "upstream_finish_reason": upstream_finish,
                "usage": usage.finalize(),
            },
        )


def _merge_messages(messages: list[AdapterMessage]) -> list[dict[str, str]]:
    """Anthropic expects alternating roles; merge adjacent equal roles."""
    merged: list[dict[str, str]] = []
    for message in messages:
        if merged and merged[-1]["role"] == message.role:
            merged[-1]["content"] += "\n\n" + message.content
        else:
            merged.append({"role": message.role, "content": message.content})
    return merged


def _extract_blocks(content: Any, *, structured: bool) -> tuple[str, str]:
    if not isinstance(content, list) or not content:
        raise _bad_response("Anthropic API response contained no content blocks")
    text_parts: list[str] = []
    thinking_parts: list[str] = []
    tool_input: Any = None
    for block in content:
        if not isinstance(block, dict):
            continue
        block_type = block.get("type")
        if block_type == "text":
            text_parts.append(str(block.get("text") or ""))
        elif block_type == "thinking":
            thinking_parts.append(str(block.get("thinking") or ""))
        elif block_type == "tool_use" and block.get("name") == STRUCTURED_TOOL:
            tool_input = block.get("input")
    if structured and tool_input is not None:
        if isinstance(tool_input, str):
            content_text = tool_input
        else:
            content_text = json.dumps(
                tool_input,
                ensure_ascii=False,
                separators=(",", ":"),
            )
    else:
        content_text = "".join(text_parts)
    return content_text, "".join(thinking_parts)


def _parse_usage(raw: Any) -> Usage:
    if not isinstance(raw, dict):
        return Usage.zero()
    raw_input = int(raw.get("input_tokens") or 0)
    cache_creation = int(raw.get("cache_creation_input_tokens") or 0)
    cache_read = int(raw.get("cache_read_input_tokens") or 0)
    # Anthropic reports non-cached input separately; normalize to total input.
    total_input = raw_input + cache_creation + cache_read
    output = int(raw.get("output_tokens") or 0)
    return Usage(
        input_tokens=total_input,
        output_tokens=output,
        total_tokens=total_input + output,
        reasoning_tokens=0,
        cached_input_tokens=cache_read,
        cache_creation_input_tokens=cache_creation,
    ).finalize()


def _merge_usage(current: Usage, raw: Any) -> None:
    if not isinstance(raw, dict):
        return
    parsed = _parse_usage(raw)
    if parsed.input_tokens:
        current.input_tokens = parsed.input_tokens
        current.cached_input_tokens = parsed.cached_input_tokens
        current.cache_creation_input_tokens = (
            parsed.cache_creation_input_tokens
        )
    if parsed.output_tokens:
        current.output_tokens = parsed.output_tokens
    current.total_tokens = 0
    current.finalize()


_STOP_REASONS = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_use",
    "refusal": "content_filter",
    "pause_turn": "stop",
}


def _finish_reason(raw: Any) -> tuple[str, str | None]:
    if raw is None:
        return "stop", None
    value = str(raw)
    return _STOP_REASONS.get(value, "stop"), value


def _event_error(event: dict[str, Any]) -> str:
    error = event.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("type") or "unknown error")
    if error:
        return str(error)
    return str(event.get("message") or "unknown error")


def _bad_response(message: str) -> UpstreamError:
    return UpstreamError(
        ErrorCode.UPSTREAM_BAD_RESPONSE,
        message,
        status_code=502,
        retryable=False,
        details={"upstream_protocol": Protocol.ANTHROPIC_MESSAGES.value},
    )
