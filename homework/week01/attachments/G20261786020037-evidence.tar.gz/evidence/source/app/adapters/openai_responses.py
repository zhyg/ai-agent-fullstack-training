# app/adapters/openai_responses.py
"""Adapter for the OpenAI Responses API.

Wire-format highlights handled here:

* auth: ``Authorization: Bearer ...``
* system messages become top-level ``instructions``
* ``input`` is an array of role/content items
* output text lives in ``output[].content[].text`` where the item type is
  ``message`` and the part type is ``output_text``
* usage is nested (``input_tokens_details.cached_tokens``,
  ``output_tokens_details.reasoning_tokens``)
* structured output uses ``text.format``
* streaming is a typed SSE event stream (``response.output_text.delta`` ...)
"""
from __future__ import annotations

import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx

from app.adapters.base import (
    AdapterRequest,
    AdapterResponse,
    BaseAdapter,
    StreamEvent,
    Usage,
    iter_sse_data,
)
from app.core.errors import ErrorCode, UpstreamError
from app.core.model_catalog import Protocol


class OpenAIResponsesAdapter(BaseAdapter):
    protocol = Protocol.OPENAI_RESPONSES
    path = "/responses"

    @property
    def url(self) -> str:
        return f"{self.settings.responses_base_url}{self.path}"

    def headers(self, *, stream: bool) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.settings.deepseek_api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
            "User-Agent": "unified-llm-gateway/1.0",
        }

    def payload(
        self,
        request: AdapterRequest,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        system = "\n\n".join(
            message.content
            for message in request.messages
            if message.role == "system"
        ).strip()
        input_items = [
            {"role": message.role, "content": message.content}
            for message in request.messages
            if message.role != "system"
        ]
        payload: dict[str, Any] = {
            "model": self.spec.upstream_model,
            "input": input_items,
            "max_output_tokens": request.max_tokens,
            "temperature": request.temperature,
            "store": False,
        }
        if system:
            payload["instructions"] = system
        if request.response_format is not None:
            payload["text"] = {
                "format": _format_payload(request.response_format)
            }
        if stream:
            payload["stream"] = True
        return payload

    # ------------------------------------------------------------------
    # Non-streaming
    # ------------------------------------------------------------------
    async def complete(self, request: AdapterRequest) -> AdapterResponse:
        try:
            response = await self._client.post(
                self.url,
                headers=self.headers(stream=False),
                json=self.payload(request, stream=False),
            )
        except httpx.HTTPError as exc:
            raise self._transport_error(exc) from exc

        if response.status_code != 200:
            raise self._upstream_error(
                response.status_code,
                response.content,
                response.headers,
            )

        try:
            data = response.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise _bad_response("Responses API returned non-JSON content") from exc

        return self._parse_response(data)

    def _parse_response(self, data: Any) -> AdapterResponse:
        if not isinstance(data, dict):
            raise _bad_response("Responses API returned a non-object body")
        status = data.get("status")
        if status == "failed":
            error = data.get("error") or {}
            message = error.get("message") if isinstance(error, dict) else str(error)
            raise UpstreamError(
                ErrorCode.UPSTREAM_UNAVAILABLE,
                f"Responses API reported a failed response: {message or 'unknown error'}",
                status_code=502,
                retryable=False,
                details={"upstream_protocol": self.protocol.value},
            )

        content, reasoning, saw_message = _extract_output(data.get("output"))
        if not saw_message:
            raise _bad_response("Responses API response contained no message item")

        usage = _parse_usage(data.get("usage"))
        finish_reason, upstream_finish = _finish_reason(data)
        return AdapterResponse(
            id=str(data.get("id") or f"resp_{uuid.uuid4().hex}"),
            content=content,
            reasoning=reasoning,
            finish_reason=finish_reason,
            upstream_finish_reason=upstream_finish,
            usage=usage,
        )

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------
    async def stream(
        self,
        request: AdapterRequest,
    ) -> AsyncIterator[StreamEvent]:
        started = False
        response_id = f"resp_{uuid.uuid4().hex}"
        usage = Usage()
        finish_reason: str | None = None
        upstream_finish: str | None = None

        try:
            async with self._client.stream(
                "POST",
                self.url,
                headers=self.headers(stream=True),
                json=self.payload(request, stream=True),
            ) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise self._upstream_error(
                        response.status_code,
                        body,
                        response.headers,
                    )

                async for raw in iter_sse_data(response):
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError as exc:
                        raise _bad_response(
                            f"Invalid SSE JSON from Responses API: {raw[:200]}"
                        ) from exc

                    event_type = event.get("type")
                    if event_type == "response.created":
                        response_data = event.get("response") or {}
                        response_id = str(
                            response_data.get("id") or response_id
                        )
                        if not started:
                            started = True
                            yield StreamEvent(
                                "start",
                                {"id": response_id, "model": self.spec.id},
                            )
                        continue

                    if not started:
                        started = True
                        yield StreamEvent(
                            "start",
                            {"id": response_id, "model": self.spec.id},
                        )

                    if event_type in (
                        "response.reasoning_text.delta",
                        "response.reasoning_summary_text.delta",
                    ):
                        delta = event.get("delta") or ""
                        if delta:
                            yield StreamEvent(
                                "reasoning_delta", {"delta": delta}
                            )
                    elif event_type == "response.output_text.delta":
                        delta = event.get("delta") or ""
                        if delta:
                            yield StreamEvent("text_delta", {"delta": delta})
                    elif event_type in ("response.completed", "response.incomplete"):
                        response_data = event.get("response") or {}
                        response_id = str(
                            response_data.get("id") or response_id
                        )
                        usage = _parse_usage(response_data.get("usage"))
                        finish_reason, upstream_finish = _finish_reason(
                            response_data
                        )
                    elif event_type == "response.failed":
                        response_data = event.get("response") or {}
                        error = response_data.get("error") or {}
                        message = (
                            error.get("message")
                            if isinstance(error, dict)
                            else str(error)
                        )
                        raise UpstreamError(
                            ErrorCode.UPSTREAM_UNAVAILABLE,
                            f"Responses API stream failed: {message or 'unknown error'}",
                            status_code=502,
                            retryable=False,
                            details={
                                "upstream_protocol": self.protocol.value
                            },
                        )
                    elif event_type == "error":
                        raise UpstreamError(
                            ErrorCode.UPSTREAM_UNAVAILABLE,
                            f"Responses API stream error: {_event_error(event)}",
                            status_code=502,
                            retryable=False,
                            details={"upstream_protocol": self.protocol.value},
                        )

        except httpx.HTTPError as exc:
            raise self._transport_error(exc) from exc

        if not started:
            yield StreamEvent(
                "start",
                {"id": response_id, "model": self.spec.id},
            )
        if finish_reason is None:
            raise UpstreamError(
                ErrorCode.UPSTREAM_STREAM_INTERRUPTED,
                "Responses API stream ended before a completed/incomplete event",
                status_code=502,
                retryable=True,
                details={"upstream_protocol": self.protocol.value},
            )

        yield StreamEvent(
            "finish",
            {
                "id": response_id,
                "finish_reason": finish_reason,
                "upstream_finish_reason": upstream_finish,
                "usage": usage.finalize(),
            },
        )


def _format_payload(fmt) -> dict[str, Any]:
    if fmt.kind == "json_object":
        return {"type": "json_object"}
    return {
        "type": "json_schema",
        "name": fmt.name,
        "schema": fmt.schema,
        "strict": fmt.strict,
    }


def _extract_output(
    output: Any,
) -> tuple[str, str, bool]:
    content_parts: list[str] = []
    reasoning_parts: list[str] = []
    saw_message = False
    if not isinstance(output, list):
        return "", "", False
    for item in output:
        if not isinstance(item, dict):
            continue
        item_type = item.get("type")
        if item_type == "message":
            saw_message = True
            for part in item.get("content") or []:
                if not isinstance(part, dict):
                    continue
                if part.get("type") == "output_text":
                    content_parts.append(str(part.get("text") or ""))
                elif part.get("type") == "refusal":
                    content_parts.append(str(part.get("refusal") or ""))
        elif item_type == "reasoning":
            for part in item.get("content") or []:
                if (
                    isinstance(part, dict)
                    and part.get("type") == "reasoning_text"
                ):
                    reasoning_parts.append(str(part.get("text") or ""))
            for part in item.get("summary") or []:
                if (
                    isinstance(part, dict)
                    and part.get("type") == "summary_text"
                ):
                    reasoning_parts.append(str(part.get("text") or ""))
    return "".join(content_parts), "".join(reasoning_parts), saw_message


def _parse_usage(raw: Any) -> Usage:
    if not isinstance(raw, dict):
        return Usage.zero()
    input_details = raw.get("input_tokens_details") or {}
    output_details = raw.get("output_tokens_details") or {}
    return Usage(
        input_tokens=int(raw.get("input_tokens") or 0),
        output_tokens=int(raw.get("output_tokens") or 0),
        total_tokens=int(raw.get("total_tokens") or 0),
        reasoning_tokens=int(output_details.get("reasoning_tokens") or 0),
        cached_input_tokens=int(input_details.get("cached_tokens") or 0),
    ).finalize()


def _finish_reason(data: dict[str, Any]) -> tuple[str, str | None]:
    status = data.get("status")
    if status == "incomplete":
        incomplete = data.get("incomplete_details") or {}
        reason = str(incomplete.get("reason") or "incomplete")
        if reason == "max_output_tokens":
            return "length", reason
        return "content_filter", reason
    return "stop", status


def _event_error(event: dict[str, Any]) -> str:
    error = event.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("code") or "unknown error")
    if error:
        return str(error)
    return str(event.get("message") or "unknown error")


def _bad_response(message: str) -> UpstreamError:
    return UpstreamError(
        ErrorCode.UPSTREAM_BAD_RESPONSE,
        message,
        status_code=502,
        retryable=False,
        details={"upstream_protocol": Protocol.OPENAI_RESPONSES.value},
    )
