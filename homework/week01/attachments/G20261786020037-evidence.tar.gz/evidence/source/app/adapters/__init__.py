"""Protocol adapters for the upstream LLM APIs."""
