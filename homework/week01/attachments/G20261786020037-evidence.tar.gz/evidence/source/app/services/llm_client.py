# app/services/llm_client.py
"""Unified LLM service: routing, prompts, structured output, retries, limits.

The HTTP layer only talks to this class. The class owns the model -> adapter
routing table, retry policy, per-model rate limiter, response normalization and
metrics recording. Neither routers nor adapters know about each other's
protocol details.
"""
from __future__ import annotations

import asyncio
import random
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any, Callable

import structlog

from app.adapters.base import (
    AdapterMessage,
    AdapterRequest,
    BaseAdapter,
    StructuredFormat,
    Usage,
)
from app.adapters.deepseek_adapter import build_adapters
from app.config import Settings
from app.core.errors import ErrorCode, ServiceError, UpstreamError
from app.core.model_catalog import ModelSpec, all_models, resolve_model
from app.core.rate_limit import ModelRateLimiter, RateLimitDecision
from app.core.sse import SseEvent
from app.models.schemas import ChatRequest
from app.prompts.registry import PromptRegistry
from app.services.metrics import CallRecord, MetricsStore
from app.services.structured import normalize_response_format, parse_and_validate

logger = structlog.get_logger()

_DEBUG_STATUSES = {429, 500, 502, 503, 504}


@dataclass
class PreparedCall:
    """Everything needed to execute one call, validated before streaming starts."""

    request_id: str
    requested_model: str
    spec: ModelSpec
    adapter: BaseAdapter
    adapter_request: AdapterRequest
    response_format: StructuredFormat | None
    prompt_ref: dict[str, Any] | None
    stream: bool
    rate_decision: RateLimitDecision
    started_at: float
    debug_fail_times: int = 0
    debug_fail_status: int = 503


class LLMService:
    def __init__(
        self,
        settings: Settings,
        prompts: PromptRegistry,
        metrics: MetricsStore,
        *,
        adapters: dict[str, BaseAdapter] | None = None,
        limiter: ModelRateLimiter | None = None,
        sleep: Callable[[float], Any] | None = None,
    ) -> None:
        self.settings = settings
        self.prompts = prompts
        self.metrics = metrics
        self._adapters = adapters or build_adapters(settings)
        self._limiter = limiter or ModelRateLimiter.from_settings(settings)
        self._sleep = sleep or asyncio.sleep
        self._closed = False

    # ------------------------------------------------------------------
    # Preparation
    # ------------------------------------------------------------------
    async def prepare(
        self,
        request: ChatRequest,
        *,
        request_id: str | None = None,
        debug_fail_times: int = 0,
        debug_fail_status: int = 503,
    ) -> PreparedCall:
        request_id = request_id or f"req_{uuid.uuid4().hex}"
        spec = resolve_model(request.model)
        if spec is None:
            raise ServiceError(
                ErrorCode.MODEL_NOT_FOUND,
                f"Unknown model {request.model!r}",
                status_code=404,
                details={
                    "model": request.model,
                    "available_models": [model.id for model in all_models()],
                },
            )
        if not self.settings.api_key_configured:
            raise ServiceError(
                ErrorCode.MODEL_NOT_CONFIGURED,
                "DEEPSEEK_API_KEY is not configured",
                status_code=503,
                details={"model": spec.id},
            )
        adapter = self._adapters.get(spec.id)
        if adapter is None:
            raise ServiceError(
                ErrorCode.MODEL_NOT_CONFIGURED,
                f"No adapter is registered for model {spec.id!r}",
                status_code=503,
            )

        messages, prompt_ref = self._resolve_messages(request)
        structured = normalize_response_format(request.response_format)
        max_tokens = min(
            request.max_tokens,
            self.settings.max_tokens_limit,
            spec.max_output_tokens,
        )
        adapter_request = AdapterRequest(
            messages=messages,
            temperature=request.temperature,
            max_tokens=max_tokens,
            response_format=structured,
            include_reasoning=request.include_reasoning,
        )

        started_at = time.perf_counter()
        try:
            decision = self._limiter.enforce(spec.id)
        except ServiceError as exc:
            self._record_rejected(
                request_id=request_id,
                spec=spec,
                request=request,
                prompt_ref=prompt_ref,
                structured=structured,
                started_at=started_at,
                exc=exc,
            )
            raise

        if not self.settings.enable_debug_faults:
            debug_fail_times = 0
        debug_fail_times = max(0, min(int(debug_fail_times), 10))
        if debug_fail_status not in _DEBUG_STATUSES:
            debug_fail_status = 503

        return PreparedCall(
            request_id=request_id,
            requested_model=request.model,
            spec=spec,
            adapter=adapter,
            adapter_request=adapter_request,
            response_format=structured,
            prompt_ref=prompt_ref,
            stream=request.stream,
            rate_decision=decision,
            started_at=started_at,
            debug_fail_times=debug_fail_times,
            debug_fail_status=debug_fail_status,
        )

    def _resolve_messages(
        self,
        request: ChatRequest,
    ) -> tuple[list[AdapterMessage], dict[str, Any] | None]:
        if request.prompt is not None:
            rendered = self.prompts.render(
                request.prompt.name,
                request.prompt.version,
                request.prompt.variables,
            )
            return (
                [AdapterMessage(role="user", content=rendered.text)],
                rendered.reference(),
            )
        assert request.messages is not None
        return (
            [
                AdapterMessage(role=message.role, content=message.content)
                for message in request.messages
            ],
            None,
        )

    # ------------------------------------------------------------------
    # Non-streaming execution
    # ------------------------------------------------------------------
    async def complete(self, prepared: PreparedCall) -> dict[str, Any]:
        attempts: list[dict[str, Any]] = []
        retry_count = 0
        response = None

        for attempt_index in range(self.settings.llm_max_retries + 1):
            attempt = {"attempt": attempt_index + 1}
            attempt_start = time.perf_counter()
            try:
                if prepared.debug_fail_times > 0:
                    prepared.debug_fail_times -= 1
                    raise self._injected_error(prepared.debug_fail_status)
                response = await prepared.adapter.complete(
                    prepared.adapter_request
                )
                attempt.update(
                    outcome="success",
                    duration_ms=_elapsed_ms(attempt_start),
                )
                attempts.append(attempt)
                break
            except ServiceError as exc:
                attempt.update(
                    outcome="error",
                    error_code=exc.code.value,
                    duration_ms=_elapsed_ms(attempt_start),
                )
                if exc.upstream_status is not None:
                    attempt["upstream_status"] = exc.upstream_status
                attempts.append(attempt)
                if (
                    not exc.retryable
                    or attempt_index >= self.settings.llm_max_retries
                ):
                    exc.details.setdefault("retry_count", retry_count)
                    exc.details.setdefault("attempts", attempts)
                    self._record_failure(
                        prepared=prepared,
                        exc=exc,
                        attempts=attempts,
                        retry_count=retry_count,
                        started_at=prepared.started_at,
                        http_status=exc.status_code,
                    )
                    raise
                delay = self._retry_delay(exc, attempt_index)
                attempt["backoff_ms"] = round(delay * 1000, 2)
                retry_count += 1
                logger.warning(
                    "llm.retry",
                    request_id=prepared.request_id,
                    model=prepared.spec.id,
                    attempt=attempt_index + 1,
                    max_retries=self.settings.llm_max_retries,
                    delay_ms=attempt["backoff_ms"],
                    error_code=exc.code.value,
                )
                await self._sleep(delay)
            except Exception as exc:  # pragma: no cover - defensive
                logger.exception(
                    "llm.unexpected_error",
                    request_id=prepared.request_id,
                    model=prepared.spec.id,
                )
                error = ServiceError(
                    ErrorCode.INTERNAL_ERROR,
                    "Unexpected gateway error",
                    status_code=500,
                    details={"exception": type(exc).__name__},
                )
                self._record_failure(
                    prepared=prepared,
                    exc=error,
                    attempts=attempts,
                    retry_count=retry_count,
                    started_at=prepared.started_at,
                    http_status=500,
                )
                raise error from exc

        if response is None:  # pragma: no cover - loop always returns/raises
            raise ServiceError(
                ErrorCode.INTERNAL_ERROR,
                "No response produced",
                status_code=500,
            )

        parsed: Any = None
        finish_reason = response.finish_reason
        try:
            if prepared.response_format is not None:
                parsed = parse_and_validate(
                    response.content,
                    prepared.response_format,
                )
                if finish_reason == "tool_use":
                    finish_reason = "stop"
        except ServiceError as exc:
            attempts[-1]["structured_validation"] = "failed"
            attempts[-1]["error_code"] = exc.code.value
            exc.details.setdefault("retry_count", retry_count)
            exc.details.setdefault("attempts", attempts)
            self._record_failure(
                prepared=prepared,
                exc=exc,
                attempts=attempts,
                retry_count=retry_count,
                started_at=prepared.started_at,
                http_status=exc.status_code,
                usage=response.usage,
            )
            raise

        total_ms = _elapsed_ms(prepared.started_at)
        result = self._response_payload(
            prepared=prepared,
            response=response,
            parsed=parsed,
            finish_reason=finish_reason,
            total_ms=total_ms,
            ttft_ms=None,
            first_text_ms=None,
            retry_count=retry_count,
            attempts=attempts,
        )
        self.metrics.record(
            CallRecord(
                request_id=prepared.request_id,
                model=prepared.spec.id,
                upstream_model=prepared.spec.upstream_model,
                protocol=prepared.spec.protocol.value,
                stream=False,
                status="success",
                http_status=200,
                usage=response.usage.to_dict(),
                latency={"total_ms": total_ms, "ttft_ms": None},
                retry_count=retry_count,
                attempts=attempts,
                prompt=prepared.prompt_ref,
                structured=prepared.response_format is not None,
                finish_reason=finish_reason,
                response_id=response.id,
            )
        )
        logger.info(
            "llm.completed",
            request_id=prepared.request_id,
            model=prepared.spec.id,
            protocol=prepared.spec.protocol.value,
            total_ms=total_ms,
            retry_count=retry_count,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
        )
        return result

    # ------------------------------------------------------------------
    # Streaming execution
    # ------------------------------------------------------------------
    async def stream(self, prepared: PreparedCall) -> AsyncIterator[SseEvent]:
        attempts: list[dict[str, Any]] = []
        retry_count = 0
        usage = Usage.zero()
        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        finish_reason: str | None = None
        upstream_finish: str | None = None
        upstream_id: str | None = None
        parsed: Any = None
        stream_started = False
        first_content_at: float | None = None
        first_text_at: float | None = None
        status = "error"
        error: ServiceError | None = None

        try:
            for attempt_index in range(self.settings.llm_max_retries + 1):
                attempt = {"attempt": attempt_index + 1}
                attempt_start = time.perf_counter()
                adapter_stream = None
                try:
                    if prepared.debug_fail_times > 0:
                        prepared.debug_fail_times -= 1
                        raise self._injected_error(prepared.debug_fail_status)

                    adapter_stream = prepared.adapter.stream(
                        prepared.adapter_request
                    )
                    async for event in adapter_stream:
                        now = time.perf_counter()
                        if event.type == "start":
                            upstream_id = str(
                                event.data.get("id") or upstream_id or ""
                            ) or None
                            if not stream_started:
                                stream_started = True
                                yield SseEvent(
                                    "start",
                                    self._start_payload(
                                        prepared,
                                        upstream_id,
                                    ),
                                )
                        elif event.type == "text_delta":
                            if first_content_at is None:
                                first_content_at = now
                            if first_text_at is None:
                                first_text_at = now
                            delta = str(event.data.get("delta") or "")
                            content_parts.append(delta)
                            if delta:
                                yield SseEvent("delta", {"delta": delta})
                        elif event.type == "reasoning_delta":
                            if first_content_at is None:
                                first_content_at = now
                            delta = str(event.data.get("delta") or "")
                            reasoning_parts.append(delta)
                            if delta and prepared.adapter_request.include_reasoning:
                                yield SseEvent(
                                    "reasoning",
                                    {"delta": delta},
                                )
                        elif event.type == "finish":
                            usage = event.data.get("usage") or Usage.zero()
                            if not isinstance(usage, Usage):
                                usage = Usage.zero()
                            finish_reason = str(
                                event.data.get("finish_reason") or "stop"
                            )
                            upstream_finish = event.data.get(
                                "upstream_finish_reason"
                            )
                            upstream_id = str(
                                event.data.get("id") or upstream_id or ""
                            ) or None
                    attempt.update(
                        outcome="success",
                        duration_ms=_elapsed_ms(attempt_start),
                    )
                    attempts.append(attempt)
                    break
                except ServiceError as exc:
                    attempt.update(
                        outcome="error",
                        error_code=exc.code.value,
                        duration_ms=_elapsed_ms(attempt_start),
                    )
                    if exc.upstream_status is not None:
                        attempt["upstream_status"] = exc.upstream_status
                    attempts.append(attempt)
                    can_retry = (
                        exc.retryable
                        and attempt_index < self.settings.llm_max_retries
                        and not stream_started
                    )
                    if not can_retry:
                        raise
                    delay = self._retry_delay(exc, attempt_index)
                    attempt["backoff_ms"] = round(delay * 1000, 2)
                    retry_count += 1
                    logger.warning(
                        "llm.retry",
                        request_id=prepared.request_id,
                        model=prepared.spec.id,
                        attempt=attempt_index + 1,
                        max_retries=self.settings.llm_max_retries,
                        delay_ms=attempt["backoff_ms"],
                        error_code=exc.code.value,
                        stream=True,
                    )
                    content_parts.clear()
                    reasoning_parts.clear()
                    usage = Usage.zero()
                    finish_reason = None
                    upstream_finish = None
                    upstream_id = None
                    first_content_at = None
                    first_text_at = None
                    await self._sleep(delay)
                finally:
                    if adapter_stream is not None:
                        await adapter_stream.aclose()

            if finish_reason is None:
                raise UpstreamError(
                    ErrorCode.UPSTREAM_STREAM_INTERRUPTED,
                    "Upstream stream ended without a finish event",
                    status_code=502,
                    retryable=False,
                )

            if not stream_started:
                stream_started = True
                yield SseEvent(
                    "start",
                    self._start_payload(prepared, upstream_id),
                )

            if prepared.response_format is not None:
                parsed = parse_and_validate(
                    "".join(content_parts),
                    prepared.response_format,
                )
                if finish_reason == "tool_use":
                    finish_reason = "stop"

            total_ms = _elapsed_ms(prepared.started_at)
            ttft_ms = (
                _elapsed_ms(prepared.started_at, first_content_at)
                if first_content_at is not None
                else None
            )
            first_text_ms = (
                _elapsed_ms(prepared.started_at, first_text_at)
                if first_text_at is not None
                else None
            )
            latency = {
                "total_ms": total_ms,
                "ttft_ms": ttft_ms,
                "first_text_ms": first_text_ms,
            }
            yield SseEvent(
                "usage",
                {
                    "usage": usage.to_dict(),
                    "ttft_ms": ttft_ms,
                    "retry_count": retry_count,
                },
            )
            status = "success"
            yield SseEvent(
                "done",
                self._stream_done_payload(
                    prepared=prepared,
                    upstream_id=upstream_id,
                    finish_reason=finish_reason,
                    upstream_finish=upstream_finish,
                    usage=usage,
                    parsed=parsed,
                    reasoning="".join(reasoning_parts),
                    latency=latency,
                    retry_count=retry_count,
                    attempts=attempts,
                ),
            )
        except asyncio.CancelledError:
            status = "cancelled"
            logger.info(
                "llm.stream_cancelled",
                request_id=prepared.request_id,
                model=prepared.spec.id,
            )
            raise
        except GeneratorExit:
            status = "cancelled"
            raise
        except ServiceError as exc:
            error = exc
            exc.details.setdefault("retry_count", retry_count)
            exc.details.setdefault("attempts", attempts)
            logger.error(
                "llm.stream_failed",
                request_id=prepared.request_id,
                model=prepared.spec.id,
                error_code=exc.code.value,
                error=exc.message,
            )
            yield SseEvent("error", exc.to_payload(prepared.request_id))
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception(
                "llm.stream_unexpected_error",
                request_id=prepared.request_id,
                model=prepared.spec.id,
            )
            error = ServiceError(
                ErrorCode.INTERNAL_ERROR,
                "Unexpected gateway error",
                status_code=500,
                details={"exception": type(exc).__name__},
            )
            yield SseEvent("error", error.to_payload(prepared.request_id))
        finally:
            total_ms = _elapsed_ms(prepared.started_at)
            ttft_ms = (
                _elapsed_ms(prepared.started_at, first_content_at)
                if first_content_at is not None
                else None
            )
            first_text_ms = (
                _elapsed_ms(prepared.started_at, first_text_at)
                if first_text_at is not None
                else None
            )
            # The HTTP response has already been committed as 200 when a
            # streaming generator runs; protocol errors travel as SSE events.
            self.metrics.record(
                CallRecord(
                    request_id=prepared.request_id,
                    model=prepared.spec.id,
                    upstream_model=prepared.spec.upstream_model,
                    protocol=prepared.spec.protocol.value,
                    stream=True,
                    status=status,
                    http_status=200,
                    usage=usage.to_dict(),
                    latency={
                        "total_ms": total_ms,
                        "ttft_ms": ttft_ms,
                        "first_text_ms": first_text_ms,
                    },
                    retry_count=retry_count,
                    attempts=attempts,
                    prompt=prepared.prompt_ref,
                    structured=prepared.response_format is not None,
                    error_code=error.code.value if error is not None else None,
                    error_message=error.message[:300] if error is not None else None,
                    finish_reason=finish_reason,
                    response_id=upstream_id,
                )
            )

    # ------------------------------------------------------------------
    # Payload builders
    # ------------------------------------------------------------------
    def _response_payload(
        self,
        *,
        prepared: PreparedCall,
        response,
        parsed: Any,
        finish_reason: str,
        total_ms: float,
        ttft_ms: float | None,
        first_text_ms: float | None,
        retry_count: int,
        attempts: list[dict[str, Any]],
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": response.id,
            "object": "chat.completion",
            "created": int(time.time()),
            "model": prepared.spec.id,
            "requested_model": prepared.requested_model,
            "protocol": prepared.spec.protocol.value,
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": response.content,
                    },
                    "finish_reason": finish_reason,
                }
            ],
            "usage": response.usage.to_dict(),
            "latency": {
                "total_ms": total_ms,
                "ttft_ms": ttft_ms,
                "first_text_ms": first_text_ms,
            },
            "retry_count": retry_count,
            "attempts": attempts,
            "request_id": prepared.request_id,
            "prompt": prepared.prompt_ref,
            "structured": prepared.response_format is not None,
        }
        if prepared.response_format is not None:
            payload["parsed"] = parsed
        if prepared.adapter_request.include_reasoning and response.reasoning:
            payload["reasoning"] = response.reasoning
        return payload

    def _start_payload(
        self,
        prepared: PreparedCall,
        upstream_id: str | None,
    ) -> dict[str, Any]:
        return {
            "id": upstream_id
            or f"chatcmpl-{uuid.uuid4().hex}",
            "object": "chat.completion.chunk",
            "model": prepared.spec.id,
            "requested_model": prepared.requested_model,
            "protocol": prepared.spec.protocol.value,
            "stream": True,
            "request_id": prepared.request_id,
            "prompt": prepared.prompt_ref,
            "structured": prepared.response_format is not None,
        }

    def _stream_done_payload(
        self,
        *,
        prepared: PreparedCall,
        upstream_id: str | None,
        finish_reason: str,
        upstream_finish: str | None,
        usage: Usage,
        parsed: Any,
        reasoning: str,
        latency: dict[str, Any],
        retry_count: int,
        attempts: list[dict[str, Any]],
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": upstream_id or f"chatcmpl-{uuid.uuid4().hex}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": prepared.spec.id,
            "protocol": prepared.spec.protocol.value,
            "finish_reason": finish_reason,
            "upstream_finish_reason": upstream_finish,
            "usage": usage.to_dict(),
            "latency": latency,
            "retry_count": retry_count,
            "attempts": attempts,
            "request_id": prepared.request_id,
            "prompt": prepared.prompt_ref,
            "structured": prepared.response_format is not None,
        }
        if prepared.response_format is not None:
            payload["parsed"] = parsed
        if prepared.adapter_request.include_reasoning and reasoning:
            payload["reasoning"] = reasoning
        return payload

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _retry_delay(self, error: ServiceError, attempt_index: int) -> float:
        retry_after = getattr(error, "retry_after", None)
        if retry_after is not None and retry_after > 0:
            return min(retry_after, self.settings.llm_retry_max_delay)
        base = min(
            self.settings.llm_retry_base_delay * (2**attempt_index),
            self.settings.llm_retry_max_delay,
        )
        jitter = base * self.settings.llm_retry_jitter
        return base + random.uniform(0, jitter)

    def _injected_error(self, status_code: int) -> UpstreamError:
        if status_code == 429:
            return UpstreamError(
                ErrorCode.UPSTREAM_RATE_LIMITED,
                "Injected upstream 429 for retry verification",
                status_code=429,
                retryable=True,
                upstream_status=429,
                details={"injected": True},
            )
        return UpstreamError(
            ErrorCode.UPSTREAM_UNAVAILABLE,
            f"Injected upstream {status_code} for retry verification",
            status_code=502,
            retryable=True,
            upstream_status=status_code,
            details={"injected": True},
        )

    def _record_failure(
        self,
        *,
        prepared: PreparedCall,
        exc: ServiceError,
        attempts: list[dict[str, Any]],
        retry_count: int,
        started_at: float,
        http_status: int,
        usage: Usage | None = None,
    ) -> None:
        self.metrics.record(
            CallRecord(
                request_id=prepared.request_id,
                model=prepared.spec.id,
                upstream_model=prepared.spec.upstream_model,
                protocol=prepared.spec.protocol.value,
                stream=prepared.stream,
                status="error",
                http_status=http_status,
                usage=(usage or Usage.zero()).to_dict(),
                latency={
                    "total_ms": _elapsed_ms(started_at),
                    "ttft_ms": None,
                },
                retry_count=retry_count,
                attempts=attempts,
                prompt=prepared.prompt_ref,
                structured=prepared.response_format is not None,
                error_code=exc.code.value,
                error_message=exc.message[:300],
            )
        )

    def _record_rejected(
        self,
        *,
        request_id: str,
        spec: ModelSpec,
        request: ChatRequest,
        prompt_ref: dict[str, Any] | None,
        structured: StructuredFormat | None,
        started_at: float,
        exc: ServiceError,
    ) -> None:
        self.metrics.record(
            CallRecord(
                request_id=request_id,
                model=spec.id,
                upstream_model=spec.upstream_model,
                protocol=spec.protocol.value,
                stream=request.stream,
                status="rejected",
                http_status=429,
                usage=Usage.zero().to_dict(),
                latency={
                    "total_ms": _elapsed_ms(started_at),
                    "ttft_ms": None,
                },
                retry_count=0,
                attempts=[],
                prompt=prompt_ref,
                structured=structured is not None,
                error_code=exc.code.value,
                error_message=exc.message[:300],
            )
        )

    def get_available_models(self) -> list[dict[str, Any]]:
        return [spec.to_public_dict() for spec in all_models()]

    def rate_limit_snapshot(self) -> list[dict[str, Any]]:
        for spec in all_models():
            self._limiter.ensure(spec.id)
        return self._limiter.snapshot()

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        for adapter in self._adapters.values():
            await adapter.aclose()


def _elapsed_ms(
    start: float,
    end: float | None = None,
) -> float:
    end_value = time.perf_counter() if end is None else end
    return round(max(0.0, end_value - start) * 1000, 2)
