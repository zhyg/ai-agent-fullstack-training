# app/services/structured.py
"""Structured-output normalization and validation."""
from __future__ import annotations

import json
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError

from app.adapters.base import StructuredFormat
from app.core.errors import ErrorCode, ServiceError
from app.models.schemas import ResponseFormat


def normalize_response_format(
    raw: ResponseFormat | None,
) -> StructuredFormat | None:
    if raw is None or raw.type == "text":
        return None
    if raw.type == "json_object":
        return StructuredFormat(kind="json_object", name="response")

    spec = raw.json_schema
    if not isinstance(spec, dict):
        raise ServiceError(
            ErrorCode.INVALID_RESPONSE_FORMAT,
            "response_format.type=json_schema requires response_format.json_schema",
            status_code=400,
            details={"received": raw.model_dump()},
        )
    schema = spec.get("schema")
    if not isinstance(schema, dict):
        raise ServiceError(
            ErrorCode.INVALID_RESPONSE_FORMAT,
            "response_format.json_schema.schema must be a JSON Schema object",
            status_code=400,
            details={"received_keys": sorted(spec)},
        )
    try:
        Draft202012Validator.check_schema(schema)
    except SchemaError as exc:
        raise ServiceError(
            ErrorCode.INVALID_RESPONSE_FORMAT,
            f"Invalid JSON Schema: {exc.message}",
            status_code=400,
            details={"path": list(exc.path)},
        ) from exc
    return StructuredFormat(
        kind="json_schema",
        name=str(spec.get("name") or "response"),
        schema=schema,
        strict=bool(spec.get("strict", True)),
    )


def parse_and_validate(
    content: str,
    fmt: StructuredFormat,
) -> Any:
    if content is None or not content.strip():
        raise _invalid("Upstream returned an empty structured-output payload")
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise _invalid(
            f"Upstream returned invalid JSON: {exc.msg}",
            raw_preview=content[:500],
        ) from exc

    if fmt.kind == "json_object":
        if not isinstance(parsed, dict):
            raise _invalid(
                "json_object mode requires a JSON object at the top level",
                raw_preview=content[:500],
            )
        return parsed

    assert fmt.schema is not None
    validator = Draft202012Validator(fmt.schema)
    try:
        validator.validate(parsed)
    except ValidationError as exc:
        raise _invalid(
            f"Structured output does not match schema: {exc.message}",
            path=list(exc.absolute_path),
            validator=exc.validator,
            raw_preview=content[:500],
        ) from exc
    return parsed


def _invalid(message: str, **details: Any) -> ServiceError:
    return ServiceError(
        ErrorCode.STRUCTURED_OUTPUT_INVALID,
        message,
        status_code=502,
        retryable=False,
        details=details,
    )
