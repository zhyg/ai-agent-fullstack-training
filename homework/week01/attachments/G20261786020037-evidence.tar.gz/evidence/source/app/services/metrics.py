# app/services/metrics.py
"""In-process call metrics with optional JSONL durability.

Each logical gateway call produces exactly one record, regardless of how many
upstream attempts it took. Records carry:

* normalized token usage (input/output/total plus reasoning/cache subsets),
* total latency, time-to-first-token (TTFT) and first-text latency,
* retry count and per-attempt outcomes,
* prompt template reference and status/error code.

The summary endpoint aggregates by model and protocol and reports p50/p95.
"""
from __future__ import annotations

import json
import math
import threading
from collections import Counter, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

from app.adapters.base import Usage

logger = structlog.get_logger()


@dataclass
class CallRecord:
    request_id: str
    model: str
    upstream_model: str
    protocol: str
    stream: bool
    status: str
    http_status: int
    usage: dict[str, int] = field(default_factory=dict)
    latency: dict[str, float | None] = field(default_factory=dict)
    retry_count: int = 0
    attempts: list[dict[str, Any]] = field(default_factory=list)
    prompt: dict[str, Any] | None = None
    structured: bool = False
    error_code: str | None = None
    error_message: str | None = None
    finish_reason: str | None = None
    response_id: str | None = None
    timestamp: str = ""

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat(
                timespec="milliseconds"
            )
        if not self.usage:
            self.usage = Usage.zero().to_dict()
        if not self.latency:
            self.latency = {"total_ms": None, "ttft_ms": None}

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "timestamp": self.timestamp,
            "model": self.model,
            "upstream_model": self.upstream_model,
            "protocol": self.protocol,
            "stream": self.stream,
            "status": self.status,
            "http_status": self.http_status,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "finish_reason": self.finish_reason,
            "response_id": self.response_id,
            "usage": self.usage,
            "latency": self.latency,
            "retry_count": self.retry_count,
            "attempts": self.attempts,
            "prompt": self.prompt,
            "structured": self.structured,
        }


class MetricsStore:
    def __init__(
        self,
        *,
        log_path: str | Path | None = None,
        max_records: int = 5000,
    ) -> None:
        self._records: deque[CallRecord] = deque(maxlen=max_records)
        self._lock = threading.Lock()
        self._file = None
        self._log_path: Path | None = None
        if log_path:
            path = Path(log_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            self._file = path.open("a", encoding="utf-8")
            self._log_path = path

    def record(self, record: CallRecord) -> None:
        with self._lock:
            self._records.append(record)
            if self._file is not None:
                try:
                    self._file.write(
                        json.dumps(
                            record.to_dict(),
                            ensure_ascii=False,
                            separators=(",", ":"),
                        )
                        + "\n"
                    )
                    self._file.flush()
                except OSError as exc:  # pragma: no cover - disk failure
                    logger.warning("metrics.write_failed", error=str(exc))

    def close(self) -> None:
        with self._lock:
            if self._file is not None:
                self._file.close()
                self._file = None

    def clear(self) -> None:
        with self._lock:
            self._records.clear()

    @property
    def log_path(self) -> str | None:
        return str(self._log_path) if self._log_path else None

    def _snapshot(self) -> list[CallRecord]:
        with self._lock:
            return list(self._records)

    def recent(
        self,
        *,
        limit: int = 50,
        model: str | None = None,
    ) -> list[dict[str, Any]]:
        records = self._snapshot()
        if model:
            records = [record for record in records if record.model == model]
        return [record.to_dict() for record in reversed(records[-limit:])]

    def get(self, request_id: str) -> dict[str, Any] | None:
        for record in reversed(self._snapshot()):
            if record.request_id == request_id:
                return record.to_dict()
        return None

    def summary(self) -> dict[str, Any]:
        records = self._snapshot()
        total = len(records)
        status_counts = Counter(record.status for record in records)
        usage_totals = _sum_usage(record.usage for record in records)
        latencies = [
            record.latency.get("total_ms")
            for record in records
            if record.latency.get("total_ms") is not None
        ]
        ttfts = [
            record.latency.get("ttft_ms")
            for record in records
            if record.latency.get("ttft_ms") is not None
        ]

        by_model: dict[str, dict[str, Any]] = {}
        for model in sorted({record.model for record in records}):
            subset = [record for record in records if record.model == model]
            model_latencies = [
                record.latency.get("total_ms")
                for record in subset
                if record.latency.get("total_ms") is not None
            ]
            model_ttfts = [
                record.latency.get("ttft_ms")
                for record in subset
                if record.latency.get("ttft_ms") is not None
            ]
            by_model[model] = {
                "calls": len(subset),
                "success": sum(1 for r in subset if r.status == "success"),
                "error": sum(1 for r in subset if r.status == "error"),
                "rejected": sum(1 for r in subset if r.status == "rejected"),
                "cancelled": sum(1 for r in subset if r.status == "cancelled"),
                "protocol": subset[0].protocol,
                "stream_calls": sum(1 for r in subset if r.stream),
                "structured_calls": sum(1 for r in subset if r.structured),
                "usage": _sum_usage(r.usage for r in subset),
                "retry_count": sum(r.retry_count for r in subset),
                "calls_with_retries": sum(
                    1 for r in subset if r.retry_count > 0
                ),
                "latency_ms": _distribution(model_latencies),
                "ttft_ms": _distribution(model_ttfts),
            }

        by_protocol: dict[str, dict[str, Any]] = {}
        for protocol in sorted({record.protocol for record in records}):
            subset = [record for record in records if record.protocol == protocol]
            by_protocol[protocol] = {
                "calls": len(subset),
                "success": sum(1 for r in subset if r.status == "success"),
                "error": sum(1 for r in subset if r.status == "error"),
                "usage": _sum_usage(r.usage for r in subset),
                "retry_count": sum(r.retry_count for r in subset),
            }

        timestamps = [record.timestamp for record in records if record.timestamp]
        return {
            "total_calls": total,
            "success": status_counts.get("success", 0),
            "error": status_counts.get("error", 0),
            "rejected": status_counts.get("rejected", 0),
            "cancelled": status_counts.get("cancelled", 0),
            "stream_calls": sum(1 for r in records if r.stream),
            "structured_calls": sum(1 for r in records if r.structured),
            "calls_with_retries": sum(1 for r in records if r.retry_count > 0),
            "total_retries": sum(r.retry_count for r in records),
            "usage": usage_totals,
            "latency_ms": _distribution(latencies),
            "ttft_ms": _distribution(ttfts),
            "by_model": by_model,
            "by_protocol": by_protocol,
            "window": {
                "first": min(timestamps) if timestamps else None,
                "last": max(timestamps) if timestamps else None,
            },
            "records_retained": len(self._records),
            "observability_log": self.log_path,
        }


def _sum_usage(usages) -> dict[str, int]:
    totals = {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "reasoning_tokens": 0,
        "cached_input_tokens": 0,
        "cache_creation_input_tokens": 0,
    }
    for usage in usages:
        for key in totals:
            totals[key] += int(usage.get(key) or 0)
    return totals


def _distribution(values: list[float]) -> dict[str, float | int | None]:
    if not values:
        return {"count": 0, "avg": None, "p50": None, "p95": None}
    ordered = sorted(float(value) for value in values)
    return {
        "count": len(ordered),
        "avg": round(sum(ordered) / len(ordered), 2),
        "p50": round(_percentile(ordered, 0.50), 2),
        "p95": round(_percentile(ordered, 0.95), 2),
    }


def _percentile(ordered: list[float], percentile: float) -> float:
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * percentile
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight
