#!/usr/bin/env python
"""End-to-end verification for the unified LLM gateway.

Starts the real FastAPI app twice (normal limits, then a low limit for
``deepseek-flash``), calls the real upstream APIs and asserts:

1. both models work through two different protocols
2. SSE streaming for both
3. response_format/json_schema structured output for both
4. prompt creation, versioning, rendering and version reference
5. usage (with categories) + latency (with TTFT) observability
6. retry with exponential backoff and per-model 429 isolation

Writes a JSON evidence report under ``evidence/`` and exits non-zero if any
check fails.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import jsonschema

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import Settings  # noqa: E402

RUN_ID = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
PROMPT_NAME = f"verify_{RUN_ID.replace('-', '_')}"
SCHEMA = {
    "type": "object",
    "properties": {
        "sentiment": {
            "type": "string",
            "enum": ["positive", "negative", "neutral"],
        },
        "confidence": {"type": "number"},
    },
    "required": ["sentiment", "confidence"],
    "additionalProperties": False,
}


# ----------------------------------------------------------------------
# SSE helpers
# ----------------------------------------------------------------------
def parse_sse(raw: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    normalized = raw.replace("\r\n", "\n")
    for block in normalized.split("\n\n"):
        event_name: str | None = None
        data_lines: list[str] = []
        for line in block.split("\n"):
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].strip())
        if not data_lines:
            continue
        payload = "\n".join(data_lines)
        if payload == "[DONE]":
            events.append({"event": "done_marker", "data": None})
            continue
        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise AssertionError(f"invalid SSE JSON: {payload[:200]}") from exc
        events.append({"event": event_name, "data": parsed})
    return events


def event_of(events: list[dict[str, Any]], name: str) -> dict[str, Any]:
    for event in events:
        if event["event"] == name:
            return event
    raise AssertionError(f"SSE event {name!r} not found in {[e['event'] for e in events]}")


def text_from_deltas(events: list[dict[str, Any]]) -> str:
    return "".join(
        str(event["data"].get("delta") or "")
        for event in events
        if event["event"] == "delta"
    )


# ----------------------------------------------------------------------
# Server process
# ----------------------------------------------------------------------
def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


class ServerProcess:
    def __init__(self, label: str, overrides: dict[str, str]) -> None:
        self.label = label
        self.overrides = overrides
        self.port = find_free_port()
        self.base_url = f"http://127.0.0.1:{self.port}"
        self.log_path = EVIDENCE / f"server-{label}-{RUN_ID}.log"
        self.process: subprocess.Popen | None = None
        self._log_file = None

    def start(self) -> None:
        EVIDENCE.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env.update(
            {
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONUTF8": "1",
                "PYTHONIOENCODING": "utf-8",
                "LOG_LEVEL": "WARNING",
                "ENVIRONMENT": "development",
                "PROMPT_STORE_DIR": "data/verify-prompts",
                "RATE_LIMIT_DEFAULT_CAPACITY": "1000",
                "RATE_LIMIT_DEFAULT_REFILL_PER_SECOND": "1000",
                "RATE_LIMIT_OVERRIDES": "",
                "LLM_MAX_RETRIES": "3",
                "LLM_RETRY_BASE_DELAY": "0.05",
                "LLM_RETRY_MAX_DELAY": "0.25",
                "LLM_RETRY_JITTER": "0",
                "OBSERVABILITY_LOG_PATH": str(
                    EVIDENCE / f"observability-{self.label}-{RUN_ID}.jsonl"
                ),
            }
        )
        env.update(self.overrides)
        self._log_file = self.log_path.open("w", encoding="utf-8")
        self.process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "app.main:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(self.port),
                "--log-level",
                "warning",
            ],
            cwd=str(ROOT),
            env=env,
            stdout=self._log_file,
            stderr=subprocess.STDOUT,
        )
        deadline = time.monotonic() + 45
        last_error: str | None = None
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError(
                    f"server {self.label} exited early; log:\n{self.log_tail()}"
                )
            try:
                response = httpx.get(
                    f"{self.base_url}/health",
                    timeout=2.0,
                )
                if response.status_code == 200:
                    return
            except httpx.HTTPError as exc:
                last_error = str(exc)
            time.sleep(0.25)
        raise RuntimeError(
            f"server {self.label} did not become healthy: {last_error}\n"
            f"{self.log_tail()}"
        )

    def log_tail(self, lines: int = 60) -> str:
        if not self.log_path.exists():
            return "<no log>"
        content = self.log_path.read_text(encoding="utf-8", errors="replace")
        return "\n".join(content.splitlines()[-lines:])

    def stop(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        if self._log_file is not None:
            self._log_file.close()
            self._log_file = None


# ----------------------------------------------------------------------
# Check runner
# ----------------------------------------------------------------------
def run_check(
    results: list[dict[str, Any]],
    name: str,
    func,
) -> dict[str, Any] | None:
    started = time.perf_counter()
    try:
        detail = func()
    except Exception as exc:  # noqa: BLE001 - report every failure
        elapsed = round((time.perf_counter() - started) * 1000, 2)
        message = "".join(
            traceback.format_exception_only(type(exc), exc)
        ).strip()
        results.append(
            {
                "check": name,
                "ok": False,
                "duration_ms": elapsed,
                "error": f"{type(exc).__name__}: {message}"[:1200],
            }
        )
        print(f"[FAIL] {name} ({elapsed} ms): {type(exc).__name__}: {message}")
        return None
    elapsed = round((time.perf_counter() - started) * 1000, 2)
    results.append(
        {
            "check": name,
            "ok": True,
            "duration_ms": elapsed,
            "detail": detail,
        }
    )
    print(f"[PASS] {name} ({elapsed} ms)")
    return detail


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def json_body(response: httpx.Response, expected: int = 200) -> dict[str, Any]:
    require(
        response.status_code == expected,
        f"expected HTTP {expected}, got {response.status_code}: {response.text[:500]}",
    )
    try:
        return response.json()
    except ValueError as exc:
        raise AssertionError(f"non-JSON response: {response.text[:500]}") from exc


def error_code(response: httpx.Response) -> str:
    body = response.json()
    return str(body.get("error", {}).get("code"))


# ----------------------------------------------------------------------
# Checks
# ----------------------------------------------------------------------
def check_discovery(client: httpx.Client) -> dict[str, Any]:
    models = json_body(client.get("/v1/models"))
    protocols = {model["protocol"] for model in models["models"]}
    require(models["total"] == 2, f"expected 2 models, got {models['total']}")
    require(
        protocols == {"openai-responses", "anthropic-messages"},
        f"unexpected protocols: {protocols}",
    )
    limits = json_body(client.get("/v1/rate-limits"))
    require(limits["total"] == 2, "expected two independent buckets")
    return {
        "models": [
            {
                "id": model["id"],
                "protocol": model["protocol"],
                "upstream_model": model["upstream_model"],
            }
            for model in models["models"]
        ],
        "rate_limit_models": [row["model"] for row in limits["limits"]],
    }


def check_non_stream(client: httpx.Client) -> dict[str, Any]:
    outcomes = {}
    for model, protocol, expected in (
        ("deepseek-v4-pro", "openai-responses", "PRO_OK"),
        ("deepseek-flash", "anthropic-messages", "FLASH_OK"),
    ):
        response = client.post(
            "/v1/chat",
            json={
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": f"Reply with exactly: {expected}",
                    }
                ],
                "max_tokens": 256,
            },
        )
        body = json_body(response)
        content = body["choices"][0]["message"]["content"]
        usage = body["usage"]
        require(expected in content, f"{model} content: {content!r}")
        require(body["protocol"] == protocol, "protocol mismatch")
        require(body["retry_count"] == 0, "unexpected retry")
        require(usage["input_tokens"] > 0, "missing input tokens")
        require(usage["output_tokens"] > 0, "missing output tokens")
        require(
            usage["total_tokens"] == usage["input_tokens"] + usage["output_tokens"],
            f"token total mismatch: {usage}",
        )
        require(body["latency"]["total_ms"] > 0, "missing latency")
        require(response.headers.get("X-Request-Id"), "missing request id header")
        outcomes[model] = {
            "request_id": body["request_id"],
            "content": content[:120],
            "usage": usage,
            "latency_ms": body["latency"]["total_ms"],
        }
    return outcomes


def check_stream(client: httpx.Client) -> dict[str, Any]:
    outcomes = {}
    for model, protocol in (
        ("deepseek-v4-pro", "openai-responses"),
        ("deepseek-flash", "anthropic-messages"),
    ):
        response = client.post(
            "/v1/chat",
            json={
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": "Write the numbers 1 through 6, comma separated.",
                    }
                ],
                "max_tokens": 512,
                "stream": True,
                "include_reasoning": True,
            },
            timeout=180.0,
        )
        require(response.status_code == 200, f"stream HTTP {response.status_code}")
        require(
            "text/event-stream" in response.headers.get("content-type", ""),
            "stream is not text/event-stream",
        )
        events = parse_sse(response.text)
        names = [event["event"] for event in events]
        require("start" in names, f"missing start event: {names}")
        require("usage" in names, f"missing usage event: {names}")
        require("done" in names, f"missing done event: {names}")
        require("done_marker" in names, "missing [DONE] marker")
        start = event_of(events, "start")["data"]
        done = event_of(events, "done")["data"]
        usage_event = event_of(events, "usage")["data"]
        text = text_from_deltas(events)
        require(start["protocol"] == protocol, "stream protocol mismatch")
        require(text.strip(), f"no streamed text for {model}")
        require(done["usage"]["output_tokens"] > 0, "stream usage missing")
        require(
            done["usage"]["total_tokens"]
            == done["usage"]["input_tokens"] + done["usage"]["output_tokens"],
            "stream token total mismatch",
        )
        require(
            done["latency"]["ttft_ms"] is not None
            and done["latency"]["ttft_ms"] > 0,
            "missing TTFT",
        )
        require(
            done["latency"].get("first_text_ms") is not None,
            "missing first_text_ms",
        )
        require(
            done["latency"]["first_text_ms"] >= done["latency"]["ttft_ms"],
            "first_text_ms must not be earlier than TTFT",
        )
        require(
            usage_event["ttft_ms"] == done["latency"]["ttft_ms"],
            "usage TTFT differs from done TTFT",
        )
        require(done["retry_count"] == 0, "unexpected stream retry")
        outcomes[model] = {
            "request_id": done["request_id"],
            "protocol": protocol,
            "delta_events": names.count("delta"),
            "reasoning_events": names.count("reasoning"),
            "text": text[:160],
            "ttft_ms": done["latency"]["ttft_ms"],
            "first_text_ms": done["latency"].get("first_text_ms"),
            "total_ms": done["latency"]["total_ms"],
            "usage": done["usage"],
        }
    return outcomes


def check_structured(client: httpx.Client) -> dict[str, Any]:
    outcomes = {}
    for model in ("deepseek-v4-pro", "deepseek-flash"):
        response = client.post(
            "/v1/chat",
            json={
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": "Classify: I love this product.",
                    }
                ],
                "max_tokens": 512,
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "sentiment",
                        "strict": True,
                        "schema": SCHEMA,
                    },
                },
            },
        )
        body = json_body(response)
        require(body["structured"] is True, "structured flag missing")
        parsed = body.get("parsed")
        require(isinstance(parsed, dict), f"missing parsed object: {body}")
        jsonschema.validate(parsed, SCHEMA)
        require(parsed["sentiment"] == "positive", f"unexpected sentiment: {parsed}")
        content = json.loads(body["choices"][0]["message"]["content"])
        require(content == parsed, "content and parsed disagree")
        outcomes[model] = {
            "request_id": body["request_id"],
            "parsed": parsed,
            "usage": body["usage"],
        }
    return outcomes


def check_prompt_versions(client: httpx.Client, context: dict[str, Any]) -> dict[str, Any]:
    create = client.post(
        "/v1/prompts",
        json={
            "name": PROMPT_NAME,
            "template": "Reply with exactly the word {{word}}",
            "description": "verification v1",
        },
    )
    v1 = json_body(create, expected=201)
    version_two = client.post(
        f"/v1/prompts/{PROMPT_NAME}/versions",
        json={
            "template": "Reply with exactly the word {{word}}!",
            "description": "verification v2",
        },
    )
    v2 = json_body(version_two, expected=201)
    require(v1["version"] == 1 and v2["version"] == 2, "version numbering wrong")
    require(v1["sha256"] != v2["sha256"], "template hashes should differ")

    render_one = json_body(
        client.post(
            f"/v1/prompts/{PROMPT_NAME}/render",
            json={"version": 1, "variables": {"word": "BANANA"}},
        )
    )
    render_two = json_body(
        client.post(
            f"/v1/prompts/{PROMPT_NAME}/render",
            json={"version": 2, "variables": {"word": "BANANA"}},
        )
    )
    require(render_one["rendered"].endswith("BANANA"), "v1 render wrong")
    require(render_two["rendered"].endswith("BANANA!"), "v2 render wrong")

    missing = client.post(
        f"/v1/prompts/{PROMPT_NAME}/render",
        json={"version": 2, "variables": {}},
    )
    require(missing.status_code == 422, "missing variable should be 422")
    require(
        error_code(missing) == "TEMPLATE_VARIABLE_MISSING",
        f"unexpected error: {missing.text}",
    )

    chat = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-flash",
            "prompt": {
                "name": PROMPT_NAME,
                "version": 1,
                "variables": {"word": "BANANA"},
            },
            "max_tokens": 256,
        },
    )
    body = json_body(chat)
    require(body["prompt"]["name"] == PROMPT_NAME, "prompt name missing")
    require(body["prompt"]["version"] == 1, "prompt version reference wrong")
    require(body["prompt"]["sha256"] == v1["sha256"], "prompt hash mismatch")
    require("BANANA" in body["choices"][0]["message"]["content"], "variable not used")

    versions = json_body(client.get(f"/v1/prompts/{PROMPT_NAME}/versions"))
    require(versions["total"] == 2, "version listing wrong")
    context["prompt_sha_v1"] = v1["sha256"]
    return {
        "name": PROMPT_NAME,
        "versions": [item["version"] for item in versions["versions"]],
        "rendered_v1": render_one["rendered"],
        "rendered_v2": render_two["rendered"],
        "chat_request_id": body["request_id"],
        "prompt_reference": body["prompt"],
    }


def check_retry(client: httpx.Client, context: dict[str, Any]) -> dict[str, Any]:
    response = client.post(
        "/v1/chat",
        headers={
            "X-Debug-Fail-Times": "2",
            "X-Debug-Fail-Status": "503",
        },
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "Reply with exactly: RETRY_OK"}],
            "max_tokens": 256,
        },
    )
    body = json_body(response)
    require(body["retry_count"] == 2, f"expected 2 retries, got {body['retry_count']}")
    require(len(body["attempts"]) == 3, "expected 3 attempts")
    require(body["attempts"][0]["outcome"] == "error", "attempt 1 should fail")
    require(body["attempts"][1]["outcome"] == "error", "attempt 2 should fail")
    require(body["attempts"][2]["outcome"] == "success", "attempt 3 should succeed")
    require(body["attempts"][0]["upstream_status"] == 503, "missing 503 status")
    require(
        body["attempts"][0]["backoff_ms"] >= 40,
        f"first backoff too small: {body['attempts'][0]['backoff_ms']}",
    )
    require(
        body["attempts"][1]["backoff_ms"] >= 80,
        f"second backoff not exponential: {body['attempts'][1]['backoff_ms']}",
    )
    context["retry_request_id"] = body["request_id"]
    return {
        "request_id": body["request_id"],
        "retry_count": body["retry_count"],
        "attempts": body["attempts"],
        "latency_ms": body["latency"]["total_ms"],
    }


def check_retry_exhaustion(client: httpx.Client) -> dict[str, Any]:
    response = client.post(
        "/v1/chat",
        headers={
            "X-Debug-Fail-Times": "9",
            "X-Debug-Fail-Status": "503",
        },
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "never reached"}],
            "max_tokens": 16,
        },
    )
    body = response.json()
    require(response.status_code == 502, f"expected 502, got {response.status_code}")
    require(
        error_code(response) == "UPSTREAM_UNAVAILABLE",
        f"unexpected code: {response.text[:300]}",
    )
    details = body["error"]["details"]
    require(details["retry_count"] == 3, "must stop after at most 3 retries")
    require(len(details["attempts"]) == 4, "expected 4 total attempts")
    return {
        "http_status": response.status_code,
        "code": body["error"]["code"],
        "retry_count": details["retry_count"],
        "attempts": len(details["attempts"]),
    }


def check_errors(client: httpx.Client) -> dict[str, Any]:
    unknown = client.post(
        "/v1/chat",
        json={"model": "does-not-exist", "messages": [{"role": "user", "content": "x"}]},
    )
    require(unknown.status_code == 404, "unknown model should be 404")
    require(error_code(unknown) == "MODEL_NOT_FOUND", "wrong unknown-model code")

    bad_format = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "x"}],
            "response_format": {"type": "json_schema", "json_schema": {"name": "x"}},
        },
    )
    require(bad_format.status_code == 400, f"bad schema shape: {bad_format.status_code}")
    require(
        error_code(bad_format) == "INVALID_RESPONSE_FORMAT",
        "wrong response-format code",
    )

    missing_version = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-flash",
            "prompt": {"name": PROMPT_NAME, "version": 99, "variables": {"word": "x"}},
        },
    )
    require(missing_version.status_code == 404, "missing prompt version should 404")
    require(
        error_code(missing_version) == "PROMPT_VERSION_NOT_FOUND",
        "wrong prompt-version code",
    )

    invalid_request = client.post(
        "/v1/chat",
        json={"model": "deepseek-v4-pro", "messages": []},
    )
    require(invalid_request.status_code == 422, "invalid body should 422")
    require(error_code(invalid_request) == "VALIDATION_ERROR", "wrong validation code")
    return {
        "unknown_model": "MODEL_NOT_FOUND",
        "bad_response_format": "INVALID_RESPONSE_FORMAT",
        "missing_prompt_version": "PROMPT_VERSION_NOT_FOUND",
        "validation": "VALIDATION_ERROR",
    }


def check_observability(
    client: httpx.Client,
    context: dict[str, Any],
) -> dict[str, Any]:
    summary = json_body(client.get("/v1/metrics/summary"))
    require(summary["total_calls"] >= 9, f"too few calls: {summary['total_calls']}")
    require("deepseek-v4-pro" in summary["by_model"], "pro metrics missing")
    require("deepseek-flash" in summary["by_model"], "flash metrics missing")
    require(summary["usage"]["input_tokens"] > 0, "input token total missing")
    require(summary["usage"]["output_tokens"] > 0, "output token total missing")
    require(
        summary["usage"]["total_tokens"]
        == summary["usage"]["input_tokens"] + summary["usage"]["output_tokens"],
        "aggregate token totals inconsistent",
    )
    require(summary["ttft_ms"]["count"] >= 2, "stream TTFT samples missing")
    require(summary["calls_with_retries"] >= 1, "retry metrics missing")
    require(summary["total_retries"] >= 2, "retry count metrics missing")
    require(
        set(summary["by_protocol"].keys())
        == {"openai-responses", "anthropic-messages"},
        "protocol aggregation missing",
    )

    recent = json_body(client.get("/v1/metrics/recent", params={"limit": 200}))
    records = recent["records"]
    retry_record = next(
        (row for row in records if row["request_id"] == context["retry_request_id"]),
        None,
    )
    require(retry_record is not None, "retry call record missing")
    require(retry_record["retry_count"] == 2, "retry count not recorded")
    require(len(retry_record["attempts"]) == 3, "attempt history not recorded")
    require(retry_record["usage"]["output_tokens"] > 0, "retry usage missing")

    stream_record = next(
        (
            row
            for row in records
            if row["stream"]
            and row["status"] == "success"
            and row["latency"]["ttft_ms"] is not None
        ),
        None,
    )
    require(stream_record is not None, "stream metric record missing")
    require(stream_record["latency"]["ttft_ms"] > 0, "stream TTFT not recorded")
    require(
        stream_record["latency"].get("first_text_ms") is not None,
        "stream first_text_ms not recorded",
    )
    require(
        stream_record["latency"]["total_ms"] >= stream_record["latency"]["ttft_ms"],
        "TTFT greater than total latency",
    )

    recorded = json_body(
        client.get(f"/v1/metrics/calls/{context['retry_request_id']}")
    )
    require(recorded["request_id"] == context["retry_request_id"], "call lookup failed")
    return {
        "total_calls": summary["total_calls"],
        "usage": summary["usage"],
        "latency_ms": summary["latency_ms"],
        "ttft_ms": summary["ttft_ms"],
        "calls_with_retries": summary["calls_with_retries"],
        "total_retries": summary["total_retries"],
        "retry_record": {
            "request_id": retry_record["request_id"],
            "retry_count": retry_record["retry_count"],
            "attempts": retry_record["attempts"],
        },
        "stream_record": {
            "request_id": stream_record["request_id"],
            "ttft_ms": stream_record["latency"]["ttft_ms"],
            "usage": stream_record["usage"],
        },
    }


def check_rate_limit_isolation(client: httpx.Client) -> dict[str, Any]:
    flash = []
    for _ in range(3):
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-flash",
                "messages": [{"role": "user", "content": "Reply with exactly: RL"}],
                "max_tokens": 64,
            },
        )
        flash.append(response)

    require(flash[0].status_code == 200, "first flash call should pass")
    require(flash[1].status_code == 200, "second flash call should pass")
    limited = flash[2]
    require(limited.status_code == 429, f"third flash call should be 429, got {limited.status_code}")
    body = limited.json()
    require(body["error"]["code"] == "RATE_LIMITED", "wrong rate-limit code")
    require(limited.headers.get("Retry-After"), "missing Retry-After header")
    require(
        int(limited.headers.get("X-RateLimit-Remaining", "1")) == 0,
        "remaining header should be 0",
    )
    require(body["error"]["details"]["model"] == "deepseek-flash", "wrong model")

    pro = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "Reply with exactly: FREE"}],
            "max_tokens": 64,
        },
    )
    require(pro.status_code == 200, "pro should be unaffected by flash limiter")

    limits = json_body(client.get("/v1/rate-limits"))["limits"]
    by_model = {row["model"]: row for row in limits}
    require(by_model["deepseek-flash"]["capacity"] == 2, "flash capacity wrong")
    require(by_model["deepseek-v4-pro"]["capacity"] == 1000, "pro capacity wrong")
    return {
        "flash_statuses": [response.status_code for response in flash],
        "flash_retry_after": limited.headers.get("Retry-After"),
        "pro_status": pro.status_code,
        "limits": {
            row["model"]: {
                "capacity": row["capacity"],
                "remaining": row["remaining_requests"],
            }
            for row in limits
        },
    }


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def main() -> int:
    os.chdir(ROOT)
    settings = Settings()
    if not settings.api_key_configured:
        print("DEEPSEEK_API_KEY is not configured; put it in .env first.")
        return 2

    EVIDENCE.mkdir(parents=True, exist_ok=True)
    started_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    results: list[dict[str, Any]] = []
    context: dict[str, Any] = {}
    servers: dict[str, str] = {}

    print(f"run id: {RUN_ID}")
    print(f"evidence: {EVIDENCE}")

    phase_a = ServerProcess(
        "phase-a",
        {
            "ENABLE_DEBUG_FAULTS": "true",
        },
    )
    phase_b = ServerProcess(
        "phase-b",
        {
            "ENABLE_DEBUG_FAULTS": "false",
            "RATE_LIMIT_OVERRIDES": json.dumps(
                {
                    "deepseek-flash": {
                        "capacity": 2,
                        "refill_per_second": 0.001,
                    }
                }
            ),
        },
    )

    try:
        phase_a.start()
        servers["phase_a"] = str(phase_a.log_path)
        with httpx.Client(
            base_url=phase_a.base_url,
            timeout=httpx.Timeout(180.0, connect=10.0),
        ) as client:
            run_check(results, "discovery", lambda: check_discovery(client))
            run_check(results, "non_stream_both_protocols", lambda: check_non_stream(client))
            run_check(results, "stream_both_protocols", lambda: check_stream(client))
            run_check(results, "structured_output_both", lambda: check_structured(client))
            run_check(
                results,
                "prompt_versions",
                lambda: check_prompt_versions(client, context),
            )
            run_check(results, "retry_backoff", lambda: check_retry(client, context))
            run_check(results, "retry_exhaustion", lambda: check_retry_exhaustion(client))
            run_check(results, "unified_errors", lambda: check_errors(client))
            run_check(
                results,
                "observability",
                lambda: check_observability(client, context),
            )

        phase_b.start()
        servers["phase_b"] = str(phase_b.log_path)
        with httpx.Client(
            base_url=phase_b.base_url,
            timeout=httpx.Timeout(180.0, connect=10.0),
        ) as client:
            run_check(
                results,
                "rate_limit_isolation",
                lambda: check_rate_limit_isolation(client),
            )
    except Exception as exc:  # noqa: BLE001 - server startup failures
        results.append(
            {
                "check": "harness",
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}"[:2000],
            }
        )
        print(f"[FAIL] harness: {type(exc).__name__}: {exc}")
    finally:
        phase_a.stop()
        phase_b.stop()

    finished_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    passed = sum(1 for item in results if item["ok"])
    failed = len(results) - passed
    report = {
        "run_id": RUN_ID,
        "started_at": started_at,
        "finished_at": finished_at,
        "python": sys.version,
        "evidence_dir": str(EVIDENCE),
        "checks": results,
        "summary": {
            "total": len(results),
            "passed": passed,
            "failed": failed,
        },
        "server_logs": servers,
        "context": {
            "prompt_name": PROMPT_NAME,
            "prompt_sha_v1": context.get("prompt_sha_v1"),
            "retry_request_id": context.get("retry_request_id"),
        },
        "models": ["deepseek-v4-pro", "deepseek-flash"],
        "protocols": ["openai-responses", "anthropic-messages"],
    }
    report_path = EVIDENCE / f"verification-{RUN_ID}.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    print("\n" + "=" * 72)
    for item in results:
        marker = "PASS" if item["ok"] else "FAIL"
        print(f"{marker:4}  {item['check']}")
        if not item["ok"]:
            print(f"      {item['error']}")
    print("=" * 72)
    print(f"summary: {passed} passed, {failed} failed")
    print(f"report: {report_path}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
