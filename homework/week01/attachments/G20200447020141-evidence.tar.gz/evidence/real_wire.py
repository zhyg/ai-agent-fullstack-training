"""Observe unchanged adapter clients; log only allowlisted request/response fields."""
import asyncio,json,time
from unittest.mock import patch
from app import service
from app.schemas import LLMRequest
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.adapters.anthropic_messages import AnthropicMessagesAdapter

rows=[]
clients=[]
async def observe(response):
    await response.aread()  # only used for these non-stream requests
    data=response.json()
    rows.append({'url':str(response.request.url),'request':json.loads(response.request.content),
                 'http_status':response.status_code,'upstream_id':data.get('id'),'upstream_model':data.get('model'),
                 'usage':data.get('usage'),'status':data.get('status',data.get('stop_reason')),
                 'headers':{k:v for k,v in response.headers.items() if k.lower() in ['x-request-id','request-id']}})

def observing(original):
    def create(self, config):
        client=original(self,config)
        client._client.event_hooks['response'].append(observe)
        clients.append(client)
        return client
    return create

async def main():
    for model in ['deepseek-v4-pro','deepseek-v4-flash']:
        start=time.monotonic()
        result=await service.complete(LLMRequest(model=model,messages=[{'role':'user','content':'Reply OK only. Do not think.'}],max_output_tokens=128,timeout_seconds=8))
        rows[-1]['gateway']=result.model_dump(mode='json')
        rows[-1]['wall_ms']=round((time.monotonic()-start)*1000)
    for client in clients: await client.close()
    with open('/tmp/kevin-grade/evidence/real-wire.json','w') as f: json.dump(rows,f,ensure_ascii=False,indent=2)

with patch.object(OpenAIResponsesAdapter,'create_client',observing(OpenAIResponsesAdapter.create_client)),patch.object(AnthropicMessagesAdapter,'create_client',observing(AnthropicMessagesAdapter.create_client)):
    asyncio.run(main())
