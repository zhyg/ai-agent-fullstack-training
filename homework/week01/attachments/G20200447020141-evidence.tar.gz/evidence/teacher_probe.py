"""Teacher-controlled SDK HTTP transport; student source remains unchanged.
Run: PYTHONPATH=homework/week01 <venv>/bin/python teacher_probe.py
Only synthetic headers/credentials are used in this process.
"""
import asyncio, json, os, time
from unittest.mock import patch
import httpx2 as httpx
from openai import AsyncOpenAI
from anthropic import AsyncAnthropic
from app.main import app
from app import service, registry
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.chat_completions import OpenAIChatCompletionsAdapter
from app.observability import tracing
from app.resilience import rate_limit, retry
from app.schemas import LLMRequest

os.environ.update(DEEPSEEK_API_KEY='teacher-synthetic', RETRY_BASE_DELAY='0.01', RATE_LIMIT_REQUESTS='1000')
records=[]
calls=[]
mode='ok'
text='{"ok":true}'
release=None

def response_obj(status='completed'):
    return dict(id='resp_teacher',object='response',created_at=1,model='teacher',status=status,
                output=[dict(id='msg_teacher',type='message',role='assistant',status='completed',content=[dict(type='output_text',text=text,annotations=[])])],
                usage=dict(input_tokens=17,output_tokens=9,total_tokens=26,input_tokens_details={'cached_tokens':5},output_tokens_details={'reasoning_tokens':4}),
                error={'code':'server_error','message':'teacher failure'} if status=='failed' else None)

def anthropic_obj():
    return dict(id='msg_teacher',type='message',role='assistant',model='teacher',content=[{'type':'text','text':text}],stop_reason='end_turn',stop_sequence=None,
                usage=dict(input_tokens=17,output_tokens=9,cache_read_input_tokens=5,cache_creation_input_tokens=2))

class Wire(httpx.AsyncByteStream):
    def __init__(self, protocol, fault): self.protocol,self.fault=protocol,fault
    async def __aiter__(self):
        def sse(t,d): return ('event: '+t+'\ndata: '+json.dumps(dict(type=t,**d))+'\n\n').encode()
        if self.protocol=='responses':
            yield sse('response.created',{'response':dict(response_obj('in_progress'),output=[])})
            yield sse('response.output_item.added',{'output_index':0,'item':dict(id='msg_teacher',type='message',role='assistant',status='in_progress',content=[])})
            yield sse('response.content_part.added',{'item_id':'msg_teacher','output_index':0,'content_index':0,'part':{'type':'output_text','text':'','annotations':[]}})
            await asyncio.sleep(.025)
            yield sse('response.output_text.delta',{'item_id':'msg_teacher','output_index':0,'content_index':0,'delta':'first'})
            if release: await release.wait()
            if self.fault=='disconnect': raise httpx.ReadError('teacher disconnect')
            status='failed' if self.fault=='failed_event' else 'completed'
            yield sse('response.'+status,{'response':response_obj(status)})
        elif self.protocol=='messages':
            yield sse('message_start',{'message':dict(anthropic_obj(),content=[],usage={'input_tokens':17,'output_tokens':0})})
            yield sse('content_block_start',{'index':0,'content_block':{'type':'text','text':''}})
            await asyncio.sleep(.025)
            yield sse('content_block_delta',{'index':0,'delta':{'type':'text_delta','text':'first'}})
            if release: await release.wait()
            if self.fault=='disconnect': raise httpx.ReadError('teacher disconnect')
            yield sse('content_block_stop',{'index':0})
            yield sse('message_delta',{'delta':{'stop_reason':'end_turn','stop_sequence':None},'usage':{'output_tokens':9}})
            yield sse('message_stop',{})

async def handler(req):
    body=json.loads(req.content)
    calls.append(dict(path=req.url.path,body=body,time=time.monotonic()))
    protocol='responses' if req.url.path.endswith('/responses') else 'messages'
    n=len(calls)
    if mode=='timeout': raise httpx.ReadTimeout('teacher timeout',request=req)
    status=429 if mode=='retry_success' and n<=2 else 429 if mode=='429' else 500 if mode=='500' else 400 if mode=='400' else 200
    if status!=200: return httpx.Response(status,json={'error':{'type':'invalid_request_error','message':'teacher controlled','code':str(status)}})
    if body.get('stream'): return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Wire(protocol,mode))
    return httpx.Response(200,json=response_obj() if protocol=='responses' else anthropic_obj())

clients=[]
def factory(cls):
    def create(self,config):
        hc=httpx.AsyncClient(transport=httpx.MockTransport(handler))
        client=cls(api_key='teacher-synthetic',base_url='https://teacher.invalid',max_retries=0,http_client=hc)
        clients.append(client)
        return client
    return create

async def main():
    global mode,text,release
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app,raise_app_exceptions=False),base_url='http://gateway') as c:
        async def invoke(model='deepseek-v4-pro',**kw):
            return await c.post('/v1/llm',json=dict(model=model,messages=[{'role':'user','content':'teacher JSON'}],**kw))
        def save(case,**data):
            row=dict(case=case,**data); records.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
        r=await invoke('unknown'); save('A04',status=r.status_code,body=r.json())
        r=await invoke(response_format={'type':'json_object'}); save('F03_response_format',status=r.status_code,body=r.json())
        for model in ['deepseek-v4-pro','deepseek-v4-flash']:
            r=await invoke(model,response_format={'type':'json_object'}); save('F03_response_format_both',model=model,status=r.status_code,body=r.json())
            mode='ok'; text='{"ok":true}'; calls.clear()
            r=await invoke(model,response_schema={'type':'object','required':['ok'],'properties':{'ok':{'type':'boolean'}}})
            save('A03_F03_schema',model=model,status=r.status_code,body=r.json(),wire=calls.copy(),trace=tracing.list_traces()[-1].model_dump(mode='json'))
            for value in ['not json','', '{"ok":']:
                text=value; calls.clear(); r=await invoke(model,response_schema={'type':'object'})
                save('F04',model=model,content=value,status=r.status_code,body=r.json(),calls=len(calls),trace=tracing.list_traces()[-1].model_dump(mode='json'))
            text='{"ok":"wrong type"}'; r=await invoke(model,response_schema={'type':'object','properties':{'ok':{'type':'boolean'}}})
            save('F04_schema_mismatch',model=model,status=r.status_code,body=r.json())
            text='{"ok":true}'
            for fault in ['ok','disconnect'] + (['failed_event'] if model.endswith('pro') else []):
                mode=fault; calls.clear(); release=asyncio.Event()
                request=LLMRequest(model=model,messages=[{'role':'user','content':'teacher'}])
                # Drive the real ASGI StreamingResponse send callback: content must arrive while upstream terminal is gated.
                queue=asyncio.Queue()
                async def send(message):
                    if message['type']=='http.response.body' and message.get('body'): await queue.put(message['body'].decode())
                async def receive(): await asyncio.Event().wait()
                prepared=service.prepare_stream(request)
                from fastapi.responses import StreamingResponse
                response=StreamingResponse(service.stream_events(request,*prepared),media_type='text/event-stream')
                task=asyncio.create_task(response({'type':'http','asgi':{'spec_version':'2.4'}},receive,send))
                first=await asyncio.wait_for(queue.get(),2)
                gate=not release.is_set() and not task.done()
                release.set(); await task
                rest=[]
                while not queue.empty(): rest.append(queue.get_nowait())
                save('F01_F02',model=model,fault=fault,gated_delta=gate,first=first,rest=rest,calls=len(calls),trace=tracing.list_traces()[-1].model_dump(mode='json'))
                release=None
        mode='ok'
        for version,variables in [('v1',{'product_name':'教师甲'}),('v2',{'product_name':'教师乙','response_style':'简短'}),('v1',{'product_name':'教师丙'}),('absent',{}),('v1',{})]:
            calls.clear(); before=len(tracing.list_traces())
            r=await invoke(prompt={'name':'knowledge_decision','version':version,'variables':variables})
            save('F05_F06',version=version,variables=variables,status=r.status_code,body=r.json(),wire=calls.copy(),trace_added=len(tracing.list_traces())-before)
        r=await invoke(prompt={'name':'absent','version':'v1','variables':{}}); save('F06_missing_template',status=r.status_code,body=r.json())
        waits=[]
        async def no_wait(delay): waits.append(delay)
        for model in ['deepseek-v4-pro','deepseek-v4-flash']:
            for fault in ['retry_success','429','400','500','timeout']:
                mode=fault; calls.clear(); waits.clear()
                with patch.object(retry,'sleep',no_wait):
                    r=await invoke(model,**({'response_schema':{'type':'object'}} if fault=='400' else {}))
                save('F08_F09',model=model,fault=fault,status=r.status_code,body=r.json(),wire_count=len(calls),waits=waits.copy(),trace=tracing.list_traces()[-1].model_dump(mode='json'))
        mode='ok'; os.environ.update(RATE_LIMIT_REQUESTS='1',RATE_LIMIT_WINDOW_SECONDS='0.06'); rate_limit.reset_limiters()
        statuses=[]
        for model in ['deepseek-v4-pro','deepseek-v4-pro','deepseek-v4-flash']:
            r=await invoke(model); statuses.append(r.status_code)
        await asyncio.sleep(.075); r=await invoke(); statuses.append(r.status_code)
        save('F10_F11',statuses=statuses,expected=[200,429,200,200])
        save('F07',traces=[t.model_dump(mode='json') for t in tracing.list_traces()])
    for client in clients: await client.close()
    with open('/tmp/kevin-grade/evidence/teacher-results.json','w') as f: json.dump(records,f,ensure_ascii=False,indent=2)

with patch.object(OpenAIResponsesAdapter,'create_client',factory(AsyncOpenAI)),patch.object(AnthropicMessagesAdapter,'create_client',factory(AsyncAnthropic)):
    asyncio.run(main())
