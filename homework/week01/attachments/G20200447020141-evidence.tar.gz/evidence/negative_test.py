"""Intentional failing control: validate verify.sh reports a broken expectation."""
def test_intentional_negative_control():
    from fastapi.testclient import TestClient
    from app.main import app
    r=TestClient(app).post('/v1/llm',json={'model':'teacher-not-registered','messages':[{'role':'user','content':'x'}]})
    assert r.status_code == 200, 'INTENTIONAL CONTROL: unknown model must not actually succeed'
