import json, time, urllib.request, urllib.error

BASE = 'http://127.0.0.1:8000'
results = []
for model in ['deepseek-v4-pro', 'deepseek-v4-flash']:
    for mode in ['normal', 'structured', 'stream']:
        payload = {'model': model, 'messages': [{'role': 'user', 'content': 'Return only JSON {"ok":true}. Do not think.'}], 'timeout_seconds': 8, 'max_output_tokens': 128}
        if mode == 'structured':
            payload['response_schema'] = {'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}
        if mode == 'stream':
            payload['stream'] = True
        path = '/v1/llm/stream' if mode == 'stream' else '/v1/llm'
        start = time.monotonic()
        try:
            with urllib.request.urlopen(urllib.request.Request(BASE+path, data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'}), timeout=40) as r:
                status, body = r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            status, body = e.code, e.read().decode()
        except Exception as e:
            status, body = None, type(e).__name__
        row = dict(model=model, mode=mode, status=status, elapsed_ms=round((time.monotonic()-start)*1000), body=body)
        results.append(row)
        print(json.dumps(row,ensure_ascii=False),flush=True)
with urllib.request.urlopen(BASE+'/v1/traces') as r:
    traces = json.load(r)
with open('/tmp/kevin-grade/evidence/real-results.json','w') as f:
    json.dump({'results':results,'traces':traces},f,ensure_ascii=False,indent=2)
