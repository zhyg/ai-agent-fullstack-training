"""SSE 事件编码。

统一事件格式，浏览器与 Agent 均可直接消费。
"""

from __future__ import annotations

import json
from typing import Any

EVENT_CONTENT_DELTA = "content.delta"
EVENT_RESPONSE_COMPLETED = "response.completed"
EVENT_RESPONSE_FAILED = "response.failed"


def encode_sse(event: dict[str, Any]) -> str:
    """将统一事件编码为 SSE 帧。"""
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
