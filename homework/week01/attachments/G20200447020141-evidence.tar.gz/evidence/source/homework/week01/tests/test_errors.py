"""FR-6 统一错误码封装。"""

from __future__ import annotations

from app.errors import ERROR_CATALOG
from tests.conftest import make_request


def test_error_body_has_stable_shape(client):
    resp = client.post("/v1/llm", json=make_request(model="not-registered"))

    assert resp.status_code == 400
    body = resp.json()["error"]
    assert set(body) == {"code", "message", "details"}
    assert body["code"] == "unknown_model"


def test_error_response_leaks_no_vendor_details(client):
    resp = client.post("/v1/llm", json=make_request(model="not-registered"))
    text = resp.text

    assert "Traceback" not in text
    assert "openai" not in text.lower()
    assert "anthropic" not in text.lower()


def test_missing_credentials_returns_503(client, monkeypatch):
    """未配置密钥时在适配器构造阶段失败，且不发起网络请求。"""
    monkeypatch.delenv("DEEPSEEK_API_KEY", raising=False)

    resp = client.post("/v1/llm", json=make_request())

    assert resp.status_code == 503
    assert resp.json()["error"]["code"] == "gateway_misconfigured"


def test_unknown_request_field_is_rejected(client):
    resp = client.post("/v1/llm", json=make_request(temperature=0.7))

    assert resp.status_code == 422
    assert resp.json()["error"]["code"] == "invalid_request"


def test_every_code_has_http_status():
    for code, (status, _desc) in ERROR_CATALOG.items():
        assert 400 <= status <= 503, code
