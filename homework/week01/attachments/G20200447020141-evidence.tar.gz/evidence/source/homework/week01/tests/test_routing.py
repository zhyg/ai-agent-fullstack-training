"""FR-1 统一抽象层与动态路由。"""

from __future__ import annotations

from pathlib import Path

from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.base import AdapterRequest
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.config import get_model_config
from app.registry import register_adapter, resolve
from app.schemas import Message
from tests.conftest import FakeAdapter, make_request

ROOT = Path(__file__).resolve().parents[1]


def test_two_models_route_to_different_adapters(client):
    pro = FakeAdapter("openai_responses", content="from-pro")
    flash = FakeAdapter("anthropic_messages", content="from-flash")
    register_adapter("deepseek-v4-pro", pro)
    register_adapter("deepseek-v4-flash", flash)

    resp_pro = client.post("/v1/llm", json=make_request(model="deepseek-v4-pro"))
    resp_flash = client.post("/v1/llm", json=make_request(model="deepseek-v4-flash"))

    assert resp_pro.status_code == 200
    assert resp_flash.status_code == 200
    assert resp_pro.json()["content"] == "from-pro"
    assert resp_flash.json()["content"] == "from-flash"
    assert resp_pro.json()["protocol"] == "openai_responses"
    assert resp_flash.json()["protocol"] == "anthropic_messages"
    assert len(pro.calls) == 1 and len(flash.calls) == 1


def test_registry_resolves_protocol_by_model():
    config_pro, adapter_pro = resolve("deepseek-v4-pro")
    config_flash, adapter_flash = resolve("deepseek-v4-flash")

    assert config_pro.protocol == "openai_responses"
    assert config_flash.protocol == "anthropic_messages"
    assert isinstance(adapter_pro, OpenAIResponsesAdapter)
    assert isinstance(adapter_flash, AnthropicMessagesAdapter)
    assert adapter_pro.protocol != adapter_flash.protocol


def test_unknown_model_returns_stable_code(client):
    resp = client.post("/v1/llm", json=make_request(model="not-registered"))

    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "unknown_model"


def test_orchestration_layer_has_no_vendor_sdk_import():
    service_src = (ROOT / "app" / "service.py").read_text(encoding="utf-8")
    router_src = (ROOT / "app" / "router.py").read_text(encoding="utf-8")
    registry_src = (ROOT / "app" / "registry.py").read_text(encoding="utf-8")

    for src in (service_src, router_src):
        assert "openai" not in src
        assert "anthropic" not in src
    # 注册表只允许出现工厂映射，不允许出现协议分支判断
    assert "if model ==" not in registry_src


def test_models_endpoint_exposes_protocols(client):
    models = {m["alias"]: m for m in client.get("/v1/models").json()}

    assert models["deepseek-v4-pro"]["protocol"] == "openai_responses"
    assert models["deepseek-v4-flash"]["protocol"] == "anthropic_messages"


def test_protocol_payload_shapes_are_isolated():
    """两种协议的请求体结构差异被收敛在适配器内部。"""
    config_pro = get_model_config("deepseek-v4-pro")
    config_flash = get_model_config("deepseek-v4-flash")
    request = AdapterRequest(
        config=config_pro,
        messages=[Message(role="user", content="你好")],
        system="你是助手",
        max_output_tokens=128,
    )

    openai_payload = OpenAIResponsesAdapter()._build_payload(request)
    request_flash = AdapterRequest(
        config=config_flash,
        messages=request.messages,
        system="你是助手",
        max_output_tokens=128,
    )
    anthropic_payload = AnthropicMessagesAdapter()._build_payload(request_flash)

    # OpenAI Responses：系统指令走 instructions，长度字段为 max_output_tokens
    assert openai_payload["instructions"] == "你是助手"
    assert openai_payload["max_output_tokens"] == 128
    assert "input" in openai_payload

    # Anthropic Messages：system 独立字段，必填 max_tokens
    assert anthropic_payload["system"] == "你是助手"
    assert anthropic_payload["max_tokens"] == 128
    assert "messages" in anthropic_payload
    assert "instructions" not in anthropic_payload
