"""指数退避重试。

仅对可重试故障重试；参数类错误与结果校验失败（GatewayError）不重试。
总计最多发起 RETRY_MAX_ATTEMPTS 次上游调用（首发 + 重试）。
"""

from __future__ import annotations

import asyncio
import logging
import random
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar

from anthropic import APIConnectionError as AnthropicConnectionError
from anthropic import APITimeoutError as AnthropicTimeoutError
from anthropic import RateLimitError as AnthropicRateLimitError
from openai import APIConnectionError, APITimeoutError, RateLimitError

from app import config as app_config
from app.errors import GatewayError, RetryableUpstreamError

logger = logging.getLogger("llm_gateway.retry")

T = TypeVar("T")

# 可重试的上游故障：连接失败、超时、限流
RETRYABLE_EXCEPTION_TYPES: tuple[type[BaseException], ...] = (
    APIConnectionError,
    APITimeoutError,
    RateLimitError,
    AnthropicConnectionError,
    AnthropicTimeoutError,
    AnthropicRateLimitError,
    RetryableUpstreamError,
    TimeoutError,
    ConnectionError,
)

# 测试可替换为不真正等待的协程
sleep = asyncio.sleep


def is_retryable(exc: BaseException) -> bool:
    return isinstance(exc, RETRYABLE_EXCEPTION_TYPES)


def compute_delay(
    attempt: int,
    base_delay: float,
    backoff_factor: float,
    max_delay: float,
    jitter: bool = True,
) -> float:
    """计算第 attempt 次重试前的等待时间（attempt 从 1 开始）。"""
    delay = base_delay * (backoff_factor ** (attempt - 1))
    if jitter:
        delay *= 1 + random.uniform(0, 0.2)
    return min(delay, max_delay)


async def run_with_retry(
    operation: Callable[[], Awaitable[T]],
    *,
    max_attempts: int | None = None,
    base_delay: float | None = None,
    backoff_factor: float | None = None,
    max_delay: float | None = None,
    jitter: bool = True,
    on_retry: Callable[[int, BaseException, float], None] | None = None,
) -> tuple[T, int]:
    """执行带指数退避的异步操作，返回 (结果, 实际尝试次数)。"""
    max_attempts = max_attempts or app_config.retry_max_attempts()
    base_delay = base_delay if base_delay is not None else app_config.retry_base_delay()
    backoff_factor = backoff_factor or app_config.retry_backoff_factor()
    max_delay = max_delay or app_config.retry_max_delay()

    attempts = 0
    last_error: BaseException | None = None
    for attempt in range(1, max_attempts + 1):
        attempts = attempt
        try:
            return await operation(), attempts
        except GatewayError:
            # 业务错误（参数、校验、凭据）不重试
            raise
        except RETRYABLE_EXCEPTION_TYPES as exc:
            last_error = exc
            if attempt >= max_attempts:
                break
            delay = compute_delay(attempt, base_delay, backoff_factor, max_delay, jitter)
            logger.warning("retry attempt=%s delay=%.3fs error=%s", attempt, delay, type(exc).__name__)
            if on_retry is not None:
                on_retry(attempt, exc, delay)
            await sleep(delay)
        except BaseException as exc:
            last_error = exc
            break
    raise (last_error or RuntimeError("retry failed")) from None


def retry_settings() -> dict[str, Any]:
    return {
        "max_attempts": app_config.retry_max_attempts(),
        "base_delay": app_config.retry_base_delay(),
        "backoff_factor": app_config.retry_backoff_factor(),
        "max_delay": app_config.retry_max_delay(),
    }
