#!/usr/bin/env bash
# 对运行中的网关执行 curl 示例，输出即为功能点证据
# 用法: GATEWAY_URL=http://127.0.0.1:8000 bash scripts/curl_examples.sh
set -uo pipefail
GATEWAY_URL="${GATEWAY_URL:-http://127.0.0.1:8000}"

hr() { echo; echo "=============== $1 ==============="; }

hr "0. 健康检查与模型清单"
curl -s "$GATEWAY_URL/health"; echo
curl -s "$GATEWAY_URL/v1/models" | head -c 600; echo

hr "1. 统一调用（OpenAI Responses 协议 / deepseek-v4-pro）"
curl -s -X POST "$GATEWAY_URL/v1/llm" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"用一句话介绍你自己"}]}' \
  | head -c 800; echo

hr "2. 统一调用（Anthropic Messages 协议 / deepseek-v4-flash）"
curl -s -X POST "$GATEWAY_URL/v1/llm" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"用一句话介绍你自己"}]}' \
  | head -c 800; echo

hr "2b. Chat Completions 协议（第三种协议，两个厂商）"
curl -s -X POST "$GATEWAY_URL/v1/llm" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"用一句话介绍你自己"}]}' \
  | head -c 800; echo
curl -s -X POST "$GATEWAY_URL/v1/llm" \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-flash","messages":[{"role":"user","content":"用一句话介绍你自己"}]}' \
  | head -c 800; echo

hr "3. 流式输出（SSE，逐块返回）"
curl -sN -X POST "$GATEWAY_URL/v1/llm/stream" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"讲一个短句"}]}' \
  | head -c 800; echo

hr "4. 结构化输出"
curl -s -X POST "$GATEWAY_URL/v1/llm" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"判断是否需要检索"}],"response_schema":{"type":"object","properties":{"decision":{"type":"string"},"reason":{"type":"string"}},"required":["decision"],"additionalProperties":false}}' \
  | head -c 800; echo

hr "5. 提示词模板引用（版本 + 变量）"
curl -s -X POST "$GATEWAY_URL/v1/llm" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"用户问：报销流程是什么"}],"prompt":{"name":"knowledge_decision","version":"v1","variables":{"product_name":"报销助手"}}}' \
  | head -c 800; echo

hr "6. 可观测数据"
echo "-- 最近 5 条追踪 --"
curl -s "$GATEWAY_URL/v1/traces?limit=5" | head -c 900; echo
echo "-- 聚合指标（Token 分类 + 延迟/TTFT）--"
curl -s "$GATEWAY_URL/v1/metrics" | head -c 900; echo

hr "7. 限流（连续打满后返回 429）"
for i in $(seq 1 3); do
  printf "第 %s 次: " "$i"
  curl -s -o /dev/null -w "%{http_code}\n" -X POST "$GATEWAY_URL/v1/llm" \
    -H "Content-Type: application/json" \
    -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"hi"}]}'
done

hr "8. 统一错误码（未注册模型 / 未知模板 / 缺变量）"
curl -s -X POST "$GATEWAY_URL/v1/llm" -H "Content-Type: application/json" \
  -d '{"model":"not-registered","messages":[{"role":"user","content":"hi"}]}'; echo
curl -s -X POST "$GATEWAY_URL/v1/llm" -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"hi"}],"prompt":{"name":"knowledge_decision","version":"v9"}}'; echo
curl -s -X POST "$GATEWAY_URL/v1/llm" -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"hi"}],"prompt":{"name":"knowledge_decision","version":"v1"}}'; echo
