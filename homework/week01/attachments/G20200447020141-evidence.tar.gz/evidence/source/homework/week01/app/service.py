"""编排层：路由分发 -> 限流 -> 重试 -> 结果校验 -> 审计埋点。

本文件不 import 任何供应商 SDK，只依赖 adapters.base 的抽象。
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import AsyncIterator
from typing import Any

from jsonschema import ValidationError as JsonSchemaError
from jsonschema import validate

from app import sse as sse_codec
from app.adapters.base import LLMAdapter, AdapterRequest
from app.config import ModelConfig
from app.errors import (
    INVALID_JSON,
    INVALID_REQUEST,
    MODEL_UNAVAILABLE,
    SCHEMA_VALIDATION_FAILED,
    STRUCTURED_OUTPUT_UNSUPPORTED,
    UPSTREAM_STREAM_FAILED,
    GatewayError,
)
from app.observability import tracing
from app.prompt import store as prompt_store
from app.registry import resolve
from app.resilience import rate_limit
from app.resilience.retry import run_with_retry 
from app.schemas import LLMRequest, LLMResponse, Message, Usage

logger = logging.getLogger("llm_gateway.service")


def build_context(request: LLMRequest) -> tuple[str | None, list[Message]]:
    """把模板系统消息与请求中的 system 消息合并，拆出 system 与对话消息。"""
    system_parts: list[str] = []
    if request.prompt is not None:
        system_parts.append(prompt_store.render(request.prompt))
    system_parts.extend(m.content for m in request.messages if m.role == "system")
    messages = [m for m in request.messages if m.role != "system"]
    if not messages:
        raise GatewayError(INVALID_REQUEST, "至少需要一条 user 或 assistant 消息", 400)
    system = "\n\n".join(part for part in system_parts if part) or None
    return system, messages


def preflight(request: LLMRequest) -> tuple[ModelConfig, LLMAdapter]:
    """前置校验：解析模型 -> 校验能力 -> 限流（未知模型不消耗配额）。"""
    config, adapter = resolve(request.model)
    if request.response_schema is not None and not config.supports_structured_output:
        raise GatewayError(
            STRUCTURED_OUTPUT_UNSUPPORTED,
            f"模型 {config.alias} 不支持 Structured Output",
            400,
        )
    rate_limit.enforce(config.alias)
    return config, adapter


def prepare_stream(
    request: LLMRequest,
) -> tuple[ModelConfig, LLMAdapter, str | None, list[Message]]:
    """流式预检：在进入 StreamingResponse 之前完成全部可能失败的前置操作。"""
    config, adapter = preflight(request)
    system, messages = build_context(request)
    return config, adapter, system, messages


def parse_structured(content: str, schema: dict[str, Any]) -> Any:
    """后置校验：模型输出必须可被解析且符合 response_schema。"""
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise GatewayError(INVALID_JSON, "模型没有返回合法 JSON") from exc
    try:
        validate(instance=parsed, schema=schema)
    except JsonSchemaError as exc:
        raise GatewayError(SCHEMA_VALIDATION_FAILED, "模型结果不符合 response_schema") from exc
    return parsed


def _prompt_meta(request: LLMRequest) -> tuple[str | None, str | None]:
    if request.prompt is None:
        return None, None
    return request.prompt.name, request.prompt.version


async def complete(request: LLMRequest) -> LLMResponse:
    """统一非流式调用入口。"""
    config, adapter = preflight(request)
    request_id = tracing.new_request_id()
    started = time.perf_counter()
    system, messages = build_context(request)
    prompt_name, prompt_version = _prompt_meta(request)

    adapter_request = AdapterRequest(
        config=config,
        messages=messages,
        system=system,
        timeout_seconds=request.timeout_seconds,
        max_output_tokens=request.max_output_tokens,
        response_schema=request.response_schema,
    )

    state = {"attempts": 0}

    async def call() -> Any:
        state["attempts"] += 1
        return await adapter.complete(adapter_request)

    try:
        result, _ = await run_with_retry(call)
        parsed = None
        if request.response_schema is not None:
            parsed = parse_structured(result.content, request.response_schema)
        latency_ms = int((time.perf_counter() - started) * 1000)
        response = LLMResponse(
            request_id=request_id,
            model=config.alias,
            protocol=config.protocol,
            content=result.content,
            parsed=parsed,
            usage=result.usage,
            latency_ms=latency_ms,
            attempts=state["attempts"],
        )
        tracing.record_trace(
            request_id=request_id,
            config=config,
            stream=False,
            usage=result.usage,
            latency_ms=latency_ms,
            attempts=state["attempts"],
            status="success",
            prompt_name=prompt_name,
            prompt_version=prompt_version,
        )
        return response
    except GatewayError as exc:
        tracing.record_trace(
            request_id=request_id,
            config=config,
            stream=False,
            usage=Usage(input_tokens=0, output_tokens=0),
            latency_ms=int((time.perf_counter() - started) * 1000),
            attempts=state["attempts"],
            status="failed",
            prompt_name=prompt_name,
            prompt_version=prompt_version,
            error_code=exc.code,
        )
        raise
    except Exception as exc:
        logger.exception("upstream call failed", exc_info=exc)
        tracing.record_trace(
            request_id=request_id,
            config=config,
            stream=False,
            usage=Usage(input_tokens=0, output_tokens=0),
            latency_ms=int((time.perf_counter() - started) * 1000),
            attempts=state["attempts"],
            status="failed",
            prompt_name=prompt_name,
            prompt_version=prompt_version,
            error_code=MODEL_UNAVAILABLE,
        )
        raise GatewayError(MODEL_UNAVAILABLE, "上游模型不可用") from exc


async def stream_events(
    request: LLMRequest,
    config: ModelConfig,
    adapter: LLMAdapter,
    system: str | None,
    messages: list[Message],
) -> AsyncIterator[str]:
    """流式事件生成器：首块用于测量 TTFT；已产出文本后不再重试，避免文本重复。"""
    request_id = tracing.new_request_id()
    started = time.perf_counter()
    prompt_name, prompt_version = _prompt_meta(request)
    adapter_request = AdapterRequest(
        config=config,
        messages=messages,
        system=system,
        timeout_seconds=request.timeout_seconds,
        max_output_tokens=request.max_output_tokens,
    )

    usage = Usage(input_tokens=0, output_tokens=0)
    ttft_ms: int | None = None
    attempts = 1
    try:
        async for event in adapter.stream(adapter_request):
            if event.delta:
                if ttft_ms is None:
                    ttft_ms = int((time.perf_counter() - started) * 1000)
                yield sse_codec.encode_sse(
                    {"type": sse_codec.EVENT_CONTENT_DELTA, "delta": event.delta}
                )
            if event.usage is not None:
                usage = event.usage
        latency_ms = int((time.perf_counter() - started) * 1000)
        tracing.record_trace(
            request_id=request_id,
            config=config,
            stream=True,
            usage=usage,
            latency_ms=latency_ms,
            attempts=attempts,
            status="success",
            prompt_name=prompt_name,
            prompt_version=prompt_version,
            ttft_ms=ttft_ms,
        )
        yield sse_codec.encode_sse(
            {
                "type": sse_codec.EVENT_RESPONSE_COMPLETED,
                "model": config.alias,
                "protocol": config.protocol,
                "usage": usage.model_dump(),
                "latency_ms": latency_ms,
                "ttft_ms": ttft_ms,
            }
        )
    except Exception as exc:
        logger.exception("upstream stream failed", exc_info=exc)
        error_code = exc.code if isinstance(exc, GatewayError) else UPSTREAM_STREAM_FAILED
        latency_ms = int((time.perf_counter() - started) * 1000)
        tracing.record_trace(
            request_id=request_id,
            config=config,
            stream=True,
            usage=Usage(input_tokens=0, output_tokens=0),
            latency_ms=latency_ms,
            attempts=attempts,
            status="failed",
            prompt_name=prompt_name,
            prompt_version=prompt_version,
            ttft_ms=ttft_ms,
            error_code=error_code,
        )
        yield sse_codec.encode_sse(
            {"type": sse_codec.EVENT_RESPONSE_FAILED, "error": error_code}
        )


async def stream_response(request: LLMRequest) -> AsyncIterator[str]:
    """供测试与脚本直接使用的一次性流式入口。"""
    config, adapter, system, messages = prepare_stream(request)
    async for chunk in stream_events(request, config, adapter, system, messages):
        yield chunk
