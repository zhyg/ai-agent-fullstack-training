"""调用追踪：每次调用落一条元数据记录，默认不存正文。"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from threading import Lock
from typing import Literal
from uuid import uuid4

from app.config import ModelConfig, calculate_cost
from app.schemas import CallTrace, Usage

logger = logging.getLogger("llm_gateway.trace")

_LOCK = Lock()
CALL_TRACES: list[CallTrace] = []


def new_request_id() -> str:
    return str(uuid4())


def record_trace(
    *,
    request_id: str,
    config: ModelConfig,
    stream: bool,
    usage: Usage,
    latency_ms: int,
    attempts: int,
    status: Literal["success", "failed"],
    prompt_name: str | None = None,
    prompt_version: str | None = None,
    ttft_ms: int | None = None,
    error_code: str | None = None,
) -> CallTrace:
    trace = CallTrace(
        request_id=request_id,
        timestamp=datetime.now(timezone.utc),
        model=config.alias,
        protocol=config.protocol,
        provider_model=config.provider_model,
        stream=stream,
        prompt_name=prompt_name,
        prompt_version=prompt_version,
        input_tokens=usage.input_tokens,
        output_tokens=usage.output_tokens,
        cost_usd=calculate_cost(config, usage.input_tokens, usage.output_tokens),
        latency_ms=latency_ms,
        ttft_ms=ttft_ms,
        attempts=attempts,
        status=status,
        error_code=error_code,
    )
    with _LOCK:
        CALL_TRACES.append(trace)
    logger.info("llm_call_trace=%s", trace.model_dump_json())
    return trace


def list_traces(limit: int | None = None) -> list[CallTrace]:
    with _LOCK:
        traces = list(CALL_TRACES)
    if limit is not None:
        return traces[-limit:]
    return traces


def clear_traces() -> None:
    with _LOCK:
        CALL_TRACES.clear()
