"""FR-8 按模型独立限流。"""

from __future__ import annotations

from app.observability import tracing
from app.registry import register_adapter
from app.resilience import rate_limit
from tests.conftest import FakeAdapter, make_request


def _setup(monkeypatch, limit: int = 2) -> tuple[FakeAdapter, FakeAdapter]:
    monkeypatch.setenv("RATE_LIMIT_REQUESTS", str(limit))
    rate_limit.reset_limiters()
    pro = FakeAdapter("openai_responses")
    flash = FakeAdapter("anthropic_messages")
    register_adapter("deepseek-v4-pro", pro)
    register_adapter("deepseek-v4-flash", flash)
    return pro, flash


def test_exceeding_limit_returns_429(client, monkeypatch):
    pro, _flash = _setup(monkeypatch, limit=2)

    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 200
    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 200
    blocked = client.post("/v1/llm", json=make_request(model="deepseek-v4-pro"))

    assert blocked.status_code == 429
    assert blocked.json()["error"]["code"] == "rate_limited"
    assert blocked.json()["error"]["details"]["limit"] == 2
    # 超限请求不再消耗上游资源
    assert len(pro.calls) == 2


def test_rate_limit_counters_are_independent_per_model(client, monkeypatch):
    pro, flash = _setup(monkeypatch, limit=1)

    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 200
    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 429
    # 打满 pro 不影响 flash
    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-flash")).status_code == 200
    assert len(flash.calls) == 1


def test_blocked_request_produces_no_trace(client, monkeypatch):
    _setup(monkeypatch, limit=1)

    client.post("/v1/llm", json=make_request(model="deepseek-v4-pro"))
    client.post("/v1/llm", json=make_request(model="deepseek-v4-pro"))

    assert len(tracing.list_traces()) == 1


def test_limiter_window_allows_after_reset(client, monkeypatch):
    _setup(monkeypatch, limit=1)

    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 200
    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 429

    rate_limit.reset_limiters()
    assert client.post("/v1/llm", json=make_request(model="deepseek-v4-pro")).status_code == 200
