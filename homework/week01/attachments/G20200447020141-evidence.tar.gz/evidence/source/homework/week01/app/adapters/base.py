"""适配器抽象接口与协议无关的请求/结果模型。

编排层只依赖本文件中的抽象，不依赖任何供应商 SDK。
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any, ClassVar

from app.config import ModelConfig
from app.errors import STRUCTURED_OUTPUT_UNSUPPORTED, GatewayError
from app.schemas import Message, Usage

SCHEMA_INSTRUCTION = (
    "只返回一个合法 JSON 对象，必须严格符合下列 JSON Schema，"
    "不要返回 Markdown 代码块或任何额外文字："
)


def normalize_strict_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """归一化为 strict json_schema 兼容形式。

    Responses API 的 strict 模式要求 required 覆盖全部 properties，
    且显式声明 additionalProperties=False，否则上游直接拒绝请求。
    """
    normalized = dict(schema)
    properties = normalized.get("properties")
    if isinstance(properties, dict) and properties:
        required = set(normalized.get("required") or [])
        required.update(properties.keys())
        normalized["required"] = sorted(required)
        normalized["additionalProperties"] = False
    return normalized


def build_prompt_instruction(schema: dict[str, Any]) -> str:
    """生成提示词形式的 JSON 约束说明，供无原生能力的协议兜底。"""
    return SCHEMA_INSTRUCTION + json.dumps(schema, ensure_ascii=False)


@dataclass(frozen=True)
class AdapterRequest:
    """协议无关的上游调用请求。system 已从 messages 中拆出。"""

    config: ModelConfig
    messages: list[Message]
    system: str | None = None
    timeout_seconds: float = 30.0
    max_output_tokens: int = 1_024
    response_schema: dict[str, Any] | None = None


@dataclass(frozen=True)
class StructuredPlan:
    """结构化输出的执行方案，三种方式互斥。

    native_schema：协议原生 json_schema 约束（能力最强）
    json_object ：协议原生保证输出合法 JSON，具体字段由网关后置校验
    system 注入 ：无原生能力时的提示词兜底
    """

    system: str | None = None
    native_schema: dict[str, Any] | None = None
    json_object: bool = False


@dataclass(frozen=True)
class CompletionResult:
    content: str
    usage: Usage


@dataclass(frozen=True)
class StreamEvent:
    """流式事件：增量文本或结束时的用量。"""

    delta: str | None = None
    usage: Usage | None = None


class LLMAdapter(ABC):
    """供应商适配器统一接口。"""

    protocol: ClassVar[str]

    @abstractmethod
    async def complete(self, request: AdapterRequest) -> CompletionResult: ...

    @abstractmethod
    def stream(self, request: AdapterRequest) -> AsyncIterator[StreamEvent]: ...

    # --- 子类可复用的通用处理 ---

    def resolve_structured_output(self, request: AdapterRequest) -> StructuredPlan:
        """按模型配置决定结构化输出的处理方式。"""
        if request.response_schema is None:
            return StructuredPlan(system=request.system)
        if not request.config.supports_structured_output:
            raise GatewayError(
                STRUCTURED_OUTPUT_UNSUPPORTED,
                f"模型 {request.config.alias} 不支持 Structured Output",
                400,
            )
        mode = request.config.structured_output_mode
        if mode == "native_schema":
            return StructuredPlan(system=request.system, native_schema=request.response_schema)
        if mode == "json_object":
            # 协议只保证输出合法 JSON，具体结构仍靠提示词描述 + 网关后置校验；
            # 部分厂商（如 DeepSeek）还要求提示词中出现 "json" 字样才会启用该模式。
            instruction = build_prompt_instruction(request.response_schema)
            system = f"{instruction}\n\n{request.system}" if request.system else instruction
            return StructuredPlan(system=system, json_object=True)
        instruction = build_prompt_instruction(request.response_schema)
        system = f"{instruction}\n\n{request.system}" if request.system else instruction
        return StructuredPlan(system=system)
