"""Anthropic Messages API 适配器。

协议要点（与 OpenAI Responses 的差异全部收敛在此）：
- 认证头：x-api-key + anthropic-version（由 SDK 处理）
- 请求体：system 独立字段、messages、必填 max_tokens
- 结构化输出：协议无原生 json_schema，走提示词约束 + 网关后置校验
- 返回：content 为 block 数组，需拼接 text；用量为 usage.input_tokens/output_tokens
- 流式事件：content_block_delta（与 OpenAI 的 delta 事件名不同）
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any, ClassVar

from anthropic import AsyncAnthropic

from app.adapters.base import (
    AdapterRequest,
    CompletionResult,
    LLMAdapter,
    StreamEvent,
    build_prompt_instruction,
)
from app.config import ModelConfig, get_api_key
from app.errors import GATEWAY_MISCONFIGURED, GatewayError
from app.schemas import Message, Usage


class AnthropicMessagesAdapter(LLMAdapter):
    protocol: ClassVar[str] = "anthropic_messages"

    def create_client(self, config: ModelConfig) -> AsyncAnthropic:
        api_key = get_api_key(config)
        if not api_key:
            raise GatewayError(
                GATEWAY_MISCONFIGURED,
                f"环境变量 {config.api_key_env} 未配置",
                503,
            )
        return AsyncAnthropic(api_key=api_key, base_url=config.base_url, max_retries=0)

    @staticmethod
    def _to_messages(messages: list[Message]) -> list[dict[str, str]]:
        # Anthropic 的 system 必须独立传参，这里只保留 user/assistant
        return [{"role": m.role, "content": m.content} for m in messages]

    def _build_payload(self, request: AdapterRequest) -> dict[str, Any]:
        plan = self.resolve_structured_output(request)
        system = plan.system
        if plan.native_schema is not None or plan.json_object:
            # Messages 协议没有原生 JSON 约束能力，退化为提示词约束 + 网关后置校验
            instruction = build_prompt_instruction(request.response_schema or {})
            system = f"{instruction}\n\n{system}" if system else instruction
        payload: dict[str, Any] = {
            "model": request.config.provider_model,
            "messages": self._to_messages(request.messages),
            "max_tokens": request.max_output_tokens,
            "timeout": request.timeout_seconds,
        }
        if system:
            payload["system"] = system
        return payload

    @staticmethod
    def _extract_content(response: Any) -> str:
        blocks = getattr(response, "content", None) or []
        return "".join(
            getattr(block, "text", "")
            for block in blocks
            if getattr(block, "type", None) == "text"
        )

    @staticmethod
    def _extract_usage(response: Any) -> Usage:
        usage = getattr(response, "usage", None)
        return Usage(
            input_tokens=getattr(usage, "input_tokens", 0) or 0,
            output_tokens=getattr(usage, "output_tokens", 0) or 0,
        )

    async def complete(self, request: AdapterRequest) -> CompletionResult:
        client = self.create_client(request.config)
        response = await client.messages.create(**self._build_payload(request))
        return CompletionResult(
            content=self._extract_content(response),
            usage=self._extract_usage(response),
        )

    async def stream(self, request: AdapterRequest) -> AsyncIterator[StreamEvent]:
        client = self.create_client(request.config)
        async with client.messages.stream(**self._build_payload(request)) as stream:
            async for event in stream:
                if getattr(event, "type", None) == "content_block_delta":
                    delta = getattr(event, "delta", None)
                    text = getattr(delta, "text", None)
                    if text:
                        yield StreamEvent(delta=text)
            final = await stream.get_final_message()
            yield StreamEvent(usage=self._extract_usage(final))
