"""按模型独立限流（滑动窗口）。

每个平台模型别名拥有独立计数，互不影响；超限返回 429 且不再消耗上游资源。
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass

from app import config as app_config
from app.errors import RATE_LIMITED, GatewayError


@dataclass(frozen=True)
class RateLimitDecision:
    allowed: bool
    limit: int
    remaining: int
    retry_after: float
    window_seconds: float


class SlidingWindowLimiter:
    """滑动窗口限流器，按 key 独立计数。"""

    def __init__(self, limit: int, window_seconds: float) -> None:
        self.limit = limit
        self.window_seconds = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def _prune(self, key: str, now: float) -> deque[float]:
        hits = self._hits[key]
        while hits and now - hits[0] >= self.window_seconds:
            hits.popleft()
        return hits

    def peek(self, key: str) -> RateLimitDecision:
        """只查询不记录。"""
        now = time.monotonic()
        hits = self._prune(key, now)
        used = len(hits)
        if used >= self.limit:
            retry_after = max(self.window_seconds - (now - hits[0]), 0.0)
            return RateLimitDecision(False, self.limit, 0, retry_after, self.window_seconds)
        return RateLimitDecision(True, self.limit, self.limit - used, 0.0, self.window_seconds)

    def acquire(self, key: str) -> RateLimitDecision:
        """查询并在允许时记录一次命中。"""
        decision = self.peek(key)
        if decision.allowed:
            self._hits[key].append(time.monotonic())
            return RateLimitDecision(
                True, self.limit, decision.remaining - 1, 0.0, self.window_seconds
            )
        return decision

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self._hits.clear()
        else:
            self._hits.pop(key, None)


_LIMITERS: dict[str, SlidingWindowLimiter] = {}


def limiter_for(alias: str) -> SlidingWindowLimiter:
    limit = app_config.rate_limit_requests()
    window = app_config.rate_limit_window_seconds()
    limiter = _LIMITERS.get(alias)
    if limiter is None or (limiter.limit, limiter.window_seconds) != (limit, window):
        limiter = SlidingWindowLimiter(limit, window)
        _LIMITERS[alias] = limiter
    return limiter


def reset_limiters() -> None:
    _LIMITERS.clear()


def enforce(alias: str) -> RateLimitDecision:
    """编排层最前置调用：超限直接抛 429。"""
    decision = limiter_for(alias).acquire(alias)
    if not decision.allowed:
        raise GatewayError(
            RATE_LIMITED,
            f"模型 {alias} 已超过限流阈值",
            429,
            details={
                "limit": decision.limit,
                "window_seconds": decision.window_seconds,
                "retry_after": round(decision.retry_after, 3),
            },
        )
    return decision
