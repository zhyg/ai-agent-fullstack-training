"""统一错误码与异常封装。

所有内部异常都归一为 GatewayError，对外只暴露稳定的 code/message/HTTP 状态码，
禁止把供应商原始异常文本或堆栈直接透出给调用方。
"""

from __future__ import annotations

# --- 参数与配置类 ---
INVALID_REQUEST = "invalid_request"
UNKNOWN_MODEL = "unknown_model"
UNKNOWN_PROMPT_TEMPLATE = "unknown_prompt_template"
MISSING_PROMPT_VARIABLE = "missing_prompt_variable"
STRUCTURED_OUTPUT_UNSUPPORTED = "structured_output_unsupported"
UNSUPPORTED_COMBINATION = "unsupported_combination"
USE_STREAM_ENDPOINT = "use_stream_endpoint"

# --- 凭据与上游类 ---
GATEWAY_MISCONFIGURED = "gateway_misconfigured"
MODEL_UNAVAILABLE = "model_unavailable"
UPSTREAM_STREAM_FAILED = "upstream_stream_failed"

# --- 结果校验类 ---
INVALID_JSON = "invalid_json"
SCHEMA_VALIDATION_FAILED = "schema_validation_failed"

# --- 治理类 ---
RATE_LIMITED = "rate_limited"

ERROR_CATALOG: dict[str, tuple[int, str]] = {
    INVALID_REQUEST: (400, "请求参数不合法"),
    UNKNOWN_MODEL: (400, "model 不在网关注册表中"),
    UNKNOWN_PROMPT_TEMPLATE: (400, "Prompt 模板不存在"),
    MISSING_PROMPT_VARIABLE: (400, "缺少 Prompt 模板变量"),
    STRUCTURED_OUTPUT_UNSUPPORTED: (400, "该模型不支持结构化输出"),
    UNSUPPORTED_COMBINATION: (400, "参数组合不被支持"),
    USE_STREAM_ENDPOINT: (400, "流式请求请使用 /v1/llm/stream"),
    GATEWAY_MISCONFIGURED: (503, "网关凭据未配置"),
    MODEL_UNAVAILABLE: (502, "上游模型不可用"),
    UPSTREAM_STREAM_FAILED: (502, "上游流式调用失败"),
    INVALID_JSON: (502, "模型未返回合法 JSON"),
    SCHEMA_VALIDATION_FAILED: (502, "模型结果不符合 response_schema"),
    RATE_LIMITED: (429, "已触发按模型限流"),
}


class GatewayError(Exception):
    """可安全暴露给调用方的业务错误。"""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 502,
        details: dict | None = None,
    ) -> None:
        default_status = ERROR_CATALOG.get(code, (502, ""))[0]
        self.code = code
        self.message = message
        self.status_code = status_code or default_status
        self.details = details
        super().__init__(message)


class RetryableUpstreamError(Exception):
    """可重试的上游故障标记异常。

    真实的 SDK 异常（连接失败/超时/限流）由 is_retryable 识别；
    Fake 适配器与自定义上游使用本类型显式声明可重试。
    """
