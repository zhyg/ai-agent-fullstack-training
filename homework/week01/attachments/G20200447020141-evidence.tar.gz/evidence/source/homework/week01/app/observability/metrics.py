"""聚合指标：按模型分类统计 Token、成本、延迟（含首 Token 延迟 TTFT）。"""

from __future__ import annotations

import math
from datetime import datetime, timezone

from app.config import get_model_config
from app.observability.tracing import list_traces
from app.schemas import MetricsSnapshot, ModelMetrics


def _percentile(values: list[float], pct: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return float(ordered[0])
    position = (len(ordered) - 1) * pct / 100
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(ordered[int(position)])
    return float(ordered[lower]) * (upper - position) + float(ordered[upper]) * (position - lower)


def _average(values: list[float]) -> float | None:
    return round(sum(values) / len(values), 2) if values else None


def snapshot() -> MetricsSnapshot:
    traces = list_traces()
    grouped: dict[str, list] = {}
    for trace in traces:
        grouped.setdefault(trace.model, []).append(trace)

    models: list[ModelMetrics] = []
    for alias in sorted(grouped):
        items = grouped[alias]
        config = get_model_config(alias)
        successes = [t for t in items if t.status == "success"]
        ttfts = [t.ttft_ms for t in items if t.ttft_ms is not None]
        latencies = [float(t.latency_ms) for t in items]
        models.append(
            ModelMetrics(
                model=alias,
                protocol=config.protocol if config else items[0].protocol,
                requests=len(items),
                successes=len(successes),
                failures=len(items) - len(successes),
                input_tokens=sum(t.input_tokens for t in items),
                output_tokens=sum(t.output_tokens for t in items),
                cost_usd=round(sum(t.cost_usd for t in items), 6),
                avg_latency_ms=_average(latencies),
                p95_latency_ms=_percentile(latencies, 95),
                avg_ttft_ms=_average([float(v) for v in ttfts]),
                p95_ttft_ms=_percentile([float(v) for v in ttfts], 95),
            )
        )

    return MetricsSnapshot(
        total_requests=len(traces),
        total_successes=sum(1 for t in traces if t.status == "success"),
        total_failures=sum(1 for t in traces if t.status == "failed"),
        total_input_tokens=sum(t.input_tokens for t in traces),
        total_output_tokens=sum(t.output_tokens for t in traces),
        total_cost_usd=round(sum(t.cost_usd for t in traces), 6),
        models=models,
        generated_at=datetime.now(timezone.utc),
    )
