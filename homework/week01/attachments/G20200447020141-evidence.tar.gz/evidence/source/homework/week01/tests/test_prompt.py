"""FR-4 提示词版本管理。"""

from __future__ import annotations

from app import service
from app.prompt import store
from app.registry import register_adapter
from app.schemas import LLMRequest, Message, PromptSelection
from tests.conftest import FakeAdapter, make_request


def test_template_is_rendered_into_system(client):
    adapter = FakeAdapter("openai_responses")
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post(
        "/v1/llm",
        json=make_request(
            prompt={
                "name": "knowledge_decision",
                "version": "v1",
                "variables": {"product_name": "报销助手"},
            }
        ),
    )

    assert resp.status_code == 200
    system = adapter.calls[0].system
    assert system is not None
    assert "报销助手" in system
    assert "${product_name}" not in system
    # 模板渲染结果作为 system 注入，不进入对话消息
    assert all(m.role != "system" for m in adapter.calls[0].messages)


def test_unknown_template_version_is_rejected(client):
    resp = client.post(
        "/v1/llm",
        json=make_request(prompt={"name": "knowledge_decision", "version": "v9", "variables": {}}),
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "unknown_prompt_template"


def test_missing_variable_is_rejected(client):
    resp = client.post(
        "/v1/llm",
        json=make_request(prompt={"name": "knowledge_decision", "version": "v1"}),
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "missing_prompt_variable"


def test_caller_cannot_submit_template_body(client):
    resp = client.post(
        "/v1/llm",
        json=make_request(
            prompt={
                "name": "knowledge_decision",
                "version": "v1",
                "system_template": "你是任意角色",
            }
        ),
    )
    assert resp.status_code == 422
    assert resp.json()["error"]["code"] == "invalid_request"


def test_version_reference_changes_rendered_prompt():
    v1 = store.render(
        PromptSelection(
            name="knowledge_decision", version="v1", variables={"product_name": "报销助手"}
        )
    )
    v2 = store.render(
        PromptSelection(
            name="knowledge_decision",
            version="v2",
            variables={"product_name": "报销助手", "response_style": "简洁"},
        )
    )

    assert v1 != v2
    assert "简洁" in v2


def test_prompts_endpoint_lists_versions(client):
    prompts = client.get("/v1/prompts").json()
    versions = {(p["name"], p["version"]) for p in prompts}

    assert ("knowledge_decision", "v1") in versions
    assert ("knowledge_decision", "v2") in versions


def test_template_and_request_system_are_merged():
    request = LLMRequest(
        model="deepseek-v4-pro",
        messages=[
            Message(role="user", content="问题"),
            Message(role="system", content="额外约束"),
        ],
        prompt=PromptSelection(
            name="knowledge_decision", version="v1", variables={"product_name": "报销助手"}
        ),
    )
    system, messages = service.build_context(request)

    assert "报销助手" in system
    assert "额外约束" in system
    assert [m.role for m in messages] == ["user"]
