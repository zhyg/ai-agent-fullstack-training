"""FR-2 流式输出（SSE）。"""

from __future__ import annotations

import json

from app import service
from app.errors import RetryableUpstreamError
from app.observability import tracing
from app.registry import register_adapter
from app.schemas import LLMRequest, Message
from tests.conftest import FakeAdapter


def _events_from_body(body: str) -> list[dict]:
    return [
        json.loads(line.removeprefix("data: ").strip())
        for line in body.splitlines()
        if line.startswith("data:")
    ]


def test_stream_emits_delta_then_completed(client):
    adapter = FakeAdapter("openai_responses", deltas=["你", "好"])
    register_adapter("deepseek-v4-pro", adapter)

    with client.stream(
        "POST",
        "/v1/llm/stream",
        json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}]},
    ) as resp:
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("text/event-stream")
        body = "".join(resp.iter_text())

    events = _events_from_body(body)
    assert [e["type"] for e in events] == ["content.delta", "content.delta", "response.completed"]
    assert "".join(e["delta"] for e in events if e["type"] == "content.delta") == "你好"
    assert events[-1]["model"] == "deepseek-v4-pro"
    assert events[-1]["usage"]["input_tokens"] == 11


async def test_stream_records_ttft():
    adapter = FakeAdapter("anthropic_messages", deltas=["你好"])
    register_adapter("deepseek-v4-flash", adapter)
    request = LLMRequest(model="deepseek-v4-flash", messages=[Message(role="user", content="hi")])

    chunks = [chunk async for chunk in service.stream_response(request)]

    assert _events_from_body("".join(chunks))[-1]["type"] == "response.completed"
    traces = tracing.list_traces()
    assert len(traces) == 1
    assert traces[0].stream is True
    assert traces[0].ttft_ms is not None
    assert traces[0].ttft_ms >= 0


async def test_stream_failure_emits_failed_event():
    adapter = FakeAdapter("openai_responses", stream_error=RetryableUpstreamError("boom"))
    register_adapter("deepseek-v4-pro", adapter)
    request = LLMRequest(model="deepseek-v4-pro", messages=[Message(role="user", content="hi")])

    chunks = [chunk async for chunk in service.stream_response(request)]

    events = _events_from_body("".join(chunks))
    assert events[-1]["type"] == "response.failed"
    assert events[-1]["error"] == "upstream_stream_failed"
    assert tracing.list_traces()[0].status == "failed"


def test_stream_endpoint_rejects_response_schema(client):
    resp = client.post(
        "/v1/llm/stream",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "hi"}],
            "response_schema": {"type": "object"},
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "unsupported_combination"


def test_sync_endpoint_rejects_stream_flag(client):
    resp = client.post(
        "/v1/llm",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "hi"}],
            "stream": True,
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "use_stream_endpoint"
