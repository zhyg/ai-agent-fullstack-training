# 第一周作业：LLM 统一模型调用服务

对外暴露一套统一协议，对内通过适配器模式接入 **三种异构上游协议**、四个模型：

| 平台模型别名 | 上游协议 | 适配器 | 凭据 |
|---|---|---|---|
| `deepseek-v4-pro` | OpenAI Responses API | `OpenAIResponsesAdapter` | `DEEPSEEK_API_KEY` |
| `deepseek-v4-flash` | Anthropic Messages API | `AnthropicMessagesAdapter` | `DEEPSEEK_API_KEY` |
| `deepseek-chat` | Chat Completions API | `OpenAIChatCompletionsAdapter` | `DEEPSEEK_API_KEY` |
| `glm-flash` | Chat Completions API | `OpenAIChatCompletionsAdapter` | `ZHIPU_API_KEY` |

前两个模型同属 DeepSeek 平台，共用一把平台密钥，协议差异体现在 **base_url / 端点路径 / 请求体结构 / 认证头** 上；后两个走 Chat Completions 协议，其中 `glm-flash` 使用独立的智谱密钥。所有协议差异全部收敛在适配器内部。

三种协议的关键差异：

| | OpenAI Responses | Anthropic Messages | Chat Completions |
|---|---|---|---|
| 请求消息字段 | `input` + `instructions` | `messages` + `system` | `messages`（system 内联） |
| 长度参数 | `max_output_tokens` | `max_tokens`（必填） | `max_tokens` |
| 取文本 | `output_text` | `content` 块数组拼接 | `choices[0].message.content` |
| 用量字段 | `input_tokens/output_tokens` | `input_tokens/output_tokens` | `prompt_tokens/completion_tokens` |
| 结构化输出 | 原生 `json_schema` | 提示词约束 + 后置校验 | `json_object` / `json_schema` |

---

## 1. 快速开始

### 安装依赖

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### 配置环境变量

```bash
cp .env.example .env
# 编辑 .env，填入真实密钥
export $(grep -v '^#' .env | grep -v '^$' | xargs)
```

### 启动服务

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

启动后访问：

- 健康检查：http://127.0.0.1:8000/health
- 交互式文档：http://127.0.0.1:8000/docs

---

## 2. 目录结构

```
week01/
├── plan.md                          # 需求说明与验收标准
├── README.md                        # 本文件
├── requirements.txt
├── .env.example
├── pytest.ini
├── app/
│   ├── main.py                      # 应用装配 + 全局异常处理器
│   ├── router.py                    # HTTP 端点
│   ├── service.py                   # 编排层：路由 -> 限流 -> 重试 -> 校验 -> 埋点
│   ├── registry.py                  # model -> adapter 动态路由
│   ├── config.py                    # 模型注册表与配置
│   ├── schemas.py                   # 统一请求/响应契约
│   ├── errors.py                    # 统一错误码
│   ├── sse.py                       # SSE 事件编码
│   ├── adapters/
│   │   ├── base.py                  # 适配器抽象 + 结构化输出策略
│   │   ├── openai_responses.py      # OpenAI Responses 协议
│   │   ├── chat_completions.py      # Chat Completions 协议
│   │   └── anthropic_messages.py    # Anthropic Messages 协议
│   ├── prompt/
│   │   ├── store.py                 # 模板存储/版本索引/变量渲染
│   │   └── templates/knowledge_decision/{v1,v2}.yaml
│   ├── observability/
│   │   ├── tracing.py               # 调用追踪
│   │   └── metrics.py               # Token 分类 + 延迟/TTFT 聚合
│   └── resilience/
│       ├── retry.py                 # 指数退避
│       └── rate_limit.py            # 按模型独立限流
├── tests/                           # 按功能点分文件
└── scripts/
    ├── verify.sh                    # 一键验证
    └── curl_examples.sh             # curl 示例
```

---

## 3. 端点

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/v1/llm` | 非流式统一调用 |
| POST | `/v1/llm/stream` | 流式调用（SSE） |
| GET | `/v1/traces?limit=` | 调用追踪明细 |
| GET | `/v1/metrics` | 聚合指标（Token 分类、延迟、TTFT） |
| GET | `/v1/models` | 已注册模型与协议 |
| GET | `/v1/prompts` | 已发布模板清单 |
| GET | `/health` | 健康检查 |

统一请求体：

```json
{
  "model": "deepseek-v4-pro",
  "messages": [{"role": "user", "content": "你好"}],
  "stream": false,
  "response_schema": null,
  "timeout_seconds": 30,
  "max_output_tokens": 1024,
  "prompt": {"name": "knowledge_decision", "version": "v1", "variables": {"product_name": "报销助手"}}
}
```

> `stream` 与 `response_schema` 互斥；未知字段会被拒绝（422）。

---

## 4. curl 示例

```bash
# 健康检查
curl -s http://127.0.0.1:8000/health

# 两个模型分别走两种协议
curl -s -X POST http://127.0.0.1:8000/v1/llm -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"用一句话介绍你自己"}]}'

curl -s -X POST http://127.0.0.1:8000/v1/llm -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"用一句话介绍你自己"}]}'

# 流式（SSE）
curl -sN -X POST http://127.0.0.1:8000/v1/llm/stream -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"讲一个短句"}]}'

# 结构化输出
curl -s -X POST http://127.0.0.1:8000/v1/llm -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"判断是否需要检索"}],"response_schema":{"type":"object","properties":{"decision":{"type":"string"},"reason":{"type":"string"}},"required":["decision"],"additionalProperties":false}}'

# 模板引用
curl -s -X POST http://127.0.0.1:8000/v1/llm -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"报销流程是什么"}],"prompt":{"name":"knowledge_decision","version":"v1","variables":{"product_name":"报销助手"}}}'

# Chat Completions 协议（第三种）
curl -s -X POST http://127.0.0.1:8000/v1/llm -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"用一句话介绍你自己"}]}'

curl -s -X POST http://127.0.0.1:8000/v1/llm -H "Content-Type: application/json" \
  -d '{"model":"glm-flash","messages":[{"role":"user","content":"用一句话介绍你自己"}]}'

# 可观测数据
curl -s "http://127.0.0.1:8000/v1/traces?limit=5"
curl -s http://127.0.0.1:8000/v1/metrics
```

一键跑全部示例：

```bash
GATEWAY_URL=http://127.0.0.1:8000 bash scripts/curl_examples.sh
```

---

## 5. 六大功能点验证

自动化验证（无需真实密钥，测试使用 Fake 适配器）：

```bash
bash scripts/verify.sh
```

功能点 → 用例 → 预期证据：

| # | 功能点 | 用例文件 | 预期证据 |
|---|---|---|---|
| 1 | 流式输出 | `tests/test_stream.py` | `content.delta` 逐块 + `response.completed`；追踪记录 `ttft_ms` 非空 |
| 2 | 结构化输出 | `tests/test_structured_output.py` | 合法 JSON 返回 `parsed`；非法 JSON → `invalid_json`；不符合 Schema → `schema_validation_failed` |
| 3 | 模板引用 | `tests/test_prompt.py` | 模板渲染进 `system`；未知版本 → `unknown_prompt_template`；缺变量 → `missing_prompt_variable`；提交正文 → 422 |
| 4 | 可观测数据 | `tests/test_observability.py` | `/v1/traces` 有完整记录且不含正文；`/v1/metrics` 按模型分类统计 Token，流式有 TTFT |
| 5 | 重试 | `tests/test_retry.py` | 可重试故障调用 3 次、退避间隔递增；不可重试错误只调用 1 次 |
| 6 | 限流 | `tests/test_rate_limit.py` | 超限 429 `rate_limited`；模型间计数独立；超限不产生上游调用与追踪 |
| 7 | 第三种协议接入 | `tests/test_chat_completions.py` | 四个模型分布在三种协议；`prompt_tokens/completion_tokens` 映射统一；`system` 内联进 messages；`glm-flash` 使用独立密钥 |

真实链路验证（需要配置 `DEEPSEEK_API_KEY`）：按第 4 节 curl 依次执行，两个模型各跑一遍，并观察 `/v1/metrics` 中两个模型的统计分别增长。

---

## 6. 统一错误码

| code | HTTP | 含义 |
|---|---|---|
| `invalid_request` | 422 | 请求参数校验失败（含未知字段） |
| `unknown_model` | 400 | model 不在注册表 |
| `unknown_prompt_template` | 400 | 模板不存在 |
| `missing_prompt_variable` | 400 | 缺少模板变量 |
| `structured_output_unsupported` | 400 | 模型不支持结构化输出 |
| `unsupported_combination` | 400 | 流式与 response_schema 混用 |
| `use_stream_endpoint` | 400 | 同步端点收到 stream=true |
| `gateway_misconfigured` | 503 | 凭据未配置 |
| `model_unavailable` | 502 | 上游不可用（重试耗尽） |
| `upstream_stream_failed` | 502 | 上游流式失败 |
| `invalid_json` | 502 | 模型未返回合法 JSON |
| `schema_validation_failed` | 502 | 结果不符合 response_schema |
| `rate_limited` | 429 | 触发按模型限流 |

错误响应统一结构：

```json
{"error": {"code": "unknown_model", "message": "...", "details": {...}}}
```

---

## 7. 环境变量

| 变量 | 说明 | 默认 |
|---|---|---|
| `DEEPSEEK_API_KEY` | 平台统一密钥（两个适配器共用） | 无 |
| `DEEPSEEK_OPENAI_BASE_URL` | OpenAI Responses 端点 | `https://api.deepseek.com` |
| `DEEPSEEK_ANTHROPIC_BASE_URL` | Anthropic Messages 端点 | `https://api.deepseek.com/anthropic` |
| `DEEPSEEK_MODEL_PRO` / `DEEPSEEK_MODEL_FLASH` | 上游真实模型名 | 同别名 |
| `DEEPSEEK_CHAT_BASE_URL` / `DEEPSEEK_CHAT_MODEL` | Chat Completions 模型配置 | `https://api.deepseek.com` / `deepseek-chat` |
| `ZHIPU_API_KEY` | 智谱密钥（`glm-flash` 专用） | 无 |
| `ZHIPU_CHAT_BASE_URL` / `ZHIPU_CHAT_MODEL` | 智谱 Chat Completions 配置 | `https://open.bigmodel.cn/api/paas/v4` / `glm-5.3-flash` |
| `RETRY_MAX_ATTEMPTS` | 总计最多调用次数（首发+重试） | `3` |
| `RETRY_BASE_DELAY` / `RETRY_BACKOFF_FACTOR` / `RETRY_MAX_DELAY` | 指数退避参数 | `0.5` / `2.0` / `8.0` |
| `RATE_LIMIT_REQUESTS` / `RATE_LIMIT_WINDOW_SECONDS` | 每模型窗口配额 | `60` / `60` |

---

## 8. 故障排查

**pytest 报 `ModuleNotFoundError: lark` 或 `unknown hook pytest_launch_collect_makemodule`**
环境中存在第三方 pytest 插件（常见于装了 ROS 的机器）与 pytest 8 冲突。`scripts/verify.sh` 已处理；直接运行 pytest 时可用：

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q -p asyncio
```

**返回 503 `gateway_misconfigured`**
`DEEPSEEK_API_KEY` 未注入进程环境，确认已 `export` 后再启动服务。

**Chat Completions 模型返回 404**
`*_CHAT_BASE_URL` 必须填**根路径**，SDK 会自行拼接 `/chat/completions`；填成完整端点会拼成 `…/chat/completions/chat/completions`。

**返回 502 `model_unavailable`**
密钥无效或上游不可达；先检查 `DEEPSEEK_OPENAI_BASE_URL` / `DEEPSEEK_ANTHROPIC_BASE_URL` 是否与平台提供的协议端点一致。
