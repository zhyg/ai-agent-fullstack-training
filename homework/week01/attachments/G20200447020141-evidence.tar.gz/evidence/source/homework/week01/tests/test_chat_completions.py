"""Chat Completions 协议适配器（第三种协议）的接入验证。"""

from __future__ import annotations

from app.adapters.base import AdapterRequest
from app.adapters.chat_completions import OpenAIChatCompletionsAdapter
from app.config import get_model_config
from app.registry import register_adapter, resolve
from app.schemas import Message
from tests.conftest import FakeAdapter, make_request

SCHEMA = {
    "type": "object",
    "properties": {"decision": {"type": "string"}},
    "required": ["decision"],
    "additionalProperties": False,
}


def test_two_chat_completions_models_route_to_same_adapter(client):
    deepseek = FakeAdapter("openai_chat_completions", content="ds")
    glm = FakeAdapter("openai_chat_completions", content="glm")
    register_adapter("deepseek-chat", deepseek)
    register_adapter("glm-flash", glm)

    resp_ds = client.post("/v1/llm", json=make_request(model="deepseek-chat"))
    resp_glm = client.post("/v1/llm", json=make_request(model="glm-flash"))

    assert resp_ds.status_code == 200
    assert resp_glm.status_code == 200
    assert resp_ds.json()["protocol"] == "openai_chat_completions"
    assert resp_glm.json()["protocol"] == "openai_chat_completions"
    assert len(deepseek.calls) == 1 and len(glm.calls) == 1


def test_registry_exposes_three_protocols():
    protocols = {c.alias: c.protocol for c in [get_model_config(a) for a in ["deepseek-v4-pro", "deepseek-v4-flash", "deepseek-chat"]]}

    assert protocols["deepseek-v4-pro"] == "openai_responses"
    assert protocols["deepseek-v4-flash"] == "anthropic_messages"
    assert protocols["deepseek-chat"] == "openai_chat_completions"
    _, adapter = resolve("deepseek-chat")
    assert isinstance(adapter, OpenAIChatCompletionsAdapter)


def test_glm_uses_its_own_credential_env():
    config = get_model_config("glm-flash")
    assert config.api_key_env == "ZHIPU_API_KEY"
    assert get_model_config("deepseek-chat").api_key_env == "DEEPSEEK_API_KEY"


def test_base_url_is_root_path_not_full_endpoint():
    """SDK 会自行拼接 /chat/completions，配置里必须是根路径。"""
    for alias in ("deepseek-chat", "glm-flash"):
        base_url = get_model_config(alias).base_url
        assert not base_url.endswith("/chat/completions")
        assert base_url.startswith("https://")


def test_system_message_is_inlined_into_messages_array():
    config = get_model_config("deepseek-chat")
    request = AdapterRequest(
        config=config,
        messages=[Message(role="user", content="问题")],
        system="你是助手",
        max_output_tokens=128,
    )
    payload = OpenAIChatCompletionsAdapter()._build_payload(request)

    assert payload["messages"][0] == {"role": "system", "content": "你是助手"}
    assert payload["messages"][1]["role"] == "user"
    assert payload["max_tokens"] == 128
    # Chat Completions 没有独立的 instructions 字段
    assert "instructions" not in payload
    assert "max_output_tokens" not in payload


def test_usage_field_names_are_mapped_to_unified_usage():
    """prompt_tokens/completion_tokens 需映射为 input_tokens/output_tokens。"""

    class _Usage:
        prompt_tokens = 21
        completion_tokens = 9

    class _Response:
        usage = _Usage()

    usage = OpenAIChatCompletionsAdapter._extract_usage(_Response())
    assert usage.input_tokens == 21
    assert usage.output_tokens == 9


def test_json_object_mode_sets_response_format_and_instruction():
    config = get_model_config("deepseek-chat")
    assert config.structured_output_mode == "json_object"

    request = AdapterRequest(
        config=config,
        messages=[Message(role="user", content="hi")],
        system="你是助手",
        response_schema=SCHEMA,
    )
    payload = OpenAIChatCompletionsAdapter()._build_payload(request)

    assert payload["response_format"] == {"type": "json_object"}
    # json_object 只保证合法 JSON，结构仍由提示词描述 + 网关后置校验
    assert "JSON" in payload["messages"][0]["content"]
    assert "decision" in payload["messages"][0]["content"]


def test_models_endpoint_lists_four_models_across_three_protocols(client):
    models = client.get("/v1/models").json()

    assert len(models) == 4
    assert {m["protocol"] for m in models} == {
        "openai_responses",
        "anthropic_messages",
        "openai_chat_completions",
    }
