"""FastAPI 应用装配。"""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.errors import INVALID_REQUEST, GatewayError
from app.router import router

logger = logging.getLogger("llm_gateway")


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )


async def gateway_error_handler(request: Request, exc: GatewayError) -> JSONResponse:
    """统一错误出口：只暴露稳定的 code/message，不透出供应商细节。"""
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": {"code": exc.code, "message": exc.message, "details": exc.details}},
    )


async def validation_error_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": INVALID_REQUEST,
                "message": "请求参数校验失败",
                "details": {"errors": exc.errors()},
            }
        },
    )


def create_app() -> FastAPI:
    configure_logging()
    app = FastAPI(
        title="LLM 统一模型调用服务",
        version="0.1.0",
        description="统一协议接入 OpenAI Responses 与 Anthropic Messages 两种异构上游。",
    )
    app.include_router(router)
    app.add_exception_handler(GatewayError, gateway_error_handler)
    app.add_exception_handler(RequestValidationError, validation_error_handler)
    return app


app = create_app()
