"""模板存储、版本索引与变量渲染。

调用方只能按 name + version 引用受控模板，不能提交模板正文。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from string import Template

import yaml

from app.errors import MISSING_PROMPT_VARIABLE, UNKNOWN_PROMPT_TEMPLATE, GatewayError
from app.schemas import PromptSelection, PromptTemplateInfo

logger = logging.getLogger("llm_gateway.prompt")

TEMPLATE_DIR = Path(__file__).parent / "templates"


@dataclass(frozen=True)
class PromptTemplate:
    name: str
    version: str
    system_template: str
    description: str = ""
    variables: list[str] = field(default_factory=list)


def _load_templates() -> dict[tuple[str, str], PromptTemplate]:
    templates: dict[tuple[str, str], PromptTemplate] = {}
    if not TEMPLATE_DIR.exists():
        return templates
    for path in sorted(TEMPLATE_DIR.glob("*/*.yaml")):
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        name = str(data.get("name") or path.parent.name)
        version = str(data.get("version") or path.stem)
        templates[(name, version)] = PromptTemplate(
            name=name,
            version=version,
            system_template=str(data.get("system_template", "")),
            description=str(data.get("description", "")),
            variables=[str(v) for v in (data.get("variables") or [])],
        )
    return templates


PROMPT_TEMPLATES: dict[tuple[str, str], PromptTemplate] = _load_templates()


def reload_templates() -> None:
    global PROMPT_TEMPLATES
    PROMPT_TEMPLATES = _load_templates()


def get_template(name: str, version: str) -> PromptTemplate:
    template = PROMPT_TEMPLATES.get((name, version))
    if template is None:
        raise GatewayError(
            UNKNOWN_PROMPT_TEMPLATE,
            f"Prompt 模板 {name}:{version} 不存在",
            400,
            details={"available": sorted(f"{n}:{v}" for n, v in PROMPT_TEMPLATES)},
        )
    return template


def render(selection: PromptSelection) -> str:
    """按模板渲染系统提示词，变量缺失时报错而不静默降级。"""
    template = get_template(selection.name, selection.version)
    try:
        return Template(template.system_template).substitute(selection.variables)
    except KeyError as exc:
        raise GatewayError(
            MISSING_PROMPT_VARIABLE,
            f"缺少 Prompt 变量: {exc.args[0]}",
            400,
            details={"expected_variables": template.variables},
        ) from exc


def list_templates() -> list[PromptTemplateInfo]:
    return [
        PromptTemplateInfo(
            name=t.name,
            version=t.version,
            description=t.description,
            variables=list(t.variables),
        )
        for t in PROMPT_TEMPLATES.values()
    ]
