"""测试公共 fixture：假适配器、状态重置、免等待 sleep。"""

from __future__ import annotations

from collections.abc import AsyncIterator

import pytest
from fastapi.testclient import TestClient

from app.adapters.base import AdapterRequest, CompletionResult, LLMAdapter, StreamEvent
from app.main import app
from app.observability import tracing
from app.registry import reset_adapters
from app.resilience import rate_limit
from app.resilience import retry as retry_module
from app.schemas import Usage

SLEEPS: list[float] = []


async def _fake_sleep(delay: float) -> None:
    """记录退避时长但不真正等待。"""
    SLEEPS.append(delay)


class FakeAdapter(LLMAdapter):
    """可编排行为的假适配器，测试全程不依赖真实网络。"""

    def __init__(
        self,
        protocol: str,
        *,
        content: str = "fake-content",
        usage: Usage | None = None,
        complete_error=None,
        deltas: list[str] | None = None,
        stream_error: BaseException | None = None,
    ) -> None:
        self.protocol = protocol
        self.content = content
        self.usage = usage or Usage(input_tokens=11, output_tokens=7)
        self.complete_error = complete_error
        self.deltas = deltas if deltas is not None else ["你好", "，世界"]
        self.stream_error = stream_error
        self.calls: list[AdapterRequest] = []
        self.stream_calls: list[AdapterRequest] = []

    def _error_at(self, index: int) -> BaseException | None:
        if callable(self.complete_error):
            return self.complete_error(index)
        return self.complete_error

    async def complete(self, request: AdapterRequest) -> CompletionResult:
        self.calls.append(request)
        error = self._error_at(len(self.calls) - 1)
        if error is not None:
            raise error
        return CompletionResult(content=self.content, usage=self.usage)

    async def stream(self, request: AdapterRequest) -> AsyncIterator[StreamEvent]:
        self.stream_calls.append(request)
        if self.stream_error is not None:
            raise self.stream_error
        for delta in self.deltas:
            yield StreamEvent(delta=delta)
        yield StreamEvent(usage=self.usage)


@pytest.fixture(autouse=True)
def clean_state(monkeypatch):
    """每个用例前重置适配器缓存、追踪记录与限流器。"""
    SLEEPS.clear()
    reset_adapters()
    tracing.clear_traces()
    rate_limit.reset_limiters()
    monkeypatch.setattr(retry_module, "sleep", _fake_sleep)
    monkeypatch.setenv("RATE_LIMIT_REQUESTS", "60")
    monkeypatch.setenv("RATE_LIMIT_WINDOW_SECONDS", "60")
    monkeypatch.setenv("RETRY_MAX_ATTEMPTS", "3")
    yield
    reset_adapters()
    tracing.clear_traces()
    rate_limit.reset_limiters()


@pytest.fixture
def sleeps() -> list[float]:
    return SLEEPS


@pytest.fixture
def client() -> TestClient:
    return TestClient(app)


def make_request(**overrides) -> dict:
    """构造 /v1/llm 的请求体。"""
    payload = {
        "model": "deepseek-v4-pro",
        "messages": [{"role": "user", "content": "你好"}],
    }
    payload.update(overrides)
    return payload
