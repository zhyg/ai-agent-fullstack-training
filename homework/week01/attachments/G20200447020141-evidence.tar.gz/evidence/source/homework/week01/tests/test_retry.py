"""FR-7 指数退避重试。"""

from __future__ import annotations

from app.errors import RetryableUpstreamError
from app.observability import tracing
from app.registry import register_adapter
from app.resilience.retry import compute_delay, is_retryable
from tests.conftest import FakeAdapter, make_request


def test_retryable_failure_is_retried_up_to_three_times(client, sleeps):
    adapter = FakeAdapter(
        "openai_responses", complete_error=lambda i: RetryableUpstreamError("上游超时")
    )
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request())

    assert resp.status_code == 502
    assert resp.json()["error"]["code"] == "model_unavailable"
    assert len(adapter.calls) == 3
    assert len(sleeps) == 2
    # 指数退避：等待间隔递增
    assert sleeps[1] > sleeps[0]


def test_non_retryable_error_is_not_retried(client, sleeps):
    from app.errors import GatewayError

    adapter = FakeAdapter(
        "openai_responses",
        complete_error=lambda i: GatewayError("invalid_json", "模型没有返回合法 JSON", 502),
    )
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request())

    assert resp.status_code == 502
    assert resp.json()["error"]["code"] == "invalid_json"
    assert len(adapter.calls) == 1
    assert sleeps == []


def test_success_after_one_failure_reports_attempts(client, sleeps):
    def error_at(index: int):
        return RetryableUpstreamError("抖动") if index == 0 else None

    adapter = FakeAdapter("openai_responses", content="恢复成功", complete_error=error_at)
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request())

    assert resp.status_code == 200
    assert resp.json()["attempts"] == 2
    assert resp.json()["content"] == "恢复成功"
    assert len(sleeps) == 1


def test_failed_call_is_traced_with_attempts(client):
    adapter = FakeAdapter(
        "openai_responses", complete_error=lambda i: RetryableUpstreamError("上游超时")
    )
    register_adapter("deepseek-v4-pro", adapter)

    client.post("/v1/llm", json=make_request())

    trace = tracing.list_traces()[0]
    assert trace.status == "failed"
    assert trace.attempts == 3
    assert trace.error_code == "model_unavailable"


def test_backoff_delay_grows_exponentially():
    delays = [compute_delay(i, base_delay=0.5, backoff_factor=2.0, max_delay=8.0, jitter=False) for i in range(1, 5)]
    assert delays == [0.5, 1.0, 2.0, 4.0]
    assert compute_delay(10, 0.5, 2.0, 8.0, jitter=False) == 8.0


def test_is_retryable_classification():
    assert is_retryable(RetryableUpstreamError("x"))
    assert is_retryable(TimeoutError())
    assert not is_retryable(ValueError("参数错误"))
