"""model 到 adapter 的动态路由表。

编排层通过 resolve() 拿到 (ModelConfig, LLMAdapter)，不出现任何按模型分支的 if。
"""

from __future__ import annotations

from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.base import LLMAdapter
from app.adapters.chat_completions import OpenAIChatCompletionsAdapter
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.config import ModelConfig, get_model_config
from app.errors import UNKNOWN_MODEL, GatewayError

ADAPTER_TYPES: dict[str, type[LLMAdapter]] = {
    "openai_responses": OpenAIResponsesAdapter,
    "openai_chat_completions": OpenAIChatCompletionsAdapter,
    "anthropic_messages": AnthropicMessagesAdapter,
}

# 适配器按模型别名缓存；测试可用 register_adapter 注入 Fake
_ADAPTER_CACHE: dict[str, LLMAdapter] = {}


def get_adapter(config: ModelConfig) -> LLMAdapter:
    cached = _ADAPTER_CACHE.get(config.alias)
    if cached is not None:
        return cached
    adapter_cls = ADAPTER_TYPES.get(config.protocol)
    if adapter_cls is None:
        raise GatewayError(UNKNOWN_MODEL, f"未实现的协议: {config.protocol}", 500)
    adapter = adapter_cls()
    _ADAPTER_CACHE[config.alias] = adapter
    return adapter


def register_adapter(alias: str, adapter: LLMAdapter) -> None:
    """注入适配器实例（测试与扩展使用）。"""
    _ADAPTER_CACHE[alias] = adapter


def reset_adapters() -> None:
    _ADAPTER_CACHE.clear()


def resolve(model: str) -> tuple[ModelConfig, LLMAdapter]:
    """按 model 别名解析出配置与适配器。"""
    config = get_model_config(model)
    if config is None:
        raise GatewayError(
            UNKNOWN_MODEL,
            f"model '{model}' 不在网关注册表中",
            400,
            details={"available_models": sorted(_available())},
        )
    return config, get_adapter(config)


def _available() -> list[str]:
    from app.config import list_model_configs

    return [c.alias for c in list_model_configs()]
