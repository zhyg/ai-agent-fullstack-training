"""统一请求/响应契约。

调用方只面对这一套契约，不感知底层是 OpenAI Responses 还是 Anthropic Messages。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Message(BaseModel):
    """跨模型通用的单条对话消息。"""

    model_config = ConfigDict(extra="forbid")

    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=20_000)


class PromptSelection(BaseModel):
    """受控模板引用：只能选模板与传变量，不能提交模板正文。"""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=100)
    version: str = Field(min_length=1, max_length=50)
    variables: dict[str, str] = Field(default_factory=dict)


class LLMRequest(BaseModel):
    """统一请求协议。"""

    model_config = ConfigDict(extra="forbid")

    model: str = Field(min_length=1, max_length=100)
    messages: list[Message] = Field(min_length=1, max_length=100)
    stream: bool = False
    response_schema: dict[str, Any] | None = None
    timeout_seconds: float = Field(default=30, gt=0, le=120)
    prompt: PromptSelection | None = None
    max_output_tokens: int = Field(default=1024, ge=1, le=8_192)

    @model_validator(mode="after")
    def check_stream_and_schema(self) -> LLMRequest:
        if self.stream and self.response_schema is not None:
            raise ValueError("stream 与 response_schema 不能同时使用")
        return self


class Usage(BaseModel):
    """统一 Token 口径。"""

    model_config = ConfigDict(extra="forbid")

    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)


class LLMResponse(BaseModel):
    """统一响应出口。"""

    model_config = ConfigDict(extra="forbid")

    request_id: str
    model: str
    protocol: str
    content: str
    parsed: dict[str, Any] | list[Any] | None = None
    usage: Usage
    latency_ms: int = Field(ge=0)
    attempts: int = Field(ge=1)


class CallTrace(BaseModel):
    """单次调用的审计记录，默认不落正文。"""

    model_config = ConfigDict(extra="forbid")

    request_id: str
    timestamp: datetime
    model: str
    protocol: str
    provider_model: str
    stream: bool
    prompt_name: str | None = None
    prompt_version: str | None = None
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    cost_usd: float = Field(ge=0)
    latency_ms: int = Field(ge=0)
    ttft_ms: int | None = None
    attempts: int = Field(ge=0)
    status: Literal["success", "failed"]
    error_code: str | None = None


class ModelMetrics(BaseModel):
    """按模型维度的聚合指标。"""

    model_config = ConfigDict(extra="forbid")

    model: str
    protocol: str
    requests: int = 0
    successes: int = 0
    failures: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0
    avg_latency_ms: float | None = None
    p95_latency_ms: float | None = None
    avg_ttft_ms: float | None = None
    p95_ttft_ms: float | None = None


class MetricsSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")

    total_requests: int = 0
    total_successes: int = 0
    total_failures: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cost_usd: float = 0
    models: list[ModelMetrics] = Field(default_factory=list)
    generated_at: datetime


class ModelInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    alias: str
    provider_model: str
    protocol: str
    supports_structured_output: bool
    structured_output_mode: str
    description: str = ""


class PromptTemplateInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    version: str
    description: str = ""
    variables: list[str] = Field(default_factory=list)


class ErrorBody(BaseModel):
    """统一错误响应体。"""

    model_config = ConfigDict(extra="forbid")

    code: str
    message: str
    details: dict | None = None
