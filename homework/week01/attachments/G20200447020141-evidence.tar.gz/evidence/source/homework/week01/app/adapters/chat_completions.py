"""OpenAI Chat Completions API 适配器。

与前两种协议的差异（全部收敛在此）：
- 请求体：messages 数组，system 作为 role=system 的消息混在同一个数组里
- 长度参数：max_tokens（Responses 用 max_output_tokens）
- 结构化输出：response_format = json_schema（原生）/ json_object
- 返回：choices[0].message.content
- 用量字段：usage.prompt_tokens / completion_tokens（与前两者都不同）
- 流式：choices[0].delta.content，用量需 stream_options.include_usage 才返回
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any, ClassVar

from openai import AsyncOpenAI

from app.adapters.base import (
    AdapterRequest,
    CompletionResult,
    LLMAdapter,
    StreamEvent,
    normalize_strict_schema,
)
from app.config import ModelConfig, get_api_key
from app.errors import GATEWAY_MISCONFIGURED, GatewayError
from app.schemas import Message, Usage


class OpenAIChatCompletionsAdapter(LLMAdapter):
    protocol: ClassVar[str] = "openai_chat_completions"

    def create_client(self, config: ModelConfig) -> AsyncOpenAI:
        api_key = get_api_key(config)
        if not api_key:
            raise GatewayError(
                GATEWAY_MISCONFIGURED,
                f"环境变量 {config.api_key_env} 未配置",
                503,
            )
        return AsyncOpenAI(api_key=api_key, base_url=config.base_url, max_retries=0)

    @staticmethod
    def _to_messages(system: str | None, messages: list[Message]) -> list[dict[str, str]]:
        """Chat Completions 把 system 作为普通消息放进 messages 数组。"""
        payload: list[dict[str, str]] = []
        if system:
            payload.append({"role": "system", "content": system})
        payload.extend({"role": m.role, "content": m.content} for m in messages)
        return payload

    def _build_payload(self, request: AdapterRequest) -> dict[str, Any]:
        plan = self.resolve_structured_output(request)
        payload: dict[str, Any] = {
            "model": request.config.provider_model,
            "messages": self._to_messages(plan.system, request.messages),
            "max_tokens": request.max_output_tokens,
            "timeout": request.timeout_seconds,
        }
        if plan.native_schema is not None:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "agent_response",
                    "strict": True,
                    "schema": normalize_strict_schema(plan.native_schema),
                },
            }
        elif plan.json_object:
            payload["response_format"] = {"type": "json_object"}
        return payload

    @staticmethod
    def _extract_usage(response: Any) -> Usage:
        usage = getattr(response, "usage", None)
        return Usage(
            input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            output_tokens=getattr(usage, "completion_tokens", 0) or 0,
        )

    @staticmethod
    def _extract_content(response: Any) -> str:
        choices = getattr(response, "choices", None) or []
        if not choices:
            return ""
        return getattr(choices[0].message, "content", "") or ""

    async def complete(self, request: AdapterRequest) -> CompletionResult:
        client = self.create_client(request.config)
        response = await client.chat.completions.create(**self._build_payload(request))
        return CompletionResult(
            content=self._extract_content(response),
            usage=self._extract_usage(response),
        )

    async def stream(self, request: AdapterRequest) -> AsyncIterator[StreamEvent]:
        client = self.create_client(request.config)
        payload = self._build_payload(request)
        # 流式不支持原生结构化约束，按提示词约束处理
        payload.pop("response_format", None)
        payload["stream"] = True
        if request.config.stream_usage:
            payload["stream_options"] = {"include_usage": True}

        usage = Usage(input_tokens=0, output_tokens=0)
        response = await client.chat.completions.create(**payload)
        async for chunk in response:
            chunk_usage = getattr(chunk, "usage", None)
            if chunk_usage is not None:
                usage = self._extract_usage(chunk)
            choice = chunk.choices[0] if chunk.choices else None
            if choice and getattr(choice.delta, "content", None):
                yield StreamEvent(delta=choice.delta.content)
        yield StreamEvent(usage=usage)
