"""配置与模型注册表。

平台别名 -> (协议适配器 + 上游模型名 + base_url + 凭据 + 单价) 的映射集中在此，
新增模型只需加一条配置，编排层代码零改动。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Literal

Protocol = Literal["openai_responses", "openai_chat_completions", "anthropic_messages"]
StructuredMode = Literal["native_schema", "json_object", "prompt_enforced"]

DEFAULT_OPENAI_BASE_URL = "https://api.deepseek.com"
DEFAULT_ANTHROPIC_BASE_URL = "https://api.deepseek.com/anthropic"
# Chat Completions 用根路径，SDK 会自行拼接 /chat/completions
DEFAULT_DEEPSEEK_CHAT_BASE_URL = "https://api.deepseek.com"
DEFAULT_ZHIPU_CHAT_BASE_URL = "https://open.bigmodel.cn/api/paas/v4"
API_KEY_ENV = "DEEPSEEK_API_KEY"
ZHIPU_API_KEY_ENV = "ZHIPU_API_KEY"


@dataclass(frozen=True)
class ModelConfig:
    """单个平台模型别名的路由与能力配置。"""

    alias: str
    provider_model: str
    protocol: Protocol
    base_url: str
    api_key_env: str = API_KEY_ENV
    supports_structured_output: bool = True
    structured_output_mode: StructuredMode = "native_schema"
    price_per_million: dict[str, float] = field(default_factory=lambda: {"input": 0.0, "output": 0.0})
    max_output_tokens: int = 2_048
    # 流式结束后是否附带用量（依赖上游 stream_options.include_usage）
    stream_usage: bool = True
    description: str = ""


def _build_registry() -> dict[str, ModelConfig]:
    """从环境变量构建模型注册表。"""
    return {
        "deepseek-v4-pro": ModelConfig(
            alias="deepseek-v4-pro",
            provider_model=os.getenv("DEEPSEEK_MODEL_PRO", "deepseek-v4-pro"),
            protocol="openai_responses",
            base_url=os.getenv("DEEPSEEK_OPENAI_BASE_URL", DEFAULT_OPENAI_BASE_URL),
            api_key_env=API_KEY_ENV,
            supports_structured_output=True,
            structured_output_mode="native_schema",
            price_per_million={"input": 2.0, "output": 8.0},
            max_output_tokens=4_096,
            description="DeepSeek V4 Pro，走 OpenAI Responses 协议",
        ),
        "deepseek-v4-flash": ModelConfig(
            alias="deepseek-v4-flash",
            provider_model=os.getenv("DEEPSEEK_MODEL_FLASH", "deepseek-v4-flash"),
            protocol="anthropic_messages",
            base_url=os.getenv("DEEPSEEK_ANTHROPIC_BASE_URL", DEFAULT_ANTHROPIC_BASE_URL),
            api_key_env=API_KEY_ENV,
            supports_structured_output=True,
            structured_output_mode="prompt_enforced",
            price_per_million={"input": 0.8, "output": 3.2},
            max_output_tokens=2_048,
            description="DeepSeek V4 Flash，走 Anthropic Messages 协议",
        ),
        "deepseek-chat": ModelConfig(
            alias="deepseek-chat",
            provider_model=os.getenv("DEEPSEEK_CHAT_MODEL", "deepseek-chat"),
            protocol="openai_chat_completions",
            base_url=os.getenv("DEEPSEEK_CHAT_BASE_URL", DEFAULT_DEEPSEEK_CHAT_BASE_URL),
            api_key_env=API_KEY_ENV,
            supports_structured_output=True,
            structured_output_mode="json_object",
            price_per_million={"input": 0.3, "output": 1.2},
            max_output_tokens=2_048,
            description="DeepSeek Chat，走 Chat Completions 协议",
        ),
        "glm-flash": ModelConfig(
            alias="glm-flash",
            provider_model=os.getenv("ZHIPU_CHAT_MODEL", "glm-5.3-flash"),
            protocol="openai_chat_completions",
            base_url=os.getenv("ZHIPU_CHAT_BASE_URL", DEFAULT_ZHIPU_CHAT_BASE_URL),
            api_key_env=ZHIPU_API_KEY_ENV,
            supports_structured_output=True,
            structured_output_mode="json_object",
            price_per_million={"input": 0.5, "output": 2.0},
            max_output_tokens=2_048,
            description="智谱 GLM Flash，走 Chat Completions 协议",
        ),
    }


MODEL_REGISTRY: dict[str, ModelConfig] = _build_registry()


def reload_registry() -> None:
    """重新加载注册表（配置变更后或测试中使用）。"""
    global MODEL_REGISTRY
    MODEL_REGISTRY = _build_registry()


def get_model_config(alias: str) -> ModelConfig | None:
    return MODEL_REGISTRY.get(alias)


def list_model_configs() -> list[ModelConfig]:
    return list(MODEL_REGISTRY.values())


def get_api_key(config: ModelConfig) -> str | None:
    return os.getenv(config.api_key_env)


def calculate_cost(config: ModelConfig, input_tokens: int, output_tokens: int) -> float:
    """按模型单价计算成本（美元）。"""
    price = config.price_per_million
    return (input_tokens * price["input"] + output_tokens * price["output"]) / 1_000_000


# --- 韧性相关配置 ---


def retry_max_attempts() -> int:
    """总计最多发起的上游调用次数（1 次首发 + 重试）。"""
    return int(os.getenv("RETRY_MAX_ATTEMPTS", "3"))


def retry_base_delay() -> float:
    return float(os.getenv("RETRY_BASE_DELAY", "0.5"))


def retry_backoff_factor() -> float:
    return float(os.getenv("RETRY_BACKOFF_FACTOR", "2.0"))


def retry_max_delay() -> float:
    return float(os.getenv("RETRY_MAX_DELAY", "8.0"))


def rate_limit_requests() -> int:
    """每个模型在窗口内的最大请求数。"""
    return int(os.getenv("RATE_LIMIT_REQUESTS", "60"))


def rate_limit_window_seconds() -> float:
    return float(os.getenv("RATE_LIMIT_WINDOW_SECONDS", "60"))
