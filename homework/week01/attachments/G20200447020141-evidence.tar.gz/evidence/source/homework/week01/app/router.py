"""HTTP 端点：只做协议转换、入口拦截与错误映射，不含业务逻辑。"""

from __future__ import annotations

from fastapi import APIRouter, Query
from fastapi.responses import StreamingResponse

from app import service
from app.config import list_model_configs
from app.errors import UNSUPPORTED_COMBINATION, USE_STREAM_ENDPOINT, GatewayError
from app.observability import metrics, tracing
from app.prompt import store as prompt_store
from app.schemas import (
    CallTrace,
    LLMRequest,
    LLMResponse,
    MetricsSnapshot,
    ModelInfo,
    PromptTemplateInfo,
)

router = APIRouter()


@router.post("/v1/llm", response_model=LLMResponse)
async def create_llm_response(request: LLMRequest) -> LLMResponse:
    """统一非流式调用。"""
    if request.stream:
        raise GatewayError(USE_STREAM_ENDPOINT, "流式请求请使用 /v1/llm/stream", 400)
    return await service.complete(request)


@router.post("/v1/llm/stream")
async def create_stream(request: LLMRequest) -> StreamingResponse:
    """统一流式调用（SSE）。预检失败在此处返回 HTTP 错误，不进入流。"""
    if request.response_schema is not None:
        raise GatewayError(UNSUPPORTED_COMBINATION, "流式输出不支持 response_schema", 400)
    config, adapter, system, messages = service.prepare_stream(request)
    return StreamingResponse(
        service.stream_events(request, config, adapter, system, messages),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/v1/traces", response_model=list[CallTrace])
def list_traces(limit: int | None = Query(default=None, ge=1, le=1_000)) -> list[CallTrace]:
    """调用审计记录。"""
    return tracing.list_traces(limit)


@router.get("/v1/metrics", response_model=MetricsSnapshot)
def get_metrics() -> MetricsSnapshot:
    """按模型分类的 Token/成本/延迟聚合指标（含 TTFT）。"""
    return metrics.snapshot()


@router.get("/v1/models", response_model=list[ModelInfo])
def list_models() -> list[ModelInfo]:
    """已注册的模型与协议信息。"""
    return [
        ModelInfo(
            alias=c.alias,
            provider_model=c.provider_model,
            protocol=c.protocol,
            supports_structured_output=c.supports_structured_output,
            structured_output_mode=c.structured_output_mode,
            description=c.description,
        )
        for c in list_model_configs()
    ]


@router.get("/v1/prompts", response_model=list[PromptTemplateInfo])
def list_prompts() -> list[PromptTemplateInfo]:
    """已发布的提示词模板清单。"""
    return prompt_store.list_templates()


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
