#!/usr/bin/env bash
# 一键验证全部功能点：运行 tests/ 下的全部用例
# 用法: bash scripts/verify.sh [pytest 额外参数]
set -euo pipefail
cd "$(dirname "$0")/.."

# 说明：PYTEST_DISABLE_PLUGIN_AUTOLOAD 用于屏蔽环境中第三方 pytest 插件的干扰
# （例如 ROS 的 launch_testing 插件），-p asyncio 显式加载 pytest-asyncio。
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q -p asyncio "$@"

echo
echo "提示：如需对运行中的服务做真实链路验证，先启动服务后执行："
echo "  GATEWAY_URL=http://127.0.0.1:8000 bash scripts/curl_examples.sh"
