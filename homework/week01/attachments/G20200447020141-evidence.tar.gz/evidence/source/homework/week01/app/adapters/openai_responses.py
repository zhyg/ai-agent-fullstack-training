"""OpenAI Responses API 适配器。

协议要点：
- 认证头：Authorization: Bearer <key>
- 请求体：input（消息数组）+ instructions（系统指令）+ max_output_tokens
- 结构化输出：text.format = json_schema（原生约束）
- 返回：response.output_text 与 usage.input_tokens/output_tokens
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any, ClassVar

from openai import AsyncOpenAI

from app.adapters.base import (
    AdapterRequest,
    CompletionResult,
    LLMAdapter,
    StreamEvent,
    normalize_strict_schema,
)
from app.config import ModelConfig, get_api_key
from app.errors import GATEWAY_MISCONFIGURED, GatewayError
from app.schemas import Message, Usage


class OpenAIResponsesAdapter(LLMAdapter):
    protocol: ClassVar[str] = "openai_responses"

    def create_client(self, config: ModelConfig) -> AsyncOpenAI:
        api_key = get_api_key(config)
        if not api_key:
            raise GatewayError(
                GATEWAY_MISCONFIGURED,
                f"环境变量 {config.api_key_env} 未配置",
                503,
            )
        return AsyncOpenAI(api_key=api_key, base_url=config.base_url, max_retries=0)

    @staticmethod
    def _to_input(messages: list[Message]) -> list[dict[str, str]]:
        return [{"role": m.role, "content": m.content} for m in messages]

    def _build_payload(self, request: AdapterRequest) -> dict[str, Any]:
        plan = self.resolve_structured_output(request)
        payload: dict[str, Any] = {
            "model": request.config.provider_model,
            "input": self._to_input(request.messages),
            "max_output_tokens": request.max_output_tokens,
            "timeout": request.timeout_seconds,
        }
        if plan.system:
            payload["instructions"] = plan.system
        if plan.native_schema is not None:
            payload["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": "agent_response",
                    "strict": True,
                    "schema": normalize_strict_schema(plan.native_schema),
                }
            }
        elif plan.json_object:
            payload["text"] = {"format": {"type": "json_object"}}
        return payload

    @staticmethod
    def _extract_usage(response: Any) -> Usage:
        usage = getattr(response, "usage", None)
        return Usage(
            input_tokens=getattr(usage, "input_tokens", 0) or 0,
            output_tokens=getattr(usage, "output_tokens", 0) or 0,
        )

    async def complete(self, request: AdapterRequest) -> CompletionResult:
        client = self.create_client(request.config)
        response = await client.responses.create(**self._build_payload(request))
        content = getattr(response, "output_text", "") or ""
        return CompletionResult(content=content, usage=self._extract_usage(response))

    async def stream(self, request: AdapterRequest) -> AsyncIterator[StreamEvent]:
        client = self.create_client(request.config)
        payload = self._build_payload(request)
        # 流式不支持原生结构化约束，按提示词约束处理
        payload.pop("text", None)
        async with client.responses.stream(**payload) as stream:
            async for event in stream:
                if getattr(event, "type", None) == "response.output_text.delta":
                    delta = getattr(event, "delta", None)
                    if delta:
                        yield StreamEvent(delta=delta)
            final = await stream.get_final_response()
            yield StreamEvent(usage=self._extract_usage(final))
