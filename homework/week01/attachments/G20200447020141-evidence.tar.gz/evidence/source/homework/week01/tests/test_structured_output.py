"""FR-3 结构化输出。"""

from __future__ import annotations

from dataclasses import replace

from app import config as app_config
from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.base import AdapterRequest
from app.config import get_model_config
from app.observability import tracing
from app.registry import register_adapter
from app.schemas import Message
from tests.conftest import FakeAdapter, make_request

SCHEMA = {
    "type": "object",
    "properties": {"decision": {"type": "string"}, "reason": {"type": "string"}},
    "required": ["decision"],
    "additionalProperties": False,
}


def test_valid_json_is_parsed_and_validated(client):
    adapter = FakeAdapter("openai_responses", content='{"decision": "search"}')
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request(response_schema=SCHEMA))

    assert resp.status_code == 200
    assert resp.json()["parsed"] == {"decision": "search"}
    assert adapter.calls[0].response_schema == SCHEMA


def test_invalid_json_returns_invalid_json_code(client):
    adapter = FakeAdapter("openai_responses", content="我不是 JSON")
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request(response_schema=SCHEMA))

    assert resp.status_code == 502
    assert resp.json()["error"]["code"] == "invalid_json"
    # 结果校验失败属于不可重试错误，只调用一次
    assert len(adapter.calls) == 1


def test_schema_mismatch_returns_validation_code(client):
    adapter = FakeAdapter("openai_responses", content='{"decision": "search", "extra": 1}')
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request(response_schema=SCHEMA))

    assert resp.status_code == 502
    assert resp.json()["error"]["code"] == "schema_validation_failed"
    assert tracing.list_traces()[0].error_code == "schema_validation_failed"


def test_model_without_structured_output_is_rejected(client, monkeypatch):
    config = get_model_config("deepseek-v4-pro")
    monkeypatch.setitem(
        app_config.MODEL_REGISTRY,
        "deepseek-v4-pro",
        replace(config, supports_structured_output=False),
    )
    adapter = FakeAdapter("openai_responses")
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request(response_schema=SCHEMA))

    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "structured_output_unsupported"
    assert len(adapter.calls) == 0


def test_native_schema_is_normalized_for_strict_mode():
    """Responses API 的 strict 模式要求 required 覆盖全部 properties。"""
    from app.adapters.base import normalize_strict_schema

    normalized = normalize_strict_schema(
        {
            "type": "object",
            "properties": {"decision": {"type": "string"}, "reason": {"type": "string"}},
            "required": ["decision"],
        }
    )

    assert set(normalized["required"]) == {"decision", "reason"}
    assert normalized["additionalProperties"] is False
    # 不改动用户的属性定义
    assert normalized["properties"]["reason"] == {"type": "string"}


def test_prompt_enforced_mode_injects_schema_instruction():
    """Anthropic 协议无原生 json_schema，网关用提示词约束 + 后置校验兜底。"""
    config = get_model_config("deepseek-v4-flash")
    assert config.structured_output_mode == "prompt_enforced"

    request = AdapterRequest(
        config=config,
        messages=[Message(role="user", content="hi")],
        system="你是助手",
        response_schema=SCHEMA,
    )
    payload = AnthropicMessagesAdapter()._build_payload(request)

    assert "JSON Schema" in payload["system"]
    assert "decision" in payload["system"]
    assert "你是助手" in payload["system"]
    # 协议层不传原生 schema 参数
    assert "response_format" not in payload
