"""FR-5 可观测性：Token 分类统计与延迟（含 TTFT）。"""

from __future__ import annotations

from app import service
from app.observability import metrics, tracing
from app.registry import register_adapter
from app.schemas import LLMRequest, Message, Usage
from tests.conftest import FakeAdapter, make_request


def test_trace_records_metadata_without_content(client):
    adapter = FakeAdapter("openai_responses", content="这是正文，不应被记录")
    register_adapter("deepseek-v4-pro", adapter)

    resp = client.post("/v1/llm", json=make_request())
    assert resp.status_code == 200

    traces = client.get("/v1/traces").json()
    assert len(traces) == 1
    trace = traces[0]
    assert trace["model"] == "deepseek-v4-pro"
    assert trace["protocol"] == "openai_responses"
    assert trace["input_tokens"] == 11
    assert trace["output_tokens"] == 7
    assert trace["cost_usd"] > 0
    assert trace["latency_ms"] >= 0
    assert trace["status"] == "success"
    # 默认不落正文
    assert "这是正文，不应被记录" not in str(trace)


def test_metrics_are_grouped_per_model(client):
    register_adapter("deepseek-v4-pro", FakeAdapter("openai_responses", usage=Usage(input_tokens=10, output_tokens=5)))
    register_adapter("deepseek-v4-flash", FakeAdapter("anthropic_messages", usage=Usage(input_tokens=100, output_tokens=50)))

    client.post("/v1/llm", json=make_request(model="deepseek-v4-pro"))
    client.post("/v1/llm", json=make_request(model="deepseek-v4-pro"))
    client.post("/v1/llm", json=make_request(model="deepseek-v4-flash"))

    snapshot = client.get("/v1/metrics").json()
    by_model = {m["model"]: m for m in snapshot["models"]}

    assert snapshot["total_requests"] == 3
    assert by_model["deepseek-v4-pro"]["input_tokens"] == 20
    assert by_model["deepseek-v4-pro"]["output_tokens"] == 10
    assert by_model["deepseek-v4-pro"]["requests"] == 2
    assert by_model["deepseek-v4-flash"]["input_tokens"] == 100
    assert by_model["deepseek-v4-flash"]["output_tokens"] == 50
    assert by_model["deepseek-v4-flash"]["requests"] == 1
    assert snapshot["total_input_tokens"] == 120
    assert snapshot["total_cost_usd"] > 0


def test_latency_percentiles_are_computed(client):
    register_adapter("deepseek-v4-pro", FakeAdapter("openai_responses"))
    for _ in range(3):
        client.post("/v1/llm", json=make_request())

    model_metrics = client.get("/v1/metrics").json()["models"][0]
    assert model_metrics["avg_latency_ms"] is not None
    assert model_metrics["p95_latency_ms"] is not None


async def test_stream_call_records_ttft_in_metrics():
    register_adapter("deepseek-v4-flash", FakeAdapter("anthropic_messages", deltas=["你", "好"]))
    request = LLMRequest(model="deepseek-v4-flash", messages=[Message(role="user", content="hi")])
    _ = [chunk async for chunk in service.stream_response(request)]

    snapshot = metrics.snapshot()
    flash = next(m for m in snapshot.models if m.model == "deepseek-v4-flash")

    assert flash.avg_ttft_ms is not None
    assert flash.p95_ttft_ms is not None
    assert tracing.list_traces()[0].ttft_ms is not None


def test_metrics_include_failure_counts(client):
    register_adapter("deepseek-v4-pro", FakeAdapter("openai_responses"))
    client.post("/v1/llm", json=make_request(model="not-registered"))

    snapshot = client.get("/v1/metrics").json()
    # 未注册模型在路由阶段即被拒绝，不产生追踪记录
    assert snapshot["total_requests"] == 0
