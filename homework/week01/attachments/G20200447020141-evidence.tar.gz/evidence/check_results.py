"""Assert observed pass/fail facts independently; known defects are NOT passes."""
import json
from pathlib import Path
p=Path(__file__).parent
rows=json.loads((p/'teacher-results.json').read_text())
for r in rows:
    case=r['case']
    if case=='A03_F03_schema':
        assert r['status']==200 and r['body']['parsed']=={'ok':True}
        assert r['body']['usage']=={'input_tokens':17,'output_tokens':9}
        assert r['wire'][0]['path'] in ['/responses','/v1/messages']
    if case=='F04': assert r['status']==502 and r['body']['error']['code']=='invalid_json' and r['calls']==1
    if case=='F04_schema_mismatch': assert r['status']==502 and r['body']['error']['code']=='schema_validation_failed'
    if case=='F01_F02':
        assert r['gated_delta'] and 'content.delta' in r['first'] and r['calls']==1
        assert ('response.completed' if r['fault']=='ok' else 'response.failed') in ''.join(r['rest'])
        assert r['trace']['ttft_ms']>=25
    if case=='F10_F11': assert r['statuses']==[200,429,200,200]
    if case=='F08_F09':
        assert r['wire_count']==(3 if r['fault'] in ['retry_success','429','timeout'] else 1)
        if r['fault']=='retry_success': assert r['status']==200
        if r['waits']: assert r['waits'][0]>.01 and r['waits'][1]>.02 # reproduces backoff cap defect
    if case=='F03_response_format_both': assert r['status']==422 # known contract defect
real=json.loads((p/'real-results.json').read_text())
assert len(real['results'])==6 and all(r['status']==200 for r in real['results'])
for r in real['results']:
    if r['mode']=='structured': assert json.loads(r['body'])['parsed']=={'ok':True}
    if r['mode']=='stream': assert 'response.completed' in r['body'] and 'response.failed' not in r['body']
wire=json.loads((p/'real-wire.json').read_text())
assert all(r['http_status']==200 and r['upstream_id'] for r in wire)
assert [r['url'] for r in wire]==['https://api.deepseek.com/responses','https://api.deepseek.com/anthropic/v1/messages']
print('CHECKED: teacher observations, known defects, six official real calls and two upstream-ID observations')
