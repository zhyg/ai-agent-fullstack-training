# Kevin G20200447020141 评测证据

固定仓库 https://gitee.com/huangke0802/agent-training，master，提交 5981c41b2277c76f0bce8f0518d9611f3dbc5cc6；评测 2026-11-08 Asia/Singapore。

## 复现

在固定快照 `homework/week01` 下按 README 建立 venv，安装 requirements.txt；冻结版本见 dependencies.txt。教师运行命令如下（路径可按解包位置调整）：

```bash
PATH=/tmp/kevin-grade/venv/bin:$PATH bash scripts/verify.sh
PYTHONPATH=. /tmp/kevin-grade/venv/bin/python /tmp/kevin-grade/evidence/teacher_probe.py
PATH=/tmp/kevin-grade/venv/bin:$PATH PYTHONPATH=. bash scripts/verify.sh tests /tmp/kevin-grade/evidence/negative_test.py
```

第三条为故意失败的负对照，预期退出 1：52 passed, 1 failed，不是学生原脚本失败。教师脚本保留完整原始观测，不把已知缺陷断言为验收通过；check_results.py 核对观测事实。

真实调用：环境已注入 DEEPSEEK_API_KEY，不复制、不输出、不归档其值。README 同等 uvicorn 启动方式由 `amp orb service start kevin-week01 --command '/tmp/kevin-grade/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000' --port 8000` 托管，省略仅开发用的 reload。不创建 .env，也不导出学生示例占位值覆盖已有密钥。无上游模型、base_url 替换；没有调用智谱或其他供应商。

```bash
/tmp/kevin-grade/venv/bin/python /tmp/kevin-grade/evidence/real_probe.py
PYTHONPATH=. /tmp/kevin-grade/venv/bin/python /tmp/kevin-grade/evidence/real_wire.py
/tmp/kevin-grade/venv/bin/python /tmp/kevin-grade/evidence/check_results.py
```

real_probe.py 通过实际 HTTP 网关验证六条普通/结构化/流式请求；超时 8 秒，上限 128 tokens，SDK 重试由原代码关闭，外层最多 3 次。全部首次成功，无 500/超时环境阻塞。real_wire.py 额外两次非流式请求在原始客户端上仅挂只读响应钩子，记录白名单上游 ID、路径、模型、用量与网关结果；不记录鉴权头。不能从一次延迟推断模型性能排名。

## 教师模拟范围与差异

teacher_probe.py 仅测试进程内替换 SDK client 的 HTTP transport，为两种真实 SDK 喂协议 JSON/SSE；模拟域 teacher.invalid，不进行外部请求。保留原始 SDK max_retries=0、原始 payload 构造与响应解析，计数 HTTP transport 收到的请求。SDK 为 openai 3.46.0 / anthropic 2.6.0，均使用其 httpx2 传输。最初教师使用 httpx 导致 Anthropic 测试装置不兼容，已修正并完整重跑；该装置问题不计入学生缺陷，归档的是修正后的运行。

SSE 门控驱动真实 Starlette StreamingResponse 的 ASGI send：收到第一条正文前不释放上游终态，确认增量已下发再释放；覆盖真实 SDK 事件解析、正文后 ReadError、Responses failed 终态和单次上游请求。它不代替 TCP 代理缓冲测试；实际 HTTP 流式另见 real.log。

外部环境配置 RETRY_BASE_DELAY=0.01；sleep 只记录等待值以缩短教师模拟；RATE_LIMIT_REQUESTS=1、窗口 0.06 秒并真实等待 0.075 秒验证恢复。未修改学生业务源码。模板使用已发布 v1/v2，再次引用 v1，不更改模板文件。

不支持 response_format 的缺陷归结构化输出一次；缺用量分类/已知用量丢失/前置失败漏记归可观测性，不重复扣协议、脚本分。普通截断终态、NaN 等未超题扣分；结构化非法/空/截断均明确失败。项目无修复流程，因此“修复后仍非法”不适用而非通过。

## 文件

- teacher-results.json / teacher.log：教师 A04、F01–F11 原始请求、上游请求计数、响应和 trace。
- real-results.json / real.log：实际 HTTP 六调用、日志查询结果，含网关请求 ID 和 TTFT。
- real-wire.json / real-wire.log：额外两次官方调用的上游 ID 与分类用量。
- student-tests.log / negative-control.log：提交方脚本和失败负对照。
- source-lines.txt：固定源码行号；source/ 为不含 .env 的相关固定源文件；snapshot-manifest.txt 为 Git blob 清单。
- service-final.txt：服务停止状态。未提交、未推送。
