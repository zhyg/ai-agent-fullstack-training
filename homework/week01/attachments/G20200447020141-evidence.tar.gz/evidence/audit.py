import hashlib,json,os,re,socket,subprocess
from pathlib import Path

root=Path('/home/user/workspace/repo')
evidence=Path(__file__).parent
feedback=root/'homework/week01/G20200447020141.md'
attachment=root/'homework/week01/attachments/G20200447020141.md'
text=feedback.read_text()
parts=re.split(r'\*\*[234]\. [^\n]+\*\*\n\n',text)[1:]
sections=[]
for part in parts:
    items=[line for line in part.splitlines() if line.startswith('- ')]
    size=sum(len(x) for x in items)
    assert 3<=len(items)<=5 and size<=500
    sections.append({'items':len(items),'characters_including_markup':size})
scores=[15,15,6,10,10,11,10,10]
assert sum(scores)==87
assert '优秀（87分）' in text and '**87/100**' in attachment.read_text()
files=[p for p in evidence.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='audit.json']+[feedback,attachment]
# AMP_SECRET_ENV_NAMES contains public variable names, not credential values.
secrets=[v.encode() for k,v in os.environ.items() if k!='AMP_SECRET_ENV_NAMES' and any(s in k.upper() for s in ['KEY','SECRET','TOKEN','PASSWORD']) and len(v)>=12]
leaks=[]
for path in files:
    data=path.read_bytes()
    if any(secret in data for secret in secrets): leaks.append(str(path.relative_to(evidence)) if path.is_relative_to(evidence) else path.name)
assert not leaks, 'environment secret found; do not archive'
suspects=[]
for path in files:
    data=path.read_text(errors='replace')
    if re.search(r'sk-[a-zA-Z0-9_-]{24,}|Bearer\s+[a-zA-Z0-9_-]{24,}|https?://[^/\s:@]+:[^/\s@]+@',data): suspects.append(path.name)
assert not suspects, 'credential-shaped value found; inspect without printing'
with socket.socket() as s:
    port_closed=s.connect_ex(('127.0.0.1',8000))!=0
assert port_closed
student=Path('/tmp/kevin-grade/student')
assert subprocess.check_output(['git','status','--porcelain'],cwd=student)==b''
checked=0
for line in (evidence/'snapshot-manifest.txt').read_text().splitlines():
    meta,name=line.split('\t',1)
    source=evidence/'source'/name
    if source.is_file():
        data=source.read_bytes()
        digest=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert digest==meta.split()[2]
        checked+=1
result=dict(total=87,grade='优秀',sections=sections,environment_secret_matches=0,credential_pattern_matches=0,
            student_worktree_clean=True,source_blobs_verified=checked,port_8000_closed=True,
            commit='5981c41b2277c76f0bce8f0518d9611f3dbc5cc6',
            sha256={str(p.relative_to(evidence)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_relative_to(evidence)})
(evidence/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='sha256'},ensure_ascii=False))
