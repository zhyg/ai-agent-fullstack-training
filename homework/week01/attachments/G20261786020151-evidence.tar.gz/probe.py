"""Teacher probe: real TCP gateway/upstream, real SDK; synthetic responses only.
Run from final project: .venv/bin/python /absolute/path/probe.py PROJECT EVIDENCE
No request headers or credentials are saved.
"""
import asyncio, json, os, sys, time
from pathlib import Path
from unittest.mock import patch
import httpx, uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

ROOT, OUT = map(Path, sys.argv[1:])
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
import main, prompt_manager
from metrics import MetricsStore
from rate_limiter import RateLimiter
from anthropic import AsyncAnthropic
from openai import AsyncOpenAI
from test_complete import message_payload, response_payload
from test_anthropic_adapter import AnthropicWire
from test_responses_adapter import ResponsesWire

state = {'mode': 'ok', 'calls': [], 'gate': None}
upstream = FastAPI()
report = []

@upstream.post('/{path:path}')
async def handle(path: str, request: Request):
    body = await request.json()
    state['calls'].append({'path': path, 'body': body, 'time': time.monotonic()})
    received = state['calls'][-1]
    mode = state['mode']
    if mode in ('503', '401', '400') or mode == 'retry' and len(state['calls']) < 3:
        return JSONResponse({'error': {'type': 'api_error', 'message': 'synthetic'}}, status_code=int(mode) if mode.isdigit() else 503)
    pro = path == 'responses'
    text = {'invalid': '{bad', 'empty': '', 'schema': '{"ok":"wrong"}', 'partial': '{"ok":'}.get(mode, '{"ok":true}')
    if body.get('stream'):
        wire = ResponsesWire(texts=(text,), terminal='error' if mode == 'break' else 'response.completed') if pro else AnthropicWire(texts=(text,), error_type='api_error' if mode == 'break' else None)
        async def stream():
            async for chunk in wire:
                if pro and b'event: response.completed' in chunk:
                    event = json.loads(chunk.decode().split('data: ', 1)[1])
                    event['response']['usage']['input_tokens_details']['cached_tokens'] = 3
                    event['response']['usage']['output_tokens_details']['reasoning_tokens'] = 1
                    chunk = ('event: response.completed\ndata: '+json.dumps(event)+'\n\n').encode()
                received.setdefault('wire_events', []).append(chunk.decode())
                yield chunk
                # Gate AFTER text: upstream terminal cannot be sent until client receives text.
                if b'content_block_delta' in chunk or b'response.output_text.delta' in chunk:
                    if state['gate'] is not None:
                        await state['gate'].wait()
                    if mode == 'drop':
                        raise RuntimeError('synthetic TCP stream interruption')
        return StreamingResponse(stream(), media_type='text/event-stream')
    payload = response_payload() if pro else message_payload()
    if pro:
        payload['output'][0]['content'][0]['text'] = text
        payload['usage']['input_tokens_details'] = {'cached_tokens': 3}
        payload['usage']['output_tokens_details'] = {'reasoning_tokens': 1}
        if mode == 'truncate':
            payload.update(status='incomplete', incomplete_details={'reason': 'max_output_tokens'})
    else:
        payload['content'] = [{'type': 'text', 'text': text}]
        payload['usage'].update(input_tokens=10, cache_read_input_tokens=30, cache_creation_input_tokens=5)
        if mode == 'truncate': payload['stop_reason'] = 'max_tokens'
    received['response'] = payload
    return payload

def factory(cls, base):
    def create(**kw):
        kw.update(api_key='synthetic-only', base_url=base)
        return cls(**kw)
    return create

async def run():
    servers = [uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='error')) for app, port in [(upstream, 18951), (main.app, 18952)]]
    tasks = [asyncio.create_task(server.serve()) for server in servers]
    try:
        while not all(s.started for s in servers): await asyncio.sleep(.02)
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18952', timeout=30) as client:
            async def call(model='deepseek-flash', mode='ok', **extra):
                state.update(mode=mode, calls=[], gate=None)
                body = {'model': model, 'prompt': 'Return JSON {"ok":true}', 'stream': False, **extra}
                response = await client.post('/chat', json=body)
                rows = (await client.get('/metrics/requests', params={'request_id': response.headers['x-request-id']})).json()
                report.append({'model': model, 'mode': mode, 'request': body, 'status': response.status_code, 'response': response.json(), 'upstream': list(state['calls']), 'metrics': rows})
                return response
            assert (await call(model='unknown')).status_code == 422
            for model in ('deepseek-flash', 'deepseek-v4-pro'):
                assert (await call(model)).status_code == 200
                for mode in ('ok', 'invalid', 'empty', 'partial', 'truncate'):
                    response = await call(model, mode, response_format={'type': 'json_object'})
                    assert response.status_code == (200 if mode == 'ok' else 502)
                assert (await call(model, 'schema', response_format={'type': 'json_schema', 'name': 'result', 'schema': {'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok']}})).status_code == 502
                for mode, count, status in [('retry', 3, 200), ('503', 4, 503), ('401', 1, 502), ('400', 1, 502)]:
                    response = await call(model, mode)
                    assert len(state['calls']) == count and response.status_code == status
                response = await call(model, '400', response_format={'type':'json_schema', 'name':'result', 'schema':{'type':'object'}})
                assert response.status_code == 502 and len(state['calls']) == 1
                for mode in ('ok', 'break', 'drop'):
                    state.update(mode=mode, calls=[], gate=asyncio.Event())
                    events, before = [], time.monotonic()
                    async with client.stream('POST', '/chat', json={'model': model, 'prompt': 'hi', 'stream': True}) as response:
                        async for line in response.aiter_lines():
                            events.append(line)
                            if line.startswith('data: ') and '"text"' in line:
                                assert not state['gate'].is_set()
                                state['gate'].set()
                    assert len(state['calls']) == 1
                    assert ('event: done' in events) == (mode == 'ok')
                    assert ('event: error' in events) == (mode != 'ok')
                    rows = (await client.get('/metrics/requests', params={'request_id':response.headers['x-request-id']})).json()
                    assert len(rows) == 1 and rows[0]['status'] == ('success' if mode == 'ok' else 'error')
                    assert rows[0]['ttft_ms'] is not None
                    report.append({'model': model, 'mode': 'gated-'+mode, 'content_before_terminal_release': True, 'events': events, 'upstream': list(state['calls']), 'metrics':rows, 'elapsed': time.monotonic()-before})
            for content in ('v1 {{name}}', 'v2 {{name}}'):
                assert (await client.post('/templates', json={'template_id': 'teacher', 'content': content})).status_code == 200
            for version in (1, 2):
                response = await call(prompt=None, template_id='teacher', template_version=version, variables={'name':'Alice'})
                assert response.status_code == 200 and state['calls'][0]['body']['messages'][0]['content'] == f'v{version} Alice'
            for extra in ({'template_id':'missing'}, {'template_id':'teacher', 'template_version':99}, {'template_id':'teacher'}):
                assert (await call(prompt=None, **extra)).status_code == 422
                assert not state['calls']
            main.rate_limiter = RateLimiter({'deepseek-flash': 1, 'deepseek-v4-pro': 1}, window_seconds=.3)
            assert (await call()).status_code == 200
            assert (await call()).status_code == 429
            assert (await call('deepseek-v4-pro')).status_code == 200
            await asyncio.sleep(.35)
            assert (await call()).status_code == 200
    finally:
        for s in servers: s.should_exit = True
        await asyncio.gather(*tasks)
        (OUT/'teacher-controlled.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main.metrics_store = MetricsStore(OUT/'probe-metrics.db')
    prompt_manager.DB_PATH = OUT/'probe-prompts.db'
    main.rate_limiter = RateLimiter({'deepseek-flash':1000, 'deepseek-v4-pro':1000})
    with patch.dict(os.environ, {'DEEPSEEK_API_KEY':'synthetic-only'}), patch('adapters.anthropic_adapter.AsyncAnthropic', factory(AsyncAnthropic, 'http://127.0.0.1:18951/anthropic')), patch('adapters.responses_adapter.AsyncOpenAI', factory(AsyncOpenAI, 'http://127.0.0.1:18951')):
        asyncio.run(run())
    print('TEACHER CONTROLLED PASS')
