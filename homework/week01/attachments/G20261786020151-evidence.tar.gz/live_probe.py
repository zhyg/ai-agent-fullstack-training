"""Real official DeepSeek only. Original student models/protocols, no remapping."""
import asyncio, json, sys, time
from pathlib import Path
import httpx
OUT = Path(sys.argv[1])

async def run():
    checks = []
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18953', timeout=95) as client:
        for model in ('deepseek-flash', 'deepseek-v4-pro'):
            for mode in ('plain', 'stream', 'json'):
                body = {'model':model, 'stream':mode=='stream', 'prompt':'Reply exactly OK.'}
                if mode == 'json': body.update(prompt='Return JSON {"ok":true}', response_format={'type':'json_object'})
                item = {'model':model, 'protocol':'Messages' if model=='deepseek-flash' else 'Responses', 'mode':mode, 'request':body}
                start = time.monotonic()
                try:
                    response = await client.post('/chat', json=body)
                    item.update(status=response.status_code, request_id=response.headers.get('x-request-id'), response=response.text)
                    item['metrics'] = (await client.get('/metrics/requests', params={'request_id':item['request_id']})).json()
                except Exception as e:
                    item['failure_type'] = type(e).__name__
                item['elapsed'] = time.monotonic()-start
                checks.append(item)
                (OUT/'teacher-live.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2))
                print(model, mode, item.get('status',item.get('failure_type')), flush=True)
asyncio.run(run())
