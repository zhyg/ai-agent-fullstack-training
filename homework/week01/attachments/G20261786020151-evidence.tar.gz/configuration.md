# 本次评测配置（无凭据）

固定仓库 Waterx/xueAI，main 的 fdcc2b533691bbbb9677debd8323dd36d6f0d7bf。
项目 21_LLM_Gateway_Final；Python 3.13.5，requirements.lock.txt 原样安装。
真实：原模型、原 SDK 参数、原协议和官方地址；仅端口改成 18953。
DEEPSEEK_API_KEY 只从已有 secret 环境读取；不留存值、不创建 .env。
deepseek-flash → https://api.deepseek.com/anthropic/v1/messages → 同名上游模型。
deepseek-v4-pro → https://api.deepseek.com/responses → 同名上游模型。
真实请求每模型普通、流式、json_object 各一次；输入短提示，原输出预算1024、thinking disabled/reasoning none。
受控：真实 SDK 工厂外置 base_url 到 18951，网关 TCP 18952；不保存任何请求头；保留 max_retries=0。
受控配额大多数流程设为每模型1000；限流专测每模型1、0.3秒窗口，实际等待0.35秒。
退避定向测随机值0.1、捕获sleep；TCP重试测试保留真实睡眠。
学生 scripts/verify.py 默认离线；故障注入仅新增临时测试，完成后删除。
probe.py 的外置合成配置不是官方真实调用配置，不改业务实现，不把模拟当真实。
复现脚本应使用原固定提交源码（包含 tests fixture）；student-source 只摘录业务源码供复核。
