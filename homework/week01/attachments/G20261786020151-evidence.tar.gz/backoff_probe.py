"""Observe requested sleep without changing production retry formula."""
import asyncio, json, sys
from pathlib import Path
from unittest.mock import AsyncMock, patch
sys.path.insert(0, sys.argv[1])
from retry import wait_before_retry

async def run():
    with patch('retry.asyncio.sleep', new_callable=AsyncMock) as sleep, patch('retry.random.uniform', return_value=0.1):
        for n in (1, 2, 3):
            await wait_before_retry(n)
        delays = [c.args[0] for c in sleep.await_args_list]
    result = {'controlled_jitter':0.1, 'requested_sleep':delays, 'rubric_caps':[0.5,1,2], 'within_rubric_caps':all(a <= b for a,b in zip(delays,[.5,1,2]))}
    Path(sys.argv[2]).write_text(json.dumps(result, indent=2))
    print(json.dumps(result))
asyncio.run(run())
