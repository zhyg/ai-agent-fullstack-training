import hashlib
import io
import json
import os
import shutil
import sqlite3
import tarfile
from pathlib import Path

base = Path(__file__).resolve().parent
evidence = base / "evidence"
student = base / "student"
delivery = base.parents[1] / "week-grading"
prefix = "G20245506050001-19530"
for filename in ("supplement.py", "negative_control.py", "package_evidence.py"):
    shutil.copy2(base / filename, evidence / filename)
for filename in ("verification_report.json", "verification_report.md"):
    shutil.copy2(student / filename, evidence / ("full-" + filename))
shutil.copy2(base / "install.log", evidence / "logs/install.log")
for db in (base / "supplement-state").glob("*.db"):
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    tables = [r[0] for r in conn.execute("select name from sqlite_master where type='table'")]
    if "traces" in tables:
        rows = [dict(r) for r in conn.execute("select * from traces")]
        (evidence / (db.stem + "-traces.json")).write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    conn.close()
for suffix in ("feedback.md", "evaluation.md"):
    shutil.copy2(delivery / f"{prefix}-{suffix}", evidence / f"{prefix}-{suffix}")

# Verify trusted snapshot and tests byte-for-byte against the assessed checkout.
with tarfile.open(evidence / "student-source.tar") as archive:
    for member in archive.getmembers():
        if member.isfile() and (member.name.startswith(("src/", "tests/")) or member.name == "scripts/verify_all.py"):
            assert archive.extractfile(member).read() == (student / member.name).read_bytes(), member.name

key = os.environ.get("DEEPSEEK_API_KEY", "").encode()
def safe(data, label):
    if key:
        assert key not in data, f"credential leak in {label}"
for path in evidence.rglob("*"):
    if path.is_file():
        safe(path.read_bytes(), str(path))
with tarfile.open(evidence / "student-source.tar") as archive:
    for member in archive.getmembers():
        if member.isfile():
            safe(archive.extractfile(member).read(), member.name)
            assert not any(part in {".venv", "node_modules", ".git"} for part in Path(member.name).parts)

manifest = []
for path in sorted(evidence.rglob("*")):
    if path.is_file() and path.name != "SHA256SUMS":
        manifest.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(evidence)}")
(evidence / "SHA256SUMS").write_text("\n".join(manifest) + "\n")
destination = delivery / f"{prefix}-evidence.tar.gz"
with tarfile.open(destination, "w:gz") as archive:
    archive.add(evidence, arcname="evidence")
print("source/tests unchanged; credential scan passed; dependency directories excluded")
print(destination)
print("files:", len(manifest), "archive bytes:", destination.stat().st_size)
