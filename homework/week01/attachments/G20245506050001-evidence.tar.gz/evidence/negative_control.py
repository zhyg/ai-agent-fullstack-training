"""Exercise original assertions against deliberately broken external upstream responses."""
import asyncio
import sys
from argparse import Namespace
from pathlib import Path
import httpx

sys.path.insert(0, str(Path.cwd()))
from scripts import verify_all as verify

original = httpx.AsyncClient.send

async def broken_upstream(self, request, **kwargs):
    if request.url.path == "/responses":
        return httpx.Response(400, json={"error": {"message": "teacher negative control"}}, request=request)
    return await original(self, request, **kwargs)

httpx.AsyncClient.send = broken_upstream
sys.exit(asyncio.run(verify.run(Namespace(live=False, only=["V-ADP-01"], upto=None, verbose=True))))
