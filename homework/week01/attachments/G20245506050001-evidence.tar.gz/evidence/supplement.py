"""Independent boundary checks; no student source/test changes. Run from student cwd."""
import asyncio
import json
import os
import sys
from pathlib import Path

import httpx
import yaml
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

sys.path.insert(0, str(Path.cwd()))
from scripts.verify_all import start_server
from gateway.main import create_app
from gateway.core.clock import OffsetClock
import gateway

BASE = Path(__file__).resolve().parent
OUT = BASE / "evidence"
STATE = BASE / "supplement-state"
STATE.mkdir(exist_ok=True)
records = []
captures = []
mode = "ok"
calls = 0
release = asyncio.Event()

def note(name, **data):
    row = {"case": name, **data}
    records.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

def frame(event, data):
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"

upstream = FastAPI()

@upstream.post("/{path:path}")
async def respond(request: Request, path: str):
    global calls
    calls += 1
    body = await request.json()
    captures.append({"path": request.url.path, "body": body})
    pro = path == "responses"
    if mode == "bad400":
        return JSONResponse({"error": {"message": "bad input"}}, status_code=400)
    if mode == "retry" and calls <= 2 or mode == "always503":
        return JSONResponse({"error": {"message": "temporary"}}, status_code=503)
    text = "not-json" if mode == "invalid" else '{"ok":true}'
    if body.get("stream"):
        async def stream():
            if pro:
                yield frame("response.output_text.delta", {"delta": "early"})
            else:
                yield frame("content_block_delta", {"delta": {"type": "text_delta", "text": "early"}})
            if mode == "gate":
                await release.wait()
            if mode == "eof":
                return
            if pro:
                yield frame("response.completed", {"response": {"status": "completed", "usage": {"input_tokens": 7, "output_tokens": 3, "total_tokens": 10}}})
            else:
                yield frame("message_delta", {"delta": {"stop_reason": "end_turn"}, "usage": {"input_tokens": 7, "output_tokens": 3}})
                yield frame("message_stop", {"type": "message_stop"})
        return StreamingResponse(stream(), media_type="text/event-stream")
    if pro:
        return {"model": body["model"], "status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}], "usage": {"input_tokens": 7, "output_tokens": 3, "total_tokens": 10}}
    return {"model": body["model"], "type": "message", "content": [{"type": "text", "text": text}], "stop_reason": "end_turn", "usage": {"input_tokens": 7, "output_tokens": 3}}

async def run():
    global mode, calls
    note("import", gateway=str(Path(gateway.__file__).resolve()), python=sys.version)
    os.environ["VERIFY_UPSTREAM_KEY"] = "teacher-controlled-local-placeholder"
    up = await start_server(upstream)
    config = yaml.safe_load(Path("config/gateway.verify.yaml").read_text())
    config["observability"]["db_path"] = str(STATE / "obs.db")
    config["prompts"]["db_path"] = str(STATE / "prompts.db")
    config["prompts"]["seed_dir"] = str(Path("config/prompts").resolve())
    for name, spec in config["models"].items():
        spec["base_url"] = f"http://127.0.0.1:{up.port}"
    cp = STATE / "offline.yaml"
    cp.write_text(yaml.safe_dump(config))
    waits = []
    async def sleep(delay):
        waits.append(delay)
    app = create_app(cp, sleep=sleep)
    gw = await start_server(app)
    async with httpx.AsyncClient(timeout=15, trust_env=False) as client:
        url = f"http://127.0.0.1:{gw.port}/v1/chat/completions"
        async def post(model="deepseek-v4-pro", **extra):
            return await client.post(url, json={"model": model, "messages": [{"role": "user", "content": "check"}], **extra})
        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            mode = "gate"
            release.clear()
            async with client.stream("POST", url, json={"model": model, "stream": True, "messages": [{"role": "user", "content": "gate"}]}) as r:
                iterator = r.aiter_lines()
                async def early():
                    async for line in iterator:
                        if '"content":"early"' in line.replace(" ", ""):
                            return line
                    raise AssertionError("no early content")
                line = await asyncio.wait_for(early(), 2)
                assert not release.is_set()
                note("gate", model=model, status=r.status_code, content_before_release=line)
                release.set()
                tail = "\n".join([line async for line in iterator])
                assert "[DONE]" in tail
            mode = "eof"
            calls = 0
            r = await post(model, stream=True)
            assert "event: error" in r.text and "stream_interrupted" in r.text and calls == 1
            note("EOF", model=model, body=r.text, calls=calls)
            mode = "ok"
            r = await post(model, response_format={"type": "json_object"})
            assert r.status_code == 200 and r.json()["choices"][0]["message"]["parsed"] == {"ok": True}
            note("json_success", model=model, status=r.status_code)
            mode = "invalid"
            calls = 0
            r = await post(model, response_format={"type": "json_object"})
            assert r.status_code == 502 and r.json()["error"]["code"] == "structured_output_invalid" and calls == 3
            note("json_invalid", model=model, status=r.status_code, calls=calls, body=r.json())
        mode = "bad400"
        calls = 0
        r = await post()
        assert r.status_code == 502 and calls == 1
        note("upstream400_mapping_DEFECT", status=r.status_code, calls=calls, body=r.json())
        mode = "retry"
        calls = 0
        waits.clear()
        r = await post()
        assert r.status_code == 200 and calls == 3 and waits == [0.5, 1.0]
        note("retry_success", status=r.status_code, calls=calls, waits=waits.copy())
        mode = "always503"
        calls = 0
        waits.clear()
        r = await post()
        assert r.status_code == 503 and calls == 4 and waits == [0.5, 1.0, 2.0]
        note("retry_cap", status=r.status_code, calls=calls, waits=waits.copy())
        mode = "ok"
        for schema, label in [({"$ref": "#/$defs/missing"}, "unresolved_ref"), ({"$defs": {"T": {"type": "object", "required": ["ok"], "properties": {"ok": {"type": "boolean"}}}}, "$ref": "#/$defs/T"}, "valid_ref")]:
            calls = 0
            r = await post(response_format={"type": "json_schema", "json_schema": {"name": "ref", "schema": schema}})
            note(label, status=r.status_code, calls=calls, body=r.json())
            assert r.status_code == (500 if label == "unresolved_ref" else 200)
        r = await post(model="nonexistent")
        assert r.status_code == 404
        note("unknown_model", status=r.status_code, body=r.json())
    await gw.stop()
    await up.stop()
    (OUT / "offline-request-captures.json").write_text(json.dumps(captures, indent=2))

    # Read-only transport instrumentation: retain URL/body, never headers or credentials.
    original_send = httpx.AsyncClient.send
    live_captures = []
    async def instrument(self, request, **kwargs):
        item = None
        if request.url.host == "api.deepseek.com":
            item = {"url": str(request.url), "body": json.loads(request.content)}
            live_captures.append(item)
        response = await original_send(self, request, **kwargs)
        if item is not None:
            item["http_status"] = response.status_code
            if not kwargs.get("stream"):
                item["response"] = response.json()
        return response
    httpx.AsyncClient.send = instrument
    live = yaml.safe_load(Path("config/gateway.yaml").read_text())
    live["observability"]["db_path"] = str(STATE / "live-obs.db")
    live["prompts"]["db_path"] = str(STATE / "live-prompts.db")
    live["prompts"]["seed_dir"] = str(Path("config/prompts").resolve())
    cp = STATE / "live.yaml"
    cp.write_text(yaml.safe_dump(live))
    gw = await start_server(create_app(cp))
    try:
        async with httpx.AsyncClient(timeout=180, trust_env=False) as client:
            for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
                for stream, structured in [(False, False), (True, False), (False, True)]:
                    payload = {"model": model, "messages": [{"role": "user", "content": 'Return only JSON {"ok":true}'}], "max_tokens": 64, "stream": stream}
                    if structured:
                        payload["response_format"] = {"type": "json_object"}
                    r = await client.post(f"http://127.0.0.1:{gw.port}/v1/chat/completions", json=payload)
                    note("live", model=model, stream=stream, structured=structured, status=r.status_code, body=r.text)
                    assert r.status_code == 200
                    if structured:
                        assert json.loads(r.json()["choices"][0]["message"]["content"]) == {"ok": True}
                    elif stream:
                        assert "[DONE]" in r.text and "event: error" not in r.text
    finally:
        await gw.stop()
        httpx.AsyncClient.send = original_send
        (OUT / "live-wire-captures.json").write_text(json.dumps(live_captures, ensure_ascii=False, indent=2))
        (OUT / "supplement-results.json").write_text(json.dumps(records, ensure_ascii=False, indent=2))

asyncio.run(run())
