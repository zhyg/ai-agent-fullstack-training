"""Inject one protocol endpoint fault without modifying student files."""
import pytest

@pytest.fixture(autouse=True)
def teacher_fault(monkeypatch):
    from app.providers.openai import OpenAIProvider
    monkeypatch.setattr(OpenAIProvider, 'endpoint', lambda self: self.base_url + '/teacher-wrong-endpoint')
