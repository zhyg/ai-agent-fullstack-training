"""Validate grading arithmetic, trace evidence, source blobs, and absence of live secrets."""
import hashlib
import json
import os
import re
import tarfile
from pathlib import Path

ROOT=Path(__file__).parent
REPO=Path(os.environ.get('COURSE_ROOT','/home/user/workspace/repo'))
feedback=REPO/'homework/week01/G20258465020022.md'
attachment=REPO/'homework/week01/attachments/G20258465020022.md'
archive=attachment.with_name('G20258465020022-evidence.tar.gz')

def check():
    f=feedback.read_text(); a=attachment.read_text()
    sizes=[]
    for section in re.split(r'\*\*[234]\. [^\n]+\*\*\n',f)[1:]:
        entries=[x for x in section.splitlines() if x.startswith('- ')]
        count=len(entries); length=sum(len(x[2:]) for x in entries)
        assert 3<=count<=5 and length<=500,(count,length)
        sizes.append({'entries':count,'characters':length})
    assert len(sizes)==3 and '良好（79分）' in f
    scores=[int(x) for x in re.findall(r'^\| [^|]+ \| (\d+)/(?:15|10) \|',a,re.M)]
    assert scores==[15,13,7,10,10,14,0,10] and sum(scores)==79,scores
    for case in ['A01','A02','A03','A04']+[f'F{i:02d}' for i in range(1,13)]:
        assert f'| {case} |' in a,case
    blobs=0
    for line in (ROOT/'source-tree.txt').read_text().splitlines():
        metadata,path=line.split('\t'); sha=metadata.split()[-1]
        data=(ROOT/'source'/path).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert actual==sha,path
        blobs+=1
    records=json.loads((ROOT/'controlled.json').read_text()); assert len(records)==37
    for record in records:
        if record['case'].startswith('F08-F09-'):
            assert record['attempts']==(1 if record['case'].endswith('unauthorized') else 3)
            assert record['requested_waits_seconds']==([] if record['attempts']==1 else [.02,.04])
    totals=[0,0,0]
    for p in ROOT.glob('real-*.json'):
        data=json.loads(p.read_text()); assert data['state']=='completed' and data['http_status']==200
        assert len(data['upstream'])==1 and data['upstream'][0]['url'].startswith('https://api.deepseek.com/')
        if data['payload']['stream']:
            events=[json.loads(line[6:]) for line in data['response'].splitlines() if line.startswith('data: {')]
            final=events[-1]; assert final['event']=='done' and final['status']=='success'
            text=''.join(c['delta']['content'] or '' for e in events if e['event']=='delta' for c in e['choices'])
            assert json.loads(text)=={'answer':42}
        else:
            final=json.loads(data['response']); assert final['choices'][0]['parsed']=={'answer':42}
        for i,k in enumerate(['prompt_tokens','completion_tokens','total_tokens']):totals[i]+=final['usage'][k]
    assert totals==[148,20,168],totals
    assert len(list(ROOT.glob('real-*.json')))==4
    # AMP_SECRET_ENV_NAMES lists variable names, not credential values.
    secrets=[v.encode() for k,v in os.environ.items() if k!='AMP_SECRET_ENV_NAMES' and any(s in k.upper() for s in ('API_KEY','TOKEN','PASSWORD','SECRET')) and len(v)>=12]
    assert os.environ.get('DEEPSEEK_API_KEY'),'actual key needed for exact-match check'
    files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]+[feedback,attachment]
    members=[]
    for p in files:
        data=p.read_bytes()
        assert not any(s in data for s in secrets),'live secret found in '+str(p)
        assert not re.search(rb'sk-[A-Za-z0-9]{24,}',data),'key-shaped string in '+str(p)
    if archive.exists():
        with tarfile.open(archive) as tar:
            for member in tar.getmembers():
                assert not member.name.startswith('/') and '..' not in Path(member.name).parts
                assert Path(member.name).name not in ('.env','.gitconfig') and '.git' not in Path(member.name).parts
                if member.isfile():
                    data=tar.extractfile(member).read()
                    assert not any(s in data for s in secrets),'live secret in archive'
                    assert not re.search(rb'sk-[A-Za-z0-9]{24,}',data),'key-shaped string in archive'
                    members.append(member.name)
    return {'score':sum(scores),'feedback_sections':sizes,'verified_git_blobs':blobs,'controlled_records':len(records),'real_calls':4,'tokens':totals,'scanned_files':len(files),'archive_files':len(members),'live_secret_occurrences':0}

if __name__=='__main__':
    result=check()
    (ROOT/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False))
