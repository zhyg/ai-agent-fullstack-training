"""Limited official-only real calls, persistent per-case files prevent repeats."""
import asyncio
import json
import os
import sys
import time
from pathlib import Path
import httpx
sys.path.insert(0, os.environ.get('STUDENT_ROOT','/tmp/llm-gateway-mini'))
from app.config import GatewayConfig
from app.gateway import Gateway
from app.main import create_app

OUT=Path(__file__).parent
async def main():
    cfg={'providers':{
        'official-chat':{'type':'openai','base_url':'https://api.deepseek.com','api_key_env':'DEEPSEEK_API_KEY'},
        'official-messages':{'type':'anthropic','base_url':'https://api.deepseek.com/anthropic','api_key_env':'DEEPSEEK_API_KEY'}},
        'models':{'teacher-pro':{'provider':'official-chat','upstream_model':'deepseek-v4-pro'},'teacher-flash':{'provider':'official-messages','upstream_model':'deepseek-flash'}},
        'prompts':{'dir':'/tmp/llm-gateway-mini/prompts'},'request':{'max_retries':0,'read_timeout':20,'connect_timeout':8,'backoff_base':.02}}
    (OUT/'official-config.json').write_text(json.dumps(cfg,indent=2))
    for model in ('teacher-pro','teacher-flash'):
        for stream in (False,True):
            target=OUT/f'real-{model}-{stream}.json'
            if target.exists(): print('SKIP existing',target.name); continue
            captured=[]
            async def request_hook(req):
                assert req.url.host=='api.deepseek.com'
                captured.append({'url':str(req.url),'body':json.loads(req.content)})
            async def response_hook(res):
                captured[-1]['http_status']=res.status_code
                captured[-1]['request_id_headers']={k:v for k,v in res.headers.items() if k.lower() in ('x-request-id','request-id','x-ds-request-id')}
                if not stream:
                    await res.aread()
                    try:
                        raw=res.json(); captured[-1]['upstream_id']=raw.get('id'); captured[-1]['usage']=raw.get('usage'); captured[-1]['upstream_error']=raw.get('error')
                    except Exception: pass
            async with httpx.AsyncClient(event_hooks={'request':[request_hook],'response':[response_hook]}) as up:
                gw=Gateway(GatewayConfig.model_validate(cfg),client=up)
                app=create_app(gateway=gw); app.state.gateway=gw
                extra={'thinking':{'type':'disabled'}}
                if model=='teacher-pro' and not stream: extra['response_format']={'type':'json_object'}
                payload={'request_id':f'real-{model}-{stream}','model':model,'messages':[{'role':'user','content':'Return exactly JSON {"answer":42} and no other text.'}], 'max_tokens':128,'stream':stream,'extra':extra,'response_scheme':{'name':'answer','json_schema':{'type':'object','properties':{'answer':{'type':'integer'}},'required':['answer']}}}
                started=time.monotonic()
                # Reserve case before network access to prevent duplicate billing after interruption.
                target.write_text(json.dumps({'state':'started-not-yet-completed','payload':payload}))
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app,raise_app_exceptions=False),base_url='http://teacher') as down:
                    r=await down.post('/v1/chat/completions',json=payload,timeout=30)
                result={'state':'completed','elapsed_seconds':round(time.monotonic()-started,3),'http_status':r.status_code,'payload':payload,'upstream':captured,'response':r.text}
                target.write_text(json.dumps(result,ensure_ascii=False,indent=2))
                print(target.name,result['http_status'],result['elapsed_seconds'])

if __name__=='__main__': asyncio.run(main())
