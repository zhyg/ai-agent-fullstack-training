"""Controlled acceptance against unchanged student source. No external network."""
import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from unittest.mock import patch

import httpx

ROOT = Path(os.environ.get('STUDENT_ROOT', '/tmp/llm-gateway-mini'))
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from support import base_config_dict, openai_completion, anthropic_message
from app.config import GatewayConfig
from app.gateway import Gateway
from app.main import create_app

os.environ['MOCK_OPENAI_KEY'] = 'teacher-dummy'
os.environ['MOCK_ANTHROPIC_KEY'] = 'teacher-dummy'
OUT = Path(__file__).parent
records = []
traces = []
class Capture(logging.Handler):
    def emit(self, r):
        if r.msg in ('llm_call_finished', 'llm_call_failed'):
            traces.append({k: v for k, v in r.__dict__.items() if k in ('msg','request_id','response_id','model','provider','usage','latency_ms','ttft_ms','status','error_type')})
# Capture the actual named student logger, independent of its spelling.
from app.logging import logger
logger.addHandler(Capture())
logger.setLevel(logging.INFO)

def save(name, **data):
    records.append({'case': name, **data})
    (OUT / 'controlled.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))

def config():
    raw = base_config_dict(ROOT / 'prompts')
    raw['request']['backoff_base'] = .02
    return GatewayConfig.model_validate(raw)

def body(model='gpt-4o-mini', **kw):
    return {'request_id': 'teacher-' + str(len(records)), 'model': model,
            'messages': [{'role':'system','content':'system-marker'}, {'role':'user','content':'return JSON'}],
            'response_scheme': {'name':'answer','json_schema': {'type':'object','properties':{'answer':{'type':'integer'}},'required':['answer']}}, **kw}

async def session(handler):
    up = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    gw = Gateway(config(), client=up)
    app = create_app(gateway=gw)
    app.state.gateway = gw
    down = httpx.AsyncClient(transport=httpx.ASGITransport(app=app, raise_app_exceptions=False), base_url='http://teacher')
    return gw, app, up, down

async def main():
    captured = []
    content = '{"answer":42}'
    finish = 'stop'
    status = 200
    async def handler(req):
        captured.append({'path':req.url.path,'body':json.loads(req.content),
                         'header_names':sorted(req.headers.keys()),'at':time.monotonic()})
        if status != 200:
            return httpx.Response(status, json={'error':{'message':'controlled bad request'}})
        data = openai_completion(content, finish) if 'completions' in req.url.path else anthropic_message(content, 'max_tokens' if finish=='length' else 'end_turn')
        if 'completions' in req.url.path:
            data['usage'].update(prompt_tokens_details={'cached_tokens':2}, completion_tokens_details={'reasoning_tokens':3})
        else:
            data['usage'].update(cache_read_input_tokens=2, cache_creation_input_tokens=1)
        captured[-1]['upstream_response'] = data
        return httpx.Response(200, json=data)
    gw, app, up, down = await session(handler)
    for model in ('gpt-4o-mini','claude-3-5-sonnet'):
        content = '{"answer":42}'
        r = await down.post('/v1/chat/completions', json=body(model))
        assert r.status_code == 200 and r.json()['choices'][0]['parsed']=={'answer':42}
        save('A03-F03-native-F07', model=model, response=r.json(), upstream=captured[-1])
        standard=body(model); standard.pop('response_scheme'); standard['response_format']={'type':'json_object'}
        r=await down.post('/v1/chat/completions',json=standard)
        assert r.status_code==400
        save('F03-required-response_format',model=model,status=r.status_code,response=r.json())
        for label,text in [('invalid','not JSON'),('empty',''),('truncated','{"answer":'),('schema','{"answer":"wrong"}'),('fenced','```json\n{"answer":42}\n```')]:
            content=text
            r=await down.post('/v1/chat/completions',json=body(model))
            assert r.status_code==(200 if label=='fenced' else 422)
            if label=='fenced':
                try:
                    json.loads(r.json()['choices'][0]['message']['content'])
                except json.JSONDecodeError:
                    pass
                else:
                    raise AssertionError('Expected to reproduce unnormalized successful content')
            save('F04-'+label,model=model,status=r.status_code,response=r.json())
    content='{"answer":42}'; finish='length'
    r=await down.post('/v1/chat/completions',json=body())
    save('F04-length-valid-json-advisory',status=r.status_code,response=r.json())
    finish='stop'
    r=await down.post('/v1/chat/completions',json=body('unknown'))
    assert r.status_code==400
    save('A04',status=r.status_code,response=r.json())
    # Publish two versions in the same in-memory registry using its public loading API.
    for v in ('1','2'):
        gw.registry.load_from_data({'name':'teacher','version':v,'variables':['x'],'messages':[{'role':'system','content':'V'+v+' {{x}}'}]})
    for v in ('1','2','1'):
        r=await down.post('/v1/chat/completions',json=body(prompt={'name':'teacher','version':v,'variables':{'x':'VALUE'}}))
        assert r.status_code==200 and captured[-1]['body']['messages'][0]['content']=='V'+v+' VALUE'
        save('F05',version=v,response=r.json(),upstream=captured[-1])
    for ref in ({'name':'missing'},{'name':'teacher','version':'404'},{'name':'teacher','version':'1','variables':{}}):
        before=len(captured); prior=len(traces)
        r=await down.post('/v1/chat/completions',json=body(prompt=ref))
        assert r.status_code==400 and len(captured)==before
        save('F06',reference=ref,status=r.status_code,response=r.json(),new_call_traces=len(traces)-prior)
    status=400
    before=len(captured)
    r=await down.post('/v1/chat/completions',json=body())
    assert len(captured)-before==1
    save('F09-nonretryable-400',attempts=1,status=r.status_code,response=r.json())
    status=401
    r=await down.post('/v1/chat/completions',json=body())
    save('F07-failure',status=r.status_code,response=r.json(),trace=traces[-1])
    status=200
    before=len(captured)
    codes=[]
    for model in ['gpt-4o-mini']*12+['claude-3-5-sonnet']:
        r=await down.post('/v1/chat/completions',json=body(model)); codes.append(r.status_code)
    await asyncio.sleep(.15)
    r=await down.post('/v1/chat/completions',json=body())
    save('F10-F11',burst_status=codes,upstream_calls=len(captured)-before,after_wait_status=r.status_code,
         note='No model limiter, threshold, or window exists; recovery cannot be established without an initial 429.')
    await down.aclose(); await up.aclose()
    # Actual HTTP transport attempt counts; httpx has no SDK retry layer.
    for model in ('gpt-4o-mini','claude-3-5-sonnet'):
        for scenario in ('recover','persistent','unauthorized'):
            calls=[]
            async def retry_handler(req):
                calls.append(time.monotonic())
                code=401 if scenario=='unauthorized' else (200 if scenario=='recover' and len(calls)==3 else 503)
                data=(openai_completion() if 'completions' in req.url.path else anthropic_message()) if code==200 else {'error':{'message':'controlled'}}
                return httpx.Response(code,json=data)
            g,a,u,d=await session(retry_handler)
            waits=[]
            original_sleep=asyncio.sleep
            async def recorded_sleep(delay, *args, **kwargs):
                waits.append(delay)
                return await original_sleep(delay, *args, **kwargs)
            with patch('app.providers.base.asyncio.sleep',new=recorded_sleep):
                r=await d.post('/v1/chat/completions',json=body(model))
            assert len(calls)==(1 if scenario=='unauthorized' else 3)
            assert waits==([] if scenario=='unauthorized' else [.02,.04])
            gaps=[round(b-a,4) for a,b in zip(calls,calls[1:])]
            if gaps: assert gaps[0]>=.019 and gaps[1]>=.039
            save('F08-F09-'+scenario,model=model,status=r.status_code,attempts=len(calls),requested_waits_seconds=waits,gaps_seconds=gaps,response=r.json())
            await d.aclose(); await u.aclose()
    for model in ('gpt-4o-mini','claude-3-5-sonnet'):
        for scenario in ('normal','disconnect','error-event'):
            await stream_case(model,scenario)
    (OUT/'traces.json').write_text(json.dumps(traces,ensure_ascii=False,indent=2))

async def stream_case(model,scenario):
    release=asyncio.Event(); received=asyncio.Event(); calls=[]; delivered=[]
    start=time.monotonic()
    anthropic=model.startswith('claude')
    class Gate(httpx.AsyncByteStream):
        async def __aiter__(self):
            metadata={'type':'message_start','message':{'id':'teacher-msg','usage':{'input_tokens':8,'output_tokens':1}}} if anthropic else {'id':'teacher-chat','choices':[{'delta':{'role':'assistant'}}]}
            yield ('data: '+json.dumps(metadata)+'\n\n').encode()
            await asyncio.sleep(.12)
            delta={'type':'content_block_delta','delta':{'type':'text_delta','text':'FIRST'}} if anthropic else {'id':'teacher-chat','choices':[{'delta':{'content':'FIRST'}}]}
            yield ('data: '+json.dumps(delta)+'\n\n').encode()
            await asyncio.wait_for(release.wait(),3)
            if scenario=='disconnect': raise httpx.ReadError('controlled disconnect')
            if scenario=='error-event':
                yield b'data: {"type":"error","error":{"type":"overloaded_error","message":"controlled"}}\n\n'
                return
            ending={'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':6}} if anthropic else {'id':'teacher-chat','choices':[{'delta':{},'finish_reason':'stop'}],'usage':{'prompt_tokens':8,'completion_tokens':6,'total_tokens':14}}
            yield ('data: '+json.dumps(ending)+'\n\n').encode()
            yield b'data: {"type":"message_stop"}\n\n' if anthropic else b'data: [DONE]\n\n'
    async def handler(req):
        calls.append(json.loads(req.content)); return httpx.Response(200,stream=Gate(),headers={'content-type':'text/event-stream'})
    g,app,u,d=await session(handler)
    payload=json.dumps(body(model,stream=True)).encode()
    scope={'type':'http','asgi':{'version':'3.0','spec_version':'2.4'},'http_version':'1.1','method':'POST','scheme':'http','path':'/v1/chat/completions','raw_path':b'/v1/chat/completions','query_string':b'','headers':[(b'content-type',b'application/json')],'server':('teacher',80),'client':('teacher',1)}
    once=False
    async def receive():
        nonlocal once
        if not once: once=True; return {'type':'http.request','body':payload,'more_body':False}
        await asyncio.Event().wait()
    async def send(event):
        if event['type']=='http.response.body' and event.get('body'):
            text=event['body'].decode(); delivered.append({'seconds':round(time.monotonic()-start,4),'wire':text})
            if 'FIRST' in text: received.set()
    task=asyncio.create_task(app(scope,receive,send))
    await asyncio.wait_for(received.wait(),3)
    assert not task.done() and not release.is_set()
    gate_time=time.monotonic()-start
    release.set(); await asyncio.wait_for(task,3)
    events=[json.loads(line[6:]) for item in delivered for line in item['wire'].splitlines() if line.startswith('data: {')]
    final=events[-1]
    assert len(calls)==1
    if scenario=='disconnect': assert final['event']=='error' and final['trace']['status']=='failed'
    if scenario=='normal':
        assert final['event']=='done'
        assert final['usage']=={'prompt_tokens':8,'completion_tokens':6,'total_tokens':14}
    save('F01-F02-F07-'+scenario,model=model,received_while_terminal_gated=True,first_content_seconds=round(gate_time,4),attempts=len(calls),final=final,delivered=delivered)
    await d.aclose(); await u.aclose()

if __name__=='__main__':
    asyncio.run(main())
    print('Controlled cases completed:',len(records))
