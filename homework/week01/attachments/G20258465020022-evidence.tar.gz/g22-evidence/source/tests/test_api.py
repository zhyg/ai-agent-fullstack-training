"""API 集成测试：非流式、流式、模型发现与健康接口（T-809、T-810、T-813）。"""

import json
from typing import Any

import httpx
import pytest
from support import (
    anthropic_message,
    anthropic_sse,
    make_client,
    make_gateway,
    openai_completion,
    openai_sse,
    sse_lines,
)

from app.config import GatewayConfig
from app.gateway import Gateway

SCHEME: dict[str, Any] = {
    "type": "object",
    "properties": {"answer": {"type": "integer"}},
    "required": ["answer"],
}

ANSWER_BODY = {"answer": 42}


def stream_json_response(content: str) -> Any:
    """OpenAI 非流式 JSON 响应 handler。"""
    return openai_completion(content)


class TestNonStreamingAPI:
    """T-809：成功响应字段、request_id 回传、parsed 与统一错误结构。"""

    def build_client(self, config: GatewayConfig, handler: Any) -> Any:
        gateway = make_gateway(config, handler)
        return make_client(gateway)

    def test_success_path(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=stream_json_response('```json\n{"answer": 42}\n```'))

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"name": "answer", "json_schema": SCHEME},
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["event"] == "done"
        assert data["status"] == "success"
        assert data["object"] == "llm.response"
        assert data["model"] == "gpt-4o-mini"
        assert data["provider"] == "openai"
        assert data["request_id"].startswith("req-")
        assert data["response_id"] == "chatcmpl-mock-1"
        choice = data["choices"][0]
        assert choice["message"]["content"] == '```json\n{"answer": 42}\n```'
        assert choice["parsed"] == ANSWER_BODY
        assert choice["finish_reason"] == "stop"
        assert choice["delta"] is None
        assert data["usage"] == {"prompt_tokens": 5, "completion_tokens": 7, "total_tokens": 12}

    def test_response_id_generated_without_upstream_id(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            payload = openai_completion('{"answer": 1}')
            payload["id"] = ""
            return httpx.Response(200, json=payload)

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        assert resp.json()["response_id"].startswith("resp-")

    def test_request_id_echo(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=openai_completion('{"answer": 1}'))

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "request_id": "req-custom-1",
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        assert resp.json()["request_id"] == "req-custom-1"

    def test_prompt_reference_trace_echo(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=openai_completion('{"answer": 2}'))

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "prompt": {
                        "name": "customer_support",
                        "variables": {"company": "ACME", "question": "退款政策？"},
                    },
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        data = resp.json()
        assert data["prompt"] == {
            "name": "customer_support",
            "version": "1",
            "content_hash": data["prompt"]["content_hash"],
        }
        assert data["prompt"]["content_hash"].startswith("sha256:")
        assert data["trace"]["prompt"]["version"] == "1"

    def test_missing_scheme_returns_400(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("不应访问上游")

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hi"}]},
            )

        assert resp.status_code == 400
        body = resp.json()
        assert body["error"]["type"] == "invalid_request"
        assert body["error"]["code"] == "validation_error"

    def test_unknown_field_400(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("不应访问上游")

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                    "temperature_x": 1,
                },
            )

        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "unexpected_field"

    def test_schema_mismatch_422(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=openai_completion("我无法给出 JSON"))

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "request_id": "req-422",
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        assert resp.status_code == 422
        body = resp.json()
        assert body["request_id"] == "req-422"
        assert body["error"]["type"] == "schema_validation_error"
        assert body["error"]["code"] == "invalid_json"

    def test_unknown_model_400(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("不应访问上游")

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "request_id": "req-unknown",
                    "model": "no-such-model",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        assert resp.status_code == 400
        body = resp.json()
        assert body["error"]["code"] == "model_not_found"
        assert body["request_id"] == "req-unknown"

    def test_missing_api_key_clear_error(
        self, config: GatewayConfig, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("MOCK_OPENAI_KEY", raising=False)

        async def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("不应访问上游")

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        assert resp.status_code == 401
        body = resp.json()
        assert body["error"]["type"] == "authentication_error"
        assert "MOCK_OPENAI_KEY" in body["error"]["message"]

    def test_trace_can_be_disabled(self, config: GatewayConfig) -> None:
        config.trace.include_in_response = False

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=openai_completion('{"answer": 1}'))

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        data = resp.json()
        assert data["trace"] is None
        assert data["event"] == "done"

    def test_anthropic_provider_e2e(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert "system" in body
            assert body["max_tokens"] == 256
            return httpx.Response(200, json=anthropic_message('{"answer": 3}'))

        with self.build_client(config, handler) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "claude-3-5-sonnet",
                    "messages": [
                        {"role": "system", "content": "be nice"},
                        {"role": "user", "content": "hi"},
                    ],
                    "max_tokens": 256,
                    "response_scheme": {"json_schema": SCHEME},
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["provider"] == "anthropic"
        assert data["choices"][0]["parsed"] == {"answer": 3}


class TestStreamingAPI:
    """T-810：start → delta* → done → [DONE]，error 事件，scheme 被忽略。"""

    def collect(self, gateway: Gateway, payload: dict[str, Any]) -> list[dict[str, Any]]:
        with make_client(gateway) as client:
            with client.stream("POST", "/v1/chat/completions", json=payload) as resp:
                assert resp.status_code == 200
                assert resp.headers["content-type"].startswith("text/event-stream")
                payloads = sse_lines(resp.read().decode("utf-8"))
        assert payloads[-1] == "[DONE]"
        return [json.loads(item) for item in payloads[:-1]]

    def test_event_order(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["stream"] is True
            return httpx.Response(200, content=openai_sse(["你好", "世界"]))

        gateway = make_gateway(config, handler)
        with make_client(gateway) as client:
            with client.stream(
                "POST",
                "/v1/chat/completions",
                json={
                    "request_id": "req-stream",
                    "model": "gpt-4o-mini",
                    "messages": [{"role": "user", "content": "hi"}],
                    "stream": True,
                },
            ) as resp:
                payloads = sse_lines(resp.read().decode("utf-8"))

        assert payloads[-1] == "[DONE]"
        events = [json.loads(p) for p in payloads[:-1]]
        assert [e["event"] for e in events] == ["start", "delta", "delta", "done"]
        assert all(e["request_id"] == "req-stream" for e in events)
        assert events[0]["status"] == "in_progress"
        assert events[0]["choices"][0]["delta"]["role"] == "assistant"
        assert events[1]["choices"][0]["delta"]["content"] == "你好"
        assert events[2]["choices"][0]["delta"]["content"] == "世界"
        done = events[-1]
        assert done["status"] == "success"
        assert done["choices"][0]["finish_reason"] == "stop"
        assert done["usage"]["total_tokens"] == 7
        assert done["trace"]["status"] == "success"
        assert done["trace"]["stream"] is True
        assert 0 <= done["trace"]["ttft_ms"] <= done["trace"]["latency_ms"]

    def test_stream_ignores_response_scheme(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert "response_format" not in body
            return httpx.Response(200, content=openai_sse(["plain text, not json"]))

        gateway = make_gateway(config, handler)
        events = self.collect(
            gateway,
            {
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
                "response_scheme": {"json_schema": SCHEME},
            },
        )
        assert events[1]["choices"][0]["delta"]["content"] == "plain text, not json"
        assert events[-1]["event"] == "done"

    def test_stream_error_event(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, json={"error": {"message": "boom"}})

        gateway = make_gateway(config, handler)
        events = self.collect(
            gateway,
            {
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            },
        )

        assert events[0]["event"] == "start"
        error_event = events[-1]
        assert error_event["event"] == "error"
        assert error_event["status"] == "failed"
        assert error_event["error"]["type"] == "provider_error"
        assert error_event["trace"]["status"] == "failed"
        assert error_event["trace"]["error_type"] == "provider_error"
        assert error_event["trace"]["ttft_ms"] is None

    def test_anthropic_stream_e2e(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, content=anthropic_sse(["a", "b"], stop="max_tokens"))

        gateway = make_gateway(config, handler)
        events = self.collect(
            gateway,
            {
                "model": "claude-3-5-sonnet",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            },
        )
        assert [e["event"] for e in events] == ["start", "delta", "delta", "done"]
        assert events[-1]["choices"][0]["finish_reason"] == "length"
        assert events[-1]["usage"]["prompt_tokens"] == 8


class TestDiscoveryEndpoints:
    """T-813：/v1/models、/healthz 与提示词变量校验。"""

    def build_client(self, config: GatewayConfig) -> Any:
        async def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("发现接口不应访问上游")

        return make_client(make_gateway(config, handler))

    def test_healthz(self, config: GatewayConfig) -> None:
        with self.build_client(config) as client:
            resp = client.get("/healthz")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["version"]
        assert set(data["providers"]) == {"openai", "anthropic"}

    def test_models(self, config: GatewayConfig) -> None:
        with self.build_client(config) as client:
            resp = client.get("/v1/models")
        assert resp.status_code == 200
        data = resp.json()
        assert data["object"] == "list"
        ids = {m["id"]: (m["provider"], m["upstream_model"]) for m in data["data"]}
        assert ids["gpt-4o-mini"] == ("openai", "gpt-4o-mini")
        assert ids["claude-3-5-sonnet"] == ("anthropic", "claude-3-5-sonnet-20241022")
        assert "gpt-*" not in ids

    def test_variables_renders_prompt_missing_variable_400(self, config: GatewayConfig) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("不应访问上游")

        with make_client(make_gateway(config, handler)) as client:
            resp = client.post(
                "/v1/chat/completions",
                json={
                    "model": "gpt-4o-mini",
                    "prompt": {"name": "customer_support", "variables": {"company": "ACME"}},
                    "response_scheme": {"json_schema": SCHEME},
                },
            )
        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "missing_prompt_variable"
