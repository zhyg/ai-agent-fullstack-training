"""严格数据模型与请求校验测试（T-801、T-802）。"""

import pytest
from pydantic import ValidationError

from app.schemas import (
    Choice,
    LLMRequest,
    LLMResponse,
    Message,
    PromptRef,
    ResponseEvent,
    ResponseScheme,
    ResponseStatus,
    Usage,
)

SCHEME = {"type": "object", "properties": {"answer": {"type": "integer"}}}


def make_request(**overrides: object) -> LLMRequest:
    """构造一个合法的非流式请求。"""
    data: dict[str, object] = {
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": "hi"}],
        "response_scheme": {"json_schema": SCHEME},
    }
    data.update(overrides)
    return LLMRequest.model_validate(data)


class TestStrictModel:
    """T-801：未定义字段被拒绝；extra 透传；响应模型结构正确。"""

    def test_rejects_undefined_field_on_request(self) -> None:
        with pytest.raises(ValidationError):
            LLMRequest.model_validate(
                {"model": "m", "messages": [{"role": "user", "content": "x"}],
                 "response_scheme": {"json_schema": SCHEME}, "unknown": 1}
            )

    def test_rejects_undefined_field_on_message(self) -> None:
        with pytest.raises(ValidationError):
            Message.model_validate({"role": "user", "content": "x", "foo": "bar"})

    def test_extra_field_allowed_and_preserved(self) -> None:
        req = make_request(extra={"top_p": 0.5, "seed": 7})
        assert req.extra == {"top_p": 0.5, "seed": 7}

    def test_response_model_structure(self) -> None:
        resp = LLMResponse(
            response_id="resp-1",
            request_id="req-1",
            created=1730000000,
            model="gpt-4o-mini",
            provider="openai",
            status=ResponseStatus.SUCCESS,
            event=ResponseEvent.DONE,
            choices=[
                Choice(
                    index=0,
                    message=Message(role="assistant", content="ok"),
                    parsed={"answer": 1},
                )
            ],
            usage=Usage(prompt_tokens=1, completion_tokens=2, total_tokens=3),
        )
        assert resp.object == "llm.response"
        assert resp.choices[0].message is not None
        assert resp.choices[0].delta is None
        with pytest.raises(ValidationError):
            LLMResponse.model_validate(resp.model_dump() | {"mystery": True})


class TestRequestValidation:
    """T-802：messages/prompt 组合与非流式 response_scheme 约束。"""

    def test_requires_messages_or_prompt(self) -> None:
        with pytest.raises(ValidationError):
            LLMRequest.model_validate(
                {"model": "m", "response_scheme": {"json_schema": SCHEME}}
            )
        with pytest.raises(ValidationError):
            LLMRequest.model_validate(
                {"model": "m", "messages": [], "response_scheme": {"json_schema": SCHEME}}
            )

    def test_prompt_only_allowed(self) -> None:
        req = LLMRequest.model_validate(
            {
                "model": "m",
                "prompt": {"name": "p", "variables": {"a": 1}},
                "response_scheme": {"json_schema": SCHEME},
            }
        )
        assert isinstance(req.prompt, PromptRef)

    def test_non_stream_requires_response_scheme(self) -> None:
        with pytest.raises(ValidationError):
            LLMRequest.model_validate(
                {"model": "m", "messages": [{"role": "user", "content": "x"}]}
            )

    def test_stream_may_omit_response_scheme(self) -> None:
        req = make_request(stream=True, response_scheme=None)
        assert req.stream is True and req.response_scheme is None

    def test_stream_accepts_scheme_field(self) -> None:
        req = LLMRequest.model_validate(
            {
                "model": "m",
                "messages": [{"role": "user", "content": "x"}],
                "stream": True,
                "response_scheme": {"json_schema": SCHEME},
            }
        )
        assert isinstance(req.response_scheme, ResponseScheme)
