"""模型路由测试（T-805）。"""

import pytest

from app.config import GatewayConfig
from app.errors import InvalidRequest
from app.providers import build_providers
from app.router import ModelRouter


@pytest.fixture
def router(config: GatewayConfig) -> ModelRouter:
    """用测试配置装配 provider 并构造路由器。"""
    return ModelRouter(config, build_providers(config))


class TestModelRouter:
    """显式映射、前缀规则与未注册模型。"""

    def test_explicit_mapping(self, router: ModelRouter) -> None:
        provider, upstream, route = router.resolve("claude-3-5-sonnet")
        assert provider.name == "anthropic"
        assert upstream == "claude-3-5-sonnet-20241022"
        assert route.provider == "anthropic"

    def test_wildcard_rule_substitutes_model(self, router: ModelRouter) -> None:
        provider, upstream, _ = router.resolve("gpt-4o-turbo")
        assert provider.name == "openai"
        assert upstream == "gpt-4o-turbo"

    def test_explicit_wins_over_pattern(self, router: ModelRouter) -> None:
        _, upstream, _ = router.resolve("gpt-4o-mini")
        assert upstream == "gpt-4o-mini"

    def test_unregistered_model_raises_400(self, router: ModelRouter) -> None:
        with pytest.raises(InvalidRequest) as exc:
            router.resolve("nope-1")
        assert exc.value.code == "model_not_found"
        assert exc.value.status_code == 400

    def test_model_pointing_to_missing_provider(self, config: GatewayConfig) -> None:
        config.models["orphan"] = config.models["gpt-4o-mini"].model_copy(
            update={"provider": "ghost"}
        )
        router = ModelRouter(config, build_providers(config))
        with pytest.raises(InvalidRequest) as exc:
            router.resolve("orphan")
        assert exc.value.code == "provider_not_configured"

    def test_list_models_contains_only_explicit(self, router: ModelRouter) -> None:
        ids = [m.id for m in router.list_models()]
        assert set(ids) == {"gpt-4o-mini", "deepseek-chat", "claude-3-5-sonnet"}
