"""测试公共夹具：Mock API Key、提示词目录与网关配置，全部测试不访问真实网络。"""

from pathlib import Path

import pytest
import yaml
from support import base_config_dict

from app.config import GatewayConfig


@pytest.fixture
def prompts_dir(tmp_path: Path) -> Path:
    """写入两版 customer_support 模板（v1 active、v2 draft）。"""
    directory = tmp_path / "prompts"
    directory.mkdir()
    templates = [
        {
            "name": "customer_support",
            "version": "1",
            "status": "active",
            "description": "客服助手 v1",
            "variables": ["company", "question"],
            "messages": [
                {"role": "system", "content": "你是 {{company}} 的客服。"},
                {"role": "user", "content": "{{question}}"},
            ],
        },
        {
            "name": "customer_support",
            "version": "2",
            "status": "draft",
            "description": "客服助手 v2",
            "variables": ["company", "question", "context"],
            "messages": [{"role": "system", "content": "v2 {{company}} {{context}}"}],
        },
    ]
    (directory / "support.yaml").write_text(
        yaml.safe_dump(templates, allow_unicode=True), encoding="utf-8"
    )
    return directory


@pytest.fixture
def config(prompts_dir: Path) -> GatewayConfig:
    """测试网关配置。"""
    return GatewayConfig.model_validate(base_config_dict(prompts_dir))


@pytest.fixture(autouse=True)
def mock_api_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    """默认注入 Mock API Key，避免真实凭据依赖。"""
    monkeypatch.setenv("MOCK_OPENAI_KEY", "sk-mock-openai")
    monkeypatch.setenv("MOCK_ANTHROPIC_KEY", "mock-anthropic-key")
