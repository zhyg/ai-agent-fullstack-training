"""CallTrace 采集测试（T-812、T-608）。"""

import logging

import pytest

from app.schemas import PromptTrace, TraceStatus, Usage
from app.trace import TraceRecorder, new_request_id, new_response_id, new_trace_id


def make_recorder(
    *,
    provider: str = "openai",
    upstream_model: str = "gpt-4o-mini",
    stream: bool = False,
) -> TraceRecorder:
    """构造追踪记录器。"""
    return TraceRecorder(
        request_id="req-1",
        model="gpt-4o-mini",
        provider=provider,
        upstream_model=upstream_model,
        prompt=PromptTrace(name="demo", version="1", content_hash="sha256:abc"),
        stream=stream,
    )


class TestTraceRecorder:
    """记录字段完整性与状态。"""

    def test_success_trace(self) -> None:
        recorder = make_recorder()
        usage = Usage(prompt_tokens=5, completion_tokens=7, total_tokens=12)
        trace = recorder.success(usage)

        assert trace.trace_id == recorder.trace_id
        assert trace.request_id == "req-1"
        assert trace.response_id == recorder.response_id
        assert trace.model == "gpt-4o-mini"
        assert trace.provider == "openai"
        assert trace.upstream_model == "gpt-4o-mini"
        assert trace.status == TraceStatus.SUCCESS
        assert trace.error_type is None
        assert trace.stream is False
        assert trace.usage == usage
        assert trace.prompt is not None and trace.prompt.content_hash == "sha256:abc"
        assert trace.latency_ms >= 0
        assert trace.ttft_ms is None
        assert trace.created_at <= (trace.finished_at or trace.created_at)

    def test_ttft_recorded_after_first_chunk(self) -> None:
        recorder = make_recorder(stream=True)
        recorder.mark_first_token()
        recorder.mark_first_token()
        trace = recorder.success()

        assert trace.ttft_ms is not None
        assert 0 <= trace.ttft_ms <= trace.latency_ms

    def test_failure_trace(self) -> None:
        trace = make_recorder().failure("upstream_timeout")
        assert trace.status == TraceStatus.FAILED
        assert trace.error_type == "upstream_timeout"
        assert trace.usage is None

    def test_bind_response_id_prefers_upstream(self) -> None:
        recorder = make_recorder()
        recorder.bind_response_id("chatcmpl-up-1")
        assert recorder.response_id == "chatcmpl-up-1"
        recorder.bind_response_id("")
        assert recorder.response_id == "chatcmpl-up-1"

    def test_bind_route(self) -> None:
        recorder = make_recorder(provider="", upstream_model="")
        recorder.bind_route("anthropic", "claude-3-5-sonnet-20241022")
        trace = recorder.success()
        assert trace.provider == "anthropic"
        assert trace.upstream_model == "claude-3-5-sonnet-20241022"

    def test_structured_log_fields(self, caplog: pytest.LogCaptureFixture) -> None:
        recorder = make_recorder(stream=True)
        recorder.mark_first_token()
        with caplog.at_level(logging.INFO, logger="llm_gateway"):
            recorder.success(Usage(prompt_tokens=1, completion_tokens=1, total_tokens=2))

        record = next(r for r in caplog.records if r.getMessage() == "llm_call_finished")
        assert record.request_id == "req-1"
        assert record.model == "gpt-4o-mini"
        assert record.provider == "openai"
        assert record.status == "success"
        assert record.ttft_ms >= 0
        assert record.usage == {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}
        assert not hasattr(record, "content")

    def test_failure_logged_as_warning(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.WARNING, logger="llm_gateway"):
            make_recorder().failure("provider_error")

        record = next(r for r in caplog.records if r.getMessage() == "llm_call_failed")
        assert record.error_type == "provider_error"
        assert record.status == "failed"

    def test_id_generators_unique(self) -> None:
        assert new_request_id().startswith("req-")
        assert new_response_id().startswith("resp-")
        assert new_trace_id().startswith("trace-")
        assert len({new_trace_id() for _ in range(50)}) == 50
