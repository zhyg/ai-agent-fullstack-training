"""超时、重试与限流测试（T-811）。"""

from typing import Any

import httpx
import pytest
from support import openai_completion

from app.config import ProviderConfig, RequestConfig
from app.errors import ProviderError, RateLimited, UpstreamTimeout
from app.providers.anthropic import AnthropicProvider
from app.providers.openai import OpenAIProvider
from app.schemas import Message, ProviderRequest

CONFIG = ProviderConfig(
    type="openai", base_url="https://mock-openai.test/v1", api_key_env="MOCK_OPENAI_KEY"
)
ANTHROPIC_CONFIG = ProviderConfig(
    type="anthropic",
    base_url="https://mock-anthropic.test",
    api_key_env="MOCK_ANTHROPIC_KEY",
)


def preq(stream: bool = False) -> ProviderRequest:
    """最小内部请求。"""
    return ProviderRequest(
        request_id="req-1",
        upstream_model="gpt-4o-mini",
        messages=[Message(role="user", content="hi")],
        stream=stream,
    )


def make_openai(handler: Any, **request_kwargs: Any) -> OpenAIProvider:
    """构造可配置重试参数的 OpenAI provider。"""
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    params: dict[str, Any] = {
        "connect_timeout": 1,
        "read_timeout": 1,
        "max_retries": 2,
        "backoff_base": 0.001,
    }
    params.update(request_kwargs)
    return OpenAIProvider(
        name="openai",
        config=CONFIG,
        request_config=RequestConfig(**params),
        client=client,
    )


class TestRetryPolicy:
    """T-504：仅超时/429/5xx 重试，指数退避，次数可配。"""

    async def test_429_then_success(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            if calls == 1:
                return httpx.Response(429, json={"error": {"message": "slow down"}})
            return httpx.Response(200, json=openai_completion())

        result = await make_openai(handler).chat(preq())
        assert calls == 2
        assert result.message.content == '{"answer": 42}'

    async def test_5xx_retries_then_normalizes(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            return httpx.Response(503, json={"error": {"message": "unavailable"}})

        with pytest.raises(ProviderError) as exc:
            await make_openai(handler).chat(preq())
        assert calls == 3  # 1 + 2 retries
        assert exc.value.status_code == 502

    async def test_429_exhausted_maps_rate_limited(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(429, json={"error": {"message": "slow down"}})

        with pytest.raises(RateLimited):
            await make_openai(handler).chat(preq())

    async def test_400_not_retried(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            return httpx.Response(400, json={"error": {"message": "bad request"}})

        with pytest.raises(ProviderError):
            await make_openai(handler).chat(preq())
        assert calls == 1

    async def test_zero_retries_configurable(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            return httpx.Response(500, json={"error": {"message": "boom"}})

        with pytest.raises(ProviderError):
            await make_openai(handler, max_retries=0).chat(preq())
        assert calls == 1

    async def test_timeout_retries_then_fails(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            raise httpx.ConnectTimeout("connect timed out", request=request)

        with pytest.raises(UpstreamTimeout):
            await make_openai(handler).chat(preq())
        assert calls == 3


class TestStreamNoRetry:
    """T-504：流式默认不重试。"""

    async def test_stream_error_status_single_attempt(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            return httpx.Response(500, json={"error": {"message": "boom"}})

        provider = make_openai(handler)
        with pytest.raises(ProviderError):
            _ = [chunk async for chunk in provider.chat_stream(preq(stream=True))]
        assert calls == 1

    async def test_anthropic_stream_single_attempt(self) -> None:
        calls = 0

        async def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            error_body = {
                "type": "error",
                "error": {"type": "rate_limit", "message": "slow"},
            }
            return httpx.Response(429, json=error_body)

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        provider = AnthropicProvider(
            name="anthropic",
            config=ANTHROPIC_CONFIG,
            request_config=RequestConfig(max_retries=2, backoff_base=0.001),
            client=client,
        )
        stream_preq = ProviderRequest(
            request_id="req-1",
            upstream_model="claude-3-5-sonnet-20241022",
            messages=[Message(role="user", content="hi")],
            stream=True,
        )
        with pytest.raises(RateLimited):
            _ = [chunk async for chunk in provider.chat_stream(stream_preq)]
        assert calls == 1
