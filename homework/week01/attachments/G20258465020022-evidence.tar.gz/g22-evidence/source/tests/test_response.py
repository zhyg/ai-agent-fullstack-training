"""响应处理测试：JSON 提取、围栏、Schema 校验与事件封装（T-808）。"""

import pytest

from app.errors import SchemaValidationError
from app.response import (
    ResponseContext,
    build_delta_event,
    build_done_event,
    build_error_event,
    build_non_stream_response,
    build_response,
    build_start_event,
    extract_json,
    process_non_stream_output,
    sse_event,
    strip_code_fences,
    validate_with_schema,
)
from app.schemas import (
    ErrorDetail,
    LLMResponse,
    Message,
    PromptTrace,
    ResponseEvent,
    ResponseScheme,
    ResponseStatus,
    Usage,
)

SCHEME = ResponseScheme(
    name="answer",
    json_schema={
        "type": "object",
        "properties": {"answer": {"type": "integer"}},
        "required": ["answer"],
    },
)


def ctx() -> ResponseContext:
    """构造响应上下文。"""
    return ResponseContext(
        request_id="req-1",
        response_id="resp-1",
        created=1730000000,
        model="gpt-4o-mini",
        provider="openai",
        prompt=PromptTrace(name="demo", version="1", content_hash="sha256:abc"),
    )


class TestJsonExtraction:
    """T-601/T-808：围栏去除、提取与 invalid_json。"""

    def test_plain_json(self) -> None:
        assert extract_json('{"answer": 1}') == {"answer": 1}

    def test_json_with_code_fence(self) -> None:
        text = '```json\n{"answer": 2}\n```'
        assert extract_json(text) == {"answer": 2}

    def test_fence_with_surrounding_text(self) -> None:
        text = '结果如下：\n```json\n{"answer": 3}\n```\n以上。'
        assert extract_json(text) == {"answer": 3}

    def test_strip_fences_idempotent_for_plain(self) -> None:
        assert strip_code_fences('{"a": 1}') == '{"a": 1}'

    def test_invalid_json_raises_invalid_json(self) -> None:
        with pytest.raises(SchemaValidationError) as exc:
            extract_json("对不起，我无法输出 JSON")
        assert exc.value.code == "invalid_json"
        assert exc.value.status_code == 422

    def test_json_array_extraction(self) -> None:
        assert extract_json("answer: [1, 2, 3]") == [1, 2, 3]


class TestSchemaValidation:
    """T-602/T-808：schema 通过、不匹配与非法 schema。"""

    def test_valid_payload(self) -> None:
        data = validate_with_schema({"answer": 42}, SCHEME)
        assert data == {"answer": 42}

    def test_mismatch_raises_schema_mismatch(self) -> None:
        with pytest.raises(SchemaValidationError) as exc:
            validate_with_schema({"answer": "not-int"}, SCHEME)
        assert exc.value.code == "schema_mismatch"

    def test_invalid_schema_definition(self) -> None:
        bad = ResponseScheme(name="bad", json_schema={"type": "not-a-type"})
        with pytest.raises(SchemaValidationError):
            validate_with_schema({}, bad)

    def test_process_end_to_end(self) -> None:
        assert process_non_stream_output('```json\n{"answer": 7}\n```', SCHEME) == {"answer": 7}

    def test_process_failure_no_partial_result(self) -> None:
        with pytest.raises(SchemaValidationError):
            process_non_stream_output('{"answer": "x"}', SCHEME)


class TestEventBuilding:
    """T-603~T-605、T-701：统一响应事件结构。"""

    def test_start_event(self) -> None:
        resp = build_start_event(ctx())
        assert resp.event == ResponseEvent.START
        assert resp.status == ResponseStatus.IN_PROGRESS
        assert resp.choices[0].delta is not None
        assert resp.choices[0].delta.role is not None

    def test_delta_event(self) -> None:
        resp = build_delta_event(ctx(), "chunk")
        assert resp.event == ResponseEvent.DELTA
        assert resp.status == ResponseStatus.IN_PROGRESS
        assert resp.choices[0].delta is not None
        assert resp.choices[0].delta.content == "chunk"

    def test_done_event_carries_finish_usage_trace(self) -> None:
        usage = Usage(prompt_tokens=1, completion_tokens=2, total_tokens=3)
        resp = build_done_event(ctx(), finish_reason="stop", usage=usage, trace=None)
        assert resp.event == ResponseEvent.DONE
        assert resp.status == ResponseStatus.SUCCESS
        assert resp.choices[0].finish_reason == "stop"
        assert resp.usage == usage

    def test_error_event(self) -> None:
        error = ErrorDetail(type="provider_error", message="boom", code="provider_error")
        resp = build_error_event(ctx(), error=error, trace=None)
        assert resp.event == ResponseEvent.ERROR
        assert resp.status == ResponseStatus.FAILED
        assert resp.error == error
        assert resp.choices == []

    def test_non_stream_response_shape(self) -> None:
        resp = build_non_stream_response(
            ctx(),
            message=Message(role="assistant", content='{"answer": 1}'),
            parsed={"answer": 1},
            finish_reason="stop",
            usage=None,
            trace=None,
        )
        assert resp.event == ResponseEvent.DONE and resp.status == ResponseStatus.SUCCESS
        assert resp.choices[0].message is not None
        assert resp.choices[0].parsed == {"answer": 1}
        assert resp.prompt is not None and resp.prompt.name == "demo"

    def test_sse_event_format(self) -> None:
        resp = build_response(
            ctx(),
            event=ResponseEvent.START,
            status=ResponseStatus.IN_PROGRESS,
            choices=[],
        )
        line = sse_event(resp)
        assert line.startswith("data: ") and line.endswith("\n\n")
        parsed = LLMResponse.model_validate_json(line[len("data:") :].strip())
        assert parsed.request_id == "req-1"
