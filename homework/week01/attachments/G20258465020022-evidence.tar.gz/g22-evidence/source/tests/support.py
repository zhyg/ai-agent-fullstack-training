"""测试辅助工具：Mock 上游响应构造与网关/应用装配。"""

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx
from fastapi.testclient import TestClient

from app.config import GatewayConfig
from app.gateway import Gateway
from app.main import create_app

Handler = Callable[[httpx.Request], httpx.Response] | Any


def base_config_dict(prompts_dir: Path) -> dict[str, Any]:
    """构造指向 Mock 上游的完整测试配置。"""
    return {
        "providers": {
            "openai": {
                "type": "openai",
                "base_url": "https://mock-openai.test/v1",
                "api_key_env": "MOCK_OPENAI_KEY",
            },
            "anthropic": {
                "type": "anthropic",
                "base_url": "https://mock-anthropic.test",
                "api_key_env": "MOCK_ANTHROPIC_KEY",
            },
        },
        "models": {
            "gpt-4o-mini": {"provider": "openai", "upstream_model": "gpt-4o-mini"},
            "deepseek-chat": {"provider": "openai", "upstream_model": "deepseek-chat"},
            "claude-3-5-sonnet": {
                "provider": "anthropic",
                "upstream_model": "claude-3-5-sonnet-20241022",
            },
            "gpt-*": {"provider": "openai", "upstream_model": "{model}"},
        },
        "prompts": {"dir": str(prompts_dir)},
        "trace": {"include_in_response": True},
        "request": {
            "connect_timeout": 2,
            "read_timeout": 5,
            "max_retries": 2,
            "backoff_base": 0.001,
        },
    }


def openai_completion(content: str = '{"answer": 42}', finish: str = "stop") -> dict[str, Any]:
    """OpenAI 非流式响应体。"""
    return {
        "id": "chatcmpl-mock-1",
        "object": "chat.completion",
        "created": 1730000000,
        "model": "gpt-4o-mini",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": finish,
            }
        ],
        "usage": {"prompt_tokens": 5, "completion_tokens": 7, "total_tokens": 12},
    }


def openai_sse(deltas: list[str], finish: str = "stop") -> bytes:
    """OpenAI 流式 SSE 字节流。"""
    events: list[dict[str, Any]] = [
        {"id": "chatcmpl-mock-1", "choices": [{"index": 0, "delta": {"role": "assistant"}}]},
    ]
    events.extend(
        {"id": "chatcmpl-mock-1", "choices": [{"index": 0, "delta": {"content": part}}]}
        for part in deltas
    )
    events.append(
        {
            "id": "chatcmpl-mock-1",
            "choices": [{"index": 0, "delta": {}, "finish_reason": finish}],
            "usage": {"prompt_tokens": 3, "completion_tokens": 4, "total_tokens": 7},
        }
    )
    text = "".join(f"data: {json.dumps(event)}\n\n" for event in events)
    text += "data: [DONE]\n\n"
    return text.encode("utf-8")


def anthropic_message(content: str = '{"answer": 42}', stop: str = "end_turn") -> dict[str, Any]:
    """Anthropic 非流式响应体。"""
    return {
        "id": "msg_mock_1",
        "type": "message",
        "role": "assistant",
        "content": [{"type": "text", "text": content}],
        "stop_reason": stop,
        "usage": {"input_tokens": 3, "output_tokens": 4},
    }


def anthropic_sse(deltas: list[str], stop: str = "end_turn") -> bytes:
    """Anthropic 流式 SSE 事件流。"""
    events: list[dict[str, Any]] = [
        {
            "type": "message_start",
            "message": {"id": "msg_mock_1", "usage": {"input_tokens": 8, "output_tokens": 1}},
        },
        {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
    ]
    events.extend(
        {
            "type": "content_block_delta",
            "index": 0,
            "delta": {"type": "text_delta", "text": part},
        }
        for part in deltas
    )
    events.append({"type": "content_block_stop", "index": 0})
    events.append(
        {"type": "message_delta", "delta": {"stop_reason": stop}, "usage": {"output_tokens": 6}}
    )
    events.append({"type": "message_stop"})
    return "".join(f"data: {json.dumps(event)}\n\n" for event in events).encode("utf-8")


def make_gateway(config: GatewayConfig, handler: Handler) -> Gateway:
    """构造注入 MockTransport 客户端的网关实例。"""
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return Gateway(config, client=client)


def make_client(gateway: Gateway) -> TestClient:
    """构造绑定网关实例的 TestClient。"""
    return TestClient(create_app(gateway=gateway))


def sse_lines(text: str) -> list[str]:
    """提取 SSE 响应中的 data 载荷列表。"""
    return [
        line[len("data:") :].strip()
        for line in text.splitlines()
        if line.startswith("data:")
    ]
