"""提示词注册表、hash、变量替换与消息装配测试（T-803、T-804、T-812 hash 部分）。"""

import pytest

from app.errors import InvalidRequest
from app.prompts import (
    MessageBuilder,
    PromptRegistry,
    compute_content_hash,
    substitute_variables,
)
from app.schemas import LLMRequest, Message, PromptRef, PromptTemplate

SCHEME = {"type": "object"}


def template_data(**overrides: object) -> dict[str, object]:
    """构造模板数据。"""
    data: dict[str, object] = {
        "name": "demo",
        "version": "1",
        "status": "active",
        "variables": ["who"],
        "messages": [{"role": "system", "content": "hello {{who}}"}],
    }
    data.update(overrides)
    return data


def load_registry(items: list[dict[str, object]]) -> PromptRegistry:
    """从内存数据构造注册表。"""
    registry = PromptRegistry()
    registry.load_from_data(items)
    return registry


class TestRegistry:
    """T-803：加载、重复版本、版本解析与 hash。"""

    def test_load_from_directory(self, prompts_dir: object) -> None:
        registry = PromptRegistry()
        count = registry.load_from_directory(prompts_dir)  # type: ignore[arg-type]
        assert count == 2
        assert registry.names() == ["customer_support"]
        assert list(registry.versions_of("customer_support")) == ["1", "2"]

    def test_duplicate_version_rejected(self) -> None:
        with pytest.raises(InvalidRequest, match="重复"):
            load_registry([template_data(), template_data()])

    def test_explicit_version_resolution(self) -> None:
        registry = load_registry(
            [
                template_data(version="1"),
                template_data(
                    version="2",
                    status="deprecated",
                    messages=[{"role": "system", "content": "v2"}],
                ),
            ]
        )
        template = registry.resolve(PromptRef(name="demo", version="2", variables={}))
        assert template.version == "2"

    def test_missing_explicit_version_rejected(self) -> None:
        registry = load_registry([template_data()])
        with pytest.raises(InvalidRequest, match="不存在"):
            registry.resolve(PromptRef(name="demo", version="9", variables={}))

    def test_latest_active_version_when_unspecified(self) -> None:
        registry = load_registry(
            [
                template_data(version="1"),
                template_data(
                    version="2",
                    status="draft",
                    messages=[{"role": "system", "content": "draft {{who}}"}],
                ),
                template_data(
                    version="3", messages=[{"role": "system", "content": "v3 {{who}}"}]
                ),
            ]
        )
        template = registry.resolve(PromptRef(name="demo", variables={"who": "x"}))
        assert template.version == "3"

    def test_no_active_version_rejected(self) -> None:
        registry = load_registry([template_data(status="draft")])
        with pytest.raises(InvalidRequest, match="active"):
            registry.resolve(PromptRef(name="demo", variables={"who": "x"}))

    def test_content_hash_stable_and_prefixed(self) -> None:
        first = compute_content_hash(PromptTemplate.model_validate(template_data()))
        second = compute_content_hash(PromptTemplate.model_validate(template_data()))
        assert first == second
        assert first.startswith("sha256:")

    def test_content_hash_changes_with_content(self) -> None:
        base = compute_content_hash(PromptTemplate.model_validate(template_data()))
        changed = compute_content_hash(
            PromptTemplate.model_validate(
                template_data(messages=[{"role": "system", "content": "bye {{who}}"}])
            )
        )
        assert base != changed

    def test_registry_assigns_hash_on_load(self) -> None:
        registry = load_registry([template_data()])
        template = registry.resolve(PromptRef(name="demo", variables={"who": "a"}))
        assert template.content_hash and template.content_hash.startswith("sha256:")

    def test_unknown_name_rejected(self) -> None:
        registry = load_registry([template_data()])
        with pytest.raises(InvalidRequest, match="不存在"):
            registry.resolve(PromptRef(name="missing", variables={}))


class TestVariables:
    """T-804：字面量替换、缺失变量报错、额外变量忽略。"""

    def test_substitute_with_whitespace_tolerance(self) -> None:
        assert substitute_variables("a {{ x }} b {{y}}", {"x": "1", "y": "2"}) == "a 1 b 2"

    def test_missing_declared_variable_rejected(self) -> None:
        registry = load_registry([template_data()])
        template = registry.resolve(PromptRef(name="demo", variables={}))
        with pytest.raises(InvalidRequest) as exc:
            registry.render(template, {})
        assert exc.value.code == "missing_prompt_variable"

    def test_extra_variables_ignored(self) -> None:
        registry = load_registry([template_data()])
        messages, used = registry.resolve_and_render(
            PromptRef(name="demo", variables={"who": "bob", "unrelated": 1})
        )
        assert messages[0].content == "hello bob"
        assert used.name == "demo"

    def test_undeclared_placeholder_kept_literal(self) -> None:
        registry = load_registry(
            [template_data(messages=[{"role": "system", "content": "{{who}} {{ghost}}"}])]
        )
        messages, _ = registry.resolve_and_render(PromptRef(name="demo", variables={"who": "x"}))
        assert messages[0].content == "x {{ghost}}"

    def test_non_string_values_serialized(self) -> None:
        registry = load_registry([template_data()])
        messages, _ = registry.resolve_and_render(PromptRef(name="demo", variables={"who": 42}))
        assert messages[0].content == "hello 42"


class TestBuildMessage:
    """T-804/T-306：模板消息在前、调用方消息追加在后。"""

    def request(self, **overrides: object) -> LLMRequest:
        data: dict[str, object] = {
            "model": "m",
            "response_scheme": {"json_schema": SCHEME},
        }
        data.update(overrides)
        return LLMRequest.model_validate(data)

    def test_template_first_caller_second(self) -> None:
        registry = load_registry([template_data()])
        builder = MessageBuilder(registry)
        req = self.request(
            prompt={"name": "demo", "variables": {"who": "world"}},
            messages=[{"role": "user", "content": "follow up"}],
        )
        result = builder.build(req)
        assert [m.content for m in result.messages] == ["hello world", "follow up"]
        assert result.prompt is not None
        assert result.prompt.name == "demo"
        assert result.prompt.content_hash.startswith("sha256:")

    def test_no_prompt_uses_caller_messages(self) -> None:
        registry = load_registry([template_data()])
        builder = MessageBuilder(registry)
        req = self.request(messages=[{"role": "user", "content": "only"}])
        result = builder.build(req)
        assert result.messages == [Message(role="user", content="only")]
        assert result.prompt is None

    def test_empty_messages_and_prompt_rejected(self) -> None:
        registry = load_registry([template_data()])
        req = LLMRequest.model_construct(
            request_id=None,
            model="m",
            messages=[],
            prompt=None,
            temperature=None,
            max_tokens=None,
            stream=False,
            response_scheme=None,
            extra={},
        )
        with pytest.raises(InvalidRequest):
            MessageBuilder(registry).build(req)
