"""Anthropic provider 测试：system 消息、max_tokens、SSE 事件与错误映射（T-807）。"""

import json
from typing import Any

import httpx
import pytest

from app.config import ProviderConfig, RequestConfig
from app.errors import AuthenticationError, ProviderError
from app.providers.anthropic import AnthropicProvider
from app.schemas import Message, ProviderRequest, ResponseScheme

SCHEME = ResponseScheme(name="answer", json_schema={"type": "object"})

REQUEST_CONFIG = RequestConfig(connect_timeout=1, read_timeout=2, max_retries=0, backoff_base=0.001)


def make_provider(handler: Any) -> AnthropicProvider:
    """构造挂接 MockTransport 的 Anthropic provider。"""
    config = ProviderConfig(
        type="anthropic",
        base_url="https://mock-anthropic.test",
        api_key_env="MOCK_ANTHROPIC_KEY",
    )
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return AnthropicProvider(
        name="anthropic", config=config, request_config=REQUEST_CONFIG, client=client
    )


def preq(messages: list[Message], **overrides: Any) -> ProviderRequest:
    """内部 provider 请求。"""
    data: dict[str, Any] = {
        "request_id": "req-1",
        "upstream_model": "claude-3-5-sonnet-20241022",
        "messages": messages,
        "stream": False,
        "response_scheme": SCHEME,
    }
    data.update(overrides)
    return ProviderRequest.model_validate(data)


class TestRequestMapping:
    """T-507：system 拆分与 max_tokens。"""

    async def test_system_extracted_and_headers(self) -> None:
        captured: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["headers"] = dict(request.headers)
            captured["url"] = str(request.url)
            captured["body"] = json.loads(request.content)
            from support import anthropic_message

            return httpx.Response(200, json=anthropic_message())

        provider = make_provider(handler)
        await provider.chat(
            preq(
                [
                    Message(role="system", content="你是助手"),
                    Message(role="user", content="hi"),
                    Message(role="assistant", content="hello"),
                    Message(role="user", content="again"),
                ],
                max_tokens=128,
                temperature=0.5,
            )
        )

        assert captured["url"] == "https://mock-anthropic.test/v1/messages"
        assert captured["headers"]["x-api-key"] == "mock-anthropic-key"
        assert captured["headers"]["anthropic-version"] == "2023-06-01"
        body = captured["body"]
        assert body["system"].startswith("你是助手")
        assert "answer" in body["system"]
        assert [m["role"] for m in body["messages"]] == ["user", "assistant", "user"]
        assert body["max_tokens"] == 128
        assert body["temperature"] == 0.5
        assert body["stream"] is False

    async def test_default_max_tokens_when_missing(self) -> None:
        captured: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            from support import anthropic_message

            return httpx.Response(200, json=anthropic_message())

        await make_provider(handler).chat(preq([Message(role="user", content="hi")]))
        assert captured["body"]["max_tokens"] == 1024

    async def test_json_instruction_via_system(self) -> None:
        captured: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            from support import anthropic_message

            return httpx.Response(200, json=anthropic_message())

        await make_provider(handler).chat(preq([Message(role="user", content="hi")]))
        assert "JSON Schema" in captured["body"]["system"]


class TestResponseNormalization:
    """T-507：响应与 usage 字段映射。"""

    async def test_parse_result(self) -> None:
        from support import anthropic_message

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=anthropic_message('{"answer": 9}', stop="max_tokens"))

        result = await make_provider(handler).chat(preq([Message(role="user", content="hi")]))
        assert result.response_id == "msg_mock_1"
        assert result.message.content == '{"answer": 9}'
        assert result.finish_reason == "length"
        assert (result.usage.prompt_tokens, result.usage.completion_tokens) == (3, 4)
        assert result.usage.total_tokens == 7


class TestStreamParsing:
    """T-508：Anthropic SSE 事件转统一增量。"""

    async def test_events_normalized(self) -> None:
        from support import anthropic_sse

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, content=anthropic_sse(["Hi", " there"], stop="max_tokens"))

        provider = make_provider(handler)
        chunks = [
            chunk
            async for chunk in provider.chat_stream(
                preq([Message(role="user", content="hi")], stream=True, response_scheme=None)
            )
        ]

        texts = [c.delta.content for c in chunks if c.delta.content]
        assert texts == ["Hi", " there"]
        assert chunks[0].delta.role is not None
        final = chunks[-1]
        assert final.finish_reason == "length"
        assert final.usage is not None
        assert final.usage.prompt_tokens == 8
        assert final.usage.completion_tokens == 6
        assert all(c.response_id == "msg_mock_1" for c in chunks)

    async def test_ignores_non_text_events(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            body = (
                b'data: {"type":"ping"}\n\n'
                b'data: {"type":"content_block_delta","delta":'
                b'{"type":"input_json_delta","partial_json":"{}"}}\n\n'
            )
            return httpx.Response(200, content=body)

        provider = make_provider(handler)
        chunks = [
            chunk
            async for chunk in provider.chat_stream(
                preq([Message(role="user", content="hi")], stream=True, response_scheme=None)
            )
        ]
        assert chunks == []


class TestErrorNormalization:
    """T-510/T-807：错误映射。"""

    async def test_invalid_key(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            error_body = {
                "type": "error",
                "error": {"type": "authentication_error", "message": "invalid x-api-key"},
            }
            return httpx.Response(401, json=error_body)

        with pytest.raises(AuthenticationError):
            await make_provider(handler).chat(preq([Message(role="user", content="hi")]))

    async def test_overloaded(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            error_body = {
                "type": "error",
                "error": {"type": "overloaded_error", "message": "Overloaded"},
            }
            return httpx.Response(529, json=error_body)

        with pytest.raises(ProviderError):
            await make_provider(handler).chat(preq([Message(role="user", content="hi")]))

    async def test_stream_error_status(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            error_body = {
                "type": "error",
                "error": {"type": "invalid_request_error", "message": "bad"},
            }
            return httpx.Response(400, json=error_body)

        provider = make_provider(handler)
        with pytest.raises(ProviderError):
            _ = [
                chunk
                async for chunk in provider.chat_stream(
                    preq([Message(role="user", content="hi")], stream=True, response_scheme=None)
                )
            ]
