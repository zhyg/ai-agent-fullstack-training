"""OpenAI 兼容 provider 测试（T-806）。"""

import json
from typing import Any

import httpx
import pytest

from app.config import ProviderConfig, RequestConfig
from app.errors import (
    AuthenticationError,
    NotFound,
    ProviderError,
    RateLimited,
    UpstreamTimeout,
)
from app.providers.openai import OpenAIProvider
from app.schemas import Message, ProviderRequest, ResponseScheme

SCHEME = ResponseScheme(name="answer", json_schema={"type": "object"})

REQUEST_CONFIG = RequestConfig(connect_timeout=1, read_timeout=2, max_retries=0, backoff_base=0.001)


def make_provider(handler: Any) -> OpenAIProvider:
    """构造挂接 MockTransport 的 OpenAI provider。"""
    config = ProviderConfig(
        type="openai",
        base_url="https://mock-openai.test/v1",
        api_key_env="MOCK_OPENAI_KEY",
    )
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return OpenAIProvider(
        name="openai", config=config, request_config=REQUEST_CONFIG, client=client
    )


def preq(stream: bool = False) -> ProviderRequest:
    """内部 provider 请求。"""
    return ProviderRequest(
        request_id="req-1",
        upstream_model="gpt-4o-mini",
        messages=[Message(role="user", content="hi")],
        temperature=0.3,
        max_tokens=64,
        stream=stream,
        response_scheme=None if stream else SCHEME,
        extra={"top_p": 0.9},
    )


class TestRequestMapping:
    """T-505/T-806：请求体映射。"""

    async def test_non_stream_body(self) -> None:
        captured: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["auth"] = request.headers.get("Authorization")
            captured["body"] = json.loads(request.content)
            payload = {
                "id": "c1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "{}"},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            }
            return httpx.Response(200, json=payload)

        provider = make_provider(handler)
        await provider.chat(preq())

        assert captured["url"] == "https://mock-openai.test/v1/chat/completions"
        assert captured["auth"] == "Bearer sk-mock-openai"
        body = captured["body"]
        assert body["model"] == "gpt-4o-mini"
        assert body["messages"] == [{"role": "user", "content": "hi"}]
        assert body["temperature"] == 0.3
        assert body["max_tokens"] == 64
        assert body["stream"] is False
        assert body["top_p"] == 0.9
        assert body["response_format"]["json_schema"]["name"] == "answer"

    async def test_stream_body_has_stream_options(self) -> None:
        captured: dict[str, Any] = {}

        async def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, content=b"data: [DONE]\n\n")

        provider = make_provider(handler)
        _ = [chunk async for chunk in provider.chat_stream(preq(stream=True))]
        assert captured["body"]["stream"] is True
        assert captured["body"]["stream_options"] == {"include_usage": True}
        assert "response_format" not in captured["body"]


class TestResponseNormalization:
    """T-505：响应字段与 usage 归一化。"""

    async def test_parse_result(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                json={
                    "id": "chatcmpl-9",
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": '{"answer": 1}'},
                            "finish_reason": "stop",
                        }
                    ],
                    "usage": {"prompt_tokens": 5, "completion_tokens": 7},
                },
            )

        result = await make_provider(handler).chat(preq())
        assert result.response_id == "chatcmpl-9"
        assert result.message.content == '{"answer": 1}'
        assert result.message.role.value == "assistant"
        assert result.finish_reason == "stop"
        assert result.usage.total_tokens == 12

    async def test_missing_choices_raises(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"id": "x", "choices": []})

        with pytest.raises(ProviderError):
            await make_provider(handler).chat(preq())


class TestStreamParsing:
    """T-506：SSE 增量、结束块与 usage。"""

    async def test_chunks_normalized(self) -> None:
        from support import openai_sse

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                content=openai_sse(["你好", "世界"]),
                headers={"content-type": "text/event-stream"},
            )

        chunks = [chunk async for chunk in make_provider(handler).chat_stream(preq(stream=True))]

        assert chunks[0].delta.role is not None
        contents = [c.delta.content for c in chunks if c.delta.content is not None]
        assert contents == ["你好", "世界"]
        final = chunks[-1]
        assert final.finish_reason == "stop"
        assert final.usage is not None and final.usage.total_tokens == 7
        assert all(c.response_id == "chatcmpl-mock-1" for c in chunks)

    async def test_skips_garbage_and_done(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            body = (
                b"data: not-json\n\n"
                b"data: \n\n"
                b"event: ping\n\n"
                b'data: {"id":"c1","choices":[{"index":0,"delta":'
                b'{"content":"ok"},"finish_reason":null}]}\n\n'
                b"data: [DONE]\n\n"
            )
            return httpx.Response(200, content=body)

        chunks = [chunk async for chunk in make_provider(handler).chat_stream(preq(stream=True))]
        assert len(chunks) == 1
        assert chunks[0].delta.content == "ok"


class TestErrorNormalization:
    """T-510：上游错误归一化。"""

    async def test_401_auth_error(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                401, json={"error": {"message": "Invalid API key", "code": "invalid_api_key"}}
            )

        with pytest.raises(AuthenticationError):
            await make_provider(handler).chat(preq())

    async def test_400_provider_error(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(400, json={"error": {"message": "bad param"}})

        with pytest.raises(ProviderError):
            await make_provider(handler).chat(preq())

    async def test_404_not_found(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"error": {"message": "model not found"}})

        with pytest.raises(NotFound):
            await make_provider(handler).chat(preq())

    async def test_429_maps_rate_limited(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(429, json={"error": {"message": "slow down"}})

        with pytest.raises(RateLimited):
            await make_provider(handler).chat(preq())

    async def test_timeout_maps_upstream_timeout(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("boom", request=request)

        with pytest.raises(UpstreamTimeout):
            await make_provider(handler).chat(preq())

    async def test_content_filter_normalized(self) -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(400, json={"error": {"message": "blocked by content_filter"}})

        with pytest.raises(ProviderError) as exc:
            await make_provider(handler).chat(preq())
        assert exc.value.code == "content_filtered"
