"""网关运行时容器：装配配置、provider、路由与提示词注册表。"""

import httpx

from .config import GatewayConfig, load_config
from .prompts import MessageBuilder, PromptRegistry
from .providers import BaseProvider, build_providers, close_providers
from .router import ModelRouter


class Gateway:
    """持有网关全部运行期依赖，供 API 层注入使用。"""

    def __init__(self, config: GatewayConfig, client: httpx.AsyncClient | None = None) -> None:
        self.config = config
        self._client = client
        self._owns_client = client is None

        self.registry = PromptRegistry()
        self.registry.load_from_directory(config.prompts.dir)
        self.builder = MessageBuilder(self.registry)

        self.providers: dict[str, BaseProvider] = build_providers(config, client)
        self.router = ModelRouter(config, self.providers)

    @classmethod
    def create(cls, config_path: str | None = None) -> "Gateway":
        """加载配置并构造网关实例。"""
        return cls(load_config(config_path))

    def build_http_timeout(self) -> httpx.Timeout:
        """按配置构造共享客户端超时。"""
        return httpx.Timeout(
            connect=self.config.request.connect_timeout,
            read=self.config.request.read_timeout,
            write=self.config.request.connect_timeout,
            pool=self.config.request.connect_timeout,
        )

    async def start(self) -> None:
        """应用启动时创建共享 AsyncClient 并重新装配 provider。"""
        if self._client is not None:
            return

        self._client = httpx.AsyncClient(
            timeout=self.build_http_timeout(),
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
        )
        self._owns_client = True
        self.providers = build_providers(self.config, self._client)
        self.router = ModelRouter(self.config, self.providers)

    async def stop(self) -> None:
        """应用关闭时释放 provider 与 HTTP 客户端。"""
        await close_providers(self.providers)
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        self._owns_client = False

    def provider_names(self) -> list[str]:
        """返回已装配的 provider 名称列表。"""
        return list(self.providers)

    @property
    def include_trace_in_response(self) -> bool:
        """是否在响应中返回 CallTrace。"""
        return self.config.trace.include_in_response
