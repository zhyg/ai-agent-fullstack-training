"""配置模型与加载逻辑。"""

import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field, ValidationError

from .errors import GatewayError

DEFAULT_CONFIG_CANDIDATES = ("config.yaml", "config.yml", "config.example.yaml")


class ProviderConfig(BaseModel):
    """单个 provider 的连接配置。"""

    type: str = Field(..., description="provider 类型：openai / anthropic")
    base_url: str = Field(..., description="上游 API 基础地址")
    api_key_env: str = Field(..., description="读取 API Key 的环境变量名")


class ModelConfig(BaseModel):
    """一条模型路由配置。"""

    provider: str = Field(..., description="provider 名称")
    upstream_model: str = Field(
        ..., description="上游真实模型名，通配规则中可用 {model} 占位"
    )


class PromptsConfig(BaseModel):
    """提示词存储配置。"""

    dir: str = Field(default="./prompts", description="提示词 YAML 目录")


class TraceConfig(BaseModel):
    """调用追踪输出配置。"""

    include_in_response: bool = Field(default=True, description="是否在响应中返回 trace")


class RequestConfig(BaseModel):
    """请求超时与重试配置。"""

    connect_timeout: float = Field(default=5.0, gt=0, description="连接超时（秒）")
    read_timeout: float = Field(default=60.0, gt=0, description="读取超时（秒）")
    max_retries: int = Field(default=2, ge=0, description="最大重试次数")
    backoff_base: float = Field(default=0.5, gt=0, description="指数退避基数（秒）")


class GatewayConfig(BaseModel):
    """网关完整配置。"""

    providers: dict[str, ProviderConfig] = Field(
        default_factory=dict, description="provider 名称 -> 连接配置"
    )
    models: dict[str, ModelConfig] = Field(
        default_factory=dict, description="逻辑模型名 -> 路由配置，键支持通配符"
    )
    prompts: PromptsConfig = Field(default_factory=PromptsConfig, description="提示词配置")
    trace: TraceConfig = Field(default_factory=TraceConfig, description="追踪配置")
    request: RequestConfig = Field(default_factory=RequestConfig, description="请求配置")


def resolve_config_path(config_path: str | Path | None = None) -> Path | None:
    """按 CONFIG_PATH 环境变量与默认候选文件解析配置路径。"""
    if config_path is not None:
        return Path(config_path)

    env_path = os.environ.get("CONFIG_PATH")
    if env_path:
        return Path(env_path)

    for candidate in DEFAULT_CONFIG_CANDIDATES:
        path = Path(candidate)
        if path.exists():
            return path
    return None


def load_config(
    config_path: str | Path | None = None, *, env_file: str | Path = ".env"
) -> GatewayConfig:
    """加载 `.env` 与 YAML 配置并校验。

    Args:
        config_path: 配置文件路径；为 None 时按 CONFIG_PATH 与默认候选文件查找
        env_file: `.env` 路径，存在时加载

    Returns:
        校验通过的配置对象

    Raises:
        GatewayError: 配置文件缺失、格式非法或字段校验失败
    """
    load_dotenv(env_file, override=False)

    path = resolve_config_path(config_path)
    if path is None:
        return GatewayConfig()
    if not path.exists():
        raise GatewayError(f"配置文件不存在: {path}", code="config_not_found")

    try:
        with open(path, encoding="utf-8") as f:
            raw: Any = yaml.safe_load(f) or {}
    except yaml.YAMLError as exc:
        raise GatewayError(f"配置文件解析失败 {path}: {exc}", code="config_invalid") from exc

    if not isinstance(raw, dict):
        raise GatewayError(
            f"配置文件格式非法 {path}: 顶层必须是映射", code="config_invalid"
        )

    try:
        return GatewayConfig.model_validate(raw)
    except ValidationError as exc:
        details = "; ".join(
            f"{'.'.join(str(p) for p in err['loc'])}: {err['msg']}" for err in exc.errors()
        )
        raise GatewayError(
            f"配置校验失败 {path}: {details}", code="config_invalid"
        ) from exc
