"""消息装配：模板消息在前，调用方 messages 追加在后。"""

from dataclasses import dataclass

from ..errors import InvalidRequest
from ..schemas import LLMRequest, Message, PromptTrace
from .registry import PromptRegistry


@dataclass(slots=True)
class AssembledMessages:
    """装配结果：最终消息列表与实际使用的提示词版本。"""

    messages: list[Message]
    prompt: PromptTrace | None = None


class MessageBuilder:
    """把受控模板与调用方消息装配为最终消息列表。"""

    def __init__(self, registry: PromptRegistry) -> None:
        self._registry = registry

    def build(self, req: LLMRequest) -> AssembledMessages:
        """装配消息；模板消息在前，`req.messages` 追加在后。"""
        template_messages: list[Message] = []
        prompt_trace: PromptTrace | None = None

        if req.prompt is not None:
            rendered, template = self._registry.resolve_and_render(req.prompt)
            template_messages = rendered
            prompt_trace = PromptTrace(
                name=template.name,
                version=template.version,
                content_hash=template.content_hash or "",
            )

        caller_messages = list(req.messages or [])

        if not template_messages and not caller_messages:
            raise InvalidRequest("messages 与 prompt 至少提供其一", code="validation_error")

        return AssembledMessages(
            messages=template_messages + caller_messages, prompt=prompt_trace
        )


def build_message(req: LLMRequest, registry: PromptRegistry) -> list[Message]:
    """函数式入口，返回装配后的消息列表。"""
    return MessageBuilder(registry).build(req).messages
