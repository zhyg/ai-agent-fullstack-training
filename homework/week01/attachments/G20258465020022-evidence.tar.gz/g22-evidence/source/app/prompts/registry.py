"""提示词注册表：YAML 加载、版本解析、变量渲染。"""

import hashlib
import json
import re
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import yaml

from ..errors import InvalidRequest
from ..schemas import (
    Message,
    PromptRef,
    PromptStatus,
    PromptTemplate,
)

VARIABLE_PATTERN = re.compile(r"\{\{([^{}]+)\}\}")


class PromptRegistry:
    """只读提示词注册表，启动时加载，运行期可安全并发访问。"""

    def __init__(self) -> None:
        self._templates: dict[str, dict[str, PromptTemplate]] = {}

    def load_from_directory(self, directory: str | Path) -> int:
        """加载目录下所有 `*.yaml` 提示词文件，返回加载的模板数量。"""
        path = Path(directory)
        if not path.exists():
            return 0

        for yaml_file in sorted(path.glob("*.yaml")):
            self._load_file(yaml_file)
        for yaml_file in sorted(path.glob("*.yml")):
            self._load_file(yaml_file)

        return sum(len(versions) for versions in self._templates.values())

    def load_from_data(self, data: Any, source: str = "<memory>") -> None:
        """从已解析的 YAML 数据加载模板。"""
        items = data if isinstance(data, list) else [data]
        for item in items:
            self._register(item, source)

    def _load_file(self, path: Path) -> None:
        """加载单个 YAML 文件。"""
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or []
        self.load_from_data(data, source=str(path))

    def _register(self, item: Any, source: str) -> None:
        """校验并注册单个模板。"""
        if not isinstance(item, dict):
            raise InvalidRequest(f"提示词文件格式非法: {source}", code="invalid_prompt_file")

        template = PromptTemplate.model_validate(item)
        template.content_hash = compute_content_hash(template)

        versions = self._templates.setdefault(template.name, {})
        if template.version in versions:
            raise InvalidRequest(
                f"重复的提示词版本: {template.name}@{template.version} ({source})",
                code="duplicate_prompt_version",
            )
        versions[template.version] = template

    def resolve(self, ref: PromptRef) -> PromptTemplate:
        """按 name + version 解析模板；version 为空时取最后一个 active 版本。"""
        versions = self._templates.get(ref.name)
        if not versions:
            raise InvalidRequest(f"提示词不存在: {ref.name}", code="prompt_not_found")

        if ref.version is not None:
            template = versions.get(ref.version)
            if template is None:
                raise InvalidRequest(
                    f"提示词版本不存在: {ref.name}@{ref.version}",
                    code="prompt_version_not_found",
                )
            return template

        for template in reversed(list(versions.values())):
            if template.status == PromptStatus.ACTIVE:
                return template

        raise InvalidRequest(
            f"提示词没有 active 版本: {ref.name}", code="prompt_not_found"
        )

    def render(self, template: PromptTemplate, variables: dict[str, Any]) -> list[Message]:
        """替换 `{{ variable }}` 并生成消息列表，仅做字面量替换。"""
        missing = [name for name in template.variables if name not in variables]
        if missing:
            raise InvalidRequest(
                f"缺失提示词变量: {', '.join(missing)}", code="missing_prompt_variable"
            )

        return [
            Message(
                role=item.role,
                content=substitute_variables(item.content, variables),
                name=None,
            )
            for item in template.messages
        ]

    def resolve_and_render(self, ref: PromptRef) -> tuple[list[Message], PromptTemplate]:
        """解析并渲染模板，返回消息列表与实际使用的模板。"""
        template = self.resolve(ref)
        return self.render(template, ref.variables), template

    def names(self) -> list[str]:
        """返回全部提示词名称。"""
        return list(self._templates)

    def versions_of(self, name: str) -> dict[str, PromptTemplate]:
        """返回指定提示词的全部版本（保持声明顺序）。"""
        return dict(self._templates.get(name, {}))

    def iter_templates(self) -> Iterator[PromptTemplate]:
        """遍历全部模板。"""
        for versions in self._templates.values():
            yield from versions.values()


def compute_content_hash(template: PromptTemplate) -> str:
    """计算模板内容的 SHA-256，带 `sha256:` 前缀。"""
    payload = {
        "name": template.name,
        "version": template.version,
        "variables": list(template.variables),
        "messages": [
            {"role": item.role.value, "content": item.content} for item in template.messages
        ],
    }
    encoded = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"


def substitute_variables(content: str, variables: dict[str, Any]) -> str:
    """对 `{{ variable }}` 做字面量替换；未声明的占位符原样保留。"""

    def replacer(match: re.Match[str]) -> str:
        key = match.group(1).strip()
        if key not in variables:
            return match.group(0)
        value = variables[key]
        if isinstance(value, str):
            return value
        return json.dumps(value, ensure_ascii=False)

    return VARIABLE_PATTERN.sub(replacer, content)
