"""POST /v1/chat/completions 与 GET /v1/models 路由。"""

from collections.abc import AsyncIterator

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from ..errors import GatewayError, InvalidRequest
from ..gateway import Gateway
from ..logging import logger
from ..providers.base import BaseProvider
from ..response import (
    SSE_DONE,
    ResponseContext,
    build_delta_event,
    build_done_event,
    build_error_event,
    build_non_stream_response,
    build_start_event,
    process_non_stream_output,
    sse_event,
)
from ..schemas import (
    LLMRequest,
    ModelList,
    ProviderRequest,
    Usage,
)
from ..trace import TraceRecorder, new_request_id

router = APIRouter()


def _get_gateway(request: Request) -> Gateway:
    """从应用状态取回网关注例。"""
    gateway: Gateway = request.app.state.gateway
    return gateway


@router.post("/v1/chat/completions", response_model=None)
async def chat_completions(
    request: Request, body: LLMRequest
) -> JSONResponse | StreamingResponse:
    """统一对话补全入口；stream=true 返回 SSE，否则返回单个 LLMResponse JSON。"""
    request_id = body.request_id or new_request_id()
    request.state.request_id = request_id

    if body.stream:
        return _streaming_response(request, body, request_id)
    return await _non_streaming_response(request, body, request_id)


@router.get("/v1/models")
async def list_models(request: Request) -> JSONResponse:
    """列出所有可调用模型及其 provider 与上游模型名。"""
    gateway = _get_gateway(request)
    models = gateway.router.list_models()
    return JSONResponse(ModelList(data=models).model_dump(mode="json"))


async def _non_streaming_response(
    request: Request, body: LLMRequest, request_id: str
) -> JSONResponse:
    """非流式链路：装配消息 → 路由 → 调用 → JSON 提取与 Schema 校验 → LLMResponse。"""
    gateway = _get_gateway(request)

    scheme = body.response_scheme
    if scheme is None:
        raise InvalidRequest(
            "非流式请求必须提供 response_scheme", code="validation_error"
        )

    assembled = gateway.builder.build(body)
    provider, upstream_model, _route = gateway.router.resolve(body.model)

    recorder = TraceRecorder(
        request_id=request_id,
        model=body.model,
        provider=provider.name,
        upstream_model=upstream_model,
        prompt=assembled.prompt,
        stream=False,
    )
    ctx = ResponseContext(
        request_id=request_id,
        response_id=recorder.response_id,
        created=recorder.created_at,
        model=body.model,
        provider=provider.name,
        prompt=assembled.prompt,
    )

    preq = ProviderRequest(
        request_id=request_id,
        upstream_model=upstream_model,
        messages=assembled.messages,
        temperature=body.temperature,
        max_tokens=body.max_tokens,
        stream=False,
        response_scheme=scheme,
        extra=body.extra,
    )

    usage: Usage | None = None
    try:
        result = await provider.chat(preq)
        recorder.bind_response_id(result.response_id)
        ctx.response_id = recorder.response_id
        usage = result.usage
        parsed = process_non_stream_output(result.message.content, scheme)
    except GatewayError as exc:
        exc.request_id = exc.request_id or request_id
        recorder.failure(exc.error_type, usage=usage)
        raise
    except Exception as exc:
        recorder.failure("internal_error", usage=usage)
        raise GatewayError(
            "内部错误", code="internal_error", request_id=request_id
        ) from exc

    trace = recorder.success(usage)
    response = build_non_stream_response(
        ctx,
        message=result.message,
        parsed=parsed if isinstance(parsed, dict) else None,
        finish_reason=result.finish_reason,
        usage=usage,
        trace=trace if gateway.include_trace_in_response else None,
    )
    return JSONResponse(response.model_dump(mode="json"))


def _streaming_response(
    request: Request, body: LLMRequest, request_id: str
) -> StreamingResponse:
    """流式链路：start → delta* → done/error，最后 data: [DONE]。"""
    gateway = _get_gateway(request)

    assembled = gateway.builder.build(body)
    provider, upstream_model, _route = gateway.router.resolve(body.model)

    recorder = TraceRecorder(
        request_id=request_id,
        model=body.model,
        provider=provider.name,
        upstream_model=upstream_model,
        prompt=assembled.prompt,
        stream=True,
    )

    preq = ProviderRequest(
        request_id=request_id,
        upstream_model=upstream_model,
        messages=assembled.messages,
        temperature=body.temperature,
        max_tokens=body.max_tokens,
        stream=True,
        response_scheme=None,
        extra=body.extra,
    )

    return StreamingResponse(
        _sse_publisher(gateway, provider, recorder, preq),
        media_type="text/event-stream",
    )


async def _sse_publisher(
    gateway: Gateway,
    provider: BaseProvider,
    recorder: TraceRecorder,
    preq: ProviderRequest,
) -> AsyncIterator[str]:
    """把流式链路封装为 SSE 事件序列，异常时发送 error 事件后结束。"""
    ctx = ResponseContext(
        request_id=recorder.request_id,
        response_id=recorder.response_id,
        created=recorder.created_at,
        model=recorder.model,
        provider=provider.name,
        prompt=recorder.prompt,
    )

    finish_reason: str | None = None
    usage: Usage | None = None

    try:
        yield sse_event(build_start_event(ctx))

        async for chunk in provider.chat_stream(preq):
            recorder.mark_first_token()
            recorder.bind_response_id(chunk.response_id)
            ctx.response_id = recorder.response_id
            if chunk.finish_reason:
                finish_reason = chunk.finish_reason
            if chunk.usage:
                usage = chunk.usage
            if chunk.delta.content is not None:
                yield sse_event(build_delta_event(ctx, chunk.delta.content))

        trace = recorder.success(usage)
        yield sse_event(
            build_done_event(
                ctx,
                finish_reason=finish_reason,
                usage=usage,
                trace=trace if gateway.include_trace_in_response else None,
            )
        )
    except GatewayError as exc:
        exc.request_id = exc.request_id or recorder.request_id
        trace = recorder.failure(exc.error_type, usage=usage)
        logger.warning(
            "stream_failed",
            extra={
                "request_id": recorder.request_id,
                "provider": provider.name,
                "error_type": exc.error_type,
            },
        )
        yield sse_event(
            build_error_event(
                ctx,
                error=exc.to_error_detail(),
                trace=trace if gateway.include_trace_in_response else None,
            )
        )
    except Exception:
        trace = recorder.failure("internal_error", usage=usage)
        error = GatewayError("内部错误", code="internal_error")
        logger.error(
            "stream_internal_error",
            extra={"request_id": recorder.request_id, "error_type": "internal_error"},
        )
        yield sse_event(
            build_error_event(
                ctx,
                error=error.to_error_detail(),
                trace=trace if gateway.include_trace_in_response else None,
            )
        )
    finally:
        yield SSE_DONE


__all__ = ["router"]
