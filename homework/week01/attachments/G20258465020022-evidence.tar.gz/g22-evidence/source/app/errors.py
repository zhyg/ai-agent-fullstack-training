"""统一异常层级与错误映射。"""

from typing import Any

from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from .schemas import ErrorDetail, ErrorResponse


class GatewayError(Exception):
    """网关基础异常，所有可预期错误的父类。"""

    error_type: str = "internal_error"
    http_status: int = 500
    default_message: str = "内部错误"

    def __init__(
        self,
        message: str | None = None,
        code: str | None = None,
        status_code: int | None = None,
        request_id: str | None = None,
    ) -> None:
        self.message = message or self.default_message
        self.code = code or self.error_type
        self.status_code = status_code or self.http_status
        self.request_id = request_id
        super().__init__(self.message)

    def to_error_detail(self) -> ErrorDetail:
        """转换为统一错误详情。"""
        return ErrorDetail(type=self.error_type, message=self.message, code=self.code)

    def to_error_response(self, request_id: str | None = None) -> ErrorResponse:
        """转换为统一错误响应体。"""
        return ErrorResponse(
            request_id=request_id or self.request_id, error=self.to_error_detail()
        )


class InvalidRequest(GatewayError):
    """请求参数非法、模型或提示词不存在等。"""

    error_type = "invalid_request"
    http_status = 400
    default_message = "请求参数无效"


class AuthenticationError(GatewayError):
    """provider 缺少或无效 API Key。"""

    error_type = "authentication_error"
    http_status = 401
    default_message = "API Key 缺失或无效"


class PermissionDenied(GatewayError):
    """上游拒绝访问。"""

    error_type = "permission_denied"
    http_status = 403
    default_message = "上游拒绝访问"


class NotFound(GatewayError):
    """上游模型或资源不存在。"""

    error_type = "not_found"
    http_status = 404
    default_message = "资源不存在"


class SchemaValidationError(GatewayError):
    """非流式输出不是合法 JSON 或不符合 response_scheme。"""

    error_type = "schema_validation_error"
    http_status = 422
    default_message = "模型输出不符合 response_scheme"


class RateLimited(GatewayError):
    """上游限流（重试耗尽后）。"""

    error_type = "rate_limited"
    http_status = 429
    default_message = "上游限流"


class ProviderError(GatewayError):
    """上游返回 5xx 或无法解析。"""

    error_type = "provider_error"
    http_status = 502
    default_message = "上游返回错误"


class UpstreamTimeout(GatewayError):
    """上游连接或读取超时。"""

    error_type = "upstream_timeout"
    http_status = 504
    default_message = "上游超时"


def error_json(exc: GatewayError, request_id: str | None = None) -> dict[str, Any]:
    """把异常序列化为错误响应字典。"""
    return exc.to_error_response(request_id).model_dump(mode="json")


def _resolve_request_id(request: Request, exc: Any) -> str | None:
    """尽力从请求状态或校验错误体中还原 request_id。"""
    state_value = getattr(request.state, "request_id", None)
    if isinstance(state_value, str):
        return state_value

    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        value = body.get("request_id")
        if isinstance(value, str):
            return value

    exc_request_id = getattr(exc, "request_id", None)
    return exc_request_id if isinstance(exc_request_id, str) else None


async def gateway_error_handler(request: Request, exc: GatewayError) -> JSONResponse:
    """处理网关内部异常，输出统一 ErrorResponse。"""
    return JSONResponse(
        status_code=exc.status_code,
        content=error_json(exc, _resolve_request_id(request, exc)),
    )


async def validation_error_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """把 Pydantic 校验错误映射为 400 invalid_request。"""
    request_id = _resolve_request_id(request, exc)
    unexpected = [e for e in exc.errors() if e.get("type") == "extra_forbidden"]

    if unexpected:
        fields = ", ".join(str(e.get("loc", ("",))[-1]) for e in unexpected)
        error = InvalidRequest(f"请求包含未定义字段：{fields}", code="unexpected_field")
    else:
        details = "; ".join(_format_validation_error(e) for e in exc.errors())
        error = InvalidRequest(f"请求校验失败：{details}", code="validation_error")

    return JSONResponse(status_code=400, content=error_json(error, request_id))


def _format_validation_error(err: dict[str, Any]) -> str:
    """格式化单条校验错误，只含字段路径与原因，不回显取值。"""
    loc = tuple(str(part) for part in err.get("loc", ()) if part not in ("body",))
    path = ".".join(loc) or "<root>"
    return f"{path}: {err.get('msg', 'invalid')}"


async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
    """兜底处理未预期异常，避免泄露内部细节。"""
    error = GatewayError("内部错误", code="internal_error")
    return JSONResponse(
        status_code=500, content=error_json(error, _resolve_request_id(request, exc))
    )
