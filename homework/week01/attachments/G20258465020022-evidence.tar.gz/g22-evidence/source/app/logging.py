"""结构化日志配置与敏感信息脱敏。"""

import json
import logging
import sys
from typing import Any


class JSONFormatter(logging.Formatter):
    """JSON 格式日志输出器。"""

    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
        }

        if hasattr(record, "request_id"):
            log_data["request_id"] = record.request_id
        if hasattr(record, "response_id"):
            log_data["response_id"] = record.response_id
        if hasattr(record, "model"):
            log_data["model"] = record.model
        if hasattr(record, "provider"):
            log_data["provider"] = record.provider
        if hasattr(record, "upstream_model"):
            log_data["upstream_model"] = record.upstream_model
        if hasattr(record, "prompt_name"):
            log_data["prompt_name"] = record.prompt_name
        if hasattr(record, "prompt_version"):
            log_data["prompt_version"] = record.prompt_version
        if hasattr(record, "latency_ms"):
            log_data["latency_ms"] = record.latency_ms
        if hasattr(record, "ttft_ms"):
            log_data["ttft_ms"] = record.ttft_ms
        if hasattr(record, "usage"):
            log_data["usage"] = record.usage
        if hasattr(record, "status"):
            log_data["status"] = record.status
        if hasattr(record, "error_type"):
            log_data["error_type"] = record.error_type

        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_data, ensure_ascii=False)


def setup_logging(level: int = logging.INFO) -> logging.Logger:
    """配置日志系统。"""
    logger = logging.getLogger("llm_gateway")
    logger.setLevel(level)
    logger.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    logger.addHandler(handler)

    return logger


def mask_sensitive(value: str | None, visible_chars: int = 4) -> str:
    """脱敏敏感字符串。"""
    if not value:
        return "***"
    if len(value) <= visible_chars:
        return "***"
    return value[:visible_chars] + "***"


def sanitize_for_log(data: dict[str, Any]) -> dict[str, Any]:
    """清理日志数据，移除或脱敏敏感信息。"""
    sensitive_keys = {"api_key", "authorization", "x-api-key"}
    result = {}
    for key, value in data.items():
        if key.lower() in sensitive_keys:
            result[key] = "***"
        elif isinstance(value, str) and len(value) > 200:
            result[key] = value[:100] + "...(truncated)"
        else:
            result[key] = value
    return result


logger = setup_logging()
