"""FastAPI 应用入口：lifespan、路由注册与异常处理器装配。"""

from collections.abc import AsyncIterator, Callable
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from typing import Any

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from . import __version__
from .api import chat_router
from .errors import (
    GatewayError,
    gateway_error_handler,
    unhandled_error_handler,
    validation_error_handler,
)
from .gateway import Gateway
from .logging import logger, setup_logging
from .schemas import HealthResponse

APP_TITLE = "LLM Gateway"


def build_lifespan(
    config_path: str | None = None, gateway: Gateway | None = None
) -> Callable[[FastAPI], AbstractAsyncContextManager[None, Any]]:
    """生成绑定配置与可选 gateway 注入的 lifespan 上下文管理器工厂。"""

    @asynccontextmanager
    async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
        setup_logging()
        active = gateway or Gateway.create(config_path)
        await active.start()
        app.state.gateway = active
        logger.info(
            "gateway_started",
            extra={
                "provider": ",".join(active.provider_names()),
                "status": "started",
            },
        )
        try:
            yield
        finally:
            await active.stop()
            logger.info("gateway_stopped", extra={"status": "stopped"})

    return _lifespan


def create_app(
    config_path: str | None = None, gateway: Gateway | None = None
) -> FastAPI:
    """构造 FastAPI 应用；gateway 可注入用于测试，否则按配置在启动时装配。"""
    app = FastAPI(
        title=APP_TITLE,
        version=__version__,
        lifespan=build_lifespan(config_path, gateway),
    )

    app.include_router(chat_router)

    app.add_exception_handler(
        GatewayError, gateway_error_handler  # type: ignore[arg-type]
    )
    app.add_exception_handler(
        RequestValidationError, validation_error_handler  # type: ignore[arg-type]
    )
    app.add_exception_handler(Exception, unhandled_error_handler)

    @app.get("/healthz")
    async def healthz() -> JSONResponse:
        """健康检查：返回状态、版本与已加载 providers，不探测上游。"""
        active: Gateway = app.state.gateway
        payload = HealthResponse(
            status="ok",
            version=__version__,
            providers=active.provider_names(),
        )
        return JSONResponse(payload.model_dump(mode="json"))

    return app


app = create_app()
