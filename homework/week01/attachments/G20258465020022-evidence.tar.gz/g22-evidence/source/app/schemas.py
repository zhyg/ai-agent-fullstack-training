"""LLM Gateway 数据模型定义。"""

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    """接口数据模型基类：禁止未定义字段。"""

    model_config = ConfigDict(extra="forbid")


class MessageRole(str, Enum):
    """对话消息角色。"""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class Message(StrictModel):
    """对话中的单条消息。"""

    role: MessageRole = Field(..., description="消息角色")
    content: str = Field(..., description="消息文本内容")
    name: str | None = Field(default=None, description="可选名称")


class Usage(StrictModel):
    """单次调用的 token 用量。"""

    prompt_tokens: int = Field(..., ge=0, description="输入 token 数")
    completion_tokens: int = Field(..., ge=0, description="输出 token 数")
    total_tokens: int = Field(..., ge=0, description="总 token 数")


class PromptStatus(str, Enum):
    """提示词版本状态。"""

    ACTIVE = "active"
    DRAFT = "draft"
    DEPRECATED = "deprecated"


class PromptMessageTemplate(StrictModel):
    """模板中的一条消息，content 支持 {{ variable }} 占位符。"""

    role: MessageRole = Field(..., description="消息角色")
    content: str = Field(..., description="消息模板内容")


class PromptTemplate(StrictModel):
    """一个受控提示词模板版本。"""

    name: str = Field(..., description="模板名称")
    version: str = Field(..., description="版本号")
    status: PromptStatus = Field(default=PromptStatus.ACTIVE, description="版本状态")
    description: str | None = Field(default=None, description="描述")
    variables: list[str] = Field(default_factory=list, description="声明变量列表")
    messages: list[PromptMessageTemplate] = Field(..., min_length=1, description="模板消息")
    created_at: int | None = Field(default=None, description="创建时间，Unix 秒")
    content_hash: str | None = Field(default=None, description="模板内容 SHA-256")


class PromptRef(StrictModel):
    """请求中的提示词模板引用。"""

    name: str = Field(..., description="模板名称")
    version: str | None = Field(default=None, description="版本；None 表示最新 active 版本")
    variables: dict[str, Any] = Field(default_factory=dict, description="变量值")


class PromptTrace(StrictModel):
    """追踪中记录的实际提示词版本。"""

    name: str = Field(..., description="模板名称")
    version: str = Field(..., description="实际版本")
    content_hash: str = Field(..., description="实际渲染模板的内容 hash")


class ResponseScheme(StrictModel):
    """非流式结构化输出约束。"""

    name: str = Field(default="response", description="Schema 名称")
    json_schema: dict[str, Any] = Field(..., description="JSON Schema 定义")
    strict: bool = Field(default=True, description="是否严格校验")
    description: str | None = Field(default=None, description="输出格式说明")


class ErrorDetail(StrictModel):
    """统一错误详情。"""

    type: str = Field(..., description="错误类型")
    message: str = Field(..., description="可读错误信息")
    code: str | None = Field(default=None, description="上游/内部错误码")


class TraceStatus(str, Enum):
    """调用追踪状态。"""

    SUCCESS = "success"
    FAILED = "failed"


class CallTrace(StrictModel):
    """一次模型调用的完整追踪记录。"""

    trace_id: str = Field(..., description="追踪唯一标识")
    request_id: str = Field(..., description="所属请求 id")
    response_id: str = Field(..., description="所属响应 id")
    model: str = Field(..., description="逻辑模型名")
    provider: str = Field(..., description="实际 provider 名称")
    upstream_model: str = Field(..., description="上游真实模型名")
    prompt: PromptTrace | None = Field(default=None, description="实际使用的提示词版本")
    usage: Usage | None = Field(default=None, description="token 用量")
    latency_ms: int = Field(..., ge=0, description="总耗时（毫秒）")
    ttft_ms: int | None = Field(
        default=None, ge=0, description="首包延迟（毫秒）；仅流式请求采集"
    )
    status: TraceStatus = Field(..., description="调用状态")
    stream: bool = Field(..., description="是否流式")
    error_type: str | None = Field(default=None, description="失败时的错误类型")
    created_at: int = Field(..., description="开始时间，Unix 秒")
    finished_at: int | None = Field(default=None, description="结束时间，Unix 秒")


class ResponseStatus(str, Enum):
    """统一响应状态。"""

    IN_PROGRESS = "in_progress"
    SUCCESS = "success"
    FAILED = "failed"


class ResponseEvent(str, Enum):
    """统一响应事件；非流式固定为 done。"""

    START = "start"
    DELTA = "delta"
    DONE = "done"
    ERROR = "error"


class Delta(StrictModel):
    """流式响应中的增量内容。"""

    role: MessageRole | None = Field(default=None, description="角色，首个块可能携带")
    content: str | None = Field(default=None, description="本块新增文本")


class Choice(StrictModel):
    """统一的候选结果，非流式与流式共用。"""

    index: int = Field(..., ge=0, description="候选序号")
    message: Message | None = Field(default=None, description="非流式完整消息")
    delta: Delta | None = Field(default=None, description="流式增量")
    parsed: dict[str, Any] | None = Field(default=None, description="Schema 校验后的结构化结果")
    finish_reason: str | None = Field(default=None, description="结束原因")


class LLMResponse(StrictModel):
    """统一的对话补全响应，流式与非流式共用。"""

    response_id: str = Field(..., description="响应唯一标识")
    request_id: str = Field(..., description="来源请求 id")
    object: str = Field(default="llm.response", description="对象类型，固定 llm.response")
    created: int = Field(..., description="创建时间，Unix 秒")
    model: str = Field(..., description="逻辑模型名")
    provider: str = Field(..., description="实际处理的 provider 名称")
    prompt: PromptTrace | None = Field(default=None, description="实际使用的提示词版本")
    status: ResponseStatus = Field(..., description="响应状态")
    event: ResponseEvent = Field(..., description="响应事件")
    choices: list[Choice] = Field(default_factory=list, description="候选结果")
    usage: Usage | None = Field(default=None, description="token 用量")
    trace: CallTrace | None = Field(default=None, description="调用追踪")
    error: ErrorDetail | None = Field(default=None, description="错误详情")


class LLMRequest(StrictModel):
    """统一的对话补全请求。"""

    request_id: str | None = Field(default=None, description="请求标识；未传时由网关生成")
    model: str = Field(..., description="逻辑模型名")
    messages: list[Message] | None = Field(default=None, description="调用方消息")
    prompt: PromptRef | None = Field(default=None, description="受控提示词模板引用")
    temperature: float | None = Field(default=None, ge=0.0, le=2.0, description="采样温度")
    max_tokens: int | None = Field(default=None, gt=0, description="最大生成 token 数")
    stream: bool = Field(default=False, description="是否流式返回")
    response_scheme: ResponseScheme | None = Field(
        default=None, description="非流式结构化输出约束"
    )
    extra: dict[str, Any] = Field(default_factory=dict, description="厂商私有参数透传")

    @model_validator(mode="after")
    def _validate_required_combinations(self) -> "LLMRequest":
        """校验消息来源与非流式 response_scheme 约束。"""
        if not self.messages and self.prompt is None:
            raise ValueError("messages 与 prompt 至少提供其一")
        if not self.stream and self.response_scheme is None:
            raise ValueError("非流式请求必须提供 response_scheme")
        return self


class ErrorResponse(StrictModel):
    """统一错误响应体。"""

    request_id: str | None = Field(default=None, description="来源请求 id")
    error: ErrorDetail = Field(..., description="错误详情")


class ModelInfo(StrictModel):
    """可调用模型的信息。"""

    id: str = Field(..., description="逻辑模型名")
    object: str = Field(default="model", description="对象类型，固定 model")
    provider: str = Field(..., description="所属 provider 名称")
    upstream_model: str = Field(..., description="上游真实模型名")


class ModelList(StrictModel):
    """模型列表响应。"""

    object: str = Field(default="list", description="对象类型，固定 list")
    data: list[ModelInfo] = Field(..., description="模型列表")


class HealthResponse(StrictModel):
    """健康检查响应。"""

    status: str = Field(default="ok", description="健康状态，固定 ok")
    version: str = Field(..., description="服务版本号")
    providers: list[str] = Field(..., description="已加载的 provider 名称列表")


class ProviderRequest(StrictModel):
    """已装配、已路由的内部请求。"""

    request_id: str = Field(..., description="请求 id，用于日志与追踪")
    upstream_model: str = Field(..., description="上游真实模型名")
    messages: list[Message] = Field(..., min_length=1, description="装配后的消息")
    temperature: float | None = Field(default=None, description="采样温度")
    max_tokens: int | None = Field(default=None, description="最大生成 token 数")
    stream: bool = Field(default=False, description="是否流式")
    response_scheme: ResponseScheme | None = Field(default=None, description="结构化输出约束")
    extra: dict[str, Any] = Field(default_factory=dict, description="厂商私有参数")


class ProviderResult(StrictModel):
    """非流式上游结果的归一化形态。"""

    response_id: str = Field(..., description="响应 id")
    message: Message = Field(..., description="完整消息")
    finish_reason: str | None = Field(default=None, description="结束原因")
    usage: Usage = Field(..., description="token 用量")
    raw: dict[str, Any] | None = Field(default=None, description="上游原始响应（调试用）")


class ProviderChunk(StrictModel):
    """流式上游增量块的归一化形态。"""

    response_id: str = Field(..., description="响应 id")
    delta: Delta = Field(..., description="增量内容")
    finish_reason: str | None = Field(default=None, description="结束原因")
    usage: Usage | None = Field(default=None, description="末块 token 用量")
    raw: dict[str, Any] | None = Field(default=None, description="上游原始块（调试用）")


class ModelRoute(StrictModel):
    """一条模型路由配置。"""

    provider: str = Field(..., description="provider 名称")
    upstream_model: str = Field(..., description="上游真实模型名")
