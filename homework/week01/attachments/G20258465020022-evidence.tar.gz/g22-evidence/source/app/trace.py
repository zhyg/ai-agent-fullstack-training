"""CallTrace 采集与输出。"""

import time
import uuid
from typing import Any

from .logging import logger
from .schemas import CallTrace, PromptTrace, TraceStatus, Usage


def new_request_id() -> str:
    """生成请求标识。"""
    return f"req-{uuid.uuid4().hex[:16]}"


def new_response_id() -> str:
    """生成响应标识。"""
    return f"resp-{uuid.uuid4().hex[:16]}"


def new_trace_id() -> str:
    """生成追踪标识。"""
    return f"trace-{uuid.uuid4().hex[:16]}"


class TraceRecorder:
    """一次调用的追踪采集器，负责计时、生成 CallTrace 并写入日志。"""

    def __init__(
        self,
        *,
        request_id: str,
        model: str,
        provider: str = "",
        upstream_model: str = "",
        prompt: PromptTrace | None = None,
        stream: bool = False,
        response_id: str | None = None,
    ) -> None:
        self.request_id = request_id
        self.response_id = response_id or new_response_id()
        self.trace_id = new_trace_id()
        self.model = model
        self.provider = provider
        self.upstream_model = upstream_model
        self.prompt = prompt
        self.stream = stream
        self.created_at = int(time.time())
        self._started = time.perf_counter()
        self._first_token_at: float | None = None

    def bind_route(self, provider: str, upstream_model: str) -> None:
        """路由解析完成后回填 provider 与上游模型名。"""
        self.provider = provider
        self.upstream_model = upstream_model

    def bind_response_id(self, response_id: str | None) -> None:
        """沿用上游 response_id；为空时保留本地生成值。"""
        if response_id:
            self.response_id = response_id

    def mark_first_token(self) -> None:
        """记录首个上游数据块到达时刻，仅首次调用生效。"""
        if self._first_token_at is None:
            self._first_token_at = time.perf_counter()

    def elapsed_ms(self) -> int:
        """返回从创建到当前的耗时（毫秒）。"""
        return max(0, int((time.perf_counter() - self._started) * 1000))

    def ttft_ms(self) -> int | None:
        """返回首包延迟（毫秒）；尚未收到数据块时为 None。"""
        if self._first_token_at is None:
            return None
        return max(0, int((self._first_token_at - self._started) * 1000))

    def success(self, usage: Usage | None = None) -> CallTrace:
        """生成成功追踪记录并写入日志。"""
        trace = self._build(TraceStatus.SUCCESS, usage=usage, error_type=None)
        self._log(trace)
        return trace

    def failure(
        self, error_type: str, usage: Usage | None = None
    ) -> CallTrace:
        """生成失败追踪记录并写入日志。"""
        trace = self._build(TraceStatus.FAILED, usage=usage, error_type=error_type)
        self._log(trace)
        return trace

    def _build(
        self, status: TraceStatus, usage: Usage | None, error_type: str | None
    ) -> CallTrace:
        """组装 CallTrace。"""
        finished_at = int(time.time())
        return CallTrace(
            trace_id=self.trace_id,
            request_id=self.request_id,
            response_id=self.response_id,
            model=self.model,
            provider=self.provider,
            upstream_model=self.upstream_model,
            prompt=self.prompt,
            usage=usage,
            latency_ms=self.elapsed_ms(),
            ttft_ms=self.ttft_ms(),
            status=status,
            stream=self.stream,
            error_type=error_type,
            created_at=self.created_at,
            finished_at=finished_at,
        )

    @staticmethod
    def _log(trace: CallTrace) -> None:
        """把追踪记录写入结构化日志（不含敏感内容）。"""
        fields: dict[str, Any] = {
            "request_id": trace.request_id,
            "response_id": trace.response_id,
            "model": trace.model,
            "provider": trace.provider,
            "upstream_model": trace.upstream_model,
            "latency_ms": trace.latency_ms,
            "status": trace.status.value,
            "error_type": trace.error_type,
        }
        if trace.ttft_ms is not None:
            fields["ttft_ms"] = trace.ttft_ms
        if trace.prompt:
            fields["prompt_name"] = trace.prompt.name
            fields["prompt_version"] = trace.prompt.version
        if trace.usage:
            fields["usage"] = trace.usage.model_dump()

        if trace.status == TraceStatus.SUCCESS:
            logger.info("llm_call_finished", extra=fields)
        else:
            logger.warning("llm_call_failed", extra=fields)
