"""响应处理：JSON 提取、Schema 校验、统一事件封装。"""

import json
import re
from dataclasses import dataclass
from typing import Any

import jsonschema

from .errors import SchemaValidationError
from .schemas import (
    CallTrace,
    Choice,
    Delta,
    ErrorDetail,
    LLMResponse,
    Message,
    MessageRole,
    PromptTrace,
    ResponseEvent,
    ResponseScheme,
    ResponseStatus,
    Usage,
)

FENCE_BLOCK_RE = re.compile(r"```[^\n`]*\n?(.*?)```", re.DOTALL)
SSE_DONE = "data: [DONE]\n\n"


@dataclass(slots=True)
class ResponseContext:
    """构建 LLMResponse 所需的公共上下文。"""

    request_id: str
    response_id: str
    created: int
    model: str
    provider: str
    prompt: PromptTrace | None = None


def strip_code_fences(text: str) -> str:
    """去除 Markdown 代码围栏，返回内部内容。"""
    stripped = text.strip()
    match = FENCE_BLOCK_RE.search(stripped)
    if match and stripped.startswith("```"):
        return match.group(1).strip()
    if stripped.startswith("```") and stripped.endswith("```"):
        return stripped[3:-3].strip()
    return stripped


def extract_json(text: str) -> Any:
    """从模型输出中提取 JSON，失败映射 invalid_json。"""
    candidate = strip_code_fences(text)

    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass

    for opener, closer in (("{", "}"), ("[", "]")):
        start = candidate.find(opener)
        end = candidate.rfind(closer)
        if start != -1 and end > start:
            try:
                return json.loads(candidate[start : end + 1])
            except json.JSONDecodeError:
                continue

    raise SchemaValidationError(
        "模型输出不是合法 JSON", code="invalid_json"
    )


def validate_with_schema(data: Any, scheme: ResponseScheme) -> Any:
    """用 response_scheme.json_schema 校验数据，失败映射 schema_mismatch。"""
    try:
        jsonschema.validate(instance=data, schema=scheme.json_schema)
    except jsonschema.SchemaError as exc:
        raise SchemaValidationError(
            f"response_scheme '{scheme.name}' 不是合法 JSON Schema: {exc.message}",
            code="schema_mismatch",
        ) from exc
    except jsonschema.ValidationError as exc:
        path = ".".join(str(part) for part in exc.absolute_path) or "<root>"
        raise SchemaValidationError(
            f"模型输出不符合 response_scheme '{scheme.name}': {path} {exc.message}",
            code="schema_mismatch",
        ) from exc
    return data


def process_non_stream_output(text: str, scheme: ResponseScheme) -> Any:
    """提取并校验非流式输出，返回结构化结果。"""
    return validate_with_schema(extract_json(text), scheme)


def build_response(
    ctx: ResponseContext,
    *,
    event: ResponseEvent,
    status: ResponseStatus,
    choices: list[Choice],
    usage: Usage | None = None,
    trace: CallTrace | None = None,
    error: ErrorDetail | None = None,
) -> LLMResponse:
    """按统一响应模型组装 LLMResponse。"""
    return LLMResponse(
        response_id=ctx.response_id,
        request_id=ctx.request_id,
        created=ctx.created,
        model=ctx.model,
        provider=ctx.provider,
        prompt=ctx.prompt,
        status=status,
        event=event,
        choices=choices,
        usage=usage,
        trace=trace,
        error=error,
    )


def build_start_event(ctx: ResponseContext) -> LLMResponse:
    """流式首事件：event=start，携带 delta.role。"""
    return build_response(
        ctx,
        event=ResponseEvent.START,
        status=ResponseStatus.IN_PROGRESS,
        choices=[
            Choice(index=0, delta=Delta(role=MessageRole.ASSISTANT, content=None))
        ],
    )


def build_delta_event(ctx: ResponseContext, content: str | None) -> LLMResponse:
    """流式增量事件：event=delta。"""
    return build_response(
        ctx,
        event=ResponseEvent.DELTA,
        status=ResponseStatus.IN_PROGRESS,
        choices=[Choice(index=0, delta=Delta(role=None, content=content))],
    )


def build_done_event(
    ctx: ResponseContext,
    *,
    finish_reason: str | None,
    usage: Usage | None,
    trace: CallTrace | None,
) -> LLMResponse:
    """流式结束事件：event=done，携带 finish_reason、usage、trace。"""
    return build_response(
        ctx,
        event=ResponseEvent.DONE,
        status=ResponseStatus.SUCCESS,
        choices=[
            Choice(index=0, delta=Delta(role=None, content=None), finish_reason=finish_reason)
        ],
        usage=usage,
        trace=trace,
    )


def build_error_event(
    ctx: ResponseContext, *, error: ErrorDetail, trace: CallTrace | None
) -> LLMResponse:
    """流式失败事件：event=error，携带错误详情与失败 trace。"""
    return build_response(
        ctx,
        event=ResponseEvent.ERROR,
        status=ResponseStatus.FAILED,
        choices=[],
        trace=trace,
        error=error,
    )


def build_non_stream_response(
    ctx: ResponseContext,
    *,
    message: Message,
    parsed: dict[str, Any] | None,
    finish_reason: str | None,
    usage: Usage | None,
    trace: CallTrace | None,
) -> LLMResponse:
    """非流式响应：单个 event=done、status=success 的 LLMResponse。"""
    return build_response(
        ctx,
        event=ResponseEvent.DONE,
        status=ResponseStatus.SUCCESS,
        choices=[
            Choice(
                index=0,
                message=message,
                delta=None,
                parsed=parsed,
                finish_reason=finish_reason,
            )
        ],
        usage=usage,
        trace=trace,
    )


def sse_event(response: LLMResponse) -> str:
    """把 LLMResponse 序列化为一条 SSE 数据行。"""
    return f"data: {response.model_dump_json()}\n\n"
