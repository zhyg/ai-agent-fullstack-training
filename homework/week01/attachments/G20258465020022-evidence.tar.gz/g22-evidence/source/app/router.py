"""模型路由：逻辑模型名 → provider 实例 + 上游模型名。"""

from __future__ import annotations

from fnmatch import fnmatchcase
from typing import TYPE_CHECKING

from .errors import InvalidRequest
from .schemas import ModelInfo, ModelRoute

if TYPE_CHECKING:
    from .config import GatewayConfig
    from .providers.base import BaseProvider

MODEL_PLACEHOLDER = "{model}"


class ModelRouter:
    """将逻辑模型名解析为 provider 与上游模型名。

    支持两种规则：

    - 显式映射：`gpt-4o-mini -> openai/gpt-4o-mini`
    - 前缀/通配规则：`gpt-* -> openai/{model}`，`upstream_model` 中的
      `{model}` 会被替换为调用方传入的逻辑模型名
    """

    def __init__(self, config: GatewayConfig, providers: dict[str, BaseProvider]) -> None:
        self._providers = providers
        self._explicit: dict[str, ModelRoute] = {}
        self._patterns: list[tuple[str, ModelRoute]] = []

        for name, model_config in config.models.items():
            route = ModelRoute(
                provider=model_config.provider, upstream_model=model_config.upstream_model
            )
            if any(char in name for char in "*?["):
                self._patterns.append((name, route))
            else:
                self._explicit[name] = route

    def resolve_route(self, model: str) -> ModelRoute:
        """解析逻辑模型名对应的路由配置。"""
        route = self._explicit.get(model)
        if route is None:
            route = self._match_pattern(model)
        if route is None:
            raise InvalidRequest(f"模型未注册: {model}", code="model_not_found")
        return route

    def _match_pattern(self, model: str) -> ModelRoute | None:
        """按声明顺序匹配通配规则。"""
        for pattern, route in self._patterns:
            if fnmatchcase(model, pattern):
                return ModelRoute(
                    provider=route.provider,
                    upstream_model=route.upstream_model.replace(MODEL_PLACEHOLDER, model),
                )
        return None

    def resolve(self, model: str) -> tuple[BaseProvider, str, ModelRoute]:
        """解析模型名，返回 (provider 实例, 上游模型名, 路由)。"""
        route = self.resolve_route(model)
        provider = self._providers.get(route.provider)
        if provider is None:
            raise InvalidRequest(
                f"模型 '{model}' 指向未装配的 provider: {route.provider}",
                code="provider_not_configured",
            )
        return provider, route.upstream_model, route

    def list_models(self) -> list[ModelInfo]:
        """列出所有显式注册的可调用模型。"""
        return [
            ModelInfo(id=name, provider=route.provider, upstream_model=route.upstream_model)
            for name, route in self._explicit.items()
        ]

    def provider_names(self) -> list[str]:
        """返回已装配的 provider 名称列表。"""
        return list(self._providers)
