"""Provider 适配层与注册工厂。"""

import httpx

from ..config import GatewayConfig, ProviderConfig, RequestConfig
from ..errors import GatewayError
from .anthropic import AnthropicProvider
from .base import BaseHTTPProvider, BaseProvider
from .openai import OpenAIProvider

PROVIDER_TYPES: dict[str, type[BaseHTTPProvider]] = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
}

__all__ = [
    "PROVIDER_TYPES",
    "AnthropicProvider",
    "BaseHTTPProvider",
    "BaseProvider",
    "OpenAIProvider",
    "build_providers",
    "create_provider",
]


def create_provider(
    name: str,
    config: ProviderConfig,
    request_config: RequestConfig,
    client: httpx.AsyncClient | None = None,
) -> BaseProvider:
    """按配置类型构造 provider 实例。"""
    provider_cls = PROVIDER_TYPES.get(config.type)
    if provider_cls is None:
        raise GatewayError(
            f"未知的 provider 类型: {config.type}（provider '{name}'），"
            f"可选值: {', '.join(sorted(PROVIDER_TYPES))}",
            code="unknown_provider_type",
        )
    return provider_cls(name=name, config=config, request_config=request_config, client=client)


def build_providers(
    config: GatewayConfig, client: httpx.AsyncClient | None = None
) -> dict[str, BaseProvider]:
    """根据配置装配全部 provider 实例。"""
    return {
        name: create_provider(name, provider_config, config.request, client)
        for name, provider_config in config.providers.items()
    }


async def close_providers(providers: dict[str, BaseProvider]) -> None:
    """释放全部 provider 资源。"""
    for provider in providers.values():
        await provider.aclose()
