"""Provider 抽象基类与共享 HTTP 实现。"""

import asyncio
import json
import os
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

import httpx

from ..config import ProviderConfig, RequestConfig
from ..errors import (
    AuthenticationError,
    GatewayError,
    NotFound,
    PermissionDenied,
    ProviderError,
    RateLimited,
    UpstreamTimeout,
)
from ..schemas import ProviderChunk, ProviderRequest, ProviderResult

RETRYABLE_STATUS = frozenset({408, 425, 429, 500, 502, 503, 504})


class BaseProvider(ABC):
    """厂商适配器抽象基类。"""

    name: str = "base"

    @abstractmethod
    async def chat(self, req: ProviderRequest) -> ProviderResult:
        """执行非流式对话补全。"""

    @abstractmethod
    def chat_stream(self, req: ProviderRequest) -> AsyncIterator[ProviderChunk]:
        """执行流式对话补全，逐块产出归一化增量。"""

    async def aclose(self) -> None:
        """释放 provider 持有的资源。"""


class BaseHTTPProvider(BaseProvider):
    """基于 httpx 的 provider 公共实现：客户端生命周期、超时、重试、错误归一化。

    子类只需实现请求体构建与响应解析，无需关心传输细节。
    """

    def __init__(
        self,
        name: str,
        config: ProviderConfig,
        request_config: RequestConfig,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.name = name
        self._config = config
        self._request_config = request_config
        self._client = client
        self._owns_client = client is None
        self._api_key: str | None = None

    @property
    def base_url(self) -> str:
        """上游 API 基础地址。"""
        return self._config.base_url.rstrip("/")

    def build_timeout(self) -> httpx.Timeout:
        """按配置构造 httpx 超时。"""
        return httpx.Timeout(
            connect=self._request_config.connect_timeout,
            read=self._request_config.read_timeout,
            write=self._request_config.connect_timeout,
            pool=self._request_config.connect_timeout,
        )

    async def client(self) -> httpx.AsyncClient:
        """获取复用的异步客户端；未注入时惰性创建。"""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.build_timeout())
            self._owns_client = True
        return self._client

    async def aclose(self) -> None:
        """关闭自建客户端；外部注入的客户端由应用生命周期负责。"""
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None
        self._owns_client = False

    def api_key(self) -> str:
        """从环境变量读取 API Key，缺失时抛 AuthenticationError。"""
        if self._api_key is None:
            self._api_key = os.environ.get(self._config.api_key_env, "").strip()
        if not self._api_key:
            raise AuthenticationError(
                f"provider '{self.name}' 缺少 API Key，请设置环境变量 "
                f"{self._config.api_key_env}",
                code="missing_api_key",
            )
        return self._api_key

    @abstractmethod
    def endpoint(self) -> str:
        """返回上游对话补全的完整 URL。"""

    @abstractmethod
    def build_headers(self) -> dict[str, str]:
        """构造上游请求头。"""

    @abstractmethod
    def build_body(self, req: ProviderRequest) -> dict[str, Any]:
        """把内部请求映射为上游请求体。"""

    @abstractmethod
    def parse_result(self, data: dict[str, Any]) -> ProviderResult:
        """把上游非流式响应归一化为 ProviderResult。"""

    @abstractmethod
    def parse_chunk(self, data: dict[str, Any], state: dict[str, Any]) -> ProviderChunk | None:
        """把一个上游 SSE 数据块归一化为 ProviderChunk；返回 None 表示跳过。"""

    @staticmethod
    def is_stream_done(payload: str) -> bool:
        """判断 SSE 数据是否为流结束标记。"""
        return payload.strip() == "[DONE]"

    def sleep_seconds(self, attempt: int) -> float:
        """指数退避等待时长。"""
        return self._request_config.backoff_base * float(2**attempt)

    async def chat(self, req: ProviderRequest) -> ProviderResult:
        """执行非流式调用，仅对超时、429、5xx 做指数退避重试。"""
        client = await self.client()
        url = self.endpoint()
        headers = self.build_headers()
        body = self.build_body(req)
        max_retries = self._request_config.max_retries

        for attempt in range(max_retries + 1):
            last_error: GatewayError | None = None
            try:
                response = await client.post(
                    url, headers=headers, json=body, timeout=self.build_timeout()
                )
            except httpx.TimeoutException as exc:
                last_error = UpstreamTimeout(
                    f"上游 '{self.name}' 请求超时", code="upstream_timeout"
                )
                if attempt >= max_retries:
                    raise last_error from exc
                await asyncio.sleep(self.sleep_seconds(attempt))
                continue
            except httpx.HTTPError as exc:
                raise ProviderError(
                    f"上游 '{self.name}' 请求失败: {exc.__class__.__name__}",
                    code="provider_error",
                ) from exc

            if response.status_code == 200:
                return self.parse_result(self._decode_json(response))

            if response.status_code in RETRYABLE_STATUS and attempt < max_retries:
                await asyncio.sleep(self.sleep_seconds(attempt))
                continue

            raise self.normalize_http_error(response.status_code, response)

        raise last_error or ProviderError("上游调用失败", code="provider_error")

    async def chat_stream(self, req: ProviderRequest) -> AsyncIterator[ProviderChunk]:
        """执行流式调用；流式请求默认不重试。"""
        client = await self.client()
        url = self.endpoint()
        headers = self.build_headers()
        body = self.build_body(req)
        state: dict[str, Any] = {}

        try:
            async with client.stream(
                "POST", url, headers=headers, json=body, timeout=self.build_timeout()
            ) as response:
                if response.status_code != 200:
                    await response.aread()
                    raise self.normalize_http_error(response.status_code, response)

                async for line in response.aiter_lines():
                    if not line.startswith("data:"):
                        continue

                    payload = line[len("data:") :].strip()
                    if not payload or self.is_stream_done(payload):
                        continue

                    try:
                        data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue

                    chunk = self.parse_chunk(data, state)
                    if chunk is not None:
                        yield chunk
        except httpx.TimeoutException as exc:
            raise UpstreamTimeout(
                f"上游 '{self.name}' 流式请求超时", code="upstream_timeout"
            ) from exc
        except httpx.HTTPError as exc:
            if isinstance(exc, httpx.TimeoutException):
                raise
            raise ProviderError(
                f"上游 '{self.name}' 流式请求失败: {exc.__class__.__name__}",
                code="provider_error",
            ) from exc

    def normalize_http_error(self, status_code: int, response: httpx.Response) -> GatewayError:
        """把上游 HTTP 错误归一化为统一异常。"""
        data = self._safe_json(response)
        message, upstream_code = self._extract_error(data, status_code)

        if status_code in (401, 403) and "api key" in message.lower():
            return AuthenticationError(message, code=upstream_code or "invalid_api_key")
        if status_code == 401:
            return AuthenticationError(message, code=upstream_code or "invalid_api_key")
        if status_code == 403:
            return PermissionDenied(message, code=upstream_code or "permission_denied")
        if status_code == 404:
            return NotFound(message, code=upstream_code or "not_found")
        if status_code == 429:
            return RateLimited(message, code=upstream_code or "rate_limited")
        if "content_filter" in message.lower() or upstream_code == "content_filter":
            return ProviderError(message, code="content_filtered")
        return ProviderError(message, code=upstream_code or "provider_error")

    @staticmethod
    def _safe_json(response: httpx.Response) -> dict[str, Any]:
        """尽力解析错误响应体。"""
        try:
            data = response.json()
        except (json.JSONDecodeError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _decode_json(response: httpx.Response) -> dict[str, Any]:
        """解析成功响应体。"""
        try:
            data = response.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise ProviderError("上游响应不是合法 JSON", code="provider_error") from exc
        if not isinstance(data, dict):
            raise ProviderError("上游响应结构非法", code="provider_error")
        return data

    @staticmethod
    def _extract_error(data: dict[str, Any], status_code: int) -> tuple[str, str | None]:
        """从上游错误体中提取可读信息与错误码，不回显敏感内容。"""
        error = data.get("error")
        if isinstance(error, dict):
            message = error.get("message") or error.get("type") or ""
            code = error.get("code") or error.get("type")
        elif isinstance(error, str):
            message, code = error, None
        else:
            message, code = "", None

        if not message:
            message = f"上游返回 HTTP {status_code}"
        return str(message), str(code) if code is not None else None


def merge_usage(prompt_tokens: int, completion_tokens: int) -> dict[str, int]:
    """构造 usage 字典，自动补全 total_tokens。"""
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
    }
