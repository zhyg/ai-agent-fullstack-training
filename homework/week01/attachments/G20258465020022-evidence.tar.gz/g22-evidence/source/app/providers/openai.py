"""OpenAI 兼容协议适配器（同样适用于 DeepSeek、通义千问等兼容厂商）。"""

from typing import Any

from ..errors import ProviderError
from ..schemas import (
    Delta,
    Message,
    MessageRole,
    ProviderChunk,
    ProviderRequest,
    ProviderResult,
    Usage,
)
from .base import BaseHTTPProvider

CHAT_COMPLETIONS_PATH = "/chat/completions"


class OpenAIProvider(BaseHTTPProvider):
    """OpenAI Chat Completions 协议适配器。"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        if not self.name or self.name == "base":
            self.name = "openai"

    def endpoint(self) -> str:
        """返回 OpenAI 对话补全地址。"""
        return f"{self.base_url}{CHAT_COMPLETIONS_PATH}"

    def build_headers(self) -> dict[str, str]:
        """构造 Bearer 认证头。"""
        return {
            "Authorization": f"Bearer {self.api_key()}",
            "Content-Type": "application/json",
        }

    def build_body(self, req: ProviderRequest) -> dict[str, Any]:
        """把内部请求映射为 OpenAI 请求体。"""
        body: dict[str, Any] = {
            "model": req.upstream_model,
            "messages": [
                {"role": message.role.value, "content": message.content}
                for message in req.messages
            ],
            "stream": req.stream,
        }

        if req.temperature is not None:
            body["temperature"] = req.temperature
        if req.max_tokens is not None:
            body["max_tokens"] = req.max_tokens

        if req.stream:
            body["stream_options"] = {"include_usage": True}
        elif req.response_scheme is not None:
            body["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": req.response_scheme.name,
                    "schema": req.response_scheme.json_schema,
                    "strict": req.response_scheme.strict,
                },
            }

        body.update(req.extra)
        return body

    def parse_result(self, data: dict[str, Any]) -> ProviderResult:
        """归一化非流式响应。"""
        choices = data.get("choices") or []
        if not choices:
            raise ProviderError("上游响应缺少 choices", code="provider_error")

        choice = choices[0]
        message_data = choice.get("message") or {}
        role = _coerce_role(message_data.get("role"))

        return ProviderResult(
            response_id=str(data.get("id") or ""),
            message=Message(role=role, content=message_data.get("content") or ""),
            finish_reason=choice.get("finish_reason"),
            usage=_parse_usage(data.get("usage")),
            raw=data,
        )

    def parse_chunk(self, data: dict[str, Any], state: dict[str, Any]) -> ProviderChunk | None:
        """归一化单个 SSE 增量块。"""
        response_id = str(data.get("id") or state.get("response_id") or "")
        if response_id:
            state["response_id"] = response_id

        usage = _parse_usage(data["usage"]) if data.get("usage") else None
        choices = data.get("choices") or []

        if not choices:
            if usage is None:
                return None
            return ProviderChunk(
                response_id=response_id,
                delta=Delta(),
                finish_reason=state.get("finish_reason"),
                usage=usage,
                raw=data,
            )

        choice = choices[0]
        delta_data = choice.get("delta") or {}
        finish_reason = choice.get("finish_reason")
        if finish_reason:
            state["finish_reason"] = finish_reason

        role = delta_data.get("role")
        content = delta_data.get("content")
        if role is None and content is None and not finish_reason and usage is None:
            return None

        return ProviderChunk(
            response_id=response_id,
            delta=Delta(role=_coerce_role(role) if role else None, content=content),
            finish_reason=finish_reason,
            usage=usage,
            raw=data,
        )


def _coerce_role(value: Any) -> MessageRole:
    """把上游角色映射为统一角色，未知值按 assistant 处理。"""
    try:
        return MessageRole(value)
    except ValueError:
        return MessageRole.ASSISTANT


def _parse_usage(usage: Any) -> Usage:
    """解析 OpenAI usage 字段。"""
    data = usage if isinstance(usage, dict) else {}
    prompt_tokens = int(data.get("prompt_tokens") or 0)
    completion_tokens = int(data.get("completion_tokens") or 0)
    total_tokens = int(data.get("total_tokens") or (prompt_tokens + completion_tokens))
    return Usage(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
    )
