"""Anthropic Messages API 适配器。"""

import json
from typing import Any

from ..schemas import (
    Delta,
    Message,
    MessageRole,
    ProviderChunk,
    ProviderRequest,
    ProviderResult,
    ResponseScheme,
    Usage,
)
from .base import BaseHTTPProvider

MESSAGES_PATH = "/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_MAX_TOKENS = 1024

STOP_REASON_MAP = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "refusal": "content_filter",
    "pause_turn": "stop",
}


class AnthropicProvider(BaseHTTPProvider):
    """Anthropic Messages 协议适配器，负责 system 消息、max_tokens 与 SSE 事件转换。"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        if not self.name or self.name == "base":
            self.name = "anthropic"

    def endpoint(self) -> str:
        """返回 Anthropic Messages 地址。"""
        base = self.base_url
        if base.endswith(MESSAGES_PATH):
            return base
        return f"{base}{MESSAGES_PATH}"

    def build_headers(self) -> dict[str, str]:
        """构造 x-api-key 与 anthropic-version 头。"""
        return {
            "x-api-key": self.api_key(),
            "anthropic-version": ANTHROPIC_VERSION,
            "Content-Type": "application/json",
        }

    def build_body(self, req: ProviderRequest) -> dict[str, Any]:
        """把内部请求映射为 Anthropic 请求体。"""
        system_text, messages = _split_messages(req.messages)

        if req.response_scheme is not None and not req.stream:
            system_text = _append_json_instruction(system_text, req.response_scheme)

        body: dict[str, Any] = {
            "model": req.upstream_model,
            "messages": messages,
            "max_tokens": req.max_tokens or DEFAULT_MAX_TOKENS,
            "stream": req.stream,
        }

        if system_text:
            body["system"] = system_text
        if req.temperature is not None:
            body["temperature"] = req.temperature

        body.update(req.extra)
        return body

    def parse_result(self, data: dict[str, Any]) -> ProviderResult:
        """归一化非流式响应。"""
        text = _join_content_blocks(data.get("content"))
        stop_reason = data.get("stop_reason")
        finish_reason = (
            STOP_REASON_MAP.get(stop_reason, stop_reason)
            if isinstance(stop_reason, str)
            else None
        )

        return ProviderResult(
            response_id=str(data.get("id") or ""),
            message=Message(role=MessageRole.ASSISTANT, content=text),
            finish_reason=finish_reason,
            usage=_parse_usage(data.get("usage")),
            raw=data,
        )

    def parse_chunk(self, data: dict[str, Any], state: dict[str, Any]) -> ProviderChunk | None:
        """归一化 Anthropic SSE 事件。"""
        event_type = data.get("type")

        if event_type == "message_start":
            message = data.get("message") or {}
            response_id = str(message.get("id") or "")
            if response_id:
                state["response_id"] = response_id
            usage = message.get("usage") or {}
            state["prompt_tokens"] = int(usage.get("input_tokens") or 0)
            state["completion_tokens"] = int(usage.get("output_tokens") or 0)
            return ProviderChunk(
                response_id=state.get("response_id", ""),
                delta=Delta(role=MessageRole.ASSISTANT, content=None),
                raw=data,
            )

        if event_type == "content_block_delta":
            delta = data.get("delta") or {}
            text = delta.get("text")
            if delta.get("type") not in ("text_delta", None) or text is None:
                return None
            return ProviderChunk(
                response_id=state.get("response_id", ""),
                delta=Delta(content=text),
                raw=data,
            )

        if event_type == "message_delta":
            delta = data.get("delta") or {}
            stop_reason = delta.get("stop_reason")
            finish_reason = (
                STOP_REASON_MAP.get(stop_reason, stop_reason)
                if isinstance(stop_reason, str)
                else None
            )
            usage = data.get("usage") or {}
            if usage.get("output_tokens") is not None:
                state["completion_tokens"] = int(usage.get("output_tokens") or 0)
            if finish_reason:
                state["finish_reason"] = finish_reason

            return ProviderChunk(
                response_id=state.get("response_id", ""),
                delta=Delta(),
                finish_reason=finish_reason,
                usage=_usage_from_state(state),
                raw=data,
            )

        return None


def _split_messages(messages: list[Message]) -> tuple[str, list[dict[str, str]]]:
    """拆出 system 文本，并把其余消息映射为 Anthropic 结构。"""
    system_parts: list[str] = []
    converted: list[dict[str, str]] = []

    for message in messages:
        if message.role == MessageRole.SYSTEM:
            system_parts.append(message.content)
        elif message.role == MessageRole.TOOL:
            prefix = f"[{message.name}] " if message.name else "[tool] "
            converted.append({"role": "user", "content": prefix + message.content})
        else:
            converted.append({"role": message.role.value, "content": message.content})

    return "\n\n".join(system_parts), converted


def _append_json_instruction(system_text: str, scheme: ResponseScheme) -> str:
    """Anthropic 无原生 JSON Schema 能力，通过 system 指令约束输出。"""
    schema_json = json.dumps(scheme.json_schema, ensure_ascii=False, sort_keys=True)
    instruction = (
        f"你必须只输出一个符合 JSON Schema '{scheme.name}' 的 JSON 对象，"
        f"不要输出 Markdown 代码围栏、解释或任何多余文本。Schema: {schema_json}"
    )
    if scheme.description:
        instruction += f"\n输出说明：{scheme.description}"

    return f"{system_text}\n\n{instruction}" if system_text else instruction


def _join_content_blocks(content: Any) -> str:
    """拼接 Anthropic content 数组中的文本块。"""
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""

    parts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(str(block.get("text") or ""))
    return "".join(parts)


def _parse_usage(usage: Any) -> Usage:
    """把 Anthropic usage 映射为统一 Usage。"""
    data = usage if isinstance(usage, dict) else {}
    prompt_tokens = int(data.get("input_tokens") or 0)
    completion_tokens = int(data.get("output_tokens") or 0)
    return Usage(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
    )


def _usage_from_state(state: dict[str, Any]) -> Usage:
    """用流式累积状态构造 Usage。"""
    prompt_tokens = int(state.get("prompt_tokens") or 0)
    completion_tokens = int(state.get("completion_tokens") or 0)
    return Usage(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
    )
