# LLM Gateway

统一的大语言模型网关服务，提供一套接口屏蔽不同厂商（OpenAI、Anthropic、DeepSeek 等）的差异。

## 功能

- 统一的请求/响应模型 `LLMRequest` / `LLMResponse`，支持非流式与流式（SSE）调用，共用同一套事件语义（`start` → `delta`* → `done` / `error`）
- 配置驱动的模型路由与厂商适配：新增厂商只需实现 `BaseProvider` 并注册配置，无需改动 API 层
- 提示词版本管理：YAML 模板存储、`{{ variable }}` 字面量替换、版本解析、内容 SHA-256 hash，变更可追溯、可复现
- 非流式结构化输出：`response_scheme` 提供 JSON Schema，自动去除代码围栏、提取并校验 JSON，结果写入 `choices[].parsed`
- 调用链路追踪 `CallTrace`：记录模型、provider、提示词版本/hash、token 用量、耗时、流式首包延迟（TTFT）与状态，可随响应返回或仅写日志
- 工程化能力：超时、指数退避重试（仅超时/429/5xx，流式不重试）、错误归一化、结构化日志、API Key 从环境变量读取

## 目录结构

```
llm-gateway/
├── app/
│   ├── main.py              # FastAPI 应用入口：lifespan、路由与异常处理器装配
│   ├── gateway.py           # 运行期依赖容器（配置、providers、router、registry）
│   ├── api/
│   │   └── chat.py          # /v1/chat/completions、/v1/models
│   ├── schemas.py           # LLMRequest / LLMResponse / Prompt* / CallTrace 等模型
│   ├── config.py            # YAML + .env 配置加载与校验
│   ├── router.py            # 模型路由：逻辑模型名 → provider + upstream_model
│   ├── errors.py            # 统一异常层级与 HTTP 错误映射
│   ├── logging.py           # 结构化 JSON 日志与敏感信息脱敏
│   ├── prompts/
│   │   ├── registry.py      # PromptRegistry：加载、版本解析、变量替换、hash
│   │   └── builder.py       # build_message：模板消息 + 调用方消息装配
│   ├── response.py          # JSON 提取、Schema 校验、统一事件封装
│   ├── trace.py             # CallTrace 采集与日志输出
│   └── providers/
│       ├── base.py          # BaseProvider 抽象 + 共享 HTTP/超时/重试/错误归一化
│       ├── openai.py        # OpenAI 兼容协议（可复用于 DeepSeek 等）
│       └── anthropic.py     # Anthropic Messages 协议
├── prompts/
│   └── example.yaml         # 提示词模板与版本示例
├── tests/                   # pytest 测试（Mock 上游，不访问真实网络）
├── config.example.yaml      # 配置示例
├── .env.example             # 环境变量示例
└── pyproject.toml
```

## 配置

1. 复制配置：

```bash
cp config.example.yaml config.yaml
cp .env.example .env
```

2. 在 `.env` 中填入各 provider 的 API Key（配置只记录环境变量名，不记录密钥）：

```
OPENAI_API_KEY=sk-xxx
ANTHROPIC_API_KEY=xxx
```

3. 编辑 `config.yaml`：

- `providers`：每个厂商的 `type`、`base_url`、`api_key_env`
- `models`：逻辑模型名 → provider 与上游模型名；键支持通配符（如 `"gpt-*"`），`upstream_model` 可用 `{model}` 占位
- `prompts.dir`：提示词 YAML 目录
- `trace.include_in_response`：是否在响应中返回 `CallTrace`（日志始终记录）
- `request`：`connect_timeout`、`read_timeout`、`max_retries`、`backoff_base`

配置文件按 `CONFIG_PATH` 环境变量 → `config.yaml` → `config.yml` → `config.example.yaml` 顺序解析，缺少必填项或配置非法时启动失败并给出清晰错误。

## 提示词编写

模板存放于 `prompts/*.yaml`，启动时加载到只读注册表：

```yaml
- name: customer_support
  version: "1"
  status: active            # active / draft / deprecated
  description: 客服助手系统提示
  variables: [company, tone, question]
  messages:
    - role: system
      content: "你是 {{company}} 的客服助理，语气{{tone}}。"
    - role: user
      content: "{{question}}"
```

规则：

- 变量替换仅做字面量替换（空白容忍，如 `{{ company }}`），不执行任何表达式
- 模板声明的变量必须全部提供，额外变量被忽略
- 请求通过 `prompt: {name, version?, variables}` 引用；未指定版本时使用该名称下最后一个 `active` 版本
- 模板内容计算 SHA-256 `content_hash`，随 `LLMResponse.prompt` 与 `CallTrace` 回显，可复现某次调用实际使用的版本
- 模板变更通过修改文件并重启生效；运行期不提供模板发现或写入接口

## 启动

```bash
pip install -e ".[dev]"     # 或 uv pip install -e ".[dev]"
uvicorn app.main:app --reload
```

## curl 示例

### 非流式（必须提供 response_scheme，返回校验后的 parsed）

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [{"role": "user", "content": "什么是 LLM 网关？用一句话回答"}],
    "response_scheme": {
      "name": "answer",
      "json_schema": {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"]
      }
    }
  }'
```

### 流式（无需 response_scheme，SSE 事件序列）

```bash
curl -N -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [{"role": "user", "content": "讲个笑话"}],
    "stream": true
  }'
```

### 使用受控提示词模板

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "claude-3-5-sonnet",
    "prompt": {
      "name": "customer_support",
      "version": "1",
      "variables": {"company": "ACME", "tone": "友好", "question": "如何退货？"}
    },
    "messages": [{"role": "user", "content": "订单号 12345"}],
    "response_scheme": {"name": "reply", "json_schema": {"type": "object", "properties": {"reply": {"type": "string"}}}}
  }'
```

### 发现接口

```bash
curl http://localhost:8000/healthz
curl http://localhost:8000/v1/models
```

## 测试

```bash
make test          # pytest（全部使用 Mock 上游，不访问真实网络）
make check         # ruff + mypy + pytest
```

## 扩展新厂商

1. 在 `app/providers/` 新建适配器，继承 `BaseHTTPProvider`（或实现 `BaseProvider`），完成 `endpoint` / `build_headers` / `build_body` / `parse_result` / `parse_chunk`
2. 在 `app/providers/__init__.py` 的 `PROVIDER_TYPES` 中注册新类型名
3. 在 `config.yaml` 中添加 provider 条目与模型映射

API 层、路由与追踪逻辑均无需改动。

## 后续扩展

数据库持久化、鉴权与限流、Docker/K8s 部署、更多厂商适配等不在本轮范围内，可按需演进。
