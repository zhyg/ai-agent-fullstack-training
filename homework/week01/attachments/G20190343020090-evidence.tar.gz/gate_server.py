from teacher import Transport, Gate, make
t=Transport()
app=make(t)
@app.post('/teacher/setup/{proto}/{cut}')
async def setup(proto: str,cut: int):
    t.calls.clear()
    t.gate=Gate(proto,bool(cut))
    return {'ready':True}
@app.post('/teacher/release')
async def release():
    t.gate.release.set()
    return {'released':True}
@app.get('/teacher/state')
async def state():
    return {'released':t.gate.release.is_set(),'closed':t.gate.closed,'calls':t.calls}
