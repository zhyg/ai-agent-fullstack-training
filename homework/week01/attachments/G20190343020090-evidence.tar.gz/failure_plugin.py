"""Inject one invalid fixture in memory, without touching student files."""
import copy
def pytest_runtest_setup(item):
    if item.name == 'test_dual_adapters_translate_same_request':
        item.module.OPENAI_RAW=copy.deepcopy(item.module.OPENAI_RAW)
        for obj in item.module.OPENAI_RAW['output']:
            if obj.get('type')=='message':
                for part in obj.get('content',[]):
                    if part.get('type')=='output_text':
                        part['text']='TEACHER_INJECTED_WRONG_RESPONSE'
