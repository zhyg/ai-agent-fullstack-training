import httpx,json,time
from pathlib import Path
results=[]
with httpx.Client(base_url='http://127.0.0.1:8031',timeout=5) as c:
    for p in ('O','A'):
        for cut in (0,1):
            c.post(f'/teacher/setup/{p}/{cut}').raise_for_status()
            start=time.perf_counter(); first=None; lines=[]; gate_state=None
            with c.stream('POST','/v1/chat',headers={'X-Request-Id':f'teacher-socket-{p}-{cut}'},json={'model':p,'messages':[{'role':'user','content':'socket gate'}],'stream':True}) as r:
                status=r.status_code
                for line in r.iter_lines():
                    lines.append(line)
                    if 'alpha' in line and first is None:
                        first=(time.perf_counter()-start)*1000
                        gate_state=c.get('/teacher/state').json()
                        time.sleep(.3)
                        c.post('/teacher/release').raise_for_status()
            wall=(time.perf_counter()-start)*1000
            state=c.get('/teacher/state').json()
            final=[json.loads(s[6:]) for s in lines if s.startswith('data: {')]
            ok=status==200 and first is not None and gate_state['released']==False and len(state['calls'])==1 and state['closed'] and any('error' in x for x in final)==bool(cut)
            results.append({'protocol':p,'cut':bool(cut),'pass':ok,'first_content_ms':first,'wall_ms':wall,'before_release':gate_state,'final_state':state,'lines':lines})
            assert ok,results[-1]
Path('/tmp/grading-G20190343020090/socket-gate-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('4 socket gate scenarios passed; actual TCP content received before terminal release; both cuts made one upstream call')
