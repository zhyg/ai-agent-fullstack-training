"""Teacher verification against unmodified student code. All upstream traffic is simulated."""
import asyncio, copy, json, os, sys, time
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from prometheus_client import CollectorRegistry
from gateway.main import create_app
from gateway.config import Settings
from gateway.core.router import Router, RouteTable
from gateway.prompt.store import SQLiteStore
from gateway.resilience.retry import RetryPolicy
from gateway.resilience.ratelimit import MemoryRateLimiter
from gateway.telemetry.metrics import GatewayMetrics

OUT=Path('/tmp/grading-G20190343020090')
os.environ['TEACHER_FAKE_KEY']='not-a-real-credential'
RESULTS=[]
def record(name, passed, detail):
    RESULTS.append({'case':name,'passed':bool(passed),'detail':detail})
    (OUT/'teacher-results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))
    print(json.dumps(RESULTS[-1],ensure_ascii=False),flush=True)

def raw(proto,text='alpha',usage=True):
    if proto=='O':
        d={'id':'resp_teacher','model':'teacher-O','status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':text}]}]}
        if usage: d['usage']={'input_tokens':17,'output_tokens':11,'input_tokens_details':{'cached_tokens':5},'output_tokens_details':{'reasoning_tokens':3}}
    else:
        d={'id':'msg_teacher','model':'teacher-A','stop_reason':'end_turn','content':[{'type':'text','text':text}]}
        if usage: d['usage']={'input_tokens':17,'output_tokens':11,'cache_read_input_tokens':5,'cache_creation_input_tokens':2}
    return d
def frame(typ,**body):
    return ('event: '+typ+'\ndata: '+json.dumps({'type':typ,**body})+'\n\n').encode()
def chunks(proto):
    if proto=='O':
        return (frame('response.created'),frame('response.output_text.delta',delta='门控-alpha'),frame('response.completed',response=raw(proto)))
    return (frame('message_start',message={'id':'msg_gate','usage':raw(proto)['usage']}),frame('content_block_delta',index=0,delta={'type':'text_delta','text':'门控-alpha'}),frame('message_delta',delta={'stop_reason':'end_turn'},usage={'output_tokens':11})+frame('message_stop'))

class Transport:
    def __init__(self): self.calls=[]; self.scripts={}; self.gate=None
    def script(self,proto,*responses): self.scripts[proto]=list(responses); return self
    async def send(self,url,payload,headers,route):
        async def handler(request):
            p=json.loads(request.content); proto=p['model']
            self.calls.append({'url':str(request.url),'payload':p,'auth_fields':sorted(k for k in request.headers if k in ('authorization','x-api-key','anthropic-version')),'time':time.perf_counter()})
            queue=self.scripts.get(proto)
            if queue:
                r=queue.pop(0) if len(queue)>1 else queue[0]
                return httpx.Response(r[0],json=r[1])
            if payload.get('stream'):
                if self.gate:
                    return httpx.Response(200,stream=self.gate,headers={'content-type':'text/event-stream'})
                return httpx.Response(200,content=b''.join(chunks(proto)),headers={'content-type':'text/event-stream'})
            return httpx.Response(200,json=raw(proto))
        # Each counted call is an HTTP request observed at the final httpx transport;
        # no OpenAI/Anthropic SDK, and httpx has no automatic retries here.
        request=httpx.Request('POST',url,json=payload,headers=headers)
        return await httpx.MockTransport(handler).handle_async_request(request)
    post=send
    stream=send

def make(t,limits=None,limiter=None,retry=None):
    table=RouteTable.model_validate({'models':{p:{'adapter':'openai_responses' if p=='O' else 'anthropic_messages','upstream_model':p,'base_url':'https://teacher.invalid'+('' if p=='O' else '/anthropic'),'api_key_env':'TEACHER_FAKE_KEY','limits':(limits or {}).get(p,{'rpm':600,'tpm':200000,'concurrent':8})} for p in ('O','A')}})
    s=Settings(logging={'sample_rate':1.0},retry={'base_delay_ms':100,'max_delay_ms':800},prompt={'db_path':':memory:'})
    app=create_app(s,router=Router(table.models),transport=t,prompt_store=SQLiteStore(':memory:'),limiter=limiter,retry=retry)
    app.state.metrics=GatewayMetrics(CollectorRegistry())
    return app
def payload(p,**kw): return {'model':p,'messages':[{'role':'user','content':'teacher asymmetric input'}],**kw}
def post(c,p,**kw): return c.post('/v1/chat',json=payload(p,**kw),headers={'X-Request-Id':'teacher-'+p+'-request'})
def samples(app):
    return {s.name+str(sorted(s.labels.items())):s.value for m in app.state.metrics.registry.collect() for s in m.samples if not s.name.endswith('_created') and not s.name.endswith('_bucket')}

def normal_and_templates():
    t=Transport(); app=make(t)
    with TestClient(app) as c:
        for p in ('O','A'):
            r=post(c,p); d=r.json(); call=t.calls[-1]
            ok= r.status_code==200 and d['text']=='alpha' and d['usage']['input_tokens']==17 and d['usage']['output_tokens']==11
            record('A03-'+p,ok,{'response':d,'upstream':call})
            u=d['usage']
            record('F07-categories-'+p,u['cache_read_tokens']==5 and (u['reasoning_tokens']==3 if p=='O' else u['cache_write_tokens']==2),u)
        r=post(c,'ghost'); record('A04',r.status_code==404 and r.json()['error']['code']=='MODEL_NOT_FOUND',r.json())
        for i,content in enumerate(('v1 {{ who }}','v2 {{ who }}'),1):
            r=c.post('/v1/prompts',json={'name':'greet','content':content,'variables':[{'name':'who'}],'status':'active'})
            assert r.status_code==201
        for v in (1,2,1):
            r=c.post('/v1/chat',json={'model':'O','prompt_ref':{'name':'greet','version':v},'variables':{'who':'Ada'}})
            text=t.calls[-1]['payload']['input'][0]['content'][0]['text']
            record('F05-v'+str(v),r.status_code==200 and text==f'v{v} Ada',{'status':r.status_code,'upstream_text':text,'prompt':r.json().get('prompt')})
        for ref,variables in (({'name':'missing','version':1},{}),({'name':'greet','version':99},{'who':'Ada'}),({'name':'greet','version':1},{})):
            before=len(t.calls); r=c.post('/v1/chat',json={'model':'O','prompt_ref':ref,'variables':variables})
            record('F06',r.status_code in (400,404) and len(t.calls)==before,{'response':r.json(),'status':r.status_code,'upstream_calls':len(t.calls)-before})

def structured():
    for p in ('O','A'):
        for name,text in [('valid','{"a":7}'),('valid-schema','{"a":7}'),('illegal','not json'),('empty',''),('cut','{"a":'),('wrong-schema','{"a":"bad"}')]:
            t=Transport().script(p,(200,raw(p,text))); app=make(t)
            fmt={'type':'json_object'}
            if name in ('valid-schema','wrong-schema'): fmt={'type':'json_schema','json_schema':{'name':'s','schema':{'type':'object','properties':{'a':{'type':'integer'}},'required':['a'],'additionalProperties':False}}}
            with TestClient(app) as c:
                r=post(c,p,response_format=fmt)
                expected=200 if name in ('valid','valid-schema') else 502
                record(('F03-' if expected==200 else 'F04-')+p+'-'+name,r.status_code==expected,{'status':r.status_code,'body':r.json(),'calls':len(t.calls),'upstream':t.calls})
        # Known usage from a failed repair must not vanish from the call ledger.
        t=Transport().script(p,(200,raw(p,'bad')),(200,raw(p,'{"a":7}')))
        app=make(t)
        with TestClient(app) as c:
            r=post(c,p,response_format={'type':'json_object'})
            vals=samples(app)
            if p=='A':
                record('F07-repair-usage-'+p,any('type\', \'input' in k and v==34 for k,v in vals.items()),{'calls':len(t.calls),'response':r.json(),'metrics':vals})
            else:
                record('F04-native-no-repair-O',r.status_code==502 and len(t.calls)==1,{'calls':len(t.calls),'response':r.json()})

def retry_and_limit():
    for p in ('O','A'):
        for kind,seq,expected,n in [('recover',[(503,{}),(503,{}),(200,raw(p))],200,3),('persistent',[(500,{})],503,3),('bad-request',[(400,{})],400,1),('auth',[(401,{})],401,1)]:
            sleeps=[]
            async def sleep(s): sleeps.append(s)
            pol=RetryPolicy(Settings().retry,rng=lambda:0.5,sleep=sleep)
            t=Transport().script(p,*seq); app=make(t,retry=pol)
            with TestClient(app) as c: r=post(c,p)
            record('F08/09-'+p+'-'+kind,r.status_code==expected and len(t.calls)==n and sleeps==([0.25,0.5] if n==3 else []),{'status':r.status_code,'calls':len(t.calls),'wait_s':sleeps,'body':r.json(),'final_transport_calls':t.calls})
    now=[1000.0]; limiter=MemoryRateLimiter(clock=lambda:now[0])
    t=Transport(); app=make(t,limits={'O':{'rpm':1,'tpm':200000,'concurrent':8}},limiter=limiter)
    with TestClient(app) as c:
        codes=[post(c,'O').status_code,post(c,'O').status_code,post(c,'A').status_code]
        now[0]+=59; before=post(c,'O').status_code
        now[0]+=1.01; after=post(c,'O').status_code
        record('F10/F11',codes==[200,429,200] and before==429 and after==200,{'statuses':codes,'at59s':before,'at60_01s':after,'calls':t.calls})

class Gate(httpx.AsyncByteStream):
    def __init__(self,p,cut=False): self.p=p; self.release=asyncio.Event(); self.cut=cut; self.closed=False
    async def __aiter__(self):
        start,delta,done=chunks(self.p)
        yield start
        await asyncio.sleep(.10)
        yield delta
        await self.release.wait()
        if not self.cut: yield done
    async def aclose(self): self.closed=True

async def gated(p,cut=False):
    t=Transport(); g=Gate(p,cut); t.gate=g; app=make(t)
    incoming=asyncio.Queue(); await incoming.put({'type':'http.request','body':json.dumps(payload(p,stream=True)).encode(),'more_body':False})
    body=[]; received=asyncio.Event(); first=None
    async def receive(): return await incoming.get()
    async def send(message):
        nonlocal first
        if message['type']=='http.response.body':
            b=message.get('body',b''); body.append(b)
            if b'alpha' in b and first is None: first=time.perf_counter(); received.set()
    scope={'type':'http','asgi':{'version':'3.0','spec_version':'2.3'},'http_version':'1.1','method':'POST','scheme':'http','path':'/v1/chat','raw_path':b'/v1/chat','query_string':b'','headers':[(b'content-type',b'application/json'),(b'x-request-id',('teacher-gate-'+p+str(cut)).encode())],'server':('teacher',80),'client':('test',123)}
    start=time.perf_counter(); task=asyncio.create_task(app(scope,receive,send))
    try:
        await asyncio.wait_for(received.wait(),3)
        before_release=not task.done() and not g.release.is_set()
        await asyncio.sleep(.30); release_time=time.perf_counter(); g.release.set()
        await asyncio.wait_for(task,3)
        elapsed=(time.perf_counter()-start)*1000
        frames=[json.loads(line[6:]) for line in b''.join(body).decode().splitlines() if line.startswith('data: {')]
        detail={'body':b''.join(body).decode(),'first_content_ms':round((first-start)*1000,2),'release_ms':round((release_time-start)*1000,2),'elapsed_ms':round(elapsed,2),'before_release':before_release,'calls':len(t.calls),'closed':g.closed,'metrics':samples(app)}
        if cut:
            record('F02-'+p,before_release and len(t.calls)==1 and any('error' in x for x in frames),detail)
        else:
            record('F01-'+p,before_release and b'[DONE]' in b''.join(body) and len(t.calls)==1,detail)
            total=frames[-1]['gateway']['total_ms']; ttft=frames[-1]['gateway']['ttft_ms']
            record('F07-stream-timing-'+p,total>=elapsed-40 and ttft>=80,{'reported_total_ms':total,'ttft_ms':ttft,'wall_ms':round(elapsed,2)})
    finally:
        g.release.set()
        if not task.done(): task.cancel()

def observations():
    for p in ('O','A'):
        t=Transport().script(p,(400,{})); app=make(t)
        with TestClient(app) as c: r=post(c,p)
        vals=samples(app)
        record('F07-failure-duration-'+p,any(k.startswith('llm_request_duration_ms_count') for k in vals),{'status':r.status_code,'metrics':vals})
        t=Transport().script(p,(200,raw(p,usage=False))); app=make(t)
        with TestClient(app) as c: r=post(c,p)
        record('F07-unknown-usage-'+p,r.json()['usage']['source']!='reported',r.json())

if __name__=='__main__':
    normal_and_templates(); structured(); retry_and_limit(); observations()
    for p in ('O','A'):
        asyncio.run(gated(p)); asyncio.run(gated(p,True))
    print('SUMMARY',sum(x['passed'] for x in RESULTS),'/',len(RESULTS))
