# G20190343020090 复现说明

固定学生仓库 https://gitee.com/menghaibin2009/llmgateway ，master 提交 789f314c8a6c4034f3e402bf1fe92950f11e7675。
直接 clone 成功，学生业务代码没有修改。source/ 是 git archive 固定源码（不含 .git 或凭据）。

证据目录对应 /tmp/grading-G20190343020090；将证据文件放回此处，student/ 由 clone 后 checkout 固定提交得到。
Python >=3.13，先在 student/ 按 README `uv sync`。

## 已执行命令

在 student/：

```bash
uv sync
uv run python -c "import fastapi,pydantic,httpx,structlog; print('deps ok')"
uv run pytest
uv run pytest tests/e2e -v
uv run python /tmp/grading-G20190343020090/teacher.py
PYTHONPATH=/tmp/grading-G20190343020090 uv run pytest tests/e2e/test_scenarios.py::test_dual_adapters_translate_same_request -p failure_plugin
```

最后一条故意注入错文本，应 1 failed、exit 1；其它教师检查中期望失败的四个可观测性缺陷会写 passed=false，不会被吞为通过。

## TCP 门控与 README 启动

在 student/，使用 orb 监督服务（不使用 nohup 或 shell 后台）：

```bash
amp orb service start grading-g20190343020090 --command 'uv run uvicorn gateway.main:app --host 0.0.0.0 --port 8030' --port 8030
curl -si http://127.0.0.1:8030/healthz
curl -si http://127.0.0.1:8030/v1/models
amp orb service start grading-g20190343020090-gate --command 'PYTHONPATH=/tmp/grading-G20190343020090 uv run uvicorn gate_server:app --host 0.0.0.0 --port 8031' --port 8031
uv run python /tmp/grading-G20190343020090/socket_gate.py
amp orb service stop grading-g20190343020090
amp orb service stop grading-g20190343020090-gate
```

门控4场景应全部通过；socket-gate-results.json 保存每次首正文、完整耗时、释放前状态、实际请求数和所有下游帧。
teacher.py 另外通过 ASGI send 记录门控与失败指标，避免 TestClient 缓冲造成假增量判断。

## 官方真实调用

进程内需预先存在个人 DEEPSEEK_API_KEY；不要打印、不要放入命令行或文件。然后在 student/：

```bash
uv run python /tmp/grading-G20190343020090/real_calls.py
```

此命令有少量真实费用，只请求 api.deepseek.com。配置已写在脚本中，无需改学生 routes.yaml 或业务代码。
每模型 normal/json/stream 各一次，max_output_tokens=256、read=25s、max_attempts=1；上游失败不无限重试，按证据标未验证。
使用原公开模型及真实映射，只有 api_key_env/输出预算/超时/采样/测试存储独立配置；未替代模型或协议。
真实流式原始上游SSE未留存，上游正文ID不明确时仅报告网关请求ID，不补造数据。

## 判分和清理

报告96/100，扣分只针对可观测性四个独立根因，不按37/44比例计分。
失败注入不写学生源码。导入默认 main 时产生的忽略数据库与测试临时数据不归档；设置 :memory: 被项目根路径解析产生的同名临时文件也已清理。
最后 git diff --exit-code=0，git status --porcelain 为空。两个服务已停。
归档包含配置变量名、假测试值和 HTTP 鉴权头名称，但不含任何真实鉴权值。
