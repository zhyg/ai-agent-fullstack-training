import json, os, time
from pathlib import Path
from fastapi.testclient import TestClient
from gateway.main import create_app
from gateway.config import Settings
from gateway.core.router import Router, RouteTable
from gateway.httpclient.pool import HttpClientPool

OUT = Path('/tmp/grading-G20190343020090')
records = []
class AuditPool(HttpClientPool):
    async def post(self, url, payload, headers, route):
        t = time.perf_counter()
        try:
            r = await super().post(url, payload, headers, route)
            records.append({'url':url,'payload':payload,'http_status':r.status_code,
                            'elapsed_ms':round((time.perf_counter()-t)*1000,2),
                            'upstream_request_id':r.headers.get('x-request-id'), 'body':r.json()})
            return r
        except Exception as e:
            records.append({'url':url,'payload':payload,'exception':type(e).__name__,
                            'elapsed_ms':round((time.perf_counter()-t)*1000,2)})
            raise
    async def stream(self, url, payload, headers, route):
        r = await super().stream(url,payload,headers,route)
        records.append({'url':url,'payload':payload,'http_status':r.status_code,
                        'upstream_request_id':r.headers.get('x-request-id')})
        return r

table = RouteTable.model_validate({'models':{
    'deepseek-v4-pro': {'adapter':'openai_responses','upstream_model':'deepseek-v4-pro','base_url':'https://api.deepseek.com','api_key_env':'DEEPSEEK_API_KEY', 'timeout':{'connect':5,'read':25}},
    'deepseek-v4-flash': {'adapter':'anthropic_messages','upstream_model':'deepseek-flash','base_url':'https://api.deepseek.com/anthropic','api_key_env':'DEEPSEEK_API_KEY','timeout':{'connect':5,'read':25}}
}})
settings = Settings(logging={'sample_rate':1.0}, retry={'max_attempts':1}, prompt={'db_path':':memory:'})
pool=AuditPool()
app=create_app(settings,router=Router(table.models),transport=pool)
results=[]
with TestClient(app) as c:
    c.portal.call(pool.startup)
    for model in table.models:
        for mode in ('normal','json','stream'):
            rid=f'teacher-real-{model}-{mode}'
            payload={'model':model,'messages':[{'role':'user','content':'Return only {"ok":true} as JSON. Do not explain.'}], 'max_output_tokens':256}
            if mode=='json': payload['response_format']={'type':'json_object'}
            if mode=='stream': payload['stream']=True
            t=time.perf_counter()
            try:
                r=c.post('/v1/chat',json=payload,headers={'X-Request-Id':rid})
                result={'model':model,'mode':mode,'request_id':rid,'status':r.status_code,'elapsed_ms':round((time.perf_counter()-t)*1000,2),'body':r.text}
            except Exception as e:
                result={'model':model,'mode':mode,'request_id':rid,'exception':type(e).__name__,'elapsed_ms':round((time.perf_counter()-t)*1000,2)}
            results.append(result)
            (OUT/'real-results.json').write_text(json.dumps({'config':table.model_dump(),'results':results,'upstream':records},ensure_ascii=False,indent=2))
            print(json.dumps({k:v for k,v in result.items() if k!='body'}),flush=True)
    c.portal.call(pool.aclose)
