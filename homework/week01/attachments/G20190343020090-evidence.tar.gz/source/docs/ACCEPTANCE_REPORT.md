# LLMGateway 功能验收报告

- 验收日期：2026-11-01
- 验收对象：Mini LLM Gateway（提交 `7c2be7c`，标签 `stage-7`）
- 验收范围：真实 DeepSeek 上游的端到端调用 + 六大核心功能 + 单元/端到端回归
- 结论：**通过**。真实上游 15 项检查全部通过（15/15），仓库全量测试 **178 passed**。

---

## 1. 验收环境与对象

| 项 | 值 |
|---|---|
| 网关版本 | `0.1.0`（commit `7c2be7c`） |
| 运行环境 | Linux 远端主机，Python 3.13，`uv` 管理依赖 |
| 网关地址 | `http://127.0.0.1:8006`（验收专用端口） |
| 上游 1 | `deepseek-v4-pro`，适配器 `openai_responses`，`https://api.deepseek.com/v1/responses` |
| 上游 2 | `deepseek-flash`，适配器 `anthropic_messages`，`https://api.deepseek.com/anthropic/v1/messages` |
| 限流验收路由 | `deepseek-flash-limited`（同一真实上游，`rpm=2`） |
| 重试验收路由 | `deepseek-v4-flaky`（本地故障注入 mock，529 × 2 后 200） |
| 密钥管理 | 仅通过环境变量 `DEEPSEEK_API_KEY` 注入进程；未写入任何文件，日志中无密钥（已 `grep` 校验） |

> 真实上游使用 DeepSeek 官方两个协议端点：Responses API 与 Anthropic 兼容 API，分别命中网关的两个适配器，因此「两个目标模型」覆盖了双协议链路。

---

## 2. 结论摘要

| # | 验收项 | 结果 | 证据 |
|---|---|---|---|
| 1 | `deepseek-flash` 调用链路（非流式 + 流式） | 通过 | A1 / A2 |
| 2 | `deepseek-v4-pro` 调用链路（非流式 + 流式） | 通过 | A3 / A4 |
| 3 | 流式输出（SSE 契约、`[DONE]`、TTFT、终态 usage） | 通过 | B1 / B2 |
| 4 | 结构化输出（原生 schema + L3 提示词兜底） | 通过 | C1 / C2 |
| 5 | 模板引用（创建、checksum、引用调用、干跑渲染） | 通过 | D1 / D2 / D3 |
| 6 | 可观测数据采集（计数、五分类 Token、6 个延迟直方图、日志字段） | 通过 | E1 / E2 |
| 7 | 自动重试（白名单重试、上限 3 次、最终成功） | 通过 | F1 |
| 8 | 限流保护（RPM 打满 429 + `Retry-After`，按模型隔离） | 通过 | G1 |
| 9 | 仓库全量回归 | 通过 | `178 passed, 1 warning in 3.55s` |

---

## 3. 两个目标模型的调用链路

### 3.1 复现步骤

```bash
export DEEPSEEK_API_KEY="<你的密钥>"        # PowerShell: $env:DEEPSEEK_API_KEY="<你的密钥>"
cd LLMGateway && uv sync

# 启动网关（默认读 config/gateway.yaml + config/routes.yaml）
uv run uvicorn gateway.main:app --host 127.0.0.1 --port 8000

# 非流式
curl -s http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-flash","messages":[{"role":"user","content":"用一句话介绍你自己"}]}'

# 流式
curl -N http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"用一句话说明什么是 API 网关"}],"stream":true}'
```

### 3.2 实际结果

| 用例 | 结果 | 实测输出 |
|---|---|---|
| A1 `deepseek-flash` 非流式 | 200 | `adapter=anthropic_messages`，文本非空，`usage={input:34, output:77, total:111, source:reported}` |
| A2 `deepseek-flash` 流式 | 200 | 10 个 delta 帧 + `[DONE]`，文本 `1 2 3 4 5`，TTFT `1383ms` |
| A3 `deepseek-v4-pro` 非流式 | 200 | `adapter=openai_responses`，`usage={input:87, output:126, reasoning:99, total:213, source:reported}` |
| A4 `deepseek-v4-pro` 流式 | 200 | 29 个 delta 帧 + `[DONE]`，TTFT `2229ms` |

**结论**：两条链路均正常返回、无报错、无异常中断；`reasoning_tokens` 被正确识别为 output 的子类（仅 pro 模型产生推理 token）。

---

## 4. 六大核心功能验证

### 4.1 流式输出

**验证步骤**

1. `stream=true` 请求 `/v1/chat`；
2. 校验响应中每个非空行要么是 `data:` 负载，要么是 SSE 注释心跳（`: heartbeat`）；
3. 校验最后一帧为 `data: [DONE]`；
4. 校验终态帧带 `usage` 与 `gateway.latency`。

**证据（B1 / B2）**

```
[PASS] B1 SSE 只含 data 行 | 异常行=[]
[PASS] B2 流式终态 usage + latency | usage={'prompt_tokens': 42, 'completion_tokens': 138, 'total_tokens': 180, 'source': 'reported'}
       latency={'total_ms': 1398.35, 'ttft_ms': 1379.69, 'upstream_ttft_ms': 1378.56, 'queue_wait_ms': 0.03, 'tpot_ms': 0.14}
```

`frames=10`（flash）/ `frames=29`（pro），两者均以 `[DONE]` 结束。TTFT 只统计真正拿到首个 `delta.content` 的请求，`tpot_ms` 以 output token 计算。

**结论**：符合 DESIGN §4.1 SSE 契约，可稳定复现。

### 4.2 结构化输出

**验证步骤**

1. pro（原生 schema）：`response_format.type=json_schema` + 兼容子集 schema；
2. flash（L3 兜底）：`response_format.type=json_object`（Anthropic 无 json_object 等价能力，走提示词修复）；
3. 检查响应中的 `structured` 与 `structured_mode`。

**证据（C1 / C2）**

```
[PASS] C1 pro 结构化（原生 schema） | HTTP 200 mode=native_schema structured={'city': '北京', 'temp_c': 18}
[PASS] C2 flash 结构化（L3 提示词兜底） | HTTP 200 mode=prompt_repair structured={'city': '广州', 'temp_c': 26}
```

**结论**：原生 schema 与提示词兜底两条路径均按设计产出结构化对象。

**注意事项**：DeepSeek 的 Anthropic 兼容端点不兑现 `output_config`，因此对 `deepseek-flash` 使用 `json_schema` 会得到 `502 OUTPUT_PARSE_FAILED`；该模型请使用 `json_object`（走 L3），或结构化请求走 `deepseek-v4-pro`。

### 4.3 模板引用

**验证步骤**

1. `POST /v1/prompts` 创建 `active` 模板（含两个必填变量）；
2. 核对返回 `checksum` 与本地 `sha256(content)` 一致；
3. `POST /v1/chat` 用 `prompt_ref` + `variables` 真实调用，检查终态回显 `{name, version, checksum}`；
4. `POST /v1/prompts/{name}/render` 干跑渲染（不产生上游费用）。

**证据（D1 / D2 / D3）**

```
[PASS] D1 模板创建 + checksum | HTTP 201 v=1 checksum=sha256:8b07012d4dc5b0d3e35addd7e40ab18509befb0b00b2a21da715ec75555ad7e3
[PASS] D2 模板引用真实调用 + 回显 | HTTP 200 prompt={'name': 'verify_prompt', 'version': 1, 'checksum': 'sha256:8b0701...'}
       text='“SSE”在不同领域有不同含义，最常见的是 **Server...'
[PASS] D3 干跑渲染（不调模型） | HTTP 200 rendered='请用英文回答：什么是网关'
```

**结论**：版本不可变、checksum 可复现、变量渲染与回显均正确。

### 4.4 可观测数据采集

**验证步骤**

1. 跑完上述请求后 `GET /metrics`；
2. 校验：请求计数带 `model/adapter/status` 标签；`llm_tokens_total` 覆盖 input/output/reasoning/cache_read/cache_write；6 个延迟直方图均已注册；
3. 校验 `llm.call` 日志字段（`usage`、`retry_count`、`rate_limited_by`、`status`、`error_code`）。

**证据（E1）**

```
llm_requests_total{adapter="anthropic_messages",model="deepseek-flash",status="ok"} 4.0
llm_requests_total{adapter="openai_responses",model="deepseek-v4-pro",status="ok"} 3.0
llm_requests_total{adapter="openai_responses",model="deepseek-v4-flaky",status="ok"} 1.0
llm_requests_total{adapter="anthropic_messages",model="deepseek-flash-limited",status="ok"} 2.0
llm_requests_total{adapter="anthropic_messages",model="deepseek-flash-limited",status="error"} 2.0
llm_tokens_total{model="deepseek-v4-pro",source="reported",type="input"} 331.0
llm_tokens_total{model="deepseek-v4-pro",source="reported",type="output"} 358.0
llm_tokens_total{model="deepseek-v4-pro",source="reported",type="reasoning"} 291.0
llm_tokens_total{model="deepseek-v4-pro",source="reported",type="cache_read"} 128.0
llm_tokens_total{model="deepseek-v4-pro",source="reported",type="cache_write"} 0.0
```

> `cache_read=128` 来自 DeepSeek 提示词缓存命中，网关按 `cache_read` 单独分类，不与 input 混报。

**证据（E2）**：`llm.call` 单行 JSON 日志（节选）

```json
{"request_id": "req_048fa9389b29e882531c4d52", "model": "deepseek-v4-flaky", "adapter": "openai_responses",
 "stream": false, "usage": {"input": 10, "output": 5, "source": "reported"},
 "retry_overhead_ms": 200.0, "retry_count": 2, "retry_skipped_reason": null,
 "rate_limited_by": null, "status": "ok", "error_code": null, "event": "llm.call"}
```

**结论**：计数、Token 分类、延迟直方图、决策字段齐备，且「指标全量、日志采样」符合 DESIGN §7。

### 4.5 自动重试机制

**验证步骤**

1. 用故障注入 mock（`127.0.0.1:8011`）对同一路由前两次返回 `529`（带 `Retry-After: 0.1`），第三次返回 200；
2. 发一次非流式请求；
3. 校验：最终 200、mock 收到 3 次、日志 `retry_count=2`、两条 `upstream.retry`。

仓库内可复现的确定性用例：`uv run pytest tests/e2e -v -k retry`。

**证据（F1）**

```
[PASS] F1 重试：529×2 后成功 | HTTP 200 text=重试后成功 mock_calls=3

{"request_id": "req_048fa9389b29e882531c4d52", "attempt": 1, "next_attempt": 2, "delay_ms": 100.0,
 "error_code": "UPSTREAM_UNAVAILABLE", "stream": false, "event": "upstream.retry", "level": "warning"}
{"request_id": "req_048fa9389b29e882531c4d52", "attempt": 2, "next_attempt": 3, "delay_ms": 100.0,
 "error_code": "UPSTREAM_UNAVAILABLE", "stream": false, "event": "upstream.retry", "level": "warning"}
```

**结论**：白名单重试生效，总尝试次数 3（首次 1 + 重试 2），退避时长受 `Retry-After` 与封顶值共同约束；400 类不重试、开流后不重试由 `tests/e2e/test_scenarios.py::test_retry_whitelist_and_no_retry_after_stream_started` 覆盖。

### 4.6 限流保护

**验证步骤**

1. 路由 `deepseek-flash-limited` 设 `rpm=2`；
2. 连续发 4 次请求；
3. 校验前 2 次 200，第 3、4 次 429 且 `code=RATE_LIMITED`；
4. 检查 429 响应头 `Retry-After` 与 `X-Request-Id`。

**证据（G1）**

```
[PASS] G1 rpm=2 限流：2 通过 + 2 拒绝 | statuses=[200, 200, 429, 429] codes=[None, None, 'RATE_LIMITED', 'RATE_LIMITED']

HTTP/1.1 429 Too Many Requests
retry-after: 8
x-request-id: req_114d011e07246b0a78fdb5d6
{"error":{"code":"RATE_LIMITED","message":"gateway rate limit exceeded (rpm) for model 'deepseek-flash-limited', retry later",
          "type":"rate_limited","request_id":"req_114d011e07246b0a78fdb5d6","retryable":true,
          "details":{"rate_limited_by":"rpm","model":"deepseek-flash-limited","remaining":0.75}}}
```

日志留痕：

```json
{"model": "deepseek-flash-limited", "rate_limited_by": "rpm", "status": "error",
 "error_code": "RATE_LIMITED", "event": "llm.call"}
```

**结论**：限流在开流前执行，超限直接返回 429 并给出 `Retry-After`；按模型独立计数（同刻 `deepseek-flash` 与 `deepseek-v4-pro` 请求未受影响）。

---

## 5. 回归测试

```text
远端裸库 reset 后：178 passed, 1 warning in 3.55s
```

覆盖范围：配置/错误码、双适配器契约、SSE 流式、结构化三档降级、提示词版本库、可观测指标、重试与限流、10 个端到端故障注入场景（含客户端断开）。

---

## 6. 已知限制与建议

1. `deepseek-flash`（Anthropic 兼容）不支持原生 `output_config`，结构化请用 `json_object`（L3）或改走 pro。
2. Fallback 上游切换、`/readyz`、`X-RateLimit-*` 信息头、Redis 限流、网关侧鉴权仍未实现（详见 `README.md` 已知限制）。
3. 重试可能带来重复计费（上游已生成但网络断开），日志以 `retry_count` 标注，v1 明确接受。
4. 压测数据来自 mock 上游，只反映网关自身开销；真实上游吞吐取决于厂商侧配额与模型耗时。

---

## 7. 可追溯性

- 代码与配置：`config/routes.yaml`（真实模型 id 与端点已校正）、`docs/stage-7.md`（阶段实证）
- 自动化证据：`tests/e2e/test_scenarios.py`（10 个场景）、`tests/resilience/`（21 个重试/限流用例）
- 本次验收所用临时脚本与 mock 不进入仓库，执行方式与参数已在上文各节给出；密钥仅通过环境变量注入。
