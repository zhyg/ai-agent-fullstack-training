# Mini LLM Gateway 实施计划（阶段划分）

> 配套文档：[`DESIGN.md`](./DESIGN.md)
> 本文件把设计文档 §11 的 M1–M6 里程碑细化为 8 个可执行阶段（Stage 0–7），每阶段给出：目标、范围、交付文件、关键实现要点、为后续阶段预留的约定、可测验收命令、DoD。

---

## 0. 划分原则

1. **每阶段结束都必须"能跑、能验"**：不是写一堆代码等最后联调，而是每阶段结束都能 `uvicorn` 起来并用 `curl` / `pytest` 看到结果。
2. **依赖单向**：抽象层 → 三大能力 → 横切（观测 / 韧性）。上层不许反向依赖。
3. **横切能力两段式落地**：观测和韧性贯穿所有阶段，采用「**先埋钩子占位，后补全实现**」，避免阶段 5/6 回来重构阶段 1/2 的代码。每个阶段都明确写出"为后续预留什么"。
4. **每个阶段打 git tag `stage-N`，并写一份实证文档 `docs/stage-N.md`**（做了什么、怎么验、贴实测输出），保证可复现。
5. **相对工作量用 T 恤尺码**（XS/S/M/L），不做虚假的精确天数估计。

---

## 1. 阶段总览

| Stage | 名称 | 核心交付 | 工作量 | 依赖 | 结束时可演示 |
|---|---|---|---|---|---|
| 0 | 地基 | 配置、错误码、日志、request_id、`/healthz` | S | — | 服务能起，错误响应体统一 |
| 1 | 抽象层 + 双适配器 | Canonical IR、Adapter Protocol、路由表、非流式调用 | L | 0 | 同一份 IR 打给两个模型都通 |
| 2 | 流式输出 | SSE 出口、事件映射、心跳、断开处理、TTFT 埋点 | L | 1 | `curl -N` 看逐块吐字 |
| 3 | 结构化输出 | schema lint、三档降级、拒答检测 | M | 1 | 给定 schema 必返回合法 JSON |
| 4 | 提示词版本管理 | SQLite 存储、版本引用、沙箱渲染、管理 API | M | 1 | 改提示词不用改代码 |
| 5 | 可观测性补全 | Token 五分类、6 个延迟指标、`/metrics` | M | 2,3,4 | `/metrics` 指标齐全 |
| 6 | 韧性 | 退避重试、按模型三道闸限流 | M | 1,2 | 上游 529 自动恢复；限流返回 429 |
| 7 | 端到端验收 | 故障注入、压测、13 条 checklist 核对 | S | 全部 | 设计文档验收清单全绿 |

**可裁剪路径**：如果只学核心抽象，做完 **Stage 0 → 1 → 2 → 7** 就够了；Stage 3/4 相对独立，可按需跳过或调换顺序；Stage 5/6 是工程化补强。

---

## 2. 依赖关系

```mermaid
flowchart LR
    S0[Stage 0<br/>地基] --> S1[Stage 1<br/>抽象层+适配器]
    S1 --> S2[Stage 2<br/>流式]
    S1 --> S3[Stage 3<br/>结构化]
    S1 --> S4[Stage 4<br/>提示词]
    S2 --> S5[Stage 5<br/>可观测性]
    S3 --> S5
    S4 --> S5
    S2 --> S6[Stage 6<br/>韧性]
    S1 --> S6
    S5 --> S7[Stage 7<br/>端到端验收]
    S6 --> S7
```

注意两条虚线依赖（文档里易漏，实际是硬约束）：

- **Stage 1 → Stage 5**：Stage 1 就要把 `CallContext` 和计时钩子埋好，否则 Stage 5 要回头改所有适配器签名。
- **Stage 2 → Stage 6**：Stage 2 必须暴露 `stream_started` 标志，否则 Stage 6 无法实现"开流后不重试"。

---

## 3. 各阶段详解

### Stage 0 · 地基

- **目标**：项目能启动，配置可校验，所有错误走统一响应体。
- **为什么在最前面**：错误码和 request_id 是后面每个阶段的公共底座，晚做会导致所有已写代码返工。
- **In scope**：`pyproject.toml`、配置加载、Pydantic Settings 校验、`GatewayError` + 异常处理器、`X-Request-Id` 中间件、JSON 结构化日志、`/healthz`。
- **Out of scope**：任何模型调用、适配器、路由表。

交付文件：

```
pyproject.toml                 # 依赖：fastapi uvicorn httpx pydantic-settings structlog prometheus-client jinja2 pytest respx
config/gateway.yaml            # 超时/重试/限流默认/日志采样
config/routes.yaml             # 路由表（本阶段只有骨架，不接真实上游）
src/gateway/main.py            # FastAPI app 装配
src/gateway/config.py          # Settings（启动即校验）
src/gateway/core/errors.py     # GatewayError + 18 个错误码 + 响应体
src/gateway/api/middlewares.py # request_id / access log
src/gateway/telemetry/logging.py
tests/test_errors.py
```

关键要点：

- 配置错值**启动即失败**，并报出字段路径（如 `retry.max_attempts must be >= 1`），不让错配置带病运行。
- 统一错误响应体固定四字段：`code` / `message` / `request_id` / `retryable`，`details` 按 `debug` 开关决定是否透出。
- request_id：客户端传则校验格式后透传，未传则服务端生成；响应头与日志一致。

验收：

```bash
pytest tests/ -q                                   # 全绿
uvicorn gateway.main:app --port 8000 &             # 能起
curl -s localhost:8000/healthz                     # → {"status":"ok"}
curl -s localhost:8000/v1/chat -d '{}'             # → 501 + 统一错误体
GW_LOG_LEVEL=debug uvicorn ... # 配置非法时启动失败并给出字段路径
```

**DoD**：错误码常量表与 `DESIGN.md` §8.1 完全一致；日志为单行 JSON；`/healthz` 不探上游。

---

### Stage 1 · 抽象层 + 双适配器（非流式）

- **目标**：统一抽象层落地，两个适配器能把同一份 `CanonicalRequest` 翻译成各自的协议，并把各自响应归一回来。
- **为什么在最前面**：后面所有能力都挂在 IR 上，这是全项目的地基，也是最该投入的一个阶段（工作量 L）。
- **In scope**：IR 定义、Adapter Protocol、路由表加载、两个适配器（仅非流式）、HTTP 连接池、`/v1/chat` 非流式分支、`/v1/models`。
- **Out of scope**：流式（Stage 2）、结构化（Stage 3）、提示词（Stage 4）、重试与限流（Stage 6）。

交付文件：

```
src/gateway/core/ir.py          # CanonicalRequest/Response/Event、TokenUsage、FinishReason
src/gateway/core/adapter.py     # ProviderAdapter Protocol + ModelCapabilities
src/gateway/core/router.py      # ModelRoute + Router(model → adapter)
src/gateway/core/invoker.py     # Gateway.invoke()：唯一调用入口
src/gateway/adapters/openai_responses.py
src/gateway/adapters/anthropic_messages.py
src/gateway/adapters/registry.py
src/gateway/httpclient/pool.py  # httpx.AsyncClient 池、超时、HTTP/2
src/gateway/api/routers/chat.py
tests/adapters/fixtures/        # 两家真实响应体样例
tests/adapters/test_contract.py # 契约测试（respx mock 上游）
```

关键要点：

- **统一走事件流**：`Gateway.invoke(req, ctx) -> AsyncIterator[CanonicalEvent]`，非流式就是"只产一个 `done` 事件"的流。这样 Stage 2 只需实现流式解析，管线不重写——**这是本阶段最重要的一个决定，能省掉 Stage 2 的大返工**。
- `build_headers()` 封装鉴权差异：OpenAI 用 `Authorization: Bearer`，Anthropic 用 `x-api-key` + `anthropic-version`。业务层只见 `route.api_key_env`。
- **Anthropic `max_tokens` 必填** → 未指定时用路由 `default_max_tokens` 兜底。
- 归一 `finish_reason`：`end_turn→STOP`、`max_tokens→LENGTH`、`refusal→CONTENT_FILTER`。
- **为 Stage 5 预留**：`CallContext` 必须携带 `request_id` / `t0` / `attempt` / `deadline`；`invoke` 内部打点 t0 与首字节时间。
- **为 Stage 6 预留**：`invoke` 内不写重试逻辑，但要把"一次上游调用"拆成可重试的单元 `adapter.call_once()`，并让异常统一收敛为 `GatewayError`（带 `retryable` 标记）。

验收：

```bash
pytest tests/adapters/test_contract.py -q
# 断言1：同一 CanonicalRequest → 两份不同 payload（键名逐项对照 DESIGN.md §3.3）
# 断言2：两家不同响应体 → 同一个 CanonicalResponse（text/usage/finish_reason 一致）
# 断言3：401/429/529/500 四类上游错误 → 归一为对应 GatewayError 且 retryable 标记正确
curl -s localhost:8000/v1/models                    # → 两个模型 + 能力声明
curl -s localhost:8000/v1/chat -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"hi"}]}'
```

**DoD**：新增第三个 mock 适配器（只实现 Protocol）时，`core/` 与 `api/` 下**零改动**——这条要写成一个真实的测试用例来证明，而不是口头保证。

---

### Stage 2 · 流式输出

- **目标**：`stream=true` 走 SSE 逐块返回，两家上游的事件差异被完全抹平。
- **为什么紧跟 Stage 1**：流式是网关最有价值的能力，也最暴露协议差异；早做能尽早验证 IR 抽象是否真的成立（抽象不成立的话这里就会崩）。
- **In scope**：SSE 解析器（两家）、事件映射、`CanonicalEvent` 流、对外 SSE 出口、心跳、客户端断开处理、TTFT 打点（骨架）。
- **Out of scope**：结构化（Stage 3）、重试（Stage 6，但必须预留钩子）。

交付文件：

```
src/gateway/core/events.py        # CanonicalEvent
src/gateway/core/sse.py           # SSE 帧解析（通用）+ 对外 SSE 编码
src/gateway/adapters/openai_responses.py    # + parse_sse()
src/gateway/adapters/anthropic_messages.py  # + parse_sse()
src/gateway/api/routers/sse.py    # StreamingResponse 装配
src/gateway/telemetry/timing.py   # TTFT / 首字节打点（骨架）
tests/test_stream.py
```

关键要点：

- 事件映射严格按 `DESIGN.md` §4.2 的表实现：`response.output_text.delta` ↔ `content_block_delta.delta.text` → `CanonicalEvent.delta`。
- 对外用 **Chat Completions 兼容 SSE**（`data-only` chunk + `data: [DONE]`），响应头必带 `X-Accel-Buffering: no`。
- **心跳 15s**（`: heartbeat` 注释行），静默 60s 判 `STREAM_INTERRUPTED`。Anthropic 自带 `ping`，OpenAI 侧靠网关定时器补齐。
- 客户端断开 → 捕获 `CancelledError`，`await resp.aclose()` 释放上游连接，日志标 `client_aborted=true`。
- **为 Stage 6 预留（硬约束）**：流对象必须维护 `stream_started: bool`（发出首个 `delta` 后置 True）和 `attempt: int`，Stage 6 的重试器据此决定"开流后不再重试"。
- **为 Stage 5 预留**：TTFT 只在真正拿到首个 delta 时打点；失败请求（零 token）不产生 TTFT，只记 `total_ms` + 错误码。

验收：

```bash
curl -N -s localhost:8000/v1/chat -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"讲个故事"}],"stream":true}'
# 期望：逐块 data: 帧 → 终态 chunk 带 usage 与 gateway.ttft_ms → data: [DONE]
pytest tests/test_stream.py -q
# 断言：两个 mock 上游分别吐自家事件格式，对外 SSE 字节序列逐帧一致
# 断言：中途 kill 客户端 → 上游连接被关闭（respx 侧断言 request closed）
```

**DoD**：两家上游的 SSE 输出在客户端视角**完全相同**（同一套断言用例跑两遍）。

---

### Stage 3 · 结构化输出

- **目标**：`response_format` 约束下返回合法 JSON，且 schema 不合规在入口就被拦下。
- **为什么在 Stage 2 之后**：依赖 Stage 1 的 IR 字段；与 Stage 2 有交集（流式 + 结构化的冲突），需要 Stage 2 的流对象已定型才好规定 `structured` 只在终态出现。
- **In scope**：schema lint、三档降级（L1/L2/L3）、拒答检测、流式与结构化的冲突策略。
- **Out of scope**：提示词模板预置 schema（Stage 4 的联动字段）。

交付文件：

```
src/gateway/structured/lint.py     # 兼容子集校验（DESIGN.md §5.3 六条规则）
src/gateway/structured/enforce.py  # L1/L2/L3 降级编排 + jsonschema 校验 + repair
src/gateway/structured/translate.py# ResponseFormat → 各家方言
tests/structured/test_lint.py
tests/structured/test_enforce.py
```

关键要点：

- 对外契约沿用 OpenAI 风格 `{type, json_schema:{name, schema, strict}}`，由 `translate.py` 翻译成：
  - OpenAI → `text.format = {type:"json_schema", name, schema, strict:true}`
  - Anthropic → `output_config.format = {type:"json_schema", json_schema:{...}}`（**GA 写法，不用已废弃的 beta `response_format`**）
- lint 六条规则（`$ref` 禁用、`additionalProperties:false` 强制、字段全进 required、`oneOf` 禁用、`pattern` 禁用、深度/规模上限）→ 不合规返回 `400 SCHEMA_INCOMPATIBLE`，把上游 500 变成客户端 400。
- **拒答检测**：OpenAI strict 模式下拒答落在 `refusal` 字段，适配器必须检查并映射 `CONTENT_FILTERED`，否则解析拿到空串。
- **流式冲突策略**：`strict=true` 时默认强制 `stream=false` 并在响应给 `note`；显式要求流式时，`structured` 只在终态 chunk 出现，中间不发半截 JSON。
- Anthropic 首次使用新 schema 有一次 grammar 编译延迟（缓存 24h），文档与日志标注，不当成故障。

验收：

```bash
pytest tests/structured/ -q
# 断言：合规 schema × 100 次 mock 调用 → json.loads 全部成功
# 断言：带 $ref / 缺 additionalProperties / 用 oneOf 的 schema → 400 SCHEMA_INCOMPATIBLE
# 断言：上游返回 refusal → CONTENT_FILTERED，不是 OUTPUT_PARSE_FAILED
# 断言：strict + stream=true → 被强制为非流式（或被允许但 structured 只在终态）
```

**DoD**：响应体回显 `structured_mode`，三种档位各有一个回归用例。

---

### Stage 4 · 提示词版本管理

- **目标**：模板存储、变量替换、版本引用，改提示词不改代码。
- **为什么在 Stage 3 之后**：它是一条相对独立的支线（纯存储 + 渲染），放在主链路（抽象层/流式）稳定之后做，不阻塞核心；但与 Stage 3 有 schema 联动字段。
- **In scope**：SQLite 存储、`PromptStore` 抽象、版本引用解析、Jinja2 沙箱渲染、管理 API、与 `messages` 的合并规则。
- **Out of scope**：多租户权限、模板 diff UI。

交付文件：

```
src/gateway/prompt/models.py     # PromptTemplate 表结构
src/gateway/prompt/store.py      # PromptStore Protocol + SQLiteStore
src/gateway/prompt/resolver.py   # 版本引用解析 + 变量校验 + 渲染 + LRU/TTL 缓存
src/gateway/api/routers/prompts.py
tests/prompt/test_resolver.py
```

关键要点：

- **已发布版本不可变**：改动必须生成新版本；日志存 `checksum`，线上可 100% 复现当时提示词。
- 四种引用写法：`latest` / `active` / 精确版本号 / `name@3`；解析不到 → `404 PROMPT_NOT_FOUND` 且回显可用版本列表。
- `SandboxedEnvironment` + `autoescape=False`（禁止模板访问 Python 内部对象）。
- 必填变量缺失 → `400 MISSING_VARIABLE`；未声明却传入的变量忽略并告警。
- **合并规则**：`prompt_ref` 渲染出 base messages，请求里的 `messages` 追加在后（支持多轮）；两者都不给 → `400 INVALID_REQUEST`。
- 模板可预置 `response_schema`，与 Stage 3 联动。
- 缓存 LRU(256) + TTL 60s，`active` 指针变更时主动失效。

验收：

```bash
pytest tests/prompt/ -q
curl -X POST localhost:8000/v1/prompts -d '{...}'          # 创建 v1
curl -X POST localhost:8000/v1/prompts -d '{...}'          # 同 name → v2
curl -X POST localhost:8000/v1/prompts/summarize/2/activate
curl -X POST localhost:8000/v1/prompts/summarize/render -d '{"variables":{...}}'   # 干跑，不调模型
# 断言：修改已发布版本内容 → 拒绝（不变性）
# 断言：日志 checksum 与模板内容 sha256 一致
```

**DoD**：日志里的 `prompt.checksum` 能反查出确切模板内容（写一个反向校验脚本）。

---

### Stage 5 · 可观测性补全

- **目标**：Token 分类统计与延迟指标完整可用，`/metrics` 可采集。
- **为什么放在能力之后**：指标的定义依赖能力形态（比如 TTFT 只有在流式存在时才有意义），但**埋点在 Stage 1/2 已占位**，本阶段只做补全与导出，不改业务代码结构。
- **In scope**：Token 五分类映射、`reported/estimated` 标记、6 个延迟指标、Prometheus 导出、日志字段补全与采样。

交付文件：

```
src/gateway/telemetry/metrics.py   # Counter/Histogram 定义
src/gateway/telemetry/usage.py     # 五分类映射 + 估算兜底
src/gateway/telemetry/timing.py    # 补全 6 个延迟指标
src/gateway/api/routers/metrics.py
tests/telemetry/test_usage.py
```

关键要点：

- Token 分类：`input` / `output` / `reasoning` / `cache_read` / `cache_write`，按 `DESIGN.md` §7.1 的字段来源映射（OpenAI 的 `input_tokens_details.cached_tokens`、Anthropic 的 `cache_read_input_tokens` 与 `cache_creation_input_tokens`）。
- **上报优先、估算兜底**：上游给了标 `reported`，中断/缺失用 `len(text)/4` 标 `estimated`，指标带 `source` 标签，**绝不混报**。
- 延迟：`ttft_ms` / `upstream_ttft_ms` / `queue_wait_ms` / `retry_overhead_ms` / `total_ms` / `tpot_ms`，直方图分桶 `[50,100,250,500,1000,2000,5000,10000,30000]`。
- 采样：错误与重试 100% 记录，成功按 `log_sample_rate`（默认 0.1）采样，但**计数器指标全量**。
- 日志脱敏：`messages` 正文默认只落长度与 hash，`debug` 开关下才落原文。

验收：

```bash
curl -s localhost:8000/metrics | grep llm_
# 期望：llm_tokens_total{model,type,source} / llm_request_duration_ms 直方图 / llm_ttft_ms 直方图
pytest tests/telemetry/ -q
# 断言：流式中断仍有用量入账且 source="estimated"
# 断言：零 token 的失败请求不产生 TTFT 样本
```

**DoD**：`/metrics` 覆盖 `DESIGN.md` §7 全部指标；每个指标有一条回归用例。

---

### Stage 6 · 韧性（重试 + 限流）

- **目标**：统一错误码 + 指数退避重试 + 按模型独立限流全部生效。
- **为什么在最后**：重试与限流是"包裹"在调用管线外的策略层，需要 Stage 1 的 `adapter.call_once()` 单元和 Stage 2 的 `stream_started` 标志都已就位，否则要回头改核心。
- **In scope**：可重试判定白名单、full jitter 退避、`Retry-After`、开流不重试、三道闸限流（RPM/TPM/并发）、Redis 接口预留。

交付文件：

```
src/gateway/resilience/retry.py      # 退避 + 可重试判定 + fallback 切换
src/gateway/resilience/ratelimit.py  # RateLimiter Protocol + MemoryLimiter(+RedisLimiter 接口)
src/gateway/resilience/lua/          # Redis 原子扣减脚本（接口预留，可后补）
tests/resilience/test_retry.py
tests/resilience/test_ratelimit.py
```

关键要点：

- `max_attempts=3`（总尝试）、`base=0.5s`、`multiplier=2`、`max_delay=8s`、**full jitter**（`uniform(0, min(max_delay, base*2^(n-1)))`）、总预算 120s。
- 可重试**白名单**：连接错误/超时、HTTP `408/409/429/500/502/503/504/529`，以及对应网关错误码；400 类一律不重试。
- **尊重 `Retry-After`**（上限 `max_delay`）。
- **开流不重试**（依赖 Stage 2 的 `stream_started`）：已吐出首个 delta 后失败 → 发 `error` 事件终止流，日志标 `retry_skipped_reason=stream_started`。
- 限流三道闸：RPM 令牌桶、TPM 令牌桶（请求前按预估预扣、响应后按实测校正）、并发信号量（排队超 2s → 429）。**每模型独立**，flash 打满不影响 pro。
- **网关自己的 429 不触发上游重试**，否则限流形同虚设。
- 单机用内存桶（默认零依赖），多实例切 Redis Lua；两者实现同一 `RateLimiter` Protocol。

验收：

```bash
pytest tests/resilience/ -q
# 断言：mock 上游连返 2 次 529 第 3 次成功 → 最终 200，retry_count=2
# 断言：mock 上游返 400 → 不重试，attempt=1
# 断言：流式已吐 delta 后上游断 → 不重试，客户端收到 error 事件
# 压测：flash 打满 RPM → 429 + Retry-After；同时 pro 请求正常 200
```

**DoD**：重试与限流的每一次决策都在日志中有据可查（`retry_count` / `retry_skipped_reason` / `rate_limited_by`）。

---

### Stage 7 · 端到端验收与固化

- **目标**：对照 `DESIGN.md` §13 的 13 条验收清单逐条核对，补齐故障注入测试与使用文档。
- **In scope**：e2e 测试、故障注入、压测脚本、`README.md`、`docs/stage-*.md` 汇总、清单核对。
- **Out of scope**：新增功能。

交付文件：

```
tests/e2e/test_scenarios.py     # 8 个端到端场景
tests/e2e/fault_injection.py    # 超时 / 529 / 流中断 / 客户端断开 / schema 违规
scripts/bench.py                # 并发压测（验证限流与 TTFT）
README.md                       # 启动、配置、最小示例
docs/stage-0..6.md              # 各阶段实证文档汇总
```

验收（对照 `DESIGN.md` §13）：

```bash
pytest tests/ -q                      # 全绿
python scripts/bench.py --model deepseek-v4-flash --concurrency 100
# 期望：超限请求 429，未超限请求 P95 TTFT 在预期内
```

**DoD**：13 条 checklist 全绿，且每条都能指出对应的测试用例文件名。

---

## 4. 接口冻结清单（阶段间契约）

前一阶段必须给后一阶段留好的东西，写死在这里，防止返工：

| 产出阶段 | 冻结的接口 / 约定 | 被谁消费 | 违反后果 |
|---|---|---|---|
| 1 | `Gateway.invoke(req, ctx) -> AsyncIterator[CanonicalEvent]`（非流式 = 单 `done` 事件） | 2, 5, 6 | Stage 2 要重写整条管线 |
| 1 | `adapter.call_once()` 为可重试的最小单元，异常统一收敛为 `GatewayError(retryable=...)` | 6 | 重试无法插入 |
| 1 | `CallContext{request_id, t0, attempt, deadline}` | 5, 6 | Stage 5 要改所有适配器签名 |
| 1 | `TokenUsage` 五分类 + `source` 字段 | 5 | 指标缺少分类维度 |
| 2 | 流对象暴露 `stream_started: bool` 与 `attempt: int` | 6 | 无法判定"开流后不重试" |
| 2 | TTFT 打点钩子（拿到首个 delta 时触发） | 5 | 指标失真或需重构流逻辑 |
| 3 | `ResponseFormat` 对外契约为 OpenAI 风格 | 4 | 模板预置 schema 无法联动 |
| 4 | 渲染结果为 `list[CanonicalMessage]` | 1 | 无法并入主链路 |

---

## 5. 风险与回滚

| 阶段 | 主要风险 | 缓解 | 回滚点 |
|---|---|---|---|
| 1 | IR 抽象不成立，两家语义无法归一 | 先做最小字段集（messages/system/stream/usage），跑通后再扩；遇到无法归一的语义，宁可在 IR 显式加字段，也不在适配器里塞特判 | `stage-0` |
| 2 | 上游 SSE 格式与文档不符 | 先用真实响应体做 fixture（而非手写假数据），解析器对未知事件类型静默忽略 | `stage-1` |
| 3 | schema 子集限制过严导致业务用不了 | lint 规则可配置，先警告后强制（灰度：`lint_mode: warn`） | `stage-2` |
| 4 | 模板渲染成为热点（每次请求查库） | LRU + TTL 缓存，渲染耗时进指标 | `stage-1` |
| 5 | 估算用量与真实计费偏差 | `source` 标签区分，绝不混报 | `stage-4` |
| 6 | 重试放大流量、掩盖上游故障 | 可重试白名单 + 总预算 + 重试指标告警 | `stage-5` |

---

## 6. 实证文档模板（`docs/stage-N.md`）

每阶段结束必须产出，格式固定：

```markdown
# Stage N · <名称>

## 做了什么
- 文件清单 + 关键改动

## 怎么验
- 命令（可复制直接跑）

## 实测输出
- 贴真实 stdout，不加工

## 与设计文档的偏差
- 有偏差就写明原因；无偏差写"无"

## 下一步
- 下一阶段的入口
```

---

## 7. tag 与分支约定

- 分支：`main` 只接受已验收的阶段合并；开发中用 `stage-N/<简述>`。
- 每阶段验收通过后打 tag：`git tag -a stage-N -m "..."`，并写 `docs/stage-N.md`。
- commit 信息前缀：`feat:` / `fix:` / `refactor:` / `docs:` / `test:` / `chore:`，正文说明"为什么"。
