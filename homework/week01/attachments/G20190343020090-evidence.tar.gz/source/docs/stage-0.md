# Stage 0 · 地基

## 做了什么

- `pyproject.toml`：项目更名为 `llm-gateway`，包目录 `src/gateway`；新增 pydantic-settings / structlog / prometheus-client / jinja2，dev 组新增 respx。
- `config/gateway.yaml`：debug、server、logging、timeout、retry、limits 默认值。
- `config/routes.yaml`：两个模型（`deepseek-v4-pro` → openai_responses、`deepseek-v4-flash` → anthropic_messages）的路由骨架。
- `src/gateway/config.py`：Pydantic Settings 嵌套模型，YAML 最低优先级、`GW_*` 环境变量可覆盖；非法配置给出 `retry.max_attempts` 这类字段路径。
- `src/gateway/core/errors.py`：18 个错误码常量表（与 DESIGN.md §8.1 完全一致）、`GatewayError`、统一响应体、GatewayError / 参数校验 / HTTPException / 兜底异常处理器。
- `src/gateway/api/middlewares.py`：`X-Request-Id` 生成（`req_<24 hex>`）与校验透传、请求级结构化日志、异常路径日志。
- `src/gateway/telemetry/logging.py`：单行 JSON 日志，时间戳固定为北京时间（+08:00）。
- `src/gateway/main.py`：应用装配、`/healthz`、`/v1/chat` 占位（501 统一错误体）、启动即校验配置。
- `tests/test_errors.py`：17 个用例覆盖错误码表、响应体形状、request_id、配置校验、日志格式。

## 怎么验

```bash
cd /root/LLMGateway && uv sync && uv run pytest -q
uv run uvicorn gateway.main:app --port 8000 &
curl -s localhost:8000/healthz
curl -s -X POST localhost:8000/v1/chat -H 'content-type: application/json' -d '{}'
GW_RETRY__MAX_ATTEMPTS=0 uv run uvicorn gateway.main:app --port 8001
```

## 实测输出

```
17 passed
```

```http
HTTP/1.1 200 OK
x-request-id: req_a2b112fdd65010bba6c4230b
{"status":"ok"}

HTTP/1.1 501 Not Implemented
{"error":{"code":"NOT_IMPLEMENTED","message":"chat endpoint is not implemented yet","type":"not_implemented","request_id":"req_748d4cf7a04e1e3dfaf7deea","retryable":false}}
```

```
invalid gateway configuration:
retry.max_attempts: Input should be greater than or equal to 1
```

## 与设计文档的偏差

- 新增了 `NOT_IMPLEMENTED`（501）作为 Stage 0 的 `/v1/chat` 占位码，不属于 §8.1 的 18 个对外错误码，Stage 1 接入真实路由后移除。
- `/readyz` 未实现：本阶段不探上游，留到后续阶段补。

## 下一步

Stage 1：Canonical IR、Adapter Protocol、路由表加载、两个适配器（非流式）、`/v1/chat` 与 `/v1/models`。
