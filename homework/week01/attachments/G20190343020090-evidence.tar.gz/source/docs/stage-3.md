# Stage 3 · 结构化输出

## 做了什么

新增/修改文件：

| 文件 | 改动 |
|---|---|
| `src/gateway/structured/lint.py` | 新增：DESIGN §5.3 六条兼容子集规则的 lint + `ensure_compatible()`（400 SCHEMA_INCOMPATIBLE） |
| `src/gateway/structured/translate.py` | 新增：`ResponseFormat` → OpenAI `text.format` / Anthropic `output_config.format`，以及 L3 提示词说明 |
| `src/gateway/structured/enforce.py` | 新增：L1/L2/L3 档位选择、提示词注入、修复请求构造、剥围栏 + `json.loads` + jsonschema 校验 |
| `src/gateway/core/invoker.py` | `prepare()` 接入 lint/档位与请求改写；`complete()` 增加结构化解析与 L3 修复循环（≤2 次）；`stream()` 只在终态挂 `structured` |
| `src/gateway/core/ir.py` | `CanonicalResponse` 新增 `structured_mode` / `note`，`to_dict()` 回显 |
| `src/gateway/core/events.py` | `CanonicalEvent` 新增 `structured_mode` |
| `src/gateway/adapters/openai_responses.py` | 方言翻译改为复用 `translate.openai_text_format()`（行为不变） |
| `src/gateway/adapters/anthropic_messages.py` | 方言翻译改为复用 `translate.anthropic_output_config()`；`json_object` 返回 None 交由 L3 |
| `src/gateway/api/routers/chat.py` | `json_schema` 必填 `name`；strict + `stream=true` 默认强制非流式并回显 `note`；新增 `structured_stream` 开关 |
| `src/gateway/api/routers/sse.py` | 终态 chunk 追加 `structured` 与 `structured_mode`（中间帧绝不携带半截 JSON） |
| `src/gateway/config.py` + `config/gateway.yaml` | 新增 `structured.max_repair_retries=2`（DESIGN §5.2 上限） |
| `pyproject.toml` / `uv.lock` | 新增依赖 `jsonschema>=4.26.0` |
| `tests/structured/test_lint.py` | 新增 17 个用例（六条规则逐条、深度/规模上限、错误明细） |
| `tests/structured/test_enforce.py` | 新增 34 个用例（档位、方言、解析、修复、拒答、API 入口、流式终态） |

关键实现点：

- **lint 前移**：`json_schema` 在 `Gateway.prepare()`（即发 200 之前）完成校验，不合规返回 `400 SCHEMA_INCOMPATIBLE`，把上游 500 变成客户端 400；`details.issues` 逐条给出 JSON 路径与规则名（仅 debug 模式透出）。
- **三档降级由能力声明驱动**，不是按厂商硬编码：`supports_json_schema` → L1；`supports_json_object` → L2；都没有 → L3（清空 `response_format`、把 schema 写进 system 提示）。
- **L3 修复闭环**：剥离 ```json 围栏 → `json.loads` → jsonschema 校验 → 失败把「上一次输出 + 错误原因」作为 assistant/user 消息回灌，额外重试 ≤2 次（独立于 Stage 6 的网络重试预算）。
- **拒答优先**：OpenAI strict 的 `refusal` 在适配器归一为 `FinishReason.CONTENT_FILTER`，结构化链路第一时间转 `400 CONTENT_FILTERED`，不会误报 `OUTPUT_PARSE_FAILED`。
- **流式 + 结构化**：`strict=true` 且请求带 `stream=true` 时默认强制非流式并回显 `note`；显式 `structured_stream=true` 才允许流式，文本照常逐块吐出，`structured` 只在终态 chunk 出现；开流后不做修复重试。
- **响应回显**：非流式 `structured` / `structured_mode`；流式只出现在终态 chunk。三种档位都有回归用例。

## 怎么验

```bash
# 单元 / 契约测试（远程）
cd /root/LLMGateway && /root/.local/bin/uv run pytest tests/structured -v --durations=8

# 全量回归
cd /root/LLMGateway && /root/.local/bin/uv run pytest

# 运行时验收：本地 mock 上游（JSON / 带 JSON 文本的 SSE）+ 网关 8003 端口
tr -d '\r' < /tmp/run_accept_stage3.sh | bash
```

## 实测输出

```
tests/structured/test_enforce.py ..................................      [ 66%]
tests/structured/test_lint.py .................                          [100%]
51 passed, 1 warning in 0.87s
```

全量：`101 passed`（Stage 2 为 50，本阶段新增 51）。

运行时验收（Gateway 8003 + mock 上游 8010）：

```text
=== 1) L1 native_schema：pro + json_schema（非流式） ===
{"structured": {"title": "网关超时", "priority": 2}, "structured_mode": "native_schema"}

=== 2) L3 prompt_repair：flash + json_object（Anthropic 无原生能力） ===
{"structured": {"title": "网关超时", "priority": 2}, "structured_mode": "prompt_repair"}

=== 3) 不合规 schema（$ref）→ 400 SCHEMA_INCOMPATIBLE ===
HTTP 400
{"code": "SCHEMA_INCOMPATIBLE", "rules": ["no_ref"]}

=== 4) strict + stream=true 默认强制非流式（带 note） ===
{"note": "structured output forced non-streaming; set structured_stream=true to stream text with structured only in the final chunk", "structured_mode": "native_schema"}

=== 5) stream + structured_stream=true：structured 只在终态 chunk ===
{"delta_chunks": 3, "chunks_with_structured": 1, "structured": {"title": "网关超时", "priority": 2}, "structured_mode": "native_schema"}

=== 6) stream + structured_stream=true（flash json_object → L3 终态结构化） ===
{"chunks_with_structured": 1, "structured": {"title": "网关超时", "priority": 2}, "structured_mode": "prompt_repair"}

=== 7) 上游收到的结构化字段（L1 带 text.format，L3 仅 system 提示） ===
PAYLOAD {"path": "/v1/messages", "stream": false, "has_output_config": false, "text": null, "system_head": "你必须只输出一个合法的 JSON 对象，不要输出任何解释..."}
PAYLOAD {"path": "/v1/responses", "stream": false, "has_output_config": false, "text": {"format": {"type": "json_schema", "name": "issue_report", "schema": {...}, "strict": true}}, "system_head": ""}
PAYLOAD {"path": "/v1/responses", "stream": true, "has_output_config": false, "text": {"format": {"type": "json_schema", "name": "issue_report", "schema": {...}, "strict": true}}, "system_head": ""}
PAYLOAD {"path": "/v1/messages", "stream": true, "has_output_config": false, "text": null, "system_head": "你必须只输出一个合法的 JSON 对象，不要输出任何解释..."}
```

## 与设计文档的偏差

1. **新增 `structured_stream` 请求字段**：DESIGN §5.4 一方面规定 strict 默认强制非流式，另一方面要求「客户端显式要求流式时」允许流式。原始 `stream=true` 无法区分「默认」与「显式」，因此增加布尔开关：只有 `structured_stream=true` 才走流式，否则强制非流式并在响应里回显 `note`。
2. **L3 schema 提示词路径**：两家真实适配器都声明 `supports_json_schema=true`（Anthropic 走 `output_config.format`），所以 L3 的 schema 分支只在能力声明为「无原生 schema」的适配器上触发；测试用 `LegacyAnthropicAdapter` 子类覆盖这条路径，证明降级由能力声明驱动。
3. **Anthropic `output_config.format` 不携带 `strict`**：按 DESIGN §5.1/§3.3 的 GA 写法（`json_schema{name,schema}`），`strict` 只影响网关侧 `structured_stream` 策略。
4. **深度上限按 object 嵌套计数**：标量叶子不额外计一层；`MAX_DEPTH=5` 时 5 层嵌套 object 通过、第 6 层报 `max_depth`。
5. **流式下 L3 不修复**：开流后重试违反「已发出字节不可撤回」的约束，终态解析失败直接发 `OUTPUT_PARSE_FAILED` 错误帧，并在消息里说明「streaming mode does not perform repair retries」。
6. **`json_schema.name` 改为必填**：DESIGN §5.1 明确「json_schema 必填 name」，Stage 1 仅透传，本阶段在入口补校验（400 INVALID_REQUEST）。

## 下一步

Stage 4 · 提示词版本管理：SQLite 存储 + 版本引用解析 + Jinja2 沙箱渲染 + 管理 API，并与本阶段的 `response_schema` 联动。
