# Stage 2 · 流式输出

## 做了什么

新增/修改文件：

| 文件 | 改动 |
|---|---|
| `src/gateway/core/events.py` | 新增：`CanonicalEvent` 从 `ir.py` 迁出，成为独立的事件模型 |
| `src/gateway/core/sse.py` | 新增：通用 SSE 帧解析（按字节缓冲、只在完整行做 UTF-8 解码）+ 对外 `data:` 编码 / 心跳 / `[DONE]` |
| `src/gateway/adapters/openai_responses.py` | 新增 `parse_sse()`：`response.created → start`、`output_text.delta → delta`、`completed/incomplete → done`、`failed/error → error`、`ping → ping`；未知事件静默忽略 |
| `src/gateway/adapters/anthropic_messages.py` | 新增 `parse_sse()`：`message_start → start`（带 input_tokens）、`text_delta → delta`、`message_delta` 累计 usage/stop_reason、`message_stop → done`、`error/ping` 映射 |
| `src/gateway/core/invoker.py` | 新增 `prepare()`（预检）+ `Gateway.stream()`；`invoke()` 对流式请求转调 `stream()`；异常统一收敛为 `GatewayError`，并保证 `finally: response.aclose()` |
| `src/gateway/httpclient/pool.py` | 新增 `stream()`：`build_request + send(stream=True)`，超时按路由配置 |
| `src/gateway/api/routers/sse.py` | 新增：对外 Chat Completions 兼容 SSE、心跳、静默超时、客户端断开、错误帧 |
| `src/gateway/api/routers/chat.py` | `stream=true` 分支改为先预检再返回 `StreamingResponse`；移除 Stage 1 的 501 占位 |
| `src/gateway/telemetry/timing.py` | 新增：TTFT / total / TPOT 打点骨架 |
| `src/gateway/config.py` + `config/gateway.yaml` | 新增 `stream.heartbeat_s=15` 与 `stream.silence_timeout_s=60` |
| `src/gateway/core/errors.py` | 移除 Stage 0 的 `NOT_IMPLEMENTED` 占位码（Stage 1 承诺的收尾） |
| `tests/test_stream.py` | 新增 13 个用例 |
| `tests/adapters/fixtures/openai_stream.sse` / `anthropic_stream.sse` | 两家上游事件流 fixtures |

关键实现点：

- **事件映射严格按 DESIGN.md §4.2**；未识别事件静默忽略，上游新增事件不会打断旧网关。
- **对外 SSE**：`data-only` chunk + `data: [DONE]`，响应头含 `X-Accel-Buffering: no`（禁用代理缓冲）。
- **首包不缓冲**：收到首个 delta 立即 flush，TTFT 在真正拿到首个 delta 时打点。
- **心跳用后台任务 + 队列，而不是 `asyncio.wait_for(anext(...))`**：后者超时会取消上游流，导致静默超时时连接被提前掐断。
- **静默 60s** → 输出 `STREAM_INTERRUPTED` 错误帧并关闭流。
- **客户端断开**：捕获 `CancelledError` / `GeneratorExit`，取消上游任务 → `Gateway.stream` 的 `finally` 调用 `response.aclose()`；日志标 `client_aborted=true`，`ctx.client_aborted=True`。
- **为 Stage 6 预留**：`ctx.stream_started` 在首个 delta 置 True，`ctx.attempt` 沿用 Stage 1 的 `CallContext`。
- **为 Stage 5 预留**：`StreamTiming` 已产出 `ttft_ms` / `total_ms` / `tpot_ms`，终态 chunk 的 `gateway` 字段直接可测。
- **预检前置**：路由解析、鉴权（`api_key_env` 缺失）、payload 构建都在返回 `StreamingResponse` 之前完成，因此未知模型 / 缺密钥仍返回 4xx JSON，而不是发出 200 后断流。

## 怎么验

```bash
# 单元 / 契约测试（远程）
cd /root/LLMGateway && /root/.local/bin/uv run pytest tests/test_stream.py -v --durations=8

# 全量回归
cd /root/LLMGateway && /root/.local/bin/uv run pytest -q

# 运行时验收：本地 mock 上游（两套 SSE 格式）+ 网关 8002 端口
tr -d '\r' < /tmp/run_accept.sh | bash
```

## 实测输出

```
tests/test_stream.py .............                                       [100%]
============================= slowest 8 durations ==============================
0.84s call     tests/test_stream.py::test_api_stream_emits_heartbeat_when_upstream_is_slow
0.11s call     tests/test_stream.py::test_api_stream_silence_timeout_emits_interrupted_error
0.06s call     tests/test_stream.py::test_api_stream_and_non_stream_share_client_semantics
0.04s call     tests/test_stream.py::test_api_stream_returns_openai_compatible_sse
0.03s call     tests/test_stream.py::test_api_stream_preflight_missing_key_returns_json_401
0.01s call     tests/test_stream.py::test_anthropic_stream_event_mapping
======================== 13 passed, 1 warning in 1.49s =========================
```

全量：`50 passed`（Stage 1 为 38，新增 13、移除 1 个 501 占位用例）。

运行时验收（`curl -N`，mock 上游每 0.35s 吐一帧）：

```text
=== 1) /v1/chat stream=true -> openai_responses（逐块 data 帧） ===
data: {"id":"req_fb75f7812794786ef0d14444","object":"chat.completion.chunk","model":"deepseek-v4-pro","choices":[{"index":0,"delta":{"content":"从"},"finish_reason":null}],"usage":null}

data: {"id":"req_fb75f7812794786ef0d14444",...,"delta":{"content":"前"}...}

data: {"id":"req_fb75f7812794786ef0d14444",...,"delta":{"content":"有座山。"}...}

data: {"id":"req_fb75f7812794786ef0d14444","object":"chat.completion.chunk","model":"deepseek-v4-pro","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":12,"completion_tokens":8,"total_tokens":20,"source":"reported"},"gateway":{"total_ms":1408.48,"ttft_ms":356.16,"tpot_ms":150.33}}

data: [DONE]

=== 2) /v1/chat stream=true -> anthropic_messages（同一套对外 SSE） ===
: heartbeat

data: {"id":"req_3c7bbc4db1381385c65b783a",...,"delta":{"content":"从"}...}
data: {"id":"req_3c7bbc4db1381385c65b783a",...,"delta":{"content":"前"}...}
data: {"id":"req_3c7bbc4db1381385c65b783a",...,"delta":{"content":"有座山。"}...}
data: {"id":"req_3c7bbc4db1381385c65b783a","object":"chat.completion.chunk","model":"deepseek-v4-flash","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":12,"completion_tokens":8,"total_tokens":20,"source":"reported"},"gateway":{"total_ms":2462.95,"ttft_ms":1058.89,"tpot_ms":200.58}}

data: [DONE]

=== 3) 响应头（SSE 契约） ===
HTTP/1.1 200 OK
cache-control: no-cache
connection: keep-alive
x-accel-buffering: no
x-request-id: req_0c27e831c503f6d78ce25910
content-type: text/event-stream; charset=utf-8
```

注：第 2 组开头的 `: heartbeat` 来自 Anthropic 的 `ping` 事件 → 网关统一转成注释行心跳。

## 与设计文档的偏差

1. **`CanonicalEvent` 位置**：DESIGN §3.1 示意写在 `core/ir.py`，实施计划交付清单要求 `core/events.py`；按计划拆出，`ir.py` 只保留请求/响应与 `CallContext`。
2. **心跳实现方式**：设计只要求「网关自维护定时器」；实现采用「后台泵任务 + 有界队列（maxsize=32）+ 等待超时」组合，避免 `wait_for` 取消上游流，同时队列上限提供背压。
3. **流中错误帧格式**：设计写「发 `error` 事件后关闭」，未规定具体 JSON；实现复用统一错误体 `{"error":{code,message,type,request_id,retryable}}`，随后补 `data: [DONE]`，便于客户端沿用非流式错误处理。
4. **`NOT_IMPLEMENTED` 已移除**：Stage 0 引入的 501 占位码按计划在真实路由落地后删除，错误码表回归 DESIGN §8.1 的 18 项。
5. **`flush_every_ms` 合并微帧未实现**：设计标注为可选优化，Stage 2 采用逐块透传；如需降低 SSE 帧数可在 Stage 5/7 补。

## 下一步

Stage 3 · 结构化输出：`structured/lint.py`（六条兼容子集规则）、`structured/enforce.py`（L1/L2/L3 + jsonschema 校验 + repair）、`structured/translate.py`（`ResponseFormat` → 两家方言），并复用本阶段的终态事件承载 `structured` 结果。
