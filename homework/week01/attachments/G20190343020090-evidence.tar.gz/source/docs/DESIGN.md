# Mini LLM Gateway 设计文档

> 目标：用一个可运行的小网关，把「不同厂商、不同协议的 LLM API」收敛成一套统一调用方式，并在此之上补齐流式、结构化输出、提示词版本管理、可观测性与韧性四项工程能力。
> 技术栈：Python 3.12+ / FastAPI / httpx(AsyncClient) / Pydantic v2 / Jinja2 / Prometheus / Redis(可选) / SQLite。
> 版本：v1.0（设计稿）　日期：2026-11-01

---

## 0. 一句话结论

网关的核心不是"转发"，而是**在中间建立一套与厂商无关的中间表示（Canonical IR）**：请求进来先归一，出去前再翻译。所有能力（流式、结构化、计量、重试、限流）都挂在这层 IR 上实现一次，而不是在每个厂商 SDK 上各实现一遍。

---

## 1. 目标与范围

### 1.1 模型与协议绑定（题设）

| 对外模型名 | 上游协议 | 适配器 | 定位 |
|---|---|---|---|
| `deepseek-v4-pro` | OpenAI **Responses API**（`POST /v1/responses`） | `OpenAIResponsesAdapter` | 强能力、贵、适合复杂任务 |
| `deepseek-v4-flash` | Anthropic **Messages API**（`POST /v1/messages`） | `AnthropicMessagesAdapter` | 快、便宜、适合高并发短任务 |

> 说明：路由表是配置，不是代码。同一个厂商的同一个模型今天走 Responses、明天走 Chat Completions，只改一行 YAML，抽象层不动。
> 客观提示：真实 DeepSeek 官方接口是 **OpenAI Chat Completions 兼容**格式，并非上述两种。题设的绑定用于练习"多协议归一"，若接真实环境只需在路由表改 `adapter`，架构不变。

### 1.2 本期做（In Scope）

- 统一抽象层 + 适配器模式 + 按 `model` 动态路由
- 流式输出（SSE 逐块）
- 结构化输出（`response_format` 约束，返回合法 JSON）
- 提示词模板：存储、变量替换、版本引用
- 可观测性：Token 分类统计、延迟统计（含 TTFT）
- 韧性：统一错误码 + 指数退避重试 + 按模型独立限流（429）

### 1.3 本期不做（Out of Scope）

- 多轮会话持久化、上下文压缩
- Function Calling / Tools 编排（IR 预留字段，v1 不实现）
- 多租户计费结算、配额购买
- 网关集群一致性（限流的 Redis 方案只给接口，单机默认内存实现）
- 向量库、RAG、Agent 框架

---

## 2. 总体架构

```mermaid
flowchart TB
    C[Client] -->|HTTP /v1/chat| API[API 层<br/>FastAPI 路由 + 鉴权]
    API --> PR[提示词引擎<br/>PromptResolver: 模板加载 + 变量渲染]
    PR --> NR[归一化<br/>CanonicalRequest 构建 + 校验]
    NR --> MW[Middleware 管线]
    MW --> RL[限流器<br/>按模型: RPM + TPM + 并发]
    MW --> RT[重试执行器<br/>指数退避 + 错误归一]
    RL --> RT
    RT --> RG[路由表 Router<br/>model → adapter + upstream]
    RG --> A1[OpenAIResponsesAdapter]
    RG --> A2[AnthropicMessagesAdapter]
    A1 --> U1[(DeepSeek v4 pro<br/>/v1/responses)]
    A2 --> U2[(DeepSeek v4 flash<br/>/v1/messages)]
    A1 --> OB[观测层<br/>Token + 延迟 + 结构化日志]
    A2 --> OB
    OB --> M[(Prometheus / 日志 / SQLite)]
```

### 2.1 分层职责

| 层 | 组件 | 职责 | 绝不关心 |
|---|---|---|---|
| 接口层 | `routers/` | HTTP 语义、鉴权、参数校验、SSE 响应构造 | 厂商协议 |
| 领域层 | `core/` | Canonical IR、适配器接口、路由、能力声明 | HTTP 细节 |
| 能力层 | `prompt/` `structured/` `telemetry/` `resilience/` | 三大能力 + 观测 + 韧性 | 具体厂商 |
| 适配层 | `adapters/` | 协议翻译（IR ↔ 厂商格式）、鉴权头、错误映射 | 业务策略 |
| 传输层 | `httpclient/` | 连接池、超时、HTTP/2、流式读取 | 业务语义 |

**依赖方向单向向下**：适配层不许反向调用能力层做业务决策，只能抛出归一化后的 `CanonicalEvent` / `GatewayError`。

---

## 3. 统一抽象层

### 3.1 中间表示（Canonical IR）

```python
# core/ir.py —— 数据结构示意，非最终代码
class Role(StrEnum):
    SYSTEM = "system"; USER = "user"; ASSISTANT = "assistant"; TOOL = "tool"

@dataclass
class CanonicalMessage:
    role: Role
    content: str                      # v1 仅文本；多模态留 ContentBlock[] 扩展位

@dataclass
class ResponseFormat:                # 对外统一 OpenAI 风格
    type: Literal["text", "json_object", "json_schema"]
    name: str | None = None           # json_schema 必填
    schema: dict | None = None        # JSON Schema（已 lint 过）
    strict: bool = True

@dataclass
class CanonicalRequest:
    request_id: str
    model: str                        # 逻辑模型名（对外）
    messages: list[CanonicalMessage]
    system: str | None = None
    stream: bool = False
    response_format: ResponseFormat | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_output_tokens: int | None = None
    stop: list[str] | None = None
    user: str | None = None           # 上游滥用追踪
    metadata: dict = field(default_factory=dict)

@dataclass
class FinishReason(StrEnum):
    STOP="stop"; LENGTH="length"; TOOL_CALLS="tool_calls"
    CONTENT_FILTER="content_filter"; ERROR="error"

@dataclass
class TokenUsage:
    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0       # 思维链
    cache_read_tokens: int = 0      # 缓存命中
    cache_write_tokens: int = 0     # 缓存写入
    source: Literal["reported", "estimated"] = "reported"
    # total = input + output；billable 口径另算（cache_read 打折）

@dataclass
class CanonicalResponse:
    id: str
    model: str                      # 上游真实模型 id
    adapter: str
    text: str
    finish_reason: FinishReason
    usage: TokenUsage
    structured: dict | None = None  # 结构化输出解析结果
    latency: "Latency"
    raw: dict | None = None         # 调试用原始响应（可按开关裁剪）

@dataclass
class CanonicalEvent:              # 流式统一事件（适配器 → 网关）
    type: Literal["start", "delta", "structured", "done", "error", "ping"]
    text_delta: str | None = None
    usage: TokenUsage | None = None
    finish_reason: FinishReason | None = None
    structured: dict | None = None
    error: "GatewayError | None" = None
    upstream_seq: int | None = None
```

**设计取舍**：IR 采用 OpenAI 风格命名（`max_output_tokens` / `finish_reason` / `response_format`）而非完全中立命名。理由：生态里 OpenAI 语义是事实标准，客户端零学习成本；代价是 Anthropic 侧需要做语义转换（见 3.3）。这个代价集中在适配器内，可控。

### 3.2 适配器接口

```python
class ModelCapabilities(TypedDict):
    max_context_tokens: int
    max_output_tokens: int
    supports_stream: bool
    supports_json_schema: bool       # 原生 grammar 约束
    supports_json_object: bool       # 仅保证合法 JSON
    supports_reasoning: bool
    supports_prompt_caching: bool

class ProviderAdapter(Protocol):
    name: str                                    # "openai_responses" | "anthropic_messages"

    def build_payload(self, req: CanonicalRequest, route: "ModelRoute") -> dict: ...
    def build_headers(self, route: "ModelRoute") -> dict: ...          # 封装鉴权差异
    def parse_response(self, raw: dict, req) -> CanonicalResponse: ...  # 封装返回差异
    def parse_sse(self, byte_stream) -> AsyncIterator[CanonicalEvent]: ...
    def normalize_error(self, status: int, body: dict | None, exc=None) -> GatewayError: ...
    def capabilities(self, route) -> ModelCapabilities: ...
```

新增一个厂商 = 新增一个实现该 Protocol 的类 + 一条路由配置。**核心管线代码零改动**，这是适配器模式的验收标准。

### 3.3 协议差异对照与归一策略

| 维度 | OpenAI Responses API | Anthropic Messages API | 网关归一做法 |
|---|---|---|---|
| 端点 | `POST /v1/responses` | `POST /v1/messages` | 路由配置 |
| 鉴权 | `Authorization: Bearer <key>` | `x-api-key` + `anthropic-version: 2023-06-01` | `build_headers()` 各自封装，业务层只见 `route.api_key_env` |
| 系统提示 | `instructions`（string） | `system`（string 或 blocks） | `CanonicalRequest.system` |
| 对话输入 | `input`（string 或 item 数组，item 可为 message/reasoning/function_call） | `messages[]` | `CanonicalMessage[]` → 各自拼装 |
| 采样 | `temperature` / `top_p` | `temperature` / `top_p` | 直接透传 |
| 长度上限 | `max_output_tokens` | `max_tokens`（**必填**） | 未指定时用路由默认 `default_max_tokens`（如 4096），避免上游 400 |
| 停止词 | `stop` | `stop_sequences` | 字段名映射 |
| 结构化 | `text.format = {type:"json_schema", name, schema, strict:true}` | `output_config.format = {type:"json_schema", json_schema:{name, schema}}` | `ResponseFormat` → 各自翻译 |
| 输出取值 | `output[0].content[0].text` | `content[0].text` | `CanonicalResponse.text` |
| 结束原因 | `status` / `incomplete_details.reason`；另有 `refusal` | `stop_reason`: `end_turn` / `max_tokens` / `tool_use` | → `FinishReason`（`max_tokens→LENGTH`、`refusal→CONTENT_FILTER`） |
| usage | `usage.{input_tokens, output_tokens, total_tokens}` + `input_tokens_details.cached_tokens`；流式**只在 `response.completed` 有值** | `usage.{input_tokens, output_tokens}` + `cache_read_input_tokens` / `cache_creation_input_tokens`；**`message_start` 就有 `input_tokens`** | 统一 `TokenUsage`；流式时两边都等到终态事件才出最终 usage |
| 流式文本 | `response.output_text.delta.delta`（字符串直接在事件上） | `content_block_delta.delta.text`（嵌套 `delta` 对象，`type:"text_delta"`） | `CanonicalEvent.delta` |
| 流式结构 | `output_item.added` / `content_part.added` 包一层 | `content_block_start` / `content_block_stop`，按 `index` 定位 | 网关不对外透出这些包装事件 |
| 保活 | 未见文档化的 ping | `ping` 事件 | 网关自行发心跳，抹平差异 |
| 过载错误 | HTTP 429 / 5xx | HTTP 529 / `overloaded_error` | → `UPSTREAM_UNAVAILABLE`（可重试） |

**两个必须记住的坑**：

1. Anthropic `max_tokens` 是必填项，OpenAI 侧可选 → 网关必须补默认值，否则同一份 `CanonicalRequest` 在两个适配器上表现不一致。
2. OpenAI 流式的真实 usage **只在 `response.completed` 出现**；Anthropic 在 `message_start` 就给 `input_tokens`。因此"流式中断也要计费"这件事，OpenAI 侧只能估算，必须在 `TokenUsage.source` 打标，不能假装精确。

### 3.4 路由表

```yaml
# config/routes.yaml
models:
  deepseek-v4-pro:
    adapter: openai_responses
    upstream_model: deepseek-v4-pro
    base_url: https://api.deepseek.com
    api_key_env: DEEPSEEK_PRO_API_KEY
    default_max_tokens: 8192
    timeout: { connect: 5, read: 120 }
    limits: { rpm: 60, tpm: 200000, concurrent: 8 }
    fallback: []                  # 可选：同模型备用上游

  deepseek-v4-flash:
    adapter: anthropic_messages
    upstream_model: deepseek-v4-flash
    base_url: https://api.deepseek.com
    api_key_env: DEEPSEEK_FLASH_API_KEY
    default_max_tokens: 4096
    timeout: { connect: 5, read: 60 }
    limits: { rpm: 600, tpm: 2000000, concurrent: 64 }
```

路由解析：`model` 未命中 → `404 MODEL_NOT_FOUND`，并在错误 `details` 里回显可用模型列表（防手滑，也防枚举时无反馈）。

---

## 4. 能力一：流式输出

### 4.1 对外 SSE 契约

网关对外统一采用 **OpenAI Chat Completions 兼容的 SSE**（data-only chunk），理由：前端/`openai` SDK/各类 UI 组件能零改造直连，学习成本低。

```
HTTP/1.1 200 OK
Content-Type: text/event-stream; charset=utf-8
Cache-Control: no-cache
Connection: keep-alive
X-Accel-Buffering: no            # 关键：禁用 Nginx 缓冲
X-Request-Id: req_01J...

data: {"id":"req_01J","object":"chat.completion.chunk","model":"deepseek-v4-flash",
       "choices":[{"index":0,"delta":{"content":"你"},"finish_reason":null}],
       "usage":null}

data: {"id":"req_01J","choices":[{"index":0,"delta":{"content":"好"},"finish_reason":null}]}

: heartbeat                       # 注释行，15s 一次

data: {"id":"req_01J","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],
       "usage":{"prompt_tokens":128,"completion_tokens":42,"total_tokens":170},
       "gateway":{"ttft_ms":412,"total_ms":1980,"prompt":{"name":"summarize","version":3}}}

data: [DONE]
```

### 4.2 事件映射

| 上游（OpenAI Responses） | 上游（Anthropic Messages） | CanonicalEvent | 对外 SSE |
|---|---|---|---|
| `response.created` | `message_start` | `start`（记录 `input_tokens`） | 无（内部打点 TTFT 起点） |
| `response.output_text.delta` | `content_block_delta`(text_delta) | `delta` | `choices[0].delta.content` |
| `response.output_text.done` | `content_block_stop` | — | 忽略（网关自己累积） |
| `response.completed` | `message_delta` + `message_stop` | `done`（usage + finish_reason） | 终态 chunk + `usage` |
| `response.failed` / `error` | `error` | `error` | `error` 事件后关闭 |
| `response.incomplete` | `stop_reason=max_tokens` | `done`(LENGTH) | `finish_reason:"length"` |
| `ping` | `ping` | `ping` | `: heartbeat` |

### 4.3 必须处理的边界

- **首包不缓冲**：收到第一个 `delta` 立即 flush，否则 TTFT 指标失真。
- **心跳 15s**：Anthropic 有 `ping`，OpenAI 侧无保证 → 网关自维护定时器，静默超时（如 60s 无数据）判定 `STREAM_INTERRUPTED`。
- **客户端断开**：`asyncio.CancelledError` / Starlette disconnect → 关闭上游响应（`httpx.Response.aclose()`），避免连接泄漏；日志标记 `client_aborted=true`，用量按已产出估算入账。
- **流中错误无法改状态码**：SSE 一旦发出 200，中途失败只能发 `error` 事件后关闭。缓解手段是把鉴权、参数校验、限流**全部前置到 200 之前**执行（preflight），让能返回 4xx 的错误都在发流前返回。
- **背压**：默认逐块透传不累积；可选 `flush_every_ms=30` 合并微帧，减少 SSE 帧数（降低代理层开销）。
- **结构化 + 流式**：原生 grammar 约束下增量文本是合法 JSON 的前缀，但客户端逐块解析需要增量 JSON 解析器。策略见 5.3。

---

## 5. 能力二：结构化输出

### 5.1 对外契约

沿用 OpenAI 风格，网关负责翻译成各厂商方言：

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "issue_report",
    "schema": { "type":"object", "properties": {...}, "required":[...], "additionalProperties": false },
    "strict": true
  }
}
```

- `type: "json_object"` → 只要求合法 JSON，不校验结构。
- `type: "json_schema"` + `strict: true` → 走上游原生 grammar 约束，强保证。

### 5.2 三档降级策略

| 档位 | 条件 | OpenAI 侧 | Anthropic 侧 | 保证强度 |
|---|---|---|---|---|
| L1 `native_schema` | 适配器 `supports_json_schema=true` 且 schema 通过 lint | `text.format.json_schema(strict)` | `output_config.format.json_schema` | 语法 + schema 双保证 |
| L2 `native_json_object` | 只要合法 JSON | `text.format={type:"json_object"}` | **无等价能力** → 走 L3 | 仅语法保证 |
| L3 `prompt_repair` | 兜底 | 提示词注入 schema 说明 | 同左 | 尽力而为：剥离 ```json 围栏 → `json.loads` → jsonschema 校验 → 失败把错误回灌给模型重试（额外 ≤ 2 次，独立于网络重试预算） |

响应中回显实际档位：`"structured": {...}, "structured_mode": "native_schema"`，便于排查。

### 5.3 Schema 兼容子集（网关强制 lint）

两家 grammar 引擎支持的 JSON Schema 子集不同，网关在**请求入口**统一 lint，不合规直接 `400 SCHEMA_INCOMPATIBLE`，把上游 500 变成客户端 400：

| 规则 | 原因 |
|---|---|
| 每个 object 必须 `additionalProperties: false` | OpenAI strict 与 Anthropic 均强制 |
| 所有字段必须进 `required`；可选字段用 `["string","null"]` 表达 | OpenAI strict 模式要求 |
| 禁用 `$ref` / `$defs` 递归引用 | 需内联展开 |
| 禁用 `oneOf`；联合类型用带判别字段的 `anyOf` | 兼容性差 |
| 禁用 `pattern` / `format` 做约束 | 各引擎不保证执行，改用 `enum` |
| 嵌套深度 ≤ 5、属性数 ≤ 100、schema ≤ 20KB | 防 grammar 编译爆炸 |

**两个实践中会踩的点**（已确认，非推测）：

1. Anthropic 首次使用新 schema 会付**一次性 grammar 编译延迟**，编译结果缓存 24h。高频 schema 建议启动时预热（发一次最小请求），或接受首个请求慢。
2. OpenAI strict 模式下安全拒答不会以普通内容返回，而是落在 `refusal` 字段 → 适配器必须检查 `refusal`，映射为 `CONTENT_FILTERED`，否则结构化解析会拿到空串。
3. 原生结构化输出与 extended thinking / reasoning 同时启用时的行为**未验证**，v1 期间二者同时出现时网关直接返回 `400 INVALID_REQUEST`（明确拒绝优于静默出错）。

### 5.4 流式 + 结构化的取舍（重要权衡）

流式与严格结构化天然有张力：grammar 约束下增量输出虽是合法 JSON 前缀，但客户端若想边收边解析，必须实现增量 JSON 解析器，复杂度不划算。

**本网关策略**：
- `response_format` 存在且 `strict=true` 时，**默认强制 `stream=false`**，并在响应里 `"note":"structured output forced non-streaming"`。
- 客户端显式要求 `stream=true` + 结构化时：文本照常流式吐出，但**解析后的 `structured` 对象只在终态 chunk 出现**，中间不发半截 JSON。客户端要么只做展示，要么等终态再解析。
- 这条规则写进文档和错误提示，避免用户踩"流式下 JSON 解析失败"。

---

## 6. 能力三：提示词版本管理

### 6.1 数据模型

```sql
CREATE TABLE prompt_templates (
  id           INTEGER PRIMARY KEY,
  name         TEXT NOT NULL,               -- "summarize"
  version      INTEGER NOT NULL,            -- 自增，单调递增
  content      TEXT NOT NULL,               -- Jinja2 模板
  variables    TEXT NOT NULL,               -- JSON: [{"name":"text","required":true,"default":null}]
  response_schema TEXT,                     -- 可选：绑定默认结构化 schema
  status       TEXT NOT NULL,               -- draft | active | deprecated
  checksum     TEXT NOT NULL,               -- sha256(content)，用于归因
  created_at   TEXT NOT NULL,
  created_by   TEXT,
  UNIQUE(name, version)
);
CREATE INDEX idx_prompt_active ON prompt_templates(name, status);
```

**不可变版本**：已发布（非 draft）版本内容不可修改，改动必须生成新版本。这样线上日志里的 `checksum` 能 100% 复现当时的提示词——这是线上归因的前提。

### 6.2 版本引用语法

```json
{"prompt_ref": {"name": "summarize", "version": "latest"}}
```

| 写法 | 语义 |
|---|---|
| `"latest"` / 省略 | 取该 name 下版本号最大者 |
| `"active"` | 取 `status=active` 的版本（推荐生产使用） |
| `3` / `"3"` | 精确版本号 |
| `"summarize@3"` | 字符串简写（兼容外部系统传入） |

解析不到 → `404 PROMPT_NOT_FOUND`，错误 `details` 回显可用版本列表。

### 6.3 渲染流程

```mermaid
sequenceDiagram
    participant C as Client
    participant G as Gateway
    participant P as PromptStore
    C->>G: POST /v1/chat {prompt_ref, variables, messages?}
    G->>P: resolve(name, version) → 缓存未命中则查 SQLite
    P-->>G: template{content, variables, checksum}
    G->>G: 校验 variables（缺失 → 400 MISSING_VARIABLE）
    G->>G: Jinja2 SandboxedEnvironment 渲染
    G->>G: 渲染结果作为 base_messages；请求里的 messages 追加在后
    G->>G: 进入 CanonicalRequest 管线（结构化/流式/限流/重试）
    G-->>C: 响应头 + 响应体回显 prompt{name, version, checksum}
```

关键设计：

- **沙箱渲染**：`SandboxedEnvironment`（禁止模板访问 Python 内部对象），且 `autoescape=False`（LLM 场景不需要 HTML 转义）。
- **变量校验**：模板声明 `required` 的变量缺失 → `400 MISSING_VARIABLE`；未声明但传入的变量 → 忽略并告警记录（防拼写错误静默生效）。
- **与 messages 的合并规则**：`prompt_ref` 渲染出 base（通常 system + 首轮 user），请求里的 `messages` **追加在后**。这样既能复用模板，又支持多轮对话。二者都不给 → `400 INVALID_REQUEST`。
- **schema 联动**：模板可预置 `response_schema`，请求未显式指定 `response_format` 时自动套用。
- **缓存**：LRU(256) + TTL 60s；`active` 指针变更时主动失效该 name 的全部缓存。
- **存储抽象**：`PromptStore` Protocol 先落 SQLite（零依赖），后续换 Postgres 不改上层。

### 6.4 管理接口

| 方法 | 路径 | 说明 |
|---|---|---|
| `POST` | `/v1/prompts` | 创建/新增版本（同 name 自动 +1） |
| `GET` | `/v1/prompts` | 列表（按 name 聚合） |
| `GET` | `/v1/prompts/{name}` | 详情 + 版本列表 |
| `GET` | `/v1/prompts/{name}/{version}` | 指定版本内容 |
| `POST` | `/v1/prompts/{name}/{version}/activate` | 设为 active（原子切换） |
| `POST` | `/v1/prompts/{name}/render` | 干跑渲染，返回渲染后文本（调试用，不调模型） |

---

## 7. 可观测性

### 7.1 Token 分类统计

| 分类 | 来源（OpenAI） | 来源（Anthropic） | 用途 |
|---|---|---|---|
| `input_tokens` | `usage.input_tokens` | `usage.input_tokens` | 基础计费 |
| `output_tokens` | `usage.output_tokens` | `usage.output_tokens` | 基础计费 |
| `reasoning_tokens` | `output_tokens_details.reasoning_tokens` | thinking 块计费 token | 单列，避免污染输出口径 |
| `cache_read_tokens` | `input_tokens_details.cached_tokens` | `cache_read_input_tokens` | 命中折扣 |
| `cache_write_tokens` | — | `cache_creation_input_tokens` | 写入溢价 |

规则：

- `total_tokens = input + output`（与上游口径一致，便于对账）；`billable_total` 另算（cache_read 按折扣系数，可配）。
- **上报优先、估算兜底**：上游给了就用上游的（`source=reported`）；流式中断 / 上游未返回 usage / 客户端断开 → 用 `len(text)/4` 近似（`source=estimated`），并在指标上打 `source` 标签，**绝不把估算值当精确值上报**。
- 聚合维度：`model`、`adapter`、`api_key_id`、`prompt_name`、`prompt_version`、`status`。
- Prometheus：`llm_tokens_total{model,type,source}`（Counter）、`llm_cost_estimate_total{model,currency}`（Counter，按路由价格表换算）。

### 7.2 延迟指标

```mermaid
gantt
    dateFormat X
    axisFormat %L ms
    section 时间轴
    请求进入(t0)           :a1, 0, 1
    限流排队 queue_wait    :a2, 1, 6
    渲染+归一化            :a3, 6, 9
    上游连接+首字节        :a4, 9, 60
    首个 delta (TTFT)      :milestone, m1, 412, 1
    生成中                 :a5, 412, 1900
    流结束(t_end)          :milestone, m2, 1980, 1
```

| 指标 | 定义 | 说明 |
|---|---|---|
| `ttft_ms` | 首个文本 delta 到达 − t0 | **含**限流排队与重试开销，反映用户真实体感 |
| `upstream_ttft_ms` | 首个 delta − 上游请求发出 | 剔除网关开销，用于判断是上游慢还是自己慢 |
| `queue_wait_ms` | 限流排队耗时 | 限流调优依据 |
| `retry_overhead_ms` | 重试累计耗时 | 重试策略依据 |
| `total_ms` | 流结束 − t0 | 端到端 |
| `tpot_ms` | (t_end − TTFT) / output_tokens | 单 token 生成速度，判断生成是否变慢 |

直方图分桶（ms）：`[50, 100, 250, 500, 1000, 2000, 5000, 10000, 30000]`。
`ttft_ms` 只在真正拿到第一个 delta 时打点；请求失败（未产出任何 token）不产生 TTFT，只记 `total_ms` 和错误码——把失败混入 TTFT 平均值是最常见的指标失真。

### 7.3 日志与追踪

结构化 JSON 一行一条，字段固定：

```json
{
  "ts":"2026-11-01T13:44:01.123+08:00", "level":"info", "event":"llm.call",
  "request_id":"req_01J...", "trace_id":"...",
  "api_key_id":"k_7f", "model":"deepseek-v4-flash", "adapter":"anthropic_messages",
  "upstream_model":"deepseek-v4-flash",
  "prompt":{"name":"summarize","version":3,"checksum":"sha256:ab12..."},
  "stream":true, "structured_mode":"native_schema",
  "usage":{"input":128,"output":42,"reasoning":0,"cache_read":64,"source":"reported"},
  "ttft_ms":412, "total_ms":1980, "queue_wait_ms":5,
  "retry_count":1, "status":"ok", "error_code":null,
  "client_aborted":false
}
```

- `X-Request-Id` 请求头：客户端可传（透传并校验格式），未传则服务端生成，响应头与日志一致。
- 采样：错误/重试/超时 100% 记录；成功请求按 `log_sample_rate`（默认 0.1）采样，但**计数器指标全量**。
- 日志脱敏：`messages` 正文默认不落日志（只落长度与 hash）；`debug` 开关下才落原文。

---

## 8. 韧性基础

### 8.1 统一错误码

响应体固定形状（对齐 OpenAI 错误风格 + 网关扩展）：

```json
{
  "error": {
    "code": "UPSTREAM_UNAVAILABLE",
    "message": "upstream returned 529, retried 2 times",
    "type": "upstream_error",
    "request_id": "req_01J...",
    "retryable": true,
    "details": {"upstream_status": 529, "attempts": 3}
  }
}
```

| code | HTTP | 含义 | 可重试 |
|---|---|---|---|
| `INVALID_REQUEST` | 400 | 参数/schema 校验失败 | 否 |
| `MISSING_VARIABLE` | 400 | 提示词必填变量缺失 | 否 |
| `SCHEMA_INCOMPATIBLE` | 400 | schema 超出兼容子集 | 否 |
| `CONTEXT_LENGTH_EXCEEDED` | 400 | 超上下文窗口 | 否 |
| `CONTENT_FILTERED` | 400 | 内容过滤 / 模型拒答 | 否 |
| `PROMPT_NOT_FOUND` | 404 | 模板或版本不存在 | 否 |
| `MODEL_NOT_FOUND` | 404 | 未知 model | 否 |
| `AUTH_FAILED` | 401 | 网关鉴权失败 | 否 |
| `PERMISSION_DENIED` | 403 | 该 key 无权访问此模型 | 否 |
| `RATE_LIMITED` | 429 | 网关限流触发 | 是（`Retry-After`） |
| `UPSTREAM_AUTH` | 401 | 上游鉴权/配额问题 | 否 |
| `UPSTREAM_BAD_REQUEST` | 400 | 上游拒绝（透传 + 归一） | 否 |
| `UPSTREAM_TIMEOUT` | 504 | 上游超时 | 是 |
| `UPSTREAM_UNAVAILABLE` | 503 | 上游 5xx / 529 / 连接失败 | 是 |
| `UPSTREAM_BAD_RESPONSE` | 502 | 上游返回不可解析 | 是 |
| `OUTPUT_PARSE_FAILED` | 502 | 结构化解析失败且修复重试耗尽 | 是（L3 档内重试） |
| `STREAM_INTERRUPTED` | 502 | 流中途断开 | 是 |
| `INTERNAL` | 500 | 网关内部异常 | 否 |

映射原则：**上游错误必须归一化后再抛**，禁止把厂商原始错误体直接透给客户端（泄漏内部信息 + 客户端无法统一处理）。原始错误体放 `details.upstream_body`，按 `debug` 开关决定是否返回。

### 8.2 指数退避重试

```
max_attempts = 3          # 总尝试次数（首次 1 + 重试 2）；配置名 retry.max_attempts
base_delay   = 0.5s
multiplier   = 2
max_delay    = 8s
jitter       = full       # sleep = uniform(0, min(max_delay, base * 2^(n-1)))
per_call_deadline = 60s   # 单次上游调用超时
total_deadline    = 120s  # 含重试的总预算，超了直接放弃
```

- **全抖动（full jitter）而非等抖动**：避免多客户端同时重试造成尖峰。
- **可重试判定**（白名单，而非黑名单）：
  - 连接错误 / 读超时 / `httpx.TimeoutException` / `httpx.ConnectError`
  - HTTP `408 / 409 / 429 / 500 / 502 / 503 / 504 / 529`
  - 网关错误码：`UPSTREAM_TIMEOUT` / `UPSTREAM_UNAVAILABLE` / `UPSTREAM_BAD_RESPONSE` / `STREAM_INTERRUPTED` / `RATE_LIMITED`
  - 其余一律不重试（尤其是 400 类，重试只会浪费配额）
- **尊重 `Retry-After`**：上游给了就以它为准（上限 `max_delay`）。
- **流式重试的关键约束**：只在**第一个 delta 尚未发给客户端**时才允许重试。一旦已吐出任何内容，重试会导致客户端看到重复文本 → 此时改为发 `error` 事件终止流，并在日志记 `retry_skipped_reason=stream_started`。
- **Fallback**：路由配置了 `fallback` 时，同一 attempt 内先重试当前上游，连续失败 2 次后切到备用上游；切换写入日志 `upstream_switched=true`。
- **非幂等警示**：重试会产生重复计费（上游已生成 token 但网络断了）。v1 明确接受这个代价，并在文档与日志标注；真要避免需要上游支持 `idempotency-key`（两家均未公开保证）。

### 8.3 按模型独立限流

**三道闸**，每个模型独立一套，互不挤占（flash 被打满不影响 pro）：

| 闸 | 维度 | 算法 | 超限行为 |
|---|---|---|---|
| RPM | 请求数/分钟 | 令牌桶 `capacity=rpm`, `refill=rpm/60` per sec | `429 RATE_LIMITED` |
| TPM | Token 数/分钟 | 令牌桶 `capacity=tpm`；**请求前按预估 input 预扣**，响应后按实测 usage 多退少补 | `429 RATE_LIMITED` |
| 并发 | in-flight 请求数 | 信号量 | 超 `max_queue_wait`(2s) → `429` |

```mermaid
flowchart LR
    R[请求到达] --> A{RPM 桶}
    A -->|通过| B{TPM 预扣}
    A -->|拒绝| X[429 + Retry-After]
    B -->|通过| C{并发信号量}
    B -->|拒绝| X
    C -->|获得| U[调用上游]
    C -->|排队超时| X
    U --> D[按实测 usage 校正 TPM]
    D --> E[释放并发]
```

- **单机**：内存令牌桶（默认，零依赖）。**多实例**：`RedisRateLimiter`，用 Lua 脚本保证"读-算-写"原子性（否则并发下桶会超发）。两者实现同一 `RateLimiter` Protocol。
- **响应头**：`X-RateLimit-Limit-Requests` / `-Remaining` / `-Reset`；429 必带 `Retry-After`。
- **Key 设计**：主 key = `model`；可选二级 key = `api_key_id + model`（防单租户打满）。两级都过才放行。
- **与重试的配合**：限流返回的 429 是**网关自己的** 429，不是 `UPSTREAM_UNAVAILABLE`，**不触发上游重试**（否则限流形同虚设）。重试器只对上游返回的 429 退避。

---

## 9. HTTP 接口

| 方法 | 路径 | 说明 |
|---|---|---|
| `POST` | `/v1/chat` | 统一入口（Canonical 风格，支持 prompt_ref / messages / stream / response_format） |
| `POST` | `/v1/chat/completions` | OpenAI Chat Completions 兼容入口（可选，便于生态直连） |
| `GET` | `/v1/models` | 返回路由表可见模型 + 能力声明 |
| `POST` | `/v1/prompts` 等 | 见 6.4 |
| `GET` | `/healthz` | 存活（不探上游） |
| `GET` | `/readyz` | 就绪（探上游连通性 + 路由表加载） |
| `GET` | `/metrics` | Prometheus |

请求示例：

```json
POST /v1/chat
{
  "model": "deepseek-v4-flash",
  "prompt_ref": {"name": "summarize", "version": "active"},
  "variables": {"text": "……", "max_len": 200},
  "messages": [{"role":"user","content":"再压缩一半"}],
  "stream": true,
  "response_format": {"type":"json_schema","json_schema":{"name":"summary","schema":{...},"strict":true}},
  "max_output_tokens": 1024
}
```

`stream=true` 时返回 SSE；否则返回 JSON。结构化请求默认强制非流式（见 5.4）。

---

## 10. 配置与目录结构（落地锚点）

```
mini-llm-gateway/
├── DESIGN.md
├── config/
│   ├── gateway.yaml        # 超时/重试/限流默认/日志采样
│   └── routes.yaml         # 模型路由表（3.4）
├── src/gateway/
│   ├── main.py             # FastAPI app 装配
│   ├── core/               # ir.py / adapter.py / router.py / errors.py
│   ├── adapters/           # openai_responses.py / anthropic_messages.py
│   ├── prompt/             # store.py / resolver.py / templates 渲染
│   ├── structured/         # lint.py / enforce.py（L1~L3 降级）
│   ├── telemetry/          # metrics.py / logging.py / usage.py
│   ├── resilience/         # retry.py / ratelimit.py
│   └── httpclient/         # pool.py
├── tests/                  # 适配器用 mock 上游（respx）跑协议翻译
└── pyproject.toml
```

配置优先级：`gateway.yaml` < 环境变量 `GW_*`（Pydantic Settings 校验，启动即失败，不让错配置带病运行）。

---

## 11. 实施里程碑

| 阶段 | 产出 | 验收（可测） |
|---|---|---|
| M1 抽象层 | IR + 2 个适配器 + 路由 + 非流式 | 同一份 `CanonicalRequest` 打给两个模型都通；新增第三个 mock 适配器不改核心代码 |
| M2 流式 | SSE 出口 + 事件映射 + 心跳 + 断开处理 | `curl -N` 看逐块输出；杀客户端后上游连接释放；TTFT 与 `upstream_ttft_ms` 分离可见 |
| M3 结构化 | schema lint + L1/L2/L3 + 校验 | 给定 schema 100 次调用全部 `json.loads` 成功；不合规 schema 返回 400 |
| M4 提示词 | SQLite 存储 + 版本 + 渲染 | 版本不可变；日志 checksum 可复现；干跑渲染接口可用 |
| M5 可观测 | Token 分类 + 延迟 + 日志 | `/metrics` 有全部指标；流式中断也有用量（标 estimated） |
| M6 韧性 | 错误码 + 重试 + 限流 | mock 上游 529 → 重试 2 次后成功；打满 RPM → 429 + Retry-After；flash 限流不影响 pro |

---

## 12. 风险与权衡（明写，不藏）

| 项 | 风险 | 处置 |
|---|---|---|
| SSE 头已发 | 流中错误无法改 HTTP 状态码 | 全部 4xx 前置到发流前（preflight）；流中错误用 `error` 事件终止 |
| 结构化 + 流式 | 增量 JSON 解析复杂、易错 | 默认强制非流式；流式时只在终态给 `structured` |
| 重试非幂等 | 上游已生成 token 但网络断 → 重复计费 | 接受；日志标 `retry_count`，只对安全错误重试 |
| usage 估算 | 中断/估算值与真实计费有偏差 | `source` 标签区分，绝不混报 |
| Anthropic `max_tokens` 必填 | 不补默认值会 400 | 路由表 `default_max_tokens` 兜底 |
| 上游协议演进 | 厂商 beta header / 字段名会变（如 Anthropic 结构化输出已从 beta response_format 改为 GA 的 output_config） | 差异全部锁在适配器内；每个适配器配协议版本常量的契约测试 |
| 内存限流 | 多实例下不生效 | 单机默认内存；多实例切 Redis Lua，接口先行预留 |
| 上下文超窗 | 上游返回 400，重试无意义 | 归一为 `CONTEXT_LENGTH_EXCEEDED`，不重试，提示裁剪 |

---

## 13. 验收清单（Checklist）

- [ ] 同一个 `CanonicalRequest` 可被两个适配器正确翻译（契约测试，mock 上游）
- [ ] `stream=true` 输出符合 4.1 的 SSE 契约，`data: [DONE]` 结尾
- [ ] TTFT 只统计真正拿到首个 delta 的请求
- [ ] `response_format` 合规 schema 走原生约束；不合规提前 400
- [ ] 提示词已发布版本不可变，日志 checksum 可复现
- [ ] 所有错误走统一响应体，含 `code` / `retryable` / `request_id`
- [ ] 重试最多总尝试 3 次，全抖动，流式已开流不重试
- [ ] flash 限流打满时，pro 请求仍正常
- [ ] `/metrics` 覆盖 Token 分类与全部延迟指标
- [ ] 新增一个 mock 厂商适配器，核心管线零改动
