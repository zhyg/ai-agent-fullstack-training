# Stage 1 · 抽象层 + 双适配器（非流式）

## 做了什么

- `core/ir.py`：`CanonicalRequest/Response/Event`、`CanonicalMessage`、`TokenUsage` 五分类、`FinishReason`、`Latency`、`CallContext`。
- `core/adapter.py`：`ProviderAdapter` Protocol 与 `ModelCapabilities`。
- `core/router.py`：路由表 pydantic 模型 + `Router.resolve()`，未知模型回显可用列表。
- `core/invoker.py`：`Gateway.call_once()`（最小可重试单元）、`complete()`、`invoke()`（非流式 = 单 `done` 事件）。
- `adapters/openai_responses.py`：`/v1/responses`，Bearer 鉴权、`input`/`instructions`/`text.format` 翻译、usage 与 finish_reason 归一。
- `adapters/anthropic_messages.py`：`/v1/messages`，`x-api-key` + `anthropic-version`、`max_tokens` 默认值兜底、system 提升到顶层、`cache_read/cache_write` 映射。
- `adapters/registry.py`：适配器注册表；新增厂商只需实现 Protocol + 加一条路由。
- `httpclient/pool.py`：共享 `httpx.AsyncClient`，按路由 connect/read 超时。
- `api/routers/chat.py`、`api/routers/models.py`：`POST /v1/chat` 非流式、`GET /v1/models`。
- 测试：`tests/adapters/test_contract.py` + fixture 响应体；含「第三个 mock 适配器零改核心」用例。

## 怎么验

```bash
cd /root/LLMGateway && uv run pytest -q
uv run uvicorn gateway.main:app --port 8000 &
curl -s localhost:8000/v1/models
curl -s -X POST localhost:8000/v1/chat -H 'content-type: application/json' \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"hi"}]}'
```

## 实测输出

```
38 passed
```

```json
{"object":"list","data":[
 {"id":"deepseek-v4-flash","adapter":"anthropic_messages","capabilities":{"max_context_tokens":200000,"max_output_tokens":4096,"supports_json_object":false,"supports_json_schema":true}},
 {"id":"deepseek-v4-pro","adapter":"openai_responses","capabilities":{"max_context_tokens":128000,"max_output_tokens":8192,"supports_json_object":true,"supports_json_schema":true}}
]}
```

```http
HTTP/1.1 401 Unauthorized
{"error":{"code":"UPSTREAM_AUTH","message":"API key env 'DEEPSEEK_FLASH_API_KEY' is not set","type":"upstream_error","retryable":false}}
```

真实上游调用在契约测试中用 respx mock，无需真实 API Key。

## 与设计文档的偏差

- OpenAI Responses 的 `input` item 统一用 `input_text` 内容块（真实 API 对 assistant 消息可用 `output_text`），属于练习用最小实现，差异已锁在适配器内。
- `/v1/chat` 的 `stream=true` 暂返回 501，Stage 2 实现。
- `/v1/chat/completions` 兼容入口未实现（设计标注为可选）。
- 模型 `capabilities` 目前按适配器硬编码，后续可下沉到路由表。

## 下一步

Stage 2：两家 SSE 解析、事件映射、对外 SSE 契约、心跳、客户端断开与 TTFT 打点。
