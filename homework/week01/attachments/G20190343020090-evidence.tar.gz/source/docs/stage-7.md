# Stage 7 · 端到端验收与固化

## 做了什么

新增/修改文件：

| 文件 | 改动 |
|---|---|
| `tests/e2e/fault_injection.py` | 新增：脚本化上游。`ScriptedTransport` 按 `route.upstream_model` 排队回复，支持 JSON / SSE / HTTP 错误 / 网络异常，并提供 `calls_for()` 计数 |
| `tests/e2e/test_scenarios.py` | 新增 10 个端到端用例，逐条对齐 DESIGN §13 验收清单；含客户端断开的故障注入用例 |
| `scripts/bench.py` | 新增：零依赖并发压测（成功/限流/失败计数、吞吐、延迟与 TTFT 分位数） |
| `README.md` | 由空文件补齐为使用文档：能力、目录、快速开始、三类调用示例、配置表、接口表、指标、韧性、测试与压测、已知限制 |
| `docs/stage-7.md` | 本文件：阶段实证记录与清单对照 |

关键实现点：

- **故障注入不碰网络**：`ScriptedTransport` 实现 `httpx.AsyncBaseTransport`，由 `build_app(transport=...)` 注入到 `Gateway`，所有场景在进程内跑完，不需要真实 API Key。
- **回复可排队且末条复用**：同一模型可以排队 `529 → 529 → 200`，队列耗尽后重复最后一条，便于断言「重试后成功」与「重试次数」。
- **SSE 帧可拼装**：`sse_frames()` / `truncated_anthropic_sse()` / `upstream_error_sse()` 覆盖正常结束、中断、上游 error 事件三种形态。
- **客户端断开走真实传输**：`TrackingTransport` + `TrackingByteStream` 记录上游流是否被 `aclose()`，直接迭代 `stream_frames` 后关闭，验证连接释放。
- **压测脚本故意不依赖项目包**：只用 `urllib` + `ThreadPoolExecutor`，可以对着任意已启动的网关施压，也能在没有 uv 环境的机器上跑。
- **TTFT 口径与网关一致**：压测侧只在收到首个含非空 `delta.content` 的 chunk 时计时，429/错误请求不计入 TTFT 样本。

## 怎么验

```bash
# e2e 场景（进程内 mock，不需要 API Key）
cd /root/LLMGateway && /root/.local/bin/uv run pytest tests/e2e -q

# 全量回归
cd /root/LLMGateway && /root/.local/bin/uv run pytest

# 压测（需先起 mock 上游 8010 与网关 8004，见临时脚本 /tmp/run_bench7.sh）
cd /root/LLMGateway && /root/.local/bin/uv run python scripts/bench.py \
    --base-url http://127.0.0.1:8004 --model deepseek-v4-flash \
    --requests 200 --concurrency 100
```

压测环境（临时配置，不进入仓库）：`routes7.yaml` 中 `deepseek-v4-flash` 为 `rpm=40 / tpm=200000 / concurrent=8`，`deepseek-v4-pro` 为 `rpm=600 / concurrent=16`，两者都指向 mock 上游 `127.0.0.1:8010`；网关 `gw7.py` 开 debug、`sample_rate=1.0`、重试 50ms 起 / 400ms 封顶、`max_queue_wait_ms=0`。

## 实测输出

```text
tests/e2e/test_scenarios.py: 10

全量：178 passed, 1 warning in 3.84s（Stage 6 为 168，本阶段新增 10）
```

压测（flash `rpm=40`，200 请求 / 并发 100）：

```text
target=http://127.0.0.1:8004 model=deepseek-v4-flash requests=200 concurrency=100 stream=True
result: ok=40 rate_limited=160 failed=0 throughput=160.6 req/s
          ok latency_ms p50=633.5 p95=650.3 max=1192.5
rate_limited latency_ms p50=245.8 p95=266.8 max=280.0
          ok ttft_ms    p50=480.2 p95=549.7 max=1190.9
```

同一时段 pro（并发 10，低于并发闸 16，100 请求）：

```text
result: ok=100 rate_limited=0 failed=0 throughput=97.3 req/s
          ok latency_ms p50=93.2 p95=169.5 max=171.7
          ok ttft_ms    p50=70.9 p95=135.7 max=146.3
```

`/metrics` 对应计数（flash 400 次里有 160 次被限流拒绝，TTFT 只统计成功的 40 次）：

```text
llm_requests_total{adapter="anthropic_messages",model="deepseek-v4-flash",status="ok"} 40.0
llm_requests_total{adapter="anthropic_messages",model="deepseek-v4-flash",status="error"} 160.0
llm_requests_total{adapter="openai_responses",model="deepseek-v4-pro",status="ok"} 100.0
llm_ttft_ms_count{adapter="anthropic_messages",model="deepseek-v4-flash"} 40.0
llm_ttft_ms_count{adapter="openai_responses",model="deepseek-v4-pro"} 100.0
```

## DESIGN §13 清单逐条对照

DESIGN §13 实际列了 10 条（文档正文写“13 条”，出入见下文偏差 1）。全部通过，每条都能指到具体测试：

| # | 验收项 | 对应测试 | 结果 |
|---|---|---|---|
| 1 | 同一个 `CanonicalRequest` 被两个适配器正确翻译 | `test_dual_adapters_translate_same_request` | ✅ |
| 2 | `stream=true` 符合 SSE 契约，`data: [DONE]` 结尾 | `test_stream_contract_is_data_only_and_ends_with_done` | ✅ |
| 3 | TTFT 只统计真正拿到首个 delta 的请求 | `test_ttft_only_for_requests_that_receive_a_delta` | ✅ |
| 4 | 合规 schema 走原生约束；不合规提前 400 | `test_structured_schema_native_and_incompatible_preflight` | ✅ |
| 5 | 已发布版本不可变，checksum 可复现 | `test_prompt_version_is_immutable_and_checksum_reproducible` | ✅ |
| 6 | 错误统一响应体，含 `code` / `retryable` / `request_id` | `test_errors_share_one_unified_body` | ✅ |
| 7 | 重试最多 3 次、全抖动、已开流不重试 | `test_retry_whitelist_and_no_retry_after_stream_started` | ✅ |
| 8 | flash 限流打满时 pro 仍正常 | `test_rate_limit_isolation_between_models` + 上面的压测 | ✅ |
| 9 | `/metrics` 覆盖 Token 五分类与 6 个延迟指标 | `test_ttft_only_for_requests_that_receive_a_delta`（断言 6 个 `# TYPE … histogram`） | ✅ |
| 10 | 新增 mock 适配器，核心管线零改动 | `test_new_mock_adapter_needs_zero_core_changes` | ✅ |

清单外补充的故障注入：

| 场景 | 对应测试 |
|---|---|
| 客户端中途断开 → 释放上游流、不产生成功样本 | `test_client_disconnect_releases_upstream_stream` |
| 上游超时 / 529 / 400 / 开流后断流 | 复用于 `ScriptedTransport` 的各场景（`timeout_reply` / `error_reply` / `truncated_anthropic_sse`） |
| schema 违规 | `test_structured_schema_native_and_incompatible_preflight` |

## 真实上游验证（DeepSeek）

用真实 DeepSeek API 跑了一轮端到端，密钥只通过环境变量 `DEEPSEEK_API_KEY` 注入进程，未写入任何文件、未进日志（见下表最后一条）。临时路由 `/tmp/llmgw_real/routes_real.yaml`：

| 网关模型 | 适配器 | 真实端点 | 真实模型 id |
|---|---|---|---|
| `deepseek-v4-pro` | `openai_responses` | `https://api.deepseek.com` + `/v1/responses` | `deepseek-v4-pro` |
| `deepseek-flash` | `anthropic_messages` | `https://api.deepseek.com/anthropic` + `/v1/messages` | `deepseek-flash` |

结果 **14/14 passed**：

| 检查项 | 实测 |
|---|---|
| healthz / models 可见 | 200；返回 `deepseek-flash`、`deepseek-v4-pro` 及能力声明 |
| flash 非流式 | 200，`usage.source=reported`，`input=34 / output=64` |
| flash 流式 | 200，3 帧 + `[DONE]`，文本 `12345`，`ttft≈1255ms`（含上游思考耗时） |
| SSE 只含 data 行 | 通过（心跳注释行按契约放行） |
| 流式终态延迟 | `{total_ms: 1290.3, ttft_ms: 1251.59, upstream_ttft_ms: 1250.11, tpot_ms: 0.47}` |
| pro 非流式 | 200，`reasoning_tokens=102`（DeepSeek 推理 token 被正确归入 output 子类） |
| pro 流式 | 200，21 帧 + `[DONE]`，`ttft≈3074ms` |
| 提示词创建 + checksum | `sha256:8b0701…` 与本地重算一致 |
| 渲染提示词并真实调用 | 200，终态回显 `{name, version, checksum}` |
| 结构化输出 | 200，`structured_mode=native_schema`，`{'city': '北京', 'temp_c': 18}` |
| 统一错误体 | 未知模型 → 404，`code=MODEL_NOT_FOUND`，含 `request_id`、`retryable=false` |
| 指标覆盖 | 两个适配器 `status="ok"` 计数 + 6 个直方图齐全；`llm.call` 里 `cache_read=128`（DeepSeek 提示词缓存命中被单独计数） |
| 日志无密钥泄漏 | 83 行日志中不含密钥字符串 |

由此顺带修正了仓库默认配置：`config/routes.yaml` 中 `deepseek-v4-flash` 的真实模型 id 是 `deepseek-flash`，且 Anthropic 兼容端点必须带 `/anthropic` 前缀（原配置指向 `https://api.deepseek.com` 会 404）。网关对外别名 `deepseek-v4-flash` 保持不变。

## 与设计文档的偏差

1. **清单数量口径不一致**：DESIGN §13 标题下实际是 10 条，`IMPLEMENTATION_PLAN.md` Stage 7 与 `stage-6.md` 的「13 条」是笔误。本阶段按 10 条逐条验收，未凑数。
2. **e2e 场景 10 个 > 计划 8 个**：计划写 8 个场景，实际拆成 10 个（清单 3 与 9 合并进一个用例后，另补客户端断开与两处独立断言），覆盖率高于计划。
3. **`/readyz` 仍未实现**：DESIGN 提过就绪探针，当前只有 `/healthz`；`README.md`「已知限制」已标注。
4. **Fallback 切换仍未实现**：Stage 6 遗留项，本阶段只验证了「重试失败后统一错误体」，未做备用上游切换。
5. **`X-RateLimit-*` 响应头未下发**：429 只带 `Retry-After`；信息型响应头未补。
6. **Redis 限流与鉴权未实现**：仍是内存实现 + 接口预留；压测数据仅代表单实例。
7. **压测为 mock 上游**：`scripts/bench.py` 的数值反映的是网关自身开销（限流、SSE 编码、指标记录），不代表真实厂商延迟；真实上游需申请 API Key 后再验证。

## 下一步（v2 建议）

1. 接真实上游做一次端到端验证（需要用户提供 API Key，仅通过 `GW_*` 环境变量注入，不落盘）。
2. fallback 路由与 `upstream_switched` 标记。
3. `X-RateLimit-*` 响应头 + `GET /readyz`。
4. Redis Lua 版 `RateLimiter` 与 `api_key_id + model` 二级 key，支撑多实例。
5. 流式结构化输出的增量 JSON 解析（当前只在终态给 `structured`）。
