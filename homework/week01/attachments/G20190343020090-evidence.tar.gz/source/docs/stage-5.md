# Stage 5 · 可观测性补全

## 做了什么

新增/修改文件：

| 文件 | 改动 |
|---|---|
| `src/gateway/telemetry/usage.py` | 新增：Token 五分类展开、`len(text)/4` 估算兜底、`reported/estimated` 决策、按价格表换算费用 |
| `src/gateway/telemetry/metrics.py` | 新增：9 个 Prometheus 指标（请求/Tokens/费用 + 6 个延迟直方图）、`observe_call()` 统一观测入口、日志组装与采样 |
| `src/gateway/telemetry/timing.py` | 补全 6 个延迟指标：新增 `latency_snapshot()`，`StreamTiming` 读取 `CallContext` 的排队/重试开销与上游发出时刻 |
| `src/gateway/api/routers/metrics.py` | 新增：`GET /metrics`（Prometheus 文本格式，不进 OpenAPI） |
| `src/gateway/api/routers/chat.py` | 非流式成功/失败路径接入 `observe_call`；流式预检失败也记指标 |
| `src/gateway/api/routers/sse.py` | 流式路径接入观测：正常终态、上游 error、静默超时、客户端断开、无终态断流五种收尾都入账 |
| `src/gateway/core/ir.py` | `CallContext` 新增 `upstream_started_at` / `queue_wait_ms` / `retry_overhead_ms` / `retry_count` |
| `src/gateway/core/invoker.py` | 上游请求发出时打点；非流式延迟改用 `latency_snapshot()` |
| `src/gateway/core/router.py` + `config/routes.yaml` | 路由新增可选 `pricing`（每百万 token 价格），用于费用估算 |
| `src/gateway/main.py` | 装配 `app.state.metrics`，注册 `/metrics` 路由 |
| `tests/telemetry/test_usage.py` | 新增 10 个用例（五分类/估算/上报优先/中断标记/费用换算） |
| `tests/telemetry/test_metrics.py` | 新增 7 个用例（指标打点/TTFT 不混入失败/估算入账/采样/导出/端点） |

关键实现点：

- **五分类口径**：`input` / `output` / `reasoning` / `cache_read` / `cache_write` 直接落到 `llm_tokens_total{model,type,source}`；适配器侧此前已按 DESIGN §7.1 完成字段映射，本阶段只做展开与导出。
- **上报优先、估算兜底**：`finalize_usage()` 是唯一裁决点——`status=ok` 且上游给了 usage 就原样入账（`reported`）；`error` / `client_aborted` / 上游缺 usage 一律改用 `len(累积文本)/4`，并强制 `source="estimated"`。零文本时保留上游已报的 output，不会把账单清零。
- **失败不进 TTFT**：`latency.ttft_ms` 只有在真正收到首个 delta 时才非空；直方图只 observe 非空值，所在失败请求只产生 `llm_request_duration_ms` 样本（DoD 用例已断言 `llm_ttft_ms_count == 0`）。
- **6 个延迟指标**：`ttft_ms`（含排队与重试，用户体感）、`upstream_ttft_ms`（首 delta − 上游请求发出）、`queue_wait_ms`、`retry_overhead_ms`、`total_ms`、`tpot_ms`，统一分桶 `[50,100,250,500,1000,2000,5000,10000,30000]`。后两个开销指标本阶段已完成数据通路，实际值由 Stage 6 的限流/重试层回填 `CallContext`。
- **观测单入口**：`observe_call()` 内先算最终用量，再「指标全量 + 日志按采样」，避免两条路径各写一遍打点逻辑。
- **采样规则**：`status != ok` 或 `retry_count > 0` 时 100% 落日志；成功请求按 `logging.sample_rate`（默认 0.1）抽样；**计数器不采样**（指标全量，只省日志）。
- **日志字段**：`llm.call` 按 DESIGN §7.3 输出 `request_id` / `model` / `adapter` / `upstream_model` / `prompt{name,version,checksum}` / `stream` / `structured_mode` / `usage`（短名五分类 + source）/ `ttft_ms` / `upstream_ttft_ms` / `total_ms` / `queue_wait_ms` / `retry_overhead_ms` / `retry_count` / `status` / `error_code` / `client_aborted`。
- **脱敏**：`messages` 默认只落 `count` / `chars` / `sha256` 前 16 位；`debug=true` 才落原文（验收时开了 debug，输出里能看到 `content`）。

## 怎么验

```bash
# 新增用例
cd /root/LLMGateway && /root/.local/bin/uv run pytest tests/telemetry -v

# 全量回归
cd /root/LLMGateway && /root/.local/bin/uv run pytest

# 运行时验收：mock 上游 8010 + 网关 8004（SQLite 落 /tmp/llmgw-stage5，日志采样率置 1.0）
cd /root/LLMGateway && /root/.local/bin/uv run python /tmp/accept5.py
grep llm.call /tmp/gw5.log | head -2
```

## 实测输出

```text
tests/telemetry/test_usage.py ......                                   [100%]
tests/telemetry/test_metrics.py .......                                [100%]

全量：147 passed, 1 warning in 3.62s（Stage 4 为 130，本阶段新增 17）
```

运行时验收（网关 8004 + mock 上游 8010）：

```text
[1] non-stream status 200
    usage= {'input_tokens': 20, 'output_tokens': 10, 'reasoning_tokens': 0,
            'cache_read_tokens': 0, 'cache_write_tokens': 0, 'total_tokens': 30, 'source': 'reported'}
    latency= {'total_ms': 6.3}

[2] stream status 200 content-type text/event-stream; charset=utf-8
    frame count 5
    final gateway latency= {'total_ms': 607.9, 'ttft_ms': 205.98,
                            'upstream_ttft_ms': 205.09, 'tpot_ms': 44.66}
    final usage= {'prompt_tokens': 20, 'completion_tokens': 10, 'total_tokens': 30, 'source': 'reported'}

[3] unknown model status 404 MODEL_NOT_FOUND

[4] metrics status 200 llm_ lines 105
     llm_requests_total{adapter="anthropic_messages",model="deepseek-v4-flash",status="ok"} 1.0
     llm_requests_total{adapter="openai_responses",model="deepseek-v4-pro",status="ok"} 1.0
     llm_requests_total{adapter="unknown",model="no-such-model",status="error"} 1.0
     llm_tokens_total{model="deepseek-v4-flash",source="reported",type="input"} 20.0
     llm_tokens_total{model="deepseek-v4-flash",source="reported",type="output"} 10.0
     llm_tokens_total{model="deepseek-v4-flash",source="reported",type="reasoning"} 0.0
     llm_tokens_total{model="deepseek-v4-flash",source="reported",type="cache_read"} 0.0
     llm_tokens_total{model="deepseek-v4-flash",source="reported",type="cache_write"} 0.0
     llm_tokens_total{model="no-such-model",source="estimated",type="input"} 0.0
     llm_cost_estimate_total{currency="USD",model="deepseek-v4-flash"} 5.600000000000001e-06
     llm_cost_estimate_total{currency="USD",model="deepseek-v4-pro"} 3.29e-05
     llm_request_duration_ms_count{adapter="anthropic_messages",model="deepseek-v4-flash"} 1.0
     llm_request_duration_ms_count{adapter="openai_responses",model="deepseek-v4-pro"} 1.0
     llm_ttft_ms_count{adapter="openai_responses",model="deepseek-v4-pro"} 1.0
     llm_ttft_ms_sum{adapter="openai_responses",model="deepseek-v4-pro"} 205.98
CHECK llm_tokens_total present: True
CHECK all six latency metrics present: True
```

`llm.call` 日志（`debug=true`，故带 `messages.content`；默认只落 hash）：

```json
{"request_id":"req_cb3aa8...","model":"deepseek-v4-pro","adapter":"openai_responses",
 "upstream_model":"deepseek-v4-pro","stream":true,"structured_mode":null,
 "usage":{"input":20,"output":10,"reasoning":0,"cache_read":0,"cache_write":0,"source":"reported"},
 "ttft_ms":205.98,"upstream_ttft_ms":205.09,"total_ms":607.9,"queue_wait_ms":null,
 "retry_overhead_ms":null,"retry_count":0,"status":"ok","error_code":null,
 "client_aborted":false,"prompt":null,
 "messages":{"count":1,"chars":2,"sha256":"sha256:8f434346648f6b96"},
 "event":"llm.call","level":"info","ts":"2026-11-01T16:02:52.740+08:00"}
```

## 与设计文档的偏差

1. **非流式不产生 TTFT / upstream_ttft / tpot 样本**：DESIGN §7.2 把 TTFT 定义为「首个文本 delta − t0」，非流式请求没有 delta，硬造一个「首字节」会污染两个指标的口径，因此非流式只记 `total_ms`。
2. **费用指标依赖路由价格表**：新增可选 `pricing` 配置；未配置的路由**不产生** `llm_cost_estimate_total` 样本，而不是记 0——避免把「没配价格」误读成「免费」。价格是示意值，接真实环境需替换。
3. **失败请求也写五分类 0 值**：`llm_tokens_total` 全量打点，失败的零值样本能反映请求量；但 TTFT 直方图严格只收非空值。
4. **模型未命中时 adapter 标签为 `unknown`**：模型解析失败发生在路由之前，此时仍要计数（否则请求量统计漏掉 404），用 `unknown` 占位保持 label 集合封闭。
5. **`queue_wait_ms` / `retry_overhead_ms` 本阶段只建通路**：`CallContext` 字段已就位，`observe_call` 有值即上报；真实数值由 Stage 6 的限流与重试层写入，因此现在恒为 `null` / 不产生样本。
6. **日志采样作用于成功请求**：默认 `0.1`；错误、重试、客户端断开全量。指标不受采样影响。
7. **`/metrics` 不进 OpenAPI**：`include_in_schema=False`，避免把它当业务接口暴露给客户端。

## 下一步

Stage 6 · 韧性：可重试白名单 + full jitter 退避 + `Retry-After`、开流不重试、按模型三道闸限流（RPM/TPM/并发）。本阶段预留的 `CallContext.retry_count` / `queue_wait_ms` / `retry_overhead_ms` 将在此阶段被真正赋值，日志里的 `retry_count`、`retry_skipped_reason`、`rate_limited_by` 也随之有据可查。
