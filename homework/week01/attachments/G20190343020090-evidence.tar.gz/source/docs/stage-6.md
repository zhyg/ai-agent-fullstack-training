# Stage 6 · 韧性（重试 + 限流）

## 做了什么

新增/修改文件：

| 文件 | 改动 |
|---|---|
| `src/gateway/resilience/__init__.py` | 新增：包说明 + 对外导出重试/限流组件 |
| `src/gateway/resilience/retry.py` | 新增：可重试白名单、full jitter 退避、`Retry-After` 解析、总预算判定、`execute()` 执行器 |
| `src/gateway/resilience/ratelimit.py` | 新增：`RateLimiter` Protocol、内存双令牌桶 + 并发信号量、TPM 预扣与多退少补、`RateLease` 幂等归还 |
| `src/gateway/core/ir.py` | `CallContext` 新增 `retry_skipped_reason`（记录拒绝重试的原因） |
| `src/gateway/core/invoker.py` | 非流式与 L3 修复循环接入 `RetryPolicy`；流式改为「开流前缓存事件」的重试循环；上游 `retry-after` 头透传进归一化错误 |
| `src/gateway/api/routers/chat.py` | 在「开流之前」取限流租约；成功/失败/预检失败三条路径都归还租约并记录决策 |
| `src/gateway/api/routers/sse.py` | 流式收尾归还租约，拿到终态 usage 才按实测校正 TPM |
| `src/gateway/telemetry/metrics.py` | `CallObservation` 增加 `retry_skipped_reason` / `rate_limited_by`，转为 `llm.call` 日志字段 |
| `src/gateway/main.py` | 装配 `RetryPolicy` 与 `MemoryRateLimiter`，支持注入替换（Redis 实现只需换这一个对象） |
| `tests/resilience/test_retry.py` | 新增 12 个用例（白名单/抖动边界/拒绝原因/执行器/Gateway 非流式与流式） |
| `tests/resilience/test_ratelimit.py` | 新增 9 个用例（三道闸、模型隔离、TPM 校正、API 层 429） |

关键实现点：

- **重试由 `Gateway` 显式注入**：`Gateway.__init__(..., retry: RetryPolicy | None = None)`，默认 None。`create_app` 才按配置装配；直连 `Gateway` 的单测不受退避 sleep 拖慢。
- **白名单判定**：HTTP `408/409/429/500/502/503/504/529` 与网关错误码 `UPSTREAM_TIMEOUT` / `UPSTREAM_UNAVAILABLE` / `UPSTREAM_BAD_RESPONSE` / `STREAM_INTERRUPTED` / `RATE_LIMITED` 可重试，400 类一律不重试。
- **full jitter**：`delay = rng() * min(max_delay, base * multiplier^(attempt-1))`；上游给了 `Retry-After` 就以它为准，但仍受 `max_delay` 封顶。
- **总预算**：`ctx.deadline` 优先，否则 `total_deadline_ms` 从请求开始计；超预算直接放弃并把原因写入 `retry_skipped_reason=deadline`。
- **开流不重试**：流式在第一个 `delta` 之前把事件缓存在本地，失败则整段丢弃后重试；一旦 `ctx.stream_started=True`，不再重试，改为把 `GatewayError` 抛给 SSE 层发 `error` 帧。日志记 `retry_skipped_reason=stream_started`。
- **限流放在 API 层、开流之前**：SSE 已返回 200 后无法改状态码，因此限流必须在 `prepare()` 之前完成。超限直接 `429 RATE_LIMITED` + `Retry-After`（HTTP 头），流式客户端也能拿到正确的状态码。
- **三道闸**：RPM 令牌桶 → TPM 令牌桶（按估算 input 预扣）→ 并发信号量（`max_queue_wait_ms` 内排队，超时 429）。每个 `route.model` 一套独立状态，flash 打满不影响 pro。
- **TPM 多退少补**：非流式按 `usage.total_tokens` 校正；流式只有拿到终态 usage 才校正；中断/失败保留预扣值，避免失败请求白嫖配额。
- **网关自己的 429 不触发上游重试**：限流在 API 层执行，早于 `RetryPolicy`，因此重试器只对上游 429 退避。
- **决策留痕**：`llm.call` 日志新增 `retry_count` / `retry_skipped_reason` / `rate_limited_by`；每次退避另有一条 `upstream.retry`（含 `attempt` / `next_attempt` / `delay_ms` / `error_code` / `stream`）。

## 怎么验

```bash
# 新增用例
cd /root/LLMGateway && /root/.local/bin/uv run pytest tests/resilience -q

# 全量回归
cd /root/LLMGateway && /root/.local/bin/uv run pytest

# 运行时验收：mock 上游 8010 + 网关 8004（退避压到 200ms 起、800ms 封顶，便于观测）
cd /root/LLMGateway && bash /tmp/run_accept6.sh
grep 'upstream.retry' /tmp/gw6.log | head -3
grep 'rate_limited_by' /tmp/gw6.log | head -2
```

验收覆盖的注入场景（`mock6.py`）：

| 模型 | 上游行为 | 期望 |
|---|---|---|
| `deepseek-v4-flaky` | 连续 2 次 529（带 `Retry-After: 0.1`）后成功 | 最终 200，`retry_count=2`，mock 收到 3 次 |
| `deepseek-v4-flaky-stream` | 首个 delta 前 1 次 529 | 流式重试成功，delta 不重复，mock 收到 2 次 |
| `deepseek-v4-bad` | 400 | 不重试，`UPSTREAM_BAD_REQUEST`，mock 只收到 1 次 |
| `deepseek-v4-cut` | 吐完 delta 即断流 | `STREAM_INTERRUPTED` error 帧，`retry_skipped_reason=stream_started`，mock 只收到 1 次 |
| `deepseek-v4-flash` | rpm=3 | 第 4 次 429 + `Retry-After`，同刻 pro 仍 200 |

## 实测输出

```text
tests/resilience/test_ratelimit.py: 9
tests/resilience/test_retry.py: 12

全量：168 passed, 1 warning in 3.33s（Stage 5 为 147，本阶段新增 21）
```

运行时验收（网关 8004 + mock 上游 8010）：

```text
== [1] flaky 非流式：上游 529 × 2 后成功 ==
    status 200
    text= 你好，我是网关。
    usage= {'input_tokens': 20, 'output_tokens': 10, ..., 'source': 'reported'}
    latency= {'total_ms': 221.7, 'queue_wait_ms': 0.05, 'retry_overhead_ms': 200.0}

== [2] flaky-stream 流式：开流前 1 次 529，重试后成功且 delta 不重复 ==
    frame count 5 errors []
    delta text= 你好，我是网关。
    final gateway= {'total_ms': 154.2, 'ttft_ms': 152.92, 'upstream_ttft_ms': 4.77,
                    'queue_wait_ms': 0.07, 'retry_overhead_ms': 100.0, 'tpot_ms': 0.14}
    CHECK delta no duplicate: True

== [3] flash rpm=3 打满 → 429 + Retry-After；pro 同时正常 ==
    flash #1 200 / #2 200 / #3 200
    flash #4 status 429 code RATE_LIMITED
    Retry-After= 20
    rate_limited_by= rpm
    pro status 200 text= 你好，我是网关。

== [4] bad：上游 400 → 不重试 ==
    status 400 code UPSTREAM_BAD_REQUEST

== [5] cut：已吐 delta 后上游断流 → 不重试，error 事件 ==
    frame count 5 delta text= 你好，我是网关。
    error codes= ['STREAM_INTERRUPTED']

== [6] /metrics 与决策留痕 ==
     llm_requests_total{adapter="anthropic_messages",model="deepseek-v4-flash",status="ok"} 3.0
     llm_requests_total{adapter="anthropic_messages",model="deepseek-v4-flash",status="error"} 1.0
     llm_retry_overhead_ms_count{adapter="openai_responses",model="deepseek-v4-flaky"} 1.0
     llm_retry_overhead_ms_sum{adapter="openai_responses",model="deepseek-v4-flaky"} 200.0
     llm_retry_overhead_ms_count{adapter="openai_responses",model="deepseek-v4-flaky-stream"} 1.0
     llm_retry_overhead_ms_sum{adapter="openai_responses",model="deepseek-v4-flaky-stream"} 100.0
CHECK llm_retry_overhead_ms present: True
CHECK llm_queue_wait_ms present: True

--- mock 上游请求次数（重试应多打，不重试应只有 1 次）---
flaky-model: 3
flaky-stream-model: 2
bad-model: 1
cut-model: 1
deepseek-v4-flash: 3
deepseek-v4-pro: 1
```

`upstream.retry` 日志（3 条：非流式 2 条 + 流式 1 条）：

```json
{"request_id":"req_4d684e57616804ec66b5b669","attempt":1,"next_attempt":2,"delay_ms":100.0,
 "error_code":"UPSTREAM_UNAVAILABLE","stream":false,"event":"upstream.retry","level":"warning"}
{"request_id":"req_4d684e57616804ec66b5b669","attempt":2,"next_attempt":3,"delay_ms":100.0,
 "error_code":"UPSTREAM_UNAVAILABLE","stream":false,"event":"upstream.retry","level":"warning"}
{"request_id":"req_ba9d30e616d9e55b4c7f1183","attempt":1,"next_attempt":2,"delay_ms":100.0,
 "error_code":"UPSTREAM_UNAVAILABLE","stream":true,"event":"upstream.retry","level":"warning"}
```

`llm.call` 中的决策字段（三次采样：成功重试 / 开流后断流 / 限流拒绝）：

```json
{"model":"deepseek-v4-flaky","retry_count":2,"retry_skipped_reason":null,"rate_limited_by":null,
 "retry_overhead_ms":200.0,"status":"ok"}
{"model":"deepseek-v4-cut","retry_count":0,"retry_skipped_reason":"stream_started",
 "error_code":"STREAM_INTERRUPTED","status":"error"}
{"model":"deepseek-v4-flash","retry_count":0,"retry_skipped_reason":null,
 "rate_limited_by":"rpm","error_code":"RATE_LIMITED","status":"error"}
```

## 与设计文档的偏差

1. **Fallback 切换未实现**：DESIGN §8.2 描述了「连续失败 2 次切备用上游 + `upstream_switched=true`」，但本阶段 In scope 未列入 fallback，`config/routes.yaml` 也没有 `fallback` 配置，故未实现。`ModelRoute` 后续增加 `fallback` 字段即可在 `RetryPolicy.execute()` 外层接入。
2. **限流在 API 层而非调用器内**：为了保证流式请求超限也能返回 HTTP 429（SSE 开流后只能改错误事件），限流租约在 chat 路由内获取/归还。`Gateway` 自身不感知限流，直连调用器不经过三道闸。
3. **TPM 只按输入估算预扣**：按 DESIGN §8.3「请求前按预估 input 预扣」，预扣只算 `system + messages` 文本（约 4 字符/token），不含输出预算；实际用量在响应后按 `usage.total_tokens` 校正。估算偏差在首次请求上可能偏小。
4. **`X-RateLimit-*` 响应头未下发**：DESIGN §8.3 列了 `X-RateLimit-Limit-Requests` / `-Remaining` / `-Reset`；本阶段只保证 429 带 `Retry-After`（限流核心行为），信息型响应头留待 Stage 7 与文档一起补。
5. **两级 key 只落地了一级**：当前 key 为 `model`；`api_key_id + model` 的二级 key 需要网关侧 API Key 体系（DESIGN 中尚属后续能力），本阶段未启用。
6. **Redis 实现只在接口层预留**：交付了 `RateLimiter` Protocol 与可注入的 `app.state.limiter`，未提供 `RedisRateLimiter` 与 Lua 脚本（计划中标注「接口预留，可后补」）。
7. **流式重试会缓冲事件**：开流前的事件先存在本地列表，只有拿到首个 `delta` 才下发给客户端。这带来极小的首包延迟（仅为同批次事件），换来「失败重试不重复文本」。

## 下一步

Stage 7 · 端到端验收与固化：对照 DESIGN §13 的 13 条清单逐条核对，补故障注入 e2e、`scripts/bench.py` 压测与 `README.md` 使用文档；同时补齐本阶段留下的 fallback 与 `X-RateLimit-*` 响应头。
