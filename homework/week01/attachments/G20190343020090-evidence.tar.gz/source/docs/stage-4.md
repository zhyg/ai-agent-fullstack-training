# Stage 4 · 提示词版本管理

## 做了什么

新增/修改文件：

| 文件 | 改动 |
|---|---|
| `src/gateway/prompt/models.py` | 新增：`prompt_templates` 表结构、`PromptTemplate` / `PromptVariable`、`sha256:` checksum |
| `src/gateway/prompt/store.py` | 新增：`PromptStore` Protocol + `SQLiteStore`（版本自增、active 原子切换、draft 可改/发布不可变、checksum 反查） |
| `src/gateway/prompt/resolver.py` | 新增：版本引用解析（latest/active/精确/`name@3`）、变量校验、Jinja2 `SandboxedEnvironment` 渲染、LRU+TTL 缓存 |
| `src/gateway/api/routers/prompts.py` | 新增：DESIGN §6.4 的 6 个管理接口（创建/列表/详情/版本/激活/干跑渲染） |
| `src/gateway/api/routers/chat.py` | `prompt_ref` + `variables` 接入；渲染结果作为 base message 与请求 `messages` 合并；模板 `response_schema` 自动套用；响应回显 `prompt` |
| `src/gateway/core/ir.py` | `CanonicalRequest` / `CanonicalResponse` 新增 `prompt` 字段并回显 |
| `src/gateway/core/events.py` + `api/routers/sse.py` | 终态事件/终态 chunk 携带 `prompt{name,version,checksum}` |
| `src/gateway/core/invoker.py` | 非流式与流式均把 `req.prompt` 挂到响应/终态事件 |
| `src/gateway/config.py` + `config/gateway.yaml` | 新增 `prompt.db_path` / `cache_size=256` / `cache_ttl_s=60` |
| `src/gateway/main.py` | 装配 `SQLiteStore` + `PromptResolver`，注册 prompts 路由，支持测试注入存储 |
| `src/gateway/core/errors.py` | 修复请求校验错误 `ctx` 含异常对象导致 JSON 序列化 500 的问题 |
| `tests/prompt/test_resolver.py` | 新增 29 个用例（存储/引用/渲染/缓存/管理 API/chat 集成） |

关键实现点：

- **不可变版本**：`SQLiteStore.update_content()` 只允许改 `draft`；`active`/`deprecated` 版本改内容直接返回 `400 INVALID_REQUEST`，必须创建新版本。
- **checksum 可复现**：`checksum = "sha256:" + sha256(content)`；`find_by_checksum()` 支持用线上日志里的 checksum 反查出确切模板（DoD 已实测）。
- **四种版本引用**：`latest` / `active` / 精确版本号 / `name@3` 字符串简写；解析不到返回 `404 PROMPT_NOT_FOUND`，message 内回显 `available versions` 与 `active`（`details` 仅在 debug 透出）。
- **沙箱渲染**：`SandboxedEnvironment(autoescape=False)`；访问 `__class__` 等内部属性会得到 `UnsafeUndefined`，一旦调用即抛 `SecurityError` → 归一为 `400 INVALID_REQUEST`。
- **变量规则**：`required` 且无默认值的变量缺失 → `400 MISSING_VARIABLE`；未声明但传入的变量忽略并打 `prompt.variables_ignored` 告警；声明了 `default` 的变量可省略。
- **合并规则**：模板渲染文本作为 base user message，请求里的 `messages` 追加在后；两者都不给 → `400 INVALID_REQUEST`。
- **schema 联动**：请求未显式指定 `response_format` 时自动套用模板的 `response_schema`，直接复用 Stage 3 的 lint/档位/校验链路；创建模板时也先做一次兼容子集 lint。
- **缓存**：LRU(256) + TTL 60s，按 `name:version_sep` 缓存；本实例创建新版本或 `activate` 时主动失效该 name。跨进程变更靠 TTL 收敛。
- **响应回显**：非流式 `prompt` 字段；流式只出现在终态 chunk，与 `structured` 的规则一致。

## 怎么验

```bash
# 单元 / API / 集成测试（远程）
cd /root/LLMGateway && /root/.local/bin/uv run pytest tests/prompt -v

# 全量回归
cd /root/LLMGateway && /root/.local/bin/uv run pytest

# 运行时验收：mock 上游 8010 + 网关 8004（SQLite 落 /tmp/llmgw-stage4）
tr -d '\r' < /tmp/run_accept_stage4.sh | bash
```

## 实测输出

```
tests/prompt/test_resolver.py .............................              [100%]

全量：130 passed, 1 warning in 3.07s（Stage 3 为 101，本阶段新增 29）
```

运行时验收（网关 8004 + mock 上游 8010）：

```text
=== 1) 创建 v1(draft) / v2(active)：同 name 自动 +1 ===
{"name": "summarize", "version": 1, "status": "draft", "checksum": "sha256:56f9..."}
{"name": "summarize", "version": 2, "status": "active", "checksum": "sha256:70eb..."}

=== 2) 列表 / 详情 / 指定版本 ===
{"name": "summarize", "versions": 2, "latest_version": 2, "active_version": 2}
{"version": 1, "content": "请用中文总结：{{ text }}"}

=== 3) 干跑渲染（默认 active，不调模型）===
{"version": 2, "rendered": "请用一句话总结：网关超时", "ignored": ["txet"]}

=== 4) 必填变量缺失 → 400 MISSING_VARIABLE ===
{"code": "MISSING_VARIABLE", "missing": ["text"]}

=== 5) 已发布版本不可变（active 版本改内容 → 拒绝）===
{"immutable": true, "code": "INVALID_REQUEST"}

=== 6) 引用不存在版本 → 404 PROMPT_NOT_FOUND ===
{"code": "PROMPT_NOT_FOUND", "message": "prompt 'summarize' version '9' not found; available versions: [1, 2], active: 2"}

=== 7) chat + prompt_ref：响应回显 prompt ===
{"text": "{\"title\":\"网关超时\",\"priority\":2}",
 "prompt": {"name": "summarize", "version": 2, "checksum": "sha256:70eb..."}}

=== 8) DoD：用日志里的 checksum 反查模板内容 ===
{"name": "summarize", "version": 2, "content": "请用一句话总结：{{ text }}", "checksum_matches": true}

=== 9) 模板预置 response_schema 与结构化输出联动 ===
{"structured": {"title": "网关超时", "priority": 2}, "structured_mode": "native_schema",
 "prompt": {"name": "issue", "version": 1, "checksum": "sha256:4513..."}}

=== 10) 流式终态 chunk 回显 prompt ===
{"delta_chunks": 3, "final_prompt": {"name": "summarize", "version": 2, "checksum": "sha256:70eb..."}}

=== 11) 既无 messages 也无 prompt_ref → 400 INVALID_REQUEST ===
=== 12) 未声明变量告警 ===
"event": "prompt.variables_ignored", "level": "warning"
```

## 与设计文档的偏差

1. **模板渲染结果视为单条 base user message**：DESIGN §6.1 表结构只有 `content`，没有独立的 system 列；请求自带的 `system` 仍走 `CanonicalRequest.system`。这样模板保持「一段 Jinja2 文本」的最简形态。
2. **未新增 HTTP 更新接口**：DESIGN §6.4 只定义 6 个接口，没有「修改版本」入口；不可变性在存储层强制（`update_content` 仅 draft 可改），运行时验收通过直接调用存储层验证拒绝。生产环境改提示词的方式是 `POST /v1/prompts` 生成新版本。
3. **activate 只降级旧的 active**：把目标设为 active 时，此前 `active` 的版本变 `deprecated`；此前仍是 `draft` 的版本保持 `draft`（未发布就不算被取代）。
4. **错误 message 自解释可用版本**：统一错误体默认不透出 `details`（与 Stage 3 一致），因此 404 message 里直接写出 `available versions` 与 `active`，`details` 仍只在 debug 下返回。
5. **缓存失效是实例内行为**：本进程创建版本/激活时主动失效；多进程部署依赖 60s TTL 收敛（以及后续换共享存储时的失效通知）。
6. **`prompt_ref` 增加字符串简写**：除 DESIGN 的 `{name, version}` 外，接受 `"name@3"` / `"name"`，兼容外部系统传参。
7. **顺带修复统一错误体的序列化缺陷**：pydantic `RequestValidationError.errors()` 的 `ctx` 可能含 `ValueError` 对象，`debug=true` 时放进 `details` 会导致二次 500；现在统一转成字符串。该问题由新增的「messages 与 prompt_ref 都缺失」用例暴露。

## 下一步

Stage 5 · 可观测性补全：Token 五分类映射、`reported/estimated` 标记、6 个延迟指标、Prometheus `/metrics`、日志字段与采样；同时把 Stage 4 的 `prompt{name,version,checksum}` 正式写入 `llm.call` 日志。
