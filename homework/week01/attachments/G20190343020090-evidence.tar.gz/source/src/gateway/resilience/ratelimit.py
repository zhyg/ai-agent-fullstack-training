"""按模型独立的三道闸限流（DESIGN.md §8.3）。

| 闸 | 算法 | 超限 |
|---|---|---|
| RPM | 令牌桶 `capacity=rpm`，`refill=rpm/60` per sec | 429 RATE_LIMITED |
| TPM | 令牌桶 `capacity=tpm`；请求前按预估 input 预扣，响应后按实测多退少补 | 429 RATE_LIMITED |
| 并发 | 信号量；排队超 `max_queue_wait_ms` | 429 RATE_LIMITED |

每个模型一套状态，flash 打满不影响 pro。单机用内存实现（零依赖）；
多实例部署实现同一个 `RateLimiter` Protocol 即可换成 Redis + Lua 原子扣减。
限流返回的 429 是网关自身行为，**不进入上游重试执行器**。
"""

from __future__ import annotations

import asyncio
import math
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Protocol

from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.ir import CanonicalRequest
from gateway.core.router import RouteLimits
from gateway.resilience.retry import retry_after_header
from gateway.telemetry.usage import estimate_tokens


def estimate_request_tokens(req: CanonicalRequest) -> int:
    """TPM 预扣口径：只按输入文本估算（system + 全部消息），保守近似 4 字符/token。

    输出 token 无法事先知道，因此预扣只覆盖输入；实测 usage 在 `release()` 里多退少补。
    """

    parts = [req.system or ""]
    parts.extend(message.content for message in req.messages)
    return estimate_tokens("\n".join(parts))


class RateLimiter(Protocol):
    """限流器接口；Redis 实现只需满足同一签名。"""

    async def acquire(
        self,
        *,
        model: str,
        limits: RouteLimits,
        estimated_tokens: int,
        max_queue_wait_ms: int,
    ) -> "RateLease": ...


@dataclass
class RateLease:
    """一次放行凭证；必须 `release()` 归还并发名额并按实测用量校正 TPM。"""

    queue_wait_ms: float = 0.0
    _release: Callable[[int | None], None] | None = field(default=None, repr=False)
    _released: bool = field(default=False, repr=False)

    def release(self, actual_tokens: int | None = None) -> None:
        if self._released or self._release is None:
            return
        self._released = True
        self._release(actual_tokens)


class _Bucket:
    """令牌桶：容量固定，按每秒速率线性补充，允许负数表示「透支待还」。"""

    __slots__ = ("tokens", "updated_at")

    def __init__(self, capacity: float, now: float) -> None:
        self.tokens = float(capacity)
        self.updated_at = now

    def refill(self, capacity: float, rate_per_s: float, now: float) -> None:
        elapsed = max(now - self.updated_at, 0.0)
        self.updated_at = now
        self.tokens = min(float(capacity), self.tokens + elapsed * rate_per_s)

    def wait_seconds(self, needed: float, rate_per_s: float) -> float:
        if rate_per_s <= 0:
            return float("inf")
        return max(needed - self.tokens, 0.0) / rate_per_s


class _ModelState:
    __slots__ = ("rpm", "tpm", "semaphore")

    def __init__(self, limits: RouteLimits, now: float) -> None:
        self.rpm = _Bucket(limits.rpm, now)
        self.tpm = _Bucket(limits.tpm, now)
        self.semaphore = asyncio.Semaphore(limits.concurrent)


class MemoryRateLimiter:
    """单机限流实现；`clock` / `sleep` 可注入，便于测试时间相关行为。"""

    def __init__(
        self,
        *,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self._clock = clock
        self._sleep = sleep
        self._models: dict[str, _ModelState] = {}

    def _state(self, model: str, limits: RouteLimits) -> _ModelState:
        state = self._models.get(model)
        if state is None:
            state = _ModelState(limits, self._clock())
            self._models[model] = state
        return state

    async def acquire(
        self,
        *,
        model: str,
        limits: RouteLimits,
        estimated_tokens: int,
        max_queue_wait_ms: int,
    ) -> RateLease:
        state = self._state(model, limits)
        now = self._clock()
        state.rpm.refill(limits.rpm, limits.rpm / 60.0, now)
        state.tpm.refill(limits.tpm, limits.tpm / 60.0, now)

        if state.rpm.tokens < 1.0:
            raise _rate_limited(
                model,
                "rpm",
                state.rpm.wait_seconds(1.0, limits.rpm / 60.0),
                remaining=state.rpm.tokens,
            )
        if state.tpm.tokens < estimated_tokens:
            raise _rate_limited(
                model,
                "tpm",
                state.tpm.wait_seconds(estimated_tokens, limits.tpm / 60.0),
                remaining=state.tpm.tokens,
            )

        queue_started = self._clock()
        await self._acquire_slot(state, max_queue_wait_ms, model, limits)
        queue_wait_ms = round((self._clock() - queue_started) * 1000, 2)

        state.rpm.tokens -= 1.0
        state.tpm.tokens -= float(estimated_tokens)

        def _release(actual_tokens: int | None) -> None:
            state.semaphore.release()
            if actual_tokens is not None:
                # 多退少补：预估比实测多扣了就退还，超了就记透支
                state.tpm.tokens = min(
                    float(limits.tpm),
                    state.tpm.tokens + float(estimated_tokens - actual_tokens),
                )

        return RateLease(queue_wait_ms=queue_wait_ms, _release=_release)

    async def _acquire_slot(
        self,
        state: _ModelState,
        max_queue_wait_ms: int,
        model: str,
        limits: RouteLimits,
    ) -> None:
        """并发闸：允许排队，但排队超过 `max_queue_wait_ms` 即 429。"""

        if max_queue_wait_ms <= 0:
            if state.semaphore.locked():
                raise _rate_limited(model, "concurrent", 0.0, limit=limits.concurrent)
            await state.semaphore.acquire()
            return

        try:
            await asyncio.wait_for(
                state.semaphore.acquire(), timeout=max_queue_wait_ms / 1000
            )
        except (asyncio.TimeoutError, TimeoutError) as exc:
            raise _rate_limited(
                model,
                "concurrent",
                max_queue_wait_ms / 1000,
                limit=limits.concurrent,
            ) from exc


def _rate_limited(
    model: str,
    dimension: str,
    wait_seconds: float,
    *,
    limit: int | None = None,
    remaining: float | None = None,
) -> GatewayError:
    """限流错误：必须带 `Retry-After`，并在 details 里标出是哪道闸。"""

    retry_after = max(1, math.ceil(wait_seconds)) if math.isfinite(wait_seconds) else 1
    details = {"rate_limited_by": dimension, "model": model}
    if limit is not None:
        details["limit"] = limit
    if remaining is not None:
        details["remaining"] = round(remaining, 2)
    return GatewayError(
        ErrorCode.RATE_LIMITED,
        f"gateway rate limit exceeded ({dimension}) for model '{model}', retry later",
        details=details,
        headers={"Retry-After": retry_after_header(wait_seconds)},
    )
