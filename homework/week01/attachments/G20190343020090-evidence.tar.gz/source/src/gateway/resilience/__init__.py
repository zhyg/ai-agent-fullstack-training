"""韧性层：指数退避重试（`retry`）与按模型独立限流（`ratelimit`）。

设计见 DESIGN.md §8.2 / §8.3。本包只依赖 `core/`，不关心具体厂商协议；
API 层负责限流的 acquire/release，`Gateway` 负责把重试包在单次上游调用外。
"""

from gateway.resilience.ratelimit import (
    MemoryRateLimiter,
    RateLease,
    RateLimiter,
    estimate_request_tokens,
)
from gateway.resilience.retry import (
    RETRYABLE_CODES,
    RETRYABLE_STATUS,
    RetryDecision,
    RetryPolicy,
    is_retryable,
    retry_after_header,
)

__all__ = [
    "MemoryRateLimiter",
    "RETRYABLE_CODES",
    "RETRYABLE_STATUS",
    "RateLease",
    "RateLimiter",
    "RetryDecision",
    "RetryPolicy",
    "estimate_request_tokens",
    "is_retryable",
    "retry_after_header",
]
