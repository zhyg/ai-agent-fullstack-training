"""指数退避重试（DESIGN.md §8.2）。

约定：
- **白名单**判定：只对连接错误/超时、`408/409/429/500/502/503/504/529`
  以及归一后的可重试网关错误码重试；400 类一律不重试；
- **full jitter**：`sleep = uniform(0, min(max_delay, base * multiplier^(n-1)))`，
  避免多客户端同时重试造成尖峰；
- **尊重 `Retry-After`**：上游给了就以它为准（仍受 `max_delay` 限制）；
- **总预算** `total_deadline_ms` 用尽即放弃，不再退避；
- 流式只能在首个 delta 之前重试，由调用方传 `stream_started`，本模块给出拒绝原因。
"""

from __future__ import annotations

import asyncio
import math
import random
import time
from dataclasses import dataclass
from typing import Awaitable, Callable, TypeVar

import structlog

from gateway.config import RetrySettings
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.ir import CallContext

logger = structlog.get_logger("gateway.retry")

T = TypeVar("T")

# 可重试的上游 HTTP 状态码（DESIGN §8.2 白名单）
RETRYABLE_STATUS = frozenset({408, 409, 429, 500, 502, 503, 504, 529})

# 可重试的网关错误码；注意 RATE_LIMITED 只表示「客户端可稍后重试」，
# 网关自己的 429 不会进入重试执行器（见 DESIGN §8.3）。
RETRYABLE_CODES = frozenset(
    {
        ErrorCode.UPSTREAM_TIMEOUT.value,
        ErrorCode.UPSTREAM_UNAVAILABLE.value,
        ErrorCode.UPSTREAM_BAD_RESPONSE.value,
        ErrorCode.STREAM_INTERRUPTED.value,
        ErrorCode.RATE_LIMITED.value,
    }
)


@dataclass(frozen=True)
class RetryDecision:
    """一次重试裁决；`reason` 只在拒绝时给出，便于日志追溯。"""

    retry: bool
    delay_s: float = 0.0
    reason: str | None = None


def is_retryable(exc: GatewayError) -> bool:
    return exc.code in RETRYABLE_CODES


def retry_after_seconds(exc: GatewayError) -> float | None:
    """解析上游 `Retry-After`（秒数形态）；HTTP-date 形态不处理（两家上游均不用）。"""

    raw = None
    if exc.headers:
        # 适配器可能透传上游的原始大小写（retry-after），两种都接受
        raw = exc.headers.get("Retry-After") or exc.headers.get("retry-after")
    if not raw:
        return None
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return None
    return value if value >= 0 else None


class RetryPolicy:
    """重试策略与执行器；注入 `rng` / `sleep` 便于测试确定性。"""

    def __init__(
        self,
        settings: RetrySettings,
        *,
        rng: Callable[[], float] = random.random,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self.settings = settings
        self._rng = rng
        self._sleep = sleep

    def plan(
        self,
        exc: GatewayError,
        ctx: CallContext,
        attempt: int,
        *,
        stream_started: bool = False,
    ) -> RetryDecision:
        """判断这一次失败是否值得重试，并给出应等待的退避时长。"""

        if not is_retryable(exc):
            return RetryDecision(False, reason="not_retryable")
        if stream_started:
            # 已经吐出内容再重试会让客户端看到重复文本
            return RetryDecision(False, reason="stream_started")
        if attempt >= self.settings.max_attempts:
            return RetryDecision(False, reason="max_attempts")

        delay = self.delay_for(attempt, retry_after=retry_after_seconds(exc))
        if delay >= self.remaining_budget_s(ctx):
            return RetryDecision(False, reason="deadline")
        return RetryDecision(True, delay_s=delay)

    def delay_for(self, attempt: int, *, retry_after: float | None = None) -> float:
        """full jitter 退避；`attempt` 是刚失败的那次尝试序号（1 起）。"""

        if retry_after is not None:
            return min(retry_after, self.settings.max_delay_ms / 1000)
        cap_ms = min(
            self.settings.max_delay_ms,
            self.settings.base_delay_ms * self.settings.multiplier ** (attempt - 1),
        )
        return round(self._rng() * cap_ms / 1000, 3)

    def remaining_budget_s(self, ctx: CallContext) -> float:
        if ctx.deadline is not None:
            return ctx.deadline - time.perf_counter()
        return self.settings.total_deadline_ms / 1000 - (time.perf_counter() - ctx.t0)

    async def sleep_for_retry(
        self,
        ctx: CallContext,
        exc: GatewayError,
        attempt: int,
        decision: RetryDecision,
        *,
        stream: bool = False,
    ) -> None:
        """登记一次重试（计数/开销/日志）并按裁决退避；流式与非流式共用。

        流式重试必须由调用方先确认 `ctx.stream_started` 仍为 False，
        否则客户端会看到重复文本（DESIGN §8.2 的关键约束）。
        """

        ctx.retry_count += 1
        ctx.retry_overhead_ms = round(
            (ctx.retry_overhead_ms or 0) + decision.delay_s * 1000, 2
        )
        logger.warning(
            "upstream.retry",
            request_id=ctx.request_id,
            attempt=attempt,
            next_attempt=attempt + 1,
            delay_ms=round(decision.delay_s * 1000, 2),
            error_code=exc.code,
            stream=stream,
        )
        await self._sleep(decision.delay_s)

    async def execute(
        self,
        operation: Callable[[], Awaitable[T]],
        ctx: CallContext,
        *,
        stream_started: bool = False,
    ) -> T:
        """执行一次「可重试单元」，失败按策略退避重试。"""

        attempt = 0
        while True:
            attempt += 1
            ctx.attempt = attempt
            try:
                return await operation()
            except GatewayError as exc:
                ctx.retry_skipped_reason = None
                decision = self.plan(exc, ctx, attempt, stream_started=stream_started)
                if not decision.retry:
                    ctx.retry_skipped_reason = decision.reason
                    raise
                await self.sleep_for_retry(ctx, exc, attempt, decision)


def retry_after_header(seconds: float) -> str:
    """网关自己产出的 429 用整数秒，向上取整避免客户端提前重试。"""

    return str(max(1, math.ceil(seconds)))
