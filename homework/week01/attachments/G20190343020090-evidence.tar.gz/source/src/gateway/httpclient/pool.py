"""传输层：共享 httpx.AsyncClient 连接池，按路由配置设置超时。"""

from __future__ import annotations

from typing import Any

import httpx

from gateway.core.router import ModelRoute


class HttpClientPool:
    """进程内共享连接池；上游地址与鉴权差异由适配器/路由负责。"""

    def __init__(self, max_connections: int = 200, max_keepalive_connections: int = 50) -> None:
        self._max_connections = max_connections
        self._max_keepalive_connections = max_keepalive_connections
        self._client: httpx.AsyncClient | None = None

    async def startup(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(60.0),
            limits=httpx.Limits(
                max_connections=self._max_connections,
                max_keepalive_connections=self._max_keepalive_connections,
            ),
            headers={"user-agent": "mini-llm-gateway/0.1.0"},
        )

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("HttpClientPool.startup() must be called before use")
        return self._client

    async def post(
        self,
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        route: ModelRoute,
    ) -> httpx.Response:
        return await self.client.post(
            url, json=payload, headers=headers, timeout=self._timeout(route)
        )

    async def stream(
        self,
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        route: ModelRoute,
    ) -> httpx.Response:
        """打开流式响应；调用方负责 `aclose()`，`read` 超时按路由配置。"""

        request = self.client.build_request(
            "POST", url, json=payload, headers=headers, timeout=self._timeout(route)
        )
        return await self.client.send(request, stream=True)

    def _timeout(self, route: ModelRoute) -> httpx.Timeout:
        return httpx.Timeout(
            connect=route.timeout.connect,
            read=route.timeout.read,
            write=route.timeout.connect,
            pool=route.timeout.connect,
        )

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None
