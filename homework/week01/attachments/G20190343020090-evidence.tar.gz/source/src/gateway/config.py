"""配置加载与校验。

优先级：`config/gateway.yaml` < 环境变量 `GW_*`（嵌套用双下划线）。
配置非法时启动即失败，并给出字段路径。
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, ValidationError, model_validator
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_FILE = PROJECT_ROOT / "config" / "gateway.yaml"

LogLevel = Literal["debug", "info", "warning", "error"]


class ServerSettings(BaseModel):
    host: str = "0.0.0.0"
    port: int = Field(default=8000, ge=1, le=65535)


class LoggingSettings(BaseModel):
    level: LogLevel = "info"
    json_logs: bool = True
    sample_rate: float = Field(default=0.1, ge=0.0, le=1.0)


class TimeoutSettings(BaseModel):
    connect_s: float = Field(default=5.0, gt=0)
    read_s: float = Field(default=60.0, gt=0)


class RetrySettings(BaseModel):
    max_attempts: int = Field(default=3, ge=1, le=10)
    base_delay_ms: int = Field(default=500, ge=1)
    multiplier: float = Field(default=2.0, ge=1.0)
    max_delay_ms: int = Field(default=8000, ge=1)
    total_deadline_ms: int = Field(default=120_000, ge=1)
    jitter: Literal["full"] = "full"

    @model_validator(mode="after")
    def _check_delay_range(self) -> "RetrySettings":
        if self.max_delay_ms < self.base_delay_ms:
            raise ValueError("max_delay_ms must be >= base_delay_ms")
        return self


class LimitsSettings(BaseModel):
    """未在路由表声明 limits 的模型使用的默认限流参数。"""

    rpm: int = Field(default=600, ge=1)
    tpm: int = Field(default=2_000_000, ge=1)
    concurrent: int = Field(default=64, ge=1)
    max_queue_wait_ms: int = Field(default=2000, ge=0)


class StreamSettings(BaseModel):
    """对外 SSE 的保活与静默判定参数（DESIGN.md §4.3）。"""

    heartbeat_s: float = Field(default=15.0, gt=0)
    silence_timeout_s: float = Field(default=60.0, gt=0)

    @model_validator(mode="after")
    def _check_silence_window(self) -> "StreamSettings":
        if self.silence_timeout_s < self.heartbeat_s:
            raise ValueError("silence_timeout_s must be >= heartbeat_s")
        return self


class StructuredSettings(BaseModel):
    """L3 `prompt_repair` 的修复预算（DESIGN.md §5.2：额外 ≤ 2 次）。"""

    max_repair_retries: int = Field(default=2, ge=0, le=2)


class PromptSettings(BaseModel):
    """提示词存储与缓存参数（DESIGN.md §6.3）。"""

    # 相对路径以项目根目录为基准，避免部署目录不同导致找不到库。
    db_path: str = "data/prompts.sqlite3"
    cache_size: int = Field(default=256, ge=1)
    cache_ttl_s: float = Field(default=60.0, gt=0)


class Settings(BaseSettings):
    """全局配置；非法值在实例化时抛 `ValidationError`。"""

    model_config = SettingsConfigDict(
        env_prefix="GW_",
        env_nested_delimiter="__",
        yaml_file=DEFAULT_CONFIG_FILE,
        yaml_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    debug: bool = False
    server: ServerSettings = Field(default_factory=ServerSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    timeout: TimeoutSettings = Field(default_factory=TimeoutSettings)
    retry: RetrySettings = Field(default_factory=RetrySettings)
    limits: LimitsSettings = Field(default_factory=LimitsSettings)
    stream: StreamSettings = Field(default_factory=StreamSettings)
    structured: StructuredSettings = Field(default_factory=StructuredSettings)
    prompt: PromptSettings = Field(default_factory=PromptSettings)

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        # YAML 放最低优先级，环境变量始终可以覆盖文件配置。
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            file_secret_settings,
            YamlConfigSettingsSource(settings_cls),
        )


def format_validation_error(exc: ValidationError) -> str:
    """把 pydantic 校验错误格式化为 `字段路径: 原因` 的可读文本。"""

    lines = []
    for err in exc.errors():
        location = ".".join(str(part) for part in err["loc"]) or "<root>"
        lines.append(f"{location}: {err['msg']}")
    return "; ".join(lines)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
