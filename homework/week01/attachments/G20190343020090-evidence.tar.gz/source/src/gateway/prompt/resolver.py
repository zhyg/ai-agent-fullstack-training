"""提示词版本引用解析、变量校验与沙箱渲染（DESIGN.md §6.2 / §6.3）。

四种引用写法：`latest` / `active` / 精确版本号 / `name@3`。
缓存策略：LRU(256) + TTL 60s；创建新版本或切换 active 时主动失效该 name。
"""

from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any

import structlog
from jinja2 import TemplateError
from jinja2.sandbox import SandboxedEnvironment, SecurityError

from gateway.core.errors import ErrorCode, GatewayError
from gateway.prompt.models import PROMPT_NAME_PATTERN, PromptTemplate
from gateway.prompt.store import PromptStore, prompt_not_found_message

logger = structlog.get_logger("gateway.prompt")

VERSION_LATEST = "latest"
VERSION_ACTIVE = "active"
DEFAULT_CACHE_SIZE = 256
DEFAULT_CACHE_TTL_S = 60.0


@dataclass(frozen=True)
class PromptRef:
    """规范化后的版本引用；`version` 只可能是 latest/active/数字字符串。"""

    name: str
    version: str = VERSION_LATEST

    @classmethod
    def parse(cls, raw: Any) -> "PromptRef":
        """接受 `{"name","version"}` 或 `"name@3"` 两种入参。"""

        if isinstance(raw, PromptRef):
            return raw
        if isinstance(raw, str):
            name, _, version = raw.partition("@")
            return cls(name=_validate_name(name), version=normalize_version(version or None))
        if isinstance(raw, dict):
            name = _validate_name(str(raw.get("name", "")))
            return cls(name=name, version=normalize_version(raw.get("version")))
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            "prompt_ref must be an object {name, version} or a string 'name@version'",
        )


def normalize_version(version: Any) -> str:
    """把 `None` / 数字 / `"3"` / `latest` / `active` 统一成内部写法。"""

    if version is None:
        return VERSION_LATEST
    if isinstance(version, bool):
        raise GatewayError(
            ErrorCode.INVALID_REQUEST, "prompt version must be a number or string"
        )
    if isinstance(version, int):
        if version < 1:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST, "prompt version must be >= 1"
            )
        return str(version)
    text = str(version).strip()
    if text in (VERSION_LATEST, VERSION_ACTIVE):
        return text
    if text.isdigit() and int(text) >= 1:
        return str(int(text))
    raise GatewayError(
        ErrorCode.INVALID_REQUEST,
        f"invalid prompt version reference '{version}'; "
        "expected 'latest', 'active' or a positive integer",
    )


@dataclass(frozen=True)
class RenderedPrompt:
    """渲染结果：模板快照 + 最终文本 + 被忽略的未声明变量。"""

    template: PromptTemplate
    text: str
    ignored_variables: tuple[str, ...] = ()

    @property
    def echo(self) -> dict[str, Any]:
        """响应体/日志回显用，对应 DESIGN §6.3 的 `prompt{name,version,checksum}`。"""

        return {
            "name": self.template.name,
            "version": self.template.version,
            "checksum": self.template.checksum,
        }


class PromptResolver:
    """版本解析 + 缓存 + 渲染。"""

    def __init__(
        self,
        store: PromptStore,
        *,
        cache_size: int = DEFAULT_CACHE_SIZE,
        cache_ttl_s: float = DEFAULT_CACHE_TTL_S,
        environment: SandboxedEnvironment | None = None,
    ) -> None:
        self.store = store
        self._cache_size = cache_size
        self._cache_ttl_s = cache_ttl_s
        # autoescape=False：LLM 提示词不是 HTML，转义反而污染内容。
        self._env = environment or SandboxedEnvironment(autoescape=False)
        self._cache: OrderedDict[str, tuple[float, PromptTemplate]] = OrderedDict()
        self._lock = threading.Lock()

    # ------------------------------------------------------------ 解析

    def resolve(self, ref: PromptRef) -> PromptTemplate:
        key = f"{ref.name}:{ref.version}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached

        if ref.version == VERSION_ACTIVE:
            template = self.store.get_active(ref.name)
        elif ref.version == VERSION_LATEST:
            template = self.store.get_latest(ref.name)
        else:
            template = self.store.get(ref.name, int(ref.version))

        if template is None:
            versions = self.store.list_versions(ref.name)
            available = [item.version for item in versions]
            active = next(
                (item.version for item in versions if item.status == "active"), None
            )
            raise GatewayError(
                ErrorCode.PROMPT_NOT_FOUND,
                prompt_not_found_message(ref.name, ref.version, versions),
                details={
                    "name": ref.name,
                    "version": ref.version,
                    "available_versions": available,
                    "active_version": active,
                },
            )

        self._cache_put(key, template)
        return template

    # ------------------------------------------------------------ 渲染

    def render(self, ref: PromptRef, variables: dict[str, Any] | None = None) -> RenderedPrompt:
        """校验变量并渲染；必填缺失 → 400，未声明变量忽略并告警。"""

        template = self.resolve(ref)
        provided = dict(variables or {})
        declared = {variable.name: variable for variable in template.variables}

        missing = [
            name
            for name, variable in declared.items()
            if variable.required and name not in provided and variable.default is None
        ]
        if missing:
            raise GatewayError(
                ErrorCode.MISSING_VARIABLE,
                f"missing required prompt variable(s) for '{template.name}' "
                f"v{template.version}: {sorted(missing)}",
                details={
                    "prompt": template.name,
                    "version": template.version,
                    "missing_variables": sorted(missing),
                },
            )

        ignored = sorted(set(provided) - set(declared))
        if ignored:
            # 防拼写错误静默生效：忽略但必须留痕。
            logger.warning(
                "prompt.variables_ignored",
                prompt_name=template.name,
                prompt_version=template.version,
                checksum=template.checksum,
                variables=ignored,
            )

        context = {
            name: provided[name] if name in provided else variable.default
            for name, variable in declared.items()
        }
        try:
            text = self._env.from_string(template.content).render(**context)
        except SecurityError as exc:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                f"prompt '{template.name}' v{template.version} uses forbidden "
                f"sandbox constructs: {exc}",
            ) from exc
        except TemplateError as exc:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                f"failed to render prompt '{template.name}' v{template.version}: {exc}",
            ) from exc

        return RenderedPrompt(template=template, text=text, ignored_variables=tuple(ignored))

    # ------------------------------------------------------------ 写入后失效

    def create(self, **kwargs: Any) -> PromptTemplate:
        template = self.store.create(**kwargs)
        self.invalidate(template.name)
        return template

    def activate(self, name: str, version: int) -> PromptTemplate:
        template = self.store.activate(name, version)
        self.invalidate(name)
        return template

    def invalidate(self, name: str) -> None:
        prefix = f"{name}:"
        with self._lock:
            for key in [key for key in self._cache if key.startswith(prefix)]:
                self._cache.pop(key, None)

    def clear_cache(self) -> None:
        with self._lock:
            self._cache.clear()

    # ------------------------------------------------------------ 缓存内部

    def _cache_get(self, key: str) -> PromptTemplate | None:
        now = time.monotonic()
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            stored_at, template = entry
            if now - stored_at >= self._cache_ttl_s:
                self._cache.pop(key, None)
                return None
            self._cache.move_to_end(key)
            return template

    def _cache_put(self, key: str, template: PromptTemplate) -> None:
        now = time.monotonic()
        with self._lock:
            self._cache[key] = (now, template)
            self._cache.move_to_end(key)
            while len(self._cache) > self._cache_size:
                self._cache.popitem(last=False)


def _validate_name(name: str) -> str:
    if not PROMPT_NAME_PATTERN.match(name or ""):
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            "prompt name must match [A-Za-z0-9_.-]{1,64}",
            details={"name": name},
        )
    return name
