"""提示词模板的数据模型与表结构（DESIGN.md §6.1）。

版本号在同一 `name` 下单调递增；`checksum = sha256(content)` 用于线上归因，
日志里只带 checksum，事后可用 `PromptStore.find_by_checksum()` 反查确切模板。
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from typing import Any, Literal

PromptStatus = Literal["draft", "active", "deprecated"]

# 模板名会出现在 URL 路径里，限制字符集避免转义歧义。
PROMPT_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS prompt_templates (
  id              INTEGER PRIMARY KEY,
  name            TEXT NOT NULL,
  version         INTEGER NOT NULL,
  content         TEXT NOT NULL,
  variables       TEXT NOT NULL,
  response_schema TEXT,
  status          TEXT NOT NULL,
  checksum        TEXT NOT NULL,
  created_at      TEXT NOT NULL,
  created_by      TEXT,
  UNIQUE(name, version)
);
CREATE INDEX IF NOT EXISTS idx_prompt_active ON prompt_templates(name, status);
CREATE INDEX IF NOT EXISTS idx_prompt_checksum ON prompt_templates(checksum);
"""


def checksum_of(content: str) -> str:
    """模板内容指纹；统一带 `sha256:` 前缀，便于日志与文档对齐。"""

    return "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class PromptVariable:
    """模板变量声明；`required=True` 且无默认值时，请求必须提供。"""

    name: str
    required: bool = True
    default: Any = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PromptVariable":
        name = str(data.get("name", "")).strip()
        if not name:
            raise ValueError("prompt variable requires a non-empty name")
        return cls(
            name=name,
            required=bool(data.get("required", True)),
            default=data.get("default"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "required": self.required, "default": self.default}


@dataclass(frozen=True)
class PromptTemplate:
    """一次查询得到的模板版本快照（不可变）。"""

    name: str
    version: int
    content: str
    variables: tuple[PromptVariable, ...] = field(default_factory=tuple)
    response_schema: dict[str, Any] | None = None
    status: PromptStatus = "draft"
    checksum: str = ""
    created_at: str = ""
    created_by: str | None = None
    id: int | None = None

    def summary(self) -> dict[str, Any]:
        """列表/详情用摘要，不返回模板正文。"""

        return {
            "name": self.name,
            "version": self.version,
            "status": self.status,
            "checksum": self.checksum,
            "created_at": self.created_at,
            "created_by": self.created_by,
        }

    def to_dict(self) -> dict[str, Any]:
        data = self.summary()
        data["variables"] = [variable.to_dict() for variable in self.variables]
        data["response_schema"] = self.response_schema
        data["content"] = self.content
        return data


def dump_variables(
    variables: tuple[PromptVariable, ...] | list[PromptVariable]
    | list[dict[str, Any]],
) -> str:
    """序列化变量声明；允许直接传 dict 声明，降低调用方样板代码。"""

    normalized = [
        variable if isinstance(variable, PromptVariable) else PromptVariable.from_dict(variable)
        for variable in variables
    ]
    return json.dumps([variable.to_dict() for variable in normalized], ensure_ascii=False)


def parse_variables(raw: str | None) -> tuple[PromptVariable, ...]:
    """从 SQLite 的 JSON 列还原变量声明；坏数据直接报错而非静默降级。"""

    if not raw:
        return ()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid variables JSON in prompt_templates: {exc}") from exc
    if not isinstance(data, list):
        raise ValueError("variables column must be a JSON array")
    return tuple(PromptVariable.from_dict(item) for item in data)
