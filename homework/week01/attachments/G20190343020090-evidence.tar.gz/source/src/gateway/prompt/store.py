"""提示词存储层：`PromptStore` Protocol + 零依赖的 SQLite 实现。

上层（`PromptResolver`）只依赖 Protocol，后续换 Postgres 不需要改业务代码。
SQLite 连接用 `check_same_thread=False` + 进程内互斥锁，保证单进程并发安全；
Prompt 读写都是毫秒级小事务，不额外引入 aiosqlite。
"""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

from gateway.core.errors import ErrorCode, GatewayError
from gateway.prompt.models import (
    PROMPT_NAME_PATTERN,
    PromptStatus,
    PromptTemplate,
    PromptVariable,
    SCHEMA_SQL,
    checksum_of,
    dump_variables,
    parse_variables,
)

_STATUSES = frozenset({"draft", "active", "deprecated"})


class PromptStore(Protocol):
    """模板存储抽象；所有方法同步实现，调用方负责在异步上下文里直接使用。"""

    def create(
        self,
        *,
        name: str,
        content: str,
        variables: tuple[PromptVariable, ...] | list[PromptVariable] = (),
        response_schema: dict[str, Any] | None = None,
        status: PromptStatus = "draft",
        created_by: str | None = None,
    ) -> PromptTemplate: ...

    def get(self, name: str, version: int) -> PromptTemplate | None: ...

    def get_latest(self, name: str) -> PromptTemplate | None: ...

    def get_active(self, name: str) -> PromptTemplate | None: ...

    def list_versions(self, name: str) -> list[PromptTemplate]: ...

    def list_names(self) -> list[dict[str, Any]]: ...

    def activate(self, name: str, version: int) -> PromptTemplate: ...

    def update_content(
        self,
        name: str,
        version: int,
        *,
        content: str,
        variables: tuple[PromptVariable, ...] | list[PromptVariable] | None = None,
        response_schema: dict[str, Any] | None = None,
    ) -> PromptTemplate: ...

    def find_by_checksum(self, checksum: str) -> PromptTemplate | None: ...


class SQLiteStore:
    """基于 SQLite 的 `PromptStore` 默认实现。"""

    def __init__(self, db_path: str | Path) -> None:
        self.path = Path(db_path)
        if str(self.path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(SCHEMA_SQL)
            self._conn.commit()

    # ------------------------------------------------------------ 写入

    def create(
        self,
        *,
        name: str,
        content: str,
        variables: tuple[PromptVariable, ...] | list[PromptVariable] = (),
        response_schema: dict[str, Any] | None = None,
        status: PromptStatus = "draft",
        created_by: str | None = None,
    ) -> PromptTemplate:
        _validate_name(name)
        _validate_content(content)
        _validate_status(status)
        declared = tuple(variables)
        now = _utc_now()

        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute(
                "SELECT MAX(version) FROM prompt_templates WHERE name = ?", (name,)
            )
            row = cursor.fetchone()
            version = (row[0] or 0) + 1
            # 同一 name 只允许一个 active：新版本直接激活时原子降级旧版本。
            if status == "active":
                cursor.execute(
                    "UPDATE prompt_templates SET status = 'deprecated' "
                    "WHERE name = ? AND status = 'active'",
                    (name,),
                )
            cursor.execute(
                "INSERT INTO prompt_templates "
                "(name, version, content, variables, response_schema, status, "
                " checksum, created_at, created_by) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    name,
                    version,
                    content,
                    dump_variables(declared),
                    json.dumps(response_schema, ensure_ascii=False)
                    if response_schema is not None
                    else None,
                    status,
                    checksum_of(content),
                    now,
                    created_by,
                ),
            )
            self._conn.commit()
            template = self._get_locked(name, version)
        assert template is not None
        return template

    def activate(self, name: str, version: int) -> PromptTemplate:
        """原子切换 active 指针：旧 active → deprecated，目标版本 → active。"""

        with self._lock:
            template = self._get_locked(name, version)
            if template is None:
                raise GatewayError(
                    ErrorCode.PROMPT_NOT_FOUND,
                    prompt_not_found_message(name, version, self._versions_locked(name)),
                )
            cursor = self._conn.cursor()
            cursor.execute(
                "UPDATE prompt_templates SET status = 'deprecated' "
                "WHERE name = ? AND status = 'active' AND version <> ?",
                (name, version),
            )
            cursor.execute(
                "UPDATE prompt_templates SET status = 'active' WHERE name = ? AND version = ?",
                (name, version),
            )
            self._conn.commit()
            return self._get_locked(name, version)  # type: ignore[return-value]

    def update_content(
        self,
        name: str,
        version: int,
        *,
        content: str,
        variables: tuple[PromptVariable, ...] | list[PromptVariable] | None = None,
        response_schema: dict[str, Any] | None = None,
    ) -> PromptTemplate:
        """只允许改 draft；已发布版本（active/deprecated）内容不可修改。"""

        _validate_content(content)
        with self._lock:
            template = self._get_locked(name, version)
            if template is None:
                raise GatewayError(
                    ErrorCode.PROMPT_NOT_FOUND,
                    prompt_not_found_message(name, version, self._versions_locked(name)),
                )
            if template.status != "draft":
                raise GatewayError(
                    ErrorCode.INVALID_REQUEST,
                    f"prompt '{name}' v{version} is {template.status} and immutable; "
                    "create a new version instead",
                    details={"name": name, "version": version, "status": template.status},
                )
            declared = tuple(variables) if variables is not None else template.variables
            schema_json = (
                json.dumps(response_schema, ensure_ascii=False)
                if response_schema is not None
                else (json.dumps(template.response_schema, ensure_ascii=False)
                      if template.response_schema is not None else None)
            )
            self._conn.execute(
                "UPDATE prompt_templates SET content = ?, variables = ?, "
                "response_schema = ?, checksum = ? WHERE name = ? AND version = ?",
                (
                    content,
                    dump_variables(declared),
                    schema_json,
                    checksum_of(content),
                    name,
                    version,
                ),
            )
            self._conn.commit()
            return self._get_locked(name, version)  # type: ignore[return-value]

    # ------------------------------------------------------------ 读取

    def get(self, name: str, version: int) -> PromptTemplate | None:
        with self._lock:
            return self._get_locked(name, version)

    def get_latest(self, name: str) -> PromptTemplate | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM prompt_templates WHERE name = ? "
                "ORDER BY version DESC LIMIT 1",
                (name,),
            ).fetchone()
        return _row_to_template(row) if row is not None else None

    def get_active(self, name: str) -> PromptTemplate | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM prompt_templates WHERE name = ? AND status = 'active' "
                "ORDER BY version DESC LIMIT 1",
                (name,),
            ).fetchone()
        return _row_to_template(row) if row is not None else None

    def list_versions(self, name: str) -> list[PromptTemplate]:
        with self._lock:
            return self._versions_locked(name)

    def list_names(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT name, COUNT(*) AS versions, MAX(version) AS latest_version, "
                "MAX(CASE WHEN status = 'active' THEN version END) AS active_version, "
                "MAX(created_at) AS updated_at "
                "FROM prompt_templates GROUP BY name ORDER BY name"
            ).fetchall()
        return [
            {
                "name": row["name"],
                "versions": row["versions"],
                "latest_version": row["latest_version"],
                "active_version": row["active_version"],
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def find_by_checksum(self, checksum: str) -> PromptTemplate | None:
        """反向校验：日志里的 checksum → 当时的模板内容。"""

        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM prompt_templates WHERE checksum = ? "
                "ORDER BY name, version LIMIT 1",
                (checksum,),
            ).fetchone()
        return _row_to_template(row) if row is not None else None

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ------------------------------------------------------------ 内部

    def _get_locked(self, name: str, version: int) -> PromptTemplate | None:
        row = self._conn.execute(
            "SELECT * FROM prompt_templates WHERE name = ? AND version = ?",
            (name, version),
        ).fetchone()
        return _row_to_template(row) if row is not None else None

    def _versions_locked(self, name: str) -> list[PromptTemplate]:
        rows = self._conn.execute(
            "SELECT * FROM prompt_templates WHERE name = ? ORDER BY version",
            (name,),
        ).fetchall()
        return [_row_to_template(row) for row in rows]


def _row_to_template(row: sqlite3.Row) -> PromptTemplate:
    raw_schema = row["response_schema"]
    return PromptTemplate(
        id=row["id"],
        name=row["name"],
        version=row["version"],
        content=row["content"],
        variables=parse_variables(row["variables"]),
        response_schema=json.loads(raw_schema) if raw_schema else None,
        status=row["status"],
        checksum=row["checksum"],
        created_at=row["created_at"],
        created_by=row["created_by"],
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _validate_name(name: str) -> None:
    if not PROMPT_NAME_PATTERN.match(name or ""):
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            "prompt name must match [A-Za-z0-9_.-]{1,64}",
            details={"name": name},
        )


def _validate_content(content: str) -> None:
    if not isinstance(content, str) or not content.strip():
        raise GatewayError(
            ErrorCode.INVALID_REQUEST, "prompt content must be a non-empty string"
        )


def _validate_status(status: str) -> None:
    if status not in _STATUSES:
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            f"invalid prompt status '{status}', expected one of {sorted(_STATUSES)}",
        )


def prompt_not_found_message(
    name: str, version_spec: int | str, versions: list[PromptTemplate]
) -> str:
    """错误 message 里回显可用版本：`details` 仅在 debug 模式透出，message 必须自解释。"""

    available = [template.version for template in versions]
    active = next((t.version for t in versions if t.status == "active"), None)
    return (
        f"prompt '{name}' version '{version_spec}' not found; "
        f"available versions: {available}, active: {active}"
    )
