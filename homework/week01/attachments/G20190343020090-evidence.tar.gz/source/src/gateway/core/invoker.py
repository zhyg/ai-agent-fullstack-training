"""调用编排：路由解析 → 适配器翻译 → 传输 → 归一化响应/事件流。

`call_once()` 与 `stream()` 都是「一次上游调用」的最小可重试单元，
Stage 6 的重试器直接包在它们外面；开流后（`ctx.stream_started=True`）不再允许重试。
"""

from __future__ import annotations

import contextlib
import json
import time
from dataclasses import dataclass
from typing import Any, AsyncIterator, Protocol

import httpx
import structlog

from gateway.adapters.registry import AdapterRegistry
from gateway.config import Settings
from gateway.core.adapter import ProviderAdapter
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.events import CanonicalEvent
from gateway.core.ir import (
    CallContext,
    CanonicalRequest,
    CanonicalResponse,
    FinishReason,
)
from gateway.core.router import ModelRoute, Router
from gateway.resilience.retry import RetryPolicy
from gateway.structured.enforce import (
    StructuredMode,
    StructuredOutputError,
    StructuredPlan,
    apply_plan,
    build_repair_request,
    choose_mode,
    extract_structured,
)
from gateway.telemetry.timing import latency_snapshot

logger = structlog.get_logger("gateway.invoker")

# L3 修复预算的上限；配置缺省时使用
_DEFAULT_MAX_REPAIR = 2


class HttpTransport(Protocol):
    """传输接口；测试可注入假实现，无需改动核心管线。"""

    async def post(
        self,
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        route: ModelRoute,
    ) -> httpx.Response: ...

    async def stream(
        self,
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        route: ModelRoute,
    ) -> httpx.Response: ...


@dataclass(frozen=True)
class PreparedCall:
    """一次上游调用的完整准备结果：预检阶段就把能返回 4xx 的错误全部抛出。"""

    route: ModelRoute
    adapter: ProviderAdapter
    url: str
    payload: dict[str, Any]
    headers: dict[str, str]
    # Stage 3：结构化计划；为 None 表示普通文本请求
    plan: StructuredPlan | None = None


class Gateway:
    def __init__(
        self,
        router: Router,
        adapters: AdapterRegistry,
        transport: HttpTransport,
        settings: Settings | None = None,
        *,
        retry: RetryPolicy | None = None,
    ) -> None:
        self.router = router
        self.adapters = adapters
        self.transport = transport
        self.settings = settings
        # Stage 6：显式注入而非按 settings 自动开启，避免直连 Gateway 的
        # 单测被退避 sleep 拖慢（限流同样由 API 层持有）。
        self.retry = retry

    def _resolve(self, model: str) -> tuple[ModelRoute, ProviderAdapter]:
        route = self.router.resolve(model)
        return route, self.adapters.get(route.adapter)

    def prepare(self, req: CanonicalRequest) -> PreparedCall:
        """解析路由并构建上游请求；鉴权缺失、未知模型等错误在此提前暴露。

        Stage 3 起同时负责结构化预检：schema lint（400 SCHEMA_INCOMPATIBLE）与
        档位选择；L3 会改写请求（注入 schema 提示、清空 response_format）。
        """

        route, adapter = self._resolve(req.model)
        plan = choose_mode(req.response_format, adapter.capabilities(route))
        upstream_req = apply_plan(req, plan) if plan is not None else req
        return PreparedCall(
            route=route,
            adapter=adapter,
            url=route.base_url.rstrip("/") + adapter.endpoint,
            payload=adapter.build_payload(upstream_req, route),
            headers=adapter.build_headers(route),
            plan=plan,
        )

    async def call_once(
        self,
        req: CanonicalRequest,
        route: ModelRoute,
        adapter: ProviderAdapter,
        ctx: CallContext,
        prepared: PreparedCall | None = None,
    ) -> CanonicalResponse:
        """执行一次非流式上游调用；异常统一收敛为 `GatewayError`。"""

        call = prepared or self.prepare(req)

        # Stage 5：记录上游请求发出时间，用于 upstream_ttft_ms 归因
        ctx.upstream_started_at = time.perf_counter()
        try:
            response = await self.transport.post(
                call.url, call.payload, call.headers, call.route
            )
        except httpx.TimeoutException as exc:
            raise adapter.normalize_error(0, None, exc) from exc
        except httpx.HTTPError as exc:
            raise adapter.normalize_error(0, None, exc) from exc

        raw = _decode_json(response)
        if response.status_code >= 400:
            raise _with_retry_after(
                adapter.normalize_error(response.status_code, raw), response
            )
        if raw is None:
            raise GatewayError(
                ErrorCode.UPSTREAM_BAD_RESPONSE,
                "upstream returned a non-JSON body",
                details={"upstream_status": response.status_code},
            )

        try:
            parsed = adapter.parse_response(raw, req)
        except GatewayError:
            raise
        except Exception as exc:
            raise GatewayError(
                ErrorCode.UPSTREAM_BAD_RESPONSE,
                f"failed to parse upstream response: {exc!r}",
            ) from exc

        parsed.latency = latency_snapshot(
            t0=ctx.t0,
            queue_wait_ms=ctx.queue_wait_ms,
            retry_overhead_ms=ctx.retry_overhead_ms,
        )
        return parsed

    async def _call_once_with_retry(
        self,
        req: CanonicalRequest,
        call: PreparedCall,
        ctx: CallContext,
    ) -> CanonicalResponse:
        """把一次非流式上游调用包进重试执行器（L3 修复的每次调用同样受保护）。"""

        if self.retry is None:
            return await self.call_once(req, call.route, call.adapter, ctx, call)
        return await self.retry.execute(
            lambda: self.call_once(req, call.route, call.adapter, ctx, call), ctx
        )

    async def complete(
        self, req: CanonicalRequest, ctx: CallContext | None = None
    ) -> CanonicalResponse:
        """非流式调用入口；结构化请求在这里完成解析与修复重试。"""

        ctx = ctx or CallContext(request_id=req.request_id)
        call = self.prepare(req)
        response = await self._call_once_with_retry(req, call, ctx)
        response.prompt = req.prompt
        return await self._enforce_structured(req, ctx, call, response)

    async def _enforce_structured(
        self,
        req: CanonicalRequest,
        ctx: CallContext,
        call: PreparedCall,
        response: CanonicalResponse,
    ) -> CanonicalResponse:
        """按计划解析结构化结果；L3 失败时把错误回灌模型修复。"""

        plan = call.plan
        if plan is None:
            return response
        _raise_if_refused(response, plan)

        if plan.mode is StructuredMode.PROMPT_REPAIR:
            return await self._repair_loop(req, ctx, response, plan)

        try:
            response.structured = extract_structured(response.text, plan.format)
        except StructuredOutputError as exc:
            raise GatewayError(
                ErrorCode.OUTPUT_PARSE_FAILED,
                f"structured output failed ({plan.mode.value}): {exc}",
                details={"structured_mode": plan.mode.value},
            ) from exc
        response.structured_mode = plan.mode.value
        return response

    async def _repair_loop(
        self,
        req: CanonicalRequest,
        ctx: CallContext,
        response: CanonicalResponse,
        plan: StructuredPlan,
    ) -> CanonicalResponse:
        """L3：解析失败 → 追加 assistant/user 修复消息重试（额外 ≤ 2 次）。"""

        max_repair = (
            self.settings.structured.max_repair_retries
            if self.settings is not None
            else _DEFAULT_MAX_REPAIR
        )
        for attempt in range(max_repair + 1):
            try:
                response.structured = extract_structured(response.text, plan.format)
            except StructuredOutputError as exc:
                if attempt >= max_repair:
                    raise GatewayError(
                        ErrorCode.OUTPUT_PARSE_FAILED,
                        f"structured output failed after {attempt + 1} attempt(s): {exc}",
                        details={
                            "structured_mode": plan.mode.value,
                            "repair_attempts": attempt,
                        },
                    ) from exc
                logger.warning(
                    "structured.repair",
                    request_id=ctx.request_id,
                    model=req.model,
                    attempt=attempt + 1,
                    max_repair=max_repair,
                    error=str(exc),
                )
                repair_req = build_repair_request(req, plan, response.text, str(exc))
                repair_call = self.prepare(repair_req)
                response = await self._call_once_with_retry(repair_req, repair_call, ctx)
                _raise_if_refused(response, plan)
                continue

            response.structured_mode = plan.mode.value
            return response

        raise AssertionError("unreachable")  # pragma: no cover - 循环内已返回或抛错

    async def invoke(
        self, req: CanonicalRequest, ctx: CallContext | None = None
    ) -> AsyncIterator[CanonicalEvent]:
        """统一事件流入口；非流式请求只产出一个 `done` 事件。"""

        if req.stream:
            async for event in self.stream(req, ctx):
                yield event
            return

        response = await self.complete(req, ctx)
        yield CanonicalEvent(
            type="done",
            text_delta=response.text,
            usage=response.usage,
            finish_reason=response.finish_reason,
            structured=response.structured,
            structured_mode=response.structured_mode,
            prompt=response.prompt,
        )

    async def stream(
        self,
        req: CanonicalRequest,
        ctx: CallContext | None = None,
        prepared: PreparedCall | None = None,
    ) -> AsyncIterator[CanonicalEvent]:
        """打开上游 SSE 并逐事件归一化（Stage 6 起带「开流前」重试）。

        - 上游 4xx/5xx 在首个事件之前抛出，让 API 层仍能返回 JSON 错误；
        - 收到首个 delta 时置 `ctx.stream_started=True`；此后失败一律不重试，
          日志记 `retry_skipped_reason=stream_started`（DESIGN §8.2）；
        - 首个 delta 之前的事件先缓存，失败可整段丢弃，避免客户端看到重复内容；
        - 结构化请求只在终态事件携带 `structured`（DESIGN §5.4），流式下不做修复重试；
        - 无论正常结束、异常还是被取消，都会 `aclose()` 上游响应，避免连接泄漏。
        """

        ctx = ctx or CallContext(request_id=req.request_id)
        call = prepared or self.prepare(req)
        attempt = 0

        while True:
            attempt += 1
            ctx.attempt = attempt
            held: list[CanonicalEvent] = []
            passthrough = False
            events = self._stream_once(req, ctx, call)
            try:
                async for event in events:
                    if passthrough:
                        yield event
                        continue
                    held.append(event)
                    if event.type == "delta" or event.type in ("done", "error"):
                        # 首个 delta（或终态）之后重试窗口关闭，先把缓存冲刷给调用方
                        passthrough = True
                        for buffered in held:
                            yield buffered
                return
            except GatewayError as exc:
                if self.retry is None:
                    raise
                decision = self.retry.plan(
                    exc, ctx, attempt, stream_started=ctx.stream_started
                )
                if not decision.retry:
                    ctx.retry_skipped_reason = decision.reason
                    raise
                await self.retry.sleep_for_retry(ctx, exc, attempt, decision, stream=True)
            finally:
                # 显式关闭本次尝试的上游流；重试时会重新打开
                await events.aclose()

    async def _stream_once(
        self,
        req: CanonicalRequest,
        ctx: CallContext,
        call: PreparedCall,
    ) -> AsyncIterator[CanonicalEvent]:
        """单次流式上游尝试；失败只抛 `GatewayError`，重试由外层决定。"""

        adapter = call.adapter
        plan = call.plan
        pieces: list[str] = []

        # Stage 5：打点上游请求发出时刻；重试会覆盖为最后一次尝试
        ctx.upstream_started_at = time.perf_counter()
        try:
            response = await self.transport.stream(
                call.url, call.payload, call.headers, call.route
            )
        except httpx.TimeoutException as exc:
            raise adapter.normalize_error(0, None, exc) from exc
        except httpx.HTTPError as exc:
            raise adapter.normalize_error(0, None, exc) from exc

        terminal = False
        try:
            if response.status_code >= 400:
                body = await _decode_error_body(response)
                raise _with_retry_after(
                    adapter.normalize_error(response.status_code, body), response
                )

            async for event in adapter.parse_sse(response.aiter_bytes()):
                if event.type == "delta":
                    if not ctx.stream_started:
                        ctx.stream_started = True
                    if event.text_delta:
                        pieces.append(event.text_delta)
                elif event.type == "done" and plan is not None:
                    # 终态统一做结构化解析；失败降级为 error 事件（此时无法改状态码）
                    event = _finalize_structured_event(event, pieces, plan)
                if event.type == "done":
                    event.prompt = req.prompt
                if event.type in ("done", "error"):
                    terminal = True
                    yield event
                    return
                yield event
        except httpx.HTTPError as exc:
            # 流中途的网络错误（读超时 / 连接被重置）
            raise adapter.normalize_error(0, None, exc) from exc
        finally:
            await _aclose(response)

        if not terminal and not ctx.client_aborted:
            raise GatewayError(
                ErrorCode.STREAM_INTERRUPTED,
                "upstream stream ended without a terminal event",
            )


def _raise_if_refused(response: CanonicalResponse, plan: StructuredPlan) -> None:
    """OpenAI strict 模式的拒答落在 `refusal` 字段并被归一为 CONTENT_FILTER。

    结构化请求必须显式报 `CONTENT_FILTERED`，否则后续解析只会拿到空串，
    被误判成 `OUTPUT_PARSE_FAILED`。
    """

    if response.finish_reason is not FinishReason.CONTENT_FILTER:
        return
    raise GatewayError(
        ErrorCode.CONTENT_FILTERED,
        "upstream refused to produce the requested structured output",
        details={"structured_mode": plan.mode.value},
    )


def _finalize_structured_event(
    event: CanonicalEvent, pieces: list[str], plan: StructuredPlan
) -> CanonicalEvent:
    """流式终态：解析累积文本并挂到 done 事件上（中间帧绝不带半截 JSON）。"""

    if event.finish_reason is FinishReason.CONTENT_FILTER:
        return CanonicalEvent(
            type="error",
            error=GatewayError(
                ErrorCode.CONTENT_FILTERED,
                "upstream refused to produce the requested structured output",
                details={"structured_mode": plan.mode.value},
            ),
        )

    try:
        structured = extract_structured("".join(pieces), plan.format)
    except StructuredOutputError as exc:
        return CanonicalEvent(
            type="error",
            error=GatewayError(
                ErrorCode.OUTPUT_PARSE_FAILED,
                f"structured output failed in streaming mode: {exc} "
                "(repair retries are disabled once the stream has started)",
                details={"structured_mode": plan.mode.value},
            ),
        )

    event.structured = structured
    event.structured_mode = plan.mode.value
    return event


def _with_retry_after(error: GatewayError, response: httpx.Response) -> GatewayError:
    """把上游 `Retry-After` 头挂到归一化错误上，供重试器按上游要求退避。"""

    value = response.headers.get("retry-after")
    if value:
        error.headers = {**error.headers, "Retry-After": value}
    return error


def _decode_json(response: httpx.Response) -> dict | None:
    try:
        data = response.json()
    except (json.JSONDecodeError, ValueError):
        return None
    return data if isinstance(data, dict) else None


async def _decode_error_body(response: httpx.Response) -> dict | None:
    """流式请求的 4xx/5xx 响应体需要显式读取，再交给适配器归一化。"""

    try:
        await response.aread()
    except httpx.HTTPError:
        return None
    return _decode_json(response)


async def _aclose(response: httpx.Response) -> None:
    with contextlib.suppress(Exception):
        await response.aclose()
