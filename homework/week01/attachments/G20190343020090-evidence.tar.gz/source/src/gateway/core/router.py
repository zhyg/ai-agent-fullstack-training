"""路由表：model -> 适配器 + 上游端点 + 超时/限流配置。"""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field, model_validator

from gateway.config import PROJECT_ROOT
from gateway.core.errors import ErrorCode, GatewayError

DEFAULT_ROUTES_FILE = PROJECT_ROOT / "config" / "routes.yaml"


class RouteTimeout(BaseModel):
    connect: float = Field(default=5.0, gt=0)
    read: float = Field(default=60.0, gt=0)


class RouteLimits(BaseModel):
    rpm: int = Field(default=600, ge=1)
    tpm: int = Field(default=2_000_000, ge=1)
    concurrent: int = Field(default=64, ge=1)


class RoutePricing(BaseModel):
    """每百万 token 的价格表，用于 `llm_cost_estimate_total` 换算（DESIGN §7.1）。"""

    input_per_1m: float = Field(default=0.0, ge=0)
    output_per_1m: float = Field(default=0.0, ge=0)
    cache_read_per_1m: float = Field(default=0.0, ge=0)
    currency: str = "USD"


class ModelRoute(BaseModel):
    model: str = ""
    adapter: str
    upstream_model: str
    base_url: str
    api_key_env: str
    default_max_tokens: int = Field(default=4096, ge=1)
    timeout: RouteTimeout = Field(default_factory=RouteTimeout)
    limits: RouteLimits = Field(default_factory=RouteLimits)
    # 价格表缺省时只记录 token，不计费用。
    pricing: RoutePricing | None = None
    # Stage 6 使用；Stage 1 只保留配置位，不切换。
    fallback: list[dict] = Field(default_factory=list)


class RouteTable(BaseModel):
    models: dict[str, ModelRoute]

    @model_validator(mode="after")
    def _fill_model_names(self) -> "RouteTable":
        for name, route in self.models.items():
            route.model = name
        return self


class Router:
    """负责 model 解析；未命中时回显可用模型列表，避免客户端盲猜。"""

    def __init__(self, routes: dict[str, ModelRoute]) -> None:
        self._routes = dict(routes)

    @classmethod
    def from_file(cls, path: Path = DEFAULT_ROUTES_FILE) -> "Router":
        with Path(path).open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
        table = RouteTable(**data)
        return cls(table.models)

    def resolve(self, model: str) -> ModelRoute:
        route = self._routes.get(model)
        if route is None:
            available = sorted(self._routes)
            raise GatewayError(
                ErrorCode.MODEL_NOT_FOUND,
                f"unknown model '{model}', available models: {available}",
                details={"available_models": available},
            )
        return route

    def all(self) -> list[ModelRoute]:
        return [self._routes[name] for name in sorted(self._routes)]

    def __contains__(self, model: str) -> bool:
        return model in self._routes
