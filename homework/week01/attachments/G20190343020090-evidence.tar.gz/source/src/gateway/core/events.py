"""统一事件流模型。

适配器把各家 SSE 事件翻译成 `CanonicalEvent`，上层（API / 观测 / 韧性）
只处理这一套语义；非流式请求等价于「只产一个 done 事件」。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from gateway.core.ir import FinishReason, TokenUsage


@dataclass
class CanonicalEvent:
    """网关内部事件，`type` 的语义见 DESIGN.md §4.2。

    - `start`：上游确认开始生成（可携带已知的 input_tokens），内部用于打点；
    - `delta`：增量文本；
    - `structured`：结构化解析结果（Stage 3 使用）；
    - `done`：终态，携带最终 usage 与 finish_reason；
    - `error`：上游流中错误，客户端收到 error 事件后流关闭；
    - `ping`：上游保活事件，对外统一转换为 `: heartbeat` 注释行。
    """

    type: Literal["start", "delta", "structured", "done", "error", "ping"]
    text_delta: str | None = None
    usage: TokenUsage | None = None
    finish_reason: FinishReason | None = None
    structured: dict[str, Any] | None = None
    # Stage 3：结构化档位；流式时只有终态事件携带
    structured_mode: str | None = None
    # Stage 4：提示词版本回显，随终态事件一起下发
    prompt: dict[str, Any] | None = None
    error: Any | None = None
    upstream_seq: int | None = None
