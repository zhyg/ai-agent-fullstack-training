"""Canonical IR：网关内部唯一的请求/响应/事件表示。

命名尽量贴近 OpenAI 语义（生态事实标准），厂商差异只在适配器内消化。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Literal


class Role(StrEnum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass(frozen=True)
class CanonicalMessage:
    role: Role
    content: str


@dataclass(frozen=True)
class ResponseFormat:
    """对外统一使用 OpenAI 风格的 response_format。"""

    type: Literal["text", "json_object", "json_schema"]
    name: str | None = None
    schema: dict[str, Any] | None = None
    strict: bool = True


@dataclass
class CanonicalRequest:
    request_id: str
    model: str
    messages: list[CanonicalMessage]
    system: str | None = None
    stream: bool = False
    response_format: ResponseFormat | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_output_tokens: int | None = None
    stop: list[str] | None = None
    user: str | None = None
    # Stage 4：本次请求引用的提示词版本（name/version/checksum），用于响应回显与日志归因
    prompt: dict[str, Any] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class FinishReason(StrEnum):
    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    CONTENT_FILTER = "content_filter"
    ERROR = "error"


@dataclass
class TokenUsage:
    """Token 五分类；`source` 区分上游上报与本地估算，二者绝不混报。"""

    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    source: Literal["reported", "estimated"] = "reported"

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def to_dict(self) -> dict[str, Any]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_write_tokens": self.cache_write_tokens,
            "total_tokens": self.total_tokens,
            "source": self.source,
        }


@dataclass
class Latency:
    """关键延迟指标；Stage 1 先落 total，Stage 2/5 逐步补全其余字段。"""

    total_ms: float | None = None
    ttft_ms: float | None = None
    upstream_ttft_ms: float | None = None
    queue_wait_ms: float | None = None
    retry_overhead_ms: float | None = None
    tpot_ms: float | None = None

    def to_dict(self, *, drop_none: bool = True) -> dict[str, Any]:
        data = {
            "total_ms": self.total_ms,
            "ttft_ms": self.ttft_ms,
            "upstream_ttft_ms": self.upstream_ttft_ms,
            "queue_wait_ms": self.queue_wait_ms,
            "retry_overhead_ms": self.retry_overhead_ms,
            "tpot_ms": self.tpot_ms,
        }
        if drop_none:
            return {key: value for key, value in data.items() if value is not None}
        return data


@dataclass
class CanonicalResponse:
    id: str
    model: str
    adapter: str
    text: str
    finish_reason: FinishReason
    usage: TokenUsage
    structured: dict[str, Any] | None = None
    latency: Latency = field(default_factory=Latency)
    raw: dict[str, Any] | None = None
    # Stage 3：实际生效的结构化档位（native_schema / native_json_object / prompt_repair）
    structured_mode: str | None = None
    # 网关附加说明（如「结构化输出已强制非流式」）
    note: str | None = None
    # Stage 4：提示词版本回显（DESIGN §6.3）
    prompt: dict[str, Any] | None = None

    def to_dict(self, *, include_raw: bool = False) -> dict[str, Any]:
        data = {
            "id": self.id,
            "object": "chat.completion",
            "model": self.model,
            "adapter": self.adapter,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": self.text},
                    "finish_reason": self.finish_reason.value,
                }
            ],
            "text": self.text,
            "finish_reason": self.finish_reason.value,
            "usage": self.usage.to_dict(),
            "structured": self.structured,
            "structured_mode": self.structured_mode,
            "latency": self.latency.to_dict(),
        }
        if self.note is not None:
            data["note"] = self.note
        if self.prompt is not None:
            data["prompt"] = self.prompt
        if include_raw:
            data["raw"] = self.raw
        return data


@dataclass
class CallContext:
    """单次请求的上下文，供计时、重试与流式状态共享。"""

    request_id: str
    t0: float = field(default_factory=time.perf_counter)
    attempt: int = 1
    deadline: float | None = None
    stream_started: bool = False
    client_aborted: bool = False
    # Stage 5：6 个延迟指标的数据来源；上游请求发出时间由 invoker 打点，
    # 排队与重试开销由限流/重试层回填（Stage 6）。
    upstream_started_at: float | None = None
    queue_wait_ms: float | None = None
    retry_overhead_ms: float | None = None
    retry_count: int = 0
    # Stage 6：某次失败被拒绝重试的原因（not_retryable / stream_started /
    # max_attempts / deadline），写入日志便于定位「为什么没重试」
    retry_skipped_reason: str | None = None

    def elapsed_ms(self) -> float:
        return (time.perf_counter() - self.t0) * 1000
