"""适配器接口定义：新增厂商 = 新增一个实现该 Protocol 的类 + 一条路由配置。"""

from __future__ import annotations

from typing import TYPE_CHECKING, AsyncIterable, AsyncIterator, Protocol, TypedDict, runtime_checkable

from gateway.core.errors import GatewayError
from gateway.core.events import CanonicalEvent
from gateway.core.ir import CanonicalRequest, CanonicalResponse

if TYPE_CHECKING:
    from gateway.core.router import ModelRoute


class ModelCapabilities(TypedDict):
    max_context_tokens: int
    max_output_tokens: int
    supports_stream: bool
    supports_json_schema: bool
    supports_json_object: bool
    supports_reasoning: bool
    supports_prompt_caching: bool


@runtime_checkable
class ProviderAdapter(Protocol):
    """厂商适配器协议；实现方不得反向依赖能力层做业务决策。"""

    name: str
    endpoint: str

    def build_payload(self, req: CanonicalRequest, route: "ModelRoute") -> dict: ...

    def build_headers(self, route: "ModelRoute") -> dict: ...

    def parse_response(self, raw: dict, req: CanonicalRequest) -> CanonicalResponse: ...

    def parse_sse(
        self, byte_stream: AsyncIterable[bytes]
    ) -> AsyncIterator[CanonicalEvent]: ...

    def normalize_error(
        self, status: int, body: dict | None, exc: BaseException | None = None
    ) -> GatewayError: ...

    def capabilities(self, route: "ModelRoute") -> ModelCapabilities: ...
