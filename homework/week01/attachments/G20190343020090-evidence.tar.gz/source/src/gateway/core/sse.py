"""SSE 帧解析与对外编码。

上游两家协议都走 SSE，但事件名与数据结构不同；本模块只负责「字节流 → 通用帧」，
语义映射留给适配器。对外编码固定为 OpenAI Chat Completions 兼容的 data-only 形式。
"""

from __future__ import annotations

from collections.abc import AsyncIterable, AsyncIterator
from dataclasses import dataclass

# 对外 SSE 的固定片段
HEARTBEAT_FRAME = ": heartbeat\n\n"
DONE_FRAME = "data: [DONE]\n\n"


@dataclass(frozen=True)
class SSEFrame:
    """一帧 SSE：`event` 可缺省（data-only），`data` 为多行 data 拼接后的文本。"""

    event: str | None
    data: str
    id: str | None = None


async def iter_sse_frames(stream: AsyncIterable[bytes]) -> AsyncIterator[SSEFrame]:
    """按行解析 SSE 字节流。

    只在「完整行」上做 UTF-8 解码：上游分块可能把一个多字节字符切成两半，
    直接对每个 chunk 解码会得到乱码。未知字段（id/retry）按 SSE 规范忽略，
    注释行（以 `:` 开头，如心跳）直接跳过。
    """

    buffer = b""
    event_name: str | None = None
    event_id: str | None = None
    data_lines: list[str] = []

    def _dispatch() -> SSEFrame | None:
        if not data_lines:
            return None
        return SSEFrame(event=event_name, data="\n".join(data_lines), id=event_id)

    async for chunk in stream:
        buffer += chunk
        while True:
            index = buffer.find(b"\n")
            if index < 0:
                break
            raw_line, buffer = buffer[:index], buffer[index + 1 :]
            line = raw_line.rstrip(b"\r").decode("utf-8", "replace")

            if not line:
                frame = _dispatch()
                if frame is not None:
                    yield frame
                event_name, event_id, data_lines = None, None, []
                continue
            if line.startswith(":"):
                # 注释行 / 心跳，按规范忽略
                continue

            field, _, value = line.partition(":")
            if value.startswith(" "):
                value = value[1:]
            if field == "data":
                data_lines.append(value)
            elif field == "event":
                event_name = value
            elif field == "id":
                event_id = value

    # 容错：流结束时最后一帧没有空行终结，仍按 data 行收尾。
    if buffer:
        trailing = buffer.rstrip(b"\r\n").decode("utf-8", "replace")
        if trailing.startswith("data:"):
            data_lines.append(trailing[5:].lstrip())
    frame = _dispatch()
    if frame is not None:
        yield frame


def encode_sse_data(payload: str) -> str:
    """编码一个 data-only SSE 帧。"""

    return f"data: {payload}\n\n"


def encode_heartbeat() -> str:
    """心跳是注释行，不会进入客户端的事件数据流。"""

    return HEARTBEAT_FRAME
