"""统一错误码与错误响应体。

错误码与 DESIGN.md §8.1 一一对应；上游错误必须先归一化成 `GatewayError`，
禁止把厂商原始错误体直接透给客户端。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Mapping

import structlog
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

logger = structlog.get_logger("gateway.errors")


class ErrorCode(StrEnum):
    """对外错误码枚举，严格对应 DESIGN.md §8.1 的 18 项。"""

    INVALID_REQUEST = "INVALID_REQUEST"
    MISSING_VARIABLE = "MISSING_VARIABLE"
    SCHEMA_INCOMPATIBLE = "SCHEMA_INCOMPATIBLE"
    CONTEXT_LENGTH_EXCEEDED = "CONTEXT_LENGTH_EXCEEDED"
    CONTENT_FILTERED = "CONTENT_FILTERED"
    PROMPT_NOT_FOUND = "PROMPT_NOT_FOUND"
    MODEL_NOT_FOUND = "MODEL_NOT_FOUND"
    AUTH_FAILED = "AUTH_FAILED"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    RATE_LIMITED = "RATE_LIMITED"
    UPSTREAM_AUTH = "UPSTREAM_AUTH"
    UPSTREAM_BAD_REQUEST = "UPSTREAM_BAD_REQUEST"
    UPSTREAM_TIMEOUT = "UPSTREAM_TIMEOUT"
    UPSTREAM_UNAVAILABLE = "UPSTREAM_UNAVAILABLE"
    UPSTREAM_BAD_RESPONSE = "UPSTREAM_BAD_RESPONSE"
    OUTPUT_PARSE_FAILED = "OUTPUT_PARSE_FAILED"
    STREAM_INTERRUPTED = "STREAM_INTERRUPTED"
    INTERNAL = "INTERNAL"


@dataclass(frozen=True)
class ErrorSpec:
    """单个错误码的 HTTP / 分类 / 可重试属性。"""

    http_status: int
    error_type: str
    retryable: bool


ERROR_SPECS: Mapping[str, ErrorSpec] = {
    ErrorCode.INVALID_REQUEST.value: ErrorSpec(400, "invalid_request", False),
    ErrorCode.MISSING_VARIABLE.value: ErrorSpec(400, "invalid_request", False),
    ErrorCode.SCHEMA_INCOMPATIBLE.value: ErrorSpec(400, "invalid_request", False),
    ErrorCode.CONTEXT_LENGTH_EXCEEDED.value: ErrorSpec(400, "invalid_request", False),
    ErrorCode.CONTENT_FILTERED.value: ErrorSpec(400, "invalid_request", False),
    ErrorCode.PROMPT_NOT_FOUND.value: ErrorSpec(404, "not_found", False),
    ErrorCode.MODEL_NOT_FOUND.value: ErrorSpec(404, "not_found", False),
    ErrorCode.AUTH_FAILED.value: ErrorSpec(401, "authentication_error", False),
    ErrorCode.PERMISSION_DENIED.value: ErrorSpec(403, "permission_error", False),
    ErrorCode.RATE_LIMITED.value: ErrorSpec(429, "rate_limited", True),
    ErrorCode.UPSTREAM_AUTH.value: ErrorSpec(401, "upstream_error", False),
    ErrorCode.UPSTREAM_BAD_REQUEST.value: ErrorSpec(400, "upstream_error", False),
    ErrorCode.UPSTREAM_TIMEOUT.value: ErrorSpec(504, "upstream_error", True),
    ErrorCode.UPSTREAM_UNAVAILABLE.value: ErrorSpec(503, "upstream_error", True),
    ErrorCode.UPSTREAM_BAD_RESPONSE.value: ErrorSpec(502, "upstream_error", True),
    ErrorCode.OUTPUT_PARSE_FAILED.value: ErrorSpec(502, "upstream_error", True),
    ErrorCode.STREAM_INTERRUPTED.value: ErrorSpec(502, "upstream_error", True),
    ErrorCode.INTERNAL.value: ErrorSpec(500, "internal_error", False),
}

_INTERNAL_SPEC = ERROR_SPECS[ErrorCode.INTERNAL.value]


def spec_for(code: str | ErrorCode) -> ErrorSpec:
    """取错误码规格；未知错误码退化为 INTERNAL，避免异常处理器自身再抛错。"""

    return ERROR_SPECS.get(str(code), _INTERNAL_SPEC)


class GatewayError(Exception):
    """网关统一异常：所有对外错误都必须收敛到这里。"""

    def __init__(
        self,
        code: str | ErrorCode,
        message: str,
        *,
        details: dict[str, Any] | None = None,
        http_status: int | None = None,
        retryable: bool | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.code = str(code)
        self.message = message
        spec = spec_for(self.code)
        self.error_type = spec.error_type
        self.status_code = spec.http_status if http_status is None else http_status
        self.retryable = spec.retryable if retryable is None else retryable
        self.details = details
        self.headers = headers or {}
        super().__init__(message)


def build_error_body(
    code: str | ErrorCode,
    message: str,
    request_id: str,
    *,
    details: dict[str, Any] | None = None,
    debug: bool = False,
    retryable: bool | None = None,
) -> dict[str, Any]:
    """构造统一错误响应体；`details` 仅在 debug 模式下透出。"""

    spec = spec_for(code)
    error: dict[str, Any] = {
        "code": str(code),
        "message": message,
        "type": spec.error_type,
        "request_id": request_id,
        "retryable": spec.retryable if retryable is None else retryable,
    }
    if debug and details is not None:
        error["details"] = details
    return {"error": error}


def error_response(
    exc: GatewayError,
    request_id: str,
    *,
    debug: bool = False,
) -> JSONResponse:
    """把 `GatewayError` 渲染成统一 JSON 错误响应。"""

    body = build_error_body(
        exc.code,
        exc.message,
        request_id,
        details=exc.details,
        debug=debug,
        retryable=exc.retryable,
    )
    return JSONResponse(status_code=exc.status_code, content=body, headers=exc.headers)


def _status_to_code(status: int) -> ErrorCode:
    """框架级 HTTPException 的错误码映射，只为兜底统一响应体形状。"""

    return {
        400: ErrorCode.INVALID_REQUEST,
        401: ErrorCode.AUTH_FAILED,
        403: ErrorCode.PERMISSION_DENIED,
        404: ErrorCode.MODEL_NOT_FOUND,
        429: ErrorCode.RATE_LIMITED,
        504: ErrorCode.UPSTREAM_TIMEOUT,
        503: ErrorCode.UPSTREAM_UNAVAILABLE,
        502: ErrorCode.UPSTREAM_BAD_RESPONSE,
    }.get(status, ErrorCode.INTERNAL if status >= 500 else ErrorCode.INVALID_REQUEST)


def _serializable_errors(exc: RequestValidationError) -> list[dict[str, Any]]:
    """pydantic 的 `ctx` 可能携带异常对象，直接放进 JSON 响应会导致二次 500。"""

    errors: list[dict[str, Any]] = []
    for err in exc.errors():
        item = dict(err)
        ctx = item.get("ctx")
        if isinstance(ctx, dict):
            item["ctx"] = {key: str(value) for key, value in ctx.items()}
        errors.append(item)
    return errors


def install_exception_handlers(app: FastAPI, *, debug: bool = False) -> None:
    """注册全局异常处理器，保证所有错误都走统一响应体。"""

    def _request_id(request: Request) -> str:
        return getattr(request.state, "request_id", "req_unknown")

    @app.exception_handler(GatewayError)
    async def _handle_gateway_error(request: Request, exc: GatewayError) -> JSONResponse:
        rid = _request_id(request)
        logger.warning(
            "gateway.error",
            code=exc.code,
            status=exc.status_code,
            request_id=rid,
            retryable=exc.retryable,
            message=exc.message,
        )
        return error_response(exc, rid, debug=debug)

    @app.exception_handler(RequestValidationError)
    async def _handle_validation_error(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        rid = _request_id(request)
        gateway_error = GatewayError(
            ErrorCode.INVALID_REQUEST,
            "request validation failed",
            details={"errors": _serializable_errors(exc)},
        )
        logger.warning(
            "gateway.error",
            code=gateway_error.code,
            request_id=rid,
            message=gateway_error.message,
        )
        return error_response(gateway_error, rid, debug=debug)

    @app.exception_handler(StarletteHTTPException)
    async def _handle_http_error(
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        rid = _request_id(request)
        code = _status_to_code(exc.status_code)
        gateway_error = GatewayError(
            code,
            str(exc.detail),
            http_status=exc.status_code,
            headers=dict(exc.headers or {}),
        )
        return error_response(gateway_error, rid, debug=debug)

    @app.exception_handler(Exception)
    async def _handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
        rid = _request_id(request)
        logger.exception("gateway.internal_error", request_id=rid, error=repr(exc))
        gateway_error = GatewayError(
            ErrorCode.INTERNAL,
            "internal gateway error",
            details={"exception": repr(exc)},
        )
        return error_response(gateway_error, rid, debug=debug)
