"""`ResponseFormat` → 各家方言，以及 L3 提示词中的 schema 说明。

对外契约沿用 OpenAI 风格（DESIGN.md §5.1），厂商差异集中在这里：
- OpenAI Responses：`text.format`
- Anthropic Messages：`output_config.format`（GA 写法，不用已废弃的 beta `response_format`）
"""

from __future__ import annotations

import json
from typing import Any

from gateway.core.ir import ResponseFormat


def openai_text_format(fmt: ResponseFormat) -> dict[str, Any]:
    """OpenAI Responses 的 `text.format` 片段。"""

    if fmt.type == "json_object":
        return {"type": "json_object"}
    if fmt.type == "json_schema":
        return {
            "type": "json_schema",
            "name": fmt.name or "response",
            "schema": fmt.schema or {},
            "strict": fmt.strict,
        }
    return {"type": "text"}


def anthropic_output_config(fmt: ResponseFormat) -> dict[str, Any] | None:
    """Anthropic 的 `output_config` 片段。

    `json_object` 在 Anthropic 无等价能力（返回 None），由 L3 提示词兜底。
    """

    if fmt.type != "json_schema":
        return None
    return {
        "format": {
            "type": "json_schema",
            "json_schema": {
                "name": fmt.name or "response",
                "schema": fmt.schema or {},
            },
        }
    }


def prompt_instruction(fmt: ResponseFormat) -> str:
    """L3 兜底：把结构化约束写进系统提示。

    明确禁止 Markdown 围栏与解释性文字，降低解析失败率。
    """

    if fmt.type == "json_schema" and fmt.schema is not None:
        schema_text = json.dumps(fmt.schema, ensure_ascii=False, indent=2)
        return (
            "你必须只输出一个 JSON 对象，且严格满足以下 JSON Schema：\n"
            f"{schema_text}\n"
            "不要输出任何解释、前后缀文字或 Markdown 围栏（不要 ```json）。"
        )
    return (
        "你必须只输出一个合法的 JSON 对象，不要输出任何解释、前后缀文字或 "
        "Markdown 围栏（不要 ```json）。"
    )
