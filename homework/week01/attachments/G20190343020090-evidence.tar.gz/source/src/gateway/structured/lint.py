"""Schema 兼容子集 lint（DESIGN.md §5.3 的六条规则）。

两家 grammar 引擎支持的 JSON Schema 子集不同，网关在请求入口统一 lint：
不合规直接 `400 SCHEMA_INCOMPATIBLE`，把上游 500 变成客户端 400。

规则一览：
1. 每个 object 必须显式 `additionalProperties: false`；
2. 所有字段必须进 `required`，可选字段用 `["string","null"]` 表达；
3. 禁用 `$ref` / `$defs`（需内联展开）；
4. 禁用 `oneOf`（联合类型用带判别字段的 `anyOf`）；
5. 禁用 `pattern` / `format`（各引擎不保证执行，改用 `enum`）；
6. 嵌套深度 ≤ 5、属性数 ≤ 100、schema ≤ 20KB。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from gateway.core.errors import ErrorCode, GatewayError

MAX_DEPTH = 5
MAX_PROPERTIES = 100
MAX_SCHEMA_BYTES = 20_000

# keyword -> (规则名, 违规说明)
_FORBIDDEN_KEYWORDS: tuple[tuple[str, str, str], ...] = (
    ("$ref", "no_ref", "$ref is not supported; inline the referenced schema"),
    ("$defs", "no_defs", "$defs is not supported; inline the definitions"),
    ("definitions", "no_defs", "definitions is not supported; inline the definitions"),
    ("oneOf", "no_oneof", "oneOf is not supported; use anyOf with a discriminator field"),
    ("pattern", "no_pattern", "pattern is not supported; use enum instead"),
    ("format", "no_format", "format is not supported; use enum instead"),
)


@dataclass(frozen=True)
class LintIssue:
    """单条 lint 违规：带 JSON 路径，便于客户端定位。"""

    path: str
    rule: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {"path": self.path, "rule": self.rule, "message": self.message}


class _WalkState:
    def __init__(
        self,
        *,
        max_depth: int,
        max_properties: int,
    ) -> None:
        self.issues: list[LintIssue] = []
        self.property_count = 0
        self.max_depth = max_depth
        self.max_properties = max_properties


def lint_schema(
    schema: Any,
    *,
    max_depth: int = MAX_DEPTH,
    max_properties: int = MAX_PROPERTIES,
    max_bytes: int = MAX_SCHEMA_BYTES,
) -> list[LintIssue]:
    """返回全部违规项；空列表表示 schema 落在兼容子集内。"""

    if not isinstance(schema, dict):
        return [LintIssue("$", "invalid_schema", "schema must be a JSON object")]

    state = _WalkState(max_depth=max_depth, max_properties=max_properties)

    try:
        size = len(json.dumps(schema, ensure_ascii=False).encode("utf-8"))
    except (TypeError, ValueError):
        return [LintIssue("$", "invalid_schema", "schema is not JSON serializable")]
    if size > max_bytes:
        state.issues.append(
            LintIssue(
                "$",
                "schema_too_large",
                f"schema is {size} bytes, exceeding the {max_bytes}-byte limit",
            )
        )

    _walk(schema, "$", 1, state)

    if state.property_count > max_properties:
        state.issues.append(
            LintIssue(
                "$",
                "too_many_properties",
                f"schema declares {state.property_count} properties, "
                f"exceeding the {max_properties} limit",
            )
        )
    return state.issues


def ensure_compatible(schema: Any, *, name: str | None = None) -> None:
    """校验 schema；不合规抛 `400 SCHEMA_INCOMPATIBLE`（details 回显全部违规）。"""

    issues = lint_schema(schema)
    if not issues:
        return
    raise GatewayError(
        ErrorCode.SCHEMA_INCOMPATIBLE,
        "response_format.json_schema.schema is outside the gateway's compatible "
        "JSON Schema subset",
        details={
            "schema_name": name,
            "issues": [issue.to_dict() for issue in issues],
        },
    )


def _walk(node: Any, path: str, depth: int, state: _WalkState) -> None:
    if not isinstance(node, dict):
        return

    for keyword, rule, message in _FORBIDDEN_KEYWORDS:
        if keyword in node:
            state.issues.append(LintIssue(path, rule, message))

    is_object = _is_object(node)
    # 深度只按 object 嵌套计（标量叶子不算一层），与「嵌套深度」的直觉一致
    if is_object and depth > state.max_depth:
        state.issues.append(
            LintIssue(
                path,
                "max_depth",
                f"schema nesting depth exceeds {state.max_depth} at {path}",
            )
        )
        # 不再深入：避免一个超深 schema 产生成百上千条噪声
        return

    properties = node.get("properties")
    if isinstance(properties, dict):
        state.property_count += len(properties)
        _check_object_keywords(node, path, properties, state)
        for prop_name, prop_schema in properties.items():
            _walk(prop_schema, f"{path}.{prop_name}", depth + 1, state)
    elif is_object:
        # 空对象（没有 properties）同样必须显式关闭额外字段
        _check_object_keywords(node, path, {}, state)

    items = node.get("items")
    if isinstance(items, dict):
        _walk(items, f"{path}[]", depth + 1, state)
    elif isinstance(items, list):
        for index, sub_schema in enumerate(items):
            _walk(sub_schema, f"{path}[{index}]", depth + 1, state)

    for combinator in ("anyOf", "allOf"):
        branches = node.get(combinator)
        if isinstance(branches, list):
            for index, sub_schema in enumerate(branches):
                _walk(sub_schema, f"{path}.{combinator}[{index}]", depth + 1, state)


def _is_object(node: dict) -> bool:
    node_type = node.get("type")
    if node_type == "object":
        return True
    if isinstance(node_type, list) and "object" in node_type:
        return True
    return "properties" in node


def _check_object_keywords(
    node: dict,
    path: str,
    properties: dict[str, Any],
    state: _WalkState,
) -> None:
    if node.get("additionalProperties") is not False:
        state.issues.append(
            LintIssue(
                path,
                "additional_properties",
                "object schemas must set additionalProperties to false",
            )
        )

    required = node.get("required")
    required_names = set(required) if isinstance(required, list) else set()
    for prop_name in properties:
        if prop_name not in required_names:
            state.issues.append(
                LintIssue(
                    f"{path}.{prop_name}",
                    "missing_required",
                    "every property must be listed in required; "
                    'express optional fields as ["string","null"]',
                )
            )
