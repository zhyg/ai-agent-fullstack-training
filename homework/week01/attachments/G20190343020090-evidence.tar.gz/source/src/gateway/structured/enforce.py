"""结构化输出三档降级编排（DESIGN.md §5.2 / §5.4）。

档位：
- **L1 `native_schema`**：上游原生 grammar 约束（语法 + schema 双保证）；
- **L2 `native_json_object`**：仅要求合法 JSON（Anthropic 无此能力 → 降级 L3）；
- **L3 `prompt_repair`**：提示词注入 schema，本地 `json.loads` + jsonschema 校验，
  失败把错误回灌给模型重试（由 `Gateway` 负责重试循环，≤2 次）。

本模块只做「决策 + 提示词改写 + 解析校验」，不发起任何网络调用。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace
from enum import StrEnum
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError

from gateway.core.adapter import ModelCapabilities
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.ir import (
    CanonicalMessage,
    CanonicalRequest,
    ResponseFormat,
    Role,
)
from gateway.structured.lint import ensure_compatible
from gateway.structured.translate import prompt_instruction

_FENCE_RE = re.compile(r"```(?:json|JSON)?\s*(.*?)\s*```", re.DOTALL)


class StructuredMode(StrEnum):
    """实际生效的档位，会回显在响应体的 `structured_mode`。"""

    NATIVE_SCHEMA = "native_schema"
    NATIVE_JSON_OBJECT = "native_json_object"
    PROMPT_REPAIR = "prompt_repair"


@dataclass(frozen=True)
class StructuredPlan:
    """一次结构化请求的执行计划。

    `format` 保留客户端原始契约（用于校验与提示词），`schema` 为 lint 通过的 schema。
    """

    mode: StructuredMode
    format: ResponseFormat
    schema: dict[str, Any] | None = None


class StructuredOutputError(Exception):
    """本地解析/校验失败的统一异常，由调用方决定重试还是报错。"""


def choose_mode(
    fmt: ResponseFormat | None,
    capabilities: ModelCapabilities,
) -> StructuredPlan | None:
    """按能力声明选择档位；`json_schema` 在这里先过 lint。"""

    if fmt is None or fmt.type == "text":
        return None

    if fmt.type == "json_schema":
        schema = fmt.schema or {}
        ensure_compatible(schema, name=fmt.name)
        if capabilities.get("supports_json_schema"):
            return StructuredPlan(StructuredMode.NATIVE_SCHEMA, fmt, schema)
        return StructuredPlan(StructuredMode.PROMPT_REPAIR, fmt, schema)

    if capabilities.get("supports_json_object"):
        return StructuredPlan(StructuredMode.NATIVE_JSON_OBJECT, fmt)
    # Anthropic 无 json_object 等价能力 → 提示词兜底
    return StructuredPlan(StructuredMode.PROMPT_REPAIR, fmt)


def apply_plan(req: CanonicalRequest, plan: StructuredPlan | None) -> CanonicalRequest:
    """把计划落到实际上游请求上。

    L3 会清空 `response_format`（避免向不支持原生 schema 的厂商下发无效字段），
    并把 schema 说明注入 system 提示。
    """

    if plan is None:
        return req
    if plan.mode is not StructuredMode.PROMPT_REPAIR:
        return replace(req, response_format=plan.format)

    instruction = prompt_instruction(plan.format)
    system = f"{req.system}\n\n{instruction}" if req.system else instruction
    return replace(req, response_format=None, system=system)


def build_repair_request(
    req: CanonicalRequest,
    plan: StructuredPlan,
    previous_text: str,
    error_message: str,
) -> CanonicalRequest:
    """把上一次的非法输出与错误原因回灌给模型，形成一次修复请求。"""

    if plan.format.type == "json_schema":
        repair_note = (
            f"上一次输出未通过校验：{error_message}\n"
            "请严格按前面的 JSON Schema 重新生成，只返回 JSON 对象本身，"
            "不要解释、不要 Markdown 围栏。"
        )
    else:
        repair_note = (
            f"上一次输出不是合法的 JSON 对象：{error_message}\n"
            "请重新生成，只返回一个 JSON 对象本身，不要解释、不要 Markdown 围栏。"
        )

    messages = [
        *req.messages,
        CanonicalMessage(role=Role.ASSISTANT, content=previous_text),
        CanonicalMessage(role=Role.USER, content=repair_note),
    ]
    return apply_plan(replace(req, messages=messages), plan)


def extract_structured(text: str, fmt: ResponseFormat) -> dict[str, Any]:
    """剥离围栏 → `json.loads` → （json_schema 时）jsonschema 校验。"""

    data = _parse_json_object(text)
    if fmt.type == "json_schema" and fmt.schema:
        _validate_against_schema(data, fmt.schema)
    return data


def strip_code_fences(text: str) -> str:
    """模型偶尔仍会加 ```json 围栏；优先取围栏内的内容。"""

    match = _FENCE_RE.search(text)
    if match:
        return match.group(1).strip()
    return text.strip()


def _parse_json_object(text: str) -> dict[str, Any]:
    if not text or not text.strip():
        raise StructuredOutputError("model returned empty content")
    candidate = strip_code_fences(text)
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise StructuredOutputError(
            f"invalid JSON at line {exc.lineno} column {exc.colno}: {exc.msg}"
        ) from exc

    if not isinstance(data, dict):
        raise StructuredOutputError(
            f"expected a JSON object, got {type(data).__name__}"
        )
    return data


def _validate_against_schema(data: dict[str, Any], schema: dict[str, Any]) -> None:
    try:
        validator = Draft202012Validator(schema)
    except SchemaError as exc:  # lint 之后理论上不会发生，兜底避免 500
        raise GatewayError(
            ErrorCode.SCHEMA_INCOMPATIBLE,
            f"schema is not a valid JSON Schema: {exc.message}",
            details={"schema_path": list(exc.path)},
        ) from exc

    errors = sorted(
        validator.iter_errors(data),
        key=lambda error: list(error.absolute_path),
    )
    if not errors:
        return

    first = errors[0]
    location = "$" + "".join(
        f"[{part}]" if isinstance(part, int) else f".{part}"
        for part in first.absolute_path
    )
    raise StructuredOutputError(
        f"schema validation failed at {location}: {first.message}"
    )
