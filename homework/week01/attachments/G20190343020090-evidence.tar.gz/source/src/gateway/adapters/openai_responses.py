"""OpenAI Responses API 适配器（`POST /v1/responses`）。

对应路由模型：`deepseek-v4-pro`。
"""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterable, AsyncIterator

import httpx

from gateway.core.adapter import ModelCapabilities
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.events import CanonicalEvent
from gateway.core.ir import (
    CanonicalRequest,
    CanonicalResponse,
    FinishReason,
    TokenUsage,
)
from gateway.core.router import ModelRoute
from gateway.core.sse import iter_sse_frames
from gateway.structured.translate import openai_text_format

_CONTEXT_ERROR_HINTS = ("context_length", "context length", "maximum context", "too long")


class OpenAIResponsesAdapter:
    name = "openai_responses"
    endpoint = "/v1/responses"

    def _api_key(self, route: ModelRoute) -> str:
        key = os.getenv(route.api_key_env)
        if not key:
            raise GatewayError(
                ErrorCode.UPSTREAM_AUTH,
                f"API key env '{route.api_key_env}' is not set",
                details={"api_key_env": route.api_key_env},
            )
        return key

    def build_headers(self, route: ModelRoute) -> dict[str, str]:
        # 鉴权差异集中在这里：OpenAI 用 Bearer，Anthropic 用 x-api-key。
        return {
            "Authorization": f"Bearer {self._api_key(route)}",
            "Content-Type": "application/json",
        }

    def build_payload(self, req: CanonicalRequest, route: ModelRoute) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": route.upstream_model,
            "input": [
                {
                    "role": message.role.value,
                    "content": [{"type": "input_text", "text": message.content}],
                }
                for message in req.messages
            ],
            "max_output_tokens": req.max_output_tokens or route.default_max_tokens,
            "stream": req.stream,
        }
        if req.system:
            payload["instructions"] = req.system
        if req.temperature is not None:
            payload["temperature"] = req.temperature
        if req.top_p is not None:
            payload["top_p"] = req.top_p
        if req.stop:
            payload["stop"] = req.stop
        if req.user:
            payload["user"] = req.user
        if req.response_format is not None:
            # 方言翻译集中在 structured/translate.py，适配器只做字段挂载。
            payload["text"] = {"format": openai_text_format(req.response_format)}
        return payload

    def parse_response(self, raw: dict, req: CanonicalRequest) -> CanonicalResponse:
        texts: list[str] = []
        refusal = _find_refusal(raw)
        for item in raw.get("output") or []:
            if item.get("type") != "message":
                continue
            for part in item.get("content") or []:
                if part.get("type") in ("output_text", "text"):
                    texts.append(part.get("text") or "")

        return CanonicalResponse(
            id=str(raw.get("id") or req.request_id),
            model=str(raw.get("model") or ""),
            adapter=self.name,
            text="".join(texts),
            finish_reason=self._finish_reason(raw, refusal=refusal is not None),
            usage=self._usage(raw),
            raw=raw,
        )

    def _usage(self, raw: dict) -> TokenUsage:
        """把 OpenAI usage 映射成五分类；`cached_tokens` 归入 cache_read。"""

        usage_raw: dict[str, Any] = raw.get("usage") or {}
        input_details: dict[str, Any] = usage_raw.get("input_tokens_details") or {}
        output_details: dict[str, Any] = usage_raw.get("output_tokens_details") or {}
        return TokenUsage(
            input_tokens=int(usage_raw.get("input_tokens") or 0),
            output_tokens=int(usage_raw.get("output_tokens") or 0),
            reasoning_tokens=int(output_details.get("reasoning_tokens") or 0),
            cache_read_tokens=int(input_details.get("cached_tokens") or 0),
            source="reported",
        )

    def _finish_reason(self, raw: dict, *, refusal: bool = False) -> FinishReason:
        status = raw.get("status")
        incomplete_reason = (raw.get("incomplete_details") or {}).get("reason")
        if refusal:
            return FinishReason.CONTENT_FILTER
        if status == "incomplete" and incomplete_reason in ("max_output_tokens", "max_tokens"):
            return FinishReason.LENGTH
        if status == "failed":
            return FinishReason.ERROR
        return FinishReason.STOP

    async def parse_sse(
        self, byte_stream: AsyncIterable[bytes]
    ) -> AsyncIterator[CanonicalEvent]:
        """解析 Responses API 的事件流（事件映射见 DESIGN.md §4.2）。

        未识别的事件类型静默忽略，保证上游新增事件不会打断旧网关。
        """

        seq = 0
        async for frame in iter_sse_frames(byte_stream):
            if not frame.data or frame.data.strip() == "[DONE]":
                continue
            payload = _load_event(frame.data)
            if payload is None:
                continue
            event_type = str(payload.get("type") or frame.event or "")
            seq += 1

            if event_type in ("response.created", "response.in_progress"):
                yield CanonicalEvent(type="start", upstream_seq=seq)
            elif event_type == "response.output_text.delta":
                delta = payload.get("delta")
                if isinstance(delta, str) and delta:
                    yield CanonicalEvent(type="delta", text_delta=delta, upstream_seq=seq)
            elif event_type == "response.output_text.done":
                # 网关自己累积文本，不用上游的整段回放
                continue
            elif event_type in ("response.completed", "response.incomplete"):
                response = payload.get("response") or payload
                raw = response if isinstance(response, dict) else {}
                yield CanonicalEvent(
                    type="done",
                    usage=self._usage(raw),
                    finish_reason=self._finish_reason(
                        raw, refusal=_find_refusal(raw) is not None
                    ),
                    upstream_seq=seq,
                )
            elif event_type in ("response.failed", "error"):
                yield CanonicalEvent(
                    type="error", error=self._stream_error(payload), upstream_seq=seq
                )
            elif event_type == "ping":
                yield CanonicalEvent(type="ping", upstream_seq=seq)

    def _stream_error(self, payload: dict) -> GatewayError:
        """流中错误无法改 HTTP 状态码，统一交给 SSE 出口渲染 error 事件。"""

        error = payload.get("error") if isinstance(payload.get("error"), dict) else payload
        message = str(error.get("message") or error.get("code") or "upstream stream failed")
        return GatewayError(
            ErrorCode.UPSTREAM_BAD_RESPONSE,
            message,
            details={"upstream_event": payload.get("type") or "error"},
        )

    def normalize_error(
        self, status: int, body: dict | None, exc: BaseException | None = None
    ) -> GatewayError:
        details: dict[str, Any] = {"upstream_status": status}
        if body is not None:
            details["upstream_body"] = body
        if exc is not None:
            if isinstance(exc, (httpx.TimeoutException, TimeoutError)):
                return GatewayError(
                    ErrorCode.UPSTREAM_TIMEOUT, f"upstream timeout: {exc!r}", details=details
                )
            if isinstance(exc, httpx.HTTPError):
                return GatewayError(
                    ErrorCode.UPSTREAM_UNAVAILABLE,
                    f"upstream connection error: {exc!r}",
                    details=details,
                )
        if status in (401, 403):
            return GatewayError(
                ErrorCode.UPSTREAM_AUTH, f"upstream auth failed (HTTP {status})", details=details
            )
        if status == 400:
            message = _error_text(body)
            if any(hint in message.lower() for hint in _CONTEXT_ERROR_HINTS):
                return GatewayError(
                    ErrorCode.CONTEXT_LENGTH_EXCEEDED,
                    "upstream rejected request: context length exceeded",
                    details=details,
                )
            return GatewayError(
                ErrorCode.UPSTREAM_BAD_REQUEST, "upstream rejected request", details=details
            )
        if status in (408, 409, 429, 500, 502, 503, 504, 529):
            return GatewayError(
                ErrorCode.UPSTREAM_UNAVAILABLE, f"upstream unavailable (HTTP {status})", details=details
            )
        if status >= 400:
            return GatewayError(
                ErrorCode.UPSTREAM_BAD_REQUEST, f"upstream returned HTTP {status}", details=details
            )
        return GatewayError(
            ErrorCode.UPSTREAM_UNAVAILABLE, "upstream connection failed", details=details
        )

    def capabilities(self, route: ModelRoute) -> ModelCapabilities:
        return {
            "max_context_tokens": 128_000,
            "max_output_tokens": route.default_max_tokens,
            "supports_stream": True,
            "supports_json_schema": True,
            "supports_json_object": True,
            "supports_reasoning": True,
            "supports_prompt_caching": True,
        }


def _error_text(body: dict | None) -> str:
    if not body:
        return ""
    error = body.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("code") or "")
    return str(body)


def _find_refusal(raw: dict) -> str | None:
    """strict 模式下安全拒答落在 `refusal` 字段，而非普通文本。"""

    for item in raw.get("output") or []:
        for part in item.get("content") or []:
            if part.get("type") == "refusal":
                return str(part.get("refusal") or part.get("text") or "refused")
    return None


def _load_event(data: str) -> dict | None:
    try:
        loaded = json.loads(data)
    except json.JSONDecodeError:
        return None
    return loaded if isinstance(loaded, dict) else None
