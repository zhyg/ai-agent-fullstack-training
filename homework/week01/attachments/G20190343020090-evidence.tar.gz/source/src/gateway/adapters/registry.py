"""适配器注册表：name -> ProviderAdapter 实例。"""

from __future__ import annotations

from gateway.adapters.anthropic_messages import AnthropicMessagesAdapter
from gateway.adapters.openai_responses import OpenAIResponsesAdapter
from gateway.core.adapter import ProviderAdapter
from gateway.core.errors import ErrorCode, GatewayError


class AdapterRegistry:
    def __init__(self, adapters: dict[str, ProviderAdapter] | None = None) -> None:
        self._adapters = dict(adapters or {})

    @classmethod
    def default(cls) -> "AdapterRegistry":
        return cls(
            {
                "openai_responses": OpenAIResponsesAdapter(),
                "anthropic_messages": AnthropicMessagesAdapter(),
            }
        )

    def register(self, adapter: ProviderAdapter) -> None:
        self._adapters[adapter.name] = adapter

    def get(self, name: str) -> ProviderAdapter:
        adapter = self._adapters.get(name)
        if adapter is None:
            raise GatewayError(
                ErrorCode.INTERNAL,
                f"adapter '{name}' is not registered",
                details={"registered_adapters": sorted(self._adapters)},
            )
        return adapter

    def names(self) -> list[str]:
        return sorted(self._adapters)
