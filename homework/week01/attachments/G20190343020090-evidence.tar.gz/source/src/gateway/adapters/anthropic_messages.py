"""Anthropic Messages API 适配器（`POST /v1/messages`）。

对应路由模型：`deepseek-v4-flash`。
"""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterable, AsyncIterator

import httpx

from gateway.core.adapter import ModelCapabilities
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.events import CanonicalEvent
from gateway.core.ir import (
    CanonicalRequest,
    CanonicalResponse,
    FinishReason,
    Role,
    TokenUsage,
)
from gateway.core.router import ModelRoute
from gateway.core.sse import iter_sse_frames
from gateway.structured.translate import anthropic_output_config

ANTHROPIC_VERSION = "2023-06-01"
_CONTEXT_ERROR_HINTS = ("prompt is too long", "context length", "maximum context")


class AnthropicMessagesAdapter:
    name = "anthropic_messages"
    endpoint = "/v1/messages"

    def _api_key(self, route: ModelRoute) -> str:
        key = os.getenv(route.api_key_env)
        if not key:
            raise GatewayError(
                ErrorCode.UPSTREAM_AUTH,
                f"API key env '{route.api_key_env}' is not set",
                details={"api_key_env": route.api_key_env},
            )
        return key

    def build_headers(self, route: ModelRoute) -> dict[str, str]:
        return {
            "x-api-key": self._api_key(route),
            "anthropic-version": ANTHROPIC_VERSION,
            "Content-Type": "application/json",
        }

    def build_payload(self, req: CanonicalRequest, route: ModelRoute) -> dict[str, Any]:
        system_parts = [req.system] if req.system else []
        messages: list[dict[str, Any]] = []
        for message in req.messages:
            if message.role == Role.SYSTEM:
                # Anthropic 没有 system role，必须提升到顶层 system。
                system_parts.append(message.content)
                continue
            messages.append({"role": message.role.value, "content": message.content})

        payload: dict[str, Any] = {
            "model": route.upstream_model,
            # Anthropic 的 max_tokens 必填，未指定时用路由默认值兜底。
            "max_tokens": req.max_output_tokens or route.default_max_tokens,
            "messages": messages,
            "stream": req.stream,
        }
        if system_parts:
            payload["system"] = "\n\n".join(system_parts)
        if req.temperature is not None:
            payload["temperature"] = req.temperature
        if req.top_p is not None:
            payload["top_p"] = req.top_p
        if req.stop:
            payload["stop_sequences"] = req.stop
        if req.response_format is not None:
            # json_object 在 Anthropic 无等价能力，translate 返回 None → L3 提示词兜底。
            output_config = anthropic_output_config(req.response_format)
            if output_config is not None:
                payload["output_config"] = output_config
        return payload

    def parse_response(self, raw: dict, req: CanonicalRequest) -> CanonicalResponse:
        texts: list[str] = []
        for block in raw.get("content") or []:
            if block.get("type") == "text":
                texts.append(block.get("text") or "")

        return CanonicalResponse(
            id=str(raw.get("id") or req.request_id),
            model=str(raw.get("model") or ""),
            adapter=self.name,
            text="".join(texts),
            finish_reason=_map_finish_reason(raw.get("stop_reason")),
            usage=self._usage(raw.get("usage") or {}),
            raw=raw,
        )

    def _usage(self, usage_raw: dict[str, Any]) -> TokenUsage:
        return TokenUsage(
            input_tokens=int(usage_raw.get("input_tokens") or 0),
            output_tokens=int(usage_raw.get("output_tokens") or 0),
            cache_read_tokens=int(usage_raw.get("cache_read_input_tokens") or 0),
            cache_write_tokens=int(usage_raw.get("cache_creation_input_tokens") or 0),
            source="reported",
        )

    async def parse_sse(
        self, byte_stream: AsyncIterable[bytes]
    ) -> AsyncIterator[CanonicalEvent]:
        """解析 Messages API 事件流（事件映射见 DESIGN.md §4.2）。

        `message_start` 就带 input_tokens，`message_delta` 带 output_tokens 与
        stop_reason，真正的终态是 `message_stop`。
        """

        seq = 0
        usage = TokenUsage(source="reported")
        stop_reason: str | None = None
        async for frame in iter_sse_frames(byte_stream):
            if not frame.data or frame.data.strip() == "[DONE]":
                continue
            payload = _load_event(frame.data)
            if payload is None:
                continue
            event_type = str(payload.get("type") or frame.event or "")
            seq += 1

            if event_type == "message_start":
                message = payload.get("message") or {}
                raw_usage = message.get("usage") or {}
                usage = self._usage(raw_usage)
                yield CanonicalEvent(type="start", usage=usage, upstream_seq=seq)
            elif event_type == "content_block_delta":
                delta = payload.get("delta") or {}
                if delta.get("type") == "text_delta" and delta.get("text"):
                    yield CanonicalEvent(
                        type="delta", text_delta=str(delta["text"]), upstream_seq=seq
                    )
            elif event_type == "content_block_start":
                # 包装事件（含 thinking / text 块起始）不对外透出
                continue
            elif event_type == "message_delta":
                delta = payload.get("delta") or {}
                if delta.get("stop_reason"):
                    stop_reason = str(delta["stop_reason"])
                raw_usage = payload.get("usage") or {}
                if raw_usage.get("output_tokens") is not None:
                    usage.output_tokens = int(raw_usage["output_tokens"])
                # 终态留给 message_stop，避免重复 done
            elif event_type == "message_stop":
                yield CanonicalEvent(
                    type="done",
                    usage=TokenUsage(
                        input_tokens=usage.input_tokens,
                        output_tokens=usage.output_tokens,
                        reasoning_tokens=usage.reasoning_tokens,
                        cache_read_tokens=usage.cache_read_tokens,
                        cache_write_tokens=usage.cache_write_tokens,
                        source=usage.source,
                    ),
                    finish_reason=_map_finish_reason(stop_reason),
                    upstream_seq=seq,
                )
            elif event_type == "error":
                yield CanonicalEvent(
                    type="error", error=self._stream_error(payload), upstream_seq=seq
                )
            elif event_type == "ping":
                yield CanonicalEvent(type="ping", upstream_seq=seq)

    def _stream_error(self, payload: dict) -> GatewayError:
        error = payload.get("error") if isinstance(payload.get("error"), dict) else {}
        message = str(error.get("message") or "upstream stream failed")
        error_type = str(error.get("type") or "")
        code = (
            ErrorCode.UPSTREAM_UNAVAILABLE
            if error_type == "overloaded_error"
            else ErrorCode.UPSTREAM_BAD_RESPONSE
        )
        return GatewayError(
            code, message, details={"upstream_event": "error", "upstream_type": error_type}
        )

    def normalize_error(
        self, status: int, body: dict | None, exc: BaseException | None = None
    ) -> GatewayError:
        details: dict[str, Any] = {"upstream_status": status}
        if body is not None:
            details["upstream_body"] = body
        if exc is not None:
            if isinstance(exc, (httpx.TimeoutException, TimeoutError)):
                return GatewayError(
                    ErrorCode.UPSTREAM_TIMEOUT, f"upstream timeout: {exc!r}", details=details
                )
            if isinstance(exc, httpx.HTTPError):
                return GatewayError(
                    ErrorCode.UPSTREAM_UNAVAILABLE,
                    f"upstream connection error: {exc!r}",
                    details=details,
                )
        if status in (401, 403):
            return GatewayError(
                ErrorCode.UPSTREAM_AUTH, f"upstream auth failed (HTTP {status})", details=details
            )
        if status == 400:
            message = _error_text(body)
            if any(hint in message.lower() for hint in _CONTEXT_ERROR_HINTS):
                return GatewayError(
                    ErrorCode.CONTEXT_LENGTH_EXCEEDED,
                    "upstream rejected request: context length exceeded",
                    details=details,
                )
            return GatewayError(
                ErrorCode.UPSTREAM_BAD_REQUEST, "upstream rejected request", details=details
            )
        if status in (408, 409, 429, 500, 502, 503, 504, 529):
            return GatewayError(
                ErrorCode.UPSTREAM_UNAVAILABLE, f"upstream unavailable (HTTP {status})", details=details
            )
        if status >= 400:
            return GatewayError(
                ErrorCode.UPSTREAM_BAD_REQUEST, f"upstream returned HTTP {status}", details=details
            )
        return GatewayError(
            ErrorCode.UPSTREAM_UNAVAILABLE, "upstream connection failed", details=details
        )

    def capabilities(self, route: ModelRoute) -> ModelCapabilities:
        return {
            "max_context_tokens": 200_000,
            "max_output_tokens": route.default_max_tokens,
            "supports_stream": True,
            "supports_json_schema": True,
            # Anthropic 无 json_object 等价能力，需要 L3 提示词兜底。
            "supports_json_object": False,
            "supports_reasoning": True,
            "supports_prompt_caching": True,
        }


def _error_text(body: dict | None) -> str:
    if not body:
        return ""
    error = body.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("type") or "")
    return str(body)


def _map_finish_reason(stop_reason: str | None) -> FinishReason:
    return {
        "end_turn": FinishReason.STOP,
        "stop_sequence": FinishReason.STOP,
        "max_tokens": FinishReason.LENGTH,
        "tool_use": FinishReason.TOOL_CALLS,
        "refusal": FinishReason.CONTENT_FILTER,
    }.get(str(stop_reason), FinishReason.STOP)


def _load_event(data: str) -> dict | None:
    try:
        loaded = json.loads(data)
    except json.JSONDecodeError:
        return None
    return loaded if isinstance(loaded, dict) else None
