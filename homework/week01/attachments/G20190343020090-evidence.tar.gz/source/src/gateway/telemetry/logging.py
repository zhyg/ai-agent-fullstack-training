"""结构化日志装配：单行 JSON，时间戳固定为北京时间。"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

import structlog

_BEIJING = ZoneInfo("Asia/Shanghai")


def _add_timestamp(_logger: Any, _method: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    event_dict.setdefault("ts", datetime.now(_BEIJING).isoformat(timespec="milliseconds"))
    return event_dict


def configure_logging(level: str = "info", *, json_logs: bool = True) -> None:
    """配置标准库与 structlog，保证每条日志是单行 JSON。"""

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=numeric_level,
        stream=sys.stdout,
        format="%(message)s",
        force=True,
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            _add_timestamp,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(ensure_ascii=False),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(numeric_level),
        logger_factory=structlog.WriteLoggerFactory(file=sys.stdout),
        cache_logger_on_first_use=True,
    )
    if not json_logs:  # 目前只提供 JSON 形态，保留开关位便于后续切换
        logging.getLogger(__name__).warning("json_logs=false 暂未实现文本渲染，继续使用 JSON")
