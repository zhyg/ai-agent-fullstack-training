"""请求计时：DESIGN.md §7.2 的 6 个延迟指标。

- `ttft_ms`：首个文本 delta − t0，**含**限流排队与重试开销，反映用户体感；
- `upstream_ttft_ms`：首个 delta − 上游请求发出，剔除网关自身开销；
- `queue_wait_ms` / `retry_overhead_ms`：由限流与重试层回填（Stage 6 落值）；
- `total_ms`：结束 − t0；
- `tpot_ms`：(total − TTFT) / (output_tokens − 1)，单 token 生成速度。

TTFT 只在真正拿到首个 delta 时打点；失败请求不产生 TTFT 样本，
只记 `total_ms` 与错误码——把失败混进 TTFT 平均是最常见的指标失真。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from gateway.core.ir import CallContext, Latency


def latency_snapshot(
    *,
    t0: float,
    ended_at: float | None = None,
    first_delta_at: float | None = None,
    upstream_started_at: float | None = None,
    queue_wait_ms: float | None = None,
    retry_overhead_ms: float | None = None,
    output_tokens: int = 0,
) -> Latency:
    """按时间戳生成一份延迟快照；缺失的时间点对应指标为 None（不产生样本）。"""

    end = time.perf_counter() if ended_at is None else ended_at
    total_ms = round((end - t0) * 1000, 2)

    ttft_ms: float | None = None
    upstream_ttft_ms: float | None = None
    tpot_ms: float | None = None

    if first_delta_at is not None:
        ttft_ms = round((first_delta_at - t0) * 1000, 2)
        if upstream_started_at is not None:
            upstream_ttft_ms = round((first_delta_at - upstream_started_at) * 1000, 2)
        if output_tokens > 1 and ttft_ms is not None:
            tpot_ms = round((total_ms - ttft_ms) / (output_tokens - 1), 2)

    return Latency(
        total_ms=total_ms,
        ttft_ms=ttft_ms,
        upstream_ttft_ms=upstream_ttft_ms,
        queue_wait_ms=queue_wait_ms,
        retry_overhead_ms=retry_overhead_ms,
        tpot_ms=tpot_ms,
    )


@dataclass
class StreamTiming:
    """流式请求的计时器；`ctx` 用于读取上游发出时间与排队/重试开销。"""

    t0: float = field(default_factory=time.perf_counter)
    ctx: CallContext | None = None
    first_delta_at: float | None = None
    last_delta_at: float | None = None
    delta_count: int = 0
    output_chars: int = 0
    input_tokens: int = 0
    output_tokens: int = 0

    def on_start(self, input_tokens: int = 0) -> None:
        """记录上游在起始事件里已经给出的输入 token 数。"""

        if input_tokens:
            self.input_tokens = input_tokens

    def on_delta(self, chars: int = 0) -> float | None:
        """记录一个增量；首次调用返回 TTFT 毫秒，其后返回 None。"""

        now = time.perf_counter()
        self.last_delta_at = now
        self.delta_count += 1
        self.output_chars += max(chars, 0)
        if self.first_delta_at is None:
            self.first_delta_at = now
            return self.ttft_ms()
        return None

    def on_done(self, output_tokens: int = 0) -> None:
        if output_tokens:
            self.output_tokens = output_tokens

    def ttft_ms(self) -> float | None:
        if self.first_delta_at is None:
            return None
        return round((self.first_delta_at - self.t0) * 1000, 2)

    def latency(self, output_tokens: int | None = None) -> Latency:
        """生成延迟快照；排队与重试开销从 `CallContext` 动态读取。"""

        tokens = self.output_tokens if output_tokens is None else output_tokens
        ctx = self.ctx
        return latency_snapshot(
            t0=self.t0,
            ended_at=self.last_delta_at or time.perf_counter(),
            first_delta_at=self.first_delta_at,
            upstream_started_at=ctx.upstream_started_at if ctx else None,
            queue_wait_ms=ctx.queue_wait_ms if ctx else None,
            retry_overhead_ms=ctx.retry_overhead_ms if ctx else None,
            output_tokens=tokens,
        )
