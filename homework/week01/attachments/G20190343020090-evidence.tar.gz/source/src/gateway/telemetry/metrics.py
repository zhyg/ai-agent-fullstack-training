"""可观测性单入口：Prometheus 指标定义 + 结构化日志 + 采样规则。

指标口径见 DESIGN.md §7：
- `llm_requests_total{model,adapter,status}`
- `llm_tokens_total{model,type,source}`（五分类）
- `llm_cost_estimate_total{model,currency}`（按路由价格表换算）
- 6 个延迟直方图：`llm_request_duration_ms` / `llm_ttft_ms` / `llm_upstream_ttft_ms`
  / `llm_queue_wait_ms` / `llm_retry_overhead_ms` / `llm_tpot_ms`

采样规则：错误、重试、客户端断开 100% 记录；成功请求按 `logging.sample_rate`
采样，但**计数器指标全量**（指标不打折，只有日志打折）。
"""

from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass, field
from typing import Any, Callable

import structlog
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    REGISTRY,
    CollectorRegistry,
    Counter,
    Histogram,
    generate_latest,
)

from gateway.config import Settings
from gateway.core.ir import CanonicalMessage, Latency, TokenUsage
from gateway.core.router import ModelRoute
from gateway.telemetry.usage import (
    estimate_cost,
    finalize_usage,
    token_classes,
    usage_fields,
)

logger = structlog.get_logger("gateway.llm")

# 直方图分桶（毫秒），与 DESIGN §7.2 一致
LATENCY_BUCKETS = (50, 100, 250, 500, 1000, 2000, 5000, 10000, 30000)

STATUS_OK = "ok"
STATUS_ERROR = "error"
STATUS_CLIENT_ABORTED = "client_aborted"


class GatewayMetrics:
    """一组网关指标；可注入独立 `CollectorRegistry`，避免测试间相互污染。"""

    def __init__(self, registry: CollectorRegistry | None = None) -> None:
        self.registry = registry or REGISTRY
        self.requests = Counter(
            "llm_requests_total",
            "Gateway 请求数，按模型/适配器/状态",
            ("model", "adapter", "status"),
            registry=self.registry,
        )
        self.tokens = Counter(
            "llm_tokens_total",
            "Token 用量，按模型/五分类/来源",
            ("model", "type", "source"),
            registry=self.registry,
        )
        self.cost = Counter(
            "llm_cost_estimate_total",
            "按路由价格表估算的费用",
            ("model", "currency"),
            registry=self.registry,
        )
        labels = ("model", "adapter")
        self.duration = self._histogram(
            "llm_request_duration_ms", "端到端延迟", labels
        )
        self.ttft = self._histogram("llm_ttft_ms", "首 token 延迟（含排队与重试）", labels)
        self.upstream_ttft = self._histogram(
            "llm_upstream_ttft_ms", "上游首 token 延迟", labels
        )
        self.queue_wait = self._histogram("llm_queue_wait_ms", "限流排队耗时", labels)
        self.retry_overhead = self._histogram("llm_retry_overhead_ms", "重试累计耗时", labels)
        self.tpot = self._histogram("llm_tpot_ms", "单 token 生成速度", labels)

    def _histogram(self, name: str, help_text: str, labels: tuple[str, ...]) -> Histogram:
        return Histogram(
            name,
            help_text,
            labels,
            buckets=LATENCY_BUCKETS,
            registry=self.registry,
        )

    def record(
        self,
        obs: "CallObservation",
        usage: TokenUsage,
        latency: Latency | None = None,
    ) -> None:
        """全量打点：请求计数、五分类 token、费用与 6 个延迟直方图。"""

        labels = (obs.model, obs.adapter)
        self.requests.labels(obs.model, obs.adapter, obs.status).inc()
        for name, value in token_classes(usage).items():
            self.tokens.labels(obs.model, name, usage.source).inc(value)
        if obs.route is not None and obs.route.pricing is not None:
            self.cost.labels(obs.model, obs.route.pricing.currency).inc(
                estimate_cost(usage, obs.route.pricing)
            )

        if latency is None:
            return
        # 值为 None 的指标不产生样本：失败请求不进 TTFT 平均值
        for histogram, value in (
            (self.duration, latency.total_ms),
            (self.ttft, latency.ttft_ms),
            (self.upstream_ttft, latency.upstream_ttft_ms),
            (self.queue_wait, latency.queue_wait_ms),
            (self.retry_overhead, latency.retry_overhead_ms),
            (self.tpot, latency.tpot_ms),
        ):
            if value is not None:
                histogram.labels(*labels).observe(value)


@dataclass
class CallObservation:
    """一次调用的观测快照；成功与失败路径都用同一套字段。"""

    request_id: str
    model: str
    adapter: str = "unknown"
    status: str = STATUS_OK
    stream: bool = False
    usage: TokenUsage | None = None
    latency: Latency | None = None
    # 已产出的文本，仅用于失败时估算用量与日志脱敏
    text: str = ""
    error_code: str | None = None
    route: ModelRoute | None = None
    prompt: dict[str, Any] | None = None
    structured_mode: str | None = None
    retry_count: int = 0
    # Stage 6：被拒绝重试的原因与触发限流的闸门，保证每次决策有据可查
    retry_skipped_reason: str | None = None
    rate_limited_by: str | None = None
    messages: list[CanonicalMessage] = field(default_factory=list)


def should_emit_log(
    status: str,
    retry_count: int,
    sample_rate: float,
    *,
    rng: Callable[[], float] = random.random,
) -> bool:
    """日志采样决策：异常路径全量，成功路径按比例。"""

    if status != STATUS_OK or retry_count > 0:
        return True
    if sample_rate >= 1.0:
        return True
    if sample_rate <= 0.0:
        return False
    return rng() < sample_rate


def observe_call(
    metrics: GatewayMetrics,
    obs: CallObservation,
    *,
    settings: Settings | None = None,
) -> TokenUsage:
    """统一观测入口：最终用量 → 指标（全量）→ 日志（按采样）。

    返回最终入账的 `TokenUsage`，调用方可直接用于响应渲染。
    """

    usage = finalize_usage(
        obs.usage, obs.text, estimated=obs.status != STATUS_OK
    )
    metrics.record(obs, usage, obs.latency)

    sample_rate = settings.logging.sample_rate if settings is not None else 1.0
    if should_emit_log(obs.status, obs.retry_count, sample_rate):
        logger.info(
            "llm.call",
            **_log_fields(obs, usage, debug=bool(settings and settings.debug)),
        )
    return usage


def _log_fields(
    obs: CallObservation, usage: TokenUsage, *, debug: bool = False
) -> dict[str, Any]:
    """组装 DESIGN §7.3 规定的字段；messages 正文默认只落长度与 hash。"""

    latency = obs.latency
    fields: dict[str, Any] = {
        "request_id": obs.request_id,
        "model": obs.model,
        "adapter": obs.adapter,
        "upstream_model": obs.route.upstream_model if obs.route is not None else obs.model,
        "stream": obs.stream,
        "structured_mode": obs.structured_mode,
        "usage": usage_fields(usage),
        "ttft_ms": _round(latency.ttft_ms if latency else None),
        "upstream_ttft_ms": _round(latency.upstream_ttft_ms if latency else None),
        "total_ms": _round(latency.total_ms if latency else None),
        "queue_wait_ms": _round(latency.queue_wait_ms if latency else None),
        "retry_overhead_ms": _round(latency.retry_overhead_ms if latency else None),
        "retry_count": obs.retry_count,
        "retry_skipped_reason": obs.retry_skipped_reason,
        "rate_limited_by": obs.rate_limited_by,
        "status": obs.status,
        "error_code": obs.error_code,
        "client_aborted": obs.status == STATUS_CLIENT_ABORTED,
        "prompt": obs.prompt,
        "messages": _messages_digest(obs.messages, debug=debug),
    }
    return fields


def _messages_digest(
    messages: list[CanonicalMessage], *, debug: bool
) -> dict[str, Any]:
    payload = "\n".join(message.content for message in messages)
    digest: dict[str, Any] = {
        "count": len(messages),
        "chars": len(payload),
        "sha256": "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16],
    }
    if debug:
        digest["content"] = [
            {"role": message.role.value, "content": message.content} for message in messages
        ]
    return digest


def _round(value: float | None) -> float | None:
    return None if value is None else round(value, 2)


_METRICS: GatewayMetrics | None = None


def get_metrics() -> GatewayMetrics:
    """进程内单例；重复实例化会因同名指标注册失败。"""

    global _METRICS
    if _METRICS is None:
        _METRICS = GatewayMetrics()
    return _METRICS


def render_metrics(registry: CollectorRegistry | None = None) -> tuple[bytes, str]:
    """导出 Prometheus 文本格式；默认使用全局 registry。"""

    target = registry or get_metrics().registry
    return generate_latest(target), CONTENT_TYPE_LATEST
