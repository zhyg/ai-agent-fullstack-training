"""Token 五分类映射与用量估算（DESIGN.md §7.1）。

规则：**上报优先、估算兜底**。上游给了 usage 就标 `reported`；流式中断、
上游未返回 usage、客户端断开时用 `len(text)/4` 近似并标 `estimated`，
指标上带 `source` 标签，绝不把估算值伪装成精确值。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from gateway.core.ir import TokenUsage

if TYPE_CHECKING:  # 仅用于类型标注，避免 telemetry 反向依赖路由实现
    from gateway.core.router import RoutePricing

# 估算口径：约 4 字符/token（中英文混合场景的保守近似）
CHARS_PER_TOKEN = 4

# 五分类 → TokenUsage 字段名，供 Prometheus 计数器逐类打点
TOKEN_CLASSES: dict[str, str] = {
    "input": "input_tokens",
    "output": "output_tokens",
    "reasoning": "reasoning_tokens",
    "cache_read": "cache_read_tokens",
    "cache_write": "cache_write_tokens",
}


def estimate_tokens(text: str | None) -> int:
    """按字符数估算 token；空文本记 0，有内容至少记 1（避免「有产出却零用量」）。"""

    if not text:
        return 0
    return max(1, len(text) // CHARS_PER_TOKEN)


def estimate_usage(*, input_text: str | None = None, output_text: str = "") -> TokenUsage:
    """完全本地估算的一组用量，用于上游完全没给 usage 的场景。"""

    return TokenUsage(
        input_tokens=estimate_tokens(input_text),
        output_tokens=estimate_tokens(output_text),
        source="estimated",
    )


def finalize_usage(
    usage: TokenUsage | None,
    text: str = "",
    *,
    estimated: bool = False,
) -> TokenUsage:
    """决定最终入账的用量：正常结束信任上游；失败/中断一律标 `estimated`。

    `estimated=True` 覆盖流式中断、客户端断开、上游缺 usage 三种情况；
    此时输出 token 优先用累积文本估算，估算不出（零文本）才退回上游上报值。
    """

    if usage is not None and usage.source == "reported" and not estimated:
        return usage

    base = usage or TokenUsage()
    guess = estimate_tokens(text)
    output_tokens = guess if guess else base.output_tokens
    return TokenUsage(
        input_tokens=base.input_tokens,
        output_tokens=output_tokens,
        reasoning_tokens=base.reasoning_tokens,
        cache_read_tokens=base.cache_read_tokens,
        cache_write_tokens=base.cache_write_tokens,
        source="estimated",
    )


def token_classes(usage: TokenUsage) -> dict[str, int]:
    """展开成五分类字典，供计数器逐个打点。"""

    return {name: int(getattr(usage, field)) for name, field in TOKEN_CLASSES.items()}


def estimate_cost(usage: TokenUsage, pricing: "RoutePricing") -> float:
    """按路由价格表（每百万 token）估算费用；命中缓存的输入按折扣价单算。"""

    billable_input = max(usage.input_tokens - usage.cache_read_tokens, 0)
    return (
        billable_input * pricing.input_per_1m
        + usage.cache_read_tokens * pricing.cache_read_per_1m
        + usage.output_tokens * pricing.output_per_1m
    ) / 1_000_000


def usage_fields(usage: TokenUsage) -> dict[str, Any]:
    """日志里的 `usage` 字段形态（DESIGN §7.3），字段名用短名。"""

    return {
        "input": usage.input_tokens,
        "output": usage.output_tokens,
        "reasoning": usage.reasoning_tokens,
        "cache_read": usage.cache_read_tokens,
        "cache_write": usage.cache_write_tokens,
        "source": usage.source,
    }
