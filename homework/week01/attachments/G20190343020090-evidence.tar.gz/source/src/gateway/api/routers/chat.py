"""Chat 接口：`POST /v1/chat`（非流式 JSON / 流式 SSE）。"""

from __future__ import annotations

import time
from typing import Any, Literal

from fastapi import APIRouter, Request
from pydantic import BaseModel, ConfigDict, Field, model_validator

from gateway.api.routers.sse import build_sse_response
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.ir import (
    CallContext,
    CanonicalMessage,
    CanonicalRequest,
    ResponseFormat,
    Role,
)
from gateway.core.router import ModelRoute
from gateway.prompt.resolver import PromptRef
from gateway.resilience.ratelimit import (
    RateLease,
    RateLimiter,
    estimate_request_tokens,
)
from gateway.telemetry.metrics import (
    STATUS_ERROR,
    STATUS_OK,
    CallObservation,
    observe_call,
)

router = APIRouter(tags=["chat"])


class MessageIn(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str


class PromptRefIn(BaseModel):
    """提示词版本引用；`version` 支持 latest/active/精确版本号。"""

    name: str
    version: str | int | None = None


class JsonSchemaSpec(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str | None = None
    schema_definition: dict[str, Any] = Field(default_factory=dict, alias="schema")
    strict: bool = True


class ResponseFormatIn(BaseModel):
    type: Literal["text", "json_object", "json_schema"] = "text"
    json_schema: JsonSchemaSpec | None = None


class ChatRequest(BaseModel):
    model: str
    messages: list[MessageIn] = Field(default_factory=list)
    system: str | None = None
    # Stage 4：提示词引用与变量；渲染结果作为 base_messages，messages 追加在后
    prompt_ref: PromptRefIn | str | None = None
    variables: dict[str, Any] = Field(default_factory=dict)
    stream: bool = False
    response_format: ResponseFormatIn | None = None
    # 网关扩展（DESIGN §5.4）：strict 结构化默认强制非流式；
    # 显式置 true 才允许流式文本 + 仅终态携带 structured 对象。
    structured_stream: bool = False
    temperature: float | None = None
    top_p: float | None = None
    max_output_tokens: int | None = Field(default=None, ge=1)
    stop: list[str] | None = None
    user: str | None = None

    @model_validator(mode="after")
    def _require_messages_or_prompt(self) -> "ChatRequest":
        # DESIGN §6.3：prompt_ref 渲染出 base messages；两者都不给 → 400。
        if not self.messages and self.prompt_ref is None:
            raise ValueError("either messages or prompt_ref is required")
        return self

    def parsed_prompt_ref(self) -> PromptRef | None:
        if self.prompt_ref is None:
            return None
        return PromptRef.parse(
            self.prompt_ref.model_dump() if isinstance(self.prompt_ref, PromptRefIn)
            else self.prompt_ref
        )

    def to_response_format(self) -> ResponseFormat | None:
        if self.response_format is None:
            return None
        spec = self.response_format.json_schema
        if self.response_format.type == "json_schema":
            if spec is None:
                raise GatewayError(
                    ErrorCode.INVALID_REQUEST,
                    "response_format json_schema requires json_schema{name,schema}",
                )
            if not spec.name:
                raise GatewayError(
                    ErrorCode.INVALID_REQUEST,
                    "response_format json_schema requires json_schema.name",
                )
            return ResponseFormat(
                type="json_schema",
                name=spec.name,
                schema=spec.schema_definition,
                strict=spec.strict,
            )
        return ResponseFormat(type=self.response_format.type)

    def to_canonical(
        self,
        request_id: str,
        *,
        messages: list[CanonicalMessage] | None = None,
        response_format: ResponseFormat | None = None,
        prompt: dict[str, Any] | None = None,
    ) -> CanonicalRequest:
        """构建 CanonicalRequest；提示词分支可覆盖 messages / response_format。"""

        return CanonicalRequest(
            request_id=request_id,
            model=self.model,
            messages=messages if messages is not None else self._canonical_messages(),
            system=self.system,
            stream=self.stream,
            response_format=(
                response_format if response_format is not None
                else self.to_response_format()
            ),
            temperature=self.temperature,
            top_p=self.top_p,
            max_output_tokens=self.max_output_tokens,
            stop=self.stop,
            user=self.user,
            prompt=prompt,
        )

    def _canonical_messages(self) -> list[CanonicalMessage]:
        return [
            CanonicalMessage(role=Role(message.role), content=message.content)
            for message in self.messages
        ]


def _apply_prompt(
    payload: ChatRequest, request: Request
) -> tuple[list[CanonicalMessage] | None, ResponseFormat | None, dict[str, Any] | None]:
    """渲染 prompt_ref 并合并 messages（DESIGN §6.3）。

    模板渲染结果是 base messages，请求里的 messages 追加在后；模板预置的
    `response_schema` 只在请求未显式指定 `response_format` 时生效。
    """

    ref = payload.parsed_prompt_ref()
    if ref is None:
        return None, None, None

    resolver = request.app.state.prompt_resolver
    rendered = resolver.render(ref, payload.variables)
    messages = [CanonicalMessage(role=Role.USER, content=rendered.text)]
    messages.extend(payload._canonical_messages())

    fmt = payload.to_response_format()
    if fmt is None and rendered.template.response_schema is not None:
        fmt = ResponseFormat(
            type="json_schema",
            name=rendered.template.name,
            schema=rendered.template.response_schema,
            strict=True,
        )
    return messages, fmt, rendered.echo


@router.post("/v1/chat", summary="统一对话入口")
async def chat(payload: ChatRequest, request: Request) -> Any:
    gateway = request.app.state.gateway
    metrics = request.app.state.metrics
    settings = request.app.state.settings
    ctx = CallContext(
        request_id=getattr(request.state, "request_id", "req_unknown"),
        t0=time.perf_counter(),
    )
    messages, fmt, prompt_echo = _apply_prompt(payload, request)
    req = payload.to_canonical(
        ctx.request_id,
        messages=messages,
        response_format=fmt,
        prompt=prompt_echo,
    )

    # DESIGN §5.4：strict 结构化默认强制非流式（避免客户端边收边解析半截 JSON）
    note: str | None = None
    fmt = req.response_format
    if req.stream and fmt is not None and fmt.strict and not payload.structured_stream:
        req.stream = False
        note = (
            "structured output forced non-streaming; set structured_stream=true "
            "to stream text with structured only in the final chunk"
        )

    route = _safe_route(gateway, req.model)

    # Stage 6：限流在「开流之前」执行，保证流式请求超限也能返回 HTTP 429 + Retry-After
    try:
        lease = await _acquire_limit(request, req, route, ctx)
    except GatewayError as exc:
        _observe_failure(metrics, settings, ctx, req, route, exc, stream=req.stream)
        raise

    if req.stream:
        # 预检放在返回 StreamingResponse 之前：未知模型 / schema 不合规 /
        # 缺少密钥仍能返回 4xx JSON。
        try:
            prepared = gateway.prepare(req)
        except GatewayError as exc:
            _release_lease(lease)
            _observe_failure(metrics, settings, ctx, req, route, exc, stream=True)
            raise
        return build_sse_response(
            request, req, ctx, prepared, metrics=metrics, lease=lease
        )

    try:
        response = await gateway.complete(req, ctx)
    except GatewayError as exc:
        _release_lease(lease)
        _observe_failure(metrics, settings, ctx, req, route, exc, stream=False)
        raise
    # 按实测 usage 校正 TPM 预扣（TPM 口径为 input + output）
    _release_lease(lease, response.usage.total_tokens)

    if note is not None:
        response.note = note
    observe_call(
        metrics,
        CallObservation(
            request_id=ctx.request_id,
            model=req.model,
            adapter=response.adapter,
            status=STATUS_OK,
            stream=False,
            usage=response.usage,
            latency=response.latency,
            text=response.text,
            route=route,
            prompt=response.prompt,
            structured_mode=response.structured_mode,
            retry_count=ctx.retry_count,
            retry_skipped_reason=ctx.retry_skipped_reason,
            messages=req.messages,
        ),
        settings=settings,
    )
    return response.to_dict()


async def _acquire_limit(
    request: Request,
    req: CanonicalRequest,
    route: ModelRoute | None,
    ctx: CallContext,
) -> RateLease | None:
    """三道闸限流放行；未配置限流器或模型未知时不拦截（让后续错误原样上抛）。"""

    limiter: RateLimiter | None = getattr(request.app.state, "limiter", None)
    if limiter is None or route is None:
        return None
    lease = await limiter.acquire(
        model=route.model,
        limits=route.limits,
        estimated_tokens=estimate_request_tokens(req),
        max_queue_wait_ms=request.app.state.settings.limits.max_queue_wait_ms,
    )
    ctx.queue_wait_ms = lease.queue_wait_ms
    return lease


def _release_lease(lease: RateLease | None, actual_tokens: int | None = None) -> None:
    """归还并发名额并按实测 token 校正 TPM；`RateLease` 自带幂等保护。"""

    if lease is not None:
        lease.release(actual_tokens)


def _safe_route(gateway: Any, model: str) -> ModelRoute | None:
    """错误路径也要能打指标：模型未命中时退化为 None，不影响原始错误上抛。"""

    try:
        return gateway.router.resolve(model)
    except GatewayError:
        return None


def _observe_failure(
    metrics: Any,
    settings: Any,
    ctx: CallContext,
    req: CanonicalRequest,
    route: ModelRoute | None,
    exc: GatewayError,
    *,
    stream: bool,
) -> None:
    """统一记录失败调用（未产出任何文本，因此不会产生 TTFT 样本）。"""

    observe_call(
        metrics,
        CallObservation(
            request_id=ctx.request_id,
            model=req.model,
            adapter=route.adapter if route is not None else "unknown",
            status=STATUS_ERROR,
            stream=stream,
            error_code=exc.code,
            route=route,
            prompt=req.prompt,
            retry_count=ctx.retry_count,
            retry_skipped_reason=ctx.retry_skipped_reason,
            rate_limited_by=(exc.details or {}).get("rate_limited_by"),
            messages=req.messages,
        ),
        settings=settings,
    )
