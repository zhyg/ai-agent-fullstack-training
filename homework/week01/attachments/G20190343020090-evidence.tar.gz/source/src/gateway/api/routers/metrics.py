"""`GET /metrics`：Prometheus 文本格式导出（DESIGN.md §7）。"""

from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import Response

from gateway.telemetry.metrics import render_metrics

router = APIRouter(tags=["ops"])


@router.get("/metrics", include_in_schema=False, summary="Prometheus 指标导出")
async def metrics() -> Response:
    body, content_type = render_metrics()
    return Response(content=body, media_type=content_type)
