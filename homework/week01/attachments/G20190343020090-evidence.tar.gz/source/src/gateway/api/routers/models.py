"""模型清单接口：`GET /v1/models`。"""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(tags=["models"])


@router.get("/v1/models", summary="路由表可见模型 + 能力声明")
async def list_models(request: Request) -> dict:
    gateway = request.app.state.gateway
    data = []
    for route in gateway.router.all():
        adapter = gateway.adapters.get(route.adapter)
        data.append(
            {
                "id": route.model,
                "object": "model",
                "adapter": route.adapter,
                "upstream_model": route.upstream_model,
                "capabilities": adapter.capabilities(route),
            }
        )
    return {"object": "list", "data": data}
