"""提示词管理接口（DESIGN.md §6.4）：创建版本、查询、激活与干跑渲染。"""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

from gateway.core.errors import ErrorCode, GatewayError
from gateway.prompt.models import PROMPT_NAME_PATTERN, PromptVariable
from gateway.prompt.resolver import PromptRef, PromptResolver
from gateway.prompt.store import PromptStore
from gateway.structured.lint import ensure_compatible

router = APIRouter(tags=["prompts"])


class VariableIn(BaseModel):
    """模板变量声明；默认必填，给了 default 就变成可选。"""

    name: str = Field(min_length=1, max_length=64)
    required: bool = True
    default: Any = None

    def to_model(self) -> PromptVariable:
        return PromptVariable(name=self.name, required=self.required, default=self.default)


class PromptCreateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=64, pattern=PROMPT_NAME_PATTERN.pattern)
    content: str = Field(min_length=1)
    variables: list[VariableIn] = Field(default_factory=list)
    response_schema: dict[str, Any] | None = None
    # 只有 draft 可改；创建时直接 active 会原子降级旧 active。
    status: Literal["draft", "active"] = "draft"
    created_by: str | None = None


class RenderRequest(BaseModel):
    version: str | int | None = "active"
    variables: dict[str, Any] = Field(default_factory=dict)


def _store(request: Request) -> PromptStore:
    return request.app.state.prompt_store


def _resolver(request: Request) -> PromptResolver:
    return request.app.state.prompt_resolver


@router.post("/v1/prompts", status_code=201, summary="创建模板或新增版本")
async def create_prompt(payload: PromptCreateRequest, request: Request) -> dict[str, Any]:
    # schema 在入库前就按兼容子集校验，避免线上到调用时才炸。
    if payload.response_schema is not None:
        ensure_compatible(payload.response_schema, name=payload.name)

    template = _resolver(request).create(
        name=payload.name,
        content=payload.content,
        variables=tuple(variable.to_model() for variable in payload.variables),
        response_schema=payload.response_schema,
        status=payload.status,
        created_by=payload.created_by,
    )
    return template.to_dict()


@router.get("/v1/prompts", summary="按 name 聚合的模板列表")
async def list_prompts(request: Request) -> dict[str, Any]:
    data = _store(request).list_names()
    return {"object": "list", "data": data}


@router.get("/v1/prompts/{name}", summary="模板详情 + 版本列表")
async def get_prompt(name: str, request: Request) -> dict[str, Any]:
    versions = _store(request).list_versions(name)
    if not versions:
        raise GatewayError(
            ErrorCode.PROMPT_NOT_FOUND,
            f"prompt '{name}' not found; available prompts: "
            f"{[item['name'] for item in _store(request).list_names()]}",
            details={"name": name},
        )
    return {
        "name": name,
        "latest_version": versions[-1].version,
        "active_version": next(
            (item.version for item in versions if item.status == "active"), None
        ),
        "versions": [item.summary() for item in versions],
    }


@router.get("/v1/prompts/{name}/{version}", summary="指定版本内容")
async def get_prompt_version(name: str, version: str, request: Request) -> dict[str, Any]:
    ref = PromptRef.parse({"name": name, "version": version})
    return _resolver(request).resolve(ref).to_dict()


@router.post("/v1/prompts/{name}/{version}/activate", summary="原子切换 active 版本")
async def activate_prompt(name: str, version: str, request: Request) -> dict[str, Any]:
    ref = PromptRef.parse({"name": name, "version": version})
    if ref.version in ("latest", "active"):
        raise GatewayError(
            ErrorCode.INVALID_REQUEST,
            "activate requires an exact version number",
            details={"version": version},
        )
    template = _resolver(request).activate(ref.name, int(ref.version))
    return template.summary()


@router.post("/v1/prompts/{name}/render", summary="干跑渲染（不调模型）")
async def render_prompt(name: str, payload: RenderRequest, request: Request) -> dict[str, Any]:
    ref = PromptRef.parse({"name": name, "version": payload.version})
    rendered = _resolver(request).render(ref, payload.variables)
    return {
        **rendered.echo,
        "rendered": rendered.text,
        "ignored_variables": list(rendered.ignored_variables),
    }
