"""对外 SSE 出口：OpenAI Chat Completions 兼容的 data-only chunk。

职责边界：
- 适配器只产出 `CanonicalEvent`，本模块负责把它编码成客户端看得懂的 chunk；
- 心跳、静默超时、客户端断开都在这里处理；
- 一旦发出 200，中途失败只能发 `error` 事件后关闭（状态码无法再改）。
"""

from __future__ import annotations

import asyncio
import contextlib
import json
from collections.abc import AsyncIterator
from typing import Any

import structlog
from fastapi import Request
from fastapi.responses import StreamingResponse

from gateway.config import Settings
from gateway.core.errors import ErrorCode, GatewayError, build_error_body
from gateway.core.events import CanonicalEvent
from gateway.core.invoker import Gateway, PreparedCall
from gateway.core.ir import CallContext, CanonicalRequest, Latency, TokenUsage
from gateway.core.sse import DONE_FRAME, encode_heartbeat, encode_sse_data
from gateway.resilience.ratelimit import RateLease
from gateway.telemetry.metrics import (
    STATUS_CLIENT_ABORTED,
    STATUS_ERROR,
    STATUS_OK,
    CallObservation,
    GatewayMetrics,
    get_metrics,
    observe_call,
)
from gateway.telemetry.timing import StreamTiming

logger = structlog.get_logger("gateway.sse")

SSE_MEDIA_TYPE = "text/event-stream; charset=utf-8"
# 关键：禁用 Nginx 等反向代理的响应缓冲，保证首包立即到达客户端。
SSE_HEADERS = {
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


def build_sse_response(
    request: Request,
    req: CanonicalRequest,
    ctx: CallContext,
    prepared: PreparedCall,
    *,
    metrics: GatewayMetrics | None = None,
    lease: RateLease | None = None,
) -> StreamingResponse:
    """组装 SSE 响应；调用前必须已完成预检（路由解析 / 鉴权 / 参数校验 / 限流）。"""

    gateway: Gateway = request.app.state.gateway
    settings: Settings = request.app.state.settings
    return StreamingResponse(
        stream_frames(gateway, req, ctx, settings, prepared, metrics=metrics, lease=lease),
        status_code=200,
        media_type=SSE_MEDIA_TYPE,
        headers={**SSE_HEADERS, "X-Request-Id": ctx.request_id},
    )


async def stream_frames(
    gateway: Gateway,
    req: CanonicalRequest,
    ctx: CallContext,
    settings: Settings,
    prepared: PreparedCall | None = None,
    *,
    metrics: GatewayMetrics | None = None,
    lease: RateLease | None = None,
) -> AsyncIterator[bytes]:
    """把规范事件流转成对外 SSE 帧。

    用后台任务 + 队列而非直接迭代上游：这样等待下一帧时可以安全地超时发心跳，
    不会像 `asyncio.wait_for(anext(...))` 那样把上游流取消掉。
    """

    timing = StreamTiming(t0=ctx.t0, ctx=ctx)
    metrics_impl = metrics or get_metrics()
    heartbeat_s = settings.stream.heartbeat_s
    silence_limit_s = settings.stream.silence_timeout_s
    queue: asyncio.Queue[tuple[str, Any]] = asyncio.Queue(maxsize=32)
    pieces: list[str] = []
    # Stage 6：终态拿到实测 usage 后用于校正 TPM 预扣；中断/断开不校正
    final_usage: TokenUsage | None = None

    def _observe(
        status: str,
        *,
        usage: TokenUsage | None = None,
        latency: Latency | None = None,
        text: str = "",
        error_code: str | None = None,
        structured_mode: str | None = None,
    ) -> None:
        """流式路径统一观测：指标全量、日志按采样。"""

        observe_call(
            metrics_impl,
            CallObservation(
                request_id=ctx.request_id,
                model=req.model,
                adapter=prepared.adapter.name if prepared is not None else "unknown",
                status=status,
                stream=True,
                usage=usage,
                latency=latency,
                text=text,
                error_code=error_code,
                route=prepared.route if prepared is not None else None,
                prompt=req.prompt,
                structured_mode=structured_mode,
                retry_count=ctx.retry_count,
                retry_skipped_reason=ctx.retry_skipped_reason,
                messages=req.messages,
            ),
            settings=settings,
        )

    async def _pump() -> None:
        try:
            async for event in gateway.stream(req, ctx, prepared):
                await queue.put(("event", event))
            await queue.put(("end", None))
        except GatewayError as exc:
            await queue.put(("error", exc))
        except Exception as exc:  # noqa: BLE001 - 兜底，保证客户端一定收到 error 帧
            logger.exception("stream.pump_failed", request_id=ctx.request_id)
            await queue.put(
                ("error", GatewayError(ErrorCode.INTERNAL, "internal gateway error"))
            )

    pump = asyncio.create_task(_pump())
    silent_s = 0.0
    try:
        while True:
            try:
                kind, item = await asyncio.wait_for(queue.get(), timeout=heartbeat_s)
            except TimeoutError:
                silent_s += heartbeat_s
                if silent_s >= silence_limit_s:
                    logger.warning(
                        "stream.silence_timeout",
                        request_id=ctx.request_id,
                        silent_s=silent_s,
                    )
                    exc = GatewayError(
                        ErrorCode.STREAM_INTERRUPTED,
                        f"upstream produced no data for {silent_s:.0f}s",
                    )
                    _observe(
                        STATUS_ERROR,
                        latency=timing.latency(None),
                        text="".join(pieces),
                        error_code=exc.code,
                    )
                    yield _error_frame(exc, ctx.request_id, settings.debug)
                    return
                yield encode_heartbeat().encode()
                continue
            silent_s = 0.0

            if kind == "end":
                break
            if kind == "error":
                exc = item
                _observe(
                    STATUS_ERROR,
                    latency=timing.latency(None),
                    text="".join(pieces),
                    error_code=getattr(exc, "code", None),
                )
                yield _error_frame(item, ctx.request_id, settings.debug)
                return

            event: CanonicalEvent = item
            if event.type == "start":
                if event.usage is not None:
                    timing.on_start(event.usage.input_tokens)
            elif event.type == "delta":
                content = event.text_delta or ""
                pieces.append(content)
                timing.on_delta(len(content))
                yield _delta_chunk(ctx.request_id, req.model, content).encode()
            elif event.type == "structured":
                # Stage 3 起 structured 只在终态 chunk 出现，这里忽略中间通知。
                continue
            elif event.type == "ping":
                yield encode_heartbeat().encode()
            elif event.type == "done":
                final_usage = event.usage
                if event.usage is not None:
                    timing.on_done(event.usage.output_tokens)
                latency = timing.latency(
                    event.usage.output_tokens if event.usage is not None else None
                )
                _observe(
                    STATUS_OK,
                    usage=event.usage,
                    latency=latency,
                    text="".join(pieces),
                    structured_mode=event.structured_mode,
                )
                yield _final_chunk(ctx.request_id, req.model, event, latency).encode()
                yield DONE_FRAME.encode()
                return
            elif event.type == "error":
                exc = event.error
                _observe(
                    STATUS_ERROR,
                    latency=timing.latency(None),
                    text="".join(pieces),
                    error_code=getattr(exc, "code", None),
                )
                yield _error_frame(event.error, ctx.request_id, settings.debug)
                return

        # 上游没有给出终态事件就断流：按 STREAM_INTERRUPTED 收尾
        exc = GatewayError(
            ErrorCode.STREAM_INTERRUPTED,
            "upstream stream ended without a terminal event",
        )
        _observe(
            STATUS_ERROR,
            latency=timing.latency(None),
            text="".join(pieces),
            error_code=exc.code,
        )
        yield _error_frame(exc, ctx.request_id, settings.debug)
    except (asyncio.CancelledError, GeneratorExit):
        # 客户端断开：取消上游任务会触发 Gateway.stream 的 finally -> response.aclose()
        ctx.client_aborted = True
        _observe(
            STATUS_CLIENT_ABORTED,
            latency=timing.latency(None),
            text="".join(pieces),
        )
        logger.info(
            "stream.client_aborted",
            request_id=ctx.request_id,
            stream_started=ctx.stream_started,
            delta_count=timing.delta_count,
        )
        raise
    finally:
        pump.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await pump
        # 归还并发名额；拿到终态 usage 才按实测校正 TPM，否则保留预扣值
        if lease is not None:
            lease.release(final_usage.total_tokens if final_usage is not None else None)


def _delta_chunk(request_id: str, model: str, content: str) -> str:
    return encode_sse_data(
        _dump(
            {
                "id": request_id,
                "object": "chat.completion.chunk",
                "model": model,
                "choices": [
                    {"index": 0, "delta": {"content": content}, "finish_reason": None}
                ],
                "usage": None,
            }
        )
    )


def _final_chunk(
    request_id: str,
    model: str,
    event: CanonicalEvent,
    latency: Latency,
) -> str:
    usage: dict[str, Any] | None = None
    if event.usage is not None:
        usage = {
            "prompt_tokens": event.usage.input_tokens,
            "completion_tokens": event.usage.output_tokens,
            "total_tokens": event.usage.total_tokens,
            "source": event.usage.source,
        }
    finish_reason = event.finish_reason.value if event.finish_reason else "stop"
    body: dict[str, Any] = {
        "id": request_id,
        "object": "chat.completion.chunk",
        "model": model,
        "choices": [{"index": 0, "delta": {}, "finish_reason": finish_reason}],
        "usage": usage,
        "gateway": latency.to_dict(),
    }
    # DESIGN §5.4：结构化结果只在终态 chunk 出现，中间帧绝不发半截 JSON
    if event.structured is not None:
        body["structured"] = event.structured
        body["structured_mode"] = event.structured_mode
    # DESIGN §6.3：提示词版本信息随终态 chunk 回显
    if event.prompt is not None:
        body["prompt"] = event.prompt
    return encode_sse_data(_dump(body))


def _error_frame(exc: Any, request_id: str, debug: bool) -> bytes:
    """SSE 中的错误帧：复用统一错误体，客户端可沿用同一套错误处理。"""

    if not isinstance(exc, GatewayError):
        exc = GatewayError(ErrorCode.STREAM_INTERRUPTED, str(exc) or "stream interrupted")
    body = build_error_body(
        exc.code, exc.message, request_id, details=exc.details, debug=debug,
        retryable=exc.retryable,
    )
    return (encode_sse_data(_dump(body)) + DONE_FRAME).encode()


def _dump(body: dict[str, Any]) -> str:
    return json.dumps(body, ensure_ascii=False, separators=(",", ":"))
