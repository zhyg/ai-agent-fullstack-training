"""HTTP 中间件：request_id 透传/生成与访问日志。"""

from __future__ import annotations

import re
import secrets
import time

import structlog
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from gateway.core.errors import ErrorCode, build_error_body

REQUEST_ID_HEADER = "X-Request-Id"
# 客户端可传的 request_id：字母数字与 . _ : - 组成，长度 8~128。
_REQUEST_ID_PATTERN = re.compile(r"^[A-Za-z0-9._:-]{8,128}$")

logger = structlog.get_logger("gateway.http")


def new_request_id() -> str:
    return f"req_{secrets.token_hex(12)}"


class RequestContextMiddleware(BaseHTTPMiddleware):
    """为每个请求建立 request_id 上下文，并输出单行访问日志。"""

    def __init__(self, app, *, debug: bool = False) -> None:
        super().__init__(app)
        self.debug = debug

    async def dispatch(self, request: Request, call_next):
        client_request_id = request.headers.get(REQUEST_ID_HEADER)
        if client_request_id and not _REQUEST_ID_PATTERN.match(client_request_id):
            rid = new_request_id()
            logger.warning(
                "http.request.invalid_request_id",
                request_id=rid,
                path=request.url.path,
            )
            body = build_error_body(
                ErrorCode.INVALID_REQUEST,
                f"{REQUEST_ID_HEADER} header must be 8-128 chars of [A-Za-z0-9._:-]",
                rid,
                debug=self.debug,
            )
            response = JSONResponse(status_code=400, content=body)
            response.headers[REQUEST_ID_HEADER] = rid
            return response

        request_id = client_request_id or new_request_id()
        request.state.request_id = request_id
        structlog.contextvars.bind_contextvars(request_id=request_id)

        started = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            logger.exception(
                "http.request.failed",
                method=request.method,
                path=request.url.path,
                duration_ms=round((time.perf_counter() - started) * 1000, 3),
            )
            raise
        finally:
            structlog.contextvars.unbind_contextvars("request_id")

        duration_ms = round((time.perf_counter() - started) * 1000, 3)
        response.headers[REQUEST_ID_HEADER] = request_id
        log = logger.error if response.status_code >= 500 else logger.info
        log(
            "http.request",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            duration_ms=duration_ms,
        )
        return response
