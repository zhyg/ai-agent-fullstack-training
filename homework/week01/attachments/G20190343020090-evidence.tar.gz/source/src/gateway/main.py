"""FastAPI 应用装配入口。"""

from __future__ import annotations

import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

import structlog
import uvicorn
from fastapi import FastAPI
from pydantic import ValidationError

from gateway.adapters.registry import AdapterRegistry
from gateway.api.middlewares import RequestContextMiddleware
from gateway.api.routers.chat import router as chat_router
from gateway.api.routers.metrics import router as metrics_router
from gateway.api.routers.models import router as models_router
from gateway.api.routers.prompts import router as prompts_router
from gateway.config import PROJECT_ROOT, Settings, format_validation_error, get_settings
from gateway.core.errors import install_exception_handlers
from gateway.core.invoker import Gateway, HttpTransport
from gateway.core.router import Router
from gateway.httpclient.pool import HttpClientPool
from gateway.prompt.resolver import PromptResolver
from gateway.prompt.store import PromptStore, SQLiteStore
from gateway.resilience.ratelimit import MemoryRateLimiter, RateLimiter
from gateway.resilience.retry import RetryPolicy
from gateway.telemetry.logging import configure_logging
from gateway.telemetry.metrics import get_metrics

APP_VERSION = "0.1.0"
logger = structlog.get_logger("gateway.main")


def create_app(
    settings: Settings | None = None,
    *,
    router: Router | None = None,
    transport: HttpTransport | None = None,
    prompt_store: PromptStore | None = None,
    retry: RetryPolicy | None = None,
    limiter: RateLimiter | None = None,
) -> FastAPI:
    """构建应用；测试可注入独立配置、路由表、传输实现、提示词存储与韧性组件。"""

    settings = settings or get_settings()
    configure_logging(settings.logging.level, json_logs=settings.logging.json_logs)

    route_table = router or Router.from_file()
    adapters = AdapterRegistry.default()
    pool = HttpClientPool()
    gateway = Gateway(
        router=route_table,
        adapters=adapters,
        transport=transport or pool,
        settings=settings,
        retry=retry or RetryPolicy(settings.retry),
    )

    if prompt_store is None:
        db_path = Path(settings.prompt.db_path)
        if not db_path.is_absolute():
            db_path = PROJECT_ROOT / db_path
        prompt_store = SQLiteStore(db_path)
    prompt_resolver = PromptResolver(
        prompt_store,
        cache_size=settings.prompt.cache_size,
        cache_ttl_s=settings.prompt.cache_ttl_s,
    )

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        await pool.startup()
        logger.info(
            "gateway.startup",
            version=APP_VERSION,
            models=[route.model for route in route_table.all()],
            adapters=adapters.names(),
        )
        try:
            yield
        finally:
            await pool.aclose()

    app = FastAPI(
        title="Mini LLM Gateway",
        version=APP_VERSION,
        description="多协议归一的 mini LLM Gateway",
        lifespan=lifespan,
    )
    app.state.settings = settings
    app.state.gateway = gateway
    app.state.router = route_table
    app.state.prompt_store = prompt_store
    app.state.prompt_resolver = prompt_resolver
    app.state.metrics = get_metrics()
    # Stage 6：按模型独立的三道闸限流；Redis 实现替换此处即可
    app.state.limiter = limiter or MemoryRateLimiter()

    install_exception_handlers(app, debug=settings.debug)
    app.add_middleware(RequestContextMiddleware, debug=settings.debug)

    @app.get("/healthz", tags=["ops"], summary="存活探针（不探上游）")
    async def healthz() -> dict[str, str]:
        return {"status": "ok"}

    app.include_router(chat_router)
    app.include_router(models_router)
    app.include_router(prompts_router)
    app.include_router(metrics_router)
    return app


try:
    _settings = get_settings()
except ValidationError as exc:  # 启动即失败，并报出字段路径
    sys.stderr.write(f"invalid gateway configuration:\n{format_validation_error(exc)}\n")
    raise SystemExit(2) from exc

app = create_app(_settings)


def main() -> None:
    """`llm-gateway` 命令行入口。"""

    uvicorn.run(
        "gateway.main:app",
        host=_settings.server.host,
        port=_settings.server.port,
        log_config=None,
    )
