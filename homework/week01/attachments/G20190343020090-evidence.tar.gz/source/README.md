# Mini LLM Gateway

一个把多家大模型 API 归一成单一 HTTP 接口的迷你网关：统一 IR、双协议适配、
SSE 流式、结构化输出、提示词版本管理、可观测性与韧性（重试 + 限流）。
设计文档见 [docs/DESIGN.md](docs/DESIGN.md)，分阶段实证记录见 `docs/stage-0..7.md`，
真实上游功能验收见 [docs/ACCEPTANCE_REPORT.md](docs/ACCEPTANCE_REPORT.md)。

## 功能清单与使用方式

| 功能 | 作用 | 使用方式 |
|---|---|---|
| 统一对话入口 | 所有厂商收敛到一个接口 | `POST /v1/chat`，传 `model` + `messages` |
| 统一 IR | 客户端/适配器共用一套请求、响应、流事件抽象 | 无需显式使用；适配器内部翻译 |
| 双协议适配 | 同时支持 OpenAI Responses 与 Anthropic Messages 上游 | 路由表 `adapter` 选 `openai_responses` / `anthropic_messages` |
| 模型路由 | 模型名 → 上游端点/密钥/超时/限流 | 改 `config/routes.yaml`，**不改代码** |
| 流式输出 | 逐帧返回，首包可感知 | 请求体加 `"stream": true`，响应为 SSE，`data: [DONE]` 结尾 |
| 结构化输出 | 让模型按 JSON Schema 返回 | `response_format: {"type": "json_schema", "json_schema": {...}}`；无原生能力时自动降级 `json_object` → L3 提示词修复 |
| schema 预检 | 不合规 schema 在调上游前就 400 | 无需开关；`additionalProperties:false`、字段全 `required`、禁 `$ref/$defs/oneOf/pattern/format` |
| 提示词版本库 | 模板集中管理、版本不可变、可审计 | `POST /v1/prompts` 创建；`/activate` 切换；`/render` 干跑 |
| 模板引用调用 | 请求里引用模板 + 变量 | `prompt_ref: {"name": "x", "version": 1}` + `variables` |
| 可观测指标 | 请求数、Token 五分类、费用估算、6 个延迟指标 | `GET /metrics`（Prometheus 文本） |
| 结构化日志 | 单行 JSON，可按 `request_id` 串联 | 标准输出；`logging.json_logs` / `sample_rate` 可调 |
| 自动重试 | 瞬时故障自愈 | 默认开启；`retry.*` 控制次数、退避与预算 |
| 限流保护 | 保护上游与自身 | 路由 `limits: {rpm, tpm, concurrent}`；超限 429 + `Retry-After` |
| 错误归一 | 所有错误同一形状，便于客户端处理 | 4xx/5xx 均为 `{"error": {code, message, type, request_id, retryable}}` |
| 请求追踪 | 每个请求可定位 | 自动生成/透传 `X-Request-Id`（8–128 位 `[A-Za-z0-9._:-]`） |
| 健康探针 | 进程存活检查 | `GET /healthz`（不探上游） |
| 并发压测脚本 | 验证限流与 TTFT | `uv run python scripts/bench.py --base-url ... --model ... --concurrency 100` |

## 目录结构

```
src/gateway/
├── main.py            # FastAPI 装配（配置 / 路由 / 适配器 / 限流器 / 指标）
├── config.py          # pydantic-settings：gateway.yaml < GW_* 环境变量
├── core/              # IR、路由、错误码、调用编排、SSE 解析
├── adapters/          # openai_responses / anthropic_messages
├── api/routers/       # chat / sse / models / prompts / metrics
├── structured/        # schema lint、三档降级、方言翻译
├── prompt/            # SQLite store、resolver、数据模型
├── resilience/        # retry、ratelimit
├── telemetry/         # metrics、logging、usage、timing
└── httpclient/        # 共享 httpx AsyncClient 池
```

## 分步使用指南

### 第 1 步：环境准备

| 依赖 | 版本 | 检查命令 |
|---|---|---|
| Python | ≥ 3.13 | `python --version` |
| uv | 最新（管理依赖与虚拟环境） | `uv --version` |

未安装 uv 时：

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
# Windows PowerShell
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

### 第 2 步：安装依赖

```bash
cd LLMGateway
uv sync            # 按 pyproject.toml + uv.lock 创建 .venv 并安装依赖
```

自检安装结果：

```bash
uv run python -c "import fastapi, pydantic, httpx, structlog; print('deps ok')"
```

### 第 3 步：配置上游密钥

密钥只放环境变量，**不要写进仓库**（`.env`、`*.sqlite3`、日志均已被 `.gitignore` 忽略）。

```bash
# macOS / Linux
export DEEPSEEK_PRO_API_KEY="sk-..."
export DEEPSEEK_FLASH_API_KEY="sk-..."

# Windows PowerShell
$env:DEEPSEEK_PRO_API_KEY="sk-..."
$env:DEEPSEEK_FLASH_API_KEY="sk-..."
```

`config/routes.yaml` 中每个模型的 `api_key_env` 决定读哪个变量；同一个密钥给两条路由使用也可以，把两个 `api_key_env` 都指向同一变量名即可。

### 第 4 步：按需调整配置

- 服务端口 / 日志采样：`config/gateway.yaml`（或用 `GW_*` 覆盖，见「配置」）
- 模型、上游地址、密钥变量名、超时、限流：`config/routes.yaml`
- 校验配置是否合法（非法值启动即失败并打印字段路径）：

```bash
uv run python -c "from gateway.config import Settings; Settings(); print('config ok')"
```

### 第 5 步：启动

```bash
# 方式一：uvicorn（推荐开发/测试）
uv run uvicorn gateway.main:app --host 0.0.0.0 --port 8000

# 方式二：入口脚本（等价，端口取自 gateway.yaml）
uv run llm-gateway

# 方式三：临时改端口/日志采样，不改文件
GW_SERVER__PORT=8004 GW_LOGGING__SAMPLE_RATE=1.0 uv run llm-gateway
```

启动成功会打印一行 `gateway.startup`，包含已加载模型与适配器。

### 第 6 步：自检

```bash
curl -s http://127.0.0.1:8000/healthz          # {"status":"ok"}
curl -s http://127.0.0.1:8000/v1/models        # 路由表可见模型 + 能力声明
curl -s http://127.0.0.1:8000/metrics | head -5
```

### 第 7 步：发起第一个请求

见下一节「最小示例」。请求失败时拿响应里的 `request_id`，在日志里 `grep request_id` 即可定位全链路。

### 第 8 步：停止

前台运行时 `Ctrl+C`；后台运行时：

```bash
pkill -f "uvicorn gateway.main:app"   # 或结束对应 PID
```

## 最小示例

非流式：

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-v4-flash",
    "messages": [{"role": "user", "content": "用一句话介绍你自己"}]
  }'
```

流式（`curl -N` 可看到逐块输出）：

```bash
curl -N http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "写首诗"}], "stream": true}'
```

结构化输出：

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "总结：今天下雨了"}],
    "response_format": {
      "type": "json_schema",
      "json_schema": {
        "name": "summary",
        "strict": true,
        "schema": {
          "type": "object",
          "properties": {"title": {"type": "string"}},
          "required": ["title"],
          "additionalProperties": false
        }
      }
    }
  }'
```

提示词模板（创建 → 干跑渲染 → 引用调用）：

```bash
curl -s -X POST http://127.0.0.1:8000/v1/prompts \
  -H 'Content-Type: application/json' \
  -d '{"name": "greet", "content": "Hello {{ name }}!", "variables": [{"name": "name"}], "status": "active"}'

curl -s -X POST http://127.0.0.1:8000/v1/prompts/greet/render \
  -H 'Content-Type: application/json' -d '{"version": 1, "variables": {"name": "Bob"}}'

curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{"model": "deepseek-v4-pro", "prompt_ref": {"name": "greet", "version": 1}, "variables": {"name": "Bob"}}'
```

## 配置

`config/gateway.yaml`（节选，完整见文件注释）：

| 字段 | 默认 | 说明 |
|---|---|---|
| `debug` | `false` | 打开后错误体带 `details`、日志落消息原文 |
| `logging.sample_rate` | `0.1` | 成功请求日志采样率；错误/重试/断开 100% |
| `retry.max_attempts` | `3` | 总尝试次数（首次 1 + 重试 2） |
| `retry.base_delay_ms` / `max_delay_ms` | `500` / `8000` | full jitter 的基数与封顶 |
| `retry.total_deadline_ms` | `120000` | 含重试的总预算 |
| `limits.max_queue_wait_ms` | `2000` | 并发闸排队上限，超时 429 |
| `stream.heartbeat_s` / `silence_timeout_s` | `15` / `60` | 对外 SSE 心跳与静默判定 |
| `structured.max_repair_retries` | `2` | L3 提示词修复的额外调用次数 |
| `prompt.db_path` | `data/prompts.sqlite3` | 模板库路径（相对项目根） |

`config/routes.yaml` 每个模型声明：`adapter`、`upstream_model`、`base_url`、
`api_key_env`、`default_max_tokens`、`timeout`、`limits`（rpm / tpm / concurrent）、
可选 `pricing`。**改路由不改核心代码**，新增厂商 = 新适配器 + 一条路由。

环境变量优先级高于 YAML，嵌套用双下划线，例如：

```bash
export GW_RETRY__MAX_ATTEMPTS=5
export GW_LIMITS__MAX_QUEUE_WAIT_MS=0
export GW_SERVER__PORT=8004
```

## 接口

| 方法 | 路径 | 说明 |
|---|---|---|
| `POST` | `/v1/chat` | 统一入口（messages / prompt_ref / stream / response_format） |
| `GET` | `/v1/models` | 路由表可见模型 + 能力声明 |
| `POST` | `/v1/prompts` | 创建模板 / 新增版本（版本不可变，checksum 可复现） |
| `GET` | `/v1/prompts` | 模板列表 |
| `GET` | `/v1/prompts/{name}` | 版本列表与激活态 |
| `GET` | `/v1/prompts/{name}/{version}` | 指定版本内容 |
| `POST` | `/v1/prompts/{name}/{version}/activate` | 原子切换 active |
| `POST` | `/v1/prompts/{name}/render` | 干跑渲染（不调模型） |
| `GET` | `/healthz` | 存活探针（不探上游） |
| `GET` | `/metrics` | Prometheus 文本格式（不进 OpenAPI） |

错误统一形状（所有 4xx/5xx 一致）：

```json
{"error": {"code": "MODEL_NOT_FOUND", "message": "...", "type": "not_found",
           "request_id": "req_...", "retryable": false}}
```

## 可观测性

`GET /metrics` 指标：

- `llm_requests_total{model,adapter,status}`
- `llm_tokens_total{model,type,source}`，`type` 为 `input/output/reasoning/cache_read/cache_write`，`source` 为 `reported/estimated`
- `llm_cost_estimate_total{model,currency}`（仅配置了 `pricing` 的路由产生样本）
- 6 个延迟直方图：`llm_request_duration_ms`、`llm_ttft_ms`、`llm_upstream_ttft_ms`、`llm_queue_wait_ms`、`llm_retry_overhead_ms`、`llm_tpot_ms`

`llm.call` 日志关键字段：`request_id`、`model`、`adapter`、`stream`、`usage`、
`ttft_ms`、`upstream_ttft_ms`、`queue_wait_ms`、`retry_overhead_ms`、`retry_count`、
`retry_skipped_reason`、`rate_limited_by`、`status`、`error_code`。
消息默认只记 `count/chars/sha256`，`debug=true` 才落原文。

## 韧性

- 可重试：连接错误/超时、HTTP `408/409/429/500/502/503/504/529`；400 类不重试。
- 退避：full jitter，尊重上游 `Retry-After`（封顶 `max_delay_ms`），受总预算约束。
- 流式：**首个 delta 之前**允许重试（事件先缓存，失败整段丢弃）；开流后失败只发
  `error` 事件并记 `retry_skipped_reason=stream_started`。
- 限流：每模型独立 RPM/TPM 令牌桶 + 并发信号量；TPM 预扣 input，响应后按实测校正；
  超限 `429 RATE_LIMITED` + `Retry-After`。限流在开流之前执行，流式请求同样拿到 429。

## 测试与压测

```bash
# 单元 + 端到端（含故障注入）
uv run pytest
uv run pytest tests/e2e -v

# 压测：打满 flash 的 RPM，观察 429 与 pro 是否仍正常
uv run python scripts/bench.py --base-url http://127.0.0.1:8000 \
  --model deepseek-v4-flash --concurrency 100 --requests 200
```

## 注意事项

1. **密钥**：只从 `api_key_env` 指定的环境变量读取；缺失时返回 `UPSTREAM_AUTH`，不会用空 key 试探上游。
2. **JSON Schema 兼容子集**：必须 `additionalProperties: false` 且所有字段都进 `required`，禁用 `$ref/$defs/oneOf/pattern/format`；不合规会在调上游之前 400，而不是等上游拒绝。
3. **结构化 + 流式**：`strict=true` 默认强制非流式（避免客户端解析半截 JSON）；确实要流式需显式 `structured_stream=true`，`structured` 只在终态出现。
4. **`deepseek-flash` 的结构化**：DeepSeek 的 Anthropic 兼容端点不兑现 `output_config`，该模型用 `json_schema` 会得到 `502 OUTPUT_PARSE_FAILED`；请改用 `json_object`（自动走 L3 提示词修复）或结构化请求走 `deepseek-v4-pro`。
5. **提示词版本不可变**：`active` / `deprecated` 版本内容不可修改，只能新建版本；同内容重复创建会产生新版本号（checksum 相同）。
6. **限流是内存实现**：按 `model` 维度独立计数，单实例有效；多实例部署需替换为 Redis 实现（`app.state.limiter` 注入点已预留）。
7. **日志采样**：成功请求仅按 `logging.sample_rate` 采样（默认 0.1），错误/重试/断开 100%；**指标计数永远全量**，不要用日志行数对账。
8. **重试可能重复计费**：上游已生成但网络断开时会再次请求，日志以 `retry_count` 标注，v1 明确接受。
9. **`request_id` 格式**：客户端可透传 `X-Request-Id`，但必须为 8–128 位 `[A-Za-z0-9._:-]`，否则网关会重新生成并告警。

## 常见问题（FAQ）

| 现象 | 可能原因 | 处理 |
|---|---|---|
| 启动即退出并打印 `invalid gateway configuration` | YAML 字段类型/范围非法 | 按报错中的字段路径修正 `config/gateway.yaml` 或 `GW_*` 变量 |
| `404 MODEL_NOT_FOUND` | `model` 不在路由表 | `GET /v1/models` 查可用模型；`config/routes.yaml` 补路由 |
| `401/403 UPSTREAM_AUTH` | 环境变量未设置或变量名与 `api_key_env` 不匹配 | 检查 `echo $DEEPSEEK_*`，或改路由里的 `api_key_env` |
| `429 RATE_LIMITED` 且带 `Retry-After` | 该模型 RPM/TPM/并发任一闸打满 | 等待 `Retry-After` 秒，或调大路由 `limits` |
| `502 UPSTREAM_BAD_RESPONSE` / `OUTPUT_PARSE_FAILED` | 上游返回不可解析内容 / 结构化校验失败 | 看响应 `details`；结构化改用 `json_object` 或换模型 |
| `503 STREAM_INTERRUPTED` | 已开流后上游断流（此时不重试） | 客户端重试整次请求；查上游侧日志 |
| 流式响应里出现 `: heartbeat` | 心跳注释行（默认 15s），按 SSE 规范客户端应忽略 | 客户端解析时跳过以 `:` 开头的行 |
| `structured` 为 `null` | 结构化未成功或被强制非流式 | 检查 `structured_mode`；必要时提高 `max_output_tokens` |
| `GET /metrics` 没有某个指标 | Counter/Histogram 无样本时不导出对应标签行 | 先发一次相应请求；`# TYPE` 行始终存在 |
| 提示词 `404 PROMPT_NOT_FOUND` | `name`/`version` 不存在或未 `active` | `GET /v1/prompts` 查版本；创建时 `status` 设 `active` |
| 变量报 `MISSING_VARIABLE` | 必填变量未传且无默认值 | 传齐 `variables`，或在创建模板时给 `default` |
| 端口被占用 | 8000 已被其它进程使用 | `GW_SERVER__PORT=8004 uv run llm-gateway` 或先释放端口 |

## 已知限制（与 DESIGN.md 的偏差）

- **Fallback 切换**未实现（DESIGN §8.2）：路由可配置 `fallback`，但重试器尚未切换备用上游。
- **`/readyz`** 未实现（DESIGN §9 接口表）；当前只有 `/healthz` 存活探针。
- **Redis 限流**只有 `RateLimiter` Protocol 与注入点，未提供 `RedisRateLimiter`/Lua 脚本。
- **`X-RateLimit-*`** 信息型响应头未下发；429 只带 `Retry-After`。
- 网关自身的**鉴权**（`AUTH_FAILED` / `PERMISSION_DENIED`）尚未启用，上游密钥全部走环境变量。
- 重试会产生重复计费风险（上游已生成但网络断开），日志以 `retry_count` 标注，v1 明确接受。
