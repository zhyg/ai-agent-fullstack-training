#!/usr/bin/env python3
"""并发压测脚本：验证限流与 TTFT（DESIGN.md §13 验收用）。

用法：
    python scripts/bench.py --model deepseek-v4-flash --concurrency 100
    python scripts/bench.py --base-url http://127.0.0.1:8004 --requests 200 --stream false

只依赖标准库，可在没有项目虚拟环境的机器上直接跑（用于对着已启动的网关施压）。
"""

from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass


@dataclass
class Result:
    status: int
    total_ms: float
    ttft_ms: float | None = None
    note: str | None = None


def percentile(values: list[float], ratio: float) -> float | None:
    """线性插值分位数；空列表返回 None（不伪造 0）。"""

    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * ratio
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    weight = position - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight


def one_request(
    base_url: str,
    model: str,
    prompt: str,
    *,
    stream: bool,
    timeout_s: float,
) -> Result:
    payload: dict = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": stream,
        "max_output_tokens": 64,
    }
    request = urllib.request.Request(
        base_url.rstrip("/") + "/v1/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=timeout_s) as response:
            status = response.status
            ttft_ms: float | None = None
            if stream:
                for raw in response:
                    line = raw.decode("utf-8", "replace").strip()
                    if not line.startswith("data:"):
                        continue
                    body = line[5:].strip()
                    if body == "[DONE]":
                        break
                    try:
                        chunk = json.loads(body)
                    except json.JSONDecodeError:
                        continue
                    choices = chunk.get("choices") or []
                    if choices and (choices[0].get("delta") or {}).get("content"):
                        ttft_ms = (time.perf_counter() - started) * 1000
                        break
                # 读空剩余流，确保连接被完整消费
                for _ in response:
                    pass
            else:
                response.read()
            total_ms = (time.perf_counter() - started) * 1000
            return Result(status=status, total_ms=total_ms, ttft_ms=ttft_ms)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        total_ms = (time.perf_counter() - started) * 1000
        return Result(status=exc.code, total_ms=total_ms, note=body[:200])
    except Exception as exc:  # noqa: BLE001 - 压测脚本需要把任何失败计入统计
        total_ms = (time.perf_counter() - started) * 1000
        return Result(status=0, total_ms=total_ms, note=repr(exc))


def main() -> int:
    parser = argparse.ArgumentParser(description="Mini LLM Gateway 并发压测")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--model", default="deepseek-v4-flash")
    parser.add_argument("--requests", type=int, default=100)
    parser.add_argument("--concurrency", type=int, default=100)
    parser.add_argument("--stream", choices=["true", "false"], default="true")
    parser.add_argument("--prompt", default="用一句话介绍你自己")
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args()

    stream = args.stream == "true"
    started = time.perf_counter()
    results: list[Result] = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        futures = [
            pool.submit(
                one_request,
                args.base_url,
                args.model,
                args.prompt,
                stream=stream,
                timeout_s=args.timeout,
            )
            for _ in range(args.requests)
        ]
        for future in as_completed(futures):
            results.append(future.result())
    elapsed = time.perf_counter() - started

    ok = [item for item in results if item.status == 200]
    limited = [item for item in results if item.status == 429]
    failed = [item for item in results if item.status not in (200, 429)]

    print(
        f"target={args.base_url} model={args.model} "
        f"requests={args.requests} concurrency={args.concurrency} stream={stream}"
    )
    print(
        f"result: ok={len(ok)} rate_limited={len(limited)} failed={len(failed)} "
        f"throughput={len(results) / elapsed:.1f} req/s"
    )
    for bucket_name, bucket in (("ok", ok), ("rate_limited", limited)):
        totals = [item.total_ms for item in bucket]
        if totals:
            print(
                f"{bucket_name:>12} latency_ms "
                f"p50={percentile(totals, 0.50):.1f} "
                f"p95={percentile(totals, 0.95):.1f} "
                f"max={max(totals):.1f}"
            )
    ttfts = [item.ttft_ms for item in ok if item.ttft_ms is not None]
    if ttfts:
        print(
            f"{'ok':>12} ttft_ms    p50={percentile(ttfts, 0.50):.1f} "
            f"p95={percentile(ttfts, 0.95):.1f} max={max(ttfts):.1f}"
        )
    else:
        print(f"{'ok':>12} ttft_ms    n/a（没有成功拿到 delta 的请求）")

    failures = [item for item in failed if item.note]
    if failures:
        sample = failures[0]
        print(f"sample failure: status={sample.status} note={sample.note}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
