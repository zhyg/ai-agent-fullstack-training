"""Stage 0 地基测试：错误码、错误响应体、request_id、配置校验与日志。"""

from __future__ import annotations

import json
import re

import pytest
import structlog
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel, ValidationError

from gateway.config import Settings, format_validation_error
from gateway.core.errors import (
    ERROR_SPECS,
    ErrorCode,
    GatewayError,
    build_error_body,
)
from gateway.main import create_app
from gateway.telemetry.logging import configure_logging

# DESIGN.md §8.1 的 18 个错误码：code -> (http_status, retryable)
DESIGN_TABLE = {
    "INVALID_REQUEST": (400, False),
    "MISSING_VARIABLE": (400, False),
    "SCHEMA_INCOMPATIBLE": (400, False),
    "CONTEXT_LENGTH_EXCEEDED": (400, False),
    "CONTENT_FILTERED": (400, False),
    "PROMPT_NOT_FOUND": (404, False),
    "MODEL_NOT_FOUND": (404, False),
    "AUTH_FAILED": (401, False),
    "PERMISSION_DENIED": (403, False),
    "RATE_LIMITED": (429, True),
    "UPSTREAM_AUTH": (401, False),
    "UPSTREAM_BAD_REQUEST": (400, False),
    "UPSTREAM_TIMEOUT": (504, True),
    "UPSTREAM_UNAVAILABLE": (503, True),
    "UPSTREAM_BAD_RESPONSE": (502, True),
    "OUTPUT_PARSE_FAILED": (502, True),
    "STREAM_INTERRUPTED": (502, True),
    "INTERNAL": (500, False),
}

REQUEST_ID_RE = re.compile(r"^req_[0-9a-f]{24}$")


class Payload(BaseModel):
    value: int


@pytest.fixture()
def app() -> FastAPI:
    application = create_app(Settings(debug=False))

    @application.post("/_test/validate")
    async def _validate(payload: Payload) -> dict[str, bool]:
        return {"ok": True}

    @application.get("/_test/boom")
    async def _boom() -> None:
        raise RuntimeError("boom")

    return application


@pytest.fixture()
def client(app: FastAPI) -> TestClient:
    # raise_server_exceptions=False 便于断言统一 500 响应体
    with TestClient(app, raise_server_exceptions=False) as test_client:
        yield test_client


def test_error_code_table_matches_design() -> None:
    assert len(ErrorCode) == 18
    for code, (status, retryable) in DESIGN_TABLE.items():
        spec = ERROR_SPECS[code]
        assert spec.http_status == status, code
        assert spec.retryable is retryable, code


def test_gateway_error_uses_table_defaults() -> None:
    exc = GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "upstream 529")
    assert exc.status_code == 503
    assert exc.retryable is True
    assert exc.error_type == "upstream_error"

    overridden = GatewayError(
        ErrorCode.MODEL_NOT_FOUND, "unknown", http_status=404, retryable=False
    )
    assert overridden.status_code == 404


def test_error_body_shape_and_debug_details() -> None:
    body = build_error_body(
        ErrorCode.MODEL_NOT_FOUND,
        "unknown model",
        "req_abc",
        details={"available": ["deepseek-v4-flash"]},
        debug=False,
        retryable=False,
    )
    assert set(body["error"]) == {"code", "message", "type", "request_id", "retryable"}
    assert body["error"]["code"] == "MODEL_NOT_FOUND"

    debug_body = build_error_body(
        ErrorCode.MODEL_NOT_FOUND,
        "unknown model",
        "req_abc",
        details={"available": ["deepseek-v4-flash"]},
        debug=True,
        retryable=False,
    )
    assert "details" in debug_body["error"]


def test_unknown_code_falls_back_to_internal() -> None:
    body = build_error_body("SOME_UNKNOWN_CODE", "boom", "req_abc")
    assert body["error"]["type"] == "internal_error"
    assert body["error"]["retryable"] is False


def test_healthz(client: TestClient) -> None:
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert response.headers["X-Request-Id"].startswith("req_")


def test_chat_rejects_empty_body(client: TestClient) -> None:
    response = client.post("/v1/chat", json={})
    assert response.status_code == 400
    payload = response.json()["error"]
    assert payload["code"] == "INVALID_REQUEST"
    assert payload["retryable"] is False
    assert payload["request_id"] == response.headers["X-Request-Id"]


def test_chat_unknown_model_returns_404(client: TestClient) -> None:
    response = client.post(
        "/v1/chat",
        json={"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert response.status_code == 404
    payload = response.json()["error"]
    assert payload["code"] == "MODEL_NOT_FOUND"
    assert "deepseek-v4-pro" in payload["message"]


def test_request_id_generated_and_echoed(client: TestClient) -> None:
    response = client.get("/healthz")
    request_id = response.headers["X-Request-Id"]
    assert REQUEST_ID_RE.match(request_id), request_id


def test_client_request_id_is_passed_through(client: TestClient) -> None:
    response = client.get("/healthz", headers={"X-Request-Id": "req_client_123456"})
    assert response.headers["X-Request-Id"] == "req_client_123456"


@pytest.mark.parametrize("bad_id", ["short", "bad id!", "x" * 129])
def test_invalid_request_id_is_rejected(client: TestClient, bad_id: str) -> None:
    response = client.get("/healthz", headers={"X-Request-Id": bad_id})
    assert response.status_code == 400
    payload = response.json()["error"]
    assert payload["code"] == "INVALID_REQUEST"
    assert REQUEST_ID_RE.match(response.headers["X-Request-Id"])


def test_request_validation_maps_to_invalid_request(client: TestClient) -> None:
    response = client.post("/_test/validate", json={})
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "INVALID_REQUEST"


def test_unexpected_error_maps_to_internal(client: TestClient) -> None:
    response = client.get("/_test/boom")
    assert response.status_code == 500
    payload = response.json()["error"]
    assert payload["code"] == "INTERNAL"
    assert payload["retryable"] is False


def test_settings_reject_invalid_retry() -> None:
    with pytest.raises(ValidationError) as excinfo:
        Settings(retry={"max_attempts": 0})
    text = format_validation_error(excinfo.value)
    assert "retry.max_attempts" in text


def test_settings_reject_inconsistent_delay_range() -> None:
    with pytest.raises(ValidationError) as excinfo:
        Settings(retry={"base_delay_ms": 10000, "max_delay_ms": 5000})
    text = format_validation_error(excinfo.value)
    assert "max_delay_ms" in text


def test_settings_env_overrides_yaml(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GW_SERVER__PORT", "9090")
    settings = Settings()
    assert settings.server.port == 9090


def test_logging_is_single_line_json(capsys: pytest.CaptureFixture[str]) -> None:
    configure_logging("info")
    structlog.get_logger("stage0-test").info("hello", answer=42)
    lines = capsys.readouterr().out.strip().splitlines()
    assert len(lines) == 1
    payload = json.loads(lines[0])
    assert payload["event"] == "hello"
    assert payload["answer"] == 42
    assert "ts" in payload and "level" in payload
