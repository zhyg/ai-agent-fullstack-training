"""Stage 3 结构化输出测试：档位选择、方言翻译、L3 修复、拒答与 API 入口。"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient

from gateway.adapters.anthropic_messages import AnthropicMessagesAdapter
from gateway.adapters.registry import AdapterRegistry
from gateway.config import Settings
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.invoker import Gateway
from gateway.core.ir import (
    CallContext,
    CanonicalMessage,
    CanonicalRequest,
    FinishReason,
    ResponseFormat,
    Role,
    TokenUsage,
)
from gateway.core.router import ModelRoute, Router
from gateway.main import create_app
from gateway.structured.enforce import (
    StructuredMode,
    StructuredOutputError,
    apply_plan,
    build_repair_request,
    choose_mode,
    extract_structured,
)
from gateway.structured.translate import (
    anthropic_output_config,
    openai_text_format,
    prompt_instruction,
)

ISSUE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "priority": {"type": "integer"},
    },
    "required": ["title", "priority"],
    "additionalProperties": False,
}

SCHEMA_FORMAT = ResponseFormat(
    type="json_schema", name="issue_report", schema=ISSUE_SCHEMA, strict=True
)
JSON_OBJECT_FORMAT = ResponseFormat(type="json_object", strict=True)
VALID_JSON_TEXT = '{"title": "网关超时", "priority": 2}'


def caps(*, schema: bool = True, json_object: bool = True) -> dict[str, Any]:
    return {
        "max_context_tokens": 1000,
        "max_output_tokens": 100,
        "supports_stream": True,
        "supports_json_schema": schema,
        "supports_json_object": json_object,
        "supports_reasoning": False,
        "supports_prompt_caching": False,
    }


def make_request(
    model: str = "deepseek-v4-pro",
    *,
    response_format: ResponseFormat | None = SCHEMA_FORMAT,
) -> CanonicalRequest:
    return CanonicalRequest(
        request_id="req_structured",
        model=model,
        messages=[CanonicalMessage(role=Role.USER, content="总结这个线上问题")],
        response_format=response_format,
    )


def openai_raw(text: str) -> dict[str, Any]:
    return {
        "id": "resp_structured",
        "model": "deepseek-v4-pro",
        "status": "completed",
        "output": [
            {"type": "message", "content": [{"type": "output_text", "text": text}]}
        ],
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }


def openai_refusal_raw(reason: str = "I cannot help with that.") -> dict[str, Any]:
    return {
        "id": "resp_refusal",
        "model": "deepseek-v4-pro",
        "status": "completed",
        "output": [
            {"type": "message", "content": [{"type": "refusal", "refusal": reason}]}
        ],
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }


def anthropic_raw(text: str) -> dict[str, Any]:
    return {
        "id": "msg_structured",
        "model": "deepseek-v4-flash",
        "content": [{"type": "text", "text": text}],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }


class ScriptedTransport:
    """按脚本依次返回上游响应，记录每次请求。"""

    def __init__(self, responses: list[httpx.Response]) -> None:
        self.responses = list(responses)
        self.calls: list[tuple[str, dict, dict]] = []

    async def post(self, url, payload, headers, route):
        self.calls.append((url, payload, headers))
        if not self.responses:
            raise AssertionError("no more scripted upstream responses")
        return self.responses.pop(0)


def gateway_with(transport: ScriptedTransport) -> Gateway:
    return Gateway(
        Router.from_file(),
        AdapterRegistry.default(),
        transport,
        Settings(debug=False),
    )


# ---------------------------------------------------------------- 档位选择


def test_choose_mode_native_schema() -> None:
    plan = choose_mode(SCHEMA_FORMAT, caps())
    assert plan is not None
    assert plan.mode is StructuredMode.NATIVE_SCHEMA
    assert plan.schema == ISSUE_SCHEMA


def test_choose_mode_falls_back_to_prompt_repair_without_native_schema() -> None:
    plan = choose_mode(SCHEMA_FORMAT, caps(schema=False))
    assert plan is not None
    assert plan.mode is StructuredMode.PROMPT_REPAIR


def test_choose_mode_json_object() -> None:
    assert choose_mode(JSON_OBJECT_FORMAT, caps()).mode is StructuredMode.NATIVE_JSON_OBJECT
    # Anthropic 无 json_object 等价能力
    assert choose_mode(JSON_OBJECT_FORMAT, caps(json_object=False)).mode is (
        StructuredMode.PROMPT_REPAIR
    )


def test_choose_mode_none_for_text() -> None:
    assert choose_mode(None, caps()) is None
    assert choose_mode(ResponseFormat(type="text"), caps()) is None


def test_choose_mode_lints_incompatible_schema() -> None:
    bad = ResponseFormat(
        type="json_schema",
        name="bad",
        schema={"type": "object", "properties": {"a": {"type": "string"}}},
    )
    with pytest.raises(GatewayError) as excinfo:
        choose_mode(bad, caps())
    assert excinfo.value.code == ErrorCode.SCHEMA_INCOMPATIBLE.value


# ---------------------------------------------------------------- 方言翻译


def test_translate_openai_format() -> None:
    fmt = openai_text_format(SCHEMA_FORMAT)
    assert fmt["type"] == "json_schema"
    assert fmt["name"] == "issue_report"
    assert fmt["schema"] == ISSUE_SCHEMA
    assert fmt["strict"] is True
    assert openai_text_format(JSON_OBJECT_FORMAT) == {"type": "json_object"}


def test_translate_anthropic_format() -> None:
    config = anthropic_output_config(SCHEMA_FORMAT)
    assert config == {
        "format": {
            "type": "json_schema",
            "json_schema": {"name": "issue_report", "schema": ISSUE_SCHEMA},
        }
    }
    # json_object 无等价能力
    assert anthropic_output_config(JSON_OBJECT_FORMAT) is None


# ---------------------------------------------------------------- 提示词与修复请求


def test_apply_plan_injects_prompt_for_l3() -> None:
    plan = choose_mode(SCHEMA_FORMAT, caps(schema=False))
    req = make_request()
    applied = apply_plan(req, plan)
    assert applied.response_format is None
    assert "JSON Schema" in applied.system
    assert "issue_report" not in applied.system  # 提示词里只有 schema 本身
    assert applied.messages == req.messages


def test_apply_plan_merges_existing_system() -> None:
    req = make_request()
    req.system = "你是问题分诊助手"
    plan = choose_mode(JSON_OBJECT_FORMAT, caps(json_object=False))
    applied = apply_plan(req, plan)
    assert applied.system.startswith("你是问题分诊助手")
    assert "JSON 对象" in applied.system


def test_apply_plan_keeps_native_format() -> None:
    plan = choose_mode(SCHEMA_FORMAT, caps())
    applied = apply_plan(make_request(), plan)
    assert applied.response_format == SCHEMA_FORMAT


def test_build_repair_request_appends_history() -> None:
    plan = choose_mode(SCHEMA_FORMAT, caps(schema=False))
    req = make_request()
    repair = build_repair_request(req, plan, "not json", "invalid JSON")
    assert repair.response_format is None
    assert repair.messages[-2].role is Role.ASSISTANT
    assert repair.messages[-2].content == "not json"
    assert repair.messages[-1].role is Role.USER
    assert "未通过校验" in repair.messages[-1].content
    assert "JSON Schema" in repair.system


def test_prompt_instruction_mentions_fence_ban() -> None:
    assert "```json" in prompt_instruction(JSON_OBJECT_FORMAT)


# ---------------------------------------------------------------- 解析与校验


def test_extract_plain_json() -> None:
    assert extract_structured(VALID_JSON_TEXT, SCHEMA_FORMAT) == {
        "title": "网关超时",
        "priority": 2,
    }


def test_extract_strips_markdown_fences() -> None:
    fenced = f"```json\n{VALID_JSON_TEXT}\n```"
    assert extract_structured(fenced, SCHEMA_FORMAT)["priority"] == 2


def test_extract_rejects_invalid_json() -> None:
    with pytest.raises(StructuredOutputError, match="invalid JSON"):
        extract_structured("{title: 1}", SCHEMA_FORMAT)


def test_extract_rejects_schema_violation() -> None:
    with pytest.raises(StructuredOutputError, match="schema validation failed"):
        extract_structured('{"title": "x", "priority": "high"}', SCHEMA_FORMAT)


def test_extract_rejects_non_object() -> None:
    with pytest.raises(StructuredOutputError, match="expected a JSON object"):
        extract_structured("[1, 2]", SCHEMA_FORMAT)


def test_extract_rejects_empty_content() -> None:
    with pytest.raises(StructuredOutputError, match="empty content"):
        extract_structured("   ", SCHEMA_FORMAT)


def test_json_object_mode_skips_schema_validation() -> None:
    assert extract_structured('{"anything": [1]}', JSON_OBJECT_FORMAT) == {"anything": [1]}


# ---------------------------------------------------------------- Gateway 三档


@pytest.mark.anyio
async def test_gateway_l1_native_schema(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw(VALID_JSON_TEXT))])
    gateway = gateway_with(transport)

    response = await gateway.complete(make_request(), CallContext(request_id="req_l1"))

    payload = transport.calls[0][1]
    assert payload["text"]["format"]["type"] == "json_schema"
    assert payload["text"]["format"]["schema"] == ISSUE_SCHEMA
    assert payload["text"]["format"]["strict"] is True
    assert response.structured == {"title": "网关超时", "priority": 2}
    assert response.structured_mode == StructuredMode.NATIVE_SCHEMA.value
    assert response.to_dict()["structured_mode"] == "native_schema"


@pytest.mark.anyio
async def test_gateway_l2_native_json_object(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw('{"ok": true}'))])
    gateway = gateway_with(transport)

    response = await gateway.complete(
        make_request(response_format=JSON_OBJECT_FORMAT),
        CallContext(request_id="req_l2"),
    )

    assert transport.calls[0][1]["text"]["format"] == {"type": "json_object"}
    assert response.structured == {"ok": True}
    assert response.structured_mode == StructuredMode.NATIVE_JSON_OBJECT.value


@pytest.mark.anyio
async def test_gateway_l3_prompt_repair_for_json_object(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash-key")
    transport = ScriptedTransport([httpx.Response(200, json=anthropic_raw('{"ok": true}'))])
    gateway = gateway_with(transport)

    response = await gateway.complete(
        make_request("deepseek-v4-flash", response_format=JSON_OBJECT_FORMAT),
        CallContext(request_id="req_l3"),
    )

    payload = transport.calls[0][1]
    assert "output_config" not in payload
    assert "JSON 对象" in payload["system"]
    assert response.structured == {"ok": True}
    assert response.structured_mode == StructuredMode.PROMPT_REPAIR.value


@pytest.mark.anyio
async def test_gateway_l3_schema_prompt_for_adapter_without_native_schema(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """能力声明为「无原生 schema」的厂商走 L3：提示词注入 schema，不下发 output_config。"""

    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash-key")
    transport = ScriptedTransport([httpx.Response(200, json=anthropic_raw(VALID_JSON_TEXT))])

    class LegacyAnthropicAdapter(AnthropicMessagesAdapter):
        name = "anthropic_legacy"

        def capabilities(self, route):
            caps = super().capabilities(route)
            caps["supports_json_schema"] = False
            return caps

    route = ModelRoute(
        model="legacy-flash",
        adapter="anthropic_legacy",
        upstream_model="deepseek-v4-flash",
        base_url="https://api.deepseek.com",
        api_key_env="DEEPSEEK_FLASH_API_KEY",
        default_max_tokens=4096,
    )
    gateway = Gateway(
        Router({"legacy-flash": route}),
        AdapterRegistry({"anthropic_legacy": LegacyAnthropicAdapter()}),
        transport,
        Settings(debug=False),
    )

    response = await gateway.complete(
        make_request("legacy-flash"), CallContext(request_id="req_l3_schema")
    )

    payload = transport.calls[0][1]
    assert "output_config" not in payload
    assert "JSON Schema" in payload["system"]
    assert response.structured_mode == StructuredMode.PROMPT_REPAIR.value
    assert response.structured["title"] == "网关超时"


@pytest.mark.anyio
async def test_gateway_l3_repair_retry_succeeds(monkeypatch: pytest.MonkeyPatch) -> None:
    """flash 的 json_object 走 L3；第一次非法 → 回灌修复 → 第二次成功。"""

    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash-key")
    transport = ScriptedTransport(
        [
            httpx.Response(200, json=anthropic_raw("我觉得是网络问题，不是 JSON。")),
            httpx.Response(200, json=anthropic_raw(f"```json\n{VALID_JSON_TEXT}\n```")),
        ]
    )
    gateway = gateway_with(transport)

    response = await gateway.complete(
        make_request("deepseek-v4-flash", response_format=JSON_OBJECT_FORMAT),
        CallContext(request_id="req_repair"),
    )

    assert len(transport.calls) == 2
    repair_payload = transport.calls[1][1]
    assert repair_payload["messages"][-2] == {
        "role": "assistant",
        "content": "我觉得是网络问题，不是 JSON。",
    }
    assert repair_payload["messages"][-1]["role"] == "user"
    assert "上一次输出" in repair_payload["messages"][-1]["content"]
    assert response.structured == {"title": "网关超时", "priority": 2}
    assert response.structured_mode == StructuredMode.PROMPT_REPAIR.value


@pytest.mark.anyio
async def test_gateway_l3_repair_budget_exhausted(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash-key")
    transport = ScriptedTransport(
        [httpx.Response(200, json=anthropic_raw("not json")) for _ in range(3)]
    )
    gateway = gateway_with(transport)

    with pytest.raises(GatewayError) as excinfo:
        await gateway.complete(
            make_request("deepseek-v4-flash", response_format=JSON_OBJECT_FORMAT),
            CallContext(request_id="req_repair_fail"),
        )

    assert len(transport.calls) == 3  # 首次 + 2 次修复
    error = excinfo.value
    assert error.code == ErrorCode.OUTPUT_PARSE_FAILED.value
    assert error.details["repair_attempts"] == 2


@pytest.mark.anyio
async def test_openai_refusal_maps_to_content_filtered(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """DESIGN §5.3：refusal 必须报 CONTENT_FILTERED，不能误报 OUTPUT_PARSE_FAILED。"""

    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport([httpx.Response(200, json=openai_refusal_raw())])
    gateway = gateway_with(transport)

    with pytest.raises(GatewayError) as excinfo:
        await gateway.complete(make_request(), CallContext(request_id="req_refusal"))

    error = excinfo.value
    assert error.code == ErrorCode.CONTENT_FILTERED.value
    assert error.code != ErrorCode.OUTPUT_PARSE_FAILED.value
    assert error.status_code == 400


@pytest.mark.anyio
async def test_native_schema_invalid_output_reports_parse_failed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw("这不是 JSON"))])
    gateway = gateway_with(transport)

    with pytest.raises(GatewayError) as excinfo:
        await gateway.complete(make_request(), CallContext(request_id="req_native_bad"))

    assert excinfo.value.code == ErrorCode.OUTPUT_PARSE_FAILED.value
    assert len(transport.calls) == 1  # 原生档位不做修复重试


# ---------------------------------------------------------------- 流式 + 结构化


def _sse(payload: dict[str, Any]) -> str:
    return f"event: {payload['type']}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


def openai_structured_stream(deltas: list[str]) -> bytes:
    frames = [_sse({"type": "response.created"})]
    frames += [
        _sse({"type": "response.output_text.delta", "delta": delta}) for delta in deltas
    ]
    frames.append(
        _sse(
            {
                "type": "response.completed",
                "response": {
                    "status": "completed",
                    "usage": {"input_tokens": 10, "output_tokens": 5},
                },
            }
        )
    )
    return "".join(frames).encode()


class FakeStreamTransport:
    """只实现流式接口的传输桩。"""

    def __init__(self, body: bytes, *, status: int = 200) -> None:
        self.body = body
        self.response = httpx.Response(
            status,
            content=body,
            headers={"content-type": "text/event-stream"},
        )
        self.calls: list[tuple[str, dict, dict]] = []

    async def post(self, url, payload, headers, route):  # pragma: no cover
        raise AssertionError("streaming request must use transport.stream()")

    async def stream(self, url, payload, headers, route):
        self.calls.append((url, payload, headers))
        return self.response


@pytest.mark.anyio
async def test_gateway_stream_attaches_structured_only_on_done(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    body = openai_structured_stream(['{"title": ', '"网关超时", ', '"priority": 2}'])
    gateway = Gateway(
        Router.from_file(),
        AdapterRegistry.default(),
        FakeStreamTransport(body),
        Settings(debug=False),
    )

    events = [
        event
        async for event in gateway.stream(make_request(), CallContext(request_id="req_sse"))
    ]

    deltas = [event for event in events if event.type == "delta"]
    assert len(deltas) == 3
    assert all(event.structured is None for event in deltas)
    done = events[-1]
    assert done.type == "done"
    assert done.structured == {"title": "网关超时", "priority": 2}
    assert done.structured_mode == StructuredMode.NATIVE_SCHEMA.value


@pytest.mark.anyio
async def test_gateway_stream_invalid_structured_emits_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    body = openai_structured_stream(["不是", "JSON"])
    gateway = Gateway(
        Router.from_file(),
        AdapterRegistry.default(),
        FakeStreamTransport(body),
        Settings(debug=False),
    )

    events = [
        event
        async for event in gateway.stream(make_request(), CallContext(request_id="req_sse_bad"))
    ]

    assert events[-1].type == "error"
    assert isinstance(events[-1].error, GatewayError)
    assert events[-1].error.code == ErrorCode.OUTPUT_PARSE_FAILED.value


# ---------------------------------------------------------------- API 入口


def _app(transport: Any, *, debug: bool = False) -> TestClient:
    return TestClient(create_app(Settings(debug=debug), transport=transport))


def test_api_rejects_incompatible_schema() -> None:
    bad_schema = {
        "type": "object",
        "properties": {"title": {"$ref": "#/$defs/title"}},
        "required": ["title"],
        "additionalProperties": False,
    }
    # debug=True 才透出 details；这里借此断言违规明细（默认线上不暴露内部细节）
    with _app(ScriptedTransport([]), debug=True) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "hi"}],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"name": "bad", "schema": bad_schema},
                },
            },
        )

    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == ErrorCode.SCHEMA_INCOMPATIBLE.value
    assert body["error"]["retryable"] is False
    assert body["error"]["details"]["issues"][0]["rule"] == "no_ref"


def test_api_json_schema_requires_name() -> None:
    with _app(ScriptedTransport([])) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "hi"}],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"schema": ISSUE_SCHEMA},
                },
            },
        )

    assert response.status_code == 400
    assert response.json()["error"]["code"] == ErrorCode.INVALID_REQUEST.value


def test_api_structured_forces_non_streaming(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw(VALID_JSON_TEXT))])
    with _app(transport) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "issue_report",
                        "schema": ISSUE_SCHEMA,
                        "strict": True,
                    },
                },
            },
        )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/json")
    body = response.json()
    assert body["note"].startswith("structured output forced non-streaming")
    assert body["structured"] == {"title": "网关超时", "priority": 2}
    assert body["structured_mode"] == "native_schema"
    assert transport.calls[0][1]["stream"] is False


def test_api_structured_stream_opt_in(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    body = openai_structured_stream(['{"title": ', '"网关超时", ', '"priority": 2}'])
    with _app(FakeStreamTransport(body)) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
                "structured_stream": True,
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "issue_report",
                        "schema": ISSUE_SCHEMA,
                        "strict": True,
                    },
                },
            },
        )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    data = [
        frame[len("data:"):].strip()
        for frame in response.text.split("\n\n")
        if frame.startswith("data:")
    ]
    assert data[-1] == "[DONE]"
    chunks = [json.loads(frame) for frame in data[:-1]]
    assert all("structured" not in chunk for chunk in chunks[:-1])
    final = chunks[-1]
    assert final["structured"] == {"title": "网关超时", "priority": 2}
    assert final["structured_mode"] == "native_schema"
    assert final["choices"][0]["finish_reason"] == "stop"


@pytest.mark.anyio
async def test_structured_response_carries_usage_and_latency(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw(VALID_JSON_TEXT))])
    gateway = gateway_with(transport)

    response = await gateway.complete(make_request(), CallContext(request_id="req_metrics"))

    assert isinstance(response.usage, TokenUsage)
    assert response.usage.total_tokens == 15
    assert response.finish_reason is FinishReason.STOP
    assert response.latency.total_ms is not None
