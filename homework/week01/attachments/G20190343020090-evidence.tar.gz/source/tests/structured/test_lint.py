"""Stage 3 schema lint 单元测试：DESIGN.md §5.3 的六条兼容子集规则。"""

from __future__ import annotations

import json
from typing import Any

import pytest

from gateway.core.errors import ErrorCode, GatewayError
from gateway.structured.lint import (
    MAX_DEPTH,
    MAX_PROPERTIES,
    MAX_SCHEMA_BYTES,
    ensure_compatible,
    lint_schema,
)


def valid_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "priority": {"type": "integer"},
            # 可选字段用 ["string","null"] 表达，而不是移出 required
            "note": {"type": ["string", "null"]},
            "tags": {"type": "array", "items": {"type": "string"}},
            "meta": {
                "type": "object",
                "properties": {"source": {"type": "string"}},
                "required": ["source"],
                "additionalProperties": False,
            },
        },
        "required": ["title", "priority", "note", "tags", "meta"],
        "additionalProperties": False,
    }


def rules_of(schema: Any) -> set[str]:
    return {issue.rule for issue in lint_schema(schema)}


def test_valid_schema_has_no_issues() -> None:
    assert lint_schema(valid_schema()) == []


def test_object_requires_additional_properties_false() -> None:
    schema = valid_schema()
    schema.pop("additionalProperties")
    issues = lint_schema(schema)
    assert {issue.rule for issue in issues} == {"additional_properties"}
    assert issues[0].path == "$"


def test_nested_object_is_checked_too() -> None:
    schema = valid_schema()
    schema["properties"]["meta"].pop("additionalProperties")
    issues = lint_schema(schema)
    assert [(issue.path, issue.rule) for issue in issues] == [
        ("$.meta", "additional_properties")
    ]


def test_optional_field_must_stay_in_required() -> None:
    schema = valid_schema()
    schema["required"].remove("note")
    issues = lint_schema(schema)
    assert len(issues) == 1
    assert issues[0].path == "$.note"
    assert issues[0].rule == "missing_required"


@pytest.mark.parametrize(
    "mutate,expected_rule",
    [
        (
            lambda schema: schema["properties"].update(
                {"title": {"$ref": "#/$defs/title"}}
            ),
            "no_ref",
        ),
        (lambda schema: schema.update({"$defs": {"title": {"type": "string"}}}), "no_defs"),
        (lambda schema: schema.update({"definitions": {}}), "no_defs"),
        (
            lambda schema: schema["properties"].update(
                {"priority": {"oneOf": [{"type": "integer"}, {"type": "string"}]}}
            ),
            "no_oneof",
        ),
        (
            lambda schema: schema["properties"].update(
                {"title": {"type": "string", "pattern": "^[A-Z]"}}
            ),
            "no_pattern",
        ),
        (
            lambda schema: schema["properties"].update(
                {"title": {"type": "string", "format": "email"}}
            ),
            "no_format",
        ),
    ],
    ids=["ref", "defs", "definitions", "oneof", "pattern", "format"],
)
def test_forbidden_keywords(mutate, expected_rule: str) -> None:
    schema = valid_schema()
    mutate(schema)
    assert expected_rule in rules_of(schema)


def _nested_objects(levels: int) -> dict[str, Any]:
    """构造 levels 层嵌套 object 的 schema（根对象算第 1 层）。"""

    schema: dict[str, Any] = {
        "type": "object",
        "properties": {"leaf": {"type": "string"}},
        "required": ["leaf"],
        "additionalProperties": False,
    }
    for _ in range(levels - 1):
        schema = {
            "type": "object",
            "properties": {"child": schema},
            "required": ["child"],
            "additionalProperties": False,
        }
    return schema


def test_depth_within_limit_passes() -> None:
    assert lint_schema(_nested_objects(MAX_DEPTH)) == []


def test_depth_over_limit_is_rejected() -> None:
    issues = lint_schema(_nested_objects(MAX_DEPTH + 1))
    assert [issue.rule for issue in issues] == ["max_depth"]


def test_property_count_limit() -> None:
    props = {f"f{index}": {"type": "string"} for index in range(MAX_PROPERTIES + 1)}
    schema = {
        "type": "object",
        "properties": props,
        "required": sorted(props),
        "additionalProperties": False,
    }
    assert "too_many_properties" in rules_of(schema)


def test_schema_size_limit() -> None:
    props = {
        f"f{index}": {"type": "string", "description": "x" * 300}
        for index in range(MAX_PROPERTIES)
    }
    schema = {
        "type": "object",
        "properties": props,
        "required": sorted(props),
        "additionalProperties": False,
    }
    size = len(json.dumps(schema, ensure_ascii=False).encode("utf-8"))
    assert size > MAX_SCHEMA_BYTES
    assert "schema_too_large" in rules_of(schema)


def test_non_object_schema_is_rejected() -> None:
    assert rules_of(["not", "a", "dict"]) == {"invalid_schema"}


def test_ensure_compatible_passes_valid_schema() -> None:
    ensure_compatible(valid_schema(), name="issue_report")


def test_ensure_compatible_raises_400_with_issue_details() -> None:
    bad = valid_schema()
    bad.pop("additionalProperties")
    with pytest.raises(GatewayError) as excinfo:
        ensure_compatible(bad, name="issue_report")

    error = excinfo.value
    assert error.code == ErrorCode.SCHEMA_INCOMPATIBLE.value
    assert error.status_code == 400
    assert error.retryable is False
    assert error.details["schema_name"] == "issue_report"
    assert error.details["issues"][0]["rule"] == "additional_properties"
