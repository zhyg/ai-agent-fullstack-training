"""Stage 7 端到端场景：逐条对齐 DESIGN.md §13 的验收清单。

每个用例都走完整的 HTTP → 路由 → 适配器 → 传输 管线（只把上游替换成
`fault_injection.ScriptedTransport`），并尽可能用真实的 Prometheus 指标
与真实的 SQLite 提示词库，避免「单测通过但整机不通」。
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient

from gateway.api.routers.sse import stream_frames
from gateway.core.adapter import ModelCapabilities
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.events import CanonicalEvent
from gateway.core.ir import (
    CallContext,
    CanonicalMessage,
    CanonicalRequest,
    CanonicalResponse,
    FinishReason,
    Role,
    TokenUsage,
)
from gateway.core.router import ModelRoute, RouteLimits, RouteTimeout
from gateway.prompt.store import SQLiteStore
from gateway.resilience.ratelimit import MemoryRateLimiter

from fault_injection import (
    ANTHROPIC_RAW,
    ANTHROPIC_SSE,
    OPENAI_RAW,
    OPENAI_SSE,
    ScriptedTransport,
    build_app,
    default_models,
    error_reply,
    ok_json,
    ok_sse,
    ok_text,
    truncated_anthropic_sse,
)

CHAT = "/v1/chat"


@pytest.fixture(autouse=True)
def _api_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    """适配器只从环境变量取密钥；测试用假值，绝不写真实 key。"""

    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "test-pro-key")
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "test-flash-key")


def extra_model(
    name: str,
    *,
    adapter: str = "openai_responses",
    upstream_model: str | None = None,
    limits: RouteLimits | None = None,
) -> ModelRoute:
    """追加一条 e2e 路由；模型名刻意唯一，便于断言指标标签。"""

    return ModelRoute(
        adapter=adapter,
        upstream_model=upstream_model or name,
        base_url="https://mock.local",
        api_key_env="DEEPSEEK_PRO_API_KEY",
        timeout=RouteTimeout(connect=5, read=30),
        limits=limits or RouteLimits(rpm=60, tpm=200000, concurrent=8),
    )


def chat_payload(model: str, *, stream: bool = False, **extra: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": model,
        "messages": [{"role": "user", "content": "讲个故事"}],
        "stream": stream,
    }
    payload.update(extra)
    return payload


def sse_data_frames(body: str) -> list[str]:
    """拆出 `data:` 负载；心跳注释行（`: heartbeat`）不进入结果。"""

    frames: list[str] = []
    for block in body.split("\n\n"):
        block = block.strip()
        if not block or block.startswith(":"):
            continue
        for line in block.splitlines():
            if line.startswith("data:"):
                frames.append(line[5:].strip())
    return frames


def sse_deltas(frames: list[str]) -> str:
    pieces: list[str] = []
    for frame in frames:
        if frame == "[DONE]":
            continue
        body = json.loads(frame)
        for choice in body.get("choices") or []:
            piece = (choice.get("delta") or {}).get("content")
            if piece:
                pieces.append(piece)
    return "".join(pieces)


def final_chunk(frames: list[str]) -> dict[str, Any]:
    for frame in reversed(frames):
        if frame == "[DONE]":
            continue
        body = json.loads(frame)
        if body.get("gateway"):
            return body
    raise AssertionError("no final chunk with gateway metadata")


def error_frame(frames: list[str]) -> dict[str, Any]:
    for frame in frames:
        if frame == "[DONE]":
            continue
        body = json.loads(frame)
        if body.get("error"):
            return body["error"]
    raise AssertionError("no error frame in stream")


def metrics_text(client: TestClient) -> str:
    response = client.get("/metrics")
    assert response.status_code == 200
    return response.text


# ---------------------------------------------------------------- 场景 1
def test_dual_adapters_translate_same_request() -> None:
    """清单 1：同一个 CanonicalRequest 能被两个适配器正确翻译。"""

    transport = (
        ScriptedTransport()
        .script("deepseek-v4-pro", ok_json(OPENAI_RAW))
        .script("deepseek-v4-flash", ok_json(ANTHROPIC_RAW))
    )
    client = TestClient(build_app(transport))

    pro = client.post(CHAT, json=chat_payload("deepseek-v4-pro"))
    flash = client.post(CHAT, json=chat_payload("deepseek-v4-flash"))

    assert pro.status_code == 200 and flash.status_code == 200
    assert pro.json()["text"] == flash.json()["text"] == "你好，我是网关。"
    assert pro.json()["adapter"] == "openai_responses"
    assert flash.json()["adapter"] == "anthropic_messages"
    # 两家 usage 字段不同，但都归一成五分类 + source
    usage = flash.json()["usage"]
    for key in (
        "input_tokens",
        "output_tokens",
        "reasoning_tokens",
        "cache_read_tokens",
        "cache_write_tokens",
        "source",
    ):
        assert key in usage
    assert usage["source"] == "reported"


# ---------------------------------------------------------------- 场景 2
def test_stream_contract_is_data_only_and_ends_with_done() -> None:
    """清单 2：SSE 出口只含 data 行，delta 可拼接，结尾 `data: [DONE]`。"""

    transport = ScriptedTransport().script("deepseek-v4-pro", ok_sse(OPENAI_SSE))
    client = TestClient(build_app(transport))

    response = client.post(CHAT, json=chat_payload("deepseek-v4-pro", stream=True))

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert response.headers["X-Request-Id"].startswith("req_")
    body = response.text
    # 每一块都是 data-only：不允许出现 event:/id: 命名事件
    for block in body.split("\n\n"):
        block = block.strip()
        if block and not block.startswith((":", "data:")):
            raise AssertionError(f"unexpected SSE block: {block!r}")

    frames = sse_data_frames(body)
    assert frames[-1] == "[DONE]"
    for frame in frames[:-1]:
        assert isinstance(json.loads(frame), dict)
    assert sse_deltas(frames) == "你好，我是网关。"

    final = final_chunk(frames)
    assert final["choices"][0]["finish_reason"] == "stop"
    assert final["usage"]["source"] == "reported"
    assert final["gateway"]["ttft_ms"] is not None


# ---------------------------------------------------------------- 场景 3
def test_ttft_only_for_requests_that_receive_a_delta() -> None:
    """清单 3 + 9：TTFT 只给真正拿到首个 delta 的请求；指标覆盖五分类与 6 个延迟。"""

    models = default_models()
    models["ttft-ok"] = extra_model("ttft-ok")
    models["ttft-fail"] = extra_model("ttft-fail")
    transport = (
        ScriptedTransport()
        .script("ttft-ok", ok_sse(OPENAI_SSE))
        .script("ttft-fail", error_reply(400, "invalid upstream request"))
    )
    client = TestClient(build_app(transport, models=models))

    ok = client.post(CHAT, json=chat_payload("ttft-ok", stream=True))
    assert ok.status_code == 200
    frames = sse_data_frames(ok.text)
    assert final_chunk(frames)["gateway"]["ttft_ms"] is not None

    failed = client.post(CHAT, json=chat_payload("ttft-fail", stream=True))
    assert failed.status_code == 200  # SSE 已开流，状态码无法再改
    assert error_frame(sse_data_frames(failed.text))["code"] == "UPSTREAM_BAD_REQUEST"

    text = metrics_text(client)
    assert 'llm_ttft_ms_count{adapter="openai_responses",model="ttft-ok"}' in text
    assert 'llm_ttft_ms_count{adapter="openai_responses",model="ttft-fail"}' not in text
    assert 'llm_request_duration_ms_count{adapter="openai_responses",model="ttft-fail"}' in text
    assert 'llm_requests_total{adapter="openai_responses",model="ttft-fail",status="error"}' in text
    # 五分类全部入账
    for token_type in ("input", "output", "reasoning", "cache_read", "cache_write"):
        assert (
            f'llm_tokens_total{{model="ttft-ok",source="reported",type="{token_type}"}}'
            in text
        )
    # 6 个延迟指标全部注册（未产生样本的指标只出现在 TYPE 声明里）
    for metric in (
        "llm_request_duration_ms",
        "llm_ttft_ms",
        "llm_upstream_ttft_ms",
        "llm_queue_wait_ms",
        "llm_retry_overhead_ms",
        "llm_tpot_ms",
    ):
        assert f"# TYPE {metric} histogram" in text


# ---------------------------------------------------------------- 场景 4
COMPATIBLE_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "tags": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["title", "tags"],
    "additionalProperties": False,
}


def structured_payload(model: str, schema: dict[str, Any]) -> dict[str, Any]:
    return chat_payload(
        model,
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "summary", "schema": schema, "strict": True},
        },
    )


def test_structured_schema_native_and_incompatible_preflight() -> None:
    """清单 4：合规 schema 走原生约束；不合规 schema 在调上游之前 400。"""

    models = default_models()
    models["schema-openai"] = extra_model("schema-openai")
    transport = ScriptedTransport().script(
        "schema-openai", ok_text('{"title":"t","tags":["a"]}')
    )
    client = TestClient(build_app(transport, models=models))

    ok = client.post(CHAT, json=structured_payload("schema-openai", COMPATIBLE_SCHEMA))
    assert ok.status_code == 200
    assert ok.json()["structured"] == {"title": "t", "tags": ["a"]}
    assert ok.json()["structured_mode"] == "native_schema"

    bad_schema = json.loads(json.dumps(COMPATIBLE_SCHEMA))
    bad_schema["properties"]["title"]["pattern"] = "^[a-z]+"
    bad = client.post(CHAT, json=structured_payload("schema-openai", bad_schema))
    assert bad.status_code == 400
    assert bad.json()["error"]["code"] == "SCHEMA_INCOMPATIBLE"
    assert bad.json()["error"]["details"]["issues"][0]["rule"] == "no_pattern"
    # lint 在预检阶段就拦下，上游一次都没被打
    assert transport.calls_for("schema-openai") == 1


# ---------------------------------------------------------------- 场景 5
def test_prompt_version_is_immutable_and_checksum_reproducible(tmp_path) -> None:
    """清单 5：已发布版本不可变；checksum 可由内容复现，并随响应回显。"""

    store = SQLiteStore(tmp_path / "prompts.sqlite3")
    transport = ScriptedTransport().script("deepseek-v4-pro", ok_text("已总结"))
    client = TestClient(build_app(transport, prompt_store=store))

    v1 = client.post(
        "/v1/prompts",
        json={
            "name": "greet",
            "content": "Hello {{ name }}!",
            "variables": [{"name": "name"}],
            "status": "active",
        },
    )
    assert v1.status_code == 201
    first = v1.json()
    assert first["version"] == 1 and first["checksum"].startswith("sha256:")

    v2 = client.post(
        "/v1/prompts", json={"name": "greet", "content": "Hi {{ name }}!"}
    )
    assert v2.status_code == 201 and v2.json()["version"] == 2

    # v1 内容与指纹不随新版本变化
    got = client.get("/v1/prompts/greet/1").json()
    assert got["content"] == "Hello {{ name }}!"
    assert got["checksum"] == first["checksum"]

    # 同样的内容再次入库 → checksum 完全一致（可复现）
    again = client.post(
        "/v1/prompts",
        json={"name": "digest", "content": "Hello {{ name }}!", "variables": []},
    )
    assert again.status_code == 201
    assert again.json()["checksum"] == first["checksum"]

    rendered = client.post(
        "/v1/prompts/greet/render", json={"version": 1, "variables": {"name": "Bob"}}
    )
    assert rendered.status_code == 200
    assert rendered.json()["rendered"] == "Hello Bob!"

    missing = client.post("/v1/prompts/greet/render", json={"version": 1, "variables": {}})
    assert missing.status_code == 400
    assert missing.json()["error"]["code"] == "MISSING_VARIABLE"

    reply = client.post(
        CHAT,
        json=chat_payload(
            "deepseek-v4-pro", prompt_ref={"name": "greet", "version": 1},
            variables={"name": "Bob"},
        ),
    )
    assert reply.status_code == 200
    assert reply.json()["prompt"]["checksum"] == first["checksum"]


# ---------------------------------------------------------------- 场景 6
def test_errors_share_one_unified_body() -> None:
    """清单 6：所有错误都是 `code` / `type` / `retryable` / `request_id` 的统一形状。"""

    models = default_models()
    models["up-400"] = extra_model("up-400")
    transport = ScriptedTransport().script("up-400", error_reply(400, "bad upstream"))
    client = TestClient(build_app(transport, models=models))

    unknown = client.post(CHAT, json=chat_payload("ghost"))
    assert unknown.status_code == 404
    body = unknown.json()["error"]
    assert body["code"] == "MODEL_NOT_FOUND"
    assert body["type"] == "not_found"
    assert body["retryable"] is False
    assert body["request_id"] == unknown.headers["X-Request-Id"]

    invalid = client.post(CHAT, json={"model": "deepseek-v4-pro"})
    assert invalid.status_code == 400
    invalid_body = invalid.json()["error"]
    assert invalid_body["code"] == "INVALID_REQUEST"
    assert set(invalid_body) >= {"code", "message", "type", "request_id", "retryable"}

    upstream = client.post(CHAT, json=chat_payload("up-400"))
    assert upstream.status_code == 400
    up_body = upstream.json()["error"]
    assert up_body["code"] == "UPSTREAM_BAD_REQUEST"
    assert up_body["details"]["upstream_status"] == 400


# ---------------------------------------------------------------- 场景 7
def test_retry_whitelist_and_no_retry_after_stream_started() -> None:
    """清单 7：最多 3 次尝试；400 不重试；已开流不重试。"""

    models = default_models()
    models["flaky-529"] = extra_model("flaky-529")
    models["flaky-stream"] = extra_model("flaky-stream")
    models["hard-400"] = extra_model("hard-400")
    models["cut-stream"] = extra_model("cut-stream", adapter="anthropic_messages")
    transport = (
        ScriptedTransport()
        .script("flaky-529", error_reply(529), error_reply(529), ok_text("重试成功"))
        .script("flaky-stream", error_reply(529), ok_sse(OPENAI_SSE))
        .script("hard-400", error_reply(400, "bad request"))
        .script("cut-stream", ok_sse(truncated_anthropic_sse()))
    )
    client = TestClient(build_app(transport, models=models))

    retried = client.post(CHAT, json=chat_payload("flaky-529"))
    assert retried.status_code == 200
    assert retried.json()["text"] == "重试成功"
    assert transport.calls_for("flaky-529") == 3
    assert retried.json()["latency"]["retry_overhead_ms"] is not None

    hard = client.post(CHAT, json=chat_payload("hard-400"))
    assert hard.status_code == 400
    assert transport.calls_for("hard-400") == 1

    # 开流前失败可以重试，且客户端只看到一份完整 delta
    stream_retried = client.post(CHAT, json=chat_payload("flaky-stream", stream=True))
    assert stream_retried.status_code == 200
    frames = sse_data_frames(stream_retried.text)
    assert sse_deltas(frames) == "你好，我是网关。"
    assert transport.calls_for("flaky-stream") == 2

    # 已吐出 delta 后断流 → 不重试，客户端收到 error 事件
    cut = client.post(CHAT, json=chat_payload("cut-stream", stream=True))
    assert cut.status_code == 200
    error = error_frame(sse_data_frames(cut.text))
    assert error["code"] == "STREAM_INTERRUPTED"
    assert transport.calls_for("cut-stream") == 1


# ---------------------------------------------------------------- 场景 8
def test_rate_limit_isolation_between_models() -> None:
    """清单 8：flash 打满只影响自己，pro 同时照常 200。"""

    models = default_models()
    models["limit-flash"] = extra_model(
        "limit-flash",
        adapter="anthropic_messages",
        limits=RouteLimits(rpm=1, tpm=2_000_000, concurrent=8),
    )
    models["limit-pro"] = extra_model(
        "limit-pro", limits=RouteLimits(rpm=100, tpm=2_000_000, concurrent=8)
    )
    transport = (
        ScriptedTransport()
        .script("limit-flash", ok_json(ANTHROPIC_RAW))
        .script("limit-pro", ok_json(OPENAI_RAW))
    )
    limiter = MemoryRateLimiter()
    client = TestClient(build_app(transport, models=models, limiter=limiter))

    first = client.post(CHAT, json=chat_payload("limit-flash"))
    assert first.status_code == 200

    second = client.post(CHAT, json=chat_payload("limit-flash"))
    assert second.status_code == 429
    assert second.json()["error"]["code"] == "RATE_LIMITED"
    assert second.json()["error"]["details"]["rate_limited_by"] == "rpm"
    assert int(second.headers["Retry-After"]) >= 1
    assert transport.calls_for("limit-flash") == 1  # 超限请求不触达上游

    pro = client.post(CHAT, json=chat_payload("limit-pro"))
    assert pro.status_code == 200
    assert pro.json()["text"] == "你好，我是网关。"


# ---------------------------------------------------------------- 场景 9
class EchoAdapter:
    """第三个「mock 厂商」适配器：只证明新适配器接入不改核心管线。"""

    name = "mock_echo"
    endpoint = "/v1/echo"

    def build_headers(self, route: ModelRoute) -> dict[str, str]:
        return {"content-type": "application/json"}

    def build_payload(self, req: CanonicalRequest, route: ModelRoute) -> dict:
        return {
            "model": route.upstream_model,
            "messages": [{"role": m.role.value, "content": m.content} for m in req.messages],
        }

    def parse_response(self, raw: dict, req: CanonicalRequest) -> CanonicalResponse:
        return CanonicalResponse(
            id=str(raw.get("id") or req.request_id),
            model=str(raw.get("model") or req.model),
            adapter=self.name,
            text=str(raw.get("text") or ""),
            finish_reason=FinishReason.STOP,
            usage=TokenUsage(input_tokens=1, output_tokens=1, source="reported"),
        )

    async def parse_sse(  # pragma: no cover - 该适配器不参与流式用例
        self, byte_stream: AsyncIterator[bytes]
    ) -> AsyncIterator[CanonicalEvent]:
        if False:
            yield CanonicalEvent(type="ping")

    def normalize_error(self, status: int, body: dict | None, exc: BaseException | None = None) -> GatewayError:
        return GatewayError(ErrorCode.UPSTREAM_BAD_RESPONSE, f"echo upstream error {status}")

    def capabilities(self, route: ModelRoute) -> ModelCapabilities:
        return {
            "max_context_tokens": 4096,
            "max_output_tokens": route.default_max_tokens,
            "supports_stream": False,
            "supports_json_schema": False,
            "supports_json_object": False,
            "supports_reasoning": False,
            "supports_prompt_caching": False,
        }


def test_new_mock_adapter_needs_zero_core_changes() -> None:
    """清单 10：注册一个第三方适配器 + 一条路由即可跑通，核心代码零改动。"""

    models = default_models()
    models["mock-echo"] = ModelRoute(
        adapter="mock_echo",
        upstream_model="echo-model",
        base_url="https://echo.local",
        api_key_env="DEEPSEEK_PRO_API_KEY",
        default_max_tokens=4096,
    )
    transport = ScriptedTransport().script(
        "echo-model", ok_json({"id": "echo_1", "model": "echo-model", "text": "echo: 讲个故事"})
    )
    app = build_app(transport, models=models)
    app.state.gateway.adapters.register(EchoAdapter())
    client = TestClient(app)

    reply = client.post(CHAT, json=chat_payload("mock-echo"))
    assert reply.status_code == 200
    assert reply.json()["adapter"] == "mock_echo"
    assert reply.json()["text"] == "echo: 讲个故事"

    listed = client.get("/v1/models").json()["data"]
    assert "mock-echo" in {item["id"] for item in listed}


# ---------------------------------------------------------------- 场景 10
class TrackingByteStream(httpx.AsyncByteStream):
    """记录是否被关闭的假上游流。"""

    def __init__(self, chunks: list[bytes]) -> None:
        self.chunks = chunks
        self.closed = False

    async def __aiter__(self) -> AsyncIterator[bytes]:
        for chunk in self.chunks:
            yield chunk

    async def aclose(self) -> None:
        self.closed = True


class TrackingTransport:
    """只实现 stream 的传输桩，用于客户端断开用例。"""

    def __init__(self) -> None:
        self.stream_obj: TrackingByteStream | None = None

    async def post(self, url, payload, headers, route):  # pragma: no cover
        raise AssertionError("disconnect test only streams")

    async def stream(self, url, payload, headers, route):
        half = len(ANTHROPIC_SSE) // 2
        self.stream_obj = TrackingByteStream([ANTHROPIC_SSE[:half], ANTHROPIC_SSE[half:]])
        return httpx.Response(
            200, stream=self.stream_obj, headers={"content-type": "text/event-stream"}
        )


@pytest.mark.anyio
async def test_client_disconnect_releases_upstream_stream() -> None:
    """故障注入：客户端中途断开 → 上游连接立即释放，且不产生成功样本。"""

    app = build_app(TrackingTransport())  # type: ignore[arg-type]
    gateway = app.state.gateway
    req = CanonicalRequest(
        request_id="req_disconnect",
        model="deepseek-v4-flash",
        messages=[CanonicalMessage(role=Role.USER, content="讲个故事")],
        stream=True,
    )
    ctx = CallContext(request_id=req.request_id)
    prepared = gateway.prepare(req)
    frames = stream_frames(gateway, req, ctx, app.state.settings, prepared)

    first = await frames.__anext__()
    assert b"chat.completion.chunk" in first
    await frames.aclose()

    transport: TrackingTransport = app.state.gateway.transport  # type: ignore[assignment]
    assert ctx.client_aborted is True
    assert transport.stream_obj is not None and transport.stream_obj.closed is True
