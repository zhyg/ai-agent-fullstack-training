"""Stage 7 故障注入夹具：可脚本化的假上游 + 统一的 app 构建器。

设计目标：
- 故障（超时 / 529 / 流中断 / 400 / 无终态）用「按上游模型排队回复」表达，
  测试只描述剧本，不关心 httpx 细节；
- app 构建统一注入小退避、零排队等待，保证 e2e 用例毫秒级完成。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI

from gateway.config import LimitsSettings, PromptSettings, RetrySettings, Settings
from gateway.core.router import ModelRoute, RouteLimits, RouteTable, Router
from gateway.prompt.store import PromptStore, SQLiteStore
from gateway.main import create_app

FIXTURES = Path(__file__).parent.parent / "adapters" / "fixtures"
OPENAI_RAW = json.loads((FIXTURES / "openai_response.json").read_text(encoding="utf-8"))
ANTHROPIC_RAW = json.loads(
    (FIXTURES / "anthropic_response.json").read_text(encoding="utf-8")
)
OPENAI_SSE = (FIXTURES / "openai_stream.sse").read_bytes()
ANTHROPIC_SSE = (FIXTURES / "anthropic_stream.sse").read_bytes()


@dataclass(frozen=True)
class Reply:
    """一次上游调用的回复；`error` 非空表示直接抛网络异常。"""

    status: int = 200
    json_body: Any | None = None
    sse_body: bytes | None = None
    error: BaseException | None = None
    headers: dict[str, str] | None = None

    def to_response(self) -> httpx.Response:
        headers = dict(self.headers or {})
        if self.sse_body is not None:
            headers.setdefault("content-type", "text/event-stream")
            return httpx.Response(self.status, content=self.sse_body, headers=headers)
        return httpx.Response(self.status, json=self.json_body, headers=headers)


def ok_json(raw: dict) -> Reply:
    return Reply(json_body=raw)


def ok_text(text: str) -> Reply:
    """OpenAI Responses 形状的纯文本回复。"""

    return Reply(
        json_body={
            "id": "resp_e2e",
            "model": "mock",
            "status": "completed",
            "output": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": text}],
                }
            ],
            "usage": {"input_tokens": 12, "output_tokens": 8},
        }
    )


def ok_sse(body: bytes | None = None) -> Reply:
    return Reply(sse_body=OPENAI_SSE if body is None else body)


def error_reply(
    status: int, message: str = "upstream unavailable", headers: dict[str, str] | None = None
) -> Reply:
    return Reply(status=status, json_body={"error": {"message": message}}, headers=headers)


def timeout_reply() -> Reply:
    return Reply(error=httpx.ReadTimeout("scripted read timeout"))


def sse_frames(frames: list[tuple[str, dict]]) -> bytes:
    """把 (event, data) 组装成 SSE 字节流，便于构造截断/错误剧本。"""

    return "".join(
        f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"
        for event, payload in frames
    )


def truncated_anthropic_sse(text: str = "半截") -> bytes:
    """吐出一个 delta 后立刻结束（无 message_stop）：验证「开流后不重试」。"""

    return sse_frames(
        [
            (
                "message_start",
                {"type": "message_start", "message": {"id": "msg_cut", "usage": {"input_tokens": 12}}},
            ),
            (
                "content_block_delta",
                {"type": "content_block_delta", "index": 0,
                 "delta": {"type": "text_delta", "text": text}},
            ),
        ]
    )


def upstream_error_sse(message: str = "upstream overloaded") -> bytes:
    """上游在流内发 error 事件（协议内错误，不是 HTTP 错误）。"""

    return sse_frames(
        [
            (
                "message_start",
                {"type": "message_start", "message": {"id": "msg_err", "usage": {"input_tokens": 12}}},
            ),
            ("error", {"type": "error", "error": {"type": "overloaded_error", "message": message}}),
        ]
    )


class ScriptedTransport:
    """按 `route.upstream_model` 排队回复的假上游。

    队列只剩最后一条时会被重复使用：既能表达「前 N 次失败、之后成功」，
    也能表达「一直成功」。所有调用都被记录，用于断言重试次数。
    """

    def __init__(self) -> None:
        self.scripts: dict[str, list[Reply]] = {}
        self.calls: list[dict[str, Any]] = []

    def script(self, upstream_model: str, *replies: Reply) -> "ScriptedTransport":
        if not replies:
            raise ValueError("at least one reply is required")
        self.scripts[upstream_model] = list(replies)
        return self

    def calls_for(self, upstream_model: str) -> int:
        return sum(1 for call in self.calls if call["upstream_model"] == upstream_model)

    def _reply_for(self, route: ModelRoute, payload: dict, kind: str) -> httpx.Response:
        self.calls.append(
            {"upstream_model": route.upstream_model, "payload": payload, "kind": kind}
        )
        queue = self.scripts.get(route.upstream_model)
        if not queue:
            return error_reply(500, f"no script for '{route.upstream_model}'").to_response()
        reply = queue.pop(0) if len(queue) > 1 else queue[0]
        if reply.error is not None:
            raise reply.error
        return reply.to_response()

    async def post(self, url, payload, headers, route) -> httpx.Response:  # noqa: ANN001
        return self._reply_for(route, payload, "post")

    async def stream(self, url, payload, headers, route) -> httpx.Response:  # noqa: ANN001
        return self._reply_for(route, payload, "stream")


def default_models() -> dict[str, ModelRoute]:
    """两份基础路由：OpenAI 协议与 Anthropic 协议各一条。"""

    return {
        "deepseek-v4-pro": ModelRoute(
            adapter="openai_responses",
            upstream_model="deepseek-v4-pro",
            base_url="https://mock.local",
            api_key_env="DEEPSEEK_PRO_API_KEY",
            default_max_tokens=8192,
            limits=RouteLimits(rpm=60, tpm=200000, concurrent=8),
        ),
        "deepseek-v4-flash": ModelRoute(
            adapter="anthropic_messages",
            upstream_model="deepseek-v4-flash",
            base_url="https://mock.local",
            api_key_env="DEEPSEEK_FLASH_API_KEY",
            default_max_tokens=4096,
            limits=RouteLimits(rpm=600, tpm=2000000, concurrent=64),
        ),
    }


def make_settings() -> Settings:
    """e2e 默认配置：退避 1ms、排队 0ms，保证用例快且确定性。"""

    return Settings(
        debug=True,
        logging={"sample_rate": 1.0},
        retry=RetrySettings(max_attempts=3, base_delay_ms=1, max_delay_ms=2),
        limits=LimitsSettings(max_queue_wait_ms=0),
        prompt=PromptSettings(db_path=":memory:"),
    )


def build_app(
    transport: ScriptedTransport,
    *,
    models: dict[str, ModelRoute] | None = None,
    limiter: Any | None = None,
    prompt_store: PromptStore | None = None,
    settings: Settings | None = None,
) -> FastAPI:
    """构建被测 app；路由表经 `RouteTable` 回填 model 名（限流桶按名分桶）。"""

    table = RouteTable(models=models or default_models())
    return create_app(
        settings or make_settings(),
        router=Router(table.models),
        transport=transport,
        prompt_store=prompt_store or SQLiteStore(":memory:"),
        limiter=limiter,
    )
