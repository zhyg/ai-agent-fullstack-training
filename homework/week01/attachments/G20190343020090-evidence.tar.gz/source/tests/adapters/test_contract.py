"""Stage 1 契约测试：同一份 IR 在两个适配器上的翻译与归一化。"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import respx
from fastapi.testclient import TestClient

from gateway.adapters.anthropic_messages import AnthropicMessagesAdapter
from gateway.adapters.openai_responses import OpenAIResponsesAdapter
from gateway.adapters.registry import AdapterRegistry
from gateway.config import Settings
from gateway.core.adapter import ModelCapabilities
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.invoker import Gateway
from gateway.core.ir import (
    CallContext,
    CanonicalMessage,
    CanonicalRequest,
    CanonicalResponse,
    FinishReason,
    Role,
    TokenUsage,
)
from gateway.core.router import ModelRoute, Router
from gateway.httpclient.pool import HttpClientPool
from gateway.main import create_app

FIXTURES = Path(__file__).parent / "fixtures"
OPENAI_RAW = json.loads((FIXTURES / "openai_response.json").read_text(encoding="utf-8"))
ANTHROPIC_RAW = json.loads((FIXTURES / "anthropic_response.json").read_text(encoding="utf-8"))


def make_request(**overrides) -> CanonicalRequest:
    data = {
        "request_id": "req_contract",
        "model": "deepseek-v4-flash",
        "messages": [
            CanonicalMessage(role=Role.SYSTEM, content="你是简洁的助手"),
            CanonicalMessage(role=Role.USER, content="讲个笑话"),
        ],
        "system": "顶层 system",
    }
    data.update(overrides)
    return CanonicalRequest(**data)


class FakeTransport:
    def __init__(self, response: httpx.Response) -> None:
        self.response = response
        self.calls: list[tuple[str, dict, dict]] = []

    async def post(self, url, payload, headers, route):
        self.calls.append((url, payload, headers))
        return self.response


def test_same_ir_translates_to_both_protocols() -> None:
    router = Router.from_file()
    openai_route = router.resolve("deepseek-v4-pro")
    anthropic_route = router.resolve("deepseek-v4-flash")
    req = make_request(max_output_tokens=100, stop=["END"], temperature=0.3)

    openai_payload = OpenAIResponsesAdapter().build_payload(req, openai_route)
    assert openai_payload["model"] == "deepseek-v4-pro"
    assert openai_payload["input"][0]["content"][0]["type"] == "input_text"
    assert openai_payload["instructions"] == "顶层 system"
    assert openai_payload["max_output_tokens"] == 100
    assert openai_payload["stop"] == ["END"]
    assert openai_payload["temperature"] == 0.3

    anthropic_payload = AnthropicMessagesAdapter().build_payload(req, anthropic_route)
    # 网关别名 → DeepSeek 真实模型 id 的映射（配置见 config/routes.yaml）
    assert anthropic_payload["model"] == "deepseek-flash"
    assert anthropic_payload["max_tokens"] == 100
    # system 消息被提升到顶层，且与请求级 system 合并
    assert anthropic_payload["system"] == "顶层 system\n\n你是简洁的助手"
    assert [m["role"] for m in anthropic_payload["messages"]] == ["user"]
    assert anthropic_payload["stop_sequences"] == ["END"]


def test_anthropic_max_tokens_falls_back_to_route_default() -> None:
    router = Router.from_file()
    route = router.resolve("deepseek-v4-flash")
    payload = AnthropicMessagesAdapter().build_payload(make_request(), route)
    assert payload["max_tokens"] == route.default_max_tokens


def test_openai_response_normalizes() -> None:
    response = OpenAIResponsesAdapter().parse_response(OPENAI_RAW, make_request())
    assert response.text == "你好，我是网关。"
    assert response.finish_reason == FinishReason.STOP
    assert response.adapter == "openai_responses"
    assert response.usage.input_tokens == 12
    assert response.usage.output_tokens == 8
    assert response.usage.cache_read_tokens == 4
    assert response.usage.reasoning_tokens == 2
    assert response.usage.source == "reported"


def test_anthropic_response_normalizes() -> None:
    response = AnthropicMessagesAdapter().parse_response(ANTHROPIC_RAW, make_request())
    assert response.text == "你好，我是网关。"
    assert response.finish_reason == FinishReason.STOP
    assert response.adapter == "anthropic_messages"
    assert response.usage.input_tokens == 12
    assert response.usage.output_tokens == 8
    assert response.usage.cache_read_tokens == 4
    assert response.usage.cache_write_tokens == 10


@pytest.mark.parametrize(
    "adapter,status,body,exc,expected_code,expected_retryable",
    [
        (OpenAIResponsesAdapter(), 401, None, None, ErrorCode.UPSTREAM_AUTH, False),
        (AnthropicMessagesAdapter(), 401, None, None, ErrorCode.UPSTREAM_AUTH, False),
        (OpenAIResponsesAdapter(), 400, {"error": {"message": "bad request"}}, None, ErrorCode.UPSTREAM_BAD_REQUEST, False),
        (
            OpenAIResponsesAdapter(),
            400,
            {"error": {"message": "This model's maximum context length is 8192 tokens"}},
            None,
            ErrorCode.CONTEXT_LENGTH_EXCEEDED,
            False,
        ),
        (
            AnthropicMessagesAdapter(),
            400,
            {"error": {"type": "invalid_request_error", "message": "prompt is too long: 300000 tokens"}},
            None,
            ErrorCode.CONTEXT_LENGTH_EXCEEDED,
            False,
        ),
        (OpenAIResponsesAdapter(), 429, None, None, ErrorCode.UPSTREAM_UNAVAILABLE, True),
        (AnthropicMessagesAdapter(), 529, None, None, ErrorCode.UPSTREAM_UNAVAILABLE, True),
        (OpenAIResponsesAdapter(), 500, None, None, ErrorCode.UPSTREAM_UNAVAILABLE, True),
        (OpenAIResponsesAdapter(), 0, None, httpx.ConnectError("refused"), ErrorCode.UPSTREAM_UNAVAILABLE, True),
        (AnthropicMessagesAdapter(), 0, None, httpx.ReadTimeout("slow"), ErrorCode.UPSTREAM_TIMEOUT, True),
    ],
)
def test_upstream_errors_normalize(adapter, status, body, exc, expected_code, expected_retryable) -> None:
    error = adapter.normalize_error(status, body, exc)
    assert error.code == expected_code.value
    assert error.retryable is expected_retryable


def test_router_unknown_model_lists_available() -> None:
    router = Router.from_file()
    with pytest.raises(GatewayError) as excinfo:
        router.resolve("gpt-4o")
    assert excinfo.value.status_code == 404
    assert "deepseek-v4-pro" in excinfo.value.message


@pytest.mark.anyio
@respx.mock
async def test_gateway_complete_calls_upstream(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "test-pro-key")
    upstream = respx.post("https://api.deepseek.com/v1/responses").mock(
        return_value=httpx.Response(200, json=OPENAI_RAW)
    )
    pool = HttpClientPool()
    await pool.startup()
    gateway = Gateway(Router.from_file(), AdapterRegistry.default(), pool, Settings())
    try:
        response = await gateway.complete(
            make_request(model="deepseek-v4-pro"), CallContext(request_id="req_contract")
        )
    finally:
        await pool.aclose()

    assert upstream.called
    assert response.text == "你好，我是网关。"
    assert response.latency.total_ms is not None
    request = upstream.calls[0].request
    assert request.headers["Authorization"] == "Bearer test-pro-key"
    sent = json.loads(request.content)
    assert sent["model"] == "deepseek-v4-pro"
    assert sent["max_output_tokens"] == 8192


def test_api_chat_uses_injected_transport(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "test-flash-key")
    transport = FakeTransport(httpx.Response(200, json=ANTHROPIC_RAW))
    app = create_app(Settings(debug=False), transport=transport)
    with TestClient(app) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "hi"}],
            },
        )
    assert response.status_code == 200
    body = response.json()
    assert body["text"] == "你好，我是网关。"
    assert body["finish_reason"] == "stop"
    url, payload, headers = transport.calls[0]
    assert url == "https://api.deepseek.com/anthropic/v1/messages"
    assert headers["x-api-key"] == "test-flash-key"
    assert headers["anthropic-version"] == "2023-06-01"
    assert payload["messages"] == [{"role": "user", "content": "hi"}]


def test_api_models_lists_routes() -> None:
    app = create_app(Settings(debug=False), transport=FakeTransport(httpx.Response(200, json={}) ))
    with TestClient(app) as client:
        response = client.get("/v1/models")
    assert response.status_code == 200
    data = response.json()["data"]
    assert {item["id"] for item in data} == {"deepseek-v4-pro", "deepseek-v4-flash"}
    pro = next(item for item in data if item["id"] == "deepseek-v4-pro")
    assert pro["capabilities"]["supports_json_schema"] is True


class MockAdapter:
    """第三个厂商适配器：只实现 Protocol，不碰 core/ 与 api/。"""

    name = "mock"
    endpoint = "/mock"

    def build_payload(self, req: CanonicalRequest, route: ModelRoute) -> dict:
        return {"echo": req.messages[-1].content, "max": route.default_max_tokens}

    def build_headers(self, route: ModelRoute) -> dict:
        return {"X-Mock": "1"}

    def parse_response(self, raw: dict, req: CanonicalRequest) -> CanonicalResponse:
        return CanonicalResponse(
            id=str(raw["id"]),
            model=str(raw["model"]),
            adapter=self.name,
            text=str(raw["text"]),
            finish_reason=FinishReason.STOP,
            usage=TokenUsage(input_tokens=int(raw["in"]), output_tokens=int(raw["out"]),
                             source="reported"),
        )

    def parse_sse(self, byte_stream):
        raise NotImplementedError

    def normalize_error(self, status: int, body: dict | None, exc=None) -> GatewayError:
        return GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "mock failed")

    def capabilities(self, route: ModelRoute) -> ModelCapabilities:
        return {
            "max_context_tokens": 1000,
            "max_output_tokens": 100,
            "supports_stream": False,
            "supports_json_schema": False,
            "supports_json_object": False,
            "supports_reasoning": False,
            "supports_prompt_caching": False,
        }


@pytest.mark.anyio
async def test_third_adapter_needs_no_core_changes() -> None:
    route = ModelRoute(
        model="mock-model",
        adapter="mock",
        upstream_model="mock-upstream",
        base_url="https://mock.local",
        api_key_env="MOCK_API_KEY",
        default_max_tokens=100,
    )
    gateway = Gateway(
        Router({"mock-model": route}),
        AdapterRegistry({"mock": MockAdapter()}),
        FakeTransport(httpx.Response(200, json={
            "id": "mock_1", "model": "mock-upstream", "text": "mock-ok", "in": 1, "out": 2,
        })),
    )
    response = await gateway.complete(
        CanonicalRequest(
            request_id="req_mock",
            model="mock-model",
            messages=[CanonicalMessage(role=Role.USER, content="ping")],
        )
    )
    assert response.text == "mock-ok"
    assert response.usage.total_tokens == 3
