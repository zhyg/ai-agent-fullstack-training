"""Stage 4 提示词版本管理测试：存储不变性、版本解析、渲染、缓存与管理 API。"""

from __future__ import annotations

import json
import time
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient
from structlog.testing import capture_logs

from gateway.config import Settings
from gateway.core.errors import ErrorCode, GatewayError
from gateway.main import create_app
from gateway.prompt.models import checksum_of
from gateway.prompt.resolver import PromptRef, PromptResolver
from gateway.prompt.store import SQLiteStore

ISSUE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {"title": {"type": "string"}, "priority": {"type": "integer"}},
    "required": ["title", "priority"],
    "additionalProperties": False,
}
VALID_JSON_TEXT = '{"title": "网关超时", "priority": 2}'


@pytest.fixture
def store(tmp_path) -> SQLiteStore:
    return SQLiteStore(tmp_path / "prompts.sqlite3")


@pytest.fixture
def resolver(store: SQLiteStore) -> PromptResolver:
    return PromptResolver(store, cache_size=256, cache_ttl_s=60)


def seed(
    store: SQLiteStore,
    *,
    name: str = "summarize",
    content: str = "请总结：{{ text }}",
    status: str = "draft",
    response_schema: dict[str, Any] | None = None,
) -> Any:
    return store.create(
        name=name,
        content=content,
        variables=[{"name": "text", "required": True, "default": None}],
        status=status,
        response_schema=response_schema,
        created_by="tester",
    )


# ---------------------------------------------------------------- 存储


def test_create_assigns_monotonic_version_and_checksum(store: SQLiteStore) -> None:
    first = seed(store, content="v1")
    second = seed(store, content="v2")

    assert first.version == 1
    assert second.version == 2
    assert second.checksum == checksum_of("v2")
    assert first.status == "draft"


def test_published_version_is_immutable(store: SQLiteStore) -> None:
    template = seed(store, content="v1")
    # draft 可以改
    updated = store.update_content("summarize", 1, content="v1-draft")
    assert updated.content == "v1-draft"
    # 发布后禁止修改内容，只允许生成新版本
    store.activate("summarize", 1)
    with pytest.raises(GatewayError) as excinfo:
        store.update_content("summarize", 1, content="tampered")
    assert excinfo.value.code == ErrorCode.INVALID_REQUEST.value
    assert "immutable" in excinfo.value.message


def test_checksum_can_reverse_lookup_template(store: SQLiteStore) -> None:
    """DoD：日志里的 checksum 能反查出确切模板内容。"""

    template = seed(store, content="请总结：{{ text }}")
    found = store.find_by_checksum(template.checksum)

    assert found is not None
    assert found.version == template.version
    assert found.content == template.content
    assert checksum_of(found.content) == template.checksum


def test_activate_keeps_single_active_pointer(store: SQLiteStore) -> None:
    seed(store, content="v1", status="active")
    seed(store, content="v2")

    active = store.activate("summarize", 2)
    assert active.status == "active"
    assert store.get("summarize", 1).status == "deprecated"
    assert store.get_active("summarize").version == 2


# ---------------------------------------------------------------- 版本引用


def test_parse_all_reference_forms() -> None:
    assert PromptRef.parse("summarize@3") == PromptRef("summarize", "3")
    assert PromptRef.parse({"name": "summarize", "version": "latest"}).version == "latest"
    assert PromptRef.parse({"name": "summarize", "version": 3}).version == "3"
    assert PromptRef.parse({"name": "summarize"}).version == "latest"


def test_parse_rejects_bad_reference() -> None:
    with pytest.raises(GatewayError) as excinfo:
        PromptRef.parse({"name": "summarize", "version": "foo"})
    assert excinfo.value.code == ErrorCode.INVALID_REQUEST.value


def test_resolve_latest_active_and_exact(resolver: PromptResolver, store: SQLiteStore) -> None:
    seed(store, content="v1", status="active")
    seed(store, content="v2")

    assert resolver.resolve(PromptRef("summarize", "latest")).version == 2
    assert resolver.resolve(PromptRef("summarize", "active")).version == 1
    assert resolver.resolve(PromptRef("summarize", "1")).version == 1


def test_resolve_not_found_lists_available_versions(
    resolver: PromptResolver, store: SQLiteStore
) -> None:
    seed(store, content="v1")
    seed(store, content="v2", status="active")

    with pytest.raises(GatewayError) as excinfo:
        resolver.resolve(PromptRef("summarize", "9"))

    error = excinfo.value
    assert error.code == ErrorCode.PROMPT_NOT_FOUND.value
    assert "available versions: [1, 2]" in error.message
    assert "active: 2" in error.message
    assert error.details["available_versions"] == [1, 2]


# ---------------------------------------------------------------- 渲染


def test_render_substitutes_variables(resolver: PromptResolver, store: SQLiteStore) -> None:
    seed(store)
    rendered = resolver.render(PromptRef("summarize"), {"text": "网关超时"})

    assert rendered.text == "请总结：网关超时"
    assert rendered.echo["name"] == "summarize"
    assert rendered.echo["version"] == 1


def test_render_missing_required_variable(resolver: PromptResolver, store: SQLiteStore) -> None:
    seed(store)
    with pytest.raises(GatewayError) as excinfo:
        resolver.render(PromptRef("summarize"), {})

    error = excinfo.value
    assert error.code == ErrorCode.MISSING_VARIABLE.value
    assert error.details["missing_variables"] == ["text"]


def test_render_uses_declared_default(resolver: PromptResolver, store: SQLiteStore) -> None:
    store.create(
        name="greet",
        content="你好 {{ name }}{{ suffix }}",
        variables=[
            {"name": "name", "required": True},
            {"name": "suffix", "required": False, "default": "先生"},
        ],
        status="active",
    )
    rendered = resolver.render(PromptRef("greet"), {"name": "张三"})

    assert rendered.text == "你好 张三先生"


def test_render_ignores_and_warns_undeclared_variables(
    resolver: PromptResolver, store: SQLiteStore
) -> None:
    seed(store)
    with capture_logs() as logs:
        rendered = resolver.render(
            PromptRef("summarize"), {"text": "x", "txet": "拼写错误"}
        )

    assert rendered.text == "请总结：x"
    assert rendered.ignored_variables == ("txet",)
    assert any(entry["event"] == "prompt.variables_ignored" for entry in logs)


def test_render_blocks_sandbox_escape(resolver: PromptResolver, store: SQLiteStore) -> None:
    # 沙箱对下划线属性返回 UnsafeUndefined；一旦调用即抛 SecurityError
    seed(store, content="{{ text.__class__() }}")
    with pytest.raises(GatewayError) as excinfo:
        resolver.render(PromptRef("summarize"), {"text": "x"})
    assert excinfo.value.code == ErrorCode.INVALID_REQUEST.value
    assert "sandbox" in excinfo.value.message


def test_render_reports_invalid_template(resolver: PromptResolver, store: SQLiteStore) -> None:
    seed(store, content="{% if text %}")
    with pytest.raises(GatewayError) as excinfo:
        resolver.render(PromptRef("summarize"), {"text": "x"})
    assert excinfo.value.code == ErrorCode.INVALID_REQUEST.value


# ---------------------------------------------------------------- 缓存


class CountingStore(SQLiteStore):
    """统计读取次数，验证缓存命中/失效。"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.reads = 0

    def get_latest(self, name: str):
        self.reads += 1
        return super().get_latest(name)

    def get_active(self, name: str):
        self.reads += 1
        return super().get_active(name)


def test_cache_hit_avoids_store_read(tmp_path) -> None:
    store = CountingStore(tmp_path / "cache.sqlite3")
    seed(store)
    resolver = PromptResolver(store, cache_size=2, cache_ttl_s=60)

    resolver.resolve(PromptRef("summarize"))
    resolver.resolve(PromptRef("summarize"))

    assert store.reads == 1


def test_cache_ttl_expiry(tmp_path) -> None:
    store = CountingStore(tmp_path / "cache.sqlite3")
    seed(store)
    resolver = PromptResolver(store, cache_size=2, cache_ttl_s=0.05)

    resolver.resolve(PromptRef("summarize"))
    time.sleep(0.08)
    resolver.resolve(PromptRef("summarize"))

    assert store.reads == 2


def test_cache_lru_eviction(tmp_path) -> None:
    store = CountingStore(tmp_path / "cache.sqlite3")
    for name in ("a", "b", "c"):
        seed(store, name=name, content=f"{name}: {{{{ text }}}}")
    resolver = PromptResolver(store, cache_size=2, cache_ttl_s=60)

    resolver.resolve(PromptRef("a"))
    resolver.resolve(PromptRef("b"))
    resolver.resolve(PromptRef("c"))  # 淘汰 a
    resolver.resolve(PromptRef("a"))

    assert store.reads == 4


def test_activate_invalidates_active_cache(tmp_path) -> None:
    store = CountingStore(tmp_path / "cache.sqlite3")
    seed(store, content="v1", status="active")
    seed(store, content="v2")
    resolver = PromptResolver(store, cache_size=2, cache_ttl_s=60)

    assert resolver.resolve(PromptRef("summarize", "active")).version == 1
    resolver.activate("summarize", 2)  # 主动失效
    assert resolver.resolve(PromptRef("summarize", "active")).version == 2


# ---------------------------------------------------------------- 管理 API


class ScriptedTransport:
    def __init__(self, responses: list[httpx.Response]) -> None:
        self.responses = list(responses)
        self.calls: list[tuple[str, dict, dict]] = []

    async def post(self, url, payload, headers, route):
        self.calls.append((url, payload, headers))
        return self.responses.pop(0)


def _app(transport: Any, store: SQLiteStore) -> TestClient:
    return TestClient(create_app(Settings(debug=True), transport=transport, prompt_store=store))


def test_api_create_list_and_activate(store: SQLiteStore) -> None:
    with _app(ScriptedTransport([]), store) as client:
        first = client.post(
            "/v1/prompts",
            json={"name": "summarize", "content": "v1: {{ text }}", "variables": [{"name": "text"}]},
        )
        second = client.post(
            "/v1/prompts",
            json={"name": "summarize", "content": "v2: {{ text }}"},
        )
        listing = client.get("/v1/prompts")
        detail = client.get("/v1/prompts/summarize")
        version = client.get("/v1/prompts/summarize/1")
        activated = client.post("/v1/prompts/summarize/2/activate")

    assert first.status_code == 201
    assert first.json()["version"] == 1
    assert first.json()["status"] == "draft"
    assert second.status_code == 201
    assert second.json()["version"] == 2

    data = listing.json()["data"]
    assert data[0]["name"] == "summarize"
    assert data[0]["versions"] == 2
    assert data[0]["active_version"] is None

    assert detail.json()["latest_version"] == 2
    assert [item["version"] for item in detail.json()["versions"]] == [1, 2]
    assert version.json()["content"] == "v1: {{ text }}"

    assert activated.json()["status"] == "active"
    assert store.get_active("summarize").version == 2


def test_api_render_is_dry_run(store: SQLiteStore) -> None:
    seed(store, status="active")
    transport = ScriptedTransport([])
    with _app(transport, store) as client:
        response = client.post(
            "/v1/prompts/summarize/render", json={"variables": {"text": "网关超时"}}
        )

    assert response.status_code == 200
    body = response.json()
    assert body["rendered"] == "请总结：网关超时"
    assert body["version"] == 1
    assert body["checksum"] == checksum_of("请总结：{{ text }}")
    assert transport.calls == []  # 干跑不调模型


def test_api_render_missing_variable(store: SQLiteStore) -> None:
    seed(store, status="active")
    with _app(ScriptedTransport([]), store) as client:
        response = client.post("/v1/prompts/summarize/render", json={"variables": {}})

    assert response.status_code == 400
    assert response.json()["error"]["code"] == ErrorCode.MISSING_VARIABLE.value


def test_api_rejects_incompatible_template_schema(store: SQLiteStore) -> None:
    bad_schema = {
        "type": "object",
        "properties": {"title": {"$ref": "#/$defs/title"}},
        "required": ["title"],
        "additionalProperties": False,
    }
    with _app(ScriptedTransport([]), store) as client:
        response = client.post(
            "/v1/prompts",
            json={"name": "bad", "content": "x", "response_schema": bad_schema},
        )

    assert response.status_code == 400
    assert response.json()["error"]["code"] == ErrorCode.SCHEMA_INCOMPATIBLE.value


def test_api_rejects_invalid_version_reference(store: SQLiteStore) -> None:
    seed(store, status="active")
    with _app(ScriptedTransport([]), store) as client:
        response = client.get("/v1/prompts/summarize/foo")

    assert response.status_code == 400
    assert response.json()["error"]["code"] == ErrorCode.INVALID_REQUEST.value


def test_api_unknown_prompt_returns_404(store: SQLiteStore) -> None:
    with _app(ScriptedTransport([]), store) as client:
        response = client.get("/v1/prompts/missing")

    assert response.status_code == 404
    assert response.json()["error"]["code"] == ErrorCode.PROMPT_NOT_FOUND.value


# ---------------------------------------------------------------- chat 集成


def openai_raw(text: str) -> dict[str, Any]:
    return {
        "id": "resp_prompt",
        "model": "deepseek-v4-pro",
        "status": "completed",
        "output": [
            {"type": "message", "content": [{"type": "output_text", "text": text}]}
        ],
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }


def test_chat_renders_prompt_and_appends_messages(
    monkeypatch: pytest.MonkeyPatch, store: SQLiteStore
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    seed(store, status="active")
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw("总结结果"))])

    with _app(transport, store) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "prompt_ref": {"name": "summarize", "version": "active"},
                "variables": {"text": "网关超时"},
                "messages": [{"role": "user", "content": "再压缩一半"}],
            },
        )

    assert response.status_code == 200
    payload = transport.calls[0][1]
    texts = [item["content"][0]["text"] for item in payload["input"]]
    assert texts == ["请总结：网关超时", "再压缩一半"]

    echo = response.json()["prompt"]
    assert echo == {
        "name": "summarize",
        "version": 1,
        "checksum": checksum_of("请总结：{{ text }}"),
    }
    # DoD：日志 checksum → 模板内容反查
    assert store.find_by_checksum(echo["checksum"]).content == "请总结：{{ text }}"


def test_chat_requires_messages_or_prompt_ref(store: SQLiteStore) -> None:
    with _app(ScriptedTransport([]), store) as client:
        response = client.post("/v1/chat", json={"model": "deepseek-v4-pro"})

    assert response.status_code == 400
    assert response.json()["error"]["code"] == ErrorCode.INVALID_REQUEST.value


def test_chat_missing_variable_fails_before_upstream(
    monkeypatch: pytest.MonkeyPatch, store: SQLiteStore
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    seed(store, status="active")
    transport = ScriptedTransport([])

    with _app(transport, store) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "prompt_ref": "summarize@1",
                "variables": {},
            },
        )

    assert response.status_code == 400
    assert response.json()["error"]["code"] == ErrorCode.MISSING_VARIABLE.value
    assert transport.calls == []


def test_chat_template_schema_links_to_structured_output(
    monkeypatch: pytest.MonkeyPatch, store: SQLiteStore
) -> None:
    """模板预置 response_schema：请求未显式指定时自动套用（Stage 3 联动）。"""

    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    seed(store, status="active", response_schema=ISSUE_SCHEMA)
    transport = ScriptedTransport([httpx.Response(200, json=openai_raw(VALID_JSON_TEXT))])

    with _app(transport, store) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "prompt_ref": {"name": "summarize"},
                "variables": {"text": "网关超时"},
            },
        )

    assert response.status_code == 200
    body = response.json()
    assert body["structured"] == {"title": "网关超时", "priority": 2}
    assert body["structured_mode"] == "native_schema"
    assert transport.calls[0][1]["text"]["format"]["name"] == "summarize"


def test_chat_stream_final_chunk_echoes_prompt(
    monkeypatch: pytest.MonkeyPatch, store: SQLiteStore
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    seed(store, status="active")

    def frame(payload: dict[str, Any]) -> str:
        return f"event: {payload['type']}\ndata: {json.dumps(payload)}\n\n"

    body = (
        frame({"type": "response.created"})
        + frame({"type": "response.output_text.delta", "delta": "总结结果"})
        + frame(
            {
                "type": "response.completed",
                "response": {"status": "completed", "usage": {"input_tokens": 10, "output_tokens": 5}},
            }
        )
    ).encode()

    class StreamTransport:
        def __init__(self) -> None:
            self.response = httpx.Response(
                200, content=body, headers={"content-type": "text/event-stream"}
            )

        async def post(self, url, payload, headers, route):  # pragma: no cover
            raise AssertionError("should stream")

        async def stream(self, url, payload, headers, route):
            return self.response

    with _app(StreamTransport(), store) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-pro",
                "prompt_ref": "summarize@1",
                "variables": {"text": "网关超时"},
                "stream": True,
            },
        )

    assert response.status_code == 200
    data = [
        item[len("data:"):].strip()
        for item in response.text.split("\n\n")
        if item.startswith("data:")
    ]
    chunks = [json.loads(item) for item in data[:-1]]
    assert chunks[-1]["prompt"] == {
        "name": "summarize",
        "version": 1,
        "checksum": checksum_of("请总结：{{ text }}"),
    }
