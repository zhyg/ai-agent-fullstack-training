"""Stage 5：Prometheus 指标、观测入口、日志采样与 `/metrics` 导出。"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from prometheus_client import CollectorRegistry

from gateway.config import Settings
from gateway.core.ir import CanonicalMessage, Latency, Role, TokenUsage
from gateway.core.router import ModelRoute, RoutePricing
from gateway.main import create_app
from gateway.telemetry.metrics import (
    STATUS_CLIENT_ABORTED,
    STATUS_ERROR,
    STATUS_OK,
    CallObservation,
    GatewayMetrics,
    observe_call,
    render_metrics,
    should_emit_log,
)


@pytest.fixture
def metrics() -> GatewayMetrics:
    """每个用例用独立 registry，避免全局指标互相污染。"""

    return GatewayMetrics(CollectorRegistry())


def make_route(pricing: RoutePricing | None = None) -> ModelRoute:
    return ModelRoute(
        model="deepseek-v4-flash",
        adapter="anthropic_messages",
        upstream_model="deepseek-v4-flash",
        base_url="http://upstream",
        api_key_env="TEST_KEY",
        pricing=pricing,
    )


def make_observation(**overrides) -> CallObservation:
    data = {
        "request_id": "req_obs",
        "model": "deepseek-v4-flash",
        "adapter": "anthropic_messages",
        "messages": [CanonicalMessage(role=Role.USER, content="你好")],
    }
    data.update(overrides)
    return CallObservation(**data)


def counter_value(metrics: GatewayMetrics, name: str, **labels: str) -> float:
    """从 registry 读样本值，避免依赖 prometheus_client 的私有属性。"""

    return sample_value(metrics, name, **labels)


def sample_value(metrics: GatewayMetrics, name: str, **labels: str) -> float:
    for family in metrics.registry.collect():
        for sample in family.samples:
            if sample.name != name:
                continue
            if all(sample.labels.get(key) == value for key, value in labels.items()):
                return sample.value
    raise AssertionError(f"metric sample not found: {name} {labels}")


def has_sample(metrics: GatewayMetrics, name: str, **labels: str) -> bool:
    for family in metrics.registry.collect():
        for sample in family.samples:
            if sample.name == name and all(
                sample.labels.get(key) == value for key, value in labels.items()
            ):
                return True
    return False


def test_observe_success_records_requests_tokens_and_latency(metrics: GatewayMetrics) -> None:
    usage = TokenUsage(
        input_tokens=128,
        output_tokens=42,
        reasoning_tokens=6,
        cache_read_tokens=64,
    )
    latency = Latency(total_ms=1980, ttft_ms=412, upstream_ttft_ms=87, tpot_ms=37.5)
    observe_call(
        metrics,
        make_observation(usage=usage, latency=latency, text="回答文本"),
        settings=Settings(logging={"sample_rate": 0.0}),
    )

    assert counter_value(
        metrics,
        "llm_requests_total",
        model="deepseek-v4-flash",
        adapter="anthropic_messages",
        status="ok",
    ) == 1
    assert counter_value(
        metrics, "llm_tokens_total", model="deepseek-v4-flash", type="input", source="reported"
    ) == 128
    assert counter_value(
        metrics, "llm_tokens_total", model="deepseek-v4-flash", type="cache_read", source="reported"
    ) == 64
    assert counter_value(
        metrics, "llm_tokens_total", model="deepseek-v4-flash", type="reasoning", source="reported"
    ) == 6

    labels = {"model": "deepseek-v4-flash", "adapter": "anthropic_messages"}
    assert counter_value(metrics, "llm_request_duration_ms_sum", **labels) == pytest.approx(1980)
    assert counter_value(metrics, "llm_ttft_ms_sum", **labels) == pytest.approx(412)
    assert counter_value(metrics, "llm_upstream_ttft_ms_sum", **labels) == pytest.approx(87)
    assert counter_value(metrics, "llm_tpot_ms_sum", **labels) == pytest.approx(37.5)
    assert counter_value(metrics, "llm_ttft_ms_count", **labels) == 1


def test_zero_token_failure_produces_no_ttft_sample(metrics: GatewayMetrics) -> None:
    """失败请求只记 total_ms 与错误码，不得混入 TTFT 平均值。"""

    observe_call(
        metrics,
        make_observation(
            status=STATUS_ERROR,
            error_code="UPSTREAM_TIMEOUT",
            latency=Latency(total_ms=5000),
        ),
        settings=Settings(logging={"sample_rate": 0.0}),
    )

    assert counter_value(
        metrics,
        "llm_requests_total",
        model="deepseek-v4-flash",
        adapter="anthropic_messages",
        status=STATUS_ERROR,
    ) == 1
    labels = {"model": "deepseek-v4-flash", "adapter": "anthropic_messages"}
    assert has_sample(metrics, "llm_ttft_ms_count", **labels) is False
    assert counter_value(metrics, "llm_request_duration_ms_count", **labels) == 1


def test_interrupted_stream_still_counts_usage_as_estimated(
    metrics: GatewayMetrics,
) -> None:
    """流式中断：按已产出文本估算入账，且指标 source="estimated"。"""

    observe_call(
        metrics,
        make_observation(
            status=STATUS_CLIENT_ABORTED,
            text="abcdefghijklmnop",
            latency=Latency(total_ms=900, ttft_ms=120),
        ),
        settings=Settings(logging={"sample_rate": 0.0}),
    )

    assert counter_value(
        metrics, "llm_tokens_total", model="deepseek-v4-flash", type="output", source="estimated"
    ) == 4
    assert counter_value(
        metrics,
        "llm_requests_total",
        model="deepseek-v4-flash",
        adapter="anthropic_messages",
        status=STATUS_CLIENT_ABORTED,
    ) == 1


def test_cost_estimate_recorded_only_when_route_has_pricing(
    metrics: GatewayMetrics,
) -> None:
    pricing = RoutePricing(input_per_1m=1.0, output_per_1m=2.0, currency="USD")
    observe_call(
        metrics,
        make_observation(
            status=STATUS_OK,
            usage=TokenUsage(input_tokens=1_000_000, output_tokens=1_000_000),
            route=make_route(pricing),
        ),
        settings=Settings(logging={"sample_rate": 0.0}),
    )
    assert counter_value(
        metrics, "llm_cost_estimate_total", model="deepseek-v4-flash", currency="USD"
    ) == pytest.approx(3.0)

    # 无价格表的路由不产生费用样本
    observe_call(
        metrics,
        make_observation(status=STATUS_OK, usage=TokenUsage(input_tokens=10)),
        settings=Settings(logging={"sample_rate": 0.0}),
    )
    assert counter_value(
        metrics, "llm_cost_estimate_total", model="deepseek-v4-flash", currency="USD"
    ) == pytest.approx(3.0)


def test_should_emit_log_samples_only_successes() -> None:
    assert should_emit_log(STATUS_ERROR, 0, 0.0) is True
    assert should_emit_log(STATUS_OK, 1, 0.0) is True
    assert should_emit_log(STATUS_CLIENT_ABORTED, 0, 0.0) is True
    assert should_emit_log(STATUS_OK, 0, 0.0) is False
    assert should_emit_log(STATUS_OK, 0, 1.0) is True

    emitted = should_emit_log(STATUS_OK, 0, 0.5, rng=lambda: 0.4)
    skipped = should_emit_log(STATUS_OK, 0, 0.5, rng=lambda: 0.6)
    assert emitted is True
    assert skipped is False


def test_render_metrics_exports_all_stage5_indicators() -> None:
    registry = CollectorRegistry()
    metrics = GatewayMetrics(registry)
    observe_call(
        metrics,
        make_observation(
            usage=TokenUsage(input_tokens=10, output_tokens=5),
            latency=Latency(total_ms=100, ttft_ms=50, tpot_ms=10, queue_wait_ms=3),
        ),
        settings=Settings(logging={"sample_rate": 0.0}),
    )
    body, content_type = render_metrics(registry)
    text = body.decode()

    for name in (
        "llm_requests_total",
        "llm_tokens_total",
        "llm_cost_estimate_total",
        "llm_request_duration_ms",
        "llm_ttft_ms",
        "llm_upstream_ttft_ms",
        "llm_queue_wait_ms",
        "llm_retry_overhead_ms",
        "llm_tpot_ms",
    ):
        assert name in text
    assert content_type.startswith("text/plain")


def test_metrics_endpoint_returns_prometheus_text() -> None:
    app = create_app(Settings(debug=False, logging={"sample_rate": 0.0}))
    with TestClient(app) as client:
        response = client.get("/metrics")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/plain")
    assert "llm_requests_total" in response.text
    assert "llm_tokens_total" in response.text
