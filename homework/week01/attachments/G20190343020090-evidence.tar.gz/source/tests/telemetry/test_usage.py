"""Stage 5：Token 五分类映射、上报/估算口径与费用换算。"""

from __future__ import annotations

import pytest

from gateway.core.ir import TokenUsage
from gateway.core.router import RoutePricing
from gateway.telemetry.usage import (
    TOKEN_CLASSES,
    estimate_cost,
    estimate_tokens,
    estimate_usage,
    finalize_usage,
    token_classes,
    usage_fields,
)


def test_estimate_tokens_uses_char_ratio() -> None:
    assert estimate_tokens("") == 0
    assert estimate_tokens(None) == 0
    assert estimate_tokens("abcd") == 1
    assert estimate_tokens("abcdefgh") == 2
    # 有内容但不足 4 字符也要记 1，避免「有产出却零用量」
    assert estimate_tokens("a") == 1


def test_estimate_usage_marks_source_estimated() -> None:
    usage = estimate_usage(input_text="你好世界", output_text="abcdefgh")
    assert usage.input_tokens >= 1
    assert usage.output_tokens == 2
    assert usage.source == "estimated"


def test_finalize_usage_prefers_reported() -> None:
    reported = TokenUsage(input_tokens=128, output_tokens=42, cache_read_tokens=64)
    result = finalize_usage(reported, "任意文本")
    assert result is reported
    assert result.source == "reported"
    assert result.cache_read_tokens == 64


def test_finalize_usage_falls_back_to_estimate_when_missing() -> None:
    result = finalize_usage(None, "abcdefgh")
    assert result.output_tokens == 2
    assert result.source == "estimated"


def test_finalize_usage_marks_interrupted_as_estimated() -> None:
    """流式中断：即使上游给了部分 usage，也要标 estimated 并按文本回落。"""

    partial = TokenUsage(input_tokens=10, output_tokens=1, source="reported")
    result = finalize_usage(partial, "abcdefghijkl", estimated=True)
    assert result.source == "estimated"
    assert result.input_tokens == 10
    assert result.output_tokens == 3


def test_finalize_usage_keeps_reported_output_when_no_text() -> None:
    """零文本（例如上游只报了 usage 就断开）不能把上报值清零。"""

    partial = TokenUsage(input_tokens=10, output_tokens=5, source="reported")
    result = finalize_usage(partial, "", estimated=True)
    assert result.output_tokens == 5
    assert result.source == "estimated"


def test_token_classes_cover_all_five() -> None:
    usage = TokenUsage(
        input_tokens=100,
        output_tokens=20,
        reasoning_tokens=5,
        cache_read_tokens=30,
        cache_write_tokens=7,
    )
    classes = token_classes(usage)
    assert set(classes) == set(TOKEN_CLASSES)
    assert set(classes) == {"input", "output", "reasoning", "cache_read", "cache_write"}
    assert classes["cache_write"] == 7
    assert classes["input"] == 100


def test_usage_fields_use_short_names_for_logs() -> None:
    fields = usage_fields(TokenUsage(input_tokens=3, output_tokens=4, source="estimated"))
    assert fields["input"] == 3
    assert fields["output"] == 4
    assert fields["source"] == "estimated"


def test_estimate_cost_bills_cache_read_separately() -> None:
    pricing = RoutePricing(
        input_per_1m=1.0, output_per_1m=2.0, cache_read_per_1m=0.1, currency="USD"
    )
    usage = TokenUsage(
        input_tokens=1_000_000,
        output_tokens=500_000,
        cache_read_tokens=200_000,
    )
    # 非缓存输入 800k × 1.0 + 缓存 200k × 0.1 + 输出 500k × 2.0 = 1.82
    assert estimate_cost(usage, pricing) == pytest.approx(1.82)


def test_estimate_cost_never_negative_when_cache_exceeds_input() -> None:
    pricing = RoutePricing(input_per_1m=1.0, cache_read_per_1m=1.0)
    usage = TokenUsage(input_tokens=10, cache_read_tokens=50)
    # 非缓存输入按 0 计（不为负），缓存部分按自己的单价
    assert estimate_cost(usage, pricing) == pytest.approx(0.00005)
