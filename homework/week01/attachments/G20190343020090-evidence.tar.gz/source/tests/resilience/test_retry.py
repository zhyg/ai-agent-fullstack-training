"""Stage 6 重试测试：白名单、full jitter、Retry-After、开流不重试与网关级接入。

对应 DESIGN.md §8.2 与 IMPLEMENTATION_PLAN Stage 6 验收：
- 529 × 2 后成功 → 最终 200，`retry_count=2`；
- 400 → 不重试，只发一次上游请求；
- 已吐 delta 后上游断流 → 不重试，日志记 `retry_skipped_reason=stream_started`。
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import httpx
import pytest

from gateway.adapters.registry import AdapterRegistry
from gateway.config import RetrySettings, Settings
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.invoker import Gateway
from gateway.core.ir import CallContext, CanonicalMessage, CanonicalRequest, Role
from gateway.core.router import Router
from gateway.resilience.retry import (
    RETRYABLE_CODES,
    RETRYABLE_STATUS,
    RetryPolicy,
    is_retryable,
    retry_after_header,
    retry_after_seconds,
)

FIXTURES = Path(__file__).parent.parent / "adapters" / "fixtures"
OPENAI_RAW = json.loads((FIXTURES / "openai_response.json").read_text(encoding="utf-8"))
OPENAI_SSE = (FIXTURES / "openai_stream.sse").read_bytes()

SETTINGS = RetrySettings(
    max_attempts=3,
    base_delay_ms=10,
    multiplier=2.0,
    max_delay_ms=100,
    total_deadline_ms=10_000,
)


def make_request(*, stream: bool = False) -> CanonicalRequest:
    return CanonicalRequest(
        request_id="req_retry",
        model="deepseek-v4-pro",
        messages=[CanonicalMessage(role=Role.USER, content="你好")],
        stream=stream,
    )


class Recorder:
    """记录退避时长，避免测试真的等待。"""

    def __init__(self) -> None:
        self.delays: list[float] = []

    async def __call__(self, delay: float) -> None:
        self.delays.append(delay)


class ScriptedTransport:
    """按脚本依次返回非流式响应。"""

    def __init__(self, responses: list[httpx.Response]) -> None:
        self.responses = list(responses)
        self.calls: list[str] = []

    async def post(self, url, payload, headers, route):
        self.calls.append(url)
        if not self.responses:
            raise AssertionError("no more scripted upstream responses")
        return self.responses.pop(0)

    async def stream(self, url, payload, headers, route):  # pragma: no cover
        raise AssertionError("streaming request must use transport.stream()")


class StreamScriptedTransport:
    """按脚本依次返回流式响应。"""

    def __init__(self, responses: list[httpx.Response]) -> None:
        self.responses = list(responses)
        self.calls: list[str] = []

    async def post(self, url, payload, headers, route):  # pragma: no cover
        raise AssertionError("non-stream request must use transport.post()")

    async def stream(self, url, payload, headers, route):
        self.calls.append(url)
        if not self.responses:
            raise AssertionError("no more scripted upstream streams")
        return self.responses.pop(0)


class FailingAfterDelta(httpx.AsyncByteStream):
    """先吐一个 start 与一个 delta，再模拟网络中断。"""

    def __init__(self) -> None:
        self.closed = False

    async def __aiter__(self):
        yield (
            b'event: response.created\ndata: {"type":"response.created"}\n\n'
            b'event: response.output_text.delta\n'
            b'data: {"type":"response.output_text.delta","delta":"\xe4\xbd\xa0"}\n\n'
        )
        raise httpx.ReadError("connection reset")

    async def aclose(self) -> None:
        self.closed = True


def gateway_with(transport: Any, policy: RetryPolicy) -> Gateway:
    return Gateway(
        Router.from_file(),
        AdapterRegistry.default(),
        transport,
        Settings(debug=False),
        retry=policy,
    )


# ---------------------------------------------------------------- 判定与退避


def test_retryable_whitelist() -> None:
    assert RETRYABLE_STATUS == frozenset({408, 409, 429, 500, 502, 503, 504, 529})
    assert is_retryable(GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "529"))
    assert is_retryable(GatewayError(ErrorCode.UPSTREAM_TIMEOUT, "timeout"))
    assert is_retryable(GatewayError(ErrorCode.STREAM_INTERRUPTED, "cut"))
    assert not is_retryable(GatewayError(ErrorCode.UPSTREAM_BAD_REQUEST, "400"))
    assert not is_retryable(GatewayError(ErrorCode.MODEL_NOT_FOUND, "unknown"))
    assert ErrorCode.UPSTREAM_UNAVAILABLE.value in RETRYABLE_CODES


def test_full_jitter_bounds() -> None:
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.5, sleep=Recorder())

    # 0.5 × min(100ms, 10ms × 2^(n-1))：指数增长并在 max_delay 处封顶
    assert policy.delay_for(1) == 0.005
    assert policy.delay_for(2) == 0.01
    assert policy.delay_for(5) == 0.05


def test_retry_after_is_honored_and_capped() -> None:
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())

    assert policy.delay_for(1, retry_after=0.02) == 0.02
    # 上游要求 5s，但 max_delay 只有 100ms
    assert policy.delay_for(1, retry_after=5.0) == 0.1


def test_retry_after_header_parsing() -> None:
    exc = GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "429", headers={"retry-after": "3"})
    assert retry_after_seconds(exc) == 3.0
    assert retry_after_seconds(GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "429")) is None

    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())
    assert policy.delay_for(1, retry_after=3.0) == 0.1
    assert retry_after_header(2.3) == "3"


def test_plan_refuses_for_each_reason() -> None:
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())
    ctx = CallContext(request_id="req_plan")
    unavailable = GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "529")

    assert policy.plan(
        GatewayError(ErrorCode.UPSTREAM_BAD_REQUEST, "400"), ctx, 1
    ).reason == "not_retryable"
    assert policy.plan(unavailable, ctx, 1, stream_started=True).reason == "stream_started"
    assert policy.plan(unavailable, ctx, SETTINGS.max_attempts).reason == "max_attempts"

    ctx.deadline = time.perf_counter() - 1
    assert policy.plan(unavailable, ctx, 1).reason == "deadline"


# ---------------------------------------------------------------- 执行器


@pytest.mark.anyio
async def test_execute_counts_and_backs_off_until_success() -> None:
    recorder = Recorder()
    policy = RetryPolicy(SETTINGS, rng=lambda: 1.0, sleep=recorder)
    ctx = CallContext(request_id="req_execute")
    calls = 0

    async def operation() -> str:
        nonlocal calls
        calls += 1
        if calls < 3:
            raise GatewayError(ErrorCode.UPSTREAM_UNAVAILABLE, "529")
        return "ok"

    assert await policy.execute(operation, ctx) == "ok"
    assert calls == 3
    assert ctx.attempt == 3
    assert ctx.retry_count == 2
    assert ctx.retry_skipped_reason is None
    assert ctx.retry_overhead_ms == 30.0  # 10ms + 20ms
    assert recorder.delays == [0.01, 0.02]


@pytest.mark.anyio
async def test_execute_does_not_retry_non_retryable() -> None:
    recorder = Recorder()
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=recorder)
    ctx = CallContext(request_id="req_no_retry")
    calls = 0

    async def operation() -> str:
        nonlocal calls
        calls += 1
        raise GatewayError(ErrorCode.UPSTREAM_BAD_REQUEST, "400")

    with pytest.raises(GatewayError):
        await policy.execute(operation, ctx)

    assert calls == 1
    assert ctx.retry_count == 0
    assert ctx.retry_skipped_reason == "not_retryable"
    assert recorder.delays == []


# ---------------------------------------------------------------- 网关接入（非流式）


@pytest.mark.anyio
async def test_gateway_retries_two_529_then_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport(
        [
            httpx.Response(529),
            httpx.Response(529),
            httpx.Response(200, json=OPENAI_RAW),
        ]
    )
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())
    gateway = gateway_with(transport, policy)
    ctx = CallContext(request_id="req_529")

    response = await gateway.complete(make_request(), ctx)

    assert response.text == "你好，我是网关。"
    assert len(transport.calls) == 3
    assert ctx.attempt == 3
    assert ctx.retry_count == 2
    assert response.latency.retry_overhead_ms == 0.0


@pytest.mark.anyio
async def test_gateway_does_not_retry_400(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport(
        [httpx.Response(400, json={"error": {"message": "bad request"}})]
    )
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())
    gateway = gateway_with(transport, policy)
    ctx = CallContext(request_id="req_400")

    with pytest.raises(GatewayError) as excinfo:
        await gateway.complete(make_request(), ctx)

    assert excinfo.value.code == ErrorCode.UPSTREAM_BAD_REQUEST.value
    assert len(transport.calls) == 1
    assert ctx.retry_count == 0
    assert ctx.retry_skipped_reason == "not_retryable"


@pytest.mark.anyio
async def test_gateway_honors_upstream_retry_after(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = ScriptedTransport(
        [
            httpx.Response(429, headers={"Retry-After": "0.05"}),
            httpx.Response(200, json=OPENAI_RAW),
        ]
    )
    recorder = Recorder()
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=recorder)
    gateway = gateway_with(transport, policy)
    ctx = CallContext(request_id="req_retry_after")

    response = await gateway.complete(make_request(), ctx)

    assert response.text == "你好，我是网关。"
    assert recorder.delays == [0.05]
    assert ctx.retry_count == 1
    assert ctx.retry_overhead_ms == 50.0


# ---------------------------------------------------------------- 网关接入（流式）


@pytest.mark.anyio
async def test_stream_retries_before_first_delta(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    transport = StreamScriptedTransport(
        [
            httpx.Response(500, json={"error": {"message": "overloaded"}}),
            httpx.Response(
                200,
                content=OPENAI_SSE,
                headers={"content-type": "text/event-stream"},
            ),
        ]
    )
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())
    gateway = gateway_with(transport, policy)
    ctx = CallContext(request_id="req_stream_retry")

    events = [event async for event in gateway.stream(make_request(stream=True), ctx)]

    assert len(transport.calls) == 2
    assert ctx.retry_count == 1
    delta_text = "".join(event.text_delta or "" for event in events if event.type == "delta")
    assert delta_text == "你好，我是网关。"
    assert events[-1].type == "done"


@pytest.mark.anyio
async def test_stream_does_not_retry_after_first_delta(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    stream = FailingAfterDelta()
    transport = StreamScriptedTransport(
        [httpx.Response(200, stream=stream, headers={"content-type": "text/event-stream"})]
    )
    policy = RetryPolicy(SETTINGS, rng=lambda: 0.0, sleep=Recorder())
    gateway = gateway_with(transport, policy)
    ctx = CallContext(request_id="req_stream_cut")

    seen = []
    with pytest.raises(GatewayError):
        async for event in gateway.stream(make_request(stream=True), ctx):
            seen.append(event.type)

    assert seen == ["start", "delta"]
    assert len(transport.calls) == 1
    assert ctx.stream_started is True
    assert ctx.retry_count == 0
    assert ctx.retry_skipped_reason == "stream_started"
    assert stream.closed is True
