"""Stage 6 限流测试：三道闸、模型隔离、TPM 多退少补与 API 层 429 行为。

对应 DESIGN.md §8.3 与 IMPLEMENTATION_PLAN Stage 6 验收：
- flash 打满 RPM → 429 + `Retry-After`，同时 pro 请求正常 200；
- 每模型独立一套桶，互不挤占。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient

from gateway.config import Settings
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.ir import CanonicalMessage, CanonicalRequest, Role
from gateway.core.router import ModelRoute, RouteLimits, RouteTable, Router
from gateway.main import create_app
from gateway.resilience.ratelimit import MemoryRateLimiter, estimate_request_tokens

FIXTURES = Path(__file__).parent.parent / "adapters" / "fixtures"
OPENAI_RAW = json.loads((FIXTURES / "openai_response.json").read_text(encoding="utf-8"))
ANTHROPIC_RAW = json.loads((FIXTURES / "anthropic_response.json").read_text(encoding="utf-8"))


class FakeClock:
    """可控时钟：不推进时间就不会有令牌补充，便于断言桶的精确余量。"""

    def __init__(self, start: float = 1000.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


async def no_sleep(_seconds: float) -> None:
    return None


def make_limiter(clock: FakeClock) -> MemoryRateLimiter:
    return MemoryRateLimiter(clock=clock, sleep=no_sleep)


def make_request(text: str = "hi") -> CanonicalRequest:
    return CanonicalRequest(
        request_id="req_limit",
        model="deepseek-v4-flash",
        messages=[CanonicalMessage(role=Role.USER, content=text)],
    )


# ---------------------------------------------------------------- 内存限流器


def test_estimate_request_tokens_uses_input_text() -> None:
    req = CanonicalRequest(
        request_id="req_est",
        model="deepseek-v4-flash",
        system="1234",
        messages=[CanonicalMessage(role=Role.USER, content="abcdefgh")],
    )
    assert estimate_request_tokens(req) == 3  # "1234\nabcdefgh" 共 13 字符 → 13//4


@pytest.mark.anyio
async def test_rpm_gate_rejects_after_bucket_empty() -> None:
    clock = FakeClock()
    limiter = make_limiter(clock)
    limits = RouteLimits(rpm=2, tpm=10_000, concurrent=8)

    first = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
    )
    second = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
    )

    with pytest.raises(GatewayError) as excinfo:
        await limiter.acquire(
            model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
        )

    error = excinfo.value
    assert error.code == ErrorCode.RATE_LIMITED.value
    assert error.status_code == 429
    assert error.details["rate_limited_by"] == "rpm"
    assert int(error.headers["Retry-After"]) >= 1

    first.release()
    second.release()


@pytest.mark.anyio
async def test_tpm_gate_pre_deducts_and_refunds_on_release() -> None:
    clock = FakeClock()
    limiter = make_limiter(clock)
    limits = RouteLimits(rpm=100, tpm=100, concurrent=8)

    lease = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=80, max_queue_wait_ms=0
    )

    with pytest.raises(GatewayError) as excinfo:
        await limiter.acquire(
            model="m", limits=limits, estimated_tokens=50, max_queue_wait_ms=0
        )
    assert excinfo.value.details["rate_limited_by"] == "tpm"

    # 实测只用了 20：多扣的 60 退回，桶里回到 80
    lease.release(20)
    again = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=70, max_queue_wait_ms=0
    )

    # release 幂等：重复释放不会再归还并发名额
    again.release()
    again.release()


@pytest.mark.anyio
async def test_concurrency_gate_rejects_when_slot_busy() -> None:
    clock = FakeClock()
    limiter = make_limiter(clock)
    limits = RouteLimits(rpm=100, tpm=10_000, concurrent=1)

    lease = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
    )

    with pytest.raises(GatewayError) as excinfo:
        await limiter.acquire(
            model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
        )
    assert excinfo.value.details["rate_limited_by"] == "concurrent"

    lease.release()


@pytest.mark.anyio
async def test_concurrency_queue_timeout_is_429() -> None:
    clock = FakeClock()
    limiter = make_limiter(clock)
    limits = RouteLimits(rpm=100, tpm=10_000, concurrent=1)

    lease = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
    )

    with pytest.raises(GatewayError) as excinfo:
        # 排队 1ms 拿不到名额即拒绝，避免客户端无限等待
        await limiter.acquire(
            model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=1
        )
    assert excinfo.value.details["rate_limited_by"] == "concurrent"

    lease.release()


@pytest.mark.anyio
async def test_models_have_independent_buckets() -> None:
    clock = FakeClock()
    limiter = make_limiter(clock)
    flash = RouteLimits(rpm=1, tpm=10_000, concurrent=8)
    pro = RouteLimits(rpm=100, tpm=10_000, concurrent=8)

    flash_lease = await limiter.acquire(
        model="deepseek-v4-flash", limits=flash, estimated_tokens=10, max_queue_wait_ms=0
    )
    with pytest.raises(GatewayError):
        await limiter.acquire(
            model="deepseek-v4-flash", limits=flash, estimated_tokens=10, max_queue_wait_ms=0
        )

    # flash 打满不影响 pro
    pro_lease = await limiter.acquire(
        model="deepseek-v4-pro", limits=pro, estimated_tokens=10, max_queue_wait_ms=0
    )

    flash_lease.release()
    pro_lease.release()


@pytest.mark.anyio
async def test_bucket_refills_over_time() -> None:
    clock = FakeClock()
    limiter = make_limiter(clock)
    limits = RouteLimits(rpm=60, tpm=10_000, concurrent=8)

    first = await limiter.acquire(
        model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
    )
    first.release()

    # rpm=60 → 每秒补 1 个令牌；等 1.1s 后额度恢复
    clock.advance(1.1)
    assert await limiter.acquire(
        model="m", limits=limits, estimated_tokens=10, max_queue_wait_ms=0
    ) is not None


# ---------------------------------------------------------------- API 集成


class ModelTransport:
    """按适配器返回对应协议的假上游响应。"""

    async def post(self, url, payload, headers, route):
        raw = ANTHROPIC_RAW if route.adapter == "anthropic_messages" else OPENAI_RAW
        return httpx.Response(200, json=raw)

    async def stream(self, url, payload, headers, route):  # pragma: no cover
        raise AssertionError("this test only covers non-stream requests")


def small_limit_router() -> Router:
    """flash 的 RPM 设成 1，pro 保持宽裕，用来验证「按模型独立」。"""

    # 必须经 RouteTable 回填 model 名，限流桶按 route.model 分桶
    table = RouteTable(
        models={
            "deepseek-v4-flash": ModelRoute(
                adapter="anthropic_messages",
                upstream_model="deepseek-v4-flash",
                base_url="https://example.com",
                api_key_env="DEEPSEEK_FLASH_API_KEY",
                limits=RouteLimits(rpm=1, tpm=10_000_000, concurrent=8),
            ),
            "deepseek-v4-pro": ModelRoute(
                adapter="openai_responses",
                upstream_model="deepseek-v4-pro",
                base_url="https://example.com",
                api_key_env="DEEPSEEK_PRO_API_KEY",
                limits=RouteLimits(rpm=100, tpm=10_000_000, concurrent=8),
            ),
        }
    )
    return Router(table.models)


def _app(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash-key")
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro-key")
    return TestClient(
        create_app(
            Settings(debug=False),
            router=small_limit_router(),
            transport=ModelTransport(),
        )
    )


def test_api_flash_429_but_pro_still_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    body: dict[str, Any] = {
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "hi"}],
    }

    with _app(monkeypatch) as client:
        assert client.post("/v1/chat", json=body).status_code == 200

        limited = client.post("/v1/chat", json=body)
        assert limited.status_code == 429
        error = limited.json()["error"]
        assert error["code"] == "RATE_LIMITED"
        assert error["retryable"] is True
        assert int(limited.headers["Retry-After"]) >= 1

        pro = client.post(
            "/v1/chat",
            json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "hi"}]},
        )
        assert pro.status_code == 200


def test_api_stream_is_limited_before_sse(monkeypatch: pytest.MonkeyPatch) -> None:
    plain: dict[str, Any] = {
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": "hi"}],
    }
    streaming: dict[str, Any] = {**plain, "stream": True}

    with _app(monkeypatch) as client:
        # 先用一次普通请求把 flash 的 RPM 额度耗尽
        assert client.post("/v1/chat", json=plain).status_code == 200

        limited = client.post("/v1/chat", json=streaming)
        # 限流发生在开流之前，因此仍是 HTTP 429 而不是 SSE 内的 error 事件
        assert limited.status_code == 429
        assert limited.headers["content-type"].startswith("application/json")
        assert limited.json()["error"]["code"] == "RATE_LIMITED"
