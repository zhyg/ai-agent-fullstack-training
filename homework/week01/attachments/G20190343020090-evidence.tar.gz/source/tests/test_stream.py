"""Stage 2 流式测试：SSE 解析、事件映射、心跳、静默超时、断开与对外 SSE 出口。"""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

from gateway.adapters.anthropic_messages import AnthropicMessagesAdapter
from gateway.adapters.openai_responses import OpenAIResponsesAdapter
from gateway.adapters.registry import AdapterRegistry
from gateway.api.routers.sse import stream_frames
from gateway.config import Settings
from gateway.core.errors import ErrorCode, GatewayError
from gateway.core.events import CanonicalEvent
from gateway.core.invoker import Gateway
from gateway.core.ir import (
    CallContext,
    CanonicalMessage,
    CanonicalRequest,
    FinishReason,
    Role,
    TokenUsage,
)
from gateway.core.router import Router
from gateway.core.sse import iter_sse_frames
from gateway.main import create_app

FIXTURES = Path(__file__).parent / "adapters" / "fixtures"
OPENAI_SSE = (FIXTURES / "openai_stream.sse").read_bytes()
ANTHROPIC_SSE = (FIXTURES / "anthropic_stream.sse").read_bytes()


async def chunked(data: bytes, size: int = 5) -> AsyncIterator[bytes]:
    """模拟网络分块：故意按小片切，覆盖跨块多字节字符。"""

    for start in range(0, len(data), size):
        yield data[start : start + size]


async def collect(agen) -> list:
    return [item async for item in agen]


def make_request(model: str = "deepseek-v4-flash", *, stream: bool = True) -> CanonicalRequest:
    return CanonicalRequest(
        request_id="req_stream",
        model=model,
        messages=[CanonicalMessage(role=Role.USER, content="讲个故事")],
        stream=stream,
    )


class RecordingStream(httpx.AsyncByteStream):
    """可控的假上游字节流：记录是否被关闭，可按块延迟。"""

    def __init__(self, chunks: list[bytes], *, delay: float = 0.0) -> None:
        self.chunks = chunks
        self.delay = delay
        self.closed = False

    async def __aiter__(self) -> AsyncIterator[bytes]:
        for chunk in self.chunks:
            if self.delay:
                await asyncio.sleep(self.delay)
            yield chunk

    async def aclose(self) -> None:
        self.closed = True


class SilentStream(httpx.AsyncByteStream):
    """始终没有数据的上游，用来触发静默超时。"""

    def __init__(self) -> None:
        self.closed = False

    async def __aiter__(self) -> AsyncIterator[bytes]:
        await asyncio.sleep(5)
        if False:  # pragma: no cover - 让函数成为异步生成器
            yield b""

    async def aclose(self) -> None:
        self.closed = True


class FakeStreamTransport:
    """只实现流式接口的传输桩。"""

    def __init__(self, stream: httpx.AsyncByteStream, *, status: int = 200) -> None:
        self.stream_obj = stream
        self.response = httpx.Response(
            status, stream=stream, headers={"content-type": "text/event-stream"}
        )
        self.calls: list[tuple[str, dict, dict]] = []

    async def post(self, url, payload, headers, route):  # pragma: no cover - 不应被调用
        raise AssertionError("streaming request must use transport.stream()")

    async def stream(self, url, payload, headers, route):
        self.calls.append((url, payload, headers))
        return self.response


def sse_frames(body: str) -> list[str]:
    """把完整响应体拆成帧（注释行为心跳原始文本）。"""

    frames: list[str] = []
    for block in body.split("\n\n"):
        block = block.strip("\n")
        if not block:
            continue
        frames.append(block)
    return frames


def data_frames(body: str) -> list[str]:
    return [frame[len("data:") :].strip() for frame in sse_frames(body) if frame.startswith("data:")]


# ---------------------------------------------------------------- SSE 解析


@pytest.mark.anyio
async def test_sse_parser_handles_split_multibyte_and_comments() -> None:
    raw = (
        'event: response.created\ndata: {"type":"response.created","tag":"你好"}\n\n'
        ": comment line\n\n"
        "data: [DONE]\n\n"
    ).encode()
    frames = await collect(iter_sse_frames(chunked(raw, 1)))

    assert frames[0].event == "response.created"
    assert json.loads(frames[0].data)["tag"] == "你好"
    assert frames[1].data == "[DONE]"


# ---------------------------------------------------------------- 事件映射


@pytest.mark.anyio
async def test_openai_stream_event_mapping() -> None:
    events = await collect(OpenAIResponsesAdapter().parse_sse(chunked(OPENAI_SSE)))

    types = [event.type for event in events]
    assert types[0] == "start"
    assert types.count("delta") == 3
    assert types[-1] == "done"
    assert "".join(e.text_delta or "" for e in events if e.type == "delta") == "你好，我是网关。"
    done = events[-1]
    assert done.finish_reason == FinishReason.STOP
    assert done.usage is not None
    assert done.usage.input_tokens == 12
    assert done.usage.output_tokens == 8
    assert done.usage.cache_read_tokens == 4
    assert done.usage.reasoning_tokens == 2


@pytest.mark.anyio
async def test_anthropic_stream_event_mapping() -> None:
    events = await collect(AnthropicMessagesAdapter().parse_sse(chunked(ANTHROPIC_SSE)))

    types = [event.type for event in events]
    assert types[0] == "start"
    assert types.count("delta") == 3
    assert types[-1] == "done"
    assert events[0].usage is not None
    assert events[0].usage.input_tokens == 12
    done = events[-1]
    assert done.finish_reason == FinishReason.STOP
    assert done.usage is not None
    assert done.usage.output_tokens == 8
    assert done.usage.cache_write_tokens == 10


def _client_view(events: list[CanonicalEvent]) -> dict:
    """只保留客户端可见语义，用于证明两家上游归一后完全一致。"""

    done = next(event for event in events if event.type == "done")
    return {
        "deltas": [event.text_delta for event in events if event.type == "delta"],
        "finish_reason": done.finish_reason,
        "prompt_tokens": done.usage.input_tokens if done.usage else None,
        "completion_tokens": done.usage.output_tokens if done.usage else None,
        "has_start": any(event.type == "start" for event in events),
    }


@pytest.mark.anyio
async def test_both_adapters_produce_identical_client_view() -> None:
    """DoD：同一套断言跑两遍，两家上游在网关内部归一为同一事件序列。"""

    openai_events = await collect(OpenAIResponsesAdapter().parse_sse(chunked(OPENAI_SSE)))
    anthropic_events = await collect(
        AnthropicMessagesAdapter().parse_sse(chunked(ANTHROPIC_SSE))
    )

    assert _client_view(openai_events) == _client_view(anthropic_events)
    assert _client_view(openai_events)["deltas"] == ["你", "好，", "我是网关。"]


@pytest.mark.anyio
async def test_stream_error_event_maps_to_gateway_error() -> None:
    raw = (
        'event: error\ndata: {"type":"error","error":{"type":"overloaded_error",'
        '"message":"Overloaded"}}\n\n'
    ).encode()
    events = await collect(AnthropicMessagesAdapter().parse_sse(chunked(raw)))
    assert events[-1].type == "error"
    assert isinstance(events[-1].error, GatewayError)
    assert events[-1].error.code == ErrorCode.UPSTREAM_UNAVAILABLE.value


# ---------------------------------------------------------------- 调用编排


@pytest.mark.anyio
async def test_gateway_stream_builds_streaming_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "test-pro-key")
    transport = FakeStreamTransport(RecordingStream([OPENAI_SSE]))
    gateway = Gateway(Router.from_file(), AdapterRegistry.default(), transport)
    ctx = CallContext(request_id="req_stream")

    events = await collect(gateway.stream(make_request("deepseek-v4-pro"), ctx))

    url, payload, headers = transport.calls[0]
    assert url == "https://api.deepseek.com/v1/responses"
    assert headers["Authorization"] == "Bearer test-pro-key"
    assert payload["stream"] is True
    assert payload["model"] == "deepseek-v4-pro"
    # 为 Stage 6 预留：收到首个 delta 后 stream_started 必须为 True
    assert ctx.stream_started is True
    assert events[-1].type == "done" and events[-1].finish_reason == FinishReason.STOP


@pytest.mark.anyio
async def test_gateway_stream_closes_upstream_on_consumer_stop(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "k")
    transport = FakeStreamTransport(RecordingStream([OPENAI_SSE]))
    gateway = Gateway(Router.from_file(), AdapterRegistry.default(), transport)

    agen = gateway.stream(make_request("deepseek-v4-pro"), CallContext(request_id="req_abort"))
    try:
        first = await anext(agen)
        assert first.type == "start"
    finally:
        await agen.aclose()

    assert transport.stream_obj.closed is True


# ---------------------------------------------------------------- 对外 SSE 出口


def _stream_app(stream_obj: httpx.AsyncByteStream, *, stream_settings: dict | None = None) -> TestClient:
    settings = Settings(debug=False, stream=stream_settings or {})
    return TestClient(
        create_app(settings, transport=FakeStreamTransport(stream_obj))
    )


def test_api_stream_returns_openai_compatible_sse(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "test-flash-key")
    body_text = ""
    with _stream_app(RecordingStream([ANTHROPIC_SSE])) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "讲个故事"}],
                "stream": True,
            },
        )
        body_text = response.text

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert response.headers["x-accel-buffering"] == "no"

    frames = data_frames(body_text)
    assert frames[-1] == "[DONE]"
    chunks = [json.loads(frame) for frame in frames[:-1]]
    deltas = "".join(
        chunk["choices"][0]["delta"].get("content", "")
        for chunk in chunks
        if chunk["choices"][0]["finish_reason"] is None
    )
    assert deltas == "你好，我是网关。"
    final = chunks[-1]
    assert final["choices"][0]["finish_reason"] == "stop"
    assert final["usage"]["prompt_tokens"] == 12
    assert final["usage"]["completion_tokens"] == 8
    assert final["gateway"]["ttft_ms"] > 0
    assert final["gateway"]["total_ms"] > 0


def test_api_stream_and_non_stream_share_client_semantics(monkeypatch: pytest.MonkeyPatch) -> None:
    """DoD：两家上游分别吐自家事件格式，对外 SSE 的客户端语义完全一致。"""

    monkeypatch.setenv("DEEPSEEK_PRO_API_KEY", "pro")
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash")

    views = []
    for model, fixture in (
        ("deepseek-v4-pro", OPENAI_SSE),
        ("deepseek-v4-flash", ANTHROPIC_SSE),
    ):
        with _stream_app(RecordingStream([fixture])) as client:
            response = client.post(
                "/v1/chat",
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": "讲个故事"}],
                    "stream": True,
                },
            )
        chunks = [json.loads(frame) for frame in data_frames(response.text)[:-1]]
        views.append(
            {
                "deltas": [
                    chunk["choices"][0]["delta"].get("content")
                    for chunk in chunks
                    if chunk["choices"][0]["finish_reason"] is None
                ],
                "finish_reason": chunks[-1]["choices"][0]["finish_reason"],
                "prompt_tokens": chunks[-1]["usage"]["prompt_tokens"],
                "completion_tokens": chunks[-1]["usage"]["completion_tokens"],
            }
        )

    assert views[0] == views[1], views


def test_api_stream_preflight_missing_key_returns_json_401() -> None:
    """流式请求的鉴权在发 200 之前完成，仍能返回统一 JSON 错误。"""

    with _stream_app(RecordingStream([ANTHROPIC_SSE])) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            },
        )

    assert response.status_code == 401
    assert response.headers["content-type"].startswith("application/json")
    assert response.json()["error"]["code"] == ErrorCode.UPSTREAM_AUTH.value


def test_api_stream_emits_heartbeat_when_upstream_is_slow(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash")
    chunks = [ANTHROPIC_SSE[i : i + 120] for i in range(0, len(ANTHROPIC_SSE), 120)]
    with _stream_app(
        RecordingStream(chunks, delay=0.1),
        stream_settings={"heartbeat_s": 0.05, "silence_timeout_s": 5},
    ) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            },
        )

    assert ": heartbeat" in response.text
    assert data_frames(response.text)[-1] == "[DONE]"


def test_api_stream_silence_timeout_emits_interrupted_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DEEPSEEK_FLASH_API_KEY", "flash")
    with _stream_app(
        SilentStream(),
        stream_settings={"heartbeat_s": 0.02, "silence_timeout_s": 0.08},
    ) as client:
        response = client.post(
            "/v1/chat",
            json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            },
        )

    body = response.text
    assert response.status_code == 200
    assert data_frames(body)[-1] == "[DONE]"
    error_frames = [
        json.loads(frame) for frame in data_frames(body)[:-1] if '"error"' in frame
    ]
    assert error_frames[-1]["error"]["code"] == ErrorCode.STREAM_INTERRUPTED.value


class SlowGateway:
    """只产一个 delta 就卡住的假网关，用于验证客户端断开。"""

    def __init__(self) -> None:
        self.closed = False

    async def stream(self, req, ctx, prepared=None):
        try:
            yield CanonicalEvent(type="delta", text_delta="你")
            await asyncio.sleep(10)
            yield CanonicalEvent(
                type="done", usage=TokenUsage(input_tokens=1, output_tokens=1),
                finish_reason=FinishReason.STOP,
            )
        finally:
            self.closed = True


@pytest.mark.anyio
async def test_client_abort_marks_flag_and_closes_upstream() -> None:
    settings = Settings(debug=False, stream={"heartbeat_s": 0.05, "silence_timeout_s": 5})
    ctx = CallContext(request_id="req_client_abort")
    fake_gateway = SlowGateway()

    agen = stream_frames(fake_gateway, make_request(), ctx, settings, prepared=None)
    first = await anext(agen)
    assert "你" in first.decode()
    await agen.aclose()

    assert ctx.client_aborted is True
    assert fake_gateway.closed is True
