import hashlib,json,os,re,sys,tarfile
from pathlib import Path

ROOT=Path('/home/user/workspace/repo')
E=Path('/tmp/grading-G20190343020090')
B=E/'bundle'
feedback=ROOT/'homework/week01/G20190343020090.md'
attachment=ROOT/'homework/week01/attachments/G20190343020090.md'
text=feedback.read_text()
sections=[]
for n,nextn in ((2,3),(3,4),(4,None)):
    body=text.split(f'**{n}. ')[1].split('**',1)[1]
    if nextn: body=body.split(f'**{nextn}. ')[0]
    items=[l for l in body.splitlines() if l.startswith('- ')]
    assert 3<=len(items)<=5 and sum(map(len,items))<=500
    sections.append({'section':n,'items':len(items),'characters':sum(map(len,items))})
scores=[]
for line in attachment.read_text().splitlines():
    m=re.match(r'\| [^|]+ \| (\d+)/(\d+) \|',line)
    if m: scores.append((int(m[1]),int(m[2])))
assert len(scores)==8 and sum(x for x,y in scores)==96 and sum(y for x,y in scores)==100
assert '作业等级：优秀（96分）' in text
assert '178 passed' in (B/'student-tests.log').read_text()
assert 'exit_code=1' in (B/'student-injected-failure.log').read_text()
teacher=json.loads((B/'teacher-results.json').read_text())
assert len(teacher)==44 and sum(x['passed'] for x in teacher)==37
socket=json.loads((B/'socket-gate-results.json').read_text())
assert len(socket)==4 and all(x['pass'] for x in socket)
real=json.loads((B/'real-results.json').read_text())
assert len(real['results'])==6
for r in real['results']:
    assert r['status']==200
    if r['mode']=='stream':
        frames=[json.loads(l[6:]) for l in r['body'].splitlines() if l.startswith('data: {')]
        assert not any('error' in f for f in frames) and 'data: [DONE]' in r['body']
        content=''.join((f['choices'][0].get('delta') or {}).get('content','') for f in frames)
    else:
        body=json.loads(r['body']); content=body['text']
        if r['mode']=='json': assert body['structured']=={'ok':True}
    assert json.loads(content)=={'ok':True}
assert all(x['url'].startswith('https://api.deepseek.com/') for x in real['upstream'])
assert (B/'source-status.txt').read_text()==''
manifest={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (B/'source-sha256.txt').read_text().splitlines()}
for f in (B/'source').rglob('*'):
    if f.is_file(): assert hashlib.sha256(f.read_bytes()).hexdigest()==manifest[str(f.relative_to(B/'source'))]
# AMP_SECRET_ENV_NAMES contains variable identifiers, not credential values.
secrets=[v.encode() for k,v in os.environ.items() if k!='AMP_SECRET_ENV_NAMES' and re.search(r'API_KEY|TOKEN|SECRET|PASSWORD',k,re.I) and len(v)>=12]
def scan(name,data):
    assert not any(s in data for s in secrets),f'Credential found in {name}'
    assert not re.search(rb'sk-(?:proj-)?[A-Za-z0-9_-]{16,}',data),f'Key-like value in {name}'
for f in [*B.rglob('*'),feedback,attachment]:
    if f.is_file(): scan(str(f),f.read_bytes())
if len(sys.argv)>1:
    with tarfile.open(sys.argv[1],'r:gz') as tar:
        for m in tar.getmembers():
            assert not m.issym() and not m.islnk()
            if m.isfile(): scan(m.name,tar.extractfile(m).read())
    print('Final archive rescanned: no credential matches')
else:
    result={'score':96,'maximum':100,'grade':'优秀','conclusion':'通过，需修复','format_sections':sections,'student_tests_passed':178,'injected_failure_exit':1,'teacher_checks':44,'teacher_checks_passed':37,'teacher_checks_failed':7,'deduction_root_causes':4,'real_official_calls_passed':6,'tcp_gate_checks_passed':4,'source_snapshot_hashes':'matched','student_worktree':'clean','secret_scan':'no exact environment credential or key-like value matches; no values printed'}
    (B/'audit-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False))
