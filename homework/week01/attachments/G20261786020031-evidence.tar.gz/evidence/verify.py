"""Checks only; never print credential material."""
import hashlib,json,os,re,socket,subprocess,tarfile
from pathlib import Path

root=Path('/home/user/workspace/repo/homework/week01')
evidence=Path(__file__).parent
feedback=root/'G20261786020031.md'
attachment=root/'attachments/G20261786020031.md'
key=os.environ.get('DEEPSEEK_API_KEY','').encode()
assert key, 'Existing credential required for exact-value leak scan'
paths=[p for p in evidence.rglob('*') if p.is_file() and '__pycache__' not in p.parts]+[feedback,attachment]
for p in paths:
    assert key not in p.read_bytes(), 'Credential found; no value displayed'
text=feedback.read_text()
sections=re.split(r'\*\*[234]\. .*?\*\*',text)[1:]
counts=[]
for s in sections:
    count=len(re.findall(r'^- ',s,re.M));assert 3<=count<=5 and len(s)<500
    counts.append({'items':count,'characters':len(s)})
assert '优秀（86分）' in text
score=[int(x) for x in re.findall(r'\| (\d+)/(?:15|10) \|',attachment.read_text())]
assert len(score)==8 and sum(score)==86
student=Path('/tmp/grade-G20261786020031/student')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=student)
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=student).decode().split('\0')
for name in filter(None,tracked):assert (evidence/'source'/name).read_bytes()==(student/name).read_bytes()
for port in [8031,18031]:
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0
result={'score':sum(score),'sections':counts,'exact_live_key_scan':'PASS; value never emitted',
        'files_scanned':len(paths),'source_snapshot_equal':True,'student_worktree_clean':True,'ports_8031_18031_closed':True}
archive=root/'attachments/G20261786020031-evidence.tar.gz'
if archive.exists():
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar.getmembers():
            if member.isfile():assert key not in tar.extractfile(member).read(), 'Archive credential leak'
    result['archive_exact_key_scan']='PASS'
else:
    (evidence/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
