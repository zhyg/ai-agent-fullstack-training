"""Teacher fault injection: only this isolated pytest process receives 503."""
import httpx
def pytest_configure(config):
    async def unavailable(self,request):
        return httpx.Response(503,json={'error':{'message':'teacher induced unavailable'}},request=request)
    httpx.MockTransport.handle_async_request=unavailable
