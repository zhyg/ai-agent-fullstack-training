import asyncio,json,os
from pathlib import Path
import httpx

async def main():
    output=[]
    async with httpx.AsyncClient(timeout=20,trust_env=False) as c:
        async with c.stream('POST','https://api.deepseek.com/responses',
            headers={'Authorization':'Bearer '+os.environ['DEEPSEEK_API_KEY']},
            json={'model':'deepseek-v4-pro','input':[{'role':'user','content':'Return only JSON: {"ok":true}'}],
                  'stream':True,'max_output_tokens':256,'thinking':{'type':'disabled'}}) as r:
            output.append({'status':r.status_code})
            async for line in r.aiter_lines():
                if line:output.append(line)
    Path(__file__).with_name('official-responses-wire.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
    print('status',output[0],'event_types',[x for x in output[1:] if x.startswith('event:')])
asyncio.run(main())
