import asyncio,json,os
from pathlib import Path
import httpx
from teacher import settings,req,wire
from studyagent.llm_gateway.app.services.upstream import AdapterRegistry
from studyagent.llm_gateway.app.services.gateway import Gateway

async def main():
    s=settings();calls=[]
    content=wire({'choices':[{'delta':{'content':'ok'}}]})
    for n in [11,13]:content+=wire({'choices':[],'usage':{'prompt_tokens':n,'completion_tokens':7,'prompt_tokens_details':{'cached_tokens':3},'completion_tokens_details':{'reasoning_tokens':2}}})
    content+=wire({'choices':[{'delta':{},'finish_reason':'stop'}]})+b'data: [DONE]\n\n'
    def handler(r):calls.append(1);return httpx.Response(200,content=content)
    g=Gateway(s,adapters=AdapterRegistry(s,transport=httpx.MockTransport(handler)))
    ctx=g.make_context();events=[e.type async for e in g.stream(req(stream=True),ctx)]
    record=g.store.get_call('local',ctx.call_id)
    assert record['usage']=={'input_tokens':13,'output_tokens':7,'cached_tokens':3,'reasoning_tokens':2}
    print(json.dumps({'case':'F07-cumulative-snapshots','events':events,'usage':record['usage'],'expected_total':20,'calls':len(calls)}))
    await g.close()
asyncio.run(main())
