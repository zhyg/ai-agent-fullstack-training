# G20261786020031 教师证据复现

固定源 master c6f5a7ae268f963f198b704e653b6851fd537a53，source/ 来自 git archive，不含 .git 或未跟踪文件。

本次路径根为 /tmp/grade-G20261786020031；student 为克隆，layout/studyagent/llm_gateway 为指向 student 的外部符号链接。解包时可将 source 作为 student，按同样结构建立符号链接。venv 为 requirements-dev.txt 安装环境。所有真实 API key 从既有 DEEPSEEK_API_KEY 环境读取，不写文件。

教师实际执行命令：

```bash
git clone https://gitee.com/tony_tang_x/learnagent /tmp/grade-G20261786020031/student
uv venv /tmp/grade-G20261786020031/venv
uv pip install --python /tmp/grade-G20261786020031/venv/bin/python -r requirements-dev.txt
mkdir -p /tmp/grade-G20261786020031/layout/studyagent
ln -s /tmp/grade-G20261786020031/student /tmp/grade-G20261786020031/layout/studyagent/llm_gateway
```

之后以 /tmp/grade-G20261786020031/layout 为工作目录：

```bash
export PYTHONPATH=/tmp/grade-G20261786020031/layout
export GATEWAY_API_KEY=teacher-local-only
export DEEPSEEK_BASE_URL=https://api.deepseek.com
/tmp/grade-G20261786020031/venv/bin/python -m studyagent.llm_gateway.smoke
/tmp/grade-G20261786020031/venv/bin/python -m studyagent.llm_gateway.smoke --live
amp orb service start grade-g20031 --command 'env PYTHONPATH=/tmp/grade-G20261786020031/layout DEEPSEEK_BASE_URL=https://api.deepseek.com DEEPSEEK_MODEL=deepseek-flash GATEWAY_API_KEY=teacher-local-only GATEWAY_DATABASE=/tmp/grade-G20261786020031/live-v4.db GATEWAY_PORT=8031 /tmp/grade-G20261786020031/venv/bin/python -m studyagent.llm_gateway.app.main' --port 8031
/tmp/grade-G20261786020031/venv/bin/python /tmp/grade-G20261786020031/evidence/teacher.py
/tmp/grade-G20261786020031/venv/bin/python /tmp/grade-G20261786020031/evidence/probe.py
/tmp/grade-G20261786020031/venv/bin/python /tmp/grade-G20261786020031/evidence/replay.py
/tmp/grade-G20261786020031/venv/bin/python /tmp/grade-G20261786020031/evidence/snapshots.py
amp orb service stop grade-g20031
```

从 student 目录运行 pytest（PYTHONPATH 同上），完整原测试 211 passed。故障注入独立进程使用 `PYTHONPATH=/tmp/grade-G20261786020031/layout:/tmp/grade-G20261786020031/evidence python -m pytest -q -p fault_plugin 'tests/test_adapters.py::test_complete_translation_and_base_path[chat]'`，预期退出1、1 failed。

脚本 teacher.py 中 controlled() 全部为受控上游，走学生原HTTP服务和协议适配器；live() 只访问上述本地网关及固定官方域名，新增 pro Responses 路由仅驻内存。probe.py 仅获取官方单次流事件，无鉴权头归档。replay.py、snapshots.py 完全离线。

日志/结果均为最终有效运行；开发教师脚本期间发生的路径、数据类使用错误已修正，不计为学生缺陷。teacher.log 是最终 teacher_exit=0 的日志；F12故意失败另存，不混入211通过结论。
