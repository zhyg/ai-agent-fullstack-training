import asyncio, json, os, time
from pathlib import Path
import httpx, uvicorn
from studyagent.llm_gateway.app.config import Settings, Target, Capabilities, ModelRoute
from studyagent.llm_gateway.app.schemas import ModelRequest, GatewayError
from studyagent.llm_gateway.app.services.gateway import Gateway
from studyagent.llm_gateway.app.services.upstream import AdapterRegistry
from studyagent.llm_gateway.app.api.routes import create_app

OUT=Path(__file__).parent
os.environ['GATEWAY_API_KEY']='teacher-local-only'
os.environ['TEACHER_DUMMY']='offline-only'
records=[]
def record(case, **data):
    item={'case':case, **data}; records.append(item); print(json.dumps(item,ensure_ascii=False),flush=True)
def settings(**extra):
    targets=[Target(id=a,provider=a,model='up-'+a,base_url='https://mock.invalid/v1',
        api_key_env='TEACHER_DUMMY',capabilities=Capabilities(apis={api},structured='json_mode'),retries=2)
        for a,api in [('a','chat'),('b','responses')]]
    return Settings(targets=targets,models={a:ModelRoute(targets=[a]) for a in ['a','b']},
        database=':memory:',cache_ttl=0,max_repairs=1,circuit_threshold=20,**extra)
def payload(api,text='{"ok":true}',finish='stop'):
    usage={'input_tokens':11,'output_tokens':7,'total_tokens':18,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}
    if api=='chat':
        return {'id':'mock-chat','choices':[{'message':{'content':text},'finish_reason':finish}],
            'usage':{'prompt_tokens':11,'completion_tokens':7,'total_tokens':18,'prompt_tokens_details':{'cached_tokens':3},'completion_tokens_details':{'reasoning_tokens':2}}}
    return {'id':'mock-responses','status':'incomplete' if finish=='length' else 'completed',
        'incomplete_details':{'reason':'max_output_tokens'} if finish=='length' else None,
        'output':[{'type':'message','content':[{'type':'output_text','text':text}]}],'usage':usage}
def wire(obj): return ('data: '+json.dumps(obj,ensure_ascii=False)+'\n\n').encode()
def req(api='chat',**extra):
    return ModelRequest(requested_model='a' if api=='chat' else 'b',api=api,
        messages=[{'role':'user','content':'probe'}],max_output_tokens=64,**extra)
async def controlled():
    state={'mode':'ok','calls':[],'gate':asyncio.Event(),'ended':False}
    class Stream(httpx.AsyncByteStream):
        async def __aiter__(self):
            api=state['api']
            yield b': heartbeat\n\n'
            await asyncio.sleep(.03)
            yield wire({'choices':[{'delta':{'content':'你好'}}]} if api=='chat' else {'type':'response.output_text.delta','delta':'你好'})
            await state['gate'].wait()
            if state['mode']=='interrupt': raise httpx.ReadError('controlled disconnect')
            yield wire({'choices':[{'delta':{},'finish_reason':'stop'}]} if api=='chat' else {'type':'response.completed','response':payload(api)})
            if api=='chat':
                yield wire({'choices':[],'usage':payload(api)['usage']})+b'data: [DONE]\n\n'
            state['ended']=True
        async def aclose(self): pass
    def handler(r):
        body=json.loads(r.content); api='responses' if r.url.path.endswith('responses') else 'chat'
        state['calls'].append({'path':r.url.path,'body':body,'time':time.monotonic()})
        if body.get('stream'):
            state['api']=api; return httpx.Response(200,stream=Stream())
        mode=state['mode']
        if mode in ['retry','persistent','auth']:
            n=len(state['calls'])
            if mode=='auth':return httpx.Response(401,json={'error':{}})
            if mode=='persistent' or n<=2:return httpx.Response(503,json={'error':{}})
        text={'bad':'not-json','empty':'','cut':'{"ok":','schema':'{"ok":"wrong"}'}.get(mode,'{"ok":true}')
        return httpx.Response(200,json=payload(api,text,'length' if mode=='length' else 'stop'),headers={'x-request-id':'mock-provider-id'})
    s=settings(backoff=.05,burst=1000,qps=1000); adapter=AdapterRegistry(s,transport=httpx.MockTransport(handler)); waits=[]
    async def sleep(n): waits.append(n)
    g=Gateway(s,adapters=adapter,sleep=sleep); app=create_app(gateway=g)
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=18031,log_level='error',lifespan='off'))
    task=asyncio.create_task(server.serve())
    while not server.started: await asyncio.sleep(.01)
    headers={'Authorization':'Bearer teacher-local-only'}
    schema={'type':'object','properties':{'ok':{'const':True}},'required':['ok']}
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18031',headers=headers,timeout=5) as c:
        for api,model in [('chat','a'),('responses','b')]:
            endpoint='/v1/chat/completions' if api=='chat' else '/v1/responses'
            body={'model':model,**({'messages':[{'role':'user','content':'probe'}]} if api=='chat' else {'input':'probe'})}
            r=await c.post(endpoint,json=body)
            record('A03-'+api,status=r.status_code,request=state['calls'][-1],response=r.json())
            if api=='chat':
                wrong=await c.post(endpoint,json={**body,'model':'b'})
                record('A02-same-entry',status=wrong.status_code,result=wrong.json())
                unknown=await c.post(endpoint,json={**body,'model':'missing'})
                record('A04',status=unknown.status_code,result=unknown.json())
            for mode in ['ok','bad','empty','cut','schema','length']:
                state['mode']=mode;state['calls']=[]
                fmt={'response_format':{'type':'json_schema','json_schema':{'name':'probe','schema':schema}}} if api=='chat' else {'text':{'format':{'type':'json_schema','name':'probe','schema':schema}}}
                r=await c.post(endpoint,json={**body,**fmt})
                record('F03' if mode=='ok' else 'F04',api=api,mode=mode,status=r.status_code,result=r.json(),calls=len(state['calls']))
            for mode in ['ok','interrupt']:
                state.update(mode=mode,calls=[],ended=False,gate=asyncio.Event())
                async with c.stream('POST',endpoint,json={**body,'stream':True}) as r:
                    lines=r.aiter_lines(); received=[]
                    async def first_text():
                        async for line in lines:
                            received.append(line)
                            if '你好' in line:return
                    await asyncio.wait_for(first_text(),2)
                    before=not state['ended'];state['gate'].set()
                    received.extend([line async for line in lines])
                record('F01' if mode=='ok' else 'F02',api=api,received_before_terminal=before,lines=received,calls=len(state['calls']))
        state['mode']='ok'
        for version in [1,2]:
            r=await c.post('/v1/prompts',json={'id':'teacher','system':f'v{version} Hello {{{{name}}}}','input_schema':{'type':'object','properties':{'name':{'type':'string'}},'required':['name']}})
            record('F05-publish',version=version,status=r.status_code)
        body={'model':'a','messages':[{'role':'user','content':'probe'}]}
        for ref in [{'id':'teacher','version':1,'variables':{'name':'甲'}},{'id':'teacher','version':2,'variables':{'name':'乙'}},{'id':'missing'},{'id':'teacher','version':99},{'id':'teacher','variables':{}}]:
            state['calls']=[];r=await c.post('/v1/chat/completions',json={**body,'prompt':ref})
            record('F05' if r.status_code==200 else 'F06',ref=ref,status=r.status_code,result=r.json(),upstream=state['calls'])
        for mode in ['retry','persistent','auth']:
            state.update(mode=mode,calls=[]);waits.clear()
            r=await c.post('/v1/chat/completions',json=body)
            record('F08' if mode=='retry' else 'F09',mode=mode,status=r.status_code,calls=len(state['calls']),waits=list(waits),result=r.json())
        state['mode']='ok';g.governance.buckets.clear();s.burst=1;s.qps=10
        statuses=[]
        # In-process client avoids network overhead while exercising full HTTP mapping.
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test',headers=headers) as fast:
            for model,endpoint,fields in [('a','/v1/chat/completions',{'messages':body['messages']}),('a','/v1/chat/completions',{'messages':body['messages']}),('b','/v1/responses',{'input':'probe'})]:
                r=await fast.post(endpoint,json={'model':model,**fields});statuses.append(r.status_code)
            record('F10',sequence=['A','A','B'],statuses=statuses)
            await asyncio.sleep(.12)
            r=await fast.post('/v1/chat/completions',json=body);record('F11',status=r.status_code)
        record('F07',calls=g.store.list_calls('local'),attempts={r['call_id']:g.store.attempts('local',r['call_id']) for r in g.store.list_calls('local')})
    server.should_exit=True;await task;await g.close()

async def live():
    # Only the official DeepSeek host and pre-existing environment credential.
    results=[]
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8031',headers={'Authorization':'Bearer teacher-local-only'},timeout=45) as c:
        for name,extra in [('chat',{}),('stream',{'stream':True,'stream_options':{'include_usage':True}}),('structured',{'response_format':{'type':'json_schema','json_schema':{'name':'probe','schema':{'type':'object','required':['ok'],'properties':{'ok':{'type':'boolean'}}}}}})]:
            start=time.monotonic()
            r=await c.post('/v1/chat/completions',json={'model':'default','messages':[{'role':'user','content':'Return only JSON: {"ok":true}'}],'max_tokens':96,**extra})
            results.append({'case':name,'status':r.status_code,'request_id':r.headers.get('x-request-id'),'elapsed_ms':(time.monotonic()-start)*1000,'body':r.text})
        traces=await c.get('/admin/traces')
        results.append({'traces':traces.json()})
    s=Settings(targets=[Target(id='official-responses',provider='deepseek',model='deepseek-v4-pro',base_url='https://api.deepseek.com',extra_body={'thinking':{'type':'disabled'}},retries=0,timeout=20,capabilities=Capabilities(apis={'responses'}))],models={'b':ModelRoute(targets=['official-responses'])},database=':memory:',max_attempts=1,max_repairs=0,deadline=25)
    g=Gateway(s)
    start=time.monotonic();ctx=g.make_context()
    try:
        for name in ['chat','stream','structured']:
            ctx=g.make_context(); start=time.monotonic()
            request=ModelRequest.model_validate({**req('responses').model_dump(),'messages':[{'role':'user','content':'Return only JSON: {"ok":true}'}],'max_output_tokens':256})
            if name=='structured':request=request.model_copy(update={'output_schema':{'type':'object','required':['ok'],'properties':{'ok':{'const':True}}}})
            if name=='stream':
                events=[e async for e in g.stream(request.model_copy(update={'stream':True}),ctx)]
                result={'events':[{'type':e.type,'data':e.data} for e in events]}
            else:
                value=await g.complete(request,ctx)
                result={'text':value.text,'data':value.data,'response_id':value.response_id,'provider_request_id':value.provider_request_id,'usage':value.usage.model_dump(),'resolved_model':value.resolved_model}
            results.append({'case':'official-responses-'+name,'elapsed_ms':(time.monotonic()-start)*1000,'call_id':ctx.call_id,'result':result,'record':g.store.get_call('local',ctx.call_id),'attempts':g.store.attempts('local',ctx.call_id)})
    except GatewayError as e:
        results.append({'case':'official-responses','status':e.status,'error':e.code,'elapsed_ms':(time.monotonic()-start)*1000,'call_id':ctx.call_id,'record':g.store.get_call('local',ctx.call_id)})
    finally:await g.close()
    (OUT/'live-detail.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    record('A02-live-summary',results=[{k:v for k,v in r.items() if k not in ['body','traces','record','result']} for r in results])

async def main():
    await controlled();await live()
    (OUT/'teacher-results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
if __name__=='__main__':asyncio.run(main())
