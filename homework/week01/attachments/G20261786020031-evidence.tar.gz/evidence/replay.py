import asyncio,json,os
from pathlib import Path
import httpx
from studyagent.llm_gateway.app.config import Settings,Target,Capabilities,ModelRoute
from studyagent.llm_gateway.app.services.upstream import AdapterRegistry
from studyagent.llm_gateway.app.services.gateway import Gateway
from studyagent.llm_gateway.app.schemas import ModelRequest

async def main():
    os.environ['REPLAY_DUMMY']='offline'
    wire=json.loads(Path(__file__).with_name('official-responses-wire.json').read_text())
    raw='\n\n'.join(x for x in wire if isinstance(x,str) and x.startswith('data:')).encode()+b'\n\n'
    target=Target(id='r',provider='mock',model='replay',base_url='https://mock.invalid',api_key_env='REPLAY_DUMMY',capabilities=Capabilities(apis={'responses'}))
    s=Settings(targets=[target],models={'default':ModelRoute(targets=['r'])},database=':memory:')
    calls=[]
    def handler(request):calls.append(1);return httpx.Response(200,content=raw)
    g=Gateway(s,adapters=AdapterRegistry(s,transport=httpx.MockTransport(handler)))
    events=[{'type':e.type,'data':e.data} async for e in g.stream(ModelRequest(api='responses',stream=True,messages=[{'role':'user','content':'probe'}]))]
    print(json.dumps({'case':'official-wire-offline-replay','events':events,'calls':len(calls)},ensure_ascii=False))
    await g.close()
asyncio.run(main())
