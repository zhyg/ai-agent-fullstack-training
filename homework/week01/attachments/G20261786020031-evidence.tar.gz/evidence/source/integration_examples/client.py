"""CLI and IDE use the exact persisted RunEvent contract consumed by /demo."""
from __future__ import annotations
import argparse
import asyncio
import json
import os
import logging
import time
import httpx
from ..app.services.sse import SSEParser
from ..app.schemas import GatewayError

client_clock = time.perf_counter
KNOWN_EVENTS = {
    "run.created", "run.started", "run.completed", "run.failed", "run.cancelled",
    "text.delta", "tool.delta", "refusal.delta", "model.usage", "model.finished",
    "completed", "failed", "cancelled",
}
RUN_TERMINALS = {"run.completed", "run.failed", "run.cancelled"}


class RunClient:
    def __init__(self, base_url, api_key):
        self.timings = {}
        self._created_at = {}
        self.http = httpx.AsyncClient(base_url=base_url, headers={'Authorization':'Bearer '+api_key},timeout=60)

    def _metrics(self, run_id):
        return self.timings.setdefault(run_id, {
            'clock':'client_monotonic', 'create_to_first_text_ms':None,
            'create_to_terminal_ms':None, 'subscriptions':[],
        })

    async def create(self, text, model='default'):
        started=client_clock()
        response=await self.http.post('/v1/runs',json={'model':model,'messages':[{'role':'user','content':text}]})
        response.raise_for_status()
        result=response.json()
        self._created_at[result['run_id']]=started
        self._metrics(result['run_id'])
        return result

    @staticmethod
    def _event(frame):
        try:
            event=json.loads(frame['data'])
        except (ValueError,TypeError):
            raise GatewayError('invalid_run_event','Run 事件不是有效 JSON',502,stage='protocol') from None
        if not isinstance(event,dict):
            raise GatewayError('invalid_run_event','Run 事件格式无效',502,stage='protocol')
        if type(event.get('schema_version')) is not int or event['schema_version']!=1:
            raise GatewayError('unsupported_event_version','不支持的 Run 事件版本，已停止订阅',502,stage='protocol')
        if type(event.get('seq')) is not int or not isinstance(event.get('type'),str):
            raise GatewayError('invalid_run_event','Run 事件位置或类型无效',502,stage='protocol')
        if event['type'] not in KNOWN_EVENTS:
            # Event consumption never executes commands or tools, including future events.
            logging.getLogger(__name__).warning('Unknown Run event type: %r; forwarding as data only',event['type'])
        return event

    async def events(self, run_id, after=-1):
        parser=SSEParser(max_event_bytes=1_048_576)
        started=client_clock()
        metrics=self._metrics(run_id)
        subscription={'after':after,'replay':after>=0,'first_text_ms':None,'elapsed_ms':None}
        metrics['subscriptions'].append(subscription)
        def record(event):
            now=client_clock()
            delta=event.get('data',{}).get('delta') if isinstance(event.get('data'),dict) else None
            if event['type']=='text.delta' and isinstance(delta,str) and delta.strip():
                if subscription['first_text_ms'] is None: subscription['first_text_ms']=(now-started)*1000
                if run_id in self._created_at and metrics['create_to_first_text_ms'] is None:
                    metrics['create_to_first_text_ms']=(now-self._created_at[run_id])*1000
            if event['type'] in RUN_TERMINALS and run_id in self._created_at and metrics['create_to_terminal_ms'] is None:
                metrics['create_to_terminal_ms']=(now-self._created_at[run_id])*1000
        try:
            async with self.http.stream('GET',f'/v1/runs/{run_id}/events',headers={'Last-Event-ID':str(after)}) as response:
                response.raise_for_status()
                async for chunk in response.aiter_bytes():
                    for frame in parser.feed(chunk):
                        if not frame.get('data'): continue
                        event=self._event(frame)
                        if event['seq']<=after: continue
                        after=event['seq']
                        record(event)
                        yield event
                for frame in parser.finish():
                    if not frame.get('data'): continue
                    event=self._event(frame)
                    if event['seq']<=after: continue
                    after=event['seq']
                    record(event)
                    yield event
        except ValueError as error:
            code='stream_event_too_large' if str(error)=='SSE event exceeds buffer limit' else 'invalid_event_stream'
            raise GatewayError(code,'Run 事件流格式无效或超过缓冲上限',502,stage='protocol') from None
        finally:
            subscription['elapsed_ms']=(client_clock()-started)*1000

    async def cancel(self,run_id):
        response=await self.http.post(f'/v1/runs/{run_id}/cancel')
        response.raise_for_status()
        return response.json()

    async def close(self): await self.http.aclose()


async def main():
    parser=argparse.ArgumentParser(description='Create or reconnect to a Gateway Run')
    parser.add_argument('text',nargs='?',default='你好')
    parser.add_argument('--url',default='http://127.0.0.1:8003')
    parser.add_argument('--run-id');parser.add_argument('--after',type=int,default=-1)
    args=parser.parse_args()
    client=RunClient(args.url,os.environ.get('GATEWAY_API_KEY',''))
    try:
        run_id=args.run_id or (await client.create(args.text))['run_id']
        print(json.dumps({'run_id':run_id},ensure_ascii=False))
        try:
            async for event in client.events(run_id,args.after): print(json.dumps(event,ensure_ascii=False))
        finally:
            print(json.dumps({'client_timings':client.timings.get(run_id)},ensure_ascii=False))
    finally: await client.close()


if __name__=='__main__': asyncio.run(main())
