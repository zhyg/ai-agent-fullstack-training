"""Run: python -m studyagent.llm_gateway.integration_examples.evaluate (offline)."""
import asyncio
import json
from ..app.schemas import ModelResult, GatewayError
from .loop import MinimalLoop


class ScriptedPort:
    def __init__(self,results):
        self.results=iter(results)
    async def complete(self,request,context=None):
        return next(self.results)


def tool_call(arguments='{"query":"gateway"}'):
    return ModelResult(kind="tool_calls",tool_calls=[{"id":"demo","type":"function",
        "function":{"name":"lookup_note","arguments":arguments}}])


async def evaluate():
    cases=[]
    loop=MinimalLoop(ScriptedPort([tool_call(),ModelResult(text="LLM Gateway 提供统一模型入口。")]))
    result=await loop.run("解释 LLM Gateway")
    cases.append({"case":"工具选择、参数、回填与答案","passed":
                  result["tool_executions"]==1 and "统一模型入口" in result["answer"]})
    for label,results,code in [
        ("重复动作保护",[tool_call(),tool_call()],"repeated_action"),
        ("非法动作零执行",[tool_call('{"query":"gateway","execute":"anything"}')],"invalid_tool_arguments")]:
        loop=MinimalLoop(ScriptedPort(results))
        try:
            await loop.run("解释网关")
            ok=False
        except GatewayError as exc:
            ok=exc.code==code and (label!="非法动作零执行" or loop.tool_executions==0)
        cases.append({"case":label,"passed":ok})
    return {"mode":"offline-fixed-cases","total":len(cases),
            "passed":sum(c["passed"] for c in cases),"cases":cases}


if __name__=="__main__":
    report=asyncio.run(evaluate())
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(0 if report["passed"]==report["total"] else 1)
