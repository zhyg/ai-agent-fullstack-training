"""Trusted Harness example: deterministic, Run-pinned Prompt version rollout.

Call this before building ModelRequest; pass the returned explicit PromptRef to
PromptService/Gateway. The Harness shares and persists CallContext.snapshots with
its Run checkpoint when restart stability is required. This helper creates no API,
background task, model call, or publication platform.
"""
from __future__ import annotations

import copy
import hashlib
import json
from typing import Any

from ..app.schemas import CallContext, GatewayError, PromptRef
from ..app.services.usage import valid_id


def select_prompt_version(store, context: CallContext, prompt_id: str, *,
                          baseline: int, candidate: int, percentage: int,
                          variables: dict[str, Any] | None = None) -> PromptRef:
    """Freeze the first valid selection for (tenant, Run, Prompt).

    SHA-256 of the canonical [tenant, run_id] JSON gives a stable bucket 0..99.
    A bucket below percentage selects candidate; all others select baseline.
    Configuration comes from the trusted Harness, never request JSON. Existing
    decisions retain their original reason, ratio, version, and immutable hash.
    """
    valid_id(prompt_id)
    if (not context.run_id or type(baseline) is not int or baseline < 1 or
            type(candidate) is not int or candidate < 1 or
            type(percentage) is not int or not 0 <= percentage <= 100):
        raise GatewayError('invalid_prompt_rollout', 'Prompt 灰度配置或 Run 上下文无效', 400, stage='prompt')
    valid_id(context.run_id)
    tenant = context.identity.tenant
    key = json.dumps([tenant, context.run_id, prompt_id], ensure_ascii=False, separators=(',', ':'))
    decisions = context.snapshots.setdefault('rollout', {})
    if key not in decisions:
        cohort = json.dumps([tenant, context.run_id], ensure_ascii=False, separators=(',', ':'))
        bucket = int.from_bytes(hashlib.sha256(cohort.encode('utf-8')).digest(), 'big') % 100
        selected = candidate if bucket < percentage else baseline
        # Resolve an explicit immutable version before recording any decision.
        bundle = store.get_prompt(tenant, prompt_id, selected)
        decisions[key] = {'tenant': tenant, 'run_id': context.run_id, 'prompt_id': prompt_id,
                          'baseline': baseline, 'candidate': candidate, 'percentage': percentage,
                          'bucket': bucket, 'version': selected, 'hash': bundle['hash'],
                          'reason': 'candidate_bucket' if bucket < percentage else 'baseline_bucket'}
    decision = decisions[key]
    return PromptRef(id=prompt_id, version=decision['version'], variables=copy.deepcopy(variables or {}))
