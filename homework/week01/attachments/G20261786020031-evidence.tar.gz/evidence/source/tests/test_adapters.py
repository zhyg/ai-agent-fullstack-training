import asyncio
import json

import httpx
import pytest

from studyagent.llm_gateway.app.services import upstream as adapters
from studyagent.llm_gateway.app.config import Capabilities, ModelRoute, Settings, Target
from studyagent.llm_gateway.app.schemas import GatewayError, Message, ModelEvent, ModelRequest, ModelResult


def target(api='chat', structured='native_schema'):
    return Target(id='test', provider='offline', model='actual', base_url='https://provider.invalid/proxy/v1',
                  api_key_env='ADAPTER_TEST_KEY', capabilities=Capabilities(apis={api}, structured=structured))


def request(api='chat', **kw):
    return ModelRequest(messages=[Message(role='user', content='你好')], api=api, **kw)


def registry(t, handler):
    return adapters.AdapterRegistry(Settings(targets=[t], models={'default': ModelRoute(targets=[t.id])}),
                                    transport=httpx.MockTransport(handler))


@pytest.fixture(autouse=True)
def credential(monkeypatch):
    monkeypatch.setenv('ADAPTER_TEST_KEY', 'offline-dummy')


@pytest.mark.parametrize('api', ['chat', 'responses'])
def test_complete_translation_and_base_path(api):
    def handler(req):
        body = json.loads(req.content)
        assert str(req.url) == 'https://provider.invalid/proxy/v1/' + ('responses' if api == 'responses' else 'chat/completions')
        assert body['model'] == 'actual'
        if api == 'chat':
            assert body['response_format']['type'] == 'json_schema'
            payload = {'id': 'r1', 'choices': [{'message': {'content': '答案', 'refusal': None,
                        'tool_calls': [{'id': 'c1', 'type': 'function', 'function': {'name': 'lookup', 'arguments': '{}'}}]},
                        'finish_reason': 'tool_calls'}], 'usage': {'prompt_tokens': 5, 'completion_tokens': 2}}
        else:
            assert body['text']['format']['type'] == 'json_schema'
            assert body['input'][0]['role'] == 'user'
            payload = {'id': 'r1', 'status': 'completed', 'output': [
                {'type': 'message', 'role': 'assistant', 'content': [{'type': 'output_text', 'text': '答案'}]},
                {'type': 'function_call', 'call_id': 'c1', 'name': 'lookup', 'arguments': '{}'}],
                'usage': {'input_tokens': 5, 'output_tokens': 2}}
        return httpx.Response(200, json=payload, headers={'x-request-id': 'p1'})
    async def run():
        r = registry(target(api), handler)
        try:
            result = await r.complete(target(api), request(api, output_schema={'type': 'object'}))
            assert result.text == '答案'
            assert result.tool_calls[0]['function']['name'] == 'lookup'
            assert result.usage.input_tokens == 5
            assert result.usage.output_tokens == 2
            assert result.provider_request_id == 'p1'
            assert result.finish_reason == 'tool_calls'
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('status,code,retryable', [(401,'upstream_auth_error',False), (400,'upstream_invalid_request',False),
                                                  (429,'upstream_rate_limited',True),(503,'upstream_unavailable',True)])
def test_http_errors_safe_and_no_internal_retry(status, code, retryable):
    seen = []
    def handler(req):
        seen.append(req)
        return httpx.Response(status, text='secret-value should never escape')
    async def run():
        r = registry(target(), handler)
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(target(), request())
            assert exc.value.code == code
            assert exc.value.retryable is retryable
            assert 'secret-value' not in str(exc.value)
            assert len(seen) == 1
        finally:
            await r.close()
    asyncio.run(run())


class BytesStream(httpx.AsyncByteStream):
    def __init__(self, content):
        self.content, self.closed = content, False
    async def __aiter__(self):
        for value in self.content:
            yield bytes([value])
    async def aclose(self):
        self.closed = True


def wire(payload):
    return ('data: ' + json.dumps(payload, ensure_ascii=False) + '\r\n\r\n').encode()


@pytest.mark.parametrize('api', ['chat', 'responses'])
def test_stream_translates_events_and_preserves_late_usage(api):
    if api == 'chat':
        content = wire({'id':'r1','choices':[{'delta':{'role':'assistant'}, 'finish_reason':None}]})
        content += wire({'choices':[{'delta':{'content':'你好'}, 'finish_reason':None}]})
        content += wire({'choices':[{'delta':{}, 'finish_reason':'stop'}]})
        content += wire({'choices':[], 'usage':{'prompt_tokens':4,'completion_tokens':2}})
        content += b'data: [DONE]\n\n'
    else:
        content = wire({'type':'response.output_text.delta','delta':'你好'})
        content += wire({'type':'response.completed','response':{'id':'r1','status':'completed','usage':{'input_tokens':4,'output_tokens':2}}})
    source = BytesStream(content)
    async def run():
        r = registry(target(api), lambda req: httpx.Response(200, stream=source))
        try:
            events = [e async for e in r.stream(target(api), request(api, stream=True))]
            assert [e.data['delta'] for e in events if e.type == 'text.delta'] == ['你好']
            assert [e.data['input_tokens'] for e in events if e.type == 'model.usage'] == [4]
            assert events[-1].type == 'model.finished'
            assert source.closed
        finally:
            await r.close()
    asyncio.run(run())


def test_stream_eof_failure_and_early_close_release_response():
    async def run():
        for early in [False, True]:
            source = BytesStream(wire({'choices':[{'delta':{'content':'partial'},'finish_reason':None}]}))
            r = registry(target(), lambda req: httpx.Response(200, stream=source))
            iterator = r.stream(target(), request(stream=True))
            try:
                if early:
                    assert (await anext(iterator)).type == 'text.delta'
                    await iterator.aclose()
                else:
                    with pytest.raises(GatewayError) as exc:
                        [event async for event in iterator]
                    assert exc.value.code == 'upstream_stream_incomplete'
                assert source.closed
            finally:
                await r.close()
    asyncio.run(run())


def test_done_marker_without_finish_reason_cannot_claim_success():
    async def run():
        source=BytesStream(wire({'choices':[{'delta':{'content':'partial'}}]})+b'data: [DONE]\n\n')
        r=registry(target(),lambda req:httpx.Response(200,stream=source))
        try:
            with pytest.raises(GatewayError) as exc:
                [e async for e in r.stream(target(),request(stream=True))]
            assert exc.value.code=='upstream_stream_incomplete'
            assert source.closed
        finally:await r.close()
    asyncio.run(run())


def test_fake_results_calls_and_error_identity():
    async def run():
        error = GatewayError('test', 'safe', 503, True)
        fake = adapters.FakeAdapter(results=[ModelResult(text='ok'), error], events=[ModelEvent('text.delta', {'delta':'x'})])
        assert (await fake.complete(target(), request())).text == 'ok'
        with pytest.raises(GatewayError) as exc:
            await fake.complete(target(), request())
        assert exc.value is error
        assert len(fake.calls) == 2
        assert [e.type async for e in fake.stream(target(), request())] == ['text.delta']
    asyncio.run(run())


@pytest.mark.parametrize('api', ['chat', 'responses'])
@pytest.mark.parametrize('mode', ['json_mode', 'prompt_only'])
def test_schema_modes_and_responses_tool_history(api, mode):
    def handler(req):
        body = json.loads(req.content)
        if api == 'chat':
            assert 'matching this schema' in body['messages'][0]['content']
            assert body.get('response_format') == ({'type':'json_object'} if mode == 'json_mode' else None)
            payload = {'choices':[{'message':{'content':None,'refusal':'cannot answer'}, 'finish_reason':'stop'}]}
        else:
            assert body['input'][-2] == {'type':'function_call', 'call_id':'c1', 'name':'lookup', 'arguments':'{}'}
            assert body['input'][-1] == {'type':'function_call_output','call_id':'c1','output':'found'}
            assert body.get('text') == ({'format':{'type':'json_object'}} if mode == 'json_mode' else None)
            payload = {'status':'completed','output':[{'type':'message','content':[{'type':'refusal','refusal':'cannot answer'}]}]}
        return httpx.Response(200, json=payload)
    async def run():
        t = target(api, mode)
        r = registry(t, handler)
        req = request(api, output_schema={'type':'object'})
        req.messages += [Message(role='assistant', tool_calls=[{'id':'c1','type':'function','function':{'name':'lookup','arguments':'{}'}}]),
                         Message(role='tool', content='found', tool_call_id='c1')]
        try:
            result = await r.complete(t, req)
            assert result.refusal == 'cannot answer'
            assert result.kind == 'refusal'
        finally:
            await r.close()
    asyncio.run(run())


def test_capability_rejection_without_any_upstream_attempt():
    async def run():
        t = target(structured='json_mode')
        def forbidden(req):
            raise AssertionError('capability mismatch must not reach transport')
        r = registry(t, forbidden)
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(t, request(output_schema={'type':'object'}, native_schema_required=True))
            assert exc.value.code == 'capability_unsupported'
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('payload,code', [({},'upstream_empty_response'),
    ({'choices':[{'message':{},'finish_reason':'stop'}]},'upstream_empty_response'),
    ({'choices':[{'message':{'content':'x'}}]},'upstream_invalid_response')])
def test_malformed_and_empty_response(payload, code):
    async def run():
        r = registry(target(), lambda req: httpx.Response(200,json=payload))
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(target(), request())
            assert exc.value.code == code
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('api', ['chat','responses'])
def test_truncation_and_detailed_usage_preserved(api):
    if api == 'chat':
        payload = {'choices':[{'message':{'content':'partial'},'finish_reason':'length'}],
                   'usage':{'prompt_tokens':9,'completion_tokens':5,'prompt_tokens_details':{'cached_tokens':3},'completion_tokens_details':{'reasoning_tokens':2}}}
    else:
        payload = {'status':'incomplete','incomplete_details':{'reason':'max_output_tokens'},
                   'output':[{'type':'message','content':[{'type':'output_text','text':'partial'}]}],
                   'usage':{'input_tokens':9,'output_tokens':5,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}}
    async def run():
        r = registry(target(api), lambda req: httpx.Response(200,json=payload))
        try:
            result = await r.complete(target(api), request(api))
            assert result.finish_reason == 'length'
            assert result.usage.cached_tokens == 3
            assert result.usage.reasoning_tokens == 2
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('error,code', [(httpx.ReadTimeout('secret'), 'upstream_timeout'),(httpx.ConnectError('secret'),'upstream_network_error')])
def test_network_error_sanitization(error, code):
    def handler(req):
        raise error
    async def run():
        r = registry(target(), handler)
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(target(), request())
            assert exc.value.code == code
            assert exc.value.retryable
            assert 'secret' not in str(exc.value)
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('api',['chat','responses'])
def test_stream_tool_and_refusal_translation(api):
    if api == 'chat':
        payloads = [{'choices':[{'delta':{'tool_calls':[{'index':0,'id':'call1','function':{'name':'lookup','arguments':'{'}}]}}]},
                    {'choices':[{'delta':{'tool_calls':[{'index':0,'function':{'arguments':'}'}}],'refusal':'refused'},'finish_reason':'tool_calls'}]}]
    else:
        payloads = [{'type':'response.output_item.added','output_index':0,'item':{'type':'function_call','call_id':'call1','name':'lookup','arguments':''}},
                    {'type':'response.function_call_arguments.delta','output_index':0,'delta':'{}'},
                    {'type':'response.refusal.delta','delta':'refused'},
                    {'type':'response.completed','response':{'status':'completed'}}]
    source = BytesStream(b''.join(wire(p) for p in payloads))
    async def run():
        r = registry(target(api),lambda req: httpx.Response(200,stream=source))
        try:
            events = [e async for e in r.stream(target(api),request(api))]
            tools = [e.data for e in events if e.type == 'tool.delta']
            assert tools[0]['name'] == 'lookup'
            assert tools[0]['id'] == 'call1'
            assert ''.join(t['arguments'] for t in tools) == '{}'
            assert next(e.data['delta'] for e in events if e.type == 'refusal.delta') == 'refused'
            assert events[-1].data['finish_reason'] == 'tool_calls'
        finally:
            await r.close()
    asyncio.run(run())


def test_responses_done_without_completed_is_incomplete():
    source = BytesStream(b'data: [DONE]\n\n')
    async def run():
        r = registry(target('responses'),lambda req:httpx.Response(200,stream=source))
        try:
            with pytest.raises(GatewayError) as exc:
                [e async for e in r.stream(target('responses'),request('responses'))]
            assert exc.value.code == 'upstream_stream_incomplete'
            assert source.closed
        finally:
            await r.close()
    asyncio.run(run())


def test_terminal_marker_ignores_following_bytes_in_same_chunk():
    content = wire({'choices':[{'delta':{},'finish_reason':'stop'}]})
    content += b'data: [DONE]\n\n' + wire({'choices':[{'delta':{'content':'after terminal'}}]})
    async def run():
        r = registry(target(),lambda req:httpx.Response(200,content=content))
        try:
            events = [e async for e in r.stream(target(),request())]
            assert [e.type for e in events] == ['model.finished']
        finally:
            await r.close()
    asyncio.run(run())


def test_cancellation_closes_inflight_stream():
    class WaitingStream(httpx.AsyncByteStream):
        def __init__(self):
            self.reading = asyncio.Event()
            self.closed = False
        async def __aiter__(self):
            self.reading.set()
            await asyncio.Event().wait()
            yield b''
        async def aclose(self):
            self.closed = True
    async def run():
        source = WaitingStream()
        r = registry(target(),lambda req:httpx.Response(200,stream=source))
        async def consume():
            return [e async for e in r.stream(target(),request())]
        task = asyncio.create_task(consume())
        try:
            await source.reading.wait()
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            assert source.closed
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('api,payload', [
    ('chat', {'choices':[{'message':{'content':[{'type':'text','text':'ok'}, {'type':'image','url':'private'}]},'finish_reason':'stop'}]}),
    ('responses', {'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'ok'}, {'type':'output_audio','data':'private'}]}]}),
    ('responses', {'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'ok'}]}, {'type':'web_search_call','id':'private'}]}),
])
def test_mixed_supported_and_unsupported_output_fails_as_a_whole(api, payload):
    async def run():
        r = registry(target(api), lambda req:httpx.Response(200,json=payload))
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(target(api),request(api))
            assert exc.value.code == 'upstream_unsupported_content'
            assert not exc.value.retryable
            assert 'private' not in str(exc.value)
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('calls', [False, {}, 'bad', [None], ['bad'], [{}],
    [{'id':'c','type':'custom','custom':{'name':'x','input':'{}'}}],
    [{'id':'c','type':'function','function':None}],
    [{'id':'c','type':'function','function':{'name':'x','arguments':{}}}],
    [{'id':7,'type':'function','function':{'name':'x','arguments':'{}'}}]])
def test_malformed_chat_tool_calls_are_stable_errors(calls):
    async def run():
        payload={'choices':[{'message':{'content':'ok','tool_calls':calls},'finish_reason':'stop'}]}
        r=registry(target(),lambda req:httpx.Response(200,json=payload))
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(target(),request())
            assert exc.value.code == 'upstream_invalid_response'
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('event', [
    {'type':'response.unmapped_business.delta','delta':'private'},
    {'type':'response.output_item.added','item':{'type':'web_search_call'}},
    {'type':'response.output_item.done','item':{'type':'image_generation_call'}},
    {'type':'response.content_part.added','part':{'type':'output_audio'}},
    {'type':'response.content_part.done','part':{'type':'unknown_part'}},
    {'type':'response.completed','response':{'status':'completed','output':[{'type':'computer_call'}]}},
])
def test_responses_stream_unsupported_content_is_visible(event):
    content=wire({'type':'response.output_text.delta','delta':'ok'})+wire(event)
    content+=wire({'type':'response.completed','response':{'status':'completed'}})
    source=BytesStream(content)
    async def run():
        r=registry(target('responses'),lambda req:httpx.Response(200,stream=source))
        try:
            events=[]
            with pytest.raises(GatewayError) as exc:
                async for item in r.stream(target('responses'),request('responses')):
                    events.append(item)
            assert exc.value.code == 'upstream_unsupported_content'
            assert events[0].data == {'delta':'ok'}
            assert all(e.type != 'model.finished' for e in events)
            assert source.closed
        finally:
            await r.close()
    asyncio.run(run())


def test_responses_standard_metadata_and_reasoning_do_not_break_stream():
    message={'type':'message','role':'assistant','content':[{'type':'output_text','text':'ok'}]}
    part={'type':'output_text','text':'ok'}
    payloads=[{'type':'response.created','response':{'status':'in_progress'}},
              {'type':'response.in_progress'}, {'type':'response.queued'},
              {'type':'response.output_item.added','item':{'type':'reasoning','summary':[]}},
              {'type':'response.reasoning_summary_part.added','part':{'type':'summary_text','text':''}},
              {'type':'response.reasoning_summary_text.delta','delta':'reasoning metadata'},
              {'type':'response.reasoning_summary_text.done','text':'reasoning metadata'},
              {'type':'response.reasoning_summary_part.done','part':{'type':'summary_text','text':'reasoning metadata'}},
              {'type':'response.output_item.done','item':{'type':'reasoning','summary':[]}},
              {'type':'response.output_item.added','item':{'type':'message','content':[]}},
              {'type':'response.content_part.added','part':{'type':'output_text','text':''}},
              {'type':'response.output_text.delta','delta':'ok'},
              {'type':'response.output_text.done','text':'ok'},
              {'type':'response.content_part.done','part':part},
              {'type':'response.output_item.done','item':message},
              {'type':'response.completed','response':{'status':'completed','output':[message]}}]
    async def run():
        r=registry(target('responses'),lambda req:httpx.Response(200,content=b''.join(wire(p) for p in payloads)))
        try:
            events=[e async for e in r.stream(target('responses'),request('responses'))]
            assert [e.type for e in events] == ['text.delta','model.finished']
            assert events[0].data == {'delta':'ok'}
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('api,payload', [
    ('chat', {'choices':[{'message':{'content':[{'type':'text','text':'ok'}, {'type':'refusal','refusal':'no'}],
                                  'reasoning_content':'metadata only'},'finish_reason':'stop'}]}),
    ('responses', {'status':'completed','output':[{'type':'reasoning','summary':[]},
       {'type':'message','content':[{'type':'output_text','text':'ok'},{'type':'refusal','refusal':'no'}]},
       {'type':'function_call','call_id':'c1','name':'lookup','arguments':'{}'}]}),
])
def test_known_reasoning_ignored_but_text_refusal_and_tools_retained(api,payload):
    async def run():
        r=registry(target(api),lambda req:httpx.Response(200,json=payload))
        try:
            result=await r.complete(target(api),request(api))
            assert result.text == 'ok'
            assert result.refusal == 'no'
            if api=='responses':
                assert result.tool_calls[0]['function']['name'] == 'lookup'
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('field,value', [('call_id',None),('call_id',7),('name',{}),('name',''),('arguments',{}),('arguments',None)])
def test_malformed_responses_function_call_is_invalid_response(field,value):
    call={'type':'function_call','call_id':'c1','name':'lookup','arguments':'{}'}
    call[field]=value
    async def run():
        r=registry(target('responses'),lambda req:httpx.Response(200,json={'status':'completed','output':[call]}))
        try:
            with pytest.raises(GatewayError) as exc:
                await r.complete(target('responses'),request('responses'))
            assert exc.value.code == 'upstream_invalid_response'
        finally:
            await r.close()
    asyncio.run(run())


def test_responses_standard_tool_refusal_lifecycle_preserves_content_once():
    tool={'type':'function_call','call_id':'c1','name':'lookup','arguments':''}
    complete_tool={**tool,'arguments':'{}'}
    denial={'type':'refusal','refusal':'no'}
    message={'type':'message','content':[denial]}
    payloads=[{'type':'response.output_item.added','item':tool},
              {'type':'response.function_call_arguments.delta','delta':'{}','output_index':0},
              {'type':'response.function_call_arguments.done','arguments':'{}'},
              {'type':'response.output_item.done','item':complete_tool},
              {'type':'response.output_item.added','item':{'type':'message','content':[]}},
              {'type':'response.content_part.added','part':{'type':'refusal','refusal':''}},
              {'type':'response.refusal.delta','delta':'no'},
              {'type':'response.refusal.done','refusal':'no'},
              {'type':'response.content_part.done','part':denial},
              {'type':'response.output_item.done','item':message},
              {'type':'response.completed','response':{'status':'completed','output':[complete_tool,message]}}]
    async def run():
        r=registry(target('responses'),lambda req:httpx.Response(200,content=b''.join(wire(p) for p in payloads)))
        try:
            events=[e async for e in r.stream(target('responses'),request('responses'))]
            assert [e.type for e in events] == ['tool.delta','tool.delta','refusal.delta','model.finished']
            assert ''.join(e.data['arguments'] for e in events if e.type=='tool.delta') == '{}'
            assert events[0].data['name']=='lookup'
            assert events[2].data == {'delta':'no'}
        finally:
            await r.close()
    asyncio.run(run())


@pytest.mark.parametrize('part', [{'type':'output_audio'}, {'type':'refusal','refusal':'no'}])
def test_reasoning_summary_unknown_part_is_not_metadata(part):
    payloads=[{'type':'response.reasoning_summary_part.added','part':part},
              {'type':'response.completed','response':{'status':'completed'}}]
    async def run():
        r=registry(target('responses'),lambda req:httpx.Response(200,content=b''.join(wire(p) for p in payloads)))
        try:
            with pytest.raises(GatewayError) as exc:
                [e async for e in r.stream(target('responses'),request('responses'))]
            assert exc.value.code == 'upstream_unsupported_content'
        finally:
            await r.close()
    asyncio.run(run())
