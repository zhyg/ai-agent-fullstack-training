import json
import pytest
from studyagent.llm_gateway.app.schemas import GatewayError
from studyagent.llm_gateway.app.services.structured import validate_output


def test_full_schema_and_safe_error():
    schema={'type':'object','properties':{'secret':{'type':'string','pattern':'^ok$'}},'required':['secret'],'additionalProperties':False}
    assert validate_output('{"secret":"ok"}', schema) == {'secret':'ok'}
    with pytest.raises(GatewayError) as e: validate_output('{"secret":"do-not-leak"}', schema)
    assert e.value.code == 'schema_validation_failed' and e.value.status == 422
    assert 'do-not-leak' not in e.value.message


@pytest.mark.parametrize('text', ['{"a":NaN}', '{"a":1,"a":2}', '[] trailing'])
def test_strict_json(text):
    with pytest.raises(GatewayError): validate_output(text, {})


def test_no_remote_or_recursive_reference():
    for schema in [{'\u0024ref':'https://example.com/private'}, {'\u0024ref':'#'}]:
        with pytest.raises(GatewayError): validate_output('{}', schema)


def test_business_actions_are_all_or_nothing():
    assert validate_output('{"action":"route_to_team","team":"support"}', None, 'ticket')['team']=='support'
    for value in [{'action':'route_to_team'}, {'action':'ask_user'}, {'action':'resolve'}, {'action':'finish'}, {'action':'route_to_team','team':'x','extra':1}]:
        with pytest.raises(GatewayError): validate_output(json.dumps(value), None, 'ticket')
    assert validate_output('{"action":"finish","answer":"done"}',None,'agent_action')['answer']=='done'
    with pytest.raises(GatewayError): validate_output('{"answer":"done"}',None,'agent_action')


def test_validation_feedback_has_safe_layer_path_and_rule():
    with pytest.raises(GatewayError) as error:
        validate_output('{"action":"finish","answer":42}',None,'agent_action')
    assert error.value.details[0]['layer']=='business'
    assert error.value.details[0]['path']==['answer']
    assert error.value.details[0]['rule']=='string_type'
    assert '42' not in json.dumps(error.value.details)
    with pytest.raises(GatewayError) as error:
        validate_output('{broken',None)
    assert error.value.details[0]['layer']=='json'


@pytest.mark.parametrize('path', ['../secrets', '/etc/passwd', 'a/../../b', 'C:\\windows', 'a\\..\\b'])
def test_patch_paths(path):
    with pytest.raises(GatewayError):
        validate_output(json.dumps({'action':'edit','file_path':path,'reason':'fix','risk':'low'}),None,'patch_plan')


def test_local_refs_and_schema_combinators():
    schema={'$defs':{'positive':{'type':'integer','minimum':1}},'type':'object','properties':{'n':{'$ref':'#/$defs/positive'}},'required':['n'],'additionalProperties':False}
    assert validate_output('{"n":1}',schema)=={'n':1}
    with pytest.raises(GatewayError): validate_output('{"n":0}',schema)
    schema={'oneOf':[{'type':'string','minLength':2},{'type':'integer','minimum':3}]}
    with pytest.raises(GatewayError): validate_output('1',schema)
    assert validate_output('3',schema)==3


@pytest.mark.parametrize('text', ['1e999', '-1e999'])
def test_nonfinite_exponent_rejected(text):
    with pytest.raises(GatewayError): validate_output(text,None)


def test_task_plan_strict_and_agent_tool_conditional():
    plan={'goal':'Investigate','steps':['Read source'],'completion_criteria':['Evidence found'],'requires_tools':True}
    assert validate_output(json.dumps(plan),None,'task_plan')==plan
    for invalid in [{**plan,'requires_tools':'true'}, {**plan,'steps':[' ']}, {**plan,'extra':True}]:
        with pytest.raises(GatewayError): validate_output(json.dumps(invalid),None,'task_plan')
    assert validate_output('{"action":"tool","tool":"read","arguments":{"path":"a"}}',None,'agent_action')['tool']=='read'
    with pytest.raises(GatewayError): validate_output('{"action":"tool","tool":"read"}',None,'agent_action')


def test_schema_data_annotations_are_not_treated_as_schema_references():
    schema={'type':'object','properties':{'$schema':{'type':'string'}},'required':['$schema']}
    assert validate_output('{"$schema":"a"}',schema)=={'$schema':'a'}
    literal={'$ref':'https://example.com/this-is-literal-data'}
    assert validate_output(json.dumps(literal),{'const':literal})==literal


def test_schema_nonfinite_values_are_rejected_safely():
    with pytest.raises(GatewayError) as e:
        validate_output('1',{'type':'number','maximum':float('inf')})
    assert e.value.status==422


def test_nested_schema_ids_cannot_trigger_remote_retrieval(monkeypatch):
    import urllib.request
    def forbidden(*args,**kwargs):
        raise AssertionError('schema validation attempted network access')
    monkeypatch.setattr(urllib.request,'urlopen',forbidden)
    schema={'$id':'https://example.invalid/root',
            '$defs':{'value':{'type':'string'}},
            'properties':{'x':{'$id':'https://example.invalid/nested','$ref':'#/$defs/value'}}}
    # Local pointer resolves relative to the nested resource, where it is absent.
    with pytest.raises(GatewayError): validate_output('{"x":"value"}',schema)
