import asyncio
import time
import pytest
from studyagent.llm_gateway.app.config import Settings, Target, ModelRoute
from studyagent.llm_gateway.app.schemas import ModelRequest, ModelResult, ModelEvent, Usage, GatewayError, CallContext


def config(tmp_path, **overrides):
    targets = [Target(id=n, provider=n, model=n+"-model", base_url="https://"+n+".test",
                      retries=1) for n in ("a", "b")]
    return Settings(targets=targets, models={"default": ModelRoute(targets=["a","b"])},
                    database=str(tmp_path/"db.sqlite"), backoff=0, **overrides)


class Scripted:
    def __init__(self, results=None, events=None):
        self.results=list(results or []); self.events=events; self.calls=[]
    async def complete(self,target,request):
        self.calls.append(target.id)
        result=self.results.pop(0)
        if isinstance(result,BaseException):raise result
        return result
    async def stream(self,target,request):
        self.calls.append(target.id)
        for event in self.events:
            if isinstance(event,BaseException):raise event
            yield event
    async def close(self):pass


def request(**kw):
    return ModelRequest(messages=[{"role":"user","content":"hi"}],**kw)


def test_retry_fallback_and_attempt_ledger(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        adapter=Scripted([GatewayError("timeout","timeout",504,True,"upstream") for _ in range(2)]
                         +[ModelResult(text="ok",usage=Usage(input_tokens=2,output_tokens=1))])
        g=Gateway(config(tmp_path),adapters=adapter)
        result=await g.complete(request())
        assert result.text=="ok" and adapter.calls==["a","a","b"]
        records=g.store.attempts("local",result.call_id)
        assert len(records)==3
        assert records[-1]["usage"]["input_tokens"]==2
        assert g.store.get_call("local",result.call_id)["status"]=="completed"
        await g.close()
    asyncio.run(run())


def test_auth_failure_never_retries(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        adapter=Scripted([GatewayError("upstream_authentication_failed","bad",502,False,"upstream")])
        g=Gateway(config(tmp_path),adapters=adapter)
        with pytest.raises(GatewayError):await g.complete(request())
        assert adapter.calls==["a"]
        await g.close()
    asyncio.run(run())


def test_no_compatible_route_has_zero_upstream_calls(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        a=Scripted()
        g=Gateway(config(tmp_path),adapters=a)
        with pytest.raises(GatewayError) as exc:
            await g.complete(request(api="responses"))
        assert exc.value.code=="unsupported_capability" and a.calls==[]
        await g.close()
    asyncio.run(run())


def test_repair_is_bounded_and_usage_retained(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        schema={"type":"object","properties":{"x":{"type":"integer"}},"required":["x"],"additionalProperties":False}
        adapter=Scripted([ModelResult(text='{"x":"bad"}'),ModelResult(text='{"x":1}')])
        g=Gateway(config(tmp_path),adapters=adapter)
        r=await g.complete(request(output_schema=schema))
        assert r.data=={"x":1} and len(adapter.calls)==2
        assert len(g.store.attempts("local",r.call_id))==2
        await g.close()
    asyncio.run(run())


def test_call_ledger_sums_repair_usage_separately_from_result(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        adapter=Scripted([
            ModelResult(text='{"action":"finish"}',usage=Usage(input_tokens=10,output_tokens=5)),
            ModelResult(text='{"action":"finish","answer":"ok"}',usage=Usage(input_tokens=12,output_tokens=6))])
        g=Gateway(config(tmp_path),adapters=adapter)
        r=await g.complete(request(business_schema="agent_action"))
        ledger=g.store.get_call("local",r.call_id)
        assert r.usage.input_tokens==12
        assert ledger["usage"]["input_tokens"]==22
        assert ledger["usage"]["output_tokens"]==11
        assert ledger["result_usage"]["input_tokens"]==12
        assert ledger["usage_status"]=="known"
        await g.close()
    asyncio.run(run())


def test_unknown_attempt_usage_is_not_reported_as_complete_sum(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        adapter=Scripted([GatewayError("upstream_timeout","timeout",504,True,"upstream"),
                          ModelResult(text="ok",usage=Usage(input_tokens=12,output_tokens=6))])
        g=Gateway(config(tmp_path),adapters=adapter)
        r=await g.complete(request())
        ledger=g.store.get_call("local",r.call_id)
        assert ledger["usage"]["input_tokens"] is None
        assert ledger["known_usage"]["input_tokens"]==12
        assert ledger["usage_status"]=="partial"
        await g.close()
    asyncio.run(run())


def test_malformed_tools_fail_before_provider(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        adapter=Scripted([ModelResult(text="must not call")])
        g=Gateway(config(tmp_path),adapters=adapter)
        with pytest.raises(GatewayError) as exc:
            await g.complete(request(tools=[{"type":"function","function":{}}]))
        assert exc.value.code=="invalid_tools"
        assert adapter.calls==[]
        await g.close()
    asyncio.run(run())


def test_empty_schema_still_requires_structured_capability(tmp_path):
    from studyagent.llm_gateway.app.services.router import Router
    settings=config(tmp_path)
    for target in settings.targets:target.capabilities.structured="none"
    with pytest.raises(GatewayError) as exc:
        Router(settings).candidates(request(output_schema={}),CallContext())
    assert exc.value.code=="unsupported_capability"


def test_stream_events_have_call_scoped_positions_and_trace_timings(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        a=Scripted(events=[ModelEvent("text.delta",{"delta":"hi"}),
                           ModelEvent("model.finished",{"finish_reason":"stop"})])
        g=Gateway(config(tmp_path),adapters=a)
        ctx=g.make_context()
        events=[e async for e in g.stream(request(stream=True),ctx)]
        assert [e.seq for e in events]==list(range(len(events)))
        assert all(e.call_id==ctx.call_id and e.schema_version==1 and e.timestamp>0 for e in events)
        assert len({e.stream_id for e in events})==1 and events[0].stream_id
        trace=g.store.get_call("local",ctx.call_id)
        assert trace["timings_ms"]["queue"]>=0 and trace["timings_ms"]["routing"]>=0
        assert trace["attempts"]==1 and trace["budget"]["attempts"]==1
        await g.close()
    asyncio.run(run())


def test_stream_after_delta_failure_does_not_retry(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        a=Scripted(events=[ModelEvent("text.delta",{"delta":"hi"}),GatewayError("network","lost",502,True,"upstream")])
        g=Gateway(config(tmp_path),adapters=a)
        events=[e async for e in g.stream(request(stream=True))]
        assert a.calls==["a"]
        assert [e.type for e in events]==["text.delta","failed"]
        await g.close()
    asyncio.run(run())


def test_explicit_finished_but_empty_stream_is_failed(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        g=Gateway(config(tmp_path),adapters=Scripted(events=[ModelEvent('model.finished',{'finish_reason':'stop'})]))
        context=g.make_context()
        events=[e async for e in g.stream(request(stream=True),context)]
        assert events[-1].type=='failed' and events[-1].data['code']=='upstream_empty_response'
        assert g.store.get_call('local',context.call_id)['status']=='failed'
        await g.close()
    asyncio.run(run())


def test_stream_trailing_usage_and_single_terminal(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        a=Scripted(events=[ModelEvent("text.delta",{"delta":"hi"}),
                          ModelEvent("model.usage",{"input_tokens":3,"output_tokens":1}),
                          ModelEvent("model.finished",{"finish_reason":"stop"})])
        g=Gateway(config(tmp_path),adapters=a)
        events=[e async for e in g.stream(request(stream=True))]
        assert events[-1].type=="completed"
        assert sum(e.type in {"completed","failed","cancelled"} for e in events)==1
        assert events[-1].data["usage"]["input_tokens"]==3
        await g.close()
    asyncio.run(run())


def test_real_deadline_interrupts_inflight_call(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    class Slow(Scripted):
        async def complete(self,target,req):
            await asyncio.sleep(1)
            raise AssertionError("deadline must interrupt")
    async def run():
        g=Gateway(config(tmp_path,deadline=0.02),adapters=Slow())
        started=time.monotonic()
        with pytest.raises(GatewayError) as exc:await g.complete(request())
        assert exc.value.code=="deadline_exceeded"
        assert time.monotonic()-started<0.5
        assert g.store.list_calls("local")[0]["status"]=="failed"
        await g.close()
    asyncio.run(run())


def test_last_allowed_attempt_can_finish(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        a=Scripted([ModelResult(text="ok")])
        g=Gateway(config(tmp_path,max_attempts=1),adapters=a)
        assert (await g.complete(request())).text=="ok"
        await g.close()
    asyncio.run(run())


def test_idempotency_reuses_without_extra_attempt(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        a=Scripted([ModelResult(text="ok")])
        g=Gateway(config(tmp_path),adapters=a)
        first=g.make_context();first.idempotency_key="same"
        second=g.make_context();second.idempotency_key="same"
        await g.complete(request(),first)
        result=await g.complete(request(),second)
        assert result.text=="ok" and a.calls==["a"]
        conflict=g.make_context();conflict.idempotency_key="same"
        with pytest.raises(GatewayError) as exc:
            await g.complete(ModelRequest(messages=[{"role":"user","content":"different"}]),conflict)
        assert exc.value.status==409
        await g.close()
    asyncio.run(run())


def test_weighted_route_rotates_once_per_call(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        settings=config(tmp_path)
        settings.models["default"].strategy="weighted_round_robin"
        adapter=Scripted([ModelResult(text="ok") for _ in range(4)])
        g=Gateway(settings,adapters=adapter)
        for _ in range(4):await g.complete(request())
        assert adapter.calls==["a","b","a","b"]
        await g.close()
    asyncio.run(run())


def test_closing_after_completed_preserves_success(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        adapter=Scripted(events=[ModelEvent("text.delta",{"delta":"ok"}),
                                ModelEvent("model.finished",{"finish_reason":"stop"})])
        g=Gateway(config(tmp_path),adapters=adapter)
        ctx=g.make_context();iterator=g.stream(request(stream=True),ctx)
        async for event in iterator:
            if event.type=="completed":break
        await iterator.aclose()
        assert g.store.get_call("local",ctx.call_id)["status"]=="completed"
        assert not ctx.cancel.is_set()
        await g.close()
    asyncio.run(run())


def test_queue_limit_counts_waiters_not_active_calls(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        release=asyncio.Event();entered=asyncio.Event()
        class Hold(Scripted):
            async def complete(self,target,req):
                self.calls.append(target.id);entered.set()
                await release.wait()
                return ModelResult(text="ok")
        g=Gateway(config(tmp_path,tenant_concurrency=1,queue_limit=1),adapters=Hold())
        one=asyncio.create_task(g.complete(request()))
        await entered.wait()
        two=asyncio.create_task(g.complete(request()))
        await asyncio.sleep(0)
        assert not two.done()
        with pytest.raises(GatewayError) as exc:await g.complete(request())
        assert exc.value.code=="queue_full"
        release.set()
        assert all(r.text=="ok" for r in await asyncio.gather(one,two))
        await g.close()
    asyncio.run(run())


def test_readonly_cache_recovers_adapter_timeout(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        settings=config(tmp_path)
        settings.models["default"].targets=["a"];settings.targets[0].retries=0
        a=Scripted([ModelResult(text="cached"),GatewayError("upstream_timeout","timeout",504,True,"upstream")])
        g=Gateway(settings,adapters=a)
        await g.complete(request(read_only_cache=True))
        result=await g.complete(request(read_only_cache=True))
        assert result.degraded and result.text=="cached"
        await g.close()
    asyncio.run(run())


def test_stream_timeout_never_cancels_consumer_between_reads(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        class Slow(Scripted):
            async def stream(self,target,req):
                yield ModelEvent("text.delta",{"delta":"one"})
                await asyncio.sleep(1)
                yield ModelEvent("model.finished",{"finish_reason":"stop"})
        g=Gateway(config(tmp_path,deadline=0.1),adapters=Slow())
        iterator=g.stream(request(stream=True))
        assert (await anext(iterator)).type=="text.delta"
        await asyncio.sleep(0.2)
        rest=[e async for e in iterator]
        assert rest[-1].type=="failed"
        assert rest[-1].data["code"]=="deadline_exceeded"
        await g.close()
    asyncio.run(run())


def test_cancel_signal_interrupts_active_complete(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    async def run():
        class Slow(Scripted):
            async def complete(self,target,req):
                await asyncio.sleep(1)
                return ModelResult(text="late")
        g=Gateway(config(tmp_path),adapters=Slow())
        ctx=g.make_context()
        task=asyncio.create_task(g.complete(request(),ctx))
        await asyncio.sleep(0.01);ctx.cancel.set()
        with pytest.raises(asyncio.CancelledError):
            await asyncio.wait_for(task,0.2)
        assert g.store.get_call("local",ctx.call_id)["status"]=="cancelled"
        await g.close()
    asyncio.run(run())
