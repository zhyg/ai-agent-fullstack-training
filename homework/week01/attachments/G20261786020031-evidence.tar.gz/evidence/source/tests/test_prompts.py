import pytest
from studyagent.llm_gateway.app.services.usage import Store
from studyagent.llm_gateway.app.services.prompts import PromptService
from studyagent.llm_gateway.app.schemas import ModelRequest, CallContext, GatewayError, Message


def request(**kwargs):
    return ModelRequest(messages=[{'role': 'user', 'content': 'input'}], prompt={'id': 'review', 'variables': {'name': 'Ada'}}, **kwargs)


def bundle(**kwargs):
    return dict(id='review', system='Review {{ name }}', input_schema={'type': 'object', 'properties': {'name': {'type': 'string', 'maxLength': 10}}, 'required': ['name'], 'additionalProperties': False}, default_model='review-model', generation={'temperature': 0.2, 'max_output_tokens': 80}, **kwargs)


def test_frozen_bundle_defaults_overrides_and_no_mutation():
    s = Store(':memory:'); p = PromptService(s)
    s.save_prompt('local', bundle())
    c = CallContext(); original = request()
    first = p.prepare(original, c)
    assert first.messages[0].content == 'Review Ada'
    assert first.max_output_tokens == 80 and first.temperature == 0.2
    assert first.requested_model == 'review-model' and len(original.messages) == 1
    s.save_prompt('local', bundle(change_note='changed'))
    assert p.prepare(original, c).messages == first.messages
    assert c.snapshots['prompt']['version'] == 1
    explicit = p.prepare(request(temperature=0.8, requested_model='custom', max_output_tokens=100), CallContext())
    assert explicit.temperature == 0.8 and explicit.max_output_tokens == 100 and explicit.requested_model == 'custom'


@pytest.mark.parametrize('variables,code', [({}, 'missing_prompt_variable'), ({'name': 'x'*11}, 'invalid_prompt_variables')])
def test_variable_schema(variables, code):
    s=Store(':memory:'); s.save_prompt('local', bundle())
    r=request(); r.prompt.variables=variables
    with pytest.raises(GatewayError) as e: PromptService(s).prepare(r, CallContext())
    assert e.value.code == code


def test_sandbox_and_hard_limits():
    s=Store(':memory:'); p=PromptService(s)
    s.save_prompt('local', bundle(context_budget={'max_output_tokens': 50}))
    with pytest.raises(GatewayError): p.prepare(request(max_output_tokens=100), CallContext())
    with pytest.raises(GatewayError): s.save_prompt('local', {**bundle(), 'system': '{{ bad.__class__ }}'})


def test_failed_draft_does_not_replace_active_and_explicit_version_rollback():
    s=Store(':memory:'); p=PromptService(s)
    one=s.save_prompt('local',bundle())
    with pytest.raises(GatewayError): s.save_prompt('local',{**bundle(),'input_schema':{'type':'broken'}})
    assert s.get_prompt('local','review')['hash']==one['hash']
    draft=s.save_prompt('local',{**bundle(),'system':'Candidate {{ name }}','status':'draft'},activate=False)
    assert s.get_prompt('local','review')['version']==1
    r=request(); r.prompt.version=draft['version']
    assert p.prepare(r,CallContext()).messages[0].content=='Candidate Ada'
    r.prompt.version=one['version']
    assert p.prepare(r,CallContext()).messages[0].content=='Review Ada'


def test_unknown_template_and_strict_undefined_safe_errors():
    s=Store(':memory:'); p=PromptService(s)
    with pytest.raises(GatewayError) as e: p.prepare(request(),CallContext())
    assert e.value.code=='unknown_prompt_template'
    s.save_prompt('local',{**bundle(),'system':'{{ missing }}'})
    with pytest.raises(GatewayError) as e: p.prepare(request(),CallContext())
    assert e.value.code=='missing_prompt_variable'
    assert 'Ada' not in e.value.message


def test_schema_tools_few_shot_and_tenant_freeze():
    s=Store(':memory:'); p=PromptService(s)
    schema={'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok']}
    tools=[{'type':'function','function':{'name':'read','parameters':{'type':'object'}}}]
    s.save_prompt('local',{**bundle(),'output_schema':schema,'tools':tools,'tools_version':'2','few_shot':[{'role':'user','content':'Example {{ name }}'},{'role':'assistant','content':'Reviewed'}]})
    ctx=CallContext(); result=p.prepare(request(),ctx)
    assert result.output_schema==schema and result.tools==tools
    assert result.messages[1].content=='Example Ada'
    assert ctx.snapshots['prompt']['tools_version']=='2'
    result.tools.clear()
    assert p.prepare(request(),ctx).tools==tools


def test_activation_does_not_change_run_snapshot():
    s=Store(':memory:'); p=PromptService(s)
    s.save_prompt('local',bundle())
    s.save_prompt('local',{**bundle(),'system':'New {{ name }}','status':'candidate'},activate=False)
    ctx=CallContext(); old=p.prepare(request(),ctx)
    s.activate_prompt('local','review',2)
    assert p.prepare(request(),ctx).messages==old.messages
    assert p.prepare(request(),CallContext()).messages[0].content=='New Ada'


def test_non_json_bundle_and_variables_have_stable_safe_errors():
    s=Store(':memory:')
    with pytest.raises(GatewayError) as e:
        s.save_prompt('local',{**bundle(),'tools':[{'bad':float('inf')}]})
    assert e.value.status==400


@pytest.mark.parametrize('source', [
    '{{ value.__class__ }}', '{{ fn() }}', '{% for x in xs %}{{ x }}{% endfor %}',
    '{% include "outside" %}', '{{ "x" * 1000000000 }}',
    '{% macro x() %}a{% endmacro %}',
])
def test_actual_jinja_sandbox_forbidden_expressions(source):
    from studyagent.llm_gateway.app.services.prompts import environment, template
    with pytest.raises(GatewayError): template(environment(),source)


def test_actual_jinja_strict_undefined_and_data_stays_inert():
    from jinja2 import UndefinedError
    from studyagent.llm_gateway.app.services.prompts import environment, template
    env=environment()
    with pytest.raises(UndefinedError): template(env,'{{ missing }}').render()
    assert template(env,'{{ text }}').render(text='{{ unsafe() }}')=='{{ unsafe() }}'


def test_prompt_budget_counts_message_tool_arguments():
    s=Store(':memory:'); s.save_prompt('local',bundle(context_budget={'max_input_chars':500}))
    r=request()
    r.messages.append(Message(
        role='assistant',tool_calls=[{'id':'tool_1','type':'function','function':{'name':'read','arguments':'x'*2000}}]))
    with pytest.raises(GatewayError) as e: PromptService(s).prepare(r,CallContext())
    assert e.value.code=='context_limit_exceeded'


@pytest.mark.parametrize('value',[True,12.0,'12'])
def test_bundle_context_limits_require_actual_integer(value):
    from pydantic import ValidationError
    from studyagent.llm_gateway.app.services.prompts import PromptBundle
    with pytest.raises(ValidationError):
        PromptBundle.model_validate({'id':'p','context_budget':{'max_output_tokens':value}})
