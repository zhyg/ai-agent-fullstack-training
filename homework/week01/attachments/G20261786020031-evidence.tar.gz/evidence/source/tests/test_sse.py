import json

from studyagent.llm_gateway.app.services import sse


def test_parser_byte_splits_multiline_metadata_comments_and_crlf():
    parser = sse.SSEParser()
    wire = ':心跳\r\nid: 7\r\nretry: 1200\r\nevent: update\r\ndata: 你\r\ndata: 好\r\n\r\n'.encode()
    result = []
    for value in wire:
        result += parser.feed(bytes([value]))
    assert result == [{'event': 'update', 'data': '你\n好', 'id': '7', 'retry': 1200}]
    assert parser.finish() == []


def test_incomplete_eof_is_not_dispatched_and_metadata_persists():
    parser = sse.SSEParser()
    assert parser.feed(b'id: abc\nretry: invalid\ndata: first\n\ndata: lost\n') == [
        {'event': 'message', 'data': 'first', 'id': 'abc', 'retry': None}]
    assert parser.finish() == []


def test_encoding_json_prevents_field_injection():
    encoded = sse.encode_event('text.delta', {'delta': '好\n世界'}, event_id='8')
    events = sse.SSEParser().feed(encoded.encode())
    assert events[0]['event'] == 'text.delta'
    assert events[0]['id'] == '8'
    assert json.loads(events[0]['data']) == {'delta': '好\n世界'}
    assert sse.SSEParser().feed(sse.heartbeat().encode()) == []


def test_unterminated_or_multiline_event_has_bounded_buffer():
    import pytest
    parser=sse.SSEParser(max_event_bytes=64)
    with pytest.raises(ValueError):
        for _ in range(100):parser.feed(b'data: 123456789\n')
    parser=sse.SSEParser(max_event_bytes=64)
    assert len(parser.feed(b'data: ok\n\n'*100))==100
