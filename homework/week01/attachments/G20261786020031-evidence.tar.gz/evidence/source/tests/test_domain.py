import pytest


def test_request_rejects_blank_and_unknown_fields():
    from studyagent.llm_gateway.app.schemas import ModelRequest
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        ModelRequest(messages=[])
    with pytest.raises(ValidationError):
        ModelRequest(messages=[{"role": "user", "content": " "}])
    with pytest.raises(ValidationError):
        ModelRequest(messages=[{"role": "user", "content": "hi"}], invented=True)


def test_unknown_usage_and_error_contract():
    from studyagent.llm_gateway.app.schemas import Usage, GatewayError
    assert Usage().input_tokens is None
    error = GatewayError("timeout", "upstream timeout", 504, True, "connect")
    assert error.retryable and error.status == 504
    assert error.payload()["error"]["code"] == "timeout"


def test_last_reserved_attempt_can_continue_but_next_attempt_is_denied():
    from studyagent.llm_gateway.app.schemas import Budget, CallContext, GatewayError
    budget = Budget(max_attempts=1)
    budget.reserve(10)
    CallContext(budget=budget).check()
    with pytest.raises(GatewayError):
        budget.reserve(1)
