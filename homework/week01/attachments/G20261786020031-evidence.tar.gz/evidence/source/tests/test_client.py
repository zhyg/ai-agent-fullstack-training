import asyncio
import json

import httpx
import pytest

from studyagent.llm_gateway.app.schemas import GatewayError
from studyagent.llm_gateway.integration_examples.client import RunClient


def frame(kind,seq,version=1,**data):
    return ('data: '+json.dumps({'schema_version':version,'run_id':'run_test','seq':seq,'type':kind,'timestamp':9999999999,'data':data})+'\n\n').encode()


class Chunks(httpx.AsyncByteStream):
    def __init__(self, values): self.values=values;self.closed=False
    async def __aiter__(self):
        for chunk in self.values: yield chunk
    async def aclose(self): self.closed=True


def test_client_unknown_version_stops_and_closes_subscription():
    async def scenario():
        stream=Chunks([frame('text.delta',0,version=2,delta='must not publish'),frame('text.delta',1,delta='later')])
        client=RunClient('http://test','secret')
        await client.http.aclose()
        client.http=httpx.AsyncClient(base_url='http://test',transport=httpx.MockTransport(lambda request:httpx.Response(200,stream=stream)))
        with pytest.raises(GatewayError) as caught:
            assert [event async for event in client.events('run_test')]==[]
        assert caught.value.code=='unsupported_event_version' and stream.closed
        await client.close()
    asyncio.run(scenario())


def test_client_known_version_unknown_event_is_logged_and_passed_through(caplog):
    async def scenario():
        client=RunClient('http://test','secret')
        await client.http.aclose()
        client.http=httpx.AsyncClient(base_url='http://test',transport=httpx.MockTransport(lambda request:httpx.Response(200,content=frame('future.notice',0,command='never execute'))))
        events=[event async for event in client.events('run_test')]
        assert events[0]['data']=={'command':'never execute'}
        assert 'future.notice' in caplog.text
        await client.close()
    asyncio.run(scenario())


def test_client_local_timings_and_replay_dedup(monkeypatch):
    import studyagent.llm_gateway.integration_examples.client as module
    now=[10.0]
    monkeypatch.setattr(module,'client_clock',lambda:now[0],raising=False)
    async def scenario():
        subscriptions=[0]
        class TimedChunks(httpx.AsyncByteStream):
            async def __aiter__(self):
                now[0]+=0.2
                yield frame('text.delta',0,delta='')
                now[0]+=0.3
                yield frame('text.delta',1,delta='你好')
                now[0]+=0.5
                yield frame('run.completed',2)
        def respond(request):
            if request.method=='POST':
                now[0]+=0.1
                return httpx.Response(201,json={'run_id':'run_test'})
            subscriptions[0]+=1
            return httpx.Response(200,stream=TimedChunks())
        client=RunClient('http://test','secret');await client.http.aclose()
        client.http=httpx.AsyncClient(base_url='http://test',transport=httpx.MockTransport(respond))
        await client.create('hi')
        events=[event async for event in client.events('run_test')]
        assert len(events)==3
        metrics=client.timings['run_test']
        assert metrics['clock']=='client_monotonic'
        assert metrics['create_to_first_text_ms']==pytest.approx(600)
        assert metrics['create_to_terminal_ms']==pytest.approx(1100)
        first_terminal=metrics['create_to_terminal_ms']
        replay=[event async for event in client.events('run_test',after=0)]
        assert [event['seq'] for event in replay]==[1,2]
        assert metrics['subscriptions'][-1]['first_text_ms']==pytest.approx(500)
        assert metrics['subscriptions'][-1]['replay'] is True
        assert metrics['create_to_terminal_ms']==first_terminal
        await client.close()
    asyncio.run(scenario())


def test_client_limits_unframed_buffer_and_closes_response():
    async def scenario():
        stream=Chunks([b'data: '+b'x'*1_048_576])
        client=RunClient('http://test','secret');await client.http.aclose()
        client.http=httpx.AsyncClient(base_url='http://test',transport=httpx.MockTransport(lambda request:httpx.Response(200,stream=stream)))
        with pytest.raises(GatewayError) as caught:
            _=[event async for event in client.events('run_test')]
        assert caught.value.code=='stream_event_too_large' and stream.closed
        await client.close()
    asyncio.run(scenario())


def test_client_split_unicode_dedup_and_eof_frame():
    async def scenario():
        raw=frame('text.delta',0,delta='duplicate')+frame('text.delta',1,delta='中文')+frame('future.notice',2).rstrip(b'\n')
        stream=Chunks([raw[index:index+1] for index in range(len(raw))])
        client=RunClient('http://test','secret');await client.http.aclose()
        client.http=httpx.AsyncClient(base_url='http://test',transport=httpx.MockTransport(lambda request:httpx.Response(200,stream=stream)))
        events=[event async for event in client.events('run_test',after=0)]
        assert [event['seq'] for event in events]==[1]
        assert events[0]['data']['delta']=='中文'
        assert stream.closed
        await client.close()
    asyncio.run(scenario())
