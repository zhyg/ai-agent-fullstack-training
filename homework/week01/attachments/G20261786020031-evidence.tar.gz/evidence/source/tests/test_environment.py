"""Environment failures must not be blamed on valid caller requests."""
import asyncio
import builtins

import httpx
import pytest

from studyagent.llm_gateway.app.core.errors import GatewayError


def block_schema_import(monkeypatch):
    original=builtins.__import__
    def importing(name,*args,**kwargs):
        if name in {'jsonschema','referencing'}:
            raise ModuleNotFoundError('test missing package')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',importing)


def test_missing_schema_dependency_is_configuration_error(monkeypatch):
    from studyagent.llm_gateway.app.services.structured import checked_schema
    block_schema_import(monkeypatch)
    with pytest.raises(GatewayError) as caught:checked_schema({'type':'object'})
    assert caught.value.code=='dependency_unavailable' and caught.value.status==503
    assert caught.value.stage=='config' and not caught.value.retryable
    assert 'test missing package' not in caught.value.message


@pytest.mark.parametrize('kind',['output','tools'])
def test_gateway_preserves_missing_dependency_and_never_calls_provider(tmp_path,monkeypatch,kind):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    from studyagent.llm_gateway.tests.test_gateway import config,request,Scripted
    block_schema_import(monkeypatch)
    async def run():
        adapter=Scripted();gateway=Gateway(config(tmp_path),adapters=adapter)
        fields={'output_schema':{'type':'object'}} if kind=='output' else {
            'tools':[{'type':'function','function':{'name':'lookup','parameters':{'type':'object'}}}]}
        try:
            with pytest.raises(GatewayError) as caught:await gateway.complete(request(**fields))
            assert caught.value.code=='dependency_unavailable' and caught.value.status==503
            assert adapter.calls==[]
        finally:await gateway.close()
    asyncio.run(run())


def test_prompt_save_preserves_dependency_error(monkeypatch):
    from studyagent.llm_gateway.app.services.usage import Store
    block_schema_import(monkeypatch)
    store=Store(':memory:')
    try:
        with pytest.raises(GatewayError) as caught:store.save_prompt('local',{'id':'example','system':'hello'})
        assert caught.value.code=='dependency_unavailable' and caught.value.status==503
    finally:store.close()


def test_readiness_requires_working_schema_dependency(tmp_path,monkeypatch):
    from studyagent.llm_gateway.app.api import routes
    from studyagent.llm_gateway.tests.test_api import FakeGateway
    monkeypatch.setenv('TEST_ADMIN','test-admin')
    monkeypatch.setattr(routes,'schema_runtime_available',lambda:False,raising=False)
    async def run():
        gateway=FakeGateway(tmp_path)
        try:
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=routes.create_app(gateway=gateway)),base_url='http://test') as client:
                assert (await client.get('/healthz')).status_code==200
                response=await client.get('/readyz')
                assert response.status_code==503 and response.json()['status']=='not_ready'
        finally:await gateway.close()
    asyncio.run(run())


def test_smoke_not_ready_without_provider_credential(monkeypatch,tmp_path):
    from studyagent.llm_gateway import smoke
    from studyagent.llm_gateway.app.config import Credential
    from studyagent.llm_gateway.tests.test_gateway import config
    settings=config(tmp_path);settings.credentials=[Credential(env='TEST_ADMIN')]
    for target in settings.targets:target.api_key_env='TEST_MISSING_PROVIDER_KEY'
    monkeypatch.delenv('TEST_MISSING_PROVIDER_KEY',raising=False)
    monkeypatch.setenv('TEST_ADMIN','test-admin')
    monkeypatch.setattr(smoke.Settings,'from_env',lambda:settings)
    monkeypatch.setattr(smoke.importlib.util,'find_spec',lambda name:object())
    _,report=smoke.configuration()
    assert not report['provider_credential_available'] and not report['ready_for_local_start']


def test_expand_env_resolves_names_defaults_and_nested_values(monkeypatch):
    from studyagent.llm_gateway.app.config import expand_env
    monkeypatch.setenv('TEST_BASE','https://api.example.test/v1')
    monkeypatch.delenv('TEST_ABSENT',raising=False)
    raw={'base':'${TEST_BASE}','fallback':'${TEST_ABSENT:-deepseek-chat}',
         'missing':'${TEST_ABSENT}','nested':[{'url':'${TEST_BASE}/chat'}],
         'plain':'no placeholders','number':7}
    assert expand_env(raw)=={'base':'https://api.example.test/v1','fallback':'deepseek-chat',
                             'missing':'','nested':[{'url':'https://api.example.test/v1/chat'}],
                             'plain':'no placeholders','number':7}


def test_config_file_expands_environment_without_storing_secrets(tmp_path,monkeypatch):
    from studyagent.llm_gateway.app.config import Settings
    monkeypatch.setenv('TEST_PROVIDER_KEY','sk-test-value')
    monkeypatch.setenv('TEST_BASE','https://api.example.test/v1')
    config_file=tmp_path/'gateway.json'
    config_file.write_text('''
    {"database":"${TEST_DB:-data/gateway.db}",
     "targets":[{"id":"primary","provider":"deepseek","model":"${TEST_MODEL:-deepseek-chat}",
                 "base_url":"${TEST_BASE}","api_key":"${TEST_PROVIDER_KEY}"}],
     "models":{"default":{"targets":["primary"]}}}
    ''',encoding='utf-8')
    monkeypatch.setenv('GATEWAY_CONFIG',str(config_file))
    monkeypatch.delenv('TEST_DB',raising=False)
    monkeypatch.delenv('TEST_MODEL',raising=False)
    settings=Settings.from_env()
    target=settings.targets[0]
    assert target.base_url=='https://api.example.test/v1'
    assert target.model=='deepseek-chat' and settings.database=='data/gateway.db'
    assert target.resolve_key()=='sk-test-value' and target.has_key()
    assert 'sk-test-value' not in repr(target)


def test_inline_key_takes_precedence_over_environment(monkeypatch):
    from studyagent.llm_gateway.app.config import Target
    from studyagent.llm_gateway.app.core.errors import GatewayError
    monkeypatch.setenv('TEST_ENV_KEY','env-value')
    inline=Target(id='a',provider='a',model='m',base_url='https://a.test',api_key='inline-value',api_key_env='TEST_ENV_KEY')
    assert inline.resolve_key()=='inline-value'
    fallback=Target(id='a',provider='a',model='m',base_url='https://a.test',api_key_env='TEST_ENV_KEY')
    assert fallback.resolve_key()=='env-value' and fallback.has_key()
    monkeypatch.delenv('TEST_ENV_KEY',raising=False)
    missing=Target(id='a',provider='a',model='m',base_url='https://a.test',api_key_env='TEST_ENV_KEY')
    assert not missing.has_key()
    with pytest.raises(GatewayError) as caught:missing.resolve_key()
    assert caught.value.code=='provider_not_configured' and caught.value.status==503


def test_routing_snapshot_hides_secret_but_rebuilt_target_keeps_key(tmp_path,monkeypatch):
    """The routing snapshot is persisted for Run resume; it must not carry the key,
    yet the rebuilt target must still be able to authenticate."""
    import json
    from studyagent.llm_gateway.app.config import ModelRoute, Settings, Target
    from studyagent.llm_gateway.app.schemas import ModelEvent, ModelRequest, ModelResult, Usage
    from studyagent.llm_gateway.app.services.gateway import Gateway

    monkeypatch.delenv('TEST_UNSET_PROVIDER_KEY',raising=False)

    class Capture:
        def __init__(self):self.target=None
        async def complete(self,target,request):
            self.target=target
            return ModelResult(text='ok',usage=Usage(input_tokens=1,output_tokens=1))
        async def stream(self,target,request):
            self.target=target
            yield ModelEvent('text.delta',{'delta':'x'})
            yield ModelEvent('model.finished',{'finish_reason':'stop'})
        async def close(self):pass

    settings=Settings(targets=[Target(id='a',provider='a',model='m',base_url='https://a.test',
                                      api_key='sk-inline-secret',api_key_env='TEST_UNSET_PROVIDER_KEY')],
                      models={'default':ModelRoute(targets=['a'])},database=str(tmp_path/'db.sqlite'))

    async def run():
        adapter=Capture();gateway=Gateway(settings,adapters=adapter)
        try:
            context=gateway.make_context()
            await gateway.complete(ModelRequest(messages=[{'role':'user','content':'hi'}]),context)
            assert adapter.target.resolve_key()=='sk-inline-secret'
            dumped=json.dumps(context.snapshots,ensure_ascii=False)
            assert 'sk-inline-secret' not in dumped and '"api_key"' not in dumped
        finally:await gateway.close()
    asyncio.run(run())
