import concurrent.futures
import pytest
from studyagent.llm_gateway.app.services.usage import Store
from studyagent.llm_gateway.app.schemas import GatewayError


def test_threaded_atomic_finalize_and_tenant_isolation(tmp_path):
    s = Store(str(tmp_path / 's.db'))
    with concurrent.futures.ThreadPoolExecutor(8) as pool:
        assert sum(pool.map(lambda _: s.finish_call('a', 'call', {'status': 'ok'}), range(20))) == 1
    s.add_attempt('a', 'call', {'attempt': 1})
    assert s.get_call('b', 'call') is None
    assert s.attempts('b', 'call') == []
    assert len(s.list_calls('a')) == 1
    s.close()


def test_prompt_versions_drafts_and_explicit_rollback():
    s = Store(':memory:')
    one = s.save_prompt('a', {'id': 'review', 'system': 'one'})
    two = s.save_prompt('a', {'id': 'review', 'system': 'two'}, activate=False)
    assert one['version'] == 1 and two['version'] == 2
    assert s.get_prompt('a', 'review')['hash'] == one['hash']
    assert s.get_prompt('a', 'review', 2)['system'] == 'two'
    with pytest.raises(GatewayError): s.get_prompt('b', 'review')
    with pytest.raises(GatewayError): s.save_prompt('a', {'id': '../bad'})


def test_memory_runs_events_cache_and_retention():
    s = Store(':memory:')
    s.create_run('a', 'run', {'status': 'running', 'checkpoint': {'step': 1}})
    with concurrent.futures.ThreadPoolExecutor(8) as pool:
        list(pool.map(lambda i: s.append_event('a', 'run', {'type': 'delta', 'data': {'i': i}}), range(40)))
    assert [e['seq'] for e in s.events('a', 'run')] == list(range(40))
    assert len(s.events('a', 'run', after=35)) == 4
    assert s.get_run('b', 'run') is None and s.events('b', 'run') == []
    s.update_run('a', 'run', {'status': 'completed'})
    assert s.get_run('a', 'run')['checkpoint'] == {'step': 1}
    s.cache_put('a', 'key', {'text': 'ok'}, 60)
    assert s.cache_get('a', 'key') == {'text': 'ok'} and s.cache_get('b', 'key') is None
    s.cache_put('a', 'expired', {}, 0)
    assert s.cache_get('a', 'expired') is None
    s.close()


def test_checkpoint_reopen_and_event_retention(tmp_path):
    path=str(tmp_path/'persist.db'); s=Store(path)
    s.create_run('a','run',{'checkpoint':{'step':2},'status':'running'})
    s.append_event('a','run',{'type':'text.delta'})
    assert s.prune_events(1, now=10**12)==1
    s.close(); s=Store(path)
    assert s.get_run('a','run')['checkpoint']['step']==2
    assert s.append_event('a','run',{'type':'completed'})['seq']==1
    assert len(s.events('a','run'))==1
    s.close()


def test_multiple_connections_append_unique_event_sequences(tmp_path):
    path=str(tmp_path/'shared.db')
    stores=[Store(path) for _ in range(4)]
    stores[0].create_run('a','run',{'status':'running'})
    with concurrent.futures.ThreadPoolExecutor(4) as pool:
        list(pool.map(lambda i: stores[i % 4].append_event('a','run',{'type':'delta'}),range(80)))
    assert [e['seq'] for e in stores[0].events('a','run')]==list(range(80))
    for s in stores: s.close()


def test_atomic_activation_rollback_and_tenant_isolation():
    s=Store(':memory:')
    one=s.save_prompt('a',{'id':'p','system':'one'})
    two=s.save_prompt('a',{'id':'p','system':'two','status':'candidate'},activate=False)
    assert s.activate_prompt('a','p',2)['hash']==two['hash']
    assert s.get_prompt('a','p')['version']==2
    assert s.activate_prompt('a','p',1)['hash']==one['hash']
    assert s.get_prompt('a','p')['version']==1
    with pytest.raises(GatewayError): s.activate_prompt('b','p',2)
    with pytest.raises(GatewayError): s.activate_prompt('a','p',99)
    assert s.get_prompt('a','p')['version']==1
    s.retire_prompt('a','p')
    with pytest.raises(GatewayError): s.get_prompt('a','p')
    assert s.get_prompt('a','p',2)['hash']==two['hash']


def test_draft_must_not_become_active():
    s=Store(':memory:')
    s.save_prompt('a',{'id':'p','system':'one'})
    draft=s.save_prompt('a',{'id':'p','system':'draft','status':'draft'},activate=False)
    with pytest.raises(GatewayError): s.activate_prompt('a','p',draft['version'])
    with pytest.raises(GatewayError): s.save_prompt('a',{'id':'p','system':'bad','status':'draft'})
    assert s.get_prompt('a','p')['version']==1
