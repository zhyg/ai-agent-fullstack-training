"""Partial-output checkpoints for direct proxy streams.

A dropped client must be able to recover the text it already paid for. The feature
is opt-in because persisting model text is a privacy decision.
"""
import asyncio

import httpx

from studyagent.llm_gateway.app.config import (
    Credential,
    ModelRoute,
    Settings,
    StreamCheckpointConfig,
    Target,
)
from studyagent.llm_gateway.app.schemas import ModelEvent, ModelRequest


def config(tmp_path, **overrides):
    target = Target(id='a', provider='a', model='a-model', base_url='https://a.test', retries=0)
    return Settings(targets=[target], models={'default': ModelRoute(targets=['a'])},
                    database=str(tmp_path/'db.sqlite'), backoff=0, **overrides)


def request():
    return ModelRequest(messages=[{'role': 'user', 'content': 'hi'}], stream=True)


def events(*deltas, finish='stop'):
    items = [ModelEvent('text.delta', {'delta': d}) for d in deltas]
    items.append(ModelEvent('model.finished', {'finish_reason': finish}))
    items.append(ModelEvent('model.usage', {'input_tokens': 1, 'output_tokens': 1}))
    return items


class Scripted:
    def __init__(self, items):
        self.items = items

    async def complete(self, target, request):
        raise AssertionError('complete must not be used by stream tests')

    async def stream(self, target, request):
        for item in self.items:
            yield item

    async def close(self):
        pass


class Blocking:
    """Emits one delta, then blocks until the consumer cancels."""

    def __init__(self, first):
        self.first = first

    async def complete(self, target, request):
        raise AssertionError('complete must not be used by stream tests')

    async def stream(self, target, request):
        yield ModelEvent('text.delta', {'delta': self.first})
        await asyncio.sleep(3600)

    async def close(self):
        pass


def test_checkpoint_is_off_by_default(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway

    async def run():
        gateway = Gateway(config(tmp_path), adapters=Scripted(events('你', '好')))
        context = gateway.make_context()
        iterator = gateway.stream(request(), context)
        async for _ in iterator:
            pass
        await iterator.aclose()
        assert gateway.store.get_stream_checkpoint('local', context.call_id) is None
        await gateway.close()

    asyncio.run(run())


def test_completed_stream_persists_full_text(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway

    async def run():
        gateway = Gateway(config(tmp_path, stream_checkpoint=StreamCheckpointConfig(
            enabled=True, flush_interval_seconds=0)), adapters=Scripted(events('你', '好', '世界')))
        context = gateway.make_context()
        iterator = gateway.stream(request(), context)
        async for _ in iterator:
            pass
        await iterator.aclose()
        record = gateway.store.get_stream_checkpoint('local', context.call_id)
        assert record['text'] == '你好世界' and record['status'] == 'completed'
        assert record['finish_reason'] == 'stop' and record['truncated'] is False
        assert record['chars'] == 4 and record['stream_id'].startswith('stream_')
        await gateway.close()

    asyncio.run(run())


def test_partial_text_survives_client_disconnect(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway

    async def run():
        gateway = Gateway(config(tmp_path, stream_checkpoint=StreamCheckpointConfig(
            enabled=True, flush_interval_seconds=0)), adapters=Blocking('你'))
        context = gateway.make_context()
        iterator = gateway.stream(request(), context)
        async for event in iterator:
            if event.type == 'text.delta':
                break
        await iterator.aclose()
        record = gateway.store.get_stream_checkpoint('local', context.call_id)
        assert record['text'] == '你'
        assert record['status'] == 'cancelled'
        await gateway.close()

    asyncio.run(run())


def test_checkpoint_is_capped_at_max_chars(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway

    async def run():
        gateway = Gateway(config(tmp_path, stream_checkpoint=StreamCheckpointConfig(
            enabled=True, flush_interval_seconds=0, max_chars=1000)),
            adapters=Scripted(events('a'*600, 'b'*600)))
        context = gateway.make_context()
        iterator = gateway.stream(request(), context)
        async for _ in iterator:
            pass
        await iterator.aclose()
        record = gateway.store.get_stream_checkpoint('local', context.call_id)
        assert record['chars'] == 1000 and record['truncated'] is True
        assert record['text'] == 'a'*600 + 'b'*400
        await gateway.close()

    asyncio.run(run())


def test_checkpoint_route_is_tenant_isolated(tmp_path, monkeypatch):
    from studyagent.llm_gateway.app.api import routes
    from studyagent.llm_gateway.app.services.gateway import Gateway

    monkeypatch.setenv('TEST_ADMIN', 'admin-secret')
    monkeypatch.setenv('TEST_OTHER', 'other-secret')
    settings = config(tmp_path, credentials=[Credential(env='TEST_ADMIN'),
                                             Credential(env='TEST_OTHER', tenant='other', role='caller')])

    async def run():
        gateway = Gateway(settings, adapters=Scripted(events('x')))
        gateway.store.save_stream_checkpoint('local', 'call_abc', {
            'request_id': 'call_abc', 'text': '部分正文', 'status': 'streaming'})
        app = routes.create_app(gateway=gateway)
        try:
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://test') as client:
                assert (await client.get('/v1/streams/call_abc/checkpoint')).status_code == 401
                client.headers['Authorization'] = 'Bearer other-secret'
                cross = await client.get('/v1/streams/call_abc/checkpoint')
                assert cross.status_code == 404 and cross.json()['error']['code'] == 'checkpoint_not_found'
                client.headers['Authorization'] = 'Bearer admin-secret'
                own = await client.get('/v1/streams/call_abc/checkpoint')
                assert own.status_code == 200 and own.json()['text'] == '部分正文'
                missing = await client.get('/v1/streams/call_missing/checkpoint')
                assert missing.status_code == 404 and missing.json()['error']['code'] == 'checkpoint_not_found'
        finally:
            await gateway.close()

    asyncio.run(run())


def test_pruned_checkpoints_do_not_leak_old_text(tmp_path):
    from studyagent.llm_gateway.app.services.usage import Store

    store = Store(str(tmp_path/'prune.db'))
    try:
        store.save_stream_checkpoint('local', 'call_old', {'text': 'old'})
        store.save_stream_checkpoint('local', 'call_new', {'text': 'new'})
        store._db.execute("UPDATE stream_checkpoints SET updated=0 WHERE request_id='call_old'")
        store._db.commit()
        assert store.prune_stream_checkpoints(3600) == 1
        assert store.get_stream_checkpoint('local', 'call_old') is None
        assert store.get_stream_checkpoint('local', 'call_new')['text'] == 'new'
    finally:
        store.close()
