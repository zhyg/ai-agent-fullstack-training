import asyncio
import pytest
from studyagent.llm_gateway.app.schemas import ModelResult, GatewayError


class Port:
    def __init__(self,results):self.results=list(results);self.requests=[]
    async def complete(self,request,context=None):
        self.requests.append(request)
        return self.results.pop(0)


def call(query="gateway"):
    return ModelResult(kind="tool_calls",text=None,tool_calls=[{
        "id":"c1","type":"function","function":{"name":"lookup_note","arguments":'{"query":"'+query+'"}'}}])


def test_loop_fills_tool_result_and_finishes():
    from studyagent.llm_gateway.integration_examples.loop import MinimalLoop
    async def run():
        port=Port([call(),ModelResult(text="网关提供统一模型入口")])
        loop=MinimalLoop(port)
        result=await loop.run("解释网关")
        assert result["answer"]=="网关提供统一模型入口"
        assert loop.tool_executions==1
        assert port.requests[1].messages[-1].role=="tool"
        assert port.requests[1].messages[-1].tool_call_id=="c1"
    asyncio.run(run())


def test_repeated_action_and_step_limit():
    from studyagent.llm_gateway.integration_examples.loop import MinimalLoop
    async def run():
        loop=MinimalLoop(Port([call(),call()]))
        with pytest.raises(GatewayError) as exc:await loop.run("hi")
        assert exc.value.code=="repeated_action" and loop.tool_executions==1
        loop=MinimalLoop(Port([call()]),max_steps=1)
        with pytest.raises(GatewayError) as exc:await loop.run("hi")
        assert exc.value.code=="step_budget_exceeded"
    asyncio.run(run())


def test_bad_tool_arguments_never_execute():
    from studyagent.llm_gateway.integration_examples.loop import MinimalLoop
    async def run():
        bad=call();bad.tool_calls[0]["function"]["arguments"]='{"query":"x","execute":"rm"}'
        loop=MinimalLoop(Port([bad]))
        with pytest.raises(GatewayError):await loop.run("hi")
        assert loop.tool_executions==0
    asyncio.run(run())
