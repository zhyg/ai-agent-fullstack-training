import asyncio
import importlib

import httpx
import pytest

from studyagent.llm_gateway.app.config import Settings, Target, ModelRoute, Credential
from studyagent.llm_gateway.app.schemas import CallContext, GatewayError, ModelEvent, ModelResult, Usage


class FakeGateway:
    def __init__(self, tmp_path):
        from studyagent.llm_gateway.app.services.usage import Store
        self.settings = Settings(targets=[Target(id='fake',provider='fake',model='private',base_url='http://fake')], models={'default':ModelRoute(targets=['fake'])}, database=str(tmp_path/'test.db'),credentials=[Credential(env='TEST_ADMIN'),Credential(env='TEST_CALLER',tenant='other',role='caller')])
        self.store = Store(self.settings.database)
        self.calls = []
        self.closed = False
        self.error = None
    def make_context(self, identity, run_id=None, step_id=None):
        return CallContext(identity=identity,run_id=run_id,step_id=step_id)
    async def complete(self, request, context=None):
        self.calls.append((request,context))
        if self.error: raise self.error
        return ModelResult(text='你好',requested_model=request.requested_model,call_id=context.call_id,usage=Usage(input_tokens=3,output_tokens=2))
    async def stream(self, request, context=None):
        self.calls.append((request,context))
        try:
            yield ModelEvent('text.delta',{'delta':'你好'})
            yield ModelEvent('tool.delta',{'index':0,'id':'tool1','type':'function','function':{'name':'lookup','arguments':'{}'}})
            yield ModelEvent('refusal.delta',{'delta':'refuse'})
            yield ModelEvent('model.finished',{'finish_reason':'tool_calls'})
            yield ModelEvent('model.usage',{'input_tokens':3,'output_tokens':2})
            if self.error: raise self.error
            yield ModelEvent('completed',{})
        finally: self.closed = True
    async def close(self): self.store.close()


def test_lifespan_prunes_expired_events_and_retains_checkpoint(tmp_path):
    from studyagent.llm_gateway.app.api.routes import create_app
    async def scenario():
        gateway=FakeGateway(tmp_path)
        gateway.store.create_run('local','old',{'status':'completed','checkpoint':{'position':'model_boundary'}})
        gateway.store.append_event('local','old',{'type':'run.completed'})
        gateway.store._db.execute('UPDATE events SET created=0')
        gateway.store._db.commit()
        app=create_app(gateway=gateway)
        async with app.router.lifespan_context(app):
            assert gateway.store.events('local','old')==[]
            assert gateway.store.get_run('local','old')['checkpoint']['position']=='model_boundary'
        gateway.store.close()
    asyncio.run(scenario())


def test_api_contract_auth_validation_and_protocols(tmp_path,monkeypatch):
    api = importlib.import_module('studyagent.llm_gateway.app.api.routes')
    monkeypatch.setenv('TEST_ADMIN','admin-secret')
    monkeypatch.setenv('TEST_CALLER','caller-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.create_app(gateway=gateway)),base_url='http://test') as c:
            body={'model':'default','messages':[{'role':'user','content':'hi'}]}
            assert (await c.post('/v1/chat/completions',json=body)).status_code==401
            c.headers['Authorization']='Bearer admin-secret'
            r=await c.post('/v1/chat/completions',json=body)
            assert r.status_code==200 and r.json()['choices'][0]['message']['content']=='你好'
            assert r.headers['x-request-id']==gateway.calls[-1][1].call_id
            for invalid in ({**body,'secret_override':'x'}, {**body,'messages':[{'role':'user','content':[{'type':'image_url','image_url':{'url':'x'}}]}]}):
                assert (await c.post('/v1/chat/completions',json=invalid)).status_code==400
            assert len(gateway.calls)==1
            r=await c.post('/v1/responses',json={'model':'default','input':'hi','instructions':'be useful'})
            assert r.status_code==200 and r.json()['output'][0]['content'][0]['text']=='你好'
            assert gateway.calls[-1][0].messages[0].role=='system'
            r=await c.post('/v1/chat/completions',json={**body,'stream':True})
            assert '[DONE]' in r.text and 'tool_calls' in r.text and 'refusal' in r.text and 'prompt_tokens' in r.text
            r=await c.post('/v1/responses',json={'input':'hi','stream':True})
            assert 'event: response.output_text.delta' in r.text and 'event: response.completed' in r.text and '[DONE]' not in r.text
            gateway.error=GatewayError('upstream_timeout','safe',504,True,'upstream')
            r=await c.post('/v1/chat/completions',json={**body,'stream':True})
            assert r.status_code==200 and 'upstream_timeout' in r.text and '[DONE]' not in r.text
            c.headers['Authorization']='Bearer caller-secret'
            assert (await c.get('/admin/routes')).status_code==403
            assert (await c.get('/admin/usage')).status_code==403
            assert (await c.get('/healthz')).status_code==200
        gateway.store.close()
    asyncio.run(scenario())


def test_prompt_tenant_isolation_and_run_routes(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    monkeypatch.setenv('TEST_ADMIN','admin-secret'); monkeypatch.setenv('TEST_CALLER','caller-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        app=api.create_app(gateway=gateway)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            r=await c.post('/v1/runs',json={'messages':[{'role':'user','content':'hi'}]})
            assert r.status_code==201
            run_id=r.json()['run_id']
            await app.state.runs.tasks[run_id]
            r=await c.get(f'/v1/runs/{run_id}/events')
            assert 'run.completed' in r.text
            c.headers['Authorization']='Bearer caller-secret'
            assert (await c.get(f'/v1/runs/{run_id}/events')).status_code==404
        await app.state.runs.close()
        gateway.store.close()
    asyncio.run(scenario())


def test_malformed_nested_fields_are_safe_and_prompt_defaults_survive(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    monkeypatch.setenv('TEST_ADMIN','admin-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        app=api.create_app(gateway=gateway)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            for extra in ({'tools':None},{'tools':'oops'},{'stream_options':None},{'response_format':[]},{'messages':[{'role':'user','content':{'image':'x'}}]}):
                r=await c.post('/v1/chat/completions',json={'messages':[{'role':'user','content':'hi'}],**extra})
                assert r.status_code==400 and 'error' in r.json()
            r=await c.post('/v1/prompts',json={'id':'welcome','system':'Hello {{name}}','input_schema':{'type':'object','properties':{'name':{'type':'string'}},'required':['name'],'additionalProperties':False},'generation':{'max_output_tokens':51,'temperature':0.1}})
            assert r.status_code==200
            from studyagent.llm_gateway.app.services.prompts import PromptService
            from studyagent.llm_gateway.app.schemas import Identity
            normalized=api.normalize({'messages':[{'role':'user','content':'hi'}],'prompt':{'id':'welcome','variables':{'name':'World'}}})
            prepared=PromptService(gateway.store).prepare(normalized,gateway.make_context(Identity()))
            assert prepared.max_output_tokens==51 and prepared.temperature==0.1
            r=await c.post('/v1/runs',json={'messages':[{'role':'user','content':'hi'}]})
            run_id=r.json()['run_id'];await app.state.runs.tasks[run_id]
            stored=gateway.store.get_run('local',run_id)
            stored['checkpoint']['snapshots']={'private_provider_base_url':'http://private'}
            gateway.store.update_run('local',run_id,stored)
            r=await c.post(f'/v1/runs/{run_id}/cancel')
            assert 'checkpoint' not in r.json() and 'request' not in r.json()
        await app.state.runs.close();gateway.store.close()
    asyncio.run(scenario())


def test_proxy_generator_disconnect_closes_upstream(tmp_path):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    from studyagent.llm_gateway.app.schemas import Identity,ModelRequest,Message
    async def scenario():
        gateway=FakeGateway(tmp_path)
        request=ModelRequest(messages=[Message(role='user',content='hi')],stream=True)
        context=gateway.make_context(Identity())
        iterator=api.external_stream(gateway,request,context,'chat')
        await anext(iterator)
        await iterator.aclose()
        assert gateway.closed and context.cancel.is_set()
        gateway.store.close()
    asyncio.run(scenario())


def test_responses_function_choice_normalizes_to_internal_chat_shape():
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    request=api.normalize({'input':[{'type':'function_call','call_id':'c1','name':'lookup','arguments':'{}'},{'type':'function_call_output','call_id':'c1','output':'found'}],'tools':[{'type':'function','name':'lookup','parameters':{'type':'object'}}],'tool_choice':{'type':'function','name':'lookup'}},'responses')
    assert request.tool_choice=={'type':'function','function':{'name':'lookup'}}
    assert request.messages[0].tool_calls[0]['id']==request.messages[1].tool_call_id


def test_proxy_cancel_sets_context_and_closes_upstream(tmp_path):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    from studyagent.llm_gateway.app.schemas import Identity,ModelRequest,Message
    async def scenario():
        gateway=FakeGateway(tmp_path)
        entered=asyncio.Event()
        async def blocking(request,context=None):
            try:
                entered.set();await asyncio.Event().wait()
                yield ModelEvent('completed',{})
            finally: gateway.closed=True
        gateway.stream=blocking
        context=gateway.make_context(Identity())
        iterator=api.external_stream(gateway,ModelRequest(messages=[Message(role='user',content='hi')]),context,'chat')
        task=asyncio.create_task(anext(iterator));await entered.wait();task.cancel()
        with pytest.raises(asyncio.CancelledError): await task
        assert gateway.closed and context.cancel.is_set()
        gateway.store.close()
    asyncio.run(scenario())


def test_prompt_activate_requires_admin_and_preserves_history(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    monkeypatch.setenv('TEST_ADMIN','admin-secret');monkeypatch.setenv('TEST_CALLER','caller-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.create_app(gateway=gateway)),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            for text in ('v1','v2'):
                assert (await c.post('/v1/prompts',json={'id':'versioned','system':text})).status_code==200
            r=await c.post('/v1/prompts/versioned/activate',json={'version':1})
            assert r.status_code==200 and r.json()['version']==1
            assert (await c.get('/v1/prompts/versioned')).json()['system']=='v1'
            assert (await c.get('/v1/prompts/versioned?version=2')).json()['system']=='v2'
            for value,code in (({},400),({'version':999},404)):
                assert (await c.post('/v1/prompts/versioned/activate',json=value)).status_code==code
            c.headers['Authorization']='Bearer caller-secret'
            assert (await c.post('/v1/prompts/versioned/activate',json={'version':1})).status_code==403
        gateway.store.close()
    asyncio.run(scenario())


def test_prompt_activation_rejects_missing_version_before_store(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes');monkeypatch.setenv('TEST_ADMIN','admin-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.create_app(gateway=gateway)),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            assert (await c.post('/v1/prompts/name/activate',json={})).status_code==400
        gateway.store.close()
    asyncio.run(scenario())


def test_nested_function_fields_are_not_silently_forwarded():
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    for message in ({'role':'assistant','tool_calls':[{'id':'c','type':'function','function':{'name':'f','arguments':'{}','secret':'forbidden'}}]}, {'role':'assistant','tool_calls':[{'id':'c','type':'function','function':{'name':'f','arguments':{}}}]}):
        with pytest.raises(GatewayError): api.normalize({'messages':[message]})


def test_unexpected_nonstream_error_is_safe_json(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes');monkeypatch.setenv('TEST_ADMIN','admin-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path);gateway.error=RuntimeError('provider-secret')
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.create_app(gateway=gateway),raise_app_exceptions=False),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            response=await c.post('/v1/chat/completions',json={'messages':[{'role':'user','content':'hi'}]})
            assert response.status_code==500 and response.json()['error']['code']=='internal_error'
            assert 'provider-secret' not in response.text
        gateway.store.close()
    asyncio.run(scenario())


def test_legacy_request_uses_core_schema_prompt_and_deadline(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes');monkeypatch.setenv('TEST_ADMIN','admin-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.create_app(gateway=gateway)),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            response=await c.post('/v1/llm',json={'model':'default','messages':[{'role':'user','content':'hi'}],'response_schema':{'type':'object'},'timeout_seconds':5,'prompt':{'name':'old','version':'v2','variables':{}}})
            assert response.status_code==200
            request,context=gateway.calls[-1]
            assert request.output_schema=={'type':'object'} and request.prompt.id=='old' and request.prompt.version==2
            assert context.budget.remaining()<=5
        gateway.store.close()
    asyncio.run(scenario())


def test_legacy_outputs_and_stream_are_course_contract(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes');monkeypatch.setenv('TEST_ADMIN','admin-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.create_app(gateway=gateway)),base_url='http://test',headers={'Authorization':'Bearer admin-secret'}) as c:
            body={'model':'default','messages':[{'role':'user','content':'hi'}]}
            r=await c.post('/v1/llm',json=body)
            assert r.json()['content']=='你好' and r.json()['request_id']==r.headers['x-request-id']
            assert r.json()['usage']=={'input_tokens':3,'output_tokens':2}
            assert (await c.post('/v1/llm',json={**body,'temperature':0.2})).status_code==400
            r=await c.post('/v1/llm/stream',json=body)
            assert 'content.delta' in r.text and 'response.completed' in r.text and '[DONE]' not in r.text
        gateway.store.close()
    asyncio.run(scenario())


def test_responses_usage_details_preserve_known_and_omit_unknown():
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    assert api.usage({'input_tokens':5,'output_tokens':2,'cached_tokens':3,'reasoning_tokens':1},'responses')=={'input_tokens':5,'output_tokens':2,'total_tokens':7,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':1}}
    assert api.usage({'input_tokens':None,'output_tokens':None},'responses')=={}


@pytest.mark.parametrize('usage_first',[True,False])
@pytest.mark.parametrize('include_usage',[True,False])
def test_chat_stream_canonical_terminal_order(tmp_path,usage_first,include_usage):
    import json
    from studyagent.llm_gateway.app.api.routes import external_stream
    from studyagent.llm_gateway.app.schemas import Identity, ModelRequest, Message
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async def events(request,context):
            yield ModelEvent('text.delta',{'delta':'ok'})
            ending=[ModelEvent('model.usage',{'input_tokens':3,'output_tokens':2}),ModelEvent('model.finished',{'finish_reason':'stop'})]
            for event in ending if usage_first else reversed(ending): yield event
            yield ModelEvent('completed',{'finish_reason':'stop','usage':{'input_tokens':3,'output_tokens':2}})
        gateway.stream=events
        request=ModelRequest(messages=[Message(role='user',content='hi')],include_usage=include_usage)
        frames=[frame async for frame in external_stream(gateway,request,gateway.make_context(Identity()),'chat')]
        assert frames[-1]=='data: [DONE]\n\n'
        chunks=[json.loads(frame.removeprefix('data: ').strip()) for frame in frames[:-1]]
        assert sum(bool(chunk['choices'] and chunk['choices'][0]['finish_reason']) for chunk in chunks)==1
        if include_usage:
            assert chunks[-1]['choices']==[] and chunks[-1]['usage']['prompt_tokens']==3
            assert chunks[-2]['choices'][0]['finish_reason']=='stop'
        else:
            assert chunks[-1]['choices'][0]['finish_reason']=='stop'
            assert all('usage' not in chunk for chunk in chunks)
        gateway.store.close()
    asyncio.run(scenario())


def test_admin_metrics_aggregates_recent_tenant_calls_without_unknown_cost_zero(tmp_path,monkeypatch):
    api=importlib.import_module('studyagent.llm_gateway.app.api.routes')
    monkeypatch.setenv('TEST_ADMIN','admin-secret');monkeypatch.setenv('TEST_CALLER','caller-secret')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        gateway.store.finish_call('local','known',{'status':'completed','attempts':2,'cache_hit':True,'cost_usd':0.125,'usage_status':'known','known_usage':{'input_tokens':10,'output_tokens':4}})
        gateway.store.finish_call('local','unknown',{'status':'failed','attempts':1,'cache_hit':False,'cost_usd':None,'usage_status':'partial','known_usage':{'input_tokens':3,'output_tokens':0}})
        gateway.store.finish_call('other','foreign',{'status':'completed','attempts':100,'cost_usd':999,'known_usage':{'input_tokens':999}})
        app=api.create_app(gateway=gateway)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as c:
            assert (await c.get('/admin/metrics')).status_code==401
            c.headers['Authorization']='Bearer caller-secret'
            assert (await c.get('/admin/metrics')).status_code==403
            c.headers['Authorization']='Bearer admin-secret'
            result=(await c.get('/admin/metrics')).json()
            assert result['window']=={'kind':'recent_calls','limit':1000}
            assert result['recent_calls']==2 and result['status_counts']=={'completed':1,'failed':1}
            assert result['attempts']==3 and result['cache_hits']==1
            assert result['known_cost_usd']==0.125 and result['unknown_cost_calls']==1 and result['cost_status']=='partial'
            assert result['known_token_subtotal']['input_tokens']==13
            assert result['unknown_usage_calls']==1
            for index in range(1001):
                gateway.store.finish_call('local',f'window_{index}',{'status':'failed','cost_usd':None,'usage_status':'unknown'})
            result=(await c.get('/admin/metrics')).json()
            assert result['recent_calls']==1000 and result['known_cost_usd'] is None
            assert result['unknown_cost_calls']==1000 and result['cost_status']=='unknown'
        gateway.store.close()
    asyncio.run(scenario())
