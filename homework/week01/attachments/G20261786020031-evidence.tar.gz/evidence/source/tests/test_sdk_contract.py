import asyncio
import json
import httpx
import pytest
from openai import AsyncOpenAI
from studyagent.llm_gateway.app.api.routes import create_app
from studyagent.llm_gateway.app.services.gateway import Gateway
from studyagent.llm_gateway.app.config import Settings, Target, Capabilities, ModelRoute


def test_real_sdk_through_api_core_and_transport(tmp_path,monkeypatch):
    monkeypatch.setenv("GATEWAY_API_KEY","test-gateway")
    monkeypatch.setenv("TEST_PROVIDER_KEY","test-provider")
    requests=[]
    def upstream(req):
        requests.append(req)
        body=json.loads(req.content)
        if req.url.path.endswith("/responses"):
            return httpx.Response(200,json={"id":"resp_test","status":"completed",
                "output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"responses ok"}]}],
                "usage":{"input_tokens":2,"output_tokens":2}})
        if body.get("stream"):
            events=[
                {"id":"chat_test","choices":[{"index":0,"delta":{"content":"stream ok"}}]},
                {"id":"chat_test","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]},
                {"id":"chat_test","choices":[],"usage":{"prompt_tokens":3,"completion_tokens":2}}]
            text="".join("data: "+json.dumps(x)+"\n\n" for x in events)+"data: [DONE]\n\n"
            return httpx.Response(200,text=text,headers={"content-type":"text/event-stream"})
        return httpx.Response(200,json={"id":"chat_test","choices":[{"index":0,
            "message":{"role":"assistant","content":"chat ok"},"finish_reason":"stop"}],
            "usage":{"prompt_tokens":2,"completion_tokens":1}})
    async def run():
        from studyagent.llm_gateway.app.services.upstream import AdapterRegistry
        settings=Settings(targets=[Target(id="test",provider="test",model="upstream-model",
            base_url="https://upstream.test/v1",api_key_env="TEST_PROVIDER_KEY",
            capabilities=Capabilities(apis={"chat","responses"}))],
            models={"default":ModelRoute(targets=["test"])},database=str(tmp_path/"db"))
        gateway=Gateway(settings,adapters=AdapterRegistry(settings,transport=httpx.MockTransport(upstream)))
        app=create_app(gateway=gateway,settings=settings)
        http=httpx.AsyncClient(transport=httpx.ASGITransport(app=app))
        async with AsyncOpenAI(base_url="http://gateway/v1",api_key="test-gateway",
                               http_client=http,max_retries=0) as client:
            reply=await client.chat.completions.create(model="default",messages=[{"role":"user","content":"hi"}])
            assert reply.choices[0].message.content=="chat ok"
            assert reply.model=="default"
            response=await client.responses.create(model="default",input="hi")
            assert response.output_text=="responses ok"
            stream=await client.chat.completions.create(model="default",messages=[{"role":"user","content":"hi"}],
                                                       stream=True,stream_options={"include_usage":True})
            chunks=[chunk async for chunk in stream]
            assert "".join(c.choices[0].delta.content or "" for c in chunks if c.choices)=="stream ok"
            assert chunks[-1].usage.prompt_tokens==3
        calls=gateway.store.list_calls("local")
        assert len(calls)==3 and all(c["status"]=="completed" for c in calls)
        assert all(json.loads(r.content)["model"]=="upstream-model" for r in requests)
        await gateway.close()
    asyncio.run(run())


@pytest.mark.parametrize('kind',['text','refusal','tool'])
def test_responses_sdk_stream_builds_output_items(tmp_path,monkeypatch,kind):
    from studyagent.llm_gateway.tests.test_api import FakeGateway
    from studyagent.llm_gateway.app.schemas import ModelEvent
    monkeypatch.setenv('TEST_ADMIN','sdk-test')
    async def run():
        gateway=FakeGateway(tmp_path)
        async def events(request,context):
            final={'text':None,'refusal':None,'tool_calls':[],'finish_reason':'stop'}
            if kind=='text':
                yield ModelEvent('text.delta',{'delta':'hello'})
                final['text']='hello'
            elif kind=='refusal':
                yield ModelEvent('refusal.delta',{'delta':'cannot answer'})
                final['refusal']='cannot answer'
            else:
                yield ModelEvent('tool.delta',{'index':0,'id':'call_demo','name':'lookup_note','arguments':'{"query":"x"}'})
                final['tool_calls']=[{'id':'call_demo','type':'function','function':{'name':'lookup_note','arguments':'{"query":"x"}'}}]
                final['finish_reason']='tool_calls'
            yield ModelEvent('completed',final)
        gateway.stream=events
        http=httpx.AsyncClient(transport=httpx.ASGITransport(app=create_app(gateway=gateway)))
        async with AsyncOpenAI(base_url='http://test/v1',api_key='sdk-test',http_client=http,max_retries=0) as client:
            async with client.responses.stream(model='default',input='hi') as stream:
                result=await stream.get_final_response()
            if kind=='text':assert result.output_text=='hello'
            elif kind=='refusal':assert result.output[0].content[0].refusal=='cannot answer'
            else:
                assert result.output[0].name=='lookup_note'
                assert result.output[0].arguments=='{"query":"x"}'
        await gateway.close()
    asyncio.run(run())
