"""Acceptance boundaries: allocation, budgets, retries, joining and partial JSON."""
import asyncio

import pytest

from studyagent.llm_gateway.app.schemas import GatewayError, Identity, ModelEvent, ModelResult
from studyagent.llm_gateway.app.services.gateway import Gateway
from studyagent.llm_gateway.app.services.streaming import IncrementalJSON
from studyagent.llm_gateway.tests.test_gateway import Scripted, config, request


def test_weighted_ratio_health_filter_and_frozen_route(tmp_path):
    async def run():
        settings=config(tmp_path,circuit_threshold=1)
        settings.targets[0].weight=2
        settings.models['default'].strategy='weighted_round_robin'
        adapter=Scripted([ModelResult(text='ok') for _ in range(6)])
        g=Gateway(settings,adapters=adapter)
        for _ in range(6):await g.complete(request())
        assert adapter.calls.count('a')==4 and adapter.calls.count('b')==2
        ctx=g.make_context()
        g.router.candidates(request(),ctx)
        settings.models['default'].targets=['b']
        assert len(g.router.candidates(request(),ctx))==2
        g.router.failure(settings.targets[0],GatewayError('timeout','safe',504,True))
        assert [t.id for t in g.router.candidates(request(),ctx)]==['b']
        assert ctx.snapshots['last_route']['rejected']==[{'target':'a','reason':'circuit_open'}]
        await g.close()
    asyncio.run(run())


@pytest.mark.parametrize('limit,code', [('token','token_budget_exceeded'),('cost','cost_budget_exceeded'),('context','unsupported_capability')])
def test_preflight_budgets_have_zero_provider_calls(tmp_path,limit,code):
    async def run():
        settings=config(tmp_path)
        if limit=='token':settings.token_budget=1
        elif limit=='cost':settings.cost_budget=0.001
        else:
            for t in settings.targets:t.capabilities.max_output_tokens=8
        adapter=Scripted()
        g=Gateway(settings,adapters=adapter)
        with pytest.raises(GatewayError) as exc:await g.complete(request())
        assert exc.value.code==code and adapter.calls==[]
        await g.close()
    asyncio.run(run())


def test_injected_sleep_observes_bounded_backoff_and_preserves_error(tmp_path):
    async def run():
        waits=[]
        async def sleep(seconds):waits.append(seconds)
        transient=GatewayError('upstream_rate_limited','safe',429,True,'upstream')
        settings=config(tmp_path);settings.backoff=0.25
        adapter=Scripted([transient,ModelResult(text='ok')])
        g=Gateway(settings,adapters=adapter,sleep=sleep)
        result=await g.complete(request())
        assert len(waits)==1 and 0.25<=waits[0]<=0.3125
        attempts=g.store.attempts('local',result.call_id)
        assert attempts[0]['error_code']==transient.code and attempts[0]['stage']==transient.stage
        assert attempts[1]['retry_index']==1
        await g.close()
    asyncio.run(run())


def test_concurrent_idempotency_joins_and_isolates_tenant(tmp_path):
    async def run():
        entered=asyncio.Event();release=asyncio.Event()
        class Hold(Scripted):
            async def complete(self,target,req):
                self.calls.append(target.id);entered.set();await release.wait()
                return ModelResult(text='answer')
        adapter=Hold();g=Gateway(config(tmp_path),adapters=adapter)
        first=g.make_context();first.idempotency_key='same'
        second=g.make_context();second.idempotency_key='same'
        one=asyncio.create_task(g.complete(request(),first));await entered.wait()
        two=asyncio.create_task(g.complete(request(),second));await asyncio.sleep(0)
        assert adapter.calls==['a']
        release.set();await asyncio.gather(one,two)
        assert adapter.calls==['a'] and g.store.get_call('local',second.call_id)['cache_hit']
        other=g.make_context(Identity(tenant='other'));other.idempotency_key='same'
        await g.complete(request(),other)
        assert adapter.calls==['a','a'] and len(g.store.list_calls('other'))==1
        await g.close()
    asyncio.run(run())


def test_partial_business_stream_has_one_failure_and_never_repairs(tmp_path):
    async def run():
        adapter=Scripted(events=[ModelEvent('text.delta',{'delta':'{"action":'}),
            ModelEvent('text.delta',{'delta':'"finish"}'}),ModelEvent('model.finished',{'finish_reason':'stop'})])
        g=Gateway(config(tmp_path),adapters=adapter)
        events=[e async for e in g.stream(request(stream=True,business_schema='agent_action'))]
        assert [e.type for e in events].count('failed')==1
        assert all(e.type!='completed' for e in events) and adapter.calls==['a']
        await g.close()
    asyncio.run(run())


def test_incremental_json_rejects_trailing_text_and_incomplete_is_unapproved():
    parser=IncrementalJSON()
    assert parser.feed('{"message":"你') is None and not parser.complete
    assert parser.feed('好"}')=={'message':'你好'} and parser.complete
    with pytest.raises(GatewayError):parser.feed(' extra')
    with pytest.raises(GatewayError):IncrementalJSON(max_chars=4).feed('{"too long":1}')
    with pytest.raises(GatewayError):IncrementalJSON().feed('{]')


def test_stream_transient_failure_before_business_can_retry(tmp_path):
    async def run():
        class FirstFailure(Scripted):
            async def stream(self,target,req):
                self.calls.append(target.id)
                if len(self.calls)==1:raise GatewayError('upstream_network_error','safe',502,True,'upstream')
                yield ModelEvent('text.delta',{'delta':'ok'})
                yield ModelEvent('model.finished',{'finish_reason':'stop'})
        adapter=FirstFailure();g=Gateway(config(tmp_path),adapters=adapter)
        events=[e async for e in g.stream(request(stream=True))]
        assert adapter.calls==['a','a'] and events[-1].type=='completed'
        assert [e.data['delta'] for e in events if e.type=='text.delta']==['ok']
        await g.close()
    asyncio.run(run())


def test_continuous_business_failures_stop_after_one_repair(tmp_path):
    async def run():
        adapter=Scripted([ModelResult(text='{"action":"finish"}') for _ in range(3)])
        g=Gateway(config(tmp_path),adapters=adapter)
        with pytest.raises(GatewayError) as error:await g.complete(request(business_schema='agent_action'))
        assert error.value.code=='schema_validation_failed' and adapter.calls==['a','a']
        trace=g.store.list_calls('local')[0]
        assert trace['status']=='failed' and trace['repair_count']==1
        assert len(trace['validation_failures'])==2
        await g.close()
    asyncio.run(run())


def test_qps_rejection_has_zero_additional_attempts(tmp_path):
    async def run():
        adapter=Scripted([ModelResult(text='ok')])
        g=Gateway(config(tmp_path,burst=1,qps=0.0001),adapters=adapter)
        await g.complete(request())
        with pytest.raises(GatewayError) as error:await g.complete(request())
        assert error.value.code=='rate_limit_exceeded' and adapter.calls==['a']
        await g.close()
    asyncio.run(run())


def test_provider_slot_limits_inflight_and_is_released(tmp_path):
    async def run():
        entered=asyncio.Event();release=asyncio.Event()
        class Hold(Scripted):
            active=0;maximum=0
            async def complete(self,target,req):
                self.calls.append(target.id);self.active+=1;self.maximum=max(self.maximum,self.active)
                entered.set()
                try:
                    await release.wait();return ModelResult(text='ok')
                finally:self.active-=1
        settings=config(tmp_path);settings.targets[0].concurrency=1
        adapter=Hold();g=Gateway(settings,adapters=adapter)
        one=asyncio.create_task(g.complete(request()));await entered.wait()
        two=asyncio.create_task(g.complete(request()));await asyncio.sleep(0)
        assert len(adapter.calls)==1
        release.set();await asyncio.gather(one,two)
        assert adapter.maximum==1 and adapter.active==0
        await g.close()
    asyncio.run(run())
