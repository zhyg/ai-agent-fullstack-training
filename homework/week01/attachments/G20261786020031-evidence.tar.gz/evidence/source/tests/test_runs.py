import asyncio
import importlib
from studyagent.llm_gateway.app.schemas import Identity, ModelRequest, Message
from studyagent.llm_gateway.tests.test_api import FakeGateway


def test_durable_replay_and_cancel_without_reexecution(tmp_path):
    runs=importlib.import_module('studyagent.llm_gateway.app.services.runs')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        manager=runs.RunManager(gateway)
        identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        run_id=record['run_id']
        await manager.tasks[run_id]
        events=[e async for e in manager.events(identity,run_id)]
        assert events[-1]['type']=='run.completed'
        assert [e['seq'] for e in events]==list(range(len(events)))
        replay=[e async for e in manager.events(identity,run_id,after=events[-2]['seq'])]
        assert replay==events[-1:] and len(gateway.calls)==1
        await manager.cancel(identity,run_id)
        assert len([e for e in gateway.store.events(identity.tenant,run_id) if e['type'].startswith('run.') and e['type'] in {'run.completed','run.cancelled','run.failed'}])==1
        await manager.close();gateway.store.close()
    asyncio.run(scenario())


def test_explicit_cancellation_closes_stream_and_is_persisted(tmp_path):
    runs=importlib.import_module('studyagent.llm_gateway.app.services.runs')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        original=gateway.stream
        started=asyncio.Event()
        async def blocked(request,context=None):
            try:
                async for event in original(request,context):
                    started.set();yield event
                    await asyncio.Event().wait()
            finally: gateway.closed=True
        gateway.stream=blocked
        manager=runs.RunManager(gateway)
        identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        await started.wait()
        await manager.cancel(identity,record['run_id'])
        assert gateway.closed
        assert gateway.store.get_run(identity.tenant,record['run_id'])['status']=='cancelled'
        assert gateway.store.events(identity.tenant,record['run_id'])[-1]['type']=='run.cancelled'
        await manager.close();gateway.store.close()
    asyncio.run(scenario())


def test_cancel_after_call_commits_preserves_completed_output(tmp_path):
    from studyagent.llm_gateway.app.services.gateway import Gateway
    from studyagent.llm_gateway.app.services.upstream import FakeAdapter
    from studyagent.llm_gateway.app.schemas import ModelResult
    from studyagent.llm_gateway.tests.test_gateway import config
    from studyagent.llm_gateway.app.services.runs import RunManager
    async def scenario():
        gateway=Gateway(config(tmp_path),adapters=FakeAdapter(results=[ModelResult(text='committed answer')]))
        manager=RunManager(gateway);identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        for _ in range(100):
            if gateway.store.get_call('local',record['call_id']):break
            await asyncio.sleep(0)
        assert gateway.store.get_call('local',record['call_id'])['status']=='completed'
        await manager.cancel(identity,record['run_id'])
        assert manager.get(identity,record['run_id'])['status']=='completed'
        events=gateway.store.events('local',record['run_id'])
        assert any(e['type']=='text.delta' and e['data']['delta']=='committed answer' for e in events)
        assert [e['type'] for e in events if e['type'] in {'run.completed','run.failed','run.cancelled'}]==['run.completed']
        await manager.close();await gateway.close()
    asyncio.run(scenario())


def test_subscriber_disconnect_keeps_worker_and_restart_resume_uses_new_call(tmp_path):
    runs=importlib.import_module('studyagent.llm_gateway.app.services.runs')
    async def scenario():
        gateway=FakeGateway(tmp_path)
        manager=runs.RunManager(gateway);identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        subscription=manager.events(identity,record['run_id'])
        await anext(subscription)
        await subscription.aclose()
        await manager.tasks[record['run_id']]
        assert len(gateway.calls)==1
        orphan={'run_id':'run_orphan','status':'running','request':ModelRequest(messages=[Message(role='user',content='hi')]).model_dump(),'call_id':'call_old','checkpoint':{'snapshots':{'trusted':'snapshot'},'budget':{'attempts':2,'reserved_tokens':100},'side_effects':'none'}}
        gateway.store.create_run('local','run_orphan',orphan)
        restarted=runs.RunManager(gateway)
        assert restarted.get(identity,'run_orphan')['status']=='failed'
        resumed=await restarted.resume(identity,'run_orphan')
        await restarted.tasks[resumed['run_id']]
        context=gateway.calls[-1][1]
        assert context.call_id!='call_old' and context.budget.attempts==2 and context.budget.reserved_tokens==100
        assert context.snapshots['trusted']=='snapshot'
        assert gateway.store.events('local','run_orphan')[-1]['type']=='run.failed'
        await manager.close();await restarted.close();gateway.store.close()
    asyncio.run(scenario())


def test_resume_preserves_omitted_request_fields_for_prompt_defaults(tmp_path):
    runs=importlib.import_module('studyagent.llm_gateway.app.services.runs')
    async def scenario():
        gateway=FakeGateway(tmp_path);gateway.error=__import__('studyagent.llm_gateway.app.schemas',fromlist=['GatewayError']).GatewayError('offline','offline',503)
        manager=runs.RunManager(gateway);identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        await manager.tasks[record['run_id']]
        resumed=await manager.resume(identity,record['run_id']);await manager.tasks[resumed['run_id']]
        assert 'temperature' not in gateway.calls[-1][0].model_fields_set
        await manager.close();gateway.store.close()
    asyncio.run(scenario())


def test_resume_deadline_cannot_relax_current_service_limit(tmp_path):
    import time
    from studyagent.llm_gateway.app.services.runs import RunManager
    async def scenario():
        gateway=FakeGateway(tmp_path);manager=RunManager(gateway)
        record=await manager.create(Identity(),ModelRequest(messages=[Message(role='user',content='hi')]),
            checkpoint={'deadline_at':time.time()+600,'side_effects':'none'})
        context=manager.contexts[record['run_id']]
        assert 0<context.budget.remaining()<=60
        await manager.tasks[record['run_id']]
        await manager.close();gateway.store.close()
    asyncio.run(scenario())


def test_reservation_callback_checkpoints_before_first_event_and_restores_caps(tmp_path):
    runs=importlib.import_module('studyagent.llm_gateway.app.services.runs')
    async def scenario():
        gateway=FakeGateway(tmp_path);original=gateway.stream
        async def reserving(request,context=None):
            context.budget.reserve(23,0.1)
            callback=getattr(context,'on_reservation',None)
            assert callback is not None
            callback()
            record=gateway.store.get_run('local',context.run_id)
            assert record['checkpoint']['budget']['reserved_tokens']==23
            async for event in original(request,context): yield event
        gateway.stream=reserving
        manager=runs.RunManager(gateway)
        checkpoint={'budget':{'max_attempts':2,'max_tokens':100,'max_cost':0.5},'side_effects':'none'}
        record=await manager.create(Identity(),ModelRequest(messages=[Message(role='user',content='hi')]),checkpoint=checkpoint)
        await manager.tasks[record['run_id']]
        saved=gateway.store.get_run('local',record['run_id'])
        assert saved['status']=='completed'
        assert saved['checkpoint']['budget']['max_attempts']==2 and saved['checkpoint']['budget']['max_tokens']==100 and saved['checkpoint']['budget']['max_cost']==0.5
        assert any(e['type']=='run.started' for e in gateway.store.events('local',record['run_id']))
        assert record['run_id'] not in manager.notifications
        await manager.close();gateway.store.close()
    asyncio.run(scenario())


def test_live_subscriber_drains_events_appended_while_yielding(tmp_path):
    runs=importlib.import_module('studyagent.llm_gateway.app.services.runs')
    async def scenario():
        gateway=FakeGateway(tmp_path);manager=runs.RunManager(gateway);identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        iterator=manager.events(identity,record['run_id'])
        first=await anext(iterator)
        await manager.tasks[record['run_id']]
        events=[first]+[event async for event in iterator]
        assert events[-1]['type']=='run.completed'
        assert events==gateway.store.events('local',record['run_id'])
        await manager.close();gateway.store.close()
    asyncio.run(scenario())


def test_run_events_keep_model_stream_positions_separate(tmp_path):
    from studyagent.llm_gateway.app.schemas import ModelEvent
    from studyagent.llm_gateway.app.services.runs import RunManager
    async def scenario():
        gateway=FakeGateway(tmp_path)
        async def stream(request,context):
            yield ModelEvent('text.delta',{'delta':'hello'},call_id=context.call_id,stream_id='stream_example',seq=40)
            yield ModelEvent('completed',{},call_id=context.call_id,stream_id='stream_example',seq=41)
        gateway.stream=stream
        manager=RunManager(gateway);identity=Identity()
        record=await manager.create(identity,ModelRequest(messages=[Message(role='user',content='hi')]))
        await manager.tasks[record['run_id']]
        events=gateway.store.events('local',record['run_id'])
        model_events=[event for event in events if event['type'] in {'text.delta','completed'}]
        assert [event['data']['model_seq'] for event in model_events]==[40,41]
        assert all(event['data']['stream_id']=='stream_example' for event in model_events)
        assert [event['seq'] for event in events]==list(range(len(events)))
        assert model_events[0]['seq']!=model_events[0]['data']['model_seq']
        await manager.close();gateway.store.close()
    asyncio.run(scenario())
