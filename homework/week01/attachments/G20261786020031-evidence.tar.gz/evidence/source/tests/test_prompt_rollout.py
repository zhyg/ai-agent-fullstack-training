"""Offline rollout tests deliberately avoid importing Jinja2/jsonschema."""
import copy
import hashlib
import json

import pytest

from studyagent.llm_gateway.app.schemas import CallContext, GatewayError, Identity
from studyagent.llm_gateway.integration_examples.prompt_rollout import select_prompt_version


class FakeStore:
    def __init__(self):
        self.lookups=[]

    def get_prompt(self, tenant, id, version=None):
        self.lookups.append((tenant,id,version))
        if version not in {1,2}:
            raise GatewayError('unknown_prompt_template','Prompt 模板或版本不存在',404)
        return {'id':id,'version':version,'hash':f'{tenant}-hash-{version}'}


def context(run='run_a',tenant='tenant_a',snapshots=None):
    return CallContext(identity=Identity(tenant=tenant),run_id=run,snapshots=snapshots if snapshots is not None else {})


def select(store, ctx, percentage=50, **kwargs):
    return select_prompt_version(store,ctx,'review',baseline=1,candidate=2,percentage=percentage,**kwargs)


def test_deterministic_tenant_run_hash_and_explicit_version():
    store=FakeStore(); ctx=context()
    ref=select(store,ctx)
    bucket=int.from_bytes(hashlib.sha256(json.dumps(['tenant_a','run_a'],separators=(',',':'),ensure_ascii=False).encode()).digest(),'big')%100
    assert ref.id=='review' and ref.version==(2 if bucket<50 else 1)
    decision=next(iter(ctx.snapshots['rollout'].values()))
    assert decision['bucket']==bucket
    assert decision['reason']==('candidate_bucket' if bucket<50 else 'baseline_bucket')
    assert decision['hash']==f'tenant_a-hash-{ref.version}'
    assert store.lookups==[('tenant_a','review',ref.version)]
    assert select(FakeStore(),context()).version==ref.version


def test_same_run_shared_snapshots_ignore_rollout_ratio_changes():
    store=FakeStore(); first=context(); variables={'question':'original'}
    old=select(store,first,percentage=100,variables=variables)
    saved=copy.deepcopy(first.snapshots)
    next_call=context(snapshots=first.snapshots)
    new=select(store,next_call,percentage=0,variables={'question':'next'})
    assert old.version==new.version==2
    assert first.snapshots==saved
    assert len(store.lookups)==1
    assert new.variables=={'question':'next'}
    old.variables['question']='changed'
    assert variables=={'question':'original'}


def test_percentage_boundaries_and_tenant_snapshot_isolation():
    store=FakeStore(); shared={}
    assert select(store,context(tenant='a',snapshots=shared),percentage=0).version==1
    assert select(store,context(tenant='b',snapshots=shared),percentage=100).version==2
    assert select(store,context(run='run_b',tenant='a',snapshots=shared),percentage=100).version==2
    assert len(shared['rollout'])==3


@pytest.mark.parametrize('kwargs',[{'baseline':0},{'candidate':True},{'percentage':-1},{'percentage':101},{'percentage':float('nan')}])
def test_invalid_rollout_configuration_is_safe_4xx(kwargs):
    store=FakeStore(); args={'baseline':1,'candidate':2,'percentage':50}; args.update(kwargs)
    with pytest.raises(GatewayError) as e:
        select_prompt_version(store,context(),'review',**args)
    assert e.value.status==400
    assert store.lookups==[]


def test_missing_run_or_selected_version_does_not_freeze_invalid_decision():
    store=FakeStore(); ctx=context(); ctx.run_id=None
    with pytest.raises(GatewayError): select(store,ctx)
    ctx=context()
    with pytest.raises(GatewayError):
        select_prompt_version(store,ctx,'review',baseline=1,candidate=99,percentage=100)
    assert ctx.snapshots.get('rollout',{})=={}


def test_real_prompt_service_rollout_when_schema_dependency_available():
    pytest.importorskip('jsonschema', reason='real Prompt integration requires installed jsonschema')
    from studyagent.llm_gateway.app.services.usage import Store
    from studyagent.llm_gateway.app.services.prompts import PromptService
    from studyagent.llm_gateway.app.schemas import ModelRequest
    store=Store(':memory:')
    try:
        store.save_prompt('tenant_a',{'id':'review','system':'baseline'})
        store.save_prompt('tenant_a',{'id':'review','system':'candidate','status':'candidate'},activate=False)
        ctx=context()
        ref=select(store,ctx,percentage=100)
        request=ModelRequest(messages=[{'role':'user','content':'inspect'}],prompt=ref)
        assert PromptService(store).prepare(request,ctx).messages[0].content=='candidate'
        assert select(store,context(snapshots=ctx.snapshots),percentage=0).version==2
    finally:
        store.close()
