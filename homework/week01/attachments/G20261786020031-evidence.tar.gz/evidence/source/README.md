# 作业一：LLM 统一模型调用服务

第一章 1.1～1.7 的完整作业。一个**模块化单体**的 LLM Gateway：把 Chat Completions、Responses、原课薄接口统一到一条执行链上，集中处理路由、鉴权、预算、重试、流式、Run、Prompt 版本、结构化校验和账本。

技术栈：Python 3.12 + FastAPI + Pydantic v2 + SQLite + httpx/openai SDK。单进程部署，无外部中间件。

## 当前状态

| 检查项 | 结果 | 证据 |
| --- | --- | --- |
| 离线测试 | **211 passed / 0 failed / 0 skipped** | `reports/pytest-summary.json` |
| 静态检查 | `All checks passed!` | `ruff check studyagent/llm_gateway` |
| 依赖健康 | `No broken requirements found.` | `pip check` |
| 容器 | 镜像构建成功，`/healthz`、`/readyz`、错误路径实测通过 | 本文「容器运行」 |
| 真实供应商 | `smoke --live` **3/3**（chat / stream / structured） | `reports/live-smoke.json` |
| 旧课回归 | day01～day03 共 20 passed，原课代码未改 | — |

`smoke --live` 只证明**链路通**，不证明提示词质量达标。依赖真实模型质量的评测结论不在本次交付内。

## 快速开始

### 1. 安装依赖

```bash
cd /Users/tcy/geektime/llmstudy
.venv/bin/python -m pip install -r studyagent/llm_gateway/requirements-dev.txt
```

### 2. 配置

配置按以下顺序加载，**前面的来源不会被后面的覆盖**：

1. 已存在的进程环境变量
2. `studyagent/.env`（项目根下）
3. `studyagent/llm_gateway/.env`

需要的变量：

| 变量 | 必填 | 说明 |
| --- | --- | --- |
| `DEEPSEEK_API_KEY` | 是 | 上游供应商密钥，只在网关进程内使用 |
| `DEEPSEEK_BASE_URL` | 否 | API 根路径，可含 `/v1`，**不能**填完整的 `/chat/completions` |
| `DEEPSEEK_MODEL` | 否 | 实际模型名，默认 `deepseek-chat` |
| `GATEWAY_API_KEY` | 是 | **访问你自己网关的凭证**，与供应商密钥完全独立 |
| `GATEWAY_CALLER_KEY` | 否 | 低权限身份，只能调模型，不能看管理接口 |
| `GATEWAY_CONFIG` | 否 | 指向自定义 JSON 配置，见 `settings.example.json` |
| `GATEWAY_HOST` / `GATEWAY_PORT` | 否 | 监听地址与端口，默认 `127.0.0.1:8003` |

`GATEWAY_API_KEY` 是你自己定的随机串，不是 DeepSeek 发的：

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

### 3. 启动

```bash
export GATEWAY_API_KEY='换成你生成的随机串'
.venv/bin/python -m studyagent.llm_gateway.smoke          # 只检查配置，不联网
.venv/bin/python -m studyagent.llm_gateway.app.main       # 启动服务
```

打开 <http://127.0.0.1:8003/docs> 看接口，<http://127.0.0.1:8003/demo> 看 Run 订阅演示。

也可以走工厂入口（单 worker 是本章约定）：

```bash
.venv/bin/python -m uvicorn studyagent.llm_gateway.app.api.routes:create_app \
  --factory --host 127.0.0.1 --port 8003 --workers 1 --no-access-log
```

PyCharm：解释器选根目录 `.venv/bin/python`，Module name 填 `studyagent.llm_gateway.app.main`，Working directory 选 `/Users/tcy/geektime/llmstudy`，把变量写进 Run Configuration。**已经启动的进程不会自动继承之后在终端里新增的变量。**

### 4. 第一次调用

```bash
curl http://127.0.0.1:8003/v1/chat/completions \
  -H "Authorization: Bearer $GATEWAY_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"model":"default","messages":[{"role":"user","content":"一句话解释 LLM Gateway"}]}'
```

流式：加 `"stream":true,"stream_options":{"include_usage":true}`，curl 加 `-N`。

用 OpenAI SDK 时**关掉客户端重试**，重试预算由网关统一管理：

```python
import os
from openai import OpenAI

with OpenAI(base_url="http://127.0.0.1:8003/v1",
            api_key=os.environ["GATEWAY_API_KEY"], max_retries=0) as client:
    r = client.chat.completions.create(
        model="default", messages=[{"role": "user", "content": "解释模型适配器"}])
    print(r.choices[0].message.content)
```

`default` 是**逻辑模型名**，不是供应商模型名。真实模型、供应商、路由决策都进 Trace。

## 目录结构

```
llm_gateway/
├── app/
│   ├── main.py              应用组装与生命周期
│   ├── config.py            环境、端点、能力、价格、预算、身份
│   ├── schemas.py           内部请求/结果/事件/上下文契约
│   ├── api/
│   │   ├── routes.py        HTTP 兼容层、管理接口、Run 入口、DEMO 页
│   │   └── response_events.py  Responses 事件生命周期编码
│   ├── core/
│   │   ├── errors.py        稳定错误契约
│   │   ├── security.py      Bearer 身份与管理员权限
│   │   └── rate_limit.py    租户 QPS、并发、有界队列、供应商槽
│   └── services/
│       ├── gateway.py       统一执行与唯一收口
│       ├── router.py        能力过滤、健康、优先级、权重
│       ├── upstream.py      Chat / Responses / Fake 适配器（不负责重试）
│       ├── prompts.py       Bundle 校验、沙箱渲染、版本快照
│       ├── structured.py    三层输出校验与业务协议
│       ├── streaming.py     增量 JSON 暂存与检查
│       ├── sse.py           字节分帧、缓冲上限
│       ├── runs.py          独立任务、重放、Checkpoint
│       └── usage.py         SQLite 账本与本章仓储
├── integration_examples/    最小 Loop、CLI 客户端、固定 Eval、灰度示例
├── prompts/                 代码审查 Bundle
├── tests/                   15 个文件、201 个用例
├── reports/                 测试与联调的机器可读证据
├── Dockerfile / compose.yaml / Makefile
├── requirements.txt / requirements-dev.txt / pyproject.toml
├── settings.example.json    多端点、价格、治理配置示例
└── .env.example             环境变量样例
```

目录职能参考老师 1.7 示例。Streaming/Run 是本章新增能力，因此额外保留 `sse.py`、`streaming.py`、`runs.py` 的独立职责，没有为了目录同名而删功能。

## 一次请求怎么走

```
客户端
  │  Authorization: Bearer <GATEWAY_API_KEY>
  ▼
API 层 routes.py ── 鉴权 → 参数校验 → 归一化为 ModelRequest
  │
  ▼
Gateway.complete / .stream ── 唯一收口点
  │  ① PromptService.prepare   固定 Bundle 版本与变量
  │  ② Router.candidates       能力/健康/参数/上下文过滤 → 排序
  │  ③ Budget.reserve          deadline、尝试、Token、费用
  │  ④ Admission               租户 QPS、并发、队列、供应商槽
  │  ⑤ Adapter.complete/stream 真实协议调用
  │  ⑥ validate_output         JSON → Schema → 业务三层校验
  │  ⑦ Store.finish_call       唯一提交，写账本
  ▼
客户端 ← 归一化结果 / 稳定错误
```

重试、fallback、repair **共用同一份预算**。已经发出业务增量的流，不再透明重生成。

## 接口清单

| 入口 | 说明 |
| --- | --- |
| `POST /v1/chat/completions` | 文本 messages、function tools/tool_choice、temperature/top_p、max_tokens 或 max_completion_tokens、response_format 的 text/json_schema、SSE + include_usage |
| `POST /v1/responses` | 文本 input/instructions、message 文本项、function_call/function_call_output、function 工具、text.format、max_output_tokens、流式子集 |
| `GET /v1/models` | 公开的逻辑模型列表 |
| `POST /v1/llm`、`/v1/llm/stream` | 原课 1.6 薄适配：`response_schema`、`timeout_seconds`、`prompt.name/version/variables`，复用同一个执行器 |
| `GET/POST /v1/prompts`、`GET /v1/prompts/{id}`、`POST /v1/prompts/{id}/render` | 保存、列表、版本读取与渲染；写入需要管理员 |
| `POST /v1/prompts/{id}/activate` | `{"version":1}` 原子切换活动版本，可回退 |
| `POST /v1/runs`、`GET /v1/runs/{id}`、`GET /v1/runs/{id}/events` | 创建后台 Run、状态查询、持久化 SSE 订阅 |
| `POST /v1/runs/{id}/cancel`、`/resume` | 显式取消；恢复创建新 Run/Call，旧事件历史保留 |
| `GET /v1/streams/{request_id}/checkpoint` | 取回直接代理流已生成的正文片段（需开启 `stream_checkpoint`，按租户隔离） |
| `GET /admin/routes`、`/admin/usage`、`/admin/traces`、`/admin/traces/{call_id}`、`/admin/metrics` | 当前管理员所属租户的配置、账本、逐次尝试、最近调用聚合 |
| `GET /healthz`、`/readyz` | 存活与本地配置就绪。**ready 不承诺上游密钥有效或网络通畅** |

兼容是**上述受支持子集**。多模态、文件、音频、内置搜索工具、Responses 的 conversation/store/previous_response_id 以及其他未知字段一律明确拒绝，不做静默丢弃。

默认 DeepSeek 端点只声明 Chat 能力；要用 Responses 必须配置真正支持 `/responses` 的目标。

## 三条执行路径

| 路径 | 谁拥有执行生命周期 | 断连后 |
| --- | --- | --- |
| 普通调用 | 当前 Call | 取消并收口 |
| 直接代理流 | 当前 Call / Stream | 关闭对应上游 |
| 独立 Run | 后台 Harness 任务 | 只断订阅，任务继续；需显式 cancel |

- **普通调用**：重试、切换、修复共享 deadline / 尝试 / Token / 费用预算。租户槽覆盖整次调用，供应商槽只覆盖实际尝试。
- **直接代理流**：边读边转发，断连即关上游；首业务增量之后失败就明确结束，不拼接重生成。
- **独立 Run**：后台任务持有执行权。恢复用新 Run/Call，**不能从模型的任意 Token 续传**。成功已提交后取消，不会覆盖已成立的结果。

### 事件契约

| 通道 | 事件名 |
| --- | --- |
| Run 订阅 | `run.created` → `run.started` → `text.delta` / `tool.delta` / `refusal.delta` → `model.usage` → `model.finished` → `completed` → `run.completed`（失败走 `failed` + `run.failed`） |
| 内部 Gateway 流 | `text.delta`、`tool.delta`、`refusal.delta`、`model.usage`、`model.finished`、`completed` / `failed` |
| 原课 `/v1/llm/stream` | `content.delta`，终态 `response.failed` |

两套词表不要混：Run 流用 `run.*` + `text.delta`，原课流用 `content.delta`。

Run 事实事件用 `(run_id, seq)` 定位，内部保留来源 `stream_id` / `model_seq`，两个位置不能当全局序号用。`Last-Event-ID` 传最后处理过的 seq，重连后丢弃 `seq <= last`。注释心跳不占 seq。未知事件可记录后跳过；未知 `schema_version` 应停止消费并升级客户端。

```bash
.venv/bin/python -m studyagent.llm_gateway.integration_examples.client '解释 SSE' --url http://127.0.0.1:8003
# 重连：--run-id <上次 run_id> --after <最后 seq>
```

浏览器里用 fetch/ReadableStream 携带 Authorization，**密钥不要放 URL**。

### 断线后的正文恢复（可选）

直接代理流默认**不保存正文**。开启 `stream_checkpoint` 后，网关在生成过程中按 `flush_interval_seconds` 节流写入已产出的文本，客户端断线后可以取回：

```bash
curl http://127.0.0.1:8003/v1/streams/$REQUEST_ID/checkpoint \
  -H "Authorization: Bearer $GATEWAY_API_KEY"
```

```json
{"request_id": "call_...", "stream_id": "stream_...", "status": "cancelled",
 "text": "已经生成的部分", "chars": 7, "truncated": false,
 "finish_reason": null, "updated_at": 1793525139.7}
```

- 默认关闭：把模型正文落库是隐私决策，需要显式开启。
- `flush_interval_seconds: 0` 表示每个增量都写（写入更密，适合调试）。
- `max_chars` 是硬上限，超出部分截断并把 `truncated` 置为 true。
- 状态只会是 `streaming` / `completed` / `failed` / `cancelled`；断线后是 `cancelled`，正文保留断线前最后一次写入的内容。
- 检查点按租户隔离，跨租户查询返回 404 `checkpoint_not_found`，与 Run 事件一起按 `event_retention_seconds` 过期清理。

这和 Run 重放是两条不同的路：Run 重放的是**事件**，恢复会开新 Call 重跑；检查点保住的是**已经生成的那段文本**，不会重复计费。

## 核心机制

### 路由与能力

先按 API 类型、流式、tools、结构化、参数、上下文、健康状态过滤，再按 `priority` 或 `weighted_round_robin` 选首选，备用目标仍需满足能力。权重按 Call 分配一次，不按重试次数漂移。

Context 用 UTF-8 字节 + 协议余量做**保守估算**，不冒充精确 tokenizer；超预算直接拒绝，不粗暴裁剪工具消息（会破坏 tool call 配对）。

### 预算、重试与退避

`deadline` 是真实总时限，覆盖等待和在途调用。`max_attempts` 管总尝试次数，`max_repairs` 管结构化修复次数，三者共享预算。退避有区间上界，可用注入 sleep 验证。认证类错误 `retryable=false`，不浪费重试。

### Prompt Bundle

Bundle 包含 system、input/output_schema、few_shot、tools/version、模型与生成参数、预算、Eval 阈值、状态、change_note。版本与 hash 由仓储生成。

```bash
curl http://127.0.0.1:8003/v1/prompts \
  -H "Authorization: Bearer $GATEWAY_API_KEY" \
  -H 'Content-Type: application/json' \
  --data-binary @studyagent/llm_gateway/prompts/review.prompt.json
```

调用时传 `prompt: {"id":"code-review","variables":{"goal":"检查输入边界","path":"app.py"}}`，待审代码放 messages。模板渲染在 Jinja 沙箱内，**模板数据不会被当模板执行**；缺变量和超长输入在上游调用之前就失败。

灰度是可信 Harness 里的确定性分桶示例，不引入发布平台。候选发布、回退与 Run 快照互不覆盖。

### 结构化输出

三层校验：JSON 语法 → JSON Schema → 业务协议。业务协议可用 `business_schema="task_plan" | "ticket" | "patch_plan" | "agent_action"`，对外用 json_schema 表达合同。

- 不合法或未完成的 JSON **不交给工具**。
- 修复次数有上限，连续业务失败只修一次就停。
- 流式中间结果只暂存不执行，最终整体校验。
- 修改计划只给工作区相对路径和风险，**不实际编辑文件**。

### 幂等与缓存

`Idempotency-Key` 只用于非流式完成：同租户/主体/权限的相同请求在 TTL 内复用，并发请求等待同一结果，键冲突返回 409。流式幂等用独立 Run + 重放，**不承诺供应商只计费一次**。只读结果缓存需显式开启，不缓存工具动作，降级时标 `degraded`。

### 限流与熔断

租户 QPS（令牌桶 + burst）、并发上限、有界等待队列；供应商并发槽只覆盖实际尝试，尝试结束立即释放。队列满返回 429 `queue_full`，QPS 超限返回 429 `rate_limit_exceeded`。熔断按连续失败计数 + 冷却窗口。

以上都是**单进程内存状态**，SQLite 持久化不会把它们变成多副本共享。

### 账本与观测

每次 attempt 单独记账，包括重试和修复。Call 的 `usage` 是全部尝试总量，`result_usage` 是最后一次响应，`known_usage` 是可知部分，`usage_status` 标注是否完整。未知用量/价格保留 `unknown` 或 `partial`，**不推断为免费**。

账本默认只存路由、版本、错误、用量、时间，**不存完整提示/回答，也不存认证头**。

## 错误码

统一响应体：

```json
{"error": {"code": "...", "message": "...", "type": "<stage>_error", "param": null, "request_id": "call_..."}}
```

| HTTP | 典型 code |
| --- | --- |
| 400 | `invalid_request`、`unsupported_parameter`、`invalid_tools`、`invalid_schema`、`capability_unsupported`、`context_limit_exceeded`、`invalid_prompt_*`、`missing_prompt_variable` |
| 401 | `authentication_failed` |
| 403 | `permission_denied` |
| 404 | `unknown_model`、`run_not_found`、`trace_not_found` |
| 409 | `run_exists`、`run_not_resumable`、`idempotency_conflict`、`prompt_not_publishable`、`side_effect_review_required` |
| 413 | `request_too_large` |
| 422 | `schema_validation_failed`、`output_truncated` |
| 429 | `rate_limit_exceeded`、`queue_full` |
| 500 | `internal_error` |
| 502 | `upstream_auth_error`、`stream_failed`、`stream_incomplete`、`upstream_network_error` |
| 503 | `provider_not_configured`、`dependency_unavailable` |
| 504 | `deadline_exceeded`、`timeout` |

## 多端点与治理配置

需要多端点/价格/额度时，复制 `settings.example.json` 并设置 `GATEWAY_CONFIG` 指向它。

配置文件支持 `${VAR}` 与 `${VAR:-默认值}` 展开，在 `model_validate` 之前对字符串递归处理；变量不存在且无默认值时展开为空串。密钥可以直接内联为 `"api_key": "${DEEPSEEK_API_KEY}"`（`SecretStr` 承载，打印不会泄漏），也可以继续用 `api_key_env` 指向环境变量名——内联值优先。

```json
{"targets": [{"id": "primary", "provider": "deepseek", "model": "${DEEPSEEK_MODEL:-deepseek-chat}",
              "base_url": "${DEEPSEEK_BASE_URL:-https://api.deepseek.com/v1}",
              "api_key": "${DEEPSEEK_API_KEY}", "extra_headers": {}}]}
```

除 `api_key` 外，其余字段仍是显式替换：文件里的模型、URL、能力不会去猜。

主要字段：

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `deadline` | 60 | 单次调用总时限（秒） |
| `max_attempts` | 6 | 总尝试次数上限 |
| `max_repairs` | 1 | 结构化修复次数上限 |
| `backoff` | 0.25 | 退避基数 |
| `tenant_concurrency` / `queue_limit` | 4 / 16 | 租户并发与等待队列 |
| `qps` / `burst` | 10 / 20 | 令牌桶速率与突发 |
| `circuit_threshold` / `circuit_cooldown` | 3 / 15 | 熔断阈值与冷却 |
| `token_budget` / `cost_budget` | 100000 / 未设 | Token 与费用预算 |
| `event_retention_seconds` | 86400 | Run 事件保留时长，启动时清理过期事件 |
| `cache_ttl` | 300 | 只读缓存 TTL |
| `stream_checkpoint` | 关闭 | `{enabled, flush_interval_seconds, max_chars}`，直接代理流的正文检查点 |

价格是自配的「每百万 Token 美元估算」+ version，项目不硬编码实时价格。配了 `cost_budget` 却没配价格时，会在上游调用前提前拒绝。

## 测试

```bash
cd /Users/tcy/geektime/llmstudy
.venv/bin/python -m pytest -q studyagent/llm_gateway/tests    # 211 passed
.venv/bin/python -m ruff check studyagent/llm_gateway
.venv/bin/python -m compileall -q studyagent/llm_gateway
.venv/bin/python -m studyagent.llm_gateway.integration_examples.evaluate   # 固定 Eval 3/3
.venv/bin/python -m studyagent.llm_gateway.smoke --live                    # 真实调用 3 次
```

测试默认**完全离线**。SDK 契约用真实 OpenAI SDK → ASGI → 核心执行器 → MockTransport，能验证协议兼容性，不能证明真实供应商可连。`--live` 才会请求供应商，普通/流式/结构化各一次，禁用重试与修复，单项 20 秒上限，不打印密钥和正文。

| 测试文件 | 用例数 | 覆盖重点 |
| --- | --- | --- |
| `test_adapters.py` | 59 | Chat/Responses/Fake 协议翻译、错误映射、流式事件、截断与 usage |
| `test_gateway.py` | 21 | 执行链、预算、退避、收口、取消仲裁 |
| `test_prompts.py` | 20 | Bundle 校验、沙箱、变量 Schema、版本 |
| `test_structured.py` | 19 | 三层校验、业务协议、有限修复、增量 JSON |
| `test_api.py` | 19 | 鉴权、租户隔离、错误契约、管理接口 |
| `test_policies.py` | 12 | 路由权重、熔断、限流、幂等 |
| `test_prompt_rollout.py` | 10 | 分桶、原子激活、Run 快照固定 |
| `test_runs.py` | 9 | 重放、取消、恢复、检查点 |
| `test_storage.py` | 7 | 账本唯一提交、事件序号、租户隔离 |
| `test_environment.py` | 10 | 配置加载、`${ENV}` 展开、密钥优先级与快照脱敏、依赖缺失 |
| `test_stream_checkpoints.py` | 6 | 检查点默认关闭、断线保留部分正文、截断、租户隔离、过期清理 |
| `test_client.py` | 5 | CLI 客户端、重连、TTFT |
| `test_sse.py` | 4 | 字节分片、CRLF、多行 data、心跳 |
| `test_sdk_contract.py` | 4 | 真实 SDK 离线契约 |
| `test_loop.py` | 3 | 最小 Loop、重复动作、步数 |
| `test_domain.py` | 3 | 内部契约类型 |

## 容器运行

```bash
cd /Users/tcy/geektime/llmstudy/studyagent/llm_gateway
export DEEPSEEK_API_KEY=... GATEWAY_API_KEY=...
docker compose up --build -d
curl -s http://127.0.0.1:8003/readyz
docker compose logs --tail=30
docker compose down          # 数据在命名卷，down 不删数据
```

镜像基于 `python:3.12-slim`，非 root 用户 `gateway` 运行，单进程。绑定 `127.0.0.1:8003`，SQLite 放命名卷。

**容器内读不到宿主机的 `studyagent/.env`**（镜像只 COPY 了 `studyagent/llm_gateway`），必须显式传入：

```bash
docker run -d --name gw-local -p 127.0.0.1:8003:8003 \
  --env-file /Users/tcy/geektime/llmstudy/studyagent/.env \
  -e GATEWAY_API_KEY=你的网关凭证 \
  llm-gateway:acceptance
```

## 常见问题

**`pip check` 报 `MarkupSafe ... is not supported on this platform`**
装到了别的 Python 版本的轮子。核对 `site-packages/markupsafe-*.dist-info/WHEEL` 里的 `Tag:`，应为 `cp312-cp312-...`。修复：

```bash
.venv/bin/python -m pip install --force-reinstall --no-deps MarkupSafe==3.0.4
```

**`pytest` 报 `FileExistsError: pytest-of-<user>`**
复用同一个临时基目录导致的，不是代码问题：

```bash
.venv/bin/python -m pytest -q studyagent/llm_gateway/tests --basetemp=/tmp/gw-basetemp
```

**`docker build` 报 `failed to update builder last activity time`**
buildx 在受限环境写 `~/.docker/buildx/activity` 被拒绝，改用传统 builder：

```bash
DOCKER_BUILDKIT=0 docker build -f Dockerfile -t llm-gateway:acceptance ../..
```

**调用返回 502 `upstream_auth_error`**
上游密钥无效或没注入到**实际运行的进程**。`/readyz` 返回 ready 只说明本地配置就绪，不代表上游可用。用 `smoke`（不带 `--live`）看 `provider_credential_available` 是否为 true。

**调用返回 401 `authentication_failed`**
`Authorization: Bearer <值>` 里的值要和 `GATEWAY_API_KEY` 环境变量一致。注意这不是 DeepSeek 的 key。

**改了 `.env` 但没生效**
`load_dotenv(..., override=False)` 不会覆盖已存在的进程环境变量。旧变量还留在 shell 里时，新值读不到；换个终端或先 `unset`。

## 保存范围与边界

- 调用账本只存路由、版本、错误、用量、时间。独立 Run 为重放会存输入、事件和配置快照，**只应放本地学习数据**。
- 事件保留时长由 `event_retention_seconds` 控制，启动时清理过期事件；Run 与 Checkpoint 随本地数据库保留。
- 清理演示数据：先停服务，再备份或删除 `data/gateway.db`。
- QPS、并发、熔断、幂等锁是单进程状态。多副本需要共享 Budget/Admission、事件通知和外部任务队列，本次**不引入**这些基础设施。
- 本章只交付 Gateway 与教学集成。真实 Tool Runtime、任意代码执行、Sandbox、RAG、Memory 留给后续章节。
- 既有 day01～day03 与课程源码保持独立，未修改。

在本目录还可以用 `make install` / `make run` / `make test` / `make lint` / `make eval` / `make smoke` / `make docker`。根目录的 `main.py` 只做启动转发，应用组装在 `app/main.py`。

> 设计过程文档（架构提示词、验收记录、审阅说明等）保留在本地但不纳入版本管理，交付以本 README 为准。
