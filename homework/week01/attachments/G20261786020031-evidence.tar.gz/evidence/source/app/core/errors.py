from __future__ import annotations

class GatewayError(Exception):
    def __init__(self, code: str, message: str, status: int = 400,
                 retryable: bool = False, stage: str = "request", details: list[dict] | None = None):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status
        self.retryable, self.stage = retryable, stage
        self.details = details or []

    def payload(self, request_id: str | None = None) -> dict:
        return {"error": {"code": self.code, "message": self.message,
                          "type": self.stage + "_error", "param": None,
                          "request_id": request_id}}
