"""Trusted identity mapping; request JSON cannot set tenant or role."""
import hmac
import os

from .errors import GatewayError


def authenticate(settings, authorization, admin=False):
    token = authorization[7:] if authorization.startswith('Bearer ') else ''
    identity = None
    for credential in settings.credentials:
        expected = os.environ.get(credential.env, '')
        if expected and hmac.compare_digest(token.encode(), expected.encode()):
            identity = credential.identity()
    if identity is None:
        raise GatewayError('authentication_failed', '网关凭证无效', 401, stage='auth')
    if admin and identity.role != 'admin':
        raise GatewayError('permission_denied', '需要管理员权限', 403, stage='auth')
    return identity
