import asyncio
import time
from contextlib import asynccontextmanager
from ..schemas import GatewayError


class Governance:
    """Single-process tenant admission and per-provider inflight limits."""
    def __init__(self, settings):
        self.settings = settings
        self.tenants, self.providers, self.waiting, self.buckets = {}, {}, {}, {}

    @asynccontextmanager
    async def tenant(self, context):
        context.check()
        key = context.identity.tenant
        now = time.monotonic()
        tokens, last = self.buckets.get(key, (float(self.settings.burst), now))
        tokens = min(float(self.settings.burst), tokens + (now-last)*self.settings.qps)
        if tokens < 1:
            raise GatewayError("rate_limit_exceeded", "租户请求频率超限", 429, stage="admission")
        self.buckets[key] = (tokens-1, now)
        sem = self.tenants.setdefault(key, asyncio.Semaphore(self.settings.tenant_concurrency))
        if sem.locked() and self.waiting.get(key, 0) >= self.settings.queue_limit:
            raise GatewayError("queue_full", "租户等待队列已满", 429, stage="admission")
        self.waiting[key] = self.waiting.get(key, 0) + 1
        acquired = False
        queued = time.monotonic()
        try:
            try:
                await sem.acquire()
            finally:
                self.waiting[key] -= 1
                context.observations.setdefault("timings_ms", {})["queue"] = (time.monotonic()-queued)*1000
            acquired = True
            context.check()
            yield
        finally:
            if acquired:
                sem.release()

    @asynccontextmanager
    async def provider(self, target, context):
        sem = self.providers.setdefault(target.provider, asyncio.Semaphore(target.concurrency))
        async with sem:
            context.check()
            yield
