"""Small single-process Harness: worker owns generation; subscribers only replay facts."""
from __future__ import annotations

import asyncio
import time
from contextlib import aclosing, suppress
from dataclasses import asdict

from ..schemas import GatewayError, Identity, ModelRequest, new_id

TERMINAL = {'completed', 'failed', 'cancelled'}


class RunManager:
    def __init__(self, gateway):
        self.gateway = gateway
        self.store = gateway.store
        self.tasks: dict[str, asyncio.Task] = {}
        self.contexts = {}
        self.notifications = {}

    def get(self, identity, run_id):
        record = self.store.get_run(identity.tenant, run_id)
        if record is None:
            raise GatewayError('run_not_found', 'Run 不存在', 404)
        # A durable running record without a live worker is an interrupted run.
        if record['status'] not in TERMINAL and run_id not in self.tasks:
            record['status'] = 'failed'
            record['error'] = 'worker_interrupted'
            self.store.update_run(identity.tenant, run_id, record)
            self._emit(identity, run_id, 'run.failed', {'code': 'worker_interrupted'})
        return record

    def _emit(self, identity, run_id, kind, data):
        event = {'schema_version': 1, 'run_id': run_id,
                 'type': kind, 'timestamp': time.time(), 'data': data}
        event = self.store.append_event(identity.tenant, run_id, event)
        signal = self.notifications.get(run_id)
        if signal: signal.set()
        return event

    async def create(self, identity: Identity, request: ModelRequest, *, checkpoint=None):
        run_id = new_id('run')
        context = self.gateway.make_context(identity, run_id=run_id, step_id='model')
        if checkpoint:
            context.snapshots.update(checkpoint.get('snapshots', {}))
            saved = checkpoint.get('budget', {})
            for key in ('max_attempts','max_tokens'):
                if key in saved: setattr(context.budget,key,min(getattr(context.budget,key),saved[key]))
            if saved.get('max_cost') is not None:
                context.budget.max_cost=min(context.budget.max_cost,saved['max_cost']) if context.budget.max_cost is not None else saved['max_cost']
            for key in ('attempts', 'reserved_tokens', 'reserved_cost'):
                if key in saved: setattr(context.budget, key, saved[key])
            if 'deadline_at' in checkpoint:
                context.budget.deadline = min(context.budget.deadline,
                    time.monotonic() + max(0, checkpoint['deadline_at'] - time.time()))
        record = {'run_id': run_id, 'status': 'queued', 'request': request.model_dump(mode='json'),
                  'request_fields': sorted(request.model_fields_set),
                  'checkpoint': checkpoint or {}, 'call_id': context.call_id,
                  'identity': {'tenant': identity.tenant, 'principal': identity.principal, 'role': identity.role}}
        self.store.create_run(identity.tenant, run_id, record)
        context.on_reservation = lambda: self.store.update_run(identity.tenant,run_id,{'checkpoint':self._checkpoint(context)})
        self.contexts[run_id] = context
        self.notifications[run_id] = asyncio.Event()
        self._emit(identity, run_id, 'run.created', {'call_id': context.call_id})
        self.tasks[run_id] = asyncio.create_task(self._work(identity, run_id, request, context))
        self.tasks[run_id].add_done_callback(lambda task: self._prune_tasks())
        return record

    def _prune_tasks(self):
        for key,task in list(self.tasks.items()):
            if len(self.tasks)<=128: break
            if task.done(): self.tasks.pop(key,None)

    async def _work(self, identity, run_id, request, context):
        record = self.store.get_run(identity.tenant, run_id)
        record['status'] = 'running'
        self.store.update_run(identity.tenant, run_id, record)
        self._emit(identity,run_id,'run.started',{'call_id':context.call_id})
        terminal, detail = 'failed', {'code': 'stream_incomplete'}
        try:
            iterator = self.gateway.stream(request.model_copy(update={'stream': True}), context)
            async with aclosing(iterator):
                async for event in iterator:
                    self._emit(identity, run_id, event.type, {**event.data, 'call_id': event.call_id or context.call_id,
                                                           'stream_id': event.stream_id, 'model_seq': event.seq})
                    record['checkpoint'] = self._checkpoint(context)
                    self.store.update_run(identity.tenant, run_id, record)
                    if event.type == 'completed':
                        terminal, detail = 'completed', {'call_id': context.call_id}
                        break
                    if event.type in {'failed', 'cancelled'}:
                        terminal, detail = event.type, event.data
                        break
        except asyncio.CancelledError:
            terminal, detail = 'cancelled', {'code': 'cancelled', 'call_id': context.call_id}
        except GatewayError as error:
            terminal, detail = 'failed', {'code': error.code, 'message': error.message}
        except Exception:
            terminal, detail = 'failed', {'code': 'worker_failed', 'message': 'Run 执行失败'}
        finally:
            record['status'] = terminal
            record['checkpoint'] = self._checkpoint(context)
            self.store.update_run(identity.tenant, run_id, record)
            self._emit(identity, run_id, 'run.' + terminal, detail)
            self.contexts.pop(run_id, None)
            self.notifications.pop(run_id,None)

    @staticmethod
    def _checkpoint(context):
        return {'position': 'model_boundary', 'snapshots': context.snapshots,
                'budget': asdict(context.budget),
                'deadline_at': time.time() + max(0, context.budget.remaining()),
                'side_effects': 'none'}

    async def cancel(self, identity, run_id):
        record = self.get(identity, run_id)
        if record['status'] in TERMINAL: return record
        context = self.contexts.get(run_id)
        task = self.tasks.get(run_id)
        if task:
            # Give a queued coroutine a chance to install its cancellation handler.
            await asyncio.sleep(0)
            call = self.store.get_call(identity.tenant, record.get('call_id'))
            if call and call.get('status') in TERMINAL:
                # Gateway's committed result wins; let the worker archive its queue.
                await asyncio.shield(task)
                return self.store.get_run(identity.tenant, run_id)
            if context: context.cancel.set()
            self.store.update_run(identity.tenant,run_id,{'status':'cancelling'})
            task.cancel()
            with suppress(asyncio.CancelledError): await task
        return self.store.get_run(identity.tenant, run_id)

    async def resume(self, identity, run_id):
        record = self.get(identity, run_id)
        if record['status'] not in {'failed', 'cancelled'}:
            raise GatewayError('run_not_resumable', '只有已中断的 Run 可以恢复', 409)
        checkpoint = record.get('checkpoint', {})
        if checkpoint.get('side_effects', 'none') != 'none':
            raise GatewayError('side_effect_review_required', '恢复前必须核对副作用', 409)
        # A new execution has its own Run/Call IDs. Existing event history stays immutable.
        request = ModelRequest.model_validate(record['request'])
        if 'request_fields' in record:
            request.__pydantic_fields_set__ = set(record['request_fields'])
        return await self.create(identity, request, checkpoint=checkpoint)

    async def events(self, identity, run_id, after=-1):
        self.get(identity, run_id)
        while True:
            signal = self.notifications.setdefault(run_id, asyncio.Event())
            signal.clear()
            for event in self.store.events(identity.tenant, run_id, after=after):
                after = event['seq']
                yield event
            record = self.store.get_run(identity.tenant, run_id)
            if record['status'] in TERMINAL:
                # The consumer may have yielded while the worker appended its terminal.
                for event in self.store.events(identity.tenant,run_id,after=after):
                    after=event['seq']
                    yield event
                self.notifications.pop(run_id,None)
                return
            try:
                await asyncio.wait_for(signal.wait(), timeout=15)
            except TimeoutError:
                yield {'type': 'heartbeat', 'run_id': run_id}

    async def close(self):
        for run_id, context in list(self.contexts.items()):
            await self.cancel(context.identity, run_id)
