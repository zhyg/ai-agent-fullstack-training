from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import time
from contextlib import asynccontextmanager
from dataclasses import asdict

from .upstream import AdapterRegistry
from ..config import Settings
from ..schemas import Budget, CallContext, GatewayError, Identity, Message, ModelEvent, ModelRequest, ModelResult, Usage, new_id
from ..core.rate_limit import Governance
from .prompts import PromptService
from .router import Router, cost, estimate_input
from .usage import Store
from .streaming import IncrementalJSON
from .structured import checked_schema, validate_output


def dump_result(result):
    data = asdict(result)
    data["usage"] = result.usage.model_dump()
    return data


def load_result(value):
    value = dict(value)
    value["usage"] = Usage.model_validate(value.get("usage", {}))
    return ModelResult(**value)


class _StreamCheckpoint:
    """Persists the text produced so far, so a dropped client can recover it.

    Off by default. Writes are throttled to ``flush_interval_seconds``; the final
    write always happens so the last state (completed/failed/cancelled) is durable.
    """

    def __init__(self, config, store, context, stream_id):
        self.config = config
        self.store = store
        self.context = context
        self.stream_id = stream_id
        self._last = 0.0

    @property
    def enabled(self):
        return bool(self.config.enabled)

    def write(self, text, status, finish_reason=None, force=False):
        if not self.enabled:
            return
        now = time.monotonic()
        if not force and self.config.flush_interval_seconds and now - self._last < self.config.flush_interval_seconds:
            return
        kept = text[:self.config.max_chars]
        self.store.save_stream_checkpoint(self.context.identity.tenant, self.context.call_id, {
            "request_id": self.context.call_id, "stream_id": self.stream_id, "status": status,
            "text": kept, "chars": len(kept), "truncated": len(kept) < len(text),
            "finish_reason": finish_reason, "updated_at": time.time()})
        self._last = now


class Gateway:
    def __init__(self, settings: Settings, adapters=None, store=None, sleep=asyncio.sleep):
        self.settings = settings
        self.adapters = adapters if adapters is not None else AdapterRegistry(settings)
        self.store = store if store is not None else Store(settings.database)
        self.prompts = PromptService(self.store)
        self.router = Router(settings)
        self.governance = Governance(settings)
        self.sleep = sleep
        self._locks = {}
        self._lock_users = {}

    def make_context(self, identity=None, run_id=None, step_id=None):
        return CallContext(identity=identity or Identity(), run_id=run_id, step_id=step_id,
                           budget=Budget(deadline=time.monotonic()+self.settings.deadline,
                                         max_attempts=self.settings.max_attempts,
                                         max_tokens=self.settings.token_budget,
                                         max_cost=self.settings.cost_budget))

    async def close(self):
        if hasattr(self.adapters, "close"):
            await self.adapters.close()
        self.store.close()

    def _live(self, context):
        if context.cancel.is_set():
            raise asyncio.CancelledError()
        if context.budget.remaining() <= 0:
            raise GatewayError("deadline_exceeded", "调用总时间预算已耗尽", 504, stage="budget")

    def _prepare(self, request, context):
        self._live(context)
        request = self.prompts.prepare(request, context)
        names = set()
        for tool in request.tools:
            function = tool.get("function")
            if (tool.get("type") != "function" or set(tool)-{"type", "function"}
                    or not isinstance(function, dict)
                    or set(function)-{"name", "description", "parameters", "strict"}
                    or not isinstance(function.get("name"), str)
                    or not function["name"].strip() or function["name"] in names
                    or not isinstance(function.get("parameters", {}), dict)):
                raise GatewayError("invalid_tools", "工具定义无效或名称重复", 400)
            names.add(function["name"])
            try:
                checked_schema(function.get("parameters", {}))
            except GatewayError as exc:
                if exc.code == "dependency_unavailable":
                    raise
                raise GatewayError("invalid_tools", "工具参数 Schema 无效", 400) from exc
        choice = request.tool_choice
        if isinstance(choice, dict):
            function = choice.get("function")
            if (set(choice) != {"type", "function"} or choice.get("type") != "function"
                    or not isinstance(function, dict) or set(function) != {"name"}
                    or function["name"] not in names):
                raise GatewayError("invalid_tools", "指定的工具未注册", 400)
        elif choice is not None and choice not in {"auto", "none", "required"}:
            raise GatewayError("invalid_tools", "tool_choice 不受支持", 400)
        if request.native_schema_required and request.output_schema is None:
            raise GatewayError("invalid_schema", "原生结构化输出需要 output_schema", 400)
        if request.output_schema is not None:
            try:
                checked_schema(request.output_schema)
            except GatewayError as exc:
                if exc.code == "dependency_unavailable":
                    raise
                raise GatewayError("invalid_schema", "输出 Schema 定义无效", 400) from exc
        return request

    def _cache_key(self, request, context):
        payload = {"request": request.model_dump(mode="json"),
                   "principal": context.identity.principal, "role": context.identity.role,
                   "prompt": context.snapshots.get("prompt"),
                   "routing": context.snapshots.get("routing")}
        return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

    def _candidates(self, request, context):
        started = time.monotonic()
        try:
            return self.router.candidates(request, context)
        finally:
            context.observations.setdefault("timings_ms", {})["routing"] = (time.monotonic()-started)*1000

    def _checked_result(self, request, result, context):
        started = time.monotonic()
        try:
            self._validate(request, result)
        except GatewayError as exc:
            context.observations.setdefault("validation_failures", []).append({"code": exc.code, "stage": exc.stage,
                                                                               "details": exc.details})
            raise
        finally:
            timings = context.observations.setdefault("timings_ms", {})
            timings["validation"] = timings.get("validation", 0)+(time.monotonic()-started)*1000

    def _finish(self, context, started, status, result=None, error=None, cache_hit=False):
        attempts = self.store.attempts(context.identity.tenant, context.call_id)
        costs = [a.get("cost_usd") for a in attempts]
        usage = {}
        known_usage = {}
        for field in Usage.model_fields:
            values = [a.get("usage", {}).get(field) for a in attempts]
            known_usage[field] = sum(v for v in values if v is not None)
            usage[field] = sum(values) if values and all(v is not None for v in values) else None
        complete = all(usage[k] is not None for k in ("input_tokens", "output_tokens"))
        any_known = any(a.get("usage", {}).get(k) is not None for a in attempts
                        for k in ("input_tokens", "output_tokens"))
        prompt = context.snapshots.get("prompt", {})
        record = {
            "call_id": context.call_id, "trace_id": context.trace_id,
            "run_id": context.run_id, "step_id": context.step_id,
            "principal": context.identity.principal, "status": status,
            "latency_ms": (time.monotonic()-started)*1000,
            "attempts": len(attempts), "cache_hit": cache_hit,
            "timings_ms": context.observations.get("timings_ms", {}),
            "validation_failures": context.observations.get("validation_failures", []),
            "retry_count": sum(a.get("retry_index", 0)>0 for a in attempts),
            "fallback_count": len({a.get("target") for a in attempts})-1 if attempts else 0,
            "repair_count": context.observations.get("repair_index", 0),
            "budget": {"attempts": context.budget.attempts, "max_attempts": context.budget.max_attempts,
                       "reserved_tokens": context.budget.reserved_tokens,
                       "remaining_seconds": max(0, context.budget.remaining())},
            "usage": usage, "known_usage": known_usage,
            "usage_status": "known" if complete else "partial" if any_known else "unknown",
            "cost_usd": sum(costs) if costs and all(c is not None for c in costs) else None,
            "cost_status": "estimated" if costs and all(c is not None for c in costs) else "unknown",
            "route": context.snapshots.get("last_route", {}),
            "prompt": {k: prompt.get(k) for k in ("id", "version", "hash", "schema_version", "tools_version")},
            "error_code": error.code if error else None}
        if result:
            record.update({"requested_model": result.requested_model, "resolved_model": result.resolved_model,
                           "provider": result.provider, "result_usage": result.usage.model_dump(),
                           "finish_reason": result.finish_reason, "degraded": result.degraded})
        if self.store.finish_call(context.identity.tenant, context.call_id, record):
            logging.getLogger("llm_gateway").info("%s", json.dumps({
                "event": "call.finished", "tenant": context.identity.tenant,
                "call_id": context.call_id, "trace_id": context.trace_id, "run_id": context.run_id,
                "status": status, "attempts": len(attempts), "error_code": record["error_code"]}))

    def _attempt_record(self, context, target, started, status, usage=None, error=None,
                        provider_request_id=None, first_delta=None):
        usage = usage or Usage()
        self.store.add_attempt(context.identity.tenant, context.call_id, {
            "attempt_id": new_id("attempt"), "provider": target.provider,
            "retry_index": context.observations.get("retry_index", 0),
            "repair_index": context.observations.get("repair_index", 0),
            "resolved_model": target.model, "target": target.id, "status": status,
            "latency_ms": (time.monotonic()-started)*1000,
            "ttft_ms": first_delta*1000 if first_delta is not None else None,
            "usage": usage.model_dump(), "cost_usd": cost(usage, target.price),
            "price_version": target.price.version, "cost_status": "estimated" if cost(usage,target.price) is not None else "unknown",
            "provider_request_id": provider_request_id,
            "error_code": error.code if error else None, "stage": error.stage if error else None})

    def _reserve(self, request, target, context):
        self._live(context)
        tokens = estimate_input(request)
        estimate = cost(Usage(input_tokens=tokens, output_tokens=request.max_output_tokens), target.price)
        context.budget.reserve(tokens+request.max_output_tokens, estimate)
        if context.on_reservation is not None:
            context.on_reservation()

    async def _wait(self, number, context):
        delay = min(5.0, self.settings.backoff * 2**number)
        delay += random.uniform(0, delay/4)
        self._live(context)
        if delay >= context.budget.remaining():
            raise GatewayError("deadline_exceeded", "剩余时间不足以继续退避", 504, stage="budget")
        await self.sleep(delay)
        self._live(context)

    async def _call(self, request, context, candidates):
        last = None
        for target in candidates:
            for retry in range(target.retries+1):
                context.observations["retry_index"] = retry
                self._reserve(request, target, context)
                started = time.monotonic()
                result = None
                status, error = "failed", None
                try:
                    async with self.governance.provider(target, context):
                        async with asyncio.timeout(min(target.timeout, context.budget.remaining())):
                            result = await self.adapters.complete(target, request)
                    self._live(context)
                    result.requested_model, result.resolved_model = request.requested_model, target.model
                    result.provider, result.call_id = target.provider, context.call_id
                    if result.finish_reason in {"length", "max_output_tokens"}:
                        raise GatewayError("output_truncated", "模型输出被截断", 422, stage="validation")
                    status = "completed"
                    self.router.success(target)
                    return result
                except TimeoutError:
                    error = GatewayError("timeout", "上游调用超时", 504, True, "upstream")
                except GatewayError as exc:
                    error = exc
                except asyncio.CancelledError:
                    status = "cancelled"
                    raise
                finally:
                    self._attempt_record(context, target, started, status,
                                         result.usage if result else None, error,
                                         result.provider_request_id if result else None)
                self.router.failure(target, error)
                if not error.retryable:
                    raise error
                last = error
                if retry < target.retries:
                    await self._wait(retry, context)
        raise last or GatewayError("upstream_unavailable", "候选端点已耗尽", 503, stage="route")

    def _validate(self, request, result):
        if not (result.text or result.refusal or result.tool_calls):
            raise GatewayError("upstream_empty_response", "上游未返回有效输出", 502, stage="upstream")
        if result.refusal or result.kind == "refusal":
            result.kind = "refusal"
            return
        if request.output_schema is not None or request.business_schema:
            result.data = validate_output(result.text or "", request.output_schema, request.business_schema)
            result.kind = "structured"
        if result.tool_calls:
            functions = {t.get("function", {}).get("name"): t.get("function", {})
                         for t in request.tools}
            for call in result.tool_calls:
                function = call.get("function", {})
                name = function.get("name")
                if name not in functions:
                    raise GatewayError("schema_validation_failed", "模型提出未注册工具", 422, stage="validation")
                try:
                    validate_output(function.get("arguments", ""), functions[name].get("parameters", {}))
                except (ValueError, TypeError, RecursionError) as exc:
                    raise GatewayError("schema_validation_failed", "工具参数未通过本地校验", 422, stage="validation") from exc
            result.kind = "tool_calls"

    @staticmethod
    def _cacheable(request, result):
        return (request.read_only_cache and not request.tools and not result.tool_calls
                and not result.refusal and (result.kind == "text" or
                    isinstance(result.data, dict) and result.data.get("action") == "finish"))

    @asynccontextmanager
    async def _idempotent_lock(self, key):
        lock = self._locks.setdefault(key, asyncio.Lock())
        self._lock_users[key] = self._lock_users.get(key, 0)+1
        try:
            async with lock:
                yield
        finally:
            self._lock_users[key] -= 1
            if not self._lock_users[key]:
                self._lock_users.pop(key)
                self._locks.pop(key)

    async def complete(self, request: ModelRequest, context: CallContext | None = None):
        context = context or self.make_context()
        started = time.monotonic()
        operation = asyncio.create_task(self._complete_dispatch(request, context))
        signal = asyncio.create_task(context.cancel.wait())
        try:
            done, _ = await asyncio.wait({operation, signal}, return_when=asyncio.FIRST_COMPLETED)
            if operation in done:
                return await operation
            operation.cancel()
            await asyncio.gather(operation, return_exceptions=True)
            raise asyncio.CancelledError()
        except asyncio.CancelledError:
            context.cancel.set()
            raise
        finally:
            signal.cancel()
            if not operation.done():
                operation.cancel()
            await asyncio.gather(signal, operation, return_exceptions=True)
            if operation.cancelled() and self.store.get_call(context.identity.tenant, context.call_id) is None:
                self._finish(context, started, "cancelled")

    async def _complete_dispatch(self, request: ModelRequest, context: CallContext | None = None):
        context = context or self.make_context()
        key = getattr(context, "idempotency_key", None)
        if not key:
            return await self._complete(request, context)
        fingerprint = hashlib.sha256(request.model_dump_json().encode()).hexdigest()
        identity = context.identity
        cache_key = "idempotency:" + hashlib.sha256(
            f"{identity.principal}:{identity.role}:{key}".encode()).hexdigest()
        started = time.monotonic()
        try:
            async with asyncio.timeout(max(0, context.budget.remaining())):
                async with self._idempotent_lock((identity.tenant, cache_key)):
                    previous = self.store.cache_get(identity.tenant, cache_key)
                    if previous:
                        if previous["fingerprint"] != fingerprint:
                            raise GatewayError("idempotency_conflict", "同一幂等键对应不同请求", 409)
                        result = load_result(previous["result"])
                        result.call_id = context.call_id
                        self._finish(context, started, "completed", result, cache_hit=True)
                        return result
                    result = await self._complete(request, context)
                    self.store.cache_put(identity.tenant, cache_key,
                                         {"fingerprint": fingerprint, "result": dump_result(result)}, 3600)
                    return result
        except TimeoutError as exc:
            error = GatewayError("deadline_exceeded", "幂等请求等待超时", 504, stage="budget")
            self._finish(context, started, "failed", error=error)
            raise error from exc

    async def _complete(self, request, context):
        started = time.monotonic()
        status, result, error = "failed", None, None
        cache_key = None
        cache_hit = False
        try:
            async with asyncio.timeout(max(0, context.budget.remaining())):
                async with self.governance.tenant(context):
                    request = self._prepare(request, context)
                    candidates = self._candidates(request, context)
                    cache_key = "readonly:" + self._cache_key(request, context)
                    current = request
                    for repair in range(self.settings.max_repairs+1):
                        context.observations["repair_index"] = repair
                        result = await self._call(current, context, candidates)
                        try:
                            self._checked_result(request, result, context)
                            break
                        except GatewayError as exc:
                            if repair >= self.settings.max_repairs:
                                raise
                            feedback = Message(role="user", content=
                                               "输出未通过本地校验，请修正字段或工具参数并严格遵循原输出协议。错误："+
                                               json.dumps({"code":exc.code,"details":exc.details},ensure_ascii=False))
                            current = current.model_copy(update={"messages": current.messages+
                                [Message(role="assistant", content=result.text, tool_calls=result.tool_calls), feedback]})
                    self._live(context)
                    if self._cacheable(request, result):
                        self.store.cache_put(context.identity.tenant, cache_key,
                                             dump_result(result), self.settings.cache_ttl)
                    status = "completed"
                    return result
        except asyncio.CancelledError:
            status = "cancelled"
            raise
        except TimeoutError as exc:
            error = GatewayError("deadline_exceeded", "调用总时间预算已耗尽", 504, stage="budget")
            raise error from exc
        except GatewayError as exc:
            error = exc
            if (cache_key and request.read_only_cache and not request.tools
                    and exc.code in {"schema_validation_failed","network","timeout","upstream_unavailable","rate_limited",
                                     "upstream_network_error","upstream_timeout","upstream_rate_limited"}
                    and context.budget.remaining() > 0 and not context.cancel.is_set()):
                cached = self.store.cache_get(context.identity.tenant, cache_key)
                if cached:
                    result = load_result(cached)
                    if self._cacheable(request, result):
                        self._validate(request, result)
                        result.degraded, result.call_id = True, context.call_id
                        status, cache_hit = "completed", True
                        return result
            raise
        finally:
            self._finish(context, started, status, result, error, cache_hit)

    async def stream(self, request: ModelRequest, context: CallContext | None = None):
        """A bounded producer owns timeout/cancellation; never timebox a consumer yield."""
        context = context or self.make_context()
        queue = asyncio.Queue(maxsize=16)
        stream_id = new_id("stream")
        sequence = 0
        def position(event):
            nonlocal sequence
            event.call_id, event.stream_id, event.seq = context.call_id, stream_id, sequence
            sequence += 1
            return event
        terminal = {}
        producer = asyncio.create_task(self._produce_stream(request, context, queue, terminal, stream_id))
        async def stop():
            await context.cancel.wait()
            if not producer.done():
                producer.cancel()
        stopper = asyncio.create_task(stop())
        getter = None
        try:
            while True:
                while not queue.empty():
                    yield position(queue.get_nowait())
                if producer.done():
                    break
                getter = asyncio.create_task(queue.get())
                done, _ = await asyncio.wait({getter, producer}, return_when=asyncio.FIRST_COMPLETED)
                if getter in done:
                    yield position(getter.result())
                else:
                    getter.cancel()
                    await asyncio.gather(getter, return_exceptions=True)
                getter = None
            await producer
            if terminal.get("event") is not None:
                yield position(terminal["event"])
        finally:
            stopper.cancel()
            if getter is not None:
                getter.cancel()
            if not producer.done():
                producer.cancel()
            await asyncio.gather(producer, stopper, *([getter] if getter else []), return_exceptions=True)

    async def _produce_stream(self, request, context, queue, terminal, stream_id=None):
        context = context or self.make_context()
        started = time.monotonic()
        status, error, final_result = "cancelled", None, None
        committed = False
        checkpoint = _StreamCheckpoint(self.settings.stream_checkpoint, self.store, context, stream_id)
        collected, last_finish = None, None
        try:
            async with asyncio.timeout(max(0, context.budget.remaining())):
                async with self.governance.tenant(context):
                    request = self._prepare(request, context)
                    candidates = self._candidates(request, context)
                    last = None
                    for target in candidates:
                        for retry in range(target.retries+1):
                            context.observations["retry_index"] = retry
                            self._reserve(request, target, context)
                            attempt_started = time.monotonic()
                            usage, text, calls, refusal = Usage(), [], {}, []
                            collected = text
                            finished, finish_reason, response_id, provider_id = False, None, None, None
                            attempt_status, attempt_error, first_delta = "cancelled", None, None
                            parser = IncrementalJSON() if request.output_schema is not None else None
                            try:
                                async with self.governance.provider(target, context):
                                    async with asyncio.timeout(min(target.timeout, context.budget.remaining())):
                                        iterator = self.adapters.stream(target, request)
                                        try:
                                            async for event in iterator:
                                                self._live(context)
                                                if event.type == "text.delta":
                                                    delta = event.data.get("delta", "")
                                                    text.append(delta)
                                                    if parser:
                                                        parser.feed(delta)
                                                    if delta:
                                                        committed = True
                                                        checkpoint.write("".join(text), "streaming")
                                                        if first_delta is None:
                                                            first_delta = time.monotonic()-started
                                                elif event.type == "tool.delta":
                                                    committed = True
                                                    d = event.data
                                                    item = calls.setdefault(d.get("index", 0), {
                                                        "id": "", "type": "function",
                                                        "function": {"name": "", "arguments": ""}})
                                                    if d.get("id"):
                                                        item["id"] = d["id"]
                                                    if d.get("name"):
                                                        item["function"]["name"] = d["name"]
                                                    item["function"]["arguments"] += d.get("arguments", "")
                                                elif event.type == "refusal.delta":
                                                    committed = True
                                                    refusal.append(event.data.get("delta", ""))
                                                elif event.type == "model.usage":
                                                    usage = Usage.model_validate(event.data)
                                                elif event.type == "model.finished":
                                                    finished = True
                                                    finish_reason = event.data.get("finish_reason")
                                                    last_finish = finish_reason
                                                    response_id = event.data.get("response_id")
                                                    provider_id = event.data.get("provider_request_id")
                                                await queue.put(event)
                                        finally:
                                            if hasattr(iterator, "aclose"):
                                                await iterator.aclose()
                                if not finished:
                                    raise GatewayError("stream_incomplete", "上游流缺少明确结束状态", 502, True, "upstream")
                                if finish_reason in {"length","max_output_tokens"}:
                                    raise GatewayError("output_truncated", "模型输出被截断", 422, stage="validation")
                                final_result = ModelResult(
                                    text="".join(text), tool_calls=list(calls.values()),
                                    refusal="".join(refusal) or None, usage=usage,
                                    finish_reason=finish_reason, response_id=response_id or new_id("response"),
                                    requested_model=request.requested_model, resolved_model=target.model,
                                    provider=target.provider, provider_request_id=provider_id, call_id=context.call_id)
                                self._checked_result(request, final_result, context)
                                self._live(context)
                                attempt_status = status = "completed"
                                self.router.success(target)
                            except TimeoutError:
                                attempt_error = GatewayError("timeout", "上游流读取超时", 504, True, "upstream")
                            except GatewayError as exc:
                                attempt_error = exc
                            finally:
                                if attempt_error:
                                    attempt_status = "failed"
                                self._attempt_record(context,target,attempt_started,attempt_status,usage,
                                                     attempt_error,provider_id,first_delta)
                            if attempt_error is None:
                                terminal["event"] = ModelEvent("completed", dump_result(final_result))
                                return
                            self.router.failure(target, attempt_error)
                            if committed or not attempt_error.retryable:
                                raise attempt_error
                            last = attempt_error
                            if retry < target.retries:
                                await self._wait(retry, context)
                    raise last or GatewayError("upstream_unavailable", "候选端点已耗尽", 503, stage="route")
        except (asyncio.CancelledError, GeneratorExit):
            status = "cancelled"
            context.cancel.set()
            raise
        except TimeoutError:
            status = "failed"
            error = GatewayError("deadline_exceeded", "流式调用总时间预算已耗尽", 504, stage="budget")
            terminal["event"] = ModelEvent("failed", {"code": error.code, "message": error.message,
                                      "retryable": False, "stage": error.stage, "call_id": context.call_id})
        except GatewayError as exc:
            status, error = "failed", exc
            terminal["event"] = ModelEvent("failed", {"code": exc.code, "message": exc.message,
                                      "retryable": False, "stage": exc.stage, "call_id": context.call_id})
        finally:
            if collected is not None:
                checkpoint.write("".join(collected), status, last_finish, force=True)
            self._finish(context, started, status, final_result, error)
