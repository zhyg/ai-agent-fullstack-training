"""Wire SSE framing, independent from model and harness event semantics."""
from __future__ import annotations

import codecs
import json


def encode_event(event_type, data, event_id=None) -> str:
    event_type = str(event_type)
    if any(c in event_type for c in '\r\n'):
        raise ValueError('Invalid SSE event type')
    lines = [f'event: {event_type}']
    if event_id is not None:
        event_id = str(event_id)
        if any(c in event_id for c in '\r\n\x00'):
            raise ValueError('Invalid SSE event id')
        lines.append(f'id: {event_id}')
    lines.append('data: ' + json.dumps(data, ensure_ascii=False, separators=(',', ':')))
    return '\n'.join(lines) + '\n\n'


def heartbeat() -> str:
    return ': heartbeat\n\n'


class SSEParser:
    def __init__(self, max_event_bytes=1_048_576):
        if max_event_bytes < 1:
            raise ValueError('Invalid SSE buffer limit')
        self._max_event_bytes = max_event_bytes
        self._pending_bytes = 0
        self._decoder = codecs.getincrementaldecoder('utf-8-sig')()
        self._line = ''
        self._skip_lf = False
        self._data = []
        self._event = ''
        self._id = None
        self._retry = None
        self._closed = False

    def _consume(self, line):
        if not line:
            self._pending_bytes = 0
            event = None
            if self._data:
                event = {'event': self._event or 'message', 'data': '\n'.join(self._data),
                         'id': self._id, 'retry': self._retry}
            self._data, self._event = [], ''
            return event
        if line.startswith(':'):
            return None
        field, sep, value = line.partition(':')
        if value.startswith(' '):
            value = value[1:]
        if field == 'data':
            self._data.append(value)
        elif field == 'event':
            self._event = value
        elif field == 'id' and '\x00' not in value:
            self._id = value
        elif field == 'retry' and value.isascii() and value.isdigit():
            self._retry = int(value)
        return None

    def feed(self, chunk: bytes) -> list[dict]:
        if self._closed:
            raise ValueError('Parser already finished')
        result = []
        for char in self._decoder.decode(chunk):
            if self._skip_lf:
                self._skip_lf = False
                if char == '\n':
                    continue
            self._pending_bytes += len(char.encode('utf-8'))
            if self._pending_bytes > self._max_event_bytes:
                raise ValueError('SSE event exceeds buffer limit')
            if char in '\r\n':
                event = self._consume(self._line)
                self._line = ''
                self._skip_lf = char == '\r'
                if event is not None:
                    result.append(event)
            else:
                self._line += char
        return result

    def finish(self) -> list[dict]:
        if not self._closed:
            self._decoder.decode(b'', final=True)
            self._closed = True
            self._line, self._data = '', []
        return []
