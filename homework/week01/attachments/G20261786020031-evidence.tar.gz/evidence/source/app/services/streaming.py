import json
from ..schemas import GatewayError


class IncrementalJSON:
    """Incrementally checks framing; validates a completed JSON root immediately."""
    def __init__(self, max_chars=1_000_000):
        self.buffer = ""
        self.stack = []
        self.string = False
        self.escape = False
        self.started = False
        self.complete = False
        self.max_chars = max_chars

    def feed(self, delta):
        self.buffer += delta
        if len(self.buffer) > self.max_chars:
            raise GatewayError("schema_validation_failed", "结构化输出超过大小上限", 422, stage="validation")
        for ch in delta:
            if self.complete:
                if not ch.isspace():
                    raise GatewayError("schema_validation_failed", "JSON 后含额外内容", 422, stage="validation")
                continue
            if not self.started:
                if ch.isspace():
                    continue
                self.started = True
                if ch not in "{[":
                    # Scalar JSON is finalized by the full validator at end.
                    self.stack.append("scalar")
            if self.string:
                if self.escape:
                    self.escape = False
                elif ch == "\\":
                    self.escape = True
                elif ch == '"':
                    self.string = False
                continue
            if ch == '"':
                self.string = True
            elif ch in "{[":
                self.stack.append(ch)
                if len(self.stack) > 64:
                    raise GatewayError("schema_validation_failed", "JSON 嵌套过深", 422, stage="validation")
            elif ch in "}]":
                expected = "{" if ch == "}" else "["
                if not self.stack or self.stack.pop() != expected:
                    raise GatewayError("schema_validation_failed", "JSON 括号不匹配", 422, stage="validation")
                if not self.stack:
                    self.complete = True
        if self.complete:
            try:
                return json.loads(self.buffer)
            except (ValueError, RecursionError) as exc:
                raise GatewayError("schema_validation_failed", "JSON 语法无效", 422, stage="validation") from exc
        return None
