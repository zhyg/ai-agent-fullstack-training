"""Versioned prompt contracts; rendering data never changes message privileges."""
from __future__ import annotations

import copy
from typing import Any, Literal

from jinja2 import StrictUndefined, UndefinedError, nodes
from jinja2.sandbox import ImmutableSandboxedEnvironment
from pydantic import Field, StrictInt, ValidationError

from ..schemas import CallContext, GatewayError, Message, ModelRequest, StrictModel
from .usage import valid_id
from .structured import checked_schema


class PromptBundle(StrictModel):
    id: str
    system: str = Field(default='', max_length=100000)
    input_schema: dict[str, Any] = Field(default_factory=lambda: {'type':'object','additionalProperties':False})
    few_shot: list[Message] = Field(default_factory=list, max_length=100)
    output_schema: dict[str, Any] | None = None
    tools: list[dict[str, Any]] = Field(default_factory=list, max_length=100)
    tools_version: str = '1'
    schema_version: str = '1'
    policy_version: str = '1'
    default_model: str = 'default'
    generation: dict[str, Any] = Field(default_factory=dict)
    context_budget: dict[str, StrictInt] = Field(default_factory=dict)
    eval_set: list[dict[str, Any]] = Field(default_factory=list)
    eval_thresholds: dict[str, float] = Field(default_factory=dict)
    status: Literal['draft','candidate','published','retired'] = 'published'
    change_note: str = Field(default='', max_length=10000)
    version: int | None = Field(default=None, ge=1)
    hash: str | None = None


class TemplateEnvironment(ImmutableSandboxedEnvironment):
    def is_safe_attribute(self, obj, attr, value):
        return False

    def is_safe_callable(self, obj):
        return False


def environment():
    env=TemplateEnvironment(undefined=StrictUndefined, autoescape=False)
    env.globals.clear()
    env.filters.clear()
    env.tests.clear()
    return env


def template(env, source):
    tree=env.parse(source)
    forbidden=(nodes.Call,nodes.Getattr,nodes.For,nodes.Macro,nodes.Import,nodes.FromImport,
               nodes.Include,nodes.Extends,nodes.Mul,nodes.Pow,nodes.Block,nodes.Assign)
    if any(isinstance(node,forbidden) for node in tree.find_all(nodes.Node)):
        raise GatewayError('invalid_prompt_template','Prompt 模板使用了禁止的表达式',400,stage='prompt')
    return env.from_string(source)


def validate_bundle(bundle):
    try:
        parsed=PromptBundle.model_validate(bundle)
        valid_id(parsed.id)
        checked_schema(parsed.input_schema)
        if parsed.output_schema is not None:
            checked_schema(parsed.output_schema)
        allowed={'temperature','top_p','max_output_tokens','tool_choice'}
        if set(parsed.generation)-allowed:
            raise ValueError('generation keys')
        ModelRequest.model_validate({'messages':[{'role':'user','content':'validation'}],
                                    'tools':parsed.tools, **parsed.generation})
        if set(parsed.context_budget)-{'max_input_chars','max_output_tokens','context_window','safety_margin'}:
            raise ValueError('context keys')
        if any(type(v) is not int or v < 0 for v in parsed.context_budget.values()):
            raise ValueError('context values')
        if any(m.role not in {'user','assistant'} or not m.content or m.tool_calls or m.tool_call_id for m in parsed.few_shot):
            raise ValueError('few-shot must be plain user/assistant messages')
        env=environment()
        template(env,parsed.system)
        for m in parsed.few_shot:
            template(env,m.content)
        from .usage import dumps
        body = parsed.model_dump(exclude_none=True)
        dumps(body)
        return body
    except GatewayError as exc:
        if exc.code in {'invalid_identifier','dependency_unavailable'}:
            raise
        raise GatewayError('invalid_prompt_bundle','Prompt Bundle 无效',400,stage='prompt') from None
    except Exception:
        raise GatewayError('invalid_prompt_bundle','Prompt Bundle 无效',400,stage='prompt') from None


class PromptService:
    def __init__(self,store):
        self.store=store

    def prepare(self,request: ModelRequest,context: CallContext) -> ModelRequest:
        result=request.model_copy(deep=True)
        if request.prompt is None:
            return result
        ref=request.prompt
        valid_id(ref.id)
        tenant=context.identity.tenant
        # Parent Runs pass the same snapshot map. Identity and explicit version are
        # part of the key so snapshots can never authorize another tenant's bundle.
        key=f'{tenant}:{ref.id}:{ref.version or "active"}'
        snapshots=context.snapshots.setdefault('prompt_bundles',{})
        if key not in snapshots:
            snapshots[key]=copy.deepcopy(self.store.get_prompt(tenant,ref.id,ref.version))
        bundle=copy.deepcopy(snapshots[key])
        context.snapshots['prompt']=copy.deepcopy(bundle)
        validator=checked_schema(bundle['input_schema'])
        try:
            error=next(validator.iter_errors(ref.variables),None)
        except Exception:
            raise GatewayError('invalid_prompt_variables','Prompt 变量无效',400,stage='prompt') from None
        if error is not None:
            code='missing_prompt_variable' if error.validator=='required' else 'invalid_prompt_variables'
            raise GatewayError(code,'Prompt 必填变量缺失' if code=='missing_prompt_variable' else 'Prompt 变量不符合输入约束',400,stage='prompt')
        # Bound even schemas that intentionally allow unconstrained strings.
        from .usage import dumps
        try:
            variable_size = len(dumps(ref.variables))
        except (ValueError, TypeError, RecursionError):
            raise GatewayError('invalid_prompt_variables','Prompt 变量不是合法 JSON',400,stage='prompt') from None
        if variable_size>1_000_000:
            raise GatewayError('invalid_prompt_variables','Prompt 变量超过长度限制',400,stage='prompt')
        env=environment()
        def render(source):
            try:
                chunks=[]; size=0
                for chunk in template(env,source).generate(**ref.variables):
                    size+=len(chunk)
                    if size>1_000_000:
                        raise ValueError('size')
                    chunks.append(chunk)
                return ''.join(chunks)
            except UndefinedError:
                raise GatewayError('missing_prompt_variable','Prompt 必填变量缺失',400,stage='prompt') from None
            except Exception:
                raise GatewayError('invalid_prompt_template','Prompt 模板渲染失败',400,stage='prompt') from None
        messages=[]
        if bundle['system']:
            messages.append(Message(role='system',content=render(bundle['system'])))
        messages.extend(Message.model_validate({**m,'content':render(m['content'])}) for m in bundle['few_shot'])
        result.messages=messages+result.messages
        if result.requested_model=='default':
            result.requested_model=bundle['default_model']
        for field,value in bundle['generation'].items():
            if field not in request.model_fields_set:
                setattr(result,field,copy.deepcopy(value))
        for field in ('tools','output_schema'):
            if field not in request.model_fields_set and bundle.get(field) is not None:
                setattr(result,field,copy.deepcopy(bundle[field]))
        limits=bundle['context_budget']
        chars=sum(len(dumps(m.model_dump(exclude_none=True))) for m in result.messages)+len(dumps(result.tools))+len(dumps(result.output_schema))
        if ((limits.get('max_output_tokens') is not None and result.max_output_tokens>limits['max_output_tokens']) or
            (limits.get('max_input_chars') is not None and chars>limits['max_input_chars']) or
            (limits.get('context_window') is not None and chars+result.max_output_tokens+limits.get('safety_margin',128)>limits['context_window'])):
            raise GatewayError('context_limit_exceeded','Prompt 上下文或输出预留超过限制',400,stage='prompt')
        # Revalidate merged defaults and explicit parameters as one request.
        try:
            return ModelRequest.model_validate(result.model_dump())
        except ValidationError:
            raise GatewayError('invalid_prompt_parameters','Prompt 与请求参数组合无效',400,stage='prompt') from None
