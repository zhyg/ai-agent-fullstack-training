import time
from ..config import Settings, Target
from ..schemas import GatewayError, ModelRequest, CallContext


def estimate_input(request: ModelRequest) -> int:
    # Conservative byte estimate plus protocol overhead, NOT billed token count.
    import json
    body = {"messages": [m.model_dump() for m in request.messages],
            "tools": request.tools, "schema": request.output_schema}
    return len(json.dumps(body, ensure_ascii=False).encode()) + 128


class Router:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.health = {}
        self.counters = {}

    def candidates(self, request: ModelRequest, context: CallContext):
        # Secrets never enter the snapshot: it is persisted for Run resume. The key is
        # re-attached from live settings below so a rebuilt target can still authenticate.
        snapshot = context.snapshots.setdefault("routing", {
            "models": {k: v.model_dump(mode="json") for k, v in self.settings.models.items()},
            "targets": {t.id: t.model_dump(mode="json", exclude={"api_key"}) for t in self.settings.targets}})
        keys = {t.id: t.api_key for t in self.settings.targets}
        route = snapshot["models"].get(request.requested_model)
        if not route:
            raise GatewayError("unknown_model", "未知逻辑模型", 404, stage="route")
        selected, rejected = [], []
        tokens = estimate_input(request) + request.max_output_tokens
        for target_id in route["targets"]:
            t = Target.model_validate(snapshot["targets"][target_id])
            t.api_key = keys.get(t.id)
            c = t.capabilities
            reason = None
            if not t.enabled:
                reason = "disabled"
            elif request.api not in c.apis:
                reason = "api"
            elif request.stream and not c.streaming:
                reason = "streaming"
            elif request.tools and not c.tools:
                reason = "tools"
            elif (request.output_schema is not None or request.business_schema) and c.structured == "none":
                reason = "structured"
            elif request.native_schema_required and c.structured != "native_schema":
                reason = "native_schema"
            elif request.temperature is not None and not c.temperature:
                reason = "temperature"
            elif request.top_p is not None and not c.top_p:
                reason = "top_p"
            elif request.max_output_tokens > c.max_output_tokens or tokens > c.context_window:
                reason = "context_budget"
            elif self.health.get(t.id, {}).get("until", 0) > time.monotonic():
                reason = "circuit_open"
            if reason:
                rejected.append({"target": t.id, "reason": reason})
            else:
                selected.append(t)
        if selected and route["strategy"] == "weighted_round_robin":
            ring = [t.id for t in selected for _ in range(t.weight)]
            i = self.counters.get(request.requested_model, 0)
            first = ring[i % len(ring)]
            self.counters[request.requested_model] = i + 1
            selected.sort(key=lambda t: t.id != first)
        decision = {"requested_model": request.requested_model, "strategy": route["strategy"],
                    "candidates": [t.id for t in selected], "rejected": rejected,
                    "input_estimate": estimate_input(request), "estimate_method": "utf8_bytes_plus_overhead"}
        context.snapshots["last_route"] = decision
        if not selected:
            transient = any(r["reason"] == "circuit_open" for r in rejected)
            raise GatewayError("upstream_unavailable" if transient else "unsupported_capability",
                               "没有满足能力、上下文预算和健康要求的端点",
                               503 if transient else 400, transient, "route")
        return selected

    def success(self, target):
        self.health[target.id] = {"failures": 0, "until": 0}

    def failure(self, target, error):
        if not error.retryable:
            return
        state = self.health.setdefault(target.id, {"failures": 0, "until": 0})
        state["failures"] += 1
        if state["failures"] >= self.settings.circuit_threshold:
            state["until"] = time.monotonic() + self.settings.circuit_cooldown


def cost(usage, price):
    if (usage.input_tokens is None or usage.output_tokens is None
            or price.input_per_million is None or price.output_per_million is None):
        return None
    cached = min(usage.cached_tokens or 0, usage.input_tokens)
    cache_price = price.cached_per_million
    if cache_price is None:
        cache_price = price.input_per_million
    return ((usage.input_tokens - cached) * price.input_per_million
            + cached * cache_price + usage.output_tokens * price.output_per_million) / 1_000_000
