"""Strict JSON, local JSON Schema, and small course business protocols."""
from __future__ import annotations

import json
import math
import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from ..schemas import GatewayError


def validation_error(message='输出未通过结构化校验', layer='schema', path=(), rule='invalid'):
    # Never copy error messages, instance values or arbitrary user data into feedback.
    safe_path=[p if type(p) is int else p if isinstance(p,str) and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_-]{0,63}',p) else '*' for p in path]
    return GatewayError('schema_validation_failed', message, 422, False, 'validation',
                        [{'layer':layer,'path':safe_path[:16],'rule':rule}])


class BusinessModel(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)


class TaskPlan(BusinessModel):
    goal: str = Field(min_length=1, max_length=1000)
    steps: list[str] = Field(min_length=1, max_length=12)
    completion_criteria: list[str] = Field(min_length=1, max_length=20)
    requires_tools: bool

    @model_validator(mode='after')
    def nonempty(self):
        if not self.goal.strip() or any(not s.strip() or len(s)>2000 for s in self.steps+self.completion_criteria):
            raise ValueError('nonempty plan items required')
        return self


class TicketDecision(BusinessModel):
    action: Literal['route_to_team', 'ask_user']
    team: str | None = Field(default=None, min_length=1, max_length=100)
    question: str | None = Field(default=None, min_length=1, max_length=1000)

    @model_validator(mode='after')
    def conditional(self):
        if self.action == 'route_to_team':
            if not self.team or not self.team.strip() or self.question is not None:
                raise ValueError('route requires only team')
        elif not self.question or not self.question.strip() or self.team is not None:
            raise ValueError('ask requires only question')
        return self


class PatchPlan(BusinessModel):
    action: Literal['edit', 'ask_user', 'finish']
    file_path: str | None = Field(default=None, min_length=1, max_length=500)
    reason: str = Field(min_length=1, max_length=500)
    risk: Literal['low', 'medium', 'high']

    @model_validator(mode='after')
    def workspace_path(self):
        if not self.reason.strip():
            raise ValueError('reason required')
        if self.action == 'edit' and self.file_path is None:
            raise ValueError('edit requires path')
        if self.file_path is not None:
            p = self.file_path
            if (p.startswith(('/', '~')) or '\\' in p or ':' in p or
                    any(part in {'', '.', '..'} for part in p.split('/')) or
                    any(ord(c) < 32 or ord(c)==127 for c in p)):
                raise ValueError('workspace relative path required')
        return self


class AgentAction(BusinessModel):
    """Explicit mapping of the original JSON demo's tool/finish envelope."""
    action: Literal['tool', 'finish']
    tool: str | None = Field(default=None, min_length=1, max_length=100)
    arguments: dict[str, Any] | None = None
    answer: str | None = Field(default=None, min_length=1, max_length=10000)

    @model_validator(mode='after')
    def conditional(self):
        if self.action == 'tool':
            if not self.tool or not self.tool.strip() or self.arguments is None or self.answer is not None:
                raise ValueError('tool requires tool and arguments only')
        elif not self.answer or not self.answer.strip() or self.tool is not None or self.arguments is not None:
            raise ValueError('finish requires answer only')
        return self


BUSINESS_MODELS = {'task_plan': TaskPlan, 'ticket': TicketDecision, 'patch_plan': PatchPlan, 'agent_action': AgentAction}


def _schema_runtime():
    try:
        from jsonschema import validators
        from referencing import Registry
    except ImportError:
        raise GatewayError('dependency_unavailable', '服务缺少结构化校验依赖，请安装项目 requirements',
                           503, stage='config') from None
    return validators, Registry


def schema_runtime_available():
    try:
        _schema_runtime()
        return True
    except GatewayError:
        return False


def checked_schema(schema: dict):
    """Validate a finite local schema before jsonschema can retrieve references.

    Cyclic refs are rejected deliberately: model output is finite and remote schema
    retrieval is never part of the gateway's validation contract.
    """
    if not isinstance(schema, dict):
        raise validation_error('JSON Schema 无效')
    try:
        if len(json.dumps(schema, allow_nan=False)) > 500000:
            raise ValueError('size')
    except (ValueError, TypeError, RecursionError):
        raise validation_error('JSON Schema 无效或超出限制') from None
    nodes = [0]

    def walk(node, stack=(), depth=0):
        nodes[0] += 1
        if depth > 64 or nodes[0] > 20000:
            raise validation_error('JSON Schema 超出复杂度限制')
        if isinstance(node, dict):
            for key in ('$ref', '$dynamicRef', '$recursiveRef'):
                if key not in node:
                    continue
                ref = node[key]
                if not isinstance(ref,str) or not ref.startswith('#/') or ref in stack:
                    raise validation_error('JSON Schema 仅支持无环本地引用')
                target = schema
                try:
                    for part in ref[2:].split('/'):
                        token = part.replace('~1','/').replace('~0','~')
                        target = target[int(token)] if isinstance(target,list) else target[token]
                except (KeyError, IndexError, ValueError, TypeError):
                    raise validation_error('JSON Schema 引用无效') from None
                walk(target, stack+(ref,), depth+1)
            if '$schema' in node and node['$schema'] not in {
                'https://json-schema.org/draft/2020-12/schema', 'https://json-schema.org/draft/2019-09/schema',
                'http://json-schema.org/draft-07/schema#', 'http://json-schema.org/draft-06/schema#',
                'http://json-schema.org/draft-04/schema#'}:
                raise validation_error('JSON Schema 版本不支持')
            # Traverse schema-valued keywords only. const/default/examples and
            # property names are data, even when they contain "$ref" or "$schema".
            mapping_keywords = {'$defs', 'definitions', 'properties', 'patternProperties', 'dependentSchemas'}
            single_keywords = {'additionalProperties', 'additionalItems', 'contains', 'contentSchema',
                               'if', 'then', 'else', 'not', 'propertyNames', 'unevaluatedProperties', 'unevaluatedItems'}
            array_keywords = {'allOf', 'anyOf', 'oneOf', 'prefixItems'}
            for key, value in node.items():
                if key in mapping_keywords and isinstance(value, dict):
                    for child in value.values():
                        walk(child, stack, depth+1)
                elif key in single_keywords:
                    walk(value, stack, depth+1)
                elif key in array_keywords or key == 'items':
                    if isinstance(value, list):
                        for child in value:
                            walk(child, stack, depth+1)
                    else:
                        walk(value, stack, depth+1)
                elif key == 'dependencies' and isinstance(value, dict):
                    for child in value.values():
                        if isinstance(child, dict):
                            walk(child, stack, depth+1)
        elif isinstance(node,list):
            for value in node:
                walk(value,stack,depth+1)
    try:
        walk(schema)
        validators, Registry = _schema_runtime()
        validator = validators.validator_for(schema)
        validator.check_schema(schema)
        # An explicit empty registry has no retrieval hook. Even future schema
        # keywords or nested resource IDs cannot cause network/file loading.
        return validator(schema, format_checker=validator.FORMAT_CHECKER, registry=Registry())
    except GatewayError:
        raise
    except Exception:
        raise validation_error('JSON Schema 无效') from None


def _finite_float(text):
    value = float(text)
    if not math.isfinite(value):
        raise ValueError('nonfinite number')
    return value


def _pairs(pairs):
    value = {}
    for k,v in pairs:
        if k in value:
            raise ValueError('duplicate key')
        value[k]=v
    return value


def validate_output(text: str, schema: dict | None, business: str | None = None) -> Any:
    try:
        if len(text)>2_000_000:
            raise ValueError('size')
        data = json.loads(text, object_pairs_hook=_pairs, parse_float=_finite_float,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('constant')))
    except (ValueError, TypeError, RecursionError):
        raise validation_error('输出不是合法的严格 JSON',layer='json',rule='invalid_json') from None
    if schema is not None:
        validator = checked_schema(schema)
        try:
            error=next(validator.iter_errors(data), None)
            if error is not None:
                raise validation_error('输出未通过 JSON Schema 校验',path=error.absolute_path,rule=error.validator)
        except GatewayError:
            raise
        except Exception:
            raise validation_error('输出未通过 JSON Schema 校验') from None
    if business is not None:
        model = BUSINESS_MODELS.get(business)
        if model is None:
            raise validation_error('业务协议不存在')
        try:
            data = model.model_validate(data).model_dump(exclude_none=True)
        except ValidationError as exc:
            error=exc.errors(include_input=False,include_context=False)[0]
            raise validation_error('输出未通过业务组合校验',layer='business',path=error['loc'],rule=error['type']) from None
        except (ValueError, TypeError):
            raise validation_error('输出未通过业务组合校验',layer='business') from None
    return data
