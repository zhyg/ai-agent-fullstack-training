"""Provider wire translation. Retry, routing and budgets belong to Gateway.

Compatibility record: reasoning_content (Chat), reasoning output items and the
explicit Responses reasoning summary/text lifecycle events are metadata only;
this text/tool/refusal port deliberately omits them. Message/item/content
lifecycle notifications, output annotations and done snapshots are validated
where they carry output, then omitted to avoid repeating already emitted deltas.
Unknown output blocks/items or event types fail closed instead of losing output.
"""
from __future__ import annotations

import asyncio
import copy
import json

import httpx

from ..config import Settings, Target
from ..schemas import GatewayError, ModelEvent, ModelRequest, ModelResult, Usage
from .sse import SSEParser


def _error(code='upstream_invalid_response', message='上游返回格式无效', status=502, retryable=False):
    return GatewayError(code, message, status, retryable, 'upstream')


def _usage(raw):
    raw = raw or {}
    incoming = raw.get('input_tokens', raw.get('prompt_tokens'))
    outgoing = raw.get('output_tokens', raw.get('completion_tokens'))
    details = raw.get('input_tokens_details') or raw.get('prompt_tokens_details') or {}
    output_details = raw.get('output_tokens_details') or raw.get('completion_tokens_details') or {}
    return Usage(input_tokens=incoming, output_tokens=outgoing,
                 cached_tokens=details.get('cached_tokens', raw.get('prompt_cache_hit_tokens')),
                 reasoning_tokens=output_details.get('reasoning_tokens'))


def _request_body(target: Target, request: ModelRequest, streaming):
    cap = target.capabilities
    unsupported = (request.api not in cap.apis or (streaming and not cap.streaming)
                   or (request.tools and not cap.tools)
                   or (request.temperature is not None and not cap.temperature)
                   or (request.top_p is not None and not cap.top_p)
                   or request.max_output_tokens > cap.max_output_tokens
                   or (request.output_schema is not None and cap.structured == 'none')
                   or (request.native_schema_required and cap.structured != 'native_schema'))
    if unsupported:
        raise GatewayError('capability_unsupported', '目标不支持请求所需能力', 400, stage='routing')
    messages = [m.model_dump(exclude_none=True) for m in request.messages]
    for m in messages:
        if not m.get('tool_calls'):
            m.pop('tool_calls', None)
    if request.output_schema is not None and cap.structured in {'json_mode', 'prompt_only'}:
        instruction = 'Return only JSON matching this schema: ' + json.dumps(request.output_schema, ensure_ascii=False)
        messages.insert(0, {'role': 'system', 'content': instruction})
    body = dict(target.extra_body)
    body.update(model=target.model, stream=streaming)
    for key in ('temperature', 'top_p'):
        if getattr(request, key) is not None:
            body[key] = getattr(request, key)
    schema_format = None
    if request.output_schema is not None:
        if cap.structured == 'native_schema':
            schema_format = {'type': 'json_schema', 'name': 'gateway_output', 'schema': request.output_schema, 'strict': True}
        elif cap.structured == 'json_mode':
            schema_format = {'type': 'json_object'}
    if request.api == 'chat':
        body.update(messages=messages, max_tokens=request.max_output_tokens)
        if streaming and request.include_usage:
            body['stream_options'] = {'include_usage': True}
        if request.tools:
            body['tools'] = request.tools
        if request.tool_choice is not None:
            body['tool_choice'] = request.tool_choice
        if schema_format:
            if schema_format['type'] == 'json_schema':
                body['response_format'] = {'type': 'json_schema', 'json_schema': {k:v for k,v in schema_format.items() if k != 'type'}}
            else:
                body['response_format'] = schema_format
    else:
        inputs = []
        for message in messages:
            if message['role'] == 'tool':
                inputs.append({'type': 'function_call_output', 'call_id': message.get('tool_call_id'), 'output': message.get('content', '')})
                continue
            if message.get('content') is not None:
                inputs.append({'role': message['role'], 'content': message['content']})
            for tool in message.get('tool_calls', []):
                inputs.append({'type': 'function_call', 'call_id': tool['id'], **tool['function']})
        body.update(input=inputs, max_output_tokens=request.max_output_tokens)
        if request.tools:
            body['tools'] = [{'type':'function', **tool['function']} if tool.get('type') == 'function' and 'function' in tool else tool for tool in request.tools]
        if request.tool_choice is not None:
            choice = request.tool_choice
            if isinstance(choice, dict) and 'function' in choice:
                choice = {'type':'function', 'name':choice['function']['name']}
            body['tool_choice'] = choice
        if schema_format:
            body['text'] = {'format': schema_format}
    return body


def _unsupported():
    return _error('upstream_unsupported_content', '上游返回了当前协议无法表达的内容')


def _string(value, *, nonempty=False):
    if not isinstance(value, str) or (nonempty and not value):
        raise _error()
    return value


def _chat_calls(value):
    if value is None:
        return []
    if not isinstance(value, list):
        raise _error()
    for call in value:
        if not isinstance(call, dict) or call.get('type') != 'function':
            raise _error()
        _string(call.get('id'), nonempty=True)
        function = call.get('function')
        if not isinstance(function, dict):
            raise _error()
        _string(function.get('name'), nonempty=True)
        _string(function.get('arguments'))
    return value


def _content_part(part, text_type, *, allow_refusal=True):
    if not isinstance(part, dict) or not isinstance(part.get('type'), str):
        raise _error()
    kind = part['type']
    if kind == text_type:
        return _string(part.get('text')), None
    if kind == 'refusal' and allow_refusal:
        return None, _string(part.get('refusal'))
    raise _unsupported()


def _response_outputs(items):
    if not isinstance(items, list):
        raise _error()
    text, refusal, calls = [], [], []
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get('type'), str):
            raise _error()
        kind = item['type']
        if kind == 'message':
            blocks = item.get('content')
            if not isinstance(blocks, list):
                raise _error()
            for block in blocks:
                content, denial = _content_part(block, 'output_text')
                if content is not None:
                    text.append(content)
                if denial is not None:
                    refusal.append(denial)
        elif kind == 'function_call':
            calls.append({'id': _string(item.get('call_id'), nonempty=True), 'type': 'function',
                          'function': {'name': _string(item.get('name'), nonempty=True),
                                       'arguments': _string(item.get('arguments'))}})
        elif kind == 'reasoning':
            # Known reasoning metadata is outside this port's output contract.
            continue
        else:
            raise _unsupported()
    return text, refusal, calls


# These carry no new user-visible content; done events repeat earlier deltas.
_RESPONSE_METADATA = frozenset({
    'response.created', 'response.in_progress', 'response.queued',
    'response.output_text.done', 'response.refusal.done',
    'response.function_call_arguments.done', 'response.output_text.annotation.added',
    'response.reasoning_summary_part.added', 'response.reasoning_summary_part.done',
    'response.reasoning_summary_text.delta', 'response.reasoning_summary_text.done',
    'response.reasoning_text.delta', 'response.reasoning_text.done',
})


def _result(raw, api):
    if not isinstance(raw, dict) or raw.get('error'):
        raise _error()
    text, refusal, calls = [], [], []
    if api == 'chat':
        choices = raw.get('choices', [])
        if not isinstance(choices, list):
            raise _error()
        if not choices:
            raise _error('upstream_empty_response', '上游未返回候选结果')
        choice = choices[0]
        message = choice['message']
        content = message.get('content')
        if isinstance(content, str):
            text.append(content)
        elif isinstance(content, list):
            for block in content:
                value, denial = _content_part(block, 'text')
                if value is not None:
                    text.append(value)
                if denial is not None:
                    refusal.append(denial)
        elif content is not None:
            raise _error()
        if message.get('refusal') is not None:
            refusal.append(_string(message['refusal']))
        if message.get('audio') is not None or message.get('function_call') is not None:
            raise _unsupported()
        calls = _chat_calls(message.get('tool_calls'))
        finish = choice.get('finish_reason')
        if not isinstance(finish, str) or not finish:
            raise _error()
    else:
        if raw.get('status') not in {'completed', 'incomplete'}:
            raise _error('upstream_failed', '上游生成未成功完成')
        text, refusal, calls = _response_outputs(raw.get('output', []))
        reason = (raw.get('incomplete_details') or {}).get('reason')
        finish = ('length' if reason == 'max_output_tokens' else 'content_filter') if raw.get('status') == 'incomplete' else ('tool_calls' if calls else 'stop')
    if not text and not refusal and not calls:
        raise _error('upstream_empty_response', '上游未返回有效输出')
    return ModelResult(text=''.join(text) or None, refusal=''.join(refusal) or None,
                       tool_calls=calls, kind='refusal' if refusal else ('tool_calls' if calls else 'text'),
                       finish_reason=finish, usage=_usage(raw.get('usage')), response_id=raw.get('id') or '')


class AdapterRegistry:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None):
        self.settings = settings
        self.client = httpx.AsyncClient(transport=transport, follow_redirects=False, trust_env=False)

    async def close(self):
        await self.client.aclose()

    def _http_request(self, target, request, stream):
        body = _request_body(target, request, stream)
        suffix = '/responses' if request.api == 'responses' else '/chat/completions'
        headers = {'Authorization': 'Bearer ' + target.resolve_key(), **target.extra_headers}
        return self.client.build_request('POST', target.base_url.rstrip('/') + suffix,
                json=body, headers=headers, timeout=target.timeout)

    @staticmethod
    def _status(response):
        status = response.status_code
        if 200 <= status < 300:
            return
        if status in {401, 403}:
            raise _error('upstream_auth_error', '上游认证失败', 502)
        if status == 429:
            raise _error('upstream_rate_limited', '上游限流', 429, True)
        if status in {408, 504}:
            raise _error('upstream_timeout', '上游调用超时', 504, True)
        if status >= 500:
            raise _error('upstream_unavailable', '上游暂不可用', 502, True)
        raise _error('upstream_invalid_request', '上游拒绝请求', 400)

    async def complete(self, target, request):
        response = None
        try:
            response = await self.client.send(self._http_request(target, request, False))
            self._status(response)
            result = _result(response.json(), request.api)
            result.provider_request_id = response.headers.get('x-request-id')
            result.requested_model, result.resolved_model, result.provider = request.requested_model, target.model, target.provider
            return result
        except GatewayError:
            raise
        except httpx.TimeoutException:
            raise _error('upstream_timeout', '上游调用超时', 504, True) from None
        except httpx.RequestError:
            raise _error('upstream_network_error', '上游网络失败', 502, True) from None
        except (ValueError, KeyError, TypeError, AttributeError, IndexError):
            raise _error() from None
        finally:
            if response is not None:
                await response.aclose()

    async def stream(self, target, request):
        response = None
        finished, finish_reason, response_id = False, 'stop', None
        parser = SSEParser()
        try:
            response = await self.client.send(self._http_request(target, request, True), stream=True)
            self._status(response)
            stop_reading = False
            async for chunk in response.aiter_bytes():
                for event in parser.feed(chunk):
                    data = event['data']
                    if data == '[DONE]':
                        if request.api == 'chat':
                            stop_reading = True
                            break
                        continue
                    raw = json.loads(data)
                    if raw.get('error'):
                        raise _error('upstream_failed', '上游流式生成失败')
                    if request.api == 'chat':
                        response_id = raw.get('id') or response_id
                        if raw.get('usage') is not None:
                            yield ModelEvent('model.usage', _usage(raw['usage']).model_dump())
                        for choice in raw.get('choices', []):
                            if choice.get('index', 0) != 0:
                                continue
                            delta = choice.get('delta') or {}
                            if delta.get('content'):
                                yield ModelEvent('text.delta', {'delta':delta['content']})
                            if delta.get('refusal'):
                                yield ModelEvent('refusal.delta', {'delta':delta['refusal']})
                            for tool in delta.get('tool_calls', []):
                                function = tool.get('function') or {}
                                yield ModelEvent('tool.delta', {'index':tool.get('index',0), 'id':tool.get('id'),
                                                  'name':function.get('name'), 'arguments':function.get('arguments','')})
                            if choice.get('finish_reason'):
                                finished, finish_reason = True, choice['finish_reason']
                    else:
                        kind = raw.get('type') or event['event']
                        if kind == 'response.output_text.delta':
                            if raw.get('delta'):
                                yield ModelEvent('text.delta', {'delta':_string(raw['delta'])})
                        elif kind == 'response.refusal.delta':
                            if raw.get('delta'):
                                yield ModelEvent('refusal.delta', {'delta':_string(raw['delta'])})
                        elif kind in {'response.output_item.added', 'response.output_item.done'}:
                            item = raw.get('item')
                            _, _, item_calls = _response_outputs([item])
                            if kind == 'response.output_item.added' and item_calls:
                                finish_reason = 'tool_calls'
                                call = item_calls[0]
                                yield ModelEvent('tool.delta', {'index':raw.get('output_index',0), 'id':call['id'],
                                                  **call['function']})
                        elif kind in {'response.content_part.added', 'response.content_part.done'}:
                            _content_part(raw.get('part'), 'output_text')
                        elif kind == 'response.function_call_arguments.delta':
                            finish_reason = 'tool_calls'
                            yield ModelEvent('tool.delta', {'index':raw.get('output_index',0), 'arguments':_string(raw.get('delta',''))})
                        elif kind in {'response.completed', 'response.incomplete'}:
                            obj = raw.get('response') or {}
                            _response_outputs(obj.get('output', []))
                            response_id = obj.get('id') or response_id
                            if obj.get('usage') is not None:
                                yield ModelEvent('model.usage', _usage(obj['usage']).model_dump())
                            if kind == 'response.incomplete':
                                reason = (obj.get('incomplete_details') or {}).get('reason')
                                finish_reason = 'length' if reason == 'max_output_tokens' else 'content_filter'
                            finished, stop_reading = True, True
                            break
                        elif kind in {'response.failed', 'error'}:
                            raise _error('upstream_failed', '上游流式生成失败')
                        elif kind in _RESPONSE_METADATA:
                            if kind in {'response.reasoning_summary_part.added', 'response.reasoning_summary_part.done'}:
                                _content_part(raw.get('part'), 'summary_text', allow_refusal=False)
                            obj = raw.get('response')
                            if obj is not None:
                                _response_outputs(obj.get('output', []))
                        else:
                            raise _unsupported()
                if stop_reading:
                    break
            parser.finish()
            if not finished:
                raise _error('upstream_stream_incomplete', '上游流意外中断', 502, True)
            yield ModelEvent('model.finished', {'finish_reason':finish_reason, 'response_id':response_id,
                                              'provider_request_id':response.headers.get('x-request-id')})
        except GatewayError:
            raise
        except httpx.TimeoutException:
            raise _error('upstream_timeout', '上游调用超时', 504, True) from None
        except httpx.RequestError:
            raise _error('upstream_network_error', '上游网络失败', 502, True) from None
        except (ValueError, KeyError, TypeError, AttributeError, IndexError):
            raise _error() from None
        finally:
            if response is not None:
                await response.aclose()


class FakeAdapter:
    def __init__(self, results=None, events=None, delay=0):
        self.results = list(results) if results is not None else [ModelResult(text='fake answer')]
        self.events = events
        self.delay = delay
        self.calls = []

    async def complete(self, target, request):
        self.calls.append((target, request.model_copy(deep=True)))
        if self.delay:
            await asyncio.sleep(self.delay)
        if not self.results:
            raise GatewayError('fake_exhausted', '离线响应已用尽', 503, stage='upstream')
        result = self.results.pop(0)
        if isinstance(result, GatewayError):
            raise result
        return copy.deepcopy(result)

    async def stream(self, target, request):
        if self.events is not None:
            self.calls.append((target, request.model_copy(deep=True)))
            for event in self.events:
                if self.delay:
                    await asyncio.sleep(self.delay)
                yield copy.deepcopy(event)
        else:
            result = await self.complete(target, request)
            if result.text:
                yield ModelEvent('text.delta', {'delta':result.text})
            for index, call in enumerate(result.tool_calls):
                yield ModelEvent('tool.delta', {'index':index, 'id':call['id'], **call['function']})
            if result.refusal:
                yield ModelEvent('refusal.delta', {'delta':result.refusal})
            yield ModelEvent('model.usage', result.usage.model_dump())
            yield ModelEvent('model.finished', {'finish_reason':result.finish_reason})

    async def close(self):
        pass
