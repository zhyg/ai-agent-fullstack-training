"""Single-process SQLite repository. No awaits occur inside short locked transactions."""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import re
import sqlite3
import threading
import time
from pathlib import Path

from ..schemas import GatewayError


def valid_id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', value):
        raise GatewayError('invalid_identifier', '标识符格式无效', 400)
    return value


def dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


class Store:
    def __init__(self, path: str):
        if path != ':memory:':
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False, timeout=10)
        self._db.row_factory = sqlite3.Row
        with self._db:
            self._db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS calls(tenant TEXT, id TEXT, body TEXT NOT NULL, created REAL, PRIMARY KEY(tenant,id));
            CREATE TABLE IF NOT EXISTS attempts(n INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT, call_id TEXT, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS prompts(tenant TEXT,id TEXT,version INTEGER,body TEXT NOT NULL,active INTEGER NOT NULL,PRIMARY KEY(tenant,id,version));
            CREATE UNIQUE INDEX IF NOT EXISTS prompt_active ON prompts(tenant,id) WHERE active=1;
            CREATE TABLE IF NOT EXISTS cache(tenant TEXT,key TEXT,body TEXT NOT NULL,expires REAL,PRIMARY KEY(tenant,key));
            CREATE TABLE IF NOT EXISTS runs(tenant TEXT,id TEXT,body TEXT NOT NULL,next_seq INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(tenant,id));
            CREATE TABLE IF NOT EXISTS events(tenant TEXT,run_id TEXT,seq INTEGER,body TEXT NOT NULL,created REAL,PRIMARY KEY(tenant,run_id,seq));
            CREATE TABLE IF NOT EXISTS stream_checkpoints(tenant TEXT,request_id TEXT,body TEXT NOT NULL,updated REAL,PRIMARY KEY(tenant,request_id));
            ''')

    @contextmanager
    def _transaction(self):
        with self._lock:
            self._db.execute('BEGIN IMMEDIATE')
            try:
                yield
                self._db.commit()
            except BaseException:
                self._db.rollback()
                raise

    def close(self):
        with self._lock:
            self._db.close()

    def add_attempt(self, tenant, call_id, record):
        with self._transaction():
            self._db.execute('INSERT INTO attempts(tenant,call_id,body) VALUES(?,?,?)', (tenant,call_id,dumps(record)))

    def finish_call(self, tenant, call_id, record):
        with self._transaction():
            return self._db.execute('INSERT OR IGNORE INTO calls VALUES(?,?,?,?)', (tenant,call_id,dumps(record),time.time())).rowcount == 1

    def list_calls(self, tenant: str | None, limit=100):
        limit = max(0, min(int(limit), 1000))
        with self._lock:
            if tenant is None:
                rows = self._db.execute('SELECT tenant,id,body FROM calls ORDER BY created DESC LIMIT ?', (limit,)).fetchall()
            else:
                rows = self._db.execute('SELECT tenant,id,body FROM calls WHERE tenant=? ORDER BY created DESC LIMIT ?', (tenant,limit)).fetchall()
        return [{**json.loads(r['body']), 'tenant': r['tenant'], 'call_id': r['id']} for r in rows]

    def get_call(self, tenant, call_id):
        with self._lock:
            r = self._db.execute('SELECT body FROM calls WHERE tenant=? AND id=?', (tenant,call_id)).fetchone()
        return json.loads(r['body']) if r else None

    def attempts(self, tenant, call_id):
        with self._lock:
            rows = self._db.execute('SELECT body FROM attempts WHERE tenant=? AND call_id=? ORDER BY n', (tenant,call_id)).fetchall()
        return [json.loads(r['body']) for r in rows]

    def save_prompt(self, tenant, bundle, activate=True):
        from .prompts import validate_bundle
        body = validate_bundle(bundle)
        prompt_id = valid_id(body['id'])
        if activate and body['status'] not in {'candidate', 'published'}:
            raise GatewayError('prompt_not_publishable', '仅候选或已发布版本可激活', 409, stage='prompt')
        # Metadata is generated here; caller cannot overwrite stored version/hash.
        for key in ('version', 'hash'):
            body.pop(key, None)
        with self._transaction():
            version = self._db.execute('SELECT COALESCE(MAX(version),0)+1 FROM prompts WHERE tenant=? AND id=?', (tenant,prompt_id)).fetchone()[0]
            body['version'] = version
            body['hash'] = hashlib.sha256(dumps(body).encode()).hexdigest()
            if activate:
                self._db.execute('UPDATE prompts SET active=0 WHERE tenant=? AND id=?', (tenant,prompt_id))
            self._db.execute('INSERT INTO prompts VALUES(?,?,?,?,?)', (tenant,prompt_id,version,dumps(body),int(activate)))
        return body

    def get_prompt(self, tenant, id, version=None):
        valid_id(id)
        if version is not None and (type(version) is not int or version < 1):
            raise GatewayError('invalid_prompt_version', 'Prompt 版本无效', 400)
        with self._lock:
            if version is None:
                row = self._db.execute('SELECT body FROM prompts WHERE tenant=? AND id=? AND active=1', (tenant,id)).fetchone()
            else:
                row = self._db.execute('SELECT body FROM prompts WHERE tenant=? AND id=? AND version=?', (tenant,id,version)).fetchone()
        if row is None:
            raise GatewayError('unknown_prompt_template', 'Prompt 模板或版本不存在', 404, stage='prompt')
        return json.loads(row['body'])

    def activate_prompt(self, tenant, id, version):
        valid_id(id)
        if type(version) is not int or version < 1:
            raise GatewayError('invalid_prompt_version', 'Prompt 版本无效', 400)
        with self._transaction():
            body = self.get_prompt(tenant, id, version)
            if body['status'] not in {'candidate', 'published'}:
                raise GatewayError('prompt_not_publishable', '仅候选或已发布版本可激活', 409, stage='prompt')
            self._db.execute('UPDATE prompts SET active=0 WHERE tenant=? AND id=?', (tenant,id))
            self._db.execute('UPDATE prompts SET active=1 WHERE tenant=? AND id=? AND version=?', (tenant,id,version))
        return body

    def retire_prompt(self, tenant, id):
        valid_id(id)
        with self._transaction():
            if not self._db.execute('SELECT 1 FROM prompts WHERE tenant=? AND id=?', (tenant,id)).fetchone():
                raise GatewayError('unknown_prompt_template', 'Prompt 模板不存在', 404, stage='prompt')
            self._db.execute('UPDATE prompts SET active=0 WHERE tenant=? AND id=?', (tenant,id))

    def list_prompts(self, tenant):
        with self._lock:
            rows = self._db.execute('SELECT body,active FROM prompts WHERE tenant=? ORDER BY id,version', (tenant,)).fetchall()
        return [{**json.loads(r['body']), 'active': bool(r['active'])} for r in rows]

    def cache_get(self, tenant, key):
        with self._lock:
            row = self._db.execute('SELECT body FROM cache WHERE tenant=? AND key=? AND expires>?', (tenant,key,time.time())).fetchone()
        return json.loads(row['body']) if row else None

    def cache_put(self, tenant, key, value, ttl):
        with self._transaction():
            self._db.execute('INSERT OR REPLACE INTO cache VALUES(?,?,?,?)', (tenant,key,dumps(value),time.time()+max(0,ttl)))

    def create_run(self, tenant, run_id, record):
        valid_id(run_id)
        with self._transaction():
            try:
                self._db.execute('INSERT INTO runs(tenant,id,body) VALUES(?,?,?)', (tenant,run_id,dumps(record)))
            except sqlite3.IntegrityError:
                raise GatewayError('run_exists', 'Run 已存在', 409) from None

    def get_run(self, tenant, run_id):
        with self._lock:
            row = self._db.execute('SELECT body FROM runs WHERE tenant=? AND id=?', (tenant,run_id)).fetchone()
        return json.loads(row['body']) if row else None

    def update_run(self, tenant, run_id, record):
        with self._transaction():
            body = self.get_run(tenant,run_id)
            if body is None:
                raise GatewayError('unknown_run', 'Run 不存在', 404)
            body.update(record)
            self._db.execute('UPDATE runs SET body=? WHERE tenant=? AND id=?', (dumps(body),tenant,run_id))

    def append_event(self, tenant, run_id, event):
        with self._transaction():
            row = self._db.execute('SELECT next_seq FROM runs WHERE tenant=? AND id=?', (tenant,run_id)).fetchone()
            if row is None:
                raise GatewayError('unknown_run', 'Run 不存在', 404)
            seq = row['next_seq']
            body = {**event, 'seq': seq, 'run_id': run_id}
            self._db.execute('INSERT INTO events VALUES(?,?,?,?,?)', (tenant,run_id,seq,dumps(body),time.time()))
            self._db.execute('UPDATE runs SET next_seq=next_seq+1 WHERE tenant=? AND id=?', (tenant,run_id))
        return body

    def events(self, tenant, run_id, after=-1):
        with self._lock:
            rows = self._db.execute('SELECT body FROM events WHERE tenant=? AND run_id=? AND seq>? ORDER BY seq', (tenant,run_id,after)).fetchall()
        return [json.loads(r['body']) for r in rows]

    def prune_events(self, retention_seconds, now=None):
        """Remove old replay events; business checkpoints and sequence counters survive."""
        with self._transaction():
            return self._db.execute('DELETE FROM events WHERE created<?', ((time.time() if now is None else now)-retention_seconds,)).rowcount

    def save_stream_checkpoint(self, tenant, request_id, record):
        """Upsert the partial text of a direct proxy stream. Tenant-scoped by primary key."""
        with self._transaction():
            self._db.execute('INSERT OR REPLACE INTO stream_checkpoints VALUES(?,?,?,?)',
                             (tenant, request_id, dumps(record), time.time()))

    def get_stream_checkpoint(self, tenant, request_id):
        with self._lock:
            row = self._db.execute('SELECT body FROM stream_checkpoints WHERE tenant=? AND request_id=?',
                                   (tenant, request_id)).fetchone()
        return json.loads(row['body']) if row else None

    def prune_stream_checkpoints(self, retention_seconds, now=None):
        with self._transaction():
            return self._db.execute('DELETE FROM stream_checkpoints WHERE updated<?',
                                    ((time.time() if now is None else now)-retention_seconds,)).rowcount
