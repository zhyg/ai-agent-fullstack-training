from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, AsyncIterator

from pydantic import BaseModel, ConfigDict, Field, model_validator
from .core.errors import GatewayError


def new_id(prefix: str) -> str:
    return prefix + "_" + uuid.uuid4().hex




class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Message(StrictModel):
    role: Literal["system", "developer", "user", "assistant", "tool"]
    content: str | None = None
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    tool_call_id: str | None = None
    name: str | None = None


class PromptRef(StrictModel):
    id: str
    version: int | None = Field(default=None, ge=1)
    variables: dict[str, Any] = Field(default_factory=dict)


class ModelRequest(StrictModel):
    requested_model: str = "default"
    messages: list[Message] = Field(min_length=1)
    api: Literal["chat", "responses"] = "chat"
    stream: bool = False
    max_output_tokens: int = Field(default=256, ge=1, le=131072)
    temperature: float | None = Field(default=None, ge=0, le=2)
    top_p: float | None = Field(default=None, gt=0, le=1)
    tools: list[dict[str, Any]] = Field(default_factory=list)
    tool_choice: str | dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    native_schema_required: bool = False
    business_schema: Literal["task_plan", "ticket", "patch_plan", "agent_action"] | None = None
    prompt: PromptRef | None = None
    include_usage: bool = True
    read_only_cache: bool = False

    @model_validator(mode="after")
    def meaningful(self):
        if not any((m.content and m.content.strip()) or m.tool_calls or m.tool_call_id
                   for m in self.messages):
            raise ValueError("消息不能为空")
        if self.tool_choice is not None and not self.tools:
            raise ValueError("tool_choice 需要 tools")
        return self


class Usage(StrictModel):
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    cached_tokens: int | None = Field(default=None, ge=0)
    reasoning_tokens: int | None = Field(default=None, ge=0)


@dataclass
class ModelResult:
    text: str | None = None
    kind: str = "text"
    data: Any = None
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    refusal: str | None = None
    finish_reason: str | None = "stop"
    usage: Usage = field(default_factory=Usage)
    response_id: str = field(default_factory=lambda: new_id("response"))
    provider_request_id: str | None = None
    requested_model: str = ""
    resolved_model: str = ""
    provider: str = ""
    degraded: bool = False
    call_id: str = ""


@dataclass
class ModelEvent:
    type: str
    data: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1
    call_id: str = ""
    stream_id: str = ""
    seq: int = -1
    timestamp: float = field(default_factory=time.time)


class ModelPort(Protocol):
    async def complete(self, request: ModelRequest, context: CallContext | None = None) -> ModelResult: ...
    def stream(self, request: ModelRequest, context: CallContext | None = None) -> AsyncIterator[ModelEvent]: ...


@dataclass(frozen=True)
class Identity:
    tenant: str = "local"
    principal: str = "local"
    role: str = "admin"


@dataclass
class Budget:
    deadline: float = field(default_factory=lambda: time.monotonic() + 60)
    max_attempts: int = 6
    attempts: int = 0
    max_tokens: int = 100000
    reserved_tokens: int = 0
    max_cost: float | None = None
    reserved_cost: float = 0.0

    def remaining(self) -> float:
        return self.deadline - time.monotonic()

    def check(self):
        if self.remaining() <= 0:
            raise GatewayError("deadline_exceeded", "调用总时间预算已耗尽", 504, stage="budget")

    def reserve(self, tokens: int, cost: float | None = None):
        self.check()
        if self.attempts >= self.max_attempts:
            raise GatewayError("attempt_budget_exceeded", "模型尝试次数已耗尽", 503, stage="budget")
        if self.reserved_tokens + tokens > self.max_tokens:
            raise GatewayError("token_budget_exceeded", "Token 预留预算不足", 429, stage="budget")
        if self.max_cost is not None and (cost is None or self.reserved_cost + cost > self.max_cost):
            raise GatewayError("cost_budget_exceeded", "费用预留预算不足或价格未知", 429, stage="budget")
        self.attempts += 1
        self.reserved_tokens += tokens
        self.reserved_cost += cost or 0


@dataclass
class CallContext:
    identity: Identity = field(default_factory=Identity)
    call_id: str = field(default_factory=lambda: new_id("call"))
    trace_id: str = field(default_factory=lambda: new_id("trace"))
    run_id: str | None = None
    step_id: str | None = None
    idempotency_key: str | None = None
    cancel: asyncio.Event = field(default_factory=asyncio.Event)
    budget: Budget = field(default_factory=Budget)
    snapshots: dict[str, Any] = field(default_factory=dict)
    observations: dict[str, Any] = field(default_factory=dict)
    on_reservation: Any = field(default=None, repr=False)

    def check(self):
        if self.cancel.is_set():
            raise asyncio.CancelledError()
        self.budget.check()
