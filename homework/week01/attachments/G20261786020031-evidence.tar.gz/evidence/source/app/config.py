from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Literal
from urllib.parse import urlsplit

from pydantic import Field, SecretStr, field_validator, model_validator
from .schemas import StrictModel, GatewayError, Identity

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?}")


def expand_env(value: Any) -> Any:
    """Expand ${VAR} / ${VAR:-default} in JSON config strings.

    Missing variable without a default becomes an empty string, matching the
    course reference. Keys are never written to logs; only resolved in memory.
    """
    if isinstance(value, str):
        def replace(match: re.Match[str]) -> str:
            name, default = match.group(1), match.group(2)
            if name in os.environ:
                return os.environ[name]
            return default if default is not None else ""
        return _ENV_PATTERN.sub(replace, value)
    if isinstance(value, list):
        return [expand_env(item) for item in value]
    if isinstance(value, dict):
        return {key: expand_env(item) for key, item in value.items()}
    return value


class Capabilities(StrictModel):
    apis: set[Literal["chat", "responses"]] = Field(default_factory=lambda: {"chat"})
    streaming: bool = True
    structured: Literal["native_schema", "json_mode", "prompt_only", "none"] = "json_mode"
    tools: bool = True
    temperature: bool = True
    top_p: bool = True
    context_window: int = Field(default=32768, ge=128)
    max_output_tokens: int = Field(default=4096, ge=1)


class Price(StrictModel):
    input_per_million: float | None = Field(default=None, ge=0)
    output_per_million: float | None = Field(default=None, ge=0)
    cached_per_million: float | None = Field(default=None, ge=0)
    version: str = "unconfigured"


class StreamCheckpointConfig(StrictModel):
    """Optional partial-output checkpoint for direct proxy streams.

    Disabled by default: storing model text is a privacy decision. When enabled,
    the text produced so far is persisted every ``flush_interval_seconds`` (0 means
    every delta) so a disconnected client can recover what it already paid for.
    """
    enabled: bool = False
    flush_interval_seconds: float = Field(default=1.0, ge=0, le=60)
    max_chars: int = Field(default=200_000, ge=1000, le=10_000_000)


class Target(StrictModel):
    id: str
    provider: str
    model: str
    base_url: str
    api_key_env: str = "DEEPSEEK_API_KEY"
    api_key: SecretStr | None = None
    capabilities: Capabilities = Field(default_factory=Capabilities)
    extra_body: dict[str, Any] = Field(default_factory=dict)
    extra_headers: dict[str, str] = Field(default_factory=dict)
    price: Price = Field(default_factory=Price)
    enabled: bool = True
    weight: int = Field(default=1, ge=1, le=100)
    retries: int = Field(default=1, ge=0, le=5)
    concurrency: int = Field(default=4, ge=1, le=100)
    timeout: float = Field(default=30, gt=0, le=300)

    @field_validator("base_url")
    @classmethod
    def base(cls, value):
        p = urlsplit(value)
        if p.scheme not in {"http", "https"} or not p.hostname or p.username or p.password or p.query or p.fragment:
            raise ValueError("上游地址必须是配置中的 HTTP(S) 基础地址")
        if p.path.rstrip("/").endswith(("/chat/completions", "/responses")):
            raise ValueError("请填写基础地址，不能填写完整生成接口")
        return value.rstrip("/")

    def has_key(self) -> bool:
        """Presence check for readiness reporting; never returns the value."""
        inline = self.api_key.get_secret_value().strip() if self.api_key is not None else ""
        return bool(inline or os.environ.get(self.api_key_env, "").strip())

    def resolve_key(self) -> str:
        inline = self.api_key.get_secret_value().strip() if self.api_key is not None else ""
        value = inline or os.environ.get(self.api_key_env, "").strip()
        if not value:
            raise GatewayError("provider_not_configured", "上游凭证未配置", 503, stage="config")
        return value


class ModelRoute(StrictModel):
    targets: list[str] = Field(min_length=1)
    strategy: Literal["priority", "weighted_round_robin"] = "priority"


class Credential(StrictModel):
    env: str = "GATEWAY_API_KEY"
    tenant: str = "local"
    principal: str = "local-admin"
    role: Literal["admin", "caller"] = "admin"

    def identity(self):
        return Identity(self.tenant, self.principal, self.role)


class Settings(StrictModel):
    database: str = "studyagent/llm_gateway/data/gateway.db"
    targets: list[Target]
    models: dict[str, ModelRoute]
    credentials: list[Credential] = Field(default_factory=lambda: [Credential()])
    deadline: float = Field(default=60, gt=0, le=600)
    max_attempts: int = Field(default=6, ge=1, le=30)
    max_repairs: int = Field(default=1, ge=0, le=3)
    backoff: float = Field(default=0.25, ge=0, le=10)
    tenant_concurrency: int = Field(default=4, ge=1)
    queue_limit: int = Field(default=16, ge=0)
    qps: float = Field(default=10, gt=0)
    burst: int = Field(default=20, ge=1)
    circuit_threshold: int = Field(default=3, ge=1)
    circuit_cooldown: float = Field(default=15, gt=0)
    token_budget: int = Field(default=100000, ge=1)
    cost_budget: float | None = Field(default=None, gt=0)
    max_body_bytes: int = Field(default=1048576, ge=1024)
    event_retention_seconds: int = Field(default=86400, ge=60)
    cache_ttl: int = Field(default=300, ge=0)
    stream_checkpoint: StreamCheckpointConfig = Field(default_factory=StreamCheckpointConfig)

    @model_validator(mode="after")
    def references(self):
        ids = [t.id for t in self.targets]
        if len(ids) != len(set(ids)):
            raise ValueError("重复的端点 ID")
        if not self.models or any(set(r.targets) - set(ids) for r in self.models.values()):
            raise ValueError("逻辑模型引用未知端点")
        return self

    @classmethod
    def from_env(cls):
        from dotenv import load_dotenv
        root = Path(__file__).resolve().parents[3]
        load_dotenv(root / "studyagent/.env", override=False)
        load_dotenv(Path(__file__).resolve().parents[1] / ".env", override=False)
        path = os.environ.get("GATEWAY_CONFIG")
        if path:
            import json
            raw = json.loads(Path(path).read_text())
            return cls.model_validate(expand_env(raw))
        target = Target(id="deepseek", provider="deepseek",
                        model=os.environ.get("DEEPSEEK_MODEL", "deepseek-chat"),
                        base_url=os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
                        extra_body={"thinking": {"type": "disabled"}})
        return cls(targets=[target], models={"default": ModelRoute(targets=["deepseek"])},
                   database=os.environ.get("GATEWAY_DATABASE", str(Path(__file__).resolve().parents[1] / "data/gateway.db")))
