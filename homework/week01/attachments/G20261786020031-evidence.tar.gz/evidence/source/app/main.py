"""Run with python -m studyagent.llm_gateway.app.main or uvicorn ...main:app."""
if __package__ in {None, ''}:
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
    from studyagent.llm_gateway.app.api.routes import create_app
else:
    from .api.routes import create_app

app = create_app()

if __name__ == '__main__':
    import os
    import uvicorn
    uvicorn.run(app, host=os.environ.get('GATEWAY_HOST','127.0.0.1'),
                port=int(os.environ.get('GATEWAY_PORT','8003')))
