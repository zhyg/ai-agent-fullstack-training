"""Responses item/content lifecycle for the supported text/function subset."""
from __future__ import annotations


class ResponseEvents:
    def __init__(self, response_id, encode):
        self.response_id, self.encode = response_id, encode
        self.sequence = 0
        self.items = []
        self.indices = {}
        self.parts = {}

    def event(self, kind, **data):
        value = self.encode(kind, {"type": kind, "sequence_number": self.sequence, **data})
        self.sequence += 1
        return value

    def start(self, model):
        return self.event("response.created", response={"id": self.response_id, "object": "response",
            "status": "in_progress", "model": model, "output": []})

    def delta(self, kind, data):
        if kind == "tool.delta":
            key = ("tool", data.get("index", 0))
            function = data.get("function", data)
            if key not in self.indices:
                index = len(self.items)
                self.indices[key] = index
                call_id = data.get("id") or f"{self.response_id}_call_{index}"
                item = {"id": "fc_"+call_id, "type": "function_call", "call_id": call_id,
                        "name": function.get("name") or "", "arguments": "", "status": "in_progress"}
                self.items.append(item)
                yield self.event("response.output_item.added", output_index=index, item=item)
            index = self.indices[key]
            item = self.items[index]
            if function.get("name"):
                item["name"] = function["name"]
            delta = function.get("arguments") or ""
            item["arguments"] += delta
            if delta:
                yield self.event("response.function_call_arguments.delta", output_index=index,
                                 item_id=item["id"], delta=delta)
            return
        key = "message"
        if key not in self.indices:
            index = len(self.items)
            self.indices[key] = index
            item = {"id": self.response_id+"_message", "type": "message", "role": "assistant",
                    "status": "in_progress", "content": []}
            self.items.append(item)
            yield self.event("response.output_item.added", output_index=index, item=item)
        index = self.indices[key]
        item = self.items[index]
        part_kind = "output_text" if kind == "text.delta" else "refusal"
        field = "text" if part_kind == "output_text" else "refusal"
        if part_kind not in self.parts:
            part = {"type": part_kind, field: ""}
            if part_kind == "output_text":
                part["annotations"] = []
            self.parts[part_kind] = len(item["content"])
            item["content"].append(part)
            yield self.event("response.content_part.added", output_index=index, item_id=item["id"],
                             content_index=self.parts[part_kind], part=part)
        content_index = self.parts[part_kind]
        delta = data.get("delta") or ""
        item["content"][content_index][field] += delta
        yield self.event("response."+part_kind+".delta", output_index=index, item_id=item["id"],
                         content_index=content_index, delta=delta, **({"logprobs": []} if field == "text" else {}))

    def finish(self):
        for index, item in enumerate(self.items):
            item["status"] = "completed"
            if item["type"] == "message":
                for content_index, part in enumerate(item["content"]):
                    field = "text" if part["type"] == "output_text" else "refusal"
                    yield self.event("response."+part["type"]+".done", output_index=index,
                                     item_id=item["id"], content_index=content_index, **{field: part[field]})
                    yield self.event("response.content_part.done", output_index=index, item_id=item["id"],
                                     content_index=content_index, part=part)
            else:
                yield self.event("response.function_call_arguments.done", output_index=index,
                                 item_id=item["id"], name=item["name"], arguments=item["arguments"])
            yield self.event("response.output_item.done", output_index=index, item=item)
