"""Strict, deliberately limited OpenAI compatibility at the HTTP boundary."""
from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import aclosing, asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import ValidationError
from starlette.exceptions import HTTPException

from ..config import Settings
from ..core.security import authenticate as authenticate_identity
from ..schemas import GatewayError, Message, ModelRequest, ModelResult, PromptRef
from ..services.runs import RunManager
from ..services.structured import schema_runtime_available
from .response_events import ResponseEvents


def sse(kind, data, event_id=None):
    prefix = f'id: {event_id}\n' if event_id is not None else ''
    if kind: prefix += f'event: {kind}\n'
    return prefix + 'data: ' + json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n\n'


def whitelist(body, allowed):
    if not isinstance(body, dict) or set(body) - set(allowed):
        raise GatewayError('unsupported_parameter', '请求包含不支持的字段', 400)


def _normalize(body, api='chat'):
    common = {'model','stream','temperature','top_p','tools','tool_choice','prompt'}
    whitelist(body, common | ({'messages','max_tokens','max_completion_tokens','response_format','stream_options'} if api == 'chat' else {'input','instructions','max_output_tokens','text'}))
    if 'stream' in body and not isinstance(body['stream'], bool):
        raise GatewayError('invalid_request', 'stream 必须为布尔值', 400)
    messages = body.get('messages')
    tools = body.get('tools', [])
    if api == 'responses':
        messages = []
        if 'instructions' in body:
            messages.append({'role':'system','content':body['instructions']})
        value = body.get('input')
        if isinstance(value, str): messages.append({'role':'user','content':value})
        elif isinstance(value, list):
            for item in value:
                if not isinstance(item, dict): raise GatewayError('unsupported_input', '不支持此输入项', 400)
                kind = item.get('type', 'message')
                if kind == 'function_call_output':
                    whitelist(item, {'type','call_id','output'})
                    messages.append({'role':'tool','content':item.get('output'),'tool_call_id':item.get('call_id')})
                elif kind == 'function_call':
                    whitelist(item, {'type','call_id','name','arguments'})
                    messages.append({'role':'assistant','tool_calls':[{'id':item.get('call_id'),'type':'function','function':{'name':item.get('name'),'arguments':item.get('arguments')}}]})
                elif kind == 'message':
                    whitelist(item, {'type','role','content'})
                    content = item.get('content')
                    if isinstance(content, list):
                        chunks = []
                        for chunk in content:
                            whitelist(chunk, {'type','text'})
                            if chunk.get('type') not in {'input_text','output_text'} or not isinstance(chunk.get('text'),str):
                                raise GatewayError('unsupported_input', '仅支持文本输入', 400)
                            chunks.append(chunk['text'])
                        content = ''.join(chunks)
                    messages.append({'role':item.get('role','user'),'content':content})
                else: raise GatewayError('unsupported_input', '不支持此输入项', 400)
        else: raise GatewayError('invalid_request', 'input 必须为文本或受支持输入项数组', 400)
        mapped_tools=[]
        for tool in tools:
            whitelist(tool, {'type','name','description','parameters','strict'})
            if tool.get('type') != 'function': raise GatewayError('unsupported_tool','仅支持 function 工具定义',400)
            mapped_tools.append({'type':'function','function':{k:v for k,v in tool.items() if k!='type'}})
        tools = mapped_tools
    else:
        if 'max_tokens' in body and 'max_completion_tokens' in body:
            raise GatewayError('invalid_request','不能同时指定两种输出上限',400)
        whitelist(body.get('stream_options', {}), {'include_usage'})
    for tool in tools:
        whitelist(tool, {'type','function'})
        if tool.get('type')!='function': raise GatewayError('unsupported_tool','仅支持 function 工具定义',400)
        whitelist(tool.get('function',{}), {'name','description','parameters','strict'})
    schema = None
    if api == 'chat' and 'response_format' in body:
        fmt=body['response_format'];whitelist(fmt, {'type','json_schema'})
        if fmt.get('type') == 'json_schema':
            spec=fmt.get('json_schema',{});whitelist(spec, {'name','description','schema','strict'})
            schema=spec.get('schema')
            if not isinstance(schema,dict): raise GatewayError('invalid_request','缺少 JSON Schema',400)
        elif fmt.get('type')!='text': raise GatewayError('unsupported_parameter','仅支持 text/json_schema 格式',400)
    if api == 'responses' and 'text' in body:
        whitelist(body['text'], {'format'})
        fmt=body['text'].get('format',{});whitelist(fmt, {'type','name','description','schema','strict'})
        if fmt.get('type')=='json_schema':
            schema=fmt.get('schema')
            if not isinstance(schema,dict): raise GatewayError('invalid_request','缺少 JSON Schema',400)
        elif fmt.get('type')!='text': raise GatewayError('unsupported_parameter','不支持此输出格式',400)
    if not isinstance(messages,list): raise GatewayError('invalid_request','messages 必须为数组',400)
    for message in messages:
        whitelist(message,{'role','content','tool_calls','tool_call_id','name'})
        for call in message.get('tool_calls',[]):
            whitelist(call,{'id','type','function'})
            function=call.get('function',{})
            whitelist(function,{'name','arguments'})
            if (call.get('type')!='function' or not isinstance(call.get('id'),str) or
                not isinstance(function.get('name'),str) or not isinstance(function.get('arguments'),str)):
                raise GatewayError('invalid_tool_call','工具调用字段无效',400)
    choice=body.get('tool_choice')
    if isinstance(choice,dict):
        if api=='responses':
            whitelist(choice,{'type','name'})
            if choice.get('type')!='function' or not isinstance(choice.get('name'),str):
                raise GatewayError('unsupported_tool_choice','不支持此工具选择',400)
            choice={'type':'function','function':{'name':choice['name']}}
        else:
            whitelist(choice,{'type','function'})
            whitelist(choice.get('function',{}),{'name'})
            if choice.get('type')!='function' or not isinstance(choice.get('function',{}).get('name'),str):
                raise GatewayError('unsupported_tool_choice','不支持此工具选择',400)
    elif choice is not None and choice not in {'auto','none','required'}:
        raise GatewayError('unsupported_tool_choice','不支持此工具选择',400)
    values={'messages':messages,'api':api}
    for source,destination in [('model','requested_model'),('stream','stream'),('temperature','temperature'),('top_p','top_p'),('tool_choice','tool_choice'),('prompt','prompt')]:
        if source in body: values[destination]=body[source]
    if 'tool_choice' in body: values['tool_choice']=choice
    if 'tools' in body: values['tools']=tools
    for key in ('max_output_tokens','max_completion_tokens','max_tokens'):
        if key in body: values['max_output_tokens']=body[key]
    if schema is not None: values['output_schema']=schema
    if 'stream_options' in body: values['include_usage']=body['stream_options'].get('include_usage',True)
    return ModelRequest(**values)


def normalize(body, api='chat'):
    try:
        return _normalize(body,api)
    except GatewayError:
        raise
    except (ValidationError,TypeError,ValueError,AttributeError,KeyError):
        raise GatewayError('invalid_request','请求字段或消息格式无效',400) from None


def usage(raw, api):
    if hasattr(raw,'model_dump'): raw=raw.model_dump()
    raw=raw or {}
    if api=='legacy': return {k:v for k,v in raw.items() if v is not None}
    if api=='responses':
        result={k:raw[k] for k in ('input_tokens','output_tokens') if raw.get(k) is not None}
        if len(result)==2: result['total_tokens']=sum(result.values())
        if raw.get('cached_tokens') is not None: result['input_tokens_details']={'cached_tokens':raw['cached_tokens']}
        if raw.get('reasoning_tokens') is not None: result['output_tokens_details']={'reasoning_tokens':raw['reasoning_tokens']}
        return result
    result={}
    for source,key in [('input_tokens','prompt_tokens'),('output_tokens','completion_tokens')]:
        if raw.get(source) is not None: result[key]=raw[source]
    if len(result)==2: result['total_tokens']=sum(result.values())
    if raw.get('cached_tokens') is not None: result['prompt_tokens_details']={'cached_tokens':raw['cached_tokens']}
    if raw.get('reasoning_tokens') is not None: result['completion_tokens_details']={'reasoning_tokens':raw['reasoning_tokens']}
    return result


def result_payload(result, api, model):
    if api=='chat':
        message={'role':'assistant','content':result.text}
        if result.tool_calls: message['tool_calls']=result.tool_calls
        if result.refusal is not None: message['refusal']=result.refusal
        return {'id':result.response_id,'object':'chat.completion','created':int(time.time()),'model':model,
                'choices':[{'index':0,'message':message,'finish_reason':result.finish_reason}], 'usage':usage(result.usage,api)}
    output=[]
    content=[]
    if result.text is not None: content.append({'type':'output_text','text':result.text,'annotations':[]})
    if result.refusal is not None: content.append({'type':'refusal','refusal':result.refusal})
    if content: output.append({'id':result.response_id+'_message','type':'message','role':'assistant','status':'completed','content':content})
    for tool in result.tool_calls:
        fn=tool.get('function',tool)
        output.append({'type':'function_call','id':tool.get('id'),'call_id':tool.get('id'),'name':fn.get('name'),'arguments':fn.get('arguments','')})
    status='incomplete' if result.finish_reason=='length' else 'completed'
    payload={'id':result.response_id,'object':'response','created_at':int(time.time()),'model':model,
             'status':status,'output':output,'usage':usage(result.usage,api),'error':None}
    if status=='incomplete': payload['incomplete_details']={'reason':'max_output_tokens'}
    return payload


async def external_stream(gateway, model_request, context, api):
    response_id='resp_'+context.call_id
    iterator=gateway.stream(model_request,context)
    responses=ResponseEvents(response_id,sse)
    completed=False
    text='';refusal='';tools={};tokens={};finish=None
    try:
        async with aclosing(iterator):
            if api=='responses':
                yield responses.start(model_request.requested_model)
            async for event in iterator:
                kind,data=event.type,event.data
                if kind in {'failed','cancelled'}:
                    raise GatewayError(data.get('code',kind), data.get('message','调用已结束'), 502, stage=data.get('stage','stream'))
                if kind=='completed':
                    completed=True
                    if api=='chat':
                        base={'id':response_id,'object':'chat.completion.chunk','created':int(time.time()),'model':model_request.requested_model}
                        yield sse(None,{**base,'choices':[{'index':0,'delta':{},'finish_reason':data.get('finish_reason',finish)}]})
                        if model_request.include_usage:
                            yield sse(None,{**base,'choices':[],'usage':usage(data.get('usage',tokens),'chat')})
                        yield 'data: [DONE]\n\n'
                    else:
                        final=ModelResult(text=data.get('text',text) or None,tool_calls=data.get('tool_calls',list(tools.values())),refusal=data.get('refusal',refusal or None),finish_reason=data.get('finish_reason',finish),response_id=response_id,usage=data.get('usage',tokens))
                        payload=result_payload(final,'responses',model_request.requested_model)
                        for frame in responses.finish(): yield frame
                        payload['output']=responses.items
                        end='response.incomplete' if payload['status']=='incomplete' else 'response.completed'
                        yield responses.event(end,response=payload)
                    break
                if kind=='text.delta': text+=data.get('delta','')
                if kind=='refusal.delta': refusal+=data.get('delta','')
                if kind=='tool.delta':
                    index=data.get('index',0);tool=tools.setdefault(index,{'id':data.get('id'),'type':'function','function':{'name':'','arguments':''}})
                    if data.get('id'): tool['id']=data['id']
                    fn=data.get('function',data)
                    if fn.get('name'): tool['function']['name']=fn['name']
                    tool['function']['arguments']+=fn.get('arguments','') or ''
                if kind=='model.usage': tokens=data
                if kind=='model.finished': finish=data.get('finish_reason')
                if api=='chat':
                    # Provider usage/finish order varies. Publish the canonical tail
                    # only after core validation produces the completed terminal.
                    if kind in {'model.usage','model.finished'}: continue
                    delta={};choices=[];extra={}
                    if kind=='text.delta': delta={'content':data.get('delta','')}
                    elif kind=='refusal.delta': delta={'refusal':data.get('delta','')}
                    elif kind=='tool.delta':
                        item={k:v for k,v in data.items() if k in {'index','id','type','function'}}
                        if 'function' not in item: item['function']={k:data[k] for k in ('name','arguments') if k in data}
                        delta={'tool_calls':[item]}
                    else: raise GatewayError('unsupported_event','不支持的上游事件',502,stage='stream')
                    choices=[{'index':0,'delta':delta,'finish_reason':None}]
                    yield sse(None,{'id':response_id,'object':'chat.completion.chunk','created':int(time.time()),'model':model_request.requested_model,'choices':choices,**extra})
                else:
                    if kind in {'text.delta','tool.delta','refusal.delta'}:
                        for frame in responses.delta(kind,data): yield frame
                    elif kind not in {'model.usage','model.finished'}: raise GatewayError('unsupported_event','不支持的上游事件',502,stage='stream')
            if not completed: raise GatewayError('stream_incomplete','上游流未提供终态',502,stage='stream')
    except (asyncio.CancelledError, GeneratorExit):
        context.cancel.set()
        raise
    except Exception as error:
        if not isinstance(error,GatewayError): error=GatewayError('stream_failed','模型流失败',502,stage='stream')
        if api=='chat': yield sse(None,error.payload(context.call_id))
        else: yield responses.event('response.failed',response={'id':response_id,'object':'response','status':'failed','error':error.payload(context.call_id)['error']})


async def legacy_events(gateway, model_request, context):
    terminal=False
    try:
        async with aclosing(gateway.stream(model_request,context)) as iterator:
            async for event in iterator:
                name={'text.delta':'content.delta','completed':'response.completed','failed':'response.failed','cancelled':'response.failed'}.get(event.type,event.type)
                yield sse(name,{'type':name,'request_id':context.call_id,**event.data})
                if event.type in {'completed','failed','cancelled'}:
                    terminal=True
                    break
            if not terminal: raise GatewayError('stream_incomplete','上游流未提供终态',502,stage='stream')
    except (asyncio.CancelledError,GeneratorExit):
        context.cancel.set()
        raise
    except Exception as error:
        if not isinstance(error,GatewayError): error=GatewayError('stream_failed','模型流失败',502,stage='stream')
        yield sse('response.failed',{'type':'response.failed','request_id':context.call_id,**error.payload(context.call_id)})


def create_app(settings=None, gateway=None):
    owned=gateway is None
    if gateway is None:
        from ..services.gateway import Gateway
        gateway=Gateway(settings or Settings.from_env())
    settings=settings or gateway.settings
    runs=RunManager(gateway)
    @asynccontextmanager
    async def lifespan(app):
        gateway.store.prune_events(settings.event_retention_seconds)
        gateway.store.prune_stream_checkpoints(settings.event_retention_seconds)
        yield
        await runs.close()
        if owned: await gateway.close()
    app=FastAPI(lifespan=lifespan)
    app.state.gateway=gateway;app.state.runs=runs

    @app.exception_handler(GatewayError)
    async def gateway_error(request,error):
        call_id=getattr(request.state,'call_id',None)
        return JSONResponse(error.payload(call_id),status_code=error.status,headers={'X-Request-ID':call_id} if call_id else {})
    @app.exception_handler(RequestValidationError)
    async def validation_error(request,error): return await gateway_error(request,GatewayError('invalid_request','请求字段无效',400))
    @app.exception_handler(HTTPException)
    async def http_error(request,error): return await gateway_error(request,GatewayError('http_error','请求资源或方法无效',error.status_code))

    @app.exception_handler(ValidationError)
    async def domain_validation_error(request,error):
        return await gateway_error(request,GatewayError('invalid_request','请求字段无效',400))
    @app.exception_handler(Exception)
    async def unexpected_error(request,error):
        return await gateway_error(request,GatewayError('internal_error','服务内部错误',500,stage='internal'))

    def authenticate(request,admin=False):
        return authenticate_identity(settings,request.headers.get('authorization',''),admin)

    async def body(request):
        # Read incrementally so an oversized body cannot allocate without a bound.
        chunks=bytearray()
        async for chunk in request.stream():
            chunks.extend(chunk)
            if len(chunks)>settings.max_body_bytes: raise GatewayError('request_too_large','请求正文过大',413)
        try:
            value=json.loads(chunks)
            if not isinstance(value,dict): raise ValueError()
            return value
        except (ValueError,UnicodeError): raise GatewayError('invalid_json','请求需要 JSON 对象',400) from None

    async def generate(request,api='chat',legacy=False,force_stream=False):
        identity=authenticate(request)
        context=gateway.make_context(identity)
        request.state.call_id=context.call_id
        value=await body(request)
        started=time.monotonic()
        if legacy:
            whitelist(value,{'model','messages','stream','response_schema','timeout_seconds','prompt'})
            value=dict(value)
            if 'response_schema' in value:
                if 'response_format' in value: raise GatewayError('invalid_request','输出约束重复',400)
                schema=value.pop('response_schema')
                if schema is not None: value['response_format']={'type':'json_schema','json_schema':{'name':'legacy','schema':schema}}
            if 'timeout_seconds' in value:
                seconds=value.pop('timeout_seconds')
                if type(seconds) not in {int,float} or not 0<seconds<=120:
                    raise GatewayError('invalid_request','timeout_seconds 无效',400)
                context.budget.deadline=min(context.budget.deadline,time.monotonic()+seconds)
            if isinstance(value.get('prompt'),dict) and 'name' in value['prompt']:
                old=value['prompt'];whitelist(old,{'name','version','variables'})
                version=old.get('version')
                if isinstance(version,str):
                    try: version=int(version.removeprefix('v'))
                    except ValueError: raise GatewayError('unknown_prompt_template','Prompt 版本不存在',404) from None
                value['prompt']={'id':old['name'],'version':version,'variables':old.get('variables',{})}
            if 'prompt' in value and isinstance(value['prompt'],str):
                if 'messages' in value: raise GatewayError('invalid_request','prompt 与 messages 冲突',400)
                value['messages']=[{'role':'user','content':value.pop('prompt')}]
        if legacy and not force_stream and value.get('stream'):
            raise GatewayError('use_stream_endpoint','流式请求请使用 /v1/llm/stream',400)
        if force_stream: value['stream']=True
        model_request=normalize(value,api)
        if hasattr(context,'idempotency_key'): context.idempotency_key=request.headers.get('Idempotency-Key')
        headers={'X-Request-ID':context.call_id}
        if model_request.stream:
            return StreamingResponse(legacy_events(gateway,model_request,context) if legacy else external_stream(gateway,model_request,context,api),media_type='text/event-stream',headers={**headers,'Cache-Control':'no-cache','X-Accel-Buffering':'no'})
        result=await gateway.complete(model_request,context)
        if legacy:
            attempts=gateway.store.attempts(identity.tenant,context.call_id)
            payload={'request_id':context.call_id,'model':model_request.requested_model,'content':result.text,
                     'parsed':result.data,'usage':usage(result.usage,'legacy'),'latency_ms':int((time.monotonic()-started)*1000),'attempts':len(attempts),
                     'tool_calls':result.tool_calls,'refusal':result.refusal,'finish_reason':result.finish_reason}
        else: payload=result_payload(result,api,model_request.requested_model)
        return JSONResponse(payload,headers=headers)

    @app.post('/v1/chat/completions')
    async def chat(request:Request): return await generate(request)
    @app.post('/v1/responses')
    async def responses(request:Request): return await generate(request,'responses')
    @app.post('/v1/llm')
    async def legacy(request:Request): return await generate(request,legacy=True)
    @app.post('/v1/llm/stream')
    async def legacy_stream(request:Request): return await generate(request,legacy=True,force_stream=True)
    @app.get('/v1/models')
    async def models(request:Request):
        authenticate(request)
        return {'object':'list','data':[{'id':key,'object':'model','owned_by':'gateway'} for key in settings.models]}
    @app.get('/healthz')
    async def health(): return {'status':'ok'}
    @app.get('/readyz')
    async def ready():
        configured=any(os.environ.get(c.env) for c in settings.credentials)
        available=any(t.enabled and (t.provider=='fake' or t.has_key()) for t in settings.targets)
        ready=configured and available and schema_runtime_available()
        return JSONResponse({'status':'ready' if ready else 'not_ready'},status_code=200 if ready else 503)
    @app.get('/admin/routes')
    async def routes(request:Request):
        authenticate(request,True)
        return {'models':{key:{'strategy':route.strategy,'targets':route.targets} for key,route in settings.models.items()},'targets':[{'id':t.id,'provider':t.provider,'enabled':t.enabled,'capabilities':t.capabilities.model_dump(mode='json')} for t in settings.targets]}
    @app.get('/admin/metrics')
    async def metrics(request:Request):
        identity=authenticate(request,True)
        calls=gateway.store.list_calls(identity.tenant,limit=1000)
        counts={}
        for call in calls:
            status=call.get('status','unknown')
            counts[status]=counts.get(status,0)+1
        costs=[call['cost_usd'] for call in calls if call.get('cost_usd') is not None]
        unknown_cost=len(calls)-len(costs)
        tokens={key:None for key in ('input_tokens','output_tokens','cached_tokens','reasoning_tokens')}
        for call in calls:
            if call.get('usage_status')=='unknown': continue
            known=call.get('known_usage',call.get('usage',{}))
            for key in tokens:
                if known.get(key) is not None: tokens[key]=(tokens[key] or 0)+known[key]
        return {'window':{'kind':'recent_calls','limit':1000},'recent_calls':len(calls),
                'status_counts':counts,'attempts':sum(call.get('attempts',0) for call in calls),
                'cache_hits':sum(bool(call.get('cache_hit')) for call in calls),
                'known_cost_usd':sum(costs) if costs else None,'unknown_cost_calls':unknown_cost,
                'cost_status':'partial' if costs and unknown_cost else 'known' if costs else 'unknown',
                'known_token_subtotal':tokens,
                'unknown_usage_calls':sum(call.get('usage_status')!='known' for call in calls)}
    @app.get('/admin/usage')
    @app.get('/admin/traces')
    @app.get('/v1/traces')
    async def traces(request:Request):
        identity=authenticate(request,True)
        return {'data':gateway.store.list_calls(identity.tenant)}
    @app.get('/admin/traces/{call_id}')
    async def trace(request:Request,call_id:str):
        identity=authenticate(request,True)
        result=gateway.store.get_call(identity.tenant,call_id)
        if result is None: raise GatewayError('trace_not_found','Trace 不存在',404)
        return {'call':result,'attempts':gateway.store.attempts(identity.tenant,call_id)}
    @app.get('/v1/prompts')
    async def prompts(request:Request):
        identity=authenticate(request)
        return {'data':gateway.store.list_prompts(identity.tenant)}
    @app.post('/v1/prompts')
    async def save_prompt(request:Request):
        identity=authenticate(request,True)
        return gateway.store.save_prompt(identity.tenant,await body(request))
    @app.post('/v1/prompts/{prompt_id}/activate')
    async def activate_prompt(request:Request,prompt_id:str):
        identity=authenticate(request,True);value=await body(request)
        whitelist(value,{'version'})
        version=value.get('version')
        if type(version) is not int or version<1:
            raise GatewayError('invalid_prompt_version','需要正整数版本',400)
        return gateway.store.activate_prompt(identity.tenant,prompt_id,version)
    @app.get('/v1/prompts/{prompt_id}')
    async def get_prompt(request:Request,prompt_id:str,version:int|None=None):
        identity=authenticate(request)
        return gateway.store.get_prompt(identity.tenant,prompt_id,version)
    @app.post('/v1/prompts/{prompt_id}/render')
    async def render_prompt(request:Request,prompt_id:str):
        from ..services.prompts import PromptService
        identity=authenticate(request);value=await body(request)
        whitelist(value,{'version','variables'})
        model_request=ModelRequest(messages=[Message(role='user',content='render')],prompt=PromptRef(id=prompt_id,version=value.get('version'),variables=value.get('variables',{})))
        prepared=PromptService(gateway.store).prepare(model_request,gateway.make_context(identity))
        return {'messages':[m.model_dump() for m in prepared.messages],'model':prepared.requested_model,'output_schema':prepared.output_schema}
    def public_run(record):
        return {key:record[key] for key in ('run_id','status','call_id') if key in record}
    @app.post('/v1/runs',status_code=201)
    async def create_run(request:Request):
        identity=authenticate(request)
        return public_run(await runs.create(identity,normalize(await body(request))))
    @app.get('/v1/runs/{run_id}')
    async def get_run(request:Request,run_id:str):
        identity=authenticate(request);record=runs.get(identity,run_id)
        return {'run_id':run_id,'status':record['status'],'call_id':record.get('call_id')}
    @app.post('/v1/runs/{run_id}/cancel')
    async def cancel_run(request:Request,run_id:str): return public_run(await runs.cancel(authenticate(request),run_id))
    @app.post('/v1/runs/{run_id}/resume',status_code=201)
    async def resume_run(request:Request,run_id:str): return public_run(await runs.resume(authenticate(request),run_id))
    @app.get('/v1/runs/{run_id}/events')
    async def run_events(request:Request,run_id:str,after:int=-1):
        identity=authenticate(request);runs.get(identity,run_id)
        try: cursor=int(request.headers.get('Last-Event-ID',after))
        except ValueError: raise GatewayError('invalid_cursor','Last-Event-ID 必须为事件序号',400) from None
        async def stream():
            async for event in runs.events(identity,run_id,cursor):
                if event['type']=='heartbeat': yield ': heartbeat\n\n'
                else: yield sse(event['type'],event,event['seq'])
        return StreamingResponse(stream(),media_type='text/event-stream',headers={'Cache-Control':'no-cache'})
    @app.get('/v1/streams/{request_id}/checkpoint')
    async def stream_checkpoint(request:Request,request_id:str):
        identity=authenticate(request)
        record=gateway.store.get_stream_checkpoint(identity.tenant,request_id)
        if record is None:
            raise GatewayError('checkpoint_not_found','流式检查点不存在或未开启',404,stage='stream')
        return record
    @app.get('/demo',response_class=HTMLResponse)
    async def demo(): return DEMO
    return app


DEMO = r'''<!doctype html><meta charset="utf-8"><title>Gateway Run Demo</title>
<h1>Run 事件订阅</h1>
<p>断开订阅不会取消 Run；重连从最后序号继续。所有时间由浏览器本地单调时钟测量，含网络和重放时间，与服务器时间分开。</p>
<input id="key" type="password" placeholder="Gateway API key"><textarea id="prompt">你好</textarea>
<button id="create" onclick="start()">创建 Run</button><button onclick="watch()">重连订阅</button>
<button onclick="disconnect()">断开订阅</button><button onclick="cancelRun()">取消 Run</button>
<p id="status" role="status">尚未订阅</p><p id="timings">客户端 TTFT：等待文本</p><pre id="events"></pre>
<script>
const MAX_DISPLAY=128*1024,MAX_BUFFER=1024*1024,encoder=new TextEncoder();
const knownEvents=new Set(['run.created','run.started','text.delta','tool.delta','refusal.delta','model.usage','model.finished','completed','failed','cancelled','run.completed','run.failed','run.cancelled']);
const terminals=new Set(['run.completed','run.failed','run.cancelled']);
let runId=null,last=-1,subscription=null,display='',refresh=null;
let createStarted=null,createTTFT=null,createE2E=null,subscriptionTTFT=null,subscriptionReplay=false;
const headers=()=>({'Authorization':'Bearer '+document.querySelector('#key').value,'Content-Type':'application/json'});
const status=(text)=>{document.querySelector('#status').textContent=text};
function bounded(text){const bytes=encoder.encode(text);if(bytes.length<=MAX_DISPLAY)return text;text=new TextDecoder().decode(bytes.subarray(bytes.length-MAX_DISPLAY));while(encoder.encode(text).length>MAX_DISPLAY)text=text.slice(1);return text}
function scheduleRender(){if(refresh===null)refresh=requestAnimationFrame(()=>{document.querySelector('#events').textContent=display;drawTiming();refresh=null})}
function queueDisplay(text){display=bounded(display+text);scheduleRender()}
function drawTiming(){const fmt=x=>x===null?'等待/不可用':x.toFixed(1)+' ms';document.querySelector('#timings').textContent='客户端创建→首有效文本 TTFT：'+fmt(createTTFT)+'；创建→Run 终态 E2E：'+fmt(createE2E)+'；本次'+(subscriptionReplay?'重连/重放':'订阅')+' TTFT：'+fmt(subscriptionTTFT)}
function disconnect(){if(subscription)subscription.abort();subscription=null;status('订阅已断开，Run 继续运行')}
async function start(){const button=document.querySelector('#create');if(button.disabled)return;button.disabled=true;disconnect();createStarted=performance.now();createTTFT=null;createE2E=null;runId=null;last=-1;display='';queueDisplay('');scheduleRender();try{const response=await fetch('/v1/runs',{method:'POST',headers:headers(),body:JSON.stringify({messages:[{role:'user',content:document.querySelector('#prompt').value}]})});const data=await response.json();if(!response.ok)throw Error('创建失败：'+JSON.stringify(data));runId=data.run_id;watch()}catch(error){status(error.message)}finally{button.disabled=false}}
async function cancelRun(){if(!runId)return;try{const response=await fetch('/v1/runs/'+encodeURIComponent(runId)+'/cancel',{method:'POST',headers:headers()});if(!response.ok)throw Error('取消失败：HTTP '+response.status);status('已请求取消 Run')}catch(error){status(error.message)}}
async function watch(){
 if(!runId)return;if(subscription)subscription.abort();
 const controller=new AbortController();subscription=controller;const activeRun=runId,started=performance.now();
 subscriptionTTFT=null;subscriptionReplay=last>=0;scheduleRender();status('订阅中：'+activeRun);
 let reader=null,buffer='';const decoder=new TextDecoder();
 function accept(frame){
  const lines=frame.split('\n').filter(line=>line.startsWith('data:')).map(line=>line.slice(5).replace(/^ /,''));if(!lines.length)return;
  const event=JSON.parse(lines.join('\n'));
  if(event.schema_version!==1||!Number.isInteger(event.schema_version))throw Error('unsupported_event_version：不支持的 Run 版本，停止订阅');
  if(!Number.isInteger(event.seq)||typeof event.type!=='string')throw Error('invalid_run_event：事件位置或类型无效');
  if(event.seq<=last)return;last=event.seq;
  if(!knownEvents.has(event.type))console.warn('Unknown Run event, display only:',event.type);
  const now=performance.now();
  if(event.type==='text.delta'&&typeof event.data?.delta==='string'&&event.data.delta.trim()){
   if(subscriptionTTFT===null)subscriptionTTFT=now-started;
   if(createStarted!==null&&createTTFT===null)createTTFT=now-createStarted;
  }
  if(terminals.has(event.type)&&createStarted!==null&&createE2E===null)createE2E=now-createStarted;
  scheduleRender();queueDisplay(JSON.stringify(event)+'\n');
 }
 try{
  const response=await fetch('/v1/runs/'+encodeURIComponent(activeRun)+'/events',{headers:{...headers(),'Last-Event-ID':String(last)},signal:controller.signal});
  if(!response.ok)throw Error('订阅失败：HTTP '+response.status);
  reader=response.body.getReader();
  while(subscription===controller){
   const {value,done}=await reader.read();if(subscription!==controller)return;
   buffer+=(done?decoder.decode():decoder.decode(value,{stream:true}));buffer=buffer.replace(/\r\n/g,'\n');
   let index;while((index=buffer.indexOf('\n\n'))>=0){const frame=buffer.slice(0,index);buffer=buffer.slice(index+2);if(encoder.encode(frame).length>MAX_BUFFER)throw Error('event_buffer_exceeded：事件超过 1 MiB');accept(frame)}
   if(encoder.encode(buffer).length>MAX_BUFFER)throw Error('event_buffer_exceeded：未分帧缓冲超过 1 MiB');
   if(done){if(buffer.trim())accept(buffer);status('本次订阅结束，可重连');break}
  }
 }catch(error){if(subscription===controller&&error.name!=='AbortError')status(error.message)}
 finally{controller.abort();if(reader){try{await reader.cancel()}catch(error){}reader.releaseLock()}if(subscription===controller)subscription=null}
}
</script>'''
