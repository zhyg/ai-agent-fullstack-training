"""Convenience launcher; application composition lives in app/main.py."""
from .app.main import app


if __name__ == '__main__':
    import os
    import uvicorn
    uvicorn.run(app, host=os.environ.get('GATEWAY_HOST', '127.0.0.1'),
                port=int(os.environ.get('GATEWAY_PORT', '8003')))
