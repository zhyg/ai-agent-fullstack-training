"""Safe configuration check; --live makes three bounded provider calls."""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os

from .app.config import Settings
from .app.schemas import GatewayError, ModelRequest


def configuration():
    required = ("fastapi", "uvicorn", "pydantic", "httpx", "dotenv", "jinja2", "jsonschema", "openai")
    deps = {name: importlib.util.find_spec(name) is not None for name in required}
    settings = Settings.from_env()
    provider_available = any(t.enabled and t.has_key() for t in settings.targets)
    gateway_available = any(bool(os.environ.get(c.env)) for c in settings.credentials)
    return settings, {
        "mode": "config-only-no-network",
        "dependencies": deps,
        "provider_credential_available": provider_available,
        "gateway_credential_available": gateway_available,
        "logical_models": list(settings.models),
        "ready_for_local_start": all(deps.values()) and gateway_available and provider_available,
    }


async def live(settings):
    from .app.services.gateway import Gateway
    from .app.services.usage import Store
    # Integration smoke spends at most three attempts; never retries or repairs.
    settings = settings.model_copy(deep=True)
    settings.deadline = 20
    settings.max_attempts = 1
    settings.max_repairs = 0
    for target in settings.targets:
        target.retries = 0
        target.timeout = min(target.timeout, 20)
    gateway = Gateway(settings, store=Store(":memory:"))
    cases = []
    try:
        for name in ("chat", "stream", "structured"):
            try:
                request = ModelRequest(messages=[{"role": "user", "content": "请用一句话解释模型网关。"}], max_output_tokens=128)
                if name == "stream":
                    events = [e async for e in gateway.stream(request.model_copy(update={"stream": True}))]
                    if not events or events[-1].type != "completed":
                        code = events[-1].data.get("code", "stream_incomplete") if events else "stream_incomplete"
                        raise GatewayError(code, "流未成功完成", 502)
                    passed = any(e.type == "text.delta" for e in events)
                else:
                    if name == "structured":
                        request = ModelRequest(messages=[{"role": "user", "content": '只返回 JSON：{"ok":true}'}],
                            max_output_tokens=128, output_schema={"type": "object", "properties": {"ok": {"const": True}},
                            "required": ["ok"], "additionalProperties": False})
                    result = await gateway.complete(request)
                    passed = result.data == {"ok": True} if name == "structured" else bool(result.text)
                cases.append({"case": name, "passed": passed})
            except GatewayError as error:
                cases.append({"case": name, "passed": False, "error_code": error.code})
        return {"mode": "live-provider", "total": len(cases), "passed": sum(c["passed"] for c in cases), "cases": cases}
    finally:
        await gateway.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="真实调用三次，会产生供应商费用")
    args = parser.parse_args()
    try:
        settings, report = configuration()
        if args.live:
            if not all(report["dependencies"].values()):
                report["live_skipped"] = "missing_dependency"
            elif not report["provider_credential_available"]:
                report["live_skipped"] = "missing_provider_credential"
            else:
                report = asyncio.run(live(settings))
        print(json.dumps(report, ensure_ascii=False, indent=2))
        if args.live:
            return 0 if report.get("passed") == 3 else 1
        return 0 if all(report["dependencies"].values()) else 1
    except Exception:
        # Do not print arbitrary Pydantic input values, env names, URLs or secrets.
        print(json.dumps({"mode": "configuration", "error_code": "invalid_configuration"}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
