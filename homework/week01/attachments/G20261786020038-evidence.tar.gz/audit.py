"""Read-only checks of report format, totals, source blobs and evidence secrets."""
import hashlib
import os
import re
from pathlib import Path

root=Path('/home/user/workspace/repo')
feedback=root/'homework/week01/G20261786020038.md'
attachment=root/'homework/week01/attachments/G20261786020038.md'
stage=Path('/tmp/sunny-grade/evidence')
text=feedback.read_text()
assert '优秀（95分）' in text
for section in ['2. 作业优点','3. 作业不足','4. 改进方案']:
    part=text.split('**'+section+'**\n\n')[1].split('\n**')[0]
    lines=[x for x in part.splitlines() if x.startswith('- ')]
    assert 3<=len(lines)<=5 and len(''.join(lines))<=500
    print(section, 'items=',len(lines),'characters=',len(''.join(lines)))
scores=[int(x) for x in re.findall(r'^\| [^|]+ \| (\d+)/\d+ \|',attachment.read_text(),re.M)]
assert scores==[15,15,8,10,15,12,10,10] and sum(scores)==95
print('score_sum=95; grade=优秀; eight categories verified')
for line in (stage/'source-blobs.txt').read_text().splitlines():
    metadata,name=line.split('\t',1)
    expected=metadata.split()[2]
    data=(stage/'student'/name).read_bytes()
    got=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert got==expected,name
print('fixed_snapshot_all_git_blobs_match=true')
secrets=[os.environ.get(k,'').encode() for k in ['DEEPSEEK_API_KEY','OPENAI_API_KEY','GITHUB_TOKEN','GH_TOKEN'] if len(os.environ.get(k,''))>=12]
files=[p for p in stage.rglob('*') if p.is_file()]+[feedback,attachment]
for path in files:
    data=path.read_bytes()
    assert not any(s in data for s in secrets),'credential match in '+str(path)
    assert not re.search(rb'\bsk-[A-Za-z0-9_-]{16,}',data),'key-shaped value in '+str(path)
    assert not re.search(rb'https?://[^/\s:@]+:[^/\s@]+@',data),'credential URL in '+str(path)
    assert path.name!='.env' and '.git' not in path.parts
print('credential_scan=PASS; files_checked=',len(files),'; no .env/.git/private keys archived')
