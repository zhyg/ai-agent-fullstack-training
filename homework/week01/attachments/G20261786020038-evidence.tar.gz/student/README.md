# Python LLM 閘道

以單一程序實作 LLM 閘道需求。FastAPI 提供統一的 API，服務依據模型將請求路由至兩種協定轉接器：

```mermaid
flowchart LR
  Client[用戶端] --> API[FastAPI 驗證]
  API --> Core[提示詞渲染 / 重試 / 模型速率限制]
  Core --> Chat[Chat Completions 轉接器]
  Core --> Responses[Responses 轉接器]
  Chat --> DeepSeek[deepseek-v4-flash]
  Responses --> OpenAI[gpt-6-astra]
  Core --> Trace[有容量上限的中繼資料追蹤紀錄]
```

## 安裝與執行

需要 Python 3.11 或更新版本。請在此目錄執行：

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[test]'
cp .env.example .env
# 在本機編輯 .env 並填入憑證；請勿將此檔案提交至版本控制。
set -a
source .env
set +a
.venv/bin/uvicorn gateway.main:app --host 127.0.0.1 --port 8000
```

應用程式會讀取程序的環境變數，不會自動載入 `.env`。
請使用單一 worker。範本、追蹤歷史與模型速率限制器皆儲存在記憶體中，重新啟動後會重設。
API 文件位於 http://127.0.0.1:8000/docs。
若已設定 `GATEWAY_API_KEY`，所有 API 請求都必須附上 `Authorization: Bearer <gateway-key>`。

## 目錄結構

```text
llm-gateway/
├── gateway/
│   ├── main.py          # 應用程式設定、供應商配置與身分驗證
│   ├── models.py        # 請求、回應與用量的資料契約
│   ├── providers.py     # Chat Completions 與 Responses 轉接器
│   ├── api/             # HTTP 路由與 SSE 回應
│   ├── core/            # 錯誤、速率限制、重試與請求上下文
│   └── services/        # 流程協調、提示詞、輸出驗證與追蹤紀錄
├── scripts/             # 驗證執行程式，包含可選的實際 API 檢查
├── tests/               # 使用模擬呼叫的閘道與供應商測試
├── .env.example         # 環境設定範本
├── pyproject.toml       # 相依套件與專案設定
└── README.md
```

## 使用範例

一次取得完整回應：

```bash
curl http://127.0.0.1:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"請用一句話解釋閘道。"}]}'
```

串流回應使用相同的端點：

```bash
curl -N http://127.0.0.1:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-v4-flash","stream":true,"messages":[{"role":"user","content":"請從一數到三。"}]}'
```

事件使用 SSE `data:` JSON 格式，`type` 為 `content.delta`、`response.completed` 或 `response.failed`。同一請求的每個事件都帶有相同的請求 ID。成功結束事件包含實際選用的模型、用量與首個內容 token 的延遲。首個內容事件發送前的錯誤會保留 HTTP 狀態碼；開始傳送內容後，錯誤則以串流事件回報。一旦送出內容，就不再重試或切換至備援模型。

### 結構化回應：分類客服訊息

要求模型依照指定的 JSON 結構，回傳訊息類別與是否緊急的旗標：

```bash
curl http://127.0.0.1:8000/v1/llm \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-v4-flash",
    "messages": [
      {
        "role": "user",
        "content": "請分類這則客服訊息：我的訂閱被重複扣款了，請立即處理。"
      }
    ],
    "response_format": {
      "type": "json_schema",
      "json_schema": {
        "name": "support_classification",
        "strict": true,
        "schema": {
          "type": "object",
          "properties": {
            "category": {
              "type": "string",
              "enum": ["billing", "technical", "other"]
            },
            "urgent": {
              "type": "boolean"
            }
          },
          "required": ["category", "urgent"],
          "additionalProperties": false
        }
      }
    }
  }'
```

若已啟用 `GATEWAY_API_KEY`，請加上 `-H 'Authorization: Bearer <gateway-key>'`。
此結構描述要求兩個欄位皆必填，將 `category` 限定為列出的三個值，要求 `urgent` 為布林值，並禁止額外欄位。

以下為示意回應，已省略中繼資料：

```json
{
  "model": "deepseek-v4-flash",
  "content": "{\"category\":\"billing\",\"urgent\":true}",
  "parsed": {
    "category": "billing",
    "urgent": true
  }
}
```

`content` 是模型回傳的原始文字；`parsed` 則是經閘道解析與驗證後的 JSON 物件。應用程式可以直接使用已驗證的欄位：

```python
result = response.json()

if result["parsed"]["category"] == "billing":
    route_to_billing_team()
```

對 DeepSeek 而言，閘道會啟用 JSON 模式，將結構描述加入模型指令，再於本機驗證回傳的 JSON。若答案包含 `"urgent": "yes"`，就會驗證失敗，並回傳 `invalid_structured_output` 錯誤。驗證可確保成功回應符合指定結構，但無法保證分類結果正確。

### 結構化 JSON 與版本化提示詞

```json
{
  "model": "deepseek-v4-flash",
  "messages": [{"role": "user", "content": "我們是否應該搜尋缺少的政策資訊？"}],
  "prompt": {
    "name": "knowledge_decision",
    "version": "v1",
    "variables": {"product_name": "Demo"}
  },
  "response_format": {
    "type": "json_schema",
    "json_schema": {
      "name": "decision",
      "strict": true,
      "schema": {
        "type": "object",
        "properties": {"search": {"type": "boolean"}},
        "required": ["search"],
        "additionalProperties": false
      }
    }
  }
}
```

也支援 `{"type":"json_object"}`。結構描述的根節點必須是物件。DeepSeek 使用 JSON 模式、指令與本機驗證；OpenAI Responses 則使用 `text.format` 與本機驗證。OpenAI 嚴格模式支援 JSON Schema 的部分功能：請將屬性設為必填，並設定 `additionalProperties: false`。若上游不支援該結構描述，請求會失敗且不會重試。串流與結構化輸出無法同時使用。

範本儲存在 [services/prompts.py](gateway/services/prompts.py) 中受控的 `TEMPLATES` 登錄表。新增 `(name, version)` 項目即可發布新版本；請求只需選擇版本並提供替換變數，不會提交範本原始內容。呼叫端仍可提供 system 訊息，因此範本管理並不能防禦提示詞注入。

## 設定與行為

請參閱 [.env.example](.env.example)。預設值如下：

| 設定 | 預設值 |
|---|---|
| 主要模型 / 協定 | `deepseek-v4-flash` / Chat Completions |
| 備援模型 / 協定 | `gpt-6-astra` / Responses |
| 模型速率限制 | 每個模型獨立計算，每個滾動分鐘最多 60 次上游嘗試 |
| 單次嘗試逾時 | 30 秒（`timeout_seconds`，上限 120 秒） |
| 整體期限 | 120 秒（`deadline_seconds`，上限 600 秒） |
| 重試額度 | 每個模型首次嘗試後最多重試 3 次 |
| 退避等待 | 0.25、0.5、1 秒，每次另加最多 25% 的隨機抖動 |
| 追蹤紀錄保留量 | 最近 1,000 筆請求 |

登錄表以實際設定的模型識別碼作為公開的 `model` 值。直接請求備援模型時，不會再切換回主要模型。SDK 的自動重試功能已停用。連線失敗、逾時、HTTP 408/429 與上游 5xx 錯誤可以重試。若上游提供數值型的 `Retry-After`，閘道會遵守該等待時間，但仍受整體期限限制。其他上游錯誤、缺少憑證、無效 JSON 與結構驗證失敗都會直接終止請求。

主要模型的重試次數耗盡後，可接續嘗試備援模型；總共最多八次上游嘗試，除非整體期限或本機速率限制提前終止請求。每次嘗試都會消耗所選模型的額度。本機額度耗盡時會回傳 HTTP 429 與 `Retry-After`，不會觸發備援切換，也不會進入等待佇列。

## 可觀測性與隱私

`GET /v1/traces` 與 `llm_gateway` 日誌記錄器只提供中繼資料：

- 請求 ID、時間戳記、設定中的請求模型與實際選用模型，以及範本版本。
- 總延遲與串流首個內容 token 的延遲；非串流回應的首個 token 延遲未知（`null`）。
- 每次嘗試的模型、結果、錯誤碼、延遲與用量。
- 輸入與輸出 token 數量，以及可選的快取輸入與推理輸出明細。
- 跨嘗試的已知用量總計，以及表示每次嘗試是否都回報輸入與輸出數量的 `usage_complete`。快取與推理類別屬於子集合，不應再次加總為額外 token。

未知的 token 數量以 `null` 表示，而非零。失敗的呼叫即使未回報用量，仍可能產生供應商費用。由於價格與不完整用量可能造成誤導，因此不提供金額估算。頂層用量描述最近一次回報的回應；每次嘗試的用量與已知總計則可用於跨重試的用量核算。驗證失敗會使用安全的通用錯誤記錄，不會回傳無效的原始輸入。

憑證保存在環境變數中；應用程式追蹤紀錄不包含請求主體、提示詞內容、輸出、原始 SDK 例外或授權標頭。SDK 偵錯日誌已停用。可選的閘道 Bearer 金鑰可保護呼叫與追蹤端點；若未設定，本示範應僅綁定 localhost。呼叫期間，程序記憶體會包含提示詞，內容也會傳送至所選供應商，包括備援切換時的 OpenAI。本專案未提供自動個人資料遮蔽、靜態資料加密層、租戶隔離或持久化稽核儲存。

## 驗證

請在此目錄執行完整驗證程式：

```bash
.venv/bin/python scripts/validate_gateway.py
```

程式會先執行模擬測試套件，涵蓋兩種供應商協定、結構化輸出、SSE、提示詞渲染、重試、備援切換、速率限制、整體期限、資源清理、隱私與身分驗證。接著，對每個已設定的供應商發送一次簡短的實際文字生成請求。實際檢查結果只會列印模型別名、成功或失敗狀態、標準化錯誤碼、HTTP 狀態碼與 token 用量，絕不列印憑證或供應商回應主體。若沒有憑證，可使用 `--skip-live`：

```bash
.venv/bin/python scripts/validate_gateway.py --skip-live
```

若測試失敗，或任一已設定的供應商缺少憑證或拒絕實際請求，指令會以非零結束碼退出。供應商可能回傳額度耗盡等有效的 HTTP 錯誤；這些情況會如實回報為實際檢查失敗。

## 測試與驗證結果

```bash
.venv/bin/pytest -q -W error::RuntimeWarning
```

測試使用假的供應商與模擬 HTTP 傳輸，不需要真實憑證，也不會產生計費請求。涵蓋兩種傳輸協定、輸出驗證、SSE 用量、重試與退避等待、備援切換、本機速率限制、整體期限、斷線清理、提示詞渲染、隱私與身分驗證。

2026-10-25 的實際檢查結果：`deepseek-v4-flash` 與 `gpt-6-astra` 皆成功完成請求並回傳用量中繼資料。結構化 JSON、SSE、重試、備援切換、速率限制、提示詞渲染與隱私行為仍以模擬測試套件作為驗證依據。

協定參考文件： [DeepSeek Chat Completions](https://api-docs.deepseek.com/api/create-chat-completion/), [OpenAI Responses](https://developers.openai.com/api/reference/resources/responses/methods/create), [GPT-6 Astra 模型](https://developers.openai.com/api/docs/models/gpt-6-astra).

## 原始碼說明

- [models.py](gateway/models.py)：經驗證的公開資料契約。
- [providers.py](gateway/providers.py)：供應商介面與協定轉接器。
- [main.py](gateway/main.py)：應用程式進入點、供應商配置、身分驗證與生命週期。
- [api/routes.py](gateway/api/routes.py)：HTTP 與 SSE 端點。
- [core/](gateway/core/)：錯誤、重試策略、速率限制與執行期型別。
- [services/](gateway/services/)：流程協調、提示詞、結構化輸出與可觀測性。
- [tests](tests)：服務與協定測試。
