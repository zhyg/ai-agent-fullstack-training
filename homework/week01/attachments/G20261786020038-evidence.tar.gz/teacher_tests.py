import asyncio
import json
import time
from unittest.mock import patch

import httpx
import pytest
from fastapi.testclient import TestClient
from openai import AsyncOpenAI

from gateway.main import create_app
from gateway.core.runtime import Model
from gateway.models import LLMRequest
from gateway.providers import ChatCompletionsProvider, ResponsesProvider
from gateway.services.gateway import Gateway
from gateway.services.prompts import TEMPLATES

CAPTURES = []


def body(model='chat', **extra):
    return dict(model=model, messages=[dict(role='user', content='Return JSON {"answer":7}')], **extra)


def wire(protocol, text='{"answer":7}', terminal='stop'):
    if protocol == 'chat':
        return dict(id='teacher-chat', object='chat.completion', created=0, model='chat-upstream',
                    choices=[dict(index=0, message=dict(role='assistant', content=text), finish_reason=terminal)],
                    usage=dict(prompt_tokens=11, completion_tokens=7, total_tokens=18,
                               prompt_cache_hit_tokens=3, completion_tokens_details=dict(reasoning_tokens=2)))
    return dict(id='teacher-response', object='response', created_at=0, model='response-upstream', status=terminal if terminal != 'stop' else 'completed',
                output=[dict(type='message', id='m', role='assistant', status='completed',
                             content=[dict(type='output_text', text=text, annotations=[])])],
                usage=dict(input_tokens=11, output_tokens=7, total_tokens=18,
                           input_tokens_details=dict(cached_tokens=3), output_tokens_details=dict(reasoning_tokens=2)))


def event_bytes(protocol, phase):
    if protocol == 'chat':
        event = dict(id='s', object='chat.completion.chunk', created=0, model='chat-upstream', choices=[])
        if phase == 'meta':
            event['choices'] = [dict(index=0, delta=dict(role='assistant'), finish_reason=None)]
        elif phase == 'text':
            event['choices'] = [dict(index=0, delta=dict(content='独立增量'), finish_reason=None)]
        else:
            event['choices'] = [dict(index=0, delta={}, finish_reason='stop')]
            event['usage'] = wire(protocol)['usage']
        return ('data: ' + json.dumps(event) + '\n\n').encode()
    if phase == 'meta':
        event = dict(type='response.created', sequence_number=0, response=wire(protocol))
    elif phase == 'text':
        event = dict(type='response.output_text.delta', delta='独立增量', item_id='m', output_index=0, content_index=0, sequence_number=1)
    else:
        event = dict(type='response.completed', sequence_number=2, response=wire(protocol))
    return ('event: ' + event['type'] + '\ndata: ' + json.dumps(event) + '\n\n').encode()


async def provider(protocol, handler):
    cls = ChatCompletionsProvider if protocol == 'chat' else ResponsesProvider
    p = cls('teacher-dummy', 'https://teacher.invalid/v1')
    retries = p.client.max_retries
    await p.client.close()
    p.client = AsyncOpenAI(api_key='teacher-dummy', base_url='https://teacher.invalid/v1', max_retries=retries,
                          http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    return p


async def setup(protocol='chat', text='{"answer":7}', terminal='stop', statuses=None, backoff=0):
    calls = []
    def handler(request):
        calls.append(dict(path=request.url.path, body=json.loads(request.content)))
        status = statuses[min(len(calls)-1, len(statuses)-1)] if statuses else 200
        return httpx.Response(status, json=wire(protocol, text, terminal) if status == 200 else {'error': {'message':'controlled upstream rejection', 'type':'invalid_request_error'}})
    p = await provider(protocol, handler)
    g = Gateway({protocol: Model(protocol+'-upstream', p)}, backoff=backoff)
    return g, p, calls


@pytest.mark.parametrize('protocol', ['chat','responses'])
async def test_A03_F03_F07_wire(protocol):
    g,p,calls = await setup(protocol)
    try:
        r = await g.complete(LLMRequest(**body(protocol, response_format={'type':'json_object'})))
        assert r.parsed == {'answer':7}
        assert r.usage.model_dump() == dict(input_tokens=11,output_tokens=7,cached_input_tokens=3,reasoning_output_tokens=2)
        assert g.traces[-1]['request_id'] == r.request_id
        assert g.traces[-1]['latency_ms'] >= 0 and r.first_token_latency_ms is None
        request = calls[0]
        assert request['path'] == ('/v1/chat/completions' if protocol == 'chat' else '/v1/responses')
        assert ('messages' in request['body']) == (protocol == 'chat')
        assert (request['body']['response_format'] if protocol == 'chat' else request['body']['text']['format']) == {'type':'json_object'}
        CAPTURES.append(dict(case='A03_F03_F07',protocol=protocol,request=request,result=r.model_dump(),trace=g.traces[-1]))
    finally:
        await p.close()


@pytest.mark.parametrize('protocol', ['chat','responses'])
@pytest.mark.parametrize('text', ['not JSON','','{"answer":','{"answer":"wrong"}'])
async def test_F04_invalid_empty_schema(protocol,text):
    g,p,calls = await setup(protocol,text)
    try:
        with TestClient(create_app(g)) as c:
            r=c.post('/v1/llm',json=body(protocol,response_format={'type':'json_schema','json_schema':{'schema':{'type':'object','properties':{'answer':{'type':'integer'}},'required':['answer']}}}))
            assert r.status_code == 502 and r.json()['error']['code']=='invalid_structured_output'
            assert len(calls)==1
            assert g.traces[-1]['status']=='failed'
            CAPTURES.append(dict(case='F04',protocol=protocol,input=text,status=r.status_code,result=r.json(),trace=g.traces[-1]))
    finally:
        await p.close()


@pytest.mark.parametrize('protocol,terminal', [('chat','length'),('responses','incomplete')])
async def test_F04_truncated_valid_json(protocol,terminal):
    g,p,calls = await setup(protocol,terminal=terminal)
    try:
        with TestClient(create_app(g)) as c:
            r=c.post('/v1/llm',json=body(protocol,response_format={'type':'json_object'}))
            CAPTURES.append(dict(case='F04_truncated_valid_json',protocol=protocol,upstream_terminal=terminal,status=r.status_code,result=r.json()))
            assert r.status_code >= 400, 'truncated structured output must not succeed'
    finally:
        await p.close()


async def test_A04_F05_F06_prompts():
    g,p,calls = await setup()
    try:
        with TestClient(create_app(g)) as c:
            assert c.post('/v1/llm',json=body('absent')).json()['error']['code']=='unknown_model'
            # Publishing by registry configuration is exactly the README interface.
            with patch.dict(TEMPLATES,{('knowledge_decision','v2'):'Version2 ${product_name}'}):
                for version, expected in [('v2','Version2 Demo'),('v1',"You are Demo's knowledge assistant")]:
                    r=c.post('/v1/llm',json=body(prompt=dict(name='knowledge_decision',version=version,variables={'product_name':'Demo'})))
                    assert r.status_code==200
                    assert calls[-1]['body']['messages'][0]['content'].startswith(expected)
                for name,version,variables,code in [('absent','v1',{},'unknown_prompt'),('knowledge_decision','v99',{},'unknown_prompt'),('knowledge_decision','v1',{},'invalid_prompt_variables')]:
                    before=len(calls)
                    r=c.post('/v1/llm',json=body(prompt=dict(name=name,version=version,variables=variables)))
                    assert r.status_code==400 and r.json()['error']['code']==code and len(calls)==before
            CAPTURES.append(dict(case='A04_F05_F06',requests=calls,traces=list(g.traces)))
    finally:
        await p.close()


@pytest.mark.parametrize('protocol', ['chat','responses'])
@pytest.mark.parametrize('status', [400,401,429,500])
async def test_F09_actual_SDK_budget(protocol,status):
    g,p,calls=await setup(protocol,statuses=[status],backoff=.001)
    try:
        with TestClient(create_app(g)) as c:
            r=c.post('/v1/llm',json=body(protocol))
            assert len(calls)==(1 if status in [400,401] else 4)
            assert r.status_code==502 and g.traces[-1]['status']=='failed'
            CAPTURES.append(dict(case='F09',protocol=protocol,upstream_status=status,actual_calls=len(calls),status=r.status_code,result=r.json(),trace=g.traces[-1]))
    finally:
        await p.close()


async def test_F03_upstream_unsupported_format_4xx():
    g,p,calls=await setup('responses',statuses=[400])
    try:
        with TestClient(create_app(g)) as c:
            r=c.post('/v1/llm',json=body('responses',response_format={'type':'json_object'}))
            CAPTURES.append(dict(case='F03_unsupported_format',status=r.status_code,result=r.json(),calls=calls))
            assert 400 <= r.status_code < 500
    finally:
        await p.close()


@pytest.mark.parametrize('factor',[1,1.25])
async def test_F08_backoff_actual_calls(factor):
    g,p,calls=await setup(statuses=[500,500,200],backoff=.25)
    waits=[]
    async def sleep(delay): waits.append(delay)
    try:
        with patch('gateway.services.gateway.asyncio.sleep',sleep),patch('gateway.core.retry.random.uniform',return_value=factor):
            r=await g.complete(LLMRequest(**body()))
        CAPTURES.append(dict(case='F08',factor=factor,calls=calls,waits=waits,trace=g.traces[-1]))
        assert len(calls)==3 and r.attempts==3
        assert all(wait <= ceiling for wait,ceiling in zip(waits,[.25,.5]))
    finally:
        await p.close()


async def test_F10_F11_independent_recovery():
    g,p,calls=await setup()
    g.models['chat'].rpm=1
    g.models['other']=Model('other-upstream',p,1)
    clock=[100.]
    try:
        with TestClient(create_app(g)) as c,patch('gateway.core.limits.time.monotonic',side_effect=lambda:clock[0]):
            first=c.post('/v1/llm',json=body())
            limited=c.post('/v1/llm',json=body())
            other=c.post('/v1/llm',json=body('other'))
            clock[0]=159.99
            before=c.post('/v1/llm',json=body())
            clock[0]=160.
            recovered=c.post('/v1/llm',json=body())
            statuses=[r.status_code for r in [first,limited,other,before,recovered]]
            assert statuses==[200,429,200,429,200]
            CAPTURES.append(dict(case='F10_F11',statuses=statuses,limited=limited.json(),retry_after=limited.headers.get('retry-after'),calls=calls))
    finally:
        await p.close()


@pytest.mark.parametrize('reference,expected',[('#/$defs/value',200),('#/$defs/missing',400)])
async def test_B02_B03_schema_local_ref(reference,expected):
    g,p,calls=await setup()
    schema={'type':'object','properties':{'answer':{'$ref':reference}},'$defs':{'value':{'type':'integer'}},'required':['answer']}
    try:
        with TestClient(create_app(g),raise_server_exceptions=False) as c:
            r=c.post('/v1/llm',json=body(response_format={'type':'json_schema','json_schema':{'schema':schema}}))
            CAPTURES.append(dict(case='B02_B03',reference=reference,status=r.status_code,body=r.text,traces=list(g.traces)))
            assert r.status_code==expected
    finally:
        await p.close()


@pytest.mark.parametrize('protocol',['chat','responses'])
def test_F01_F02_F07_socket_gate(protocol):
    # This client talks to a supervised uvicorn process, not a buffered ASGI transport.
    for fail in [False,True]:
        with httpx.Client(base_url='http://127.0.0.1:18762',timeout=8) as c:
            c.post('/teacher/reset',json={'protocol':protocol,'fail':fail}).raise_for_status()
            with c.stream('POST','/v1/llm',json=body(protocol,stream=True)) as response:
                lines=response.iter_lines()
                first=next(line for line in lines if line.startswith('data: '))
                delta=json.loads(first[6:])
                assert delta['type']=='content.delta' and delta['delta']=='独立增量'
                state=c.get('/teacher/state').json()
                assert state['released'] is False and len(state['calls'])==1
                c.post('/teacher/release').raise_for_status()
                rest=[json.loads(line[6:]) for line in lines if line.startswith('data: ')]
                assert [e['type'] for e in rest]==['response.failed' if fail else 'response.completed']
            state=c.get('/teacher/state').json()
            assert len(state['calls'])==1
            trace=state['traces'][-1]
            assert trace['status']==('failed' if fail else 'success')
            assert trace['first_token_latency_ms']>=40
            if not fail:
                assert trace['usage']['input_tokens']==11 and trace['usage']['reasoning_output_tokens']==2
            CAPTURES.append(dict(case='F01_F02_F07_gate',protocol=protocol,fail=fail,first=delta,rest=rest,state=state))


@pytest.fixture(scope='session',autouse=True)
def save_results():
    yield
    with open('/tmp/sunny-grade/teacher-results.json','w') as f:
        json.dump(CAPTURES,f,ensure_ascii=False,indent=2)
