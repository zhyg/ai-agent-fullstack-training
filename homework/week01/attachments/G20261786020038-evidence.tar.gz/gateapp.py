import asyncio
import httpx
from fastapi import Request
from gateway.main import create_app
from gateway.services.gateway import Gateway
from gateway.core.runtime import Model
from teacher_tests import provider,event_bytes

state={}
g=Gateway({})
app=create_app(g)

class Gated(httpx.AsyncByteStream):
    async def __aiter__(self):
        yield event_bytes(state['protocol'],'meta')
        await asyncio.sleep(.06)
        yield event_bytes(state['protocol'],'text')
        await state['gate'].wait()
        if state['fail']:
            raise httpx.ReadError('controlled disconnect after text')
        yield event_bytes(state['protocol'],'end')

@app.post('/teacher/reset')
async def reset(request:Request):
    for m in g.models.values(): await m.provider.close()
    state.clear()
    state.update(await request.json())
    state.update(gate=asyncio.Event(),calls=[],released=False)
    def handler(req):
        import json
        state['calls'].append({'path':req.url.path,'body':json.loads(req.content)})
        return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Gated())
    p=await provider(state['protocol'],handler)
    g.models={state['protocol']:Model(state['protocol']+'-upstream',p)}
    g.limiter.windows.clear()
    g.traces.clear()
    return {'ok':True}

@app.post('/teacher/release')
async def release():
    state['released']=True
    state['gate'].set()
    return {'ok':True}

@app.get('/teacher/state')
async def get_state():
    return {**{k:v for k,v in state.items() if k!='gate'},'traces':list(g.traces)}
