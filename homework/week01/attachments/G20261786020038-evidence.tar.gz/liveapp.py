"""External configuration/instrumentation only; no provider or gateway logic changes."""
import json
import time
import httpx
from gateway.main import configured_gateway,create_app

g=configured_gateway()

class CaptureStream(httpx.AsyncByteStream):
    def __init__(self,stream,record):
        self.stream,self.record=stream,record
    async def __aiter__(self):
        pending=b''
        async for chunk in self.stream:
            pending+=chunk
            while b'\n' in pending:
                line,pending=pending.split(b'\n',1)
                if line.startswith(b'data: '):
                    try:
                        data=json.loads(line[6:])
                        value=data.get('id') or data.get('response',{}).get('id')
                        if value:self.record['upstream_id']=value
                    except (ValueError,AttributeError):pass
            yield chunk
    async def aclose(self):
        await self.stream.aclose()
        with open('/tmp/sunny-grade/live-wire.jsonl','a') as f:
            f.write(json.dumps(self.record,ensure_ascii=False)+'\n')

async def request_hook(request):
    request.extensions['teacher_started']=time.perf_counter()

async def response_hook(response):
    request=response.request
    record={'host':request.url.host,'path':request.url.path,
            'request_body':json.loads(request.content),'status':response.status_code,
            'headers_latency_ms':round((time.perf_counter()-request.extensions['teacher_started'])*1000,3),
            'request_ids':{k:v for k,v in response.headers.items() if k.lower() in {'x-request-id','request-id','x-ds-request-id','trace-id'}}}
    if record['request_body'].get('stream'):
        response.stream=CaptureStream(response.stream,record)
    else:
        data=json.loads(await response.aread())
        record['upstream_id']=data.get('id')
        with open('/tmp/sunny-grade/live-wire.jsonl','a') as f:
            f.write(json.dumps(record,ensure_ascii=False)+'\n')

for model in g.models.values():
    if model.provider:
        model.provider.client._client.event_hooks['request'].append(request_hook)
        model.provider.client._client.event_hooks['response'].append(response_hook)

app=create_app(g)
