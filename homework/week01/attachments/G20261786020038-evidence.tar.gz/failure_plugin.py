"""Inject one controlled test failure to verify the student's validation entry point."""
def pytest_runtest_call(item):
    if item.name == 'test_complete_prompt_usage':
        raise AssertionError('TEACHER_F12_CONTROLLED_FAILURE: validation must report this failure')
