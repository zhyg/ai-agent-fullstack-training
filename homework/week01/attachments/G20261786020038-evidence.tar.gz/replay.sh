#!/usr/bin/env bash
# Extract evidence contents to /tmp/sunny-grade before use. No stored credentials.
# Offline cases intentionally retain four failures on the fixed student snapshot.
set -eu
cd /tmp/sunny-grade/student
python3 -m venv .venv
.venv/bin/pip install -e '.[test]'
.venv/bin/python scripts/validate_gateway.py --skip-live
amp orb service start sunny-gate --command 'PYTHONPATH=/tmp/sunny-grade /tmp/sunny-grade/student/.venv/bin/uvicorn gateapp:app --host 127.0.0.1 --port 18762' --port 18762
trap 'amp orb service stop sunny-gate; amp orb service stop sunny-live' EXIT
for i in $(seq 1 15); do curl -fsS http://127.0.0.1:18762/healthz >/dev/null && break; sleep 1; done
set +e
.venv/bin/python -m pytest -c pyproject.toml ../teacher_tests.py -v --tb=short
echo "teacher_exit=$? (expected 1: 25 passed, 4 failed)"
PYTHONPATH=/tmp/sunny-grade PYTEST_ADDOPTS='-p failure_plugin' .venv/bin/python scripts/validate_gateway.py --skip-live
echo "injected_failure_exit=$? (expected 1)"
set -e
# Real calls are opt-in. Supply the official key via the environment, never in this file.
if [ "${RUN_LIVE:-0}" = 1 ]; then
  : "${DEEPSEEK_API_KEY:?Set existing official key in environment}"
  export PRIMARY_MODEL=deepseek-v4-flash BACKUP_MODEL=deepseek-v4-pro
  export PRIMARY_BASE_URL=https://api.deepseek.com BACKUP_BASE_URL=https://api.deepseek.com
  export OPENAI_API_KEY="$DEEPSEEK_API_KEY"
  .venv/bin/python scripts/validate_gateway.py --timeout 15
  amp orb service start sunny-live --command 'PYTHONPATH=/tmp/sunny-grade /tmp/sunny-grade/student/.venv/bin/uvicorn liveapp:app --host 127.0.0.1 --port 18761' --port 18761
  for i in $(seq 1 15); do curl -fsS http://127.0.0.1:18761/readyz >/dev/null && break; sleep 1; done
  .venv/bin/python ../live_checks.py
fi
