import asyncio
import json
import time
from pathlib import Path
import httpx

async def main():
    results=[]
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18761',timeout=50) as c:
        for model in ['deepseek-v4-flash','deepseek-v4-pro']:
            for mode in ['plain','json','stream']:
                payload={'model':model,'messages':[{'role':'user','content':'Return exactly {"ok":true} as JSON, no explanation.' if mode=='json' else 'Reply exactly OK. No explanation.'}],
                         'timeout_seconds':18,'deadline_seconds':22}
                if mode=='json':payload['response_format']={'type':'json_object'}
                if mode=='stream':payload['stream']=True
                start=time.perf_counter()
                entry={'model':model,'mode':mode,'payload':payload}
                try:
                    if mode!='stream':
                        response=await c.post('/v1/llm',json=payload)
                        entry.update(status=response.status_code,result=response.json())
                        if response.status_code==200 and mode=='json':
                            assert json.loads(response.json()['content'])=={'ok':True}
                    else:
                        events=[]
                        async with c.stream('POST','/v1/llm',json=payload) as response:
                            entry['status']=response.status_code
                            async for line in response.aiter_lines():
                                if line.startswith('data: '):events.append({'received_ms':round((time.perf_counter()-start)*1000,3),'event':json.loads(line[6:])})
                        entry['events']=events
                        assert response.status_code==200 and events[-1]['event']['type']=='response.completed'
                except Exception as e:
                    entry.update(check_error=type(e).__name__)
                entry['elapsed_ms']=round((time.perf_counter()-start)*1000,3)
                results.append(entry)
        traces=(await c.get('/v1/traces')).json()
    Path('/tmp/sunny-grade/live-results.json').write_text(json.dumps({'results':results,'traces':traces},ensure_ascii=False,indent=2))
    for r in results:
        print(r['model'],r['mode'],r.get('status'),r['elapsed_ms'],r.get('check_error',''))

asyncio.run(main())
