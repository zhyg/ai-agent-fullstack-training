"""Observe actual SSE without changing request/response content or student source."""
import os,sys,json,asyncio,time
from pathlib import Path
from contextlib import asynccontextmanager
os.environ.update(LLM_MODE='live',DEEPSEEK_BASE_URL='https://api.deepseek.com',RETRY_MAX_ATTEMPTS='0',PROMPTS_DIR='/tmp/grading-307/live-prompts')
sys.path.insert(0,'/tmp/grading-307/student/week1')
import httpx
from app.services.llm_service import get_llm_service
from app.models.schemas import ChatRequest
metadata=[]; original=httpx.AsyncClient.stream
@asynccontextmanager
async def observed(self,method,url,**kwargs):
    start=time.monotonic(); rec={'url':str(url),'alias':kwargs['json']['model'],'protocol':'Chat Completions','max_tokens':kwargs['json']['max_tokens']}; metadata.append(rec)
    async with original(self,method,url,**kwargs) as response:
        rec.update(status=response.status_code,request_id=response.headers.get('x-request-id'))
        lines=response.aiter_lines
        async def traced():
            async for line in lines():
                if line.startswith('data:') and line[5:].strip()!='[DONE]':
                    try:
                        data=json.loads(line[5:]); rec.update(upstream_id=data.get('id'),upstream_model=data.get('model'))
                        if data.get('usage'): rec['usage']=data['usage']
                        choice=(data.get('choices') or [{}])[0]; delta=choice.get('delta') or {}
                        for field in ['content','reasoning_content']:
                            if delta.get(field) and 'first_'+field+'_ms' not in rec: rec['first_'+field+'_ms']=round((time.monotonic()-start)*1000,2)
                        if choice.get('finish_reason'): rec['finish_reason']=choice['finish_reason']
                    except ValueError: pass
                yield line
        response.aiter_lines=traced
        yield response
    rec['elapsed_ms']=round((time.monotonic()-start)*1000,2)
httpx.AsyncClient.stream=observed
async def run(model):
    start=time.monotonic(); result={'alias':model,'events':[]}
    async def consume():
        async for event in get_llm_service().chat_stream(ChatRequest(model=model,stream=True,max_tokens=1024,messages=[{'role':'user','content':'Reply only OK.'}])):
            result['events'].append({'elapsed_ms':round((time.monotonic()-start)*1000,2),**event})
    try: await asyncio.wait_for(consume(),70)
    except Exception as exc: result.update(status='unverified',error_type=type(exc).__name__)
    return result
async def main():
    results=await asyncio.gather(run('deepseek-v4-pro'),run('deepseek-v4-flash'))
    Path(__file__).with_name('live-stream-results.json').write_text(json.dumps({'results':results,'upstream_metadata':metadata,'metrics':get_llm_service().obs.list_recent()},ensure_ascii=False,indent=2))
    print(json.dumps([{'model':r['alias'],'events':[e['event'] for e in r['events']]} for r in results]))
asyncio.run(main())
