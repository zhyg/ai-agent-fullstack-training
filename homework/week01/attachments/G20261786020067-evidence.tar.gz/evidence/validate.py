"""Validate delivered grading documents and credential-free evidence; never print secrets."""
import os,re,json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).parent
root=Path('/home/user/workspace/repo')
feedback=root/'homework/week01/G20261786020067.md'
report=root/'homework/week01/attachments/G20261786020067.md'
text=feedback.read_text(); detail=report.read_text()
scores=[int(x) for x in re.findall(r'^\| (?:统一接口与适配器|流式输出|结构化输出|提示词版本管理|可观测性|统一错误与重试|按模型独立限流|源码、README 与验证脚本) \| (\d+)/\d+ \|',detail,re.M)]
assert len(scores)==8 and sum(scores)==82 and '优秀（82分）' in text
sections={}
for number,next_number in [(2,3),(3,4),(4,None)]:
    part=text.split('**'+str(number)+'.',1)[1]
    if next_number: part=part.split('**'+str(next_number)+'.',1)[0]
    bullets=re.findall(r'^- (.+)$',part,re.M)
    assert 3<=len(bullets)<=5 and sum(len(b) for b in bullets)<=500
    assert '**\n\n-' in '**'+str(number)+'.'+part
    sections[str(number)]={'items':len(bullets),'characters':sum(len(b) for b in bullets)}
for label in ['A01','A02','A03','A04']+['F%02d'%i for i in range(1,13)]: assert label in detail
assert len(json.loads((p/'teacher-results.json').read_text()))==39
for line in (p/'source-sha256.txt').read_text().splitlines():
    digest,name=line.split('  ',1); assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest
tree={line.split('\t',1)[1]:line.split()[2] for line in (p/'git-tree.txt').read_text().splitlines()}
for name,blob in tree.items():
    data=(p/'source'/name).read_bytes(); assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
key=os.environ.get('DEEPSEEK_API_KEY','').encode()
assert key,'existing credential required for exact-match leak scan'
files=[f for f in p.rglob('*') if f.is_file()]+[feedback,report]
findings=[]
for f in files:
    data=f.read_bytes()
    if key in data: findings.append(str(f.relative_to(p)) if f.is_relative_to(p) else f.name)
    if re.search(rb'sk-[A-Za-z0-9_-]{20,}|Bearer [A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----',data): findings.append(f.name+' credential-like pattern')
    assert f.name!='.env' and '.git' not in f.parts
assert not findings, 'Sensitive findings (file names only): '+repr(findings)
summary={'scores':scores,'total':sum(scores),'grade':'优秀','acceptance':'未通过','sections':sections,'teacher_checks':39,'real_successful_calls':6,'source_sha256_and_git_blob_validation':'passed','exact_environment_key_scan':'passed','credential_pattern_scan':'passed','scanned_file_count':len(files),'uncommitted_deliverables':True}
(p/'checks.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
