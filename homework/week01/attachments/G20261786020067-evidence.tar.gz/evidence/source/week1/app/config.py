"""
全局配置

从环境变量 / .env 加载运行参数。
LLM_MODE=mock 时走内置模拟上游，适合无 Key 验收；
LLM_MODE=live 时按适配器协议真实调用上游。
"""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """应用配置项，字段名即环境变量名（大小写不敏感）。"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ---------- 服务监听 ----------
    host: str = "0.0.0.0"
    port: int = 8000

    # ---------- 上游调用模式 ----------
    # mock: 不访问外网，适配器内部模拟协议行为
    # live: 使用真实 HTTP 调用（需 API Key）
    llm_mode: str = "mock"

    # ---------- DeepSeek / 兼容上游 ----------
    deepseek_api_key: str = ""
    deepseek_base_url: str = "https://api.deepseek.com"

    # ---------- 限流（按模型独立配额，单位：次/分钟） ----------
    rate_limit_pro_per_minute: int = 30
    rate_limit_flash_per_minute: int = 60

    # ---------- 重试（指数退避） ----------
    retry_max_attempts: int = 3
    retry_base_delay_seconds: float = 0.5

    # ---------- Prompt 模板目录 ----------
    prompts_dir: str = "prompts"

    # ---------- 模型 → 适配器 映射 ----------
    # deepseek-v4-pro  → OpenAI Responses API 协议
    # deepseek-v4-flash → Anthropic Messages API 协议
    model_adapter_map: dict[str, str] = {
        "deepseek-v4-pro": "openai_responses",
        "deepseek-v4-flash": "anthropic_messages",
    }


@lru_cache
def get_settings() -> Settings:
    """进程内单例配置，避免重复解析环境变量。"""
    return Settings()
