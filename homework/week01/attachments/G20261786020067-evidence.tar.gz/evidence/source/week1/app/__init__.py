"""
LLM 统一模型调用服务（Week 1）

对外暴露统一 HTTP 接口，内部通过适配器模式屏蔽
OpenAI Responses API 与 Anthropic Messages API 的协议差异。
"""

__version__ = "1.0.0"
