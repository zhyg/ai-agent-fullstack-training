"""
按模型独立限流

使用滑动窗口（近 60 秒内请求计数）。
超额时抛出 AppError(RATE_LIMITED)，由路由层映射为 HTTP 429。
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from threading import Lock

from app.config import Settings, get_settings
from app.errors import AppError, ErrorCode


class PerModelRateLimiter:
    """
    每个 model 一把滑动窗口计数器。

    窗口长度固定 60 秒；限额来自配置：
    - deepseek-v4-pro   → rate_limit_pro_per_minute
    - deepseek-v4-flash → rate_limit_flash_per_minute
    """

    WINDOW_SECONDS = 60.0

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()
        # 模型 → 每分钟配额
        self._limits: dict[str, int] = {
            "deepseek-v4-pro": self.settings.rate_limit_pro_per_minute,
            "deepseek-v4-flash": self.settings.rate_limit_flash_per_minute,
        }

    def set_limit(self, model: str, per_minute: int) -> None:
        """运行时调整限额（验收脚本会临时调低以触发 429）。"""
        with self._lock:
            self._limits[model] = per_minute
            # 清空该模型历史，避免旧窗口干扰新限额测试
            self._hits[model].clear()

    def get_limit(self, model: str) -> int:
        return self._limits.get(model, 60)

    def check(self, model: str) -> None:
        """
        通过则记录一次命中；超额抛 RATE_LIMITED。

        注意：在真正调用上游之前检查，避免浪费配额外的上游调用。
        """
        now = time.monotonic()
        limit = self.get_limit(model)
        with self._lock:
            q = self._hits[model]
            # 丢弃窗口外的旧记录
            while q and now - q[0] > self.WINDOW_SECONDS:
                q.popleft()
            if len(q) >= limit:
                raise AppError(
                    ErrorCode.RATE_LIMITED,
                    message=f"模型 {model} 触发限流",
                    details={
                        "model": model,
                        "limit_per_minute": limit,
                        "retry_after_seconds": max(
                            1, int(self.WINDOW_SECONDS - (now - q[0]))
                        ),
                    },
                    http_status=429,
                )
            q.append(now)

    def reset(self, model: str | None = None) -> None:
        """清空计数（测试用）。"""
        with self._lock:
            if model is None:
                self._hits.clear()
            else:
                self._hits[model].clear()


_limiter: PerModelRateLimiter | None = None


def get_rate_limiter() -> PerModelRateLimiter:
    global _limiter
    if _limiter is None:
        _limiter = PerModelRateLimiter()
    return _limiter
