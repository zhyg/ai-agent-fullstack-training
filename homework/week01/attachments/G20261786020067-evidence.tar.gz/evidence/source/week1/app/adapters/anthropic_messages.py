"""
Anthropic Messages API 协议适配器

映射模型：deepseek-v4-flash

协议要点（相对 OpenAI 的差异）：
- Header 使用 x-api-key + anthropic-version，而非 Bearer
- system 是顶层字段，不放在 messages 里
- max_tokens 必填；流式事件为 content_block_delta
- 结构化输出：通过 system 提示 + 校验保证 JSON（Messages API 无原生 json_object）

mock 模式完整模拟上述协议；live 模式映射到兼容 Chat Completions。
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx

from app.adapters.base import AdapterResult, BaseAdapter, StreamChunk
from app.config import Settings
from app.errors import AppError, ErrorCode
from app.models.schemas import Message, ResponseFormat, TokenUsage


class AnthropicMessagesAdapter(BaseAdapter):
    """DeepSeek V4 flash → Anthropic Messages API。"""

    name = "anthropic_messages"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._pending_failures = 0

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    async def invoke(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        force_failures: int | None = None,
    ) -> AdapterResult:
        self._arm_force_failures(force_failures)
        payload = self._build_request(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format=response_format,
            stream=False,
        )

        if self.settings.llm_mode == "mock":
            raw = await self._mock_call(payload)
        else:
            raw = await self._live_call(payload)

        return self._parse_response(raw, messages, response_format)

    async def stream_invoke(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        force_failures: int | None = None,
    ) -> AsyncIterator[StreamChunk]:
        self._arm_force_failures(force_failures)
        payload = self._build_request(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format=response_format,
            stream=True,
        )

        if self.settings.llm_mode == "mock":
            async for chunk in self._mock_stream(payload):
                yield chunk
        else:
            async for chunk in self._live_stream(payload):
                yield chunk

    # ------------------------------------------------------------------
    # 协议翻译：统一 Schema → Anthropic Messages 请求体
    # ------------------------------------------------------------------

    def _build_request(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        stream: bool,
    ) -> dict[str, Any]:
        """
        Anthropic Messages 典型形状：
        {
          "model": "...",
          "system": "...",          # 顶层，不在 messages 内
          "messages": [{"role": "user"|"assistant", "content": "..."}],
          "max_tokens": 1024,       # 必填
          "temperature": 0.7,
          "stream": false
        }
        """
        system_parts: list[str] = []
        anth_messages: list[dict[str, str]] = []

        for msg in messages:
            if msg.role == "system":
                system_parts.append(msg.content)
            else:
                # Anthropic 仅允许 user / assistant
                role = "assistant" if msg.role == "assistant" else "user"
                anth_messages.append({"role": role, "content": msg.content})

        # 结构化输出：用 system 指令约束（Messages 无原生 response_format）
        if response_format and response_format.type == "json_object":
            system_parts.append(
                "You must respond with a single valid JSON object only. "
                "Do not wrap it in markdown fences."
            )

        if not anth_messages:
            anth_messages = [{"role": "user", "content": ""}]

        body: dict[str, Any] = {
            "model": model,
            "messages": anth_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": stream,
        }
        if system_parts:
            body["system"] = "\n".join(system_parts)
        return body

    def _auth_headers(self) -> dict[str, str]:
        """
        Anthropic 鉴权与 OpenAI Bearer 完全不同：
        - x-api-key: <key>
        - anthropic-version: 2023-06-01
        """
        return {
            "x-api-key": self.settings.deepseek_api_key or "mock-key",
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

    # ------------------------------------------------------------------
    # 响应解析
    # ------------------------------------------------------------------

    def _parse_response(
        self,
        raw: dict[str, Any],
        messages: list[Message],
        response_format: ResponseFormat | None,
    ) -> AdapterResult:
        content = self._extract_text(raw)
        if response_format and response_format.type == "json_object":
            content = self._ensure_json(content)

        usage_raw = raw.get("usage") or {}
        usage = TokenUsage(
            prompt_tokens=int(usage_raw.get("input_tokens", 0)),
            completion_tokens=int(usage_raw.get("output_tokens", 0)),
            total_tokens=int(
                usage_raw.get("input_tokens", 0) + usage_raw.get("output_tokens", 0)
            ),
        )
        if usage.total_tokens == 0:
            prompt_text = " ".join(m.content for m in messages)
            usage = TokenUsage(
                prompt_tokens=self.estimate_tokens(prompt_text),
                completion_tokens=self.estimate_tokens(content),
                total_tokens=self.estimate_tokens(prompt_text) + self.estimate_tokens(content),
            )

        return AdapterResult(
            content=content,
            finish_reason=raw.get("stop_reason", "end_turn"),
            usage=usage,
            raw=raw,
        )

    @staticmethod
    def _extract_text(raw: dict[str, Any]) -> str:
        """从 content 块数组提取文本。"""
        parts: list[str] = []
        for block in raw.get("content") or []:
            if block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "".join(parts)

    @staticmethod
    def _ensure_json(content: str) -> str:
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError as exc:
            raise AppError(
                ErrorCode.STRUCTURED_OUTPUT_INVALID,
                message="结构化输出不是合法 JSON",
                details={"content": content, "reason": str(exc)},
            ) from exc
        return json.dumps(parsed, ensure_ascii=False)

    # ------------------------------------------------------------------
    # Mock / Live
    # ------------------------------------------------------------------

    def _arm_force_failures(self, n: int | None) -> None:
        """n 为 None 表示重试中，不重置计数；为 int 则覆盖（含 0）。"""
        if n is not None:
            self._pending_failures = n

    def _maybe_fail(self) -> None:
        if self._pending_failures > 0:
            self._pending_failures -= 1
            raise AppError(
                ErrorCode.UPSTREAM_ERROR,
                message="模拟上游瞬时故障（Anthropic Messages）",
                details={"adapter": self.name, "remaining": self._pending_failures},
            )

    async def _mock_call(self, payload: dict[str, Any]) -> dict[str, Any]:
        self._maybe_fail()
        await asyncio.sleep(0.02)

        user_text = ""
        for item in payload.get("messages") or []:
            if item.get("role") == "user":
                user_text = item.get("content", "")

        want_json = "JSON object" in (payload.get("system") or "")
        if want_json:
            content = json.dumps(
                {
                    "protocol": "anthropic_messages",
                    "model": payload.get("model"),
                    "echo": user_text[:200],
                    "ok": True,
                },
                ensure_ascii=False,
            )
        else:
            content = (
                f"[anthropic_messages/{payload.get('model')}] "
                f"已处理: {user_text[:200] or '(empty)'}"
            )

        prompt_tokens = self.estimate_tokens(
            (payload.get("system") or "")
            + json.dumps(payload.get("messages"), ensure_ascii=False)
        )
        completion_tokens = self.estimate_tokens(content)
        return {
            "id": f"msg_{uuid.uuid4().hex[:12]}",
            "type": "message",
            "role": "assistant",
            "model": payload.get("model"),
            "content": [{"type": "text", "text": content}],
            "stop_reason": "end_turn",
            "usage": {
                "input_tokens": prompt_tokens,
                "output_tokens": completion_tokens,
            },
        }

    async def _mock_stream(self, payload: dict[str, Any]) -> AsyncIterator[StreamChunk]:
        result = await self._mock_call(payload)
        text = self._extract_text(result)
        step = 8
        for i in range(0, len(text), step):
            await asyncio.sleep(0.01)
            # 对应 Anthropic content_block_delta 事件中的 text
            yield StreamChunk(delta=text[i : i + step])
        usage = TokenUsage(
            prompt_tokens=result["usage"]["input_tokens"],
            completion_tokens=result["usage"]["output_tokens"],
            total_tokens=result["usage"]["input_tokens"] + result["usage"]["output_tokens"],
        )
        yield StreamChunk(delta="", finish_reason="end_turn", usage=usage)

    async def _live_call(self, payload: dict[str, Any]) -> dict[str, Any]:
        """
        live：将 Messages 形状映射到 Chat Completions 兼容端点。
        鉴权 Header 在适配器内仍按 Anthropic 方式组装（演示差异），
        发往 DeepSeek 时再换成 Bearer。
        """
        self._maybe_fail()
        _ = self._auth_headers()  # 演示 Anthropic 鉴权组装，live 实际用 Bearer

        chat_body = self._messages_to_chat_completions(payload)
        headers = {
            "Authorization": f"Bearer {self.settings.deepseek_api_key}",
            "Content-Type": "application/json",
        }
        url = f"{self.settings.deepseek_base_url.rstrip('/')}/v1/chat/completions"
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post(url, headers=headers, json=chat_body)
        except httpx.TimeoutException as exc:
            raise AppError(ErrorCode.UPSTREAM_TIMEOUT, "上游超时") from exc
        except httpx.HTTPError as exc:
            raise AppError(ErrorCode.UPSTREAM_ERROR, f"上游网络错误: {exc}") from exc

        if resp.status_code >= 400:
            raise AppError(
                ErrorCode.UPSTREAM_ERROR,
                message="上游返回错误",
                details={"status": resp.status_code, "body": resp.text[:500]},
            )

        data = resp.json()
        choice = (data.get("choices") or [{}])[0]
        content = (choice.get("message") or {}).get("content", "")
        usage = data.get("usage") or {}
        return {
            "id": data.get("id", f"msg_{uuid.uuid4().hex[:8]}"),
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": content}],
            "stop_reason": choice.get("finish_reason") or "end_turn",
            "usage": {
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": usage.get("completion_tokens", 0),
            },
        }

    async def _live_stream(self, payload: dict[str, Any]) -> AsyncIterator[StreamChunk]:
        self._maybe_fail()
        chat_body = self._messages_to_chat_completions(payload)
        chat_body["stream"] = True
        headers = {
            "Authorization": f"Bearer {self.settings.deepseek_api_key}",
            "Content-Type": "application/json",
        }
        url = f"{self.settings.deepseek_base_url.rstrip('/')}/v1/chat/completions"
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                async with client.stream("POST", url, headers=headers, json=chat_body) as resp:
                    if resp.status_code >= 400:
                        body = await resp.aread()
                        raise AppError(
                            ErrorCode.UPSTREAM_ERROR,
                            message="上游流式返回错误",
                            details={"status": resp.status_code, "body": body.decode()[:500]},
                        )
                    async for line in resp.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        event = json.loads(data)
                        delta = ((event.get("choices") or [{}])[0].get("delta") or {}).get(
                            "content"
                        ) or ""
                        if delta:
                            yield StreamChunk(delta=delta)
                        finish = (event.get("choices") or [{}])[0].get("finish_reason")
                        if finish:
                            yield StreamChunk(delta="", finish_reason=finish)
        except httpx.TimeoutException as exc:
            raise AppError(ErrorCode.UPSTREAM_TIMEOUT, "上游流式超时") from exc

    @staticmethod
    def _messages_to_chat_completions(payload: dict[str, Any]) -> dict[str, Any]:
        """Anthropic Messages → Chat Completions。"""
        messages: list[dict[str, str]] = []
        if payload.get("system"):
            messages.append({"role": "system", "content": payload["system"]})
        for item in payload.get("messages") or []:
            messages.append({"role": item["role"], "content": item["content"]})

        body: dict[str, Any] = {
            "model": payload["model"],
            "messages": messages,
            "temperature": payload.get("temperature", 0.7),
            "max_tokens": payload.get("max_tokens", 1024),
            "stream": payload.get("stream", False),
        }
        if "JSON object" in (payload.get("system") or ""):
            body["response_format"] = {"type": "json_object"}
        return body
