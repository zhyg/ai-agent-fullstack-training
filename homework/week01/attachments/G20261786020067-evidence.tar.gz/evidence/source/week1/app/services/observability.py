"""
可观测性：Token 消耗 + 延迟（含首 Token 延迟）

每次调用结束后写入内存环形缓冲，便于 /v1/metrics 查询与验收。
生产环境可替换为 Prometheus / OpenTelemetry 导出。
"""

from __future__ import annotations

import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass, field
from threading import Lock
from typing import Any

from app.models.schemas import Observability, TokenUsage


@dataclass
class CallRecord:
    """单次调用观测记录。"""

    call_id: str
    model: str
    adapter: str
    stream: bool
    usage: dict[str, int]
    latency_ms: float
    first_token_latency_ms: float | None
    retries: int
    success: bool
    error_code: str | None = None
    created_at: float = field(default_factory=time.time)


class ObservabilityStore:
    """进程内观测存储（环形，默认保留最近 500 条）。"""

    def __init__(self, capacity: int = 500) -> None:
        self._records: deque[CallRecord] = deque(maxlen=capacity)
        self._lock = Lock()

    def record(self, rec: CallRecord) -> None:
        with self._lock:
            self._records.appendleft(rec)

    def list_recent(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._lock:
            return [asdict(r) for r in list(self._records)[:limit]]

    def clear(self) -> None:
        with self._lock:
            self._records.clear()


class CallTimer:
    """
    调用计时器。

    - mark_first_token(): 流式首包到达时调用
    - finish(): 返回 Observability 所需的延迟字段
    """

    def __init__(self) -> None:
        self.started = time.perf_counter()
        self.first_token_at: float | None = None

    def mark_first_token(self) -> None:
        if self.first_token_at is None:
            self.first_token_at = time.perf_counter()

    def latency_ms(self) -> float:
        return (time.perf_counter() - self.started) * 1000

    def first_token_latency_ms(self) -> float | None:
        if self.first_token_at is None:
            return None
        return (self.first_token_at - self.started) * 1000

    def to_observability(
        self,
        *,
        model: str,
        adapter: str,
        usage: TokenUsage,
        retries: int,
        # 非流式场景：首 Token 延迟近似等于总延迟
        treat_total_as_first_token: bool = False,
    ) -> Observability:
        ft = self.first_token_latency_ms()
        total = self.latency_ms()
        if treat_total_as_first_token and ft is None:
            ft = total
        return Observability(
            latency_ms=round(total, 2),
            first_token_latency_ms=round(ft, 2) if ft is not None else None,
            usage=usage,
            adapter=adapter,
            retries=retries,
            model=model,
        )


def new_call_id() -> str:
    return f"call_{uuid.uuid4().hex[:16]}"


_store: ObservabilityStore | None = None


def get_observability_store() -> ObservabilityStore:
    global _store
    if _store is None:
        _store = ObservabilityStore()
    return _store
