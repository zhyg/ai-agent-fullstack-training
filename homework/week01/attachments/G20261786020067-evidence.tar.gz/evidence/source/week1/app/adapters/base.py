"""
适配器抽象基类（Adapter Pattern 的 Target 接口）

所有协议适配器必须实现 invoke / stream_invoke，
使上层 LLMService 无需关心 OpenAI / Anthropic 差异。
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

from app.models.schemas import Message, ResponseFormat, TokenUsage


@dataclass
class StreamChunk:
    """流式输出的单个分片。"""

    delta: str  # 增量文本
    finish_reason: str | None = None
    usage: TokenUsage | None = None  # 通常在最后一个 chunk 携带


@dataclass
class AdapterResult:
    """非流式调用的统一结果。"""

    content: str
    finish_reason: str = "stop"
    usage: TokenUsage = field(default_factory=TokenUsage)
    raw: dict | None = None  # 原始上游响应，便于调试


class BaseAdapter(ABC):
    """
    协议适配器基类。

    子类职责：
    1. 将统一 messages / 参数 翻译成目标协议请求体
    2. 处理鉴权 Header 差异
    3. 将上游响应翻译回 AdapterResult / StreamChunk
    """

    name: str = "base"

    @abstractmethod
    async def invoke(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        force_failures: int | None = None,
    ) -> AdapterResult:
        """同步语义的一次完整调用（非 SSE）。"""

    @abstractmethod
    async def stream_invoke(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        force_failures: int | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """流式调用，逐块产出 StreamChunk。"""
        # 作为 async generator 的抽象声明占位
        if False:  # pragma: no cover
            yield StreamChunk(delta="")

    def estimate_tokens(self, text: str) -> int:
        """
        粗略 Token 估算（mock / 缺 usage 时兜底）。

        中英文混排场景用「字符数 / 2」近似，仅用于演示可观测性。
        """
        if not text:
            return 0
        return max(1, len(text) // 2)
