"""
Prompt 版本管理

能力：
1. 模板存储（文件系统 prompts/ 目录，文件名 name.version.txt）
2. 变量替换（{{var}} → 实际值）
3. 版本引用（prompt_ref = name 或 name@version；省略版本取最新）
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from app.config import Settings, get_settings
from app.errors import AppError, ErrorCode
from app.models.schemas import PromptCreateRequest, PromptInfo

# 匹配 {{ variable_name }} 占位符
_VAR_PATTERN = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}")


class PromptManager:
    """基于本地文件的 Prompt 仓库。"""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.root = Path(self.settings.prompts_dir)
        self.root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # 存储
    # ------------------------------------------------------------------

    def save(self, req: PromptCreateRequest) -> PromptInfo:
        """写入 / 覆盖一个版本。"""
        path = self._path(req.name, req.version)
        # 可选：同目录下放 .meta 描述（简化起见描述写在首行注释约定，这里用 sidecar）
        path.write_text(req.content, encoding="utf-8")
        meta = path.with_suffix(path.suffix + ".meta")
        meta.write_text(req.description or "", encoding="utf-8")
        return PromptInfo(
            name=req.name,
            version=req.version,
            content=req.content,
            description=req.description or "",
            ref=f"{req.name}@{req.version}",
        )

    def get(self, name: str, version: str | None = None) -> PromptInfo:
        """读取指定版本；version 为空则取「最新」（按版本名字典序最大）。"""
        if version:
            path = self._path(name, version)
            if not path.exists():
                raise AppError(
                    ErrorCode.PROMPT_NOT_FOUND,
                    message=f"Prompt 不存在: {name}@{version}",
                )
            desc = self._read_meta(path)
            return PromptInfo(
                name=name,
                version=version,
                content=path.read_text(encoding="utf-8"),
                description=desc,
                ref=f"{name}@{version}",
            )

        versions = self.list_versions(name)
        if not versions:
            raise AppError(
                ErrorCode.PROMPT_NOT_FOUND,
                message=f"Prompt 不存在: {name}",
            )
        latest = sorted(versions)[-1]
        return self.get(name, latest)

    def list_all(self) -> list[PromptInfo]:
        """列出仓库内全部模板版本。"""
        items: list[PromptInfo] = []
        for path in sorted(self.root.glob("*.*.txt")):
            # 文件名约定：{name}.{version}.txt ，version 可含点，这里取最后一段前为 version
            # 简化：name.v1.txt / name.v2.txt
            stem_parts = path.name[: -len(".txt")].rsplit(".", 1)
            if len(stem_parts) != 2:
                continue
            name, version = stem_parts
            items.append(
                PromptInfo(
                    name=name,
                    version=version,
                    content=path.read_text(encoding="utf-8"),
                    description=self._read_meta(path),
                    ref=f"{name}@{version}",
                )
            )
        return items

    def list_versions(self, name: str) -> list[str]:
        """某模板的全部版本号。"""
        versions: list[str] = []
        for path in self.root.glob(f"{name}.*.txt"):
            if path.name.endswith(".txt.meta"):
                continue
            # greeting.v1.txt → v1
            rest = path.name[len(name) + 1 : -len(".txt")]
            if rest and not path.name.endswith(".meta"):
                versions.append(rest)
        # 过滤误匹配到的 .txt.meta 已由 glob 排除；再排除空
        return [v for v in versions if v and not v.endswith(".txt")]

    # ------------------------------------------------------------------
    # 引用解析 + 变量替换
    # ------------------------------------------------------------------

    def resolve_ref(self, prompt_ref: str) -> PromptInfo:
        """
        解析 prompt_ref。

        支持：
        - greeting        → 最新版本
        - greeting@v2     → 指定版本
        """
        if "@" in prompt_ref:
            name, version = prompt_ref.split("@", 1)
            return self.get(name.strip(), version.strip())
        return self.get(prompt_ref.strip(), None)

    def render(self, prompt_ref: str, variables: dict[str, Any] | None = None) -> str:
        """
        拉取模板并做 {{var}} 替换。

        未提供的变量保留原占位符，避免静默吞错；也可按需改为抛错。
        """
        info = self.resolve_ref(prompt_ref)
        variables = variables or {}

        def _repl(match: re.Match[str]) -> str:
            key = match.group(1)
            if key not in variables:
                return match.group(0)  # 保留 {{key}}
            return str(variables[key])

        return _VAR_PATTERN.sub(_repl, info.content)

    # ------------------------------------------------------------------
    # 内部工具
    # ------------------------------------------------------------------

    def _path(self, name: str, version: str) -> Path:
        # 简单清洗，防止路径穿越
        safe_name = name.replace("/", "_").replace("\\", "_").replace("..", "_")
        safe_version = version.replace("/", "_").replace("\\", "_").replace("..", "_")
        return self.root / f"{safe_name}.{safe_version}.txt"

    @staticmethod
    def _read_meta(path: Path) -> str:
        meta = path.with_suffix(path.suffix + ".meta")
        if meta.exists():
            return meta.read_text(encoding="utf-8")
        return ""


_prompt_manager: PromptManager | None = None


def get_prompt_manager() -> PromptManager:
    """惰性单例。"""
    global _prompt_manager
    if _prompt_manager is None:
        _prompt_manager = PromptManager()
    return _prompt_manager
