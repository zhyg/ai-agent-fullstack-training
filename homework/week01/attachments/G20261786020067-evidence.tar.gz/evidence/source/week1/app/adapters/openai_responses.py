"""
OpenAI Responses API 协议适配器

映射模型：deepseek-v4-pro

协议要点（相对 Chat Completions 的差异）：
- 入口字段使用 input（而非 messages）
- 结构化输出通过 text.format 声明
- 流式事件类型为 response.output_text.delta 等

本适配器在 mock 模式下完整模拟上述协议形状；
live 模式下将统一请求翻译后发往兼容端点。
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx

from app.adapters.base import AdapterResult, BaseAdapter, StreamChunk
from app.config import Settings
from app.errors import AppError, ErrorCode
from app.models.schemas import Message, ResponseFormat, TokenUsage


class OpenAIResponsesAdapter(BaseAdapter):
    """DeepSeek v4 pro → OpenAI Responses API。"""

    name = "openai_responses"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        # 测试钩子：剩余强制失败次数（进程内按适配器实例计数）
        self._pending_failures = 0

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    async def invoke(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        force_failures: int | None = None,
    ) -> AdapterResult:
        """非流式：构造 Responses 请求体 → 调用/模拟 → 解析输出。"""
        self._arm_force_failures(force_failures)
        payload = self._build_request(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format=response_format,
            stream=False,
        )

        if self.settings.llm_mode == "mock":
            raw = await self._mock_call(payload, stream=False)
        else:
            raw = await self._live_call(payload, stream=False)

        return self._parse_response(raw, messages, response_format)

    async def stream_invoke(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        force_failures: int | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """流式：产出模拟 / 真实的 Responses SSE 事件并转为 StreamChunk。"""
        self._arm_force_failures(force_failures)
        payload = self._build_request(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format=response_format,
            stream=True,
        )

        if self.settings.llm_mode == "mock":
            async for chunk in self._mock_stream(payload, messages, response_format):
                yield chunk
        else:
            async for chunk in self._live_stream(payload):
                yield chunk

    # ------------------------------------------------------------------
    # 协议翻译：统一 Schema → OpenAI Responses 请求体
    # ------------------------------------------------------------------

    def _build_request(
        self,
        *,
        model: str,
        messages: list[Message],
        temperature: float,
        max_tokens: int,
        response_format: ResponseFormat | None,
        stream: bool,
    ) -> dict[str, Any]:
        """
        将统一 messages 转为 Responses API 的 input 数组。

        OpenAI Responses 典型形状：
        {
          "model": "...",
          "input": [{"role": "user", "content": "..."}, ...],
          "temperature": 0.7,
          "max_output_tokens": 1024,
          "stream": false,
          "text": {"format": {"type": "json_object"}}  # 可选
        }
        """
        # system 消息合并进 instructions，其余进入 input
        instructions_parts: list[str] = []
        input_items: list[dict[str, str]] = []
        for msg in messages:
            if msg.role == "system":
                instructions_parts.append(msg.content)
            else:
                input_items.append({"role": msg.role, "content": msg.content})

        body: dict[str, Any] = {
            "model": model,
            "input": input_items or [{"role": "user", "content": ""}],
            "temperature": temperature,
            "max_output_tokens": max_tokens,
            "stream": stream,
        }
        if instructions_parts:
            body["instructions"] = "\n".join(instructions_parts)

        # 结构化输出：Responses 用 text.format，而非 response_format
        if response_format and response_format.type == "json_object":
            body["text"] = {"format": {"type": "json_object"}}

        return body

    # ------------------------------------------------------------------
    # 响应解析：OpenAI Responses → AdapterResult
    # ------------------------------------------------------------------

    def _parse_response(
        self,
        raw: dict[str, Any],
        messages: list[Message],
        response_format: ResponseFormat | None,
    ) -> AdapterResult:
        """从 Responses 风格 JSON 提取文本与 usage。"""
        content = self._extract_output_text(raw)
        if response_format and response_format.type == "json_object":
            content = self._ensure_json(content)

        usage_raw = raw.get("usage") or {}
        usage = TokenUsage(
            prompt_tokens=int(usage_raw.get("input_tokens", 0)),
            completion_tokens=int(usage_raw.get("output_tokens", 0)),
            total_tokens=int(
                usage_raw.get(
                    "total_tokens",
                    usage_raw.get("input_tokens", 0) + usage_raw.get("output_tokens", 0),
                )
            ),
        )
        # 缺 usage 时用估算兜底，保证可观测性字段始终有值
        if usage.total_tokens == 0:
            prompt_text = " ".join(m.content for m in messages)
            usage = TokenUsage(
                prompt_tokens=self.estimate_tokens(prompt_text),
                completion_tokens=self.estimate_tokens(content),
                total_tokens=self.estimate_tokens(prompt_text) + self.estimate_tokens(content),
            )

        return AdapterResult(
            content=content,
            finish_reason=raw.get("status", "completed"),
            usage=usage,
            raw=raw,
        )

    @staticmethod
    def _extract_output_text(raw: dict[str, Any]) -> str:
        """兼容 output_text 直出与 output[].content[].text 两种形态。"""
        if isinstance(raw.get("output_text"), str):
            return raw["output_text"]

        parts: list[str] = []
        for item in raw.get("output") or []:
            for block in item.get("content") or []:
                if block.get("type") in ("output_text", "text") and "text" in block:
                    parts.append(block["text"])
        return "".join(parts)

    @staticmethod
    def _ensure_json(content: str) -> str:
        """校验并规范化 JSON 字符串；非法则抛统一错误码。"""
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError as exc:
            raise AppError(
                ErrorCode.STRUCTURED_OUTPUT_INVALID,
                message="结构化输出不是合法 JSON",
                details={"content": content, "reason": str(exc)},
            ) from exc
        return json.dumps(parsed, ensure_ascii=False)

    # ------------------------------------------------------------------
    # Mock / Live 上游
    # ------------------------------------------------------------------

    def _arm_force_failures(self, n: int | None) -> None:
        """
        设置「接下来 N 次调用强制失败」，供重试验收使用。

        - n 为 int：覆盖计数（含 0，用于新请求清空残留）
        - n 为 None：重试过程中不改动计数
        """
        if n is not None:
            self._pending_failures = n

    def _maybe_fail(self) -> None:
        """若仍有强制失败配额，则抛出可重试的上游错误。"""
        if self._pending_failures > 0:
            self._pending_failures -= 1
            raise AppError(
                ErrorCode.UPSTREAM_ERROR,
                message="模拟上游瞬时故障（OpenAI Responses）",
                details={"adapter": self.name, "remaining": self._pending_failures},
            )

    async def _mock_call(self, payload: dict[str, Any], stream: bool) -> dict[str, Any]:
        """模拟一次完整 Responses 调用。"""
        del stream  # 非流式路径不使用
        self._maybe_fail()
        await asyncio.sleep(0.02)  # 模拟网络延迟，便于观测 latency

        user_text = ""
        for item in payload.get("input") or []:
            if item.get("role") == "user":
                user_text = item.get("content", "")

        want_json = (
            isinstance(payload.get("text"), dict)
            and payload["text"].get("format", {}).get("type") == "json_object"
        )
        if want_json:
            content = json.dumps(
                {
                    "protocol": "openai_responses",
                    "model": payload.get("model"),
                    "echo": user_text[:200],
                    "ok": True,
                },
                ensure_ascii=False,
            )
        else:
            content = (
                f"[openai_responses/{payload.get('model')}] "
                f"已处理: {user_text[:200] or '(empty)'}"
            )

        prompt_tokens = self.estimate_tokens(json.dumps(payload.get("input"), ensure_ascii=False))
        completion_tokens = self.estimate_tokens(content)
        return {
            "id": f"resp_{uuid.uuid4().hex[:12]}",
            "object": "response",
            "status": "completed",
            "output_text": content,
            "output": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": content}],
                }
            ],
            "usage": {
                "input_tokens": prompt_tokens,
                "output_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            },
        }

    async def _mock_stream(
        self,
        payload: dict[str, Any],
        messages: list[Message],
        response_format: ResponseFormat | None,
    ) -> AsyncIterator[StreamChunk]:
        """模拟 Responses 流式事件，按字符块切分。"""
        result = await self._mock_call(payload, stream=True)
        text = result["output_text"]
        # 按约 8 字符一块，演示 SSE 分块
        step = 8
        for i in range(0, len(text), step):
            await asyncio.sleep(0.01)
            yield StreamChunk(delta=text[i : i + step])
        usage = TokenUsage(
            prompt_tokens=result["usage"]["input_tokens"],
            completion_tokens=result["usage"]["output_tokens"],
            total_tokens=result["usage"]["total_tokens"],
        )
        yield StreamChunk(delta="", finish_reason="stop", usage=usage)

    async def _live_call(self, payload: dict[str, Any], stream: bool) -> dict[str, Any]:
        """
        真实 HTTP 调用。

        说明：DeepSeek 当前主流为 Chat Completions 兼容接口。
        live 模式下将 Responses 形状再映射到 /v1/chat/completions，
        同时保留适配器内部的 Responses 协议翻译逻辑（作业核心）。
        """
        del stream
        self._maybe_fail()
        chat_body = self._responses_to_chat_completions(payload)
        headers = {
            "Authorization": f"Bearer {self.settings.deepseek_api_key}",
            "Content-Type": "application/json",
        }
        url = f"{self.settings.deepseek_base_url.rstrip('/')}/v1/chat/completions"
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post(url, headers=headers, json=chat_body)
        except httpx.TimeoutException as exc:
            raise AppError(ErrorCode.UPSTREAM_TIMEOUT, "上游超时") from exc
        except httpx.HTTPError as exc:
            raise AppError(ErrorCode.UPSTREAM_ERROR, f"上游网络错误: {exc}") from exc

        if resp.status_code >= 400:
            raise AppError(
                ErrorCode.UPSTREAM_ERROR,
                message="上游返回错误",
                details={"status": resp.status_code, "body": resp.text[:500]},
            )

        data = resp.json()
        # 将 Chat Completions 响应回填为 Responses 形状，再走统一解析
        choice = (data.get("choices") or [{}])[0]
        content = (choice.get("message") or {}).get("content", "")
        usage = data.get("usage") or {}
        return {
            "id": data.get("id", f"resp_{uuid.uuid4().hex[:8]}"),
            "object": "response",
            "status": "completed",
            "output_text": content,
            "usage": {
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": usage.get("completion_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0),
            },
        }

    async def _live_stream(self, payload: dict[str, Any]) -> AsyncIterator[StreamChunk]:
        """live 流式：读取 Chat Completions SSE 并转为 StreamChunk。"""
        self._maybe_fail()
        chat_body = self._responses_to_chat_completions(payload)
        chat_body["stream"] = True
        headers = {
            "Authorization": f"Bearer {self.settings.deepseek_api_key}",
            "Content-Type": "application/json",
        }
        url = f"{self.settings.deepseek_base_url.rstrip('/')}/v1/chat/completions"
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                async with client.stream("POST", url, headers=headers, json=chat_body) as resp:
                    if resp.status_code >= 400:
                        body = await resp.aread()
                        raise AppError(
                            ErrorCode.UPSTREAM_ERROR,
                            message="上游流式返回错误",
                            details={"status": resp.status_code, "body": body.decode()[:500]},
                        )
                    async for line in resp.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        event = json.loads(data)
                        delta = ((event.get("choices") or [{}])[0].get("delta") or {}).get(
                            "content"
                        ) or ""
                        if delta:
                            yield StreamChunk(delta=delta)
                        finish = (event.get("choices") or [{}])[0].get("finish_reason")
                        if finish:
                            yield StreamChunk(delta="", finish_reason=finish)
        except httpx.TimeoutException as exc:
            raise AppError(ErrorCode.UPSTREAM_TIMEOUT, "上游流式超时") from exc

    @staticmethod
    def _responses_to_chat_completions(payload: dict[str, Any]) -> dict[str, Any]:
        """Responses 请求体 → Chat Completions（live 兼容层）。"""
        messages: list[dict[str, str]] = []
        if payload.get("instructions"):
            messages.append({"role": "system", "content": payload["instructions"]})
        for item in payload.get("input") or []:
            messages.append({"role": item["role"], "content": item["content"]})

        body: dict[str, Any] = {
            "model": payload["model"],
            "messages": messages,
            "temperature": payload.get("temperature", 0.7),
            "max_tokens": payload.get("max_output_tokens", 1024),
            "stream": payload.get("stream", False),
        }
        # Chat Completions 用 response_format 表达 JSON 约束
        text_fmt = (payload.get("text") or {}).get("format") or {}
        if text_fmt.get("type") == "json_object":
            body["response_format"] = {"type": "json_object"}
        return body
