"""
LLM 统一调用编排

流程：
1. 限流检查（按 model）
2. Prompt 引用渲染（若有）
3. 按 model 解析适配器
4. 指数退避包装上游调用
5. 记录可观测数据
6. 返回统一响应 / SSE 事件流
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from typing import Any

from app.adapters.base import BaseAdapter, StreamChunk
from app.adapters.registry import AdapterRegistry, get_registry
from app.config import get_settings
from app.errors import AppError, ErrorCode
from app.models.schemas import ChatRequest, ChatResponse, Message, Observability, TokenUsage
from app.services.observability import (
    CallRecord,
    CallTimer,
    get_observability_store,
    new_call_id,
)
from app.services.prompt_manager import PromptManager, get_prompt_manager
from app.services.rate_limiter import PerModelRateLimiter, get_rate_limiter
from app.services.retry import with_exponential_backoff

_RETRYABLE = {ErrorCode.UPSTREAM_ERROR, ErrorCode.UPSTREAM_TIMEOUT}


class LLMService:
    """对外统一调用入口（Facade + 适配器路由）。"""

    def __init__(
        self,
        registry: AdapterRegistry | None = None,
        prompts: PromptManager | None = None,
        limiter: PerModelRateLimiter | None = None,
    ) -> None:
        self.registry = registry or get_registry()
        self.prompts = prompts or get_prompt_manager()
        self.limiter = limiter or get_rate_limiter()
        self.obs = get_observability_store()

    # ------------------------------------------------------------------
    # 非流式
    # ------------------------------------------------------------------

    async def chat(self, req: ChatRequest) -> ChatResponse:
        """统一非流式调用。"""
        self.limiter.check(req.model)
        messages = self._build_messages(req)
        adapter = self.registry.resolve(req.model)
        timer = CallTimer()
        call_id = new_call_id()

        # 首次传入 force_failures（含 0 以清空残留）；重试传 None 保留计数
        armed = {"done": False}

        async def _once():
            force: int | None
            if not armed["done"]:
                force = req.force_failures
                armed["done"] = True
            else:
                force = None
            return await adapter.invoke(
                model=req.model,
                messages=messages,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
                response_format=req.response_format,
                force_failures=force,
            )

        try:
            result, retries = await with_exponential_backoff(_once)
            timer.mark_first_token()
            obs = timer.to_observability(
                model=req.model,
                adapter=adapter.name,
                usage=result.usage,
                retries=retries,
                treat_total_as_first_token=True,
            )
            self._store_success(call_id, req, adapter.name, obs, retries)
            return ChatResponse(
                id=call_id,
                model=req.model,
                content=result.content,
                finish_reason=result.finish_reason,
                observability=obs,
            )
        except AppError as exc:
            self._store_failure(call_id, req, adapter.name, timer, exc)
            raise

    # ------------------------------------------------------------------
    # 流式（SSE）
    # ------------------------------------------------------------------

    async def chat_stream(self, req: ChatRequest) -> AsyncIterator[dict[str, Any]]:
        """
        统一流式调用，产出 SSE 事件字典。

        事件类型：
        - meta: 首包元信息（id / model / adapter）
        - delta: 文本增量
        - done: 结束，携带 observability
        - error: 流中错误
        """
        self.limiter.check(req.model)
        messages = self._build_messages(req)
        adapter = self.registry.resolve(req.model)
        timer = CallTimer()
        call_id = new_call_id()

        yield {
            "event": "meta",
            "data": {
                "id": call_id,
                "model": req.model,
                "adapter": adapter.name,
            },
        }

        try:
            iterator, first_chunk, retries = await self._open_stream_with_retry(
                adapter, req, messages
            )

            usage = TokenUsage()
            finish_reason = "stop"
            collected = ""

            async def _handle(chunk: StreamChunk) -> dict[str, Any] | None:
                nonlocal collected, usage, finish_reason
                if chunk.delta:
                    if timer.first_token_at is None:
                        timer.mark_first_token()
                    collected += chunk.delta
                    return {"event": "delta", "data": {"content": chunk.delta}}
                if chunk.usage is not None:
                    usage = chunk.usage
                if chunk.finish_reason:
                    finish_reason = chunk.finish_reason
                return None

            if first_chunk is not None:
                evt = await _handle(first_chunk)
                if evt:
                    yield evt

            async for chunk in iterator:
                evt = await _handle(chunk)
                if evt:
                    yield evt

            # 结构化输出：流式结束后校验完整 JSON
            if req.response_format and req.response_format.type == "json_object":
                try:
                    json.loads(collected)
                except json.JSONDecodeError as exc:
                    raise AppError(
                        ErrorCode.STRUCTURED_OUTPUT_INVALID,
                        message="流式结构化输出不是合法 JSON",
                        details={"content": collected, "reason": str(exc)},
                    ) from exc

            if usage.total_tokens == 0:
                prompt_text = " ".join(m.content for m in messages)
                pt = max(1, len(prompt_text) // 2)
                ct = max(1, len(collected) // 2) if collected else 0
                usage = TokenUsage(
                    prompt_tokens=pt,
                    completion_tokens=ct,
                    total_tokens=pt + ct,
                )

            obs = timer.to_observability(
                model=req.model,
                adapter=adapter.name,
                usage=usage,
                retries=retries,
            )
            self._store_success(call_id, req, adapter.name, obs, retries, stream=True)
            yield {
                "event": "done",
                "data": {
                    "id": call_id,
                    "finish_reason": finish_reason,
                    "observability": obs.model_dump(),
                },
            }
        except AppError as exc:
            self._store_failure(call_id, req, adapter.name, timer, exc, stream=True)
            yield {"event": "error", "data": exc.to_dict()["error"]}

    async def _open_stream_with_retry(
        self,
        adapter: BaseAdapter,
        req: ChatRequest,
        messages: list[Message],
    ) -> tuple[Any, StreamChunk | None, int]:
        """
        打开流式迭代器；仅在读到首包之前做指数退避重试。

        Returns:
            (async_iterator, first_chunk_or_None, retries)
        """
        settings = get_settings()
        max_attempts = settings.retry_max_attempts
        base_delay = settings.retry_base_delay_seconds
        last_err: AppError | None = None
        armed = False

        for attempt in range(max_attempts + 1):
            force: int | None
            if not armed:
                force = req.force_failures
                armed = True
            else:
                force = None
            try:
                agen = adapter.stream_invoke(
                    model=req.model,
                    messages=messages,
                    temperature=req.temperature,
                    max_tokens=req.max_tokens,
                    response_format=req.response_format,
                    force_failures=force,
                )
                iterator = agen.__aiter__()
                try:
                    first = await iterator.__anext__()
                except StopAsyncIteration:
                    return iterator, None, attempt
                return iterator, first, attempt
            except AppError as exc:
                last_err = exc
                if exc.code not in _RETRYABLE:
                    raise
                if attempt >= max_attempts:
                    break
                await asyncio.sleep(min(base_delay * (2**attempt), 8.0))

        raise AppError(
            ErrorCode.RETRY_EXHAUSTED,
            message="流式调用重试耗尽",
            details={"last_error": last_err.to_dict() if last_err else None},
        )

    # ------------------------------------------------------------------
    # 内部辅助
    # ------------------------------------------------------------------

    def _build_messages(self, req: ChatRequest) -> list[Message]:
        """合并 prompt_ref 渲染结果与 messages。"""
        messages = list(req.messages)
        if req.prompt_ref:
            rendered = self.prompts.render(req.prompt_ref, req.variables)
            if messages and messages[0].role == "system":
                messages[0] = Message(
                    role="system",
                    content=rendered + "\n" + messages[0].content,
                )
            else:
                messages.insert(0, Message(role="system", content=rendered))

        if not messages:
            raise AppError(
                ErrorCode.INVALID_REQUEST,
                message="messages 与 prompt_ref 不能同时为空",
            )
        return messages

    def _store_success(
        self,
        call_id: str,
        req: ChatRequest,
        adapter: str,
        obs: Observability,
        retries: int,
        stream: bool = False,
    ) -> None:
        self.obs.record(
            CallRecord(
                call_id=call_id,
                model=req.model,
                adapter=adapter,
                stream=stream,
                usage=obs.usage.model_dump(),
                latency_ms=obs.latency_ms,
                first_token_latency_ms=obs.first_token_latency_ms,
                retries=retries,
                success=True,
            )
        )

    def _store_failure(
        self,
        call_id: str,
        req: ChatRequest,
        adapter: str,
        timer: CallTimer,
        exc: AppError,
        stream: bool = False,
    ) -> None:
        self.obs.record(
            CallRecord(
                call_id=call_id,
                model=req.model,
                adapter=adapter,
                stream=stream,
                usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                latency_ms=round(timer.latency_ms(), 2),
                first_token_latency_ms=None,
                retries=0,
                success=False,
                error_code=exc.code.value,
            )
        )


_llm_service: LLMService | None = None


def get_llm_service() -> LLMService:
    global _llm_service
    if _llm_service is None:
        _llm_service = LLMService()
    return _llm_service
