"""
HTTP API 路由

统一入口：
- POST /v1/chat            非流式 / 流式（由 stream 字段决定）
- GET  /v1/models          已注册模型与适配器映射
- CRUD /v1/prompts         Prompt 版本管理
- GET  /v1/metrics         可观测记录
- POST /v1/admin/rate-limit 测试用：动态调整限流（验收 429）
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.adapters.registry import get_registry
from app.models.schemas import ChatRequest, ChatResponse, PromptCreateRequest, PromptInfo
from app.services.llm_service import get_llm_service
from app.services.observability import get_observability_store
from app.services.prompt_manager import get_prompt_manager
from app.services.rate_limiter import get_rate_limiter

router = APIRouter()


# ======================================================================
# Chat
# ======================================================================


@router.post("/v1/chat", response_model=None)
async def chat(req: ChatRequest) -> ChatResponse | StreamingResponse:
    """
    统一模型调用。

    - stream=false → 一次性 JSON（ChatResponse）
    - stream=true  → text/event-stream（SSE）
    """
    service = get_llm_service()
    if req.stream:
        return StreamingResponse(
            _sse_generator(req),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )
    return await service.chat(req)


async def _sse_generator(req: ChatRequest):
    """
    将服务层事件字典编码为 SSE 文本帧。

    格式：
      event: delta
      data: {"content":"..."}

      event: done
      data: {...}
    """
    service = get_llm_service()
    async for evt in service.chat_stream(req):
        event_name = evt.get("event", "message")
        data = json.dumps(evt.get("data", {}), ensure_ascii=False)
        yield f"event: {event_name}\ndata: {data}\n\n"


# ======================================================================
# Models
# ======================================================================


@router.get("/v1/models")
async def list_models() -> dict[str, Any]:
    """查看 model → adapter 路由表。"""
    return {"models": get_registry().list_models()}


# ======================================================================
# Prompts
# ======================================================================


@router.post("/v1/prompts", response_model=PromptInfo)
async def create_prompt(req: PromptCreateRequest) -> PromptInfo:
    """创建或覆盖一个 Prompt 版本。"""
    return get_prompt_manager().save(req)


@router.get("/v1/prompts", response_model=list[PromptInfo])
async def list_prompts() -> list[PromptInfo]:
    """列出全部 Prompt 版本。"""
    return get_prompt_manager().list_all()


@router.get("/v1/prompts/{name}")
async def get_prompt(
    name: str,
    version: str | None = Query(default=None, description="省略则返回最新版本"),
) -> PromptInfo:
    """按名称（及可选版本）读取 Prompt。"""
    return get_prompt_manager().get(name, version)


@router.post("/v1/prompts/render")
async def render_prompt(body: dict[str, Any]) -> dict[str, str]:
    """
    预览模板渲染结果。

    body: { "prompt_ref": "greeting@v1", "variables": {"name": "Alice"} }
    """
    ref = body.get("prompt_ref") or body.get("ref")
    if not ref:
        from app.errors import AppError, ErrorCode

        raise AppError(ErrorCode.INVALID_REQUEST, "缺少 prompt_ref")
    text = get_prompt_manager().render(ref, body.get("variables") or {})
    return {"prompt_ref": ref, "rendered": text}


# ======================================================================
# Observability
# ======================================================================


@router.get("/v1/metrics")
async def metrics(limit: int = Query(default=20, ge=1, le=200)) -> dict[str, Any]:
    """最近调用的 Token / 延迟等可观测数据。"""
    return {"records": get_observability_store().list_recent(limit)}


# ======================================================================
# Admin（验收辅助）
# ======================================================================


class RateLimitUpdate(BaseModel):
    """动态调整某模型的每分钟限额。"""

    model: str
    per_minute: int = Field(..., ge=0)


@router.post("/v1/admin/rate-limit")
async def update_rate_limit(body: RateLimitUpdate) -> dict[str, Any]:
    """测试专用：调低限额以便触发 HTTP 429。"""
    limiter = get_rate_limiter()
    limiter.set_limit(body.model, body.per_minute)
    return {
        "model": body.model,
        "per_minute": limiter.get_limit(body.model),
        "message": "限流配额已更新",
    }


@router.post("/v1/admin/rate-limit/reset")
async def reset_rate_limit(model: str | None = None) -> dict[str, str]:
    """清空限流计数窗口。"""
    get_rate_limiter().reset(model)
    return {"status": "ok"}
