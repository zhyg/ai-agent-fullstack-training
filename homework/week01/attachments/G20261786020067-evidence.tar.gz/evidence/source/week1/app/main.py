"""
应用入口

启动：
  cd week1
  pip install -r requirements.txt
  uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import __version__
from app.api.routes import router
from app.config import get_settings
from app.errors import AppError, app_error_handler, unhandled_error_handler
from app.models.schemas import PromptCreateRequest
from app.services.prompt_manager import get_prompt_manager


def _seed_default_prompts() -> None:
    """
    若 prompts/ 为空，写入作业演示用的默认模板。
    已有文件时不覆盖，方便用户自定义。
    """
    pm = get_prompt_manager()
    if pm.list_all():
        return

    defaults = [
        PromptCreateRequest(
            name="greeting",
            version="v1",
            description="问候模板 v1",
            content="你是友好助手。请用一句话问候用户 {{name}}。",
        ),
        PromptCreateRequest(
            name="greeting",
            version="v2",
            description="问候模板 v2（更正式）",
            content="你是专业助理。请以正式语气向 {{name}} 问好，并询问需要什么帮助。",
        ),
        PromptCreateRequest(
            name="extract_json",
            version="v1",
            description="结构化抽取提示",
            content=(
                "从用户输入中提取关键信息，只输出 JSON，字段包括 "
                "name、intent。用户输入：{{text}}"
            ),
        ),
    ]
    for item in defaults:
        pm.save(item)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """启动时初始化 Prompt 仓库。"""
    settings = get_settings()
    Path(settings.prompts_dir).mkdir(parents=True, exist_ok=True)
    _seed_default_prompts()
    yield


app = FastAPI(
    title="LLM Unified Model Invocation Service",
    description=(
        "Week 1：统一模型调用服务。\n"
        "- deepseek-v4-pro → OpenAI Responses API 适配器\n"
        "- deepseek-v4-flash → Anthropic Messages API 适配器"
    ),
    version=__version__,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_exception_handler(AppError, app_error_handler)
app.add_exception_handler(Exception, unhandled_error_handler)
app.include_router(router)


@app.get("/health")
async def health() -> dict[str, str]:
    """健康检查。"""
    settings = get_settings()
    return {"status": "ok", "version": __version__, "llm_mode": settings.llm_mode}
