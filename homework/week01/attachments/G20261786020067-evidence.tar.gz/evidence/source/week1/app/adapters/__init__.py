"""
适配器包

每个适配器负责一种上游协议的鉴权、请求体构造与响应解析。
对外只暴露 BaseAdapter 契约与 Registry 路由。
"""

from app.adapters.base import AdapterResult, BaseAdapter, StreamChunk
from app.adapters.registry import AdapterRegistry, get_registry

__all__ = [
    "AdapterResult",
    "AdapterRegistry",
    "BaseAdapter",
    "StreamChunk",
    "get_registry",
]
