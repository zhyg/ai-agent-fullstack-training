"""
指数退避重试

对可恢复的上游错误最多重试 retry_max_attempts 次（默认 3）。
延迟序列：base, base*2, base*4, ...（封顶 8 秒）。
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import TypeVar

from app.config import get_settings
from app.errors import AppError, ErrorCode

logger = logging.getLogger(__name__)

T = TypeVar("T")

# 仅对这些错误码重试；限流 / 参数错误等不应重试
_RETRYABLE = {
    ErrorCode.UPSTREAM_ERROR,
    ErrorCode.UPSTREAM_TIMEOUT,
}


async def with_exponential_backoff(
    func: Callable[[], Awaitable[T]],
    *,
    max_attempts: int | None = None,
    base_delay: float | None = None,
) -> tuple[T, int]:
    """
    执行异步调用并在可重试错误时退避重试。

    Returns:
        (result, retries) — retries 为实际重试次数（不含首次）

    Raises:
        AppError(RETRY_EXHAUSTED): 超过最大次数仍失败
        AppError: 不可重试错误原样抛出
    """
    settings = get_settings()
    max_attempts = (
        settings.retry_max_attempts if max_attempts is None else max_attempts
    )
    base_delay = (
        settings.retry_base_delay_seconds if base_delay is None else base_delay
    )

    # 总尝试次数 = 1 次首次 + max_attempts 次重试
    total_tries = max_attempts + 1
    last_error: AppError | None = None

    for attempt in range(total_tries):
        try:
            result = await func()
            return result, attempt  # attempt 即已发生的重试次数
        except AppError as exc:
            last_error = exc
            if exc.code not in _RETRYABLE:
                raise
            if attempt >= max_attempts:
                break
            delay = min(base_delay * (2**attempt), 8.0)
            logger.warning(
                "上游调用失败，准备第 %s 次重试（等待 %.2fs）: %s",
                attempt + 1,
                delay,
                exc.message,
            )
            await asyncio.sleep(delay)

    raise AppError(
        ErrorCode.RETRY_EXHAUSTED,
        message="重试次数耗尽，上游仍不可用",
        details={
            "max_attempts": max_attempts,
            "last_error": last_error.to_dict() if last_error else None,
        },
    )
