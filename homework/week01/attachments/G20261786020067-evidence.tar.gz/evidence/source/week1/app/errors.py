"""
统一错误码封装

所有业务异常都转换为 ErrorCode + HTTP 状态码，
保证客户端收到结构一致的错误响应。
"""

from enum import Enum
from typing import Any

from fastapi import Request
from fastapi.responses import JSONResponse


class ErrorCode(str, Enum):
    """服务对外统一错误码。"""

    INVALID_REQUEST = "INVALID_REQUEST"  # 请求参数非法
    MODEL_NOT_SUPPORTED = "MODEL_NOT_SUPPORTED"  # 未知模型，无法路由适配器
    PROMPT_NOT_FOUND = "PROMPT_NOT_FOUND"  # 模板或版本不存在
    RATE_LIMITED = "RATE_LIMITED"  # 触发按模型限流
    UPSTREAM_ERROR = "UPSTREAM_ERROR"  # 上游返回错误
    UPSTREAM_TIMEOUT = "UPSTREAM_TIMEOUT"  # 上游超时
    RETRY_EXHAUSTED = "RETRY_EXHAUSTED"  # 重试耗尽仍失败
    STRUCTURED_OUTPUT_INVALID = "STRUCTURED_OUTPUT_INVALID"  # 结构化输出非合法 JSON
    INTERNAL_ERROR = "INTERNAL_ERROR"  # 未预期内部错误


# 错误码 → 默认 HTTP 状态码
ERROR_HTTP_STATUS: dict[ErrorCode, int] = {
    ErrorCode.INVALID_REQUEST: 400,
    ErrorCode.MODEL_NOT_SUPPORTED: 400,
    ErrorCode.PROMPT_NOT_FOUND: 404,
    ErrorCode.RATE_LIMITED: 429,
    ErrorCode.UPSTREAM_ERROR: 502,
    ErrorCode.UPSTREAM_TIMEOUT: 504,
    ErrorCode.RETRY_EXHAUSTED: 502,
    ErrorCode.STRUCTURED_OUTPUT_INVALID: 502,
    ErrorCode.INTERNAL_ERROR: 500,
}


class AppError(Exception):
    """
    业务异常基类。

    路由层捕获后统一序列化为：
    {
      "error": {
        "code": "...",
        "message": "...",
        "details": {...}
      }
    }
    """

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        details: dict[str, Any] | None = None,
        http_status: int | None = None,
    ) -> None:
        self.code = code
        self.message = message
        self.details = details or {}
        self.http_status = http_status or ERROR_HTTP_STATUS.get(code, 500)
        super().__init__(message)

    def to_dict(self) -> dict[str, Any]:
        """转为 API 错误响应体。"""
        payload: dict[str, Any] = {
            "code": self.code.value,
            "message": self.message,
        }
        if self.details:
            payload["details"] = self.details
        return {"error": payload}


async def app_error_handler(_: Request, exc: AppError) -> JSONResponse:
    """FastAPI 全局异常处理器：AppError → JSON。"""
    return JSONResponse(status_code=exc.http_status, content=exc.to_dict())


async def unhandled_error_handler(_: Request, exc: Exception) -> JSONResponse:
    """兜底：未捕获异常统一包装为 INTERNAL_ERROR。"""
    err = AppError(
        ErrorCode.INTERNAL_ERROR,
        message="内部服务异常",
        details={"reason": str(exc)},
    )
    return JSONResponse(status_code=err.http_status, content=err.to_dict())
