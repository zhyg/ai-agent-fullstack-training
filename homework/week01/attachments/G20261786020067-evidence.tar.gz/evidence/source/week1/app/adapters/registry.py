"""
适配器注册表

根据请求中的 model 字段动态选择适配器实例，
上层只依赖 BaseAdapter，不感知具体协议类。
"""

from __future__ import annotations

from functools import lru_cache

from app.adapters.anthropic_messages import AnthropicMessagesAdapter
from app.adapters.base import BaseAdapter
from app.adapters.openai_responses import OpenAIResponsesAdapter
from app.config import Settings, get_settings
from app.errors import AppError, ErrorCode


class AdapterRegistry:
    """
    model → adapter 路由器。

    作业要求：根据 model 动态路由到正确适配器，
    隐藏鉴权、请求体、响应格式差异。
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        # 预创建适配器实例（有状态：force_failures 计数）
        self._adapters: dict[str, BaseAdapter] = {
            "openai_responses": OpenAIResponsesAdapter(settings),
            "anthropic_messages": AnthropicMessagesAdapter(settings),
        }
        # 模型别名，兼容大小写 / 下划线写法
        self._model_aliases: dict[str, str] = {
            "deepseek-v4-pro": "deepseek-v4-pro",
            "deepseek_v4_pro": "deepseek-v4-pro",
            "deepseek-v4-flash": "deepseek-v4-flash",
            "deepseek_v4_flash": "deepseek-v4-flash",
        }

    def resolve(self, model: str) -> BaseAdapter:
        """
        按 model 返回适配器。

        Raises:
            AppError(MODEL_NOT_SUPPORTED): 未配置映射的模型
        """
        normalized = self._model_aliases.get(model.strip().lower(), model.strip().lower())
        adapter_key = self.settings.model_adapter_map.get(normalized)
        if not adapter_key:
            raise AppError(
                ErrorCode.MODEL_NOT_SUPPORTED,
                message=f"不支持的模型: {model}",
                details={
                    "supported": list(self.settings.model_adapter_map.keys()),
                },
            )
        adapter = self._adapters.get(adapter_key)
        if adapter is None:
            raise AppError(
                ErrorCode.INTERNAL_ERROR,
                message=f"适配器未注册: {adapter_key}",
            )
        return adapter

    def list_models(self) -> list[dict[str, str]]:
        """列出已注册模型及其协议适配器。"""
        return [
            {"model": m, "adapter": a}
            for m, a in self.settings.model_adapter_map.items()
        ]


@lru_cache
def get_registry() -> AdapterRegistry:
    """进程内单例注册表。"""
    return AdapterRegistry(get_settings())
