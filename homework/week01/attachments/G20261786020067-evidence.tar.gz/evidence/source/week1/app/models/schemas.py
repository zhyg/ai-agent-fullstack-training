"""
统一请求 / 响应 Schema

这是对外契约：调用方只关心统一字段，无需知道底层协议是
OpenAI Responses 还是 Anthropic Messages。
"""

from typing import Any, Literal

from pydantic import BaseModel, Field


class Message(BaseModel):
    """对话消息，role 对齐常见 Chat 语义。"""

    role: Literal["system", "user", "assistant"]
    content: str


class ResponseFormat(BaseModel):
    """
    结构化输出约束。

    type=json_object 时，服务保证最终 content 可被 json.loads 解析。
    """

    type: Literal["text", "json_object"] = "text"


class ChatRequest(BaseModel):
    """
    统一调用请求。

    - model: 决定路由到哪个适配器
    - messages / prompt_ref: 二选一或组合；若有 prompt_ref 则先渲染模板再拼入
    - stream: true 时以 SSE 分块返回
    - response_format: 结构化输出开关
    - variables: 模板变量替换字典
    """

    model: str = Field(..., description="模型名，如 deepseek-v4-pro / deepseek-v4-flash")
    messages: list[Message] = Field(default_factory=list, description="对话消息列表")
    prompt_ref: str | None = Field(
        default=None,
        description="Prompt 引用，格式 name 或 name@version，如 greeting@v2",
    )
    variables: dict[str, Any] = Field(
        default_factory=dict,
        description="Prompt 模板变量，用于 {{var}} 替换",
    )
    stream: bool = Field(default=False, description="是否流式（SSE）输出")
    response_format: ResponseFormat | None = Field(
        default=None,
        description="响应格式；json_object 时强制合法 JSON",
    )
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=1024, ge=1, le=8192)
    # 测试钩子：模拟上游瞬时失败次数，用于验收「指数退避重试」
    force_failures: int = Field(
        default=0,
        description="仅测试用：强制上游前 N 次失败以验证重试",
    )


class TokenUsage(BaseModel):
    """Token 用量拆分（可观测性）。"""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class Observability(BaseModel):
    """
    单次调用的可观测数据。

    - latency_ms: 端到端总耗时
    - first_token_latency_ms: 首 Token 延迟（流式场景有意义；非流式约等于总耗时）
    - usage: Token 分类消耗
    - adapter: 实际命中的适配器名称
    - retries: 实际重试次数（不含首次）
    """

    latency_ms: float
    first_token_latency_ms: float | None = None
    usage: TokenUsage
    adapter: str
    retries: int = 0
    model: str


class ChatResponse(BaseModel):
    """统一非流式响应。"""

    id: str
    model: str
    content: str
    finish_reason: str = "stop"
    observability: Observability


class PromptCreateRequest(BaseModel):
    """创建 / 更新 Prompt 模板。"""

    name: str = Field(..., min_length=1, description="模板名，如 greeting")
    version: str = Field(..., min_length=1, description="版本号，如 v1 / v2")
    content: str = Field(..., min_length=1, description="模板正文，支持 {{var}} 占位符")
    description: str = ""


class PromptInfo(BaseModel):
    """Prompt 元信息。"""

    name: str
    version: str
    content: str
    description: str = ""
    ref: str  # name@version
