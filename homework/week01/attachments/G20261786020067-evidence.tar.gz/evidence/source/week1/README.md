# Week 1：LLM 统一模型调用服务

统一 HTTP 接口屏蔽不同 LLM 协议差异。通过 **适配器模式**，按请求中的 `model` 字段动态路由：

| 模型 | 协议适配器 |
|------|------------|
| `deepseek-v4-pro` | OpenAI Responses API |
| `deepseek-v4-flash` | Anthropic Messages API |

默认 `LLM_MODE=mock`，无需 API Key 即可本地验收全部能力。

---

## 目录结构

```
week1/
├── app/
│   ├── main.py                 # FastAPI 入口
│   ├── config.py               # 环境配置
│   ├── errors.py               # 统一错误码
│   ├── adapters/
│   │   ├── base.py             # 适配器抽象
│   │   ├── openai_responses.py # Responses 协议
│   │   ├── anthropic_messages.py
│   │   └── registry.py         # model → adapter 路由
│   ├── services/
│   │   ├── llm_service.py      # 统一编排
│   │   ├── prompt_manager.py   # 模板存储 / 变量 / 版本
│   │   ├── rate_limiter.py     # 按模型限流
│   │   ├── retry.py            # 指数退避重试
│   │   └── observability.py    # Token / 延迟记录
│   ├── models/schemas.py       # 统一请求响应 Schema
│   └── api/routes.py           # HTTP 路由
├── prompts/                    # Prompt 版本文件
├── scripts/verify.py           # 验收脚本
├── requirements.txt
└── .env.example
```

---

## 快速启动

```bash
cd week1
python -m venv .venv

# Windows
.venv\Scripts\activate
# macOS / Linux
# source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Linux/macOS: cp .env.example .env

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

浏览器打开文档：http://127.0.0.1:8000/docs

### 切换真实上游（可选）

编辑 `.env`：

```env
LLM_MODE=live
DEEPSEEK_API_KEY=sk-xxx
```

---

## curl 示例

### 1. 调用 deepseek-v4-pro（OpenAI Responses 适配器）

```bash
curl -s http://127.0.0.1:8000/v1/chat ^
  -H "Content-Type: application/json" ^
  -d "{\"model\":\"deepseek-v4-pro\",\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}]}"
```

macOS / Linux：

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"你好"}]}'
```

### 2. 调用 deepseek-v4-flash（Anthropic Messages 适配器）

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"你好"}]}'
```

### 3. 流式输出（SSE）

```bash
curl -N http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","stream":true,"messages":[{"role":"user","content":"讲个短笑话"}]}'
```

### 4. 结构化输出

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","response_format":{"type":"json_object"},"messages":[{"role":"user","content":"提取城市信息"}]}'
```

### 5. Prompt 模板引用

```bash
# 预览渲染
curl -s http://127.0.0.1:8000/v1/prompts/render \
  -H "Content-Type: application/json" \
  -d '{"prompt_ref":"greeting@v2","variables":{"name":"Alice"}}'

# 调用时引用
curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","prompt_ref":"greeting@v1","variables":{"name":"Bob"},"messages":[{"role":"user","content":"开始"}]}'
```

### 6. 可观测数据

```bash
curl -s http://127.0.0.1:8000/v1/metrics?limit=5
```

响应中的 `observability` 字段包含：

- `usage.prompt_tokens` / `completion_tokens` / `total_tokens`
- `latency_ms`（端到端）
- `first_token_latency_ms`（首 Token 延迟）
- `adapter` / `retries`

### 7. 重试（测试钩子）

```bash
# 前 2 次强制失败，第 3 次成功，observability.retries == 2
curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","force_failures":2,"messages":[{"role":"user","content":"retry"}]}'
```

### 8. 限流 429

```bash
# 将 flash 限额调到 1 次/分钟
curl -s http://127.0.0.1:8000/v1/admin/rate-limit \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","per_minute":1}'

curl -s http://127.0.0.1:8000/v1/admin/rate-limit/reset?model=deepseek-v4-flash

curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"1"}]}'

# 第二次应返回 429 + RATE_LIMITED
curl -s http://127.0.0.1:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"2"}]}'
```

---

## 验收脚本

另开终端：

```bash
cd week1
python scripts/verify.py
```

脚本会逐项验证：双模型、流式、结构化输出、模板引用、可观测、重试、限流。

---

## 核心设计说明

### 适配器模式

```
Client → /v1/chat → LLMService → AdapterRegistry
                                      ├─ OpenAIResponsesAdapter   (pro)
                                      └─ AnthropicMessagesAdapter (flash)
```

- **鉴权差异**：Responses 用 `Authorization: Bearer`；Messages 用 `x-api-key` + `anthropic-version`
- **请求体差异**：Responses 用 `input` / `instructions` / `text.format`；Messages 用顶层 `system` + `messages` + 必填 `max_tokens`
- **响应差异**：各自解析后统一为 `AdapterResult` / `StreamChunk`

### 弹性

- 统一错误码见 `app/errors.py`
- 可重试错误（`UPSTREAM_*`）指数退避，最多 3 次
- 每个 model 独立滑动窗口限流，超额 HTTP 429

### Prompt 版本

文件约定：`prompts/{name}.{version}.txt`，引用格式 `name` 或 `name@version`，占位符 `{{var}}`。
