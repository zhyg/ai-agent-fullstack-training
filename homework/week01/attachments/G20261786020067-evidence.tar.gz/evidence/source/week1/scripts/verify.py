#!/usr/bin/env python3
"""
功能验收脚本

覆盖验收标准：
1. 两个模型均可调用（pro / flash → 不同适配器）
2. 流式输出（SSE）
3. 结构化输出（合法 JSON）
4. 模板引用（prompt_ref + 变量替换）
5. 可观测数据（Token 拆分 + 延迟 / 首 Token 延迟）
6. 重试（force_failures + 指数退避）
7. 限流（调低配额触发 HTTP 429）

用法：
  # 先启动服务：uvicorn app.main:app --port 8000
  python scripts/verify.py
  python scripts/verify.py --base-url http://127.0.0.1:8000
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Any

import httpx

PASS = 0
FAIL = 0


def ok(name: str, detail: str = "") -> None:
    global PASS
    PASS += 1
    print(f"  [PASS] {name}" + (f" — {detail}" if detail else ""))


def bad(name: str, detail: str = "") -> None:
    global FAIL
    FAIL += 1
    print(f"  [FAIL] {name}" + (f" — {detail}" if detail else ""))


def section(title: str) -> None:
    print(f"\n== {title} ==")


def main() -> int:
    parser = argparse.ArgumentParser(description="Week1 LLM 统一服务验收脚本")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    args = parser.parse_args()
    base = args.base_url.rstrip("/")

    client = httpx.Client(base_url=base, timeout=60.0)

    # ------------------------------------------------------------------
    section("0. 健康检查")
    # ------------------------------------------------------------------
    try:
        r = client.get("/health")
        r.raise_for_status()
        data = r.json()
        ok("health", f"mode={data.get('llm_mode')}")
    except Exception as exc:
        bad("health", str(exc))
        print("\n服务未启动？请先运行: uvicorn app.main:app --port 8000")
        return 1

    # ------------------------------------------------------------------
    section("1. 双模型调用（不同协议适配器）")
    # ------------------------------------------------------------------
    models = client.get("/v1/models").json()["models"]
    mapping = {m["model"]: m["adapter"] for m in models}
    if mapping.get("deepseek-v4-pro") == "openai_responses":
        ok("pro → openai_responses")
    else:
        bad("pro → openai_responses", str(mapping))

    if mapping.get("deepseek-v4-flash") == "anthropic_messages":
        ok("flash → anthropic_messages")
    else:
        bad("flash → anthropic_messages", str(mapping))

    for model, expect_adapter in [
        ("deepseek-v4-pro", "openai_responses"),
        ("deepseek-v4-flash", "anthropic_messages"),
    ]:
        r = client.post(
            "/v1/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": f"hello from {model}"}],
            },
        )
        if r.status_code != 200:
            bad(f"invoke {model}", f"status={r.status_code} body={r.text[:200]}")
            continue
        body = r.json()
        adapter = body.get("observability", {}).get("adapter")
        if adapter == expect_adapter and body.get("content"):
            ok(f"invoke {model}", f"adapter={adapter}")
        else:
            bad(f"invoke {model}", f"adapter={adapter} content={body.get('content')!r}")

    # ------------------------------------------------------------------
    section("2. 流式输出（SSE）")
    # ------------------------------------------------------------------
    deltas: list[str] = []
    done_obs: dict[str, Any] | None = None
    with client.stream(
        "POST",
        "/v1/chat",
        json={
            "model": "deepseek-v4-pro",
            "stream": True,
            "messages": [{"role": "user", "content": "stream please"}],
        },
    ) as resp:
        if resp.status_code != 200:
            bad("sse status", f"{resp.status_code}")
        else:
            event = None
            for line in resp.iter_lines():
                if line.startswith("event:"):
                    event = line.split(":", 1)[1].strip()
                elif line.startswith("data:") and event:
                    payload = json.loads(line.split(":", 1)[1].strip())
                    if event == "delta":
                        deltas.append(payload.get("content", ""))
                    elif event == "done":
                        done_obs = payload.get("observability")
                    event = None
            if deltas and done_obs:
                ok("sse chunks", f"parts={len(deltas)} text={''.join(deltas)[:40]}...")
            else:
                bad("sse chunks", f"deltas={deltas} done={done_obs}")

    # ------------------------------------------------------------------
    section("3. 结构化输出（response_format=json_object）")
    # ------------------------------------------------------------------
    for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
        r = client.post(
            "/v1/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": "return json about cats"}],
                "response_format": {"type": "json_object"},
            },
        )
        if r.status_code != 200:
            bad(f"json {model}", f"status={r.status_code}")
            continue
        content = r.json()["content"]
        try:
            parsed = json.loads(content)
            if isinstance(parsed, dict):
                ok(f"json {model}", f"keys={list(parsed.keys())}")
            else:
                bad(f"json {model}", f"not object: {content}")
        except json.JSONDecodeError as exc:
            bad(f"json {model}", f"{exc}: {content}")

    # ------------------------------------------------------------------
    section("4. Prompt 模板引用 + 变量替换")
    # ------------------------------------------------------------------
    r = client.post(
        "/v1/prompts/render",
        json={"prompt_ref": "greeting@v2", "variables": {"name": "Alice"}},
    )
    rendered = r.json().get("rendered", "")
    if "Alice" in rendered and "{{" not in rendered:
        ok("render greeting@v2", rendered[:60])
    else:
        bad("render greeting@v2", rendered)

    r = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-v4-flash",
            "prompt_ref": "greeting@v1",
            "variables": {"name": "Bob"},
            "messages": [{"role": "user", "content": "开始吧"}],
        },
    )
    if r.status_code == 200 and r.json().get("content"):
        ok("chat with prompt_ref")
    else:
        bad("chat with prompt_ref", r.text[:200])

    # ------------------------------------------------------------------
    section("5. 可观测性（Token + 延迟）")
    # ------------------------------------------------------------------
    r = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "obs check"}],
        },
    )
    obs = r.json().get("observability", {})
    usage = obs.get("usage") or {}
    checks = [
        ("latency_ms", obs.get("latency_ms") is not None and obs["latency_ms"] >= 0),
        (
            "first_token_latency_ms",
            obs.get("first_token_latency_ms") is not None,
        ),
        ("prompt_tokens", usage.get("prompt_tokens", 0) > 0),
        ("completion_tokens", usage.get("completion_tokens", 0) > 0),
        ("total_tokens", usage.get("total_tokens", 0) > 0),
    ]
    for label, passed in checks:
        if passed:
            ok(f"obs.{label}", str(obs.get(label, usage.get(label.replace("obs.", "")))))
        else:
            bad(f"obs.{label}", str(obs))

    metrics = client.get("/v1/metrics?limit=5").json()
    if metrics.get("records"):
        ok("metrics endpoint", f"n={len(metrics['records'])}")
    else:
        bad("metrics endpoint", "empty")

    # ------------------------------------------------------------------
    section("6. 指数退避重试（最多 3 次）")
    # ------------------------------------------------------------------
    # force_failures=2 → 前两次失败，第三次成功，retries 应为 2
    t0 = time.perf_counter()
    r = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "retry me"}],
            "force_failures": 2,
        },
    )
    elapsed = time.perf_counter() - t0
    if r.status_code != 200:
        bad("retry success after failures", r.text[:200])
    else:
        retries = r.json().get("observability", {}).get("retries", -1)
        # base 0.5 + 1.0 = 1.5s 理论最小退避（默认配置）
        if retries == 2:
            ok("retry count == 2", f"elapsed={elapsed:.2f}s")
        else:
            bad("retry count == 2", f"retries={retries}")
        if elapsed >= 1.0:
            ok("retry backoff delay observed", f"{elapsed:.2f}s")
        else:
            bad("retry backoff delay observed", f"elapsed={elapsed:.2f}s too small")

    # force_failures=5 → 超过 max_attempts=3，应耗尽
    r = client.post(
        "/v1/chat",
        json={
            "model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "exhaust"}],
            "force_failures": 5,
        },
    )
    if r.status_code >= 400 and r.json().get("error", {}).get("code") == "RETRY_EXHAUSTED":
        ok("retry exhausted", f"status={r.status_code}")
    else:
        bad("retry exhausted", r.text[:200])

    # ------------------------------------------------------------------
    section("7. 按模型限流 → HTTP 429")
    # ------------------------------------------------------------------
    model = "deepseek-v4-flash"
    client.post(
        "/v1/admin/rate-limit",
        json={"model": model, "per_minute": 2},
    )
    client.post("/v1/admin/rate-limit/reset", params={"model": model})

    statuses = []
    for i in range(4):
        r = client.post(
            "/v1/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": f"rl-{i}"}],
            },
        )
        statuses.append(r.status_code)

    # 恢复默认限额，避免影响后续手工调试
    client.post(
        "/v1/admin/rate-limit",
        json={"model": model, "per_minute": 60},
    )
    client.post("/v1/admin/rate-limit/reset", params={"model": model})

    if statuses.count(200) >= 2 and 429 in statuses:
        ok("rate limit 429", f"statuses={statuses}")
        # 确认错误码
        # 重新触发一次以便检查 body（限额已恢复，需再压一次）
        client.post("/v1/admin/rate-limit", json={"model": model, "per_minute": 1})
        client.post("/v1/admin/rate-limit/reset", params={"model": model})
        client.post(
            "/v1/chat",
            json={"model": model, "messages": [{"role": "user", "content": "a"}]},
        )
        r = client.post(
            "/v1/chat",
            json={"model": model, "messages": [{"role": "user", "content": "b"}]},
        )
        code = r.json().get("error", {}).get("code")
        if r.status_code == 429 and code == "RATE_LIMITED":
            ok("rate limit error code", code)
        else:
            bad("rate limit error code", r.text[:200])
        client.post("/v1/admin/rate-limit", json={"model": model, "per_minute": 60})
        client.post("/v1/admin/rate-limit/reset", params={"model": model})
    else:
        bad("rate limit 429", f"statuses={statuses}")

    # ------------------------------------------------------------------
    section("汇总")
    # ------------------------------------------------------------------
    total = PASS + FAIL
    print(f"\n结果: {PASS}/{total} 通过, {FAIL} 失败")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
