"""Real calls, official DeepSeek only; key read from environment, never serialized."""
import os, sys, asyncio, json, time
from pathlib import Path
os.environ.update(LLM_MODE='live',DEEPSEEK_BASE_URL='https://api.deepseek.com',RETRY_MAX_ATTEMPTS='0',PROMPTS_DIR='/tmp/grading-307/live-prompts')
sys.path.insert(0,'/tmp/grading-307/student/week1')
from app.services.llm_service import get_llm_service
from app.models.schemas import ChatRequest
from app.errors import AppError
import httpx

records=[]
# Observe upstream request and response metadata without headers/body credentials.
original_post=httpx.AsyncClient.post
async def post(self,url,*args,**kw):
    start=time.monotonic(); rec={'url':str(url),'model':kw['json'].get('model'),'stream':kw['json'].get('stream'),'max_tokens':kw['json'].get('max_tokens')}
    try:
        r=await original_post(self,url,*args,**kw)
        rec.update(status=r.status_code,request_id=r.headers.get('x-request-id'))
        try:
            b=r.json(); rec.update(upstream_id=b.get('id'),upstream_model=b.get('model'),usage=b.get('usage'),finish_reason=(b.get('choices') or [{}])[0].get('finish_reason'))
        except Exception: pass
        return r
    finally:
        rec['elapsed_ms']=round((time.monotonic()-start)*1000,2); records.append(rec)
httpx.AsyncClient.post=post

async def run(model,structured):
    req=ChatRequest(model=model,max_tokens=1024,messages=[{'role':'user','content':'Return only JSON: {"ok":true}.' if structured else 'Reply only OK.'}],response_format={'type':'json_object'} if structured else None)
    start=time.monotonic(); result={'alias':model,'protocol':'Chat Completions','structured':structured}
    try:
        r=await asyncio.wait_for(get_llm_service().chat(req),70)
        result.update(status='success',response=r.model_dump())
    except AppError as e: result.update(status='unverified' if e.code.value in ['RETRY_EXHAUSTED','UPSTREAM_TIMEOUT'] else 'failed',error=e.to_dict())
    except Exception as e: result.update(status='unverified',error_type=type(e).__name__)
    result['elapsed_ms']=round((time.monotonic()-start)*1000,2)
    return result
async def main():
    if not os.environ.get('DEEPSEEK_API_KEY'): raise RuntimeError('credential unavailable')
    results=await asyncio.gather(*(run(m,s) for m in ['deepseek-v4-pro','deepseek-v4-flash'] for s in [False,True]))
    output={'configuration':{'endpoint':'https://api.deepseek.com','mode':'live','retry_max_attempts':0,'model_substitution':False,'note':'bounded one attempt per scenario, no source logic changes; original retry count is 3'},'results':results,'upstream_metadata':records,'metrics':get_llm_service().obs.list_recent()}
    Path(__file__).with_name('live-results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
    print(json.dumps([{'model':r['alias'],'structured':r['structured'],'status':r['status']} for r in results]))
asyncio.run(main())
