"""Finite network acceptance run against unchanged student code. No credentials."""
import os, sys, json, time, threading, asyncio
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
os.environ.update(LLM_MODE='live', DEEPSEEK_BASE_URL='http://127.0.0.1:19081', DEEPSEEK_API_KEY='teacher-dummy', PROMPTS_DIR='/tmp/grading-307/test-prompts', RATE_LIMIT_PRO_PER_MINUTE='1000', RATE_LIMIT_FLASH_PER_MINUTE='1000')
sys.path.insert(0, '/tmp/grading-307/student/week1')
import httpx, uvicorn
from app.main import app

OUT=Path(__file__).parent
mode='normal'; calls=[]; release=threading.Event(); entered=threading.Event()
class Upstream(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        calls.append({'path':self.path,'body':body,'at':time.monotonic(),'auth_scheme':'Bearer' if self.headers.get('Authorization','').startswith('Bearer') else 'other'})
        active=mode
        status=400 if active=='400' else 401 if active=='401' else 429 if active=='429' else 500 if active=='500' or (active=='retry' and len(calls)<3) else 200
        self.send_response(status)
        self.send_header('Content-Type','text/event-stream' if body.get('stream') and status==200 else 'application/json'); self.end_headers()
        if status!=200:
            self.wfile.write(b'{"error":{"message":"controlled failure"}}'); return
        if body.get('stream'):
            def emit(obj):
                self.wfile.write(('data: '+json.dumps(obj)+'\n\n').encode()); self.wfile.flush()
            emit({'choices':[{'delta':{},'finish_reason':None}]})
            time.sleep(.12)
            emit({'choices':[{'delta':{'content':'first'},'finish_reason':None}]})
            if active=='gate': entered.set(); release.wait(5)
            if active=='disconnect': return
            if active=='error-event': emit({'error':{'message':'stream failed','type':'server_error'}}); return
            emit({'choices':[{'delta':{'content':'第二'},'finish_reason':None}]})
            emit({'choices':[{'delta':{},'finish_reason':'stop'}], 'usage':{'prompt_tokens':17,'completion_tokens':9,'total_tokens':26}})
            self.wfile.write(b'data: [DONE]\n\n'); return
        text={'invalid':'not-json','empty':'','truncated':'{"x":','valid':'{"x":7}'}.get(active,'reply')
        data={'id':'upstream-fixed-id','choices':[{'message':{'content':text},'finish_reason':'length' if active=='truncated' else 'stop'}], 'usage':{'prompt_tokens':17,'completion_tokens':9,'total_tokens':26,'prompt_cache_hit_tokens':11,'prompt_cache_miss_tokens':6,'completion_tokens_details':{'reasoning_tokens':4}}}
        if active=='missing-usage': data.pop('usage')
        self.wfile.write(json.dumps(data).encode())

up=ThreadingHTTPServer(('127.0.0.1',19081),Upstream)
threading.Thread(target=up.serve_forever,daemon=True).start()
server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=19082,log_level='error'))
t=threading.Thread(target=server.run,daemon=True); t.start()
while not server.started: time.sleep(.02)
c=httpx.Client(base_url='http://127.0.0.1:19082',timeout=15)
models=['deepseek-v4-pro','deepseek-v4-flash']; results=[]
def reset(m='normal'):
    global mode
    mode=m; calls.clear()
    c.post('/v1/admin/rate-limit/reset')
def chat(model,**kw):
    return c.post('/v1/chat',json={'model':model,'messages':[{'role':'user','content':'test'}],**kw})
def save(name,expected,actual,passed):
    results.append(json.loads(json.dumps({'case':name,'expected':expected,'actual':actual,'passed':passed})))
try:
    reset(); r=chat('unknown'); save('A04','400 MODEL_NOT_SUPPORTED; no upstream',{'status':r.status_code,'body':r.json(),'calls':len(calls)},r.status_code==400 and not calls)
    for model in models:
        reset(); r=chat(model,messages=[{'role':'system','content':'sys'},{'role':'user','content':'test'}]); expected_path='/v1/responses' if model==models[0] else '/v1/messages'; save('A03-'+model,'documented protocol on wire: '+expected_path,{'status':r.status_code,'request':calls,'response':r.json()},len(calls)==1 and calls[0]['path']==expected_path)
        reset('valid'); r=chat(model,response_format={'type':'json_object'}); save('F03-'+model,'valid JSON and mapped response_format',{'body':r.json(),'request':calls},r.status_code==200 and json.loads(r.json()['content'])=={'x':7})
        for bad in ['invalid','empty','truncated']:
            reset(bad); r=chat(model,response_format={'type':'json_object'}); save('F04-'+model+'-'+bad,'structured error, no invalid successful JSON',{'status':r.status_code,'body':r.json(),'calls':len(calls)},r.status_code==502 and r.json()['error']['code']=='STRUCTURED_OUTPUT_INVALID')
        reset('gate'); release.clear(); entered.clear(); got=threading.Event(); received=[]
        def consume():
            with c.stream('POST','/v1/chat',json={'model':model,'stream':True,'messages':[{'role':'user','content':'stream'}]}) as r:
                for line in r.iter_lines():
                    received.append({'line':line,'at':time.monotonic()})
                    if 'first' in line: got.set()
        reader=threading.Thread(target=consume); reader.start(); entered.wait(5); incremental=got.wait(2); release.set(); reader.join(5)
        save('F01-'+model,'first text reaches client before upstream terminal released',{'incremental':incremental,'events':received,'calls':len(calls)},incremental and any('event: done'==x['line'] for x in received))
        rec=c.get('/v1/metrics').json()['records'][0]; save('F07-stream-'+model,'TTFT >=120ms; exact usage 17/9/26 + provided cache/reasoning',rec,rec['first_token_latency_ms']>=120 and rec['usage'].get('total_tokens')==26)
        for bad in ['disconnect','error-event']:
            reset(bad); r=chat(model,stream=True); save('F02-'+model+'-'+bad,'error event, no success done, exactly one request',{'sse':r.text,'calls':len(calls)},'event: error' in r.text and 'event: done' not in r.text and len(calls)==1)
        reset('missing-usage'); r=chat(model); obs=r.json()['observability']; save('F07-missing-usage-'+model,'unknown or explicitly estimated usage',r.json(),obs.get('usage') is None or obs.get('usage_estimated') is True)
    reset()
    for version,text in [('v1','old {{name}}'),('v2','new {{name}}')]:
        c.post('/v1/prompts',json={'name':'teacher','version':version,'content':text}).raise_for_status()
    rendered=[]
    for version in ['v2','v1']:
        chat(models[0],prompt_ref='teacher@'+version,variables={'name':'Ada'}); rendered.append(calls[-1]['body']['messages'][0]['content'])
    save('F05','v2 and retained v1 enter upstream',rendered,rendered==['new Ada','old Ada'])
    for ref,variables in [('absent@v1',{}),('teacher@v9',{}),('teacher@v1',{})]:
        reset(); r=chat(models[0],prompt_ref=ref,variables=variables); save('F06-'+ref,'explicit missing item error; no unresolved placeholders sent',{'status':r.status_code,'body':r.json(),'calls':calls.copy()},r.status_code in [400,404] and not calls)
    for m in ['retry','500','400','401','429']:
        reset(m); r=chat(models[0]); attempts=len(calls); gaps=[round(calls[i]['at']-calls[i-1]['at'],3) for i in range(1,attempts)]
        save('F08-F09-'+m,'3 attempts success / max 4 persistent / one nonretryable',{'status':r.status_code,'body':r.json(),'attempts':attempts,'gaps_seconds':gaps}, attempts== (3 if m=='retry' else 4 if m in ['500','429'] else 1))
        rec=c.get('/v1/metrics').json()['records'][0]; save('F07-failure-'+m,'failed attempts accurately recorded',rec,m=='retry' or rec['retries']==attempts-1)
    reset(); before=len(c.get('/v1/metrics?limit=200').json()['records']); r=chat('unknown'); after=len(c.get('/v1/metrics?limit=200').json()['records']); save('F07-early-failure','every call creates failure record',{'before':before,'after':after,'status':r.status_code},after==before+1)
    reset(); c.post('/v1/admin/rate-limit',json={'model':models[0],'per_minute':1}); statuses=[chat(models[0]).status_code,chat(models[0]).status_code,chat(models[1]).status_code]; save('F10','[200,429,200] separate budgets',statuses,statuses==[200,429,200])
    start=time.monotonic(); time.sleep(60.2); r=chat(models[0]); save('F11','actual 60s window restores without reset',{'status':r.status_code,'wait_seconds':time.monotonic()-start},r.status_code==200)
    # Student verification deliberately sees upstream invalid content.
    c.post('/v1/admin/rate-limit',json={'model':models[0],'per_minute':1000}); reset('invalid')
    import subprocess
    p=subprocess.run([sys.executable,'/tmp/grading-307/student/week1/scripts/verify.py','--base-url','http://127.0.0.1:19082'],capture_output=True,text=True)
    (OUT/'student-verify-forced-failure.log').write_text(p.stdout+p.stderr)
    save('F12','student script reports induced failure',{'exit':p.returncode,'failure_visible':'[FAIL]' in p.stdout},p.returncode!=0 and '[FAIL]' in p.stdout)
finally:
    release.set(); c.close(); server.should_exit=True; t.join(5); up.shutdown(); up.server_close()
    (OUT/'teacher-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps({'checks':len(results),'passed':sum(x['passed'] for x in results),'failed':[x['case'] for x in results if not x['passed']]},ensure_ascii=False))
