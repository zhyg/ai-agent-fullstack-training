import asyncio
import json
import time
from pathlib import Path
import httpx

OUT = Path('/tmp/fuyu-grade')
MODELS = ['v4-pro', 'v4-flash']
SCHEMA = {'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok'], 'additionalProperties': False}
FORMAT = {'type': 'json_schema', 'json_schema': {'name': 'result', 'schema': SCHEMA}}
results = []

async def controlled():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18732', timeout=15) as c:
        async def reset(mode='normal'): await c.post('/__teacher/control', json={'mode': mode})
        async def calls(): return (await c.get('/__teacher/calls')).json()['calls']
        async def ledger():
            await asyncio.sleep(.03)
            return (await c.get('/admin/usage')).json()['data']
        async def post(model, **kw):
            return await c.post('/v1/chat/completions', json={'model': model, 'messages': [{'role': 'user', 'content': 'Return JSON {"ok":true}'}], **kw})
        def save(case, actual, passed):
            results.append({'case': case, 'passed': passed, 'actual': actual})
        await reset()
        r = await c.get('/healthz'); save('A01', r.json(), r.status_code == 200)
        for m in MODELS:
            await reset()
            r = await post(m, messages=[{'role': 'system', 'content': 'teacher system'}, {'role': 'user', 'content': 'hello'}])
            captured = await calls()
            save('A03-' + m, {'response': r.json(), 'requests': captured}, r.status_code == 200 and len(captured) == 1)
        await reset()
        r = await post('missing'); save('A04', {'status': r.status_code, 'body': r.json(), 'calls': await calls()}, r.status_code == 404 and not await calls())
        for m in MODELS:
            for mode in ['gated', 'broken', 'event_error']:
                await reset(mode)
                seen, first_at, released = [], None, None
                start = time.monotonic()
                async with c.stream('POST', '/v1/chat/completions', json={'model': m, 'messages': [{'role': 'user', 'content': 'hello'}], 'stream': True}) as r:
                    async for line in r.aiter_lines():
                        seen.append(line)
                        if 'GATE' in line and first_at is None:
                            first_at = time.monotonic() - start
                            if mode == 'gated':
                                released = time.monotonic() - start
                                await c.post('/__teacher/release')
                rows = await ledger()
                row = next(x for x in rows if x['request_id'] == r.headers['x-request-id'])
                cs = await calls()
                ok = first_at is not None and len(cs) == 1
                if mode != 'gated': ok = ok and row['status'] == 'error' and 'error' in '\n'.join(seen)
                save(('F01-' if mode == 'gated' else 'F02-') + m + '-' + mode,
                     {'lines': seen, 'first_content_seconds': first_at, 'released_seconds': released, 'calls': cs, 'ledger': row}, ok)
        for m in MODELS:
            for fmt in [{'type': 'json_object'}, FORMAT]:
                for mode in ['normal', 'invalid', 'empty', 'truncated', 'schema_wrong']:
                    if fmt['type'] == 'json_object' and mode == 'schema_wrong': continue
                    await reset(mode)
                    r = await post(m, response_format=fmt)
                    save(('F03-' if mode == 'normal' else 'F04-') + m + '-' + fmt['type'] + '-' + mode,
                         {'status': r.status_code, 'body': r.json(), 'calls': await calls()}, r.status_code == (200 if mode == 'normal' else 422))
        await reset()
        for version in [1, 2]:
            r = await c.post('/v1/prompts', json={'id': 'teacher-version', 'name': 'teacher', 'content': f'V{version} {{{{ language }}}}'})
        for version in [1, 2]:
            r = await post(MODELS[0], gateway_prompt={'id': 'teacher-version', 'version': version, 'variables': {'language': 'Python'}})
            text = (await calls())[-1]['body']['messages'][0]['content']
            save('F05-v' + str(version), {'status': r.status_code, 'upstream_prompt': text}, text == f'V{version} Python')
        for ref in [{'id': 'missing'}, {'id': 'teacher-version', 'version': 99}, {'id': 'teacher-version'}]:
            await reset(); r = await post(MODELS[0], gateway_prompt=ref)
            save('F06-' + str(ref), {'status': r.status_code, 'body': r.json(), 'calls': await calls()}, r.status_code in [404, 422] and not await calls())
        for mode in ['retry', 'fail500', 'timeout', 'fail400']:
            await reset(mode); r = await post(MODELS[0]); cs = await calls()
            intervals = [cs[i]['time'] - cs[i-1]['time'] for i in range(1, len(cs))]
            save(('F08-' if mode == 'retry' else 'F09-') + mode, {'status': r.status_code, 'calls': cs, 'intervals': intervals, 'ledger': (await ledger())[0]},
                 len(cs) == (1 if mode == 'fail400' else 3) and r.status_code == (200 if mode == 'retry' else 400 if mode == 'fail400' else 502))
        await reset()
        statuses = [(await post('quota-a')).status_code, (await post('quota-a')).status_code, (await post('quota-b')).status_code]
        save('F10-model-isolation', statuses, statuses == [200,429,200])
        await asyncio.sleep(1.1)
        r = await post('quota-a'); save('F11-recovery', r.status_code, r.status_code == 200)
        # Global default bucket also affects every model despite separate model buckets.
        rows = await ledger()
        (OUT / 'controlled-ledger.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    (OUT / 'controlled-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
    print('\n'.join(f"{r['case']}: {'PASS' if r['passed'] else 'FAIL'}" for r in results))

async def real():
    records = []
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18733', timeout=85) as c:
        for model in MODELS:
            for kind in ['ordinary', 'structured', 'stream']:
                body = {'model': model, 'messages': [{'role': 'user', 'content': 'Return only JSON {"ok":true}'}], 'max_tokens': 128, 'thinking': {'type': 'disabled'}}
                if kind == 'structured': body['response_format'] = FORMAT if model == 'v4-flash' else {'type': 'json_object'}
                started = time.monotonic()
                rec = {'model_alias': model, 'kind': kind}
                try:
                    if kind == 'stream':
                        body['stream'] = True
                        if model == 'v4-pro': body['stream_options'] = {'include_usage': True}
                        lines = []
                        async with c.stream('POST', '/v1/chat/completions', json=body) as r:
                            rec.update(status=r.status_code, request_id=r.headers.get('x-request-id'))
                            async for line in r.aiter_lines():
                                if line: lines.append({'seconds': time.monotonic()-started, 'line': line})
                        rec['events'] = lines
                    else:
                        r = await c.post('/v1/chat/completions', json=body)
                        rec.update(status=r.status_code, request_id=r.headers.get('x-request-id'), body=r.json())
                except Exception as e: rec['error'] = str(e)
                rec['elapsed_seconds'] = time.monotonic() - started
                records.append(rec)
                (OUT / 'real-results.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
                print(model, kind, rec.get('status'), round(rec['elapsed_seconds'], 2), flush=True)
        rows = (await c.get('/admin/usage')).json()
        (OUT / 'real-ledger.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    import sys
    asyncio.run(real() if '--real' in sys.argv else controlled())
