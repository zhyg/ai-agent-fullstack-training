import asyncio
import json
import os
import time
from pathlib import Path

import httpx
from fastapi import Request
from app.config import load_config
from app.main import create_app

ROOT = Path('/tmp/fuyu-grade')
state = {'mode': 'normal', 'calls': [], 'release': False, 'n': 0}

def frame(obj):
    return ('data: ' + json.dumps(obj) + '\n\n').encode()

def usage(proto):
    if proto == 'anthropic':
        return {'input_tokens': 13, 'output_tokens': 7, 'cache_read_input_tokens': 3, 'cache_creation_input_tokens': 2}
    return {'prompt_tokens': 13, 'completion_tokens': 7, 'total_tokens': 20,
            'prompt_tokens_details': {'cached_tokens': 3}, 'completion_tokens_details': {'reasoning_tokens': 2}}

class Stream(httpx.AsyncByteStream):
    def __init__(self, proto, mode): self.proto, self.mode = proto, mode
    async def __aiter__(self):
        yield b': heartbeat\n\n'
        await asyncio.sleep(.12)
        if self.proto == 'anthropic':
            yield frame({'type': 'message_start', 'message': {'usage': usage(self.proto)}})
            yield frame({'type': 'content_block_delta', 'delta': {'type': 'text_delta', 'text': 'GATE'}})
        else:
            yield frame({'choices': [{'delta': {'content': 'GATE'}}]})
        if self.mode == 'broken': raise httpx.ReadError('teacher interrupted after content')
        if self.mode == 'event_error':
            yield frame({'type': 'error', 'error': {'message': 'teacher event failure', 'type': 'api_error'}})
            return
        if self.mode == 'gated':
            while not state['release']: await asyncio.sleep(.01)
        if self.proto == 'anthropic':
            yield frame({'type': 'message_delta', 'delta': {'stop_reason': 'end_turn'}, 'usage': usage(self.proto)})
            yield frame({'type': 'message_stop'})
        else:
            yield frame({'choices': [{'delta': {}, 'finish_reason': 'stop'}], 'usage': usage(self.proto)})
            yield b'data: [DONE]\n\n'

async def handler(req):
    body = json.loads(req.content)
    proto = 'anthropic' if req.url.path.endswith('/messages') else 'chat'
    state['n'] += 1
    state['calls'].append({'time': time.monotonic(), 'path': req.url.path, 'body': body,
                           'auth_kind': 'x-api-key' if 'x-api-key' in req.headers else 'bearer'})
    mode = state['mode']
    if '/broken/' in req.url.path or mode == 'fail500' or (mode == 'retry' and state['n'] <= 2):
        return httpx.Response(500, json={'error': {'message': 'controlled busy'}})
    if mode == 'fail400': return httpx.Response(400, json={'error': {'message': 'controlled invalid'}})
    if mode == 'timeout': raise httpx.ReadTimeout('controlled timeout')
    if body.get('stream'): return httpx.Response(200, stream=Stream(proto, mode), headers={'content-type': 'text/event-stream'})
    content = {'invalid': 'not json', 'empty': '', 'truncated': '{"ok":', 'schema_wrong': '{"ok": "wrong"}'}.get(mode, '{"ok":true}')
    # Script-specific deterministic result, independent of student implementation.
    messages = json.dumps(body.get('messages', []), ensure_ascii=False)
    if 'name 填 Claude' in messages: content = '{"name":"Claude","role":"AI assistant"}'
    if 'answer' in json.dumps(body.get('response_format', {})): content = '{"answer":42}'
    if proto == 'anthropic':
        blocks = [{'type': 'text', 'text': content}]
        if body.get('tool_choice', {}).get('type') == 'tool' and mode == 'normal':
            name = body['tool_choice']['name']
            blocks = [{'type': 'tool_use', 'id': 'tool_teacher', 'name': name, 'input': json.loads(content)}]
        return httpx.Response(200, json={'id': 'msg_teacher', 'type': 'message', 'model': body['model'], 'role': 'assistant',
                                        'content': blocks, 'stop_reason': 'max_tokens' if mode == 'truncated' else 'end_turn', 'usage': usage(proto)})
    return httpx.Response(200, json={'id': 'chat_teacher', 'object': 'chat.completion', 'model': body['model'],
        'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': content}, 'finish_reason': 'length' if mode == 'truncated' else 'stop'}], 'usage': usage(proto)})

async def capture(req):
    with (ROOT / 'real-upstream.jsonl').open('a') as f:
        f.write(json.dumps({'time': time.time(), 'url': str(req.url), 'body': json.loads(req.content),
                            'auth_kind': 'x-api-key' if 'x-api-key' in req.headers else 'bearer'}) + '\n')

if os.getenv('TEACHER_REAL') == '1':
    upstream = httpx.AsyncClient(event_hooks={'request': [capture]})
else:
    upstream = httpx.AsyncClient(transport=httpx.MockTransport(handler))
app = create_app(load_config(), http_client=upstream)

@app.post('/__teacher/control')
async def control(request: Request):
    body = await request.json()
    state.update(mode=body.get('mode', 'normal'), calls=[], n=0, release=False)
    app.state.model_router._circuits.clear() if hasattr(app.state.model_router, '_circuits') else None
    return {'ok': True}

@app.post('/__teacher/release')
async def release():
    state['release'] = True
    return {'ok': True}

@app.get('/__teacher/calls')
async def calls(): return state
