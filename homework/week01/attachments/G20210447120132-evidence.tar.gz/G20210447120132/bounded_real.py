import asyncio
import json
import time
from pathlib import Path
import httpx

async def main():
    root = Path('/tmp/fuyu-grade')
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18733', timeout=74) as c:
        start = time.monotonic()
        record = {'model_alias': 'v4-flash', 'upstream_model': 'deepseek-flash', 'kind': 'ordinary', 'wall_budget_seconds': 75}
        try:
            async with asyncio.timeout(75):
                r = await c.post('/v1/chat/completions', json={'model': 'v4-flash', 'messages': [{'role': 'user', 'content': 'Reply OK'}], 'max_tokens': 128, 'thinking': {'type': 'disabled'}})
                record.update(status=r.status_code, request_id=r.headers.get('x-request-id'), body=r.json())
        except Exception as e:
            record['error'] = type(e).__name__
        record['elapsed_seconds'] = time.monotonic() - start
        (root/'real-flash-result.json').write_text(json.dumps(record, indent=2))
        rows = (await c.get('/admin/usage')).json()
        (root/'real-ledger.json').write_text(json.dumps(rows, indent=2))
        print(json.dumps(record, indent=2))

asyncio.run(main())
