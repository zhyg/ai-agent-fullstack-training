import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, patch
import httpx
from app.config import load_config
from app.main import create_app

async def main():
    config = load_config('/tmp/fuyu-grade/controlled.yaml')
    config.database_url = '/tmp/fuyu-grade/supplement.db'
    config.rate_limit.burst = 2
    config.rate_limit.requests_per_minute = 60
    count = 0
    def handle(request):
        nonlocal count
        count += 1
        return httpx.Response(200, json={'id': 'teacher', 'choices': [{'message': {'content': 'ok'}}], 'usage': {'prompt_tokens': 13, 'completion_tokens': 7, 'prompt_cache_hit_tokens': 3, 'prompt_cache_miss_tokens': 10}})
    up = httpx.AsyncClient(transport=httpx.MockTransport(handle))
    app = create_app(config, http_client=up)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url='http://teacher') as client:
            requests = []
            for model in ['quota-a', 'quota-a', 'quota-b']:
                r = await client.post('/v1/chat/completions', json={'model': model, 'messages': [{'role': 'user', 'content': 'hi'}]})
                requests.append({'model': model, 'status': r.status_code, 'body': r.json()})
            rows = await app.state.usage.recent()
            sleeper = AsyncMock()
            with patch('app.services.gateway.random.uniform', return_value=1.25), patch('app.services.gateway.asyncio.sleep', sleeper):
                for attempt in range(5): await app.state.gateway._backoff(attempt)
            delays = [c.args[0] for c in sleeper.call_args_list]
            result = {'F10-global-coupling': {'config': config.rate_limit.model_dump(), 'requests': requests, 'upstream_count': count},
                      'F07-deepseek-cache': {'upstream_usage': {'prompt_tokens':13,'completion_tokens':7,'prompt_cache_hit_tokens':3,'prompt_cache_miss_tokens':10}, 'ledger': rows},
                      'F08-backoff-injected-random': {'random_uniform':1.25, 'base':.08, 'cap':.5,'actual_delays':delays, 'expected_maxima':[.08,.16,.32,.5,.5]}}
            Path('/tmp/fuyu-grade/supplement.json').write_text(json.dumps(result, indent=2))
            print(json.dumps(result, indent=2))
    await up.aclose()

asyncio.run(main())
