#!/usr/bin/env python3
"""Teacher acceptance probe. Does not modify student source or test assertions.

Offline cases use the student's own mock upstream and test harness.
Real calls use DEEPSEEK_API_KEY and never print it.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
import traceback
from pathlib import Path

STUDENT = Path("/home/user/workspace/repo/.amp/in/orb-backup/student/llm-gateway")
sys.path.insert(0, str(STUDENT))
os.chdir(STUDENT)
os.environ.setdefault("MINIMAX_API_KEY", "dummy-not-used")

import httpx  # noqa: E402
from fastapi import FastAPI  # noqa: E402

from core.types import LLMRequest, UnifiedMessage  # noqa: E402
from tests.conftest import StreamingASGITransport, build_harness, make_settings  # noqa: E402
from main import create_app  # noqa: E402
from upstream.mock_server import reset_mock_state  # noqa: E402

OUT = Path("/home/user/workspace/repo/.amp/in/week-grading/probe/logs")
OUT.mkdir(parents=True, exist_ok=True)

SCHEMA = {
    "name": "ping",
    "strict": True,
    "schema": {
        "type": "object",
        "properties": {"ok": {"type": "boolean"}},
        "required": ["ok"],
        "additionalProperties": False,
    },
}

results: list[dict] = []


def rec(case: str, status: str, **detail) -> None:
    results.append({"case": case, "status": status, **detail})
    print(f"[{status}] {case}")


def redact(obj) -> str:
    text = json.dumps(obj, ensure_ascii=False, default=str, indent=2)
    key = os.environ.get("DEEPSEEK_API_KEY") or ""
    if key and key != "dummy-not-used":
        text = text.replace(key, "[REDACTED]")
    return text


async def sse_collect(client, body) -> dict:
    t0 = time.perf_counter()
    chunks = []
    times = []
    ctype = None
    status = None
    async with client.stream("POST", "/v1/chat/completions", json=body) as resp:
        status = resp.status_code
        ctype = resp.headers.get("content-type")
        async for line in resp.aiter_lines():
            if line.startswith("data:"):
                times.append(round((time.perf_counter() - t0) * 1000, 1))
                chunks.append(line[:240])
    return {
        "status_code": status,
        "content_type": ctype,
        "n": len(chunks),
        "times": times,
        "chunks": chunks,
        "total_ms": round((time.perf_counter() - t0) * 1000, 1),
    }


def summarize_records(payload: dict) -> list[dict]:
    out = []
    for x in payload.get("data") or []:
        attempts = x.get("attempts") or []
        out.append({
            "id": x.get("request_id"),
            "status": x.get("status"),
            "model": x.get("model"),
            "error": x.get("error_code"),
            "latency_ms": x.get("latency_ms"),
            "ttft_ms": x.get("ttft_ms"),
            "usage": x.get("usage"),
            "attempt_count": len(attempts),
            "attempt_ok": [a.get("ok") for a in attempts],
            "attempt_errors": [a.get("error_code") for a in attempts],
        })
    return out


async def run_offline(tmp: Path) -> None:
    settings = make_settings(
        tmp / "data",
        rpm=60,
        tpm=600_000,
        max_attempts=3,
        base_delay=0.05,
        deadline=8.0,
        attempt=2.0,
        first_token=3.0,
        stream_idle=3.0,
    )
    # equal jitter so delay is deterministic
    settings.retry.jitter = "equal"
    h = await build_harness(tmp / "data", settings)
    client, mock = h.client, h.mock_client
    try:
        # A02 / A03 normal + protocol capture
        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            r = await client.post("/v1/chat/completions", json={
                "model": model,
                "messages": [{"role": "user", "content": "say hi"}],
            })
            body = r.json()
            rec("A02-" + model, "pass" if r.status_code == 200 and body.get("content") and body.get("model") == model else "fail",
                status_code=r.status_code, model=body.get("model"), content=str(body.get("content"))[:80],
                usage=body.get("usage"), latency_ms=body.get("latency_ms"), id=body.get("id"))

        snap = (await mock.get("/_mock/_control")).json()
        paths = []
        for item in snap.get("requests") or []:
            paths.append({
                "path": item.get("path") or item.get("url"),
                "keys": sorted((item.get("body") or {}).keys()) if isinstance(item.get("body"), dict) else None,
                "model": (item.get("body") or {}).get("model") if isinstance(item.get("body"), dict) else None,
                "auth": sorted((item.get("headers") or {}).keys()) if isinstance(item.get("headers"), dict) else None,
            })
        rec("A03-mock-requests", "info", n=len(snap.get("requests") or []), sample_keys=list((snap.get("requests") or [{}])[0].keys()) if snap.get("requests") else [], paths=paths[:6])
        # dump one raw request shape (no secrets in mock)
        if snap.get("requests"):
            rec("A03-first-request", "info", request=snap["requests"][0])
            rec("A03-second-request", "info", request=snap["requests"][1] if len(snap["requests"]) > 1 else None)

        # A04
        r = await client.post("/v1/chat/completions", json={
            "model": "no-such-model",
            "messages": [{"role": "user", "content": "hi"}],
        })
        rec("A04", "pass" if r.status_code == 404 and "GW_MODEL_NOT_FOUND" in r.text else "fail",
            status_code=r.status_code, body=r.text[:240])

        # response_format rejected at unified entry
        r = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "hi"}],
            "response_format": {"type": "json_object"},
        })
        rec("entry-response_format", "observed", status_code=r.status_code, body=r.text[:280])

        # F03 structured both protocols
        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            r = await client.post("/v1/chat/completions", json={
                "model": model,
                "messages": [{"role": "user", "content": "return ok true"}],
                "output_schema": SCHEMA,
            })
            body = r.json()
            parsed = None
            err = None
            if r.status_code == 200:
                try:
                    parsed = json.loads(body.get("content") or "")
                except Exception as exc:
                    err = str(exc)
            rec("F03-" + model, "pass" if isinstance(parsed, dict) and "ok" in parsed else "fail",
                status_code=r.status_code, parsed=parsed, err=err, body=r.text[:300])

        # capture structured upstream bodies
        snap = (await mock.get("/_mock/_control")).json()
        structured = []
        for item in snap.get("requests") or []:
            body = item.get("body") or {}
            if not isinstance(body, dict):
                continue
            if "text" in body or "tools" in body or "response_format" in body:
                structured.append({
                    "path": item.get("path"),
                    "model": body.get("model"),
                    "text_format": (body.get("text") or {}).get("format") if isinstance(body.get("text"), dict) else None,
                    "tools": body.get("tools"),
                    "tool_choice": body.get("tool_choice"),
                    "response_format": body.get("response_format"),
                    "max_output_tokens": body.get("max_output_tokens"),
                    "max_tokens": body.get("max_tokens"),
                })
        rec("F03-upstream-bodies", "info", structured=structured)

        # F01 streaming both
        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            got = await sse_collect(client, {
                "model": model, "stream": True,
                "messages": [{"role": "user", "content": "count to three"}],
            })
            ok = (
                got["status_code"] == 200
                and got["content_type"]
                and "text/event-stream" in got["content_type"]
                and got["n"] >= 2
            )
            rec("F01-" + model, "pass" if ok else "fail", **{k: got[k] for k in ("status_code", "content_type", "n", "times", "total_ms")}, chunks=got["chunks"][:8])

        # F05 templates v1/v2
        r = await client.post("/v1/prompts", json={
            "name": "greet",
            "content": "Hello {{name}}, v1",
            "variables": ["name"],
        })
        rec("F05-create", "pass" if r.status_code == 200 else "fail", status_code=r.status_code, body=r.text[:200])
        r = await client.post("/v1/prompts/greet/versions", json={
            "content": "Hello {{name}}, v2",
            "variables": ["name"],
        })
        rec("F05-v2", "pass" if r.status_code == 200 else "fail", status_code=r.status_code, body=r.text[:200])
        r1 = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "go"}],
            "prompt": {"name": "greet", "version": 1, "vars": {"name": "Ada"}},
        })
        r2 = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "go"}],
            "prompt": {"name": "greet", "version": 2, "vars": {"name": "Ada"}},
        })
        snap = (await mock.get("/_mock/_control")).json()
        rendered = []
        for item in (snap.get("requests") or [])[-2:]:
            body = item.get("body") or {}
            rendered.append(json.dumps(body.get("input") or body.get("messages") or body.get("system"), ensure_ascii=False)[:300])
        rec("F05-render", "observed", v1_status=r1.status_code, v2_status=r2.status_code, rendered=rendered)

        # F06 missing template / var
        missing = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "go"}],
            "prompt": {"name": "nope", "vars": {}},
        })
        novar = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "go"}],
            "prompt": {"name": "greet", "version": 1, "vars": {}},
        })
        rec("F06-missing", "observed",
            template_status=missing.status_code, template_body=missing.text[:220],
            var_status=novar.status_code, var_body=novar.text[:220])

        # F08 retry then success: first 2 upstream calls 500
        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"fail": "500", "fail_times": 2})
        t0 = time.perf_counter()
        r = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "retry please"}],
        })
        elapsed = round(time.perf_counter() - t0, 3)
        snap = (await mock.get("/_mock/_control")).json()
        rec("F08-retry-success", "observed", status_code=r.status_code, elapsed=elapsed,
            calls=snap.get("calls"), body=r.text[:240])

        # F09 persistent 401 and 400
        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"fail": "401"})
        t0 = time.perf_counter()
        r401 = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "auth"}],
        })
        snap = (await mock.get("/_mock/_control")).json()
        rec("F09-401", "observed", status_code=r401.status_code, elapsed=round(time.perf_counter() - t0, 3),
            calls=snap.get("calls"), body=r401.text[:280])

        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"fail": "400"})
        t0 = time.perf_counter()
        r400 = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "bad"}],
        })
        snap = (await mock.get("/_mock/_control")).json()
        rec("F09-400", "observed", status_code=r400.status_code, elapsed=round(time.perf_counter() - t0, 3),
            calls=snap.get("calls"), body=r400.text[:280])

        # F04 bad json / schema violation / empty-ish
        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"content": "bad_json", "content_times": 5})
        r = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "json"}],
            "output_schema": SCHEMA,
        })
        snap = (await mock.get("/_mock/_control")).json()
        rec("F04-bad-json", "observed", status_code=r.status_code, calls=snap.get("calls"), body=r.text[:360])

        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"content": "schema_violation", "content_times": 5})
        r = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "json"}],
            "output_schema": SCHEMA,
        })
        rec("F04-schema", "observed", status_code=r.status_code, body=r.text[:360])

        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"content": "markdown_json", "content_times": 1})
        r = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "json"}],
            "output_schema": SCHEMA,
        })
        parsed = None
        if r.status_code == 200:
            try:
                parsed = json.loads(r.json().get("content") or "")
            except Exception as exc:
                parsed = f"PARSE {exc}"
        rec("F04-fence-repair", "observed", status_code=r.status_code, parsed=parsed, body=r.text[:300])

        # strict false: illegal JSON still success?
        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"content": "bad_json", "content_times": 1})
        r = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "json"}],
            "output_schema": {**SCHEMA, "strict": False},
        })
        rec("F04-strict-false", "observed", status_code=r.status_code, body=r.text[:300])

        # F02 stream error and break
        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"fail": "stream_error", "fail_times": 1})
        got = await sse_collect(client, {
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "stream fail"}],
        })
        rec("F02-stream-error", "observed", status_code=got["status_code"], n=got["n"], chunks=got["chunks"])

        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"break_after": 1})
        got = await sse_collect(client, {
            "model": "deepseek-v4-flash", "stream": True,
            "messages": [{"role": "user", "content": "break"}],
        })
        rec("F02-break-after", "observed", status_code=got["status_code"], n=got["n"], chunks=got["chunks"])

        # gate: delay first chunk to prove incremental (chunk_delay)
        await mock.post("/_mock/_control", json={"reset": True})
        await mock.post("/_mock/_control", json={"chunk_delay": 0.4})
        got = await sse_collect(client, {
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "slow"}],
        })
        deltas = []
        if len(got["times"]) >= 2:
            deltas = [round(got["times"][i] - got["times"][i - 1], 1) for i in range(1, min(4, len(got["times"])))]
        rec("F01-incremental", "observed", times=got["times"][:8], deltas=deltas, n=got["n"], chunks=got["chunks"][:4])

        recs = (await client.get("/v1/requests?limit=50")).json()
        rec("records", "info", summary=summarize_records(recs))
    finally:
        await client.aclose()
        await mock.aclose()


async def run_ratelimit(tmp: Path) -> None:
    settings = make_settings(tmp / "rl", rpm=2, tpm=500_000, max_attempts=1, base_delay=0.01)
    h = await build_harness(tmp / "rl", settings)
    client = h.client
    try:
        codes = []
        bodies = []
        for i in range(3):
            r = await client.post("/v1/chat/completions", json={
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": f"rl {i}"}],
            })
            codes.append(r.status_code)
            bodies.append(r.text[:220])
        other = await client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-flash",
            "messages": [{"role": "user", "content": "other"}],
        })
        rec("F10", "observed", pro_codes=codes, pro_bodies=bodies, flash_status=other.status_code, flash_body=other.text[:180])
        # same caller other model independence already checked; also a second caller if auth off is anonymous only
        remaining = h.app.state.gateway.limiter.remaining("anonymous", "deepseek-v4-flash")
        rec("F10-remaining-flash", "info", remaining=remaining)
    finally:
        await client.aclose()
        await h.mock_client.aclose()


async def run_real() -> None:
    if not os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("DEEPSEEK_API_KEY") == "dummy-not-used":
        rec("real", "unverified", reason="DEEPSEEK_API_KEY unset")
        return
    data = Path("/tmp/lgw-accept-real")
    data.mkdir(parents=True, exist_ok=True)
    models = {
        "deepseek-v4-pro": {
            "base_url": "https://api.deepseek.com",
            "upstream_id": "deepseek-v4-pro",
            "api_key_env": "DEEPSEEK_API_KEY",
            "enabled": True,
            "default_max_tokens": 64,
            "rate_limit": {"rpm": 20, "tpm": 20000},
        },
        "deepseek-v4-flash": {
            "base_url": "https://api.deepseek.com/anthropic",
            "upstream_id": "deepseek-flash",
            "api_key_env": "DEEPSEEK_API_KEY",
            "enabled": True,
            "default_max_tokens": 64,
            "rate_limit": {"rpm": 20, "tpm": 20000},
        },
    }
    from core.config import Settings
    settings = Settings.model_validate({
        "storage": {"data_dir": str(data)},
        "retry": {"max_attempts": 1, "base_delay": 0.2, "max_delay": 1.0, "jitter": "equal"},
        "timeout": {"deadline": 40.0, "attempt": 30.0, "first_token": 30.0, "stream_idle": 30.0, "connect": 10.0, "write": 10.0},
        "auth": {"enabled": False, "keys": []},
        "models": models,
    })
    app = create_app(settings, http_client=httpx.AsyncClient(timeout=40))
    client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://gw", timeout=45)
    try:
        gw = app.state.gateway
        for alias, adapter in gw.adapters.items():
            req = LLMRequest(model=alias, messages=[UnifiedMessage(role="user", content="hi")], output_schema=SCHEMA)
            call = adapter.prepare(req)
            headers = {}
            for k, v in call.upstream.headers.items():
                if k.lower() in ("authorization", "x-api-key"):
                    headers[k] = "[REDACTED]"
                else:
                    headers[k] = v
            body = call.upstream.body
            rec("A03-real-prepare-" + alias, "info",
                protocol=adapter.provider.protocol,
                url=call.upstream.url,
                headers=headers,
                model=body.get("model"),
                body_keys=sorted(body.keys()),
                text_format_type=((body.get("text") or {}).get("format") or {}).get("type") if isinstance(body.get("text"), dict) else None,
                has_tools="tools" in body,
                tool_choice=body.get("tool_choice"),
                max_output_tokens=body.get("max_output_tokens"),
                max_tokens=body.get("max_tokens"))

        prompt = "Reply with exactly the word pong."
        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            t0 = time.perf_counter()
            try:
                r = await client.post("/v1/chat/completions", json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                })
                body = r.json()
                rec("REAL-normal-" + model,
                    "pass" if r.status_code == 200 and body.get("content") else "fail",
                    status_code=r.status_code,
                    elapsed=round(time.perf_counter() - t0, 2),
                    content=str(body.get("content"))[:120],
                    finish=body.get("finish_reason"),
                    usage=body.get("usage"),
                    latency_ms=body.get("latency_ms"),
                    ttft_ms=body.get("ttft_ms"),
                    error=body.get("error"))
            except Exception as exc:
                rec("REAL-normal-" + model, "unverified", error=type(exc).__name__, detail=str(exc)[:300])

        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            try:
                got = await sse_collect(client, {
                    "model": model, "stream": True,
                    "messages": [{"role": "user", "content": "Reply with exactly: stream-ok"}],
                })
                text = "".join(
                    json.loads(c[5:].strip()).get("text", "")
                    for c in got["chunks"]
                    if '"text_delta"' in c or '"reasoning_delta"' in c
                )
                rec("REAL-stream-" + model,
                    "pass" if got["status_code"] == 200 and got["n"] >= 2 and "text/event-stream" in (got["content_type"] or "") else "fail",
                    status_code=got["status_code"], content_type=got["content_type"], n=got["n"],
                    times=got["times"][:10], total_ms=got["total_ms"],
                    text=text[:80], chunks=got["chunks"][:8])
            except Exception as exc:
                rec("REAL-stream-" + model, "unverified", error=type(exc).__name__, detail=str(exc)[:300])

        for model in ("deepseek-v4-pro", "deepseek-v4-flash"):
            try:
                r = await client.post("/v1/chat/completions", json={
                    "model": model,
                    "messages": [{"role": "user", "content": "Set ok to true."}],
                    "output_schema": SCHEMA,
                })
                body = r.json()
                parsed = None
                perr = None
                if isinstance(body.get("content"), str):
                    try:
                        parsed = json.loads(body["content"])
                    except Exception as exc:
                        perr = str(exc)
                rec("REAL-struct-" + model,
                    "pass" if r.status_code == 200 and isinstance(parsed, dict) and parsed.get("ok") is True else "fail",
                    status_code=r.status_code, parsed=parsed, parse_err=perr,
                    finish=body.get("finish_reason"), usage=body.get("usage"),
                    error=body.get("error"), content=str(body.get("content"))[:200])
            except Exception as exc:
                rec("REAL-struct-" + model, "unverified", error=type(exc).__name__, detail=str(exc)[:400])

        recs = (await client.get("/v1/requests?limit=20")).json()
        rec("REAL-records", "info", summary=summarize_records(recs))
    finally:
        await client.aclose()
        await app.state.gateway.client.client.aclose()


async def main() -> None:
    mode = sys.argv[1] if len(sys.argv) > 1 else "offline"
    tmp = Path("/tmp/lgw-accept")
    tmp.mkdir(parents=True, exist_ok=True)
    try:
        if mode in ("offline", "all"):
            await run_offline(tmp)
            await run_ratelimit(tmp)
        if mode in ("real", "all"):
            await run_real()
    except Exception:
        traceback.print_exc()
        rec("crash", "fail", trace=traceback.format_exc()[-1000:])
    path = OUT / f"accept-{mode}.json"
    path.write_text(redact(results), encoding="utf-8")
    print("WROTE", path, "cases", len(results))


if __name__ == "__main__":
    asyncio.run(main())
