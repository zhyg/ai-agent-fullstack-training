#!/usr/bin/env python3
"""Targeted fault probes. Does not modify student code."""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

STUDENT = Path("/home/user/workspace/repo/.amp/in/orb-backup/student/llm-gateway")
sys.path.insert(0, str(STUDENT))
os.chdir(STUDENT)
os.environ.setdefault("MINIMAX_API_KEY", "dummy-not-used")

import httpx
from fastapi import FastAPI

from core.config import Settings
from main import create_app
from tests.conftest import StreamingASGITransport, build_harness, make_settings
from upstream.mock_server import create_mock_router, reset_mock_state

OUT = Path("/home/user/workspace/repo/.amp/in/week-grading/probe/logs")
OUT.mkdir(parents=True, exist_ok=True)
results = []


def rec(case, status, **detail):
    results.append({"case": case, "status": status, **detail})
    print(f"[{status}] {case}")


async def sse(client, body):
    chunks = []
    async with client.stream("POST", "/v1/chat/completions", json=body) as resp:
        async for line in resp.aiter_lines():
            if line.startswith("data:"):
                chunks.append(line[:300])
        return resp.status_code, resp.headers.get("content-type"), chunks


async def main():
    tmp = Path("/tmp/lgw-faults")
    tmp.mkdir(exist_ok=True)

    # 1. stream error event on chat-completions protocol (minimax adapter)
    reset_mock_state()
    settings = make_settings(tmp / "chat", rpm=30, tpm=200000, max_attempts=3, base_delay=0.01)
    h = await build_harness(tmp / "chat", settings)
    try:
        await h.mock_client.post("/_mock/_control", json={"fail": "stream_error"})
        code, ctype, chunks = await sse(h.client, {
            "model": "minimax-m2.7",
            "stream": True,
            "messages": [{"role": "user", "content": "fail stream"}],
        })
        snap = (await h.mock_client.get("/_mock/_control")).json()
        rec("stream-error-chat", "observed", status_code=code, content_type=ctype,
            calls=snap.get("calls"), chunks=chunks[:8])
        recs = (await h.client.get("/v1/requests?limit=5")).json()
        last = (recs.get("data") or [{}])[0]
        rec("stream-error-record", "info", record_status=last.get("status"), error=last.get("error_code"),
            attempts=len(last.get("attempts") or []), ttft=last.get("ttft_ms"))
    finally:
        await h.client.aclose()
        await h.mock_client.aclose()

    # 2. EOF after content, no success terminal, on responses protocol
    reset_mock_state()
    settings = make_settings(tmp / "eof", rpm=30, tpm=200000, max_attempts=2, base_delay=0.01)
    h = await build_harness(tmp / "eof", settings)
    try:
        await h.mock_client.post("/_mock/_control", json={"break_after": 1})
        code, ctype, chunks = await sse(h.client, {
            "model": "deepseek-v4-pro",
            "stream": True,
            "messages": [{"role": "user", "content": "break"}],
        })
        rec("eof-after-delta-responses", "observed", status_code=code, chunks=chunks)
        recs = (await h.client.get("/v1/requests?limit=3")).json()
        last = (recs.get("data") or [{}])[0]
        rec("eof-record", "info", record_status=last.get("status"), error=last.get("error_code"),
            ttft=last.get("ttft_ms"), usage=last.get("usage"), attempts=last.get("attempts"))
    finally:
        await h.client.aclose()
        await h.mock_client.aclose()

    # 3. heartbeat / empty delta should not be TTFT: comment line then delayed text
    # Inject via a tiny local upstream, not student code.
    app_up = FastAPI()

    @app_up.post("/v1/responses")
    async def fake_responses():
        async def gen():
            yield ": keep-alive\n\n"
            yield "event: response.created\ndata: {\"type\":\"response.created\"}\n\n"
            await asyncio.sleep(0.4)
            yield "event: response.output_text.delta\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"Hi\"}\n\n"
            await asyncio.sleep(0.05)
            yield "event: response.completed\ndata: {\"type\":\"response.completed\",\"response\":{\"id\":\"r1\",\"status\":\"completed\",\"usage\":{\"input_tokens\":3,\"output_tokens\":1,\"total_tokens\":4}}}\n\n"
        return httpx.Response  # placeholder to satisfy linters

    # use StreamingResponse
    from fastapi.responses import StreamingResponse

    # redefine properly
    routes_added = True

    upstream = FastAPI()

    @upstream.post("/v1/responses")
    async def responses():
        async def gen():
            yield ": heartbeat\n\n"
            yield "event: response.created\ndata: {\"type\":\"response.created\",\"response\":{\"id\":\"r1\"}}\n\n"
            await asyncio.sleep(0.35)
            yield "event: response.output_text.delta\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"Hi\"}\n\n"
            yield "event: response.completed\ndata: {\"type\":\"response.completed\",\"response\":{\"id\":\"r1\",\"model\":\"deepseek-v4-pro\",\"status\":\"completed\",\"usage\":{\"input_tokens\":3,\"output_tokens\":1,\"total_tokens\":4}}}\n\n"
        return StreamingResponse(gen(), media_type="text/event-stream")

    @upstream.post("/v1/messages")
    async def messages(request: httpx.Request):
        return {"ok": True}

    settings = Settings.model_validate({
        "storage": {"data_dir": str(tmp / "hb")},
        "retry": {"max_attempts": 1, "base_delay": 0.01, "max_delay": 0.05, "jitter": "equal"},
        "timeout": {"deadline": 8, "attempt": 4, "first_token": 5, "stream_idle": 5, "connect": 2, "write": 2},
        "auth": {"enabled": False, "keys": []},
        "models": {
            "deepseek-v4-pro": {
                "base_url": "http://up.test",
                "upstream_id": "deepseek-v4-pro",
                "enabled": True,
                "rate_limit": {"rpm": 20, "tpm": 100000},
            }
        },
    })
    (tmp / "hb").mkdir(exist_ok=True)
    up_client = httpx.AsyncClient(transport=StreamingASGITransport(upstream), base_url="http://up.test")
    app = create_app(settings, http_client=up_client)
    client = httpx.AsyncClient(transport=StreamingASGITransport(app), base_url="http://gw")
    try:
        t0 = time.perf_counter()
        times = []
        chunks = []
        async with client.stream("POST", "/v1/chat/completions", json={
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "hi"}],
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    times.append(round((time.perf_counter() - t0) * 1000, 1))
                    chunks.append(line[:180])
        recs = (await client.get("/v1/requests?limit=3")).json()
        last = (recs.get("data") or [{}])[0]
        rec("heartbeat-ttft", "observed", times=times, chunks=chunks, ttft=last.get("ttft_ms"),
            record_status=last.get("status"), latency=last.get("latency_ms"))
    finally:
        await client.aclose()
        await up_client.aclose()

    # 4. empty delta then text: does TTFT attach to empty?
    upstream2 = FastAPI()

    @upstream2.post("/v1/responses")
    async def responses2():
        async def gen():
            yield "event: response.output_text.delta\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"\"}\n\n"
            await asyncio.sleep(0.3)
            yield "event: response.output_text.delta\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"Yo\"}\n\n"
            yield "event: response.completed\ndata: {\"type\":\"response.completed\",\"response\":{\"id\":\"r2\",\"status\":\"completed\",\"usage\":{\"input_tokens\":2,\"output_tokens\":1,\"total_tokens\":3}}}\n\n"
        return StreamingResponse(gen(), media_type="text/event-stream")

    settings2 = Settings.model_validate({
        "storage": {"data_dir": str(tmp / "empty")},
        "retry": {"max_attempts": 1, "base_delay": 0.01, "max_delay": 0.05, "jitter": "equal"},
        "timeout": {"deadline": 8, "attempt": 4, "first_token": 5, "stream_idle": 5, "connect": 2, "write": 2},
        "auth": {"enabled": False, "keys": []},
        "models": {
            "deepseek-v4-pro": {
                "base_url": "http://up.test",
                "upstream_id": "deepseek-v4-pro",
                "enabled": True,
                "rate_limit": {"rpm": 20, "tpm": 100000},
            }
        },
    })
    (tmp / "empty").mkdir(exist_ok=True)
    up2 = httpx.AsyncClient(transport=StreamingASGITransport(upstream2), base_url="http://up.test")
    app2 = create_app(settings2, http_client=up2)
    c2 = httpx.AsyncClient(transport=StreamingASGITransport(app2), base_url="http://gw")
    try:
        t0 = time.perf_counter()
        times = []
        chunks = []
        async with c2.stream("POST", "/v1/chat/completions", json={
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "hi"}],
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    times.append(round((time.perf_counter() - t0) * 1000, 1))
                    chunks.append(line[:160])
        recs = (await c2.get("/v1/requests?limit=3")).json()
        last = (recs.get("data") or [{}])[0]
        rec("empty-delta-ttft", "observed", times=times, chunks=chunks, ttft=last.get("ttft_ms"), record_status=last.get("status"))
    finally:
        await c2.aclose()
        await up2.aclose()

    # 5. positive jitter can exceed cap? check delay_for distribution
    from resilience.retry import RetryPolicy
    from core.config import RetryConfig
    policy = RetryPolicy(RetryConfig(base_delay=0.5, max_delay=8.0, max_attempts=3, jitter="full"))
    samples = [policy.delay_for(1), policy.delay_for(2), policy.delay_for(3)]
    overs = 0
    for n in (1, 2, 3):
        cap = min(0.5 * (2 ** (n - 1)), 8.0)
        for _ in range(200):
            d = policy.delay_for(n)
            if d > cap + 1e-9:
                overs += 1
    rec("jitter-cap", "observed", sample=samples, overs_in_600=overs)

    # 6. missing usage on failure: 500 then success, usage of failed attempt
    reset_mock_state()
    settings = make_settings(tmp / "usagefail", rpm=30, tpm=200000, max_attempts=3, base_delay=0.01)
    h = await build_harness(tmp / "usagefail", settings)
    try:
        await h.mock_client.post("/_mock/_control", json={"fail": "500", "fail_times": 1})
        r = await h.client.post("/v1/chat/completions", json={
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "usage"}],
        })
        recs = (await h.client.get("/v1/requests?limit=3")).json()
        last = (recs.get("data") or [{}])[0]
        rec("fail-then-success-usage", "observed", http=r.status_code,
            record_status=last.get("status"), usage=last.get("usage"),
            attempts=[{
                "ok": a.get("ok"), "error": a.get("error_code"), "usage": a.get("usage")
            } for a in (last.get("attempts") or [])])
    finally:
        await h.client.aclose()
        await h.mock_client.aclose()

    # 7. quota recovery: rpm=1, wait refill
    settings = make_settings(tmp / "recover", rpm=60, tpm=100000, max_attempts=1)
    # rpm 60 refills 1/sec. Use rpm=60 and consume 60? too slow.
    # Token bucket capacity = rpm. Set rpm=1 so one call empties request bucket, refill 1/60 per sec.
    # That's 60s. Use a tiny custom limiter instead by constructing settings rpm=2 and checking retry_after, then monkeypatch clock? 
    # We can call limiter directly after lowering capacity via remaining wait from 429 body.
    h = await build_harness(tmp / "recover", make_settings(tmp / "recover", rpm=1, tpm=100000, max_attempts=1))
    try:
        r1 = await h.client.post("/v1/chat/completions", json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "a"}]})
        r2 = await h.client.post("/v1/chat/completions", json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "b"}]})
        body = r2.json()
        retry_after = ((body.get("error") or {}).get("details") or {}).get("retry_after")
        rec("quota-before-wait", "observed", first=r1.status_code, second=r2.status_code, retry_after=retry_after, header=r2.headers.get("retry-after"))
        # don't wait 60s; advance by calling bucket refill math: sleep min(retry_after, 2) only if small
        if retry_after and retry_after < 3:
            await asyncio.sleep(retry_after + 0.05)
            r3 = await h.client.post("/v1/chat/completions", json={"model": "deepseek-v4-pro", "messages": [{"role": "user", "content": "c"}]})
            rec("quota-after-wait", "observed", status=r3.status_code)
        else:
            rec("quota-after-wait", "skipped", reason=f"retry_after={retry_after} too long for this probe; recovery math not executed")
    finally:
        await h.client.aclose()
        await h.mock_client.aclose()

    path = OUT / "faults.json"
    path.write_text(json.dumps(results, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print("WROTE", path)


if __name__ == "__main__":
    asyncio.run(main())
