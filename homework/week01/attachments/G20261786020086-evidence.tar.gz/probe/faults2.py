#!/usr/bin/env python3
"""Finish the fault cases that faults.py crashed before writing."""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

STUDENT = Path("/home/user/workspace/repo/.amp/in/orb-backup/student/llm-gateway")
sys.path.insert(0, str(STUDENT))
os.chdir(STUDENT)
os.environ.setdefault("MINIMAX_API_KEY", "dummy-not-used")

import httpx
from fastapi import FastAPI
from fastapi.responses import StreamingResponse

from core.config import RetryConfig, Settings
from main import create_app
from resilience.retry import RetryPolicy
from tests.conftest import StreamingASGITransport, build_harness, make_settings
from upstream.mock_server import reset_mock_state

OUT = Path("/home/user/workspace/repo/.amp/in/week-grading/probe/logs")
results = []


def rec(case, status, **detail):
    results.append({"case": case, "status": status, **detail})
    print(f"[{status}] {case}")


async def main():
    tmp = Path("/tmp/lgw-faults2")
    tmp.mkdir(exist_ok=True)

    reset_mock_state()
    h = await build_harness(tmp / "chat", make_settings(tmp / "chat", rpm=30, tpm=200000, max_attempts=3, base_delay=0.01))
    try:
        await h.mock_client.post("/_mock/_control", json={"fail": "stream_error"})
        chunks = []
        async with h.client.stream("POST", "/v1/chat/completions", json={
            "model": "minimax-m2.7", "stream": True,
            "messages": [{"role": "user", "content": "fail stream"}],
        }) as resp:
            code = resp.status_code
            ctype = resp.headers.get("content-type")
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    chunks.append(line[:300])
        snap = (await h.mock_client.get("/_mock/_control")).json()
        rec("stream-error-chat", "observed", status_code=code, content_type=ctype, calls=snap.get("calls"), chunks=chunks[:8])
        recs = (await h.client.get("/v1/requests?limit=5")).json()
        last = (recs.get("data") or [{}])[0]
        rec("stream-error-record", "info", record_status=last.get("status"), error=last.get("error_code"),
            attempts=len(last.get("attempts") or []), ttft=last.get("ttft_ms"))
    finally:
        await h.client.aclose(); await h.mock_client.aclose()

    reset_mock_state()
    h = await build_harness(tmp / "eof", make_settings(tmp / "eof", rpm=30, tpm=200000, max_attempts=2, base_delay=0.01))
    try:
        await h.mock_client.post("/_mock/_control", json={"break_after": 1})
        chunks = []
        async with h.client.stream("POST", "/v1/chat/completions", json={
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "break"}],
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    chunks.append(line[:280])
        rec("eof-after-delta", "observed", chunks=chunks)
        recs = (await h.client.get("/v1/requests?limit=3")).json()
        last = (recs.get("data") or [{}])[0]
        rec("eof-record", "info", record_status=last.get("status"), error=last.get("error_code"),
            ttft=last.get("ttft_ms"), usage=last.get("usage"))
    finally:
        await h.client.aclose(); await h.mock_client.aclose()

    upstream = FastAPI()

    @upstream.post("/v1/responses")
    async def responses():
        async def gen():
            yield ": heartbeat\n\n"
            yield 'event: response.created\ndata: {"type":"response.created","response":{"id":"r1"}}\n\n'
            await asyncio.sleep(0.35)
            yield 'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"Hi"}\n\n'
            yield 'event: response.completed\ndata: {"type":"response.completed","response":{"id":"r1","model":"deepseek-v4-pro","status":"completed","usage":{"input_tokens":3,"output_tokens":1,"total_tokens":4}}}\n\n'
        return StreamingResponse(gen(), media_type="text/event-stream")

    (tmp / "hb").mkdir(exist_ok=True)
    settings = Settings.model_validate({
        "storage": {"data_dir": str(tmp / "hb")},
        "retry": {"max_attempts": 1, "base_delay": 0.01, "max_delay": 0.05, "jitter": "equal"},
        "timeout": {"deadline": 8, "attempt": 4, "first_token": 5, "stream_idle": 5, "connect": 2, "write": 2},
        "auth": {"enabled": False, "keys": []},
        "models": {"deepseek-v4-pro": {"base_url": "http://up.test", "upstream_id": "deepseek-v4-pro", "enabled": True, "rate_limit": {"rpm": 20, "tpm": 100000}}},
    })
    up_client = httpx.AsyncClient(transport=StreamingASGITransport(upstream), base_url="http://up.test")
    app = create_app(settings, http_client=up_client)
    client = httpx.AsyncClient(transport=StreamingASGITransport(app), base_url="http://gw")
    try:
        t0 = time.perf_counter()
        times, chunks = [], []
        async with client.stream("POST", "/v1/chat/completions", json={
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "hi"}],
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    times.append(round((time.perf_counter() - t0) * 1000, 1))
                    chunks.append(line[:160])
        last = ((await client.get("/v1/requests?limit=3")).json().get("data") or [{}])[0]
        rec("heartbeat-ttft", "observed", times=times, chunks=chunks, ttft=last.get("ttft_ms"), record_status=last.get("status"))
    finally:
        await client.aclose(); await up_client.aclose()

    upstream2 = FastAPI()

    @upstream2.post("/v1/responses")
    async def responses2():
        async def gen():
            yield 'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":""}\n\n'
            await asyncio.sleep(0.3)
            yield 'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"Yo"}\n\n'
            yield 'event: response.completed\ndata: {"type":"response.completed","response":{"id":"r2","status":"completed","usage":{"input_tokens":2,"output_tokens":1,"total_tokens":3}}}\n\n'
        return StreamingResponse(gen(), media_type="text/event-stream")

    (tmp / "empty").mkdir(exist_ok=True)
    settings2 = Settings.model_validate({
        "storage": {"data_dir": str(tmp / "empty")},
        "retry": {"max_attempts": 1, "base_delay": 0.01, "max_delay": 0.05, "jitter": "equal"},
        "timeout": {"deadline": 8, "attempt": 4, "first_token": 5, "stream_idle": 5, "connect": 2, "write": 2},
        "auth": {"enabled": False, "keys": []},
        "models": {"deepseek-v4-pro": {"base_url": "http://up.test", "upstream_id": "deepseek-v4-pro", "enabled": True, "rate_limit": {"rpm": 20, "tpm": 100000}}},
    })
    up2 = httpx.AsyncClient(transport=StreamingASGITransport(upstream2), base_url="http://up.test")
    app2 = create_app(settings2, http_client=up2)
    c2 = httpx.AsyncClient(transport=StreamingASGITransport(app2), base_url="http://gw")
    try:
        t0 = time.perf_counter()
        times, chunks = [], []
        async with c2.stream("POST", "/v1/chat/completions", json={
            "model": "deepseek-v4-pro", "stream": True,
            "messages": [{"role": "user", "content": "hi"}],
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    times.append(round((time.perf_counter() - t0) * 1000, 1))
                    chunks.append(line[:160])
        last = ((await c2.get("/v1/requests?limit=3")).json().get("data") or [{}])[0]
        rec("empty-delta-ttft", "observed", times=times, chunks=chunks, ttft=last.get("ttft_ms"), record_status=last.get("status"))
    finally:
        await c2.aclose(); await up2.aclose()

    policy = RetryPolicy(RetryConfig(base_delay=0.5, max_delay=8.0, max_attempts=3, jitter="full"))
    overs = 0
    for n in (1, 2, 3):
        cap = min(0.5 * (2 ** (n - 1)), 8.0)
        for _ in range(200):
            if policy.delay_for(n) > cap + 1e-9:
                overs += 1
    rec("jitter-cap", "observed", overs_in_600=overs, sample=[round(policy.delay_for(1), 4), round(policy.delay_for(2), 4)])

    # thinking disabled via extra_body, real call if key present
    key = os.environ.get("DEEPSEEK_API_KEY")
    if key and key != "dummy-not-used":
        (tmp / "think").mkdir(exist_ok=True)
        settings = Settings.model_validate({
            "storage": {"data_dir": str(tmp / "think")},
            "retry": {"max_attempts": 1, "base_delay": 0.1, "max_delay": 0.2, "jitter": "equal"},
            "timeout": {"deadline": 40, "attempt": 30, "first_token": 30, "stream_idle": 30, "connect": 10, "write": 10},
            "auth": {"enabled": False, "keys": []},
            "models": {
                "deepseek-v4-flash": {
                    "base_url": "https://api.deepseek.com/anthropic",
                    "upstream_id": "deepseek-flash",
                    "api_key_env": "DEEPSEEK_API_KEY",
                    "enabled": True,
                    "default_max_tokens": 64,
                    "rate_limit": {"rpm": 10, "tpm": 20000},
                    "extra_body": {"thinking": {"type": "disabled"}},
                }
            },
        })
        app = create_app(settings, http_client=httpx.AsyncClient(timeout=40))
        client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://gw", timeout=40)
        try:
            adapter = app.state.gateway.adapters["deepseek-v4-flash"]
            from core.types import LLMRequest, UnifiedMessage, OutputSchemaSpec
            req = LLMRequest(
                model="deepseek-v4-flash",
                messages=[UnifiedMessage(role="user", content="Set ok to true.")],
                output_schema={"name": "ping", "schema": {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"], "additionalProperties": False}},
            )
            call = adapter.prepare(req)
            body = dict(call.upstream.body)
            rec("thinking-disabled-body", "info", has_thinking="thinking" in body, thinking=body.get("thinking"), tool_choice=body.get("tool_choice"), max_tokens=body.get("max_tokens"))
            r = await client.post("/v1/chat/completions", json={
                "model": "deepseek-v4-flash",
                "messages": [{"role": "user", "content": "Set ok to true."}],
                "output_schema": {"name": "ping", "strict": True, "schema": {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"], "additionalProperties": False}},
            })
            payload = r.json()
            parsed = None
            if isinstance(payload.get("content"), str):
                try:
                    parsed = json.loads(payload["content"])
                except Exception as exc:
                    parsed = f"PARSE {exc}"
            rec("REAL-struct-flash-thinking-off", "pass" if r.status_code == 200 and isinstance(parsed, dict) and parsed.get("ok") is True else "fail",
                status_code=r.status_code, parsed=parsed, error=payload.get("error"), content=str(payload.get("content"))[:200], usage=payload.get("usage"))
        finally:
            await client.aclose()
            await app.state.gateway.client.client.aclose()
    else:
        rec("REAL-struct-flash-thinking-off", "unverified", reason="no key")

    path = OUT / "faults2.json"
    path.write_text(json.dumps(results, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print("WROTE", path)

if __name__ == "__main__":
    asyncio.run(main())
