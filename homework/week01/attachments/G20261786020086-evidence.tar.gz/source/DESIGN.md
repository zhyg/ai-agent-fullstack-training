# LLMGateway 设计文档

> 版本: v2.14
> 状态: 对外契约已确认，进入实现
>
> **v2.14 的变更**：补齐**上游密钥的供给方式**（见 §7.9）——这一轮**不改变
> `/v1/*` 的对外契约形状**，改的是**部署侧**：`config.toml` 早就写着「`.env` +
> `config.toml`」（§10），但代码里**从来没有 `.env` 加载器**，`api_key_env`
> 只能从进程环境变量取值。结果是：真实部署必须额外配环境变量，缺了就得到
> 一个含义模糊的 502 `GW_AUTH_ERROR`。v2.14 兑现这个欠账，并新增
> `api_key_file`（密钥文件，与 Docker / K8s secret 挂载天然契合）。
>
> 两条新机制：**① `.env` 自动加载**（不覆盖已有环境变量）；
> **② `api_key_file`**（读文件内容当密钥）。环境变量优先，文件兜底。
> 另外把「配了密钥来源却读不到」从**运行期 401** 提前到**启动期失败**——
> 与入站鉴权同一条纪律（§8.6.3）。
>
> **v2.13 的变更**：接入**真实上游**——MiniMax M2.7（OpenAI 兼容协议，见 §4.5）。
> 这一轮**不改变 `/v1/*` 的对外契约形状**，新增的是**协议层的一种**（Chat Completions）
> 与**模型层的一个**（MiniMax M2.7）：`providers/openai_chat_completions.py` +
> `adapters/models/minimax_m2_7.py`。协议细节全部由**真机探测**确定（见 §4.5.2），
> 不采信二手文档。
>
> 关键实测结论（**改写了原计划的结构化输出策略**）：MiniMax 接受
> `response_format`（HTTP 200）但**不执行**它——响应仍是散文。因此 MiniMax
> 走 `prompt_only`（实测产出符合 schema 的 JSON），**不是** `native`。详见 §5.2.3。
>
> **v2.12 的变更**：工作台新增**试调用页签**（见 §8.9）——在前端直接向
> `POST /v1/chat/completions` 发一次真实请求，把**请求契约本身**（而不是它的
> 运行结果）可视化出来：SSE 帧序列、错误信封原文、耗时与 request id。
> 这一轮**仍不新增任何后端接口、不改变 `/v1/*` 的契约形状**：工作台只是
> `POST /v1/chat/completions` 的一个消费者。
>
> **v2.11 的变更**：新增**前端工作台**（只读可观测面板，见 §8.8）——把后台已有的
> 调用记录、指标、模型能力、提示词模板以可视化方式呈现。这一轮**不新增任何业务接口**，
> **不改变 `/v1/*` 的契约形状**：工作台只是现有只读端点的一个消费者。
> 后端唯一的改动是把静态页面挂到 `/console` 并让 `/` 跳转过去。
>
> **v2.6 ~ v2.9 的变更**分别落在各自的章节里：站点鉴权（§8.6）、多租户（§7.6 / §8.7）、
> 定价与成本（§7.7）、多上游 failover 与熔断（§7.8）。
>
> **v2.10 的变更**：**修正实现与规范不一致的地方**。这一轮不新增能力，只把
> 已经写在规范里、但代码没兑现（或兑现得不对）的语义补齐：
> 上游 4xx 不再复用 `GW_INVALID_REQUEST`（新增 `GW_UPSTREAM_REJECTED`，
> 见 §7.1）、`timeout.first_token` 真正生效、流式不再沿用总 deadline、
> 重试预算把 `attempt_timeout` 算进去、流式也结算限流预扣、
> `penalize_on_upstream_429` 真正接线、限流桶加锁、本地 429 补 `Retry-After` 头。
>
> **v2.0 的核心变更**：对外契约从「OpenAI Chat Completions 兼容」改为
> **网关自有的厂商中立契约**（见 §8）。调用方不再需要知道背后是 OpenAI、
> Anthropic 还是别的厂商，**只指定 `model`**；做不到的组合一律**显式拒绝**，
> 绝不静默降级。
>
> **v2.1 的变更**：请求契约进一步收窄——**不暴露采样旋钮与输出上限**
> （`temperature` / `top_p` / `stop` / `seed` / `n` / `max_output_tokens` 传了即 400，
> 理由见 §4.1）。输出上限改为网关按模型能力决定，通过
> `GET /v1/models` 的 `capabilities.max_output_tokens` 声明。
>
> **v2.2 的变更**：`messages[].content` 增加**长度上限 20000 字符**，
> 超出即 400 `GW_INVALID_REQUEST`（见 §8.1.1）。
>
> **v2.3 的变更**：**请求契约的入参校验补全**——`model` / `messages` / `output_schema` /
> `prompt` / `metadata` 全部补上长度、数量、取值域约束（见 §8.1.1）。
> 其中 `metadata` 的值类型从「任意 JSON」收紧为**字符串**。
>
> **v2.4 的变更**：**`stream` 与 `output_schema` 互斥**——两者同时出现即
> 400 `GW_INVALID_REQUEST`（见 §8.1.1）。这推翻了 v2.0 里「流式也做流尾 schema
> 校验」的决定，理由见 §5.1。
>
> **v2.5 的变更**：**响应头契约**（`X-Request-ID` / `Cache-Control` /
> `X-Accel-Buffering`，见 §8.1.4）与**客户端断开即取消上游**（见 §5.1）。
> 两者都**不改变请求体与响应体的形状**，只补语义与可观测口径：
> 调用记录新增 `status = "cancelled"`，`/v1/metrics` 新增 `cancelled` 计数。

> **命名约定**：本项目中 `Adapter` 指**模型层**（一个模型的知识），`Provider` 指**协议层**（一种 API 协议的翻译知识）。
> 这与社区惯例相反（社区里 adapter 通常指协议翻译），阅读代码时请注意。

---

## 1. 目标与范围

构建一个 LLM 统一模型调用服务（LLMGateway），对外提供单一入口，内部按 `model` 字段动态路由到对应模型的适配器，由适配器组合对应协议的 Provider，屏蔽底层差异。

**协议组合（训练目标）**

| 模型别名 | 适配器（模型层） | Provider（协议层） |
|---|---|---|
| `deepseek-v4-pro` | `DeepSeekV4ProAdapter` | `OpenAIResponsesProvider` |
| `deepseek-v4-flash` | `DeepSeekV4FlashAdapter` | `AnthropicMessagesProvider` |
| `minimax-m2.7` | `MiniMaxM27Adapter` | `OpenAIChatCompletionsProvider` |

前两个别名均为**纯配置别名**，指向内置 Mock 上游；后续接真实 DeepSeek 端点时只需改 `base_url` 与 `upstream_id` 映射，无需改动任何业务代码。

第三个别名 `minimax-m2.7` 是**第一个指向真实厂商端点**的模型：`base_url` 指向
`https://api.minimaxi.com`，密钥走环境变量 `MINIMAX_API_KEY`（见 §4.5）。

### 1.1 范围内

- 统一抽象层（Provider 协议层 + Adapter 模型层，组合式分层）
- 流式输出（SSE）
- 结构化输出（JSON Schema 约束）
- 提示词版本管理（模板存储 / 变量替换 / 版本引用）
- 可观测性（Token 分类统计 + 延迟 + 首 Token 延迟）
- 韧性（统一错误码 + 指数退避重试 + 按模型独立限流）
- 客户端断开时取消上游请求（仅流式，见 5.1.1）
- 站点鉴权（入站 API Key，见 8.6）
- 多租户（按调用方的配额、模型可见性、数据归属，见 7.6 / 8.7）
- 定价表与成本核算（按模型计价、调用方可见成本、按租户聚合，见 7.7）
- 多上游 failover 与熔断（一个模型多个端点、失败自动切换、连续失败自动隔离，见 7.8）
- Mock 上游（模拟三种协议的请求/响应/流式/故障）

### 1.2 范围外（本期不做）

- 对外暴露任何厂商的原生格式入口（OpenAI / Anthropic 均不提供）—— 对外**只有**网关自有契约的 `/v1/chat/completions`
- 原生工具调用（`tools` / `tool_choice`）—— 传了直接 400 `GW_INVALID_REQUEST`（含 MiniMax 的 `tool_use` 变通，见 §4.5）
- 租户级差异化定价（按租户覆盖价目表）、账单 / 结算 / 发票（成本核算已在 v2.8 落地）
- 跨模型的负载均衡 / 按权重分流（多上游 failover 只在**同一个模型的多个端点**之间切换）
- 熔断状态的分布式共享（熔断器状态在进程内存里，多实例各算各的）
- 分布式限流（Redis）、多实例共享配额
- 对话历史持久化、会话管理
- Embeddings / 图像 / 音频等非文本模态

---

## 2. 总体架构

```
                      ┌──────────────────────────────────────────┐
   客户端 (网关自有      │            FastAPI 应用                   │
   契约 SDK / curl) ──▶│  /v1/chat/completions  /v1/models        │
                      │  /v1/metrics  /v1/requests  /v1/prompts  │
                      └───────────────┬──────────────────────────┘
                                      │
                          ┌───────────▼───────────────┐
                          │   调用编排 pipeline.py      │
                          │  1. 解析请求/模型路由      │
                          │  1b. 能力校验(不支持→400)  │
                          │  2. 提示词渲染(可选)        │
                          │  3. 限流闸门(rpm+tpm)      │
                          │  4. 重试循环(≤3次)         │
                          │  5. 适配器+Provider 翻译   │
                          │  6. 上游调用 / SSE 转发     │
                          │  7. 计量结算 + 记录         │
                          └───────────┬───────────────┘
                                      │
              ┌───────────────────────┼───────────────────────┐
              │                       │                       │
    ┌─────────▼──────────┐ ┌──────────▼─────────┐ ┌───────────▼──────────┐
    │ Registry           │ │ PromptManager      │ │ Recorder / Metrics   │
    │ alias → 适配器实例  │ │ 模板/版本/变量替换  │ │ token分类/延迟/TTFT  │
    └─────────┬──────────┘ └────────────────────┘ └──────────────────────┘
              │
    ┌─────────▼──────────────────────────────────────────┐
    │  ModelAdapter  (模型层)                            │
    │   模型身份 / 能力声明 / 参数改写钩子                 │
    │   build_request / parse_response / parse_stream    │
    │         ▲ 组合 (不是继承)                          │
    │  ┌──────┴───────────────────────────────────────┐  │
    │  │  BaseProvider (协议层)                       │  │
    │  │   只认协议，不认模型                          │  │
    │  ├───────────────┬────────────────┬─────────────┤  │
    │  │ OpenAIResponses│ Anthropic      │ OpenAIChat  │  │
    │  │ Provider       │ Messages       │ Completions │  │
    │  │                │ Provider       │ Provider    │  │
    │  └───────┬────────┴───────┬────────┴──────┬──────┘  │
    └──────────┼────────────────┼───────────────┼─────────┘
               │                │               │
        ┌──────▼──────┐ ┌───────▼───────┐ ┌─────▼──────────┐
        │ Mock /v1/   │ │ Mock /v1/     │ │ 真实上游 /v1/  │
        │ responses   │ │ messages      │ │ chat/          │
        │             │ │               │ │ completions    │
        └─────────────┘ └───────────────┘ └────────────────┘
```

**分层原则**

- `api/` 只做 HTTP 编解码，不含协议知识也不含模型知识
- `resilience/` 不认识协议也不认识模型，只认识"调用一次上游"这个动作
- `providers/` 是**唯一**知道协议差异的地方（协议知识）
- `adapters/` 是**唯一**知道模型差异的地方（模型知识），并且是唯一同时接触两层的地方
- `observability/` 是旁路，失败不影响主链路

---

## 3. 目录结构

```
LLMGateway/
├─ main.py                      # FastAPI 入口，组装所有组件
├─ DESIGN.md
├─ requirements.txt
├─ .env.example
├─ core/
│  ├─ config.py                 # pydantic-settings 配置模型
│  ├─ secrets.py                # `.env` 解析 + 密钥文件读取（v2.14，见 §7.9）
│  ├─ types.py                  # 统一领域模型（Pydantic）
│  ├─ errors.py                 # 统一错误码 + GatewayError
│  └─ structured.py             # JSON 本地修复 + schema 校验（协议无关）
├─ adapters/                    # 模型层
│  ├─ base.py                   # ModelAdapter 薄基类 + ModelConfig
│  ├─ models/
│  │  ├─ deepseek_v4_pro.py     # DeepSeekV4ProAdapter
│  │  ├─ deepseek_v4_flash.py   # DeepSeekV4FlashAdapter
│  │  └─ minimax_m2_7.py        # MiniMaxM27Adapter（真实厂商模型）
│  └─ registry.py               # 代码自注册 → alias → 适配器实例
├─ providers/                   # 协议层
│  ├─ base.py                   # BaseProvider 抽象 + ProtocolContext
│  ├─ openai_responses.py       # OpenAIResponsesProvider
│  ├─ anthropic_messages.py     # AnthropicMessagesProvider
│  └─ openai_chat_completions.py# OpenAIChatCompletionsProvider（v2.13）
├─ upstream/
│  ├─ client.py                 # httpx 异步客户端 + SSE 读取
│  └─ mock_server.py            # 内置 FakeDeepSeek（三种协议 + 故障注入）
├─ prompts/
│  ├─ store.py                  # JSON 文件持久化（原子写）
│  └─ manager.py                # 变量替换 + 版本引用解析
├─ observability/
│  ├─ recorder.py               # 调用记录（内存 + jsonl）
│  └─ metrics.py                # 聚合：token 分类 / 延迟 / TTFT
├─ resilience/
│  ├─ retry.py                  # 指数退避
│  ├─ ratelimit.py              # 令牌桶（rpm + tpm）
│  ├─ token_counter.py          # token 估算器
│  └─ pipeline.py               # 调用编排
├─ api/
│  ├─ routes.py                 # 路由
│  └─ schemas.py                # 提示词管理的出入参模型（推理入参见 core/types.py）
├─ storage/
│  └─ jsonstore.py              # 通用 JSON 读写工具
├─ web/                         # 前端工作台（无构建的纯静态资源，见 §8.8）
│  ├─ index.html                # 唯一 HTML 入口
│  └─ assets/
│     ├─ styles.css             # 设计令牌（Cappuccino Latte）+ 全局样式
│     ├─ dom.js                 # 唯一的建 DOM 入口（只走 textContent）
│     ├─ format.js              # 展示格式化（时间 / 金额 / 耗时的统一口径）
│     ├─ store.js               # localStorage（API Key）
│     ├─ api.js                 # 唯一的发请求入口（Bearer 头 / 错误信封）
│     ├─ charts.js              # ECharts 封装 + 降级
│     ├─ app.js                 # 页签路由 + 轮询调度
│     └─ views/                 # 五个页签各自的渲染逻辑
│        ├─ overview.js         # 总览（只读）
│        ├─ records.js          # 调用记录（只读）
│        ├─ models.js           # 模型能力（只读）
│        ├─ prompts.js          # 提示词模板（只读）
│        └─ playground.js       # 试调用（唯一有副作用的页签，见 §8.9）
└─ tests/
   ├─ conftest.py
   ├─ test_routing.py
   ├─ test_streaming.py
   ├─ test_structured_output.py
   ├─ test_prompts.py
   ├─ test_observability.py
   ├─ test_resilience.py
   ├─ test_auth.py              # 站点鉴权（v2.6）
   ├─ test_tenants.py           # 多租户（v2.7）
   ├─ test_pricing.py           # 定价与成本（v2.8）
   ├─ test_failover.py          # 多上游 failover 与熔断（v2.9）
   ├─ test_v210.py              # 实现与规范一致性修正（v2.10）
   ├─ test_request_validation.py# 入参校验（v2.1 ~ v2.4）
   ├─ test_headers_and_disconnect.py  # 响应头与客户端断开（v2.5）
   ├─ test_console.py           # 工作台的挂载、鉴权边界与前端安全约束
   ├─ test_minimax.py           # Chat Completions 协议 + MiniMax M2.7 接入（v2.13）
   └─ test_secrets.py           # `.env` 加载 + 密钥文件（v2.14）
```

---

## 4. 统一抽象层

### 4.1 领域模型（`core/types.py`）

网关自有的中立格式，与任何上游协议解耦。**这一组模型同时就是线上 HTTP 契约**
（`api/routes.py` 直接把请求体绑定到 `LLMRequest`，响应体直接 `model_dump()`
`UnifiedResponse`），因此这里的字段名与语义就是对调用方的承诺。

> 命名说明：请求体叫 `LLMRequest`（它是「一次 LLM 调用」的入参，路由层读起来最直白），
> 其余沿用 `Unified*` 前缀（`UnifiedResponse` / `UnifiedMessage` / `UnifiedStreamEvent`）。
> 这是刻意的：**请求是调用方直接构造的东西，名字要按调用方的视角起**；
> 响应与事件是网关内部流转的结构化数据，`Unified` 前缀强调「跨协议统一」。

```python
class OutputSchemaSpec(BaseModel):
    """结构化输出契约。只有「有 schema」这一档——没有「只要 JSON 不要 schema」。"""
    model_config = ConfigDict(extra="forbid", populate_by_name=True)
    name: str = "response"
    schema_: dict[str, Any] = Field(alias="schema")   # 必填
    strict: bool = True

class LLMRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")   # 未知字段一律 400，不静默丢弃
    model: str
    messages: list[UnifiedMessage]              # role: system|user|assistant
    output_schema: OutputSchemaSpec | None = None
    stream: bool = False
    prompt: PromptRef | None = None             # 提示词模板引用
    metadata: dict[str, Any] = Field(default_factory=dict)

class UnifiedResponse(BaseModel):
    id: str                                     # 网关 request id，不是上游 id
    model: str                                  # 网关别名，不是上游模型名
    content: str
    reasoning_content: str | None = None
    finish_reason: str                          # stop | length | error
    usage: TokenUsage
    latency_ms: float
    ttft_ms: float | None = None                # 非流式恒为 None
    created: int

class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    total_tokens: int = 0

class UnifiedStreamEvent(BaseModel):
    type: Literal["text_delta", "reasoning_delta", "usage", "done", "error"]
    text: str | None = None
    usage: TokenUsage | None = None
    finish_reason: str | None = None
    error: dict[str, Any] | None = None         # type == "error" 时填充
```

**已删除的模型**（v1.1 的 OpenAI 词汇）：`ResponseFormat` / `JsonSchemaSpec` /
`StreamOptions`。它们的存在本身就让「厂商中立」无从谈起——`json_object` 这一档
在两个模型上都只能降级成提示词软约束（实测两条路径都 502 `GW_INVALID_JSON`），
调用方却从契约里看不出这件事。

**不暴露采样旋钮与输出上限**：`temperature` / `top_p` / `stop` / `seed` / `n` /
`max_output_tokens` 都不在请求契约里，调用方传了就是 400。

理由是这些旋钮的**跨厂商语义本就不一致**，暴露它们等于把厂商差异原样泄漏回调用方：
- `temperature`：OpenAI 与 Anthropic 的取值分布不同，Anthropic 在开启扩展思考时
  还要求它必须是 1。调用方设一个 0.7，在两个模型上得到的并不是「同样的 0.7」。
- `max_output_tokens`：输出上限是**网关按模型能力决定的策略**（pro 4096 / flash 2048），
  不是一个对所有模型通用的旋钮。把它开放给调用方，就必须回答「超出模型上限怎么办、
  限流预扣按哪个值算」，这些都是网关内部职责。

输出上限通过 `GET /v1/models` 的 `capabilities.max_output_tokens` **声明**（可查、
不可调），采样策略由网关按模型固定。

**`finish_reason` 只有三档**：`stop` / `length` / `error`。没有 `tool_calls`：
工具调用是结构化输出的实现细节（Anthropic 侧靠 tool use 变通），属于 Provider
内部机制，不该出现在中立契约里。

### 4.2 分层：Provider（协议层）与 Adapter（模型层）

两种知识严格分离：

- **Provider = 协议知识**。Responses 长什么样、Messages 长什么样、SSE 事件叫什么、鉴权头放哪。它**不认识"模型"**。
- **Adapter = 模型知识**。模型别名、上游 id、用哪种机制实现结构化输出、上下文上限、默认输出上限、模型级特例。

两者是**组合**关系，不是继承。Adapter 是唯一同时接触两层的地方。

#### 4.2.1 Provider 层（`providers/base.py`）

```python
@dataclass
class UpstreamRequest:
    method: str
    url: str
    headers: dict[str, str]
    body: dict[str, Any]

class BaseProvider(ABC):
    protocol: str

    def build_request(self, req: LLMRequest, ctx: ProtocolContext) -> UpstreamRequest: ...
    def parse_response(self, raw: dict, ctx: ProtocolContext) -> UnifiedResponse: ...
    def parse_stream_event(self, chunk: SSEChunk, ctx: ProtocolContext) -> UnifiedStreamEvent | None: ...
```

`ProtocolContext` 是**窄接口**，只暴露协议翻译真正需要的字段，避免协议层泄漏模型概念：

```python
class ProtocolContext(BaseModel):
    upstream_id: str                      # 填进 body 的上游模型名
    structured_output_mode: str           # native | tool_use | prompt_only
    schema_name: str | None = None
    json_schema: dict | None = None
    schema_strict: bool = False           # schema 是否要求严格符合
    max_output_tokens: int = 4096         # 输出上限的唯一来源（三个协议都必须下发）
    extra_body: dict[str, Any] = {}       # 模型级自定义参数
```

Provider 永远看不到 `alias`、`max_input_tokens` 这类模型概念。

**`max_output_tokens` 恒定下发**：v1.1 里 Responses 侧「未指定就不发」，
Anthropic 侧硬编码 4096——同一份请求在两个模型上的实际输出上限完全不同，
而调用方从契约里看不出来。现在由 Adapter 解析出**唯一有效值**放进 ctx，
三个 Provider 都必须把它写进上游 body。

#### 4.2.2 Adapter 层（`adapters/base.py`）

```python
@dataclass(frozen=True)
class StructuredPlan:
    """结构化输出的执行计划：Adapter 决定用哪种 mode，Provider 实现该 mode 的协议机制。"""
    mode: str                 # none | native | tool_use | prompt_only
    schema_name: str | None = None
    schema: dict | None = None
    strict: bool = False

class ModelAdapter:
    alias: str
    provider_class: type[BaseProvider]
    upstream_id: str
    structured_output_mode: str = "native"      # 该模型首选的结构化输出策略
    max_input_tokens: int = 128_000
    default_max_tokens: int = 4_096             # 输出上限（网关策略，调用方不可调）

    def __init__(self, cfg: ModelConfig):
        self.cfg = cfg
        self.provider = self.provider_class()

    # 组装窄接口上下文（解析阶段复用同一份）
    def _context(self, req: LLMRequest) -> ProtocolContext: ...

    # 结构化输出计划（不再返回裸元组——三个返回值容易在调用点解包错位）
    def structured_mode(self, req: LLMRequest) -> StructuredPlan: ...

    # 输出上限的唯一解析点：网关按模型能力决定，调用方无法覆盖
    def resolve_max_output_tokens(self) -> int: ...

    # 模型级参数改写钩子（默认无操作）
    def _apply_model_overrides(self, upstream: UpstreamRequest, req: LLMRequest) -> None: ...

    def build_request(self, req: LLMRequest) -> UpstreamRequest:
        upstream = self.provider.build_request(req, self._context(req))
        self._apply_model_overrides(upstream, req)
        return upstream

    def parse_response(self, raw: dict) -> UnifiedResponse:
        return self.provider.parse_response(raw, self._context_for_parse())

    def parse_stream_event(self, chunk: SSEChunk) -> UnifiedStreamEvent | None:
        return self.provider.parse_stream_event(chunk, self._context_for_parse())
```

`ModelAdapter` 是**薄基类**：只承载与协议无关的装配逻辑（装配 Provider、组装 ctx、委托、参数钩子）。
**不引入"协议基类"**（不要 `ResponsesAdapterBase` 这类东西）——公共的是"装配零件"，不是"协议实现"。

**已删除 `supports_response_format`**：它在 v1.1 里恒为 `True`，没有真实语义，
却让人以为「模型支不支持结构化输出」是一个可配的能力开关。真实的语义是
`structured_output_mode`——模型**用哪种机制**实现结构化输出，而不是支不支持。

**`resolve_max_output_tokens()` 是输出上限的唯一解析点**。限流预估（tpm 预扣）
也必须走它，否则「预扣用的上限」和「实际下发给上游的上限」会不一致。
它只读模型声明的 `default_max_tokens`——调用方没有覆盖的余地（见 §4.1）。

#### 4.2.3 注册：代码自注册（`adapters/registry.py`）

模型与它的实现是同一件事，因此由代码自注册：

```python
ADAPTERS: dict[str, ModelAdapter] = {}

def register_all() -> None:
    for cls in _collect_subclasses(ModelAdapter):
        ADAPTERS[cls.alias] = cls(config_for(cls.alias))
```

启动时扫描 `adapters.models` 下所有 `ModelAdapter` 子类，按各自声明的 `alias` 建映射。
**配置里不写 `adapter = "xxx"`**，配置只描述这台部署的差异（base_url / upstream_id / 限流 / 超时）。

同协议的第二个模型 = 新增一个很薄的 Adapter 类（复用同一个 provider），而不是复制协议翻译代码。

### 4.3 路由

请求 `model` → 查 `ADAPTERS` → 拿到**已绑定该模型配置**的适配器实例 → 调 `build_request`。

未注册的 model → 统一错误 `GW_MODEL_NOT_FOUND`（HTTP 404）。
配置存在但没有对应适配器类 → 启动时校验失败（fail fast），不等到运行时。

**完整调用链**

```
POST /v1/chat/completions
  → registry.get(model) ─────▶ ModelAdapter 实例（模型身份 + Provider 实例）
  → 能力校验（不支持的组合 → 400，不消耗配额、不发上游请求）
  → 提示词渲染（协议无关，在上层）
  → 限流闸门 rpm + tpm（按 model alias 独立）
  → 重试循环（≤3 次，协议无关）
       → adapter.build_request(req)
            ├─ provider.build_request(req, ctx)   协议翻译
            └─ _apply_model_overrides()            模型特例
       → httpx 调上游
       → provider.parse_response(raw, ctx)
         provider.parse_stream_event(chunk, ctx)
  → 计量结算（token 分类 / TTFT / 总延迟）
  → recorder 落库
```

限流、重试、提示词、计量全在 Provider/Adapter 之上的编排层，**既不感知协议也不感知模型**。

**能力校验的位置是刻意的**：它必须在限流闸门**之前**。调用方发了一个网关做不到的
请求（比如对不支持 `output_schema` 的模型提结构化输出），网关应该立刻 400，
而不是先扣掉一份限流配额、再占住一个上游连接、最后才失败。

### 4.4 协议差异对照（本项目的核心训练点）

下表是三个 Provider 的实现差异，**不是三个 Adapter 的差异**。

| 维度 | `OpenAIResponsesProvider` | `AnthropicMessagesProvider` | `OpenAIChatCompletionsProvider`（v2.13） |
|---|---|---|---|
| 端点 | `POST {base}/v1/responses` | `POST {base}/v1/messages` | `POST {base}/v1/chat/completions` |
| 鉴权头 | `Authorization: Bearer <key>` | `x-api-key: <key>` + `anthropic-version: 2023-06-01` | `Authorization: Bearer <key>` |
| system 位置 | 混在 `input` 数组（`role=system`） | 独立的顶层 `system` 参数 | 混在 `messages` 数组（`role=system`） |
| 消息体 | `input: [{role, content:[{type:"input_text", text}]}]` | `messages: [{role, content:"..."}]`（content 是字符串，非数组） | `messages: [{role, content:"..."}]`（content 是字符串） |
| 非流式输出 | `output: [{type:"message", content:[{type:"output_text", text}]}]`；需过滤掉 `type=reasoning` 块 | `content: [{type:"text", text}]` | `choices[0].message.content`；`choices[0].message.reasoning_content` 单独取思维链 |
| 流式事件名 | `response.output_text.delta` / `response.output_text.done` / `response.completed` | `content_block_start` / `content_block_delta` / `content_block_stop` / `message_delta` / `message_stop` | 无事件名，全是 `data:` 帧；`choices[0].delta.content` 增量 |
| 流式数据形状 | `data.delta` 直接是字符串 | `data.delta.text` 嵌套一层 | `data.choices[0].delta.content` 多一层数组 |
| 结构化输出 | 原生 `text.format = {type:"json_schema", name, schema, strict:true}` | **无原生 json_schema** → 转为 tool use：`tools:[{name, input_schema}]` + `tool_choice:{type:"tool", name}`，回包从 `tool_use` block 取 `.input` | 协议层有 `response_format = {type:"json_schema", json_schema:{name, schema, strict}}`（**上游是否执行另说，见 §4.5.2**） |
| Token 字段 | `input_tokens` / `output_tokens` / `output_tokens_details.reasoning_tokens` | `input_tokens` / `output_tokens` / `cache_creation_input_tokens` / `cache_read_input_tokens` | `prompt_tokens` / `completion_tokens` / `completion_tokens_details.reasoning_tokens` / `prompt_tokens_details.cached_tokens` |
| 结束标志 | `response.completed` | `message_stop` | `choices[0].finish_reason`（无 `[DONE]` 哨兵） |
| 缓存 | 无显式控制（隐式） | `cache_control:{type:"ephemeral"}` 显式标记，产出 cache_creation / cache_read token | 隐式前缀缓存（上游单列 `cached_tokens`） |

**三处必须由 Provider 分别实现的地方**

1. **结构化输出机制**：Anthropic 没有 `response_format`，其 Provider 必须实现 tool-use 变通；Responses Provider 直传 `text.format`；Chat Completions Provider 直传 `response_format`（**协议层标准如此，但上游是否执行是模型层的事**，见 §5.2.3）。
2. **Token 分类映射**：三个协议对 reasoning token 与 cache token 的表达方式完全不同，各自映射到统一的 `TokenUsage` 五分类。
3. **流式帧形状**：Responses 有事件名、Anthropic 有事件名且 data 嵌套一层、Chat Completions 全是 `data:` 帧且 data 里再套一层 `choices[]`——三种 Provider 的 `parse_stream_event` 写法完全不同。

---

### 4.5 第三个协议：OpenAI Chat Completions（v2.13）

#### 4.5.1 为什么是「新增协议」而不是「只加 Adapter」

现有两个 Provider 是 **Responses**（`input[]` / `text.format`）与 **Messages**
（`messages[]` / `tools`）。MiniMax 的 OpenAI 兼容入口是 **Chat Completions**：
`POST {base}/v1/chat/completions`、`messages[]` + `response_format` +
`choices[].delta`。它与 Responses **不是同一种协议**，因此必须新增
`OpenAIChatCompletionsProvider`；模型身份（`MiniMax-M2.7`、结构化输出档位、
上下文长度）则是 `MiniMaxM27Adapter` 的事。**协议 ≠ 模型**这条分界线在本轮
被真机验证了一次。

#### 4.5.2 实测事实（2026-11-15，真机探测，`https://api.minimaxi.com`）

| 项 | 实测值 |
|---|---|
| 模型清单 | `GET /v1/models` 返回 `MiniMax-M3.1-Flash` / `MiniMax-M3` / **`MiniMax-M2.7`** / `MiniMax-M2.7-highspeed` / `MiniMax-M2.5` / `MiniMax-M2.1` / `MiniMax-M2`（CamelCase，大小写不敏感） |
| 端点 | `POST https://api.minimaxi.com/v1/chat/completions` |
| 鉴权 | `Authorization: Bearer <key>`；错误为 HTTP 401 + `{"type":"error","error":{...},"request_id":"..."}` |
| 请求 | `messages:[{role, content}]`、`model`、`max_tokens`、`stream`、`stream_options`、`response_format` |
| 输出上限 | `max_tokens` 上限 **196608**（超出 → HTTP 400 `model[MiniMax-M2.7] does not support max tokens > 196608`）。**不认** `max_completion_tokens` |
| 非流式输出 | `choices[0].message.content`；思维链**默认内联在 content 里**（`<think>…</think>`），需 `reasoning_split: true` 才拆到 `choices[0].message.reasoning_content` |
| 用量 | `usage.total_tokens` / `prompt_tokens` / `completion_tokens` / `completion_tokens_details.reasoning_tokens` / `prompt_tokens_details.cached_tokens`（另有 `total_characters` 与 `base_resp`，网关不使用） |
| 流式 | `data: {...}` 逐帧，`choices[0].delta.content` 增量；**没有 `[DONE]` 哨兵**；`finish_reason` 在收尾帧 |
| 流式用量 | 需显式 `stream_options:{"include_usage":true}`，用量出现在一个 `choices: []` 的空帧里 |
| 结构化输出 | `response_format`（`json_schema` 与 `json_object`）**接受但不执行**：HTTP 200，输出仍是散文 |
| 未知字段 | **静默忽略**（不报错）——因此「未知字段 → 400」这条契约仍由网关自己的入参校验层保证 |

#### 4.5.3 Provider 行为约定

- **请求**：`{base}/v1/chat/completions`；body 恒含 `model` / `messages` / `max_tokens`
  （输出上限唯一来源，见 §4.2.1）；`stream` 时加 `stream: true` 与
  `stream_options:{"include_usage":true}`（否则拿不到流式用量）。
- **`reasoning_split`**：这是**模型级**参数（不是协议语义），走
  `extra_body` 配置下发（见 §10），不写死在 Provider 里。
- **响应解析**：`choices[0].message.content` → 正文；`reasoning_content` → 思维链。
  `finish_reason` 中立化：`length` → `length`，其余（含 `stop` / `content_filter`）→ `stop`。
- **Token 归一化**：`prompt_tokens` → `input_tokens`；`completion_tokens` → `output_tokens`；
  `completion_tokens_details.reasoning_tokens` → `reasoning_tokens`；
  `prompt_tokens_details.cached_tokens` → `cache_read_tokens`；
  `total_tokens` 原样。**注意口径**：推理 token **已含在** `completion_tokens` 里，
  `total_tokens` 也不重复加——不能像有些协议那样再自己加一次。
- **流式解析**：`delta.content`（非空）→ `text_delta`；`delta.reasoning_content`（非空）→
  `reasoning_delta`；**空 delta 必须跳过**（否则 TTFT 会被打到空帧上）；
  带 `usage` 的帧 → `usage` 事件；`[DONE]` 哨兵不存在，若出现则忽略。
- **同帧双增量**：一个上游帧里同时有 `reasoning_content` 与 `content` 时，
  Provider 一次只能返回一个事件，第二个暂存在 `ctx.state`，下一次调用先吐暂存的那个。
- **上游错误帧**：`{"error": {...}}` → `UnifiedStreamEvent(type="error")`，
  由编排层转成网关错误帧（见 §5.1）。

---

## 5. 三大能力

### 5.1 流式输出

对外是**网关自有的事件序列**，不是任何厂商的 chunk 格式：

```
data: {"type":"text_delta","text":"你"}
data: {"type":"reasoning_delta","text":"思考"}
data: {"type":"usage","usage":{"input_tokens":17,"output_tokens":6,"total_tokens":23},"cost_usd":0.000011}
data: {"type":"done","finish_reason":"stop"}
```

| 事件 | 何时出现 | 载荷 |
|---|---|---|
| `text_delta` | 每个正文分片 | `text`：增量文本 |
| `reasoning_delta` | 模型有思维链时（可选） | `text`：增量思维链 |
| `usage` | 流尾，**总是**发一次 | `usage`：五分类 token 用量；`cost_usd`：本次成本（v2.8，未定价为 `null`） |
| `done` | 流尾，**终止符** | `finish_reason`：`stop` / `length` / `error` |
| `error` | 中途失败 | `error`：与 HTTP 错误体同构的信封 |

`cost_usd` 放在**事件顶层**、与 `usage` 平级，而不是塞进 `usage` 对象里：
`usage` 的字段集是「token 分类」的规范（见 §6.2），成本不是 token 的一种，
塞进去会让 `usage` 的形状随定价功能变化。

**没有 `[DONE]` 哨兵**——`done` 事件本身就是终止符，再加一个哨兵只是冗余。
**没有 role 首帧**——流里没有「角色」这个概念。

- 内部：上游 SSE 逐行读取 → `parse_stream_event` 归一化 → 网关产出统一事件。
- **TTFT 计时**：第一个 `text_delta` 到达的时刻，记录为 `ttft_ms`。
- 流中途上游报错：HTTP 状态码在响应头发出时就定死了，改不了；因此以
  `data: {"type":"error","error":{...}}` 形式发出，随后补一帧
  `data: {"type":"done","finish_reason":"error"}` 并关闭连接，记录中标记失败。
- **流式不支持结构化输出**：`stream` 与 `output_schema` 互斥，两者同时出现
  在入口就 400（见 §8.1.1）。v2.0 曾设计「流尾做 schema 校验」，v2.4 推翻它——
  理由见下面「为什么流式不做 schema 校验」。

**为什么流式不做 schema 校验**（v2.4 推翻 v2.0 的决定）：

1. **流尾校验是「事后」的，对客户端没有帮助**。字节已经发出去了，客户端已经
   消费了不符合 schema 的增量；此时再补一帧 `error`，客户端拿到的仍然是一段
   不合法的内容，只是多了一个错误信号。
2. **保证的口径会变得别扭**。硬性保证第 2 条是「200 ⇒ 内容已通过本地 schema
   校验」，流式下 HTTP 状态码在响应头发出时就定死了——校验结果只出现在流尾，
   变成「事后追认」，而不是「先校验再给结果」。
3. **做不到的组合就该显式拒绝**。流式 + 结构化输出真正想要的是「逐字段增量
   推送」，那是另一种契约（需要字段级的 delta 协议），不是「把整段 JSON 拆成
   增量再在末尾校验」。与其做一个语义含糊的半吊子，不如在入口说清楚：
   要结构化结果就用非流式。

#### 5.1.1 客户端断开（v2.5）

流式响应期间客户端可能断开：用户关页面、上游客户端超时、网络切换。
网关的行为是确定的：

| 情形 | 网关行为 |
|---|---|
| 检测到客户端断开 | **立即取消上游请求**（关闭上游连接），停止为一个已经不存在的客户端继续生成 |
| 断开后是否再发事件帧 | **不发**——包括 `error` 与 `done`。客户端已经不在了，往断开的连接写帧没有意义 |
| 是否重试 | **不重试**——客户端不在了，重试给谁看 |
| 调用记录 | `status = "cancelled"`，`partial_output_chars` 记下已产出但未送达的字符数 |

**取消上游是省钱的关键**：不取消的话，上游会把整段答案生成完才停，
这段时间的 token 全白烧。

**断开检测必须与「读取上游数据」并行**。如果只在「每个 chunk 到达时」检查一次，
那么上游静默的那段时间（例如 60 秒没有新 chunk）里发生的断开会被延迟很久才发现，
这段时间的 token 就白烧了。因此网关在等待上游数据的同时并行轮询「客户端是否已断开」
的探针（间隔 250ms）。

**探针由 HTTP 层提供**（`request.is_disconnected`），编排层只接收一个
「是否已断开」的异步探针回调，不直接依赖 Web 框架——编排层因此仍能脱离 HTTP
单独测试。

**断开有两条检测通路，缺一不可**：

| 通路 | 触发条件 | 特点 |
|---|---|---|
| 探针（并行轮询，间隔 250ms） | 上游静默、迟迟没有新 chunk | 「上游一直不说话」时唯一的发现手段 |
| ASGI 服务器取消响应任务 | 客户端断开，服务器投递 `http.disconnect` | 比探针快（不用等 250ms），但依赖服务器行为 |

两条通路殊途同归：取消上游、记 `cancelled`、不发事件帧。

**实现约束（别踩）**：探针要求应用能直接拿到 ASGI 的 `receive` 通道。
Starlette 的 `BaseHTTPMiddleware`（也就是 `@app.middleware("http")`）会把
`receive` 包一层「等响应发完才算断开」的代理，导致 `request.is_disconnected()`
**永远返回 False**——网关会继续为一个已经离开的客户端烧 token。因此本项目的
request-id 中间件刻意写成**纯 ASGI** 的（见 `main.py` 的 `_RequestIdMiddleware`），
不要为了「写法统一」改回装饰器。

**非流式不做取消**。非流式响应是一次性返回的：客户端断开时上游请求早已发出、
模型已在生成，取消它省下的 token 有限，却会让非流式的重试与计量路径多出一套
取消语义。本期只对流式做取消。**代价**：非流式请求在客户端断开后仍会跑完一次
上游调用并计入 `usage`。

### 5.2 结构化输出

对外入参只有**一个** `output_schema` 字段：

```json
{
  "model": "deepseek-v4-flash",
  "output_schema": {
    "name": "person",
    "strict": true,
    "schema": { "type": "object", "properties": { ... }, "required": [ ... ] }
  },
  "messages": [{ "role": "user", "content": "..." }]
}
```

**没有「只要 JSON 不要 schema」这一档**。v1.1 的 `json_object` 在两个模型上都只能
降级成提示词软约束（实测两条路径都 502 `GW_INVALID_JSON`），而调用方从契约里
完全看不出这件事——它是一个**契约在骗人**的档位。取消了它，「有 schema」就等价于
「有保证」。

**`strict` 的语义**

| 值 | 语义 |
|---|---|
| `true`（默认） | 输出**保证**符合 schema；不符 ⇒ 内容层重试，仍不符 ⇒ 502 `GW_SCHEMA_MISMATCH` |
| `false` | 尽力而为；不符**不报错**，也**不重试** |

**「保证」的来源是网关本地的 schema 校验，不是上游**（这一点必须说准）：

| mode | 上游是否硬约束 | 说明 |
|---|---|---|
| `native` | ✅ 是 | Responses 的 `text.format.strict=true`，上游层拦截 |
| `tool_use` | ❌ 否 | Anthropic 的 `input_schema` 对模型只是**建议** |
| `prompt_only` | ❌ 否 | 纯提示词软约束 |

真正让「同一请求跨模型行为一致」的是**网关本地 `jsonschema` 校验**——它对每个
模型一视同仁。`native` 只是多一层上游拦截，不是保证的来源。
因此契约承诺的准确表述是：

> **`output_schema` 存在 ⇒ 200 响应的内容已通过网关本地 schema 校验。**

（该保证只覆盖**非流式**：`stream` 与 `output_schema` 互斥，流式请求根本不会
带 `output_schema`，理由见 5.1。）

**职责划分：Adapter 决定用哪种 mode（模型能力），Provider 实现该 mode 在本协议下的机制（协议知识）。**

```
请求里有 output_schema 吗？
   │
   ├─ 否 → mode = "none"（纯文本）
   │
   └─ 是 → mode = Adapter.structured_output_mode
            ├─ "native"    → Provider 走 text.format（Responses）
            │                或 response_format（Chat Completions）
            ├─ "tool_use"  → Provider 走 tools + tool_choice（Anthropic）
            └─ "prompt_only"→ Provider 把 schema 写进提示词并要求只回 JSON
```

- **Responses Provider**：`native` 模式直传 `text.format`，schema 原样透传。
- **Anthropic Provider**：无原生 `json_schema`，`tool_use` 模式下把 schema 塞进 `tools[].input_schema`，配 `tool_choice:{type:"tool",name}`，并追加一句"必须调用工具"的约束提示；回包时取 `content` 中 `type=tool_use` 的 `.input` 作为结果。
- **Chat Completions Provider**：`native` 模式直传 `response_format.json_schema`
  （`name` / `schema` / `strict` 原样透传）。
- **解析阶段**：Provider 按同一 mode 决定 JSON 从哪取（`output[].content[].output_text` vs `content[].tool_use.input`），因此 `ProtocolContext` 在解析阶段同样携带 mode。
- **校验与修复**：输出先过本地确定性修复（剥 markdown 围栏、去 BOM、提取最外层 JSON、去尾随逗号），再过 `jsonschema` 校验；仍不通过 → 走**内容层重试**（见 7.2.3），最终失败返回 `GW_INVALID_JSON` / `GW_SCHEMA_MISMATCH`（HTTP 502）。
- **`jsonschema` 是硬依赖**：缺失时必须**硬失败**，不能静默放行——否则
  「保证符合 schema」在缺依赖时就是一句空承诺。

#### 5.2.3 协议支持 ≠ 上游执行（v2.13 的关键教训）

`mode` 是**模型层**的属性，不是「协议有没有这个字段」。Chat Completions 协议
**有** `response_format.json_schema`，但 MiniMax **接受却不执行**（实测 HTTP 200、
输出仍是散文）。若 Adapter 声明 `native`，网关就会向调用方**承诺一个上游没兑现的
硬约束**——那正是本项目要消灭的「契约在骗人」。

因此：

- **Provider 仍实现 `native`**（协议层标准如此，别的厂商会真的执行）；
- **MiniMax Adapter 声明 `prompt_only`**（模型层据实选择）；
- 真正的保证仍然来自**网关本地校验 + 内容层重试**——这条不变量在三个模型上成立。

> 反面教训：仅凭「HTTP 200 + 无错误」就断定「参数生效了」是不够的。
> 结构化输出必须**看输出内容**是否真的符合 schema。

**实测**：`prompt_only` 下 MiniMax 对
`{"city":"string","temp":"integer"}` 产出 `{"city":"北京","temp":25}`——符合 schema。

### 5.3 提示词版本管理

**数据模型**

```python
class PromptVersion(BaseModel):
    version: int
    content: str                  # 含 {{var}} 占位符
    variables: list[str]          # 声明的变量名
    note: str = ""                # 版本说明
    created_at: str

class PromptTemplate(BaseModel):
    name: str
    description: str = ""
    current_version: int
    versions: list[PromptVersion] # 按版本号升序，只增不改
```

**存储**：`storage/prompts.json`，结构 `{ "templates": { "<name>": {...} } }`。

- 启动时全量载入内存（内存为唯一读路径，零查询开销）
- 写入时：写临时文件 → `os.replace` 原子替换，避免半截文件
- 版本**不可变**：只能追加新版本，或把 `current_version` 指针回滚

**引用方式**

```json
"prompt": { "name": "qa_summary", "version": 3, "vars": { "topic": "向量检索" } }
```

- `version` 省略 → 使用 `current_version`
- `version` 指定 → 固定版本（可复现）

**变量替换**

- 语法 `{{var}}`；支持默认值 `{{var|默认文本}}`
- 严格模式：
  - 声明了但未提供的变量 → `GW_TEMPLATE_VAR_MISSING`
  - 提供了但模板未使用 → `GW_TEMPLATE_VAR_UNUSED`
  - 模板中出现未声明的占位符 → `GW_TEMPLATE_VAR_UNDECLARED`
- 替换后注入到 system 消息（若模板里含 `{{messages}}` 则整段替换消息列表）
- 渲染结果记入调用记录（`rendered_prompt` + `prompt_version`），保证可追溯与复现

---

## 6. 可观测性

### 6.1 调用记录（`CallRecord`）

```python
class CallRecord(BaseModel):
    request_id: str
    ts: str
    model: str
    adapter: str                      # 适配器 alias（即模型别名）
    caller: str                       # 租户标识（v2.7；未开鉴权时为 "anonymous"）
    provider: str                     # 协议名
    protocol: str
    stream: bool
    status: Literal["success", "error", "cancelled"]
    error_code: str | None
    error_message: str | None
    error_stage: str | None           # connect | read | status | parse | validate | local
    attempt_count: int                # 总尝试次数
    retry_count: int                  # = attempt_count - 1
    last_upstream_status: int | None
    upstream_response_id: str | None  # 上游返回的 id（只落记录，不进线上契约）
    latency_ms: float                 # 总延迟
    ttft_ms: float | None             # 首 Token 延迟（流式）
    usage: TokenUsage                 # 五分类，语义为"所有尝试的总消耗"
    cost_usd: float | None            # 本次调用的成本（v2.8）；未定价的模型为 None
    upstream_endpoint: str | None     # 最后使用的上游端点名（v2.9；单端点模式为 None）
    failover_count: int               # 本次调用换过几次上游端点（v2.9）
    metadata: dict[str, str]          # 调用方传入的业务标识（透传）
    prompt_template: str | None
    prompt_version: int | None
    rendered_prompt: str | None
    attempts: list[AttemptRecord]     # 每次尝试的明细

class AttemptRecord(BaseModel):
    attempt: int
    ok: bool
    error_code: str | None
    upstream_status: int | None
    usage: TokenUsage                 # 该次尝试的消耗
    prompt_hash: str                  # 该次尝试实际渲染/加强后的 prompt hash
    prompt_strength: int              # 0=原样 1=第一档加强 2=第二档加强
    partial_output_chars: int | None  # 流式中断时已产出的字符数
    upstream_endpoint: str | None    # 该次尝试使用的上游端点名（v2.9）
```

**持久化**：`storage/requests.jsonl`（追加写，一行一条）+ 内存滚动窗口（默认保留最近 1000 条）。

**上游 id 只落记录，不进线上契约**。v1.1 把上游返回的 id 透传给了调用方
（Responses 侧是 `resp_...`，Anthropic 侧是 `msg_...`）——调用方能直接看出背后
是哪家厂商。现在响应里的 `id` 一律是网关自己的 request id（`lgw-` 前缀），
上游 id 挪到 `upstream_response_id` 字段，供排障时对账用。

**`metadata` 是调用方 → 网关的唯一数据通道**：原样落进调用记录，
让「这次调用是谁发起的、属于哪条业务链路」可追溯。它**不影响**路由与执行。

**`caller` 是租户标识（v2.7）**：由入站 API Key 的 `name` 决定（见 §7.6），
未开启鉴权时固定为 `anonymous`。它是「这次调用算在谁头上」的唯一凭据——
配额扣减、指标分组、记录查询都以它为准。

**重试场景下的 usage 语义**：`usage` 是**本次逻辑调用的总消耗**（所有尝试之和），不是"最终成功那次"的消耗。
内容层重试时前一次失败输出已经产生了真实 token 消耗（虽然没被采用），必须计入，否则成本统计会失真。
每次尝试的明细保留在 `attempts[]` 里。

**`cost_usd` 是成本估算值（v2.8）**：由该次调用的 `usage` 按模型价目表算出
（见 §7.7），口径与 `usage` 一致——**所有尝试之和**。模型没配价目表时为
`null`（未知），不是 `0`：「免费」与「不知道价格」必须能区分。

**`status` 的第三个取值 `cancelled`（v2.5）**：客户端在流式响应完成前断开，
网关取消上游请求后记的状态。它**不是错误**——没有上游错误码，`error_code` 为 `null`，
不计入 `errors` 计数（见 6.5）。它与 `error` 分开，是因为二者的运维含义不同：
`error` 是「上游/网络出问题，要查上游」，`cancelled` 是「客户端自己走了，
上游已经取消，没有额外成本」。

### 6.2 Token 分类统计

统一五分类：`input / output / reasoning / cache_read / cache_write`，外加派生 `total`。

映射规则：

| 统一分类 | Responses 来源 | Anthropic 来源 |
|---|---|---|
| input | `usage.input_tokens` | `usage.input_tokens` |
| output | `usage.output_tokens` | `usage.output_tokens` |
| reasoning | `usage.output_tokens_details.reasoning_tokens` | （无，从 output 拆分） |
| cache_read | （无） | `usage.cache_read_input_tokens` |
| cache_write | （无） | `usage.cache_creation_input_tokens` |

聚合维度：按 model、按 provider（协议）、按 adapter；输出每类的总量与占比、平均每请求消耗。

**成本（v2.8）**：每个聚合桶额外给出 `cost_usd`（该桶的已知成本合计）与
`unpriced_requests`（成本未知的请求数）。详见 §7.7.4。

### 6.3 延迟

- `latency_ms`：从收到请求到响应完成（流式则到流结束）。
- `ttft_ms`：从发出上游请求到收到第一个内容 delta。
- 聚合：count / avg / p50 / p95 / max。

### 6.4 查询接口

- `GET /v1/metrics` —— 聚合指标（token 分类、延迟分位、错误率、限流/重试计数）
- `GET /v1/requests?model=&status=&limit=` —— 调用明细

### 6.5 重试指标

```
retry_total              重试次数总计
retry_success            重试后最终成功的次数
retry_exhausted          重试耗尽仍失败的次数
retry_by_error_code      按错误码分布（区分传输层 / 内容层）
rate_limit_rejected      本地限流拒绝次数
cancelled                客户端断开导致的取消次数（v2.5；不算 error）
failover_total           换上游端点的次数（v2.9；多上游 failover）
```

---

## 7. 韧性

### 7.1 统一错误码

对外统一错误体：

```json
{
  "error": {
    "code": "GW_UPSTREAM_ERROR",
    "message": "upstream returned 503",
    "type": "upstream",
    "request_id": "lgw-...",
    "retriable": true,
    "attempts": 3
  }
}
```

`retriable` 表示"客户端可以自己再试"，与服务端已重试过几次是两回事，两者都保留。

**`type` 的取值全部中立化**，不带任何厂商词汇：

| type | 含义 |
|---|---|
| `invalid_request` | 入参违反契约 |
| `capability` | 请求合法，但网关/模型做不到 |
| `authentication` | 鉴权失败（入站 API Key / 上游） |
| `upstream` | 上游故障 |
| `model_output` | 模型输出不满足要求 |
| `rate_limit` | 触发限流 |
| `timeout` | 超时 |
| `internal` | 未预期异常 |

**所有契约违规一律 400**，不混用 FastAPI 的 422：

| 情形 | 错误码 |
|---|---|
| 未知字段（`tools` / `top_p` / `stop` / `seed` / `n` / `stream_options` …） | `GW_INVALID_REQUEST` |
| 字段类型错 / 缺必填字段 | `GW_INVALID_REQUEST` |
| 请求合法但该模型做不到（如对不支持结构化输出的模型提 `output_schema`） | `GW_CAPABILITY_UNSUPPORTED` |

FastAPI 的 `RequestValidationError` 与 Starlette 的 `HTTPException`（404 / 405）
都要挂 handler，统一渲染成同一个错误信封——**不存在** `{"detail": ...}` 这种
第二种错误体形状。

| 错误码 | HTTP | 触发条件 | 服务端可重试 |
|---|---|---|---|
| `GW_INVALID_REQUEST` | 400 | 入参违反契约（未知字段 / 类型错 / 缺必填） | 否 |
| `GW_CAPABILITY_UNSUPPORTED` | 400 | 请求合法，但该模型不支持所需能力 | 否 |
| `GW_MODEL_NOT_FOUND` | 404 | model 未注册 | 否 |
| `GW_TEMPLATE_NOT_FOUND` | 404 | 提示词模板不存在 | 否 |
| `GW_TEMPLATE_VAR_MISSING` | 400 | 缺少必填变量 | 否 |
| `GW_TEMPLATE_VAR_UNUSED` | 400 | 传入未使用变量 | 否 |
| `GW_TEMPLATE_VAR_UNDECLARED` | 400 | 模板含未声明占位符 | 否 |
| `GW_AUTH_ERROR` | 502 | 上游 401/403 | 否 |
| `GW_UPSTREAM_REJECTED` | 502 | 上游 4xx（除 401/403/429）——上游拒收了网关转发的请求（v2.10） | 否 |
| `GW_UNAUTHORIZED` | 401 | 入站 API Key 缺失或无效（见 8.6） | 否 |
| `GW_MALFORMED_UPSTREAM` | 502 | 上游 200 但 body 不是合法 JSON / 不是预期结构（协议层） | 是（传输层） |
| `GW_INVALID_JSON` | 502 | 响应正常，模型输出经修复后仍不是合法 JSON（内容层） | 是（内容层） |
| `GW_SCHEMA_MISMATCH` | 502 | 是合法 JSON 但不符合 schema（内容层） | 是（内容层） |
| `GW_RATE_LIMITED` | 429 | 本地限流触发 | 否（客户端退避） |
| `GW_UPSTREAM_RATE_LIMITED` | 429 | 上游 429 | 是（传输层） |
| `GW_UPSTREAM_TIMEOUT` | 504 | 上游超时 | 是（传输层） |
| `GW_UPSTREAM_ERROR` | 502 | 上游 5xx / 连接错误 | 是（传输层） |
| `GW_UPSTREAM_UNAVAILABLE` | 503 | 该模型的所有上游端点都不可用（全部熔断中，见 7.8.5） | 是（传输层） |
| `GW_INTERNAL_ERROR` | 500 | 未预期异常 | 否 |

三个"上游给不出可用结果"的错误码刻意区分，因为**故障层不同、走的重试路径不同、成功率不同**：
`GW_MALFORMED_UPSTREAM` 是传输层（换个时机可能就正常）；`GW_INVALID_JSON` / `GW_SCHEMA_MISMATCH` 是内容层（必须改写提示才有机会成功）。

上游原始状态码与 body 保留在 `CallRecord` 与日志中，但不直接透传给客户端。

**`GW_UPSTREAM_REJECTED` 为什么不是 `GW_INVALID_REQUEST`（v2.10）**

调用方的请求已经过了网关自己的契约校验（否则根本不会发上游）。
上游回 4xx 意味着**上游拒收了网关转发出去的东西**——可能是网关下发的模型名不对、
参数组合上游不认、端点配置错了。这些问题调用方改不了，改了也没用。

把上游的 400 原样透传成 400 `GW_INVALID_REQUEST`，等于告诉调用方「你的请求非法」，
调用方会去反复检查自己那份完全正确的请求体，浪费大量排障时间。
所以：**入参违规 → 400 `GW_INVALID_REQUEST`；上游拒收 → 502 `GW_UPSTREAM_REJECTED`**。
两者的 `type` 都是 `invalid_request` 与 `upstream` 的区别，调用方一看 type 就知道该找谁。

这是**破坏性变更**（v2.9 及之前上游 4xx 映射到 400 `GW_INVALID_REQUEST`）：
上游 401/403 仍然是 `GW_AUTH_ERROR`（502），429 仍然是 `GW_UPSTREAM_RATE_LIMITED`（429），
只有其余 4xx 改道。

### 7.2 重试

重试分两类，触发条件不同、动作不同，但**共用同一条尝试序列**：

- **传输层重试**：请求不变，直接重发。用于连接失败、超时、上游 429、上游 5xx、协议解析失败。
- **内容层重试**：改写请求（加强约束提示）后重发。用于模型输出不符合期望（非法 JSON / schema 不匹配）。

#### 7.2.1 错误分类与可重试性

不按 HTTP 状态码一刀切，按**故障层**分类：

| 故障层 | 具体情形 | 可重试 | 错误码 |
|---|---|---|---|
| 连接层 | DNS 失败、连接被拒、TLS 握手失败、连接重置 | ✅ 传输层 | `GW_UPSTREAM_ERROR` |
| 超时 | connect / read / write / pool 超时 | ✅ 传输层 | `GW_UPSTREAM_TIMEOUT` |
| 上游限流 | 429 | ✅ 传输层 | `GW_UPSTREAM_RATE_LIMITED` |
| 上游 5xx | 500 / 502 / 503 / 504 | ✅ 传输层 | `GW_UPSTREAM_ERROR` |
| 上游 5xx（其余） | 501 / 505 等 | ❌ | `GW_UPSTREAM_ERROR` |
| 上游 4xx（鉴权） | 401 / 403 | ❌ | `GW_AUTH_ERROR` |
| 上游 4xx（拒收） | 400 / 404 / 405 / 409 / 422 等 | ❌ | `GW_UPSTREAM_REJECTED`（v2.10） |
| 本地校验 | 入参非法、模板变量缺失、模型未注册 | ❌ | 对应本地错误码 |
| 协议解析 | 200 但 body 不是合法 JSON / 不是预期结构 | ✅ 传输层 | `GW_MALFORMED_UPSTREAM` |
| 输出校验 | 结构化输出经修复后仍非法 / schema 不匹配 | ✅ 内容层 | `GW_INVALID_JSON` / `GW_SCHEMA_MISMATCH` |
| 客户端断开 | 客户端主动断开 | ❌ | 不计入 |

**关键**：解析失败与输出校验失败**不按"原样重试"处理**。上游已返回完整响应，原样重发只会再拿到同样的坏结果并再烧一份 token——它们分别走传输层（协议层解析）和内容层（改写提示）两条不同的路径。

#### 7.2.2 流式：首字节分界线

**一旦向客户端 yield 过一个 chunk，就不能再重试**——否则客户端会收到重复内容。

用 `response_started` 标志判定：

| 情形 | 可否重试 | 处理 |
|---|---|---|
| 上游连上但一个 chunk 都没吐，读超时 | ✅ | 退避后重来 |
| 已吐 3 个 chunk，第 4 个时连接断开 | ❌ | 中断流，发 `data: {"type":"error",...}` + `data: {"type":"done","finish_reason":"error"}` 后关闭连接，记录 `partial_output_chars` |

非流式请求没有此约束（客户端什么都没收到，重试安全）。

流式**不降级**为「非流式重跑再一次性返回」——先给半截再给全文的体验不可接受。

**流式没有内容层重试**：字节已经发出去了，重来一次会让客户端收到重复内容。
而且流式**根本不支持**结构化输出（`stream` 与 `output_schema` 互斥，见 5.1），
所以流式路径上不存在内容层的 schema 校验。

#### 7.2.3 内容层重试：三级处理管线

结构化输出请求（`output_schema` 存在）的处理按代价从低到高逐级升级：

```
模型输出
  │
  ├─ ① 本地确定性修复（无 LLM 调用，零成本零延迟）
  │     剥 markdown 围栏 ```json ... ```
  │     去 UTF-8 BOM
  │     提取最外层 {...} / [...]
  │     去尾随逗号
  │     → 修复成功？直接用，不重试
  │
  ├─ ② schema 校验
  │     修复后的 JSON 过 jsonschema
  │     → 通过？直接用，不重试
  │
  └─ ③ 内容层重试（改写请求后重发）
        加强提示 → 重新调用 → 回到 ①
        仍失败 → GW_INVALID_JSON / GW_SCHEMA_MISMATCH（终止）
```

**① 这一层是性价比最高的**：实测"非法 JSON"里绝大多数是 markdown 包裹或前后带说明文字，属于纯格式问题，本地剥一下就好，根本不该触发一次 LLM 重试。

**提示强化的分档**（每次内容层重试加强程度递增）：

第 1 档（通用约束）：
```
你必须只返回一个 JSON 对象，不要包含任何解释文字、前言、总结，
也不要使用 Markdown 代码块（```）包裹。输出必须严格符合以下 schema：
{schema}
```

第 2 档（贴上次输出，要求只修格式）：
```
你上一次的回复无法被解析为合法 JSON，原文如下：
---
{上一次的实际输出}
---
请只修正上述内容的 JSON 语法错误后重新输出，不要改变其中的语义内容，
不要添加任何解释文字，不要使用 Markdown 代码块包裹。
```

第 2 档采用"贴上次输出要求只修格式"（self-repair），不需要生成 schema 示例，省掉 `json-schema-faker` 之类依赖。

**注入位置**：统一层追加到 **system 消息**末尾（无 system 则新建一条）。system 在三个协议里都是一等公民（Responses 塞进 `input` 数组、Anthropic 是顶层 `system` 字段、Chat Completions 是 `messages` 数组里的 `role=system`），统一层加一次三个 Provider 都自然吃到。

**Anthropic tool_use 模式的例外**：该模式已通过 `tool_choice` 强制结构化输出，再加"只返回 JSON"会干扰 tool 调用。此时提示改为"必须调用 `<tool_name>` 工具，且参数必须符合该工具的 input_schema"。

#### 7.2.4 尝试序列

两类重试共享一条尝试序列，总尝试次数上限 `max_attempts = 3`（含首次，即最多重试 2 次）：

```
attempt 1: 传输层失败（503）      → 不改提示，直接重发
attempt 2: 传输层失败（超时）      → 不改提示，直接重发
attempt 3: 内容层失败（非法 JSON） → 补第 1 档提示，重发
           → 超过 max_attempts，终止
```

- **是否加强提示取决于上一次失败的原因**：传输失败 → 提示不变；内容失败 → 加强提示
- **提示词模板只渲染一次**，内容层重试是在已渲染结果上追加约束，不重新渲染模板、不重新替换变量
- **每次尝试都过限流闸门并扣桶**（见 7.3）

#### 7.2.5 时间预算

只有一个 timeout 不够——重试会放大总耗时。分两层：

**非流式**
```
总 deadline      30s   整个逻辑调用
单次 attempt     10s   每次上游调用
```
重试前检查 `剩余预算 >= 退避时长 + attempt_timeout`，不足则放弃重试，
直接返回**最后一次错误**（不是新的超时错误——调用方需要知道上游到底报了什么）。
最坏总耗时被钉在 30s 附近，而不是 `3×10s + 退避`。

**流式**——不能用总 deadline（长文本生成可能跑几分钟），改用两个空闲型超时：
```
首 token deadline   60s   从发起到收到第一个 chunk
chunk 间隔超时      60s   相邻两个 chunk 的最大间隔（空闲超时）
```
httpx 的 `read_timeout` 天然就是「两个 chunk 之间的空闲超时」，正好对应。

**（v2.10 修正）这两段预算此前与实现不符，这一轮改的是「实现向规范看齐」：**

1. **重试预算漏算 `attempt_timeout`**：此前只判断 `剩余预算 >= 退避时长`，
   没把「下一次尝试本身要花多久」算进去。结果是：剩余 8s、退避 1s 时，
   网关会再发一次请求，而这次尝试最多要跑 10s —— 总耗时 19s，**穿透 30s 的总预算**。
   正确判据是 `剩余预算 >= 退避时长 + attempt_timeout`，也就是
   **下一次尝试要能完整跑完才算还有预算**。不足则不再重试，直接返回最后一次错误。
2. **流式的重试判据此前沿用了总 deadline**：代码里流式路径也拿 `started + deadline`
   判断「还有没有预算重试」，而流式并没有总 deadline 这回事——长文本生成本来就可能
   跑几分钟。结果是：第一次尝试耗掉了大部分预算（例如首 token 等待就花掉了 20s），
   后续重试会被一刀切掉，即使每次尝试各自的 `first_token` 预算还很宽裕。
   v2.10 起**流式彻底不设总 deadline**：每次尝试各自受 `first_token` 约束（首字节前），
   字节开始后只受 `stream_idle` 的空闲超时约束。
   流式的最坏总耗时因此是 `max_attempts × first_token + 退避之和`。
3. **`timeout.first_token` 此前没有被任何代码使用**：首包超时实际靠的是
   `stream_idle` 的 httpx read 超时。v2.10 起 `first_token` 由**网关自己**计时：
   把「建连 + 读到第一个可解析事件」整段包进 `asyncio.wait_for(first_token)`，
   超时按 `GW_UPSTREAM_TIMEOUT` 处理（首字节前，可重试）。
   为什么不能靠 httpx：httpx 的 `read_timeout` 管的是「两次读之间的空闲」，
   它管不到「上游连上了但一个事件都不发」——虽然对 SSE 来说这两件事都表现为
   「迟迟没有数据」，但语义不同：前者是**流中途**卡住，后者是**流开头**没开始。
   网关自己计时才能把两者分开。

#### 7.2.6 退避算法

```
delay = random.uniform(0, min(base * 2**(n-1), max_delay))
base = 0.5s, max_delay = 8s
```

用 **full jitter**（在 [0, 上界] 均匀取）而非等因式（`base*2^n + jitter`）。
理由：多实例同时被上游拒绝时，等因式会让它们在同一刻一起再打，等于惊群；full jitter 把重试打散。

**Retry-After 优先**：上游 429 带 `Retry-After` 时采用（支持秒数与 HTTP-date 两种格式），但受总 deadline 约束——超出剩余预算则放弃重试直接返回 429。

#### 7.2.7 最终错误语义

重试全部失败后返回**最后一次**的错误（不是第一次），并带上尝试次数：

```json
{
  "error": {
    "code": "GW_UPSTREAM_ERROR",
    "message": "upstream returned 503",
    "type": "upstream",
    "request_id": "lgw-...",
    "retriable": true,
    "attempts": 3
  }
}
```

#### 7.2.8 编排伪代码

```python
async def call_with_retry(adapter, req, ctx):
    last_error = None
    strength = 0
    for attempt in range(1, max_attempts + 1):
        # 预算判据（v2.10）：下一次尝试必须能**完整跑完**才算还有预算。
        # 少了 attempt_timeout 这一项时，总耗时能穿透 deadline。
        if not ctx.has_budget_for_next_attempt(backoff=ctx.last_backoff,
                                              attempt_timeout=ctx.attempt_timeout):
            raise last_error or GatewayError(TIMEOUT)
        await limiter.acquire(ctx.model, ctx.estimated_tokens)   # 失败则抛 429

        attempt_req = apply_prompt_strength(req, strength)      # strength=0 时原样
        upstream = adapter.build_request(attempt_req)
        try:
            if attempt_req.stream:
                # 流式没有总 deadline（v2.10）：每次尝试各自受 first_token 约束，
                # 字节开始后只受 stream_idle 约束。
                return await self._stream(adapter, upstream, ctx)
            raw = await http_client.post(upstream, timeout=...)
            result = adapter.parse_response(raw)
            result = self._validate_and_repair(result, attempt_req)  # ① ②
            return result
        except RetryableError as e:
            last_error = e
            if attempt == max_attempts:
                break
            if e.kind == "content":                # 内容层失败 → 下次加强提示
                strength = min(strength + 1, 2)
            delay = compute_backoff(attempt, e.retry_after, ctx)
            await asyncio.sleep(delay)
    raise last_error
```

流式路径内部自行处理「首字节前可重试、首字节后中断」的判定，重试逻辑集中在流方法内。
流式**没有总 deadline**（v2.10），因此流式路径里没有上面那个预算判据。

#### 7.2.9 已知代价

- 重试会产生**额外上游调用与计费**：上游已收到并计费的失败请求，重试不会退回。`usage` 已按"所有尝试之和"统计（见 6.1）。
- 三个协议都不支持标准 idempotency key，因此**不做**幂等去重。

#### 7.2.10 未来演进（P2，不在本期）

**prefill / assistant 前缀注入**：在最后一条消息后追加一个不完整的 assistant 消息（如 `{`），强制模型从 JSON 开头续写，能大幅消灭"markdown 包裹"和"前言文字"。

它是 **provider 特性**（各协议支持度不同、实现细节不同），属于 Provider 层的可选能力；Anthropic Messages 原生支持 prefill，Responses API 的等价能力不统一。还需要处理 prefill 前缀与模型续写的拼接。本期靠"① 本地修复 + ③ 提示加强"覆盖。

### 7.3 按模型独立限流（rpm + tpm 双维度）

每个模型一把**双维令牌桶**，两个维度任一不足即拒绝：

| 维度 | 含义 | 配置项 | 默认 |
|---|---|---|---|
| rpm | 每分钟请求数 | `models.<name>.rate_limit.rpm` | 60 |
| tpm | 每分钟 token 数 | `models.<name>.rate_limit.tpm` | 60000 |

**tpm 的计量与结算**

1. 准入时按**预估**扣减：`预估输入 token + 输出上限`。输出上限走
   `adapter.resolve_max_output_tokens()`（由网关按模型能力决定，调用方不可调）——
   **必须**与实际下发给上游的那个值一致，否则预扣和实扣会对不上。
   - 预估输入 = 消息内容 token 估算 + 渲染后的提示词 token 估算
2. 请求完成后按**实际**用量结算：多占的预扣退回，少占的补扣。
3. 流式请求在流结束时结算（流中途断开按已产出 token 结算）。

**结算的三种结局（v2.10 明确，此前只有第 1 条在代码里兑现）**

| 结局 | 结算口径 |
|---|---|
| 正常结束 | 上游 `usage` 的实际 token（上游没给则用「输入估算 + 已产出文本估算」） |
| 流中途出错 / 客户端断开 | 「输入估算 + 已产出文本估算」（上游可能已按产出计费，不能当作零） |
| 首个事件之前就失败 | **不结算**，预扣保留（上游可能已经计费，网关无从得知） |

第 3 行的「不结算」与非流式路径一致：失败的那次尝试，网关不知道上游到底计没计费，
保守地按「计费了」处理。代价是失败的调用会吃掉一份额度——这正是限流该有的行为
（失败的调用也占用了上游的真实负载）。

**与重试的交互：每次上游尝试都过一次闸门并扣桶**

每次尝试都是一次真实的上游请求，都消耗上游配额。因此限流判定放在**每次尝试之前**，而不是每次逻辑调用一次：

```
attempt 1 → 扣 1 次请求 + N tokens → 上游 503
attempt 2 → 再扣 1 次请求 + N tokens → 上游 503
attempt 3 → 再扣 1 次请求 + N tokens → 成功
```

这样本地桶反映的是**真实的上游负载**，而不是"逻辑调用数"。
代价是一次逻辑调用可能吃掉 3 份额度——但这恰恰是对的，否则网关会绕过自己的限流保护去打上游。
桶在重试时已空 → 立即返回 429，不再重试。

**上游 429 的本地惩罚扣减**（可配置，默认关闭）

上游已经用 429 表达了"你太密了"，本地可以跟着收紧。可配置项 `penalize_on_upstream_429`：
开启后，收到上游 429 时除退避外，额外对该模型的桶做一次惩罚性扣减。

**扣减多少（v2.10 明确，此前这个配置项根本没有接线）**：扣减**该次尝试预扣的 token 数**
（`预估输入 + 输出上限`）。理由是那一次尝试已经被**扣了两次**——一次是网关自己的预扣，
一次是上游真的按请求计了费（或者上游的 429 本身就是在说「你这种请求太贵/太密」）。
按「本次尝试的预扣量」扣，是与这次尝试一一对应的惩罚，不会因为输出上限配得大而
惩罚得不成比例。

默认关闭：惩罚扣减会让一次上游 429 连带影响后续请求的可用额度，
在「上游偶发抖动」时会误伤。开启它意味着**主动把上游的限流放大成本地限流**。

**Token 估算器**（`resilience/token_counter.py`）

Mock 场景无需精确分词，采用可解释的启发式：

- CJK 字符：1 字 ≈ 1 token
- 其它字符：4 字符 ≈ 1 token（即 `len/4`）
- `estimate(text) = cjk_count + ceil(non_cjk_count / 4)`

估算器封装为独立接口，后续可替换为 `tiktoken` 而不影响调用方。

**超限行为**

- 立即返回 HTTP **429**，统一错误体 `GW_RATE_LIMITED`，附 `Retry-After` 头（按令牌桶最早可恢复时间计算）
- **不占用**任何上游请求

**实现**：进程内令牌桶（`resilience/ratelimit.py`），线程/协程安全。多实例部署需换 Redis 实现，本期不做。

**（v2.10 修正）锁用 `threading.Lock`，不是 `asyncio.Lock`**

此前规范写的是 `asyncio.Lock`，代码里一把锁都没有。v2.10 落到 `threading.Lock`，
理由是限流器的接口是**同步**的（`consume` / `settle` / `penalize`），
而且它必须在**取消态下也能调用**——流式的结算写在 `finally` 里，
那里可能正在被 `CancelledError` 打断，此时 `await` 一个 `asyncio.Lock.acquire()`
既可能立刻再次抛 `CancelledError`，也可能把临界区交给一个不确定何时恢复的协程。
`threading.Lock` 没有这个问题：临界区里没有 `await`，不会让出事件循环，
在取消态下也能安全地拿住。

单事件循环里同步代码本来就是原子的，所以这把锁真正的价值是**跨线程**调用
限流器时的正确性（例如后台线程或将来引入的同步路径）。
锁的粒度是**每个 (租户, 模型) 一把**，不构成全局瓶颈。

### 7.6 多租户（v2.7）

**租户（tenant）= 调用方身份**。身份直接来自 v2.6 的 API Key——key 的 `name`
就是租户名；未开启鉴权时，所有调用方都是 `anonymous` 这一个租户。

租户带来三件事：**独立的配额**、**可见模型的范围**、**数据的归属与隔离**。

#### 7.6.1 租户配置

```toml
[tenants."team-a"]
admin = false                      # 管理员租户可见全局数据（见 7.6.5）
models = ["deepseek-v4-pro"]       # 可见模型白名单；省略 = 全部可见

[tenants."team-a".rate_limit]      # 该租户的统一配额；省略 = 用模型默认配额
rpm = 30
tpm = 30000

[tenants."team-a".model_rate_limit."deepseek-v4-flash"]   # 按模型覆盖
rpm = 10
tpm = 10000
```

**没有出现在 `[tenants.*]` 里的调用方**：全部模型可见、用模型默认配额、非管理员。
这条默认让「只开鉴权、不做隔离」的配置零成本可用；需要收紧时再逐个租户加配置。

#### 7.6.2 配额的三级回退

配额键是 **(租户, 模型)**——每个租户对每个模型有独立的 rpm/tpm 桶。
所以一个租户打爆了某个模型，不会影响另一个租户用同一个模型。

某个 (租户, 模型) 的实际配额取以下三级里第一个有值的：

| 优先级 | 配置项 | 含义 |
|---|---|---|
| 1 | `tenants.<租户>.model_rate_limit.<模型>` | 该租户在这个模型上的覆盖 |
| 2 | `tenants.<租户>.rate_limit` | 该租户的统一覆盖 |
| 3 | `models.<模型>.rate_limit` | 模型默认（v2.3 起就有） |

三级都没有 → 该 (租户, 模型) 不限流（桶不存在，直接放行）。

#### 7.6.3 模型可见性

租户请求**不在白名单里**的模型 → `GW_MODEL_NOT_FOUND`（404）。

**为什么是 404 而不是 403**：403 等于告诉调用方「这个模型存在，只是你不许用」，
等于泄露模型目录。对无权访问的租户，「不存在」与「不许用」必须不可区分。

可见性检查发生在**限流之前**：无权访问的请求不消耗任何配额、不发上游请求。

#### 7.6.4 归属

调用记录带 `caller` 字段，指标按租户分组（`by_caller`），配额按租户扣减。

#### 7.6.5 数据隔离与管理员

调用记录里有**提示词正文**（`rendered_prompt`）与调用方传入的 `metadata`——
这是租户之间的敏感数据，所以「租户 A 能不能看到租户 B 的记录」必须有明确答案：

| 租户 | `GET /v1/requests` | `GET /v1/metrics` |
|---|---|---|
| 普通租户 | 只返回**自己**的记录 | 只返回**自己**的聚合 |
| 管理员租户（`admin = true`） | 全部记录，可 `?caller=` 过滤 | 全局聚合 + `by_caller` |

普通租户显式传 `?caller=<别人>` → `GW_INVALID_REQUEST`（400），而不是静默忽略：
静默忽略会让调用方以为「对方没有记录」，那是错误结论。

未开启鉴权时只有 `anonymous` 一个租户，两种视角没有区别。

### 7.7 定价与成本核算（v2.8）

**要解决的问题**：调用方要知道「这次调用花了多少钱」，运维要知道「哪个租户、
哪个模型花了多少钱」。没有成本数据，v2.7 的配额与归属就只是「用量」而不是「账单」。

#### 7.7.1 价目表

价目表挂在**模型**上（不是租户上）：同一个模型对所有租户价格相同。

```toml
[models."deepseek-v4-pro".pricing]
input = 0.27          # USD / 1M 输入 token
output = 1.10         # USD / 1M 输出 token（含推理 token）
cached_input = 0.07   # USD / 1M 缓存命中 token；省略 = 按 input 价计
```

| 字段 | 语义 | 省略时 |
|---|---|---|
| `input` | 输入 token 单价（USD / 1M） | 视为 `0` |
| `output` | 输出 token 单价（USD / 1M） | 视为 `0` |
| `cached_input` | 缓存命中 token 单价（USD / 1M） | 按 `input` 计 |

计价单位固定为 **USD / 每百万 token**，与主流厂商价目表一致；币种固定 USD，
本版本不做多币种。

**整个模型没配 `[models.*.pricing]` = 该模型未定价**：成本记为 `null`（未知），
不是 `0`——「免费」与「不知道价格」必须能区分开。价格字段为负数 → 启动失败
（配置校验，见 §10）。

#### 7.7.2 成本算法

```
cost_usd = input_tokens       / 1e6 * input
         + output_tokens      / 1e6 * output
         + cache_read_tokens  / 1e6 * cached_input
```

三条归一化约定：

1. **推理 token 包含在 `output_tokens` 里**（见 §6.2 的映射），因此按 `output`
   价计费，**不重复计**。上游单列推理 token 时它也是从 output 里拆出来的。
2. **缓存命中 token 与 `input_tokens` 不重叠**：归一化后的 `cache_read_tokens`
   是上游单列出来的部分，`input_tokens` 不含它，因此不会双算。
3. **缓存写入（`cache_write_tokens`）按 `input` 价计费**：本版本不给缓存写单列
   价格；部署方若需要更精确的缓存写定价，用调高 `input` 价来覆盖。

#### 7.7.3 重试的成本语义

`cost_usd` 与 `usage` 同口径：**所有尝试之和**（见 §6.1「重试场景下的 usage
语义」）。内容层重试时前一次失败输出已经产生了真实 token 消耗，必须计入——
否则成本会被系统性低估。

#### 7.7.4 成本出现在哪

| 位置 | 字段 | 说明 |
|---|---|---|
| 非流式响应体 | `cost_usd` | 这次调用的成本；未定价为 `null` |
| 流式 `usage` 事件 | `cost_usd` | 与 `usage` **同级**的兄弟字段；未定价为 `null` |
| 调用记录 `CallRecord` | `cost_usd` | 同上 |
| `/v1/metrics` 每个桶 | `cost_usd` | 该桶的**已知成本合计**（USD） |
| `/v1/metrics` 每个桶 | `unpriced_requests` | 成本未知的请求数 |

聚合语义：桶的 `cost_usd` 是**已知成本之和**；未定价的请求不计入金额，但计入
`unpriced_requests`——这样「金额为 0」不会被误读成「没花钱」。

#### 7.7.5 精度

- 内部用 float 计算，**对外保留 6 位小数**（1e-6 USD）。
- 这是**估算值，不是账单凭据**：token 数来自上游 `usage`，上游没给时用本地
  估算兜底（见 §7.3），估算误差会直接反映到成本上。
- 按租户聚合的成本（`by_caller` 桶）是**对账线索**，不是结算依据。

### 7.8 多上游 failover 与熔断（v2.9）

**要解决的问题**：一个模型可能对应多个真实端点（不同区域、不同厂商账号、
主备部署）。主端点抽风时，调用方不该跟着一起挂——网关应该自己切到备端点。
反过来，一个持续坏掉的端点不该每次都被选中：**熔断器**把它临时隔离掉。

两个概念分工明确：

- **failover** = 「这次调用换一个端点再试」——**单次调用内**的行为，由重试循环驱动。
- **熔断** = 「这个端点最近一直失败，先别选了」——**跨调用**的状态，由熔断器维护。

#### 7.8.1 配置

一个模型可以配多个上游端点。**配了 `upstreams` 就以它为准**，
模型上的 `base_url` / `upstream_id` / `api_key_env` 被忽略；没配就退化成
原来的单端点写法（向后兼容，配置文件不用改）。

```toml
[models."deepseek-v4-pro"]
base_url = "http://127.0.0.1:8000/_mock/openai"   # 单端点写法（兼容）
upstream_id = "deepseek-v4-pro"
enabled = true

[[models."deepseek-v4-pro".upstreams]]             # 多端点写法（v2.9）
name = "primary"
base_url = "https://api.deepseek.com"
upstream_id = "deepseek-v4-pro"
api_key_env = "DEEPSEEK_API_KEY"

[[models."deepseek-v4-pro".upstreams]]
name = "backup"
base_url = "https://api.deepseek.com/backup"
upstream_id = "deepseek-v4-pro"
api_key_env = "DEEPSEEK_API_KEY_BACKUP"
```

**配置顺序 = 优先级**：先选前面的。`name` 是端点的标识，会出现在调用记录里
（`upstream_endpoint`），便于排障时知道「这次打的是哪个端点」；不填就用
`base_url` 代替。

熔断器参数是全局的：

```toml
[circuit_breaker]
enabled = true
failure_threshold = 5     # 连续失败达到该次数 → 断开该端点
cooldown = 30.0           # 断开后经过多少秒 → 进入半开
```

#### 7.8.2 选择规则

每次尝试前挑一个端点：

1. 按配置顺序（优先级）遍历；
2. **跳过本次调用已经失败过的端点**——同一个逻辑调用不重复打同一个坏端点；
3. **跳过处于熔断（open）状态的端点**；
4. 命中第一个可用的就用它。

规则 2 让「主端点挂了 → 这次调用直接落到备端点」成立；规则 3 让「持续坏掉的
端点自动退出轮转」成立。

#### 7.8.3 熔断器状态机

每个端点独立维护一个状态：

| 状态 | 行为 | 转移到 |
|---|---|---|
| `closed`（闭合） | 正常放行；连续失败计数 ≥ `failure_threshold` → 断开 | `open` |
| `open`（断开） | **跳过该端点**，不发起任何请求；经过 `cooldown` 秒 | `half_open` |
| `half_open`（半开） | 只放行**一次**试探请求；成功 → 闭合；失败 → 重新断开 | `closed` / `open` |

**成功一次就把失败计数清零**——失败计数是「连续失败」，不是「累计失败」。
半开状态只放行一个试探：并发请求不会一起涌向一个刚从熔断里恢复的端点。

#### 7.8.4 什么算一次「失败」

只有**上游侧的故障**计入熔断：

| 错误 | 计入熔断 | 理由 |
|---|---|---|
| `GW_UPSTREAM_ERROR`（含 5xx） | 是 | 端点本身有问题 |
| `GW_UPSTREAM_TIMEOUT` | 是 | 端点响应不过来 |
| `GW_MALFORMED_UPSTREAM` | 是 | 端点返回的东西不对 |
| `GW_UPSTREAM_RATE_LIMITED` | 是 | 端点过载 |
| `GW_AUTH_ERROR` | 否 | 配置/密钥问题，重试与换端点都没用 |
| `GW_UPSTREAM_REJECTED` | 否 | 上游对**这次请求**的确定性拒绝（v2.10）——它不会因为换端点/重试而变好，算进熔断只会误伤端点 |
| `GW_INVALID_JSON` / `GW_SCHEMA_MISMATCH` | 否 | 模型输出质量问题，不是端点故障 |
| 本地错误（限流、能力拒绝） | 否 | 与上游无关 |

内容层错误尤其不能计入：模型答得不好不代表端点坏了，把它算进熔断会误伤
一个健康的端点。

#### 7.8.5 全部端点不可用

- **第一次尝试就没有可用端点**（全部处于熔断）→ `GW_UPSTREAM_UNAVAILABLE`（503），
  `retriable = true`（过一会儿冷却结束就能用了）。
- **端点在本次调用里已经试完**（还有重试预算但没有新端点可试）→ **沿用最后一次
  错误**，不换错误码。调用方看到的是「上游真的报了什么」，而不是一个含糊的
  「不可用」。

#### 7.8.6 与重试预算的关系

重试预算 `max_attempts`（含首次）**不因 failover 而扩大**：换端点消耗的是同一次
尝试。因此端点数多于 `max_attempts` 时，靠后的端点这次调用用不上。

流式沿用既有的首字节边界：**只在首字节之前可以换端点**；一旦开始向客户端吐字，
换端点没有意义（客户端已经拿到半个响应），只能中断。

#### 7.8.7 可观测

| 位置 | 字段 | 说明 |
|---|---|---|
| 调用记录 | `upstream_endpoint` | 最后使用的端点名（单端点模式为 `null`） |
| 调用记录 | `failover_count` | 本次调用换过几次端点 |
| 每次尝试明细 | `upstream_endpoint` | 该次尝试打的端点 |
| `/v1/metrics` 每个桶 | `failover_total` | 累计换端点次数 |

**端点的 URL 不进契约**：那是部署细节，记录里只留 `name`（未命名时是 base_url）。

---

### 7.9 上游密钥的供给（v2.14）

**问题**：v2.13 之前，出站密钥只有一种来源——`api_key_env` 指向的**进程环境变量**。
这对开发者友好（IDE 运行配置、shell `export`），对**真实部署**不友好：
systemd / Docker / K8s 各有各的环境变量注入方式，运维还得额外记一份
「哪个变量名对应哪家的 key」；忘配了不会在启动时被发现，而是等到某次调用
打过去拿到上游 401，网关把它翻译成 `GW_AUTH_ERROR` → 502，
错误信息里**完全看不出是「没配 key」**（这是 v2.13 接入真机时实际踩到的）。

**本节只管出站**（网关 → 上游）的密钥。入站（调用方 → 网关）的密钥供给见 §8.6.3，
两者的纪律一致：**配置文件里只写「去哪取」，不写密钥本身**。

#### 7.9.1 三种来源与优先级

模型级（`[models.*]`）与端点级（`[models.*.upstreams.*]`）通用：

| 配置项 | 含义 |
|---|---|
| `api_key_env` | 环境变量名（v2.x 既有写法，语义不变） |
| `api_key_file` | 密钥文件路径；文件内容（去掉首尾空白）即密钥 |
| 都没配 | 该上游不需要鉴权（本地模型 / mock） |

**解析优先级：`api_key_env` → `api_key_file` → 无**。
环境变量优先，因为它能被容器编排平台直接注入、也最容易临时覆盖（调试时
`MINIMAX_API_KEY=xxx` 就能换一把 key 试）。

`api_key_file` 存在的理由：主流部署平台都把 secret 落成**文件**
（Docker secrets、K8s secret 挂载、systemd `LoadCredential=`、Vault agent），
让配置直接指向那个文件，就不必把密钥塞进环境变量再想办法不落到 `ps` 输出里。

#### 7.9.2 `.env` 自动加载

`config.toml` 的第一节就写着「`.env` + `config.toml`」（§10），但代码里
**从来没有 `.env` 加载器**——`.env` 只是一句口号。v2.14 兑现它。

- 配置文件：`[env] file = ".env"`（默认 `.env`，相对**进程工作目录**；
  配空串 = 不加载）。
- 加载时机：**读 `config.toml` 之后、构造 `Settings` 之前**——
  因为 `.env` 里可能含 `[env].file` 之外的东西，但路径本身只能来自配置文件。
- 语义：**只补不覆盖**。已存在的环境变量优先（`os.environ.setdefault` 语义），
  所以 systemd / Docker 注入的值不会被 `.env` 悄悄改掉。
- 解析：自写极简解析器（**不引入 `python-dotenv` 依赖**），支持
  `KEY=VALUE`、`export KEY=VALUE`、空行、`#` 注释、单/双引号包裹（去引号）、
  行尾注释。解析失败（行没有 `=`）**跳过该行**而不是报错——
  `.env` 是部署现场的文件，一行手误不该让网关起不来。
- `.env` **不入版本库**（`.gitignore` 已含 `.env`）；仓库里提供 `.env.example`
  作为模板，只写键名不写值。

#### 7.9.3 读不到密钥 = 启动失败

配了 `api_key_env` / `api_key_file` 却拿不到密钥 → **进程起不来**，
错误信息点名模型、配置项与变量名/文件路径。

这与入站鉴权同一条纪律（§8.6.3：「开了鉴权却一把钥匙都没有」是配置错误，
在构造时就该失败，而不是运行期永远 401）。差别只在于**读文件失败**（文件不存在）
与**变量没设**都归为同一类失败。

代价：想在本机只跑 mock、暂时不接真上游时，得把该模型 `enabled = false`
或注释掉它的 `api_key_env`——这是**显式选择**，比「以为配好了、跑起来才发现 401」好。

**运行期仍然 401 的情形只剩一种**：密钥**存在但无效**（上游拒绝）。那属于
上游语义，按 §7.1 映射成 `GW_AUTH_ERROR` → 502。

#### 7.9.4 不做的事

- **不做**密钥管理界面：不出现在 `/console` 里，也不存进网关的本地存储。
  密钥供给是部署侧的职责，网关只负责「按配置取到它」。
- **不做**密钥加密存储：密钥以明文躺在 `.env` 或密钥文件里，
  保护它靠文件系统权限（`.env` 建议 `chmod 600`）。
- **不合并**出站与入站：两者的信任方向相反（入站 key 是**调用方**的，
  由运维分发给调用方；出站 key 是**厂商**的，由运维自己持有），
  混在一个界面里只会让人搞不清谁是谁。

---

## 8. HTTP 接口

**本节是对外契约的规范来源（normative）。** 实现与测试都以本节为准；
任何与本节不符的行为都是缺陷，不是「实现细节」。

### 8.1 推理

```
POST /v1/chat/completions
```

这是网关**唯一**的推理入口。对外契约由本节定义，**不兼容任何厂商的原生格式**。

#### 8.1.1 请求

| 字段 | 类型 | 必填 | 默认 | 约束 | 语义 |
|---|---|---|---|---|---|
| `model` | string | ✅ | — | 1–128 字符；`^[A-Za-z0-9._-]+$` | 网关模型别名（`GET /v1/models` 里可查） |
| `messages` | array | ✅ | — | 至少 1 条；最多 100 条；所有 `content` 合计 ≤ 100000 字符 | `[{role, content}]`；`role` ∈ `system`/`user`/`assistant`；`content` 必须是**字符串**且**最长 20000 字符** |
| `output_schema` | object | ❌ | — | `name` 1–64 字符；`schema` 序列化后 ≤ 20000 字符且嵌套 ≤ 10 层 | 结构化输出契约，见 5.2 |
| `stream` | bool | ❌ | `false` | 与 `output_schema` **互斥** | 是否走 SSE |
| `prompt` | object | ❌ | — | `name` 1–128 字符；`version` ≥ 1；`vars` ≤ 50 项，值必须是标量且字符串值 ≤ 2000 字符 | 提示词模板引用 `{name, version?, vars?}` |
| `metadata` | object | ❌ | `{}` | ≤ 32 项；键 1–64 字符；**值必须是字符串**且 ≤ 512 字符 | 业务标识，原样落进调用记录 |

**未知字段一律 400 `GW_INVALID_REQUEST`。** 这条是硬性的：v1.1 用的是 pydantic
默认的 `extra="ignore"`，`tools` / `tool_choice` / `top_p` / `stop` / `seed` / `n`
被**静默丢弃**——调用方以为参数生效了，其实根本没有。现在 `extra="forbid"`。

**采样旋钮与输出上限不在契约里。** `temperature` / `top_p` / `stop` / `seed` / `n` /
`max_output_tokens` 一律按未知字段处理（400），理由见 §4.1：这些旋钮的跨厂商语义
不一致，暴露它们等于把厂商差异泄漏回调用方。输出上限是网关按模型能力决定的策略，
需要知道当前模型上限的调用方查 `GET /v1/models` 的 `capabilities.max_output_tokens`。

同理，`content` 只接受字符串——多模态内容块（数组形式）本期不支持，
传了会 400 而不是被悄悄拼成字符串。

**`content` 的长度上限是 20000 字符**（单条消息，超出即 400 `GW_INVALID_REQUEST`）。
这个上限是**入参侧的硬校验**，在请求解析阶段就拒绝，不会走到上游。
它挡的是「单条消息塞进几十万字」这种明显超出模型上下文的需求——
上游本来也会因为超上下文报错，但那时已经消耗了一次上游连接与配额；
在入口拒绝更便宜也更明确。
注意这与 `max_input_tokens` 不同：后者是**声明不强制**（token 估算是启发式的，
强制会误拒），而这里是**字符数**的精确计数，可以放心硬拒。

**入参校验的总体口径**（v2.3 补全）：契约里每一个**调用方可控**的字段都必须有
明确的长度 / 数量 / 取值域约束，理由有三：

1. **非法输入不消耗配额**——超长 / 超量 / 类型不符的请求在解析阶段就 400，
   不进限流器、不发上游请求（与「能力不足先拒绝」同一条原则）。
2. **错误码要能区分**——`model` 为空串是「参数非法」（400），而不是「模型不存在」
   （404）；空 `messages` 数组同理，不该变成上游 502。
3. **防止无界输入**——`metadata` / `prompt.vars` / `output_schema.schema` 这类
   「原样透传」字段如果不设上限，就是一条从调用方直通上游的放大链路。

`metadata` 的值收紧为**字符串**是 v2.3 的破坏性变更：调用记录里的
`metadata` 本来就是 `dict[str, str]`，之前允许传数字/嵌套对象，是契约与
存储结构对不上。

**`stream` 与 `output_schema` 互斥（v2.4）**。两者同时出现 → 400
`GW_INVALID_REQUEST`，在解析阶段就拒，不消耗配额、不发上游请求。
理由见 §5.1「为什么流式不做 schema 校验」——一句话：**流式下「保证内容符合
schema」这件事本身做不到**，那就别承诺。

#### 8.1.2 响应（非流式）

```json
{
  "id": "lgw-1a2b3c4d5e6f7a8b9c0d1e2",
  "model": "deepseek-v4-flash",
  "created": 1794118851,
  "content": "...",
  "reasoning_content": null,
  "finish_reason": "stop",
  "usage": {
    "input_tokens": 17, "output_tokens": 6, "reasoning_tokens": 5,
    "cache_read_tokens": 0, "cache_write_tokens": 0, "total_tokens": 23
  },
  "cost_usd": 0.000011,
  "latency_ms": 12.3,
  "ttft_ms": null
}
```

| 字段 | 语义 |
|---|---|
| `id` | **网关**的 request id（`lgw-` 前缀），不是上游 id |
| `model` | **网关**的模型别名，不是上游模型名 |
| `content` | 正文 |
| `reasoning_content` | 思维链（模型没有则显式为 `null`，不是省略） |
| `finish_reason` | `stop` / `length` / `error` |
| `usage` | 五分类 token 用量 |
| `cost_usd` | 本次调用的成本（v2.8）；模型未定价 → `null`（见 7.7） |
| `latency_ms` | 端到端延迟 |
| `ttft_ms` | 首 token 延迟；**非流式恒为 `null`** |

字段集固定：空值一律显式为 `null`，不使用 `exclude_none`——调用方不必区分
「没有这个字段」和「这个字段是空的」。

#### 8.1.3 响应（流式）

SSE，事件序列见 5.1：

```
data: {"type":"text_delta","text":"你"}
data: {"type":"reasoning_delta","text":"思考"}
data: {"type":"usage","usage":{"input_tokens":17,"output_tokens":6,"total_tokens":23},"cost_usd":0.000011}
data: {"type":"done","finish_reason":"stop"}
```

中途失败：

```
data: {"type":"error","error":{"code":"GW_UPSTREAM_ERROR","message":"...","type":"upstream","request_id":"lgw-...","retriable":true}}
data: {"type":"done","finish_reason":"error"}
```

#### 8.1.4 响应头（v2.5）

| 响应 | 必带响应头 |
|---|---|
| 全部（成功 / 错误 / SSE） | `X-Request-ID: <request_id>` |
| SSE（`stream=true`） | 追加 `Cache-Control: no-cache, no-transform`、`X-Accel-Buffering: no` |
| 401（未通过入站鉴权） | 追加 `WWW-Authenticate: Bearer` |
| 429（本地限流 / 上游 429） | 追加 `Retry-After: <秒>`（v2.10） |

**`Retry-After` 的口径（v2.10）**：任何错误，只要它的 `details.retry_after` 有值，
响应就带 `Retry-After` 头。取值是**秒数**（向上取整，最少 1 秒）——
HTTP 的 `Retry-After` 允许秒数或 HTTP-date，这里统一用秒数，调用方不用写两种解析。

哪些错误会带：`GW_RATE_LIMITED`（本地桶的最早可恢复时间）与
`GW_UPSTREAM_RATE_LIMITED`（上游给的 `Retry-After`，上游没给则不带）。

**为什么必须带头**：429 的语义就是「过一会儿再来」，但「过一会儿」到底是多久，
只有响应体里的一句自然语言描述是不够的——标准的 HTTP 客户端（重试中间件、
SDK 的退避逻辑）读的是**头**，不读 body。缺了这个头，调用方只能自己猜一个退避时间，
要么退得太快继续被拒，要么退得太久白白浪费额度。

**`X-Request-ID` 的值必须与响应体里的 id 一致**：非流式响应体的 `id`、
错误信封的 `request_id`、以及流式场景下同一个 request id，三者是同一个值。
调用方拿到这个值就能直接拿去 `GET /v1/requests` 查这一次调用的完整记录。

**为什么这三个头是必需的**：

1. `X-Request-ID` —— 排障的唯一凭据。没有它，调用方报「刚才那次请求出问题了」
   时，网关根本不知道是哪一次。
2. `Cache-Control: no-cache, no-transform` —— 禁止任何中间层缓存 SSE；
   `no-transform` 额外禁止代理改写响应体（压缩、换格式）。SSE 被缓存是灾难：
   客户端会收到上一次请求的内容。
3. `X-Accel-Buffering: no` —— nginx 反向代理默认会缓冲上游响应，开了它
   SSE 会被攒成一坨再一次性吐给客户端，流式效果与 TTFT 全部失效。
   **这一条本地测不出来**（直连 uvicorn 没有代理层），只有部署到 nginx 后面才暴露，
   所以必须在契约里写死，而不是指望部署时记得配。

#### 8.1.5 错误

统一信封，见 7.1：

```json
{"error":{"code":"GW_INVALID_REQUEST","message":"...","type":"invalid_request",
          "request_id":"lgw-...","retriable":false}}
```

#### 8.1.6 四条硬性保证

1. **未知字段一律 400**，不做静默忽略。
2. **`output_schema` 存在 ⇒ 200 响应的内容已通过网关本地 schema 校验。**
   该保证只覆盖**非流式**——`stream` 与 `output_schema` 互斥（见 §8.1.1），
   流式请求根本不会带 `output_schema`。
3. **响应里的 `id` 是网关 request id、`model` 是网关别名**——不泄漏上游厂商
   id / 模型名 / 协议名。
4. **同一请求在不同模型上行为一致**；做不到的组合**显式拒绝**
   （`GW_CAPABILITY_UNSUPPORTED`），绝不静默降级。

### 8.2 模型与元信息

```
GET /v1/models
GET /healthz
```

`GET /v1/models` 返回网关模型清单与**能力声明**（不是 OpenAI 的 `{"object":"list"}` 外壳）：

```json
{
  "models": [
    {
      "id": "deepseek-v4-flash",
      "capabilities": {
        "streaming": true,
        "output_schema": true,
        "output_schema_strict": true,
        "prompt_cache": true,
        "max_output_tokens": 2048,
        "max_input_tokens": 64000
      }
    },
    {
      "id": "minimax-m2.7",
      "capabilities": {
        "streaming": true,
        "output_schema": true,
        "output_schema_strict": false,
        "prompt_cache": true,
        "max_output_tokens": 8192,
        "max_input_tokens": 196608
      }
    }
  ]
}
```

（`minimax-m2.7` 的 `output_schema_strict` 是 `false`：它走 `prompt_only`，
上游不施加硬约束（见 §5.2.3）。但 `output_schema` 的**保证**仍然成立——
那来自网关本地校验，不来自上游。）

**能力声明的意义**：调用方可以据此判断「这个模型能不能满足我的需求」，
而不必先发一个请求、再从 400 里读出答案。

`max_input_tokens` **仅声明不强制**——token 估算是启发式的（见 7.3），
拿它做硬校验会误拒合法请求。强制校验列为待办。

### 8.3 可观测

```
GET /v1/metrics
GET /v1/requests?model=&status=&limit=&offset=&caller=
```

两个端点的租户视角见 §7.6.5；成本字段见 §7.7.4。

### 8.4 提示词管理

```
GET    /v1/prompts                        # 列表
POST   /v1/prompts                        # 新建模板（带首版本）
GET    /v1/prompts/{name}                 # 详情（含全部版本）
POST   /v1/prompts/{name}/versions        # 新增版本
POST   /v1/prompts/{name}/rollback        # 回滚 current_version
```

### 8.5 Mock 上游（仅测试/开发环境启用）

```
POST /_mock/openai/v1/responses
POST /_mock/anthropic/v1/messages
POST /_mock/_control          # 故障注入控制端点（见 9.3）
GET  /_mock/_control          # 查询当前控制状态与请求记录
```

### 8.6 站点鉴权（v2.6）

网关在**入站**方向要求调用方出示 API Key。密钥是**站点级**的：谁拿到密钥就能用
这个站点上的所有模型——多租户配额与分租户计费不在本期（见 §1.2）。

#### 8.6.1 请求头

| 请求头 | 形式 |
|---|---|
| `Authorization` | `Bearer <api_key>` |

**只认 `Authorization: Bearer`**，不提供 `X-API-Key` 之类的第二套写法：多一套写法
就会让「网关到底认哪个头」变成调用方的猜测题。

#### 8.6.2 生效范围

| 路径 | 是否鉴权 |
|---|---|
| `POST /v1/chat/completions` | 是 |
| `GET /v1/models` | 是 |
| `GET /v1/metrics` | 是 |
| `GET /v1/requests` | 是 |
| `/v1/prompts/**` | 是 |
| `GET /healthz` | **否**（探针不该被迫持有密钥） |
| `/_mock/**` | **否**（Mock 上游是开发期设施，不是对外契约的一部分） |
| `GET /console/**` | **否**（工作台的静态资源**不含任何数据**；真正的数据由浏览器带 key 去调 `/v1/*` 取，见 §8.8.2） |
| `GET /` | **否**（只是 307 跳转到 `/console/`，不返回任何内容） |

鉴权在**路由之前**完成（纯 ASGI 中间件，见 §8.6.6）：未鉴权的请求不会触发
请求体解析，因此不会因为「请求体非法」而暴露「先鉴权还是先校验」的顺序信息；
并且**未鉴权请求不消耗限流配额、不产生调用记录**——它根本没到模型调用这一步。

#### 8.6.3 密钥配置

密钥**不出现在配置文件里**，配置里只放环境变量名：

```toml
[auth]
enabled = true

[[auth.keys]]
name = "team-a"        # 调用方标识，会出现在调用记录里
key_env = "LGW_KEY_TEAM_A"
```

`key_env` 指向的环境变量在**启动时**读取；读不到就**启动失败**（fail fast），
而不是等到请求来了才发现「鉴权永远通不过」。

`[auth] enabled = false`（默认）表示不鉴权，此时所有调用方的标识统一是
`anonymous`。**`enabled = true` 但一个 key 都没有 = 启动失败**：绝不提供
「开了鉴权却没配密钥」这种既开又开的形态。

#### 8.6.4 校验方式

- 比对用 `hmac.compare_digest`（常数时间），避免时序侧信道；
- 遍历所有 key 时**不提前 break**（用 `|=` 累加而不是 `any()` 短路），
  否则「命中第 1 个 key 比命中第 8 个 key 快」本身就是信息泄露；
- 密钥只在内存里存在，**不写日志、不写调用记录、不回显**。需要关联某次调用时
  用指纹：`sha256(key).hexdigest()[:16]`。

#### 8.6.5 失败响应

```
HTTP/1.1 401 Unauthorized
WWW-Authenticate: Bearer
X-Request-ID: lgw-...
```

```json
{"error":{"code":"GW_UNAUTHORIZED","message":"missing or invalid api key",
          "type":"authentication","request_id":"lgw-...","retriable":false}}
```

**「没带」和「带错了」返回完全一样的响应体**（同一个 code、同一句话），
不给调用方一个「这个 key 存在但只是不对」的预言机。

错误码 `GW_UNAUTHORIZED` 与已有的 `GW_AUTH_ERROR` 是两回事：

| 错误码 | HTTP | 方向 | 含义 |
|---|---|---|---|
| `GW_UNAUTHORIZED` | 401 | **入站** | 调用方没通过网关的 API Key 校验 |
| `GW_AUTH_ERROR` | 502 | **出站** | 网关调上游时上游返回 401/403 |

两者 `type` 都是 `authentication`（粗粒度维度），但 code 与状态码不同，
调用方据此能区分「我的密钥不对」与「网关的密钥不对」。

#### 8.6.6 实现约束

鉴权中间件必须是**纯 ASGI** 的，理由与 `main.py` 里 `_RequestIdMiddleware` 相同：
Starlette 的 `BaseHTTPMiddleware` 会包住 `receive`，破坏 `request.is_disconnected()`
（见 §5.1.1 的「实现约束」）。鉴权本身只用请求头、不碰 `receive`，但把它写成
纯 ASGI 才能与 request-id 中间件保持同一套形状，且能在路由之前短路。

### 8.7 多租户相关的接口变化（v2.7）

| 变化 | 说明 |
|---|---|
| `GET /v1/models` | **只返回当前租户可见的模型**；未开鉴权时返回全部 |
| `GET /v1/requests` | 新增查询参数 `caller=<租户名>`；普通租户只能查自己（见 §7.6.5） |
| `GET /v1/metrics` | 新增 `by_caller` 分组（结构与 `by_model` 相同）；普通租户只看到自己的数据 |
| 调用记录 | 新增 `caller` 字段（见 §6.1） |

`/v1/metrics` 的响应形状**不变**（`overall` + `by_model` + `by_caller`），
只是普通租户拿到的内容被收窄到自己的范围——形状稳定，客户端解析逻辑不用改。

限流错误（429）的 `message` 会带上租户与模型，例如
`rate limit exceeded for caller 'team-a' on model 'deepseek-v4-pro'`，
方便调用方一眼看出是「自己的配额用完了」而不是「网关坏了」。

### 8.8 前端工作台（v2.11）

#### 8.8.1 定位与边界

工作台是**已有后台能力的可视化视图**，不是新的产品面。它**只读**：

| 做 | 不做 |
|---|---|
| 展示 `GET /v1/metrics` 的聚合指标 | 不新增任何指标口径 |
| 展示 `GET /v1/requests` 的调用记录 | 不提供记录查询之外的新视角（不落盘、不导出） |
| 展示 `GET /v1/models` 的模型能力 | 不展示 `config.toml` 的原始内容 |
| 展示 `GET /v1/prompts` 的模板（只读） | 不提供提示词的**新建 / 加版本 / 回滚**（接口已有，但属写操作，不在只读面板内） |
| 展示 `GET /healthz` 的存活状态 | 不做上游探活（网关自己没有这个能力） |

**后端的唯一改动是「把静态页面挂出来」**——不改任何 `/v1/*` 的路径、形状与语义。
工作台是这些端点的**消费者**，不是它们的扩展。

> **v2.12 的例外**：§8.9 的**试调用页签**会真的 `POST /v1/chat/completions`，
> 因此工作台不再是**纯**只读。但它仍然**不新增后端接口、不改变任何契约**，
> 并且试调用是**唯一**有副作用的页签——其余四个页签保持只读不变。

**不做配置编辑**（租户 / 模型 / 定价 / 熔断阈值）：那需要新增管理接口、admin 鉴权、
配置写盘与校验，是一次独立的、有写入副作用的变更，不属于「可视化呈现」。

#### 8.8.2 挂载与路径

| 项 | 取值 | 理由 |
|---|---|---|
| 挂载点 | `/console` | 挂 `/` 会抢走所有未匹配路径；且免鉴权前缀里出现 `"/"` 会让 `startswith("/")` 命中一切，等于把整个网关变成免鉴权 |
| 根路径 | `GET /` → **307** → `/console/` | 访问网关根直接进工作台；307（而非 302）语义是「资源换了位置」 |
| 静态服务 | `StaticFiles(directory=web, html=True)` | `html=True` 让目录请求命中 `index.html` |
| 目录缺失 | **启动失败**（`check_dir=True`，默认） | 部署漏了 `web/` 应该是「起不来」，不是「运行期 404」 |
| 免鉴权 | `/console/**` 与 `/` 免鉴权 | 页面本身不含数据；取数仍要 key |
| 前缀匹配 | **边界匹配**（`p` 或 `p + "/"` 开头） | 裸 `startswith` 会让 `/consolex` 也被放行 |

挂载必须放在 `include_router` **之后**：Starlette 按路由注册顺序匹配，先注册者先赢。
`/v1/*` 与 `/console` 前缀不重叠，顺序本身不影响结果，但约定俗成把静态挂载放最后
（将来若要新增 `/console/xxx` 路由，必须注册在它之前）。

`StaticFiles` 找不到文件时抛 `HTTPException(404)`，被网关既有的
`StarletteHTTPException` 处理器接住 → 渲染成**网关自己的错误信封**（JSON），
不会漏出 HTML 栈。

> **已知限制**：`/docs`（Swagger UI）在浏览器里打不开——浏览器导航请求无法携带
> `Authorization` 头。这是既有行为，不是本次引入；工作台里不放指向 `/docs` 的链接。

#### 8.8.3 前端技术约定

- **无构建**：纯 HTML + CSS + 原生 ES module，由浏览器直接加载。
  **不引入框架、不装 `node_modules`、不写打包步骤**——改完保存刷新即可。
- **资源用相对路径**（`./assets/...`）：按文档 URL 解析，自动跟随挂载前缀。
- **API 基址运行时推导**：`location.pathname` 里 `/console/` 之前的部分即 API 根前缀
  （页面在 `/console/` → `""`；在 `/gw/console/` → `"/gw"`）。**不写死 `/v1`**，
  这样网关被挂在反向代理子路径下时前端不需要改。
- **模块职责**：`api.js` 是唯一发请求的地方，`dom.js` 是唯一建 DOM 的地方，
  `app.js` 只管页签与生命周期；每个页签一个 `views/*.js`。
- **页签切换靠 `hidden` 属性**，因此 `hidden` 必须**真的**藏住东西：UA 样式表里
  有一条 `[hidden] { display: none }`，但任何同级的 `display` 声明都会盖掉它
  （`.view` 声明了 `display: flex`，于是所有视图同时显示——页签形同虚设）。
  因此 reset 里显式写 `[hidden] { display: none !important }`，并有用例钉住。
- **图表**用 ECharts（CDN 引入）。**CDN 不可达时降级**：图表位显示提示，数据由
  表格承载——表格本来就是主载体，图表只是增强。
- **配色**取 Catppuccin **Latte**（浅色、低饱和），颜色统一收敛到 `:root` 的 CSS 变量，
  ECharts 主题从同一套变量派生。只做浅色一套，不跟随系统深色模式。

#### 8.8.4 安全约定（硬约束）

工作台的 API Key 存在浏览器 `localStorage` 里，**一次成功的 XSS 就等于站点级密钥泄漏**。
因此下面这些不是风格偏好，是必须被 CI 断言的硬约束：

1. **禁止**把字符串当 HTML 解析的 API：`innerHTML` / `outerHTML` / `insertAdjacentHTML` /
   `document.write` / `eval` / `new Function` / `srcdoc`。
2. 后端返回的所有文本（`error_message`、`error_code`、`metadata` 的键和值、
   `rendered_prompt`、`upstream_endpoint`、模型名 / 租户名 / 上游响应 ID）
   **只能**通过 `textContent` / `createTextNode` 写入 DOM。
3. 唯一的建 DOM 入口是 `assets/dom.js` 的 `el()`；清空容器用 `replaceChildren()`。
4. **ECharts 的 tooltip 必须 `renderMode: "richText"`**——默认的 HTML 模板会解析
   `formatter` 返回的字符串，是最容易漏掉的注入入口。
5. 不把后端数据拼进 `href`；确需外链时先校验 `http(s)://` 前缀，并带
   `rel="noopener noreferrer"`。
6. API Key **只**存 `localStorage`：不进 DOM 属性、不进 URL、不进日志、不回显
   （输入框是 `type="password"`，只显示末 4 位）。
7. 页面只引入 ECharts 一个第三方脚本；将来新增第三方脚本必须同样受本节约束。

第 1 条由 `tests/test_console.py` 扫描 `web/**/*.js` 强制（禁用词一个都不许出现，
**注释里也不许出现**，否则断言会误报）。

#### 8.8.5 身份推断与可见范围

网关的 API **不返回**「我是谁」。工作台只能**推断**：

> **未开启鉴权时**（`auth.enabled = false`）前端**不带** `Authorization` 头也能取到数据——
> 此时所有调用方的标识都是 `anonymous`，不需要用户填任何密钥。填了密钥也不影响后端行为。

| 线索 | 判据 |
|---|---|
| 普通租户 | `GET /v1/metrics` 的 `by_caller` **恒为单键**（就是自己的租户名，见 §7.6.5） |
| 管理员租户 | `GET /v1/requests?caller=__probe__` 返回 **200**（普通租户会得到 400） |

界面上的身份标签必须标注「推断」二字——它不是权威身份，只是「当前 key 能看到什么」
的提示。数据本身的可见范围仍由后端保证（普通租户只看到自己的记录与指标）。

**提示词是例外**：`GET /v1/prompts` **不按租户过滤**，返回的是**站点级**模板。
因此界面不得宣称「我的提示词」，只能叫「提示词模板（站点级）」。

#### 8.8.6 轮询与竞态

| 页签 | 数据源 | 刷新策略 |
|---|---|---|
| 总览 | `/v1/metrics` | 每 5 秒轮询 |
| 调用记录 | `/v1/requests` | 每 10 秒轮询（可关闭）+ 手动刷新 |
| 模型 | `/v1/models` | 激活时加载一次 + 手动刷新 |
| 提示词 | `/v1/prompts` | 激活时加载一次 + 手动刷新 |
| 试调用（v2.12） | `POST /v1/chat/completions` | **不轮询**——由用户手动发送触发 |

- **失败退避**：5s → 10s → 20s → 30s 封顶，成功一次即复位。
- **切后台暂停**：`visibilitychange` 到 `hidden` 时停掉轮询并 `abort()` 在途请求；
  回到 `visible` 时立即刷一次再恢复。
- **三层竞态防护**（缺一不可）：
  1. `AbortController` 取消上一个在途请求；
  2. 请求序号，**只认最后一次**的响应；
  3. 换 API Key 时 `epoch` 递增，在途响应回来 epoch 不符直接丢弃。
- **总览不做时间序列**：`/v1/requests` 每条都带 `rendered_prompt` 全文且 `limit` 无上限，
  拿它做轮询是 MB 级流量。总览的图表全部从**一次** `/v1/metrics` 响应派生。

**分页漂移**：`/v1/requests` 的数据来自 1000 条内存环形窗口，窗口在滑动，
`offset` 语义不稳定。因此前端限制 `limit ≤ 200`，并在页脚提示
「记录来自 1000 条内存窗口，翻页期间数据可能移动」，同时提供「回到最新」。

### 8.9 试调用页签（v2.12）

#### 8.9.1 定位与边界

§8.8 的四个页签展示的是**调用的运行结果**（跑完之后留下的记录与指标）。
这一页展示的是**调用本身**——请求契约的实际行为：入参怎么被校验、
流式吐出什么样的帧、出错时错误信封长什么样。

> 之前的盲区：`extra="forbid"` 的未知字段 400、`stream` 与 `output_schema`
> 互斥 400 这类**入口级拒绝**根本不会产生调用记录，因此在「调用记录」页里
> **永远看不到**。SSE 帧的形状更是只在传输层存在，记录里不留。

| 做 | 不做 |
|---|---|
| 构造一个符合 `LLMRequest` 的请求体并发送 | 不提供「改网关配置」的入口（仍然不做配置编辑） |
| 展示原始 HTTP 状态、`X-Request-Id`、耗时 | 不展示上游的原始响应体（网关不转发它） |
| 逐帧展示 SSE 事件序列 | 不做请求历史、不落盘、不导出 |
| 展示网关的错误信封原文 | 不吞掉错误——错误也是要观察的东西 |

**这一页有副作用**：每次发送都是一次**真实调用**——消耗配额、产生 token 成本、
在「调用记录」页留下一条记录、可能触发上游限流。因此页面上必须常驻一句提示，
且**不自动发送**（没有「自动重试」这类行为）。

#### 8.9.2 请求表单

表单字段与 `LLMRequest`（见 §4.1）一一对应，**不多不少**——多一个字段
就是前端在教用户一个后端不认的契约。

| 字段 | 控件 | 说明 |
|---|---|---|
| `model` | 下拉 | 选项来自 `GET /v1/models`（当前租户可见的那些），不手输 |
| `messages` | JSON 文本域 | 数组，元素为 `{role, content}`；`content` 必须是**字符串**（见 §4.1） |
| `stream` | 复选框 | 默认关 |
| `output_schema` | JSON 文本域（可空） | `{name, schema, strict}`；`schema` 字段是 JSON Schema 对象 |
| `prompt` | 名称 / 版本 / 变量（可空） | 对应 `PromptRef{name, version, vars}`；`vars` 的值必须是标量 |
| `metadata` | JSON 文本域（可空） | `dict[str, str]`——键与值都必须是字符串 |

**本地校验**（不发请求就能发现的错误，不消耗配额）：

1. **JSON 解析失败** → 在字段下方标红提示，**不发送**。
2. **`stream` 与 `output_schema` 同时有值** → 提示「网关会以 400 `GW_INVALID_REQUEST`
   拒绝（两者互斥，见 §4.1）」，并提供「仍要发送」的按钮。
   前端**不静默替你去掉一个**——那等于偷偷改契约；提示 + 逃生口才是诚实的做法。
3. **`messages` 为空数组 / 缺 `role`** → 提示，同样不发送。

其余校验（长度上限、条数上限、`metadata` 值必须是字符串…）**交给后端**：
前端复刻一份契约只会产生两份会漂移的真相，**前端只做 JSON 可解析性与
明显的结构缺失**。

#### 8.9.3 输出区

一次发送的结果按下列顺序呈现：

| 区 | 内容 |
|---|---|
| 概要条 | HTTP 状态码、耗时（ms）、`X-Request-Id`（响应头里取，便于去查后端日志） |
| 非流式 | 格式化后的响应体（`content` / `reasoning_content` / `finish_reason` / `usage` / `cost_usd`）+ 原始 JSON 折叠区 |
| 流式 | **正文区按到达顺序逐字追加**（像打印机一样）：每个 `text_delta` 帧的文本**追加**到正文区末尾，容器自动滚到底；正文区是主视图 |
| 流式（辅） | 「思维链」折叠区（`reasoning_delta` 逐字追加）+「逐帧原文」折叠区（序号 + 类型徽章 + 该帧的原文 JSON） |
| 出错 | 网关的错误信封**原文**（`code` / `type` / `message` / `retriable` / `details`），不只显示一句「操作失败」 |

- **流式的默认视图是正文，不是帧表**：帧表是「排障时才看」的细节，放折叠区。
  正文区**只追加、不重写**——每个增量是一个新的文本节点，而不是把累计字符串
  重新写一遍（重写会导致闪烁、滚动跳变，也丢掉了「逐字到达」的手感）。
- 流式进行中正文区末尾有一个闪烁光标，收到 `done` 帧后熄灭。
- 帧类型共 5 种（见 §5.1）：`text_delta` / `reasoning_delta` / `usage` / `done` / `error`。
  **没有** `data: [DONE]` 哨兵——`done` 帧就是终止帧（§8.9.6）。
- 错误帧之后必定还有一帧 `done`（`finish_reason == "error"`），这是**契约的一部分**，
  界面上要能看出这个「错误也收尾」的顺序。
- **停止**按钮随时可中断在途请求（`AbortController`）；中断后已收到的帧与已渲染的正文保留。

#### 8.9.4 安全与副作用

§8.8.4 的七条硬约束**全部继续适用**，并追加两条：

- **8｜模型输出是不可信文本**：上游返回的内容与错误消息一律 `textContent` 写入，
  不当 HTML 解析（这是 §8.8.4 第 1、2 条的延续——模型输出恰恰是最典型的
  注入载荷）。
- **9｜不自动发送**：任何请求都必须由用户显式点击触发。页面上不存在定时器、
  「重试」按钮或任何自动重发逻辑——试调用的副作用（烧额度）不能被前端放大。

#### 8.9.5 与只读页签的关系

- 试调用是**第五个**页签，与其余四个平级，但**排在最后**——它是排障工具，
  不是浏览入口。
- 它**不轮询**：其余页签靠轮询保持新鲜，试调用是「发出去 → 看结果」的一次性动作。
- 它**不写后端状态**：除了调用本身（记录、配额、成本），前端不写任何东西。
- 其余四个页签的只读性**不变**：§8.8 的边界表在 v2.12 里只有这一处例外。

#### 8.9.6 SSE 线格式（供前端实现对照）

网关的流式响应是 `text/event-stream`，每个事件块形如：

```
data: {"type":"text_delta","text":"..."}\n\n
```

- 事件类型：`text_delta`（`text`）、`reasoning_delta`（`text`）、
  `usage`（`usage` + `cost_usd`）、`done`（`finish_reason`）、`error`（`error` 信封）。
- **没有** `[DONE]` 哨兵帧，也没有 `event:` 行——只有 `data:` 行。
- `error` 之后必跟一帧 `done`（`finish_reason == "error"`）。

---

## 9. Mock 上游设计

内置 FastAPI 子应用，挂在 `/_mock`，**严格按三种协议的真实交互形态实现**，使 Provider 代码与真实对接时的形状一致。

### 9.1 行为

- 非流式：返回对应协议结构的完整 JSON，`usage` 字段与真实协议一致
- 流式：按各协议原生事件名与数据形状逐块推送（Responses 用 `event: response.output_text.delta`；Anthropic 用 `event: content_block_delta` 且 `delta` 多一层 `text`；Chat Completions 无事件名，`data:` 帧里套一层 `choices[].delta`）
- Anthropic 侧支持 `cache_control`，并回填 `cache_creation_input_tokens` / `cache_read_input_tokens`
- Responses 侧回填 `output_tokens_details.reasoning_tokens`
- Chat Completions 侧回填 `completion_tokens_details.reasoning_tokens` 与 `prompt_tokens_details.cached_tokens`（v2.13）
- 支持 tool use 回包（用于结构化输出的 Anthropic 路径）
- **三侧都要发思维链事件**：Responses 侧发 `response.reasoning_summary_text.delta`，
  Anthropic 侧发 `thinking_delta`，Chat Completions 侧发 `delta.reasoning_content`。
  否则 `reasoning_delta` 在两侧都是死代码——
  网关的 `reasoning_content` / `reasoning_delta` 就没有可测的来源。

### 9.2 故障注入

通过请求头控制：

| 头 | 含义 |
|---|---|
| `X-Mock-Fail` | `429` / `500` / `503` / `timeout` / `malformed` |
| `X-Mock-Fail-Times` | 前 N 次调用失败，第 N+1 次成功（默认永久失败） |
| `X-Mock-Delay` | 首字节延迟（秒），用于制造 TTFT |
| `X-Mock-Content` | `markdown_json` / `bad_json` / `schema_violation`（内容层失败，用于验证内容层重试） |

- `X-Mock-Fail: malformed` —— 返回 200 但 body 不是合法 JSON（触发 `GW_MALFORMED_UPSTREAM`，走传输层重试）
- `X-Mock-Content: markdown_json` —— 返回合法的协议响应，但内容是 ```` ```json ... ``` ```` 包裹（验证本地修复层能救回来，**不触发**重试）
- `X-Mock-Content: bad_json` —— 内容是 `这不是 JSON`（验证内容层重试：加提示后第 2 次成功）
- `X-Mock-Content: schema_violation` —— 内容是合法 JSON 但不符合 schema（验证 `GW_SCHEMA_MISMATCH`）

Mock 状态由内存计数器维护（按上游 id 分组），测试间可重置。

### 9.3 控制端点（自动化测试入口）

请求头注入只适用于手工 curl 调试：自动化测试无法控制网关**出站**请求的头。因此 Mock 另外提供控制端点，由测试直接改写 Mock 的全局行为：

```
POST /_mock/_control
{
  "fail": "500",          # 400 | 401 | 429 | 500 | 503 | timeout | malformed | null
  "fail_times": 2,        # 前 N 次失败，第 N+1 次成功；null = 永久失败
  "content": "bad_json",  # markdown_json | bad_json | schema_violation | null
  "content_times": 1,
  "delay": 2.0,           # 响应前延迟（秒），用于制造超时 / TTFT
  "break_after": 1,       # 流式：输出 N 个分片后异常断开
  "cache_read": true,     # 回填 cache_read_input_tokens
  "fail_by_model": {"primary-model": "500"},  # 按上游 id 分别注入故障（v2.9）
  "reset": true           # 重置全部计数与控制状态
}
```

`fail_by_model` 让**不同的上游端点独立地失败**：键是请求体里的 `model`（也就是
网关下发的 `upstream_id`），值是故障模式。它是验证多上游 failover 的前提——
全局的 `fail` 开关没法让「主端点坏、备端点好」同时成立。

`GET /_mock/_control` 返回 `{control, calls, last_request, requests}`：按「协议:上游 id」统计的调用次数、最近一次请求（头 + 体）、以及全部请求历史。

---

## 10. 配置

`.env` + `config.toml`（模型注册表用 TOML，便于按模型分区）。

```toml
[gateway]
host = "127.0.0.1"
port = 8000
log_level = "INFO"

# v2.14：启动时自动加载的环境变量文件（只补不覆盖）。详见 §7.9.2。
# 配空串 = 不加载。路径相对进程工作目录。
[env]
file = ".env"

[storage]
data_dir = "./storage"

[gateway.retry]
max_attempts = 3          # 总尝试次数（含首次），即最多重试 2 次
base_delay = 0.5
max_delay = 8.0
jitter = "full"           # full | equal

[gateway.timeout]
deadline = 30.0           # 非流式：整个逻辑调用的总预算（秒）
attempt = 10.0            # 非流式：单次上游调用超时（秒）
first_token = 60.0        # 流式：首 token deadline（秒）
stream_idle = 60.0        # 流式：相邻 chunk 的最大空闲间隔（秒）
connect = 3.0
write = 3.0

[gateway.structured_output]
repair = true             # 启用本地确定性修复层
content_retry = true      # 启用内容层重试
max_prompt_strength = 2   # 提示加强的最高档位

[gateway.rate_limit]
penalize_on_upstream_429 = false   # 上游 429 时是否额外惩罚性扣减本地桶

[gateway.token_counter]
cjk_per_token = 1.0
chars_per_token = 4

[gateway.circuit_breaker]  # 上游端点熔断（见 7.8）
enabled = true
failure_threshold = 5     # 连续失败达到该次数 → 断开该端点
cooldown = 30.0           # 断开后经过多少秒 → 进入半开

[auth]
enabled = true             # 入站 API Key 鉴权（见 8.6）；默认 false

[[auth.keys]]
name = "team-a"            # 调用方标识
key_env = "LGW_KEY_TEAM_A" # 密钥放在环境变量里，不进配置文件

[tenants."team-a"]
admin = false                 # 管理员租户可见全局数据（见 7.6.5）
models = ["deepseek-v4-pro"]  # 可见模型白名单；省略 = 全部可见

[tenants."team-a".rate_limit] # 该租户的统一配额；省略 = 用模型默认配额
rpm = 30
tpm = 30000

[tenants."team-a".model_rate_limit."deepseek-v4-flash"]   # 按模型覆盖
rpm = 10
tpm = 10000

[models."deepseek-v4-pro"]
base_url = "http://127.0.0.1:8000/_mock/openai"
upstream_id = "deepseek-v4-pro"
enabled = true

[models."deepseek-v4-pro".rate_limit]
rpm = 60
tpm = 60000

[models."deepseek-v4-pro".pricing]   # 价目表（v2.8）；不配 = 该模型未定价
input = 0.27           # USD / 1M 输入 token
output = 1.10          # USD / 1M 输出 token（含推理 token）
cached_input = 0.07    # USD / 1M 缓存命中 token；省略 = 按 input 价计

[models."deepseek-v4-flash"]
base_url = "http://127.0.0.1:8000/_mock/anthropic"
upstream_id = "deepseek-v4-flash"
enabled = true

[models."deepseek-v4-flash".rate_limit]
rpm = 60
tpm = 60000

[models."deepseek-v4-flash".pricing]
input = 0.07
output = 0.27

# 真实厂商模型（v2.13）：MiniMax 国内站，OpenAI 兼容协议。
# 密钥走环境变量或密钥文件，不进配置文件；国内站 base_url 是 https://api.minimaxi.com。
[models."minimax-m2.7"]
base_url = "https://api.minimaxi.com"
upstream_id = "MiniMax-M2.7"     # 上游模型名是 CamelCase（大小写不敏感，但用规范写法）
api_key_env = "MINIMAX_API_KEY"  # 或 api_key_file = "./secrets/minimax.key"（见 §7.9.1）
enabled = true

[models."minimax-m2.7".rate_limit]
rpm = 60
tpm = 60000

# extra_body：模型级的厂商私有参数，直接透传到上游 body。
# reasoning_split=true 让上游把思维链从 content 里拆到独立的 reasoning_content 字段，
# 否则思维链会内联在正文里（污染正文输出）。这是**模型层**知识，不是协议语义。
[models."minimax-m2.7".extra_body]
reasoning_split = true

# pricing 先不配 → 该模型记为「未定价」（cost_usd = null，≠ 免费）。见 §7.7。

# 多上游端点（v2.9）：配了 upstreams 就以它为准，base_url/upstream_id 被忽略。
# 配置顺序 = 优先级；name 会出现在调用记录里（upstream_endpoint）。
# [[models."deepseek-v4-pro".upstreams]]
# name = "primary"
# base_url = "https://api.deepseek.com"
# upstream_id = "deepseek-v4-pro"
# api_key_env = "DEEPSEEK_API_KEY"
#
# [[models."deepseek-v4-pro".upstreams]]
# name = "backup"
# base_url = "https://api.deepseek.com/backup"
# upstream_id = "deepseek-v4-pro"
# api_key_env = "DEEPSEEK_API_KEY_BACKUP"
```

**配置里没有 `adapter` 字段**：模型与适配器实现绑定在代码里（代码自注册），配置只描述这台部署的差异。
启动时校验：每个 `[models.*]` 条目必须存在同名已注册的适配器类，否则启动失败。

密钥（`.env`，不入库）：`DEEPSEEK_API_KEY` 等，按模型配置项 `api_key_env` 指定读取哪个环境变量。
密钥的**来源与优先级**（环境变量 / 密钥文件 / `.env` 自动加载）见 §7.9——
配置里只写「去哪取」，不写密钥本身。

---

## 11. 测试计划

pytest + `httpx.AsyncClient(ASGITransport)`，用 FastAPI 的 `httpx` ASGI 传输直连应用，不起真实端口。

| # | 用例 | 断言要点 |
|---|---|---|
| 1 | 路由正确性 | `deepseek-v4-pro` 打到 `/_mock/openai/v1/responses`；`deepseek-v4-flash` 打到 `/_mock/anthropic/v1/messages`；未注册 model → 404 `GW_MODEL_NOT_FOUND` |
| 2 | Provider 请求翻译 | 上游收到的 body/headers 符合各自协议（Responses 的 `input` + `text.format`；Anthropic 的顶层 `system` + `messages` + `tools` + `x-api-key`） |
| 3 | Provider 响应解析 | Responses 的 reasoning 块被剔除；Anthropic 的 content 数组正确提取 |
| 4 | Adapter 隔离性 | Provider 层不出现 `alias` / `max_input_tokens` 等模型字段（可用静态检查断言） |
| 5 | 流式 | 分片拼接结果 == 非流式结果；末事件 `type == "done"`（**无** `[DONE]`）；TTFT 已记录 |
| 6 | 结构化输出 | 两个模型都产出合法 JSON 且通过 schema 校验；Anthropic 路径确认走了 tool use；本地修复层在 `core/structured.py` |
| 7 | 提示词 | 变量替换、默认值、缺变量报错、固定版本 vs latest、rollback 后生效 |
| 8 | Token 统计 | reasoning / cache_read / cache_write 分类正确；total 正确 |
| 9 | 延迟 | p50/p95/avg 计算正确；非流式请求 ttft 为 None |
| 10 | 传输层重试 | mock 前 2 次 500 → 第 3 次成功；4xx 不重试；退避时长落在预期区间；`malformed` → `GW_MALFORMED_UPSTREAM` |
| 11 | 内容层重试 | `bad_json` → 第 1 次失败后加强提示，第 2 次成功，且第 2 次的 prompt 强度档位 = 1；`schema_violation` → `GW_SCHEMA_MISMATCH` |
| 12 | 本地修复层 | `markdown_json` → 本地剥离围栏后成功，**不触发**重试（上游只被调用 1 次） |
| 13 | 流式重试边界 | 首字节前失败 → 可重试；首字节后断开 → 不重试，中断流并记录 `partial_output_chars` |
| 14 | 限流 | 超过 rpm → 429 + `GW_RATE_LIMITED`，且上游调用次数未增加；超 tpm 同样返回 429；重试会重复扣桶 |
| 15 | 错误映射 | 上游 401 → `GW_AUTH_ERROR`；超时 → `GW_UPSTREAM_TIMEOUT` |
| 16 | usage 语义 | 多次尝试后 `usage` 为各次之和；`attempts[]` 记录每次的 usage / prompt_hash / prompt_strength |
| 17 | 时间预算 | 非流式总耗时不超过 deadline + 单次 attempt 的边界 |
| 18 | **契约违规** | 传未知字段（`tools` / `top_p` / `stop` / `seed` / `n` / `stream_options` / `response_format` / `temperature` / `max_output_tokens`）→ 400 `GW_INVALID_REQUEST`，且**上游调用次数 = 0** |
| 19 | **能力拒绝** | 对不支持 `output_schema` 的模型提结构化输出 → 400 `GW_CAPABILITY_UNSUPPORTED`，**不消耗限流配额**、不发上游请求 |
| 20 | **厂商中立** | 响应 `id` 是 `lgw-` 前缀、`model` 是网关别名（**不是** `resp_mock` / `msg_mock`）；`finish_reason` 不出现 `tool_calls` |
| 21 | **输出上限** | 两个模型的默认输出上限各自按 adapter 声明下发（断言上游 body 的 `max_tokens` / `max_output_tokens`），不因请求未指定而省略 |
| 22 | **metadata 透传** | `metadata` 出现在 `/v1/requests` 的记录里 |
| 23 | **流式与结构化输出互斥** | `stream=true` 且带 `output_schema` → 400 `GW_INVALID_REQUEST`，且**上游调用次数 = 0** |
| 24 | **strict=false** | `strict=false` 且内容不符 schema → **不报错**、不重试 |
| 25 | **内容长度上限** | `messages[].content` 超过 20000 字符 → 400 `GW_INVALID_REQUEST`，且**上游调用次数 = 0**；恰好 20000 字符则放行 |
| 26 | **入参校验补全** | `model` 空串 / 非法字符 → 400；`messages` 空数组 / 超过 100 条 / 合计超 100000 字符 → 400；`output_schema.name` 超 64 字符、`schema` 超 20000 字符或嵌套超 10 层 → 400；`prompt.version` 为 0 → 400；`metadata` 传非字符串值 → 400。全部**上游调用次数 = 0** |
| 27 | **响应头**（v2.5） | 非流式 / 错误 / SSE 三种响应都带 `X-Request-ID`；其值 == 响应体 `id` == 错误信封 `request_id`；SSE 额外带 `Cache-Control: no-cache, no-transform` 与 `X-Accel-Buffering: no` |
| 28 | **客户端断开**（v2.5） | 流式响应进行中断开连接 → 上游被取消（不再被继续读取）、调用记录 `status == "cancelled"`、不产生 `error` / `done` 事件帧、不重试（上游调用次数 = 1） |
| 29 | **入站鉴权**（v2.6） | 未带 `Authorization` → 401 `GW_UNAUTHORIZED` + `WWW-Authenticate: Bearer`；带错 key → **完全相同**的响应体；带对 key → 200 |
| 30 | **鉴权范围**（v2.6） | `/v1/chat/completions`、`/v1/models`、`/v1/metrics`、`/v1/requests`、`/v1/prompts` 全部要鉴权；`/healthz` 不要；未鉴权请求**不产生调用记录**、**上游调用次数 = 0** |
| 31 | **密钥不泄露**（v2.6） | 密钥不出现在响应体、响应头、调用记录里；记录里只有 `sha256(key)[:16]` 指纹 |
| 32 | **配置 fail fast**（v2.6） | `auth.enabled = true` 但没配 key、或 `key_env` 指向的环境变量不存在 → **启动失败**（不是运行期 401） |
| 33 | **租户配额独立**（v2.7） | 租户 A 打满自己的 rpm → A 收到 429 `GW_RATE_LIMITED`，租户 B 同时仍能正常调用；错误信息里带出租户名 |
| 34 | **配额三级回退**（v2.7） | `model_rate_limit` > 租户 `rate_limit` > 模型默认，依次生效 |
| 35 | **模型可见性**（v2.7） | 租户请求不在白名单里的模型 → 404 `GW_MODEL_NOT_FOUND`，**上游调用次数 = 0**、不消耗配额 |
| 36 | **模型清单按租户过滤**（v2.7） | `GET /v1/models` 只返回该租户可见的模型 |
| 37 | **记录归属与隔离**（v2.7） | 调用记录带 `caller`；普通租户 `GET /v1/requests` 只看得到自己的；管理员看得到全部并可用 `?caller=` 过滤；普通租户显式查别人 → 400 |
| 38 | **指标按租户分组**（v2.7） | `/v1/metrics` 含 `by_caller`；普通租户只看到自己的数据，响应形状不变 |
| 39 | **未开鉴权不回归**（v2.7） | 不开鉴权时 `caller` 恒为 `anonymous`，行为与 v2.6 一致 |
| 40 | **成本计算**（v2.8） | 配了价目表的模型 → 响应体 `cost_usd` 按 §7.7.2 公式算出（断言具体数值）；`/v1/requests` 里的 `cost_usd` 与响应一致 |
| 41 | **未定价模型**（v2.8） | 没配 `[models.*.pricing]` → `cost_usd` 为 `null`（**不是 0**）；metrics 桶的 `unpriced_requests` 计数 |
| 42 | **缓存与推理 token 计价**（v2.8） | 推理 token 按 `output` 价、缓存命中按 `cached_input` 价，且不重复计入 `input` |
| 43 | **重试成本**（v2.8） | 发生重试的调用，`cost_usd` 按**所有尝试的 token 之和**计，不只是最后一次 |
| 44 | **成本按租户聚合**（v2.8） | `/v1/metrics` 的 `by_caller` 各桶带自己的 `cost_usd`；普通租户只看得到自己的 |
| 45 | **流式成本**（v2.8） | 流式 `usage` 事件带 `cost_usd`，与非流式同一公式 |
| 46 | **价目表配置校验**（v2.8） | 价格为负数 → 启动失败（配置校验），不是运行期算错账 |
| 47 | **多上游 failover**（v2.9） | 主端点 500 → 同一次调用自动切到备端点并成功；记录里 `upstream_endpoint` 是备端点、`failover_count == 1` |
| 48 | **同一次调用不复用失败端点**（v2.9） | 两个端点都失败 → 每个端点只被打一次（上游调用次数 = 端点数），错误沿用最后一次上游错误 |
| 49 | **熔断隔离**（v2.9） | 连续失败达到 `failure_threshold` → 该端点被断开，后续调用不再打它（上游调用次数不增加） |
| 50 | **半开试探**（v2.9） | 冷却结束后该端点被放行一次试探；试探成功 → 恢复闭合 |
| 51 | **全部端点不可用**（v2.9） | 所有端点都在熔断中 → 503 `GW_UPSTREAM_UNAVAILABLE`，`retriable == true` |
| 52 | **内容层错误不计入熔断**（v2.9） | 上游返回坏 JSON（内容层失败）→ 端点**不**被断开 |
| 53 | **单端点行为不回归**（v2.9） | 不配 `upstreams` 时行为与 v2.8 一致：同一个端点按原有重试逻辑重试 |
| 54 | **上游 4xx 改道**（v2.10） | 上游 400 → **502 `GW_UPSTREAM_REJECTED`**（不再是 400 `GW_INVALID_REQUEST`），`type == "upstream"`、`retriable == false`；不重试（上游调用次数 = 1）；端点**不**熔断（确定性拒绝不是端点的健康问题）；上游 401/403 仍是 `GW_AUTH_ERROR`、429 仍是 `GW_UPSTREAM_RATE_LIMITED` |
| 55 | **流式结算：正常结束**（v2.10） | 流式跑完后 tpm 桶按**实际用量**结算（桶里退掉的是「预扣 − 实际」，不是全额的预扣） |
| 56 | **流式结算：中途断开**（v2.10） | 客户端在流中断开 → 按「输入估算 + 已产出文本估算」结算（桶比「完全不结算」多退了额度） |
| 57 | **流式结算：首字节前失败**（v2.10） | 上游在吐出第一个事件前就失败 → **不结算**，预扣保留（上游可能已计费） |
| 58 | **上游 429 惩罚扣减**（v2.10） | `penalize_on_upstream_429 = true` 且上游 429 → 该次尝试的预扣量被**额外**扣掉；关闭时不扣（两者桶余额差 == 该次尝试的预扣量） |
| 59 | **首 token 超时**（v2.10） | 上游连上但不吐事件 → 超过 `first_token` 即 `GW_UPSTREAM_TIMEOUT`（**早于** `stream_idle` 生效，不空等） |
| 60 | **重试预算含 attempt_timeout**（v2.10） | 剩余预算不足以跑完一次尝试时**不再重试**（上游调用次数不增加），直接返回最后一次错误 |
| 61 | **流式不受总 deadline 约束**（v2.10） | 流式总耗时超过 `deadline` 仍能正常跑完（不被掐断），末事件仍是 `type == "done"` |
| 62 | **限流桶并发安全**（v2.10） | 多线程并发 `consume()`，放行次数**恰好**等于配额（不多放也不少放） |
| 63 | **429 带 Retry-After**（v2.10） | 本地 429 的响应带 `Retry-After` 头，值 ≥ 1 秒；上游 429 带 `Retry-After` 时沿用上游的值 |
| 64 | **工作台页面可匿名访问**（v2.11） | 开鉴权时 `GET /console/` **不带** `Authorization` → 200、`content-type` 为 `text/html`，body 含 `assets/app.js`（证明挂载指向真实目录而不是空壳） |
| 65 | **挂载点补斜杠**（v2.11） | `GET /console` → 307，`Location` 以 `/console/` 结尾 |
| 66 | **根路径跳转**（v2.11） | `GET /` → 307 → `/console/`；**不带** key 也是 307（证明 `/` 在免鉴权集合里，否则浏览器访问根会先被 401 掉） |
| 67 | **静态资源可取**（v2.11） | `GET /console/assets/app.js` → 200 且 content-type 含 `javascript`；`styles.css` → 200 且含 `text/css` |
| 68 | **静态资源 404 用网关信封**（v2.11） | `GET /console/nope.js` → 404，body 是 `{"error":{...}}` 而不是 HTML 错误页 |
| 69 | **挂载不遮蔽 API**（v2.11） | `/v1/models`、`/v1/metrics`、`/v1/requests`、`/healthz` 的行为**零变化**（回归网） |
| 70 | **豁免不外溢**（v2.11） | 开鉴权时不带 key 的 `/v1/metrics` → 401 `GW_UNAUTHORIZED`，同时 `/console/` → 200 |
| 71 | **前缀豁免边界安全**（v2.11） | `GET /consolex` → **401**（钉死边界匹配：裸 `startswith` 会把它放行） |
| 72 | **路径穿越防护**（v2.11） | `GET /console/%2e%2e/main.py` → 404，且 body 不含 `create_app`（读不出仓库源码） |
| 73 | **静态目录 fail fast**（v2.11） | 把静态目录指向不存在的路径 → `create_app()` 抛 `RuntimeError`（启动失败，不是运行期 404） |
| 74 | **前端禁用 HTML 注入**（v2.11） | 扫描 `web/**/*.js`：§8.8.4 的禁用词一个都不出现（注释里也不许出现，否则误报） |
| 75 | **静态挂载不进契约文档**（v2.11） | `/openapi.json` 的 `paths` 里**没有** `/console` 与 `/` |
| 76 | **试调用页签已挂载**（v2.12） | `GET /console/assets/views/playground.js` → 200 且 content-type 含 javascript；`index.html` 含「试调用」页签与 `view-playground` 容器 |
| 77 | **试调用只用已存在的接口**（v2.12） | 扫描 `web/assets/views/playground.js`：**唯一**的 POST 目标是 `/v1/chat/completions`——前端不得自己发明后端接口（§8.9.1） |
| 78 | **试调用不自动发送**（v2.12） | 扫描 `playground.js`：不含定时器（`setInterval` / `setTimeout`）——副作用只能由用户点击触发（§8.9.4） |
| 79 | **互斥提示与后端一致**（v2.12） | 后端对 `stream` + `output_schema` 返回 400 `GW_INVALID_REQUEST`；前端源码里的互斥提示写明**同一个**错误码——两侧不会各说各话（§8.9.2） |
| 80 | **页签切换真的切换**（v2.12） | `styles.css` 里必须有 `[hidden] { display: none }` 级别的规则，且 `index.html` 用 `hidden` 属性标出非默认视图——否则组件自己的 `display: flex` 会盖掉 UA 的 `[hidden]`，所有页签同时显示（§8.8.3） |
| 81 | **Chat Provider 非流式解析**（v2.13） | `choices[0].message.content` → 正文；`reasoning_content` → 思维链；`prompt_tokens`/`completion_tokens`/`completion_tokens_details.reasoning_tokens`/`prompt_tokens_details.cached_tokens` 映射到五分类；`finish_reason` 中立化（`length`→`length`，其余→`stop`） |
| 82 | **Chat Provider 流式解析**（v2.13） | `delta.content` → `text_delta`；`delta.reasoning_content` → `reasoning_delta`；**空 delta 被跳过**（不产生空 `text_delta`）；带 `usage` 的帧 → `usage` 事件；`[DONE]` 哨兵被忽略；同帧双增量被拆成两个事件 |
| 83 | **Chat Provider 请求翻译**（v2.13） | 上游收到的 body 含 `model`/`messages`/`max_tokens`；`stream` 时含 `stream:true` 与 `stream_options:{"include_usage":true}`；`response_format` 仅在 `native` 模式下出现；`extra_body` 被透传 |
| 84 | **端到端非流式**（v2.13） | 200；响应 `id` 是 `lgw-` 前缀、`model` 是网关别名 `minimax-m2.7`（**不是**上游 id）；`usage` 分类正确；上游收到的 `Authorization` 是 `Bearer <key>` |
| 85 | **端到端流式**（v2.13） | 网关事件序列为 `text_delta…` → `usage` → `done`；**无** `[DONE]`；TTFT 有值；空 delta 帧不产生事件 |
| 86 | **结构化输出走 prompt_only**（v2.13） | 上游收到的 body **不含** `response_format`（因为该模型走 `prompt_only`）；但 system 消息里含 schema；返回内容符合 schema（本地校验通过） |
| 87 | **能力声明**（v2.13） | `GET /v1/models` 出现 `minimax-m2.7`，`capabilities.output_schema_strict == false`（prompt_only）、`max_output_tokens == 8192`、`max_input_tokens == 196608` |
| 88 | **未注册模型**（v2.13） | 请求 `minimax-m2.9` → 404 `GW_MODEL_NOT_FOUND`，**上游调用次数 = 0** |
| 89 | **上游错误映射**（v2.13） | 上游 401 → `GW_AUTH_ERROR`；上游 429 → `GW_UPSTREAM_RATE_LIMITED` 且可重试；上游 400 → 502 `GW_UPSTREAM_REJECTED`（不重试） |
| 90 | **流式上游错误帧**（v2.13） | 上游在流中返回 `{"error":{...}}` → 网关发出 `error` 帧 + `done{finish_reason:"error"}`，记录状态为失败，**不静默吞掉** |
| 91 | **`.env` 解析**（v2.14） | `KEY=VALUE` / `export KEY=VALUE` / `# 注释` / 空行 / 引号包裹（去引号）都能解析；没有 `=` 的行被跳过（不抛异常） |
| 92 | **`.env` 只补不覆盖**（v2.14） | 已存在的环境变量**不被** `.env` 覆盖；`.env` 里没有的键**不被**删除；`[env].file` 配空串 = 完全不加载 |
| 93 | **密钥文件**（v2.14） | `api_key_file` 指向的文件内容（去首尾空白）即密钥；环境变量与文件同时存在时**环境变量优先**；文件不存在 → 启动失败并点名路径 |
| 94 | **读不到密钥 = 启动失败**（v2.14） | 模型配了 `api_key_env` 但环境变量与 `.env` 都没有它 → `create_app()` 抛错，错误信息含模型名与变量名（**不是**运行期的 502） |
| 95 | **端到端用密钥文件**（v2.14） | 模型配 `api_key_file` → 上游收到的 `Authorization` 是 `Bearer <文件内容>` |

---

## 12. 实施里程碑

| 阶段 | 内容 | 产出 |
|---|---|---|
| M1 | 骨架 + 配置 + 类型 + 错误码 | `core/`, `main.py` 起得来 |
| M2 | Mock 上游（两种协议 + 故障注入） | `upstream/mock_server.py` |
| M3 | Provider（两种协议）+ Adapter（两个模型）+ 自注册 + 非流式链路 | `providers/`, `adapters/`, 端到端非流式跑通 |
| M4 | 流式 + 结构化输出 | SSE 端到端跑通 |
| M5 | 提示词版本管理 | `prompts/`, REST 端点 |
| M6 | 可观测性 | 记录 + 聚合 + 查询端点 |
| M7 | 韧性（传输层重试 + 内容层重试 + rpm/tpm 限流） | 429/重试/修复路径 |
| M8 | 测试补齐 + 文档 | 全量用例通过 |
| M9 | **契约切换（v2.0）**：设计文档先行 → 内部通路 → 一次性切换线上契约 → 文档收尾 | 对外契约变为网关自有契约；旧 OpenAI 形状彻底下线 |
| M10 | **站点鉴权（v2.6）**：设计文档先行 → 中间件 + 配置 → 用例 | `core/security.py`；`Authorization: Bearer` 入站鉴权 |
| M11 | **多租户（v2.7）**：设计文档先行 → 租户注册表 + 配额改造 + 归属 → 用例 | `core/tenants.py`；按 (租户, 模型) 限流；记录归属与数据隔离 |
| M12 | **定价与成本（v2.8）**：设计文档先行 → 价目表 + 成本计算 + 聚合 → 用例 | `core/pricing.py`；响应 / 记录 / 指标带 `cost_usd` |
| M13 | **多上游 failover + 熔断（v2.9）**：设计文档先行 → 端点池 + 熔断状态机 + 编排接入 → 用例 | `upstream/pool.py`、`resilience/circuit_breaker.py`；按优先级切换端点 |
| M14 | **修正实现与规范不一致（v2.10）**：设计文档先行 → 错误码改道 + 时间预算修正 + 流式结算 + 惩罚扣减 + 限流加锁 + `Retry-After` → 用例 | `GW_UPSTREAM_REJECTED`；`first_token` 生效；流式结算；`Retry-After` 头 |
| M15 | **前端工作台（v2.11）**：设计文档先行 → 静态挂载 + 根路径跳转 → 前端页面 → 用例 | `web/`；`/console` 挂载；只读可观测面板 |
| M16 | **试调用页签（v2.12）**：设计文档先行 → 表单 + SSE 帧展示 → 用例 | `web/assets/views/playground.js`；工作台第五个页签 |
| M17 | **真实上游接入（v2.13）**：设计文档先行 → Chat Completions Provider + MiniMax Adapter + Mock 第三协议 → 用例 → 真机验证 | `providers/openai_chat_completions.py`；`adapters/models/minimax_m2_7.py`；`minimax-m2.7` 指向真实端点 |
| M18 | **上游密钥供给（v2.14）**：设计文档先行 → `.env` 加载器 + `api_key_file` + 启动期校验 → 用例 | `core/secrets.py`；`.env` 免环境变量启动；缺密钥时启动即失败 |

---

## 13. 风险与取舍

| 风险 | 取舍 |
|---|---|
| Token 估算不精确 | 用可解释的启发式估算；估算器抽象为独立接口，后续换 tiktoken。tpm 是保护性限流，不用于计费 |
| 进程内限流不支持多实例 | 本期单实例；`RateLimiter` 接口预留 Redis 实现位置 |
| Anthropic 结构化输出靠 tool use 变通 | 与真实 Anthropic API 的官方做法一致；schema 约束强度略弱于 Responses 的 `strict:true`，已通过校验器兜底 |
| Mock 与真实上游可能有出入 | Mock 严格对齐三种协议的官方事件名与字段形状；接真实端点时只需核对字段名。**v2.13 的教训**：Mock 对得上 ≠ 真实上游对得上——MiniMax 接受 `response_format` 却不执行，只有真机能看出来（见 §5.2.3）。因此接新模型必须真机验证 |
| MiniMax 的 `response_format` 不执行（v2.13） | 该模型走 `prompt_only`，靠网关本地校验 + 内容层重试兜底。代价是**没有上游硬拦截**，模型不听话时要靠重试救；收益是不会向调用方承诺一个上游没兑现的约束 |
| MiniMax 的 `reasoning_split` 是模型级参数（v2.13） | 思维链默认内联在 `content` 里（会污染正文）。把它放进 `extra_body` 配置而不是写死在 Provider 里——因为它是**模型**的知识不是**协议**的知识。代价是换模型时这条配置要跟着换 |
| MiniMax 未定价（v2.13） | `cost_usd` 恒为 `null`（未定价 ≠ 免费，见 §7.7.1）。真实成本只能从 MiniMax 控制台查。补价目表只需加一段 `[models."minimax-m2.7".pricing]` |
| 真实上游的未知字段被静默忽略（v2.13） | MiniMax 对未知 body 字段不报错。这不影响契约——网关自己的入参校验（`extra="forbid"`）在**上游之前**就把未知字段 400 掉了；上游的宽松只是多一层保险，不是漏洞 |
| 每加一个模型就要新增一个 Adapter 类 | 这是模型中心分层的固有代价：模型行为有明确归属，不会退化成协议类里堆 `if model == ...`。同协议新模型只需写一个很薄的 Adapter 类（复用 Provider），约 15 行 |
| `.env` 与密钥文件是明文（v2.14） | 密钥以明文躺在 `.env` 或密钥文件里，防护靠文件系统权限（`.env` 建议 `chmod 600`）与「不入版本库」。换来的是部署简单：不配环境变量也能起服务。代价是**不能**把密钥放在共享磁盘的明文目录里——这是运维侧的常识，不在网关能力范围内 |
| 缺密钥就启动失败（v2.14） | 只跑 mock、暂不接真上游的部署必须 `enabled = false` 或删掉 `api_key_env`。这是**显式选择**，好过运行期 401/502；代价是本地开发要多想一步 |
| Provider 层若将来也需要模型信息 | `ProtocolContext` 是窄接口，出现需要扩展时优先在 ctx 上加字段，而不是把整个 ModelSpec 塞进去；Provider 仍不得出现模型概念 |
| 重试产生额外计费 | 上游已收到并计费的失败请求不会退回，三个协议都不支持幂等键。已按"所有尝试 token 之和"统计，真实成本可见 |
| 内容层重试未必能救回 | 若模型能力不足或 schema 过于复杂，加提示也无效，代价是多烧两份 token。用 max_attempts（3）封顶，且本地修复层先拦掉大部分格式问题 |
| 内容层重试把上次输出回灌给模型 | self-repair 常规做法，但会放大敏感数据在提示中的出现。默认允许，可用 `structured_output.content_retry` 关闭 |
| 提示词全文不落库 | 重试后 prompt 变了，只存 hash + 强度档位。复现某次"成功"需比对 hash，必要时开 DEBUG 日志 |
| 熔断器未实现 | v2.9 已实现：每个上游端点独立的熔断状态机（见 §7.8.3），失败阈值与冷却时间可配 |
| prefill 未实现 | 强制 JSON 开头的成功率提升手段，留作 P2。属 Provider 层可选能力，见 7.2.10 |
| 契约切换是**破坏性变更**（v2.0） | 调用方必须改代码。**这是有意的**：兼容层（如 `AliasChoices` 兼容 `max_tokens`、保留 `response_format` 别名）会把旧词表留在契约里，等于没改。切换分阶段落地并单 commit，便于回滚 |
| 未知字段一律 400 可能"劝退"调用方 | 静默忽略才是更坏的选择——调用方会以为参数生效了。400 至少把问题暴露在第一次调用时 |
| `output_schema` 的保证依赖本地校验 | Anthropic 侧 tool use 只是建议，本地 `jsonschema` 校验才是保证的来源。代价是每条响应多一次本地校验（可忽略），收益是跨模型行为一致 |
| 客户端断开只对流式生效 | 非流式的上游调用在客户端断开后仍会跑完并计入 `usage`。省下的 token 有限，却要让非流式的重试与计量路径多出一套取消语义。流式是长连接、烧 token 多，因此只做流式（见 §5.1.1） |
| 断开检测依赖 ASGI 服务器投递 `http.disconnect` | 网关用轮询探针（250ms）而非等服务器主动通知，因此最坏情况多等 250ms。轮询而非事件，是因为 ASGI 规范没有规定断开时的投递时序，各服务器实现差异很大 |
| `X-Accel-Buffering` 只对 nginx 生效 | 其他代理（envoy、ALB）各有各的防缓冲头。契约里写死 nginx 这条是因为它是当前最常见的部署形态；换代理时需要补对应头 |
| 鉴权默认关闭（v2.6） | `[auth] enabled` 默认 `false`，方便本地起服务与现有测试；**上线必须显式打开**。「开了但没配 key」会直接启动失败，不会退化成"开着但不拦" |
| 站点级密钥没有租户隔离 | v2.6 的密钥是**站点级**的：拿到 key 就能用全部模型、共享同一份配额。真正的租户隔离（分租户配额 / 分租户可见模型）留待后续版本（见 §1.2） |
| 密钥存环境变量，多实例要各自注入 | 容器化部署时密钥要通过 secret 注入到每个实例；本进程内不做密钥的落盘加密 |
| 租户配额仍在进程内存里（v2.7） | 与模型级限流同一个实现，多实例部署时每个实例各算各的，实际总配额是 N 倍。需要共享配额时换成 Redis，接口位置已预留 |
| 未配置的租户默认「全模型 + 默认配额」（v2.7） | 这是让「只开鉴权不做隔离」零成本的代价。收紧要显式写 `[tenants.*]`——好处是不会「忘记配某个人」导致意外放开 |
| 租户身份靠 key 的 `name`（v2.7） | 租户名 = key 名，没有独立的「用户 → 租户」映射表。代价是「一个人多把钥匙」会算成多个租户；真需要时再加映射 |
| 管理员租户能看全部记录（v2.7） | 运维视角需要全局可见。记录里有提示词正文，管理员能看到全部租户的提示内容——这是「运维」这个角色本身的授权范围 |
| 成本是估算值不是账单（v2.8） | token 数来自上游 `usage`，上游没给时用本地估算兜底，误差直接进成本。网关不做金额结算，也不做多币种——**成本只用于「谁花了多少」的相对对账**，真要结算得另接账单系统 |
| 价目表挂在模型上而非租户上（v2.8） | 同一模型对所有租户同价，配置简单。代价是「老客户折扣」「内部免费额度」这类场景做不了，需要时再引入租户级覆盖（优先级：租户覆盖 > 模型价目表） |
| 缓存 token 的计价依赖归一化正确（v2.8） | 成本公式假定 `cache_read_tokens` 与 `input_tokens` 不重叠。当前三个协议都满足（缓存命中部分被上游单列：Anthropic 用 `cache_read_input_tokens`、MiniMax 用 `prompt_tokens_details.cached_tokens`）。若将来接的协议把缓存 token 同时计入 input，缓存那部分会被按 input 价重复计——这是**协议适配层要保证的归一化不变量** |
| 缓存写入没有独立价格（v2.8） | 本版本 `cache_write_tokens` 按 `input` 价计，不支持「写缓存比普通输入贵」的真实价目。部署方可用调高 `input` 价近似覆盖，代价是普通输入也被抬高 |
| 熔断状态在进程内存里（v2.9） | 与限流桶同一个实现，多实例部署时每个实例各断各的：实例 A 熔断了主端点，实例 B 还在打它。需要全局一致时把熔断状态换成共享存储（接口位置已预留） |
| 端点按优先级而非权重分流（v2.9） | 配置顺序就是优先级，健康时永远先打第一个。好处是行为可预测、故障语义清楚；代价是「两个等价端点各扛一半」做不到——那是负载均衡，不是 failover |
| 失败计数只算连续失败（v2.9） | 一次成功就把计数清零。因此「间歇性失败」的端点可能长期不断不了。要更激进就调低 `failure_threshold` |
| failover 不扩大重试预算（v2.9） | 换端点消耗的是同一次尝试，端点数多于 `max_attempts` 时靠后的端点用不上。宁可少试也不要让单次调用的上游花费失控 |
| 上游 429 计入熔断（v2.9） | 上游限流说明端点过载，计入熔断可以快速把它摘掉。但也可能是**整体配额**打满（所有端点一起限流），那时熔断只会让所有端点都被断开、返回 503。真出现这种情况应调大上游配额 |
| 上游 4xx 改 502（v2.10） | 调用方看到的 400 会变成 502，且错误码从 `GW_INVALID_REQUEST` 变成 `GW_UPSTREAM_REJECTED`。**这是有意的破坏性变更**：透传上游 400 会让调用方去查自己那份完全合法的请求体。代价是调用方原有的「上游 400 就是我参数写错了」的判断要改成看 `type == "upstream"` |
| 失败调用不退还限流额度（v2.10） | 上游可能已经计费，网关无从得知，因此失败的尝试保留预扣。代价是失败的调用会吃额度——但这本来就符合限流的本意（失败也占用了上游的真实负载）。若上游有明确的「未计费」信号（如响应头），将来可以据此退还 |
| 流式没有总 deadline（v2.10） | 一条只要持续吐字就能一直跑下去（上限是 `max_attempts × first_token + 退避`）。这是「长文本生成可能跑几分钟」的代价：网关不会替调用方掐断一条健康的流。调用方自己需要超时的话，在客户端侧设 |
| `threading.Lock` 而不是 `asyncio.Lock`（v2.10） | 限流器的接口是同步的，且结算可能发生在取消态的 `finally` 里——那里 `await` 一个 `asyncio.Lock` 不可靠。代价是临界区里不能有 `await`（限流器本来也没有），以及它对单事件循环没有额外收益，只是让跨线程调用变安全 |
| 工作台的密钥存在浏览器里（v2.11） | 复用网关现有 api key（不另造账号体系）意味着密钥落在 `localStorage`——**一次成功的 XSS 就等于站点级密钥泄漏**。因此「禁用 HTML 字符串注入」不是洁癖而是密钥保护的前置条件，并用 CI 断言钉住（§8.8.4）。代价是前端必须自己处理鉴权失败与密钥保管，无法享受 SSO 之类的能力 |
| 工作台的身份是「推断」出来的（v2.11） | 网关的 API 不返回「我是谁」，只能用 `by_caller` 单键 + 探测请求推断（§8.8.5）。这是**提示**而不是授权——数据可见范围始终由后端保证。代价是界面上的身份标签可能与用户直觉不符，故标注「推断」 |
| 提示词接口不按租户过滤（v2.11） | `GET /v1/prompts` 返回站点级模板，任何持 key 的调用方都能看到全部。这是**既有接口语义**（非本次引入），但工作台把它可视化了，故界面必须标注「站点级模板，非租户私有」 |
| 工作台没有配置编辑（v2.11） | 只读面板不改任何配置，代价是「改一个重试次数还要去翻 TOML」。换来的是：后端零业务改动、无写操作副作用、不需要新增 admin 鉴权与配置写盘校验 |
| 试调用页签让工作台不再纯只读（v2.12） | §8.9 每次发送都是一次**真实调用**：烧额度、占配额、在「调用记录」页留下记录。因此它必须**显式标注**副作用、**不自动发送**（§8.9.4），并与只读页签在导航上分开（排在最后）。换来的是：入口级 400（未知字段、`stream`⊕`output_schema` 互斥）与 SSE 帧形状第一次变得可见——这些是记录页永远看不到的 |
| 前端只做浅层校验（v2.12） | 表单只做 JSON 可解析性与明显结构缺失的检查，其余（长度上限、条数上限、`metadata` 值类型）全部交给后端。代价是用户可能白发一次请求；换来的是**只有一份契约真相**，不会因为前端复刻而漂移 |
| 前端不静默修正参数（v2.12） | `stream` 与 `output_schema` 同时有值时，前端只提示 + 给「仍要发送」的逃生口，**不替用户去掉一个**。代价是多一步操作；换来的是「前端悄悄改了我的请求」这种最难查的问题不会发生 |

---

## 14. 待确认事项

1. ~~对外是否暴露 Anthropic 原生格式入口~~ → 已确认（v2.0 修订）：**对外只有网关自有契约**，OpenAI / Anthropic 原生入口均不提供
2. ~~DeepSeek 别名~~ → 已确认：**配置别名**，可映射到真实端点
3. ~~限流维度~~ → 已确认：**rpm + tpm 双维度均启用**
4. ~~适配器粒度~~ → 已确认：**Adapter 按模型**，**Provider 按协议**，两者组合
5. ~~Provider 上下文~~ → 已确认：**窄接口 `ProtocolContext`**
6. ~~Adapter 基类~~ → 已确认：**保留薄基类，不引入协议基类**
7. ~~注册方式~~ → 已确认：**代码自注册**，配置不写 `adapter` 字段
8. ~~提示词注入位置~~ → 已确认：**两种模式都支持**（默认注入 system；模板含 `{{messages}}` 时整段替换）
9. ~~metrics 聚合时间窗~~ → 已确认：**全量累计**（进程生命周期内）
10. ~~非法 JSON 是否可重试~~ → 已确认：**可重试**，且重试时加强提示要求输出 JSON
11. ~~错误码细分~~ → 已确认：**区分** `GW_MALFORMED_UPSTREAM` / `GW_INVALID_JSON` / `GW_SCHEMA_MISMATCH`
12. ~~self-repair 允许回灌上次输出~~ → 已确认：**允许**
13. ~~重试后的 prompt 是否存全文~~ → 已确认：**只存 hash + 强度档位**
14. ~~限流扣减时机~~ → 已确认：**每次尝试扣桶**
15. ~~退避算法~~ → 已确认：**full jitter**
16. ~~时间预算~~ → 已确认：非流式 deadline 30s / attempt 10s；流式首 token 60s / chunk 间隔 60s
17. ~~上游 429 本地惩罚扣减~~ → 已确认：**默认关闭**，配置项 `penalize_on_upstream_429` 可开
18. ~~熔断器~~ → **已推翻（v2.9）**：v2.0 决定「本期不做」，v2.9 实现——
    每个上游端点独立的熔断状态机（closed / open / half_open），阈值与冷却可配（见 §7.8）
19. ~~max_attempts 语义~~ → 已确认：**总尝试 3 次**（最多重试 2 次）
20. ~~对外契约形态~~ → 已确认：**网关自有契约**（入参 / 出参 / 流式事件全改），路径仍是 `POST /v1/chat/completions`，**不保留** OpenAI 兼容入口
21. ~~结构化输出入参~~ → 已确认：**单一 `output_schema` 字段**；取消 schema-less 的 JSON 档（`json_object` 无 schema 语义，无损映射不了）
22. ~~原生工具调用~~ → 已确认：**本期不实现**，`tools` / `tool_choice` 传了直接 400
23. ~~流式是否也做 schema 校验~~ → **已推翻（v2.4）**：流式**不做** schema 校验，
    且 `stream` 与 `output_schema` **互斥**，同时出现直接 400。理由见 §5.1
    「为什么流式不做 schema 校验」——流尾校验是事后追认，对已经拿到增量的
    客户端没有帮助，反而让「200 ⇒ 内容符合 schema」这条保证变形。
    将来若要做「逐字段增量推送」，那是另一套契约（字段级 delta），另议。
24. ~~max_input_tokens 是否强制~~ → 已确认：**仅声明不强制**（token 估算是启发式的，强制会误拒）
25. ~~是否暴露采样旋钮与输出上限~~ → 已确认：**都不暴露**。`temperature` / `top_p` /
    `stop` / `seed` / `n` / `max_output_tokens` 一律按未知字段处理（400）——这些旋钮的
    跨厂商语义不一致，暴露它们等于把厂商差异泄漏回调用方；输出上限改为网关按模型能力
    决定，通过 `GET /v1/models` 的 `capabilities.max_output_tokens` 声明
26. ~~`messages[].content` 长度上限~~ → 已确认：**20000 字符**，超出即 400
    `GW_INVALID_REQUEST`，在入口拒绝（不消耗配额、不发上游请求）
27. ~~其余字段的入参校验~~ → 已确认：**每个调用方可控字段都要有约束**
    （见 §8.1.1 表格的「约束」列）。`metadata` 的值类型收紧为**字符串**
    （破坏性变更，调用记录里本来就是 `dict[str, str]`）
28. ~~客户端断开是否取消上游~~ → 已确认（v2.5）：**流式取消**——取消上游请求、
    不再发事件帧、记录 `status = "cancelled"`、不重试；**非流式不取消**
    （理由见 §5.1.1）
29. ~~响应头~~ → 已确认（v2.5）：**全部响应必带 `X-Request-ID`**（值与响应体
    `id` 一致）；**SSE 追加** `Cache-Control: no-cache, no-transform` 与
    `X-Accel-Buffering: no`（见 §8.1.4）
30. ~~站点鉴权怎么做~~ → 已确认（v2.6）：**只做 API Key**，走
    `Authorization: Bearer`；**密钥不进配置文件**（只存环境变量名）；
    生效范围为全部 `/v1/**`（`/healthz` 与 `/_mock/**` 除外）；
    失败一律 401 `GW_UNAUTHORIZED`，「没带」与「带错」响应完全一致（见 §8.6）
31. ~~鉴权是否默认开启~~ → 已确认（v2.6）：**默认关闭**，显式开启；
    开了却没配密钥 / 环境变量缺失 → **启动失败**
32. ~~多租户怎么隔离~~ → 已确认（v2.7）：**配额按 (租户, 模型) 分桶** +
    **模型可见性白名单** + **记录与指标按租户归属**；普通租户只看自己的数据，
    管理员租户（`admin = true`）看全局（见 §7.6）
33. ~~越权访问模型返回什么~~ → 已确认（v2.7）：**404 `GW_MODEL_NOT_FOUND`**，
    不用 403——403 会泄露「这个模型存在」
34. ~~配额粒度~~ → 已确认（v2.7）：**租户 × 模型**，三级回退：
    `model_rate_limit` > 租户 `rate_limit` > 模型默认
35. ~~成本怎么算~~ → 已确认（v2.8）：**价目表按模型配**（USD / 1M token，
    三档：input / output / cached_input），公式见 §7.7.2；**未定价 → `null`**，
    不当 0；成本出现在**响应体 / 流式 usage 事件 / 调用记录 / 指标桶**四处；
    重试按所有尝试之和（见 §7.7）
36. ~~成本要不要按租户差异化~~ → 已确认（v2.8）：**本期不做**。价目表只挂模型，
    租户差异化定价与账单结算留待后续版本（见 §1.2）
37. ~~多上游怎么配~~ → 已确认（v2.9）：**一个模型可配多个端点**
    （`[[models.*.upstreams]]`），**配置顺序 = 优先级**；不配就沿用原来的
    单 `base_url` 写法（向后兼容）
38. ~~failover 怎么触发~~ → 已确认（v2.9）：**同一次调用内换端点**，失败过的端点
    不再复用；换端点消耗的是同一次重试预算，不额外扩大尝试次数
39. ~~熔断器怎么做~~ → 已确认（v2.9）：**每个端点独立的 closed / open / half_open
    状态机**，阈值与冷却时间可配；只有上游侧故障计入熔断，内容层错误与本地错误不计
40. ~~全部端点不可用返回什么~~ → 已确认（v2.9）：**503 `GW_UPSTREAM_UNAVAILABLE`**，
    `retriable = true`；而「端点在本次调用里已试完」沿用最后一次上游错误
41. ~~上游 4xx 怎么映射~~ → 已确认（v2.10）：**502 `GW_UPSTREAM_REJECTED`**
    （`type = "upstream"`、不可重试、不计入熔断）；401/403 仍是 `GW_AUTH_ERROR`，
    429 仍是 `GW_UPSTREAM_RATE_LIMITED`。不再复用 `GW_INVALID_REQUEST`
42. ~~重试预算怎么算~~ → 已确认（v2.10）：**`剩余预算 >= 退避时长 + attempt_timeout`**——
    下一次尝试要能完整跑完才算还有预算
43. ~~流式有没有总 deadline~~ → 已确认（v2.10）：**没有**。流式只受
    `first_token`（每次尝试各自计时）与 `stream_idle`（chunk 间隔）约束
44. ~~`first_token` 由谁计时~~ → 已确认（v2.10）：**网关自己**用 `asyncio.wait_for`
    包住「建连 + 读到第一个事件」，超时按 `GW_UPSTREAM_TIMEOUT` 处理（首字节前可重试）
45. ~~流式怎么结算限流~~ → 已确认（v2.10）：正常结束按实际用量；中途出错/断开按
    「输入估算 + 已产出文本估算」；**首字节前失败不结算**（预扣保留）
46. ~~上游 429 惩罚扣多少~~ → 已确认（v2.10）：扣**该次尝试的预扣量**
    （预估输入 + 输出上限）；默认仍关闭
47. ~~限流桶用什么锁~~ → 已确认（v2.10）：**`threading.Lock`**，粒度是每个
    (租户, 模型) 一把；不用 `asyncio.Lock` 是因为结算可能发生在取消态的 `finally` 里
48. ~~429 的退避建议怎么给~~ → 已确认（v2.10）：**响应头 `Retry-After`（秒，向上取整，
    最少 1）**；`details.retry_after` 有值的错误都带这个头
49. ~~工作台用什么技术栈~~ → 已确认（v2.11）：**无构建的纯静态前端**（HTML + CSS +
    原生 ES module），**不引框架、不装 `node_modules`**；图表用 ECharts CDN + 降级
50. ~~工作台要不要自己的账号体系~~ → 已确认（v2.11）：**不另造**。复用网关现有的
    api key，前端存 `localStorage`；数据可见范围仍由后端按租户隔离保证
51. ~~工作台挂在哪~~ → 已确认（v2.11）：挂 **`/console`**（不挂 `/`），根路径
    307 跳过去；与后端**同源**，因此**不需要 CORS**；`/console/**` 与 `/` 免鉴权
    （页面本身不含数据）
52. ~~要不要给工作台加配置开关~~ → 已确认（v2.11）：**本期不加**。保持后端改动只有
    「挂静态页面」这一件事；代价是所有部署都会暴露 `/console` 页面（页面本身无数据，
    取数仍需 key）
53. ~~工作台要不要能发请求~~ → 已确认（v2.12）：**加一个页签，但只加一个**
    （§8.9「试调用」）。它**不新增任何后端接口**——只是把 `POST /v1/chat/completions`
    摆到界面里，让入口级 400 与 SSE 帧形状变得可见。代价是这一页有副作用
    （烧额度），因此必须显式标注、不自动发送；换来的是契约本身第一次可被观察
54. ~~接 MiniMax 只需加 Adapter 吗~~ → **已推翻（v2.13）**：**不止**。
    MiniMax 的 OpenAI 兼容入口是 **Chat Completions** 协议，与现有的 Responses /
    Messages 都不同，因此要**新增一个 Provider**（协议层）**再加一个 Adapter**
    （模型层）。协议 ≠ 模型这条分界线在真机接入时被验证了一次
55. ~~MiniMax 的结构化输出用 native 吗~~ → **已推翻（v2.13）**：**用 `prompt_only`**。
    实测 MiniMax 接受 `response_format`（HTTP 200）但**不执行**，输出仍是散文。
    声明 `native` 等于向调用方承诺一个上游没兑现的硬约束。真正的保证仍来自
    网关本地校验（见 §5.2.3）
56. ~~MiniMax 的模型 id 怎么写~~ → 已确认（v2.13）：`GET /v1/models` 的规范写法是
    **`MiniMax-M2.7`**（CamelCase，大小写不敏感）；网关别名是 `minimax-m2.7`
57. ~~MiniMax 要不要定价~~ → 已确认（v2.13）：**先不配**，该模型记为**未定价**
    （`cost_usd = null`，≠ 免费，见 §7.7.1）
58. ~~接真实上游要不要改对外契约~~ → 已确认（v2.13）：**不改**。`/v1/*` 的入参、
    出参、流式事件全都不变；新增的只是内部的一种协议与一个模型
59. ~~上游密钥怎么给真实用户~~ → **已推翻（v2.14）**：**不能只靠进程环境变量**。
    环境变量对开发者友好、对真实部署不友好（systemd / Docker / K8s 各有各的注入方式，
    运维还得额外记「哪个变量名对应哪家的 key」；忘配了不会在启动时暴露，而是变成一个
    含义模糊的 502 `GW_AUTH_ERROR`）。改为**三种来源**：`api_key_env`（环境变量）、
    `api_key_file`（密钥文件，契合 secret 挂载）、`.env` 自动加载（免环境变量起服务）；
    优先级：环境变量 → 密钥文件；**读不到就在启动时失败**（见 §7.9）
60. ~~缺上游密钥要不要启动失败~~ → 已确认（v2.14）：**要**。与入站鉴权同一条纪律
    （§8.6.3）——配置错误在启动时暴露，而不是运行期变成 401/502。
    代价：只想跑 mock 的部署要把该模型 `enabled = false`
