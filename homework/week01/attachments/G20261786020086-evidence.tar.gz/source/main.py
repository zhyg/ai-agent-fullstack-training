"""应用装配入口（composition root）。

职责：读配置 → 造适配器/记录器/指标/提示词存储/限流器 → 组装 ChatService →
挂路由 → 注册 Mock 上游 → 挂统一错误处理。

架构位置：整个网关的最外层，FastAPI 应用实例在这里诞生。

对应的 Java 概念：
- `create_app()` ≈ Spring 的 `@Configuration` 类 + `@Bean` 方法，本质是手工
  的依赖注入容器。
- `app.state.gateway` ≈ 把单例组件挂在 ApplicationContext 上，路由层通过
  `request.app.state.gateway` 取用。
- `@asynccontextmanager` ≈ try-with-resources 的异步版：`yield` 之前是启动逻辑，
  `yield` 之后是关闭逻辑。
- `httpx.AsyncClient` ≈ 共享的 HTTP 连接池，必须全局复用一个，不能每次请求新建。
"""

from __future__ import annotations

import json
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.types import ASGIApp, Receive, Scope, Send

from adapters.registry import build_adapters
from api.routes import error_response, router
from core.config import (
    PricingConfig,
    Settings,
    load_settings,
    validate_upstream_secrets,
)
from core.errors import ErrorCode, GatewayError
from core.pricing import PriceTable
from core.security import Authenticator
from core.tenants import TenantRegistry
from core.types import UpstreamEndpoint, new_request_id
from observability.metrics import Metrics
from observability.recorder import Recorder
from prompts.manager import PromptManager
from prompts.store import PromptStore
from resilience.pipeline import ChatService
from resilience.ratelimit import RateLimiter
from upstream.client import UpstreamClient
from upstream.mock_server import create_mock_router
from upstream.pool import UpstreamPool


class _RequestIdMiddleware:
    """纯 ASGI 中间件：给每个请求分配一个网关 request id。

    放在中间件而不是路由里，是因为**错误响应**也要能带上它：请求体校验失败
    （400）发生在路由函数执行之前，此时路由自己生成的 id 还不存在。
    路由层通过 `request.state.request_id` 取同一个 id，保证「响应里的 id」与
    「错误信封里的 request_id」一致（契约 §8.1.4）。

    为什么不用 `@app.middleware("http")`：那是 Starlette 的 `BaseHTTPMiddleware`，
    它会用一个「等响应发完才算断开」的代理把 ASGI 的 receive 包起来，导致
    `request.is_disconnected()` **永远返回 False**——客户端断开的探测就废了
    （网关会在客户端已经走了之后继续让上游生成，白烧 token）。
    纯 ASGI 中间件原样透传 receive，探测才拿得到 `http.disconnect`。
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            # setdefault 而不是直接赋值：鉴权中间件可能已经分配过 id，
            # 两个中间件要给出**同一个** id（响应头 / 错误信封 / 调用记录三处一致）。
            scope.setdefault("state", {}).setdefault("request_id", new_request_id())
        await self.app(scope, receive, send)


# 免鉴权的路径（见 DESIGN §8.6.2）。
# /healthz：探针不该被迫持有密钥。
# /：只是 307 跳转到工作台，不返回任何内容。
# /_mock：Mock 上游是开发期设施，不是对外契约的一部分。
# /console：工作台的 HTML/JS/CSS 本身**不含任何业务数据**，真正的数据由浏览器
#   带 Authorization 头去调 /v1/* 取（见 DESIGN §8.8）。
_PUBLIC_PATHS = ("/healthz", "/")
_PUBLIC_PREFIXES = ("/_mock", "/console")

# 前端工作台（只读可观测面板，见 DESIGN §8.8）的静态资源目录。
# 用 __file__ 定位而不是相对 CWD：uvicorn 可能从任意工作目录启动，
# 相对路径会在「换个目录启动」时静默变成 404。
_WEB_DIR = Path(__file__).resolve().parent / "web"


def _is_public(path: str) -> bool:
    """路径是否免鉴权。

    前缀用**边界匹配**（`p` 本身，或 `p + "/"` 开头）而不是裸 `startswith`：
    否则 "/consolex" 也会被当成公开路径。改动很小，但把「前缀豁免」的边界钉死，
    避免以后再加公开前缀时复制这个坑。

    副作用：`/_mockfoo` 从「免鉴权」变成「要鉴权」——这是收紧，不是回归。
    """
    if path in _PUBLIC_PATHS:
        return True
    return any(
        path == prefix or path.startswith(prefix + "/") for prefix in _PUBLIC_PREFIXES
    )


def _header(scope: Scope, name: str) -> str | None:
    """从 ASGI scope 里取一个请求头的值（取不到返回 None）。

    ASGI 规范里头名是小写，但这里仍然做一次 lower() 比较——不依赖「上游框架
    一定按规范来」这种假设。
    """
    target = name.lower().encode()
    for key, value in scope.get("headers") or []:
        if key.lower() == target:
            return value.decode("latin-1")
    return None


class _AuthMiddleware:
    """入站 API Key 鉴权（纯 ASGI，见 DESIGN §8.6）。

    为什么放在中间件而不是路由依赖（FastAPI 的 `Depends`）：
    1. 未鉴权的请求**不会触发请求体解析**——不会因为「请求体非法」而暴露
       「先鉴权还是先校验」的顺序信息；
    2. 失败响应能与其它错误共用同一个信封（同一个 request_id、同一套响应头）；
    3. 纯 ASGI 中间件不会像 `BaseHTTPMiddleware` 那样包住 receive，
       破坏断开探测（见 `_RequestIdMiddleware` 的说明）。
    """

    def __init__(self, app: ASGIApp, authenticator: Authenticator) -> None:
        self.app = app
        self.authenticator = authenticator

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or _is_public(scope.get("path", "")):
            await self.app(scope, receive, send)
            return

        state = scope.setdefault("state", {})
        request_id = state.get("request_id") or new_request_id()
        state["request_id"] = request_id

        principal = self.authenticator.authenticate(_header(scope, "authorization"))
        if principal is None:
            await self._reject(send, request_id)
            return

        state["principal"] = principal
        await self.app(scope, receive, send)

    @staticmethod
    async def _reject(send: Send, request_id: str) -> None:
        """回 401：与其它错误同构的信封 + `WWW-Authenticate`。

        「没带 key」与「key 错了」渲染出**完全一样**的响应体，
        不给调用方「这个 key 存在但只是不对」的预言机。
        """
        error = GatewayError(
            ErrorCode.UNAUTHORIZED, "missing or invalid api key"
        )
        body = json.dumps(
            {"error": error.to_body(request_id)}, ensure_ascii=False
        ).encode("utf-8")
        await send(
            {
                "type": "http.response.start",
                "status": 401,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"x-request-id", request_id.encode()),
                    (b"www-authenticate", b"Bearer"),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


def create_app(
    settings: Settings | None = None,
    http_client: httpx.AsyncClient | None = None,
) -> FastAPI:
    """构造并返回一个配置好的 FastAPI 应用。

    参数：
    - settings：不为 None 时用调用方给的配置（测试用），否则从配置文件加载。
    - http_client：不为 None 时复用外部的 httpx 客户端（测试用）；此时应用
      **不会**负责关闭它。

    关键约束：注入的组件都是进程级单例，因此 `create_app()` 在一个进程里通常
    只调用一次（模块底部的 `app = create_app()` 就是这一次的产物，≈ Java 的
    `SpringApplication.run`）。
    """
    settings = settings or load_settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)

    # 上游密钥必须在启动时就齐备（DESIGN §7.9.3）：配了 api_key_env /
    # api_key_file 却读不到，就让进程起不来——而不是运行期变成上游 401、
    # 再被翻译成一个看不出「是缺密钥」的 502。
    validate_upstream_secrets(settings)

    adapters = build_adapters(settings)
    recorder = Recorder(settings.data_dir)
    metrics = Metrics()

    store = PromptStore(settings.data_dir / "prompts.json")
    store.load()
    prompt_manager = PromptManager(store)

    # 只为「启用的模型」建限流器；被禁用的模型不在字典里，限流时会直接放行。
    # 限流桶按 (租户, 模型) 分桶，配额由租户层解析（见 DESIGN §7.6.2）。
    tenants = TenantRegistry(
        settings.tenants,
        {alias: cfg.rate_limit for alias, cfg in settings.models.items() if cfg.enabled},
    )
    limiter = RateLimiter(tenants.quota)

    # 价目表（见 DESIGN §7.7）：只有配了 pricing 的模型才有价格，
    # 其余模型的 cost_usd 恒为 null（未定价 ≠ 免费）。
    pricing_by_model: dict[str, PricingConfig] = {}
    for alias, cfg in settings.models.items():
        if cfg.enabled and cfg.pricing is not None:
            pricing_by_model[alias] = cfg.pricing
    prices = PriceTable(pricing_by_model)

    # 多上游端点池（见 DESIGN §7.8）：只有配了 upstreams 的模型才有池子。
    # 配了 upstreams 就以它为准，模型上的 base_url / upstream_id / api_key_env 被忽略。
    pools: dict[str, UpstreamPool] = {}
    for alias, cfg in settings.models.items():
        if not cfg.enabled or not cfg.upstreams:
            continue
        endpoints = []
        for endpoint_cfg in cfg.upstreams:
            api_key = endpoint_cfg.api_key()
            endpoints.append(
                UpstreamEndpoint(
                    name=endpoint_cfg.name or endpoint_cfg.base_url,
                    base_url=endpoint_cfg.base_url,
                    upstream_id=endpoint_cfg.upstream_id,
                    api_key=api_key,
                )
            )
        pools[alias] = UpstreamPool(endpoints, settings.circuit_breaker)

    # 入站鉴权器：密钥在启动时从环境变量读取，读不到就抛异常（fail fast）。
    authenticator = Authenticator.from_config(settings.auth)

    owned_client = http_client is None
    client = http_client or httpx.AsyncClient()

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        """应用生命周期钩子：启动 / 关闭时各跑一次。

        `@asynccontextmanager` 把一个「含 yield 的异步函数」变成上下文管理器，
        ≈ Java 的 try-with-resources 的异步版：
        - `yield` 之前 = 启动阶段（这里不需要做什么，所以直接 yield）；
        - `yield` 之后 = 关闭阶段（关闭我们自己创建的 HTTP 连接池）。
        """
        # yield 之前 = 启动阶段，yield 之后 = 关闭阶段。
        yield
        # 只有自己创建的客户端才由自己关闭（外部注入的不越权管理）。
        if owned_client:
            await client.aclose()

    service = ChatService(
        settings=settings,
        adapters=adapters,
        limiter=limiter,
        recorder=recorder,
        metrics=metrics,
        prompt_manager=prompt_manager,
        client=UpstreamClient(client),
        tenants=tenants,
        prices=prices,
        pools=pools,
    )

    application = FastAPI(title="LLMGateway", version="1.0.0", lifespan=lifespan)
    # 把核心组件挂到 app.state 上，供路由层通过 request.app.state 取用。
    application.state.gateway = service
    application.state.http_client = client
    application.include_router(router)
    # Mock 上游：不需要真实厂商账号也能跑通整条链路。
    application.include_router(create_mock_router())

    # 前端工作台（只读面板，见 DESIGN §8.8）。
    # 挂在 /console 而不是 /：
    #   1. 挂 / 会让所有未匹配路径落到 StaticFiles，抢走网关自己的 404 处理；
    #   2. 挂 / 时若把 "/" 放进免鉴权前缀集合，startswith("/") 会命中一切路径，
    #      等于把整个网关（含 /v1/*）变成免鉴权。
    # mount 放在两处 include_router 之后：Starlette 按注册顺序匹配，先注册者先赢。
    # check_dir 保持默认（True）：web/ 目录缺失时**启动即失败**，而不是运行期 404。
    application.mount(
        "/console",
        StaticFiles(directory=_WEB_DIR, html=True),
        name="console",
    )

    @application.get("/", include_in_schema=False)
    async def _console_root() -> RedirectResponse:
        """根路径跳到工作台。

        放在路由层而不是让 StaticFiles 接管 "/"，是为了不遮蔽 /v1/*。
        307 而不是 302：语义上「资源换了位置」。
        """
        return RedirectResponse("/console/")

    # 入站鉴权（见 DESIGN §8.6）。
    # **添加顺序有意义**：Starlette 的 add_middleware 是「后加的在最外层」，
    # 所以这里先加鉴权、再加 request-id —— request-id 在最外层先分配 id，
    # 鉴权中间件在里层拿到的就是同一个 id。
    application.add_middleware(_AuthMiddleware, authenticator=authenticator)

    # 给每个请求分配一个网关 request id（见 _RequestIdMiddleware）。
    application.add_middleware(_RequestIdMiddleware)

    @application.exception_handler(GatewayError)
    async def _gateway_error_handler(request: Request, exc: GatewayError) -> JSONResponse:
        """统一错误出口：把 GatewayError 变成网关自有的错误信封 + 正确的状态码。

        ≈ Spring 的 `@ExceptionHandler(GatewayError.class)`。
        注意 api/routes.py 里的路由大多自己 try/except 转成了错误响应，
        这里是给「没被路由层接住、从更深层冒泡上来」的异常兜底。
        """
        request_id = getattr(request.state, "request_id", "") or new_request_id()
        return error_response(exc, request_id)

    @application.exception_handler(RequestValidationError)
    async def _validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        """请求体校验失败 → **400**（不是 FastAPI 默认的 422）。

        契约违规一律 400：调用方要能只靠状态码判断「是我写错了，重发也没用」。
        混用 422 会让「参数错」和「业务错」两种失败长得不一样。

        典型触发场景：未知字段（`tools` / `top_p` / `response_format` 等）、
        字段类型不对、缺必填字段。
        """
        error = GatewayError(
            ErrorCode.INVALID_REQUEST,
            "request body failed validation",
            details={"errors": _format_validation_errors(exc)},
        )
        request_id = getattr(request.state, "request_id", "") or new_request_id()
        return JSONResponse(
            status_code=error.http_status,
            content={"error": error.to_body(request_id)},
            headers={"X-Request-ID": request_id},
        )

    @application.exception_handler(StarletteHTTPException)
    async def _http_exception_handler(
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        """路由级 HTTP 异常（404 路径不存在 / 405 方法不对）也渲染成同一个信封。

        否则调用方会看到 FastAPI 默认的 `{"detail": "Not Found"}`，与网关其它
        错误的形状完全不同，客户端得写两套解析逻辑。
        """
        error = GatewayError(
            ErrorCode.INVALID_REQUEST,
            str(exc.detail) if exc.detail else "request could not be routed",
        )
        request_id = getattr(request.state, "request_id", "") or new_request_id()
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": error.to_body(request_id)},
            headers={"X-Request-ID": request_id},
        )

    return application


def _format_validation_errors(exc: RequestValidationError) -> list[dict]:
    """把 pydantic 的校验错误压成可读的列表：字段路径 + 原因。

    pydantic 的 `loc` 是元组（`("body", "messages", 0, "content")`），这里丢掉
    最前面的 "body"，拼成 `messages.0.content` 这样的路径，方便调用方定位。
    """
    formatted: list[dict] = []
    for item in exc.errors():
        location = [str(part) for part in item.get("loc", ()) if part != "body"]
        formatted.append(
            {
                "field": ".".join(location),
                "reason": item.get("msg", "invalid value"),
                "type": item.get("type", "value_error"),
            }
        )
    return formatted


# 供 `uvicorn main:app` 使用的应用实例。
app = create_app()
