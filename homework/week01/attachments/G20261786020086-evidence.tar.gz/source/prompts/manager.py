"""提示词版本解析与变量替换。

架构位置：网关「提示词层」的渲染端。上游是 HTTP 层传入的 `PromptRef`，下游
是调用编排层（resilience/pipeline.py）需要的消息列表；模板本身存在
`prompts/store.py` 里。

对应的 Java 概念：
- `re.compile(...)` ≈ Java 的 `Pattern.compile(...)`，`_PLACEHOLDER.findall/sub`
  ≈ `Matcher.find()` / `Matcher.replaceAll()`。
- `X | None` ≈ Java 的 `Optional<X>`。

占位符语法：`{{变量名}}` 或 `{{变量名|默认值}}`；`{{messages}}` 是特殊占位符，
会被展开成原始消息的 JSON。
"""

from __future__ import annotations

import json
import re

from pydantic import ValidationError

from core.errors import ErrorCode, GatewayError
from core.types import MAX_MESSAGE_CHARS, PromptRef, UnifiedMessage
from prompts.store import PromptStore, PromptTemplate, PromptVersion

# 占位符正则：{{ 名 }} 或 {{ 名|默认值 }}；名必须是合法标识符。
_PLACEHOLDER = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?:\|([^}]*))?}}")
_MESSAGES_PLACEHOLDER = "messages"


def _serialize_messages(messages: list[UnifiedMessage]) -> str:
    """展开 {{messages}} 用的形式：JSON 对象用 ", " 连接，可直接拼进 JSON 数组。"""
    return ", ".join(
        json.dumps({"role": m.role, "content": m.content}, ensure_ascii=False)
        for m in messages
    )


class PromptManager:
    """提示词管理器：解析版本 + 替换变量。

    关键约束：变量必须「声明了且都用到」——模板里出现未声明的占位符会报错，
    声明了却没用到的变量也会报错。这是为了让模板的接口保持明确，避免拼错
    变量名导致静默生成错误提示词。
    """

    def __init__(self, store: PromptStore) -> None:
        self.store = store

    def resolve(self, ref: PromptRef) -> tuple[PromptTemplate, PromptVersion]:
        """解析出请求指定的模板与版本。

        参数：`ref.version` 为 None 表示取模板的当前版本。

        返回值：(模板, 版本) 二元组。

        抛 GatewayError(ErrorCode.TEMPLATE_NOT_FOUND)：模板或该版本不存在。
        """
        template = self.store.get(ref.name)
        version_number = ref.version if ref.version is not None else template.current_version
        for version in template.versions:
            if version.version == version_number:
                return template, version
        raise GatewayError(
            ErrorCode.TEMPLATE_NOT_FOUND,
            f"prompt template '{ref.name}' has no version {version_number}",
        )

    def render(
        self, ref: PromptRef, messages: list[UnifiedMessage]
    ) -> tuple[list[UnifiedMessage], str]:
        """渲染模板并生成最终消息列表。

        返回 (渲染后的消息列表, 渲染后的模板文本)。

        两条路径：
        - 模板里含 `{{messages}}` 或 injection == "messages"：渲染结果本身必须
          是一段 JSON 消息数组，整段替换原消息列表。
        - 否则：渲染结果作为一条 system 消息，插在原消息列表最前面。

        抛 GatewayError：见 `_substitute` 与 `_as_message_list`。
        """
        template, version = self.resolve(ref)
        rendered = self._substitute(template, version, ref.vars, messages)

        if _MESSAGES_PLACEHOLDER in version.content or template.injection == "messages":
            return self._as_message_list(rendered), rendered

        try:
            system_message = UnifiedMessage(role="system", content=rendered)
        except ValidationError as exc:
            # 渲染结果超长（模板正文 + 变量拼起来的字符数超了单条上限）。
            # 这是调用方能间接影响的输入，翻译成 400 而不是让它冒泡成 500。
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                f"rendered prompt exceeds the {MAX_MESSAGE_CHARS} character limit",
            ) from exc
        return [system_message] + list(messages), rendered

    # --- 变量替换 -----------------------------------------------------

    def _substitute(
        self,
        template: PromptTemplate,
        version: PromptVersion,
        provided: dict,
        messages: list[UnifiedMessage],
    ) -> str:
        """把模板里的占位符替换成实际值。

        优先级：调用方传入的值 > 占位符自带的默认值 > 声明了但没给值（报错）。

        抛 GatewayError：
        - ErrorCode.TEMPLATE_VAR_UNDECLARED：模板里有未在 variables 中声明的占位符。
        - ErrorCode.TEMPLATE_VAR_MISSING：声明的变量没有提供值也没有默认值。
        - ErrorCode.TEMPLATE_VAR_UNUSED：声明了却没在模板里用到的变量。
        """
        declared = list(version.variables)
        placeholders = {
            name for name, _default in _PLACEHOLDER.findall(version.content)
        }
        placeholders.discard(_MESSAGES_PLACEHOLDER)

        undeclared = sorted(placeholders - set(declared))
        if undeclared:
            raise GatewayError(
                ErrorCode.TEMPLATE_VAR_UNDECLARED,
                f"template contains undeclared placeholders: {', '.join(undeclared)}",
            )

        used: set[str] = set()
        values: dict[str, str] = {}

        for name, default in _PLACEHOLDER.findall(version.content):
            if name == _MESSAGES_PLACEHOLDER:
                continue
            used.add(name)
            if name in provided:
                values[name] = str(provided[name])
            elif default:
                values[name] = default.strip()
            elif name in declared:
                raise GatewayError(
                    ErrorCode.TEMPLATE_VAR_MISSING,
                    f"missing value for prompt variable '{name}'",
                )
            else:
                raise GatewayError(
                    ErrorCode.TEMPLATE_VAR_UNDECLARED,
                    f"template contains undeclared placeholder '{name}'",
                )

        unused = sorted(set(declared) - used)
        if unused:
            raise GatewayError(
                ErrorCode.TEMPLATE_VAR_UNUSED,
                f"unused prompt variables: {', '.join(unused)}",
            )

        def replace(match: re.Match) -> str:
            """正则替换回调：每个占位符匹配到时调用一次，返回替换文本。

            ≈ Java 的 `Matcher.appendReplacement` 里自己拼替换串。
            """
            # 正则的替换回调（≈ Java 的 Matcher.appendReplacement + 自定义逻辑）。
            name = match.group(1)
            if name == _MESSAGES_PLACEHOLDER:
                return _serialize_messages(messages)
            return values.get(name, match.group(0))

        return _PLACEHOLDER.sub(replace, version.content)

    @staticmethod
    def _as_message_list(rendered: str) -> list[UnifiedMessage]:
        """把渲染结果解析成消息列表。

        抛 GatewayError(ErrorCode.INVALID_REQUEST)：
        - 渲染结果不是合法 JSON；
        - 渲染结果不是 JSON 数组；
        - 数组里有元素缺少 role / content 字段。
        """
        try:
            payload = json.loads(rendered)
        except (json.JSONDecodeError, ValueError) as exc:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                f"prompt rendered to a non-JSON message list: {exc}",
            ) from exc
        if not isinstance(payload, list):
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                "prompt rendered to a JSON value that is not a message list",
            )
        messages: list[UnifiedMessage] = []
        for item in payload:
            if not isinstance(item, dict) or "role" not in item or "content" not in item:
                raise GatewayError(
                    ErrorCode.INVALID_REQUEST,
                    "prompt rendered message list contains an invalid entry",
                )
            try:
                messages.append(
                    UnifiedMessage(role=item["role"], content=str(item["content"]))
                )
            except ValidationError as exc:
                # role 非法，或 content 超长——都是渲染结果本身不合法。
                raise GatewayError(
                    ErrorCode.INVALID_REQUEST,
                    "prompt rendered message list contains an invalid entry",
                ) from exc
        return messages
