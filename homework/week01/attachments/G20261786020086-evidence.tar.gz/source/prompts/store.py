"""提示词模板的 JSON 文件存储。内存是唯一读路径，写入时原子替换文件。

架构位置：网关「提示词层」的持久化端。`prompts/manager.py` 负责渲染，本模块
只负责存取「模板 + 版本历史」，两者之间由 `PromptStore` 这个接口隔开。

对应的 Java 概念：
- `pydantic.BaseModel` ≈ 带运行时校验的 Java POJO/record；
  `model_validate(dict)` ≈ Jackson 把 JSON 反序列化成对象。
- `os.replace(tmp, target)` ≈ Java NIO 的 `Files.move(..., ATOMIC_MOVE)`，
  POSIX 上是原子改名，读者要么看到旧文件要么看到新文件，不会看到半个文件。

关键约束：内存字典是唯一读路径，磁盘只是持久化快照——所以每次写完内存后都要
`_flush()` 落盘，且落盘必须原子。
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from core.errors import ErrorCode, GatewayError


class PromptVersion(BaseModel):
    """模板的一个历史版本：内容 + 声明的变量 + 备注 + 创建时间。

    版本号在同一个模板内自增；内容变化不影响旧版本，可随时回滚。
    """

    version: int
    content: str
    variables: list[str] = Field(default_factory=list)
    note: str = ""
    created_at: str = ""


class PromptTemplate(BaseModel):
    """一个提示词模板：名字 + 若干版本 + 当前生效版本号。

    `injection` 决定渲染结果怎么用：
    - "system"：渲染文本作为一条 system 消息插到消息列表最前面。
    - "messages"：渲染文本必须是一段 JSON 消息数组，整段替换消息列表。
    """

    name: str
    description: str = ""
    injection: str = "system"  # system | messages
    current_version: int = 1
    versions: list[PromptVersion] = Field(default_factory=list)


def _now() -> str:
    """当前 UTC 时间的 ISO-8601 字符串（秒精度）。"""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class PromptStore:
    """模板存储：内存字典 + 单个 JSON 文件。

    关键约束：没有加锁——它假定由单线程（FastAPI 的启动装配阶段）使用；
    多线程写入需要自己加 `threading.Lock`（≈ Java 的 `synchronized`）。
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        self._templates: dict[str, PromptTemplate] = {}

    # --- 持久化 -------------------------------------------------------

    def load(self) -> None:
        """从 JSON 文件把全部模板读进内存。文件不存在时视为空库。

        抛异常：JSON 格式错误或内容不符合模型结构时，pydantic 会直接抛
        `ValidationError`（此处没有吞掉，是刻意的——启动期就应该失败）。
        """
        if not self.path.exists():
            self._templates = {}
            return
        raw: dict[str, Any] = json.loads(self.path.read_text(encoding="utf-8"))
        self._templates = {
            name: PromptTemplate.model_validate(data)
            for name, data in (raw.get("templates") or {}).items()
        }

    def _flush(self) -> None:
        """把内存里的模板全量写回 JSON 文件（原子替换）。

        做法：先写临时文件，再 `os.replace` 原子改名覆盖目标文件。
        为什么不用直接写目标文件：直接写中途崩溃会留下半截 JSON，下次启动
        就读不出来；原子改名保证磁盘上永远是完整的一份。

        抛异常：磁盘错误会向上抛（写失败不能假装成功）。
        """
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "templates": {
                name: template.model_dump() for name, template in self._templates.items()
            }
        }
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        os.replace(tmp, self.path)

    # --- 读 -----------------------------------------------------------

    def list_templates(self) -> list[PromptTemplate]:
        """列出全部模板（副本 list，调用方改动不影响内部状态）。"""
        return list(self._templates.values())

    def get(self, name: str) -> PromptTemplate:
        """按名字取模板。

        抛 GatewayError(ErrorCode.TEMPLATE_NOT_FOUND)：模板不存在。
        """
        template = self._templates.get(name)
        if template is None:
            raise GatewayError(
                ErrorCode.TEMPLATE_NOT_FOUND, f"prompt template '{name}' not found"
            )
        return template

    # --- 写 -----------------------------------------------------------

    def create(
        self,
        name: str,
        content: str,
        variables: list[str] | None = None,
        description: str = "",
        injection: str = "system",
        note: str = "",
    ) -> PromptTemplate:
        """新建模板，初始版本号固定为 1。

        抛 GatewayError(ErrorCode.INVALID_REQUEST)：同名模板已存在。
        """
        if name in self._templates:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST, f"prompt template '{name}' already exists"
            )
        template = PromptTemplate(
            name=name,
            description=description,
            injection=injection,
            current_version=1,
            versions=[
                PromptVersion(
                    version=1,
                    content=content,
                    variables=variables or [],
                    note=note,
                    created_at=_now(),
                )
            ],
        )
        self._templates[name] = template
        self._flush()
        return template

    def add_version(
        self,
        name: str,
        content: str,
        variables: list[str] | None = None,
        note: str = "",
    ) -> PromptTemplate:
        """追加一个新版本，并把它设为当前版本。

        参数：`variables` 为 None 时**继承上一版本的变量声明**（显式传空列表则
        表示清空）。

        抛 GatewayError(ErrorCode.TEMPLATE_NOT_FOUND)：模板不存在。
        """
        template = self.get(name)
        version = max((v.version for v in template.versions), default=0) + 1
        template.versions.append(
            PromptVersion(
                version=version,
                content=content,
                variables=variables if variables is not None else template.versions[-1].variables,
                note=note,
                created_at=_now(),
            )
        )
        template.versions.sort(key=lambda v: v.version)
        template.current_version = version
        self._flush()
        return template

    def rollback(self, name: str, version: int) -> PromptTemplate:
        """回滚：把当前版本号切到指定的历史版本。

        注意：历史版本**不会删除**，只是切换「当前生效版本」，因此可以再切回来。

        抛 GatewayError：
        - ErrorCode.TEMPLATE_NOT_FOUND：模板不存在。
        - ErrorCode.INVALID_REQUEST：目标版本号不存在。
        """
        template = self.get(name)
        if not any(v.version == version for v in template.versions):
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                f"prompt template '{name}' has no version {version}",
            )
        template.current_version = version
        self._flush()
        return template
