"""提示词管理接口的请求体模型。

架构位置：网关「接口层」的数据契约层。`PromptCreateRequest` ≈ 一个带校验的
Java request DTO（≈ Spring 的 `@RequestBody` + `@Valid`）。

**这里不再有「统一响应 → 兼容响应」的转换层**：网关对外的契约就是它自己的
`UnifiedResponse`（见 DESIGN §8.1），不需要再翻译成任何厂商的形状。

对应的 Java 概念：
- `pydantic.BaseModel` ≈ 带运行时校验的 Java POJO/record；字段声明即 JSON 契约。
- `Field(default_factory=list)` ≈ 每次 new 都新建一个空列表（不能写 `= []`，
  那样所有实例会共享同一个可变默认值）。
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class PromptCreateRequest(BaseModel):
    """创建提示词模板的请求体。`injection` 只能是 "system" 或 "messages"。"""

    name: str
    content: str
    variables: list[str] = Field(default_factory=list)
    description: str = ""
    injection: str = "system"
    note: str = ""


class PromptVersionRequest(BaseModel):
    """追加模板版本的请求体。`variables` 为 None 表示继承上一版本的声明。"""

    content: str
    variables: list[str] | None = None
    note: str = ""


class PromptRollbackRequest(BaseModel):
    """回滚请求体：目标版本号。"""

    version: int
