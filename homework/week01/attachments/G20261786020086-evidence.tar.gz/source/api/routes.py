"""HTTP 路由层：对外暴露网关自有契约的对话接口与运维接口。

架构位置：网关最外层。它只做三件事：解析请求 → 调用编排层（resilience/pipeline.py）
→ 把结果转成 JSON 或 SSE。所有业务逻辑都在下层，这里不碰限流、重试、模型差异。

对外契约是**网关自己的**，不是任何厂商的兼容层：请求体是 `LLMRequest`，
响应体是 `UnifiedResponse`，流式事件是 `UnifiedStreamEvent`（见 DESIGN §8.1）。

对应的 Java 概念：
- `@router.get/post` ≈ Spring MVC 的 `@RestController` + `@GetMapping`/`@PostMapping`；
  FastAPI 会按函数签名自动解析请求体和查询参数（相当于 Spring 的
  `@RequestBody` + `@RequestParam`），并把返回值自动序列化成 JSON。
- `request.app.state.gateway` ≈ 从 ServletContext 里取单例组件（≈ Spring 的
  `@Autowired` / `ApplicationContext.getBean`）。
- `async def` 路由 ≈ Spring MVC 的响应式控制器，不是 `CompletableFuture`。
- `JSONResponse` / `StreamingResponse` ≈ Spring 的 `ResponseEntity` 与
  `SseEmitter` / `StreamingResponseBody`。
"""

from __future__ import annotations

import math

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from api.schemas import (
    PromptCreateRequest,
    PromptRollbackRequest,
    PromptVersionRequest,
)
from core.errors import ErrorCode, GatewayError
from core.types import LLMRequest, new_request_id

router = APIRouter()

# 契约 §8.1.4：全部响应必带 X-Request-ID，值与响应体里的 id 一致。
_REQUEST_ID_HEADER = "X-Request-ID"

# 契约 §8.1.4：SSE 专用的两个头。
# Cache-Control 禁止中间层缓存 / 改写 SSE；X-Accel-Buffering 告诉 nginx 别缓冲
# ——不缓冲才能保住流式效果与 TTFT（直连 uvicorn 没有代理层，本地测不出来）。
_SSE_HEADERS = {
    "Cache-Control": "no-cache, no-transform",
    "X-Accel-Buffering": "no",
}


def _request_id(request: Request) -> str:
    """取本次请求的网关 request id。

    优先用中间件分配的那个（见 main.py 的 `_request_id_middleware`），
    保证「响应头」「错误信封」「调用记录」三处用的是同一个 id。
    """
    return getattr(request.state, "request_id", "") or new_request_id()


def _caller(request: Request) -> str:
    """取本次请求的租户标识（见 DESIGN §7.6）。

    来自入站鉴权中间件放进来的 Principal；未开启鉴权时是 `anonymous`。
    """
    principal = getattr(request.state, "principal", None)
    return getattr(principal, "name", "") or "anonymous"


def error_response(exc: GatewayError, request_id: str) -> JSONResponse:
    """把内部异常统一成错误信封：`{"error": {...}}` + 对应 HTTP 状态码。

    429 的错误额外带 `Retry-After` 头（见 DESIGN §8.1.4）：调用方的标准 HTTP
    客户端读的是头而不是 body，缺了这个头就只能自己猜退避时间。
    """
    headers = {_REQUEST_ID_HEADER: request_id}
    retry_after = exc.details.get("retry_after")
    if retry_after is not None:
        # 秒数、向上取整、最少 1 秒——「马上再来」对客户端没有意义。
        headers["Retry-After"] = str(max(1, math.ceil(float(retry_after))))
    return JSONResponse(
        status_code=exc.http_status,
        content={"error": exc.to_body(request_id)},
        headers=headers,
    )


@router.post("/v1/chat/completions")
async def chat_completions(payload: LLMRequest, request: Request):
    """网关自有的对话接口：`payload` 由 pydantic 自动从 JSON 请求体解析校验。

    **未知字段一律 400**（`LLMRequest` 是 `extra="forbid"`）——调用方拼错了
    参数名不能被静默丢弃，否则它会以为参数生效了。

    流式与非流式在这里分叉：流式返回 `StreamingResponse`，由编排层的
    AsyncIterator 逐帧产出 SSE；非流式直接把统一响应序列化出去（网关契约就是
    `UnifiedResponse` 本身，没有第二层翻译）。

    流式时把 `request.is_disconnected` 作为断开探针交给编排层：客户端断开后
    网关要立刻取消上游，而不是继续为一个已经不在的客户端生成（见 DESIGN §5.1.1）。

    抛 GatewayError：已由下面的 except 捕获并转成错误响应，不会冒泡。
    """
    service = request.app.state.gateway
    # 复用中间件分配的 id，保证响应里的 id 与错误信封里的 request_id 是同一个。
    request_id = _request_id(request)
    caller = _caller(request)
    try:
        if payload.stream:
            iterator = await service.start_stream(
                payload,
                request_id,
                is_disconnected=request.is_disconnected,
                caller=caller,
            )
            return StreamingResponse(
                iterator,
                media_type="text/event-stream",
                headers={_REQUEST_ID_HEADER: request_id, **_SSE_HEADERS},
            )
        response = await service.chat(payload, request_id, caller)
        return JSONResponse(
            response.model_dump(), headers={_REQUEST_ID_HEADER: request_id}
        )
    except GatewayError as exc:
        return error_response(exc, request_id)


@router.get("/v1/models")
async def list_models(request: Request):
    """列出可用模型及它们的能力声明。

    调用方据此判断「这个模型能不能满足我的需求」，不必先发一个请求、
    再从 400 里读出答案。

    **只返回当前租户可见的模型**（见 DESIGN §8.7）——模型清单本身也是信息，
    不该让无权访问的租户看到完整目录。
    """
    service = request.app.state.gateway
    visible = set(service.visible_models(_caller(request)))
    return {
        "models": [
            {
                "id": alias,
                "protocol": adapter.provider.protocol,
                "capabilities": adapter.capabilities(),
            }
            for alias, adapter in service.adapters.items()
            if alias in visible
        ],
    }


@router.get("/healthz")
async def healthz():
    """健康检查：只要进程能响应就返回 ok（不探测上游）。"""
    return {"status": "ok"}


@router.get("/v1/metrics")
async def metrics(request: Request):
    """返回聚合指标快照（全局 + 按模型 + 按租户）。

    管理员租户看到全局数据；普通租户只看到自己的（响应形状不变，
    见 DESIGN §8.7）。
    """
    service = request.app.state.gateway
    caller = _caller(request)
    if service.is_admin(caller):
        return service.metrics.snapshot()
    return service.metrics.snapshot(caller=caller)


@router.get("/v1/requests")
async def list_requests(request: Request, model: str | None = None, status: str | None = None,
                        limit: int = 50, offset: int = 0, caller: str | None = None):
    """分页查询最近的调用记录（数据来自内存滚动窗口，不是 jsonl 文件）。

    查询参数由 FastAPI 按函数签名自动解析（`model`/`status`/`caller` 可为空
    表示不过滤）。

    普通租户只能查自己的记录；显式查别人的 → 400（不静默忽略，见 §7.6.5）。
    """
    service = request.app.state.gateway
    me = _caller(request)
    if not service.is_admin(me):
        if caller is not None and caller != me:
            raise GatewayError(
                ErrorCode.INVALID_REQUEST,
                "cannot query call records of another caller",
            )
        caller = me
    records = service.recorder.list(
        model=model, status=status, limit=limit, offset=offset, caller=caller
    )
    return {
        "object": "list",
        "data": [record.model_dump() for record in records],
    }


# --- 提示词管理 -------------------------------------------------------


@router.get("/v1/prompts")
async def list_prompts(request: Request):
    """列出全部提示词模板。"""
    service = request.app.state.gateway
    return {
        "object": "list",
        "data": [
            template.model_dump()
            for template in service.prompt_manager.store.list_templates()
        ],
    }


@router.post("/v1/prompts")
async def create_prompt(payload: PromptCreateRequest, request: Request):
    """新建提示词模板（初始版本为 1）。同名模板会返回 400 错误。"""
    service = request.app.state.gateway
    try:
        template = service.prompt_manager.store.create(
            name=payload.name,
            content=payload.content,
            variables=payload.variables,
            description=payload.description,
            injection=payload.injection,
            note=payload.note,
        )
    except GatewayError as exc:
        return error_response(exc, _request_id(request))
    return template.model_dump()


@router.get("/v1/prompts/{name}")
async def get_prompt(name: str, request: Request):
    """按名字取提示词模板；不存在返回 404。"""
    service = request.app.state.gateway
    try:
        template = service.prompt_manager.store.get(name)
    except GatewayError as exc:
        return error_response(exc, _request_id(request))
    return template.model_dump()


@router.post("/v1/prompts/{name}/versions")
async def add_prompt_version(name: str, payload: PromptVersionRequest, request: Request):
    """给模板追加一个新版本，并把新版本设为当前版本。"""
    service = request.app.state.gateway
    try:
        template = service.prompt_manager.store.add_version(
            name=name,
            content=payload.content,
            variables=payload.variables,
            note=payload.note,
        )
    except GatewayError as exc:
        return error_response(exc, _request_id(request))
    return template.model_dump()


@router.post("/v1/prompts/{name}/rollback")
async def rollback_prompt(name: str, payload: PromptRollbackRequest, request: Request):
    """把模板的当前版本切换到指定的历史版本（版本本身不会被删除）。"""
    service = request.app.state.gateway
    try:
        template = service.prompt_manager.store.rollback(name, payload.version)
    except GatewayError as exc:
        return error_response(exc, _request_id(request))
    return template.model_dump()
