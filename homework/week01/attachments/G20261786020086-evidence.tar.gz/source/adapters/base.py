"""模型层适配器基类：声明「这个模型是什么、能干什么」，并把协议翻译委托给 Provider。

在整体架构中的位置：Provider 只懂协议（URL/鉴权/请求体怎么拼、响应怎么读），
Adapter 只懂模型（模型身份、能力上限、结构化输出怎么实现）。两者是「组合」关系而非
「继承」关系——Adapter 持有一个 Provider 实例并把翻译工作转交出去。
这样同一个协议可以服务多个模型，同一个模型换协议也不影响 Adapter 的模型语义。

对应的 Java 概念：这里用普通的 Python 类 + 类属性（不是 dataclass），子类通过
「重新声明类属性」来覆盖父类默认值 ≈ Java 里子类覆盖字段初始值；
组合持有 Provider ≈ Java 里 final 字段持有一个 collaborator 而非 extends。
"""

from __future__ import annotations

from dataclasses import dataclass

from core.config import ModelConfig
from core.types import (
    LLMRequest,
    ProtocolContext,
    SSEChunk,
    UnifiedResponse,
    UnifiedStreamEvent,
    UpstreamEndpoint,
)
from providers.base import BaseProvider, UpstreamRequest


@dataclass
class PreparedCall:
    """一次上游调用的准备结果：请求体 + 协议上下文（解析阶段复用同一份）。

    @dataclass ≈ 「Lombok @Data 生成的 POJO 或 Java record」：自动生成构造器、
    __repr__、__eq__。这里它是可变的普通 dataclass（不是 frozen），
    相当于 Java 里一个字段非 final 的 POJO。
    """

    upstream: UpstreamRequest
    ctx: ProtocolContext


@dataclass(frozen=True)
class StructuredPlan:
    """结构化输出的执行计划：**Adapter 决定用哪种 mode，Provider 实现该 mode 的协议机制**。

    之所以是具名 dataclass 而不是裸元组：`(mode, name, schema)` 这种三元组在调用点
    解包，一旦顺序写反就是「schema 传给了 name」这种难查的 bug。
    frozen=True ≈ Java 的 record（不可变，构造后不能改）。
    """

    mode: str  # none | native | tool_use | prompt_only
    schema_name: str | None = None
    schema: dict | None = None
    strict: bool = False


class ModelAdapter:
    """模型层：模型身份 + 能力声明 + 参数改写钩子。与 Provider 是组合关系。

    子类通常只需要覆盖几个类属性（alias / provider_class / structured_output_mode 等）
    就能表达一个新模型；只有需要附加模型专属参数时才覆写 _apply_model_overrides。
    """

    alias: str = ""
    provider_class: type[BaseProvider] = BaseProvider
    upstream_id: str = ""
    supports_output_schema: bool = True
    supports_streaming: bool = True
    structured_output_mode: str = "native"
    supports_prompt_cache: bool = False
    max_input_tokens: int = 128_000
    default_max_tokens: int = 4_096

    def __init__(self, cfg: ModelConfig) -> None:
        """构造适配器，并让配置覆盖类级别的默认值。

        顺序是有讲究的：先记下 cfg，再实例化 provider，
        然后用 `cfg.x or 类默认值` 的方式让「配置里显式给了值」优先。
        这里用 or 而不是 if is not None，意味着配置里写 0 会被当成「没填」而回退默认值，
        对 max_tokens 这类字段是合理的（0 本身没有意义）。
        """
        self.cfg = cfg
        self.provider = self.provider_class()
        self.upstream_id = cfg.upstream_id or self.upstream_id
        self.default_max_tokens = cfg.default_max_tokens or self.default_max_tokens
        self.max_input_tokens = cfg.max_input_tokens or self.max_input_tokens

    # --- 能力与上下文 -------------------------------------------------

    def structured_mode(self, req: LLMRequest) -> StructuredPlan:
        """根据请求里的结构化输出要求和模型自身能力，算出实际的执行计划。

        mode 的含义：
        - none：不需要 JSON，原样返回文本；
        - prompt_only：靠提示词约束模型输出 JSON（协议无原生支持时的兜底）；
        - native：上游协议原生支持 json_schema；
        - tool_use：上游没有 json_schema，改用「工具调用」模拟。

        模型声明的 structured_output_mode 就是它**用哪种机制**实现结构化输出，
        不是一个「支不支持」的开关——后者由 supports_output_schema 表达。
        """
        spec = req.output_schema
        if spec is None:
            return StructuredPlan(mode="none")
        return StructuredPlan(
            mode=self.structured_output_mode,
            schema_name=spec.name,
            schema=spec.schema_,
            strict=spec.strict,
        )

    def resolve_max_output_tokens(self) -> int:
        """输出上限的**唯一**解析点：网关按模型能力决定，调用方无法覆盖。

        限流预扣（tpm）和实际下发给上游的值都必须走这里，否则两者会不一致——
        预扣按 4096 算、实际只发 2048，桶就永远补不回多扣的那部分。

        调用方想知道自己能拿到多长的输出，查 `GET /v1/models` 的
        `capabilities.max_output_tokens`（可查、不可调）。
        """
        return self.default_max_tokens

    def _context(
        self, req: LLMRequest, endpoint: UpstreamEndpoint | None = None
    ) -> ProtocolContext:
        """组装给 Provider 用的协议上下文。

        这里刻意只填协议层需要的信息——没有 alias、没有 max_input_tokens，
        因为 Provider 不该知道「模型」这个概念，那是 Adapter 的职责。
        extra_body 传的是副本（dict(...)），避免 Provider 改动时污染配置对象。

        `endpoint` 是本次要打的上游端点（多上游 failover，见 DESIGN §7.8）。
        传 None 时用模型自身的单端点配置——单端点模型的行为与 v2.8 完全一致。
        """
        plan = self.structured_mode(req)
        if endpoint is None:
            base_url = self.cfg.base_url
            upstream_id = self.upstream_id
            api_key = self.cfg.api_key()
        else:
            base_url = endpoint.base_url
            upstream_id = endpoint.upstream_id or self.upstream_id
            api_key = endpoint.api_key
        return ProtocolContext(
            upstream_id=upstream_id,
            base_url=base_url,
            api_key=api_key,
            structured_output_mode=plan.mode,
            schema_name=plan.schema_name,
            json_schema=plan.schema,
            schema_strict=plan.strict,
            max_output_tokens=self.resolve_max_output_tokens(),
            extra_body=dict(self.cfg.extra_body),
            cache_prompt=self.supports_prompt_cache,
            state={},
        )

    # --- 对外动作 -----------------------------------------------------

    def capabilities(self) -> dict[str, object]:
        """声明这个模型能做什么，供 `GET /v1/models` 对外公布。

        调用方据此判断「这个模型能不能满足我的需求」，不必先发一个请求、
        再从 400 里读出答案。

        `output_schema_strict` 表示**上游能否施加硬约束**（即 structured_output_mode
        是不是 native）。tool_use / prompt_only 模式下上游只是"建议"，
        最终的保证来自网关本地的 schema 校验（见 DESIGN §5.2）。
        """
        return {
            "streaming": self.supports_streaming,
            "output_schema": self.supports_output_schema,
            "output_schema_strict": self.structured_output_mode == "native",
            "prompt_cache": self.supports_prompt_cache,
            "max_output_tokens": self.default_max_tokens,
            "max_input_tokens": self.max_input_tokens,
        }

    def prepare(
        self, req: LLMRequest, endpoint: UpstreamEndpoint | None = None
    ) -> PreparedCall:
        """准备一次上游调用：先建上下文，再让 Provider 拼请求，最后应用模型级改写。

        顺序不能颠倒——Provider 拼请求时要用到 ctx，而模型级改写要在协议翻译之后
        才能看到最终的 URL / body 才能改。

        `endpoint` 指定本次打哪个上游端点；None = 用模型自身的单端点配置。
        """
        ctx = self._context(req, endpoint)
        upstream = self.provider.build_request(req, ctx)
        self._apply_model_overrides(upstream, req)
        return PreparedCall(upstream=upstream, ctx=ctx)

    def parse_response(self, call: PreparedCall, raw: dict) -> UnifiedResponse:
        """把上游的非流式响应翻译回统一响应。

        复用 prepare 时建好的 ctx（而不是重新建一个），因为流式/非流式之间可能
        共享 state 里的解析状态。
        """
        return self.provider.parse_response(raw, call.ctx)

    def parse_stream_event(
        self, chunk: SSEChunk, ctx: ProtocolContext
    ) -> UnifiedStreamEvent | None:
        """把一个 SSE 事件翻译成统一流式事件；Provider 认不出来时返回 None（跳过即可）。"""
        return self.provider.parse_stream_event(chunk, ctx)

    # --- 模型级钩子 ---------------------------------------------------

    def _apply_model_overrides(self, upstream: UpstreamRequest, req: LLMRequest) -> None:
        """留给模型特例（如附加模型专属参数）。默认无操作。

        钩子方法（hook）：基类留一个空实现，子类按需覆写，
        相当于 Java 里的模板方法模式 / 默认空实现的 protected 方法。
        """
