"""适配器注册表：用「代码自注册」把配置里的模型名对上 Adapter 实现类。

在整体架构中的位置：启动时把 config.toml 里的每个模型条目变成一个可用的 ModelAdapter 实例。
新增模型只需写一个 Adapter 子类并声明 alias，这里自动发现，配置里加一行即可生效。

对应的 Java 概念：整体相当于 Spring 的组件扫描 + @Autowired 注入（或 ServiceLoader），
差别在于这里不靠注解，而是靠 Python 运行时能枚举出所有子类。
"""

from __future__ import annotations

import logging

from adapters.base import ModelAdapter
from core.config import Settings

logger = logging.getLogger(__name__)


def _all_subclasses(cls: type) -> list[type]:
    """递归收集 cls 的所有子类（含孙子类）。

    Python 的 cls.__subclasses__() ≈ Java 里 Class.getSubclasses()，
    但它只返回直接子类，所以需要自己递归。
    注意：这个 API 只知道已经被导入过的类，因此 discover_adapter_classes 里必须
    先 import 所有模型模块，否则它们的子类不会被注册。
    """
    found: list[type] = []
    for subclass in cls.__subclasses__():
        found.append(subclass)
        found.extend(_all_subclasses(subclass))
    return found


def discover_adapter_classes() -> dict[str, type[ModelAdapter]]:
    """代码自注册：扫描所有 ModelAdapter 子类，按其声明的 alias 建映射。

    返回 alias → 类对象（不是实例），实例的创建交给 build_adapters，
    因为实例需要注入 ModelConfig。

    下面那行 import 是必需的（noqa: F401 表示「故意导入但不使用」）：
    它的作用是把模型模块加载进来，让它们的类真正被创建、从而出现在 __subclasses__() 里。
    放在函数体内是为了避免模块级循环导入。
    """
    from adapters.models import (  # noqa: F401
        deepseek_v4_flash,
        deepseek_v4_pro,
        minimax_m2_7,
    )

    return {
        subclass.alias: subclass
        for subclass in _all_subclasses(ModelAdapter)
        if getattr(subclass, "alias", "")
    }


def build_adapters(settings: Settings) -> dict[str, ModelAdapter]:
    """按配置实例化所有启用的模型，返回 alias → Adapter 实例。

    两种不匹配都会被发现并处理：
    - 配置里有模型但代码里没有对应 Adapter → 抛 RuntimeError，因为配置写了却用不了，
      属于部署错误，必须尽早暴露（相当于 Java 里启动时 Bean 装配失败直接启动失败）；
    - 代码里有 Adapter 但配置里没有 → 只记 warning 并跳过，因为该模型只是暂时没开放。
    """
    classes = discover_adapter_classes()
    adapters: dict[str, ModelAdapter] = {}

    for alias, cfg in settings.models.items():
        if not cfg.enabled:
            logger.info("model %s disabled by config", alias)
            continue
        adapter_class = classes.get(alias)
        if adapter_class is None:
            raise RuntimeError(
                f"model '{alias}' has a config entry but no registered adapter class"
            )
        adapters[alias] = adapter_class(cfg)

    for alias in classes:
        if alias not in adapters:
            logger.warning("adapter class '%s' has no config entry, model unavailable", alias)

    return adapters
