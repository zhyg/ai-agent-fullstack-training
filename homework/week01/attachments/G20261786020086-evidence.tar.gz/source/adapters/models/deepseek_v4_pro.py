"""DeepSeek v4 pro 模型的适配器（走 OpenAI Responses API 协议）。

在整体架构中的位置：这是「模型层」的一个具体实现，只做两件事：
声明模型身份与能力，以及指定用哪个 Provider 来翻译协议。
它不含任何 HTTP 细节，那些都在 OpenAIResponsesProvider 里。

对应的 Java 概念：整个文件相当于一个只有几个字段的 Java 配置类/常量持有者，
继承自 ModelAdapter 相当于 extends ModelAdapter（这里用的是组合 Provider 而非继承）。
"""

from __future__ import annotations

from adapters.base import ModelAdapter
from providers.openai_responses import OpenAIResponsesProvider


class DeepSeekV4ProAdapter(ModelAdapter):
    """DeepSeek v4 pro —— OpenAI Responses API 协议。

    关键约束：结构化输出用 native 模式（上游协议原生支持 json_schema，无需变通），
    且不支持提示词缓存（cache_prompt 始终为 False）。
    上下文 128K、默认输出 4096 token。
    """

    alias = "deepseek-v4-pro"
    provider_class = OpenAIResponsesProvider
    upstream_id = "deepseek-v4-pro"

    structured_output_mode = "native"
    supports_prompt_cache = False

    max_input_tokens = 128_000
    default_max_tokens = 4_096
