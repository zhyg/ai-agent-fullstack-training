"""DeepSeek v4 flash 模型的适配器（走 Anthropic Messages API 协议）。

在整体架构中的位置：这是「模型层」的具体实现之一，展示了同一个模型家族
在不同协议下的差异表达——协议由 provider_class 决定，模型能力由其余类属性声明。

对应的 Java 概念：相当于一个继承 ModelAdapter、只有常量字段的 Java 子类；
provider_class 指定用哪个协议实现去干活（组合而非继承 Provider）。
"""

from __future__ import annotations

from adapters.base import ModelAdapter
from providers.anthropic_messages import AnthropicMessagesProvider


class DeepSeekV4FlashAdapter(ModelAdapter):
    """DeepSeek v4 flash —— Anthropic Messages API 协议。

    该模型走 Anthropic 协议且不提供原生 json_schema，结构化输出经 tool_use 变通。
    关键约束：tool_use 模式下 schema 会被包装成一个「工具定义」发给上游，
    模型以调用工具的方式返回 JSON，网关再把工具入参还原成结果。
    支持提示词缓存；上下文 64K、默认输出 2048 token。
    """

    alias = "deepseek-v4-flash"
    provider_class = AnthropicMessagesProvider
    upstream_id = "deepseek-v4-flash"

    structured_output_mode = "tool_use"
    supports_prompt_cache = True

    max_input_tokens = 64_000
    default_max_tokens = 2_048
