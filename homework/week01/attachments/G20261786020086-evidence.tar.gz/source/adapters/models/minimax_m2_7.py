"""MiniMax M2.7 模型的适配器（走 OpenAI Chat Completions 协议）。

在整体架构中的位置：这是「模型层」的一个具体实现，只做两件事：
声明模型身份与能力，以及指定用哪个 Provider 来翻译协议。
它不含任何 HTTP 细节，那些都在 OpenAIChatCompletionsProvider 里。

对应的 Java 概念：整个文件相当于一个只有几个字段的 Java 配置类/常量持有者，
继承自 ModelAdapter 相当于 extends ModelAdapter（这里用的是组合 Provider 而非继承）。
"""

from __future__ import annotations

from adapters.base import ModelAdapter
from providers.openai_chat_completions import OpenAIChatCompletionsProvider


class MiniMaxM27Adapter(ModelAdapter):
    """MiniMax M2.7 —— OpenAI Chat Completions 协议（真实厂商端点）。

    关键约束（都由真机探测确定，见 DESIGN §4.5.2）：
    - **结构化输出走 `prompt_only`**：上游接受 `response_format` 但**不执行**，
      声明 `native` 等于向调用方承诺一个上游没兑现的硬约束。真正的保证来自
      网关本地 schema 校验 + 内容层重试。
    - **支持提示词缓存**：上游隐式缓存前缀，用量里会单列 `cached_tokens`。
    - 上下文 196608 token、默认输出 8192 token（网关策略，调用方不可调）。
    """

    alias = "minimax-m2.7"
    provider_class = OpenAIChatCompletionsProvider
    upstream_id = "MiniMax-M2.7"

    structured_output_mode = "prompt_only"
    supports_prompt_cache = True

    max_input_tokens = 196_608
    default_max_tokens = 8_192
