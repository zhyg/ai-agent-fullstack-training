# LLMGateway

统一模型调用网关：**一套网关自有的、厂商中立的契约**，屏蔽不同厂商的**协议差异**
（Responses API / Messages API）和**模型差异**（DeepSeek V4 pro / V4 flash）。

调用方只指定 `model`，其余语义由网关保证；同一份请求在不同模型上行为一致，
做不到的组合**显式拒绝**（400），绝不静默降级。

- 设计文档：[DESIGN.md](DESIGN.md)
- 运行：`uvicorn main:app --reload`
- 测试：`python -m pytest -q`

---

## 一、给 Java 开发者的 Python 速查

本项目所有源文件都写了中文注释，且每个模块的文档字符串里都有「对应的 Java 概念」一节。
下面这张表是全局速查，模块内的对照会更具体。

### 1.1 语法与类型

| Python | Java | 备注 |
|---|---|---|
| `X \| None` | `Optional<X>` | `None` ≈ `null` |
| `str \| None = None` | `String x = null` | 声明 + 默认值 |
| `list[str]` / `dict[str, X]` | `List<String>` / `Map<String, X>` | |
| `tuple[str, int]` | `record Pair(String s, int i)` | 不可变 |
| `class Foo(BaseModel)` | 带校验的 POJO / record | pydantic **自动**做运行时校验与 JSON 序列化 |
| `@dataclass` | Lombok `@Data` / record | 自动生成构造器、`__eq__`、`__repr__` |
| `class Foo(Bar): ...` | `class Foo extends Bar` | Python 支持多继承，但本项目刻意不用 |
| `str, Enum` | `enum` | `ErrorCode.INVALID_JSON` |
| `def f(x: int) -> str:` | `String f(int x)` | |
| `-> None` | `void` | |

### 1.2 装饰器（本项目用到的几个）

| Python | Java |
|---|---|
| `@router.post("/v1/chat/completions")` | Spring MVC 的 `@RestController` + `@PostMapping` |
| `@router.get("/healthz")` | `@GetMapping` |
| `@app.exception_handler(GatewayError)` | `@ExceptionHandler(GatewayError.class)` |
| `@asynccontextmanager` | try-with-resources 的异步版 |
| `@pytest.mark.anyio` | JUnit 的 `@Test` + 异步支持 |

### 1.3 异步（最容易踩坑的地方）

```python
async def chat(req) -> Response:
    raw = await client.post_json(...)   # 挂起当前协程，把线程让给事件循环
```

- `async def` ≈ **协程**，跑在**单线程**事件循环上，**不是** `CompletableFuture`，
  也不占线程。**不要**在里面写阻塞代码（`requests.get(...)`），否则整个网关会卡死。
- `await` ≈ 挂起并让出线程，不是 `Future.get()`。
- `AsyncIterator` + `yield` ≈ 响应式流（Java 里接近 `SseEmitter` / `Flux`）。
- `asyncio.sleep(d)` ≈ 不阻塞线程的 `Thread.sleep(d)`。

### 1.4 常用容器与惯用法

| Python | Java |
|---|---|
| `dict.get(k, default)` | `Map.getOrDefault(k, default)` |
| `dict.setdefault(k, v)` | `map.computeIfAbsent(k, x -> v)` |
| `collections.defaultdict(int)` | `merge` 语义的 Map |
| `deque(maxlen=100)` | 环形缓冲区 / `LinkedBlockingQueue(100)` |
| `threading.Lock()` + `with lock:` | `synchronized` |
| `sorted(x)` | `Collections.sort` / `Stream.sorted` |
| `f"{name!r}"` / `f"{x}"` | `String.format` |
| `raise X from exc` | 包装异常并保留 cause |
| `assert x is not None` | `Objects.requireNonNull(x)` |

---

## 二、架构分层

```
HTTP 请求
   │
   ▼
api/routes.py          路由层：解析请求 → 调编排层 → 输出网关自有契约的 JSON / SSE
   │
   ▼
resilience/pipeline.py 编排层：限流 → 重试 → 计量 → 记录（不感知协议、不感知模型）
   │
   ▼
adapters/             模型层：这个模型是什么、能干什么（组合持有 Provider）
   │
   ▼
providers/            协议层：URL/鉴权/请求体怎么拼、响应怎么读
   │
   ▼
upstream/client.py    传输层：只管发 HTTP、切 SSE 帧、映射状态码
```

**两层抽象是关键**：

- **Provider（协议层）**：只懂协议。`OpenAIResponsesProvider` 走 Responses API，
  `AnthropicMessagesProvider` 走 Messages API。它**不认识**"模型"这个概念。
- **Adapter（模型层）**：只懂模型。`DeepSeekV4ProAdapter` 声明自己用什么协议、
  支不支持结构化输出、最大输入多少 token。它**不认识**具体协议细节。

两者是**组合**（Adapter 里 `self.provider = self.provider_class()`）而不是继承。
`ProtocolContext` 是两者之间的窄接口，Provider 只从里面拿协议需要的信息。

### 核心数据结构

| 类 | 文件 | 作用 |
|---|---|---|
| `LLMRequest` / `UnifiedResponse` / `UnifiedMessage` | `core/types.py` | 统一请求/响应模型，**同时就是对外的 HTTP 契约** |
| `OutputSchemaSpec` | `core/types.py` | 结构化输出契约（`schema` 必填，未知字段 400） |
| `ProtocolContext` | `core/types.py` | Adapter → Provider 的窄接口（协议上下文） |
| `GatewayError` + `ErrorCode` | `core/errors.py` | 统一错误码包装 |
| `PreparedCall` | `adapters/base.py` | 一次上游调用的准备结果（body + ctx） |

### 对外契约的四条硬性保证

1. **未知字段一律 400**（`GW_INVALID_REQUEST`），不做静默忽略。
2. **`output_schema` 存在 ⇒ 200 响应的内容已通过网关本地 schema 校验**
   （只覆盖非流式：`stream` 与 `output_schema` 互斥，同时出现直接 400）。
3. **响应里的 `id` 是网关 request id、`model` 是网关别名**——不泄漏上游厂商 id / 模型名。
4. **同一请求在不同模型上行为一致**；做不到的组合显式拒绝
   （`GW_CAPABILITY_UNSUPPORTED`），绝不静默降级。

> 注意第 2 条的来源：保证来自**网关本地的 jsonschema 校验**，不是上游。
> `native`（上游原生 json_schema）只是多一层上游拦截，`tool_use` 对模型只是建议。

---

## 三、建议阅读顺序（约 10 分钟）

1. **`main.py`** — 装配入口。看 `create_app()` 怎么把所有组件组装起来，
   `app.state.gateway` 相当于挂在 ApplicationContext 上的单例。
2. **`api/routes.py`** — 路由层。FastAPI 怎么把 pydantic 模型当请求体，
   怎么把 `AsyncIterator` 变成 SSE。
3. **`core/types.py`** — 统一模型定义。所有层的公共词汇表。
4. **`resilience/pipeline.py`** — 编排层。**最核心的一个文件**：
   非流式 `chat()` 和流式 `start_stream()` 两条路径、两级重试、首字节边界。
5. **`adapters/base.py`** — 模型层基类。理解 `structured_mode()` 如何
   在 `native` / `tool_use` / `prompt_only` 之间选择。
6. **`adapters/models/deepseek_v4_pro.py`** / `deepseek_v4_flash.py` /
   `minimax_m2_7.py` — 三个具体模型。
   对比着看，能立刻体会"换模型只改这几行"的收益。
7. **`providers/openai_responses.py`** / `providers/anthropic_messages.py` /
   `providers/openai_chat_completions.py` — 三种协议。
8. **`upstream/client.py`** — 传输层与状态码 → 错误码的映射表。
9. 其余（`core/config.py`、`core/structured.py`、`resilience/ratelimit.py`、
   `resilience/retry.py`、`resilience/token_counter.py`、`observability/*`、
   `prompts/*`）按需查阅，每个文件头部都有一句话说明它负责什么。

---

## 四、跑起来看看

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

### PowerShell（Windows）

⚠️ **坑**：PowerShell 里的 `curl` 是 `Invoke-WebRequest` 的**别名**，不支持 `-H` / `-d`。
要用真正的 curl 必须写全 `curl.exe`。

而且 PowerShell 5.1 在把参数交给原生程序时会把 `"` 吃掉，所以 JSON 里的双引号
要写成 `\"`（在单引号字符串里）。

```powershell
# 非流式
curl.exe -s localhost:8000/v1/chat/completions -H "Content-Type: application/json" -d '{\"model\":\"deepseek-v4-pro\",\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}]}'

# 流式（-N = 不缓冲，逐块显示）
curl.exe -sN localhost:8000/v1/chat/completions -H "Content-Type: application/json" -d '{\"model\":\"deepseek-v4-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}],\"stream\":true}'

# 结构化输出（保证返回的内容符合 schema）
curl.exe -s localhost:8000/v1/chat/completions -H "Content-Type: application/json" -d '{\"model\":\"deepseek-v4-pro\",\"messages\":[{\"role\":\"user\",\"content\":\"北京天气\"}],\"output_schema\":{\"name\":\"weather\",\"schema\":{\"type\":\"object\",\"properties\":{\"city\":{\"type\":\"string\"}},\"required\":[\"city\"]}}}'

# 未知字段会被拒绝（这是故意的：不做静默忽略）
curl.exe -s localhost:8000/v1/chat/completions -H "Content-Type: application/json" -d '{\"model\":\"deepseek-v4-pro\",\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}],\"tools\":[]}'

# 运维接口
curl.exe -s localhost:8000/v1/models
curl.exe -s localhost:8000/v1/metrics
curl.exe -s localhost:8000/v1/requests
```

不想跟转义较劲，用 PowerShell 原生写法（自动处理 JSON）：

```powershell
$body = @{
  model    = 'deepseek-v4-pro'
  messages = @(@{ role = 'user'; content = '你好' })
} | ConvertTo-Json -Depth 5

$r = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/v1/chat/completions' `
                       -Method Post -ContentType 'application/json' -Body $body
$r.content
$r.usage
```

### bash（Git Bash / WSL / Linux）

这里 JSON 用**单引号**包住即可（内部的双引号原样保留）：

```bash
# 非流式
curl -s localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","messages":[{"role":"user","content":"你好"}]}'

# 流式
curl -N localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"你好"}],"stream":true}'

# 运维接口
curl -s localhost:8000/v1/models
curl -s localhost:8000/v1/metrics
curl -s localhost:8000/v1/requests
```

> 如果 bash 里报 `Expecting property name enclosed in double quotes`，说明双引号被
> 某个 shell 层吃掉了。改用「写文件再 `@file` 传参」最稳：
> `curl -s ... -d @body.json`

### 接入真实模型（MiniMax M2.7）

`minimax-m2.7` 是**第一个指向真实厂商端点**的模型，走 MiniMax 国内站的
**OpenAI 兼容（Chat Completions）**协议。密钥**不进配置文件**——配置里只写
「去哪取」，有三种取法（见 DESIGN §7.9）：

**① `.env` 文件（最省事）**：在项目根目录放一个 `.env`（已进 `.gitignore`）：

```bash
MINIMAX_API_KEY=sk-...
```

网关启动时自动加载它，**只补不覆盖**（已有的环境变量优先，容器编排注入的值不会被改）。
模板见 `.env.example`。

**② 环境变量**：

```bash
export MINIMAX_API_KEY=sk-...        # Git Bash / WSL / Linux
```

```powershell
$env:MINIMAX_API_KEY = "sk-..."      # PowerShell（当前会话）
```

**③ 密钥文件**（与 Docker / K8s secret 挂载天然契合）：

```toml
api_key_file = "./secrets/minimax.key"   # 文件内容即密钥
```

优先级：**环境变量 → 密钥文件**（都没配 = 该上游不需要鉴权）。

`config.toml` 里的对应配置（密钥名 = 环境变量名）：

```toml
[env]
file = ".env"                          # 启动时自动加载的环境变量文件

[models."minimax-m2.7"]
base_url = "https://api.minimaxi.com"
upstream_id = "MiniMax-M2.7"
api_key_env = "MINIMAX_API_KEY"        # 或 api_key_file = "./secrets/minimax.key"
enabled = true

[models."minimax-m2.7".rate_limit]
rpm = 60
tpm = 60000

[models."minimax-m2.7".extra_body]
reasoning_split = true               # 让上游把思维链从正文里拆出来
```

然后照常调网关（对外契约**完全不变**，只是 `model` 换成 `minimax-m2.7`）：

```bash
curl -s localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"minimax-m2.7","messages":[{"role":"user","content":"用一句话介绍你自己"}]}'
```

三点说明：

- **结构化输出走 `prompt_only`**：实测 MiniMax 接受 `response_format`（HTTP 200）
  但**不执行**——输出仍是散文。所以网关把 schema 写进提示词，靠**本地 jsonschema
  校验 + 内容层重试**兜底。「返回内容符合 schema」的保证照样成立（见 DESIGN §5.2.3）。
- **该模型未定价**：`cost_usd` 恒为 `null`（未定价 ≠ 免费）。要计价就补一段
  `[models."minimax-m2.7".pricing]`。
- **缺密钥 = 启动就失败**：模型配了 `api_key_env` / `api_key_file` 却读不到密钥，
  网关**起不来**，报错会点名是哪个模型的哪个变量/文件——不会等到调用时才发现，
  更不会变成一个含义模糊的 502（见 DESIGN §7.9.3）。只想先跑 mock 的话，
  把该模型 `enabled = false`。

### 提示词模板存在哪

`storage/prompts.json`——**进版本管理**，团队共享（`.gitignore` 只忽略同目录下的
调用记录 `requests.jsonl`）。通过 `/v1/prompts` 接口创建或修改模板后，
直接 `git add storage/prompts.json` 提交即可同步给同事。

### 前端工作台（可观测面板 + 试调用）

服务起好后，浏览器直接打开：

```
http://127.0.0.1:8000/console/
```

访问根路径 `http://127.0.0.1:8000/` 也会自动跳过去。

| 页签 | 数据来源 |
|---|---|
| **总览** | `GET /v1/metrics` —— KPI 卡片 + 图表 + 按模型 / 按调用方的明细表 |
| **调用记录** | `GET /v1/requests` —— 筛选、列表，点任意一行看这次调用的完整轨迹（每次尝试、token、错误） |
| **模型** | `GET /v1/models` —— 各模型的能力声明 |
| **提示词** | `GET /v1/prompts` —— 模板与版本历史（**只读**，站点级模板，非租户私有） |
| **试调用** | `POST /v1/chat/completions` —— 手工发一次请求，看**契约本身**的响应：流式逐帧、错误信封原文、耗时与 request id |

几点说明：

- **前四个页签只读**：不新增任何接口、不改配置，也不提供提示词的新建 / 回滚。
- **「试调用」是唯一有副作用的页签**：每点一次「发送」都是一次**真实调用**——烧额度、
  占配额、并在「调用记录」页留下一条记录。它**不会自动发送**，页面上也常驻这条提示。
  它的价值是把**记录页看不到的东西**变可见：入口级 400（未知字段、`stream` 与
  `output_schema` 互斥）根本不产生调用记录，SSE 帧的形状也只在传输层存在。
- **右上角填 API Key**（存浏览器 `localStorage`）。没开鉴权（`auth.enabled = false`）时
  不填也能看数据；开了鉴权时填网关的 key。**密钥落在浏览器里**，所以页面对后端返回的
  所有文本一律走 `textContent` 渲染，不做任何 HTML 字符串注入（这条有 CI 断言守着）。
- **同源直连**：工作台由网关自己托管，所以不需要 CORS，也不用单独起前端服务。
- **数据范围由后端决定**：普通租户只看得到自己的记录与指标，管理员看全量。

技术上是**无构建的纯静态页面**（HTML + CSS + 原生 ES module，代码在 `web/` 目录），
改完保存刷新即可；图表用 ECharts 的 CDN，断网时自动降级成纯表格。

### 契约长什么样

请求（`POST /v1/chat/completions`）：

```json
{
  "model": "deepseek-v4-pro",
  "messages": [{"role": "user", "content": "你好"}],
  "output_schema": {
    "name": "weather",
    "schema": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]},
    "strict": true
  },
  "stream": false,
  "metadata": {"trace_id": "t-1"}
}
```

> **采样旋钮与输出上限不在契约里**：`temperature` / `top_p` / `stop` / `seed` / `n` /
> `max_output_tokens` 一律按未知字段处理（400）。输出上限是网关按模型能力决定的策略，
> 需要知道当前模型上限的调用方查 `GET /v1/models` 的 `capabilities.max_output_tokens`
> （**可查、不可调**）。
>
> **消息有长度上限**：单条 `messages[].content` 最长 20000 字符，`role` 只接受
> `system` / `user` / `assistant`。超长或非法 role 在入口就 400，不消耗配额、
> 不发上游请求。
>
> **入参约束一览**（违反即 400 `GW_INVALID_REQUEST`，在解析阶段就拒）：

| 字段 | 约束 |
|---|---|
| `model` | 1–128 字符，`^[A-Za-z0-9._-]+$`（格式非法 400；格式合法但未注册 404） |
| `messages` | ≥1 条、≤100 条；所有 `content` 合计 ≤100000 字符 |
| `messages[].content` | ≤20000 字符 |
| `output_schema.name` | 1–64 字符 |
| `output_schema.schema` | 序列化后 ≤20000 字符、嵌套 ≤10 层 |
| `prompt.name` / `prompt.version` | 1–128 字符 / ≥1 |
| `prompt.vars` | ≤50 项，值必须是标量，字符串值 ≤2000 字符 |
| `metadata` | ≤32 项，键 1–64 字符，**值必须是字符串**且 ≤512 字符 |
| `stream` + `output_schema` | **互斥**，同时出现 → 400（流式下无法保证内容符合 schema） |

响应：

```json
{
  "id": "lgw-1a2b3c...",
  "model": "deepseek-v4-pro",
  "content": "...",
  "reasoning_content": null,
  "finish_reason": "stop",
  "usage": {"input_tokens": 17, "output_tokens": 6, "reasoning_tokens": 5,
            "cache_read_tokens": 0, "cache_write_tokens": 0, "total_tokens": 23},
  "latency_ms": 12.3,
  "ttft_ms": null,
  "created": 1794118851
}
```

流式（SSE，**没有** `[DONE]` 哨兵，`type == "done"` 的事件就是终止符）：

```
data: {"type":"reasoning_delta","text":"思考"}
data: {"type":"text_delta","text":"你"}
data: {"type":"usage","usage":{"input_tokens":17,"output_tokens":6,"total_tokens":23}}
data: {"type":"done","finish_reason":"stop"}
```

错误（所有契约违规都是这个形状，状态码一律 400 而不是 422）：

```json
{"error": {"code": "GW_INVALID_REQUEST", "message": "...", "type": "invalid_request",
           "request_id": "lgw-...", "retriable": false}}
```

项目自带 **Mock 上游**（`upstream/mock_server.py`），不需要真实厂商账号就能跑通整条链路。

---

## 五、测试

```bash
python -m pytest -q
```

206 个用例覆盖 DESIGN.md §11 的场景：路由、鉴权、流式、结构化输出、
提示词版本、可观测性、重试与限流，以及契约层的四条硬性保证
（未知字段 400、响应 id/model 中立化、输出上限一致、能力不足显式拒绝）。

测试用 `pytest.mark.anyio`（**不是** `pytest-asyncio`，项目没装那个），
并发 fixture 在 `tests/conftest.py` 里，其中 `StreamingASGITransport` 是自写的
真·分块 ASGI 传输（httpx 自带的 `ASGITransport` 会把整个 body 缓冲成一坨，
测不了 SSE 的增量性）。

---

## 六、本地开发环境（MCP）

仓库里的 `.mcp.json` 声明了 PyCharm 自带的 MCP server，但**不写死端口**——
端口由本机 PyCharm 决定，换台机器可能是别的值，提交上去别人就连不上：

```json
{"mcpServers": {"pycharm": {"type": "http", "url": "http://127.0.0.1:${PYCHARM_MCP_PORT}/stream"}}}
```

用之前把端口设成环境变量（端口在 PyCharm 的 MCP server 设置里能看到）：

```bash
# Git Bash / WSL / Linux
export PYCHARM_MCP_PORT=64462
```

```powershell
# Windows：写进用户环境变量，之后新开的终端生效
setx PYCHARM_MCP_PORT 64462
```

也可以写进 `.claude/settings.local.json`（该目录不入库，只对本机生效）：

```json
{"env": {"PYCHARM_MCP_PORT": "64462"}}
```

变量没设的话，`${PYCHARM_MCP_PORT}` 会原样留在 URL 里，MCP server 连不上——
不会静默连到别的端口。
