"""用例 10、14、15、17：重试、限流、错误映射、时间预算。"""

from __future__ import annotations

import time

import pytest

from core.config import RetryConfig
from resilience.retry import RetryPolicy

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"


def _payload(**extra):
    return {"model": PRO, "messages": [{"role": "user", "content": "你好"}], **extra}


async def test_case10_server_error_is_retried_until_success(harness):
    await harness.control(fail="500", fail_times=2)
    response = await harness.chat(_payload())

    assert response.status_code == 200
    assert await harness.upstream_calls() == 3
    records = await harness.records()
    assert records[0]["status"] == "success"
    assert records[0]["attempt_count"] == 3
    assert records[0]["retry_count"] == 2


async def test_case10_client_error_is_not_retried(harness):
    """上游 4xx 不重试，且改道成 502 GW_UPSTREAM_REJECTED（v2.10）。

    调用方的请求已经过了网关自己的契约校验，是上游拒收了网关转发出去的东西，
    所以不能回 400 `GW_INVALID_REQUEST`——那会让调用方去查自己那份合法的请求体。
    """
    await harness.control(fail="400")
    response = await harness.chat(_payload())

    assert response.status_code == 502
    error = response.json()["error"]
    assert error["code"] == "GW_UPSTREAM_REJECTED"
    assert error["type"] == "upstream"
    assert error["retriable"] is False
    assert await harness.upstream_calls() == 1


async def test_case10_malformed_upstream_is_retried(harness):
    await harness.control(fail="malformed", fail_times=1)
    response = await harness.chat(_payload())

    assert response.status_code == 200
    assert await harness.upstream_calls() == 2
    attempts = (await harness.records())[0]["attempts"]
    assert attempts[0]["ok"] is False
    assert attempts[0]["error_code"] == "GW_MALFORMED_UPSTREAM"


async def test_case10_retries_are_exhausted(harness):
    await harness.control(fail="500")
    response = await harness.chat(_payload())

    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_UPSTREAM_ERROR"
    assert await harness.upstream_calls() == 3
    records = await harness.records()
    assert records[0]["attempt_count"] == 3
    assert records[0]["retry_count"] == 2


def test_case10_backoff_is_bounded_and_jittered():
    policy = RetryPolicy(RetryConfig(base_delay=0.5, max_delay=8.0, jitter="full"))
    for attempt in range(1, 5):
        ceiling = min(0.5 * (2 ** (attempt - 1)), 8.0)
        for _ in range(50):
            delay = policy.delay_for(attempt)
            assert 0.0 <= delay <= ceiling


def test_case10_retry_after_is_honoured():
    policy = RetryPolicy(RetryConfig(base_delay=0.5, max_delay=8.0))
    assert policy.delay_for(1, retry_after=2.5) == 2.5


async def test_case14_rpm_limit_returns_429(make_harness):
    built = await make_harness(rpm=1)
    first = await built.chat(_payload())
    assert first.status_code == 200

    second = await built.chat(_payload())
    assert second.status_code == 429
    assert second.json()["error"]["code"] == "GW_RATE_LIMITED"
    assert await built.upstream_calls() == 1, "被限流的请求不应触达上游"

    metrics = await built.metrics()
    assert metrics["overall"]["rate_limit_rejected"] == 1


async def test_case14_tpm_limit_returns_429(make_harness):
    built = await make_harness(tpm=5)
    response = await built.chat(_payload())

    assert response.status_code == 429
    assert response.json()["error"]["code"] == "GW_RATE_LIMITED"
    assert await built.upstream_calls() == 0


async def test_case14_retries_consume_the_bucket_each_time(make_harness):
    built = await make_harness(rpm=3)
    await built.control(fail="500", fail_times=2)
    first = await built.chat(_payload())
    assert first.status_code == 200
    assert await built.upstream_calls() == 3

    second = await built.chat(_payload())
    assert second.status_code == 429
    assert await built.upstream_calls() == 3, "重试已耗尽额度，后续请求不应触达上游"


async def test_case15_auth_error_is_mapped(harness):
    await harness.control(fail="401")
    response = await harness.chat(_payload())

    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_AUTH_ERROR"
    assert await harness.upstream_calls() == 1


async def test_case15_timeout_is_mapped(make_harness):
    built = await make_harness(attempt=0.3)
    await built.control(delay=2.0)
    response = await built.chat(_payload())

    assert response.status_code == 504
    assert response.json()["error"]["code"] == "GW_UPSTREAM_TIMEOUT"


async def test_case17_non_streaming_respects_deadline(make_harness):
    built = await make_harness(deadline=1.0, attempt=0.3, base_delay=0.05)
    await built.control(delay=2.0)

    started = time.perf_counter()
    response = await built.chat(_payload())
    elapsed = time.perf_counter() - started

    assert response.status_code == 504
    budget = built.settings.timeout.deadline + built.settings.timeout.attempt
    assert elapsed <= budget + 0.5, f"超出时间预算：{elapsed:.2f}s > {budget:.2f}s"
