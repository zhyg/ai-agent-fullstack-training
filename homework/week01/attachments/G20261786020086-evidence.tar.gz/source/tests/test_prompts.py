"""用例 7：提示词模板的变量替换、版本引用与回滚。"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"


async def _create(client, name: str, content: str, variables: list[str]):
    return await client.post(
        "/v1/prompts",
        json={"name": name, "content": content, "variables": variables},
    )


def _payload(prompt: dict):
    return {
        "model": PRO,
        "messages": [{"role": "user", "content": "原始问题"}],
        "prompt": prompt,
    }


async def test_case7_variable_substitution(harness):
    await _create(
        harness.client, "greet", "请用一句话回答关于 {{topic}} 的问题", ["topic"]
    )
    response = await harness.chat(
        _payload({"name": "greet", "vars": {"topic": "天气"}})
    )
    assert response.status_code == 200

    body = (await harness.mock_state())["last_request"]["body"]
    system = body["input"][0]
    assert system["role"] == "system"
    assert system["content"][0]["text"] == "请用一句话回答关于 天气 的问题"

    records = await harness.records()
    assert records[0]["prompt_template"] == "greet"
    assert records[0]["prompt_version"] == 1
    assert records[0]["rendered_prompt"] == "请用一句话回答关于 天气 的问题"


async def test_case7_default_value_is_used(harness):
    await _create(
        harness.client, "greet2", "请用一句话回答关于 {{topic|天气}} 的问题", ["topic"]
    )
    response = await harness.chat(_payload({"name": "greet2"}))
    assert response.status_code == 200

    body = (await harness.mock_state())["last_request"]["body"]
    assert body["input"][0]["content"][0]["text"] == "请用一句话回答关于 天气 的问题"


async def test_case7_missing_variable_is_rejected(harness):
    await _create(harness.client, "greet3", "关于 {{topic}} 的问题", ["topic"])
    response = await harness.chat(_payload({"name": "greet3"}))
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_TEMPLATE_VAR_MISSING"


async def test_case7_undeclared_placeholder_is_rejected(harness):
    await _create(harness.client, "greet4", "关于 {{topic}} 的问题", [])
    response = await harness.chat(_payload({"name": "greet4"}))
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_TEMPLATE_VAR_UNDECLARED"


async def test_case7_unused_variable_is_rejected(harness):
    await _create(harness.client, "greet5", "没有变量", ["topic"])
    response = await harness.chat(_payload({"name": "greet5"}))
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_TEMPLATE_VAR_UNUSED"


async def test_case7_missing_template_is_404(harness):
    response = await harness.chat(_payload({"name": "does-not-exist"}))
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "GW_TEMPLATE_NOT_FOUND"


async def test_case7_fixed_version_and_latest(harness):
    await _create(harness.client, "tpl", "第一版 {{topic}}", ["topic"])
    await harness.client.post(
        "/v1/prompts/tpl/versions",
        json={"content": "第二版 {{topic}}", "variables": ["topic"], "note": "v2"},
    )

    await harness.chat(_payload({"name": "tpl", "version": 1, "vars": {"topic": "X"}}))
    body = (await harness.mock_state())["last_request"]["body"]
    assert body["input"][0]["content"][0]["text"] == "第一版 X"

    await harness.chat(_payload({"name": "tpl", "vars": {"topic": "X"}}))
    body = (await harness.mock_state())["last_request"]["body"]
    assert body["input"][0]["content"][0]["text"] == "第二版 X"


async def test_case7_rollback_switches_current_version(harness):
    await _create(harness.client, "tpl2", "第一版 {{topic}}", ["topic"])
    await harness.client.post(
        "/v1/prompts/tpl2/versions",
        json={"content": "第二版 {{topic}}", "variables": ["topic"]},
    )
    rollback = await harness.client.post(
        "/v1/prompts/tpl2/rollback", json={"version": 1}
    )
    assert rollback.status_code == 200
    assert rollback.json()["current_version"] == 1

    await harness.chat(_payload({"name": "tpl2", "vars": {"topic": "X"}}))
    body = (await harness.mock_state())["last_request"]["body"]
    assert body["input"][0]["content"][0]["text"] == "第一版 X"


async def test_case7_prompt_listing_and_get(harness):
    await _create(harness.client, "tpl3", "内容", [])
    listing = await harness.client.get("/v1/prompts")
    names = [item["name"] for item in listing.json()["data"]]
    assert "tpl3" in names

    detail = await harness.client.get("/v1/prompts/tpl3")
    assert detail.status_code == 200
    assert detail.json()["versions"][0]["content"] == "内容"


async def test_case7_rendered_prompt_over_length_limit_is_400(harness):
    """模板正文过长 → 渲染结果超单条上限 → 400，不是 500。

    模板正文是管理员配的，但渲染结果会拼上调用方传的变量，长度最终由入参决定，
    所以这条路径必须翻译成 400（见 DESIGN §8.1.1）。
    """
    await _create(harness.client, "long", "x" * 21000, [])
    response = await harness.chat(_payload({"name": "long"}))

    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"
    assert await harness.upstream_calls() == 0
