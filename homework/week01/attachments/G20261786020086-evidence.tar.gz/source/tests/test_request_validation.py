"""请求契约的入参校验（DESIGN §8.1.1 / v2.3）。

覆盖每一个**调用方可控**字段的长度、数量、取值域约束。
所有非法入参都必须在**解析阶段**被 400 掉：上游调用次数 = 0，
既不消耗限流配额，也不发上游连接。
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"


def _payload(**extra):
    return {"model": PRO, "messages": [{"role": "user", "content": "你好"}], **extra}


async def _assert_rejected(harness, payload):
    response = await harness.chat(payload)
    assert response.status_code == 400, f"应当被拒绝：{payload}"
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"
    assert await harness.upstream_calls() == 0, "非法入参不应触达上游"


# --- model ------------------------------------------------------------


async def test_model_must_not_be_empty(harness):
    """空串是「参数非法」（400），不是「模型不存在」（404）。"""
    await _assert_rejected(harness, _payload(model=""))


async def test_model_rejects_illegal_characters(harness):
    """模型别名只允许字母数字与 . _ -，其它字符 400。"""
    await _assert_rejected(harness, _payload(model="deepseek v4 pro"))


async def test_model_length_is_capped(harness):
    await _assert_rejected(harness, _payload(model="m" * 129))


async def test_unknown_but_wellformed_model_is_still_404(harness):
    """格式合法但没注册的模型 → 404（与「参数非法」区分开）。"""
    response = await harness.chat(_payload(model="deepseek-v9-ultra"))
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "GW_MODEL_NOT_FOUND"


# --- messages ---------------------------------------------------------


async def test_messages_must_not_be_empty(harness):
    await _assert_rejected(harness, _payload(messages=[]))


async def test_messages_count_is_capped(harness):
    messages = [{"role": "user", "content": "x"} for _ in range(101)]
    await _assert_rejected(harness, _payload(messages=messages))


async def test_messages_total_content_is_capped(harness):
    """单条都在 20000 以内，但合计超 100000 也要拒。"""
    messages = [{"role": "user", "content": "x" * 20000} for _ in range(6)]
    await _assert_rejected(harness, _payload(messages=messages))


# --- output_schema ----------------------------------------------------


async def test_output_schema_name_is_capped(harness):
    await _assert_rejected(
        harness,
        _payload(output_schema={"name": "n" * 65, "schema": {"type": "object"}}),
    )


async def test_output_schema_size_is_capped(harness):
    """schema 序列化后超过 20000 字符 → 400。"""
    schema = {
        "type": "object",
        "properties": {f"p{i}": {"type": "string", "description": "x" * 100} for i in range(200)},
    }
    await _assert_rejected(harness, _payload(output_schema={"name": "r", "schema": schema}))


async def test_output_schema_depth_is_capped(harness):
    """嵌套超过 10 层 → 400。"""
    node: dict = {"type": "string"}
    for _ in range(11):
        node = {"type": "object", "properties": {"child": node}}
    await _assert_rejected(harness, _payload(output_schema={"name": "r", "schema": node}))


# --- prompt -----------------------------------------------------------


async def test_prompt_version_must_be_positive(harness):
    await _assert_rejected(
        harness, _payload(prompt={"name": "tpl", "version": 0})
    )


async def test_prompt_name_must_not_be_empty(harness):
    await _assert_rejected(harness, _payload(prompt={"name": ""}))


async def test_prompt_vars_count_is_capped(harness):
    variables = {f"v{i}": "x" for i in range(51)}
    await _assert_rejected(harness, _payload(prompt={"name": "tpl", "vars": variables}))


async def test_prompt_vars_values_must_be_scalar(harness):
    await _assert_rejected(
        harness, _payload(prompt={"name": "tpl", "vars": {"v": {"nested": 1}}})
    )


async def test_prompt_vars_string_value_is_capped(harness):
    await _assert_rejected(
        harness, _payload(prompt={"name": "tpl", "vars": {"v": "x" * 2001}})
    )


# --- metadata ---------------------------------------------------------


async def test_metadata_values_must_be_strings(harness):
    """metadata 的值类型收紧为字符串：传数字 → 400。"""
    await _assert_rejected(harness, _payload(metadata={"count": 3}))


async def test_metadata_entry_count_is_capped(harness):
    metadata = {f"k{i}": "v" for i in range(33)}
    await _assert_rejected(harness, _payload(metadata=metadata))


async def test_metadata_value_length_is_capped(harness):
    await _assert_rejected(harness, _payload(metadata={"k": "v" * 513}))


async def test_metadata_is_still_recorded(harness):
    """收紧后正常路径仍然可用。"""
    response = await harness.chat(_payload(metadata={"trace_id": "t-1"}))
    assert response.status_code == 200
    records = await harness.records()
    assert records[0]["metadata"] == {"trace_id": "t-1"}


# --- stream 与 output_schema 互斥 ---------------------------------------


async def test_stream_and_output_schema_are_mutually_exclusive(harness):
    """`stream` 与 `output_schema` 同时出现 → 400，且不触达上游。

    流式下「保证内容符合 schema」做不到（字节已经发出，流尾校验只是事后追认），
    所以这个组合在入口就拒，而不是先发字节再补一个 error 帧（见 DESIGN §5.1）。
    """
    await _assert_rejected(
        harness,
        _payload(
            stream=True,
            output_schema={
                "name": "r",
                "schema": {"type": "object", "properties": {"city": {"type": "string"}}},
            },
        ),
    )


async def test_stream_without_output_schema_is_allowed(harness):
    """只有 stream、没有 output_schema → 正常走 SSE。"""
    response = await harness.chat(_payload(stream=True))
    assert response.status_code == 200
    assert await harness.upstream_calls() == 1
