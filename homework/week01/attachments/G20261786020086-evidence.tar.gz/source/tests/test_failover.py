"""用例 47-53：多上游 failover 与熔断（契约 v2.9）。"""

from __future__ import annotations

import asyncio

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"

# 两个端点的 upstream_id 不同 → 网关下发给上游的 body.model 不同，
# Mock 上游据此把两个端点区分开（fail_by_model 的键就是它）。
PRIMARY_ID = "mock-primary"
BACKUP_ID = "mock-backup"


def _upstreams() -> dict:
    return {
        PRO: [
            {
                "name": "primary",
                "base_url": "http://upstream.test/_mock/openai",
                "upstream_id": PRIMARY_ID,
            },
            {
                "name": "backup",
                "base_url": "http://upstream.test/_mock/openai",
                "upstream_id": BACKUP_ID,
            },
        ]
    }


def _payload(model: str = PRO, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


def _breaker(harness) -> dict:
    """取网关内部该模型的端点池（测试要观察熔断状态）。"""
    pool = harness.app.state.gateway.pools[PRO]
    return {name: pool._breakers[name] for name in ("primary", "backup")}


async def _calls(harness) -> dict:
    """Mock 上游按「协议:模型」统计的调用次数。"""
    state = await harness.mock_state()
    return state["calls"]


async def test_case47_failover_switches_endpoint_and_succeeds(make_harness):
    """主端点 500 → 同一次调用自动切到备端点并成功。"""
    harness = await make_harness(upstreams=_upstreams())
    await harness.control(fail_by_model={PRIMARY_ID: "500"})

    response = await harness.chat(_payload())
    assert response.status_code == 200

    records = await harness.records()
    assert records[0]["upstream_endpoint"] == "backup"
    assert records[0]["failover_count"] == 1
    assert records[0]["attempt_count"] == 2
    assert records[0]["attempts"][0]["upstream_endpoint"] == "primary"
    assert records[0]["attempts"][1]["upstream_endpoint"] == "backup"

    metrics = await harness.metrics()
    assert metrics["overall"]["failover_total"] == 1


async def test_case48_failed_endpoint_is_not_reused(make_harness):
    """两个端点都失败 → 每个端点只被打一次，错误沿用最后一次上游错误。"""
    harness = await make_harness(upstreams=_upstreams())
    await harness.control(fail_by_model={PRIMARY_ID: "500", BACKUP_ID: "500"})

    response = await harness.chat(_payload())
    assert response.status_code == 502

    body = response.json()["error"]
    # 沿用最后一次上游错误，而不是含糊的「不可用」。
    assert body["code"] == "GW_UPSTREAM_ERROR"
    assert body["upstream_status"] == 500

    calls = await _calls(harness)
    assert calls[f"openai:{PRIMARY_ID}"] == 1
    assert calls[f"openai:{BACKUP_ID}"] == 1


async def test_case49_circuit_breaker_isolates_endpoint(make_harness):
    """连续失败达到阈值 → 端点被断开，后续调用不再打它。"""
    harness = await make_harness(
        upstreams=_upstreams(),
        circuit_breaker={"enabled": True, "failure_threshold": 2, "cooldown": 60.0},
    )
    await harness.control(fail_by_model={PRIMARY_ID: "500", BACKUP_ID: "500"})

    for _ in range(2):
        response = await harness.chat(_payload())
        assert response.status_code == 502

    calls = await _calls(harness)
    assert calls[f"openai:{PRIMARY_ID}"] == 2
    assert calls[f"openai:{BACKUP_ID}"] == 2

    # 第三次调用：两个端点都已断开 → 503。
    response = await harness.chat(_payload())
    assert response.status_code == 503

    # 断开的端点不再被打：调用次数不增加。
    calls = await _calls(harness)
    assert calls[f"openai:{PRIMARY_ID}"] == 2
    assert calls[f"openai:{BACKUP_ID}"] == 2


async def test_case50_half_open_probe_recovers(make_harness):
    """冷却结束后放行一次试探；试探成功 → 恢复闭合。"""
    harness = await make_harness(
        upstreams=_upstreams(),
        circuit_breaker={"enabled": True, "failure_threshold": 1, "cooldown": 0.2},
    )
    # 主端点只在第一次调用时失败，之后恢复正常。
    await harness.control(fail_by_model={PRIMARY_ID: "500"}, fail_times=1)

    first = await harness.chat(_payload())
    assert first.status_code == 200
    records = await harness.records()
    assert records[0]["upstream_endpoint"] == "backup"
    assert records[0]["failover_count"] == 1

    breakers = _breaker(harness)
    assert breakers["primary"].state.value == "open"

    # 等冷却结束 → 半开，放行一次试探。
    await asyncio.sleep(0.3)

    second = await harness.chat(_payload())
    assert second.status_code == 200
    records = await harness.records()
    assert records[0]["upstream_endpoint"] == "primary"
    assert records[0]["failover_count"] == 0

    breakers = _breaker(harness)
    assert breakers["primary"].state.value == "closed"


async def test_case51_all_endpoints_unavailable(make_harness):
    """所有端点都在熔断中 → 503 GW_UPSTREAM_UNAVAILABLE，retriable == true。"""
    harness = await make_harness(
        upstreams=_upstreams(),
        circuit_breaker={"enabled": True, "failure_threshold": 1, "cooldown": 60.0},
    )
    await harness.control(fail_by_model={PRIMARY_ID: "500", BACKUP_ID: "500"})

    # 第一次调用把两个端点都打失败 → 两个端点都断开。
    first = await harness.chat(_payload())
    assert first.status_code == 502

    second = await harness.chat(_payload())
    assert second.status_code == 503
    body = second.json()["error"]
    assert body["code"] == "GW_UPSTREAM_UNAVAILABLE"
    assert body["type"] == "upstream"
    assert body["retriable"] is True


async def test_case52_content_error_does_not_trip_breaker(make_harness):
    """上游返回坏 JSON（内容层失败）→ 端点不被断开。"""
    harness = await make_harness(
        upstreams=_upstreams(),
        circuit_breaker={"enabled": True, "failure_threshold": 1, "cooldown": 60.0},
    )
    await harness.control(content="bad_json")

    response = await harness.chat(
        _payload(
            output_schema={
                "name": "answer",
                "schema": {"type": "object", "properties": {"ok": {"type": "boolean"}}},
            }
        )
    )
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_INVALID_JSON"

    breakers = _breaker(harness)
    assert breakers["primary"].state.value == "closed"
    assert breakers["backup"].state.value == "closed"


async def test_case53_single_endpoint_behaviour_unchanged(make_harness):
    """不配 upstreams 时行为与 v2.8 一致：同一个端点按原有重试逻辑重试。"""
    harness = await make_harness()
    await harness.control(fail_times=1, fail="500")

    response = await harness.chat(_payload())
    assert response.status_code == 200

    records = await harness.records()
    # 单端点模式：记录里没有端点信息，也没有 failover。
    assert records[0]["upstream_endpoint"] is None
    assert records[0]["failover_count"] == 0
    assert records[0]["attempt_count"] == 2

    metrics = await harness.metrics()
    assert metrics["overall"]["failover_total"] == 0


async def test_streaming_fails_over_before_first_byte(make_harness):
    """流式：首字节之前的失败可以换端点（见 DESIGN §7.8.6）。"""
    harness = await make_harness(upstreams=_upstreams())
    await harness.control(fail_by_model={PRIMARY_ID: "500"})

    text, _ = await harness.stream_chat(_payload(stream=True))
    payloads = harness.sse_payloads(text)
    assert any(item["type"] == "text_delta" for item in payloads)
    assert not any(item["type"] == "error" for item in payloads)

    records = await harness.records()
    assert records[0]["upstream_endpoint"] == "backup"
    assert records[0]["failover_count"] == 1
    assert records[0]["status"] == "success"


async def test_failover_does_not_expand_retry_budget(make_harness):
    """换端点消耗的是同一次尝试，不扩大 max_attempts（见 DESIGN §7.8.6）。"""
    harness = await make_harness(upstreams=_upstreams(), max_attempts=1)
    await harness.control(fail_by_model={PRIMARY_ID: "500", BACKUP_ID: "500"})

    response = await harness.chat(_payload())
    assert response.status_code == 502

    calls = await _calls(harness)
    # 只有一个尝试预算 → 备端点这次调用用不上。
    assert calls[f"openai:{PRIMARY_ID}"] == 1
    assert f"openai:{BACKUP_ID}" not in calls
