"""用例 54-63：契约 v2.10 的 8 处修正（错误改道、流式结算、惩罚扣减、超时预算）。

这一组用例盯的是「网关内部行为与对外契约是否一致」，因此大量断言直接读内部状态
（限流桶余额、熔断状态、调用次数），而不是只看响应体。
"""

from __future__ import annotations

import asyncio
import sys
import threading
import time

import pytest

from core.config import RateLimitConfig
from core.errors import GatewayError
from resilience.ratelimit import RateLimiter

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
PRIMARY_ID = "mock-primary"
BACKUP_ID = "mock-backup"

# 桶的补充速率 = 容量 / 60（每秒）。断言余额时要给这个速率留出容差，
# 否则「测试跑了 0.1 秒」本身就会让桶多出十几个 token。
TOLERANCE = 50


def _upstreams() -> dict:
    return {
        PRO: [
            {
                "name": "primary",
                "base_url": "http://upstream.test/_mock/openai",
                "upstream_id": PRIMARY_ID,
            },
            {
                "name": "backup",
                "base_url": "http://upstream.test/_mock/openai",
                "upstream_id": BACKUP_ID,
            },
        ]
    }


def _payload(**extra):
    return {"model": PRO, "messages": [{"role": "user", "content": "你好"}], **extra}


def _breakers(harness) -> dict:
    pool = harness.app.state.gateway.pools[PRO]
    return {name: pool._breakers[name] for name in ("primary", "backup")}


async def _wait_for_record(harness, timeout: float = 3.0) -> dict:
    """等调用记录落库（客户端断开时，记录是在断开之后才写的）。"""
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        records = await harness.records()
        if records:
            return records[0]
        await asyncio.sleep(0.05)
    raise AssertionError("调用记录没有出现")


# --- 54：上游 4xx 改道 -----------------------------------------------


async def test_case54_upstream_4xx_is_rejected_not_invalid_request(make_harness):
    """上游 400 → 502 GW_UPSTREAM_REJECTED，不再复用 GW_INVALID_REQUEST。

    调用方的请求已经过了网关自己的契约校验，是上游拒收了网关转发出去的东西；
    回 400 会让调用方去查自己那份完全合法的请求体。
    """
    harness = await make_harness(upstreams=_upstreams())
    await harness.control(fail_by_model={PRIMARY_ID: "400"})

    response = await harness.chat(_payload())
    assert response.status_code == 502

    error = response.json()["error"]
    assert error["code"] == "GW_UPSTREAM_REJECTED"
    assert error["type"] == "upstream"
    assert error["retriable"] is False
    assert error["upstream_status"] == 400

    # 确定性拒绝不可重试，也不该换端点再试一次。
    assert await harness.upstream_calls() == 1

    # 端点的健康没问题，不该被熔断。
    breakers = _breakers(harness)
    assert breakers["primary"].state.value == "closed"
    assert breakers["backup"].state.value == "closed"


async def test_case54_upstream_auth_and_rate_limit_keep_their_codes(harness):
    """401/403 → GW_AUTH_ERROR，429 → GW_UPSTREAM_RATE_LIMITED（都不变）。"""
    await harness.control(fail="401")
    response = await harness.chat(_payload())
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_AUTH_ERROR"

    await harness.reset()
    await harness.control(fail="429")
    response = await harness.chat(_payload())
    assert response.status_code == 429
    assert response.json()["error"]["code"] == "GW_UPSTREAM_RATE_LIMITED"


# --- 55-57：流式结算 ---------------------------------------------------


async def test_case55_streaming_settles_by_actual_usage(make_harness):
    """流式跑完后按**实际用量**结算：退掉的是「预扣 − 实际」，不是整笔预扣。"""
    harness = await make_harness(tpm=8192)
    before = harness.tpm_remaining()
    reserved = harness.reserved_tokens(PRO, ["你好"])

    text, _ = await harness.stream_chat(_payload(stream=True))
    assert harness.stream_content(text)

    after = harness.tpm_remaining()
    records = await harness.records()
    actual = records[0]["usage"]["total_tokens"]

    # 桶里只剩「实际用量」那么多，而不是「预扣量」那么多。
    assert after == pytest.approx(before - actual, abs=TOLERANCE)
    assert after > before - reserved, "流式没有结算：多预扣的额度没有退回"


async def test_case56_streaming_settles_on_client_disconnect(make_harness):
    """客户端中途断开：按「输入估算 + 已产出文本估算」结算（比完全不结算多退）。"""
    harness = await make_harness(tpm=8192, disconnect_after=3)
    await harness.control(chunk_delay=0.05)
    before = harness.tpm_remaining()
    reserved = harness.reserved_tokens(PRO, ["你好"])

    await harness.stream_chat(_payload(stream=True))
    record = await _wait_for_record(harness)
    assert record["status"] == "cancelled"

    after = harness.tpm_remaining()
    # 结算发生了：退掉的不只是「实际用量」，而是「预扣 − 实际」这一大截。
    assert after > before - reserved / 2
    assert after <= before


async def test_case57_streaming_failure_before_first_event_keeps_reserved(make_harness):
    """上游在吐出第一个事件之前就失败 → 不结算，预扣保留。

    上游可能已经按这次请求计费了，网关无从得知，退款反而会超发。
    """
    harness = await make_harness(tpm=8192, max_attempts=1)
    await harness.control(fail="500")
    before = harness.tpm_remaining()
    reserved = harness.reserved_tokens(PRO, ["你好"])

    response = await harness.chat(_payload(stream=True))
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_UPSTREAM_ERROR"

    after = harness.tpm_remaining()
    assert after == pytest.approx(before - reserved, abs=TOLERANCE)


# --- 58：上游 429 惩罚扣减 ---------------------------------------------


async def test_case58_upstream_429_penalty_is_configurable(make_harness):
    """`penalize_on_upstream_429` 打开时，上游 429 会额外扣掉该次尝试的预扣量。"""
    penalized = await make_harness(
        tpm=20_000, max_attempts=1, penalize_on_upstream_429=True
    )
    plain = await make_harness(
        tpm=20_000, max_attempts=1, penalize_on_upstream_429=False
    )
    # mock 的故障开关是模块级共享的（两个 harness 共用同一个 mock 状态）。
    await penalized.control(fail="429")

    penalized_before = penalized.tpm_remaining()
    plain_before = plain.tpm_remaining()

    penalized_response = await penalized.chat(_payload())
    plain_response = await plain.chat(_payload())
    assert penalized_response.status_code == 429
    assert plain_response.status_code == 429

    reserved = penalized.reserved_tokens(PRO, ["你好"])
    consumed_penalized = penalized_before - penalized.tpm_remaining()
    consumed_plain = plain_before - plain.tpm_remaining()

    # 开启惩罚的这一次比不惩罚的多扣了整整一笔预扣量。
    assert consumed_penalized - consumed_plain == pytest.approx(
        reserved, abs=TOLERANCE
    )


# --- 59-61：超时预算 ---------------------------------------------------


async def test_case59_first_token_deadline_applies_before_stream_idle(make_harness):
    """上游连上但不吐事件 → 超过 first_token 即 GW_UPSTREAM_TIMEOUT。

    这个超时必须早于 `stream_idle` 生效，否则「上游连上了却一直不说话」要空等
    一整个 chunk 空闲超时才发现。
    """
    harness = await make_harness(first_token=0.2, stream_idle=5.0, max_attempts=1)
    await harness.control(delay=1.0)

    started = time.perf_counter()
    response = await harness.chat(_payload(stream=True))
    elapsed = time.perf_counter() - started

    assert response.status_code == 504
    assert response.json()["error"]["code"] == "GW_UPSTREAM_TIMEOUT"
    assert elapsed < 3.0, f"等到了 stream_idle 才报错：{elapsed:.2f}s"
    assert await harness.upstream_calls() == 1


async def test_case60_retry_budget_accounts_for_attempt_timeout(make_harness):
    """剩余预算不足以跑完一次尝试时不再重试（上游调用次数不增加）。"""
    harness = await make_harness(deadline=0.3, attempt=0.4, max_attempts=3)
    await harness.control(fail="500")

    response = await harness.chat(_payload())
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_UPSTREAM_ERROR"
    # 退避 + 下一次尝试本身（0.4s）已经塞不进剩余的 0.3s 预算 → 不再重试。
    assert await harness.upstream_calls() == 1


async def test_case61_streaming_is_not_cut_by_total_deadline(make_harness):
    """流式总耗时超过 deadline 仍能正常跑完（末事件仍是 done）。"""
    harness = await make_harness(deadline=0.2, first_token=5.0, stream_idle=5.0)
    await harness.control(chunk_delay=0.1)

    started = time.perf_counter()
    text, _ = await harness.stream_chat(_payload(stream=True))
    elapsed = time.perf_counter() - started

    payloads = harness.sse_payloads(text)
    assert payloads[-1]["type"] == "done"
    assert elapsed > 0.2, "流应该比 deadline 长，否则这个用例没意义"

    record = await _wait_for_record(harness)
    assert record["status"] == "success"


async def test_case61_streaming_retry_is_not_cut_by_total_deadline(make_harness):
    """流式的**重试**也不受总 deadline 约束。

    每次尝试各自受 `first_token` 约束；总预算不该把重试一刀切掉——流式没有总
    deadline，长文本生成本来就可能跑很久。
    """
    harness = await make_harness(
        deadline=0.2, first_token=0.2, stream_idle=5.0, max_attempts=3
    )
    await harness.control(delay=1.0)

    response = await harness.chat(_payload(stream=True))
    assert response.status_code == 504
    assert response.json()["error"]["code"] == "GW_UPSTREAM_TIMEOUT"
    # 3 次尝试都跑完了（每次都卡在 first_token 上），没有被 deadline 提前掐断。
    assert await harness.upstream_calls() == 3


# --- 62：限流桶并发安全 -------------------------------------------------


def test_case62_rate_limiter_admits_exactly_the_quota():
    """多线程并发准入，放行次数恰好等于配额（不多放也不少放）。

    直接测限流器本身（不走 HTTP）：并发窗口在编排层里很难稳定复现。
    """
    quota = 10
    limiter = RateLimiter(lambda caller, model: RateLimitConfig(rpm=quota, tpm=1000))
    granted: list[int] = []
    lock = threading.Lock()
    barrier = threading.Barrier(50)

    def worker() -> None:
        barrier.wait()
        try:
            limiter.consume("tenant", PRO, 1)
        except GatewayError:
            return
        with lock:
            granted.append(1)

    # 把线程切换间隔压到最小，让「先查后扣」的竞态更容易出现。
    original = sys.getswitchinterval()
    sys.setswitchinterval(1e-6)
    try:
        threads = [threading.Thread(target=worker) for _ in range(50)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
    finally:
        sys.setswitchinterval(original)

    assert len(granted) == quota


# --- 63：429 带 Retry-After --------------------------------------------


async def test_case63_local_rate_limit_carries_retry_after(make_harness):
    """本地 429 的响应带 Retry-After 头（值 ≥ 1 秒）。"""
    harness = await make_harness(rpm=1)

    first = await harness.chat(_payload())
    assert first.status_code == 200

    second = await harness.chat(_payload())
    assert second.status_code == 429
    assert second.json()["error"]["code"] == "GW_RATE_LIMITED"
    assert int(second.headers["Retry-After"]) >= 1


async def test_case63_upstream_rate_limit_passes_retry_after_through(make_harness):
    """上游 429 带 Retry-After 时沿用上游的值。"""
    harness = await make_harness(max_attempts=1)
    await harness.control(fail="429")

    response = await harness.chat(_payload())
    assert response.status_code == 429
    assert response.json()["error"]["code"] == "GW_UPSTREAM_RATE_LIMITED"
    assert response.headers["Retry-After"] == "1"
