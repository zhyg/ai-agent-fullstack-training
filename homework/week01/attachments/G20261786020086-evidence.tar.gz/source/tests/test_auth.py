"""用例 29-32：入站站点鉴权（契约 v2.6）。"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
KEY = "sk-test-secret-a"
ENV = "LGW_KEY_TEAM_A"


def _payload(model: str = PRO, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


def _bearer(key: str = KEY) -> dict[str, str]:
    return {"Authorization": f"Bearer {key}"}


async def _authed_harness(monkeypatch, make_harness):
    monkeypatch.setenv(ENV, KEY)
    return await make_harness(
        auth_enabled=True,
        auth_keys=[{"name": "team-a", "key_env": ENV}],
        auth_headers={"Authorization": f"Bearer {KEY}"},
    )


async def test_case29_missing_api_key_is_rejected(monkeypatch, make_harness):
    """没带 Authorization → 401 + GW_UNAUTHORIZED + WWW-Authenticate。"""
    harness = await _authed_harness(monkeypatch, make_harness)
    harness.auth_headers = {}

    response = await harness.chat(_payload())

    assert response.status_code == 401
    body = response.json()
    assert body["error"]["code"] == "GW_UNAUTHORIZED"
    assert body["error"]["type"] == "authentication"
    assert body["error"]["retriable"] is False
    assert response.headers["www-authenticate"] == "Bearer"
    assert response.headers["x-request-id"] == body["error"]["request_id"]


async def test_case29_wrong_api_key_is_indistinguishable(monkeypatch, make_harness):
    """key 错了 → 401，且响应体与「没带 key」**完全一致**。

    不能给调用方一个「这个 key 存在但只是不对」的预言机。
    """
    harness = await _authed_harness(monkeypatch, make_harness)

    harness.auth_headers = {}
    missing = await harness.chat(_payload())
    wrong = await harness.chat(_payload(), headers=_bearer("sk-not-the-key"))

    assert wrong.status_code == 401
    assert wrong.json()["error"]["code"] == "GW_UNAUTHORIZED"
    assert wrong.json()["error"]["message"] == missing.json()["error"]["message"]


async def test_case29_valid_api_key_is_accepted(monkeypatch, make_harness):
    """带对 key → 正常调用。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    response = await harness.chat(_payload(), headers=_bearer())

    assert response.status_code == 200
    assert response.json()["model"] == PRO


async def test_case29_bearer_scheme_is_case_insensitive(monkeypatch, make_harness):
    """scheme 大小写不敏感（HTTP 规定如此）。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    response = await harness.chat(_payload(), headers={"Authorization": f"bearer {KEY}"})

    assert response.status_code == 200


async def test_case29_auth_is_off_by_default(harness):
    """默认不鉴权：不带 key 也能调通（未开启鉴权时配置里没有 [auth]）。"""
    response = await harness.chat(_payload())

    assert response.status_code == 200


@pytest.mark.parametrize(
    "method,path",
    [
        ("GET", "/v1/models"),
        ("GET", "/v1/metrics"),
        ("GET", "/v1/requests"),
        ("GET", "/v1/prompts"),
    ],
)
async def test_case30_ops_endpoints_are_protected(
    monkeypatch, make_harness, method, path
):
    """运维类端点同样要鉴权——它们暴露的是调用记录与指标。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    response = await harness.client.request(method, path)

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "GW_UNAUTHORIZED"


async def test_case30_healthz_is_public(monkeypatch, make_harness):
    """健康检查不鉴权：探针不该被迫持有密钥。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    response = await harness.client.get("/healthz")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"


async def test_case30_mock_upstream_is_public(monkeypatch, make_harness):
    """Mock 上游不鉴权：它是开发期设施，不是对外契约的一部分。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    response = await harness.mock_client.get("/_mock/_control")

    assert response.status_code == 200


async def test_case30_unauthenticated_request_leaves_no_trace(
    monkeypatch, make_harness
):
    """未鉴权的请求：不发上游、不产生调用记录（它根本没到模型调用这一步）。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    # 先摘掉凭证发出一个未鉴权的请求，再把凭证装回去查记录
    # （/v1/requests 本身也要鉴权）。
    credentials = harness.auth_headers
    harness.auth_headers = {}
    await harness.chat(_payload())
    harness.auth_headers = credentials

    assert await harness.upstream_calls() == 0
    assert await harness.records() == []


async def test_case31_api_key_never_leaks(monkeypatch, make_harness):
    """密钥不出现在响应体、响应头、调用记录里；记录里只有指纹。"""
    harness = await _authed_harness(monkeypatch, make_harness)

    response = await harness.chat(_payload(), headers=_bearer())

    assert KEY not in response.text
    assert KEY not in str(dict(response.headers))

    records = await harness.records()
    assert KEY not in str(records)


async def test_case32_enabled_without_keys_fails_fast(monkeypatch, make_harness):
    """开了鉴权却一把钥匙都没配 → 启动失败（不是运行期永远 401）。"""
    with pytest.raises(ValueError, match="no auth.keys"):
        await make_harness(auth_enabled=True)


async def test_case32_missing_env_var_fails_fast(monkeypatch, make_harness):
    """key_env 指向的环境变量不存在 → 启动失败。"""
    monkeypatch.delenv(ENV, raising=False)

    with pytest.raises(ValueError, match=ENV):
        await make_harness(
            auth_enabled=True,
            auth_keys=[{"name": "team-a", "key_env": ENV}],
        )
