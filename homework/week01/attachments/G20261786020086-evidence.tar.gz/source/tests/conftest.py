"""测试夹具。

要点：
1. httpx 自带的 ASGITransport 会把整个响应体缓冲成一个 chunk，无法验证流式增量，
   因此这里实现了 StreamingASGITransport：按 ASGI 消息逐块投递。
2. pytest-asyncio 未安装，用 anyio 官方 pytest 插件（@pytest.mark.anyio）。
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import httpx
import pytest
from fastapi import FastAPI

from core.config import Settings
from main import create_app
from upstream.mock_server import create_mock_router, reset_mock_state


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


class StreamingASGITransport(httpx.AsyncBaseTransport):
    """真正按块投递的 ASGI 传输。

    `disconnect_after` 用来模拟「客户端在流到一半时挂断」：
    收到第 N 个响应体分片后，传输层向应用投递 `http.disconnect`
    （≈ 真实服务器在 TCP 连接断开时做的事），并停止继续投递分片。
    `disconnect_after=0` 表示「请求刚发出去就挂断，连响应都没等到」。

    只对**第一个**请求生效：挂断之后测试还要继续查 `/v1/requests` 之类的接口，
    那些请求得正常完成。
    """

    def __init__(self, app: Any, *, disconnect_after: int | None = None) -> None:
        self.app = app
        self.disconnect_after = disconnect_after
        self._armed = disconnect_after is not None

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        disconnect_after = self.disconnect_after if self._armed else None
        self._armed = False
        body = await request.aread()
        timeout = request.extensions.get("timeout") or {}
        read_timeout = timeout.get("read")

        scope = {
            "type": "http",
            "asgi": {"version": "3.0", "spec_version": "2.3"},
            "http_version": "1.1",
            "method": request.method,
            "headers": [(k.lower(), v) for k, v in request.headers.raw],
            "scheme": request.url.scheme,
            "path": request.url.path,
            "raw_path": request.url.raw_path.split(b"?")[0],
            "query_string": request.url.query,
            "server": (request.url.host, request.url.port),
            "client": ("127.0.0.1", 50000),
            "root_path": "",
        }

        queue: asyncio.Queue = asyncio.Queue()
        body_sent = False
        # 客户端「走了」：要么响应正常发完，要么模拟的挂断发生。
        # ASGI 的 receive 阻塞在这个事件上，等到了就返回 http.disconnect。
        client_gone = asyncio.Event()
        sent_chunks = 0
        hung_up = False
        sentinel_sent = False

        async def receive() -> dict:
            # 第一次交付请求体，之后阻塞等待断开；不能立即返回，否则
            # Starlette 的 listen_for_disconnect 会变成死循环。
            nonlocal body_sent
            if not body_sent:
                body_sent = True
                if disconnect_after == 0:
                    # 客户端在响应开始之前就挂断了（发完请求体就跑）。
                    client_gone.set()
                return {"type": "http.request", "body": body, "more_body": False}
            await client_gone.wait()
            return {"type": "http.disconnect"}

        async def send(message: dict) -> None:
            nonlocal sent_chunks, hung_up, sentinel_sent
            if message["type"] != "http.response.body":
                await queue.put(message)
                return
            sent_chunks += 1
            if (
                not hung_up
                and disconnect_after is not None
                and sent_chunks >= disconnect_after
            ):
                hung_up = True
                client_gone.set()
                if disconnect_after == 0:
                    # 客户端在收到任何分片之前就挂断了：这一分片不投递。
                    sentinel_sent = True
                    await queue.put(("disconnect", None))
                    return
            await queue.put(message)
            if hung_up and not sentinel_sent:
                # 客户端在这一分片之后就挂断了：结束响应流。
                sentinel_sent = True
                await queue.put(("disconnect", None))

        async def run() -> None:
            try:
                await self.app(scope, receive, send)
            except BaseException as exc:  # noqa: BLE001 - 模拟真实连接的异常断开
                await queue.put(("error", exc))
            else:
                await queue.put(("eof", None))

        task = asyncio.create_task(run())

        async def pull() -> Any:
            if read_timeout is None:
                return await queue.get()
            try:
                return await asyncio.wait_for(queue.get(), read_timeout)
            except asyncio.TimeoutError as exc:
                raise httpx.ReadTimeout("upstream read timeout", request=request) from exc

        status = 500
        headers: list[tuple[bytes, bytes]] = []
        try:
            while True:
                message = await pull()
                if isinstance(message, tuple):
                    _, exc = message
                    raise httpx.RemoteProtocolError(
                        f"upstream connection closed abruptly: {exc}"
                    ) from exc
                if message["type"] == "http.response.start":
                    status = message["status"]
                    headers = list(message.get("headers") or [])
                    break
        except BaseException:
            task.cancel()
            raise

        async def iterate() -> Any:
            try:
                while True:
                    message = await pull()
                    if isinstance(message, tuple):
                        kind, exc = message
                        if kind == "disconnect":
                            # 模拟客户端挂断：响应体到此为止（不等收尾帧）。
                            return
                        raise httpx.RemoteProtocolError(
                            f"upstream connection closed abruptly: {exc}"
                        ) from exc
                    if message["type"] != "http.response.body":
                        continue
                    chunk = message.get("body") or b""
                    if chunk:
                        yield chunk
                    if not message.get("more_body", False):
                        return
            finally:
                client_gone.set()
                task.cancel()

        return httpx.Response(
            status_code=status,
            headers=headers,
            stream=_Stream(iterate()),
            extensions=request.extensions,
            request=request,
        )


class _Stream(httpx.AsyncByteStream):
    def __init__(self, agen: Any) -> None:
        self._agen = agen

    async def __aiter__(self) -> Any:
        async for chunk in self._agen:
            yield chunk

    async def aclose(self) -> None:
        await self._agen.aclose()


def make_settings(
    data_dir: Path,
    *,
    rpm: int = 600,
    tpm: int = 600_000,
    max_attempts: int = 3,
    deadline: float = 10.0,
    attempt: float = 2.0,
    first_token: float = 5.0,
    stream_idle: float = 5.0,
    base_delay: float = 0.01,
    penalize_on_upstream_429: bool = False,
    api_key_env: str | None = None,
    api_key_file: str | None = None,
    auth_enabled: bool = False,
    auth_keys: list[dict] | None = None,
    tenants: dict[str, Any] | None = None,
    pricing: dict[str, Any] | None = None,
    upstreams: dict[str, list[dict[str, Any]]] | None = None,
    circuit_breaker: dict[str, Any] | None = None,
) -> Settings:
    models: dict[str, Any] = {
        "deepseek-v4-pro": {
            "base_url": "http://upstream.test/_mock/openai",
            "upstream_id": "deepseek-v4-pro",
            "enabled": True,
            "rate_limit": {"rpm": rpm, "tpm": tpm},
        },
        "deepseek-v4-flash": {
            "base_url": "http://upstream.test/_mock/anthropic",
            "upstream_id": "deepseek-v4-flash",
            "enabled": True,
            "rate_limit": {"rpm": rpm, "tpm": tpm},
        },
        "minimax-m2.7": {
            "base_url": "http://upstream.test/_mock/openai-chat",
            "upstream_id": "MiniMax-M2.7",
            "enabled": True,
            "rate_limit": {"rpm": rpm, "tpm": tpm},
        },
    }
    if api_key_env:
        for cfg in models.values():
            cfg["api_key_env"] = api_key_env
    if api_key_file:
        for cfg in models.values():
            cfg["api_key_file"] = api_key_file
    for alias, prices in (pricing or {}).items():
        models[alias]["pricing"] = prices
    for alias, endpoints in (upstreams or {}).items():
        models[alias]["upstreams"] = endpoints
    return Settings.model_validate(
        {
            "storage": {"data_dir": str(data_dir)},
            "retry": {
                "max_attempts": max_attempts,
                "base_delay": base_delay,
                "max_delay": 0.2,
                "jitter": "full",
            },
            "timeout": {
                "deadline": deadline,
                "attempt": attempt,
                "first_token": first_token,
                "stream_idle": stream_idle,
                "connect": 1.0,
                "write": 1.0,
            },
            "rate_limit": {"penalize_on_upstream_429": penalize_on_upstream_429},
            "auth": {"enabled": auth_enabled, "keys": auth_keys or []},
            "tenants": tenants or {},
            "circuit_breaker": circuit_breaker or {},
            "models": models,
        }
    )


class Harness:
    """一个网关实例 + 一个 mock 上游实例。"""

    def __init__(
        self,
        app: FastAPI,
        client: httpx.AsyncClient,
        mock_client: httpx.AsyncClient,
        settings: Settings,
        auth_headers: dict[str, str] | None = None,
    ) -> None:
        self.app = app
        self.client = client
        self.mock_client = mock_client
        self.settings = settings
        # 默认带上鉴权头（网关开了鉴权时，连测试自己查 /v1/requests 都要带头）。
        # 想测「没带 key」的场景就把它清空：harness.auth_headers = {}。
        self.auth_headers: dict[str, str] = auth_headers or {}

    async def chat(
        self, payload: dict, headers: dict[str, str] | None = None
    ) -> httpx.Response:
        merged = {**self.auth_headers, **(headers or {})}
        return await self.client.post(
            "/v1/chat/completions", json=payload, headers=merged
        )

    async def stream_chat(
        self, payload: dict, headers: dict[str, str] | None = None
    ) -> tuple[str, list[bytes]]:
        """发起流式请求，返回 (完整 SSE 文本, 逐块收到的原始字节)。"""
        chunks: list[bytes] = []
        merged = {**self.auth_headers, **(headers or {})}
        async with self.client.stream(
            "POST", "/v1/chat/completions", json=payload, headers=merged
        ) as response:
            async for chunk in response.aiter_bytes():
                chunks.append(chunk)
        return b"".join(chunks).decode("utf-8"), chunks

    @staticmethod
    def sse_payloads(text: str) -> list[dict]:
        """从 SSE 文本里抽出所有 data: 的 JSON 负载。

        网关的流式事件是自有的 `{"type": ...}` 形状（见 DESIGN §5.1），
        没有 `data: [DONE]` 哨兵——`type == "done"` 的事件本身就是终止符。
        """
        payloads: list[dict] = []
        for block in text.split("\n\n"):
            block = block.strip()
            if not block.startswith("data:"):
                continue
            data = block[len("data:") :].strip()
            if not data:
                continue
            payloads.append(json.loads(data))
        return payloads

    @staticmethod
    def stream_content(text: str) -> str:
        """拼接流式响应里所有 text_delta 的正文。"""
        return "".join(
            payload.get("text") or ""
            for payload in Harness.sse_payloads(text)
            if payload.get("type") == "text_delta"
        )

    @staticmethod
    def stream_reasoning(text: str) -> str:
        """拼接流式响应里所有 reasoning_delta 的思维链。"""
        return "".join(
            payload.get("text") or ""
            for payload in Harness.sse_payloads(text)
            if payload.get("type") == "reasoning_delta"
        )

    async def control(self, **payload: Any) -> dict:
        response = await self.mock_client.post("/_mock/_control", json=payload)
        return response.json()

    async def reset(self) -> dict:
        return await self.control(reset=True)

    async def mock_state(self) -> dict:
        response = await self.mock_client.get("/_mock/_control")
        return response.json()

    async def mock_chunks(self) -> dict[str, int]:
        """上游已产出的流式分片数（按「协议:模型」分组）。

        正常跑完的流会产满全部分片；被网关掐断的流会明显偏少。
        """
        state = await self.mock_state()
        return state.get("chunks", {})

    async def upstream_calls(self) -> int:
        state = await self.mock_state()
        return sum(state["calls"].values())

    async def records(
        self, headers: dict[str, str] | None = None, **params: Any
    ) -> list[dict]:
        merged = {**self.auth_headers, **(headers or {})}
        response = await self.client.get(
            "/v1/requests", params=params, headers=merged
        )
        return response.json()["data"]

    async def metrics(self, headers: dict[str, str] | None = None) -> dict:
        merged = {**self.auth_headers, **(headers or {})}
        response = await self.client.get("/v1/metrics", headers=merged)
        return response.json()

    def tpm_remaining(
        self, model: str = "deepseek-v4-pro", caller: str = "anonymous"
    ) -> float:
        """tpm 桶当前余额——用来观察预扣 / 结算 / 惩罚扣减的实际效果。"""
        remaining = self.app.state.gateway.limiter.remaining(caller, model)
        assert remaining is not None
        return remaining

    def reserved_tokens(self, model: str, contents: list[str]) -> int:
        """一次尝试的预扣量（预估输入 + 输出上限），与编排层算法一致。"""
        service = self.app.state.gateway
        adapter = service.adapter_for(model)
        return (
            service.token_counter.estimate_messages(contents)
            + adapter.resolve_max_output_tokens()
        )


async def build_harness(
    data_dir: Path,
    settings: Settings,
    *,
    disconnect_after: int | None = None,
    auth_headers: dict[str, str] | None = None,
) -> Harness:
    reset_mock_state()

    mock_app = FastAPI()
    mock_app.include_router(create_mock_router())

    upstream_client = httpx.AsyncClient(
        transport=StreamingASGITransport(mock_app),
        base_url="http://upstream.test",
    )
    app = create_app(settings, http_client=upstream_client)
    client = httpx.AsyncClient(
        transport=StreamingASGITransport(app, disconnect_after=disconnect_after),
        base_url="http://gateway.test",
    )
    mock_client = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=mock_app), base_url="http://upstream.test"
    )
    return Harness(app, client, mock_client, settings, auth_headers)


@pytest.fixture
async def harness(tmp_path: Path):
    settings = make_settings(tmp_path / "data")
    built = await build_harness(tmp_path / "data", settings)
    try:
        yield built
    finally:
        await built.client.aclose()
        await built.mock_client.aclose()


@pytest.fixture
async def make_harness(tmp_path: Path):
    """需要自定义限流/超时参数时用的工厂夹具。

    `disconnect_after` 特殊：它不是网关配置，而是**测试客户端**的行为
    （收到第 N 个响应分片后模拟挂断），所以在这里从网关配置里摘出来。
    `auth_headers` 同理：它是**测试客户端**带的头，不是网关配置。
    """

    created: list[Harness] = []

    async def factory(**kwargs: Any) -> Harness:
        disconnect_after = kwargs.pop("disconnect_after", None)
        auth_headers = kwargs.pop("auth_headers", None)
        data_dir = tmp_path / f"data-{len(created)}"
        settings = make_settings(data_dir, **kwargs)
        built = await build_harness(
            data_dir,
            settings,
            disconnect_after=disconnect_after,
            auth_headers=auth_headers,
        )
        created.append(built)
        return built

    try:
        yield factory
    finally:
        for built in created:
            await built.client.aclose()
            await built.mock_client.aclose()
