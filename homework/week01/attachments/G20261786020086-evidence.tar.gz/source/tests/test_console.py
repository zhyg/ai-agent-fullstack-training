"""用例 64-79：前端工作台的静态挂载、免鉴权边界、前端安全约束与试调用页签（契约 v2.11 / v2.12）。

这些用例覆盖的是**契约边界**，不是界面长相：
- 静态资源挂出来，但**不遮蔽**任何 `/v1/*` 行为；
- 免鉴权只给「不含数据的页面」，绝不外溢到数据接口；
- 前端源码里不出现「把字符串当 HTML 解析」的 API（XSS 即密钥泄漏）；
- 试调用页签只用**已存在**的接口、不自动发送、提示与后端行为一致。
"""

from __future__ import annotations

import re
from pathlib import Path

import httpx
import pytest

import main
from core.config import Settings

pytestmark = pytest.mark.anyio

WEB_DIR = Path(__file__).resolve().parent.parent / "web"

KEY = "sk-console-secret"
ENV = "LGW_KEY_CONSOLE"


def _settings(tmp_path: Path) -> Settings:
    """一份最小可用的网关配置（够 create_app 装配起来即可）。"""
    return Settings.model_validate(
        {
            "storage": {"data_dir": str(tmp_path / "data")},
            "models": {
                "deepseek-v4-pro": {
                    "base_url": "http://upstream.test/_mock/openai",
                    "upstream_id": "deepseek-v4-pro",
                    "enabled": True,
                }
            },
        }
    )


# --- 64-68：页面与静态资源 -----------------------------------------------


async def test_case64_console_page_is_public(harness):
    """开着鉴权时，工作台页面本身**不需要** key。

    页面只是外壳（HTML/JS/CSS），不含任何业务数据；真正的数据由浏览器
    带 Authorization 头去调 `/v1/*` 取。
    """
    response = await harness.client.get("/console/")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/html")
    assert "assets/app.js" in response.text


async def test_case65_console_without_slash_redirects(harness):
    """`/console` → 307 → `/console/`（补斜杠，否则相对路径解析会错）。"""
    response = await harness.client.get("/console", follow_redirects=False)

    assert response.status_code == 307
    assert response.headers["location"].endswith("/console/")


async def test_case66_root_redirects_to_console(harness):
    """`/` → 307 → `/console/`；不带 key 也一样（证明 `/` 在免鉴权集合里）。"""
    response = await harness.client.get("/", follow_redirects=False)

    assert response.status_code == 307
    assert response.headers["location"].endswith("/console/")


async def test_case67_static_assets_have_proper_content_type(harness):
    """JS / CSS 的 content-type 必须正确——否则浏览器会拒绝执行模块脚本。"""
    script = await harness.client.get("/console/assets/app.js")
    style = await harness.client.get("/console/assets/styles.css")

    assert script.status_code == 200
    assert "javascript" in script.headers["content-type"]
    assert style.status_code == 200
    assert "text/css" in style.headers["content-type"]


async def test_case68_unknown_asset_returns_error_envelope(harness):
    """不存在的静态资源 → 404，且 body 是网关的错误信封（不是 HTML 栈）。"""
    response = await harness.client.get("/console/nope.js")

    assert response.status_code == 404
    body = response.json()
    assert body["error"]["code"]
    assert body["error"]["request_id"] == response.headers["x-request-id"]


# --- 69-72：边界与隔离 ---------------------------------------------------


async def test_case69_mount_does_not_shadow_api(harness):
    """挂上 `/console` 之后，`/v1/*` 与 `/healthz` 行为零变化。"""
    models = await harness.client.get("/v1/models")
    metrics = await harness.client.get("/v1/metrics")
    health = await harness.client.get("/healthz")

    assert models.status_code == 200
    assert "models" in models.json()
    assert metrics.status_code == 200
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}


async def test_case70_exemption_does_not_leak(monkeypatch, make_harness):
    """免鉴权只覆盖页面：数据接口仍然要 key。"""
    monkeypatch.setenv(ENV, KEY)
    harness = await make_harness(
        auth_enabled=True,
        auth_keys=[{"name": "team-a", "key_env": ENV}],
        auth_headers={"Authorization": f"Bearer {KEY}"},
    )
    harness.auth_headers = {}

    denied = await harness.client.get("/v1/metrics")
    page = await harness.client.get("/console/")

    assert denied.status_code == 401
    assert denied.json()["error"]["code"] == "GW_UNAUTHORIZED"
    assert page.status_code == 200


async def test_case71_prefix_matching_respects_boundary(monkeypatch, make_harness):
    """`/consolex` 不能被 `/console` 的前缀豁免顺带放行。"""
    monkeypatch.setenv(ENV, KEY)
    harness = await make_harness(
        auth_enabled=True,
        auth_keys=[{"name": "team-a", "key_env": ENV}],
        auth_headers={"Authorization": f"Bearer {KEY}"},
    )
    harness.auth_headers = {}

    response = await harness.client.get("/consolex")

    assert response.status_code == 401


async def test_case72_path_traversal_is_rejected(harness):
    """路径穿越拿不到源码：404，且响应里不含后端源码片段。"""
    response = await harness.client.get("/console/%2e%2e/main.py")

    assert response.status_code == 404
    assert "create_app" not in response.text


# --- 73-75：装配与前端约束 -----------------------------------------------


def test_case73_missing_web_dir_fails_fast(monkeypatch, tmp_path):
    """`web/` 目录缺失 → 启动即失败，而不是运行期 404。

    `StaticFiles` 必须在 `create_app()` 内部构造，monkeypatch 才会生效。
    """
    monkeypatch.setattr(main, "_WEB_DIR", tmp_path / "no-such-dir")
    with pytest.raises(RuntimeError):
        main.create_app(_settings(tmp_path))


def test_case74_frontend_has_no_html_injection_apis():
    """前端源码里不许出现「把字符串当 HTML 解析」的 API（注释里也不许）。

    API Key 存在 localStorage 里，一次 XSS 就等于站点级密钥泄漏——
    这条约束必须是机器可检的，而不是靠人肉 review。
    """
    forbidden = [
        "innerHTML",
        "outerHTML",
        "insertAdjacentHTML",
        "document.write",
        "eval",
        "new Function",
        "srcdoc",
    ]

    offenders: list[str] = []
    for path in sorted(WEB_DIR.rglob("*.js")):
        source = path.read_text(encoding="utf-8")
        for token in forbidden:
            if token in source:
                offenders.append(f"{path.relative_to(WEB_DIR)}: {token}")

    assert offenders == []


async def test_case75_console_not_in_openapi(harness):
    """静态挂载不进契约文档——`/console` 与 `/` 都不是对外接口。"""
    response = await harness.client.get("/openapi.json")

    paths = response.json()["paths"]
    assert "/console" not in paths
    assert "/" not in paths
    assert "/v1/metrics" in paths


# --- 76-79：试调用页签（契约 v2.12） ------------------------------------


async def test_case76_playground_view_is_served(harness):
    """试调用页签的脚本挂出来了，页面里也真的有那个页签与容器。"""
    script = await harness.client.get("/console/assets/views/playground.js")
    page = await harness.client.get("/console/")

    assert script.status_code == 200
    assert "javascript" in script.headers["content-type"]
    assert "试调用" in page.text
    assert "view-playground" in page.text


def test_case77_playground_only_calls_existing_endpoints():
    """试调用页签只打**已存在**的接口——前端不得自己发明后端接口。"""
    source = (WEB_DIR / "assets" / "views" / "playground.js").read_text(encoding="utf-8")

    posted = set(re.findall(r'apiPost\(\s*"([^"]+)"', source))
    assert posted == {"/v1/chat/completions"}

    # 页签里出现的所有 `/v1/` 路径就这两个：取模型清单 + 发请求。
    referenced = set(re.findall(r'"(/v1/[^"]*)"', source))
    assert referenced <= {"/v1/chat/completions", "/v1/models"}


def test_case78_playground_never_sends_on_its_own():
    """这一页不许有定时器：副作用只能由用户点击触发（DESIGN §8.9.4）。"""
    source = (WEB_DIR / "assets" / "views" / "playground.js").read_text(encoding="utf-8")

    assert "setInterval" not in source
    assert "setTimeout" not in source


async def test_case79_conflict_hint_matches_backend_behavior(harness):
    """前端提示的错误码，必须就是后端真的会返回的那一个。"""
    response = await harness.chat(
        {
            "model": "deepseek-v4-pro",
            "messages": [{"role": "user", "content": "你好"}],
            "stream": True,
            "output_schema": {"name": "weather", "schema": {"type": "object"}},
        }
    )
    source = (WEB_DIR / "assets" / "views" / "playground.js").read_text(encoding="utf-8")

    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"
    assert "GW_INVALID_REQUEST" in source


def test_case80_hidden_attribute_really_hides_views():
    """页签切换靠 `hidden` 属性——它必须真的藏住视图。

    UA 样式表里有一条 `[hidden] { display: none }`，但任何同级的 `display`
    声明都会盖掉它：`.view` 声明了 `display: flex`，于是所有页签同时显示，
    页签形同虚设。这条规则必须由 reset 显式提供。
    """
    styles = (WEB_DIR / "assets" / "styles.css").read_text(encoding="utf-8")
    page = (WEB_DIR / "index.html").read_text(encoding="utf-8")

    assert re.search(r"\[hidden\][^{]*\{[^}]*display:\s*none", styles)
    # 除默认视图外，其余四个视图在 HTML 里都标了 hidden。
    assert page.count("hidden") >= 4


# --- 附加：真实 HTTP 客户端下的行为 --------------------------------------


async def test_extra_console_page_served_over_real_asgi_stack(tmp_path):
    """用普通 httpx（ASGITransport）访问，确认挂载不依赖测试客户端的特殊行为。"""
    app = main.create_app(_settings(tmp_path))
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://gw.test") as client:
        page = await client.get("/console/")
        root = await client.get("/", follow_redirects=False)

    assert page.status_code == 200
    assert "<title>" in page.text
    assert root.status_code == 307
