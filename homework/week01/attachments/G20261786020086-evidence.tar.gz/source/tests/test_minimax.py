"""用例 81-90：Chat Completions 协议与 MiniMax M2.7 接入（契约 v2.13）。

这些用例钉住的是**协议翻译**与**模型能力声明**：
- Provider 把统一请求/响应翻译成 Chat Completions 的形状（messages / choices / delta）；
- MiniMax 走 `prompt_only`（上游不执行 `response_format`），保证来自网关本地校验；
- 上游的错误（HTTP 码与流中错误帧）都被网关显式接住，不静默吞掉。
"""

from __future__ import annotations

import json

import pytest

from core.types import LLMRequest, ProtocolContext, SSEChunk
from providers.openai_chat_completions import OpenAIChatCompletionsProvider

pytestmark = pytest.mark.anyio

MODEL = "minimax-m2.7"
UPSTREAM_ID = "MiniMax-M2.7"

SCHEMA = {
    "type": "object",
    "properties": {"city": {"type": "string"}, "temp": {"type": "integer"}},
    "required": ["city", "temp"],
}


def _payload(model: str = MODEL, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


def _ctx(**overrides) -> ProtocolContext:
    base = {
        "upstream_id": UPSTREAM_ID,
        "base_url": "http://upstream.test",
        "api_key": "sk-test",
        "max_output_tokens": 8192,
    }
    base.update(overrides)
    return ProtocolContext(**base)


def _req(**overrides) -> LLMRequest:
    payload = {"model": MODEL, "messages": [{"role": "user", "content": "你好"}]}
    payload.update(overrides)
    return LLMRequest.model_validate(payload)


# --- 81：Provider 非流式解析 ---------------------------------------------


def test_case81_non_stream_response_is_translated():
    provider = OpenAIChatCompletionsProvider()
    raw = {
        "id": "chatcmpl_real",
        "model": UPSTREAM_ID,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "你好", "reasoning_content": "先想一下"},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 17,
            "completion_tokens": 6,
            "total_tokens": 23,
            "completion_tokens_details": {"reasoning_tokens": 4},
            "prompt_tokens_details": {"cached_tokens": 8},
        },
    }

    response = provider.parse_response(raw, _ctx())

    assert response.content == "你好"
    assert response.reasoning_content == "先想一下"
    assert response.finish_reason == "stop"
    assert response.usage.input_tokens == 17
    assert response.usage.output_tokens == 6
    assert response.usage.reasoning_tokens == 4
    assert response.usage.cache_read_tokens == 8
    assert response.usage.total_tokens == 23


def test_case81_finish_reason_is_neutralized():
    """上游的 finish_reason 只保留 stop / length 两档，其余一律当 stop。"""
    provider = OpenAIChatCompletionsProvider()

    def _parse(reason: str) -> str:
        raw = {
            "choices": [{"message": {"content": "x"}, "finish_reason": reason}],
        }
        return provider.parse_response(raw, _ctx()).finish_reason

    assert _parse("length") == "length"
    assert _parse("stop") == "stop"
    assert _parse("content_filter") == "stop"
    assert _parse("tool_calls") == "stop"


# --- 82：Provider 流式解析 -----------------------------------------------


def _chunk(data: dict) -> SSEChunk:
    return SSEChunk(event=None, data=json.dumps(data, ensure_ascii=False))


def test_case82_stream_deltas_are_translated():
    provider = OpenAIChatCompletionsProvider()
    ctx = _ctx()

    text = provider.parse_stream_event(_chunk({"choices": [{"delta": {"content": "你"}}]}), ctx)
    reasoning = provider.parse_stream_event(
        _chunk({"choices": [{"delta": {"reasoning_content": "想"}}]}), ctx
    )

    assert text.type == "text_delta" and text.text == "你"
    assert reasoning.type == "reasoning_delta" and reasoning.text == "想"


def test_case82_empty_delta_is_skipped():
    """空 delta 必须被跳过——否则 TTFT 会被打到一个空帧上。"""
    provider = OpenAIChatCompletionsProvider()
    ctx = _ctx()

    assert provider.parse_stream_event(_chunk({"choices": [{"delta": {}}]}), ctx) is None


def test_case82_usage_frame_is_translated():
    provider = OpenAIChatCompletionsProvider()
    ctx = _ctx()

    provider.parse_stream_event(
        _chunk({"choices": [{"delta": {}, "finish_reason": "stop"}]}), ctx
    )
    event = provider.parse_stream_event(
        _chunk(
            {
                "choices": [],
                "usage": {
                    "prompt_tokens": 17,
                    "completion_tokens": 6,
                    "total_tokens": 23,
                    "completion_tokens_details": {"reasoning_tokens": 4},
                },
            }
        ),
        ctx,
    )

    assert event.type == "usage"
    assert event.usage.input_tokens == 17
    assert event.usage.output_tokens == 6
    assert event.usage.reasoning_tokens == 4
    assert event.finish_reason == "stop"


def test_case82_done_sentinel_is_ignored():
    provider = OpenAIChatCompletionsProvider()

    assert provider.parse_stream_event(SSEChunk(event=None, data="[DONE]"), _ctx()) is None


def test_case82_same_frame_dual_delta_is_split():
    """一帧里同时有思维链与正文时，两个事件都要发出去，一个都不能丢。"""
    provider = OpenAIChatCompletionsProvider()
    ctx = _ctx()

    first = provider.parse_stream_event(
        _chunk({"choices": [{"delta": {"reasoning_content": "想", "content": "你好"}}]}), ctx
    )
    second = provider.parse_stream_event(_chunk({"choices": [{"delta": {}}]}), ctx)

    assert first.type == "reasoning_delta"
    assert second.type == "text_delta"
    assert second.text == "你好"


# --- 83：Provider 请求翻译 -----------------------------------------------


def test_case83_request_translation():
    provider = OpenAIChatCompletionsProvider()
    ctx = _ctx()

    upstream = provider.build_request(_req(), ctx)

    assert upstream.method == "POST"
    assert upstream.url == "http://upstream.test/v1/chat/completions"
    assert upstream.headers["Authorization"] == "Bearer sk-test"
    assert upstream.body["model"] == UPSTREAM_ID
    assert upstream.body["messages"] == [{"role": "user", "content": "你好"}]
    # 输出上限恒定下发（不因请求未指定而省略）
    assert upstream.body["max_tokens"] == 8192
    assert "stream" not in upstream.body


def test_case83_stream_request_asks_for_usage():
    provider = OpenAIChatCompletionsProvider()

    upstream = provider.build_request(_req(stream=True), _ctx())

    assert upstream.body["stream"] is True
    assert upstream.body["stream_options"] == {"include_usage": True}


def test_case83_native_mode_sends_response_format():
    provider = OpenAIChatCompletionsProvider()
    ctx = _ctx(
        structured_output_mode="native",
        schema_name="weather",
        json_schema=SCHEMA,
        schema_strict=True,
    )

    upstream = provider.build_request(_req(), ctx)

    assert upstream.body["response_format"]["type"] == "json_schema"
    assert upstream.body["response_format"]["json_schema"]["name"] == "weather"
    assert upstream.body["response_format"]["json_schema"]["schema"] == SCHEMA
    assert upstream.body["response_format"]["json_schema"]["strict"] is True


def test_case83_extra_body_is_passthrough():
    """模型级私有参数（reasoning_split）直接透传，且能覆盖默认值。"""
    provider = OpenAIChatCompletionsProvider()

    upstream = provider.build_request(
        _req(), _ctx(extra_body={"reasoning_split": True})
    )

    assert upstream.body["reasoning_split"] is True


# --- 84：端到端非流式 ---------------------------------------------------


async def test_case84_end_to_end_non_stream(harness):
    response = await harness.chat(_payload())
    body = response.json()

    assert response.status_code == 200
    # id / model 中立化：不是上游的厂商 id 与模型名
    assert body["id"].startswith("lgw-")
    assert body["model"] == MODEL
    assert body["content"] == "Hello from mock chat completions"
    assert body["reasoning_content"] == "mock reasoning"
    assert body["finish_reason"] == "stop"
    assert body["usage"]["input_tokens"] > 0
    assert body["usage"]["total_tokens"] > 0


async def test_case84_upstream_receives_bearer_token(make_harness, monkeypatch):
    monkeypatch.setenv("TEST_LLM_KEY", "secret-token")
    built = await make_harness(api_key_env="TEST_LLM_KEY")

    await built.chat(_payload())
    last = (await built.mock_state())["last_request"]

    assert last["path"] == "/_mock/openai-chat/v1/chat/completions"
    assert last["protocol"] == "openai-chat"
    assert last["headers"]["authorization"] == "Bearer secret-token"
    assert last["body"]["model"] == UPSTREAM_ID


# --- 85：端到端流式 -----------------------------------------------------


async def test_case85_end_to_end_stream(harness):
    plain = await harness.chat(_payload())
    expected = plain.json()["content"]

    text, chunks = await harness.stream_chat(_payload(stream=True))
    payloads = harness.sse_payloads(text)
    types = [payload["type"] for payload in payloads]

    assert harness.stream_content(text) == expected
    assert len(chunks) > 1, "SSE 没有分块返回"
    assert types[0] == "reasoning_delta"
    assert types[-2:] == ["usage", "done"]
    assert "[DONE]" not in text, "旧契约的 [DONE] 哨兵不应残留"


async def test_case85_stream_ttft_is_recorded(harness):
    await harness.stream_chat(_payload(stream=True))
    records = await harness.records()

    assert records[0]["ttft_ms"] is not None
    assert records[0]["ttft_ms"] > 0


# --- 86：结构化输出走 prompt_only ----------------------------------------


async def test_case86_structured_output_uses_prompt_only(harness):
    """MiniMax 走 prompt_only：上游**收不到** response_format。

    上游接受但不执行 response_format（实测），声明 native 等于向调用方承诺一个
    上游没兑现的硬约束——所以 Adapter 据实选 prompt_only（DESIGN §5.2.3）。
    """
    response = await harness.chat(
        _payload(output_schema={"name": "weather", "schema": SCHEMA})
    )
    body = (await harness.mock_state())["last_request"]["body"]

    assert "response_format" not in body
    # schema 被写进了 system 提示词
    system_text = " ".join(m["content"] for m in body["messages"] if m["role"] == "system")
    assert "city" in system_text and "temp" in system_text
    # 200 且内容通过网关本地 schema 校验
    assert response.status_code == 200
    content = json.loads(response.json()["content"])
    assert set(content) == {"city", "temp"}


async def test_case86_capability_declares_prompt_only(harness):
    """`output_schema_strict` 只在 native 模式下为真（上游能否硬约束）。"""
    response = await harness.client.get("/v1/models")
    models = {item["id"]: item for item in response.json()["models"]}

    capabilities = models[MODEL]["capabilities"]
    assert capabilities["output_schema"] is True
    assert capabilities["output_schema_strict"] is False
    assert capabilities["max_output_tokens"] == 8192
    assert capabilities["max_input_tokens"] == 196608


# --- 87/88：模型清单与未注册模型 -----------------------------------------


async def test_case87_model_is_listed(harness):
    response = await harness.client.get("/v1/models")
    ids = [item["id"] for item in response.json()["models"]]

    assert MODEL in ids


async def test_case88_unregistered_model_is_404(harness):
    response = await harness.chat(_payload("minimax-m2.9"))

    assert response.status_code == 404
    assert response.json()["error"]["code"] == "GW_MODEL_NOT_FOUND"
    assert await harness.upstream_calls() == 0


# --- 89：上游错误映射 ---------------------------------------------------


async def test_case89_upstream_401_is_auth_error(harness):
    await harness.control(fail="401")
    response = await harness.chat(_payload())

    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_AUTH_ERROR"


async def test_case89_upstream_400_is_upstream_rejected(harness):
    await harness.control(fail="400")
    response = await harness.chat(_payload())

    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_UPSTREAM_REJECTED"


async def test_case89_upstream_429_is_retriable(harness):
    await harness.control(fail="429")
    response = await harness.chat(_payload())

    assert response.status_code == 429
    body = response.json()["error"]
    assert body["code"] == "GW_UPSTREAM_RATE_LIMITED"
    assert body["retriable"] is True


# --- 90：流中途的上游错误帧 ---------------------------------------------


async def test_case90_stream_error_frame_is_not_swallowed(harness):
    """上游在流里报错 → 网关发 error 帧 + done{finish_reason:"error"}。

    不能静默吞掉：吞掉的话客户端会以为这次调用正常结束。
    """
    await harness.control(fail="stream_error")
    text, _ = await harness.stream_chat(_payload(stream=True))
    payloads = harness.sse_payloads(text)
    types = [payload["type"] for payload in payloads]

    assert "error" in types
    assert types[-1] == "done"
    assert payloads[-1]["finish_reason"] == "error"

    records = await harness.records()
    assert records[0]["status"] == "error"
