"""用例 91-95：上游密钥的供给（契约 v2.14）。

钉住的是**部署侧的取密钥路径**：
- `.env` 能被解析、被加载，且**只补不覆盖**（容器编排注入的值优先）；
- 密钥文件可作为环境变量的替代来源，环境变量优先；
- 配了密钥来源却读不到 → **启动就失败**，而不是运行期变成 502。
"""

from __future__ import annotations

import json
import os

import pytest

from core.config import Settings, load_settings, validate_upstream_secrets
from core.secrets import parse_env_file, read_secret_file, resolve_api_key
from main import create_app

pytestmark = pytest.mark.anyio

MODEL = "minimax-m2.7"


# --- 91：.env 解析 -----------------------------------------------------


def test_case91_env_file_parsing():
    parsed = parse_env_file(
        "\n".join(
            [
                "# 一行注释",
                "",
                "PLAIN=value",
                "export EXPORTED=exported-value",
                'QUOTED="quoted value"',
                "SINGLE='single value'",
                "SPACED = spaced ",
                "INLINE=keep # 注释丢掉",
                "NO_EQUALS_SIGN",
            ]
        )
    )

    assert parsed["PLAIN"] == "value"
    assert parsed["EXPORTED"] == "exported-value"
    assert parsed["QUOTED"] == "quoted value"
    assert parsed["SINGLE"] == "single value"
    assert parsed["SPACED"] == "spaced"
    assert parsed["INLINE"] == "keep"
    # 没有 `=` 的行被跳过，而不是让整个文件解析失败
    assert "NO_EQUALS_SIGN" not in parsed


def test_case91_env_file_is_loaded_into_environment(tmp_path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text("LGW_TEST_ENV_KEY=from-env-file\n", encoding="utf-8")

    monkeypatch.delenv("LGW_TEST_ENV_KEY", raising=False)
    settings = load_settings(_write_config(tmp_path, env_file=str(env_file)))

    assert settings.env.file == str(env_file)
    assert os.environ["LGW_TEST_ENV_KEY"] == "from-env-file"


# --- 92：只补不覆盖 ----------------------------------------------------


def test_case92_existing_environment_wins(tmp_path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text("LGW_TEST_ENV_KEY=from-env-file\n", encoding="utf-8")

    monkeypatch.setenv("LGW_TEST_ENV_KEY", "from-environment")
    load_settings(_write_config(tmp_path, env_file=str(env_file)))

    assert os.environ["LGW_TEST_ENV_KEY"] == "from-environment"


def test_case92_env_file_can_be_disabled(tmp_path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text("LGW_TEST_ENV_KEY=from-env-file\n", encoding="utf-8")

    monkeypatch.delenv("LGW_TEST_ENV_KEY", raising=False)
    settings = load_settings(_write_config(tmp_path, env_file=""))

    assert settings.env.file == ""
    assert "LGW_TEST_ENV_KEY" not in os.environ


# --- 93：密钥文件 ------------------------------------------------------


def test_case93_secret_file_is_read(tmp_path):
    secret = tmp_path / "minimax.key"
    secret.write_text("sk-from-file\n", encoding="utf-8")

    assert read_secret_file(secret) == "sk-from-file"


def test_case93_missing_secret_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        read_secret_file(tmp_path / "nope.key")


def test_case93_environment_wins_over_file(tmp_path, monkeypatch):
    secret = tmp_path / "minimax.key"
    secret.write_text("sk-from-file", encoding="utf-8")

    monkeypatch.setenv("LGW_TEST_UPSTREAM_KEY", "sk-from-environment")

    assert resolve_api_key("LGW_TEST_UPSTREAM_KEY", str(secret)) == "sk-from-environment"
    monkeypatch.delenv("LGW_TEST_UPSTREAM_KEY")
    assert resolve_api_key("LGW_TEST_UPSTREAM_KEY", str(secret)) == "sk-from-file"


# --- 94：读不到密钥 = 启动失败 -----------------------------------------


def test_case94_missing_secret_fails_at_startup(monkeypatch, tmp_path):
    monkeypatch.delenv("LGW_TEST_MISSING_KEY", raising=False)
    settings = Settings.model_validate(
        {
            "storage": {"data_dir": str(tmp_path / "data")},
            "models": {
                MODEL: {
                    "base_url": "http://upstream.test",
                    "upstream_id": "MiniMax-M2.7",
                    "api_key_env": "LGW_TEST_MISSING_KEY",
                }
            },
        }
    )

    with pytest.raises(ValueError) as excinfo:
        create_app(settings)

    message = str(excinfo.value)
    assert MODEL in message
    assert "LGW_TEST_MISSING_KEY" in message


def test_case94_missing_secret_file_fails_at_startup(tmp_path):
    settings = Settings.model_validate(
        {
            "storage": {"data_dir": str(tmp_path / "data")},
            "models": {
                MODEL: {
                    "base_url": "http://upstream.test",
                    "upstream_id": "MiniMax-M2.7",
                    "api_key_file": str(tmp_path / "missing.key"),
                }
            },
        }
    )

    with pytest.raises(ValueError) as excinfo:
        create_app(settings)

    assert "missing.key" in str(excinfo.value)


def test_case94_disabled_model_is_not_checked(monkeypatch, tmp_path):
    """只想跑 mock 的部署：把模型关掉就不该被密钥校验拦住。"""
    monkeypatch.delenv("LGW_TEST_MISSING_KEY", raising=False)
    settings = Settings.model_validate(
        {
            "storage": {"data_dir": str(tmp_path / "data")},
            "models": {
                MODEL: {
                    "base_url": "http://upstream.test",
                    "upstream_id": "MiniMax-M2.7",
                    "api_key_env": "LGW_TEST_MISSING_KEY",
                    "enabled": False,
                }
            },
        }
    )

    validate_upstream_secrets(settings)


# --- 95：端到端用密钥文件 ----------------------------------------------


async def test_case95_secret_file_reaches_upstream(make_harness, tmp_path):
    secret = tmp_path / "minimax.key"
    secret.write_text("sk-secret-file-token\n", encoding="utf-8")

    built = await make_harness(api_key_file=str(secret))
    await built.chat({"model": MODEL, "messages": [{"role": "user", "content": "你好"}]})

    last = (await built.mock_state())["last_request"]
    assert last["headers"]["authorization"] == "Bearer sk-secret-file-token"


def _write_config(tmp_path, *, env_file: str) -> str:
    """造一份只含 `[env]` 的 config.toml，返回它的路径。

    路径用 JSON 风格转义后再写进 TOML：Windows 的反斜杠在 TOML 基本字符串里
    是转义符，直接写会让文件解析失败。
    """
    path = tmp_path / "config.toml"
    path.write_text(f"[env]\nfile = {json.dumps(env_file)}\n", encoding="utf-8")
    return str(path)
