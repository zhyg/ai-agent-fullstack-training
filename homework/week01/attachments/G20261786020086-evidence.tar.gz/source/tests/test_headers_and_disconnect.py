"""用例 27、28：响应头契约、客户端断开取消上游（契约 v2.5）。"""

from __future__ import annotations

import asyncio

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"

# 上游完整跑完时会产出的分片数（openai 协议）：
# created + reasoning + 4 段正文 + text.done + completed
FULL_STREAM_CHUNKS = 8


def _payload(model: str, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


async def _wait_for_record(harness, timeout: float = 3.0) -> dict:
    """等调用记录落库。

    客户端断开时，网关是在**收到断开之后**才异步取消上游并写记录的，
    客户端这边的连接可能先结束，所以这里轮询等一下再断言。
    """
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        records = await harness.records()
        if records:
            return records[0]
        await asyncio.sleep(0.05)
    raise AssertionError("调用记录没有出现")


async def test_case27_non_stream_response_carries_request_id(harness):
    """非流式响应：头里的 id == 响应体里的 id。"""
    response = await harness.chat(_payload(PRO))
    body = response.json()

    assert response.status_code == 200
    assert response.headers["X-Request-ID"]
    assert response.headers["X-Request-ID"] == body["id"]


async def test_case27_error_response_carries_request_id(harness):
    """错误响应：头里的 id == 错误信封里的 request_id。"""
    response = await harness.chat(_payload(PRO, tools=[]))

    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "GW_INVALID_REQUEST"
    assert response.headers["X-Request-ID"] == body["error"]["request_id"]


async def test_case27_sse_response_carries_stream_headers(harness):
    """SSE 响应：X-Request-ID 之外还要带两个防缓冲 / 防缓存的头。"""
    async with harness.client.stream(
        "POST", "/v1/chat/completions", json=_payload(PRO, stream=True)
    ) as response:
        headers = response.headers
        async for _ in response.aiter_bytes():
            pass

    assert headers["X-Request-ID"]
    assert headers["cache-control"] == "no-cache, no-transform"
    assert headers["x-accel-buffering"] == "no"


async def test_case27_request_id_matches_call_record(harness):
    """同一个 id 要贯穿「响应头 / 响应体 / 调用记录」三处。"""
    response = await harness.chat(_payload(PRO))
    request_id = response.headers["X-Request-ID"]

    records = await harness.records()
    assert records[0]["request_id"] == request_id


async def test_case28_client_disconnect_cancels_upstream(make_harness):
    """客户端在流到一半时挂断：取消上游、不发事件帧、不重试、记 cancelled。"""
    harness = await make_harness(disconnect_after=1)
    # 让上游一个分片一个分片地慢慢吐，测试才有「流到一半」可言。
    await harness.control(chunk_delay=0.05)

    text, _ = await harness.stream_chat(_payload(PRO, stream=True))

    # 客户端已经不在了：不能再发 error / done 事件帧。
    types = [payload["type"] for payload in harness.sse_payloads(text)]
    assert "error" not in types, "客户端断开后不应再发错误帧"
    assert "done" not in types, "客户端断开后不应再发收尾帧"

    record = await _wait_for_record(harness)
    assert record["status"] == "cancelled"
    assert record["error_code"] is None, "取消不是错误，不该带错误码"
    assert record["attempt_count"] == 1, "客户端断开不应重试"
    assert await harness.upstream_calls() == 1

    # 上游确实被掐断了：分片数明显少于完整跑完的次数。
    chunks = await harness.mock_chunks()
    assert chunks["openai:deepseek-v4-pro"] < FULL_STREAM_CHUNKS, "上游没有被取消"


async def test_case28_cancelled_is_counted_separately(make_harness):
    """取消单独计数，不算 error（契约 §6.5）。"""
    harness = await make_harness(disconnect_after=1)
    await harness.control(chunk_delay=0.05)

    await harness.stream_chat(_payload(PRO, stream=True))
    await _wait_for_record(harness)

    metrics = await harness.metrics()
    assert metrics["overall"]["cancelled"] == 1
    assert metrics["overall"]["errors"] == 0


async def test_case28_disconnect_before_first_byte_cancels_upstream(make_harness):
    """客户端在**首字节之前**就走了：同样取消上游、记 cancelled、不发事件帧。

    这个窗口比「流到一半」更危险——此时网关已经把请求发出去了，
    上游正在生成，却没有任何字节发回给客户端，不取消就是纯烧 token。
    """
    harness = await make_harness(disconnect_after=0)

    text, _ = await harness.stream_chat(_payload(PRO, stream=True))
    assert text == "", "客户端已经走了，不该收到任何事件帧"

    record = await _wait_for_record(harness)
    assert record["status"] == "cancelled"
    assert record["error_code"] is None
    assert await harness.upstream_calls() <= 1, "客户端断开不应重试"
