"""用例 8、9、16：Token 分类统计、延迟分位、usage 语义。"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"


def _payload(model: str, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


async def test_case8_openai_token_categories(harness):
    await harness.chat(_payload(PRO))
    metrics = await harness.metrics()
    tokens = metrics["overall"]["tokens"]

    assert tokens["input_tokens"] > 0
    assert tokens["output_tokens"] > 0
    assert tokens["reasoning_tokens"] == 5
    assert tokens["cache_read_tokens"] == 0
    assert tokens["cache_write_tokens"] == 0
    assert tokens["total_tokens"] == (
        tokens["input_tokens"] + tokens["output_tokens"]
    )


async def test_case8_anthropic_cache_categories(harness):
    await harness.control(cache_read=True)
    await harness.chat(
        {
            "model": FLASH,
            "messages": [
                {"role": "system", "content": "你是助手"},
                {"role": "user", "content": "你好"},
            ],
        }
    )
    tokens = (await harness.metrics())["overall"]["tokens"]

    assert tokens["cache_read_tokens"] > 0
    assert tokens["cache_write_tokens"] > 0
    assert tokens["reasoning_tokens"] == 0
    assert tokens["total_tokens"] == (
        tokens["input_tokens"] + tokens["output_tokens"]
    )


async def test_case8_tokens_are_split_by_model(harness):
    await harness.chat(_payload(PRO))
    await harness.chat(_payload(FLASH))
    metrics = await harness.metrics()
    by_model = metrics["by_model"]
    assert by_model[PRO]["requests"] == 1
    assert by_model[FLASH]["requests"] == 1
    assert metrics["overall"]["requests"] == 2


async def test_case9_latency_percentiles(harness):
    for _ in range(3):
        await harness.chat(_payload(PRO))
    latency = (await harness.metrics())["overall"]["latency_ms"]

    assert latency["avg"] > 0
    assert latency["p50"] > 0
    assert latency["p50"] <= latency["p95"] <= latency["max"]


async def test_case9_non_streaming_has_no_ttft(harness):
    await harness.chat(_payload(PRO))
    records = await harness.records()
    assert records[0]["ttft_ms"] is None

    metrics = await harness.metrics()
    assert metrics["overall"]["ttft_ms"]["count"] == 0


async def test_case9_streaming_records_ttft(harness):
    await harness.stream_chat(_payload(PRO, stream=True))
    metrics = await harness.metrics()
    assert metrics["overall"]["ttft_ms"]["count"] == 1
    assert metrics["overall"]["ttft_ms"]["avg"] > 0


async def test_case16_usage_is_sum_of_attempts(harness):
    await harness.control(content="bad_json", content_times=1)
    response = await harness.chat(
        {
            "model": PRO,
            "messages": [{"role": "user", "content": "你好"}],
            "output_schema": {
                "name": "r",
                "schema": {"type": "object", "properties": {"a": {"type": "string"}}},
            },
        }
    )
    usage = response.json()["usage"]
    records = await harness.records()
    attempts = records[0]["attempts"]

    assert len(attempts) == 2
    assert attempts[0]["usage"]["total_tokens"] > 0
    assert usage["total_tokens"] == sum(a["usage"]["total_tokens"] for a in attempts)


async def test_case16_attempts_record_prompt_hash_and_strength(harness):
    await harness.control(content="bad_json", content_times=1)
    await harness.chat(
        {
            "model": PRO,
            "messages": [{"role": "user", "content": "你好"}],
            "output_schema": {
                "name": "r",
                "schema": {"type": "object", "properties": {"a": {"type": "string"}}},
            },
        }
    )
    attempts = (await harness.records())[0]["attempts"]
    assert attempts[0]["prompt_hash"]
    assert attempts[1]["prompt_hash"]
    assert attempts[0]["prompt_hash"] != attempts[1]["prompt_hash"]
    assert attempts[0]["prompt_strength"] == 0
    assert attempts[1]["prompt_strength"] == 1


async def test_case16_usage_uses_neutral_token_names(harness):
    """usage 的字段名是网关自有的 input/output_tokens，不是 prompt/completion_tokens。"""
    response = await harness.chat(_payload(PRO))
    usage = response.json()["usage"]

    assert "input_tokens" in usage
    assert "output_tokens" in usage
    assert "prompt_tokens" not in usage
    assert "completion_tokens" not in usage


async def test_case16_requests_endpoint_exposes_records(harness):
    await harness.chat(_payload(PRO))
    records = await harness.records(model=PRO)
    assert len(records) == 1
    assert records[0]["model"] == PRO
    assert records[0]["adapter"] == PRO
    assert records[0]["provider"] == "openai_responses"
    assert records[0]["protocol"] == "openai_responses"
    assert records[0]["status"] == "success"
