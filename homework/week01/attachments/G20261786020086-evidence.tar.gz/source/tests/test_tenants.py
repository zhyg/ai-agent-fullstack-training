"""用例 33-39：多租户（契约 v2.7）。"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"
MINIMAX = "minimax-m2.7"

KEY_A = "sk-tenant-a"
KEY_B = "sk-tenant-b"
KEY_OPS = "sk-tenant-ops"

ENV_A = "LGW_KEY_A"
ENV_B = "LGW_KEY_B"
ENV_OPS = "LGW_KEY_OPS"


def _payload(model: str = PRO, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


def _as(key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {key}"}


async def _tenants_harness(monkeypatch, make_harness, tenants: dict, **settings):
    """起一个开了鉴权、带三个租户（team-a / team-b / ops）的网关。

    team-a / team-b 的租户配置由参数 `tenants` 决定；ops 恒为管理员。
    """
    monkeypatch.setenv(ENV_A, KEY_A)
    monkeypatch.setenv(ENV_B, KEY_B)
    monkeypatch.setenv(ENV_OPS, KEY_OPS)
    config = {
        "team-a": tenants.get("team-a", {}),
        "team-b": tenants.get("team-b", {}),
        "ops": {"admin": True},
    }
    return await make_harness(
        auth_enabled=True,
        auth_keys=[
            {"name": "team-a", "key_env": ENV_A},
            {"name": "team-b", "key_env": ENV_B},
            {"name": "ops", "key_env": ENV_OPS},
        ],
        tenants=config,
        auth_headers=_as(KEY_OPS),
        **settings,
    )


async def test_case33_tenant_quotas_are_independent(monkeypatch, make_harness):
    """租户 A 打满自己的配额 → A 收 429，租户 B 同时照常调用。"""
    harness = await _tenants_harness(
        monkeypatch,
        make_harness,
        tenants={"team-a": {"rate_limit": {"rpm": 2, "tpm": 600_000}}},
    )

    for _ in range(2):
        assert (
            await harness.chat(_payload(), headers=_as(KEY_A))
        ).status_code == 200

    rejected = await harness.chat(_payload(), headers=_as(KEY_A))
    assert rejected.status_code == 429
    assert rejected.json()["error"]["code"] == "GW_RATE_LIMITED"
    assert "team-a" in rejected.json()["error"]["message"]

    # 另一个租户的桶是独立的，不受影响。
    assert (
        await harness.chat(_payload(), headers=_as(KEY_B))
    ).status_code == 200


async def test_case34_model_override_beats_tenant_quota(monkeypatch, make_harness):
    """优先级 1：`model_rate_limit` 高于租户的统一 `rate_limit`。"""
    harness = await _tenants_harness(
        monkeypatch,
        make_harness,
        tenants={
            "team-a": {
                "rate_limit": {"rpm": 5, "tpm": 600_000},
                "model_rate_limit": {PRO: {"rpm": 1, "tpm": 600_000}},
            }
        },
    )

    assert (
        await harness.chat(_payload(PRO), headers=_as(KEY_A))
    ).status_code == 200
    # pro 的桶只有 1 个请求的额度（租户统一配额是 5，但按模型覆盖更严）。
    assert (
        await harness.chat(_payload(PRO), headers=_as(KEY_A))
    ).status_code == 429
    # 换个模型不受 pro 的覆盖影响，租户统一配额 5 仍然生效。
    for _ in range(5):
        assert (
            await harness.chat(_payload(FLASH), headers=_as(KEY_A))
        ).status_code == 200
    assert (
        await harness.chat(_payload(FLASH), headers=_as(KEY_A))
    ).status_code == 429


async def test_case34_tenant_quota_beats_model_default(monkeypatch, make_harness):
    """优先级 2：租户的统一 `rate_limit` 高于模型默认配额。"""
    harness = await _tenants_harness(
        monkeypatch,
        make_harness,
        tenants={"team-a": {"rate_limit": {"rpm": 3, "tpm": 600_000}}},
        rpm=1,
    )

    for _ in range(3):
        assert (
            await harness.chat(_payload(), headers=_as(KEY_A))
        ).status_code == 200
    assert (
        await harness.chat(_payload(), headers=_as(KEY_A))
    ).status_code == 429


async def test_case34_unconfigured_tenant_uses_model_default(
    monkeypatch, make_harness
):
    """优先级 3：没配租户的调用方用模型默认配额。"""
    harness = await _tenants_harness(monkeypatch, make_harness, tenants={}, rpm=2)

    for _ in range(2):
        assert (
            await harness.chat(_payload(), headers=_as(KEY_B))
        ).status_code == 200
    assert (
        await harness.chat(_payload(), headers=_as(KEY_B))
    ).status_code == 429


async def test_case35_model_visibility_is_enforced(monkeypatch, make_harness):
    """租户请求不在白名单里的模型 → 404，且不发上游请求、不消耗配额。"""
    harness = await _tenants_harness(
        monkeypatch,
        make_harness,
        tenants={"team-a": {"models": [PRO]}},
    )

    response = await harness.chat(_payload(FLASH), headers=_as(KEY_A))

    assert response.status_code == 404
    assert response.json()["error"]["code"] == "GW_MODEL_NOT_FOUND"
    assert await harness.upstream_calls() == 0


async def test_case36_model_list_is_filtered_per_tenant(monkeypatch, make_harness):
    """`GET /v1/models` 只返回该租户可见的模型。"""
    harness = await _tenants_harness(
        monkeypatch,
        make_harness,
        tenants={"team-a": {"models": [PRO]}},
    )

    listed = await harness.client.get("/v1/models", headers=_as(KEY_A))
    ids = [item["id"] for item in listed.json()["models"]]
    assert ids == [PRO]

    # 另一个租户没配白名单 → 看到全部。
    listed_b = await harness.client.get("/v1/models", headers=_as(KEY_B))
    ids_b = [item["id"] for item in listed_b.json()["models"]]
    assert set(ids_b) == {PRO, FLASH, MINIMAX}


async def test_case37_records_are_attributed_and_isolated(monkeypatch, make_harness):
    """记录带 caller；普通租户只看得到自己的，管理员看得到全部。"""
    harness = await _tenants_harness(monkeypatch, make_harness, tenants={})

    await harness.chat(_payload(), headers=_as(KEY_A))
    await harness.chat(_payload(), headers=_as(KEY_B))

    own = await harness.records(headers=_as(KEY_A))
    assert [item["caller"] for item in own] == ["team-a"]

    # 显式查别人的 → 400（不静默忽略）。
    denied = await harness.client.get(
        "/v1/requests", params={"caller": "team-b"}, headers=_as(KEY_A)
    )
    assert denied.status_code == 400
    assert denied.json()["error"]["code"] == "GW_INVALID_REQUEST"

    # 管理员看得到全部，并可按租户过滤。
    everything = await harness.records(headers=_as(KEY_OPS))
    assert {item["caller"] for item in everything} == {"team-a", "team-b"}
    filtered = await harness.records(headers=_as(KEY_OPS), caller="team-b")
    assert [item["caller"] for item in filtered] == ["team-b"]


async def test_case38_metrics_are_grouped_by_caller(monkeypatch, make_harness):
    """`/v1/metrics` 含 by_caller；普通租户只看到自己的数据，形状不变。"""
    harness = await _tenants_harness(monkeypatch, make_harness, tenants={})

    await harness.chat(_payload(), headers=_as(KEY_A))
    await harness.chat(_payload(), headers=_as(KEY_B))

    own = await harness.metrics(headers=_as(KEY_A))
    assert set(own["by_caller"]) == {"team-a"}
    assert own["overall"]["requests"] == 1
    assert set(own["by_model"]) == {PRO}

    admin_view = await harness.metrics(headers=_as(KEY_OPS))
    assert set(admin_view["by_caller"]) == {"team-a", "team-b"}
    assert admin_view["overall"]["requests"] == 2


async def test_case39_caller_is_anonymous_without_auth(harness):
    """未开鉴权时 caller 恒为 anonymous，行为与 v2.6 一致。"""
    response = await harness.chat(_payload())
    assert response.status_code == 200

    records = await harness.records()
    assert [item["caller"] for item in records] == ["anonymous"]
