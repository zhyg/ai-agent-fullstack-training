"""用例 5、13：流式输出与流式重试边界。"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"


def _payload(model: str, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


async def test_case5_stream_matches_non_stream(harness):
    plain = await harness.chat(_payload(PRO))
    expected = plain.json()["content"]

    text, chunks = await harness.stream_chat(_payload(PRO, stream=True))
    assert harness.stream_content(text) == expected
    assert len(chunks) > 1, "SSE 没有分块返回"


async def test_case5_flash_stream_matches_non_stream(harness):
    plain = await harness.chat(_payload(FLASH))
    expected = plain.json()["content"]

    text, _ = await harness.stream_chat(_payload(FLASH, stream=True))
    assert harness.stream_content(text) == expected


async def test_case5_stream_ends_with_done(harness):
    """流以 `type == "done"` 的事件收尾，没有 `[DONE]` 哨兵。"""
    text, _ = await harness.stream_chat(_payload(PRO, stream=True))
    payloads = harness.sse_payloads(text)

    assert payloads[-1]["type"] == "done"
    assert payloads[-1]["finish_reason"] == "stop"
    assert "[DONE]" not in text, "旧契约的 [DONE] 哨兵不应残留"


async def test_case5_stream_event_order(harness):
    """事件序列固定：增量 → usage → done。"""
    text, _ = await harness.stream_chat(_payload(PRO, stream=True))
    types = [payload["type"] for payload in harness.sse_payloads(text)]

    assert types[0] == "reasoning_delta"
    assert types[-2:] == ["usage", "done"]
    assert "text_delta" in types
    assert types.count("done") == 1


async def test_case5_both_models_emit_reasoning_delta(harness):
    """两条协议都要能产出思维链，否则 reasoning_delta 在一侧是死代码。"""
    text, _ = await harness.stream_chat(_payload(PRO, stream=True))
    assert harness.stream_reasoning(text) == "mock reasoning"

    text, _ = await harness.stream_chat(_payload(FLASH, stream=True))
    assert harness.stream_reasoning(text) == "mock thinking done"


async def test_case5_ttft_is_recorded(harness):
    await harness.stream_chat(_payload(PRO, stream=True))
    records = await harness.records()
    assert records[0]["ttft_ms"] is not None
    assert records[0]["ttft_ms"] > 0
    assert records[0]["stream"] is True


async def test_case5_stream_always_reports_usage(harness):
    """usage 恒定下发，不需要调用方额外传开关（旧契约的 stream_options 已下线）。"""
    text, _ = await harness.stream_chat(_payload(PRO, stream=True))
    payloads = harness.sse_payloads(text)
    usage_payloads = [p for p in payloads if p.get("type") == "usage"]
    assert usage_payloads, "流式响应缺少 usage 帧"
    assert usage_payloads[-1]["usage"]["total_tokens"] > 0
    assert usage_payloads[-1]["usage"]["input_tokens"] > 0


async def test_contract_stream_options_is_rejected(harness):
    """`stream_options` 是旧契约的字段，新契约里是未知字段 → 400。"""
    response = await harness.chat(
        _payload(PRO, stream=True, stream_options={"include_usage": True})
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"


async def test_case13_failure_before_first_byte_is_retried(harness):
    await harness.control(fail="500", fail_times=1)
    text, _ = await harness.stream_chat(_payload(PRO, stream=True))

    assert await harness.upstream_calls() == 2
    assert harness.stream_content(text) == "Hello from mock responses"
    records = await harness.records()
    assert records[0]["status"] == "success"
    assert records[0]["attempt_count"] == 2


async def test_case13_disconnect_after_first_byte_is_not_retried(harness):
    await harness.control(break_after=1)
    text, _ = await harness.stream_chat(_payload(PRO, stream=True))

    assert await harness.upstream_calls() == 1, "首字节后断开不应重试"

    payloads = harness.sse_payloads(text)
    errors = [p for p in payloads if p.get("error")]
    assert errors, "流式响应缺少错误帧"
    assert errors[0]["error"]["code"] == "GW_UPSTREAM_ERROR"

    records = await harness.records()
    assert records[0]["status"] == "error"
    assert records[0]["attempt_count"] == 1
    assert records[0]["attempts"][0]["partial_output_chars"] > 0


async def test_contract_stream_and_output_schema_are_mutually_exclusive(harness):
    """`stream` 与 `output_schema` 互斥：同时出现即 400，且不触达上游。

    v2.4 推翻了「流尾做 schema 校验」：流式下「保证内容符合 schema」本身
    做不到（字节已经发出去了，流尾校验只是事后追认），所以在入口就拒。
    """
    response = await harness.chat(
        _payload(
            PRO,
            stream=True,
            output_schema={
                "name": "r",
                "schema": {
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                    "required": ["city"],
                },
            },
        )
    )

    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"
    assert await harness.upstream_calls() == 0, "契约违规的请求不应触达上游"
