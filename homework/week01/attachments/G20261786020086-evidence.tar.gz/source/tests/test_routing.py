"""用例 1-4：路由、协议翻译、响应解析、适配器隔离。"""

from __future__ import annotations

import pathlib

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"


def _payload(model: str, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


async def test_case1_pro_routes_to_openai_responses(harness):
    response = await harness.chat(_payload(PRO))
    assert response.status_code == 200
    state = await harness.mock_state()
    assert state["last_request"]["path"] == "/_mock/openai/v1/responses"
    assert state["last_request"]["protocol"] == "openai"
    assert state["last_request"]["body"]["model"] == "deepseek-v4-pro"


async def test_case1_flash_routes_to_anthropic_messages(harness):
    response = await harness.chat(_payload(FLASH))
    assert response.status_code == 200
    state = await harness.mock_state()
    assert state["last_request"]["path"] == "/_mock/anthropic/v1/messages"
    assert state["last_request"]["protocol"] == "anthropic"


async def test_case1_unknown_model_is_404(harness):
    response = await harness.chat(_payload("deepseek-v9-ultra"))
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "GW_MODEL_NOT_FOUND"


async def test_case2_openai_request_translation(harness):
    schema = {
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    }
    await harness.chat(
        _payload(PRO, output_schema={"name": "weather", "schema": schema})
    )
    body = (await harness.mock_state())["last_request"]["body"]
    assert isinstance(body["input"], list)
    assert body["input"][0]["content"][0]["type"] == "input_text"
    assert body["text"]["format"]["type"] == "json_schema"
    assert body["text"]["format"]["name"] == "weather"
    assert body["text"]["format"]["schema"] == schema
    assert "messages" not in body


async def test_case2_anthropic_request_translation(make_harness, monkeypatch):
    monkeypatch.setenv("TEST_LLM_KEY", "secret-token")
    built = await make_harness(api_key_env="TEST_LLM_KEY")
    await built.chat(
        _payload(
            FLASH,
            output_schema={
                "name": "weather",
                "schema": {
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                    "required": ["city"],
                },
            },
        )
    )
    last = (await built.mock_state())["last_request"]
    body = last["body"]
    assert "system" not in body or body["system"]
    assert body["messages"] == [{"role": "user", "content": "你好"}]
    assert body["tools"][0]["name"] == "weather"
    assert body["tool_choice"] == {"type": "tool", "name": "weather"}
    assert last["headers"]["x-api-key"] == "secret-token"
    assert last["headers"]["anthropic-version"] == "2023-06-01"


async def test_case3_openai_reasoning_block_is_stripped(harness):
    response = await harness.chat(_payload(PRO))
    data = response.json()
    assert data["content"] == "Hello from mock responses"
    assert data["reasoning_content"] == "mock reasoning"
    assert data["finish_reason"] == "stop"


async def test_case3_anthropic_content_array_extracted(harness):
    response = await harness.chat(_payload(FLASH))
    data = response.json()
    assert data["content"] == "Hello from mock messages"
    assert data["finish_reason"] == "stop"


async def test_case2_no_auth_header_without_api_key(harness):
    """没有配置密钥时不能发出空的 Authorization（h11 会拒绝带尾随空格的值）。"""
    await harness.chat(_payload(PRO))
    headers = (await harness.mock_state())["last_request"]["headers"]
    assert "authorization" not in headers

    await harness.chat(_payload(FLASH))
    headers = (await harness.mock_state())["last_request"]["headers"]
    assert "x-api-key" not in headers
    assert headers["anthropic-version"] == "2023-06-01"


def test_case4_provider_layer_has_no_model_concepts():
    root = pathlib.Path(__file__).resolve().parent.parent
    for path in (root / "providers").glob("*.py"):
        source = path.read_text(encoding="utf-8")
        assert "alias" not in source, f"{path.name} 引入了模型层概念 alias"
        assert "max_input_tokens" not in source, f"{path.name} 引入了模型层概念 max_input_tokens"
        assert "default_max_tokens" not in source, f"{path.name} 引入了模型层概念 default_max_tokens"


# --- 契约层（DESIGN v2.0 的四条硬性保证） ---------------------------------


async def test_contract_unknown_field_is_rejected(harness):
    """未知字段一律 400，且**不触达上游**。

    旧契约下 pydantic 默认 extra="ignore"，`tools` / `top_p` 会被静默丢弃——
    调用方以为参数生效了，其实根本没有。
    """
    response = await harness.chat(_payload(PRO, tools=[{"type": "function"}]))

    assert response.status_code == 400
    error = response.json()["error"]
    assert error["code"] == "GW_INVALID_REQUEST"
    assert error["type"] == "invalid_request"
    assert await harness.upstream_calls() == 0, "契约违规的请求不应触达上游"


async def test_contract_legacy_response_format_is_rejected(harness):
    """旧契约的 `response_format` 已彻底下线，不是兼容别名。"""
    response = await harness.chat(
        _payload(PRO, response_format={"type": "json_object"})
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"


async def test_contract_response_id_and_model_are_gateway_owned(harness):
    """响应里的 id / model 是网关自己的，不泄漏上游厂商值。"""
    response = await harness.chat(_payload(PRO))
    data = response.json()

    assert data["id"].startswith("lgw-")
    assert data["model"] == PRO
    assert data["id"] != "resp_mock", "上游 id 泄漏了"
    assert data["id"] != "msg_mock", "上游 id 泄漏了"

    # 上游 id 只落调用记录，不进线上契约。
    records = await harness.records()
    assert records[0]["upstream_response_id"] == "resp_mock"


async def test_contract_finish_reason_is_neutral(harness):
    """`finish_reason` 只有 stop / length / error 三档，不漏出 tool_calls。"""
    response = await harness.chat(
        _payload(
            FLASH,
            output_schema={
                "name": "r",
                "schema": {"type": "object", "properties": {"a": {"type": "string"}}},
            },
        )
    )
    data = response.json()
    assert data["finish_reason"] in {"stop", "length", "error"}
    assert data["finish_reason"] != "tool_calls"


async def test_contract_capability_unsupported_is_rejected(harness):
    """能力不足 → 400 GW_CAPABILITY_UNSUPPORTED，且不消耗限流配额。

    契约要求「做不到的组合显式拒绝」，而不是先扣配额再失败。
    """
    adapter = harness.app.state.gateway.adapters[PRO]
    adapter.supports_output_schema = False

    response = await harness.chat(
        _payload(
            PRO,
            output_schema={
                "name": "r",
                "schema": {"type": "object", "properties": {"a": {"type": "string"}}},
            },
        )
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_CAPABILITY_UNSUPPORTED"
    assert response.json()["error"]["type"] == "capability"
    assert await harness.upstream_calls() == 0

    metrics = await harness.metrics()
    assert metrics["overall"]["rate_limit_rejected"] == 0

    # 配额没被扣掉：下一次正常请求仍然成功。
    assert (await harness.chat(_payload(PRO))).status_code == 200


async def test_contract_each_model_sends_its_own_output_cap(harness):
    """两个模型各自的默认输出上限都恒定下发给上游。

    旧实现里 OpenAI 侧「请求未指定就不发 max_output_tokens」，导致同一份请求
    在两个模型上的实际输出上限不同，而调用方看不出来。
    """
    await harness.chat(_payload(PRO))
    body = (await harness.mock_state())["last_request"]["body"]
    assert body["max_output_tokens"] == 4096

    await harness.chat(_payload(FLASH))
    body = (await harness.mock_state())["last_request"]["body"]
    assert body["max_tokens"] == 2048


async def test_contract_sampling_knobs_and_output_cap_are_rejected(harness):
    """采样旋钮与输出上限不暴露给调用方，传入即 400。

    输出上限是网关按模型能力决定的策略（pro 4096 / flash 2048），
    调用方只能通过 `GET /v1/models` 的 `capabilities.max_output_tokens` 查。
    """
    for field, value in (
        ("max_output_tokens", 512),
        ("temperature", 0.7),
        ("top_p", 0.9),
        ("stop", ["x"]),
        ("seed", 7),
        ("n", 2),
    ):
        response = await harness.chat(_payload(PRO, **{field: value}))
        assert response.status_code == 400, f"{field} 应当被拒绝"
        assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"

    assert await harness.upstream_calls() == 0, "契约违规的请求不应触达上游"


async def test_contract_message_content_length_is_capped(harness):
    """单条消息内容超过 20000 字符 → 400，且不触达上游。

    这是入参侧的硬校验：超长请求在解析阶段就被拒，不消耗配额、不发上游连接。
    """
    over = _payload(PRO, messages=[{"role": "user", "content": "x" * 20_001}])
    response = await harness.chat(over)

    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"
    assert await harness.upstream_calls() == 0, "超长请求不应触达上游"

    # 恰好 20000 字符放行。
    edge = _payload(PRO, messages=[{"role": "user", "content": "x" * 20_000}])
    assert (await harness.chat(edge)).status_code == 200


async def test_contract_message_role_is_restricted(harness):
    """role 只接受 system / user / assistant，其它值 400。"""
    for role in ("system", "user", "assistant"):
        response = await harness.chat(_payload(PRO, messages=[{"role": role, "content": "hi"}]))
        assert response.status_code == 200

    response = await harness.chat(_payload(PRO, messages=[{"role": "tool", "content": "hi"}]))
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"


async def test_contract_metadata_is_recorded(harness):
    await harness.chat(_payload(PRO, metadata={"trace_id": "t-1", "tenant": "acme"}))
    records = await harness.records()
    assert records[0]["metadata"] == {"trace_id": "t-1", "tenant": "acme"}


async def test_contract_models_endpoint_declares_capabilities(harness):
    response = await harness.client.get("/v1/models")
    assert response.status_code == 200

    payload = response.json()
    assert "models" in payload
    assert "data" not in payload, "外壳不应再沿用 OpenAI 的 list 形状"

    by_id = {item["id"]: item for item in payload["models"]}
    pro = by_id[PRO]["capabilities"]
    assert pro["streaming"] is True
    assert pro["output_schema"] is True
    assert pro["output_schema_strict"] is True
    assert pro["max_output_tokens"] == 4096

    flash = by_id[FLASH]["capabilities"]
    assert flash["output_schema_strict"] is False, "tool_use 只是建议，不是硬约束"
    assert flash["max_output_tokens"] == 2048
