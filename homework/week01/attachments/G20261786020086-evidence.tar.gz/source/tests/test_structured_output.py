"""用例 6、11、12：结构化输出、内容层重试、本地确定性修复。"""

from __future__ import annotations

import json

import pytest

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"

SCHEMA = {
    "type": "object",
    "properties": {"city": {"type": "string"}, "temperature": {"type": "number"}},
    "required": ["city", "temperature"],
    "additionalProperties": False,
}


def _payload(model: str, **extra):
    return {
        "model": model,
        "messages": [{"role": "user", "content": "北京天气"}],
        "output_schema": {"name": "weather", "schema": SCHEMA},
        **extra,
    }


async def test_case6_pro_returns_schema_valid_json(harness):
    response = await harness.chat(_payload(PRO))
    assert response.status_code == 200
    content = response.json()["content"]
    parsed = json.loads(content)
    assert set(parsed) == {"city", "temperature"}


async def test_case6_flash_returns_schema_valid_json(harness):
    response = await harness.chat(_payload(FLASH))
    assert response.status_code == 200
    content = response.json()["content"]
    parsed = json.loads(content)
    assert set(parsed) == {"city", "temperature"}


async def test_case6_flash_uses_tool_use(harness):
    await harness.chat(_payload(FLASH))
    body = (await harness.mock_state())["last_request"]["body"]
    assert body["tools"][0]["name"] == "weather"
    assert body["tool_choice"]["name"] == "weather"
    assert body["tools"][0]["input_schema"] == SCHEMA


async def test_case11_bad_json_triggers_content_retry(harness):
    await harness.control(content="bad_json", content_times=1)
    response = await harness.chat(_payload(PRO))
    assert response.status_code == 200

    assert await harness.upstream_calls() == 2
    records = await harness.records()
    attempts = records[0]["attempts"]
    assert attempts[0]["ok"] is False
    assert attempts[0]["error_code"] == "GW_INVALID_JSON"
    assert attempts[0]["prompt_strength"] == 0
    assert attempts[1]["ok"] is True
    assert attempts[1]["prompt_strength"] == 1


async def test_case11_strengthened_prompt_is_sent(harness):
    await harness.control(content="bad_json", content_times=1)
    await harness.chat(_payload(PRO))
    state = await harness.mock_state()
    second_input = state["requests"][1]["body"]["input"]
    system = [item for item in second_input if item["role"] == "system"]
    assert system, "第二次尝试没有加强提示"
    assert "JSON" in system[0]["content"][0]["text"]


async def test_case11_schema_violation_ends_with_schema_mismatch(harness):
    await harness.control(content="schema_violation")
    response = await harness.chat(_payload(PRO))
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "GW_SCHEMA_MISMATCH"

    records = await harness.records()
    assert records[0]["status"] == "error"
    assert records[0]["attempt_count"] == 3
    assert records[0]["attempts"][0]["error_code"] == "GW_SCHEMA_MISMATCH"


async def test_case12_markdown_json_is_repaired_locally(harness):
    await harness.control(content="markdown_json")
    response = await harness.chat(_payload(PRO))
    assert response.status_code == 200
    assert await harness.upstream_calls() == 1, "本地修复层不应触发重试"

    content = response.json()["content"]
    assert json.loads(content)  # 修复后是裸 JSON
    assert "```" not in content

    records = await harness.records()
    assert records[0]["attempt_count"] == 1
    assert records[0]["status"] == "success"


async def test_contract_strict_false_does_not_fail(harness):
    """strict=false：内容不符 schema 也不报错、不重试，原样返回。"""
    await harness.control(content="schema_violation")
    response = await harness.chat(_payload(PRO, output_schema={
        "name": "weather",
        "schema": SCHEMA,
        "strict": False,
    }))

    assert response.status_code == 200
    assert await harness.upstream_calls() == 1, "strict=false 不该触发内容层重试"
    assert json.loads(response.json()["content"]) == {"unexpected_field": True}


async def test_contract_output_schema_is_required_to_have_a_schema(harness):
    """schema 是必填的：只写 name 不写 schema → 400，不允许发出空 schema。"""
    response = await harness.chat(_payload(PRO, output_schema={"name": "weather"}))
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "GW_INVALID_REQUEST"
    assert await harness.upstream_calls() == 0
