"""用例 40-46：定价表与成本核算（契约 v2.8）。"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from core.config import Settings

pytestmark = pytest.mark.anyio

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"

# 单价：USD / 1M token。刻意让三档价格互不相同，才能区分算错档位。
INPUT_RATE = 1.0
OUTPUT_RATE = 2.0
CACHED_RATE = 0.1

KEY_A = "sk-price-a"
KEY_B = "sk-price-b"
KEY_OPS = "sk-price-ops"

ENV_A = "LGW_PRICE_KEY_A"
ENV_B = "LGW_PRICE_KEY_B"
ENV_OPS = "LGW_PRICE_KEY_OPS"


def _payload(model: str = PRO, **extra):
    return {"model": model, "messages": [{"role": "user", "content": "你好"}], **extra}


def _as(key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {key}"}


def _pricing() -> dict:
    return {"input": INPUT_RATE, "output": OUTPUT_RATE, "cached_input": CACHED_RATE}


def _expected_cost(usage: dict) -> float:
    """按 DESIGN §7.7.2 的公式算期望成本。"""
    usd = (
        usage["input_tokens"] * INPUT_RATE
        + usage["output_tokens"] * OUTPUT_RATE
        + usage.get("cache_read_tokens", 0) * CACHED_RATE
    ) / 1_000_000
    return round(usd, 6)


async def test_case40_cost_is_computed_from_usage(make_harness):
    """成本按公式算出，响应体与调用记录一致。"""
    harness = await make_harness(pricing={PRO: _pricing()})

    response = await harness.chat(_payload(PRO))
    assert response.status_code == 200

    body = response.json()
    assert body["cost_usd"] == _expected_cost(body["usage"])
    assert body["cost_usd"] > 0

    records = await harness.records()
    assert records[0]["cost_usd"] == body["cost_usd"]


async def test_case41_unpriced_model_is_null_not_zero(make_harness):
    """没配价目表的模型 → 成本是 null（未定价），不是 0。"""
    harness = await make_harness(pricing={PRO: _pricing()})

    response = await harness.chat(_payload(FLASH))
    assert response.status_code == 200
    assert response.json()["cost_usd"] is None

    records = await harness.records()
    assert records[0]["cost_usd"] is None

    metrics = await harness.metrics()
    assert metrics["overall"]["cost_usd"] == 0.0
    assert metrics["overall"]["unpriced_requests"] == 1


async def test_case42_cache_and_reasoning_are_priced_once(make_harness):
    """缓存命中按 cached_input 价；推理 token 不额外计（已含在 output 里）。"""
    harness = await make_harness(pricing={FLASH: _pricing()})
    await harness.control(cache_read=True)

    response = await harness.chat(_payload(FLASH))
    assert response.status_code == 200

    usage = response.json()["usage"]
    assert usage["cache_read_tokens"] > 0
    assert response.json()["cost_usd"] == _expected_cost(usage)


async def test_case42_reasoning_tokens_are_not_billed_twice(make_harness):
    """推理 token 不单独计价：成本只按 output_tokens 算一次。"""
    harness = await make_harness(pricing={PRO: _pricing()})

    response = await harness.chat(_payload(PRO))
    assert response.status_code == 200

    usage = response.json()["usage"]
    assert usage["reasoning_tokens"] > 0
    assert response.json()["cost_usd"] == _expected_cost(usage)


async def test_case43_retry_cost_covers_all_attempts(make_harness):
    """重试的成本按「所有尝试之和」计，不只是最后一次。"""
    harness = await make_harness(pricing={PRO: _pricing()})
    # 内容层重试：第一次返回坏 JSON（已经产生了真实 token 消耗），第二次成功。
    await harness.control(content="bad_json", content_times=1)

    response = await harness.chat(
        {
            "model": PRO,
            "messages": [{"role": "user", "content": "你好"}],
            "output_schema": {
                "name": "answer",
                "schema": {"type": "object", "properties": {"ok": {"type": "boolean"}}},
            },
        }
    )
    assert response.status_code == 200
    assert await harness.upstream_calls() == 2

    records = await harness.records()
    record = records[0]
    assert len(record["attempts"]) == 2

    attempts_usage = {
        "input_tokens": sum(a["usage"]["input_tokens"] for a in record["attempts"]),
        "output_tokens": sum(a["usage"]["output_tokens"] for a in record["attempts"]),
        "cache_read_tokens": 0,
    }
    assert record["cost_usd"] == _expected_cost(attempts_usage)
    # 全部尝试的成本严格大于「只算最后一次」的成本。
    last_only = _expected_cost(record["attempts"][-1]["usage"])
    assert record["cost_usd"] > last_only


async def test_case44_cost_is_grouped_by_caller(make_harness, monkeypatch):
    """指标按租户聚合成本；普通租户只看得到自己的。"""
    monkeypatch.setenv(ENV_A, KEY_A)
    monkeypatch.setenv(ENV_B, KEY_B)
    monkeypatch.setenv(ENV_OPS, KEY_OPS)

    harness = await make_harness(
        auth_enabled=True,
        auth_keys=[
            {"name": "team-a", "key_env": ENV_A},
            {"name": "team-b", "key_env": ENV_B},
            {"name": "ops", "key_env": ENV_OPS},
        ],
        tenants={"ops": {"admin": True}},
        pricing={PRO: _pricing()},
        auth_headers=_as(KEY_OPS),
    )

    await harness.chat(_payload(PRO), headers=_as(KEY_A))
    await harness.chat(_payload(PRO), headers=_as(KEY_B))

    admin_view = await harness.metrics(headers=_as(KEY_OPS))
    assert set(admin_view["by_caller"]) == {"team-a", "team-b"}
    assert admin_view["overall"]["cost_usd"] == round(
        admin_view["by_caller"]["team-a"]["cost_usd"]
        + admin_view["by_caller"]["team-b"]["cost_usd"],
        6,
    )

    own = await harness.metrics(headers=_as(KEY_A))
    assert set(own["by_caller"]) == {"team-a"}
    assert own["overall"]["cost_usd"] == admin_view["by_caller"]["team-a"]["cost_usd"]


async def test_case45_streaming_reports_cost(make_harness):
    """流式的 usage 事件带 cost_usd，与非流式同一公式。"""
    harness = await make_harness(pricing={PRO: _pricing()})

    text, _ = await harness.stream_chat(_payload(PRO, stream=True))
    events = harness.sse_payloads(text)
    usage_events = [event for event in events if event.get("type") == "usage"]
    assert len(usage_events) == 1

    event = usage_events[0]
    assert event["cost_usd"] == _expected_cost(event["usage"])
    assert event["cost_usd"] > 0


async def test_case46_negative_price_fails_fast():
    """价格为负 → 配置校验失败（启动失败），不是运行期算出一笔负成本。"""
    with pytest.raises(ValidationError):
        Settings.model_validate(
            {
                "storage": {"data_dir": "./storage"},
                "models": {
                    PRO: {
                        "base_url": "http://upstream.test",
                        "upstream_id": PRO,
                        "pricing": {"input": -1.0},
                    }
                },
            }
        )
