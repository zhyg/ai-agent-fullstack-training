"""上游端点池：按优先级挑端点，并维护每个端点的熔断状态（见 DESIGN §7.8）。

架构位置：网关的「上游选择层」，夹在编排层与协议适配层之间。编排层不关心
有几个端点、谁熔断了——它只问「给我一个能用的端点」。

对应的 Java 概念：`UpstreamPool` ≈ Resilience4j 的 `CircuitBreakerRegistry` +
一个「按优先级取下一个可用者」的查找表；纯内存、无锁（与限流器同样的假设：
单事件循环里这些状态切换不会被并发穿插）。

选择规则（DESIGN §7.8.2）：
1. 按配置顺序（优先级）遍历；
2. 跳过本次调用已经失败过的端点；
3. 跳过处于熔断（open）状态的端点。
"""

from __future__ import annotations

from core.config import CircuitBreakerConfig
from core.errors import GatewayError
from core.types import UpstreamEndpoint
from resilience.circuit_breaker import CircuitBreaker


class UpstreamPool:
    """某个模型的全部上游端点 + 每个端点的熔断器。"""

    def __init__(
        self,
        endpoints: list[UpstreamEndpoint],
        breaker_config: CircuitBreakerConfig | None = None,
    ) -> None:
        self._endpoints = list(endpoints)
        config = breaker_config or CircuitBreakerConfig()
        self._breakers = {
            endpoint.name: CircuitBreaker(config) for endpoint in self._endpoints
        }

    @property
    def endpoints(self) -> list[UpstreamEndpoint]:
        """端点清单（按优先级）。"""
        return list(self._endpoints)

    def pick(self, exclude: set[str] | frozenset[str] = frozenset()) -> UpstreamEndpoint | None:
        """挑一个可用的端点；全都不可用时返回 None。

        `exclude` 是本次调用已经失败过的端点名——同一个逻辑调用不重复打同一个
        坏端点（DESIGN §7.8.2 规则 2）。
        """
        for endpoint in self._endpoints:
            if endpoint.name in exclude:
                continue
            if self._breakers[endpoint.name].acquire():
                return endpoint
        return None

    def report_success(self, endpoint: UpstreamEndpoint) -> None:
        """这次调用在该端点上成功了。"""
        self._breakers[endpoint.name].report_success()

    def report_failure(self, endpoint: UpstreamEndpoint, exc: GatewayError) -> None:
        """这次调用在该端点上失败了（是否计入熔断由熔断器自己判断）。"""
        self._breakers[endpoint.name].report_failure(exc)

    def release(self, endpoint: UpstreamEndpoint) -> None:
        """归还试探名额但不计失败（客户端断开导致的上游取消）。"""
        self._breakers[endpoint.name].release()
