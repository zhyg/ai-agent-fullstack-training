"""内置 Mock 上游：严格按三种协议的真实交互形态实现，支持故障注入。

故障注入有两种入口：
1. 请求头（手工 curl 调试用）：X-Mock-Fail / X-Mock-Fail-Times / X-Mock-Content / ...
2. 控制端点（自动化测试用）：POST /_mock/_control

在整体架构中的位置：它是「假的上游厂商」，让网关在没有真实 API Key 的情况下也能跑通
端到端链路，并精确复现各类故障（401 / 429 / 500 / 超时 / 坏 JSON / 流中断）。

对应的 Java 概念：
- `APIRouter` ≈ Spring MVC 的 `@RestController` + `@RequestMapping` 前缀路由集合。
- `@router.post("/...")` ≈ `@PostMapping`；`Header(default=None)` ≈ `@RequestHeader(required=false)`。
- `async def` / `await` ≈ 协程，但跑在单线程事件循环上，不是 `CompletableFuture` 那种多线程。
- `StreamingResponse` ≈ 直接往响应流里写 chunk（`StreamingResponseBody`）。
- 模块级全局变量 ≈ Spring 的静态字段/单例 bean 里的共享状态（测试之间靠 reset 隔离）。
"""

from __future__ import annotations

import asyncio
import json
from collections import defaultdict
from typing import Any, AsyncIterator

from fastapi import APIRouter, Header, Request
from fastapi.responses import JSONResponse, StreamingResponse

_FAIL_MODES = {"400", "401", "429", "500", "503", "timeout", "malformed", "stream_error"}
_CONTENT_MODES = {"markdown_json", "bad_json", "schema_violation"}

# 下面三个是模块级共享状态（≈ 单例 bean 的可变字段），测试之间靠 reset_mock_state() 隔离。
# _state 记录每个「协议:模型」已调用次数，用于 fail_times / content_times 这类「前 N 次才故障」的注入。
_state: dict[str, int] = defaultdict(int)
# 每个「协议:模型」已产出的流式分片数。用来观察「上游被中途掐断」——
# 正常跑完的流会产满全部分片，被取消的流会明显偏少。
_chunks: dict[str, int] = defaultdict(int)
_last_request: dict[str, Any] = {}
_request_log: list[dict[str, Any]] = []

_control: dict[str, Any] = {
    "fail": None,
    "fail_times": None,
    "fail_by_model": {},
    "content": None,
    "content_times": None,
    "delay": 0.0,
    "chunk_delay": 0.0,
    "break_after": None,
    "cache_read": False,
}


def reset_mock_state() -> None:
    """把所有共享状态与故障开关恢复默认值（≈ 测试的 `@BeforeEach` 清理）。

    异常：不抛异常。
    """
    _state.clear()
    _chunks.clear()
    _last_request.clear()
    _request_log.clear()
    _control.update(
        {
            "fail": None,
            "fail_times": None,
            "fail_by_model": {},
            "content": None,
            "content_times": None,
            "delay": 0.0,
            "chunk_delay": 0.0,
            "break_after": None,
            "cache_read": False,
        }
    )


def _sample_from_schema(schema: Any) -> Any:
    """从 JSON Schema 生成一个最小合法实例（仅覆盖常见类型）。

    只处理 object / string / integer / number / boolean / array / null，
    够用来构造「符合 schema 的合法响应」，不追求通用 JSON Schema 实现。

    非必填字段直接不生成（模拟真实模型只填必填项）。
    异常：不抛异常，遇到不认识的结构返回 `None` 或 `{}`。
    """
    if not isinstance(schema, dict):
        return {}
    if "properties" in schema or schema.get("type") == "object":
        properties = schema.get("properties") or {}
        required = schema.get("required")
        instance: dict[str, Any] = {}
        for name, sub in properties.items():
            if required is not None and name not in required:
                continue
            instance[name] = _sample_from_schema(sub)
        return instance
    schema_type = schema.get("type")
    if schema_type == "string":
        return "mock"
    if schema_type == "integer":
        return 0
    if schema_type == "number":
        return 0.0
    if schema_type == "boolean":
        return True
    if schema_type == "array":
        return []
    if schema_type == "null":
        return None
    return None


_SCHEMA_MARKER = "输出必须严格符合以下 schema："


def _schema_from_messages(messages: Any) -> dict[str, Any] | None:
    """从 system 提示词里抠出 JSON Schema。

    `prompt_only` 模式下上游收不到 `response_format`，schema 只存在于提示词里
    （见 DESIGN §5.2.3），mock 得能据此生成合规内容——模拟「模型读懂了提示词」。

    异常：不抛异常；提示词里没有可解析的 schema 时返回 None。
    """
    if not isinstance(messages, list):
        return None
    for message in messages:
        if not isinstance(message, dict) or message.get("role") != "system":
            continue
        content = message.get("content")
        if not isinstance(content, str) or _SCHEMA_MARKER not in content:
            continue
        try:
            schema = json.loads(content.split(_SCHEMA_MARKER, 1)[1].strip())
        except (ValueError, TypeError):
            continue
        if isinstance(schema, dict):
            return schema
    return None


def _apply_content_mode(mode: str | None, payload: Any) -> str:
    """按注入模式把 payload 变成最终的文本内容。

    三种模式分别模拟：
    - `markdown_json`：模型把 JSON 包在 ```json 代码块里（需要网关剥壳）。
    - `bad_json`：完全不是 JSON（需要网关报内容层错误）。
    - `schema_violation`：是合法 JSON 但不符合 schema（需要网关报 schema 不匹配）。

    异常：不抛异常。
    """
    if mode == "markdown_json":
        return f"```json\n{json.dumps(payload, ensure_ascii=False)}\n```"
    if mode == "bad_json":
        return "这不是 JSON"
    if mode == "schema_violation":
        return json.dumps({"unexpected_field": True}, ensure_ascii=False)
    return json.dumps(payload, ensure_ascii=False)


def _estimate_tokens(text: str) -> int:
    """粗略估算 token 数（≈ 4 个字符 1 token）。

    Mock 用，不需要真实分词器；`max(1, ...)` 保证空文本也算 1 个 token。
    """
    return max(1, len(text) // 4)


def _sse(event: str | None, data: dict) -> str:
    """拼一帧 SSE 文本：可选的 `event:` 行 + `data:` 行 + 空行结尾。

    `ensure_ascii=False` 让中文以原字符输出，便于调试时肉眼比对。
    """
    prefix = f"event: {event}\n" if event else ""
    return f"{prefix}data: {json.dumps(data, ensure_ascii=False)}\n\n"


class _Behavior:
    """一次请求最终生效的故障行为。

    把「请求头注入」与「控制端点注入」归一化后的结果，
    让下游处理逻辑不必关心故障是「这次请求带的」还是「全局设的」。
    """

    def __init__(
        self,
        attempt: int,
        fail: str | None,
        content: str | None,
        delay: float,
        chunk_delay: float,
        break_after: int | None,
    ) -> None:
        self.attempt = attempt
        self.fail = fail
        self.content = content
        self.delay = delay
        self.chunk_delay = chunk_delay
        self.break_after = break_after


def _resolve_behavior(
    protocol: str,
    model: str,
    header_fail: str | None,
    header_fail_times: str | None,
    header_content: str | None,
    header_content_times: str | None,
    header_delay: str | None,
    header_break: str | None,
    header_chunk_delay: str | None = None,
) -> _Behavior:
    """归一化本次请求的故障行为。

    优先级：请求头 > 全局控制开关。请求头里带了非法模式值时视为「没带」，
    回退到全局配置（而不是报错），方便手工 curl 试错。

    `fail_times` / `content_times` 语义：前 N 次生效，第 N+1 次自动恢复正常，
    用于测试「网关重试后成功」的场景。

    异常：不抛异常。
    """
    key = f"{protocol}:{model}"
    _state[key] += 1
    attempt = _state[key]

    # 故障来源的优先级：请求头 > 按模型（fail_by_model）> 全局开关。
    # fail_by_model 让不同的上游端点独立地失败（网关下发的 upstream_id 不同，
    # 请求体里的 model 也就不同），这样「主端点坏、备端点好」才能同时成立。
    if header_fail in _FAIL_MODES:
        fail = header_fail
    else:
        per_model = (_control["fail_by_model"] or {}).get(model)
        fail = per_model if per_model in _FAIL_MODES else _control["fail"]
    fail_times = (
        int(header_fail_times) if header_fail_times else _control["fail_times"]
    )
    content = (
        header_content if header_content in _CONTENT_MODES else _control["content"]
    )
    content_times = (
        int(header_content_times)
        if header_content_times
        else _control["content_times"]
    )
    delay = float(header_delay) if header_delay else float(_control["delay"])
    chunk_delay = (
        float(header_chunk_delay)
        if header_chunk_delay
        else float(_control["chunk_delay"])
    )
    break_after = (
        int(header_break) if header_break else _control["break_after"]
    )

    if fail and fail != "timeout" and fail_times is not None and attempt > fail_times:
        fail = None
    if content and content_times is not None and attempt > content_times:
        content = None

    return _Behavior(attempt, fail, content, delay, chunk_delay, break_after)


def _failure_response(mode: str) -> JSONResponse:
    """按模式构造故障响应。

    注意 `malformed` 故意返回 **200 + 非法 JSON**：
    它模拟的不是「请求失败」，而是「请求成功但上游给了坏内容」，
    用于验证网关把这类问题归到内容层错误而不是传输层错误。

    异常：不抛异常。
    """
    if mode == "400":
        return JSONResponse(
            status_code=400,
            content={"error": {"type": "invalid_request_error", "message": "mock 400"}},
        )
    if mode == "401":
        return JSONResponse(
            status_code=401,
            content={"error": {"type": "authentication_error", "message": "mock 401"}},
        )
    if mode == "429":
        return JSONResponse(
            status_code=429,
            content={"error": {"type": "rate_limit_error", "message": "mock upstream 429"}},
            headers={"Retry-After": "1"},
        )
    if mode == "500":
        return JSONResponse(
            status_code=500, content={"error": {"type": "api_error", "message": "mock 500"}}
        )
    if mode == "503":
        return JSONResponse(
            status_code=503,
            content={"error": {"type": "overloaded_error", "message": "mock 503"}},
        )
    if mode == "malformed":
        return JSONResponse(
            status_code=200,
            content="{ this is not valid json",
            media_type="application/json",
        )
    return JSONResponse(status_code=500, content={"error": {"message": "mock failure"}})


def _split_text(text: str, size: int = 8) -> list[str]:
    """把长文本切成固定大小的片段，用于模拟流式增量。

    末尾的 `or [""]` 保证空文本也产出至少一个片段，
    这样流里至少会有一次 delta 事件，形态更接近真实上游。

    异常：不抛异常。
    """
    return [text[i : i + size] for i in range(0, len(text), size)] or [""]


async def _paced(
    frames: AsyncIterator[str], key: str, chunk_delay: float
) -> AsyncIterator[str]:
    """给上游流套一层「计数 + 限速」。

    - 计数：每产出一帧记一次。正常跑完的流会产满全部分片，
      被网关中途掐断的流会明显偏少——这是观察「上游确实被取消了」的凭据。
    - 限速：每帧之间停顿 `chunk_delay` 秒，好让测试能在流中途断开客户端
      （否则 mock 会瞬间跑完，根本没有「中途」可言）。
    """
    async for frame in frames:
        _chunks[key] += 1
        yield frame
        if chunk_delay:
            await asyncio.sleep(chunk_delay)


def _control_state() -> dict[str, Any]:
    """返回当前 mock 状态快照（开关 + 各模型调用次数 + 请求日志）。

    异常：不抛异常。
    """
    return {
        "control": dict(_control),
        "calls": dict(_state),
        "chunks": dict(_chunks),
        "last_request": _last_request,
        "requests": list(_request_log),
    }


def create_mock_router() -> APIRouter:
    """构造并返回 mock 上游的路由集合（≈ 一个 `@RestController` 类）。

    挂载前缀 `/_mock`，实际路径形如 `/_mock/openai/v1/responses`、
    `/_mock/anthropic/v1/messages`，与真实厂商的 `/v1/...` 保持一致，
    这样网关侧只需替换 base_url 就能切到 mock。

    异常：构造本身不抛异常；非法控制参数在请求时才抛 `ValueError`。
    """
    router = APIRouter(prefix="/_mock")

    # ---------- 控制端点（测试用） ----------

    @router.post("/_control")
    async def control(payload: dict):
        """设置故障注入开关（自动化测试入口）。

        可设字段：`fail` / `content` / `fail_times` / `content_times` /
        `fail_by_model` / `delay` / `break_after` / `cache_read`，
        以及 `reset: true` 表示清空所有状态。

        `fail_by_model` 是「模型名 → 故障模式」的映射，键是请求体里的 `model`
        （也就是网关下发的 upstream_id），用来让多个上游端点独立地失败。

        异常：`fail` / `content` / `fail_by_model` 的值传了未知模式时抛
        `ValueError`（≈ `IllegalArgumentException`）。
        """
        if payload.get("reset"):
            reset_mock_state()
            return _control_state()
        for key in ("fail", "content"):
            if key in payload:
                value = payload[key]
                if value is not None and value not in (
                    _FAIL_MODES if key == "fail" else _CONTENT_MODES
                ):
                    raise ValueError(f"unknown {key} mode: {value}")
                _control[key] = value
        if "fail_by_model" in payload:
            mapping = payload["fail_by_model"] or {}
            for model_name, mode in mapping.items():
                if mode is not None and mode not in _FAIL_MODES:
                    raise ValueError(f"unknown fail_by_model mode: {mode}")
            _control["fail_by_model"] = dict(mapping)
        for key in ("fail_times", "content_times", "break_after"):
            if key in payload:
                _control[key] = payload[key]
        if "delay" in payload:
            _control["delay"] = float(payload["delay"])
        if "chunk_delay" in payload:
            _control["chunk_delay"] = float(payload["chunk_delay"])
        if "cache_read" in payload:
            _control["cache_read"] = bool(payload["cache_read"])
        return _control_state()

    @router.get("/_control")
    async def control_state():
        """读取当前 mock 状态快照（只读）。

        异常：不抛异常。
        """
        return _control_state()

    # ---------- OpenAI Responses ----------

    @router.post("/openai/v1/responses")
    async def mock_responses(
        request: Request,
        x_mock_fail: str | None = Header(default=None),
        x_mock_fail_times: str | None = Header(default=None),
        x_mock_content: str | None = Header(default=None),
        x_mock_content_times: str | None = Header(default=None),
        x_mock_delay: str | None = Header(default=None),
        x_mock_break: str | None = Header(default=None),
        x_mock_chunk_delay: str | None = Header(default=None),
    ):
        """Mock 的 OpenAI Responses API 端点（≈ `@PostMapping("/openai/v1/responses")`）。

        请求头 `X-Mock-*` 用于单次请求级故障注入；无请求头时使用全局控制开关。

        响应形态严格对齐真实 OpenAI Responses API：非流式返回 `output[]` 块数组，
        流式返回 `response.created` / `response.output_text.delta` / `response.completed` 事件。

        异常：请求体不是合法 JSON 时由 FastAPI 抛 422；`break_after` 触发的流中断
        会在流生成器里抛 `RuntimeError`（模拟上游中途断开）。
        """
        body = await request.json()
        model = body.get("model", "unknown")
        _last_request.clear()
        _last_request.update(
            {
                "protocol": "openai",
                "path": request.url.path,
                "headers": dict(request.headers),
                "body": body,
            }
        )
        _request_log.append(
            {"protocol": "openai", "path": request.url.path, "body": body}
        )
        behavior = _resolve_behavior(
            "openai",
            model,
            x_mock_fail,
            x_mock_fail_times,
            x_mock_content,
            x_mock_content_times,
            x_mock_delay,
            x_mock_break,
            x_mock_chunk_delay,
        )

        if behavior.fail == "timeout":
            await asyncio.sleep(behavior.delay or 30)
        elif behavior.fail:
            return _failure_response(behavior.fail)

        if behavior.delay:
            await asyncio.sleep(behavior.delay)

        schema = ((body.get("text") or {}).get("format") or {}).get("schema")
        # 有 schema 才说明走的是 native 结构化输出，此时按 schema 生成合法内容。
        payload = _sample_from_schema(schema) if schema else {"ok": True}
        if schema:
            text = _apply_content_mode(behavior.content, payload)
        else:
            text = "Hello from mock responses"

        input_text = json.dumps(body.get("input", []), ensure_ascii=False)
        input_tokens = _estimate_tokens(input_text)
        output_tokens = _estimate_tokens(text)
        reasoning_tokens = 5 if schema is None else 0

        usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "output_tokens_details": {"reasoning_tokens": reasoning_tokens},
        }

        if body.get("stream"):
            async def gen() -> AsyncIterator[str]:
                """流式响应生成器（≈ `StreamingResponseBody`）。

                依次产出：created → 若干 output_text.delta → output_text.done → completed。
                `break_after` 用于在第 N 个增量后抛错，模拟上游中途断流。
                """
                yield _sse(
                    "response.created",
                    {"type": "response.created", "response": {"id": "resp_mock", "status": "in_progress"}},
                )
                # 推理摘要增量：让网关的 reasoning_delta 通路可测（真实上游也会先思考）。
                yield _sse(
                    "response.reasoning_summary_text.delta",
                    {
                        "type": "response.reasoning_summary_text.delta",
                        "delta": "mock reasoning",
                    },
                )
                emitted = 0
                for piece in _split_text(text):
                    if behavior.break_after is not None and emitted >= behavior.break_after:
                        raise RuntimeError("mock upstream aborted mid-stream")
                    yield _sse(
                        "response.output_text.delta",
                        {"type": "response.output_text.delta", "delta": piece},
                    )
                    emitted += 1
                yield _sse(
                    "response.output_text.done",
                    {"type": "response.output_text.done", "text": text},
                )
                yield _sse(
                    "response.completed",
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_mock",
                            "model": model,
                            "status": "completed",
                            "output": [
                                {
                                    "type": "message",
                                    "id": "msg_mock",
                                    "role": "assistant",
                                    "content": [{"type": "output_text", "text": text}],
                                }
                            ],
                            "usage": usage,
                        },
                    },
                )

            return StreamingResponse(
                _paced(gen(), f"openai:{model}", behavior.chunk_delay),
                media_type="text/event-stream",
            )

        return JSONResponse(
            {
                "id": "resp_mock",
                "object": "response",
                "model": model,
                "status": "completed",
                "output": [
                    {
                        "type": "reasoning",
                        "id": "rs_mock",
                        "summary": [{"type": "summary_text", "text": "mock reasoning"}],
                    },
                    {
                        "type": "message",
                        "id": "msg_mock",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": text}],
                    },
                ],
                "usage": usage,
            }
        )

    # ---------- Anthropic Messages ----------

    @router.post("/anthropic/v1/messages")
    async def mock_messages(
        request: Request,
        x_mock_fail: str | None = Header(default=None),
        x_mock_fail_times: str | None = Header(default=None),
        x_mock_content: str | None = Header(default=None),
        x_mock_content_times: str | None = Header(default=None),
        x_mock_delay: str | None = Header(default=None),
        x_mock_break: str | None = Header(default=None),
        x_mock_chunk_delay: str | None = Header(default=None),
    ):
        """Mock 的 Anthropic Messages API 端点（≈ `@PostMapping("/anthropic/v1/messages")`）。

        请求头 `X-Mock-*` 用于单次请求级故障注入；无请求头时使用全局控制开关。

        响应形态严格对齐真实 Anthropic Messages API：非流式返回 `content[]` 块数组
        （`text` 或 `tool_use`）+ 顶层 `system`；流式返回
        `message_start` / `content_block_start` / `content_block_delta` / `message_delta` / `message_stop`。

        异常：请求体不是合法 JSON 时由 FastAPI 抛 422；`break_after` 触发的流中断
        会在流生成器里抛 `RuntimeError`。
        """
        body = await request.json()
        model = body.get("model", "unknown")
        _last_request.clear()
        _last_request.update(
            {
                "protocol": "anthropic",
                "path": request.url.path,
                "headers": dict(request.headers),
                "body": body,
            }
        )
        _request_log.append(
            {"protocol": "anthropic", "path": request.url.path, "body": body}
        )
        behavior = _resolve_behavior(
            "anthropic",
            model,
            x_mock_fail,
            x_mock_fail_times,
            x_mock_content,
            x_mock_content_times,
            x_mock_delay,
            x_mock_break,
            x_mock_chunk_delay,
        )

        if behavior.fail == "timeout":
            await asyncio.sleep(behavior.delay or 30)
        elif behavior.fail:
            return _failure_response(behavior.fail)

        if behavior.delay:
            await asyncio.sleep(behavior.delay)

        tools = body.get("tools") or []
        tool_name = tools[0]["name"] if tools else None
        tool_schema = tools[0].get("input_schema") if tools else None
        content_broken = behavior.content is not None

        # 有 tools 说明走 tool_use 结构化输出：工具入参就是最终的结构化结果。
        if tool_name and not content_broken:
            payload = _sample_from_schema(tool_schema)
            raw_text = json.dumps(payload, ensure_ascii=False)
        elif content_broken:
            payload = _sample_from_schema(tool_schema) if tool_schema else {"ok": True}
            raw_text = _apply_content_mode(behavior.content, payload)
        else:
            payload = None
            raw_text = "Hello from mock messages"

        messages_text = json.dumps(body.get("messages", []), ensure_ascii=False)
        system_text = body.get("system") or ""
        if isinstance(system_text, list):
            system_text = json.dumps(system_text, ensure_ascii=False)
        input_tokens = _estimate_tokens(messages_text) + _estimate_tokens(str(system_text))
        output_tokens = _estimate_tokens(raw_text)

        system_blocks = body.get("system")
        cache_write = 0
        cache_read = 0
        if isinstance(system_blocks, list):
            for block in system_blocks:
                if isinstance(block, dict) and block.get("cache_control"):
                    cache_write = _estimate_tokens(str(block.get("text", "")))
        if _control["cache_read"]:
            cache_read = input_tokens
        usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_creation_input_tokens": cache_write,
            "cache_read_input_tokens": cache_read,
        }

        if body.get("stream"):
            async def gen() -> AsyncIterator[str]:
                """流式响应生成器（≈ `StreamingResponseBody`）。

                依次产出：message_start → content_block_start → 若干 content_block_delta
                → content_block_stop → message_delta → message_stop。
                走工具模式时 delta 是 `input_json_delta`（JSON 片段），
                普通模式是 `text_delta`（正文片段）。
                """
                yield _sse(
                    "message_start",
                    {
                        "type": "message_start",
                        "message": {
                            "id": "msg_mock",
                            "type": "message",
                            "role": "assistant",
                            "model": model,
                            "content": [],
                            "usage": {**usage, "output_tokens": 0},
                        },
                    },
                )
                # 思维链块：thinking → thinking_delta → thinking_delta_stop。
                # 让网关的 reasoning_delta 通路可测（否则只有 Responses 侧能产出思维链）。
                yield _sse(
                    "content_block_start",
                    {
                        "type": "content_block_start",
                        "index": 0,
                        "content_block": {"type": "thinking", "thinking": ""},
                    },
                )
                yield _sse(
                    "content_block_delta",
                    {
                        "type": "content_block_delta",
                        "index": 0,
                        "delta": {"type": "thinking_delta", "thinking": "mock thinking"},
                    },
                )
                yield _sse(
                    "content_block_delta",
                    {
                        "type": "content_block_delta",
                        "index": 0,
                        "delta": {"type": "thinking_delta", "thinking": " done"},
                    },
                )
                yield _sse("content_block_stop", {"type": "content_block_stop", "index": 0})
                emitted = 0
                if tool_name and not content_broken:
                    yield _sse(
                        "content_block_start",
                        {
                            "type": "content_block_start",
                            "index": 0,
                            "content_block": {
                                "type": "tool_use",
                                "id": "toolu_mock",
                                "name": tool_name,
                                "input": {},
                            },
                        },
                    )
                    for piece in _split_text(raw_text):
                        if behavior.break_after is not None and emitted >= behavior.break_after:
                            raise RuntimeError("mock upstream aborted mid-stream")
                        yield _sse(
                            "content_block_delta",
                            {
                                "type": "content_block_delta",
                                "index": 0,
                                "delta": {"type": "input_json_delta", "partial_json": piece},
                            },
                        )
                        emitted += 1
                else:
                    yield _sse(
                        "content_block_start",
                        {
                            "type": "content_block_start",
                            "index": 0,
                            "content_block": {"type": "text", "text": ""},
                        },
                    )
                    for piece in _split_text(raw_text):
                        if behavior.break_after is not None and emitted >= behavior.break_after:
                            raise RuntimeError("mock upstream aborted mid-stream")
                        yield _sse(
                            "content_block_delta",
                            {
                                "type": "content_block_delta",
                                "index": 0,
                                "delta": {"type": "text_delta", "text": piece},
                            },
                        )
                        emitted += 1
                yield _sse("content_block_stop", {"type": "content_block_stop", "index": 0})
                yield _sse(
                    "message_delta",
                    {
                        "type": "message_delta",
                        "delta": {"stop_reason": "tool_use" if tool_name else "end_turn"},
                        "usage": {"output_tokens": output_tokens},
                    },
                )
                yield _sse("message_stop", {"type": "message_stop"})

            return StreamingResponse(
                _paced(gen(), f"anthropic:{model}", behavior.chunk_delay),
                media_type="text/event-stream",
            )

        # 非流式也带一个 thinking 块：让两条协议的 reasoning_content 都能产出。
        thinking_block = {"type": "thinking", "thinking": "mock thinking"}
        if tool_name and not content_broken:
            content = [
                thinking_block,
                {"type": "tool_use", "id": "toolu_mock", "name": tool_name, "input": payload},
            ]
            stop_reason = "tool_use"
        else:
            content = [thinking_block, {"type": "text", "text": raw_text}]
            stop_reason = "end_turn"

        return JSONResponse(
            {
                "id": "msg_mock",
                "type": "message",
                "role": "assistant",
                "model": model,
                "content": content,
                "stop_reason": stop_reason,
                "usage": usage,
            }
        )

    # ---------- OpenAI Chat Completions ----------

    @router.post("/openai-chat/v1/chat/completions")
    async def mock_chat_completions(
        request: Request,
        x_mock_fail: str | None = Header(default=None),
        x_mock_fail_times: str | None = Header(default=None),
        x_mock_content: str | None = Header(default=None),
        x_mock_content_times: str | None = Header(default=None),
        x_mock_delay: str | None = Header(default=None),
        x_mock_break: str | None = Header(default=None),
        x_mock_chunk_delay: str | None = Header(default=None),
    ):
        """Mock 的 OpenAI Chat Completions 端点（≈ `@PostMapping("/openai-chat/v1/chat/completions")`）。

        响应形态严格对齐真实 Chat Completions API：非流式返回
        `choices[0].message`（含 `content` 与 `reasoning_content`）+ `usage`；
        流式返回 `choices[0].delta` 增量帧，收尾帧带 `finish_reason`，
        用量单独放在一个 `choices: []` 的空帧里（真实上游要 `stream_options.include_usage`
        才会给），**不发** `[DONE]` 哨兵。

        异常：请求体不是合法 JSON 时由 FastAPI 抛 422；`break_after` 触发的流中断
        会在流生成器里抛 `RuntimeError`（模拟上游中途断开）。
        """
        body = await request.json()
        model = body.get("model", "unknown")
        _last_request.clear()
        _last_request.update(
            {
                "protocol": "openai-chat",
                "path": request.url.path,
                "headers": dict(request.headers),
                "body": body,
            }
        )
        _request_log.append(
            {"protocol": "openai-chat", "path": request.url.path, "body": body}
        )
        behavior = _resolve_behavior(
            "openai-chat",
            model,
            x_mock_fail,
            x_mock_fail_times,
            x_mock_content,
            x_mock_content_times,
            x_mock_delay,
            x_mock_break,
            x_mock_chunk_delay,
        )

        if behavior.fail == "timeout":
            await asyncio.sleep(behavior.delay or 30)
        elif behavior.fail and behavior.fail != "stream_error":
            return _failure_response(behavior.fail)

        if behavior.delay:
            await asyncio.sleep(behavior.delay)

        schema = ((body.get("response_format") or {}).get("json_schema") or {}).get("schema")
        if schema is None:
            # prompt_only：schema 只在提示词里，上游照样得读懂它。
            schema = _schema_from_messages(body.get("messages"))
        content_broken = behavior.content is not None
        if schema and not content_broken:
            payload = _sample_from_schema(schema)
            raw_text = json.dumps(payload, ensure_ascii=False)
        elif content_broken:
            payload = _sample_from_schema(schema) if schema else {"ok": True}
            raw_text = _apply_content_mode(behavior.content, payload)
        else:
            raw_text = "Hello from mock chat completions"

        messages_text = json.dumps(body.get("messages", []), ensure_ascii=False)
        input_tokens = _estimate_tokens(messages_text)
        output_tokens = _estimate_tokens(raw_text)
        reasoning_tokens = 5 if schema is None else 0
        cache_read = input_tokens if _control["cache_read"] else 0

        usage = {
            "prompt_tokens": input_tokens,
            "completion_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "completion_tokens_details": {"reasoning_tokens": reasoning_tokens},
            "prompt_tokens_details": {"cached_tokens": cache_read},
        }

        if body.get("stream"):
            async def gen() -> AsyncIterator[str]:
                """流式响应生成器（≈ `StreamingResponseBody`）。

                依次产出：思维链增量帧 → 若干正文增量帧 → 收尾帧（带 finish_reason）
                → 用量帧（`choices` 为空）。`break_after` 用于在第 N 个增量后抛错，
                模拟上游中途断流。

                `stream_error` 故障模式：只吐一个错误帧就结束——模拟「上游在流中途
                报错」，用来验证网关不会把这种帧静默吞掉（见 DESIGN §4.5.3）。
                """
                if behavior.fail == "stream_error":
                    yield _sse(
                        None,
                        {
                            "type": "error",
                            "error": {"message": "mock upstream error mid-stream"},
                        },
                    )
                    return
                yield _sse(
                    None,
                    {
                        "id": "chatcmpl_mock",
                        "object": "chat.completion.chunk",
                        "model": model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {"role": "assistant", "reasoning_content": "mock reasoning"},
                                "finish_reason": None,
                            }
                        ],
                    },
                )
                emitted = 0
                for piece in _split_text(raw_text):
                    if behavior.break_after is not None and emitted >= behavior.break_after:
                        raise RuntimeError("mock upstream aborted mid-stream")
                    yield _sse(
                        None,
                        {
                            "id": "chatcmpl_mock",
                            "object": "chat.completion.chunk",
                            "model": model,
                            "choices": [
                                {
                                    "index": 0,
                                    "delta": {"content": piece},
                                    "finish_reason": None,
                                }
                            ],
                        },
                    )
                    emitted += 1
                yield _sse(
                    None,
                    {
                        "id": "chatcmpl_mock",
                        "object": "chat.completion.chunk",
                        "model": model,
                        "choices": [
                            {"index": 0, "delta": {}, "finish_reason": "stop"}
                        ],
                    },
                )
                # 用量单独一帧，且 choices 为空（与真实上游一致）。
                if (body.get("stream_options") or {}).get("include_usage"):
                    yield _sse(
                        None,
                        {
                            "id": "chatcmpl_mock",
                            "object": "chat.completion.chunk",
                            "model": model,
                            "choices": [],
                            "usage": usage,
                        },
                    )

            return StreamingResponse(
                _paced(gen(), f"openai-chat:{model}", behavior.chunk_delay),
                media_type="text/event-stream",
            )

        return JSONResponse(
            {
                "id": "chatcmpl_mock",
                "object": "chat.completion",
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": raw_text,
                            "reasoning_content": "mock reasoning" if schema is None else None,
                        },
                        "finish_reason": "stop",
                    }
                ],
                "usage": usage,
            }
        )

    return router
