"""出站 HTTP 客户端：负责把请求发到上游，并把上游状态码映射成统一错误码。

职责边界：
- 只做「传输」：发请求、读响应、切 SSE 帧。完全不认识模型，也不知道各厂商协议细节。
- 区分两类失败：
  1) 传输层失败（超时、连接断开）→ `UPSTREAM_TIMEOUT` / `UPSTREAM_ERROR`，可重试。
  2) 内容层失败（HTTP 200 但 body 不是 JSON）→ `MALFORMED_UPSTREAM`，
     属于「上游返回了坏东西」，与「请求根本没送到」是不同性质的问题。

对应的 Java 概念：
- `async def` / `await` ≈ 协程，但跑在单线程事件循环上，不是 `CompletableFuture` 那种多线程。
- `httpx.AsyncClient` ≈ OkHttp 的异步客户端 / Spring 的 `RestClient` 异步版。
- `raise ... from exc` ≈ Java 的「异常包装并保留 cause」。
- `AsyncIterator` ≈ `Stream<T>`，但只能在 `async for` 里消费。
"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator

import httpx

from core.errors import ErrorCode, GatewayError
from core.types import SSEChunk
from providers.base import UpstreamRequest


def _parse_retry_after(value: str | None) -> float | None:
    """解析 `Retry-After` 头，返回「建议等待多少秒」。

    HTTP 允许该头是两种形态：整数秒数，或 HTTP-date（绝对时间）。
    两种都试；都解析不了就返回 `None`（≈ `Optional.empty()`），表示不提供重试建议。

    异常：函数内部已吞掉所有解析异常，不会抛出。
    """
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        pass
    try:
        from email.utils import parsedate_to_datetime

        target = parsedate_to_datetime(value)
        import datetime as _dt

        now = _dt.datetime.now(_dt.timezone.utc)
        # HTTP-date 可能不带时区，此时按 UTC 解释，否则与 now 相减会抛 TypeError。
        if target.tzinfo is None:
            target = target.replace(tzinfo=_dt.timezone.utc)
        return max(0.0, (target - now).total_seconds())
    except Exception:
        # 任何解析异常都视为「没有重试建议」，不能因为一个响应头让整个请求失败。
        return None


def raise_for_upstream_status(
    status: int, body: str, headers: httpx.Headers | None = None
) -> None:
    """把上游状态码映射成统一错误码（并抛 `GatewayError`）。

    映射规则：
    - 401 / 403 → `AUTH_ERROR`（密钥错或没权限）
    - 429 → `UPSTREAM_RATE_LIMITED`，并把 `Retry-After` 解析结果放进 `details`
    - >= 500 → `UPSTREAM_ERROR`（上游自己挂了，可重试）
    - 其余 4xx → `UPSTREAM_REJECTED`（上游拒收了网关转发出去的东西，见 DESIGN §7.1）

    异常：状态码 >= 400 时必定抛 `GatewayError`；< 400 时正常返回（`None`）。
    """
    if status in (401, 403):
        raise GatewayError(
            ErrorCode.AUTH_ERROR,
            f"upstream auth failed with status {status}",
            upstream_status=status,
        )
    if status == 429:
        retry_after = _parse_retry_after(headers.get("Retry-After") if headers else None)
        raise GatewayError(
            ErrorCode.UPSTREAM_RATE_LIMITED,
            "upstream returned 429",
            upstream_status=status,
            details={"retry_after": retry_after} if retry_after else None,
        )
    if status >= 500:
        raise GatewayError(
            ErrorCode.UPSTREAM_ERROR, f"upstream returned {status}", upstream_status=status
        )
    if status >= 400:
        # 上游拒收 ≠ 调用方入参非法：调用方的请求已经过了网关自己的契约校验，
        # 是上游不认网关转发过去的模型名 / 参数组合。透传成 400 会让调用方
        # 去查自己那份完全合法的请求体（见 DESIGN §7.1）。
        raise GatewayError(
            ErrorCode.UPSTREAM_REJECTED,
            f"upstream rejected the request with status {status}: {body[:200]}",
            upstream_status=status,
        )


class UpstreamStream:
    """已建立的上游 SSE 连接。

    相当于 Java 里「已经拿到 Response 但 body 是流」的句柄：
    持有它就必须负责关闭（用完调 `aclose()`），否则连接不会被回收。
    """

    def __init__(self, response: httpx.Response, chunks: AsyncIterator[SSEChunk]) -> None:
        self.response = response
        self.chunks = chunks
        self._primed: SSEChunk | None = None

    async def next_chunk(self) -> SSEChunk | None:
        """取下一个 SSE 块；流已结束返回 `None`（≈ `Optional.empty()`）。

        优先返回被 `prime()` 预读的那一块，保证预读的块不会被丢弃。
        """
        if self._primed is not None:
            chunk, self._primed = self._primed, None
            return chunk
        return await anext(self.chunks, None)

    async def prime(self) -> SSEChunk | None:
        """读取第一个 chunk，但不关闭连接。

        用途：建连后先探一下第一个块，尽早发现上游立刻返回的错误事件，
        而不是等到真正向下游转发时才发现。

        异常：上游连接异常时会抛出底层 `httpx` 异常。
        """
        self._primed = await anext(self.chunks, None)
        return self._primed

    async def aclose(self) -> None:
        """关闭底层响应连接。

        异常：吞掉所有异常 —— 关闭失败不应掩盖调用方正在处理的真实错误。
        """
        try:
            await self.response.aclose()
        except Exception:
            pass


class UpstreamClient:
    """对上游发起 HTTP 调用。协议与模型均不感知。

    它只认 `UpstreamRequest`（URL / 头 / 体），不知道请求对应哪种协议，
    也不知道背后是什么模型 —— 协议翻译在 Provider 层已经完成。

    异常约定：本类抛出的异常一律是 `GatewayError`（已映射好的统一错误码），
    不会把 `httpx` 的原始异常泄漏到上层。
    """

    def __init__(self, client: httpx.AsyncClient) -> None:
        self.client = client

    async def post_json(
        self, upstream: UpstreamRequest, timeout: httpx.Timeout
    ) -> dict[str, Any]:
        """发起一次非流式 POST，并把响应体解析成 JSON 对象。

        异常：
        - `GatewayError(UPSTREAM_TIMEOUT)`：请求超时。
        - `GatewayError(UPSTREAM_ERROR)`：连接失败等传输层错误。
        - `GatewayError(AUTH_ERROR / UPSTREAM_RATE_LIMITED / UPSTREAM_ERROR / UPSTREAM_REJECTED)`：
          由状态码映射而来（见 `raise_for_upstream_status`）。
        - `GatewayError(MALFORMED_UPSTREAM)`：HTTP 成功但 body 不是合法 JSON 对象。
        """
        try:
            response = await self.client.post(
                upstream.url,
                headers=upstream.headers,
                json=upstream.body,
                timeout=timeout,
            )
        except httpx.TimeoutException as exc:
            raise GatewayError(ErrorCode.UPSTREAM_TIMEOUT, f"upstream timeout: {exc}") from exc
        except httpx.HTTPError as exc:
            raise GatewayError(
                ErrorCode.UPSTREAM_ERROR, f"upstream transport error: {exc}"
            ) from exc

        if response.status_code >= 400:
            raise_for_upstream_status(response.status_code, response.text, response.headers)

        try:
            payload = response.json()
        except (json.JSONDecodeError, ValueError) as exc:
            # 状态码 200 但 body 解析不了 —— 这是「内容层失败」，与传输层失败性质不同，
            # 上层按不同策略决定是否重试。
            raise GatewayError(
                ErrorCode.MALFORMED_UPSTREAM,
                f"upstream returned a non-JSON body: {response.text[:200]}",
                upstream_status=response.status_code,
            ) from exc
        if not isinstance(payload, dict):
            # JSON 合法但不是对象（如顶层是数组/字符串），同样按内容层失败处理。
            raise GatewayError(
                ErrorCode.MALFORMED_UPSTREAM,
                "upstream returned a JSON body that is not an object",
                upstream_status=response.status_code,
            )
        return payload

    async def open_stream(
        self, upstream: UpstreamRequest, timeout: httpx.Timeout
    ) -> UpstreamStream:
        """发起一次流式 POST，返回可逐块读取 SSE 的 `UpstreamStream`。

        与 `post_json` 的区别：这里不把 body 读完，而是交给调用方按需拉取。

        异常：与 `post_json` 同类（超时 / 传输错误 / 状态码映射错误 / body 非 JSON）；
        另外状态码 >= 400 时会先把流读完再抛错，避免连接悬着不释放。
        """
        request = self.client.build_request(
            "POST",
            upstream.url,
            headers=upstream.headers,
            json=upstream.body,
            timeout=timeout,
        )
        try:
            response = await self.client.send(request, stream=True)
        except httpx.TimeoutException as exc:
            raise GatewayError(ErrorCode.UPSTREAM_TIMEOUT, f"upstream timeout: {exc}") from exc
        except httpx.HTTPError as exc:
            raise GatewayError(
                ErrorCode.UPSTREAM_ERROR, f"upstream transport error: {exc}"
            ) from exc

        if response.status_code >= 400:
            # 流式响应要先读完 body 才能拿到错误内容，所以这里 aread() 一次再关闭。
            body = (await response.aread()).decode("utf-8", "replace")
            await response.aclose()
            raise_for_upstream_status(response.status_code, body, response.headers)

        return UpstreamStream(response, _iter_sse(response))


async def _iter_sse(response: httpx.Response) -> AsyncIterator[SSEChunk]:
    """把 SSE 字节流切成一个个 `SSEChunk`。

    SSE 帧格式：以空行分隔，每帧由若干 `event:` / `data:` 行组成；
    `data:` 可能有多行，要用换行拼接后再作为一个整体交给上层。

    异常：连接中途出错时抛 `GatewayError`（超时 / 传输错误），由上层决定是否重试。
    """
    event: str | None = None
    data_lines: list[str] = []
    try:
        async for line in response.aiter_lines():
            line = line.rstrip("\r")
            if line == "":
                # 空行 = 一帧结束。注意要先 yield 再清空，否则事件名会被丢掉。
                if data_lines:
                    yield SSEChunk(event=event, data="\n".join(data_lines))
                event = None
                data_lines = []
                continue
            if line.startswith(":"):
                # 以冒号开头的是注释行（常见于心跳 keep-alive），直接忽略。
                continue
            if line.startswith("event:"):
                event = line[len("event:") :].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:") :].strip())
    except httpx.TimeoutException as exc:
        raise GatewayError(ErrorCode.UPSTREAM_TIMEOUT, f"upstream timeout: {exc}") from exc
    except httpx.HTTPError as exc:
        raise GatewayError(
            ErrorCode.UPSTREAM_ERROR, f"upstream transport error: {exc}"
        ) from exc

    # 上游可能没发结尾空行就断流，这里补上最后一帧，避免丢掉尾部增量。
    if data_lines:
        yield SSEChunk(event=event, data="\n".join(data_lines))
