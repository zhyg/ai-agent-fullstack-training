"""调用编排：提示词渲染 → 限流 → 重试 → 适配器/Provider → 计量 → 记录。

本层既不感知协议，也不感知模型。

架构位置：网关的「编排层」。它在 HTTP 路由层（api/routes.py）之下、协议适配层
（adapters/）与上游客户端（upstream/）之上。各厂商的协议差异全部由下层吸收，
本层只处理跨厂商通用的流程控制：超时预算、限流准入、重试、内容校验、计量落账。

对应的 Java 概念：
- `async def` / `await` ≈ 协程，跑在单线程事件循环上，不是 CompletableFuture；
  `await` 是「挂起当前协程让出线程」，不是阻塞等待。
- `AsyncIterator` + `yield` ≈ Java 的 Stream / 响应式流，但每次产出前都可能挂起
  一次网络 I/O。
- `X | None` ≈ Java 的 `Optional<X>`；`dict[str, X]` ≈ `Map<String, X>`。
- `pydantic.BaseModel` ≈ 带运行时校验的 Java POJO/record。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from datetime import datetime, timezone
from typing import AsyncIterator, Awaitable, Callable

import httpx

from adapters.base import ModelAdapter, PreparedCall
from core.config import Settings
from core.errors import ErrorCode, GatewayError
from core.pricing import PriceTable
from core.structured import strength_instruction, try_parse, validate_schema
from core.tenants import TenantRegistry
from core.types import (
    LLMRequest,
    SSEChunk,
    TokenUsage,
    UnifiedMessage,
    UnifiedResponse,
    UnifiedStreamEvent,
    UpstreamEndpoint,
    now_ts,
)
from observability.metrics import Metrics
from observability.recorder import AttemptRecord, CallRecord, Recorder
from prompts.manager import PromptManager
from resilience.ratelimit import RateLimiter
from resilience.retry import RetryPolicy
from resilience.token_counter import TokenCounter
from upstream.client import UpstreamClient, UpstreamStream
from upstream.pool import UpstreamPool

# 「客户端是否已断开」的异步探针。由 HTTP 层提供（`request.is_disconnected`），
# 编排层只认这个回调——因此编排层不依赖 Web 框架，仍能脱离 HTTP 单独测试。
DisconnectProbe = Callable[[], Awaitable[bool]]

# 断开检测的轮询间隔（秒）。见 DESIGN §5.1.1。
DISCONNECT_POLL_INTERVAL = 0.25


def _now_iso() -> str:
    """当前 UTC 时间的 ISO-8601 字符串（毫秒精度），用于调用记录的 ts 字段。"""
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _prompt_hash(messages: list[UnifiedMessage]) -> str:
    """对全部消息正文做 SHA-256 后截取前 16 位。

    用途是把「这次请求实际发了什么提示词」与内容脱敏，只留指纹便于比对两次调用
    的提示词是否一致。哈希不区分角色，所以同样文本但角色不同会得到相同结果。
    """
    joined = "\n".join(message.content for message in messages)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:16]


def _sse_event(payload: dict) -> str:
    """构造一个 SSE 事件块（`data: {...}\\n\\n`）。

    SSE 协议要求每个事件以空行结束。载荷是**网关自有的事件形状**
    （见 DESIGN §5.1）：text_delta / reasoning_delta / usage / done / error。
    不用任何厂商的 chunk 形状，也**没有** `data: [DONE]` 哨兵——`done` 事件
    本身就是终止符。
    """
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


class _DisconnectWatcher:
    """轮询探针，检测客户端是否已断开。

    为什么单独跑在一个任务里：它必须与「读取上游数据」**并行**。如果只在
    「每个 chunk 到达时」检查一次，那么上游长时间没有新 chunk 的那段时间里
    发生的断开会被延迟很久才发现，上游这段时间的 token 就白烧了
    （见 DESIGN §5.1.1）。

    对应的 Java 概念：≈ 一个后台线程 + `AtomicBoolean`，只不过这里是
    asyncio 协程，不占线程。
    """

    def __init__(self, probe: DisconnectProbe) -> None:
        self._probe = probe
        self._task: asyncio.Task | None = None
        self._disconnected = False

    def start(self) -> None:
        """启动监听任务（幂等）。"""
        if self._task is None:
            self._task = asyncio.create_task(self._run())

    @property
    def disconnected(self) -> bool:
        """客户端是否已断开。"""
        return self._disconnected

    @property
    def task(self) -> asyncio.Task:
        """监听任务本身，用于与「读上游」做竞速。"""
        if self._task is None:
            raise RuntimeError("disconnect watcher has not been started")
        return self._task

    async def _run(self) -> None:
        while True:
            try:
                if await self._probe():
                    self._disconnected = True
                    return
            except Exception:
                # 探针自身出错**不代表**客户端断开，继续观察。
                pass
            await asyncio.sleep(DISCONNECT_POLL_INTERVAL)

    def cancel(self) -> None:
        """停止监听（不等待它结束）。"""
        if self._task is not None and not self._task.done():
            self._task.cancel()


class _EmptyStream:
    """空事件流：客户端已断开后返回，一个事件帧都不发（见 DESIGN §5.1.1）。

    客户端已经不在了，往断开的连接写帧没有意义，所以这里什么都不产出。
    """

    def __aiter__(self) -> "_EmptyStream":
        return self

    async def __anext__(self) -> str:
        raise StopAsyncIteration


class ChatService:
    """调用编排的核心服务，路由层唯一的业务入口。

    职责：把一次「统一请求」变成一次「统一响应」，并在过程中处理限流、两级重试、
    超时预算、内容校验、计量与调用记录。

    要记住的两个关键约束：
    1. 本类不感知任何厂商协议，所有协议差异都由 `ModelAdapter` 吸收。
    2. 本类是单请求串行推进的（无共享可变状态），因此同一个实例可以被所有并发
       请求共用；跨请求共享的只有注入进来的 limiter / recorder / metrics。
    """

    def __init__(
        self,
        settings: Settings,
        adapters: dict[str, ModelAdapter],
        limiter: RateLimiter,
        recorder: Recorder,
        metrics: Metrics,
        prompt_manager: PromptManager,
        client: UpstreamClient,
        tenants: TenantRegistry | None = None,
        prices: PriceTable | None = None,
        pools: dict[str, UpstreamPool] | None = None,
    ) -> None:
        self.settings = settings
        self.adapters = adapters
        self.limiter = limiter
        self.recorder = recorder
        self.metrics = metrics
        self.prompt_manager = prompt_manager
        self.client = client
        self.tenants = tenants or TenantRegistry()
        self.prices = prices or PriceTable()
        # 模型别名 → 上游端点池。只有配了 upstreams 的模型才有池子；
        # 没有池子的模型走原来的单端点路径（见 DESIGN §7.8.1）。
        self.pools = pools or {}
        self.token_counter = TokenCounter(settings.token_counter)
        self.retry_policy = RetryPolicy(settings.retry)

    # --- 公共辅助 -----------------------------------------------------

    def adapter_for(self, model: str, caller: str = "anonymous") -> ModelAdapter:
        """按模型别名取适配器。

        抛 GatewayError(ErrorCode.MODEL_NOT_FOUND)：
        - 别名未注册或该模型被禁用；
        - 该租户无权使用这个模型（见 DESIGN §7.6.3）。无权访问一律按
          「不存在」处理——403 会泄露模型目录。
        """
        adapter = self.adapters.get(model)
        if adapter is None or not self.tenants.allows(caller, model):
            raise GatewayError(
                ErrorCode.MODEL_NOT_FOUND, f"model '{model}' is not available"
            )
        return adapter

    def visible_models(self, caller: str) -> list[str]:
        """该租户可见的模型清单（顺序与注册顺序一致）。"""
        return self.tenants.visible_models(caller, list(self.adapters))

    def is_admin(self, caller: str) -> bool:
        """该租户是不是管理员（可见全局数据，见 DESIGN §7.6.5）。"""
        return self.tenants.is_admin(caller)

    def _render(self, req: LLMRequest):
        """渲染提示词模板。

        返回四元组 (消息列表, 渲染后的模板文本, 模板名, 模板版本号)。未使用模板
        时后三项为 None，便于调用记录里区分「走了模板」和「直接透传消息」。

        抛 GatewayError：模板不存在、版本不存在、变量声明/缺失/未使用有误
        （详见 prompts/manager.py）。
        """
        if req.prompt is None:
            return list(req.messages), None, None, None
        messages, rendered = self.prompt_manager.render(req.prompt, req.messages)
        template, version = self.prompt_manager.resolve(req.prompt)
        return messages, rendered, template.name, version.version

    def _strengthen(
        self,
        req: LLMRequest,
        adapter: ModelAdapter,
        messages: list[UnifiedMessage],
        strength: int,
        previous_output: str,
    ) -> LLMRequest:
        """按「加强档位」生成新的请求对象（内容层重试的关键）。

        strength 是加强档位：0 表示不加强；每失败一次内容校验就 +1（上限由
        `structured_output.max_prompt_strength` 决定）。加强方式是把
        `strength_instruction` 追加到 system 消息末尾；若原本没有 system 消息，
        则在最前面插入一条。

        `req.model_copy(update=...)` 是 pydantic 的浅拷贝，≈ Java 的
        `copy-constructor`/record 的 with 语法，返回新对象而不改动原请求。
        """
        if strength <= 0:
            return req.model_copy(update={"messages": list(messages)})
        plan = adapter.structured_mode(req)
        instruction = strength_instruction(
            strength, plan.mode, plan.schema, plan.schema_name, previous_output
        )
        updated = list(messages)
        for index, message in enumerate(updated):
            if message.role == "system":
                updated[index] = UnifiedMessage(
                    role="system", content=f"{message.content}\n\n{instruction}"
                )
                break
        else:
            updated.insert(0, UnifiedMessage(role="system", content=instruction))
        return req.model_copy(update={"messages": updated})

    def _estimate(self, req: LLMRequest, adapter: ModelAdapter) -> int:
        """估算本次调用要预留的 token 数（用于 tpm 限流预扣）。

        口径 = 输入 token 估算 + 预估输出上限。输出上限必须走
        `adapter.resolve_max_output_tokens()`——那才是实际下发给上游的值；
        预扣用另一个数，桶就永远补不回多扣的那部分。
        预扣是「先扣后结算」，真实用量在调用结束后由 `settle()` 退回。
        """
        input_tokens = self.token_counter.estimate_messages(
            [message.content for message in req.messages]
        )
        return input_tokens + adapter.resolve_max_output_tokens()

    def _maybe_penalize(
        self, caller: str, model: str, reserved: int, exc: GatewayError
    ) -> None:
        """上游 429 时按配置做一次惩罚性扣减（见 DESIGN §7.3）。

        扣减量 = **该次尝试预扣的 token 数**：那次尝试已经被扣了两次
        （网关自己的预扣 + 上游真的按请求计费），按预扣量扣是与这次尝试
        一一对应的惩罚。

        默认关闭（`rate_limit.penalize_on_upstream_429`）：上游偶发抖动时，
        惩罚扣减会连带吃掉后续请求的额度。
        """
        if exc.code != ErrorCode.UPSTREAM_RATE_LIMITED:
            return
        if not self.settings.rate_limit.penalize_on_upstream_429:
            return
        self.limiter.penalize(caller, model, reserved)

    def _settle_stream(
        self,
        caller: str,
        req: LLMRequest,
        reserved: int,
        upstream_usage: TokenUsage | None,
        produced: str,
    ) -> None:
        """流式的限流结算（见 DESIGN §7.3「结算的三种结局」）。

        流式和非流式一样是「先扣后结算」：准入时按「预估输入 + 输出上限」
        预扣，流结束后按实际用量把差额退回。

        口径：
        - 上游给了 usage → 用它的实际 token；
        - 没有 usage（上游中途断了、或本来就没给）→ 「输入估算 + 已产出文本估算」。

        「首个事件之前就失败」的情况根本走不到这里（流的主体没启动），
        预扣保留——上游可能已经计费，网关无从得知（见 DESIGN §7.3）。
        """
        if upstream_usage is not None and upstream_usage.total_tokens > 0:
            actual = upstream_usage.total_tokens
        else:
            actual = self.token_counter.estimate_messages(
                [message.content for message in req.messages]
            ) + self.token_counter.estimate(produced)
        self.limiter.settle(caller, req.model, reserved, actual)

    def _timeouts(self, streaming: bool) -> httpx.Timeout:
        """构造本次 HTTP 调用的超时预算。

        两段式超时预算：
        - 整体 deadline（`cfg.deadline`）在编排层维护，约束「一次请求从进入到
          最终结束」的总时长；单次 attempt 的耗时上限则由这里的 httpx.Timeout
          承担。
        - 非流式：read = `cfg.attempt`，即单次尝试最多等这么久拿完整响应。
        - 流式：read = `cfg.stream_idle`，即「相邻两个 chunk 之间的最大空闲间隔」，
          而不是整个流的总时长。

        流式的**首包**超时（`cfg.first_token`）不靠 httpx，而是由编排层自己用
        `asyncio.wait_for` 计时（见 `_open_stream`）——httpx 的 read 超时管的是
        「两次读之间的空闲」，管不到「上游连上了但一个事件都不发」。

        注意：流式**没有**总 deadline（见 DESIGN §7.2.5），`cfg.deadline`
        只约束非流式路径。
        """
        cfg = self.settings.timeout
        if streaming:
            return httpx.Timeout(
                connect=cfg.connect,
                read=cfg.stream_idle,
                write=cfg.write,
                pool=cfg.connect,
            )
        return httpx.Timeout(
            connect=cfg.connect,
            read=cfg.attempt,
            write=cfg.write,
            pool=cfg.connect,
        )

    def _validate_output(
        self, req: LLMRequest, response: UnifiedResponse
    ) -> UnifiedResponse:
        """校验模型输出（内容层的最后一道闸）。

        仅当请求带了 `output_schema` 时才生效，流程是：
        本地 JSON 修复 → JSON 解析 → schema 校验 → 把规范化后的 JSON 写回
        `response.content`。

        `strict` 的语义：
        - true（默认）：不符 ⇒ 抛错 ⇒ 触发内容层重试；仍不符 ⇒ 502。
        - false：尽力而为，**不报错也不重试**，content 原样返回。

        抛 GatewayError：
        - ErrorCode.INVALID_JSON：修复后仍不是合法 JSON（内容层可重试）。
        - ErrorCode.SCHEMA_MISMATCH：JSON 合法但不符合请求的 schema。
        """
        spec = req.output_schema
        if spec is None or not spec.strict:
            return response
        parsed = try_parse(response.content, repair=self.settings.structured_output.repair)
        if parsed is None:
            raise GatewayError(
                ErrorCode.INVALID_JSON,
                "model output is not valid JSON even after local repair",
            )
        ok, detail = validate_schema(parsed, spec.schema_)
        if not ok:
            raise GatewayError(
                ErrorCode.SCHEMA_MISMATCH,
                f"model output does not match the requested schema: {detail}",
            )
        response.content = json.dumps(parsed, ensure_ascii=False)
        return response

    def _build_record(
        self,
        request_id: str,
        req: LLMRequest,
        adapter: ModelAdapter,
        started: float,
        status: str,
        error: GatewayError | None,
        attempts: list[AttemptRecord],
        usage: TokenUsage,
        rendered: str | None,
        template_name: str | None,
        template_version: int | None,
        ttft_ms: float | None = None,
        partial_chars: int | None = None,
        upstream_response_id: str | None = None,
        caller: str = "anonymous",
        upstream_endpoint: str | None = None,
        failover_count: int = 0,
    ) -> CallRecord:
        """把本次调用的全部信息汇总成一条 `CallRecord`（供 recorder/metrics 使用）。

        `retry_count = attempt 数 - 1`，即「除了第一次之外又试了几次」；失败时
        `attempt_count` 记录真实尝试次数，成功时也包含失败后成功的那些尝试。

        `upstream_response_id` 是上游厂商返回的 id —— 它**只落记录**，不进线上
        契约（响应里的 id 一律是网关自己的 request id，见 DESIGN §6.1）。

        `upstream_endpoint` / `failover_count` 是多上游 failover 的痕迹
        （见 DESIGN §7.8.7）：单端点模式下前者恒为 None。
        """
        return CallRecord(
            request_id=request_id,
            ts=_now_iso(),
            model=req.model,
            caller=caller,
            adapter=adapter.alias,
            provider=adapter.provider.protocol,
            protocol=adapter.provider.protocol,
            stream=req.stream,
            status=status,
            error_code=error.code.value if error else None,
            error_message=error.message if error else None,
            error_stage=error.details.get("stage") if error else None,
            attempt_count=len(attempts),
            retry_count=max(0, len(attempts) - 1),
            last_upstream_status=error.upstream_status if error else None,
            upstream_response_id=upstream_response_id,
            latency_ms=round((time.perf_counter() - started) * 1000, 2),
            ttft_ms=round(ttft_ms, 2) if ttft_ms is not None else None,
            usage=usage,
            cost_usd=self.prices.cost(req.model, usage),
            upstream_endpoint=upstream_endpoint,
            failover_count=failover_count,
            metadata={str(k): str(v) for k, v in (req.metadata or {}).items()},
            prompt_template=template_name,
            prompt_version=template_version,
            rendered_prompt=rendered,
            attempts=attempts,
        )

    def _finish(
        self,
        record: CallRecord,
        error: GatewayError | None = None,
        request_id: str | None = None,
    ) -> None:
        """收尾：落调用记录 + 累加指标。成功和失败都要走这里。"""
        self.recorder.record(record)
        self.metrics.observe(record)

    def _check_capabilities(self, adapter: ModelAdapter, req: LLMRequest) -> None:
        """检查这个模型能不能满足本次请求。

        **必须在限流与重试之前**：调用方提了一个网关做不到的要求，网关应该立刻
        400，而不是先扣掉一份限流配额、再占住一个上游连接、最后才失败。

        抛 GatewayError(ErrorCode.CAPABILITY_UNSUPPORTED)：能力不满足。
        """
        if req.output_schema is not None and not adapter.supports_output_schema:
            raise GatewayError(
                ErrorCode.CAPABILITY_UNSUPPORTED,
                f"model '{adapter.alias}' does not support output_schema",
            )
        if req.stream and not adapter.supports_streaming:
            raise GatewayError(
                ErrorCode.CAPABILITY_UNSUPPORTED,
                f"model '{adapter.alias}' does not support streaming",
            )

    # --- 非流式 -------------------------------------------------------

    async def chat(
        self, req: LLMRequest, request_id: str, caller: str = "anonymous"
    ) -> UnifiedResponse:
        """执行一次非流式对话调用。

        流程：渲染提示词 → 限流准入 → 重试循环 → 适配器准备请求 → 上游调用 →
        内容校验 → 结算限流额度 → 计量与记录。

        两级重试（同一个循环里完成，靠错误类型区分）：
        - 传输层重试：连接失败、超时、5xx、429 等 `exc.retriable` 的错误，重试时
          提示词保持不变，靠指数退避等待。
        - 内容层重试：模型返回了但内容不合法（JSON 非法 / schema 不匹配），
          `exc.retry_kind == "content"` 时把加强档位 +1，用更强的提示词再问一次；
          该能力可由 `structured_output.content_retry` 关闭。

        `caller` 是租户标识：决定模型可见性、配额归属与记录归属
        （见 DESIGN §7.6）。

        抛 GatewayError：模型不存在、能力不足（400）、限流 429、以及重试耗尽后的
        最后一次错误。
        """
        started = time.perf_counter()
        adapter = self.adapter_for(req.model, caller)
        messages, rendered, template_name, template_version = self._render(req)

        # 能力校验在最前面：做不到的请求直接 400，不消耗限流配额、不发上游请求。
        try:
            self._check_capabilities(adapter, req)
        except GatewayError as exc:
            record = self._build_record(
                request_id, req, adapter, started, "error", exc, [],
                TokenUsage(), rendered, template_name, template_version,
                caller=caller,
            )
            self._finish(record, exc, request_id)
            raise

        deadline = started + self.settings.timeout.deadline
        attempts: list[AttemptRecord] = []
        total_usage = TokenUsage()
        strength = 0
        previous_output = ""
        last_error: GatewayError | None = None
        # 多上游 failover（见 DESIGN §7.8）：没有端点池的模型走原来的单端点路径。
        pool = self.pools.get(req.model)
        failed_endpoints: set[str] = set()
        failover_count = 0
        last_endpoint: UpstreamEndpoint | None = None

        for attempt in range(1, self.retry_policy.max_attempts + 1):
            # 每一轮都用当前的加强档位重新构造请求：内容层重试靠 strength 递增，
            # 传输层重试时 strength 不变。
            current = self._strengthen(req, adapter, messages, strength, previous_output)
            reserved = self._estimate(current, adapter)

            # 挑端点：跳过本次调用已经失败过的端点，跳过处于熔断状态的端点。
            endpoint: UpstreamEndpoint | None = None
            if pool is not None:
                endpoint = pool.pick(exclude=failed_endpoints)
                if endpoint is None:
                    if last_error is None:
                        # 第一次尝试就没有可用端点（全部熔断中）。
                        exc = GatewayError(
                            ErrorCode.UPSTREAM_UNAVAILABLE,
                            "no healthy upstream endpoint is available for this model",
                        )
                        record = self._build_record(
                            request_id, req, adapter, started, "error", exc, attempts,
                            total_usage, rendered, template_name, template_version,
                            caller=caller,
                        )
                        self._finish(record, exc, request_id)
                        raise exc
                    # 端点在本次调用里已经试完：沿用最后一次错误，不换错误码。
                    break
                if last_endpoint is not None and endpoint.name != last_endpoint.name:
                    failover_count += 1
                last_endpoint = endpoint

            try:
                # 限流在每次尝试前都要重新准入；额度不足直接 429，不做退避重试，
                # 因为客户端可以自己按 retry_after 再来。
                self.limiter.consume(caller, req.model, reserved)
            except GatewayError as exc:
                if pool is not None and endpoint is not None:
                    # 还没打这个端点就放弃了：归还试探名额，别让它一直占着。
                    pool.release(endpoint)
                record = self._build_record(
                    request_id, req, adapter, started, "error", exc, attempts,
                    total_usage, rendered, template_name, template_version,
                    caller=caller,
                    upstream_endpoint=last_endpoint.name if last_endpoint else None,
                    failover_count=failover_count,
                )
                self._finish(record, exc, request_id)
                raise

            call = adapter.prepare(current, endpoint)
            attempt_usage = TokenUsage()
            try:
                raw = await self.client.post_json(call.upstream, self._timeouts(False))
                response = adapter.parse_response(call, raw)
                attempt_usage = response.usage
                previous_output = response.content
                response = self._validate_output(current, response)
            except GatewayError as exc:
                total_usage.add(attempt_usage)
                attempts.append(
                    AttemptRecord(
                        attempt=attempt,
                        ok=False,
                        error_code=exc.code.value,
                        upstream_status=exc.upstream_status,
                        usage=attempt_usage,
                        prompt_hash=_prompt_hash(current.messages),
                        prompt_strength=strength,
                        upstream_endpoint=endpoint.name if endpoint else None,
                    )
                )
                last_error = exc
                self._maybe_penalize(caller, req.model, reserved, exc)
                if pool is not None and endpoint is not None:
                    if exc.retry_kind == "content":
                        # 内容层错误不是端点的错：只归还试探名额，不计失败。
                        pool.release(endpoint)
                    else:
                        pool.report_failure(endpoint, exc)
                        failed_endpoints.add(endpoint.name)
                # 不可重试的错误，或已经用到最后一次尝试，就直接跳出循环。
                if not exc.retriable or attempt == self.retry_policy.max_attempts:
                    break
                # 内容层重试：加强提示词档位，让模型重新按要求输出。
                if exc.retry_kind == "content" and self.settings.structured_output.content_retry:
                    strength = min(strength + 1, self.settings.structured_output.max_prompt_strength)
                delay = self.retry_policy.delay_for(
                    attempt, exc.details.get("retry_after")
                )
                # 退避时间 + 下一次尝试本身要花的时间，必须都塞得进剩余预算。
                # 只算退避是不够的：那会让总耗时穿透 deadline（见 DESIGN §7.2.5）。
                if time.perf_counter() + delay + self.settings.timeout.attempt >= deadline:
                    break
                # asyncio.sleep ≈ 让出事件循环的 Thread.sleep，不阻塞线程。
                await asyncio.sleep(delay)
                continue

            total_usage.add(attempt_usage)
            # 按真实用量结算限流额度，多预扣的部分退回 tpm 桶。
            self.limiter.settle(
                caller, req.model, reserved, attempt_usage.total_tokens
            )
            if pool is not None and endpoint is not None:
                pool.report_success(endpoint)
            attempts.append(
                AttemptRecord(
                    attempt=attempt,
                    ok=True,
                    usage=attempt_usage,
                    prompt_hash=_prompt_hash(current.messages),
                    prompt_strength=strength,
                    upstream_endpoint=endpoint.name if endpoint else None,
                )
            )
            # 上游 id 只落记录；线上契约里的 id / model 一律是网关自己的——
            # 调用方不该从响应里看出背后是哪家厂商。
            upstream_response_id = response.id or None
            response.id = request_id
            response.model = req.model
            response.created = now_ts()
            response.usage = total_usage
            response.cost_usd = self.prices.cost(req.model, total_usage)
            response.latency_ms = round((time.perf_counter() - started) * 1000, 2)
            record = self._build_record(
                request_id, req, adapter, started, "success", None, attempts,
                total_usage, rendered, template_name, template_version,
                upstream_response_id=upstream_response_id,
                caller=caller,
                upstream_endpoint=last_endpoint.name if last_endpoint else None,
                failover_count=failover_count,
            )
            self._finish(record)
            return response

        assert last_error is not None
        record = self._build_record(
            request_id, req, adapter, started, "error", last_error, attempts,
            total_usage, rendered, template_name, template_version,
            caller=caller,
            upstream_endpoint=last_endpoint.name if last_endpoint else None,
            failover_count=failover_count,
        )
        self._finish(record, last_error, request_id)
        raise last_error

    # --- 流式 ---------------------------------------------------------

    async def start_stream(
        self,
        req: LLMRequest,
        request_id: str,
        *,
        is_disconnected: DisconnectProbe | None = None,
        caller: str = "anonymous",
    ) -> AsyncIterator[str]:
        """建立上游流并返回 SSE 迭代器。首字节前的失败抛 GatewayError。

        与非流式的差别：本方法只负责「把流打开并拿到第一个事件」，真正的吐字在
        `_stream_body` 里。

        关键边界——流式首字节边界：只有在还没有向客户端吐出任何字节之前发生的
        失败（建连失败、首事件超时、事件解析失败）才可以重试；一旦
        `_stream_body` 开始 yield，重试就不可能了（客户端已经收到半个响应），
        只能中断并返回一个错误事件帧。

        `is_disconnected` 是「客户端是否已断开」的探针（见 DESIGN §5.1.1）。
        客户端断开时：取消上游、不再发事件帧、记 `cancelled`、不重试。

        `caller` 是租户标识（见 DESIGN §7.6）。
        """
        started = time.perf_counter()
        adapter = self.adapter_for(req.model, caller)
        messages, rendered, template_name, template_version = self._render(req)

        # 能力校验在最前面：做不到的请求直接 400，不消耗限流配额、不发上游请求。
        try:
            self._check_capabilities(adapter, req)
        except GatewayError as exc:
            record = self._build_record(
                request_id, req, adapter, started, "error", exc, [],
                TokenUsage(), rendered, template_name, template_version,
                caller=caller,
            )
            self._finish(record, exc, request_id)
            raise

        attempts: list[AttemptRecord] = []
        total_usage = TokenUsage()
        strength = 0
        previous_output = ""
        last_error: GatewayError | None = None
        watcher = _DisconnectWatcher(is_disconnected) if is_disconnected else None
        # 流式**不设总 deadline**（见 DESIGN §7.2.5）：长文本生成可能跑几分钟，
        # 用总预算掐断它与「流式不用总 deadline」的初衷相反。流式只受两件事
        # 约束：每次尝试的首 token deadline，以及 chunk 之间的空闲超时。
        # 多上游 failover（见 DESIGN §7.8.6）：流式只在首字节之前可以换端点。
        pool = self.pools.get(req.model)
        failed_endpoints: set[str] = set()
        failover_count = 0
        last_endpoint: UpstreamEndpoint | None = None
        # 监听器的生命周期：正常情况下交给 `_stream_body` 收尾（那里才知道流何时结束），
        # 只有在本方法自己退出时才需要在这里关掉。
        handed_off = False

        try:
            if watcher is not None:
                watcher.start()
            for attempt in range(1, self.retry_policy.max_attempts + 1):
                current = self._strengthen(req, adapter, messages, strength, previous_output)
                reserved = self._estimate(current, adapter)

                endpoint: UpstreamEndpoint | None = None
                if pool is not None:
                    endpoint = pool.pick(exclude=failed_endpoints)
                    if endpoint is None:
                        if last_error is None:
                            exc = GatewayError(
                                ErrorCode.UPSTREAM_UNAVAILABLE,
                                "no healthy upstream endpoint is available for this model",
                            )
                            record = self._build_record(
                                request_id, req, adapter, started, "error", exc, attempts,
                                total_usage, rendered, template_name, template_version,
                                caller=caller,
                            )
                            self._finish(record, exc, request_id)
                            raise exc
                        break
                    if last_endpoint is not None and endpoint.name != last_endpoint.name:
                        failover_count += 1
                    last_endpoint = endpoint

                try:
                    self.limiter.consume(caller, req.model, reserved)
                except GatewayError as exc:
                    if pool is not None and endpoint is not None:
                        pool.release(endpoint)
                    record = self._build_record(
                        request_id, req, adapter, started, "error", exc, attempts,
                        total_usage, rendered, template_name, template_version,
                        caller=caller,
                        upstream_endpoint=last_endpoint.name if last_endpoint else None,
                        failover_count=failover_count,
                    )
                    self._finish(record, exc, request_id)
                    raise

                call = adapter.prepare(current, endpoint)
                stream: UpstreamStream | None = None
                first_event: UnifiedStreamEvent | None = None
                try:
                    stream, first_event = await self._open_stream(adapter, call, watcher)
                    if first_event is None:
                        if watcher is not None and watcher.disconnected:
                            # 客户端在首字节之前就走了：不重试（重试给谁看？），
                            # 取消上游并按 cancelled 收尾。
                            await stream.aclose()
                            if pool is not None and endpoint is not None:
                                pool.release(endpoint)
                            attempts.append(
                                AttemptRecord(
                                    attempt=attempt,
                                    ok=False,
                                    usage=TokenUsage(),
                                    prompt_hash=_prompt_hash(current.messages),
                                    prompt_strength=strength,
                                    upstream_endpoint=endpoint.name if endpoint else None,
                                )
                            )
                            record = self._build_record(
                                request_id, req, adapter, started, "cancelled", None,
                                attempts, total_usage, rendered, template_name,
                                template_version,
                                caller=caller,
                                upstream_endpoint=last_endpoint.name if last_endpoint else None,
                                failover_count=failover_count,
                            )
                            self._finish(record, None, request_id)
                            return _EmptyStream()
                        raise GatewayError(
                            ErrorCode.MALFORMED_UPSTREAM,
                            "upstream stream ended without producing any event",
                        )
                except GatewayError as exc:
                    # 必须先关掉半开的流，否则连接会泄漏。
                    if stream is not None:
                        await stream.aclose()
                    last_error = exc
                    self._maybe_penalize(caller, req.model, reserved, exc)
                    attempts.append(
                        AttemptRecord(
                            attempt=attempt,
                            ok=False,
                            error_code=exc.code.value,
                            upstream_status=exc.upstream_status,
                            usage=TokenUsage(),
                            prompt_hash=_prompt_hash(current.messages),
                            prompt_strength=strength,
                            upstream_endpoint=endpoint.name if endpoint else None,
                        )
                    )
                    if pool is not None and endpoint is not None:
                        if exc.retry_kind == "content":
                            pool.release(endpoint)
                        else:
                            pool.report_failure(endpoint, exc)
                            failed_endpoints.add(endpoint.name)
                    if not exc.retriable or attempt == self.retry_policy.max_attempts:
                        break
                    delay = self.retry_policy.delay_for(
                        attempt, exc.details.get("retry_after")
                    )
                    # 流式没有总 deadline，所以这里不做预算判断：退避完直接重来，
                    # 每次尝试各自受 first_token 约束（见 DESIGN §7.2.5）。
                    await asyncio.sleep(delay)
                    continue

                # 到这里说明首字节之前的所有尝试都失败了，可以安全地抛错并重试。
                handed_off = True
                return self._stream_body(
                    req=req,
                    request_id=request_id,
                    adapter=adapter,
                    call=call,
                    stream=stream,
                    first_event=first_event,
                    started=started,
                    attempts=attempts,
                    total_usage=total_usage,
                    rendered=rendered,
                    template_name=template_name,
                    template_version=template_version,
                    watcher=watcher,
                    caller=caller,
                    endpoint=endpoint,
                    failover_count=failover_count,
                    reserved=reserved,
                )

            assert last_error is not None
            record = self._build_record(
                request_id, req, adapter, started, "error", last_error, attempts,
                total_usage, rendered, template_name, template_version,
                caller=caller,
                upstream_endpoint=last_endpoint.name if last_endpoint else None,
                failover_count=failover_count,
            )
            self._finish(record, last_error, request_id)
            raise last_error
        finally:
            if watcher is not None and not handed_off:
                watcher.cancel()

    async def _open_stream(
        self,
        adapter: ModelAdapter,
        call: PreparedCall,
        watcher: _DisconnectWatcher | None = None,
    ) -> tuple[UpstreamStream, UnifiedStreamEvent | None]:
        """建连并读到第一个事件，整段受 `timeout.first_token` 约束。

        为什么要自己计时（见 DESIGN §7.2.5）：httpx 的 `read_timeout` 管的是
        「两次读之间的空闲」，它能覆盖「流中途卡住」，但覆盖不了
        「上游连上了却一个事件都不发」——后者是**流开头**没开始，语义不同。
        把「建连 + 第一个事件」整段包进 `asyncio.wait_for` 才是真正的首 token 预算。

        返回 (流, 第一个事件)。第一个事件为 None 表示上游在产出任何事件之前
        就结束了（上层按 MALFORMED_UPSTREAM 处理）；客户端断开时也是 None
        （上层据此判定「客户端已走」）。

        抛 GatewayError(UPSTREAM_TIMEOUT)：超过 first_token 仍没拿到第一个事件。
        """
        stream: UpstreamStream | None = None

        async def _run() -> UnifiedStreamEvent | None:
            nonlocal stream
            stream = await self.client.open_stream(call.upstream, self._timeouts(True))
            return await self._first_event(adapter, call, stream, watcher)

        try:
            first_event = await asyncio.wait_for(
                _run(), timeout=self.settings.timeout.first_token
            )
        except asyncio.TimeoutError as exc:
            # 超时发生在「已经建连、流还开着」的情况下时要把流关掉，否则连接泄漏。
            if stream is not None:
                await stream.aclose()
            raise GatewayError(
                ErrorCode.UPSTREAM_TIMEOUT,
                "upstream did not produce the first event within the first-token deadline",
            ) from exc
        assert stream is not None
        return stream, first_event

    async def _first_event(
        self,
        adapter: ModelAdapter,
        call: PreparedCall,
        stream: UpstreamStream,
        watcher: _DisconnectWatcher | None = None,
    ) -> UnifiedStreamEvent | None:
        """读取并解析第一个有效事件。

        返回 None 表示上游流在产生任何事件之前就结束了（此时上层按
        MALFORMED_UPSTREAM 处理）。会跳过解析不出事件的分片（例如心跳、
        注释行），这与 Java 里「循环读取直到拿到第一个可用对象」是一回事。

        客户端在等待首事件期间断开时，读上游的动作会被中断（见 `_next_chunk`），
        返回 None —— 上层据此判定为「客户端已走」而不是「上游流异常结束」。
        """
        while True:
            chunk = await self._next_chunk(stream, watcher)
            if chunk is None:
                return None
            event = adapter.parse_stream_event(chunk, call.ctx)
            if event is not None:
                return event

    async def _next_chunk(
        self, stream: UpstreamStream, watcher: _DisconnectWatcher | None
    ) -> SSEChunk | None:
        """取下一个上游 SSE 块；流结束返回 None。

        有断开监听时，「读上游」与「看客户端是否断开」并行竞速：只有并行才能在
        上游长时间没有新 chunk 的情况下及时发现断开（见 DESIGN §5.1.1）。
        """
        if watcher is None:
            return await stream.next_chunk()
        read = asyncio.create_task(stream.next_chunk())
        try:
            done, _ = await asyncio.wait(
                {read, watcher.task}, return_when=asyncio.FIRST_COMPLETED
            )
        except BaseException:
            # 自身被取消时也要把「读上游」停掉，否则连接会悬着。
            read.cancel()
            raise
        if read not in done:
            # 客户端先断开：停掉还在等待的上游读取，不给上游继续生成的机会。
            read.cancel()
            return None
        return read.result()

    async def _stream_body(
        self,
        *,
        req: LLMRequest,
        request_id: str,
        adapter: ModelAdapter,
        call: PreparedCall,
        stream: UpstreamStream,
        first_event: UnifiedStreamEvent,
        started: float,
        attempts: list[AttemptRecord],
        total_usage: TokenUsage,
        rendered: str | None,
        template_name: str | None,
        template_version: int | None,
        watcher: _DisconnectWatcher | None = None,
        caller: str = "anonymous",
        endpoint: UpstreamEndpoint | None = None,
        failover_count: int = 0,
        reserved: int = 0,
    ) -> AsyncIterator[str]:
        """流的真正主体：把上游事件翻译成 SSE 帧逐个吐给客户端。

        这里是「流式首字节边界」的所在：一旦进入本方法并开始 yield，响应就已经
        开始发给客户端，之后任何异常都**不能**再重试，只能：
        1. 关掉上游流；
        2. 吐一个 `data: {"type":"error", ...}` 事件帧；
        3. 再吐 `data: {"type":"done","finish_reason":"error"}` 收尾，
           让客户端能识别出这是一次中断。

        客户端断开是另一条收尾路径：**不发任何事件帧**（error / done 也不发），
        取消上游并记 `cancelled`（见 DESIGN §5.1.1）。

        抛出的异常在内部被捕获成 error 事件帧，因此本方法正常结束时不抛异常。
        """
        collected: list[str] = []
        ttft_ms: float | None = None
        finish_reason = "stop"
        usage: TokenUsage | None = None
        # 上游**自己**报的 usage（可能没有）；与本地兜底估算区分开，
        # 限流结算要用前者（见 DESIGN §7.3）。
        upstream_usage: TokenUsage | None = None
        error: GatewayError | None = None
        partial_chars: int | None = None
        cancelled = False

        pending = first_event
        try:
            try:
                while True:
                    # 客户端已断开：立即收手，不给一个已经不在的客户端继续烧 token。
                    if watcher is not None and watcher.disconnected:
                        cancelled = True
                        break
                    if pending is None:
                        chunk = await self._next_chunk(stream, watcher)
                        if watcher is not None and watcher.disconnected:
                            cancelled = True
                            break
                        if chunk is None:
                            break
                        pending = adapter.parse_stream_event(chunk, call.ctx)
                        if pending is None:
                            continue
                    event = pending
                    pending = None

                    if event.type == "text_delta":
                        if ttft_ms is None:
                            # 首个文本 token 的到达时刻 = TTFT（首 token 延迟）。
                            ttft_ms = (time.perf_counter() - started) * 1000
                        collected.append(event.text or "")
                        yield _sse_event({"type": "text_delta", "text": event.text or ""})
                    elif event.type == "reasoning_delta":
                        yield _sse_event(
                            {"type": "reasoning_delta", "text": event.text or ""}
                        )
                    elif event.type == "usage":
                        upstream_usage = event.usage
                        finish_reason = event.finish_reason or finish_reason
                    elif event.type == "done":
                        finish_reason = event.finish_reason or finish_reason
                    elif event.type == "error":
                        # Provider 认出了「上游在流中途自己报了错」——
                        # 转成 GatewayError 走统一的错误出口（error 帧 + done{error}），
                        # 不能让它被静默吞掉：那样客户端会以为这次调用正常结束。
                        raise GatewayError(
                            ErrorCode.UPSTREAM_ERROR,
                            "upstream reported an error mid-stream",
                            details=event.error,
                        )
            except GatewayError as exc:
                # 已经吐过字节，不能重试，只能把错误编码成事件帧发出去。
                error = exc
                partial_chars = sum(len(part) for part in collected)
            except asyncio.CancelledError:
                # ASGI 服务器（uvicorn + Starlette）在客户端断开时也会取消响应任务，
                # 与探针发现断开是同一件事：取消上游、记 cancelled、不发事件帧。
                cancelled = True
                partial_chars = sum(len(part) for part in collected)
                raise
            finally:
                # 无论成功失败都要关掉上游流，否则连接泄漏。
                # 取消态下不能 await（会立刻再次抛 CancelledError），改用独立任务兜底，
                # 保证连接一定被释放。
                if cancelled:
                    asyncio.create_task(stream.aclose())
                else:
                    await stream.aclose()

            if cancelled:
                # 客户端已经不在了：不再发 error / done 事件帧，直接收尾。
                return

            if error is not None:
                body = error.to_body(request_id, attempts=len(attempts) + 1)
                yield _sse_event({"type": "error", "error": body})
                yield _sse_event({"type": "done", "finish_reason": "error"})
            else:
                usage = upstream_usage
                if usage is None:
                    # 上游没给 usage 时用本地估算兜底，保证客户端拿到的 usage 字段非空。
                    usage = TokenUsage(
                        output_tokens=self.token_counter.estimate("".join(collected)),
                        total_tokens=self.token_counter.estimate("".join(collected)),
                    )
                total_usage.add(usage)
                yield _sse_event(
                    {
                        "type": "usage",
                        "usage": total_usage.model_dump(),
                        "cost_usd": self.prices.cost(req.model, total_usage),
                    }
                )
                yield _sse_event({"type": "done", "finish_reason": finish_reason})
        finally:
            if watcher is not None:
                watcher.cancel()
            # 限流结算（v2.10）：流式也是「先扣后结算」，流结束就把多预扣的退回。
            self._settle_stream(caller, req, reserved, upstream_usage, "".join(collected))
            pool = self.pools.get(req.model)
            if pool is not None and endpoint is not None:
                if cancelled:
                    # 客户端断开不是端点的错：只归还试探名额，不计失败。
                    pool.release(endpoint)
                elif error is not None:
                    pool.report_failure(endpoint, error)
                else:
                    pool.report_success(endpoint)
            attempts.append(
                AttemptRecord(
                    attempt=len(attempts) + 1,
                    ok=error is None and not cancelled,
                    error_code=error.code.value if error else None,
                    usage=usage or TokenUsage(),
                    prompt_hash=_prompt_hash(req.messages),
                    prompt_strength=0,
                    partial_output_chars=partial_chars,
                    upstream_endpoint=endpoint.name if endpoint else None,
                )
            )
            status = "cancelled" if cancelled else ("error" if error else "success")
            record = self._build_record(
                request_id, req, adapter, started, status,
                error, attempts, total_usage, rendered, template_name, template_version,
                ttft_ms=ttft_ms,
                caller=caller,
                upstream_endpoint=endpoint.name if endpoint else None,
                failover_count=failover_count,
            )
            self._finish(record, error, request_id)
