"""上游端点的熔断状态机（见 DESIGN §7.8.3）。

架构位置：网关「韧性层」里的准入控制组件，作用对象是**上游端点**（不是模型、
不是租户）。编排层在挑端点之前问它「这个端点现在能不能用」。

对应的 Java 概念：≈ Resilience4j 的 `CircuitBreaker`，但只有最核心的
「闭合 / 断开 / 半开」三态，没有滑动窗口计数、没有事件监听器。

三条约定（改这里之前先改设计文档）：
1. 失败计数是**连续失败**：成功一次就清零（§7.8.3）；
2. 只有**上游侧故障**计入失败，内容层错误与本地错误不计（§7.8.4）；
3. 半开状态只放行**一个**试探请求，并发请求不会一起涌向刚恢复的端点。
"""

from __future__ import annotations

import time
from enum import Enum

from core.config import CircuitBreakerConfig
from core.errors import ErrorCode, GatewayError

# 计入熔断的错误码：全是「上游侧故障」。
# 不含 GW_AUTH_ERROR（密钥/权限问题，换端点也没用）、不含内容层错误
# （模型答得不好不代表端点坏了）。
_BREAKER_ERRORS = frozenset(
    {
        ErrorCode.UPSTREAM_ERROR,
        ErrorCode.UPSTREAM_TIMEOUT,
        ErrorCode.MALFORMED_UPSTREAM,
        ErrorCode.UPSTREAM_RATE_LIMITED,
    }
)


class CircuitState(str, Enum):
    """熔断器的三个状态（对应 DESIGN §7.8.3 的表格）。"""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """单个上游端点的熔断状态机。构造后只读配置，状态随调用变化。"""

    def __init__(self, config: CircuitBreakerConfig) -> None:
        self._threshold = config.failure_threshold
        self._cooldown = config.cooldown
        self._enabled = config.enabled
        # 连续失败次数（成功一次就清零）。
        self._failures = 0
        # 进入「断开」的时刻；None = 没断开。
        self._opened_at: float | None = None
        # 半开状态下试探请求是否已被占用（防止并发请求一起涌向刚恢复的端点）。
        self._probe_inflight = False

    @property
    def state(self) -> CircuitState:
        """当前状态（只读，不改变状态机）。"""
        if not self._enabled:
            return CircuitState.CLOSED
        if self._opened_at is None:
            return CircuitState.CLOSED
        if time.monotonic() - self._opened_at >= self._cooldown:
            return CircuitState.HALF_OPEN
        return CircuitState.OPEN

    def acquire(self) -> bool:
        """申请一次使用许可：现在能不能选中这个端点。

        副作用：半开状态下会**占住唯一的试探名额**（返回 True 时名额被本调用
        拿走，直到 report_success / report_failure / release 归还）。

        熔断器关闭时永远返回 True。
        """
        if not self._enabled:
            return True
        if self._opened_at is None:
            return True
        if time.monotonic() - self._opened_at >= self._cooldown:
            # 冷却结束 → 半开：只放行一个试探。
            if self._probe_inflight:
                return False
            self._probe_inflight = True
            return True
        return False

    def report_success(self) -> None:
        """这次调用成功了：清零失败计数，回到闭合状态。"""
        self._probe_inflight = False
        if not self._enabled:
            return
        self._failures = 0
        self._opened_at = None

    def report_failure(self, exc: GatewayError) -> None:
        """这次调用失败了。

        只有**上游侧故障**才计入失败计数；内容层错误（坏 JSON / schema 不匹配）
        与本地错误只归还试探名额，不动熔断状态——把模型答得不好算成端点故障，
        会误伤一个健康的端点。
        """
        self._probe_inflight = False
        if not self._enabled:
            return
        if exc.code not in _BREAKER_ERRORS:
            return
        self._failures += 1
        if self._failures >= self._threshold:
            self._opened_at = time.monotonic()

    def release(self) -> None:
        """归还试探名额，但不计失败。

        用于「客户端断开导致的上游取消」：这不是端点的错，不能因此断开它，
        但半开的试探名额必须还回去，否则这个端点永远等不到下一次试探。
        """
        self._probe_inflight = False
