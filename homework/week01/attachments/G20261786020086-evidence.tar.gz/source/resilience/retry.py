"""指数退避策略。

架构位置：网关「韧性层」的一个小组件，被调用编排层（resilience/pipeline.py）的
重试循环调用，作用只有一个——算出「下一次尝试要等多久」。

对应的 Java 概念：
- 本模块是一个无状态的策略对象（≈ Java 里持有配置字段的普通 bean）。
- `random.uniform(0.0, ceiling)` ≈ Java 的 `ThreadLocalRandom.current().nextDouble(0, ceiling)`。
"""

from __future__ import annotations

import random

from core.config import RetryConfig


class RetryPolicy:
    """计算重试等待时间的策略对象。

    职责：根据「这是第几次失败」和上游可能给出的 `Retry-After`，算出下一次尝试
    之前的等待秒数。本类不发起任何请求，也不关心错误类型。
    """

    def __init__(self, config: RetryConfig | None = None) -> None:
        self.config = config or RetryConfig()

    @property
    def max_attempts(self) -> int:
        """最多尝试次数（含第一次），至少为 1，避免配置成 0 时循环一次都不执行。"""
        return max(1, self.config.max_attempts)

    def delay_for(self, attempt: int, retry_after: float | None = None) -> float:
        """算出等待秒数。

        参数：
        - attempt 为刚刚失败的那次尝试的序号（从 1 开始）。
        - retry_after：上游通过 `Retry-After` 头或错误详情给出的建议等待秒数。

        返回值：等待秒数（float）。

        规则：
        - 上游给了 `retry_after`（>= 0）就**完全听它的**，不再叠加指数退避——
          这是避免被上游限流时加剧拥塞的关键。
        - 否则按指数退避：base * 2^(attempt-1)，并以 `max_delay` 封顶。
        - jitter == "equal" 时不加随机抖动（退避值固定）；默认的 "full" 是
          full jitter：在 [0, ceiling] 之间**随机**取值，好处是多个客户端不会
          在同一时刻一起重试形成尖峰（≈ Java 的 Randomized 负载均衡思路）。

        不抛异常。
        """
        if retry_after is not None and retry_after >= 0:
            return retry_after
        ceiling = min(self.config.base_delay * (2 ** (attempt - 1)), self.config.max_delay)
        if self.config.jitter == "equal":
            return min(self.config.base_delay * (2 ** (attempt - 1)), self.config.max_delay)
        return random.uniform(0.0, ceiling)
