"""按 (租户, 模型) 隔离的 rpm + tpm 双维令牌桶。

架构位置：网关「韧性层」中的准入控制组件，在调用编排层发起上游调用**之前**被
调用，判断这一次请求是否还有配额。

对应的 Java 概念：
- 令牌桶 ≈ Guava 的 `RateLimiter` / Resilience4j 的 `RateLimiter`，区别是这里用
  「惰性补充」的方式算令牌（不靠后台线程）。
- `time.monotonic()` ≈ Java 的 `System.nanoTime()`，单调时钟，不受系统时间调整
  影响；这里**不能**用 `time.time()`。
- `threading.Lock` ≈ Java 的 `synchronized` 块；这里锁的粒度是「每个 (租户, 模型)
  一把」，临界区里没有 `await`（见 DESIGN §7.3 为什么不用 `asyncio.Lock`）。

重要限制：所有状态都在进程内存里，多实例部署时每个实例各算各的，实际总配额会
是 N 倍，需要换成 Redis 等共享存储实现。
"""

from __future__ import annotations

import threading
import time
from typing import Callable

from core.config import RateLimitConfig
from core.errors import ErrorCode, GatewayError


class TokenBucket:
    """单个维度的令牌桶（容量 + 每秒补充速率）。

    「惰性补充」：不跑后台线程刷新，而是在每次操作前根据距上次操作的时间算
    应该补多少，所以不会有定时任务带来的额外开销。
    """

    def __init__(self, capacity: int, refill_per_second: float) -> None:
        self.capacity = max(0, capacity)
        # 下限 0.0001 是为了防止 refill_per_second 为 0 时除零（无限等待）。
        self.refill_per_second = max(refill_per_second, 0.0001)
        # 初始时桶是满的。
        self.tokens = float(self.capacity)
        self.updated_at = time.monotonic()

    def _refill(self) -> None:
        """按经过的时间补充令牌，上限不超过容量。"""
        now = time.monotonic()
        self.tokens = min(
            self.capacity, self.tokens + (now - self.updated_at) * self.refill_per_second
        )
        self.updated_at = now

    def peek(self, amount: float) -> float | None:
        """额度不足时返回需要等待的秒数，充足返回 None。

        只查询不扣减，≈ Java 的「tryAcquire 的 dry-run 版本」。
        """
        self._refill()
        if self.tokens >= amount:
            return None
        return (amount - self.tokens) / self.refill_per_second

    def consume(self, amount: float) -> None:
        """扣减令牌，扣到 0 为止（不会扣成负数）。"""
        self._refill()
        self.tokens = max(0.0, self.tokens - amount)

    def refund(self, amount: float) -> None:
        """退还令牌（预扣后按真实用量结算时用），不超过容量。"""
        self._refill()
        self.tokens = min(self.capacity, self.tokens + amount)


class ModelLimiter:
    """单个模型的限流器：两个桶——请求数桶（rpm）与 token 桶（tpm）。

    rpm / tpm 都是「每分钟」的配额，所以补充速率要除以 60 换算成「每秒」。

    锁的粒度是**一个限流器一把**：准入（查 + 扣）必须在同一个临界区里完成，
    否则两个线程可能都查到「还有额度」然后都扣，额度就被超发了。
    """

    def __init__(self, config: RateLimitConfig) -> None:
        self.requests = TokenBucket(config.rpm, config.rpm / 60.0)
        self.tokens = TokenBucket(config.tpm, config.tpm / 60.0)
        self._lock = threading.Lock()

    def acquire(self, tokens: int) -> float | None:
        """尝试准入：额度充足就扣掉并返回 None；不足则返回需要等待的秒数（不扣）。

        「查 + 扣」在同一个临界区里完成——这是限流器唯一的正确性要求。
        """
        with self._lock:
            waits = [
                wait
                for wait in (
                    self.requests.peek(1),
                    self.tokens.peek(max(0, tokens)),
                )
                if wait is not None
            ]
            if waits:
                return max(waits)
            self.requests.consume(1)
            self.tokens.consume(max(0, tokens))
            return None

    def refund(self, tokens: int) -> None:
        """退还令牌（预扣后按真实用量结算时用）。"""
        if tokens <= 0:
            return
        with self._lock:
            self.tokens.refund(tokens)

    def remaining(self) -> float:
        """桶里还剩多少 token（可观测用）。"""
        with self._lock:
            self.tokens._refill()
            return self.tokens.tokens

    def penalize(self, tokens: int) -> None:
        """惩罚性扣减（上游 429 时用）。"""
        if tokens <= 0:
            return
        with self._lock:
            self.tokens.consume(tokens)


class RateLimiter:
    """按 **(租户, 模型)** 隔离的限流器。进程内实现，多实例部署需换 Redis。

    两个维度必须同时满足才放行：rpm（每分钟请求数）和 tpm（每分钟 token 数）。

    桶的**配额由外部解析**（`resolve(caller, model) -> RateLimitConfig | None`），
    限流器只管计数——这样租户的三级回退逻辑（见 DESIGN §7.6.2）留在租户层，
    限流器不必知道「租户」这个概念。
    """

    def __init__(self, resolve: Callable[[str, str], RateLimitConfig | None]) -> None:
        self._resolve = resolve
        self._limiters: dict[tuple[str, str], ModelLimiter] = {}
        # 只保护「限流器字典」本身：两个线程同时为同一个 (租户, 模型) 建限流器时，
        # 后建的会被丢弃，先建的那个继续用（桶不会凭空多出一份额度）。
        self._registry_lock = threading.Lock()

    def _limiter(self, caller: str, model: str) -> ModelLimiter | None:
        """取 (租户, 模型) 的限流器；解析不出配额返回 None（表示不限流）。"""
        key = (caller, model)
        limiter = self._limiters.get(key)
        if limiter is None:
            config = self._resolve(caller, model)
            if config is None:
                return None
            limiter = ModelLimiter(config)
            with self._registry_lock:
                existing = self._limiters.get(key)
                if existing is not None:
                    return existing
                self._limiters[key] = limiter
        return limiter

    def consume(self, caller: str, model: str, tokens: int) -> None:
        """准入并扣减额度。额度不足立即抛 429。

        参数：
        - caller：租户标识。
        - model：模型别名。
        - tokens：本次预估要消耗的 token 数。

        抛 GatewayError(ErrorCode.RATE_LIMITED)：任一维度额度不足。此时
        `details["retry_after"]` 给出建议等待秒数（两个维度取较大者），
        响应层会把它渲染成 `Retry-After` 头（见 DESIGN §8.1.4）。
        """
        limiter = self._limiter(caller, model)
        if limiter is None:
            return
        retry_after = limiter.acquire(tokens)
        if retry_after is not None:
            raise GatewayError(
                ErrorCode.RATE_LIMITED,
                f"rate limit exceeded for caller '{caller}' on model '{model}'",
                details={"retry_after": round(retry_after, 3)},
            )

    def settle(
        self, caller: str, model: str, reserved_tokens: int, actual_tokens: int
    ) -> None:
        """按实际用量结算，把多预扣的额度退回。

        调用前先按「预估输出上限」预扣了 token，实际调用往往用不到那么多，
        所以要把差额退还，避免额度被慢慢吃光。只会退不会补（实际用量超过预扣
        时不额外扣）。
        """
        limiter = self._limiter(caller, model)
        if limiter is None:
            return
        limiter.refund(reserved_tokens - actual_tokens)

    def penalize(self, caller: str, model: str, tokens: int) -> None:
        """上游返回 429 时的惩罚性扣减。

        上游自己限流说明我们的请求太密集，这里额外扣减本地额度作为惩罚，
        逼着调用方自动降速。不会抛异常。

        扣减量由调用方给出：编排层传的是**该次尝试预扣的 token 数**
        （见 DESIGN §7.3）。
        """
        limiter = self._limiter(caller, model)
        if limiter is None:
            return
        limiter.penalize(tokens)

    def remaining(self, caller: str, model: str) -> float | None:
        """桶里还剩多少 token；该 (租户, 模型) 不限流时返回 None。

        供测试观察「预扣 / 结算 / 惩罚扣减」的实际效果（见 DESIGN §7.3）。
        """
        limiter = self._limiter(caller, model)
        if limiter is None:
            return None
        return limiter.remaining()
