"""Token 估算器。启发式实现，接口独立，后续可替换为 tiktoken。

架构位置：网关「韧性层」中的计量辅助件，被调用编排层用来做 tpm 限流预扣和
用量兜底估算。

对应的 Java 概念：
- 本模块是一个纯函数式的估算器，无状态、可安全共享。
- `unicodedata.east_asian_width` ≈ Java 的 `Character.getType` / ICU 的
  `EastAsianWidth` 判定。

注意：这是**估算**不是精确计数，结果只用于限流和展示，不用于计费。
"""

from __future__ import annotations

import math
import unicodedata

from core.config import TokenCounterConfig


def _is_cjk(ch: str) -> bool:
    """判断单个字符是否按 CJK 规则计数。

    判据是 Unicode 的「东亚宽度」为 W（宽，Wide）或 F（全宽，Fullwidth），
    典型如汉字、日文假名、韩文、全角标点。ASCII 字符一律不算 CJK。
    """
    if not ch.isascii():
        return unicodedata.east_asian_width(ch) in ("W", "F")
    return False


class TokenCounter:
    """按启发式规则估算文本的 token 数。

    规则：CJK 字符按 `cjk_per_token`（默认 1 字 ≈ 1 token）折算，其余字符按
    `chars_per_token`（默认 4 字符 ≈ 1 token）折算，最后向上取整，且最少为 1。
    """

    def __init__(self, config: TokenCounterConfig | None = None) -> None:
        self.config = config or TokenCounterConfig()

    def estimate(self, text: str) -> int:
        """估算一段文本的 token 数。

        返回值：token 数（int）。空串返回 0；非空结果至少为 1。
        不抛异常。
        """
        if not text:
            return 0
        cjk = 0
        other = 0
        for ch in text:
            if _is_cjk(ch):
                cjk += 1
            else:
                other += 1
        # max(..., 0.0001) 防止配置的每 token 字符数被设成 0 时除零。
        tokens = cjk / max(self.config.cjk_per_token, 0.0001)
        tokens += other / max(self.config.chars_per_token, 0.0001)
        return max(1, math.ceil(tokens))

    def estimate_messages(self, contents: list[str]) -> int:
        """估算多段文本的 token 总数（≈ Java 里对 Stream 求和）。"""
        return sum(self.estimate(content) for content in contents)
