"""配置装载：把 config.toml（TOML）+ 环境变量读成一个强类型 Settings 对象。

在整体架构中的位置：这是全网关的唯一配置入口，core 层以下的模块都只从 Settings 取参数，
不再各自去读文件或环境变量，便于测试时整体替换配置。

对应的 Java 概念：这里的 pydantic.BaseModel ≈ 「带运行时校验的 Java POJO/record」——
Settings 相当于一个用 @ConfigurationProperties 绑定后的配置根对象；
tomllib ≈ Java 的 properties 加载器（这里是标准库自带，无需第三方依赖）；
环境变量读法 ≈ System.getenv。
"""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from core.secrets import load_env_file, resolve_api_key


class RetryConfig(BaseModel):
    """重试策略。jitter="full" 表示在每次退避延时上叠加 [0, delay) 的随机抖动，
    目的是让多个并发请求不要在同一时刻一起重试把上游打爆（惊群效应）。
    """

    max_attempts: int = 3
    base_delay: float = 0.5
    max_delay: float = 8.0
    jitter: str = "full"


class TimeoutConfig(BaseModel):
    """各级超时（单位：秒）。

    deadline 是整次调用的总预算；attempt 是单次尝试；first_token 等首 token；
    stream_idle 是流式过程中两个事件之间的最大空闲；connect/write 是建连与写请求的耗时。
    分层设置是为了能区分「上游慢」和「上游根本没接」。
    """

    deadline: float = 30.0
    attempt: float = 10.0
    first_token: float = 60.0
    stream_idle: float = 60.0
    connect: float = 3.0
    write: float = 3.0


class StructuredOutputConfig(BaseModel):
    """结构化输出策略。repair 控制是否做本地 JSON 修复，content_retry 控制是否在
    内容层重试（把上一次的坏输出贴回给模型让它自己改），max_prompt_strength 是允许的最大加强档位。
    """

    repair: bool = True
    content_retry: bool = True
    max_prompt_strength: int = 2


class RateLimitConfig(BaseModel):
    """单个模型的限流：rpm = 每分钟请求数，tpm = 每分钟 token 数。"""

    rpm: int = 60
    tpm: int = 60_000


class GlobalRateLimitConfig(BaseModel):
    """全局限流策略。

    `penalize_on_upstream_429` 决定收到上游 429 时，是否额外对本地的 tpm 桶做一次
    惩罚性扣减（扣减量 = 该次尝试预扣的 token 数，见 DESIGN §7.3）。
    默认关闭：上游偶发抖动时，惩罚扣减会连带吃掉后续请求的额度。
    """

    penalize_on_upstream_429: bool = False


class TokenCounterConfig(BaseModel):
    """本地 token 估算参数（用于在真正调用前预估长度、提前触发限流）。
    cjk_per_token 是每个中文字约折算几个 token，chars_per_token 是每个西文字符折算几个 token。
    """

    cjk_per_token: float = 1.0
    chars_per_token: float = 4.0


class AuthKeyConfig(BaseModel):
    """一个调用方的 API Key 条目。

    `key_env` 存的是环境变量名而不是密钥本身——密钥不进配置文件、不进版本库，
    与 `ModelConfig.api_key_env` 是同一条纪律。
    """

    name: str = Field(min_length=1, max_length=64)
    key_env: str = Field(min_length=1, max_length=128)


class AuthConfig(BaseModel):
    """站点鉴权配置（见 DESIGN §8.6）。

    enabled = false（默认）表示不鉴权，此时所有调用方的标识统一是 anonymous。
    enabled = true 但没配 key —— 那是「既开又开」，在启动时就该失败，
    因此这个检查放在 `core/security.py` 的 Authenticator 构造里。
    """

    enabled: bool = False
    keys: list[AuthKeyConfig] = Field(default_factory=list)


class TenantConfig(BaseModel):
    """单个租户的配置（见 DESIGN §7.6）。

    admin：管理员租户可以看全局的调用记录与指标（见 §7.6.5）。
    models：可见模型白名单；None = 全部可见。
    rate_limit：该租户的统一配额覆盖；None = 用模型默认配额。
    model_rate_limit：按模型的配额覆盖，优先级高于 rate_limit。
    """

    admin: bool = False
    models: list[str] | None = None
    rate_limit: RateLimitConfig | None = None
    model_rate_limit: dict[str, RateLimitConfig] = Field(default_factory=dict)


class PricingConfig(BaseModel):
    """单个模型的价目表（见 DESIGN §7.7.1）。

    单位统一是 **USD / 每百万 token**。三个字段都可以省略，省略的按 0 计
    （`cached_input` 省略时按 `input` 计，见 §7.7.2）。

    价格为负数 → 配置校验失败 → 启动失败。宁可起不来，也不要算出一笔负成本。
    """

    input: float = Field(default=0.0, ge=0)
    output: float = Field(default=0.0, ge=0)
    cached_input: float | None = Field(default=None, ge=0)


class UpstreamEndpointConfig(BaseModel):
    """一个上游端点（见 DESIGN §7.8.1）。

    同一个模型可以配多个端点，**配置顺序 = 优先级**：先选前面的。
    name 是端点的标识，会出现在调用记录里（upstream_endpoint）；不填就用
    base_url 代替。

    api_key_env / api_key_file 存的是**去哪取密钥**而不是密钥本身——
    与 ModelConfig 同一条纪律，来源与优先级见 DESIGN §7.9。
    """

    name: str | None = None
    base_url: str
    upstream_id: str | None = None
    api_key_env: str | None = None
    api_key_file: str | None = None

    def api_key(self) -> str | None:
        """取该端点的密钥：环境变量 → 密钥文件 → None。"""
        return resolve_api_key(self.api_key_env, self.api_key_file)


class CircuitBreakerConfig(BaseModel):
    """上游端点的熔断参数（见 DESIGN §7.8.1 / §7.8.3）。

    failure_threshold：连续失败达到该次数 → 断开该端点。
    cooldown：断开后经过多少秒 → 进入半开（放行一次试探）。
    enabled=false 时熔断器整体关闭，退化成「只有 failover、没有熔断」。
    """

    enabled: bool = True
    failure_threshold: int = Field(default=5, ge=1)
    cooldown: float = Field(default=30.0, ge=0)


class StorageConfig(BaseModel):
    """本地存储目录（提示词模板等）。"""

    data_dir: str = "./storage"


class ServerConfig(BaseModel):
    """HTTP 服务监听配置。"""

    host: str = "127.0.0.1"
    port: int = 8000
    log_level: str = "INFO"


class ModelConfig(BaseModel):
    """单个模型的配置项。注意这个类名里的 "Model" 指的是「被调用的模型」，
    与 pydantic 内部所说的 model config（模型行为配置）是两回事，容易混淆。

    api_key_env / api_key_file 存的是**去哪取密钥**而不是密钥本身，
    避免密钥落进配置文件或版本库；来源与优先级见 DESIGN §7.9。
    """

    base_url: str
    upstream_id: str
    enabled: bool = True
    api_key_env: str | None = None
    api_key_file: str | None = None
    default_max_tokens: int | None = None
    max_input_tokens: int | None = None
    extra_body: dict[str, Any] = Field(default_factory=dict)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)
    # 价目表；None = 该模型未定价（成本记为 null，不是 0，见 DESIGN §7.7.1）。
    pricing: PricingConfig | None = None
    # 多上游端点；为空 = 沿用上面的单端点写法（见 DESIGN §7.8.1）。
    upstreams: list[UpstreamEndpointConfig] = Field(default_factory=list)

    def api_key(self) -> str | None:
        """取该模型的上游密钥：环境变量 → 密钥文件 → None。

        都没配时返回 None（该上游不需要鉴权，比如本地部署的模型）；
        配了却读不到时，由启动期的密钥校验抛错（见 DESIGN §7.9.3）。
        """
        return resolve_api_key(self.api_key_env, self.api_key_file)


class EnvConfig(BaseModel):
    """`.env` 文件的位置（见 DESIGN §7.9.2）。

    `file` 相对进程工作目录；配空串 = 不加载。
    加载语义是**只补不覆盖**：已存在的环境变量优先，
    所以容器编排注入的值不会被仓库里的 `.env` 改掉。
    """

    file: str = ".env"


class Settings(BaseModel):
    """配置根对象，一个 TOML 文件对应它的一个实例。

    所有嵌套段都用 default_factory 兜底，因此即使 config.toml 只写了一小节，
    也能构造出完整对象——相当于 Java 里给 @ConfigurationProperties 的每个字段都配了默认值。
    """

    server: ServerConfig = Field(default_factory=ServerConfig)
    env: EnvConfig = Field(default_factory=EnvConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    retry: RetryConfig = Field(default_factory=RetryConfig)
    timeout: TimeoutConfig = Field(default_factory=TimeoutConfig)
    structured_output: StructuredOutputConfig = Field(default_factory=StructuredOutputConfig)
    rate_limit: GlobalRateLimitConfig = Field(default_factory=GlobalRateLimitConfig)
    circuit_breaker: CircuitBreakerConfig = Field(default_factory=CircuitBreakerConfig)
    auth: AuthConfig = Field(default_factory=AuthConfig)
    tenants: dict[str, TenantConfig] = Field(default_factory=dict)
    token_counter: TokenCounterConfig = Field(default_factory=TokenCounterConfig)
    models: dict[str, ModelConfig] = Field(default_factory=dict)

    @property
    def data_dir(self) -> Path:
        """数据目录的 Path 对象。

        @property ≈ Java 的 getter 方法，但调用时写作 settings.data_dir 而非 getDataDir()。
        """
        return Path(self.storage.data_dir)


def load_settings(config_path: str | Path = "config.toml") -> Settings:
    """读取配置文件并校验成 Settings。

    文件不存在时不报错，返回全默认配置（相当于 Java 里 @ConfigurationProperties 的宽松模式），
    这样本地起服务不需要先造一个 config.toml。

    读取用二进制模式 "rb"：tomllib 要求二进制流，纯文本模式在某些平台会带上编码声明前缀。

    `.env` 在这里加载（DESIGN §7.9.2）：先读 TOML 拿到 `[env].file`，
    再把 `.env` 里的键值补进环境变量，**最后**才校验成 Settings——
    这样 `api_key_env` 指向的变量可以来自 `.env`。
    """
    path = Path(config_path)
    raw: dict[str, Any] = {}
    if path.exists():
        with path.open("rb") as fh:
            raw = tomllib.load(fh)

    env_file = (raw.get("env") or {}).get("file", ".env")
    load_env_file(env_file)

    raw.setdefault("models", {})
    return Settings.model_validate(raw)


def validate_upstream_secrets(settings: Settings) -> None:
    """启动期校验上游密钥：配了来源却读不到 → 抛错，让进程起不来。

    与入站鉴权同一条纪律（DESIGN §8.6.3）：配置错误在启动时暴露，
    好过运行期才收到上游 401、再被翻译成一个含义模糊的 502
    `GW_AUTH_ERROR`（那正是 v2.13 接入真机时踩到的坑，见 DESIGN §7.9）。

    两种失败：
    - 文件不存在 / 为空 → 报错点名文件路径；
    - 环境变量没设（且没有文件兜底）→ 报错点名变量名。
    """
    for alias, cfg in settings.models.items():
        if not cfg.enabled:
            continue
        _check_secret(alias, cfg.api_key_env, cfg.api_key_file)
        for endpoint in cfg.upstreams:
            label = f"{alias}/{endpoint.name or endpoint.base_url}"
            _check_secret(label, endpoint.api_key_env, endpoint.api_key_file)


def _check_secret(label: str, env_name: str | None, file_path: str | None) -> None:
    """校验单个密钥来源；没配来源 = 该上游不需要鉴权，直接放过。"""
    if not env_name and not file_path:
        return
    try:
        key = resolve_api_key(env_name, file_path)
    except (OSError, ValueError) as exc:
        raise ValueError(f"model '{label}': {exc}") from exc
    if not key:
        detail = f"api_key_env '{env_name}' is not set"
        if file_path:
            detail += f" and api_key_file '{file_path}' is unavailable"
        raise ValueError(f"model '{label}': {detail}")
