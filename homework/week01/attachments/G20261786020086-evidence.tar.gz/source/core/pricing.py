"""价目表：把 token 用量换算成成本（见 DESIGN §7.7）。

架构位置：网关的「计价层」，纯函数、无状态。编排层在计量之后问它要成本，
编排层自己不懂价目表，也不碰配置。

对应的 Java 概念：`PriceTable` ≈ 一个只读的 `Map<String, Pricing>`；`cost()`
是纯函数，≈ Java 的静态工具方法。

三条约定（与 DESIGN §7.7.2 一致，改这里之前先改设计文档）：
1. 推理 token 已包含在 `output_tokens` 里 → 按 output 价计，不重复计；
2. `cache_read_tokens` 与 `input_tokens` 不重叠 → 缓存部分不会被算两遍；
3. 缓存写入（`cache_write_tokens`）按 `input` 价计（见 §7.7.2 第 3 条）。
"""

from __future__ import annotations

from core.config import PricingConfig
from core.types import TokenUsage

# 计价单位是「每百万 token」，所以要先除以这个数。
_TOKENS_PER_PRICE_UNIT = 1_000_000

# 对外保留的小数位：1e-6 USD。低于这个粒度的金额没有实际意义。
_COST_PRECISION = 6


class PriceTable:
    """按模型别名的价目表。构造后只读，可以被所有请求并发使用。"""

    def __init__(self, pricing: dict[str, PricingConfig] | None = None) -> None:
        self._pricing = pricing or {}

    def cost(self, model: str, usage: TokenUsage) -> float | None:
        """算这次用量的成本（USD）。

        返回 None 表示**该模型未定价**——不是「免费」。两者必须能区分：
        「免费」是明确的结论，「未定价」是没数据。

        口径与 `usage` 一致：调用方传进来的 usage 是「所有尝试之和」，
        因此重试产生的 token 消耗也一并计入成本（见 DESIGN §7.7.3）。
        """
        prices = self._pricing.get(model)
        if prices is None:
            return None
        cached_price = (
            prices.input if prices.cached_input is None else prices.cached_input
        )
        usd = (
            usage.input_tokens * prices.input
            + usage.output_tokens * prices.output
            + usage.cache_read_tokens * cached_price
            + usage.cache_write_tokens * prices.input
        ) / _TOKENS_PER_PRICE_UNIT
        return round(usd, _COST_PRECISION)
