"""入站鉴权：API Key 的比对与调用方识别（见 DESIGN §8.6）。

在整体架构中的位置：网关的「门口」。请求进来先过这里，通过了才有资格进入
路由层去解析请求体、扣限流配额、发上游请求。

对应的 Java 概念：
- `Authenticator` ≈ Spring Security 的 `OncePerRequestFilter` + `UserDetailsService`
  的合体；但这里刻意**不**用 Spring 那种「认证结果塞进 SecurityContext」的框架，
  而是直接把一个 `Principal` 放进 ASGI 的 `scope["state"]`，由路由层按需取用。
- `Principal` ≈ 「已认证的用户」：这里只有两个字段——名字（调用方标识）与
  指纹（密钥的 sha256 前 16 位），**不含密钥本身**。

两条纪律：
1. 密钥只在内存里存在，不写日志、不写调用记录、不回显。
2. 比对必须是常数时间，且遍历所有 key 时不能提前退出（见 `authenticate`）。
"""

from __future__ import annotations

import hashlib
import hmac
import os
from dataclasses import dataclass

from core.config import AuthConfig


@dataclass(frozen=True)
class Principal:
    """一个通过鉴权的调用方。

    name 是配置里写的调用方标识（会出现在调用记录里）；
    fingerprint 是密钥的 sha256 前 16 位，用来在不泄露密钥的前提下
    关联「这次调用用的是哪把钥匙」。frozen ≈ Java 的 record（不可变）。
    """

    name: str
    fingerprint: str


# 未开启鉴权时的默认调用方。相当于「匿名用户」。
ANONYMOUS = Principal(name="anonymous", fingerprint="")


def fingerprint(key: str) -> str:
    """算密钥指纹：sha256 前 16 位（十六进制）。

    16 位 = 64 bit，足够在「同一个站点有几十把钥匙」的量级下唯一定位一把钥匙，
    又短到可以直接出现在日志与调用记录里。
    """
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


class Authenticator:
    """站点 API Key 校验器。

    `enabled = False` 时不做任何校验，一律放行并返回 ANONYMOUS；
    `enabled = True` 时必须至少配一把 key——「开了鉴权却一把钥匙都没有」
    是配置错误，在构造时（=启动时）就该失败，而不是运行期永远 401。
    """

    def __init__(self, *, enabled: bool, entries: list[tuple[str, str]]) -> None:
        self.enabled = enabled
        # 预编码成 bytes：hmac.compare_digest 对 bytes 没有非 ASCII 的限制，
        # 对 str 遇到非 ASCII 会直接抛 TypeError。
        self._entries: list[tuple[str, bytes, str]] = [
            (name, key.encode("utf-8"), fingerprint(key)) for name, key in entries
        ]

    @classmethod
    def from_config(cls, config: AuthConfig) -> "Authenticator":
        """按配置构造校验器。

        密钥在**启动时**从环境变量读取：读不到就抛异常，让进程起不来。
        这比「运行期才发现鉴权永远通不过」好得多——后者会让人以为网关坏了。
        """
        if not config.enabled:
            return cls(enabled=False, entries=[])
        if not config.keys:
            raise ValueError("auth.enabled is true but no auth.keys are configured")

        entries: list[tuple[str, str]] = []
        for item in config.keys:
            key = os.environ.get(item.key_env)
            if not key:
                raise ValueError(
                    f"auth key '{item.name}': environment variable "
                    f"'{item.key_env}' is not set"
                )
            entries.append((item.name, key))
        return cls(enabled=True, entries=entries)

    def authenticate(self, authorization: str | None) -> Principal | None:
        """校验 `Authorization` 头，通过返回 Principal，不通过返回 None。

        形如 `Bearer <api_key>`。scheme 大小写不敏感（HTTP 规定如此），
        token 前后允许有空格。

        「没带」与「带错了」返回同一个结果（None），上层据此渲染**完全相同**的
        401 响应体——不给调用方一个「这个 key 存在但只是不对」的预言机。
        """
        if not self.enabled:
            return ANONYMOUS
        if not authorization:
            return None

        scheme, _, token = authorization.partition(" ")
        if scheme.lower() != "bearer":
            return None
        token = token.strip()
        if not token:
            return None

        raw = token.encode("utf-8")
        matched: Principal | None = None
        for name, key, digest in self._entries:
            # 刻意**不** break：命中第 1 把钥匙比命中第 8 把钥匙快，
            # 本身就是信息泄露（能据此枚举出哪把钥匙是有效的）。
            # compare_digest 是常数时间的，所以「比对全部钥匙」的开销可接受。
            if hmac.compare_digest(raw, key):
                matched = Principal(name, digest)
        return matched
