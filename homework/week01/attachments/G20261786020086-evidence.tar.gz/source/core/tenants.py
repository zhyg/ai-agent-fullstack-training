"""租户注册表：谁能看到哪些模型、能用多少配额、是不是管理员。

架构位置：网关的「租户层」。它把 `[tenants.*]` 的配置与模型默认配额合成为
一组查询：可见性、配额、身份特权。编排层与 HTTP 层都问它，不各自读配置。

对应的 Java 概念：`TenantRegistry` ≈ Spring Security 的 `RoleHierarchy` +
资源授权表的合体；查询方法都是纯函数，没有状态。

三条约定（见 DESIGN §7.6）：
1. **没有配置的租户** = 全部模型可见 + 模型默认配额 + 非管理员。
   这条默认让「只开鉴权、不做隔离」的配置零成本可用。
2. **可见性用「不存在」表达**：无权访问的模型一律 404，而不是 403——
   403 会泄露模型目录。
3. **配额按 (租户, 模型) 分桶**，三级回退：按模型覆盖 > 租户统一 > 模型默认。
"""

from __future__ import annotations

from core.config import RateLimitConfig, TenantConfig


class TenantRegistry:
    """租户配置查询表。构造后只读，可以被所有请求并发使用。"""

    def __init__(
        self,
        tenants: dict[str, TenantConfig] | None = None,
        model_limits: dict[str, RateLimitConfig] | None = None,
    ) -> None:
        self._tenants = tenants or {}
        self._model_limits = model_limits or {}

    def config(self, caller: str) -> TenantConfig | None:
        """取租户配置；未配置的租户返回 None（表示「用默认行为」）。"""
        return self._tenants.get(caller)

    def is_admin(self, caller: str) -> bool:
        """该租户是不是管理员（可见全局数据，见 DESIGN §7.6.5）。"""
        config = self._tenants.get(caller)
        return bool(config and config.admin)

    def allows(self, caller: str, model: str) -> bool:
        """该租户能不能用这个模型。

        白名单为空（未配置）= 全部可见。
        """
        config = self._tenants.get(caller)
        if config is None or config.models is None:
            return True
        return model in config.models

    def visible_models(self, caller: str, models: list[str]) -> list[str]:
        """把模型清单收窄成该租户可见的部分（顺序保持不变）。"""
        config = self._tenants.get(caller)
        if config is None or config.models is None:
            return list(models)
        allowed = set(config.models)
        return [model for model in models if model in allowed]

    def quota(self, caller: str, model: str) -> RateLimitConfig | None:
        """取 (租户, 模型) 的实际配额；None 表示不限流。

        三级回退（见 DESIGN §7.6.2）：
        1. `tenants.<租户>.model_rate_limit.<模型>`
        2. `tenants.<租户>.rate_limit`
        3. `models.<模型>.rate_limit`
        """
        config = self._tenants.get(caller)
        if config is not None:
            override = config.model_rate_limit.get(model)
            if override is not None:
                return override
            if config.rate_limit is not None:
                return config.rate_limit
        return self._model_limits.get(model)
