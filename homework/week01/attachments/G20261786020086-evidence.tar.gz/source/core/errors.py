"""统一错误码体系：一个 ErrorCode 决定 HTTP 状态码、error.type 和是否重试。

在整体架构中的位置：网关内部任何地方出错都抛 GatewayError，由最外层统一转成网关自有的
错误响应体。调用方（SDK / 客户端）只看 code 和 type，不用理解内部模块划分。

对应的 Java 概念：ErrorCode 是 `str, Enum` ≈ 「Java enum，但成员值就是那个字符串」
（所以 GatewayError 里用 self.code.value 拿到的就是 "GW_XXX" 这种字面量）；
下方的三个字典相当于 Java enum 里的静态查表方法，只是这里拆成了模块级常量。
"""

from __future__ import annotations

from enum import Enum


class ErrorCode(str, Enum):
    """全网关唯一的错误码枚举。名字本身是语义，值是线上协议里对外暴露的字符串，
    一旦发布就不能随意改动。
    """

    INVALID_REQUEST = "GW_INVALID_REQUEST"
    CAPABILITY_UNSUPPORTED = "GW_CAPABILITY_UNSUPPORTED"
    MODEL_NOT_FOUND = "GW_MODEL_NOT_FOUND"
    TEMPLATE_NOT_FOUND = "GW_TEMPLATE_NOT_FOUND"
    TEMPLATE_VAR_MISSING = "GW_TEMPLATE_VAR_MISSING"
    TEMPLATE_VAR_UNUSED = "GW_TEMPLATE_VAR_UNUSED"
    TEMPLATE_VAR_UNDECLARED = "GW_TEMPLATE_VAR_UNDECLARED"
    AUTH_ERROR = "GW_AUTH_ERROR"
    UPSTREAM_REJECTED = "GW_UPSTREAM_REJECTED"
    UNAUTHORIZED = "GW_UNAUTHORIZED"
    MALFORMED_UPSTREAM = "GW_MALFORMED_UPSTREAM"
    INVALID_JSON = "GW_INVALID_JSON"
    SCHEMA_MISMATCH = "GW_SCHEMA_MISMATCH"
    RATE_LIMITED = "GW_RATE_LIMITED"
    UPSTREAM_RATE_LIMITED = "GW_UPSTREAM_RATE_LIMITED"
    UPSTREAM_TIMEOUT = "GW_UPSTREAM_TIMEOUT"
    UPSTREAM_ERROR = "GW_UPSTREAM_ERROR"
    UPSTREAM_UNAVAILABLE = "GW_UPSTREAM_UNAVAILABLE"
    INTERNAL_ERROR = "GW_INTERNAL_ERROR"


# 错误码 → HTTP 状态码。相当于 Java 里一个 static Map<ErrorCode, Integer>，
# 用模块级私有常量（下划线开头）表示「不对外暴露」。
_HTTP_STATUS: dict[ErrorCode, int] = {
    ErrorCode.INVALID_REQUEST: 400,
    ErrorCode.CAPABILITY_UNSUPPORTED: 400,
    ErrorCode.MODEL_NOT_FOUND: 404,
    ErrorCode.TEMPLATE_NOT_FOUND: 404,
    ErrorCode.TEMPLATE_VAR_MISSING: 400,
    ErrorCode.TEMPLATE_VAR_UNUSED: 400,
    ErrorCode.TEMPLATE_VAR_UNDECLARED: 400,
    ErrorCode.AUTH_ERROR: 502,
    ErrorCode.UPSTREAM_REJECTED: 502,
    ErrorCode.UNAUTHORIZED: 401,
    ErrorCode.MALFORMED_UPSTREAM: 502,
    ErrorCode.INVALID_JSON: 502,
    ErrorCode.SCHEMA_MISMATCH: 502,
    ErrorCode.RATE_LIMITED: 429,
    ErrorCode.UPSTREAM_RATE_LIMITED: 429,
    ErrorCode.UPSTREAM_TIMEOUT: 504,
    ErrorCode.UPSTREAM_ERROR: 502,
    ErrorCode.UPSTREAM_UNAVAILABLE: 503,
    ErrorCode.INTERNAL_ERROR: 500,
}

# 错误码 → error.type 字符串，与 HTTP 状态码是两个正交维度：
# 同一个 type 可以对应不同的 HTTP 码（如 MODEL_NOT_FOUND 是 404，INVALID_REQUEST 是 400，
# 但两者 type 都是 invalid_request）。
#
# type 取值全部**中立化**，不带任何厂商词汇（v1.1 用的是 OpenAI 的 *_error 后缀）：
# invalid_request | capability | authentication | upstream | model_output |
# rate_limit | timeout | internal
_ERROR_TYPE: dict[ErrorCode, str] = {
    ErrorCode.INVALID_REQUEST: "invalid_request",
    ErrorCode.CAPABILITY_UNSUPPORTED: "capability",
    ErrorCode.MODEL_NOT_FOUND: "invalid_request",
    ErrorCode.TEMPLATE_NOT_FOUND: "invalid_request",
    ErrorCode.TEMPLATE_VAR_MISSING: "invalid_request",
    ErrorCode.TEMPLATE_VAR_UNUSED: "invalid_request",
    ErrorCode.TEMPLATE_VAR_UNDECLARED: "invalid_request",
    ErrorCode.AUTH_ERROR: "authentication",
    ErrorCode.UPSTREAM_REJECTED: "upstream",
    ErrorCode.UNAUTHORIZED: "authentication",
    ErrorCode.MALFORMED_UPSTREAM: "upstream",
    ErrorCode.INVALID_JSON: "model_output",
    ErrorCode.SCHEMA_MISMATCH: "model_output",
    ErrorCode.RATE_LIMITED: "rate_limit",
    ErrorCode.UPSTREAM_RATE_LIMITED: "rate_limit",
    ErrorCode.UPSTREAM_TIMEOUT: "timeout",
    ErrorCode.UPSTREAM_ERROR: "upstream",
    ErrorCode.UPSTREAM_UNAVAILABLE: "upstream",
    ErrorCode.INTERNAL_ERROR: "internal",
}

# 故障层：transport = 传输层重试，content = 内容层重试，none = 不重试
# 表里没有的错误码默认按 "none" 处理（用 .get 的默认值），因为参数错误、鉴权错误这类
# 重试多少次都不会变好。
_RETRY_KIND: dict[ErrorCode, str] = {
    ErrorCode.MALFORMED_UPSTREAM: "transport",
    ErrorCode.UPSTREAM_RATE_LIMITED: "transport",
    ErrorCode.UPSTREAM_TIMEOUT: "transport",
    ErrorCode.UPSTREAM_ERROR: "transport",
    ErrorCode.UPSTREAM_UNAVAILABLE: "transport",
    ErrorCode.INVALID_JSON: "content",
    ErrorCode.SCHEMA_MISMATCH: "content",
}


class GatewayError(Exception):
    """网关的统一异常类型，所有内部错误最终都包装成它抛出。

    相当于 Java 里一个自定义 RuntimeException：构造时把错误码、人类可读信息、
    上游状态码和附加细节一起带上，调用方既能判定「该不该重试」，也能还原现场。
    """

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        *,
        upstream_status: int | None = None,
        details: dict | None = None,
    ) -> None:
        """构造一个网关错误。

        code 决定 HTTP 状态码 / error.type / 重试策略，不可为空；
        message 是给用户看的说明；
        upstream_status 是上游厂商返回的原始状态码（例如上游 401），没有则留空；
        details 是可选的补充信息（如校验失败的具体字段）。

        参数前的 "*" 表示这些参数只能按关键字传（相当于 Java 里没有对应的重载写法，
        只能写 upstreamStatus: 401）。
        """
        super().__init__(message)
        self.code = code
        self.message = message
        self.upstream_status = upstream_status
        self.details = details or {}

    @property
    def http_status(self) -> int:
        """对外返回的 HTTP 状态码，由错误码查表得到。"""
        return _HTTP_STATUS[self.code]

    @property
    def error_type(self) -> str:
        """错误体的 type 字段（中立取值），由错误码查表得到。"""
        return _ERROR_TYPE[self.code]

    @property
    def retry_kind(self) -> str:
        """transport | content | none

        补充说明：transport 表示换一次连接重发即可（网络/上游临时故障）；
        content 表示需要把上一次的坏输出带回给模型修正；
        none 表示不可重试。
        """
        return _RETRY_KIND.get(self.code, "none")

    @property
    def retriable(self) -> bool:
        """是否值得重试，等价于 retry_kind != "none"。"""
        return self.retry_kind != "none"

    def to_body(self, request_id: str, attempts: int | None = None) -> dict:
        """转成网关自有的错误响应体。

        attempts 为已尝试次数，只有发生过重试时才带上（没有重试就省略该字段）；
        upstream_status / details 同理，只在有值时输出，避免响应体里出现一堆 null。
        """
        body = {
            "code": self.code.value,
            "message": self.message,
            "type": self.error_type,
            "request_id": request_id,
            "retriable": self.retriable,
        }
        if attempts is not None:
            body["attempts"] = attempts
        if self.upstream_status is not None:
            body["upstream_status"] = self.upstream_status
        if self.details:
            body["details"] = self.details
        return body
