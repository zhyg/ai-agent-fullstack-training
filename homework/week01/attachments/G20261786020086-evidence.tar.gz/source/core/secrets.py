"""密钥供给：`.env` 解析 + 密钥文件读取（见 DESIGN §7.9）。

分两个方向：

- **出站**（网关 → 上游）：本模块负责「按配置把密钥取到手」，
  取不到就在启动时失败，而不是运行期变成一个含义模糊的 401/502。
- **入站**（调用方 → 网关）：在 `core/security.py`，那里的密钥来自环境变量
  `key_env`，由运维分发给调用方——信任方向相反，不与出站混在一起。
"""

from __future__ import annotations

import os
from pathlib import Path


def parse_env_file(text: str) -> dict[str, str]:
    """解析 `.env` 的内容。

    支持的写法：`KEY=VALUE`、`export KEY=VALUE`、空行、`#` 注释行、
    单/双引号包裹的值（解析时去引号）、未加引号时的行尾 ` #` 注释。

    **没有 `=` 的行被跳过**，不抛异常：`.env` 是部署现场的文件，
    一行手误不该让网关起不来（DESIGN §7.9.2）。
    """
    parsed: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if not key:
            continue
        parsed[key] = _clean_value(value.strip())
    return parsed


def _clean_value(value: str) -> str:
    """去掉值的引号与行尾注释。"""
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        return value[1:-1]
    comment = value.find(" #")
    if comment != -1:
        value = value[:comment]
    return value.strip()


def load_env_file(path: str | Path) -> dict[str, str]:
    """加载 `.env` 文件到进程环境变量，**只补不覆盖**。

    文件不存在时静默返回（没有 `.env` 是正常状态，不是错误）。
    已存在的环境变量优先——容器编排（Docker / systemd / K8s）注入的值
    不该被仓库里的 `.env` 悄悄改掉。

    返回本次解析出的键值（便于测试与排查），不代表实际生效的变量集合。
    """
    if not path:
        return {}
    file_path = Path(path)
    if not file_path.is_file():
        return {}
    parsed = parse_env_file(file_path.read_text(encoding="utf-8"))
    for key, value in parsed.items():
        os.environ.setdefault(key, value)
    return parsed


def read_secret_file(path: str | Path) -> str:
    """读取密钥文件的内容（去掉首尾空白）。

    文件不存在或内容为空 → 抛异常。这是**配置错误**，
    应当在启动时暴露，而不是运行期变成上游 401。
    """
    file_path = Path(path)
    if not file_path.is_file():
        raise FileNotFoundError(f"secret file not found: {file_path}")
    content = file_path.read_text(encoding="utf-8").strip()
    if not content:
        raise ValueError(f"secret file is empty: {file_path}")
    return content


def resolve_api_key(env_name: str | None, file_path: str | None) -> str | None:
    """按优先级取上游密钥：环境变量 → 密钥文件 → None。

    环境变量优先：它能被容器编排直接注入，也最容易临时覆盖
    （调试时临时设一个环境变量就能换一把 key）。
    """
    if env_name:
        value = os.environ.get(env_name)
        if value:
            return value
    if file_path:
        return read_secret_file(file_path)
    return None
