"""JSON 本地确定性修复 + schema 校验（协议无关）。

在整体架构中的位置：这是「内容层重试」的公共基础设施。模型返回的文本先在这里被尽力
修成合法 JSON，再用 schema 校验；修不动时由调用方把上一次的坏输出贴回给模型让它自己改。
它不认识 OpenAI / Anthropic 任何一方，所以 Provider 和 Adapter 都能共用。

对应的 Java 概念：模块级 re.compile 常量 ≈ Java 的 static final Pattern；
jsonschema 库 ≈ Java 的 JSON Schema 校验实现（org.everit 或 networknt 之类）；
"确定性" 指的是同样的输入永远得到同样的修复结果，不含模型调用、不含随机性。
"""

from __future__ import annotations

import json
import re
from typing import Any

from core.errors import ErrorCode, GatewayError

# 匹配 ```json ... ``` 代码围栏；非贪婪匹配 + DOTALL 保证多行内容也能整体取到。
_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
# 匹配对象/数组结尾前多余的逗号，如 {"a":1,}。
_TRAILING_COMMA = re.compile(r",\s*([}\]])")


def json_instruction(schema: dict[str, Any] | None) -> str:
    """生成「请严格按此 schema 输出 JSON」的提示词。

    schema 为 None 时输出一个空 schema，调用方通常此时并不真的想要 JSON，
    只是复用这段模板化的措辞。ensure_ascii=False 保证中文不被转成 \\uXXXX。
    """
    return (
        "你必须只返回一个 JSON 对象，不要包含任何解释文字、前言、总结，"
        "也不要使用 Markdown 代码块（```）包裹。"
        "输出必须严格符合以下 schema：\n"
        + json.dumps(schema or {}, ensure_ascii=False, indent=2)
    )


def strip_code_fence(text: str) -> str:
    """剥掉 Markdown 代码围栏，只留里面的内容；没有围栏时原样返回。"""
    match = _FENCE.search(text)
    return match.group(1).strip() if match else text


def extract_json_object(text: str) -> str:
    """截取最外层的 {...} 或 [...]。

    不能简单用正则找第一个 } 到最后一个 }，因为字符串值里可能自带花括号，
    所以这里手工扫描并维护括号深度；in_string / escaped 两个标志用来区分
    「字符串里的括号」和「真正的括号」。
    找不到任何括号时原样返回（交给调用方去判定为解析失败）。
    """
    for opener, closer in (("{", "}"), ("[", "]")):
        start = text.find(opener)
        if start == -1:
            continue
        depth = 0
        in_string = False
        escaped = False
        for idx in range(start, len(text)):
            ch = text[idx]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == opener:
                depth += 1
            elif ch == closer:
                depth -= 1
                if depth == 0:
                    return text[start : idx + 1]
    return text


def repair_json(text: str) -> str:
    """剥围栏 / 去 BOM / 提取最外层 JSON / 去尾随逗号。

    这是纯文本层面的修复，不保证修复后一定能解析成功，所以解析仍要靠 try_parse。
    BOM 是模型有时会吐出的不可见字节头，不去掉会导致 json.loads 直接失败。
    """
    cleaned = text.lstrip("﻿").strip()
    cleaned = strip_code_fence(cleaned)
    cleaned = extract_json_object(cleaned)
    cleaned = _TRAILING_COMMA.sub(r"\1", cleaned)
    return cleaned.strip()


def try_parse(text: str, *, repair: bool = True) -> Any | None:
    """把文本解析成 Python 对象，失败返回 None（不抛异常）。

    repair=True 时先做本地修复再解析；repair=False 时只做 strip（相当于 Java 里
    试图 new ObjectMapper().readValue(...) 并 catch 掉异常）。
    返回 None 而不是抛异常，是为了让调用方能直接写 if parsed is None 判断。
    """
    candidate = repair_json(text) if repair else text.strip()
    try:
        return json.loads(candidate)
    except (json.JSONDecodeError, ValueError):
        return None


def validate_schema(instance: Any, schema: dict[str, Any] | None) -> tuple[bool, str | None]:
    """用 JSON Schema 校验解析结果。

    返回 (是否通过, 失败原因)，原因在通过时为 None。相当于 Java 里
    boolean + errorMessage 的一对返回值，而不像 Java 那样抛异常——
    这里不抛异常是因为**校验失败**是业务上的正常结果，要交给上层决定是否重试。

    schema 为空视为通过（没要求就没得违反）。

    jsonschema 未安装时**硬失败**（GatewayError），不静默放行：契约承诺
    「200 ⇒ 内容已通过本地 schema 校验」，缺了校验器这个承诺就是空的，
    静默放行等于骗调用方。
    """
    if not schema:
        return True, None
    try:
        import jsonschema
    except ImportError as exc:  # pragma: no cover - 依赖缺失属于部署问题
        raise GatewayError(
            ErrorCode.INTERNAL_ERROR,
            "jsonschema dependency is missing; output_schema cannot be enforced",
        ) from exc
    try:
        jsonschema.validate(instance=instance, schema=schema)
    except jsonschema.ValidationError as exc:
        # absolute_path 是出错位置在实例里的路径，转成 a/b/c 形式方便定位字段。
        path = "/".join(str(p) for p in exc.absolute_path)
        return False, f"{path}: {exc.message}" if path else exc.message
    except Exception as exc:  # schema 本身不合法等情况
        return False, str(exc)
    return True, None


def strength_instruction(
    level: int,
    mode: str,
    schema: dict[str, Any] | None,
    schema_name: str | None,
    previous_output: str | None,
) -> str:
    """内容层重试时的提示加强文本。level 1 = 通用约束，level 2 = 贴上次输出要求只修格式。

    mode 为 "tool_use" 时走工具调用口径（要求模型调用指定工具），
    其余情况走纯 JSON 口径。level 由 1 递增到 max_prompt_strength，
    越往后越把上次失败的原文交给模型，让它只做语法修正而不重新发挥语义。
    """
    if level <= 1:
        if mode == "tool_use" and schema_name:
            return (
                f"你必须调用 `{schema_name}` 工具，并且参数必须严格符合该工具的 input_schema。"
                "不要输出任何解释文字，也不要输出工具调用之外的内容。"
            )
        return json_instruction(schema)

    previous = (previous_output or "").strip()
    if mode == "tool_use" and schema_name:
        return (
            "你上一次的调用返回的 JSON 无法被解析，原文如下：\n---\n"
            f"{previous}\n---\n"
            f"请只修正上述内容的 JSON 语法错误后重新调用 `{schema_name}` 工具，不要改变语义内容。"
        )
    return (
        "你上一次的回复无法被解析为合法 JSON，原文如下：\n---\n"
        f"{previous}\n---\n"
        "请只修正上述内容的 JSON 语法错误后重新输出，不要改变其中的语义内容，"
        "不要添加任何解释文字，不要使用 Markdown 代码块包裹。"
    )
