"""全链路流转的领域数据结构（统一请求 / 统一响应 / 流式事件 / 协议上下文）。

在整体架构中的位置：这是 LLMGateway 的「公共语言」。上游 API 层的请求进来后被翻译成
LLMRequest，各 Provider/Adapter 之间只传这里的类型，翻译回来又变回 UnifiedResponse，
因此任何一处改字段都会牵动全链路。

对应的 Java 概念：这里几乎全部是 pydantic.BaseModel ≈ 「带运行时校验的 Java POJO/record」——
字段类型在构造时就校验，非法值直接抛 ValidationError（对应 Java 的 Jackson 反序列化失败）。
类内的小写字段名 ≈ Java 的 private 字段；默认值 ≈ 字段初始值。
"""

from __future__ import annotations

import json
import time
import uuid
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def new_request_id() -> str:
    """生成一次请求的唯一 ID，前缀 "lgw-" 表示这是网关自己的 ID。

    取 uuid4 的十六进制前 24 位，相当于 Java 的 UUID.randomUUID().toString().substring(0, 24)。
    """
    return f"lgw-{uuid.uuid4().hex[:24]}"


def now_ts() -> int:
    """当前 Unix 秒级时间戳（相当于 Java 的 System.currentTimeMillis() / 1000）。"""
    return int(time.time())


# --- 请求契约的入参约束（见 DESIGN §8.1.1） --------------------------------
#
# 常量放在这里是因为它们同时是「请求契约的一部分」和「测试要引用的断言值」。
# 口径：每一个**调用方可控**的字段都必须有明确的长度 / 数量 / 取值域约束，
# 目的是让非法输入在入口就被 400 掉，而不是先扣配额再变成上游 502。

MAX_MODEL_CHARS = 128          # 模型别名长度
MAX_MESSAGES = 100             # 消息条数上限
MAX_MESSAGE_CHARS = 20_000     # 单条消息内容的字符数上限
MAX_TOTAL_MESSAGE_CHARS = 100_000  # 所有消息内容合计的字符数上限
MAX_SCHEMA_NAME_CHARS = 64     # output_schema.name 长度
MAX_SCHEMA_CHARS = 20_000      # output_schema.schema 序列化后的字符数上限
MAX_SCHEMA_DEPTH = 10          # output_schema.schema 的嵌套层数上限
MAX_PROMPT_NAME_CHARS = 128    # prompt.name 长度
MAX_PROMPT_VARS = 50           # prompt.vars 的项数上限
MAX_PROMPT_VAR_CHARS = 2_000   # prompt.vars 里字符串值的长度上限
MAX_METADATA_ENTRIES = 32      # metadata 的项数上限
MAX_METADATA_KEY_CHARS = 64    # metadata 键的长度上限
MAX_METADATA_VALUE_CHARS = 512  # metadata 值的长度上限


def _json_depth(value: Any) -> int:
    """算一个 JSON 值的嵌套深度（标量算 1 层）。

    用来给 `output_schema.schema` 挡「几千层嵌套」这种输入——JSON 解析本身
    能扛住，但下游的 jsonschema 校验与上游的序列化会踩进去。
    """
    if isinstance(value, dict):
        if not value:
            return 1
        return 1 + max(_json_depth(item) for item in value.values())
    if isinstance(value, list):
        if not value:
            return 1
        return 1 + max(_json_depth(item) for item in value)
    return 1


class UnifiedMessage(BaseModel):
    """统一格式的一条对话消息。

    Literal["system", "user", "assistant"] ≈ 「枚举化的 String 字面量」，Java 里要写成
    enum Role { SYSTEM, USER, ASSISTANT }；这里用 Literal 是因为要原样透传给上游 JSON。

    `content` 的 `max_length` 是**入参侧的硬校验**：超过就在请求解析阶段 400，
    不消耗限流配额、不发上游请求（见 DESIGN §8.1.1）。
    """

    role: Literal["system", "user", "assistant"]
    content: str = Field(max_length=MAX_MESSAGE_CHARS)


class OutputSchemaSpec(BaseModel):
    """结构化输出契约：只有「有 schema」这一档，没有「只要 JSON 不要 schema」。

    schema_ 字段带 alias="schema"：schema 是 Python 保留概念（内置函数名），
    但对外协议里字段名必须叫 "schema"。alias ≈ Java 的 @JsonProperty("schema")。

    与 v1.1 的 JsonSchemaSpec 的差别：
    - schema **必填**（旧版有默认值，等于允许发出一个空 schema）
    - extra="forbid"：拼错的字段名直接 400，不静默丢弃
    - v2.3：name 有长度上限，schema 有大小与嵌套深度上限（防止无界输入）
    """

    name: str = Field(default="response", min_length=1, max_length=MAX_SCHEMA_NAME_CHARS)
    schema_: dict[str, Any] = Field(alias="schema")
    strict: bool = True

    # populate_by_name=True ≈ Jackson 的 @JsonAlias：既能用 "schema" 也能用 "schema_" 赋值，
    # 避免内部代码因为用了 Python 关键字而必须绕路。
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    @field_validator("schema_")
    @classmethod
    def _check_schema_size(cls, value: dict[str, Any]) -> dict[str, Any]:
        """挡掉超大 / 嵌套过深的 schema。

        schema 会被原样下发上游（OpenAI 的 text.format.json_schema、Anthropic 的
        tools[].input_schema），所以它是调用方直通上游的一条链路，必须有上限。
        """
        serialized = json.dumps(value, ensure_ascii=False)
        if len(serialized) > MAX_SCHEMA_CHARS:
            raise ValueError(
                f"output_schema.schema exceeds {MAX_SCHEMA_CHARS} characters"
            )
        depth = _json_depth(value)
        if depth > MAX_SCHEMA_DEPTH:
            raise ValueError(
                f"output_schema.schema nesting exceeds {MAX_SCHEMA_DEPTH} levels"
            )
        return value


class PromptRef(BaseModel):
    """对「提示词模板」的引用，而非模板正文本身。

    模板存放在存储层，网关按 name + version 取出再把 vars 填进去，
    相当于 Java 里传一个模板 id 加参数 Map，而不是传渲染好的大段字符串。

    v2.3：name / version / vars 都有约束。vars 的值必须是**标量**——渲染时会被
    `str()` 拼进模板，嵌套对象塞进去没意义还会撑爆长度。
    """

    name: str = Field(min_length=1, max_length=MAX_PROMPT_NAME_CHARS)
    version: int | None = Field(default=None, ge=1)
    vars: dict[str, Any] = Field(default_factory=dict)

    @field_validator("vars")
    @classmethod
    def _check_vars(cls, value: dict[str, Any]) -> dict[str, Any]:
        """限制 vars 的项数、键长与值形态。"""
        if len(value) > MAX_PROMPT_VARS:
            raise ValueError(f"prompt.vars exceeds {MAX_PROMPT_VARS} entries")
        for key, item in value.items():
            if not key or len(key) > MAX_PROMPT_NAME_CHARS:
                raise ValueError(
                    f"prompt.vars key '{key}' must be 1-{MAX_PROMPT_NAME_CHARS} characters"
                )
            if isinstance(item, (dict, list)):
                raise ValueError(
                    f"prompt.vars['{key}'] must be a scalar, not {type(item).__name__}"
                )
            if isinstance(item, str) and len(item) > MAX_PROMPT_VAR_CHARS:
                raise ValueError(
                    f"prompt.vars['{key}'] exceeds {MAX_PROMPT_VAR_CHARS} characters"
                )
        return value


class LLMRequest(BaseModel):
    """一次模型调用的统一请求体，同时就是对外的 HTTP 契约（见 DESIGN §8.1）。

    extra="forbid"：未知字段一律 400，不静默丢弃。v1.1 用的是 pydantic 默认的
    extra="ignore"，tools / top_p / stop / seed / n 会被悄悄扔掉——调用方以为
    参数生效了，其实根本没有。

    **刻意不暴露采样旋钮与输出上限**：`temperature` / `top_p` / `stop` / `seed` /
    `n` / `max_output_tokens` 都不在这里，传了按未知字段处理（400）。这些旋钮的
    跨厂商语义不一致，暴露它们等于把厂商差异泄漏回调用方；输出上限是网关按模型
    能力决定的策略（见 `GET /v1/models` 的 `capabilities.max_output_tokens`）。

    v2.3：所有调用方可控的字段都补上了长度 / 数量 / 取值域约束，非法入参在
    解析阶段就 400，不消耗限流配额、不发上游请求。
    """

    model_config = ConfigDict(extra="forbid")

    model: str = Field(
        min_length=1,
        max_length=MAX_MODEL_CHARS,
        pattern=r"^[A-Za-z0-9._-]+$",
    )
    messages: list[UnifiedMessage] = Field(min_length=1, max_length=MAX_MESSAGES)
    output_schema: OutputSchemaSpec | None = None
    stream: bool = False
    prompt: PromptRef | None = None
    metadata: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_total_message_chars(self) -> "LLMRequest":
        """所有消息内容的**合计**字符数不能超限。

        单条 20000 字符的上限挡不住「100 条各 20000 字」这种用法，所以还要有
        一道总量闸。这里是精确的字符计数，可以放心硬拒。
        """
        total = sum(len(message.content) for message in self.messages)
        if total > MAX_TOTAL_MESSAGE_CHARS:
            raise ValueError(
                f"messages content exceeds {MAX_TOTAL_MESSAGE_CHARS} characters in total"
            )
        return self

    @model_validator(mode="after")
    def _check_stream_and_schema_are_exclusive(self) -> "LLMRequest":
        """`stream` 与 `output_schema` 互斥。

        流式下「保证内容符合 schema」这件事本身做不到：字节已经发出去了，
        流尾校验只是事后追认，对已经拿到增量的客户端没有帮助。所以这个组合
        在入口就 400，而不是「先发字节再补一个 error 帧」（见 DESIGN §5.1）。
        """
        if self.stream and self.output_schema is not None:
            raise ValueError(
                "stream and output_schema are mutually exclusive; "
                "use a non-streaming request for structured output"
            )
        return self

    @field_validator("metadata")
    @classmethod
    def _check_metadata(cls, value: dict[str, str]) -> dict[str, str]:
        """限制 metadata 的项数、键长与值长。

        值类型是 `str`（不是 `Any`）：调用记录里的 `metadata` 本来就是
        `dict[str, str]`，pydantic v2 不会把数字/对象悄悄转成字符串，
        传非字符串会直接 400。
        """
        if len(value) > MAX_METADATA_ENTRIES:
            raise ValueError(f"metadata exceeds {MAX_METADATA_ENTRIES} entries")
        for key, item in value.items():
            if not key or len(key) > MAX_METADATA_KEY_CHARS:
                raise ValueError(
                    f"metadata key must be 1-{MAX_METADATA_KEY_CHARS} characters"
                )
            if len(item) > MAX_METADATA_VALUE_CHARS:
                raise ValueError(
                    f"metadata['{key}'] exceeds {MAX_METADATA_VALUE_CHARS} characters"
                )
        return value


class TokenUsage(BaseModel):
    """一次调用的 token 计量。除了常规输入/输出，还区分推理 token 与缓存读写 token，
    因为不同厂商的计费口径不同，归一化到这里才能统一统计与限流。
    """

    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    total_tokens: int = 0

    def add(self, other: "TokenUsage") -> None:
        """把另一份用量累加到自身（就地修改，返回 None），相当于 Java 里对可变 POJO 做 +=。

        注意 total_tokens 是直接相加而不是各子项重新求和，
        因为部分上游把缓存命中的 token 同时计入 input 和 total，直接重算会算重。
        """
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        self.reasoning_tokens += other.reasoning_tokens
        self.cache_read_tokens += other.cache_read_tokens
        self.cache_write_tokens += other.cache_write_tokens
        self.total_tokens += other.total_tokens


class UnifiedResponse(BaseModel):
    """统一响应体。除内容外还带网关自测的耗时指标：
    latency_ms 是端到端耗时，ttft_ms 是首 token 延迟（time to first token）。
    """

    id: str = ""
    model: str = ""
    content: str = ""
    reasoning_content: str | None = None
    finish_reason: str = "stop"
    usage: TokenUsage = Field(default_factory=TokenUsage)
    cost_usd: float | None = None
    latency_ms: float = 0.0
    ttft_ms: float | None = None
    created: int = Field(default_factory=now_ts)


class UnifiedStreamEvent(BaseModel):
    """流式过程中的一条统一事件，对应 OpenAI 流式响应里的 data chunk。

    text_delta / reasoning_delta 是增量文本；usage 是用量汇总；done 表示正常结束；
    error 表示流中断。其余字段按 type 取值，其余为 None。
    """

    type: Literal["text_delta", "reasoning_delta", "usage", "done", "error"]
    text: str | None = None
    usage: TokenUsage | None = None
    finish_reason: str | None = None
    error: dict[str, Any] | None = None  # type == "error" 时填充，与 HTTP 错误体同构


class SSEChunk(BaseModel):
    """一个原始 SSE 事件：event 行 + data 行。

    对应 Java 里解析 text/event-stream 后得到的一对（事件名, 数据），
    Provider 拿到它才知道这是 content_block_delta 还是 message_delta。
    """

    event: str | None = None
    data: str = ""


class ProtocolContext(BaseModel):
    """Provider 翻译协议时需要的窄接口。不含模型概念（无 alias / max_input_tokens）。

    这是「协议层 ↔ 模型层」的边界契约：Adapter 负责填好它，Provider 只读它。
    state 是给 Provider 跨事件保存流式解析进度用的（比如 Anthropic 需要按 index 拼接内容块）。
    """

    upstream_id: str
    base_url: str
    api_key: str | None = None
    structured_output_mode: str = "none"  # none | native | tool_use | prompt_only
    schema_name: str | None = None
    json_schema: dict[str, Any] | None = None
    schema_strict: bool = False           # schema 是否要求严格符合
    max_output_tokens: int = 4096         # 输出上限的唯一来源，三个协议都必须下发
    extra_body: dict[str, Any] = Field(default_factory=dict)
    cache_prompt: bool = False
    state: dict[str, Any] = Field(default_factory=dict)


class UpstreamEndpoint(BaseModel):
    """一个可被选中的上游端点（见 DESIGN §7.8.1）。

    同一个模型可以有多个端点，配置顺序即优先级。name 是端点的标识，会出现在
    调用记录里；不填就用 base_url 代替（URL 不进契约，但标识要能定位问题）。
    """

    name: str
    base_url: str
    upstream_id: str | None = None
    api_key: str | None = None
