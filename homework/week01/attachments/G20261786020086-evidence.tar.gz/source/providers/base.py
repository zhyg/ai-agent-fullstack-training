"""协议层抽象：把统一请求翻译成某家厂商的 HTTP 协议，再把上游响应翻译回统一结构。

职责边界（这是本模块最该记住的约束）：
- Provider 只懂「协议」，不懂「模型」。它拿到的 `ProtocolContext` 是刻意收窄的接口，
  里面没有「模型别名」「上下文长度上限」之类的模型概念，模型层永远不会被协议层污染。
- 结构化输出用哪种模式（`native` / `tool_use` / `prompt_only`）由 Adapter（模型层）决定，
  Provider 只负责按自己协议实现该机制，不做模式选择。

对应的 Java 概念：
- `ABC` + `@abstractmethod` ≈ Java 的 `abstract class` + `abstract` 方法（子类必须实现）。
- `@dataclass` ≈ Lombok `@Data` 生成的 POJO（无 getter，属性直接访问）。
- `X | None` ≈ `Optional<X>`；`dict[str, Any]` ≈ `Map<String, Object>`。
- `from __future__ import annotations` 让类型注解延迟到运行时才求值，作用类似
  Java 里让注解不参与方法签名解析的写法。
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from core.structured import json_instruction
from core.types import (
    LLMRequest,
    ProtocolContext,
    SSEChunk,
    UnifiedResponse,
    UnifiedStreamEvent,
)


@dataclass
class UpstreamRequest:
    """一次出站 HTTP 调用的描述（≈ Java 的不可变 Request DTO / record）。

    只描述「怎么发」：方法、URL、请求头、JSON 请求体、超时。
    不含任何模型语义，也不含业务语义，协议层与模型层在这里彻底解耦。
    """

    method: str
    url: str
    headers: dict[str, str]
    body: dict[str, Any] = field(default_factory=dict)
    timeout: float | None = None


__all__ = ["BaseProvider", "UpstreamRequest", "json_instruction"]


class BaseProvider(ABC):
    """协议层：只认协议，不认模型。

    每个子类负责一种厂商协议（OpenAI Responses / Anthropic Messages ...），
    实现「统一格式 → 厂商格式」和「厂商格式 → 统一格式」两个方向的翻译。

    要记住的约束：
    1. 子类只允许从 `ctx`（`ProtocolContext`）取协议翻译所需字段，
       不允许引入模型别名、上下文窗口等模型概念。
    2. `ctx.state` 是协议翻译期间的临时黑板（≈ 挂在请求作用域上的可变 Map），
       用来在「同一个流的多个 SSE 事件之间」传递状态，例如用量和结束原因。
    """

    protocol: str = "base"

    @abstractmethod
    def build_request(self, req: LLMRequest, ctx: ProtocolContext) -> UpstreamRequest:
        """把统一请求翻译成目标协议的 URL / 鉴权头 / 请求体。

        参数：
        - req：统一请求（≈ 网关对外暴露的 OpenAI 兼容请求体）。
        - ctx：协议翻译所需的窄上下文，含上游地址、密钥、结构化输出模式等。

        返回：可直接交给 `upstream/client.py` 发送的 `UpstreamRequest`。

        异常：本方法只做纯数据拼装，约定不抛异常；网络/状态码异常由客户端层负责。
        """

    @abstractmethod
    def parse_response(self, raw: dict, ctx: ProtocolContext) -> UnifiedResponse:
        """把目标协议的非流式响应翻译回统一响应。

        参数：
        - raw：上游返回的 JSON 对象（已由客户端解析）。
        - ctx：同上，用于判断结构化输出模式等。

        返回：`UnifiedResponse`，其中 `content` 已经是统一的纯文本/JSON 字符串。

        异常：本方法只做纯解析，约定不抛异常；上游内容不合法的判定由上层负责。
        """

    @abstractmethod
    def parse_stream_event(
        self, chunk: SSEChunk, ctx: ProtocolContext
    ) -> UnifiedStreamEvent | None:
        """把目标协议的单个 SSE 事件翻译成统一流式事件；不认识的返回 None。

        参数：
        - chunk：一个已切分好的 SSE 块（含 `event` 名与 `data` 原文）。
        - ctx：同上；需要跨事件共享的状态写进 `ctx.state`。

        返回：`UnifiedStreamEvent`；若该事件只是心跳、控制类事件则返回 `None`
        （返回 `None` 表示「跳过，不产生任何输出」，不要抛异常）。

        异常：约定不抛异常；数据解析失败时应吞掉并返回 `None`。
        """
