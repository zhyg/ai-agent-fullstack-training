"""Anthropic Messages API 的协议适配实现。

职责：把统一请求/响应翻译成 Anthropic Messages API 的形状
（顶层 `system` + `messages` + `tools`/`tool_choice` + `content_block_delta` 事件）。
它只懂协议，不懂模型；结构化输出用哪种模式由上游 Adapter 决定，
本模块实现 `tool_use` 与 `prompt_only` 两种模式在此协议下的具体机制。

对应的 Java 概念：
- `class AnthropicMessagesProvider(BaseProvider)` ≈ 继承抽象基类实现协议适配器。
- `dict.get(k, default)` ≈ `Map.getOrDefault(k, default)`。
- `X | None` ≈ `Optional<X>`；`list[str]` ≈ `List<String>`。
- `ctx.state` ≈ 挂在请求作用域上的可变 Map，用来跨 SSE 事件传递用量。
"""

from __future__ import annotations

import json
from typing import Any

from core.types import (
    LLMRequest,
    ProtocolContext,
    SSEChunk,
    TokenUsage,
    UnifiedResponse,
    UnifiedStreamEvent,
)
from providers.base import BaseProvider, UpstreamRequest, json_instruction

# Anthropic 的 stop_reason → 统一 finish_reason 的对照表。
# 兜底值统一给 "stop"，避免上游出现未知取值时抛异常。
#
# 注意 `tool_use` 映射成 "stop" 而不是 "tool_calls"：工具调用是结构化输出的
# **实现细节**（本协议没有原生 json_schema，只能借工具变通），不属于调用方
# 需要知道的语义——中立契约里只有 stop / length / error 三档。
_STOP_REASON = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "stop",
}


class AnthropicMessagesProvider(BaseProvider):
    """Anthropic Messages API 协议。

    与 OpenAI Chat Completions 的关键差异（读代码时对照着看）：
    - system 提示词不在 `messages` 里，而是顶层独立的 `system` 字段。
    - `max_tokens` 是**必填**参数（OpenAI 侧是可选），所以必须由 ctx 恒定提供。
    - 鉴权头是 `x-api-key` 而非 `Authorization: Bearer`，还必须带 `anthropic-version`。
    - 结构化输出的原生手段是「工具调用」：`tools` + `tool_choice` 强制模型调用。
    """

    protocol = "anthropic_messages"

    def build_request(self, req: LLMRequest, ctx: ProtocolContext) -> UpstreamRequest:
        """把统一请求翻译成 Messages API 的请求体、URL 和鉴权头。

        翻译要点：
        - 拆出 system 消息 → 顶层 `system`（多条用空行拼接）；其余进 `messages`。
        - `structured_output_mode == "tool_use"` → 声明一个带 `input_schema` 的工具，
          并用 `tool_choice` 强制模型必须调用它（这就是本协议的「原生结构化输出」）。
        - `"prompt_only"` → 把 schema 追加到 `system` 提示词后面。
        - `ctx.cache_prompt` 为真 → 把 `system` 升级成块数组并打上 `cache_control`，
          让上游缓存这段前缀（缓存命中时 `cache_read_input_tokens` 会计入用量）。

        返回：`UpstreamRequest`（POST {base_url}/v1/messages）。
        异常：纯拼装，约定不抛异常。
        """
        system_parts = [m.content for m in req.messages if m.role == "system"]
        chat = [m for m in req.messages if m.role != "system"]

        body: dict[str, Any] = {
            "model": ctx.upstream_id,
            "messages": [{"role": m.role, "content": m.content} for m in chat],
            "max_tokens": ctx.max_output_tokens,
        }
        if system_parts:
            body["system"] = "\n\n".join(system_parts)
        if req.stream:
            body["stream"] = True

        if ctx.structured_output_mode == "tool_use":
            tool_name = ctx.schema_name or "structured_output"
            body["tools"] = [
                {
                    "name": tool_name,
                    "description": "以结构化形式返回结果",
                    "input_schema": ctx.json_schema or {"type": "object"},
                }
            ]
            body["tool_choice"] = {"type": "tool", "name": tool_name}
        elif ctx.structured_output_mode == "prompt_only":
            suffix = json_instruction(ctx.json_schema)
            body["system"] = f"{body.get('system', '')}\n\n{suffix}".strip()

        # 开启提示词缓存时 system 必须是「块数组」才能挂 cache_control，
        # 字符串形态的 system 无法携带缓存标记。
        if ctx.cache_prompt and body.get("system"):
            body["system"] = [
                {
                    "type": "text",
                    "text": body["system"],
                    "cache_control": {"type": "ephemeral"},
                }
            ]

        body.update(ctx.extra_body)

        headers = {
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        if ctx.api_key:
            headers["x-api-key"] = ctx.api_key
        return UpstreamRequest(
            method="POST",
            url=f"{ctx.base_url.rstrip('/')}/v1/messages",
            headers=headers,
            body=body,
        )

    def parse_response(self, raw: dict, ctx: ProtocolContext) -> UnifiedResponse:
        """把 Messages API 的非流式响应翻译成 `UnifiedResponse`。

        响应体的 `content` 是「块数组」，按 `type` 分流：
        `text` 块拼成正文；`thinking` 块是思维链；`tool_use` 块里是结构化结果（`input`）。
        当结构化输出模式是 `tool_use` 时，最终 `content` 取工具的 `input` 序列化成 JSON 字符串，
        这样上层无论哪种模式拿到的都是「一个 JSON 字符串」。

        `stop_reason` 通过 `_STOP_REASON` 映射成统一的结束原因（`stop` / `length`）。

        异常：纯解析，约定不抛异常。
        """
        text_parts: list[str] = []
        thinking_parts: list[str] = []
        tool_input: Any = None
        for block in raw.get("content") or []:
            block_type = block.get("type")
            if block_type == "text":
                text_parts.append(block.get("text", ""))
            elif block_type == "thinking":
                thinking_parts.append(block.get("thinking", ""))
            elif block_type == "tool_use":
                tool_input = block.get("input")

        if ctx.structured_output_mode == "tool_use" and tool_input is not None:
            content = json.dumps(tool_input, ensure_ascii=False)
        else:
            content = "".join(text_parts)

        usage = self._map_usage(raw.get("usage") or {})
        finish_reason = _STOP_REASON.get(raw.get("stop_reason", ""), "stop")

        return UnifiedResponse(
            id=raw.get("id", ""),
            model=raw.get("model", ""),
            content=content,
            reasoning_content="".join(thinking_parts) or None,
            finish_reason=finish_reason,
            usage=usage,
        )

    def parse_stream_event(
        self, chunk: SSEChunk, ctx: ProtocolContext
    ) -> UnifiedStreamEvent | None:
        """把单个 Messages API 的 SSE 事件翻译成统一流式事件。

        事件映射：
        - `content_block_delta` 且 `delta.type == "text_delta"` → `text_delta`（正文增量）
        - `content_block_delta` 且 `delta.type == "input_json_delta"` → `text_delta`
          （工具入参的 JSON 片段，同样以文本增量形式吐出，由上层拼接）
        - `content_block_delta` 且 `delta.type == "thinking_delta"` → `reasoning_delta`
          （思维链增量，与 Responses 侧的 reasoning 事件对齐）
        - `message_stop` → `usage`（用量与结束原因此时才齐）

        `message_start` / `message_delta` 本身不产生输出，只把用量、结束原因暂存到 `ctx.state`，
        等 `message_stop` 时再统一发出 —— 这是 Anthropic 与 OpenAI 流式协议的关键差异。

        异常：数据不是合法 JSON 时吞掉并返回 `None`。
        """
        if not chunk.data:
            return None
        try:
            data = json.loads(chunk.data)
        except (json.JSONDecodeError, ValueError):
            return None
        if not isinstance(data, dict):
            return None

        event = chunk.event or data.get("type")

        if event == "message_start":
            message = data.get("message") or {}
            ctx.state["usage"] = self._map_usage(message.get("usage") or {})
            return None

        if event == "content_block_delta":
            delta = data.get("delta") or {}
            delta_type = delta.get("type")
            if delta_type == "text_delta":
                return UnifiedStreamEvent(type="text_delta", text=delta.get("text", ""))
            if delta_type == "input_json_delta":
                return UnifiedStreamEvent(type="text_delta", text=delta.get("partial_json", ""))
            if delta_type == "thinking_delta":
                return UnifiedStreamEvent(type="reasoning_delta", text=delta.get("thinking", ""))
            return None

        if event == "message_delta":
            delta = data.get("delta") or {}
            partial = data.get("usage") or {}
            if partial:
                ctx.state["usage"] = self._merge_usage(ctx.state.get("usage"), self._map_usage(partial))
            stop_reason = delta.get("stop_reason")
            if stop_reason:
                ctx.state["finish_reason"] = _STOP_REASON.get(str(stop_reason), "stop")
            return None

        if event == "message_stop":
            usage = ctx.state.get("usage") or TokenUsage()
            finish_reason = ctx.state.get("finish_reason", "stop")
            return UnifiedStreamEvent(type="usage", usage=usage, finish_reason=finish_reason)

        return None

    @staticmethod
    def _map_usage(usage_raw: dict) -> TokenUsage:
        """把 Messages API 的 `usage` 对象翻译成统一的 `TokenUsage`。

        Anthropic 会把缓存命中/写入的 token 单独列在
        `cache_read_input_tokens` / `cache_creation_input_tokens`，
        它们已计入 `input_tokens`，所以 `total_tokens` 只做 input + output。

        异常：纯映射，约定不抛异常（字段缺失一律按 0 处理）。
        """
        input_tokens = usage_raw.get("input_tokens", 0) or 0
        output_tokens = usage_raw.get("output_tokens", 0) or 0
        cache_read = usage_raw.get("cache_read_input_tokens", 0) or 0
        cache_write = usage_raw.get("cache_creation_input_tokens", 0) or 0
        return TokenUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
            cache_write_tokens=cache_write,
            total_tokens=input_tokens + output_tokens,
        )

    @staticmethod
    def _merge_usage(base: TokenUsage | None, new: TokenUsage) -> TokenUsage:
        """把后到的用量片段合并进已有用量（≈ 字段级覆盖的 merge）。

        Anthropic 的用量是分片下发的：`message_start` 给输入部分，
        `message_delta` 给输出部分。所以这里只覆盖「本次上报了非 0 值」的字段，
        没上报的字段保留原值，而不是整体替换。

        异常：纯合并，约定不抛异常。
        """
        if base is None:
            return new
        # model_copy() 是 pydantic v2 的浅拷贝，先复制再改，避免污染入参 base。
        merged = base.model_copy()
        for field in ("input_tokens", "output_tokens", "cache_read_tokens", "cache_write_tokens"):
            value = getattr(new, field)
            if value:
                setattr(merged, field, value)
        merged.total_tokens = merged.input_tokens + merged.output_tokens
        return merged
