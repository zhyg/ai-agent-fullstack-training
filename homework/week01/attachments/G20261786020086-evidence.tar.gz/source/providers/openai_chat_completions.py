"""OpenAI Chat Completions API 的协议适配实现。

职责：把统一请求/响应翻译成 Chat Completions 的形状
（`messages` 数组 + `response_format` + `choices[].delta`）。
它只懂协议，不懂模型；结构化输出用哪种模式由上游 Adapter 决定，
本模块实现 `native` 与 `prompt_only` 两种在本协议下的具体机制。

对应的 Java 概念：
- `class OpenAIChatCompletionsProvider(BaseProvider)` ≈ 继承抽象基类实现协议适配器。
- `ctx.state` ≈ 挂在请求作用域上的可变 Map，用来跨 SSE 事件传递状态。
- `X | None` ≈ `Optional<X>`。
"""

from __future__ import annotations

import json
from typing import Any

from core.types import (
    LLMRequest,
    ProtocolContext,
    SSEChunk,
    TokenUsage,
    UnifiedResponse,
    UnifiedStreamEvent,
)
from providers.base import BaseProvider, UpstreamRequest, json_instruction

# Chat Completions 的 finish_reason → 统一 finish_reason。
#
# 上游可能给出 `stop` / `length` / `content_filter` / `tool_calls` 等取值，
# 中立契约里只有 stop / length / error 三档（见 DESIGN §8.1）：
# 只有「被长度上限截断」才是调用方需要区分的，`tool_calls` 是结构化输出的
# 实现细节，不该泄漏给调用方。
_FINISH_REASON = {
    "length": "length",
    "stop": "stop",
}


class OpenAIChatCompletionsProvider(BaseProvider):
    """OpenAI Chat Completions API 协议。

    与另外两个 Provider 对照着看（DESIGN §4.4）：
    - 消息叫 `messages`，`content` 是**字符串**（不是块数组）。
    - 结构化输出走 `response_format.json_schema`（不是 `text.format`）。
    - 流式没有事件名：全是 `data:` 帧，且数据里再套一层 `choices[]`。
    - 鉴权头是 `Authorization: Bearer`（与 Responses 相同，与 Anthropic 不同）。
    """

    protocol = "openai_chat_completions"

    def build_request(self, req: LLMRequest, ctx: ProtocolContext) -> UpstreamRequest:
        """把统一请求翻译成 Chat Completions 的请求体、URL 和鉴权头。

        翻译要点：
        - 统一 `messages` → `messages` 数组（content 保持字符串）。
        - 输出上限恒定下发 `ctx.max_output_tokens`——输出上限只有一个来源，
          不因请求未指定而省略（见 DESIGN §4.2.1）。
        - `stream` 时额外下发 `stream_options.include_usage`：**不主动要就没有用量**，
          流尾的 `usage` 事件会退化成本地估算。
        - `structured_output_mode == "native"` → 写 `response_format.json_schema`；
          `"prompt_only"` → 追加一条 system 消息把 schema 塞进提示词。
        - `extra_body` 最后 merge：允许透传厂商私有参数（如 `reasoning_split`）。

        返回：`UpstreamRequest`（POST {base_url}/v1/chat/completions）。
        异常：纯拼装，约定不抛异常。
        """
        messages: list[dict[str, Any]] = [
            {"role": message.role, "content": message.content} for message in req.messages
        ]

        body: dict[str, Any] = {
            "model": ctx.upstream_id,
            "messages": messages,
            "max_tokens": ctx.max_output_tokens,
        }
        if req.stream:
            body["stream"] = True
            body["stream_options"] = {"include_usage": True}

        if ctx.structured_output_mode == "native":
            body["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": ctx.schema_name or "response",
                    "schema": ctx.json_schema or {},
                    "strict": ctx.schema_strict,
                },
            }
        elif ctx.structured_output_mode == "prompt_only":
            messages.append(
                {
                    "role": "system",
                    "content": json_instruction(ctx.json_schema),
                }
            )

        body.update(ctx.extra_body)

        headers = {"Content-Type": "application/json"}
        if ctx.api_key:
            headers["Authorization"] = f"Bearer {ctx.api_key}"
        return UpstreamRequest(
            method="POST",
            url=f"{ctx.base_url.rstrip('/')}/v1/chat/completions",
            headers=headers,
            body=body,
        )

    def parse_response(self, raw: dict, ctx: ProtocolContext) -> UnifiedResponse:
        """把 Chat Completions 的非流式响应翻译成 `UnifiedResponse`。

        正文在 `choices[0].message.content`，思维链在 `choices[0].message.reasoning_content`
        （上游要开了 `reasoning_split` 才拆出来，否则思维链内联在 content 里）。

        异常：纯解析，约定不抛异常。
        """
        choices = raw.get("choices") or []
        message = (choices[0].get("message") if choices else None) or {}

        finish_reason = _FINISH_REASON.get(
            str(choices[0].get("finish_reason")) if choices else "", "stop"
        )

        return UnifiedResponse(
            id=raw.get("id", ""),
            model=raw.get("model", ""),
            content=message.get("content") or "",
            reasoning_content=message.get("reasoning_content") or None,
            finish_reason=finish_reason,
            usage=self._map_usage(raw.get("usage") or {}),
        )

    def parse_stream_event(
        self, chunk: SSEChunk, ctx: ProtocolContext
    ) -> UnifiedStreamEvent | None:
        """把单个 Chat Completions 的 SSE 帧翻译成统一流式事件。

        帧的形状（没有事件名，全靠 data 里的字段区分）：
        - `choices[0].delta.content` → `text_delta`
        - `choices[0].delta.reasoning_content` → `reasoning_delta`
        - `choices[0].finish_reason` → 记进 `ctx.state`，随 `usage` 事件一起发出
        - `usage`（常常在一个 `choices: []` 的空帧里）→ `usage` 事件
        - `{"error": {...}}` → `error` 事件（交由编排层转成网关错误帧）

        两条容易踩的规则：
        1. **空 delta 必须跳过**——否则 TTFT 会被打到一个空帧上（首个 text_delta
           的时刻才是 TTFT，见 DESIGN §5.1）。
        2. **一帧里同时有 reasoning 与 content 时只能返回一个事件**——
        多出来的那个排进 `ctx.state` 里的队列，下一次调用先吐它。

        队列而不是单个暂存位：一帧最多产生两个事件，用队列才能保证
        「上一帧多出来的」与「本帧新产生的」都按原顺序发出去，一个都不丢。

        异常：数据不是合法 JSON 时吞掉并返回 `None`。
        """
        queue: list[UnifiedStreamEvent] = ctx.state.setdefault("_queue", [])
        queue.extend(self._events_of(chunk, ctx))
        if queue:
            return queue.pop(0)
        return None

    def _events_of(self, chunk: SSEChunk, ctx: ProtocolContext) -> list[UnifiedStreamEvent]:
        """把一帧翻译成 0..2 个统一流式事件（同一帧可能既有思维链又有正文）。

        返回空列表表示该帧不产生任何输出（心跳、空帧、无法识别的数据）。

        异常：数据不是合法 JSON 时吞掉并返回空列表。
        """
        if not chunk.data:
            return []
        # `[DONE]` 哨兵不是合法 JSON，直接忽略（MiniMax 实测不发，但别被它炸到）。
        if chunk.data.strip() == "[DONE]":
            return []
        try:
            data = json.loads(chunk.data)
        except (json.JSONDecodeError, ValueError):
            return []
        if not isinstance(data, dict):
            return []

        if data.get("error"):
            return [UnifiedStreamEvent(type="error", error=data.get("error"))]

        usage_raw = data.get("usage")
        choices = data.get("choices") or []
        choice = choices[0] if choices else {}
        delta = choice.get("delta") or {}

        content = delta.get("content")
        reasoning = delta.get("reasoning_content")

        finish_reason = choice.get("finish_reason")
        if finish_reason:
            ctx.state["finish_reason"] = _FINISH_REASON.get(str(finish_reason), "stop")

        events: list[UnifiedStreamEvent] = []
        # 思维链在前、正文在后：一帧里两者同时出现时，模型是「先想后答」。
        if reasoning:
            events.append(UnifiedStreamEvent(type="reasoning_delta", text=reasoning))
        if content:
            events.append(UnifiedStreamEvent(type="text_delta", text=content))
        if events:
            return events

        if usage_raw:
            return [
                UnifiedStreamEvent(
                    type="usage",
                    usage=self._map_usage(usage_raw),
                    finish_reason=ctx.state.get("finish_reason", "stop"),
                )
            ]
        return []

    @staticmethod
    def _map_usage(usage_raw: dict) -> TokenUsage:
        """把 Chat Completions 的 `usage` 对象翻译成统一的 `TokenUsage`。

        口径（与 OpenAI 家族一致）：推理 token **已含在** `completion_tokens` 里，
        缓存命中 token **已含在** `prompt_tokens` 里，所以 `total_tokens` 不能再加一次。

        异常：纯映射，约定不抛异常（字段缺失一律按 0 处理）。
        """
        prompt_details = usage_raw.get("prompt_tokens_details") or {}
        completion_details = usage_raw.get("completion_tokens_details") or {}
        input_tokens = usage_raw.get("prompt_tokens", 0) or 0
        output_tokens = usage_raw.get("completion_tokens", 0) or 0
        total_tokens = usage_raw.get("total_tokens", 0) or 0
        return TokenUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            reasoning_tokens=completion_details.get("reasoning_tokens", 0) or 0,
            cache_read_tokens=prompt_details.get("cached_tokens", 0) or 0,
            total_tokens=total_tokens or (input_tokens + output_tokens),
        )
