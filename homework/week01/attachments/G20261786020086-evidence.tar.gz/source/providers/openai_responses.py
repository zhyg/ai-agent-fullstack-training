"""OpenAI Responses API 的协议适配实现。

职责：把统一请求/响应翻译成 OpenAI Responses API 的形状
（`input` 数组 + `text.format` 结构化约束 + `output[]` 块 + SSE 事件）。
它只懂协议，不懂模型；结构化输出用哪种模式由上游 Adapter 决定，
本模块只实现 `native` 与 `prompt_only` 两种在本协议下的具体机制。

对应的 Java 概念：
- `class OpenAIResponsesProvider(BaseProvider)` ≈ 继承抽象基类实现协议适配器。
- 列表推导 / `for` 拼装 `dict` ≈ 手工构造 `Map` / `List` 的请求体。
- `dict.get(k, default)` ≈ `Map.getOrDefault(k, default)`。
- `X | None` ≈ `Optional<X>`。
"""

from __future__ import annotations

import json
from typing import Any

from core.types import (
    LLMRequest,
    ProtocolContext,
    SSEChunk,
    TokenUsage,
    UnifiedResponse,
    UnifiedStreamEvent,
)
from providers.base import BaseProvider, UpstreamRequest, json_instruction

_CONTENT_TYPE = {"assistant": "output_text"}


class OpenAIResponsesProvider(BaseProvider):
    """OpenAI Responses API 协议。

    与 Chat Completions 的关键差异（读代码时对照着看）：
    - 消息不叫 `messages`，叫 `input` 数组，且每条消息的 `content` 是「块数组」而非字符串。
    - 助手消息的块类型是 `output_text`，其余角色用 `input_text`。
    - 结构化输出不走 `response_format`，而是 `text.format` 里的 `json_schema`。
    - 流式增量的 SSE 事件名是 `response.output_text.delta`。
    """

    protocol = "openai_responses"

    def build_request(self, req: LLMRequest, ctx: ProtocolContext) -> UpstreamRequest:
        """把统一请求翻译成 Responses API 的请求体、URL 和鉴权头。

        翻译要点：
        - 统一 `messages` → `input` 数组，每条消息的 `content` 变成块数组。
        - 输出上限恒定下发 `ctx.max_output_tokens`——不因请求未指定而省略，
          否则同一份请求在两个模型上的实际输出上限会不同，而调用方看不出来。
        - `structured_output_mode == "native"` → 写 `text.format.json_schema`；
          `"prompt_only"` → 追加一条 system 消息把 schema 塞进提示词。
          `tool_use` 在本协议下不实现（本协议无 tools 语义）。

        返回：`UpstreamRequest`（POST {base_url}/v1/responses）。
        异常：纯拼装，约定不抛异常。
        """
        items: list[dict[str, Any]] = []
        for message in req.messages:
            items.append(
                {
                    "role": message.role,
                    "content": [
                        {"type": _CONTENT_TYPE.get(message.role, "input_text"), "text": message.content}
                    ],
                }
            )

        body: dict[str, Any] = {"model": ctx.upstream_id, "input": items}
        body["max_output_tokens"] = ctx.max_output_tokens
        if req.stream:
            body["stream"] = True

        if ctx.structured_output_mode == "native":
            body["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": ctx.schema_name or "response",
                    "schema": ctx.json_schema or {},
                    "strict": ctx.schema_strict,
                }
            }
        elif ctx.structured_output_mode == "prompt_only":
            items.append(
                {
                    "role": "system",
                    "content": [{"type": "input_text", "text": json_instruction(ctx.json_schema)}],
                }
            )

        body.update(ctx.extra_body)

        # extra_body 放在最后 merge：允许上层透传任意厂商私有参数覆盖默认值。
        headers = {"Content-Type": "application/json"}
        if ctx.api_key:
            headers["Authorization"] = f"Bearer {ctx.api_key}"
        return UpstreamRequest(
            method="POST",
            url=f"{ctx.base_url.rstrip('/')}/v1/responses",
            headers=headers,
            body=body,
        )

    def parse_response(self, raw: dict, ctx: ProtocolContext) -> UnifiedResponse:
        """把 Responses API 的非流式响应翻译成 `UnifiedResponse`。

        响应体的 `output` 是一个「块数组」，需要按 `type` 分流：
        `message` 块里再嵌一层 `content` 块数组，取其中的 `output_text`；
        `reasoning` 块里是推理摘要，取 `summary[].text`。

        注意 `status == "incomplete"` 表示上游因长度上限截断，统一映射为 `finish_reason="length"`。

        异常：纯解析，约定不抛异常。
        """
        text_parts: list[str] = []
        reasoning_parts: list[str] = []
        for block in raw.get("output") or []:
            block_type = block.get("type")
            if block_type == "message":
                for part in block.get("content") or []:
                    if part.get("type") in ("output_text", "text"):
                        text_parts.append(part.get("text", ""))
            elif block_type == "reasoning":
                for summary in block.get("summary") or []:
                    reasoning_parts.append(summary.get("text", ""))

        usage = self._map_usage(raw.get("usage") or {})
        status = raw.get("status")
        finish_reason = "length" if status == "incomplete" else "stop"

        return UnifiedResponse(
            id=raw.get("id", ""),
            model=raw.get("model", ""),
            content="".join(text_parts),
            reasoning_content="".join(reasoning_parts) or None,
            finish_reason=finish_reason,
            usage=usage,
        )

    def parse_stream_event(
        self, chunk: SSEChunk, ctx: ProtocolContext
    ) -> UnifiedStreamEvent | None:
        """把单个 Responses API 的 SSE 事件翻译成统一流式事件。

        事件映射：
        - `response.output_text.delta` → `text_delta`
        - `response.reasoning_summary_text.delta` / `response.reasoning_text.delta` → `reasoning_delta`
        - `response.completed` / `response.incomplete` → `usage`（顺带把结束原因写进 `ctx.state`）

        返回 `None` 表示该事件无需向客户端输出（如 `response.created`、`*.done` 之类）。
        异常：数据不是合法 JSON 时吞掉并返回 `None`，不让单个坏事件打断整个流。
        """
        if not chunk.data:
            return None
        try:
            data = json.loads(chunk.data)
        except (json.JSONDecodeError, ValueError):
            return None
        if not isinstance(data, dict):
            return None

        event = chunk.event or data.get("type")
        if event == "response.output_text.delta":
            return UnifiedStreamEvent(type="text_delta", text=data.get("delta", ""))
        if event in ("response.reasoning_summary_text.delta", "response.reasoning_text.delta"):
            return UnifiedStreamEvent(type="reasoning_delta", text=data.get("delta", ""))
        if event in ("response.completed", "response.incomplete"):
            response = data.get("response") or {}
            usage = self._map_usage(response.get("usage") or {})
            finish_reason = "length" if event == "response.incomplete" else "stop"
            ctx.state["finish_reason"] = finish_reason
            return UnifiedStreamEvent(type="usage", usage=usage, finish_reason=finish_reason)
        return None

    @staticmethod
    def _map_usage(usage_raw: dict) -> TokenUsage:
        """把 Responses API 的 `usage` 对象翻译成统一的 `TokenUsage`。

        注意 Responses 侧的推理 token 藏在 `output_tokens_details.reasoning_tokens`，
        且已经包含在 `output_tokens` 里，所以 `total_tokens` 只做 input + output，
        不再把 reasoning 重复加一次。

        异常：纯映射，约定不抛异常（字段缺失一律按 0 处理）。
        """
        details = usage_raw.get("output_tokens_details") or {}
        input_tokens = usage_raw.get("input_tokens", 0) or 0
        output_tokens = usage_raw.get("output_tokens", 0) or 0
        reasoning_tokens = details.get("reasoning_tokens", 0) or 0
        return TokenUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            reasoning_tokens=reasoning_tokens,
            total_tokens=input_tokens + output_tokens,
        )
