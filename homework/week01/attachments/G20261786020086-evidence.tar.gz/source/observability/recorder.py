"""调用记录：内存滚动窗口 + jsonl 追加落盘。

架构位置：网关「可观测层」的记录端。调用编排层（resilience/pipeline.py）每
结束一次调用就把一条 `CallRecord` 交给它；同时被 HTTP 层 `/v1/requests` 读取，
也被聚合指标模块（observability/metrics.py）消费。

对应的 Java 概念：
- `pydantic.BaseModel` ≈ 带运行时校验的 Java POJO/record；`Field(default_factory=...)`
  ≈ 构造默认值（类似 `new ArrayList<>()`，不能写 `= []` 否则所有实例共享同一个列表）。
- `collections.deque(maxlen=...)` ≈ 固定容量的环形缓冲区（超过上限自动丢最旧的）。
- `threading.Lock` ≈ Java 的 `synchronized`；`with self._lock:` ≈ try-with-resources
  风格的自动释放（Python 的 `with` 一定释放，≈ Java 的 try-finally）。
- jsonl 格式 = 每行一个 JSON 对象，方便用 grep/awk 直接查。

注意：磁盘写入失败会被**静默忽略**（见 `record`），保证观测组件不会拖垮主链路。
"""

from __future__ import annotations

import json
import threading
from collections import deque
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from core.types import TokenUsage


class AttemptRecord(BaseModel):
    """单次尝试的记录。一次调用可能有多个 AttemptRecord（对应重试）。

    注意这里只有「尝试级别」的信息：谁失败了、失败码是什么、这次用了多少 token。
    """

    attempt: int
    ok: bool
    error_code: str | None = None
    upstream_status: int | None = None
    usage: TokenUsage = Field(default_factory=TokenUsage)
    prompt_hash: str = ""
    prompt_strength: int = 0
    partial_output_chars: int | None = None
    upstream_endpoint: str | None = None


class CallRecord(BaseModel):
    """一次完整调用的记录（一个请求一条）。

    包含最终结果（status / error_code / usage）与过程信息（attempts 里每一次
    尝试的明细、延迟、命中的提示词模板版本）。
    """

    request_id: str
    ts: str
    model: str
    caller: str = "anonymous"
    adapter: str
    provider: str
    protocol: str
    stream: bool
    status: Literal["success", "error", "cancelled"]
    error_code: str | None = None
    error_message: str | None = None
    error_stage: str | None = None
    attempt_count: int = 1
    retry_count: int = 0
    last_upstream_status: int | None = None
    upstream_response_id: str | None = None
    latency_ms: float = 0.0
    ttft_ms: float | None = None
    usage: TokenUsage = Field(default_factory=TokenUsage)
    cost_usd: float | None = None
    upstream_endpoint: str | None = None
    failover_count: int = 0
    metadata: dict[str, str] = Field(default_factory=dict)
    prompt_template: str | None = None
    prompt_version: int | None = None
    rendered_prompt: str | None = None
    attempts: list[AttemptRecord] = Field(default_factory=list)


class Recorder:
    """调用记录器：内存窗口（供查询）+ jsonl 文件（供持久化与事后分析）。

    关键约束：内存里的记录**只保留最近 window_size 条**（环形缓冲区），更早的
    只能去 jsonl 文件里查；写盘失败不影响内存记录。
    """

    def __init__(self, data_dir: Path, window_size: int = 1000) -> None:
        self.data_dir = data_dir
        self.path = data_dir / "requests.jsonl"
        # deque(maxlen=...) ≈ 固定容量环形缓冲区，超出自动丢弃最旧的一条。
        self._records: deque[CallRecord] = deque(maxlen=window_size)
        self._lock = threading.Lock()

    def record(self, record: CallRecord) -> None:
        """记录一次调用：先入内存窗口，再追加写 jsonl。

        不抛异常：磁盘问题（目录不可写、磁盘满）被吞掉，因为观测失败不应该让
        业务请求失败。
        """
        with self._lock:
            self._records.append(record)
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(record.model_dump_json() + "\n")
        except OSError:
            pass

    def list(
        self,
        model: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
        caller: str | None = None,
    ) -> list[CallRecord]:
        """按模型/状态/租户过滤内存窗口中的记录，按时间倒序分页返回。

        参数：`model`/`status`/`caller` 为 None 表示不过滤；`limit` 是页大小，
        `offset` 是偏移量（≈ SQL 的 LIMIT/OFFSET）。

        返回值：`CallRecord` 列表（新的在前）。不抛异常。
        """
        with self._lock:
            items = list(self._records)
        if model:
            items = [item for item in items if item.model == model]
        if status:
            items = [item for item in items if item.status == status]
        if caller:
            items = [item for item in items if item.caller == caller]
        # deque 按写入顺序（旧的在前），反转成「最新的在前」符合直觉。
        items.reverse()
        return items[offset : offset + limit]
