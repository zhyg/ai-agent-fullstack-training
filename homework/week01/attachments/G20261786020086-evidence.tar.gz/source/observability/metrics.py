"""聚合指标：Token 分类统计 + 延迟分位 + 错误与重试计数。

架构位置：网关「可观测层」的消费端。调用编排层每结束一次调用就把一条
`CallRecord` 交给 `Metrics.observe()`，由它维护「全局一份 + 每个模型一份」的
累计统计，供 `/v1/metrics` 查询。

对应的 Java 概念：
- `collections.defaultdict(int)` ≈ `new HashMap<>()` + 缺失时自动 put 0。
- `threading.Lock` ≈ Java 的 `synchronized`；这里用锁保证「读-改-写」不被并发穿插。
- 本模块是**累计量**（counter/求和型），不是 Prometheus 那种带时间窗口的 gauge；
  延迟分位是按「全部样本」算的，样本越多越准但不会自动过期。

注意：指标只存在内存里，进程重启即清零（对比 recorder 还会落 jsonl）。
"""

from __future__ import annotations

import threading
from collections import defaultdict

from observability.recorder import CallRecord

# 需要累计的 token 分类字段，与 TokenUsage 的字段一一对应。
_TOKEN_FIELDS = (
    "input_tokens",
    "output_tokens",
    "reasoning_tokens",
    "cache_read_tokens",
    "cache_write_tokens",
    "total_tokens",
)


def _percentile(values: list[float], fraction: float) -> float:
    """求分位数（近似算法，不插值）。

    参数：`values` 为样本，`fraction` 为分位（如 0.95 表示 p95）。

    返回值：分位值；样本为空时返回 0.0。

    坑：这是「最近秩法」，只取已有样本中的某一个值，不像 Java 的
    `Percentile` 库会做线性插值。
    """
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(round(fraction * (len(ordered) - 1)))))
    return ordered[index]


class _Bucket:
    """单个统计桶（一批请求的聚合结果）。

    有两个实例在用：一个代表全局，一个代表某个模型。字段名与输出 JSON 的键
    一一对应。
    """

    def __init__(self) -> None:
        self.requests = 0
        self.errors = 0
        # 客户端断开导致的取消（契约 §6.5）：单独计数，**不算 error**。
        self.cancelled = 0
        self.tokens = {field: 0 for field in _TOKEN_FIELDS}
        self.latencies: list[float] = []
        self.ttfts: list[float] = []
        self.retry_total = 0
        self.retry_success = 0
        self.retry_exhausted = 0
        self.retry_by_error_code: dict[str, int] = defaultdict(int)
        self.error_by_code: dict[str, int] = defaultdict(int)
        self.rate_limit_rejected = 0
        # 成本（v2.8）：已知成本之和 + 成本未知的请求数。
        # 分开记是为了让「金额为 0」不被误读成「没花钱」——可能是模型没定价。
        self.cost_usd = 0.0
        self.unpriced_requests = 0
        # 多上游 failover（v2.9）：这次调用里切换过几次端点。
        self.failover_total = 0

    def snapshot(self) -> dict:
        """把当前累计值导出成一个普通 dict（可直接 JSON 序列化）。

        注意延迟列表的原始样本仍留在桶里，样本无限增长是这个实现的已知取舍。
        """
        latencies = self.latencies
        ttfts = self.ttfts
        return {
            "requests": self.requests,
            "errors": self.errors,
            "cancelled": self.cancelled,
            "tokens": dict(self.tokens),
            "latency_ms": {
                "avg": round(sum(latencies) / len(latencies), 2) if latencies else 0.0,
                "p50": round(_percentile(latencies, 0.50), 2),
                "p95": round(_percentile(latencies, 0.95), 2),
                "max": round(max(latencies), 2) if latencies else 0.0,
            },
            "ttft_ms": {
                "count": len(ttfts),
                "avg": round(sum(ttfts) / len(ttfts), 2) if ttfts else 0.0,
                "p50": round(_percentile(ttfts, 0.50), 2),
                "p95": round(_percentile(ttfts, 0.95), 2),
            },
            "retry": {
                "total": self.retry_total,
                "success": self.retry_success,
                "exhausted": self.retry_exhausted,
                "by_error_code": dict(self.retry_by_error_code),
            },
            "errors_by_code": dict(self.error_by_code),
            "rate_limit_rejected": self.rate_limit_rejected,
            "cost_usd": round(self.cost_usd, 6),
            "unpriced_requests": self.unpriced_requests,
            "failover_total": self.failover_total,
        }


class Metrics:
    """聚合指标收集器。

    关键约束：一次 `observe()` 会同时更新「全局桶」「该模型的桶」「该租户的桶」
    「该 (租户, 模型) 的桶」，四者的数字必须始终一致；所有更新都在同一把锁内完成。

    四个维度的桶各有用途：
    - 全局：管理员看整体；
    - 按模型：容量规划（哪个模型吃额度）；
    - 按租户：谁的用量（对账）；
    - 按 (租户, 模型)：普通租户视角的「by_model」。
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # defaultdict：第一次遇到某个模型名时自动建一个空桶（≈ Java 的 computeIfAbsent）。
        self._by_model: dict[str, _Bucket] = defaultdict(_Bucket)
        self._by_caller: dict[str, _Bucket] = defaultdict(_Bucket)
        self._by_caller_model: dict[tuple[str, str], _Bucket] = defaultdict(_Bucket)
        self._overall = _Bucket()

    def observe(self, record: CallRecord) -> None:
        """把一条调用记录计入统计（全局 + 按模型 + 按租户）。不抛异常。"""
        with self._lock:
            for bucket in (
                self._overall,
                self._by_model[record.model],
                self._by_caller[record.caller],
                self._by_caller_model[(record.caller, record.model)],
            ):
                self._apply(bucket, record)

    @staticmethod
    def _apply(bucket: _Bucket, record: CallRecord) -> None:
        """把单条记录累加进某个桶的各计数器。"""
        bucket.requests += 1
        if record.status == "error":
            bucket.errors += 1
            if record.error_code:
                bucket.error_by_code[record.error_code] += 1
        elif record.status == "cancelled":
            bucket.cancelled += 1
        for field in _TOKEN_FIELDS:
            bucket.tokens[field] += getattr(record.usage, field, 0)
        bucket.latencies.append(record.latency_ms)
        if record.ttft_ms is not None:
            bucket.ttfts.append(record.ttft_ms)
        bucket.retry_total += record.retry_count
        if record.retry_count:
            # 「重试过并且最终成功」与「重试到耗尽仍失败」分开统计，
            # 这样能区分「重试救回来了」和「重试也没用」。
            # 取消（cancelled）既不是成功也不是耗尽，单独不算（契约 §6.5）。
            if record.status == "success":
                bucket.retry_success += 1
            elif record.status == "error":
                bucket.retry_exhausted += 1
            for attempt in record.attempts:
                if attempt.error_code:
                    bucket.retry_by_error_code[attempt.error_code] += 1
        if record.error_code == "GW_RATE_LIMITED":
            bucket.rate_limit_rejected += 1
        if record.cost_usd is None:
            bucket.unpriced_requests += 1
        else:
            bucket.cost_usd += record.cost_usd
        bucket.failover_total += record.failover_count

    def snapshot(self, caller: str | None = None) -> dict:
        """导出统计快照。不抛异常。

        `caller` 为 None = **全局视角**（管理员）：返回全部数据。
        `caller` 非 None = **租户视角**：返回的三个分组都只含该租户的数据，
        但**响应形状保持不变**（overall + by_model + by_caller），客户端解析逻辑
        不需要因为「我是不是管理员」而写两套。
        """
        with self._lock:
            if caller is None:
                return {
                    "overall": self._overall.snapshot(),
                    "by_model": {
                        name: bucket.snapshot() for name, bucket in self._by_model.items()
                    },
                    "by_caller": {
                        name: bucket.snapshot() for name, bucket in self._by_caller.items()
                    },
                }
            own = self._by_caller.get(caller, _Bucket())
            return {
                "overall": own.snapshot(),
                "by_model": {
                    model: bucket.snapshot()
                    for (owner, model), bucket in self._by_caller_model.items()
                    if owner == caller
                },
                "by_caller": {caller: own.snapshot()},
            }
