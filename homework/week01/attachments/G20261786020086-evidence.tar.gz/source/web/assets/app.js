/**
 * 工作台入口：页签路由、API Key 管理、身份推断、轮询调度。
 *
 * 它是唯一「知道全局」的地方：其余模块（api.js / dom.js / charts.js / views/*）
 * 都只管自己那一块。这里的职责边界是——
 * - 谁是「当前视图」（页签路由 + 生命周期）；
 * - 密钥变更时如何让所有在途请求作废（epoch，见 DESIGN §8.8.6 第三层防护）；
 * - 提示条与详情抽屉（跨视图共享的 UI 外壳）。
 *
 * 对应的 Java 概念：≈ 一个前端控制器（≈ Spring MVC 的 `DispatcherServlet` +
 * `HandlerInterceptor`）：路由到视图、拦截器做生命周期回调、视图是「渲染层」。
 */

import { apiGet, createLatest } from "./api.js";
import { chartsAvailable, resizeCharts } from "./charts.js";
import { appendAll, clear, el } from "./dom.js";
import { maskKey, getApiKey, setApiKey } from "./store.js";
import { createOverview } from "./views/overview.js";
import { createRecords } from "./views/records.js";
import { createModels } from "./views/models.js";
import { createPrompts } from "./views/prompts.js";
import { createPlayground } from "./views/playground.js";

/** 页签名 → 视图容器 id。 */
const VIEWS = {
  overview: "view-overview",
  records: "view-records",
  models: "view-models",
  prompts: "view-prompts",
  playground: "view-playground",
};

const app = {
  /** 当前视图名。 */
  current: "overview",
  /** 视图实例表（懒创建）。 */
  instances: {},
  /**
   * 密钥代次：换 key 就 ++。任何跨越 await 的旧结果，回来时发现代次变了就丢弃。
   * 这是 DESIGN §8.8.6 的第三层防护（前两层在 api.js 的 createLatest 里）。
   */
  epoch: 0,
  /** 推断出的身份。 */
  identity: { name: "", isAdmin: false, known: false },
};

/* ------------------------------------------------------------------ 提示条 */

const toastRoot = document.getElementById("toast-root");

function toast(message, isError) {
  const node = el("div", { class: isError ? "toast is-error" : "toast", text: message });
  toastRoot.append(node);
  setTimeout(() => node.remove(), 3000);
}

/* -------------------------------------------------------------------- 抽屉 */

const drawerRoot = document.getElementById("drawer-root");
let drawerCloser = null;

function closeDrawer() {
  clear(drawerRoot);
  drawerCloser = null;
}

function openDrawer(title, body) {
  closeDrawer();
  const backdrop = el("div", {
    class: "drawer-backdrop",
    onclick: (event) => {
      if (event.target === backdrop) closeDrawer();
    },
  });
  const close = el("button", {
    class: "drawer-close",
    type: "button",
    text: "关闭",
    onclick: () => closeDrawer(),
  });
  const drawer = el("aside", { class: "drawer" }, [
    el("div", { class: "drawer-head" }, [
      el("h2", { class: "section-title", text: title }),
      close,
    ]),
    body,
  ]);
  backdrop.append(drawer);
  drawerRoot.append(backdrop);
  drawerCloser = close;

  const onKey = (event) => {
    if (event.key === "Escape") {
      closeDrawer();
      document.removeEventListener("keydown", onKey);
    }
  };
  document.addEventListener("keydown", onKey);
}

/* ------------------------------------------------------------ 身份推断 */

/**
 * 推断当前身份。
 *
 * 网关的接口不返回「你是谁」，只能间接推断（见 DESIGN §8.8.5）：
 * 1. `/v1/metrics` 的 `by_caller` 对普通租户恒为单键（= 自己的租户名），
 *    对管理员则是全部租户——所以「单键」是普通租户的指纹。
 * 2. 管理员判定：显式查一个不存在的调用方 `__probe__`——管理员会真的去过滤
 *    （200），普通租户则因「不许查别人的记录」被拒（400）。
 *
 * 结论是**推断**而非权威身份，界面上必须标注。
 */
async function inferIdentity() {
  const identity = { name: "", isAdmin: false, known: false };
  try {
    const metrics = await apiGet("/v1/metrics");
    const callers = Object.keys((metrics && metrics.by_caller) || {});
    if (callers.length === 1) {
      identity.name = callers[0];
      identity.known = true;
    } else if (callers.length > 1) {
      identity.name = `${callers.length} 个租户`;
      identity.known = true;
    }
  } catch {
    // 指标取不到（多半是 401）→ 身份未知，后面统一按「未知」处理。
  }

  try {
    await apiGet("/v1/requests", { params: { caller: "__probe__", limit: 1 } });
    identity.isAdmin = true;
  } catch {
    identity.isAdmin = false;
  }
  return identity;
}

/** 把推断出的身份画到顶栏。 */
function paintIdentity() {
  const node = document.getElementById("identity");
  if (!node) return;
  clear(node);
  node.hidden = false;
  const { name, isAdmin, known } = app.identity;
  // 注意用 appendAll 而不是 node.append(...)：DOM 的 append 会把 null
  // 当成字符串 "null" 渲染出来。
  appendAll(node, [
    el("span", { class: "identity-name", text: known ? name : "身份未知" }),
    el("span", { class: "identity-tag", text: "推断" }),
    isAdmin ? el("span", { class: "identity-tag is-admin", text: "管理员" }) : null,
  ]);
}

/* ------------------------------------------------------------ 密钥缺失遮罩 */

const gateRoot = document.getElementById("gate-root");

/**
 * 401 遮罩：需要 API Key 时盖住页面，提示去右上角填。
 *
 * 页面本身是免鉴权的（静态资源不含数据），真正的数据都要带 key 去取，
 * 所以「缺 key」不是加载失败，而是「还差一步」。
 */
function showGate(message) {
  clear(gateRoot);
  const card = el("div", { class: "gate-card" }, [
    el("h2", { class: "gate-title", text: "需要 API Key" }),
    el("p", {
      class: "gate-text",
      text: message || "网关开启了鉴权。请在右上角填入网关的 API Key 后再试。",
    }),
    el("button", {
      class: "btn btn-primary",
      type: "button",
      text: "我已填好，重新加载",
      onclick: async () => {
        clear(gateRoot);
        await onKeyChanged();
      },
    }),
  ]);
  gateRoot.append(el("div", { class: "gate" }, [card]));
}

/** 是不是「缺/错密钥」这种错误。 */
function isAuthError(error) {
  return Boolean(error) && error.name === "UnauthorizedError";
}

/* ------------------------------------------------------------------ 密钥 */

const keyForm = document.getElementById("key-form");
const keyInput = document.getElementById("key-input");
const keyClear = document.getElementById("key-clear");

function paintKeyPlaceholder() {
  const key = getApiKey();
  keyInput.value = "";
  keyInput.placeholder = key ? `已保存 ${maskKey(key)}` : "留空 = 未开启鉴权";
}

/**
 * 换密钥：代次 ++，让所有在途结果作废，然后重新推断身份并重载当前视图。
 */
async function onKeyChanged() {
  app.epoch += 1;
  clear(gateRoot);
  paintKeyPlaceholder();
  app.identity = await inferIdentity();
  paintIdentity();
  await reloadCurrent();
}

/* -------------------------------------------------------------- 视图路由 */

const views = {
  overview: createOverview,
  records: createRecords,
  models: createModels,
  prompts: createPrompts,
  playground: createPlayground,
};

const host = {
  toast,
  /** 统一的错误出口：缺/错密钥 → 遮罩提示，其它 → 提示条。 */
  fail(error) {
    if (isAuthError(error)) {
      showGate("网关开启了鉴权，但当前密钥缺失或无效。请在右上角重新填入 API Key。");
      return;
    }
    toast((error && error.message) || "操作失败", true);
  },
  openDrawer,
  closeDrawer,
  get epoch() {
    return app.epoch;
  },
  get identity() {
    return app.identity;
  },
};

/** 取（并懒创建）某个视图的实例。 */
function instanceOf(name) {
  if (!app.instances[name]) {
    app.instances[name] = views[name](host);
  }
  return app.instances[name];
}

/** 切换页签。 */
async function switchView(name) {
  if (!VIEWS[name] || name === app.current) return;
  const previous = app.instances[app.current];
  if (previous) previous.deactivate();

  app.current = name;
  for (const [key, id] of Object.entries(VIEWS)) {
    document.getElementById(id).hidden = key !== name;
  }
  for (const tab of document.querySelectorAll(".tab")) {
    tab.classList.toggle("is-active", tab.dataset.view === name);
  }

  const view = instanceOf(name);
  try {
    await view.mount(document.getElementById(VIEWS[name]));
  } catch (error) {
    host.fail(error);
  }
  view.activate();
}

/** 重载当前视图（换 key、切回前台时用）。 */
async function reloadCurrent() {
  const view = instanceOf(app.current);
  try {
    await view.reload();
  } catch (error) {
    host.fail(error);
  }
}

/* ------------------------------------------------------------------ 启动 */

function bindTabs() {
  for (const tab of document.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => {
      switchView(tab.dataset.view);
    });
  }
}

function bindKeyForm() {
  keyForm.addEventListener("submit", (event) => {
    event.preventDefault();
    setApiKey(keyInput.value);
    onKeyChanged();
  });
  keyClear.addEventListener("click", () => {
    setApiKey("");
    onKeyChanged();
  });
}

/** 页面切到后台时停轮询：回到前台立即刷一次。 */
function bindVisibility() {
  document.addEventListener("visibilitychange", () => {
    const view = app.instances[app.current];
    if (!view) return;
    if (document.hidden) {
      view.deactivate();
    } else {
      view.activate();
      view.reload().catch((error) => host.fail(error));
    }
  });
}

async function start() {
  bindTabs();
  bindKeyForm();
  bindVisibility();
  paintKeyPlaceholder();

  window.addEventListener("resize", () => {
    resizeCharts();
  });

  if (!chartsAvailable()) {
    toast("图表库未加载（CDN 不可达），已降级为纯表格。", true);
  }

  app.identity = await inferIdentity();
  paintIdentity();

  const view = instanceOf("overview");
  try {
    await view.mount(document.getElementById(VIEWS.overview));
  } catch (error) {
    host.fail(error);
  }
  view.activate();
}

start().catch((error) => {
  // 兜底：启动期的任何异常都不该让页面变成一片空白。
  toast((error && error.message) || "工作台启动失败", true);
});
