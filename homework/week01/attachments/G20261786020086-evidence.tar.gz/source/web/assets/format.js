/**
 * 展示格式化：把后端的原始数值变成人读的形式。
 *
 * 单独一个模块的原因：总览、调用记录、模型三个页签都要用同一套口径
 * （时间怎么显示、金额几位小数、耗时用 ms 还是 s），口径散在各视图里
 * 迟早会打架。
 *
 * 对应的 Java 概念：≈ 一组 `DateTimeFormatter` / `DecimalFormat` 常量，
 * 相当于把「怎么显示」与「显示什么」分开。
 */

const NUMBER = new Intl.NumberFormat("zh-CN");

/** 千分位整数。 */
export function fmtInt(value) {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return NUMBER.format(Math.round(value));
}

/** 固定小数位。 */
export function fmtNum(value, digits = 2) {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return Number(value).toFixed(digits);
}

/** 百分比（分母为 0 时返回 0%）。 */
export function fmtPercent(part, total) {
  if (!total) return "0%";
  return `${((part / total) * 100).toFixed(1)}%`;
}

/** 耗时：小于 1 秒用 ms，否则用秒。 */
export function fmtMs(value) {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  if (value < 1000) return `${Math.round(value)} ms`;
  return `${(value / 1000).toFixed(2)} s`;
}

/** 金额（USD）。未定价是 null → 显示「未定价」，不是 0。 */
export function fmtCost(value) {
  if (value === null || value === undefined) return "未定价";
  const amount = Number(value);
  if (amount === 0) return "$0";
  if (amount < 0.01) return `$${amount.toFixed(6)}`;
  return `$${amount.toFixed(4)}`;
}

/** ISO 时间戳 → 本地时间 `MM-DD HH:mm:ss`。 */
export function fmtTime(iso) {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return String(iso);
  const pad = (n) => String(n).padStart(2, "0");
  return (
    `${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
    `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
  );
}

/** 状态 → 徽章的类别。 */
export function statusKind(status) {
  if (status === "success") return "success";
  if (status === "error") return "error";
  if (status === "cancelled") return "cancelled";
  return "muted";
}

/** 状态的中文标签。 */
export function statusLabel(status) {
  if (status === "success") return "成功";
  if (status === "error") return "失败";
  if (status === "cancelled") return "已取消";
  return status || "—";
}
