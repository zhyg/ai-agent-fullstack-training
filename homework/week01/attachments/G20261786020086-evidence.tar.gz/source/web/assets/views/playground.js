/**
 * 试调用页签：向 `POST /v1/chat/completions` 发一次**真实**请求。
 *
 * 这一页存在的理由（DESIGN §8.9）：其余页签展示的是「调用的运行结果」，
 * 但入口级的拒绝（未知字段 400、`stream` 与 `output_schema` 互斥 400）
 * 根本不产生调用记录，SSE 帧的形状也只在传输层存在——记录页永远看不到它们。
 *
 * 两条硬约束：
 * - **不自动发送**（§8.9.4）：没有定时器、没有自动重试，只有用户点「发送」。
 * - **不静默修正参数**（§8.9.2）：`stream` 与 `output_schema` 同时有值时只提示
 *   并给「仍要发送」的逃生口，绝不替用户去掉一个。
 *
 * 对应的 Java 概念：≈ 一个「调试用」的 HTTP 客户端面板——请求构造器 + 响应
 * 观察窗，但**不落盘、不留历史**。
 */

import { apiGet, apiPost, UnauthorizedError } from "../api.js";
import { badge, clear, el, empty, kv, section, text } from "../dom.js";
import { fmtCost, fmtInt, fmtMs } from "../format.js";

const DEFAULT_MESSAGES = '[{"role": "user", "content": "你好"}]';

/** 帧类型 → 徽章类别与中文标签（帧类型见 DESIGN §8.9.6）。 */
const FRAME_KIND = {
  text_delta: "accent",
  reasoning_delta: "muted",
  usage: "info",
  done: "success",
  error: "error",
};

const FRAME_LABEL = {
  text_delta: "文本增量",
  reasoning_delta: "推理增量",
  usage: "用量",
  done: "结束",
  error: "错误",
};

/** 视图工厂。 */
export function createPlayground(host) {
  let root = null;
  /** 在途请求的取消器（停止按钮 / 切页签时用）。 */
  let controller = null;

  let modelSelect = null;
  let messagesField = null;
  let schemaField = null;
  let metadataField = null;
  let varsField = null;
  let promptNameInput = null;
  let promptVersionInput = null;
  let promptNote = null;
  let streamCheck = null;
  let sendButton = null;
  let stopButton = null;
  let conflictBox = null;
  let outputRoot = null;
  let modelList = [];

  /** 互斥提示已被用户确认过（确认只对当前这一次发送有效）。 */
  let overrideConflict = false;

  /* ---------------------------------------------------------------- 表单 */

  /** 一个 JSON 文本域 + 它自己的提示行（本地校验的错误写在这里）。 */
  function jsonField(label, key, value, placeholder, rows) {
    const input = el("textarea", {
      class: "control code",
      rows: String(rows),
      spellcheck: "false",
      placeholder: placeholder || "",
    });
    input.value = value || "";
    const note = el("p", { class: "field-note" });
    const wrap = el("div", { class: "field-wrap field-wide" }, [
      el("span", { class: "field-label", text: label }),
      input,
      note,
    ]);
    return { key, wrap, input, note };
  }

  /** 一个普通文本输入。 */
  function textField(label, placeholder, width) {
    const input = el("input", {
      class: "control",
      type: "text",
      placeholder: placeholder || "",
      spellcheck: "false",
    });
    const wrap = el("div", { class: "field-wrap" }, [
      el("span", { class: "field-label", text: label }),
      input,
    ]);
    if (width) wrap.style.width = width;
    return { input, wrap };
  }

  /** 左侧的请求表单。 */
  function buildForm() {
    modelSelect = el("select", { class: "control" }, [
      el("option", { value: "", text: "（加载中…）" }),
    ]);

    messagesField = jsonField(
      "messages",
      "messages",
      DEFAULT_MESSAGES,
      '[{"role": "user", "content": "你好"}]',
      6,
    );
    schemaField = jsonField(
      "output_schema（可空）",
      "output_schema",
      "",
      '{"name": "weather", "schema": {"type": "object"}, "strict": true}',
      4,
    );
    metadataField = jsonField("metadata（可空）", "metadata", "", '{"trace_id": "abc"}', 2);
    varsField = jsonField("prompt.vars（可空）", "vars", "", '{"city": "北京"}', 2);

    const name = textField("prompt.name", "模板名", "220px");
    promptNameInput = name.input;
    const version = textField("prompt.version", "版本号", "120px");
    promptVersionInput = version.input;
    promptNote = el("p", { class: "field-note" });

    streamCheck = el("input", { type: "checkbox" });
    const streamLabel = el("label", { class: "field-check" }, [
      streamCheck,
      el("span", { text: "流式（stream）" }),
    ]);

    sendButton = el("button", {
      class: "btn btn-primary",
      type: "button",
      text: "发送",
      onclick: () => startSend(),
    });
    stopButton = el("button", {
      class: "btn btn-ghost",
      type: "button",
      text: "停止",
      disabled: "",
      onclick: () => stopSend(),
    });

    conflictBox = el("div", { class: "pg-conflict" });

    // 改动任一互斥相关的字段就撤销「仍要发送」的确认。
    streamCheck.addEventListener("change", () => {
      overrideConflict = false;
      clear(conflictBox);
    });
    schemaField.input.addEventListener("input", () => {
      overrideConflict = false;
      clear(conflictBox);
    });

    return el("div", { class: "card pg-form" }, [
      el("div", { class: "field-wrap field-wide" }, [
        el("span", { class: "field-label", text: "model" }),
        modelSelect,
      ]),
      messagesField.wrap,
      el("div", { class: "field-row pg-toolbar" }, [
        streamLabel,
        el("div", { class: "pg-toolbar-actions" }, [sendButton, stopButton]),
      ]),
      schemaField.wrap,
      el("div", { class: "field-wrap field-wide" }, [
        el("span", { class: "field-label", text: "prompt（可空）" }),
        el("div", { class: "field-row" }, [name.wrap, version.wrap, varsField.wrap]),
        promptNote,
      ]),
      metadataField.wrap,
      conflictBox,
    ]);
  }

  /* ---------------------------------------------------------- 本地校验 */

  /** 清掉所有字段的提示行。 */
  function clearNotes() {
    for (const field of [messagesField, schemaField, metadataField, varsField]) {
      field.note.textContent = "";
    }
    promptNote.textContent = "";
  }

  /** 解析一个 JSON 文本域；失败时把原因写到提示行并返回 undefined。 */
  function parseField(field, label) {
    const raw = field.input.value.trim();
    if (!raw) return undefined;
    try {
      return JSON.parse(raw);
    } catch (error) {
      field.note.textContent = `${label} 不是合法 JSON：${error.message}`;
      return undefined;
    }
  }

  /**
   * 收集请求体。
   *
   * 只做「JSON 能不能解析」与「明显的结构缺失」；其余（长度上限、条数上限、
   * metadata 的值类型…）一律交给后端——前端复刻一份契约只会多出一份会漂移
   * 的真相（DESIGN §8.9.2）。
   */
  function collect() {
    clearNotes();
    let failed = false;

    const messages = parseField(messagesField, "messages");
    if (messages === undefined && messagesField.input.value.trim()) {
      failed = true;
    } else if (!Array.isArray(messages) || messages.length === 0) {
      messagesField.note.textContent = "messages 必须是非空数组";
      failed = true;
    } else if (!messages.every((m) => m && typeof m === "object" && m.role && typeof m.content === "string")) {
      messagesField.note.textContent = "每条消息必须是 {role, content}，且 content 是字符串";
      failed = true;
    }

    const schema = parseField(schemaField, "output_schema");
    if (schema === undefined && schemaField.input.value.trim()) {
      failed = true;
    } else if (schema !== undefined && (typeof schema !== "object" || schema === null || Array.isArray(schema))) {
      schemaField.note.textContent = "output_schema 必须是一个对象";
      failed = true;
    }

    const metadata = parseField(metadataField, "metadata");
    if (metadata === undefined && metadataField.input.value.trim()) {
      failed = true;
    } else if (metadata !== undefined && (typeof metadata !== "object" || metadata === null || Array.isArray(metadata))) {
      metadataField.note.textContent = "metadata 必须是一个对象";
      failed = true;
    }

    const vars = parseField(varsField, "prompt.vars");
    if (vars === undefined && varsField.input.value.trim()) {
      failed = true;
    } else if (vars !== undefined && (typeof vars !== "object" || vars === null || Array.isArray(vars))) {
      varsField.note.textContent = "prompt.vars 必须是一个对象";
      failed = true;
    }

    const body = {
      model: modelSelect.value,
      messages: messages || [],
    };
    if (streamCheck.checked) body.stream = true;
    if (schema !== undefined) body.output_schema = schema;
    if (metadata !== undefined) body.metadata = metadata;

    const promptName = promptNameInput.value.trim();
    if (promptName) {
      body.prompt = { name: promptName };
      const version = promptVersionInput.value.trim();
      if (version) {
        const parsedVersion = Number(version);
        if (!Number.isInteger(parsedVersion) || parsedVersion < 1) {
          promptNote.textContent = "prompt.version 必须是 ≥ 1 的整数";
          failed = true;
        } else {
          body.prompt.version = parsedVersion;
        }
      }
      if (vars !== undefined) body.prompt.vars = vars;
    }

    return { body, failed };
  }

  /* ---------------------------------------------------------------- 输出 */

  /** 概要条：状态码、耗时、request id。 */
  function statusBar(status, elapsedMs, requestId) {
    return el("div", { class: "pg-status" }, [
      badge(status >= 200 && status < 300 ? "success" : "error", `HTTP ${status}`),
      el("span", { class: "mono", text: fmtMs(elapsedMs) }),
      el("span", { class: "faint", text: "X-Request-Id" }),
      el("span", { class: "mono", text: requestId || "—" }),
    ]);
  }

  /** 错误信封原文。 */
  function errorBlock(envelope, rawText) {
    return el("div", { class: "section" }, [
      el("h3", { class: "section-title", text: "错误信封" }),
      el("div", { class: "kv-grid" }, [
        kv("code", envelope.code || "—"),
        kv("type", envelope.type || "—"),
        kv("retriable", envelope.retriable === undefined ? "—" : String(envelope.retriable)),
        kv("message", envelope.message || "—"),
      ]),
      el("pre", { class: "pre", text: rawText || "(空)" }),
    ]);
  }

  /** 非流式的正常响应。 */
  function responseBlock(data, rawText) {
    const usage = data.usage || {};
    return el("div", { class: "section" }, [
      el("h3", { class: "section-title", text: "响应" }),
      el("div", { class: "kv-grid" }, [
        kv("id", data.id || "—"),
        kv("model", data.model || "—"),
        kv("finish_reason", data.finish_reason || "—"),
        kv("latency_ms", fmtMs(data.latency_ms)),
        kv("ttft_ms", data.ttft_ms === null || data.ttft_ms === undefined ? "—" : fmtMs(data.ttft_ms)),
        kv("token（入 / 出 / 推理 / 缓存读 / 缓存写）",
          `${fmtInt(usage.input_tokens)} / ${fmtInt(usage.output_tokens)} / ` +
          `${fmtInt(usage.reasoning_tokens)} / ${fmtInt(usage.cache_read_tokens)} / ` +
          `${fmtInt(usage.cache_write_tokens)}`),
        kv("cost_usd", fmtCost(data.cost_usd)),
      ]),
      data.reasoning_content
        ? el("div", { class: "section" }, [
            el("h3", { class: "section-title", text: "reasoning_content" }),
            el("pre", { class: "pre", text: data.reasoning_content }),
          ])
        : null,
      el("div", { class: "section" }, [
        el("h3", { class: "section-title", text: "content" }),
        el("pre", { class: "pre", text: data.content || "" }),
      ]),
      el("details", { class: "pg-raw" }, [
        el("summary", { text: "原始响应体" }),
        el("pre", { class: "pre", text: rawText }),
      ]),
    ]);
  }

  /** 流式的帧列表。 */
  function frameTable() {
    const body = el("tbody", {});
    const table = el("div", { class: "table-wrap" }, [
      el("table", { class: "data" }, [
        el("thead", {}, [
          el("tr", {}, [
            el("th", { class: "num", text: "#" }),
            el("th", { text: "类型" }),
            el("th", { text: "内容" }),
          ]),
        ]),
        body,
      ]),
    ]);
    return { table, body };
  }

  /**
   * 一个帧在表格里的一行。
   *
   * 内容列放**原文**：这一页存在的意义就是看清契约本身，摘要会把它抹平。
   * 可读性交给旁边的「累计文本」区。
   */
  function frameRow(index, payload) {
    let type = "未知";
    try {
      const parsed = JSON.parse(payload);
      type = parsed.type || "未知";
    } catch {
      // 不是 JSON 就当「未知」类型——线格式变了也要看得见。
    }
    return el("tr", {}, [
      el("td", { class: "num", text: String(index) }),
      el("td", {}, [badge(FRAME_KIND[type] || "muted", FRAME_LABEL[type] || type)]),
      el("td", { class: "mono pg-frame-text", text: payload }),
    ]);
  }

  /* ---------------------------------------------------------------- 发送 */

  /** 「仍要发送」的逃生口：确认互斥冲突，硬发一次。 */
  function showConflict() {
    clear(conflictBox);
    conflictBox.append(
      el("div", { class: "pg-warn" }, [
        el("span", {
          text:
            "网关会以 400 GW_INVALID_REQUEST 拒绝这个组合（stream 与 output_schema 互斥，见 DESIGN §4.1）。" +
            "前端不会替你去掉其中一个——要发就点下面这个按钮。",
        }),
        el("button", {
          class: "btn btn-sm",
          type: "button",
          text: "仍要发送",
          onclick: () => {
            overrideConflict = true;
            clear(conflictBox);
            startSend();
          },
        }),
      ]),
    );
  }

  /** 停止在途请求。 */
  function stopSend() {
    if (!controller) return;
    controller.abort();
    controller = null;
    setBusy(false);
    host.toast("已停止");
  }

  /** 发送中：禁用「发送」、启用「停止」。 */
  function setBusy(busy) {
    if (busy) {
      sendButton.setAttribute("disabled", "");
      stopButton.removeAttribute("disabled");
    } else {
      sendButton.removeAttribute("disabled");
      stopButton.setAttribute("disabled", "");
    }
  }

  /**
   * 发一次请求。
   *
   * 非流式：整体读入并渲染；流式：逐帧渲染，边到边显示。
   */
  async function startSend() {
    const { body, failed } = collect();
    if (failed) return;
    if (!body.model) {
      host.toast("先选一个模型", true);
      return;
    }

    const conflict = Boolean(body.stream) && body.output_schema !== undefined;
    if (conflict && !overrideConflict) {
      showConflict();
      return;
    }

    if (controller) controller.abort();
    controller = new AbortController();
    const signal = controller.signal;
    setBusy(true);
    clear(outputRoot);

    const startedAt = performance.now();
    let response;
    try {
      response = await apiPost("/v1/chat/completions", body, { signal });
    } catch (error) {
      controller = null;
      setBusy(false);
      if (error && error.name === "AbortError") {
        outputRoot.append(el("div", { class: "empty", text: "已中止。" }));
        return;
      }
      outputRoot.append(errorBlock({ code: "网络错误", message: error.message || String(error) }, ""));
      return;
    }

    const elapsed = Math.round(performance.now() - startedAt);
    const requestId = response.headers.get("x-request-id") || "";

    // 密钥缺失 / 无效：与其显示一屏错误信封，不如直接盖上「去右上角填 Key」的遮罩。
    if (response.status === 401) {
      controller = null;
      setBusy(false);
      host.fail(new UnauthorizedError());
      return;
    }

    if (body.stream) {
      await renderStream(response, elapsed, requestId);
    } else {
      await renderPlain(response, elapsed, requestId);
    }

    controller = null;
    setBusy(false);
  }

  /** 非流式：整体读入。 */
  async function renderPlain(response, elapsed, requestId) {
    const rawText = await response.text().catch(() => "");
    let data = null;
    try {
      data = JSON.parse(rawText);
    } catch {
      data = null;
    }

    outputRoot.append(statusBar(response.status, elapsed, requestId));

    if (!response.ok) {
      const envelope = (data && data.error) || { message: rawText };
      outputRoot.append(errorBlock(envelope, rawText));
      return;
    }
    if (!data) {
      outputRoot.append(el("pre", { class: "pre", text: rawText }));
      return;
    }
    outputRoot.append(responseBlock(data, rawText));
  }

  /**
   * 流式：逐帧读 SSE。
   *
   * 线格式是 `data: {json}\n\n`，**没有** `[DONE]` 哨兵——`done` 帧就是
   * 终止帧（DESIGN §8.9.6）。
   */
  async function renderStream(response, elapsed, requestId) {
    outputRoot.append(statusBar(response.status, elapsed, requestId));

    if (!response.ok) {
      const rawText = await response.text().catch(() => "");
      let data = null;
      try {
        data = JSON.parse(rawText);
      } catch {
        data = null;
      }
      outputRoot.append(errorBlock((data && data.error) || { message: rawText }, rawText));
      return;
    }
    if (!response.body) {
      outputRoot.append(el("div", { class: "empty", text: "响应没有可读流。" }));
      return;
    }

    const frames = frameTable();
    // 正文区是流式的主视图：每个增量**追加**一个新文本节点，而不是把累计
    // 字符串重写一遍——重写会闪烁、滚动跳变，也丢掉了「逐字到达」的手感
    // （DESIGN §8.9.3）。
    const caret = el("span", { class: "pg-caret", text: "▍" });
    const printer = el("div", { class: "pg-print is-live" }, [caret]);
    const reasoning = el("div", { class: "pg-reason" });

    outputRoot.append(
      el("div", { class: "section" }, [
        el("h3", { class: "section-title", text: "输出" }),
        printer,
      ]),
      el("details", { class: "pg-raw" }, [
        el("summary", { text: "思维链" }),
        reasoning,
      ]),
      el("details", { class: "pg-raw" }, [
        el("summary", { text: "逐帧原文" }),
        frames.table,
      ]),
    );

    let index = 0;
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    /** 把容器滚到底——正文变长时要跟得上。 */
    const scrollToEnd = () => {
      printer.scrollTop = printer.scrollHeight;
    };

    const handle = (payload) => {
      index += 1;
      frames.body.append(frameRow(index, payload));
      let parsed = null;
      try {
        parsed = JSON.parse(payload);
      } catch {
        // 不是 JSON 就只显示原文——线格式变了也要看得见。
        return;
      }
      if (parsed.type === "text_delta" && parsed.text) {
        // 光标始终是最后一个子节点：追加正文后再把它挪到末尾。
        printer.append(text(parsed.text), caret);
        scrollToEnd();
      } else if (parsed.type === "reasoning_delta" && parsed.text) {
        reasoning.append(text(parsed.text));
      }
    };

    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let cut = buffer.indexOf("\n\n");
        while (cut >= 0) {
          handle(buffer.slice(0, cut).replace(/^data:\s*/, "").trim());
          buffer = buffer.slice(cut + 2);
          cut = buffer.indexOf("\n\n");
        }
      }
      const tail = buffer.trim();
      if (tail) handle(tail.replace(/^data:\s*/, "").trim());
    } catch (error) {
      if (error && error.name === "AbortError") {
        outputRoot.append(el("div", { class: "empty", text: "已中止（已收到的正文保留在上方）。" }));
      } else {
        outputRoot.append(el("div", { class: "empty", text: `读取中断：${error.message || error}` }));
      }
    }
    // 流结束（或中断）——光标熄灭。
    printer.classList.remove("is-live");
  }

  /* ------------------------------------------------------------ 模型清单 */

  /** 模型下拉的选项来自 `/v1/models`（当前租户可见的那些），不手输。 */
  async function loadModels() {
    try {
      const data = await apiGet("/v1/models");
      modelList = (data && data.models) || [];
    } catch (error) {
      modelList = [];
      host.fail(error);
    }
    clear(modelSelect);
    if (modelList.length === 0) {
      modelSelect.append(el("option", { value: "", text: "（没有可用模型）" }));
      modelSelect.disabled = true;
      return;
    }
    for (const model of modelList) {
      modelSelect.append(el("option", { value: model.id, text: model.id }));
    }
  }

  return {
    async mount(container) {
      root = container;
      clear(root);
      outputRoot = el("div", { class: "pg-output" });

      root.append(
        el("div", { class: "pg-notice" }, [
          el("strong", { text: "这一页会发真实请求。" }),
          el("span", {
            text:
              "每次点「发送」都会消耗配额、产生 token 成本，并在「调用记录」页留下一条记录。" +
              "页面不会自动发送任何东西。",
          }),
        ]),
        el("div", { class: "pg-layout" }, [
          section("请求", "字段与 LLMRequest 一一对应（DESIGN §8.1）", buildForm()),
          section("响应", "状态码、耗时、request id，以及流式的逐帧序列", outputRoot),
        ]),
      );

      outputRoot.append(empty("还没有发过请求。"));
      await loadModels();
    },
    activate() {
      // 没有轮询：这一页的动作完全由用户触发。
    },
    deactivate() {
      // 切走页签就中断在途请求——别在后台替用户烧额度。
      if (controller) {
        controller.abort();
        controller = null;
      }
    },
    async reload() {
      await loadModels();
    },
  };
}
