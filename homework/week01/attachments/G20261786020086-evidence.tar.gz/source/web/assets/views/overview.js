/**
 * 总览页：指标看板。
 *
 * 数据来源只有一个——`GET /v1/metrics` 的一次响应（见 DESIGN §8.8.6：
 * 不用 `/v1/requests` 做轮询，那里的每条记录都带提示词全文，代价太大）。
 *
 * 图表全部由这一个响应派生，因此 KPI 卡片、图表、表格三者的数字必然一致。
 *
 * 对应的 Java 概念：≈ 一个 Controller 的 GET 方法 + 一个把 DTO 渲染成视图的
 * Presenter；轮询由外部（app.js）调度，视图只管「给我数据，我画出来」。
 */

import { apiGet, createLatest } from "../api.js";
import { badge, clear, el, empty, kv, section } from "../dom.js";
import { fmtCost, fmtInt, fmtMs, fmtNum, fmtPercent } from "../format.js";
import {
  categoryAxis,
  disposeChartsIn,
  mountChart,
  valueAxis,
} from "../charts.js";

const POLL_INTERVAL = 5000;

/** 一个 KPI 卡片。 */
function kpi(label, value, sub, tone) {
  return el("div", { class: tone ? `kpi is-${tone}` : "kpi" }, [
    el("div", { class: "kpi-label", text: label }),
    el("div", { class: "kpi-value", text: value }),
    sub ? el("div", { class: "kpi-sub", text: sub }) : null,
  ]);
}

/** 按模型的明细表。 */
function modelTable(byModel) {
  const names = Object.keys(byModel).sort();
  if (names.length === 0) return empty("还没有任何调用数据。");

  const rows = names.map((name) => {
    const bucket = byModel[name];
    const success = bucket.requests - bucket.errors - bucket.cancelled;
    return el("tr", {}, [
      el("td", { class: "mono", text: name }),
      el("td", { class: "num", text: fmtInt(bucket.requests) }),
      el("td", { class: "num", text: fmtInt(bucket.errors) }),
      el("td", { class: "num", text: fmtInt(bucket.cancelled) }),
      el("td", { class: "num", text: fmtPercent(bucket.errors, bucket.requests) }),
      el("td", { class: "num", text: fmtInt(bucket.tokens.total_tokens) }),
      el("td", { class: "num", text: fmtInt(bucket.tokens.input_tokens) }),
      el("td", { class: "num", text: fmtInt(bucket.tokens.output_tokens) }),
      el("td", { class: "num", text: fmtMs(bucket.latency_ms.p95) }),
      el("td", { class: "num", text: fmtInt(bucket.retry.total) }),
      el("td", { class: "num", text: fmtCost(bucket.cost_usd) }),
    ]);
  });

  return el("div", { class: "table-wrap" }, [
    el("table", { class: "data" }, [
      el("thead", {}, [
        el("tr", {}, [
          el("th", { text: "模型" }),
          el("th", { class: "num", text: "请求" }),
          el("th", { class: "num", text: "错误" }),
          el("th", { class: "num", text: "取消" }),
          el("th", { class: "num", text: "错误率" }),
          el("th", { class: "num", text: "总 token" }),
          el("th", { class: "num", text: "输入" }),
          el("th", { class: "num", text: "输出" }),
          el("th", { class: "num", text: "p95 延迟" }),
          el("th", { class: "num", text: "重试" }),
          el("th", { class: "num", text: "成本" }),
        ]),
      ]),
      el("tbody", {}, rows),
    ]),
  ]);
}

/** 按调用方的明细表。 */
function callerTable(byCaller) {
  const names = Object.keys(byCaller).sort();
  if (names.length === 0) return empty("还没有任何调用数据。");

  const rows = names.map((name) => {
    const bucket = byCaller[name];
    return el("tr", {}, [
      el("td", { class: "mono", text: name }),
      el("td", { class: "num", text: fmtInt(bucket.requests) }),
      el("td", { class: "num", text: fmtInt(bucket.errors) }),
      el("td", { class: "num", text: fmtInt(bucket.tokens.total_tokens) }),
      el("td", { class: "num", text: fmtMs(bucket.latency_ms.avg) }),
      el("td", { class: "num", text: fmtInt(bucket.rate_limit_rejected) }),
      el("td", { class: "num", text: fmtInt(bucket.failover_total) }),
      el("td", { class: "num", text: fmtCost(bucket.cost_usd) }),
    ]);
  });

  return el("div", { class: "table-wrap" }, [
    el("table", { class: "data" }, [
      el("thead", {}, [
        el("tr", {}, [
          el("th", { text: "调用方" }),
          el("th", { class: "num", text: "请求" }),
          el("th", { class: "num", text: "错误" }),
          el("th", { class: "num", text: "总 token" }),
          el("th", { class: "num", text: "平均延迟" }),
          el("th", { class: "num", text: "限流拒绝" }),
          el("th", { class: "num", text: "failover" }),
          el("th", { class: "num", text: "成本" }),
        ]),
      ]),
      el("tbody", {}, rows),
    ]),
  ]);
}

/** 视图工厂。 */
export function createOverview(host) {
  const latest = createLatest();
  let root = null;
  let timer = null;
  let failureStreak = 0;

  /** 用一次 metrics 响应把整页画出来。 */
  function render(data) {
    const overall = data.overall;
    const byModel = data.by_model || {};
    const byCaller = data.by_caller || {};
    const modelNames = Object.keys(byModel).sort();
    const callerNames = Object.keys(byCaller).sort();

    const kpis = el("div", { class: "kpi-grid" }, [
      kpi("请求数", fmtInt(overall.requests), `取消 ${fmtInt(overall.cancelled)}`),
      kpi(
        "错误数",
        fmtInt(overall.errors),
        `错误率 ${fmtPercent(overall.errors, overall.requests)}`,
        overall.errors ? "error" : "ok",
      ),
      kpi("总 token", fmtInt(overall.tokens.total_tokens), `输入 ${fmtInt(overall.tokens.input_tokens)} · 输出 ${fmtInt(overall.tokens.output_tokens)}`),
      kpi(
        "成本",
        fmtCost(overall.cost_usd),
        overall.unpriced_requests ? `${fmtInt(overall.unpriced_requests)} 次未定价` : "全部已定价",
      ),
      kpi("平均延迟", fmtMs(overall.latency_ms.avg), `p95 ${fmtMs(overall.latency_ms.p95)}`),
      kpi("最大延迟", fmtMs(overall.latency_ms.max), `p50 ${fmtMs(overall.latency_ms.p50)}`),
      kpi(
        "TTFT p95",
        overall.ttft_ms.count ? fmtMs(overall.ttft_ms.p95) : "—",
        `样本 ${fmtInt(overall.ttft_ms.count)} 条`,
      ),
      kpi(
        "重试",
        fmtInt(overall.retry.total),
        `救回 ${fmtInt(overall.retry.success)} · 耗尽 ${fmtInt(overall.retry.exhausted)}`,
      ),
      kpi(
        "限流拒绝",
        fmtInt(overall.rate_limit_rejected),
        "本地 429",
        overall.rate_limit_rejected ? "warn" : null,
      ),
      kpi("failover", fmtInt(overall.failover_total), "切换上游端点次数"),
    ]);

    // 重画之前先销毁旧图表实例——否则每 5 秒就多留一批（内存泄漏）。
    disposeChartsIn(root);
    clear(root);
    root.append(kpis);

    // --- 图表区 ---
    const chartGrid = el("div", { class: "card-grid" });

    const requestBox = el("div", { class: "chart-box" });
    const statusBox = el("div", { class: "chart-box" });
    const tokenBox = el("div", { class: "chart-box" });
    const latencyBox = el("div", { class: "chart-box" });
    const errorBox = el("div", { class: "chart-box" });
    const callerBox = el("div", { class: "chart-box" });

    chartGrid.append(
      el("div", { class: "card" }, [
        el("h3", { class: "section-title", text: "按模型的请求量" }),
        requestBox,
      ]),
      el("div", { class: "card" }, [
        el("h3", { class: "section-title", text: "按模型的结果构成" }),
        statusBox,
      ]),
      el("div", { class: "card" }, [
        el("h3", { class: "section-title", text: "按模型的 token 构成" }),
        tokenBox,
      ]),
      el("div", { class: "card" }, [
        el("h3", { class: "section-title", text: "按模型的延迟分位" }),
        latencyBox,
      ]),
      el("div", { class: "card" }, [
        el("h3", { class: "section-title", text: "错误码分布" }),
        errorBox,
      ]),
      el("div", { class: "card" }, [
        el("h3", { class: "section-title", text: "按调用方的请求量" }),
        callerBox,
      ]),
    );
    root.append(chartGrid);

    if (modelNames.length > 0) {
      mountChart(requestBox, {
        tooltip: { trigger: "axis", renderMode: "richText" },
        grid: { left: 8, right: 24, top: 16, bottom: 8, containLabel: true },
        xAxis: valueAxis("请求"),
        yAxis: { ...categoryAxis(modelNames), inverse: true },
        series: [
          {
            type: "bar",
            barMaxWidth: 22,
            itemStyle: { borderRadius: [0, 4, 4, 0] },
            data: modelNames.map((name) => byModel[name].requests),
          },
        ],
      });

      mountChart(statusBox, {
        tooltip: { trigger: "axis", renderMode: "richText" },
        xAxis: valueAxis("次数"),
        yAxis: { ...categoryAxis(modelNames), inverse: true },
        legend: { top: 0, data: ["成功", "失败", "取消"] },
        series: [
          {
            name: "成功",
            type: "bar",
            stack: "s",
            itemStyle: { color: "#40a02b" },
            data: modelNames.map(
              (name) =>
                byModel[name].requests -
                byModel[name].errors -
                byModel[name].cancelled,
            ),
          },
          {
            name: "失败",
            type: "bar",
            stack: "s",
            itemStyle: { color: "#d20f39" },
            data: modelNames.map((name) => byModel[name].errors),
          },
          {
            name: "取消",
            type: "bar",
            stack: "s",
            itemStyle: { color: "#df8e1d" },
            data: modelNames.map((name) => byModel[name].cancelled),
          },
        ],
      });

      mountChart(tokenBox, {
        tooltip: { trigger: "axis", renderMode: "richText" },
        legend: { top: 0 },
        xAxis: valueAxis("token"),
        yAxis: { ...categoryAxis(modelNames), inverse: true },
        series: [
          { name: "输入", type: "bar", stack: "t", data: modelNames.map((n) => byModel[n].tokens.input_tokens) },
          { name: "输出", type: "bar", stack: "t", data: modelNames.map((n) => byModel[n].tokens.output_tokens) },
          { name: "推理", type: "bar", stack: "t", data: modelNames.map((n) => byModel[n].tokens.reasoning_tokens) },
          { name: "缓存读", type: "bar", stack: "t", data: modelNames.map((n) => byModel[n].tokens.cache_read_tokens) },
          { name: "缓存写", type: "bar", stack: "t", data: modelNames.map((n) => byModel[n].tokens.cache_write_tokens) },
        ],
      });

      mountChart(latencyBox, {
        tooltip: { trigger: "axis", renderMode: "richText" },
        legend: { top: 0 },
        xAxis: valueAxis("毫秒"),
        yAxis: { ...categoryAxis(modelNames), inverse: true },
        series: [
          { name: "p50", type: "bar", data: modelNames.map((n) => byModel[n].latency_ms.p50) },
          { name: "p95", type: "bar", data: modelNames.map((n) => byModel[n].latency_ms.p95) },
          { name: "max", type: "bar", data: modelNames.map((n) => byModel[n].latency_ms.max) },
        ],
      });
    }

    const errorCodes = Object.entries(overall.errors_by_code || {});
    if (errorCodes.length > 0) {
      mountChart(errorBox, {
        tooltip: { trigger: "item", renderMode: "richText" },
        legend: { top: 0, type: "scroll" },
        series: [
          {
            type: "pie",
            radius: ["42%", "68%"],
            itemStyle: { borderColor: "#ffffff", borderWidth: 2 },
            label: { color: "#6c6f85", fontSize: 12 },
            data: errorCodes
              .sort((a, b) => b[1] - a[1])
              .map(([code, count]) => ({ name: code, value: count })),
          },
        ],
      });
    } else {
      clear(errorBox);
      errorBox.append(empty("没有错误记录。"));
    }

    if (callerNames.length > 0) {
      mountChart(callerBox, {
        tooltip: { trigger: "axis", renderMode: "richText" },
        xAxis: categoryAxis(callerNames),
        yAxis: valueAxis("请求"),
        series: [
          {
            type: "bar",
            barMaxWidth: 28,
            itemStyle: { borderRadius: [4, 4, 0, 0] },
            data: callerNames.map((name) => byCaller[name].requests),
          },
        ],
      });
    }

    // --- 表格区 ---
    root.append(
      section(
        "按模型",
        "与上方图表同源，图表不可用时这张表就是全部内容",
        modelTable(byModel),
      ),
      section(
        "按调用方",
        "普通租户只会看到自己一行——这是后端的数据隔离决定的",
        callerTable(byCaller),
      ),
    );
  }

  /** 拉一次数据并渲染。 */
  async function refresh() {
    const mine = host.epoch;
    const result = await latest.run((signal) =>
      apiGet("/v1/metrics", { signal }),
    );
    // 竞态防护：结果已过期就丢弃，绝不用旧数据盖掉新数据。
    if (result.stale) return;
    // 换密钥后旧响应一律作废（DESIGN §8.8.6 的第三层防护）。
    if (host.epoch !== mine) return;
    failureStreak = 0;
    render(result.data);
  }

  return {
    async mount(container) {
      root = container;
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
      }
    },
    activate() {
      // 轮询：只在本页签激活时跑；失败退避 5s → 30s 封顶。
      const tick = async () => {
        if (timer) return;
        try {
          await refresh();
          failureStreak = 0;
        } catch (error) {
          failureStreak += 1;
          const delay = Math.min(30000, 5000 * 2 ** (failureStreak - 1));
          host.fail(error);
          timer = setTimeout(() => {
            timer = null;
            tick();
          }, delay);
          return;
        }
        timer = setTimeout(() => {
          timer = null;
          tick();
        }, POLL_INTERVAL);
      };
      timer = setTimeout(() => {
        timer = null;
        tick();
      }, POLL_INTERVAL);
    },
    deactivate() {
      if (timer) clearTimeout(timer);
      timer = null;
      latest.abort();
      if (root) disposeChartsIn(root);
    },
    async reload() {
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
      }
    },
  };
}
