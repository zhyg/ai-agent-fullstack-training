/**
 * 提示词页：模板列表 + 详情 + 版本历史（**只读**）。
 *
 * 后端本来就有新建 / 追加版本 / 回滚接口，但本轮工作台的范围是「只读可观测面板」
 * （见 DESIGN §8.8.1），所以这里一个写操作都不接。
 *
 * 一个必须说清楚的事实：`/v1/prompts` **不按租户过滤**（见 DESIGN §8.8.5）——
 * 看到的是站点级模板，不是某个租户私有的模板。界面上必须标注出来，
 * 否则会被误读成「这是我的模板」。
 *
 * 对应的 Java 概念：≈ 一个只读的 DetailView + VersionHistory 列表，
 * 数据来自两个 GET 接口（列表 + 单个模板）。
 */

import { apiGet, createLatest } from "../api.js";
import { clear, el, empty, kv, section } from "../dom.js";
import { fmtTime } from "../format.js";

const INJECTIONS = {
  system: "作为一条 system 消息插到最前面",
  messages: "整段替换消息列表（渲染结果必须是 JSON 数组）",
};

/** 视图工厂。 */
export function createPrompts(host) {
  const latest = createLatest();
  let root = null;
  let templates = [];
  let selected = null;

  /** 模板列表。 */
  function listView() {
    if (templates.length === 0) return empty("还没有任何提示词模板。");
    const rows = templates.map((template) =>
      el(
        "tr",
        {
          class: "clickable",
          onclick: () => select(template.name),
        },
        [
          el("td", { class: "mono", text: template.name }),
          el("td", { text: template.description || "—" }),
          el("td", { text: template.injection || "system" }),
          el("td", { class: "num", text: template.current_version }),
          el("td", { class: "num", text: (template.versions || []).length }),
        ],
      ),
    );
    return el("div", { class: "table-wrap" }, [
      el("table", { class: "data" }, [
        el("thead", {}, [
          el("tr", {}, [
            el("th", { text: "名称" }),
            el("th", { text: "说明" }),
            el("th", { text: "注入方式" }),
            el("th", { class: "num", text: "当前版本" }),
            el("th", { class: "num", text: "版本数" }),
          ]),
        ]),
        el("tbody", {}, rows),
      ]),
    ]);
  }

  /** 单个模板的详情 + 版本历史。 */
  function detailView(template) {
    if (!template) return empty("点击左侧任意模板查看详情。");
    const versions = template.versions || [];
    const versionRows = versions.map((version) =>
      el("tr", {}, [
        el("td", { class: "num", text: version.version }),
        el("td", {
          text: version.version === template.current_version ? "当前生效" : "历史版本",
        }),
        el("td", { text: version.note || "—" }),
        el("td", { text: fmtTime(version.created_at) }),
        el("td", { text: (version.variables || []).join("、") || "—" }),
      ]),
    );

    const current = versions.find((v) => v.version === template.current_version);

    return el("div", {}, [
      el("div", { class: "kv-grid" }, [
        kv("名称", template.name),
        kv("说明", template.description || "—"),
        kv("注入方式", INJECTIONS[template.injection] || template.injection || "—"),
        kv("当前版本", template.current_version),
        kv("版本数", versions.length),
      ]),
      current
        ? el("div", { class: "section" }, [
            el("h3", { class: "section-title", text: "当前内容" }),
            el("pre", { class: "pre", text: current.content || "" }),
          ])
        : null,
      el("div", { class: "section" }, [
        el("h3", { class: "section-title", text: "版本历史" }),
        versions.length
          ? el("div", { class: "table-wrap" }, [
              el("table", { class: "data" }, [
                el("thead", {}, [
                  el("tr", {}, [
                    el("th", { class: "num", text: "版本" }),
                    el("th", { text: "状态" }),
                    el("th", { text: "备注" }),
                    el("th", { text: "创建时间" }),
                    el("th", { text: "变量" }),
                  ]),
                ]),
                el("tbody", {}, versionRows),
              ]),
            ])
          : empty("这个模板还没有版本记录。"),
      ]),
    ]);
  }

  function paint() {
    if (!root) return;
    clear(root);
    root.append(
      section(
        "提示词模板",
        "站点级模板，非租户私有——所有租户看到的是同一份",
        listView(),
      ),
      section(
        "模板详情",
        "只读视图；新建与回滚接口后端已有，本工作台不提供写入口",
        detailView(selected),
      ),
    );
  }

  /** 选中某个模板（单独请求一次详情接口）。 */
  async function select(name) {
    try {
      const mine = host.epoch;
      const result = await latest.run((signal) =>
        apiGet(`/v1/prompts/${encodeURIComponent(name)}`, { signal }),
      );
      if (result.stale) return;
      if (host.epoch !== mine) return;
      selected = result.data;
      paint();
    } catch (error) {
      host.fail(error);
    }
  }

  async function refresh() {
    const mine = host.epoch;
    const result = await latest.run((signal) => apiGet("/v1/prompts", { signal }));
    if (result.stale) return;
    // 换密钥后旧响应一律作废（DESIGN §8.8.6 的第三层防护）。
    if (host.epoch !== mine) return;
    templates = (result.data && result.data.data) || [];
    if (selected) {
      const still = templates.find((t) => t.name === selected.name);
      selected = still || null;
    }
    paint();
  }

  return {
    async mount(container) {
      root = container;
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
        paint();
      }
    },
    activate() {
      // 激活时加载一次即可。
    },
    deactivate() {
      latest.abort();
    },
    async reload() {
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
      }
    },
  };
}
