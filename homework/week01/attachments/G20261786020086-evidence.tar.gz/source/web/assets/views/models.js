/**
 * 模型页：`GET /v1/models` 的能力表。
 *
 * 这个接口的价值在于：调用方不必先发一个请求、再从 400 里读出答案，
 * 直接看「这个模型支持流式吗 / 支持 output_schema 吗 / 上限多大」。
 *
 * 只展示当前租户可见的模型——这是后端按租户过滤后的结果，不是前端裁的。
 *
 * 对应的 Java 概念：≈ 一个只读的资源列表视图 + 一次 `GET` 查询，
 * 没有写路径（工作台是只读的）。
 */

import { apiGet, createLatest } from "../api.js";
import { badge, clear, el, empty, section } from "../dom.js";
import { fmtInt } from "../format.js";

/** 能力项 → 中文标签。key 与 adapters/base.py 的 capabilities() 一致。 */
const CAPABILITIES = [
  ["streaming", "流式", "支持 SSE 流式响应"],
  ["output_schema", "结构化输出", "接受 output_schema"],
  ["output_schema_strict", "硬约束", "上游原生施加约束（否则由网关本地校验）"],
  ["prompt_cache", "提示词缓存", "支持缓存命中计费"],
];

const PROTOCOLS = {
  openai: "OpenAI",
  anthropic: "Anthropic",
  gemini: "Gemini",
  custom: "自定义",
};

/** 视图工厂。 */
export function createModels(host) {
  const latest = createLatest();
  let root = null;

  /** 能力徽章。 */
  function capabilityBadge(capabilities, key, label, hint) {
    const on = Boolean(capabilities[key]);
    return el("span", { class: "cap", title: hint }, [
      badge(on ? "success" : "muted", label),
    ]);
  }

  function table(models) {
    if (models.length === 0) return empty("当前租户看不到任何模型。");
    const rows = models.map((model) => {
      const capabilities = model.capabilities || {};
      return el("tr", {}, [
        el("td", { class: "mono", text: model.id }),
        el("td", { text: PROTOCOLS[model.protocol] || model.protocol || "—" }),
        ...CAPABILITIES.map(([key, label, hint]) =>
          el("td", {}, [capabilityBadge(capabilities, key, label, hint)]),
        ),
        el("td", {
          class: "num",
          text: capabilities.max_output_tokens
            ? fmtInt(capabilities.max_output_tokens)
            : "—",
        }),
        el("td", {
          class: "num",
          text: capabilities.max_input_tokens
            ? fmtInt(capabilities.max_input_tokens)
            : "—",
        }),
      ]);
    });

    return el("div", { class: "table-wrap" }, [
      el("table", { class: "data" }, [
        el("thead", {}, [
          el("tr", {}, [
            el("th", { text: "模型" }),
            el("th", { text: "协议" }),
            ...CAPABILITIES.map(([, label]) => el("th", { text: label })),
            el("th", { class: "num", text: "最大输出 token" }),
            el("th", { class: "num", text: "最大输入 token" }),
          ]),
        ]),
        el("tbody", {}, rows),
      ]),
    ]);
  }

  function render(models) {
    if (!root) return;
    clear(root);
    root.append(
      section(
        "模型能力",
        "后端按租户过滤后的可见清单——普通租户只看到自己能调用的模型",
        table(models),
      ),
    );
  }

  async function refresh() {
    const mine = host.epoch;
    const result = await latest.run((signal) => apiGet("/v1/models", { signal }));
    if (result.stale) return;
    // 换密钥后旧响应一律作废（DESIGN §8.8.6 的第三层防护）。
    if (host.epoch !== mine) return;
    render((result.data && result.data.models) || []);
  }

  return {
    async mount(container) {
      root = container;
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
      }
    },
    activate() {
      // 激活时加载一次即可：模型清单变动不频繁。
    },
    deactivate() {
      latest.abort();
    },
    async reload() {
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
      }
    },
  };
}
