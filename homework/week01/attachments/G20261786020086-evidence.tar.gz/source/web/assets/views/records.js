/**
 * 调用记录页：最近调用的明细 + 详情抽屉。
 *
 * 数据来源：`GET /v1/requests`（分页查询内存滚动窗口，见 DESIGN §8.8.6）。
 * 注意后端的 `limit` **没有上限**，而每条记录都带提示词全文——前端自己钉死
 * 200 条的上限，免得一个手滑把整个窗口拖回来。
 *
 * 记录来自 1000 条内存环形窗口（不是 jsonl 文件）：翻页期间新记录会挤掉旧记录，
 * 所以页脚明确提示「数据可能移动」，并提供「回到最新」按钮。
 *
 * 对应的 Java 概念：≈ 一个分页查询的 Controller 方法 + 一个带筛选条件的
 * ViewState；「回到最新」≈ 把页码重置并重新查询。
 */

import { apiGet, createLatest } from "../api.js";
import { badge, clear, el, empty, kv, section } from "../dom.js";
import { fmtCost, fmtInt, fmtMs, fmtTime, statusKind, statusLabel } from "../format.js";

const POLL_INTERVAL = 10000;
const PAGE_SIZE = 50;
/** 前端硬上限：后端不限制，但记录里带提示词全文，不能放开。 */
const MAX_LIMIT = 200;

const STATUS_OPTIONS = [
  ["", "全部状态"],
  ["success", "成功"],
  ["error", "失败"],
  ["cancelled", "已取消"],
];

/** 视图工厂。 */
export function createRecords(host) {
  const latest = createLatest();
  let root = null;
  let timer = null;
  let failureStreak = 0;

  const filters = { model: "", status: "", caller: "" };
  let offset = 0;
  let autoPoll = true;
  let rows = [];
  let latestRequestId = "";

  /** 顶部筛选条。 */
  function toolbar() {
    const modelInput = el("input", {
      class: "control",
      type: "text",
      placeholder: "模型名（精确匹配）",
      value: filters.model,
    });
    const statusSelect = el(
      "select",
      { class: "control" },
      STATUS_OPTIONS.map(([value, label]) =>
        el("option", { value, text: label, selected: value === filters.status }),
      ),
    );
    const callerInput = el("input", {
      class: "control",
      type: "text",
      placeholder: "调用方（精确匹配）",
      value: filters.caller,
      disabled: !host.identity.isAdmin,
    });

    const apply = async (reset) => {
      filters.model = modelInput.value.trim();
      filters.status = statusSelect.value;
      filters.caller = host.identity.isAdmin ? callerInput.value.trim() : "";
      if (reset) offset = 0;
      await safeRefresh();
    };

    modelInput.addEventListener("change", () => apply(true));
    statusSelect.addEventListener("change", () => apply(true));
    callerInput.addEventListener("change", () => apply(true));

    const pollToggle = el(
      "label",
      { class: "field-check" },
      [
        el("input", {
          type: "checkbox",
          checked: autoPoll,
          onchange: (event) => {
            autoPoll = event.target.checked;
            if (autoPoll) schedule();
          },
        }),
        el("span", { text: "自动刷新（10 秒）" }),
      ],
    );

    return el("div", { class: "toolbar" }, [
      el("label", { class: "field-wrap" }, [
        el("span", { class: "field-label", text: "模型" }),
        modelInput,
      ]),
      el("label", { class: "field-wrap" }, [
        el("span", { class: "field-label", text: "状态" }),
        statusSelect,
      ]),
      el("label", { class: "field-wrap" }, [
        el("span", { class: "field-label", text: "调用方" }),
        callerInput,
      ]),
      pollToggle,
      el("button", {
        class: "btn btn-ghost",
        type: "button",
        text: "回到最新",
        onclick: async () => {
          offset = 0;
          await safeRefresh();
        },
      }),
    ]);
  }

  /** 明细表。 */
  function table() {
    if (rows.length === 0) return empty("没有匹配的调用记录。");
    const head = el("tr", {}, [
      el("th", { text: "时间" }),
      el("th", { text: "模型" }),
      el("th", { text: "调用方" }),
      el("th", { text: "状态" }),
      el("th", { class: "num", text: "耗时" }),
      el("th", { class: "num", text: "TTFT" }),
      el("th", { class: "num", text: "token" }),
      el("th", { class: "num", text: "成本" }),
      el("th", { class: "num", text: "重试" }),
      el("th", { text: "上游端点" }),
      el("th", { class: "mono", text: "request_id" }),
    ]);
    const body = el(
      "tbody",
      {},
      rows.map((record) =>
        el(
          "tr",
          {
            class: "clickable",
            onclick: () => openDetail(record),
          },
          [
            el("td", { class: "mono", text: fmtTime(record.ts) }),
            el("td", { text: record.model }),
            el("td", { class: "mono", text: record.caller }),
            el("td", {}, [badge(statusKind(record.status), statusLabel(record.status))]),
            el("td", { class: "num", text: fmtMs(record.latency_ms) }),
            el("td", {
              class: "num",
              text: record.ttft_ms === null || record.ttft_ms === undefined
                ? "—"
                : fmtMs(record.ttft_ms),
            }),
            el("td", { class: "num", text: fmtInt(record.usage.total_tokens) }),
            el("td", { class: "num", text: fmtCost(record.cost_usd) }),
            el("td", { class: "num", text: fmtInt(record.retry_count) }),
            el("td", { class: "mono", text: record.upstream_endpoint || "—" }),
            el("td", { class: "mono", text: record.request_id }),
          ],
        ),
      ),
    );
    return el("div", { class: "table-wrap" }, [
      el("table", { class: "data" }, [el("thead", {}, [head]), body]),
    ]);
  }

  /** 详情抽屉的内容。 */
  function openDetail(record) {
    const attempts = record.attempts || [];
    const metadata = record.metadata || {};

    const body = el("div", { class: "drawer-body" }, [
      el("div", { class: "kv-grid" }, [
        kv("request_id", record.request_id),
        kv("时间", fmtTime(record.ts)),
        kv("模型", record.model),
        kv("调用方", record.caller),
        kv("适配器 / 协议", `${record.adapter} · ${record.protocol}`),
        kv("上游供应商", record.provider),
        kv("流式", record.stream ? "是" : "否"),
        kv("状态", statusLabel(record.status)),
        kv("错误码", record.error_code || "—"),
        kv("错误阶段", record.error_stage || "—"),
        kv("尝试 / 重试", `${record.attempt_count} / ${record.retry_count}`),
        kv("上游状态码", record.last_upstream_status ?? "—"),
        kv("上游响应 id", record.upstream_response_id || "—"),
        kv("上游端点", record.upstream_endpoint || "—"),
        kv("failover", fmtInt(record.failover_count)),
        kv("延迟", fmtMs(record.latency_ms)),
        kv(
          "TTFT",
          record.ttft_ms === null || record.ttft_ms === undefined
            ? "—"
            : fmtMs(record.ttft_ms),
        ),
        kv("token（入 / 出 / 推理 / 缓存读 / 缓存写）",
          `${fmtInt(record.usage.input_tokens)} / ${fmtInt(record.usage.output_tokens)} / ` +
          `${fmtInt(record.usage.reasoning_tokens)} / ${fmtInt(record.usage.cache_read_tokens)} / ` +
          `${fmtInt(record.usage.cache_write_tokens)}`),
        kv("成本", fmtCost(record.cost_usd)),
        kv("提示词模板", record.prompt_template || "—"),
        kv("模板版本", record.prompt_version ?? "—"),
      ]),

      record.error_message
        ? el("div", { class: "section" }, [
            el("h3", { class: "section-title", text: "错误信息" }),
            el("pre", { class: "pre", text: record.error_message }),
          ])
        : null,

      attempts.length
        ? el("div", { class: "section" }, [
            el("h3", { class: "section-title", text: `尝试明细（${attempts.length} 次）` }),
            el("div", { class: "table-wrap" }, [
              el("table", { class: "data" }, [
                el("thead", {}, [
                  el("tr", {}, [
                    el("th", { class: "num", text: "#" }),
                    el("th", { text: "结果" }),
                    el("th", { text: "错误码" }),
                    el("th", { class: "num", text: "上游状态" }),
                    el("th", { class: "num", text: "token" }),
                    el("th", { class: "num", text: "提示词强度" }),
                    el("th", { text: "上游端点" }),
                  ]),
                ]),
                el(
                  "tbody",
                  {},
                  attempts.map((attempt) =>
                    el("tr", {}, [
                      el("td", { class: "num", text: fmtInt(attempt.attempt) }),
                      el("td", {}, [
                        badge(attempt.ok ? "success" : "error", attempt.ok ? "成功" : "失败"),
                      ]),
                      el("td", { text: attempt.error_code || "—" }),
                      el("td", { class: "num", text: attempt.upstream_status ?? "—" }),
                      el("td", { class: "num", text: fmtInt(attempt.usage.total_tokens) }),
                      el("td", { class: "num", text: fmtInt(attempt.prompt_strength) }),
                      el("td", { class: "mono", text: attempt.upstream_endpoint || "—" }),
                    ]),
                  ),
                ),
              ]),
            ]),
          ])
        : null,

      Object.keys(metadata).length
        ? el("div", { class: "section" }, [
            el("h3", { class: "section-title", text: "metadata" }),
            el(
              "div",
              { class: "kv-grid" },
              Object.entries(metadata).map(([key, value]) => kv(key, value)),
            ),
          ])
        : null,

      record.rendered_prompt
        ? el("div", { class: "section" }, [
            el("h3", { class: "section-title", text: "渲染后的提示词" }),
            el("pre", { class: "pre", text: record.rendered_prompt }),
          ])
        : null,
    ]);

    host.openDrawer(`调用详情 · ${record.request_id}`, body);
  }

  /** 刷新并把异常交给统一的错误出口（事件回调里不能抛未处理的 rejection）。 */
  async function safeRefresh() {
    try {
      await refresh();
    } catch (error) {
      host.fail(error);
    }
  }

  /** 拉一次数据并渲染。 */
  async function refresh() {
    const params = {
      model: filters.model,
      status: filters.status,
      caller: filters.caller,
      limit: Math.min(PAGE_SIZE, MAX_LIMIT),
      offset,
    };
    const mine = host.epoch;
    const result = await latest.run((signal) => apiGet("/v1/requests", { params, signal }));
    if (result.stale) return;
    // 换密钥后旧响应一律作废（DESIGN §8.8.6 的第三层防护）。
    if (host.epoch !== mine) return;
    const data = result.data || {};
    rows = data.data || [];
    latestRequestId = rows.length ? rows[0].request_id : "";
    failureStreak = 0;
    paint();
  }

  /** 重新画整页（筛选条 + 表格 + 页脚）。 */
  function paint() {
    if (!root) return;
    clear(root);
    root.append(
      toolbar(),
      section("调用记录", "点击任意一行查看完整明细", table()),
      el("div", { class: "table-foot" }, [
        el("span", {
          text:
            `记录来自最近 1000 条的内存窗口，翻页期间数据可能移动。` +
            `当前 ${rows.length} 条，最新一条 ${latestRequestId || "—"}。`,
        }),
        el("span", { class: "spacer" }),
        el("button", {
          class: "btn btn-ghost",
          type: "button",
          text: "上一页",
          disabled: offset === 0 ? "" : null,
          onclick: async () => {
            offset = Math.max(0, offset - PAGE_SIZE);
            await safeRefresh();
          },
        }),
        el("span", { text: `偏移 ${fmtInt(offset)}` }),
        el("button", {
          class: "btn btn-ghost",
          type: "button",
          text: "下一页",
          disabled: rows.length < PAGE_SIZE ? "" : null,
          onclick: async () => {
            offset += PAGE_SIZE;
            await safeRefresh();
          },
        }),
      ]),
    );
  }

  /** 安排下一次轮询。 */
  function schedule(delay = POLL_INTERVAL) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      tick();
    }, delay);
  }

  async function tick() {
    if (!autoPoll) return;
    try {
      await refresh();
      failureStreak = 0;
    } catch (error) {
      failureStreak += 1;
      const delay = Math.min(30000, 5000 * 2 ** (failureStreak - 1));
      host.fail(error);
      schedule(delay);
      return;
    }
    schedule();
  }

  return {
    async mount(container) {
      root = container;
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
        paint();
      }
    },
    activate() {
      schedule();
    },
    deactivate() {
      if (timer) clearTimeout(timer);
      timer = null;
      latest.abort();
    },
    async reload() {
      try {
        await refresh();
      } catch (error) {
        host.fail(error);
      }
    },
  };
}
