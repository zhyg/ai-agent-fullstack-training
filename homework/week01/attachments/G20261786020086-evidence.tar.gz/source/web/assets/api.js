/**
 * 唯一的发请求入口。
 *
 * 职责：拼 URL、带上 `Authorization: Bearer`、解析网关的错误信封、把 401
 * 翻译成「需要重新输入密钥」。视图层不直接调 fetch——统一入口才能保证
 * 鉴权头不漏、错误处理一致、竞态可控（见 DESIGN §8.8.6）。
 *
 * 对应的 Java 概念：≈ 一个手写的 `RestClient` 门面（≈ Spring 的
 * `RestTemplate` + 统一 `ResponseErrorHandler`）。
 */

import { getApiKey } from "./store.js";

/**
 * API 根前缀：页面 URL 里 `/console/` 之前的部分。
 *
 * 不写死 `/v1`——网关被挂在反向代理子路径下（如 `/gw/console/`）时，
 * 前端不需要改代码。推导不出来时退回空串（同源根），行为退化但仍可用。
 */
export const API_BASE = (() => {
  const index = location.pathname.indexOf("/console/");
  return index >= 0 ? location.pathname.slice(0, index) : "";
})();

/** 请求失败（HTTP 非 2xx），带网关的错误信封内容。 */
export class ApiError extends Error {
  constructor(status, envelope, requestId) {
    super((envelope && envelope.message) || `HTTP ${status}`);
    this.name = "ApiError";
    this.status = status;
    this.code = envelope && envelope.code;
    this.type = envelope && envelope.type;
    this.retriable = envelope ? envelope.retriable : undefined;
    this.details = envelope && envelope.details;
    this.requestId = requestId;
  }
}

/** 需要（重新）输入 API Key。 */
export class UnauthorizedError extends Error {
  constructor(message) {
    super(message || "missing or invalid api key");
    this.name = "UnauthorizedError";
  }
}

/**
 * 发一个 GET 请求。
 *
 * @param {string} path 以 `/` 开头的路径，如 `/v1/metrics`
 * @param {Object} [options]
 * @param {Object} [options.params] 查询参数
 * @param {AbortSignal} [options.signal] 取消信号
 * @returns {Promise<any>} 解析后的 JSON
 */
export async function apiGet(path, options = {}) {
  const url = new URL(API_BASE + path, location.origin);
  for (const [key, value] of Object.entries(options.params || {})) {
    if (value === null || value === undefined || value === "") continue;
    url.searchParams.set(key, String(value));
  }

  const headers = { Accept: "application/json" };
  const key = getApiKey();
  // 没开鉴权时（auth.enabled = false）不带这个头也能取到数据（见 §8.8.5）。
  if (key) headers.Authorization = `Bearer ${key}`;

  const response = await fetch(url, { headers, signal: options.signal });

  if (response.status === 401) {
    throw new UnauthorizedError();
  }

  const body = await response.json().catch(() => null);
  if (!response.ok) {
    throw new ApiError(
      response.status,
      body && body.error,
      response.headers.get("x-request-id"),
    );
  }
  return body;
}

/**
 * 发一个 POST 请求（试调用页签用，见 DESIGN §8.9）。
 *
 * 与 `apiGet` 的刻意差别：**不**把响应解析成 JSON 就返回——试调用要看到
 * 原始状态码、`X-Request-Id` 响应头，以及流式响应的逐帧内容。解析留给调用方。
 *
 * @param {string} path 以 `/` 开头的路径，如 `/v1/chat/completions`
 * @param {Object} body 请求体（会被 JSON 序列化）
 * @param {Object} [options]
 * @param {AbortSignal} [options.signal] 取消信号
 * @returns {Promise<Response>} 原始响应
 */
export async function apiPost(path, body, options = {}) {
  const url = new URL(API_BASE + path, location.origin);
  const headers = { Accept: "application/json", "Content-Type": "application/json" };
  const key = getApiKey();
  if (key) headers.Authorization = `Bearer ${key}`;

  return fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
    signal: options.signal,
  });
}

/**
 * 「只认最后一次」的请求协调器。
 *
 * 三层竞态防护里的前两层（见 DESIGN §8.8.6）：
 * 1. 取消上一个在途请求（AbortController）；
 * 2. 请求序号比对——只有最后一次发起的请求的结果算数。
 *
 * 第三层（换密钥时的 epoch）由 app.js 统一管理。
 */
export function createLatest() {
  let seq = 0;
  let controller = null;

  return {
    /**
     * 跑一次请求。
     * @returns {Promise<{stale: boolean, data?: any}>} stale 为 true 表示结果已过期，调用方必须丢弃
     */
    async run(fn) {
      const mine = ++seq;
      if (controller) controller.abort();
      controller = new AbortController();
      try {
        const data = await fn(controller.signal);
        return mine === seq ? { stale: false, data } : { stale: true };
      } catch (error) {
        if (error && error.name === "AbortError") return { stale: true };
        throw error;
      }
    },
    /** 取消在途请求（切页签、页面隐藏时用）。 */
    abort() {
      if (controller) controller.abort();
      controller = null;
      seq += 1;
    },
  };
}
