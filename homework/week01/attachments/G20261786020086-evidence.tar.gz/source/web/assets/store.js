/**
 * 浏览器本地存储：只存 API Key。
 *
 * 为什么只存这一个：工作台没有自己的账号体系（见 DESIGN §8.8.1），复用网关现有的
 * api key；其余状态（当前页签、筛选条件）都不值得持久化。
 *
 * 安全约束（见 DESIGN §8.8.4）：Key 只落在 localStorage——**不进 DOM 属性、
 * 不进 URL、不进日志、不回显**。localStorage 而非 cookie 是有意的：cookie 会带上
 * CSRF 面，而这里不需要浏览器自动带凭证。
 *
 * 对应的 Java 概念：≈ 一个进程内的 `Preferences` 门面（≈ Java 的
 * `java.util.prefs.Preferences`），区别是这里随浏览器走、不随进程走。
 */

const KEY_API = "lgw.console.apiKey";

/** 读取已保存的 API Key；没有则返回空串。 */
export function getApiKey() {
  try {
    return localStorage.getItem(KEY_API) || "";
  } catch {
    // 隐私模式下 localStorage 可能直接抛错——工作台不该因此整个挂掉。
    return "";
  }
}

/** 保存 API Key；传空串等于清除。 */
export function setApiKey(value) {
  try {
    const key = (value || "").trim();
    if (key) {
      localStorage.setItem(KEY_API, key);
    } else {
      localStorage.removeItem(KEY_API);
    }
  } catch {
    // 存不进去就当没存：功能降级为「每次重新输入」，但不影响其它功能。
  }
}

/** 密钥的掩码显示（只露末 4 位）。 */
export function maskKey(value) {
  const key = value || "";
  if (!key) return "";
  if (key.length <= 4) return "•".repeat(key.length);
  return `${"•".repeat(Math.min(8, key.length - 4))}${key.slice(-4)}`;
}
