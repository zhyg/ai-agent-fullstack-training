/**
 * 唯一的建 DOM 入口。
 *
 * 硬约束（见 DESIGN §8.8.4）：本项目的前端**禁止**任何「把字符串当 HTML 解析」的
 * DOM API（清单见该节）。所有后端返回的文本一律通过 textContent 写入。
 * 原因很直接：API Key 存在 localStorage 里，一次 XSS 就等于站点级密钥泄漏。
 *
 * 对应的 Java 概念：≈ 一个「只允许安全构造」的 DTO → DOM 转换器。
 * 相当于把 SQL 注入的防线（预编译占位符）搬到 DOM 构造上：
 * 参数只能是数据，不能变成语法。
 */

/**
 * 创建一个元素。
 *
 * @param {string} tag 标签名
 * @param {Object} [attrs] 属性；`text` 是文本内容，`on*` 是事件监听器
 * @param {Array|Node|string} [children] 子节点
 * @returns {HTMLElement}
 */
export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === "class") {
      node.className = String(value);
    } else if (key === "text") {
      node.textContent = String(value);
    } else if (key.startsWith("on") && typeof value === "function") {
      node.addEventListener(key.slice(2).toLowerCase(), value);
    } else {
      node.setAttribute(key, String(value));
    }
  }
  appendAll(node, children);
  return node;
}

/** 把若干个子节点挂到父节点上（字符串按纯文本处理）。 */
export function appendAll(parent, children) {
  const list = Array.isArray(children) ? children : [children];
  for (const child of list) {
    if (child === null || child === undefined || child === false) continue;
    if (child instanceof Node) {
      parent.append(child);
    } else {
      parent.append(text(child));
    }
  }
  return parent;
}

/** 纯文本节点。 */
export function text(value) {
  return document.createTextNode(value === null || value === undefined ? "" : String(value));
}

/** 清空容器。用 replaceChildren 而不是清空字符串写法——后者属于「按 HTML 解析」。 */
export function clear(node) {
  node.replaceChildren();
  return node;
}

/** 「标签：值」一行。 */
export function kv(label, value) {
  return el("div", { class: "kv" }, [
    el("span", { class: "kv-k", text: label }),
    el("span", { class: "kv-v", text: value === null || value === undefined ? "—" : String(value) }),
  ]);
}

/** 状态徽章。kind ∈ success / error / cancelled / info / muted / accent。 */
export function badge(kind, label) {
  return el("span", { class: `badge badge-${kind}`, text: label });
}

/** 一个区块（标题 + 说明 + 内容）。 */
export function section(title, note, children) {
  return el("section", { class: "section" }, [
    el("div", { class: "section-head" }, [
      el("h2", { class: "section-title", text: title }),
      note ? el("span", { class: "section-note", text: note }) : null,
    ]),
    ...(Array.isArray(children) ? children : [children]),
  ]);
}

/** 空状态占位。 */
export function empty(message) {
  return el("div", { class: "empty", text: message });
}
