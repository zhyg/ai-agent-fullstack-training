/**
 * ECharts 封装：Latte 配色、统一的坐标轴 / 提示条样式、以及降级处理。
 *
 * 降级（见 DESIGN §8.8.3）：CDN 不可达时 `globalThis.echarts` 不存在，
 * 图表位渲染成一句提示，**数据由旁边的表格承载**——表格本来就是主载体，
 * 图表只是增强。
 *
 * 安全（见 DESIGN §8.8.4）：tooltip 必须用 `renderMode: "richText"`——
 * ECharts 默认的提示条是 HTML 模板，会把 `formatter` 返回的字符串当 HTML 解析，
 * 是最容易漏掉的注入入口。所有 formatter 只返回纯文本。
 *
 * 对应的 Java 概念：≈ 一个「图表配置工厂」，把主题常量收在一处，
 * 业务代码只描述数据与坐标轴，不关心配色。
 */

/** 分类色序（与 styles.css 的令牌同源）。 */
export const PALETTE = [
  "#1e66f5", "#cba6f7", "#299685", "#df8e1d",
  "#04a5e5", "#d20f39", "#7287fd", "#e64553",
  "#fe640b", "#40a02b", "#f5c2e7", "#209fb5",
];

const AXIS_LINE = "#ccd0da";
const SPLIT_LINE = "#e6e9ef";
const TEXT_DIM = "#6c6f85";
const TEXT = "#4c4f69";
const BORDER = "#dce0e8";
const SURFACE = "#ffffff";

const available = () =>
  !!globalThis.echarts && !globalThis.__LGW_ECHARTS_UNAVAILABLE__;

/** 图表库是否可用（供界面提示用）。 */
export function chartsAvailable() {
  return available();
}

/** 所有图表实例的登记处：切页签时统一 dispose，避免实例泄漏。 */
const instances = new Set();

/**
 * 在容器里画一张图。
 *
 * @param {HTMLElement} node 容器
 * @param {Object} option ECharts 配置
 * @returns {Object|null} 图表实例；图表库不可用时返回 null
 */
export function mountChart(node, option) {
  if (!available()) {
    node.replaceChildren();
    const hint = document.createElement("p");
    hint.className = "chart-fallback";
    hint.textContent = "图表库未加载（CDN 不可达），请查看下方数据表。";
    node.append(hint);
    return null;
  }
  const instance = globalThis.echarts.init(node, null, { renderer: "canvas" });
  instance.setOption(withTheme(option));
  instances.add(instance);
  return instance;
}

/** 容器被移除前调用：销毁实例。 */
export function disposeChart(instance) {
  if (!instance) return;
  instances.delete(instance);
  instance.dispose();
}

/** 销毁某个容器下的全部实例（按 DOM 归属）。 */
export function disposeChartsIn(root) {
  for (const instance of Array.from(instances)) {
    if (root.contains(instance.getDom())) {
      disposeChart(instance);
    }
  }
}

/** 窗口尺寸变化时重画。 */
export function resizeCharts() {
  for (const instance of instances) {
    if (!instance.isDisposed()) instance.resize();
  }
}

/**
 * 合并主题默认值。
 * 调用方给的配置优先，但 tooltip 的 richText 模式与坐标轴样式是硬要求，
 * 因此这里做的是「补默认值」而不是「整体替换」。
 */
function withTheme(option) {
  const base = {
    color: PALETTE,
    textStyle: { color: TEXT, fontFamily: "inherit" },
    tooltip: {
      trigger: "axis",
      renderMode: "richText",
      backgroundColor: SURFACE,
      borderColor: BORDER,
      borderWidth: 1,
      textStyle: { color: TEXT, fontSize: 12 },
      axisPointer: { type: "shadow", shadowStyle: { color: "rgba(76,79,105,0.06)" } },
    },
    legend: { textStyle: { color: TEXT_DIM, fontSize: 12 } },
    grid: { left: 12, right: 16, top: 32, bottom: 8, containLabel: true },
  };
  return merge(base, option);
}

/** 浅合并（数组整体替换，不做逐项合并——图表配置不适合深合并）。 */
function merge(base, override) {
  const result = { ...base };
  for (const [key, value] of Object.entries(override || {})) {
    result[key] =
      value && typeof value === "object" && !Array.isArray(value)
        ? { ...(base[key] || {}), ...value }
        : value;
  }
  return result;
}

/** 分类轴（模型名、调用方名）的统一样式。 */
export function categoryAxis(data) {
  return {
    type: "category",
    data,
    axisLine: { lineStyle: { color: AXIS_LINE } },
    axisTick: { show: false },
    axisLabel: { color: TEXT_DIM, fontSize: 12 },
  };
}

/** 数值轴的统一样式。 */
export function valueAxis(name) {
  return {
    type: "value",
    name,
    nameTextStyle: { color: TEXT_DIM, fontSize: 12 },
    axisLine: { show: false },
    axisTick: { show: false },
    axisLabel: { color: TEXT_DIM, fontSize: 12 },
    splitLine: { lineStyle: { color: SPLIT_LINE } },
  };
}
