import pytest

@pytest.fixture(autouse=True)
def injected_bad_upstream(request):
    # One controlled upstream 400, not an edit to student business code or tests.
    if request.node.name == 'test_request_id_header_on_responses':
        ctx = request.getfixturevalue('ctx')
        ctx.resp.enqueue({'type': 'error', 'status': 400, 'message': 'teacher injected failure'})
        ctx.anth.enqueue({'type': 'error', 'status': 400, 'message': 'teacher injected failure'})
