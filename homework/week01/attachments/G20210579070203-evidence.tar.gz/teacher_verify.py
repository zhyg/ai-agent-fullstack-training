import json
import time
from pathlib import Path
import httpx

out = Path('/tmp/gateway-grade/evidence')
c = httpx.Client(base_url='http://127.0.0.1:18121', headers={'Authorization': 'Bearer test-gateway-key'}, timeout=10)
results = []
def save(case, status, detail):
    results.append({'case': case, 'status': status, 'detail': detail})
    print(case, status, json.dumps(detail, ensure_ascii=False))
def control(**data):
    r = c.post('/teacher/control', json=data)
    r.raise_for_status()
def caps():
    return c.get('/teacher/captures').json()
def chat(model='pro', **data):
    return c.post('/v1/chat/completions', json={'model': model, 'messages': [{'role': 'user', 'content': 'hi'}], **data})
def row(r):
    rid = r.headers['x-request-id']
    return next((x for x in c.get('/admin/usage?limit=500').json()['records'] if x['request_id'] == rid), None)

control(reset=True)
for alias, name in [('pro', 'resp'), ('flash', 'anth')]:
    r = chat(alias, messages=[{'role': 'system', 'content': 'SYS'}, {'role': 'user', 'content': 'USER'}])
    cap = caps()[-1]
    assert r.status_code == 200 and r.json()['choices'][0]['message']['content'] == 'hi-' + ('openai_responses' if name == 'resp' else 'anthropic_messages')
    assert (cap['url'].endswith('/responses') and cap['body']['instructions'] == 'SYS' and cap['body']['input'][0]['content'][0]['type'] == 'input_text') if name == 'resp' else (cap['url'].endswith('/messages') and cap['body']['system'] == 'SYS' and cap['body']['messages'][0]['content'][0]['type'] == 'text')
    save('A03-'+alias, 'PASS', {'capture': cap, 'response': r.json(), 'ledger': row(r)})
r = chat('missing')
assert r.status_code == 404
save('A04', 'PASS', {'response': r.json(), 'ledger': row(r)})

for alias, name in [('pro', 'resp'), ('flash', 'anth')]:
    for abort in [False, True]:
        control(reset=True, scripts={name: [{'type': 'gate', 'abort': abort}]})
        body = {'model': alias, 'messages': [{'role': 'user', 'content': 'gate'}], 'stream': True}
        t = time.monotonic()
        with c.stream('POST', '/v1/chat/completions', json=body) as r:
            assert r.status_code == 200 and r.headers['content-type'].startswith('text/event-stream')
            lines = r.iter_lines()
            first = next(line for line in lines if line.startswith('data:'))
            assert json.loads(first[5:])['choices'][0]['delta']['content'] == 'first'
            first_ms = (time.monotonic()-t)*1000
            # The upstream cannot send a terminal event until this separate HTTP request.
            control(release=[name])
            rest = '\n'.join(lines)
        record = row(r)
        capture = caps()
        assert len(capture) == 1 and '[DONE]' in rest
        assert ('"error"' in rest) == abort
        assert record['status'] == ('failed' if abort else 'success')
        assert record['ttft_ms'] >= 140
        save(('F02-' if abort else 'F01-')+alias, 'PASS', {'first_before_release': first, 'first_ms': first_ms, 'rest': rest, 'calls': len(capture), 'ledger': record})
        if not abort:
            ok = record['input_tokens'] == 17 and record['output_tokens'] == 5 and record['cache_tokens'] == 3
            save('F07-token-'+alias, 'PASS' if ok else 'FAIL', {'expected': {'input': 17, 'output': 5, 'cache': 3}, 'ledger': record, 'reasoning_tokens_supplied': 2 if name == 'resp' else None})

for alias, name in [('pro', 'resp'), ('flash', 'anth')]:
    control(reset=True, scripts={name: [{'type': 'text', 'text': '{"x":3}'}]})
    r = chat(alias, response_format={'type': 'json_object'})
    assert r.status_code == 200 and json.loads(r.json()['choices'][0]['message']['content']) == {'x': 3}
    save('F03-'+alias, 'PASS', {'capture': caps(), 'response': r.json()})
    for kind, text in [('invalid', 'not-json'), ('empty', ''), ('truncated', '{"x":')]:
        control(reset=True, scripts={name: [{'type': 'text', 'text': text, 'finish': 'length'}]*2})
        r = chat(alias, response_format={'type': 'json_object'})
        assert r.status_code == 422 and len(caps()) == 2
        save('F04-'+alias+'-'+kind, 'PASS', {'response': r.json(), 'calls': len(caps()), 'ledger': row(r)})

pid = 'teacher-'+str(time.time_ns())
for template in ['v1 {{name}}', 'v2 {{name}}']:
    assert c.post('/v1/prompts', json={'prompt_id': pid, 'template': template}).status_code == 200
for version in [1, 2, 1]:
    control(reset=True)
    r = chat(prompt_ref={'id': pid, 'version': version, 'variables': {'name': 'Ada'}})
    assert r.status_code == 200 and caps()[0]['body']['instructions'] == f'v{version} Ada'
    save('F05-v'+str(version), 'PASS', {'capture': caps(), 'ledger': row(r)})
for ref in [{'id': 'absent'}, {'id': pid, 'version': 99}, {'id': pid}]:
    control(reset=True)
    r = chat(prompt_ref=ref)
    assert r.status_code in [404, 422] and not caps()
    save('F06', 'PASS', {'ref': ref, 'status': r.status_code, 'response': r.json(), 'ledger': row(r)})

for label, script, expected, count in [('recover', [{'type': 'error', 'status': 500}]*2+[{'type': 'text', 'text': 'ok'}], 200, 3), ('persistent', [{'type': 'error', 'status': 500}]*4, 502, 3), ('bad-input', [{'type': 'error', 'status': 400}]*4, 400, 1)]:
    control(reset=True, scripts={'resp': script})
    r = chat()
    captured = caps()
    delays = [captured[i]['time']-captured[i-1]['time'] for i in range(1, len(captured))]
    assert r.status_code == expected and len(captured) == count
    if count == 3:
        assert .075 <= delays[0] <= .14 and .155 <= delays[1] <= .22
    save('F08' if label == 'recover' else 'F09-'+label, 'PASS', {'calls': count, 'interval_seconds': delays, 'response': r.json(), 'ledger': row(r)})

control(reset=True, rate={'requests_per_minute': 60, 'burst': 1})
passed = chat()
limited = chat()
other = chat('flash')
assert [passed.status_code, limited.status_code, other.status_code] == [200, 429, 200]
save('F10', 'PASS', {'statuses': [200,429,200], 'limited': limited.json(), 'limited_ledger': row(limited), 'captures': caps()})
time.sleep(1.1)
r = chat()
assert r.status_code == 200
save('F11', 'PASS', {'status': r.status_code, 'wait_seconds': 1.1})
out.joinpath('teacher-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
out.joinpath('teacher-ledger.json').write_text(json.dumps(c.get('/admin/usage?limit=500').json(), ensure_ascii=False, indent=2))
print('TEACHER COMPLETED', len(results))
