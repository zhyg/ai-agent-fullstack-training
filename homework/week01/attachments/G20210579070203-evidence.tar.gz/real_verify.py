import gzip
import json
import time
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from gateway.main import create_app
from gateway.config import load_config

out = Path('/tmp/gateway-grade/evidence')
app = create_app(load_config('/tmp/gateway-grade/real.yaml'))
wire = []
class CaptureStream(httpx.AsyncByteStream):
    def __init__(self, stream, entry):
        self.stream, self.entry, self.parts = stream, entry, []
    async def __aiter__(self):
        async for part in self.stream:
            self.parts.append(part)
            yield part
        raw = b''.join(self.parts)
        if raw.startswith(b'\x1f\x8b'):
            raw = gzip.decompress(raw)
        self.entry['raw_response'] = raw.decode('utf-8')
    async def aclose(self):
        await self.stream.aclose()

async def request_hook(request):
    wire.append({'url': str(request.url), 'body': json.loads(request.content), 'start': time.monotonic()})
async def response_hook(response):
    entry = wire[-1]
    entry.update({'http_status': response.status_code, 'headers_latency_ms': (time.monotonic()-entry['start'])*1000,
                  'upstream_request_id': response.headers.get('x-request-id') or response.headers.get('request-id')})
    response.stream = CaptureStream(response.stream, entry)
for client in app.state.gateway.pipeline.clients.values():
    client.event_hooks = {'request': [request_hook], 'response': [response_hook]}

results = []
with TestClient(app, raise_server_exceptions=False) as c:
    c.headers['Authorization'] = 'Bearer teacher-local-key'
    for alias in ['deepseek-pro', 'deepseek-flash']:
        for mode in ['schema', 'stream']:
            body = {'model': alias, 'messages': [{'role': 'user', 'content': 'Return only {"ok":true} as JSON. Do not reason.'}], 'max_tokens': 128}
            if mode == 'schema':
                body['response_format'] = {'type': 'json_schema', 'json_schema': {'name': 'answer', 'schema': {'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok'], 'additionalProperties': False}}}
            if mode == 'stream':
                body['stream'] = True
            start = time.monotonic()
            r = c.post('/v1/chat/completions', json=body)
            ledger = c.get('/admin/usage?limit=30').json()['records']
            rid = r.headers.get('x-request-id')
            entry = {'alias': alias, 'mode': mode, 'status': r.status_code, 'gateway_request_id': rid,
                     'wall_ms': (time.monotonic()-start)*1000, 'response': r.text,
                     'ledger': next((x for x in ledger if x['request_id'] == rid), None)}
            results.append(entry)
            print(json.dumps(entry, ensure_ascii=False), flush=True)
            out.joinpath('real-detail-results.json').write_text(json.dumps({'results': results, 'wire': wire}, ensure_ascii=False, indent=2))
            assert r.status_code == 200, r.text
            if mode == 'schema':
                assert json.loads(r.json()['choices'][0]['message']['content']) == {'ok': True}
            if r.status_code != 200:
                break
