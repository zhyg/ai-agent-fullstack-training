import json
from pathlib import Path
import httpx

c = httpx.Client(base_url='http://127.0.0.1:18121', headers={'Authorization': 'Bearer test-gateway-key'})
results = []
schema = {'type': 'object', 'properties': {'x': {'type': 'integer'}}, 'required': ['x'], 'additionalProperties': False}
for alias, name in [('pro','resp'), ('flash','anth')]:
    for label, final in [('repair-success','{"x":4}'), ('repair-failed','{"x":"bad"}')]:
        scripts = [{'type': 'text', 'text': '{"x":"bad"}', 'usage': {'input_tokens': 13, 'output_tokens': 7}}, {'type': 'text', 'text': final, 'usage': {'input_tokens': 5, 'output_tokens': 3}}]
        c.post('/teacher/control', json={'reset': True, 'rate': {'requests_per_minute': 100000, 'burst': 10000}, 'scripts': {name: scripts}}).raise_for_status()
        r = c.post('/v1/chat/completions', json={'model': alias, 'messages': [{'role':'user','content':'return x integer'}], 'response_format': {'type': 'json_schema', 'json_schema': {'name': 'answer', 'schema': schema}}})
        rid = r.headers['x-request-id']
        record = next(x for x in c.get('/admin/usage?limit=500').json()['records'] if x['request_id'] == rid)
        captures = c.get('/teacher/captures').json()
        assert r.status_code == (200 if label == 'repair-success' else 422)
        assert len(captures) == 2
        if label == 'repair-success':
            assert json.loads(r.json()['choices'][0]['message']['content']) == {'x':4}
        entry = {'case': label+'-'+alias, 'expected_known_usage': {'input_tokens':18,'output_tokens':10}, 'ledger': record, 'response': r.json(), 'captures': captures}
        print(json.dumps(entry, ensure_ascii=False))
        results.append(entry)
Path('/tmp/gateway-grade/evidence/extra-results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False))
