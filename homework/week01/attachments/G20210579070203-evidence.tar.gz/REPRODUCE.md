# G20210579070203 教师评测复现

对象：https://github.com/canyuda/agentStudyCodeProject，main，14084eee06f46584027f4d22c860704d98dfe4bd。
2026-11-08 Asia/Singapore；学生源码没有修改。Python 3.11.6。
复现前将证据包解包到 `/tmp/gateway-grade`，脚本与 real.yaml 位于该目录根；安装命令后保持工作目录为学生作业目录。证据中的数据库无需也不会随包提供，运行时重新生成。

## 安装与学生脚本

```bash
git clone --branch main --single-branch https://github.com/canyuda/agentStudyCodeProject /tmp/G20210579070203
git -C /tmp/G20210579070203 checkout 14084eee06f46584027f4d22c860704d98dfe4bd
cd /tmp/G20210579070203/homework/my-llm-gateway
uv venv .venv
uv pip install -p .venv/bin/python -e '.[dev]'
bash scripts/verify_mock.sh
PYTHONPATH=/tmp/gateway-grade PYTEST_ADDOPTS='-p teacher_failure' bash scripts/verify_mock.sh
GATEWAY_API_KEY=teacher-local-key .venv/bin/python scripts/verify_real.py --dry-run
```

正常 mock 脚本退出 0，79 passed；故障注入退出 1，1 failed / 78 passed。插件只替换一个测试中的上游返回为 400，不修改学生逻辑或断言。dry-run 不算真实调用。

## 默认启动与教师 socket 验证

README 的启动命令仅调整监听端口至 18120，用 supervised service 执行；/healthz 实际 HTTP 200。
教师脚本使用学生公开 create_app 的 transport 注入点；HTTP 客户端经真实 uvicorn socket 消费 SSE。

```bash
amp orb service start grade-gateway-default --command '/tmp/G20210579070203/homework/my-llm-gateway/.venv/bin/python -m uvicorn gateway.main:app --host 127.0.0.1 --port 18120' --port 18120
amp orb service start grade-gateway-teacher --command 'env PYTHONPATH=/tmp/gateway-grade:/tmp/G20210579070203/homework/my-llm-gateway /tmp/G20210579070203/homework/my-llm-gateway/.venv/bin/python -m uvicorn teacher_app:app --host 127.0.0.1 --port 18121' --port 18121
.venv/bin/python /tmp/gateway-grade/teacher_verify.py
.venv/bin/python /tmp/gateway-grade/extra_verify.py
```

teacher_verify.py 28 条结果包含一条 FAIL（Anthropic 起始用量丢失），退出 0 表示脚本完整运行，不代表全部用例通过；以 JSON 中 status 为准。Responses 的 F07-token-pro PASS 仅验证输入/输出/缓存，推理分类缺失由真实原始报文另行证明。extra_verify.py 的断言验证结构修复结果；账本少记用量是所记录的缺陷，不以脚本退出 0 宣称记账正确。

独立配置：pro 单一路由 Responses；flash 单一路由 Anthropic；重试 3 次总尝试，jitter=0，base=.08s；限流在用例中调整至 60/min、burst=1；不改变实现。门控上游先发正文 first，必须收到独立 release 请求后才会发终态或断流。

## 官方真实调用

只在内存读取已有 DEEPSEEK_API_KEY；归档仅保留变量引用，不提供密钥文件。只访问 api.deepseek.com。real.yaml 的 flash 根据当日 /models 换成 deepseek-flash（DeepSeek-V4.1-Flash），pro 保持 deepseek-v4-pro；协议不变。独立数据库，超时 25 秒、最多两次尝试，不测真实上游限流。

```bash
.venv/bin/python /tmp/gateway-grade/real_verify.py
```

evidence/real-results.json 是首轮普通、流式、json_object 调用；evidence/real-detail-results.json 是最终 Schema/流式复核，含透明采集并解压 gzip 后的上游正文。脚本为最终复核版本；首轮与最终配置一致，首轮 mode 为 normal/stream/json。中间一次采集只保留压缩正文、不能辨读，已用最终解压采集替换，不作为证据。网关头的 X-Request-Id 与上游正文 id 不同，报告分别记录；上游响应头未提供 request-id 时不编造。

Responses json_object 在本实现中映射为无 properties 的严格 Schema，官方返回统一 400；完整 json_schema 在双协议实际成功。这按上游能力限制记录，不额外扣分。学生真实脚本仅执行 dry-run，未将其结果冒充真实验收；真实验收由教师脚本完成，避免原配置中未在本次列表出现的模型别名及外部故障域名带来的干扰。

## 归档与清理

source-lines/ 为固定提交关键源码带行号副本；配置中仅本地测试凭据和环境变量引用。原始数据库、学生 .env、venv、视频和仓库其他内容不入包。secret-scan.json 记录对最终反馈、附件和解包内容的实际环境密钥逐字节及常见密钥模式扫描。
服务结束后用 amp orb service stop 停止两项服务，保留停止结果与源码 git diff 检查。
