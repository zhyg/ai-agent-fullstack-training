import asyncio
import json
import time
from pathlib import Path

import httpx
from fastapi import Request
from gateway.config import AliasCfg, RouteCfg, RetryCfg, RateLimitCfg, BreakerCfg
from gateway.main import create_app
from tests.conftest import make_config
from tests.upstreams.fake import FakeUpstream, _sse

root = Path('/tmp/gateway-grade')
cfg = make_config(root)
cfg.aliases['pro'] = AliasCfg(routes=[RouteCfg(provider='resp', model='real-pro')])
cfg.retry = RetryCfg(max_attempts=3, base_delay_seconds=.08, max_delay_seconds=1, jitter=0)
cfg.circuit_breaker = BreakerCfg(failure_threshold=1000)
fakes = {'resp': FakeUpstream('openai_responses'), 'anth': FakeUpstream('anthropic_messages')}
gates = {}
captures = []

class WireStream(httpx.AsyncByteStream):
    def __init__(self, name, behavior):
        self.name, self.behavior = name, behavior

    async def __aiter__(self):
        if self.name == 'anth':
            yield _sse('message_start', {'message': {'usage': {'input_tokens': 17, 'output_tokens': 0, 'cache_read_input_tokens': 3}}}).encode()
            yield _sse('ping', {}).encode()
        else:
            yield _sse('response.created', {'response': {}}).encode()
        await asyncio.sleep(.15)
        event = 'response.output_text.delta' if self.name == 'resp' else 'content_block_delta'
        data = {'delta': 'first'} if self.name == 'resp' else {'delta': {'type': 'text_delta', 'text': 'first'}}
        yield _sse(event, data).encode()
        await gates[self.name].wait()
        if self.behavior.get('abort'):
            return
        if self.name == 'resp':
            yield _sse('response.completed', {'response': {'status': 'completed', 'usage': {'input_tokens': 17, 'output_tokens': 5, 'input_tokens_details': {'cached_tokens': 3}, 'output_tokens_details': {'reasoning_tokens': 2}}}}).encode()
        else:
            yield _sse('message_delta', {'delta': {'stop_reason': 'end_turn'}, 'usage': {'output_tokens': 5}}).encode()
            yield _sse('message_stop', {}).encode()

def transport(name):
    async def handle(request):
        fake = fakes[name]
        captures.append({'provider': name, 'time': time.monotonic(), 'url': str(request.url), 'body': json.loads(request.content), 'auth_kind': 'bearer' if 'authorization' in request.headers else 'x-api-key'})
        if fake.script and fake.script[0].get('type') == 'gate':
            behavior = fake.script.pop(0)
            gates[name] = asyncio.Event()
            return httpx.Response(200, headers={'content-type': 'text/event-stream'}, stream=WireStream(name, behavior))
        return fake._handle(request)
    return httpx.MockTransport(handle)

app = create_app(cfg, transports={name: transport(name) for name in fakes})

@app.post('/teacher/control')
async def control(request: Request):
    data = await request.json()
    if data.get('reset'):
        captures.clear()
        for fake in fakes.values():
            fake.clear()
        app.state.gateway.rate_limiter._buckets.clear()
    for name, script in data.get('scripts', {}).items():
        fakes[name].script = script
    for name in data.get('release', []):
        gates[name].set()
    if 'rate' in data:
        from gateway.resilience.ratelimit import TokenBucketRateLimiter
        app.state.gateway.rate_limiter = TokenBucketRateLimiter(RateLimitCfg(**data['rate']))
    return {'ok': True}

@app.get('/teacher/captures')
async def capture():
    return captures
