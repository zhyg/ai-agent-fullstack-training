import io
import json
import os
from pathlib import Path
import re
import tarfile

repo = Path('/home/user/workspace/repo')
feedback = repo/'homework/week01/G20210579070203.md'
attachment = repo/'homework/week01/attachments/G20210579070203.md'
bundle = Path('/tmp/gateway-grade/bundle')
archive = attachment.with_name('G20210579070203-evidence.tar.gz')
text = feedback.read_text()
sections = re.split(r'\*\*[234]\. [^\n]+\*\*', text)[1:]
checks = []
for section in sections:
    items = [line for line in section.splitlines() if line.startswith('- ')]
    count = len(items)
    chars = sum(len(line[2:]) for line in items)
    assert 3 <= count <= 5 and chars <= 500
    checks.append({'list_items': count, 'characters': chars})
scores = [int(x) for x in re.findall(r'^\| (?:统一接口与适配器|流式输出|结构化输出|提示词版本管理|可观测性|统一错误与重试|按模型独立限流|源码、README 与验证脚本) \| (\d+)/\d+ \|', attachment.read_text(), re.M)]
assert len(scores) == 8 and sum(scores) == 96
assert '优秀（96分）' in text
(bundle/'evidence/format-check.json').write_text(json.dumps({'sections': checks, 'scores': scores, 'sum': sum(scores), 'status': 'PASS'}, ensure_ascii=False, indent=2))

secrets = [v.encode() for k,v in os.environ.items() if (k.endswith('_API_KEY') or k.endswith('_TOKEN') or k.endswith('_SECRET')) and len(v) >= 8]
assert os.environ.get('DEEPSEEK_API_KEY'), 'Required actual key is absent from scanning environment'
pattern = re.compile(rb'(?:sk-[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
def check_bytes(name, data):
    if any(secret in data for secret in secrets) or pattern.search(data):
        raise RuntimeError('Sensitive material detected in '+name)

files = [p for p in bundle.rglob('*') if p.is_file()] + [feedback, attachment]
for path in files:
    check_bytes(str(path.relative_to(bundle)) if path.is_relative_to(bundle) else path.name, path.read_bytes())
report = {'status': 'PASS', 'actual_environment_secret_values_checked': len(secrets), 'includes_actual_DEEPSEEK_API_KEY': True, 'files_checked_before_pack': len(files), 'findings': 0, 'method': 'Exact byte matching against actual API keys/tokens/secrets plus common API-key/private-key patterns; no values logged'}
(bundle/'evidence/secret-scan.json').write_text(json.dumps(report, indent=2))
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(bundle.rglob('*')):
        if path.is_file():
            tar.add(path, arcname=str(path.relative_to(bundle)))
count = 0
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar.getmembers():
        if member.isfile():
            check_bytes(member.name, tar.extractfile(member).read())
            count += 1
print(json.dumps({'format': 'PASS', 'sum': sum(scores), 'secret_scan': 'PASS', 'archive_members_scanned': count, 'archive_bytes': archive.stat().st_size}, ensure_ascii=False))
