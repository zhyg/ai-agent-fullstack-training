# 第一周作业评测附件

- 学员：灿若繁星先生 G20210579070203。
- 仓库：https://github.com/canyuda/agentStudyCodeProject；目录：`homework/my-llm-gateway`。
- 分支与固定提交：main，`14084eee06f46584027f4d22c860704d98dfe4bd`；学生源码全程未修改。
- 评测日期：2026-11-08，Asia/Singapore（日志 UTC 为 2026-11-07）。本独立 orb 亲自执行，无再委派。
- 总分：96/100；作业等级：优秀；验收结论：通过，需修复。
- 依据：第一周作业原文、评分标准 v1.1、学员反馈报告模板 v1.0；不以通过率折算分数。
- 证据包：`G20210579070203-evidence.tar.gz`。下文证据路径均相对解包根目录；源码路径均相对固定提交作业的 `src/gateway/`。

## 八项评分

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 统一入口 3、model 路由 4、双协议 4、统一结果 4；真实路径和报文验证，未知模型 404。 |
| 流式输出 | 15/15 | 双模型 SSE 5、门控真实增量 5、终止错误 3、输出后不重试 2。 |
| 结构化输出 | 10/10 | 双协议完整 Schema 实际成功 4；本地 JSON 校验 3；非法、空、截断及 Schema 类型错误修复失败拒绝 3。 |
| 提示词版本管理 | 10/10 | 存储 3、变量替换 3、版本保留 2、缺失处理 2；检查实际上游模板文本。 |
| 可观测性 | 11/15 | Token 分类及统计 2/5（D1 −2、D2 −1）；总延迟与正文 TTFT 4/4；请求关联查询 3/3；失败记录 2/3（D3 −1）。 |
| 统一错误与重试 | 15/15 | 错误映射 4、指数退避 4、次数上限 3、不可重试错误 3、过程证据 1；直接 httpx，无 SDK 额外重试层。 |
| 按模型独立限流 | 10/10 | 独立计数 4、HTTP 429 3、补充恢复 2、可配置 1。429 漏账只在可观测性扣分。 |
| 源码、README 与验证脚本 | 10/10 | 源码依赖 2、README 启动 3、curl 入口 2、六功能有效断言脚本 3；79 passed，注入故障后明确失败。 |
| **合计** | **96/100** | 15+15+10+10+11+15+10+10=96；共扣 4 分，不重复扣根因。 |

## 环境与执行方法

- Python 3.11.6，按 README 执行 `uv venv .venv && uv pip install -p .venv/bin/python -e '.[dev]'`。以 uvicorn 默认应用启动，只改独立端口 18120；`/healthz` HTTP 200。安装、健康响应见 `evidence/install.log`、`healthz.log`。
- 学生脚本：`bash scripts/verify_mock.sh` 退出 0，ruff 通过、79 passed，20 场景映射通过；证据 `student-mock.log`。`verify_real.py --dry-run` 退出 0，仅配置自检，不计真实验收。
- F12 故障注入：`PYTHONPATH=/tmp/gateway-grade PYTEST_ADDOPTS='-p teacher_failure' bash scripts/verify_mock.sh`，插件只对一个测试的模拟上游注入 400。退出 1，`test_request_id_header_on_responses` 失败、78 passed；见 `student-injected-failure.log`。未改学生业务和断言。
- 教师服务使用学生公开 `create_app(..., transports=...)` 注入受控上游，通过真实 uvicorn socket 验证 SSE；独立配置只调整路由、重试等待、限流阈值与数据库。命令和配置见 `REPRODUCE.md`、`teacher_app.py`。
- 真实调用仅 DeepSeek 官方 `api.deepseek.com`，仅使用环境已有 `DEEPSEEK_API_KEY`，不输出或归档。根据实际 `/models`，将原 flash 上游 `deepseek-v4-flash` 替换为 `deepseek-flash`（DeepSeek-V4.1-Flash），pro 保持 `deepseek-v4-pro`；协议类型不变。25 秒超时、最多两次总尝试，独立 SQLite，无 fallback；未访问原验证配置的外部故障域名。真实限流不通过耗尽官方额度验证。

## A01–A04 / F01–F12 验证结果

| 用例 | 状态 | 实际操作、结果及证据 |
| --- | --- | --- |
| A01 | 通过 | README 安装和默认应用启动成功，独立 18120 健康检查 200；`healthz.log`、`startup-service.log`。 |
| A02 | 通过 | 同一 `/v1/chat/completions` 入口，两别名分别真实调用官方成功；`real-results.json` 普通请求。 |
| A03 | 通过 | 实际 POST `/v1/responses`，`input[].content[type=input_text]`、`instructions`、`text.format`；实际 POST `/anthropic/messages`，`messages[].content[type=text]`、顶层 `system`、`max_tokens`。正文分别从 `output[].content[].output_text` 和 `content[type=text]` 解析；流事件分别 output_text.delta/completed 与 content_block_delta/message_delta。见 `teacher-results.json` A03 及 `real-detail-results.json` 原始报文。 |
| A04 | 通过 | 未知 model 返回统一 404，不访问默认上游；`teacher-results.json` A04。 |
| F01 | 通过 | 两协议先发 first，终态被 Event 门控，客户端收到正文后另发 release；首内容约 154ms，TTFT 忽略起始元数据/心跳；真实官方 SSE 也成功。`teacher-results.json` F01。 |
| F02 | 通过 | 两协议收到正文后释放为无终态 EOF；下游有统一 error 与 DONE，账本 failed，实际各一次上游请求，无重试。学生脚本另覆盖显式流错误事件。`teacher-results.json` F02、`student-mock.log`。 |
| F03 | 通过（能力限制见后） | 统一 response_format 的 json_object 在双模拟协议可解析；完整 json_schema 双官方成功且正文解析为 `{ "ok": true }`。`teacher-results.json` F03、`real-detail-results.json`。 |
| F04 | 通过 | 双协议非法、空、截断正文经一次修复仍非法均 422；Schema 类型错误修复成功/失败分别 200/422。`teacher-results.json` F04、`extra-results.json`。 |
| F05 | 通过 | 同模板发布 v1/v2，按 1→2→1 顺序调用；实际上游 instructions 为 v1 Ada/v2 Ada/v1 Ada，账本记录版本。`teacher-results.json` F05。 |
| F06 | 通过 | 缺模板/版本 404，缺变量 422；均未发上游。`teacher-results.json` F06。 |
| F07 | 部分失败 | 普通、流式、上游错误、模板错误均可关联查询，延迟/正文 TTFT 可用；起始用量、推理分类、修复累计和本地 429 存在 D1–D3。见下述复现。 |
| F08 | 通过 | 500、500、成功，实际 3 次，等待约 .0807/.1613s，与无抖动 base=.08 指数退避一致；`teacher-results.json` F08。 |
| F09 | 通过 | 持续 500 实际 3 次后统一 502；400 只调用 1 次；直接 httpx，无 OpenAI/Anthropic SDK 叠加重试。`teacher-results.json` F09，源码 main.py:71–77、pipeline.py:215–245。 |
| F10 | 通过 | 限额 60/min、burst=1：A 首次 200、第二次 429，B 仍 200；被拒请求不发上游。`teacher-results.json` F10。 |
| F11 | 通过 | 等待 1.1 秒后 A 恢复 200，符合每秒补一个令牌；`teacher-results.json` F11。 |
| F12 | 通过 | 学生离线脚本覆盖六功能并含内容、用量、次数、错误和模板断言；注入故障后明确报告失败。见两份 student 日志与 teacher_failure.py。 |

教师主脚本完整执行 28 条观测，包含一条显式 FAIL；退出 0 只表示完成，不能解释成全部通过。F07-token-pro 的 PASS 只针对输入/输出/缓存，不代表推理分类完整。额外修复脚本也以记录的账本实际值判缺陷，而非以退出码声称用量正确。

## 扣分复现（固定源码行号）

### D1：流式用量合并与分类不完整，可观测性扣 2 分

- 触发：标准 Anthropic `message_start.usage` 提供输入 17、缓存 3，`message_delta.usage` 仅输出 5；Responses 提供推理分类。
- 预期：保留输入 17、输出 5、缓存 3，不把起始已知数据当未知；记录上游提供的推理分类，分类不重复计入总量。
- 实际：flash 账本输入 0、输出 5、缓存 0。pro 真实 Schema 上游输入 143、输出 35、缓存 128、推理 29，账本无推理分类；真实流上游输出 20 含推理 14，亦未保留分类。DeepSeek 本次 Anthropic 会在末事件重复输入，故真实调用输入正常不能反证标准分离事件缺陷。
- 命令：`.venv/bin/python /tmp/gateway-grade/teacher_verify.py`；`.venv/bin/python /tmp/gateway-grade/real_verify.py`。
- 证据：`evidence/teacher-results.json` → F07-token-flash；`evidence/real-detail-results.json` → pro Schema/stream 的 wire.raw_response 与 ledger。
- 源码：`adapters/anthropic_messages.py:138–152` 忽略 message_start、只解析末事件；`adapters/openai_responses.py:112–125` 仅映射输入/输出/缓存；`ir.py:95–104` 的 Usage 未定义推理分类。仅从 Token 子项合并扣分，不再扣协议/流式分。

### D2：结构修复丢失已知消耗，可观测性扣 1 分

- 触发：两次已返回 usage 的模型调用：首轮输入/输出 13/7，类型错误；修复轮 5/3，分别返回合法 JSON 或仍错误。
- 预期：可对账的已知输入/输出为 18/10，或分次列明并明确计量口径/不完整状态；不能无说明丢弃已知消耗。
- 实际：两协议修复成功账本仅 5/3，修复失败账本为 0/0。均实际 2 次调用，有效的 Schema 成功/失败处理本身正确。
- 命令：`.venv/bin/python /tmp/gateway-grade/extra_verify.py`。
- 证据：`evidence/extra-results.json` 四个 repair-success/repair-failed 条目，含两次实际请求、预期已知用量与终态账本。
- 源码：`pipeline.py:190–201` 仅成功完成修复后设置 state.usage；`:263–276` 新 result 覆盖上轮；`:431–447` 缺值回落零。仅扣计量完整性，不因同一问题重复扣失败记录或脚本分。

### D3：本地 429 未落账，可观测性扣 1 分

- 触发：A 模型独立令牌桶耗尽，第二次请求返回本地 429。
- 预期：响应请求标识可查到 failed/429 的账本记录；本地限流继续正常阻断。
- 实际：错误结构、HTTP 状态和隔离均正确，但按返回 X-Request-Id 查账本为空（limited_ledger=null）。
- 命令：`.venv/bin/python /tmp/gateway-grade/teacher_verify.py`，F10；查 `/admin/usage?limit=500`。
- 证据：`evidence/teacher-results.json` F10 的 limited_ledger、captures 及 `teacher-ledger.json`。
- 源码：`api/chat.py:71–79` 和 `api/responses.py:76–84` 在创建 CallState/进入记录管道前检查限流；异常处理器只格式化响应。仅扣失败记录 1 分，限流评分保留满分。

## 真实模型请求、用量与延迟

均来自教师独立配置。输入/输出/总量中，缓存和推理是子集，不再次加总；延迟用网关账本总延迟，非流式 TTFT 为 null。上游头未给请求 ID 时，从原始正文 id 提取，不与网关 ID 混同。

| 别名 / 上游模型 / 协议 | 场景 / HTTP | 网关请求 ID | 上游正文 ID | 输入/输出/总量；缓存；推理 | 总延迟 / TTFT ms |
| --- | --- | --- | --- | --- | --- |
| deepseek-pro / deepseek-v4-pro / Responses | 普通 / 200 | 141f486fb22943d4b324a9751dff83c0 | 首轮未采集正文 ID | 97/30/127；0；首轮未采集 | 1458 / null |
| deepseek-flash / deepseek-flash / Messages | 普通 / 200 | e402a84c394d42a38c05d7113b691bb4 | 首轮未采集正文 ID | 44/22/66；0；上游未提供 | 851 / null |
| deepseek-pro / deepseek-v4-pro / Responses | Schema / 200 | c1ce2b1f5bf2426b93757ef8b025c18a | 54e628a9-7138-42d1-8ae4-d213189217f5 | 143/35/178；128；29（账本漏分类） | 1245 / null |
| deepseek-pro / deepseek-v4-pro / Responses | SSE / 200 | 9f07725189634b6cb01792a1c0f35d44 | 47b73e7d-03d6-4970-b119-b871d578cc06 | 97/20/117；0；14（账本漏分类） | 713 / 709 |
| deepseek-flash / deepseek-flash / Messages | Schema / 200 | 9b783d078fac43af84d132882c483fbe | e2dd7a81-d4e2-4ab4-8011-ff75daababd6 | 115/38/153；0；上游未提供 | 974 / null |
| deepseek-flash / deepseek-flash / Messages | SSE / 200 | a6aa40f05c914bfda037c578c24b7ab2 | 445d5294-b162-42ca-aca2-eb740c246620 | 44/22/66；0；上游未提供 | 836 / 823 |

首轮及最终复核的其他请求详见 real-results.json、real-detail-results.json。真实结构化成功正文均可解析为 `{ "ok": true }`；原始流的增量/终态/usage 均保留。透明采集解压只用于证据，不修改学生收到的字节或协议逻辑。

## 限制、不扣分项与补交要求

- Responses 的 json_object 被实现映射为无 properties 的严格 Schema，本次官方返回 400，网关统一封装且没有重试；网关 ID `326ae6b8d4094016a4c8732b57e42ae0`，上游错误含 ID `87e3833a-d818-4135-aa8b-3c3612a88690`，273ms，失败无用量可确认（账本零不当作真实用量）。完整 json_schema 双协议真实成功，按能力限制说明，不另扣分。
- 官方可用模型名称随时间变化；原 flash 名称未在本次 /models 列表中出现，未实际调用该名称，也未把替代配置等同于原配置全部成功。环境差异不扣分，本次无超时/500 环境阻塞留作暂评。
- 不强制流式与 response_format 组合；README 已声明流式不本地结构修复，本次不因该组合未校验扣分。不评测额外脱敏业务范围；已有脚本中的规则与占位符还原只作亮点，不加分。
- 学生真实脚本只执行 dry-run；其真实模式含硬编码原验证配置、原 flash 名称和外部故障域名，未宣称该模式运行通过。六功能实际证据由学生离线脚本和教师受控/官方调用共同提供，不额外设置门槛。
- 必须修复：D1 用量事件合并/推理分类，D2 修复过程已知消耗保留，D3 本地拒绝记录。补交相应用量断言及按请求 ID 查询记录；复验须同时保持双协议、正文 TTFT、流后不重试及限流隔离正常。
- 本次两个 supervised 服务已停止，端口复核无监听；未提交、未推送。最终归档包含格式/合计检查、实际密钥扫描及学生源码无修改检查结果。
