"""Teacher-only upstream fixtures; student source unchanged. Run from week01 with PYTHONPATH=."""
import asyncio
import json
import threading
import time
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import httpx

OUT = Path(__file__).parent
state = {'mode': 'normal', 'requests': [], 'gate': threading.Event()}
results = []

class Upstream(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *args):
        pass
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        state['requests'].append({'path': self.path, 'body': body, 'time': time.monotonic(),
                                  'bearer_present': bool(self.headers.get('Authorization')),
                                  'x_api_key_present': bool(self.headers.get('x-api-key'))})
        mode = state['mode']
        n = len(state['requests'])
        code = 503 if mode == 'always503' or (mode == 'recover' and n <= 2) else 400 if mode == '400' else 200
        if code != 200:
            data = json.dumps({'error': {'type': 'test_error', 'message': 'teacher controlled'}}).encode()
            self.send_response(code); self.send_header('Content-Length', str(len(data))); self.end_headers()
            self.wfile.write(data); return
        anth = self.path.endswith('/messages')
        if not body.get('stream'):
            text = {'illegal': 'not json', 'empty': '', 'truncated': '{"ok":',
                    'normal': '{"ok":true,"n":7}'}.get(mode, '{"ok":true,"n":7}')
            data = {'id': 'teacher-upstream-id', 'model': body['model']}
            if anth:
                data.update(content=[{'type': 'text', 'text': text}], usage={'input_tokens': 17, 'output_tokens': 9}, stop_reason='max_tokens' if mode == 'truncated' else 'end_turn')
            else:
                data.update(choices=[{'message': {'content': text}, 'finish_reason': 'length' if mode == 'truncated' else 'stop'}], usage={'prompt_tokens': 17, 'completion_tokens': 9, 'total_tokens': 26, 'prompt_cache_hit_tokens': 5, 'completion_tokens_details': {'reasoning_tokens': 4}})
            raw = json.dumps(data).encode()
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        self.send_response(200); self.send_header('Content-Type', 'text/event-stream'); self.send_header('Connection', 'close')
        if mode == 'transportbroken':
            self.send_header('Content-Length', '1000000')
        self.end_headers()
        self.close_connection = True
        def event(obj):
            self.wfile.write(('data: ' + json.dumps(obj) + '\n\n').encode()); self.wfile.flush()
        # Empty protocol event precedes first actual content to distinguish TTFT.
        if anth:
            event({'type': 'content_block_delta', 'delta': {'type': 'text_delta', 'text': ''}})
        else:
            event({'choices': [{'delta': {'content': ''}, 'finish_reason': None}]})
        time.sleep(.14)
        if anth:
            event({'type': 'content_block_delta', 'delta': {'type': 'text_delta', 'text': 'FIRST'}})
        else:
            event({'choices': [{'delta': {'content': 'FIRST'}, 'finish_reason': None}]})
        if mode == 'gated':
            state['gate_release_seen'] = state['gate'].wait(5)
        if mode == 'broken':
            # A valid protocol error followed by EOF, no success terminal.
            event({'type': 'error', 'error': {'type': 'api_error', 'message': 'teacher stream interrupted'}})
            return
        if mode == 'transportbroken':
            return
        if anth:
            event({'type': 'message_delta', 'usage': {'output_tokens': 9}, 'delta': {'stop_reason': 'end_turn'}})
            event({'type': 'message_stop'})
        else:
            event({'choices': [{'delta': {}, 'finish_reason': 'stop'}], 'usage': {'prompt_tokens':17, 'completion_tokens':9, 'total_tokens':26}})
            self.wfile.write(b'data: [DONE]\n\n'); self.wfile.flush()

def reset(mode):
    state['mode'] = mode; state['requests'] = []; state['gate'] = threading.Event(); state['gate_release_seen'] = None

def save(name, **data):
    row = {'case': name, **data, 'upstream': list(state['requests'])}
    results.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

def req(model, **kw):
    return {'model': model, 'messages': [{'role': 'system', 'content': 'teacher system'}, {'role': 'user', 'content': 'return json'}], **kw}

def post(data):
    return httpx.post('http://127.0.0.1:19102/v1/chat/completions', json=data, timeout=15)

async def inspect_metrics():
    from app.core.config import Settings
    from app.core.models import ChatRequest
    from app.gateway import Gateway
    settings = Settings(use_mock=False, deepseek_api_key='teacher-placeholder', anthropic_api_key='teacher-placeholder', deepseek_base_url='http://127.0.0.1:19101/v1', anthropic_base_url='http://127.0.0.1:19101/v1', retry_base_delay=.04)
    gateway = Gateway(settings)
    for model in settings.model_routing:
        reset('normal')
        response = await gateway.complete(ChatRequest(**req(model)))
        save('F07-nonstream-'+model, response=response.model_dump(), record=asdict(gateway.metrics._records[-1]))
        reset('normal')
        t = time.monotonic(); first_text = None; chunks = []
        async for chunk in gateway.stream(ChatRequest(**req(model, stream=True))):
            chunks.append(chunk.model_dump())
            if first_text is None and any(c.get('delta', {}).get('content') for c in chunk.choices):
                first_text = (time.monotonic()-t)*1000
        save('F07-stream-'+model, first_text_ms=first_text, record=asdict(gateway.metrics._records[-1]), chunks=chunks)
    reset('always503')
    try:
        await gateway.complete(ChatRequest(**req('deepseek-v4-pro')))
    except Exception as e:
        save('F07-failed-provider', error=str(e), record=asdict(gateway.metrics._records[-1]))
    before = len(gateway.metrics._records)
    for data in [req('unknown'), req('deepseek-v4-pro', prompt_template='missing')]:
        try:
            await gateway.complete(ChatRequest(**data))
        except Exception as e:
            save('F07-preflight', error=str(e), records_added=len(gateway.metrics._records)-before)

def main():
    upstream = ThreadingHTTPServer(('127.0.0.1', 19101), Upstream)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    try:
        reset('normal'); r = post(req('unknown')); save('A04', status=r.status_code, response=r.json())
        for model in ['deepseek-v4-pro', 'deepseek-v4-flash']:
            for mode in ['normal', 'illegal', 'empty', 'truncated']:
                reset(mode); r = post(req(model, response_format={'type':'json_object'}))
                save('F03/F04-'+model+'-'+mode, status=r.status_code, response=r.json())
            reset('normal'); r = post({'model':model, 'messages':[{'role':'user','content':'hello'}], 'response_format':{'type':'json_object'}})
            save('F03-no-system-'+model, status=r.status_code, response=r.json())
            for mode in ['gated', 'broken', 'transportbroken']:
                reset(mode); lines=[]; early=False
                with httpx.stream('POST', 'http://127.0.0.1:19102/v1/chat/completions', json=req(model, stream=True), timeout=10) as r:
                    for line in r.iter_lines():
                        if line:
                            lines.append(line)
                        if 'FIRST' in line:
                            early = not state['gate'].is_set()
                            state['gate'].set()
                save('F01/F02-'+model+'-'+mode, status=r.status_code, received_before_terminal_release=early, upstream_gate_released_by_client=state['gate_release_seen'], lines=lines)
            for mode in ['recover', 'always503', '400']:
                reset(mode); start=time.monotonic(); r=post(req(model))
                times=[x['time'] for x in state['requests']]
                save('F08/F09-'+model+'-'+mode, status=r.status_code, response=r.json(), count=len(times), gaps=[b-a for a,b in zip(times,times[1:])], elapsed=time.monotonic()-start)
        # Public prompt API + captured upstream request proves selected old version injection.
        for version in ['v1','v2']:
            r=httpx.post('http://127.0.0.1:19102/v1/prompts', json={'id':'teacher','version':version,'content':version+' hello {{ name }}'})
            assert r.status_code==200
        for version,variables in [('v1',{'name':'Ada'}),('v2',{'name':'Bob'}),('v9',{'name':'Ada'}),('v1',{})]:
            reset('normal'); r=post(req('deepseek-v4-pro',prompt_template='teacher',prompt_version=version,prompt_variables=variables))
            save('F05/F06-'+version+str(variables),status=r.status_code,response=r.json())
        reset('normal'); r=post(req('deepseek-v4-pro',prompt_template='not-present')); save('F06-missing',status=r.status_code,response=r.json())
        asyncio.run(inspect_metrics())
    finally:
        upstream.shutdown(); upstream.server_close()
        (OUT/'controlled-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
