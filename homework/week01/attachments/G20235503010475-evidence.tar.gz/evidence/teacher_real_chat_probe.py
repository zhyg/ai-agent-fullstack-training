"""Bounded Chat Completions evidence with the officially listed flash model."""
import asyncio
import json
import os
import time
from pathlib import Path
from dataclasses import asdict
import httpx
from app.core.config import Settings
from app.core.models import ChatRequest
from app.gateway import Gateway
import teacher_real as capture

async def main():
    model=os.environ.get('TEACHER_MODEL','deepseek-flash')
    settings=Settings(use_mock=False,deepseek_api_key=os.environ['DEEPSEEK_API_KEY'],
        deepseek_base_url='https://api.deepseek.com/v1',model_routing={model:'deepseek'},templates_dir='/tmp/xue-eval/templates')
    httpx.AsyncClient=capture.observed_client
    gw=Gateway(settings); rows=[]
    for mode in os.environ.get('TEACHER_MODES','ordinary,json').split(','):
        data={'model':model,'messages':[{'role':'system','content':'Only reply JSON.'},{'role':'user','content':'Return {"ok":true} as JSON.'}],'max_tokens':256}
        if mode=='json': data['response_format']={'type':'json_object'}
        row={'model':model,'mode':mode,'protocol':'deepseek-chat'}; t=time.monotonic()
        try:
            response=await asyncio.wait_for(gw.complete(ChatRequest(**data)),90)
            row.update(response=response.model_dump(),record=asdict(gw.metrics._records[-1]),outcome='returned')
        except BaseException as e:
            row.update(outcome='unverified' if isinstance(e,asyncio.TimeoutError) else 'error',error=type(e).__name__+': '+str(e))
        row['elapsed_ms']=(time.monotonic()-t)*1000; rows.append(row)
        print(json.dumps(row,ensure_ascii=False),flush=True)
        name='real-pro-diagnostic-results.json' if model=='deepseek-v4-pro' else 'real-chat-probe-results.json'
        Path(__file__).with_name(name).write_text(json.dumps({'calls':rows,'wire':capture.wire},ensure_ascii=False,indent=2))
    httpx.AsyncClient=capture.original

if __name__=='__main__': asyncio.run(main())
