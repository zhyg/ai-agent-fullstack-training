"""Additional public HTTP limiter tests, exact sleep capture, student failure injection."""
import asyncio
import json
import runpy
from unittest.mock import patch
import httpx
from app.capabilities.retry import with_retries
from app.core.errors import GatewayError, ERR_PROVIDER_ERROR

async def backoff():
    calls=[]; sleeps=[]
    async def fail(i):
        calls.append(i)
        raise GatewayError(ERR_PROVIDER_ERROR,'controlled',502)
    async def sleep(n): sleeps.append(n)
    with patch('app.capabilities.retry.asyncio.sleep',sleep), patch('app.capabilities.retry.random.uniform',return_value=.02):
        try:
            await with_retries(fail,3,.04)
        except GatewayError as e:
            print(json.dumps({'case':'F08-exact-backoff','actual_attempts':e.attempts,'calls':calls,'sleep_seconds':sleeps,'rubric_caps':[.04,.08,.16]}))

def limiter():
    import time
    c=httpx.Client(base_url='http://127.0.0.1:19103')
    outcomes=[]
    for model in ['deepseek-v4-pro','deepseek-v4-pro','deepseek-v4-flash']:
        r=c.post('/v1/chat/completions',json={'model':model,'messages':[{'role':'user','content':'hi'}]})
        outcomes.append({'model':model,'status':r.status_code,'response':r.json()})
    time.sleep(.55)
    r=c.post('/v1/chat/completions',json={'model':'deepseek-v4-pro','messages':[{'role':'user','content':'hi'}]})
    outcomes.append({'model':'deepseek-v4-pro-after-window','status':r.status_code,'response':r.json()})
    print(json.dumps({'case':'F10-F11','outcomes':outcomes,'metrics':c.get('/v1/metrics').json()}))

asyncio.run(backoff())
limiter()
async def injected(*args,**kwargs):
    raise GatewayError('TEACHER_INJECTED','intentional F12 failure',400)
try:
    with patch('app.adapters.mock.MockOpenAIAdapter.chat',injected):
        runpy.run_path('tests/test_full.py',run_name='__main__')
except BaseException as e:
    print('F12 manufactured failure reported:',type(e).__name__,str(e))
