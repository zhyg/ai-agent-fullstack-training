# 第一周作业评测附件

- 学员：G20235503010475（xue.）
- 仓库：https://github.com/xuejieph/ai-agent-homework
- 固定分支与完整提交：main，`6abf0f05577be193471381cb2c98b0e5ada77ab5`
- 范围：week01；完整提交已 clone，评测前后学生 tracked/untracked 状态均为空；业务源码无修改。
- 评测日期：2026-11-07，Asia/Singapore。
- 总分：**80/100（暂评分）**；作业等级：**优秀**。
- 验收结论：**证据不完整**。Pro 及部分真实流式未获有效成功正文；已确定的 JSON、流异常、观测及重试缺陷另列，不因真实上游不稳定扣代码分。
- 标准：评分标准 v1.1、第一周作业原文、反馈报告模板 v1.0。未设置封顶、一票否决或按测试率换分。
- 证据：同目录 `G20235503010475-evidence.tar.gz`；内部 `REPRODUCE.md` 给出完整启动环境及命令，`student-source/` 为固定完整提交快照。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 统一入口、未知模型 404、实际双协议请求与解析成立；真实双模型前提单列未验证，不作环境扣分。 |
| 流式输出 | 12/15 | 双协议门控增量、结束块、传输断流错误及中断不重试成立；D3 协议错误事件/无终态 EOF 未识别，扣 3。 |
| 结构化输出 | 6/10 | 合法 JSON 正常解析，真实 Flash JSON 成功；D1 缺少成功前 JSON 校验扣 3；D2 无 system 时遗漏 Messages 约束扣 1。 |
| 提示词版本管理 | 10/10 | v1/v2、旧版入上游、持久化、缺模板/版本/变量均有证据。 |
| 可观测性 | 7/15 | 有分类汇总、总延迟、普通上游失败记录；D4 用量扣 3、D5 TTFT 扣 2、D6 流 ID 关联扣 1、D7 失败账目扣 2。 |
| 统一错误与重试 | 10/15 | 503 两败一成实际 3 次；持续失败 4 次符合首次加 3；D8 参数错误映射并重复请求这一根因合计扣 4；D9 抖动越上限扣 1。 |
| 按模型独立限流 | 10/10 | A:200→429，B:200，0.55 秒后 A:200；容量与窗口可配置。 |
| 源码、README 与验证脚本 | 10/10 | 安装启动、curl 入口、六项功能断言及失败输出成立；脚本仅 Mock 不当作真实验收，业务缺陷不再按缺回归重复扣。 |
| **合计** | **80/100** | 15+12+6+10+7+10+10+10=80；独立扣分共 20。 |

## 评测环境与执行入口

- 独立 venv：Python 3.11，`pip install -r requirements.txt` 成功；锁定现场版本见 `dependencies.txt`，安装日志 `install.log`。
- README 原命令 `python run.py` 在 8000 端口启动，`/health` 为 `{"status":"ok"}`；仅将模板目录指向 `/tmp/xue-eval/templates`，不修改业务源码。
- 学生 `python -m pytest tests/ -v`：**33 passed**；README 六个 `python tests/test_*.py` 入口均退出 0。见 `student-pytest.log` 与对应脚本日志。
- 受控服务 19102：`USE_MOCK=0`，两个真实 httpx 适配器的 Base URL 指向教师本地 19101 fixture；虚拟凭据为 teacher-placeholder，非真实密钥。`MAX_RETRIES=3`、`RETRY_BASE_DELAY=0.04`、容量 1000。脚本 `teacher_controlled.py`，日志 `controlled.log`，结果 `controlled-results.json`。
- 限流服务 19103：`USE_MOCK=1 RATE_LIMIT_CAPACITY=1 RATE_LIMIT_WINDOW=0.5`；`teacher_extra.py` 覆盖实际 HTTP 限流、固定随机值的等待观测、学生脚本失败注入。见 `extra.log`。
- HTTP 上游实际计数包含全部网络请求；学生使用 httpx 而非 OpenAI/Anthropic SDK，无 SDK 内置重试叠加。没有通过缩小重试次数制造通过。

复现命令约定：以下 C1、C2 均在固定源码 week01 目录运行，预先按归档 `REPRODUCE.md` 启动对应服务：

```bash
# C1：覆盖 A04、F01–F09（包含真实适配器请求/响应协议 fixture）
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_controlled.py
# C2：覆盖精确退避、F10/F11、F12 失败注入
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_extra.py
```

## A/F 验证结果

| 用例 | 结果 | 证据与范围 |
| --- | --- | --- |
| A01 | 通过 | README 安装、原 run.py 启动、健康检查；`install.log`、`startup.log`。 |
| A02 | 部分通过/未验证 | Flash 在官方 Chat、Messages 有成功正文；Pro 未取得有效真实响应，不把同一 Flash 经两协议当两个实际模型成功。 |
| A03 | 通过（受控及部分真实） | `/v1/chat/completions` 的 messages 含 system、response_format；`/v1/messages` 分离 system、必填 max_tokens、不同 content/SSE 解析；真实端点同见下表。未调用其他供应商。 |
| A04 | 通过 | unknown →404 MODEL_NOT_FOUND，上游请求为 0。 |
| F01 | 受控通过；真实未完整验证 | 两协议 FIRST 到达后才由下游放行终态，`upstream_gate_released_by_client=true`，非保护超时放行；真实若为空流不算通过。 |
| F02 | 部分失败 | 受控 HTTP 传输中断均输出 PROVIDER_ERROR，上游各 1 次不重试；协议 error 事件加 EOF 却只发 DONE，没有错误，D3。 |
| F03 | 部分通过 | 受控合法 JSON 两协议成功，真实 Flash JSON 内容合法；Messages 无 system 时未转译约束，D2。未要求额外 Schema 能力。 |
| F04 | 失败 | 两协议非法 `not json`、空串、截断 `{"ok":` 都 HTTP 200、finish_reason=stop；无修复逻辑，D1 只扣一次。 |
| F05 | 通过 | 发布 v1/v2 后显式引用均成功；捕获上游 system 为 v1 hello Ada、v2 hello Bob。 |
| F06 | 通过 | 不存在模板/版本→404；缺 name→400，未发上游请求。 |
| F07 | 部分失败 | 普通真实/受控用量、总延迟、上游失败记录存在；空块 TTFT、流用量、关联与失败覆盖见 D4–D7。 |
| F08 | 部分失败 | 两协议上游先 503 两次后成功：实际 3 次；精确 sleep 为 0.06/0.10/0.18 秒，超过 base=0.04 对应 0.04/0.08/0.16 上限，D9。 |
| F09 | 部分失败 | 持续 503 均在 4 次停止，符合代码声明首次加 3；上游 400 也实际 4 次，D8。 |
| F10 | 通过 | A 首次 200、其次 HTTP 429 RATE_LIMITED，B 仍 200。 |
| F11 | 通过 | 0.5 秒窗口，实际等待 0.55 秒后 A 200。 |
| F12 | 通过（离线范围） | 学生脚本六项断言可运行；运行期仅对 MockOpenAIAdapter 注入 GatewayError 后，学生脚本中止并清晰输出 intentional F12 failure。教师外层捕获后退出 0 不冒充学生成功，不因退出码另扣分。 |

## 每次扣分的可复现依据

行号均相对固定提交的 **week01/**，不是课程仓库同名文件；在归档 student-source/week01 下可直接核对。相同缺陷跨协议、跨输入仅计一次。

1. **D1：成功前缺少模型 JSON 校验；结构化输出扣 3 分。**
   - 触发：统一 response_format=json_object，上游分别给非法、空、截断内容。
   - 期望：不以成功返回非法正文，可明确失败；如有修复必须再次解析。
   - 实际：两协议均 HTTP 200，原样返回上述正文并标记 stop。
   - 复现：C1；`F03/F04-*-illegal/empty/truncated`，`controlled-results.json`。
   - 固定源码：`app/adapters/deepseek_adapter.py:101-109`、`app/adapters/anthropic_adapter.py:93-102`、`app/gateway.py:96-116`。缺校验这一根因统一扣 3，不另按截断或无修复重复扣。

2. **D2：Messages 没有 system 时 response_format 被忽略；结构化输出扣 1 分。**
   - 触发：只有 user 消息，仍传 response_format=json_object。
   - 期望：协议没有原生格式字段时也应添加 JSON 提示约束。
   - 实际：上游 body 只有普通 messages，没有 system 或其他格式约束；fixture 恰好给合法 JSON 不能证明学生约束生效。
   - 复现：C1；`F03-no-system-deepseek-v4-flash` 的上游 body，与带 system 的用例对照。
   - 固定源码：`app/adapters/anthropic_adapter.py:35-55`，约束代码被 `if system` 包围；与 D1 的出站校验为不同问题。

3. **D3：未识别协议错误事件及无成功终态 EOF；流式输出扣 3 分。**
   - 触发：上游已输出 FIRST，然后发送 type=error 并关闭，未发成功终态。
   - 期望：下游能区分失败，不重新生成已有内容。
   - 实际：下游只有 FIRST 与 DONE、无 error；每协议上游各 1 次。真实 HTTP 不完整 Content-Length 对照组能报 PROVIDER_ERROR 且不重试。
   - 复现：C1；`F01/F02-*-broken` 与 `*-transportbroken` 的完整 SSE 行和 upstream 数量。
   - 固定源码：`app/adapters/deepseek_adapter.py:117-143`、`app/adapters/anthropic_adapter.py:110-130`、`app/transport/server.py:55-64`。保留增量和避免重试所得分；不再就同一流失败误记成功重复扣可观测性分。

4. **D4：用量估算替代已知真实值且缺分类；可观测性扣 3 分。**
   - 触发：受控非流式上游提供输入17/输出9/总26及 cache5、reasoning4；流式也提供17/9/26（Messages 提供 output9）。
   - 期望：优先使用可获得用量，保留已提供分类；估算或未知必须标明，不当作真实值展示。
   - 实际：非流式仅保留17/9/26，分类丢失；流记录为6/1/7，无估算标记。真实 Chat probe 的 reasoning21/15 同样不在统一 usage 中。不是缺上游数据所致。
   - 复现：C1；`F07-nonstream-*`、`F07-stream-*`；真实 `real-chat-probe-results.json` 为补充对照。
   - 固定源码：`app/adapters/deepseek_adapter.py:66-71,127-130`、`app/adapters/anthropic_adapter.py:58-63,120-129`、`app/gateway.py:169-178`、`app/core/models.py:77-85`（Usage 契约）。合并用量处理根因计一次，不再分协议扣。

5. **D5：TTFT 在空块打点，非流式用总延迟冒充首 Token；可观测性扣 2 分。**
   - 触发：先发空 content，140ms 后才发 FIRST；另执行非流式请求。
   - 期望：流式首个非空内容打点；非流式无法测首 Token 时可为空。
   - 实际：最终受控结果中首正文约167.76/168.89ms，记录 TTFT 约27.11/28.22ms；非流式 TTFT 直接等于总延迟。
   - 复现：C1；`F07-stream-*` 的 first_text_ms 与 record.ttft_ms、`F07-nonstream-*`。
   - 固定源码：`app/gateway.py:102-112,158-167`；同一 TTFT 口径问题合计扣 2，不按两协议重复扣。

6. **D6：流记录 ID 与响应无法关联；可观测性扣 1 分。**
   - 触发：正常流式调用后核对块 id、CallRecord.id 与公开 metrics。
   - 期望：单次请求的响应和观测有共同可关联标识。
   - 实际：流块 ID 为 chatcmpl_*/msg_*，记录另造8位随机 ID；公开 /v1/metrics 仅聚合，没有这两个 ID 的关联。非流式复用 response.id 的部分保留得分。
   - 复现：C1；`F07-stream-*` 的 chunks[0].id 与 record.id；C2 的 metrics 汇总结构。
   - 固定源码：`app/gateway.py:171-173,186-188`、`app/capabilities/observability.py:63-95`。

7. **D7：失败记录范围及失败尝试账目不完整；可观测性扣 2 分。**
   - 触发：未知模型、缺模板、本地限流；持续503耗尽4次。
   - 期望：失败也有记录，已知重试应计3而不是0。
   - 实际：前置错误新增记录0；限流请求没有进入 metrics（C2 四次新请求只增加三条成功记录）；503有 error 记录但 retries=0。
   - 复现：C1 的 `F07-preflight`、`F07-failed-provider`，C2 `F10-F11.metrics`。外层耗尽错误已携带 attempts=4。
   - 固定源码：`app/gateway.py:89-94,117-132,142-157`、`app/capabilities/retry.py:49-52`。统一按失败账目缺陷扣 2，不用 D3 的流误记成功再扣分；不据失败尝试未知 Token 要求编造用量。

8. **D8：将上游参数错误统一归为可重试 PROVIDER_ERROR；统一错误与重试合计扣 4 分。**
   - 触发：上游持续 HTTP 400（不可修复参数错误）。
   - 期望：明确统一的4xx，实际仅请求一次。
   - 实际：两协议均请求4次，最终 HTTP502 PROVIDER_ERROR。
   - 复现：C1；`F08/F09-*-400` 的 status/count/upstream；对照 `*-always503` 合理4次、`*-recover` 合理3次。
   - 固定源码：`app/adapters/deepseek_adapter.py:94-99`、`app/adapters/anthropic_adapter.py:86-91`、`app/core/errors.py:40`。**错误状态映射和错误重试来自同一映射根因，只作本条一次4分扣分**，不再跨适配器或结构化能力扣分。

9. **D9：加性抖动超过指数单次等待上限；统一错误与重试扣 1 分。**
   - 触发：base=0.04，uniform 固定为合法取值0.02，连续失败。
   - 期望：第n次等待不超过 min(cap,base·2^(n−1))，对应0.04/0.08/0.16秒。
   - 实际：记录 sleep 为0.06/0.10/0.18；仍存在指数增长且尝试预算正确，故仅部分扣分。
   - 复现：C2，`F08-exact-backoff`。受控 HTTP 实际间隔包含连接开销，故不直接拿间隔冒充纯等待；此处单独记录公式结果。
   - 固定源码：`app/capabilities/retry.py:42-56`；无 SDK 隐藏尝试，持续错误总4次不扣次数上限。

## 真实调用记录与未验证范围

所有真实网络目标均为 **api.deepseek.com**，没有向 OpenAI、Anthropic 或其他非官方网关发请求。原提交 `deepseek-v4-pro→deepseek`、`deepseek-v4-flash→anthropic`；原 Messages Base URL 是 api.anthropic.com，本次独立配置改为 `https://api.deepseek.com/anthropic/v1`，在内存将已有 DeepSeek 凭据用于此协议。另按现场 /models 映射 flash 公共名为 `deepseek-flash`；补充 Chat probe 将此模型走 Chat，仅证明协议，不算第二个模型。没有改业务逻辑或添加 thinking 参数制造通过。

下表 request_id 使用官方响应 JSON id；响应头 x-request-id/request-id 均未提供时保持未知，不编造。耗时包含真实重试等待，Token为输入/输出/总；流记录中的字符估算不是上游用量。

| 证据文件 / 调用 | 模型与协议 | 请求标识 | 实际结果、用量、耗时 |
| --- | --- | --- | --- |
| real-results / ordinary | deepseek-v4-pro，Chat | 未取得 | 解析异常，无有效成功正文；90,841ms，真实用量未知。 |
| real-results / json | deepseek-v4-pro，Chat | 未取得 | 解析异常，未验证；109,267ms，真实用量未知。 |
| real-results / stream | deepseek-v4-pro，Chat | 未取得 | returned 但0块，**非通过**；78,871ms，真实用量未知。 |
| real-results / ordinary | deepseek-v4-flash，Messages | 未取得 | 解析异常，未验证；37,205ms，真实用量未知。 |
| real-results / json | deepseek-v4-flash，Messages | abab02a4-f83d-46bc-8501-083f18adcc91 | 内容 {"ok":true}，69/6/75；48,318ms。保留原名成功事实，不声称原别名必然无效。 |
| real-results / stream | deepseek-v4-flash，Messages | 未取得 | returned 但0块，非通过；15,346ms，真实用量未知。 |
| real-mapped-results / ordinary | deepseek-flash，Messages | 12000a0a-3e7f-4e20-826e-8f53d0d8d72d | 内容 {"ok":true}，48/19/67；11,511ms。 |
| real-mapped-results / json | deepseek-flash，Messages | 未取得 | 教师90秒外层截止，未验证；90,031ms，用量未知。 |
| real-mapped-results / stream | deepseek-flash，Messages | 未取得 | returned 但0块，非通过；15,396ms，用量未知。 |
| real-mapped-results / ordinary | deepseek-v4-pro，Chat | 未取得 | 解析异常，未验证；48,813ms，用量未知。 |
| real-mapped-results / json | deepseek-v4-pro，Chat | 未取得 | 解析异常，未验证；48,666ms，用量未知。 |
| real-mapped-results / stream | deepseek-v4-pro，Chat | 未取得 | 教师90秒截止，未验证；90,007ms，用量未知。 |
| real-chat-probe-results / ordinary | deepseek-flash，Chat | dc8345c0-4eca-47d5-8804-ecb8c5e4c4ba | 有效正文 {"ok":true}，43/27/70，reasoning21；930ms。 |
| real-chat-probe-results / json | deepseek-flash，Chat | 565c64b5-aa0b-4aee-9a03-3fb492f72c64 | 有效JSON，65/21/86，reasoning15；45,518ms。先3次官方500，错误正文request_id分别da8a456a-67a9-4138-9361-defe3bace024、0cf0bb1a-3019-4f3b-bdac-991d4ca4d16b、4909fd13-0e58-49cf-aca3-d786196d0c37；失败用量未知。 |
| real-pro-diagnostic-results / ordinary | deepseek-v4-pro，Chat | 未取得 | 最后一项已发出的诊断调用，88,193ms后解析/观察钩子异常，无有效正文和用量；不作为业务扣分依据。 |

- `official-preflight.json`：GET /models 成功；独立 baseline（显式关闭 thinking）200，id=0c89a3de-3968-41dc-8101-a2a383f58f65，6/1/7，2198ms；**不是学生适配器成功证据**，只说明网络和凭据具备部分真实接入条件。
- 观察限制：早期 real-results / real-mapped-results 的 hook 未解压 gzip，wire 部分只能核对状态与请求，成功用量取自学生响应对象。补充 Flash probe 已修正并留存解压后的原始 JSON。最后 Pro 诊断的旧 hook 对非对象 JSON 可能异常，未保存完整正文；不能据此把所有解析异常归因学生或断言确切上游根因。修正 hook 后按要求**未再发真实请求**。已有成功、失败与未验证均保留，不用 Mock 补齐真实成功。
- 未验证：Pro 有效成功接入、两实际模型完整真实 SSE 正文及终态；有原名 Messages JSON 成功，但独立映射 JSON 那次超时，不能当通过。官方500等上游条件和观察工具缺口不扣代码分，当前为暂评。
- 未额外要求：Responses 适配器真实接入、额外 Schema、NaN 严格拒绝、流式与 JSON 组合、分布式限流、持久化监控平台；不是本次扣分点。

## 补交要求与复验条件

- 必须修复：D1–D9，优先保证 JSON 成功有效、协议错误可识别、参数错误不重复请求；观测值可追溯且口径真实。
- 必须补充：官方可用配置下两个实际模型的成功响应、SSE有效正文及成功/失败终态、可关联请求标识、真实用量及总延迟。无需故意耗尽真实上游配额，重试和限流继续用受控 fixture。
- 复验：合法对照保持通过，非法/空/截断不成功；协议错误与传输断流均可识别且不重复；参数错误1次、临时错误按预算退避；已知用量、非空TTFT和失败账目准确；补足未验证真实证据后再确认最终成绩。
- 交付：仅课程仓库三份产出，未提交、未推送。评测服务停止、源码不变、合计和脱敏检查见归档 final-check.json。
