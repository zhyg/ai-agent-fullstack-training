"""Offline final checks; never makes model requests or prints credential values."""
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tarfile

ROOT=Path('/home/user/workspace/repo')
BASE=Path(__file__).parent
REPORT=ROOT/'homework/week01/G20235503010475.md'
INTERNAL=ROOT/'homework/week01/attachments/G20235503010475.md'
ARCHIVE=INTERNAL.with_name('G20235503010475-evidence.tar.gz')

def main():
    report=REPORT.read_text(); internal=INTERNAL.read_text()
    sections={}
    for n,name in [(2,'作业优点'),(3,'作业不足'),(4,'改进方案')]:
        section=report.split(f'**{n}. {name}**\n\n',1)[1].split('\n**',1)[0]
        items=[s for s in section.splitlines() if s.startswith('- ')]
        assert 3<=len(items)<=5 and len(''.join(items))<=500
        sections[name]={'items':len(items),'characters':len(''.join(items))}
    scores=[int(x) for x in re.findall(r'^\| [^|]+ \| (\d+)/(?:10|15) \|',internal,re.M)]
    assert len(scores)==8 and sum(scores)==80
    assert '优秀（80分）' in report and '80/100' in internal
    deductions=[int(x) for x in re.findall(r'^\d+\. \*\*D\d+：.*?(?:扣|扣分合计扣) (\d+) 分',internal,re.M)]
    assert len(deductions)==9 and sum(deductions)==20,(deductions,sum(deductions))
    for case in [f'A{i:02}' for i in range(1,5)]+[f'F{i:02}' for i in range(1,13)]:
        assert f'| {case} |' in internal
    clone=Path('/tmp/xue-eval/student')
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()
    status=subprocess.check_output(['git','status','--porcelain'],cwd=clone,text=True)
    assert head=='6abf0f05577be193471381cb2c98b0e5ada77ab5' and not status
    ports={}
    for port in [8000,19101,19102,19103]:
        with socket.socket() as s:
            s.settimeout(.2); ports[str(port)]=s.connect_ex(('127.0.0.1',port))!=0
    assert all(ports.values()),ports
    controlled=json.loads((BASE/'controlled-results.json').read_text())
    gated=[r for r in controlled if r['case'].endswith('gated')]
    assert len(gated)==2 and all(r['upstream_gate_released_by_client'] for r in gated)
    assert '33 passed' in (BASE/'student-pytest.log').read_text()
    # Exact-value scan; *_NAMES is metadata naming secrets, not credential material.
    credentials=[v.encode() for k,v in os.environ.items() if re.search('KEY|TOKEN|SECRET',k) and not k.endswith('_NAMES') and len(v)>=12]
    assert os.environ.get('DEEPSEEK_API_KEY')
    scanned=0
    files=[p for p in BASE.rglob('*') if p.is_file() and '__pycache__' not in p.parts]+[REPORT,INTERNAL]
    for p in files:
        raw=p.read_bytes(); assert not any(v in raw for v in credentials),f'credential leakage: {p.name}'
        scanned+=1
    archive_members=0
    if ARCHIVE.exists():
        with tarfile.open(ARCHIVE) as tar:
            for member in tar.getmembers():
                if member.isfile():
                    raw=tar.extractfile(member).read()
                    assert not any(v in raw for v in credentials),f'credential leakage in archive: {member.name}'
                    archive_members+=1
    result={'score':sum(scores),'eight_scores':scores,'deductions_total':sum(deductions),
            'format':sections,'student_commit':head,'student_worktree_clean':not status,
            'evaluation_ports_closed':ports,'gated_protocols':len(gated),'student_pytest':'33 passed',
            'exact_credential_scan':'passed','files_scanned':scanned,'archive_members_scanned':archive_members,
            'no_new_real_requests_during_finalization':True,'committed':False,'pushed':False}
    (BASE/'final-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
