"""Real calls only to api.deepseek.com, with transparent wire evidence hooks."""
import asyncio
import json
import os
import time
import gzip
from pathlib import Path
from dataclasses import asdict
import httpx
from app.core.config import Settings
from app.core.models import ChatRequest
from app.gateway import Gateway

OUT=Path(__file__).parent
wire=[]
original=httpx.AsyncClient

class Capture(httpx.AsyncByteStream):
    def __init__(self, inner, row):
        self.inner=inner; self.row=row
    async def __aiter__(self):
        parts=[]
        async for chunk in self.inner:
            parts.append(chunk)
            yield chunk
        payload=b''.join(parts)
        if payload.startswith(b'\x1f\x8b'):
            payload=gzip.decompress(payload)
        raw=payload.decode('utf8',errors='replace')
        try:
            data=json.loads(raw)
            self.row.update(upstream_id=data.get('id'),usage=data.get('usage'), upstream_model=data.get('model'),finish=[c.get('finish_reason') for c in data.get('choices',[])],stop_reason=data.get('stop_reason'))
            if self.row['status']!=200:
                self.row['error']=data
        except ValueError:
            events=[]
            for line in raw.splitlines():
                if line.startswith('data:'):
                    try:
                        evt=json.loads(line[5:])
                    except ValueError:
                        continue
                    if evt.get('usage') or evt.get('message',{}).get('usage') or evt.get('type')=='error':
                        events.append(evt)
            self.row['usage_events']=events
    async def aclose(self):
        await self.inner.aclose()

async def response_hook(response):
    request=response.request
    assert request.url.host=='api.deepseek.com', 'real traffic restricted to official DeepSeek'
    row={'url':str(request.url),'body':json.loads(request.content),'status':response.status_code,
         'request_id':response.headers.get('x-request-id') or response.headers.get('request-id')}
    wire.append(row)
    if not row['body'].get('stream'):
        await response.aread()
        try:
            data=response.json()
            row['raw_response']=data
            if isinstance(data,dict):
                row.update(upstream_id=data.get('id'),usage=data.get('usage'),upstream_model=data.get('model'))
        except ValueError:
            row['non_json_response']=response.text[:500]
    else:
        response.stream=Capture(response.stream,row)

def observed_client(*args,**kwargs):
    kwargs['event_hooks']={'response':[response_hook]}
    return original(*args,**kwargs)

async def main():
    key=os.environ.get('DEEPSEEK_API_KEY')
    if not key:
        (OUT/'real-results.json').write_text(json.dumps({'unverified':'DEEPSEEK_API_KEY absent'})); return
    settings=Settings(use_mock=False,deepseek_api_key=key,anthropic_api_key=key,
                      deepseek_base_url='https://api.deepseek.com/v1',
                      anthropic_base_url='https://api.deepseek.com/anthropic/v1',
                      templates_dir='/tmp/xue-eval/templates',max_retries=3)
    httpx.AsyncClient=observed_client
    gateway=Gateway(settings)
    results=[]
    try:
        for model in settings.model_routing:
            for mode in ['ordinary','json','stream']:
                data={'model':model,'messages':[{'role':'system','content':'Answer concisely. For JSON requests output only valid JSON.'},{'role':'user','content':'Return {"ok":true} as JSON only, no explanation.'}], 'max_tokens':512}
                if mode=='json': data['response_format']={'type':'json_object'}
                if mode=='stream': data['stream']=True
                row={'model':model,'mode':mode,'protocol':gateway.registry.resolve(model).protocol}
                start=time.monotonic(); before=len(gateway.metrics._records)
                try:
                    if mode=='stream':
                        chunks=[]
                        async for chunk in gateway.stream(ChatRequest(**data)):
                            chunks.append(chunk.model_dump())
                        row['chunks']=chunks
                    else:
                        row['response']=(await gateway.complete(ChatRequest(**data))).model_dump()
                    row['outcome']='returned'
                except Exception as e:
                    row.update(outcome='error',error=type(e).__name__+': '+str(e))
                row['elapsed_ms']=(time.monotonic()-start)*1000
                if len(gateway.metrics._records)>before:
                    row['record']=asdict(gateway.metrics._records[-1])
                results.append(row)
                print(json.dumps(row,ensure_ascii=False),flush=True)
                (OUT/'real-results.json').write_text(json.dumps({'calls':results,'wire':wire},ensure_ascii=False,indent=2))
    finally:
        httpx.AsyncClient=original

if __name__=='__main__': asyncio.run(main())
