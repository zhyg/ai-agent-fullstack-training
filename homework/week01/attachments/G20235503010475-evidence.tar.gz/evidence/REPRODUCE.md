# G20235503010475 教师复核入口

固定对象：https://github.com/xuejieph/ai-agent-homework，main，6abf0f05577be193471381cb2c98b0e5ada77ab5。
评测日期：2026-11-07（Asia/Singapore）。业务源码未改；完整固定提交另存 student-source/。

## 安装与学生脚本

在 /tmp/xue-eval/student/week01 执行；若换目录，调整下文教师脚本中临时路径。

```bash
python3 -m venv /tmp/xue-eval/venv
/tmp/xue-eval/venv/bin/pip install -r requirements.txt
TEMPLATES_DIR=/tmp/xue-eval/templates /tmp/xue-eval/venv/bin/python -m pytest tests/ -v
for f in test_routing test_core test_adapters test_streaming test_prompts test_full; do
  /tmp/xue-eval/venv/bin/python tests/$f.py
done
```

原 README 的 run.py 已按原入口启动（8000），/health 返回 200；仅将模板目录独立配置，避免测试写入固定源码目录。

## 受控协议验收

启动服务（以下为前台命令；orb 中已用 amp orb service start 监督运行）：

```bash
USE_MOCK=0 DEEPSEEK_API_KEY=teacher-placeholder ANTHROPIC_API_KEY=teacher-placeholder \
DEEPSEEK_BASE_URL=http://127.0.0.1:19101/v1 ANTHROPIC_BASE_URL=http://127.0.0.1:19101/v1 \
TEMPLATES_DIR=/tmp/xue-eval/templates MAX_RETRIES=3 RETRY_BASE_DELAY=0.04 RATE_LIMIT_CAPACITY=1000 \
/tmp/xue-eval/venv/bin/uvicorn app.transport.server:app --host 127.0.0.1 --port 19102
```

另一个终端执行：

```bash
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_controlled.py
```

fixture 仅在脚本生存期内监听 19101；只替换上游，不替换学生适配器、编排或 HTTP 层。记录路径、body 和鉴权字段是否存在，不记录凭据。门控只有下游读到 FIRST 后才主动放行终态；记录上游是否由客户端释放，排除 5 秒保护超时被误判为增量。transportbroken 使用错误 Content-Length 制造真实 HTTP 断流；broken 使用协议错误事件加 EOF。

## 限流、精确退避与脚本失败注入

```bash
USE_MOCK=1 RATE_LIMIT_CAPACITY=1 RATE_LIMIT_WINDOW=0.5 TEMPLATES_DIR=/tmp/xue-eval/templates \
/tmp/xue-eval/venv/bin/uvicorn app.transport.server:app --host 127.0.0.1 --port 19103
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_extra.py
```

F08/F09 实际次数以受控 HTTP 上游记录为准。teacher_extra.py 为精确观察等待，将 sleep 替换为记录器、将 uniform 固定为 0.02；不改变公式。F12 运行期替换学生 MockOpenAIAdapter.chat 注入明确异常，学生 test_full.py 输出错误并停止，不改源文件。

## 真实调用配置

只访问 https://api.deepseek.com；凭据从已有 DEEPSEEK_API_KEY 读取，未写入脚本、日志、配置或归档。

| 配置项 | 原提交 | 教师独立配置 |
|---|---|---|
| mock | 默认 1 | 0 |
| pro 路由 | deepseek-v4-pro → deepseek | 保留 |
| flash 路由 | deepseek-v4-flash → anthropic | 先尝试原值；另按官方 /models 配为 deepseek-flash → anthropic |
| DeepSeek base | https://api.deepseek.com/v1 | 保留 |
| Messages base | https://api.anthropic.com/v1 | https://api.deepseek.com/anthropic/v1 |
| Messages key 来源 | ANTHROPIC_API_KEY | 仅在内存引用 DEEPSEEK_API_KEY |
| 补充 Chat probe | 无 | deepseek-flash → deepseek，仅证明此协议，不冒充 Pro 成功 |
| 输出上限 | 请求可指定 | 初次 512，独立映射 128，补充 probe 256 |
| 重试 | 首次 + 3 | 保留；受控测试只降低 base，不改变次数 |

官方参考：https://api-docs.deepseek.com/guides/anthropic_api；GET /models 现场返回 deepseek-flash、deepseek-v4-pro。原 flash 名称与现行模型名的差异不单独扣代码分；原名也出现了一次成功响应，不能仅凭 /models 列表声称该别名必然不可用。

```bash
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_real.py
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_real_mapped.py
PYTHONPATH=. /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_real_chat_probe.py
TEACHER_MODEL=deepseek-v4-pro TEACHER_MODES=ordinary PYTHONPATH=. \
  /tmp/xue-eval/venv/bin/python /tmp/xue-eval/evidence/teacher_real_chat_probe.py
```

hooks 仅观察传输。初次 real-results / real-mapped-results 的 hook 未解压 gzip，所以 wire 部分可能只有状态而没有 usage；调用返回对象里的 ID/usage 仍为学生实际解析值。最终补充 probe 使用修正的 hook，保存脱敏 raw_response。不要把 outcome=returned、HTTP 200 或空流误读为验收通过；以正文、终态和 JSON 校验为准。普通接口 reasoning-only 或上游异常对象不按额外要求扣分。official-preflight 中显式关闭 thinking 的 baseline 仅排查网络条件，不算学生接入证据。

90 秒教师外层截止用于防止上游持续占用评测，不改变业务重试。超时记未验证，真实 500、超时不直接扣代码分。响应头未给 request_id 时使用官方 JSON id；两者都无则明确记未知。所有输出结果已留存，重现会产生费用，请勿为核对文字重复真实请求。
