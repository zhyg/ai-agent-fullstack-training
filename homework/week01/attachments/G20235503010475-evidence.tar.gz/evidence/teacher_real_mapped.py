"""Official advertised model-name configuration, no student logic changes."""
import asyncio
import json
import os
import time
from pathlib import Path
from dataclasses import asdict
import httpx
from app.core.config import Settings
from app.core.models import ChatRequest
from app.gateway import Gateway
import teacher_real as capture

async def main():
    key=os.environ['DEEPSEEK_API_KEY']
    # Flash public alias is corrected using official GET /models.
    settings=Settings(use_mock=False,deepseek_api_key=key,anthropic_api_key=key,
        deepseek_base_url='https://api.deepseek.com/v1',anthropic_base_url='https://api.deepseek.com/anthropic/v1',
        model_routing={'deepseek-flash':'anthropic','deepseek-v4-pro':'deepseek'},templates_dir='/tmp/xue-eval/templates')
    httpx.AsyncClient=capture.observed_client
    gw=Gateway(settings); rows=[]
    for model in settings.model_routing:
        for mode in ['ordinary','json','stream']:
            data={'model':model,'messages':[{'role':'system','content':'Reply with only JSON. Do not think or explain.'},{'role':'user','content':'Return JSON {"ok":true}.'}],'max_tokens':128}
            if mode=='json': data['response_format']={'type':'json_object'}
            if mode=='stream': data['stream']=True
            row={'model':model,'mode':mode,'protocol':gw.registry.resolve(model).protocol}
            async def invoke():
                if mode=='stream':
                    chunks=[]
                    async for chunk in gw.stream(ChatRequest(**data)):
                        chunks.append(chunk.model_dump())
                    return {'chunks':chunks}
                return {'response':(await gw.complete(ChatRequest(**data))).model_dump()}
            start=time.monotonic(); before=len(gw.metrics._records)
            try:
                row.update(await asyncio.wait_for(invoke(),90)); row['outcome']='returned'
            except BaseException as e:
                row.update(outcome='unverified' if isinstance(e,asyncio.TimeoutError) else 'error',error=type(e).__name__+': '+str(e))
            row['elapsed_ms']=(time.monotonic()-start)*1000
            if len(gw.metrics._records)>before: row['record']=asdict(gw.metrics._records[-1])
            rows.append(row)
            print(json.dumps(row,ensure_ascii=False),flush=True)
            Path(__file__).with_name('real-mapped-results.json').write_text(json.dumps({'calls':rows,'wire':capture.wire},ensure_ascii=False,indent=2))
    httpx.AsyncClient=capture.original

if __name__=='__main__': asyncio.run(main())
