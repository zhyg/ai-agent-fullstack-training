"""Real calls restricted to api.deepseek.com; API key comes only from environment.
No request authentication headers are persisted.
"""
import asyncio,json,os,time
from pathlib import Path
import httpx
from src.app import create_app
from src.config import Settings

OUT=Path(os.environ.get('EVIDENCE_DIR','/tmp/ck-evidence'))
events=[]
class Tap(httpx.AsyncByteStream):
    def __init__(self,inner,entry):self.inner,self.entry=inner,entry
    async def __aiter__(self):
        chunks=[]
        try:
            async for chunk in self.inner:
                chunks.append(chunk);yield chunk
        finally:self.entry['stream_body']=b''.join(chunks).decode('utf-8','replace')
    async def aclose(self):await self.inner.aclose()
class Capture(httpx.AsyncBaseTransport):
    def __init__(self):self.inner=httpx.AsyncHTTPTransport()
    async def handle_async_request(self,req):
        assert req.url.host=='api.deepseek.com', 'Real egress must be official DeepSeek only'
        start=time.monotonic()
        res=await self.inner.handle_async_request(req)
        entry={'url':str(req.url),'request':json.loads(req.content),'status':res.status_code,
            'headers':{k:v for k,v in res.headers.items() if 'request' in k.lower()},
            'time_to_headers_s':round(time.monotonic()-start,4)}
        if not json.loads(req.content).get('stream'):
            entry['upstream_body']=(await res.aread()).decode('utf-8','replace')
        else:
            res.stream=Tap(res.stream,entry)
        events.append(entry)
        return res
    async def aclose(self):await self.inner.aclose()

async def main():
    env={'DEEPSEEK_API_KEY':os.environ['DEEPSEEK_API_KEY'],'DEEPSEEK_BASE_URL':os.environ.get('DEEPSEEK_TEACHER_BASE','https://api.deepseek.com/v1')}
    for name,model,mode in [('a','deepseek-flash','chat'),('b','deepseek-v4-pro','responses'),('c','deepseek-v4-pro','chat')]:
        env.update({f'MODEL_{name.upper()}_PROVIDER':'deepseek',f'MODEL_{name.upper()}_UPSTREAM':model,
                    f'MODEL_{name.upper()}_MODE':mode,f'MODEL_{name.upper()}_CAPS':'json_schema,stream_usage'})
    safe={k:v for k,v in env.items() if 'API_KEY' not in k}
    safe.update({'MODEL_CHAIN':'b','ENABLE_RESPONSES_MODE':True,'READ_TIMEOUT':40,
                 'MAX_CONCURRENT_REQUESTS':10,'DATABASE_URL':'sqlite:///:memory:'})
    (OUT/'real-config.json').write_text(json.dumps(safe,indent=2))
    app=create_app(Settings(_env_file=None,model_chain='b',enable_responses_mode=True,
        database_url='sqlite:///:memory:',max_concurrent_requests=10,read_timeout=40),env=env,transport=Capture())
    results=[]
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app,raise_app_exceptions=False),base_url='http://teacher',timeout=120,
                                     headers={'X-User-Id':'teacher-real'}) as client:
            for alias,kind in [('a','normal'),('c','normal'),('b','normal'),('a','json')]:
                payload={'model':alias,'input':'Return only JSON: {"ok":true}' if kind=='json' else 'Reply only OK.',
                         'max_tokens':128,'thinking':{'type':'disabled'}}
                if kind=='json':payload['response_format']={'type':'json_object'}
                t=time.monotonic();n=len(events)
                r=await client.post('/v1/generate',json=payload)
                row={'alias':alias,'kind':kind,'status':r.status_code,'elapsed_s':round(time.monotonic()-t,4),
                     'response':r.json() if r.headers.get('content-type','').startswith('application/json') else r.text,'upstream':events[n:]}
                results.append(row);print(json.dumps(row),flush=True)
            # Collect real SSE at the ASGI send boundary; unlike ASGITransport this does not buffer.
            from teacher import asgi_request
            n=len(events);t=time.monotonic()
            try:
                r=await asgi_request(app,{'model':'a','input':'Reply only OK.','max_tokens':128,
                                         'thinking':{'type':'disabled'},'stream':True})
            except Exception as exc:
                r={'status':'exception','chunks':[],'exception':type(exc).__name__+': '+str(exc)}
            for chunk in r['chunks']:chunk['elapsed_s']=round(chunk.pop('time')-t,4)
            row={'alias':'a','kind':'stream','elapsed_s':round(time.monotonic()-t,4),'upstream':events[n:],**r}
            results.append(row);print(json.dumps(row),flush=True)
    (OUT/'real-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

if __name__=='__main__':asyncio.run(main())
