# 陈康 G20261786020140 评测证据

固定仓库：https://github.com/colorlesswind/llm-gateway
分支 main；提交 0100a8618407fcab89c1f8d64172866d596c9a32；评测日 2026-11-07（Asia/Singapore）。
student-source.tar 是 git archive HEAD 的完整提交，不含 .git、运行时 .env 或任何真实凭据。
student-status.txt 为空，表示学生跟踪源码未改。

## 复现

把 student-source.tar 解包到单独源码目录，创建 Python venv（本次 Python 3.11；orb 无 conda），安装 requirements-dev.txt。
以下命令在源码目录执行，E 是本证据目录的绝对路径，PY 是 venv 的 Python：

```sh
$PY -m pip install -r requirements-dev.txt
$PY -m pytest -q
PYTHONPATH=.:$E EVIDENCE_DIR=$E $PY $E/teacher.py
PYTHONPATH=.:$E EVIDENCE_DIR=$E $PY $E/observability.py
PYTHONPATH=.:$E $PY -m pytest -q -p forced_failure tests/test_api.py::test_generate_non_stream_returns_text
```

最后一条预期退出 1，其他退出 0；教师脚本有意记录学生缺陷而非将其全部断言成通过。
教师门控脚本通过 ASGI send 边界直接确认收到 FIRST 后才释放上游终态，避免 httpx ASGITransport 缓冲掩盖增量；模拟上游只存在于 MockTransport，controlled.invalid 不发真实网络请求。
F07 只收集 src.* 学生 logger，httpx 与教师计时不能算作学生可观测能力。

真实调用（会计费）仅在已经安全配置 DEEPSEEK_API_KEY 的进程中运行，不打印或写入其值：

```sh
PYTHONPATH=.:$E EVIDENCE_DIR=$E $PY $E/real.py
DEEPSEEK_TEACHER_BASE=https://api.deepseek.com PYTHONPATH=.:$E EVIDENCE_DIR=$E $PY $E/real.py
PYTHONPATH=.:$E EVIDENCE_DIR=$E $PY $E/real_normal_probe.py
```

第一次真实运行日志 real-initial.log 是最初 a,b,c 降级链的异常中止；保留，不隐藏。
随后 real-v1-* 是 /v1 前缀的完整逐项运行；real-* 是无 /v1 前缀的诊断运行；real-normal-probe-* 独立单模型无 fallback。
real.py 最终版本增加流体采集与配置字段，因此早期 real-v1-config.json 未包含静态设置；设置可据此脚本/附件复核。
官方模型列表为 official-models.json。official-prefix-probe.json 为不经学生网关的官方直连对照，不作为网关通过证据。

## README 安装启动差异

- README 的 conda activate agent-training 在本 orb 无 conda，改为 Python 3.11 venv；依赖原样安装，结果见 install.log、pip-freeze.txt。
- 按 README cp .env.example .env，DEEPSEEK_API_KEY 只由已存在环境注入，不写入文件。
- 原始配置 deepseek-chat → DeepSeek chat；gpt-4o-mini → OpenAI chat；Responses 开关 false。未向 OpenAI 发真实请求。
- 使用 uvicorn src.main:app --host 127.0.0.1 --port 8014，无 reload；只将数据库路径改为 /tmp/ck-startup.db。/health 和 /ready 成功，见 startup.*。
- amp orb service start ck-grade 管理启动，评测完成 amp orb service stop ck-grade 已停止。
- 真实替代配置 real-config.json：a → deepseek-flash/chat；b → deepseek-v4-pro/responses；c → deepseek-v4-pro/chat；启用 Responses，chain=b 使各协议探测不交叉 fallback，显式请求 a/c 仍由注册表正常路由；thinking disabled 由已有 extra 参数透传，max_tokens=128。未改业务逻辑。
- 受控配置 teacher.py：a/chat 与 b/responses，假凭据，退避 base=.08s、cap=.5s，熔断阈值99避免影响次数检查；F10 并发上限1。内存 SQLite。

## 关键结果

学生原套件 94 passed；故障注入 1 failed/退出1。
controlled-results.json 包含 A03/A04、F01-F06、F08-F11；observability-results.json 为 F07；F12 参考两份 student-*tests 日志及 forced-failure 日志。
完整 A/F 判定和扣分以课程仓库内部附件为准。真实双模型双协议未完成，不能把模拟通过宣称真实接入通过。
