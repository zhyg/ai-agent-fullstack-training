"""Inject one upstream failure into a student test, without editing student files."""
import httpx
def pytest_collection_modifyitems(items):
    for item in items:
        if item.name=='test_generate_non_stream_returns_text':
            item.module.chat_ok=lambda *a,**kw:httpx.Response(400,json={'error':{'message':'teacher-injected failure'}})
