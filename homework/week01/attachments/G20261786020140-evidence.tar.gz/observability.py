"""F07: inspect public responses and student-owned log records, not teacher httpx logs."""
import asyncio,json,logging,time
import httpx
from teacher import app_for,success,post,GateStream,asgi_request,OUT

async def main():
    rows=[]; logs=[]
    class Collect(logging.Handler):
        def emit(self,r):
            if r.name.startswith('src.'):
                logs.append({'logger':r.name,'level':r.levelname,'message':r.getMessage()})
    root=logging.getLogger();root.setLevel(logging.DEBUG);h=Collect();root.addHandler(h)
    scenario='normal';release=asyncio.Event();release.set()
    def handler(req):
        if scenario=='error':return httpx.Response(400,json={'error':{'message':'teacher invalid request'}})
        if scenario=='stream':return httpx.Response(200,stream=GateStream('chat',release),headers={'Content-Type':'text/event-stream'})
        return success(req)
    app=app_for(handler)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://teacher',headers={'X-User-Id':'teacher'}) as c:
            for value in ('normal','stream','error'):
                scenario=value;logs.clear();t=time.monotonic()
                if scenario=='stream':response=await asgi_request(app,{'model':'a','input':'hi','stream':True})
                else:
                    r=await post(c);response={'status':r.status_code,'body':r.json()}
                rows.append({'kind':scenario,'teacher_elapsed_s':time.monotonic()-t,'public_response':response,'student_logs':list(logs)})
    root.removeHandler(h)
    (OUT/'observability-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    print(json.dumps(rows,ensure_ascii=False,indent=2))

if __name__=='__main__':asyncio.run(main())
