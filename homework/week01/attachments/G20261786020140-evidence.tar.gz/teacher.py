"""Teacher-controlled acceptance. Run from fixed student's checkout with PYTHONPATH=.:/tmp/ck-evidence.
Only injects upstream transport/config; never changes student business logic.
"""
import asyncio, json, time, logging, os
from pathlib import Path
import httpx
from src.app import create_app
from src.config import Settings

OUT = Path(os.environ.get('EVIDENCE_DIR', '/tmp/ck-evidence'))
records = []
def record(name, **data):
    row = dict(case=name, **data)
    records.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

ENV = {'DEEPSEEK_API_KEY':'teacher-dummy-not-a-secret','DEEPSEEK_BASE_URL':'https://controlled.invalid/v1',
       'MODEL_A_PROVIDER':'deepseek','MODEL_A_UPSTREAM':'upstream-a','MODEL_A_MODE':'chat',
       'MODEL_B_PROVIDER':'deepseek','MODEL_B_UPSTREAM':'upstream-b','MODEL_B_MODE':'responses'}
def app_for(handler, **kw):
    return create_app(Settings(_env_file=None, model_chain='a,b', enable_responses_mode=True,
        database_url='sqlite:///:memory:', retry_base_delay=.08, retry_max_delay=.5,
        circuit_failure_threshold=99, **kw), env=ENV, transport=httpx.MockTransport(handler))

def success(req, text='{"value":7}', finish='stop'):
    if req.url.path.endswith('/responses'):
        return httpx.Response(200, json={'id':'resp-teacher','status':'incomplete' if finish=='length' else 'completed',
            'incomplete_details':{'reason':'max_output_tokens'} if finish=='length' else None,
            'output':[{'type':'message','content':[{'type':'output_text','text':text}]}],
            'usage':{'input_tokens':11,'output_tokens':5,'total_tokens':16,
                     'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2}}})
    return httpx.Response(200,json={'id':'chat-teacher','choices':[{'message':{'content':text},'finish_reason':finish}],
        'usage':{'prompt_tokens':11,'completion_tokens':5,'total_tokens':16,'prompt_cache_hit_tokens':3,
                 'completion_tokens_details':{'reasoning_tokens':2}}})

async def post(c, model='a', **kw):
    return await c.post('/v1/generate',json={'model':model,'input':'Return JSON {"value":7}',**kw})

class GateStream(httpx.AsyncByteStream):
    def __init__(self, protocol, release, broken=False):
        self.protocol,self.release,self.broken=protocol,release,broken
    async def __aiter__(self):
        yield b': heartbeat\n\n'
        await asyncio.sleep(.04)
        if self.protocol=='chat':
            yield b'data: {"choices":[{"delta":{"content":"FIRST"}}]}\n\n'
        else:
            yield b'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"FIRST"}\n\n'
        await self.release.wait()
        if self.broken:
            raise httpx.ReadError('teacher-controlled interruption')
        if self.protocol=='chat':
            yield b'data: {"choices":[{"delta":{"content":"SECOND"},"finish_reason":"stop"}],"usage":{"prompt_tokens":11,"completion_tokens":5,"total_tokens":16}}\n\ndata: [DONE]\n\n'
        else:
            yield b'data: {"type":"response.output_text.delta","delta":"SECOND"}\n\ndata: {"type":"response.completed","response":{"status":"completed","usage":{"input_tokens":11,"output_tokens":5,"total_tokens":16}}}\n\n'

async def asgi_request(app, payload, first=None):
    data=json.dumps(payload).encode(); chunks=[]; status=None; called=False; never=asyncio.Event()
    async def receive():
        nonlocal called
        if not called:
            called=True
            return {'type':'http.request','body':data,'more_body':False}
        await never.wait()
    async def send(m):
        nonlocal status
        if m['type']=='http.response.start': status=m['status']
        if m['type']=='http.response.body':
            chunks.append({'time':time.monotonic(),'body':m.get('body',b'').decode()})
            if first is not None and 'FIRST' in chunks[-1]['body']: first.set()
    scope={'type':'http','asgi':{'version':'3.0','spec_version':'2.4'},'http_version':'1.1','method':'POST',
           'scheme':'http','path':'/v1/generate','raw_path':b'/v1/generate','query_string':b'',
           'headers':[(b'content-type',b'application/json'),(b'x-user-id',b'teacher')],
           'server':('teacher',80),'client':('teacher',1)}
    await app(scope,receive,send)
    return {'status':status,'chunks':chunks}

async def controlled():
    captured=[]
    def handler(req):
        captured.append({'path':req.url.path,'body':json.loads(req.content),'auth_scheme':req.headers.get('authorization','').split(' ')[0]})
        return success(req)
    app=app_for(handler)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://teacher',headers={'X-User-Id':'teacher'}) as c:
            for model in ('a','b'):
                r=await post(c,model,response_format={'type':'json_object'})
                record('A03/F03-valid-'+model,status=r.status_code,response=r.json(),upstream=captured[-1])
                assert r.status_code==200 and json.loads(r.json()['output']['text'])=={'value':7}
            r=await post(c,'missing'); record('A04',status=r.status_code,body=r.json()); assert r.status_code==404
            p=await c.post('/v1/prompts',json={'name':'teacher','content':'V1 {{name}}'})
            pid=p.json()['id']
            u=await c.patch('/v1/prompts/'+pid,json={'content':'V2 {{name}}','expected_version':1})
            for version in (1,2):
                r=await post(c,prompt={'id':pid,'version':version,'variables':{'name':'Alice'}})
                record('F05-v'+str(version),status=r.status_code,upstream=captured[-1],headers=dict(r.headers))
                assert captured[-1]['body']['messages'][0]['content']=='V'+str(version)+' Alice'
            for label,prompt in [('missing-template',{'id':'ptpl_missing'}),('missing-version',{'id':pid,'version':99}),('missing-variable',{'id':pid})]:
                n=len(captured);r=await post(c,prompt=prompt)
                record('F06-'+label,status=r.status_code,body=r.json(),upstream_calls=len(captured)-n)
                assert r.status_code in (400,404) and len(captured)==n
    for model in ('a','b'):
        for label,text,finish in [('invalid','not JSON','stop'),('empty','','stop'),('truncated','{"value":','length')]:
            calls=[]
            def bad(req): calls.append(json.loads(req.content));return success(req,text,finish)
            app=app_for(bad)
            async with app.router.lifespan_context(app):
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://teacher',headers={'X-User-Id':'teacher'}) as c:
                    r=await post(c,model,response_format={'type':'json_object'})
                    record('F04-response_format-'+model+'-'+label,status=r.status_code,body=r.json(),calls=len(calls))
                    schema={'type':'object','properties':{'value':{'type':'integer'}},'required':['value']}
                    calls.clear()
                    r=await post(c,model,structured_output={'schema':schema,'max_repair_attempts':1})
                    record('F04-structured_output-'+model+'-'+label,status=r.status_code,body=r.json(),calls=len(calls))
                    assert r.status_code==502
    for model,protocol in [('a','chat'),('b','responses')]:
        for broken in (False,True):
            release=asyncio.Event();first=asyncio.Event();calls=[]
            def stream_handler(req):
                calls.append({'path':req.url.path,'body':json.loads(req.content)})
                return httpx.Response(200,headers={'Content-Type':'text/event-stream'},stream=GateStream(protocol,release,broken))
            app=app_for(stream_handler)
            async with app.router.lifespan_context(app):
                start=time.monotonic()
                task=asyncio.create_task(asgi_request(app,{'model':model,'input':'hi','stream':True},first))
                await asyncio.wait_for(first.wait(),2)
                before=not task.done() and not release.is_set()
                await asyncio.sleep(.06); release_at=time.monotonic();release.set()
                result=await asyncio.wait_for(task,3)
                record(('F02-' if broken else 'F01-')+model,first_before_release=before,release_at=release_at,
                       elapsed=time.monotonic()-start,calls=calls,**result)
                body=''.join(x['body'] for x in result['chunks'])
                assert before and len(calls)==1 and ('event: error' if broken else 'event: done') in body
                if broken: assert 'event: done' not in body
    for status,failures in [(429,2),(429,99),(400,99),(401,99),(500,2)]:
        times=[]
        def retry_handler(req):
            times.append(time.monotonic())
            if len(times)<=failures:return httpx.Response(status,json={'error':{'message':'teacher failure'}})
            return success(req)
        app=app_for(retry_handler)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://teacher',headers={'X-User-Id':'teacher'}) as c:
                r=await post(c)
                record('F08/F09-'+str(status)+'-'+str(failures),status=r.status_code,body=r.json(),actual_attempts=len(times),
                       intervals=[round(b-a,4) for a,b in zip(times,times[1:])])
    release=asyncio.Event(); entered=asyncio.Event(); calls=[]
    async def held(req):
        calls.append(json.loads(req.content)['model']); entered.set();await release.wait();return success(req)
    app=app_for(held,max_concurrent_requests=1)
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://teacher',headers={'X-User-Id':'teacher'}) as c:
            task=asyncio.create_task(post(c,'a'));await asyncio.wait_for(entered.wait(),2)
            a=await post(c,'a');b=await post(c,'b')
            record('F10',A_status=a.status_code,B_status=b.status_code,A=a.json(),B=b.json(),upstream_calls=calls.copy())
            release.set();await task
            a=await post(c,'a');b=await post(c,'b')
            record('F11',A_status=a.status_code,B_status=b.status_code,upstream_calls=calls)
            assert a.status_code==b.status_code==200
    (OUT/'controlled-results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))

if __name__=='__main__':
    logging.basicConfig(level=logging.INFO)
    asyncio.run(controlled())
