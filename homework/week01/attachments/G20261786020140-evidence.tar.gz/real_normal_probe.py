"""Isolate prompt/provider stability with no fallback, official host only."""
import asyncio,os,json,time
import httpx
from real import Capture,events,OUT
from src.app import create_app
from src.config import Settings

async def main():
    rows=[]
    for model in ('deepseek-flash','deepseek-v4-pro'):
        env={'DEEPSEEK_API_KEY':os.environ['DEEPSEEK_API_KEY'],'DEEPSEEK_BASE_URL':'https://api.deepseek.com',
             'MODEL_ONLY_PROVIDER':'deepseek','MODEL_ONLY_MODE':'chat','MODEL_ONLY_UPSTREAM':model}
        app=create_app(Settings(_env_file=None,model_chain='only',read_timeout=40),env=env,transport=Capture())
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app,raise_app_exceptions=False),base_url='http://teacher') as c:
                n=len(events);t=time.monotonic()
                r=await c.post('/v1/generate',headers={'X-User-Id':'teacher-real'},json={'model':'only','input':'Reply OK.',
                    'max_tokens':128,'thinking':{'type':'disabled'}})
                row={'model':model,'status':r.status_code,'elapsed_s':time.monotonic()-t,
                     'body':r.json() if r.headers.get('content-type','').startswith('application/json') else r.text,'upstream':events[n:]}
                rows.append(row);print(json.dumps(row),flush=True)
    (OUT/'real-normal-probe-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))

if __name__=='__main__':asyncio.run(main())
