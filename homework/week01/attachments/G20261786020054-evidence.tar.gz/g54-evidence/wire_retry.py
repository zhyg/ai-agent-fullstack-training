"""Count actual upstream TCP HTTP requests with the default student HTTP client.
No real model calls; both gateway and controlled upstream run on loopback.
"""
import asyncio
import json
import logging
import os
from pathlib import Path
import sys
import time

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import SecretStr

sys.path.insert(0, os.getcwd())
from app.config import load_config
from app.main import create_app

OUT = Path(__file__).resolve().parent
STATE = {}
RECORDS = []
stub = FastAPI()

@stub.post('/responses')
@stub.post('/anthropic/v1/messages')
async def fake(req: Request):
    body = await req.json()
    STATE['received'].append({'path': req.url.path, 'model': body['model'], 'at': time.monotonic()})
    mode = STATE['mode']
    if mode != 'retry' or len(STATE['received']) <= 2:
        return JSONResponse({'error': {'message': 'controlled wire failure'}}, status_code={'auth': 401, 'bad_request': 400}.get(mode, 503))
    if req.url.path == '/responses':
        return {'id': 'resp_wire', 'output': [{'content': [{'type': 'output_text', 'text': 'wire-OK'}]}], 'usage': {'input_tokens': 3, 'output_tokens': 2}}
    return {'id': 'msg_wire', 'content': [{'type': 'text', 'text': 'wire-OK'}], 'stop_reason': 'end_turn', 'usage': {'input_tokens': 3, 'output_tokens': 2}}

async def main():
    logging.getLogger('httpx').setLevel(logging.WARNING)
    c = load_config('gateway.example.yaml')
    c.api_keys = [SecretStr('teacher-local-only')]
    c.database_url = str(OUT / 'wire.db')
    Path(c.database_url).unlink(missing_ok=True)
    c.rate_limit.enabled = False
    c.circuit_breaker.failure_threshold = 1000
    c.retry.base_delay_seconds = .1
    c.retry.max_delay_seconds = 1
    for name, p in c.providers.items():
        p.base_url = 'http://127.0.0.1:18556' + ('/anthropic' if 'anthropic' in name else '')
        p.api_key = SecretStr('teacher-fake-upstream')
    gateway = create_app(c)  # No injected HTTP client or transport.
    servers = [uvicorn.Server(uvicorn.Config(stub, host='127.0.0.1', port=18556, log_level='warning')), uvicorn.Server(uvicorn.Config(gateway, host='127.0.0.1', port=18557, log_level='warning'))]
    tasks = [asyncio.create_task(s.serve()) for s in servers]
    while not all(s.started for s in servers):
        await asyncio.sleep(.02)
    try:
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18557', headers={'Authorization': 'Bearer teacher-local-only'}) as client:
            for model in c.models:
                for mode in ['retry', 'fail', 'auth', 'bad_request']:
                    STATE.update(mode=mode, received=[])
                    r = await client.post('/v1/chat/completions', json={'model': model, 'messages': [{'role': 'user', 'content': 'wire probe'}]})
                    received = STATE['received']
                    expected_count = 3 if mode in ('retry', 'fail') else 1
                    expected_status = {'retry': 200, 'fail': 502, 'auth': 401, 'bad_request': 400}[mode]
                    ok = r.status_code == expected_status and len(received) == expected_count
                    if mode == 'retry':
                        ok = ok and r.json()['choices'][0]['message']['content'] == 'wire-OK'
                    row = {'model': model, 'mode': mode, 'pass': ok, 'status': r.status_code, 'actual_upstream_http_requests': len(received), 'requests': received, 'intervals_seconds': [round(received[i+1]['at']-received[i]['at'], 4) for i in range(len(received)-1)]}
                    RECORDS.append(row)
                    print(json.dumps(row), flush=True)
    finally:
        for s in servers:
            s.should_exit = True
        await asyncio.gather(*tasks)
    (OUT / 'wire-results.json').write_text(json.dumps(RECORDS, indent=2))

asyncio.run(main())
