"""Capture requested waits with a legal worst-case jitter; no real calls."""
import asyncio
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, os.getcwd())
from app.config import load_config
from app.services.gateway import GatewayService

async def main():
    c = load_config('gateway.example.yaml')
    c.retry.base_delay_seconds = .1
    c.retry.max_delay_seconds = .15
    service = GatewayService(c, None, None, None, None)
    sleeps = []
    async def capture(delay):
        sleeps.append(delay)
    with patch('app.services.gateway.random.uniform', return_value=1.25), patch('app.services.gateway.asyncio.sleep', capture):
        await service._backoff(0)
        await service._backoff(1)
    row = {'base': .1, 'cap': .15, 'legal_jitter_factor': 1.25, 'requested_sleeps': sleeps, 'expected_max_sleeps': [.1, .15], 'within_bounds': all(a <= b for a, b in zip(sleeps, [.1, .15]))}
    print(json.dumps(row))
    Path(__file__).with_name('backoff-results.json').write_text(json.dumps(row, indent=2))

asyncio.run(main())
