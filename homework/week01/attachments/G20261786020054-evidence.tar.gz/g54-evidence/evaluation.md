# 第一周作业评测附件

- 学员：闲着也是闲着，G20261786020054。
- 仓库：https://github.com/CwjXFH/AgentCode；目录：`llmgateway`。
- 固定分支：`master`；固定提交：`58aefa4293d3f9f382424848199224aad768530c`。评测期间未更新分支，学生已跟踪源码无修改。
- 评测日期：2026-11-07（Asia/Singapore；原始日志使用 UTC）。
- 总分：**92/100**；作业等级：**优秀**。
- 验收结论：**通过，需修复**。双模型真实普通调用通过；功能异常路径仍有四个待修复根因，不以离线全绿替代完整验收。
- 依据：课程仓库《第一周作业.md》《第一周作业评分标准.md》v1.1、《学员作业反馈报告模板与要求.md》v1.0。
- 本次在独立 orb 亲自执行；未另开线程、未修改学生逻辑、未提交或推送。

## 一、八项评分明细

| 评分项 | 得分 | 子项与依据 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 统一入口 3、路由 4、双协议 4、统一结果 4。真实官方普通调用均为 200；受控请求证明 `input/instructions/text.format` 与 `messages/system/max_tokens` 的协议差异，未知模型明确 404。 |
| 流式输出 | 12/15 | 双模型 SSE 5、真实增量 5、终止错误 0、输出后不重试 2。D1：协议错误事件和缺少成功终态被忽略，扣 3；传输 ReadError 能发错误且仅一次上游请求，保留对应得分。 |
| 结构化输出 | 8/10 | 双协议 Schema 正常流程 4、本地解析校验 1、失败/修复再校验 3。D2：围栏只在验证局部变量中剥离，原始非法 JSON 正文仍成功返回，扣 2；非法、空、截断 JSON 和类型错误在一次修复后仍无效均返回 422。 |
| 提示词版本管理 | 10/10 | 存储 3、替换 3、旧版本引用 2、缺失项处理 2。实际发布并调用 v1/v2；缺失项没有发往模型，返回 404/422。 |
| 可观测性 | 13/15 | Token 分类 5、总延迟/TTFT 4、关联查询 3、失败记录 1。D3：模板和本地限流失败没有入账，扣 2；上游失败、结构化失败、ReadError 均有记录。D1 导致的错误流误记成功不在此重复扣分。 |
| 统一错误与重试 | 14/15 | 错误封装 4、退避 3、次数 3、不可重试 3、过程验证 1。D4：抖动后突破等待上限，扣 1；真实 TCP 受控上游两协议均实收 3/3/1/1 次，未发生 SDK 叠加超预算。 |
| 按模型独立限流 | 10/10 | 独立计数 4、HTTP 429 3、恢复 2、可配置 1。A 成功→A 429→B 成功；真实时钟等待后 A 恢复。失败漏记仅计入 D3。 |
| 源码、README 与验证脚本 | 10/10 | 源码依赖 2、启动 3、curl 示例 2、六项断言脚本 3。README 安装启动成功；12 项离线通过；强制上游 503 后 10 failed、2 passed、退出 1。未因同一业务缺陷缺回归再次扣脚本分。 |
| **合计** | **92/100** | **15 + 12 + 8 + 10 + 13 + 14 + 10 + 10 = 92；四个独立根因共扣 8 分。** |

## 二、环境、方法及复现入口

### 固定与安装启动

```bash
git clone --branch master --single-branch https://github.com/CwjXFH/AgentCode /tmp/AgentCode
git -C /tmp/AgentCode checkout --detach 58aefa4293d3f9f382424848199224aad768530c
cd /tmp/AgentCode/llmgateway
uv sync --extra dev
uv run --extra dev python scripts/verify_gateway.py
```

本次 clone 后 master HEAD 即上述固定提交，后续未移动；复现时额外 detach 以防远端更新。原 README 的 macOS 绝对路径换成 orb 中实际路径，不记为代码缺陷。Python 3.11.6、uv 0.12.9、httpx 0.28.1；完整依赖见证据包 `versions.txt`。

将 `gateway.example.yaml` 复制至独立证据目录 `readme-gateway.yaml`，保留环境变量占位符，独立 SQLite。用本地测试网关口令及个人 `DEEPSEEK_API_KEY` 环境变量，执行 README 的 `uv run uvicorn app.main:app`，仅调整 host/端口为 `0.0.0.0:18555`，由 orb service 监督启动。`/healthz`、`/readyz` 均 HTTP 200；初次 curl 早于进程就绪曾连接拒绝，确认启动日志后重新检查成功，非学生故障。原始证据：`install.log`、`startup.log`、`startup-service.log`、`health.txt`、`ready.txt`。

### 教师验证边界

- `teacher.py`：真实 uvicorn/TCP 下游；仅上游 HTTP 传输注入 `httpx.MockTransport`。走原路由、适配器、重试、模板、限流、JSON 校验和 SQLite，不修改业务函数。门控上游只有收到下游有效内容后才释放终态，排除先聚合再伪流式。
- `wire_retry.py`：两个真实 loopback TCP 服务，网关使用原始默认 `httpx.AsyncClient()`，不注入传输层；上游接收端计数，覆盖 SDK/传输隐藏重试风险。
- `backoff_probe.py`：只注入合法抖动值 1.25 与等待记录器，捕获业务代码申请的等待，不进行网络调用，不改退避公式。
- `live.py`：原配置的两个官方模型各一次普通真实调用。为限制费用仅把重试总预算降为 1、超时设为 25 秒；不替换模型、不更换协议、不修改适配逻辑。普通调用通过后未重复调用。
- `fault_plugin.py`：仅教师故障注入，将离线测试的上游 HTTP 一律变为 503，原测试断言和学生源码不变。

离线复现：解压证据包后，在固定 `llmgateway` 目录运行以下命令，`E` 指向解压后的 `g54-evidence` 目录。脚本将重建自己的独立数据库；不要与其他评测同时占用 18554/18556/18557 端口。

```bash
uv run python "$E/teacher.py" > "$E/teacher.log" 2>&1
uv run python "$E/wire_retry.py" > "$E/wire.log" 2>&1
uv run python "$E/backoff_probe.py" > "$E/backoff.log" 2>&1
PYTHONPATH="$E:$PWD" PYTEST_ADDOPTS='-p fault_plugin' \
  uv run --extra dev python scripts/verify_gateway.py
```

真实调用脚本仅在显式需要复验且提供个人环境密钥时运行，默认不应重复；已有 `live-results.json` 时脚本拒绝重跑。所有生成配置中的 SecretStr 均为遮罩，不能直接作为真实口令配置使用。证据包保留环境变量模板而非真实密钥。

## 三、A01—A04 / F01—F12 结果

| 用例 | 结果 | 触发及观察 | 证据 |
| --- | --- | --- | --- |
| A01 | 通过 | uv 安装成功、README uvicorn 启动，health/ready 均 200；没有学生机器隐藏配置依赖。 | install/startup/health/ready 文件 |
| A02 | 通过（真实） | 原别名两模型经同一 `/v1/chat/completions` 各一次官方真实调用，均 200、正文 `OK`。 | live-results.json、live-usage.json |
| A03 | 通过 | Responses `/responses`：Bearer、`input/instructions/text.format`；Messages `/anthropic/v1/messages`：x-api-key、`anthropic-version`、`messages/system/max_tokens`；原始响应分别解析 output 文本和 content 文本块。 | controlled-requests.json、A03-F03 两行、live-results.json |
| A04 | 通过 | 未知别名返回统一 `model_not_found` 404，上游计数 0。 | controlled-results.json：A04 |
| F01 | 通过（受控） | 双协议首内容在门控未释放时到达；正文 `你好-A` 完整；正常终态有 finish/DONE。UTF-8 中文跨块仍正常。 | F01-F02-…-normal |
| F02 | 部分通过 | 两协议 ReadError 均明确错误、error 账本、仅 1 次请求；协议错误事件/直接 EOF 无错误事件且账本 success，D1。 | F01-F02-…-transport_error/error_event/eof |
| F03 | 通过（受控） | 两协议统一 response_format.json_schema，正文直接解析为 `{"n":7}`；Responses 映射 text.format，Messages 系统约束+本地 Schema。 | A03-F03-… |
| F04 | 部分通过 | 非法、空、截断 JSON、字段类型不匹配，每协议均两次上游（原调用+一次修复）后 422；围栏正文直接 200，D2。 | F04-…-illegal/empty/truncated-json/schema-mismatch/fenced |
| F05 | 通过 | 发布 v1/v2，分别引用，实际进入 Responses instructions 的内容为 v1-Python/v2-Python，v1 未丢失。 | F05-v1/v2 与请求快照 |
| F06 | 通过 | 缺失模板、版本分别 404，缺变量 422，上游请求数均 0。账本问题另归 D3，不扣本项。 | F06 三行 |
| F07 | 部分通过 | 正常、流式、上游失败可关联；分类/TTFT/累计 usage 快照正确；模板、本地限流失败漏记录，D3。 | F07-…、controlled-usage.json |
| F08 | 部分通过 | 两协议前两次 503 后第三次成功；指数形状和实际等待已记录，但抖动可突破指数/配置上界，D4。 | wire-results.json、backoff-results.json |
| F09 | 通过 | 持续 503 实收 3 次后 502；401/400 仅 1 次。无 OpenAI/Anthropic SDK 安装，默认 httpx 无额外重试；真实 TCP 计数确认未叠加。 | wire-results.json、versions.txt、upstream.py 行 21—25、69—84 |
| F10 | 通过 | 同身份模型 A 配额用尽后返回真实 HTTP 429，B 正常；三个状态 `[200,429,200]`，上游共 2 次。 | F10 |
| F11 | 通过 | burst=1、600 RPM（每 0.1 秒补充 1 token），真实等待 0.12 秒后 A 再次 200。未修改时钟或桶状态。 | F11、teacher.py |
| F12 | 通过 | 正常 12 passed/0.63s，退出 0；教师强制 503 后 10 failed、2 passed/0.58s，退出 1，覆盖六项的原断言能发现故障。 | student.log、student-forced-failure.log |

结果不按测试通过率换算得分。`controlled-results.json` 中 json_object 探索用例为 false，但 README 仅明确承诺 json_schema，**不因缺少另一种结构化格式另扣分**；建议不支持的格式明确拒绝，避免“接受但未校验”。这不影响已在承诺的 json_schema 下复现的 D2。

## 四、扣分问题：触发、期望、实际、命令、固定行号

以下行号全部相对于固定提交下 `llmgateway/`，包内 `fixed-source-lines.txt` 留存带行号源码，`student-source-sha256.txt` 可校验。复现脚本输出中的 case 字段可精确定位，不依赖运行截图。

### D1：协议错误/无成功终态被当作流式成功（流式 −3）

- 触发：两协议先输出 `你好-A`，确认下游收到后发送 Responses `response.failed` / Messages `error`，或直接结束上游字节流而不发成功终态。
- 期望：客户端可识别失败，账本 error；输出后不发起新的模型生成请求。
- 实际：下游只有内容块，没有错误事件或正常 DONE；账本 status=success、status_code=200。每条仍仅请求 1 次，故不扣“输出后不重试”分。ReadError 对照组则明确 error、502、DONE，证明并非所有断流处理都缺失。
- 源码：`app/services/adapters.py:318—339` 仅处理文本与成功终态，未识别上述错误；`app/services/gateway.py:275—279,326—329` 在字节迭代结束后无条件 completed=True，并不检查 normalizer.finished。
- 命令：`uv run python "$E/teacher.py"`，查 `F01-F02-*-error_event` / `*-eof`；原始 SSE、请求次数、request_id 与账本均在 `controlled-results.json`。
- 只在流式终止与错误处理扣 3，不再按相同根因扣可观测性或统一错误分。

### D2：验证时去围栏，返回时却仍是带围栏正文（结构化 −2）

- 触发：统一请求使用 README 承诺的 json_schema，上游文本为三个反引号包围的 `json\n{"n":7}`，两协议同样复现。
- 期望：成功时 `json.loads(choices[0].message.content)` 可直接通过并满足 Schema；或统一返回失败，不允许把非法 JSON 正文作为成功。
- 实际：HTTP 200、一次上游请求，原始带围栏字符串原样返回；直接 JSON 解析失败。普通非法文本、空串、`{"n":`、类型错误对照均在两次相同输出后返回 422，保留已有解析与失败处理得分。
- 源码：`app/services/structured.py:44—63` 只修改局部 content 并返回 parsed；`app/services/gateway.py:150—152` 忽略解析结果，返回未改写的 result。
- 命令：`uv run python "$E/teacher.py"`，查 `F04-deepseek-v4-pro-fenced`、`F04-deepseek-v4-flash-fenced`。具体响应在 `controlled-results.json`，请求在 `controlled-requests.json`。
- 扣解析校验子项 2 分，不按两个协议或 json_object 探索结果重复扣分。

### D3：前置模板/本地限流失败未入账（可观测性 −2）

- 触发：推理请求引用缺失模板、版本或缺变量；以及同模型第二次请求触发本地限流。
- 期望：每次调用均可关联查询失败状态和延迟；无上游用量时不能伪造真实消耗。
- 实际：三个模板失败前后账本条数均 17→17；限流场景三次请求 `[200,429,200]` 账本仅 29→31，缺少 429 记录。上游 503/401/400 和结构化失败均实际入账，故保留失败记录部分分数。
- 源码：`app/api/routes.py:27—46` 先限流、再 prepare_body，最后才进入 call_json/stream；`app/services/gateway.py:79—89,183—193` 在业务调用内部才生成 request_id 和 UsageEvent。前置错误绕过 finally 记录。
- 命令：`uv run python "$E/teacher.py"`，查 `F07-local-failure-*`、`F07-rate-failure`，与前后条数、状态码一起复核。
- 仅可观测性失败记录扣 2；模板明确错误及本地 429 都是正确行为，不在模板/限流重复扣。

### D4：抖动后突破退避等待上界（重试 −1）

- 触发：base=0.1 秒、cap=0.15 秒，固定合法抖动因子 1.25，记录前两次实际申请的 sleep 参数。
- 期望：满足验收 F08 的上界，至多 `[0.1,0.15]` 秒；抖动不突破指数预算或配置上限。
- 实际：申请 `[0.125,0.1875]` 秒；第二次超过 cap。网络实测还留有未固定随机源的请求间隔，但不把其中网络调度开销当成精确 sleep 证据，定量结论以等待记录器为准。
- 源码：`app/services/gateway.py:347—350` 在 min(base,cap) 后乘 0.75—1.25，截断没有覆盖最终值。
- 命令：`uv run python "$E/backoff_probe.py"`；`backoff-results.json` 的 `within_bounds=false`。仅测试随机源和等待记录器注入，不改业务公式。
- 指数增长、重试范围、实际调用上限均已满足，只扣退避子项 1 分，不把“总尝试三次”当作应为“重试三次”扣分。

## 五、真实官方模型调用证据与限制

凭据只从个人 `DEEPSEEK_API_KEY` 环境读取；没有打印、复制进配置或归档。域名仅 `api.deepseek.com`，未使用第三方网关。评测时官方文档确认这两种端点及模型名有效：

- https://api-docs.deepseek.com/guides/responses_api
- https://api-docs.deepseek.com/guides/anthropic_api

| 别名 → 实际模型 | 协议与路径 | 真实结果 | 原始用量 | 延迟 |
| --- | --- | --- | --- | --- |
| deepseek-v4-pro → deepseek-v4-pro | Responses，`https://api.deepseek.com/responses` | HTTP 200；status completed；正文 OK | 输入 87，输出 24，总量 111，缓存 0，推理 22（输出子集，不能再相加） | 客户端 1826.109 ms；账本 1803.506 ms；非流式 TTFT=null |
| deepseek-v4-flash → deepseek-flash | Anthropic Messages，`https://api.deepseek.com/anthropic/v1/messages` | HTTP 200；stop_reason=end_turn；正文 OK | 输入 34，输出 23，合计 57，cache_read=0、cache_creation=0；上游未给 reasoning 分类，不认定实测为 0 | 客户端 1060.625 ms；账本 1055.931 ms；非流式 TTFT=null |

请求关联：

- Pro 网关 ID：`req_38f3b3be70f74fa58b402ec471a21c63`；上游响应 ID：`745fb6f1-ec32-43dc-a778-5bcc848ff8ca`。
- Flash 网关 ID：`req_b392db08387945299618efbc65c0fd8c`；上游响应 ID：`eea6b97c-3503-4798-a79b-695dc5b25aea`。
- 两者上游 `x-request-id` 响应头均未提供；以响应体 id 记录，不编造头部 ID。客户端延迟含下游响应/落库等开销，账本延迟口径不同，不混同。

真实调用时间约 2026-11-07 20:35（Asia/Singapore），每个别名只发一次，max_tokens=256、网关重试预算各 1。未触发 500 或超时，不需要暂评分或环境扣分；上游近期不稳定不作为代码缺陷。

**验证范围限制：**真实只验证两个普通调用及协议解析；流式、JSON/Schema、模板、失败、退避和限流均为教师受控验证，不声称已对官方逐项实测。没有替代模型差异。已成功后不重复付费验证，也未跑学生 `--live` 以免再次调用相同模型。

## 六、可观测、重试、限流专项复核

- 普通 Responses 受控 input=13、cached=3、uncached=10、output=7、reasoning=2；总量为 20，不把 cached/reasoning 重复相加。Messages 受控 uncached=11、read=3、creation=2，input=16、output=7，总量 23。原始响应及归一化结果都有记录。
- 流式重复发送累计 output=7 快照，账本仍为 7，不累计为 14。Responses 重复终态额外 DONE 属补测副作用，不据此增加扣分。
- 上游先发送无正文的 created/message_start，再延迟 120 ms 发送正文；首正文到达后下游再等 100 ms 才释放终态。Pro 下游首正文 123.7 ms、账本 TTFT 122.057 ms、总延迟 223.820 ms；Flash 为 123.6 / 121.788 / 224.072 ms。TTFT 不取连接或元数据时间。
- README 未写清未提供分类时 0 的语义，真实 Messages 的 reasoning=0 应读为“未提供”，建议改为 null 或明确文档说明；不把缺失分类作真实零消费结论，本次不另扣。Token 总量可由正确 input+output 还原，不要求新增存储字段。
- 真实 TCP 上游每协议：“503、503、成功”实收 3 次并返回 200；持续 503 实收 3 次返回 502；401/400 各实收 1 次并保留明确 4xx。默认客户端没有 SDK，未安装 openai/anthropic 包；httpx 默认链路实测亦无隐藏次数。`wire-results.json` 是接收端证据，不只统计封装函数被调用次数。
- 网络实际间隔：Pro 恢复场景 0.0919、0.2206 秒；Flash 0.0854、0.1850 秒。抖动使某次间隔可能不严格单调，因此不以单次“变小”判失败；D4 仅针对确定的最终等待上界。
- 限流按“身份+公开模型别名”分桶。burst=1、600 RPM 只用于快速验证补充规则，不修改 limiter；A 本地 429 不影响 B，0.12 秒后 A 恢复。没有耗尽真实上游额度。

## 七、补交与复验要求

1. 修复协议错误及无成功终态处理；用同样门控流证明异常可识别、账本失败、每个已输出流仍只生成一次。
2. 修复围栏校验/返回不一致；用正常 JSON、围栏、非法、空、截断和修复仍非法对照，断言成功正文可直接解析。
3. 前置模板、限流等失败纳入统一关联记录，分别复验 404/422/429；保留现有正常、上游故障和 TTFT 证据。
4. 抖动后限制最终等待上限，固定随机源重测预算；保持两协议真实 TCP 上游三次总预算与非重试错误一次请求。

不要求 Redis、Docker、多副本、额外协议、真实上游压测或题目外能力。真实普通调用已补齐，修复后优先用受控回归，不必重复付费调用。

## 八、交付及脱敏复核

- 简明报告：`homework/week01/G20261786020054.md`；四节结构，优点/不足/方案各 4 条、每节不超过 500 字。
- 本附件：`homework/week01/attachments/G20261786020054.md`。
- 证据包：`homework/week01/attachments/G20261786020054-evidence.tar.gz`。含教师脚本、遮罩配置、学生验证输出、故障输出、请求/响应摘要、分类/延迟账本、源码行号和哈希、环境与停止服务记录；不含 SQLite 原库、环境转储或真实凭据。
- 包内 `security-check.json` 记录对全部包内文件及两份报告做真实密钥精确字节匹配与常见凭据模式扫描的结果；占位符、SecretStr 遮罩及教师固定假口令不属于真实凭据。
- `student-worktree.txt` 为空，固定源码未改；`services-final.txt` 为 No orb services are running。有限期受控脚本内的 uvicorn 均已正常退出；未提交、推送或主动向父线程发消息。
