"""Teacher-controlled integration probes; student business logic remains unchanged.
Run: cd AgentCode/llmgateway && uv run python /path/to/teacher.py
Upstream HTTP boundary is simulated; downstream uses a real TCP uvicorn server.
"""
import asyncio
import json
import logging
import os
from pathlib import Path
import sys
import time

import httpx
import uvicorn

sys.path.insert(0, os.getcwd())
from app.config import load_config
from app.main import create_app

OUT = Path(__file__).resolve().parent
RESULTS = []
CALLS = []
STATE = {}
MODELS = ['deepseek-v4-pro', 'deepseek-v4-flash']
AUTH = {'Authorization': 'Bearer teacher-local-only'}
SCHEMA = {'type': 'object', 'properties': {'n': {'type': 'integer'}}, 'required': ['n'], 'additionalProperties': False}
FORMAT = {'type': 'json_schema', 'json_schema': {'name': 'result', 'schema': SCHEMA}}

def result(name, ok, **facts):
    row = {'case': name, 'pass': bool(ok), **facts}
    RESULTS.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

def frame(event, payload):
    return f'event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n'.encode()

def usage(proto):
    if proto == 'responses':
        return {'input_tokens': 13, 'output_tokens': 7, 'input_tokens_details': {'cached_tokens': 3}, 'output_tokens_details': {'reasoning_tokens': 2}}
    return {'input_tokens': 11, 'output_tokens': 7, 'cache_read_input_tokens': 3, 'cache_creation_input_tokens': 2}

class GateStream(httpx.AsyncByteStream):
    def __init__(self, proto, mode, release):
        self.proto, self.mode, self.release = proto, mode, release

    async def __aiter__(self):
        if self.proto == 'responses':
            yield frame('response.created', {'type': 'response.created', 'response': {'status': 'in_progress'}})
        else:
            yield frame('message_start', {'type': 'message_start', 'message': {'usage': {'input_tokens': 11, 'cache_read_input_tokens': 3, 'cache_creation_input_tokens': 2}}})
        await asyncio.sleep(.12)
        text = '你好-A'
        if self.proto == 'responses':
            data = frame('response.output_text.delta', {'type': 'response.output_text.delta', 'delta': text})
        else:
            data = frame('content_block_delta', {'type': 'content_block_delta', 'delta': {'type': 'text_delta', 'text': text}})
        # Split a multibyte UTF-8 codepoint across network chunks.
        p = data.index('你'.encode()) + 1
        yield data[:p]
        yield data[p:]
        await self.release.wait()
        if self.mode == 'transport_error':
            raise httpx.ReadError('controlled disconnect')
        if self.mode == 'eof':
            return
        if self.mode == 'error_event':
            if self.proto == 'responses':
                yield frame('response.failed', {'type': 'response.failed', 'response': {'status': 'failed', 'error': {'code': 'server_error', 'message': 'controlled failure'}}})
            else:
                yield frame('error', {'type': 'error', 'error': {'type': 'overloaded_error', 'message': 'controlled failure'}})
            return
        if self.proto == 'responses':
            for _ in range(2):
                yield frame('response.completed', {'type': 'response.completed', 'response': {'usage': usage(self.proto)}})
        else:
            for _ in range(2):
                yield frame('message_delta', {'type': 'message_delta', 'usage': {'output_tokens': 7}})
            yield frame('message_stop', {'type': 'message_stop'})

async def handler(req):
    body = json.loads(req.content)
    proto = 'responses' if req.url.path == '/responses' else 'anthropic'
    CALLS.append({'t': time.monotonic(), 'path': req.url.path, 'body': body, 'auth_kind': 'bearer' if 'authorization' in req.headers else 'x-api-key', 'request_id': req.headers.get('x-request-id')})
    STATE['count'] = STATE.get('count', 0) + 1
    mode = STATE.get('mode', 'normal')
    if mode in ('fail', 'auth', 'bad_request') or (mode == 'retry' and STATE['count'] <= 2):
        status = {'auth': 401, 'bad_request': 400}.get(mode, 503)
        return httpx.Response(status, json={'error': {'message': 'controlled failure'}})
    if body.get('stream'):
        return httpx.Response(200, stream=GateStream(proto, mode, STATE['release']), headers={'content-type': 'text/event-stream'})
    text = STATE.get('text', '{"n":7}')
    if proto == 'responses':
        payload = {'id': 'resp_controlled', 'status': 'incomplete' if mode == 'truncated' else 'completed', 'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}], 'usage': usage(proto)}
    else:
        payload = {'id': 'msg_controlled', 'content': [{'type': 'text', 'text': text}], 'stop_reason': 'max_tokens' if mode == 'truncated' else 'end_turn', 'usage': usage(proto)}
    return httpx.Response(200, json=payload)

def reset(mode='normal', text='{"n":7}'):
    STATE.clear()
    STATE.update(mode=mode, text=text, count=0, release=asyncio.Event())

async def main():
    logging.getLogger('httpx').setLevel(logging.WARNING)
    config = load_config('gateway.example.yaml')
    config.api_keys = [__import__('pydantic').SecretStr('teacher-local-only')]
    config.database_url = str(OUT / 'controlled.db')
    Path(config.database_url).unlink(missing_ok=True)
    config.rate_limit.enabled = False
    config.retry.base_delay_seconds = .1
    config.retry.max_delay_seconds = 1
    config.circuit_breaker.failure_threshold = 1000
    for name, p in config.providers.items():
        p.base_url = 'https://controlled.invalid' + ('/anthropic' if 'anthropic' in name else '')
        p.api_key = __import__('pydantic').SecretStr('teacher-upstream-fake')
    (OUT / 'controlled-config.json').write_text(config.model_dump_json(indent=2))
    upstream = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    app = create_app(config, http_client=upstream)
    server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=18554, log_level='warning'))
    task = asyncio.create_task(server.serve())
    while not server.started:
        await asyncio.sleep(.02)
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18554', headers=AUTH, timeout=10) as c:
        async def post(model=MODELS[0], **extra):
            return await c.post('/v1/chat/completions', json={'model': model, 'messages': [{'role': 'system', 'content': 'system-A'}, {'role': 'user', 'content': 'user-B'}], **extra})
        async def rows():
            return (await c.get('/admin/usage?limit=1000')).json()['data']
        reset()
        result('A01-health-ready', (await c.get('/healthz')).status_code == (await c.get('/readyz')).status_code == 200)
        for m in MODELS:
            reset()
            r = await post(m, max_tokens=32, response_format=FORMAT)
            call = CALLS[-1]
            pro = m == MODELS[0]
            mapping = (call['path'] == '/responses' and call['body']['input'][0]['content'] == 'user-B' and call['body']['instructions'] == 'system-A' and call['body']['text']['format']['schema'] == SCHEMA) if pro else (call['path'] == '/anthropic/v1/messages' and call['body']['messages'][0]['content'] == 'user-B' and 'conforms to this schema' in call['body']['system'])
            result('A03-F03-'+m, r.status_code == 200 and json.loads(r.json()['choices'][0]['message']['content']) == {'n': 7} and mapping, response=r.json(), request=call)
            row = (await rows())[0]
            result('F07-normal-'+m, row['input_tokens'] == (13 if pro else 16) and row['uncached_input_tokens'] == (10 if pro else 11) and row['output_tokens'] == 7 and row['cached_tokens'] == 3 and row['reasoning_tokens'] == (2 if pro else 0) and row['first_token_ms'] is None, usage=row)
        reset()
        r = await post('unknown-model')
        result('A04', r.status_code == 404 and STATE['count'] == 0, status=r.status_code, body=r.json())
        for m in MODELS:
            for text, label in [('not-json', 'illegal'), ('', 'empty'), ('{"n":', 'truncated-json'), ('{"n":"wrong"}', 'schema-mismatch'), ('```json\n{"n":7}\n```', 'fenced')]:
                reset(text=text)
                r = await post(m, response_format=FORMAT)
                result('F04-'+m+'-'+label, r.status_code == 422, status=r.status_code, attempts=STATE['count'], body=r.json())
            reset(text='{"n":')
            r = await post(m, response_format={'type': 'json_object'})
            result('F04-json-object-'+m, r.status_code >= 400, status=r.status_code, body=r.json(), note='README advertises json_schema only; assess scope before deducting')
        # Template APIs and actual upstream injection, with retained old version.
        reset()
        for version in (1, 2):
            r = await c.post('/v1/prompts', json={'id': 'teacher', 'name': 'teacher', 'content': f'v{version}-{{{{ language }}}}', 'activate': True})
            assert r.json()['version'] == version
        for version in (1, 2):
            r = await post(gateway_prompt={'id': 'teacher', 'version': version, 'variables': {'language': 'Python'}})
            result('F05-v'+str(version), r.status_code == 200 and CALLS[-1]['body']['instructions'].startswith(f'v{version}-Python'), request=CALLS[-1])
        for ref in [{'id': 'missing'}, {'id': 'teacher', 'version': 99}, {'id': 'teacher', 'version': 1}]:
            reset()
            before = len(await rows())
            r = await post(gateway_prompt=ref)
            after = len(await rows())
            result('F06-'+str(ref), r.status_code in (404, 422) and STATE['count'] == 0, status=r.status_code, body=r.json())
            result('F07-local-failure-'+str(ref), after == before + 1, before=before, after=after, status=r.status_code)
        for mode in ['retry', 'fail', 'auth', 'bad_request']:
            reset(mode)
            start = len(CALLS)
            r = await post()
            calls = CALLS[start:]
            times = [round(calls[i+1]['t'] - calls[i]['t'], 4) for i in range(len(calls)-1)]
            expected = 3 if mode in ('retry', 'fail') else 1
            result('F08-F09-'+mode, STATE['count'] == expected and r.status_code == {'retry': 200, 'fail': 502, 'auth': 401, 'bad_request': 400}[mode], status=r.status_code, attempts=STATE['count'], intervals_seconds=times, usage=(await rows())[0])
        # One stream is held open until the downstream actually receives content.
        for m in MODELS:
            for mode in ['normal', 'transport_error', 'error_event', 'eof']:
                reset(mode)
                t0 = time.monotonic()
                data = b''
                received_before_release = False
                async with c.stream('POST', '/v1/chat/completions', json={'model': m, 'messages': [{'role': 'user', 'content': 'gate'}], 'stream': True}) as r:
                    rid = r.headers['x-request-id']
                    async for chunk in r.aiter_bytes():
                        data += chunk
                        if '你好-A'.encode() in data and not STATE['release'].is_set():
                            received_before_release = True
                            first = time.monotonic() - t0
                            await asyncio.sleep(.1)
                            STATE['release'].set()
                await asyncio.sleep(.05)
                row = next(x for x in await rows() if x['request_id'] == rid)
                has_error = b'"error"' in data
                ok = received_before_release and STATE['count'] == 1 and (row['status'] == 'success' and b'[DONE]' in data if mode == 'normal' else row['status'] == 'error' and has_error)
                result('F01-F02-'+m+'-'+mode, ok, before_release=received_before_release, first_content_seconds=round(first,4), attempts=STATE['count'], sse=data.decode(), usage=row)
                if mode == 'normal':
                    result('F07-stream-'+m, row['input_tokens'] == (13 if m == MODELS[0] else 16) and row['output_tokens'] == 7 and row['first_token_ms'] >= 110 and row['latency_ms'] > row['first_token_ms'] + 80, usage=row)
        # Token-bucket refill uses the real monotonic clock, not a patched limiter.
        config.rate_limit.enabled = True
        config.rate_limit.burst = 1
        config.rate_limit.requests_per_minute = 600
        reset()
        before = len(await rows())
        a = await post(MODELS[0]); b = await post(MODELS[0]); d = await post(MODELS[1])
        count = STATE['count']
        after = len(await rows())
        result('F10', [a.status_code, b.status_code, d.status_code] == [200,429,200] and count == 2, statuses=[a.status_code,b.status_code,d.status_code], attempts=count)
        result('F07-rate-failure', after == before + 3, before=before, after=after)
        await asyncio.sleep(.12)
        r = await post(MODELS[0])
        result('F11', r.status_code == 200, status=r.status_code)
        (OUT / 'controlled-usage.json').write_text(json.dumps(await rows(), ensure_ascii=False, indent=2))
    server.should_exit = True
    await task
    await upstream.aclose()
    (OUT / 'controlled-results.json').write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2))
    (OUT / 'controlled-requests.json').write_text(json.dumps(CALLS, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    asyncio.run(main())
