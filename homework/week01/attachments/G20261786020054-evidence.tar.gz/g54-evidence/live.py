"""Exactly one upstream request per configured model; official DeepSeek only.
Credentials come only from DEEPSEEK_API_KEY and are never serialized.
Run explicitly once: uv run python /path/to/live.py
"""
import asyncio
import json
import logging
import os
from pathlib import Path
import sys
import time

import httpx
from pydantic import SecretStr

sys.path.insert(0, os.getcwd())
from app.config import load_config
from app.main import create_app

OUT = Path(__file__).resolve().parent
logging.getLogger('httpx').setLevel(logging.WARNING)

async def main():
    if (OUT / 'live-results.json').exists():
        raise RuntimeError('Prior live results exist; refusing to repeat paid calls')
    config = load_config('gateway.example.yaml')
    config.api_keys = [SecretStr('teacher-local-only')]
    config.database_url = str(OUT / 'live.db')
    config.retry.max_attempts_per_route = 1
    config.retry.max_total_attempts = 1
    config.rate_limit.enabled = False
    config.providers['deepseek_responses'].base_url = 'https://api.deepseek.com'
    config.providers['deepseek_anthropic'].base_url = 'https://api.deepseek.com/anthropic'
    for p in config.providers.values():
        p.api_key = SecretStr(os.environ['DEEPSEEK_API_KEY'])
        p.timeout_seconds = 25
        p.connect_timeout_seconds = 10
    (OUT / 'live-config.json').write_text(config.model_dump_json(indent=2))
    upstream_records = []
    async def hook(response):
        await response.aread()
        try:
            data = response.json()
        except Exception:
            data = {'non_json': True, 'bytes': len(response.content)}
        # Whitelisted result metadata, never the request headers or arbitrary error body.
        upstream_records.append({'path': response.request.url.path, 'status': response.status_code, 'request_id': response.headers.get('x-request-id'), 'id': data.get('id'), 'model': data.get('model'), 'usage': data.get('usage'), 'response_status': data.get('status'), 'stop_reason': data.get('stop_reason'), 'body_keys': list(data), 'request_body': json.loads(response.request.content)})
    upstream = httpx.AsyncClient(event_hooks={'response': [hook]})
    app = create_app(config, http_client=upstream)
    results = []
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://gateway.test', headers={'Authorization': 'Bearer teacher-local-only'}) as c:
            async def one(model):
                start = time.monotonic()
                r = await c.post('/v1/chat/completions', json={'model': model, 'messages': [{'role': 'user', 'content': 'Reply only OK.'}], 'max_tokens': 256})
                body = r.json()
                text = (body.get('choices') or [{}])[0].get('message', {}).get('content')
                row = {'alias': model, 'gateway_status': r.status_code, 'request_id': r.headers.get('x-request-id'), 'elapsed_ms': round((time.monotonic()-start)*1000,3), 'content': text, 'usage': body.get('usage'), 'error_type': body.get('error', {}).get('type'), 'error_message': body.get('error', {}).get('message')}
                results.append(row)
                print(json.dumps(row, ensure_ascii=False), flush=True)
            await asyncio.gather(*(one(m) for m in config.models))
            (OUT / 'live-usage.json').write_text(json.dumps((await c.get('/admin/usage')).json(), indent=2))
    await upstream.aclose()
    (OUT / 'live-results.json').write_text(json.dumps({'calls': results, 'upstream': upstream_records, 'attempt_limit_per_model': 1, 'official_only': True}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    asyncio.run(main())
