"""Final report arithmetic/format check and credential scan, without disclosing secrets.
Run from the course repository root. Rebuilds the evidence archive from whitelisted files.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tarfile

ROOT = Path.cwd()
E = Path(__file__).resolve().parent
REPORT = ROOT / 'homework/week01/G20261786020054.md'
ANNEX = ROOT / 'homework/week01/attachments/G20261786020054.md'
ARCHIVE = ANNEX.with_name('G20261786020054-evidence.tar.gz')
text = REPORT.read_text()
sections = {}
for n in (2, 3, 4):
    part = text.split(f'**{n}. ', 1)[1].split('**', 1)[1]
    part = part.split(f'**{n+1}. ', 1)[0] if n != 4 else part
    bullets = [s for s in part.splitlines() if s.startswith('- ')]
    chars = len(''.join(bullets))
    assert 3 <= len(bullets) <= 5 and chars <= 500
    assert part.startswith('\n\n')
    sections[str(n)] = {'bullets': len(bullets), 'chars_including_markup': chars}
scores = [int(x) for x in re.findall(r'^\| (?!\*\*)(?:[^|]+) \| (\d+)/\d+ \|', ANNEX.read_text(), re.M)]
assert len(scores) == 8 and sum(scores) == 92
assert '优秀（92分）' in text
for prefix, ns in [('A', range(1,5)), ('F', range(1,13))]:
    for n in ns:
        assert f'| {prefix}{n:02d} |' in ANNEX.read_text()
live = json.loads((E / 'live-results.json').read_text())
assert len(live['calls']) == len(live['upstream']) == 2
assert all(x['gateway_status'] == 200 and x['content'] == 'OK' for x in live['calls'])
assert all(x['pass'] for x in json.loads((E / 'wire-results.json').read_text()))
assert (E / 'student-worktree.txt').read_text() == ''
assert 'No orb services are running' in (E / 'services-final.txt').read_text()
check = {'scores': scores, 'sum': sum(scores), 'grade': '优秀', 'sections': sections, 'real_call_count': 2, 'all_16_acceptance_cases_documented': True, 'student_tracked_source_unchanged': True, 'services_stopped': True}
(E / 'format-check.json').write_text(json.dumps(check, ensure_ascii=False, indent=2))
shutil.copyfile(REPORT, E / 'feedback.md')
shutil.copyfile(ANNEX, E / 'evaluation.md')
files = sorted(p for p in E.iterdir() if p.is_file() and p.suffix != '.db' and p.name not in ('manifest.json', 'security-check.json'))
secrets = [v.encode() for k, v in os.environ.items() if re.search(r'(?:API_KEY|TOKEN|SECRET|PASSWORD)$', k, re.I) and len(v) >= 16]
assert os.getenv('DEEPSEEK_API_KEY'), 'Exact-key scan requires the evaluation key environment'
patterns = [rb'sk-[A-Za-z0-9_-]{20,}', rb'gh[pousr]_[A-Za-z0-9]{20,}', rb'AIza[A-Za-z0-9_-]{25,}', rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
hits = []
for p in files + [REPORT, ANNEX]:
    b = p.read_bytes()
    if any(s in b for s in secrets) or any(re.search(pattern, b) for pattern in patterns):
        hits.append(p.name)
assert not hits, f'Credential scan failed in files: {hits}'
security = {'exact_environment_secret_scan': 'PASS', 'includes_actual_DEEPSEEK_API_KEY': True, 'pattern_scan': 'PASS', 'secret_values_or_fingerprints_recorded': False, 'report_files_scanned': 2, 'evidence_files_scanned': len(files), 'credential_hits': 0, 'databases_and_environment_dumps_excluded': True}
(E / 'security-check.json').write_text(json.dumps(security, indent=2))
files.append(E / 'security-check.json')
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(E / 'manifest.json').write_text(json.dumps(manifest, indent=2))
files.append(E / 'manifest.json')
with tarfile.open(ARCHIVE, 'w:gz') as tar:
    for p in files:
        tar.add(p, arcname='g54-evidence/' + p.name)
# Scan the actual decompressed deliverable again and validate its manifest.
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    for member in tar.getmembers():
        b = tar.extractfile(member).read()
        assert not any(s in b for s in secrets)
        assert not any(re.search(pattern, b) for pattern in patterns)
        name = Path(member.name).name
        if name in manifest:
            assert hashlib.sha256(b).hexdigest() == manifest[name]
print(json.dumps({'format': check, 'security': security, 'archive_bytes': ARCHIVE.stat().st_size}, ensure_ascii=False, indent=2))
