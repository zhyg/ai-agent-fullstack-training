"""Teacher fault injection only; no student source or assertions are changed."""
import httpx
import pytest

@pytest.fixture(autouse=True)
def controlled_upstream_failure(monkeypatch):
    async def fail(self, request):
        return httpx.Response(503, json={'error': {'message': 'teacher forced upstream failure'}}, request=request)
    monkeypatch.setattr(httpx.MockTransport, 'handle_async_request', fail)
