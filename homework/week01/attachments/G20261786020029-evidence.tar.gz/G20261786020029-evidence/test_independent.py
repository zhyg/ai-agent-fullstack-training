"""Teacher-controlled upstream tests; no real key or provider request is used here.
Run: STUDENT_DIR=/path/to/fixed/clone python -m pytest -q -s test_independent.py
"""
import asyncio
import json
import os
import sqlite3
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, os.environ.get("STUDENT_DIR", str(Path(__file__).parent / "student")))
import gateway
import verify_live

pytestmark = pytest.mark.anyio
CHAT = "/v1/chat/completions"
MSG = [{"role": "system", "content": "Be brief."}, {"role": "user", "content": "Reply OK."}]
USAGE_PRO = {"input_tokens": 17, "output_tokens": 7, "input_tokens_details": {"cached_tokens": 5},
             "output_tokens_details": {"reasoning_tokens": 3}}
USAGE_FLASH = {"input_tokens": 11, "output_tokens": 7, "cache_read_input_tokens": 5,
               "cache_creation_input_tokens": 1}


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture(autouse=True)
def isolated(monkeypatch, tmp_path):
    monkeypatch.setenv("DEEPSEEK_API_KEY", "teacher-controlled-placeholder")
    monkeypatch.setenv("GATEWAY_USAGE_DB", str(tmp_path / "usage.sqlite3"))
    monkeypatch.setenv("GATEWAY_PRO_RPM", "60")
    monkeypatch.setenv("GATEWAY_FLASH_RPM", "60")


def emit(case, **data):
    print(json.dumps({"case": case, **data}, ensure_ascii=False), flush=True)


def upstream_result(model, text="OK", incomplete=False):
    if model == "pro":
        return {"status": "incomplete" if incomplete else "completed", "usage": USAGE_PRO,
                "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}]}
    return {"stop_reason": "max_tokens" if incomplete else "end_turn", "usage": USAGE_FLASH,
            "content": [{"type": "text", "text": text}]}


@asynccontextmanager
async def client_for(handler, on_send=None):
    app = gateway.create_app(transport=httpx.MockTransport(handler))

    async def observed(scope, receive, send):
        async def send_body(message):
            await send(message)
            if on_send and message["type"] == "http.response.body":
                on_send(message.get("body", b""))
        await app(scope, receive, send_body)

    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=observed), base_url="http://teacher.test") as c:
            yield c, app


async def invoke(c, model, **extra):
    r = await c.post(CHAT, json={"model": model, "messages": MSG, **extra})
    rid = r.headers.get("x-request-id")
    record = (await c.get(f"/v1/usage/{rid}")).json() if rid else None
    return r, record


class Frames(httpx.AsyncByteStream):
    def __init__(self, generator):
        self.generator = generator

    async def __aiter__(self):
        async for item in self.generator:
            yield item


def frame(kind, **fields):
    return ("data: " + json.dumps({"type": kind, **fields}, ensure_ascii=False) + "\n\n").encode()


@pytest.mark.parametrize("model", ["pro", "flash"])
async def test_protocol_and_gate(model):
    gate = asyncio.Event()
    requests = []
    async def frames():
        yield b": heartbeat\n\n"
        if model == "pro":
            yield frame("response.output_text.delta", delta="")
            first = frame("response.output_text.delta", delta="门")
        else:
            yield frame("message_start", message={"usage": {"input_tokens": 11, "cache_read_input_tokens": 5,
                                                               "cache_creation_input_tokens": 1}})
            first = frame("content_block_delta", delta={"type": "text_delta", "text": "门"})
        cut = first.index("门".encode()) + 1
        yield first[:cut]
        yield first[cut:]
        await asyncio.wait_for(gate.wait(), 2)
        if model == "pro":
            yield frame("response.completed", response={"usage": USAGE_PRO})
        else:
            yield frame("message_delta", delta={"stop_reason": "end_turn"}, usage=USAGE_FLASH)
            yield frame("message_stop")
    def handler(request):
        requests.append({"path": request.url.path, "body": json.loads(request.content)})
        return httpx.Response(200, stream=Frames(frames()))
    def on_send(body):
        if '"content": "门"'.encode() in body:
            gate.set()
    async with client_for(handler, on_send) as (c, app):
        r, record = await invoke(c, model, stream=True)
    emit("A03/F01 gated", model=model, received_before_terminal=gate.is_set(), requests=requests,
         response=r.text, ledger=record)
    assert gate.is_set() and "[DONE]" in r.text
    assert record["status"] == "success" and record["first_token_ms"] is not None
    assert requests[0]["path"] == ("/responses" if model == "pro" else "/anthropic/v1/messages")
    body = requests[0]["body"]
    assert (body["input"] == MSG and "messages" not in body) if model == "pro" else (
        body["system"] == "Be brief." and body["messages"] == MSG[1:] and "input" not in body)


@pytest.mark.parametrize("model", ["pro", "flash"])
async def test_interrupted_not_retried(model):
    calls = []
    async def frames():
        yield frame("response.output_text.delta", delta="partial") if model == "pro" else frame(
            "content_block_delta", delta={"type": "text_delta", "text": "partial"})
        raise httpx.ReadError("controlled disconnection")
    def handler(r):
        calls.append(time.monotonic())
        return httpx.Response(200, stream=Frames(frames()))
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, model, stream=True)
    emit("F02", model=model, attempts=len(calls), response=r.text, ledger=record)
    assert len(calls) == 1 and "[DONE]" not in r.text and "upstream_error" in r.text
    assert record["status"] == "error" and record["retries"] == 0


@pytest.mark.parametrize("model", ["pro", "flash"])
@pytest.mark.parametrize("kind,text,incomplete,expected", [
    ("valid", '{"ok":true}', False, 200), ("illegal", "not JSON", False, 502),
    ("empty", "", False, 502), ("truncated", '{"ok":', True, 502),
    ("partial-valid-text", '{"ok":true}', True, 502),
])
async def test_json_cases(model, kind, text, incomplete, expected):
    calls = []
    def handler(r):
        calls.append(json.loads(r.content))
        return httpx.Response(200, json=upstream_result(model, text, incomplete))
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, model, response_format={"type": "json_object"})
    emit("F03/F04", model=model, kind=kind, status=r.status_code, response=r.json(), ledger=record,
         attempts=len(calls), upstream_body=calls)
    assert r.status_code == expected and len(calls) == 1
    if expected == 200:
        assert json.loads(r.json()["choices"][0]["message"]["content"]) == {"ok": True}
    else:
        assert record["status"] == "error"


@pytest.mark.parametrize("model", ["pro", "flash"])
@pytest.mark.parametrize("schema,text,status", [
    ({"$defs": {"v": {"type": "integer"}}, "type": "object", "properties": {"x": {"$ref": "#/$defs/v"}}}, '{"x":2}', 200),
    ({"type": "object", "properties": {"x": {"$ref": "#/$defs/absent"}}}, '{"x":2}', 422),
    ({"type": "object", "properties": {"x": {"type": "string"}}}, '{"x":2}', 502),
])
async def test_schema(model, schema, text, status):
    def handler(r):
        return httpx.Response(200, json=upstream_result(model, text))
    fmt = {"type": "json_schema", "json_schema": {"name": "check", "schema": schema}}
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, model, response_format=fmt)
    emit("F03/B02/B03", model=model, schema=schema, status=r.status_code, body=r.json(), ledger=record)
    assert r.status_code == status


@pytest.mark.parametrize("model", ["pro", "flash"])
async def test_templates(model):
    bodies = []
    def handler(r):
        bodies.append(json.loads(r.content))
        return httpx.Response(200, json=upstream_result(model))
    outcomes = []
    async with client_for(handler) as (c, app):
        for version in (2, 1):
            r, record = await invoke(c, model, gateway_prompt={"id": "reviewer", "version": version,
                                                              "variables": {"language": "French"}})
            assert r.status_code == 200 and record["prompt_version"] == version
            outcomes.append({"version": version, "body": bodies[-1], "ledger": record})
        for ref, status in [({"id": "absent", "version": 1}, 404),
                            ({"id": "reviewer", "version": 99}, 404),
                            ({"id": "reviewer", "version": 1}, 422)]:
            r, record = await invoke(c, model, gateway_prompt=ref)
            outcomes.append({"ref": ref, "status": r.status_code, "response": r.json(), "ledger": record})
            assert r.status_code == status
    assert len(bodies) == 2
    texts = [b["input"][0]["content"] if model == "pro" else b["system"] for b in bodies]
    assert "concrete example" in texts[0] and "short answer" in texts[1]
    assert all("French" in t and "${" not in t for t in texts)
    emit("F05/F06", model=model, outcomes=outcomes)


@pytest.mark.parametrize("model", ["pro", "flash"])
@pytest.mark.parametrize("mode,attempts,status", [("recover", 3, 200), ("exhaust", 4, 502), ("unauthorized", 1, 502)])
async def test_retry_real_waits(model, mode, attempts, status):
    times = []
    def handler(r):
        times.append(time.monotonic())
        if mode == "unauthorized":
            return httpx.Response(401)
        if mode == "exhaust" or len(times) < 3:
            return httpx.Response(503)
        return httpx.Response(200, json=upstream_result(model))
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, model)
    intervals = [round(b-a, 4) for a, b in zip(times, times[1:])]
    emit("F08/F09", model=model, mode=mode, attempts=len(times), intervals=intervals,
         status=r.status_code, ledger=record)
    assert r.status_code == status and len(times) == attempts
    for measured, expected in zip(intervals, [.25, .5, 1]):
        assert expected <= measured < expected + .2
    assert record["retries"] == attempts-1


async def test_rate_isolation_recovery(monkeypatch):
    monkeypatch.setenv("GATEWAY_PRO_RPM", "1")
    calls = []
    def handler(r):
        model = "pro" if r.url.path == "/responses" else "flash"
        calls.append(model)
        return httpx.Response(200, json=upstream_result(model))
    async with client_for(handler) as (c, app):
        records = []
        for model, expected in [("pro", 200), ("pro", 429), ("flash", 200)]:
            r, record = await invoke(c, model)
            records.append({"model": model, "status": r.status_code, "ledger": record})
            assert r.status_code == expected
        # Real 60 second window; no clock patch, quota mutation or shortened business rule.
        await asyncio.sleep(60.1)
        r, record = await invoke(c, "pro")
        records.append({"model": "pro-after-60s", "status": r.status_code, "ledger": record})
    emit("F10/F11", records=records, upstream_calls=calls)
    assert r.status_code == 200 and calls == ["pro", "flash", "pro"]


async def test_usage_total_contract():
    def handler(r):
        return httpx.Response(200, json=upstream_result("pro"))
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, "pro")
    emit("F07 total", ledger=record, expected_total=24)
    assert record["usage"].get("total_tokens") == 24


async def test_messages_usage_split_events():
    async def frames():
        yield frame("message_start", message={"usage": {"input_tokens": 11, "cache_read_input_tokens": 5,
                                                           "cache_creation_input_tokens": 1}})
        yield frame("content_block_delta", delta={"type": "text_delta", "text": "OK"})
        yield frame("message_delta", delta={"stop_reason": "end_turn"}, usage={"output_tokens": 7})
        yield frame("message_stop")
    def handler(r):
        return httpx.Response(200, stream=Frames(frames()))
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, "flash", stream=True)
    emit("F07 split Messages usage", response=r.text, ledger=record, expected_input=17, expected_cached=5)
    assert record["usage"]["input_tokens"] == 17 and record["usage"]["cached_input_tokens"] == 5


async def test_known_usage_on_truncation():
    def handler(r):
        return httpx.Response(200, json=upstream_result("pro", '{"ok":', True))
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, "pro", response_format={"type": "json_object"})
    emit("F07 known failed usage", status=r.status_code, ledger=record, upstream_usage=USAGE_PRO)
    assert record["usage"]["input_tokens"] == 17 and record["usage"]["output_tokens"] == 7


async def test_upstream_unsupported_format_is_4xx():
    calls = []
    def handler(r):
        calls.append(json.loads(r.content))
        return httpx.Response(400, json={"error": {"message": "Unsupported response format", "type": "invalid_request_error"}})
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, "pro", response_format={"type": "json_schema", "json_schema": {
            "name": "check", "schema": {"type": "object"}}})
    emit("F03 unsupported format", status=r.status_code, body=r.json(), ledger=record, attempts=len(calls))
    assert len(calls) == 1 and 400 <= r.status_code < 500


async def test_early_failure_has_ledger():
    def handler(r):
        raise AssertionError("Unknown model must not reach upstream")
    async with client_for(handler) as (c, app):
        r, record = await invoke(c, "unknown")
        with sqlite3.connect(app.state.call_store.path) as db:
            count = db.execute("SELECT COUNT(*) FROM calls").fetchone()[0]
    emit("A04/F07 early failure", status=r.status_code, body=r.json(), request_id=r.headers.get("x-request-id"), rows=count)
    assert r.status_code == 404 and r.headers.get("x-request-id") and count == 1


def test_student_script_detects_empty_response():
    def handler(r):
        return httpx.Response(200, json={"choices": [{"message": {"content": ""}}]})
    with httpx.Client(transport=httpx.MockTransport(handler), base_url="http://controlled.test") as c:
        with pytest.raises(RuntimeError, match="empty ordinary reply") as error:
            verify_live.check_model(c, "pro")
    emit("F12 forced failure", detected=str(error.value))
