"""Validate fixed assessment and package only explicitly allowlisted evidence."""
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
ID = "G20261786020029"
REPORT = ROOT / "homework/week01" / (ID + ".md")
ASSESS = REPORT.parent / "attachments" / REPORT.name
ARCHIVE = ASSESS.with_name(ID + "-evidence.tar.gz")
text = REPORT.read_text()
detail = ASSESS.read_text()
audit = []
assert "优秀（96分）" in text
for number, name in [(2, "作业优点"), (3, "作业不足"), (4, "改进方案")]:
    body = text.split(f"**{number}. {name}**\n\n", 1)[1].split("\n**", 1)[0]
    bullets = [line for line in body.splitlines() if line.startswith("- ")]
    size = sum(len(re.sub(r"\s", "", line[2:])) for line in bullets)
    assert 3 <= len(bullets) <= 5 and size <= 500
    assert not any(word in body for word in ("扣分", "评分标准", "扣1", "扣2"))
    audit.append(f"{name}: {len(bullets)}条, {size}非空白字符（含标点和英文，保守计数）<=500")
scores = [int(n) for n in re.findall(r"^\| (?!合计)[^|]+ \| (\d+)/\d+ \|", detail, re.M)]
assert len(scores) == 8 and sum(scores) == 96
audit.append(f"8项得分={scores}; 合计=96; 等级=优秀; 反馈/附件一致")
for case in [f"A{i:02}" for i in range(1, 5)] + [f"F{i:02}" for i in range(1, 13)]:
    assert f"| {case} |" in detail
audit.append("A01-A04/F01-F12矩阵齐全；D1-D4复现、证据、源码位置齐全")
head = subprocess.check_output(["git", "-C", str(BASE / "student"), "rev-parse", "HEAD"], text=True).strip()
assert head == "d9373d87f3f1a0b4961b1b90692ab9726367c1f4"
assert not subprocess.check_output(["git", "-C", str(BASE / "student"), "status", "--porcelain"], text=True)
audit.append("学生HEAD正确；工作树clean；未修改学生源码")
records = [json.loads(line) for line in (BASE / "live-results.jsonl").read_text().splitlines()]
assert len(records) == 6 and all(r["status"] == 200 and r["ledger"]["status"] == "success" for r in records)
for r in records:
    if r["kind"] != "stream":
        data = json.loads(r["chunks"][0]["line"])
        assert json.loads(data["choices"][0]["message"]["content"]) == {"ok": True}
    else:
        assert r["chunks"][-1]["line"] == "data: [DONE]"
assert "exit=0" in (BASE / "student-live.log").read_text()
assert "37 passed" in (BASE / "student-tests.log").read_text()
assert "5 failed, 30 passed" in (BASE / "independent.log").read_text()
audit.append("真实探针六次200且正文可解析/流有DONE；学生另六次真实调用exit0；离线37通过；独立35项保留5失败")
assert "stopped" in (BASE / "service-stop.log").read_text()
assert "port_8129_connect_ex= 111" in (BASE / "service-stop.log").read_text()
audit.append("cody-grade服务已停止；8129端口拒绝连接")
names = ["EVIDENCE-README.md", "live_probe.py", "live-results.jsonl", "test_independent.py",
         "independent.log", "student-tests.log", "student-live.log", "dependencies.txt", "install.log",
         "source-manifest.txt", "service-stop.log", "audit_pack.py"]
entries = {name: (BASE / name).read_bytes() for name in names}
entries["feedback.md"] = REPORT.read_bytes()
entries["assessment.md"] = ASSESS.read_bytes()
secret = os.environ.get("DEEPSEEK_API_KEY", "").encode()
assert secret, "Real credential must be present for exact-value leak check"
for name, data in entries.items():
    assert secret not in data, f"Secret detected in {name}"
    assert not re.search(rb"sk-[A-Za-z0-9_-]{16,}", data), f"Key pattern in {name}"
    assert not re.search(rb"(?im)^\s*(?:authorization|x-api-key|api-key)\s*:", data), f"Auth header in {name}"
    assert not name.startswith(".env") and not name.endswith((".env", ".sqlite3", ".db", ".pem"))
audit.append("全部白名单文件扫描：真实密钥精确值0命中；sk密钥模式0命中；鉴权头行0命中；无env/数据库/密钥文件")
audit.append("归档只含下列文件；不含venv、git目录、上游请求头或进程环境转储：")
audit.extend(f"{name}: SHA256={hashlib.sha256(data).hexdigest()}" for name, data in sorted(entries.items()))
entries["audit.txt"] = ("\n".join(audit) + "\n").encode()
assert secret not in entries["audit.txt"]
with tarfile.open(ARCHIVE, "x:gz") as archive:
    for name, data in sorted(entries.items()):
        item = tarfile.TarInfo("G20261786020029-evidence/" + name)
        item.size = len(data)
        item.mode = 0o644
        archive.addfile(item, io.BytesIO(data))
with tarfile.open(ARCHIVE) as archive:
    assert len(archive.getmembers()) == len(entries)
    assert all(secret not in archive.extractfile(item).read() for item in archive.getmembers())
print("\n".join(audit[:8]))
print(f"Archive verified: {ARCHIVE.name}; {len(entries)} files; {ARCHIVE.stat().st_size} bytes")
print("SHA256=" + hashlib.sha256(ARCHIVE.read_bytes()).hexdigest())
