# Cody 第一周首次提交：独立评测证据

- 学号：G20261786020029。
- 仓库：https://github.com/yuanwenlou/ai-agent-week01-llm-gateway
- 分支：main；固定提交：d9373d87f3f1a0b4961b1b90692ab9726367c1f4（detached HEAD）。
- 评测日期：2026-11-14，Asia/Singapore。
- 依据：课程仓库 hw-guide/week01/第一周作业.md、第一周作业评分标准.md（1.1）与 hw-guide/学员作业反馈报告模板与要求.md（1.0）。
- 学生源码未修改；实际 git clone 成功，不是网页快照。

## 文件和信任边界

- live_probe.py / live-results.jsonl：教师通过真实 Uvicorn 服务发起的两模型普通、SSE、JSON 六次真实调用，记录正文到达时间、响应 ID、完整响应及账本。只使用进程继承的个人 DEEPSEEK_API_KEY；无重新映射、代理适配或其他供应商调用。每次固定 1024 输出 token 上限，短提示且关闭思考模式。
- student-live.log：原版 verify_live.py 的另外六次真实调用及用量查询，退出码 0。
- test_independent.py / independent.log：教师独立受控上游测试；通过学生公开 create_app(transport=...) 注入 httpx.MockTransport，仅替换网络边界，不改业务逻辑。测试以明确的虚拟凭据在进程内隔离，绝不连接真实供应商。预期契约失败保留为 pytest 失败，不修改期望使其转绿。
- student-tests.log：原版离线测试运行结果。仅模拟测试通过，不等于真实功能全部通过。
- dependencies.txt / install.log：隔离虚拟环境安装记录。
- source-manifest.txt：固定提交及源码 SHA-256；源码从该公开提交复取，不在包中保存带鉴权构造的源码或请求头。
- audit.txt：报告格式、分数、归档内容和秘密扫描结果。

## 复现

在独立目录执行以下命令（不含任何真实密钥；真实测试先在自己的进程环境安全注入密钥）：

```bash
git clone https://github.com/yuanwenlou/ai-agent-week01-llm-gateway student
git -C student checkout --detach d9373d87f3f1a0b4961b1b90692ab9726367c1f4
python -m venv venv
venv/bin/pip install -r student/requirements.txt
# 原版离线脚本：在 student 目录执行 python -B -m pytest -q -p no:cacheprovider
STUDENT_DIR="$PWD/student" venv/bin/python -B -m pytest -q -s -p no:cacheprovider test_independent.py
```

独立测试包含真正等待 60.1 秒的限流恢复，不是改时钟或修改窗口。该轮整体需约一分钟以上。单项复现可用 `-k usage_total_contract`、`-k messages_usage_split_events`、`-k known_usage_on_truncation`、`-k upstream_unsupported_format_is_4xx` 等筛选器。

真实服务启动命令（Linux 对 README PowerShell 的等价转换；模型、协议和预算均为原版默认值）：

```bash
# 在 student 目录；凭据只从现有进程环境读取，不写入文件或命令行
GATEWAY_USAGE_DB=/absolute/writable/live.sqlite3 ../venv/bin/python -B -m uvicorn gateway:app --host 127.0.0.1 --port 8129
```

另一个终端执行 `venv/bin/python -B live_probe.py`；原版真实脚本在 student 目录执行 `../venv/bin/python -B verify_live.py --base-url http://127.0.0.1:8129`。

## 已知限制

只验证单进程部署与短文本。并未用真实模型制造持续 503、连接中断、配额耗尽或上游不支持格式；这些是明确标识的受控测试。此次真实 DeepSeek Messages 末尾事件包含完整用量，因此真实流式用量正常；输入用量仅在 message_start 提供的有效协议变体在受控测试中复现漏记，不能说本次真实调用漏记。未做真实 json_schema、长思考、压测、多 worker 或生产部署验收。没有输出任何环境快照、鉴权头或真实凭据。
