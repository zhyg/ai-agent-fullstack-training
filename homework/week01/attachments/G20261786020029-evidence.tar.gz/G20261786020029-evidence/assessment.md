# 第一周作业评测附件

- 学员：Cody，G20261786020029，第一次提交。
- 仓库：https://github.com/yuanwenlou/ai-agent-week01-llm-gateway
- 分支与提交号：克隆 main 后 detached HEAD 固定 `d9373d87f3f1a0b4961b1b90692ab9726367c1f4`。
- 评测日期：2026-11-14（Asia/Singapore，14:03起）。
- 总分：96/100。
- 作业等级：优秀（仅按 80/60 分段，不封顶，不使用一票否决）。
- 验收结论：通过，需修复。
- 唯一判分及格式依据：`hw-guide/week01/第一周作业评分标准.md` v1.1、`hw-guide/学员作业反馈报告模板与要求.md` v1.0；另完整阅读 `hw-guide/week01/第一周作业.md` 原文。
- 交付状态：本线程新 orb 实际 git clone，独立评测，无其他线程或子代理；未修改学生业务逻辑，未提交、推送。无同名旧文件，使用标准文件名。
- 证据包：`G20261786020029-evidence.tar.gz`；下文日志、脚本均指包内文件。源码行号均指上述固定学生提交，不是课程仓库文件。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 统一入口3、路由4、双协议4、统一结果4。真实双路由成功，未知模型404且不触发上游。 |
| 流式输出 | 15/15 | 双模型SSE5、真实增量5、终止错误3、输出后不重试2。门控等待下游首字后才释放终态；断流返回错误且只有一次上游请求。 |
| 结构化输出 | 10/10 | 正常流程4、解析3、失败处理3。双模型真实JSON成功；受控非法/空/截断拒绝，Schema类型与本地引用有正反例。格式不支持的状态码问题只计入统一错误项。 |
| 提示词版本管理 | 10/10 | 存储3、替换3、旧版2、缺失处理2。文件含v1/v2，先引用v2再v1，实际请求包含不同模板文本；缺模板/版本404、缺变量422。 |
| 可观测性 | 12/15 | Token总量及分类2/5：缺总量D1扣1、分事件输入用量丢失D2扣1、失败响应已有用量丢失D3扣1；延迟4、关联查询3、失败记录3。失败记录确实存在，D3不再按失败记录重复扣。 |
| 统一错误与重试 | 14/15 | 统一错误及状态3/4：格式不支持的上游400被映射502，D4扣1；退避4、上限3、不可重试3、可验证1。实际四次上限，无SDK叠加。 |
| 按模型独立限流 | 10/10 | 独立4、429计3、恢复2、配置1。pro配额1：200→429，flash仍200；真实等待60.1秒后pro200。 |
| 源码、README 与验证脚本 | 10/10 | 源码依赖2、启动3、curl示例2、六功能断言3。Windows启动语法在Linux等价转换；原版37项离线通过，真实脚本六次调用通过，注入空正文能触发脚本失败。 |
| 合计 | 96/100 | 15+15+10+10+12+14+10+10=96；共扣4分，各根因只记一次，不按测试通过率计分。 |

## 环境、启动与固定对象

1. 实际执行 `git clone https://github.com/yuanwenlou/ai-agent-week01-llm-gateway student`，再 `git checkout --detach d9373d87f3f1a0b4961b1b90692ab9726367c1f4`；结束核查学生工作树为空。`source-manifest.txt` 记录提交与文件SHA-256。
2. 使用独立Python venv，`pip install -r requirements.txt` 成功；依赖版本见 `dependencies.txt`，安装输出见 `install.log`。未更改依赖声明。
3. README示例为PowerShell；本orb使用等价Linux环境变量注入、`python -B -m uvicorn gateway:app --host 127.0.0.1 --port 8129`。SQLite使用独立可写路径，未读取学生本机文件。
4. 真实服务由 `amp orb service start cody-grade` 托管。真实调用仅使用继承的个人secret环境中的 `DEEPSEEK_API_KEY`，未写入文件、未输出内容，未请求其他供应商。
5. 受控测试用学生原有 `create_app(transport=httpx.MockTransport(handler))` 测试缝，模拟配置在pytest独立进程内设为虚拟凭据。没有修改适配器、重试或限流业务规则。仅配额通过原有环境变量降低；恢复实等60.1秒。

## 两个模型真实调用与协议

真实映射未替换：`pro` → `deepseek-v4-pro`，官方 `https://api.deepseek.com/responses`；`flash` → `deepseek-flash`，官方 `https://api.deepseek.com/anthropic/v1/messages`。协议依据不只是类名：前者实际构造 `input`、`max_output_tokens`、`reasoning`，JSON约束映射 `text.format`，解析 `output[].content[].output_text` 及 `response.output_text.delta`；后者发送 `messages`、独立 `system`、`max_tokens`、`thinking`，通过提示约束加本地JSON/Schema解析，解析文本块和 `content_block_delta`。源码：`adapters.py:167–283`；独立请求体证据：`independent.log` 的 `A03/F01 gated` 和 `F03/F04`。鉴权方式已源码复核，不归档鉴权头。

教师真实探针使用短提示 `Return only {"ok":true}.`，原版固定输出预算1024 token、关闭思考，未调整业务配置。每条响应及分块接收时间均在 `live-results.jsonl`：

| 模型/模式 | HTTP及结果 | 请求标识 | 输入/输出Token | 总延迟ms / TTFTms |
| --- | --- | --- | --- | --- |
| pro 普通 | 200，正文 `{"ok":true}` | chatcmpl-6e775e4ec9a4481fbe5093f838f96b95 | 11/5 | 1070.806 / null |
| pro 流式 | 200，正文完整，收到DONE | chatcmpl-7b41d6bd0541483c8a8203e948eb49b4 | 11/5 | 1101.506 / 961.320 |
| pro JSON | 200，模型正文可解析 | chatcmpl-cdc8bc4e49a447af8a9ae7fa402ffdf5 | 40/5 | 949.790 / null |
| flash 普通 | 200，正文 `{"ok":true}` | chatcmpl-52b52551dcc9467a862a467ab72151fe | 11/5 | 1182.306 / null |
| flash 流式 | 200，正文完整，收到DONE | chatcmpl-18cbf55018524b458684b088838bbf9b | 11/5 | 1132.996 / 966.304 |
| flash JSON | 200，正文含空白但可解析 | chatcmpl-cfb17460fe4f4ef39c3e1db52a3d1030 | 25/6 | 967.302 / null |

此外原版 `verify_live.py --base-url http://127.0.0.1:8129` 对两个模型各执行普通、带v2模板JSON和流式，共另外6次真实调用，全部成功、`exit=0`，记录见 `student-live.log`。本次共12次真实调用，无失败重试；并非仅凭学生已有截图或passed报告。

## A01–A04 / F01–F12 实测矩阵

统一入口 `POST /v1/chat/completions`；通用受控复现入口为 `STUDENT_DIR=/path/to/student venv/bin/python -B -m pytest -q -s -p no:cacheprovider test_independent.py`。普通配置与各输入在脚本内，日志每条含case、模型、请求/响应、账本或尝试计数。默认完整运行约66秒。

| 编号 | 方式、实际操作与可复现结果 | 证据 / 源码 |
| --- | --- | --- |
| A01 | 实际clone、venv安装、按README等价启动，真实HTTP请求成功 | install.log、dependencies.txt、live-results.jsonl；README |
| A02 | 双模型真实普通请求200、统一choices结果 | live-results.jsonl、student-live.log |
| A03 | 受控捕获路径与JSON请求体，复核实际官方映射；分别解析两协议 | test_protocol_and_gate、test_json_cases；adapters.py:167–283 |
| A04 | unknown返回404 model_not_found，不调用上游；没有静默默认模型 | test_early_failure_has_ledger记录404；原版test_request_errors_do_not_call_upstream也通过；gateway.py:178–182 |
| F01 | 真实双流有分时正文和终态；受控双路由先发UTF-8跨块“门”，必须收到下游正文才放终态，均通过 | test_protocol_and_gate；gateway.py:80–139；adapters.py:81–108 |
| F02 | 双路由发partial后ReadError，错误帧收尾，无DONE/stop，实际一次请求、retries=0、失败入账 | test_interrupted_not_retried；gateway.py:116–132 |
| F03 | 双模型真实json_object合法；受控schema正确/类型错误、合法/悬空本地ref均有明确结果。上游格式不支持400→502为D4 | test_json_cases、test_schema、test_upstream_unsupported_format_is_4xx |
| F04 | 双协议非法、空、截断、状态incomplete但正文合法也明确失败；无修复机制，单次调用后失败，不存在“修复后未校验”路径 | test_json_cases；output_options.py:91–105；adapters.py:190–203,254–257 |
| F05 | 文件持久保存v1/v2；先v2后v1，French变量已替换，两版本实际发送文本不同 | test_templates；prompts.json；output_options.py:21–34 |
| F06 | 缺模板/版本404，缺变量422，无新增上游请求；失败记录含prompt信息 | test_templates；output_options.py:21–29 |
| F07 | 普通、流式、上游失败、本地429、JSON失败可查账，TTFT不被心跳/空文本占用。总量/事件合并/失败用量存在D1–D3 | independent.log与真实账本；call_policy.py:16–58，gateway.py:65–139,220–231 |
| F08 | 双路由受控503、503、成功，共3次；真实等待约0.251、0.501秒，总延迟包含退避；无补丁跳过等待 | test_retry_real_waits[recover-*]；call_policy.py:61–62 |
| F09 | 双路由持续503各4次后停止，间隔约0.251/0.501/1.002秒；401各1次。README声明首次+3重试；httpx无模型SDK隐藏重试 | test_retry_real_waits[exhaust/unauthorized-*]；gateway.py:211–219；原版测试另外覆盖pro流前失败4次 |
| F10 | pro RPM=1，依次pro200/pro429/flash200，429不访问上游 | test_rate_isolation_recovery；call_policy.py:65–79 |
| F11 | 不改时钟，不缩短规则，等待60.1秒后pro恢复200；实际上游顺序pro,flash,pro | 同上，日志F10/F11 |
| F12 | 原版pytest：37 passed；原版真实脚本exit0；用受控空正文调用原版check_model，抛出pro: empty ordinary reply，失败检测有效 | student-tests.log、student-live.log、test_student_script_detects_empty_response |

### 运行汇总与判读

- `python -B -m pytest -q -p no:cacheprovider`（学生目录）：`37 passed in 1.62s`。
- 教师独立脚本：`5 failed, 30 passed in 66.03s`，`exit=1`。其中4项对应D1–D4；第五项为下述不扣分的提前拒绝请求关联建议。保留真实失败，不能描述成全部通过，也不能直接以30/35计算分数。
- 原版脚本的限流用例已覆盖隔离；教师补足真实窗口恢复。原版流式用量fixture在终态重复提供输入统计，未覆盖仅起始事件提供输入的情况；这是D2边界缺口，不另从验证脚本重复扣分。
- 基本正常Token口径正确：Responses缓存/推理为子集；Messages输入11+缓存5+创建1=17，输出7；合计应24，不重复加缓存或推理。不存在将每个累计快照相加的已确认问题。

## 待修复问题与逐项扣分复现

以下命令在证据脚本所在目录执行，先按包内EVIDENCE-README安装固定提交和依赖。`STUDENT_DIR` 指向固定学生clone。每项预期与实际直接写入 `independent.log`，可按case名检索。

### D1：账本没有总Token（可观测性扣1分）

- 触发：普通pro上游已知输入17、输出7，缓存5、推理3为子集。
- 预期：记录输入17、输出7及总量24；不能算成32。
- 实际：`usage`仅输入、输出和分类字段，没有total_tokens或其他总量字段；真实12次账本同样未记录总量。
- 复现：`STUDENT_DIR=/path/to/student venv/bin/python -B -m pytest -q -s test_independent.py -k usage_total_contract`。
- 证据：case `F07 total`，请求 `chatcmpl-e3ccbd5aaf2d481f8df6b8d512a43f0c`；源码 `call_policy.py:16–22,53–58`。
- 范围：仅从Token总量及分类子项扣1，不扣统一响应抽象或验证脚本。

### D2：Messages分事件用量未合并（可观测性扣1分）

- 触发：message_start提供input=11/cache_read=5/cache_creation=1；message_delta仅output=7，最后正常end_turn/message_stop。
- 预期：账本输入17、输出7、缓存5、创建1，不把起始和终态快照累加。
- 实际：流式正文成功且DONE，但input/cached/cache_creation均null，output=7。
- 复现：`STUDENT_DIR=/path/to/student venv/bin/python -B -m pytest -q -s test_independent.py -k messages_usage_split_events`。
- 证据：case `F07 split Messages usage`，请求 `chatcmpl-15adfd1587be4128bc14761970b964b5`；源码 `adapters.py:259–283` 未处理message_start，`gateway.py:97–99`用后续TokenUsage整对象覆盖。
- 限制：这是受控有效Messages事件分布；本次真实DeepSeek终态重复返回完整用量，所以真实流未出现该缺陷。只扣用量解析，不扣SSE可用性。

### D3：失败响应已知用量被丢弃（可观测性扣1分）

- 触发：Responses status=incomplete且正文截断，但响应含input17/output7/cache5/reasoning3；另空正文对照也含明确usage。
- 预期：仍报错，同时保留已经提供的用量，不能把已知误记为未知。
- 实际：HTTP502 upstream_incomplete，状态/错误入账正确，但usage全部null。空正文同因在model_result抛错前未将usage交给调用账本而丢失。
- 复现：`STUDENT_DIR=/path/to/student venv/bin/python -B -m pytest -q -s test_independent.py -k known_usage_on_truncation`；空正文见完整运行的F03/F04日志。
- 证据：case `F07 known failed usage`，请求 `chatcmpl-270ce2fc988e4cb88d4e44871f7b2491`；源码 `adapters.py:190–203,160–164,254–257`、`gateway.py:220`在适配器成功返回后才赋usage。
- 去重：双协议空/截断同属“成功路径才提取/返回用量”，合并扣1；结构化已正确拒绝、不再扣其分数；失败记录存在、不再扣失败记录分。

### D4：上游格式不支持400被映射为502（统一错误扣1分）

- 触发：统一response_format=json_schema，上游受控返回HTTP400及Unsupported response format。
- 预期：统一错误对象、明确4xx、不可重试。
- 实际：统一对象存在，只有一次上游请求，但HTTP502、code=upstream_error/type=server_error，丢失请求能力错误语义。
- 复现：`STUDENT_DIR=/path/to/student venv/bin/python -B -m pytest -q -s test_independent.py -k upstream_unsupported_format_is_4xx`。
- 证据：case `F03 unsupported format`，请求 `chatcmpl-91f416302b4148f782207c697df9890e`；源码 `adapters.py:46–53`把非429 HTTP错误统一映射502。
- 去重：只从统一错误扣1，不再扣结构化、不把401同样502重复计分，也不扣已经正确的一次请求策略。真实DeepSeek本轮未产生该错误，不声称真实上游拒绝过schema。

## 不扣分建议、未验证项目与限制

- 提前拒绝unknown模型正确返回404、零上游请求，但没有X-Request-ID、SQLite零条目；独立 `test_early_failure_has_ledger` 因更强的“每个入口请求也可追踪”断言失败。此请求尚未进行模型调用，评分对边界从宽，仅建议扩大审计范围，不另外扣分。缺密钥、Pydantic入参拒绝等同样可能在账本建立前返回，未逐项扩展判缺陷。
- 无真实凭据或网络阻塞项：本次个人凭据可用，两个真实模型六种基本组合均验证成功。没有以模拟替代真实通过。
- 真实json_schema、长推理、真实持续故障、真实断流、真实限流耗尽、多worker/分布式部署未验证；其中schema本地行为与异常路径使用受控测试，不声称官方全部格式均支持。
- 未使用其他供应商，无外部模型替换或别名重映射；不是只读网页快照。单进程内存限流和文件模板为允许实现，不因未用Redis等扣分。
- 修复JSON不属于必要手段：学生选择拒绝而不修复，明确失败满足要求。
- 成绩不按37/37或30/35换算，不将同因多输入重复扣分。

## 补交要求与复验通过条件

- 必须修复：D1总量、D2分事件用量合并、D3失败已知用量留存、D4格式不支持错误状态映射；不要求更换框架或增加基础设施。
- 必须补充：对应四种回归输入，保留双协议门控流、断流无重复、四次尝试上限、独立限流及窗口恢复断言。
- 复验通过条件：四项复现达到上述预期；双模型普通/SSE/JSON仍能真实调用成功；输入输出总量和缓存/推理分类不重复累计，失败记录与正文/错误状态一致。
- 交付检查：反馈三节条数与字数、八项合计、证据包内容/秘密扫描及学生源码未改校验见包内 `audit.txt`；评测服务结束后停止。不含密钥文件、环境转储或鉴权头。
