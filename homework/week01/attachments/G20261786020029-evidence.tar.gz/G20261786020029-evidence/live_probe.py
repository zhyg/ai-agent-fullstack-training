"""Only gateway calls; gateway uses inherited DEEPSEEK_API_KEY and official host."""
import json
import time
import httpx

with httpx.Client(base_url="http://127.0.0.1:8129", timeout=140) as client:
    for model in ("pro", "flash"):
        for kind in ("ordinary", "stream", "json"):
            payload = {"model": model, "messages": [{"role": "user", "content": 'Return only {"ok":true}.'}]}
            if kind == "stream":
                payload["stream"] = True
            if kind == "json":
                payload["response_format"] = {"type": "json_object"}
            start = time.monotonic()
            try:
                with client.stream("POST", "/v1/chat/completions", json=payload) as r:
                    chunks = [{"ms": round((time.monotonic()-start)*1000, 2), "line": line}
                              for line in r.iter_lines() if line]
                    rid = r.headers.get("x-request-id")
                    record = client.get(f"/v1/usage/{rid}").json() if rid else None
                    print(json.dumps({"model": model, "kind": kind, "status": r.status_code,
                                      "request_id": rid, "chunks": chunks, "ledger": record,
                                      "elapsed_ms": round((time.monotonic()-start)*1000, 2)}, ensure_ascii=False), flush=True)
            except Exception as exc:
                print(json.dumps({"model": model, "kind": kind, "error": type(exc).__name__,
                                  "elapsed_ms": round((time.monotonic()-start)*1000, 2)}), flush=True)
