"""统一配置读取接口。

配置文件统一放在项目根目录 config/ 下：
- llm.yaml     大模型供应商、协议、超时、别名与降级
- runtime.yaml 重试、缓存、指标、埋点
- app.yaml     服务端口、网关鉴权、管理端点开关
- prompts.yaml Prompt 存储、审计、系统提示词与模板渲染限制

通用能力：
- ${VAR} / ${VAR:-默认值} 递归展开；
- 按文件 mtime/size 检测变更自动热更新；
- 多环境切换：GATEWAY_ENV=dev 时优先读取 <name>.dev.yaml（LLM_ENV 优先用于 llm.yaml）；
- 显式文件覆盖：LLM_CONFIG_FILE / GATEWAY_RUNTIME_CONFIG / APP_CONFIG_FILE / PROMPT_CONFIG_FILE。
"""

from __future__ import annotations

import os
import re
import threading
from pathlib import Path
from typing import Any

import yaml

_ROOT = Path(__file__).resolve().parent.parent
_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")

_lock = threading.Lock()
_cache: dict[str, tuple[tuple[str, int, int], dict[str, Any]]] = {}


def project_root() -> Path:
    """项目根目录，供相对路径类配置使用。"""

    return _ROOT


def resolve_config_path(
    path: str | Path | None = None,
    *,
    filename: str = "llm.yaml",
    explicit_var: str = "LLM_CONFIG_FILE",
    env_var: str = "LLM_ENV",
) -> Path:
    """解析当前生效的配置文件路径。"""

    if path is not None:
        return Path(path)
    explicit = os.getenv(explicit_var, "").strip()
    if explicit:
        return Path(explicit)
    base = _ROOT / "config" / filename
    env = os.getenv(env_var, "").strip() or os.getenv("GATEWAY_ENV", "").strip()
    if env:
        candidate = base.with_name(f"{base.stem}.{env}{base.suffix}")
        if candidate.is_file():
            return candidate
    return base


def _load(path: str | Path | None, **options: str) -> dict[str, Any]:
    target = resolve_config_path(path, **options)  # type: ignore[arg-type]
    try:
        stat = target.stat()
    except OSError as exc:
        raise FileNotFoundError(f"config file not found: {target}") from exc

    key = (str(target), stat.st_mtime_ns, stat.st_size)
    with _lock:
        cached = _cache.get(str(target))
        if cached is None or cached[0] != key:
            raw = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
            data = _expand(raw)
            _cache[str(target)] = (key, data)
            return data
        return cached[1]


def get_llm_config(path: str | Path | None = None) -> dict[str, Any]:
    return _load(path, filename="llm.yaml", explicit_var="LLM_CONFIG_FILE", env_var="LLM_ENV")


def get_runtime_config(path: str | Path | None = None) -> dict[str, Any]:
    return _load(
        path,
        filename="runtime.yaml",
        explicit_var="GATEWAY_RUNTIME_CONFIG",
        env_var="GATEWAY_ENV",
    )


def get_app_config(path: str | Path | None = None) -> dict[str, Any]:
    return _load(path, filename="app.yaml", explicit_var="APP_CONFIG_FILE", env_var="GATEWAY_ENV")


def get_prompt_config(path: str | Path | None = None) -> dict[str, Any]:
    return _load(path, filename="prompts.yaml", explicit_var="PROMPT_CONFIG_FILE", env_var="GATEWAY_ENV")


def reset_llm_config() -> None:
    """清空全部配置缓存，用于测试或运维手动刷新。"""

    with _lock:
        _cache.clear()


def _expand(value: Any) -> Any:
    """递归展开 ${VAR} 与 ${VAR:-默认值}，支持字典、列表与字符串。"""

    if isinstance(value, dict):
        return {key: _expand(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_expand(item) for item in value]
    if isinstance(value, str):
        return _ENV_PATTERN.sub(
            lambda match: os.getenv(match.group(1), match.group(2) or ""),
            value,
        )
    return value
