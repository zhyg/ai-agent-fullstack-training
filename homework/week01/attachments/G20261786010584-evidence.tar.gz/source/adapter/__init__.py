"""大模型模态适配器层。

统一契约见 adapter/base.py，注册表与调用入口见 adapter/registry.py，
接口文档与使用示例见 adapter/README.md。
"""

from adapter.base import AdapterState, Modality, ModalityAdapter
from adapter.chat import ChatAdapter, stream_sse
from error.adapter import (
    AdapterError,
    AdapterLifecycleError,
    AdapterNotRegisteredError,
    AdapterParamError,
)
from adapter.registry import (
    AdapterRegistry,
    adapter_names,
    get_adapter,
    get_registry,
    register_adapter,
    reset_adapters,
    shutdown_adapters,
    startup_adapters,
    unregister_adapter,
)

__all__ = [
    "Modality",
    "ModalityAdapter",
    "AdapterState",
    "ChatAdapter",
    "stream_sse",
    "AdapterError",
    "AdapterParamError",
    "AdapterNotRegisteredError",
    "AdapterLifecycleError",
    "AdapterRegistry",
    "get_adapter",
    "get_registry",
    "register_adapter",
    "unregister_adapter",
    "adapter_names",
    "startup_adapters",
    "shutdown_adapters",
    "reset_adapters",
]
