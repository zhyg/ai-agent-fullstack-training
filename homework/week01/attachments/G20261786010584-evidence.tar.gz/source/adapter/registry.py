"""模态适配器注册表：统一的存储容器与调用入口。

业务层只依赖 `get_adapter(modality)`，无需感知具体适配器实现；
新增模态或替换实现只需注册，不改调用方。
"""

from __future__ import annotations

from typing import Any

from adapter.base import Modality, ModalityAdapter
from adapter.chat import ChatAdapter
from error.adapter import AdapterError, AdapterNotRegisteredError


class AdapterRegistry:
    """线程内共享的适配器容器；支持注册、替换、注销与批量生命周期管理。"""

    def __init__(self, adapters: dict[Modality, ModalityAdapter] | None = None) -> None:
        self._adapters: dict[Modality, ModalityAdapter] = dict(adapters or {})

    def register(
        self,
        adapter: ModalityAdapter,
        *,
        modality: Modality | None = None,
        replace: bool = False,
    ) -> ModalityAdapter:
        key = modality or adapter.modality
        if not replace and key in self._adapters:
            raise AdapterError(f"adapter already registered for modality: {_label(key)}")
        self._adapters[key] = adapter
        return adapter

    def unregister(self, modality: Modality) -> ModalityAdapter | None:
        return self._adapters.pop(modality, None)

    def get(self, modality: Modality) -> ModalityAdapter:
        adapter = self._adapters.get(modality)
        if adapter is None:
            raise AdapterNotRegisteredError(f"no adapter registered for modality: {_label(modality)}")
        return adapter

    def names(self) -> list[str]:
        return sorted(self._adapters)

    def all(self) -> list[ModalityAdapter]:
        return list(self._adapters.values())

    async def startup_all(self) -> None:
        """按注册顺序启动全部适配器；重复调用安全。"""

        for adapter in self.all():
            await adapter.startup()

    async def shutdown_all(self) -> None:
        """逆序关闭全部适配器；重复调用安全。"""

        for adapter in reversed(self.all()):
            await adapter.shutdown()

    def reset(self, adapters: dict[Modality, ModalityAdapter] | None = None) -> None:
        self._adapters = dict(adapters or {})


def _default_registry() -> AdapterRegistry:
    return AdapterRegistry({Modality.CHAT: ChatAdapter()})


def _label(modality: Any) -> str:
    return str(getattr(modality, "value", modality))


_registry = _default_registry()


def get_adapter(modality: Modality) -> ModalityAdapter:
    """统一调用入口：按模态取用适配器。"""

    return _registry.get(modality)


def register_adapter(
    adapter: ModalityAdapter,
    *,
    modality: Modality | None = None,
    replace: bool = False,
) -> ModalityAdapter:
    return _registry.register(adapter, modality=modality, replace=replace)


def unregister_adapter(modality: Modality) -> ModalityAdapter | None:
    return _registry.unregister(modality)


def adapter_names() -> list[str]:
    return _registry.names()


async def startup_adapters() -> None:
    await _registry.startup_all()


async def shutdown_adapters() -> None:
    await _registry.shutdown_all()


def reset_adapters() -> None:
    """恢复默认注册表，供测试或热替换后重置使用。"""

    global _registry
    _registry = _default_registry()


def get_registry() -> AdapterRegistry:
    return _registry
