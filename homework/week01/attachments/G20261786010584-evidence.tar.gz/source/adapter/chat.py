"""对话模态适配器：按供应商协议规则发起请求并改写响应。

实现细节与抽离前 gateway/modality/chat.py 完全一致：
- 非流式：协议格式化请求、归一化错误与响应；
- 流式：透传上游 SSE 并交给协议转换器改写；
- 用完即关闭上游响应，避免连接泄漏。
"""

from __future__ import annotations

from typing import Any, AsyncIterator

import httpx

from adapter.base import Modality, ModalityAdapter
from gateway.transport import post_json, send_stream
from provider import Provider, get_protocol
from provider.protocols.base import StreamConverter


async def stream_sse(upstream: httpx.Response, converter: StreamConverter) -> AsyncIterator[str]:
    """逐行读取上游 SSE，交给协议转换器改写为对外 SSE。"""

    try:
        async for line in upstream.aiter_lines():
            if not line.startswith("data:"):
                continue
            raw = line[5:].strip()
            for chunk in converter.feed(raw):
                yield chunk
        for chunk in converter.close():
            yield chunk
    finally:
        await upstream.aclose()


async def _normalize_error(adapter: Any, upstream: httpx.Response, *, read: bool) -> httpx.Response:
    content = await upstream.aread() if read else upstream.content
    await upstream.aclose()
    status, error = adapter.format_error(content, upstream.status_code)
    return httpx.Response(status, json=error)


class ChatAdapter(ModalityAdapter):
    """对话（chat）模态适配器。"""

    name = "chat"
    modality = Modality.CHAT

    async def _complete(
        self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]
    ) -> httpx.Response:
        adapter = get_protocol(provider.protocol)
        upstream = await post_json(
            client,
            provider,
            adapter.endpoint,
            adapter.format_request(payload, provider),
            headers=adapter.headers(provider),
        )
        if upstream.status_code >= 400:
            return await _normalize_error(adapter, upstream, read=False)
        try:
            data = upstream.json()
        except ValueError:
            return upstream
        return httpx.Response(upstream.status_code, json=adapter.format_response(data))

    async def _open_stream(
        self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]
    ) -> httpx.Response:
        adapter = get_protocol(provider.protocol)
        upstream = await send_stream(
            client,
            provider,
            adapter.endpoint,
            adapter.format_request(payload, provider),
            headers=adapter.headers(provider),
        )
        if upstream.status_code >= 400:
            return await _normalize_error(adapter, upstream, read=True)
        return upstream

    def _transform_stream(
        self, upstream: httpx.Response, client_model: str, provider: Provider
    ) -> AsyncIterator[str]:
        converter = get_protocol(provider.protocol).stream_converter(client_model)
        return stream_sse(upstream, converter)
