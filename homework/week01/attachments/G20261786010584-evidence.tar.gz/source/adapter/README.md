# 大模型模态适配器（adapter）

本目录收拢所有与大模型交互的模态实现：对话请求、流式开启、SSE 改写、错误归一化。
业务层只通过 `adapter.registry.get_adapter(modality)` 获取适配器，不直接依赖任何具体实现。

```
adapter/
├── __init__.py     # 对外统一导出
├── base.py         # 标准契约 ModalityAdapter + 生命周期/校验/错误处理
├── chat.py         # 对话模态实现 ChatAdapter
├── registry.py     # 统一存储容器 AdapterRegistry 与全局入口
├── errors.py       # 统一异常类型
└── README.md       # 本文档
```

## 1. 标准契约

所有适配器继承 `adapter.base.ModalityAdapter`，实现三个受保护方法：

| 方法 | 说明 |
| --- | --- |
| `_complete(client, provider, payload)` | 非流式请求上游，返回归一化后的 `httpx.Response` |
| `_open_stream(client, provider, payload)` | 发起流式请求，返回未读取响应体的上游 `httpx.Response` |
| `_transform_stream(upstream, client_model, provider)` | 返回改写后的 SSE 异步迭代器 |

对外只调用基类的三个公开方法（内部完成校验、生命周期与错误记录）：

### `async complete(client, provider, payload) -> httpx.Response`

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `client` | `httpx.AsyncClient` | 复用的 HTTP 客户端 |
| `provider` | `Provider` | 已解析的供应商（协议、地址、密钥、options） |
| `payload` | `dict` | OpenAI 风格请求体，至少包含 `model` 与 `messages` |

返回：已按对外协议归一化的响应；上游错误会被转换为统一的错误结构。
抛出：入参非法 `AdapterParamError`；传输/协议异常原样抛出（仅追加日志，不改变类型与内容）。

### `async open_stream(client, provider, payload) -> httpx.Response`

参数同 `complete`。返回尚未读取响应体的上游响应，供流式改写使用。
上游 `>=400` 时返回错误归一化后的响应，调用方无需重复判断。

### `transform_stream(upstream, client_model, provider) -> AsyncIterator[str]`

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `upstream` | `httpx.Response` | `open_stream` 返回的上游响应 |
| `client_model` | `str` | 对外暴露的模型名，流式块中的 `model` 会被改写为该值 |
| `provider` | `Provider` | 供应商，用于选择协议转换器 |

返回：`data: ...\n\n` 形式的 SSE 文本异步迭代器；迭代结束会关闭上游连接。

### 适配器属性

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `name` | `str` | 适配器名称，如 `chat` |
| `modality` | `Modality` | 绑定的模态枚举 |
| `state` | `AdapterState` | `created` / `started` / `stopped` |

### 生命周期

| 方法 | 说明 |
| --- | --- |
| `async startup()` | 启动适配器，幂等；子类可覆写 `_on_startup()` 申请资源 |
| `async shutdown()` | 释放资源，幂等；子类可覆写 `_on_shutdown()` |

应用启动/关闭时由 `main.py` 统一调用 `startup_adapters()` / `shutdown_adapters()`。
适配器本身无状态时可不在调用前显式启动，现有业务调用行为不受影响。

## 2. 统一存储容器

`adapter.registry.AdapterRegistry` 是模态适配器的统一容器：

| 方法 | 说明 |
| --- | --- |
| `register(adapter, modality=None, replace=False)` | 注册适配器；重复注册抛 `AdapterError`，`replace=True` 可替换 |
| `unregister(modality)` | 注销并返回原适配器 |
| `get(modality)` | 取用适配器；未注册抛 `AdapterNotRegisteredError` |
| `names()` / `all()` | 已注册模态名 / 适配器列表 |
| `async startup_all()` / `async shutdown_all()` | 批量生命周期管理 |
| `reset(adapters=None)` | 重置容器内容 |

全局入口：

| 函数 | 说明 |
| --- | --- |
| `get_adapter(modality)` | **业务唯一调用入口** |
| `register_adapter(adapter, modality=None, replace=False)` | 注册到全局容器 |
| `unregister_adapter(modality)` | 从全局容器注销 |
| `adapter_names()` | 已注册模态列表 |
| `async startup_adapters()` / `async shutdown_adapters()` | 全局生命周期 |
| `reset_adapters()` | 恢复默认注册表（测试/热替换） |
| `get_registry()` | 获取全局容器实例 |

## 3. 统一异常

| 异常 | 基类 | 场景 |
| --- | --- | --- |
| `AdapterError` | `GatewayError` | 适配器层通用错误（定义在 `error/adapter.py`） |
| `AdapterParamError` | `AdapterError, ValueError` | 入参类型/结构非法 |
| `AdapterNotRegisteredError` | `AdapterError, LookupError` | 模态未注册适配器 |
| `AdapterLifecycleError` | `AdapterError, RuntimeError` | 生命周期状态异常 |

`complete` / `open_stream` / `transform_stream` 捕获异常后会调用 `_handle_error()` 统一记录
（适配器名、动作、异常类型与消息），随后**原样抛出**，调用方感知与重构前完全一致。

## 4. 使用示例

### 4.1 业务侧标准调用（与原有 `get_handler` 行为一致）

```python
import httpx

from adapter import Modality, get_adapter
from provider import Provider

provider = Provider(
    name="openai",
    base_url="https://api.openai.com/v1",
    api_key="sk-...",
    protocol="openai",
)
payload = {
    "model": "gpt-4o-mini",
    "messages": [{"role": "user", "content": "hello"}],
}

async with httpx.AsyncClient() as client:
    adapter = get_adapter(Modality.CHAT)
    response = await adapter.complete(client, provider, payload)
    data = response.json()
```

### 4.2 流式调用

```python
adapter = get_adapter(Modality.CHAT)
upstream = await adapter.open_stream(client, provider, payload)
async for chunk in adapter.transform_stream(upstream, client_model="gpt-4o-mini", provider=provider):
    yield chunk  # 直接写入 StreamingResponse
```

### 4.3 新增模态适配器（无需改动业务调用方）

```python
import httpx
from typing import Any, AsyncIterator

from adapter import Modality, ModalityAdapter, register_adapter
from provider import Provider


class EmbeddingAdapter(ModalityAdapter):
    name = "embedding"
    modality = Modality("embedding")  # 需先在 Modality 枚举中扩展

    async def _complete(self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]) -> httpx.Response:
        return await client.post(f"{provider.base_url}/embeddings", json=payload)

    async def _open_stream(self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]) -> httpx.Response:
        raise NotImplementedError("embedding 不支持流式")

    def _transform_stream(self, upstream: httpx.Response, client_model: str, provider: Provider) -> AsyncIterator[str]:
        async def _empty():
            if False:
                yield ""

        return _empty()


register_adapter(EmbeddingAdapter())
```

### 4.4 FastAPI 生命周期接入

```python
from contextlib import asynccontextmanager

from fastapi import FastAPI

from adapter import shutdown_adapters, startup_adapters


@asynccontextmanager
async def lifespan(app: FastAPI):
    await startup_adapters()
    try:
        yield
    finally:
        await shutdown_adapters()
```

### 4.5 测试中替换适配器

```python
from adapter import AdapterRegistry, Modality

# fake_adapter 为测试桩，需实现 _complete / _open_stream / _transform_stream
registry = AdapterRegistry({Modality.CHAT: fake_adapter})
assert registry.get(Modality.CHAT) is fake_adapter
```

需要影响全局入口时使用 `register_adapter(fake_adapter, replace=True)`，测试结束后调用
`reset_adapters()` 恢复默认 `ChatAdapter`。

## 5. 兼容性说明

- `gateway.modality` 保留为兼容门面：`Modality`、`ModalityHandler`、`get_handler()` 仍可用，
  内部全部委托到 `adapter`，旧代码无需修改。
- 抽离前后 `complete` / `open_stream` / `transform_stream` 的入参、返回值、异常类型与流式输出保持一致。
- 上游请求头、协议转换、错误映射仍由 `provider/protocols` 负责，适配器只做模态编排。
