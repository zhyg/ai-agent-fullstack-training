"""模态适配器标准契约。

所有与大模型交互的模态实现都必须继承 ModalityAdapter，并实现三个受保护方法：
`_complete`、`_open_stream`、`_transform_stream`。
对外只暴露 `complete` / `open_stream` / `transform_stream`，由基类统一完成：
- 入参合法性校验（validate / validate_stream）
- 全局异常捕获与记录（保持原异常类型与内容不变，仅追加日志）
- 生命周期管理（startup / shutdown，幂等）
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Any, AsyncIterator

import httpx

from error.adapter import AdapterParamError
from provider import Provider

logger = logging.getLogger(__name__)


class Modality(StrEnum):
    """模态类型；新增模态时在此扩展并在注册表中注册适配器。"""

    CHAT = "chat"


class AdapterState(StrEnum):
    CREATED = "created"
    STARTED = "started"
    STOPPED = "stopped"


class ModalityAdapter(ABC):
    """模态适配器抽象基类：屏蔽不同模态与上游协议的实现差异。"""

    name: str
    modality: Modality

    def __init__(self) -> None:
        self._state = AdapterState.CREATED

    # --------------------------------------------------------------- lifecycle

    @property
    def state(self) -> AdapterState:
        return self._state

    async def startup(self) -> None:
        """启动适配器；重复调用安全。"""

        if self._state is AdapterState.STARTED:
            return
        await self._on_startup()
        self._state = AdapterState.STARTED

    async def shutdown(self) -> None:
        """释放适配器资源；重复调用安全。"""

        if self._state is AdapterState.STOPPED:
            return
        await self._on_shutdown()
        self._state = AdapterState.STOPPED

    async def _on_startup(self) -> None:
        """子类可覆写：申请连接池、加载规则等。"""

    async def _on_shutdown(self) -> None:
        """子类可覆写：释放连接池、清理缓存等。"""

    # ------------------------------------------------------------ public API

    async def complete(
        self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]
    ) -> httpx.Response:
        """非流式请求上游，返回已按对外协议归一化的响应。"""

        self.validate(provider, payload)
        try:
            return await self._complete(client, provider, payload)
        except Exception as exc:  # noqa: BLE001 - 记录后原样抛出，行为不变
            self._handle_error("complete", exc)
            raise

    async def open_stream(
        self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]
    ) -> httpx.Response:
        """发起流式请求，返回尚未读取响应体的上游响应。"""

        self.validate(provider, payload)
        try:
            return await self._open_stream(client, provider, payload)
        except Exception as exc:  # noqa: BLE001
            self._handle_error("open_stream", exc)
            raise

    def transform_stream(
        self, upstream: httpx.Response, client_model: str, provider: Provider
    ) -> AsyncIterator[str]:
        """把上游流式响应改写为对外 SSE 文本序列。"""

        self.validate_stream(upstream, client_model, provider)
        try:
            return self._transform_stream(upstream, client_model, provider)
        except Exception as exc:  # noqa: BLE001
            self._handle_error("transform_stream", exc)
            raise

    # ------------------------------------------------------------- validation

    def validate(self, provider: Provider, payload: dict[str, Any]) -> None:
        """统一入参校验；只拦明显非法值，不改变既有合法调用。"""

        if not isinstance(provider, Provider):
            raise AdapterParamError(f"{self.name}: provider must be a Provider instance")
        if not isinstance(payload, dict):
            raise AdapterParamError(f"{self.name}: payload must be a dict")
        model = payload.get("model")
        if model is not None and not isinstance(model, str):
            raise AdapterParamError(f"{self.name}: payload['model'] must be a string")
        messages = payload.get("messages")
        if messages is not None and not isinstance(messages, list):
            raise AdapterParamError(f"{self.name}: payload['messages'] must be a list")

    def validate_stream(
        self, upstream: httpx.Response, client_model: str, provider: Provider
    ) -> None:
        if not isinstance(upstream, httpx.Response):
            raise AdapterParamError(f"{self.name}: upstream must be an httpx.Response")
        if not isinstance(client_model, str):
            raise AdapterParamError(f"{self.name}: client_model must be a string")
        if not isinstance(provider, Provider):
            raise AdapterParamError(f"{self.name}: provider must be a Provider instance")

    # ----------------------------------------------------------- error handle

    def _handle_error(self, action: str, exc: Exception) -> None:
        """全局错误记录点；不吞异常，保证调用方感知与重构前一致。"""

        logger.error(
            "adapter %s failed during %s: %s: %s",
            self.name,
            action,
            type(exc).__name__,
            exc,
            exc_info=exc,
        )

    # ------------------------------------------------------------- abstracts

    @abstractmethod
    async def _complete(
        self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]
    ) -> httpx.Response: ...

    @abstractmethod
    async def _open_stream(
        self, client: httpx.AsyncClient, provider: Provider, payload: dict[str, Any]
    ) -> httpx.Response: ...

    @abstractmethod
    def _transform_stream(
        self, upstream: httpx.Response, client_model: str, provider: Provider
    ) -> AsyncIterator[str]: ...
