"""协议注册表：按配置里的 protocol 名称动态取用适配器。"""

from __future__ import annotations

from error import messages
from error.provider import UnknownProtocolError
from provider.protocols.anthropic import AnthropicProtocol
from provider.protocols.base import ProtocolAdapter
from provider.protocols.openai import OpenAIProtocol

_ADAPTERS: dict[str, ProtocolAdapter] = {
    adapter.name: adapter for adapter in (OpenAIProtocol(), AnthropicProtocol())
}

DEFAULT_PROTOCOL = "openai"


def protocol_names() -> list[str]:
    return sorted(_ADAPTERS)


def get_protocol(name: str | None) -> ProtocolAdapter:
    key = (name or DEFAULT_PROTOCOL).strip().lower()
    adapter = _ADAPTERS.get(key)
    if adapter is None:
        raise UnknownProtocolError(
            messages.UNKNOWN_PROTOCOL.format(protocol=name, supported=", ".join(protocol_names()))
        )
    return adapter
