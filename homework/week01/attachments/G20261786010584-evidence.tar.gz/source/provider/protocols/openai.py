"""OpenAI 协议规则：请求体基本透传，SSE 仅改写 model 字段。"""

from __future__ import annotations

import json
from typing import Any, Mapping

from error.upstream import extract_error
from provider.base import Provider
from provider.protocols.base import ProtocolAdapter, StreamConverter


class OpenAIStreamConverter:
    def __init__(self, client_model: str) -> None:
        self.client_model = client_model

    def feed(self, data: str) -> list[str]:
        if not data:
            return [f"data: {data or '[DONE]'}\n\n"]
        if data == "[DONE]":
            return ["data: [DONE]\n\n"]
        try:
            chunk = json.loads(data)
        except json.JSONDecodeError:
            return [f"data: {data}\n\n"]
        chunk["model"] = self.client_model
        return [f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"]

    def close(self) -> list[str]:
        return []


class OpenAIProtocol(ProtocolAdapter):
    name = "openai"
    endpoint = "/chat/completions"

    def headers(self, provider: Provider) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if provider.api_key:
            headers["Authorization"] = f"Bearer {provider.api_key}"
        return headers

    def format_request(self, payload: Mapping[str, Any], provider: Provider) -> dict[str, Any]:
        return dict(payload)

    def format_response(self, data: dict[str, Any], client_model: str | None = None) -> dict[str, Any]:
        return data

    def format_error(self, content: bytes, status_code: int) -> tuple[int, dict[str, Any]]:
        return status_code, extract_error(content, status_code)

    def stream_converter(self, client_model: str) -> StreamConverter:
        return OpenAIStreamConverter(client_model)
