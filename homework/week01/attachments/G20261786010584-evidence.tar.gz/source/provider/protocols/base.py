"""协议适配抽象：把网关统一的 OpenAI 风格请求/响应，与上游各家协议互相转换。

依赖方向固定为 gateway → provider，因此本模块不得反向引用 gateway 的任何内容。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Mapping, Protocol

from provider.base import Provider


class StreamConverter(Protocol):
    """把上游单条 SSE data 转成若干条对外 SSE 文本。

    feed 为纯函数式转换，便于单测；close 用于补齐收尾事件。
    """

    def feed(self, data: str) -> list[str]: ...

    def close(self) -> list[str]: ...


class ProtocolAdapter(ABC):
    """协议规则：请求格式化、响应解析、错误映射、流式转换。"""

    name: str
    endpoint: str

    @abstractmethod
    def headers(self, provider: Provider) -> dict[str, str]:
        """构造该协议要求的上游请求头。"""

    @abstractmethod
    def format_request(self, payload: Mapping[str, Any], provider: Provider) -> dict[str, Any]:
        """把统一请求体转换为上游协议请求体。"""

    def format_response(self, data: dict[str, Any], client_model: str | None = None) -> dict[str, Any]:
        """把上游响应转换为 OpenAI 风格响应；默认原样返回。"""
        return data

    @abstractmethod
    def format_error(self, content: bytes, status_code: int) -> tuple[int, dict[str, Any]]:
        """把上游错误体转换为 (对外状态码, OpenAI 风格错误结构)。"""

    @abstractmethod
    def stream_converter(self, client_model: str) -> StreamConverter:
        """创建流式转换器。"""
