"""协议规则包：OpenAI / Anthropic 等上游协议适配。"""

from provider.protocols.base import ProtocolAdapter, StreamConverter
from provider.protocols.registry import DEFAULT_PROTOCOL, get_protocol, protocol_names

__all__ = ["ProtocolAdapter", "StreamConverter", "DEFAULT_PROTOCOL", "get_protocol", "protocol_names"]
