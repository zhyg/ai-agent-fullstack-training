"""Anthropic Messages API 协议规则。

对外仍使用 OpenAI 风格请求/响应，本模块负责：
- 请求参数格式化：system 抽取、tool_calls/tool 消息转换、参数白名单与默认值；
- 响应解析：content blocks → message.content / tool_calls，stop_reason → finish_reason；
- 错误码映射：Anthropic error.type → HTTP 状态码与 OpenAI 风格错误结构；
- 流式响应：Anthropic 事件流 → OpenAI chat.completion.chunk。
"""

from __future__ import annotations

import json
import time
import uuid
from typing import Any, Iterable, Mapping

from provider.base import Provider
from provider.protocols.base import ProtocolAdapter, StreamConverter

DEFAULT_ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_MAX_TOKENS = 1024

# Anthropic stop_reason -> OpenAI finish_reason
_STOP_REASON_MAP = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "refusal": "content_filter",
    "pause_turn": "stop",
}

# Anthropic error.type -> 对外 HTTP 状态码
_ERROR_STATUS_MAP = {
    "invalid_request_error": 400,
    "authentication_error": 401,
    "permission_error": 403,
    "not_found_error": 404,
    "request_too_large": 413,
    "rate_limit_error": 429,
    "api_error": 500,
    "overloaded_error": 503,
    "timeout_error": 504,
}


def _json_or_none(content: bytes) -> Any:
    try:
        return json.loads(content)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


def _flatten_text(content: Any) -> str | None:
    """把 OpenAI content（str 或 parts 列表）压平成纯文本。"""

    if content is None:
        return None
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        texts = []
        for part in content:
            if isinstance(part, str):
                texts.append(part)
            elif isinstance(part, dict) and part.get("type") == "text":
                texts.append(str(part.get("text") or ""))
        return "\n\n".join(text for text in texts if text) or None
    return str(content)


def _parse_arguments(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


def _image_block(part: Mapping[str, Any]) -> dict[str, Any] | None:
    source = part.get("image_url")
    url = source.get("url") if isinstance(source, dict) else source
    if not isinstance(url, str) or not url:
        return None
    if url.startswith("data:"):
        header, _, data = url.partition(",")
        media_type = header[5:].split(";", 1)[0] or "image/png"
        return {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": data}}
    return {"type": "image", "source": {"type": "url", "url": url}}


def _user_blocks(content: Any) -> list[dict[str, Any]]:
    """OpenAI user content → Anthropic content blocks。"""

    if content is None:
        return []
    if isinstance(content, str):
        return [{"type": "text", "text": content}] if content else []
    if not isinstance(content, list):
        return [{"type": "text", "text": str(content)}]

    blocks: list[dict[str, Any]] = []
    for part in content:
        if isinstance(part, str):
            blocks.append({"type": "text", "text": part})
            continue
        if not isinstance(part, dict):
            continue
        part_type = part.get("type")
        if part_type == "text":
            blocks.append({"type": "text", "text": str(part.get("text") or "")})
        elif part_type == "image_url":
            block = _image_block(part)
            if block is not None:
                blocks.append(block)
        elif part_type in {"image", "document", "tool_result", "tool_use"}:
            blocks.append(dict(part))
    return blocks


def _tool_result_content(content: Any) -> Any:
    if isinstance(content, str) or content is None:
        return content or ""
    if isinstance(content, list):
        return _user_blocks(content) or ""
    return str(content)


def _anthropic_tools(tools: Iterable[Any]) -> list[dict[str, Any]]:
    converted: list[dict[str, Any]] = []
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        if "input_schema" in tool:  # 已是 Anthropic 原生格式
            converted.append(dict(tool))
            continue
        function = tool.get("function")
        if not isinstance(function, dict):
            continue
        schema = function.get("parameters")
        converted.append(
            {
                "name": function.get("name") or "",
                "description": function.get("description") or "",
                "input_schema": schema if isinstance(schema, dict) else {"type": "object", "properties": {}},
            }
        )
    return converted


def _anthropic_tool_choice(choice: Any) -> dict[str, Any] | None:
    if isinstance(choice, str):
        if choice in {"auto", "any", "none"}:
            return {"type": choice}
        return None
    if isinstance(choice, dict) and choice.get("type") == "function":
        function = choice.get("function") or {}
        name = function.get("name")
        return {"type": "tool", "name": name} if name else None
    return None


def _finish_reason(stop_reason: str | None) -> str:
    return _STOP_REASON_MAP.get(stop_reason or "", "stop")


def _usage(prompt_tokens: int | None, completion_tokens: int | None) -> dict[str, int] | None:
    if prompt_tokens is None and completion_tokens is None:
        return None
    prompt = int(prompt_tokens or 0)
    completion = int(completion_tokens or 0)
    return {"prompt_tokens": prompt, "completion_tokens": completion, "total_tokens": prompt + completion}


def _chunk(
    chunk_id: str,
    model: str,
    created: int,
    delta: dict[str, Any],
    finish_reason: str | None = None,
    usage: dict[str, int] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "id": chunk_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}],
    }
    if usage is not None:
        payload["usage"] = usage
    return payload


def _sse(payload: dict[str, Any]) -> str:
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


class AnthropicStreamConverter:
    """Anthropic 事件流 → OpenAI chunk；有状态但每个事件转换是纯函数。"""

    def __init__(self, client_model: str) -> None:
        self.client_model = client_model
        self._id = f"chatcmpl-{uuid.uuid4().hex}"
        self._model = client_model
        self._created = int(time.time())
        self._tool_index = -1
        self._block_to_tool: dict[int, int] = {}
        self._done = False

    def feed(self, data: str) -> list[str]:
        if not data:
            return []
        if data == "[DONE]":
            return self._finish()
        try:
            event = json.loads(data)
        except json.JSONDecodeError:
            return [f"data: {data}\n\n"]
        if not isinstance(event, dict):
            return []

        event_type = event.get("type")
        if event_type == "message_start":
            return self._message_start(event.get("message") or {})
        if event_type == "content_block_start":
            return self._content_block_start(event)
        if event_type == "content_block_delta":
            return self._content_block_delta(event)
        if event_type == "message_delta":
            return self._message_delta(event)
        if event_type == "message_stop":
            return self._finish()
        if event_type == "error":
            return self._error(event)
        return []  # ping / content_block_stop 等无需对外输出

    def close(self) -> list[str]:
        return self._finish()

    # ------------------------------------------------------------------ events

    def _message_start(self, message: Mapping[str, Any]) -> list[str]:
        self._id = str(message.get("id") or self._id)
        self._model = self.client_model or str(message.get("model") or "")
        usage_raw = message.get("usage") or {}
        usage = _usage(usage_raw.get("input_tokens"), usage_raw.get("output_tokens"))
        chunk = _chunk(self._id, self._model, self._created, {"role": "assistant", "content": ""}, usage=usage)
        return [_sse(chunk)]

    def _content_block_start(self, event: Mapping[str, Any]) -> list[str]:
        block = event.get("content_block") or {}
        if block.get("type") != "tool_use":
            return []
        self._tool_index += 1
        block_index = int(event.get("index") or 0)
        self._block_to_tool[block_index] = self._tool_index
        delta = {
            "tool_calls": [
                {
                    "index": self._tool_index,
                    "id": block.get("id") or "",
                    "type": "function",
                    "function": {"name": block.get("name") or "", "arguments": ""},
                }
            ]
        }
        return [_sse(_chunk(self._id, self._model, self._created, delta))]

    def _content_block_delta(self, event: Mapping[str, Any]) -> list[str]:
        delta = event.get("delta") or {}
        delta_type = delta.get("type")
        if delta_type == "text_delta":
            return [_sse(_chunk(self._id, self._model, self._created, {"content": delta.get("text") or ""}))]
        if delta_type == "input_json_delta":
            block_index = int(event.get("index") or 0)
            tool_index = self._block_to_tool.get(block_index, 0)
            tool_delta = {
                "tool_calls": [
                    {"index": tool_index, "function": {"arguments": delta.get("partial_json") or ""}}
                ]
            }
            return [_sse(_chunk(self._id, self._model, self._created, tool_delta))]
        return []

    def _message_delta(self, event: Mapping[str, Any]) -> list[str]:
        delta = event.get("delta") or {}
        usage_raw = event.get("usage") or {}
        usage = _usage(None, usage_raw.get("output_tokens"))
        chunk = _chunk(
            self._id,
            self._model,
            self._created,
            {},
            finish_reason=_finish_reason(delta.get("stop_reason")),
            usage=usage,
        )
        return [_sse(chunk)]

    def _error(self, event: Mapping[str, Any]) -> list[str]:
        error = event.get("error") if isinstance(event.get("error"), dict) else event
        error_type = str(error.get("type") or "api_error")
        payload = {
            "error": {
                "message": str(error.get("message") or "Anthropic stream error"),
                "type": "upstream_error",
                "code": error_type,
            }
        }
        return [_sse(payload), *self._finish()]

    def _finish(self) -> list[str]:
        if self._done:
            return []
        self._done = True
        return ["data: [DONE]\n\n"]


class AnthropicProtocol(ProtocolAdapter):
    name = "anthropic"
    endpoint = "/messages"

    def headers(self, provider: Provider) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "anthropic-version": str(provider.options.get("anthropic_version") or DEFAULT_ANTHROPIC_VERSION),
        }
        if provider.api_key:
            headers["x-api-key"] = provider.api_key
        beta = provider.options.get("anthropic_beta")
        if beta:
            headers["anthropic-beta"] = str(beta)
        return headers

    # --------------------------------------------------------------- request

    def format_request(self, payload: Mapping[str, Any], provider: Provider) -> dict[str, Any]:
        messages: list[dict[str, Any]] = []
        system_parts: list[str] = []

        for message in payload.get("messages") or []:
            if not isinstance(message, dict):
                continue
            role = message.get("role")
            content = message.get("content")

            if role in {"system", "developer"}:
                text = _flatten_text(content)
                if text:
                    system_parts.append(text)
                continue

            if role == "tool":
                block = {
                    "type": "tool_result",
                    "tool_use_id": message.get("tool_call_id") or "",
                    "content": _tool_result_content(content),
                }
                self._append(messages, "user", [block])
                continue

            if role == "assistant":
                blocks: list[dict[str, Any]] = []
                text = _flatten_text(content)
                if text:
                    blocks.append({"type": "text", "text": text})
                for call in message.get("tool_calls") or []:
                    if not isinstance(call, dict):
                        continue
                    function = call.get("function") or {}
                    blocks.append(
                        {
                            "type": "tool_use",
                            "id": call.get("id") or "",
                            "name": function.get("name") or "",
                            "input": _parse_arguments(function.get("arguments")),
                        }
                    )
                if blocks:
                    self._append(messages, "assistant", blocks)
                continue

            blocks = _user_blocks(content)
            if blocks:
                self._append(messages, "user", blocks)

        body: dict[str, Any] = {
            "model": payload.get("model"),
            "messages": messages,
            "max_tokens": int(payload.get("max_tokens") or provider.options.get("default_max_tokens") or DEFAULT_MAX_TOKENS),
        }
        if system_parts:
            body["system"] = "\n\n".join(system_parts)

        if payload.get("temperature") is not None:
            body["temperature"] = min(max(float(payload["temperature"]), 0.0), 1.0)

        for key in ("top_p", "top_k"):
            if payload.get(key) is not None:
                body[key] = payload[key]

        stop = payload.get("stop")
        if isinstance(stop, str):
            body["stop_sequences"] = [stop]
        elif isinstance(stop, list):
            sequences = [str(item) for item in stop if item]
            if sequences:
                body["stop_sequences"] = sequences

        if payload.get("user"):
            body["metadata"] = {"user_id": str(payload["user"])}

        tools = _anthropic_tools(payload.get("tools") or [])
        if tools:
            body["tools"] = tools
            tool_choice = _anthropic_tool_choice(payload.get("tool_choice"))
            if tool_choice is not None:
                body["tool_choice"] = tool_choice

        if payload.get("stream"):
            body["stream"] = True
        return body

    @staticmethod
    def _append(messages: list[dict[str, Any]], role: str, blocks: list[dict[str, Any]]) -> None:
        """Anthropic 要求 user/assistant 交替，连续同角色消息合并。"""

        if messages and messages[-1]["role"] == role:
            messages[-1]["content"].extend(blocks)
            return
        messages.append({"role": role, "content": blocks})

    # -------------------------------------------------------------- response

    def format_response(self, data: dict[str, Any], client_model: str | None = None) -> dict[str, Any]:
        blocks = data.get("content") or []
        texts = [str(block.get("text") or "") for block in blocks if block.get("type") == "text"]
        tool_calls = [
            {
                "id": block.get("id") or "",
                "type": "function",
                "function": {
                    "name": block.get("name") or "",
                    "arguments": json.dumps(block.get("input") or {}, ensure_ascii=False),
                },
            }
            for block in blocks
            if block.get("type") == "tool_use"
        ]

        message: dict[str, Any] = {"role": "assistant", "content": "".join(texts) if texts else None}
        if tool_calls:
            message["tool_calls"] = tool_calls

        usage_raw = data.get("usage") or {}
        result: dict[str, Any] = {
            "id": data.get("id") or f"chatcmpl-{uuid.uuid4().hex}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": client_model or data.get("model") or "",
            "choices": [
                {
                    "index": 0,
                    "message": message,
                    "finish_reason": _finish_reason(data.get("stop_reason")),
                }
            ],
        }
        usage = _usage(usage_raw.get("input_tokens"), usage_raw.get("output_tokens"))
        if usage is not None:
            result["usage"] = usage
        return result

    # ----------------------------------------------------------------- error

    def format_error(self, content: bytes, status_code: int) -> tuple[int, dict[str, Any]]:
        body = _json_or_none(content)
        error = body.get("error") if isinstance(body, dict) else None
        if isinstance(error, dict):
            error_type = str(error.get("type") or "api_error")
            message = str(error.get("message") or "Anthropic request failed")
        else:
            error_type = "api_error"
            message = content.decode("utf-8", "ignore").strip() or f"Anthropic returned {status_code}"

        status = _ERROR_STATUS_MAP.get(error_type)
        if status is None:
            status = status_code if 400 <= status_code < 600 else 500
        return status, {
            "error": {
                "message": message,
                "type": "invalid_request_error" if status < 500 else "gateway_error",
                "code": error_type,
                "details": {"upstream_status": status_code},
            }
        }

    # ----------------------------------------------------------------- stream

    def stream_converter(self, client_model: str) -> StreamConverter:
        return AnthropicStreamConverter(client_model)
