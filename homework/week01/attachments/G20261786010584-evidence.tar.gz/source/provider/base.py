"""供应商数据模型。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Provider:
    name: str
    base_url: str
    api_key: str | None = None
    modalities: frozenset[str] = frozenset({"chat"})
    capabilities: dict[str, Any] = field(default_factory=dict)
    # 上游协议规则名（openai / anthropic），默认保持旧配置兼容
    protocol: str = "openai"
    # 协议专属配置，如 anthropic_version、default_max_tokens
    options: dict[str, Any] = field(default_factory=dict)
    # 是否启用；false 时路由前置校验直接拒绝转发
    enabled: bool = True
    # 是否要求配置 API Key；true 时缺失凭据会在前置校验阶段报错
    requires_api_key: bool = False

    def supports(self, capability: str, value: str) -> bool:
        values = self.capabilities.get(capability) or []
        return value in values
