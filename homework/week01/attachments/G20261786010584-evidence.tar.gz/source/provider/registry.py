"""供应商注册表：通过统一配置接口读取根目录 config/llm.yaml 并构建 Provider。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from config.loader import get_llm_config
from error import messages
from error.provider import UnknownProtocolError
from provider.base import Provider
from provider.protocols.registry import protocol_names


def _to_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _load(path: str | Path | None = None) -> tuple[dict[str, Provider], str]:
    """按当前生效配置构建供应商映射；每次调用都会感知配置热更新。"""

    raw: dict[str, Any] = get_llm_config(path)

    providers: dict[str, Provider] = {}
    for name, item in (raw.get("providers") or {}).items():
        protocol = str(item.get("protocol") or "openai").strip().lower()
        if protocol not in protocol_names():
            raise UnknownProtocolError(
                messages.PROVIDER_UNKNOWN_PROTOCOL.format(
                    name=name, protocol=protocol, supported=", ".join(protocol_names())
                )
            )
        providers[name] = Provider(
            name=name,
            base_url=str(item["base_url"]).rstrip("/"),
            api_key=str(item.get("api_key") or "") or None,
            modalities=frozenset(item.get("modalities") or ["chat"]),
            capabilities=item.get("capabilities") or {},
            protocol=protocol,
            options=item.get("options") or {},
            enabled=_to_bool(item.get("enabled"), True),
            requires_api_key=_to_bool(item.get("requires_api_key"), False),
        )
    return providers, str(raw.get("default_provider") or "openai")


def get_providers() -> dict[str, Provider]:
    return _load()[0]


def get_default_provider() -> str:
    raw = get_llm_config()
    return str(raw.get("default_provider") or "openai")


def get_provider(name: str) -> Provider | None:
    return get_providers().get(name)
