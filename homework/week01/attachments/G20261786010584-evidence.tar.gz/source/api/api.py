"""接口层：对外暴露 OpenAI 协议的 HTTP 端点。"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any, AsyncIterator, Literal

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field

from config.loader import get_app_config
from error import messages
from error.base import PromptError
from error.codes import ErrorCode
from error.http import http_error, prompt_http_error
from error.upstream import extract_error
from gateway.modality import Modality, get_handler
from gateway.observability import get_observability
from gateway.resilience import (
    ErrorCategory,
    ResponseCache,
    Target,
    build_targets,
    classify_error,
    get_cache,
    get_retry_policy,
)
from gateway.status import ExecutionStatus
from gateway.trace import TraceContext, collect_business_ids, start_trace
from prompt.models import OutputMode, PromptInvocation
from prompt.output import build_response_format, validate_output
from prompt.service import get_service
from provider import Provider
from router.health import get_health_registry, record_provider_failure, record_provider_success
from router.router import get_model_aliases, resolve_model, select_provider
from router.validation import health_unavailable_error, validate_targets


def _gateway_api_key() -> str:
    """网关自身鉴权 Key；为空则不校验。每次读取支持配置热更新。"""

    return str((get_app_config().get("gateway") or {}).get("api_key") or "").strip()


api_router = APIRouter()


async def verify_api_key(authorization: str | None = Header(default=None)) -> None:
    api_key = _gateway_api_key()
    if not api_key:
        return
    if not authorization or not authorization.startswith("Bearer ") or authorization[7:] != api_key:
        raise HTTPException(
            401,
            messages.INVALID_GATEWAY_API_KEY,
            headers={"WWW-Authenticate": "Bearer"},
        )


# ---------------------------------------------------------------------------
# 协议模型（与 OpenAI /v1/chat/completions 对齐）
# ---------------------------------------------------------------------------


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: Literal["system", "developer", "user", "assistant", "tool"]
    content: str | list[dict[str, Any]] | None = None
    name: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None


class LLMRequest(BaseModel):
    """统一的请求协议；未知字段会原样透传给上游。"""

    model_config = ConfigDict(extra="allow")

    model: str
    messages: list[ChatMessage]
    stream: bool = False

    temperature: float | None = None
    top_p: float | None = None
    n: int | None = None
    max_tokens: int | None = None
    stop: str | list[str] | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    seed: int | None = None
    user: str | None = None
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict[str, Any] | None = None
    response_format: dict[str, Any] | None = None

    # 网关扩展字段：强制指定供应商，不转发给上游
    provider: str | None = None
    # 网关扩展字段：prompt 模板编排，不转发给上游
    prompt: PromptInvocation | None = None


class ResponseMessage(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: Literal["assistant"] = "assistant"
    content: str | None = None
    tool_calls: list[dict[str, Any]] | None = None


class Choice(BaseModel):
    model_config = ConfigDict(extra="allow")

    index: int = 0
    message: ResponseMessage
    finish_reason: str | None = None


class Usage(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class LLMResponse(BaseModel):
    """统一的响应协议。"""

    model_config = ConfigDict(extra="allow")

    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex}")
    object: Literal["chat.completion"] = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: list[Choice]
    usage: Usage | None = None


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------


def _response_format_matches(response_format: dict[str, Any], mode: OutputMode) -> bool:
    expected = "json_object" if mode is OutputMode.JSON else "json_schema"
    return response_format.get("type") == expected


def _request_id(request: Request) -> str:
    return getattr(request.state, "request_id", "") or f"req_{uuid.uuid4().hex[:16]}"


def _trace_id(request: Request) -> str:
    return getattr(request.state, "trace_id", "") or f"tr_{uuid.uuid4().hex[:16]}"


def _usage_counts(data: dict[str, Any]) -> tuple[int, int]:
    usage = data.get("usage") or {}
    try:
        return int(usage.get("prompt_tokens") or 0), int(usage.get("completion_tokens") or 0)
    except (TypeError, ValueError):
        return 0, 0


@dataclass
class _AttemptInfo:
    """一次请求模式尝试的上下文，用于指标与埋点归属。"""

    mode: str
    provider: Provider
    model: str
    started_at: str
    started_perf: float


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _total_tokens(data: dict[str, Any]) -> int:
    usage = data.get("usage") or {}
    try:
        return int(usage.get("total_tokens") or 0)
    except (TypeError, ValueError):
        return 0


def _stream_usage(chunk: str) -> tuple[int, int]:
    if not chunk.startswith("data: "):
        return 0, 0
    raw = chunk[6:].strip()
    if not raw or raw == "[DONE]":
        return 0, 0
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return 0, 0
    usage = payload.get("usage") if isinstance(payload, dict) else None
    if not isinstance(usage, dict):
        return 0, 0
    try:
        return int(usage.get("prompt_tokens") or 0), int(usage.get("completion_tokens") or 0)
    except (TypeError, ValueError):
        return 0, 0


def _error_code(exc: HTTPException) -> str:
    if isinstance(exc.detail, dict):
        error = exc.detail.get("error")
        if isinstance(error, dict) and error.get("code") is not None:
            return str(error["code"])
    return str(exc.status_code)


def _record_failed_attempt(
    info: _AttemptInfo, request_id: str, error_code: str | None, ttft_ms: float | None = None
) -> None:
    duration_ms = round((time.perf_counter() - info.started_perf) * 1000, 3)
    get_observability().record_metric(
        request_id=request_id,
        mode=info.mode,
        provider=info.provider.name,
        model=info.model,
        mode_started_at=info.started_at,
        mode_ended_at=_now_iso(),
        ttft_ms=duration_ms if ttft_ms is None else ttft_ms,
        total_tokens=0,
        status=ExecutionStatus.FAILED,
        error_code=error_code,
    )


def _record_prompt_usage(
    prepared: Any,
    *,
    request_id: str,
    model: str,
    provider_name: str,
    status: ExecutionStatus,
    started: float,
    error_code: str | None = None,
) -> None:
    if prepared is None:
        return
    get_service().record_usage(
        prepared,
        request_id=request_id,
        model=model,
        provider=provider_name,
        status=status.value,
        error_code=error_code,
        latency_ms=int((time.perf_counter() - started) * 1000),
    )


async def _prepare_prompt_with_retry(body: LLMRequest) -> Any:
    """Prompt 编排：模板缺失等错误按配置重试，鉴权/模型类错误直接终止。"""

    if body.prompt is None:
        return None
    policy = get_retry_policy()
    obs = get_observability()
    attempt = 0
    while True:
        attempt += 1
        try:
            async with obs.span("prompt.prepare", prompt_id=body.prompt.id, attempt=attempt) as span:
                prepared = await get_service().prepare(body.prompt, body.messages)
                span.output(template_id=prepared.template_id, version=prepared.version)
                return prepared
        except PromptError as exc:
            category = classify_error(exc.status_code, exc.code, exc.message)
            if policy.is_terminal(category) or attempt >= policy.attempts_for("primary", category):
                raise prompt_http_error(exc) from exc
            await asyncio.sleep(policy.delay_seconds)


async def _complete_with_fallback(
    *,
    handler: Any,
    client: httpx.AsyncClient,
    targets: list[Target],
    primary_provider: Provider,
    payload: dict[str, Any],
    client_model: str,
    request_id: str,
    policy: Any,
    cache: ResponseCache,
    cache_key: str,
    trace: TraceContext,
    unavailable_error: HTTPException | None = None,
) -> tuple[dict[str, Any], _AttemptInfo]:
    """非流式：主模式 → 备用模式 → 缓存，按错误类别决定重试次数。"""

    obs = get_observability()
    last_error: HTTPException | None = None

    for target in targets:
        attempt = 0
        while True:
            attempt += 1
            info = _AttemptInfo(target.role, target.provider, target.model, _now_iso(), time.perf_counter())
            current = {**payload, "model": target.model}
            try:
                async with obs.span(
                    "upstream.complete",
                    role=target.role,
                    provider=target.provider.name,
                    model=target.model,
                    attempt=attempt,
                    payload=current,
                ) as span:
                    resp = await handler.complete(client, target.provider, current)
                    span.output(status_code=resp.status_code, body=resp.content)
            except httpx.HTTPError as exc:
                duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
                last_error = http_error(
                    502,
                    ErrorCode.UPSTREAM_TRANSPORT_ERROR,
                    str(exc) or messages.UPSTREAM_TRANSPORT_ERROR,
                )
                _record_failed_attempt(info, request_id, ErrorCode.UPSTREAM_TRANSPORT_ERROR)
                record_provider_failure(
                    target.provider,
                    ErrorCategory.TRANSIENT,
                    error_code=ErrorCode.UPSTREAM_TRANSPORT_ERROR.value,
                )
                trace.add_attempt(
                    provider=target.provider.name,
                    model=target.model,
                    role=target.role,
                    attempt=attempt,
                    status="failed",
                    duration_ms=duration,
                    error_code=ErrorCode.UPSTREAM_TRANSPORT_ERROR.value,
                )
                if attempt >= policy.attempts_for(target.role, ErrorCategory.TRANSIENT):
                    break
                await asyncio.sleep(policy.delay_seconds)
                continue

            if resp.status_code >= 400:
                duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
                error = extract_error(resp.content, resp.status_code)
                body = error.get("error") if isinstance(error, dict) else {}
                category = classify_error(resp.status_code, body.get("code"), body.get("message"))
                failure_code = str(body.get("code") or resp.status_code)
                last_error = HTTPException(resp.status_code, error)
                _record_failed_attempt(info, request_id, failure_code)
                record_provider_failure(
                    target.provider,
                    category,
                    status_code=resp.status_code,
                    error_code=failure_code,
                )
                trace.add_attempt(
                    provider=target.provider.name,
                    model=target.model,
                    role=target.role,
                    attempt=attempt,
                    status="failed",
                    duration_ms=duration,
                    error_code=failure_code,
                )
                if policy.is_terminal(category):
                    raise last_error
                if attempt >= policy.attempts_for(target.role, category):
                    break
                await asyncio.sleep(policy.delay_seconds)
                continue

            try:
                data = resp.json()
            except ValueError:
                duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
                last_error = http_error(
                    502,
                    ErrorCode.UPSTREAM_INVALID_RESPONSE,
                    messages.UPSTREAM_INVALID_RESPONSE,
                )
                _record_failed_attempt(info, request_id, ErrorCode.UPSTREAM_INVALID_RESPONSE)
                record_provider_failure(
                    target.provider,
                    ErrorCategory.TRANSIENT,
                    status_code=resp.status_code,
                    error_code=ErrorCode.UPSTREAM_INVALID_RESPONSE.value,
                )
                trace.add_attempt(
                    provider=target.provider.name,
                    model=target.model,
                    role=target.role,
                    attempt=attempt,
                    status="failed",
                    duration_ms=duration,
                    error_code=ErrorCode.UPSTREAM_INVALID_RESPONSE.value,
                )
                break

            data["model"] = client_model
            duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
            record_provider_success(target.provider)
            trace.add_attempt(
                provider=target.provider.name,
                model=target.model,
                role=target.role,
                attempt=attempt,
                status="completed",
                duration_ms=duration,
            )
            if target.role != "primary":
                trace.mark_degraded("fallback")
            return data, info

    cached = cache.get(cache_key)
    if isinstance(cached, dict) and isinstance(cached.get("response"), dict):
        data = dict(cached["response"])
        data["model"] = client_model
        data["cached"] = True
        trace.mark_degraded("cache")
        trace.add_attempt(
            provider=primary_provider.name,
            model=client_model,
            role="cache",
            attempt=1,
            status="completed",
            duration_ms=0.0,
        )
        return data, _AttemptInfo("cache", primary_provider, client_model, _now_iso(), time.perf_counter())

    raise unavailable_error or last_error or http_error(
        503,
        ErrorCode.UPSTREAM_UNAVAILABLE,
        messages.UPSTREAM_UNAVAILABLE,
    )


async def _open_stream_with_fallback(
    *,
    handler: Any,
    client: httpx.AsyncClient,
    targets: list[Target],
    primary_provider: Provider,
    payload: dict[str, Any],
    client_model: str,
    request_id: str,
    policy: Any,
    cache: ResponseCache,
    cache_key: str,
    trace: TraceContext,
    unavailable_error: HTTPException | None = None,
) -> tuple[httpx.Response | None, _AttemptInfo, list[str] | None]:
    """流式：只在首事件产出前重试/降级；失败后读取缓存回放。"""

    obs = get_observability()
    last_error: HTTPException | None = None

    for target in targets:
        attempt = 0
        while True:
            attempt += 1
            info = _AttemptInfo(target.role, target.provider, target.model, _now_iso(), time.perf_counter())
            current = {**payload, "model": target.model}
            try:
                async with obs.span(
                    "upstream.open_stream",
                    role=target.role,
                    provider=target.provider.name,
                    model=target.model,
                    attempt=attempt,
                    payload=current,
                ) as span:
                    upstream = await handler.open_stream(client, target.provider, current)
                    span.output(status_code=upstream.status_code)
            except httpx.HTTPError as exc:
                duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
                last_error = http_error(
                    502,
                    ErrorCode.UPSTREAM_TRANSPORT_ERROR,
                    str(exc) or messages.UPSTREAM_TRANSPORT_ERROR,
                )
                _record_failed_attempt(info, request_id, ErrorCode.UPSTREAM_TRANSPORT_ERROR, ttft_ms=0.0)
                record_provider_failure(
                    target.provider,
                    ErrorCategory.TRANSIENT,
                    error_code=ErrorCode.UPSTREAM_TRANSPORT_ERROR.value,
                )
                trace.add_attempt(
                    provider=target.provider.name,
                    model=target.model,
                    role=target.role,
                    attempt=attempt,
                    status="failed",
                    duration_ms=duration,
                    error_code=ErrorCode.UPSTREAM_TRANSPORT_ERROR.value,
                )
                if attempt >= policy.attempts_for(target.role, ErrorCategory.TRANSIENT):
                    break
                await asyncio.sleep(policy.delay_seconds)
                continue

            if upstream.status_code >= 400:
                duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
                error_body = await upstream.aread()
                await upstream.aclose()
                error = extract_error(error_body, upstream.status_code)
                body = error.get("error") if isinstance(error, dict) else {}
                category = classify_error(upstream.status_code, body.get("code"), body.get("message"))
                failure_code = str(body.get("code") or upstream.status_code)
                last_error = HTTPException(upstream.status_code, error)
                _record_failed_attempt(info, request_id, failure_code, ttft_ms=0.0)
                record_provider_failure(
                    target.provider,
                    category,
                    status_code=upstream.status_code,
                    error_code=failure_code,
                )
                trace.add_attempt(
                    provider=target.provider.name,
                    model=target.model,
                    role=target.role,
                    attempt=attempt,
                    status="failed",
                    duration_ms=duration,
                    error_code=failure_code,
                )
                if policy.is_terminal(category):
                    raise last_error
                if attempt >= policy.attempts_for(target.role, category):
                    break
                await asyncio.sleep(policy.delay_seconds)
                continue

            duration = round((time.perf_counter() - info.started_perf) * 1000, 3)
            record_provider_success(target.provider)
            trace.add_attempt(
                provider=target.provider.name,
                model=target.model,
                role=target.role,
                attempt=attempt,
                status="completed",
                duration_ms=duration,
            )
            if target.role != "primary":
                trace.mark_degraded("fallback")
            return upstream, info, None

    cached = cache.get(cache_key)
    if isinstance(cached, dict) and isinstance(cached.get("lines"), list) and cached["lines"]:
        trace.mark_degraded("cache")
        trace.add_attempt(
            provider=primary_provider.name,
            model=client_model,
            role="cache",
            attempt=1,
            status="completed",
            duration_ms=0.0,
        )
        info = _AttemptInfo("cache", primary_provider, client_model, _now_iso(), time.perf_counter())
        return None, info, [str(line) for line in cached["lines"]]

    raise unavailable_error or last_error or http_error(
        503,
        ErrorCode.UPSTREAM_UNAVAILABLE,
        messages.UPSTREAM_UNAVAILABLE,
    )


async def _replay_stream(lines: list[str]) -> AsyncIterator[str]:
    for line in lines:
        await asyncio.sleep(0)
        yield line


async def _instrumented_stream(
    source: AsyncIterator[str],
    *,
    service: Any,
    prepared: Any,
    request_id: str,
    info: _AttemptInfo,
    client_model: str,
    cache: ResponseCache,
    cache_key: str,
    cache_enabled: bool,
    trace: TraceContext,
) -> AsyncIterator[str]:
    """流式埋点：记录 TTFT、token 总量、执行状态，并在成功后写入缓存。"""

    obs = get_observability()
    token = obs.begin_request(request_id)
    span = obs.begin_span("stream.consume", mode=info.mode, provider=info.provider.name, model=info.model)
    status = ExecutionStatus.FAILED
    error_code: str | None = "upstream_error"
    lines: list[str] = []
    prompt_tokens = 0
    completion_tokens = 0
    first_at: float | None = None
    try:
        async for chunk in source:
            if first_at is None:
                first_at = time.perf_counter()
                span.output(ttft_ms=round((first_at - info.started_perf) * 1000, 3))
            lines.append(chunk)
            chunk_prompt, chunk_completion = _stream_usage(chunk)
            prompt_tokens = max(prompt_tokens, chunk_prompt)
            completion_tokens = max(completion_tokens, chunk_completion)
            yield chunk
        status = ExecutionStatus.COMPLETED
        error_code = None
    except (asyncio.CancelledError, GeneratorExit):
        status = ExecutionStatus.CANCELLED
        error_code = "cancelled"
        span.end(status, "client disconnected")
        raise
    except Exception as exc:  # noqa: BLE001 - 记录后原样抛出
        span.end(ExecutionStatus.FAILED, f"{type(exc).__name__}: {exc}")
        raise
    finally:
        total_tokens = prompt_tokens + completion_tokens
        ttft_ms = round((first_at - info.started_perf) * 1000, 3) if first_at else 0.0
        ended_at = _now_iso()
        span.end(status, error_code)
        if status is ExecutionStatus.FAILED:
            record_provider_failure(info.provider, ErrorCategory.TRANSIENT, error_code=error_code)
        if status is ExecutionStatus.COMPLETED and cache_enabled and cache_key and lines:
            cache.put(cache_key, {"lines": lines, "tokens": total_tokens})
        obs.record_metric(
            request_id=request_id,
            mode=info.mode,
            provider=info.provider.name,
            model=info.model,
            mode_started_at=info.started_at,
            mode_ended_at=ended_at,
            ttft_ms=ttft_ms,
            total_tokens=total_tokens,
            status=status,
            error_code=error_code,
        )
        _record_prompt_usage(
            prepared,
            request_id=request_id,
            model=client_model,
            provider_name=info.provider.name,
            status=status,
            started=info.started_perf,
            error_code=error_code,
        )
        trace.set_usage(prompt_tokens, completion_tokens)
        trace.finish(
            status,
            error_code=error_code,
            http_status=200 if status is ExecutionStatus.COMPLETED else None,
        )
        obs.end_request(token)


# ---------------------------------------------------------------------------
# 端点
# ---------------------------------------------------------------------------


@api_router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@api_router.get("/v1/models", dependencies=[Depends(verify_api_key)])
async def list_models() -> dict[str, Any]:
    data = []
    for name in get_model_aliases():
        provider, _ = resolve_model(name)
        data.append({"id": name, "object": "model", "created": 0, "owned_by": provider.base_url})
    return {"object": "list", "data": data}


@api_router.post("/v1/chat/completions", response_model=None, dependencies=[Depends(verify_api_key)])
async def chat_completions(body: LLMRequest, request: Request) -> Any:
    obs = get_observability()
    request_id = _request_id(request)
    trace = start_trace(
        trace_id=_trace_id(request),
        request_id=request_id,
        business_ids=collect_business_ids(request.headers, user=body.user),
        stream=body.stream,
    )
    token = obs.begin_request(request_id)
    started = time.perf_counter()

    try:
        async with obs.span("route.resolve", model=body.model, provider_override=body.provider) as span:
            provider, upstream_model = select_provider(body.model, body.provider)
            trace.set_route(
                provider=provider.name,
                client_model=body.model,
                upstream_model=upstream_model,
            )
            span.output(provider=provider.name, upstream_model=upstream_model, protocol=provider.protocol)

        prepared = await _prepare_prompt_with_retry(body)
        trace.set_prompt(prepared)

        degraded = False
        async with obs.span("payload.build", stream=body.stream, has_prompt=body.prompt is not None) as span:
            payload = body.model_dump(exclude_none=True)
            payload.pop("prompt", None)
            payload.pop("provider", None)  # 网关扩展字段不转发上游
            payload["model"] = upstream_model
            if prepared is not None:
                payload["messages"] = prepared.messages

            if prepared is not None and prepared.output.mode is not OutputMode.TEXT:
                if body.stream:
                    raise prompt_http_error(
                        PromptError(
                            ErrorCode.STRUCTURED_OUTPUT_REQUIRES_NON_STREAM,
                            messages.PROMPT_STRUCTURED_STREAM_UNSUPPORTED,
                            400,
                        )
                    )
                if body.response_format is not None:
                    if not _response_format_matches(body.response_format, prepared.output.mode):
                        raise http_error(
                            400,
                            ErrorCode.PROMPT_OUTPUT_MODE_CONFLICT,
                            messages.PROMPT_RESPONSE_FORMAT_CONFLICT,
                            details={},
                        )
                else:
                    response_format, degraded = build_response_format(prepared.output, provider)
                    if response_format is not None:
                        payload["response_format"] = response_format
            span.output(
                message_count=len(payload.get("messages") or []),
                response_format=payload.get("response_format"),
            )

        handler = get_handler(Modality.CHAT)
        client: httpx.AsyncClient = request.app.state.client
        policy = get_retry_policy()
        targets = validate_targets(build_targets(provider, upstream_model))
        targets, excluded = get_health_registry().order_targets(targets)
        unavailable_error = health_unavailable_error(excluded) if not targets else None
        cache = get_cache()
        cache_key = cache.key({"model": body.model, "payload": payload}, body.stream)

        if body.stream:
            try:
                upstream, info, cached_lines = await _open_stream_with_fallback(
                    handler=handler,
                    client=client,
                    targets=targets,
                    primary_provider=provider,
                    payload=payload,
                    client_model=body.model,
                    request_id=request_id,
                    policy=policy,
                    cache=cache,
                    cache_key=cache_key,
                    trace=trace,
                    unavailable_error=unavailable_error,
                )
            except HTTPException as exc:
                _record_prompt_usage(
                    prepared,
                    request_id=request_id,
                    model=body.model,
                    provider_name=provider.name,
                    status=ExecutionStatus.FAILED,
                    started=started,
                    error_code=_error_code(exc),
                )
                raise

            if upstream is None:
                source: AsyncIterator[str] = _replay_stream(cached_lines or [])
                cache_enabled = False
            else:
                source = handler.transform_stream(upstream, client_model=body.model, provider=info.provider)
                cache_enabled = True

            stream = _instrumented_stream(
                source,
                service=get_service(),
                prepared=prepared,
                request_id=request_id,
                info=info,
                client_model=body.model,
                cache=cache,
                cache_key=cache_key,
                cache_enabled=cache_enabled,
                trace=trace,
            )
            return StreamingResponse(
                stream,
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        try:
            data, info = await _complete_with_fallback(
                handler=handler,
                client=client,
                targets=targets,
                primary_provider=provider,
                payload=payload,
                client_model=body.model,
                request_id=request_id,
                policy=policy,
                cache=cache,
                cache_key=cache_key,
                trace=trace,
                unavailable_error=unavailable_error,
            )
        except HTTPException as exc:
            _record_prompt_usage(
                prepared,
                request_id=request_id,
                model=body.model,
                provider_name=provider.name,
                status=ExecutionStatus.FAILED,
                started=started,
                error_code=_error_code(exc),
            )
            raise

        if prepared is not None:
            meta: dict[str, Any] = {**prepared.meta, "validated": False, "degraded": degraded}
            if prepared.output.mode is not OutputMode.TEXT:
                try:
                    _, _ = validate_output(prepared.output, _first_content(data))
                except PromptError as exc:
                    obs.record_metric(
                        request_id=request_id,
                        mode=info.mode,
                        provider=info.provider.name,
                        model=info.model,
                        mode_started_at=info.started_at,
                        mode_ended_at=_now_iso(),
                        ttft_ms=round((time.perf_counter() - info.started_perf) * 1000, 3),
                        total_tokens=_total_tokens(data),
                        status=ExecutionStatus.FAILED,
                        error_code=exc.code,
                    )
                    _record_prompt_usage(
                        prepared,
                        request_id=request_id,
                        model=body.model,
                        provider_name=provider.name,
                        status=ExecutionStatus.FAILED,
                        started=started,
                        error_code=exc.code,
                    )
                    trace.set_usage(*_usage_counts(data))
                    raise prompt_http_error(exc)
                meta["validated"] = True
            data["prompt"] = meta

        elapsed_ms = round((time.perf_counter() - info.started_perf) * 1000, 3)
        obs.record_metric(
            request_id=request_id,
            mode=info.mode,
            provider=info.provider.name,
            model=info.model,
            mode_started_at=info.started_at,
            mode_ended_at=_now_iso(),
            ttft_ms=elapsed_ms,
            total_tokens=_total_tokens(data),
            status=ExecutionStatus.COMPLETED,
        )
        _record_prompt_usage(
            prepared,
            request_id=request_id,
            model=body.model,
            provider_name=provider.name,
            status=ExecutionStatus.COMPLETED,
            started=started,
        )

        if not data.get("cached"):
            cacheable = {key: value for key, value in data.items() if key not in {"prompt", "cached"}}
            cache.put(cache_key, {"response": cacheable, "tokens": _total_tokens(data)})

        async with obs.span("response.build", cached=bool(data.get("cached"))) as span:
            response = LLMResponse.model_validate(data)
            span.output(response_id=response.id)

        trace.set_usage(*_usage_counts(data))
        trace.finish(ExecutionStatus.COMPLETED, http_status=200)
        return response
    except HTTPException as exc:
        trace.finish(
            ExecutionStatus.FAILED,
            error_code=_error_code(exc),
            http_status=exc.status_code,
        )
        raise
    except Exception as exc:  # noqa: BLE001 - 记录后原样抛出
        trace.finish(
            ExecutionStatus.FAILED,
            error_code=type(exc).__name__,
            http_status=500,
        )
        raise
    finally:
        obs.end_request(token)


def _first_content(data: dict[str, Any]) -> str | None:
    choices = data.get("choices") or []
    if not choices:
        return None
    message = choices[0].get("message") or {}
    content = message.get("content")
    return content if isinstance(content, str) else None
