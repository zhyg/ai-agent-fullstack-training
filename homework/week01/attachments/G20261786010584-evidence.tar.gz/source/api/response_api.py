"""Response 端点：POST /v1/response。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import Response

from api.api import verify_api_key
from response.models import ResponseRequest
from response.service import build_response

response_router = APIRouter()


@response_router.post(
    "/v1/response",
    response_model=None,
    dependencies=[Depends(verify_api_key)],
)
async def create_response(
    payload: ResponseRequest,
    request: Request,
    mode: str | None = Query(default=None, description="normal | stream，优先于请求体"),
) -> Response:
    return await build_response(payload, request, query_mode=mode)
