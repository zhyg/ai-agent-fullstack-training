"""Trace 查询端点：GET /v1/traces。

支持按 trace_id、request_id、供应商、时间范围、执行状态与服务运行状态检索，
返回按请求开始时间倒序排列的结构化记录。
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from api.api import verify_api_key
from error import messages
from error.codes import ErrorCode
from error.http import http_error
from gateway.trace import get_trace_store

trace_router = APIRouter()


@trace_router.get("/v1/traces", dependencies=[Depends(verify_api_key)])
async def list_traces(
    trace_id: str | None = Query(default=None, description="全链路唯一 trace_id"),
    request_id: str | None = Query(default=None, description="请求 ID"),
    provider: str | None = Query(default=None, description="供应商名称"),
    start: str | None = Query(default=None, description="起始时间（ISO8601，含时区）"),
    end: str | None = Query(default=None, description="结束时间（ISO8601，含时区）"),
    status: str | None = Query(default=None, description="执行状态：completed/failed/cancelled"),
    service_status: str | None = Query(
        default=None, description="服务运行状态：healthy/degraded/failed"
    ),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
) -> dict[str, Any]:
    try:
        records, total = get_trace_store().query(
            trace_id=trace_id,
            request_id=request_id,
            provider=provider,
            start=start,
            end=end,
            status=status,
            service_status=service_status,
            limit=limit,
            offset=offset,
        )
    except ValueError as exc:
        raise http_error(
            400,
            ErrorCode.TRACE_QUERY_INVALID.value,
            messages.TRACE_QUERY_INVALID.format(reason=str(exc)),
        ) from exc

    return {
        "object": "list",
        "total": total,
        "limit": limit,
        "offset": offset,
        "data": records,
    }
