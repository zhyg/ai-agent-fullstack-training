"""模板管理接口：/api/v1/prompts。"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from api.api import verify_api_key
from prompt.audit import get_audit
from error.base import PromptError
from prompt.models import OutputSpec, VariablesSchema
from prompt.service import get_service
from prompt.store import get_store

prompt_router = APIRouter()

_ID_PATTERN = r"^[A-Za-z0-9._-]{1,64}$"


class TemplateWrite(BaseModel):
    model_config = ConfigDict(extra="forbid")

    description: str | None = Field(default=None, max_length=1024)
    tags: list[str] = Field(default_factory=list)
    system: str | None = Field(default=None, max_length=262_144)
    user_template: str | None = Field(default=None, max_length=262_144)
    variables_schema: VariablesSchema = Field(default_factory=VariablesSchema)
    output: OutputSpec = Field(default_factory=OutputSpec)
    enabled: bool = True


class TemplateCreate(TemplateWrite):
    id: str = Field(pattern=_ID_PATTERN)


class TemplateUpdate(TemplateWrite):
    expected_version: int = Field(ge=1)


class PreviewRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: int | None = Field(default=None, ge=1)
    variables: dict[str, Any] = Field(default_factory=dict)


def _request_id(request: Request) -> str:
    return getattr(request.state, "request_id", "")


def _ok(request: Request, data: Any, status_code: int = 200) -> JSONResponse:
    return JSONResponse(
        {"ok": True, "data": data, "request_id": _request_id(request)},
        status_code=status_code,
    )


def _fail(request: Request, exc: PromptError) -> JSONResponse:
    return JSONResponse(
        {
            "ok": False,
            "error": {"code": exc.code, "message": exc.message, "details": exc.details},
            "request_id": _request_id(request),
        },
        status_code=exc.status_code,
    )


@prompt_router.get("/api/v1/prompts", dependencies=[Depends(verify_api_key)])
async def list_templates(request: Request) -> JSONResponse:
    data = [template.model_dump(exclude_none=True) for template in get_store().list()]
    return _ok(request, {"items": data, "total": len(data)})


@prompt_router.get("/api/v1/prompts/{template_id}", dependencies=[Depends(verify_api_key)])
async def get_template(
    request: Request,
    template_id: str,
    version: int | None = Query(default=None, ge=1),
) -> JSONResponse:
    try:
        template = get_store().get(template_id, version)
    except PromptError as exc:
        return _fail(request, exc)
    return _ok(request, template.model_dump(exclude_none=True))


@prompt_router.post("/api/v1/prompts", dependencies=[Depends(verify_api_key)])
async def create_template(request: Request, payload: TemplateCreate) -> JSONResponse:
    try:
        template = await get_service().upsert_template(
            payload.id,
            expected_version=None,
            description=payload.description,
            tags=payload.tags,
            system=payload.system,
            user_template=payload.user_template,
            variables_schema=payload.variables_schema,
            output=payload.output,
            enabled=payload.enabled,
            actor=request.headers.get("X-Actor"),
        )
    except PromptError as exc:
        return _fail(request, exc)
    return _ok(request, template.model_dump(exclude_none=True), status_code=201)


@prompt_router.put("/api/v1/prompts/{template_id}", dependencies=[Depends(verify_api_key)])
async def update_template(request: Request, template_id: str, payload: TemplateUpdate) -> JSONResponse:
    try:
        template = await get_service().upsert_template(
            template_id,
            expected_version=payload.expected_version,
            description=payload.description,
            tags=payload.tags,
            system=payload.system,
            user_template=payload.user_template,
            variables_schema=payload.variables_schema,
            output=payload.output,
            enabled=payload.enabled,
            actor=request.headers.get("X-Actor"),
        )
    except PromptError as exc:
        return _fail(request, exc)
    return _ok(request, template.model_dump(exclude_none=True))


@prompt_router.delete("/api/v1/prompts/{template_id}", dependencies=[Depends(verify_api_key)])
async def delete_template(request: Request, template_id: str) -> JSONResponse:
    try:
        await get_service().delete_template(template_id, actor=request.headers.get("X-Actor"))
    except PromptError as exc:
        return _fail(request, exc)
    return _ok(request, {"deleted": True, "id": template_id})


@prompt_router.post("/api/v1/prompts/{template_id}/preview", dependencies=[Depends(verify_api_key)])
async def preview_template(request: Request, template_id: str, payload: PreviewRequest) -> JSONResponse:
    try:
        result = get_service().preview(template_id, payload.variables, version=payload.version)
    except PromptError as exc:
        return _fail(request, exc)
    return _ok(request, result)


@prompt_router.get("/api/v1/prompts/{template_id}/usages", dependencies=[Depends(verify_api_key)])
async def list_usages(
    request: Request,
    template_id: str,
    status: str | None = Query(default=None),
    session_id: str | None = Query(default=None),
    since: str | None = Query(default=None),
    until: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
) -> JSONResponse:
    records = get_audit().query(
        template_id=template_id,
        status=status,
        session_id=session_id,
        since=since,
        until=until,
        limit=limit,
    )
    return _ok(request, {"items": records, "total": len(records)})
