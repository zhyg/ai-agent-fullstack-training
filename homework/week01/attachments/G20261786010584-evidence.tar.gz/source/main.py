"""轻量级 OpenAI 协议 LLM Gateway 入口。

统一入口：装配 FastAPI 应用，按模型名路由到上游供应商，并提供：
- POST /v1/chat/completions   （OpenAI 协议，支持 prompt 模板扩展与 SSE 透传）
- POST /v1/response           （自定义 HTTP 响应，normal/stream 可切换，Jinja2 渲染）
- GET  /v1/models
- GET  /v1/traces             （请求级全链路 Trace 检索）
- GET  /health
- /api/v1/prompts*            （模板管理，需 PROMPT_MANAGE_ENABLED=true）

启动：
    $env:OPENAI_API_KEY="sk-..."
    python -m uvicorn main:app --reload
"""

from __future__ import annotations

import uuid
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from adapter import shutdown_adapters, startup_adapters
from api.api import api_router
from api.response_api import response_router
from api.trace_api import trace_router
from config.loader import get_app_config
from error import messages
from gateway.observability import get_observability
from gateway.transport import request_timeout
from prompt.audit import get_audit
from router.health import reset_health


def _manage_enabled() -> bool:
    value = (get_app_config().get("gateway") or {}).get("prompt_manage_enabled", False)
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


@asynccontextmanager
async def lifespan(app: FastAPI):
    reset_health()
    audit = get_audit()
    await audit.start()
    observability = get_observability()
    await observability.start()
    await startup_adapters()
    app.state.client = httpx.AsyncClient(timeout=request_timeout())
    try:
        yield
    finally:
        await app.state.client.aclose()
        await shutdown_adapters()
        await observability.stop()
        await audit.stop()


app = FastAPI(title="LLM Gateway", version="0.2.0", lifespan=lifespan)
app.include_router(api_router)
app.include_router(response_router)
app.include_router(trace_router)
if _manage_enabled():
    from api.prompt_api import prompt_router

    app.include_router(prompt_router)


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request_id = request.headers.get("X-Request-Id") or f"req_{uuid.uuid4().hex[:16]}"
    trace_id = request.headers.get("X-Trace-Id") or f"tr_{uuid.uuid4().hex[:16]}"
    request.state.request_id = request_id
    request.state.trace_id = trace_id
    response = await call_next(request)
    response.headers["X-Request-Id"] = request_id
    response.headers["X-Trace-Id"] = trace_id
    return response


@app.exception_handler(HTTPException)
async def openai_style_error(_: Request, exc: HTTPException) -> JSONResponse:
    """把异常统一成 OpenAI 风格的错误结构。"""
    if isinstance(exc.detail, dict) and "error" in exc.detail:
        return JSONResponse(exc.detail, status_code=exc.status_code, headers=exc.headers)
    return JSONResponse(
        {
            "error": {
                "message": str(exc.detail),
                "type": "gateway_error" if exc.status_code >= 500 else "invalid_request_error",
                "code": exc.status_code,
            }
        },
        status_code=exc.status_code,
        headers=exc.headers,
    )


@app.exception_handler(RequestValidationError)
async def response_validation_error(request: Request, exc: RequestValidationError):
    """仅对 /v1/response 把契约错误收敛为 400，其余端点保持 FastAPI 默认行为。"""

    if request.url.path != "/v1/response":
        return await request_validation_exception_handler(request, exc)

    errors = exc.errors()
    message = " ".join(str(item.get("msg", "")) for item in errors)
    lowered = message.lower()

    if "mutually exclusive" in lowered:
        code = "response_body_conflict"
    elif "header" in lowered:
        code = "response_header_invalid"
    elif "stream" in lowered:
        code = "response_stream_invalid"
    else:
        code = "response_invalid"

    safe_errors = jsonable_encoder(errors)

    return JSONResponse(
        {
            "error": {
                "message": messages.RESPONSE_VALIDATION_FAILED,
                "type": "invalid_request_error",
                "code": code,
                "details": {"errors": safe_errors},
            }
        },
        status_code=400,
    )


if __name__ == "__main__":
    import uvicorn

    server = get_app_config().get("server") or {}
    uvicorn.run(
        "main:app",
        host=str(server.get("host") or "0.0.0.0"),
        port=int(server.get("port") or 8000),
    )
