"""统一的 Jinja2 沙箱渲染入口。

所有动态内容（prompt 模板、response 模板）都必须经过本模块渲染：
- 沙箱环境，禁止任意属性逃逸；
- 无 loader，因此 include/extends/import 均不可用；
- 白名单过滤器与受限全局函数；
- 模板大小、渲染结果、循环迭代数三类硬上限。
"""

from __future__ import annotations

import hashlib
import threading
from collections import OrderedDict
from typing import Any, Mapping

from jinja2 import StrictUndefined, TemplateSyntaxError, meta
from jinja2.exceptions import SecurityError, TemplateNotFound, UndefinedError
from jinja2.nodes import Call, Name
from jinja2.sandbox import SandboxedEnvironment
from jinja2.visitor import NodeTransformer

from config.loader import get_prompt_config
from error import messages
from error.base import TemplateRenderError


def _config_int(key: str, default: int) -> int:
    try:
        value = (get_prompt_config().get("templating") or {}).get(key)
        return int(value) if value not in (None, "") else default
    except (TypeError, ValueError):
        return default


MAX_TEMPLATE_BYTES = _config_int("max_template_bytes", 262_144)
MAX_RENDERED_CHARS = _config_int("max_rendered_chars", 16_777_216)
MAX_ITERATIONS = _config_int("max_iterations", 100_000)
CACHE_SIZE = _config_int("cache_size", 128)

_ITER_GUARD = "_gateway_guard_iter"

ALLOWED_FILTERS = frozenset(
    {
        "default",
        "d",
        "replace",
        "trim",
        "upper",
        "lower",
        "title",
        "length",
        "count",
        "join",
        "indent",
        "tojson",
        "e",
        "escape",
    }
)

_ALLOWED_GLOBALS = {"dict": dict, "list": list, "len": len}


class _LoopGuard(NodeTransformer):
    """把每个 for 循环的迭代对象包一层计数守卫。"""

    def visit_For(self, node):  # noqa: N802 - Jinja2 访问器命名
        self.generic_visit(node)
        node.iter = Call(Name(_ITER_GUARD, "load"), [node.iter], [], None, None)
        return node


def _guarded_iter(iterable: Any):
    count = 0
    for item in iterable:
        count += 1
        if count > MAX_ITERATIONS:
            raise TemplateRenderError(
                "template_security_error",
                messages.TEMPLATE_LOOP_LIMIT.format(limit=MAX_ITERATIONS),
            )
        yield item


class GatewayEnvironment(SandboxedEnvironment):
    """在解析阶段注入循环守卫的沙箱环境。"""

    def _parse(self, source, name, filename):
        ast = super()._parse(source, name, filename)
        _LoopGuard().visit(ast)
        return ast


def _build_environment() -> GatewayEnvironment:
    env = GatewayEnvironment(
        undefined=StrictUndefined,
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )
    env.loader = None
    env.globals = dict(_ALLOWED_GLOBALS)
    env.globals[_ITER_GUARD] = _guarded_iter
    env.filters = {name: func for name, func in env.filters.items() if name in ALLOWED_FILTERS}
    return env


_ENV = _build_environment()

_CACHE: "OrderedDict[str, Any]" = OrderedDict()
_CACHE_LOCK = threading.Lock()


def _cache_key(source: str) -> str:
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


def _compile(source: str):
    key = _cache_key(source)
    with _CACHE_LOCK:
        cached = _CACHE.get(key)
        if cached is not None:
            _CACHE.move_to_end(key)
            return cached

    template = _ENV.from_string(source)

    with _CACHE_LOCK:
        _CACHE[key] = template
        while len(_CACHE) > CACHE_SIZE:
            _CACHE.popitem(last=False)
    return template


def clear_cache() -> None:
    with _CACHE_LOCK:
        _CACHE.clear()


def render(source: str, variables: Mapping[str, Any] | None = None, *, media_type: str | None = None) -> str:
    """渲染模板；失败时抛出 TemplateRenderError。"""

    if not isinstance(source, str):
        raise TemplateRenderError("template_render_error", messages.TEMPLATE_SOURCE_NOT_STRING)

    if len(source.encode("utf-8")) > MAX_TEMPLATE_BYTES:
        raise TemplateRenderError(
            "template_too_large",
            messages.TEMPLATE_TOO_LARGE.format(max_bytes=MAX_TEMPLATE_BYTES),
            {"media_type": media_type},
        )

    try:
        template = _compile(source)
    except TemplateSyntaxError as exc:
        raise TemplateRenderError(
            "template_syntax_error", str(exc), {"line": exc.lineno, "name": exc.name}
        ) from exc
    except TemplateRenderError:
        raise
    except Exception as exc:  # noqa: BLE001 - 编译期兜底
        raise TemplateRenderError("template_render_error", str(exc)) from exc

    try:
        output = template.render(dict(variables or {}))
    except TemplateRenderError:
        raise
    except UndefinedError as exc:
        raise TemplateRenderError("template_undefined_variable", str(exc)) from exc
    except SecurityError as exc:
        raise TemplateRenderError("template_security_error", str(exc)) from exc
    except TemplateNotFound as exc:
        raise TemplateRenderError(
            "template_security_error", messages.TEMPLATE_LOADING_DISABLED, {"template": exc.name}
        ) from exc
    except UnicodeDecodeError as exc:  # 非 UTF-8 文本
        raise TemplateRenderError("template_render_error", str(exc)) from exc
    except TypeError as exc:
        if "loader" in str(exc).lower():
            raise TemplateRenderError("template_security_error", messages.TEMPLATE_LOADING_DISABLED) from exc
        raise TemplateRenderError("template_render_error", str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - 渲染期兜底
        raise TemplateRenderError("template_render_error", str(exc)) from exc

    if len(output) > MAX_RENDERED_CHARS:
        raise TemplateRenderError(
            "template_output_too_large",
            messages.TEMPLATE_OUTPUT_TOO_LARGE.format(limit=MAX_RENDERED_CHARS),
        )
    return output


def extract_variable_names(source: str) -> set[str]:
    """提取模板引用的顶层变量名（用于注册期与 Schema 交叉校验）。"""

    try:
        ast = _ENV.parse(source)
    except TemplateSyntaxError as exc:
        raise TemplateRenderError("template_syntax_error", str(exc), {"line": exc.lineno}) from exc

    names = {name.split(".", 1)[0] for name in meta.find_undeclared_variables(ast)}
    return names - set(_ALLOWED_GLOBALS) - {_ITER_GUARD}
