"""模板渲染层：统一的 Jinja2 沙箱入口。"""

from templating.jinja import TemplateRenderError, extract_variable_names, render

__all__ = ["TemplateRenderError", "render", "extract_variable_names"]
