"""供应商有效性前置校验。

在真正转发请求之前检查供应商配置是否可用，避免把必然失败的请求发到上游。
校验维度：启用状态、base_url、上游协议、模态能力、凭据要求。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from urllib.parse import urlsplit

from fastapi import HTTPException

from error import messages
from error.codes import ErrorCode
from error.http import http_error, error_payload
from provider import Provider
from provider.protocols.registry import protocol_names
from router.health import ProviderHealthSnapshot

logger = logging.getLogger(__name__)

CONFIGURATION_ERROR = "configuration_error"
PERMISSION_ERROR = "permission_error"
SERVICE_UNAVAILABLE = "service_unavailable"
MODALITY_NOT_SUPPORTED = "modality_not_supported"


@dataclass(frozen=True)
class ProviderIssue:
    provider: str
    code: str
    error_type: str
    reason: str
    remediation: str
    status_code: int = 503

    def to_dict(self) -> dict[str, str]:
        return {
            "provider": self.provider,
            "code": self.code,
            "error_type": self.error_type,
            "reason": self.reason,
            "remediation": self.remediation,
        }


def _credential_remediation(provider: Provider) -> str:
    return (
        f"check the environment variable referenced by providers.{provider.name}.api_key "
        "and verify the upstream account permissions"
    )


def validate_provider(provider: Provider, modality: str = "chat") -> ProviderIssue | None:
    """返回首个配置级问题；配置有效时返回 None。"""

    if not provider.enabled:
        return ProviderIssue(
            provider=provider.name,
            code=ErrorCode.PROVIDER_DISABLED.value,
            error_type=CONFIGURATION_ERROR,
            reason="provider is disabled",
            remediation=f"set providers.{provider.name}.enabled=true in config/llm.yaml",
        )

    base_url = (provider.base_url or "").strip()
    parsed = urlsplit(base_url)
    if not base_url:
        reason = "base_url is empty"
    elif parsed.scheme not in {"http", "https"} or not parsed.netloc:
        reason = f"base_url {base_url!r} is not a valid http(s) URL"
    else:
        reason = ""
    if reason:
        return ProviderIssue(
            provider=provider.name,
            code=ErrorCode.PROVIDER_CONFIG_INVALID.value,
            error_type=CONFIGURATION_ERROR,
            reason=reason,
            remediation=f"fix providers.{provider.name}.base_url in config/llm.yaml",
        )

    supported = protocol_names()
    if provider.protocol not in supported:
        return ProviderIssue(
            provider=provider.name,
            code=ErrorCode.UNKNOWN_PROTOCOL.value,
            error_type=CONFIGURATION_ERROR,
            reason=f"unknown protocol {provider.protocol!r}; supported: {', '.join(supported)}",
            remediation=f"set providers.{provider.name}.protocol to a registered protocol",
        )

    if modality not in provider.modalities:
        return ProviderIssue(
            provider=provider.name,
            code=ErrorCode.PROVIDER_UNSUPPORTED_MODALITY.value,
            error_type=MODALITY_NOT_SUPPORTED,
            reason=f"modality {modality!r} is not enabled for this provider",
            remediation=f"add {modality!r} to providers.{provider.name}.modalities",
            status_code=400,
        )

    if provider.requires_api_key and not provider.api_key:
        return ProviderIssue(
            provider=provider.name,
            code=ErrorCode.PROVIDER_CREDENTIALS_MISSING.value,
            error_type=PERMISSION_ERROR,
            reason="api_key is not configured",
            remediation=_credential_remediation(provider),
        )

    return None


def provider_issue_error(issue: ProviderIssue) -> HTTPException:
    if issue.code == ErrorCode.PROVIDER_DISABLED.value:
        message = messages.PROVIDER_DISABLED.format(name=issue.provider)
    elif issue.code == ErrorCode.PROVIDER_CREDENTIALS_MISSING.value:
        message = messages.PROVIDER_CREDENTIALS_MISSING.format(name=issue.provider)
    elif issue.code == ErrorCode.PROVIDER_UNSUPPORTED_MODALITY.value:
        message = messages.PROVIDER_UNSUPPORTED_MODALITY.format(name=issue.provider, modality="chat")
    elif issue.code == ErrorCode.UNKNOWN_PROTOCOL.value:
        message = messages.PROVIDER_CONFIG_INVALID.format(name=issue.provider, reason=issue.reason)
    else:
        message = messages.PROVIDER_CONFIG_INVALID.format(name=issue.provider, reason=issue.reason)
    return http_error(
        issue.status_code,
        issue.code,
        message,
        details={
            "provider": issue.provider,
            "error_type": issue.error_type,
            "reason": issue.reason,
            "remediation": issue.remediation,
        },
    )


def health_unavailable_error(snapshots: list[ProviderHealthSnapshot]) -> HTTPException:
    """所有目标供应商均不健康时，返回可定位的供应商错误。"""

    if not snapshots:
        return http_error(
            503,
            ErrorCode.PROVIDER_UNAVAILABLE.value,
            messages.PROVIDER_UNAVAILABLE.format(name="unknown", reason="no healthy provider"),
            details={
                "provider": None,
                "error_type": SERVICE_UNAVAILABLE,
                "reason": "no healthy provider",
                "remediation": "check provider health and fallback configuration",
            },
        )

    auth_snapshot = next(
        (item for item in snapshots if item.last_error_type == "auth"), None
    )
    primary = auth_snapshot or snapshots[0]
    if auth_snapshot is not None:
        code = ErrorCode.PROVIDER_AUTH_INVALID.value
        error_type = PERMISSION_ERROR
        reason = auth_snapshot.reason or "upstream credentials were rejected"
        remediation = _credential_remediation_by_name(auth_snapshot.provider)
        message = messages.PROVIDER_AUTH_INVALID.format(name=primary.provider, reason=reason)
    else:
        code = ErrorCode.PROVIDER_UNAVAILABLE.value
        error_type = SERVICE_UNAVAILABLE
        reason = primary.reason or "provider health is below the configured threshold"
        remediation = (
            "wait for the cooldown window, then verify upstream availability and credentials; "
            "configure a healthy fallback provider if needed"
        )
        message = messages.PROVIDER_UNAVAILABLE.format(name=primary.provider, reason=reason)

    payload = error_payload(
        503,
        code,
        message,
        {
            "provider": primary.provider,
            "error_type": error_type,
            "reason": reason,
            "remediation": remediation,
            "providers": [item.to_dict() for item in snapshots],
        },
    )
    return HTTPException(503, payload)


def _credential_remediation_by_name(name: str) -> str:
    return (
        f"check the environment variable referenced by providers.{name}.api_key "
        "and verify the upstream account permissions"
    )


def validate_targets(targets: list) -> list:
    """校验全部目标；主目标配置错误立即抛出，备用目标配置错误仅剔除。"""

    valid: list = []
    for index, target in enumerate(targets):
        issue = validate_provider(target.provider)
        if issue is None:
            valid.append(target)
            continue
        if index == 0:
            raise provider_issue_error(issue)
        logger.warning(
            "fallback provider %r is invalid and will be skipped: %s",
            target.provider.name,
            issue.reason,
        )
    return valid
