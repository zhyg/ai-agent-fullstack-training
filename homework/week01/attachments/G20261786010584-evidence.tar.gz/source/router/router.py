"""路由层：决定请求落到哪个供应商与上游模型。"""

from __future__ import annotations

from fastapi import HTTPException

from config.loader import get_llm_config
from error import messages
from provider import Provider, get_default_provider, get_provider


def get_model_aliases() -> dict[str, tuple[str, str]]:
    """从配置读取对外模型别名 -> (供应商名, 上游真实模型名)。

    支持两种写法：
      gpt-4o-mini: {provider: openai, model: gpt-4o-mini}
      deepseek-chat: deepseek/deepseek-chat
    """

    raw = get_llm_config().get("models") or {}
    aliases: dict[str, tuple[str, str]] = {}
    for name, item in raw.items():
        if isinstance(item, str):
            provider_name, upstream = _split(item)
        else:
            provider_name = str(item.get("provider") or get_default_provider())
            upstream = str(item.get("model") or name)
        aliases[str(name)] = (provider_name, upstream)
    return aliases


def _split(value: str) -> tuple[str, str]:
    if "/" in value:
        provider_name, upstream = value.split("/", 1)
        return provider_name, upstream
    return get_default_provider(), value


def resolve_model(model: str) -> tuple[Provider, str]:
    """根据客户端传入的 model 解析出供应商与上游模型名。

    支持三种写法：别名（配置 models）、"provider/upstream"、直接透传。
    """

    aliases = get_model_aliases()
    if model in aliases:
        provider_name, upstream_model = aliases[model]
    elif "/" in model and get_provider(model.split("/", 1)[0]) is not None:
        provider_name, upstream_model = model.split("/", 1)
    else:
        provider_name, upstream_model = get_default_provider(), model

    provider = get_provider(provider_name)
    if provider is None:
        raise HTTPException(400, messages.UNKNOWN_PROVIDER.format(provider=provider_name))
    return provider, upstream_model


def select_provider(model: str, override: str | None = None) -> tuple[Provider, str]:
    """解析请求目标；override（网关扩展字段 provider）优先于模型名推断。"""

    provider, upstream_model = resolve_model(model)
    if override:
        provider = get_provider(override) or provider
    return provider, upstream_model
