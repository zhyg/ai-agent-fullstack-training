"""供应商健康度：滑动窗口失败率 + 连续失败 + 冷却期。

规则：
- 连续失败达到阈值，或滑动窗口内失败率达到阈值（样本数达标）时，判定为不健康；
- 鉴权类失败（401/403）立即判定为不健康，并进入更长的冷却期；
- 模型类（model）与 Prompt 类错误与供应商整体可用性无关，不计入健康度；
- 冷却期结束后自动恢复为可探测状态，成功一次即清零连续失败次数。
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, Iterable

from config.loader import get_runtime_config
from gateway.resilience import ErrorCategory, Target
from provider import Provider


class HealthStatus(StrEnum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


def _to_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _to_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _to_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class HealthPolicy:
    enabled: bool = True
    failure_threshold: int = 3
    failure_rate_threshold: float = 0.5
    min_samples: int = 5
    window_size: int = 20
    cooldown_seconds: int = 60
    auth_cooldown_seconds: int = 300

    @classmethod
    def from_config(cls) -> "HealthPolicy":
        raw = get_runtime_config().get("health") or {}
        return cls(
            enabled=_to_bool(raw.get("enabled"), True),
            failure_threshold=max(1, _to_int(raw.get("failure_threshold"), 3)),
            failure_rate_threshold=max(0.0, min(1.0, _to_float(raw.get("failure_rate_threshold"), 0.5))),
            min_samples=max(1, _to_int(raw.get("min_samples"), 5)),
            window_size=max(1, _to_int(raw.get("window_size"), 20)),
            cooldown_seconds=max(0, _to_int(raw.get("cooldown_seconds"), 60)),
            auth_cooldown_seconds=max(0, _to_int(raw.get("auth_cooldown_seconds"), 300)),
        )


@dataclass(frozen=True)
class ProviderHealthSnapshot:
    provider: str
    status: HealthStatus
    score: float
    healthy: bool
    reason: str | None
    consecutive_failures: int
    sample_size: int
    failure_rate: float
    cooldown_remaining_s: float
    last_error_type: str | None
    last_failure_at: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "status": self.status.value,
            "score": self.score,
            "healthy": self.healthy,
            "reason": self.reason,
            "consecutive_failures": self.consecutive_failures,
            "sample_size": self.sample_size,
            "failure_rate": round(self.failure_rate, 4),
            "cooldown_remaining_s": round(self.cooldown_remaining_s, 1),
            "last_error_type": self.last_error_type,
            "last_failure_at": self.last_failure_at,
        }


@dataclass
class _ProviderState:
    window: deque[bool] = field(default_factory=lambda: deque(maxlen=20))
    consecutive_failures: int = 0
    total_successes: int = 0
    total_failures: int = 0
    last_error_type: str | None = None
    last_failure_at: str | None = None
    cooldown_until: float = 0.0


def _provider_name(provider: Provider | str) -> str:
    return provider.name if isinstance(provider, Provider) else str(provider)


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


class ProviderHealthRegistry:
    def __init__(self) -> None:
        self._states: dict[str, _ProviderState] = {}
        self._lock = threading.Lock()

    def _state(self, name: str, policy: HealthPolicy) -> _ProviderState:
        state = self._states.get(name)
        if state is None:
            state = _ProviderState(window=deque(maxlen=policy.window_size))
            self._states[name] = state
        return state

    def record_success(self, provider: Provider | str) -> None:
        name = _provider_name(provider)
        policy = HealthPolicy.from_config()
        with self._lock:
            state = self._state(name, policy)
            state.total_successes += 1
            state.consecutive_failures = 0
            state.cooldown_until = 0.0
            state.window.append(True)

    def record_failure(
        self,
        provider: Provider | str,
        category: ErrorCategory | str | None = None,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
    ) -> None:
        """记录一次供应商级失败；模型类与 Prompt 类错误不影响供应商健康度。"""

        category_value = category.value if isinstance(category, ErrorCategory) else str(category or "unknown")
        if category_value in {ErrorCategory.MODEL.value, ErrorCategory.PROMPT_MISSING.value}:
            return

        name = _provider_name(provider)
        policy = HealthPolicy.from_config()
        now = time.monotonic()
        with self._lock:
            state = self._state(name, policy)
            state.total_failures += 1
            state.consecutive_failures += 1
            state.last_error_type = category_value
            state.last_failure_at = _now_iso()
            state.window.append(False)

            failure_rate = _failure_rate(state)
            breached = state.consecutive_failures >= policy.failure_threshold
            if state.window and len(state.window) >= policy.min_samples:
                breached = breached or failure_rate >= policy.failure_rate_threshold

            if category_value == ErrorCategory.AUTH.value:
                # 权限失效立即熔断，避免持续向上游发送无效凭据。
                state.consecutive_failures = max(state.consecutive_failures, policy.failure_threshold)
                state.cooldown_until = max(state.cooldown_until, now + policy.auth_cooldown_seconds)
            elif breached:
                state.cooldown_until = max(state.cooldown_until, now + policy.cooldown_seconds)

    def snapshot(self, provider: Provider | str) -> ProviderHealthSnapshot:
        name = _provider_name(provider)
        policy = HealthPolicy.from_config()
        if not policy.enabled:
            return ProviderHealthSnapshot(
                provider=name,
                status=HealthStatus.HEALTHY,
                score=100.0,
                healthy=True,
                reason=None,
                consecutive_failures=0,
                sample_size=0,
                failure_rate=0.0,
                cooldown_remaining_s=0.0,
                last_error_type=None,
                last_failure_at=None,
            )

        now = time.monotonic()
        with self._lock:
            state = self._state(name, policy)
            sample_size = len(state.window)
            failure_rate = _failure_rate(state)
            cooldown = max(0.0, state.cooldown_until - now)
            consecutive = state.consecutive_failures
            last_error = state.last_error_type
            last_failure = state.last_failure_at

            if cooldown > 0:
                status = HealthStatus.UNHEALTHY
                reason = f"cooldown active for {cooldown:.1f}s after {last_error or 'failure'}"
            elif consecutive >= policy.failure_threshold:
                status = HealthStatus.UNHEALTHY
                reason = f"{consecutive} consecutive failures (threshold {policy.failure_threshold})"
            elif sample_size >= policy.min_samples and failure_rate >= policy.failure_rate_threshold:
                status = HealthStatus.UNHEALTHY
                reason = (
                    f"failure rate {failure_rate:.0%} over {sample_size} samples "
                    f"(threshold {policy.failure_rate_threshold:.0%})"
                )
            elif consecutive > 0 or (
                sample_size > 0 and failure_rate >= policy.failure_rate_threshold / 2
            ):
                status = HealthStatus.DEGRADED
                reason = f"recent failure rate {failure_rate:.0%} over {sample_size} samples"
            else:
                status = HealthStatus.HEALTHY
                reason = None

            score = 100.0 - failure_rate * 70.0 - min(consecutive, 5) * 6.0
            if cooldown > 0:
                score = 0.0

        return ProviderHealthSnapshot(
            provider=name,
            status=status,
            score=round(max(0.0, min(100.0, score)), 1),
            healthy=status is not HealthStatus.UNHEALTHY,
            reason=reason,
            consecutive_failures=consecutive,
            sample_size=sample_size,
            failure_rate=failure_rate,
            cooldown_remaining_s=cooldown,
            last_error_type=last_error,
            last_failure_at=last_failure,
        )

    def order_targets(
        self, targets: Iterable[Target]
    ) -> tuple[list[Target], list[ProviderHealthSnapshot]]:
        """过滤不健康供应商，返回可用目标与被排除供应商快照。"""

        candidates = list(targets)
        snapshots = {target.provider.name: self.snapshot(target.provider) for target in candidates}
        healthy = [target for target in candidates if snapshots[target.provider.name].healthy]
        excluded = [snapshots[name] for name in snapshots if not snapshots[name].healthy]
        return healthy, excluded

    def reset(self) -> None:
        with self._lock:
            self._states.clear()


def _failure_rate(state: _ProviderState) -> float:
    if not state.window:
        return 0.0
    failures = sum(1 for ok in state.window if not ok)
    return failures / len(state.window)


_registry: ProviderHealthRegistry | None = None


def get_health_registry() -> ProviderHealthRegistry:
    global _registry
    if _registry is None:
        _registry = ProviderHealthRegistry()
    return _registry


def record_provider_success(provider: Provider | str) -> None:
    get_health_registry().record_success(provider)


def record_provider_failure(
    provider: Provider | str,
    category: ErrorCategory | str | None = None,
    *,
    status_code: int | None = None,
    error_code: str | None = None,
) -> None:
    get_health_registry().record_failure(
        provider, category, status_code=status_code, error_code=error_code
    )


def reset_health() -> None:
    get_health_registry().reset()
