"""Response 分支：契约模型与校验。"""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from error import messages

_HEADER_NAME_RE = re.compile(r"^[A-Za-z0-9!#$%&'*+.^_`|~-]+$")
_MEDIA_TYPE_RE = r"^[A-Za-z0-9.+-]+/[A-Za-z0-9.+-]+(; charset=[A-Za-z0-9_-]+)?$"

FORBIDDEN_HEADERS = frozenset(
    {
        "content-length",
        "transfer-encoding",
        "connection",
        "host",
        "upgrade",
        "keep-alive",
    }
)

MAX_HEADER_BYTES = 16_384
MAX_HEADER_VALUE_BYTES = 8_192


class ResponseMode(StrEnum):
    NORMAL = "normal"
    STREAM = "stream"


class StreamOptions(BaseModel):
    model_config = ConfigDict(extra="forbid")

    chunk_size: int = Field(default=1024, ge=1, le=65536)
    event: str | None = Field(default=None, pattern=r"^[A-Za-z0-9_-]{1,64}$")
    include_id: bool = False
    retry_ms: int | None = Field(default=None, ge=0, le=60000)
    include_done: bool = True
    heartbeat_ms: int | None = Field(default=None, ge=1000, le=60000)


def has_control_chars(value: str) -> bool:
    return any(ord(ch) < 0x20 or ord(ch) == 0x7f for ch in value)


def validate_headers(headers: dict[str, str]) -> None:
    """校验响应头合法性；非法时抛出 ValueError（由契约层转换为 400）。"""

    total = 0
    for name, value in headers.items():
        if not _HEADER_NAME_RE.match(name):
            raise ValueError(messages.RESPONSE_HEADER_NAME_INVALID.format(name=name))
        if name.lower() in FORBIDDEN_HEADERS or name.lower().startswith("proxy-"):
            raise ValueError(messages.RESPONSE_HEADER_MANAGED.format(name=name))
        if not isinstance(value, str):
            raise ValueError(messages.RESPONSE_HEADER_VALUE_TYPE.format(name=name))
        if has_control_chars(value):
            raise ValueError(messages.RESPONSE_HEADER_CONTROL_CHARS.format(name=name))
        if len(value.encode("utf-8")) > MAX_HEADER_VALUE_BYTES:
            raise ValueError(messages.RESPONSE_HEADER_VALUE_TOO_LARGE.format(name=name))
        total += len(name.encode("utf-8")) + len(value.encode("utf-8"))
    if total > MAX_HEADER_BYTES:
        raise ValueError(messages.RESPONSE_HEADERS_TOO_LARGE)


class ResponseRequest(BaseModel):
    """POST /v1/response 的请求契约。"""

    model_config = ConfigDict(extra="forbid")

    status_code: int = Field(default=200, ge=100, le=599)
    headers: dict[str, str] = Field(default_factory=dict)
    body: Any = None
    template: str | None = Field(default=None, max_length=262_144)
    variables: dict[str, Any] = Field(default_factory=dict)
    variables_schema: dict[str, Any] | None = None
    media_type: str | None = Field(default=None, pattern=_MEDIA_TYPE_RE)
    mode: ResponseMode = ResponseMode.NORMAL
    stream: StreamOptions = Field(default_factory=StreamOptions)

    @model_validator(mode="after")
    def _check(self) -> "ResponseRequest":
        if self.body is not None and self.template is not None:
            raise ValueError(messages.RESPONSE_BODY_TEMPLATE_CONFLICT)
        validate_headers(self.headers)
        if self.mode is ResponseMode.STREAM:
            if not 200 <= self.status_code < 300:
                raise ValueError(messages.RESPONSE_STREAM_STATUS)
            content_type = self.content_type
            if content_type is not None and content_type.split(";", 1)[0].strip().lower() != "text/event-stream":
                raise ValueError(messages.RESPONSE_STREAM_CONTENT_TYPE)
        return self

    @property
    def content_type(self) -> str | None:
        for name, value in self.headers.items():
            if name.lower() == "content-type":
                return value
        return self.media_type
