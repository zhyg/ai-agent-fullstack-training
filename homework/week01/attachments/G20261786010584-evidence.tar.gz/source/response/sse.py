"""SSE 编码与分块工具。"""

from __future__ import annotations

import json
from typing import Any, Iterator


def encode_sse(
    data: str | None = None,
    *,
    event: str | None = None,
    event_id: str | None = None,
    retry: int | None = None,
    comment: str | None = None,
) -> str:
    """按 SSE 规范编码单个事件。

    顺序固定为 retry → id → event → data；多行 data 拆成多条 data: 行。
    """

    if comment is not None:
        return f": {comment}\n\n"

    lines: list[str] = []
    if retry is not None:
        lines.append(f"retry: {int(retry)}")
    if event_id is not None:
        lines.append(f"id: {event_id}")
    if event is not None:
        lines.append(f"event: {event}")
    if data is not None:
        for line in str(data).replace("\r\n", "\n").replace("\r", "\n").split("\n"):
            lines.append(f"data: {line}")
    return "\n".join(lines) + "\n\n"


def encode_event_json(payload: dict[str, Any], *, event: str, event_id: str | None = None) -> str:
    return encode_sse(json.dumps(payload, ensure_ascii=False), event=event, event_id=event_id)


def iter_chunks(text: str, chunk_size: int) -> Iterator[str]:
    """按字符切片，避免一次性构造额外大对象。"""

    size = max(1, chunk_size)
    for start in range(0, len(text), size):
        yield text[start : start + size]
