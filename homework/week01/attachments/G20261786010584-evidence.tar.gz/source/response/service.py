"""Response 分支：普通响应与 SSE 生命周期。"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any, AsyncIterator

from fastapi import Request
from fastapi.responses import Response, StreamingResponse

from error import messages
from error.base import PromptError, TemplateRenderError
from error.http import response_http_error
from response.models import ResponseMode, ResponseRequest, StreamOptions
from response.sse import encode_event_json, encode_sse, iter_chunks
from templating import render

logger = logging.getLogger(__name__)

SSE_MEDIA_TYPE = "text/event-stream; charset=utf-8"
SSE_DEFAULT_HEADERS = {
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


def resolve_mode(payload: ResponseRequest, query_mode: str | None) -> ResponseMode:
    """模式切换优先级：query > body > normal。"""

    if query_mode:
        try:
            return ResponseMode(query_mode)
        except ValueError as exc:
            raise response_http_error(
                400,
                "response_invalid",
                messages.RESPONSE_UNKNOWN_MODE.format(mode=query_mode),
            ) from exc
    return payload.mode


def _render_body(payload: ResponseRequest) -> tuple[str, bool]:
    """返回 (body 文本, 是否来自模板)。"""

    if payload.template is not None:
        try:
            return render(payload.template, payload.variables), True
        except TemplateRenderError as exc:
            status = 500 if exc.code in {"template_render_error"} else 400
            raise response_http_error(status, exc.code, exc.message, exc.details) from exc

    body = payload.body
    if body is None:
        return "", False
    if isinstance(body, str):
        return body, False
    return json.dumps(body, ensure_ascii=False), False


def _validate_variables(payload: ResponseRequest) -> None:
    if payload.variables_schema is None:
        return

    from prompt.models import VariablesSchema
    from prompt.schema import validate_variables

    try:
        schema = VariablesSchema.model_validate(payload.variables_schema)
        validate_variables(schema, payload.variables)
    except PromptError as exc:
        raise response_http_error(exc.status_code, exc.code, exc.message, exc.details) from exc
    except Exception as exc:  # noqa: BLE001 - 契约解析失败
        raise response_http_error(400, "response_invalid", str(exc)) from exc


def _resolve_media_type(payload: ResponseRequest, from_template: bool) -> str:
    if payload.content_type is not None:
        return payload.content_type
    if from_template or isinstance(payload.body, str) or payload.body is None:
        return "text/plain; charset=utf-8"
    return "application/json; charset=utf-8"


def _headers_without_content_type(headers: dict[str, str]) -> dict[str, str]:
    return {name: value for name, value in headers.items() if name.lower() != "content-type"}


async def event_stream(
    request: Request,
    content: str,
    options: StreamOptions,
    *,
    media_type: str = SSE_MEDIA_TYPE,
) -> AsyncIterator[str]:
    """SSE 生命周期：可选 retry → 分块推送（含断连检测/心跳）→ done。"""

    if options.retry_ms:
        yield encode_sse(retry=options.retry_ms)

    last_sent = time.monotonic()
    try:
        for index, chunk in enumerate(iter_chunks(content, options.chunk_size)):
            if await request.is_disconnected():
                logger.info("sse client disconnected at chunk %s", index)
                return
            if options.heartbeat_ms and (time.monotonic() - last_sent) * 1000 >= options.heartbeat_ms:
                yield encode_sse(comment="ping")
            yield encode_sse(
                chunk,
                event=options.event,
                event_id=str(index) if options.include_id else None,
            )
            last_sent = time.monotonic()
            await asyncio.sleep(0)

        if await request.is_disconnected():
            return
        if options.include_done:
            yield encode_sse("[DONE]", event="done")
    except asyncio.CancelledError:
        logger.info("sse cancelled by client")
        raise
    except Exception as exc:  # noqa: BLE001 - 已发送首块后尽力通知
        logger.exception("sse streaming failed")
        yield encode_event_json(
            {"code": messages.RESPONSE_STREAM_ERROR_CODE, "message": str(exc)},
            event="error",
        )


async def build_response(
    payload: ResponseRequest,
    request: Request,
    *,
    query_mode: str | None = None,
) -> Response:
    mode = resolve_mode(payload, query_mode)

    _validate_variables(payload)
    body, from_template = _render_body(payload)

    if mode is ResponseMode.NORMAL:
        media_type = _resolve_media_type(payload, from_template)
        headers = _headers_without_content_type(payload.headers)
        return Response(content=body, status_code=payload.status_code, headers=headers, media_type=media_type)

    headers = dict(SSE_DEFAULT_HEADERS)
    headers.update(_headers_without_content_type(payload.headers))
    return StreamingResponse(
        event_stream(request, body, payload.stream),
        status_code=payload.status_code,
        headers=headers,
        media_type=SSE_MEDIA_TYPE,
    )
