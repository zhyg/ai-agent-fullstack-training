"""请求级全链路 Trace：采集、结构化落盘与检索。

每条 trace 对应一次模型请求，字段覆盖：
- trace_id / request_id 与业务 ID；
- 请求开始、结束/失败时间与总耗时；
- 供应商、客户端模型、上游模型、流式标记；
- 输入/输出 token；
- Prompt 模板 ID、版本与模板内容；
- 执行状态、服务运行状态、错误码与 HTTP 状态；
- 每次上游尝试的供应商、模型、耗时与结果。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Mapping

from gateway.observability import get_observability
from gateway.status import ExecutionStatus

TRACE_FILENAME = "request_traces.jsonl"

_HEADER_BUSINESS_IDS = {
    "x-business-id": "business_id",
    "x-session-id": "session_id",
    "x-user-id": "user_id",
    "x-tenant-id": "tenant_id",
    "x-conversation-id": "conversation_id",
    "x-request-id": "request_id",
}


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _clip(value: Any, limit: int) -> Any:
    if isinstance(value, str):
        return value if len(value) <= limit else value[:limit] + "...<truncated>"
    if isinstance(value, dict):
        return {key: _clip(item, limit) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clip(item, limit) for item in value]
    return value


def collect_business_ids(headers: Mapping[str, str], *, user: str | None = None) -> dict[str, Any]:
    """从请求头收集业务 ID，并支持 X-Business-Ids 传入 JSON 对象。"""

    ids: dict[str, Any] = {}
    for header, key in _HEADER_BUSINESS_IDS.items():
        value = headers.get(header)
        if value:
            ids[key] = value[:512]

    raw = headers.get("x-business-ids")
    if raw:
        try:
            parsed = json.loads(raw)
        except (TypeError, ValueError):
            parsed = None
        if isinstance(parsed, dict):
            for key, value in parsed.items():
                if value is not None:
                    ids[str(key)] = value

    if user:
        ids.setdefault("user_id", user)
    return ids


@dataclass
class TraceContext:
    trace_id: str
    request_id: str
    business_ids: dict[str, Any]
    stream: bool
    started_at: str = field(default_factory=_now_iso)
    started_perf: float = field(default_factory=time.perf_counter)

    provider: str | None = None
    client_model: str | None = None
    upstream_model: str | None = None

    prompt_template_id: str | None = None
    prompt_template_version: int | None = None
    prompt_template_content: dict[str, Any] | None = None

    prompt_tokens: int = 0
    completion_tokens: int = 0
    attempts: list[dict[str, Any]] = field(default_factory=list)
    degradation_reasons: list[str] = field(default_factory=list)
    cached: bool = False
    fallback_used: bool = False

    _finished: bool = field(default=False, repr=False)
    _record: dict[str, Any] | None = field(default=None, repr=False)

    def set_route(self, *, provider: str, client_model: str, upstream_model: str) -> None:
        self.provider = provider
        self.client_model = client_model
        self.upstream_model = upstream_model

    def set_prompt(self, prepared: Any) -> None:
        if prepared is None:
            return
        self.prompt_template_id = prepared.template_id
        self.prompt_template_version = prepared.version
        self.prompt_template_content = {
            "system": prepared.template_system,
            "user_template": prepared.template_user,
        }

    def set_usage(self, prompt_tokens: int, completion_tokens: int) -> None:
        self.prompt_tokens = max(0, int(prompt_tokens))
        self.completion_tokens = max(0, int(completion_tokens))

    def mark_degraded(self, reason: str) -> None:
        if reason not in self.degradation_reasons:
            self.degradation_reasons.append(reason)
        if reason == "fallback":
            self.fallback_used = True
        if reason == "cache":
            self.cached = True

    def add_attempt(
        self,
        *,
        provider: str,
        model: str,
        role: str,
        attempt: int,
        status: str,
        duration_ms: float,
        error_code: str | None = None,
    ) -> None:
        if len(self.attempts) >= 20:
            return
        self.attempts.append(
            {
                "provider": provider,
                "model": model,
                "role": role,
                "attempt": attempt,
                "status": status,
                "duration_ms": round(duration_ms, 3),
                "error_code": error_code,
            }
        )

    def finish(
        self,
        status: ExecutionStatus | str,
        *,
        error_code: str | None = None,
        http_status: int | None = None,
    ) -> None:
        if self._finished:
            return
        self._finished = True
        status_value = status.value if isinstance(status, ExecutionStatus) else str(status)
        ended_at = _now_iso()
        duration_ms = round((time.perf_counter() - self.started_perf) * 1000, 3)

        if status_value == ExecutionStatus.COMPLETED.value:
            service_status = "degraded" if self.degradation_reasons else "healthy"
        else:
            service_status = "failed"

        limit = get_observability().max_field_chars
        self._record = {
            "trace_id": self.trace_id,
            "request_id": self.request_id,
            "service_status": service_status,
            "status": status_value,
            "business_ids": _clip(self.business_ids, limit),
            "provider": self.provider,
            "client_model": self.client_model,
            "upstream_model": self.upstream_model,
            "stream": self.stream,
            "started_at": self.started_at,
            "ended_at": ended_at,
            "duration_ms": duration_ms,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.prompt_tokens + self.completion_tokens,
            "prompt_template_id": self.prompt_template_id,
            "prompt_template_version": self.prompt_template_version,
            "prompt_template_content": _clip(self.prompt_template_content, limit),
            "error_code": error_code,
            "http_status": http_status,
            "attempts": _clip(self.attempts, limit),
            "degradation_reasons": self.degradation_reasons,
            "fallback_used": self.fallback_used,
            "cached": self.cached,
        }
        get_trace_store().append(self._record)

    @property
    def record(self) -> dict[str, Any] | None:
        return self._record


def start_trace(
    *,
    trace_id: str,
    request_id: str,
    business_ids: dict[str, Any],
    stream: bool,
) -> TraceContext:
    return TraceContext(
        trace_id=trace_id,
        request_id=request_id,
        business_ids=business_ids,
        stream=stream,
    )


def _parse_time(value: str | datetime | None) -> float | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.timestamp()
    text = str(value).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(text).timestamp()
    except ValueError as exc:
        raise ValueError(f"invalid timestamp {value!r}") from exc


class TraceStore:
    """JSONL 持久化与按 trace_id / request_id / provider / 时间范围检索。"""

    def append(self, record: dict[str, Any]) -> None:
        get_observability().record_trace(record)

    def _files(self) -> list[Path]:
        obs = get_observability()
        current = obs.trace_dir / TRACE_FILENAME
        rotated = current.with_name(current.name + ".1")
        return [path for path in (rotated, current) if path.is_file()]

    def query(
        self,
        *,
        trace_id: str | None = None,
        request_id: str | None = None,
        provider: str | None = None,
        start: str | datetime | None = None,
        end: str | datetime | None = None,
        status: str | None = None,
        service_status: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> tuple[list[dict[str, Any]], int]:
        obs = get_observability()
        if not obs.trace_enabled:
            return [], 0

        start_ts = _parse_time(start)
        end_ts = _parse_time(end)
        if start_ts is not None and end_ts is not None and start_ts > end_ts:
            raise ValueError("start must be earlier than end")

        records: list[tuple[float, dict[str, Any]]] = []
        for path in self._files():
            try:
                with path.open("r", encoding="utf-8") as handle:
                    for line in handle:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            record = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if not isinstance(record, dict):
                            continue
                        if trace_id and record.get("trace_id") != trace_id:
                            continue
                        if request_id and record.get("request_id") != request_id:
                            continue
                        if provider and record.get("provider") != provider:
                            continue
                        if status and record.get("status") != status:
                            continue
                        if service_status and record.get("service_status") != service_status:
                            continue
                        try:
                            record_ts = _parse_time(record.get("started_at")) or 0.0
                        except ValueError:
                            record_ts = 0.0
                        if start_ts is not None and record_ts < start_ts:
                            continue
                        if end_ts is not None and record_ts > end_ts:
                            continue
                        records.append((record_ts, record))
            except OSError:
                continue

        records.sort(key=lambda item: item[0], reverse=True)
        total = len(records)
        safe_offset = max(0, int(offset))
        safe_limit = max(1, min(1000, int(limit)))
        page = [record for _, record in records[safe_offset : safe_offset + safe_limit]]
        return page, total


_store: TraceStore | None = None


def get_trace_store() -> TraceStore:
    global _store
    if _store is None:
        _store = TraceStore()
    return _store
