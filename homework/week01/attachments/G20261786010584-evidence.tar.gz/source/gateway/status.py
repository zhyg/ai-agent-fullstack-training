"""执行状态枚举：流式输出与请求指标只允许 completed / failed / cancelled 三种取值。"""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from error.messages import INVALID_EXECUTION_STATUS
from error.status import InvalidExecutionStatusError

ALLOWED_STATUSES = ("completed", "failed", "cancelled")


class ExecutionStatus(StrEnum):
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


def normalize_status(value: Any) -> ExecutionStatus:
    """把外部传入状态转换为合法枚举，非法值直接报错。"""

    try:
        return ExecutionStatus(str(value))
    except ValueError as exc:
        raise InvalidExecutionStatusError(
            INVALID_EXECUTION_STATUS.format(value=value, allowed=", ".join(ALLOWED_STATUSES))
        ) from exc
