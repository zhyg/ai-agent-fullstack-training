"""HTTP 传输：拼接上游地址、构造请求头并发送请求。"""

from __future__ import annotations

from typing import Any

import httpx

from config.loader import get_llm_config
from provider import Provider


def request_timeout() -> httpx.Timeout:
    """从大模型配置读取超时参数；每次请求读取，支持热更新。"""

    config = get_llm_config().get("timeouts") or {}
    total = float(config.get("total_seconds") or 600.0)
    connect = float(config.get("connect_seconds") or 10.0)
    return httpx.Timeout(total, connect=connect)


def endpoint_url(provider: Provider, path: str) -> str:
    return f"{provider.base_url}/{path.lstrip('/')}"


def build_headers(provider: Provider) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if provider.api_key:
        headers["Authorization"] = f"Bearer {provider.api_key}"
    return headers


async def post_json(
    client: httpx.AsyncClient,
    provider: Provider,
    path: str,
    payload: dict[str, Any],
    headers: dict[str, str] | None = None,
) -> httpx.Response:
    """非流式请求上游，返回原始响应，状态码交给调用方判断。"""

    return await client.post(
        endpoint_url(provider, path),
        json=payload,
        headers=headers or build_headers(provider),
        timeout=request_timeout(),
    )


async def send_stream(
    client: httpx.AsyncClient,
    provider: Provider,
    path: str,
    payload: dict[str, Any],
    headers: dict[str, str] | None = None,
) -> httpx.Response:
    """发起流式请求但不读取响应体，返回可逐行迭代的上游响应。"""

    return await client.send(
        client.build_request(
            "POST",
            endpoint_url(provider, path),
            json=payload,
            headers=headers or build_headers(provider),
            timeout=request_timeout(),
        ),
        stream=True,
    )
