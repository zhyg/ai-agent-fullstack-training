"""运行时配置、全链路埋点与请求指标持久化。

- 埋点：每个关键节点记录入参、出参、耗时、异常，追加写入 traces.txt；
- 指标：按请求模式记录 token 总量、模式起止时间、TTFT、request_id、执行状态，写入 metrics.txt；
- 两者均通过后台队列异步落盘，队列满或写盘失败只记日志，不影响主请求流程。
"""

from __future__ import annotations

import asyncio
import contextlib
import contextvars
import json
import logging
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterator

from config.loader import get_runtime_config
from gateway.status import ExecutionStatus, normalize_status

logger = logging.getLogger(__name__)

_DEFAULT_MAX_FIELD_CHARS = 4096
_DEFAULT_MAX_FILE_BYTES = 5 * 1024 * 1024
_DEFAULT_QUEUE_SIZE = 2048

_observability: "Observability | None" = None
_current_request: contextvars.ContextVar[str | None] = contextvars.ContextVar("gateway_request_id", default=None)


# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------


def _config_int(section: str, key: str, default: int) -> int:
    """从 runtime.yaml 读取整数配置，非法或缺失时回退默认值。"""

    try:
        value = (get_runtime_config().get(section) or {}).get(key)
        return int(value) if value not in (None, "") else default
    except (TypeError, ValueError):
        return default


def _observability_limits() -> tuple[int, int, int]:
    """返回 (单字段截断长度, 单文件轮转阈值, 异步队列容量)。"""

    section = "observability"
    return (
        _config_int(section, "max_field_chars", _DEFAULT_MAX_FIELD_CHARS),
        _config_int(section, "max_file_bytes", _DEFAULT_MAX_FILE_BYTES),
        _config_int(section, "queue_size", _DEFAULT_QUEUE_SIZE),
    )


def _to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _snip(value: Any, limit: int | None = None) -> Any:
    """把任意对象压缩成可读且限长的 JSON 结构，避免日志无限膨胀。"""

    if limit is None:
        limit = _observability_limits()[0]
    if value is None or isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, str):
        return value if len(value) <= limit else value[:limit] + "...<truncated>"
    if isinstance(value, bytes):
        return _snip(value.decode("utf-8", "ignore"), limit)
    try:
        text = json.dumps(value, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        text = str(value)
    if len(text) <= limit:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text
    return text[:limit] + "...<truncated>"


# ---------------------------------------------------------------------------
# 埋点跨度
# ---------------------------------------------------------------------------


class ManualSpan:
    """可手动结束的埋点节点，用于流式等跨 yield 的场景。"""

    def __init__(self, observability: "Observability", name: str, inputs: dict[str, Any]) -> None:
        self._observability = observability
        self.name = name
        self.inputs = inputs
        self.outputs: dict[str, Any] = {}
        self.request_id = _current_request.get()
        self.started_at = _now_iso()
        self._started_perf = time.perf_counter()
        self._ended = False

    def output(self, **values: Any) -> None:
        self.outputs.update(values)

    def end(self, status: ExecutionStatus | str, error: str | None = None) -> None:
        if self._ended:
            return
        self._ended = True
        duration_ms = round((time.perf_counter() - self._started_perf) * 1000, 3)
        self._observability._emit(
            "span",
            {
                "ts": self.started_at,
                "request_id": self.request_id,
                "span": self.name,
                "status": normalize_status(status).value,
                "started_at": self.started_at,
                "ended_at": _now_iso(),
                "duration_ms": duration_ms,
                "inputs": _snip(self.inputs),
                "outputs": _snip(self.outputs),
                "error": _snip(error),
            },
        )


# ---------------------------------------------------------------------------
# 观测器
# ---------------------------------------------------------------------------


class Observability:
    def __init__(self) -> None:
        settings = get_runtime_config()
        max_field_chars, max_file_bytes, queue_size = _observability_limits()
        self.trace_enabled = _to_bool((settings.get("trace") or {}).get("enabled", True))
        self.trace_dir = Path((settings.get("trace") or {}).get("directory") or "data/traces")
        self.metrics_dir = Path((settings.get("metrics") or {}).get("directory") or "data/metrics")
        self.max_field_chars = max_field_chars
        self.max_file_bytes = max_file_bytes
        self.queue_size = queue_size
        self._queue: asyncio.Queue[tuple[str, dict[str, Any]] | None] = asyncio.Queue(maxsize=queue_size)
        self._task: asyncio.Task[None] | None = None
        self._lock = threading.Lock()
        self._dropped = 0

    # -------------------------------------------------------------- lifecycle

    async def start(self) -> None:
        if self._task is not None:
            return
        self._queue = asyncio.Queue(maxsize=self.queue_size)
        self._task = asyncio.create_task(self._run(), name="gateway-observability")

    async def stop(self) -> None:
        if self._task is None:
            return
        await self._queue.put(None)
        with contextlib.suppress(asyncio.CancelledError):
            await self._task
        self._task = None

    async def flush(self) -> None:
        while not self._queue.empty():
            await asyncio.sleep(0.01)
        await asyncio.sleep(0.02)

    async def _run(self) -> None:
        stopped = False
        while not stopped:
            item = await self._queue.get()
            if item is None:
                break
            batch = [item]
            while True:
                try:
                    nxt = self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
                if nxt is None:
                    stopped = True
                    break
                batch.append(nxt)
            await asyncio.to_thread(self._write_batch, batch)

    def _write_batch(self, batch: list[tuple[str, dict[str, Any]]]) -> None:
        spans = [record for kind, record in batch if kind == "span"]
        metrics = [record for kind, record in batch if kind == "metric"]
        traces = [record for kind, record in batch if kind == "request_trace"]
        if spans and self.trace_enabled:
            self._append(self.trace_dir / "traces.txt", spans)
        if metrics:
            self._append(self.metrics_dir / "metrics.txt", metrics)
        if traces and self.trace_enabled:
            self._append(self.trace_dir / "request_traces.jsonl", traces)

    def _append(self, path: Path, records: list[dict[str, Any]]) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with self._lock:
                if path.is_file() and path.stat().st_size > self.max_file_bytes:
                    path.replace(path.with_suffix(path.suffix + ".1"))
                with path.open("a", encoding="utf-8") as handle:
                    for record in records:
                        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError as exc:
            logger.warning("failed to persist observability records: %s", exc)

    def _emit(self, kind: str, record: dict[str, Any]) -> None:
        if kind in {"span", "request_trace"} and not self.trace_enabled:
            return
        try:
            self._queue.put_nowait((kind, record))
        except asyncio.QueueFull:
            self._dropped += 1
            if self._dropped % 100 == 1:
                logger.warning("observability queue full, dropped=%s", self._dropped)

    # ------------------------------------------------------------------ trace

    def begin_request(self, request_id: str) -> contextvars.Token:
        return _current_request.set(request_id)

    def end_request(self, token: contextvars.Token) -> None:
        with contextlib.suppress(ValueError):
            _current_request.reset(token)

    def begin_span(self, name: str, **inputs: Any) -> ManualSpan:
        return ManualSpan(self, name, inputs)

    @asynccontextmanager
    async def span(self, name: str, **inputs: Any) -> AsyncIterator[ManualSpan]:
        span = self.begin_span(name, **inputs)
        try:
            yield span
        except (asyncio.CancelledError, GeneratorExit):
            span.end(ExecutionStatus.CANCELLED, "cancelled")
            raise
        except Exception as exc:
            span.end(ExecutionStatus.FAILED, f"{type(exc).__name__}: {exc}")
            raise
        else:
            span.end(ExecutionStatus.COMPLETED)

    # ---------------------------------------------------------------- metrics

    def record_trace(self, record: dict[str, Any]) -> None:
        """结构化请求级 trace，写入 request_traces.jsonl。"""

        self._emit("request_trace", record)

    def record_metric(
        self,
        *,
        request_id: str | None,
        mode: str,
        provider: str | None,
        model: str | None,
        mode_started_at: str,
        mode_ended_at: str,
        ttft_ms: float | None,
        total_tokens: int,
        status: ExecutionStatus | str,
        error_code: str | None = None,
    ) -> None:
        self._emit(
            "metric",
            {
                "ts": mode_ended_at,
                "request_id": request_id or _current_request.get(),
                "mode": mode,
                "provider": provider,
                "model": model,
                "mode_started_at": mode_started_at,
                "mode_ended_at": mode_ended_at,
                "ttft_ms": ttft_ms,
                "total_tokens": total_tokens,
                "status": normalize_status(status).value,
                "error_code": error_code,
            },
        )


def get_observability() -> Observability:
    global _observability
    if _observability is None:
        _observability = Observability()
    return _observability
