"""兼容入口：模态实现已抽离至项目根目录 adapter 包。

保留原有导入路径与函数名，业务调用方无需修改；新代码建议直接使用 adapter。
"""

from __future__ import annotations

from adapter import Modality, ModalityAdapter, get_adapter

ModalityHandler = ModalityAdapter


def get_handler(modality: Modality) -> ModalityAdapter:
    """兼容旧入口：等价于 adapter.get_adapter(modality)。"""

    return get_adapter(modality)


__all__ = ["Modality", "ModalityHandler", "get_handler"]
