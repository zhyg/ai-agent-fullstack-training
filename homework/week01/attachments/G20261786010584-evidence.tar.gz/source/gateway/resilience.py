"""降级重试策略与响应缓存。

错误分类用于决定是否重试：
- auth / model：终止类，直接失败；
- prompt_missing / over_budget：按配置次数重试；
- transient / unknown：按主模式、备用模式各自的次数重试。
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

from config.loader import get_llm_config, get_runtime_config
from error.codes import (
    AUTH_CODES,
    MODEL_CODES,
    OVER_BUDGET_CODES,
    PROMPT_MISSING_CODES,
    TRANSIENT_CODES,
    matches,
)
from provider import Provider, get_provider

logger = logging.getLogger(__name__)


class ErrorCategory(StrEnum):
    AUTH = "auth"
    MODEL = "model"
    PROMPT_MISSING = "prompt_missing"
    OVER_BUDGET = "over_budget"
    TRANSIENT = "transient"
    UNKNOWN = "unknown"


def classify_error(status_code: int | None, code: Any = None, message: str | None = None) -> ErrorCategory:
    """按错误码、HTTP 状态码与错误文本归类。"""

    message_text = str(message or "").lower()

    if matches(PROMPT_MISSING_CODES, code):
        return ErrorCategory.PROMPT_MISSING
    if matches(OVER_BUDGET_CODES, code) or status_code == 402:
        return ErrorCategory.OVER_BUDGET
    if status_code in {401, 403} or matches(AUTH_CODES, code):
        return ErrorCategory.AUTH
    if matches(MODEL_CODES, code):
        return ErrorCategory.MODEL
    if status_code == 404 or (status_code in {400, 404, 422} and "model" in message_text):
        return ErrorCategory.MODEL
    if status_code in {408, 409, 425, 429} or status_code is None or (status_code or 0) >= 500:
        return ErrorCategory.TRANSIENT
    if matches(TRANSIENT_CODES, code):
        return ErrorCategory.TRANSIENT
    return ErrorCategory.UNKNOWN


@dataclass(frozen=True)
class RetryPolicy:
    primary_attempts: int = 2
    fallback_attempts: int = 2
    prompt_missing_attempts: int = 2
    over_budget_attempts: int = 2
    retry_delay_ms: int = 0
    terminal: frozenset[ErrorCategory] = frozenset({ErrorCategory.AUTH, ErrorCategory.MODEL})

    def is_terminal(self, category: ErrorCategory) -> bool:
        return category in self.terminal

    def attempts_for(self, role: str, category: ErrorCategory) -> int:
        if self.is_terminal(category):
            return 1
        if category is ErrorCategory.PROMPT_MISSING:
            return max(1, self.prompt_missing_attempts)
        if category is ErrorCategory.OVER_BUDGET:
            return max(1, self.over_budget_attempts)
        base = self.primary_attempts if role == "primary" else self.fallback_attempts
        return max(1, base)

    @property
    def delay_seconds(self) -> float:
        return max(0, self.retry_delay_ms) / 1000


def get_retry_policy() -> RetryPolicy:
    config = get_runtime_config().get("retry") or {}
    terminal = {
        ErrorCategory(item)
        for item in (config.get("terminal_categories") or ["auth", "model"])
        if str(item) in {category.value for category in ErrorCategory}
    }
    return RetryPolicy(
        primary_attempts=int(config.get("primary_attempts") or 2),
        fallback_attempts=int(config.get("fallback_attempts") or 2),
        prompt_missing_attempts=int(config.get("prompt_missing_attempts") or 2),
        over_budget_attempts=int(config.get("over_budget_attempts") or 2),
        retry_delay_ms=int(config.get("retry_delay_ms") or 0),
        terminal=frozenset(terminal or {ErrorCategory.AUTH, ErrorCategory.MODEL}),
    )


# ---------------------------------------------------------------------------
# 备用请求模式
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Target:
    role: str
    provider: Provider
    model: str


def build_targets(primary: Provider, model: str) -> list[Target]:
    targets = [Target("primary", primary, model)]
    config = get_llm_config().get("fallback") or {}
    fallback_model = str(config.get("model") or "").strip()
    if not fallback_model:
        return targets

    fallback_name = str(config.get("provider") or primary.name).strip()
    fallback_provider = get_provider(fallback_name)
    if fallback_provider is None:
        logger.warning("fallback provider %r not found, degrade disabled", fallback_name)
        return targets
    if fallback_provider.name == primary.name and fallback_model == model:
        return targets
    targets.append(Target("fallback", fallback_provider, fallback_model))
    return targets


# ---------------------------------------------------------------------------
# 响应缓存
# ---------------------------------------------------------------------------


class ResponseCache:
    def __init__(self, directory: Path | str | None = None, ttl_seconds: int | None = None) -> None:
        config = get_runtime_config().get("cache") or {}
        self.directory = Path(directory or config.get("directory") or "data/cache")
        self.ttl_seconds = int(ttl_seconds if ttl_seconds is not None else config.get("ttl_seconds") or 300)

    @staticmethod
    def key(payload: dict[str, Any], stream: bool) -> str:
        canonical = json.dumps(
            {"payload": payload, "stream": bool(stream)},
            sort_keys=True,
            ensure_ascii=False,
            default=str,
        )
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _path(self, key: str) -> Path:
        return self.directory / f"{key}.json"

    def get(self, key: str) -> dict[str, Any] | None:
        path = self._path(key)
        try:
            if not path.is_file():
                return None
            record = json.loads(path.read_text(encoding="utf-8"))
            created = float(record.get("created_at") or 0)
            if self.ttl_seconds > 0 and time.time() - created > self.ttl_seconds:
                path.unlink(missing_ok=True)
                return None
            value = record.get("value")
            return value if isinstance(value, dict) else None
        except (OSError, ValueError, TypeError) as exc:
            logger.warning("cache read failed for %s: %s", key, exc)
            return None

    def put(self, key: str, value: dict[str, Any]) -> None:
        path = self._path(key)
        try:
            self.directory.mkdir(parents=True, exist_ok=True)
            temp = path.with_suffix(f".{os.getpid()}.tmp")
            temp.write_text(
                json.dumps({"created_at": time.time(), "value": value}, ensure_ascii=False),
                encoding="utf-8",
            )
            os.replace(temp, path)
        except OSError as exc:
            logger.warning("cache write failed for %s: %s", key, exc)


_cache: ResponseCache | None = None


def get_cache() -> ResponseCache:
    global _cache
    if _cache is None:
        _cache = ResponseCache()
    return _cache


def reset_cache() -> None:
    global _cache
    _cache = None
