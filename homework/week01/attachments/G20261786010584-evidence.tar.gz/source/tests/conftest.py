"""测试配置：隔离存储目录并注册管理接口。"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="llmgw-tests-"))
os.environ["PROMPT_STORE_DIR"] = str(_TMP / "data")
os.environ["PROMPT_MANAGE_ENABLED"] = "true"
os.environ["CACHE_DIR"] = str(_TMP / "cache")
os.environ["METRICS_DIR"] = str(_TMP / "metrics")
os.environ["TRACE_DIR"] = str(_TMP / "traces")
os.environ["RETRY_DELAY_MS"] = "0"
os.environ.pop("GATEWAY_API_KEY", None)


@pytest.fixture()
def store_dir(tmp_path: Path) -> Path:
    return tmp_path / "store"


@pytest.fixture()
def client():
    from fastapi.testclient import TestClient

    from main import app

    with TestClient(app) as test_client:
        yield test_client
