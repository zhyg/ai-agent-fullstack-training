"""txt 追加存储：重放、版本、轮转与容错测试。"""

from __future__ import annotations

import json
from datetime import datetime

import pytest

from error.base import PromptError
from prompt.models import ChangeEvent, OutputSpec, PromptTemplate, VariablesSchema
from prompt.store import PromptStore


def _ts() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _template(template_id: str, version: int) -> PromptTemplate:
    return PromptTemplate(
        id=template_id,
        version=version,
        system="You are helpful.",
        user_template="Hi {{ name }}",
        variables_schema=VariablesSchema.model_validate(
            {"variables": {"name": {"type": "string", "required": True}}}
        ),
        output=OutputSpec(),
        created_at=_ts(),
        updated_at=_ts(),
    )


def _event(event_type: str, template: PromptTemplate | None, version: int) -> ChangeEvent:
    return ChangeEvent(
        ts=_ts(),
        event=event_type,
        template_id=template.id if template else "qa",
        version=version,
        template=template,
    )


def test_create_and_replay(tmp_path):
    store = PromptStore(tmp_path)
    template = _template("qa", 1)
    store.append_change(_event("create", template, 1))

    reopened = PromptStore(tmp_path)
    reopened.load()
    loaded = reopened.get("qa")
    assert loaded.version == 1
    assert loaded.user_template == "Hi {{ name }}"


def test_update_creates_new_version(tmp_path):
    store = PromptStore(tmp_path)
    store.append_change(_event("create", _template("qa", 1), 1))
    store.append_change(_event("update", _template("qa", 2), 2))
    assert store.get("qa").version == 2
    assert store.get("qa", 1).version == 1


def test_unknown_template_and_version(tmp_path):
    store = PromptStore(tmp_path)
    with pytest.raises(PromptError) as exc:
        store.get("missing")
    assert exc.value.code == "prompt_not_found"
    with pytest.raises(PromptError) as exc:
        store.get("qa", 9)
    assert exc.value.code == "prompt_version_not_found"


def test_disable_then_delete(tmp_path):
    store = PromptStore(tmp_path)
    store.append_change(_event("create", _template("qa", 1), 1))
    store.append_change(_event("disable", None, 1))
    assert store.get("qa").enabled is False

    store.append_change(_event("delete", None, 1))
    with pytest.raises(PromptError):
        store.get("qa")


def test_malformed_lines_are_skipped(tmp_path):
    store = PromptStore(tmp_path)
    store.append_change(_event("create", _template("qa", 1), 1))
    with (tmp_path / "templates.txt").open("a", encoding="utf-8") as handle:
        handle.write("{\"broken\": \n")
        handle.write(json.dumps({"ts": _ts(), "event": "update", "template_id": "qa", "version": 2}) + "\n")

    reopened = PromptStore(tmp_path)
    reopened.load()
    assert reopened.get("qa").version == 1


def test_rotation_keeps_history(tmp_path):
    store = PromptStore(tmp_path, max_bytes=200)
    store.append_change(_event("create", _template("qa", 1), 1))
    store.append_change(_event("update", _template("qa", 2), 2))
    store.append_change(_event("update", _template("qa", 3), 3))

    files = sorted(path.name for path in tmp_path.glob("templates*.txt"))
    assert len(files) >= 2

    reopened = PromptStore(tmp_path, max_bytes=200)
    reopened.load()
    assert reopened.get("qa").version == 3
    assert reopened.get("qa", 1).version == 1
