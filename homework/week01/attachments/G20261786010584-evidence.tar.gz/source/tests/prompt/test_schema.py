"""变量 Schema 编译与校验测试。"""

from __future__ import annotations

import pytest

from error.base import PromptError
from prompt.models import VariableSpec, VariablesSchema
from prompt.schema import check_variable_names, compile_schema, validate_variables


def _schema(variables: dict[str, dict], strict: bool = True) -> VariablesSchema:
    return VariablesSchema(strict=strict, variables={name: VariableSpec(**spec) for name, spec in variables.items()})


def test_nested_object_and_array():
    schema = _schema(
        {
            "user": {
                "type": "object",
                "required": True,
                "properties": {
                    "name": {"type": "string", "required": True, "min_length": 2},
                    "tags": {"type": "array", "required": True, "items": {"type": "string"}},
                },
            }
        }
    )
    values = validate_variables(schema, {"user": {"name": "Ada", "tags": ["x"]}})
    assert values["user"]["name"] == "Ada"


def test_missing_required():
    schema = _schema({"name": {"type": "string", "required": True}})
    with pytest.raises(PromptError) as exc:
        validate_variables(schema, {})
    assert exc.value.code == "prompt_variable_missing"
    assert exc.value.status_code == 422


def test_unknown_variable_strict():
    schema = _schema({"name": {"type": "string"}})
    with pytest.raises(PromptError) as exc:
        validate_variables(schema, {"name": "a", "extra": 1})
    assert exc.value.code == "prompt_variable_unknown"


def test_unknown_variable_ignored_when_not_strict():
    schema = _schema({"name": {"type": "string"}}, strict=False)
    values = validate_variables(schema, {"name": "a", "extra": 1})
    assert "extra" not in values


def test_defaults_filled():
    schema = _schema({"name": {"type": "string", "default": "anon"}})
    values = validate_variables(schema, {})
    assert values["name"] == "anon"


def test_enum_and_pattern():
    schema = _schema(
        {
            "mode": {"type": "string", "enum": ["a", "b"], "required": True},
            "code": {"type": "string", "pattern": r"^\d{3}$", "required": True},
        }
    )
    assert validate_variables(schema, {"mode": "a", "code": "123"})["mode"] == "a"
    with pytest.raises(PromptError) as exc:
        validate_variables(schema, {"mode": "c", "code": "12"})
    assert exc.value.code == "prompt_variables_invalid"


def test_numeric_bounds():
    schema = _schema({"score": {"type": "integer", "minimum": 0, "maximum": 100, "required": True}})
    with pytest.raises(PromptError):
        validate_variables(schema, {"score": 200})


def test_compile_cache():
    schema = _schema({"name": {"type": "string"}})
    assert compile_schema(schema) is compile_schema(schema)


def test_undeclared_placeholder():
    schema = _schema({"name": {"type": "string"}})
    with pytest.raises(PromptError) as exc:
        check_variable_names("{{ missing }}", schema)
    assert exc.value.code == "prompt_placeholder_undeclared"


def test_declared_placeholder_ok():
    schema = _schema({"name": {"type": "string"}})
    assert check_variable_names("{{ name }}", schema) == {"name"}
