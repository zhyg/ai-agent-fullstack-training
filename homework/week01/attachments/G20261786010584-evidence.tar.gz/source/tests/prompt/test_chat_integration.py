"""chat 端点 + prompt 集成的端到端测试（上游用假 handler）。"""

from __future__ import annotations

import uuid

import httpx
import pytest


class _FakeHandler:
    def __init__(self, content: str = "hello", status: int = 200):
        self.content = content
        self.status = status
        self.payloads: list[dict] = []

    async def complete(self, client, provider, payload):
        self.payloads.append(dict(payload))
        if self.status >= 400:
            return httpx.Response(self.status, content=b'{"error": {"message": "boom"}}')
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-test",
                "object": "chat.completion",
                "created": 1,
                "model": payload["model"],
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": self.content},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            },
        )


@pytest.fixture()
def fake_handler(monkeypatch):
    handler = _FakeHandler()
    monkeypatch.setattr("api.api.get_handler", lambda modality: handler)
    return handler


def _register(client, template_id: str, **overrides):
    payload = {
        "id": template_id,
        "system": "You are {{ tone }}.",
        "user_template": "Answer: {{ question }}",
        "variables_schema": {
            "strict": True,
            "variables": {
                "tone": {"type": "string", "required": True},
                "question": {"type": "string", "required": True},
            },
        },
    }
    payload.update(overrides)
    return client.post("/api/v1/prompts", json=payload)


def test_chat_without_prompt_is_unchanged(client, fake_handler):
    resp = client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert resp.status_code == 200
    assert "prompt" not in resp.json()
    payload = fake_handler.payloads[-1]
    assert "prompt" not in payload
    assert payload["messages"] == [{"role": "user", "content": "hi"}]


def test_chat_with_prompt_injects_messages(client, fake_handler):
    assert _register(client, "chat-1").status_code == 201
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "original"}],
            "prompt": {"id": "chat-1", "variables": {"tone": "calm", "question": "why"}},
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["prompt"]["template_id"] == "chat-1"
    assert body["prompt"]["validated"] is False
    payload = fake_handler.payloads[-1]
    assert "prompt" not in payload
    assert payload["messages"][0] == {"role": "system", "content": "You are calm."}
    assert payload["messages"][-1]["content"] == "Answer: why"


def test_chat_prompt_variable_error(client, fake_handler):
    _register(client, "chat-2")
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "prompt": {"id": "chat-2", "variables": {"tone": "calm"}},
        },
    )
    assert resp.status_code == 422
    assert resp.json()["error"]["code"] == "prompt_variable_missing"
    assert fake_handler.payloads == []


def test_chat_prompt_not_found(client, fake_handler):
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "prompt": {"id": "missing"},
        },
    )
    assert resp.status_code == 404
    assert resp.json()["error"]["code"] == "prompt_not_found"


def test_structured_output_validated(client, fake_handler):
    _register(
        client,
        "chat-json",
        output={
            "mode": "structured",
            "schema_name": "reply",
            "schema_def": {"variables": {"answer": {"type": "string", "required": True}}},
        },
    )
    fake_handler.content = '{"answer": "ok"}'
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "prompt": {"id": "chat-json", "variables": {"tone": "calm", "question": "q"}},
        },
    )
    assert resp.status_code == 200
    assert resp.json()["prompt"]["validated"] is True
    payload = fake_handler.payloads[-1]
    assert payload["response_format"]["type"] == "json_schema"
    assert payload["response_format"]["json_schema"]["name"] == "reply"


def test_structured_output_invalid(client, fake_handler):
    _register(
        client,
        "chat-json-bad",
        output={
            "mode": "structured",
            "schema_def": {"variables": {"answer": {"type": "string", "required": True}}},
        },
    )
    fake_handler.content = "not json"
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "prompt": {"id": "chat-json-bad", "variables": {"tone": "calm", "question": "q"}},
        },
    )
    assert resp.status_code == 502
    assert resp.json()["error"]["code"] == "structured_output_invalid"


def test_structured_with_stream_rejected(client, fake_handler):
    _register(
        client,
        "chat-stream",
        output={"mode": "json"},
    )
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "stream": True,
            "prompt": {"id": "chat-stream", "variables": {"tone": "calm", "question": "q"}},
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "structured_output_requires_non_stream"


def test_response_format_conflict(client, fake_handler):
    _register(client, "chat-conflict", output={"mode": "json"})
    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "response_format": {"type": "json_schema"},
            "prompt": {"id": "chat-conflict", "variables": {"tone": "calm", "question": "q"}},
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "prompt_output_mode_conflict"


@pytest.fixture()
def boundary_payload(client, monkeypatch):
    """为每个场景创建独立模板，并显式启用严格变量校验。"""
    from config.loader import reset_llm_config

    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("PROMPT_STRICT_VARIABLES", "true")
    reset_llm_config()
    try:
        template_id = f"boundary-{uuid.uuid4().hex}"
        response = _register(client, template_id)
        assert response.status_code == 201, response.text
        assert response.json()["ok"] is True
        assert response.json()["data"]["id"] == template_id
        assert response.json()["data"]["version"] == 1
        yield {
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "original"}],
            "stream": False,
            "prompt": {
                "id": template_id,
                "variables": {"tone": "calm", "question": "why"},
            },
        }
    finally:
        reset_llm_config()


def _assert_text_completion(response, handler, payload, question):
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["object"] == "chat.completion"
    assert body["model"] == payload["model"]
    assert body["choices"][0]["message"]["content"] == "hello"
    assert body["choices"][0]["finish_reason"] == "stop"
    assert body["usage"]["total_tokens"] == 2
    assert body["prompt"]["template_id"] == payload["prompt"]["id"]
    assert body["prompt"]["version"] == 1
    assert body["prompt"]["output_mode"] == "text"
    assert body["prompt"]["validated"] is False
    assert len(handler.payloads) == 1
    upstream = handler.payloads[0]
    assert upstream["model"] == "gpt-4o-mini"
    assert upstream["stream"] is False
    assert "prompt" not in upstream
    assert "provider" not in upstream
    assert upstream["messages"] == [
        {"role": "system", "content": "You are calm."},
        {"role": "user", "content": f"Answer: {question}"},
    ]


@pytest.mark.parametrize("question", ["why", ""], ids=["TC-CHAT-001", "B01-empty-allowed"])
def test_chat_boundary_text_success(client, fake_handler, boundary_payload, question):
    boundary_payload["prompt"]["variables"]["question"] = question
    response = client.post("/v1/chat/completions", json=boundary_payload)
    _assert_text_completion(response, fake_handler, boundary_payload, question)


@pytest.mark.parametrize(
    ("scenario", "status", "code"),
    [
        pytest.param("missing", 422, "prompt_variable_missing", id="F01-missing-variable"),
        pytest.param("null", 422, "prompt_variables_invalid", id="F02-null-variable"),
        pytest.param("array", 422, "prompt_variables_invalid", id="F03-invalid-type"),
        pytest.param("unknown", 422, "prompt_variable_unknown", id="F04-unknown-variable"),
        pytest.param("template", 404, "prompt_not_found", id="F05-template-not-found"),
        pytest.param("version", 404, "prompt_version_not_found", id="F06-version-not-found"),
        pytest.param("messages", 400, "prompt_user_message_missing", id="F07-empty-messages"),
    ],
)
def test_chat_boundary_rejected_before_upstream(client, fake_handler, boundary_payload, scenario, status, code):
    invocation = boundary_payload["prompt"]
    if scenario == "missing":
        del invocation["variables"]["question"]
    elif scenario == "null":
        invocation["variables"]["question"] = None
    elif scenario == "array":
        invocation["variables"]["question"] = []
    elif scenario == "unknown":
        invocation["variables"]["extra"] = "x"
    elif scenario == "template":
        invocation["id"] = f"missing-{uuid.uuid4().hex}"
    elif scenario == "version":
        invocation["version"] = 999
    elif scenario == "messages":
        boundary_payload["messages"] = []

    response = client.post("/v1/chat/completions", json=boundary_payload)

    assert response.status_code == status, response.text
    error = response.json()["error"]
    assert error["code"] == code
    assert error["type"] == "invalid_request_error"
    assert isinstance(error["message"], str) and error["message"]
    if scenario == "unknown":
        assert error["details"]["unknown"] == ["extra"]
    assert fake_handler.payloads == []


@pytest.mark.parametrize(
    ("scenario", "location", "error_type"),
    [
        pytest.param("missing-messages", ["body", "messages"], "missing", id="F08-missing-messages"),
        pytest.param("invalid-role", ["body", "messages", 0, "role"], "literal_error", id="F09-invalid-role"),
    ],
)
def test_chat_boundary_request_validation(client, fake_handler, boundary_payload, scenario, location, error_type):
    if scenario == "missing-messages":
        del boundary_payload["messages"]
    else:
        boundary_payload["messages"][0]["role"] = "invalid"

    response = client.post("/v1/chat/completions", json=boundary_payload)

    assert response.status_code == 422, response.text
    details = response.json()["detail"]
    assert isinstance(details, list)
    assert any(error["loc"] == location and error["type"] == error_type for error in details)
    assert fake_handler.payloads == []


@pytest.mark.parametrize(
    ("question", "status"),
    [
        pytest.param("", 422, id="B02-below-minimum"),
        pytest.param("a", 200, id="B03-at-minimum"),
        pytest.param("abcdefghij", 200, id="B04-at-maximum"),
        pytest.param("abcdefghijk", 422, id="B05-above-maximum"),
    ],
)
def test_chat_boundary_question_length(client, fake_handler, boundary_payload, question, status):
    template_id = f"length-{uuid.uuid4().hex}"
    created = _register(
        client,
        template_id,
        variables_schema={
            "strict": True,
            "variables": {
                "tone": {"type": "string", "required": True},
                "question": {"type": "string", "required": True, "min_length": 1, "max_length": 10},
            },
        },
    )
    assert created.status_code == 201, created.text
    boundary_payload["prompt"]["id"] = template_id
    boundary_payload["prompt"]["variables"]["question"] = question

    response = client.post("/v1/chat/completions", json=boundary_payload)

    assert response.status_code == status, response.text
    if status == 200:
        _assert_text_completion(response, fake_handler, boundary_payload, question)
    else:
        error = response.json()["error"]
        assert error["code"] == "prompt_variables_invalid"
        assert error["type"] == "invalid_request_error"
        assert error["message"]
        assert fake_handler.payloads == []
