"""使用记录审计测试。"""

from __future__ import annotations

import asyncio

import pytest

from prompt.audit import PromptAudit, sanitize


def test_sanitize_masks_sensitive_keys():
    values = {"api_key": "sk-123", "nested": {"token": "abc", "ok": "v"}}
    masked = sanitize(values)
    assert masked["api_key"] == "***"
    assert masked["nested"]["token"] == "***"
    assert masked["nested"]["ok"] == "v"


def test_sanitize_truncates_long_values():
    masked = sanitize({"text": "x" * 10_000})
    assert masked["text"].endswith("<truncated>")
    assert len(masked["text"]) <= 4_096 + len("...<truncated>")


def test_record_and_flush(tmp_path):
    audit = PromptAudit(tmp_path, queue_size=8)

    async def run():
        await audit.start()
        audit.record_usage(
            request_id="req_1",
            template_id="qa",
            version=1,
            model="gpt-4o-mini",
            provider="openai",
            output_mode="text",
            variables={"api_key": "sk-1", "question": "hello"},
            status="completed",
            latency_ms=12,
            session_id="s-1",
        )
        await audit.flush()
        await audit.stop()

    asyncio.run(run())

    records = audit.query(template_id="qa")
    assert len(records) == 1
    assert records[0]["variables"]["api_key"] == "***"
    assert records[0]["status"] == "completed"


def test_query_filters(tmp_path):
    audit = PromptAudit(tmp_path, queue_size=8)

    async def run():
        await audit.start()
        for index, status in enumerate(["completed", "failed", "completed"]):
            audit.record_usage(
                request_id=f"req_{index}",
                template_id="qa",
                version=1,
                model=None,
                provider=None,
                output_mode="text",
                variables={},
                status=status,
                session_id="s-a" if index == 0 else "s-b",
            )
        await audit.flush()
        await audit.stop()

    asyncio.run(run())

    assert len(audit.query(template_id="qa", status="completed")) == 2
    assert len(audit.query(template_id="qa", session_id="s-a")) == 1
    assert audit.query(template_id="other") == []


def test_record_usage_rejects_undefined_status(tmp_path):
    audit = PromptAudit(tmp_path, queue_size=8)
    with pytest.raises(ValueError):
        audit.record_usage(
            request_id="req_x",
            template_id="qa",
            version=1,
            model=None,
            provider=None,
            output_mode="text",
            variables={},
            status="ok",
        )


def test_queue_full_never_raises(tmp_path):
    audit = PromptAudit(tmp_path, queue_size=1)
    audit.record({"ts": "x"})
    audit.record({"ts": "y"})
