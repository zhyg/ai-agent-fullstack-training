"""输出规范测试：response_format 构造与结构化校验。"""

from __future__ import annotations

import json

import pytest

from error.base import PromptError
from prompt.models import OutputMode, OutputSpec, VariableSpec, VariablesSchema
from prompt.output import build_response_format, to_json_schema, validate_output


class _Provider:
    def __init__(self, formats: list[str] | None = None):
        self.capabilities = {"response_format": formats} if formats is not None else {}


_SCHEMA = VariablesSchema(
    variables={
        "answer": VariableSpec(type="string", required=True),
        "score": VariableSpec(type="integer", required=False),
    }
)


def test_text_mode_no_injection():
    assert build_response_format(OutputSpec()) == (None, False)


def test_json_mode_injection():
    assert build_response_format(OutputSpec(mode=OutputMode.JSON)) == ({"type": "json_object"}, False)


def test_structured_injection():
    spec = OutputSpec(mode=OutputMode.STRUCTURED, schema_def=_SCHEMA, schema_name="reply")
    response_format, degraded = build_response_format(spec, _Provider(["text", "json_object", "json_schema"]))
    assert degraded is False
    assert response_format["type"] == "json_schema"
    assert response_format["json_schema"]["name"] == "reply"
    assert response_format["json_schema"]["schema"]["required"] == ["answer"]


def test_structured_degraded():
    spec = OutputSpec(mode=OutputMode.STRUCTURED, schema_def=_SCHEMA)
    response_format, degraded = build_response_format(spec, _Provider(["text", "json_object"]))
    assert degraded is True
    assert response_format == {"type": "json_object"}


def test_to_json_schema_nested():
    schema = VariablesSchema(
        variables={
            "user": VariableSpec(
                type="object",
                required=True,
                properties={
                    "name": VariableSpec(type="string", required=True),
                    "tags": VariableSpec(type="array", items=VariableSpec(type="string")),
                },
            )
        }
    )
    result = to_json_schema(schema)
    assert result["properties"]["user"]["required"] == ["name"]
    assert result["properties"]["user"]["properties"]["tags"]["type"] == "array"


def test_validate_json_output():
    output = OutputSpec(mode=OutputMode.JSON)
    assert validate_output(output, '{"a": 1}')[0] == {"a": 1}

    with pytest.raises(PromptError) as exc:
        validate_output(output, "not json")
    assert exc.value.status_code == 502
    assert exc.value.code == "structured_output_invalid"

    with pytest.raises(PromptError):
        validate_output(output, "[1,2]")


def test_validate_structured_output():
    output = OutputSpec(mode=OutputMode.STRUCTURED, schema_def=_SCHEMA)
    parsed, _ = validate_output(output, json.dumps({"answer": "ok", "score": 3}))
    assert parsed["answer"] == "ok"

    with pytest.raises(PromptError) as exc:
        validate_output(output, json.dumps({"score": 3}))
    assert exc.value.code == "structured_output_invalid"


def test_max_chars():
    output = OutputSpec(mode=OutputMode.JSON, max_chars=5)
    with pytest.raises(PromptError):
        validate_output(output, '{"long": true}')
