"""PromptService 编排测试（不发起上游请求）。"""

from __future__ import annotations

import asyncio

import pytest

from prompt.audit import PromptAudit
from error.base import PromptError
from prompt.models import OutputMode, OutputSpec, PromptInvocation, VariablesSchema
from prompt.service import PromptService
from prompt.store import PromptStore


def _service(tmp_path) -> PromptService:
    return PromptService(store=PromptStore(tmp_path), audit=PromptAudit(tmp_path))


def _create(service: PromptService, template_id: str = "qa") -> None:
    asyncio.run(
        service.upsert_template(
            template_id,
            expected_version=None,
            system="You are {{ role }}.",
            user_template="Question: {{ question }}",
            variables_schema=VariablesSchema.model_validate(
                {
                    "variables": {
                        "role": {"type": "string", "required": True},
                        "question": {"type": "string", "required": True},
                    }
                }
            ),
            output=OutputSpec(),
        )
    )


def test_prepare_injects_system_and_user(tmp_path):
    service = _service(tmp_path)
    _create(service)

    invocation = PromptInvocation(id="qa", variables={"role": "a judge", "question": "why?"})
    messages = [
        {"role": "system", "content": "old system"},
        {"role": "user", "content": "original"},
    ]
    prepared = asyncio.run(service.prepare(invocation, messages))

    assert prepared.messages[0] == {"role": "system", "content": "You are a judge."}
    assert prepared.messages[-1]["content"] == "Question: why?"
    assert prepared.meta["template_id"] == "qa"
    assert prepared.meta["output_mode"] == "text"


def test_prepare_missing_variable(tmp_path):
    service = _service(tmp_path)
    _create(service)
    with pytest.raises(PromptError) as exc:
        asyncio.run(service.prepare(PromptInvocation(id="qa", variables={"role": "x"}), [{"role": "user", "content": "hi"}]))
    assert exc.value.code == "prompt_variable_missing"


def test_prepare_unknown_template(tmp_path):
    service = _service(tmp_path)
    with pytest.raises(PromptError) as exc:
        asyncio.run(service.prepare(PromptInvocation(id="nope"), []))
    assert exc.value.status_code == 404


def test_prepare_disabled_template(tmp_path):
    service = _service(tmp_path)
    _create(service)
    asyncio.run(service.set_enabled("qa", False))

    with pytest.raises(PromptError) as exc:
        asyncio.run(
            service.prepare(
                PromptInvocation(id="qa", variables={"role": "x", "question": "q"}),
                [{"role": "user", "content": "hi"}],
            )
        )
    assert exc.value.status_code == 404


def test_upsert_conflict(tmp_path):
    service = _service(tmp_path)
    _create(service)
    with pytest.raises(PromptError) as exc:
        asyncio.run(service.upsert_template("qa", expected_version=None))
    assert exc.value.code == "prompt_version_conflict"

    with pytest.raises(PromptError) as exc:
        asyncio.run(service.upsert_template("qa", expected_version=99))
    assert exc.value.code == "prompt_version_conflict"


def test_register_undeclared_variable(tmp_path):
    service = _service(tmp_path)
    with pytest.raises(PromptError) as exc:
        asyncio.run(
            service.upsert_template(
                "bad",
                expected_version=None,
                user_template="{{ missing }}",
                variables_schema=VariablesSchema.model_validate({"variables": {}}),
            )
        )
    assert exc.value.code == "prompt_placeholder_undeclared"


def test_preview(tmp_path):
    service = _service(tmp_path)
    _create(service)
    output = service.preview("qa", {"role": "judge", "question": "why"})
    assert output["system"].startswith("You are judge")
    assert output["user"] == "Question: why"


def test_structured_output_spec_override(tmp_path):
    service = _service(tmp_path)
    _create(service)
    schema = VariablesSchema.model_validate(
        {"variables": {"answer": {"type": "string", "required": True}}}
    )
    invocation = PromptInvocation(
        id="qa",
        variables={"role": "x", "question": "q"},
        output=OutputSpec(mode=OutputMode.STRUCTURED, schema_def=schema, schema_name="reply"),
    )
    prepared = asyncio.run(service.prepare(invocation, [{"role": "user", "content": "hi"}]))
    assert prepared.output.mode is OutputMode.STRUCTURED
    assert prepared.output.schema_name == "reply"
