"""模板管理接口测试。"""

from __future__ import annotations


def _create(client, template_id: str):
    return client.post(
        "/api/v1/prompts",
        json={
            "id": template_id,
            "system": "You are {{ tone }}.",
            "user_template": "Say {{ word }}",
            "variables_schema": {
                "strict": True,
                "variables": {
                    "tone": {"type": "string", "required": True},
                    "word": {"type": "string", "required": True},
                },
            },
            "output": {"mode": "text"},
        },
    )


def test_create_list_get(client):
    resp = _create(client, "api-test-1")
    assert resp.status_code == 201
    assert resp.json()["ok"] is True
    assert resp.json()["request_id"].startswith("req_")

    listed = client.get("/api/v1/prompts").json()
    assert any(item["id"] == "api-test-1" for item in listed["data"]["items"])

    detail = client.get("/api/v1/prompts/api-test-1").json()["data"]
    assert detail["version"] == 1


def test_update_requires_expected_version(client):
    _create(client, "api-test-2")
    resp = client.put(
        "/api/v1/prompts/api-test-2",
        json={
            "expected_version": 99,
            "user_template": "Say {{ word }}",
            "variables_schema": {"variables": {"word": {"type": "string", "required": True}}},
        },
    )
    assert resp.status_code == 409
    assert resp.json()["error"]["code"] == "prompt_version_conflict"


def test_update_success(client):
    _create(client, "api-test-3")
    resp = client.put(
        "/api/v1/prompts/api-test-3",
        json={
            "expected_version": 1,
            "user_template": "Say {{ word }}",
            "variables_schema": {"variables": {"word": {"type": "string", "required": True}}},
        },
    )
    assert resp.status_code == 200
    assert resp.json()["data"]["version"] == 2


def test_preview_does_not_call_upstream(client):
    _create(client, "api-test-4")
    resp = client.post(
        "/api/v1/prompts/api-test-4/preview",
        json={"variables": {"tone": "calm", "word": "hello"}},
    )
    assert resp.status_code == 200
    assert resp.json()["data"]["user"] == "Say hello"


def test_delete_template(client):
    _create(client, "api-test-5")
    resp = client.delete("/api/v1/prompts/api-test-5")
    assert resp.status_code == 200
    assert client.get("/api/v1/prompts/api-test-5").status_code == 404


def test_undeclared_variable_rejected(client):
    resp = client.post(
        "/api/v1/prompts",
        json={"id": "api-test-6", "user_template": "{{ missing }}"},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "prompt_placeholder_undeclared"
