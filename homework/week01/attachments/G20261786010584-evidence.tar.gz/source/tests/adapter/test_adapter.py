"""模态适配器层测试：统一入口、生命周期、参数校验、错误处理与行为兼容。"""

from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator

import httpx
import pytest

import adapter.chat as chat_module
from adapter import (
    AdapterError,
    AdapterNotRegisteredError,
    AdapterParamError,
    AdapterRegistry,
    AdapterState,
    ChatAdapter,
    Modality,
    ModalityAdapter,
    adapter_names,
    get_adapter,
    register_adapter,
    reset_adapters,
    shutdown_adapters,
    startup_adapters,
    unregister_adapter,
)
from gateway.modality import get_handler
from provider import Provider

_PROVIDER = Provider(name="openai", base_url="https://api.openai.com/v1", api_key="k")
_PAYLOAD = {"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hi"}]}


class _DummyAdapter(ModalityAdapter):
    name = "dummy"
    modality = Modality.CHAT

    async def _complete(self, client, provider, payload):
        return httpx.Response(200, json={"ok": True})

    async def _open_stream(self, client, provider, payload):
        return httpx.Response(200, content=b"data: [DONE]\n\n")

    def _transform_stream(self, upstream, client_model, provider) -> AsyncIterator[str]:
        async def _gen():
            yield "data: [DONE]\n\n"

        return _gen()


# ---------------------------------------------------------------------------
# 统一存储容器与入口
# ---------------------------------------------------------------------------


def test_default_registry_exposes_chat_adapter():
    adapter = get_adapter(Modality.CHAT)
    assert isinstance(adapter, ChatAdapter)
    assert adapter.name == "chat"
    assert adapter_names() == ["chat"]


def test_get_handler_keeps_legacy_entry_compatible():
    assert get_handler(Modality.CHAT) is get_adapter(Modality.CHAT)


def test_unknown_modality_raises():
    reset_adapters()
    with pytest.raises(AdapterNotRegisteredError):
        get_adapter("audio")  # type: ignore[arg-type]


def test_registry_register_unregister_and_replace():
    registry = AdapterRegistry()
    first = _DummyAdapter()
    registry.register(first)
    assert registry.get(Modality.CHAT) is first
    with pytest.raises(AdapterError):
        registry.register(_DummyAdapter())
    second = _DummyAdapter()
    registry.register(second, replace=True)
    assert registry.get(Modality.CHAT) is second
    assert registry.unregister(Modality.CHAT) is second
    assert registry.names() == []


def test_global_register_and_unregister():
    original = get_adapter(Modality.CHAT)
    replacement = _DummyAdapter()
    register_adapter(replacement, replace=True)
    assert get_adapter(Modality.CHAT) is replacement
    assert unregister_adapter(Modality.CHAT) is replacement
    with pytest.raises(AdapterNotRegisteredError):
        get_adapter(Modality.CHAT)
    reset_adapters()
    assert get_adapter(Modality.CHAT) is not None
    assert original is not None


# ---------------------------------------------------------------------------
# 生命周期
# ---------------------------------------------------------------------------


def test_lifecycle_is_idempotent_and_managed_in_bulk():
    registry = AdapterRegistry({Modality.CHAT: _DummyAdapter()})
    adapter = registry.get(Modality.CHAT)
    assert adapter.state is AdapterState.CREATED

    asyncio.run(registry.startup_all())
    asyncio.run(registry.startup_all())
    assert adapter.state is AdapterState.STARTED

    asyncio.run(registry.shutdown_all())
    asyncio.run(registry.shutdown_all())
    assert adapter.state is AdapterState.STOPPED


def test_global_lifecycle_entrypoints_are_safe():
    reset_adapters()
    asyncio.run(startup_adapters())
    assert get_adapter(Modality.CHAT).state is AdapterState.STARTED
    asyncio.run(shutdown_adapters())
    assert get_adapter(Modality.CHAT).state is AdapterState.STOPPED
    reset_adapters()


# ---------------------------------------------------------------------------
# 参数校验与错误处理
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("provider", "payload"),
    [
        ("not-a-provider", _PAYLOAD),
        (_PROVIDER, ["not-a-dict"]),
        (_PROVIDER, {"model": 123, "messages": []}),
        (_PROVIDER, {"model": "m", "messages": "not-a-list"}),
    ],
)
def test_invalid_complete_params_raise(provider, payload):
    with pytest.raises(AdapterParamError):
        asyncio.run(ChatAdapter().complete(None, provider, payload))  # type: ignore[arg-type]


def test_invalid_stream_params_raise():
    adapter = ChatAdapter()
    with pytest.raises(AdapterParamError):
        adapter.transform_stream("not-a-response", "m", _PROVIDER)  # type: ignore[arg-type]
    with pytest.raises(AdapterParamError):
        adapter.transform_stream(httpx.Response(200), 1, _PROVIDER)  # type: ignore[arg-type]
    with pytest.raises(AdapterParamError):
        adapter.transform_stream(httpx.Response(200), "m", "not-a-provider")  # type: ignore[arg-type]


def test_errors_are_logged_and_re_raised_unchanged(monkeypatch):
    async def boom(http_client, provider, path, payload, headers=None):
        raise RuntimeError("upstream exploded")

    monkeypatch.setattr(chat_module, "post_json", boom)
    with pytest.raises(RuntimeError, match="upstream exploded"):
        asyncio.run(ChatAdapter().complete(None, _PROVIDER, dict(_PAYLOAD)))


# ---------------------------------------------------------------------------
# 行为兼容：与抽离前 gateway/modality/chat.py 一致
# ---------------------------------------------------------------------------


def test_complete_passes_payload_and_returns_openai_response(monkeypatch):
    captured: dict[str, Any] = {}

    async def fake_post(http_client, provider, path, payload, headers=None):
        captured.update(path=path, payload=payload, headers=headers)
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-1",
                "model": payload["model"],
                "choices": [{"index": 0, "message": {"role": "assistant", "content": "hi"}}],
            },
        )

    monkeypatch.setattr(chat_module, "post_json", fake_post)
    data = asyncio.run(ChatAdapter().complete(None, _PROVIDER, dict(_PAYLOAD)))

    assert captured["path"] == "/chat/completions"
    assert captured["payload"] == _PAYLOAD
    assert captured["headers"]["Authorization"] == "Bearer k"
    assert data.status_code == 200
    assert data.json()["id"] == "chatcmpl-1"


def test_open_stream_normalizes_upstream_error(monkeypatch):
    async def fake_send(http_client, provider, path, payload, headers=None):
        return httpx.Response(400, json={"error": {"message": "bad request", "type": "invalid_request_error"}})

    monkeypatch.setattr(chat_module, "send_stream", fake_send)
    response = asyncio.run(ChatAdapter().open_stream(None, _PROVIDER, dict(_PAYLOAD)))

    assert response.status_code == 400
    assert response.json()["error"]["message"] == "bad request"


def test_transform_stream_rewrites_model_for_client():
    sse = b'data: {"model": "upstream", "choices": []}\n\ndata: [DONE]\n\n'
    upstream = httpx.Response(200, content=sse)
    stream = ChatAdapter().transform_stream(upstream, "gpt-4o-mini", _PROVIDER)

    async def collect():
        return [chunk async for chunk in stream]

    chunks = asyncio.run(collect())
    assert chunks[0].startswith("data: ")
    assert json.loads(chunks[0][len("data: ") :])["model"] == "gpt-4o-mini"
    assert chunks[-1] == "data: [DONE]\n\n"
