"""降级重试、状态枚举、缓存与指标/埋点持久化测试。"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import httpx
import pytest

from gateway.resilience import (
    ErrorCategory,
    ResponseCache,
    RetryPolicy,
    build_targets,
    classify_error,
    get_cache,
)
from gateway.status import ALLOWED_STATUSES, ExecutionStatus, normalize_status
from provider import Provider, get_providers


# ---------------------------------------------------------------------------
# 状态枚举
# ---------------------------------------------------------------------------


def test_execution_status_only_three_values():
    assert ALLOWED_STATUSES == ("completed", "failed", "cancelled")
    assert {status.value for status in ExecutionStatus} == set(ALLOWED_STATUSES)
    assert normalize_status("completed") is ExecutionStatus.COMPLETED
    with pytest.raises(ValueError):
        normalize_status("ok")


# ---------------------------------------------------------------------------
# 错误分类与重试策略
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("status", "code", "message", "expected"),
    [
        (401, None, None, ErrorCategory.AUTH),
        (403, "permission_error", None, ErrorCategory.AUTH),
        (404, "model_not_found", None, ErrorCategory.MODEL),
        (400, "invalid_request_error", "model does not exist", ErrorCategory.MODEL),
        (400, "insufficient_quota", None, ErrorCategory.OVER_BUDGET),
        (402, None, None, ErrorCategory.OVER_BUDGET),
        (404, "prompt_not_found", None, ErrorCategory.PROMPT_MISSING),
        (429, "rate_limit_error", None, ErrorCategory.TRANSIENT),
        (500, None, None, ErrorCategory.TRANSIENT),
    ],
)
def test_error_classification(status, code, message, expected):
    assert classify_error(status, code, message) is expected


def test_retry_policy_attempts_and_terminal_categories():
    policy = RetryPolicy()
    assert policy.is_terminal(ErrorCategory.AUTH)
    assert policy.is_terminal(ErrorCategory.MODEL)
    assert policy.attempts_for("primary", ErrorCategory.AUTH) == 1
    assert policy.attempts_for("primary", ErrorCategory.MODEL) == 1
    assert policy.attempts_for("primary", ErrorCategory.PROMPT_MISSING) == 2
    assert policy.attempts_for("fallback", ErrorCategory.OVER_BUDGET) == 2
    assert policy.attempts_for("primary", ErrorCategory.TRANSIENT) == 2
    assert policy.attempts_for("fallback", ErrorCategory.UNKNOWN) == 2


def test_build_targets_includes_configured_fallback():
    primary = Provider(name="anthropic", base_url="https://api.anthropic.com/v1", api_key="k", protocol="anthropic")
    targets = build_targets(primary, "claude-opus")

    assert [target.role for target in targets] == ["primary", "fallback"]
    assert targets[0].model == "claude-opus"
    assert targets[1].model == "gpt-4o-mini"
    assert targets[1].provider.name == "openai"


def test_build_targets_skips_identical_fallback():
    primary = get_providers()["openai"]
    targets = build_targets(primary, "gpt-4o-mini")
    assert len(targets) == 1


# ---------------------------------------------------------------------------
# 响应缓存
# ---------------------------------------------------------------------------


def test_response_cache_roundtrip_and_key_stability(tmp_path):
    cache = ResponseCache(tmp_path / "cache", ttl_seconds=60)
    key = cache.key({"model": "m", "messages": [{"role": "user", "content": "hi"}]}, False)

    assert cache.get(key) is None
    cache.put(key, {"response": {"id": "chatcmpl-1"}, "tokens": 2})

    stored = cache.get(key)
    assert stored == {"response": {"id": "chatcmpl-1"}, "tokens": 2}
    assert cache.key({"messages": [{"role": "user", "content": "hi"}], "model": "m"}, False) == key
    assert cache.key({"model": "m"}, True) != key


def test_response_cache_ignores_expired_and_corrupted(tmp_path):
    cache = ResponseCache(tmp_path / "cache", ttl_seconds=1)
    key = cache.key({"model": "m"}, False)

    path = tmp_path / "cache" / f"{key}.json"
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({"created_at": time.time() - 10, "value": {"x": 1}}), encoding="utf-8")
    assert cache.get(key) is None
    assert not path.exists()

    (tmp_path / "cache" / f"{cache.key({'model': 'bad'}, False)}.json").write_text("not json", encoding="utf-8")
    assert cache.get(cache.key({"model": "bad"}, False)) is None


# ---------------------------------------------------------------------------
# 端点：降级、终止、缓存兜底
# ---------------------------------------------------------------------------


def _success(model: str, total: int = 3) -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1,
            "model": model,
            "choices": [
                {"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}
            ],
            "usage": {"prompt_tokens": 1, "completion_tokens": 2, "total_tokens": total},
        },
    )


class _SeqHandler:
    def __init__(self, *, fail_model: str, fail_status: int = 500, fail_code: str = "server_error"):
        self.fail_model = fail_model
        self.fail_status = fail_status
        self.fail_code = fail_code
        self.calls: list[tuple[str, str]] = []

    async def complete(self, client, provider, payload):
        self.calls.append((provider.name, payload["model"]))
        if self.fail_model is None or payload["model"] == self.fail_model:
            return httpx.Response(
                self.fail_status,
                json={"error": {"message": "boom", "type": "upstream_error", "code": self.fail_code}},
            )
        return _success(payload["model"])

    async def open_stream(self, client, provider, payload):
        self.calls.append((provider.name, payload["model"]))
        if self.fail_model is None or payload["model"] == self.fail_model:
            return httpx.Response(
                self.fail_status,
                json={"error": {"message": "boom", "type": "upstream_error", "code": self.fail_code}},
            )
        return httpx.Response(
            200,
            content=b'data: {"id":"c1","object":"chat.completion.chunk","model":"m","choices":[]}\n\ndata: [DONE]\n\n',
            headers={"content-type": "text/event-stream"},
        )

    def transform_stream(self, upstream, client_model, provider):
        async def generator():
            for line in upstream.text.splitlines(keepends=True):
                yield line

        return generator()


def _install(monkeypatch, handler):
    monkeypatch.setattr("api.api.get_handler", lambda modality: handler)


def test_primary_retries_twice_then_fallback_succeeds(client, monkeypatch):
    handler = _SeqHandler(fail_model="custom-model")
    _install(monkeypatch, handler)

    resp = client.post(
        "/v1/chat/completions",
        json={"model": "custom-model", "messages": [{"role": "user", "content": "hi"}]},
    )

    assert resp.status_code == 200
    assert resp.json()["choices"][0]["message"]["content"] == "ok"
    assert [model for _, model in handler.calls] == ["custom-model", "custom-model", "gpt-4o-mini"]


def test_auth_error_terminates_without_retry_or_fallback(client, monkeypatch):
    handler = _SeqHandler(fail_model="custom-model", fail_status=401, fail_code="authentication_error")
    _install(monkeypatch, handler)

    resp = client.post(
        "/v1/chat/completions",
        json={"model": "custom-model", "messages": [{"role": "user", "content": "hi"}]},
    )

    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "authentication_error"
    assert len(handler.calls) == 1


def test_model_error_terminates_without_retry(client, monkeypatch):
    handler = _SeqHandler(fail_model="custom-model", fail_status=404, fail_code="model_not_found")
    _install(monkeypatch, handler)

    resp = client.post(
        "/v1/chat/completions",
        json={"model": "custom-model", "messages": [{"role": "user", "content": "hi"}]},
    )

    assert resp.status_code == 404
    assert len(handler.calls) == 1


def test_all_modes_fail_then_cache_hit(client, monkeypatch):
    handler = _SeqHandler(fail_model=None)
    _install(monkeypatch, handler)

    payload = {
        "model": "custom-model",
        "messages": [{"role": "user", "content": "hi"}],
        "stream": False,
    }
    cache = get_cache()
    cache.put(
        cache.key({"model": "custom-model", "payload": payload}, False),
        {"response": {"id": "cached-1", "object": "chat.completion", "created": 1, "model": "custom-model",
                      "choices": [{"index": 0, "message": {"role": "assistant", "content": "cached"}, "finish_reason": "stop"}]},
         "tokens": 0},
    )

    resp = client.post(
        "/v1/chat/completions",
        json={"model": "custom-model", "messages": [{"role": "user", "content": "hi"}]},
    )

    assert resp.status_code == 200
    body = resp.json()
    assert body["cached"] is True
    assert body["choices"][0]["message"]["content"] == "cached"
    assert len(handler.calls) == 4  # 主模式 2 次 + 备用模式 2 次


def test_stream_falls_back_before_first_chunk(client, monkeypatch):
    handler = _SeqHandler(fail_model="custom-model")
    _install(monkeypatch, handler)

    with client.stream(
        "POST",
        "/v1/chat/completions",
        json={"model": "custom-model", "messages": [{"role": "user", "content": "hi"}], "stream": True},
    ) as resp:
        body = "".join(resp.iter_text())

    assert resp.status_code == 200
    assert "data: [DONE]" in body
    assert [model for _, model in handler.calls] == ["custom-model", "custom-model", "gpt-4o-mini"]


# ---------------------------------------------------------------------------
# 指标与埋点落盘
# ---------------------------------------------------------------------------


def _wait_for_lines(path: Path, predicate, timeout: float = 2.0) -> list[dict]:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if path.is_file():
            records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
            matched = [record for record in records if predicate(record)]
            if matched:
                return matched
        time.sleep(0.02)
    return []


def test_metrics_and_traces_persisted_as_txt(client, monkeypatch):
    handler = _SeqHandler(fail_model="never")
    _install(monkeypatch, handler)

    resp = client.post(
        "/v1/chat/completions",
        json={"model": "custom-model", "messages": [{"role": "user", "content": "hi"}]},
    )
    request_id = resp.headers["X-Request-Id"]

    metrics = _wait_for_lines(
        Path(os.environ["METRICS_DIR"]) / "metrics.txt",
        lambda record: record.get("request_id") == request_id,
    )
    assert metrics, "metrics.txt 未写入请求指标"
    record = metrics[-1]
    assert set(record) >= {
        "request_id",
        "mode_started_at",
        "mode_ended_at",
        "ttft_ms",
        "total_tokens",
        "status",
    }
    assert record["status"] in ALLOWED_STATUSES
    assert record["total_tokens"] == 3

    traces = _wait_for_lines(
        Path(os.environ["TRACE_DIR"]) / "traces.txt",
        lambda record: record.get("request_id") == request_id,
    )
    assert traces, "traces.txt 未写入埋点"
    assert {record["span"] for record in traces} >= {"route.resolve", "payload.build", "upstream.complete"}
    assert all("duration_ms" in record for record in traces)
