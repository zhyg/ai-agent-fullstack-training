"""兼容性与路由注册测试。"""

from __future__ import annotations

from api.api import LLMRequest


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_models_route(client):
    resp = client.get("/v1/models")
    assert resp.status_code == 200
    assert resp.json()["object"] == "list"


def test_routes_present(client):
    paths = client.get("/openapi.json").json()["paths"]
    assert "/v1/chat/completions" in paths
    assert "/v1/response" in paths
    assert "/api/v1/prompts" in paths


def test_request_without_prompt_has_no_prompt_field():
    body = LLMRequest(model="gpt-4o-mini", messages=[{"role": "user", "content": "hi"}])
    payload = body.model_dump(exclude_none=True)
    assert "prompt" not in payload
    assert payload["messages"] == [{"role": "user", "content": "hi"}]
