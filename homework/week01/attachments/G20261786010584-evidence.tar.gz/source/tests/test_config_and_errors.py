"""配置集中化与错误集中化测试。"""

from __future__ import annotations

import os

import pytest

import config.loader as loader
from config.loader import (
    get_app_config,
    get_prompt_config,
    get_runtime_config,
    reset_llm_config,
)
from error.base import GatewayError, PromptError
from error.codes import ErrorCode, matches, PROMPT_MISSING_CODES
from error.http import prompt_http_error, response_http_error
from error.provider import UnknownProtocolError
from error.status import InvalidExecutionStatusError
from error.upstream import extract_error
from gateway.status import normalize_status


def test_runtime_config_sections_and_env_expansion():
    config = get_runtime_config()
    assert {"retry", "cache", "metrics", "trace", "observability"} <= set(config)
    assert int(config["retry"]["retry_delay_ms"]) == int(os.getenv("RETRY_DELAY_MS", "200"))
    assert config["cache"]["directory"] == os.getenv("CACHE_DIR")
    assert config["metrics"]["directory"] == os.getenv("METRICS_DIR")
    assert config["trace"]["directory"] == os.getenv("TRACE_DIR")
    assert int(config["observability"]["queue_size"]) == 2048


def test_prompt_config_sections_and_defaults():
    config = get_prompt_config()
    assert {"store", "audit", "system", "templating"} <= set(config)
    assert config["store"]["directory"] == os.getenv("PROMPT_STORE_DIR")
    assert config["system"]["config_path"] == "config/system_prompts.yaml"
    assert int(config["templating"]["max_template_bytes"]) == 262_144
    assert config["audit"]["redact_keys"]


def test_app_config_and_manage_flag():
    config = get_app_config()
    assert config["server"]["host"] == os.getenv("HOST", "0.0.0.0")
    assert config["gateway"]["prompt_manage_enabled"] == os.getenv("PROMPT_MANAGE_ENABLED")

    from main import _manage_enabled

    assert _manage_enabled() is True


def test_runtime_config_env_specific_file(tmp_path, monkeypatch):
    monkeypatch.setattr(loader, "_ROOT", tmp_path)
    monkeypatch.delenv("GATEWAY_RUNTIME_CONFIG", raising=False)
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    (config_dir / "runtime.yaml").write_text("cache:\n  ttl_seconds: 300\n", encoding="utf-8")
    (config_dir / "runtime.dev.yaml").write_text("cache:\n  ttl_seconds: 30\n", encoding="utf-8")
    reset_llm_config()

    monkeypatch.setenv("GATEWAY_ENV", "dev")
    assert get_runtime_config()["cache"]["ttl_seconds"] == 30


def test_error_hierarchy_and_http_payload():
    error = PromptError("prompt_not_found", "missing", 404, {"id": "qa"})
    assert isinstance(error, GatewayError)
    assert error.code == "prompt_not_found"

    http = prompt_http_error(error)
    assert http.status_code == 404
    assert http.detail["error"] == {
        "message": "missing",
        "type": "invalid_request_error",
        "code": "prompt_not_found",
        "details": {"id": "qa"},
    }

    response_error = response_http_error(400, "response_invalid", "bad", {"reason": "x"})
    assert response_error.detail["error"]["details"] == {"reason": "x"}


def test_error_classification_and_status_validation():
    assert matches(PROMPT_MISSING_CODES, ErrorCode.PROMPT_NOT_FOUND)
    assert normalize_status("completed") is normalize_status("completed")

    with pytest.raises(InvalidExecutionStatusError):
        normalize_status("ok")

    with pytest.raises(UnknownProtocolError):
        from provider.protocols.registry import get_protocol

        get_protocol("unknown-protocol")


def test_extract_error_normalizes_non_json_body():
    payload = extract_error(b"plain failure", 502)
    assert payload["error"]["message"] == "plain failure"
    assert payload["error"]["type"] == "upstream_error"
    assert payload["error"]["code"] == 502
