"""Anthropic 协议规则单元测试：请求格式化、响应解析、错误映射、流式转换与动态加载。"""

from __future__ import annotations

import json

import httpx
import pytest

import router.router as router_router
from provider import Provider
from provider.protocols.anthropic import AnthropicProtocol, AnthropicStreamConverter
from provider.protocols.openai import OpenAIProtocol
from provider.protocols.registry import get_protocol, protocol_names


def _provider(**options) -> Provider:
    opts = {"anthropic_version": "2023-06-01", "default_max_tokens": 2048}
    opts.update(options)
    return Provider(
        name="anthropic",
        base_url="https://api.anthropic.com/v1",
        api_key="sk-ant-test",
        protocol="anthropic",
        options=opts,
    )


def _decode(lines: list[str]) -> list[dict]:
    return [json.loads(line[len("data: ") :]) for line in lines if line.startswith("data: ") and "[DONE]" not in line]


# ---------------------------------------------------------------------------
# 协议注册
# ---------------------------------------------------------------------------


def test_protocol_registry_contains_both_protocols():
    assert set(protocol_names()) == {"openai", "anthropic"}
    assert get_protocol("anthropic").endpoint == "/messages"
    assert get_protocol(None).name == "openai"
    with pytest.raises(ValueError):
        get_protocol("unknown")


def test_provider_registry_loads_protocol_from_config(tmp_path, monkeypatch):
    import provider.registry as registry

    config = tmp_path / "providers.yaml"
    config.write_text(
        """
default_provider: anthropic
providers:
  anthropic:
    base_url: "https://api.anthropic.com/v1"
    api_key: "static-key"
    protocol: anthropic
    options:
      anthropic_version: "2023-06-01"
  legacy:
    base_url: "https://api.openai.com/v1"
""",
        encoding="utf-8",
    )

    providers, default = registry._load(config)
    assert default == "anthropic"
    assert providers["anthropic"].protocol == "anthropic"
    assert providers["anthropic"].api_key == "static-key"
    assert providers["anthropic"].options["anthropic_version"] == "2023-06-01"
    assert providers["legacy"].protocol == "openai"


def test_provider_registry_rejects_unknown_protocol(tmp_path, monkeypatch):
    import provider.registry as registry

    config = tmp_path / "providers.yaml"
    config.write_text(
        """
providers:
  broken:
    base_url: "https://example.com"
    protocol: nowhere
""",
        encoding="utf-8",
    )

    with pytest.raises(ValueError):
        registry._load(config)


# ---------------------------------------------------------------------------
# 请求格式化
# ---------------------------------------------------------------------------


def test_headers_use_anthropic_auth_scheme():
    headers = AnthropicProtocol().headers(_provider())
    assert headers["x-api-key"] == "sk-ant-test"
    assert headers["anthropic-version"] == "2023-06-01"
    assert "Authorization" not in headers


def test_format_request_extracts_system_and_maps_params():
    payload = {
        "model": "claude-3-5-sonnet-20241022",
        "messages": [
            {"role": "system", "content": "be concise"},
            {"role": "developer", "content": "and polite"},
            {"role": "user", "content": "hi"},
        ],
        "temperature": 1.5,
        "top_p": 0.9,
        "stop": "END",
        "user": "u-1",
        "n": 2,
        "response_format": {"type": "json_object"},
        "provider": "anthropic",
    }

    body = AnthropicProtocol().format_request(payload, _provider())

    assert body["model"] == "claude-3-5-sonnet-20241022"
    assert body["system"] == "be concise\n\nand polite"
    assert body["messages"] == [{"role": "user", "content": [{"type": "text", "text": "hi"}]}]
    assert body["max_tokens"] == 2048  # 来自 provider.options
    assert body["temperature"] == 1.0  # 超出 Anthropic 上限时截断
    assert body["top_p"] == 0.9
    assert body["stop_sequences"] == ["END"]
    assert body["metadata"] == {"user_id": "u-1"}
    for dropped in ("n", "response_format", "provider", "stop", "user"):
        assert dropped not in body


def test_format_request_defaults_max_tokens_and_merges_consecutive_roles():
    payload = {
        "model": "claude",
        "messages": [
            {"role": "user", "content": "one"},
            {"role": "user", "content": "two"},
        ],
    }
    body = AnthropicProtocol().format_request(payload, _provider(default_max_tokens=None))

    assert body["max_tokens"] == 1024
    assert len(body["messages"]) == 1
    assert body["messages"][0]["content"] == [
        {"type": "text", "text": "one"},
        {"type": "text", "text": "two"},
    ]


def test_format_request_converts_tools_and_tool_choice():
    payload = {
        "model": "claude",
        "messages": [{"role": "user", "content": "weather?"}],
        "tools": [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "lookup weather",
                    "parameters": {"type": "object", "properties": {"city": {"type": "string"}}},
                },
            }
        ],
        "tool_choice": {"type": "function", "function": {"name": "get_weather"}},
    }
    body = AnthropicProtocol().format_request(payload, _provider())

    assert body["tools"] == [
        {
            "name": "get_weather",
            "description": "lookup weather",
            "input_schema": {"type": "object", "properties": {"city": {"type": "string"}}},
        }
    ]
    assert body["tool_choice"] == {"type": "tool", "name": "get_weather"}


def test_format_request_converts_assistant_tool_calls_and_tool_results():
    payload = {
        "model": "claude",
        "messages": [
            {"role": "user", "content": "weather?"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "toolu_1",
                        "type": "function",
                        "function": {"name": "get_weather", "arguments": '{"city": "SH"}'},
                    }
                ],
            },
            {"role": "tool", "tool_call_id": "toolu_1", "content": "sunny"},
        ],
    }
    body = AnthropicProtocol().format_request(payload, _provider())

    assert body["messages"][1] == {
        "role": "assistant",
        "content": [
            {
                "type": "tool_use",
                "id": "toolu_1",
                "name": "get_weather",
                "input": {"city": "SH"},
            }
        ],
    }
    assert body["messages"][2] == {
        "role": "user",
        "content": [{"type": "tool_result", "tool_use_id": "toolu_1", "content": "sunny"}],
    }


def test_format_request_converts_image_parts():
    payload = {
        "model": "claude",
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "describe"},
                    {"type": "image_url", "image_url": {"url": "data:image/png;base64,AAAA"}},
                    {"type": "image_url", "image_url": {"url": "https://example.com/a.png"}},
                ],
            }
        ],
    }
    body = AnthropicProtocol().format_request(payload, _provider())

    assert body["messages"][0]["content"] == [
        {"type": "text", "text": "describe"},
        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "AAAA"}},
        {"type": "image", "source": {"type": "url", "url": "https://example.com/a.png"}},
    ]


# ---------------------------------------------------------------------------
# 响应解析
# ---------------------------------------------------------------------------


def test_format_response_text_and_usage():
    data = {
        "id": "msg_1",
        "type": "message",
        "role": "assistant",
        "content": [{"type": "text", "text": "Hello"}, {"type": "text", "text": " world"}],
        "model": "claude-3-5-sonnet-20241022",
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 10, "output_tokens": 5},
    }
    result = AnthropicProtocol().format_response(data, client_model="my-model")

    choice = result["choices"][0]
    assert choice["message"] == {"role": "assistant", "content": "Hello world"}
    assert choice["finish_reason"] == "stop"
    assert result["model"] == "my-model"
    assert result["usage"] == {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    assert result["object"] == "chat.completion"


def test_format_response_tool_use():
    data = {
        "id": "msg_2",
        "content": [{"type": "tool_use", "id": "toolu_1", "name": "get_weather", "input": {"city": "SH"}}],
        "model": "claude",
        "stop_reason": "tool_use",
        "usage": {"input_tokens": 3, "output_tokens": 2},
    }
    result = AnthropicProtocol().format_response(data)

    message = result["choices"][0]["message"]
    assert message["content"] is None
    assert message["tool_calls"] == [
        {
            "id": "toolu_1",
            "type": "function",
            "function": {"name": "get_weather", "arguments": '{"city": "SH"}'},
        }
    ]
    assert result["choices"][0]["finish_reason"] == "tool_calls"


@pytest.mark.parametrize(
    ("stop_reason", "expected"),
    [
        ("end_turn", "stop"),
        ("max_tokens", "length"),
        ("stop_sequence", "stop"),
        ("tool_use", "tool_calls"),
        ("refusal", "content_filter"),
        (None, "stop"),
    ],
)
def test_finish_reason_mapping(stop_reason, expected):
    data = {"content": [{"type": "text", "text": "x"}], "stop_reason": stop_reason}
    assert AnthropicProtocol().format_response(data)["choices"][0]["finish_reason"] == expected


# ---------------------------------------------------------------------------
# 错误映射
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("content", "status", "expected_status", "expected_type"),
    [
        (b'{"type":"error","error":{"type":"rate_limit_error","message":"slow down"}}', 429, 429, "rate_limit_error"),
        (b'{"type":"error","error":{"type":"overloaded_error","message":"busy"}}', 529, 503, "overloaded_error"),
        (b'{"type":"error","error":{"type":"authentication_error","message":"bad key"}}', 401, 401, "authentication_error"),
        (b'{"type":"error","error":{"type":"invalid_request_error","message":"bad"}}', 400, 400, "invalid_request_error"),
        (b'{"type":"error","error":{"type":"api_error","message":"boom"}}', 500, 500, "api_error"),
    ],
)
def test_error_mapping(content, status, expected_status, expected_type):
    mapped_status, error = AnthropicProtocol().format_error(content, status)
    assert mapped_status == expected_status
    assert error["error"]["code"] == expected_type
    assert error["error"]["type"] == ("invalid_request_error" if expected_status < 500 else "gateway_error")
    assert error["error"]["details"]["upstream_status"] == status


def test_error_mapping_plain_text_body():
    mapped_status, error = AnthropicProtocol().format_error(b"oops", 500)
    assert mapped_status == 500
    assert error["error"]["message"] == "oops"
    assert error["error"]["code"] == "api_error"


# ---------------------------------------------------------------------------
# 流式转换
# ---------------------------------------------------------------------------


def _event(payload: dict) -> str:
    return json.dumps(payload)


def test_stream_converter_text_flow():
    converter = AnthropicStreamConverter("my-model")
    outputs: list[str] = []

    outputs += converter.feed(
        _event(
            {
                "type": "message_start",
                "message": {
                    "id": "msg_1",
                    "model": "claude",
                    "usage": {"input_tokens": 7, "output_tokens": 1},
                },
            }
        )
    )
    outputs += converter.feed(_event({"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}}))
    outputs += converter.feed(_event({"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Hel"}}))
    outputs += converter.feed(_event({"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "lo"}}))
    outputs += converter.feed(
        _event(
            {
                "type": "message_delta",
                "delta": {"stop_reason": "end_turn"},
                "usage": {"output_tokens": 2},
            }
        )
    )
    outputs += converter.feed(_event({"type": "message_stop"}))
    outputs += converter.close()

    payloads = _decode(outputs)
    assert payloads[0]["choices"][0]["delta"] == {"role": "assistant", "content": ""}
    assert payloads[0]["model"] == "my-model"
    assert payloads[0]["usage"]["prompt_tokens"] == 7
    assert payloads[1]["choices"][0]["delta"]["content"] == "Hel"
    assert payloads[2]["choices"][0]["delta"]["content"] == "lo"
    assert payloads[3]["choices"][0]["finish_reason"] == "stop"
    assert payloads[3]["usage"] == {"prompt_tokens": 0, "completion_tokens": 2, "total_tokens": 2}
    assert outputs[-1] == "data: [DONE]\n\n"


def test_stream_converter_tool_use_flow():
    converter = AnthropicStreamConverter("my-model")
    outputs: list[str] = []
    outputs += converter.feed(
        _event({"type": "content_block_start", "index": 1, "content_block": {"type": "tool_use", "id": "toolu_1", "name": "get_weather"}})
    )
    outputs += converter.feed(
        _event({"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": '{"city"'}})
    )
    outputs += converter.feed(
        _event({"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": ': "SH"}'}})
    )
    outputs += converter.feed(_event({"type": "message_delta", "delta": {"stop_reason": "tool_use"}}))

    payloads = _decode(outputs)
    tool_start = payloads[0]["choices"][0]["delta"]["tool_calls"][0]
    assert tool_start["id"] == "toolu_1"
    assert tool_start["function"]["name"] == "get_weather"
    assert payloads[1]["choices"][0]["delta"]["tool_calls"][0]["function"]["arguments"] == '{"city"'
    assert payloads[2]["choices"][0]["delta"]["tool_calls"][0]["function"]["arguments"] == ': "SH"}'
    assert payloads[3]["choices"][0]["finish_reason"] == "tool_calls"


def test_stream_converter_error_event():
    converter = AnthropicStreamConverter("my-model")
    outputs = converter.feed(
        _event({"type": "error", "error": {"type": "overloaded_error", "message": "busy"}})
    )

    payloads = _decode(outputs)
    assert payloads[0]["error"]["code"] == "overloaded_error"
    assert outputs[-1] == "data: [DONE]\n\n"
    assert converter.close() == []


def test_openai_stream_converter_still_rewrites_model():
    converter = OpenAIProtocol().stream_converter("alias")
    outputs = converter.feed(json.dumps({"model": "upstream", "choices": []}))
    assert _decode(outputs)[0]["model"] == "alias"
    assert converter.feed("[DONE]") == ["data: [DONE]\n\n"]


# ---------------------------------------------------------------------------
# 端点集成（替换传输层为假响应）
# ---------------------------------------------------------------------------


@pytest.fixture()
def anthropic_provider(monkeypatch):
    provider = _provider()
    original = router_router.get_provider

    def fake_get_provider(name: str):
        return provider if name == "anthropic" else original(name)

    monkeypatch.setattr(router_router, "get_provider", fake_get_provider)
    return provider


def test_chat_endpoint_normalizes_anthropic_response(client, anthropic_provider, monkeypatch):
    captured: dict = {}

    async def fake_post(http_client, provider, path, payload, headers=None):
        captured.update(path=path, payload=payload, headers=headers)
        return httpx.Response(
            200,
            json={
                "id": "msg_1",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "text", "text": "hello"}],
                "model": "claude-3-5-sonnet-20241022",
                "stop_reason": "end_turn",
                "usage": {"input_tokens": 4, "output_tokens": 2},
            },
        )

    monkeypatch.setattr("adapter.chat.post_json", fake_post)

    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "anthropic/claude-3-5-sonnet-20241022",
            "messages": [
                {"role": "system", "content": "be nice"},
                {"role": "user", "content": "hi"},
            ],
        },
    )

    assert resp.status_code == 200
    body = resp.json()
    assert body["model"] == "anthropic/claude-3-5-sonnet-20241022"
    assert body["choices"][0]["message"]["content"] == "hello"
    assert body["usage"]["total_tokens"] == 6

    assert captured["path"] == "/messages"
    assert captured["headers"]["x-api-key"] == "sk-ant-test"
    assert captured["payload"]["system"] == "be nice"
    assert captured["payload"]["messages"] == [{"role": "user", "content": [{"type": "text", "text": "hi"}]}]


def test_chat_endpoint_maps_anthropic_error(client, anthropic_provider, monkeypatch):
    from gateway.resilience import Target

    async def fake_post(http_client, provider, path, payload, headers=None):
        return httpx.Response(
            529,
            json={"type": "error", "error": {"type": "overloaded_error", "message": "busy"}},
        )

    monkeypatch.setattr("adapter.chat.post_json", fake_post)
    # 关闭降级模式，单独验证 Anthropic 错误码映射
    monkeypatch.setattr("api.api.build_targets", lambda provider, model: [Target("primary", provider, model)])

    resp = client.post(
        "/v1/chat/completions",
        json={"model": "anthropic/claude-3-5-sonnet-20241022", "messages": [{"role": "user", "content": "hi"}]},
    )

    assert resp.status_code == 503
    assert resp.json()["error"]["code"] == "overloaded_error"


def test_chat_endpoint_streams_openai_chunks(client, anthropic_provider, monkeypatch):
    sse = (
        'data: {"type":"message_start","message":{"id":"msg_1","model":"claude","usage":{"input_tokens":2,"output_tokens":0}}}\n\n'
        'data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}\n\n'
        'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Hi"}}\n\n'
        'data: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":1}}\n\n'
        'data: {"type":"message_stop"}\n\n'
    ).encode("utf-8")

    async def fake_send(http_client, provider, path, payload, headers=None):
        return httpx.Response(200, content=sse, headers={"content-type": "text/event-stream"})

    monkeypatch.setattr("adapter.chat.send_stream", fake_send)

    with client.stream(
        "POST",
        "/v1/chat/completions",
        json={
            "model": "anthropic/claude-3-5-sonnet-20241022",
            "messages": [{"role": "user", "content": "hi"}],
            "stream": True,
        },
    ) as resp:
        body = "".join(resp.iter_text())

    assert resp.status_code == 200
    assert '"content": "Hi"' in body
    assert '"finish_reason": "stop"' in body
    assert "data: [DONE]" in body
    assert '"model": "anthropic/claude-3-5-sonnet-20241022"' in body
