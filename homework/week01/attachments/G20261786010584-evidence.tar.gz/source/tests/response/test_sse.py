"""SSE 编码与生命周期单元测试。"""

from __future__ import annotations

import asyncio
import json

from response.sse import encode_event_json, encode_sse, iter_chunks
from response.service import event_stream


def test_encode_single_event():
    assert encode_sse("hello", event="message", event_id="1") == "id: 1\nevent: message\ndata: hello\n\n"


def test_encode_multiline_data():
    assert encode_sse("line1\nline2") == "data: line1\ndata: line2\n\n"


def test_encode_retry_order():
    text = encode_sse("x", event="e", event_id="7", retry=1500)
    assert text == "retry: 1500\nid: 7\nevent: e\ndata: x\n\n"


def test_encode_comment():
    assert encode_sse(comment="ping") == ": ping\n\n"


def test_encode_event_json():
    text = encode_event_json({"code": "x", "message": "失败"}, event="error")
    payload = text.split("data: ", 1)[1].strip()
    assert json.loads(payload)["code"] == "x"
    assert "event: error" in text


def test_iter_chunks_reassemble():
    text = "abcdefghij"
    chunks = list(iter_chunks(text, 3))
    assert chunks == ["abc", "def", "ghi", "j"]
    assert "".join(chunks) == text


class _FakeRequest:
    def __init__(self, disconnect_after: int | None = None):
        self.calls = 0
        self.disconnect_after = disconnect_after

    async def is_disconnected(self) -> bool:
        self.calls += 1
        return self.disconnect_after is not None and self.calls >= self.disconnect_after


def _collect(agen):
    async def run():
        return [item async for item in agen]

    return asyncio.run(run())


def test_stream_done_event():
    from response.models import StreamOptions

    options = StreamOptions(chunk_size=4)
    events = _collect(event_stream(_FakeRequest(), "abcdefgh", options))
    assert events[0] == "data: abcd\n\n"
    assert events[-1] == "event: done\ndata: [DONE]\n\n"


def test_stream_disconnect_stops_early():
    from response.models import StreamOptions

    options = StreamOptions(chunk_size=4, include_done=False)
    events = _collect(event_stream(_FakeRequest(disconnect_after=2), "abcdefghijkl", options))
    assert len(events) == 1


def test_stream_include_done_disabled():
    from response.models import StreamOptions

    options = StreamOptions(chunk_size=100, include_done=False)
    events = _collect(event_stream(_FakeRequest(), "abc", options))
    assert events == ["data: abc\n\n"]
