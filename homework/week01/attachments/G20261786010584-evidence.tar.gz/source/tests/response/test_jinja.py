"""Jinja2 渲染与边界测试。"""

from __future__ import annotations

import pytest

import templating.jinja as jinja_module
from templating import TemplateRenderError, extract_variable_names, render


@pytest.fixture(autouse=True)
def _clear_cache():
    jinja_module.clear_cache()
    yield
    jinja_module.clear_cache()


def test_variables_and_control_flow():
    source = "{% if show %}Hello {{ user.name }}, {% endif %}{% for item in items %}[{{ item }}]{% endfor %}"
    output = render(source, {"show": True, "user": {"name": "Ada"}, "items": [1, 2, 3]})
    assert output == "Hello Ada, [1][2][3]"


def test_filters_and_set():
    source = "{% set name = user | upper %}{{ name }}:{{ user | length }}"
    assert render(source, {"user": "abc"}) == "ABC:3"


def test_undefined_variable():
    with pytest.raises(TemplateRenderError) as exc:
        render("{{ missing }}", {})
    assert exc.value.code == "template_undefined_variable"


def test_syntax_error():
    with pytest.raises(TemplateRenderError) as exc:
        render("{% if %}", {})
    assert exc.value.code == "template_syntax_error"


def test_sandbox_escape_blocked():
    with pytest.raises(TemplateRenderError) as exc:
        render("{{ ''.__class__.__mro__ }}", {})
    assert exc.value.code == "template_security_error"


def test_include_blocked():
    with pytest.raises(TemplateRenderError) as exc:
        render("{% include 'secret.html' %}", {})
    assert exc.value.code == "template_security_error"


def test_output_size_limit(monkeypatch):
    monkeypatch.setattr(jinja_module, "MAX_RENDERED_CHARS", 5)
    with pytest.raises(TemplateRenderError) as exc:
        render("{{ value }}", {"value": "0123456789"})
    assert exc.value.code == "template_output_too_large"


def test_loop_iteration_limit(monkeypatch):
    monkeypatch.setattr(jinja_module, "MAX_ITERATIONS", 5)
    with pytest.raises(TemplateRenderError) as exc:
        render("{% for item in items %}{{ item }}{% endfor %}", {"items": list(range(10))})
    assert exc.value.code == "template_security_error"


def test_template_size_limit(monkeypatch):
    monkeypatch.setattr(jinja_module, "MAX_TEMPLATE_BYTES", 8)
    with pytest.raises(TemplateRenderError) as exc:
        render("x" * 64, {})
    assert exc.value.code == "template_too_large"


def test_compile_cache_reused():
    render("{{ value }}", {"value": "a"})
    render("{{ value }}", {"value": "b"})
    assert len(jinja_module._CACHE) == 1


def test_extract_variable_names():
    names = extract_variable_names("{{ user.name }}{{ total }}{{ len(items) }}")
    assert names == {"user", "total", "items"}
