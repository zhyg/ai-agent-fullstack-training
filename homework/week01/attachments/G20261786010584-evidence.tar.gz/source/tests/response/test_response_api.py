"""POST /v1/response 端到端测试。"""

from __future__ import annotations

import json

import pytest


pytestmark = pytest.mark.usefixtures("client")


def test_normal_text_response(client):
    resp = client.post(
        "/v1/response",
        json={"status_code": 201, "headers": {"X-Test": "1"}, "body": "hello"},
    )
    assert resp.status_code == 201
    assert resp.text == "hello"
    assert resp.headers["x-test"] == "1"
    assert resp.headers["content-type"].startswith("text/plain")


def test_normal_json_body(client):
    resp = client.post("/v1/response", json={"body": {"ok": True, "value": 1}})
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/json")
    assert resp.json() == {"ok": True, "value": 1}


def test_template_render_with_schema(client):
    resp = client.post(
        "/v1/response",
        json={
            "template": "{% if vip %}VIP{% else %}USER{% endif %}:{{ name }}",
            "variables": {"vip": True, "name": "Ada"},
            "variables_schema": {
                "strict": True,
                "variables": {
                    "vip": {"type": "boolean", "required": True},
                    "name": {"type": "string", "required": True},
                },
            },
        },
    )
    assert resp.status_code == 200
    assert resp.text == "VIP:Ada"


def test_template_variable_error(client):
    resp = client.post(
        "/v1/response",
        json={
            "template": "{{ name }}",
            "variables": {},
            "variables_schema": {
                "variables": {"name": {"type": "string", "required": True}}
            },
        },
    )
    assert resp.status_code == 422
    assert resp.json()["error"]["code"] == "prompt_variable_missing"


def test_body_template_conflict(client):
    resp = client.post("/v1/response", json={"body": "x", "template": "y"})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_body_conflict"


def test_header_injection_rejected(client):
    resp = client.post("/v1/response", json={"body": "x", "headers": {"X-Bad": "a\nb"}})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_header_invalid"


def test_managed_header_rejected(client):
    resp = client.post("/v1/response", json={"body": "x", "headers": {"Content-Length": "10"}})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_header_invalid"


def test_stream_mode_via_query(client):
    resp = client.post(
        "/v1/response?mode=stream",
        json={"body": "abcdefgh", "stream": {"chunk_size": 4}},
    )
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")
    body = resp.text
    assert "data: abcd" in body
    assert "event: done" in body
    assert "data: [DONE]" in body


def test_stream_invalid_status(client):
    resp = client.post("/v1/response", json={"mode": "stream", "status_code": 404, "body": "x"})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_stream_invalid"


def test_stream_invalid_content_type(client):
    resp = client.post(
        "/v1/response",
        json={"mode": "stream", "body": "x", "headers": {"Content-Type": "application/json"}},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_stream_invalid"


def test_unknown_query_mode(client):
    resp = client.post("/v1/response?mode=weird", json={"body": "x"})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_invalid"


def test_large_content_stream_reassembles(client):
    payload = "x" * 600_000
    resp = client.post(
        "/v1/response?mode=stream",
        json={"body": payload, "stream": {"chunk_size": 10_000}},
    )
    assert resp.status_code == 200
    data_lines = [
        line[len("data: ") :]
        for line in resp.text.splitlines()
        if line.startswith("data: ") and line != "data: [DONE]"
    ]
    assert len("".join(data_lines)) == len(payload)
    assert "".join(data_lines) == payload


def test_template_render_error_returns_code(client):
    resp = client.post("/v1/response", json={"template": "{{ missing }}", "variables": {}})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "template_undefined_variable"


def test_extra_field_rejected(client):
    resp = client.post("/v1/response", json={"body": "x", "unknown": 1})
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "response_invalid"
