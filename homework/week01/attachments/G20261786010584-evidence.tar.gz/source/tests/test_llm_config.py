"""大模型配置抽离测试：统一读取接口、环境切换、热更新与业务层接入。"""

from __future__ import annotations

import config.loader as loader
import provider.registry as registry
import router.router as router
from config.loader import get_llm_config, reset_llm_config, resolve_config_path
from gateway.transport import request_timeout


def _write(path, *, default_provider: str, base_url: str, models: str = "") -> None:
    path.write_text(
        f"""\
default_provider: {default_provider}
timeouts:
  total_seconds: 30
  connect_seconds: 3
{models}
providers:
  {default_provider}:
    base_url: "{base_url}"
    api_key: "${{TEST_API_KEY:-}}"
""",
        encoding="utf-8",
    )


def test_default_config_contains_all_llm_settings():
    config = get_llm_config()
    assert config["default_provider"] == "openai"
    assert {"openai", "deepseek", "anthropic"} <= set(config["providers"])
    assert config["providers"]["anthropic"]["options"]["default_max_tokens"] == 1024
    assert config["timeouts"] == {"total_seconds": 600, "connect_seconds": 10}
    assert config["models"]["gpt-4o-mini"] == {"provider": "openai", "model": "gpt-4o-mini"}
    assert config["fallback"] == {"provider": "openai", "model": "gpt-4o-mini"}


def test_env_switch_prefers_env_specific_file(tmp_path, monkeypatch):
    monkeypatch.setattr(loader, "_ROOT", tmp_path)
    monkeypatch.delenv("DEFAULT_PROVIDER", raising=False)
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    _write(config_dir / "llm.yaml", default_provider="openai", base_url="https://api.openai.com/v1")
    _write(config_dir / "llm.dev.yaml", default_provider="deepseek", base_url="https://api.deepseek.com/v1")
    reset_llm_config()

    monkeypatch.setenv("LLM_ENV", "dev")
    assert resolve_config_path().name == "llm.dev.yaml"
    assert registry.get_default_provider() == "deepseek"
    assert registry.get_provider("deepseek").base_url == "https://api.deepseek.com/v1"


def test_hot_reload_when_file_changes(tmp_path):
    path = tmp_path / "llm.yaml"
    path.write_text(
        """\
default_provider: openai
timeouts:
  total_seconds: 10
  connect_seconds: 2
providers:
  openai:
    base_url: "https://api.openai.com/v1"
""",
        encoding="utf-8",
    )
    reset_llm_config()
    first = get_llm_config(path)

    path.write_text(
        """\
default_provider: openai
timeouts:
  total_seconds: 20
  connect_seconds: 4
providers:
  openai:
    base_url: "https://changed.example.com/v1"
""",
        encoding="utf-8",
    )
    second = get_llm_config(path)

    assert first["providers"]["openai"]["base_url"] == "https://api.openai.com/v1"
    assert second["providers"]["openai"]["base_url"] == "https://changed.example.com/v1"
    assert second["timeouts"]["total_seconds"] == 20


def test_business_layer_reads_config_via_loader(tmp_path, monkeypatch):
    monkeypatch.setattr(loader, "_ROOT", tmp_path)
    monkeypatch.delenv("DEFAULT_PROVIDER", raising=False)
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    _write(
        config_dir / "llm.yaml",
        default_provider="openai",
        base_url="https://api.openai.com/v1",
        models="""models:
  mini:
    provider: openai
    model: gpt-mini
""",
    )
    reset_llm_config()

    assert registry.get_provider("openai").api_key is None
    assert router.get_model_aliases()["mini"] == ("openai", "gpt-mini")
    timeout = request_timeout()
    assert timeout.connect == 3
    assert timeout.read == 30
