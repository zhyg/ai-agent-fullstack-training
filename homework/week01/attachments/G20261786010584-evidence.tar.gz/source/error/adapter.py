"""适配器层异常：入参校验、未注册与生命周期状态。"""

from __future__ import annotations

from error.base import GatewayError


class AdapterError(GatewayError):
    """适配器层异常基类。"""


class AdapterParamError(AdapterError, ValueError):
    """入参不合法（类型错误、缺失必要字段等）。"""


class AdapterNotRegisteredError(AdapterError, LookupError):
    """请求的模态未注册对应适配器。"""


class AdapterLifecycleError(AdapterError, RuntimeError):
    """适配器生命周期状态异常。"""
