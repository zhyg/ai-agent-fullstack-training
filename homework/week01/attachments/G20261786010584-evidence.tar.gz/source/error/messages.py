"""集中管理的错误提示文案。

约定：
- 常量用于固定文案；
- 带上占位符的文案通过 format(**kwargs) 生成，避免各模块散落拼接字符串；
- 文案只描述“发生了什么”，不泄露密钥等敏感信息。
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# 网关 / 鉴权
# ---------------------------------------------------------------------------
INVALID_GATEWAY_API_KEY = "Invalid gateway API key"

# ---------------------------------------------------------------------------
# 路由与供应商
# ---------------------------------------------------------------------------
UNKNOWN_PROVIDER = "Unknown provider: {provider}"
UNKNOWN_PROTOCOL = "Unknown provider protocol: {protocol!r}; supported: {supported}"
PROVIDER_UNKNOWN_PROTOCOL = "Provider {name!r} declares unknown protocol {protocol!r}; supported: {supported}"
PROVIDER_DISABLED = "provider {name!r} is disabled"
PROVIDER_CONFIG_INVALID = "provider {name!r} configuration is invalid: {reason}"
PROVIDER_CREDENTIALS_MISSING = "provider {name!r} has no API credential configured"
PROVIDER_UNSUPPORTED_MODALITY = "provider {name!r} does not support modality {modality!r}"
PROVIDER_UNHEALTHY = "provider {name!r} is unhealthy: {reason}"
PROVIDER_AUTH_INVALID = "provider {name!r} credentials are invalid: {reason}"
PROVIDER_UNAVAILABLE = "provider {name!r} is unavailable: {reason}"

# ---------------------------------------------------------------------------
# Trace 查询
# ---------------------------------------------------------------------------
TRACE_QUERY_INVALID = "invalid trace query: {reason}"

# ---------------------------------------------------------------------------
# 上游
# ---------------------------------------------------------------------------
UPSTREAM_TRANSPORT_ERROR = "upstream transport error"
UPSTREAM_INVALID_RESPONSE = "upstream returned non-JSON body"
UPSTREAM_UNAVAILABLE = "all request modes failed and no valid cache available"
UPSTREAM_DEFAULT_ERROR = "Upstream returned {status_code}"
UPSTREAM_ERROR_TYPE = "upstream_error"

# ---------------------------------------------------------------------------
# Response
# ---------------------------------------------------------------------------
RESPONSE_VALIDATION_FAILED = "response request validation failed"
RESPONSE_STREAM_ERROR_CODE = "response_stream_error"
RESPONSE_UNKNOWN_MODE = "unknown mode: {mode}"
RESPONSE_BODY_TEMPLATE_CONFLICT = "body and template are mutually exclusive"
RESPONSE_HEADER_NAME_INVALID = "invalid header name: {name!r}"
RESPONSE_HEADER_MANAGED = "header {name!r} is managed by the gateway"
RESPONSE_HEADER_VALUE_TYPE = "header {name!r} value must be a string"
RESPONSE_HEADER_CONTROL_CHARS = "header {name!r} contains control characters"
RESPONSE_HEADER_VALUE_TOO_LARGE = "header {name!r} value too large"
RESPONSE_HEADERS_TOO_LARGE = "response headers exceed size limit"
RESPONSE_STREAM_STATUS = "stream mode requires a 2xx status code"
RESPONSE_STREAM_CONTENT_TYPE = "stream mode requires Content-Type text/event-stream"

# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------
PROMPT_DISABLED = "prompt template {template_id!r} is disabled"
PROMPT_NOT_FOUND = "prompt template {template_id!r} not found"
PROMPT_VERSION_NOT_FOUND = "prompt template {template_id!r} version {version} not found"
PROMPT_ALREADY_EXISTS = "template {template_id!r} already exists"
PROMPT_VERSION_CONFLICT = "template {template_id!r} current version is {current_version}"
PROMPT_TOO_LARGE = "template exceeds {max_bytes} bytes"
PROMPT_STORE_UNAVAILABLE = "prompt store write failed: {error}"
PROMPT_USER_MESSAGE_MISSING = "template defines user_template but the request has no user message"
PROMPT_DEFINITION_INVALID = "prompt definition is invalid"
PROMPT_STRUCTURED_STREAM_UNSUPPORTED = "structured output is not supported with stream=true"
PROMPT_RESPONSE_FORMAT_CONFLICT = "response_format conflicts with prompt output mode"
PROMPT_UNKNOWN_VARIABLES = "unknown variables are not allowed"
PROMPT_VARIABLES_INVALID = "variables validation failed"
PROMPT_UNDECLARED_VARIABLES = "template references undeclared variables"
PROMPT_SCHEMA_DEPTH = "schema depth exceeds {max_depth}"
PROMPT_VARIABLES_EXCEED = "variables exceed {max_variables}"

# 结构化输出校验
OUTPUT_MAX_CHARS = "output exceeds max_chars"
OUTPUT_EMPTY = "empty structured output"
OUTPUT_INVALID_JSON = "output is not valid JSON"
OUTPUT_NOT_OBJECT = "json output must be an object"
OUTPUT_SCHEMA_MISMATCH = "output does not match schema"

# ---------------------------------------------------------------------------
# 执行状态
# ---------------------------------------------------------------------------
INVALID_EXECUTION_STATUS = "invalid execution status: {value!r}; allowed values: {allowed}"

# ---------------------------------------------------------------------------
# 模板渲染
# ---------------------------------------------------------------------------
TEMPLATE_SOURCE_NOT_STRING = "template source must be a string"
TEMPLATE_TOO_LARGE = "template exceeds {max_bytes} bytes"
TEMPLATE_LOOP_LIMIT = "loop iterations exceeded limit of {limit}"
TEMPLATE_OUTPUT_TOO_LARGE = "rendered output exceeds {limit} chars"
TEMPLATE_LOADING_DISABLED = "template loading is disabled"
