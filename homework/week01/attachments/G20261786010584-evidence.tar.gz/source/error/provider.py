"""供应商/协议相关异常。"""

from __future__ import annotations

from error.base import GatewayError


class UnknownProtocolError(GatewayError, ValueError):
    """配置声明了未注册的上游协议。"""
