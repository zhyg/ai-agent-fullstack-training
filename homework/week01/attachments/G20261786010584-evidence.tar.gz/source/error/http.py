"""HTTP 错误工厂：统一 OpenAI 风格的错误响应结构。"""

from __future__ import annotations

from typing import Any

from fastapi import HTTPException

from error.base import PromptError


def _error_type(status_code: int) -> str:
    return "gateway_error" if status_code >= 500 else "invalid_request_error"


def error_payload(
    status_code: int,
    code: Any,
    message: str,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """构造 {"error": {...}} 载荷；details 为 None 时不输出该字段。"""

    error: dict[str, Any] = {
        "message": message,
        "type": _error_type(status_code),
        "code": code,
    }
    if details is not None:
        error["details"] = details
    return {"error": error}


def http_error(
    status_code: int,
    code: Any,
    message: str,
    *,
    details: dict[str, Any] | None = None,
) -> HTTPException:
    return HTTPException(status_code, error_payload(status_code, code, message, details))


def prompt_http_error(exc: PromptError) -> HTTPException:
    """把 PromptError 转成 HTTP 异常，保留 code/details。"""

    return HTTPException(
        exc.status_code,
        {
            "error": {
                "message": exc.message,
                "type": _error_type(exc.status_code),
                "code": exc.code,
                "details": exc.details,
            }
        },
    )


def response_http_error(
    status_code: int,
    code: Any,
    message: str,
    details: dict[str, Any] | None = None,
) -> HTTPException:
    """Response 分支错误，始终携带 details（与原有响应结构一致）。"""

    return HTTPException(
        status_code,
        {
            "error": {
                "message": message,
                "type": _error_type(status_code),
                "code": code,
                "details": details or {},
            }
        },
    )
