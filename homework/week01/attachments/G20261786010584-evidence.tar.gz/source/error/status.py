"""执行状态异常。"""

from __future__ import annotations

from error.base import GatewayError


class InvalidExecutionStatusError(GatewayError, ValueError):
    """非法的执行状态取值（仅允许 completed/failed/cancelled）。"""
