"""错误码与错误分类集合。

错误码用于对外稳定标识（写入错误响应与指标），分类集合用于重试/降级决策。
新增错误码时请同时补充到对应的分类集合，避免重试策略出现盲区。
"""

from __future__ import annotations

import enum
from typing import Any


class ErrorCode(enum.StrEnum):
    # 通用 / 网关
    INVALID_GATEWAY_API_KEY = "invalid_gateway_api_key"
    UPSTREAM_TRANSPORT_ERROR = "upstream_transport_error"
    UPSTREAM_INVALID_RESPONSE = "upstream_invalid_response"
    UPSTREAM_UNAVAILABLE = "upstream_unavailable"

    # 路由 / 供应商
    UNKNOWN_PROVIDER = "unknown_provider"
    UNKNOWN_PROTOCOL = "unknown_protocol"
    PROVIDER_DISABLED = "provider_disabled"
    PROVIDER_CONFIG_INVALID = "provider_config_invalid"
    PROVIDER_CREDENTIALS_MISSING = "provider_credentials_missing"
    PROVIDER_UNSUPPORTED_MODALITY = "provider_unsupported_modality"
    PROVIDER_UNHEALTHY = "provider_unhealthy"
    PROVIDER_AUTH_INVALID = "provider_auth_invalid"
    PROVIDER_UNAVAILABLE = "provider_unavailable"

    # Trace 查询
    TRACE_QUERY_INVALID = "trace_query_invalid"

    # Prompt
    PROMPT_NOT_FOUND = "prompt_not_found"
    PROMPT_VERSION_NOT_FOUND = "prompt_version_not_found"
    PROMPT_VERSION_CONFLICT = "prompt_version_conflict"
    PROMPT_INVALID = "prompt_invalid"
    PROMPT_STORE_UNAVAILABLE = "prompt_store_unavailable"
    PROMPT_USER_MESSAGE_MISSING = "prompt_user_message_missing"
    PROMPT_VARIABLES_INVALID = "prompt_variables_invalid"
    PROMPT_VARIABLE_UNKNOWN = "prompt_variable_unknown"
    PROMPT_VARIABLE_MISSING = "prompt_variable_missing"
    PROMPT_PLACEHOLDER_UNDECLARED = "prompt_placeholder_undeclared"
    PROMPT_OUTPUT_MODE_CONFLICT = "prompt_output_mode_conflict"
    STRUCTURED_OUTPUT_INVALID = "structured_output_invalid"
    STRUCTURED_OUTPUT_REQUIRES_NON_STREAM = "structured_output_requires_non_stream"

    # Response
    RESPONSE_INVALID = "response_invalid"
    RESPONSE_BODY_CONFLICT = "response_body_conflict"
    RESPONSE_HEADER_INVALID = "response_header_invalid"
    RESPONSE_STREAM_INVALID = "response_stream_invalid"
    RESPONSE_STREAM_ERROR = "response_stream_error"

    # 模板渲染
    TEMPLATE_RENDER_ERROR = "template_render_error"
    TEMPLATE_SYNTAX_ERROR = "template_syntax_error"
    TEMPLATE_UNDEFINED_VARIABLE = "template_undefined_variable"
    TEMPLATE_SECURITY_ERROR = "template_security_error"
    TEMPLATE_TOO_LARGE = "template_too_large"
    TEMPLATE_OUTPUT_TOO_LARGE = "template_output_too_large"


PROMPT_MISSING_CODES = frozenset(
    {
        ErrorCode.PROMPT_NOT_FOUND,
        ErrorCode.PROMPT_VERSION_NOT_FOUND,
        ErrorCode.PROMPT_USER_MESSAGE_MISSING,
        "prompt_template_missing",
    }
)

OVER_BUDGET_CODES = frozenset(
    {
        "insufficient_quota",
        "quota_exceeded",
        "billing_hard_limit_reached",
        "budget_exceeded",
        "account_over_budget",
        "billing_error",
    }
)

AUTH_CODES = frozenset(
    {
        "authentication_error",
        "permission_error",
        "invalid_api_key",
        "invalid_token",
        "unauthorized",
        "authentication_failed",
    }
)

MODEL_CODES = frozenset(
    {
        "model_not_found",
        "unknown_model",
        "invalid_model",
        "provider_not_found",
        ErrorCode.UNKNOWN_PROVIDER,
    }
)

TRANSIENT_CODES = frozenset(
    {
        "rate_limit_error",
        "overloaded_error",
        "timeout_error",
        ErrorCode.UPSTREAM_TRANSPORT_ERROR,
        "api_connection_error",
        "server_error",
    }
)


def matches(codes: frozenset[Any], value: Any) -> bool:
    """错误码既可能是字符串，也可能是 ErrorCode 枚举。"""

    text = str(value or "").strip().lower()
    return any(str(code).lower() == text for code in codes)
