"""错误基类：网关统一异常层级。

- GatewayError：所有自定义业务异常的根，便于统一捕获与分类；
- PromptError：Prompt 编排/存储/校验异常，携带稳定错误码与 HTTP 状态码；
- TemplateRenderError：Jinja2 渲染异常，携带稳定错误码。
"""

from __future__ import annotations

from typing import Any


class GatewayError(Exception):
    """网关自定义异常基类。"""


class PromptError(GatewayError):
    """携带稳定错误码的业务异常，由 api 层转换为 HTTP 响应。"""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 400,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}

    def __str__(self) -> str:
        return self.message


class TemplateRenderError(GatewayError):
    """渲染失败的统一异常，携带稳定错误码。"""

    def __init__(self, code: str, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        return self.message
