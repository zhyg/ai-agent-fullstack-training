"""上游错误整理：统一成 OpenAI 风格的错误结构。"""

from __future__ import annotations

import json
from typing import Any

from error.messages import UPSTREAM_DEFAULT_ERROR, UPSTREAM_ERROR_TYPE


def extract_error(content: bytes, status_code: int) -> dict[str, Any]:
    try:
        payload = json.loads(content)
    except (json.JSONDecodeError, UnicodeDecodeError):
        payload = None
    if isinstance(payload, dict) and "error" in payload:
        return payload
    return {
        "error": {
            "message": content.decode("utf-8", "ignore")
            or UPSTREAM_DEFAULT_ERROR.format(status_code=status_code),
            "type": UPSTREAM_ERROR_TYPE,
            "code": status_code,
        }
    }
