"""错误层：统一异常层级、错误码、错误文案与 HTTP 错误工厂。

目录组织：
- base.py     异常基类（GatewayError / PromptError / TemplateRenderError）
- adapter.py  适配器层异常
- provider.py 供应商/协议异常
- status.py   执行状态异常
- codes.py    错误码与重试分类集合
- messages.py 集中管理的错误提示文案
- upstream.py 上游错误体归一化
- http.py     OpenAI 风格 HTTP 错误工厂
"""

from error.adapter import (
    AdapterError,
    AdapterLifecycleError,
    AdapterNotRegisteredError,
    AdapterParamError,
)
from error.base import GatewayError, PromptError, TemplateRenderError
from error.codes import (
    AUTH_CODES,
    MODEL_CODES,
    OVER_BUDGET_CODES,
    PROMPT_MISSING_CODES,
    TRANSIENT_CODES,
    ErrorCode,
    matches,
)
from error.http import error_payload, http_error, prompt_http_error, response_http_error
from error.provider import UnknownProtocolError
from error.status import InvalidExecutionStatusError
from error.upstream import extract_error

__all__ = [
    "GatewayError",
    "PromptError",
    "TemplateRenderError",
    "AdapterError",
    "AdapterParamError",
    "AdapterNotRegisteredError",
    "AdapterLifecycleError",
    "UnknownProtocolError",
    "InvalidExecutionStatusError",
    "ErrorCode",
    "PROMPT_MISSING_CODES",
    "OVER_BUDGET_CODES",
    "AUTH_CODES",
    "MODEL_CODES",
    "TRANSIENT_CODES",
    "matches",
    "extract_error",
    "error_payload",
    "http_error",
    "prompt_http_error",
    "response_http_error",
]
