"""Prompt 编排：解析 → 变量校验 → 渲染 → System Prompt 注入 → 审计。"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Sequence

from pydantic import ValidationError

from config.loader import get_prompt_config
from error import messages as error_messages
from error.base import PromptError
from prompt.audit import PromptAudit, get_audit
from prompt.models import (
    ChangeEvent,
    OutputSpec,
    PromptInvocation,
    PromptTemplate,
    VariablesSchema,
    compute_content_sha256,
)
from prompt.renderer import render_text
from prompt.schema import check_variable_names, compile_schema, validate_variables
from prompt.store import PromptStore, get_store
from prompt.system import (
    SystemPromptConflict,
    apply_system,
    get_default_entry,
    resolve_system_content,
)
from templating import TemplateRenderError

MAX_TEMPLATE_BYTES = 262_144


def _max_template_bytes() -> int:
    try:
        value = (get_prompt_config().get("templating") or {}).get("max_template_bytes")
        return int(value) if value not in (None, "") else MAX_TEMPLATE_BYTES
    except (TypeError, ValueError):
        return MAX_TEMPLATE_BYTES


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _as_dict(message: Any) -> dict[str, Any]:
    if hasattr(message, "model_dump"):
        return message.model_dump(exclude_none=True)
    return dict(message)


def _template_size(template: PromptTemplate) -> int:
    total = (template.system or "") + (template.user_template or "")
    return len(total.encode("utf-8"))


def _render(source: str, variables: dict[str, Any]) -> str:
    try:
        return render_text(source, variables)
    except TemplateRenderError as exc:
        raise PromptError(exc.code, exc.message, 400, exc.details) from exc


@dataclass
class PreparedPrompt:
    messages: list[dict[str, Any]]
    output: OutputSpec
    template_id: str
    version: int
    variables: dict[str, Any] = field(default_factory=dict)
    ignored_variables: list[str] = field(default_factory=list)
    template_system: str | None = None
    template_user: str | None = None
    content_sha256: str | None = None

    @property
    def meta(self) -> dict[str, Any]:
        return {
            "template_id": self.template_id,
            "version": self.version,
            "output_mode": self.output.mode.value,
        }


class PromptService:
    def __init__(
        self,
        store: PromptStore | None = None,
        audit: PromptAudit | None = None,
    ) -> None:
        self.store = store or get_store()
        self.audit = audit or get_audit()

    # --------------------------------------------------------------- invocation

    async def prepare(self, invocation: PromptInvocation, messages: Sequence[Any]) -> PreparedPrompt:
        template = await asyncio.to_thread(self.store.get, invocation.id, invocation.version)
        if not template.enabled:
            raise PromptError(
                "prompt_not_found",
                error_messages.PROMPT_DISABLED.format(template_id=invocation.id),
                404,
            )

        variables = validate_variables(
            template.variables_schema,
            invocation.variables,
            strict=_strict_variables(),
        )
        ignored = sorted(set(invocation.variables) - set(template.variables_schema.variables))

        prepared_messages = [_as_dict(message) for message in messages]

        if template.user_template:
            rendered_user = _render(template.user_template, variables)
            index = _last_user_index(prepared_messages)
            if index is None:
                raise PromptError(
                    "prompt_user_message_missing",
                    error_messages.PROMPT_USER_MESSAGE_MISSING,
                    400,
                )
            prepared_messages[index] = {**prepared_messages[index], "content": rendered_user}

        explicit_system = invocation.system.content if invocation.system else None
        system_content = resolve_system_content(explicit_system, template.system)
        if system_content is not None:
            system_content = _render(system_content, variables)

        if invocation.system is not None:
            on_conflict = invocation.system.on_conflict
        elif template.system is None:
            default_entry = get_default_entry()
            on_conflict = default_entry.on_conflict if default_entry else SystemPromptConflict.REPLACE
        else:
            on_conflict = SystemPromptConflict.REPLACE

        prepared_messages = apply_system(prepared_messages, system_content, on_conflict)
        output = invocation.output or template.output

        return PreparedPrompt(
            messages=prepared_messages,
            output=output,
            template_id=template.id,
            version=template.version,
            variables=variables,
            ignored_variables=ignored,
            template_system=template.system,
            template_user=template.user_template,
            content_sha256=template.content_sha256,
        )

    def record_usage(
        self,
        prepared: PreparedPrompt,
        *,
        request_id: str,
        model: str | None,
        provider: str | None,
        status: str,
        error_code: str | None = None,
        latency_ms: int | None = None,
        session_id: str | None = None,
    ) -> None:
        self.audit.record_usage(
            request_id=request_id,
            template_id=prepared.template_id,
            version=prepared.version,
            model=model,
            provider=provider,
            output_mode=prepared.output.mode.value,
            variables=prepared.variables,
            status=status,
            error_code=error_code,
            latency_ms=latency_ms,
            session_id=session_id,
            ignored_variables=prepared.ignored_variables,
        )

    # --------------------------------------------------------------- management

    async def upsert_template(
        self,
        template_id: str,
        *,
        expected_version: int | None,
        description: str | None = None,
        tags: list[str] | None = None,
        system: str | None = None,
        user_template: str | None = None,
        variables_schema: VariablesSchema | dict[str, Any] | None = None,
        output: OutputSpec | dict[str, Any] | None = None,
        enabled: bool = True,
        actor: str | None = None,
    ) -> PromptTemplate:
        current_version = self.store.current_version(template_id)
        if expected_version is None:
            if current_version is not None:
                raise PromptError(
                    "prompt_version_conflict",
                    error_messages.PROMPT_ALREADY_EXISTS.format(template_id=template_id),
                    409,
                )
            version = 1
        else:
            if current_version is None:
                raise PromptError(
                    "prompt_not_found",
                    error_messages.PROMPT_NOT_FOUND.format(template_id=template_id),
                    404,
                )
            if current_version != expected_version:
                raise PromptError(
                    "prompt_version_conflict",
                    error_messages.PROMPT_VERSION_CONFLICT.format(
                        template_id=template_id, current_version=current_version
                    ),
                    409,
                    {"current_version": current_version},
                )
            version = current_version + 1

        schema = _parse_model(VariablesSchema, variables_schema)
        output_spec = _parse_model(OutputSpec, output)

        for source in (system, user_template):
            if source:
                check_variable_names(source, schema)
        compile_schema(schema)

        previous = self.store.get(template_id, current_version) if current_version else None
        now = _now()
        template = PromptTemplate(
            id=template_id,
            version=version,
            description=description,
            tags=tags or [],
            system=system,
            user_template=user_template,
            variables_schema=schema,
            output=output_spec,
            enabled=enabled,
            created_at=previous.created_at if previous else now,
            updated_at=now,
        )
        limit = _max_template_bytes()
        if _template_size(template) > limit:
            raise PromptError(
                "prompt_invalid",
                error_messages.PROMPT_TOO_LARGE.format(max_bytes=limit),
                400,
            )

        template = template.model_copy(update={"content_sha256": compute_content_sha256(template)})
        event = ChangeEvent(
            ts=now,
            event="create" if current_version is None else "update",
            template_id=template_id,
            version=version,
            content_sha256=template.content_sha256,
            actor=actor,
            template=template,
        )
        await asyncio.to_thread(self.store.append_change, event)
        return template

    async def set_enabled(
        self,
        template_id: str,
        enabled: bool,
        *,
        actor: str | None = None,
    ) -> PromptTemplate:
        current = self.store.get(template_id)
        event = ChangeEvent(
            ts=_now(),
            event="enable" if enabled else "disable",
            template_id=template_id,
            version=current.version,
            actor=actor,
        )
        await asyncio.to_thread(self.store.append_change, event)
        return self.store.get(template_id)

    async def delete_template(self, template_id: str, *, actor: str | None = None) -> None:
        current = self.store.get(template_id)
        event = ChangeEvent(
            ts=_now(),
            event="delete",
            template_id=template_id,
            version=current.version,
            actor=actor,
        )
        await asyncio.to_thread(self.store.append_change, event)

    def preview(
        self,
        template_id: str,
        variables: dict[str, Any],
        *,
        version: int | None = None,
    ) -> dict[str, str | None]:
        template = self.store.get(template_id, version)
        values = validate_variables(template.variables_schema, variables, strict=_strict_variables())
        return {
            "system": _render(template.system, values) if template.system else None,
            "user": _render(template.user_template, values) if template.user_template else None,
        }


def _last_user_index(messages: list[dict[str, Any]]) -> int | None:
    for index in range(len(messages) - 1, -1, -1):
        if messages[index].get("role") == "user":
            return index
    return None


def _strict_variables() -> bool | None:
    raw = str(get_prompt_config().get("strict_variables") or "").strip()
    if not raw:
        return None
    return raw.lower() in {"1", "true", "yes"}


def _parse_model(model: type, payload: Any) -> Any:
    if payload is None:
        return model()
    if isinstance(payload, model):
        return payload
    try:
        return model.model_validate(payload)
    except ValidationError as exc:
        raise PromptError(
            "prompt_invalid",
            error_messages.PROMPT_DEFINITION_INVALID,
            400,
            {"errors": exc.errors(include_url=False)},
        ) from exc


_service: PromptService | None = None


def get_service() -> PromptService:
    global _service
    if _service is None:
        _service = PromptService()
    return _service


def reset_service() -> None:
    global _service
    _service = None
