"""模型输出校验与 response_format 构造。"""

from __future__ import annotations

import json
from typing import Any

from pydantic import ValidationError

from error import messages
from error.base import PromptError
from prompt.models import OutputMode, OutputSpec, VariableSpec, VariableType, VariablesSchema
from prompt.schema import compile_schema


def _spec_to_json_schema(spec: VariableSpec) -> dict[str, Any]:
    node: dict[str, Any] = {"type": spec.type.value}
    if spec.description:
        node["description"] = spec.description
    if spec.enum:
        node["enum"] = spec.enum
    if spec.type is VariableType.STRING:
        if spec.min_length is not None:
            node["minLength"] = spec.min_length
        if spec.max_length is not None:
            node["maxLength"] = spec.max_length
        if spec.pattern is not None:
            node["pattern"] = spec.pattern
    if spec.type in {VariableType.INTEGER, VariableType.NUMBER}:
        if spec.minimum is not None:
            node["minimum"] = spec.minimum
        if spec.maximum is not None:
            node["maximum"] = spec.maximum
    if spec.type is VariableType.OBJECT and spec.properties:
        node["properties"] = {name: _spec_to_json_schema(child) for name, child in spec.properties.items()}
        node["required"] = [name for name, child in spec.properties.items() if child.required]
        node["additionalProperties"] = spec.additional_properties
    if spec.type is VariableType.ARRAY and spec.items is not None:
        node["items"] = _spec_to_json_schema(spec.items)
    return node


def to_json_schema(schema: VariablesSchema) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {name: _spec_to_json_schema(spec) for name, spec in schema.variables.items()},
        "required": [name for name, spec in schema.variables.items() if spec.required],
        "additionalProperties": not schema.strict,
    }


def _provider_degraded(provider: Any, output: OutputSpec) -> bool:
    if provider is None or output.mode is not OutputMode.STRUCTURED:
        return False
    declared = (getattr(provider, "capabilities", None) or {}).get("response_format") or []
    if not declared:
        return False
    return "json_schema" not in declared


def build_response_format(output: OutputSpec, provider: Any | None = None) -> tuple[dict[str, Any] | None, bool]:
    """返回 (response_format, degraded)。"""

    if output.mode is OutputMode.TEXT:
        return None, False
    if output.mode is OutputMode.JSON:
        return {"type": "json_object"}, False

    if _provider_degraded(provider, output):
        return {"type": "json_object"}, True

    assert output.schema_def is not None
    return (
        {
            "type": "json_schema",
            "json_schema": {
                "name": output.schema_name or "structured_output",
                "schema": to_json_schema(output.schema_def),
                "strict": output.strict,
            },
        },
        False,
    )


def validate_output(output: OutputSpec, content: str | None) -> tuple[Any, bool]:
    """校验模型输出；失败抛出 PromptError(502 structured_output_invalid)。"""

    text = content or ""
    if output.max_chars is not None and len(text) > output.max_chars:
        raise PromptError(
            "structured_output_invalid",
            messages.OUTPUT_MAX_CHARS,
            502,
            {"reason": "max_chars", "length": len(text)},
        )
    if output.mode is OutputMode.TEXT:
        return None, False

    if not text.strip() and not output.allow_empty:
        raise PromptError(
            "structured_output_invalid", messages.OUTPUT_EMPTY, 502, {"reason": "empty"}
        )

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise PromptError(
            "structured_output_invalid",
            messages.OUTPUT_INVALID_JSON,
            502,
            {"reason": "invalid_json", "detail": str(exc)},
        ) from exc

    if output.mode is OutputMode.JSON:
        if not isinstance(parsed, dict):
            raise PromptError(
                "structured_output_invalid",
                messages.OUTPUT_NOT_OBJECT,
                502,
                {"reason": "not_object"},
            )
        return parsed, False

    assert output.schema_def is not None
    model = compile_schema(output.schema_def)
    try:
        validated = model.model_validate(parsed)
    except ValidationError as exc:
        raise PromptError(
            "structured_output_invalid",
            messages.OUTPUT_SCHEMA_MISMATCH,
            502,
            {"errors": exc.errors(include_url=False)},
        ) from exc
    return validated.model_dump(), False
