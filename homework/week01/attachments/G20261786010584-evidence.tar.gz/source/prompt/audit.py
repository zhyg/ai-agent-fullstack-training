"""模板使用记录：有界异步队列 + txt 追加写 + 脱敏。"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from config.loader import get_prompt_config
from gateway.status import normalize_status
from prompt.store import store_directory

logger = logging.getLogger(__name__)

MAX_FIELD_CHARS = 4_096
MAX_LINE_CHARS = 16_384
DEFAULT_QUEUE_SIZE = 1024
DEFAULT_MAX_BYTES = 10_485_760
DEFAULT_RETENTION_DAYS = 30
DEFAULT_REDACT = "api_key,token,password,secret,authorization"


def _audit_config() -> dict[str, Any]:
    return get_prompt_config().get("audit") or {}


def _config_int(key: str, default: int) -> int:
    try:
        value = _audit_config().get(key)
        return int(value) if value not in (None, "") else default
    except (TypeError, ValueError):
        return default


def _max_field_chars() -> int:
    return _config_int("max_field_chars", MAX_FIELD_CHARS)


def _max_line_chars() -> int:
    return _config_int("max_line_chars", MAX_LINE_CHARS)


def _redact_keys() -> set[str]:
    raw = _audit_config().get("redact_keys") or DEFAULT_REDACT
    return {item.strip().lower() for item in str(raw).split(",") if item.strip()}


def sanitize(values: Any, keys: set[str] | None = None, depth: int = 0) -> Any:
    """递归脱敏与截断，保证单行体积可控。"""

    keys = keys or _redact_keys()
    limit = _max_field_chars()
    if depth > 6:
        return "<depth-limit>"
    if isinstance(values, dict):
        return {
            str(name): ("***" if str(name).lower() in keys else sanitize(value, keys, depth + 1))
            for name, value in values.items()
        }
    if isinstance(values, list):
        return [sanitize(item, keys, depth + 1) for item in values]
    if isinstance(values, str) and len(values) > limit:
        return values[:limit] + "...<truncated>"
    return values


class PromptAudit:
    def __init__(
        self,
        directory: Path | str | None = None,
        *,
        queue_size: int | None = None,
        max_bytes: int | None = None,
        retention_days: int | None = None,
    ) -> None:
        config = _audit_config()
        self.directory = Path(directory) if directory else Path(config.get("directory") or store_directory())
        self.max_bytes = max_bytes or _config_int("max_bytes", DEFAULT_MAX_BYTES)
        self.retention_days = (
            retention_days if retention_days is not None else _config_int("retention_days", DEFAULT_RETENTION_DAYS)
        )
        self.max_line_chars = _max_line_chars()
        size = queue_size or _config_int("queue_size", DEFAULT_QUEUE_SIZE)
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=max(1, size))
        self._task: asyncio.Task[None] | None = None
        self._write_lock = threading.Lock()

    # ---------------------------------------------------------------- lifecycle

    async def start(self) -> None:
        if self._task is not None:
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        self._cleanup()
        self._task = asyncio.create_task(self._run())

    async def stop(self, timeout: float = 5.0) -> None:
        if self._task is None:
            return
        try:
            await self.flush(timeout)
        except Exception:  # noqa: BLE001 - 关停阶段不抛出
            logger.warning("prompt audit flush failed during shutdown", exc_info=True)
        self._task.cancel()
        try:
            await self._task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        self._task = None

    def record(self, record: dict[str, Any]) -> None:
        """非阻塞入队；队列满时丢弃并告警，绝不抛出。"""

        try:
            self._queue.put_nowait(record)
        except asyncio.QueueFull:
            logger.warning("prompt audit queue full, record dropped")
        except Exception:  # noqa: BLE001 - 审计不得影响主流程
            logger.warning("prompt audit enqueue failed", exc_info=True)

    def record_usage(
        self,
        *,
        request_id: str,
        template_id: str,
        version: int,
        model: str | None,
        provider: str | None,
        output_mode: str,
        variables: dict[str, Any] | None,
        status: str,
        error_code: str | None = None,
        latency_ms: int | None = None,
        session_id: str | None = None,
        ignored_variables: list[str] | None = None,
    ) -> None:
        self.record(
            {
                "ts": _now(),
                "request_id": request_id,
                "session_id": session_id,
                "template_id": template_id,
                "version": version,
                "model": model,
                "provider": provider,
                "output_mode": output_mode,
                "variables_sha256": _digest(variables),
                "variables": sanitize(variables or {}),
                "status": normalize_status(status).value,
                "error_code": error_code,
                "latency_ms": latency_ms,
                "ignored_variables": ignored_variables or [],
            }
        )

    async def flush(self, timeout: float = 5.0) -> None:
        deadline = time.monotonic() + timeout
        while not self._queue.empty() and time.monotonic() < deadline:
            await asyncio.sleep(0.01)
        records: list[dict[str, Any]] = []
        while True:
            try:
                records.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        if records:
            await asyncio.to_thread(self._write_records, records)

    async def _run(self) -> None:
        while True:
            record = await self._queue.get()
            batch = [record]
            while len(batch) < 50:
                try:
                    batch.append(self._queue.get_nowait())
                except asyncio.QueueEmpty:
                    break
            try:
                await asyncio.to_thread(self._write_records, batch)
            except Exception:  # noqa: BLE001 - 写盘失败不终止后台任务
                logger.warning("prompt audit write failed", exc_info=True)

    # ------------------------------------------------------------------ writing

    def _write_records(self, records: list[dict[str, Any]]) -> None:
        lines = [self._serialize(record) for record in records]
        with self._write_lock:
            try:
                self.directory.mkdir(parents=True, exist_ok=True)
                self._rotate_if_needed()
                with (self.directory / "usages.txt").open("a", encoding="utf-8") as handle:
                    for line in lines:
                        handle.write(line + "\n")
            except OSError as exc:
                logger.warning("prompt audit write failed: %s", exc)

    def _serialize(self, record: dict[str, Any]) -> str:
        line = json.dumps(record, ensure_ascii=False)
        if len(line) > self.max_line_chars:
            record = {**record, "variables": "<truncated>", "truncated": True}
            line = json.dumps(record, ensure_ascii=False)
        return line

    def _rotate_if_needed(self) -> None:
        current = self.directory / "usages.txt"
        if not current.is_file() or current.stat().st_size < self.max_bytes:
            return
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = self.directory / f"usages-{stamp}.txt"
        suffix = 1
        while target.exists():
            target = self.directory / f"usages-{stamp}-{suffix}.txt"
            suffix += 1
        current.rename(target)

    def _cleanup(self) -> None:
        if not self.directory.is_dir():
            return
        threshold = datetime.now() - timedelta(days=self.retention_days)
        for path in self.directory.glob("usages-*.txt"):
            try:
                if datetime.fromtimestamp(path.stat().st_mtime) < threshold:
                    path.unlink()
            except OSError as exc:
                logger.warning("prompt audit cleanup failed for %s: %s", path, exc)

    # -------------------------------------------------------------------- query

    def query(
        self,
        *,
        template_id: str | None = None,
        status: str | None = None,
        session_id: str | None = None,
        since: str | None = None,
        until: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        if not self.directory.is_dir():
            return []
        records: list[dict[str, Any]] = []
        for path in sorted(self.directory.glob("usages*.txt"), key=lambda item: item.name):
            try:
                for line in path.read_text(encoding="utf-8").splitlines():
                    if not line.strip():
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if template_id and record.get("template_id") != template_id:
                        continue
                    if status and record.get("status") != status:
                        continue
                    if session_id and record.get("session_id") != session_id:
                        continue
                    timestamp = record.get("ts") or ""
                    if since and timestamp < since:
                        continue
                    if until and timestamp > until:
                        continue
                    records.append(record)
            except OSError as exc:
                logger.warning("prompt audit query failed for %s: %s", path, exc)
        return records[-limit:] if limit > 0 else records


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _digest(values: dict[str, Any] | None) -> str | None:
    if values is None:
        return None
    import hashlib

    canonical = json.dumps(values, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


_audit: PromptAudit | None = None
_audit_lock = threading.Lock()


def get_audit() -> PromptAudit:
    global _audit
    with _audit_lock:
        if _audit is None:
            _audit = PromptAudit()
        return _audit


def reset_audit() -> None:
    global _audit
    with _audit_lock:
        _audit = None
