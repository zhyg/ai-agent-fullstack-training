"""变量 Schema 编译与校验（基于 Pydantic 动态模型）。"""

from __future__ import annotations

import threading
from collections import OrderedDict
from typing import Annotated, Any, Optional

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, ValidationError, conint, confloat, create_model

from error import messages
from error.base import PromptError
from prompt.models import VariableSpec, VariableType, VariablesSchema
from templating import TemplateRenderError, extract_variable_names

MAX_DEPTH = 8
MAX_VARIABLES = 64
MAX_ARRAY_LENGTH = 100_000

_CACHE: "OrderedDict[str, type[BaseModel]]" = OrderedDict()
_CACHE_LOCK = threading.Lock()
_CACHE_SIZE = 128


def _enum_validator(allowed: list[Any]):
    def check(value: Any) -> Any:
        if value not in allowed:
            raise ValueError(f"value must be one of {allowed}")
        return value

    return AfterValidator(check)


def _annotation(spec: VariableSpec, depth: int) -> Any:
    if depth > MAX_DEPTH:
        raise PromptError(
            "prompt_variables_invalid",
            messages.PROMPT_SCHEMA_DEPTH.format(max_depth=MAX_DEPTH),
            400,
        )

    if spec.type is VariableType.STRING:
        metadata = [Field(
            min_length=spec.min_length,
            max_length=spec.max_length,
            pattern=spec.pattern,
        )]
        base: Any = Annotated[str, *metadata]
    elif spec.type is VariableType.INTEGER:
        base = conint(ge=spec.minimum, le=spec.maximum)
    elif spec.type is VariableType.NUMBER:
        base = confloat(ge=spec.minimum, le=spec.maximum)
    elif spec.type is VariableType.BOOLEAN:
        base = bool
    elif spec.type is VariableType.OBJECT:
        if spec.properties:
            fields: dict[str, Any] = {}
            for name, child in spec.properties.items():
                child_ann = _annotation(child, depth + 1)
                fields[name] = _field_definition(child, child_ann)
            config = ConfigDict(extra="allow" if spec.additional_properties else "forbid")
            base = create_model(f"Nested_{depth}_{abs(hash(tuple(spec.properties)))}", __config__=config, **fields)
        else:
            base = dict[str, Any]
    else:  # ARRAY
        item_spec = spec.items or VariableSpec(type=VariableType.STRING)
        base = list[_annotation(item_spec, depth + 1)]

    if spec.enum:
        base = Annotated[base, _enum_validator(spec.enum)]
    return base


def _field_definition(spec: VariableSpec, annotation: Any) -> tuple[Any, Any]:
    if spec.required:
        return annotation, ...
    if spec.default is not None:
        return annotation, spec.default
    return Optional[annotation], None


def _cache_key(schema: VariablesSchema) -> str:
    return schema.model_dump_json()


def compile_schema(schema: VariablesSchema) -> type[BaseModel]:
    """把 VariablesSchema 编译为 Pydantic 模型（带 LRU 缓存）。"""

    if len(schema.variables) > MAX_VARIABLES:
        raise PromptError(
            "prompt_variables_invalid",
            messages.PROMPT_VARIABLES_EXCEED.format(max_variables=MAX_VARIABLES),
            400,
        )

    key = _cache_key(schema)
    with _CACHE_LOCK:
        cached = _CACHE.get(key)
        if cached is not None:
            _CACHE.move_to_end(key)
            return cached

    fields: dict[str, Any] = {}
    for name, spec in schema.variables.items():
        fields[name] = _field_definition(spec, _annotation(spec, 0))
    model = create_model("PromptVariables", __config__=ConfigDict(extra="forbid"), **fields)

    with _CACHE_LOCK:
        _CACHE[key] = model
        while len(_CACHE) > _CACHE_SIZE:
            _CACHE.popitem(last=False)
    return model


def validate_variables(
    schema: VariablesSchema,
    variables: dict[str, Any],
    *,
    strict: bool | None = None,
) -> dict[str, Any]:
    """校验输入变量并回填默认值；失败抛出 PromptError(422)。"""

    strict_mode = schema.strict if strict is None else strict
    unknown = sorted(set(variables) - set(schema.variables))
    if unknown and strict_mode:
        raise PromptError(
            "prompt_variable_unknown",
            messages.PROMPT_UNKNOWN_VARIABLES,
            422,
            {"unknown": unknown},
        )

    data = {name: value for name, value in variables.items() if name in schema.variables}
    model = compile_schema(schema)
    try:
        parsed = model.model_validate(data)
    except ValidationError as exc:
        errors = exc.errors(include_url=False)
        code = (
            "prompt_variable_missing"
            if any(item["type"] == "missing" for item in errors)
            else "prompt_variables_invalid"
        )
        raise PromptError(code, messages.PROMPT_VARIABLES_INVALID, 422, {"errors": errors}) from exc
    return parsed.model_dump()


def check_variable_names(source: str, schema: VariablesSchema) -> set[str]:
    """校验模板引用的变量名必须已在 Schema 中声明。"""

    try:
        names = extract_variable_names(source)
    except TemplateRenderError as exc:
        raise PromptError(exc.code, exc.message, 400, exc.details) from exc

    undeclared = sorted(name for name in names if name not in schema.variables)
    if undeclared:
        raise PromptError(
            "prompt_placeholder_undeclared",
            messages.PROMPT_UNDECLARED_VARIABLES,
            400,
            {"undeclared": undeclared},
        )
    return names


def clear_cache() -> None:
    with _CACHE_LOCK:
        _CACHE.clear()
