"""Prompt 子系统契约模型。"""

from __future__ import annotations

import hashlib
import json
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class OutputMode(StrEnum):
    TEXT = "text"
    JSON = "json"
    STRUCTURED = "structured"


class SystemPromptConflict(StrEnum):
    REPLACE = "replace"
    PREPEND = "prepend"
    APPEND = "append"


class VariableType(StrEnum):
    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    OBJECT = "object"
    ARRAY = "array"


class VariableSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: VariableType
    required: bool = False
    default: Any = None
    description: str | None = Field(default=None, max_length=512)
    enum: list[Any] | None = None
    pattern: str | None = None
    min_length: int | None = Field(default=None, ge=0)
    max_length: int | None = Field(default=None, ge=0)
    minimum: float | None = None
    maximum: float | None = None
    items: "VariableSpec | None" = None
    properties: dict[str, "VariableSpec"] | None = None
    additional_properties: bool = False

    @model_validator(mode="after")
    def _check(self) -> "VariableSpec":
        if self.type is VariableType.ARRAY and self.items is None:
            raise ValueError("array variable requires items")
        if self.type is not VariableType.ARRAY and self.items is not None:
            raise ValueError("items is only allowed for array variables")
        if self.type is not VariableType.OBJECT and self.properties is not None:
            raise ValueError("properties is only allowed for object variables")
        if self.type is not VariableType.STRING:
            if self.pattern is not None or self.min_length is not None or self.max_length is not None:
                raise ValueError("string constraints are only allowed for string variables")
        if self.minimum is not None and self.maximum is not None and self.minimum > self.maximum:
            raise ValueError("minimum must be <= maximum")
        return self


class VariablesSchema(BaseModel):
    model_config = ConfigDict(extra="forbid")

    strict: bool = True
    variables: dict[str, VariableSpec] = Field(default_factory=dict)


class OutputSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mode: OutputMode = OutputMode.TEXT
    schema_name: str | None = Field(default=None, pattern=r"^[A-Za-z0-9_-]{1,64}$")
    schema_def: VariablesSchema | None = None
    strict: bool = True
    allow_empty: bool = False
    max_chars: int | None = Field(default=None, ge=1, le=1_048_576)

    @model_validator(mode="after")
    def _check(self) -> "OutputSpec":
        if self.mode is OutputMode.JSON and not self.schema_name:
            self.schema_name = "json_object"
        if self.mode is OutputMode.STRUCTURED and self.schema_def is None:
            raise ValueError("structured output requires schema_def")
        if self.mode is not OutputMode.STRUCTURED and self.schema_def is not None:
            raise ValueError("schema_def is only allowed in structured mode")
        return self


class PromptTemplate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(pattern=r"^[A-Za-z0-9._-]{1,64}$")
    version: int = Field(ge=1)
    description: str | None = Field(default=None, max_length=1024)
    tags: list[str] = Field(default_factory=list)
    system: str | None = Field(default=None, max_length=262_144)
    user_template: str | None = Field(default=None, max_length=262_144)
    variables_schema: VariablesSchema = Field(default_factory=VariablesSchema)
    output: OutputSpec = Field(default_factory=OutputSpec)
    enabled: bool = True
    created_at: str | None = None
    updated_at: str | None = None
    content_sha256: str | None = None


class SystemPromptOverride(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=262_144)
    on_conflict: SystemPromptConflict = SystemPromptConflict.REPLACE


class PromptInvocation(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(pattern=r"^[A-Za-z0-9._-]{1,64}$")
    version: int | None = Field(default=None, ge=1)
    variables: dict[str, Any] = Field(default_factory=dict)
    system: SystemPromptOverride | None = None
    output: OutputSpec | None = None


ChangeEventType = Literal["create", "update", "enable", "disable", "delete"]


class ChangeEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ts: str
    event: ChangeEventType
    template_id: str
    version: int
    content_sha256: str | None = None
    actor: str | None = None
    template: PromptTemplate | None = None


def compute_content_sha256(template: PromptTemplate) -> str:
    payload = {
        "id": template.id,
        "version": template.version,
        "system": template.system,
        "user_template": template.user_template,
        "variables_schema": template.variables_schema.model_dump(exclude_none=True),
        "output": template.output.model_dump(exclude_none=True),
    }
    canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


VariableSpec.model_rebuild()
PromptTemplate.model_rebuild()
