"""Prompt 渲染封装：唯一渲染入口是 templating.jinja。"""

from __future__ import annotations

from typing import Any

from templating import TemplateRenderError, render as render_template


def render_text(source: str, variables: dict[str, Any]) -> str:
    return render_template(source, variables)
