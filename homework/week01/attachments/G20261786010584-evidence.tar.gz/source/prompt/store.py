"""模板库持久化：事件溯源 + txt 追加写。"""

from __future__ import annotations

import json
import logging
import threading
from pathlib import Path

from config.loader import get_prompt_config
from error import messages
from error.base import PromptError
from prompt.models import ChangeEvent, PromptTemplate

logger = logging.getLogger(__name__)

DEFAULT_MAX_BYTES = 10_485_760


def store_directory() -> Path:
    config = get_prompt_config().get("store") or {}
    return Path(config.get("directory") or "data/prompt")


def store_max_bytes() -> int:
    config = get_prompt_config().get("store") or {}
    try:
        return int(config.get("max_bytes") or DEFAULT_MAX_BYTES)
    except (TypeError, ValueError):
        return DEFAULT_MAX_BYTES


class PromptStore:
    """只追加的模板事件存储；启动时重放生成内存快照。"""

    def __init__(self, directory: Path | str | None = None, *, max_bytes: int | None = None) -> None:
        self.directory = Path(directory) if directory else store_directory()
        self.max_bytes = max_bytes or store_max_bytes()
        self._lock = threading.RLock()
        self._latest: dict[str, PromptTemplate] = {}
        self._versions: dict[str, dict[int, PromptTemplate]] = {}
        self._loaded = False

    # ------------------------------------------------------------------ load

    def load(self) -> None:
        with self._lock:
            self._ensure_loaded()

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self._replay()
            self._loaded = True

    def _files(self, prefix: str) -> list[Path]:
        if not self.directory.is_dir():
            return []
        return sorted(self.directory.glob(f"{prefix}*.txt"), key=lambda path: path.name)

    def _replay(self) -> None:
        self._latest.clear()
        self._versions.clear()
        for path in self._files("templates"):
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except OSError as exc:
                logger.warning("prompt store file unreadable: %s (%s)", path, exc)
                continue
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = ChangeEvent.model_validate(json.loads(line))
                except (json.JSONDecodeError, ValueError) as exc:
                    logger.warning("skip malformed template event in %s: %s", path.name, exc)
                    continue
                self._apply(event)

    def _apply(self, event: ChangeEvent) -> None:
        template_id = event.template_id
        if event.event in {"create", "update"}:
            if event.template is None:
                return
            self._versions.setdefault(template_id, {})[event.template.version] = event.template
            self._latest[template_id] = event.template
            return

        if event.event in {"enable", "disable"}:
            current = self._latest.get(template_id)
            if current is not None:
                self._latest[template_id] = current.model_copy(update={"enabled": event.event == "enable"})
            return

        if event.event == "delete":
            self._latest.pop(template_id, None)

    # ------------------------------------------------------------------ read

    def list(self) -> list[PromptTemplate]:
        with self._lock:
            self._ensure_loaded()
            return [template.model_copy(deep=True) for template in self._latest.values()]

    def get(self, template_id: str, version: int | None = None) -> PromptTemplate:
        with self._lock:
            self._ensure_loaded()
            if version is not None:
                template = self._versions.get(template_id, {}).get(version)
                if template is None:
                    raise PromptError(
                        "prompt_version_not_found",
                        messages.PROMPT_VERSION_NOT_FOUND.format(template_id=template_id, version=version),
                        404,
                    )
                return template.model_copy(deep=True)
            template = self._latest.get(template_id)
            if template is None:
                raise PromptError(
                    "prompt_not_found",
                    messages.PROMPT_NOT_FOUND.format(template_id=template_id),
                    404,
                )
            return template.model_copy(deep=True)

    def current_version(self, template_id: str) -> int | None:
        with self._lock:
            self._ensure_loaded()
            template = self._latest.get(template_id)
            return template.version if template else None

    # ----------------------------------------------------------------- write

    def append_change(self, event: ChangeEvent) -> PromptTemplate | None:
        line = event.model_dump_json(exclude_none=True)
        with self._lock:
            self._ensure_loaded()
            try:
                self._rotate_if_needed()
                self.directory.mkdir(parents=True, exist_ok=True)
                with (self.directory / "templates.txt").open("a", encoding="utf-8") as handle:
                    handle.write(line + "\n")
            except OSError as exc:
                raise PromptError(
                    "prompt_store_unavailable",
                    messages.PROMPT_STORE_UNAVAILABLE.format(error=exc),
                    503,
                ) from exc
            self._apply(event)
        return event.template

    def _rotate_if_needed(self) -> None:
        current = self.directory / "templates.txt"
        if not current.is_file():
            return
        try:
            if current.stat().st_size < self.max_bytes:
                return
            from datetime import datetime

            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            target = self.directory / f"templates-{stamp}.txt"
            suffix = 1
            while target.exists():
                target = self.directory / f"templates-{stamp}-{suffix}.txt"
                suffix += 1
            current.rename(target)
        except OSError as exc:
            logger.warning("prompt store rotation skipped: %s", exc)


_store: PromptStore | None = None
_store_lock = threading.Lock()


def get_store() -> PromptStore:
    global _store
    with _store_lock:
        if _store is None:
            _store = PromptStore()
            _store.load()
        return _store


def reset_store() -> None:
    global _store
    with _store_lock:
        _store = None
