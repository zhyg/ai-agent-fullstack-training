"""System Prompt 配置：加载、优先级合并与冲突策略。"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field

from config.loader import get_prompt_config, project_root
from prompt.models import SystemPromptConflict

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")
_SYSTEM_ROLES = {"system", "developer"}


class SystemPromptEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=262_144)
    on_conflict: SystemPromptConflict = SystemPromptConflict.REPLACE


class SystemPromptConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    default_key: str = "default"
    system_prompts: dict[str, SystemPromptEntry] = Field(default_factory=dict)


def _expand(value: str) -> str:
    def replace(match: re.Match[str]) -> str:
        name, default = match.group(1), match.group(2) or ""
        return os.getenv(name, default)

    return _ENV_PATTERN.sub(replace, value)


def config_path() -> Path:
    """System Prompt 配置文件路径；相对路径基于项目根目录解析。"""

    config = get_prompt_config().get("system") or {}
    raw = str(config.get("config_path") or "config/system_prompts.yaml")
    path = Path(raw)
    return path if path.is_absolute() else project_root() / path


def load_config(path: Path | None = None) -> SystemPromptConfig:
    target = path or config_path()
    if not target.is_file():
        return SystemPromptConfig()
    raw: dict[str, Any] = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    if isinstance(raw.get("system_prompts"), dict):
        for entry in raw["system_prompts"].values():
            if isinstance(entry, dict) and isinstance(entry.get("content"), str):
                entry["content"] = _expand(entry["content"])
    return SystemPromptConfig.model_validate(raw)


def get_default_entry(config: SystemPromptConfig | None = None) -> SystemPromptEntry | None:
    cfg = config or load_config()
    key = str((get_prompt_config().get("system") or {}).get("key") or cfg.default_key)
    return cfg.system_prompts.get(key)


def apply_system(messages: list[dict[str, Any]], content: str | None, on_conflict: SystemPromptConflict) -> list[dict[str, Any]]:
    """按冲突策略把 System Prompt 合并进消息列表。"""

    result = [dict(message) for message in messages]
    if content is None:
        return result

    existing = [index for index, message in enumerate(result) if message.get("role") in _SYSTEM_ROLES]
    system_message = {"role": "system", "content": content}

    if on_conflict is SystemPromptConflict.REPLACE:
        result = [message for message in result if message.get("role") not in _SYSTEM_ROLES]
        return [system_message, *result]

    if on_conflict is SystemPromptConflict.PREPEND:
        return [system_message, *result]

    # APPEND：合并到已有 system 消息末尾；无 system 时退化为插入首条
    if not existing:
        return [system_message, *result]
    index = existing[-1]
    previous = result[index].get("content")
    if isinstance(previous, str):
        result[index] = {**result[index], "content": f"{previous}\n\n{content}"}
    else:
        result.insert(index + 1, system_message)
    return result


def resolve_system_content(explicit: str | None, template_content: str | None) -> str | None:
    """优先级：请求级 > 模板级 > 全局默认。"""

    if explicit is not None:
        return explicit
    if template_content is not None:
        return template_content
    default = get_default_entry()
    return default.content if default is not None else None
