"""Analyze persisted public records against independent upstream stimulus."""
import json
from pathlib import Path

ROOT = Path(__file__).parent
BASE = ROOT.parent
tests = json.loads((ROOT / "teacher-results.json").read_text())
metrics = [json.loads(x) for x in (BASE / "data/metrics/metrics.txt").read_text().splitlines()]
traces = json.loads((ROOT / "trace-query.json").read_text())["data"]
spans = [json.loads(x) for x in (BASE / "data/traces/traces.txt").read_text().splitlines()]
checks = []
for model in ["teacher-chat", "teacher-messages"]:
    rid = "F01-"+model+"-gate"
    received = next(x["actual"]["first_content_ms"] for x in tests if x["case"] == rid)
    metric = next(x for x in metrics if x["request_id"] == rid)
    checks.append({"case": "F07-TTFT-"+model, "expected": "first nonempty text >=250ms after empty role event", "actual": {"downstream_content_ms": received, "metric_ttft_ms": metric["ttft_ms"]}, "status": "PASS" if metric["ttft_ms"] >= 240 else "FAIL"})
    rid = "F02-"+model+"-stream_error"
    trace = next(x for x in traces if x["request_id"] == rid)
    checks.append({"case": "F07-SSE-error-"+model, "expected": "failed ledger despite error SSE followed by EOF", "actual": trace, "status": "PASS" if trace["status"] == "failed" else "FAIL"})
    rid = "F02-"+model+"-disconnect"
    trace = next(x for x in traces if x["request_id"] == rid)
    checks.append({"case": "F07-transport-error-"+model, "expected": "failed ledger on premature Content-Length termination", "actual": trace, "status": "PASS" if trace["status"] == "failed" else "FAIL"})
    trace = next(x for x in traces if x["request_id"] == "A03-"+model)
    raw = next(x for x in spans if x.get("request_id") == "A03-"+model and x.get("span") == "upstream.complete")["outputs"]["body"]
    checks.append({"case": "F07-token-categories-"+model, "expected": "supplied cache=3 retained in any persisted record; chat reasoning=2 also supplied", "actual": {"ledger": {k:v for k,v in trace.items() if "token" in k}, "raw_response_span": raw}, "status": "PASS" if "cache" in raw and (model != "teacher-chat" or "reasoning_tokens" in raw) else "FAIL"})
trace = next(x for x in traces if x["request_id"] == "F08-F09-auth401")
checks.append({"case": "F07-HTTP-failure", "expected": "401 recorded and correlated", "actual": trace, "status": "PASS" if trace["status"] == "failed" else "FAIL"})
trace = next(x for x in traces if x["request_id"] == "F08-F09-retry")
checks.append({"case": "F07-total-latency", "expected": "request trace includes two 200ms waits", "actual": trace, "status": "PASS" if trace["duration_ms"] >= 400 else "FAIL"})
(ROOT / "observability-results.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2))
for x in checks:
    print(x["case"], x["status"])
