"""Teacher controlled upstream. Never saves request authentication headers."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).parent
state = {"mode": "normal", "calls": [], "gate": threading.Event()}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        self.reply(200, {"mode": state["mode"], "calls": state["calls"]})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        if self.path == "/control":
            state["mode"] = body["mode"]
            state["calls"] = []
            state["gate"].clear()
            return self.reply(200, {"ok": True})
        if self.path == "/release":
            state["gate"].set()
            return self.reply(200, {"ok": True})
        call = {"path": self.path, "body": body, "time": time.monotonic(),
                "auth_kind": "x-api-key" if self.headers.get("x-api-key") else "bearer"}
        state["calls"].append(call)
        with (ROOT / "upstream.jsonl").open("a") as out:
            out.write(json.dumps({"mode": state["mode"], **call}) + "\n")
        mode = state["mode"]
        anth = self.path.endswith("/messages")
        if body.get("model", "").startswith("does-not-exist"):
            return self.reply(404, {"error": {"code": "model_not_found", "message": "unknown model"}})
        if mode in {"retry", "always500", "bad400", "auth401"}:
            code = {"bad400": 400, "auth401": 401}.get(mode, 500)
            if mode != "retry" or len(state["calls"]) <= 2:
                error = {"type": "invalid_request_error" if code == 400 else "authentication_error" if code == 401 else "api_error", "code": "bad_input" if code == 400 else "auth" if code == 401 else "server_error", "message": "controlled upstream failure"}
                return self.reply(code, {"type": "error", "error": error})
        text = {"invalid": "not-json", "empty": "", "truncated": '{"value":', "wrongtype": '{"value":"wrong"}'}.get(mode, '{"value":7}')
        if body.get("stream"):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            if mode == "disconnect":
                self.send_header("Content-Length", "100000")
            self.end_headers()
            def send(obj):
                self.wfile.write(("data: " + (obj if isinstance(obj, str) else json.dumps(obj)) + "\n\n").encode())
                self.wfile.flush()
            if anth:
                send({"type": "message_start", "message": {"id": "msg-teacher", "usage": {"input_tokens": 11, "output_tokens": 0}}})
            else:
                send({"id": "chat-teacher", "choices": [{"delta": {"role": "assistant", "content": ""}, "finish_reason": None}]})
            time.sleep(0.25)
            if anth:
                send({"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "FIRST"}})
            else:
                send({"choices": [{"delta": {"content": "FIRST"}, "finish_reason": None}]})
            if mode == "gate":
                state["gate"].wait(8)
            if mode == "eof":
                return
            if mode == "stream_error":
                send({"type": "error", "error": {"type": "api_error", "message": "controlled stream failure"}})
                return
            if mode == "disconnect":
                self.wfile.write(b"data: {\"partial\"")
                self.wfile.flush()
                return
            if anth:
                send({"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 5}})
                send({"type": "message_stop"})
            else:
                send({"choices": [{"delta": {}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 11, "completion_tokens": 5, "total_tokens": 16, "prompt_tokens_details": {"cached_tokens": 3}, "completion_tokens_details": {"reasoning_tokens": 2}}})
                send("[DONE]")
            return
        if anth:
            result = {"id": "msg-teacher", "model": body["model"], "content": [{"type": "text", "text": text}], "stop_reason": "max_tokens" if mode == "truncated" else "end_turn", "usage": {"input_tokens": 11, "output_tokens": 5, "cache_read_input_tokens": 3}}
        else:
            result = {"id": "chat-teacher", "model": body["model"], "choices": [{"message": {"role": "assistant", "content": text}, "finish_reason": "length" if mode == "truncated" else "stop"}], "usage": {"prompt_tokens": 11, "completion_tokens": 5, "total_tokens": 16, "prompt_cache_hit_tokens": 3, "completion_tokens_details": {"reasoning_tokens": 2}}}
        self.reply(200, result)


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", 18684), Handler).serve_forever()
