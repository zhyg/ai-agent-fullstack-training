#!/usr/bin/env bash
# Recorded evaluation commands; paths are the independent grading environment.
# Never export or echo the real key. real.yaml references existing environment.
set -eu
ROOT=/tmp/grading-G20261786010584
cd "$ROOT/source"
# This transcript applies to the original clone. The archive source/ is a git
# export without .git; source-metadata.txt and sha256-manifest.txt identify it.
if test -d .git; then
  test "$(git rev-parse HEAD)" = c3b86f5bc0cfcc79c33ca6a87a8ee6a90e108d9d
fi
# Reproduce in a fresh disposable directory. Move archived data/ and real-data/
# aside first: teacher-template must not already exist. Do not overwrite evidence.
uv venv "$ROOT/venv"
uv pip install --python "$ROOT/venv/bin/python" -r requirements-dev.txt
# Baseline startup fails: No module named uvicorn (startup.txt).
uv pip install --python "$ROOT/venv/bin/python" uvicorn
"$ROOT/venv/bin/python" -m pytest -q
amp orb service start grade-zzi-upstream --command "$ROOT/venv/bin/python $ROOT/evidence/mock_server.py" --port 18684
amp orb service start grade-zzi-gateway --command "env LLM_CONFIG_FILE=$ROOT/evidence/mock.yaml GATEWAY_RUNTIME_CONFIG=$ROOT/evidence/runtime.yaml PROMPT_STORE_DIR=$ROOT/data/prompts PROMPT_MANAGE_ENABLED=true $ROOT/venv/bin/python -m uvicorn main:app --host 127.0.0.1 --port 18685" --port 18685
until curl -fsS http://127.0.0.1:18685/health; do sleep 1; done
"$ROOT/venv/bin/python" "$ROOT/evidence/teacher_verify.py"
"$ROOT/venv/bin/python" "$ROOT/evidence/observability_verify.py"
# Expected exit 1; deliberately erase request conversion only in this test process.
PYTHONPATH="$ROOT/evidence:$PWD" "$ROOT/venv/bin/python" -m pytest -q -p injected_fail tests/provider/test_anthropic_protocol.py::test_format_request_extracts_system_and_maps_params || test "$?" = 1
amp orb service start grade-zzi-real --command "env LLM_CONFIG_FILE=$ROOT/evidence/real.yaml GATEWAY_RUNTIME_CONFIG=$ROOT/evidence/real-runtime.yaml PROMPT_STORE_DIR=$ROOT/real-data/prompts $ROOT/venv/bin/python -m uvicorn main:app --host 127.0.0.1 --port 18686" --port 18686
until curl -fsS http://127.0.0.1:18686/health; do sleep 1; done
"$ROOT/venv/bin/python" "$ROOT/evidence/real_verify.py"
amp orb service stop grade-zzi-real
amp orb service stop grade-zzi-gateway
amp orb service stop grade-zzi-upstream
