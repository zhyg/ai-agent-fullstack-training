"""Offline final checks. Never invokes models or prints credential values."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tarfile
import urllib.parse

BASE = Path('/tmp/grading-G20261786010584')
REPO = Path('/home/user/workspace/repo')
OUT = REPO / 'homework/week01'
PACKAGE = BASE / 'package'
ARCHIVE = OUT / 'attachments/G20261786010584-evidence.tar.gz'
feedback = (OUT / 'G20261786010584.md').read_text()
attachment = (OUT / 'attachments/G20261786010584.md').read_text()
checks = []


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append('PASS ' + label)


check('作业等级：良好（69分）' in feedback, 'feedback grade and score')
for number, next_number in [(2, 3), (3, 4), (4, None)]:
    section = feedback.split('**' + str(number) + '. ')[1]
    if next_number:
        section = section.split('**' + str(next_number) + '. ')[0]
    bullets = [line for line in section.splitlines() if line.startswith('- ')]
    check(3 <= len(bullets) <= 5, f'section {number} bullet count={len(bullets)}')
    chars = sum(len(line[2:]) for line in bullets)
    check(chars <= 500, f'section {number} content chars={chars} <=500')
    check('**\n\n- ' in '**' + str(number) + '. ' + section, f'section {number} heading spacing')

score_lines = attachment.split('## B. 八项评分')[1].split('## C.')[0]
scores = [(int(a), int(b)) for a, b in re.findall(r'^\| [^|]+ \| (\d+)/(\d+) \|', score_lines, re.M)]
check(len(scores) == 8, 'exactly eight score items')
check(sum(x[0] for x in scores) == 69 and sum(x[1] for x in scores) == 100, 'score sum=69/100')
deduction_section = attachment.split('## D.')[1].split('## E.')[0]
deductions = re.findall(r'\| -(\d+) \|$', deduction_section, re.M)
check(sum(map(int, deductions)) == 31, 'deductions sum=31, no duplicate case multiplication')
for section in 'ABCDEF':
    check('## ' + section + '.' in attachment, 'attachment section ' + section)
for case in ['A01','A02','A03','A04'] + [f'F{i:02}' for i in range(1,13)]:
    check('| ' + case + ' |' in attachment, 'acceptance coverage ' + case)

real = json.loads((BASE / 'evidence/real-results.json').read_text())
calls = [x for group in real for x in group]
check(len(calls) == 6 and all(x['http'] == 200 for x in calls), 'reuse six existing real HTTP 200 results')
check({x['upstream_model'] for x in calls} == {'deepseek-v4-pro','deepseek-v4-flash'}, 'two real models')
obs = {x['case']: x for x in json.loads((BASE / 'evidence/observability-results.json').read_text())}
check(obs['F07-token-categories-teacher-chat']['status'] == 'PASS', 'Chat raw span preserves cache and reasoning categories')
check(obs['F07-token-categories-teacher-messages']['status'] == 'FAIL', 'Messages loses supplied cache category')
for port in [18684,18685,18686]:
    try:
        connection = socket.create_connection(('127.0.0.1', port), timeout=1)
    except OSError:
        check(True, f'grade service port {port} stopped')
    else:
        connection.close()
        check(False, f'grade service port {port} still open')

head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=BASE/'source', text=True).strip()
check(head == 'c3b86f5bc0cfcc79c33ca6a87a8ee6a90e108d9d', 'fixed student commit')
check(not subprocess.check_output(['git','status','--porcelain'], cwd=BASE/'source'), 'student source worktree unchanged')
names = subprocess.check_output(['git','ls-files','-z'], cwd=BASE/'source').split(b'\0')
names = [x.decode() for x in names if x]
check(len(names) == 81, '81 fixed source files')
for name in names:
    blob = subprocess.check_output(['git','show',f'{head}:{name}'], cwd=BASE/'source')
    check((PACKAGE/'source'/name).read_bytes() == blob, 'snapshot blob ' + name)

key = os.environ.get('DEEPSEEK_API_KEY', '')
check(bool(key), 'actual credential available for exact-match scan (value not emitted)')
needles = {key.encode(), json.dumps(key)[1:-1].encode(), base64.b64encode(key.encode()), urllib.parse.quote(key, safe='').encode()}
for folder in [PACKAGE]:
    for path in folder.rglob('*'):
        if path.is_file():
            raw = path.read_bytes()
            check(not any(needle in raw for needle in needles), 'credential scan ' + str(path.relative_to(PACKAGE)))
for path in [OUT/'G20261786010584.md', OUT/'attachments/G20261786010584.md']:
    check(not any(needle in path.read_bytes() for needle in needles), 'credential scan report ' + path.name)

if ARCHIVE.exists():
    count = 0
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for member in archive:
            check(not member.name.startswith('/') and '..' not in Path(member.name).parts, 'safe archive member ' + member.name)
            if member.isfile():
                raw = archive.extractfile(member).read()
                check(not any(needle in raw for needle in needles), 'archive credential scan ' + member.name)
                check((PACKAGE/member.name).read_bytes() == raw, 'archive content matches package ' + member.name)
                count += 1
    checks.append(f'PASS archive members verified={count}; sha256=' + hashlib.sha256(ARCHIVE.read_bytes()).hexdigest())
print('\n'.join(checks))
print('FINAL PASS: 69/100; feedback format, source integrity, category distinction, secret scan, stopped services')
