"""HTTP acceptance probes; no student source modification, no real keys."""
import json
import time
from pathlib import Path
import httpx

ROOT = Path(__file__).parent
gw = httpx.Client(base_url="http://127.0.0.1:18685", timeout=15)
up = httpx.Client(base_url="http://127.0.0.1:18684", timeout=15)
results = []


def save(name, expected, actual, passed):
    record = {"case": name, "expected": expected, "actual": actual, "status": "PASS" if passed else "FAIL"}
    results.append(record)
    print(json.dumps(record, ensure_ascii=False), flush=True)
    (ROOT / "teacher-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))


def mode(value):
    up.post("/control", json={"mode": value}).raise_for_status()


def calls():
    return up.get("/state").json()["calls"]


def request(model="teacher-chat", **extra):
    return {"model": model, "messages": [{"role": "system", "content": "Return JSON object"}, {"role": "user", "content": "test"}], **extra}


def post(name, payload):
    payload = {**payload, "messages": [*payload["messages"], {"role": "user", "content": "probe-id=" + name}]}
    t = time.monotonic()
    r = gw.post("/v1/chat/completions", json=payload, headers={"X-Request-Id": name})
    return {"http": r.status_code, "body": r.json(), "elapsed_ms": round((time.monotonic()-t)*1000, 2), "request_id": r.headers.get("x-request-id")}


save("A01-health", "service starts after extra uvicorn install", gw.get("/health").json(), gw.get("/health").status_code == 200)
for model in ["teacher-chat", "teacher-messages"]:
    mode("normal")
    actual = post("A03-"+model, request(model))
    actual["upstream"] = calls()
    save("A03-"+model, "distinct wire protocol; response normalized", actual,
         actual["http"] == 200 and actual["body"]["choices"][0]["message"]["content"] == '{"value":7}')

mode("normal")
actual = post("A04-unknown", request("does-not-exist-984"))
actual["upstream"] = calls()
save("A04", "explicit unknown-model error, not default-provider success", actual, actual["http"] >= 400)

for model in ["teacher-chat", "teacher-messages"]:
    for testmode in ["gate", "eof", "stream_error", "disconnect"]:
        mode(testmode)
        name = ("F01-" if testmode == "gate" else "B05-" if testmode == "eof" else "F02-") + model + "-" + testmode
        t = time.monotonic()
        chunks = []
        released = False
        error = None
        first_content_ms = None
        try:
            with httpx.stream("POST", "http://127.0.0.1:18685/v1/chat/completions", json=request(model, stream=True), headers={"X-Request-Id": name}, timeout=15) as r:
                for line in r.iter_lines():
                    if not line:
                        continue
                    chunks.append({"ms": round((time.monotonic()-t)*1000, 2), "line": line})
                    if "FIRST" in line and first_content_ms is None:
                        first_content_ms = round((time.monotonic()-t)*1000, 2)
                        if testmode == "gate":
                            up.post("/release", json={})
                            released = True
        except Exception as exc:
            error = type(exc).__name__ + ": " + str(exc)
        actual = {"http": r.status_code, "chunks": chunks, "content_before_gate_release": released, "first_content_ms": first_content_ms, "transport_error": error, "attempts": len(calls())}
        actual["done"] = any(chunk["line"] == "data: [DONE]" for chunk in chunks)
        explicit_error = any('"error"' in chunk["line"] for chunk in chunks) or error is not None or not actual["done"]
        save(name, "content received before release" if testmode == "gate" else "failure identifiable; no retry after content", actual,
             released if testmode == "gate" else explicit_error and len(calls()) == 1)

for model in ["teacher-chat", "teacher-messages"]:
    for value in ["normal", "invalid", "empty", "truncated"]:
        mode(value)
        name = ("F03-" if value == "normal" else "F04-") + model + "-" + value
        actual = post(name, request(model, response_format={"type": "json_object"}))
        actual["upstream"] = calls()
        save(name, "legal JSON or explicit rejection" if value == "normal" else "reject invalid/empty/truncated JSON", actual,
             actual["http"] == 200 if value == "normal" else actual["http"] >= 400)

template = {"id": "teacher-template", "user_template": "v1 {{name}}", "variables_schema": {"variables": {"name": {"type": "string", "required": True}}}}
create = gw.post("/api/v1/prompts", json=template)
update = gw.put("/api/v1/prompts/teacher-template", json={"expected_version": 1, **{k: v for k,v in template.items() if k != "id"}, "user_template": "v2 {{name}}"})
save("F05-publish", "v1 and v2 retained", {"create": create.json(), "update": update.json()}, create.status_code == 201 and update.status_code == 200)
for version in [1, 2]:
    mode("normal")
    actual = post(f"F05-v{version}", request(prompt={"id": "teacher-template", "version": version, "variables": {"name": "Zed"}}))
    actual["upstream"] = calls()
    rendered = calls()[0]["body"]["messages"] if calls() else []
    save(f"F05-v{version}", f"v{version} Zed reaches upstream", actual, f"v{version} Zed" in json.dumps(rendered))
for name, invocation in [("missing-template", {"id": "absent"}), ("missing-version", {"id": "teacher-template", "version": 99, "variables": {"name": "Zed"}}), ("missing-variable", {"id": "teacher-template", "version": 1})]:
    mode("normal")
    actual = post("F06-"+name, request(prompt=invocation))
    actual["attempts"] = len(calls())
    save("F06-"+name, "clear error, no placeholder sent", actual, actual["http"] >= 400 and len(calls()) == 0)

# Positive control: the student's optional prompt.output path does validate.
for model in ["teacher-chat", "teacher-messages"]:
    for value in ["normal", "invalid", "empty", "truncated", "wrongtype"]:
        mode(value)
        output = {"mode": "structured", "schema_def": {"variables": {"value": {"type": "integer", "required": True}}}} if value == "wrongtype" else {"mode": "json"}
        actual = post("F04-control-"+model+"-"+value, request(model, prompt={"id": "teacher-template", "version": 1, "variables": {"name": "Zed"}, "output": output}))
        save("F04-control-"+model+"-"+value, "prompt.output validates JSON/schema", actual, actual["http"] == 200 if value == "normal" else actual["http"] >= 400)

for value in ["retry", "always500", "bad400", "auth401"]:
    mode(value)
    actual = post("F08-F09-"+value, request())
    received = calls()
    actual["attempts"] = len(received)
    actual["interval_ms"] = [round((b["time"]-a["time"])*1000, 2) for a,b in zip(received, received[1:])]
    expected = "3 attempts then success, exponential 200/400ms" if value == "retry" else "bounded 3 attempts" if value == "always500" else "1 attempt for non-retryable input/auth error"
    passed = (actual["http"] == 200 and len(received) == 3 and actual["interval_ms"][1] >= 350) if value == "retry" else len(received) == (3 if value == "always500" else 1)
    save("F08-F09-"+value, expected, actual, passed)

mode("normal")
statuses = [post("F10-A-"+str(i), request())["http"] for i in range(15)]
b = post("F10-B", request("teacher-messages"))
time.sleep(1)
recovered = post("F11-A", request())
save("F10-F11", "local per-model quota and recovery", {"model_A_statuses": statuses, "model_B_status": b["http"], "A_after_1s": recovered["http"], "note": "No quota/window configuration or limiter implementation exists; burst is corroboration, not assumed threshold."}, False)

time.sleep(0.5)
traces = gw.get("/v1/traces", params={"limit": 1000}).json()
(ROOT / "trace-query.json").write_text(json.dumps(traces, indent=2, ensure_ascii=False))
save("F07-trace-query", "normal/stream/failure queryable by request", {"query_file": "trace-query.json", "total": traces.get("total")}, traces.get("total", 0) > 0)
