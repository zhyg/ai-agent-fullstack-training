"""Teacher F12 fault injection: erase outgoing request in one student test."""
import pytest


@pytest.fixture(autouse=True)
def inject(monkeypatch):
    from provider.protocols.anthropic import AnthropicProtocol
    monkeypatch.setattr(AnthropicProtocol, "format_request", lambda *args, **kwargs: {})
