"""Real calls through unchanged student gateway; only official DeepSeek endpoints.
Authentication remains in environment expansion; never read/print/archive key.
"""
import concurrent.futures
import json
import time
from pathlib import Path
import httpx

ROOT = Path(__file__).parent


def run(model):
    records = []
    with httpx.Client(base_url="http://127.0.0.1:18686", timeout=55) as client:
        for kind in ["normal", "json", "stream"]:
            name = "real-"+model+"-"+kind
            payload = {"model": model, "messages": [{"role": "system", "content": "Return only a JSON object: {\"ok\":true}. No explanation."}, {"role": "user", "content": "Return the JSON now."}], "max_tokens": 256, "thinking": {"type": "disabled"}}
            if kind == "json":
                payload["response_format"] = {"type": "json_object"}
            t = time.monotonic()
            row = {"model_alias": model, "upstream_model": "deepseek-v4-pro" if model == "teacher-pro" else "deepseek-v4-flash", "kind": kind, "request_id": name}
            try:
                if kind == "stream":
                    payload["stream"] = True
                    row["events"] = []
                    with client.stream("POST", "/v1/chat/completions", json=payload, headers={"X-Request-Id": name}) as resp:
                        row["http"] = resp.status_code
                        for line in resp.iter_lines():
                            if line:
                                row["events"].append({"ms": round((time.monotonic()-t)*1000, 2), "line": line})
                    row["status"] = "VERIFIED" if row["http"] == 200 and any('"content":' in e["line"] for e in row["events"]) else "UNVERIFIED"
                else:
                    resp = client.post("/v1/chat/completions", json=payload, headers={"X-Request-Id": name})
                    row["http"] = resp.status_code
                    row["body"] = resp.json()
                    row["status"] = "VERIFIED" if row["http"] == 200 else "UNVERIFIED"
                    if kind == "json" and row["http"] == 200:
                        try:
                            row["parsed_content"] = json.loads(row["body"]["choices"][0]["message"]["content"])
                        except (ValueError, TypeError, KeyError) as exc:
                            row["status"] = "FAIL"
                            row["parse_error"] = str(exc)
            except Exception as exc:
                row["status"] = "UNVERIFIED"
                row["exception"] = type(exc).__name__ + ": " + str(exc)
            row["elapsed_ms"] = round((time.monotonic()-t)*1000, 2)
            records.append(row)
            print(json.dumps(row, ensure_ascii=False), flush=True)
            # One finite normal attempt per protocol when environment unavailable.
            if kind == "normal" and row["status"] == "UNVERIFIED":
                break
    return records


with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    result = list(pool.map(run, ["teacher-pro", "teacher-flash"]))
(ROOT / "real-results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
