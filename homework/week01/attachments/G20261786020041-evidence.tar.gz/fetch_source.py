import base64, concurrent.futures, hashlib, json, pathlib, urllib.request, time

ROOT = pathlib.Path('/tmp/haoyi-eval/snapshot')
ROOT.mkdir(exist_ok=True)
tree = json.loads(pathlib.Path('/tmp/haoyi-eval/tree-proxy.txt').read_text().split('Markdown Content:\n', 1)[1])
def fetch(entry):
    if entry['type'] != 'blob':
        return
    target = ROOT / entry['path']
    if target.exists():
        data = target.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == entry['sha']
        return
    url = 'https://r.jina.ai/' + entry['url']
    for attempt in range(8):
        try:
            raw = urllib.request.urlopen(url, timeout=90).read().decode()
            break
        except Exception as error:
            print('FETCH_RETRY', entry['path'], attempt, str(error), flush=True)
            if attempt == 7:
                raise
            time.sleep(5)
    blob = json.loads(raw.split('Markdown Content:\n', 1)[1])
    data = base64.b64decode(blob['content'])
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert actual == entry['sha'], (entry['path'], actual, entry['sha'])
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    print(entry['path'], len(data), actual, flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    futures = [pool.submit(fetch, entry) for entry in tree['tree']]
    errors = []
    for future in concurrent.futures.as_completed(futures):
        try:
            future.result()
        except Exception as error:
            errors.append(str(error))
    assert not errors, errors
print('ALL_BLOBS_HASH_VERIFIED', flush=True)
