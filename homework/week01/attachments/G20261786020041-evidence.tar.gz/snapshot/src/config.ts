import { z } from 'zod';

export type CircuitBreakerConfig = {
  failureThreshold: number;
  cooldownMs: number;
  permanentSkipTTLMs: number;
};

export type RetryConfig = {
  maxAttempts: number; // number of attempts including the first call
  baseDelayMs: number;
  maxDelayMs: number;
};

export type SSEConfig = {
  keepaliveIntervalMs: number;
  inactivityWatchdogMs: number;
};

export type ReplayConfig = {
  maxEvents: number;
  ttlMs: number;
  maxEventSizeBytes: number;
};

export type PromptGuardMode = 'off' | 'log_only' | 'log_and_reject';

export type PromptGuardConfig = {
  mode: PromptGuardMode;
};

export type StructuredOutputConfig = {
  outputRetryMax: number;
};

export type ProviderOrderConfig = {
  primary: string;
  fallback?: string;
};

/** OpenAI-compatible upstream (OpenAI, DeepSeek, Moonshot, Ollama, vLLM, ...). */
export type OpenAIProviderConfig = {
  /** Empty/undefined → the provider is not registered at all. */
  apiKey?: string;
  baseUrl: string;
  defaultModel: string;
  providerName: string;
};

export type AppConfig = {
  port: number;
  host: string;
  nodeEnv: string;
  providerOrder: ProviderOrderConfig;
  openai: OpenAIProviderConfig;
  circuitBreaker: CircuitBreakerConfig;
  retry: RetryConfig;
  sse: SSEConfig;
  replay: ReplayConfig;
  promptGuard: PromptGuardConfig;
  structuredOutput: StructuredOutputConfig;
};

const envSchema = z.object({
  PORT: z.coerce.number().int().positive().default(3000),
  HOST: z.string().default('127.0.0.1'),
  NODE_ENV: z.string().default('development'),

  PRIMARY_PROVIDER: z.string().default('mock'),
  FALLBACK_PROVIDER: z.string().optional(),

  // Real upstream — registered only when OPENAI_API_KEY is set.
  OPENAI_API_KEY: z.string().optional(),
  OPENAI_BASE_URL: z.string().default('https://api.openai.com/v1'),
  OPENAI_MODEL: z.string().default('gpt-4o-mini'),
  OPENAI_PROVIDER_NAME: z.string().default('openai'),

  CB_FAILURE_THRESHOLD: z.coerce.number().int().positive().default(3),
  CB_COOLDOWN_MS: z.coerce.number().int().positive().default(30_000),
  CB_PERMANENT_SKIP_TTL_MS: z.coerce.number().int().positive().default(86_400_000),

  RETRY_MAX_ATTEMPTS: z.coerce.number().int().positive().default(2),
  RETRY_BASE_DELAY_MS: z.coerce.number().int().positive().default(200),
  RETRY_MAX_DELAY_MS: z.coerce.number().int().positive().default(2000),

  KEEPALIVE_INTERVAL_MS: z.coerce.number().int().positive().default(15_000),
  INACTIVITY_WATCHDOG_MS: z.coerce.number().int().positive().default(60_000),

  REPLAY_MAX_EVENTS: z.coerce.number().int().positive().default(1000),
  REPLAY_TTL_MS: z.coerce.number().int().positive().default(300_000),
  REPLAY_MAX_EVENT_SIZE_BYTES: z.coerce.number().int().positive().default(262_144),

  PROMPT_GUARD_MODE: z.enum(['off', 'log_only', 'log_and_reject']).default('log_and_reject'),

  OUTPUT_RETRY_MAX: z.coerce.number().int().nonnegative().default(1),
});

function loadEnv(): Record<string, string> {
  const out: Record<string, string> = {};
  for (const key of Object.keys(process.env)) {
    out[key] = process.env[key] ?? '';
  }
  return out;
}

export function loadConfig(): AppConfig {
  const parsed = envSchema.parse(loadEnv());
  return {
    port: parsed.PORT,
    host: parsed.HOST,
    nodeEnv: parsed.NODE_ENV,
    providerOrder: {
      primary: parsed.PRIMARY_PROVIDER,
      fallback: parsed.FALLBACK_PROVIDER,
    },
    openai: {
      apiKey: parsed.OPENAI_API_KEY,
      baseUrl: parsed.OPENAI_BASE_URL,
      defaultModel: parsed.OPENAI_MODEL,
      providerName: parsed.OPENAI_PROVIDER_NAME,
    },
    circuitBreaker: {
      failureThreshold: parsed.CB_FAILURE_THRESHOLD,
      cooldownMs: parsed.CB_COOLDOWN_MS,
      permanentSkipTTLMs: parsed.CB_PERMANENT_SKIP_TTL_MS,
    },
    retry: {
      maxAttempts: parsed.RETRY_MAX_ATTEMPTS,
      baseDelayMs: parsed.RETRY_BASE_DELAY_MS,
      maxDelayMs: parsed.RETRY_MAX_DELAY_MS,
    },
    sse: {
      keepaliveIntervalMs: parsed.KEEPALIVE_INTERVAL_MS,
      inactivityWatchdogMs: parsed.INACTIVITY_WATCHDOG_MS,
    },
    replay: {
      maxEvents: parsed.REPLAY_MAX_EVENTS,
      ttlMs: parsed.REPLAY_TTL_MS,
      maxEventSizeBytes: parsed.REPLAY_MAX_EVENT_SIZE_BYTES,
    },
    promptGuard: {
      mode: parsed.PROMPT_GUARD_MODE,
    },
    structuredOutput: {
      outputRetryMax: parsed.OUTPUT_RETRY_MAX,
    },
  };
}

// For tests, create a deterministic config.
export function testConfig(overrides: Partial<AppConfig> = {}): AppConfig {
  return {
    port: 3000,
    host: '127.0.0.1',
    nodeEnv: 'test',
    providerOrder: { primary: 'mock', fallback: 'mock-fallback' },
    openai: {
      apiKey: undefined,
      baseUrl: 'https://api.openai.com/v1',
      defaultModel: 'gpt-4o-mini',
      providerName: 'openai',
    },
    circuitBreaker: { failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 },
    retry: { maxAttempts: 2, baseDelayMs: 200, maxDelayMs: 2000 },
    sse: { keepaliveIntervalMs: 15_000, inactivityWatchdogMs: 60_000 },
    replay: { maxEvents: 1000, ttlMs: 300_000, maxEventSizeBytes: 262_144 },
    promptGuard: { mode: 'log_and_reject' },
    structuredOutput: { outputRetryMax: 1 },
    ...overrides,
  };
}
