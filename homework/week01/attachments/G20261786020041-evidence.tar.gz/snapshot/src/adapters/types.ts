/**
 * Unified LLM adapter contract.
 *
 * All upstream providers (OpenAI-compatible, Gemini, Anthropic, local) MUST
 * implement this interface. No route-level code is allowed to call provider
 * SDKs directly.
 */

import type { FailureClass } from '../core/failure.js';

/** One chat message in a unified shape. */
export type ChatMessage = {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  name?: string;
};

/** Non-streaming unified response. */
export type UnifiedResponse = {
  text: string;
  usage?: TokenUsage;
  rawProviderMeta?: Record<string, unknown>;
};

/** Token usage reported by the provider. */
export type TokenUsage = {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
};

/**
 * Internal stream event emitted by a provider Adapter.
 *
 * This type is INTERNAL to the Adapter -> Stream layer. The SSE routing key
 * for the client side is the SSE `event` field, not this `.type` field.
 * The Stream module does a 1:1 mapping when serialising to SSE.
 */
export type UnifiedStreamEvent =
  | { type: 'delta'; text: string }
  | { type: 'usage'; usage: TokenUsage }
  | { type: 'done'; rawProviderMeta?: Record<string, unknown> }
  | { type: 'error'; failureClass: FailureClass; message: string; retryable: boolean; statusCode?: number };

/**
 * Context passed to every adapter call. Contains trace-level identifiers
 * that SHOULD be forwarded upstream (as request headers, traceparent, ...).
 */
export type AdapterCallContext = {
  requestId: string;
  streamId: string;
};

/** Request shape accepted by every adapter. */
export type AdapterRequest = {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  stream: boolean;
  /** Optional JSON schema that the provider may use for native structured output. */
  responseJsonSchema?: Record<string, unknown>;
  /** Provider name key (e.g. "openai", "mock"). */
  providerName: string;
  /** Opaque provider-specific configuration (API key, base URL, ...). */
  providerConfig?: Record<string, unknown>;
};

export interface LLMAdapter {
  /** Provider identifier, e.g. "openai", "mock". */
  readonly providerName: string;

  /**
   * Non-streaming chat. MUST reject with an AdapterError carrying a
   * FailureClass so the caller can retry / break-circuit / fallback.
   */
  chat(
    req: AdapterRequest,
    signal: AbortSignal,
    ctx: AdapterCallContext,
  ): Promise<UnifiedResponse>;

  /**
   * Streaming chat. Returns an AsyncIterable of UnifiedStreamEvent.
   *
   * Contract:
   * - MUST end with a `done` or `error` event.
   * - MUST NOT emit more than one of `done` or `error`.
   * - MUST respect `signal`; when aborted the iterator should finish promptly.
   * - When the upstream fails, emit a single `error` event instead of throwing.
   */
  chatStream(
    req: AdapterRequest,
    signal: AbortSignal,
    ctx: AdapterCallContext,
  ): AsyncIterable<UnifiedStreamEvent>;
}
