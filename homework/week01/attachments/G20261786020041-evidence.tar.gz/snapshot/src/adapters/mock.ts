/**
 * Mock provider adapter for tests and local development.
 *
 * Behaviour is controlled via `providerConfig`:
 *   - streamDelayMs: ms between delta events (default 10).
 *   - preFirstDeltaFailures: number of times a chat/chatStream call should
 *     fail BEFORE emitting any delta (primary use case: 惰性重试 before
 *     first token). Each failure cycles through {unavailable, rate_limited,
 *     timeout, auth, payment, model_not_found, unknown}.
 *   - postFirstDeltaFailures: times a stream should emit some deltas then
 *     fail. The stream emits one "fake-delta" and then an error event.
 *   - simulatedText: string to stream back (default "Hello world").
 *   - usage: fixed usage object (default {promptTokens:5,completionTokens:5,totalTokens:10}).
 *
 * Every call hits an in-memory counter per providerName, so consecutive
 * invocations behave deterministically.
 */

import { AdapterError } from '../adapters/adapter-error.js';
import type { LLMAdapter, AdapterRequest, AdapterCallContext, UnifiedStreamEvent } from './types.js';

const FAILURE_CLASSES: Array<{ cls: string; status?: number; msg: string; retryable: boolean; tripsCircuit: boolean; perm?: boolean }> = [
  { cls: 'unavailable', status: 503, msg: 'mock upstream 503', retryable: true, tripsCircuit: true },
  { cls: 'rate_limited', status: 429, msg: 'mock rate limited', retryable: true, tripsCircuit: true },
  { cls: 'timeout', status: 408, msg: 'mock timeout', retryable: true, tripsCircuit: true },
  { cls: 'auth', status: 401, msg: 'mock auth failed', retryable: false, tripsCircuit: true, perm: true },
  { cls: 'payment', status: 402, msg: 'mock payment required', retryable: false, tripsCircuit: true, perm: true },
  { cls: 'model_not_found', status: 404, msg: 'mock model not found', retryable: false, tripsCircuit: true, perm: true },
  { cls: 'unknown', msg: 'mock unknown error', retryable: false, tripsCircuit: false },
];

type MockConfig = {
  simulatedText?: string;
  streamDelayMs?: number;
  preFirstDeltaFailures?: number;
  postFirstDeltaFailures?: number;
  usage?: { promptTokens: number; completionTokens: number; totalTokens: number };
  /** Fixed failure class for ALL calls (overrides cycling). */
  alwaysFailClass?: string;
};

const counters = new Map<string, { pre: number; post: number; total: number }>();

function getCounter(name: string): { pre: number; post: number; total: number } {
  let c = counters.get(name);
  if (!c) {
    c = { pre: 0, post: 0, total: 0 };
    counters.set(name, c);
  }
  return c;
}

/** Reset all mock counters (call this in test setup). */
export function __resetMockCounters(): void {
  counters.clear();
}

function buildErrorFromFailureSpec(spec: (typeof FAILURE_CLASSES)[number]): AdapterError {
  return new AdapterError({
    failureClass: spec.cls as never,
    message: spec.msg,
    retryable: spec.retryable,
    tripsCircuit: spec.tripsCircuit,
    isPermanentSkip: spec.perm ?? false,
    statusCode: spec.status,
  });
}

function cycleFailure(idx: number): (typeof FAILURE_CLASSES)[number] {
  return FAILURE_CLASSES[idx % FAILURE_CLASSES.length]!;
}

async function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  if (ms <= 0) return;
  await new Promise<void>((resolve, reject) => {
    const onAbort = () => {
      clearTimeout(t);
      reject(new AdapterError({
        failureClass: 'timeout',
        message: 'aborted',
        retryable: true,
        tripsCircuit: true,
      }));
    };
    const t = setTimeout(() => {
      if (signal) signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    if (signal) {
      if (signal.aborted) {
        clearTimeout(t);
        reject(new AdapterError({
          failureClass: 'timeout',
          message: 'aborted',
          retryable: true,
          tripsCircuit: true,
        }));
        return;
      }
      signal.addEventListener('abort', onAbort, { once: true });
    }
  });
}

export class MockAdapter implements LLMAdapter {
  readonly providerName: string;
  private readonly config: MockConfig;

  constructor(providerName: string, config: MockConfig = {}) {
    this.providerName = providerName;
    this.config = config;
  }

  private getSimulatedText(): string {
    return this.config.simulatedText ?? 'Hello world from mock';
  }

  private getUsage(): { promptTokens: number; completionTokens: number; totalTokens: number } {
    return this.config.usage ?? { promptTokens: 5, completionTokens: 5, totalTokens: 10 };
  }

  private shouldPreFail(counter: number): boolean {
    return (this.config.preFirstDeltaFailures ?? 0) > counter;
  }

  private shouldPostFail(counter: number): boolean {
    return (this.config.postFirstDeltaFailures ?? 0) > counter;
  }

  private getCounter(): { pre: number; post: number; total: number } {
    return getCounter(this.providerName);
  }

  async chat(req: AdapterRequest, signal: AbortSignal, _ctx: AdapterCallContext): Promise<{ text: string; usage?: { promptTokens: number; completionTokens: number; totalTokens: number }; rawProviderMeta?: Record<string, unknown> }> {
    void req;
    const c = this.getCounter();
    c.total += 1;

    if (this.config.alwaysFailClass) {
      const spec = FAILURE_CLASSES.find((f) => f.cls === this.config.alwaysFailClass) ?? FAILURE_CLASSES[0]!;
      throw buildErrorFromFailureSpec(spec);
    }

    if (this.shouldPreFail(c.pre)) {
      const spec = cycleFailure(c.pre);
      c.pre += 1;
      throw buildErrorFromFailureSpec(spec);
    }
    if (signal?.aborted) {
      throw buildErrorFromFailureSpec(FAILURE_CLASSES[2]!); // timeout
    }
    await sleep(this.config.streamDelayMs ?? 10, signal);
    return {
      text: this.getSimulatedText(),
      usage: this.getUsage(),
      rawProviderMeta: { provider: this.providerName },
    };
  }

  async *chatStream(req: AdapterRequest, signal: AbortSignal, _ctx: AdapterCallContext): AsyncGenerator<UnifiedStreamEvent, void, void> {
    void req;
    const c = this.getCounter();
    c.total += 1;

    if (this.config.alwaysFailClass) {
      const spec = FAILURE_CLASSES.find((f) => f.cls === this.config.alwaysFailClass) ?? FAILURE_CLASSES[0]!;
      const err = buildErrorFromFailureSpec(spec);
      yield { type: 'error', failureClass: err.failureClass, message: err.message, retryable: err.retryable, statusCode: err.statusCode };
      return;
    }

    // Pre-first-delta failure — emit error event immediately, never a delta.
    if (this.shouldPreFail(c.pre)) {
      const spec = cycleFailure(c.pre);
      c.pre += 1;
      const err = buildErrorFromFailureSpec(spec);
      yield { type: 'error', failureClass: err.failureClass, message: err.message, retryable: err.retryable, statusCode: err.statusCode };
      return;
    }

    const text = this.getSimulatedText();
    const delay = this.config.streamDelayMs ?? 10;

    // Post-first-delta failure — emit a few deltas then error.
    if (this.shouldPostFail(c.post)) {
      c.post += 1;
      const chars = text.split('');
      for (let i = 0; i < Math.min(3, chars.length); i++) {
        if (signal?.aborted) {
          yield { type: 'error', failureClass: 'timeout', message: 'aborted', retryable: true };
          return;
        }
        await sleep(delay, signal);
        yield { type: 'delta', text: chars[i]! };
      }
      const spec = cycleFailure(c.post);
      const err = buildErrorFromFailureSpec(spec);
      yield { type: 'error', failureClass: err.failureClass, message: err.message, retryable: err.retryable, statusCode: err.statusCode };
      return;
    }

    // Happy path — yield deltas character-by-character, then usage, then done.
    const chars = text.split('');
    for (const ch of chars) {
      if (signal?.aborted) {
        yield { type: 'error', failureClass: 'timeout', message: 'aborted', retryable: true };
        return;
      }
      await sleep(delay, signal);
      yield { type: 'delta', text: ch };
    }
    yield { type: 'usage', usage: this.getUsage() };
    yield { type: 'done', rawProviderMeta: { provider: this.providerName } };
  }
}
