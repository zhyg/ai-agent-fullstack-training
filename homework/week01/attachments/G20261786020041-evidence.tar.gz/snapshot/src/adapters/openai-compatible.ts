/**
 * OpenAI-compatible adapter.
 *
 * Works with any server exposing `POST {baseUrl}/chat/completions`
 * (OpenAI, Azure OpenAI, DeepSeek, Moonshot, Ollama, vLLM, LM Studio, ...).
 * Uses the global `fetch` — no SDK dependency.
 *
 * Failure handling: every path rejects with (or emits) an `AdapterError`
 * carrying a `FailureClass`, so retry / circuit-breaker / fallback keep working.
 */

import { AdapterError } from './adapter-error.js';
import { buildAdapterErrorFromStatus, classifyError } from '../core/failure.js';
import type {
  AdapterCallContext,
  AdapterRequest,
  ChatMessage,
  LLMAdapter,
  TokenUsage,
  UnifiedResponse,
  UnifiedStreamEvent,
} from './types.js';

export type OpenAICompatibleOptions = {
  providerName: string;
  baseUrl: string;
  defaultModel: string;
  apiKey?: string;
  /** Extra headers, e.g. for Azure (`api-key`) or custom gateways. */
  extraHeaders?: Record<string, string>;
};

type OpenAIUsage = {
  prompt_tokens?: number;
  completion_tokens?: number;
  total_tokens?: number;
};

type OpenAIChunk = {
  choices?: Array<{ delta?: { content?: string | null }; message?: { content?: string | null } }>;
  usage?: OpenAIUsage | null;
  error?: { message?: string; type?: string; code?: string };
};

function mapUsage(u: OpenAIUsage | null | undefined): TokenUsage | undefined {
  if (!u) return undefined;
  return {
    promptTokens: u.prompt_tokens ?? 0,
    completionTokens: u.completion_tokens ?? 0,
    totalTokens: u.total_tokens ?? (u.prompt_tokens ?? 0) + (u.completion_tokens ?? 0),
  };
}

/** Extract a human-readable upstream error from a JSON/plain-text body. */
function extractUpstreamMessage(body: string): string | undefined {
  try {
    const parsed = JSON.parse(body) as { error?: { message?: string } };
    if (parsed.error?.message) return parsed.error.message;
  } catch {
    // not JSON
  }
  const trimmed = body.trim();
  return trimmed.length > 0 ? trimmed.slice(0, 300) : undefined;
}

function networkError(err: unknown): AdapterError {
  const cls = classifyError(err);
  const message = err instanceof Error ? err.message : String(err);
  return new AdapterError({
    failureClass: cls === 'unknown' ? 'unavailable' : cls,
    message: `network error: ${message}`,
    retryable: true,
    tripsCircuit: true,
  });
}

export class OpenAICompatibleAdapter implements LLMAdapter {
  readonly providerName: string;
  private readonly baseUrl: string;
  private readonly defaultModel: string;
  private readonly apiKey?: string;
  private readonly extraHeaders: Record<string, string>;

  constructor(opts: OpenAICompatibleOptions) {
    this.providerName = opts.providerName;
    this.baseUrl = opts.baseUrl.replace(/\/+$/, '');
    this.defaultModel = opts.defaultModel;
    this.apiKey = opts.apiKey;
    this.extraHeaders = opts.extraHeaders ?? {};
  }

  /** `model: "any"` (used in gateway examples) falls back to the configured model. */
  private resolveModel(req: AdapterRequest): string {
    return req.model && req.model !== 'any' ? req.model : this.defaultModel;
  }

  private headers(): Record<string, string> {
    const h: Record<string, string> = {
      'Content-Type': 'application/json',
      // Lets a proxy correlate gateway logs with upstream requests.
      ...this.extraHeaders,
    };
    if (this.apiKey) h.Authorization = `Bearer ${this.apiKey}`;
    return h;
  }

  private body(req: AdapterRequest, stream: boolean): string {
    const messages: ChatMessage[] = req.messages.map((m) => ({
      role: m.role,
      content: m.content,
      ...(m.name ? { name: m.name } : {}),
    }));
    const payload: Record<string, unknown> = {
      model: this.resolveModel(req),
      messages,
      stream,
    };
    if (req.temperature !== undefined) payload.temperature = req.temperature;
    if (req.maxTokens !== undefined) payload.max_tokens = req.maxTokens;
    // Ask for token usage on the final streaming chunk (OpenAI-compatible servers
    // that don't support this option simply ignore it).
    if (stream) payload.stream_options = { include_usage: true };
    return JSON.stringify(payload);
  }

  private url(): string {
    return `${this.baseUrl}/chat/completions`;
  }

  async chat(req: AdapterRequest, signal: AbortSignal, _ctx: AdapterCallContext): Promise<UnifiedResponse> {
    let res: Response;
    try {
      res = await fetch(this.url(), { method: 'POST', headers: this.headers(), body: this.body(req, false), signal });
    } catch (err) {
      throw networkError(err);
    }

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw buildAdapterErrorFromStatus({
        statusCode: res.status,
        message: extractUpstreamMessage(text) ?? `upstream responded ${res.status}`,
        raw: text,
      });
    }

    const json = (await res.json().catch(() => null)) as OpenAIChunk | null;
    if (!json) {
      throw new AdapterError({
        failureClass: 'unknown',
        message: 'upstream returned a non-JSON body',
        retryable: false,
        tripsCircuit: false,
      });
    }

    return {
      text: json.choices?.[0]?.message?.content ?? '',
      usage: mapUsage(json.usage),
      rawProviderMeta: { streamed: false },
    };
  }

  async *chatStream(
    req: AdapterRequest,
    signal: AbortSignal,
    _ctx: AdapterCallContext,
  ): AsyncGenerator<UnifiedStreamEvent> {
    let res: Response;
    try {
      res = await fetch(this.url(), { method: 'POST', headers: this.headers(), body: this.body(req, true), signal });
    } catch (err) {
      if (signal.aborted) return;
      const ae = networkError(err);
      yield { type: 'error', failureClass: ae.failureClass, message: ae.message, retryable: true };
      return;
    }

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      const ae = buildAdapterErrorFromStatus({
        statusCode: res.status,
        message: extractUpstreamMessage(text) ?? `upstream responded ${res.status}`,
        raw: text,
      });
      yield {
        type: 'error',
        failureClass: ae.failureClass,
        message: ae.message,
        retryable: ae.retryable,
        statusCode: ae.statusCode,
      };
      return;
    }

    if (!res.body) {
      yield { type: 'error', failureClass: 'unavailable', message: 'upstream returned an empty body', retryable: true };
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let usage: TokenUsage | undefined;
    let sawDone = false;

    try {
      while (true) {
        if (signal.aborted) {
          await reader.cancel().catch(() => {});
          return;
        }
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const rawLine of lines) {
          const line = rawLine.trim();
          if (!line.startsWith('data:')) continue;
          const data = line.slice(5).trim();
          if (!data) continue;
          if (data === '[DONE]') {
            sawDone = true;
            continue;
          }

          let chunk: OpenAIChunk;
          try {
            chunk = JSON.parse(data) as OpenAIChunk;
          } catch {
            continue; // ignore malformed keepalive/partial lines
          }

          // Some servers stream errors inside a 200 response.
          if (chunk.error) {
            const message = chunk.error.message ?? 'upstream stream error';
            yield { type: 'error', failureClass: 'unavailable', message, retryable: true };
            return;
          }

          const delta = chunk.choices?.[0]?.delta?.content;
          if (typeof delta === 'string' && delta.length > 0) {
            yield { type: 'delta', text: delta };
          }
          const u = mapUsage(chunk.usage);
          if (u) usage = u;
        }
      }
    } catch (err) {
      if (signal.aborted) return;
      const ae = networkError(err);
      yield { type: 'error', failureClass: ae.failureClass, message: ae.message, retryable: true };
      return;
    }

    if (usage) yield { type: 'usage', usage };
    yield { type: 'done', rawProviderMeta: { streamed: true, sawDone } };
  }
}
