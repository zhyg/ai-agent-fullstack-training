import { FailureClass } from '../core/failure.js';

/**
 * Unified error thrown / emitted by adapters and core layers.
 *
 * Having one error type everywhere lets FailureClass remain the single source
 * of truth — callers never need to switch on `instanceof` or HTTP codes.
 */
export class AdapterError extends Error {
  readonly failureClass: FailureClass;
  readonly retryable: boolean;
  readonly tripsCircuit: boolean;
  readonly isPermanentSkip: boolean;
  readonly statusCode?: number;
  readonly raw?: unknown;

  constructor(opts: {
    failureClass: FailureClass;
    message: string;
    retryable: boolean;
    tripsCircuit: boolean;
    isPermanentSkip?: boolean;
    statusCode?: number;
    raw?: unknown;
  }) {
    super(opts.message);
    this.name = 'AdapterError';
    this.failureClass = opts.failureClass;
    this.retryable = opts.retryable;
    this.tripsCircuit = opts.tripsCircuit;
    this.isPermanentSkip = opts.isPermanentSkip ?? false;
    this.statusCode = opts.statusCode;
    this.raw = opts.raw;
  }
}
