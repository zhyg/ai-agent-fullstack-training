/**
 * Prompt injection heuristic guard + output redactor.
 *
 * Heuristics are intentionally simple (regex patterns). This is defense-in-depth,
 * not a security boundary — the REAL protection is the architecture that
 * NEVER concatenates user content into the system zone. See the README
 * section on injection for details.
 */

import type { PromptGuardMode } from '../config.js';

export type GuardResult = {
  blocked: boolean;
  patternHit?: string;
  hits: string[];
};

/** Heuristic patterns ordered by confidence. All are case-insensitive. */
const INJECTION_PATTERNS: Array<{ name: string; re: RegExp }> = [
  { name: 'ignore_previous', re: /ignore(\s+all)?(\s+of)?(\s+the)?\s+(above|prior|previous|earlier)\s+(instructions?|prompts?|commands?|directions)/i },
  { name: 'system_prompt_reveal', re: /(what\s+(is|are))(\s+your)?\s+(system\s+prompt|instructions?)/i },
  { name: 'jailbreak', re: /\b(jailbreak|dan\s+mode|dual\s+persona|sydney|opposite\s+day)\b/i },
  { name: 'prompt_injection_literal', re: /\b(prompt\s*injection|prompt_injection)\b/i },
  { name: 'disregard', re: /disregard(\s+all)?(\s+of)?(\s+the)?\s+(above|prior|previous)\s+(instructions?|prompts?)/i },
  { name: 'new_instruction', re: /(your|all)(\s+new)?\s+instructions?(\s+are)?(\s+as\s+follows)/i },
];

export function detectInjection(text: string): GuardResult {
  const hits: string[] = [];
  for (const p of INJECTION_PATTERNS) {
    if (p.re.test(text)) hits.push(p.name);
  }
  return { blocked: hits.length > 0, patternHit: hits[0], hits };
}

/**
 * Apply guard to a message's content. Per `mode`:
 *   - "off": no-op
 *   - "log_only": returns the original text + hits; caller logs
 *   - "log_and_reject": when blocked, throws PromptGuardBlockedError
 */
export function applyGuard(text: string, mode: PromptGuardMode): GuardResult {
  const result = detectInjection(text);
  if (result.blocked && mode === 'log_and_reject') {
    throw new PromptGuardBlockedError(result);
  }
  return result;
}

export class PromptGuardBlockedError extends Error {
  readonly hits: string[];
  readonly first: string;
  readonly guardResult: GuardResult;
  constructor(result: GuardResult) {
    super(`prompt injection blocked: ${result.hits.join(',')}`);
    this.name = 'PromptGuardBlockedError';
    this.hits = result.hits;
    this.first = result.hits[0]!;
    this.guardResult = result;
  }
}

/** Redact suspected secrets (API keys, Bearer tokens) from output or logs. */
const SECRET_PATTERNS: Array<{ name: string; re: RegExp }> = [
  { name: 'bearer', re: /\bBearer\s+[A-Za-z0-9\-._~+/]+=*/g },
  { name: 'api_key_assignment', re: /\b(api[_-]?key|apikey)\s*[:=]\s*['"]?[A-Za-z0-9\-._~+/]{16,}['"]?/gi },
  { name: 'sk_literal', re: /\bsk-[A-Za-z0-9]{10,}\b/g },
];

export function redactSecrets(text: string): string {
  let out = text;
  for (const p of SECRET_PATTERNS) {
    out = out.replace(p.re, '[REDACTED]');
  }
  return out;
}

// Silence unused.
void INJECTION_PATTERNS;
