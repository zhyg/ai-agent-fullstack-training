/**
 * Prompt template registry.
 */

export type PromptTemplate = {
  system: string;
  dataContract: string;
  description?: string;
  createdAt?: number;
};

export type PromptEntry = {
  versions: Map<string, PromptTemplate>;
  latest: string;
};

export class PromptRegistry {
  private readonly prompts = new Map<string, PromptEntry>();

  register(promptId: string, version: string, template: PromptTemplate): void {
    let entry = this.prompts.get(promptId);
    if (!entry) {
      entry = { versions: new Map(), latest: version };
      this.prompts.set(promptId, entry);
    }
    const finalTpl: PromptTemplate = {
      ...template,
      createdAt: Date.now(),
    };
    entry.versions.set(version, finalTpl);
    if (!entry.latest || compareVersions(version, entry.latest) > 0) {
      entry.latest = version;
    }
  }

  resolve(promptId: string, requestedVersion?: string): { template: PromptTemplate; actualVersion: string } | null {
    const entry = this.prompts.get(promptId);
    if (!entry) return null;
    let v = requestedVersion;
    if (!v || v === 'latest') v = entry.latest;
    const tpl = entry.versions.get(v);
    if (!tpl) return null;
    return { template: tpl, actualVersion: v };
  }

  has(promptId: string): boolean {
    return this.prompts.has(promptId);
  }

  listAll(): string[] {
    return [...this.prompts.keys()];
  }
}

function compareVersions(a: string, b: string): number {
  const pa = a.split('.').map((s) => Number(s) || 0);
  const pb = b.split('.').map((s) => Number(s) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const na = pa[i] ?? 0;
    const nb = pb[i] ?? 0;
    if (na !== nb) return na - nb;
  }
  return 0;
}
