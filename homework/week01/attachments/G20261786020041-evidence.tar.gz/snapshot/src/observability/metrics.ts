/**
 * Lightweight in-memory metrics aggregate.
 */

import { childLogger } from './logger.js';

export type MetricsSnapshot = {
  totalRequests: number;
  success: number;
  failure: number;
  perProvider: Record<string, { success: number; failure: number }>;
  ttftMs: { count: number; p50: number; p99: number };
  e2eMs: { count: number; p50: number; p99: number };
  fallbacksUsed: number;
  replaysUsed: number;
};

type Sample = { provider: string; success: boolean; failureClass?: string; ttftMs?: number; e2eMs?: number; fallbackUsed: boolean; replayUsed: boolean };

export class Metrics {
  private samples: Sample[] = [];
  private readonly maxSamples = 10_000;

  record(sample: Sample): void {
    this.samples.push(sample);
    if (this.samples.length > this.maxSamples) {
      this.samples.splice(0, Math.floor(this.maxSamples / 2));
    }
  }

  snapshot(): MetricsSnapshot {
    const perProvider: Record<string, { success: number; failure: number }> = {};
    const ttft: number[] = [];
    const e2e: number[] = [];
    let success = 0;
    let failure = 0;
    let fallbacks = 0;
    let replays = 0;

    for (const s of this.samples) {
      perProvider[s.provider] ??= { success: 0, failure: 0 };
      if (s.success) {
        success += 1;
        perProvider[s.provider]!.success += 1;
      } else {
        failure += 1;
        perProvider[s.provider]!.failure += 1;
      }
      if (s.fallbackUsed) fallbacks += 1;
      if (s.replayUsed) replays += 1;
      if (typeof s.ttftMs === 'number') ttft.push(s.ttftMs);
      if (typeof s.e2eMs === 'number') e2e.push(s.e2eMs);
    }

    return {
      totalRequests: this.samples.length,
      success,
      failure,
      perProvider,
      ttftMs: percentile(ttft),
      e2eMs: percentile(e2e),
      fallbacksUsed: fallbacks,
      replaysUsed: replays,
    };
  }

  reset(): void {
    this.samples = [];
    childLogger({ component: 'metrics' }).info('metrics reset');
  }
}

function percentile(values: number[]): { count: number; p50: number; p99: number } {
  if (values.length === 0) return { count: 0, p50: 0, p99: 0 };
  const sorted = [...values].sort((a, b) => a - b);
  const p50 = sorted[Math.floor(sorted.length * 0.5)]!;
  const p99 = sorted[Math.floor(sorted.length * 0.99)]!;
  return { count: sorted.length, p50, p99 };
}
