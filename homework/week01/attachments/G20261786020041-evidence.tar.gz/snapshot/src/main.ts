// CLI entry point. Keeping `dotenv` loading here (instead of in server.ts)
// ensures tests and library consumers never pick up local secrets or a
// non-default provider from `.env`.
import 'dotenv/config';
import { startServer } from './server.js';

await startServer();
