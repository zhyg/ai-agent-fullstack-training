/**
 * POST /v1/chat
 *
 * - non-stream: uses withFallback + adapter.chat().
 * - stream: uses runStreamPipeline (which handles fallback, SSE, replay buffer).
 * - SSE replay: GET /v1/chat/replay with streamId + lastEventId.
 *
 * Replay rule (per spec): when streamId exists and lastEventId has valid
 * seq in buffer → emit only the MISSING events (no meta re-emission because
 * replay clients already know the stream context). After emitting all
 * buffered events, if doneEvent exists → emit done and close; else keep
 * the connection idle (replay is read-only, no upstream re-call).
 */

import type { FastifyInstance, FastifyRequest } from 'fastify';
import { ZodType as Z, z } from 'zod';
import { CircuitBreaker, PermanentSkipError, CircuitOpenError } from '../core/circuit-breaker.js';
import { StreamReplayBuffer } from '../core/stream-replay.js';
import { KEEPALIVE_FRAME, parseEventId } from '../core/sse-format.js';
import { runStreamPipeline } from '../core/stream.js';
import { withFallback } from '../core/fallback.js';
import { MockAdapter } from '../adapters/mock.js';
import type { ProviderRegistry } from '../core/fallback.js';
import type { AppConfig, ProviderOrderConfig, RetryConfig, SSEConfig, ReplayConfig, PromptGuardConfig } from '../config.js';
import type { LLMAdapter, AdapterRequest, AdapterCallContext } from '../adapters/types.js';
import { AdapterError } from '../adapters/adapter-error.js';
import { classifyError } from '../core/failure.js';
import { applyGuard, PromptGuardBlockedError, redactSecrets } from '../prompt/guard.js';
import { PromptRegistry } from '../prompt/registry.js';
import { registerBuiltinPrompts } from '../prompt/templates.js';
import { SchemaRegistry, parseWithSchema, formatZodSummary, StructuredOutputError } from '../core/structured-output.js';
import { childLogger } from '../observability/logger.js';
import { Metrics } from '../observability/metrics.js';

const chatRequestSchema = z.object({
  requestId: z.string().optional(),
  model: z.string().min(1),
  messages: z.array(z.object({
    role: z.enum(['system', 'user', 'assistant', 'tool']),
    content: z.string(),
    name: z.string().optional(),
  })).min(1),
  stream: z.boolean().default(true),
  promptId: z.string().optional(),
  promptVersion: z.string().optional(),
  responseSchemaName: z.string().optional(),
  temperature: z.number().min(0).max(2).optional(),
  maxTokens: z.number().int().positive().optional(),
});

const replayQuerySchema = z.object({
  streamId: z.string().min(1),
  lastEventId: z.string().min(1),
});

export type ChatDeps = {
  config: AppConfig;
  circuitBreaker: CircuitBreaker;
  retryCfg: RetryConfig;
  sseCfg: SSEConfig;
  replayCfg: ReplayConfig;
  promptGuardCfg: PromptGuardConfig;
  replayBuffer: StreamReplayBuffer;
  promptRegistry: PromptRegistry;
  schemaRegistry: SchemaRegistry;
  adapters: Map<string, LLMAdapter>;
  providerRegistry: ProviderRegistry;
  providerOrder: ProviderOrderConfig;
  metrics: Metrics;
};

function generateRequestId(): string {
  // UUID v4 without needing the uuid package.
  const hex = '0123456789abcdef';
  const groups = [8, 4, 4, 4, 12];
  const parts: string[] = [];
  for (const len of groups) {
    let s = '';
    for (let i = 0; i < len; i++) s += hex[Math.floor(Math.random() * 16)]!;
    parts.push(s);
  }
  // version nibble = 4, variant nibble = 8..b
  parts[2] = '4' + parts[2]!.slice(1);
  parts[3] = hex[8 + Math.floor(Math.random() * 4)]! + parts[3]!.slice(1);
  return parts.join('-');
}

function generateStreamId(requestId: string): string {
  return requestId; // default: streamId equals requestId (per spec).
}

export async function registerChatRoutes(fastify: FastifyInstance, deps: ChatDeps): Promise<void> {
  // Register built-in demo prompts so clients have something to call.
  registerBuiltinPrompts(deps.promptRegistry);

  // -------- POST /v1/chat --------
  fastify.post(
    '/v1/chat',
    { schema: { body: { type: 'object' } } },
    async (req: FastifyRequest, reply) => {
      const log = childLogger({ reqId: req.id });

      let body: unknown;
      try { body = chatRequestSchema.parse(req.body); } catch (e) {
        const issues = (e as z.ZodError).issues ?? [];
        reply.code(400);
        return { ok: false, error: 'invalid_request', details: issues };
      }
      const parsed = body as z.infer<typeof chatRequestSchema>;

      const requestId = parsed.requestId ?? generateRequestId();
      const streamId = generateStreamId(requestId);

      // Prompt guard on user messages. System messages are allowed because
      // they come from the app layer, but we still apply guard defensively.
      try {
        for (const m of parsed.messages) {
          const guard = applyGuard(m.content, deps.promptGuardCfg.mode);
          if (guard.blocked && deps.promptGuardCfg.mode === 'log_only') {
            log.warn({ requestId: parsed.requestId, hits: guard.hits }, 'prompt guard detected injection (allowed by log_only)');
          }
        }
      } catch (err) {
        if (err instanceof PromptGuardBlockedError) {
          log.warn({ requestId: parsed.requestId, hits: err.hits }, 'prompt guard blocked request');
          reply.code(422);
          return { ok: false, error: 'prompt_injection_blocked', hits: err.hits };
        }
        throw err;
      }

      // Resolve prompt template (if any) and inject system prompt.
      const effectiveMessages = [...parsed.messages];
      let actualPromptVersion: string | undefined;
      if (parsed.promptId) {
        const resolved = deps.promptRegistry.resolve(parsed.promptId, parsed.promptVersion);
        if (resolved) {
          actualPromptVersion = resolved.actualVersion;
          // Insert system prompt at the front (or replace first system message).
          const sysIdx = effectiveMessages.findIndex((m) => m.role === 'system');
          if (sysIdx >= 0) {
            effectiveMessages[sysIdx] = { role: 'system', content: resolved.template.system };
          } else {
            effectiveMessages.unshift({ role: 'system', content: resolved.template.system });
          }
        }
      }

      // Resolve response schema (if any).
      let responseJsonSchema: Record<string, unknown> | undefined;
      let schemaName: string | undefined;
      if (parsed.responseSchemaName) {
        const sch = deps.schemaRegistry.resolve(parsed.responseSchemaName);
        if (sch) {
          responseJsonSchema = sch.jsonSchema;
          schemaName = sch.name;
        }
      }

      // Build provider list.
      const providers = [deps.providerOrder.primary];
      if (deps.providerOrder.fallback) providers.push(deps.providerOrder.fallback);

      const ctx: AdapterCallContext = { requestId, streamId };

      if (parsed.stream) {
        // Stream path — hijack response so we bypass Fastify's JSON serialiser
        // (Fastify will try to set Content-Type and end the stream).
        reply.hijack();
        const httpRes = reply.raw;

        // Client disconnect handler.
        let outerAbort = new AbortController();
        httpRes.once('close', () => {
          outerAbort.abort();
          log.info('client disconnected');
        });

        const metrics = await runStreamPipeline({
          res: httpRes,
          requestId,
          streamId,
          messages: effectiveMessages,
          model: parsed.model,
          promptId: parsed.promptId,
          promptVersion: actualPromptVersion,
          temperature: parsed.temperature,
          maxTokens: parsed.maxTokens,
          responseJsonSchema,
          providerRegistry: deps.providerRegistry,
          providerOrder: deps.providerOrder,
          adapters: deps.adapters,
          circuitBreaker: deps.circuitBreaker,
          sseCfg: deps.sseCfg,
          replayCfg: deps.replayCfg,
          replayBuffer: deps.replayBuffer,
          abortSignal: outerAbort.signal,
        });

        deps.metrics.record({
          provider: metrics.provider || deps.providerOrder.primary,
          success: !metrics.failureClass,
          failureClass: metrics.failureClass,
          ttftMs: metrics.ttftMs,
          e2eMs: metrics.e2eMs,
          fallbackUsed: metrics.fallbackUsed,
          replayUsed: metrics.replayUsed ?? false,
        });
        return undefined;
      }

      // Non-stream path.
      try {
        const fbResult = await withFallback(
          async (providerKey) => {
            const adapter = deps.adapters.get(providerKey);
            if (!adapter) throw new AdapterError({ failureClass: 'unknown', message: `provider ${providerKey} not registered`, retryable: false, tripsCircuit: false });
            const entry = deps.providerRegistry.get(providerKey);
            const req: AdapterRequest = {
              model: parsed.model,
              messages: effectiveMessages,
              temperature: parsed.temperature,
              maxTokens: parsed.maxTokens,
              stream: false,
              responseJsonSchema,
              providerName: providerKey,
              providerConfig: entry?.providerConfig,
            };
            return await adapter.chat(req, new AbortController().signal, ctx);
          },
          deps.providerRegistry,
          deps.providerOrder,
          deps.circuitBreaker,
          deps.retryCfg,
          { requestId },
        );

        // Structured output (output retry is local, independent of network retry).
        let text: string = fbResult.result.text;
        const outputAttempts: string[] = [text];
        let structured: unknown = undefined;
        if (schemaName) {
          const sch = deps.schemaRegistry.resolve(schemaName);
          let outAttempt = 0;
          const maxOutAttempts = deps.config.structuredOutput.outputRetryMax + 1; // first try + N retries
          while (outAttempt < maxOutAttempts) {
            if (!sch) break;
            const parse = parseWithSchema(text, sch.schema);
            if (parse.ok) { structured = parse.data; break; }
            // Build an "inject zod errors back to prompt" payload. For the
            // mock adapter this is a no-op (it doesn't actually see the
            // prompt), but the real Adapter path would insert the summary.
            const summary = formatZodSummary(parse.error);
            const adapter = deps.adapters.get(fbResult.usedProvider)!;
            const retryReq: AdapterRequest = {
              model: parsed.model,
              messages: [
                ...effectiveMessages,
                { role: 'assistant', content: text },
                { role: 'user', content: `Previous JSON failed validation. Fix these issues: ${summary}. Respond with ONLY valid JSON matching the schema.` },
              ],
              temperature: parsed.temperature,
              maxTokens: parsed.maxTokens,
              stream: false,
              responseJsonSchema,
              providerName: fbResult.usedProvider,
              providerConfig: deps.providerRegistry.get(fbResult.usedProvider)?.providerConfig,
            };
            const retryRes = await adapter.chat(retryReq, new AbortController().signal, ctx);
            text = retryRes.text;
            outputAttempts.push(text);
            outAttempt += 1;
          }
          if (structured === undefined) {
            deps.metrics.record({ provider: fbResult.usedProvider, success: false, failureClass: 'structured_output_error', fallbackUsed: fbResult.fallbackUsed, replayUsed: false });
            reply.code(400);
            return { ok: false, error: 'structured_output_failed', attempts: outputAttempts.length };
          }
        }

        deps.metrics.record({ provider: fbResult.usedProvider, success: true, fallbackUsed: fbResult.fallbackUsed, replayUsed: false });

        // Redact secrets before returning.
        return {
          ok: true,
          requestId,
          streamId,
          promptVersion: actualPromptVersion,
          usedProvider: fbResult.usedProvider,
          fallbackUsed: fbResult.fallbackUsed,
          text: redactSecrets(text),
          usage: fbResult.result.usage,
          structured,
        };
      } catch (err) {
        const cls = err instanceof AdapterError ? err.failureClass : classifyError(err);
        if (err instanceof CircuitOpenError) {
          deps.metrics.record({ provider: deps.providerOrder.primary, success: false, failureClass: 'circuit_open', fallbackUsed: false, replayUsed: false });
          reply.code(503);
          return { ok: false, error: 'circuit_open', provider: err.provider };
        }
        if (err instanceof PermanentSkipError) {
          reply.code(503);
          return { ok: false, error: 'provider_permanently_skipped', provider: err.provider };
        }
        deps.metrics.record({ provider: deps.providerOrder.primary, success: false, failureClass: cls, fallbackUsed: false, replayUsed: false });
        reply.code(502);
        return { ok: false, error: 'all_providers_failed', failureClass: cls, message: (err as Error).message };
      }
    },
  );

  // -------- GET /v1/chat/replay (SSE replay) --------
  fastify.get('/v1/chat/replay', async (req: FastifyRequest, reply) => {
    const log = childLogger({ reqId: req.id });

    // Always hijack and emit SSE frames for replay requests — even on
    // validation failures. Clients connect expecting an SSE stream.
    reply.hijack();
    const httpRes = reply.raw;
    httpRes.statusCode = 200;
    httpRes.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    httpRes.setHeader('Cache-Control', 'no-cache, no-transform');
    httpRes.setHeader('Connection', 'keep-alive');
    httpRes.setHeader('X-Accel-Buffering', 'no');
    httpRes.setHeader('X-Proxy-Buffering', 'off');
    httpRes.setHeader('Surrogate-Control', 'no-store');
    httpRes.setHeader('X-Accel-Expires', '0');

    const writeAndClose = (code: string, message: string): void => {
      const payload = {
        code,
        failureClass: 'unknown',
        message,
        retryable: false,
      };
      const frame = Buffer.from(`id: replay:0\nevent: error\ndata: ${JSON.stringify(payload)}\n\n`, 'utf-8');
      httpRes.write(frame);
      httpRes.end();
    };

    // lastEventId may arrive as a query param (explicit) or as the standard
    // `Last-Event-ID` request header that browsers send on automatic reconnect.
    // Query wins; the header is the fallback so EventSource reconnects work.
    const rawQuery = { ...(req.query as Record<string, unknown>) };
    const headerId = req.headers['last-event-id'];
    if (rawQuery.lastEventId === undefined && typeof headerId === 'string' && headerId.length > 0) {
      rawQuery.lastEventId = headerId;
    }

    const q = replayQuerySchema.safeParse(rawQuery);
    if (!q.success) {
      writeAndClose('replay_expired', 'missing streamId or lastEventId');
      return undefined;
    }
    const { streamId, lastEventId } = q.data;

    const parsed = parseEventId(lastEventId);
    if (!parsed || parsed.streamId !== streamId) {
      writeAndClose('replay_expired', 'invalid or mismatched Last-Event-ID');
      return undefined;
    }

    const lookup = deps.replayBuffer.lookup({ streamId, lastEventId });

    const kaTimer = setInterval(() => {
      httpRes.write(KEEPALIVE_FRAME);
    }, deps.sseCfg.keepaliveIntervalMs);
    if (typeof kaTimer.unref === 'function') kaTimer.unref();

    const writeAndMaybePause = async (frame: Buffer) => {
      const ok = httpRes.write(frame);
      if (!ok) {
        await new Promise<void>((resolve) => httpRes.once('drain', resolve));
      }
    };

    const done = () => {
      clearInterval(kaTimer);
      httpRes.end();
    };

    let replayUsed = true;
    let replayEventCount = 0;

    if (lookup.kind === 'replay_expired') {
      // Send an error SSE frame, then close.
      const payload = {
        code: 'replay_expired',
        failureClass: 'unknown',
        message: `stream ${streamId} not found or buffer expired`,
        retryable: false,
      };
      const frame = Buffer.from(`id: ${streamId}:0\nevent: error\ndata: ${JSON.stringify(payload)}\n\n`, 'utf-8');
      await writeAndMaybePause(frame);
      done();
      deps.metrics.record({ provider: 'replay', success: false, failureClass: 'replay_expired', fallbackUsed: false, replayUsed: true });
      return undefined;
    }

    if (lookup.kind === 'replay_gap') {
      const payload = {
        code: 'replay_gap',
        failureClass: 'unknown',
        message: `lastEventId older than replay buffer start for ${streamId}`,
        retryable: false,
        earliestAvailableEventId: lookup.earliestAvailableEventId,
      };
      const frame = Buffer.from(`id: ${streamId}:0\nevent: error\ndata: ${JSON.stringify(payload)}\n\n`, 'utf-8');
      await writeAndMaybePause(frame);
      done();
      deps.metrics.record({ provider: 'replay', success: false, failureClass: 'replay_gap', fallbackUsed: false, replayUsed: true });
      return undefined;
    }

    // ok — replay buffered events.
    for (const ev of lookup.events) {
      await writeAndMaybePause(ev.frame);
      replayEventCount += 1;
    }

    // If the stream has ended, emit the cached done and close.
    if (lookup.doneEvent) {
      // For replay, we may need to re-emit done with `replayUsed: true` —
      // but we already have the cached done event. The replay lookup
      // guarantees clients that any done event at the tail is final.
      await writeAndMaybePause(lookup.doneEvent.frame);
      deps.metrics.record({ provider: 'replay', success: true, fallbackUsed: false, replayUsed });
      done();
      return undefined;
    }

    // Stream not yet done in buffer → we can't re-call upstream, so we
    // leave the connection open with keepalive until the client disconnects.
    // In a production system this would integrate with live stream delivery;
    // here we just wait and let keepalive run.
    httpRes.once('close', () => {
      clearInterval(kaTimer);
      log.info('replay client disconnected');
    });

    // Also handle graceful timeout — close after 15min max.
    setTimeout(() => {
      done();
    }, 15 * 60_000).unref?.();

    return undefined;
  });

  // -------- GET /v1/chat/metrics --------
  fastify.get('/v1/chat/metrics', async (_req, reply) => {
    reply.send(deps.metrics.snapshot());
  });

  // -------- POST /v1/admin/circuit-breaker/reset --------
  fastify.post('/v1/admin/circuit-breaker/reset', async (req, reply) => {
    const q = req.query as { provider?: string };
    if (q.provider) {
      deps.circuitBreaker.reset(q.provider);
    } else {
      for (const provider of deps.adapters.keys()) deps.circuitBreaker.reset(provider);
    }
    reply.send({ ok: true });
  });

  // silence unused
  void MockAdapter;
  void Z;
  void StructuredOutputError;
}
