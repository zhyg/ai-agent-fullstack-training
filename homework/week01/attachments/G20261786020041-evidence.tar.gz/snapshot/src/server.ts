import Fastify, { type FastifyInstance } from 'fastify';
import type { Server } from 'node:http';
import { pathToFileURL } from 'node:url';
import { loadConfig } from './config.js';
import { getLogger } from './observability/logger.js';
import { CircuitBreaker } from './core/circuit-breaker.js';
import { StreamReplayBuffer } from './core/stream-replay.js';
import { PromptRegistry } from './prompt/registry.js';
import { SchemaRegistry } from './core/structured-output.js';
import { Metrics } from './observability/metrics.js';
import { MockAdapter } from './adapters/mock.js';
import { OpenAICompatibleAdapter } from './adapters/openai-compatible.js';
import { registerChatRoutes } from './routes/chat.js';
import type { LLMAdapter } from './adapters/types.js';

export async function buildApp(): Promise<{ app: FastifyInstance<Server>; cfg: ReturnType<typeof loadConfig> }> {
  const cfg = loadConfig();
  const log = getLogger();

  const adapters = new Map<string, LLMAdapter>();
  adapters.set('mock', new MockAdapter('mock'));
  adapters.set('mock-fallback', new MockAdapter('mock-fallback'));

  const providerRegistry = new Map([
    ['mock', { name: 'mock' }],
    ['mock-fallback', { name: 'mock-fallback' }],
  ]);

  // Register the real upstream only when a key is configured, so the project
  // still runs with zero credentials (mock-only).
  if (cfg.openai.apiKey) {
    adapters.set(
      cfg.openai.providerName,
      new OpenAICompatibleAdapter({
        providerName: cfg.openai.providerName,
        baseUrl: cfg.openai.baseUrl,
        defaultModel: cfg.openai.defaultModel,
        apiKey: cfg.openai.apiKey,
      }),
    );
    providerRegistry.set(cfg.openai.providerName, { name: cfg.openai.providerName });
    log.info(
      { provider: cfg.openai.providerName, baseUrl: cfg.openai.baseUrl, model: cfg.openai.defaultModel },
      'openai-compatible provider registered',
    );
  } else if (
    cfg.providerOrder.primary === cfg.openai.providerName ||
    cfg.providerOrder.fallback === cfg.openai.providerName
  ) {
    log.warn(
      { provider: cfg.openai.providerName },
      'OPENAI_API_KEY is not set — provider is not registered and requests will fail',
    );
  }

  const cb = new CircuitBreaker(cfg.circuitBreaker);
  const replayBuffer = new StreamReplayBuffer(cfg.replay);
  replayBuffer.startPeriodicCleanup();
  const promptRegistry = new PromptRegistry();
  const schemaRegistry = new SchemaRegistry();
  const metrics = new Metrics();

  const app = Fastify<Server>({
    logger: log,
    trustProxy: true,
    disableRequestLogging: false,
  });

  await registerChatRoutes(app, {
    config: cfg,
    circuitBreaker: cb,
    retryCfg: cfg.retry,
    sseCfg: cfg.sse,
    replayCfg: cfg.replay,
    promptGuardCfg: cfg.promptGuard,
    replayBuffer,
    promptRegistry,
    schemaRegistry,
    adapters,
    providerRegistry,
    providerOrder: cfg.providerOrder,
    metrics,
  });

  app.get('/health', async () => ({ ok: true }));

  return { app, cfg };
}

export async function startServer(): Promise<void> {
  const { app, cfg } = await buildApp();
  const log = getLogger();

  const shutdown = async () => {
    log.info('shutdown signal received');
    try {
      await app.close();
    } catch {
      // already closed
    } finally {
      process.exit(0);
    }
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  try {
    await app.listen({ port: cfg.port, host: cfg.host });
    log.info({ port: cfg.port, host: cfg.host }, 'server started');
  } catch (err) {
    log.error({ err }, 'server failed to start');
    process.exit(1);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  void startServer();
}