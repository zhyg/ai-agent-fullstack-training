/**
 * SSE wire-format encoder/decoder.
 *
 * IMPORTANT DESIGN CHOICE: the single routing key for clients is the SSE
 * outer `event:` field. We NEVER duplicate `type` inside the JSON `data`.
 *
 * This module is a PURE UTILITY — no logging, no side effects. Unit tests
 * assert the exact byte output.
 */

/** Event types that we emit to clients (streamId:seq  format). */
export type SSEEventType = 'meta' | 'provider_switched' | 'delta' | 'usage' | 'error' | 'done';

/** One fully formatted SSE event, ready to be written or buffered. */
export type FormattedSSEEvent = {
  /** id field, e.g. "req-abc:1" */
  id: string;
  /** SSE event type */
  event: SSEEventType;
  /** JSON payload (object — we JSON.stringify here, never elsewhere). */
  payload: Record<string, unknown>;
  /** Wall-clock timestamp when emitted (ms since epoch). Useful for TTL. */
  emittedAt: number;
  /** Pre-computed SSE frame bytes, including terminating \n\n. */
  frame: Buffer;
};

/** Generate an event ID in our canonical format. */
export function generateEventId(streamId: string, seq: number): string {
  return `${streamId}:${seq}`;
}

/** Parse our canonical event ID back into (streamId, seq). Returns null if malformed. */
export function parseEventId(id: string): { streamId: string; seq: number } | null {
  const idx = id.lastIndexOf(':');
  if (idx < 0) return null;
  const streamId = id.slice(0, idx);
  const seqStr = id.slice(idx + 1);
  const seq = Number(seqStr);
  if (!Number.isInteger(seq) || seq <= 0) return null;
  return { streamId, seq };
}

/**
 * Build a single SSE frame as Buffer.
 *
 * SSE spec:
 *   - Each event is terminated by \n\n.
 *   - If the data JSON itself contains newlines, we must emit multiple
 *     `data:` lines — SSE will concatenate them with a single \n.
 *   - `event:` and `id:` are optional but we always emit them.
 *   - Always write UTF-8 Buffer explicitly (Node's Buffer default is UTF-8
 *     but this makes the contract visible).
 */
export function encodeFrame(opts: {
  id: string;
  event: SSEEventType;
  payload: Record<string, unknown>;
}): Buffer {
  const idLine = `id: ${opts.id}\n`;
  const eventLine = `event: ${opts.event}\n`;
  const json = JSON.stringify(opts.payload);
  // Split on \n; SSE concatenates data lines with a single \n between them.
  const jsonLines = json.split('\n');
  const dataLines = jsonLines.map((l) => `data: ${l}\n`).join('');
  const full = `${idLine}${eventLine}${dataLines}\n`; // final blank line = \n\n terminator
  return Buffer.from(full, 'utf-8');
}

/** Convenience: build a FormattedSSEEvent. */
export function formatEvent(opts: {
  streamId: string;
  seq: number;
  event: SSEEventType;
  payload: Record<string, unknown>;
  emittedAt?: number;
}): FormattedSSEEvent {
  const id = generateEventId(opts.streamId, opts.seq);
  const emittedAt = opts.emittedAt ?? Date.now();
  return {
    id,
    event: opts.event,
    payload: opts.payload,
    emittedAt,
    frame: encodeFrame({ id, event: opts.event, payload: opts.payload }),
  };
}

/** SSE keepalive comment frame (`: keepalive\n\n`). */
export const KEEPALIVE_FRAME: Buffer = Buffer.from(': keepalive\n\n', 'utf-8');

/** SSE `retry:` directive — our default reconnect hint (5s). */
export const RETRY_FRAME: Buffer = Buffer.from('retry: 5000\n\n', 'utf-8');

/**
 * Parse a buffer of SSE events (possibly containing multiple events) into
 * FormattedSSEEvent[] or keepalive/comment markers.
 *
 * Used by tests to assert event ordering, and by the client-side replay
 * validator. Not used in production runtime (we only write, never parse).
 */
export type ParsedChunk =
  | { kind: 'event'; id?: string; event?: string; payload: Record<string, unknown> }
  | { kind: 'comment'; text: string }
  | { kind: 'retry'; ms: number };

export function parseSSEBlocks(buf: Buffer): ParsedChunk[] {
  const text = buf.toString('utf-8');
  const blocks = text.split(/\n\n+/);
  const out: ParsedChunk[] = [];
  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed) continue;

    const lines = trimmed.split(/\n/);
    let id: string | undefined;
    let event: string | undefined;
    const dataParts: string[] = [];
    let comment: string | undefined;
    let retryMs: number | undefined;

    for (const rawLine of lines) {
      const line = rawLine;
      if (!line) continue;
      if (line.startsWith(':')) {
        comment = line.slice(1).trim();
        continue;
      }
      if (line.startsWith('id:')) {
        id = line.slice(3).trim();
        continue;
      }
      if (line.startsWith('event:')) {
        event = line.slice(6).trim();
        continue;
      }
      if (line.startsWith('retry:')) {
        const v = line.slice(6).trim();
        const n = Number(v);
        if (Number.isFinite(n)) retryMs = n;
        continue;
      }
      if (line.startsWith('data:')) {
        // SSE spec: after `data:` there may be an optional leading space.
        let payload = line.slice(5);
        if (payload.startsWith(' ')) payload = payload.slice(1);
        dataParts.push(payload);
        continue;
      }
      // Unknown lines — skip silently per SSE spec.
    }

    if (comment !== undefined && dataParts.length === 0 && !id && !event && retryMs === undefined) {
      out.push({ kind: 'comment', text: comment });
      continue;
    }
    if (retryMs !== undefined && dataParts.length === 0 && !id && !event) {
      out.push({ kind: 'retry', ms: retryMs });
      continue;
    }
    if (dataParts.length > 0) {
      const joined = dataParts.join('\n');
      let payload: Record<string, unknown>;
      try {
        payload = JSON.parse(joined);
      } catch {
        // Non-JSON data — still record as a data string.
        payload = { _raw: joined };
      }
      out.push({ kind: 'event', id, event, payload });
    }
  }
  return out;
}
