/**
 * Network-level retry with exponential backoff + full jitter.
 *
 * - Only retries errors where `isRetryable(failureClass)` returns true.
 * - Respects AbortSignal — cancelled upstream means we stop immediately.
 * - Sleep uses `AbortSignal.timeout` when possible so that a parent abort
 *   cancels the sleep mid-way.
 *
 * This is a generic retry helper. The caller (fallback.ts) owns the actual
 * adapter invocation and circuit-breaker check.
 */

import { AdapterError } from '../adapters/adapter-error.js';
import { childLogger } from '../observability/logger.js';
import { classifyError, isRetryable } from './failure.js';
import type { RetryConfig } from '../config.js';

export type RetryAttemptRecord = {
  attempt: number; // 1-based
  provider: string;
  failureClass?: string;
  durationMs: number;
};

export class RetryAbortedError extends Error {
  constructor() {
    super('retry aborted by signal');
    this.name = 'RetryAbortedError';
  }
}

/** Generate full-jitter delay in [0, delayMs]. */
export function fullJitter(delayMs: number, rng: () => number = Math.random): number {
  return Math.floor(rng() * delayMs);
}

/** Compute delay for a given attempt number (1-based). attempt=1 returns 0. */
export function computeDelay(attempt: number, cfg: RetryConfig, rng: () => number = Math.random): number {
  if (attempt <= 1) return 0;
  const exponent = Math.min(attempt - 1, 10); // cap so we don't overflow
  const capped = Math.min(cfg.baseDelayMs * Math.pow(2, exponent - 1), cfg.maxDelayMs);
  return fullJitter(capped, rng);
}

/**
 * Sleep that can be cancelled by an AbortSignal.
 * Returns normally when the timeout fires, throws if aborted.
 */
function cancellableSleep(ms: number, signal: AbortSignal | undefined): Promise<void> {
  if (ms <= 0) return Promise.resolve();
  return new Promise<void>((resolve, reject) => {
    const onAbort = () => {
      cleanup();
      reject(new RetryAbortedError());
    };
    const timer = setTimeout(() => {
      cleanup();
      resolve();
    }, ms);
    const cleanup = () => {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', onAbort);
    };
    if (signal) {
      if (signal.aborted) {
        cleanup();
        reject(new RetryAbortedError());
        return;
      }
      signal.addEventListener('abort', onAbort, { once: true });
    }
  });
}

export type RetryContext = {
  requestId?: string;
  provider: string;
};

/**
 * Retry a synchronous-looking async `fn` up to `cfg.maxAttempts` times.
 * Only retries on retryable failures; re-raises everything else immediately.
 *
 * `attempt` values in the returned records are 1-based.
 * `onFailure` is called after each failure (including non-retryable) with
 * the attempt number, the error, and the context — useful for recording
 * into the circuit breaker.
 */
export async function withRetry<T>(
  fn: (attempt: number) => Promise<T>,
  cfg: RetryConfig,
  ctx: RetryContext,
  signal?: AbortSignal,
  onFailure?: (attempt: number, err: unknown) => void,
): Promise<{ result: T; attempts: RetryAttemptRecord[] }> {
  const log = childLogger({ requestId: ctx.requestId, provider: ctx.provider });
  const records: RetryAttemptRecord[] = [];

  let lastErr: unknown;
  for (let attempt = 1; attempt <= cfg.maxAttempts; attempt++) {
    if (signal?.aborted) throw new RetryAbortedError();

    const started = performance.now();
    try {
      const result = await fn(attempt);
      const durationMs = performance.now() - started;
      records.push({ attempt, provider: ctx.provider, durationMs });
      return { result, attempts: records };
    } catch (err: unknown) {
      const durationMs = performance.now() - started;
      const cls = err instanceof AdapterError ? err.failureClass : classifyError(err);
      records.push({ attempt, provider: ctx.provider, failureClass: cls, durationMs });
      lastErr = err;

      if (onFailure) onFailure(attempt, err);

      if (signal?.aborted) throw new RetryAbortedError();

      if (!isRetryable(cls)) {
        log.warn({ attempt, failureClass: cls }, 'non-retryable error, stopping');
        throw err;
      }

      if (attempt >= cfg.maxAttempts) {
        log.warn({ attempt, failureClass: cls }, 'max attempts reached');
        throw err;
      }

      const delay = computeDelay(attempt + 1, cfg);
      log.info({ attempt, nextDelayMs: delay, failureClass: cls }, 'retrying after delay');
      await cancellableSleep(delay, signal);
    }
  }
  // Unreachable, but satisfy type system.
  throw lastErr;
}
