/**
 * Primary → fallback provider chain.
 *
 * For each provider in order:
 *   1. Ask the circuit breaker whether it's allowed (tries CLOSED / tries
 *      HALF_OPEN probe, skips OPEN / permanently skipped).
 *   2. Run `withRetry` inside that provider.
 *   3. On failure, record into the circuit breaker (respecting tripsCircuit).
 *   4. If the error is not retryable OR we've exhausted retries AND the
 *      provider is permanent, skip to next. Otherwise: if failure is
 *      degradable (isRetryable is false but NOT permanent — i.e. "unknown"),
 *      also skip.
 *        - auth / payment / model_not_found → skip immediately, no retry.
 *        - rate_limited / timeout / unavailable → try withRetry first,
 *          then fallback if still failing.
 *        - unknown → skip immediately (per spec, "原样上抛", no retry).
 */

import { AdapterError } from '../adapters/adapter-error.js';
import { CircuitBreaker } from './circuit-breaker.js';
import { classifyError, tripsCircuit } from './failure.js';
import { withRetry } from './retry.js';
import { childLogger } from '../observability/logger.js';
import type { RetryConfig, ProviderOrderConfig } from '../config.js';

export type ProviderRegistry = Map<string, {
  name: string;
  providerConfig?: Record<string, unknown>;
}>;

export type AttemptRecord = {
  provider: string;
  success: boolean;
  failureClass?: string;
  durationMs: number;
  retryAttempts: number;
};

export type FallbackResult<T> = {
  result: T;
  primaryProvider: string;
  usedProvider: string;
  fallbackUsed: boolean;
  attempts: AttemptRecord[];
};

export class AllProvidersFailedError extends Error {
  readonly attempts: AttemptRecord[];
  constructor(attempts: AttemptRecord[]) {
    super('all providers failed');
    this.name = 'AllProvidersFailedError';
    this.attempts = attempts;
  }
}

function makeFallbackList(order: ProviderOrderConfig): string[] {
  const list: string[] = [order.primary];
  if (order.fallback) list.push(order.fallback);
  return list;
}

export async function withFallback<T>(
  invoker: (providerKey: string) => Promise<T>,
  registry: ProviderRegistry,
  order: ProviderOrderConfig,
  cb: CircuitBreaker,
  retryCfg: RetryConfig,
  ctx: { requestId?: string },
  signal?: AbortSignal,
): Promise<FallbackResult<T>> {
  const log = childLogger({ requestId: ctx.requestId });
  const providers = makeFallbackList(order);
  const attempts: AttemptRecord[] = [];

  let usedProvider = '';
  let fallbackUsed = false;

  for (let i = 0; i < providers.length; i++) {
    const providerKey = providers[i]!;
    const entry = registry.get(providerKey);
    if (!entry) {
      log.warn({ provider: providerKey }, 'provider not registered, skipping');
      attempts.push({ provider: providerKey, success: false, durationMs: 0, retryAttempts: 0, failureClass: 'unknown' });
      continue;
    }

    const gate = cb.tryAcquire(providerKey);
    if (!gate.allowed) {
      log.info({ provider: providerKey }, 'circuit breaker skipped provider');
      attempts.push({ provider: providerKey, success: false, durationMs: 0, retryAttempts: 0, failureClass: 'circuit_open' });
      if (i === 0) fallbackUsed = true;
      continue;
    }

    const started = performance.now();

    try {
      const out = await withRetry(
        () => invoker(providerKey),
        retryCfg,
        { requestId: ctx.requestId, provider: providerKey },
        signal,
        (_attempt, err) => {
          const cls = err instanceof AdapterError ? err.failureClass : classifyError(err);
          if (tripsCircuit(cls)) {
            cb.recordFailure(providerKey, cls);
          }
        },
      );
      cb.recordSuccess(providerKey);
      attempts.push({
        provider: providerKey,
        success: true,
        durationMs: performance.now() - started,
        retryAttempts: out.attempts.length,
      });
      usedProvider = providerKey;
      if (i > 0) fallbackUsed = true;
      return {
        result: out.result,
        primaryProvider: order.primary,
        usedProvider,
        fallbackUsed,
        attempts,
      };
    } catch (err: unknown) {
      const cls = err instanceof AdapterError ? err.failureClass : classifyError(err);
      if (tripsCircuit(cls)) cb.recordFailure(providerKey, cls);

      attempts.push({
        provider: providerKey,
        success: false,
        durationMs: performance.now() - started,
        retryAttempts: 0,
        failureClass: cls,
      });
      log.warn({ provider: providerKey, failureClass: cls }, 'provider failed, moving on');

      if (i === 0 && providers.length > 1) fallbackUsed = true;
    }
  }

  throw new AllProvidersFailedError(attempts);
}
