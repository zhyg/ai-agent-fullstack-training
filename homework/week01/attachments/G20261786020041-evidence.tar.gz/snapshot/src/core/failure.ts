/**
 * Single source of truth for failure classification.
 *
 * Every retry / circuit-breaker / fallback decision MUST call into this
 * module — NEVER switch on `instanceof` or raw HTTP codes in those layers.
 */

import { AdapterError } from '../adapters/adapter-error.js';

export type FailureClass =
  | 'auth'
  | 'payment'
  | 'rate_limited'
  | 'timeout'
  | 'unavailable'
  | 'model_not_found'
  | 'unknown';

const STATUS_TO_CLASS: Record<number, FailureClass> = {
  401: 'auth',
  402: 'payment',
  404: 'model_not_found',
  408: 'timeout',
  429: 'rate_limited',
  500: 'unavailable',
  502: 'unavailable',
  503: 'unavailable',
  504: 'unavailable',
};

/** Map an HTTP status code (or undefined) to a FailureClass. */
export function classifyStatusCode(statusCode: number | undefined): FailureClass {
  if (statusCode === undefined) return 'unknown';
  return STATUS_TO_CLASS[statusCode] ?? 'unknown';
}

/** Map an arbitrary Error to a FailureClass. */
export function classifyError(err: unknown): FailureClass {
  if (err instanceof AdapterError) return err.failureClass;
  if (err instanceof Error) {
    // AbortError means timeout / client cancellation.
    if (err.name === 'AbortError') return 'timeout';
  }
  // Try to sniff a statusCode property (common shape in fetch errors).
  const anyErr = err as { statusCode?: number; status?: number } | undefined;
  if (anyErr && (anyErr.statusCode !== undefined || anyErr.status !== undefined)) {
    return classifyStatusCode(anyErr.statusCode ?? anyErr.status);
  }
  return 'unknown';
}

/** True if the FailureClass should be retried (network-level retry). */
export function isRetryable(cls: FailureClass): boolean {
  switch (cls) {
    case 'rate_limited':
    case 'timeout':
    case 'unavailable':
      return true;
    case 'auth':
    case 'payment':
    case 'model_not_found':
    case 'unknown':
      return false;
  }
}

/** True if this failure trips the circuit breaker on the provider. */
export function tripsCircuit(cls: FailureClass): boolean {
  switch (cls) {
    case 'rate_limited':
    case 'timeout':
    case 'unavailable':
    case 'auth':
    case 'payment':
    case 'model_not_found':
      return true;
    case 'unknown':
      return false;
  }
}

/** True if this failure is permanent and should skip the provider entirely. */
export function isPermanent(cls: FailureClass): boolean {
  return cls === 'auth' || cls === 'payment' || cls === 'model_not_found';
}

/** Convenience: build an AdapterError from a status code + raw error. */
export function buildAdapterErrorFromStatus(opts: {
  statusCode: number;
  message: string;
  raw?: unknown;
}): AdapterError {
  const cls = classifyStatusCode(opts.statusCode);
  return new AdapterError({
    failureClass: cls,
    message: opts.message,
    retryable: isRetryable(cls),
    tripsCircuit: tripsCircuit(cls),
    isPermanentSkip: isPermanent(cls),
    statusCode: opts.statusCode,
    raw: opts.raw,
  });
}
