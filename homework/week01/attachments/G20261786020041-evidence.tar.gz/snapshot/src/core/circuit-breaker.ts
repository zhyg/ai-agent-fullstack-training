/**
 * Three-state circuit breaker keyed by provider.
 *
 * CLOSED  → normal traffic; consecutive failures accumulate.
 * OPEN    → calls fail-fast with CircuitOpenError; no accumulation.
 * HALF_OPEN → one probe request is allowed; success closes, failure re-opens.
 *
 * Permanent failures (auth/payment/model_not_found) immediately open the
 * breaker AND mark the provider as permanently skipped, cleaned up after
 * `permanentSkipTTLMs`.
 */

import { getLogger } from '../observability/logger.js';
import { isPermanent, type FailureClass } from './failure.js';
import type { CircuitBreakerConfig } from '../config.js';

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export type ProviderState = {
  state: CircuitState;
  failureCount: number;
  lastFailureAt: number | null;
  nextAttemptAt: number | null;
  permanentSkipUntil: number | null;
};

export class CircuitOpenError extends Error {
  readonly provider: string;
  constructor(provider: string) {
    super(`circuit OPEN for provider ${provider}`);
    this.name = 'CircuitOpenError';
    this.provider = provider;
  }
}

export class PermanentSkipError extends Error {
  readonly provider: string;
  constructor(provider: string) {
    super(`provider ${provider} is permanently skipped`);
    this.name = 'PermanentSkipError';
    this.provider = provider;
  }
}

export class CircuitBreaker {
  private readonly states = new Map<string, ProviderState>();
  private readonly config: CircuitBreakerConfig;

  constructor(config: CircuitBreakerConfig) {
    this.config = config;
  }

  /** Returns current state; creates default CLOSED if unknown. */
  getState(provider: string): ProviderState {
    let s = this.states.get(provider);
    if (!s) {
      s = {
        state: 'CLOSED',
        failureCount: 0,
        lastFailureAt: null,
        nextAttemptAt: null,
        permanentSkipUntil: null,
      };
      this.states.set(provider, s);
    }
    return s;
  }

  /**
   * Decide whether a call to the provider is allowed right now.
   * Returns `true` if the caller should proceed, `false` if fail-fast.
   *
   * Mutates state transitions (OPEN → HALF_OPEN) as a side effect.
   */
  tryAcquire(provider: string, now: number = Date.now()): { allowed: boolean; probe: boolean } {
    const s = this.getState(provider);

    // Permanent skip takes precedence.
    if (s.permanentSkipUntil !== null) {
      if (now < s.permanentSkipUntil) {
        return { allowed: false, probe: false };
      }
      // TTL expired — clear permanent skip and reset.
      s.permanentSkipUntil = null;
      s.state = 'CLOSED';
      s.failureCount = 0;
    }

    if (s.state === 'CLOSED') return { allowed: true, probe: false };

    if (s.state === 'OPEN') {
      if (s.nextAttemptAt !== null && now >= s.nextAttemptAt) {
        s.state = 'HALF_OPEN';
        s.nextAttemptAt = null;
        getLogger().debug({ provider, state: 'HALF_OPEN' }, 'circuit half-open, releasing probe');
        return { allowed: true, probe: true };
      }
      return { allowed: false, probe: false };
    }

    // HALF_OPEN: one probe at a time. We use `probeUsed` flag tracked as
    // `failureCount === -1` to indicate an in-flight probe.
    if (s.failureCount === -1) {
      // Another probe is in flight — block until it finishes.
      return { allowed: false, probe: false };
    }
    // Allow exactly one probe.
    s.failureCount = -1;
    return { allowed: true, probe: true };
  }

  /** Record a successful call. */
  recordSuccess(provider: string, now: number = Date.now()): void {
    const s = this.getState(provider);
    if (s.state === 'HALF_OPEN') {
      s.state = 'CLOSED';
      s.failureCount = 0;
      s.nextAttemptAt = null;
      getLogger().info({ provider, state: 'CLOSED' }, 'circuit closed after probe success');
    } else {
      s.failureCount = 0;
    }
    s.permanentSkipUntil = null; // success clears any lingering permanent skip
    void now;
  }

  /** Record a failure. `failureClass` drives permanent-skip decision. */
  recordFailure(provider: string, failureClass: FailureClass, now: number = Date.now()): void {
    const s = this.getState(provider);
    s.lastFailureAt = now;

    if (isPermanent(failureClass)) {
      s.permanentSkipUntil = now + this.config.permanentSkipTTLMs;
      s.state = 'OPEN';
      s.nextAttemptAt = now + this.config.permanentSkipTTLMs; // keep it OPEN until skip clears
      s.failureCount = Number.MIN_SAFE_INTEGER; // mark as never to probe again until TTL
      getLogger().warn({ provider, failureClass, permanentSkipUntil: s.permanentSkipUntil }, 'provider permanently skipped');
      return;
    }

    if (s.state === 'HALF_OPEN') {
      // Probe failed → re-open.
      s.state = 'OPEN';
      s.failureCount = 0;
      s.nextAttemptAt = now + this.config.cooldownMs;
      getLogger().warn({ provider, state: 'OPEN' }, 'probe failed, circuit re-opened');
      return;
    }

    if (s.state === 'CLOSED') {
      s.failureCount += 1;
      if (s.failureCount >= this.config.failureThreshold) {
        s.state = 'OPEN';
        s.nextAttemptAt = now + this.config.cooldownMs;
        getLogger().warn({ provider, state: 'OPEN', failureCount: s.failureCount }, 'circuit opened');
      }
      return;
    }

    // OPEN (shouldn't normally get here since tryAcquire blocks, but be defensive).
    s.nextAttemptAt ??= now + this.config.cooldownMs;
  }

  /** Reset a provider's state (useful for admin endpoint & tests). */
  reset(provider: string): void {
    this.states.delete(provider);
    getLogger().info({ provider }, 'circuit breaker state reset');
  }

  /** Manually force a provider to permanently skip. */
  forcePermanentSkip(provider: string, now: number = Date.now()): void {
    const s = this.getState(provider);
    s.state = 'OPEN';
    s.permanentSkipUntil = now + this.config.permanentSkipTTLMs;
    s.failureCount = Number.MIN_SAFE_INTEGER;
    s.nextAttemptAt = now + this.config.permanentSkipTTLMs;
  }

  /** List all known providers and their current state. */
  snapshot(): Record<string, ProviderState> {
    const out: Record<string, ProviderState> = {};
    for (const [k, v] of this.states.entries()) out[k] = { ...v };
    return out;
  }
}
