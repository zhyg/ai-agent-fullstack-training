/**
 * SSE replay buffer.
 *
 * Design:
 *   - Bounded by MAX_EVENTS (ring semantics) AND TTL (evict from head).
 *   - Each entry = FormattedSSEEvent (pre-encoded frame). Replay is pure
 *     reads — no re-calling of upstream providers.
 *   - Cleanup is LAZY (on append) + PERIODIC (every 30s) — no timer wakeup
 *     when there are no streams.
 *   - StreamId → { events (indexed by seq), doneEvent (optional), createdAt }
 */

import type { ReplayConfig } from '../config.js';
import { parseEventId, type FormattedSSEEvent } from './sse-format.js';

export type ReplayLookupResult =
  | { kind: 'ok'; events: FormattedSSEEvent[]; doneEvent: FormattedSSEEvent | null }
  | { kind: 'replay_gap'; earliestAvailableEventId: string }
  | { kind: 'replay_expired' };

type StreamBucket = {
  /** Events indexed by seq. Using Map so we can drop individual ones cheaply. */
  events: Map<number, FormattedSSEEvent>;
  /** Earliest seq still in buffer (optimisation for replay_gap detection). */
  headSeq: number;
  /** Latest seq seen. */
  tailSeq: number;
  doneEvent: FormattedSSEEvent | null;
  createdAt: number;
  lastAccessAt: number;
};

export class StreamReplayBuffer {
  private readonly buckets = new Map<string, StreamBucket>();
  private readonly config: ReplayConfig;
  private cleanupTimer: ReturnType<typeof setInterval> | null = null;

  constructor(config: ReplayConfig) {
    this.config = config;
    // Timer is NOT auto-started — callers that need periodic cleanup (server.ts)
    // explicitly call startPeriodicCleanup(). Tests rely on lazy eviction via
    // append()/lookup() and never start a ticking interval.
  }

  /** Opt-in periodic cleanup. Call once after construction. */
  startPeriodicCleanup(): void {
    if (this.cleanupTimer !== null) return;
    this.cleanupTimer = setInterval(() => {
      this.expireAll(Date.now());
    }, 30_000);
    if (typeof (this.cleanupTimer as unknown as { unref?: () => void }).unref === 'function') {
      (this.cleanupTimer as unknown as { unref: () => void }).unref();
    }
  }

  stop(): void {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
  }

  private getOrCreateBucket(streamId: string, now: number = Date.now()): StreamBucket {
    let b = this.buckets.get(streamId);
    if (!b) {
      b = {
        events: new Map(),
        headSeq: 0,
        tailSeq: 0,
        doneEvent: null,
        createdAt: now,
        lastAccessAt: now,
      };
      this.buckets.set(streamId, b);
    }
    return b;
  }

  /** Append one event to the buffer. Evicts from head to stay within maxEvents. */
  append(streamId: string, event: FormattedSSEEvent, now: number = Date.now()): void {
    // Refuse oversized frames: a pathological delta would otherwise pin memory
    // until TTL expiry. Dropped events simply do not appear on replay.
    if (event.frame.length > this.config.maxEventSizeBytes) return;

    const b = this.getOrCreateBucket(streamId, now);

    // Drop the done event if we're seeing it again (shouldn't happen but safe).
    if (event.event === 'done') {
      b.doneEvent = event;
      b.lastAccessAt = now;
      return;
    }

    // Enforce TTL on head before adding.
    this.evictExpiredFromHead(b, now);

    const seq = parseEventId(event.id)?.seq;
    if (seq === undefined) {
      // Malformed event — skip silently.
      return;
    }
    b.events.set(seq, event);
    if (b.headSeq === 0) b.headSeq = seq;
    b.tailSeq = Math.max(b.tailSeq, seq);

    // Evict oldest if we're over capacity.
    while (b.events.size > this.config.maxEvents && b.headSeq > 0 && b.headSeq <= b.tailSeq) {
      b.events.delete(b.headSeq);
      b.headSeq += 1;
    }

    b.lastAccessAt = now;
  }

  private evictExpiredFromHead(b: StreamBucket, now: number): void {
    // While the head event is older than TTL, drop it.
    // The `headSeq <= tailSeq` guard is essential: after evicting every stored
    // event, headSeq points one past tailSeq (a seq not appended yet). Without
    // the guard the missing-head branch would increment forever.
    while (b.headSeq > 0 && b.headSeq <= b.tailSeq) {
      const head = b.events.get(b.headSeq);
      if (!head) {
        b.headSeq += 1;
        continue;
      }
      if (now - head.emittedAt > this.config.ttlMs) {
        b.events.delete(b.headSeq);
        b.headSeq += 1;
      } else {
        break;
      }
    }
    // Also evict the done event if it's old.
    if (b.doneEvent && now - b.doneEvent.emittedAt > this.config.ttlMs) {
      b.doneEvent = null;
    }
    // If bucket is empty, just leave it — callers handle key deletion explicitly.
  }

  // The line above was intentionally odd — keep deletion logic here:
  private _maybeDeleteBucket(streamId: string): void {
    const b = this.buckets.get(streamId);
    if (!b) return;
    if (b.events.size === 0 && !b.doneEvent) {
      this.buckets.delete(streamId);
    }
  }

  expireAll(now: number = Date.now()): void {
    for (const [streamId, b] of this.buckets) {
      this.evictExpiredFromHead(b, now);
      this._maybeDeleteBucket(streamId);
      void streamId;
    }
  }

  /**
   * Look up replay events for a (streamId, lastEventId).
   *
   * Cases:
   *   - streamId unknown / fully expired → replay_expired
   *   - lastEventId malformed → replay_expired (treat as unknown)
   *   - lastEventId's streamId doesn't match → replay_expired (cross-stream refused)
   *   - lastEventId.seq < headSeq → replay_gap with earliestAvailableEventId
   *   - Otherwise return events after lastEventId, up to tail, plus cached done.
   */
  lookup(opts: { streamId: string; lastEventId: string; now?: number }): ReplayLookupResult {
    const { now = Date.now() } = opts;
    const b = this.buckets.get(opts.streamId);
    if (!b) return { kind: 'replay_expired' };

    // Parse lastEventId.
    const colonIdx = opts.lastEventId.lastIndexOf(':');
    if (colonIdx < 0) return { kind: 'replay_expired' };
    const sid = opts.lastEventId.slice(0, colonIdx);
    const seqStr = opts.lastEventId.slice(colonIdx + 1);
    const seq = Number(seqStr);
    if (!Number.isInteger(seq) || seq <= 0) return { kind: 'replay_expired' };

    // Cross-stream check — MUST match.
    if (sid !== opts.streamId) return { kind: 'replay_expired' };

    this.evictExpiredFromHead(b, now);
    this._maybeDeleteBucket(opts.streamId);
    if (!this.buckets.has(opts.streamId)) return { kind: 'replay_expired' };

    if (b.headSeq > 0 && seq < b.headSeq) {
      // Gap — report the earliest seq that is ACTUALLY present. headSeq can point
      // at a slot that was never written (sparse seqs / partial TTL eviction),
      // so scanning forward avoids advertising a non-existent event id.
      let earliestSeq = b.headSeq;
      while (earliestSeq <= b.tailSeq && !b.events.has(earliestSeq)) earliestSeq += 1;
      const earliest = b.events.get(earliestSeq);
      return {
        kind: 'replay_gap',
        earliestAvailableEventId: earliest?.id ?? `${opts.streamId}:${earliestSeq}`,
      };
    }

    // OK — replay from seq+1 to tail.
    const out: FormattedSSEEvent[] = [];
    for (let s = seq + 1; s <= b.tailSeq; s++) {
      const evt = b.events.get(s);
      if (evt) out.push(evt);
    }
    return { kind: 'ok', events: out, doneEvent: b.doneEvent };
  }

  /** Check if a streamId has ANY events (used by tests). */
  hasStream(streamId: string): boolean {
    return this.buckets.has(streamId) && this.buckets.get(streamId)!.events.size > 0;
  }

  /** Number of known streams (tests & observability). */
  streamCount(): number {
    return this.buckets.size;
  }

  /** Clear everything (tests). */
  clear(): void {
    this.buckets.clear();
  }
}
