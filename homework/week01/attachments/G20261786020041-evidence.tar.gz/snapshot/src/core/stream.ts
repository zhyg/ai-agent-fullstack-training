/**
 * SSE streaming orchestrator.
 *
 * Responsibilities:
 *   - Run fallback chain until a provider starts streaming successfully.
 *   - Emit SSE frames to an http.ServerResponse, with proper headers,
 *     disable-proxy-buffering directives, UTF-8 buffers, \n\n separators.
 *   - Record TTFT / GEN / E2E by inspecting event timestamps.
 *   - Feed every emitted event into the StreamReplayBuffer (for later replay).
 *   - Send keepalive every 15s (configurable).
 *   - Enforce inactivity watchdog: if no new upstream chunk arrives within
 *     `inactivityWatchdogMs`, abort and emit an error event.
 *   - Respect backpressure: when `res.write()` returns false, pause reading
 *     from the upstream AsyncIterable until the `drain` event fires.
 *   - Handle client disconnect (abort) gracefully.
 *   - Lazy retry boundary: if the upstream fails BEFORE we emit the FIRST
 *     SSE event (not even meta), we transparently retry or fall back. Once
 *     any byte has been written, no more silent retries — we emit an
 *     `error` event and close.
 */

import type { ServerResponse } from 'node:http';
import { CircuitBreaker } from './circuit-breaker.js';
import type { SSEConfig, ReplayConfig, ProviderOrderConfig } from '../config.js';
import { StreamReplayBuffer } from './stream-replay.js';
import { formatEvent, KEEPALIVE_FRAME, type FormattedSSEEvent, type SSEEventType } from './sse-format.js';
import { childLogger } from '../observability/logger.js';
import { AdapterError } from '../adapters/adapter-error.js';
import type { FailureClass } from './failure.js';
import type { ProviderRegistry } from './fallback.js';
import type { AdapterRequest, AdapterCallContext, LLMAdapter, UnifiedStreamEvent, ChatMessage, TokenUsage } from '../adapters/types.js';

type StreamMetrics = {
  requestId: string;
  streamId: string;
  provider: string;
  model: string;
  promptVersion: string;
  attempt: number;
  fallbackUsed: boolean;
  ttftMs?: number;
  genMs?: number;
  e2eMs?: number;
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
  failureClass?: string;
  replayUsed?: boolean;
  replayEventCount?: number;
  replayGap?: boolean;
  replayExpired?: boolean;
};

export type StreamInitArgs = {
  res: ServerResponse;
  requestId: string;
  streamId: string;
  messages: ChatMessage[];
  model: string;
  promptId?: string;
  promptVersion?: string;
  temperature?: number;
  maxTokens?: number;
  responseJsonSchema?: Record<string, unknown>;
  providerRegistry: ProviderRegistry;
  providerOrder: ProviderOrderConfig;
  adapters: Map<string, LLMAdapter>;
  circuitBreaker: CircuitBreaker;
  sseCfg: SSEConfig;
  replayCfg: ReplayConfig;
  replayBuffer: StreamReplayBuffer;
  abortSignal?: AbortSignal;
};

/**
 * Write the standard SSE response headers. This MUST happen BEFORE we do
 * any async work; otherwise Fastify may already have written other headers.
 */
export function writeSSEHeaders(res: ServerResponse): void {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setHeader('X-Proxy-Buffering', 'off');
  res.setHeader('Surrogate-Control', 'no-store');
  res.setHeader('X-Accel-Expires', '0');
}

/** Wait for res's drain event so we can respect backpressure. */
function waitDrain(res: ServerResponse): Promise<void> {
  return new Promise((resolve) => {
    const done = () => {
      res.off('drain', done);
      res.off('close', done);
      res.off('error', done);
      resolve();
    };
    res.once('drain', done);
    // A disconnected client never emits 'drain' — resolving on close avoids
    // leaving the pipeline stuck forever on a write that will never flush.
    res.once('close', done);
    res.once('error', done);
    if (res.writableEnded) resolve();
  });
}

type EmitArg = { event: SSEEventType; payload: Record<string, unknown> };

export async function runStreamPipeline(args: StreamInitArgs): Promise<StreamMetrics> {
  const { res, requestId, streamId, adapters, providerRegistry, providerOrder, circuitBreaker, sseCfg, replayBuffer, abortSignal } = args;
  const log = childLogger({ requestId, streamId, model: args.model });

  writeSSEHeaders(res);

  let seq = 0;
  const emit = (ev: EmitArg): FormattedSSEEvent => {
    seq += 1;
    const fullPayload = { ...ev.payload, _seq: seq };
    const fmt = formatEvent({ streamId, seq, event: ev.event, payload: fullPayload });
    replayBuffer.append(streamId, fmt);
    return fmt;
  };

  const pipe = async (frame: Buffer): Promise<void> => {
    const ok = res.write(frame);
    if (!ok) {
      await waitDrain(res);
    }
  };

  const startedAt = performance.now();
  let firstDeltaAt: number | undefined;
  let lastDeltaAt: number | undefined;
  let metrics: StreamMetrics = {
    requestId,
    streamId,
    provider: '',
    model: args.model,
    promptVersion: args.promptVersion ?? 'latest',
    attempt: 0,
    fallbackUsed: false,
  };

  let firstEventEmitted = false;
  let keepaliveTimer: ReturnType<typeof setInterval> | null = null;

  const stopTimers = () => {
    if (keepaliveTimer) { clearInterval(keepaliveTimer); keepaliveTimer = null; }
  };

  const startKeepalive = () => {
    keepaliveTimer = setInterval(() => {
      pipe(KEEPALIVE_FRAME).catch((e) => {
        log.warn({ err: String(e) }, 'keepalive write failed');
      });
    }, sseCfg.keepaliveIntervalMs);
    if (typeof keepaliveTimer.unref === 'function') keepaliveTimer.unref();
  };

  const providerList: string[] = [providerOrder.primary];
  if (providerOrder.fallback) providerList.push(providerOrder.fallback);

  let fallbackUsed = false;
  let finalError: AdapterError | null = null;
  /** True once the client received a terminal frame (`done` or `error`). */
  let clientTerminated = false;
  /** `meta` is emitted exactly once — later providers report a switch instead. */
  let metaEmitted = false;
  let previousProvider = '';

  for (let currentIdx = 0; currentIdx < providerList.length; currentIdx++) {
    const providerKey = providerList[currentIdx]!;
    const entry = providerRegistry.get(providerKey);
    const adapter = adapters.get(providerKey);
    if (!entry || !adapter) {
      log.warn({ provider: providerKey }, 'provider not registered, skipping');
      continue;
    }

    const gate = circuitBreaker.tryAcquire(providerKey);
    if (!gate.allowed) {
      log.info({ provider: providerKey }, 'circuit breaker open, skipping');
      if (currentIdx === 0 && providerList.length > 1) fallbackUsed = true;
      continue;
    }

    if (currentIdx > 0) fallbackUsed = true;

    const localAbort = new AbortController();
    if (abortSignal?.aborted) localAbort.abort();
    abortSignal?.addEventListener('abort', () => localAbort.abort(), { once: true });

    const req: AdapterRequest = {
      model: args.model,
      messages: args.messages,
      temperature: args.temperature,
      maxTokens: args.maxTokens,
      stream: true,
      responseJsonSchema: args.responseJsonSchema,
      providerName: providerKey,
      providerConfig: entry.providerConfig,
    };
    const ctx: AdapterCallContext = { requestId, streamId };

    log.info({ provider: providerKey }, 'starting stream from provider');

    try {
      const iter = adapter.chatStream(req, localAbort.signal, ctx);
      const it = iter[Symbol.asyncIterator]();

      /**
       * Race each upstream read against the inactivity watchdog. On timeout we
       * abort the adapter AND reject, so a provider that never resolves (or
       * ignores AbortSignal) can no longer keep the client hanging forever.
       */
      const nextWithWatchdog = async (): Promise<IteratorResult<UnifiedStreamEvent>> => {
        let timer: ReturnType<typeof setTimeout> | null = null;
        const watchdog = new Promise<never>((_resolve, reject) => {
          timer = setTimeout(() => {
            log.warn({ watchdogMs: sseCfg.inactivityWatchdogMs }, 'inactivity watchdog fired');
            localAbort.abort();
            reject(
              new AdapterError({
                failureClass: 'timeout',
                message: `inactivity watchdog: no upstream data within ${sseCfg.inactivityWatchdogMs}ms`,
                retryable: true,
                tripsCircuit: true,
              }),
            );
          }, sseCfg.inactivityWatchdogMs);
          if (typeof timer.unref === 'function') timer.unref();
        });
        try {
          return await Promise.race([it.next(), watchdog]);
        } finally {
          if (timer) clearTimeout(timer);
        }
      };

      if (!metaEmitted) {
        const metaEv = emit({
          event: 'meta',
          payload: {
            requestId,
            streamId,
            provider: providerKey,
            model: args.model,
            promptId: args.promptId,
            promptVersion: args.promptVersion ?? 'latest',
          },
        });
        await pipe(metaEv.frame);
        metaEmitted = true;
      } else {
        // Provider changed after a pre-delta failure. Keep `meta` unique and
        // make the switch explicit so clients/audits see the real producer.
        const swEv = emit({
          event: 'provider_switched',
          payload: {
            from: previousProvider,
            to: providerKey,
            reason: finalError?.failureClass ?? 'unknown',
          },
        });
        await pipe(swEv.frame);
      }
      previousProvider = providerKey;
      firstEventEmitted = true;

      startKeepalive();

      let emittedDeltaCount = 0;
      let done = false;
      let endedWithError = false;
      let switchProvider = false;
      let usage: TokenUsage | undefined;

      while (true) {
        if (localAbort.signal.aborted) {
          log.info('stream aborted externally');
          break;
        }

        let next: IteratorResult<UnifiedStreamEvent>;
        try {
          next = await nextWithWatchdog();
        } catch (iterErr) {
          if (firstEventEmitted && emittedDeltaCount === 0) {
            log.warn({ err: String(iterErr), provider: providerKey }, 'pre-delta error, transparently switching provider');
            // Keep the failure class so it can be reported if no provider succeeds.
            finalError = iterErr instanceof AdapterError
              ? iterErr
              : new AdapterError({ failureClass: 'timeout', message: String(iterErr), retryable: true, tripsCircuit: true });
            stopTimers();
            firstEventEmitted = false;
            break;
          }
          const failureFromIter = iterErr instanceof AdapterError ? iterErr.failureClass : 'timeout' as FailureClass;
          finalError = iterErr instanceof AdapterError
            ? iterErr
            : new AdapterError({ failureClass: failureFromIter, message: String(iterErr), retryable: true, tripsCircuit: true });
          const errEv = emit({
            event: 'error',
            payload: {
              code: finalError.failureClass,
              failureClass: finalError.failureClass,
              message: finalError.message,
              retryable: finalError.retryable,
            },
          });
          await pipe(errEv.frame);
          clientTerminated = true;
          endedWithError = true;
          done = true;
          break;
        }

        if (next.done) break;
        const ev = next.value!;

        switch (ev.type) {
          case 'delta': {
            const frame = emit({ event: 'delta', payload: { text: ev.text } });
            await pipe(frame.frame);
            emittedDeltaCount += 1;
            const now = performance.now();
            if (firstDeltaAt === undefined) firstDeltaAt = now;
            lastDeltaAt = now;
            break;
          }
          case 'usage': {
            usage = ev.usage;
            const frame = emit({
              event: 'usage',
              payload: {
                promptTokens: ev.usage.promptTokens,
                completionTokens: ev.usage.completionTokens,
                totalTokens: ev.usage.totalTokens,
              },
            });
            await pipe(frame.frame);
            break;
          }
          case 'done': {
            const ttftMs = firstDeltaAt !== undefined ? firstDeltaAt - startedAt : 0;
            const genMs = (firstDeltaAt !== undefined && lastDeltaAt !== undefined) ? lastDeltaAt - firstDeltaAt : 0;
            const e2eMs = performance.now() - startedAt;
            const frame = emit({
              event: 'done',
              payload: { ttftMs, genMs, e2eMs, replayUsed: false },
            });
            await pipe(frame.frame);
            done = true;
            clientTerminated = true;
            metrics = {
              requestId, streamId, provider: providerKey, model: args.model,
              promptVersion: args.promptVersion ?? 'latest',
              attempt: currentIdx, fallbackUsed,
              ttftMs, genMs, e2eMs,
              promptTokens: usage?.promptTokens,
              completionTokens: usage?.completionTokens,
              totalTokens: usage?.totalTokens,
            };
            break;
          }
          case 'error': {
            finalError = new AdapterError({
              failureClass: ev.failureClass,
              message: ev.message,
              retryable: ev.retryable,
              tripsCircuit: true,
              statusCode: ev.statusCode,
            });
            // Lazy retry boundary: before any delta the client has only seen
            // `meta`, so a pre-delta error event may still switch providers
            // transparently instead of terminating the stream.
            if (emittedDeltaCount === 0 && currentIdx < providerList.length - 1) {
              log.warn(
                { failureClass: finalError.failureClass, provider: providerKey },
                'pre-delta error event, switching provider',
              );
              switchProvider = true;
              break;
            }
            const frame = emit({
              event: 'error',
              payload: { code: ev.failureClass, failureClass: ev.failureClass, message: ev.message, retryable: ev.retryable },
            });
            await pipe(frame.frame);
            done = true;
            clientTerminated = true;
            endedWithError = true;
            metrics.failureClass = finalError.failureClass;
            break;
          }
        }
        if (switchProvider) break;
        if (done) break;
      }

      if (done) {
        // A provider that sent an `error` event did NOT succeed — recording a
        // success here would keep a broken provider in CLOSED state forever.
        if (endedWithError && finalError) {
          circuitBreaker.recordFailure(providerKey, finalError.failureClass);
        } else {
          circuitBreaker.recordSuccess(providerKey);
        }
        break;
      }

      if (emittedDeltaCount === 0 && currentIdx < providerList.length - 1) {
        if (finalError) {
          circuitBreaker.recordFailure(providerKey, finalError.failureClass);
        } else {
          circuitBreaker.recordFailure(providerKey, 'unavailable');
        }
        continue;
      }

      if (!finalError) {
        finalError = new AdapterError({
          failureClass: 'unavailable',
          message: 'upstream stream ended without done or error',
          retryable: true,
          tripsCircuit: true,
        });
      }
      const errEv = emit({
        event: 'error',
        payload: {
          code: finalError.failureClass,
          failureClass: finalError.failureClass,
          message: finalError.message,
          retryable: finalError.retryable,
        },
      });
      await pipe(errEv.frame);
      clientTerminated = true;
      metrics.failureClass = finalError.failureClass;
      break;
    } catch (outerErr) {
      if (!firstEventEmitted) {
        const aErr = outerErr instanceof AdapterError ? outerErr : new AdapterError({
          failureClass: 'unknown', message: String(outerErr), retryable: false, tripsCircuit: false,
        });
        finalError = aErr;
        circuitBreaker.recordFailure(providerKey, aErr.failureClass);
        stopTimers();
        continue;
      }
      const aErr = outerErr instanceof AdapterError ? outerErr : new AdapterError({
        failureClass: 'unknown', message: String(outerErr), retryable: false, tripsCircuit: false,
      });
      finalError = aErr;
      const errEv = emit({
        event: 'error',
        payload: { code: aErr.failureClass, failureClass: aErr.failureClass, message: aErr.message, retryable: aErr.retryable },
      });
      await pipe(errEv.frame);
      clientTerminated = true;
      break;
    } finally {
      stopTimers();
    }
  }

  // The client must ALWAYS receive a terminal frame. A provider can fail
  // pre-delta and be skipped for fallback (unregistered or circuit-open), in
  // which case no `done`/`error` was written — previously the connection just
  // closed silently after `meta`.
  if (!clientTerminated) {
    const errEv = emit({
      event: 'error',
      payload: {
        code: 'all_providers_failed',
        failureClass: 'unknown' as FailureClass,
        message: 'all providers failed or circuit open',
        retryable: false,
      },
    });
    await pipe(errEv.frame);
    metrics.failureClass = finalError?.failureClass ?? 'unknown';
    clientTerminated = true;
  }

  res.end();
  log.info({ metrics }, 'stream finished');
  return metrics;
}
