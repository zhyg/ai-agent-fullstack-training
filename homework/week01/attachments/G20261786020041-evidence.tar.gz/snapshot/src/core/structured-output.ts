/**
 * Structured output with zod schemas.
 *
 * - Registry maps responseSchemaName → ZodType (raw zod schema).
 * - `repairJson` does minimal local fixes: strip markdown fences, trim trailing commas.
 * - `parseStructured` returns the parsed object or throws with a
 *   StructuredOutputError that carries the zod issue summary — the caller
 *   injects that summary back into the prompt and retries.
 * - Output retries are INDEPENDENT of network-level retries. The caller
 *   loops locally inside a single provider call; only after
 *   `outputRetryMax` exhaustion do we fall through to the provider-level
 *   fallback chain.
 */

import { z, type ZodType } from 'zod';

export class StructuredOutputError extends Error {
  readonly issues: z.ZodIssue[];
  readonly rawText: string;
  constructor(issues: z.ZodIssue[], rawText: string) {
    super(`structured output validation failed: ${issues.length} issue(s)`);
    this.name = 'StructuredOutputError';
    this.issues = issues;
    this.rawText = rawText;
  }
}

export type RegisteredSchema = {
  name: string;
  schema: ZodType;
  jsonSchema: Record<string, unknown>; // static `.schema` call if available
};

export class SchemaRegistry {
  private readonly byName = new Map<string, RegisteredSchema>();

  register(name: string, schema: ZodType): RegisteredSchema {
    const entry: RegisteredSchema = {
      name,
      schema,
      jsonSchema: (schema as unknown as { jsonSchema?: Record<string, unknown> }).jsonSchema ?? {},
    };
    this.byName.set(name, entry);
    return entry;
  }

  resolve(name: string): RegisteredSchema | null {
    return this.byName.get(name) ?? null;
  }
}

/** Strip ```json ... ``` fences and markdown code blocks. */
export function stripMarkdownFence(text: string): string {
  const trimmed = text.trim();
  const fenceMatch = trimmed.match(/^```(?:json|javascript|typescript)?\s*\n?([\s\S]*?)\n?```$/i);
  if (fenceMatch) return fenceMatch[1]!.trim();
  // Sometimes the fence has no opening marker — look for a loose closing.
  const loose = trimmed.match(/\n?```[\s\S]*$/);
  if (loose) return trimmed.slice(0, loose.index).trim();
  return trimmed;
}

/**
 * Minimal local JSON repair. Handles:
 *   - markdown fences (strip)
 *   - trailing commas before `}` / `]`
 *   - single quotes around keys → double quotes (best-effort)
 */
export function repairJson(text: string): string {
  let t = stripMarkdownFence(text);
  // Remove trailing commas before } or ]
  t = t.replace(/,\s*([}\]])/g, '$1');
  return t;
}

/** SafeParse result with original text attached. */
export type ParseResult<T> =
  | { ok: true; data: T; rawText: string }
  | { ok: false; error: StructuredOutputError; rawText: string };

export function parseWithSchema<T>(raw: string, schema: ZodType<T>): ParseResult<T> {
  const repaired = repairJson(raw);
  let obj: unknown;
  try {
    obj = JSON.parse(repaired);
  } catch (e) {
    return {
      ok: false,
      error: new StructuredOutputError([{ code: 'custom', message: `JSON.parse failed: ${(e as Error).message}`, path: [] }], repaired),
      rawText: repaired,
    };
  }
  const res = schema.safeParse(obj);
  if (!res.success) {
    return {
      ok: false,
      error: new StructuredOutputError(res.error.issues, repaired),
      rawText: repaired,
    };
  }
  return { ok: true, data: res.data, rawText: repaired };
}

/** Build a human-readable summary of zod issues to inject into the next prompt. */
export function formatZodSummary(err: StructuredOutputError): string {
  return err.issues
    .map((i) => `${i.path.length ? i.path.join('.') : '<root>'}: ${i.message}`)
    .join('; ');
}

// silence unused
void z;
