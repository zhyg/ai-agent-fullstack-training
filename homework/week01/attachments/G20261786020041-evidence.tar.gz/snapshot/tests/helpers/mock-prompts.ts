/**
 * Mock 数据生成器（测试共享）。
 *
 * 所有默认值都带自增序号，确保不同调用产出的内容不会「恰好相同」，
 * 避免断言因数据碰撞而假通过；需要断言具体内容时用 overrides 覆盖。
 */

import type { PromptRegistry, PromptTemplate } from '../../src/prompt/registry.js';

let mockSeq = 0;

function nextSeq(): number {
  mockSeq += 1;
  return mockSeq;
}

/** 生成一个 mock 模板；默认字段带自增序号，可用 overrides 覆盖 */
export function mockTemplate(overrides: Partial<PromptTemplate> = {}): PromptTemplate {
  const n = nextSeq();
  return {
    system: `mock system #${n}`,
    dataContract: `mock contract #${n}: user messages only`,
    description: `mock template #${n}`,
    ...overrides,
  };
}

/** 生成递增的语义化版本号序列：1.0.0, 1.1.0, 1.2.0 ... */
export function mockVersionLadder(count: number, major = 1, minorStart = 0): string[] {
  return Array.from({ length: count }, (_, i) => `${major}.${minorStart + i}.0`);
}

/**
 * 按给定版本序列注册同一个 promptId，返回 version → system 文本的映射，
 * 便于在断言里核对「某个版本拿到了它自己的内容」。
 */
export function registerLadder(
  reg: PromptRegistry,
  promptId: string,
  versions: string[],
): Map<string, string> {
  const byVersion = new Map<string, string>();
  for (const v of versions) {
    const system = `system for ${promptId}@${v}`;
    reg.register(promptId, v, mockTemplate({ system, description: `${promptId} ${v}` }));
    byVersion.set(v, system);
  }
  return byVersion;
}

/** mulberry32：确定性伪随机，同一 seed 必然产生同一序列 */
export function makeRng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates 洗牌（用传入的确定性随机源，返回新数组） */
export function shuffle<T>(items: T[], rand: () => number): T[] {
  const out = [...items];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}
