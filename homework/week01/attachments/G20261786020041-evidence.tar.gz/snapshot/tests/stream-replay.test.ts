import { describe, it, expect } from 'vitest';
import { StreamReplayBuffer } from '../src/core/stream-replay.js';
import { formatEvent, parseEventId, generateEventId } from '../src/core/sse-format.js';

function mkEvent(
  streamId: string,
  seq: number,
  payload: Record<string, unknown> = { text: 'hi' },
  emittedAt?: number,
): ReturnType<typeof formatEvent> {
  return formatEvent({ streamId, seq, event: 'delta', payload, emittedAt });
}

describe('StreamReplayBuffer', () => {
  const cfg = { maxEvents: 5, ttlMs: 60_000, maxEventSizeBytes: 1_000_000 };

  it('appends events and looks them back up', () => {
    const buf = new StreamReplayBuffer(cfg);
    buf.append('s1', mkEvent('s1', 1));
    buf.append('s1', mkEvent('s1', 2));
    buf.append('s1', mkEvent('s1', 3));

    const res = buf.lookup({ streamId: 's1', lastEventId: generateEventId('s1', 1) });
    expect(res.kind).toBe('ok');
    if (res.kind === 'ok') {
      expect(res.events.length).toBe(2);
      expect(parseEventId(res.events[0]!.id)!.seq).toBe(2);
      expect(parseEventId(res.events[1]!.id)!.seq).toBe(3);
    }
  });

  it('replay_expired for unknown streamId', () => {
    const buf = new StreamReplayBuffer(cfg);
    expect(buf.lookup({ streamId: 'nope', lastEventId: 'nope:1' }).kind).toBe('replay_expired');
  });

  it('replay_expired for malformed lastEventId', () => {
    const buf = new StreamReplayBuffer(cfg);
    buf.append('s1', mkEvent('s1', 1));
    expect(buf.lookup({ streamId: 's1', lastEventId: 'garbage' }).kind).toBe('replay_expired');
    expect(buf.lookup({ streamId: 's1', lastEventId: 's1:0' }).kind).toBe('replay_expired'); // seq must be positive
  });

  it('replay_expired for cross-stream lastEventId', () => {
    const buf = new StreamReplayBuffer(cfg);
    buf.append('s1', mkEvent('s1', 1));
    expect(buf.lookup({ streamId: 's1', lastEventId: 's2:1' }).kind).toBe('replay_expired');
  });

  it('replay_gap when lastEventId.seq < headSeq (evicted by maxEvents)', () => {
    const buf = new StreamReplayBuffer({ ...cfg, maxEvents: 3 });
    buf.append('s1', mkEvent('s1', 1));
    buf.append('s1', mkEvent('s1', 2));
    buf.append('s1', mkEvent('s1', 3));
    buf.append('s1', mkEvent('s1', 4)); // evicts seq 1
    buf.append('s1', mkEvent('s1', 5)); // evicts seq 2
    // Now headSeq should be 3.
    const res = buf.lookup({ streamId: 's1', lastEventId: generateEventId('s1', 2) });
    expect(res.kind).toBe('replay_gap');
    if (res.kind === 'replay_gap') {
      expect(res.earliestAvailableEventId).toBe(generateEventId('s1', 3));
    }
  });

  it('replay_gap when lastEventId.seq < headSeq (evicted by TTL)', () => {
    const buf = new StreamReplayBuffer({ ...cfg, ttlMs: 100 });
    const now = Date.now();
    // Append at "now".
    buf.append('s1', mkEvent('s1', 1, { text: 'hi' }, now), now);
    buf.append('s1', mkEvent('s1', 2, { text: 'hi' }, now), now);
    // Append a newer event 200ms from now — this should evict seq 1 & 2.
    buf.append('s1', mkEvent('s1', 3, { text: 'hi' }, now + 200), now + 200);
    const res = buf.lookup({ streamId: 's1', lastEventId: generateEventId('s1', 1), now: now + 200 });
    expect(res.kind).toBe('replay_gap');
  });

  it('TTL eviction of every buffered event terminates and leaves a gap (no headSeq runaway)', () => {
    const buf = new StreamReplayBuffer({ ...cfg, ttlMs: 100 });
    const now = Date.now();
    buf.append('s1', mkEvent('s1', 1, { text: 'hi' }, now), now);
    buf.append('s1', mkEvent('s1', 2, { text: 'hi' }, now), now);
    // Every stored event is now stale; the eviction walk must stop at tailSeq
    // instead of incrementing headSeq forever.
    buf.expireAll(now + 500);
    expect(buf.hasStream('s1')).toBe(false);
    expect(buf.lookup({ streamId: 's1', lastEventId: 's1:1', now: now + 500 }).kind).toBe('replay_expired');
  });

  it('headSeq stops at tailSeq: sparse append after TTL eviction stays replayable', () => {
    const buf = new StreamReplayBuffer({ ...cfg, ttlMs: 100 });
    const now = Date.now();
    // seq 1 expires, then seq 3 is appended 200ms later. The eviction walk ends
    // when headSeq reaches tailSeq (1) — i.e. at seq 2, which was never written.
    buf.append('s1', mkEvent('s1', 1, { text: 'hi' }, now), now);
    buf.append('s1', mkEvent('s1', 3, { text: 'hi2' }, now + 200), now + 200);

    // Replay from the (now evicted) seq 1 → gap, earliest available is seq 3.
    const gap = buf.lookup({ streamId: 's1', lastEventId: 's1:1', now: now + 200 });
    expect(gap.kind).toBe('replay_gap');
    if (gap.kind === 'replay_gap') {
      expect(gap.earliestAvailableEventId).toBe(generateEventId('s1', 3));
    }

    // A checkpoint on the never-written slot (seq 2) is also a gap — and it must
    // advertise seq 3, not the phantom seq 2 that the eviction pointer landed on.
    const gapFromHole = buf.lookup({ streamId: 's1', lastEventId: 's1:2', now: now + 200 });
    expect(gapFromHole.kind).toBe('replay_gap');
    if (gapFromHole.kind === 'replay_gap') {
      expect(gapFromHole.earliestAvailableEventId).toBe(generateEventId('s1', 3));
    }

    // The buffer keeps working: appending seq 4 and replaying from the real seq 3.
    buf.append('s1', mkEvent('s1', 4, { text: 'hi3' }, now + 200), now + 200);
    const res = buf.lookup({ streamId: 's1', lastEventId: 's1:3', now: now + 200 });
    expect(res.kind).toBe('ok');
    if (res.kind === 'ok') {
      expect(res.events.map((e) => parseEventId(e.id)!.seq)).toEqual([4]);
    }
  });

  it('capacity eviction over sparse seqs terminates and keeps the newest events', () => {
    // maxEvents=1 forces eviction on every append; seqs 2 and 4 are never written,
    // so the eviction pointer must skip missing slots without spinning.
    const buf = new StreamReplayBuffer({ ...cfg, maxEvents: 1 });
    buf.append('s1', mkEvent('s1', 1));
    buf.append('s1', mkEvent('s1', 3));
    buf.append('s1', mkEvent('s1', 5));

    // Only the newest event survives.
    expect(buf.streamCount()).toBe(1);

    // Checkpoint on the phantom seq 4 → gap pointing at the real seq 5.
    const gap = buf.lookup({ streamId: 's1', lastEventId: 's1:4' });
    expect(gap.kind).toBe('replay_gap');
    if (gap.kind === 'replay_gap') {
      expect(gap.earliestAvailableEventId).toBe(generateEventId('s1', 5));
    }

    // Checkpoint on an evicted seq → gap as well.
    expect(buf.lookup({ streamId: 's1', lastEventId: 's1:1' }).kind).toBe('replay_gap');

    // The surviving event is the head: replaying from it yields an empty tail.
    const res = buf.lookup({ streamId: 's1', lastEventId: 's1:5' });
    expect(res.kind).toBe('ok');
  });

  it('doneEvent is dropped once its own TTL expires', () => {
    const buf = new StreamReplayBuffer({ ...cfg, ttlMs: 100 });
    const now = Date.now();
    buf.append('s1', mkEvent('s1', 1, { text: 'hi' }, now), now);
    // Fresh event keeps the bucket alive so we can observe the cached done event.
    buf.append('s1', mkEvent('s1', 2, { text: 'hi2' }, now + 200), now + 200);
    buf.append(
      's1',
      formatEvent({ streamId: 's1', seq: 3, event: 'done', payload: { ttftMs: 1, genMs: 2, e2eMs: 3, replayUsed: false }, emittedAt: now }),
      now,
    );

    // Within TTL the done event is still replayed.
    const before = buf.lookup({ streamId: 's1', lastEventId: 's1:2', now });
    expect(before.kind).toBe('ok');
    if (before.kind === 'ok') {
      expect(before.doneEvent).not.toBeNull();
      expect(before.doneEvent!.id).toBe('s1:3');
    }

    // 200ms later the done event itself is stale → cleared, while seq 2 survives.
    const after = buf.lookup({ streamId: 's1', lastEventId: 's1:2', now: now + 200 });
    expect(after.kind).toBe('ok');
    if (after.kind === 'ok') {
      expect(after.doneEvent).toBeNull();
    }
  });

  it('evicts expired streams independently (one stream expiry does not affect another)', () => {
    const buf = new StreamReplayBuffer({ ...cfg, ttlMs: 100 });
    const now = Date.now();
    buf.append('s1', mkEvent('s1', 1, { text: 'old' }, now), now);
    buf.append('s2', mkEvent('s2', 1, { text: 'fresh' }, now + 200), now + 200);
    buf.append('s2', mkEvent('s2', 2, { text: 'fresh2' }, now + 200), now + 200);

    // Only s1's single event is older than the TTL.
    buf.expireAll(now + 200);

    expect(buf.hasStream('s1')).toBe(false);
    expect(buf.hasStream('s2')).toBe(true);
    expect(buf.streamCount()).toBe(1);

    expect(buf.lookup({ streamId: 's1', lastEventId: 's1:1', now: now + 200 }).kind).toBe('replay_expired');
    const s2 = buf.lookup({ streamId: 's2', lastEventId: 's2:1', now: now + 200 });
    expect(s2.kind).toBe('ok');
    if (s2.kind === 'ok') {
      expect(s2.events.map((e) => parseEventId(e.id)!.seq)).toEqual([2]);
    }
  });

  it('returns doneEvent if stream ended', () => {
    const buf = new StreamReplayBuffer(cfg);
    buf.append('s1', mkEvent('s1', 1));
    const done = formatEvent({ streamId: 's1', seq: 2, event: 'done', payload: { ttftMs: 10, genMs: 20, e2eMs: 30, replayUsed: false } });
    buf.append('s1', done);
    const res = buf.lookup({ streamId: 's1', lastEventId: generateEventId('s1', 1) });
    expect(res.kind).toBe('ok');
    if (res.kind === 'ok') {
      expect(res.doneEvent).not.toBeNull();
      expect(res.doneEvent!.id).toBe(generateEventId('s1', 2));
    }
  });

  it('hasStream / streamCount / clear', () => {
    const buf = new StreamReplayBuffer(cfg);
    expect(buf.hasStream('s1')).toBe(false);
    expect(buf.streamCount()).toBe(0);
    buf.append('s1', mkEvent('s1', 1));
    expect(buf.hasStream('s1')).toBe(true);
    expect(buf.streamCount()).toBe(1);
    buf.clear();
    expect(buf.hasStream('s1')).toBe(false);
    expect(buf.streamCount()).toBe(0);
  });

  it('drops events larger than maxEventSizeBytes (and creates no bucket)', () => {
    const buf = new StreamReplayBuffer({ ...cfg, maxEventSizeBytes: 64 });
    buf.append('s1', mkEvent('s1', 1, { text: 'ok' }));
    buf.append('s1', mkEvent('s1', 2, { text: 'x'.repeat(200) }));

    const res = buf.lookup({ streamId: 's1', lastEventId: 's1:1' });
    expect(res.kind).toBe('ok');
    if (res.kind === 'ok') {
      expect(res.events).toHaveLength(0);
    }

    // An oversized FIRST event must not even allocate a bucket.
    const fresh = new StreamReplayBuffer({ ...cfg, maxEventSizeBytes: 64 });
    fresh.append('s9', mkEvent('s9', 1, { text: 'x'.repeat(200) }));
    expect(fresh.streamCount()).toBe(0);
  });

  it('oversized done event is refused too', () => {
    const buf = new StreamReplayBuffer({ ...cfg, maxEventSizeBytes: 64 });
    buf.append('s1', mkEvent('s1', 1));
    buf.append(
      's1',
      formatEvent({ streamId: 's1', seq: 2, event: 'done', payload: { padding: 'x'.repeat(200) } }),
    );
    const res = buf.lookup({ streamId: 's1', lastEventId: 's1:1' });
    expect(res.kind).toBe('ok');
    if (res.kind === 'ok') {
      expect(res.doneEvent).toBeNull();
    }
  });

  it('lookup from seq=0 still works (plays all events)', () => {
    const buf = new StreamReplayBuffer(cfg);
    buf.append('s1', mkEvent('s1', 1));
    buf.append('s1', mkEvent('s1', 2));
    // seq=0 is malformed → replay_expired. So test seq=0 properly fails.
    expect(buf.lookup({ streamId: 's1', lastEventId: 's1:0' }).kind).toBe('replay_expired');
    // To replay everything the client should pass lastEventId that's before
    // the first event. Since our seq starts at 1, a seq=0 id would be too old.
    // Real clients typically don't do this.
  });

  it('append silently ignores malformed event ids (no seq, no storage)', () => {
    const buf = new StreamReplayBuffer(cfg);
    buf.append('s1', mkEvent('s1', 1));
    buf.append('s1', { ...mkEvent('s1', 2), id: 'not-an-event-id' });

    expect(buf.hasStream('s1')).toBe(true);
    expect(buf.streamCount()).toBe(1);

    const res = buf.lookup({ streamId: 's1', lastEventId: 's1:1' });
    expect(res.kind).toBe('ok');
    if (res.kind === 'ok') {
      expect(res.events).toHaveLength(0);
    }
  });

  it('startPeriodicCleanup is idempotent, evicts on tick, and stop() halts it', () => {
    vi.useFakeTimers();
    try {
      vi.setSystemTime(1000);
      const buf = new StreamReplayBuffer({ ...cfg, ttlMs: 100 });
      buf.append('s1', mkEvent('s1', 1, { text: 'old' }, 1000), 1000);

      // Calling twice must not register a second interval.
      buf.startPeriodicCleanup();
      buf.startPeriodicCleanup();

      vi.advanceTimersByTime(30_000);
      expect(buf.hasStream('s1')).toBe(false);
      expect(buf.streamCount()).toBe(0);

      buf.stop();
      buf.append('s2', mkEvent('s2', 1, { text: 'kept' }, 31_000), 31_000);
      vi.advanceTimersByTime(60_000);
      // Timer is stopped → the now-expired s2 must still be present.
      expect(buf.hasStream('s2')).toBe(true);
    } finally {
      vi.useRealTimers();
    }
  });
});
