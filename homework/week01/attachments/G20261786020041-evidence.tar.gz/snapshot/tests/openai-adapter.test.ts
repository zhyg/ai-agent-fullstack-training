/**
 * OpenAI-compatible adapter tests — run against a local stub server so no
 * real API key or network access is required.
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createServer, type Server } from 'node:http';
import { AddressInfo } from 'node:net';
import { OpenAICompatibleAdapter } from '../src/adapters/openai-compatible.js';
import { AdapterError } from '../src/adapters/adapter-error.js';
import type { AdapterRequest, UnifiedStreamEvent } from '../src/adapters/types.js';

type Captured = { url: string; auth?: string; body: Record<string, unknown> };

let server: Server;
let baseUrl = '';
let captured: Captured[] = [];
let respond: (req: Captured, res: import('node:http').ServerResponse) => void;

beforeEach(async () => {
  captured = [];
  server = createServer((req, res) => {
    let raw = '';
    req.on('data', (d) => (raw += d));
    req.on('end', () => {
      const entry: Captured = {
        url: req.url ?? '',
        auth: req.headers.authorization as string | undefined,
        body: raw ? (JSON.parse(raw) as Record<string, unknown>) : {},
      };
      captured.push(entry);
      respond(entry, res);
    });
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

afterEach(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
});

function makeAdapter(apiKey = 'sk-test') {
  return new OpenAICompatibleAdapter({
    providerName: 'openai',
    baseUrl,
    defaultModel: 'test-model',
    apiKey,
  });
}

function req(overrides: Partial<AdapterRequest> = {}): AdapterRequest {
  return {
    model: 'any',
    messages: [{ role: 'user', content: 'hi' }],
    stream: false,
    providerName: 'openai',
    ...overrides,
  };
}

const ctx = { requestId: 'r1', streamId: 'r1' };

describe('OpenAICompatibleAdapter', () => {
  it('non-stream: maps text, usage and sends the configured model for model="any"', async () => {
    respond = (_req, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          choices: [{ message: { content: 'hello' } }],
          usage: { prompt_tokens: 3, completion_tokens: 2, total_tokens: 5 },
        }),
      );
    };

    const out = await makeAdapter().chat(req(), new AbortController().signal, ctx);

    expect(out.text).toBe('hello');
    expect(out.usage).toEqual({ promptTokens: 3, completionTokens: 2, totalTokens: 5 });
    expect(captured[0]!.url).toBe('/chat/completions');
    expect(captured[0]!.auth).toBe('Bearer sk-test');
    expect(captured[0]!.body.model).toBe('test-model');
    expect(captured[0]!.body.stream).toBe(false);
  });

  it('non-stream: 401 becomes a permanent auth AdapterError', async () => {
    respond = (_req, res) => {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'invalid api key' } }));
    };

    const err = await makeAdapter('sk-bad')
      .chat(req(), new AbortController().signal, ctx)
      .catch((e: unknown) => e);

    expect(err).toBeInstanceOf(AdapterError);
    const ae = err as AdapterError;
    expect(ae.failureClass).toBe('auth');
    expect(ae.isPermanentSkip).toBe(true);
    expect(ae.retryable).toBe(false);
    expect(ae.statusCode).toBe(401);
    expect(ae.message).toBe('invalid api key');
  });

  it('stream: parses deltas, usage and [DONE]', async () => {
    respond = (_req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {"choices":[{"delta":{"content":"hel"}}]}\n\n');
      res.write('data: {"choices":[{"delta":{"content":"lo"}}]}\n\n');
      res.write('data: {"choices":[{"delta":{}}],"usage":{"prompt_tokens":1,"completion_tokens":2,"total_tokens":3}}\n\n');
      res.write('data: [DONE]\n\n');
      res.end();
    };

    const events: UnifiedStreamEvent[] = [];
    for await (const ev of makeAdapter().chatStream(req({ stream: true }), new AbortController().signal, ctx)) {
      events.push(ev);
    }

    expect(events.filter((e) => e.type === 'delta').map((e) => (e as { text: string }).text)).toEqual(['hel', 'lo']);
    const usage = events.find((e) => e.type === 'usage');
    expect(usage).toMatchObject({ usage: { promptTokens: 1, completionTokens: 2, totalTokens: 3 } });
    expect(events[events.length - 1]!.type).toBe('done');
    expect(captured[0]!.body.stream).toBe(true);
    expect(captured[0]!.body.stream_options).toEqual({ include_usage: true });
  });

  it('stream: 503 yields exactly one error event and no done', async () => {
    respond = (_req, res) => {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'upstream busy' } }));
    };

    const events: UnifiedStreamEvent[] = [];
    for await (const ev of makeAdapter().chatStream(req({ stream: true }), new AbortController().signal, ctx)) {
      events.push(ev);
    }

    expect(events).toHaveLength(1);
    expect(events[0]).toMatchObject({ type: 'error', failureClass: 'unavailable', retryable: true, statusCode: 503 });
    expect(events.some((e) => e.type === 'done')).toBe(false);
  });

  it('stream: in-band error chunk is surfaced as an error event', async () => {
    respond = (_req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {"error":{"message":"content filtered"}}\n\n');
      res.end();
    };

    const events: UnifiedStreamEvent[] = [];
    for await (const ev of makeAdapter().chatStream(req({ stream: true }), new AbortController().signal, ctx)) {
      events.push(ev);
    }

    expect(events).toHaveLength(1);
    expect(events[0]).toMatchObject({ type: 'error', message: 'content filtered' });
  });

  it('explicit model overrides the default', async () => {
    respond = (_req, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { content: 'ok' } }] }));
    };

    await makeAdapter().chat(req({ model: 'gpt-4o' }), new AbortController().signal, ctx);

    expect(captured[0]!.body.model).toBe('gpt-4o');
  });
});
