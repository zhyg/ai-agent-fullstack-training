import { describe, it, expect } from 'vitest';
import { withFallback, AllProvidersFailedError, type ProviderRegistry } from '../src/core/fallback.js';
import { CircuitBreaker } from '../src/core/circuit-breaker.js';
import { AdapterError } from '../src/adapters/adapter-error.js';
import { __resetMockCounters, MockAdapter } from '../src/adapters/mock.js';
import type { ProviderOrderConfig, RetryConfig } from '../src/config.js';

const retryCfg: RetryConfig = { maxAttempts: 1, baseDelayMs: 1, maxDelayMs: 10 };

describe('fallback', () => {
  beforeEach(() => __resetMockCounters());

  function makeProviders(): { registry: ProviderRegistry; adapters: Map<string, MockAdapter> } {
    const primary = new MockAdapter('mock', { simulatedText: 'primary-win' });
    const fallback = new MockAdapter('mock-fallback', { simulatedText: 'fallback-win' });
    const registry: ProviderRegistry = new Map([
      ['mock', { name: 'mock' }],
      ['mock-fallback', { name: 'mock-fallback' }],
    ]);
    return { registry, adapters: new Map([['mock', primary], ['mock-fallback', fallback]]) };
  }

  const order: ProviderOrderConfig = { primary: 'mock', fallback: 'mock-fallback' };

  it('primary succeeds without fallback', async () => {
    const { registry, adapters } = makeProviders();
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    const fb = await withFallback(
      (key) => adapters.get(key)!.chat({ model: 'x', messages: [], stream: false, providerName: key }, new AbortController().signal, { requestId: 'r', streamId: 'r' }),
      registry, order, cb, retryCfg, { requestId: 'r' },
    );
    expect(fb.usedProvider).toBe('mock');
    expect(fb.fallbackUsed).toBe(false);
    expect(fb.result.text).toBe('primary-win');
  });

  it('primary unavailable → fallback succeeds', async () => {
    const primary = new MockAdapter('mock', { alwaysFailClass: 'unavailable' });
    const fallback = new MockAdapter('mock-fallback', { simulatedText: 'fb-ok' });
    const registry: ProviderRegistry = new Map([
      ['mock', { name: 'mock' }],
      ['mock-fallback', { name: 'mock-fallback' }],
    ]);
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    const fb = await withFallback(
      (key) => {
        const adapter = key === 'mock' ? primary : fallback;
        return adapter.chat({ model: 'x', messages: [], stream: false, providerName: key }, new AbortController().signal, { requestId: 'r', streamId: 'r' });
      },
      registry, order, cb, retryCfg, { requestId: 'r' },
    );
    expect(fb.usedProvider).toBe('mock-fallback');
    expect(fb.fallbackUsed).toBe(true);
    expect(fb.result.text).toBe('fb-ok');
  });

  it('both fail → AllProvidersFailedError', async () => {
    const primary = new MockAdapter('mock', { alwaysFailClass: 'unavailable' });
    const fallback = new MockAdapter('mock-fallback', { alwaysFailClass: 'rate_limited' });
    const registry: ProviderRegistry = new Map([
      ['mock', { name: 'mock' }],
      ['mock-fallback', { name: 'mock-fallback' }],
    ]);
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    await expect(
      withFallback(
        (key) => {
          const adapter = key === 'mock' ? primary : fallback;
          return adapter.chat({ model: 'x', messages: [], stream: false, providerName: key }, new AbortController().signal, { requestId: 'r', streamId: 'r' });
        },
        registry, order, cb, retryCfg, { requestId: 'r' },
      ),
    ).rejects.toBeInstanceOf(AllProvidersFailedError);
  });

  it('primary permanent (auth) → fallback still tried', async () => {
    const primary = new MockAdapter('mock', { alwaysFailClass: 'auth' });
    const fallback = new MockAdapter('mock-fallback', { simulatedText: 'fb-ok' });
    const registry: ProviderRegistry = new Map([
      ['mock', { name: 'mock' }],
      ['mock-fallback', { name: 'mock-fallback' }],
    ]);
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    const fb = await withFallback(
      (key) => {
        const adapter = key === 'mock' ? primary : fallback;
        return adapter.chat({ model: 'x', messages: [], stream: false, providerName: key }, new AbortController().signal, { requestId: 'r', streamId: 'r' });
      },
      registry, order, cb, retryCfg, { requestId: 'r' },
    );
    expect(fb.usedProvider).toBe('mock-fallback');
    expect(fb.fallbackUsed).toBe(true);
    // And circuit breaker should have permanently skipped primary.
    expect(cb.getState('mock').permanentSkipUntil).toBeGreaterThan(Date.now());
  });

  it('circuit breaker OPEN skips provider immediately', async () => {
    const primary = new MockAdapter('mock');
    const fallback = new MockAdapter('mock-fallback', { simulatedText: 'fb-won' });
    const registry: ProviderRegistry = new Map([
      ['mock', { name: 'mock' }],
      ['mock-fallback', { name: 'mock-fallback' }],
    ]);
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    // Force primary OPEN with permanent skip.
    cb.recordFailure('mock', 'auth');
    const fb = await withFallback(
      (key) => {
        const adapter = key === 'mock' ? primary : fallback;
        return adapter.chat({ model: 'x', messages: [], stream: false, providerName: key }, new AbortController().signal, { requestId: 'r', streamId: 'r' });
      },
      registry, order, cb, retryCfg, { requestId: 'r' },
    );
    expect(fb.usedProvider).toBe('mock-fallback');
  });

  it('attempt records capture failure classes', async () => {
    const primary = new MockAdapter('mock', { alwaysFailClass: 'unavailable' });
    const fallback = new MockAdapter('mock-fallback');
    const registry: ProviderRegistry = new Map([
      ['mock', { name: 'mock' }],
      ['mock-fallback', { name: 'mock-fallback' }],
    ]);
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    const fb = await withFallback(
      (key) => {
        const adapter = key === 'mock' ? primary : fallback;
        return adapter.chat({ model: 'x', messages: [], stream: false, providerName: key }, new AbortController().signal, { requestId: 'r', streamId: 'r' });
      },
      registry, order, cb, retryCfg, { requestId: 'r' },
    );
    expect(fb.attempts[0]?.failureClass).toBe('unavailable');
    expect(fb.attempts[1]?.success).toBe(true);
  });

  // silence
  void AdapterError;
});
