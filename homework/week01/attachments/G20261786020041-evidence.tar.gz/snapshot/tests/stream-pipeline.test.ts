/**
 * Stream pipeline termination tests.
 *
 * These cover the two failure modes that used to leave the client with no
 * terminal frame:
 *   1. The inactivity watchdog only logged a warning and never closed the
 *      stream (a hung provider kept the connection open forever).
 *   2. Every provider failed pre-delta and the fallback was unavailable
 *      (unregistered / circuit-open), so the stream ended right after `meta`.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { EventEmitter } from 'node:events';
import type { ServerResponse } from 'node:http';
import { runStreamPipeline } from '../src/core/stream.js';
import { StreamReplayBuffer } from '../src/core/stream-replay.js';
import { CircuitBreaker } from '../src/core/circuit-breaker.js';
import { MockAdapter, __resetMockCounters } from '../src/adapters/mock.js';
import { parseSSEBlocks } from '../src/core/sse-format.js';
import { testConfig } from '../src/config.js';
import type { LLMAdapter, UnifiedStreamEvent } from '../src/adapters/types.js';

type FakeRes = ServerResponse & { written: Buffer[]; headers: Record<string, string> };

function makeFakeRes(): FakeRes {
  const res = new EventEmitter() as unknown as FakeRes;
  const raw = res as unknown as Record<string, unknown>;
  raw.written = [];
  raw.headers = {};
  raw.statusCode = 200;
  Object.defineProperty(res, 'writableEnded', { value: false, writable: true });
  raw.setHeader = (name: string, value: string) => {
    (raw.headers as Record<string, string>)[name.toLowerCase()] = value;
  };
  raw.write = (chunk: Buffer) => {
    (raw.written as Buffer[]).push(chunk);
    return true;
  };
  raw.end = () => {
    raw.writableEnded = true;
  };
  return res;
}

type ParsedEvent = { kind: 'event'; id?: string; event?: string; payload: Record<string, unknown> };

function eventsOf(res: FakeRes): ParsedEvent[] {
  return parseSSEBlocks(Buffer.concat(res.written)).filter(
    (p): p is ParsedEvent => p.kind === 'event',
  );
}

const baseConfig = testConfig();

function runPipeline(
  adapters: Map<string, LLMAdapter>,
  registry: Map<string, { name: string }>,
  order: { primary: string; fallback?: string },
  cb: CircuitBreaker,
  watchdogMs: number,
) {
  const res = makeFakeRes();
  const replayBuffer = new StreamReplayBuffer(baseConfig.replay);
  const done = runStreamPipeline({
    res,
    requestId: 'r1',
    streamId: 'r1',
    messages: [{ role: 'user', content: 'hi' }],
    model: 'any',
    providerRegistry: registry,
    providerOrder: order,
    adapters,
    circuitBreaker: cb,
    sseCfg: { keepaliveIntervalMs: 30_000, inactivityWatchdogMs: watchdogMs },
    replayCfg: baseConfig.replay,
    replayBuffer,
  });
  return { res, done };
}

describe('stream pipeline termination', () => {
  beforeEach(() => __resetMockCounters());

  it('watchdog closes a hung provider instead of waiting forever', async () => {
    // A provider that never yields and ignores the abort signal.
    const hung: LLMAdapter = {
      providerName: 'hung',
      async chat() {
        throw new Error('not used');
      },
      chatStream(): AsyncGenerator<UnifiedStreamEvent> {
        return (async function* () {
          await new Promise(() => {});
          yield { type: 'delta', text: 'unreachable' };
        })();
      },
    };

    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    const { res, done } = runPipeline(
      new Map([['hung', hung]]),
      new Map([['hung', { name: 'hung' }]]),
      { primary: 'hung' },
      cb,
      40,
    );

    const metrics = await done;

    expect(res.writableEnded).toBe(true);
    const err = eventsOf(res).find((e) => e.event === 'error');
    expect(err).toBeTruthy();
    expect(err!.payload.code).toBe('timeout');
    expect(metrics.failureClass).toBe('timeout');
  });

  it('emits all_providers_failed when primary fails pre-delta and fallback is unregistered', async () => {
    const primary = new MockAdapter('mock', { preFirstDeltaFailures: 1 });
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });

    const { res, done } = runPipeline(
      new Map([['mock', primary]]),
      new Map([['mock', { name: 'mock' }]]),
      { primary: 'mock', fallback: 'not-registered' },
      cb,
      5_000,
    );

    await done;

    expect(res.writableEnded).toBe(true);
    const events = eventsOf(res);
    expect(events.some((e) => e.event === 'meta')).toBe(true);
    const err = events.find((e) => e.event === 'error');
    expect(err).toBeTruthy();
    expect(err!.payload.code).toBe('all_providers_failed');
  });

  it('emits all_providers_failed when primary fails pre-delta and fallback circuit is open', async () => {
    const primary = new MockAdapter('mock', { preFirstDeltaFailures: 1 });
    const fallback = new MockAdapter('mock-fallback');
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });
    // Permanent skip → tryAcquire refuses without a probe.
    cb.recordFailure('mock-fallback', 'auth');

    const { res, done } = runPipeline(
      new Map<string, LLMAdapter>([['mock', primary], ['mock-fallback', fallback]]),
      new Map([['mock', { name: 'mock' }], ['mock-fallback', { name: 'mock-fallback' }]]),
      { primary: 'mock', fallback: 'mock-fallback' },
      cb,
      5_000,
    );

    await done;

    expect(res.writableEnded).toBe(true);
    const err = eventsOf(res).find((e) => e.event === 'error');
    expect(err).toBeTruthy();
    expect(err!.payload.code).toBe('all_providers_failed');
  });

  it('switches provider transparently: meta once, then provider_switched', async () => {
    const primary = new MockAdapter('mock', { preFirstDeltaFailures: 1 });
    const fallback = new MockAdapter('mock-fallback', { simulatedText: 'hello' });
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });

    const { res, done } = runPipeline(
      new Map<string, LLMAdapter>([['mock', primary], ['mock-fallback', fallback]]),
      new Map([['mock', { name: 'mock' }], ['mock-fallback', { name: 'mock-fallback' }]]),
      { primary: 'mock', fallback: 'mock-fallback' },
      cb,
      5_000,
    );

    const metrics = await done;
    const events = eventsOf(res);

    // `meta` must appear exactly once, even across a provider switch.
    expect(events.filter((e) => e.event === 'meta')).toHaveLength(1);

    const sw = events.find((e) => e.event === 'provider_switched');
    expect(sw).toBeTruthy();
    expect(sw!.payload).toMatchObject({ from: 'mock', to: 'mock-fallback', reason: 'unavailable' });
    expect(sw!.payload._seq).toBe(2);

    const text = events
      .filter((e) => e.event === 'delta')
      .map((e) => (e.payload as { text: string }).text)
      .join('');
    expect(text).toBe('hello');
    expect(events[events.length - 1]!.event).toBe('done');
    expect(metrics.fallbackUsed).toBe(true);
    expect(metrics.provider).toBe('mock-fallback');
  });

  it('healthy stream still terminates with done', async () => {
    const primary = new MockAdapter('mock', { simulatedText: 'ok' });
    const cb = new CircuitBreaker({ failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 86_400_000 });

    const { res, done } = runPipeline(
      new Map([['mock', primary]]),
      new Map([['mock', { name: 'mock' }]]),
      { primary: 'mock' },
      cb,
      5_000,
    );

    const metrics = await done;
    expect(res.writableEnded).toBe(true);
    const events = eventsOf(res);
    expect(events[events.length - 1]!.event).toBe('done');
    expect(metrics.failureClass).toBeUndefined();
  });
});
