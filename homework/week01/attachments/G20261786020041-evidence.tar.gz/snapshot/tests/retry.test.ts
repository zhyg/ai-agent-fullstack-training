import { describe, it, expect, vi } from 'vitest';
import { withRetry, computeDelay, fullJitter, RetryAbortedError } from '../src/core/retry.js';
import { AdapterError } from '../src/adapters/adapter-error.js';
import type { RetryConfig } from '../src/config.js';

const cfg: RetryConfig = { maxAttempts: 2, baseDelayMs: 10, maxDelayMs: 100 };

describe('retry', () => {
  it('succeeds on first attempt', async () => {
    let calls = 0;
    const result = await withRetry(async () => {
      calls += 1;
      return 42;
    }, cfg, { provider: 'p' });
    expect(result.result).toBe(42);
    expect(calls).toBe(1);
    expect(result.attempts.length).toBe(1);
  });

  it('retries retryable errors up to maxAttempts', async () => {
    let calls = 0;
    const result = await withRetry(async () => {
      calls += 1;
      if (calls < cfg.maxAttempts) throw new AdapterError({
        failureClass: 'unavailable', message: 'down', retryable: true, tripsCircuit: true, statusCode: 503,
      });
      return 'ok';
    }, cfg, { provider: 'p' });
    expect(calls).toBe(cfg.maxAttempts);
    expect(result.result).toBe('ok');
  });

  it('non-retryable error stops immediately', async () => {
    let calls = 0;
    await expect(
      withRetry(async () => {
        calls += 1;
        throw new AdapterError({
          failureClass: 'auth', message: 'nope', retryable: false, tripsCircuit: true, isPermanentSkip: true, statusCode: 401,
        });
      }, cfg, { provider: 'p' }),
    ).rejects.toMatchObject({ failureClass: 'auth' });
    expect(calls).toBe(1);
  });

  it('retries exhausted throws last error', async () => {
    await expect(
      withRetry(async () => {
        throw new AdapterError({
          failureClass: 'rate_limited', message: 'slow', retryable: true, tripsCircuit: true, statusCode: 429,
        });
      }, cfg, { provider: 'p' }),
    ).rejects.toMatchObject({ failureClass: 'rate_limited' });
  });

  it('AbortSignal cancels retries', async () => {
    let calls = 0;
    const ac = new AbortController();
    // Abort before starting, should throw immediately.
    ac.abort();
    await expect(
      withRetry(async () => { calls += 1; return 1; }, cfg, { provider: 'p' }, ac.signal),
    ).rejects.toBeInstanceOf(RetryAbortedError);
  });

  it('computeDelay respects jitter bounds', () => {
    const c: RetryConfig = { maxAttempts: 5, baseDelayMs: 100, maxDelayMs: 10000 };
    for (let attempt = 1; attempt <= 10; attempt++) {
      const d = computeDelay(attempt, c);
      if (attempt === 1) expect(d).toBe(0);
      else expect(d).toBeGreaterThanOrEqual(0);
      // Upper bound is baseDelayMs * 2^(attempt-2), capped at maxDelayMs, then jitter → [0, cap]
      const cap = Math.min(c.baseDelayMs * Math.pow(2, attempt - 2), c.maxDelayMs);
      expect(d).toBeLessThanOrEqual(cap);
    }
  });

  it('fullJitter is deterministic with given RNG', () => {
    const rng = vi.fn(() => 0.5);
    expect(fullJitter(100, rng)).toBe(50);
    expect(fullJitter(0, rng)).toBe(0);
  });

  it('onFailure called for every failure including last', async () => {
    const failures: { attempt: number }[] = [];
    await expect(
      withRetry(async () => {
        throw new AdapterError({
          failureClass: 'timeout', message: 't', retryable: true, tripsCircuit: true, statusCode: 408,
        });
      }, cfg, { provider: 'p' }, undefined, (attempt) => failures.push({ attempt })),
    ).rejects.toBeTruthy();
    expect(failures.map((f) => f.attempt)).toEqual([1, 2]);
  });
});
