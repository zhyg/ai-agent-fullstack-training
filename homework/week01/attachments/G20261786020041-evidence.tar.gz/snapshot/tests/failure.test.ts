import { describe, it, expect } from 'vitest';
import {
  classifyStatusCode,
  classifyError,
  isRetryable,
  tripsCircuit,
  isPermanent,
  buildAdapterErrorFromStatus,
  type FailureClass,
} from '../src/core/failure.js';
import { AdapterError } from '../src/adapters/adapter-error.js';

describe('failure classification', () => {
  const table: Array<[number | undefined, FailureClass]> = [
    [401, 'auth'],
    [402, 'payment'],
    [404, 'model_not_found'],
    [408, 'timeout'],
    [429, 'rate_limited'],
    [500, 'unavailable'],
    [502, 'unavailable'],
    [503, 'unavailable'],
    [504, 'unavailable'],
    [400, 'unknown'],
    [undefined, 'unknown'],
    [0, 'unknown'],
  ];

  it.each(table)('status %s → class %s', (status, expected) => {
    expect(classifyStatusCode(status)).toBe(expected);
  });

  it('classifyError: AdapterError → its failureClass', () => {
    const err = new AdapterError({
      failureClass: 'rate_limited', message: 'nope', retryable: true, tripsCircuit: true, statusCode: 429,
    });
    expect(classifyError(err)).toBe('rate_limited');
  });

  it('classifyError: AbortError → timeout', () => {
    const abortErr = new Error('aborted');
    abortErr.name = 'AbortError';
    expect(classifyError(abortErr)).toBe('timeout');
  });

  it('classifyError: generic Error → unknown', () => {
    expect(classifyError(new Error('boom'))).toBe('unknown');
  });

  describe('isRetryable', () => {
    it.each<[FailureClass, boolean]>([
      ['rate_limited', true],
      ['timeout', true],
      ['unavailable', true],
      ['auth', false],
      ['payment', false],
      ['model_not_found', false],
      ['unknown', false],
    ])('%s → %s', (cls, want) => {
      expect(isRetryable(cls)).toBe(want);
    });
  });

  describe('tripsCircuit', () => {
    it.each<[FailureClass, boolean]>([
      ['rate_limited', true],
      ['timeout', true],
      ['unavailable', true],
      ['auth', true],
      ['payment', true],
      ['model_not_found', true],
      ['unknown', false],
    ])('%s → %s', (cls, want) => {
      expect(tripsCircuit(cls)).toBe(want);
    });
  });

  describe('isPermanent', () => {
    it.each<[FailureClass, boolean]>([
      ['auth', true],
      ['payment', true],
      ['model_not_found', true],
      ['rate_limited', false],
      ['timeout', false],
      ['unavailable', false],
      ['unknown', false],
    ])('%s → %s', (cls, want) => {
      expect(isPermanent(cls)).toBe(want);
    });
  });

  it('buildAdapterErrorFromStatus 401 → failureClass=auth, permanentSkip=true', () => {
    const err = buildAdapterErrorFromStatus({ statusCode: 401, message: 'nope' });
    expect(err.failureClass).toBe('auth');
    expect(err.retryable).toBe(false);
    expect(err.isPermanentSkip).toBe(true);
  });
});
