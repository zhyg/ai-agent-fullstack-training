import { describe, it, expect, vi } from 'vitest';
import { CircuitBreaker, CircuitOpenError, PermanentSkipError } from '../src/core/circuit-breaker.js';

const cfg = { failureThreshold: 3, cooldownMs: 30_000, permanentSkipTTLMs: 24 * 60_60 * 1000 };

describe('circuit breaker', () => {
  it('starts CLOSED', () => {
    const cb = new CircuitBreaker(cfg);
    expect(cb.getState('p').state).toBe('CLOSED');
    expect(cb.tryAcquire('p')).toEqual({ allowed: true, probe: false });
  });

  it('CLOSED → OPEN after threshold', () => {
    const cb = new CircuitBreaker(cfg);
    for (let i = 0; i < cfg.failureThreshold; i++) cb.recordFailure('p', 'unavailable');
    expect(cb.getState('p').state).toBe('OPEN');
    expect(cb.tryAcquire('p').allowed).toBe(false);
  });

  it('OPEN skips without accumulating more failures', () => {
    const cb = new CircuitBreaker(cfg);
    for (let i = 0; i < cfg.failureThreshold; i++) cb.recordFailure('p', 'unavailable');
    const before = cb.getState('p').failureCount;
    cb.recordFailure('p', 'unavailable');
    cb.recordFailure('p', 'unavailable');
    cb.recordFailure('p', 'unavailable');
    expect(cb.getState('p').failureCount).toBe(before); // OPEN state doesn't increment
  });

  it('OPEN → HALF_OPEN → CLOSED on probe success', () => {
    const cb = new CircuitBreaker(cfg);
    for (let i = 0; i < cfg.failureThreshold; i++) cb.recordFailure('p', 'unavailable');
    const cooldownEndsAt = Date.now() + cfg.cooldownMs;
    // Simulate time passing.
    vi.setSystemTime(cooldownEndsAt + 1);
    cb.tryAcquire('p', cooldownEndsAt + 1);
    expect(cb.getState('p').state).toBe('HALF_OPEN');

    cb.recordSuccess('p');
    expect(cb.getState('p').state).toBe('CLOSED');
    expect(cb.getState('p').failureCount).toBe(0);
    vi.useRealTimers();
  });

  it('OPEN → HALF_OPEN → OPEN on probe failure', () => {
    const cb = new CircuitBreaker(cfg);
    for (let i = 0; i < cfg.failureThreshold; i++) cb.recordFailure('p', 'unavailable');
    const cooldownEndsAt = Date.now() + cfg.cooldownMs;
    vi.setSystemTime(cooldownEndsAt + 1);
    cb.tryAcquire('p', cooldownEndsAt + 1);
    expect(cb.getState('p').state).toBe('HALF_OPEN');

    cb.recordFailure('p', 'unavailable', cooldownEndsAt + 2);
    expect(cb.getState('p').state).toBe('OPEN');
    vi.useRealTimers();
  });

  it('permanent failure (auth) immediately opens with permanentSkipUntil', () => {
    const cb = new CircuitBreaker(cfg);
    cb.recordFailure('p', 'auth'); // one auth → permanent skip
    const state = cb.getState('p');
    expect(state.state).toBe('OPEN');
    expect(state.permanentSkipUntil).toBeGreaterThan(Date.now());
    expect(cb.tryAcquire('p').allowed).toBe(false);
  });

  it('permanent skip TTL expires → provider becomes available again', () => {
    vi.useFakeTimers();
    try {
      const cb = new CircuitBreaker({ ...cfg, permanentSkipTTLMs: 100 });
      cb.recordFailure('p', 'auth');
      expect(cb.tryAcquire('p').allowed).toBe(false);

      vi.advanceTimersByTime(200);
      expect(cb.tryAcquire('p').allowed).toBe(true);
      expect(cb.getState('p').state).toBe('CLOSED');
    } finally {
      vi.useRealTimers();
    }
  });

  it('recordSuccess clears permanent skip marker', () => {
    const cb = new CircuitBreaker(cfg);
    cb.recordFailure('p', 'auth');
    cb.recordSuccess('p'); // even though state was OPEN, success clears permanentSkipUntil
    expect(cb.getState('p').permanentSkipUntil).toBeNull();
  });

  it('reset() fully clears state', () => {
    const cb = new CircuitBreaker(cfg);
    for (let i = 0; i < cfg.failureThreshold; i++) cb.recordFailure('p', 'unavailable');
    expect(cb.getState('p').state).toBe('OPEN');
    cb.reset('p');
    expect(cb.getState('p').state).toBe('CLOSED');
    expect(cb.getState('p').failureCount).toBe(0);
  });

  it('CircuitOpenError / PermanentSkipError constructors', () => {
    try { throw new CircuitOpenError('mock'); } catch (e) {
      expect(e instanceof CircuitOpenError).toBe(true);
      expect((e as CircuitOpenError).provider).toBe('mock');
    }
    try { throw new PermanentSkipError('mock'); } catch (e) {
      expect(e instanceof PermanentSkipError).toBe(true);
      expect((e as PermanentSkipError).provider).toBe('mock');
    }
  });
});
