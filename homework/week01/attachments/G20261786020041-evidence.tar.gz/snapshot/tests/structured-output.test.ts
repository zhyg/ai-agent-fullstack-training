import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import {
  SchemaRegistry,
  repairJson,
  parseWithSchema,
  formatZodSummary,
  StructuredOutputError,
  stripMarkdownFence,
} from '../src/core/structured-output.js';

describe('structured output', () => {
  const personSchema = z.object({ name: z.string(), age: z.number().int() });

  describe('stripMarkdownFence', () => {
    it('strips ```json fence', () => {
      const inp = '```json\n{"a":1}\n```';
      expect(stripMarkdownFence(inp)).toBe('{"a":1}');
    });

    it('strips ``` fence without language', () => {
      const inp = '```\n{"a":1}\n```';
      expect(stripMarkdownFence(inp)).toBe('{"a":1}');
    });

    it('passes plain text through', () => {
      expect(stripMarkdownFence('{"a":1}')).toBe('{"a":1}');
    });
  });

  describe('repairJson', () => {
    it('strips fences', () => {
      expect(repairJson('```json\n{"a":1}\n```')).toBe('{"a":1}');
    });
    it('removes trailing commas', () => {
      expect(repairJson('{"a":1, "b":2,}')).toBe('{"a":1, "b":2}');
      expect(repairJson('[1,2,3,]')).toBe('[1,2,3]');
    });
  });

  describe('parseWithSchema', () => {
    it('parses valid JSON', () => {
      const r = parseWithSchema('{"name":"Alice","age":30}', personSchema);
      expect(r.ok).toBe(true);
      if (r.ok) {
        expect(r.data).toEqual({ name: 'Alice', age: 30 });
      }
    });

    it('repairs markdown fence then validates', () => {
      const r = parseWithSchema('```json\n{"name":"Bob","age":25}\n```', personSchema);
      expect(r.ok).toBe(true);
    });

    it('repairs trailing comma then validates', () => {
      const r = parseWithSchema('{"name":"Charlie","age":33,}', personSchema);
      expect(r.ok).toBe(true);
    });

    it('zod failure → StructuredOutputError', () => {
      const r = parseWithSchema('{"name":"Dana","age":"too-old"}', personSchema);
      expect(r.ok).toBe(false);
      if (!r.ok) {
        expect(r.error).toBeInstanceOf(StructuredOutputError);
        expect(r.error.issues.length).toBeGreaterThan(0);
      }
    });

    it('malformed JSON → StructuredOutputError with "custom" issue', () => {
      const r = parseWithSchema('not json at all', personSchema);
      expect(r.ok).toBe(false);
      if (!r.ok) {
        expect(r.error.issues[0]?.code).toBe('custom');
      }
    });
  });

  describe('formatZodSummary', () => {
    it('produces readable path:message list', () => {
      const r = parseWithSchema('{"age":"bad"}', personSchema);
      if (!r.ok) {
        const summary = formatZodSummary(r.error);
        expect(summary).toContain('name'); // name missing
        expect(summary).toContain('age'); // age has wrong type
      }
    });
  });

  describe('SchemaRegistry', () => {
    it('register + resolve', () => {
      const reg = new SchemaRegistry();
      const s = reg.register('person', personSchema);
      expect(reg.resolve('person')).toBe(s);
      expect(reg.resolve('nonexistent')).toBeNull();
    });

    it('exposes jsonSchema via schema.jsonSchema if available', () => {
      const reg = new SchemaRegistry();
      reg.register('person', personSchema);
      const res = reg.resolve('person')!;
      // zod's .schema is on the ZodObject; let's check it's there.
      expect(typeof res.jsonSchema).toBe('object');
    });
  });
});
