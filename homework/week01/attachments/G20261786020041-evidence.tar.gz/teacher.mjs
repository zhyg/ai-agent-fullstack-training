import http from 'node:http';
import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { buildApp } from './snapshot/dist/server.js';
import { registerChatRoutes } from './snapshot/dist/routes/chat.js';
import { testConfig } from './snapshot/dist/config.js';
import { CircuitBreaker } from './snapshot/dist/core/circuit-breaker.js';
import { StreamReplayBuffer } from './snapshot/dist/core/stream-replay.js';
import { PromptRegistry } from './snapshot/dist/prompt/registry.js';
import { SchemaRegistry, parseWithSchema } from './snapshot/dist/core/structured-output.js';
import { Metrics } from './snapshot/dist/observability/metrics.js';
import { OpenAICompatibleAdapter } from './snapshot/dist/adapters/openai-compatible.js';
import Fastify from './snapshot/node_modules/fastify/fastify.js';
import { z } from './snapshot/node_modules/zod/index.js';

const results = [], requests = [], real = [];
const save = () => fs.writeFileSync('/tmp/haoyi-eval/teacher-results.json', JSON.stringify({results, requests, real}, null, 2));
const record = (name, verdict, detail) => { results.push({name, verdict, detail}); save(); };
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let mode = 'ok', calls = [], gateRelease;
const usage = {prompt_tokens: 17, completion_tokens: 9, total_tokens: 26, prompt_cache_hit_tokens: 6, prompt_cache_miss_tokens: 11, completion_tokens_details: {reasoning_tokens: 4}};
const content = () => ({valid:'{"answer":7}', invalid:'not-json', empty:'', truncated:'{"answer":', repair:'{"answer":7,}', wrong:'{"answer":"seven"}'}[mode] ?? 'controlled-OK');
const chunk = obj => 'data: ' + JSON.stringify(obj) + '\n\n';
const upstream = http.createServer(async (req,res) => {
  let raw = ''; for await (const part of req) raw += part;
  const body = JSON.parse(raw || '{}');
  const entry = {at:performance.now(), path:req.url, body, authScheme:req.headers.authorization?.split(' ')[0], mode};
  calls.push(entry); requests.push(entry);
  if (mode === 'always503' || (mode === 'first2fail' && calls.length <= 2) || mode === 'auth401' || mode === 'bad400' || mode === 'rate429') {
    const status = {auth401:401,bad400:400,rate429:429}[mode] ?? 503;
    res.writeHead(status, {'Content-Type':'application/json'});
    res.end(JSON.stringify({error:{message:'teacher-controlled-'+status}})); return;
  }
  if (body.stream) {
    res.writeHead(200, {'Content-Type':'text/event-stream'});
    res.write(': heartbeat\n\n' + chunk({choices:[{delta:{role:'assistant',content:''}}]}));
    await sleep(90);
    res.write(chunk({id:'fixture-stream-id', choices:[{delta:{content:'first-'}}]}));
    if (mode === 'gated') await new Promise(resolve => gateRelease = resolve);
    if (mode === 'errorEvent') { res.end(chunk({error:{message:'teacher interruption'}})); return; }
    if (mode === 'transportBreak') { await sleep(80); res.destroy(); return; }
    if (mode === 'cleanEOF') { res.end(); return; }
    res.write(chunk({choices:[{delta:{content:'second'}}]}));
    res.write(chunk({choices:[],usage}));
    res.end('data: [DONE]\n\n'); return;
  }
  res.writeHead(200, {'Content-Type':'application/json'});
  res.end(JSON.stringify({id:'fixture-response-id',choices:[{message:{content:content()},finish_reason:mode === 'truncated'?'length':'stop'}],usage}));
});
await new Promise(resolve => upstream.listen(0,'127.0.0.1',resolve));
const upstreamUrl = `http://127.0.0.1:${upstream.address().port}/v1`;
Object.assign(process.env, {PRIMARY_PROVIDER:'openai',OPENAI_API_KEY:'teacher-placeholder',OPENAI_BASE_URL:upstreamUrl,OPENAI_MODEL:'model-A',RETRY_MAX_ATTEMPTS:'3',RETRY_BASE_DELAY_MS:'80',RETRY_MAX_DELAY_MS:'320',CB_FAILURE_THRESHOLD:'100',PROMPT_GUARD_MODE:'off'});
delete process.env.FALLBACK_PROVIDER;
async function start() {
  const {app} = await buildApp(); await app.listen({port:0,host:'127.0.0.1'});
  return {app, url:`http://127.0.0.1:${app.server.address().port}`};
}
let current = await start();
const bodyFor = (extra={}) => ({model:'model-A',stream:false,requestId:'teacher-'+results.length,messages:[{role:'user',content:'Return JSON with answer 7.'}],...extra});
async function post(extra={}, base=current.url) {
  const started = performance.now();
  const res = await fetch(base+'/v1/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(bodyFor(extra)),signal:AbortSignal.timeout(120000)});
  const text = await res.text(); let json; try {json=JSON.parse(text);} catch {}
  return {status:res.status,text,json,elapsedMs:performance.now()-started};
}
async function reset(nextMode) { mode=nextMode; calls=[]; await fetch(current.url+'/v1/admin/circuit-breaker/reset',{method:'POST'}); }
try {
  for (const model of ['model-A','model-B']) {
    await reset('ok'); const response=await post({model});
    record('A03-'+model,'FAIL_TWO_PROTOCOLS',{response,upstream:calls});
  }
  // Default README mock path must not silently accept an unknown model.
  process.env.PRIMARY_PROVIDER='mock'; const mock=await start();
  record('A04-default-mock', 'FAIL', await post({model:'not-a-registered-model'},mock.url));
  await mock.app.close(); process.env.PRIMARY_PROVIDER='openai';
  for (const model of ['model-A','model-B']) {
    await reset('gated'); const started=performance.now();
    const res=await fetch(current.url+'/v1/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(bodyFor({model,stream:true})),signal:AbortSignal.timeout(10000)});
    const reader=res.body.getReader(); let text='',deltaAt;
    while (!text.includes('event: delta')) { const part=await reader.read(); if(part.done) break; text+=new TextDecoder().decode(part.value); }
    deltaAt=performance.now()-started; const receivedBeforeRelease=text.includes('first-') && !text.includes('event: done');
    await sleep(120); const releasedAt=performance.now()-started; gateRelease();
    while(true) {const part=await reader.read();if(part.done)break;text+=new TextDecoder().decode(part.value);}
    record('F01-gate-'+model,receivedBeforeRelease?'PASS':'FAIL',{status:res.status,deltaAt,releasedAt,totalMs:performance.now()-started,text,upstreamCount:calls.length});
  }
  for (const nextMode of ['errorEvent','transportBreak','cleanEOF']) {
    await reset(nextMode); const response=await post({stream:true});
    record('F02-'+nextMode,nextMode==='cleanEOF'?'ADVISORY':response.text.includes('event: error')&&calls.length===1?'PASS':'FAIL',{response,upstreamCount:calls.length});
  }
  for (const nextMode of ['valid','invalid','empty','truncated','wrong']) {
    await reset(nextMode); const response=await post({response_format:{type:'json_object'}});
    let valid=true;try{JSON.parse(response.json?.text);}catch{valid=false;}
    record('F03-F04-'+nextMode,nextMode==='valid'?'PARTIAL_CONTENT_ONLY':response.json?.ok&&!valid?'FAIL':'OBSERVED',{response,validModelJSON:valid,upstream:calls});
  }
  await reset('invalid'); record('F03-named-schema-default','FAIL_UNREGISTERED',await post({responseSchemaName:'your-schema'}));
  for (const version of ['1.0.0','1.1.0','9.9.9']) {
    await reset('ok'); const response=await post({promptId:'default-chat',promptVersion:version});
    record('F05-template-'+version,version==='9.9.9'?'OBSERVED_SILENT_SKIP':'PASS',{response,upstream:calls});
  }
  await reset('ok'); record('F06-missing-template','OBSERVED_SILENT_SKIP',{response:await post({promptId:'missing'}),upstream:calls});
  for(const nextMode of ['first2fail','always503','auth401','bad400','rate429']) {
    await reset(nextMode); const response=await post();
    record('F08-F09-'+nextMode,(nextMode==='first2fail'?response.json?.ok&&calls.length===3:nextMode==='auth401'||nextMode==='bad400'?calls.length===1:calls.length===3)?'PASS_COUNTS':'FAIL',{response,actualCalls:calls.length,gapsMs:calls.slice(1).map((x,i)=>x.at-calls[i].at),upstream:calls});
  }
  await reset('ok'); const before=await (await fetch(current.url+'/v1/chat/metrics')).json();
  const normal=await post({requestId:'obs-normal'}); const stream=await post({stream:true,requestId:'obs-stream'});
  await reset('auth401'); const failure=await post({requestId:'obs-failure'});
  const after=await (await fetch(current.url+'/v1/chat/metrics')).json();
  record('F07-observability','PARTIAL',{before,normal,stream,failure,after,expectedUsage:usage});
  await reset('ok'); const statuses=[];
  for(let i=0;i<12;i++)statuses.push((await post({model:'model-A'})).status);
  const B=await post({model:'model-B'}); await sleep(300); const Aafter=await post({model:'model-A'});
  record('F10-F11-local-limit','FAIL_NO_QUOTA',{modelAStatuses:statuses,modelB:B,modelAAfterWait:Aafter,upstreamCount:calls.length,note:'No per-model local limit configuration exists; recovery cannot be established without a limit.'});
  await current.app.close();

  // Dependency injection uses unchanged production route and adapter; it only
  // registers a template/schema through existing public registry APIs.
  const cfg=testConfig({providerOrder:{primary:'openai'},retry:{maxAttempts:3,baseDelayMs:80,maxDelayMs:320},promptGuard:{mode:'off'}});
  const promptRegistry=new PromptRegistry();
  promptRegistry.register('teacher-variable','1.0.0',{system:'Hello {{name}}',dataContract:'name required'});
  const schemaRegistry=new SchemaRegistry();schemaRegistry.register('answer',z.object({answer:z.number()}));
  const replayBuffer=new StreamReplayBuffer(cfg.replay);
  const app=Fastify();
  await registerChatRoutes(app,{config:cfg,circuitBreaker:new CircuitBreaker(cfg.circuitBreaker),retryCfg:cfg.retry,sseCfg:cfg.sse,replayCfg:cfg.replay,promptGuardCfg:cfg.promptGuard,replayBuffer,promptRegistry,schemaRegistry,adapters:new Map([['openai',new OpenAICompatibleAdapter({providerName:'openai',baseUrl:upstreamUrl,defaultModel:'model-A',apiKey:'teacher-placeholder'})]]),providerRegistry:new Map([['openai',{name:'openai'}]]),providerOrder:cfg.providerOrder,metrics:new Metrics()});
  await app.listen({port:0,host:'127.0.0.1'});const harnessUrl=`http://127.0.0.1:${app.server.address().port}`;
  mode='ok';calls=[];
  record('F06-custom-variable-present','FAIL',{response:await post({promptId:'teacher-variable',variables:{name:'昊易'}},harnessUrl),upstream:calls});
  calls=[];
  record('F06-custom-variable-missing','FAIL',{response:await post({promptId:'teacher-variable'},harnessUrl),upstream:calls});
  for(const nextMode of ['valid','invalid','empty','truncated','repair','wrong']) {
    mode=nextMode;calls=[]; const response=await post({responseSchemaName:'answer'},harnessUrl);
    record('F04-library-route-'+nextMode,(nextMode==='valid'||nextMode==='repair'?response.json?.ok:response.status===400)?'PASS_LIBRARY_ONLY':'FAIL',{response,upstreamCount:calls.length,upstream:calls});
  }
  await app.close();

  if(process.argv.includes('--real')) {
    Object.assign(process.env,{OPENAI_API_KEY:process.env.DEEPSEEK_API_KEY,OPENAI_BASE_URL:'https://api.deepseek.com/v1',OPENAI_MODEL:'deepseek-flash',PRIMARY_PROVIDER:'openai',RETRY_MAX_ATTEMPTS:'2',PROMPT_GUARD_MODE:'off'});
    const originalFetch=globalThis.fetch;const observed=[];
    globalThis.fetch=async (input,init) => {
      const url=String(input);
      if(!url.startsWith('https://api.deepseek.com/'))return originalFetch(input,init);
      const request=JSON.parse(init.body);const t=performance.now();
      const res=await originalFetch(input,init);
      const row={url,protocol:'Chat Completions',model:request.model,stream:request.stream,requestKeys:Object.keys(request),status:res.status,headerRequestIds:Object.fromEntries([...res.headers].filter(([k])=>/request.id|trace.id/.test(k))),headerLatencyMs:performance.now()-t};real.push(row);
      observed.push(res.clone().text().then(text=>{
        row.totalUpstreamMs=performance.now()-t;
        if(request.stream){const objects=text.split('\n').filter(x=>x.startsWith('data: {')).map(x=>{try{return JSON.parse(x.slice(6));}catch{return {};}});row.responseId=objects.find(x=>x.id)?.id;row.usage=objects.findLast(x=>x.usage)?.usage;row.contentChunks=objects.filter(x=>x.choices?.[0]?.delta?.content).length;row.finishReasons=objects.map(x=>x.choices?.[0]?.finish_reason).filter(Boolean);}
        else{try{const j=JSON.parse(text);row.responseId=j.id;row.usage=j.usage;row.finishReason=j.choices?.[0]?.finish_reason;row.modelContent=j.choices?.[0]?.message?.content;row.error=j.error;}catch{row.nonJSON=true;}}
      }).catch(error=>row.readError=String(error)));
      return res;
    };
    current=await start();
    for(const model of ['deepseek-flash','deepseek-v4-pro']) {
      for(const kind of ['normal','stream','json']) {
        try {
          const response=await post({model,requestId:'real-'+model+'-'+kind,stream:kind==='stream',maxTokens:2048,messages:[{role:'user',content:kind==='json'?'Return only this JSON object: {"answer":7}.':'Reply only OK.'}],...(kind==='json'?{response_format:{type:'json_object'}}:{})});
          record('REAL-'+model+'-'+kind,response.status===200&&((kind==='stream')?response.text.includes('event: delta')&&response.text.includes('event: done'):response.json?.ok&&response.json?.text?.length>0)?'PASS_CONTENT':'UNVERIFIED_OR_FAILURE',response);
        }catch(error){record('REAL-'+model+'-'+kind,'UNVERIFIED',{error:String(error)});}
      }
    }
    await Promise.allSettled(observed);globalThis.fetch=originalFetch;save();await current.app.close();
  }
} finally {
  gateRelease?.();await current.app.close().catch(()=>{});
  upstream.closeAllConnections();await new Promise(resolve=>upstream.close(resolve));save();
}
console.log('TEACHER_FINISHED', results.map(x=>x.name+':'+x.verdict).join('\n'));
