# 第一周作业评测附件

- 学员：昊易（G20261786020041）
- 仓库：https://gitee.com/yuantao027/llm-gateway-yt
- 分支与固定提交：main，988f7a34246b8ab25c5690ba0316715075f1caed。
- 评测日期：2026-11-07（Asia/Singapore；现场日志为 UTC，约 07:03–07:39 UTC）。
- 总分：67/100（暂评）；作业等级：良好。真实 Pro 接入证据未完整，不据环境失败扣代码分。
- 验收结论：未通过。源码可确认仅一种真实协议、缺少本地按模型限流等核心要求；另有 Pro 真实接入证据不完整，不能以 HTTP 200 代替内容成功。
- 标准：评分标准 v1.1、第一周作业原文、反馈报告模板 v1.0。
- 证据包：同目录 `G20261786020041-evidence.tar.gz`。下文证据路径均指解包后的文件。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 9/15 | 接口 3、路由 2、双协议 0、结果抽象 4；D1 −4、D2 −2。两个模型名走同一 Chat Completions 适配器。 |
| 流式输出 | 15/15 | 两个受控模型别名均有 SSE、门控增量、明确错误事件及输出后不重试；Flash 官方实测通过。第二协议缺失仅在 D1 扣分，不跨项重复扣；Pro 真实内容未验证不扣环境分。 |
| 结构化输出 | 3/10 | D3 −7：统一入口正常约束及非法结果失败处理未接通。保留已有 JSON 解析／本地校验 3 分：使用公开注册 API 注入 Schema 的不改源码组件现场验证有效，不冒充标准启动已通过。 |
| 提示词版本管理 | 7/10 | 存储与旧版本引用实测可用；D4 −3：变量渲染缺失。缺变量残留占位符为同根因，不再次扣分；缺模板／版本静默跳过仅记录行为，不追加门槛。 |
| 可观测性 | 10/15 | Token 2/5、延迟 3/4、关联与记录 2/3、失败记录 3/3。D5 −5：分类及普通调用记录不全。失败计数及带关联字段的失败日志已存在，不判完全缺失。 |
| 统一错误与重试 | 13/15 | 错误映射 2/4、退避 4/4、次数 3/3、不可重试 3/3、过程证据 1/1；D6 −2：外层丢失错误类别，状态均变 502。无 SDK 重试叠加。 |
| 按模型独立限流 | 0/10 | D7 −10：不存在本地额度计数、429 拦截与恢复机制。熔断器和上游 429 重试不是本地限流。 |
| 源码、README 与验证脚本 | 10/10 | 43 个文件完整固定；安装、类型检查、构建、启动及文档 curl 等价请求可执行；172 项断言测试及冒烟脚本有效。覆盖范围有局限，见 F12；未因上述同根因业务缺失，再机械扣“缺对应回归”分。 |
| **合计** | **67/100** | 100 − (4+2+7+3+5+2+10) = 67；未按用例通过率换算，无封顶或一票否决。 |

## 固定源码、安装与配置

1. 亲自执行 `git clone https://gitee.com/yuantao027/llm-gateway-yt /tmp/haoyi-eval/student`，退出 128，`SSL connection timeout`（`clone.log`）。DNS 可解析；Gitee HTTPS 页面、API、raw、ZIP 的 orb 直连均超时，无 HTTP 401/403，因此不能称“私有／权限拒绝”。GitHub 同名只读镜像查询为 404，不能证明 Gitee 权限。
2. `read_web_page` 可读 Gitee 公共页面与固定提交的递归树；orb 经 `r.jina.ai` 只读代理获取 Gitee Git blob API Base64 内容，逐文件计算 `SHA1("blob " + length + NUL + bytes)`。`tree.json` 表明未截断；`source-manifest.json` 记录全部 **43/43** blob 哈希一致。归档保留完整原文件 `snapshot/`，没有改业务源码。不是把 Markdown 页面重写成源码，也不是仅取部分文件。
3. 按 README `npm install` 成功；`npm run typecheck`、`npm run build` 成功；`npm test`：12 files、172 passed。最初构建在文件下载尚未结束时提示缺 tsconfig，补齐快照后重跑成功，不作为学生缺陷。
4. README 启动使用 supervised service：在 snapshot 内执行 `amp orb service start haoyi-readme --command 'env PORT=$PORT HOST=0.0.0.0 npm run dev' --port 3011`。`readme.env` 为教师独立 `.env`，仅改变端口／绑定地址，仍使用默认 Mock。原 `.env.example` 的 primary=mock、fallback=mock-fallback；教师冒烟现场未启用 fallback，避免成功掩盖错误。
5. 学生冒烟原命令要求 Windows `powershell`、`curl.exe`；本 orb 临时安装 PowerShell 7.4.6，并建立命令别名到真实 pwsh／curl，`TEMP=/tmp`，未改学生脚本。先对错端口试跑失败是教师端口差异，不扣分；独立 `.env` 配置 3011 后 `npm run smoke` 为 `ALL CHECKS PASSED`、exit 0。另将 `-BaseUrl http://127.0.0.1:1 -TimeoutSec 2` 制造不可达，输出 FAIL、exit 1（`smoke-forced-failure.log`）。
6. 受控配置：真实业务 `buildApp()` + 本机 HTTP 上游 fixture；primary=openai、无 fallback、base 指向临时本机 `/v1`、假凭据 teacher-placeholder，RETRY_MAX_ATTEMPTS=3、base=80ms、cap=320ms、CB_FAILURE_THRESHOLD=100、guard=off。阈值改动只避免熔断遮盖实际重试次数；不注入成功适配逻辑。额外组件现场仅通过学生现有 Registry API 注册变量模板与 Zod Schema，再调用未改动的生产路由和适配器，单独标为 library-only。
7. 官方替代配置：OPENAI_BASE_URL=`https://api.deepseek.com/v1`，PRIMARY_PROVIDER=openai，无 fallback，OPENAI_MODEL=deepseek-flash；请求显式分别传 deepseek-flash／deepseek-v4-pro，凭据只从既有 DEEPSEEK_API_KEY 在进程内映射到 OPENAI_API_KEY，不写配置／报告／归档。原默认模型 gpt-4o-mini、默认官方 OpenAI URL 没有发出真实请求。两种 DeepSeek 名称仍是同一种 Chat Completions 协议，不能靠改名字补齐第二协议。
8. 额外官方 `/models` 只读探测确认模型 ID 为 deepseek-flash、deepseek-v4-pro。最初真实阶段部分 500／长等待；恢复额度后仅补两次未成功的 stream，每模型一次、RETRY_MAX_ATTEMPTS=1；没有重跑已成功的 Flash JSON 请求。所有真实模型请求仅去 api.deepseek.com。早期两个直连官方诊断请求不算学生网关验收：Flash `/v1/chat/completions` 返回 500；Pro `/chat/completions` 读取超时，后者留存 `official-diagnostic.json`。

## A01–A04／F01–F12 结果

| 编号 | 结果 | 实际证据与边界 |
| --- | --- | --- |
| A01 | 通过 | install/typecheck/build 日志、readme-service.log；README mock 启动与 curl 请求可用。 |
| A02 | 部分／未验证 | Flash 官方 JSON 正文及补验 SSE 成功；Pro 所有现场尝试均无有效正文证据，不能确认第二模型真实可用。 |
| A03 | 不通过 | `A03-model-A/B` 记录相同 `/v1/chat/completions`、Bearer、`model/messages/stream`，解析 choices.message／choices.delta；完整源码只有 OpenAI-compatible 真适配器，没有 Responses／Messages 路径。 |
| A04 | 不通过 | `A04-default-mock`：model=not-a-registered-model 返回 200、ok=true、usedProvider=mock。 |
| F01 | 受控通过；真实部分 | `F01-gate-model-A/B`：下游首正文分别 97.14/94.57ms，教师释放终态分别 217.52/214.46ms，最终完成 220.98/216.54ms；证明不是生成后缓冲。各 1 个上游请求。Flash 官方 SSE 补验成功；Pro 未验证。 |
| F02 | 通过 | 输出 first- 后上游 error event／物理断流，各仅 1 次请求、下游 error，无重试与重复正文。普通流无终态 clean EOF 被报 done 是 B05 建议，不加扣分。 |
| F03 | 不通过 | 统一 response_format 被入口剥离，上游无约束字段；合法 JSON 恰好返回不能证明字段生效。标准启动 responseSchemaName=your-schema 也未注册、被忽略。 |
| F04 | 不通过（公开入口） | 非法 not-json、空串、截断 `{"answer":` 均 HTTP 200/ok=true。组件补验：注册 answer Schema 后有效 JSON 通过，非法／空／截断／错误类型最终 400；本地去尾逗号可修复，但 text 仍保留原串，不能据此宣布外部模型内容全面合法。 |
| F05 | 部分通过 | default-chat 1.0.0／1.1.0 均进入实际上游 system，旧版不含新版 Prefer plain text 句。自定义模板变量不替换，见 F06。 |
| F06 | 不通过（变量） | `F06-custom-variable-present/missing` 均向上游发送 Hello {{name}}。缺模板／版本被静默跳过且无 500，不对此另扣。 |
| F07 | 部分通过 | `F07-observability`：普通、流式、失败后 totalRequests 22→25、success 16→18、failure 6→7；仅流式增加 TTFT/e2e 样本 3→4。流式日志有 requestId、17/9/26 和约 91ms TTFT；分类 6/11/4 丢失；普通成功日志没有客户端 requestId 与用量。 |
| F08 | 通过 | 前两次 503、第三次成功，fixture 实收 3 次；日志 nextDelayMs=73/119，上游实际间隔约 77.80/121.75ms，均符合全抖动上限 80/160ms（网络处理开销另计）。 |
| F09 | 次数通过，错误映射不通过 | 持续 503：3 次，延迟日志 62/8ms；上游 429：3 次、60/36ms；400、401 各 1 次。依赖及源码使用 fetch、无 SDK 内置重试。最终外部错误都成为 502/all_providers_failed/unknown。 |
| F10 | 不通过 | model-A 连续 12 次均 200；B 随后 200。完整代码／配置无本地模型配额项，不能把 B 成功当隔离验证；D7。 |
| F11 | 无法成立 | A 等 300ms 后仍 200，但之前从未触发本地限流，故不是额度恢复证据；无窗口／补充机制可等待。同 D7，不另扣。 |
| F12 | 部分通过 | npm test 172/172，npm smoke 规定范围内通过，制造不可达后明确 FAIL。smoke 实际覆盖 health、普通、流式、replay、metrics、guard，不代表六项要求全覆盖；组件测试也不能替代真实双协议。未因已计分业务缺陷缺回归重复扣。 |

## 每次扣分的复现依据

通用复现：解包到 `/tmp/haoyi-eval`，在 `snapshot` 运行 `npm install && npm run build`，回上层运行 `node teacher.mjs > teacher.log 2>&1`（不带 --real 为纯受控）。结果为 `teacher-results.json`；脚本最终退出码不代表全部通过，必须读逐项 verdict。以下固定行号对应归档原文件与提交 988f7a3；不要用后来变更的 main。

### D1：双协议适配缺失，统一接口与适配器 −4

- 触发：同一入口分别请求 model-A、model-B，以及 Flash／Pro 的官方配置。
- 期望：至少两种不同协议的路径、请求结构、响应／流解析。
- 实际：仅 `/chat/completions` + messages + choices；MockAdapter 是内存模拟，不是第二协议。
- 复现：上述通用命令；查看 `A03-model-A`、`A03-model-B` 与 requests；`rg -n 'chat/completions|responses|/messages' snapshot/src` 核对路径。
- 固定源码：`src/server.ts:20–41` 注册 Mock 和唯一真实适配器；`src/adapters/openai-compatible.ts:107–127,157–160,219–248` 请求与解析。
- 只扣本项双协议 4 分，不再次扣流式／结构化的“第二协议缺失”。

### D2：model 未形成适配器路由／未知模型被成功兜底，统一接口与适配器 −2

- 触发：README 默认 mock，model=not-a-registered-model。
- 期望：明确统一错误，不静默当正常模型调用。
- 实际：HTTP 200、ok=true、usedProvider=mock；providerOrder 只看环境变量，不随 model 选适配器。显式模型名向真实上游透传这一部分保留分数。
- 复现：通用命令的 `A04-default-mock`；或默认服务 `POST /v1/chat`，正文 `{"model":"not-a-registered-model","stream":false,"messages":[{"role":"user","content":"hello"}]}`。
- 固定源码：`src/routes/chat.ts:35–49,160–162,214–235`；`src/adapters/openai-compatible.ts:92–95`。不再按错误分类扣未知模型的同一现象。

### D3：统一结构化入口没有接通，结构化输出 −7

- 触发：传 `response_format:{"type":"json_object"}`，受控返回合法、非法、空、截断 JSON；对照传 README 的 responseSchemaName。
- 期望：映射上游约束，成功前校验内容，非法最终明确失败。
- 实际：入口无 response_format；上游 payload 没有约束；not-json／空／截断正文仍 200、ok=true。标准服务 SchemaRegistry 为空；组件注册后本地 parse/validation 可执行，保留 3 分。
- 复现：通用命令的 `F03-F04-*`、`F03-named-schema-default` 与 `F04-library-route-*` 对照；错误类型 wrong 只在显式注册的 Schema 组件内检查，不把 Schema 当原题强制门槛。
- 固定源码：`src/routes/chat.ts:35–49,149–158,238–279`；`src/server.ts:59–60`；`src/adapters/openai-compatible.ts:107–123`；已有解析能力见 `src/core/structured-output.ts:81–107`。
- 非法／空／截断、两模型、多入口复现均合并此根因；不跨错误项再次扣这批输入。

### D4：模板变量不渲染，提示词版本管理 −3

- 触发：通过现有 PromptRegistry.register 注册 `Hello {{name}}`，分别传 variables.name=昊易 与不传变量，再调用同一生产路由。
- 期望：替换变量；缺必要变量明确处理，不能把占位符发上游。
- 实际：两次上游 system 都是 `Hello {{name}}`；版本存储、引用仍正常。
- 复现：通用命令的 `F06-custom-variable-present`／`F06-custom-variable-missing`。额外注册只是固定教师输入，没有改 registry、路由或适配器逻辑。
- 固定源码：`src/prompt/registry.ts:5–10,20–43`；`src/routes/chat.ts:35–49,132–147` 直接转发 template.system，无变量入参或渲染。
- “缺变量残留占位符”与“有变量也不渲染”同根因，只扣 3 分。

### D5：调用记录不完整，可观测性 −5

- 触发：受控上游提供 prompt=17、completion=9、total=26，cache hit=6／miss=11、reasoning=4；发 obs-normal、obs-stream、obs-failure 后查询 metrics 并读日志。
- 期望：逐调用关联记录用量分类、总延迟，流式 TTFT 为首个非空正文而非心跳；失败也留记录。
- 实际：总量映射准确、流式 TTFT 约 91ms、失败计数和关联失败日志存在。但分类字段被 mapUsage 丢弃（−2）；普通成功仅把用量返回客户端，不纳入调用日志／账本（−1）；非流式不记录 e2e 观测样本（−1）；普通成功日志仅 Fastify reqId，缺少客户端 requestId 对应的完成记录（−1）。Fastify responseTime 本身存在，不声称完全没有计时。
- 复现：通用命令 `F07-observability`；`rg 'obs-normal|obs-stream|obs-failure' teacher.log`，与 metrics 前后 count 比较。一般成功日志可见 reqId，但不会出现 obs-normal 的用量／耗时完成条目。
- 固定源码：`src/adapters/openai-compatible.ts:33–51`；`src/routes/chat.ts:200–208,275–281,284–308`；`src/observability/metrics.ts:18–28,40–63`；流式已做好的记录见 `src/core/stream.ts:323–363`。
- 失败类别丢失由 D6 计分，此处不再扣；失败计数和日志保留 3/3。

### D6：外层错误丢失类别与状态，统一错误与重试 −2

- 触发：受控上游分别 400、401、持续 503、429。
- 期望：保留合理统一类别；参数／鉴权类为明确 4xx，临时上游故障与之可区分；400／401 不重复请求。
- 实际：内部能识别 auth／unavailable／rate_limited，次数正确；外层 AllProvidersFailedError 把所有情况变为 HTTP 502、failureClass=unknown、同一句 all providers failed。
- 复现：通用命令 `F08-F09-bad400/auth401/always503/rate429`；fixture 实收分别 1/1/3/3 次。以客户端响应与内部分类日志做对照。
- 固定源码：`src/core/fallback.ts:44–52,126–143`；`src/core/failure.ts:37–49`；`src/routes/chat.ts:295–308`。只扣错误码／状态映射 2 分，不扣已正确执行的重试及不可重试行为。

### D7：没有网关本地按模型限流，按模型独立限流 −10

- 触发：模型 A 连续 12 次、模型 B 一次、等待后再发 A；并核对完整固定源码及配置。
- 期望：可设定本地小配额，A 超限 HTTP 429、B 独立通过、到声明窗口后 A 恢复。
- 实际：14 次上游均执行；配置没有任何本地配额／窗口，代码没有本地计数或 429 拦截。不能仅凭 12 次不触发限流推断缺失，结论同时依据完整源码所有请求分支。上游 429 和 provider 熔断不等于按模型配额。
- 复现：通用命令 `F10-F11-local-limit`；`rg -n -i 'rate.limit|ratelimit|quota|limiter|token.bucket' snapshot/src`；完整 env/config 对照。
- 固定源码：`src/config.ts:50–96` 完整配置；`src/routes/chat.ts:96–235,295–308` 主入口及错误出口；`src/server.ts:20–83` 依赖注册，均无本地限流。`src/core/failure.ts:19–29` 仅分类上游 429。
- 计数、429、隔离、恢复都是同一缺失功能，合并扣本项 10，不再在 F11／脚本项重复扣。

## 真实调用明细与限制

均经未改源码网关指向 `https://api.deepseek.com/v1/chat/completions`，协议为 **Chat Completions**，无第二种协议。完整每次官方 HTTP 观测（含自动重试）见 `teacher-results.json.real` 9 条、`real-supplement.json.observations` 2 条；请求标识保留响应 id 和 x-ds-trace-id，错误信息中另有官方 request_id。

| 现场 | 网关 requestId／上游 id 或 trace | 结果、用量、延迟 |
| --- | --- | --- |
| Flash 普通首轮 | real-deepseek-flash-normal；trace=96c48229f36557edbceb14cbca7d58a8、c4c293bc478cf50839a1ce64b10e42f4 | 首次 500 约15.35s，第二次头 200 但最终不能解析完整 JSON，上游读取约232.44s，客户端120s超时。无有效用量，不记成功。 |
| Flash SSE 首轮 | real-deepseek-flash-stream；trace=9c463bca4716203dec49692e3713ce41；错误 request_id=9eab09d1-8006-4800-ab16-8d4135c0c5d9 | 上游500；网关 SSE error；约15.29s，无用量。 |
| Flash JSON 首轮 | real-deepseek-flash-json；首次 trace=7adab13ec7678b09d11f47ced8e3f5a2；成功 id=c457576d-542e-431c-b76d-b2a13651f423、trace=4fe71c35cc9b40d6ec6a05ee7548208b | 初次500约15.30s后重试成功，正文 {"answer":7}；输入41／输出26／总67，推理20、cache hit0／miss41；成功尝试上游约49.13s，客户端合计64.49s。请求约束字段未进入上游，故只证明真实内容可用，不算 response_format 通过。 |
| Pro 普通首轮 | real-deepseek-v4-pro-normal；trace=a8cdfc46ad4ea830b2a9be4d7981f88f | 上游头200，最终 nonJSON，网关502；约78.89s，缺有效 id／用量。 |
| Pro SSE 首轮 | real-deepseek-v4-pro-stream；trace=dbe632c3a9e62ad2370d73f08ef697d8；错误 request_id=25d25cca-405a-47b5-96b5-78e143d4f283 | 上游500、SSE error；约15.29s，无用量。 |
| Pro JSON 首轮 | real-deepseek-v4-pro-json；trace=c5b6781f8aa0ac80e0be183f61f55194、791aa2db760b35d38697c9b818fd3cd0 | 500后重试，第二次头200但 nonJSON；网关502约48.85s，无有效用量。 |
| Flash SSE 额度恢复后补验 | supplement-deepseek-flash-stream；id=8b94baa5-b9e3-499e-9016-314da90fecd3；trace=8d380bb25116b6e7fea11c6187a6353f | **有效正文 OK + usage + done**；输入34／输出11／总45，推理9、cache hit0／miss34；TTFT679.34ms、网关e2e684.97ms、客户端732.20ms。只有1次官方请求。 |
| Pro SSE 额度恢复后补验 | supplement-deepseek-v4-pro-stream；trace=1e1ff465818dc980d24549f61e6bb550 | 头200，但观察到0个正文块、无可解析 response id／usage；网关仍发done、TTFT0，客户端33.64s。**未验证内容成功**，不把done视为成功证明；也不把未知上游正文归咎学生。只有1次官方请求，未再重复收费请求。 |

早期非流式超时请求仍可能在上游继续执行，因此不将本地超时视为官方没有消耗；缺用量请求不能估算为 0 Token。真实首轮观察脚本保存了错误／解析结果而未保留所有非 JSON 原始字节，故 Pro 的异常正文根因未确认，不宣称余额、模型逻辑或解析器是确定原因。官方仍不稳定时应补交一次 Pro 正文、request_id、用量和延迟；不得改学生逻辑强行通过。暂评分不对上述环境／上游阻塞扣分。

## 未验证与不扣分建议

- Pro 有效真实正文、Token、TTFT 未验证；真实第二协议不存在，不可写成“只缺密钥”。密钥环境已具备，限制是现场未获可解析有效内容。
- F11 无本地限流前提，无法验证额度恢复；属 D7 缺失，不是环境问题。
- 标准服务没有公开 Schema 注册入口；组件注入验证只给实现部分分，不冒充完整交付。
- 普通 SSE clean EOF 被适配器转 done（`openai-compatible.ts:258–259`），建议区分成功终态，按 B05 不另扣；推理先行但无正文时 TTFT=0 建议改为未知，未按非结构化边界另扣。
- 不额外要求 Redis、持久化账本、分布式额度、JSON Schema、stream+JSON、Retry-After 或恢复重连；不因 PowerShell 平台差异、工具安装、原始网络阻塞扣代码分。

## 补交与复验要求

- 修复 D1–D7；优先双协议路由、本地按模型限流、response_format 约束和成功前校验、模板变量。
- 增加对应公开入口验证断言：双模型真实证据；门控增量与中断不重试；JSON 边界；旧版本与缺变量；关联用量和失败记录；实际重试次数；限流隔离和恢复。
- 按 README 重跑，补齐 Pro 以及新增协议的官方真实成功记录，不以 Mock／截图／HTTP200 代替正文证据；密钥仍只用环境变量。
- 收尾：教师有限测试进程均已结束；`haoyi-readme` 已在其启动目录停止，`amp orb service list` 返回 `No orb services are running.`；源码再次校验 43/43 不变。最终报告／归档的实际密钥扫描与分数格式检查见 `final-checks.json`。
