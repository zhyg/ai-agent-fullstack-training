import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import tarfile

root = pathlib.Path('/tmp/haoyi-eval')
repo = pathlib.Path('/home/user/workspace/repo')
feedback = repo / 'homework/week01/G20261786020041.md'
attachment = repo / 'homework/week01/attachments/G20261786020041.md'
destination = root / 'evidence'
destination.mkdir(exist_ok=True)
manifest = json.loads((root / 'source-manifest.json').read_text())
for entry in manifest['files']:
    data = (root / 'snapshot' / entry['path']).read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert actual == entry['expected'], entry['path']
    target = destination / 'snapshot' / entry['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

names = ['fetch_source.py', 'tree-proxy.txt', 'tree.json', 'source-manifest.json',
         'teacher.mjs', 'teacher-results.json', 'teacher.log', 'real-supplement.mjs',
         'real-supplement.json', 'real-supplement.log', 'readme.env', 'clone.log',
         'fetch.log', 'fetch2.log', 'fetch3.log', 'install.log', 'typecheck.log',
         'build.log', 'student-tests.log', 'smoke-normal.log', 'smoke-3011.log',
         'smoke-forced-failure.log', 'readme-service.log', 'service-start.log',
         'official-diagnostic.json', 'package_evidence.py']
names += [p.name for p in root.glob('probe-*.log')]
for name in names:
    shutil.copy2(root / name, destination / name)
shutil.copy2(feedback, destination / 'feedback.md')
shutil.copy2(attachment, destination / 'assessment.md')

text = feedback.read_text()
sections = {}
for number, title in [(2, '作业优点'), (3, '作业不足'), (4, '改进方案')]:
    section = text.split(f'**{number}. {title}**', 1)[1].split('**', 1)[0]
    lines = [line for line in section.splitlines() if line.startswith('- ')]
    sections[title] = {'items': len(lines), 'characters': sum(len(line[2:]) for line in lines)}
    assert 3 <= len(lines) <= 5 and sections[title]['characters'] <= 500
assert '作业等级：良好（67分）' in text
assessment = attachment.read_text()
score_part = assessment.split('## 固定源码', 1)[0]
scores = [int(n) for n in re.findall(r'^\| [^|]+ \| (\d+)/(?:10|15) \|', score_part, re.M)]
assert len(scores) == 8 and sum(scores) == 67, scores
for code in [f'A{i:02}' for i in range(1, 5)] + [f'F{i:02}' for i in range(1, 13)]:
    assert f'| {code} |' in assessment
for deduction in range(1, 8):
    assert f'### D{deduction}' in assessment

services = subprocess.run(['amp', 'orb', 'service', 'list'], cwd=root / 'snapshot', capture_output=True, text=True, check=True)
service_output = services.stdout + services.stderr
assert 'No orb services are running.' in service_output, service_output
secrets = [value.encode() for key, value in os.environ.items()
           if re.search(r'KEY|TOKEN|SECRET|PASSWORD', key, re.I)
           and not key.endswith('_ENV_NAMES') and len(value) >= 12]
assert os.environ.get('DEEPSEEK_API_KEY'), 'Expected credential must be present to scan its actual bytes'
def scan(path, data):
    assert not any(value in data for value in secrets), f'Credential found in {path}; value intentionally not printed'
files = [p for p in destination.rglob('*') if p.is_file()]
for path in files + [feedback, attachment]:
    scan(str(path), path.read_bytes())
checks = {'scores': scores, 'sum': sum(scores), 'grade': '良好', 'provisional': True,
          'sections': sections, 'all_A_F_present': True, 'deductions_with_evidence': 7,
          'source_files': len(manifest['files']), 'source_hashes_unchanged': True,
          'actual_environment_credentials_scanned': True, 'credential_matches': 0,
          'services': service_output.strip(), 'teacher_processes_completed': True,
          'student_tests': '172 passed / 12 files', 'typecheck': 'exit 0', 'build': 'exit 0',
          'smoke': 'exit 0; forced failure exit 1', 'committed_or_pushed': False}
(destination / 'final-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2))
archive = repo / 'homework/week01/attachments/G20261786020041-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(destination.rglob('*')):
        if path.is_file():
            tar.add(path, arcname=str(path.relative_to(destination)), recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
        scan(member.name, tar.extractfile(member).read())
print(json.dumps(checks, ensure_ascii=False, indent=2))
print('ARCHIVE_MEMBERS', len(members), 'ARCHIVE_BYTES', archive.stat().st_size,
      'ARCHIVE_SHA256', hashlib.sha256(archive.read_bytes()).hexdigest())
