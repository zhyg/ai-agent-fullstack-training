import fs from 'node:fs';
import { buildApp } from './snapshot/dist/server.js';

Object.assign(process.env,{PRIMARY_PROVIDER:'openai',OPENAI_API_KEY:process.env.DEEPSEEK_API_KEY,OPENAI_BASE_URL:'https://api.deepseek.com/v1',OPENAI_MODEL:'deepseek-flash',RETRY_MAX_ATTEMPTS:'1',PROMPT_GUARD_MODE:'off',INACTIVITY_WATCHDOG_MS:'60000'});
delete process.env.FALLBACK_PROVIDER;
const observations=[], results=[],pending=[];
const original=globalThis.fetch;
globalThis.fetch=async(input,init)=>{
  if(!String(input).startsWith('https://api.deepseek.com/'))return original(input,init);
  const body=JSON.parse(init.body),started=performance.now();
  const response=await original(input,init);
  const item={url:String(input),model:body.model,protocol:'Chat Completions',requestKeys:Object.keys(body),status:response.status,headerRequestIds:Object.fromEntries([...response.headers].filter(([k])=>/request.id|trace.id/.test(k))),headerMs:performance.now()-started};observations.push(item);
  pending.push(response.clone().text().then(text=>{
    item.elapsedMs=performance.now()-started;
    const chunks=text.split('\n').filter(x=>x.startsWith('data: {')).map(x=>{try{return JSON.parse(x.slice(6));}catch{return {};}});
    item.responseId=chunks.find(x=>x.id)?.id;item.usage=chunks.findLast(x=>x.usage)?.usage;item.contentChunks=chunks.filter(x=>x.choices?.[0]?.delta?.content).length;
    if(!response.ok){try{item.error=JSON.parse(text);}catch{item.error=text.slice(0,500);}}
  }).catch(e=>item.error=String(e)));
  return response;
};
const {app}=await buildApp();await app.listen({port:0,host:'127.0.0.1'});
try {
  for(const model of ['deepseek-flash','deepseek-v4-pro']) {
    const started=performance.now(),requestId='supplement-'+model+'-stream';
    try{
      const response=await fetch(`http://127.0.0.1:${app.server.address().port}/v1/chat`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,requestId,stream:true,maxTokens:2048,messages:[{role:'user',content:'Reply only OK.'}]}),signal:AbortSignal.timeout(90000)});
      const text=await response.text();results.push({model,requestId,status:response.status,elapsedMs:performance.now()-started,text,contentVerified:text.includes('event: delta')&&text.includes('event: done')});
    }catch(e){results.push({model,requestId,error:String(e),elapsedMs:performance.now()-started});}
    fs.writeFileSync('/tmp/haoyi-eval/real-supplement.json',JSON.stringify({results,observations},null,2));
  }
}finally{
  await Promise.allSettled(pending);fs.writeFileSync('/tmp/haoyi-eval/real-supplement.json',JSON.stringify({results,observations},null,2));
  await app.close();globalThis.fetch=original;
}
console.log('SUPPLEMENT_FINISHED',JSON.stringify({results,observations}));
