import json,time
from pathlib import Path
import httpx

rows=[]
with httpx.Client(base_url='http://127.0.0.1:8912',headers={'Authorization':'Bearer teacher-real-local'},timeout=70) as c:
    for model in ('deepseek-v4-pro','deepseek-v4-flash'):
        for stream in (False,True):
            payload={'model':model,'messages':[{'role':'user','content':'Return exactly {"ok":true}, no other words.'}],'max_tokens':4096}
            if not stream: payload['response_format']={'type':'json_object'}
            else: payload['stream']=True
            start=time.monotonic(); events=[]
            with c.stream('POST','/v1/chat/completions',json=payload) as r:
                rid=r.headers.get('x-request-id')
                if stream:
                    for line in r.iter_lines():
                        if line.startswith('data: '): events.append({'at_ms':round((time.monotonic()-start)*1000,3),'data':line[6:]})
                    response={'events':events}
                else:
                    r.read(); response=r.json()
            rec=c.get('/v1/calls/'+rid).json() if rid else None
            row={'case':'F01-real' if stream else 'F03-real','model':model,'status':r.status_code,'response':response,'record':rec}
            rows.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
Path('/tmp/huncidd-grade/real-features.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
