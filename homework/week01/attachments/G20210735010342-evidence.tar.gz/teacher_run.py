import json,time,threading
from pathlib import Path
import httpx

root=Path('/tmp/huncidd-grade')
c=httpx.Client(base_url='http://127.0.0.1:8911',headers={'Authorization':'Bearer test-gateway-key'},timeout=15)
models=['deepseek-v4-pro','deepseek-v4-flash']; results=[]
def log(name, passed, **data):
    row={'case':name,'result':'PASS' if passed else 'FAIL',**data}
    results.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
def control(mode='normal',**kw): c.post('/teacher/control',json={'mode':mode,**kw}).raise_for_status()
def state(): return c.get('/teacher/state').json()
def chat(model,**kw):
    return c.post('/v1/chat/completions',json={'model':model,'messages':[{'role':'user','content':'Return JSON {"ok":true}'}],**kw})
def record(r):
    rid=r.headers['x-request-id']; return c.get('/v1/calls/'+rid).json()

log('A01',c.get('/health').status_code==200)
for model in models:
    control(); r=chat(model); s=state(); body=s['requests'][0]['body']; pro=model==models[0]
    log('A03 '+model,r.status_code==200 and ('input' in body if pro else 'messages' in body),upstream=s['requests'],response=r.json())
control(); r=chat('unknown'); log('A04',r.status_code==404 and not state()['requests'],status=r.status_code,response=r.json(),record=record(r))
log('F07-unknown-failure',record(r).get('status')=='error',record=record(r))
for model in models:
    control('gate'); chunks=[]; arrival=threading.Event(); errors=[]
    start=time.monotonic()
    def read():
        try:
            with c.stream('POST','/v1/chat/completions',json={'model':model,'messages':[{'role':'user','content':'hi'}],'stream':True}) as r:
                for line in r.iter_lines():
                    if line.startswith('data: '):
                        chunks.append({'at_ms':(time.monotonic()-start)*1000,'data':line[6:]})
                        if 'alpha' in line: arrival.set()
        except Exception as e: errors.append(type(e).__name__)
    thread=threading.Thread(target=read); thread.start(); got=arrival.wait(3); before=state()
    time.sleep(.15); c.post('/teacher/release'); thread.join(5)
    final=next((json.loads(x['data']) for x in chunks if '"gateway"' in x['data']),{})
    log('F01 '+model,got and not before['released'] and not errors and chunks[-1]['data']=='[DONE]',chunks=chunks,errors=errors,upstream=before['requests'])
    if final:
        rec=c.get('/v1/calls/'+final['gateway']['request_id']).json()
        log('F07-stream '+model,rec['input_tokens']==17 and rec['output_tokens']==9 and rec['cached_input_tokens']==4 and 60<=rec['ttft_ms']<rec['total_latency_ms'],record=rec)
    for mode in ('error','disconnect','eof'):
        control(mode); r=chat(model,stream=True); rec=record(r); s=state()
        log('F02 '+model+' '+mode,'"error"' in r.text and rec.get('status')=='error' and len(s['requests'])==1,response=r.text,record=rec,upstream_attempts=len(s['requests']))
    for mode in ('normal','invalid','empty','truncated','array'):
        control(mode); r=chat(model,response_format={'type':'json_object'}); rec=record(r)
        expected=200 if mode=='normal' else 422
        log(('F03 ' if mode=='normal' else 'F04 ')+model+' '+mode,r.status_code==expected,status=r.status_code,response=r.json(),record=rec)
        if mode=='invalid':
            log('F07-known-usage-on-failure '+model,rec.get('input_tokens')==17 and rec.get('output_tokens')==9,expected={'input_tokens':17,'output_tokens':9,'total_tokens':26},record=rec)

control(); name='teacher-'+str(int(time.time()))
c.post('/v1/prompts',json={'name':name,'template':'v1 asymmetric {{ x }}'}).raise_for_status()
c.post('/v1/prompts/'+name+'/versions',json={'template':'v2 different {{ x }}'}).raise_for_status()
for model in models:
    for version in (1,2):
        control(); r=chat(model,prompt={'name':name,'version':version,'variables':{'x':'VALUE'}})
        body=state()['requests'][0]['body']; log('F05 '+model+' v'+str(version),r.status_code==200 and ('v'+str(version)) in json.dumps(body) and '{{' not in json.dumps(body),upstream=body)
for label,prompt in [('template',{'name':'absent','version':1}),('version',{'name':name,'version':99}),('variable',{'name':name,'version':1})]:
    control(); r=chat(models[0],prompt=prompt); log('F06 '+label,r.status_code in (404,422) and not state()['requests'],status=r.status_code,response=r.json(),record=record(r))
for model in models:
    for mode,expected,n,delays in [('retry',200,3,[.02,.04]),('503',503,4,[.02,.04,.08]),('429',429,4,[.02,.04,.08]),('400',400,1,[]),('401',502,1,[])]:
        control(mode); r=chat(model); s=state(); rec=record(r)
        log(('F08 ' if mode=='retry' else 'F09 ')+model+' '+mode,r.status_code==expected and len(s['requests'])==n and s['sleeps']==delays,status=r.status_code,attempts=len(s['requests']),sleeps=s['sleeps'],actual_intervals=[round(b['at']-a['at'],4) for a,b in zip(s['requests'],s['requests'][1:])],record=rec)
control(limit=True); a=chat(models[0]); b=chat(models[0]); other=chat(models[1]); limited_record=record(b)
log('F10',[a.status_code,b.status_code,other.status_code]==[200,429,200],statuses=[a.status_code,b.status_code,other.status_code],record=limited_record)
time.sleep(.55); r=chat(models[0]); log('F11',r.status_code==200,status=r.status_code)
root.joinpath('teacher-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('SUMMARY',sum(x['result']=='PASS' for x in results),'PASS',sum(x['result']=='FAIL' for x in results),'FAIL')
