import json,time
from pathlib import Path
import httpx

rows=[]
with httpx.Client(base_url='http://127.0.0.1:8912',headers={'Authorization':'Bearer teacher-real-local'},timeout=70) as c:
    for model in ('deepseek-v4-pro','deepseek-v4-flash'):
        started=time.monotonic()
        r=c.post('/v1/chat/completions',json={'model':model,'messages':[{'role':'user','content':'Reply with exactly OK.'}],'max_tokens':1024})
        rid=r.headers.get('x-request-id')
        rec=c.get('/v1/calls/'+rid).json() if rid else None
        row={'case':'A02','alias':model,'status':r.status_code,'elapsed_ms':round((time.monotonic()-started)*1000,3),'response':r.json(),'record':rec}
        rows.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
Path('/tmp/huncidd-grade/real-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
