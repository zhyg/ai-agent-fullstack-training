# 复现入口

固定仓库 HunCiDD/jksj-aiagent，master ebc9b7d9ee655d93c84fe49e92fd420d68694c6e。
包内 student-source 为固定提交快照，不含教师修改；uv.lock.generated 为 uv sync 产生的未跟踪依赖锁。

```bash
git clone --branch master --single-branch https://github.com/HunCiDD/jksj-aiagent /tmp/huncidd-grade/student
git -C /tmp/huncidd-grade/student checkout ebc9b7d9ee655d93c84fe49e92fd420d68694c6e
```

在 student 根运行 `uv sync`、`uv run pytest -q`。将包内教师脚本解压到 /tmp/huncidd-grade；不改变学生源码。

受控服务（8911）：

```bash
PYTHONPATH=/tmp/huncidd-grade/student/week01/llm-gateway:/tmp/huncidd-grade/student/week01/llm-gateway/tests /tmp/huncidd-grade/student/.venv/bin/uvicorn teacher_server:app --app-dir /tmp/huncidd-grade --host 127.0.0.1 --port 8911
/tmp/huncidd-grade/student/.venv/bin/python /tmp/huncidd-grade/teacher_run.py
```

orb 中应使用 supervisor 托管上述 uvicorn；先确认 health 200 再运行教师脚本。MockTransport 只模拟上游，真实适配器/服务/数据库/HTTP流式响应全部执行，sleep 实际等待并记录；无学生逻辑 monkeypatch。控制入口每次重建桶消除测试残留，限流场景内不重置。

真实服务（8912）：已有 DEEPSEEK_API_KEY 时运行 `sh /tmp/huncidd-grade/start-real.sh`，只能连接脚本声明的官方端点。不得把密钥值写入脚本或日志。运行 `python real_run.py`、`python real_features.py`；每模型普通/JSON/SSE各1个逻辑请求，失败最多额外1次，25秒超时。实际六次均首次成功。

学生 live：在 student 根运行 `GATEWAY_URL=http://127.0.0.1:8912 GATEWAY_API_KEY=teacher-real-local uv run python week01/llm-gateway/scripts/smoke.py`。本次首请求422，退出1，见 student-smoke.log；不能当作成功。gateway 的教师本地访问密码是无外部权限的固定测试值，不是供应商密钥。

学生失败注入：在 student 根运行 `PYTHONPATH=/tmp/huncidd-grade uv run pytest -q -p failure_plugin -k auth_health`。这是故意将学生 fixture 的 Responses 响应改为400，预期一个断言失败、exit1。它不用于业务评分。

证据日志以 JSON results 为最终完整受控轮次；teacher.log 对应41通过5失败。所有扣分可用固定源码行号核对。最后停止两个 supervisor 服务并检查8911/8912不可连接。
