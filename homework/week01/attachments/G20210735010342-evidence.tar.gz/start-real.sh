#!/bin/sh
set -eu
export GATEWAY_API_KEY=teacher-real-local
export GATEWAY_DB_URL=sqlite+aiosqlite:////tmp/huncidd-grade/real.db
export DEEPSEEK_RESPONSES_BASE_URL=https://api.deepseek.com
export DEEPSEEK_MESSAGES_BASE_URL=https://api.deepseek.com/anthropic/v1
export DEEPSEEK_RESPONSES_MODEL=deepseek-v4-pro
export DEEPSEEK_MESSAGES_MODEL=deepseek-flash
export DEEPSEEK_RESPONSES_API_KEY="$DEEPSEEK_API_KEY"
export DEEPSEEK_MESSAGES_API_KEY="$DEEPSEEK_API_KEY"
export DEEPSEEK_RESPONSES_TIMEOUT=25
export DEEPSEEK_MESSAGES_TIMEOUT=25
export GATEWAY_MAX_RETRIES=1
export GATEWAY_DEFAULT_MAX_TOKENS=1024
exec /tmp/huncidd-grade/student/.venv/bin/uvicorn app.main:app --app-dir /tmp/huncidd-grade/student/week01/llm-gateway --host 127.0.0.1 --port 8912
