import asyncio
import json
import time
from pathlib import Path
import httpx
from fastapi import Body
from app.main import create_app
from conftest import make_settings
from dataclasses import replace

state = {'mode': 'normal', 'requests': [], 'sleeps': [], 'released': False}
gate = asyncio.Event()
usage = {'input_tokens': 17, 'output_tokens': 9, 'total_tokens': 26,
         'input_tokens_details': {'cached_tokens': 4}, 'output_tokens_details': {'reasoning_tokens': 3}}

def event(data):
    return ('data: '+json.dumps(data)+'\n\n').encode()

class Stream(httpx.AsyncByteStream):
    def __init__(self, pro, mode): self.pro, self.mode = pro, mode
    async def __aiter__(self):
        yield b': heartbeat\n\n'
        await asyncio.sleep(.08)
        if not self.pro:
            yield event({'type':'message_start','message':{'usage':{'input_tokens':17,'cache_read_input_tokens':4}}})
        yield event({'type':'response.output_text.delta','delta':'alpha'} if self.pro else
                    {'type':'content_block_delta','delta':{'type':'text_delta','text':'alpha'}})
        if self.mode == 'gate': await asyncio.wait_for(gate.wait(), 8)
        if self.mode == 'disconnect': raise httpx.ReadError('controlled disconnect')
        if self.mode == 'error':
            yield event({'type':'error','error':{'message':'controlled error'}})
            return
        if self.mode == 'eof': return
        yield event({'type':'response.output_text.delta','delta':'-omega'} if self.pro else
                    {'type':'content_block_delta','delta':{'type':'text_delta','text':'-omega'}})
        if self.pro:
            yield event({'type':'response.completed','response':{'status':'completed','usage':usage}})
        else:
            yield event({'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':9}})
            yield event({'type':'message_stop'})
    async def aclose(self): pass

async def handler(req):
    body = json.loads(req.content)
    state['requests'].append({'path':req.url.path,'body':body,'at':time.monotonic(),
        'auth_header_names':[k for k in req.headers if k in ('authorization','x-api-key','anthropic-version')]})
    mode = state['mode']; n = len(state['requests']); pro = req.url.path.endswith('/responses')
    if mode in ('503','400','401','429') or (mode == 'retry' and n <= 2):
        return httpx.Response(int(mode) if mode != 'retry' else 503, json={'error':{'message':'controlled'}})
    if body.get('stream'):
        return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Stream(pro,mode))
    text = {'invalid':'not JSON','empty':'','truncated':'{"ok":','array':'[]'}.get(mode,'{"ok":true}')
    if pro:
        data={'id':'teacher-resp','status':'incomplete' if mode=='truncated' else 'completed',
              'output':[{'type':'message','content':[{'type':'output_text','text':text}]}],'usage':usage}
    else:
        data={'id':'teacher-msg','content':[{'type':'text','text':text}],
              'stop_reason':'max_tokens' if mode=='truncated' else 'end_turn',
              'usage':{'input_tokens':17,'output_tokens':9,'cache_read_input_tokens':4}}
    return httpx.Response(200,json=data)

async def sleep(delay):
    state['sleeps'].append(delay)
    await asyncio.sleep(delay)

Path('/tmp/huncidd-grade/mock').mkdir(exist_ok=True)
settings=make_settings(Path('/tmp/huncidd-grade/mock'),pro_rpm=6000,pro_burst=100,flash_rpm=6000,flash_burst=100)
settings=replace(settings,retry_base_delay=.02,retry_max_delay=.2)
app=create_app(settings,upstream_transport=httpx.MockTransport(handler),sleep=sleep)

@app.post('/teacher/control')
async def control(body:dict=Body(...)):
    state.update(mode=body.get('mode','normal'),requests=[],sleeps=[],released=False)
    gate.clear()
    from app.rate_limit import ModelRateLimiter,TokenBucket
    rpm,burst=(120,1) if body.get('limit') else (6000,100)
    app.state.gateway_service.rate_limiter=ModelRateLimiter({m:TokenBucket(rpm,burst) for m in settings.models})
    return {'ok':True}

@app.post('/teacher/release')
async def release():
    state['released']=True; gate.set(); return {'ok':True}

@app.get('/teacher/state')
async def inspect(): return state
