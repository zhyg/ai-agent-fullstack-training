import httpx

def pytest_collection_modifyitems(items):
    for item in items:
        if hasattr(item.module,'MockUpstream'):
            item.module.MockUpstream._responses=lambda self,request,body:httpx.Response(400,json={'error':{'message':'teacher injected failure'}})
