"""Provider protocol adapters."""
