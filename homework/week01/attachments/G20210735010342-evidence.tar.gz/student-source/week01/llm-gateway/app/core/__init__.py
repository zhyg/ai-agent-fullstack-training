"""Shared gateway infrastructure."""
