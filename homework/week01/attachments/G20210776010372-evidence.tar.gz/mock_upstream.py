import asyncio
import json
import time
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI()
state = {}
gate = asyncio.Event()

@app.post('/control')
async def control(req: Request):
    state.clear()
    state.update(await req.json())
    state['calls'] = []
    gate.clear()
    return {'ok': True}

@app.get('/state')
async def inspect():
    return state

@app.post('/release')
async def release():
    gate.set()
    return {'ok': True}

@app.post('/{path:path}')
async def upstream(path: str, req: Request):
    body = await req.json()
    p = 'responses' if path.endswith('responses') else 'messages'
    state.setdefault('calls', []).append({'path': req.url.path, 'body': body, 'time': time.monotonic(),
        'auth_header': 'Authorization' if 'authorization' in req.headers else 'x-api-key'})
    calls = [c for c in state['calls'] if c['path'] == req.url.path]
    mode = state.get('mode', 'normal')
    if mode == 'retry' and len(calls) <= state.get('failures', 2):
        return JSONResponse({'error': 'controlled'}, status_code=state.get('status', 500))
    text = state.get('text', '{"ok":true}')
    if mode == 'repair' and len(calls) > 1:
        text = '{"ok":true}'
    usage = {'input_tokens': 17, 'output_tokens': 9}
    if not body.get('stream'):
        if p == 'responses':
            data = {'id': 'mock-response', 'model': body['model'], 'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}],
                'usage': dict(usage, input_tokens_details={'cached_tokens': 4}, output_tokens_details={'reasoning_tokens': 3}),
                'incomplete_details': {}, 'status': 'completed'}
            if mode == 'null-details':
                data['incomplete_details'] = None
        else:
            data = {'id': 'mock-message', 'model': body['model'], 'content': [{'type': 'text', 'text': text}],
                'usage': dict(usage, cache_read_input_tokens=4), 'stop_reason': 'end_turn'}
        return JSONResponse(data, headers={'x-request-id': 'mock-response-id', 'request-id': 'mock-message-id'})
    async def generate():
        def ev(data):
            return ('data: ' + json.dumps(data) + '\n\n').encode()
        if p == 'responses':
            if mode == 'empty-first':
                yield ev({'type': 'response.output_text.delta', 'delta': ''})
                await asyncio.sleep(.25)
            yield ev({'type': 'response.output_text.delta', 'delta': '甲'})
        else:
            yield ev({'type': 'message_start', 'message': {'id': 'mock-stream-id', 'usage': dict(usage, cache_read_input_tokens=4)}})
            yield ev({'type': 'content_block_delta', 'delta': {'type': 'text_delta', 'text': '甲'}})
        if mode in ('gate', 'error', 'eof'):
            await gate.wait()
        if mode == 'eof':
            return
        if mode == 'error':
            yield ev({'type': 'response.failed', 'response': {'error': {'message': 'controlled interruption'}}} if p == 'responses' else {'type': 'error', 'error': {'type': 'overloaded_error', 'message': 'controlled interruption'}})
            return
        if mode == 'transport':
            raise RuntimeError('controlled socket close')
        if p == 'responses':
            yield ev({'type': 'response.completed', 'response': {'usage': dict(usage, input_tokens_details={'cached_tokens':4}, output_tokens_details={'reasoning_tokens':3}), 'incomplete_details': {}}})
        else:
            yield ev({'type': 'message_delta', 'usage': {'output_tokens':9}, 'delta': {'stop_reason': 'end_turn'}})
            yield ev({'type': 'message_stop'})
    return StreamingResponse(generate(), media_type='text/event-stream')
