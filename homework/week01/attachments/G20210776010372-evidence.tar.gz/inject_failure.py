import pytest

@pytest.fixture(autouse=True)
def inject_bad_usage(monkeypatch):
    from app.adapters.openai_responses import OpenAIResponsesAdapter
    from app.core.types import Usage
    monkeypatch.setattr(OpenAIResponsesAdapter, '_normalize_usage', staticmethod(lambda u: Usage()))
