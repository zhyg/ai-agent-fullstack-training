"""Official DeepSeek only; key is read by unchanged student registry from environment.
No headers or environment values are persisted. Original models.yaml is retained.
"""
import asyncio
import json
import os
import time
from pathlib import Path
os.environ['DATABASE_URL']='sqlite+aiosqlite:////tmp/grade-10372/real.db'
os.environ['MODELS_PATH']='/tmp/student-10372/work/01/homework/models.yaml'
from app.main import app
import httpx

async def main():
    results=[]
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app,raise_app_exceptions=False),base_url='http://student',timeout=35) as c:
            for model in ['deepseek-v4-pro','deepseek-v4-flash']:
                for kind in ['normal','stream','schema']:
                    body={'model':model,'messages':[{'role':'user','content':'Return JSON only: {"ok":true}. No explanation.'}], 'max_tokens':256,'timeout_ms':12000,'trace_id':'real-'+model+'-'+kind}
                    if kind=='schema':
                        body['response_schema']={'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}
                    if kind=='stream': body['stream']=True
                    t=time.monotonic()
                    try:
                        r=await asyncio.wait_for(c.post('/v1/chat/stream' if kind=='stream' else '/v1/chat',json=body),40)
                        result=dict(model=model,kind=kind,status=r.status_code,elapsed_ms=round((time.monotonic()-t)*1000),body=r.text)
                    except Exception as e:
                        result=dict(model=model,kind=kind,error=type(e).__name__,elapsed_ms=round((time.monotonic()-t)*1000))
                    results.append(result)
                    print(json.dumps(result,ensure_ascii=False),flush=True)
    Path('/tmp/grade-10372/real-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

asyncio.run(main())
