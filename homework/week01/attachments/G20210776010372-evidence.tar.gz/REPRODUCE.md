# G20210776010372 教师证据复现说明

对象：shanli/agent-dev，main，b290f537174f245fc4ec068a1dcff38d71f36f74，work/01/homework。
日期：2026-11-08，Asia/Singapore。所有脚本在学生仓库外，不修改学生逻辑。

## 环境与启动

1. `git clone --branch main https://github.com/shanli/agent-dev /tmp/student-10372`
2. `git -C /tmp/student-10372 checkout b290f537174f245fc4ec068a1dcff38d71f36f74`
3. 将证据包解压到 `/tmp/grade-10372`；进入学生的 `work/01/homework`。
4. `python -m venv /tmp/grade-10372/venv`
5. `/tmp/grade-10372/venv/bin/pip install -e .`（README 原命令：成功，install.log）。
6. `/tmp/grade-10372/venv/bin/python -m pytest tests/`（最初缺 pytest，tests-initial.log）。
7. `/tmp/grade-10372/venv/bin/pip install aiosqlite pytest pytest-asyncio respx greenlet`
8. `/tmp/grade-10372/venv/bin/python -m pytest tests/ -q`（63 passed）。完整版本见 requirements-lock.txt。

README 允许 SQLite；独立数据库替代其随仓库提交的 llm_dev.db，不访问原学生数据。
原配置：pro Responses 官方 /v1；flash Messages 官方 /anthropic；双向候选池；RPM 60/300。
受控配置 mock-models.yaml：只把 base_url 改成本地上游、凭据变量改成无效占位值、候选池置空以隔离每模型，flash RPM 改成60；TPM统一100000。
这不是对原配置可用性的证明。真实调用脚本保留原 models.yaml、候选池和官方模型映射。

## 受控 HTTP 验收（只允许本地模拟，不消耗官方配额）

从学生作业目录启动两个独立服务。普通终端可在两窗口前台运行；Amp orb 使用下述监督服务：

```bash
amp orb service start grade10372-mock --command '/tmp/grade-10372/venv/bin/python -m uvicorn mock_upstream:app --app-dir /tmp/grade-10372 --host 127.0.0.1 --port 8137' --port 8137
amp orb service start grade10372-gateway --command 'TEACHER_MOCK_KEY=teacher-dummy DATABASE_URL=sqlite+aiosqlite:////tmp/grade-10372/teacher-v2.db MODELS_PATH=/tmp/grade-10372/mock-models.yaml /tmp/grade-10372/venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8138' --port 8138
curl -s http://127.0.0.1:8138/health
/tmp/grade-10372/venv/bin/python /tmp/grade-10372/teacher.py
/tmp/grade-10372/venv/bin/python /tmp/grade-10372/check_results.py
```

使用新的 teacher-v2.db 启动，避免模板版本及限流状态受上一轮影响。teacher.py 是事实采集器，退出0不代表通过；check_results.py 按独立预期判定，现状应退出1（38 PASS/12 FAIL），不可按通过率换算分数。
上游的 `/control` 重置测试模式；`/release` 仅在下游已收到首非空正文后释放终态。传输强制断开会在 mock 服务产生预期异常，不代表教师设施故障。

F12 人工制造失败：

```bash
PYTHONPATH=/tmp/grade-10372 /tmp/grade-10372/venv/bin/python -m pytest tests/test_adapters.py -q -p inject_failure
```

仅外部 pytest fixture 把 Responses 用量解析替换为空，学生测试应退出1，显示1 failed/15 passed；不保留对学生文件的改动。

## 官方真实调用

只使用已在环境中的 DEEPSEEK_API_KEY；不要写入脚本或打印值。
`real.py` 使用原模型配置、普通/流式/response_schema三场景，单请求12秒预算、外围40秒截止；无额外SDK重试。
`capture_real.py` 对同样六场景增加只读传输旁路，记录路径、请求体、响应体、允许的请求ID及耗时，不记录鉴权头。
旁路只对存档副本解压gzip，不改变传递给学生解析器的原始字节和时序。曾有一轮gzip归档显示不正确，修正旁路后最终一轮结果保留在 capture-real.json；这不是学生缺陷，未扣分。real-results.json 是未加观察器的对照。

```bash
/tmp/grade-10372/venv/bin/python /tmp/grade-10372/real.py
/tmp/grade-10372/venv/bin/python /tmp/grade-10372/capture_real.py
```

无须继续重试已确认的客户端解析错误。没有上游500/超时阻塞；学生网关500是官方200的null字段被误解析，不能当作环境故障。
若复验遇到上游500/超时，仅保留有限尝试，标未验证/暂评，不以环境失败扣代码分。

## 证据文件

- teacher-results.json / teacher.log：每用例请求、响应、上游计数与SQL账本快照。
- teacher-verdicts.json / .log：50项判定（重复协议输入仅作证据，不重复扣分）。
- real-results.json / real.log：无观察器的官方请求对照。
- capture-real.json / .log：最终一轮官方原始协议和异常堆栈。
- real-ledger.json：初始真实调用账本；capture-real-ledger.json：最终一轮每trace最新账本（缺pro记录本身是null异常的后果，不另扣）。
- source-lines.txt：固定提交带行号的源码与README依据，不含.env、学生数据库或Git凭据。
- 首次教师mock忘设占位凭据导致Bearer空值，已修正教师环境；最终受控结果不包含该次设施误配，不作学生扣分证据。
- install.log / tests-initial.log / student-tests.log / injected-tests.log：安装和学生脚本结果。

## 收尾

`amp orb service stop grade10372-gateway`、`amp orb service stop grade10372-mock`。
只归档列出的脱敏文本；不归档venv、数据库、.env、环境变量、真实密钥或学生整个仓库。
secret-scan.json 记录对解包文件及两份报告逐文件扫描真实环境凭据与常见凭据模式的结果，不记录值。
