"""Observe unchanged student adapter transports, without replacing request data."""
import asyncio
import gzip
import json
import os
import time
import traceback
from pathlib import Path
os.environ['DATABASE_URL']='sqlite+aiosqlite:////tmp/grade-10372/capture-real.db'
os.environ['MODELS_PATH']='/tmp/student-10372/work/01/homework/models.yaml'
import httpx
from app.main import app

records=[]
class Tee(httpx.AsyncByteStream):
    def __init__(self, stream, rec): self.stream,self.rec=stream,rec
    async def __aiter__(self):
        chunks=[]
        try:
            async for b in self.stream:
                chunks.append(b)
                yield b
        finally:
            raw=b''.join(chunks)
            if raw.startswith(b'\x1f\x8b'):
                raw=gzip.decompress(raw)
            self.rec['response_body']=raw.decode('utf-8', errors='replace')
            self.rec['elapsed_ms']=round((time.monotonic()-self.rec['started'])*1000)
    async def aclose(self): await self.stream.aclose()

async def observe(response):
    req=response.request
    rec=dict(url=str(req.url),method=req.method,request_body=json.loads(req.content),status=response.status_code,
        request_ids={k:v for k,v in response.headers.items() if k in ('x-request-id','request-id','x-ds-request-id')},started=time.monotonic())
    records.append(rec)
    response.stream=Tee(response.stream,rec)

async def main():
    results=[]
    async with app.router.lifespan_context(app):
        for adapter in app.state.registry._adapters.values():
            adapter._client.event_hooks['response']=[observe]
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app,raise_app_exceptions=True),base_url='http://student') as c:
            for model in ['deepseek-v4-pro','deepseek-v4-flash']:
                for kind in ['normal','stream','schema']:
                    body={'model':model,'messages':[{'role':'user','content':'Reply with the JSON object having key ok and boolean value true.'}],'max_tokens':256,'timeout_ms':12000,'trace_id':'capture-'+model+'-'+kind}
                    if kind=='schema':body['response_schema']={'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}
                    if kind=='stream':body['stream']=True
                    t=time.monotonic()
                    try:
                        r=await asyncio.wait_for(c.post('/v1/chat/stream' if kind=='stream' else '/v1/chat',json=body),40)
                        result=dict(model=model,kind=kind,status=r.status_code,body=r.text)
                    except Exception:
                        result=dict(model=model,kind=kind,exception=traceback.format_exc())
                    result['elapsed_ms']=round((time.monotonic()-t)*1000)
                    results.append(result)
                    print(json.dumps(result,ensure_ascii=False),flush=True)
    Path('/tmp/grade-10372/capture-real.json').write_text(json.dumps(dict(requests=records,results=results),ensure_ascii=False,indent=2))

asyncio.run(main())
