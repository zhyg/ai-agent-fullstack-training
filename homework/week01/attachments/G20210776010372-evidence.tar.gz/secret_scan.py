"""Scan evidence and reports without ever printing credential values."""
import base64
import json
import os
import re
import tarfile
from pathlib import Path
from urllib.parse import quote

root=Path('/tmp/grade-10372/evidence')
repo=Path('/home/user/workspace/repo')
reports=[repo/'homework/week01/G20210776010372.md',repo/'homework/week01/attachments/G20210776010372.md']
archive=repo/'homework/week01/attachments/G20210776010372-evidence.tar.gz'
# This variable lists credential *names*, not values; its metadata is public code text.
secrets={k:v for k,v in os.environ.items() if k!='AMP_SECRET_ENV_NAMES' and re.search(r'(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)',k,re.I) and len(v)>=12}
assert 'DEEPSEEK_API_KEY' in secrets, 'Required credential absent; do not claim actual-key scan'
needles=set()
for value in secrets.values():
    needles.update([value.encode(),quote(value,safe='').encode(),base64.b64encode(value.encode())])
patterns=[re.compile(rb'sk-[A-Za-z0-9_-]{20,}'),re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')]
hits=[]
checked=0
def scan(name,data):
    global checked
    checked+=1
    if any(s in data for s in needles) or any(p.search(data) for p in patterns):hits.append(name)
for path in list(root.rglob('*'))+reports:
    if path.is_file():scan(str(path.relative_to(root)) if path.is_relative_to(root) else path.name,path.read_bytes())
members=0
if archive.exists():
    with tarfile.open(archive) as tar:
        for m in tar.getmembers():
            if m.isfile():
                members+=1
                scan('tar:'+m.name,tar.extractfile(m).read())
result=dict(files_scanned=checked,archive_members_scanned=members,environment_credentials_checked=len(secrets),deepseek_actual_value_checked=True,encodings=['literal','URL encoded','base64'],credential_values_logged=False,hits=hits,result='PASS' if not hits else 'FAIL')
(root/'secret-scan.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
raise SystemExit(bool(hits))
