import json
from pathlib import Path

root=Path('/tmp/grade-10372')
data=json.loads((root/'teacher-results.json').read_text())
checks=[]
def check(case,passed,expected,actual):
    checks.append(dict(case=case,result='PASS' if passed else 'FAIL',expected=expected,actual=actual))
for r in data:
    name=r['case']; model=r.get('model',''); tag=name+'/'+model
    if name=='A03-normal':
        check(tag,r['status']==200 and r['response']['usage']['input_tokens']==17,'200, input=17',r['status'])
    elif name=='A04':
        check(name,r['status']==404 and not r['calls'],'404, no upstream',r['status'])
    elif name.startswith('F01-F02-F07-'):
        mode=name[len('F01-F02-F07-'):]; chunks=[x['chunk'] for x in r['received']]; types=[c['type'] for c in chunks]
        if mode=='gate':
            check('F01/'+model,r['first_before_release'] and types==['text_delta','usage','done'],'text arrives before terminal release; done',types)
            usage=chunks[-2]['usage']
            check('F07-stream-usage/'+model,usage['input_tokens']==17 and usage['cached_tokens']==4,'input=17,cached=4',usage)
        if mode in ('error','eof','transport'):
            check('F02-'+mode+'/'+model,'error' in types and r['ledger'][0]['final_state']=='error' and len(r['calls'])==1,'explicit error, failure ledger, exactly 1 upstream',dict(types=types,state=r['ledger'][0]['final_state'],calls=len(r['calls'])))
        if mode=='empty-first' and model.endswith('pro'):
            valid=next(z for z in r['received'] if z['chunk'].get('delta'))
            observed=(valid['at']-r['started'])*1000
            stored=r['ledger'][0]['ttft_ms']
            check('F07-TTFT',abs(stored-observed)<100,'TTFT near first nonempty delta, not empty delta',dict(valid_delta_ms=observed,stored_ms=stored))
    elif name=='F03-F04-response_format':
        try: json.loads(r['response'].get('content','')); valid=True
        except (ValueError,AttributeError): valid=False
        check('F03-response_format/'+model,r['status']>=400 or valid,'valid JSON success or explicit rejection',r['response'])
    elif name.startswith('F03-F04-'):
        kind=name[len('F03-F04-'):]
        expected=200 if kind in ('valid','repair') else 502
        check('F04-'+kind+'/'+model,r['status']==expected and len(r['calls'])==(1 if kind=='valid' else 2),f'{expected}, bounded validation/repair',dict(status=r['status'],calls=len(r['calls'])))
        if kind in ('repair','invalid'):
            ledger=r['ledger'][0]
            check('F07-known-attempt-usage-'+kind+'/'+model,ledger['input_tokens']==34 and ledger['output_tokens']==18,'two known attempts input=34 output=18, or explicit incomplete accounting',dict(input=ledger['input_tokens'],output=ledger['output_tokens'],state=ledger['final_state']))
    elif name=='A03-null-details':
        check(name,r['status']==200,'valid completed response with incomplete_details=null accepted',dict(status=r['status'],ledger=r['ledger']))
    elif name=='F05-F06':
        ref=r['ref']; valid='variables' in ref
        if valid:
            text=r['calls'][0]['body']['input'][0]['content']
            check('F05-v'+str(ref['version']),r['status']==200 and text==('v1 Alice' if ref['version']==1 else 'v2 Bob'),'explicit old/new version rendered into upstream',text)
        else: check('F06',r['status'] in (404,422) and not r['calls'],'clear missing-item error; no upstream',r['status'])
    elif name=='F08-F09':
        expected=3 if r['upstream_status'] in (429,500) else 1
        wanted_status = 200 if r['failures']==2 else (502 if r['upstream_status']==500 else r['upstream_status'])
        timing_ok = not r['gaps'] or (.5 <= r['gaps'][0] <= .85 and 1 <= r['gaps'][1] <= 1.35)
        check(tag+str(r['upstream_status'])+'/'+str(r['failures']),r['actual_attempts']==expected and r['status']==wanted_status and timing_ok,'actual transport attempts='+str(expected)+'; documented additive jitter +100ms transport tolerance',dict(attempts=r['actual_attempts'],status=r['status'],gaps=r['gaps']))
    elif name=='F10':check(name,r['A_status']==429 and r['B_status']==200,'A 429 and B 200',dict(A=r['A_status'],B=r['B_status']))
    elif name=='F11':check(name,r['status']==200,'quota restored after 1.1s',r['status'])
(root/'teacher-verdicts.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
for c in checks:print(c['result'],c['case'],json.dumps(c['actual'],ensure_ascii=False))
print('SUMMARY',sum(c['result']=='PASS' for c in checks),'PASS',sum(c['result']=='FAIL' for c in checks),'FAIL')
raise SystemExit(any(c['result']=='FAIL' for c in checks))
