import asyncio
import json
import sqlite3
import time
from pathlib import Path
import httpx

ROOT = Path('/tmp/grade-10372')
results = []
MODELS = ['deepseek-v4-pro', 'deepseek-v4-flash']
SCHEMA = {'type':'object', 'properties':{'ok':{'type':'boolean'}}, 'required':['ok']}

def record(name, **data):
    results.append(dict(case=name, **data))
    print(json.dumps(results[-1], ensure_ascii=False), flush=True)

def rows(trace):
    with sqlite3.connect(ROOT/'teacher-v2.db') as db:
        db.row_factory = sqlite3.Row
        return [dict(r) for r in db.execute('select * from llm_call_records where trace_id=?', (trace,))]

async def main():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8138', timeout=15) as c, httpx.AsyncClient(base_url='http://127.0.0.1:8137', timeout=15) as u:
        async def setup(**kw):
            await u.post('/control', json=kw)
        async def chat(model, trace, **kw):
            body = dict(model=model, trace_id=trace, messages=[{'role':'system','content':'System test'}, {'role':'user','content':'JSON please'}], max_tokens=32)
            body.update(kw)
            r = await c.post('/v1/chat', json=body)
            try: data = r.json()
            except ValueError: data = r.text
            return r.status_code, data
        for model in MODELS:
            await setup()
            status, data = await chat(model, 'normal-'+model)
            record('A03-normal', model=model, status=status, response=data, upstream=(await u.get('/state')).json()['calls'], ledger=rows('normal-'+model))
        await setup()
        status, data = await chat('unknown', 'A04')
        record('A04', status=status, response=data, calls=(await u.get('/state')).json()['calls'], ledger=rows('A04'))
        for model in MODELS:
            for mode in ['gate', 'error', 'eof', 'transport', 'empty-first']:
                await setup(mode=mode)
                trace = mode+'-'+model
                received = []
                first = asyncio.Event()
                async def consume():
                    async with c.stream('POST', '/v1/chat/stream', json={'model':model, 'messages':[{'role':'user','content':'hi'}], 'stream':True, 'trace_id':trace, 'max_tokens':32}) as r:
                        async for line in r.aiter_lines():
                            if line.startswith('data: '):
                                obj = json.loads(line[6:])
                                received.append(dict(at=time.monotonic(), chunk=obj))
                                if obj.get('delta'):
                                    first.set()
                t0 = time.monotonic()
                task = asyncio.create_task(consume())
                await asyncio.wait_for(first.wait(), 3)
                before_release = not task.done()
                released = time.monotonic()
                await u.post('/release')
                await task
                await asyncio.sleep(.04)
                record('F01-F02-F07-'+mode, model=model, first_before_release=before_release, started=t0, released=released, received=received, calls=(await u.get('/state')).json()['calls'], ledger=rows(trace))
        for model in MODELS:
            for name, options, body in [
                ('response_format', {'text':'not JSON'}, {'response_format':{'type':'json_object'}}),
                ('valid', {}, {'response_schema':SCHEMA}),
                ('invalid', {'text':'not JSON'}, {'response_schema':SCHEMA}),
                ('empty', {'text':''}, {'response_schema':SCHEMA}),
                ('truncated', {'text':'{"ok":'}, {'response_schema':SCHEMA}),
                ('wrong-type', {'text':'{"ok":"yes"}'}, {'response_schema':SCHEMA}),
                ('repair', {'mode':'repair','text':'not JSON'}, {'response_schema':SCHEMA}),
            ]:
                await setup(**options)
                trace=name+'-'+model
                status, data=await chat(model, trace, **body)
                record('F03-F04-'+name, model=model, status=status, response=data, calls=(await u.get('/state')).json()['calls'], ledger=rows(trace))
        await setup(mode='null-details')
        status, data = await chat(MODELS[0], 'null-details')
        record('A03-null-details', status=status, response=data, ledger=rows('null-details'))
        await setup()
        for template in ['v1 {{name}}', 'v2 {{name}}']:
            r=await c.post('/v1/prompts/teacher/versions', json={'template':template,'variables':['name']})
            record('F05-create', status=r.status_code, response=r.json())
        await c.post('/v1/prompts/teacher/versions/2/activate')
        for ref in [dict(name='teacher',version=1,variables={'name':'Alice'}),dict(name='teacher',version=2,variables={'name':'Bob'}),dict(name='missing'),dict(name='teacher',version=99),dict(name='teacher',version=1)]:
            await setup()
            status,data=await chat(MODELS[0], 'prompt-'+str(ref), prompt_ref=ref)
            record('F05-F06', ref=ref, status=status, response=data, calls=(await u.get('/state')).json()['calls'])
        for model in MODELS:
            for status_code, failures in [(500,2),(500,99),(400,99),(401,99),(429,2)]:
                await setup(mode='retry',status=status_code,failures=failures)
                trace=f'retry-{model}-{status_code}-{failures}'
                status,data=await chat(model,trace)
                calls=(await u.get('/state')).json()['calls']
                record('F08-F09', model=model, upstream_status=status_code, failures=failures, status=status, response=data, actual_attempts=len(calls), gaps=[b['time']-a['time'] for a,b in zip(calls,calls[1:])], ledger=rows(trace))
        await setup()
        consumed=0
        while consumed<65:
            status,data=await chat(MODELS[0],f'limit-{consumed}')
            consumed+=1
            if status==429: break
        bstatus,bdata=await chat(MODELS[1], 'limit-B')
        record('F10', A_status=status, A_response=data, B_status=bstatus,B_response=bdata,requests_until_limit=consumed)
        await asyncio.sleep(1.1)
        status,data=await chat(MODELS[0],'recovery')
        record('F11', waited_s=1.1,status=status,response=data)
    (ROOT/'teacher-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

asyncio.run(main())
