     1	# LLM 统一模型调用服务
     2	
     3	一个模型网关：上层调用方只面对**一套 API**，下层可以是 **OpenAI Responses**、**OpenAI Chat Completions**、**Anthropic Messages** 三种互不相容的协议。按请求里的 `model` 字段动态路由到对应适配器，把鉴权、请求体结构、流式事件、返回格式、Token 统计口径的差异全部屏蔽掉。
     4	
     5	```
     6	                    POST /v1/chat  {model, input, stream, response_format, template}
     7	                              │
     8	        ┌─────────────────────┼─────────────────────┐
     9	        │  统一抽象层 Gateway  │                     │
    10	        │  ① 路由（model→协议）② 限流（按模型独立桶）│
    11	        │  ③ 模板渲染+版本     ④ 重试（指数退避×3）  │
    12	        │  ⑤ 结构化校验       ⑥ 观测（Token/延迟）  │
    13	        └─────────────────────┬─────────────────────┘
    14	                              │  适配器模式 Adapter
    15	        ┌─────────────────────┼─────────────────────┐
    16	        ▼                     ▼                     ▼
    17	 OpenAIResponses      OpenAIChatCompletions   AnthropicMessages
    18	 /v1/responses        /v1/chat/completions    /v1/messages
    19	 Bearer xxx           Bearer xxx              x-api-key + anthropic-version
    20	 instructions         messages[system]        system
    21	 max_output_tokens    max_tokens              max_tokens
    22	 text.format=schema   response_format         tools + tool_choice（强制）
    23	```
    24	
    25	---
    26	
    27	## 1. 快速开始
    28	
    29	```bash
    30	cd llm-gateway
    31	pip install -r requirements.txt
    32	
    33	cp .env.example .env      # 填入真实 endpoint / key
    34	bash scripts/run.sh       # 或：uvicorn app.main:app --port 8000
    35	```
    36	
    37	服务默认监听 `http://127.0.0.1:8000`，交互文档：`http://127.0.0.1:8000/docs`。
    38	
    39	### 最小配置（.env）
    40	
    41	```bash
    42	# 模型 A：OpenAI Responses 协议
    43	MODEL_A_ALIAS=deepseek-v4-pro
    44	MODEL_A_PROTOCOL=openai_responses
    45	MODEL_A_BASE_URL=https://api.openai.com/v1      # 网关自动拼 /responses
    46	MODEL_A_API_KEY=<REDACTED>
    47	MODEL_A_UPSTREAM_MODEL=gpt-4o-mini
    48	
    49	# 模型 B：Anthropic Messages 协议
    50	MODEL_B_ALIAS=deepseek-v4-flash
    51	MODEL_B_PROTOCOL=anthropic_messages
    52	MODEL_B_BASE_URL=https://api.anthropic.com      # 网关自动拼 /v1/messages
    53	MODEL_B_API_KEY=<REDACTED>
    54	MODEL_B_UPSTREAM_MODEL=claude-sonnet-4-5
    55	```
    56	
    57	> **关于模型名的现实约束**：DeepSeek 官方目前只提供 **OpenAI Chat Completions 兼容**协议，不提供 Responses API，也不提供 Anthropic Messages 协议。因此：
    58	> - 若你的 "DeepSeek v4 pro" 走 DeepSeek 官方，请把 `MODEL_A_PROTOCOL` 改成 `openai_chat_completions`、`MODEL_A_BASE_URL=https://api.deepseek.com/v1`；
    59	> - "DeepSeek V4 flash → Anthropic Messages" 这一路需要指向**真正提供 Anthropic 协议**的服务（Anthropic 官方 Claude 系列，或兼容该协议的中转）；
    60	> - 无论如何，**两个模型的 protocol 必须不同**才能达成训练目标。三种协议可任意两两组合。
    61	
    62	---
    63	
    64	## 2. 协议差异对照（适配器里被抹平的部分）
    65	
    66	| 能力 | OpenAI Responses | OpenAI Chat Completions | Anthropic Messages |
    67	|---|---|---|---|
    68	| 鉴权 | `Authorization: Bearer` | `Authorization: Bearer` | `x-api-key` + `anthropic-version` |
    69	| 系统提示 | `instructions` | `messages[0].role=system` | `system` |
    70	| 长度字段 | `max_output_tokens` | `max_tokens` | `max_tokens`（必填） |
    71	| 结构化输出 | `text.format={json_schema}` | `response_format` | 强制 `tool_choice`（json_schema→工具入参）；`json_object` 退化成 assistant prefill `{` |
    72	| 流式事件 | `response.output_text.delta` / `response.completed` | `choices[0].delta.content` + `stream_options.include_usage` | `content_block_delta(text_delta / input_json_delta)` + `message_delta(usage)` |
    73	| Token 字段 | `input_tokens/output_tokens`、`*.details.cached_tokens`、`reasoning_tokens` | `prompt_tokens/completion_tokens` + details | `input_tokens/output_tokens`、`cache_read_input_tokens` |
    74	
    75	**统一输出**：无论走哪条协议，`/v1/chat` 的响应结构与 SSE 事件结构完全一致。
    76	
    77	---
    78	
    79	## 3. curl 示例
    80	
    81	### 3.1 非流式调用（两种协议各一次）
    82	
    83	```bash
    84	# 模型 A（OpenAI Responses）
    85	curl -s http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' -d '{
    86	  "model": "deepseek-v4-pro",
    87	  "system": "你是一个简洁的助手",
    88	  "input": "用一句话解释什么是令牌桶限流",
    89	  "temperature": 0.3,
    90	  "max_output_tokens": 300
    91	}'
    92	
    93	# 模型 B（Anthropic Messages）
    94	curl -s http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' -d '{
    95	  "model": "deepseek-v4-flash",
    96	  "input": "用一句话解释什么是指数退避",
    97	  "max_output_tokens": 300
    98	}'
    99	```
   100	
   101	响应（两个协议的字段名完全一致）：
   102	
   103	```json
   104	{
   105	  "id": "req_xxx", "object": "llm.response",
   106	  "model": "deepseek-v4-pro", "upstream_model": "gpt-4o-mini",
   107	  "protocol": "openai_responses",
   108	  "output_text": "令牌桶……",
   109	  "structured": null,
   110	  "finish_reason": "completed",
   111	  "usage": {"input_tokens": 106, "output_tokens": 53, "total_tokens": 159,
   112	            "cached_tokens": 11, "reasoning_tokens": 0, "tool_tokens": 0},
   113	  "latency": {"first_token_ms": null, "upstream_ms": 812.5, "total_ms": 815.2},
   114	  "attempts": 1,
   115	  "template": null
   116	}
   117	```
   118	
   119	### 3.2 流式输出（SSE，`stream=true`）
   120	
   121	```bash
   122	curl -N http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' -d '{
   123	  "model": "deepseek-v4-flash",
   124	  "input": "分三点说明网关的价值",
   125	  "stream": true,
   126	  "max_output_tokens": 400
   127	}'
   128	```
   129	
   130	```text
   131	event: response.start
   132	data: {"id":"req_xxx","model":"deepseek-v4-flash","protocol":"anthropic_messages",...}
   133	
   134	event: response.delta
   135	data: {"delta":"1."}
   136	
   137	event: response.delta
   138	data: {"delta":" 统一协议……"}
   139	
   140	event: response.stop
   141	data: {"finish_reason":"stop","usage":{"input_tokens":106,"output_tokens":66,...},
   142	       "latency":{"first_token_ms":54.18,"total_ms":352.4},"attempts":1}
   143	```
   144	
   145	三种协议的流式输出都是这三类事件（`start` / `delta` / `stop`），Anthropic 的 `input_json_delta` 会在块结束时合并成一次完整 JSON 再下发，保证下游拿到的永远是合法 JSON。
   146	
   147	### 3.3 结构化输出
   148	
   149	```bash
   150	curl -s http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' -d '{
   151	  "model": "deepseek-v4-pro",
   152	  "input": "抽取人物信息：张三，28岁，擅长 Python 和 Go，资深网关工程师。",
   153	  "response_format": {
   154	    "type": "json_schema",
   155	    "name": "person",
   156	    "json_schema": {
   157	      "type": "object",
   158	      "properties": {
   159	        "name": {"type": "string"},
   160	        "age": {"type": "integer"},
   161	        "skills": {"type": "array", "items": {"type": "string"}},
   162	        "summary": {"type": "string"}
   163	      },
   164	      "required": ["name", "age", "skills"],
   165	      "additionalProperties": false
   166	    }
   167	  },
   168	  "temperature": 0.2
   169	}'
   170	```
   171	
   172	响应里 `structured` 是**已通过 jsonschema 校验**的对象；不满足 schema 或不是合法 JSON 时返回 `structured_output_invalid`（502），不会出现"看着像 JSON 但字段缺失"的静默失败。
   173	
   174	### 3.4 提示词模板与版本引用
   175	
   176	```bash
   177	# 创建模板（自动成为 v1）
   178	curl -s -X POST http://127.0.0.1:8000/v1/templates -H 'Content-Type: application/json' -d '{
   179	  "name": "summarize",
   180	  "description": "文本摘要",
   181	  "system": "你是内容分析助手",
   182	  "content": "请总结：{{text}}",
   183	  "changelog": "初版"
   184	}'
   185	
   186	# 迭代新版本（自动成为 v2，v1 永久保留可回退）
   187	curl -s -X POST http://127.0.0.1:8000/v1/templates/summarize/versions -H 'Content-Type: application/json' -d '{
   188	  "content": "请总结：{{text}}\n要求：三个要点，语气{{tone}}",
   189	  "changelog": "加语气变量"
   190	}'
   191	
   192	# 渲染指定版本（不消耗 token，纯本地）
   193	curl -s -X POST http://127.0.0.1:8000/v1/templates/summarize/render -H 'Content-Type: application/json' -d '{
   194	  "version": 1, "variables": {"text": "网关要做统一抽象层"}
   195	}'
   196	
   197	# 调用时引用版本：name / name@2 / name@latest
   198	curl -s http://127.0.0.1:8000/v1/chat -H 'Content-Type: application/json' -d '{
   199	  "model": "deepseek-v4-pro",
   200	  "template": "summarize@2",
   201	  "variables": {"text": "网关要做统一抽象层", "tone": "专业"},
   202	  "max_output_tokens": 400
   203	}'
   204	```
   205	
   206	响应中的 `template` 字段回显 `{name, version, rendered_chars}`，方便追溯"这次到底用的哪一版提示词"。缺少变量时返回 `400 template_render_error` 并列出缺失变量名。
   207	
   208	### 3.5 可观测性
   209	
   210	```bash
   211	curl -s http://127.0.0.1:8000/v1/metrics          # JSON：分类 Token、延迟分位、错误/重试/限流计数
   212	curl -s http://127.0.0.1:8000/v1/metrics/prometheus   # Prometheus 文本格式
   213	curl -s "http://127.0.0.1:8000/v1/calls?limit=10"     # 最近 N 次调用明细
   214	```
   215	
   216	每次调用的明细同时以 JSONL 追加落盘到 `logs/calls.jsonl`，含：
   217	
   218	- `usage`：`input_tokens / output_tokens / total_tokens / cached_tokens / reasoning_tokens / tool_tokens`
   219	- `latency`：`first_token_ms`（首 Token 延迟，流式才有）、`upstream_ms`、`total_ms`
   220	- `attempts`：实际尝试次数（>1 说明发生了重试）
   221	- `error_code`、`model`、`protocol`、`stream`、`template`
   222	
   223	### 3.6 错误码、重试、限流
   224	
   225	```bash
   226	# 触发限流（连续快速请求打满令牌桶）
   227	for i in $(seq 1 8); do
   228	  curl -s -o /dev/null -w "%{http_code} " http://127.0.0.1:8000/v1/chat \
   229	    -H 'Content-Type: application/json' -d '{"model":"deepseek-v4-pro","input":"hi","max_output_tokens":16}'
   230	done
   231	# -> 200 200 429 429 ... ，429 响应带 Retry-After 头
   232	```
   233	
   234	统一错误结构：
   235	
   236	```json
   237	{"error": {"code": "rate_limited", "message": "模型级限流触发", "type": "GatewayError",
   238	           "http_status": 429, "retryable": false, "upstream_status": null,
   239	           "details": {"retry_after_s": 1.83}, "request_id": "req_xxx"}}
   240	```
   241	
   242	| code | HTTP | 可重试 | 含义 |
   243	|---|---|---|---|
   244	| `invalid_request` / `invalid_json_schema` | 400 | 否 | 请求体或 schema 非法 |
   245	| `template_not_found` / `template_version_not_found` | 404 | 否 | 模板或版本不存在 |
   246	| `template_render_error` | 400 | 否 | 缺少模板变量 |
   247	| `model_not_found` | 404 | 否 | 未知模型别名 |
   248	| `unauthorized` | 401 | 否 | 网关鉴权失败 |
   249	| `rate_limited` | 429 | 否 | 模型级限流（带 Retry-After） |
   250	| `upstream_rate_limited` | 429 | 是 | 上游限流 |
   251	| `upstream_auth_failed` | 401 | 否 | 上游 Key/base_url 配错 |
   252	| `upstream_timeout` | 408 | 是 | 上游超时 |
   253	| `upstream_error` / `upstream_unavailable` | 502/503 | 是 | 上游 5xx / 连接失败 |
   254	| `upstream_bad_response` | 502 | 否 | 上游返回无法解析 |
   255	| `structured_output_invalid` | 502 | 否 | 输出不满足 JSON Schema |
   256	
   257	重试策略：`max_attempts=3`，`delay = min(0.5 × 2^(n-1), 8) + jitter`，**只对可重试错误生效**（5xx/429/超时/连接失败；401/400 立即失败）。响应中的 `attempts` 与 `error.details.retry_history` 是可核对的证据。
   258	限流：每个模型别名一个独立令牌桶（`MODEL_*_RPM` + `MODEL_*_BURST`），A 打满不影响 B。
   259	
   260	---
   261	
   262	## 4. 验收脚本
   263	
   264	```bash
   265	# 前置：网关已在 8000 端口运行
   266	python scripts/verify.py --mode sim    # 全量走本地协议仿真上游，离线可跑，17/17
   267	python scripts/verify.py --mode real   # 走 .env 里配置的真实上游
   268	```
   269	
   270	`--mode sim` 会用 `scripts/faulty_upstream.py`（真实模拟三种协议的请求体/SSE/返回结构 + 故障注入）作为上游，**不需要任何 API Key** 即可验证全部链路。
   271	`--mode real` 下，重试与限流两项仍会临时把模型 A 指向本地仿真上游（因为无法对真实服务注入 500），结束后自动还原。
   272	
   273	覆盖的 17 项检查：
   274	
   275	| 编号 | 检查项 | 证据 |
   276	|---|---|---|
   277	| 00-01 | 健康检查、双协议模型注册 | 两个 alias 的 protocol 不同 |
   278	| 02-03 | 两协议非流式调用 | `protocol` 字段 + `usage` + `latency` |
   279	| 04-05 | 两协议流式 SSE | delta 分块数、`first_token_ms`、`response.stop.usage` |
   280	| 06-07 | 两协议结构化输出 | `structured` 通过 jsonschema 校验 |
   281	| 08-09 | 模板创建/迭代、版本引用与变量替换 | v1 与 v2 渲染结果差异 |
   282	| 10-11 | 对话中引用模板版本、缺变量统一报错 | `template.version`、400 `template_render_error` |
   283	| 12 | Token 分类 + 首 Token 延迟 | `tokens_by_category`、`first_token_ms.samples` |
   284	| 13a/13b | 注入 2 次 500 → 重试成功；注入 5 次 → 重试耗尽 | `attempts=3` / 502 `upstream_error` |
   285	| 14 | 模型级限流 | 状态码序列出现 429 + `rate_limited_total>0` |
   286	| 15 | 未知模型 | 404 `model_not_found` |
   287	
   288	结果写入 `logs/verify_report.json`，退出码非 0 表示有未通过项。
   289	
   290	当前仿真模式实测输出：`=== 结果：17/17 通过 ===`。
   291	
   292	---
   293	
   294	## 5. 目录结构
   295	
   296	```
   297	llm-gateway/
   298	├── app/
   299	│   ├── main.py                     FastAPI 入口、SSE 输出、统一异常处理
   300	│   ├── gateway.py                  编排：路由/限流/模板/重试/结构化/观测
   301	│   ├── config.py                   模型路由表与限流额度（环境变量驱动）
   302	│   ├── models.py                   统一请求/响应/SSE 契约
   303	│   ├── errors.py                   统一错误码体系
   304	│   ├── http.py                     共享 httpx 客户端 + 传输异常翻译
   305	│   ├── retry.py                    指数退避重试
   306	│   ├── ratelimit.py                按模型独立令牌桶
   307	│   ├── observability.py            Token/延迟聚合、JSONL 落盘、Prometheus 输出
   308	│   ├── templates.py                模板存储、版本、{{变量}} 渲染
   309	│   └── adapters/
   310	│       ├── base.py                 适配器抽象基类
   311	│       ├── openai_responses.py     OpenAI Responses 协议
   312	│       ├── openai_chat.py          OpenAI Chat Completions 协议（兼容备选）
   313	│       └── anthropic_messages.py   Anthropic Messages 协议
   314	├── prompts/                        提示词模板（每个模板一个 JSON，含全部版本）
   315	├── scripts/
   316	│   ├── run.sh                      一键启动（自动加载 .env）
   317	│   ├── faulty_upstream.py          协议仿真 + 故障注入上游（仅验证用）
   318	│   └── verify.py                   17 项验收脚本
   319	├── logs/                           调用明细 JSONL + 验收报告
   320	├── .env.example
   321	└── requirements.txt
   322	```
   323	
   324	## 6. 扩展新协议
   325	
   326	1. 在 `app/adapters/` 下新增适配器，继承 `BaseAdapter`，实现 `endpoint/headers/build_payload/parse_response/parse_stream_chunk/call/stream`；
   327	2. 在 `app/gateway.py::build_adapter` 里注册协议名；
   328	3. 在 `app/config.py::SUPPORTED_PROTOCOLS` 加入该协议名；
   329	4. `.env` 里配置 `MODEL_x_PROTOCOL=<新协议>`。
   330	
   331	上层 `/v1/chat` 契约与所有可观测、限流、重试、模板能力**零改动**即可复用。
   332	
   333	## 7. 常见问题
   334	
   335	- **启动时日志提示"未配置 API Key"**：对应 `MODEL_*_API_KEY` 为空，请求会直接返回 400（不浪费重试）。
   336	- **`upstream_bad_response`**：多为 `base_url` 层级写错，Responses 应填到 `…/v1`，Anthropic 应填到 `https://api.anthropic.com`（网关各自拼接 `/responses`、`/v1/messages`）。
   337	- **结构化输出偶发失败**：降低 `temperature`，或换用对 schema 遵循更好的模型；Anthropic 走的是强制 tool_use，比 prefill 稳定得多。
   338	- **限流太紧/太松**：`MODEL_A_RPM` / `MODEL_A_BURST`，或运行时用 `POST /admin/ratelimit/{alias}?rpm=&burst=` 调整（生产建议 `ENABLE_ADMIN=false`）。
