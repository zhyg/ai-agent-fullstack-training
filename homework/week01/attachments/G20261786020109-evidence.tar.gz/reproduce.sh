#!/usr/bin/env bash
# Read-only checks against the pinned student checkout. No credential required.
set -u
ROOT=${1:-/tmp/hush-grade/student}
PY=${2:-/tmp/hush-grade/venv/bin/python}
UVICORN=${3:-/tmp/hush-grade/venv/bin/uvicorn}
cd "$ROOT" || exit 1
git rev-parse HEAD
git ls-tree -r HEAD
git status --porcelain
test -d llm-gateway; echo "README_cd_target_exit=$?"
bash scripts/run.sh; echo "run_exit=$?"
"$PY" scripts/verify.py --mode sim; echo "verify_sim_exit=$?"
"$PY" scripts/verify.py --mode real; echo "verify_real_exit=$?"
"$UVICORN" app.main:app --port 8019; echo "uvicorn_exit=$?"
