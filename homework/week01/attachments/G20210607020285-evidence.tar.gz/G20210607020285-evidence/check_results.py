import json,pathlib
R=pathlib.Path('/tmp/vita-grading')
rows=json.loads((R/'teacher-results.json').read_text())
sup=json.loads((R/'supplement-results.json').read_text())
result=[]
def check(case,condition,meaning):result.append({'case':case,'status':'PASS' if condition else 'FAIL','contract':meaning})
def get(case,source=rows):return next(r for r in source if r['case']==case)
check('A01',len(get('A01')['health'])==3,'three healthy original services')
for m in ('real-chat','real-messages'):
    for kind in ('normal','json','stream'):
        r=get('A02-real-'+m+'-'+kind)
        good=r['status']==200
        if kind=='json':good=good and json.loads(json.loads(r['response'])['choices'][0]['message']['content'])=={'ok':True}
        elif kind=='normal':good=good and json.loads(r['response'])['choices'][0]['message']['content']=='OK'
        else:good=good and 'OK' in r['response'] and '[DONE]' in r['response']
        check(r['case'],good,'actual official call has expected content and successful completion')
wire=get('A03-wire')['state']['calls']
check('A03',wire[0]['path']=='/v1/chat/completions' and wire[1]['path']=='/v1/messages' and 'system' in wire[1]['body'] and 'system' not in wire[0]['body'],'distinct path and request structure through real adapters')
check('A04',get('A04')['status']==404,'unknown model explicitly rejected')
for m in ('mock-a','mock-b'):
    r=get('F01-F02-'+m+'-gate');check('F01-'+m,r['first_before_release'] and any('[DONE]' in l for l in r['lines']),'content received before gate release')
    r=get('F01-F02-'+m+'-errorstream');check('F02-event-'+m,any('"error"' in l for l in r['lines']),'in-band upstream error visible to caller')
    r=get('supplement-'+m+'-transport',sup);check('F02-transport-'+m,len(r['wire']['calls'])==1 and any('"error"' in l for l in r['lines']),'transport interruption explicit, no repeated generation')
    for scenario in ('good','invalid','empty','truncated','repair'):
        r=get('F03-F04-'+m+'-'+scenario)
        check(r['case'],r['status']==(200 if scenario in ('good','repair') else 422),'valid/repaired JSON succeeds; invalid/empty/truncated JSON fails')
    r=get('F03-F04-'+m+'-schema');check(r['case'],r['status']!=200,'declared enum and maximum violations rejected')
    for mode,attempts in [('retry',3),('fail500',4),('bad400',1)]:
        r=get('F08-F09-'+m+'-'+mode);check(r['case']+'-attempts',len(r['state']['calls'])==attempts,'count actual HTTP upstream calls including all transport layers')
    for mode,attempts in [('retry',3),('fail500',3),('bad400',1)]:
        r=get('supplement-'+m+'-'+mode,sup);check(r['case']+'-attempts',len(r['wire']['calls'])==attempts,'stream retry count on actual upstream')
    r=get('supplement-'+m+'-timed',sup)
    check('F07-TTFT-'+m,len(r['records'])==1 and 0.4<=r['records'][0]['latency']['ttft']<r['records'][0]['latency']['total'],'heartbeat ignored, first content delayed 0.4s')
    check('F07-tokens-'+m,r['records'][0]['tokens']['input']==13 and r['records'][0]['tokens']['output']==7,'known usage preserved: 13 input, 7 output')
r=get('F06-missing-variable');last=r['state']['calls'][-1]['body']['messages']
check('F05-F06-variable',r['status']!=200 or not any('{{name}}' in x['content'] for x in last),'missing template variable not sent unresolved')
for case in ('F06-missing-template','F06-missing-version'):
    check(case,get(case)['status']==422,'missing template/version explicitly rejected')
v=[r['state']['calls'][-1]['body']['messages'][1]['content'] for r in rows if r['case'] in ('F05-F06-v1','F05-F06-v2')]
check('F05-version',v==['v1 Hello {{name}}','v2 Hello {{name}}','v1 Hello {{name}}'],'old version retained; variable substitution evaluated separately')
r=get('F07-nonstream-failure-ledger',sup);check(r['case'],r['ledger_after']>r['ledger_before'],'nonstream failure creates an invocation record')
r=get('F08-deterministic-sleep',sup);check(r['case'],all(w<=cap for w,cap in zip(r['waits'],r['rubric_caps'])),'jitter stays within exponential caps')
check('F09-400-status',400<=get('F08-F09-mock-a-bad400')['status']<500,'unsupported upstream parameter remains explicit 4xx')
check('F10',[r['status'] for r in get('F10')['responses']]==[200,200,429,200],'A depleted while B independently succeeds')
check('F11-TPM',get('F11-TPM')['statuses']==[200,429,200],'token bucket genuinely refills after real waiting')
check('F11-RPM',get('F11-RPM')['status']==200,'sliding window recovers after real waiting')
check('F12-failure-visible','[FAIL]' in get('F12-injected-failure')['output'],'student script reports injected failure; exit zero is advisory only')
(R/'assertions.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('Contract checks:',sum(r['status']=='PASS' for r in result),'PASS;',sum(r['status']=='FAIL' for r in result),'FAIL; grading is not calculated from this ratio')
