import os,sys
sys.path.insert(0,'/tmp/vita-grading/submission/LlmGateway')
os.environ['APP_ENV']='teacher'
from app.core.database import SessionLocal
from app.models.model import Model
from app.core.encryption import encrypt_value
db=SessionLocal()
for alias,name,provider,url,rpm,tpm,real in [
 ('mock-a','teacher-a','openai','http://127.0.0.1:18080/v1',0,0,False),
 ('mock-b','teacher-b','anthropic','http://127.0.0.1:18080/v1/messages',0,0,False),
 ('limit-a','limit-a','openai','http://127.0.0.1:18080/v1',2,0,False),
 ('limit-b','limit-b','anthropic','http://127.0.0.1:18080/v1/messages',2,0,False),
 ('tpm-a','tpm-a','openai','http://127.0.0.1:18080/v1',0,100,False),
 ('real-chat','deepseek-flash','openai','https://api.deepseek.com',0,0,True),
 ('real-messages','deepseek-v4-pro','anthropic','https://api.deepseek.com/anthropic/v1/messages',0,0,True),
]:
    db.add(Model(name=name,display_name=alias,provider=provider,url=url,api_key_encrypted=encrypt_value(os.environ['DEEPSEEK_API_KEY'] if real else 'teacher-dummy'),rpm=rpm,tpm=tpm,context_tokens=4096,input_per_million=0,output_per_million=0,cached_input_per_million=0))
db.commit();db.close()
print('Seeded 7 isolated model configurations; no credentials printed')
