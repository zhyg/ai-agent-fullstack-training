import asyncio,json,pathlib,subprocess,time,sys,os
import httpx
R=pathlib.Path('/tmp/vita-grading');results=[]
def records():
    # CLI pipe capture is capped; a regular file preserves the complete journal.
    with (R/'journal-snapshot.tmp').open('w') as f:
        subprocess.run(['amp','orb','service','logs','vita-gateway','-n','20000'],stdout=f,check=True)
    text=(R/'journal-snapshot.tmp').read_text()
    return [json.loads(l.split('llm_invocation: ',1)[1]) for l in text.splitlines() if 'llm_invocation: ' in l]
async def main():
    headers=json.loads((R/'runtime-auth.json').read_text())['headers']
    async with httpx.AsyncClient(timeout=30) as c:
        for m in ('mock-a','mock-b'):
            for mode in ('transport','timed','retry','fail500','bad400'):
                await c.post('http://127.0.0.1:18080/control',json={'mode':mode})
                before=records();t0=time.monotonic();lines=[];first=None
                async with c.stream('POST','http://127.0.0.1:18003/api/llm/v1/chat/completions',headers=headers,json={'model':m,'messages':[{'role':'user','content':'test'}],'stream':True}) as r:
                    async for l in r.aiter_lines():
                        lines.append(l)
                        if 'FIRST' in l and first is None:
                            first=time.monotonic()-t0
                            if mode=='transport':await c.post('http://127.0.0.1:18080/release')
                after=records();state=(await c.get('http://127.0.0.1:18080/state')).json()
                row={'case':'supplement-'+m+'-'+mode,'lines':lines,'first_content_elapsed':first,'total_elapsed':time.monotonic()-t0,'wire':state,'records':after[len(before):]}
                results.append(row);print(json.dumps(row),flush=True)
        await c.post('http://127.0.0.1:18080/control',json={'mode':'bad400'})
        before=records()
        r=await c.post('http://127.0.0.1:18003/api/llm/v1/chat/completions',headers=headers,json={'model':'mock-a','messages':[{'role':'user','content':'test'}]})
        after=records();results.append({'case':'F07-nonstream-failure-ledger','status':r.status_code,'response':r.json(),'ledger_before':len(before),'ledger_after':len(after),'new_records':after[len(before):]})
    os.environ['APP_ENV']='teacher';sys.path.insert(0,str(R/'submission/LlmGateway'))
    from app.gateway.retry import execute_with_retry
    from app.gateway.errors import UpstreamError
    from unittest.mock import patch
    waits=[];count=0
    async def failed():
        nonlocal count;count+=1;raise UpstreamError('controlled')
    async def capture(delay):waits.append(delay)
    with patch('app.gateway.retry.asyncio.sleep',capture),patch('app.gateway.retry.random.uniform',return_value=0.5):
        try:await execute_with_retry(failed)
        except UpstreamError:pass
    results.append({'case':'F08-deterministic-sleep','attempts':count,'waits':waits,'rubric_caps':[1,2,4]})
    (R/'supplement-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
asyncio.run(main())
