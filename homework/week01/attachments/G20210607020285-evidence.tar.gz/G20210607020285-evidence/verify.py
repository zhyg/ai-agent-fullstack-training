import asyncio,json,time,pathlib,subprocess,os
import httpx
ROOT=pathlib.Path('/tmp/vita-grading')
out=[]
def save(name,**data):
    row={'case':name,**data};out.append(row)
    (ROOT/'teacher-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps(row,ensure_ascii=False),flush=True)
async def main():
    async with httpx.AsyncClient(timeout=110) as c:
        login=(await c.post('http://127.0.0.1:18001/api/user/auth/login',json={'uid':'admin','password':'admin123'})).json()
        auth={'Authorization':'Bearer '+login['access_token']}
        key=(await c.post('http://127.0.0.1:18001/api/user/api-keys',headers=auth,json={'name':'teacher-isolated'})).json()['secret']
        headers={'Authorization':'Bearer '+key}
        (ROOT/'runtime-auth.json').write_text(json.dumps({'headers':headers,'auth':auth}))
        (ROOT/'runtime-auth.json').chmod(0o600)
        async def mode(m):await c.post('http://127.0.0.1:18080/control',json={'mode':m})
        async def state():return (await c.get('http://127.0.0.1:18080/state')).json()
        async def call(model='mock-a',**extra):
            return await c.post('http://127.0.0.1:18003/api/llm/v1/chat/completions',headers=headers,json={'model':model,'messages':[{'role':'system','content':'Return JSON.'},{'role':'user','content':'test'}],**extra})
        save('A01',health=[(await c.get(f'http://127.0.0.1:{port}/api/{path}/health')).json() for port,path in [(18001,'user'),(18002,'knowledge'),(18003,'llm')]])
        await mode('good')
        for m in ('mock-a','mock-b'):
            r=await call(m);save('A03-'+m,status=r.status_code,response=r.json())
        save('A03-wire',state=await state())
        r=await call('does-not-exist');save('A04',status=r.status_code,response=r.json())
        for m in ('mock-a','mock-b'):
            for scenario in ('gate','errorstream','eof'):
                await mode(scenario)
                async with c.stream('POST','http://127.0.0.1:18003/api/llm/v1/chat/completions',headers=headers,json={'model':m,'messages':[{'role':'user','content':'test'}],'stream':True}) as r:
                    lines=[];first_before_release=False;released=False;t0=time.monotonic()
                    async for line in r.aiter_lines():
                        lines.append(line)
                        if 'FIRST' in line and not released:
                            first_before_release=True;released=True
                            await c.post('http://127.0.0.1:18080/release')
                    save('F01-F02-'+m+'-'+scenario,status=r.status_code,first_before_release=first_before_release,elapsed=time.monotonic()-t0,lines=lines,state=await state())
        for m in ('mock-a','mock-b'):
            for scenario in ('good','invalid','empty','truncated','schema','repair'):
                await mode(scenario)
                fmt={'type':'json_object'}
                if scenario=='schema':fmt['schema']={'type':'object','properties':{'x':{'type':'string','enum':['ok']},'n':{'type':'integer','maximum':3}},'required':['x','n']}
                r=await call(m,response_format=fmt)
                save('F03-F04-'+m+'-'+scenario,status=r.status_code,response=r.json(),state=await state())
        await mode('good')
        for version in ('v1','v2'):
            r=await c.post('http://127.0.0.1:18002/api/knowledge/prompts',headers=auth,json={'name':'teacher-template','version':version,'content':version+' Hello {{name}}','description':'teacher test'})
            save('F05-create-'+version,status=r.status_code,response=r.json())
        for version in ('v1','v2','v1','missing'):
            r=await call(prompt_name='teacher-template',prompt_version=version,variables={'name':'Vita'})
            save('F05-F06-'+version,status=r.status_code,response=r.json(),state=await state())
        r=await call(prompt_name='missing-template',prompt_version='v1');save('F06-missing-template',status=r.status_code,response=r.json())
        r=await call(prompt_name='teacher-template');save('F06-missing-version',status=r.status_code,response=r.json())
        r=await call(prompt_name='teacher-template',prompt_version='v1');save('F06-missing-variable',status=r.status_code,response=r.json(),state=await state())
        for m in ('mock-a','mock-b'):
            for scenario in ('retry','fail500','bad400'):
                await mode(scenario);t0=time.monotonic();r=await call(m)
                save('F08-F09-'+m+'-'+scenario,status=r.status_code,elapsed=time.monotonic()-t0,response=r.json(),state=await state())
        await mode('good')
        statuses=[]
        for m in ('limit-a','limit-a','limit-a','limit-b'):
            r=await call(m);statuses.append({'model':m,'status':r.status_code,'response':r.json()})
        save('F10',responses=statuses)
        r1=await call('tpm-a',messages=[{'role':'user','content':'x'*400}])
        r2=await call('tpm-a',messages=[{'role':'user','content':'x'*40}])
        await asyncio.sleep(7)
        r3=await call('tpm-a',messages=[{'role':'user','content':'x'*40}])
        save('F11-TPM',statuses=[r1.status_code,r2.status_code,r3.status_code])
        await asyncio.sleep(54)
        r=await call('limit-a');save('F11-RPM',status=r.status_code,response=r.json())
        for script,extra in [('test_rpm_rate_limit.sh',{'REQUEST_COUNT':'3','RPM_LIMIT':'2','MODEL':'limit-b'}),('test_tpm_rate_limit.sh',{'REQUEST_COUNT':'3','MSG_SIZE':'400','TPM_CAPACITY':'100','MODEL':'tpm-a'})]:
            env={**os.environ,'API_KEY':key,'BASE_URL':'http://127.0.0.1:18003','REDIS_PORT':'56379',**extra}
            p=await asyncio.create_subprocess_exec('bash',str(ROOT/'submission/LlmGateway/tests'/script),env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
            text=(await p.communicate())[0].decode();(ROOT/(script+'.log')).write_text(text)
            save('F12-'+script,exit=p.returncode,output=text)
        env={**os.environ,'API_KEY':key,'BASE_URL':'http://127.0.0.1:18003','REQUEST_COUNT':'2','RPM_LIMIT':'2','MODEL':'does-not-exist'}
        p=await asyncio.create_subprocess_exec('bash',str(ROOT/'submission/LlmGateway/tests/test_rpm_rate_limit.sh'),env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
        text=(await p.communicate())[0].decode();(ROOT/'student-injected-failure.log').write_text(text);save('F12-injected-failure',exit=p.returncode,output=text)
        # Real network calls are ONLY made by unmodified student adapters to the two official endpoints seeded in seed.py.
        for m in ('real-chat','real-messages'):
            for kind in ('normal','json','stream'):
                body={'model':m,'messages':[{'role':'system','content':'Be concise. Return JSON when asked.'},{'role':'user','content':'Return {"ok":true} only.' if kind=='json' else 'Reply only OK.'}],'max_tokens':1024}
                if kind=='json':body['response_format']={'type':'json_object'}
                if kind=='stream':body['stream']=True
                t0=time.monotonic()
                try:
                    r=await c.post('http://127.0.0.1:18003/api/llm/v1/chat/completions',headers=headers,json=body)
                    save('A02-real-'+m+'-'+kind,status=r.status_code,elapsed=time.monotonic()-t0,response=r.text)
                except Exception as e:save('A02-real-'+m+'-'+kind,status='UNVERIFIED',error=type(e).__name__,elapsed=time.monotonic()-t0)
asyncio.run(main())
