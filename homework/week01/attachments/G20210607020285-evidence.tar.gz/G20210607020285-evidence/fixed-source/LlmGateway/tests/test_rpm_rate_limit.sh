#!/usr/bin/env bash
# =============================================================================
# test_rpm_rate_limit.sh
#
# 验证 LlmGateway RPM（Requests Per Minute）限流是否生效。
#
# 原理：
#   - RPM 使用 SlidingWindowCounter（Redis sorted set），60 秒滑动窗口
#   - 每次请求计数 +1，超过数据库配置的 rpm 值即返回 HTTP 429
#   - 当前测试目标模型 RPM 配置：20
#
# 用法：
#   chmod +x test_rpm_rate_limit.sh
#   ./test_rpm_rate_limit.sh
#
# 可调参数（通过环境变量或直接在下方修改）：
#   API_KEY        - API Key
#   MODEL          - 模型 display name
#   BASE_URL       - 网关地址
#   REQUEST_COUNT  - 快速连续发送的请求总数（需 > RPM 限制才能触发限流）
#   RPM_LIMIT      - 数据库中该模型配置的 RPM 值（用于显示和判断）
# =============================================================================

API_KEY="${API_KEY:-[REDACTED]}"
MODEL="${MODEL:-deepseek-flash-deepseek}"
BASE_URL="${BASE_URL:-http://localhost:8003}"
REQUEST_COUNT="${REQUEST_COUNT:-30}"
RPM_LIMIT="${RPM_LIMIT:-20}"

ENDPOINT="${BASE_URL}/api/llm/v1/chat/completions"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo "=============================================="
echo -e "${CYAN}  LlmGateway RPM Rate Limit 测试脚本${NC}"
echo "=============================================="
echo ""
echo -e "${YELLOW}[配置]${NC}"
echo "  网关地址         : ${BASE_URL}"
echo "  模型名称         : ${MODEL}"
echo "  连续请求数       : ${REQUEST_COUNT}"
echo "  数据库 RPM 限制  : ${RPM_LIMIT}"
echo "  预期             : 前 ${RPM_LIMIT} 个请求成功，超出后返回 429"
echo ""
echo "----------------------------------------------"
echo "开始发送请求..."
echo ""

# ---------- 结果统计 ----------
TMPDIR_RESULTS=$(mktemp -d)
trap "rm -rf ${TMPDIR_RESULTS}" EXIT

TOTAL=0
SUCCESS=0
RATE_LIMITED=0
FAILED=0

# ---------- 顺序快速发送请求（确保在 60 秒窗口内） ----------
for i in $(seq 1 "$REQUEST_COUNT"); do
    outfile="${TMPDIR_RESULTS}/req_${i}.json"

    start_time=$(python3 -c "import time; print(int(time.time()*1000))")

    body=$(curl -s -w "\n%{http_code}" \
        -X POST "${ENDPOINT}" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${API_KEY}" \
        -d "{
            \"model\": \"${MODEL}\",
            \"messages\": [
                {\"role\": \"user\", \"content\": \"Hi\"}
            ],
            \"max_tokens\": 1
        }" \
        --max-time 30 2>/dev/null)

    end_time=$(python3 -c "import time; print(int(time.time()*1000))")
    elapsed_ms=$(( end_time - start_time ))

    # 分离 HTTP status code 和 body
    http_code=$(echo "$body" | tail -1 | tr -d '[:space:]')
    response_body=$(echo "$body" | sed '$d')
    echo "$response_body" > "$outfile"

    TOTAL=$((TOTAL + 1))

    # 分类统计
    if [ "$http_code" = "200" ]; then
        SUCCESS=$((SUCCESS + 1))
        echo -e "  [${GREEN}✓${NC}] #$(printf '%02d' $i)  HTTP ${http_code}  ${elapsed_ms}ms"
    elif [ "$http_code" = "429" ]; then
        RATE_LIMITED=$((RATE_LIMITED + 1))
        echo -e "  [${YELLOW}⚠${NC}] #$(printf '%02d' $i)  HTTP ${http_code}  ${elapsed_ms}ms  ← RPM 限流触发"
    else
        FAILED=$((FAILED + 1))
        echo -e "  [${RED}✗${NC}] #$(printf '%02d' $i)  HTTP ${http_code}  ${elapsed_ms}ms  $(echo "$response_body" | head -c 100)"
    fi
done

echo ""
echo "----------------------------------------------"
echo ""
echo -e "${CYAN}=============================================="
echo -e "  测试结果汇总"
echo -e "==============================================${NC}"
echo ""
echo -e "  总请求数          : ${TOTAL}"
echo -e "  成功 (HTTP 200)   : ${GREEN}${SUCCESS}${NC}"
echo -e "  限流 (HTTP 429)   : ${YELLOW}${RATE_LIMITED}${NC}"
echo -e "  失败 (其他错误)   : ${RED}${FAILED}${NC}"
echo ""

# ---------- 结论判断 ----------
if [ "$RATE_LIMITED" -gt 0 ] && [ "$SUCCESS" -gt 0 ]; then
    echo -e "${GREEN}[PASS]${NC} RPM 限流已正确触发！"
    echo "       前 ${SUCCESS} 个请求通过，后续 ${RATE_LIMITED} 个请求被限流 (HTTP 429)。"
    echo "       符合预期：60 秒滑动窗口内超过 ${RPM_LIMIT} 个请求后被拒绝。"
elif [ "$RATE_LIMITED" -gt 0 ] && [ "$SUCCESS" -eq 0 ]; then
    echo -e "${YELLOW}[WARN]${NC} 所有请求都被限流，可能是上一轮测试的窗口还未过期。"
    echo "       请等待 60 秒后重试，让 SlidingWindow 滑动过去。"
elif [ "$FAILED" -gt 0 ] && [ "$SUCCESS" -eq 0 ] && [ "$RATE_LIMITED" -eq 0 ]; then
    echo -e "${RED}[FAIL]${NC} 所有请求均失败，可能是 API Key 无效、模型不存在或网关未启动。"
    echo "       请检查服务日志排查问题。"
elif [ "$SUCCESS" -eq "$TOTAL" ]; then
    echo -e "${YELLOW}[INFO]${NC} 所有请求均成功，RPM 限流未触发。"
    echo "       可能原因："
    echo "         1. 请求发送速度不够快，未能在 60 秒内超过 ${RPM_LIMIT} 个"
    echo "         2. 数据库 rpm 配置大于预期"
    echo "         3. Redis 不可用，限流降级放行（见服务日志 warning）"
    echo ""
    echo "       建议：增大 REQUEST_COUNT 或检查数据库中 rpm 的实际值"
else
    echo -e "${YELLOW}[WARN]${NC} 部分请求失败但非限流原因，请查看具体错误内容。"
fi

echo ""
echo "----------------------------------------------"
echo "提示：RPM 使用 60 秒滑动窗口，等待 60 秒后计数器自动清零。"
echo "      若连续测试，请间隔 60 秒以上，否则上一轮的请求仍在窗口内。"
echo "----------------------------------------------"
