import json
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from app.adapters.base import ModelConfig
from app.gateway.errors import InvalidRequestError
from app.gateway.registry import ModelRegistry
from app.schemas.chat_completion import ChatCompletionRequest, ResponseFormat
from app.services.llm_gateway_service import LLMGatewayService


class SchemaPromptTests(unittest.IsolatedAsyncioTestCase):
    """测试 JSON Schema 提示注入功能：验证 response_format.schema 被正确拼接到系统提示中。"""

    def setUp(self):
        self.registry = ModelRegistry()
        self.service = LLMGatewayService(self.registry)
        self.schema = {
            "type": "object",
            "properties": {"answer": {"type": "string", "description": "回答"}},
            "required": ["answer"],
        }
        self.request = ChatCompletionRequest(
            model="model", messages=[{"role": "user", "content": "hello"}],
            response_format=ResponseFormat(type="json_object", schema=self.schema),
        )

    async def test_schema_is_added_with_or_without_system_prompt_and_template(self):
        """测试在四种组合下（有/无 system 消息 × 有/无 prompt 模板），schema 都能被正确注入到系统提示中，
        且原始消息列表不会被就地修改。"""
        for with_system in (False, True):
            for with_template in (False, True):
                with self.subTest(system=with_system, template=with_template):
                    messages = [{"role": "user", "content": "hello"}]
                    if with_system:
                        messages.insert(0, {"role": "system", "content": "original"})
                    original = [dict(message) for message in messages]
                    self.request.prompt_name = "template" if with_template else None
                    self.request.prompt_version = "1" if with_template else None
                    with patch(
                        "app.services.llm_gateway_service.fetch_prompt",
                        new_callable=AsyncMock, return_value={"content": "template content"},
                    ) as fetch:
                        result = await self.service._resolve_prompt(self.request, messages)
                    self.assertEqual(messages, original)
                    self.assertEqual(result[0]["role"], "system")
                    self.assertIn(json.dumps(self.schema, ensure_ascii=False), result[0]["content"])
                    self.assertEqual(result[-1], {"role": "user", "content": "hello"})
                    if with_system:
                        self.assertTrue(result[0]["content"].startswith("original\n\n"))
                    if with_template:
                        self.assertTrue(any("template content" in m["content"] for m in result))
                        fetch.assert_awaited_once_with("template", "1")
                    else:
                        fetch.assert_not_awaited()

    async def test_no_instructions_without_nonempty_json_schema(self):
        """测试当 response_format 为 None、无 schema、空 schema 或 type 非 json_object 时，
        _resolve_prompt 不会注入额外的 schema 指令，消息列表原样返回。"""
        messages = [{"role": "system", "content": "original"}, {"role": "user", "content": "hello"}]
        for response_format in (
            None,
            ResponseFormat(type="json_object"),
            ResponseFormat(type="json_object", schema={}),
            ResponseFormat(type="text", schema=self.schema),
        ):
            with self.subTest(response_format=response_format):
                self.request.response_format = response_format
                self.assertEqual(
                    await self.service._resolve_prompt(self.request, messages), messages,
                )

    async def test_missing_template_version_still_fails(self):
        """测试指定了 prompt_name 但缺少 prompt_version 时，应抛出 InvalidRequestError。"""
        self.request.prompt_name = "template"
        with self.assertRaises(InvalidRequestError):
            await self.service._resolve_prompt(
                self.request, [{"role": "user", "content": "hello"}],
            )

    async def test_schema_reaches_adapter_for_streaming_and_non_streaming(self):
        """端到端测试：schema 在非流式（complete）和流式（stream）两条路径中，
        都能被正确传递到底层 adapter 的消息列表和 response_format 参数中。"""
        self.registry.models["model"] = ModelConfig(
            name="deepseek-flash", provider="openai", url="https://api.deepseek.com", api_key="[REDACTED_KEY]",
        )
        adapter = MagicMock()
        self.registry.adapters["test"] = adapter
        adapter.complete = AsyncMock(return_value={
            "content": '{"answer":"ok"}', "usage": {}, "finish_reason": "stop",
        })

        async def stream(*args, **kwargs):
            yield {"type": "delta", "content": '{"answer":"ok"}'}
            yield {"type": "done"}

        adapter.stream.side_effect = stream
        with patch.object(self.service, "_record_and_log"):
            result = await self.service.process_request(self.request, {}, MagicMock())
            self.request.stream = True
            events = [
                event async for event in self.service.process_stream_request(
                    self.request, {}, MagicMock(),
                )
            ]
        self.assertEqual(json.loads(result.choices[0].message["content"]), {"answer": "ok"})
        self.assertEqual(json.loads(events[0]["content"]), {"answer": "ok"})
        for call in (adapter.complete.call_args, adapter.stream.call_args):
            self.assertEqual(call.args[1][0]["role"], "system")
            self.assertIn(json.dumps(self.schema, ensure_ascii=False), call.args[1][0]["content"])
            self.assertEqual(call.kwargs["response_format"]["schema"], self.schema)
