import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from app.adapters.anthropic_adapter import AnthropicAdapter
from app.adapters.base import ModelConfig
from app.adapters.openai_adapter import OpenAIAdapter
from app.gateway.errors import UpstreamError, UpstreamTimeoutError
from app.gateway.registry import ModelRegistry
from app.schemas.chat_completion import ChatCompletionRequest, ResponseFormat
from app.services.llm_gateway_service import LLMGatewayService


class StreamRetryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.config = ModelConfig(
            name="model", provider="test", url="https://example.com",
            api_key="test-key",
        )
        self.adapter = MagicMock()
        registry = ModelRegistry()
        registry.models = {"model": self.config}
        registry.adapters = {"test": self.adapter}
        self.service = LLMGatewayService(registry)
        self.request = ChatCompletionRequest(
            model="model", messages=[{"role": "user", "content": "hello"}],
            stream=True,
        )

    async def run_stream(self):
        return [
            event async for event in self.service.process_stream_request(
                self.request, {}, MagicMock()
            )
        ]

    async def test_event_failure_retries_and_discards_failed_attempt_usage(self):
        error = {"type": "error", "message": "timeout", "error_code": "upstream_timeout"}
        usage = {"type": "usage", "input": 1}
        events = [[usage, error], [usage, {"type": "delta", "content": "ok"}, {"type": "done"}]]
        closed = []

        async def stream(*args, **kwargs):
            index = self.adapter.stream.call_count - 1
            try:
                for event in events[index]:
                    yield event
            finally:
                closed.append(index)

        self.adapter.stream.side_effect = stream
        with (
            patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
            patch.object(self.service, "_record_and_log") as record,
        ):
            result = await self.run_stream()

        self.assertEqual(result, events[1])
        self.assertEqual(closed, [0, 1])
        self.assertEqual(self.adapter.stream.call_count, 2)
        sleep.assert_awaited_once_with(1.0)
        self.assertEqual(record.call_args.args[6:8], (1, "stop"))

    async def test_exhaustion_records_last_error_and_retry_count(self):
        error = {"type": "error", "message": "unavailable", "error_code": "upstream_error"}

        async def stream(*args, **kwargs):
            yield error

        self.adapter.stream.side_effect = stream
        with (
            patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
            patch.object(self.service, "_record_and_log") as record,
        ):
            result = await self.run_stream()

        self.assertEqual(result, [error])
        self.assertEqual(self.adapter.stream.call_count, 3)
        self.assertEqual([call.args for call in sleep.await_args_list], [(1.0,), (2.0,)])
        self.assertEqual(record.call_args.args[6:8], (2, "error"))
        self.assertEqual(record.call_args.kwargs["error_code"], "upstream_error")

    async def test_raised_upstream_errors_are_retried_during_iteration(self):
        async def stream(*args, **kwargs):
            if self.adapter.stream.call_count == 1:
                raise UpstreamTimeoutError("timeout")
            yield {"type": "delta", "content": "ok"}
            yield {"type": "done"}

        self.adapter.stream.side_effect = stream
        with (
            patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock),
            patch.object(self.service, "_record_and_log") as record,
        ):
            result = await self.run_stream()
        self.assertEqual(result, [{"type": "delta", "content": "ok"}, {"type": "done"}])
        self.assertEqual(record.call_args.args[6], 1)

    async def test_non_retryable_raised_upstream_error_is_not_retried(self):
        async def stream(*args, **kwargs):
            raise UpstreamError("unauthorized", retryable=False)
            yield

        self.adapter.stream.side_effect = stream
        with (
            patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
            patch.object(self.service, "_record_and_log"),
        ):
            result = await self.run_stream()
        self.assertEqual(result, [{
            "type": "error", "message": "unauthorized",
            "error_code": "upstream_error", "retryable": False,
        }])
        self.assertEqual(self.adapter.stream.call_count, 1)
        sleep.assert_not_awaited()

    async def test_closing_consumer_closes_adapter_stream(self):
        closed = False

        async def stream(*args, **kwargs):
            nonlocal closed
            try:
                yield {"type": "delta", "content": "partial"}
                yield {"type": "done"}
            finally:
                closed = True

        self.adapter.stream.side_effect = stream
        generator = self.service.process_stream_request(self.request, {}, MagicMock())
        self.assertEqual(await anext(generator), {"type": "delta", "content": "partial"})
        await generator.aclose()
        self.assertTrue(closed)

    async def test_no_retry_after_delta_even_when_json_is_buffered(self):
        for json_mode in (False, True):
            with self.subTest(json_mode=json_mode):
                self.adapter.stream.reset_mock()
                self.request.response_format = ResponseFormat(type="json_object") if json_mode else None
                error = {"type": "error", "message": "broken", "error_code": "upstream_error"}

                async def stream(*args, **kwargs):
                    yield {"type": "delta", "content": "partial"}
                    raise UpstreamError("broken")

                self.adapter.stream.side_effect = stream
                with (
                    patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
                    patch.object(self.service, "_record_and_log"),
                ):
                    result = await self.run_stream()
                self.assertEqual(result, ([error] if json_mode else [
                    {"type": "delta", "content": "partial"}, error,
                ]))
                self.assertEqual(self.adapter.stream.call_count, 1)
                sleep.assert_not_awaited()

    async def test_non_retryable_and_unexpected_failures_are_not_retried(self):
        for failure in (
            {"type": "error", "message": "invalid", "error_code": "invalid_request"},
            {"type": "error", "message": "unauthorized", "error_code": "upstream_error",
             "retryable": False},
            ValueError("bug"),
        ):
            with self.subTest(failure=failure):
                self.adapter.stream.reset_mock()

                async def stream(*args, **kwargs):
                    if isinstance(failure, Exception):
                        raise failure
                    yield failure

                self.adapter.stream.side_effect = stream
                with (
                    patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
                    patch.object(self.service, "_record_and_log"),
                ):
                    if isinstance(failure, Exception):
                        with self.assertRaisesRegex(ValueError, "bug"):
                            await self.run_stream()
                    else:
                        self.assertEqual(await self.run_stream(), [failure])
                self.assertEqual(self.adapter.stream.call_count, 1)
                sleep.assert_not_awaited()

    async def test_real_adapters_retry_http_failures_and_propagate_bugs(self):
        for adapter_class in (OpenAIAdapter, AnthropicAdapter):
            with self.subTest(adapter=adapter_class.__name__):
                count = 0

                def respond(request):
                    nonlocal count
                    count += 1
                    if count == 1:
                        return httpx.Response(503, text="unavailable")
                    if adapter_class is OpenAIAdapter:
                        content = 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n'
                    else:
                        content = (
                            'data: {"type":"content_block_delta","delta":'
                            '{"type":"text_delta","text":"ok"}}\n\n'
                            'data: {"type":"message_stop"}\n\n'
                        )
                    return httpx.Response(200, text=content)

                client_class = httpx.AsyncClient
                self.service.registry.adapters["test"] = adapter_class()
                with (
                    patch(
                        "httpx.AsyncClient",
                        side_effect=lambda **kwargs: client_class(
                            transport=httpx.MockTransport(respond), **kwargs
                        ),
                    ),
                    patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock),
                    patch.object(self.service, "_record_and_log") as record,
                ):
                    result = await self.run_stream()
                self.assertEqual(result, [{"type": "delta", "content": "ok"}, {"type": "done"}])
                self.assertEqual(count, 2)
                self.assertEqual(record.call_args.args[6], 1)

                def bug(request):
                    raise ValueError("unexpected bug")

                client = httpx.AsyncClient(transport=httpx.MockTransport(bug))
                with (
                    patch("httpx.AsyncClient", return_value=client) as factory,
                    patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
                    patch.object(self.service, "_record_and_log"),
                    self.assertRaisesRegex(ValueError, "unexpected bug"),
                ):
                    await self.run_stream()
                self.assertEqual(factory.call_count, 1)
                sleep.assert_not_awaited()

    async def test_real_adapters_do_not_retry_authentication_errors(self):
        for adapter_class in (OpenAIAdapter, AnthropicAdapter):
            with self.subTest(adapter=adapter_class.__name__):
                client = httpx.AsyncClient(
                    transport=httpx.MockTransport(
                        lambda request: httpx.Response(401, text="unauthorized")
                    )
                )
                self.service.registry.adapters["test"] = adapter_class()
                with (
                    patch("httpx.AsyncClient", return_value=client) as factory,
                    patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock) as sleep,
                    patch.object(self.service, "_record_and_log") as record,
                ):
                    result = await self.run_stream()
                self.assertEqual(result[0]["error_code"], "upstream_error")
                self.assertFalse(result[0]["retryable"])
                self.assertEqual(factory.call_count, 1)
                self.assertEqual(record.call_args.args[6], 0)
                sleep.assert_not_awaited()

    async def test_anthropic_retry_does_not_reuse_input_usage_from_failed_attempt(self):
        responses = [
            'data: {"type":"message_start","message":{"usage":{"input_tokens":10}}}\n\n',
            'data: {"type":"message_stop"}\n\n',
        ]
        attempt = 0

        class FailingStream(httpx.AsyncByteStream):
            async def __aiter__(self):
                yield responses[0].encode()
                raise httpx.ReadError("connection lost")

        def respond(request):
            nonlocal attempt
            attempt += 1
            if attempt == 1:
                return httpx.Response(200, stream=FailingStream())
            return httpx.Response(200, text=responses[1])

        client_class = httpx.AsyncClient
        self.service.registry.adapters["test"] = AnthropicAdapter()
        with (
            patch(
                "httpx.AsyncClient",
                side_effect=lambda **kwargs: client_class(
                    transport=httpx.MockTransport(respond), **kwargs
                ),
            ),
            patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock),
            patch.object(self.service, "_record_and_log") as record,
        ):
            result = await self.run_stream()
        self.assertEqual(result, [{"type": "done"}])
        self.assertEqual(record.call_args.args[6], 1)
