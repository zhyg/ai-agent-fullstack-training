import unittest

from app.main import app


class ChatRouteTests(unittest.TestCase):
    def test_only_openai_compatible_chat_completions_is_registered(self):
        routes = {
            route.path
            for route in app.routes
            if "POST" in getattr(route, "methods", set())
        }
        self.assertNotIn("/api/llm/chat/completions", routes)
        self.assertIn("/api/llm/v1/chat/completions", routes)
