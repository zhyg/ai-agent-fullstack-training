import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from app.adapters.openai_adapter import OpenAIAdapter
from app.gateway.registry import ModelRegistry
from app.schemas.chat_completion import ChatCompletionRequest
from app.services.llm_gateway_service import LLMGatewayService


class DisplayNameRoutingTests(unittest.TestCase):
    def test_display_name_resolves_provider_model_and_url(self):
        model = SimpleNamespace(
            name="provider-model",
            display_name="Friendly model",
            provider="openai",
            url="https://example.com/v1/chat/completions",
            api_key_encrypted="encrypted-test-key",
            rpm=0,
            tpm=0,
            context_tokens=4096,
            input_per_million=0,
            output_per_million=0,
            cached_input_per_million=0,
        )
        db = MagicMock()
        db.query.return_value.all.return_value = [model]
        registry = ModelRegistry()
        adapter = OpenAIAdapter()
        registry.register_adapter(adapter)
        with patch("app.gateway.registry.decrypt_value", return_value="test-key"):
            registry.load_from_db(db)
        service = LLMGatewayService(registry)
        request = ChatCompletionRequest(
            model="Friendly model",
            messages=[{"role": "user", "content": "hello"}],
            stream=True,
        )
        config, resolved_name = service._resolve_model(request)
        self.assertEqual(resolved_name, "provider-model")
        self.assertEqual(config.url, model.url)
        self.assertEqual(config.api_key, "test-key")
        self.assertIs(service._get_adapter(config), adapter)
        self.assertEqual(
            adapter._build_payload(config, [], stream=True)["model"], "provider-model"
        )
