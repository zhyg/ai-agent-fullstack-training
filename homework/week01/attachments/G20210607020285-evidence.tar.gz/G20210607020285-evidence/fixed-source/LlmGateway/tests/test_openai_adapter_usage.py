import unittest

from app.adapters.openai_adapter import OpenAIAdapter


class OpenAIAdapterUsageTests(unittest.TestCase):
    def setUp(self):
        self.adapter = OpenAIAdapter()

    def test_parse_usage_reads_cached_and_reasoning_tokens_from_details(self):
        usage = self.adapter._parse_usage(
            {
                "prompt_tokens": 4776,
                "completion_tokens": 791,
                "total_tokens": 5567,
                "prompt_tokens_details": {"cached_tokens": 3840},
                "completion_tokens_details": {"reasoning_tokens": 110},
            }
        )

        self.assertEqual(
            usage,
            {"input": 4776, "output": 791, "cached": 3840, "reasoning": 110},
        )

    def test_parse_usage_handles_missing_details(self):
        usage = self.adapter._parse_usage({"prompt_tokens": 12, "completion_tokens": 3})

        self.assertEqual(
            usage, {"input": 12, "output": 3, "cached": 0, "reasoning": 0}
        )


if __name__ == "__main__":
    unittest.main()
