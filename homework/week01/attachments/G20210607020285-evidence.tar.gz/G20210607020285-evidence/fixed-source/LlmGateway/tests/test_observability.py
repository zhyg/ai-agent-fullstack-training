import unittest
from unittest.mock import patch

from prometheus_client import CollectorRegistry, Counter, Histogram

from app.gateway import observability


class PromptMetricTests(unittest.TestCase):
    def test_all_metrics_include_prompt_labels(self):
        for prompt_name, prompt_version in (("travel-planner", "1.0"), (None, None)):
            with self.subTest(prompt_name=prompt_name):
                registry = CollectorRegistry()
                metrics = {}
                for name in (
                    "llm_request_total", "llm_tokens_total", "llm_latency_seconds",
                    "llm_cost_estimate", "llm_retry_total",
                ):
                    original = getattr(observability, name)
                    metric_type = Histogram if name == "llm_latency_seconds" else Counter
                    metrics[name] = metric_type(
                        name, "Test metric", original._labelnames, registry=registry,
                    )
                record = observability.InvocationRecord(
                    model_name="model", provider="openai",
                    prompt_name=prompt_name, prompt_version=prompt_version,
                    tokens={"input": 1, "output": 2, "cached": 3, "reasoning": 4},
                    latency={
                        "queue": 0.1, "route": 0.1, "ttft": 0.1,
                        "generation": 0.1, "total": 0.4,
                    },
                    estimated_cost=0.01, retries=1,
                )
                with patch.multiple(observability, **metrics):
                    observability.record_invocation(record)

                for name, metric in metrics.items():
                    samples = [
                        sample for family in metric.collect() for sample in family.samples
                    ]
                    self.assertTrue(samples, name)
                    for sample in samples:
                        self.assertEqual(sample.labels["prompt_name"], prompt_name or "")
                        self.assertEqual(sample.labels["prompt_version"], prompt_version or "")

    def test_gateway_invocation_carries_request_prompt_metadata(self):
        from app.adapters.base import ModelConfig
        from app.gateway.registry import ModelRegistry
        from app.schemas.chat_completion import ChatCompletionRequest
        from app.services.llm_gateway_service import LLMGatewayService

        service = LLMGatewayService(ModelRegistry())
        config = ModelConfig(name="model", provider="openai", url="", api_key="")
        request = ChatCompletionRequest(
            model="model", messages=[{"role": "user", "content": "hello"}],
            prompt_name="travel-planner", prompt_version="1.0",
        )
        with (
            patch("app.services.llm_gateway_service.record_invocation") as record,
            patch("app.services.llm_gateway_service.log_invocation"),
        ):
            service._record_and_log(
                request, {}, config, config, {}, {}, 0, "stop",
            )
        invocation = record.call_args.args[0]
        self.assertEqual(invocation.prompt_name, "travel-planner")
        self.assertEqual(invocation.prompt_version, "1.0")
