import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from app.adapters.base import ModelConfig
from app.gateway.errors import UpstreamError
from app.gateway.registry import ModelRegistry
from app.schemas.chat_completion import ChatCompletionRequest
from app.services.llm_gateway_service import LLMGatewayService


class NoFallbackTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.primary = ModelConfig(
            name="primary", provider="primary-provider", url="https://example.com",
            api_key="test-key",
        )
        self.backup = ModelConfig(
            name="backup", provider="backup-provider", url="https://example.com",
            api_key="test-key",
        )
        self.adapter = MagicMock()
        self.backup_adapter = MagicMock()
        registry = ModelRegistry()
        registry.models = {"primary": self.primary, "backup": self.backup}
        registry.adapters = {
            "primary-provider": self.adapter,
            "backup-provider": self.backup_adapter,
        }
        self.service = LLMGatewayService(registry)
        self.request = ChatCompletionRequest(
            model="primary", messages=[{"role": "user", "content": "hello"}],
        )

    async def test_non_streaming_failure_retries_only_requested_model(self):
        error = UpstreamError("primary unavailable")
        self.adapter.complete = AsyncMock(side_effect=error)
        with patch("app.gateway.retry.asyncio.sleep", new_callable=AsyncMock):
            with self.assertRaises(UpstreamError) as raised:
                await self.service.process_request(self.request, {}, MagicMock())
        self.assertIs(raised.exception, error)
        self.assertEqual(self.adapter.complete.await_count, 4)
        self.backup_adapter.complete.assert_not_called()
        self.backup_adapter.stream.assert_not_called()

    async def test_non_streaming_retry_success_keeps_requested_model(self):
        self.adapter.complete = AsyncMock(side_effect=[
            UpstreamError("temporary failure"),
            {"content": "answer", "usage": {}, "finish_reason": "stop"},
        ])
        with (
            patch("app.gateway.retry.asyncio.sleep", new_callable=AsyncMock),
            patch.object(self.service, "_record_and_log") as record,
        ):
            result = await self.service.process_request(self.request, {}, MagicMock())
        self.assertEqual(result.model, "primary")
        self.assertEqual(result.choices[0].message["content"], "answer")
        self.assertEqual(record.call_args.args[6:8], (1, "stop"))
        self.backup_adapter.complete.assert_not_called()

    async def test_stream_error_never_switches_models(self):
        for with_delta in (False, True):
            with self.subTest(with_delta=with_delta):
                error = {
                    "type": "error", "message": "primary unavailable",
                    "error_code": "upstream_error",
                }
                events = [{"type": "delta", "content": "partial"}] if with_delta else []
                events += [error, {"type": "done"}]

                async def stream(*args, **kwargs):
                    for event in events:
                        yield event

                self.adapter.stream.side_effect = stream
                self.request.stream = True
                with (
                    patch("app.services.llm_gateway_service.asyncio.sleep", new_callable=AsyncMock),
                    patch.object(self.service, "_record_and_log") as record,
                ):
                    result = [
                        event async for event in self.service.process_stream_request(
                            self.request, {}, MagicMock(),
                        )
                    ]
                self.assertEqual(result, events[:-1])
                self.assertEqual(record.call_args.args[7], "error")
                self.backup_adapter.stream.assert_not_called()

    async def test_successful_stream_preserves_events(self):
        events = [
            {"type": "delta", "content": "answer"},
            {"type": "usage", "input": 1, "output": 2},
            {"type": "done"},
        ]

        async def stream(*args, **kwargs):
            for event in events:
                yield event

        self.adapter.stream.side_effect = stream
        self.request.stream = True
        with patch.object(self.service, "_record_and_log"):
            result = [
                event async for event in self.service.process_stream_request(
                    self.request, {}, MagicMock(),
                )
            ]
        self.assertEqual(result, events)
        self.backup_adapter.stream.assert_not_called()
