#!/usr/bin/env bash
# =============================================================================
# test_tpm_rate_limit.sh
#
# 验证 LlmGateway TPM（Token Per Minute）限流是否生效。
#
# 原理：
#   - 每个请求消耗的 token 数 = sum(len(msg.content)) // 4
#   - TokenBucket 容量 = 数据库中模型的 tpm 值
#   - 当桶内 token 耗尽时，网关应返回 HTTP 429 (rate_limit_exceeded)
#
# 用法：
#   chmod +x test_tpm_rate_limit.sh
#   ./test_tpm_rate_limit.sh
#
# 可调参数（通过环境变量或直接在下方修改）：
#   API_KEY        - API Key
#   MODEL          - 模型 display name
#   BASE_URL       - 网关地址
#   REQUEST_COUNT  - 并发请求总数
#   MSG_SIZE       - 每条 user message 的大致字符数（用于撑大 estimated_tokens）
#   TPM_CAPACITY   - 数据库中该模型配置的 TPM 容量（仅用于显示预估）
# =============================================================================

API_KEY="${API_KEY:-[REDACTED]}"
MODEL="${MODEL:-deepseek-flash-deepseek}"
BASE_URL="${BASE_URL:-http://localhost:8003}"
REQUEST_COUNT="${REQUEST_COUNT:-15}"
MSG_SIZE="${MSG_SIZE:-10000}"
TPM_CAPACITY="${TPM_CAPACITY:-20000}"

# Redis 配置（用于诊断）
REDIS_HOST="${REDIS_HOST:-127.0.0.1}"
REDIS_PORT="${REDIS_PORT:-6379}"
REDIS_DB="${REDIS_DB:-0}"

ENDPOINT="${BASE_URL}/api/llm/v1/chat/completions"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ---------- 生成填充文本 ----------
# 用重复字符构造指定长度的字符串（避免 shell 参数过长，用 printf 循环）
generate_padding() {
    local size=$1
    # 使用重复的短文本块拼接，比纯空格更接近真实场景
    local block="This is a test message for TPM rate limiting verification. "
    local result=""
    while [ ${#result} -lt "$size" ]; do
        result="${result}${block}"
    done
    echo "${result:0:$size}"
}

PADDING=$(generate_padding "$MSG_SIZE")
# estimated_tokens ≈ (system_len + user_len) // 4
EST_TOKENS=$(( (20 + MSG_SIZE) / 4 ))

echo "=============================================="
echo -e "${CYAN}  LlmGateway TPM Rate Limit 测试脚本${NC}"
echo "=============================================="
echo ""
echo -e "${YELLOW}[配置]${NC}"
echo "  网关地址       : ${BASE_URL}"
echo "  模型名称       : ${MODEL}"
echo "  并发请求数     : ${REQUEST_COUNT}"
echo "  每消息字符数   : ${MSG_SIZE} chars"
echo "  预估每请求消耗 : ~${EST_TOKENS} tokens (len//4)"
echo "  预估总消耗     : ~$(( EST_TOKENS * REQUEST_COUNT )) tokens"
echo "  数据库 TPM 容量: ${TPM_CAPACITY}（请根据实际配置核实）"
echo ""

# ---------- Redis 诊断（测试前） ----------
REDIS_KEY_TOKENS="llm_gw:ratelimit:${MODEL}:tpm:tokens"
REDIS_KEY_TS="llm_gw:ratelimit:${MODEL}:tpm:ts"

check_redis() {
    local label=$1
    if command -v redis-cli &>/dev/null; then
        local tokens ts
        tokens=$(redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" -n "$REDIS_DB" GET "$REDIS_KEY_TOKENS" 2>/dev/null)
        ts=$(redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" -n "$REDIS_DB" GET "$REDIS_KEY_TS" 2>/dev/null)
        if [ -z "$tokens" ] || [ "$tokens" = "" ]; then
            tokens="(key不存在，首次访问将按满桶计算)"
        fi
        if [ -z "$ts" ] || [ "$ts" = "" ]; then
            ts="(key不存在)"
        fi
        echo -e "${CYAN}[Redis 诊断 ${label}]${NC}"
        echo "  Key: ${REDIS_KEY_TOKENS}"
        echo "  当前令牌数 : ${tokens}"
        echo "  上次时间戳 : ${ts}"
        echo ""
    else
        echo -e "${YELLOW}[Redis 诊断] redis-cli 未安装，跳过诊断${NC}"
        echo ""
    fi
}

echo "----------------------------------------------"
check_redis "测试前"
echo "----------------------------------------------"
echo "发送请求中..."
echo ""

# ---------- 结果统计 ----------
TMPDIR_RESULTS=$(mktemp -d)
trap "rm -rf ${TMPDIR_RESULTS}" EXIT

TOTAL=0
SUCCESS=0
RATE_LIMITED=0
FAILED=0

# ---------- 并发发送请求 ----------
send_request() {
    local idx=$1
    local start_time end_time elapsed http_code body
    local outfile="${TMPDIR_RESULTS}/req_${idx}.json"

    start_time=$(python3 -c "import time; print(int(time.time()*1000))")

    body=$(curl -s -w "\n%{http_code}" \
        -X POST "${ENDPOINT}" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${API_KEY}" \
        -d "{
            \"model\": \"${MODEL}\",
            \"messages\": [
                {\"role\": \"system\", \"content\": \"你是一个测试助手，简洁回复。\"},
                {\"role\": \"user\", \"content\": \"${PADDING}\"}
            ],
            \"temperature\": 0.1,
            \"max_tokens\": 5
        }" \
        --max-time 60 2>/dev/null)

    end_time=$(python3 -c "import time; print(int(time.time()*1000))")
    elapsed_ms=$(( end_time - start_time ))
    elapsed_sec=$(( elapsed_ms / 1000 ))
    elapsed_frac=$(printf '%03d' $(( elapsed_ms % 1000 )))
    elapsed_display="${elapsed_sec}.${elapsed_frac}"

    # 分离 HTTP status code 和 body（curl -w 追加的最后一行）
    http_code=$(echo "$body" | tail -1 | tr -d '[:space:]')
    response_body=$(echo "$body" | sed '$d')

    echo "$response_body" > "$outfile"

    # 输出单条结果
    if [ "$http_code" = "200" ]; then
        echo -e "  [${GREEN}✓${NC}] #${idx}  HTTP ${http_code}  ${elapsed_display}s"
    elif [ "$http_code" = "429" ]; then
        echo -e "  [${YELLOW}⚠${NC}] #${idx}  HTTP ${http_code}  ${elapsed_display}s  ← TPM 限流触发"
    else
        echo -e "  [${RED}✗${NC}] #${idx}  HTTP ${http_code}  ${elapsed_display}s  $(echo "$response_body" | head -c 100)"
    fi
}

# ---------- 主流程：并发发送 ----------
pids=()
for i in $(seq 1 "$REQUEST_COUNT"); do
    send_request "$i" &
    pids+=($!)
done

# 等待所有后台任务完成
for pid in "${pids[@]}"; do
    wait "$pid"
done

echo ""
echo "----------------------------------------------"
echo "统计结果..."
echo ""
check_redis "测试后"

# ---------- 汇总统计 ----------
for i in $(seq 1 "$REQUEST_COUNT"); do
    outfile="${TMPDIR_RESULTS}/req_${i}.json"
    if [ ! -f "$outfile" ]; then
        FAILED=$((FAILED + 1))
        TOTAL=$((TOTAL + 1))
        continue
    fi

    content=$(cat "$outfile")
    TOTAL=$((TOTAL + 1))

    # 通过响应内容判断类型
    if echo "$content" | grep -q '"rate_limit_exceeded"'; then
        RATE_LIMITED=$((RATE_LIMITED + 1))
    elif echo "$content" | grep -q '"choices"'; then
        SUCCESS=$((SUCCESS + 1))
    else
        FAILED=$((FAILED + 1))
    fi
done

echo ""
echo -e "${CYAN}=============================================="
echo -e "  测试结果汇总"
echo -e "==============================================${NC}"
echo ""
echo -e "  总请求数          : ${TOTAL}"
echo -e "  成功 (HTTP 200)   : ${GREEN}${SUCCESS}${NC}"
echo -e "  限流 (HTTP 429)   : ${YELLOW}${RATE_LIMITED}${NC}"
echo -e "  失败 (其他错误)   : ${RED}${FAILED}${NC}"
echo ""

# ---------- 结论判断 ----------
if [ "$RATE_LIMITED" -gt 0 ]; then
    echo -e "${GREEN}[PASS]${NC} TPM 限流已触发！共 ${RATE_LIMITED} 个请求被限流 (HTTP 429)。"
    echo "       说明 TokenBucket 令牌耗尽后，网关正确返回了 rate_limit_exceeded。"
elif [ "$FAILED" -gt 0 ] && [ "$SUCCESS" -eq 0 ]; then
    echo -e "${RED}[FAIL]${NC} 所有请求均失败，可能是 API Key 无效、模型不存在或网关未启动。"
    echo "       请检查服务日志排查问题。"
elif [ "$SUCCESS" -eq "$TOTAL" ]; then
    echo -e "${YELLOW}[INFO]${NC} 所有请求均成功，TPM 限流未触发。"
    echo "       可能原因："
    echo "         1. 数据库中该模型的 tpm=0（不限流）"
    echo "         2. 数据库 TPM 实际值大于预期，当前请求量不足以耗尽"
    echo "         3. Redis 不可用，限流降级放行（见服务日志 warning）"
    echo ""
    echo "       排查步骤："
    echo "         1. 检查 Redis 中 TPM key 是否存在："
    echo "            redis-cli GET ${REDIS_KEY_TOKENS}"
    echo "         2. 检查数据库中模型的 tpm 字段："
    echo "            SELECT name, tpm FROM llm_gateway.models WHERE display_name='${MODEL}' OR name='${MODEL}';"
    echo "         3. 检查服务日志中是否有 Redis 降级 warning"
else
    echo -e "${YELLOW}[WARN]${NC} 部分请求失败，但非限流原因，请查看具体错误内容。"
fi

echo ""
echo "----------------------------------------------"
echo "提示：TokenBucket 补充速率 = TPM容量 / 60 (tokens/sec)"
echo "      当前 TPM=20000 → 约 333 tokens/sec 自动补充"
echo "      等待约 60 秒后再次执行，可观察限流是否恢复。"
echo "----------------------------------------------"
