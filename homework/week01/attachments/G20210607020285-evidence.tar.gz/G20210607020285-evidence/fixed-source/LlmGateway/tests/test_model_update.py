import unittest
from unittest.mock import patch

from cryptography.fernet import Fernet
from pydantic import ValidationError
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.encryption import decrypt_value
from app.models.model import Model
from app.schemas.model import ModelCreate, ModelUpdate, ModelResponse
from app.services.model_service import create_model, list_models, update_model


class ModelUpdateTests(unittest.TestCase):
    def setUp(self):
        key_patch = patch.object(
            settings.encryption, "fernet_key", Fernet.generate_key().decode()
        )
        key_patch.start()
        self.addCleanup(key_patch.stop)
        self.engine = create_engine("sqlite://").execution_options(
            schema_translate_map={settings.database.db_schema: None}
        )
        self.addCleanup(self.engine.dispose)
        Model.__table__.create(self.engine)
        self.db = Session(self.engine)
        self.addCleanup(self.db.close)
        self.fields = {
            "name": "example-model",
            "category": "chat",
            "provider": "OpenAI",
            "url": "https://example.com",
            "context_tokens": 4096,
            "rpm": 0,
            "tpm": 0,
            "input_per_million": 0,
            "output_per_million": 0,
            "cached_input_per_million": 0,
        }
        self.original_key = "test-original-key"
        result = create_model(
            self.db, ModelCreate(**self.fields, api_key=self.original_key)
        )
        self.model = self.db.get(Model, result["id"])
        self.original_ciphertext = self.model.api_key_encrypted

    def test_edit_preserves_key_when_omitted_or_blank(self):
        for key_fields in ({}, {"api_key": None}, {"api_key": ""}, {"api_key": "  \t"}):
            with self.subTest(key_fields=key_fields):
                result = update_model(
                    self.db,
                    self.model.id,
                    ModelUpdate(**{**self.fields, "name": "renamed"}, **key_fields),
                )
                self.db.expire_all()
                self.assertEqual(self.model.name, "renamed")
                self.assertEqual(
                    self.model.api_key_encrypted, self.original_ciphertext
                )
                self.assertEqual(
                    decrypt_value(self.model.api_key_encrypted), self.original_key
                )
                self.assertNotIn("api_key", result)

    def test_edit_replaces_key_when_provided(self):
        result = update_model(
            self.db,
            self.model.id,
            ModelUpdate(**self.fields, api_key="test-replacement-key"),
        )
        self.db.expire_all()
        self.assertNotEqual(self.model.api_key_encrypted, self.original_ciphertext)
        self.assertEqual(
            decrypt_value(self.model.api_key_encrypted), "test-replacement-key"
        )
        self.assertEqual(result["api_key_masked"], "tes****-key")
        self.assertNotIn("api_key", result)

    def test_create_still_requires_key(self):
        for key_fields in ({}, {"api_key": None}, {"api_key": ""}):
            with self.subTest(key_fields=key_fields):
                with self.assertRaises(ValidationError):
                    ModelCreate(**self.fields, **key_fields)

    def test_model_contract_and_storage_no_longer_include_capabilities(self):
        self.assertNotIn("capabilities", Model.__table__.columns)
        for schema in (ModelCreate, ModelUpdate, ModelResponse):
            with self.subTest(schema=schema.__name__):
                self.assertNotIn("capabilities", schema.model_json_schema()["properties"])

        updated = update_model(
            self.db, self.model.id, ModelUpdate(**self.fields),
        )
        items, total = list_models(self.db)
        self.assertEqual(total, 1)
        for result in (updated, items[0]):
            self.assertNotIn("capabilities", result)
            ModelResponse.model_validate(result)

    def test_edit_still_validates_other_fields_and_key_type(self):
        for changes in ({"context_tokens": 0}, {"rpm": -1}, {"api_key": 123}):
            with self.subTest(changes=changes):
                with self.assertRaises(ValidationError):
                    ModelUpdate(**{**self.fields, **changes})


if __name__ == "__main__":
    unittest.main()
