import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from app.adapters.anthropic_adapter import AnthropicAdapter
from app.adapters.base import ModelConfig
from app.adapters.openai_adapter import OpenAIAdapter
from app.gateway.errors import UpstreamError, UpstreamTimeoutError
from app.gateway.registry import ModelRegistry
from app.schemas.chat_completion import ChatCompletionRequest
from app.services.llm_gateway_service import LLMGatewayService


class CompletionRetryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        config = ModelConfig(
            name="model", provider="test", url="https://example.com",
            api_key="test-key",
        )
        self.registry = ModelRegistry()
        self.registry.models = {"model": config}
        self.service = LLMGatewayService(self.registry)
        self.request = ChatCompletionRequest(
            model="model", messages=[{"role": "user", "content": "hello"}],
        )

    async def test_http_errors_obey_retry_policy(self):
        statuses = {
            302: 1, 400: 1, 401: 1, 403: 1, 404: 1, 422: 1,
            408: 4, 409: 4, 429: 4, 500: 4, 503: 4, 599: 4,
        }
        client_class = httpx.AsyncClient
        for adapter_class in (OpenAIAdapter, AnthropicAdapter):
            self.registry.adapters["test"] = adapter_class()
            for status, expected_attempts in statuses.items():
                with self.subTest(adapter=adapter_class.__name__, status=status):
                    count = 0

                    def respond(request):
                        nonlocal count
                        count += 1
                        return httpx.Response(status, text="provider error")

                    with (
                        patch(
                            "httpx.AsyncClient",
                            side_effect=lambda **kwargs: client_class(
                                transport=httpx.MockTransport(respond), **kwargs
                            ),
                        ),
                        patch("app.gateway.retry.asyncio.sleep", new_callable=AsyncMock) as sleep,
                        self.assertRaises(UpstreamError) as raised,
                    ):
                        await self.service.process_request(self.request, {}, MagicMock())

                    self.assertEqual(count, expected_attempts)
                    self.assertEqual(sleep.await_count, expected_attempts - 1)
                    self.assertEqual(raised.exception.retryable, expected_attempts > 1)
                    self.assertEqual(raised.exception.http_status, 502)
                    self.assertEqual(raised.exception.to_dict(), {
                        "error": {
                            "message": f"{adapter_class.__name__.replace('Adapter', '')} API returned {status}: provider error",
                            "type": "service_error",
                            "code": "upstream_error",
                        }
                    })

    async def test_retryable_failure_then_success(self):
        client_class = httpx.AsyncClient
        for adapter_class in (OpenAIAdapter, AnthropicAdapter):
            with self.subTest(adapter=adapter_class.__name__):
                self.registry.adapters["test"] = adapter_class()
                count = 0

                def respond(request):
                    nonlocal count
                    count += 1
                    if count == 1:
                        return httpx.Response(503, text="unavailable")
                    if adapter_class is OpenAIAdapter:
                        return httpx.Response(200, json={
                            "choices": [{"message": {"content": "ok"}}],
                        })
                    return httpx.Response(200, json={
                        "content": [{"type": "text", "text": "ok"}],
                    })

                with (
                    patch(
                        "httpx.AsyncClient",
                        side_effect=lambda **kwargs: client_class(
                            transport=httpx.MockTransport(respond), **kwargs
                        ),
                    ),
                    patch("app.gateway.retry.asyncio.sleep", new_callable=AsyncMock) as sleep,
                    patch.object(self.service, "_record_and_log") as record,
                ):
                    result = await self.service.process_request(self.request, {}, MagicMock())
                self.assertEqual(result.choices[0].message["content"], "ok")
                self.assertEqual(count, 2)
                self.assertEqual(record.call_args.args[6], 1)
                sleep.assert_awaited_once()

    async def test_connection_and_timeout_remain_retryable(self):
        client_class = httpx.AsyncClient
        for adapter_class in (OpenAIAdapter, AnthropicAdapter):
            self.registry.adapters["test"] = adapter_class()
            for failure, expected_error in (
                (httpx.ConnectError("unavailable"), UpstreamError),
                (httpx.ReadTimeout("timeout"), UpstreamTimeoutError),
            ):
                with self.subTest(adapter=adapter_class.__name__, failure=failure):
                    count = 0

                    def respond(request):
                        nonlocal count
                        count += 1
                        raise failure

                    with (
                        patch(
                            "httpx.AsyncClient",
                            side_effect=lambda **kwargs: client_class(
                                transport=httpx.MockTransport(respond), **kwargs
                            ),
                        ),
                        patch("app.gateway.retry.asyncio.sleep", new_callable=AsyncMock) as sleep,
                        self.assertRaises(expected_error),
                    ):
                        await self.service.process_request(self.request, {}, MagicMock())
                    self.assertEqual(count, 4)
                    self.assertEqual(sleep.await_count, 3)
