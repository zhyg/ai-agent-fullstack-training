import logging
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.database import init_schema, SessionLocal
from app.core.config import settings
from app.routers import models, v1_chat
from app.gateway.registry import ModelRegistry
from app.gateway.rate_limiter import RateLimiterManager
from app.adapters.openai_adapter import OpenAIAdapter
from app.adapters.anthropic_adapter import AnthropicAdapter
from app.gateway.observability import setup_metrics_endpoint
from app.gateway.errors import GatewayError
from app.services.llm_gateway_service import LLMGatewayService

logging.basicConfig(
    level=settings.logging.level,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown lifecycle."""
    logger.info("Initializing LlmGateway service...")
    init_schema()

    # Initialize model registry with adapters
    registry = ModelRegistry()
    registry.register_adapter(OpenAIAdapter())
    registry.register_adapter(AnthropicAdapter())

    # Load model configs from database
    db = SessionLocal()
    try:
        registry.load_from_db(db)
    finally:
        db.close()

    # Redis client for distributed rate limiting
    redis_client = aioredis.Redis(
        host=settings.redis.host,
        port=settings.redis.port,
        db=settings.redis.db,
        password=settings.redis.password,
        decode_responses=True,
    )

    # Initialize gateway components
    app.state.registry = registry
    rate_limiter = RateLimiterManager(redis_client)
    app.state.gateway_service = LLMGatewayService(
        registry,
        rate_limiter=rate_limiter,
    )

    # Register Prometheus /metrics endpoint
    setup_metrics_endpoint(app)

    logger.info("LlmGateway service started")
    yield
    await redis_client.aclose()
    logger.info("LlmGateway service shutting down")


app = FastAPI(
    title="LlmGateway Service",
    description="LLM 网关服务 - 开发者门户平台",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware — read from config
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors.allow_origins,
    allow_credentials=settings.cors.allow_credentials,
    allow_methods=settings.cors.allow_methods,
    allow_headers=settings.cors.allow_headers,
)

# Global exception handler for GatewayError (covers dependency injection phase)
@app.exception_handler(GatewayError)
async def gateway_error_handler(request: Request, exc: GatewayError):
    return JSONResponse(
        status_code=exc.http_status,
        content=exc.to_dict(),
    )


# Register routers
app.include_router(models.router, prefix="/api/llm")
app.include_router(v1_chat.router, prefix="/api/llm")


@app.get("/api/llm/health")
async def health_check():
    return {"status": "ok", "service": "LlmGateway"}
