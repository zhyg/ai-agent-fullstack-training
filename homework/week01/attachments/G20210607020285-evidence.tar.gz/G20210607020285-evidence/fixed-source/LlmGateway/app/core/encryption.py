from cryptography.fernet import Fernet
from app.core.config import settings


def _get_fernet() -> Fernet:
    """Create a Fernet instance from the configured key."""
    key = settings.encryption.fernet_key
    return Fernet(key.encode() if isinstance(key, str) else key)


def encrypt_value(plain_text: str) -> str:
    """Encrypt a string value using Fernet symmetric encryption."""
    f = _get_fernet()
    return f.encrypt(plain_text.encode()).decode()


def decrypt_value(encrypted_text: str) -> str:
    """Decrypt a Fernet-encrypted string value."""
    f = _get_fernet()
    return f.decrypt(encrypted_text.encode()).decode()


def mask_api_key(api_key: str) -> str:
    """Mask an API key for display: show first 3 + **** + last 4 chars."""
    if len(api_key) <= 7:
        return "****"
    return f"{api_key[:3]}****{api_key[-4:]}"
