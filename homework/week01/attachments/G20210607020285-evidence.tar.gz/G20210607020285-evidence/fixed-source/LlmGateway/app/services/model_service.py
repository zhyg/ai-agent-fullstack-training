import uuid
from datetime import datetime, timezone
from typing import Optional, List, Tuple
from decimal import Decimal

from sqlalchemy.orm import Session

from app.models.model import Model
from app.schemas.model import ModelCreate, ModelUpdate
from app.core.encryption import encrypt_value, decrypt_value, mask_api_key


def _model_to_response(model: Model) -> dict:
    """Convert a Model ORM object to a response dict with masked API key."""
    decrypted_key = decrypt_value(model.api_key_encrypted)
    return {
        "id": model.id,
        "name": model.name,
        "display_name": model.display_name,
        "category": model.category,
        "provider": model.provider,
        "url": model.url,
        "api_key_masked": mask_api_key(decrypted_key),
        "context_tokens": model.context_tokens,
        "rpm": model.rpm,
        "tpm": model.tpm,
        "input_per_million": model.input_per_million,
        "output_per_million": model.output_per_million,
        "cached_input_per_million": model.cached_input_per_million,
        "created_at": model.created_at,
        "updated_at": model.updated_at,
    }


def create_model(db: Session, data: ModelCreate) -> dict:
    """Create a new model with Fernet-encrypted api_key storage."""
    # 唯一性预检查：同一供应商下 name 不可重复
    existing = (
        db.query(Model)
        .filter(Model.provider == data.provider, Model.name == data.name)
        .first()
    )
    if existing:
        raise ValueError("该供应商下已存在同名模型")

    encrypted_key = encrypt_value(data.api_key)

    model = Model(
        id=str(uuid.uuid4()),
        name=data.name,
        display_name=data.display_name,
        category=data.category,
        provider=data.provider,
        url=data.url,
        api_key_encrypted=encrypted_key,
        context_tokens=data.context_tokens,
        rpm=data.rpm,
        tpm=data.tpm,
        input_per_million=data.input_per_million,
        output_per_million=data.output_per_million,
        cached_input_per_million=data.cached_input_per_million,
    )
    db.add(model)
    db.commit()
    db.refresh(model)
    return _model_to_response(model)


def list_models(
    db: Session, page: int = 1, page_size: int = 20
) -> Tuple[List[dict], int]:
    """List all models with masked API keys."""
    query = db.query(Model)
    total = query.count()
    items = (
        query.order_by(Model.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    result = [_model_to_response(m) for m in items]
    return result, total


def update_model(
    db: Session, model_id: str, data: ModelUpdate
) -> Optional[dict]:
    """Update a model, preserving the stored key unless a new one is provided."""
    model = db.query(Model).filter(Model.id == model_id).first()
    if not model:
        return None

    # 唯一性预检查：同一供应商下 name 不可重复（排除自身）
    if data.provider != model.provider or data.name != model.name:
        existing = (
            db.query(Model)
            .filter(
                Model.provider == data.provider,
                Model.name == data.name,
                Model.id != model_id,
            )
            .first()
        )
        if existing:
            raise ValueError("该供应商下已存在同名模型")

    model.name = data.name
    model.display_name = data.display_name
    model.category = data.category
    model.provider = data.provider
    model.url = data.url
    if data.api_key is not None:
        model.api_key_encrypted = encrypt_value(data.api_key)
    model.context_tokens = data.context_tokens
    model.rpm = data.rpm
    model.tpm = data.tpm
    model.input_per_million = data.input_per_million
    model.output_per_million = data.output_per_million
    model.cached_input_per_million = data.cached_input_per_million
    model.updated_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(model)
    return _model_to_response(model)


def delete_model(db: Session, model_id: str) -> bool:
    """Delete a model."""
    model = db.query(Model).filter(Model.id == model_id).first()
    if not model:
        return False

    db.delete(model)
    db.commit()
    return True
