"""OpenAI Compatible API router: /v1/chat/completions."""

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_api_key_user
from app.schemas.chat_completion import ChatCompletionRequest
from app.services.llm_gateway_service import LLMGatewayService
from app.gateway.errors import GatewayError
from app.gateway.sse import (
    format_sse_event,
    format_sse_done,
    format_delta_chunk,
    format_final_chunk,
    format_error_event,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1", tags=["OpenAI Compatible"])

# Max request body size: 1MB
MAX_BODY_SIZE = 1 * 1024 * 1024


def _get_gateway_service(request: Request) -> LLMGatewayService:
    """Get the gateway service from app state."""
    return request.app.state.gateway_service


@router.post("/chat/completions")
async def chat_completions(
    body: ChatCompletionRequest,
    request: Request,
    user: dict = Depends(get_api_key_user),
    db: Session = Depends(get_db),
):
    """OpenAI Compatible Chat Completions endpoint.

    Supports both streaming (stream=true) and non-streaming (stream=false) modes.
    Authentication: API Key Bearer Token.
    """
    # Request body size check
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_BODY_SIZE:
        return JSONResponse(
            status_code=413,
            content={
                "error": {
                    "message": f"Request body too large. Max {MAX_BODY_SIZE // 1024 // 1024}MB allowed.",
                    "type": "invalid_request_error",
                    "code": "request_too_large",
                }
            },
        )

    gateway_service = _get_gateway_service(request)

    try:
        if not body.stream:
            # Non-streaming mode
            response = await gateway_service.process_request(body, user, db)
            return response.model_dump()
        else:
            # Streaming mode — SSE
            async def event_generator():
                delta_events = 0
                content_chars = 0
                logger.info("gateway_stream start model=%s", body.model)
                try:
                    async for event in gateway_service.process_stream_request(
                        body, user, db
                    ):
                        event_type = event.get("type")
                        if event_type == "delta":
                            delta_events += 1
                            content_chars += len(event.get("content", ""))
                            yield format_delta_chunk(
                                id_="",
                                model=body.model,
                                content=event.get("content", ""),
                            )
                        elif event_type == "usage":
                            yield format_final_chunk(
                                id_="",
                                model=body.model,
                                usage=event,
                            )
                        elif event_type == "done":
                            yield format_sse_done()
                            return
                        elif event_type == "error":
                            from app.gateway.errors import UpstreamError
                            err = UpstreamError(event.get("message", "Unknown error"))
                            yield format_error_event(err)
                            yield format_sse_done()
                            return
                    # If stream ended without explicit done
                    yield format_sse_done()
                except GatewayError as e:
                    logger.error(
                        "gateway_stream rejected model=%s error_type=%s error_code=%s",
                        body.model, e.error_type, e.error_code,
                    )
                    yield format_error_event(e)
                    yield format_sse_done()
                except Exception as e:
                    logger.error(f"Streaming error: {e}")
                    from app.gateway.errors import UpstreamError
                    yield format_error_event(UpstreamError(str(e)))
                    yield format_sse_done()
                finally:
                    log_summary = logger.info if content_chars else logger.warning
                    log_summary(
                        "gateway_stream summary model=%s delta_events=%d content_chars=%d",
                        body.model, delta_events, content_chars,
                    )

            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

    except GatewayError as e:
        return JSONResponse(
            status_code=e.http_status,
            content=e.to_dict(),
        )
    except Exception as e:
        logger.error(f"Unexpected error in chat completions: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "message": "Internal server error",
                    "type": "internal_error",
                    "code": "internal_error",
                }
            },
        )
