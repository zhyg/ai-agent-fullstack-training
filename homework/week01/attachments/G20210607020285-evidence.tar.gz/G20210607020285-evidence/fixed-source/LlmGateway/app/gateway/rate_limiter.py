"""Distributed rate limiter backed by Redis.

RPM — sliding window counter implemented with a sorted set.
TPM — token bucket implemented with a Lua script for atomicity.

All state lives in Redis so multiple gateway instances share the same counters.
If Redis is unreachable the limiter degrades gracefully: requests are allowed
and a warning is logged, so a Redis outage does not take down the gateway.
"""

import logging
import time
import uuid

import redis.asyncio as redis

from app.gateway.errors import RateLimitError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lua script for atomic token-bucket operations.
# KEYS[1] = tokens key, KEYS[2] = last-refill timestamp key
# ARGV[1] = capacity, ARGV[2] = refill_rate (tokens/sec), ARGV[3] = requested tokens
# Returns: {allowed (0/1), tokens_remaining}
# ---------------------------------------------------------------------------
_TPM_LUA = """
local tokens_key = KEYS[1]
local ts_key     = KEYS[2]
local capacity   = tonumber(ARGV[1])
local rate       = tonumber(ARGV[2])
local requested  = tonumber(ARGV[3])
local now        = tonumber(ARGV[4])

local last  = tonumber(redis.call('GET', ts_key) or now)
local avail = math.min(capacity,
    tonumber(redis.call('GET', tokens_key) or capacity) + (now - (last or now)) * rate)

if avail >= requested then
    redis.call('SET', tokens_key, avail - requested)
    redis.call('SET', ts_key, now)
    return {1, avail - requested}
else
    return {0, avail}
end
"""


class SlidingWindowCounter:
    """Distributed RPM limiter using a Redis sorted set."""

    def __init__(self, redis_client: redis.Redis, key: str, limit: int, window_seconds: float = 60.0):
        self._redis = redis_client
        self._key = key
        self.limit = limit
        self.window_seconds = window_seconds

    async def allow_request(self) -> bool:
        if self.limit <= 0:
            return True

        now = time.time()
        cutoff = now - self.window_seconds
        # Use a unique member so concurrent requests don't collide on the same score.
        member = f"{now}:{uuid.uuid4().hex[:8]}"

        pipe = self._redis.pipeline()
        pipe.zremrangebyscore(self._key, 0, cutoff)
        pipe.zadd(self._key, {member: now})
        pipe.zcard(self._key)
        pipe.expire(self._key, int(self.window_seconds) + 1)
        results = await pipe.execute()
        count = results[2]

        if count > self.limit:
            # Over limit — remove the member we just added.
            await self._redis.zrem(self._key, member)
            return False
        return True

    async def current_count(self) -> int:
        now = time.time()
        cutoff = now - self.window_seconds
        await self._redis.zremrangebyscore(self._key, 0, cutoff)
        return await self._redis.zcard(self._key)


class TokenBucket:
    """Distributed TPM limiter using an atomic Lua script."""

    def __init__(
        self,
        redis_client: redis.Redis,
        tokens_key: str,
        ts_key: str,
        capacity: int,
        refill_rate: float = 0.0,
    ):
        self._redis = redis_client
        self._tokens_key = tokens_key
        self._ts_key = ts_key
        self.capacity = capacity
        self.refill_rate = refill_rate or (capacity / 60.0 if capacity > 0 else 0)
        self._script = self._redis.register_script(_TPM_LUA)

    async def allow_tokens(self, tokens: int) -> bool:
        if self.capacity <= 0:
            return True

        now = time.time()
        allowed, _ = await self._script(
            keys=[self._tokens_key, self._ts_key],
            args=[self.capacity, self.refill_rate, tokens, now],
        )
        return bool(allowed)


class RateLimiterManager:
    """Manages per-model distributed rate limiters.

    Counters are stored in Redis so all gateway instances share the same state.
    Limiters are created lazily on first check — no explicit registration needed.
    """

    KEY_PREFIX = "llm_gw:ratelimit"

    def __init__(self, redis_client: redis.Redis):
        self._redis = redis_client
        self._limiters: dict[str, tuple[SlidingWindowCounter, TokenBucket]] = {}

    def _get_or_create(self, model_name: str, rpm: int, tpm: int):
        if model_name not in self._limiters:
            prefix = f"{self.KEY_PREFIX}:{model_name}"
            self._limiters[model_name] = (
                SlidingWindowCounter(self._redis, f"{prefix}:rpm", rpm),
                TokenBucket(self._redis, f"{prefix}:tpm:tokens", f"{prefix}:tpm:ts", tpm),
            )
        return self._limiters[model_name]

    async def check(self, model_name: str, estimated_tokens: int = 0, rpm: int = 0, tpm: int = 0):
        """Check rate limits for a model. Raises RateLimitError if exceeded."""
        try:
            rpm_limiter, tpm_limiter = self._get_or_create(model_name, rpm, tpm)

            if not await rpm_limiter.allow_request():
                count = await rpm_limiter.current_count()
                raise RateLimitError(
                    f"Rate limit exceeded for model '{model_name}'. "
                    f"RPM: {count}/{rpm_limiter.limit}"
                )

            if estimated_tokens > 0 and not await tpm_limiter.allow_tokens(estimated_tokens):
                raise RateLimitError(
                    f"Token limit exceeded for model '{model_name}'. "
                    f"TPM capacity: {tpm_limiter.capacity}"
                )
        except redis.RedisError as exc:
            # Redis unavailable — degrade gracefully, allow the request through.
            logger.warning("Redis rate-limiter unavailable, allowing request: %s", exc)
