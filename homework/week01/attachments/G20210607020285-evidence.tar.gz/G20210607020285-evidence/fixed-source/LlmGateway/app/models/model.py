import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, Text, TIMESTAMP, Numeric, UniqueConstraint

from app.core.database import Base
from app.core.config import settings


class Model(Base):
    __tablename__ = "models"
    __table_args__ = (
        UniqueConstraint('provider', 'name', name='uq_models_provider_name'),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False, comment="模型名称")
    display_name = Column(String(200), nullable=True, comment="模型显示名称")
    category = Column(String(20), nullable=False, default='chat', comment="模型分类")
    provider = Column(String(100), nullable=False, comment="模型供应商")
    url = Column(String(500), nullable=False, comment="LLM API 端点 URL")
    api_key_encrypted = Column(Text, nullable=False, comment="Fernet 加密后的 API Key")
    context_tokens = Column(Integer, nullable=False, comment="上下文窗口大小")
    rpm = Column(Integer, nullable=False, comment="Rate Limit: Requests Per Minute")
    tpm = Column(Integer, nullable=False, comment="Rate Limit: Tokens Per Minute")
    input_per_million = Column(Numeric(10, 4), nullable=False, comment="输入 token 价格/百万")
    output_per_million = Column(Numeric(10, 4), nullable=False, comment="输出 token 价格/百万")
    cached_input_per_million = Column(Numeric(10, 4), nullable=False, comment="缓存命中 token 价格/百万")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )
