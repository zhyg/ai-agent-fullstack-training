import os
import yaml
from pydantic import BaseModel, Field
from typing import Optional, List


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8003


class DatabaseConfig(BaseModel):
    url: str
    db_schema: str = Field(default="public", validation_alias="schema")
    echo: bool = False


class JwtConfig(BaseModel):
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7


class EncryptionConfig(BaseModel):
    fernet_key: str = ""


class LoggingConfig(BaseModel):
    level: str = "INFO"


class RedisConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None


class CorsConfig(BaseModel):
    allow_origins: List[str] = ["*"]
    allow_credentials: bool = True
    allow_methods: List[str] = ["*"]
    allow_headers: List[str] = ["*"]


class Settings(BaseModel):
    server: ServerConfig
    database: DatabaseConfig
    jwt: JwtConfig
    provider_timeout: float = Field(gt=0)
    encryption: EncryptionConfig = EncryptionConfig()
    redis: RedisConfig = RedisConfig()
    cors: CorsConfig = CorsConfig()
    services: dict = {}
    logging: LoggingConfig = LoggingConfig()


def load_settings(env: Optional[str] = None) -> Settings:
    env = env or os.getenv("APP_ENV", "dev")
    config_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        f"config.{env}.yaml"
    )
    with open(config_path) as f:
        data = yaml.safe_load(f)
    return Settings(**data)


settings = load_settings()
