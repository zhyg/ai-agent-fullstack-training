"""Abstract base class for LLM provider adapters."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator


@dataclass
class ModelConfig:
    """Runtime model configuration loaded from the database."""

    name: str
    provider: str
    url: str
    api_key: str
    rpm: int = 0
    tpm: int = 0
    context_tokens: int = 0
    pricing: dict[str, float] = field(default_factory=dict)


class BaseAdapter(ABC):
    """Abstract adapter for LLM provider APIs.

    Each adapter encapsulates the protocol differences of a specific
    LLM provider (OpenAI Responses API, Anthropic Messages API, etc.).
    """

    @property
    @abstractmethod
    def provider(self) -> str:
        """Unique provider identifier (e.g. 'openai', 'anthropic')."""
        ...

    @property
    def health_status(self) -> str:
        """Current health status of the adapter."""
        return getattr(self, "_health_status", "healthy")

    @health_status.setter
    def health_status(self, value: str):
        self._health_status = value

    @abstractmethod
    async def complete(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> dict:
        """Non-streaming call. Returns unified response dict.

        Expected return structure:
        {
            "content": str,
            "finish_reason": str,
            "usage": {"input": int, "output": int, "cached": int, "reasoning": int},
        }
        """
        ...

    @abstractmethod
    async def stream(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> AsyncGenerator[dict, None]:
        """Streaming call. Yields standardized event dicts.

        Event types:
        - {"type": "delta", "content": "..."}
        - {"type": "usage", "input": int, "output": int, "cached": int, "reasoning": int}
        - {"type": "done"}
        - {"type": "error", "message": "...", "error_code": "..."}

        Set retryable to False on an error event for non-retryable provider failures.
        Unexpected exceptions must propagate instead of being marked retryable.
        """
        ...
