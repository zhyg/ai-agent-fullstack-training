"""Prompt template service: fetches prompt templates from KnowledgeManage."""

import logging

import httpx

from app.core.config import settings
from app.gateway.errors import PromptNotFoundError, PromptServiceUnavailableError

logger = logging.getLogger(__name__)


async def fetch_prompt(prompt_name: str, version: str) -> dict:
    """Fetch a prompt template from KnowledgeManage service.

    Args:
        prompt_name: Name of the prompt template.
        version: Version of the prompt template.

    Returns:
        dict with keys: id, name, version, content

    Raises:
        PromptNotFoundError: If the prompt doesn't exist (HTTP 404).
        PromptServiceUnavailableError: If KnowledgeManage is unreachable.
    """
    km_url = settings.services.get("knowledge_manage", "http://localhost:8002")
    endpoint = f"{km_url}/api/knowledge/prompts/lookup"

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                endpoint,
                params={"name": prompt_name, "version": version},
            )

            if response.status_code == 200:
                data = response.json()
                return {
                    "id": data.get("id"),
                    "name": data.get("name", prompt_name),
                    "version": data.get("version", version),
                    "content": data.get("content", ""),
                }
            elif response.status_code == 404:
                raise PromptNotFoundError(
                    f"Prompt template '{prompt_name}' version '{version}' not found"
                )
            else:
                logger.error(
                    f"KnowledgeManage returned {response.status_code} for prompt lookup"
                )
                raise PromptServiceUnavailableError(
                    f"Prompt service returned {response.status_code}"
                )

    except (PromptNotFoundError, PromptServiceUnavailableError):
        raise
    except httpx.ConnectError as e:
        logger.error(f"KnowledgeManage connection failed: {e}")
        raise PromptServiceUnavailableError("Prompt template service unavailable")
    except httpx.TimeoutException:
        logger.error("KnowledgeManage request timeout")
        raise PromptServiceUnavailableError("Prompt template service timeout")
    except Exception as e:
        logger.error(f"Prompt fetch failed: {e}")
        raise PromptServiceUnavailableError(str(e))
