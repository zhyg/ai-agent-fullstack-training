"""OpenAI Responses API adapter."""

import json
import logging
from typing import Any, AsyncGenerator

import httpx

from app.adapters.base import BaseAdapter, ModelConfig
from app.gateway.errors import UpstreamError, UpstreamTimeoutError
from app.gateway.retry import is_retryable_http_status
from app.core.config import settings

logger = logging.getLogger(__name__)

_CHAT_COMPLETIONS_SUFFIX = "/chat/completions"


def _normalize_url(url: str) -> str:
    """Ensure the URL ends with /chat/completions path."""
    url = url.rstrip("/")
    if not url.endswith(_CHAT_COMPLETIONS_SUFFIX):
        url += _CHAT_COMPLETIONS_SUFFIX
    return url


class OpenAIAdapter(BaseAdapter):
    """Adapter for OpenAI-compatible Responses API."""

    _provider = "openai"

    @property
    def provider(self) -> str:
        return self._provider

    def _build_headers(self, model_config: ModelConfig) -> dict:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {model_config.api_key}",
        }

    def _build_payload(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> dict:
        payload: dict[str, Any] = {
            "model": model_config.name,
            "messages": messages,
            "stream": kwargs.get("stream", False),
        }
        if "temperature" in kwargs:
            payload["temperature"] = kwargs["temperature"]
        if "max_tokens" in kwargs:
            payload["max_tokens"] = kwargs["max_tokens"]
        if "response_format" in kwargs and kwargs["response_format"]:
            payload["response_format"] = kwargs["response_format"]
        return payload

    def _parse_usage(self, usage_data: dict | None) -> dict:
        if not usage_data:
            return {"input": 0, "output": 0, "cached": 0, "reasoning": 0}
        logger.info("provider_parse_usage usage_data=%s", usage_data)
        # provider_parse_usage usage_data={'prompt_tokens': 4776, 'completion_tokens': 791, 'total_tokens': 5567, 'prompt_tokens_details': {'cached_tokens': 3840}, 'completion_tokens_details': {'reasoning_tokens': 110}, 'prompt_cache_hit_tokens': 3840, 'prompt_cache_miss_tokens': 936}
        prompt_details = usage_data.get("prompt_tokens_details") or {}
        completion_details = usage_data.get("completion_tokens_details") or {}
        return {
            "input": usage_data.get("prompt_tokens", 0),
            "output": usage_data.get("completion_tokens", 0),
            "cached": prompt_details.get("cached_tokens", 0),
            "reasoning": completion_details.get("reasoning_tokens", 0),
        }

    async def complete(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> dict:
        """Non-streaming call to OpenAI Responses API."""
        headers = self._build_headers(model_config)
        payload = self._build_payload(model_config, messages, stream=False, **kwargs)
        url = _normalize_url(model_config.url)

        try:
            async with httpx.AsyncClient(timeout=settings.provider_timeout) as client:
                response = await client.post(url, json=payload, headers=headers)
        except httpx.TimeoutException:
            raise UpstreamTimeoutError(f"OpenAI API timeout: {url}")
        except httpx.ConnectError as e:
            raise UpstreamError(f"OpenAI API connection failed: {e}")

        if response.status_code != 200:
            error_text = response.text
            logger.error(f"OpenAI API error {response.status_code}: {error_text}")
            raise UpstreamError(
                f"OpenAI API returned {response.status_code}: {error_text}",
                retryable=is_retryable_http_status(response.status_code),
            )

        data = response.json()
        logger.info(
            "provider_complete response model=%s status=%d response_json=%d",
            model_config.name, response.status_code, data,
        )
        choices = data.get("choices", [])
        message = choices[0].get("message", {}) if choices else {}

        return {
            "content": message.get("content", ""),
            "finish_reason": choices[0].get("finish_reason", "stop") if choices else "stop",
            "usage": self._parse_usage(data.get("usage")),
        }

    async def stream(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> AsyncGenerator[dict, None]:
        """Streaming call to OpenAI Responses API, yields standardized events."""
        headers = self._build_headers(model_config)
        payload = self._build_payload(model_config, messages, stream=True, **kwargs)
        data_events = 0
        content_chars = 0
        invalid_events = 0
        end_reason = "eof"
        logger.info(
            "provider_stream start model=%s adapter=%s messages=%d",
            model_config.name, type(self).__name__, len(messages),
        )

        url = _normalize_url(model_config.url)
        try:
            async with httpx.AsyncClient(timeout=settings.provider_timeout) as client:
                async with client.stream(
                    "POST", url, json=payload, headers=headers
                ) as response:
                    logger.info(
                        "provider_stream response model=%s status=%d content_type=%s",
                        model_config.name, response.status_code,
                        response.headers.get("content-type"),
                    )
                    if response.status_code != 200:
                        end_reason = "http_error"
                        body = await response.aread()
                        error_text = body.decode("utf-8", errors="replace")
                        logger.error(f"OpenAI streaming error {response.status_code}: {error_text}")
                        yield {
                            "type": "error",
                            "message": f"OpenAI API returned {response.status_code}: {error_text}",
                            "error_code": "upstream_error",
                            "retryable": is_retryable_http_status(response.status_code),
                        }
                        return

                    async for line in response.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        data_str = line[6:]
                        data_events += 1
                        if data_str.strip() == "[DONE]":
                            end_reason = "done_marker"
                            yield {"type": "done"}
                            return

                        try:
                            chunk = json.loads(data_str)
                        except json.JSONDecodeError:
                            invalid_events += 1
                            if invalid_events <= 3:
                                logger.warning(
                                    "provider_stream invalid JSON model=%s event=%d payload_chars=%d",
                                    model_config.name, data_events, len(data_str),
                                )
                            continue

                        # Extract content delta
                        choices = chunk.get("choices", [])
                        if data_events <= 3:
                            delta = (choices[0].get("delta") or {}) if choices else {}
                            logger.info(
                                "provider_stream event model=%s event=%d keys=%s "
                                "choices=%d delta_keys=%s finish_reason=%s",
                                model_config.name, data_events, sorted(chunk), len(choices),
                                sorted(delta),
                                choices[0].get("finish_reason") if choices else None,
                            )
                        if choices:
                            delta = choices[0].get("delta", {})
                            content = delta.get("content", "")
                            finish_reason = choices[0].get("finish_reason")
                            if content:
                                content_chars += len(content)
                                yield {"type": "delta", "content": content}
                            if finish_reason:
                                yield {
                                    "type": "delta",
                                    "content": "",
                                    "finish_reason": finish_reason,
                                }

                        # Extract usage if present in final chunk
                        if "usage" in chunk and chunk["usage"]:
                            yield {
                                "type": "usage",
                                **self._parse_usage(chunk["usage"]),
                            }

        except httpx.TimeoutException:
            end_reason = "timeout"
            yield {
                "type": "error",
                "message": "OpenAI API timeout during streaming",
                "error_code": "upstream_timeout",
            }
        except httpx.TransportError as e:
            end_reason = "connection_error"
            yield {
                "type": "error",
                "message": f"OpenAI API connection failed: {e}",
                "error_code": "upstream_error",
            }
        except Exception:
            end_reason = "exception"
            logger.exception("provider_stream failed model=%s", model_config.name)
            raise
        finally:
            log_summary = logger.info if content_chars else logger.warning
            log_summary(
                "provider_stream summary model=%s end=%s data_events=%d "
                "content_chars=%d invalid_events=%d",
                model_config.name, end_reason, data_events, content_chars, invalid_events,
            )
