"""JSON extraction, repair and validation utilities.

Implements a bounded repair strategy:
1. Try direct json.loads
2. Extract JSON block from surrounding text (regex)
3. Validate against JSON Schema via Pydantic dynamic model
Max 3 attempts total, then return None.
"""

import json
import logging
import re
from typing import Any, Optional

from pydantic import BaseModel, ValidationError, create_model

logger = logging.getLogger(__name__)


def extract_json(text: str) -> Optional[str]:
    """Extract a JSON block ({...} or [...]) from text.

    Tries to find the outermost balanced JSON structure.
    Returns the JSON string if found, None otherwise.
    """
    text = text.strip()

    # Try to find a JSON object {...}
    for start_char, end_char in [('{', '}'), ('[', ']')]:
        start_idx = text.find(start_char)
        if start_idx == -1:
            continue

        # Find matching end by counting brackets
        depth = 0
        in_string = False
        escape_next = False

        for i in range(start_idx, len(text)):
            ch = text[i]
            if escape_next:
                escape_next = False
                continue
            if ch == '\\':
                escape_next = True
                continue
            if ch == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if ch == start_char:
                depth += 1
            elif ch == end_char:
                depth -= 1
                if depth == 0:
                    return text[start_idx:i + 1]

    return None


def _validate_with_schema(data: Any, schema: dict) -> bool:
    """Validate data against a JSON Schema using Pydantic dynamic model."""
    try:
        # Build a simple Pydantic model from the schema
        if schema.get("type") == "object":
            fields = {}
            properties = schema.get("properties", {})
            required = set(schema.get("required", []))
            for prop_name, prop_schema in properties.items():
                prop_type = prop_schema.get("type", "str")
                py_type = _json_type_to_python(prop_type)
                if prop_name in required:
                    fields[prop_name] = (py_type, ...)
                else:
                    fields[prop_name] = (Optional[py_type], None)

            DynamicModel = create_model("DynamicSchema", **fields)
            DynamicModel.model_validate(data)
            return True
        elif schema.get("type") == "array":
            # Basic array validation — just check it's a list
            return isinstance(data, list)
        return True
    except (ValidationError, TypeError, ValueError) as e:
        logger.debug(f"Schema validation failed: {e}")
        return False


def _json_type_to_python(json_type: str) -> type:
    """Map JSON Schema type to Python type."""
    mapping = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }
    return mapping.get(json_type, str)


def repair_and_validate(
    raw: str, schema: Optional[dict] = None, max_attempts: int = 3
) -> Optional[dict]:
    """Try to parse and validate JSON, with bounded repair attempts.

    Strategy:
    1. Direct json.loads
    2. Extract JSON block from text, then loads
    3. If schema provided, validate with Pydantic

    Returns parsed dict/list on success, None on failure.
    """
    for attempt in range(max_attempts):
        # Attempt 1 (first try): direct parse
        if attempt == 0:
            try:
                data = json.loads(raw)
                if schema and not _validate_with_schema(data, schema):
                    logger.debug(f"Attempt {attempt + 1}: schema validation failed")
                    continue
                return data
            except (json.JSONDecodeError, TypeError):
                pass

        # Attempt 2+: extract from text
        extracted = extract_json(raw)
        if extracted:
            try:
                data = json.loads(extracted)
                if schema and not _validate_with_schema(data, schema):
                    logger.debug(f"Attempt {attempt + 1}: schema validation failed after extraction")
                    continue
                return data
            except (json.JSONDecodeError, TypeError):
                pass

        logger.debug(f"Attempt {attempt + 1}: JSON parse/repair failed")

    return None
