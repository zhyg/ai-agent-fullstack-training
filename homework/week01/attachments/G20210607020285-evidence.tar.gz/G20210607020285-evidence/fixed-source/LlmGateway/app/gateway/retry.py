"""Retry strategy with exponential backoff and full jitter."""

import asyncio
import logging
import random
from typing import Any, Callable, Awaitable, Type

from app.gateway.errors import UpstreamError, UpstreamTimeoutError

logger = logging.getLogger(__name__)

# Default retryable exceptions
DEFAULT_RETRYABLE: tuple[Type[Exception], ...] = (UpstreamError, UpstreamTimeoutError)


def is_retryable_http_status(status_code: int) -> bool:
    """Apply the same upstream HTTP retry policy to streaming and non-streaming calls."""
    return status_code in (408, 409, 429) or 500 <= status_code < 600


async def execute_with_retry(
    coro_factory: Callable[[], Awaitable[Any]],
    max_retries: int = 3,
    base_delay: float = 1.0,
    retryable_exceptions: tuple[Type[Exception], ...] = DEFAULT_RETRYABLE,
    context: str = "",
) -> Any:
    """Execute an async operation with exponential backoff retry.

    Args:
        coro_factory: A callable that returns a coroutine (not a coroutine itself).
                      Called fresh for each attempt.
        max_retries: Maximum number of retry attempts.
        base_delay: Base delay in seconds for backoff calculation.
        retryable_exceptions: Tuple of exception types that trigger retry.
        context: Optional context string for logging.

    Returns:
        The result of the successful coroutine execution.

    Raises:
        The last exception if all retries are exhausted.
    """
    last_exception: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            result = await coro_factory()
            if attempt > 0:
                logger.info(
                    f"Retry succeeded{f' [{context}]' if context else ''}: "
                    f"attempt {attempt + 1}"
                )
            return result
        except retryable_exceptions as e:
            if isinstance(e, UpstreamError) and not e.retryable:
                raise
            last_exception = e
            if attempt < max_retries:
                # Exponential backoff with full jitter
                delay = base_delay * (2 ** attempt) + random.uniform(0, base_delay)
                logger.warning(
                    f"Retry {attempt + 1}/{max_retries}{f' [{context}]' if context else ''}: "
                    f"{type(e).__name__}: {e}. "
                    f"Retrying in {delay:.2f}s"
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    f"All {max_retries} retries exhausted{f' [{context}]' if context else ''}: "
                    f"{type(e).__name__}: {e}"
                )

    # All retries exhausted
    assert last_exception is not None
    raise last_exception
