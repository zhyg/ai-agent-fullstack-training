"""LLM Gateway Service: orchestrates the model call chain.

Routing flow:
  1. Lookup ModelConfig from ModelRegistry
  2. Get matching adapter for the provider
  3. Call adapter (complete or stream)
  4. Translate result to OpenAI-compatible response
"""

import asyncio
import json
import logging
import time
import uuid
from contextlib import aclosing
from typing import AsyncGenerator

from sqlalchemy.orm import Session

from app.adapters.base import BaseAdapter, ModelConfig
from app.gateway.registry import ModelRegistry
from app.gateway.rate_limiter import RateLimiterManager
from app.gateway.retry import execute_with_retry
from app.gateway.errors import (
    ModelNotFoundError,
    AdapterUnavailableError,
    SchemaValidationError,
    UpstreamError,
    UpstreamTimeoutError,
)
from app.gateway.json_repair import repair_and_validate
from app.gateway.observability import (
    InvocationRecord,
    record_invocation,
    log_invocation,
)
from app.services.prompt_service import fetch_prompt
from app.schemas.chat_completion import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    build_completion_response,
)

logger = logging.getLogger(__name__)


class LLMGatewayService:
    """Core service that orchestrates the LLM call pipeline."""

    def __init__(
        self,
        registry: ModelRegistry,
        rate_limiter: RateLimiterManager,
    ):
        self.registry = registry
        self.rate_limiter = rate_limiter

    def _resolve_model(self, request: ChatCompletionRequest) -> tuple[ModelConfig, str]:
        """Resolve model name to ModelConfig and adapter.

        Returns (model_config, resolved_model_name).
        """
        model_config = self.registry.get_model_config(request.model)
        if not model_config:
            raise ModelNotFoundError(f"Model '{request.model}' not found")
        return model_config, model_config.name

    def _get_adapter(self, model_config: ModelConfig):
        """Get the adapter for a model's provider."""
        adapter = self.registry.get_adapter(model_config.provider)
        if not adapter:
            raise AdapterUnavailableError(
                f"No adapter registered for provider '{model_config.provider}'"
            )
        return adapter

    def _build_adapter_kwargs(self, request: ChatCompletionRequest) -> dict:
        """Build kwargs for adapter calls from the request."""
        kwargs = {}
        if request.temperature != 1.0:
            kwargs["temperature"] = request.temperature
        if request.max_tokens is not None:
            kwargs["max_tokens"] = request.max_tokens
        if request.response_format and request.response_format.type == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
            if request.response_format.schema_:
                kwargs["response_format"]["schema"] = request.response_format.schema_
        return kwargs

    async def _resolve_prompt(
        self, request: ChatCompletionRequest, messages: list[dict]
    ) -> list[dict]:
        """Resolve the prompt template and add structured output instructions.

        If prompt_name is present but prompt_version is missing,
        raises InvalidRequestError.
        """
        if request.prompt_name:
            if not request.prompt_version:
                from app.gateway.errors import InvalidRequestError
                raise InvalidRequestError(
                    "prompt_version is required when prompt_name is specified"
                )

            prompt = await fetch_prompt(request.prompt_name, request.prompt_version)
            system_message = {"role": "system", "content": prompt["content"]}

            # If user already provided system message, append template after it
            if messages and messages[0]["role"] == "system":
                messages = [messages[0], system_message] + messages[1:]
            else:
                messages = [system_message] + messages

        response_format = request.response_format
        if (
            response_format
            and response_format.type == "json_object"
            and response_format.schema_
        ):
            schema_instruction = (
                "Return only a JSON object that conforms to the following JSON Schema. "
                "Do not include Markdown fences or explanatory text.\n"
                + json.dumps(response_format.schema_, ensure_ascii=False)
            )
            if messages and messages[0]["role"] == "system":
                messages = [
                    {**messages[0], "content": messages[0]["content"] + "\n\n" + schema_instruction},
                    *messages[1:],
                ]
            else:
                messages = [{"role": "system", "content": schema_instruction}, *messages]

        return messages

    async def _call_with_retry(
        self,
        model_config: ModelConfig,
        adapter: BaseAdapter,
        messages: list[dict],
        kwargs: dict,
    ) -> tuple[dict, ModelConfig, int]:
        """Call the requested model with retries, without switching models.

        Returns (result_dict, model_config_used, retry_count).
        """
        retry_count = 0

        async def call():
            nonlocal retry_count
            try:
                return await adapter.complete(model_config, messages, **kwargs)
            except (UpstreamError, UpstreamTimeoutError):
                retry_count += 1
                raise

        result = await execute_with_retry(
            coro_factory=call,
            max_retries=3,
            base_delay=1.0,
            context=f"model={model_config.name}",
        )
        return result, model_config, retry_count

    def _compute_cost(self, model_config: ModelConfig, usage: dict) -> float:
        """Compute estimated cost from usage and model pricing."""
        pricing = model_config.pricing or {}
        input_tokens = usage.get("input", 0)
        output_tokens = usage.get("output", 0)
        cached_tokens = usage.get("cached", 0)
        cost = (
            input_tokens * pricing.get("input_per_million", 0) / 1e6
            + output_tokens * pricing.get("output_per_million", 0) / 1e6
            + cached_tokens * pricing.get("cached_input_per_million", 0) / 1e6
        )
        return round(cost, 8)

    def _record_and_log(
        self,
        request: ChatCompletionRequest,
        user: dict,
        model_config: ModelConfig,
        used_config: ModelConfig,
        usage: dict,
        latency: dict,
        retries: int,
        finish_reason: str,
        error_code: str | None = None,
    ):
        """Build InvocationRecord and dispatch to metrics + logging."""
        record = InvocationRecord(
            trace_id=str(uuid.uuid4()),
            call_id=str(uuid.uuid4()),
            user_email=user.get("user_email", ""),
            model_name=request.model,
            resolved_model=used_config.name,
            provider=used_config.provider,
            prompt_name=request.prompt_name,
            prompt_version=request.prompt_version,
            tokens=usage,
            latency=latency,
            retries=retries,
            finish_reason=finish_reason,
            error_code=error_code,
            estimated_cost=self._compute_cost(used_config, usage),
        )
        record_invocation(record)
        log_invocation(record)

    async def process_request(
        self,
        request: ChatCompletionRequest,
        user: dict,
        db: Session,
    ) -> ChatCompletionResponse:
        """Process a non-streaming chat completion request.

        Returns a ChatCompletionResponse.
        """
        start_time = time.monotonic()

        # Route phase
        route_start = time.monotonic()
        model_config, resolved_model = self._resolve_model(request)
        adapter = self._get_adapter(model_config)
        kwargs = self._build_adapter_kwargs(request)
        route_time = time.monotonic() - route_start

        # Queue phase (rate limiting)
        queue_start = time.monotonic()
        await self.rate_limiter.check(
            model_config.name,
            estimated_tokens=sum(len(m.content) for m in request.messages) // 4,
            rpm=model_config.rpm,
            tpm=model_config.tpm,
        )
        queue_time = time.monotonic() - queue_start

        messages = [{"role": m.role, "content": m.content} for m in request.messages]
        messages = await self._resolve_prompt(request, messages)

        # Generation phase (retry the requested model only)
        gen_start = time.monotonic()
        result, used_config, retries = await self._call_with_retry(
            model_config, adapter, messages, kwargs
        )
        gen_time = time.monotonic() - gen_start
        total_time = time.monotonic() - start_time

        content = result.get("content", "")
        usage = result.get("usage", {})
        finish_reason = result.get("finish_reason", "stop")
        used_model = used_config.name if used_config.name != model_config.name else request.model

        # Structured output: validate and repair JSON
        if request.response_format and request.response_format.type == "json_object":
            schema = request.response_format.schema_
            repaired = repair_and_validate(content, schema)
            if repaired is None:
                self._record_and_log(
                    request, user, model_config, used_config, usage,
                    {"queue": queue_time, "route": route_time, "ttft": 0,
                     "generation": gen_time, "total": total_time},
                    retries, finish_reason,
                    error_code="schema_validation_failed",
                )
                raise SchemaValidationError(
                    f"Structured output validation failed after 3 repair attempts",
                    raw_output=content,
                )
            content = json.dumps(repaired, ensure_ascii=False)

        # Record observability
        self._record_and_log(
            request, user, model_config, used_config, usage,
            {"queue": queue_time, "route": route_time, "ttft": 0,
             "generation": gen_time, "total": total_time},
            retries, finish_reason,
        )

        return build_completion_response(
            model=used_model,
            content=content,
            usage=usage,
            finish_reason=finish_reason,
        )

    async def process_stream_request(
        self,
        request: ChatCompletionRequest,
        user: dict,
        db: Session,
    ) -> AsyncGenerator[dict, None]:
        """Process a streaming chat completion request.

        Yields standardized event dicts for the SSE layer to format.

        Only the requested model is called.
        Retry upstream failures up to two times before emitting stream output.
        """
        start_time = time.monotonic()

        # Route phase
        route_start = time.monotonic()
        model_config, resolved_model = self._resolve_model(request)
        adapter = self._get_adapter(model_config)
        kwargs = self._build_adapter_kwargs(request)
        route_time = time.monotonic() - route_start

        # Queue phase (rate limiting)
        queue_start = time.monotonic()
        await self.rate_limiter.check(
            model_config.name,
            estimated_tokens=sum(len(m.content) for m in request.messages) // 4,
            rpm=model_config.rpm,
            tpm=model_config.tpm,
        )
        queue_time = time.monotonic() - queue_start

        messages = [{"role": m.role, "content": m.content} for m in request.messages]
        messages = await self._resolve_prompt(request, messages)

        is_json = request.response_format and request.response_format.type == "json_object"
        content_buffer = ""
        first_delta_sent = False
        ttft_time = 0.0
        stream_usage: dict = {}
        finish_reason = "stop"
        retries = 0
        active_config = model_config

        async def stream_with_retry() -> AsyncGenerator[dict, None]:
            nonlocal retries
            for attempt in range(3):
                pending_usage = []
                output_started = False
                try:
                    async with aclosing(
                        adapter.stream(model_config, messages, **kwargs)
                    ) as stream:
                        async for event in stream:
                            event_type = event.get("type")
                            if event_type == "error":
                                error = event
                                break
                            if not output_started and event_type == "usage":
                                pending_usage.append(event)
                                continue
                            output_started = True
                            for usage_event in pending_usage:
                                yield usage_event
                            pending_usage.clear()
                            yield event
                            if event_type == "done":
                                return
                        else:
                            for usage_event in pending_usage:
                                yield usage_event
                            return
                except (UpstreamError, UpstreamTimeoutError) as e:
                    error = {
                        "type": "error",
                        "message": str(e),
                        "error_code": e.error_code,
                    }
                    if isinstance(e, UpstreamError) and not e.retryable:
                        error["retryable"] = False

                if (
                    output_started
                    or error.get("error_code") not in ("upstream_error", "upstream_timeout")
                    or error.get("retryable") is False
                    or attempt == 2
                ):
                    for usage_event in pending_usage:
                        yield usage_event
                    yield error
                    return

                retries += 1
                delay = 1.0 * (2 ** attempt)
                logger.warning(
                    "Stream attempt %d/3 for '%s' failed: %s; retrying in %.1fs",
                    attempt + 1, model_config.name, error.get("message"), delay,
                )
                await asyncio.sleep(delay)

        # --- Active streaming phase ---
        async with aclosing(stream_with_retry()) as stream_gen:
            async for event in stream_gen:
                event_type = event.get("type")

                if event_type == "delta":
                    if not first_delta_sent:
                        ttft_time = time.monotonic() - start_time
                    first_delta_sent = True
                    delta_content = event.get("content", "")
                    if is_json:
                        content_buffer += delta_content
                    else:
                        yield event

                elif event_type == "usage":
                    stream_usage = {
                        "input": event.get("input", 0),
                        "output": event.get("output", 0),
                        "cached": event.get("cached", 0),
                        "reasoning": event.get("reasoning", 0),
                    }
                    yield event

                elif event_type == "error":
                    total_time = time.monotonic() - start_time
                    self._record_and_log(
                        request, user, model_config, active_config, stream_usage,
                        {"queue": queue_time, "route": route_time, "ttft": ttft_time,
                         "generation": total_time, "total": total_time},
                        retries, "error",
                        error_code=event.get("error_code"),
                    )
                    yield event
                    return
                else:
                    if event_type == "done":
                        gen_time = time.monotonic() - start_time
                        total_time = gen_time
                        if is_json and content_buffer:
                            schema = request.response_format.schema_
                            repaired = repair_and_validate(content_buffer, schema)
                            if repaired is None:
                                self._record_and_log(
                                    request, user, model_config, active_config,
                                    stream_usage,
                                    {"queue": queue_time, "route": route_time,
                                     "ttft": ttft_time, "generation": gen_time,
                                     "total": total_time},
                                    retries, finish_reason,
                                    error_code="schema_validation_failed",
                                )
                                yield {
                                    "type": "error",
                                    "message": "Structured output validation failed after 3 repair attempts",
                                    "error_code": "schema_validation_failed",
                                    "raw_output": content_buffer,
                                }
                                return
                            validated_json = json.dumps(repaired, ensure_ascii=False)
                            yield {"type": "delta", "content": validated_json}
                        self._record_and_log(
                            request, user, model_config, active_config,
                            stream_usage,
                            {"queue": queue_time, "route": route_time,
                             "ttft": ttft_time, "generation": gen_time,
                             "total": total_time},
                            retries, finish_reason,
                        )
                    yield event
