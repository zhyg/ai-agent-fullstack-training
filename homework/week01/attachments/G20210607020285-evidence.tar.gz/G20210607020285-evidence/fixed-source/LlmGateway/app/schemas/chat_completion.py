"""OpenAI Chat Completions compatible request/response schemas."""

import time
import uuid

from pydantic import BaseModel, Field
from typing import List, Optional, Literal


# --- Request ---


class ChatCompletionMessage(BaseModel):
    role: Literal["system", "user", "assistant"] = Field(
        ..., description="Message role"
    )
    content: str = Field(
        ..., min_length=1, max_length=100_000,
        description="Message content (max 100KB per message)"
    )


class ResponseFormat(BaseModel):
    type: Literal["text", "json_object"] = Field(
        default="text", description="Output format type"
    )
    schema_: Optional[dict] = Field(
        default=None, alias="schema", description="JSON Schema (when type=json_object)"
    )

    model_config = {"populate_by_name": True}


class ChatCompletionRequest(BaseModel):
    model: str = Field(..., description="Model display name")
    messages: List[ChatCompletionMessage] = Field(
        ..., min_length=1, max_length=100,
        description="Message list (1-100 messages)"
    )
    stream: bool = Field(default=False, description="Enable streaming")
    temperature: float = Field(default=1.0, ge=0, le=2, description="Sampling temperature")
    max_tokens: Optional[int] = Field(default=None, ge=1, description="Max output tokens")
    response_format: Optional[ResponseFormat] = Field(
        default=None, description="Structured output constraint"
    )
    prompt_name: Optional[str] = Field(
        default=None, description="Prompt template name"
    )
    prompt_version: Optional[str] = Field(
        default=None, description="Prompt template version"
    )


# --- Response ---


class ChatCompletionChoice(BaseModel):
    index: int = 0
    message: dict  # {"role": "assistant", "content": "..."}
    finish_reason: str = "stop"


class UsageInfo(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0
    reasoning_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: UsageInfo


def build_completion_response(
    model: str,
    content: str,
    usage: dict,
    finish_reason: str = "stop",
) -> ChatCompletionResponse:
    """Build a ChatCompletionResponse from adapter output."""
    return ChatCompletionResponse(
        id=f"chatcmpl-{uuid.uuid4().hex[:12]}",
        object="chat.completion",
        created=int(time.time()),
        model=model,
        choices=[
            ChatCompletionChoice(
                index=0,
                message={"role": "assistant", "content": content},
                finish_reason=finish_reason,
            )
        ],
        usage=UsageInfo(
            prompt_tokens=usage.get("input", 0),
            completion_tokens=usage.get("output", 0),
            total_tokens=usage.get("input", 0) + usage.get("output", 0),
            cached_tokens=usage.get("cached", 0),
            reasoning_tokens=usage.get("reasoning", 0),
        ),
    )
