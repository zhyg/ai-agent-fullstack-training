# Gateway core: registry, routing, rate limiting, retry, observability
