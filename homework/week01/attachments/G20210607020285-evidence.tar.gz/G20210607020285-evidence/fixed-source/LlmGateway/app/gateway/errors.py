"""Unified error codes and exception classes for the LLM Gateway.

Each exception maps to a specific HTTP status code and error code,
following the OpenAI-compatible error response contract.
"""


class GatewayError(Exception):
    """Base exception for all Gateway errors."""

    message: str = "Internal server error"
    error_type: str = "internal_error"
    error_code: str = "internal_error"
    http_status: int = 500

    def __init__(self, message: str | None = None, **kwargs):
        if message is not None:
            self.message = message
        self.extra = kwargs
        super().__init__(self.message)

    def to_dict(self) -> dict:
        result = {
            "error": {
                "message": self.message,
                "type": self.error_type,
                "code": self.error_code,
            }
        }
        result["error"].update(self.extra)
        return result


class AuthenticationError(GatewayError):
    message = "Invalid API key"
    error_type = "authentication_error"
    error_code = "invalid_api_key"
    http_status = 401


class PermissionDeniedError(GatewayError):
    message = "Permission denied"
    error_type = "authentication_error"
    error_code = "permission_denied"
    http_status = 403


class ModelNotFoundError(GatewayError):
    message = "Model not found"
    error_type = "invalid_request_error"
    error_code = "model_not_found"
    http_status = 404


class InvalidRequestError(GatewayError):
    message = "Invalid request"
    error_type = "invalid_request_error"
    error_code = "invalid_request"
    http_status = 422


class PromptNotFoundError(GatewayError):
    message = "Prompt template not found"
    error_type = "invalid_request_error"
    error_code = "prompt_not_found"
    http_status = 422


class SchemaValidationError(GatewayError):
    message = "Structured output validation failed"
    error_type = "validation_error"
    error_code = "schema_validation_failed"
    http_status = 422

    def __init__(self, message: str | None = None, raw_output: str | None = None):
        super().__init__(message)
        if raw_output is not None:
            self.extra["raw_output"] = raw_output


class RateLimitError(GatewayError):
    message = "Rate limit exceeded"
    error_type = "rate_limit_error"
    error_code = "rate_limit_exceeded"
    http_status = 429


class AdapterUnavailableError(GatewayError):
    message = "Adapter unavailable for requested provider"
    error_type = "service_error"
    error_code = "adapter_unavailable"
    http_status = 502


class UpstreamError(GatewayError):
    message = "Upstream provider error"
    error_type = "service_error"
    error_code = "upstream_error"
    http_status = 502

    def __init__(self, message: str | None = None, *, retryable: bool = True, **kwargs):
        super().__init__(message, **kwargs)
        self.retryable = retryable


class PromptServiceUnavailableError(GatewayError):
    message = "Prompt template service unavailable"
    error_type = "service_error"
    error_code = "prompt_service_unavailable"
    http_status = 503


class UpstreamTimeoutError(GatewayError):
    message = "Upstream provider timeout"
    error_type = "service_error"
    error_code = "upstream_timeout"
    http_status = 504
