"""Model registry: loads model configurations and provider adapters."""

import logging
from typing import Optional

from sqlalchemy.orm import Session

from app.adapters.base import ModelConfig, BaseAdapter
from app.models.model import Model
from app.core.encryption import decrypt_value

logger = logging.getLogger(__name__)


class ModelRegistry:
    """In-memory registry of adapters and model configurations.

    Loaded from the database at startup. Looks up models by name or display name.
    """

    def __init__(self):
        self.adapters: dict[str, BaseAdapter] = {}
        self.models: dict[str, ModelConfig] = {}

    def register_adapter(self, adapter: BaseAdapter):
        """Register an adapter instance for a provider."""
        self.adapters[adapter.provider] = adapter
        logger.info("Registered adapter: %s", adapter.provider)

    def get_adapter(self, provider: str) -> Optional[BaseAdapter]:
        """Get an adapter by provider name."""
        return self.adapters.get(provider)

    def get_model_config(self, model_name: str) -> Optional[ModelConfig]:
        """Get a model configuration by display name or name."""
        return self.models.get(model_name)

    def load_from_db(self, db: Session):
        """Load all model records from the database."""
        self.models.clear()

        models = db.query(Model).all()
        for model in models:
            try:
                api_key = decrypt_value(model.api_key_encrypted)
            except Exception:
                logger.error(f"Failed to decrypt API key for model '{model.name}', skipping")
                continue

            config = ModelConfig(
                name=model.name,
                provider=model.provider.lower(),
                url=model.url,
                api_key=api_key,
                rpm=model.rpm,
                tpm=model.tpm,
                context_tokens=model.context_tokens,
                pricing={
                    "input_per_million": float(model.input_per_million),
                    "output_per_million": float(model.output_per_million),
                    "cached_input_per_million": float(model.cached_input_per_million),
                },
            )

            # Index by display_name if available, otherwise by name
            lookup_key = model.display_name or model.name
            self.models[lookup_key] = config
            # Also index by name if different from display_name
            if model.display_name and model.name != model.display_name:
                self.models[model.name] = config

        logger.info(
            f"ModelRegistry loaded: {len(self.models)} model configs, "
            f"{len(self.adapters)} adapters"
        )
