from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
import logging

import httpx

from app.core.security import decode_token
from app.core.config import settings
from app.gateway.errors import AuthenticationError

logger = logging.getLogger(__name__)

security_scheme = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security_scheme),
) -> dict:
    """Extract and validate JWT token, return current user info dict.

    The token payload contains:
    - sub: user ID (UUID)
    - uid: username
    - role_ids: list of role IDs
    - permissions: list of permission keys
    """
    token = credentials.credentials
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="无效的令牌类型"
            )
        return {
            "id": payload.get("sub"),
            "uid": payload.get("uid"),
            "role_ids": payload.get("role_ids", []),
            "permissions": payload.get("permissions", [])
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="令牌已过期，请重新登录"
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="无效的令牌"
        )


def require_permission(permission: str):
    """Dependency factory: require a specific permission."""
    async def check_permission(
        current_user: dict = Depends(get_current_user)
    ) -> dict:
        user_permissions = current_user.get("permissions", [])
        if permission not in user_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"无权访问：需要 {permission} 权限"
            )
        return current_user
    return check_permission


async def get_api_key_user(
    credentials: HTTPAuthorizationCredentials = Depends(security_scheme),
) -> dict:
    """Validate API Key via UserManage service and return user info.

    Used for OpenAI Compatible API endpoints (/v1/chat/completions).
    Returns dict with: user_id, user_email.
    """
    api_key = credentials.credentials
    user_manage_url = settings.services.get("user_manage", "http://localhost:8001")

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            verify_resp = await client.post(
                f"{user_manage_url}/api/user/api-keys/verify",
                json={"key": api_key},
            )
            if verify_resp.status_code != 200:
                raise AuthenticationError("Failed to verify API key")

            verify_data = verify_resp.json()
            if not verify_data.get("valid"):
                raise AuthenticationError("Invalid API key")

            user_id = verify_data.get("user_id")
            user_email = verify_data.get("user_email") or "unknown"
            if not user_id:
                raise AuthenticationError("Invalid API key")

            return {
                "user_id": user_id,
                "user_email": user_email,
            }

    except AuthenticationError:
        raise
    except httpx.ConnectError as e:
        logger.error(f"UserManage service connection failed: {e}")
        raise AuthenticationError("Authentication service unavailable")
    except Exception as e:
        logger.error(f"API key verification failed: {e}")
        raise AuthenticationError("Failed to verify API key")
