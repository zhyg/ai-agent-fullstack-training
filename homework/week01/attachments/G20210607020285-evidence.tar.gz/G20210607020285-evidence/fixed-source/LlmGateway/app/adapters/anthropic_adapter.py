"""Anthropic Messages API adapter."""

import json
import logging
from typing import Any, AsyncGenerator

import httpx

from app.adapters.base import BaseAdapter, ModelConfig
from app.gateway.errors import UpstreamError, UpstreamTimeoutError
from app.gateway.retry import is_retryable_http_status
from app.core.config import settings

logger = logging.getLogger(__name__)


class AnthropicAdapter(BaseAdapter):
    """Adapter for Anthropic Messages API."""

    _provider = "anthropic"

    @property
    def provider(self) -> str:
        return self._provider

    def _build_headers(self, model_config: ModelConfig) -> dict:
        return {
            "Content-Type": "application/json",
            "x-api-key": model_config.api_key,
            "anthropic-version": "2023-06-01",
        }

    def _build_payload(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> dict:
        """Convert OpenAI-style messages to Anthropic format.

        Separates system message from user/assistant messages.
        """
        system_content = ""
        anthropic_messages = []

        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            if role == "system":
                system_content = content
            else:
                anthropic_messages.append({"role": role, "content": content})

        payload: dict[str, Any] = {
            "model": model_config.name,
            "messages": anthropic_messages,
            "max_tokens": kwargs.get("max_tokens", model_config.context_tokens or 4096),
            "stream": kwargs.get("stream", False),
        }
        if system_content:
            payload["system"] = system_content
        if "temperature" in kwargs:
            payload["temperature"] = kwargs["temperature"]
        return payload

    def _parse_usage(self, usage_data: dict | None) -> dict:
        if not usage_data:
            return {"input": 0, "output": 0, "cached": 0, "reasoning": 0}
        return {
            "input": usage_data.get("input_tokens", 0),
            "output": usage_data.get("output_tokens", 0),
            "cached": usage_data.get("cache_read_input_tokens", 0),
            "reasoning": 0,
        }

    def _extract_content_text(self, content_blocks: list[dict]) -> str:
        """Extract text from Anthropic content blocks."""
        parts = []
        for block in content_blocks:
            if block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "".join(parts)

    async def complete(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> dict:
        """Non-streaming call to Anthropic Messages API."""
        headers = self._build_headers(model_config)
        payload = self._build_payload(model_config, messages, stream=False, **kwargs)

        try:
            async with httpx.AsyncClient(timeout=settings.provider_timeout) as client:
                response = await client.post(model_config.url, json=payload, headers=headers)
        except httpx.TimeoutException:
            raise UpstreamTimeoutError(f"Anthropic API timeout: {model_config.url}")
        except httpx.ConnectError as e:
            raise UpstreamError(f"Anthropic API connection failed: {e}")

        if response.status_code != 200:
            error_text = response.text
            logger.error(f"Anthropic API error {response.status_code}: {error_text}")
            raise UpstreamError(
                f"Anthropic API returned {response.status_code}: {error_text}",
                retryable=is_retryable_http_status(response.status_code),
            )

        data = response.json()
        content_text = self._extract_content_text(data.get("content", []))
        usage = data.get("usage", {})

        return {
            "content": content_text,
            "finish_reason": self._map_stop_reason(data.get("stop_reason", "end_turn")),
            "usage": self._parse_usage(usage),
        }

    def _map_stop_reason(self, stop_reason: str) -> str:
        """Map Anthropic stop_reason to OpenAI finish_reason."""
        mapping = {
            "end_turn": "stop",
            "max_tokens": "length",
            "stop_sequence": "stop",
            "tool_use": "tool_calls",
        }
        return mapping.get(stop_reason, "stop")

    async def stream(
        self, model_config: ModelConfig, messages: list[dict], **kwargs: Any
    ) -> AsyncGenerator[dict, None]:
        """Streaming call to Anthropic Messages API, yields standardized events."""
        headers = self._build_headers(model_config)
        payload = self._build_payload(model_config, messages, stream=True, **kwargs)
        input_usage_data = None

        try:
            async with httpx.AsyncClient(timeout=settings.provider_timeout) as client:
                async with client.stream(
                    "POST", model_config.url, json=payload, headers=headers
                ) as response:
                    if response.status_code != 200:
                        body = await response.aread()
                        error_text = body.decode("utf-8", errors="replace")
                        logger.error(f"Anthropic streaming error {response.status_code}: {error_text}")
                        yield {
                            "type": "error",
                            "message": f"Anthropic API returned {response.status_code}: {error_text}",
                            "error_code": "upstream_error",
                            "retryable": is_retryable_http_status(response.status_code),
                        }
                        return

                    current_event_type = None

                    async for line in response.aiter_lines():
                        if line.startswith("event: "):
                            current_event_type = line[7:].strip()
                            continue

                        if not line.startswith("data: "):
                            continue

                        data_str = line[6:]
                        try:
                            event = json.loads(data_str)
                        except json.JSONDecodeError:
                            continue

                        event_type = event.get("type", current_event_type)

                        if event_type == "content_block_delta":
                            delta = event.get("delta", {})
                            if delta.get("type") == "text_delta":
                                text = delta.get("text", "")
                                if text:
                                    yield {"type": "delta", "content": text}

                        elif event_type == "message_delta":
                            # Contains stop_reason and usage at stream end
                            usage_data = event.get("usage", {})
                            stop_reason = event.get("delta", {}).get("stop_reason", "")
                            if usage_data:
                                yield {
                                    "type": "usage",
                                    **self._parse_usage(usage_data),
                                }
                            if stop_reason:
                                yield {
                                    "type": "delta",
                                    "content": "",
                                    "finish_reason": self._map_stop_reason(stop_reason),
                                }

                        elif event_type == "message_start":
                            # Contains initial usage (input tokens)
                            message = event.get("message", {})
                            usage_data = message.get("usage", {})
                            if usage_data:
                                input_usage_data = usage_data

                        elif event_type == "message_stop":
                            # Final usage: combine input from message_start + output from message_delta
                            if input_usage_data is not None:
                                input_usage = self._parse_usage(input_usage_data)
                                yield {
                                    "type": "usage",
                                    "input": input_usage["input"],
                                    "output": 0,
                                    "cached": input_usage["cached"],
                                    "reasoning": 0,
                                }
                            yield {"type": "done"}
                            return

        except httpx.TimeoutException:
            yield {
                "type": "error",
                "message": "Anthropic API timeout during streaming",
                "error_code": "upstream_timeout",
            }
        except httpx.TransportError as e:
            yield {
                "type": "error",
                "message": f"Anthropic API connection failed: {e}",
                "error_code": "upstream_error",
            }
        except Exception:
            logger.exception("Anthropic streaming unexpected error")
            raise
