"""Observability: Prometheus metrics + structured invocation logging.

Metrics (T034):
  - llm_request_total (Counter): total requests by model/provider/user/finish_reason
  - llm_tokens_total (Counter): tokens consumed by model/user/type
  - llm_latency_seconds (Histogram): latency breakdown by model/phase
  - llm_cost_estimate (Counter): estimated cost by model/user
  - llm_retry_total (Counter): retry attempts by model

Structured Logging (T035):
  - log_invocation(): JSON-formatted log entry for each invocation
"""

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from fastapi import FastAPI
from fastapi.responses import Response
from prometheus_client import (
    Counter,
    Histogram,
    generate_latest,
    CONTENT_TYPE_LATEST,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prometheus Metrics (T034)
# ---------------------------------------------------------------------------

llm_request_total = Counter(
    "llm_request_total",
    "Total LLM requests",
    ["model", "provider", "user_email", "finish_reason", "prompt_name", "prompt_version"],
)

llm_tokens_total = Counter(
    "llm_tokens_total",
    "Total tokens consumed",
    ["model", "user_email", "type", "prompt_name", "prompt_version"],  # type: input/output/cached/reasoning
)

llm_latency_seconds = Histogram(
    "llm_latency_seconds",
    "Latency in seconds by phase",
    ["model", "phase", "prompt_name", "prompt_version"],  # phase: queue/route/ttft/generation/total
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0, 120.0),
)

llm_cost_estimate = Counter(
    "llm_cost_estimate",
    "Estimated cost in 人民币元",
    ["model", "user_email", "prompt_name", "prompt_version"],
)

llm_retry_total = Counter(
    "llm_retry_total",
    "Total retry attempts",
    ["model", "prompt_name", "prompt_version"],
)

# ---------------------------------------------------------------------------
# InvocationRecord (shared between metrics + logging)
# ---------------------------------------------------------------------------

@dataclass
class InvocationRecord:
    """Runtime record of a single model invocation."""

    trace_id: str = ""
    call_id: str = ""
    user_email: str = ""
    model_name: str = ""
    resolved_model: str = ""
    provider: str = ""
    prompt_name: Optional[str] = None
    prompt_version: Optional[str] = None
    tokens: dict[str, int] = field(
        default_factory=lambda: {"input": 0, "output": 0, "cached": 0, "reasoning": 0}
    )
    latency: dict[str, float] = field(
        default_factory=lambda: {
            "queue": 0.0,
            "route": 0.0,
            "ttft": 0.0,
            "generation": 0.0,
            "total": 0.0,
        }
    )
    retries: int = 0
    finish_reason: str = "stop"
    error_code: Optional[str] = None
    estimated_cost: float = 0.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# record_invocation — update all Prometheus metrics
# ---------------------------------------------------------------------------

def record_invocation(record: InvocationRecord) -> None:
    """Update Prometheus metrics from an InvocationRecord."""
    prompt_labels = {
        "prompt_name": record.prompt_name or "",
        "prompt_version": record.prompt_version or "",
    }
    try:
        # Request counter
        llm_request_total.labels(
            model=record.model_name,
            provider=record.provider,
            user_email=record.user_email,
            finish_reason=record.finish_reason,
            **prompt_labels,
        ).inc()

        # Token counters
        for token_type in ("input", "output", "cached", "reasoning"):
            count = record.tokens.get(token_type, 0)
            if count > 0:
                llm_tokens_total.labels(
                    model=record.model_name,
                    user_email=record.user_email,
                    type=token_type,
                    **prompt_labels,
                ).inc(count)

        # Latency histograms
        for phase in ("queue", "route", "ttft", "generation", "total"):
            value = record.latency.get(phase, 0.0)
            if value > 0:
                llm_latency_seconds.labels(
                    model=record.model_name,
                    phase=phase,
                    **prompt_labels,
                ).observe(value)

        # Cost estimate
        if record.estimated_cost > 0:
            llm_cost_estimate.labels(
                model=record.model_name,
                user_email=record.user_email,
                **prompt_labels,
            ).inc(record.estimated_cost)

        # Retries
        if record.retries > 0:
            llm_retry_total.labels(
                model=record.model_name,
                **prompt_labels,
            ).inc(record.retries)

    except Exception:
        logger.exception("Failed to record invocation metrics")


# ---------------------------------------------------------------------------
# log_invocation — structured JSON log (T035)
# ---------------------------------------------------------------------------

def log_invocation(record: InvocationRecord) -> None:
    """Emit a structured JSON log line for the invocation."""
    log_data = {
        "trace_id": record.trace_id,
        "call_id": record.call_id,
        "user_email": record.user_email,
        "model": record.model_name,
        "resolved_model": record.resolved_model,
        "provider": record.provider,
        "tokens": record.tokens,
        "latency": {k: round(v, 4) for k, v in record.latency.items()},
        "retries": record.retries,
        "finish_reason": record.finish_reason,
        "error_code": record.error_code,
        "estimated_cost": str(round(record.estimated_cost, 8)),
        "timestamp": record.timestamp.isoformat(),
    }
    if record.prompt_name:
        log_data["prompt_name"] = record.prompt_name
        log_data["prompt_version"] = record.prompt_version

    if record.error_code:
        logger.warning("llm_invocation: %s", json.dumps(log_data, ensure_ascii=False))
    else:
        logger.info("llm_invocation: %s", json.dumps(log_data, ensure_ascii=False))


# ---------------------------------------------------------------------------
# Metrics endpoint (T034)
# ---------------------------------------------------------------------------

def setup_metrics_endpoint(app: FastAPI) -> None:
    """Register the /metrics endpoint for Prometheus scraping."""

    @app.get("/metrics", include_in_schema=False)
    async def metrics():
        return Response(
            content=generate_latest(),
            media_type=CONTENT_TYPE_LATEST,
        )

    logger.info("Prometheus /metrics endpoint registered")
