"""SSE formatting utilities for OpenAI-compatible streaming responses."""

import json
import time
import uuid
from typing import Any

from app.gateway.errors import GatewayError


def _generate_chunk_id() -> str:
    return f"chatcmpl-{uuid.uuid4().hex[:12]}"


def format_sse_event(data: dict) -> str:
    """Format a dict as an SSE data line."""
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


def format_sse_done() -> str:
    """Format the SSE stream end marker."""
    return "data: [DONE]\n\n"


def format_delta_chunk(id_: str, model: str, content: str) -> str:
    """Format a content delta chunk in OpenAI SSE format."""
    if not id_:
        id_ = _generate_chunk_id()
    chunk = {
        "id": id_,
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {"content": content} if content else {},
                "finish_reason": None,
            }
        ],
    }
    return format_sse_event(chunk)


def format_final_chunk(id_: str, model: str, usage: dict[str, Any]) -> str:
    """Format the final chunk with finish_reason and usage."""
    if not id_:
        id_ = _generate_chunk_id()
    chunk = {
        "id": id_,
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": usage.get("input", 0),
            "completion_tokens": usage.get("output", 0),
            "total_tokens": usage.get("input", 0) + usage.get("output", 0),
            "cached_tokens": usage.get("cached", 0),
            "reasoning_tokens": usage.get("reasoning", 0),
        },
    }
    return format_sse_event(chunk)


def format_error_event(error: GatewayError) -> str:
    """Format a GatewayError as an SSE error event."""
    return format_sse_event(error.to_dict())
