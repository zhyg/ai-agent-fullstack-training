from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import List, TypeVar, Generic, Optional, Literal
from decimal import Decimal
from datetime import datetime

CATEGORY_VALUES = ('chat', 'embedding', 'rerank', 'vision', 'speech')


class ModelCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="模型名称（必填）")
    display_name: Optional[str] = Field(None, max_length=200, description="模型显示名称（可选）")
    category: Literal['chat', 'embedding', 'rerank', 'vision', 'speech'] = Field(
        ..., description="模型分类（必填）"
    )
    provider: str = Field(..., min_length=1, max_length=100, description="模型供应商（必填）")
    url: str = Field(..., description="LLM API 端点 URL（必填）")
    api_key: str = Field(..., min_length=1, description="API Key（必填）")
    context_tokens: int = Field(..., ge=1, description="上下文窗口大小（必填）")
    rpm: int = Field(..., ge=0, description="RPM，0=不限（必填）")
    tpm: int = Field(..., ge=0, description="TPM，0=不限（必填）")
    input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输入价格/百万 tokens（必填）")
    output_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输出价格/百万 tokens（必填）")
    cached_input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="缓存命中价格/百万 tokens（必填）")


class ModelUpdate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="模型名称（必填）")
    display_name: Optional[str] = Field(None, max_length=200, description="模型显示名称（可选）")
    category: Literal['chat', 'embedding', 'rerank', 'vision', 'speech'] = Field(
        ..., description="模型分类（必填）"
    )
    provider: str = Field(..., min_length=1, max_length=100, description="模型供应商（必填）")
    url: str = Field(..., description="LLM API 端点 URL（必填）")
    api_key: Optional[str] = Field(
        default=None, min_length=1, description="新 API Key；不传、null 或留空则保留原密钥"
    )
    context_tokens: int = Field(..., ge=1, description="上下文窗口大小（必填）")
    rpm: int = Field(..., ge=0, description="RPM，0=不限（必填）")
    tpm: int = Field(..., ge=0, description="TPM，0=不限（必填）")
    input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输入价格/百万 tokens（必填）")
    output_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="输出价格/百万 tokens（必填）")
    cached_input_per_million: Decimal = Field(..., ge=0, decimal_places=4, description="缓存命中价格/百万 tokens（必填）")

    @field_validator("api_key", mode="before")
    @classmethod
    def preserve_blank_api_key(cls, value):
        if isinstance(value, str) and not value.strip():
            return None
        return value


class ModelResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    display_name: Optional[str]
    category: str
    provider: str
    url: str
    api_key_masked: str  # 掩码显示，如 sk-****1234
    context_tokens: int
    rpm: int
    tpm: int
    input_per_million: Decimal
    output_per_million: Decimal
    cached_input_per_million: Decimal
    created_at: datetime
    updated_at: datetime


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
