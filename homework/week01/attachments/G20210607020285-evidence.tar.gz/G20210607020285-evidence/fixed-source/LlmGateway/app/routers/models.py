import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import require_permission
from app.schemas.model import ModelCreate, ModelUpdate, ModelResponse, PaginatedResponse
from app.services import model_service

logger = logging.getLogger(__name__)

router = APIRouter(tags=["models"])


@router.get("/models", response_model=PaginatedResponse[ModelResponse])
def list_models(
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=1, le=1000, description="每页条数"),
    current_user: dict = Depends(require_permission("model_manage")),
    db: Session = Depends(get_db),
):
    """获取模型列表（仅管理员）。"""
    items, total = model_service.list_models(db, page, page_size)
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("/models", response_model=ModelResponse, status_code=status.HTTP_201_CREATED)
def create_model(
    data: ModelCreate,
    current_user: dict = Depends(require_permission("model_manage")),
    db: Session = Depends(get_db),
):
    """创建模型配置（仅管理员）。"""
    try:
        return model_service.create_model(db, data)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        )


@router.put("/models/{model_id}", response_model=ModelResponse)
def update_model(
    model_id: str,
    data: ModelUpdate,
    current_user: dict = Depends(require_permission("model_manage")),
    db: Session = Depends(get_db),
):
    """修改模型配置（仅管理员）。"""
    try:
        result = model_service.update_model(db, model_id, data)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        )
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="模型不存在",
        )
    return result


@router.delete("/models/{model_id}")
def delete_model(
    model_id: str,
    current_user: dict = Depends(require_permission("model_manage")),
    db: Session = Depends(get_db),
):
    """删除模型配置（仅管理员）。"""
    deleted = model_service.delete_model(db, model_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="模型不存在",
        )
    return {"message": "模型删除成功"}
