"""Remove capabilities from models.

Revision ID: c8d9e0f1a2b3
Revises: b7c8d9e0f1a2
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "c8d9e0f1a2b3"
down_revision: Union[str, None] = "b7c8d9e0f1a2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = "llm_gateway"


def upgrade() -> None:
    op.drop_column("models", "capabilities", schema=SCHEMA)


def downgrade() -> None:
    op.add_column(
        "models",
        sa.Column("capabilities", sa.JSON(), nullable=False, server_default="[]"),
        schema=SCHEMA,
    )
    op.alter_column("models", "capabilities", server_default=None, schema=SCHEMA)
