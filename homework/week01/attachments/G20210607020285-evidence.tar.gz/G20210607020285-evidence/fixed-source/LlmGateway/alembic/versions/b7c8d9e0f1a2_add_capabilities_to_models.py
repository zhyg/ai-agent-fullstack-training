"""add capabilities column to models table

Revision ID: b7c8d9e0f1a2
Revises: a1b2c3d4e5f6
Create Date: 2026-10-28 16:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'b7c8d9e0f1a2'
down_revision: Union[str, None] = 'a1b2c3d4e5f6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = 'llm_gateway'


def upgrade() -> None:
    op.add_column(
        'models',
        sa.Column(
            'capabilities',
            sa.JSON(),
            nullable=False,
            server_default='[]',
            comment='模型能力列表 (JSON array)',
        ),
        schema=SCHEMA,
    )
    # Remove server_default after setting initial value
    op.alter_column('models', 'capabilities', server_default=None, schema=SCHEMA)


def downgrade() -> None:
    op.drop_column('models', 'capabilities', schema=SCHEMA)
