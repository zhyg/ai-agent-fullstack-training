"""add category provider display_name and rename max_tokens to context_tokens

Revision ID: a1b2c3d4e5f6
Revises: 6cf8e0a5cb94
Create Date: 2026-10-28 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, None] = '6cf8e0a5cb94'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = 'llm_gateway'


def upgrade() -> None:
    # 1. 新增 category 列（默认值 'chat'，兼容旧数据）
    op.add_column(
        'models',
        sa.Column('category', sa.String(20), nullable=False, server_default='chat', comment='模型分类'),
        schema=SCHEMA,
    )

    # 2. 新增 provider 列（默认值 'OpenAI'，兼容旧数据）
    op.add_column(
        'models',
        sa.Column('provider', sa.String(100), nullable=False, server_default='OpenAI', comment='模型供应商'),
        schema=SCHEMA,
    )

    # 3. 新增 display_name 列（可选）
    op.add_column(
        'models',
        sa.Column('display_name', sa.String(200), nullable=True, comment='模型显示名称'),
        schema=SCHEMA,
    )

    # 4. 重命名 max_tokens → context_tokens
    op.alter_column(
        'models',
        'max_tokens',
        new_column_name='context_tokens',
        schema=SCHEMA,
    )

    # 5. 添加复合唯一约束 (provider, name)
    op.create_unique_constraint(
        'uq_models_provider_name',
        'models',
        ['provider', 'name'],
        schema=SCHEMA,
    )

    # 6. 移除 server_default（仅在迁移期间使用）
    op.alter_column('models', 'category', server_default=None, schema=SCHEMA)
    op.alter_column('models', 'provider', server_default=None, schema=SCHEMA)

    # 7. 为 category 添加索引以加速分类筛选
    op.create_index(
        'idx_models_category',
        'models',
        ['category'],
        schema=SCHEMA,
    )


def downgrade() -> None:
    op.drop_index('idx_models_category', table_name='models', schema=SCHEMA)
    op.drop_constraint('uq_models_provider_name', 'models', schema=SCHEMA, type_='unique')
    op.alter_column('models', 'context_tokens', new_column_name='max_tokens', schema=SCHEMA)
    op.drop_column('models', 'display_name', schema=SCHEMA)
    op.drop_column('models', 'provider', schema=SCHEMA)
    op.drop_column('models', 'category', schema=SCHEMA)
