# LlmGateway 分布式限流实现说明

## 概述

LlmGateway 采用**分布式限流**架构，以 Redis 作为共享状态存储，为每个模型独立维护 RPM 和 TPM 两个维度的流量控制。多实例部署时，所有网关节点共享同一套计数器，保证限流策略全局一致。

---

## 整体架构

```
请求进入
  │
  ▼
RateLimiterManager.check()
  │
  ├──① SlidingWindowCounter.allow_request()  ← RPM 检查
  │       │
  │       ├── 通过 → 继续
  │       └── 超限 → 抛出 RateLimitError (HTTP 429)
  │
  └──② TokenBucket.allow_tokens()             ← TPM 检查
          │
          ├── 通过 → 放行请求
          └── 超限 → 抛出 RateLimitError (HTTP 429)
```

**调用链路：** `LLMGatewayService.process_request()` → `rate_limiter.check(model_name, estimated_tokens, rpm, tpm)`

---

## Redis Key 命名规范

所有键统一前缀，保证多实例间键名一致：

```
llm_gw:ratelimit:{model_name}:rpm           # RPM 滑动窗口 sorted set
llm_gw:ratelimit:{model_name}:tpm:tokens    # TPM 当前令牌数
llm_gw:ratelimit:{model_name}:tpm:ts        # TPM 上次补充时间戳
```

---

## RPM — 滑动窗口计数器（SlidingWindowCounter）

### 为什么用滑动窗口而不是固定窗口

**固定窗口**（如按整分钟计数）存在边界突刺问题：

```
固定窗口：每分钟最多 20 个请求

第1分钟 59秒：发送 20 个请求  ← 全部通过
第2分钟 00秒：再发送 20 个请求 ← 全部通过

→ 2 秒内实际处理了 40 个请求，瞬时压力翻倍
```

**滑动窗口**始终统计"过去 60 秒内"的请求数，窗口随时间连续滑动，不存在边界突刺，任何时刻的统计都精确反映真实流量。

### 滑动窗口可视化

```
固定窗口的问题（边界突刺）
════════════════════════════════════════════════════════════════════════

  第 1 分钟窗口 [00:00 ───────────────── 01:00]
                                    ●●●●●●●●●●  ← 59秒附近发了 20 个请求，全部通过
                                                 
  第 2 分钟窗口 [01:00 ───────────────── 02:00]
  ●●●●●●●●●●  ← 01:00秒又发了 20 个请求，全部通过
  
  ╠═══════════════════════════════════════╣
  ║  00:59 ── 01:01 这 2 秒内实际处理了 40 个请求！  ║  ⚠ 瞬时压力翻倍
  ╚═══════════════════════════════════════╝


滑动窗口如何解决
════════════════════════════════════════════════════════════════════════

  窗口始终跟着当前时间滑动，任何时刻只统计过去 60 秒的请求数。

  t = 01:00 时的窗口：[00:00 ──────────────────────── 01:00]
                        ●  ●  ●    ● ● ●    ●●●●●●●●●●
                        ↑ 早期请求逐渐滑出窗口 ↑      ↑ 密集请求
                                                 count = 20
  
  t = 01:10 时的窗口：[00:10 ──────────────────────── 01:10]
                           ●  ●    ● ● ●    ●●●●●●●●●●  ●●
                           ↑ 旧请求已被淘汰 ↑              ↑ 新增
                                                 count = 18
  
  → 无论请求如何分布，窗口内的计数始终精确 ≤ RPM 限制


Sorted Set 中的数据结构示意（RPM=20）
════════════════════════════════════════════════════════════════════════

  当前时间 now = 10:00:45
  窗口范围   [09:59:45 ──────────────────── 10:00:45]

  Sorted Set 内容：
  ┌────────────────────────────────────────────────────────────────────┐
  │  score (时间戳)        member                     状态            │
  ├────────────────────────────────────────────────────────────────────┤
  │  09:59:30.100   "09:59:30.100:e4a12bc3"          ✗ 已过期删除    │
  │  09:59:40.200   "09:59:40.200:7f3c9d01"          ✗ 已过期删除    │
  │  ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ 窗口边界 09:59:45 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  │
  │  09:59:46.500   "09:59:46.500:a1b2c3d4"          ✓ 在窗口内     │
  │  09:59:55.800   "09:59:55.800:b5e6f7a8"          ✓ 在窗口内     │
  │  10:00:10.300   "10:00:10.300:c9d0e1f2"          ✓ 在窗口内     │
  │  10:00:30.600   "10:00:30.600:d3a4b5c6"          ✓ 在窗口内     │
  │  10:00:45.000   "10:00:45.000:f7a8b9c0"          ✓ 新写入       │
  └────────────────────────────────────────────────────────────────────┘

  ZCARD → 5 个存活请求
  判断：5 ≤ 20 (RPM) → ✓ 放行
```

### 为什么选择 Redis Sorted Set

Sorted Set 的 `score` 字段天然适合存储时间戳，并支持按分数范围批量删除过期数据，一条 Pipeline 即可完成"清理 + 写入 + 计数"三步操作：

| Redis 命令 | 作用 |
|-----------|------|
| `ZREMRANGEBYSCORE key 0 (now-60)` | 删除 60 秒前的过期请求 |
| `ZADD key now member` | 写入本次请求，score = 当前时间戳 |
| `ZCARD key` | 统计窗口内存活请求数 |
| `EXPIRE key 61` | 设置 key 过期时间（兜底清理） |

相比简单计数器（`INCR` + `EXPIRE`），Sorted Set 方案可以精确淘汰过期请求，避免计数漂移。

### 完整执行流程

```
请求到来（now = 10:00:45）
  │
  ▼
Step 1: ZREMRANGEBYSCORE
  删除 score ∈ [0, 10:00:45 - 60s] 即 09:59:45 之前的所有成员
  ┌──────────────────────────────────────────────────┐
  │  09:59:30  ✗ 已删除                              │
  │  09:59:40  ✗ 已删除                              │
  │  09:59:46  ✓ 保留                                │
  │  09:59:55  ✓ 保留                                │
  │  10:00:10  ✓ 保留                                │
  │  10:00:30  ✓ 保留                                │
  └──────────────────────────────────────────────────┘
  窗口：[09:59:45 ──────── 10:00:45]  共 60 秒

  │
  ▼
Step 2: ZADD
  写入新成员：member="10:00:45:a3f2b1c9", score=10:00:45
  ┌──────────────────────────────────────────────────┐
  │  09:59:46  ✓                                     │
  │  09:59:55  ✓                                     │
  │  10:00:10  ✓                                     │
  │  10:00:30  ✓                                     │
  │  10:00:45  ✓  ← 新写入                           │
  └──────────────────────────────────────────────────┘

  │
  ▼
Step 3: ZCARD → 返回 count=5

  │
  ▼
Step 4: 判断 count > rpm_limit ?
  ├── count <= limit → 通过，继续处理请求
  └── count > limit  → 超限：
        执行 ZREM 撤回刚写入的成员（还原状态）
        返回 False → 上层抛出 RateLimitError (HTTP 429)
```

### Pipeline 原子批量执行

以上四步通过 Redis **Pipeline** 打包发送，一次网络往返完成，减少延迟：

```python
pipe = self._redis.pipeline()
pipe.zremrangebyscore(self._key, 0, cutoff)   # Step 1: 清理过期
pipe.zadd(self._key, {member: now})            # Step 2: 写入新请求
pipe.zcard(self._key)                          # Step 3: 计数
pipe.expire(self._key, int(window) + 1)        # Step 4: 设置 key TTL
results = await pipe.execute()                 # 一次 RTT 执行全部命令
count = results[2]                             # ZCARD 的返回值
```

### member 防碰撞设计

```python
member = f"{now}:{uuid.uuid4().hex[:8]}"
# 示例：1698667245.123:a3f2b1c9
```

如果只用时间戳作为 member，同一毫秒内的两个并发请求会产生相同的 member，导致 Sorted Set 中后者**覆盖前者**（score 相同、member 相同视为同一个元素），计数少 1，限流失效。

拼接 8 位随机 hex 后，碰撞概率为 `1/16^8 ≈ 1/42亿`，工程上可忽略。

### 超限回滚机制

```python
if count > self.limit:
    # 撤回刚才 ZADD 写入的成员，保持窗口计数的准确性
    await self._redis.zrem(self._key, member)
    return False
```

Pipeline 执行后才知道是否超限，因此采用"先写入、再判断、超限则回滚"的策略，而非"先判断、再写入"（后者需要两次 RTT，且并发下存在竞态）。

### EXPIRE 兜底清理

```python
pipe.expire(self._key, int(self.window_seconds) + 1)  # TTL = 61 秒
```

每次请求都重置 key 的 TTL 为 61 秒。如果某模型长时间无请求，key 会在 61 秒后自动过期删除，避免 Redis 中遗留大量僵尸键。

### 时间复杂度

| 操作 | 复杂度 | 说明 |
|------|--------|------|
| ZREMRANGEBYSCORE | O(log N + M) | N = sorted set 大小，M = 被删除元素数 |
| ZADD | O(log N) | 单个元素插入 |
| ZCARD | O(1) | 直接返回内部计数 |
| ZREM（回滚） | O(log N) | 单个元素删除 |
| 整体 | O(log N) | 稳态下 M≈0（每次只删少量过期），主导项为 ZADD |

### 配置来源

数据库 `models.rpm` 字段，启动时加载到内存。`rpm=0` 表示不限流。

---

## TPM — 令牌桶算法（TokenBucket）

### 算法原理

使用 Redis **Lua 脚本**实现原子性的令牌补充与扣减。令牌以恒定速率（`tpm / 60` tokens/sec）持续补充，请求到来时扣减估算 token 数，桶空则拒绝。

### Lua 脚本核心逻辑

```lua
-- KEYS[1] = tokens key, KEYS[2] = last-refill timestamp key
-- ARGV[1] = capacity, ARGV[2] = refill_rate, ARGV[3] = requested, ARGV[4] = now

local last  = tonumber(redis.call('GET', ts_key) or now)
local avail = math.min(capacity,
    tonumber(redis.call('GET', tokens_key) or capacity) + (now - last) * rate)

if avail >= requested then
    redis.call('SET', tokens_key, avail - requested)
    redis.call('SET', ts_key, now)
    return {1, avail - requested}   -- 允许，返回剩余令牌
else
    return {0, avail}               -- 拒绝，返回当前可用令牌
end
```

| 设计点 | 说明 |
|--------|------|
| 原子性 | Lua 脚本在 Redis 中单线程执行，避免并发请求间的竞态条件 |
| 补充速率 | `refill_rate = tpm / 60`（tokens/sec），60 秒补满一桶 |
| 容量上限 | `math.min(capacity, ...)` 确保令牌不超过桶容量 |
| 初始化 | 首次访问时 `tokens_key` 不存在，默认按满桶（capacity）计算 |

### estimated_tokens 的计算

在 `LLMGatewayService` 中，每次请求按字符数估算 token 消耗：

```python
# llm_gateway_service.py
estimated_tokens = sum(len(m.content) for m in request.messages) // 4
```

### 配置来源

数据库 `models.tpm` 字段，启动时加载到内存。`tpm=0` 表示不限流。

---

## RateLimiterManager — 管理层

### 职责

- 为每个模型**懒创建**独立的 RPM 和 TPM 限流器实例（首次 check 时创建）
- 缓存限流器到内存 `dict`，避免重复初始化
- 封装 Redis 异常，实现容错降级

### 容错降级策略

```python
# rate_limiter.py — RateLimiterManager.check()
except redis.RedisError as exc:
    logger.warning("Redis rate-limiter unavailable, allowing request: %s", exc)
    # Redis 不可用时放行请求，避免限流组件成为单点故障
```

| 场景 | 行为 |
|------|------|
| Redis 正常 | 正常执行 RPM + TPM 检查 |
| Redis 不可用 | 记录 WARNING，放行所有请求（降级不阻断） |
| rpm=0 或 tpm=0 | 跳过对应维度的检查（`limit <= 0` 直接返回 True） |

---

## 限流触发时的响应

限流触发时抛出 `RateLimitError`，由全局异常处理器转换为 HTTP 429 响应：

```json
{
  "error": {
    "message": "Rate limit exceeded for model 'xxx'. RPM: 21/20",
    "type": "rate_limit_error",
    "code": "rate_limit_exceeded"
  }
}
```

---

## 上游有限重试机制

Gateway 对上游 LLM 供应商的瞬时故障提供**有限重试**，非流式和流式两条路径各有独立的重试策略。

### 整体决策流程

```
请求进入 Generation 阶段
  │
  ├── stream=false（非流式）
  │     │
  │     ▼
  │   _call_with_retry() → execute_with_retry()
  │     │
  │     ├── 成功 → 返回结果
  │     ├── 可重试错误 → 指数退避 + 随机抖动，最多重试 3 次
  │     ├── 不可重试错误（retryable=False）→ 立即抛出
  │     └── 3 次耗尽 → 抛出最后一次异常
  │
  └── stream=true（流式）
        │
        ▼
      stream_with_retry()
        │
        ├── 未开始输出前失败 → 指数退避，最多重试 3 次
        ├── 已开始输出后失败 → 不重试，直接 emit error 事件
        ├── 不可重试错误 → 不重试，直接 emit error 事件
        └── 3 次耗尽 → emit error 事件
```

### 可重试条件

| 条件 | 说明 |
|------|------|
| `UpstreamError` 且 `retryable=True` | 上游返回可重试的 HTTP 状态码 |
| `UpstreamTimeoutError` | 上游请求超时，始终可重试 |

#### 可重试的 HTTP 状态码

```python
# retry.py — is_retryable_http_status()
def is_retryable_http_status(status_code: int) -> bool:
    return status_code in (408, 409, 429) or 500 <= status_code < 600
```

| 状态码 | 含义 |
|--------|------|
| 408 | Request Timeout |
| 409 | Conflict（并发冲突） |
| 429 | Too Many Requests（上游限流） |
| 5xx | 上游服务器错误 |

### 不可重试条件

| 条件 | 行为 |
|------|------|
| `UpstreamError` 且 `retryable=False` | 立即抛出，不重试 |
| 非上游错误（认证失败、本地限流等） | 不进入重试逻辑 |
| 流式模式下已开始输出（`output_started=True`） | 无法重试，直接 emit error |

### 非流式重试（execute_with_retry）

调用链：`_call_with_retry()` → `execute_with_retry(coro_factory, max_retries=3, base_delay=1.0)`

**退避策略：指数退避 + 完全随机抖动（Full Jitter）**

```python
delay = base_delay * (2 ** attempt) + random.uniform(0, base_delay)
```

| 尝试次数 | 基础延迟 | 随机抖动 | 实际延迟范围 |
|---------|---------|---------|------------|
| 第 1 次重试（attempt=0） | 1.0s | 0 ~ 1.0s | 1.0 ~ 2.0s |
| 第 2 次重试（attempt=1） | 2.0s | 0 ~ 1.0s | 2.0 ~ 3.0s |
| 第 3 次重试（attempt=2） | 4.0s | 0 ~ 1.0s | 4.0 ~ 5.0s |

> 加入随机抖动（Jitter）避免多个并发请求在同一时刻重试，导致"惊群效应"。

**coro_factory 设计**：传入的是协程工厂（`Callable`），而非协程本身，确保每次重试都创建全新的请求协程。

### 流式重试（stream_with_retry）

流式重试自行实现，不复用 `execute_with_retry`，原因在于流式场景有一个关键约束：**一旦开始向客户端发送 delta 数据，就不能再重试**（客户端已经收到了部分响应）。

```python
# llm_gateway_service.py — stream_with_retry()
for attempt in range(3):           # 最多 3 次尝试
    output_started = False
    try:
        async with aclosing(adapter.stream(...)) as stream:
            async for event in stream:
                if event_type == "error":
                    break                  # 上游报错，跳出当前尝试
                output_started = True      # 标记已开始输出
                yield event
    except (UpstreamError, UpstreamTimeoutError) as e:
        error = {"type": "error", ...}

    # 判断是否应该停止重试
    if (
        output_started                                # 已开始输出，无法重试
        or error.get("retryable") is False             # 明确不可重试
        or error_code not in ("upstream_error", ...)   # 非上游错误
        or attempt == 2                                # 已是最后一次
    ):
        yield error
        return

    # 可重试 → 指数退避（无抖动）
    delay = 1.0 * (2 ** attempt)     # 1s, 2s, 4s
    await asyncio.sleep(delay)
```

**流式与非流式的关键差异：**

| 差异点 | 非流式 | 流式 |
|--------|-------|------|
| 退避策略 | 指数退避 + 随机抖动 | 指数退避（无抖动） |
| 输出后重试 | 不适用（整体返回） | **不允许**（`output_started` 检查） |
| 资源清理 | 协程自然结束 | `aclosing()` 确保 stream 资源释放 |
| usage 事件处理 | 直接包含在响应中 | 输出前暂存 `pending_usage`，输出后补发 |
| 错误传递 | 抛出异常 | yield error 事件（SSE 协议） |

### pending_usage 缓冲机制

流式场景中，部分供应商会在流开始时先发送 usage 事件。如果此时直接 yield，客户端会先收到 usage 再收到 delta，顺序不合预期。因此引入缓冲：

```
上游事件流：  [usage] → [delta] → [delta] → [usage] → [done]
                      ↑ output_started

缓冲策略：
  1. output_started=False 时，usage 事件暂存到 pending_usage
  2. 收到第一个 delta 时，先补发 pending_usage 中的所有 usage
  3. 后续 usage 直接 yield

客户端收到：  [usage] → [delta] → [delta] → [usage] → [done]
              ↑ 补发    ↑ 首个delta
```

如果重试发生（未开始输出就失败），`pending_usage` 会被丢弃，下次尝试重新缓冲。

---

## 客户端断开时的资源清理链路

当外部客户端主动断开连接（如关闭浏览器、取消请求、网络中断），Gateway 会通过多层 `aclosing()` 和 `async with` 上下文管理器将断开信号逐层传递到上游供应商，确保所有资源被及时释放。

### 完整传播链路

```
客户端断开连接
  │
  ▼
① StreamingResponse 检测到连接断开
  │  Starlette 的 ASGI send() 抛出异常（CancelledError）
  │  → event_generator() 的 async for 循环被中断
  │  → finally 块执行，打印 gateway_stream summary 日志
  │
  ▼
② process_stream_request() 被中断
  │  event_generator 不再消费 → async generator 被悬挂
  │  → 外层 aclosing(stream_with_retry()) 触发 aclose()
  │
  ▼
③ stream_with_retry() 被 aclose
  │  内层 aclosing(adapter.stream(...)) 触发 aclose()
  │
  ▼
④ adapter.stream() 异步生成器被 aclose
  │  生成器在下一个 yield 点收到 GeneratorExit
  │  → 退出 async for line in response.aiter_lines() 循环
  │  → 执行 adapter 的 finally 块（打印 provider_stream summary）
  │
  ▼
⑤ httpx 上下文管理器逆序退出
  │  async with client.stream(...) 退出 → 关闭 HTTP 响应流
  │  async with httpx.AsyncClient(...) 退出 → 关闭 TCP 连接
  │
  ▼
⑥ 上游供应商检测到连接关闭
     停止生成，释放服务端资源
```

### 关键机制详解

#### aclosing() 的作用

`aclosing()` 是 Python `contextlib` 提供的上下文管理器，确保异步生成器在退出时一定会调用 `aclose()`，即使发生异常或被取消也不例外：

```python
# llm_gateway_service.py — 两层 aclosing 嵌套

# 外层：包裹 stream_with_retry 生成器
async with aclosing(stream_with_retry()) as stream_gen:
    async for event in stream_gen:
        yield event

# 内层：包裹 adapter.stream 生成器
async with aclosing(adapter.stream(...)) as stream:
    async for event in stream:
        yield event
```

如果不用 `aclosing()`，当外层循环中断时，内层异步生成器可能不会立即释放（依赖 GC 回收），导致：
- 上游 HTTP 连接未关闭，持续占用网络资源
- 供应商继续生成无人消费的内容，浪费算力

#### httpx 的上下文管理器清理

两个 adapter 都使用 `async with` 嵌套管理 httpx 资源：

```python
# openai_adapter.py / anthropic_adapter.py
async with httpx.AsyncClient(timeout=...) as client:      # 管理 TCP 连接池
    async with client.stream("POST", url, ...) as response:  # 管理 HTTP 响应流
        async for line in response.aiter_lines():
            yield ...
```

当生成器被 `aclose()` 后，`async with` 块退出时会自动：
1. 关闭 `response` — 停止读取响应流，发送 TCP RST/FIN
2. 关闭 `client` — 释放连接池资源

#### event_generator 的 finally 清理

Router 层的 `event_generator()` 通过 `finally` 块确保无论何种原因结束都打印汇总日志：

```python
# v1_chat.py — event_generator()
try:
    async for event in gateway_service.process_stream_request(...):
        yield ...
finally:
    # 无论正常结束、出错、还是客户端断开，都会执行
    log_summary(
        "gateway_stream summary model=%s delta_events=%d content_chars=%d",
        body.model, delta_events, content_chars,
    )
```

### 各层清理职责总览

| 层级 | 组件 | 清理动作 |
|------|------|----------|
| ① | StreamingResponse | 检测客户端断开，中断 event_generator |
| ② | event_generator (Router) | finally 打印汇总日志 |
| ③ | aclosing (Service 外层) | 关闭 stream_with_retry 生成器 |
| ④ | aclosing (Service 内层) | 关闭 adapter.stream 生成器 |
| ⑤ | adapter.stream finally | 打印 provider_stream summary 日志 |
| ⑥ | httpx async with | 关闭 HTTP 响应流 + TCP 连接 |
| ⑦ | 上游供应商 | 检测到连接关闭，停止生成 |

---

## Prometheus 可观测性指标

Gateway 通过 `prometheus_client` 库在 `/metrics` 端点暴露 Prometheus 格式的指标数据，每次请求完成后通过 `InvocationRecord` 统一更新所有指标。

### 采集入口

```
GET http://localhost:8003/metrics
```

由 `setup_metrics_endpoint(app)` 注册，使用 `generate_latest()` 输出标准 Prometheus 文本格式。

### 指标定义

#### 请求计数器

| 指标名 | 类型 | 说明 |
|---------|------|------|
| `llm_request_total` | Counter | 请求总数 |

**标签：**

| 标签 | 说明 | 示例值 |
|------|------|--------|
| `model` | 请求的模型显示名 | `deepseek-flash-deepseek` |
| `provider` | 供应商 | `openai` / `anthropic` |
| `user_email` | 调用用户邮箱 | `user@example.com` |
| `finish_reason` | 结束原因 | `stop` / `error` / `length` |
| `prompt_name` | Prompt 模板名 | `sentiment-analysis` |
| `prompt_version` | Prompt 版本 | `v1.2` |

#### Token 消耗计数器

| 指标名 | 类型 | 说明 |
|---------|------|------|
| `llm_tokens_total` | Counter | 累计消耗 token 数 |

**标签：**

| 标签 | 说明 | 取值 |
|------|------|------|
| `model` | 模型名称 | — |
| `user_email` | 调用用户 | — |
| `type` | token 类型 | `input` / `output` / `cached` / `reasoning` |
| `prompt_name` | Prompt 模板名 | — |
| `prompt_version` | Prompt 版本 | — |

> 仅当某个 type 的 token 数 > 0 时才写入，避免无效标签组合。

#### 延迟分布直方图

| 指标名 | 类型 | 说明 |
|---------|------|------|
| `llm_latency_seconds` | Histogram | 各阶段延迟分布 |

**标签：**

| 标签 | 说明 |
|------|------|
| `model` | 模型名称 |
| `phase` | 请求阶段（见下表） |
| `prompt_name` | Prompt 模板名 |
| `prompt_version` | Prompt 版本 |

**阶段说明：**

| phase | 含义 | 起始点 |
|-------|------|--------|
| `queue` | 限流排队等待时间 | 进入限流检查 → 限流通过 |
| `route` | 模型路由解析时间 | 解析 model_config + adapter + kwargs |
| `ttft` | Time To First Token（流式） | 请求开始 → 第一个 delta 事件 |
| `generation` | 上游生成耗时 | 开始调用 adapter → adapter 返回 |
| `total` | 端到端总延迟 | 请求进入 → 响应完成 |

**桶边界（buckets）：**

```
0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0, 120.0
```

覆盖从 50ms 到 2min 的范围，适合 LLM 场景的延迟分布。

#### 费用估算计数器

| 指标名 | 类型 | 说明 |
|---------|------|------|
| `llm_cost_estimate` | Counter | 累计估算费用（人民币元） |

**标签：** `model`, `user_email`, `prompt_name`, `prompt_version`

**计算方式：**

```python
cost = (
    input_tokens  * pricing.input_per_million  / 1e6
  + output_tokens * pricing.output_per_million / 1e6
  + cached_tokens * pricing.cached_input_per_million / 1e6
)
```

价格从数据库 `models` 表的 `input_per_million`、`output_per_million`、`cached_input_per_million` 字段加载。

#### 重试计数器

| 指标名 | 类型 | 说明 |
|---------|------|------|
| `llm_retry_total` | Counter | 累计重试次数 |

**标签：** `model`, `prompt_name`, `prompt_version`

> 仅在 `retries > 0` 时写入，每次请求记录实际重试次数（而非固定 +1）。

### InvocationRecord —— 统一采集载体

所有指标通过 `InvocationRecord` 数据类统一传递：

```python
@dataclass
class InvocationRecord:
    trace_id: str            # 追踪 ID（每次调用唯一）
    call_id: str             # 调用 ID
    user_email: str          # 用户邮箱
    model_name: str          # 请求的模型显示名
    resolved_model: str      # 实际解析的模型名
    provider: str            # 供应商
    prompt_name: str | None  # Prompt 模板名
    prompt_version: str | None  # Prompt 版本
    tokens: dict             # {"input": N, "output": N, "cached": N, "reasoning": N}
    latency: dict            # {"queue": f, "route": f, "ttft": f, "generation": f, "total": f}
    retries: int             # 重试次数
    finish_reason: str       # 结束原因
    error_code: str | None   # 错误码（成功时为 None）
    estimated_cost: float    # 估算费用
    timestamp: datetime      # 时间戳
```

在 `LLMGatewayService` 的 `process_request()` 和 `process_stream_request()` 完成后，调用 `record_invocation(record)` 更新 Prometheus 指标，同时调用 `log_invocation(record)` 输出结构化 JSON 日志。

### 结构化日志（log_invocation）

除 Prometheus 指标外，每次调用还会输出一行 JSON 格式的结构化日志：

```json
{
  "trace_id": "a1b2c3...",
  "call_id": "d4e5f6...",
  "user_email": "user@example.com",
  "model": "deepseek-flash-deepseek",
  "resolved_model": "deepseek-chat",
  "provider": "openai",
  "tokens": {"input": 150, "output": 80, "cached": 0, "reasoning": 0},
  "latency": {"queue": 0.001, "route": 0.002, "ttft": 0.85, "generation": 1.23, "total": 1.24},
  "retries": 0,
  "finish_reason": "stop",
  "error_code": null,
  "estimated_cost": "0.00035000",
  "timestamp": "2026-10-30T12:00:00+00:00"
}
```

| 情况 | 日志级别 |
|------|----------|
| 成功（`error_code` 为 None） | `INFO` |
| 失败（有 `error_code`） | `WARNING` |

### 常用 PromQL 查询示例

```promql
# 过去 5 分钟各模型的 QPS
sum(rate(llm_request_total[5m])) by (model)

# 各模型的 P95 总延迟
histogram_quantile(0.95, sum(rate(llm_latency_seconds_bucket{phase="total"}[5m])) by (model, le))

# 过去 1 小时各用户的 token 消耗（按类型）
sum(increase(llm_tokens_total[1h])) by (user_email, type)

# 过去 24 小时各模型的估算费用
sum(increase(llm_cost_estimate[24h])) by (model)

# 各模型的重试率（重试次数 / 总请求数）
sum(rate(llm_retry_total[5m])) by (model) / sum(rate(llm_request_total[5m])) by (model)

# 错误率（finish_reason != "stop"）
sum(rate(llm_request_total{finish_reason!="stop"}[5m])) by (model) / sum(rate(llm_request_total[5m])) by (model)
```

---

## 测试脚本

| 脚本 | 用途 | 路径 |
|------|------|------|
| `test_rpm_rate_limit.sh` | 验证 RPM 限流（快速发送超过 RPM 限制个请求） | `tests/test_rpm_rate_limit.sh` |
| `test_tpm_rate_limit.sh` | 验证 TPM 限流（用大 payload 耗尽令牌桶） | `tests/test_tpm_rate_limit.sh` |

```bash
# RPM 测试：连续发送 30 个请求（RPM=20），预期第 21 个起返回 429
./tests/test_rpm_rate_limit.sh

# TPM 测试：并发发送大 payload 请求耗尽令牌桶
REQUEST_COUNT=20 MSG_SIZE=8000 ./tests/test_tpm_rate_limit.sh
```

> 两轮测试之间建议间隔 60 秒，等待滑动窗口过期和令牌桶补满。

---

## 相关文件

| 文件 | 说明 |
|------|------|
| `app/gateway/rate_limiter.py` | 限流核心实现（SlidingWindowCounter、TokenBucket、RateLimiterManager） |
| `app/gateway/retry.py` | 重试策略实现（execute_with_retry、指数退避、可重试状态码判断） |
| `app/gateway/observability.py` | Prometheus 指标定义、InvocationRecord、结构化日志、/metrics 端点 |
| `app/services/llm_gateway_service.py` | 调用 `rate_limiter.check()` 并传入 estimated_tokens；流式重试实现 |
| `app/gateway/errors.py` | 异常体系定义（UpstreamError.retryable、RateLimitError 等） |
| `app/main.py` | 初始化 Redis 客户端并注入 RateLimiterManager |
| `tests/test_rpm_rate_limit.sh` | RPM 限流测试脚本 |
| `tests/test_tpm_rate_limit.sh` | TPM 限流测试脚本 |
