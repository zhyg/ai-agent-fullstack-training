# Quick Start — 开发者门户平台

本地开发环境快速启动指南。涵盖所有后端服务、前端项目及数据库的初始化与启动流程。

---

## 一、前置依赖

| 依赖 | 版本要求 | 说明 |
|------|----------|------|
| Python | 3.11+ | 推荐使用 conda 虚拟环境 |
| Node.js | 18+ | 推荐 26.x |
| PostgreSQL | 14+ | 需创建数据库 `mydb` |
| Redis | 6+ | LlmGateway 和 KnowledgeManage 依赖 |

---

## 二、数据库初始化

### 2.1 创建数据库

```bash
# 连接 PostgreSQL，创建共用数据库
psql -U admin -h 127.0.0.1
CREATE DATABASE mydb;
```

> 所有服务共用同一个数据库 `mydb`，通过 **PostgreSQL Schema 隔离** 各自的表：
> - `user_manage` — UserManage 服务
> - `llm_gateway` — LlmGateway 服务
> - `knowledge_manage` — KnowledgeManage 服务

### 2.2 执行 Alembic 数据库迁移

每个服务都有独立的 Alembic 迁移脚本，需**分别执行**：

```bash
# UserManage — 创建用户、角色、API 密钥等表
cd UserManage
alembic upgrade head

# LlmGateway — 创建模型配置表
cd ../LlmGateway
alembic upgrade head

# KnowledgeManage — 创建提示词、聊天会话、消息等表
cd ../KnowledgeManage
alembic upgrade head
```

> 迁移脚本会自动创建对应的 Schema（`CREATE SCHEMA IF NOT EXISTS`），无需手动建。

### 2.3 迁移文件清单

| 服务 | 迁移文件 | 说明 |
|------|----------|------|
| **UserManage** | `001_initial.py` | 初始用户、角色表 |
| | `002_add_api_keys.py` | API 密钥表 |
| **LlmGateway** | `6cf8e0a5cb94_add_models_table.py` | 模型配置表 |
| | `a1b2c3d4e5f6_add_category_provider_display_context.py` | 分类、供应商、显示上下文字段 |
| | `b7c8d9e0f1a2_add_capabilities_to_models.py` | 模型能力字段 |
| | `c8d9e0f1a2b3_remove_capabilities_from_models.py` | 移除能力字段 |
| **KnowledgeManage** | `309dcc94fbaf_add_prompts_table.py` | 提示词表 |
| | `5426a5756ea3_add_chats_and_messages_tables.py` | 聊天和消息表 |
| | `a3f5e6d7c8b9_add_status_to_chats.py` | 聊天状态字段 |
| | `b4c6d8e0f2a1_add_chat_model_name.py` | 聊天模型名称字段 |
| | `c7e9f1a2b3d4_add_chat_generation_lease.py` | 聊天生成租约字段（多实例支持） |

### 2.4 自动初始化行为

- **Schema 自动创建**：每个服务启动时 `init_schema()` 会自动创建对应的 PostgreSQL Schema，无需手动操作
- **默认数据（UserManage）**：UserManage 服务启动时会自动创建：
  - 默认角色：`admin`（系统管理员）、`user`（普通用户）
  - 默认管理员账号：`uid=admin, password=admin123`

---

## 三、后端服务启动

### 3.1 安装 Python 依赖

所有后端服务共用同一个 Python 环境，安装一次即可：

```bash
# 在项目根目录执行
pip install -r UserManage/requirements.txt
pip install -r LlmGateway/requirements.txt
pip install -r KnowledgeManage/requirements.txt
```

### 3.2 配置环境

通过环境变量 `APP_ENV` 切换配置文件，默认为 `dev`：

| 环境 | 配置文件 | 说明 |
|------|----------|------|
| dev（默认） | `config.dev.yaml` | 本地开发 |
| test | `config.test.yaml` | 测试环境 |
| prod | `config.prod.yaml` | 生产环境 |

### 3.3 服务一览

| 服务 | 端口 | Schema | 说明 |
|------|------|--------|------|
| **UserManage** | 8001 | `user_manage` | 用户、角色、权限、API 密钥管理 |
| **KnowledgeManage** | 8002 | `knowledge_manage` | 提示词管理、聊天会话管理 |
| **LlmGateway** | 8003 | `llm_gateway` | LLM 统一调用网关 |

### 3.4 启动命令

每个服务在各自目录下独立启动：

```bash
# 终端 1 — UserManage（端口 8001）
cd UserManage
uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload

# 终端 2 — KnowledgeManage（端口 8002）
cd KnowledgeManage
uvicorn app.main:app --host 0.0.0.0 --port 8002 --reload

# 终端 3 — LlmGateway（端口 8003）
cd LlmGateway
uvicorn app.main:app --host 0.0.0.0 --port 8003 --reload
```

### 3.5 健康检查

启动后验证各服务是否正常运行：

```bash
curl http://localhost:8001/api/user/health
# {"status": "ok", "service": "UserManage"}

curl http://localhost:8002/api/knowledge/health
# {"status": "ok", "service": "KnowledgeManage"}

curl http://localhost:8003/api/llm/health
# {"status": "ok", "service": "LlmGateway"}
```

---

## 四、前端启动

### 4.1 安装依赖

```bash
cd frontend
npm install
```

### 4.2 启动开发服务器

```bash
npm run dev
```

前端开发服务器运行在 `http://localhost:5173`，通过 Vite 代理转发 API 请求到各后端服务：

| 前端路由 | 代理目标 |
|----------|----------|
| `/api/user/*` | `http://localhost:8001` (UserManage) |
| `/api/knowledge/*` | `http://localhost:8002` (KnowledgeManage) |
| `/api/llm/*` | `http://localhost:8003` (LlmGateway) |

### 4.3 构建与预览

```bash
# 构建生产包
npm run build

# 预览构建产物
npm run preview
```

---

## 五、关键配置说明

### 5.1 数据库连接（config.dev.yaml）

所有服务的数据库连接配置一致：

```yaml
database:
  url: "postgresql://admin:123456@127.0.0.1:5432/mydb"
```

### 5.2 Redis 配置

LlmGateway 和 KnowledgeManage 需要 Redis：

```yaml
redis:
  host: "127.0.0.1"
  port: 6379
  db: 0
```

- **LlmGateway**：Redis 用于分布式限流（RPM/TPM）
- **KnowledgeManage**：Redis 用于聊天流式生成的多实例事件同步（Redis Stream + Pub/Sub）

### 5.3 JWT 配置

所有后端服务共享同一套 JWT 密钥，用于 Token 签发与验证：

```yaml
jwt:
  secret_key: "dev-secret-key-not-for-production"
  algorithm: "HS256"
  access_token_expire_minutes: 30
  refresh_token_expire_days: 7
```

### 5.4 启动顺序

推荐按以下顺序启动服务：

```
1. PostgreSQL + Redis          ← 基础设施
2. alembic upgrade head       ← 数据库迁移（首次启动时）
3. UserManage (8001)           ← 用户认证（其他服务依赖）
4. KnowledgeManage (8002)      ← 知识管理
5. LlmGateway (8003)           ← LLM 网关
6. frontend (5173)             ← 前端
```

---

## 六、Docker 部署（可选）

每个服务都提供了 Dockerfile，支持容器化部署：

```bash
# 构建镜像
cd UserManage
docker build -t user-manage .

cd ../KnowledgeManage
docker build -t knowledge-manage .

cd ../LlmGateway
docker build -t llm-gateway .

# 运行容器
docker run -d -p 8001:8001 --name user-manage user-manage
docker run -d -p 8002:8002 --name knowledge-manage knowledge-manage
docker run -d -p 8003:8003 --name llm-gateway llm-gateway
```

---

## 七、常见问题

**Q: 首次启动需要手动创建 Schema 吗？**
A: 不需要。`init_schema()` 会在服务启动时自动执行 `CREATE SCHEMA IF NOT EXISTS`。

**Q: 数据库迁移可以重复执行吗？**
A: 可以。Alembic 通过 `alembic_version` 表跟踪已应用的迁移，重复执行 `alembic upgrade head` 只会应用新的迁移。

**Q: 默认管理员账号是什么？**
A: UserManage 服务首次启动会自动创建：`uid=admin, password=admin123`。

**Q: Redis 不启动会怎样？**
A: LlmGateway 的限流会降级放行（不阻断请求）；KnowledgeManage 的聊天多实例同步功能不可用。
