import json
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from app.services import chat_service
from app.models.prompt import Prompt


class ChatStreamTests(unittest.IsolatedAsyncioTestCase):
    async def consume(self, events, prompt=None, prompt_id=None):
        response = MagicMock()
        response.status_code = 200
        response.headers = {"content-type": "text/event-stream"}

        async def lines():
            for event in events:
                yield "data: " + (json.dumps(event) if isinstance(event, dict) else event)

        response.aiter_lines = lines
        stream_context = AsyncMock()
        stream_context.__aenter__.return_value = response
        client = MagicMock()
        client.stream.return_value = stream_context
        client_context = AsyncMock()
        client_context.__aenter__.return_value = client
        chat = SimpleNamespace(
            id="test-chat",
            model_name="test-display-name",
            status="idle",
            prompt_id=prompt_id,
        )
        db = MagicMock()
        db.query.return_value.filter.return_value.first.return_value = prompt
        db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        # Ensure Prompt filter chain returns the prompt object
        db.query.return_value.filter.return_value.first.return_value = prompt

        with (
            patch.object(chat_service, "get_chat", return_value=chat),
            patch.object(chat_service, "_get_redis_pool", return_value=None),
            patch.object(chat_service, "save_message") as save,
            patch.object(chat_service, "SessionLocal") as session_mock,
            patch.object(chat_service.httpx, "AsyncClient", return_value=client_context),
            self.assertLogs(chat_service.logger, level="INFO") as logs,
        ):
            session_mock.return_value.__enter__ = MagicMock(return_value=db)
            session_mock.return_value.__exit__ = MagicMock(return_value=False)
            # Configure filter chain on session_mock.return_value (used by send_message_stream's db)
            session_mock.return_value.query.return_value.filter.return_value.first.return_value = prompt
            session_mock.return_value.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
            result = [
                event async for event in chat_service.send_message_stream(
                    "test-chat", "private-question", "test-user"
                )
            ]
            if prompt_id and prompt is None:
                client.stream.assert_not_called()
                save.assert_not_called()
            else:
                payload = client.stream.call_args.kwargs["json"]
                self.assertEqual(payload["model"], "test-display-name")
                if prompt:
                    self.assertEqual(payload["prompt_name"], prompt.name)
                    self.assertEqual(payload["prompt_version"], prompt.version)
                else:
                    self.assertNotIn("prompt_name", payload)
                    self.assertNotIn("prompt_version", payload)
        return result, save.call_args_list, "\n".join(logs.output)

    async def test_selected_prompt_name_and_version_are_forwarded(self):
        await self.consume(
            ["[DONE]"],
            prompt=SimpleNamespace(name="travel-planner", version="1.0"),
            prompt_id="test-prompt",
        )

    async def test_missing_selected_prompt_returns_error_without_gateway_call(self):
        result, _, logs = await self.consume([], prompt_id="deleted-prompt")
        self.assertEqual(json.loads(result[0][6:])["type"], "error")
        self.assertEqual(result[-1], "data: [DONE]\n\n")
        self.assertIn("Chat prompt not found", logs)

    async def test_openai_content_is_forwarded_saved_and_counted(self):
        result, saves, logs = await self.consume([
            {"choices": [{"delta": {"role": "assistant"}}]},
            {"choices": [{"delta": {"content": "private-answer"}}]},
            "[DONE]",
        ])
        self.assertIn(
            'data: {"type": "delta", "content": "private-answer"}\n\n', result
        )
        self.assertEqual(saves[-1].args[2:], ("assistant", "private-answer"))
        self.assertIn("delta_events=1 content_chars=14", logs)
        self.assertNotIn("private-question", logs)
        self.assertNotIn("private-answer", logs)
        self.assertEqual(result[-1], "data: [DONE]\n\n")

    async def test_empty_stream_logs_warning_and_no_assistant_is_saved(self):
        result, saves, logs = await self.consume(["[DONE]"])
        self.assertEqual(len(saves), 1)
        self.assertEqual(result, ['data: {"type": "done"}\n\n', "data: [DONE]\n\n"])
        self.assertIn("WARNING:", logs)
        self.assertIn("end=done_marker data_events=1 delta_events=0 content_chars=0", logs)

    async def test_legacy_and_invalid_events_are_logged_without_content(self):
        result, _, logs = await self.consume([
            "not-json",
            {"unexpected": True},
            {"type": "delta", "content": "private-answer"},
            {"type": "done"},
        ])
        self.assertIn(
            'data: {"type": "delta", "content": "private-answer"}\n\n', result
        )
        self.assertIn("invalid_events=1 unhandled_events=1", logs)
        self.assertIn("end=done_event", logs)
        self.assertNotIn("private-answer", logs)

    async def test_openai_error_code_is_logged_without_error_body(self):
        result, _, logs = await self.consume([
            {"error": {
                "type": "invalid_request_error",
                "code": "model_not_found",
                "message": "private-error-detail",
            }},
            "[DONE]",
        ])
        self.assertIn("error_code=model_not_found", logs)
        self.assertIn("end=upstream_error", logs)
        error = json.loads(result[0][6:])
        self.assertEqual(error["type"], "error")
        self.assertEqual(error["error_code"], "model_not_found")
        self.assertEqual(error["message"], "private-error-detail")
        self.assertNotIn("private-error-detail", logs)
