import asyncio
import json
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi.responses import StreamingResponse

from app.services import chat_service


class ChatBackgroundTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.release = asyncio.Event()
        self.waiting = asyncio.Event()
        self.chat = SimpleNamespace(
            id="background-chat", model_name="test-model", status="idle", prompt_id=None,
        )
        self.db = MagicMock()
        self.db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
        self.response = MagicMock(status_code=200)
        self.response.headers = {"content-type": "text/event-stream"}
        self.response.aiter_lines = self.lines
        self.stream_context = AsyncMock()
        self.stream_context.__aenter__.return_value = self.response
        client = MagicMock()
        client.stream.return_value = self.stream_context
        client_context = AsyncMock()
        client_context.__aenter__.return_value = client
        self.patches = [
            patch.object(chat_service, "get_chat", return_value=self.chat),
            patch.object(chat_service, "_get_redis_pool", return_value=None),
            patch.object(chat_service, "SessionLocal"),
            patch.object(chat_service, "save_message"),
            patch.object(chat_service.httpx, "AsyncClient", return_value=client_context),
        ]
        mocks = [self.enterContext(patcher) for patcher in self.patches]
        self.sessions, self.save = mocks[2:4]
        self.sessions.return_value.__enter__.return_value = self.db

    async def lines(self):
        yield 'data: {"type": "delta", "content": "first"}'
        self.waiting.set()
        await self.release.wait()
        yield 'data: {"type": "delta", "content": "-last"}'
        yield "data: [DONE]"

    async def asyncTearDown(self):
        self.release.set()
        await asyncio.wait_for(chat_service.finish_generations(), timeout=2)

    async def start(self):
        stream = chat_service.send_message_stream(
            self.chat.id, "question", "test-user"
        )
        event = await asyncio.wait_for(anext(stream), timeout=2)
        self.assertEqual(json.loads(event[6:])["content"], "first")
        await asyncio.wait_for(self.waiting.wait(), timeout=2)
        return stream

    async def test_browser_close_continues_and_persists_full_response(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        self.assertFalse(job.task.done())
        self.assertEqual(self.chat.status, "generating")
        self.sessions.return_value.__exit__.assert_not_called()
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        self.assertEqual(self.chat.status, "completed")
        self.sessions.return_value.__exit__.assert_called_once()

    async def test_cancel_after_browser_close_interrupts_idle_upstream(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        result = await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        self.assertEqual(result.status, "cancelled")
        await asyncio.wait_for(job.task, timeout=2)
        self.assertFalse(self.release.is_set())
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first\n[已取消]"))
        self.stream_context.__aexit__.assert_awaited_once()
        self.assertEqual(self.chat.status, "cancelled")

    async def test_http_disconnect_does_not_cancel_generation(self):
        disconnected = asyncio.Event()
        stream = chat_service.send_message_stream(self.chat.id, "question", "test-user")

        async def receive():
            await disconnected.wait()
            return {"type": "http.disconnect"}

        async def send(message):
            if message["type"] == "http.response.body" and message.get("body"):
                disconnected.set()

        await asyncio.wait_for(
            StreamingResponse(stream, media_type="text/event-stream")(
                {"type": "http", "asgi": {"spec_version": "2.0"}}, receive, send,
            ),
            timeout=2,
        )
        job = chat_service._generations[self.chat.id]
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.task.done())
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        self.assertEqual(self.chat.status, "completed")

    async def test_cancelling_sse_while_waiting_does_not_cancel_generation(self):
        stream = await self.start()
        observer = asyncio.create_task(anext(stream))
        await asyncio.sleep(0)
        observer.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await observer
        job = chat_service._generations[self.chat.id]
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.cancel.is_set())
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(self.chat.status, "completed")

    async def test_connected_cancel_emits_cancelled_not_error(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        events = [event async for event in stream]
        await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(json.loads(events[0][6:])["type"], "cancelled")
        self.assertEqual(events[-1], "data: [DONE]\n\n")

    async def test_cancel_from_redis_interrupts_idle_upstream(self):
        messages = asyncio.Queue()
        pubsub = MagicMock()
        pubsub.subscribe = AsyncMock()
        pubsub.unsubscribe = AsyncMock()
        pubsub.aclose = AsyncMock()

        async def listen():
            yield await messages.get()

        pubsub.listen = listen
        pool = MagicMock()
        pool.pubsub.return_value = pubsub
        pool.get = AsyncMock(return_value=None)
        pool.xadd = AsyncMock(return_value="1-0")
        pool.expire = AsyncMock(return_value=True)
        with patch.object(chat_service, "_get_redis_pool", return_value=pool):
            stream = await self.start()
            job = chat_service._generations[self.chat.id]
            self.chat.status = "cancelled"
            messages.put_nowait({
                "type": "message",
                "data": json.dumps({
                    "action": "cancel",
                    "generation_id": job.generation_id,
                }),
            })
            events = [event async for event in stream]
            await asyncio.wait_for(job.task, timeout=2)
        self.assertEqual(json.loads(events[0][6:])["type"], "cancelled")
        self.assertFalse(self.release.is_set())
        pubsub.unsubscribe.assert_awaited_once()
        pubsub.aclose.assert_awaited_once()

    async def test_shared_generation_replays_stream_and_stops_at_done_marker(self):
        events = [
            "data: {\"type\": \"delta\", \"content\": \"shared\"}\n\n",
            "data: [DONE]\n\n",
        ]
        pool = MagicMock()
        pool.xread = AsyncMock(return_value=[(
            "shared-stream",
            [
                ("1-0", {"event": events[0], "done": "0"}),
                ("2-0", {"event": events[1], "done": "0"}),
                ("3-0", {"event": "", "done": "1"}),
            ],
        )])
        with patch.object(chat_service, "_get_redis_pool", return_value=pool):
            replayed = [
                event async for event in chat_service._stream_shared_generation(
                    self.chat.id, "shared-generation"
                )
            ]

        self.assertEqual(replayed, events)
        pool.xread.assert_awaited_once_with(
            {chat_service._generation_stream_key(self.chat.id, "shared-generation"): "0-0"},
            count=100,
            block=1000,
        )

    async def test_cancel_next_generation_does_not_inherit_previous_signal(self):
        stream = await self.start()
        first_job = chat_service._generations[self.chat.id]
        await chat_service.cancel_chat(self.db, self.chat.id, "test-user")
        _ = [event async for event in stream]
        await first_job.task
        second = await self.start()
        second_job = chat_service._generations[self.chat.id]
        self.assertFalse(second_job.cancel.is_set())
        await second.aclose()
        self.release.set()
        await asyncio.wait_for(second_job.task, timeout=2)
        self.assertEqual(self.chat.status, "completed")

    async def test_detaching_does_not_cancel_generation(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        self.assertTrue(job.detached.is_set())
        self.assertFalse(job.cancel.is_set())
        self.assertFalse(job.task.done())
        self.release.set()
        await asyncio.wait_for(job.task, timeout=2)
        self.assertTrue(job.done.is_set())
        self.assertEqual(self.chat.status, "completed")

    async def test_duplicate_send_reattaches_to_active_job(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()
        duplicate = chat_service.send_message_stream(self.chat.id, "duplicate", "test-user")
        # Release must happen BEFORE consuming the duplicate stream,
        # otherwise the background task blocks on release.wait() and
        # the async for deadlocks waiting for events.
        self.release.set()
        events = [event async for event in duplicate]
        self.assertEqual(json.loads(events[0][6:])["type"], "delta")
        self.assertEqual(events[-1], "data: [DONE]\n\n")
        # Job stays in _generations when detached, allowing reattach
        self.assertIs(chat_service._generations.get(self.chat.id), job)
        # save_message called twice: user message (send_message_stream) + assistant message (_run_generation)
        self.assertEqual(self.save.call_count, 2)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        await asyncio.wait_for(job.task, timeout=2)
        self.assertTrue(job.done.is_set())

    async def test_reconnect_replays_events_received_before_disconnect(self):
        stream = await self.start()
        job = chat_service._generations[self.chat.id]
        await stream.aclose()

        reconnect = chat_service.send_message_stream(
            self.chat.id, "", "test-user"
        )
        replayed = await asyncio.wait_for(anext(reconnect), timeout=2)
        self.assertEqual(json.loads(replayed[6:])["content"], "first")

        self.release.set()
        remaining = [event async for event in reconnect]
        self.assertEqual(
            [json.loads(event[6:]).get("content") for event in remaining[:-1]],
            ["-last", None],
        )
        self.assertEqual(remaining[-1], "data: [DONE]\n\n")
        await asyncio.wait_for(job.task, timeout=2)

    async def test_empty_message_without_generating_chat_is_rejected(self):
        events = [
            event async for event in chat_service.send_message_stream(
                self.chat.id, "", "test-user"
            )
        ]

        self.assertEqual(
            json.loads(events[0][6:])["message"], "没有正在生成的回复可恢复"
        )
        self.assertEqual(events[-1], "data: [DONE]\n\n")
        self.sessions.assert_called_once()
        self.save.assert_not_called()

    async def test_completed_chat_with_stale_generating_status_is_reconciled(self):
        self.chat.status = "generating"
        self.sessions.return_value.query.return_value.filter.return_value.order_by.return_value.all.return_value = [
            SimpleNamespace(role="user", content="question"),
            SimpleNamespace(role="assistant", content="completed answer"),
        ]

        events = [
            event async for event in chat_service.send_message_stream(
                self.chat.id, "", "test-user"
            )
        ]

        self.assertEqual(self.chat.status, "completed")
        self.sessions.return_value.commit.assert_called()
        self.assertEqual(json.loads(events[0][6:])["type"], "done")
        self.assertEqual(events[-1], "data: [DONE]\n\n")
        self.sessions.assert_called_once()
        self.save.assert_not_called()

    async def test_missing_job_restarts_from_persisted_conversation(self):
        self.chat.status = "generating"
        self.sessions.return_value.query.return_value.filter.return_value.order_by.return_value.all.return_value = [
            SimpleNamespace(role="user", content="original question")
        ]
        self.save.reset_mock()

        stream = chat_service.send_message_stream(
            self.chat.id, "", "test-user"
        )
        first_event = await asyncio.wait_for(anext(stream), timeout=2)
        self.assertEqual(json.loads(first_event[6:])["content"], "first")
        job = chat_service._generations[self.chat.id]
        await asyncio.wait_for(self.waiting.wait(), timeout=2)

        self.release.set()
        events = [first_event, *[event async for event in stream]]
        await asyncio.wait_for(job.task, timeout=2)

        self.assertEqual(self.save.call_count, 1)
        self.assertEqual(self.save.call_args.args[2:], ("assistant", "first-last"))
        self.assertEqual(self.chat.status, "completed")
