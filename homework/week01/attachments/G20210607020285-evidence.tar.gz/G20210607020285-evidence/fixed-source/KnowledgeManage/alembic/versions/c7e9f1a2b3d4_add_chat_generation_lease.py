"""Add distributed generation ownership to chats."""

from alembic import op
import sqlalchemy as sa

revision = "c7e9f1a2b3d4"
down_revision = "b4c6d8e0f2a1"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "chats",
        sa.Column("generation_id", sa.String(36), nullable=True),
        schema="knowledge_manage",
    )
    op.add_column(
        "chats",
        sa.Column("lease_owner", sa.String(36), nullable=True),
        schema="knowledge_manage",
    )
    op.add_column(
        "chats",
        sa.Column("lease_expires_at", sa.TIMESTAMP(timezone=True), nullable=True),
        schema="knowledge_manage",
    )
    op.create_index(
        "idx_chats_generation_id",
        "chats",
        ["generation_id"],
        schema="knowledge_manage",
    )


def downgrade() -> None:
    op.drop_index("idx_chats_generation_id", table_name="chats", schema="knowledge_manage")
    op.drop_column("chats", "lease_expires_at", schema="knowledge_manage")
    op.drop_column("chats", "lease_owner", schema="knowledge_manage")
    op.drop_column("chats", "generation_id", schema="knowledge_manage")
