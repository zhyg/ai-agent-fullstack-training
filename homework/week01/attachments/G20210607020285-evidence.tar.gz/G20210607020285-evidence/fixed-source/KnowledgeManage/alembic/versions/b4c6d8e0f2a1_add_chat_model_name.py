"""Store the model display name used for Gateway routing."""

from alembic import op
import sqlalchemy as sa

revision = "b4c6d8e0f2a1"
down_revision = "a3f5e6d7c8b9"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "chats",
        sa.Column("model_name", sa.String(200), nullable=True),
        schema="knowledge_manage",
    )


def downgrade() -> None:
    op.drop_column("chats", "model_name", schema="knowledge_manage")
