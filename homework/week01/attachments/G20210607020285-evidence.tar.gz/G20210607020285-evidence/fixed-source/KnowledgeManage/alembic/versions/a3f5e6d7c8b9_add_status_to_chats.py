"""add status column to chats table

Revision ID: a3f5e6d7c8b9
Revises: 5426a5756ea3
Create Date: 2026-10-28 16:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'a3f5e6d7c8b9'
down_revision: Union[str, None] = '5426a5756ea3'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = 'knowledge_manage'


def upgrade() -> None:
    op.add_column(
        'chats',
        sa.Column(
            'status',
            sa.String(20),
            nullable=False,
            server_default='idle',
            comment='会话状态: idle/generating/completed/cancelled',
        ),
        schema=SCHEMA,
    )
    # Remove server_default after setting initial value
    op.alter_column('chats', 'status', server_default=None, schema=SCHEMA)
    # Index for status filtering
    op.create_index(
        'idx_chats_status',
        'chats',
        ['status'],
        schema=SCHEMA,
    )


def downgrade() -> None:
    op.drop_index('idx_chats_status', table_name='chats', schema=SCHEMA)
    op.drop_column('chats', 'status', schema=SCHEMA)
