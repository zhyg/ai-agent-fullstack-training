# Chat Service 多实例流式生成架构

## 整体架构图

```
┌──────────┐     ┌──────────┐
│ 客户端SSE │     │ 客户端SSE │
└────┬─────┘     └────┬─────┘
     │                │
     ▼                ▼
┌─────────────────────────┐
│       负载均衡           │
└────┬───────────────┬────┘
     │               │
     ▼               ▼
┌─────────┐     ┌─────────┐
│  实例 A  │     │  实例 B  │
└────┬────┘     └────┬────┘
     │               │
     │   XADD events │   XREAD events
     │   PUBLISH     │   SUBSCRIBE
     ▼               ▼
┌─────────────────────────┐
│         Redis           │
└─────────────────────────┘
     │               │
     ▼               ▼
┌─────────────────────────┐
│       PostgreSQL        │
└─────────────────────────┘
```

## 一、核心概念

### 1. Generation（生成任务）

每次用户发消息，会创建一个 `generation_id`（UUID），代表一次完整的 LLM 生成过程。

```python
generation_id = str(uuid.uuid4())  # 例如: "a1b2c3d4-..."
```

### 2. Lease（租约机制）

**核心思想**：谁拥有租约，谁才能执行生成任务。

Chat 表相关字段：
```python
generation_id     # 当前生成任务 ID
lease_owner       # 持有该任务的实例 ID（如 "host1:abc123"）
lease_expires_at  # 租约过期时间（当前时间 + 30秒）
```

租约每 5 秒续期一次，30 秒过期。如果实例崩溃，租约自然过期，其他实例可以接管。

## 二、Redis 的三种用途

### 用途 1：Redis Stream — 跨实例事件流

**Key 格式**：`chat:{chat_id}:generation:{generation_id}:events`

**作用**：让不在运行任务的实例也能"看到"生成进度。

```
实例A 运行生成任务 → XADD 事件到 Stream
实例B 收到客户端重连 → XREAD 从 Stream 回放事件
```

**写入端** (`_emit_event`)：
```python
async def _emit_event(job, event_str):
    job._emit(event_str)           # 1. 写入本地内存队列
    await pool.xadd(stream_key,    # 2. 写入 Redis Stream
        {"event": event_str, "done": "0"},
        maxlen=5000, approximate=True
    )
    await pool.expire(stream_key, 86400)  # TTL 24小时
```

**读取端** (`_stream_shared_generation`)：
```python
# 从 Redis Stream 读取事件，阻塞等待新事件
response = await pool.xread({stream_key: last_id}, count=100, block=1000)
for _, entries in response:
    for entry_id, fields in entries:
        event = fields.get("event", "")
        done = fields.get("done", "0")
        if event:
            yield event          # 转发给客户端
        if done == "1":
            return               # 生成结束
```

**完成标记** (`_publish_generation_done`)：
```python
await pool.xadd(stream_key, {"event": "", "done": "1"})  # 发送结束信号
```

---

### 用途 2：Redis Key — 持久化取消信号

**Key 格式**：`chat:{chat_id}:generation:{generation_id}:cancel`

**作用**：解决"取消时目标实例还没开始监听 Pub/Sub"的竞态问题。

```python
# cancel_chat 中
await pool.set(cancel_key, "1", ex=86400)   # 先持久化
await pool.publish(channel, {...})           # 再广播
```

```python
# _listen_cancel 启动时检查
if await pool.get(cancel_key):   # 如果 key 已存在
    job.cancel.set()             # 说明在我们启动前就被取消了
    job.task.cancel()
    return
```

**为什么需要这个？** 考虑这个时序：

```
T1: 用户点取消 → set cancel_key = "1", publish
T2: 后台任务启动 → subscribe channel

如果没有 cancel_key，T2 永远收不到 T1 的 publish（因为 publish 时还没人订阅）
有了 cancel_key，T2 启动后先检查 key，发现已被取消，直接退出
```

---

### 用途 3：Redis Pub/Sub — 实时取消广播

**Channel 格式**：`chat:{chat_id}:cancel`

**作用**：实时通知所有实例"这个 chat 被取消了"。

```python
# 发布端（cancel_chat）
await pool.publish(channel, json.dumps({
    "action": "cancel",
    "chat_id": chat_id,
    "generation_id": generation_id  # 带上 generation_id 防止误取消
}))
```

```python
# 订阅端（_listen_cancel）
await pubsub.subscribe(channel)
async for message in pubsub.listen():
    signal = json.loads(message.get("data"))
    if signal.get("generation_id") == job.generation_id:  # 只处理匹配的 generation
        job.cancel.set()
        job.task.cancel()
        break
```

## 三、关键流程详解

### 流程 1：新消息发送

```
客户端                send_message_stream          PostgreSQL       Redis          _run_generation
  │                          │                         │              │                  │
  │──POST /messages─────────>│                         │              │                  │
  │                          │──get_chat()────────────>│              │                  │
  │                          │<────────────────────────│              │                  │
  │                          │                         │              │                  │
  │                          │  检查 lease 是否被其他实例持有          │                  │
  │                          │                         │              │                  │
  │                          │  ┌─ 如果其他实例正在生成 ─┐              │                  │
  │                          │  │ XREAD (跟随事件流)    │              │                  │
  │<──yield events───────────│  └───────────────────────┘              │                  │
  │                          │                         │              │                  │
  │                          │  ┌─ 如果无活跃生成 ─────┐              │                  │
  │                          │  │ _claim_generation()  │              │                  │
  │                          │  │ (原子抢占)           │              │                  │
  │                          │  │                      │              │                  │
  │                          │  │ save_message(user)   │              │                  │
  │                          │  │ 创建 _GenerationJob  │              │                  │
  │                          │  │ asyncio.create_task()│              │                  │
  │                          │  └──────────────────────┘              │                  │
  │                          │                         │              │                  │
  │                          │                         │              │<─XADD events─────│
  │<──yield events───────────│<──local queue───────────│              │                  │
```

**`_claim_generation` 的原子性保证**：

```python
def _claim_generation(db, chat, user_id, generation_id, *, recovery):
    # 用 UPDATE ... WHERE 条件实现原子抢占
    # 只有满足条件的行才会被更新（返回 rowcount=1）
    result = db.query(Chat).filter(
        Chat.id == chat.id,
        Chat.user_id == user_id,
        # 状态必须是 idle/completed/cancelled，或者 generating 但租约过期
        or_(
            Chat.status.in_(("idle", "completed", "cancelled")),
            (Chat.status == "generating") & (Chat.lease_expires_at <= now),
        )
    ).update({
        Chat.status: "generating",
        Chat.generation_id: generation_id,
        Chat.lease_owner: _instance_id,
        Chat.lease_expires_at: now + 30秒,
    })

    if result.rowcount != 1:
        return False  # 被其他实例抢先了
    return True
```

---

### 流程 2：客户端重连到其他实例

```
客户端              实例B                    Redis              PostgreSQL
  │                   │                       │                    │
  │─POST /messages───>│                       │                    │
  │  (reconnect)      │──get_chat()──────────>│                    │
  │                   │<──────────────────────│                    │
  │                   │                       │                    │
  │                   │  检查 lease_expires_at │                    │
  │                   │                       │                    │
  │                   │  ┌─ lease 未过期 (实例A还在跑) ─┐           │
  │                   │  │                             │           │
  │                   │  │──XREAD events──────────────>│           │
  │                   │  │<──event entries─────────────│           │
  │<──yield event─────│  │                             │           │
  │                   │  │──XREAD events (继续)───────>│           │
  │                   │  │<──event entries─────────────│           │
  │<──yield event─────│  └─────────────────────────────┘           │
  │                   │                       │                    │
  │                   │  ┌─ lease 已过期 (实例A挂了) ─┐             │
  │                   │  │                           │             │
  │                   │  │──_claim_generation()──────>│             │
  │                   │  │  (接管任务，重新启动生成)   │             │
  │                   │  └───────────────────────────┘             │
```

---

### 流程 3：取消生成

```
客户端          实例B (cancel请求)       Redis              实例A (运行任务)       PostgreSQL
  │                   │                   │                      │                    │
  │─POST /cancel─────>│                   │                      │                    │
  │                   │──UPDATE status───>│                      │                    │
  │                   │  ='cancelled'     │                      │                    │
  │                   │                   │                      │                    │
  │                   │──SET cancel_key──>│                      │                    │
  │                   │  = "1" (持久化)   │                      │                    │
  │                   │                   │                      │                    │
  │                   │──PUBLISH cancel──>│                      │                    │
  │                   │                   │                      │                    │
  │                   │  ┌─ 如果任务在本地 ─┐                     │                    │
  │                   │  │ job.cancel.set() │                    │                    │
  │                   │  └─────────────────┘                     │                    │
  │                   │                   │                      │                    │
  │                   │                   │──message────────────>│                    │
  │                   │                   │  _listen_cancel      │                    │
  │                   │                   │  收到信号            │                    │
  │                   │                   │                      │                    │
  │                   │                   │                      │──job.cancel.set()  │
  │                   │                   │                      │──break 循环        │
  │                   │                   │                      │                    │
  │                   │                   │                      │──_finalize_generation()
  │                   │                   │                      │──UPDATE status     │
  │                   │                   │                      │                    │
  │                   │                   │                      │──XADD done=1       │
```

---

### 流程 4：租约维护

```
_run_generation                    PostgreSQL
      │                                │
      │  ┌─ 循环开始 ─────────────────┐ │
      │  │                            │ │
      │  │  await sleep(5秒)          │ │
      │  │                            │ │
      │  │──UPDATE lease_expires_at──>│ │
      │  │   = now + 30秒             │ │
      │  │                            │ │
      │  │  ┌─ 如果更新失败 ────────┐ │ │
      │  │  │ (被取消或租约丢失)    │ │ │
      │  │  │ job.cancel.set()     │ │ │
      │  │  │ return               │ │ │
      │  │  └──────────────────────┘ │ │
      │  │                            │ │
      │  └────────────────────────────┘ │
```

**`_renew_generation_lease`**：
```python
def _renew_generation_lease(chat_id, generation_id, db):
    result = db.query(Chat).filter(
        Chat.id == chat_id,
        Chat.generation_id == generation_id,
        Chat.lease_owner == _instance_id,  # 只续自己的租约
        Chat.status == "generating",
    ).update({
        Chat.lease_expires_at: now + 30秒,
    })
    return result.rowcount == 1
```

---

### 流程 5：生成完成/失败

```python
# _finalize_generation
def _finalize_generation(db, chat_id, generation_id, content, cancelled):
    # 只有仍持有租约时才能写入最终状态
    result = db.query(Chat).filter(
        Chat.id == chat_id,
        Chat.generation_id == generation_id,
        Chat.lease_owner == _instance_id,  # 防止覆盖其他实例的结果
    ).update({
        Chat.status: "cancelled" if cancelled else "completed",
        Chat.lease_owner: None,        # 释放租约
        Chat.lease_expires_at: None,
    })

    if content:
        save_message(db, chat_id, "assistant", content)

    # 最后发布完成标记到 Redis Stream
    await _publish_generation_done(job)  # XADD done=1
```

## 四、Redis Key 总结

| Key/Channel | 类型 | TTL | 用途 |
|-------------|------|-----|------|
| `chat:{id}:generation:{gid}:events` | Stream | 24h | 跨实例事件流 |
| `chat:{id}:generation:{gid}:cancel` | String | 24h | 持久化取消信号 |
| `chat:{id}:cancel` | Pub/Sub | - | 实时取消广播 |

## 五、设计解决的问题

| 问题 | 解决方案 |
|------|----------|
| 两个实例同时启动同一 chat 的生成 | `_claim_generation` 原子 UPDATE，只有一个能成功 |
| 实例崩溃，任务无法完成 | 租约30秒过期，其他实例可以接管 |
| 取消时目标实例还没开始监听 | 先 SET key，再 PUBLISH，启动时先检查 key |
| 客户端重连到不同实例 | 通过 Redis Stream 回放事件 |
| 重复写入 assistant 消息 | `_finalize_generation` 检查 `lease_owner`，只有持有者能写入 |

## 六、核心设计思想

> **DB 做状态仲裁，Redis 做事件同步，内存做快速路径。**

- **PostgreSQL**：通过 `UPDATE ... WHERE` 条件实现原子状态转换，确保只有一个实例能拥有生成任务
- **Redis Stream**：持久化事件流，支持跨实例回放和实时订阅
- **Redis Key**：解决 Pub/Sub "发布时无人订阅"的竞态问题
- **Redis Pub/Sub**：低延迟实时通知
- **内存队列**：本地实例的快速路径，避免 Redis 开销
