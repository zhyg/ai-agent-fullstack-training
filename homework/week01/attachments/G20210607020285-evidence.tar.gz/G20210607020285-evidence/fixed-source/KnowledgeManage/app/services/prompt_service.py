import uuid
import logging
from datetime import datetime, timezone
from typing import Optional, List, Tuple

import httpx
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.prompt import Prompt
from app.schemas.prompt import PromptCreate, PromptUpdate

logger = logging.getLogger(__name__)


def _is_admin(user: dict) -> bool:
    """Check if user has admin permissions."""
    permissions = user.get("permissions", [])
    return "permission_manage" in permissions


async def _resolve_user_names(user_ids: List[str], token: str = "") -> dict:
    """Resolve user IDs to email via UserManage service.

    Returns a dict mapping user_id -> email.
    """
    if not user_ids:
        return {}

    user_manage_url = settings.services.get("user_manage", "http://localhost:8001")
    name_map = {}

    try:
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        logger.debug(f"Resolving {len(set(user_ids))} users via {user_manage_url}, token present: {bool(token)}")
        async with httpx.AsyncClient(timeout=5.0) as client:
            for uid in set(user_ids):
                try:
                    resp = await client.get(
                        f"{user_manage_url}/api/user/users/{uid}",
                        headers=headers
                    )
                    logger.debug(f"User lookup {uid}: status={resp.status_code}")
                    if resp.status_code == 200:
                        data = resp.json()
                        name_map[uid] = data.get("email", "已删除用户")
                    else:
                        logger.warning(f"User lookup failed: status={resp.status_code}, body={resp.text}")
                        name_map[uid] = "已删除用户"
                except Exception:
                    name_map[uid] = "已删除用户"
    except Exception as e:
        logger.warning(f"Failed to resolve user names: {e}")
        for uid in set(user_ids):
            if uid not in name_map:
                name_map[uid] = "已删除用户"

    return name_map


def create_prompt(db: Session, data: PromptCreate, current_user: dict) -> Prompt:
    """Create a new prompt with auto-set creator_id."""
    prompt = Prompt(
        id=str(uuid.uuid4()),
        name=data.name,
        version=data.version,
        description=data.description,
        content=data.content,
        creator_id=current_user["id"],
    )
    db.add(prompt)
    db.commit()
    db.refresh(prompt)
    return prompt


def list_prompts(
    db: Session, current_user: dict, page: int = 1, page_size: int = 20
) -> Tuple[List[Prompt], int]:
    """List prompts with access control:
    - Regular user: only own records
    - Admin: all records
    """
    query = db.query(Prompt)

    if not _is_admin(current_user):
        query = query.filter(Prompt.creator_id == current_user["id"])

    total = query.count()
    items = (
        query.order_by(Prompt.updated_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    return items, total


async def list_prompts_with_names(
    db: Session, current_user: dict, page: int = 1, page_size: int = 20
) -> Tuple[List[dict], int]:
    """List prompts with creator_name resolved for admin view."""
    items, total = list_prompts(db, current_user, page, page_size)
    is_admin = _is_admin(current_user)

    result = []
    if is_admin and items:
        creator_ids = [p.creator_id for p in items]
        token = current_user.get("token", "")
        name_map = await _resolve_user_names(creator_ids, token)
    else:
        name_map = {}

    for prompt in items:
        item_dict = {
            "id": prompt.id,
            "name": prompt.name,
            "version": prompt.version,
            "description": prompt.description or "",
            "content": prompt.content,
            "creator_id": prompt.creator_id,
            "created_at": prompt.created_at,
            "updated_at": prompt.updated_at,
        }
        if is_admin:
            item_dict["creator_name"] = name_map.get(prompt.creator_id, "已删除用户")
        result.append(item_dict)

    return result, total


def update_prompt(
    db: Session, prompt_id: str, data: PromptUpdate, current_user: dict
) -> Optional[Prompt]:
    """Update a prompt. Only the creator can update."""
    prompt = db.query(Prompt).filter(Prompt.id == prompt_id).first()
    if not prompt:
        return None

    if prompt.creator_id != current_user["id"]:
        raise PermissionError("无权编辑此提示词")

    if data.description is not None:
        prompt.description = data.description
    if data.content is not None:
        prompt.content = data.content

    prompt.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(prompt)
    return prompt


def delete_prompt(
    db: Session, prompt_id: str, current_user: dict
) -> bool:
    """Delete a prompt.
    - Regular user: only own records
    - Admin: any record
    """
    prompt = db.query(Prompt).filter(Prompt.id == prompt_id).first()
    if not prompt:
        return False

    is_admin = _is_admin(current_user)
    if not is_admin and prompt.creator_id != current_user["id"]:
        raise PermissionError("无权删除此提示词")

    db.delete(prompt)
    db.commit()
    return True
