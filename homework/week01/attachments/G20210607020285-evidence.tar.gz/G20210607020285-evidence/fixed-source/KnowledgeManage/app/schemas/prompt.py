from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, TypeVar, Generic
from datetime import datetime


class PromptCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="提示词名称（必填）")
    version: str = Field(..., min_length=1, max_length=20, description="版本号（必填）")
    description: str = Field("", description="描述")
    content: str = Field(..., min_length=1, description="提示词内容（必填）")


class PromptUpdate(BaseModel):
    description: Optional[str] = Field(None, description="描述")
    content: str = Field(..., min_length=1, description="提示词内容（必填）")
    # name 和 version 不可修改，不出现在 Update Schema 中


class PromptResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    version: str
    description: str
    content: str
    creator_id: str
    creator_name: Optional[str] = None  # 仅管理员视图返回
    created_at: datetime
    updated_at: datetime


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
