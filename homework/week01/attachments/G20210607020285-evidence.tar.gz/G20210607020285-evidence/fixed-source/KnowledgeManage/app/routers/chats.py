from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.schemas.chat import (
    ChatCreate,
    ChatUpdate,
    ChatResponse,
    MessageCreate,
    MessageResponse,
    ChatCancelResponse,
    PaginatedResponse,
)
from app.services import chat_service

router = APIRouter(prefix="/chats", tags=["会话管理"])


@router.get("", response_model=PaginatedResponse[ChatResponse])
async def list_chats(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取当前用户的会话列表"""
    items, total = chat_service.list_chats(db, current_user["id"], page, page_size)
    return {
        "items": [ChatResponse.model_validate(c) for c in items],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("", response_model=ChatResponse, status_code=status.HTTP_201_CREATED)
async def create_chat(
    body: ChatCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """创建新会话"""
    chat = chat_service.create_chat(db, current_user["id"], body)
    return ChatResponse.model_validate(chat)


@router.put("/{chat_id}", response_model=ChatResponse)
async def update_chat(
    chat_id: str,
    body: ChatUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """更新会话（标题/模型/提示词）"""
    chat = chat_service.update_chat(db, chat_id, current_user["id"], body)
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")
    return ChatResponse.model_validate(chat)


@router.delete("/{chat_id}")
async def delete_chat(
    chat_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除会话及其所有消息"""
    ok = chat_service.delete_chat(db, chat_id, current_user["id"])
    if not ok:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")
    return {"message": "会话删除成功"}


@router.get("/{chat_id}/messages", response_model=PaginatedResponse[MessageResponse])
async def list_messages(
    chat_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取会话消息列表"""
    chat = chat_service.get_chat(db, chat_id, current_user["id"])
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")

    items, total = chat_service.list_messages(db, chat_id, page, page_size)
    return {
        "items": [MessageResponse.model_validate(m) for m in items],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("/{chat_id}/messages")
async def send_message(
    chat_id: str,
    body: MessageCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """发送消息并获取 LLM 流式回复（SSE），支持 Redis Pub/Sub 取消"""
    chat = chat_service.get_chat(db, chat_id, current_user["id"])
    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")

    if not chat.model_name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="请先选择模型")

    return StreamingResponse(
        chat_service.send_message_stream(
            chat_id, body.content, current_user["id"]
        ),
        media_type="text/event-stream",
    )


@router.post("/{chat_id}/cancel", response_model=ChatCancelResponse)
async def cancel_chat(
    chat_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """取消正在生成中的会话，通过 Redis Pub/Sub 发送取消信号"""
    try:
        chat = await chat_service.cancel_chat(db, chat_id, current_user["id"])
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))

    if not chat:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="会话不存在或无权访问")

    return ChatCancelResponse(id=chat.id, status=chat.status, message="Session cancelled")
