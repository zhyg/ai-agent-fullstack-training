import os
import yaml
from pydantic import BaseModel, Field
from typing import Optional


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8002


class DatabaseConfig(BaseModel):
    url: str
    db_schema: str = Field(default="public", validation_alias="schema")
    echo: bool = False


class JwtConfig(BaseModel):
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7


class LoggingConfig(BaseModel):
    level: str = "INFO"


class RedisConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None

    @property
    def url(self) -> str:
        auth = f":{self.password}@" if self.password else ""
        return f"redis://{auth}{self.host}:{self.port}/{self.db}"


class Settings(BaseModel):
    server: ServerConfig
    database: DatabaseConfig
    jwt: JwtConfig
    redis: RedisConfig = RedisConfig()
    services: dict = {}
    llm_api_key: str = ""
    logging: LoggingConfig = LoggingConfig()


def load_settings(env: Optional[str] = None) -> Settings:
    env = env or os.getenv("APP_ENV", "dev")
    config_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        f"config.{env}.yaml"
    )
    with open(config_path) as f:
        data = yaml.safe_load(f)
    return Settings(**data)


settings = load_settings()
