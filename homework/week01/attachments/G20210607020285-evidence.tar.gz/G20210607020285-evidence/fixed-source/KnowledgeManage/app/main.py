import logging
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import init_schema
from app.core.config import settings
from app.routers import prompts, chats
from app.services.chat_service import set_redis_pool
from app.services import chat_service

logging.basicConfig(
    level=settings.logging.level,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown lifecycle."""
    logger.info("Initializing KnowledgeManage service...")
    init_schema()

    # Initialize Redis connection pool
    redis_pool = aioredis.Redis(
        host=settings.redis.host,
        port=settings.redis.port,
        db=settings.redis.db,
        password=settings.redis.password,
        decode_responses=True,
    )
    set_redis_pool(redis_pool)
    app.state.redis = redis_pool
    logger.info("Redis connection pool initialized")

    logger.info("KnowledgeManage service started")
    yield

    # Gracefully finish any active generation jobs
    await chat_service.finish_generations()

    # Cleanup Redis pool
    await redis_pool.aclose()
    logger.info("KnowledgeManage service shutting down")


app = FastAPI(
    title="KnowledgeManage Service",
    description="知识管理服务 - 开发者门户平台",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(prompts.router, prefix="/api/knowledge")
app.include_router(chats.router, prefix="/api/knowledge")


@app.get("/api/knowledge/health")
async def health_check():
    return {"status": "ok", "service": "KnowledgeManage"}
