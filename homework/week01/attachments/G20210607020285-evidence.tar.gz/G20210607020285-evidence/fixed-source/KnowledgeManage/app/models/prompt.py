import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, Text, TIMESTAMP, Index

from app.core.database import Base
from app.core.config import settings


class Prompt(Base):
    __tablename__ = "prompts"
    __table_args__ = (
        Index("idx_prompts_creator", "creator_id"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False, comment="提示词名称")
    version = Column(String(20), nullable=False, comment="版本号")
    description = Column(Text, default="", comment="描述")
    content = Column(Text, nullable=False, comment="提示词内容")
    creator_id = Column(String(36), nullable=False, comment="创建者用户 ID")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )
