from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

from app.core.security import decode_token

security_scheme = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security_scheme),
) -> dict:
    """Extract and validate JWT token, return current user info dict.

    The token payload contains:
    - sub: user ID (UUID)
    - uid: username
    - role_ids: list of role IDs
    - permissions: list of permission keys
    """
    token = credentials.credentials
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="无效的令牌类型"
            )
        return {
            "id": payload.get("sub"),
            "uid": payload.get("uid"),
            "role_ids": payload.get("role_ids", []),
            "permissions": payload.get("permissions", []),
            "token": token
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="令牌已过期，请重新登录"
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="无效的令牌"
        )


def require_permission(permission: str):
    """Dependency factory: require a specific permission."""
    async def check_permission(
        current_user: dict = Depends(get_current_user)
    ) -> dict:
        user_permissions = current_user.get("permissions", [])
        if permission not in user_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"无权访问：需要 {permission} 权限"
            )
        return current_user
    return check_permission
