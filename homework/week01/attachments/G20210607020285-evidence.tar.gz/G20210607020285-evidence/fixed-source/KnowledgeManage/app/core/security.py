import jwt
from datetime import datetime, timedelta, timezone
from typing import Optional

from app.core.config import settings


def decode_token(token: str) -> dict:
    """Decode and verify a JWT token using shared secret.
    Raises jwt.PyJWTError on failure.
    """
    return jwt.decode(
        token,
        settings.jwt.secret_key,
        algorithms=[settings.jwt.algorithm]
    )
