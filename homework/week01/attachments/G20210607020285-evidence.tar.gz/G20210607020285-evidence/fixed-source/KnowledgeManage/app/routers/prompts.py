import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.models.prompt import Prompt
from app.schemas.prompt import PromptCreate, PromptUpdate, PromptResponse, PaginatedResponse
from app.services import prompt_service

logger = logging.getLogger(__name__)

router = APIRouter(tags=["prompts"])


@router.get("/prompts/lookup")
async def lookup_prompt(
    name: str = Query(..., description="提示词名称"),
    version: str = Query(..., description="版本号"),
    db: Session = Depends(get_db),
):
    """Internal endpoint: lookup a prompt by name and version.

    Used by LlmGateway service. No authentication required (internal call).
    """
    prompt = (
        db.query(Prompt)
        .filter(Prompt.name == name, Prompt.version == version)
        .first()
    )
    if not prompt:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"提示词 '{name}' 版本 '{version}' 不存在",
        )
    return {
        "id": prompt.id,
        "name": prompt.name,
        "version": prompt.version,
        "content": prompt.content,
    }


@router.get("/prompts", response_model=PaginatedResponse[PromptResponse])
async def list_prompts(
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=1, le=100, description="每页条数"),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取提示词列表。普通用户仅看自己的，管理员可看所有并附带 creator_name。"""
    items, total = await prompt_service.list_prompts_with_names(
        db, current_user, page, page_size
    )
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("/prompts", response_model=PromptResponse, status_code=status.HTTP_201_CREATED)
def create_prompt(
    data: PromptCreate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """创建提示词，creator_id 自动设置为当前用户。"""
    prompt = prompt_service.create_prompt(db, data, current_user)
    return prompt


@router.put("/prompts/{prompt_id}", response_model=PromptResponse)
def update_prompt(
    prompt_id: str,
    data: PromptUpdate,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """编辑提示词，仅创建者可编辑。"""
    try:
        prompt = prompt_service.update_prompt(db, prompt_id, data, current_user)
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )

    if prompt is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="提示词不存在",
        )
    return prompt


@router.delete("/prompts/{prompt_id}")
def delete_prompt(
    prompt_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除提示词。普通用户仅删自己的，管理员可删任意。"""
    try:
        deleted = prompt_service.delete_prompt(db, prompt_id, current_user)
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="提示词不存在",
        )
    return {"message": "提示词删除成功"}
