"""create users and roles tables

Revision ID: 001_initial
Revises:
Create Date: 2026-10-27

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSON

from app.core.config import settings

# revision identifiers, used by Alembic.
revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = settings.database.db_schema


def upgrade() -> None:
    op.create_table(
        "roles",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(50), unique=True, nullable=False),
        sa.Column("description", sa.String(200), server_default=""),
        sa.Column("created_at", sa.TIMESTAMP, nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.TIMESTAMP, nullable=False, server_default=sa.func.now()),
        schema=SCHEMA,
    )

    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("uid", sa.String(50), unique=True, nullable=False),
        sa.Column("email", sa.String(100), unique=True, nullable=False),
        sa.Column("password", sa.String(255), nullable=False),
        sa.Column("role_ids", JSON, nullable=False, server_default="[]"),
        sa.Column("login_fail_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("locked_until", sa.TIMESTAMP, nullable=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.TIMESTAMP, nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.TIMESTAMP, nullable=False, server_default=sa.func.now()),
        schema=SCHEMA,
    )

    op.create_index("idx_users_uid", "users", ["uid"], schema=SCHEMA)
    op.create_index("idx_users_email", "users", ["email"], schema=SCHEMA)


def downgrade() -> None:
    op.drop_index("idx_users_email", table_name="users", schema=SCHEMA)
    op.drop_index("idx_users_uid", table_name="users", schema=SCHEMA)
    op.drop_table("users", schema=SCHEMA)
    op.drop_table("roles", schema=SCHEMA)
