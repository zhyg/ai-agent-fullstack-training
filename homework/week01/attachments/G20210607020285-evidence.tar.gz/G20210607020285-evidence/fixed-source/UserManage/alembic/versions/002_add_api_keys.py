"""add api_keys table

Revision ID: 002_add_api_keys
Revises: 001_initial
Create Date: 2026-10-28

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

from app.core.config import settings

# revision identifiers, used by Alembic.
revision: str = "002_add_api_keys"
down_revision: Union[str, None] = "001_initial"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SCHEMA = settings.database.db_schema


def upgrade() -> None:
    op.create_table(
        "api_keys",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(36),
            sa.ForeignKey(
                f"{SCHEMA}.users.id", ondelete="CASCADE"
            ),
            nullable=False,
        ),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("key_hash", sa.String(64), nullable=False),
        sa.Column("masked_key", sa.String(50), nullable=False),
        sa.Column(
            "created_at",
            sa.TIMESTAMP,
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("last_used_at", sa.TIMESTAMP, nullable=True),
        schema=SCHEMA,
    )

    op.create_index(
        "idx_api_keys_user_id", "api_keys", ["user_id"], schema=SCHEMA
    )
    op.create_index(
        "idx_api_keys_key_hash", "api_keys", ["key_hash"], schema=SCHEMA
    )


def downgrade() -> None:
    op.drop_index("idx_api_keys_key_hash", table_name="api_keys", schema=SCHEMA)
    op.drop_index("idx_api_keys_user_id", table_name="api_keys", schema=SCHEMA)
    op.drop_table("api_keys", schema=SCHEMA)
