from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.orm import Session

from app.models.user import User
from app.core.security import (
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
)
from app.core.permissions import get_permissions_for_roles
from app.services.user_service import get_user_by_uid, get_role_names_by_ids
import jwt


LOCKOUT_THRESHOLD = 5
LOCKOUT_DURATION_MINUTES = 15


def _is_account_locked(user: User) -> bool:
    """Check if user account is currently locked."""
    if user.locked_until is None:
        return False
    now = datetime.now(timezone.utc)
    locked_until = user.locked_until
    if locked_until.tzinfo is None:
        locked_until = locked_until.replace(tzinfo=timezone.utc)
    return now < locked_until


def _lock_account(user: User) -> None:
    """Lock user account for LOCKOUT_DURATION_MINUTES."""
    user.locked_until = datetime.now(timezone.utc) + timedelta(
        minutes=LOCKOUT_DURATION_MINUTES
    )


def _reset_login_fail(user: User) -> None:
    """Reset login failure counter and lock."""
    user.login_fail_count = 0
    user.locked_until = None


def _increment_login_fail(user: User) -> None:
    """Increment login failure counter, lock if threshold reached."""
    user.login_fail_count += 1
    if user.login_fail_count >= LOCKOUT_THRESHOLD:
        _lock_account(user)


def login(
    db: Session, uid: str, password: str
) -> dict:
    """Authenticate user and return tokens + user info.

    Returns dict with: access_token, refresh_token, user, permissions
    Raises ValueError with appropriate message on failure.
    """
    user = get_user_by_uid(db, uid)
    if not user:
        raise ValueError("用户名或密码错误")

    if not user.is_active:
        raise ValueError("账户已被禁用")

    # Check lockout
    if _is_account_locked(user):
        locked_until = user.locked_until
        if locked_until.tzinfo is None:
            locked_until = locked_until.replace(tzinfo=timezone.utc)
        remaining = int(
            (locked_until - datetime.now(timezone.utc)).total_seconds() / 60
        ) + 1
        db.commit()
        raise PermissionError(f"账户已锁定，请 {remaining} 分钟后再试")

    # Verify password
    if not verify_password(password, user.password):
        _increment_login_fail(user)
        db.commit()
        raise ValueError("用户名或密码错误")

    # Success — reset fail count
    _reset_login_fail(user)

    # Build token payload
    role_names = get_role_names_by_ids(db, user.role_ids)
    permissions = get_permissions_for_roles(role_names)

    token_data = {
        "sub": user.id,
        "uid": user.uid,
        "role_ids": user.role_ids or [],
        "permissions": permissions,
    }

    access_token = create_access_token(token_data)
    refresh_token = create_refresh_token(token_data)

    db.commit()

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user": user,
        "permissions": permissions,
    }


def refresh_access_token(db: Session, refresh_token_str: str) -> dict:
    """Refresh an access token using a valid refresh token."""
    try:
        payload = decode_token(refresh_token_str)
    except jwt.ExpiredSignatureError:
        raise ValueError("刷新令牌已过期，请重新登录")
    except jwt.PyJWTError:
        raise ValueError("无效的刷新令牌")

    if payload.get("type") != "refresh":
        raise ValueError("无效的令牌类型")

    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    if not user or not user.is_active:
        raise ValueError("用户不存在或已被禁用")

    role_names = get_role_names_by_ids(db, user.role_ids)
    permissions = get_permissions_for_roles(role_names)

    token_data = {
        "sub": user.id,
        "uid": user.uid,
        "role_ids": user.role_ids or [],
        "permissions": permissions,
    }

    new_access_token = create_access_token(token_data)

    return {
        "access_token": new_access_token,
        "token_type": "bearer",
    }


def logout() -> dict:
    """Logout (stateless — client just discards token)."""
    return {"message": "退出成功"}
