import uuid
from datetime import datetime, timezone
from typing import Optional, Tuple, List

from sqlalchemy.orm import Session

from app.models.api_key import ApiKey
from app.core.security import generate_api_key, hash_api_key, mask_api_key

MAX_API_KEYS_PER_USER = 20


def count_user_keys(db: Session, user_id: str) -> int:
    """Count the number of API keys owned by a user."""
    return db.query(ApiKey).filter(ApiKey.user_id == user_id).count()


def create_api_key(
    db: Session, user_id: str, name: str
) -> Tuple[ApiKey, str]:
    """Create a new API key for the user.

    Returns:
        Tuple of (ApiKey model instance, full secret key string).
    Raises:
        ValueError if the user has reached the key limit or name is blank.
    """
    name = name.strip()
    if not name:
        raise ValueError("API key 名称不能为空")

    if count_user_keys(db, user_id) >= MAX_API_KEYS_PER_USER:
        raise ValueError(f"API key 数量已达上限（最多 {MAX_API_KEYS_PER_USER} 个）")

    secret = generate_api_key()
    key_hash = hash_api_key(secret)
    masked = mask_api_key(secret)

    api_key = ApiKey(
        id=str(uuid.uuid4()),
        user_id=user_id,
        name=name,
        key_hash=key_hash,
        masked_key=masked,
        created_at=datetime.now(timezone.utc),
    )
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return api_key, secret


def list_api_keys(
    db: Session, user_id: str, page: int = 1, page_size: int = 10
) -> Tuple[List[ApiKey], int]:
    """List API keys for a user with pagination, ordered by created_at DESC."""
    query = db.query(ApiKey).filter(ApiKey.user_id == user_id)
    total = query.count()
    items = (
        query.order_by(ApiKey.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return items, total


def update_api_key_name(
    db: Session, key_id: str, user_id: str, name: str
) -> Optional[ApiKey]:
    """Update the name of an API key. Returns None if not found or not owned."""
    name = name.strip()
    if not name:
        raise ValueError("API key 名称不能为空")

    api_key = (
        db.query(ApiKey)
        .filter(ApiKey.id == key_id, ApiKey.user_id == user_id)
        .first()
    )
    if not api_key:
        return None

    api_key.name = name
    db.commit()
    db.refresh(api_key)
    return api_key


def delete_api_key(db: Session, key_id: str, user_id: str) -> bool:
    """Physically delete an API key. Returns True if deleted, False if not found."""
    api_key = (
        db.query(ApiKey)
        .filter(ApiKey.id == key_id, ApiKey.user_id == user_id)
        .first()
    )
    if not api_key:
        return False

    db.delete(api_key)
    db.commit()
    return True


def verify_api_key(db: Session, key: str) -> Optional[ApiKey]:
    """Verify an API key by hashing it and looking up the hash.

    If found, updates last_used_at and returns the ApiKey record.
    Returns None if the key is invalid.
    """
    key_hash = hash_api_key(key)
    api_key = db.query(ApiKey).filter(ApiKey.key_hash == key_hash).first()
    if api_key:
        api_key.last_used_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(api_key)
    return api_key
