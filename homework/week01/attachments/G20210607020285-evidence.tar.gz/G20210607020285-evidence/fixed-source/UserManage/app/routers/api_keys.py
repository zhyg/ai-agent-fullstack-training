from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.schemas.api_key import (
    ApiKeyCreateRequest,
    ApiKeyCreateResponse,
    ApiKeyUpdateRequest,
    ApiKeyResponse,
    PaginatedApiKeyResponse,
    ApiKeyVerifyRequest,
    ApiKeyVerifyResponse,
)
from app.services import api_key_service

router = APIRouter(prefix="/api-keys", tags=["API Key 管理"])


@router.post("", response_model=ApiKeyCreateResponse, status_code=status.HTTP_201_CREATED)
async def create_api_key(
    body: ApiKeyCreateRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """创建 API Key，返回完整密钥（仅此一次）。"""
    try:
        api_key, secret = api_key_service.create_api_key(
            db, current_user["id"], body.name
        )
        return ApiKeyCreateResponse(
            id=api_key.id,
            name=api_key.name,
            masked_key=api_key.masked_key,
            secret=secret,
            created_at=api_key.created_at,
            last_used_at=api_key.last_used_at,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("", response_model=PaginatedApiKeyResponse)
async def list_api_keys(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """获取当前用户的 API Key 列表（分页）。"""
    items, total = api_key_service.list_api_keys(
        db, current_user["id"], page, page_size
    )
    return PaginatedApiKeyResponse(
        items=[ApiKeyResponse.model_validate(k) for k in items],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.put("/{key_id}", response_model=ApiKeyResponse)
async def update_api_key_name(
    key_id: str,
    body: ApiKeyUpdateRequest,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """修改 API Key 名称。"""
    try:
        api_key = api_key_service.update_api_key_name(
            db, key_id, current_user["id"], body.name
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="API key 不存在或无权操作"
        )
    return ApiKeyResponse.model_validate(api_key)


@router.delete("/{key_id}")
async def delete_api_key(
    key_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除 API Key（物理删除，不可恢复）。"""
    ok = api_key_service.delete_api_key(db, key_id, current_user["id"])
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="API key 不存在或无权操作"
        )
    return {"message": "API key 已删除"}


@router.post("/verify", response_model=ApiKeyVerifyResponse)
async def verify_api_key(
    body: ApiKeyVerifyRequest,
    db: Session = Depends(get_db),
):
    """内部端点：验证 API Key 是否有效（供 LLM Gateway 调用）。"""
    api_key = api_key_service.verify_api_key(db, body.key)
    if api_key:
        user = db.query(User).filter(User.id == api_key.user_id).first()
        return ApiKeyVerifyResponse(
            valid=True,
            key_id=api_key.id,
            user_id=api_key.user_id,
            user_email=user.email if user else None,
        )
    return ApiKeyVerifyResponse(valid=False)
