from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from datetime import datetime


# --- Requests ---

class ApiKeyCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="API Key 名称")


class ApiKeyUpdateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="API Key 名称")


class ApiKeyVerifyRequest(BaseModel):
    key: str = Field(..., min_length=1, description="完整 API Key")


# --- Responses ---

class ApiKeyCreateResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    masked_key: str
    secret: str  # 仅创建时返回完整密钥
    created_at: datetime
    last_used_at: Optional[datetime] = None


class ApiKeyResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    masked_key: str
    created_at: datetime
    last_used_at: Optional[datetime] = None


class PaginatedApiKeyResponse(BaseModel):
    items: List[ApiKeyResponse]
    total: int
    page: int
    page_size: int


class ApiKeyVerifyResponse(BaseModel):
    valid: bool
    key_id: Optional[str] = None
    user_id: Optional[str] = None
    user_email: Optional[str] = None
