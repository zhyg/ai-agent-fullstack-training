"""Predefined permissions and role-permission mapping."""

# Predefined permission items
PREDEFINED_PERMISSIONS = [
    {"key": "prompt_manage", "label": "提示词管理"},
    {"key": "chat_manage", "label": "会话管理"},
    {"key": "model_manage", "label": "模型管理"},
    {"key": "permission_manage", "label": "权限管理"},
]

# Default role permissions
DEFAULT_ROLE_PERMISSIONS = {
    "admin": ["prompt_manage", "chat_manage", "model_manage", "permission_manage"],
    "user": ["prompt_manage", "chat_manage"],
}


def get_permissions_for_roles(role_names: list[str]) -> list[str]:
    """Get aggregated permission keys for a list of role names."""
    permissions = set()
    for role_name in role_names:
        perms = DEFAULT_ROLE_PERMISSIONS.get(role_name, [])
        permissions.update(perms)
    return sorted(permissions)
