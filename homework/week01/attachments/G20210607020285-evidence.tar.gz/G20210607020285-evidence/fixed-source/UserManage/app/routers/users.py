from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import require_permission
from app.schemas.user import (
    UserCreateRequest,
    UserUpdateRequest,
    UserResponse,
    PaginatedUserResponse,
)
from app.services import user_service
from app.dependencies import get_current_user

router = APIRouter(prefix="/users", tags=["用户管理"])


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get user by ID (internal service call, any authenticated user)."""
    user = user_service.get_user_by_id(db, user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="用户不存在")
    return UserResponse.model_validate(user)


@router.get("", response_model=PaginatedUserResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """获取用户列表"""
    items, total = user_service.list_users(db, page, page_size)
    return {
        "items": [UserResponse.model_validate(u) for u in items],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    body: UserCreateRequest,
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """创建用户"""
    try:
        user = user_service.create_user(db, body)
        return UserResponse.model_validate(user)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    body: UserUpdateRequest,
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """修改用户信息"""
    try:
        user = user_service.update_user(db, user_id, body)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="用户不存在")
        return UserResponse.model_validate(user)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.delete("/{user_id}")
async def delete_user(
    user_id: str,
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """删除用户"""
    ok = user_service.delete_user(db, user_id)
    if not ok:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="用户不存在")
    return {"message": "用户删除成功"}
