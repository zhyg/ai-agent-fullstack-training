import uuid
from datetime import datetime, timezone
from typing import Optional, List, Tuple

from sqlalchemy.orm import Session

from app.models.role import Role
from app.models.user import User
from app.schemas.role import RoleCreateRequest, RoleUpdateRequest


def list_roles(db: Session) -> Tuple[List[Role], int]:
    """List all roles."""
    items = db.query(Role).order_by(Role.created_at.asc()).all()
    return items, len(items)


def create_role(db: Session, req: RoleCreateRequest) -> Role:
    """Create a new role."""
    existing = db.query(Role).filter(Role.name == req.name).first()
    if existing:
        raise ValueError("角色名已存在")

    role = Role(
        id=str(uuid.uuid4()),
        name=req.name,
        description=req.description,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    db.add(role)
    db.commit()
    db.refresh(role)
    return role


def update_role(
    db: Session, role_id: str, req: RoleUpdateRequest
) -> Optional[Role]:
    """Update a role."""
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        return None

    if req.name is not None:
        existing = db.query(Role).filter(Role.name == req.name, Role.id != role_id).first()
        if existing:
            raise ValueError("角色名已存在")
        role.name = req.name

    if req.description is not None:
        role.description = req.description

    role.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(role)
    return role


def delete_role(db: Session, role_id: str) -> Tuple[bool, Optional[str]]:
    """Delete a role. Reject if role has assigned users."""
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        return False, None

    # Check if any users have this role
    users_with_role = (
        db.query(User)
        .filter(User.role_ids.contains([role_id]))
        .first()
    )
    if users_with_role:
        return False, "该角色已分配给用户，请先解除关联后再删除"

    db.delete(role)
    db.commit()
    return True, None
