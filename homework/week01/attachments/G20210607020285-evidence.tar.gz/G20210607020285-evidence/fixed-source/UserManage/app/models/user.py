import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, Boolean, TIMESTAMP, Index, Text
from sqlalchemy.dialects.postgresql import JSON

from app.core.database import Base
from app.core.config import settings


class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        Index("idx_users_uid", "uid"),
        Index("idx_users_email", "email"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    uid = Column(String(50), unique=True, nullable=False, comment="用户名，3-20 字符")
    email = Column(String(100), unique=True, nullable=False, comment="邮箱")
    password = Column(String(255), nullable=False, comment="bcrypt 哈希密码")
    role_ids = Column(JSON, nullable=False, default=list, comment="关联角色 ID 列表")
    login_fail_count = Column(Integer, nullable=False, default=0, comment="连续登录失败次数")
    locked_until = Column(TIMESTAMP, nullable=True, comment="锁定截止时间")
    is_active = Column(Boolean, nullable=False, default=True, comment="账户是否激活")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )
