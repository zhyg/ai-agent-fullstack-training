from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.dependencies import require_permission
from app.schemas.role import (
    RoleCreateRequest,
    RoleUpdateRequest,
    RoleResponse,
    PaginatedRoleResponse,
)
from app.services import role_service

router = APIRouter(prefix="/roles", tags=["角色管理"])


@router.get("", response_model=PaginatedRoleResponse)
async def list_roles(
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """获取角色列表"""
    items, total = role_service.list_roles(db)
    return {
        "items": [RoleResponse.model_validate(r) for r in items],
        "total": total,
        "page": 1,
        "page_size": total,
    }


@router.post("", response_model=RoleResponse, status_code=status.HTTP_201_CREATED)
async def create_role(
    body: RoleCreateRequest,
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """创建角色"""
    try:
        role = role_service.create_role(db, body)
        return RoleResponse.model_validate(role)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.put("/{role_id}", response_model=RoleResponse)
async def update_role(
    role_id: str,
    body: RoleUpdateRequest,
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """修改角色"""
    try:
        role = role_service.update_role(db, role_id, body)
        if not role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="角色不存在")
        return RoleResponse.model_validate(role)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.delete("/{role_id}")
async def delete_role(
    role_id: str,
    current_user: dict = Depends(require_permission("permission_manage")),
    db: Session = Depends(get_db),
):
    """删除角色"""
    ok, error_msg = role_service.delete_role(db, role_id)
    if not ok:
        detail = error_msg or "角色不存在"
        code = status.HTTP_400_BAD_REQUEST if error_msg else status.HTTP_404_NOT_FOUND
        raise HTTPException(status_code=code, detail=detail)
    return {"message": "角色删除成功"}
