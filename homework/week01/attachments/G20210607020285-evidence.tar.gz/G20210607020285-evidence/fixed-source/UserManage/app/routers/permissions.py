from fastapi import APIRouter

from app.core.permissions import PREDEFINED_PERMISSIONS

router = APIRouter(tags=["权限"])


@router.get("/permissions")
async def list_permissions():
    """获取预定义权限项列表"""
    return {"items": PREDEFINED_PERMISSIONS}
