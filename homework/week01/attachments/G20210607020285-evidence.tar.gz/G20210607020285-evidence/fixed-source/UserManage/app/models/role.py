import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, TIMESTAMP

from app.core.database import Base
from app.core.config import settings


class Role(Base):
    __tablename__ = "roles"
    __table_args__ = (
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(50), unique=True, nullable=False, comment="角色名")
    description = Column(String(200), default="", comment="角色描述")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at = Column(
        TIMESTAMP, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )
