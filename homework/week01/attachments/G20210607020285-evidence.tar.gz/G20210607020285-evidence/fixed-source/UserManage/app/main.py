import uuid
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import init_schema, SessionLocal
from app.core.security import hash_password
from app.models.user import User
from app.models.role import Role
from app.routers import auth, users, roles, permissions, api_keys

logger = logging.getLogger(__name__)


def seed_default_data():
    """Seed default admin/user roles and admin account if they don't exist."""
    db = SessionLocal()
    try:
        # Create default roles
        admin_role = db.query(Role).filter(Role.name == "admin").first()
        if not admin_role:
            admin_role = Role(
                id=str(uuid.uuid4()),
                name="admin",
                description="系统管理员",
            )
            db.add(admin_role)
            logger.info("Created default admin role")

        user_role = db.query(Role).filter(Role.name == "user").first()
        if not user_role:
            user_role = Role(
                id=str(uuid.uuid4()),
                name="user",
                description="普通用户",
            )
            db.add(user_role)
            logger.info("Created default user role")

        db.commit()

        # Create default admin user
        admin_user = db.query(User).filter(User.uid == "admin").first()
        if not admin_user:
            admin_user = User(
                id=str(uuid.uuid4()),
                uid="admin",
                email="admin@example.com",
                password=hash_password("admin123"),
                role_ids=[admin_role.id],
                login_fail_count=0,
                is_active=True,
            )
            db.add(admin_user)
            db.commit()
            logger.info("Created default admin user (uid: admin, password: admin123)")

    except Exception as e:
        db.rollback()
        logger.error(f"Failed to seed default data: {e}")
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown lifecycle."""
    logger.info("Initializing UserManage service...")
    init_schema()
    seed_default_data()
    logger.info("UserManage service started")
    yield
    logger.info("UserManage service shutting down")


app = FastAPI(
    title="UserManage Service",
    description="用户管理服务 - 开发者门户平台",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(auth.router, prefix="/api/user")
app.include_router(users.router, prefix="/api/user")
app.include_router(roles.router, prefix="/api/user")
app.include_router(permissions.router, prefix="/api/user")
app.include_router(api_keys.router, prefix="/api/user")


@app.get("/api/user/health")
async def health_check():
    return {"status": "ok", "service": "UserManage"}
