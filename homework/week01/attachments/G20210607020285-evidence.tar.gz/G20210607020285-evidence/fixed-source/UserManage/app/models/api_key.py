import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, ForeignKey, Index, TIMESTAMP

from app.core.database import Base
from app.core.config import settings


class ApiKey(Base):
    __tablename__ = "api_keys"
    __table_args__ = (
        Index("idx_api_keys_user_id", "user_id"),
        Index("idx_api_keys_key_hash", "key_hash"),
        {"schema": settings.database.db_schema},
    )

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(
        String(36),
        ForeignKey(f"{settings.database.db_schema}.users.id", ondelete="CASCADE"),
        nullable=False,
    )
    name = Column(String(100), nullable=False, comment="用户自定义的 Key 名称")
    key_hash = Column(String(64), nullable=False, comment="SHA-256 哈希值，用于验证")
    masked_key = Column(String(50), nullable=False, comment="脱敏版本，如 [REDACTED_KEY]...WxYz")
    created_at = Column(
        TIMESTAMP, nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    last_used_at = Column(
        TIMESTAMP, nullable=True, comment="最后使用时间，初始为 NULL"
    )
