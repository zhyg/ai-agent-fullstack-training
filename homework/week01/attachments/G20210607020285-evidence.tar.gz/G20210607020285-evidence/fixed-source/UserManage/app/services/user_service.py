import uuid
from datetime import datetime, timezone
from typing import Optional, List, Tuple

from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.models.user import User
from app.models.role import Role
from app.core.security import hash_password
from app.schemas.user import RegisterRequest, UserCreateRequest, UserUpdateRequest


def get_user_by_uid(db: Session, uid: str) -> Optional[User]:
    """Find a user by username."""
    schema = db.bind.dialect.default_schema_name or "public"
    return db.query(User).filter(User.uid == uid).first()


def get_user_by_email(db: Session, email: str) -> Optional[User]:
    """Find a user by email."""
    return db.query(User).filter(User.email == email).first()


def get_user_by_id(db: Session, user_id: str) -> Optional[User]:
    """Find a user by ID."""
    return db.query(User).filter(User.id == user_id).first()


def get_role_names_by_ids(db: Session, role_ids: list[str]) -> list[str]:
    """Get role names from role IDs."""
    if not role_ids:
        return []
    roles = db.query(Role).filter(Role.id.in_(role_ids)).all()
    return [r.name for r in roles]


def register_user(db: Session, req: RegisterRequest) -> User:
    """Register a new user with bcrypt password hashing."""
    # Check uniqueness
    existing = db.query(User).filter(
        or_(User.uid == req.uid, User.email == req.email)
    ).first()
    if existing:
        if existing.uid == req.uid:
            raise ValueError("用户名已存在")
        raise ValueError("邮箱已被注册")

    # Find default 'user' role
    default_role = db.query(Role).filter(Role.name == "user").first()
    role_ids = [default_role.id] if default_role else []

    user = User(
        id=str(uuid.uuid4()),
        uid=req.uid,
        email=req.email,
        password=hash_password(req.password),
        role_ids=role_ids,
        login_fail_count=0,
        is_active=True,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_user(db: Session, req: UserCreateRequest) -> User:
    """Admin create user with optional role assignment."""
    existing = db.query(User).filter(
        or_(User.uid == req.uid, User.email == req.email)
    ).first()
    if existing:
        if existing.uid == req.uid:
            raise ValueError("用户名已存在")
        raise ValueError("邮箱已被注册")

    role_ids = req.role_ids if req.role_ids else []
    if not role_ids:
        default_role = db.query(Role).filter(Role.name == "user").first()
        role_ids = [default_role.id] if default_role else []

    user = User(
        id=str(uuid.uuid4()),
        uid=req.uid,
        email=req.email,
        password=hash_password(req.password),
        role_ids=role_ids,
        login_fail_count=0,
        is_active=True,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def list_users(
    db: Session, page: int = 1, page_size: int = 20
) -> Tuple[List[User], int]:
    """List all users with pagination."""
    query = db.query(User)
    total = query.count()
    items = (
        query.order_by(User.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return items, total


def update_user(
    db: Session, user_id: str, req: UserUpdateRequest
) -> Optional[User]:
    """Update user info and/or role assignments."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return None

    if req.uid is not None:
        existing = db.query(User).filter(User.uid == req.uid, User.id != user_id).first()
        if existing:
            raise ValueError("用户名已存在")
        user.uid = req.uid

    if req.email is not None:
        existing = db.query(User).filter(User.email == req.email, User.id != user_id).first()
        if existing:
            raise ValueError("邮箱已被注册")
        user.email = req.email

    if req.password is not None:
        user.password = hash_password(req.password)

    if req.role_ids is not None:
        user.role_ids = req.role_ids

    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    return user


def delete_user(db: Session, user_id: str) -> bool:
    """Delete a user. Their prompts/chats retain creator_id/user_id."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return False
    db.delete(user)
    db.commit()
    return True
