from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from datetime import datetime


class RoleCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=50, description="角色名")
    description: str = Field("", max_length=200, description="角色描述")


class RoleUpdateRequest(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=50)
    description: Optional[str] = Field(None, max_length=200)


class RoleResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    description: str
    created_at: datetime


class PaginatedRoleResponse(BaseModel):
    items: List[RoleResponse]
    total: int
    page: int
    page_size: int
