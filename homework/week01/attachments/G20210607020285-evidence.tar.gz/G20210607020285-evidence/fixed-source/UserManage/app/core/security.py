import jwt
import bcrypt
import hashlib
import secrets
import string
from datetime import datetime, timedelta, timezone
from typing import Optional

from app.core.config import settings


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against a bcrypt hash."""
    return bcrypt.checkpw(
        plain_password.encode('utf-8'),
        hashed_password.encode('utf-8')
    )


def create_access_token(
    data: dict,
    expires_delta: Optional[timedelta] = None
) -> str:
    """Create a JWT access token."""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta
        or timedelta(minutes=settings.jwt.access_token_expire_minutes)
    )
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(
        to_encode,
        settings.jwt.secret_key,
        algorithm=settings.jwt.algorithm
    )


def create_refresh_token(
    data: dict,
    expires_delta: Optional[timedelta] = None
) -> str:
    """Create a JWT refresh token."""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta
        or timedelta(days=settings.jwt.refresh_token_expire_days)
    )
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(
        to_encode,
        settings.jwt.secret_key,
        algorithm=settings.jwt.algorithm
    )


def decode_token(token: str) -> dict:
    """Decode and verify a JWT token. Raises jwt.PyJWTError on failure."""
    return jwt.decode(
        token,
        settings.jwt.secret_key,
        algorithms=[settings.jwt.algorithm]
    )


# --- API Key helpers ---

_API_KEY_CHARS = string.ascii_letters + string.digits
_API_KEY_LENGTH = 32
_API_KEY_PREFIX = "sk-"


def generate_api_key() -> str:
    """Generate a cryptographically secure API key: sk- + 32 random chars."""
    random_part = "".join(secrets.choice(_API_KEY_CHARS) for _ in range(_API_KEY_LENGTH))
    return f"{_API_KEY_PREFIX}{random_part}"


def hash_api_key(key: str) -> str:
    """Return the SHA-256 hex digest of the given API key."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def mask_api_key(key: str) -> str:
    """Return a masked version: sk-{first 8 chars after prefix}...{last 4 chars}."""
    # key format: [REDACTED_KEY]
    body = key[len(_API_KEY_PREFIX):]  # strip prefix
    return f"{_API_KEY_PREFIX}{body[:8]}...{body[-4:]}"
