import pathlib,subprocess,json,os,re,hashlib,shutil,yaml,tarfile
R=pathlib.Path('/tmp/vita-grading');S=R/'submission';E=R/'evidence';E.mkdir(exist_ok=True)
private_values=set()
def redact_config(value):
    if isinstance(value,dict):
        output={}
        for key,item in value.items():
            if re.search(r'api_key|secret_key|fernet_key|password|access_token|refresh_token|authorization',key,re.I) and isinstance(item,str) and item:
                private_values.add(item)
                if item.startswith('Bearer '):private_values.add(item[7:])
                output[key]='[REDACTED]'
            else:output[key]=redact_config(item)
        return output
    if isinstance(value,list):return [redact_config(item) for item in value]
    return value
sanitized_configs={service:redact_config(yaml.safe_load((S/service/'config.teacher.yaml').read_text())) for service in ('UserManage','KnowledgeManage','LlmGateway')}
redact_config(json.loads((R/'runtime-auth.json').read_text()))
def clean(s):
    for key in sorted(private_values | {os.environ.get('DEEPSEEK_API_KEY','')},key=len,reverse=True):
        if key:s=s.replace(key,'[REDACTED]')
    s=re.sub(r'sk-[A-Za-z0-9_-]{8,}','[REDACTED_KEY]',s)
    s=re.sub(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+','[REDACTED_JWT]',s)
    s=re.sub(r'\x1b\[[0-9;]*m','',s)
    return s
files=['clone.log','install.log','student-unittest.log','docx-extracted.txt','docx-link-audit.json','teacher-results.json','teacher-run.log','supplement-results.json','supplement-run.log','assertions.json','check_results.py','check-results.log','package.py','services-stopped.log','services-final.log','gateway-raw.log','test_rpm_rate_limit.sh.log','test_tpm_rate_limit.sh.log','student-injected-failure.log','setup.py','seed.py','mock_upstream.py','verify.py','supplement.py','migration-UserManage.log','migration-KnowledgeManage.log','migration-LlmGateway.log','source-unchanged.log']
for n in files:
    (E/n.replace('gateway-raw','gateway-sanitized')).write_text(clean((R/n).read_text()))
manifest=[]
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=S,text=True).splitlines()
for p in paths:
    if p.startswith(('LlmGateway/','KnowledgeManage/','UserManage/')) and (p.endswith(('.py','.sh','requirements.txt','README.md'))):
        raw=subprocess.check_output(['git','show','HEAD:'+p],cwd=S)
        target=E/'fixed-source'/p;target.parent.mkdir(parents=True,exist_ok=True)
        text=raw.decode();sanitized=clean(text)
        target.write_text(sanitized)
        manifest.append({'path':p,'original_sha256':hashlib.sha256(raw).hexdigest(),'redacted':text!=sanitized})
raw=subprocess.check_output(['git','show','HEAD:quickstart.md'],cwd=S)
(E/'fixed-source/quickstart.md').write_text(clean(raw.decode()))
(E/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
(E/'source-tree.txt').write_text(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=S,text=True))
for service,config in sanitized_configs.items():
    (E/(service+'-teacher-sanitized.yaml')).write_text(clean(yaml.safe_dump(config)))
records=[]
for line in (R/'gateway-raw.log').read_text().splitlines():
    if 'llm_invocation: ' in line:
        records.append(json.loads(line.split('llm_invocation: ',1)[1]))
(E/'invocation-ledger.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
(E/'versions.txt').write_text(subprocess.check_output(['uv','pip','freeze','--python',str(R/'venv/bin/python')],text=True))
(E/'numbered-source.txt').write_text('\n'.join('\n### '+p+'\n'+'\n'.join(f'{i:4} {l}' for i,l in enumerate((E/'fixed-source'/p).read_text().splitlines(),1)) for p in ['LlmGateway/app/services/llm_gateway_service.py','LlmGateway/app/adapters/openai_adapter.py','LlmGateway/app/adapters/anthropic_adapter.py','LlmGateway/app/gateway/json_repair.py','LlmGateway/app/gateway/retry.py','LlmGateway/app/gateway/sse.py','LlmGateway/app/routers/v1_chat.py','LlmGateway/app/schemas/chat_completion.py','LlmGateway/tests/test_completion_retry.py']))
# Never include runtime-auth.json, private configs, database files, original DOCX or screenshots.
bad=[]
for p in E.rglob('*'):
    if p.is_file():
        s=p.read_text()
        if any(value and value in s for value in private_values | {os.environ.get('DEEPSEEK_API_KEY','')}):bad.append(str(p))
        if re.search(r'sk-[A-Za-z0-9_-]{8,}|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',s):bad.append(str(p))
assert not bad,bad
(E/'secret-scan.txt').write_text('PASS: exact live credential, all private config credential values, runtime authentication tokens, sk-style keys and JWT scan; no private configs/auth/DB/docx images archived.\n')
print('Sanitized evidence staged:',len(list(E.rglob('*'))),'entries')
