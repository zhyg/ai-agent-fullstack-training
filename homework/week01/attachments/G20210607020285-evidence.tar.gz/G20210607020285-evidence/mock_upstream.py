import asyncio, time
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
app=FastAPI()
state={'mode':'good','calls':[]}
gate=asyncio.Event()
@app.post('/control')
async def control(r:Request):
    state.update(await r.json());state['calls']=[];gate.clear()
    return {'ok':True}
@app.get('/state')
async def read(): return state
@app.post('/release')
async def release(): gate.set();return {'ok':True}
@app.post('/{path:path}')
async def upstream(path:str,r:Request):
    b=await r.json(); mode=state['mode']
    state['calls'].append({'path':'/'+path,'body':b,'header_names':sorted(r.headers.keys()),'at':time.monotonic()})
    n=len(state['calls'])
    if mode=='bad400': return JSONResponse({'error':{'message':'bad parameter'}},status_code=400)
    if mode=='fail500' or (mode=='retry' and n<=2): return JSONResponse({'error':{'message':'controlled temporary failure'}},status_code=500)
    anth=path.endswith('messages')
    text={'invalid':'not json','empty':'','truncated':'{"x":','schema':'{"x":"WRONG","n":99}','repair':'prefix {"x":"ok","n":2} suffix'}.get(mode,'{"x":"ok","n":2}')
    if not b.get('stream'):
        if anth:return {'content':[{'type':'text','text':text}],'stop_reason':'max_tokens' if mode=='truncated' else 'end_turn','usage':{'input_tokens':13,'output_tokens':7,'cache_read_input_tokens':3}}
        return {'choices':[{'message':{'content':text},'finish_reason':'length' if mode=='truncated' else 'stop'}],'usage':{'prompt_tokens':13,'completion_tokens':7,'total_tokens':20,'prompt_tokens_details':{'cached_tokens':3},'completion_tokens_details':{'reasoning_tokens':2}}}
    def event(d):return 'data: '+__import__('json').dumps(d)+'\n\n'
    async def chunks():
        if mode=='timed':
            yield ': heartbeat\n\n'
            await asyncio.sleep(0.4)
        if anth:
            yield event({'type':'message_start','message':{'usage':{'input_tokens':13,'output_tokens':0,'cache_read_input_tokens':3}}})
            yield event({'type':'content_block_delta','delta':{'type':'text_delta','text':'FIRST'}})
        else:
            yield event({'choices':[{'delta':{'content':'FIRST'}}]})
        if mode in ('gate','errorstream','eof','transport'):await asyncio.wait_for(gate.wait(),10)
        if mode=='transport':raise RuntimeError('controlled transport interruption')
        if mode=='timed':await asyncio.sleep(0.3)
        if mode=='eof':return
        if mode=='errorstream':
            yield event({'type':'error','error':{'type':'overloaded_error','message':'controlled midstream failure'}})
            return
        if anth:
            yield event({'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':7}})
            yield event({'type':'message_stop'})
        else:
            yield event({'choices':[],'usage':{'prompt_tokens':13,'completion_tokens':7,'total_tokens':20}})
            yield 'data: [DONE]\n\n'
    return StreamingResponse(chunks(),media_type='text/event-stream')
