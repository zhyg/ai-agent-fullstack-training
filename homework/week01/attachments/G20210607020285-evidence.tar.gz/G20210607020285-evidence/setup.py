import pathlib, yaml, secrets
from cryptography.fernet import Fernet
root=pathlib.Path('/tmp/vita-grading/submission')
key=Fernet.generate_key().decode()
jwt=secrets.token_urlsafe(32)
for service,schema,port in [('UserManage','user_manage',18001),('KnowledgeManage','knowledge_manage',18002),('LlmGateway','llm_gateway',18003)]:
    data=yaml.safe_load((root/service/'config.dev.yaml').read_text())
    data['database']={'url':'postgresql://postgres@127.0.0.1:55432/vita','schema':schema,'echo':False}
    data['server']={'host':'127.0.0.1','port':port}
    data['jwt']['secret_key']=jwt
    data['encryption']={'fernet_key':key}
    data['redis']={'host':'127.0.0.1','port':56379,'db':0}
    data['services']={'user_manage':'http://127.0.0.1:18001','knowledge_manage':'http://127.0.0.1:18002','llm_gateway':'http://127.0.0.1:18003'}
    data['provider_timeout']=20
    (root/service/'config.teacher.yaml').write_text(yaml.safe_dump(data))
    (root/service/'config.teacher.yaml').chmod(0o600)
