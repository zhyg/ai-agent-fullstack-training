"""Inject only an upstream HTTP failure to demonstrate student assertions detect faults."""
import httpx
import pytest

@pytest.fixture(autouse=True)
def injected_upstream_500(monkeypatch):
    async def failed(self, request):
        return httpx.Response(500, json={'error':{'message':'teacher F12 injected upstream failure'}})
    monkeypatch.setattr(httpx.MockTransport, 'handle_async_request', failed)
