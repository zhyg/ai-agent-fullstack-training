"""A larger output budget is a control, not a student-code change."""
import asyncio
import json
import os
from pathlib import Path
import httpx
from app.main import create_app
from teacher import config, body, RecordingTransport

async def main():
    cfg=config(database_url='/tmp/grading-G20261786020012/json-control.db',
        providers={'p':{'base_url':'https://api.deepseek.com','api_key':os.environ['DEEPSEEK_API_KEY'],'timeout_seconds':25}},
        models={'fast':{'routes':[{'provider':'p','model':'deepseek-flash','api':'both'}]}},
        retry={'max_attempts_per_route':1})
    t=RecordingTransport()
    async with httpx.AsyncClient(transport=t) as up:
        app=create_app(cfg,http_client=up)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://teacher.test') as c:
                r=await c.post('/v1/responses',json=body('responses',max_output_tokens=256,text={'format':{'type':'json_object'}},thinking={'type':'disabled'}))
                data=r.json()
                text=''.join(z.get('text','') for x in data.get('output',[]) for z in x.get('content',[]) if z.get('type')=='output_text')
                try: parsed=json.loads(text); valid=True
                except ValueError: parsed=None; valid=False
                output={'status':r.status_code,'request_id':r.headers.get('x-request-id'),'response':data,
                    'valid_model_json':valid,'parsed':parsed,'calls':t.calls,'usage':(await c.get('/admin/usage')).json()['data']}
                Path(__file__).with_name('real-json-control-results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
                print(json.dumps(output,ensure_ascii=False))

asyncio.run(main())
