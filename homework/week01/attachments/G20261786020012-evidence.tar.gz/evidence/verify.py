"""Check reports and actual secret bytes without printing secret values."""
import io
import os
from pathlib import Path
import re
import subprocess
import tarfile

ROOT=Path('/home/user/workspace/repo')
E=Path(__file__).parent
feedback=ROOT/'homework/week01/G20261786020012.md'
attachment=ROOT/'homework/week01/attachments/G20261786020012.md'
archive=attachment.with_name('G20261786020012-evidence.tar.gz')
messages=[]
text=feedback.read_text()
for heading in ('2. 作业优点','3. 作业不足','4. 改进方案'):
    section=text.split('**'+heading+'**\n\n')[1].split('\n**')[0]
    items=[line[2:] for line in section.splitlines() if line.startswith('- ')]
    count=sum(len(x) for x in items)
    assert 3<=len(items)<=5 and count<=500, (heading,len(items),count)
    messages.append(f'{heading}: {len(items)} items, {count} characters PASS')
scores=[(11,15),(13,15),(7,10),(10,10),(11,15),(13,15),(6,10),(10,10)]
assert sum(a for a,b in scores)==81 and sum(b-a for a,b in scores)==19
assert '优秀（81分）' in text and '**81/100**' in attachment.read_text()
for i in range(1,5): assert f'| A{i:02} |' in attachment.read_text()
for i in range(1,13): assert f'| F{i:02} |' in attachment.read_text()
messages.append('Eight scores sum to 81; deductions 19; grade and A/F coverage PASS')
secrets=[(name,value.encode()) for name,value in os.environ.items()
         if re.search(r'KEY|TOKEN|PASSWORD|SECRET',name,re.I) and len(value)>=16
         and name != 'AMP_SECRET_ENV_NAMES']  # Names-only metadata is not a credential value.
assert any(name=='DEEPSEEK_API_KEY' for name,_ in secrets)
blobs=[(str(p.relative_to(E)),p.read_bytes()) for p in E.rglob('*') if p.is_file()]
blobs.extend([(str(feedback),feedback.read_bytes()),(str(attachment),attachment.read_bytes())])
for filename,data in blobs:
    assert not any(value in data for name,value in secrets), f'actual credential detected in {filename}'
    assert not re.search(rb'sk-[a-zA-Z0-9_-]{24,}',data), f'key-shaped value detected in {filename}'
messages.append(f'Actual sensitive environment values (including DEEPSEEK_API_KEY) and key patterns: {len(blobs)} files PASS; values not printed')
# Source snapshot must equal the fixed Git object, not modified working copies.
student=Path('/tmp/student-G20261786020012')
for p in (E/'source/01').rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(E/'source').as_posix()
    original=subprocess.check_output(['git','show',f'f529a9c209d864d775fabd859a667ec602b13cb6:{rel}'],cwd=student)
    assert p.read_bytes()==original, rel
assert not subprocess.check_output(['git','status','--porcelain'],cwd=student).strip()
messages.append('Fixed source snapshot and untouched student worktree PASS')
if archive.exists():
    count=0
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            if not member.isfile(): continue
            data=tar.extractfile(member).read()
            assert not any(value in data for name,value in secrets), f'credential in archive member {member.name}'
            assert not re.search(rb'sk-[a-zA-Z0-9_-]{24,}',data), f'key pattern in archive member {member.name}'
            count+=1
    messages.append(f'Decompressed archive scan: {count} files PASS')
print('\n'.join(messages))
