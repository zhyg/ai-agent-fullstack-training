"""Teacher harness; never modifies student code. Run from 01 with PYTHONPATH=.:evidence."""
import asyncio
import contextlib
import json
import os
import random
import sys
import time
from pathlib import Path

import httpx
import uvicorn
from app.config import GatewayConfig
from app.main import create_app

OUT = Path(__file__).parent
RESULTS = []
SEQ = 0

def record(name, **values):
    RESULTS.append(dict(case=name, **values))
    filename = 'extra-real-results.json' if '--extra-real' in sys.argv else ('real-results.json' if '--real' in sys.argv else 'teacher-results.json')
    (OUT / filename).write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2))
    print(name, json.dumps(values, ensure_ascii=False), flush=True)

def config(**overrides):
    global SEQ
    SEQ += 1
    raw = dict(database_url=f'/tmp/grading-G20261786020012/case-{SEQ}.db',
        rate_limit={'enabled': False}, retry={'max_attempts_per_route': 3,
        'base_delay_seconds': .04, 'max_delay_seconds': .2},
        circuit_breaker={'failure_threshold': 100}, structured_output_retries=1,
        providers={'p': {'base_url': 'https://mock.test'}},
        models={m: {'routes': [{'provider': 'p', 'model': 'up-'+m, 'api': api}]}
                for m, api in [('smart','chat'), ('fast','responses')]})
    raw.update(overrides)
    return GatewayConfig.model_validate(raw)

def body(api='chat', model=None, **extra):
    b = {'model': model or ('smart' if api=='chat' else 'fast')}
    b.update({'messages': [{'role':'user','content':'Return JSON {"ok":true}'}]} if api=='chat'
             else {'input':'Return JSON {"ok":true}'})
    b.update(extra)
    return b

def path(api):
    return '/v1/chat/completions' if api=='chat' else '/v1/responses'

def payload(api, content='{"ok":true}', **extra):
    p = {'id': 'mock-'+api, 'usage': {'prompt_tokens':11,'completion_tokens':7,'total_tokens':18,
         'prompt_cache_hit_tokens':4,'completion_tokens_details': {'reasoning_tokens':3}}}
    if api=='chat': p['choices']=[{'message': {'role':'assistant','content':content},'finish_reason':'stop'}]
    else:
        p['output']=[{'type':'message','content':[{'type':'output_text','text':content}]}]
        p['usage']={'input_tokens':11,'output_tokens':7,'total_tokens':18,
            'input_tokens_details':{'cached_tokens':4},'output_tokens_details':{'reasoning_tokens':3}}
    p.update(extra)
    return p

@contextlib.asynccontextmanager
async def client(cfg, handler):
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as up:
        app=create_app(cfg, http_client=up)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app, raise_app_exceptions=False),
                    base_url='http://teacher.test') as c:
                yield c, app

async def checks():
    requests=[]
    def good(req):
        api='chat' if req.url.path.endswith('completions') else 'responses'
        requests.append({'path':req.url.path,'body':json.loads(req.content)})
        return httpx.Response(200,json=payload(api))
    async with client(config(),good) as (c,app):
        for api in ('chat','responses'):
            r=await c.post(path(api),json=body(api))
            assert r.status_code==200
        record('A03_protocol_capture', requests=requests.copy())
        r=await c.post(path('chat'),json=body(model='fast'))
        record('A02_single_entry_cross_protocol',status=r.status_code,response=r.json())
        r=await c.post(path('chat'),json=body(model='absent'))
        assert r.status_code==404
        record('A04',status=r.status_code,response=r.json())
        for v in (1,2):
            r=await c.post('/v1/prompts',json={'id':'review','name':'Review','content':f'v{v} '+ '{{ name }}'})
            assert r.status_code==201
        for api in ('chat','responses'):
            for v in (1,2):
                r=await c.post(path(api),json=body(api,gateway_prompt={'id':'review','version':v,'variables':{'name':'Ada'}}))
                assert r.status_code==200
                sent=requests[-1]['body']
                actual=sent['messages'][0]['content'] if api=='chat' else sent['instructions']
                assert actual==f'v{v} Ada'
                record('F05',api=api,version=v,actual=actual,request_id=r.headers.get('x-request-id'))
        for ref in ({'id':'absent'}, {'id':'review','version':99}, {'id':'review','variables':{}}):
            before=len(requests)
            r=await c.post(path('chat'),json=body(gateway_prompt=ref))
            assert r.status_code in (404,422) and len(requests)==before
            record('F06',ref=ref,status=r.status_code,response=r.json())
        usage=(await c.get('/admin/usage')).json()['data']
        record('F07_normal_and_preflight_failures',events=usage,upstream_calls=len(requests),
               missing_template_failure_records=not any(x['error_type']=='invalid_request_error' and x['error_message'] and 'Prompt' in x['error_message'] for x in usage))
    schema={'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok']}
    for api in ('chat','responses'):
        formats=({'response_format':{'type':'json_object'}},
                 {'response_format':{'type':'json_schema','json_schema':{'name':'test','schema':schema}}}) if api=='chat' else (
                 {'response_format':{'type':'json_object'}}, {'text':{'format':{'type':'json_schema','name':'test','schema':schema}}})
        for fmt in formats:
            for value in ('{"ok":true}', 'not-json', '', '{"ok":', '{"ok":"wrong"}', '```json\n{"ok":true}\n```'):
                calls=[]
                def respond(req):
                    calls.append(json.loads(req.content))
                    return httpx.Response(200,json=payload(api,value))
                async with client(config(),respond) as (c,app):
                    r=await c.post(path(api),json=body(api,**fmt))
                    record('F03_F04',api=api,format=fmt,value=value,status=r.status_code,
                        response=r.json(),attempts=len(calls),sent=calls)
        calls=[]
        def repaired(req):
            calls.append(json.loads(req.content))
            return httpx.Response(200,json=payload(api,'bad' if len(calls)==1 else '{"ok":true}'))
        async with client(config(),repaired) as (c,app):
            r=await c.post(path(api),json=body(api,**formats[1]))
            assert r.status_code==200 and len(calls)==2
            record('F04_repair_success',api=api,status=r.status_code,attempts=len(calls))
    for statuses in ([500,500,200],[500]*8,[400]*8,[401]*8):
        times=[]
        def retry(req):
            times.append(time.perf_counter())
            s=statuses[min(len(times)-1,len(statuses)-1)]
            return httpx.Response(s,json=payload('chat') if s==200 else {'error':{'message':'teacher injected'}})
        async with client(config(),retry) as (c,app):
            random.seed(42)
            r=await c.post(path('chat'),json=body())
            expected=3 if statuses[0]==500 else 1
            assert len(times)==expected
            record('F08_F09',statuses=statuses,status=r.status_code,attempts=len(times),
                intervals=[round(b-a,4) for a,b in zip(times,times[1:])],
                usage=(await c.get('/admin/usage')).json()['data'])
    async with client(config(rate_limit={'enabled':True,'burst':1,'requests_per_minute':600}),good) as (c,app):
        statuses=[]
        for api in ('chat','chat','responses'):
            statuses.append((await c.post(path(api),json=body(api))).status_code)
        await asyncio.sleep(.13)
        recovery=await c.post(path('responses'),json=body('responses'))
        assert statuses==[200,429,429] and recovery.status_code==200
        record('F10_F11',sequence=['smart','smart','fast'],statuses=statuses,recovery=recovery.status_code,wait_seconds=.13)
    # Claimed schema support: unresolved references must not become unhandled 500.
    async with client(config(),good) as (c,app):
        r=await c.post(path('chat'),json=body(response_format={'type':'json_schema','json_schema':{'name':'badref','schema':{'$ref':'#/$defs/missing'}}}))
        record('B02_schema_ref',status=r.status_code,text=r.text,usage=(await c.get('/admin/usage')).json()['data'])
    await streaming_checks()

class Controlled(httpx.AsyncByteStream):
    def __init__(self,api,mode,gate): self.api,self.mode,self.gate=api,mode,gate
    async def __aiter__(self):
        yield b': heartbeat\n\n'
        await asyncio.sleep(.06)
        p={'choices':[{'delta':{'content':'first'}}]} if self.api=='chat' else {'type':'response.output_text.delta','delta':'first'}
        yield ('data: '+json.dumps(p)+'\n\n').encode()
        if self.mode=='gated':
            await asyncio.wait_for(self.gate.wait(),2)
            yield b'data: {"usage":{"prompt_tokens":11,"completion_tokens":7}}\n\n'
            yield b'data: [DONE]\n\n' if self.api=='chat' else b'event: response.completed\ndata: {"type":"response.completed","response":{"usage":{"input_tokens":11,"output_tokens":7}}}\n\n'
        elif self.mode=='disconnect': raise httpx.ReadError('teacher connection lost')
        elif self.mode=='error_event':
            yield b'data: {"error":{"message":"upstream failed","type":"server_error"},"type":"error"}\n\n'
        # silent EOF intentionally has no success terminal

async def streaming_checks():
    # Real TCP downstream: ASGITransport alone buffers streams and cannot prove incremental delivery.
    for api in ('chat','responses'):
        for mode in ('gated','disconnect','error_event','silent_eof'):
            gate=asyncio.Event(); calls=[]
            def handler(req):
                calls.append({'path':req.url.path,'body':json.loads(req.content)})
                return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Controlled(api,mode,gate))
            async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as up:
                app=create_app(config(),http_client=up)
                server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=18762,log_level='warning'))
                task=asyncio.create_task(server.serve())
                try:
                    while not server.started: await asyncio.sleep(.01)
                    start=time.perf_counter(); chunks=[]; before_release=False
                    async with httpx.AsyncClient() as c:
                        async with c.stream('POST','http://127.0.0.1:18762'+path(api),json=body(api,stream=True)) as r:
                            rid=r.headers.get('x-request-id')
                            async for text in r.aiter_text():
                                chunks.append({'ms':round((time.perf_counter()-start)*1000,2),'text':text})
                                if 'first' in text and mode=='gated':
                                    before_release=not gate.is_set()
                                    gate.set()
                        await asyncio.sleep(.03)
                        logs=(await c.get('http://127.0.0.1:18762/admin/usage')).json()['data']
                    assert len(calls)==1
                    if mode=='gated': assert before_release
                    if mode=='disconnect': assert 'stream_error' in ''.join(x['text'] for x in chunks) and logs[0]['status']=='error'
                    record('F01_F02_F07',api=api,mode=mode,received_before_terminal_released=before_release,
                        calls=calls,chunks=chunks,request_id=rid,usage=logs)
                finally:
                    server.should_exit=True
                    await task

class RecordingTransport(httpx.AsyncBaseTransport):
    def __init__(self): self.inner=httpx.AsyncHTTPTransport(); self.calls=[]
    async def handle_async_request(self,req):
        t=time.perf_counter()
        item={'url':str(req.url),'body':json.loads(req.content),'client_request_id':req.headers.get('x-request-id')}
        self.calls.append(item)
        try:
            r=await self.inner.handle_async_request(req)
            item['status']=r.status_code
            item['response_headers']={k:v for k,v in r.headers.items() if k.lower() in ('x-request-id','request-id','content-type','x-ds-trace-id')}
            return r
        except Exception as e:
            item['error']=type(e).__name__
            raise
        finally: item['headers_latency_ms']=round((time.perf_counter()-t)*1000,3)
    async def aclose(self): await self.inner.aclose()

async def real():
    if not os.getenv('DEEPSEEK_API_KEY'):
        record('REAL_UNVERIFIED',reason='DEEPSEEK_API_KEY absent'); return
    cfg=config(database_url='/tmp/grading-G20261786020012/real.db',
                providers={'p':{'base_url':'https://api.deepseek.com','api_key':os.environ['DEEPSEEK_API_KEY'],
                'timeout_seconds':25}},models={m:{'routes':[{'provider':'p','model':up,'api':'both'}]}
                for m,up in [('smart','deepseek-v4-pro'),('fast','deepseek-flash')]},
                retry={'max_attempts_per_route':1}, pricing={})
    transport=RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as up:
        app=create_app(cfg,http_client=up)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://real.test') as c:
                cases = [('responses','fast','stream'),('responses','fast','json'),('chat','fast','schema')] if '--extra-real' in sys.argv else [('chat','smart','normal'),('chat','fast','normal'),
                        ('responses','fast','normal'),('chat','smart','stream'),('chat','fast','stream'),
                        ('chat','smart','json'),('chat','fast','json')]
                for api,model,kind in cases:
                    extras={'thinking':{'type':'disabled'}}
                    if api=='chat': extras['max_tokens']=64
                    else: extras['max_output_tokens']=64
                    if kind=='stream':
                        extras['stream']=True
                        if api=='chat': extras['stream_options']={'include_usage':True}
                    if kind=='json':
                        if api=='chat': extras['response_format']={'type':'json_object'}
                        else: extras['text']={'format':{'type':'json_object'}}
                    if kind=='schema': extras['response_format']={'type':'json_schema','json_schema':{'name':'ok','schema':{'type':'object'}}}
                    before=len(transport.calls); start=time.perf_counter()
                    r=await c.post(path(api),json=body(api,model=model,**extras))
                    record('REAL',api=api,model_alias=model,kind=kind,status=r.status_code,
                        gateway_request_id=r.headers.get('x-request-id'),elapsed_ms=round((time.perf_counter()-start)*1000,3),
                        response=r.text,calls=transport.calls[before:])
                record('REAL_USAGE',events=(await c.get('/admin/usage')).json()['data'])

if __name__=='__main__': asyncio.run(real() if '--real' in sys.argv or '--extra-real' in sys.argv else checks())
