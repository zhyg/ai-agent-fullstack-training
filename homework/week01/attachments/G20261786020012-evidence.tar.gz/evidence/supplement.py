import asyncio
import json
import random
import time
from pathlib import Path
import httpx
import teacher

async def main():
    teacher.SEQ=1000
    result=[]
    def good(req): return httpx.Response(200,json=teacher.payload('chat'))
    async with teacher.client(teacher.config(),good) as (c,app):
        fmt={'type':'json_schema','json_schema':{'name':'ref','schema':{'$defs':{'ok':{'type':'boolean'}},'type':'object','properties':{'ok':{'$ref':'#/$defs/ok'}},'required':['ok']}}}
        r=await c.post(teacher.path('chat'),json=teacher.body(response_format=fmt))
        assert r.status_code==200
        result.append({'case':'B03_valid_ref','status':r.status_code,'response':r.json()})
    # Observe exact waits through an injected clock recorder, not scheduler overhead.
    waits=[]; actual_sleep=asyncio.sleep
    async def recorded_sleep(seconds):
        waits.append(seconds)
        await actual_sleep(seconds)
    times=[]
    def fails(req):
        times.append(time.perf_counter())
        return httpx.Response(500,json={'error':{'message':'cap test'}})
    async with teacher.client(teacher.config(retry={'max_attempts_per_route':3,'base_delay_seconds':.04,'max_delay_seconds':.02}),fails) as (c,app):
        random.seed(42)
        asyncio.sleep=recorded_sleep
        try: r=await c.post(teacher.path('chat'),json=teacher.body())
        finally: asyncio.sleep=actual_sleep
        assert r.status_code==502 and len(times)==3
        result.append({'case':'F08_cap','cap':.02,'waits':waits,'attempts':len(times),'status':r.status_code})
    Path(__file__).with_name('supplement-results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

asyncio.run(main())
