"""Teacher transport-controlled acceptance; student checkout is never edited."""
import asyncio, json, os, sys, time
from pathlib import Path
from unittest.mock import patch
import httpx, uvicorn
from openai import AsyncOpenAI

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'student/backend'))
os.environ.update(AUTH_TOKEN='teacher-local', OPENAI_API_KEY='teacher-placeholder',
                  ANTHROPIC_API_KEY='teacher-placeholder', DATABASE_URL='sqlite:///:memory:',
                  RATE_LIMIT_PER_MINUTE='1000', DEFAULT_MODEL='deepseek-chat')
from app.container import container
from app.main import app
from app.config import settings
from app.llm.schemas import LLMRequest, Message, ResponseFormat
from app.llm.retry import RetryConfig
from app.llm.adapter.openai_adapter import OpenAIAdapter
from app.llm.adapter.anthropic_adapter import AnthropicAdapter
from app.core.prompt import renderer, templates

RESULT = []
def record(case, status, **data):
    row = dict(case=case, status=status, **data)
    RESULT.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

VALID = json.dumps(dict(thought='test', action='final_answer', answer='OK', is_done=True))
class Wire:
    def __init__(self):
        self.calls=[]; self.mode='valid'; self.text=VALID; self.release=asyncio.Event()
    async def handle(self, req):
        body=json.loads(req.content); anth=req.url.path.endswith('/messages')
        self.calls.append(dict(path=req.url.path, body=body, time=time.monotonic()))
        n=len(self.calls)
        if self.mode in ('500','401','400') or self.mode=='twice' and n<=2:
            code=int(self.mode) if self.mode!='twice' else 500
            return httpx.Response(code,json={'error':{'message':'controlled','type':'invalid_request_error'}})
        if body.get('stream'):
            return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Frames(self,anth))
        usage={'input_tokens':11,'output_tokens':7,'cache_read_input_tokens':3} if anth else {
            'prompt_tokens':11,'completion_tokens':7,'total_tokens':18,
            'prompt_tokens_details':{'cached_tokens':3},'completion_tokens_details':{'reasoning_tokens':2}}
        data= dict(id='msg_teacher',type='message',role='assistant',content=[{'type':'text','text':self.text}],
                   stop_reason='max_tokens' if self.mode=='length' else 'end_turn',usage=usage) if anth else dict(
            id='chat_teacher',object='chat.completion',created=1,model=body['model'],
            choices=[{'index':0,'message':{'role':'assistant','content':self.text},
                      'finish_reason':'length' if self.mode=='length' else 'stop'}],usage=usage)
        return httpx.Response(200,json=data)

class Frames(httpx.AsyncByteStream):
    def __init__(self, wire, anth): self.w=wire; self.anth=anth
    async def __aiter__(self):
        def frame(d): return ('data: '+json.dumps(d)+'\n\n').encode()
        def cc(text='',finish=None): return dict(id='stream_teacher',object='chat.completion.chunk',created=1,
            model='teacher',choices=[{'index':0,'delta':{'content':text},'finish_reason':finish}])
        yield b': heartbeat\n\n'
        if self.anth:
            yield frame({'type':'message_start','message':{'usage':{'input_tokens':11,'output_tokens':0}}})
            yield frame({'type':'content_block_delta','index':0,'delta':{'type':'text_delta','text':self.w.text}})
        else: yield frame(cc(self.w.text))
        if self.w.mode=='gate': await self.w.release.wait()
        if self.w.mode=='disconnect': raise httpx.ReadError('controlled disconnect')
        if self.w.mode=='eof': return
        if self.w.mode=='error':
            yield frame({'type':'error','error':{'type':'overloaded_error','message':'controlled'}})
            return
        if self.anth:
            yield frame({'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':7}})
            yield frame({'type':'message_stop'})
        else:
            yield frame(cc(finish='stop'))
            yield frame(dict(id='stream_teacher',object='chat.completion.chunk',created=1,model='teacher',
                choices=[],usage={'prompt_tokens':11,'completion_tokens':7,'total_tokens':18}))
            yield b'data: [DONE]\n\n'

async def adapters(w):
    cfg=RetryConfig(max_retries=3,base_delay=0.1,jitter=False)
    o=OpenAIAdapter('teacher-placeholder',base_url='https://mock.invalid/v1',retry_config=cfg)
    await o._client.close()
    o._client=AsyncOpenAI(api_key='teacher-placeholder',base_url='https://mock.invalid/v1',
        http_client=httpx.AsyncClient(transport=httpx.MockTransport(w.handle)))
    a=AnthropicAdapter('teacher-placeholder',base_url='https://mock.invalid',retry_config=cfg)
    await a._client.aclose()
    a._client=httpx.AsyncClient(base_url='https://mock.invalid',transport=httpx.MockTransport(w.handle))
    return o,a

def request(model='gpt-4o', structured=False):
    return LLMRequest(model_id=model,messages=[Message(role='system',content='JSON only'),
        Message(role='user',content='test')],max_tokens=32,
        response_format=ResponseFormat() if structured else None)

async def main():
    await container.startup()
    await container.gateway.aclose()
    w=Wire(); o,a=await adapters(w)
    container.gateway._adapters={'openai':o,'anthropic':a}
    gw=container.gateway
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=18219,lifespan='off',log_level='warning'))
    serving=asyncio.create_task(server.serve())
    while not server.started: await asyncio.sleep(.01)
    try:
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18219',headers={'Authorization':'Bearer teacher-local'},timeout=5) as client:
            r=await client.get('/health'); record('A01','PASS',http=r.status_code,body=r.json())
            r=await client.post('/api/v1/tasks/start',json={'input':'test','model_id':'unknown'})
            record('A04','PASS' if r.status_code==400 else 'FAIL',http=r.status_code,body=r.json())
            for model in ('gpt-4o','claude-3-5-sonnet'):
                w.calls=[]; w.mode='valid'; w.text='{"ok":true}'
                r=await gw.invoke(request(model,True),trace_id='A03-'+model)
                record('A03/F03','PASS',model=model,content=r.content,usage=r.usage.model_dump(),wire=w.calls)
                for text,mode in [('not-json','valid'),('','valid'),('{"ok":','valid'),('{"ok":','length')]:
                    w.text=text; w.mode=mode; w.calls=[]
                    try:
                        r=await gw.invoke(request(model,True),trace_id='F04-'+model)
                        record('F04','FAIL',model=model,input=text,mode=mode,returned=r.content,calls=len(w.calls))
                    except Exception as e: record('F04','PASS',model=model,mode=mode,error=type(e).__name__,calls=len(w.calls))
                for mode in ('gate','disconnect','error','eof'):
                    w.mode=mode; w.text=VALID; w.calls=[]; w.release.clear()
                    r=await client.post('/api/v1/tasks/start',json={'input':'test','model_id':model,'max_steps':1})
                    task=r.json()['data']['task_id']; tokens=[]; events=[]; transport_error=None
                    try:
                        async with client.stream('GET',f'/api/v1/tasks/{task}/events') as s:
                            async for line in s.aiter_lines():
                                if line.startswith('event:'): events.append(line[6:].strip())
                                if line.startswith('data:') and events and events[-1]=='token':
                                    tokens.append(json.loads(line[5:]))
                                    if mode=='gate':
                                        record('F01-gate','PASS',model=model,received_before_release=True,
                                               content_type=s.headers['content-type'],token=tokens[-1])
                                        w.release.set()
                    except httpx.ReadTimeout:
                        transport_error='ReadTimeout: no terminal/error event within 5s'
                    record('F02','PASS' if mode=='gate' or 'error' in events else 'FAIL',model=model,
                           mode=mode,events=events,tokens=tokens,calls=len(w.calls),transport_error=transport_error)
            w.mode='valid'; w.text=VALID
            r=renderer.build_decision_message(task='asymmetric <x>',current_step=2,max_steps=7,executed_steps=[])
            record('F05/F06','PARTIAL',rendered=r.content,renderer_parameters=list(__import__('inspect').signature(renderer.build_decision_message).parameters),
                   template_constants=[k for k in vars(templates) if k.isupper()],
                   note='No template ID/version store or selection entry; Python required arguments reject missing task')
            for adapter,model in ((a,'claude-3-5-sonnet'),(o,'gpt-4o')):
                for mode in ('twice','500','401','400'):
                    w.mode=mode; w.calls=[]; waits=[]
                    try:
                        r=await gw.invoke(request(model),trace_id='retry-'+model+'-'+mode)
                        error=None
                    except Exception as e:
                        error=dict(type=type(e).__name__,code=getattr(getattr(e,'code',None),'value',None),http=getattr(e,'http_status',None))
                    waits=[round(y['time']-x['time'],4) for x,y in zip(w.calls,w.calls[1:])]
                    record('F08/F09','OBSERVED',model=model,mode=mode,calls=len(w.calls),waits=waits,error=error,
                           reported_retries=adapter.last_retry_count,sdk_max_retries=getattr(adapter._client,'max_retries',None))
            conn=container.db._require_conn()
            rows=[dict(r) for r in await (await conn.execute('SELECT * FROM llm_request_logs')).fetchall()]
            cols=[r[1] for r in await (await conn.execute('PRAGMA table_info(llm_request_logs)')).fetchall()]
            record('F07','PARTIAL',columns=cols,rows=rows,token_fields=list(r.usage.model_fields) if hasattr(r,'usage') else ['prompt_tokens','completion_tokens','total_tokens'])
            settings.rate_limit_per_minute=1
            w.mode='valid'; w.text=VALID
            r1=await client.post('/api/v1/tasks/start',json={'input':'test','model_id':'gpt-4o'})
            await asyncio.sleep(.1)
            r2=await client.post('/api/v1/tasks/start',json={'input':'test','model_id':'gpt-4o'})
            rb=await client.post('/api/v1/tasks/start',json={'input':'test','model_id':'claude-3-5-sonnet'})
            record('F10','FAIL',A_first=r1.status_code,A_second=r2.status_code,B=rb.status_code,body=rb.json())
            # Controlled clock advances only limiter's time module; no business logic replacement.
            import app.api.middleware.rate_limit as rl
            now=time.monotonic()
            class Clock:
                @staticmethod
                def monotonic(): return now+61
            with patch.object(rl,'time',Clock):
                rr=await client.post('/api/v1/tasks/start',json={'input':'test','model_id':'gpt-4o'})
            record('F11','PASS' if rr.status_code==200 else 'FAIL',clock_advance_seconds=61,http=rr.status_code)
            await asyncio.sleep(.2)
    finally:
        server.should_exit=True
        await serving
        await container.shutdown()
        (ROOT/'results.json').write_text(json.dumps(RESULT,ensure_ascii=False,indent=2))

asyncio.run(main())
