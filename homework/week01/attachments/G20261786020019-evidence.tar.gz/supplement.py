"""Small missing contract probes plus one distinct real model, no repeated real successes."""
import asyncio, json, os, sys, time, inspect
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'student/backend'))
os.environ.update(AUTH_TOKEN='teacher-local',OPENAI_API_KEY='teacher-placeholder',DATABASE_URL='sqlite:///:memory:')
from app.llm.adapter.openai_adapter import DeepSeekAdapter
from app.llm.gateway import LLMGateway
from app.llm.retry import RetryConfig
from app.llm.schemas import LLMRequest, Message
from app.infra.db import Database
from app.infra.logger import get_logger
from app.core.prompt.renderer import build_decision_message
from app.config import Settings, validate_sensitive_config

async def main():
    out={}
    try:
        s=Settings(_env_file=None,auth_token='teacher-local',openai_api_key='',deepseek_api_key='teacher-placeholder')
        validate_sensitive_config(s)
        out['deepseek_only_config']='accepted'
    except Exception as e: out['deepseek_only_config']={'error':type(e).__name__,'message':str(e)}
    for name,kwargs in [('missing_variable',dict(current_step=2,max_steps=7,executed_steps=[])),
                        ('version_selection',dict(task='x',current_step=2,max_steps=7,executed_steps=[],version='v1')),
                        ('template_selection',dict(task='x',current_step=2,max_steps=7,executed_steps=[],template_id='absent'))]:
        try: out[name]=build_decision_message(**kwargs).model_dump()
        except Exception as e: out[name]={'error':type(e).__name__,'message':str(e)}
    db=Database('sqlite:///:memory:'); await db.init()
    adapter=DeepSeekAdapter(os.environ['DEEPSEEK_API_KEY'],'https://api.deepseek.com/v1',RetryConfig(max_retries=0))
    adapter._client=adapter._client.with_options(timeout=30,max_retries=0)
    gw=LLMGateway({'deepseek':adapter},db,get_logger('supplement'))
    try:
        try: await gw.invoke(LLMRequest(model_id='absent',messages=[Message(role='user',content='x')]),trace_id='missing-model')
        except Exception as e: out['unknown_model']={'error':type(e).__name__}
        count=(await (await db._require_conn().execute('SELECT count(*) FROM llm_request_logs')).fetchone())[0]
        out['unknown_model']['request_log_count']=count
        wire=[]
        async def reqhook(req): wire.append({'url':str(req.url),'body':json.loads(req.content)})
        async def resphook(resp): wire[-1]['http']=resp.status_code
        adapter._client._client.event_hooks={'request':[reqhook],'response':[resphook]}
        start=time.perf_counter()
        try:
            async with asyncio.timeout(40):
                r=await gw.invoke(LLMRequest(model_id='deepseek-v4-pro',messages=[Message(role='user',content='Say OK only.')],max_tokens=2048),trace_id='real-distinct-pro')
            out['real_pro']={'status':'returned','content':r.content,'finish_reason':r.finish_reason,
                'provider_request_id':r.provider_request_id,'upstream_model':r.raw.get('model'),
                'usage':r.usage.model_dump(),'upstream_usage':r.raw.get('usage')}
        except Exception as e: out['real_pro']={'status':'unverified','error':type(e).__name__}
        out['real_pro'].update(latency_ms=round((time.perf_counter()-start)*1000),wire=wire)
        out['request_logs']=[dict(x) for x in await (await db._require_conn().execute('SELECT * FROM llm_request_logs')).fetchall()]
    finally: await gw.aclose(); await db.close()
    (ROOT/'supplement-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps(out,ensure_ascii=False))

asyncio.run(main())
