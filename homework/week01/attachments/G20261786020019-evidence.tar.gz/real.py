"""Official DeepSeek only; credential stays in process environment, never output."""
import asyncio, json, os, sys, time
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'student/backend'))
os.environ.update(AUTH_TOKEN='teacher-local',OPENAI_API_KEY='teacher-placeholder',DATABASE_URL='sqlite:///:memory:')
from app.llm.adapter.openai_adapter import DeepSeekAdapter
from app.llm.adapter.anthropic_adapter import AnthropicAdapter
from app.llm.retry import RetryConfig
from app.llm.gateway import LLMGateway
from app.llm.schemas import LLMRequest, Message, ResponseFormat
from app.infra.db import Database
from app.infra.logger import get_logger
import httpx

async def main():
    key=os.environ['DEEPSEEK_API_KEY']
    cfg=RetryConfig(max_retries=0)
    o=DeepSeekAdapter(key,'https://api.deepseek.com/v1',cfg)
    o._client=o._client.with_options(timeout=30,max_retries=0)
    a=AnthropicAdapter(key,'https://api.deepseek.com/anthropic',cfg)
    a._client.timeout=httpx.Timeout(30)
    wire=[]
    async def on_request(req):
        wire.append({'url':str(req.url),'body':json.loads(req.content)})
    async def on_response(resp):
        wire[-1].update(http=resp.status_code,headers={k:v for k,v in resp.headers.items() if k.lower() in ('x-request-id','request-id','content-type')})
    for client in (o._client._client,a._client):
        client.event_hooks={'request':[on_request],'response':[on_response]}
    db=Database('sqlite:///:memory:'); await db.init()
    g=LLMGateway({'deepseek':o,'anthropic':a},db,get_logger('real'))
    results=[]
    try:
        for model in ('deepseek-chat','claude-3-5-sonnet'):
            for kind in ('normal','json','stream'):
                req=LLMRequest(model_id=model,messages=[Message(role='user',content='Return only JSON {"ok":true}. No explanation.')],
                    max_tokens=2048,response_format=ResponseFormat() if kind=='json' else None)
                started=time.perf_counter(); trace='real-'+model+'-'+kind
                try:
                    if kind=='stream':
                        chunks=[]; first=None
                        async with asyncio.timeout(40):
                            async for chunk in g.stream(req,trace_id=trace):
                                if chunk.content and first is None: first=round((time.perf_counter()-started)*1000)
                                chunks.append(chunk.model_dump())
                        result={'chunks':chunks,'teacher_first_content_ms':first}
                    else:
                        async with asyncio.timeout(40): r=await g.invoke(req,trace_id=trace)
                        result={'content':r.content,'finish_reason':r.finish_reason,'usage':r.usage.model_dump(),
                            'provider_request_id':r.provider_request_id,'upstream_model':r.raw.get('model'),
                            'upstream_usage':r.raw.get('usage')}
                        if kind=='json':
                            try: json.loads(r.content); result['valid_json']=True
                            except ValueError: result['valid_json']=False
                    row=dict(model_alias=model,kind=kind,trace_id=trace,status='returned',latency_ms=round((time.perf_counter()-started)*1000),result=result)
                except Exception as e:
                    row=dict(model_alias=model,kind=kind,trace_id=trace,status='unverified',error_type=type(e).__name__,
                        error_code=getattr(getattr(e,'code',None),'value',None),latency_ms=round((time.perf_counter()-started)*1000))
                results.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
        rows=[dict(x) for x in await (await db._require_conn().execute('SELECT * FROM llm_request_logs')).fetchall()]
        (ROOT/'real-results.json').write_text(json.dumps(dict(results=results,wire=wire,request_logs=rows),ensure_ascii=False,indent=2))
    finally:
        await g.aclose(); await db.close()

asyncio.run(main())
