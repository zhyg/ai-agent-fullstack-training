"""全链路验证脚本（真实调用 LLM，需先在 .env 配置有效 Key）。

运行方式（在 backend 目录下）：
    python scripts/test_e2e.py

验证链路：
  Phase 1  DeepSeek 直连（httpx → /chat/completions）—— 验证 Key / base_url / 模型名
  Phase 2  Gateway 适配层（LLMGateway.invoke）—— 验证适配器、重试边界、请求记录落库
  Phase 3  Agent 全链路（orchestrator.start → AgentLoop → SSE 事件 → DB）—— 验证任务闭环
  Phase 4  暂停/续流链路（start → stop(paused) → resume 原地续流）—— 验证会话不结束、seq 连续
"""
import asyncio
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx  # noqa: E402

from app.api.schemas.sse import SSEEventType  # noqa: E402
from app.api.schemas.task import TaskResumeRequest, TaskStartRequest  # noqa: E402
from app.config import settings  # noqa: E402
from app.container import container  # noqa: E402
from app.llm.registry import get_model_info  # noqa: E402
from app.llm.schemas import LLMRequest, Message, ResponseFormat  # noqa: E402

PASS = "  ✓"
FAIL = "  ✗"


def fail(phase: str, msg: str) -> None:
    print(f"{FAIL} [{phase}] {msg}")
    print("\n链路验证终止。请修复上述问题后重跑。")
    sys.exit(1)


def ok(phase: str, msg: str) -> None:
    print(f"{PASS} [{phase}] {msg}")


# ── Phase 1: DeepSeek 直连 ──
async def phase1_direct() -> None:
    print("\n── Phase 1: DeepSeek 直连（验证 Key / base_url / 模型名）──")
    if not settings.deepseek_api_key:
        fail("Phase1", "DEEPSEEK_API_KEY 未配置")

    model_id = settings.default_model
    info = get_model_info(model_id)
    provider_model = info.provider_model if info else model_id
    url = f"{settings.deepseek_base_url.rstrip('/')}/chat/completions"
    print(f"  POST {url}  model={provider_model}")

    payload = {
        "model": provider_model,
        "messages": [{"role": "user", "content": "用一句话回答：1+1=?"}],
        "stream": False,
    }
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                url, json=payload,
                headers={"Authorization": f"Bearer {settings.deepseek_api_key}"},
            )
    except httpx.HTTPError as e:
        fail("Phase1", f"网络错误: {e}")

    if resp.status_code == 401:
        fail("Phase1", f"Key 无效（401）: {resp.text[:200]}")
    if resp.status_code != 200:
        fail("Phase1", f"HTTP {resp.status_code}: {resp.text[:300]}")
    content = resp.json()["choices"][0]["message"]["content"]
    ok("Phase1", f"模型应答: {content[:80]}")


# ── Phase 2: Gateway 适配层 ──
async def phase2_gateway() -> None:
    print("\n── Phase 2: Gateway 适配层（适配器 + 请求记录落库）──")
    trace_id = "trace_e2e_phase2"
    resp = await container.gateway.invoke(
        LLMRequest(
            model_id=settings.default_model,
            messages=[
                Message(role="system", content="你只能输出 JSON。"),
                Message(role="user", content='只回复这个 JSON: {"ok": true}'),
            ],
            response_format=ResponseFormat(type="json_object"),
            max_tokens=256,
        ),
        trace_id=trace_id,
    )
    assert resp.content, "空响应"
    ok("Phase2", f"LLMResponse: finish_reason={resp.finish_reason}, "
                 f"usage={resp.usage.total_tokens} tokens, content={resp.content[:60]}")

    # 验证请求记录落库
    row = None
    async with container.db._require_conn().execute(
        "SELECT * FROM llm_request_logs WHERE trace_id = ?", (trace_id,)
    ) as cur:
        row = await cur.fetchone()
    assert row is not None, "llm_request_logs 无记录"
    ok("Phase2", f"请求记录已落库: request_id={row['request_id']}, "
                 f"status={row['status']}, latency={row['latency_ms']}ms")


# ── Phase 3: Agent 全链路 ──
async def phase3_agent() -> str:
    print("\n── Phase 3: Agent 全链路（start → Loop → SSE 事件 → DB）──")
    start_resp = await container.orchestrator.start(TaskStartRequest(
        input="直接用一句话回答：中国的首都是哪里？不需要调用任何工具。",
        model_id=settings.default_model,
        max_steps=5,
    ))
    task_id = start_resp.task_id
    ok("Phase3", f"任务已启动: task_id={task_id}, trace_id={start_resp.trace_id}")

    events = await _drain_events(task_id, timeout_s=180)
    types = [e.event for e in events]

    # 事件序列完整性
    seqs = [e.seq for e in events]
    assert seqs == list(range(1, len(events) + 1)), f"seq 不连续: {seqs}"
    assert SSEEventType.TASK_STARTED in types, "缺 task_started"
    assert SSEEventType.TASK_FINISHED in types, "缺 task_finished"
    finished = events[-1].data
    ok("Phase3", f"任务结束: status={finished['status']}, "
                 f"total_steps={finished['total_steps']}, 事件数={len(events)}")

    if SSEEventType.FINAL_ANSWER in types:
        ans = next(e for e in events if e.event == SSEEventType.FINAL_ANSWER)
        ok("Phase3", f"最终答案: {ans.data['answer'][:80]}")

    token_events = [e for e in events if e.event == SSEEventType.TOKEN]
    assert token_events, "缺 token 事件（LLM 调用未走流式输出）"
    ok("Phase3", f"流式输出正常: token 事件 {len(token_events)} 条")

    # DB 持久化检查
    row = await container.db.get_task(task_id)
    assert row is not None and row["status"] in ("completed", "failed"), \
        f"tasks 表状态异常: {row and row['status']}"
    db_events = await container.db.get_events(task_id)
    assert len(db_events) == len(events), "task_events 持久化数量不一致"
    ok("Phase3", f"DB 持久化一致: status={row['status']}, events={len(db_events)} 条")
    return task_id


# ── Phase 4: 暂停 / 原地续流 ──
async def phase4_pause_resume() -> None:
    print("\n── Phase 4: 暂停/续流链路（start → stop(paused) → resume 原地续流）──")
    start_resp = await container.orchestrator.start(TaskStartRequest(
        input="搜索最近一周的全球科技新闻，并逐条详细总结（这是一个需要多步的长任务）。",
        model_id=settings.default_model,
        max_steps=10,
    ))
    task_id = start_resp.task_id
    await asyncio.sleep(2)  # 让 Loop 进入 LLM 流式输出中

    stop_resp = await container.orchestrator.stop(task_id)
    assert stop_resp.status.value == "paused", f"stop 返回状态异常: {stop_resp.status}"
    ok("Phase4", f"暂停返回: status=paused, last_seq={stop_resp.last_seq}")

    await asyncio.sleep(1.5)
    # 暂停期间：任务仍在内存（会话未结束），不应出现任何终止事件
    assert container.task_service.get(task_id) is not None, "暂停后任务被移出内存"
    snapshot = await container.event_buffer.next_events(task_id, 0, timeout=0.1) or []
    types = [e.event for e in snapshot]
    assert SSEEventType.TASK_FINISHED not in types, "暂停不应产生 task_finished"
    assert SSEEventType.CANCELLED not in types, "暂停不应产生 cancelled"
    row = await container.db.get_task(task_id)
    assert row["status"] == "paused", f"DB 状态未持久化: {row['status']}"
    ok("Phase4", f"暂停态: 任务仍在内存, DB={row['status']}, 输出已停止")

    resume_resp = await container.orchestrator.resume(
        task_id, TaskResumeRequest(last_seq=stop_resp.last_seq)
    )
    assert resume_resp.in_place is True, "暂停中恢复应走原地续流"
    ok("Phase4", f"恢复返回: in_place=True, start_seq={resume_resp.start_seq}")

    events = await _drain_events(task_id, timeout_s=120)
    types = [e.event for e in events]
    assert SSEEventType.CANCELLED not in types, "原地续流不应产生 cancelled 事件"
    # seq 必须从 1 连续递增：中间无空洞、无重放
    assert [e.seq for e in events] == list(range(1, len(events) + 1)), "seq 不连续"
    # 第 1 步只应思考一次：证明恢复没有重做该步骤
    step1 = [e for e in events if e.event == SSEEventType.THOUGHT and e.data.get("step") == 1]
    assert len(step1) == 1, f"第 1 步被重复执行 {len(step1)} 次"
    ok("Phase4", f"续流验证: seq 连续 1..{len(events)}, 第 1 步未重做")


# ── 事件收取（模拟 SSE 订阅端）──
async def _drain_events(task_id: str, timeout_s: float):
    events = []
    last = 0
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        remaining = max(1.0, deadline - time.monotonic())
        evs = await container.event_buffer.next_events(
            task_id, last, timeout=min(15.0, remaining)
        )
        if evs is None:
            continue  # 心跳超时，继续等
        if not evs:
            break  # 终止事件已送达
        for ev in evs:
            events.append(ev)
            last = ev.seq
            data = json.dumps(ev.data, ensure_ascii=False)
            print(f"    [seq={ev.seq:>2}] {ev.event.value}: {data[:100]}")
            if ev.event == SSEEventType.TASK_FINISHED:
                return events
    else:
        fail("Events", f"等待 task_finished 超时（{timeout_s}s）")
    return events


async def main() -> None:
    print("=" * 60)
    print("个人助理 Agent 全链路验证")
    print(f"默认模型: {settings.default_model}  base_url: {settings.deepseek_base_url}")
    print("=" * 60)

    await phase1_direct()

    await container.startup()
    try:
        await phase2_gateway()
        await phase3_agent()
        await phase4_pause_resume()
    finally:
        await container.shutdown()

    print("\n" + "=" * 60)
    print("全链路验证通过 ✓")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
