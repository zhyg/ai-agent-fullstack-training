"""复现脚本：取消后恢复，观察 SSE 续传是否正常（模拟前端调用顺序）。"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx

BASE = "http://127.0.0.1:8000/api/v1"
TOKEN = "[REDACTED_STUDENT_AUTH_TOKEN]"
H = {"Authorization": f"Bearer {TOKEN}"}


async def main() -> None:
    async with httpx.AsyncClient(timeout=None) as c:
        # 1. start
        r = await c.post(f"{BASE}/tasks/start", headers=H, json={
            "input": "搜索最近一周的科技新闻并逐条总结", "max_steps": 10})
        tid = r.json()["data"]["task_id"]
        print("1) started:", tid)

        # 2. 跑 4 秒后 stop
        await asyncio.sleep(4)
        r = await c.post(f"{BASE}/tasks/{tid}/stop", headers=H)
        stop = r.json()["data"]
        last = stop["last_seq"]
        print(f"2) stopped: status={stop['status']} last_seq={last}")

        # 3. 等 1 秒再 resume（模拟用户点击间隔）
        await asyncio.sleep(1)
        r = await c.post(f"{BASE}/tasks/{tid}/resume", headers=H,
                         json={"last_seq": last})
        print(f"3) resume: HTTP {r.status_code} {r.text[:200]}")
        if r.status_code != 200:
            return

        # 4. 带 last_seq 连 SSE，观察 60 秒
        print(f"4) SSE connect from last_seq={last}, listening 60s...")
        try:
            async with asyncio.timeout(60):
                async with c.stream(
                    "GET", f"{BASE}/tasks/{tid}/events?last_seq={last}", headers=H
                ) as resp:
                    print("   stream HTTP", resp.status_code)
                    async for line in resp.aiter_lines():
                        if line:
                            print("   SSE:", line[:160])
                        if '"task_finished"' in line or "event:task_finished" in line:
                            break
        except asyncio.TimeoutError:
            print("   !! 60s 内未收到 task_finished（事件流可能中断）")


asyncio.run(main())
