"""SSE 事件缓冲区：内存缓冲 + SQLite 持久化 + asyncio.Condition 订阅通知。"""
import asyncio
import json

from app.api.schemas.sse import SSEEvent, SSEEventType, TERMINAL_EVENT_TYPES
from app.infra.db import Database


class EventBuffer:
    """每个任务一个事件序列：seq 单调递增，支持断点续传与超时心跳。"""

    def __init__(self, db: Database):
        self._db = db
        self._buffers: dict[str, list[SSEEvent]] = {}
        self._conds: dict[str, asyncio.Condition] = {}
        self._loaded: set[str] = set()
        self._is_active = None  # Callable[[str], bool] | None，探测任务是否仍在运行

    def set_active_probe(self, fn) -> None:
        """注入任务活跃探测器（避免恢复后旧终止事件误判流结束）。"""
        self._is_active = fn

    def _cond(self, task_id: str) -> asyncio.Condition:
        cond = self._conds.get(task_id)
        if cond is None:
            cond = asyncio.Condition()
            self._conds[task_id] = cond
        return cond

    async def open_task(self, task_id: str) -> None:
        """初始化任务缓冲：从持久化加载已有事件（断点续传场景）。"""
        if task_id in self._loaded:
            return
        rows = await self._db.get_events(task_id, after_seq=0)
        self._buffers[task_id] = [
            SSEEvent(
                seq=r["seq"],
                event=SSEEventType(r["event_type"]),
                data=json.loads(r["data"]),
            )
            for r in rows
        ]
        self._loaded.add(task_id)

    async def latest_seq(self, task_id: str) -> int:
        """返回任务当前最新事件序列号（无事件为 0）。"""
        await self.open_task(task_id)
        buf = self._buffers.get(task_id) or []
        return buf[-1].seq if buf else 0

    async def publish(self, task_id: str, event_type: SSEEventType, data: dict) -> int:
        """发布事件：分配 seq → 内存缓冲 → 持久化 → 唤醒订阅者。返回 seq。"""
        await self.open_task(task_id)
        cond = self._cond(task_id)
        async with cond:
            buf = self._buffers[task_id]
            seq = (buf[-1].seq + 1) if buf else 1
            event = SSEEvent(seq=seq, event=event_type, data=data)
            buf.append(event)
            await self._db.insert_event(
                task_id, seq, event_type.value,
                json.dumps(data, ensure_ascii=False),
            )
            cond.notify_all()
            return seq

    async def next_events(
        self,
        task_id: str,
        after_seq: int,
        timeout: float = 15.0,
    ) -> list[SSEEvent] | None:
        """返回 seq > after_seq 的事件。

        - 有事件：返回事件列表。
        - 已终止（最后事件为终止事件且都已送达）：返回空列表 []。
        - 超时无事件：返回 None（调用方发送 ": ping" 心跳）。
        """
        await self.open_task(task_id)
        cond = self._cond(task_id)
        async with cond:
            while True:
                buf = self._buffers[task_id]
                pending = [e for e in buf if e.seq > after_seq]
                if pending:
                    return pending
                if buf and buf[-1].event.value in TERMINAL_EVENT_TYPES:
                    # 任务已恢复运行（resume 场景）：旧终止事件不代表本次运行结束，
                    # 继续等待新事件；否则确认终止。
                    if not (self._is_active and self._is_active(task_id)):
                        return []
                try:
                    await asyncio.wait_for(cond.wait(), timeout)
                except asyncio.TimeoutError:
                    return None

    async def close_task(self, task_id: str) -> None:
        """释放内存缓冲（事件已持久化，可按需重新加载）。"""
        self._buffers.pop(task_id, None)
        self._conds.pop(task_id, None)
        self._loaded.discard(task_id)
