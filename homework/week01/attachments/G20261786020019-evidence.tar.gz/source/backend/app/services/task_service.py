"""任务服务：RunningTask 内存注册 + 任务快照持久化 + 危险工具确认等待。"""
import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.core.runtime import TaskRuntime
from app.infra.db import Database


@dataclass
class PendingConfirmation:
    """一次危险工具二次确认的等待句柄。"""

    step: int
    tool_name: str
    tool_args: dict
    event: asyncio.Event = field(default_factory=asyncio.Event)
    confirmed: bool = False


@dataclass
class RunningTask:
    """运行中任务的内存载体。"""

    runtime: TaskRuntime
    cancel_event: asyncio.Event = field(default_factory=asyncio.Event)
    # 暂停/恢复信号：set=继续消费；clear=暂停（不再读取 LLM 流、不再发布 token）
    resume_event: asyncio.Event = field(default_factory=asyncio.Event)
    # 暂停确认：循环真正停在帧边界时置位，供 stop 接口等待"输出确实已停止"
    paused_ack: asyncio.Event = field(default_factory=asyncio.Event)
    runner: asyncio.Task | None = None
    confirmation: PendingConfirmation | None = None

    def __post_init__(self) -> None:
        self.resume_event.set()

    def pause(self) -> None:
        """暂停：清空恢复信号，循环在下一个帧边界停住。"""
        self.paused_ack.clear()
        self.resume_event.clear()

    def resume(self) -> None:
        """恢复：重新置位，循环从当前位置继续消费同一条流。"""
        self.paused_ack.clear()
        self.resume_event.set()

    async def wait_if_paused(self) -> None:
        """暂停期间挂起；恢复后返回。硬取消时抛出 CancelledError。"""
        if self.cancel_event.is_set():
            raise asyncio.CancelledError()
        if not self.resume_event.is_set():
            self.paused_ack.set()
            await self.resume_event.wait()
            self.paused_ack.clear()
        if self.cancel_event.is_set():
            raise asyncio.CancelledError()


class TaskService:
    """任务注册表（内存）+ 快照读写（DB）+ 确认协调。"""

    CONFIRM_TIMEOUT = 300.0  # 二次确认等待超时（秒）

    def __init__(self, db: Database):
        self._db = db
        self._tasks: dict[str, RunningTask] = {}

    @property
    def db(self) -> Database:
        return self._db

    # ── 注册表 ──
    def register(self, running: RunningTask) -> None:
        self._tasks[running.runtime.task_id] = running

    def get(self, task_id: str) -> RunningTask | None:
        return self._tasks.get(task_id)

    def unregister(self, task_id: str) -> None:
        self._tasks.pop(task_id, None)

    # ── 快照持久化 ──
    async def snapshot(self, runtime: TaskRuntime) -> None:
        """将运行时状态持久化到 tasks 表。"""
        runtime.updated_at = datetime.now(timezone.utc)
        await self._db.upsert_task({
            "task_id": runtime.task_id,
            "trace_id": runtime.trace_id,
            "input": runtime.input,
            "model_id": runtime.model_id,
            "max_steps": runtime.max_steps,
            "status": runtime.status.value,
            "business_id": runtime.business_id,
            "current_step": runtime.current_step,
            "conversation_history": [
                m.model_dump() for m in runtime.conversation_history
            ],
            "executed_steps": [
                s.model_dump() for s in runtime.executed_steps
            ],
            "last_seq": runtime.last_seq,
            "created_at": runtime.created_at.isoformat(),
        })

    async def load_runtime(self, task_id: str) -> TaskRuntime | None:
        """从 DB 加载任务快照并重建运行时对象。"""
        row = await self._db.get_task(task_id)
        if row is None:
            return None
        return TaskRuntime(
            task_id=row["task_id"],
            trace_id=row["trace_id"],
            input=row["input"],
            model_id=row["model_id"],
            max_steps=row["max_steps"],
            status=row["status"],
            business_id=row["business_id"],
            current_step=row["current_step"],
            conversation_history=row["conversation_history"],
            executed_steps=row["executed_steps"],
            last_seq=row["last_seq"],
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
        )

    # ── 危险工具二次确认 ──
    async def wait_confirmation(
        self,
        running: RunningTask,
        *,
        step: int,
        tool_name: str,
        tool_args: dict,
    ) -> bool:
        """挂起等待用户确认，返回 confirmed；超时按未确认处理。"""
        pending = PendingConfirmation(step=step, tool_name=tool_name, tool_args=tool_args)
        running.confirmation = pending
        try:
            await asyncio.wait_for(pending.event.wait(), self.CONFIRM_TIMEOUT)
        except asyncio.TimeoutError:
            return False
        finally:
            running.confirmation = None
        return pending.confirmed

    def resolve_confirmation(
        self,
        task_id: str,
        *,
        step: int,
        tool_name: str,
        confirmed: bool,
    ) -> bool:
        """用户确认到达：匹配当前挂起的确认并唤醒等待方。返回是否匹配成功。"""
        running = self._tasks.get(task_id)
        if running is None or running.confirmation is None:
            return False
        pending = running.confirmation
        if pending.step != step or pending.tool_name != tool_name:
            return False
        pending.confirmed = confirmed
        pending.event.set()
        return True
