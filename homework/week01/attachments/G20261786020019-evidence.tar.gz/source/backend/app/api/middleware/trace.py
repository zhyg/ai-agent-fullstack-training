"""Trace 中间件：注入 trace_id / business_id 到 request.state。"""
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class TraceMiddleware(BaseHTTPMiddleware):
    """每个请求生成/透传追踪 ID，业务 ID 从 X-Business-Id 头透传不解析。"""

    async def dispatch(self, request: Request, call_next):
        request.state.trace_id = request.headers.get(
            "X-Trace-Id", f"trace_{uuid.uuid4().hex[:16]}"
        )
        request.state.business_id = request.headers.get("X-Business-Id")
        response = await call_next(request)
        response.headers["X-Trace-Id"] = request.state.trace_id
        return response
