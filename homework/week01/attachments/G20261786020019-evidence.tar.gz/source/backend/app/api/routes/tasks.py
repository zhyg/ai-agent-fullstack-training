"""任务接口：开始/停止/恢复/确认/切换模型/SSE 事件流。"""
import asyncio
from typing import Annotated

from fastapi import APIRouter, Path, Query, Request
from fastapi.responses import StreamingResponse

from app.api.schemas.common import ApiResponse, ok
from app.api.schemas.sse import SSEEventType
from app.api.schemas.task import (
    ConfirmToolRequest,
    ConfirmToolResponse,
    SwitchModelRequest,
    SwitchModelResponse,
    TaskResumeRequest,
    TaskResumeResponse,
    TaskStartRequest,
    TaskStartResponse,
    TaskStopResponse,
)
from app.container import container

router = APIRouter(prefix="/tasks", tags=["tasks"])

TaskIdPath = Annotated[
    str,
    Path(..., pattern=r"^task_[0-9]{8}_[a-zA-Z0-9]+$",
         min_length=1, max_length=64, description="任务 ID"),
]


@router.post("/start", response_model=ApiResponse[TaskStartResponse])
async def start_task(req: TaskStartRequest, request: Request):
    """开始任务：异步触发任务循环，立即返回 task_id。"""
    data = await container.orchestrator.start(
        req, business_id=getattr(request.state, "business_id", None)
    )
    return ok(data)


@router.post("/{task_id}/stop", response_model=ApiResponse[TaskStopResponse])
async def stop_task(task_id: TaskIdPath):
    """暂停任务：停止输出与消费，任务不结束，可原地续流恢复。"""
    data = await container.orchestrator.stop(task_id)
    return ok(data)


@router.post("/{task_id}/resume", response_model=ApiResponse[TaskResumeResponse])
async def resume_task(task_id: TaskIdPath, req: TaskResumeRequest):
    """恢复任务：暂停中则唤醒同一条流原地续传，否则按快照冷恢复。"""
    data = await container.orchestrator.resume(task_id, req)
    return ok(data)


@router.post("/{task_id}/confirm", response_model=ApiResponse[ConfirmToolResponse])
async def confirm_tool(task_id: TaskIdPath, req: ConfirmToolRequest):
    """危险工具二次确认：传回用户决策。"""
    data = await container.orchestrator.confirm(task_id, req)
    return ok(data)


@router.put("/{task_id}/model", response_model=ApiResponse[SwitchModelResponse])
async def switch_model(task_id: TaskIdPath, req: SwitchModelRequest):
    """切换模型：下一轮 LLM 调用生效。"""
    data = await container.orchestrator.switch_model(task_id, req)
    return ok(data)


@router.get("/{task_id}/events")
async def task_events(
    task_id: TaskIdPath,
    last_seq: Annotated[int, Query(ge=0, description="从该序列号之后开始推送")] = 0,
):
    """SSE 资源接口：长连接推送任务事件，支持断点续传。"""
    buffer = container.event_buffer

    async def gen():
        last = last_seq
        try:
            while True:
                events = await buffer.next_events(task_id, last, timeout=15.0)
                if events is None:
                    # 超时心跳，保持连接
                    yield ": ping\n\n"
                    continue
                if not events:
                    return  # 任务已终止且事件全部送达
                for ev in events:
                    yield ev.encode()
                    last = ev.seq
                    # 仅在最终结束事件关闭连接，确保同一批的 cancelled 不吞掉 task_finished
                    if ev.event.value == SSEEventType.TASK_FINISHED.value:
                        return
        except asyncio.CancelledError:
            return

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
