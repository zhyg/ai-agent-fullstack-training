"""SSE 事件模型：id(seq) / event / data 三段式，支持断点续传。"""
import json
from enum import Enum
from typing import Annotated

from pydantic import BaseModel, Field


class SSEEventType(str, Enum):
    TASK_STARTED = "task_started"
    THOUGHT = "thought"
    TOOL_CALL = "tool_call"
    TOOL_CONFIRMATION_REQUEST = "tool_confirmation_request"
    TOOL_RESULT = "tool_result"
    TOKEN = "token"
    FINAL_ANSWER = "final_answer"
    ERROR = "error"
    CANCELLED = "cancelled"
    TASK_FINISHED = "task_finished"


# 收到这些事件后 SSE 连接可关闭
TERMINAL_EVENT_TYPES = {
    SSEEventType.CANCELLED.value,
    SSEEventType.TASK_FINISHED.value,
}


class SSEEvent(BaseModel):
    """一条 SSE 事件。"""

    seq: Annotated[int, Field(..., ge=1, description="事件序列号，单调递增")]
    event: Annotated[SSEEventType, Field(..., description="事件类型")]
    data: Annotated[dict, Field(default_factory=dict, description="事件数据")]

    def encode(self) -> str:
        """编码为标准 SSE 文本帧。"""
        payload = json.dumps(self.data, ensure_ascii=False)
        return f"id: {self.seq}\nevent: {self.event.value}\ndata: {payload}\n\n"


# ── 各事件 data 结构（协议文档）──
class TaskStartedData(BaseModel):
    task_id: str
    trace_id: str
    model_id: str


class ThoughtData(BaseModel):
    step: int
    content: str


class ToolCallData(BaseModel):
    step: int
    tool_name: str
    tool_args: dict


class ToolConfirmationRequestData(BaseModel):
    step: int
    tool_name: str
    tool_args: dict
    message: str


class ToolResultData(BaseModel):
    step: int
    tool_name: str
    result: dict
    duration_ms: int


class TokenData(BaseModel):
    content: str


class FinalAnswerData(BaseModel):
    answer: str
    usage: dict


class ErrorData(BaseModel):
    error_type: str
    message: str
    retryable: bool


class CancelledData(BaseModel):
    last_seq: int


class TaskFinishedData(BaseModel):
    status: str
    total_steps: int
