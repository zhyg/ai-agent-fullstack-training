"""运维接口查询/响应模型。"""
from typing import Annotated

from pydantic import BaseModel, Field, field_validator, model_validator


class RequestLogQuery(BaseModel):
    """请求记录查询参数。"""

    trace_id: Annotated[str | None, Field(None, description="按 trace_id 过滤")] = None
    model_id: Annotated[str | None, Field(None, description="按模型过滤")] = None
    status: Annotated[str | None, Field(None, description="按状态过滤")] = None
    start_time: Annotated[str | None, Field(None, description="开始时间 ISO8601")] = None
    end_time: Annotated[str | None, Field(None, description="结束时间 ISO8601")] = None
    page: Annotated[int, Field(1, ge=1, description="页码，从 1 开始")] = 1
    page_size: Annotated[int, Field(20, ge=1, le=100, description="每页条数，1~100")] = 20

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str | None) -> str | None:
        if v is not None and v not in {"success", "failed", "cancelled"}:
            raise ValueError("status 必须为 success/failed/cancelled")
        return v

    @model_validator(mode="after")
    def validate_time_range(self) -> "RequestLogQuery":
        if self.start_time and self.end_time:
            from datetime import datetime
            try:
                s = datetime.fromisoformat(self.start_time)
                e = datetime.fromisoformat(self.end_time)
            except ValueError:
                raise ValueError("时间格式必须为 ISO8601")
            if s > e:
                raise ValueError("start_time 不能晚于 end_time")
        return self


class RequestLogItem(BaseModel):
    """单次 Gateway 请求记录。"""

    request_id: str
    trace_id: str
    business_id: str | None = None
    model_id: str
    endpoint: str
    status: str
    latency_ms: int
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    retry_count: int = 0
    error_type: str | None = None
    error_message: str | None = None
    created_at: str


class RequestLogPage(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[RequestLogItem]


class ErrorTraceItem(BaseModel):
    """异常链路中的一条异常记录。"""

    trace_id: str
    request_id: str | None = None
    stage: str
    error_type: str
    message: str
    stack_trace: str | None = None
    retry_count: int = 0
    strategy: str | None = None
    created_at: str


class ErrorTraceList(BaseModel):
    trace_id: str
    items: list[ErrorTraceItem]
