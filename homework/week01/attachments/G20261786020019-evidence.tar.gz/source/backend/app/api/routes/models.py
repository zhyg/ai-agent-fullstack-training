"""模型接口：可用模型列表。"""
from fastapi import APIRouter

from app.api.schemas.common import ApiResponse, ok
from app.config import settings
from app.container import container

router = APIRouter(prefix="/models", tags=["models"])


@router.get("", response_model=ApiResponse[dict])
async def list_models():
    """可用模型列表（供应商适配器已就绪的），default 跟随配置。"""
    models = [
        {
            "id": m.id,
            "name": m.name,
            "provider": m.provider,
            "default": m.id == settings.default_model,
        }
        for m in container.gateway.available_models()
    ]
    return ok({"models": models})
