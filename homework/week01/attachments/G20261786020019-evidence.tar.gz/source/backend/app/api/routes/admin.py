"""运维接口：请求记录查询 + 异常链路查询。"""
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query

from app.api.schemas.admin import (
    ErrorTraceItem,
    ErrorTraceList,
    RequestLogItem,
    RequestLogPage,
    RequestLogQuery,
)
from app.api.schemas.common import ApiResponse, ok
from app.container import container

router = APIRouter(prefix="/admin", tags=["admin"])


def _query_params(
    trace_id: Annotated[str | None, Query(description="按 trace_id 过滤")] = None,
    model_id: Annotated[str | None, Query(description="按模型过滤")] = None,
    status: Annotated[str | None, Query(description="按状态过滤 success/failed/cancelled")] = None,
    start_time: Annotated[str | None, Query(description="开始时间 ISO8601")] = None,
    end_time: Annotated[str | None, Query(description="结束时间 ISO8601")] = None,
    page: Annotated[int, Query(ge=1, description="页码，从 1 开始")] = 1,
    page_size: Annotated[int, Query(ge=1, le=100, description="每页条数")] = 20,
) -> RequestLogQuery:
    return RequestLogQuery(
        trace_id=trace_id, model_id=model_id, status=status,
        start_time=start_time, end_time=end_time,
        page=page, page_size=page_size,
    )


@router.get("/requests", response_model=ApiResponse[RequestLogPage])
async def query_requests(query: RequestLogQuery = Depends(_query_params)):
    """请求记录分页查询。"""
    total, rows = await container.db.query_request_logs(query)
    return ok(RequestLogPage(
        total=total,
        page=query.page,
        page_size=query.page_size,
        items=[RequestLogItem(**r) for r in rows],
    ))


@router.get("/traces/{trace_id}", response_model=ApiResponse[ErrorTraceList])
async def get_error_traces(
    trace_id: Annotated[str, Path(..., min_length=1, max_length=64, description="追踪 ID")],
):
    """异常链路：该 trace_id 下所有阶段的异常列表。"""
    rows = await container.db.get_error_traces(trace_id)
    return ok(ErrorTraceList(
        trace_id=trace_id,
        items=[ErrorTraceItem(**r) for r in rows],
    ))
