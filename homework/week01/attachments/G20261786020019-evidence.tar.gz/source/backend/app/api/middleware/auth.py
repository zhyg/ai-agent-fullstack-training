"""鉴权中间件：Authorization Bearer Token 校验（含 SSE 接口）。"""
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from app.config import settings

# 跳过鉴权的路径
_PUBLIC_PATHS = {"/health", "/docs", "/openapi.json", "/redoc"}


def _error(code: str, message: str, status: int) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "code": code,
            "message": message,
            "retryable": False,
            "details": {},
            "trace_id": None,
        },
    )


class AuthMiddleware(BaseHTTPMiddleware):
    """所有 /api 接口需 Authorization: Bearer <token>。"""

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if not path.startswith("/api") or path in _PUBLIC_PATHS:
            return await call_next(request)

        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return _error("1100", "缺少 Authorization Bearer Token", 401)
        token = auth.removeprefix("Bearer ").strip()
        if token != settings.auth_token:
            return _error("1101", "Token 无效", 401)
        return await call_next(request)
