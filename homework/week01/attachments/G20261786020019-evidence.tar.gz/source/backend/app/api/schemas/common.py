"""统一响应格式。"""
from typing import Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    """统一响应：成功 code=0。"""

    code: int = Field(0, description="响应码，0 表示成功")
    message: str = Field("success", description="响应消息")
    data: T | None = Field(None, description="响应数据")


def ok(data: T) -> ApiResponse[T]:
    return ApiResponse(code=0, message="success", data=data)
