"""任务接口 Request/Response DTO（含完整字段校验）。"""
import re
from enum import Enum
from typing import Annotated

from pydantic import BaseModel, Field, field_validator


class TaskStatus(str, Enum):
    """任务状态枚举，限定合法取值范围。"""

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskStartRequest(BaseModel):
    """开始任务请求。"""

    input: Annotated[
        str,
        Field(..., min_length=1, max_length=2000, description="用户任务描述，1~2000 字符"),
    ]
    model_id: Annotated[
        str | None,
        Field(None, min_length=1, max_length=64, description="模型 ID，为空则使用默认模型"),
    ] = None
    max_steps: Annotated[
        int,
        Field(20, ge=1, le=50, description="最大循环步数，1~50"),
    ] = 20

    @field_validator("input")
    @classmethod
    def input_not_whitespace(cls, v: str) -> str:
        """input 不能全为空白字符。"""
        if not v.strip():
            raise ValueError("任务描述不能为空白")
        return v.strip()


class TaskResumeRequest(BaseModel):
    """恢复任务请求。"""

    last_seq: Annotated[
        int,
        Field(..., ge=0, description="最后接收的事件序列号，>= 0"),
    ]
    model_id: Annotated[
        str | None,
        Field(None, min_length=1, max_length=64, description="恢复时切换的模型 ID"),
    ] = None


class SwitchModelRequest(BaseModel):
    """切换模型请求。"""

    model_id: Annotated[
        str,
        Field(..., min_length=1, max_length=64, description="目标模型 ID"),
    ]

    @field_validator("model_id")
    @classmethod
    def model_id_format(cls, v: str) -> str:
        """model_id 只能包含字母、数字、连字符、下划线、点。"""
        if not re.match(r"^[a-zA-Z0-9\-_.]+$", v):
            raise ValueError("model_id 格式不合法")
        return v


class ConfirmToolRequest(BaseModel):
    """危险工具二次确认请求。"""

    step: Annotated[int, Field(..., ge=0, description="对应的步骤序号")]
    tool_name: Annotated[str, Field(..., min_length=1, max_length=64, description="工具名")]
    confirmed: Annotated[bool, Field(..., description="true=确认执行，false=取消执行")]


# ── Response DTO ──
class TaskStartResponse(BaseModel):
    task_id: Annotated[str, Field(..., description="任务 ID")]
    trace_id: Annotated[str, Field(..., description="追踪 ID")]
    status: Annotated[TaskStatus, Field(..., description="任务状态")]


class TaskStopResponse(BaseModel):
    task_id: str
    status: TaskStatus
    last_seq: Annotated[int, Field(..., ge=0, description="最后事件序列号")]


class TaskResumeResponse(BaseModel):
    task_id: str
    status: TaskStatus
    start_seq: Annotated[int, Field(..., ge=0, description="续传起始序列号")]
    in_place: Annotated[
        bool,
        Field(False, description="true=原地续流（暂停中恢复，同一 LLM 流继续）；false=冷恢复（重做中断步骤）"),
    ] = False


class SwitchModelResponse(BaseModel):
    task_id: str
    model_id: str
    effective_on: Annotated[str, Field("next_llm_call", description="生效时机")]


class ConfirmToolResponse(BaseModel):
    task_id: str
    step: int
    tool_name: str
    confirmed: bool
