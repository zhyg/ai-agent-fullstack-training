"""限流中间件：令牌桶，按 token 限流；开始接口与 SSE 接口分别配置。"""
import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from app.config import settings

_SSE_PER_MINUTE = 60  # SSE 资源接口 60 次/分钟


class _TokenBucket:
    """简单令牌桶：按分钟速率匀速补充。"""

    __slots__ = ("capacity", "tokens", "refill_per_sec", "last")

    def __init__(self, per_minute: int):
        self.capacity = float(per_minute)
        self.tokens = float(per_minute)
        self.refill_per_sec = per_minute / 60.0
        self.last = time.monotonic()

    def allow(self) -> bool:
        now = time.monotonic()
        self.tokens = min(
            self.capacity,
            self.tokens + (now - self.last) * self.refill_per_sec,
        )
        self.last = now
        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True
        return False


class RateLimitMiddleware(BaseHTTPMiddleware):
    """令牌桶限流，按 Authorization token 分桶；超限返回 429 + Retry-After。"""

    def __init__(self, app):
        super().__init__(app)
        self._buckets: dict[tuple[str, str], _TokenBucket] = {}

    def _bucket_key_and_limit(self, path: str) -> tuple[str, int]:
        """按接口类别返回 (分桶键, 每分钟限额)。"""
        if path.endswith("/tasks/start"):
            return ("start", settings.rate_limit_per_minute)
        if "/events" in path:
            return ("events", _SSE_PER_MINUTE)
        return ("default", _SSE_PER_MINUTE)

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if not path.startswith("/api"):
            return await call_next(request)

        category, per_minute = self._bucket_key_and_limit(path)
        identity = request.headers.get("Authorization", "anonymous")
        key = (identity, category)
        bucket = self._buckets.get(key)
        if bucket is None or bucket.capacity != float(per_minute):
            bucket = _TokenBucket(per_minute)
            self._buckets[key] = bucket
        if not bucket.allow():
            return JSONResponse(
                status_code=429,
                content={
                    "code": "1200",
                    "message": "请求过于频繁，请 60 秒后重试",
                    "retryable": True,
                    "details": {},
                    "trace_id": getattr(request.state, "trace_id", None),
                },
                headers={"Retry-After": "60"},
            )
        return await call_next(request)
