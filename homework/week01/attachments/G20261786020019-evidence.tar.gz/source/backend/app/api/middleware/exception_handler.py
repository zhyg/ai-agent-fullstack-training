"""全局异常处理器：所有异常转换为统一响应格式。"""
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.core.exceptions import AppException, ErrorCode


def register_exception_handlers(app: FastAPI) -> None:
    """注册三类异常处理器：AppException / 参数校验 / 未预期异常。"""

    @app.exception_handler(AppException)
    async def app_exception_handler(request: Request, exc: AppException):
        headers = {}
        if exc.code == ErrorCode.RATE_LIMITED and getattr(exc, "retry_after", None):
            headers["Retry-After"] = str(exc.retry_after)
        return JSONResponse(
            status_code=exc.http_status,
            content={
                "code": exc.code.value,
                "message": exc.message,
                "retryable": exc.retryable,
                "details": exc.details,
                "trace_id": getattr(request.state, "trace_id", None),
            },
            headers=headers,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={
                "code": ErrorCode.VALIDATION_ERROR.value,
                "message": "请求参数校验失败",
                "retryable": False,
                "details": {"errors": exc.errors()},
                "trace_id": getattr(request.state, "trace_id", None),
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        return JSONResponse(
            status_code=500,
            content={
                "code": ErrorCode.INTERNAL_ERROR.value,
                "message": "服务器内部错误",
                "retryable": False,
                "details": {},
                "trace_id": getattr(request.state, "trace_id", None),
            },
        )
