"""全局配置：敏感信息从环境变量读取，不写入代码。"""
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core.exceptions import ConfigurationError


class Settings(BaseSettings):
    """全局配置，敏感字段从环境变量读取，不写入代码。"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── 服务配置（非敏感）──
    host: str = Field("0.0.0.0", description="服务监听地址")
    port: int = Field(8000, ge=1, le=65535, description="服务端口")
    debug: bool = Field(False, description="调试模式")

    # ── 鉴权（敏感）──
    auth_token: str = Field(..., description="API 鉴权 Token，从环境变量读取")

    # ── 限流（非敏感）──
    rate_limit_per_minute: int = Field(10, ge=1, le=1000, description="每分钟限流次数")

    # ── 模型配置（混合）──
    default_model: str = Field("gpt-4o", description="默认模型 ID")
    openai_api_key: str = Field(..., description="OpenAI API Key，敏感，从环境变量读取")
    openai_base_url: str = Field("https://api.openai.com/v1", description="OpenAI Base URL")
    anthropic_api_key: str | None = Field(None, description="Anthropic API Key，敏感")
    anthropic_base_url: str = Field("https://api.anthropic.com", description="Anthropic Base URL")
    deepseek_api_key: str | None = Field(None, description="DeepSeek API Key，敏感")
    deepseek_base_url: str = Field("https://api.deepseek.com/v1", description="DeepSeek Base URL")

    # ── 数据库（敏感）──
    database_url: str = Field("sqlite:///./agent.db", description="数据库连接串，含密码时为敏感")

    # ── Agent 运行参数（非敏感）──
    agent_max_steps: int = Field(20, ge=1, le=50, description="Agent 最大循环步数")
    llm_max_retries: int = Field(3, ge=0, le=10, description="LLM 最大重试次数")
    llm_base_delay: float = Field(1.0, ge=0.1, le=60.0, description="重试退避基数（秒）")
    llm_max_tokens: int = Field(4096, ge=1, le=128000, description="LLM 最大输出 token")

    # ── 工具配置（敏感）──
    send_email_smtp_host: str | None = Field(None, description="SMTP 主机，如 smtp.qq.com")
    send_email_smtp_port: int = Field(465, ge=1, le=65535, description="SMTP 端口，465(SSL)/587(STARTTLS)")
    send_email_smtp_use_ssl: bool = Field(True, description="是否使用 SSL，465 端口通常为 True")
    send_email_smtp_user: str | None = Field(None, description="SMTP 用户名，须为完整邮箱地址")
    send_email_smtp_password: str | None = Field(None, description="SMTP 授权码（非登录密码），敏感")
    send_email_from_name: str | None = Field(None, description="发件人显示名称")
    web_search_api_key: str | None = Field(None, description="搜索 API Key，敏感")


settings = Settings()


def validate_sensitive_config(s: Settings) -> None:
    """启动时校验敏感配置，缺失则终止。"""
    missing: list[str] = []
    if not s.auth_token:
        missing.append("AUTH_TOKEN")
    if not s.openai_api_key:
        missing.append("OPENAI_API_KEY")
    if missing:
        raise ConfigurationError(
            f"缺少必填敏感配置: {', '.join(missing)}，"
            f"请通过环境变量或 .env 文件设置，切勿写入代码"
        )
