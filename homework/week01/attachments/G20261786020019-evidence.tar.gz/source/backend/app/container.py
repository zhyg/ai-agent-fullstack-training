"""依赖容器：全局单例，负责启动初始化与关闭清理。"""
from app.config import settings, validate_sensitive_config
from app.core.orchestrator import Orchestrator
from app.infra.db import Database
from app.infra.logger import get_logger
from app.llm.adapter.anthropic_adapter import AnthropicAdapter
from app.llm.adapter.base import BaseLLMAdapter
from app.llm.adapter.openai_adapter import DeepSeekAdapter, OpenAIAdapter
from app.llm.gateway import LLMGateway
from app.llm.retry import RetryConfig
from app.services.event_buffer import EventBuffer
from app.services.task_service import TaskService


class Container:
    """组装各层依赖：配置校验 → DB → 适配器 → Gateway → 服务 → 编排器。"""

    def __init__(self) -> None:
        self.db: Database | None = None
        self.gateway: LLMGateway | None = None
        self.event_buffer: EventBuffer | None = None
        self.task_service: TaskService | None = None
        self.orchestrator: Orchestrator | None = None
        self.logger = get_logger("agent")

    async def startup(self) -> None:
        # ① 敏感配置校验，缺失则终止
        validate_sensitive_config(settings)

        # ② 数据库初始化
        self.db = Database(settings.database_url)
        await self.db.init()

        # ③ 构建供应商适配器（openai 必有，其余按 Key 配置）
        retry_config = RetryConfig(
            max_retries=settings.llm_max_retries,
            base_delay=settings.llm_base_delay,
        )
        adapters: dict[str, BaseLLMAdapter] = {
            "openai": OpenAIAdapter(
                api_key=settings.openai_api_key,
                base_url=settings.openai_base_url,
                retry_config=retry_config,
            ),
        }
        if settings.anthropic_api_key:
            adapters["anthropic"] = AnthropicAdapter(
                api_key=settings.anthropic_api_key,
                base_url=settings.anthropic_base_url,
                retry_config=retry_config,
            )
        if settings.deepseek_api_key:
            adapters["deepseek"] = DeepSeekAdapter(
                api_key=settings.deepseek_api_key,
                base_url=settings.deepseek_base_url,
                retry_config=retry_config,
            )

        # ④ Gateway / 服务 / 编排器
        self.gateway = LLMGateway(adapters, self.db, self.logger)
        self.event_buffer = EventBuffer(self.db)
        self.task_service = TaskService(self.db)
        self.event_buffer.set_active_probe(
            lambda task_id: self.task_service.get(task_id) is not None
        )
        self.orchestrator = Orchestrator(
            self.gateway, self.task_service, self.event_buffer, self.logger
        )
        self.logger.info(
            "container_started",
            providers=list(adapters.keys()),
            default_model=settings.default_model,
        )

    async def shutdown(self) -> None:
        if self.gateway is not None:
            await self.gateway.aclose()
        if self.db is not None:
            await self.db.close()
        self.logger.info("container_shutdown")


# 全局单例
container = Container()
