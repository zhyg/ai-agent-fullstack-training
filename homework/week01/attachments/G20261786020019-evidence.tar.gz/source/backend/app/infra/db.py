"""数据库：aiosqlite 原生 SQL，开发用 SQLite（生产可替换 PostgreSQL）。"""
import asyncio
import json
from datetime import datetime, timezone

import aiosqlite


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


_SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    task_id TEXT PRIMARY KEY,
    trace_id TEXT NOT NULL,
    input TEXT NOT NULL,
    model_id TEXT NOT NULL,
    max_steps INTEGER NOT NULL,
    status TEXT NOT NULL,
    business_id TEXT,
    current_step INTEGER NOT NULL DEFAULT 0,
    conversation_history TEXT NOT NULL DEFAULT '[]',
    executed_steps TEXT NOT NULL DEFAULT '[]',
    last_seq INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS task_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    seq INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    data TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(task_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_task_events_task ON task_events(task_id, seq);

CREATE TABLE IF NOT EXISTS llm_request_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    business_id TEXT,
    model_id TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    status TEXT NOT NULL,
    latency_ms INTEGER NOT NULL,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    retry_count INTEGER NOT NULL DEFAULT 0,
    error_type TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_request_logs_trace ON llm_request_logs(trace_id);
CREATE INDEX IF NOT EXISTS idx_request_logs_created ON llm_request_logs(created_at);

CREATE TABLE IF NOT EXISTS error_traces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    request_id TEXT,
    stage TEXT NOT NULL,
    error_type TEXT NOT NULL,
    message TEXT NOT NULL,
    stack_trace TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    strategy TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_error_traces_trace ON error_traces(trace_id);
"""


class Database:
    """SQLite 异步访问层：单连接 + 写锁串行化。"""

    def __init__(self, url: str):
        # 支持 sqlite:///path 与 sqlite:///:memory:
        self._path = url.removeprefix("sqlite:///")
        self._conn: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    async def init(self) -> None:
        self._conn = await aiosqlite.connect(self._path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.executescript(_SCHEMA)
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    def _require_conn(self) -> aiosqlite.Connection:
        assert self._conn is not None, "Database 未初始化，请先调用 init()"
        return self._conn

    # ── 任务快照 ──
    async def upsert_task(self, task: dict) -> None:
        """持久化任务快照（task_id 为主键，存在则覆盖）。"""
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT OR REPLACE INTO tasks (
                    task_id, trace_id, input, model_id, max_steps, status,
                    business_id, current_step, conversation_history,
                    executed_steps, last_seq, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    task["task_id"], task["trace_id"], task["input"],
                    task["model_id"], task["max_steps"], task["status"],
                    task.get("business_id"), task.get("current_step", 0),
                    json.dumps(task.get("conversation_history", []), ensure_ascii=False),
                    json.dumps(task.get("executed_steps", []), ensure_ascii=False),
                    task.get("last_seq", 0),
                    task.get("created_at", _now()), _now(),
                ),
            )
            await conn.commit()

    async def get_task(self, task_id: str) -> dict | None:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT * FROM tasks WHERE task_id = ?", (task_id,)
        ) as cur:
            row = await cur.fetchone()
        if row is None:
            return None
        d = dict(row)
        d["conversation_history"] = json.loads(d["conversation_history"])
        d["executed_steps"] = json.loads(d["executed_steps"])
        return d

    # ── SSE 事件持久化 ──
    async def insert_event(self, task_id: str, seq: int, event_type: str, data_json: str) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT OR IGNORE INTO task_events (task_id, seq, event_type, data, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (task_id, seq, event_type, data_json, _now()),
            )
            await conn.commit()

    async def get_events(self, task_id: str, after_seq: int = 0) -> list[dict]:
        """按 seq 升序返回 task_id 下 seq > after_seq 的全部事件。"""
        conn = self._require_conn()
        async with conn.execute(
            "SELECT seq, event_type, data FROM task_events "
            "WHERE task_id = ? AND seq > ? ORDER BY seq ASC",
            (task_id, after_seq),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # ── 请求记录 ──
    async def insert_request_log(
        self,
        *,
        request_id: str,
        trace_id: str,
        business_id: str | None,
        model_id: str,
        endpoint: str,
        status: str,
        latency_ms: int,
        prompt_tokens: int,
        completion_tokens: int,
        total_tokens: int,
        retry_count: int,
        error_type: str | None,
        error_message: str | None,
    ) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT INTO llm_request_logs (
                    request_id, trace_id, business_id, model_id, endpoint,
                    status, latency_ms, prompt_tokens, completion_tokens,
                    total_tokens, retry_count, error_type, error_message, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    request_id, trace_id, business_id, model_id, endpoint,
                    status, latency_ms, prompt_tokens, completion_tokens,
                    total_tokens, retry_count, error_type, error_message, _now(),
                ),
            )
            await conn.commit()

    async def query_request_logs(self, query) -> tuple[int, list[dict]]:
        """分页查询请求记录，返回 (total, rows)。query 为 RequestLogQuery。"""
        conn = self._require_conn()
        conditions: list[str] = []
        params: list = []
        if query.trace_id:
            conditions.append("trace_id = ?")
            params.append(query.trace_id)
        if query.model_id:
            conditions.append("model_id = ?")
            params.append(query.model_id)
        if query.status:
            conditions.append("status = ?")
            params.append(query.status)
        if query.start_time:
            conditions.append("created_at >= ?")
            params.append(query.start_time)
        if query.end_time:
            conditions.append("created_at <= ?")
            params.append(query.end_time)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        async with conn.execute(
            f"SELECT COUNT(*) AS c FROM llm_request_logs {where}", params
        ) as cur:
            total = (await cur.fetchone())["c"]

        offset = (query.page - 1) * query.page_size
        async with conn.execute(
            f"SELECT * FROM llm_request_logs {where} "
            "ORDER BY id DESC LIMIT ? OFFSET ?",
            (*params, query.page_size, offset),
        ) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
        return total, rows

    # ── 异常链路 ──
    async def insert_error_trace(
        self,
        *,
        trace_id: str,
        request_id: str | None,
        stage: str,
        error_type: str,
        message: str,
        stack_trace: str | None,
        retry_count: int,
        strategy: str | None,
    ) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT INTO error_traces (
                    trace_id, request_id, stage, error_type, message,
                    stack_trace, retry_count, strategy, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trace_id, request_id, stage, error_type, message,
                    stack_trace, retry_count, strategy, _now(),
                ),
            )
            await conn.commit()

    async def get_error_traces(self, trace_id: str) -> list[dict]:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT * FROM error_traces WHERE trace_id = ? ORDER BY id ASC",
            (trace_id,),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]
