"""OpenTelemetry 追踪：可选依赖，未安装时降级为 no-op。"""
from contextlib import contextmanager
from typing import Any

try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        ConsoleSpanExporter,
    )

    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover - 可选依赖
    _OTEL_AVAILABLE = False


def setup_tracing(app: Any, service_name: str = "personal-agent") -> None:
    """初始化 OTel（若依赖可用）；否则静默跳过。"""
    if not _OTEL_AVAILABLE:
        return
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
    trace.set_tracer_provider(provider)


@contextmanager
def span(name: str, **attributes):
    """创建一个 Span；OTel 不可用时为 no-op。"""
    if not _OTEL_AVAILABLE:
        yield None
        return
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span(name) as s:
        for k, v in attributes.items():
            s.set_attribute(k, str(v))
        yield s
