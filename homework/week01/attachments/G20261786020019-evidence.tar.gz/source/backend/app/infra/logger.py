"""structlog 结构化日志：JSON 格式，自动脱敏敏感字段。"""
import logging

import structlog

SENSITIVE_KEYS = {
    "api_key", "token", "password", "authorization", "auth_token",
    "secret", "apikey", "access_token", "smtp_password",
}


def _mask_sensitive(_, __, event_dict: dict) -> dict:
    """日志脱敏：递归掩盖敏感字段值。"""
    def mask(d: dict) -> dict:
        for k, v in list(d.items()):
            kl = str(k).lower()
            if any(s in kl for s in SENSITIVE_KEYS):
                d[k] = "***"
            elif isinstance(v, dict):
                mask(v)
        return d

    return mask(event_dict)


def configure_logging(debug: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.INFO,
        format="%(message)s",
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", key="timestamp"),
            _mask_sensitive,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(ensure_ascii=False),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.DEBUG if debug else logging.INFO
        ),
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "agent"):
    return structlog.get_logger(name)
