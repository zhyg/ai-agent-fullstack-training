"""FastAPI 入口：lifespan 启停 + 中间件 + 路由。"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.middleware.auth import AuthMiddleware
from app.api.middleware.exception_handler import register_exception_handlers
from app.api.middleware.rate_limit import RateLimitMiddleware
from app.api.middleware.trace import TraceMiddleware
from app.api.routes import admin, models, tasks
from app.config import settings
from app.container import container
from app.infra.logger import configure_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging(settings.debug)
    await container.startup()
    yield
    await container.shutdown()


app = FastAPI(
    title="个人助理 Agent",
    version="1.1.0",
    lifespan=lifespan,
)

# ── 中间件（add 顺序 = 执行顺序反向，RateLimit 最外层）──
app.add_middleware(TraceMiddleware)       # 最内层：注入 trace_id
app.add_middleware(AuthMiddleware)        # 中层：鉴权
app.add_middleware(RateLimitMiddleware)   # 最外层：限流
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── 全局异常处理器 ──
register_exception_handlers(app)

# ── 路由 ──
app.include_router(tasks.router, prefix="/api/v1")
app.include_router(models.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")


@app.get("/health")
async def health():
    """健康检查（无需鉴权）。"""
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host=settings.host, port=settings.port)
