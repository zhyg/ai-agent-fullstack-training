"""LLM 适配层输入输出对象 + Agent 决策结构。"""
from enum import Enum
from typing import Annotated

from pydantic import BaseModel, Field, field_validator, model_validator


class Message(BaseModel):
    """对话消息。"""

    role: Annotated[str, Field(..., description="角色: system/user/assistant/tool")]
    content: Annotated[str, Field(..., description="消息内容")]
    name: Annotated[str | None, Field(None, description="可选名称（工具名等）")] = None


class ToolDef(BaseModel):
    """工具定义，供模型理解。"""

    name: Annotated[str, Field(..., min_length=1, max_length=64, description="工具名，唯一")]
    description: Annotated[str, Field("", description="工具描述")]
    parameters: Annotated[dict, Field(default_factory=dict, description="参数 JSON Schema")]


class ToolCall(BaseModel):
    """模型返回的工具调用。"""

    id: Annotated[str, Field("", description="工具调用 ID")] = ""
    name: Annotated[str, Field(..., description="工具名")]
    arguments: Annotated[dict, Field(default_factory=dict, description="工具参数")]


class TokenUsage(BaseModel):
    """token 用量。"""

    prompt_tokens: Annotated[int, Field(0, ge=0, description="输入 token")] = 0
    completion_tokens: Annotated[int, Field(0, ge=0, description="输出 token")] = 0
    total_tokens: Annotated[int, Field(0, ge=0, description="总 token")] = 0


class ResponseFormat(BaseModel):
    """结构化输出格式。"""

    type: Annotated[str, Field("json_object", description="json_object / json_schema")] = "json_object"
    json_schema: Annotated[dict | None, Field(None, description="JSON Schema 定义")] = None


class LLMRequest(BaseModel):
    """适配层统一入参。"""

    model_id: Annotated[str, Field(..., min_length=1, max_length=64, description="模型 ID")]
    messages: Annotated[list[Message], Field(..., min_length=1, description="消息列表，至少 1 条")]
    temperature: Annotated[float, Field(0.7, ge=0.0, le=2.0, description="温度，0~2")] = 0.7
    max_tokens: Annotated[int, Field(4096, ge=1, le=128000, description="最大输出 token")] = 4096
    stream: Annotated[bool, Field(False, description="是否流式")] = False
    response_format: ResponseFormat | None = None
    tools: list[ToolDef] | None = None
    metadata: dict = Field(default_factory=dict, description="透传元数据")


class LLMResponse(BaseModel):
    """适配层统一出参。"""

    content: Annotated[str, Field("", description="文本内容")] = ""
    finish_reason: Annotated[str, Field(..., description="结束原因: stop/length/tool_calls/content_filter")]
    usage: TokenUsage = Field(default_factory=TokenUsage)
    tool_calls: list[ToolCall] | None = None
    raw: dict = Field(default_factory=dict, description="供应商原始响应")
    provider_request_id: str | None = Field(None, description="供应商响应 ID")

    @field_validator("finish_reason")
    @classmethod
    def validate_finish_reason(cls, v: str) -> str:
        if v not in {"stop", "length", "tool_calls", "content_filter"}:
            raise ValueError(f"非法 finish_reason: {v}")
        return v


class LLMChunk(BaseModel):
    """流式输出分片。"""

    content: Annotated[str, Field("", description="增量文本")] = ""
    finish_reason: str | None = None
    usage: TokenUsage | None = Field(None, description="累计用量，流结束时的末分片携带")


# ── Agent 决策结构 ──
class ActionType(str, Enum):
    TOOL_CALL = "tool_call"
    FINAL_ANSWER = "final_answer"
    NEED_CLARIFICATION = "need_clarification"


class StepRecord(BaseModel):
    """已执行步骤记录。"""

    step: Annotated[int, Field(..., ge=0, description="步骤序号")]
    thought: Annotated[str, Field("", description="思考过程")] = ""
    action: Annotated[str, Field(..., description="动作类型")]
    tool_name: str | None = None
    tool_args: dict | None = None
    tool_summary: Annotated[str, Field("", description="工具结果摘要")] = ""


class AgentDecisionInput(BaseModel):
    """请求大模型做下一步决策的输入结构。"""

    task: Annotated[str, Field(..., description="用户原始任务")]
    current_step: Annotated[int, Field(..., ge=0, description="当前步骤序号")]
    executed_steps: list[StepRecord] = Field(default_factory=list, description="已执行步骤")
    available_tools: list[ToolDef] = Field(default_factory=list, description="可用工具")
    constraints: list[str] = Field(default_factory=list, description="约束条件")


class AgentDecisionOutput(BaseModel):
    """大模型决策输出，必须可被 Pydantic 校验。"""

    thought: Annotated[str, Field(..., description="思考过程")]
    action: Annotated[ActionType, Field(..., description="动作类型")]
    tool_name: str | None = Field(None, description="工具名（action=tool_call 时必填）")
    tool_args: dict | None = Field(None, description="工具参数（action=tool_call 时必填）")
    answer: str | None = Field(None, description="最终答案（action=final_answer 时必填）")
    is_done: Annotated[bool, Field(..., description="任务是否完成")]

    @model_validator(mode="after")
    def validate_action_consistency(self) -> "AgentDecisionOutput":
        if self.action == ActionType.TOOL_CALL:
            if not self.tool_name:
                raise ValueError("action=tool_call 时 tool_name 必填")
            if self.tool_args is None:
                raise ValueError("action=tool_call 时 tool_args 必填")
        if self.action == ActionType.FINAL_ANSWER:
            if not self.answer:
                raise ValueError("action=final_answer 时 answer 必填")
            if not self.is_done:
                raise ValueError("action=final_answer 时 is_done 必须为 True")
        return self


class ValidationErrorResponse(BaseModel):
    """Schema 校验失败时的结构化返回。"""

    error_type: str = "schema_validation_failed"
    message: str
    original_output: str
    errors: list[dict] = Field(default_factory=list, description="Pydantic 校验错误详情")
