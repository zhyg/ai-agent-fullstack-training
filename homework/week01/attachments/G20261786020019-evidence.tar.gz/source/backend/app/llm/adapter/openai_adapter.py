"""OpenAI 协议适配器（兼容 OpenAI / DeepSeek 等 OpenAI 协议供应商）。"""
import json
from collections.abc import AsyncIterator

import openai
from openai import AsyncOpenAI

from app.core.exceptions import (
    LLMAuthFailedException,
    LLMModelForbiddenException,
    LLMNetworkErrorException,
    LLMOverloadException,
    LLMProviderErrorException,
    LLMRateLimitedException,
    LLMTimeoutException,
)
from app.llm.adapter.base import BaseLLMAdapter
from app.llm.retry import RetryConfig
from app.llm.schemas import LLMChunk, LLMRequest, LLMResponse, TokenUsage, ToolCall


class OpenAIAdapter(BaseLLMAdapter):
    """基于 AsyncOpenAI SDK 的适配器，兼容所有 OpenAI 协议供应商。"""

    provider = "openai"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        retry_config: RetryConfig | None = None,
        provider: str = "openai",
    ):
        super().__init__(retry_config)
        self.provider = provider
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    async def _invoke_once(self, req: LLMRequest) -> LLMResponse:
        kwargs: dict = {
            "model": req.model_id,
            "messages": [
                {k: v for k, v in m.model_dump().items() if v is not None}
                for m in req.messages
            ],
            "temperature": req.temperature,
            "max_tokens": req.max_tokens,
        }
        if req.response_format is not None:
            kwargs["response_format"] = {"type": req.response_format.type}
        if req.tools:
            kwargs["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    },
                }
                for t in req.tools
            ]

        try:
            resp = await self._client.chat.completions.create(**kwargs)
        except openai.AuthenticationError as e:
            raise LLMAuthFailedException(f"LLM 认证失败: {self._safe_msg(e)}") from e
        except openai.PermissionDeniedError as e:
            raise LLMModelForbiddenException(req.model_id, self._safe_msg(e)) from e
        except openai.RateLimitError as e:
            retry_after = self._parse_retry_after(e)
            quota = "insufficient_quota" in str(e).lower() or "quota" in str(e).lower()
            raise LLMRateLimitedException(retry_after=retry_after, quota_exceeded=quota) from e
        except openai.APITimeoutError as e:
            raise LLMTimeoutException(f"LLM 调用超时: {self._safe_msg(e)}") from e
        except openai.APIConnectionError as e:
            raise LLMNetworkErrorException(f"LLM 网络连接失败: {self._safe_msg(e)}") from e
        except openai.InternalServerError as e:
            raise LLMOverloadException(f"LLM 服务过载: {self._safe_msg(e)}") from e
        except openai.BadRequestError as e:
            raise LLMProviderErrorException(f"LLM 请求参数错误: {self._safe_msg(e)}") from e
        except openai.APIError as e:
            raise LLMProviderErrorException(f"LLM 供应商错误: {self._safe_msg(e)}") from e

        choice = resp.choices[0]
        tool_calls: list[ToolCall] | None = None
        if choice.message.tool_calls:
            tool_calls = []
            for tc in choice.message.tool_calls:
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except (ValueError, TypeError):
                    args = {"_raw": tc.function.arguments}
                tool_calls.append(ToolCall(id=tc.id or "", name=tc.function.name, arguments=args))

        usage = TokenUsage()
        if resp.usage:
            usage = TokenUsage(
                prompt_tokens=resp.usage.prompt_tokens or 0,
                completion_tokens=resp.usage.completion_tokens or 0,
                total_tokens=resp.usage.total_tokens or 0,
            )

        return LLMResponse(
            content=choice.message.content or "",
            tool_calls=tool_calls,
            finish_reason=choice.finish_reason or "stop",
            usage=usage,
            raw=resp.model_dump(),
            provider_request_id=getattr(resp, "id", None),
        )

    async def stream(self, req: LLMRequest) -> AsyncIterator[LLMChunk]:
        kwargs: dict = {
            "model": req.model_id,
            "messages": [
                {k: v for k, v in m.model_dump().items() if v is not None}
                for m in req.messages
            ],
            "temperature": req.temperature,
            "max_tokens": req.max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        try:
            stream = await self._client.chat.completions.create(**kwargs)
            async for chunk in stream:
                if chunk.usage:
                    # 末分片携带整次调用的用量
                    yield LLMChunk(
                        usage=TokenUsage(
                            prompt_tokens=chunk.usage.prompt_tokens or 0,
                            completion_tokens=chunk.usage.completion_tokens or 0,
                            total_tokens=chunk.usage.total_tokens or 0,
                        ),
                    )
                if not chunk.choices:
                    continue
                delta = chunk.choices[0].delta
                finish = chunk.choices[0].finish_reason
                yield LLMChunk(
                    content=(delta.content or "") if delta else "",
                    finish_reason=finish,
                )
        except openai.APITimeoutError as e:
            raise LLMTimeoutException() from e
        except openai.APIConnectionError as e:
            raise LLMNetworkErrorException() from e
        except openai.APIError as e:
            raise LLMProviderErrorException(f"LLM 供应商错误: {self._safe_msg(e)}") from e

    async def aclose(self) -> None:
        await self._client.close()

    @staticmethod
    def _parse_retry_after(e: openai.RateLimitError) -> int | None:
        try:
            headers = getattr(e.response, "headers", None) or {}
            value = headers.get("retry-after") or headers.get("Retry-After")
            return int(float(value)) if value else None
        except (ValueError, TypeError, AttributeError):
            return None

    @staticmethod
    def _safe_msg(e: BaseException) -> str:
        """异常消息截断，避免泄露敏感信息。"""
        return str(e)[:300]


class DeepSeekAdapter(OpenAIAdapter):
    """DeepSeek 走 OpenAI 兼容协议。"""

    def __init__(self, api_key: str, base_url: str, retry_config: RetryConfig | None = None):
        super().__init__(api_key=api_key, base_url=base_url,
                         retry_config=retry_config, provider="deepseek")
