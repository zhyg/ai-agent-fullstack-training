"""LLM Gateway：所有大模型调用的唯一入口，负责 ID 生成、路由、记录、追踪。"""
import asyncio
import time
import traceback
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from app.core.exceptions import AppException, ModelNotAvailableException, get_error_stage
from app.core.runtime import gen_request_id
from app.llm.adapter.base import BaseLLMAdapter
from app.llm.registry import MODEL_REGISTRY, ModelInfo, get_model_info
from app.llm.schemas import LLMChunk, LLMRequest, LLMResponse, TokenUsage

if TYPE_CHECKING:
    from app.infra.db import Database


class LLMGateway:
    """ID 路由 + 请求记录 + 异常链路写入。"""

    def __init__(
        self,
        adapters: dict[str, BaseLLMAdapter],
        db: "Database",
        logger,
    ):
        self._adapters = adapters
        self._db = db
        self._logger = logger

    def available_models(self) -> list[ModelInfo]:
        """可用模型列表（供应商适配器已就绪的）。"""
        return [m for m in MODEL_REGISTRY.values() if m.provider in self._adapters]

    def _route(self, model_id: str) -> tuple[BaseLLMAdapter, ModelInfo]:
        info = get_model_info(model_id)
        if info is None:
            raise ModelNotAvailableException(model_id)
        adapter = self._adapters.get(info.provider)
        if adapter is None:
            raise ModelNotAvailableException(
                f"{model_id}（供应商 {info.provider} 未配置 API Key）"
            )
        return adapter, info

    async def invoke(
        self,
        req: LLMRequest,
        *,
        trace_id: str,
        business_id: str | None = None,
    ) -> LLMResponse:
        """统一调用入口：生成 request_id → 路由适配器 → 记录请求日志/异常链路。"""
        request_id = gen_request_id()
        adapter, info = self._route(req.model_id)
        provider_req = req.model_copy(update={"model_id": info.provider_model})

        start = time.perf_counter()
        status = "success"
        error_type: str | None = None
        error_message: str | None = None
        usage = None
        resp: LLMResponse | None = None

        try:
            resp = await adapter.invoke(provider_req)
            usage = resp.usage
            return resp
        except asyncio.CancelledError:
            status = "cancelled"
            raise
        except AppException as e:
            status = "failed"
            error_type = e.code.value
            error_message = e.message
            strategy = (
                f"retry_exhausted({adapter.last_retry_count})"
                if e.retryable else "no_retry_terminated"
            )
            await self._db.insert_error_trace(
                trace_id=trace_id,
                request_id=request_id,
                stage=get_error_stage(e),
                error_type=error_type,
                message=e.message,
                stack_trace=traceback.format_exc(),
                retry_count=adapter.last_retry_count,
                strategy=strategy,
            )
            self._logger.error(
                "llm_invoke_failed",
                trace_id=trace_id,
                request_id=request_id,
                model_id=req.model_id,
                error_type=error_type,
                message=e.message,
            )
            raise
        finally:
            latency_ms = int((time.perf_counter() - start) * 1000)
            await self._db.insert_request_log(
                request_id=request_id,
                trace_id=trace_id,
                business_id=business_id,
                model_id=req.model_id,
                endpoint=f"{info.provider}/chat",
                status=status,
                latency_ms=latency_ms,
                prompt_tokens=usage.prompt_tokens if usage else 0,
                completion_tokens=usage.completion_tokens if usage else 0,
                total_tokens=usage.total_tokens if usage else 0,
                retry_count=adapter.last_retry_count,
                error_type=error_type,
                error_message=error_message,
            )

    async def stream(
        self,
        req: LLMRequest,
        *,
        trace_id: str,
        business_id: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        """流式调用（记录日志但不重试，重试边界在非流式 invoke）。"""
        request_id = gen_request_id()
        adapter, info = self._route(req.model_id)
        provider_req = req.model_copy(update={"model_id": info.provider_model})
        start = time.perf_counter()
        status = "success"
        error_type: str | None = None
        error_message: str | None = None
        usage = TokenUsage()
        try:
            async for chunk in adapter.stream(provider_req):
                if chunk.usage is not None:
                    usage = chunk.usage
                yield chunk
        except asyncio.CancelledError:
            status = "cancelled"
            raise
        except AppException as e:
            status = "failed"
            error_type = e.code.value
            error_message = e.message
            raise
        finally:
            latency_ms = int((time.perf_counter() - start) * 1000)
            await self._db.insert_request_log(
                request_id=request_id,
                trace_id=trace_id,
                business_id=business_id,
                model_id=req.model_id,
                endpoint=f"{info.provider}/chat_stream",
                status=status,
                latency_ms=latency_ms,
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                total_tokens=usage.total_tokens,
                retry_count=0,
                error_type=error_type,
                error_message=error_message,
            )

    async def aclose(self) -> None:
        for adapter in self._adapters.values():
            await adapter.aclose()
