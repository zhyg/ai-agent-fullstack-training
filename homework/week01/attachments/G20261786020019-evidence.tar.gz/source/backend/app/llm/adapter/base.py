"""LLM 适配器基类：统一 invoke/stream 接口，重试单一边界在本层。"""
import asyncio
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator

from app.core.exceptions import (
    LLMNetworkErrorException,
    LLMOverloadException,
    LLMRateLimitedException,
    LLMRefusedException,
    LLMTimeoutException,
    LLMTruncatedException,
)
from app.llm.retry import RetryConfig, compute_delay
from app.llm.schemas import LLMChunk, LLMRequest, LLMResponse

MAX_OUTPUT_TOKENS = 128000


class BaseLLMAdapter(ABC):
    """模型适配器抽象基类。新增供应商只需实现 _invoke_once / stream。"""

    provider: str = "unknown"

    def __init__(self, retry_config: RetryConfig | None = None):
        self.retry_config = retry_config or RetryConfig()
        self.last_retry_count = 0  # 最近一次调用的重试次数（供 Gateway 记录）

    async def invoke(self, req: LLMRequest) -> LLMResponse:
        """
        统一调用入口，含重试策略：
        - 传输中异常（超时/网络）：指数退避 + jitter，最多 max_retries 次
        - 服务端异常（限流/过载）：尊重 Retry-After，否则退避；配额耗尽不重试
        - 请求前异常（认证/权限/参数）：不重试，直接抛出
        - 生成后异常（拒答/截断）：拒答终止；截断增大 max_tokens 重试一次
        """
        cfg = self.retry_config
        attempts = 0
        truncation_retried = False
        self.last_retry_count = 0
        current_req = req

        while True:
            try:
                resp = await self._invoke_once(current_req)
            except (LLMTimeoutException, LLMNetworkErrorException,
                    LLMOverloadException):
                if attempts >= cfg.max_retries:
                    self.last_retry_count = attempts
                    raise
                await asyncio.sleep(compute_delay(cfg, attempts))
                attempts += 1
                continue
            except LLMRateLimitedException as e:
                if e.quota_exceeded or not e.retryable or attempts >= cfg.max_retries:
                    self.last_retry_count = attempts
                    raise
                delay = compute_delay(cfg, attempts, retry_after=e.retry_after)
                await asyncio.sleep(delay)
                attempts += 1
                continue

            # ── 生成后处理 ──
            if resp.finish_reason == "content_filter":
                self.last_retry_count = attempts
                raise LLMRefusedException("模型因内容策略拒答")
            if resp.finish_reason == "length":
                if not truncation_retried and current_req.max_tokens < MAX_OUTPUT_TOKENS:
                    # 截断先修预算（max_tokens），重试一次
                    current_req = current_req.model_copy(update={
                        "max_tokens": min(current_req.max_tokens * 2, MAX_OUTPUT_TOKENS)
                    })
                    truncation_retried = True
                    attempts += 1
                    continue
                self.last_retry_count = attempts
                raise LLMTruncatedException("LLM 输出被截断（已尝试扩容 max_tokens）")

            self.last_retry_count = attempts
            return resp

    @abstractmethod
    async def _invoke_once(self, req: LLMRequest) -> LLMResponse:
        """单次调用（不重试），供应商异常在此翻译为统一异常体系。"""
        ...

    @abstractmethod
    def stream(self, req: LLMRequest) -> AsyncIterator[LLMChunk]:
        """流式调用，返回增量分片迭代器。"""
        ...

    async def aclose(self) -> None:
        """释放底层连接资源。"""
        return None
