"""Anthropic 适配器（httpx 直连 Messages API）。"""
import json
from collections.abc import AsyncIterator

import httpx

from app.core.exceptions import (
    LLMAuthFailedException,
    LLMModelForbiddenException,
    LLMNetworkErrorException,
    LLMOverloadException,
    LLMProviderErrorException,
    LLMRateLimitedException,
    LLMTimeoutException,
)
from app.llm.adapter.base import BaseLLMAdapter
from app.llm.retry import RetryConfig
from app.llm.schemas import LLMChunk, LLMRequest, LLMResponse, TokenUsage

_STOP_REASON_MAP = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "refusal": "content_filter",
}


class AnthropicAdapter(BaseLLMAdapter):
    provider = "anthropic"

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.anthropic.com",
        retry_config: RetryConfig | None = None,
    ):
        super().__init__(retry_config)
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            timeout=120.0,
        )

    def _build_payload(self, req: LLMRequest) -> dict:
        """构建 Messages API 请求体（invoke 与 stream 共用）。"""
        system_parts = [m.content for m in req.messages if m.role == "system"]
        messages = [
            {"role": m.role, "content": m.content}
            for m in req.messages if m.role in ("user", "assistant")
        ]
        if not messages:
            messages = [{"role": "user", "content": " "}]

        payload: dict = {
            "model": req.model_id,
            "max_tokens": req.max_tokens,
            "messages": messages,
            "temperature": req.temperature,
        }
        if system_parts:
            payload["system"] = "\n".join(system_parts)
        if req.tools:
            payload["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.parameters,
                }
                for t in req.tools
            ]
        if req.response_format is not None:
            # Anthropic 无原生 json_object 模式，通过 system 指令约束
            payload["system"] = (
                payload.get("system", "")
                + "\n你必须只输出合法 JSON，不要输出任何其他内容。"
            ).strip()
        return payload

    def _raise_http_error(self, resp: httpx.Response, model_id: str) -> None:
        """按 HTTP 状态码翻译为统一异常体系。"""
        if resp.status_code == 401:
            raise LLMAuthFailedException(f"LLM 认证失败: {resp.text[:200]}")
        if resp.status_code == 403:
            raise LLMModelForbiddenException(model_id, resp.text[:200])
        if resp.status_code == 429:
            raise LLMRateLimitedException(
                retry_after=self._parse_retry_after(resp),
                quota_exceeded="quota" in resp.text.lower(),
            )
        if resp.status_code in (500, 502, 503, 529):
            raise LLMOverloadException(f"LLM 服务过载: HTTP {resp.status_code}")
        if resp.status_code != 200:
            raise LLMProviderErrorException(
                f"LLM 供应商错误: HTTP {resp.status_code} {resp.text[:200]}"
            )

    async def _invoke_once(self, req: LLMRequest) -> LLMResponse:
        payload = self._build_payload(req)

        try:
            resp = await self._client.post("/v1/messages", json=payload)
        except httpx.TimeoutException as e:
            raise LLMTimeoutException(f"LLM 调用超时: {e}") from e
        except httpx.ConnectError as e:
            raise LLMNetworkErrorException(f"LLM 网络连接失败: {e}") from e

        self._raise_http_error(resp, req.model_id)

        try:
            data = resp.json()
        except ValueError as e:
            raise LLMProviderErrorException(f"供应商响应非 JSON: {resp.text[:200]}") from e

        content = "".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        )
        usage_raw = data.get("usage", {}) or {}
        usage = TokenUsage(
            prompt_tokens=usage_raw.get("input_tokens", 0),
            completion_tokens=usage_raw.get("output_tokens", 0),
            total_tokens=usage_raw.get("input_tokens", 0) + usage_raw.get("output_tokens", 0),
        )
        finish_reason = _STOP_REASON_MAP.get(data.get("stop_reason") or "end_turn", "stop")

        return LLMResponse(
            content=content,
            finish_reason=finish_reason,
            usage=usage,
            raw=data,
            provider_request_id=data.get("id"),
        )

    async def stream(self, req: LLMRequest) -> AsyncIterator[LLMChunk]:
        """SSE 流式调用：逐帧 yield 文本增量，末帧携带用量。"""
        payload = self._build_payload(req)
        payload["stream"] = True

        input_tokens = 0
        output_tokens = 0
        finish_reason = "stop"

        try:
            async with self._client.stream(
                "POST", "/v1/messages", json=payload
            ) as resp:
                if resp.status_code != 200:
                    await resp.aread()
                    self._raise_http_error(resp, req.model_id)

                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    raw = line[5:].strip()
                    if not raw:
                        continue
                    try:
                        event = json.loads(raw)
                    except ValueError:
                        continue

                    etype = event.get("type")
                    if etype == "message_start":
                        usage = (event.get("message") or {}).get("usage") or {}
                        input_tokens = usage.get("input_tokens", 0)
                        output_tokens = usage.get("output_tokens", 0)
                    elif etype == "content_block_delta":
                        delta = event.get("delta") or {}
                        if delta.get("type") == "text_delta" and delta.get("text"):
                            yield LLMChunk(content=delta["text"])
                    elif etype == "message_delta":
                        output_tokens = (event.get("usage") or {}).get(
                            "output_tokens", output_tokens
                        )
                        finish_reason = _STOP_REASON_MAP.get(
                            (event.get("delta") or {}).get("stop_reason") or "end_turn",
                            "stop",
                        )
                    elif etype == "message_stop":
                        yield LLMChunk(
                            finish_reason=finish_reason,
                            usage=TokenUsage(
                                prompt_tokens=input_tokens,
                                completion_tokens=output_tokens,
                                total_tokens=input_tokens + output_tokens,
                            ),
                        )
        except httpx.TimeoutException as e:
            raise LLMTimeoutException(f"LLM 调用超时: {e}") from e
        except httpx.ConnectError as e:
            raise LLMNetworkErrorException(f"LLM 网络连接失败: {e}") from e

    async def aclose(self) -> None:
        await self._client.aclose()

    @staticmethod
    def _parse_retry_after(resp: httpx.Response) -> int | None:
        try:
            value = resp.headers.get("retry-after")
            return int(float(value)) if value else None
        except (ValueError, TypeError):
            return None
