"""模型注册表：model_id → 供应商/真实模型名，Gateway 据此路由。"""
from dataclasses import dataclass


@dataclass(frozen=True)
class ModelInfo:
    id: str              # 对外模型 ID（model_id）
    name: str            # 展示名
    provider: str        # 供应商: openai / anthropic / deepseek
    provider_model: str  # 供应商侧真实模型名
    default: bool = False


MODEL_REGISTRY: dict[str, ModelInfo] = {
    "gpt-4o": ModelInfo(
        id="gpt-4o", name="GPT-4o", provider="openai",
        provider_model="gpt-4o", default=True,
    ),
    "gpt-4o-mini": ModelInfo(
        id="gpt-4o-mini", name="GPT-4o mini", provider="openai",
        provider_model="gpt-4o-mini",
    ),
    "claude-3-5-sonnet": ModelInfo(
        id="claude-3-5-sonnet", name="Claude 3.5 Sonnet", provider="anthropic",
        provider_model="claude-3-5-sonnet-latest",
    ),
    "deepseek-flash": ModelInfo(
        id="deepseek-flash", name="DeepSeek Flash (V4.1)", provider="deepseek",
        provider_model="deepseek-flash",
    ),
    "deepseek-v4-pro": ModelInfo(
        id="deepseek-v4-pro", name="DeepSeek V4 Pro", provider="deepseek",
        provider_model="deepseek-v4-pro",
    ),
    "deepseek-chat": ModelInfo(
        id="deepseek-chat", name="DeepSeek Chat", provider="deepseek",
        provider_model="deepseek-chat",
    ),
}


def get_model_info(model_id: str) -> ModelInfo | None:
    return MODEL_REGISTRY.get(model_id)
