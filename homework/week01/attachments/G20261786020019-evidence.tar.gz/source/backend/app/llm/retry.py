"""重试引擎：指数退避 + jitter，尊重 Retry-After。重试只在 Adapter 层。"""
import random
from dataclasses import dataclass


@dataclass(frozen=True)
class RetryConfig:
    """重试参数（默认值见架构文档 4.1.2）。"""

    max_retries: int = 3          # 最大重试次数（传输中/服务端）
    base_delay: float = 1.0       # 指数退避基数（秒）
    max_delay: float = 30.0       # 最大退避时间（秒）
    jitter: bool = True           # 是否加随机抖动
    retry_after_enabled: bool = True  # 是否尊重 Retry-After 头


def compute_delay(cfg: RetryConfig, retry_count: int, retry_after: float | None = None) -> float:
    """
    计算退避时长。
    - 有 Retry-After 且启用时，直接尊重该值。
    - 否则指数退避 + jitter：min(base * 2^n, max) * random(0.5, 1.5)
    """
    if retry_after is not None and cfg.retry_after_enabled:
        return min(float(retry_after), cfg.max_delay)
    delay = min(cfg.base_delay * (2 ** retry_count), cfg.max_delay)
    if cfg.jitter:
        delay *= random.uniform(0.5, 1.5)
    return delay
