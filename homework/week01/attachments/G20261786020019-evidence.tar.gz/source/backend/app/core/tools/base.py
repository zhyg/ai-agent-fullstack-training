"""工具基类与执行结果对象。"""
from abc import ABC, abstractmethod
from typing import Annotated

from pydantic import BaseModel, Field, ValidationError

from app.core.exceptions import ToolArgsValidationException
from app.llm.schemas import ToolDef


class ToolResult(BaseModel):
    """工具执行结果。"""

    tool_name: Annotated[str, Field(..., description="工具名")]
    success: Annotated[bool, Field(..., description="是否成功")]
    data: Annotated[dict, Field(default_factory=dict, description="结构化结果数据")]
    summary: Annotated[str, Field("", description="供 LLM 阅读的摘要")]
    error: Annotated[str | None, Field(None, description="失败时的错误信息")] = None


class BaseTool(ABC):
    """工具接口：唯一名 + 描述 + 参数 Schema + 异步执行。"""

    name: str                          # 工具名，唯一
    description: str                   # 工具描述，供模型理解
    args_schema: type[BaseModel]       # 参数 Schema（Pydantic）
    requires_confirmation: bool = False  # 危险工具：执行前需二次确认

    @abstractmethod
    async def execute(self, args: dict) -> ToolResult:
        """执行工具，参数已按 args_schema 校验。"""
        ...

    def validate_args(self, args: dict) -> BaseModel:
        """用 args_schema 校验工具参数，失败抛 ToolArgsValidationException。"""
        try:
            return self.args_schema(**args)
        except ValidationError as e:
            raise ToolArgsValidationException(self.name, e.errors()) from e

    def to_tool_def(self) -> ToolDef:
        """转换为供模型理解的工具定义。"""
        return ToolDef(
            name=self.name,
            description=self.description,
            parameters=self.args_schema.model_json_schema(),
        )
