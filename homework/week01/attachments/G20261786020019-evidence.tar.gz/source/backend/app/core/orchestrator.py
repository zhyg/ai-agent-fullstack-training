"""任务编排器：任务生命周期管理（开始/暂停/恢复/切换模型/工具确认）。"""
import asyncio
import contextlib
from datetime import datetime, timezone

from app.api.schemas.task import (
    ConfirmToolRequest,
    ConfirmToolResponse,
    SwitchModelRequest,
    SwitchModelResponse,
    TaskResumeRequest,
    TaskResumeResponse,
    TaskStartRequest,
    TaskStartResponse,
    TaskStatus,
    TaskStopResponse,
)
from app.api.schemas.sse import SSEEventType, TaskStartedData
from app.config import settings
from app.core.exceptions import (
    ErrorCode,
    ModelNotAvailableException,
    ResourceNotFoundException,
    TaskStateException,
)
from app.core.loop import AgentLoop
from app.core.runtime import TaskRuntime, gen_task_id, gen_trace_id, transition_status
from app.llm.gateway import LLMGateway
from app.llm.registry import get_model_info
from app.services.event_buffer import EventBuffer
from app.services.task_service import RunningTask, TaskService


class Orchestrator:
    """生成 task_id/trace_id，异步启动 Agent Loop，协调取消/恢复/确认。"""

    def __init__(
        self,
        gateway: LLMGateway,
        task_service: TaskService,
        event_buffer: EventBuffer,
        logger,
    ):
        self._gateway = gateway
        self._task_service = task_service
        self._event_buffer = event_buffer
        self._logger = logger

    # ── 开始任务 ──
    async def start(self, req: TaskStartRequest, *, business_id: str | None = None) -> TaskStartResponse:
        model_id = req.model_id or settings.default_model
        if get_model_info(model_id) is None:
            raise ModelNotAvailableException(model_id)

        now = datetime.now(timezone.utc)
        runtime = TaskRuntime(
            task_id=gen_task_id(),
            trace_id=gen_trace_id(),
            input=req.input,
            model_id=model_id,
            max_steps=req.max_steps,
            status=TaskStatus.PENDING,
            business_id=business_id,
            created_at=now,
            updated_at=now,
        )
        running = RunningTask(runtime=runtime)
        self._task_service.register(running)
        await self._event_buffer.open_task(runtime.task_id)

        transition_status(runtime.status, TaskStatus.RUNNING)
        runtime.status = TaskStatus.RUNNING
        seq = await self._event_buffer.publish(
            runtime.task_id, SSEEventType.TASK_STARTED,
            TaskStartedData(
                task_id=runtime.task_id,
                trace_id=runtime.trace_id,
                model_id=model_id,
            ).model_dump(),
        )
        runtime.last_seq = seq
        await self._task_service.snapshot(runtime)

        # 异步启动任务循环，立即返回 task_id
        running.runner = asyncio.create_task(self._run(running))
        self._logger.info(
            "task_started", task_id=runtime.task_id,
            trace_id=runtime.trace_id, model_id=model_id,
        )
        return TaskStartResponse(
            task_id=runtime.task_id,
            trace_id=runtime.trace_id,
            status=runtime.status,
        )

    async def _run(self, running: RunningTask) -> None:
        try:
            loop = AgentLoop(
                self._gateway, self._event_buffer, self._task_service, self._logger
            )
            await loop.run(running)
        finally:
            self._task_service.unregister(running.runtime.task_id)

    # ── 暂停任务（保留会话，不终止循环）──
    async def stop(self, task_id: str) -> TaskStopResponse:
        running = self._task_service.get(task_id)
        if running is None:
            # 内存中不存在：区分"任务不存在"与"任务已结束"
            rt = await self._task_service.load_runtime(task_id)
            if rt is None:
                raise ResourceNotFoundException("任务", task_id)
            raise TaskStateException(
                f"任务未在运行: {rt.status.value}", ErrorCode.TASK_NOT_RUNNING
            )
        rt = running.runtime
        if rt.status == TaskStatus.PAUSED:
            # 幂等：已暂停直接返回
            return TaskStopResponse(
                task_id=task_id, status=rt.status, last_seq=rt.last_seq
            )
        if rt.status != TaskStatus.RUNNING:
            raise TaskStateException(
                f"任务未在运行: {rt.status.value}", ErrorCode.TASK_NOT_RUNNING
            )
        # 暂停：只清恢复信号，不取消 runner、不发终止事件，循环在下一个帧边界停住
        running.pause()
        # 等循环真正停在帧边界（最多 1s），保证 stop 返回时输出已停止
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(running.paused_ack.wait(), timeout=1.0)
        transition_status(rt.status, TaskStatus.PAUSED)
        rt.status = TaskStatus.PAUSED
        await self._task_service.snapshot(rt)
        self._logger.info(
            "task_paused", task_id=task_id, trace_id=rt.trace_id, last_seq=rt.last_seq,
        )
        return TaskStopResponse(
            task_id=task_id, status=rt.status, last_seq=rt.last_seq
        )

    # ── 恢复任务 ──
    async def resume(self, task_id: str, req: TaskResumeRequest) -> TaskResumeResponse:
        running = self._task_service.get(task_id)
        if running is not None:
            return await self._resume_in_place(running, req)

        # 冷恢复：进程内已无该任务（重启/已结束），按快照重做中断步骤
        rt = await self._task_service.load_runtime(task_id)
        if rt is None:
            raise ResourceNotFoundException("任务", task_id)
        if rt.status not in (TaskStatus.PAUSED, TaskStatus.CANCELLED, TaskStatus.FAILED):
            raise TaskStateException(
                f"当前状态 {rt.status.value} 不可恢复（仅 paused/cancelled/failed 可恢复）",
                ErrorCode.TASK_CANNOT_RESUME,
            )
        if req.model_id:
            if get_model_info(req.model_id) is None:
                raise ModelNotAvailableException(req.model_id)
            rt.model_id = req.model_id

        # 断点可能落在未完成的步骤内：回退到最后一个已执行步骤，恢复后重做该步骤
        rt.current_step = rt.executed_steps[-1].step if rt.executed_steps else 0

        transition_status(rt.status, TaskStatus.RUNNING)
        rt.status = TaskStatus.RUNNING
        running = RunningTask(runtime=rt)
        self._task_service.register(running)
        await self._event_buffer.open_task(task_id)
        await self._task_service.snapshot(rt)

        # 续传起点以服务端真实最新 seq 为准，避免重放上一轮残留的终止事件
        start_seq = await self._event_buffer.latest_seq(task_id) + 1

        # 重新触发任务循环，从断点继续（对话历史/已执行步骤已恢复）
        running.runner = asyncio.create_task(self._run(running))
        self._logger.info(
            "task_resumed", task_id=task_id, trace_id=rt.trace_id,
            from_seq=req.last_seq, start_seq=start_seq, in_place=False,
        )
        return TaskResumeResponse(
            task_id=task_id, status=rt.status, start_seq=start_seq, in_place=False
        )

    async def _resume_in_place(
        self, running: RunningTask, req: TaskResumeRequest
    ) -> TaskResumeResponse:
        """原地续流：任务仍在内存中且处于暂停，直接唤醒同一个循环。"""
        task_id = running.runtime.task_id
        rt = running.runtime
        if rt.status == TaskStatus.RUNNING:
            raise TaskStateException(
                "任务已在运行中", ErrorCode.TASK_ALREADY_RUNNING
            )
        if rt.status != TaskStatus.PAUSED:
            raise TaskStateException(
                f"当前状态 {rt.status.value} 不可原地恢复", ErrorCode.TASK_CANNOT_RESUME,
            )
        if req.model_id:
            if get_model_info(req.model_id) is None:
                raise ModelNotAvailableException(req.model_id)
            rt.model_id = req.model_id

        transition_status(rt.status, TaskStatus.RUNNING)
        rt.status = TaskStatus.RUNNING
        running.resume()
        await self._task_service.snapshot(rt)
        start_seq = await self._event_buffer.latest_seq(task_id) + 1
        self._logger.info(
            "task_resumed_in_place", task_id=task_id, trace_id=rt.trace_id,
            from_seq=req.last_seq, start_seq=start_seq,
        )
        return TaskResumeResponse(
            task_id=task_id, status=rt.status, start_seq=start_seq, in_place=True
        )

    # ── 切换模型（下一轮 LLM 调用生效）──
    async def switch_model(self, task_id: str, req: SwitchModelRequest) -> SwitchModelResponse:
        running = self._require_running(task_id)
        if get_model_info(req.model_id) is None:
            raise ModelNotAvailableException(req.model_id)
        running.runtime.model_id = req.model_id
        await self._task_service.snapshot(running.runtime)
        self._logger.info(
            "model_switched", task_id=task_id, model_id=req.model_id
        )
        return SwitchModelResponse(
            task_id=task_id, model_id=req.model_id, effective_on="next_llm_call"
        )

    # ── 危险工具二次确认 ──
    async def confirm(self, task_id: str, req: ConfirmToolRequest) -> ConfirmToolResponse:
        ok = self._task_service.resolve_confirmation(
            task_id, step=req.step, tool_name=req.tool_name, confirmed=req.confirmed
        )
        if not ok:
            raise TaskStateException(
                "无匹配的待确认工具调用（可能已超时或已完成）"
            )
        return ConfirmToolResponse(
            task_id=task_id, step=req.step,
            tool_name=req.tool_name, confirmed=req.confirmed,
        )

    # ── 内部 ──
    def _require_running(self, task_id: str) -> RunningTask:
        running = self._task_service.get(task_id)
        if running is None:
            raise ResourceNotFoundException("任务", task_id)
        return running
