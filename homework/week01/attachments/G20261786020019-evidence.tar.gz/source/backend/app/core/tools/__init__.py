"""工具注册表：按名索引所有内置工具。"""
from app.core.exceptions import ToolNotFoundException
from app.core.tools.base import BaseTool, ToolResult
from app.core.tools.send_email import SendEmailTool
from app.core.tools.web_search import WebSearchTool

TOOL_REGISTRY: dict[str, BaseTool] = {
    t.name: t
    for t in (WebSearchTool(), SendEmailTool())
}


def get_tool(name: str) -> BaseTool:
    """按名获取工具，不存在则抛 ToolNotFoundException。"""
    tool = TOOL_REGISTRY.get(name)
    if tool is None:
        raise ToolNotFoundException(name)
    return tool


__all__ = ["BaseTool", "ToolResult", "TOOL_REGISTRY", "get_tool"]
