"""统一异常体系：4 类异常（客户端/限流/业务/服务端）+ 统一错误码。"""
from enum import Enum


class ErrorCode(str, Enum):
    """统一错误码，4 位数字，前两位为模块，后两位为序号。"""

    # 通用 10xx
    UNKNOWN_ERROR = "1000"
    INTERNAL_ERROR = "1001"
    CONFIGURATION_ERROR = "1002"

    # 鉴权 11xx
    UNAUTHORIZED = "1100"
    INVALID_TOKEN = "1101"
    TOKEN_EXPIRED = "1102"
    FORBIDDEN = "1103"

    # 限流 12xx
    RATE_LIMITED = "1200"

    # 参数校验 13xx
    VALIDATION_ERROR = "1300"
    INVALID_INPUT = "1301"
    INVALID_MODEL_ID = "1302"
    INVALID_TASK_STATUS = "1303"

    # 任务 14xx
    TASK_NOT_FOUND = "1400"
    TASK_ALREADY_RUNNING = "1401"
    TASK_NOT_RUNNING = "1402"
    TASK_CANNOT_RESUME = "1403"
    TASK_CANCELLED = "1404"

    # LLM 15xx
    LLM_AUTH_FAILED = "1500"
    LLM_TIMEOUT = "1501"
    LLM_RATE_LIMITED = "1502"
    LLM_OVERLOAD = "1503"
    LLM_REFUSED = "1504"
    LLM_TRUNCATED = "1505"
    LLM_SCHEMA_VALIDATION_FAILED = "1506"
    LLM_PROVIDER_ERROR = "1507"
    LLM_MODEL_FORBIDDEN = "1508"       # 无该模型调用权限（403）
    LLM_QUOTA_EXCEEDED = "1509"        # 配额耗尽
    LLM_NETWORK_ERROR = "1510"         # 网络/连接错误

    # 工具 16xx
    TOOL_NOT_FOUND = "1600"
    TOOL_EXECUTION_FAILED = "1601"
    TOOL_ARGS_VALIDATION_FAILED = "1602"
    TOOL_NEEDS_CONFIRMATION = "1603"


class AppException(Exception):
    """应用异常基类。"""

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        http_status: int = 400,
        retryable: bool = False,
        details: dict | None = None,
    ):
        self.code = code
        self.message = message
        self.http_status = http_status
        self.retryable = retryable
        self.details = details or {}
        super().__init__(message)


# ── 客户端异常 ──
class UnauthorizedException(AppException):
    def __init__(self, message: str = "未授权"):
        super().__init__(ErrorCode.UNAUTHORIZED, message, http_status=401)


class InvalidTokenException(AppException):
    def __init__(self, message: str = "Token 无效"):
        super().__init__(ErrorCode.INVALID_TOKEN, message, http_status=401)


class ForbiddenException(AppException):
    def __init__(self, message: str = "无权限"):
        super().__init__(ErrorCode.FORBIDDEN, message, http_status=403)


class ValidationException(AppException):
    def __init__(self, message: str, details: dict | None = None):
        super().__init__(ErrorCode.VALIDATION_ERROR, message,
                         http_status=422, details=details)


class ResourceNotFoundException(AppException):
    def __init__(self, resource: str, resource_id: str):
        super().__init__(ErrorCode.TASK_NOT_FOUND,
                         f"{resource} 不存在: {resource_id}", http_status=404)


# ── 限流异常 ──
class RateLimitException(AppException):
    def __init__(self, retry_after: int = 60):
        super().__init__(ErrorCode.RATE_LIMITED,
                         f"请求过于频繁，请 {retry_after} 秒后重试",
                         http_status=429, retryable=True)
        self.retry_after = retry_after


# ── 业务异常 ──
class TaskStateException(AppException):
    def __init__(self, message: str, code: ErrorCode = ErrorCode.INVALID_TASK_STATUS):
        super().__init__(code, message, http_status=409)


class ModelNotAvailableException(AppException):
    def __init__(self, model_id: str):
        super().__init__(ErrorCode.INVALID_MODEL_ID,
                         f"模型不可用: {model_id}", http_status=400)


# ── LLM 异常 ──
class LLMAuthFailedException(AppException):
    def __init__(self, message: str = "LLM 认证失败"):
        super().__init__(ErrorCode.LLM_AUTH_FAILED, message,
                         http_status=500, retryable=False)


class LLMModelForbiddenException(AppException):
    """无该模型调用权限（403 / model_not_found 权限类）。"""

    def __init__(self, model_id: str, reason: str = "无权限"):
        super().__init__(ErrorCode.LLM_MODEL_FORBIDDEN,
                         f"模型 {model_id} 不可用: {reason}",
                         http_status=500, retryable=False)


class LLMTimeoutException(AppException):
    def __init__(self, message: str = "LLM 调用超时"):
        super().__init__(ErrorCode.LLM_TIMEOUT, message,
                         http_status=504, retryable=True)


class LLMNetworkErrorException(AppException):
    """网络/连接错误。"""

    def __init__(self, message: str = "LLM 网络连接失败"):
        super().__init__(ErrorCode.LLM_NETWORK_ERROR, message,
                         http_status=504, retryable=True)


class LLMRateLimitedException(AppException):
    def __init__(self, retry_after: int | None = None, quota_exceeded: bool = False):
        if quota_exceeded:
            msg = "LLM 配额已耗尽"
            super().__init__(ErrorCode.LLM_QUOTA_EXCEEDED, msg,
                             http_status=503, retryable=False)
        else:
            msg = "LLM 供应商限流"
            if retry_after:
                msg += f"，建议 {retry_after} 秒后重试"
            super().__init__(ErrorCode.LLM_RATE_LIMITED, msg,
                             http_status=503, retryable=True)
        self.retry_after = retry_after
        self.quota_exceeded = quota_exceeded


class LLMOverloadException(AppException):
    def __init__(self, message: str = "LLM 服务过载"):
        super().__init__(ErrorCode.LLM_OVERLOAD, message,
                         http_status=503, retryable=True)


class LLMRefusedException(AppException):
    def __init__(self, message: str = "LLM 拒答"):
        super().__init__(ErrorCode.LLM_REFUSED, message,
                         http_status=500, retryable=False)


class LLMTruncatedException(AppException):
    def __init__(self, message: str = "LLM 输出被截断"):
        super().__init__(ErrorCode.LLM_TRUNCATED, message,
                         http_status=500, retryable=True)


class LLMSchemaValidationException(AppException):
    def __init__(self, message: str, errors: list[dict]):
        super().__init__(ErrorCode.LLM_SCHEMA_VALIDATION_FAILED, message,
                         http_status=500, retryable=True,
                         details={"validation_errors": errors})


class LLMProviderErrorException(AppException):
    """供应商其他错误（如 400 参数错误），请求前阶段，不重试。"""

    def __init__(self, message: str = "LLM 供应商错误"):
        super().__init__(ErrorCode.LLM_PROVIDER_ERROR, message,
                         http_status=500, retryable=False)


# ── 工具异常 ──
class ToolNotFoundException(AppException):
    def __init__(self, tool_name: str):
        super().__init__(ErrorCode.TOOL_NOT_FOUND,
                         f"工具不存在: {tool_name}", http_status=400)


class ToolExecutionException(AppException):
    def __init__(self, tool_name: str, message: str):
        super().__init__(ErrorCode.TOOL_EXECUTION_FAILED,
                         f"工具 {tool_name} 执行失败: {message}",
                         http_status=500, retryable=False)


class ToolArgsValidationException(AppException):
    def __init__(self, tool_name: str, errors: list[dict]):
        super().__init__(ErrorCode.TOOL_ARGS_VALIDATION_FAILED,
                         f"工具 {tool_name} 参数校验失败",
                         http_status=400, details={"errors": errors})


class ToolNeedsConfirmationException(AppException):
    def __init__(self, tool_name: str):
        super().__init__(ErrorCode.TOOL_NEEDS_CONFIRMATION,
                         f"工具 {tool_name} 需要用户二次确认",
                         http_status=400)


# ── 配置异常 ──
class ConfigurationError(AppException):
    def __init__(self, message: str):
        super().__init__(ErrorCode.CONFIGURATION_ERROR, message,
                         http_status=500, retryable=False)


# ── 异常阶段映射（用于 error_traces 表 stage 字段）──
_ERROR_STAGE_MAP: dict[type, str] = {
    LLMAuthFailedException: "pre_request",
    LLMModelForbiddenException: "pre_request",
    LLMProviderErrorException: "pre_request",
    LLMTimeoutException: "in_transit",
    LLMNetworkErrorException: "in_transit",
    LLMRateLimitedException: "server",
    LLMOverloadException: "server",
    LLMRefusedException: "post_generation",
    LLMTruncatedException: "post_generation",
    LLMSchemaValidationException: "post_parsing",
    ToolExecutionException: "post_parsing",
    ToolArgsValidationException: "post_parsing",
}


def get_error_stage(exc: BaseException) -> str:
    """按异常类型推断其所处阶段：pre_request / in_transit / server / post_generation / post_parsing。"""
    for exc_type, stage in _ERROR_STAGE_MAP.items():
        if isinstance(exc, exc_type):
            return stage
    return "unknown"
