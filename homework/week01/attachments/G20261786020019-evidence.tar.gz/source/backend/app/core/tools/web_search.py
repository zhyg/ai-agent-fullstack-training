"""搜索工具：百度千帆 AI 搜索（异步 httpx）。"""
from typing import Annotated

import httpx
from pydantic import BaseModel, Field, field_validator

from app.config import settings
from app.core.exceptions import ToolExecutionException
from app.core.tools.base import BaseTool, ToolResult


class WebSearchArgs(BaseModel):
    query: Annotated[str, Field(..., min_length=1, max_length=500, description="搜索关键词")]
    max_results: Annotated[int, Field(5, ge=1, le=20, description="返回结果条数，1~20")] = 5
    recency_filter: Annotated[str, Field("week", description="时间范围过滤")] = "week"

    @field_validator("recency_filter")
    @classmethod
    def validate_recency(cls, v: str) -> str:
        allowed = {"day", "week", "month", "year", "no_limit"}
        if v not in allowed:
            raise ValueError(f"recency_filter 必须为 {allowed} 之一")
        return v


class WebSearchTool(BaseTool):
    name = "web_search"
    description = "搜索互联网获取最新信息，支持按时间范围过滤"
    args_schema = WebSearchArgs

    API_URL = "https://qianfan.baidubce.com/v2/ai_search/web_search"
    TIMEOUT = 30.0  # 秒

    async def execute(self, args: dict) -> ToolResult:
        validated = self.validate_args(args)
        assert isinstance(validated, WebSearchArgs)
        if not settings.web_search_api_key:
            raise ToolExecutionException(self.name, "搜索 API Key 未配置")

        payload = {
            "messages": [{"role": "user", "content": validated.query}],
            "edition": "standard",
            "search_source": "baidu_search_v2",
            "search_recency_filter": validated.recency_filter,
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {settings.web_search_api_key}",
        }

        try:
            async with httpx.AsyncClient(timeout=self.TIMEOUT) as client:
                resp = await client.post(self.API_URL, json=payload, headers=headers)
        except httpx.TimeoutException:
            raise ToolExecutionException(self.name, "搜索请求超时")
        except httpx.ConnectError:
            raise ToolExecutionException(self.name, "搜索服务连接失败")

        # ── 分层防御：状态码 → Content-Type → JSON 解析 ──
        if resp.status_code != 200:
            raise ToolExecutionException(
                self.name,
                f"搜索接口返回 {resp.status_code}: {resp.text[:200]}",
            )

        content_type = resp.headers.get("Content-Type", "")
        if "application/json" not in content_type:
            raise ToolExecutionException(
                self.name,
                f"响应非 JSON (Content-Type={content_type}): {resp.text[:200]}",
            )

        try:
            data = resp.json()
        except ValueError:
            raise ToolExecutionException(
                self.name, f"响应 JSON 解析失败: {resp.text[:200]}"
            )

        return self._parse_response(data, validated.max_results)

    def _parse_response(self, data: dict, max_results: int) -> ToolResult:
        """解析千帆 AI 搜索 v2 响应：顶层 references 列表。"""
        refs = data.get("references") or []
        items = []
        for r in refs[:max_results]:
            items.append({
                "title": r.get("title", ""),
                "url": r.get("url", ""),
                "snippet": (r.get("content") or "")[:500],
                "source": r.get("web_anchor", r.get("source", "")),
                "date": r.get("date", ""),
            })
        return ToolResult(
            tool_name=self.name,
            success=True,
            data={"items": items},
            summary=f"搜索到 {len(items)} 条结果",
        )
