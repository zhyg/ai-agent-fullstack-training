"""Agent Loop：思考 → 行动 → 观察 循环，直到完成/达上限/被取消。"""
import asyncio
import json
import time
import traceback

from pydantic import ValidationError

from app.api.schemas.sse import (
    CancelledData,
    ErrorData,
    FinalAnswerData,
    SSEEventType,
    TaskFinishedData,
    ThoughtData,
    TokenData,
    ToolCallData,
    ToolConfirmationRequestData,
    ToolResultData,
)
from app.api.schemas.task import TaskStatus
from app.config import settings
from app.core.exceptions import AppException, get_error_stage
from app.core.prompt.renderer import (
    build_correction_message,
    build_decision_message,
    build_system_message,
)
from app.core.prompt.security import sanitize_output
from app.core.runtime import transition_status
from app.core.tools import TOOL_REGISTRY, get_tool
from app.core.tools.base import ToolResult
from app.llm.gateway import LLMGateway
from app.llm.schemas import (
    ActionType,
    AgentDecisionOutput,
    LLMRequest,
    Message,
    ResponseFormat,
    StepRecord,
    TokenUsage,
)
from app.services.event_buffer import EventBuffer
from app.services.task_service import RunningTask, TaskService

MAX_CONSECUTIVE_FAILURES = 3   # 连续 Schema 校验失败上限，防死循环
MAX_CORRECTION_RETRIES = 1     # 单次输出的纠错重试上限（附带错误信息）


class AgentLoop:
    """单任务循环执行器：构建提示词 → LLM 决策 → 执行工具 → 注入上下文。"""

    def __init__(
        self,
        gateway: LLMGateway,
        event_buffer: EventBuffer,
        task_service: TaskService,
        logger,
    ):
        self._gateway = gateway
        self._event_buffer = event_buffer
        self._task_service = task_service
        self._logger = logger

    # ── 事件发布 ──
    async def _publish(self, running: RunningTask, event_type: SSEEventType, data: dict) -> int:
        rt = running.runtime
        seq = await self._event_buffer.publish(rt.task_id, event_type, data)
        rt.last_seq = seq
        return seq

    # ── 主循环 ──
    async def run(self, running: RunningTask) -> None:
        rt = running.runtime
        tool_defs = [t.to_tool_def() for t in TOOL_REGISTRY.values()]
        consecutive_failures = 0
        total_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

        try:
            while True:
                # ① 用户取消检查（每轮循环边界）
                if running.cancel_event.is_set():
                    await self._terminate(running, TaskStatus.CANCELLED)
                    return
                # ② 暂停等待：暂停期间不进入下一轮（不发起新的 LLM 调用）
                await running.wait_if_paused()
                # ③ 最大步数检查
                if rt.current_step >= rt.max_steps:
                    await self._fail(
                        running,
                        error_type="max_steps_exceeded",
                        message=f"达到最大步数 {rt.max_steps}，任务终止",
                    )
                    return

                rt.current_step += 1
                step = rt.current_step

                # ③ 构建提示词并请求 LLM 决策（含纠错重试）
                try:
                    decision, usage = await self._decide(
                        running, tool_defs, consecutive_failures
                    )
                except _SchemaFailuresExhausted:
                    await self._fail(
                        running,
                        error_type="schema_validation_failed",
                        message="连续 Schema 校验失败，任务终止",
                    )
                    return

                consecutive_failures = 0
                for k in total_usage:
                    total_usage[k] += getattr(usage, k, 0)

                # ④ 发布思考事件（输出脱敏）
                await self._publish(
                    running, SSEEventType.THOUGHT,
                    ThoughtData(step=step, content=sanitize_output(decision.thought)).model_dump(),
                )

                # ⑤ 判断动作
                if decision.action in (ActionType.FINAL_ANSWER, ActionType.NEED_CLARIFICATION):
                    answer = decision.answer or decision.thought
                    await self._publish(
                        running, SSEEventType.FINAL_ANSWER,
                        FinalAnswerData(answer=sanitize_output(answer), usage=total_usage).model_dump(),
                    )
                    rt.executed_steps.append(StepRecord(
                        step=step, thought=decision.thought,
                        action=decision.action.value,
                    ))
                    await self._terminate(running, TaskStatus.COMPLETED)
                    return

                # ⑥ 工具调用
                await self._publish(
                    running, SSEEventType.TOOL_CALL,
                    ToolCallData(step=step, tool_name=decision.tool_name,
                                 tool_args=decision.tool_args or {}).model_dump(),
                )
                try:
                    tool = get_tool(decision.tool_name)
                except AppException as e:
                    await self._fail(running, error_type=e.code.value, message=e.message)
                    return

                # 危险工具：二次确认
                if tool.requires_confirmation:
                    await self._publish(
                        running, SSEEventType.TOOL_CONFIRMATION_REQUEST,
                        ToolConfirmationRequestData(
                            step=step, tool_name=tool.name,
                            tool_args=decision.tool_args or {},
                            message=f"请确认是否执行 {tool.name}",
                        ).model_dump(),
                    )
                    confirmed = await self._task_service.wait_confirmation(
                        running, step=step, tool_name=tool.name,
                        tool_args=decision.tool_args or {},
                    )
                    if running.cancel_event.is_set():
                        await self._terminate(running, TaskStatus.CANCELLED)
                        return
                    if not confirmed:
                        # 用户取消/超时：跳过该步骤，进入下一轮决策
                        rt.executed_steps.append(StepRecord(
                            step=step, thought=decision.thought,
                            action=decision.action.value, tool_name=tool.name,
                            tool_args=decision.tool_args,
                            tool_summary="用户未确认，已跳过该工具调用",
                        ))
                        await self._task_service.snapshot(rt)
                        continue

                # 执行工具（暂停期间不发起新的副作用操作）
                await running.wait_if_paused()
                result, duration_ms = await self._execute_tool(
                    tool, decision.tool_args or {}
                )
                await self._publish(
                    running, SSEEventType.TOOL_RESULT,
                    ToolResultData(
                        step=step, tool_name=tool.name,
                        result=result.model_dump(),
                        duration_ms=duration_ms,
                    ).model_dump(),
                )

                # ⑦ 注入上下文
                rt.executed_steps.append(StepRecord(
                    step=step, thought=decision.thought,
                    action=decision.action.value, tool_name=tool.name,
                    tool_args=decision.tool_args,
                    tool_summary=result.summary if result.success else f"工具执行失败: {result.error}",
                ))
                if not result.success:
                    consecutive_failures += 1
                    if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                        await self._fail(
                            running,
                            error_type="tool_execution_failed",
                            message=f"工具连续失败 {MAX_CONSECUTIVE_FAILURES} 次，任务终止",
                        )
                        return
                await self._task_service.snapshot(rt)

        except asyncio.CancelledError:
            # 外部取消（停止接口取消 runner task）
            await self._terminate(running, TaskStatus.CANCELLED)
        except AppException as e:
            self._logger.error(
                "agent_loop_failed",
                trace_id=rt.trace_id, task_id=rt.task_id,
                error_type=e.code.value, message=e.message,
            )
            await self._fail(running, error_type=e.code.value, message=e.message, exc=e)
        except Exception as e:  # 未预期异常兜底
            self._logger.error(
                "agent_loop_unexpected_error",
                trace_id=rt.trace_id, task_id=rt.task_id, exc_info=True,
            )
            await self._fail(running, error_type="internal_error", message=str(e), exc=e)

    # ── LLM 决策（流式增量 + 纠错重试）──
    async def _decide(
        self,
        running: RunningTask,
        tool_defs,
        consecutive_failures: int,
    ) -> tuple[AgentDecisionOutput, TokenUsage]:
        rt = running.runtime
        messages = [
            build_system_message(tool_defs),
            build_decision_message(
                task=rt.input,
                current_step=rt.current_step,
                max_steps=rt.max_steps,
                executed_steps=[s.model_dump() for s in rt.executed_steps],
            ),
        ]
        failures = consecutive_failures
        correction_used = 0

        while True:
            if running.cancel_event.is_set():
                raise asyncio.CancelledError()
            await running.wait_if_paused()
            content, usage = await self._stream_content(running, messages)
            try:
                decision = AgentDecisionOutput.model_validate(json.loads(content))
                return decision, usage
            except (json.JSONDecodeError, ValidationError) as e:
                failures += 1
                if failures >= MAX_CONSECUTIVE_FAILURES or correction_used >= MAX_CORRECTION_RETRIES:
                    raise _SchemaFailuresExhausted() from e
                correction_used += 1
                errors = (
                    e.errors(include_context=False)
                    if isinstance(e, ValidationError)
                    else [{"msg": f"JSON 解析失败: {e}"}]
                )
                messages.append(Message(role="assistant", content=content))
                messages.append(build_correction_message(
                    errors=json.loads(json.dumps(errors, default=str)),
                    original_output=content[:2000],
                ))

    # ── 流式调用：每个增量立即发 token 事件，返回完整文本与用量 ──
    async def _stream_content(
        self,
        running: RunningTask,
        messages: list[Message],
    ) -> tuple[str, TokenUsage]:
        rt = running.runtime
        req = LLMRequest(
            model_id=rt.model_id,
            messages=messages,
            response_format=ResponseFormat(type="json_object"),
            max_tokens=settings.llm_max_tokens,
            stream=True,
        )

        chunks: list[str] = []
        usage = TokenUsage()
        stream = self._gateway.stream(
            req, trace_id=rt.trace_id, business_id=rt.business_id
        )
        iterator = stream.__aiter__()
        try:
            while True:
                # 暂停：不再读取下一个增量（不消费=不发布），底层流保持不动；
                # 恢复后从同一位置继续读，seq 与内容都接着往下走。
                await running.wait_if_paused()
                if running.cancel_event.is_set():
                    raise asyncio.CancelledError()
                try:
                    chunk = await iterator.__anext__()
                except StopAsyncIteration:
                    break
                if chunk.usage is not None:
                    usage = chunk.usage
                if not chunk.content:
                    continue
                chunks.append(chunk.content)
                # 发布前再确认一次暂停：避免"暂停瞬间已读到的帧"继续输出
                await running.wait_if_paused()
                await self._publish(
                    running, SSEEventType.TOKEN,
                    TokenData(content=chunk.content).model_dump(),
                )
        finally:
            await stream.aclose()
        return "".join(chunks), usage

    # ── 工具执行 ──
    async def _execute_tool(self, tool, args: dict) -> tuple[ToolResult, int]:
        """执行工具并返回 (结果, 耗时毫秒)；异常转换为失败结果不中断循环。"""
        start = time.perf_counter()
        try:
            result = await tool.execute(args)
        except AppException as e:
            result = ToolResult(
                tool_name=tool.name, success=False, error=e.message,
                summary=f"工具 {tool.name} 执行失败: {e.message}",
            )
        except Exception as e:
            result = ToolResult(
                tool_name=tool.name, success=False, error=str(e),
                summary=f"工具 {tool.name} 执行异常: {e}",
            )
        return result, int((time.perf_counter() - start) * 1000)

    # ── 终止处理 ──
    async def _terminate(self, running: RunningTask, status: TaskStatus) -> None:
        rt = running.runtime
        if status == TaskStatus.CANCELLED:
            await self._publish(
                running, SSEEventType.CANCELLED,
                CancelledData(last_seq=rt.last_seq).model_dump(),
            )
        transition_status(rt.status, status)
        rt.status = status
        await self._publish(
            running, SSEEventType.TASK_FINISHED,
            TaskFinishedData(status=status.value, total_steps=rt.current_step).model_dump(),
        )
        await self._task_service.snapshot(rt)
        self._logger.info(
            "task_finished", task_id=rt.task_id, trace_id=rt.trace_id,
            status=status.value, total_steps=rt.current_step,
        )

    async def _fail(
        self,
        running: RunningTask,
        *,
        error_type: str,
        message: str,
        exc: AppException | None = None,
    ) -> None:
        rt = running.runtime
        await self._publish(
            running, SSEEventType.ERROR,
            ErrorData(error_type=error_type, message=message,
                      retryable=exc.retryable if exc else False).model_dump(),
        )
        if exc is not None:
            await self._task_service.db.insert_error_trace(
                trace_id=rt.trace_id,
                request_id=None,
                stage=get_error_stage(exc),
                error_type=error_type,
                message=message,
                stack_trace=traceback.format_exc(),
                retry_count=0,
                strategy="terminated",
            )
        await self._terminate(running, TaskStatus.FAILED)


class _SchemaFailuresExhausted(Exception):
    """连续 Schema 校验失败达到上限。"""
