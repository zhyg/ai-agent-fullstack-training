"""运行时对象：TaskRuntime 状态机校验。"""
import uuid
from datetime import datetime, timezone
from typing import Annotated

from pydantic import BaseModel, Field, model_validator

from app.api.schemas.task import TaskStatus
from app.core.exceptions import TaskStateException
from app.llm.schemas import Message, StepRecord

# 合法状态转换
VALID_STATUS_TRANSITIONS: dict[TaskStatus, set[TaskStatus]] = {
    TaskStatus.PENDING: {TaskStatus.RUNNING, TaskStatus.CANCELLED},
    TaskStatus.RUNNING: {
        TaskStatus.COMPLETED, TaskStatus.CANCELLED, TaskStatus.FAILED, TaskStatus.PAUSED,
    },
    TaskStatus.PAUSED: {  # 暂停：等待原地续流
        TaskStatus.RUNNING, TaskStatus.COMPLETED, TaskStatus.CANCELLED, TaskStatus.FAILED,
    },
    TaskStatus.CANCELLED: {TaskStatus.RUNNING},   # 恢复
    TaskStatus.COMPLETED: set(),                   # 终态
    TaskStatus.FAILED: {TaskStatus.RUNNING},       # 重试
}


def transition_status(current: TaskStatus, target: TaskStatus) -> None:
    """状态转换合法性校验，非法则抛 TaskStateException。"""
    if target not in VALID_STATUS_TRANSITIONS.get(current, set()):
        raise TaskStateException(
            f"非法状态转换: {current.value} -> {target.value}"
        )


class TaskRuntime(BaseModel):
    """Agent 核心层运行时对象，承载任务执行状态。"""

    task_id: Annotated[str, Field(..., description="任务 ID")]
    trace_id: Annotated[str, Field(..., description="追踪 ID")]
    input: Annotated[str, Field(..., min_length=1, max_length=2000, description="任务描述")]
    model_id: Annotated[str, Field(..., min_length=1, max_length=64, description="模型 ID")]
    max_steps: Annotated[int, Field(..., ge=1, le=50, description="最大步数")]
    status: Annotated[TaskStatus, Field(..., description="任务状态")]
    business_id: Annotated[str | None, Field(None, description="业务 ID，透传不解析")] = None
    current_step: Annotated[int, Field(0, ge=0, description="当前步骤序号")] = 0
    conversation_history: list[Message] = Field(default_factory=list, description="对话历史")
    executed_steps: list[StepRecord] = Field(default_factory=list, description="已执行步骤")
    last_seq: Annotated[int, Field(0, ge=0, description="最后事件序列号")] = 0
    cancel_event: Annotated[bool, Field(False, description="取消信号")] = False
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="after")
    def validate_step_bounds(self) -> "TaskRuntime":
        if self.current_step > self.max_steps:
            raise ValueError(
                f"current_step({self.current_step}) 不能超过 max_steps({self.max_steps})"
            )
        return self


def gen_task_id() -> str:
    """task_{YYYYMMDD}_{8位随机}"""
    now = datetime.now(timezone.utc)
    return f"task_{now:%Y%m%d}_{uuid.uuid4().hex[:8]}"


def gen_trace_id() -> str:
    """trace_{uuid4 前缀}"""
    return f"trace_{uuid.uuid4().hex[:16]}"


def gen_request_id() -> str:
    """req_{uuid4}"""
    return f"req_{uuid.uuid4().hex}"
