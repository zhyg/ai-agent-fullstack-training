"""提示词安全：防注入转义 + 输出敏感信息脱敏。"""
import re

# 常见敏感信息模式（API Key / Token / 授权码等）
_SENSITIVE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"sk-[A-Za-z0-9_\-]{8,}"),                     # OpenAI 风格 Key
    re.compile(r"Bearer\s+[A-Za-z0-9_\-\.]{8,}", re.IGNORECASE),
    re.compile(r"(?i)(api[_-]?key|token|password|secret|授权码)\s*[:=]\s*\S+"),
]

_MASK = "***REDACTED***"


def escape_user_input(text: str) -> str:
    """转义用户输入中的 XML 特殊字符，防止伪造标签闭合（防提示词注入）。"""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def sanitize_output(text: str) -> str:
    """对模型输出做敏感信息检测并脱敏（API Key、Token 等）。"""
    result = text
    for pattern in _SENSITIVE_PATTERNS:
        result = pattern.sub(_MASK, result)
    return result
