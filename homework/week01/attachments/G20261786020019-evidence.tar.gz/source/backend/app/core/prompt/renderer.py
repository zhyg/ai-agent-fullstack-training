"""模板渲染：构建决策消息与纠错消息。"""
import json

from app.core.prompt.security import escape_user_input
from app.core.prompt.templates import (
    CORRECTION_PROMPT,
    DECISION_PROMPT,
    OUTPUT_FORMAT_DESCRIPTION,
    SYSTEM_PROMPT,
)
from app.llm.schemas import Message, ToolDef


def _format_tools_description(tools: list[ToolDef]) -> str:
    """生成工具清单文本，供模型理解。"""
    if not tools:
        return "（无可用工具）"
    lines = []
    for t in tools:
        params = json.dumps(t.parameters, ensure_ascii=False)
        lines.append(f"- {t.name}: {t.description}，参数 Schema: {params}")
    return "\n".join(lines)


def _format_executed_steps(steps: list[dict]) -> str:
    if not steps:
        return "（尚无已执行步骤）"
    lines = []
    for s in steps:
        line = f"步骤 {s.get('step')}: action={s.get('action')}"
        if s.get("thought"):
            line += f"，思考: {s['thought']}"
        if s.get("tool_name"):
            line += f"，工具: {s['tool_name']}({json.dumps(s.get('tool_args') or {}, ensure_ascii=False)})"
        if s.get("tool_summary"):
            line += f"，结果: {s['tool_summary']}"
        lines.append(line)
    return "\n".join(lines)


def build_system_message(tools: list[ToolDef]) -> Message:
    """System Prompt：角色、准则、可用工具。"""
    return Message(
        role="system",
        content=SYSTEM_PROMPT.format(tools_description=_format_tools_description(tools)),
    )


def build_decision_message(
    *,
    task: str,
    current_step: int,
    max_steps: int,
    executed_steps: list[dict],
) -> Message:
    """决策请求消息：用户输入（转义防注入）+ 运行时上下文 + 输出格式。"""
    content = DECISION_PROMPT.format(
        task=escape_user_input(task),
        current_step=current_step,
        max_steps=max_steps,
        executed_steps=_format_executed_steps(executed_steps),
        output_format=OUTPUT_FORMAT_DESCRIPTION,
    )
    return Message(role="user", content=content)


def build_correction_message(*, errors: list[dict], original_output: str) -> Message:
    """纠错消息：附带校验错误与原始输出，要求重新输出。"""
    content = CORRECTION_PROMPT.format(
        errors=json.dumps(errors, ensure_ascii=False, indent=2),
        original_output=original_output,
    )
    return Message(role="user", content=content)
