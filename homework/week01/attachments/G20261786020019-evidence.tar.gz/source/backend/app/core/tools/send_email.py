"""邮件工具：aiosmtplib 异步 SMTP，危险工具需二次确认。"""
from email.message import EmailMessage
from typing import Annotated

import aiosmtplib
from pydantic import BaseModel, EmailStr, Field

from app.config import settings
from app.core.exceptions import ToolExecutionException
from app.core.tools.base import BaseTool, ToolResult


class SendEmailArgs(BaseModel):
    to: Annotated[EmailStr, Field(..., description="收件人邮箱")]
    subject: Annotated[str, Field(..., min_length=1, max_length=200, description="邮件主题")]
    body: Annotated[str, Field(..., min_length=1, description="邮件正文")]
    cc: Annotated[list[EmailStr] | None, Field(None, description="抄送人列表")] = None


class SendEmailTool(BaseTool):
    name = "send_email"
    description = "发送邮件给指定收件人（需用户二次确认）"
    args_schema = SendEmailArgs
    # 危险工具：执行前需二次确认
    requires_confirmation = True

    async def execute(self, args: dict) -> ToolResult:
        validated = self.validate_args(args)
        assert isinstance(validated, SendEmailArgs)

        # ── 配置校验 ──
        if not all([
            settings.send_email_smtp_host,
            settings.send_email_smtp_user,
            settings.send_email_smtp_password,
        ]):
            raise ToolExecutionException(self.name, "邮件 SMTP 配置不完整")

        # 授权码清洗：去除首尾空格/换行，禁止包含空格
        auth_code = settings.send_email_smtp_password.strip()
        if " " in auth_code:
            raise ToolExecutionException(self.name, "SMTP 授权码包含非法空格")

        msg = EmailMessage()
        msg["From"] = (
            f"{settings.send_email_from_name} <{settings.send_email_smtp_user}>"
            if settings.send_email_from_name
            else settings.send_email_smtp_user
        )
        msg["To"] = validated.to
        if validated.cc:
            msg["Cc"] = ", ".join(validated.cc)
        msg["Subject"] = validated.subject
        msg.set_content(validated.body)

        try:
            if settings.send_email_smtp_use_ssl:
                # SSL 模式（端口 465）
                await aiosmtplib.send(
                    msg,
                    hostname=settings.send_email_smtp_host,
                    port=settings.send_email_smtp_port,
                    username=settings.send_email_smtp_user,
                    password=auth_code,
                    use_tls=True,
                    timeout=30.0,
                )
            else:
                # STARTTLS 模式（端口 587）
                await aiosmtplib.send(
                    msg,
                    hostname=settings.send_email_smtp_host,
                    port=settings.send_email_smtp_port,
                    username=settings.send_email_smtp_user,
                    password=auth_code,
                    start_tls=True,
                    timeout=30.0,
                )
        except aiosmtplib.SMTPAuthenticationError as e:
            # 535 认证失败：授权码错误/未开启 SMTP 服务/用户名非完整邮箱
            raise ToolExecutionException(
                self.name,
                f"SMTP 认证失败: {e.code} {e.message}。"
                f"请检查：① 授权码是否正确（非登录密码）；"
                f"② 邮箱是否开启 SMTP 服务；"
                f"③ 用户名是否为完整邮箱地址",
            )
        except aiosmtplib.SMTPConnectError as e:
            raise ToolExecutionException(
                self.name, f"SMTP 连接失败: {e.code} {e.message}"
            )
        except aiosmtplib.SMTPTimeoutError:
            raise ToolExecutionException(self.name, "SMTP 连接超时")
        except aiosmtplib.SMTPException as e:
            raise ToolExecutionException(self.name, f"邮件发送失败: {e}")

        return ToolResult(
            tool_name=self.name,
            success=True,
            data={"to": validated.to, "subject": validated.subject},
            summary=f"邮件已发送至 {validated.to}",
        )
