# 教师独立配置（无真实密钥）

- 仓库/固定提交：gitee.com/xiliang2022/my-agent master 952c58e5ac3de1053fb3454f6daffef61b66835a。
- 本地认证：teacher-local，仅隔离测试，无效外部凭据。
- OPENAI_API_KEY：teacher-placeholder，仅满足强制启动检查，不是有效凭据。
- 真正 DEEPSEEK_API_KEY：仅从外部进程环境读取；没有保存值。
- 真实 Chat：https://api.deepseek.com/v1；DeepSeekAdapter 原实现；deepseek-chat 实际回报 deepseek-flash，deepseek-v4-pro 实际回报同名模型。
- 真实 Messages：https://api.deepseek.com/anthropic；AnthropicAdapter 原实现；claude-3-5-sonnet-latest 按官方说明映射 Flash，不是 Claude 原厂。
- 真实测试：HTTP timeout=30秒、外层deadline=40秒、外层重试=0、SDK重试=0、max_tokens=2048。没有修改适配器业务逻辑，使用运行时配置限制费用和等待。
- 受控测试：上游使用 httpx.MockTransport，SDK默认重试2保留；外层最多重试3，base_delay=0.1、jitter=false。实际请求计数、等待、请求体见results.json。
- 下游使用真实FastAPI、uvicorn和HTTP SSE连接，门控收到正文后才放终态；每个流只收到一个上游请求。
- 限流：容量1，通过限流模块独立时钟推进61秒验证恢复；没有消耗真实服务配额。
- README启动：Python3.11替代3.13，Linux环境变量替代Windows copy/激活；独立端口18220、独立DB；未改学生源码。
- 学生脚本正常运行沿用DeepSeek官方endpoint，外层重试0；SDK未改，实际本次均正常返回。搜索工具未配置，不触发邮件。
- source为固定Git对象导出，原始blob哈希见source-manifest.json；scripts/repro_resume.py中学生硬编码认证TOKEN在归档内已替换为[REDACTED_STUDENT_AUTH_TOKEN]，保持行号，未运行该硬编码凭据。除此未更改归档源码。
- 不归档.env/.env.example、数据库、Git目录、环境导出或真实鉴权头。teacher脚本内的本地测试字符串可公开，不是API Key。
