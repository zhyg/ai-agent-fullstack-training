"""HTTP-level probes. Student source is imported, not modified."""
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/workspace/student/llm-gateway")
import httpx

from app.app import create_app
from app.core.config import AppConfig
from app.core.providers.base import ProviderResult, ProviderError, StreamChunk
from app.core.schemas import Usage

OUT = Path("/tmp/probe-http")
OUT.mkdir(exist_ok=True)

SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}

class ScriptedProvider:
    capabilities = {"streaming", "structured_output"}

    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def _pop(self, kind, config, call):
        self.calls.append({
            "kind": kind,
            "model": config.provider_model,
            "adapter": config.adapter,
            "mode": config.structured_output_mode,
            "has_schema": call.response_schema is not None,
            "roles": [m.role for m in call.messages],
            "timeout": call.timeout_seconds,
        })
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    async def complete(self, config, call):
        item = self._pop("complete", config, call)
        if isinstance(item, ProviderResult):
            return item
        return ProviderResult(content=item, usage=Usage(input_tokens=3, output_tokens=2, cached_input_tokens=1, reasoning_tokens=9), finish_reason="length", provider_request_id="up")

    async def stream(self, config, call):
        item = self._pop("stream", config, call)
        for chunk in item:
            if isinstance(chunk, Exception):
                raise chunk
            if isinstance(chunk, StreamChunk):
                yield chunk
            else:
                yield StreamChunk(text=chunk, usage=None)

    async def close(self):
        return None


def config(rate_burst=100, rpm=6000, attempts=2, jitter=True, base=0.1, admin=True, checkpoint=False):
    return AppConfig.model_validate({
        "version": "1.0",
        "models": {
            "chat-fast": {
                "adapter": "openai_compatible",
                "capabilities": ["streaming", "structured_output"],
                "priority": 100,
                "provider_model": "deepseek-flash",
                "base_url": "https://api.deepseek.com",
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_object",
                "pricing": {"input": 1.0, "cached_input": 0.1, "output": 4.0},
            },
            "chat-pro": {
                "adapter": "openai_compatible",
                "capabilities": ["streaming", "structured_output"],
                "priority": 80,
                "provider_model": "deepseek-v4-pro",
                "base_url": "https://api.deepseek.com",
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_schema",
                "pricing": {"input": 0.8, "cached_input": 0.08, "output": 3.2},
            },
        },
        "limits": {
            "rate": {"enabled": True, "requests_per_minute": rpm, "burst": rate_burst},
            "stream_checkpoint": {"enabled": checkpoint},
        },
        "retry": {"max_attempts_per_model": attempts, "base_delay_seconds": base, "backoff_factor": 2.0, "max_delay_seconds": 2.0, "jitter": jitter},
        "admin_endpoints": {"enabled": admin},
        "storage": {"backend": "memory"},
    })


async def client_for(provider, **kw):
    app = create_app(config=config(**kw), providers={"openai_compatible": provider})
    transport = httpx.ASGITransport(app=app)
    return app, httpx.AsyncClient(transport=transport, base_url="http://test")


async def post(client, path, payload):
    t0 = asyncio.get_event_loop().time()
    resp = await client.post(path, json=payload)
    return {
        "status": resp.status_code,
        "headers": {k: v for k, v in resp.headers.items() if k.lower() in {"content-type", "x-request-id", "x-trace-id", "retry-after"}},
        "body": resp.json() if "application/json" in resp.headers.get("content-type", "") else resp.text[:1500],
        "elapsed": round(asyncio.get_event_loop().time() - t0, 4),
    }


async def stream_post(client, path, payload):
    events = []
    t0 = asyncio.get_event_loop().time()
    first = None
    async with client.stream("POST", path, json=payload) as resp:
        ctype = resp.headers.get("content-type")
        status = resp.status_code
        async for line in resp.aiter_lines():
            if line.startswith("data: "):
                if first is None:
                    first = asyncio.get_event_loop().time() - t0
                events.append(line[6:])
    return {"status": status, "content_type": ctype, "first_data_s": first, "events": events}


async def main():
    report = {}

    # unknown model / response_format rejection / prompt missing
    provider = ScriptedProvider(['{"answer":"ok"}', '{"answer":"ok"}'])
    app, client = await client_for(provider, admin=True)
    async with client:
        report["unknown_model"] = await post(client, "/v1/llm", {"model": "nope", "messages": [{"role": "user", "content": "hi"}]})
        report["native_response_format"] = await post(client, "/v1/llm", {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "hi"}],
            "response_format": {"type": "json_object"},
        })
        report["native_schema_ok"] = await post(client, "/v1/llm", {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "hi"}],
            "response_schema": SCHEMA,
        })
        report["missing_prompt"] = await post(client, "/v1/llm", {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "hi"}],
            "prompt": {"name": "missing", "version": "v1", "variables": {}},
        })
        report["facade_json_object"] = await post(client, "/v1/chat/completions", {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "hi"}],
            "response_format": {"type": "json_object"},
        })
        traces = await client.get("/v1/traces")
        report["traces_after"] = traces.json()
        report["provider_calls_1"] = provider.calls

    # rate limit is per identity, not model: burst 1, A then B
    provider = ScriptedProvider(["a", "b", "c"])
    app, client = await client_for(provider, rate_burst=1, rpm=60, admin=True)
    async with client:
        a = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}]})
        b = await post(client, "/v1/llm", {"model": "chat-pro", "messages": [{"role": "user", "content": "hi"}]})
        report["rate_limit_models"] = {"fast": {"status": a["status"], "code": a["body"]}, "pro": {"status": b["status"], "code": b["body"], "retry_after": b["headers"].get("retry-after")}}
        report["rate_calls"] = provider.calls

    # stream incremental + eof without terminal is treated success
    provider = ScriptedProvider([["你", "好"], ["你"]])  # second has no completed distinction at provider; service always completes
    app, client = await client_for(provider, admin=True)
    async with client:
        report["stream_normal"] = await stream_post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "stream": True})
        report["stream_partial_provider"] = await stream_post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "stream": True})
        traces = (await client.get("/v1/traces")).json()
        report["stream_traces"] = [{k: t.get(k) for k in ("status", "error_code", "finish_reason", "usage", "latency", "usage_estimated")} for t in traces]

    # stream error after first delta
    class Boom(ProviderError):
        retryable = True
        fallback_allowed = True
        def __init__(self):
            super().__init__("provider_server_error", "boom", 502)

    provider = ScriptedProvider([["你", Boom()]])
    app, client = await client_for(provider, admin=True)
    async with client:
        report["stream_error_after_delta"] = await stream_post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "stream": True})
        traces = (await client.get("/v1/traces")).json()
        report["stream_error_trace"] = [{k: t.get(k) for k in ("status", "error_code", "http_status", "usage", "latency")} for t in traces]

    # retry count and sleep with jitter false
    sleeps = []
    async def fake_sleep(delay):
        sleeps.append(delay)

    provider = ScriptedProvider([
        ProviderError("provider_server_error", "1", 502),
        ProviderError("provider_server_error", "2", 502),
        ProviderError("provider_server_error", "3", 502),
    ])
    # ProviderError defaults retryable False. Use ProviderServerError.
    from app.core.providers.base import ProviderServerError, ProviderBadRequestError
    provider = ScriptedProvider([ProviderServerError(), ProviderServerError(), "ok-after"])
    app = create_app(config=config(attempts=3, jitter=False, base=0.05, admin=True), providers={"openai_compatible": provider}, sleep=fake_sleep, clock=lambda: 0.0)
    # clock stuck at 0 means remaining budget never decreases; OK for retry count
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        report["retry_then"] = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}]})
        report["retry_sleeps"] = sleeps
        report["retry_calls"] = provider.calls
        traces = (await client.get("/v1/traces")).json()
        report["retry_trace"] = [{k: t.get(k) for k in ("status", "error_code", "resilience", "usage")} for t in traces]

    # non-retryable 400 not repeated; also fallback? BadRequest fallback_allowed False so should stop
    provider = ScriptedProvider([ProviderBadRequestError(), "should-not"])
    app = create_app(config=config(attempts=3, jitter=False, admin=True), providers={"openai_compatible": provider}, sleep=fake_sleep)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        report["bad_request"] = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}]})
        report["bad_request_calls"] = len(provider.calls)

    # prompt versions
    from app.core.prompts import PromptRegistry, PromptEngine, PromptPackage
    # use prompts_dir
    prompts = Path("/tmp/probe-prompts")
    (prompts / "demo").mkdir(parents=True, exist_ok=True)
    (prompts / "demo" / "v1.yaml").write_text("name: demo\nversion: v1\nstatus: published\nsystem_template: 'V1 {{ name }}'\nvariables:\n  name: {type: str, max_length: 20}\n", encoding="utf-8")
    (prompts / "demo" / "v2.yaml").write_text("name: demo\nversion: v2\nstatus: published\nsystem_template: 'V2 {{ name }}'\nvariables:\n  name: {type: str, max_length: 20}\n", encoding="utf-8")
    provider = ScriptedProvider(["ok1", "ok2", "ok3"])
    app = create_app(config=config(admin=True), providers={"openai_compatible": provider}, prompts_dir=prompts)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        report["prompt_v1"] = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "prompt": {"name": "demo", "version": "v1", "variables": {"name": "Ada"}}})
        report["prompt_v2"] = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "prompt": {"name": "demo", "version": "v2", "variables": {"name": "Ada"}}})
        report["prompt_missing_var"] = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "prompt": {"name": "demo", "version": "v1", "variables": {}}})
        report["prompt_missing_ver"] = await post(client, "/v1/llm", {"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}], "prompt": {"name": "demo", "version": "v9", "variables": {"name": "Ada"}}})
        report["prompt_roles"] = provider.calls

    # capacity per model: set per_model to 1 by mutating? config field exists. We'll construct custom.
    # skip if too heavy; do a direct CapacityGuard check already known.

    (OUT / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print((OUT / "report.json").read_text()[:12000])

asyncio.run(main())
