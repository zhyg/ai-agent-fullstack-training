"""Local controlled probes against the student's gateway. Does not modify student code."""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/workspace/student/llm-gateway")
os.chdir("/home/user/workspace/student/llm-gateway")

import httpx
from openai import AsyncOpenAI

from app.core.capabilities import Capability
from app.core.config import AppConfig, ModelConfig
from app.core.providers.base import ProviderCall
from app.core.providers.openai_compatible import OpenAICompatibleProvider
from app.core.rate_limit import InMemoryRateLimiter, RateLimitConfig
from app.core.schemas import Message
from app.core.validation import validate_output
from app.service.retry import RetryPolicy, backoff_delay

OUT = Path("/tmp/probe-local")
OUT.mkdir(exist_ok=True)

def dump(name, obj):
    text = json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    (OUT / name).write_text(text, encoding="utf-8")
    print(f"\n===== {name} =====")
    print(text[:4000])

CONFIG = ModelConfig(
    adapter="openai_compatible",
    capabilities={Capability.STREAMING, Capability.STRUCTURED_OUTPUT},
    priority=100,
    provider_model="deepseek-v4-flash",
    base_url="http://upstream.test",
    api_key_env="DEEPSEEK_API_KEY",
    structured_output_mode="json_object",
    pricing={"input": 1.0, "cached_input": 0.1, "output": 4.0},
)
SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}

async def main():
    captured = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content) if request.content else {}
        captured.append({
            "method": request.method,
            "path": request.url.path,
            "auth": "Bearer" in request.headers.get("authorization", ""),
            "body_keys": sorted(body),
            "model": body.get("model"),
            "response_format": body.get("response_format"),
            "stream": body.get("stream"),
            "messages_roles": [m.get("role") for m in body.get("messages", [])],
        })
        mode = body.get("_probe")
        # distinguish by a header we cannot set; use path + last message content marker via model
        marker = ""
        for m in body.get("messages", []):
            marker += m.get("content", "")
        if "PROBE_400" in marker:
            return httpx.Response(400, json={"error": {"message": "bad", "type": "invalid_request_error"}}, request=request)
        if "PROBE_401" in marker:
            return httpx.Response(401, json={"error": {"message": "no", "type": "authentication_error"}}, request=request)
        if "PROBE_429" in marker:
            return httpx.Response(429, json={"error": {"message": "slow"}}, headers={"retry-after": "2"}, request=request)
        if "PROBE_500" in marker:
            return httpx.Response(500, json={"error": {"message": "boom"}}, request=request)
        content = '{"answer":"ok"}'
        if "PROBE_FENCE" in marker:
            content = '```json\n{"answer":"ok"}\n```'
        if "PROBE_ILLEGAL" in marker:
            content = "not json at all"
        if "PROBE_EMPTY" in marker:
            content = ""
        if "PROBE_TRUNC" in marker:
            content = '{"answer":'
        if "PROBE_SCHEMA" in marker:
            content = '{"answer": 1}'
        if "PROBE_NAN" in marker:
            content = '{"answer": NaN}'
        if "PROBE_PROSE" in marker:
            content = '结果是 {"answer":"ok"} 完毕'
        finish = "length" if "PROBE_LENGTH" in marker else "stop"
        if body.get("stream"):
            sse = (
                'data: {"id":"c1","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":""},"finish_reason":null}]}\n\n'
                'data: {"id":"c1","object":"chat.completion.chunk","choices":[{"index":0,"delta":{},"finish_reason":null}]}\n\n'
                'data: {"id":"c1","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"你"},"finish_reason":null}]}\n\n'
                'data: {"id":"c1","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"好"},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":2,"total_tokens":5,"completion_tokens_details":{"reasoning_tokens":1}}}\n\n'
                "data: [DONE]\n\n"
            )
            if "PROBE_STREAM_ERR" in marker:
                sse = (
                    'data: {"id":"c1","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"你"},"finish_reason":null}]}\n\n'
                    'data: {"error":{"message":"upstream died","type":"server_error"}}\n\n'
                )
            if "PROBE_EOF" in marker:
                sse = 'data: {"id":"c1","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"你"},"finish_reason":null}]}\n\n'
            return httpx.Response(200, content=sse, headers={"content-type": "text/event-stream"}, request=request)
        return httpx.Response(200, json={
            "id": "chatcmpl-local",
            "object": "chat.completion",
            "created": 1,
            "model": body.get("model"),
            "choices": [{"index": 0, "message": {"role": "assistant", "content": content, "reasoning_content": "think"}, "finish_reason": finish}],
            "usage": {
                "prompt_tokens": 11,
                "completion_tokens": 7,
                "total_tokens": 18,
                "prompt_tokens_details": {"cached_tokens": 4},
                "completion_tokens_details": {"reasoning_tokens": 3},
            },
        }, request=request)

    transport = httpx.MockTransport(handler)
    http_client = httpx.AsyncClient(transport=transport, base_url="http://upstream.test")
    provider = OpenAICompatibleProvider(
        client_factory=lambda config: AsyncOpenAI(
            api_key="test", base_url=config.base_url, http_client=http_client, max_retries=0
        )
    )

    async def call(label, content, schema=None, stream=False, mode="json_object"):
        cfg = CONFIG.model_copy(update={"structured_output_mode": mode, "provider_model": "deepseek-v4-pro" if mode == "json_schema" else "deepseek-v4-flash"})
        pc = ProviderCall(messages=[Message(role="user", content=content)], timeout_seconds=5, response_schema=schema)
        try:
            if stream:
                chunks = []
                async for ch in provider.stream(cfg, pc):
                    chunks.append({"text": ch.text, "usage": None if ch.usage is None else ch.usage.model_dump()})
                return {"label": label, "ok": True, "chunks": chunks}
            result = await provider.complete(cfg, pc)
            return {
                "label": label,
                "ok": True,
                "content": result.content,
                "usage": result.usage.model_dump(),
                "finish_reason": result.finish_reason,
                "request_id": result.provider_request_id,
            }
        except Exception as exc:
            return {"label": label, "ok": False, "type": type(exc).__name__, "code": getattr(exc, "code", None), "status": getattr(exc, "status_code", None), "retryable": getattr(exc, "retryable", None), "fallback": getattr(exc, "fallback_allowed", None), "msg": str(exc)}

    results = []
    results.append(await call("plain", "hello"))
    results.append(await call("json_object", "give json", schema=SCHEMA, mode="json_object"))
    results.append(await call("json_schema", "give json", schema=SCHEMA, mode="json_schema"))
    results.append(await call("err400", "PROBE_400"))
    results.append(await call("err401", "PROBE_401"))
    results.append(await call("err429", "PROBE_429"))
    results.append(await call("err500", "PROBE_500"))
    results.append(await call("stream", "hello stream", stream=True))
    results.append(await call("stream_err", "PROBE_STREAM_ERR stream", stream=True))
    results.append(await call("stream_eof", "PROBE_EOF stream", stream=True))
    dump("adapter_calls.json", {"captured": captured, "results": results})

    # validation of returned contents
    val = []
    for label, content in [
        ("ok", '{"answer":"ok"}'),
        ("fence", '```json\n{"answer":"ok"}\n```'),
        ("illegal", "not json at all"),
        ("empty", ""),
        ("trunc", '{"answer":'),
        ("schema_mismatch", '{"answer": 1}'),
        ("nan", '{"answer": NaN}'),
        ("prose", '结果是 {"answer":"ok"} 完毕'),
        ("whitespace", "   "),
    ]:
        try:
            parsed = validate_output(content, SCHEMA)
            val.append({"label": label, "ok": True, "parsed": parsed})
        except Exception as exc:
            val.append({"label": label, "ok": False, "code": getattr(exc, "code", None), "status": getattr(exc, "status_code", None), "msg": str(exc)})
    dump("validation.json", val)

    # jitter can exceed cap
    policy = RetryPolicy(base_delay_seconds=0.1, backoff_factor=2.0, max_delay_seconds=2.0, jitter=True)
    over = []
    for attempt in (1, 2, 3, 4):
        cap = min(0.1 * (2 ** (attempt - 1)), 2.0)
        samples = [backoff_delay(attempt, policy) for _ in range(200)]
        over.append({
            "attempt": attempt,
            "cap": cap,
            "min": min(samples),
            "max": max(samples),
            "over_cap": sum(1 for s in samples if s > cap + 1e-12),
        })
    dump("backoff.json", over)

    # rate limit identity vs model
    limiter = InMemoryRateLimiter(RateLimitConfig(enabled=True, requests_per_minute=60, burst=1), clock=lambda: 1000.0)
    rl = []
    for ident in ("caller", "caller", "other"):
        try:
            await limiter.check(ident)
            rl.append({"identity": ident, "ok": True})
        except Exception as exc:
            rl.append({"identity": ident, "ok": False, "code": exc.code, "status": exc.status_code})
    dump("ratelimit_identity.json", rl)
    await provider.close()

asyncio.run(main())
