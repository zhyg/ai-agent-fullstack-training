"""Real calls using only the student's OpenAICompatibleProvider and HTTP entry.

Does not modify student source. Config is built in this process.
"""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/workspace/student/llm-gateway")
os.chdir("/tmp")

import httpx

from app.app import create_app
from app.core.config import AppConfig
from app.core.providers.openai_compatible import OpenAICompatibleProvider

OUT = Path("/tmp/ds-live")
KEY = os.environ["DEEPSEEK_API_KEY"]


class Recording(OpenAICompatibleProvider):
    def __init__(self):
        super().__init__()
        self.seen = []

    def get_client(self, config):
        client = super().get_client(config)
        return client

    async def complete(self, config, call):
        self.seen.append({
            "kind": "complete",
            "provider_model": config.provider_model,
            "base_url": config.base_url,
            "mode": config.structured_output_mode,
            "schema": call.response_schema is not None,
        })
        return await super().complete(config, call)

    async def stream(self, config, call):
        self.seen.append({
            "kind": "stream",
            "provider_model": config.provider_model,
            "base_url": config.base_url,
            "mode": config.structured_output_mode,
        })
        async for chunk in super().stream(config, call):
            yield chunk


def make_config():
    return AppConfig.model_validate({
        "version": "1.0",
        "models": {
            "chat-fast": {
                "adapter": "openai_compatible",
                "capabilities": ["streaming", "structured_output"],
                "priority": 100,
                "provider_model": "deepseek-flash",
                "base_url": "https://api.deepseek.com",
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_object",
                "pricing": {"input": 1.0, "cached_input": 0.1, "output": 4.0},
            },
            "chat-pro": {
                "adapter": "openai_compatible",
                "capabilities": ["streaming", "structured_output"],
                "priority": 80,
                "provider_model": "deepseek-v4-pro",
                "base_url": "https://api.deepseek.com",
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_schema",
                "pricing": {"input": 0.8, "cached_input": 0.08, "output": 3.2},
            },
        },
        "limits": {"rate": {"enabled": False}},
        "retry": {"max_attempts_per_model": 1, "jitter": False},
        "admin_endpoints": {"enabled": True},
        "storage": {"backend": "memory"},
    })


SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
    "additionalProperties": False,
}


async def main():
    provider = Recording()
    app = create_app(config=make_config(), providers={"openai_compatible": provider})
    transport = httpx.ASGITransport(app=app)
    report = {}
    async with httpx.AsyncClient(transport=transport, base_url="http://test", timeout=90) as client:
        cases = {
            "fast_plain": {"model": "chat-fast", "messages": [{"role": "user", "content": "只回复一个词 pong"}], "timeout_seconds": 45},
            "pro_plain": {"model": "chat-pro", "messages": [{"role": "user", "content": "只回复一个词 pong"}], "timeout_seconds": 45},
            "fast_json": {"model": "chat-fast", "messages": [{"role": "user", "content": "返回 {\"answer\":\"pong\"}"}], "response_schema": SCHEMA, "timeout_seconds": 45},
            "pro_json": {"model": "chat-pro", "messages": [{"role": "user", "content": "返回 {\"answer\":\"pong\"}"}], "response_schema": SCHEMA, "timeout_seconds": 45},
            "facade_json": None,
        }
        for name, payload in cases.items():
            if name == "facade_json":
                t0 = time.perf_counter()
                resp = await client.post("/v1/chat/completions", json={
                    "model": "chat-fast",
                    "messages": [{"role": "user", "content": "返回 {\"answer\":\"pong\"}"}],
                    "response_format": {"type": "json_object"},
                })
            else:
                t0 = time.perf_counter()
                resp = await client.post("/v1/llm", json=payload)
            body = resp.json()
            report[name] = {
                "status": resp.status_code,
                "elapsed_ms": int((time.perf_counter() - t0) * 1000),
                "request_id": resp.headers.get("x-request-id"),
                "body": body,
            }
            print(name, resp.status_code, str(body)[:240])
        t0 = time.perf_counter()
        events = []
        first = None
        async with client.stream("POST", "/v1/llm", json={
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "只回复一个词 pong"}],
            "stream": True,
            "timeout_seconds": 45,
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    if first is None:
                        first = int((time.perf_counter() - t0) * 1000)
                    events.append(json.loads(line[6:]))
        report["fast_stream"] = {
            "status": resp.status_code,
            "content_type": resp.headers.get("content-type"),
            "ttft_ms": first,
            "events": events,
        }
        print("stream", resp.status_code, first, events)
        t0 = time.perf_counter()
        events = []
        first = None
        async with client.stream("POST", "/v1/llm", json={
            "model": "chat-pro",
            "messages": [{"role": "user", "content": "只回复一个词 pong"}],
            "stream": True,
            "timeout_seconds": 45,
        }) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    if first is None:
                        first = int((time.perf_counter() - t0) * 1000)
                    events.append(json.loads(line[6:]))
        report["pro_stream"] = {
            "status": resp.status_code,
            "content_type": resp.headers.get("content-type"),
            "ttft_ms": first,
            "events": events,
        }
        print("pro stream", resp.status_code, first, events)
        report["traces"] = (await client.get("/v1/traces")).json()
    report["seen"] = provider.seen
    await provider.close()
    path = OUT / "student_adapter_live.json"
    text = json.dumps(report, ensure_ascii=False, indent=2)
    text = text.replace(KEY, "***")
    path.write_text(text, encoding="utf-8")
    print("wrote", path)

asyncio.run(main())
