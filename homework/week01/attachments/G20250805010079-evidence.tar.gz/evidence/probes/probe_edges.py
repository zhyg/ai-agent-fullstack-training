"""Edge probes: quota recovery, failed usage loss, stream error event, heartbeat TTFT, README boot."""
import asyncio
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/workspace/student/llm-gateway")
import httpx
from openai import AsyncOpenAI

from app.app import create_app
from app.core.config import AppConfig
from app.core.providers.base import ProviderResult, ProviderServerError, StreamChunk
from app.core.providers.openai_compatible import OpenAICompatibleProvider
from app.core.schemas import Usage
from app.core.capabilities import Capability
from app.core.config import ModelConfig

OUT = Path("/tmp/probe-edges")
OUT.mkdir(exist_ok=True)

def cfg(**kw):
    data = {
        "version": "1.0",
        "models": {
            "chat-fast": {
                "adapter": "openai_compatible",
                "capabilities": ["streaming", "structured_output"],
                "priority": 100,
                "provider_model": "deepseek-flash",
                "base_url": "http://upstream.test",
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_object",
                "pricing": {"input": 1.0, "cached_input": 0.1, "output": 4.0},
            },
            "chat-pro": {
                "adapter": "openai_compatible",
                "capabilities": ["streaming", "structured_output"],
                "priority": 80,
                "provider_model": "deepseek-v4-pro",
                "base_url": "http://upstream.test",
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_schema",
                "pricing": {"input": 0.8, "cached_input": 0.08, "output": 3.2},
            },
        },
        "limits": {"rate": {"enabled": True, "requests_per_minute": 60, "burst": 1}},
        "retry": {"max_attempts_per_model": 1, "jitter": False},
        "admin_endpoints": {"enabled": True},
        "storage": {"backend": "memory"},
    }
    data.update(kw)
    return AppConfig.model_validate(data)

class P:
    capabilities = {"streaming", "structured_output"}
    def __init__(self):
        self.n = 0
    async def complete(self, config, call):
        self.n += 1
        if self.n == 2:
            raise ProviderServerError()
        return ProviderResult(content="ok", usage=Usage(input_tokens=4, output_tokens=2, reasoning_tokens=1), finish_reason="stop", provider_request_id="u")
    async def stream(self, config, call):
        yield StreamChunk(text="你", usage=None)
    async def close(self):
        return None

async def main():
    report = {}
    clock = {"t": 1000.0}
    provider = P()
    app = create_app(config=cfg(), providers={"openai_compatible": provider}, clock=lambda: clock["t"])
    # rate limiter uses its own clock; patch it
    app.state.rate_limiter._clock = lambda: clock["t"]
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        a = await client.post("/v1/llm", json={"model": "chat-fast", "messages": [{"role": "user", "content": "hi"}]})
        b = await client.post("/v1/llm", json={"model": "chat-pro", "messages": [{"role": "user", "content": "hi"}]})
        clock["t"] += 2.0  # 60 rpm => 1 token/s, burst 1, 2s should refill 2 but cap is burst 1
        c = await client.post("/v1/llm", json={"model": "chat-pro", "messages": [{"role": "user", "content": "hi"}]})
        report["quota"] = {
            "first": a.status_code,
            "second_other_model": b.status_code,
            "second_body": b.json(),
            "after_2s": c.status_code,
            "after_body_code": c.json().get("detail", {}).get("code") if c.status_code != 200 else "ok",
            "upstream_calls": provider.n,
        }
        traces = (await client.get("/v1/traces")).json()
        report["traces_raw_type"] = type(traces).__name__
        report["traces"] = traces if isinstance(traces, dict) else [{k: item.get(k) for k in ("requested_model", "status", "error_code", "usage", "http_status")} for item in traces]

    # adapter stream error event and heartbeat
    captured = {}
    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        marker = body["messages"][0]["content"]
        if marker == "err":
            sse = (
                'data: {"id":"c","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"你"},"finish_reason":null}]}\n\n'
                'data: {"error":{"message":"upstream died","type":"server_error"}}\n\n'
            )
        elif marker == "hb":
            sse = (
                ': heartbeat\n\n'
                'data: {"id":"c","object":"chat.completion.chunk","choices":[{"index":0,"delta":{},"finish_reason":null}]}\n\n'
                'data: {"id":"c","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":""},"finish_reason":null}]}\n\n'
                'data: {"id":"c","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"pong"},"finish_reason":"stop"}]}\n\n'
                'data: [DONE]\n\n'
            )
        else:
            sse = 'data: [DONE]\n\n'
        return httpx.Response(200, content=sse, headers={"content-type": "text/event-stream"}, request=request)

    transport = httpx.MockTransport(handler)
    http_client = httpx.AsyncClient(transport=transport, base_url="http://upstream.test")
    provider = OpenAICompatibleProvider(client_factory=lambda config: AsyncOpenAI(api_key="x", base_url=config.base_url, http_client=http_client, max_retries=0))
    app = create_app(config=cfg(), providers={"openai_compatible": provider})
    app.state.rate_limiter.config.enabled = False
    transport2 = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport2, base_url="http://test") as client:
        async def collect(content):
            events = []
            async with client.stream("POST", "/v1/llm", json={"model": "chat-fast", "messages": [{"role": "user", "content": content}], "stream": True}) as resp:
                async for line in resp.aiter_lines():
                    if line.startswith("data: "):
                        events.append(line[6:])
            return resp.status_code, events
        report["stream_error_event"] = await collect("err")
        report["stream_heartbeat"] = await collect("hb")
        traces = (await client.get("/v1/traces")).json()
        report["stream_traces"] = [{k: t.get(k) for k in ("status", "error_code", "finish_reason", "latency", "usage_estimated")} for t in traces]
    await provider.close()
    Path("/tmp/probe-edges/report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str)[:5000])

asyncio.run(main())
