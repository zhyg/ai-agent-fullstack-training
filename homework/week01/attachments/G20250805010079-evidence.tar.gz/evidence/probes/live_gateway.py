"""Real DeepSeek calls through the student's gateway. No student files are changed.

Protocols:
- chat-fast -> Chat Completions /chat/completions, model deepseek-flash
- chat-pro  -> Responses /responses, model deepseek-v4-pro
The second adapter is injected only in this harness.
"""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/workspace/student/llm-gateway")
os.chdir("/tmp")

import httpx

from app.app import create_app
from app.core.config import AppConfig
from app.core.providers.base import (
    ProviderCall,
    ProviderResult,
    StreamChunk,
    ProviderBadRequestError,
    ProviderServerError,
    ProviderInvalidResponseError,
)
from app.core.providers.openai_compatible import OpenAICompatibleProvider, _translate_sdk_error
from app.core.schemas import Usage

OUT = Path("/tmp/ds-live")
OUT.mkdir(exist_ok=True)
KEY = os.environ["DEEPSEEK_API_KEY"]
BASE = "https://api.deepseek.com"


def scrub(obj):
    if isinstance(obj, dict):
        return {k: scrub(v) for k, v in obj.items() if k.lower() not in {"authorization", "api_key"}}
    if isinstance(obj, list):
        return [scrub(v) for v in obj]
    if isinstance(obj, str) and KEY and KEY in obj:
        return obj.replace(KEY, "***")
    return obj


class ResponsesProvider:
    """Minimal Responses adapter used only to exercise the student's unified entry with a second protocol."""

    capabilities = {"streaming", "structured_output"}

    def __init__(self):
        self.requests = []
        self.client = httpx.AsyncClient(base_url=BASE, timeout=httpx.Timeout(60.0), headers={
            "Authorization": f"Bearer {KEY}",
            "Content-Type": "application/json",
        })

    async def close(self):
        await self.client.aclose()

    def _body(self, config, call, stream):
        text = "\n".join(m.content for m in call.messages)
        body = {
            "model": config.provider_model,
            "input": text,
            "max_output_tokens": 48,
            "stream": stream,
        }
        if call.response_schema is not None:
            body["text"] = {"format": {"type": "json_object"}}
        return body

    def _usage(self, usage):
        usage = usage or {}
        details = usage.get("input_tokens_details") or {}
        out_details = usage.get("output_tokens_details") or {}
        return Usage(
            input_tokens=usage.get("input_tokens") or 0,
            output_tokens=usage.get("output_tokens") or 0,
            cached_input_tokens=details.get("cached_tokens") or 0,
            reasoning_tokens=out_details.get("reasoning_tokens") or 0,
        )

    def _text(self, data):
        parts = []
        for item in data.get("output") or []:
            if item.get("type") == "message":
                for c in item.get("content") or []:
                    if c.get("type") in ("output_text", "text") and c.get("text"):
                        parts.append(c["text"])
        return "".join(parts)

    async def complete(self, config, call: ProviderCall) -> ProviderResult:
        body = self._body(config, call, False)
        self.requests.append({"path": "/responses", "model": body["model"], "keys": sorted(body), "stream": False, "format": body.get("text")})
        resp = await self.client.post("/responses", json=body)
        data = resp.json()
        if resp.status_code == 400:
            raise ProviderBadRequestError()
        if resp.status_code >= 500:
            raise ProviderServerError()
        if resp.status_code >= 400:
            raise ProviderBadRequestError()
        if data.get("status") not in ("completed", "incomplete"):
            raise ProviderInvalidResponseError()
        return ProviderResult(
            content=self._text(data),
            usage=self._usage(data.get("usage")),
            finish_reason=data.get("status"),
            provider_request_id=data.get("id"),
        )

    async def stream(self, config, call: ProviderCall):
        body = self._body(config, call, True)
        self.requests.append({"path": "/responses", "model": body["model"], "keys": sorted(body), "stream": True})
        async with self.client.stream("POST", "/responses", json=body) as resp:
            if resp.status_code >= 400:
                raw = await resp.aread()
                raise ProviderServerError("provider_server_error", raw.decode()[:180])
            event = None
            async for line in resp.aiter_lines():
                if line.startswith("event: "):
                    event = line[7:]
                elif line.startswith("data: "):
                    payload = json.loads(line[6:])
                    if event in ("response.output_text.delta",) or payload.get("type") == "response.output_text.delta":
                        delta = payload.get("delta") or ""
                        if delta:
                            yield StreamChunk(text=delta, usage=None)
                    if event == "response.completed" or payload.get("type") == "response.completed":
                        response = payload.get("response") or {}
                        yield StreamChunk(text=None, usage=self._usage(response.get("usage")))


class RecordingChat(OpenAICompatibleProvider):
    def __init__(self):
        super().__init__()
        self.requests = []
        orig = self.complete

    async def complete(self, config, call):
        self.requests.append({
            "path": "/chat/completions",
            "model": config.provider_model,
            "mode": config.structured_output_mode,
            "schema": call.response_schema is not None,
            "stream": False,
        })
        return await super().complete(config, call)

    async def stream(self, config, call):
        self.requests.append({
            "path": "/chat/completions",
            "model": config.provider_model,
            "stream": True,
        })
        async for chunk in super().stream(config, call):
            yield chunk


def app_config():
    return AppConfig.model_validate({
        "version": "1.0",
        "models": {
            "chat-fast": {
                "adapter": "chat_completions",
                "capabilities": ["streaming", "structured_output"],
                "priority": 100,
                "provider_model": "deepseek-flash",
                "base_url": BASE,
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_object",
                "pricing": {"input": 1.0, "cached_input": 0.1, "output": 4.0},
            },
            "chat-pro": {
                "adapter": "responses",
                "capabilities": ["streaming", "structured_output"],
                "priority": 80,
                "provider_model": "deepseek-v4-pro",
                "base_url": BASE,
                "api_key_env": "DEEPSEEK_API_KEY",
                "structured_output_mode": "json_object",
                "pricing": {"input": 0.8, "cached_input": 0.08, "output": 3.2},
            },
        },
        "limits": {"rate": {"enabled": False}},
        "retry": {"max_attempts_per_model": 1, "jitter": False},
        "admin_endpoints": {"enabled": True},
        "storage": {"backend": "memory"},
    })


# register synthetic adapters so config validation accepts them
from app.core.capabilities import ADAPTER_CAPABILITIES, Capability
ADAPTER_CAPABILITIES["chat_completions"] = {Capability.STREAMING, Capability.STRUCTURED_OUTPUT}
ADAPTER_CAPABILITIES["responses"] = {Capability.STREAMING, Capability.STRUCTURED_OUTPUT}


async def post(client, payload):
    t0 = time.perf_counter()
    resp = await client.post("/v1/llm", json=payload)
    body = resp.json()
    return {
        "status": resp.status_code,
        "elapsed_ms": int((time.perf_counter() - t0) * 1000),
        "request_id": resp.headers.get("x-request-id"),
        "body": body,
    }


async def stream(client, payload):
    t0 = time.perf_counter()
    events = []
    first = None
    async with client.stream("POST", "/v1/llm", json=payload) as resp:
        status = resp.status_code
        ctype = resp.headers.get("content-type")
        async for line in resp.aiter_lines():
            if not line.startswith("data: "):
                continue
            if first is None:
                first = int((time.perf_counter() - t0) * 1000)
            events.append(json.loads(line[6:]))
    return {
        "status": status,
        "content_type": ctype,
        "ttft_ms": first,
        "total_ms": int((time.perf_counter() - t0) * 1000),
        "events": events,
    }


async def main():
    chat = RecordingChat()
    responses = ResponsesProvider()
    app = create_app(
        config=app_config(),
        providers={"chat_completions": chat, "responses": responses},
    )
    transport = httpx.ASGITransport(app=app)
    report = {"note": "chat-fast uses student OpenAICompatibleProvider; chat-pro uses harness Responses adapter"}
    schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"], "additionalProperties": False}
    async with httpx.AsyncClient(transport=transport, base_url="http://test", timeout=90) as client:
        report["fast_plain"] = await post(client, {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "只回复一个词 pong"}],
            "timeout_seconds": 40,
        })
        report["pro_plain"] = await post(client, {
            "model": "chat-pro",
            "messages": [{"role": "user", "content": "只回复一个词 pong"}],
            "timeout_seconds": 40,
        })
        report["fast_json"] = await post(client, {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "返回 {\"answer\":\"pong\"}"}],
            "response_schema": schema,
            "timeout_seconds": 40,
        })
        report["pro_json"] = await post(client, {
            "model": "chat-pro",
            "messages": [{"role": "user", "content": "返回 {\"answer\":\"pong\"}"}],
            "response_schema": schema,
            "timeout_seconds": 40,
        })
        report["fast_stream"] = await stream(client, {
            "model": "chat-fast",
            "messages": [{"role": "user", "content": "只回复一个词 pong"}],
            "stream": True,
            "timeout_seconds": 40,
        })
        report["pro_stream"] = await stream(client, {
            "model": "chat-pro",
            "messages": [{"role": "user", "content": "只回复一个词 pong"}],
            "stream": True,
            "timeout_seconds": 40,
        })
        traces = (await client.get("/v1/traces")).json()
        report["traces"] = traces
    report["chat_requests"] = chat.requests
    report["responses_requests"] = responses.requests
    await chat.close()
    await responses.close()
    path = OUT / "gateway_live.json"
    path.write_text(json.dumps(scrub(report), ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote", path, "bytes", path.stat().st_size)

asyncio.run(main())
