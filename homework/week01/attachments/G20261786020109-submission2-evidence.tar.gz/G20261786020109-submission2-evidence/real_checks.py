import asyncio
import json
import os
import time
from pathlib import Path
import httpx

root=Path(__file__).parent

async def main():
    results=[]
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18303',timeout=160) as c:
        results.append({'models':(await c.get('/v1/models')).json(), 'credential_present':bool(os.getenv('DEEPSEEK_API_KEY'))})
        for m in ('deepseek-v4-pro','deepseek-v4-flash'):
            for mode in ('normal','stream','json'):
                p={'model':m,'input':'仅回答OK，不要解释。','max_output_tokens':512}
                if mode=='stream':
                    p['stream']=True
                if mode=='json':
                    p.update(input='Return only JSON: {"ok":true}',response_format={'type':'json_object'})
                start=time.monotonic()
                try:
                    r=await c.post('/v1/chat',json=p)
                    results.append({'model':m,'mode':mode,'request':p,'http':r.status_code,'body':r.text,'elapsed_s':round(time.monotonic()-start,3)})
                    print(m,mode,'HTTP',r.status_code,'elapsed',round(time.monotonic()-start,2),flush=True)
                except Exception as e:
                    results.append({'model':m,'mode':mode,'error':type(e).__name__,'elapsed_s':round(time.monotonic()-start,3)})
        results.append({'ledger':(await c.get('/v1/calls',params={'limit':100})).json()})
    # Exact credential removal is additional to never logging headers or configuration secrets.
    text=json.dumps(results,ensure_ascii=False,indent=2)
    key=os.getenv('DEEPSEEK_API_KEY','')
    if key:
        text=text.replace(key,'<REDACTED>')
    (root/'evidence/real-results.json').write_text(text)

asyncio.run(main())
