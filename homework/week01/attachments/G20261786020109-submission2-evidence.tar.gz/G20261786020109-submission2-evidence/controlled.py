import asyncio
import json
import time
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI()
state = {}
gate = asyncio.Event()

@app.post('/control')
async def control(r: Request):
    state.clear()
    state.update(await r.json())
    state['requests'] = []
    gate.clear()
    return {'ok': True}

@app.post('/release')
async def release():
    gate.set()
    return {'ok': True}

@app.get('/stats')
async def stats():
    return state

def event(data):
    return 'data: ' + json.dumps(data) + '\n\n'

@app.post('/{path:path}')
async def upstream(path: str, r: Request):
    body = await r.json()
    state.setdefault('requests', []).append({'path': path, 'body': body, 't': time.monotonic()})
    n = len(state['requests'])
    if n <= state.get('fail', 0):
        return JSONResponse({'error': {'message': 'injected'}}, status_code=state.get('status', 500))
    text = state.get('text', '{"ok":true}')
    proto = 'responses' if path.endswith('responses') else 'messages' if path.endswith('messages') else 'chat'
    finish = state.get('finish', 'completed')
    u = {'input_tokens': 19, 'output_tokens': 7, 'total_tokens': 26,
         'input_tokens_details': {'cached_tokens': 5}, 'output_tokens_details': {'reasoning_tokens': 3}}
    au = {'input_tokens': 19, 'output_tokens': 7, 'cache_read_input_tokens': 5, 'cache_creation_input_tokens': 2}
    cu = {'prompt_tokens': 19, 'completion_tokens': 7, 'total_tokens': 26,
          'prompt_cache_hit_tokens': 5, 'prompt_cache_miss_tokens': 14,
          'completion_tokens_details': {'reasoning_tokens': 3}}
    if not body.get('stream'):
        if proto == 'responses':
            return {'output': [{'content': [{'type': 'output_text', 'text': text}]}], 'status': finish, 'usage': u}
        if proto == 'messages':
            # json_object uses an assistant '{' prefill; complete that prefix, as the protocol specifies.
            if body.get('messages', [{}])[-1].get('role') == 'assistant' and text.startswith('{'):
                text = text[1:]
            content = [{'type': 'text', 'text': text}]
            if body.get('tools') and state.get('tool', True):
                content = [{'type': 'tool_use', 'name': 'emit_structured_output', 'input': json.loads(text)}]
            return {'content': content, 'stop_reason': finish, 'usage': au}
        return {'choices': [{'message': {'content': text}, 'finish_reason': finish}], 'usage': cu}
    async def generate():
        mode = state.get('mode', 'normal')
        if proto == 'responses':
            yield event({'type': 'response.created', 'response': {}})
            await asyncio.sleep(.08)
            yield event({'type': 'response.output_text.delta', 'delta': text})
        elif proto == 'messages':
            yield event({'type': 'message_start', 'message': {'usage': {**au, 'output_tokens': 0}}})
            await asyncio.sleep(.08)
            yield event({'type': 'content_block_delta', 'delta': {'type': 'text_delta', 'text': text}})
        else:
            yield event({'choices': [{'delta': {}}]})
            await asyncio.sleep(.08)
            yield event({'choices': [{'delta': {'content': text}}]})
        if mode == 'gate':
            await asyncio.wait_for(gate.wait(), 8)
        if mode == 'eof':
            return
        if mode == 'disconnect':
            raise RuntimeError('controlled transport disconnect')
        if mode == 'error':
            yield event({'type': 'error', 'error': {'message': 'controlled after-text error'}})
            return
        if proto == 'responses':
            yield event({'type': 'response.completed', 'response': {'usage': u}})
        elif proto == 'messages':
            yield event({'type': 'message_delta', 'delta': {'stop_reason': 'end_turn'}, 'usage': {'output_tokens': 7}})
            yield event({'type': 'message_stop'})
        else:
            yield event({'choices': [{'delta': {}, 'finish_reason': 'stop'}], 'usage': cu})
            yield 'data: [DONE]\n\n'
    return StreamingResponse(generate(), media_type='text/event-stream')
