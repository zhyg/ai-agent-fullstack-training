import hashlib
import json
import os
import re
from pathlib import Path

root=Path(__file__).parent
feedback=(root/'feedback.md').read_text()
assessment=(root/'assessment.md').read_text()
counts={}
for title,next_title in [('2. 作业优点','3. 作业不足'),('3. 作业不足','4. 改进方案'),('4. 改进方案',None)]:
    section=feedback.split('**'+title+'**\n\n')[1]
    if next_title:section=section.split('**'+next_title+'**')[0]
    lines=[x for x in section.splitlines() if x.startswith('- ')]
    count=len(''.join(x[2:] for x in lines))
    assert 3<=len(lines)<=5 and count<=500
    assert '扣分' not in section and '评分依据' not in section
    counts[title]={'items':len(lines),'characters':count}
assert '**1. 作业等级：优秀（85分）**' in feedback
scores=[]
for line in assessment.splitlines():
    m=re.match(r'\| (?!合计)([^|]+) \| (\d+)/(\d+) \|',line)
    if m:scores.append((m[1].strip(),int(m[2]),int(m[3])))
assert len(scores)==8 and sum(x[1] for x in scores)==85 and sum(x[2] for x in scores)==100
e=root/'evidence'
xs=json.loads((e/'controlled-results.json').read_text())
assert len(xs)==45
assert sum(x.get('received_before_release',False) for x in xs)==2
for x in xs:
    name=x['name']
    if name.startswith('F02'):
        assert x['upstream_count']==1
        assert ('event: error' in x['sse']) == ('eof' not in name)
    if name.startswith('F03/F04'):
        assert x['status']==(200 if "'{\"ok\":true}'" in name else 502)
    if name.startswith('F08/F09'):
        expect=1 if '(99, 400)' in name or '(99, 401)' in name else 3
        assert x['actual_requests']==expect
        assert x['ledger']['attempts']==(3 if '(2, 500)' in name else 1)
    if name=='F10/F11':
        assert x['statuses']==[200,429,200,200]
        assert x['after']['errors_by_code']['rate_limited']-x['before']['errors_by_code']['rate_limited']==2
    if name=='stream_local_limit':assert x['status']==200 and 'rate_limited' in x['sse']
assert json.loads((e/'student-verify.json').read_text())['passed']==17
assert json.loads((e/'student-injected-failure.json').read_text())['passed']==13
original=json.loads((e/'real-original-results.json').read_text())
assert len(original)==4 and all(x['http']==200 for x in original)
real=[x for x in json.loads((e/'real-results.json').read_text()) if 'mode' in x]
assert len(real)==6 and [x['http'] for x in real]==[200,200,200,200,200,502]
supp=json.loads((e/'supplement-results.json').read_text())
assert all(x['new_records']==[] for x in supp if x['name']=='ledger_missing')
assert next(x for x in supp if x['name']=='chat_cache_usage')['body']['usage']['cached_tokens']==0
assert next(x for x in supp if x['name']=='official_prefill_control')['body']['content'][-1]['text']=='{"ok":true}'
assert next(x for x in supp if x['name']=='real_flash_schema_control')['body']['error']['upstream_status']==400
assert 'port 18305: not listening' in (e/'shutdown.log').read_text()
# AMP_SECRET_ENV_NAMES contains variable names, not secret values.
secret_values=[v.encode() for k,v in os.environ.items() if k!='AMP_SECRET_ENV_NAMES' and re.search(r'KEY|TOKEN|SECRET|PASSWORD',k,re.I) and len(v)>=8]
for p in root.rglob('*'):
    if not p.is_file():continue
    assert p.name!='.env' and p.suffix not in ('.pyc', '.p12')
    data=p.read_bytes()
    assert not any(v in data for v in secret_values),f'secret value in {p.relative_to(root)}'
    if p.parent==e and p.suffix in ('.json','.log','.jsonl'):
        assert not re.search(rb'(?i)(?:authorization|x-api-key)["\s]*[:=]["\s]*(?:bearer\s+)?sk-[a-zA-Z0-9_-]{16,}',data)
report={'scores':scores,'score':85,'maximum':100,'grade':'优秀','acceptance':'证据不完整','format':counts,'controlled_scenarios':45,'student_sim':'17/17','injected_failure':'13/17, exit 1','secrets_exact_match':'zero matches','env_files':'none','services':'all stopped','evidence_assertions':'passed'}
(root/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
