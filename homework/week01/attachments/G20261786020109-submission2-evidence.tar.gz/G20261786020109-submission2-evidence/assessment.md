# 第一周作业评测附件：第二次提交独立复评

本次暂评85/100，等级优秀；新仓库已解决前次缺源码问题，但不能把离线17/17等同于双模型全部真实功能通过。

- 学员：hush / G20261786020109。
- 仓库：https://github.com/1qq-1233/LLM_gateway 。
- 分支与固定提交：main，检出为 detached HEAD；`d280b522acb484e9e2da3693f6a52e55b5bb931f`。
- 评测日期：2026-11-14，Asia/Singapore（执行日志使用UTC，转换需加8小时）。
- 总分：85/100（暂评分；环境及替代上游兼容限制不扣代码分）。
- 作业等级：优秀（≥80；良好≥60且<80；未设封顶）。
- 验收结论：证据不完整。两个模型普通、流式和双协议真实接入已验证，但 Flash 真实结构化尚未闭环；另有下述已验证代码缺陷待修复。
- 评分依据：完整读取评分标准v1.1、反馈报告模板v1.0、第一周作业原文、第一次学员报告及附件。旧结论未用作本仓库事实。
- 范围：本线程新orb实际clone，自行完成，没有创建线程、修改学生业务逻辑、提交或推送。只新增本次指定三份交付物，第一次三份文件保留，摘要见证据包 `evidence/first-submission-sha256.txt`。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 同一入口按model路由；Responses、Messages真实请求均可工作；Chat兼容备选也实测；未知模型明确报错。错误边界只在错误项计分。 |
| 流式输出 | 13/15 | 双协议门控增量通过，输出后错误和硬断流均只请求一次；无终态EOF却返回response.stop并记ok，D1扣2。 |
| 结构化输出 | 10/10 | 非法、空、截断JSON和Schema类型错误均明确失败；本地校验及双协议模拟正常流程通过。Flash真实兼容阻塞另列未闭环，不据此扣代码分。Schema引用错误仅在错误项扣分。 |
| 提示词版本管理 | 10/10 | v1/v2保留、显式版本实际进入上游，缺模板/版本/变量不发送残留占位符。 |
| 可观测性 | 8/15 | 正常请求有编号、用量、总延迟和正文首Token延迟；D2失败记录生命周期扣4，D3用量映射扣2，D4限流计数重复扣1。 |
| 统一错误与重试 | 12/15 | 500/429实际三次，400/401实际一次，无SDK叠加；D5上游400映射扣1，D6Schema引用未封装500扣1，D7抖动超退避边界扣1。 |
| 按模型独立限流 | 8/10 | 普通调用HTTP429、A/B隔离和令牌恢复均通过；D8流式超限实际HTTP200扣2。 |
| 源码、README 与验证脚本 | 9/10 | 源码完整、安装启动可复现、curl形状可用；原脚本17/17，制造失败13/17且exit1；D9脚本未实际断言B隔离及恢复扣1。 |
| 合计 | 85/100 | 15+13+10+10+8+12+8+9=85；累计扣15，同根因不跨项目重复扣分。 |

可观测性拆分：用量及计数准确性2/5、延迟4/4、关联与查询2/3、失败记录0/3，合计8/15。D2中的失败出口漏账、耗尽次数固定1、校验失败丢已知用量共扣4，分别占关联1分与失败记录3分；D3用量映射扣2、D4计数重复扣1，合计使用量及计数由5降为2。不是把每个协议、每种输入都重复扣一次。

## 固定对象与前次问题核实

实际执行 `git clone https://github.com/1qq-1233/LLM_gateway.git`，记录HEAD后detach固定。`git ls-tree -r HEAD`确认27个必需文件、16个app Python文件均存在；`scripts/check_submission.py`也报告27/27。新提交包含app、scripts、prompts和evidence，学生工作树在评测前后均干净。原源码与行号保存在证据包 `source/`，完整文件树见 `evidence/source-tree.txt`。

第一次针对另一仓库 `1qq-1233/week_01` 的固定提交 `b3a4115d615d7b61a139caa41ca0b6ce71e21503` 判待评，本次不改写其报告、不追溯造分。现在可以确认“本次仓库缺源码”不成立。新README对上次文件清单的转述不用于推翻第一次取证。

## 执行环境与复现入口

- Python独立venv，`pip install -r requirements.txt`成功；实际版本见 `evidence/dependencies.txt`，安装输出见 `evidence/install.log`。
- 按README运行 `bash scripts/run.sh`，受控网关18300；另以`python -m uvicorn app.main:app`启动18304等实例，健康检查成功。只替换配置、目录及端口，不修补业务代码。运行时模板和账本均在学生检出目录外。
- 学生原脚本：`python student/scripts/verify.py --mode sim --base-url http://127.0.0.1:18300 --sim-port 18301 --report evidence/student-verify.json`，exit0，17/17。
- 教师受控测试：`controlled.py`为本地HTTP协议上游，`controlled_checks.py`运行45个观测场景，exit0表示取证脚本执行完成，不表示45项全部通过。每项结论由响应、次数、时间及源码共同判定。
- 制造失败：受控上游设置`text=not-json, tool=false`后，原脚本以`--mode real`访问**本地**18300，报告13/17、exit1。这个文件名中的real只是学生脚本的模式，不是真实供应商证据；两条结构化断言失败，另两条因样例仅一个内容块而失败。没有篡改学生脚本断言。
- 证据包中的 `REPRODUCE.md`给出服务、脚本和停止命令；`real_launcher.py`只从环境读取DEEPSEEK_API_KEY，不含值，不写.env。真实调用脚本在 `real_checks.py`、`real_original.py`、`supplement.py`。

## A01–A04 / F01–F12逐项结果

| 编号 | 结论 | 实际结果及证据 |
| --- | --- | --- |
| A01 | 通过 | 独立venv安装成功；run.sh和uvicorn入口实际启动，healthz正常。tree-check、install、*-start-health、gateway服务日志。 |
| A02 | 通过（普通调用） | Pro、Flash均真实返回OK和统一结构；不是仅检查模型注册表。真实JSON范围另见F03。 |
| A03 | 通过 | 原Responses适配器实际调用官方`/responses`；Messages实际调用`/anthropic/v1/messages`，请求体分别使用input/instructions与messages/system。受控请求体也保留在A03条目；不是用两个Chat标签冒充双协议。 |
| A04 | 通过 | unknown非流式404 model_not_found，未调用默认模型。流式也明确error事件，但其HTTP预检及漏账另列。 |
| F01 | 通过 | Responses、Messages在上游尚未发送终态时，下游已收到gate-content，教师才POST/release；两项received_before_release=true。空元数据先到，正文TTFT约82ms，不用连接建立时间代替首Token。 |
| F02 | 部分通过 | error事件与传输硬断开均下发error且实际上游计数1，未重新生成；没有协议终态的正常EOF却产生成功stop，D1。 |
| F03 | 模拟通过；真实部分未闭环 | 双协议Schema、json_object受控成功，Pro真实两种格式通过。Flash真实json_object变成双左花括号而502；Schema因默认thinking不支持强制tool_choice被官方400拒绝。见真实调用表及兼容说明。 |
| F04 | 通过 | 两协议分别注入not-json、空字符串、`{"ok":`、布尔字段返回字符串，均502 structured_output_invalid；合法对象对照200。没有修复回路，因此“修复后仍非法”不适用，未虚称测试修复能力。 |
| F05 | 通过 | teacher2发布v1/v2，显式引用@1/@2分别送入上游`v1 old`和`v2 new second`；更新后旧版仍可用。 |
| F06 | 通过 | 缺模板404、缺版本404、缺变量400，受控requests为空；流式模板失败同样明确报错，但缺账另计D2。 |
| F07 | 部分通过 | 正常账本、用量及延迟存在；失败遗漏、实际次数误记、已知用量丢失、分类不完整、计数重复见D2–D4。 |
| F08 | 次数通过，退避边界失败 | 两次500后成功，两协议均上游实际收到3次；持续失败3次停止。真实间隔和错误retry_history均保留；叠加抖动超边界见D7。 |
| F09 | 通过（次数及不可重试） | 两协议持续500/429均3次；400/401均1次，无OpenAI/Anthropic SDK，httpx默认传输也无内置重试；400状态映射另计D5。 |
| F10 | 部分通过 | 普通A请求200→429，B仍200；同一额度流式请求HTTP200、正文rate_limited，D8。 |
| F11 | 通过 | A设置60RPM/burst1，耗尽后不重置桶，等待1.1秒再次200。序列[200,429,200,200]依次为A正常/A超限/B正常/A恢复。 |
| F12 | 部分通过 | 原脚本17/17；制造非法JSON后能报告失败并exit1。但“模型级限流”只检查A出现429和计数，不调用B也不等待恢复，D9。 |

## 真实调用、协议与外部配置

仅使用环境变量DEEPSEEK_API_KEY，且只发到`https://api.deepseek.com`。没有访问OpenAI、Anthropic或其他供应商端点，没有打印密钥、记录鉴权头或创建.env。短prompt，每次输出预算512，超时45秒；网关默认三次上限未调整。实际所有真实供应商请求均一次，没有以压测验证限流。

原示例A为Responses→gpt-4o-mini、B为Messages→claude-sonnet-4-5，示例Base URL是其他供应商；本次全部替换为官方DeepSeek配置：

| 用途 | 对外别名 | 协议 | 实际上游模型 / Base URL |
| --- | --- | --- | --- |
| 原协议正式复验 | deepseek-v4-pro | openai_responses | deepseek-v4-pro / https://api.deepseek.com |
| 原协议正式复验 | deepseek-v4-flash | anthropic_messages | deepseek-flash / https://api.deepseek.com/anthropic |
| 额外兼容路径 | deepseek-v4-pro | openai_chat_completions | deepseek-v4-pro / https://api.deepseek.com |

Flash别名保留学生命名，不把它误写为上游仍叫deepseek-v4-flash；当前官方deepseek-flash由V4.1 Flash服务。Chat只是额外验证，不用于代替原双协议证明。所有改动均在外部环境配置，原适配器未修改。

| 真实场景 | 网关请求编号 | HTTP / 结果 | 用量（输入/输出/总计；分类） | 网关总延迟 |
| --- | --- | --- | --- | --- |
| Pro Responses普通 | req_5926cf0a2e0943e6 | 200，OK | 90/33/123；推理31 | 1379.46ms |
| Pro Responses流式 | req_75e26dc6cf2d4461 | 200，OK，stop | 90/24/114；推理22 | 1191.53ms；正文TTFT1190.01ms |
| Pro Responses JSON | req_9944a5a797c24fda | 200，`{"ok":true}` | 112/37/149；推理31 | 1366.40ms |
| Pro Responses Schema | req_1ceb0b51c2024764 | 200，校验通过 | 138/24/162；缓存128、推理18 | 1427.30ms |
| Flash Messages普通 | req_9ed8c8df61b74607 | 200，OK | 网关37/8/45；分类存在遗漏风险 | 1069.90ms |
| Flash Messages流式 | req_57664de0edcc4d35 | 200，OK，end_turn | 网关37/13/50；分类存在遗漏风险 | 669.84ms；正文TTFT668.97ms |
| Flash Messages JSON | req_88993d8520214a8c | 502，校验拒绝`{{"ok":true}` | 本次失败账本没有保留已知上游用量 | 端到端855ms |
| Flash Messages Schema | req_356482b2b392496b | 上游400，被网关映射502 | 上游未返回可用量；不能写成0实耗 | 见supplement与服务日志 |

正文TTFT采用首个非空正文增量，忽略thinking/心跳，和代码一致。以上是网关输出的用量，不把存在映射问题的Flash数字称为完整真实账单。额外Chat三次普通/流式/JSON均200，原始请求编号、正文、用量与延迟在`real-results.json`；正式Responses四次在`real-original-results.json`。

Flash真实结构化限制的判定：

- 官方Messages直连对照，响应ID `c006382f-16f6-46e2-8422-c07aeb38ee78`，在同样assistant `{`前缀下返回完整`{"ok":true}`；学生适配器116–117行无条件补`{`，在该兼容端点上造成非法JSON。其上游usage还包含`output_tokens_details.thinking_tokens=12`，而适配器只读顶层reasoning_tokens。
- Schema路径被官方明确拒绝：“Thinking mode does not support this tool_choice”，官方请求ID `8e7a9d8e-2eeb-4631-ac0b-9efb0eb90f3f`。学生统一请求没有thinking配置入口，未修改业务逻辑来关闭thinking凑成功。
- 这两项属于本次替代上游的兼容限制；没有原Anthropic供应商凭据验证其原配置，不能据此断言原配置Schema路径也不可用，不扣结构化正常流程分。后续须补原配置的真实证据或明确适配兼容端点。本次不能写“双模型真实结构化通过”。上游400转502则是可独立复现的统一错误缺陷，只计D5一次。
- 依据的官方文档：https://api-docs.deepseek.com/ 、https://api-docs.deepseek.com/guides/responses_api 、https://api-docs.deepseek.com/guides/anthropic_api 。文档支持Responses与Messages，不能以旧知识认定官方只有Chat。

## 待修复问题与单一计分归属

### D1：无成功终态的EOF被当作成功（流式输出，扣2）

- 触发：受控上游先发one-piece，再结束HTTP流，不发送response.completed或message_stop。
- 预期：客户端得到明确错误，账本失败；不得伪造正常完成。
- 实际：两协议均response.stop、finish_reason=null、status=ok；实际请求1次，没有重复生成。
- 源码：`app/gateway.py:200–213,230–247`在迭代结束后不检查成功终态；各适配器stream循环也没有终态完整性检查。
- 复现证据：`controlled_checks.py`、`evidence/controlled-results.json`中的`F02 eof`；输出后硬断流与error事件为对照，均error且不重试。
- 不再因同一次EOF的ok账本重复扣可观测分；普通length建议不单独扣分。

### D2：失败生命周期记录不完整（可观测性，扣4）

- 触发：未知模型、流式缺模板、文本后硬断流、重试耗尽、JSON校验失败。
- 预期：每个调用有可关联记录；次数等于实际尝试，已知用量不丢，未知部分明确标识。
- 实际：`supplement-results.json`三类失败`new_records=[]`；耗尽真实3次，error.details.attempts=3，但同request_id账本attempts=1；非法JSON上游已返回19输入和7输出，校验错误记录usage={}。本地流式超限也不落账。
- 源码：`app/gateway.py:123–127`路由在try外；`140`固定attempts=1且不保留raw.usage；`176–186`流式预处理在主try外；`225–228`兜底只yield、不record。
- 证据：controlled-results中F08/F09逐条带按request_id匹配的ledger，F07最终calls；supplement中前后差集。并非只取账本第一条猜测是否有关联。
- 扣分拆分：遗漏关联记录1、失败记账与次数/已知用量3；同根因两个协议不叠扣，重试项不再扣次数上限，因为实际次数确实有限。

### D3：输入/输出及缓存推理用量明细未正确归一（可观测性，扣2）

- 触发：非零缓存Messages响应，或Chat响应只提供DeepSeek的prompt_cache_hit_tokens。
- 预期：按各协议口径记录输入、输出和上游实际提供的缓存、推理明细。Responses的缓存是输入子集、推理是输出子集，不重复相加；Messages的input_tokens不含缓存输入，应另纳入完整输入口径。
- 实际：受控Messages非缓存输入19、缓存读5、缓存写2、输出7，完整输入26、总计33；网关输入19、总计26，缓存读写合并7却标作命中缓存。Chat受控cache hit=5，网关cached_tokens=0。原Messages适配器也不读官方返回的output_tokens_details.thinking_tokens，缺失值直接显示0且未说明未知口径。
- 源码：`app/adapters/anthropic_messages.py:125–136,146–172`；`app/adapters/openai_chat.py:21–31`；`app/models.py:57–64`。
- 证据：controlled-results A03与F01中非零缓存响应；supplement的chat_cache_usage及官方prefill对照；`controlled.py`明确列出注入用量，不从被测实现反推期望。
- 不按每个字段分别扣分，也不因未提供的分类强求编造；计入该归一根因共2分。

### D4：一次普通限流错误累计两次（可观测性，扣1）

- 触发：普通A第一次成功后，第二次本地超限；对比metrics前后差值。
- 预期：一次拒绝，错误与限流计数各增加1。
- 实际：errors_by_code.rate_limited增加2。先调用bump_rate_limited，再record时又递增同一错误/限流计数。
- 源码：`app/gateway.py:134–143`；`app/observability.py:52–64,83–86`。
- 证据：controlled-results的F10/F11 before/after；与D8的HTTP状态错误分属独立原因。

### D5：上游请求错误被映射为502（统一错误与重试，扣1）

- 触发：受控上游返回400；真实Flash强制tool_choice也返回400。
- 预期：上游不支持所请求格式，统一错误响应应为明确4xx。
- 实际：502 upstream_bad_response，上游状态400仅存正文；请求只发一次，不可重试次数本身正确。
- 源码：`app/errors.py:70–81`兜底把400归为upstream_bad_response（502）。
- 证据：controlled-results中两个`F08/F09 (99, 400)`；supplement真实Schema控制。此问题不再在结构化或统一接口重复扣。

### D6：坏Schema本地引用触发裸500（统一错误与重试，扣1）

- 触发：`$ref=#/$defs/missing`，只定义present。
- 预期：入口或校验层明确报告非法请求；正常引用仍工作。
- 实际：500纯文本Internal Server Error，jsonschema的WrappedReferencingError未统一封装；`#/$defs/present`对照200。
- 源码：`app/gateway.py:112–117`只捕获ValidationError；`app/models.py:26–30`只检查Schema是否为空。
- 证据：controlled-results的两条schema_ref、gateway-service.log异常堆栈。首次教师客户端复用该500连接后发生ReadError，已改测试客户端Connection:close复验两条对照；没有改学生逻辑。

### D7：抖动叠加在退避边界之外（统一错误与重试，扣1）

- 触发：默认base=.5、max=8，两次可重试失败。
- 预期：第1/2次等待不超过min(cap,base×2^(n−1))，即.5/1秒；允许该范围内抖动。
- 实际：Responses耗尽记录sleep_s=.585/1.041，实际HTTP间隔.588/1.044；Messages耗尽sleep_s=.554/1.056。源码在min之后加正抖动，也可能越过cap。
- 源码：`app/retry.py:41–49,54–56`。
- 证据：controlled-results错误retry_history和实际请求时间。没有只凭网络间隔略超限认定睡眠错误；睡眠日志与源码均确认。
- 保留指数增长、有限重试、不可重试立即失败的其余得分；没有SDK内置重试叠加，持续失败每协议最多3次。

### D8：流式本地超限未返回HTTP429（按模型独立限流，扣2）

- 触发：A耗尽本地令牌，再以stream=true请求。
- 预期：HTTP429，不能只在HTTP200的SSE里写429。
- 实际：HTTP200 text/event-stream，唯一事件error.code=rate_limited，data.http_status=429。
- 源码：`app/main.py:79–83`先建立成功StreamingResponse；`app/gateway.py:178–183`在生成器内检查额度。
- 证据：controlled-results的stream_local_limit。普通HTTP429、隔离、恢复都真实通过；仅从超限HTTP状态子项3分中扣2，不把模型隔离也判失败。

### D9：限流验证脚本没有覆盖隔离与恢复（源码、README与脚本，扣1）

- 触发：阅读并实际运行学生verify.py的14项。
- 预期：覆盖全部功能点，分别断言A耗尽、B不受影响、窗口恢复。
- 实际：只验证A状态码出现429及rate_limited_total>0；直接重设A桶结束，没有调用B或等待原桶补充。教师独立测试确认这两项实现本身可用。
- 源码：`scripts/verify.py:319–337`的`# 14 按模型独立限流`代码段。
- 证据：student-verify.json、student-injected-failure.json、固定脚本源码；该扣分只针对独立的覆盖缺口，不为D1–D8缺少回归逐个追加扣分。

## 未验证范围、补交和收尾

- 未闭环：Flash在原供应商配置下的真实JSON/Schema；当前DeepSeek兼容端点的Flash真实结构化成功路径；原示例供应商账号不在本次允许访问范围。不能用模拟或其他协议成功替代该证据，不因这些环境/配置限制扣代码分。
- 不要求学生增加Redis、分布式限流、自动JSON修复或流式与结构化组合。没有对NaN/Infinity额外扣分，也没有将普通截断当独立扣分项。
- 必须修复：D1–D8已证实缺陷，补齐D9有效断言；特别按请求编号验证失败记录、真实尝试次数和已知用量不丢。
- 必须补证：双模型双协议真实普通、流式及结构化结果，明确模型映射、状态、用量及延迟；Flash需原配置成功证据或兼容能力适配说明。证据不得含密钥、.env或鉴权头。
- 复验标准：相同受控失败用例不再出现伪成功、漏账、错误次数、重复统计或HTTP200限流；原17项及新增断言通过；真实兼容受阻项如仍无法执行应继续标未验证。
- 服务收尾：本次启动的hush2-gateway、hush2-sim、hush2-control、hush2-real、hush2-chat、hush2-original全部停止；端口18300–18305均不再监听。停止结果在证据包shutdown.log。
- 交付状态：仅新增第二次反馈、第二次内部附件、第二次脱敏证据包；旧三份原样保留。未提交、未推送。
