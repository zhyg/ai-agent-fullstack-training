import asyncio
import json
from pathlib import Path
import httpx

ROOT = Path(__file__).parent
OUT = ROOT/'evidence'
results = []
A, B = 'deepseek-v4-pro', 'deepseek-v4-flash'

async def main():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18300', timeout=20, headers={'Connection':'close'}) as c, httpx.AsyncClient(base_url='http://127.0.0.1:18302', timeout=20) as u:
        async def setup(**kw):
            await u.post('/control', json=kw)
        async def ask(model=A, **kw):
            return await c.post('/v1/chat', json={'model': model, 'input': 'short test', **kw})
        async def record(name, **kw):
            results.append({'name': name, **kw})
            (OUT/'controlled-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
        async def calls():
            return (await c.get('/v1/calls', params={'limit': 2000})).json()['data']
        for m in (A, B):
            await c.post(f'/admin/models/{m}/upstream', params={'base_url': 'http://127.0.0.1:18302/v1', 'upstream_model': 'controlled'})
            await c.post(f'/admin/ratelimit/{m}', params={'rpm': 6000, 'burst': 200})
        await setup()
        r = await ask(model='unknown')
        await record('A04 unknown', status=r.status_code, body=r.json())
        for m in (A, B):
            await setup()
            r = await ask(m, system='system control')
            await record('A03 normal '+m, status=r.status_code, body=r.json(), upstream=(await u.get('/stats')).json())
            # Read first content before releasing upstream completion, rather than infer from elapsed times.
            await setup(mode='gate', text='gate-content')
            events = []
            released = False
            async with c.stream('POST', '/v1/chat', json={'model': m, 'input': 'gate', 'stream': True}) as s:
                async for line in s.aiter_lines():
                    if line:
                        events.append(line)
                    if line.startswith('data:') and '"delta"' in line and not released:
                        released = True
                        await u.post('/release')
            await record('F01 gate '+m, received_before_release=released, events=events)
            for mode in ('error', 'disconnect', 'eof'):
                await setup(mode=mode, text='one-piece')
                r = await ask(m, stream=True)
                await record('F02 '+mode+' '+m, sse=r.text, upstream_count=len((await u.get('/stats')).json()['requests']))
            for text in ('{"ok":true}', 'not-json', '', '{"ok":', '{"ok":"wrong"}'):
                await setup(text=text, tool=False)
                r = await ask(m, response_format={'type': 'json_schema', 'json_schema': {'type': 'object', 'properties': {'ok': {'type':'boolean'}}, 'required':['ok']}})
                await record('F03/F04 '+repr(text)+' '+m, status=r.status_code, body=r.json())
            await setup(text='{"ok":true}')
            r = await ask(m, response_format={'type':'json_object'})
            await record('F03 json_object '+m, status=r.status_code, body=r.json())
        await c.delete('/v1/templates/teacher2')
        await c.post('/v1/templates', json={'name':'teacher2', 'content':'v1 {{x}}'})
        await c.post('/v1/templates/teacher2/versions', json={'content':'v2 {{x}} {{y}}'})
        for ref, variables in [('teacher2@1', {'x':'old'}), ('teacher2@2',{'x':'new','y':'second'}), ('missing',{}), ('teacher2@99',{}), ('teacher2@2',{'x':'only'})]:
            await setup()
            r = await c.post('/v1/chat', json={'model':A, 'template':ref, 'variables':variables})
            await record('F05/F06 '+ref, status=r.status_code, body=r.json(), upstream=(await u.get('/stats')).json())
        for m in (A,B):
            for fail, status in ((2,500),(99,500),(99,400),(99,401),(99,429)):
                await setup(fail=fail,status=status)
                r=await ask(m)
                upstream=(await u.get('/stats')).json()['requests']
                times=[x['t'] for x in upstream]
                body = r.json()
                rid = body.get('id') or body['error']['request_id']
                ledger = next((x for x in await calls() if x['request_id'] == rid), None)
                await record('F08/F09 '+str((fail,status))+' '+m,status=r.status_code,body=body,actual_requests=len(upstream),intervals=[round(b-a,3) for a,b in zip(times,times[1:])],ledger=ledger)
        # Invalid schema reference is a promised Schema capability, with a valid reference control.
        for ref in ('#/$defs/missing','#/$defs/present'):
            await setup(text='{"ok":true}')
            r=await ask(response_format={'type':'json_schema','json_schema':{'$ref':ref,'$defs':{'present':{'type':'object'}}}})
            await record('schema_ref '+ref,status=r.status_code,body=r.text)
        # Local rate isolation and genuine token refill, without resetting between exhausted and recovered call.
        await setup()
        await c.post(f'/admin/ratelimit/{A}',params={'rpm':60,'burst':1})
        r1=await ask()
        before=(await c.get('/v1/metrics')).json()
        r2=await ask()
        after=(await c.get('/v1/metrics')).json()
        rb=await ask(B)
        await asyncio.sleep(1.1)
        r3=await ask()
        await record('F10/F11',statuses=[r1.status_code,r2.status_code,rb.status_code,r3.status_code],limited=r2.json(),before=before,after=after)
        # SSE local rejection status and missing preflight ledger.
        rs=await ask(stream=True)
        await record('stream_local_limit',status=rs.status_code,sse=rs.text,ledger=(await calls())[:4])
        await c.post(f'/admin/ratelimit/{A}',params={'rpm':6000,'burst':200})
        for payload in ({'model':'unknown','input':'x'}, {'model':A,'template':'missing'}):
            r=await c.post('/v1/chat',json={**payload,'stream':True})
            await record('stream_preflight',payload=payload,status=r.status_code,sse=r.text)
        allcalls=await calls()
        await record('F07 final ledger',calls=allcalls,metrics=(await c.get('/v1/metrics')).json())
    (OUT/'controlled-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print('Recorded',len(results),'scenarios; inspect controlled-results.json (observations, not automatic pass counts)')

asyncio.run(main())
