import asyncio
import json
import os
import time
from pathlib import Path
import httpx

root=Path(__file__).parent

async def main():
    out=[]
    async with httpx.AsyncClient(timeout=60,headers={'Connection':'close'}) as c:
        # Real JSON Schema control uses the existing Anthropic adapter's tool mapping, unchanged.
        p={'model':'deepseek-v4-flash','input':'Use the tool to emit {"ok":true}.','max_output_tokens':512,
           'response_format':{'type':'json_schema','json_schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}}
        r=await c.post('http://127.0.0.1:18303/v1/chat',json=p)
        out.append({'name':'real_flash_schema_control','request':p,'http':r.status_code,'body':r.json()})
        # Direct official protocol control: same assistant prefill and short JSON prompt; no third-party endpoint.
        key=os.environ.get('DEEPSEEK_API_KEY','')
        if key:
            headers={'x-api-key':key,'anthropic-version':'2023-06-01'}
            p={'model':'deepseek-flash','messages':[{'role':'user','content':'Return only JSON: {"ok":true}'},{'role':'assistant','content':'{'}], 'temperature':.7,'max_tokens':512,'stream':False}
            r=await c.post('https://api.deepseek.com/anthropic/v1/messages',headers=headers,json=p)
            out.append({'name':'official_prefill_control','request':p,'http':r.status_code,'body':r.json()})
        # DeepSeek-specific usage fields through the actual Chat adapter and HTTP stack.
        await c.post('http://127.0.0.1:18302/control',json={})
        r=await c.post('http://127.0.0.1:18304/v1/chat',json={'model':'deepseek-v4-pro','input':'usage fixture'})
        out.append({'name':'chat_cache_usage','http':r.status_code,'body':r.json(),'upstream':(await c.get('http://127.0.0.1:18302/stats')).json()})
        # Observe exact per-request ledger changes, including failures before a start event.
        for payload in ({'model':'absent','input':'x'}, {'model':'deepseek-v4-pro','template':'missing','stream':True}, {'model':'deepseek-v4-pro','input':'x','stream':True}):
            if payload.get('input')=='x' and payload['model']=='deepseek-v4-pro':
                await c.post('http://127.0.0.1:18302/control',json={'mode':'disconnect'})
            before=(await c.get('http://127.0.0.1:18300/v1/calls?limit=2000')).json()['data']
            r=await c.post('http://127.0.0.1:18300/v1/chat',json=payload)
            after=(await c.get('http://127.0.0.1:18300/v1/calls?limit=2000')).json()['data']
            out.append({'name':'ledger_missing','request':payload,'http':r.status_code,'body':r.text,'new_records':[a for a in after if a['request_id'] not in {b['request_id'] for b in before}]})
        # Student validation failure injection, prepared here; run verify separately in mode real against local-only routes.
        await c.post('http://127.0.0.1:18302/control',json={'text':'not-json','tool':False})
    text=json.dumps(out,ensure_ascii=False,indent=2)
    key=os.environ.get('DEEPSEEK_API_KEY','')
    if key:text=text.replace(key,'<REDACTED>')
    (root/'evidence/supplement-results.json').write_text(text)
    print('Supplement recorded',len(out),'scenarios')

asyncio.run(main())
