# 第二次提交独立复评复现

对象：1qq-1233/LLM_gateway，固定提交d280b522acb484e9e2da3693f6a52e55b5bb931f。source/来自该提交；仅.env.example将示例API_KEY赋值脱敏，不用于运行。已有.env、鉴权头、真实密钥均不在包中。

本包不是“全部通过”报告。controlled-results.json记录45个实际场景，其中部分观察正是缺陷；评分与逐项预期见assessment.md。student-verify.json是本次复跑17/17，不是学生已有报告。student-injected-failure.json虽模式名为real，所有上游都在本地，用于证明脚本能报告失败，不是真实模型证据。

## 安装和本地受控复现

解压到独立空目录，在该目录执行以下命令。使用18300–18305，先确认无其他任务占用。Amp orb内使用受管服务；其他环境可在独立终端以前台方式启动同样命令，完成后Ctrl-C。

```bash
ROOT=$(pwd)
python -m venv venv
venv/bin/pip install -r source/requirements.txt
ln -s source student
venv/bin/python source/scripts/check_submission.py --root source
amp orb service start hush2-gateway --port 18300 --command "PATH=$ROOT/venv/bin:\$PATH PROMPTS_DIR=$ROOT/runtime-prompts LOG_DIR=$ROOT/runtime-logs PORT=18300 bash $ROOT/source/scripts/run.sh"
amp orb service start hush2-sim --port 18301 --command "$ROOT/venv/bin/python -m uvicorn scripts.faulty_upstream:app --app-dir $ROOT/source --host 127.0.0.1 --port 18301"
# 等待healthz成功，再运行原脚本。
curl -fsS http://127.0.0.1:18300/healthz
venv/bin/python source/scripts/verify.py --mode sim --base-url http://127.0.0.1:18300 --sim-port 18301 --report evidence/reproduced-student.json
amp orb service start hush2-control --port 18302 --command "$ROOT/venv/bin/python -m uvicorn controlled:app --app-dir $ROOT --host 127.0.0.1 --port 18302"
# 等待control端口就绪后执行，模板与日志均在source外。
curl -fsS http://127.0.0.1:18302/stats
venv/bin/python controlled_checks.py
```

controlled_checks.py每次刷新本次运行的controlled-results.json；若想保留本包原始证据，先在另一个空目录复制脚本运行，或备份原始evidence目录。它不修改source业务源码。门控只有下游收到delta后才释放上游终态；错误事件、硬断流、EOF分别验证；次数取上游真实HTTP请求数；账本按request_id匹配，不依赖排序。

## 真实调用及补充对照

在运行环境安全提供DEEPSEEK_API_KEY，不要把值写入命令、报告或.env。只使用DeepSeek官方域名。下面步骤会产生少量真实费用；每次短prompt、max_output_tokens=512。必须确认service继承的环境有该变量。

```bash
amp orb service start hush2-real --port 18303 --command "$ROOT/venv/bin/python $ROOT/real_launcher.py"
amp orb service start hush2-chat --port 18304 --command "MODEL_A_PROTOCOL=openai_chat_completions MODEL_A_BASE_URL=http://127.0.0.1:18302/v1 PROMPTS_DIR=$ROOT/chat-prompts LOG_DIR=$ROOT/chat-logs $ROOT/venv/bin/python -m uvicorn app.main:app --app-dir $ROOT/source --host 127.0.0.1 --port 18304"
amp orb service start hush2-original --port 18305 --command "$ROOT/venv/bin/python $ROOT/real_launcher.py --responses"
# 确认三个healthz均成功后运行，不把启动竞态当作业务故障。
venv/bin/python real_checks.py
venv/bin/python real_original.py
venv/bin/python supplement.py
# supplement最后设置本地非法JSON。以下real模式仅访问本地模拟，不是真实供应商请求。
venv/bin/python source/scripts/verify.py --mode real --base-url http://127.0.0.1:18300 --sim-port 18301 --report evidence/reproduced-injected-failure.json
```

实际配置映射：18303的A为Chat→deepseek-v4-pro，B为Messages→deepseek-flash；18305的A保留Responses→deepseek-v4-pro，B同上。官方域名均api.deepseek.com，Messages Base URL带/anthropic。18304是无凭据本地Chat用量样例。原始真实结果在real-results、real-original-results、supplement-results；供应商返回的usage及网关usage不能混为完整账单。Flash结构化未闭环，不能将上述脚本退出0解释为通过。

## 收尾

```bash
for name in hush2-gateway hush2-sim hush2-control hush2-real hush2-chat hush2-original; do
  amp orb service stop "$name"
done
```

本次取证已全部停止，shutdown.log记录结果。source原文件sha256列在source-sha256.txt；MANIFEST.sha256覆盖证据包文件。validation.json记录格式、总分、证据断言及脱敏检查。首次三份文件的摘要另列，便于确认未覆盖。
