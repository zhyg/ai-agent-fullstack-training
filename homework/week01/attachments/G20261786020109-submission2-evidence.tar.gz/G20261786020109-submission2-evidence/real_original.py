import asyncio
import json
import os
import time
from pathlib import Path
import httpx

async def main():
    results=[]
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18305',timeout=150) as c:
        for mode in ('normal','stream','json','schema'):
            p={'model':'deepseek-v4-pro','input':'仅回答OK，不要解释。','max_output_tokens':512}
            if mode=='stream':p['stream']=True
            if mode in ('json','schema'):
                p.update(input='Return only JSON: {"ok":true}',response_format={'type':'json_object'})
            if mode=='schema':p['response_format']={'type':'json_schema','json_schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}
            t=time.monotonic()
            r=await c.post('/v1/chat',json=p)
            results.append({'mode':mode,'request':p,'http':r.status_code,'body':r.text,'elapsed_s':round(time.monotonic()-t,3)})
            print(mode,r.status_code,flush=True)
    text=json.dumps(results,ensure_ascii=False,indent=2)
    key=os.getenv('DEEPSEEK_API_KEY','')
    if key:text=text.replace(key,'<REDACTED>')
    (Path(__file__).parent/'evidence/real-original-results.json').write_text(text)

asyncio.run(main())
