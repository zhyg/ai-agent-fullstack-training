import os
import sys
from pathlib import Path

root = Path(__file__).parent
key = os.environ.get('DEEPSEEK_API_KEY', '')
responses = '--responses' in sys.argv
os.environ.update({
    'MODEL_A_PROTOCOL': 'openai_responses' if responses else 'openai_chat_completions',
    'MODEL_A_BASE_URL': 'https://api.deepseek.com',
    'MODEL_A_UPSTREAM_MODEL': 'deepseek-v4-pro',
    'MODEL_A_API_KEY': key,
    'MODEL_B_PROTOCOL': 'anthropic_messages',
    'MODEL_B_BASE_URL': 'https://api.deepseek.com/anthropic',
    'MODEL_B_UPSTREAM_MODEL': 'deepseek-flash',
    'MODEL_B_API_KEY': key,
    'MODEL_A_TIMEOUT_S': '45', 'MODEL_B_TIMEOUT_S': '45',
    'PROMPTS_DIR': str(root/'real-prompts'), 'LOG_DIR': str(root/'real-logs'),
    'ENABLE_ADMIN': 'false',
})
os.chdir(root/'student')
os.execv(sys.executable,[sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port','18305' if responses else '18303'])
