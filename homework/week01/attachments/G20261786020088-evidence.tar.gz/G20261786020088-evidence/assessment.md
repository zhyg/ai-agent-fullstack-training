# 第一周作业评测附件

- 学员：。（G20261786020088），第一次提交。
- 仓库：https://github.com/BboyXing/AI-Agent
- 分支：main；固定提交：`4b094287a87300fbd9718a4aea75f5b590887733`（detached HEAD）。
- 子目录：`01 LLM Gateway/llm_gateway`。下文源码路径均相对此目录。
- 日期：2026-11-14，Asia/Singapore；主要执行时间 14:23–14:54。以证据文件内 UTC 时间戳为准。
- 总分：**73/100**；作业等级：**良好**。
- 验收结论：**未通过**。双协议和多项基础能力可运行，但指数退避重试、按模型独立限流、模板版本交付未达到要求；不采用封顶或一票否决。
- 完整阅读依据：`hw-guide/week01/第一周作业评分标准.md`（v1.1）、`hw-guide/学员作业反馈报告模板与要求.md`（v1.0）、`hw-guide/week01/第一周作业.md`。
- 证据包：同目录 `G20261786020088-evidence.tar.gz`。其中 `evidence/` 是脚本、脱敏请求正文/响应、配置和日志；`source-evidence.txt` 为固定提交的带行号源码摘录。

## 评分明细

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 统一入口3、路由4、双协议4、统一结果4。实际捕获 Chat Completions 与 Messages 两种请求；未知模型404，干净状态下上游调用数0。 |
| 流式输出 | 14/15 | 双模型SSE5、真实增量5、终止处理2、输出后不重复2。正常门控和传输断流通过；缺少上游成功终态时仍生成 stop/[DONE]，扣1。 |
| 结构化输出 | 7/10 | 双协议Schema正常流程4、成功前解析2、失败处理1。json_schema正常且能拒绝异常；json_object整条路径被忽略，非法/空/截断均成功，合并扣3，不按协议、输入重复扣。 |
| 提示词版本管理 | 7/10 | 文件存储3、变量替换3、版本引用0、缺项处理1。缺少已交付的版本引用/旧版保留约定与流程扣2；缺变量未处理500扣1。 |
| 可观测性 | 8/15 | Token口径2、延迟2、关联查询3、失败记录1。分类丢失及流式输入更新未采纳扣3；无TTFT扣2；入口失败无记录、Schema失败已知用量丢失合并扣2。 |
| 统一错误与重试 | 10/15 | 统一错误4、指数退避0、有限次数3、不可重试3、重试过程0。仅切换候选，不进行同上游重试/指数等待，扣5；不再在接口项重复扣。 |
| 按模型独立限流 | 6/10 | 独立计数0、HTTP429为3、窗口恢复2、可配置1。按key共享桶，不按model分桶，扣4；恢复和429本身保留。 |
| 源码、README 与验证脚本 | 6/10 | 源码依赖2、启动2、curl0、有效脚本2。pnpm11的esbuild构建授权配置未确定致make setup中止扣1；README无curl扣2；脚本未覆盖模板版本、流式首Token计量等完整验收扣1。 |
| **合计** | **73/100** | **15+14+7+7+8+10+6+6=73；扣分合计27。** |

同根因合并：json_object问题只记结构化；按key限流只记限流；模板缺变量500只记模板、不在统一错误再扣；模板缺变量无账本不单独重复扣；EOF误判只记流式、不在账本再次扣；没有重试不再按缺少其回归测试机械重复扣。可观测性计量问题统一在该项内部计分。

## 环境、安装与启动

1. 在新orb实际clone，checkout上述固定commit，未修改学生业务源码；评测前后学生仓库 `git status --short` 为空。
2. Python3.13.5，按README建立 `.tooling`，安装uv0.13.0，执行 `.tooling/bin/uv sync --project apps/api --all-groups` 成功，锁定依赖实际安装。环境Node26.13.1（文档推荐22），pnpm实际为11系列。Node版本差异本身不扣分。
3. `make setup` 的Python安装成功，pnpm安装阶段报 `ERR_PNPM_IGNORED_BUILDS`，esbuild0.28.2未授权。源文件 `pnpm-workspace.yaml:8-9` 的 `allowBuilds.esbuild` 仍是文字 `set this to true or false`，不是确定的布尔授权；同时存在onlyBuiltDependencies。只按项目自身安装配置缺陷扣1，不按环境差异扣分。
4. 未修业务和配置来伪造一键安装通过。继续用已安装的Python环境，实际以README的 `make dev-api` 启动原配置，8000端口 `/healthz` 返回ok，`/readyz` 返回ready/database up/routes2（`default-start.log`）。另用18888受控、18889真实专用端口隔离评测配置与SQLite。
5. 后端原测试：`cd apps/api && ../../.tooling/bin/uv run pytest` → **17 passed**。前端pnpm包装命令同样受构建授权阻断，绕过包装，直接执行已安装的vitest：**4 test files，5 tests passed**；没有修改测试或业务文件。
6. F12主动把原测试的模拟上游统一变为503，原 `test_chat_completion_and_usage_are_persisted` 确实失败，退出1，表明该断言有效；不是“所有测试只检查不崩溃”。

## 真实模型验证与配置映射

仅使用orb已有 `DEEPSEEK_API_KEY` secret；未输出其值、未写入.env或归档、未使用其他供应商。官方接口依据：https://api-docs.deepseek.com/ ，当前注明OpenAI与Anthropic兼容入口及模型名。

| 外部评测路由 | 上游模型 | 学生适配器/实际URL | 说明 |
| --- | --- | --- | --- |
| real-flash | deepseek-flash | openai；`https://api.deepseek.com/chat/completions` | 官方现行Flash名称；不是新增学生适配器。 |
| real-pro | deepseek-v4-pro | anthropic；`https://api.deepseek.com/anthropic/v1/messages` | 学生自动在Anthropic base后拼接/v1/messages；system独立于messages。 |

`real.yaml` 用公开配置能力替代原示例的候选表，不设置跨供应商fallback。原示例default、fast-chat都优先deepseek-chat，后备为GPT和Claude；本次**未验证原deepseek-chat模型名和原跨供应商fallback真实可用性**，未调用OpenAI或Anthropic供应商。本次证明的是固定学生代码在上述明确映射下的官方双模型、双协议能力，不声称原默认表中每个候选通过。

六次主验收均为短prompt、max_tokens512、单候选，无业务改动、无真实故障压测。JSON采用统一 `response_format.type=json_schema`，学生转成系统提示+本地校验，属于允许的实现；不是声称上游原生Schema约束。

| 请求标识 | 状态 | 输入/输出/总Token（学生账本口径） | 账本总延迟ms |
| --- | ---: | --- | ---: |
| real-real-flash-ordinary | 200 | 77/19/96 | 913 |
| real-real-flash-stream | 200 | 77/22/99 | 681 |
| real-real-flash-json | 200 | 114/35/149 | 1110 |
| real-real-pro-ordinary | 200 | 129/38/167 | 1264 |
| real-real-pro-stream | 200 | 1/18/19 | 1197 |
| real-real-pro-json | 200 | 166/63/229 | 1819 |

正文JSON两次均独立解析为 `{"ok":true}`；两次主流式有正文内容及[DONE]。门控增量证据另见受控测试，不能仅以真实调用首末时间差证明无缓冲。

另进行两轮各两次的短“Reply only OK.”流式调用核对用量，共**10次真实上游请求**，每次上限512，未故意耗尽配额。第一轮上游记录因gzip压缩仅保留了不可解析的采集内容，已删除该无效采集；下游与账本保留为 `real-extra-*.jsonl`，不据此推断上游字段。修正的是教师采集器的解压，不是学生逻辑，第二轮 `real-upstream.jsonl` 仅记录请求正文、URL、状态、解压后的响应正文，完全不记录请求头。

第二轮可交叉核对：Flash实际70/2/72；Pro实际122/15/137，Pro上游明确提供 `output_tokens_details.thinking_tokens=13`，学生账本只有输入/输出/总量，丢失推理分类；这是真实证据。Flash该轮缓存与推理分类均0，非零缓存分类丢失用受控夹具验证，**不冒充真实非零缓存验证**。主验收Pro流式input=1与其他请求不同，不据相邻请求猜测其原始总量；其原始上游未留存，不能据此单独判错。

## A01–A04、F01–F12验证矩阵

| 用例 | 验证方式 | 结果与证据 |
| --- | --- | --- |
| A01 | 实际安装与进程启动 | 部分通过；API可启动且ready，完整make setup在pnpm配置处中止。install.log、make-setup.log、default-start.log。 |
| A02 | DeepSeek官方真实 | 两模型普通、流式、Schema共六次均200；real-results.json含请求标识、用量和延迟。 |
| A03 | 受控请求捕获+真实上游正文 | A实际/v1/chat/completions，messages包含system；B实际/v1/messages，system独立；真实分别对应官方两个路径。不是把对外/v1/responses当作上游Responses协议。 |
| A04 | 受控HTTP | unknown返回404/route_not_found；extra-results.json的A04-clean上游0次。旧controlled-results的A04保留了前次调用列表，不能误读为新增1次。 |
| F01 | 双协议真实+门控HTTP | 双方FIRST在教师释放终态前已到下游；放行后SECOND和正常终态。controlled-results.json中gate-A/B，含单调时钟接收时间。 |
| F02 | 输出后传输断流 | 双方FIRST仅一次，错误事件可见；A特设fallback路由仍只请求第一候选1次，无重复生成；gate_break-A/B。 |
| F03 | 真实+受控 | json_schema双协议成功并本地验证；json_object虽被入口接受但未转为约束，见下一项。 |
| F04 | 受控 | json_object非法、空、截断均200；json_schema相同输入及错误类型均502，未冒充成功；没有修复器，只是失败后切候选。 |
| F05 | 源码+HTTP+模板夹具 | 默认模板的route变量确实进入捕获请求。prompt/prompt_version/variables请求字段被422拒绝；提交没有版本文件/发布引用约定。教师新建v1/v2文件可分别渲染，证明底层加载器能并存命名文件，不计成学生交付了版本发布和旧版引用完整流程。 |
| F06 | 原类+外部模板夹具+HTTP | 无文件/无模板名是明确ConfigError；缺变量为UndefinedError。在仅替换外部模板fixture、不改业务处理的HTTP请求中实得未处理500；template-results.json。 |
| F07 | 账本查询+受控分类+真实分类 | 正常与传输失败有request/attempt/trace，流式无TTFT字段；缓存/推理分类丢失。Schema失败有记录但已知13/7/20消耗变null；入口404/429无记录。最终输入更新17未采纳仍记13，extra-results.json。 |
| F08 | 前两次503、第三次可成功的夹具 | 单候选实际仅1次就502；双候选总2次均503，未等到第3次；无同上游重试和指数等待。 |
| F09 | 持续503与400 | 持续503单候选1、双候选2次后停止；400实际1次且HTTP400统一错误；没有SDK内置重试叠加。 |
| F10 | 配置式降低阈值 | 原限流器limit=2，window=2s；仅调整阈值并清空测试计数，不改算法/key。A1/A2=200、A3=429、B=429，独立性失败。 |
| F11 | 等待真实2.1秒 | 同一key窗口后B=200，恢复通过。 |
| F12 | 原提交测试+故障注入 | 后端17、前端5通过；503注入原后端测试后1 failed/退出1。没有覆盖完整模板版本/首Token计量验收，不能据17 passed宣称全部功能通过。 |

## 扣分问题、源码与最小复现

所有复现均从证据包内 `evidence/README.md` 启动说明进入，不需要改学生业务代码。`probe.py` 批量触发，`controlled-results.json` 以case名称检索。`check_results.py` 是**核对评测发现**的断言，不是声称学生功能全通过；当前执行输出 `Evidence assertions passed`。

### 1. json_object被静默忽略：结构化扣3

- 条件：同一入口，A/B，`response_format={"type":"json_object"}`，受控上游正文依次为not-json、空串、`{"ok":`。
- 预期：不返回成功，明确失败；实际：六种组合全200，choices.message.content原样返回。
- 源码：`api/routes/chat_completions.py:79-85` 只有json_schema映射response_schema；`gateway/service.py:69-74` 只有非空schema才校验；`gateway/adapters/openai.py:111-132` 也没转发json_object。
- 证据：`F03-F04-json_object-invalid/empty/truncated-A/B`；对照json_schema三类均502。

### 2. 意外EOF伪装正常完成：流式扣1

- 条件：发送FIRST后直接干净EOF，不发finish/[DONE]或message_stop。
- 预期：能区分缺失成功终态；实际：两协议下游仍得到finish_reason=stop和[DONE]。
- 源码：OpenAI适配器 `:67-109`、Anthropic适配器 `:70-124` 未在退出时检查终态；`gateway/service.py:194-239` 循环自然结束后直接记成功并发completed。
- 证据：`F01-F02-eof-A/B`。此处不同于普通文本达到长度上限；普通length不另扣分。显式ReadError断流处理则通过。

### 3. 模板版本未交付、缺变量500：模板扣3

- 版本：现有prompts只有default.j2、code_review.j2；`services/prompts.py:19-31` 为名称缓存，无提交的v1/v2及旧版保留约定；`schemas/chat_completions.py:38-53` 不含模板引用或变量入参。HTTP显式版本字段422。未要求必须新增HTTP发布API，也不因使用文件模板扣分；扣的是没有可复现的版本引用交付。扣2。
- 缺变量：`PromptRegistry` 使用StrictUndefined但render异常不转为GatewayError；`gateway/service.py:313-321` 只提供route/endpoint/request_id。外部default模板含missing_variable时，HTTP实际500/Internal Server Error，非明确业务错误。扣1。
- 证据：`template-results.json`、`F05-F06-*`。夹具v1/v2/v1渲染成功明确记为加载器能力对照，不冒充版本功能完成。

### 4. 可观测性不完整：扣7

- 用量扣3：两个适配器只采集input/output/total。受控A提供cached5、reasoning3，B提供cache_read5/cache_creation2，均丢失；真实Pro提供thinking13也丢失。流式B最终input从13更新17，仍记13。源码：`schemas/gateway.py:8-12`；OpenAI适配器 `:145-157`；Anthropic适配器 `:94-119,165-179`。
- 延迟扣2：只记录latency_ms，不记录第一个非空正文或推理增量的时间。门控证明首内容确实先到，但账本不能查询TTFT。源码：`gateway/service.py:173-194`；`services/usage.py`、`schemas/usage.py`、`persistence/migrations/0001_initial.sql`。非流式无TTFT不扣，只扣要求中的流式部分。
- 失败记录扣2：上游传输/503失败已有账本，保留相应分数。A04未知模型、F10本地429查询返回404；Schema失败已收到的13/7/20用量在异常分支未传finish_attempt，变成null。源码：入口路由 `:35`、identity `:38-44` 在usage.begin之前；service `:75-85` 结构校验失败丢失已知result.usage。
- 计量分类是总量子集，未机械相加；未知用量保留null本身不扣，扣的是已经实际提供却丢失。

### 5. 没有同上游指数退避重试：扣5

- 条件：故障夹具首次与第二次503，第三次200；单候选A或双候选fallback。
- 预期：合理有限重试并有指数等待；实际：A仅1次失败，fallback对A/B各1次后失败；两次候选请求间仅为SQLite记账等开销，不存在等待计划。
- 源码：`gateway/service.py:48-106`，retryable仅continue到下一个candidate；无重试循环、sleep或退避函数。依赖没有OpenAI/Anthropic SDK，实际用httpx；默认transport无自动HTTP状态重试，受控实际次数与源码一致。真实记录器明确retries=0只是观察网络，不给学生添加重试。
- 持续503实际1/2次、400实际1次，无超预算或无限循环，故次数上限、不可重试分数保留；不能将“有限fallback”叫作“重试通过”。证据：`F08-F09-*`，时间戳at可相减。

### 6. key共享额度而非模型分桶：扣4

- 条件：limit2/window2s，同一认证身份连续A、A、A、B。
- 预期：200、200、429、200；实际：200、200、429、429。2.1s后B200。
- 源码：`services/identity.py:36-44` 传给consume的只有key_id；`services/rate_limit.py:39-56` 以该key索引窗口。路由model尚未参与计数。
- 证据：`F10-A1/A2/A3/B`、`F11-B-recovered`；只在此项扣独立计数4，不否定原实现确有429和恢复。

### 7. 交付与验证入口：扣4

- 启动扣1：`make setup` 实际失败；项目 `pnpm-workspace.yaml:8-9` 的esbuild构建授权仍为占位文字。补齐布尔授权/与pnpm11一致的配置后应重跑完整setup；这不是因为缺少供应商密钥扣分。
- curl扣2：主README与apps/api/README只有API路径概览，没有作业要求的curl示例；源码中的测试不能替代面向调用方的curl交付。
- 覆盖扣1：原测试有有效普通、流式、Schema及fallback断言，但模板版本和流式TTFT计量未被覆盖。测试明细与原tests源码均可核对。仅指出独立的交付覆盖缺口，不按每个业务bug缺少回归测试叠扣。

## 限制与补交要求

- 本次不是生产压测、浏览器外观评审或其他供应商接入认证；不因这些未验证项扣分。
- 未声明严格拒绝NaN/Infinity，未将其作为扣分门槛；未要求Redis、分布式限流或特定框架；不强制stream与response_format组合。
- 必须修复：json_object校验、无终态结束识别、退避重试、模型分桶、用量/TTFT/失败记录；交付可引用旧版的模板方案和缺项处理。
- 必须补证：原默认模型/候选的实际映射说明，修复后用同样门控和故障夹具复验；补README curl与覆盖六项功能的脚本。若继续用本次官方替代映射，应明确是配置替代，不能把GPT/Claude候选标成已验证。
- 复验条件：两模型各普通/流式/JSON有真实正文；所有成功结构化正文合法；前两次503第三次成功且有退避记录，400仅一次；A超限B仍通且额度恢复；模板v1→v2→v1的实际请求可追踪；账本正确反映有效首Token、分类及失败消耗。
- 归档前核对无.env、真实密钥和捕获的鉴权头，报告格式/分项合计已检查；评测服务全部停止并检查8000、18888、18889无监听。没有提交或推送。
