"""Local template fixtures, unchanged PromptRegistry and HTTP configuration validation."""
import json
import tempfile
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from llm_gateway.main import create_app
from llm_gateway.services.prompts import PromptRegistry
from llm_gateway.core.config import ConfigError

ROOT = Path(__file__).resolve().parent
out = []
with tempfile.TemporaryDirectory() as d:
    p = Path(d)
    (p / "v1.j2").write_text("v1 {{ name }}")
    (p / "v2.j2").write_text("v2 {{ name }}")
    registry = PromptRegistry(p, {"v1", "v2"})
    for version in ["v1", "v2", "v1"]:
        out.append({"version": version, "rendered": registry.render(version, {"name": "小明"})})
    for name, variables in [("absent", {}), ("v1", {})]:
        try:
            registry.render(name, variables)
        except Exception as exc:
            out.append({"template": name, "exception": type(exc).__name__, "message": str(exc)})
    try:
        PromptRegistry(p, {"missing"})
    except ConfigError as exc:
        out.append({"missing_file": str(exc)})
    # Observe whether a missing Jinja variable is translated into an API error.
    (p / "default.j2").write_text("Hello {{ missing_variable }}")
    app = create_app(config_path=ROOT / "controlled.yaml", transport=httpx.MockTransport(lambda r: httpx.Response(500)))
    with TestClient(app, raise_server_exceptions=False) as c:
        app.state.gateway.prompts = PromptRegistry(p, {"default"})
        r = c.post("/v1/chat/completions", headers={"Authorization": "Bearer grading-local", "X-Request-ID": "missing-template-variable"}, json={"model": "A", "messages": [{"role": "user", "content": "hi"}]})
        out.append({"missing_variable_http_status": r.status_code, "body": r.text})
        r = c.get("/api/v1/usage/calls/missing-template-variable", headers={"Authorization": "Bearer grading-local"})
        out.append({"missing_variable_ledger_status": r.status_code})
(ROOT / "template-results.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))
print(json.dumps(out, ensure_ascii=False, indent=2))
