"""Six bounded calls; no fallback, no header capture, only DeepSeek official hosts."""
import asyncio
import json
import time
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parent


async def main():
    records = []
    async with httpx.AsyncClient(base_url="http://127.0.0.1:18889", headers={"Authorization": "Bearer grading-local"}, timeout=90) as c:
        for model in ["real-flash", "real-pro"]:
            for kind in ["ordinary", "stream", "json"]:
                rid = "real-" + model + "-" + kind
                body = {"model": model, "messages": [{"role": "user", "content": 'Return only {"ok":true}. Do not explain.'}], "max_tokens": 512}
                if kind == "json":
                    body["response_format"] = {"type": "json_schema", "json_schema": {"name": "ok", "schema": {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]}}}
                if kind == "stream":
                    body["stream"] = True
                started = time.monotonic()
                try:
                    async with c.stream("POST", "/v1/chat/completions", json=body, headers={"X-Request-ID": rid}) as r:
                        lines = []
                        async for line in r.aiter_lines():
                            if line:
                                lines.append({"seconds": round(time.monotonic() - started, 3), "line": line})
                    out = {"case": rid, "request": body, "status": r.status_code, "seconds": round(time.monotonic() - started, 3), "lines": lines}
                except Exception as e:
                    out = {"case": rid, "error": type(e).__name__, "seconds": round(time.monotonic() - started, 3)}
                detail = await c.get("/api/v1/usage/calls/" + rid)
                out["ledger"] = detail.json()
                records.append(out)
                (ROOT / "real-results.json").write_text(json.dumps(records, ensure_ascii=False, indent=2))
                print(rid, out.get("status"), out["seconds"], flush=True)


asyncio.run(main())
