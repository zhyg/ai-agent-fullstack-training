"""Two additional bounded streams to compare upstream usage to persisted usage."""
import json
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parent
with httpx.Client(base_url="http://127.0.0.1:18889", headers={"Authorization": "Bearer grading-local"}, timeout=85) as c:
    for alias in ["real-flash", "real-pro"]:
        rid = "raw2-" + alias + "-stream"
        r = c.post("/v1/chat/completions", json={"model": alias, "messages": [{"role": "user", "content": "Reply only OK."}], "max_tokens": 512, "stream": True}, headers={"X-Request-ID": rid})
        out = {"id": rid, "status": r.status_code, "body": r.text}
        with (ROOT / "real-raw-downstream.jsonl").open("a") as f:
            f.write(json.dumps(out) + "\n")
        detail = c.get("/api/v1/usage/calls/" + rid)
        with (ROOT / "real-raw-ledger.jsonl").open("a") as f:
            f.write(json.dumps(detail.json()) + "\n")
        print(alias, r.status_code)
