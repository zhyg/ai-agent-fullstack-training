"""Observing transport; does not change requests, responses or student business logic."""
import json
from pathlib import Path
import httpx
from llm_gateway.main import create_app

ROOT = Path(__file__).resolve().parent


class Tee(httpx.AsyncByteStream):
    def __init__(self, inner, record):
        self.inner, self.record, self.parts = inner, record, []

    async def __aiter__(self):
        async for part in self.inner:
            self.parts.append(part)
            yield part

    async def aclose(self):
        await self.inner.aclose()
        self.record["response_body"] = httpx.Response(
            200, headers={"content-encoding": self.record["encoding"]},
            content=b"".join(self.parts),
        ).text
        with (ROOT / "real-upstream.jsonl").open("a") as f:
            f.write(json.dumps(self.record, ensure_ascii=False) + "\n")


class Recording(httpx.AsyncBaseTransport):
    def __init__(self):
        self.inner = httpx.AsyncHTTPTransport(retries=0)

    async def handle_async_request(self, request):
        assert request.url.host == "api.deepseek.com"
        record = {"url": str(request.url), "request_body": json.loads(request.content)}
        response = await self.inner.handle_async_request(request)
        record["status"] = response.status_code
        record["encoding"] = response.headers.get("content-encoding", "identity")
        response.stream = Tee(response.stream, record)
        return response

    async def aclose(self):
        await self.inner.aclose()


app = create_app(config_path=ROOT / "real.yaml", transport=Recording())
