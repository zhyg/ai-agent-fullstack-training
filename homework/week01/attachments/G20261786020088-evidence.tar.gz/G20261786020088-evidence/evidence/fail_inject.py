"""Only corrupt the submitted test's simulated upstream, not student production code."""
import httpx
import pytest


@pytest.fixture(autouse=True)
def injected_failure(monkeypatch):
    async def failed(self, request):
        return httpx.Response(503, json={"error": {"message": "teacher injected failure"}})
    monkeypatch.setattr(httpx.MockTransport, "handle_async_request", failed)
