"""Teacher-controlled transport only; student source is unchanged. Never contacts Internet."""
import asyncio
import json
import time
from pathlib import Path

import httpx
from fastapi import Request
from llm_gateway.main import create_app

ROOT = Path(__file__).resolve().parent
state = {"mode": "normal", "calls": []}
gate = asyncio.Event()


def sse(obj):
    return ("data: " + json.dumps(obj) + "\n\n").encode()


class Stream(httpx.AsyncByteStream):
    def __init__(self, anthropic):
        self.anthropic = anthropic

    async def __aiter__(self):
        if self.anthropic:
            yield sse({"type": "message_start", "message": {"usage": {"input_tokens": 13}}})
            yield sse({"type": "content_block_delta", "delta": {"type": "text_delta", "text": "FIRST"}})
        else:
            yield sse({"choices": [{"delta": {"content": "FIRST"}}]})
        if state["mode"].startswith("gate"):
            await asyncio.wait_for(gate.wait(), 15)
        if state["mode"] == "gate_break":
            raise httpx.ReadError("controlled disconnection after visible token")
        if state["mode"] == "eof":
            return
        if self.anthropic:
            yield sse({"type": "content_block_delta", "delta": {"type": "text_delta", "text": "SECOND"}})
            yield sse({"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"input_tokens": 17 if state["mode"] == "usage_update" else 13, "output_tokens": 7, "cache_read_input_tokens": 5, "output_tokens_details": {"thinking_tokens": 3}}})
            yield sse({"type": "message_stop"})
        else:
            yield sse({"choices": [{"delta": {"content": "SECOND"}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 13, "completion_tokens": 7, "total_tokens": 20, "prompt_tokens_details": {"cached_tokens": 5}, "completion_tokens_details": {"reasoning_tokens": 3}, "prompt_cache_hit_tokens": 5}})
            yield b"data: [DONE]\n\n"


async def handler(request):
    body = json.loads(request.content)
    state["calls"].append({"path": request.url.path, "body": body, "at": time.monotonic()})
    mode = state["mode"]
    n = len(state["calls"])
    status = 503 if mode == "fail503" or (mode == "failtwice" and n <= 2) else 400 if mode == "fail400" else 200
    if status != 200:
        return httpx.Response(status, json={"error": {"message": "controlled failure", "code": "controlled", "type": "controlled"}})
    anthropic = request.url.path.endswith("/messages")
    if body.get("stream"):
        return httpx.Response(200, stream=Stream(anthropic), headers={"Content-Type": "text/event-stream"})
    text = {"invalid": "not-json", "empty": "", "truncated": '{"ok":', "shape": '{"ok":"wrong"}'}.get(mode, '{"ok":true}')
    if anthropic:
        return httpx.Response(200, json={"content": [{"type": "text", "text": text}], "stop_reason": "max_tokens" if mode == "truncated" else "end_turn", "usage": {"input_tokens": 13, "output_tokens": 7, "cache_read_input_tokens": 5, "cache_creation_input_tokens": 2}})
    return httpx.Response(200, json={"choices": [{"message": {"content": text}, "finish_reason": "length" if mode == "truncated" else "stop"}], "usage": {"prompt_tokens": 13, "completion_tokens": 7, "total_tokens": 20, "prompt_tokens_details": {"cached_tokens": 5}, "completion_tokens_details": {"reasoning_tokens": 3}, "prompt_cache_hit_tokens": 5}})


app = create_app(config_path=ROOT / "controlled.yaml", transport=httpx.MockTransport(handler))


@app.post("/__control")
async def control(request: Request):
    body = await request.json()
    if body.get("release"):
        gate.set()
    else:
        state["mode"] = body["mode"]
        state["calls"] = []
        gate.clear()
    return {"mode": state["mode"]}


@app.get("/__calls")
async def calls():
    return state


@app.post("/__limit")
async def limit(request: Request):
    body = await request.json()
    limiter = app.state.identity._limiter
    limiter.limit = body["limit"]
    limiter._windows.clear()
    return {"limit": limiter.limit}
