import json
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parent
out = []
with httpx.Client(base_url="http://127.0.0.1:18888", headers={"Authorization": "Bearer grading-local"}, timeout=20) as c:
    c.post("/__control", json={"mode": "normal"})
    r = c.post("/v1/chat/completions", json={"model": "missing", "messages": [{"role": "user", "content": "hi"}]})
    out.append({"case": "A04-clean", "status": r.status_code, "response": r.json(), "calls": c.get("/__calls").json()["calls"]})
    for model in ["A", "B"]:
        c.post("/__control", json={"mode": "normal"})
        r = c.post("/v1/responses", json={"model": model, "input": "hi"})
        out.append({"case": "responses-ingress-" + model, "status": r.status_code, "response": r.json(), "calls": c.get("/__calls").json()["calls"]})
    c.post("/__control", json={"mode": "usage_update"})
    r = c.post("/v1/chat/completions", headers={"X-Request-ID": "usage-update-B"}, json={"model": "B", "messages": [{"role": "user", "content": "hi"}], "stream": True})
    d = c.get("/api/v1/usage/calls/usage-update-B").json()
    out.append({"case": "F07-final-usage-update", "expected_input_tokens": 17, "initial_input_tokens": 13, "actual_ledger": d, "response": r.text})
(ROOT / "extra-results.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))
for x in out:
    print(x["case"], x.get("status"), x.get("actual_ledger", {}).get("input_tokens"))
