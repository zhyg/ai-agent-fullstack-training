"""Assert evidence matches findings, not that all student functionality passes."""
import json
from pathlib import Path

P = Path(__file__).resolve().parent
r = {x["case"]: x for x in json.loads((P / "controlled-results.json").read_text())}
for m in ["A", "B"]:
    assert r["A02-A03-" + m]["status"] == 200
    for scenario in ["gate", "gate_break"]:
        x = r[f"F01-F02-{scenario}-{m}"]
        assert x["first_before_release"] and len(x["upstream"]) == 1
        text = "\n".join(e["line"] for e in x["events"])
        assert text.count('"content":"FIRST"') == 1
        assert ('"error"' in text) == (scenario == "gate_break")
    for mode in ["invalid", "empty", "truncated"]:
        assert r[f"F03-F04-json_object-{mode}-{m}"]["status"] == 200
        assert r[f"F03-F04-json_schema-{mode}-{m}"]["status"] == 502
    assert '"finish_reason":"stop"' in str(r[f"F01-F02-eof-{m}"]["events"])
assert [r[k]["status"] for k in ["F10-A1", "F10-A2", "F10-A3", "F10-B", "F11-B-recovered"]] == [200, 200, 429, 429, 200]
assert len(r["F08-F09-failtwice-A"]["upstream"]) == 1
assert len(r["F08-F09-failtwice-fallback"]["upstream"]) == 2
assert len(r["F08-F09-fail400-fallback"]["upstream"]) == 1
for x in json.loads((P / "real-results.json").read_text()):
    assert x["status"] == 200 and x["ledger"]["status"] == "success"
    if x["case"].endswith("json"):
        body = json.loads(x["lines"][0]["line"])
        assert json.loads(body["choices"][0]["message"]["content"]) == {"ok": True}
    if x["case"].endswith("stream"):
        assert any('"content"' in l["line"] for l in x["lines"])
        assert x["lines"][-1]["line"] == "data: [DONE]"
e = json.loads((P / "extra-results.json").read_text())
assert e[0]["status"] == 404 and e[0]["calls"] == []
assert e[-1]["actual_ledger"]["input_tokens"] == 13 != e[-1]["expected_input_tokens"]
print("Evidence assertions passed: real dual-model six calls, controlled defects, gated SSE, retry counts, rate recovery")
