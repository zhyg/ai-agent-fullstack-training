"""Run against controlled_app on real HTTP sockets. Records bodies, never headers."""
import asyncio
import json
import time
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parent
records = []
SCHEMA = {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]}


async def main():
    async with httpx.AsyncClient(base_url="http://127.0.0.1:18888", headers={"Authorization": "Bearer grading-local"}, timeout=25) as c:
        async def mode(m):
            await c.post("/__control", json={"mode": m})

        async def call(label, model="A", extra=None):
            body = {"model": model, "messages": [{"role": "user", "content": "Return JSON {\"ok\":true}"}], **(extra or {})}
            r = await c.post("/v1/chat/completions", json=body, headers={"X-Request-ID": label})
            out = {"case": label, "status": r.status_code, "response": r.json() if "json" in r.headers.get("content-type", "") else r.text, "upstream": (await c.get("/__calls")).json()["calls"]}
            records.append(out)
            return out

        for model in ["A", "B"]:
            await mode("normal")
            await call("A02-A03-" + model, model)
        await call("A04-unknown", "missing")
        for fmt in ["json_object", "json_schema"]:
            for m in ["normal", "invalid", "empty", "truncated", "shape"]:
                for model in ["A", "B"]:
                    await mode(m)
                    f = {"type": fmt}
                    if fmt == "json_schema":
                        f["json_schema"] = {"name": "ok", "schema": SCHEMA}
                    await call(f"F03-F04-{fmt}-{m}-{model}", model, {"response_format": f})
        for model in ["A", "B"]:
            for scenario in ["gate", "gate_break", "eof"]:
                await mode(scenario)
                got_before_release = False
                received = []
                started = time.monotonic()
                async with c.stream("POST", "/v1/chat/completions", json={"model": "fallback" if model == "A" else "B", "messages": [{"role": "user", "content": "hello"}], "stream": True}, headers={"X-Request-ID": f"F01-F02-{scenario}-{model}"}) as r:
                    async for line in r.aiter_lines():
                        if line:
                            received.append({"line": line, "seconds": round(time.monotonic() - started, 3)})
                        if '"content":"FIRST"' in line:
                            got_before_release = True
                            await asyncio.sleep(.12)
                            await c.post("/__control", json={"release": True})
                records.append({"case": f"F01-F02-{scenario}-{model}", "status": r.status_code, "first_before_release": got_before_release, "events": received, "upstream": (await c.get("/__calls")).json()["calls"]})
        for m in ["failtwice", "fail503", "fail400"]:
            for model in ["A", "fallback"]:
                await mode(m)
                await call(f"F08-F09-{m}-{model}", model)
        for field, value in [("prompt", {"name": "default", "version": "v1", "variables": {"name": "x"}}), ("prompt_version", "v1"), ("variables", {})]:
            await mode("normal")
            await call("F05-F06-" + field, extra={field: value})
        # Lower threshold in the existing limiter, not its algorithm or keying.
        await c.post("/__limit", json={"limit": 2})
        await mode("normal")
        await call("F10-A1")
        await call("F10-A2")
        await call("F10-A3")
        await call("F10-B", "B")
        await asyncio.sleep(2.1)
        await call("F11-B-recovered", "B")
        await c.post("/__limit", json={"limit": 1000})
        detail = await c.get("/api/v1/usage/calls", params={"limit": 100})
        records.append({"case": "F07-ledger", "response": detail.json()})
        for req in ["A02-A03-A", "A02-A03-B", "F01-F02-gate-A", "F01-F02-gate_break-A", "F03-F04-json_schema-invalid-A", "F10-A3", "F10-B", "A04-unknown"]:
            r = await c.get("/api/v1/usage/calls/" + req)
            records.append({"case": "F07-detail-" + req, "status": r.status_code, "response": r.json()})
    (ROOT / "controlled-results.json").write_text(json.dumps(records, ensure_ascii=False, indent=2))
    for x in records:
        print(x["case"], x.get("status"), "calls=" + str(len(x["upstream"])) if "upstream" in x else "")


asyncio.run(main())
