# G20261786020088 第一次提交评测证据

固定学生仓库 https://github.com/BboyXing/AI-Agent main：4b094287a87300fbd9718a4aea75f5b590887733。
子目录 `01 LLM Gateway/llm_gateway`。未改业务源码，不包含.env，不包含真实密钥或捕获的鉴权头。
配置中的grading-local/dummy只是教师本地公开夹具，不是供应商凭据。脚本中构造本地认证字段只用于重跑，未采集该头到日志。

## 安装与路径

在课程仓库执行clone、checkout固定提交；本次路径为：
`.amp/in/orb-backup/grading88/student/01 LLM Gateway/llm_gateway`。
Python3.13.5，uv0.13.0，按学生README建立.tooling后执行：
`make setup`（完整输出make-setup.log；pnpm esbuild授权阻断），Python部分另有install.log。
`cd apps/api && ../../.tooling/bin/uv run pytest`：17 passed。
`node apps/web/node_modules/vitest/vitest.mjs run --root apps/web`：5 passed（从项目根执行）。

## 重跑受控验收

1. 使用已安装的apps/api/.venv/bin/python；设置PYTHONPATH包括学生apps/api/src和本证据目录。
2. 如更换目录，修改controlled.yaml/real.yaml的database_path为外部临时文件；删除旧测试数据库，以免相同X-Request-ID主键冲突。不要改学生业务源码。
3. 执行 `python -m uvicorn controlled_app:app --host 127.0.0.1 --port 18888`。本次通过amp orb service start监督启动。
4. 执行 `python probe.py`，然后 `python extra_probe.py`；保存controlled-results.json、extra-results.json。控制端仅教师本地服务使用，禁止生产暴露。
5. 执行 `python supplement.py`，用外部模板目录替换PromptRegistry依赖，验证命名模板与缺变量；不修改学生模板文件。
6. `python check_results.py`验证证据和已发现缺陷一致。这不是把缺陷计为功能通过。

上游使用学生支持的httpx.MockTransport注入点，绝不访问controlled.invalid或任何真实供应商；网关与教师客户端之间是真正HTTP socket，门控FIRST到达后由客户端释放终态，可排除缓冲假通过。
`__limit`只降低原限流器阈值并重置测试状态，不改keying/算法；2秒固定窗口用真实等待2.1秒验证恢复。

## 原测试故障注入

在apps/api目录运行：
`PYTHONPATH=<本证据目录> ../../.tooling/bin/uv run pytest -p fail_inject tests/integration/test_api.py::test_chat_completion_and_usage_are_persisted`
插件仅将原测试用MockTransport的上游改为503。预期原用例失败退出1，不修改学生生产代码。

## 官方真实调用（需要经授权的DEEPSEEK_API_KEY环境secret）

仅real.yaml中的api.deepseek.com官方域名。不要使用其他供应商key，不把key填进文件。
启动原 `llm_gateway.main:app`，环境GATEWAY_CONFIG_FILE指向real.yaml，监听18889；运行real_probe.py，六次短prompt，每次max_tokens512，无fallback。
如需核对原始上游，用相同端口改为启动 `real_record_app:app`，运行raw_probe.py（额外两次有界流式）。记录器只观察URL、正文、状态，自动解压gzip，不保存请求头；代码显式禁止其他主机。
本次为核对采集解压先额外跑过两次，10次真实请求总计的记录边界见完整附件。第一轮无效压缩采集已删除，不作为证据。
real-results.json保存六次主请求正文、下游响应、请求标识和账本；real-upstream.jsonl是第二轮两次有效原始响应。real-extra-*是前一轮额外两次的下游/账本；real-raw-*是有效采集那轮下游/账本。

## 结果文件

- controlled-results.json：A/F主验收；probe.log为简表。
- extra-results.json：干净unknown模型、对外Responses入口、Messages最终输入快照变化。
- template-results.json：命名文件对照、缺模板、缺变量500。
- student-tests.log / student-web-direct.log：原测试实跑。
- student-injected-failure.log：实际失败输出；student-web-tests.log为pnpm阻断的原命令。
- real-probe.log / raw-probe.log：真实调用状态与时延摘要。
- evidence-check.log：评测结果一致性断言。
- source-evidence.txt（包根）：固定提交带行号关键源码，不含鉴权头实现段。
- lifecycle.log / audit.json / manifest.sha256（包根）：停止监听、安全/格式检查、文件摘要。

评分不是测试通过率换算；真实、受控、未验证边界须按完整附件解释。
