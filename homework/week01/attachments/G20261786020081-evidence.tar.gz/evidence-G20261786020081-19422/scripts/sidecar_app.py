"""Start the student app with deepseek pointed at a local mock. Not student code."""
import os
import sys

os.environ.setdefault("MINI_MAX_API_KEY", "local-mock-key")
# DEEPSEEK_API_KEY already in env; we will not print it.

MOCK = os.environ["MOCK_BASE_URL"]
import app.config.settings as settings
from dataclasses import replace

cfg = settings.MODEL_CONFIGS["deepseek"]
settings.MODEL_CONFIGS["deepseek"] = replace(cfg, base_url=MOCK, provider_model="mock-model", fallback_model=None)
# drop cached adapters if any
from app.adapters.llm import get_adapter
get_adapter.cache_clear()

import uvicorn
from main import app

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=int(os.environ.get("SIDECAR_PORT", "8011")), log_level="warning")
