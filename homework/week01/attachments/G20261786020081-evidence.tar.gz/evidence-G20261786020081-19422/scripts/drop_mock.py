import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
MODE = {"name": sys.argv[1] if len(sys.argv) > 1 else "drop"}
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a):
        return
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        self.rfile.read(n)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        mode = MODE["name"]
        if mode == "drop":
            self.wfile.write(b'data: {"choices":[{"delta":{"content":"HELLO"},"finish_reason":null}]}\n\n')
            self.wfile.flush()
            return
        if mode == "error_event":
            self.wfile.write(b'data: {"choices":[{"delta":{"content":"PARTIAL"},"finish_reason":null}]}\n\n')
            self.wfile.write(b'data: {"error":{"message":"upstream broke","type":"server_error"}}\n\n')
            self.wfile.flush()
            return
srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
print("mock_port", srv.server_address[1], flush=True)
srv.serve_forever()
