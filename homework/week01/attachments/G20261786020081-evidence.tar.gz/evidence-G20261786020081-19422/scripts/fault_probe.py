"""Fault-injecting mock. Counts requests. Modes via path query is not available; mode via header X-Mode set by... 
Student client does not send X-Mode. Mode is global, switched by GET /mode?name=.
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

STATE = {"mode": "ok", "counts": {}}
LOCK = threading.Lock()

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, fmt, *args):
        return
    def _read(self):
        n = int(self.headers.get("Content-Length", "0"))
        return self.rfile.read(n).decode() if n else ""
    def _json(self, code, obj, headers=None):
        raw = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(raw)
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/mode":
            name = parse_qs(parsed.query).get("name", ["ok"])[0]
            with LOCK:
                STATE["mode"] = name
                STATE["counts"] = {}
            self._json(200, {"mode": name})
            return
        if parsed.path == "/counts":
            with LOCK:
                self._json(200, {"mode": STATE["mode"], "counts": STATE["counts"]})
            return
        self._json(404, {})
    def do_POST(self):
        body = self._read()
        with LOCK:
            mode = STATE["mode"]
            STATE["counts"][self.path] = STATE["counts"].get(self.path, 0) + 1
            n = STATE["counts"][self.path]
        if mode == "fail2":
            if n <= 2:
                self._json(503, {"error": {"message": "temporary", "type": "server_error"}})
                return
        elif mode == "always500":
            self._json(500, {"error": {"message": "down", "type": "server_error"}})
            return
        elif mode == "status400":
            self._json(400, {"error": {"message": "bad request", "type": "invalid_request_error"}})
            return
        elif mode == "status401":
            self._json(401, {"error": {"message": "unauthorized", "type": "authentication_error"}})
            return
        elif mode == "status429":
            self._json(429, {"error": {"message": "rate", "type": "rate_limit"}}, {"retry-after": "1"})
            return
        # success
        if '"stream":true' in body.replace(" ", "") or '"stream": true' in body:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            self.wfile.write(b'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":null}]}\n\n')
            self.wfile.write(b'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}\n\n')
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
            return
        self._json(200, {
            "choices": [{"message": {"role": "assistant", "content": "{\"ok\": true}"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 2, "completion_tokens": 2, "total_tokens": 4},
        })

def main():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    print("mock_port", server.server_address[1], flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()
