"""Local mock upstream with a release endpoint. Not student code."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

RELEASE = threading.Event()
SEEN = []
LOCK = threading.Lock()

def sse_openai(payload: dict) -> bytes:
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n".encode()

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        return

    def _read(self) -> str:
        n = int(self.headers.get("Content-Length", "0"))
        return self.rfile.read(n).decode() if n else ""

    def do_POST(self):
        body = self._read()
        auth = self.headers.get("Authorization") or ""
        xkey = self.headers.get("x-api-key") or ""
        with LOCK:
            SEEN.append({
                "path": self.path,
                "has_bearer": auth.startswith("Bearer "),
                "has_x_api_key": bool(xkey),
                "anthropic_version": self.headers.get("anthropic-version"),
                "body": body[:700],
            })
        compact = body.replace(" ", "")
        if self.path in ("/release",):
            RELEASE.set()
            self._json(200, {"released": True, "seen": len(SEEN)})
            return
        if self.path.endswith("/chat/completions") and '"stream":true' in compact:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(sse_openai({
                "choices": [{"index": 0, "delta": {"content": "FIRST"}, "finish_reason": None}]
            }))
            self.wfile.flush()
            RELEASE.wait(12)
            self.wfile.write(sse_openai({
                "choices": [{"index": 0, "delta": {"content": "-SECOND"}, "finish_reason": None}]
            }))
            self.wfile.write(sse_openai({
                "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6,
                          "prompt_tokens_details": {"cached_tokens": 1},
                          "completion_tokens_details": {"reasoning_tokens": 0}},
            }))
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
            return
        if self.path.endswith("/chat/completions"):
            # non-stream: return illegal JSON body so gateway validation can be checked
            text = "not-json {{{"
            if "INVALID_EMPTY" in body:
                text = ""
            if "FENCE" in body:
                text = "```json\n{\"ok\": true}\n```"
            if "TRUNC" in body:
                text = "{\"ok\": "
            self._json(200, {
                "choices": [{"message": {"role": "assistant", "content": text}, "finish_reason": "length" if "TRUNC" in body else "stop"}],
                "usage": {"prompt_tokens": 2, "completion_tokens": 1, "total_tokens": 3},
            })
            return
        if self.path.endswith("/v1/messages") and '"stream":true' in compact:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            self.wfile.write(b"event: message_start\ndata: {\"type\":\"message_start\",\"message\":{\"usage\":{\"input_tokens\":3}}}\n\n")
            self.wfile.write(b"event: content_block_delta\ndata: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"A\"}}\n\n")
            self.wfile.flush()
            RELEASE.wait(12)
            self.wfile.write(b"event: content_block_delta\ndata: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"B\"}}\n\n")
            self.wfile.write(b"event: message_delta\ndata: {\"type\":\"message_delta\",\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":2}}\n\n")
            self.wfile.flush()
            return
        self._json(404, {"error": "no route", "path": self.path})

    def do_GET(self):
        if self.path == "/seen":
            with LOCK:
                self._json(200, {"seen": SEEN})
            return
        if self.path == "/release":
            RELEASE.set()
            self._json(200, {"released": True})
            return
        self._json(404, {"error": "no"})

    def _json(self, code, obj):
        raw = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

def main():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    print("mock_port", server.server_address[1], flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()
