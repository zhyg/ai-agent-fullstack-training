"""Validate requested deliverables and build a credential-free, reproducible evidence archive."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parents[3]
out = repo / ".amp/in/week-grading"
prefix = "G19701786020231-19553"
feedback = out / f"{prefix}-feedback.md"
evaluation = out / f"{prefix}-evaluation.md"
fb = feedback.read_text()
ev = evaluation.read_text()
sections = re.split(r"\*\*[234]\. [^\n]+\*\*", fb)[1:]
feedback_checks = []
for section in sections:
    items = re.findall(r"^- .+$", section, re.M)
    assert 3 <= len(items) <= 5
    assert len(section.strip()) <= 500
    assert not any(w in section for w in ("扣分", "评分标准", "判分", "评分项"))
    feedback_checks.append({"items": len(items), "characters_including_markdown": len(section.strip())})
assert len(feedback_checks) == 3
scores = [int(x) for x in re.findall(r"^\| (?:统一接口与适配器|流式输出|结构化输出|提示词版本管理|可观测性|统一错误与重试|按模型独立限流|源码、README 与验证脚本) \| (\d+)/", ev, re.M)]
assert scores == [15, 15, 10, 10, 13, 12, 10, 9]
assert sum(scores) == 94 and "优秀（94分）" in fb
results = json.loads((root / "supplement-results.json").read_text())
assert len(results) == 37
assert sum(r["status"] == "PASS" for r in results) == 30
assert "21 passed" in (root / "pytest.log").read_text()
real = json.loads((root / "source/evidence/verification-20261127-065606.json").read_text())
assert real["summary"] == {"passed": 15, "failed": 0, "total": 15}

stage = root / "evidence-package"
stage.mkdir(exist_ok=True)
with tarfile.open(root / "source-original.tar") as archive:
    archive.extractall(stage / "source", filter="data")
integrity = []
for rel in subprocess.check_output(["git", "-C", str(root / "source"), "ls-files", "app", "tests", "scripts"], text=True).splitlines():
    original = subprocess.check_output(["git", "-C", str(root / "source"), "show", "HEAD:" + rel])
    current = (root / "source" / rel).read_bytes()
    snapshot = (stage / "source" / rel).read_bytes()
    assert original == current == snapshot, rel
    integrity.append({"path": rel, "sha256": hashlib.sha256(original).hexdigest(), "matches_git_commit": True})
(stage / "integrity.json").write_text(json.dumps(integrity, indent=2))
(stage / "logs").mkdir(exist_ok=True)
for name in ["install.log", "install-dev.log", "pytest-readme.log", "pytest.log", "environment.log", "dependencies.txt", "verify.log", "verify-exit.log", "supplement.log", "supplement-exit.log", "supplement-gateway.log", "failure-injection.log"]:
    shutil.copy2(root / name, stage / "logs" / name)
for name in ["supplement.py", "supplement-results.json", "package_evidence.py"]:
    shutil.copy2(root / name, stage / name)
(stage / "real-run").mkdir(exist_ok=True)
for name in ["verification-20261127-065606.json", "verification-20261127-065606.md"]:
    shutil.copy2(root / "source/evidence" / name, stage / "real-run" / name)
shutil.copytree(root / "source/evidence/logs", stage / "real-run/logs", dirs_exist_ok=True)
(stage / "course").mkdir(exist_ok=True)
for relative in ["hw-guide/week01/第一周作业.md", "hw-guide/week01/第一周作业评分标准.md", "hw-guide/学员作业反馈报告模板与要求.md"]:
    shutil.copy2(repo / relative, stage / "course" / Path(relative).name)
shutil.copy2(feedback, stage / "feedback.md")
shutil.copy2(evaluation, stage / "evaluation.md")
metadata = {
    "student": "陵宴", "student_id": "G19701786020231", "submission_id": "19553",
    "repository": "https://github.com/Ninshar/llm-protocol-gateway", "branch": "main",
    "student_commit": subprocess.check_output(["git", "-C", str(root / "source"), "rev-parse", "HEAD"], text=True).strip(),
    "course_branch": "feat/guide", "course_commit": subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip(),
    "grade": "优秀", "score": sum(scores), "scores": scores, "acceptance": "通过，需修复", "provisional": False,
    "original_unit_tests": {"passed": 21, "exit_code": 0, "readme_only_install_exit_code": 1},
    "original_verification": {"passed": 15, "total": 15, "exit_code": 0, "uses_real_deepseek": True},
    "supplement": {"probes": 37, "pass": 30, "confirmed_defect_probes": 7, "exit_code": 0},
    "business_and_original_tests_unchanged": True,
    "feedback_checks": feedback_checks,
    "environment": (root / "environment.log").read_text(),
}
assert metadata["student_commit"] == "d12350e58661103adf68f72a7a629bdc2d51b31f"
assert metadata["course_commit"] == "cd7c2e08510aac4ab56b4d4ef2ffc1eb33b22893"
(stage / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False))
secrets = [os.environ[n].encode() for n in ("DEEPSEEK_API_KEY", "GEEKBANG_COOKIE") if len(os.environ.get(n, "")) >= 12]
hashes = []
for p in sorted(stage.rglob("*")):
    if not p.is_file() or p.name == "SHA256SUMS":
        continue
    assert not any(part in (".git", "venv", ".venv", "node_modules", "__pycache__") for part in p.relative_to(stage).parts)
    assert p.name != ".env"
    data = p.read_bytes()
    assert not any(secret in data for secret in secrets), "credential leak in " + str(p.relative_to(stage))
    hashes.append(hashlib.sha256(data).hexdigest() + "  " + str(p.relative_to(stage)))
(stage / "SHA256SUMS").write_text("\n".join(hashes) + "\n")
target = out / f"{prefix}-evidence.tar.gz"
with tarfile.open(target, "w:gz") as archive:
    for path in sorted(stage.iterdir()):
        archive.add(path, arcname=path.name)
with tarfile.open(target) as archive:
    for line in hashes:
        expected, name = line.split("  ", 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
    assert archive.extractfile("feedback.md").read() == feedback.read_bytes()
    assert archive.extractfile("evaluation.md").read() == evaluation.read_bytes()
print(json.dumps({"score": sum(scores), "feedback_sections": feedback_checks, "unchanged_source_files": len(integrity), "archive_files": len(hashes) + 1, "secret_scan": "clean", "archive_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "archive_bytes": target.stat().st_size}, ensure_ascii=False))
