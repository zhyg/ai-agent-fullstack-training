# LLM Protocol Gateway

统一封装 **OpenAI Responses API** 与 **Anthropic Messages API** 的模型调用网关。

> GitHub: <https://github.com/Ninshar/llm-protocol-gateway>

| 网关模型 | 上游模型 | 协议 | 上游路径 |
| --- | --- | --- | --- |
| `deepseek-v4-pro` | `deepseek-v4-pro` | **OpenAI Responses API** | `POST https://api.deepseek.com/responses` |
| `deepseek-flash` | `deepseek-flash` | **Anthropic Messages API** | `POST https://api.deepseek.com/anthropic/v1/messages` |

请求只面向统一的 `POST /v1/chat`，由请求体里的 `model` 字段动态选择适配器。鉴权方式、请求体结构、返回结构、SSE 事件类型、Usage 字段的差异全部被适配器层屏蔽。

> 本仓库已用真实 DeepSeek API 完成验收：**15/15 检查通过**，见 [验证明细](evidence/latest.md) 与 [原始证据 JSON](evidence/latest.json)。

---

## 1. 功能总览

| 能力 | 实现 |
| --- | --- |
| 统一抽象层 / 动态路由 | `BaseAdapter` + `OpenAIResponsesAdapter` + `AnthropicMessagesAdapter`，按 `model` 路由 |
| 流式输出 | `stream=true`，统一 SSE：`meta` / `delta` / `reasoning` / `done` / `error` |
| 结构化输出 | `response_format` 支持 `text` / `json_object` / `json_schema`，服务端 JSON Schema 二次校验 |
| 提示词版本管理 | SQLite 存储，版本不可变、`latest`/固定版本引用、Jinja2 变量替换、渲染预览 |
| 可观测性 | 每次调用的输入/输出/缓存/推理/可见 Token 分类，总延迟、首 Token 延迟、重试轨迹 |
| 韧性 | 统一错误码、指数退避重试（总尝试 ≤3）、按模型独立令牌桶限流（超限 429） |

---

## 2. 架构

```mermaid
flowchart LR
    C[Client / curl] -->|POST /v1/chat| API[FastAPI]
    API --> T[TemplateStore<br/>SQLite]
    API --> RL[Per-model<br/>Token Bucket]
    API --> R[Model Router]
    R -->|model=deepseek-v4-pro| A1[OpenAI Responses<br/>Adapter]
    R -->|model=deepseek-flash| A2[Anthropic Messages<br/>Adapter]
    A1 -->|Authorization: Bearer| U1[DeepSeek /responses]
    A2 -->|x-api-key + anthropic-version| U2[DeepSeek /anthropic/v1/messages]
    API --> RETRY[Exponential Backoff]
    API --> OBS[Observability<br/>SQLite + JSONL]
```

一次调用的处理顺序：

```
请求校验 -> 解析 model -> 渲染模板 -> 模型级限流 -> 适配器组装请求
        -> [指数退避重试] -> 上游调用 -> 统一 Usage / 错误码 -> 观测落库
        -> JSON 响应 或 SSE 事件流
```

### 目录结构

```
llm-protocol-gateway/
├── app/
│   ├── main.py                  # FastAPI 路由 / 中间件 / 错误处理
│   ├── service.py               # 编排：模板、限流、重试、SSE、观测
│   ├── config.py                # YAML + ${ENV} + 启动期校验
│   ├── schemas.py               # 请求模型 / 统一 Usage
│   ├── errors.py                # 统一错误码与错误信封
│   ├── retry.py                 # 指数退避
│   ├── ratelimit.py             # 每模型独立令牌桶
│   ├── templates.py             # 模板版本与 Jinja2 渲染
│   ├── observability.py         # 调用明细与聚合
│   ├── logging_setup.py         # JSONL 日志
│   └── adapters/
│       ├── base.py              # 统一接口、SSE 解析、Usage 归一
│       ├── openai_responses.py
│       └── anthropic_messages.py
├── mock/upstream.py             # 协议级 mock 上游（仅验证重试/限流）
├── scripts/verify.py            # 端到端验收脚本
├── tests/                       # 离线单元测试
├── config.yaml                  # 生产配置
├── config.test.yaml             # 验收配置（含 mock 探针模型）
├── evidence/                    # 自动生成的验收证据
├── run.ps1 / run.sh
├── requirements.txt
└── .env.example
```

---

## 3. 快速开始

环境：Python 3.11+（实测 3.12.8），Windows / macOS / Linux 均可。下面以 Windows 的 `py` 启动器为例；Linux/macOS 把 `py` 换成 `python3` 即可。

```bash
cd llm-protocol-gateway

# 1) 安装依赖
py -m pip install -r requirements.txt

# 2) 配置 Key（.env 已被 .gitignore 忽略）
cp .env.example .env            # PowerShell: Copy-Item .env.example .env
# 编辑 .env，填入 DEEPSEEK_API_KEY=sk-...

# 3) 启动
py -m uvicorn app.main:app --host 127.0.0.1 --port 8000
# 或 Windows: powershell -ExecutionPolicy Bypass -File .\run.ps1
# 或 Linux/macOS: bash run.sh

# 4) 检查
curl -s http://127.0.0.1:8000/healthz
curl -s http://127.0.0.1:8000/v1/models
```

- Swagger：<http://127.0.0.1:8000/docs>
- 就绪检查：`GET /readyz`
- 运行日志：`data/gateway.log`（业务日志为 JSON Lines；uvicorn 启动/访问日志保持纯文本）
- 模板 / 观测数据库：`data/gateway.db`（SQLite）

### 一键验收

```bash
py scripts/verify.py
```

脚本会自动：

1. 选择空闲端口启动 `mock/upstream.py` 与网关（`config.test.yaml`）；
2. 真实调用 `deepseek-v4-pro`（Responses）与 `deepseek-flash`（Messages）；
3. 覆盖流式、结构化、模板、观测、重试、限流、错误码；
4. 输出 PASS/FAIL 表格，并写入 `evidence/verification-<时间>.json` / `.md`，同时更新 `evidence/latest.*`；
5. 结束时自动停止两个进程。

单元测试（不访问网络）：

```bash
py -m pytest -q
# 21 passed
```

---

## 4. 配置

`config.yaml` 的核心片段：

```yaml
server:
  host: 127.0.0.1
  port: 8000

storage:
  db_path: data/gateway.db
  log_path: data/gateway.log

http:
  connect_timeout_s: 15
  read_timeout_s: 300

retry:
  max_attempts: 3          # 总尝试次数：首次 + 2 次重试
  base_delay_s: 0.5
  max_delay_s: 8.0
  jitter_s: 0.2

models:
  deepseek-v4-pro:
    adapter: openai_responses
    base_url: https://api.deepseek.com
    path: /responses
    upstream_model: deepseek-v4-pro
    api_key_env: DEEPSEEK_API_KEY
    rate_limit:
      requests_per_minute: 60
      burst: 10
    defaults:
      max_tokens: 2048
      reasoning_effort: low

  deepseek-flash:
    adapter: anthropic_messages
    base_url: https://api.deepseek.com/anthropic
    path: /v1/messages
    upstream_model: deepseek-flash
    api_key_env: DEEPSEEK_API_KEY
    anthropic_version: "2023-06-01"
    rate_limit:
      requests_per_minute: 120
      burst: 20
    defaults:
      max_tokens: 1024
```

- `${VAR}` 会从 `.env` / 进程环境展开；缺失时启动即报错，不会等到首个请求。
- `requests_per_minute: 0` 可关闭某模型限流。
- 环境变量 `GATEWAY_CONFIG` 指定配置文件，`GATEWAY_HOST` / `GATEWAY_PORT` 覆盖监听地址。
- `config.test.yaml` 额外定义 `probe-retry` / `probe-ratelimit`，指向本地 mock，仅用于可重复地验证重试与限流。

---

## 5. API

### 5.1 统一调用 `POST /v1/chat`

兼容别名：`POST /v1/chat/completions`。

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `model` | string | 是 | 网关模型名，见 `GET /v1/models` |
| `messages` | array | 否 | `system` / `user` / `assistant` 消息 |
| `template` | object | 否 | `{name, version, variables}`；`version` 可为整数或 `"latest"` |
| `stream` | bool | 否 | `true` 返回 SSE，默认 `false` |
| `max_tokens` | int | 否 | 缺省用模型 `defaults.max_tokens` |
| `temperature` / `top_p` | number | 否 | 缺省用模型默认值 |
| `response_format` | object | 否 | `text` / `json_object` / `json_schema` |
| `reasoning_effort` | string | 否 | `none` / `low` / `high` / `max` |
| `metadata` | object | 否 | 透传字符串元数据 |

`messages` 与 `template` 至少提供一个；使用模板且最后一条是 user 时，渲染结果会拼接到该 user 消息末尾。

#### 非流式（OpenAI Responses）

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "用一句话解释什么是 SSE"}],
    "max_tokens": 512,
    "reasoning_effort": "low"
  }'
```

响应（节选）：

```json
{
  "id": "cd5b2cd9-fa33-4a6d-bf12-275f0444d157",
  "object": "chat.completion",
  "model": "deepseek-v4-pro",
  "adapter": "openai_responses",
  "choices": [
    {
      "index": 0,
      "message": {"role": "assistant", "content": "SSE 是服务器通过一条长连接持续推送文本事件的标准。"},
      "finish_reason": "stop"
    }
  ],
  "output_text": "SSE 是服务器通过一条长连接持续推送文本事件的标准。",
  "structured_output": null,
  "usage": {
    "input_tokens": 11,
    "output_tokens": 16,
    "total_tokens": 27,
    "cached_input_tokens": 0,
    "cache_write_input_tokens": 0,
    "cache_read_input_tokens": 0,
    "reasoning_tokens": 12,
    "visible_output_tokens": 4
  },
  "meta": {
    "request_id": "req_f6a4f5f47c1e8b6db3b028dc",
    "adapter": "openai_responses",
    "protocol": "OpenAI Responses API",
    "upstream_model": "deepseek-v4-pro",
    "latency_ms": 1176.7,
    "ttft_ms": null,
    "attempts": 1,
    "retries": [],
    "template": null,
    "rate_limit": {"limit": 60, "remaining": 9}
  }
}
```

非流式请求无法从上游拿到首 Token 时刻，因此 `ttft_ms` 为 `null`；首 Token 延迟由流式调用提供。

#### 流式（Anthropic Messages）

```bash
curl -N http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-flash",
    "messages": [{"role": "user", "content": "数到 3，用逗号分隔"}],
    "reasoning_effort": "none",
    "stream": true
  }'
```

统一 SSE 事件：

| event | data | 说明 |
| --- | --- | --- |
| `meta` | 请求/模型/适配器/模板信息 | 第一个事件 |
| `delta` | `{"text": "..."}` | 正文增量 |
| `reasoning` | `{"text": "..."}` | 思维链增量（若上游返回） |
| `done` | `finish_reason`、`usage`、`structured_output`、`meta` | 最后一个事件，含延迟与首 Token 延迟 |
| `error` | 统一错误信封 | 流已开始后发生错误时使用 |

示例：

```text
event: meta
data: {"request_id":"req_...","model":"deepseek-flash","adapter":"anthropic_messages","protocol":"Anthropic Messages API","stream":true,"template":null}

event: delta
data: {"text":"1"}

event: delta
data: {"text":", 2, 3"}

event: done
data: {"finish_reason":"stop","usage":{"input_tokens":14,"output_tokens":7,"total_tokens":21,...},"meta":{"ttft_ms":251.9,"latency_ms":359.4,"attempts":1,"retries":[],...}}
```

> 流式接口不使用 `data: [DONE]`，以 `event: done` 作为结束标志。结构化流式输出时，`delta` 是 JSON 片段，`done.structured_output` 是最终对象。

#### 结构化输出

```bash
curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role": "user", "content": "给杭州生成一条天气 JSON，值合理即可"}],
    "max_tokens": 900,
    "reasoning_effort": "low",
    "response_format": {
      "type": "json_schema",
      "json_schema": {
        "name": "weather",
        "strict": true,
        "schema": {
          "type": "object",
          "properties": {
            "city": {"type": "string"},
            "temp_c": {"type": "number"},
            "conditions": {"type": "string"}
          },
          "required": ["city", "temp_c", "conditions"],
          "additionalProperties": false
        }
      }
    }
  }'
```

两种协议的结构化策略：

- **Responses**：映射到 `text.format = {"type":"json_schema", ...}`，由上游原生约束；
- **Messages**：上游没有可靠的 `response_format`，适配器使用 **强制 `tool_use`**（`emit_structured_output` + `tool_choice`）把 JSON Schema 变成解码约束，再从 `tool_use.input` 取回对象；为避免 DeepSeek thinking 模式拒绝强制工具调用，结构化请求会自动 `thinking: disabled`。

返回同时包含：

- `choices[0].message.content`：JSON 字符串；
- `structured_output`：已通过 `jsonschema` 二次校验的 Python 对象；
- 校验失败返回 `STRUCTURED_OUTPUT_INVALID`，不会把非法 JSON 透传给调用方。

`json_object` 只保证是 JSON 对象，不保证字段；需要固定字段请使用 `json_schema`。

---

### 5.2 提示词模板

模板版本 **不可变**：创建时生成 v1，之后只能追加 v2、v3…；历史版本永远可按编号引用。

```bash
# 创建模板 v1
curl -s -X POST http://127.0.0.1:8000/v1/templates \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "weekly_brief",
    "description": "周报提纲",
    "content": "用 {{words}} 字总结 {{topic}}，面向 {{audience}}。",
    "variables": [
      {"name": "topic", "required": true},
      {"name": "words", "required": true},
      {"name": "audience", "required": false, "default": "工程师"}
    ]
  }'

# 追加 v2
curl -s -X POST http://127.0.0.1:8000/v1/templates/weekly_brief/versions \
  -H 'Content-Type: application/json' \
  -d '{"content": "用 {{words}} 字总结 {{topic}}，并给出 3 个风险点。"}'

# 渲染预览（不调用模型）
curl -s -X POST http://127.0.0.1:8000/v1/templates/weekly_brief/render \
  -H 'Content-Type: application/json' \
  -d '{"version": 1, "variables": {"topic": "统一模型网关", "words": 200}}'

# 调用固定版本 v1
curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-flash",
    "template": {
      "name": "weekly_brief",
      "version": 1,
      "variables": {"topic": "统一模型网关", "words": 200}
    },
    "max_tokens": 400,
    "reasoning_effort": "none"
  }'

# 引用 latest（解析为 v2）
curl -s http://127.0.0.1:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-flash",
    "template": {"name": "weekly_brief", "version": "latest", "variables": {"topic": "统一模型网关", "words": 200}},
    "max_tokens": 400,
    "reasoning_effort": "none"
  }'
```

接口：

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/v1/templates` | 创建模板（v1） |
| GET | `/v1/templates` | 列出模板及最新版本 |
| GET | `/v1/templates/{name}` | 模板详情 + 全部版本 |
| POST | `/v1/templates/{name}/versions` | 追加不可变版本 |
| GET | `/v1/templates/{name}/versions/{version}` | 读取指定版本 |
| POST | `/v1/templates/{name}/render` | 变量渲染预览 |

渲染使用 `SandboxedEnvironment + StrictUndefined`：缺变量返回 `TEMPLATE_VARIABLE_MISSING`，语法错误在创建时即返回 `TEMPLATE_SYNTAX_ERROR`。

---

### 5.3 模型与观测

```bash
# 模型 / 适配器 / 协议 / 限流配置
curl -s http://127.0.0.1:8000/v1/models

# 最近调用明细（可按 model / status 过滤）
curl -s 'http://127.0.0.1:8000/v1/observability/calls?limit=20'

# 单次调用
curl -s http://127.0.0.1:8000/v1/observability/calls/req_xxx

# 聚合统计（默认最近 60 分钟）
curl -s 'http://127.0.0.1:8000/v1/observability/summary?window_minutes=60'
```

单次调用记录包含：

```json
{
  "request_id": "req_...",
  "model": "deepseek-v4-pro",
  "adapter": "openai_responses",
  "stream": true,
  "status": "success",
  "input_tokens": 20,
  "output_tokens": 25,
  "total_tokens": 45,
  "cached_input_tokens": 0,
  "cache_write_input_tokens": 0,
  "cache_read_input_tokens": 0,
  "reasoning_tokens": 17,
  "visible_output_tokens": 8,
  "latency_ms": 829.78,
  "ttft_ms": 318.72,
  "attempts": 1,
  "retry_trace": [],
  "template_name": null,
  "template_version": null
}
```

聚合统计按 `model` 与 `adapter` 分组，返回 calls / success / errors / rate_limited、各类 Token 合计、平均与 P95 延迟、平均与 P95 首 Token 延迟、总重试次数。

Token 口径：

- `input_tokens`：总输入；Anthropic 已把 `cache_creation_input_tokens` 与 `cache_read_input_tokens` 加回，便于跨协议比较。
- `cached_input_tokens`：命中缓存的输入。
- `cache_write_input_tokens` / `cache_read_input_tokens`：Anthropic 缓存写/读。
- `reasoning_tokens`：Responses 的 `reasoning_tokens` 或 Messages 的 `thinking_tokens`。
- `visible_output_tokens = max(0, output_tokens - reasoning_tokens)`。

---

## 6. 错误码与韧性

### 6.1 统一错误信封

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "模型 'deepseek-flash' 触发本地限流：60 请求/分钟，请 1.0s 后重试",
    "type": "rate_limit_error",
    "retryable": true,
    "details": {"model": "deepseek-flash", "scope": "per_model"},
    "request_id": "req_..."
  }
}
```

| code | HTTP | 含义 |
| --- | --- | --- |
| `INVALID_REQUEST` | 400 / 422 | 请求或 JSON Schema 非法 |
| `MODEL_NOT_FOUND` | 404 | 网关没有该 model |
| `TEMPLATE_NOT_FOUND` | 404 | 模板不存在 |
| `TEMPLATE_VERSION_NOT_FOUND` | 404 | 版本不存在 |
| `TEMPLATE_CONFLICT` | 409 | 模板重名 |
| `TEMPLATE_VARIABLE_MISSING` | 422 | 缺少必需变量 |
| `TEMPLATE_RENDER_ERROR` | 422 | 渲染结果为空 |
| `TEMPLATE_SYNTAX_ERROR` | 422 | Jinja 语法错误 |
| `RATE_LIMITED` | 429 | 本地/上游限流，带 `Retry-After` |
| `UPSTREAM_ERROR` | 502 | 上游 4xx/5xx（重试耗尽） |
| `UPSTREAM_AUTH_ERROR` | 502 | 上游 Key/权限问题 |
| `UPSTREAM_PROTOCOL_ERROR` | 502 | 上游响应格式异常 |
| `STRUCTURED_OUTPUT_INVALID` | 502 | 模型输出不满足 JSON Schema |
| `STREAM_INTERRUPTED` | 502 | 流在结束事件前中断（SSE `error` 事件） |
| `UPSTREAM_UNAVAILABLE` | 503 | 连接失败 |
| `UPSTREAM_TIMEOUT` | 504 | 超时 |
| `INTERNAL_ERROR` | 500 | 网关兜底错误 |

所有响应带 `X-Request-ID`；错误体里的 `request_id` 与日志、观测记录一致，便于串联排查。

### 6.2 指数退避重试

- 默认 `max_attempts: 3`（首次 + 2 次重试）；可通过 `GATEWAY_CONFIG` 调整。
- 只重试 `UPSTREAM_ERROR`、`UPSTREAM_UNAVAILABLE`、`UPSTREAM_TIMEOUT`、上游 `RATE_LIMITED`；`INVALID_REQUEST`、鉴权失败、结构化校验失败不重试。
- 延迟：`min(base_delay * 2^(attempt-1), max_delay) + random(0, jitter)`；若上游返回 `Retry-After`，优先遵守。
- 流式请求只在 **收到 2xx 响应头之前** 重试；一旦开始向下游发送 token，失败只能通过 SSE `error` 事件告知，避免重复输出。
- `meta.attempts` / `meta.retries` 与 `retry_trace` 会记录每次失败及等待时间，并落库到观测数据。

真实验收中，mock 注入 2 次 503 后：`attempts=3`，退避约 `0.2s -> 0.35s`（含 jitter），第三次成功。

### 6.3 按模型独立限流

- 每个模型一个令牌桶，容量 `burst`，按 `requests_per_minute / 60` 每秒补充。
- 模型之间完全独立：`probe-ratelimit` 被限流时，`deepseek-flash` 仍可正常调用。
- 超限返回 `429 RATE_LIMITED`，并带：
  - `Retry-After`
  - `X-RateLimit-Limit`
  - `X-RateLimit-Remaining`
  - `X-RateLimit-Reset`
- 限流拒绝同样写入观测记录（`status=error`, `error_code=RATE_LIMITED`, `attempts=0`）。

> 当前限流是 **单进程内存** 实现。多副本部署时应换成 Redis 令牌桶或网关级限流。

---

## 7. 验收证据

运行：

```bash
py scripts/verify.py
```

最近一次结果：

```text
15/15 PASS
```

证据文件：

- [验证明细（Markdown）](evidence/latest.md)
- [原始证据（JSON）](evidence/latest.json)
- [网关 JSONL 日志](evidence/logs/gateway.log)
- [mock 上游日志](evidence/logs/mock.log)

15 个检查项与需求的对应关系：

| # | 检查 | 覆盖需求 |
| --- | --- | --- |
| 1 | `health_ready` | 服务可用性 |
| 2 | `models_routing` | 统一抽象 / 按 model 动态路由 |
| 3 | `upstream_models` | 真实上游模型存在 |
| 4 | `non_stream_responses` | Responses 协议非流式 |
| 5 | `non_stream_messages` | Messages 协议非流式 |
| 6 | `stream_responses` | Responses SSE + 首 Token 延迟 |
| 7 | `stream_messages` | Messages SSE + 首 Token 延迟 |
| 8 | `structured_responses` | Responses `json_schema` |
| 9 | `structured_messages` | Messages 强制 tool_use 结构化 |
| 10 | `templates` | 模板版本、变量替换、版本引用、错误分支 |
| 11 | `error_mapping` | 统一错误码 |
| 12 | `retry_backoff` | 指数退避（3 次尝试成功） |
| 13 | `retry_exhaustion` | 重试上限与最终错误 |
| 14 | `rate_limit` | 每模型独立限流 + 429 + 隔离 |
| 15 | `observability` | Token 分类、延迟、首 Token、重试轨迹、模板元数据 |

验证脚本使用的是**真实 DeepSeek API**；`probe-retry` / `probe-ratelimit` 指向本地 mock 上游，只用于可重复地制造 503 和低配额，不消耗真实额度。所有真实调用都使用很小的 `max_tokens`。

---

## 8. 设计取舍与边界

1. **协议差异是重点**：两个适配器分别处理 `Authorization: Bearer` 与 `x-api-key`、`input/output` 与 `messages`、`response.completed` 与 `message_stop`、`input_tokens_details` 与 `cache_*` 等差异；统一层只暴露一种 `Usage` 和一种 SSE。
2. **结构化输出不依赖上游“善意”**：Responses 用原生 `text.format`；Messages 用强制工具调用；两条路径最终都经过 `jsonschema` 校验，非法结果直接报错。
3. **流式可观测性**：`ttft_ms` 在服务端收到第一个 `delta/reasoning` 时记录；客户端断开时记录 `status=cancelled`，避免“调用消失”。
4. **模板不可变**：版本只能追加，不能覆盖；这使线上 prompt 可回滚、可审计。模板内容是纯文本，不执行任意代码（Jinja Sandbox）。
5. **单进程边界**：SQLite 与内存令牌桶适合演示/单实例；生产多副本建议 PostgreSQL/ClickHouse + Redis。
6. **未内置客户端鉴权**：网关假定部署在内网或由 API Gateway 前置鉴权；公网部署请加 `X-API-Key`/OAuth。
7. **Responses 的 `reasoning_effort=none`**：该协议只支持 `low/high/max`，因此 `none` 会省略 `reasoning` 字段，交由上游默认；Messages 的 `none` 会明确 `thinking: disabled`。
8. **Anthropic `json_object`**：强制工具调用可能返回 `{"parameters": {...}}` 这类包装；需要固定结构时请使用 `json_schema`。这是上游工具解码行为，不是网关透传错误。

---

## 9. 常用命令速查

```bash
# 安装
py -m pip install -r requirements.txt

# 启动
py -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# 验收（自动起停 mock + 网关）
py scripts/verify.py

# 单元测试
py -m pytest -q

# 看最近 10 条调用
curl -s 'http://127.0.0.1:8000/v1/observability/calls?limit=10'

# 看最近 60 分钟聚合
curl -s 'http://127.0.0.1:8000/v1/observability/summary?window_minutes=60'

# 查看模板列表
curl -s http://127.0.0.1:8000/v1/templates
```

### Windows PowerShell 调用示例

`curl` 在部分 Windows 环境的 Schannel 下可能报 TLS 凭据错误；调用本机 HTTP 服务不受影响。若需要更稳的 JSON 引号处理，可直接用 PowerShell：

```powershell
$body = @{
  model = "deepseek-flash"
  messages = @(@{ role = "user"; content = "Reply with exactly: PS-OK" })
  max_tokens = 100
  reasoning_effort = "none"
} | ConvertTo-Json -Depth 5

Invoke-RestMethod -Uri http://127.0.0.1:8000/v1/chat `
  -Method Post -ContentType "application/json" -Body $body |
  ConvertTo-Json -Depth 8
```

---

## 10. 安全

- `.env` 与 `data/` 已在 `.gitignore` 中；不要提交真实 Key。
- 验收证据只包含模型输出与统计，不包含 API Key。
- 日志不记录完整 Prompt/响应正文，只记录 request_id、模型、Token、延迟和状态。
- 模板内容由调用方提供；虽然使用 Sandbox，仍建议只对可信调用方开放模板写接口。
