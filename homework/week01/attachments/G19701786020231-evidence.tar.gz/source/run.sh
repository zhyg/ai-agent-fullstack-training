#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

export GATEWAY_CONFIG="${GATEWAY_CONFIG:-config.yaml}"
export GATEWAY_PORT="${GATEWAY_PORT:-8000}"

echo "Starting LLM gateway on http://127.0.0.1:${GATEWAY_PORT} (config: ${GATEWAY_CONFIG})"
exec python3 -m uvicorn app.main:app --host 127.0.0.1 --port "${GATEWAY_PORT}"
