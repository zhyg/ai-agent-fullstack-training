"""FastAPI 入口：路由、中间件、统一错误处理。"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastapi import FastAPI, Path, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from .config import GatewayConfig, load_config
from .context import current_request_id, request_id_var, sanitize_request_id
from .errors import GatewayError
from .logging_setup import setup_logging
from .observability import ObservabilityStore
from .ratelimit import RateLimiterRegistry
from .schemas import (
    ChatRequest,
    TemplateCreate,
    TemplateRenderRequest,
    TemplateVersionCreate,
)
from .service import GatewayService
from .templates import TemplateStore

logger = logging.getLogger("gateway.api")

DESCRIPTION = """
统一封装 OpenAI Responses API 与 Anthropic Messages API 的模型调用服务。

- **统一入口**：`POST /v1/chat` / `POST /v1/chat/completions`
- **动态路由**：按请求体 `model` 选择适配器
- **流式输出**：`stream=true` 返回统一 SSE 事件
- **结构化输出**：`response_format` 支持 `json_object` / `json_schema`
- **提示词模板**：模板版本不可变，支持 `name@version` 引用与变量替换
- **可观测性**：Token 分类统计、总延迟、首 Token 延迟
- **韧性**：统一错误码、指数退避重试、按模型独立限流
"""

TAGS = [
    {"name": "chat", "description": "统一模型调用（流式 / 非流式 / 结构化）"},
    {"name": "models", "description": "模型与适配器信息"},
    {"name": "templates", "description": "提示词模板与版本管理"},
    {"name": "observability", "description": "调用明细与聚合统计"},
    {"name": "health", "description": "健康检查"},
]


@asynccontextmanager
async def lifespan(app: FastAPI):
    config: GatewayConfig = load_config()
    setup_logging(config.storage.log_path)
    logger.info(
        "starting gateway models=%s adapters=%s db=%s",
        sorted(config.models),
        sorted({model.adapter for model in config.models.values()}),
        config.storage.db_path,
    )

    templates = TemplateStore(config.storage.db_path)
    observability = ObservabilityStore(config.storage.db_path)
    limiters = RateLimiterRegistry(
        {name: model.rate_limit for name, model in config.models.items()}
    )
    client = httpx.AsyncClient(
        timeout=httpx.Timeout(
            connect=config.http.connect_timeout_s,
            read=config.http.read_timeout_s,
            write=config.http.write_timeout_s,
            pool=config.http.connect_timeout_s,
        ),
        limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
    )
    service = GatewayService(config, client, templates, observability, limiters)

    app.state.config = config
    app.state.service = service
    app.state.observability = observability
    app.state.templates = templates
    app.state.started_at = time.time()

    try:
        yield
    finally:
        await client.aclose()
        observability.close()
        templates.close()
        logger.info("gateway stopped")


app = FastAPI(
    title="LLM 统一模型调用服务",
    description=DESCRIPTION,
    version="1.0.0",
    openapi_tags=TAGS,
    lifespan=lifespan,
)


# --------------------------------------------------------------------- 中间件
@app.middleware("http")
async def request_context_middleware(request: Request, call_next):
    request_id = sanitize_request_id(request.headers.get("X-Request-ID"))
    token = request_id_var.set(request_id)
    started = time.perf_counter()
    try:
        response = await call_next(request)
    finally:
        request_id_var.reset(token)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time-Ms"] = f"{(time.perf_counter() - started) * 1000:.1f}"
    return response


# --------------------------------------------------------------------- 错误
@app.exception_handler(GatewayError)
async def gateway_error_handler(request: Request, exc: GatewayError) -> JSONResponse:
    request_id = current_request_id()
    headers = {"X-Request-ID": request_id, **exc.headers}
    return JSONResponse(
        status_code=exc.http_status,
        content=exc.envelope(request_id),
        headers=headers,
    )


@app.exception_handler(RequestValidationError)
async def validation_error_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    errors = []
    for item in exc.errors():
        errors.append(
            {
                "loc": [str(part) for part in item.get("loc", ())],
                "msg": item.get("msg", ""),
                "type": item.get("type", ""),
            }
        )
    error = GatewayError(
        "INVALID_REQUEST",
        "请求参数校验失败",
        http_status=422,
        details={"errors": errors},
    )
    request_id = current_request_id()
    return JSONResponse(
        status_code=422,
        content=error.envelope(request_id),
        headers={"X-Request-ID": request_id},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(
    request: Request, exc: StarletteHTTPException
) -> JSONResponse:
    if exc.status_code == 404:
        code = "NOT_FOUND"
    elif exc.status_code == 405:
        code = "METHOD_NOT_ALLOWED"
    elif exc.status_code == 401:
        code = "UNAUTHORIZED"
    elif exc.status_code == 403:
        code = "FORBIDDEN"
    else:
        code = "INVALID_REQUEST"
    error = GatewayError(
        code,
        str(exc.detail),
        http_status=exc.status_code,
        headers=dict(exc.headers or {}),
    )
    request_id = current_request_id()
    return JSONResponse(
        status_code=exc.status_code,
        content=error.envelope(request_id),
        headers={"X-Request-ID": request_id, **dict(exc.headers or {})},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("unhandled error path=%s", request.url.path)
    error = GatewayError("INTERNAL_ERROR", f"网关内部错误: {exc.__class__.__name__}")
    request_id = current_request_id()
    return JSONResponse(
        status_code=500,
        content=error.envelope(request_id),
        headers={"X-Request-ID": request_id},
    )


# --------------------------------------------------------------------- 基础
@app.get("/", tags=["health"], summary="服务信息")
async def root(request: Request) -> dict[str, Any]:
    return {
        "name": "LLM 统一模型调用服务",
        "version": "1.0.0",
        "docs": str(request.url_for("swagger_ui_html")),
        "endpoints": [
            "GET /v1/models",
            "POST /v1/chat",
            "POST /v1/chat/completions",
            "GET/POST /v1/templates",
            "GET /v1/observability/summary",
            "GET /v1/observability/calls",
        ],
    }


@app.get("/healthz", tags=["health"], summary="存活检查")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/readyz", tags=["health"], summary="就绪检查")
async def readyz(request: Request) -> dict[str, Any]:
    service: GatewayService = request.app.state.service
    return service.ready()


@app.get("/v1/models", tags=["models"], summary="列出网关模型与适配器")
async def list_models(request: Request) -> dict[str, Any]:
    service: GatewayService = request.app.state.service
    return {"object": "list", "data": service.list_models()}


# --------------------------------------------------------------------- 调用
@app.post(
    "/v1/chat",
    tags=["chat"],
    summary="统一模型调用（支持 stream / response_format / template）",
    response_model=None,
)
@app.post("/v1/chat/completions", include_in_schema=False, response_model=None)
async def chat(payload: ChatRequest, request: Request):
    service: GatewayService = request.app.state.service
    request_id = current_request_id()
    client_ip = request.client.host if request.client else None
    started_at = time.perf_counter()

    prepared = await service.prepare(
        payload,
        request_id,
        client_ip=client_ip,
        started_at=started_at,
    )
    if payload.stream:
        return await service.stream_response(prepared)

    body = await service.complete(prepared)
    headers = {
        **prepared.rate_decision.headers(),
        "X-Request-ID": request_id,
    }
    return JSONResponse(content=body, headers=headers)


# --------------------------------------------------------------------- 模板
@app.post("/v1/templates", tags=["templates"], status_code=201, summary="创建模板（v1）")
async def create_template(payload: TemplateCreate, request: Request) -> dict[str, Any]:
    store: TemplateStore = request.app.state.templates
    return store.create(
        payload.name,
        payload.content,
        description=payload.description,
        variables=[item.model_dump() for item in payload.variables],
    )


@app.get("/v1/templates", tags=["templates"], summary="列出模板（最新版本）")
async def list_templates(request: Request) -> dict[str, Any]:
    store: TemplateStore = request.app.state.templates
    return {"object": "list", "data": store.list_templates()}


@app.get("/v1/templates/{name}", tags=["templates"], summary="模板详情与全部版本")
async def get_template(
    request: Request, name: str = Path(min_length=1, max_length=64)
) -> dict[str, Any]:
    store: TemplateStore = request.app.state.templates
    return store.get(name)


@app.post(
    "/v1/templates/{name}/versions",
    tags=["templates"],
    status_code=201,
    summary="追加不可变的新版本",
)
async def add_template_version(
    payload: TemplateVersionCreate,
    request: Request,
    name: str = Path(min_length=1, max_length=64),
) -> dict[str, Any]:
    store: TemplateStore = request.app.state.templates
    variables = (
        [item.model_dump() for item in payload.variables]
        if payload.variables is not None
        else None
    )
    return store.add_version(name, payload.content, variables=variables)


@app.get(
    "/v1/templates/{name}/versions/{version}",
    tags=["templates"],
    summary="读取指定版本",
)
async def get_template_version(
    request: Request,
    name: str = Path(min_length=1, max_length=64),
    version: int = Path(ge=1),
) -> dict[str, Any]:
    store: TemplateStore = request.app.state.templates
    return store.get_version(name, version)


@app.post("/v1/templates/{name}/render", tags=["templates"], summary="渲染预览（不调用模型）")
async def render_template(
    payload: TemplateRenderRequest,
    request: Request,
    name: str = Path(min_length=1, max_length=64),
) -> dict[str, Any]:
    store: TemplateStore = request.app.state.templates
    return store.render(name, payload.version, payload.variables)


# --------------------------------------------------------------------- 观测
@app.get("/v1/observability/summary", tags=["observability"], summary="调用聚合统计")
async def observability_summary(
    request: Request,
    window_minutes: int = Query(default=60, ge=1, le=10_080),
) -> dict[str, Any]:
    store: ObservabilityStore = request.app.state.observability
    return store.summary(window_minutes=window_minutes)


@app.get("/v1/observability/calls", tags=["observability"], summary="最近调用明细")
async def observability_calls(
    request: Request,
    limit: int = Query(default=50, ge=1, le=500),
    model: str | None = Query(default=None),
    status: str | None = Query(default=None),
) -> dict[str, Any]:
    store: ObservabilityStore = request.app.state.observability
    data = store.list_calls(limit=limit, model=model, status=status)
    return {"object": "list", "count": len(data), "data": data}


@app.get(
    "/v1/observability/calls/{request_id}",
    tags=["observability"],
    summary="按 request_id 查询调用",
)
async def observability_call(request: Request, request_id: str) -> dict[str, Any]:
    store: ObservabilityStore = request.app.state.observability
    data = store.get_call(request_id)
    if data is None:
        raise GatewayError("NOT_FOUND", f"没有 request_id={request_id!r} 的调用记录")
    return data
