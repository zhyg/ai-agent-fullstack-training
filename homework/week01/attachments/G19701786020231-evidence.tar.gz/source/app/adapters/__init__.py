"""适配器注册与工厂。"""

from __future__ import annotations

from ..config import GatewayConfig, ModelConfig
from .anthropic_messages import AnthropicMessagesAdapter
from .base import AdapterResult, BaseAdapter, NormalizedRequest, StreamChunk
from .openai_responses import OpenAIResponsesAdapter

__all__ = [
    "AdapterResult",
    "AnthropicMessagesAdapter",
    "BaseAdapter",
    "NormalizedRequest",
    "OpenAIResponsesAdapter",
    "StreamChunk",
    "build_adapter",
]


def build_adapter(
    model_name: str, config: ModelConfig, gateway: GatewayConfig
) -> BaseAdapter:
    if config.adapter == "openai_responses":
        return OpenAIResponsesAdapter(model_name, config, gateway)
    if config.adapter == "anthropic_messages":
        return AnthropicMessagesAdapter(model_name, config, gateway)
    raise ValueError(f"未知适配器: {config.adapter}")
