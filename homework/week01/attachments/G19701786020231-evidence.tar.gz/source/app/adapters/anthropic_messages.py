"""Anthropic Messages API 适配器（DeepSeek V4 Flash 走此协议）。"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator

import httpx

from ..errors import GatewayError
from ..schemas import Usage
from .base import (
    FINISH_REASONS,
    AdapterResult,
    BaseAdapter,
    NormalizedRequest,
    StreamChunk,
    iter_sse,
    sse_json,
    usage_from_anthropic,
)

_STRUCTURED_TOOL = "emit_structured_output"


class AnthropicMessagesAdapter(BaseAdapter):
    adapter_name = "anthropic_messages"
    protocol = "Anthropic Messages API"

    def auth_headers(self) -> dict[str, str]:
        return {
            "x-api-key": self.cfg.resolve_api_key(),
            "anthropic-version": self.cfg.anthropic_version,
        }

    # ------------------------------------------------------------------ 请求
    def build_payload(self, req: NormalizedRequest, *, stream: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": req.upstream_model,
            "max_tokens": req.max_tokens,
            "messages": [{"role": role, "content": content} for role, content in req.messages],
            "stream": stream,
        }
        if req.system:
            payload["system"] = req.system
        if req.temperature is not None:
            payload["temperature"] = req.temperature
        if req.top_p is not None:
            payload["top_p"] = req.top_p

        schema = self.structured_schema(req)
        if schema is not None:
            # Anthropic Messages 没有可靠的 response_format：用强制 tool_use 把
            # JSON Schema 变成解码约束，再从 tool_use.input 取回结构化结果。
            payload["tools"] = [
                {
                    "name": _STRUCTURED_TOOL,
                    "description": (
                        "Return the final answer as a JSON object that strictly conforms "
                        "to the provided input_schema. Do not add any other text."
                    ),
                    "input_schema": schema,
                }
            ]
            payload["tool_choice"] = {"type": "tool", "name": _STRUCTURED_TOOL}
            # DeepSeek 的 thinking 模式不支持强制 tool_choice，结构化输出时关闭 thinking。
            payload["thinking"] = {"type": "disabled"}
        elif req.reasoning_effort == "none":
            payload["thinking"] = {"type": "disabled"}
        return payload

    # ------------------------------------------------------------------ 响应
    def parse_response(self, data: dict[str, Any], req: NormalizedRequest) -> AdapterResult:
        if data.get("type") == "error" or data.get("error"):
            raise GatewayError(
                "UPSTREAM_ERROR", "上游返回 error", details={"error": data.get("error")}
            )

        text_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_input: dict[str, Any] | None = None

        for block in data.get("content") or []:
            if not isinstance(block, dict):
                continue
            block_type = block.get("type")
            if block_type == "text":
                text_parts.append(str(block.get("text") or ""))
            elif block_type == "thinking":
                reasoning_parts.append(str(block.get("thinking") or ""))
            elif block_type == "tool_use" and block.get("name") == _STRUCTURED_TOOL:
                candidate = block.get("input")
                if isinstance(candidate, dict):
                    tool_input = candidate

        structured = None
        text = "".join(text_parts)
        if self.is_structured(req):
            if tool_input is not None:
                structured = self.validate_structured(tool_input, req)
            else:
                structured = self.parse_structured_text(text, req)
            text = json.dumps(structured, ensure_ascii=False)
        elif not text:
            raise GatewayError(
                "UPSTREAM_PROTOCOL_ERROR",
                "上游响应没有 text 内容",
                details={"stop_reason": data.get("stop_reason")},
            )

        return AdapterResult(
            upstream_id=str(data.get("id") or ""),
            text=text,
            reasoning_text="".join(reasoning_parts),
            finish_reason=self._finish_reason(data.get("stop_reason"), structured is not None),
            usage=usage_from_anthropic(data.get("usage")),
            upstream_model=str(data.get("model") or req.upstream_model),
            structured_output=structured,
            status="completed",
        )

    # ------------------------------------------------------------------ 流式
    async def iter_stream(
        self, response: httpx.Response, req: NormalizedRequest
    ) -> AsyncIterator[StreamChunk]:
        text_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_parts: list[str] = []
        upstream_id = ""
        usage_raw: dict[str, Any] = {}
        stop_reason: str | None = None
        completed = False

        async for event_name, raw in iter_sse(response):
            data = sse_json(event_name, raw)
            etype = str(data.get("type") or event_name or "")

            if etype == "message_start":
                message = data.get("message") or {}
                upstream_id = str(message.get("id") or upstream_id)
                usage_raw = dict(message.get("usage") or {})
            elif etype == "content_block_delta":
                delta = data.get("delta") or {}
                delta_type = delta.get("type")
                if delta_type == "text_delta":
                    text = str(delta.get("text") or "")
                    if text:
                        text_parts.append(text)
                        yield StreamChunk("delta", text=text)
                elif delta_type == "thinking_delta":
                    thinking = str(delta.get("thinking") or "")
                    if thinking:
                        reasoning_parts.append(thinking)
                        yield StreamChunk("reasoning", text=thinking)
                elif delta_type == "input_json_delta":
                    partial = str(delta.get("partial_json") or "")
                    if partial:
                        tool_parts.append(partial)
                        yield StreamChunk("delta", text=partial)
            elif etype == "message_delta":
                delta = data.get("delta") or {}
                stop_reason = delta.get("stop_reason") or stop_reason
                delta_usage = data.get("usage") or {}
                # message_delta 只覆盖输出侧，输入侧以 message_start 为准
                if "output_tokens" in delta_usage:
                    usage_raw["output_tokens"] = delta_usage["output_tokens"]
                if "output_tokens_details" in delta_usage:
                    usage_raw["output_tokens_details"] = delta_usage["output_tokens_details"]
                if delta_usage.get("cache_creation_input_tokens") is not None:
                    usage_raw["cache_creation_input_tokens"] = delta_usage[
                        "cache_creation_input_tokens"
                    ]
                if delta_usage.get("cache_read_input_tokens") is not None:
                    usage_raw["cache_read_input_tokens"] = delta_usage[
                        "cache_read_input_tokens"
                    ]
            elif etype == "message_stop":
                completed = True
            elif etype == "error":
                raise GatewayError(
                    "UPSTREAM_ERROR", "上游流式响应返回 error 事件", details={"error": data}
                )

        if not completed:
            raise GatewayError(
                "STREAM_INTERRUPTED", "上游流在 message_stop 之前结束", retryable=False
            )

        structured = None
        if self.is_structured(req):
            raw_json = "".join(tool_parts).strip()
            if not raw_json:
                raise GatewayError("STRUCTURED_OUTPUT_INVALID", "结构化流式输出为空")
            if raw_json.startswith("```"):
                from .base import _strip_code_fence

                raw_json = _strip_code_fence(raw_json)
            try:
                candidate = json.loads(raw_json)
            except json.JSONDecodeError as exc:
                raise GatewayError(
                    "STRUCTURED_OUTPUT_INVALID",
                    "结构化流式输出不是合法 JSON",
                    details={"error": str(exc), "preview": raw_json[:300]},
                ) from exc
            structured = self.validate_structured(candidate, req)
            text = json.dumps(structured, ensure_ascii=False)
        else:
            text = "".join(text_parts)

        yield StreamChunk(
            "done",
            text=text,
            usage=usage_from_anthropic(usage_raw),
            finish_reason=self._finish_reason(stop_reason, structured is not None),
            structured_output=structured,
            upstream_id=upstream_id,
        )

    @staticmethod
    def _finish_reason(stop_reason: Any, structured: bool) -> str:
        if structured:
            return "stop"
        return FINISH_REASONS.get(str(stop_reason), "stop")
