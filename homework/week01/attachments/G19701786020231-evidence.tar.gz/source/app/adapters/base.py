"""适配器基类：统一请求/响应/流式事件的公共逻辑。"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, ClassVar

import httpx
from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError

from ..config import GatewayConfig, ModelConfig
from ..errors import GatewayError
from ..schemas import ResponseFormat, Usage

FINISH_REASONS = {
    "stop": "stop",
    "end_turn": "stop",
    "stop_sequence": "stop",
    "length": "length",
    "max_tokens": "length",
    "tool_calls": "tool_calls",
    "tool_use": "tool_calls",
    "content_filter": "content_filter",
    "refusal": "content_filter",
}


@dataclass(slots=True)
class NormalizedRequest:
    model: str
    upstream_model: str
    system: str | None
    messages: list[tuple[str, str]]
    max_tokens: int
    temperature: float | None = None
    top_p: float | None = None
    response_format: ResponseFormat | None = None
    reasoning_effort: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class AdapterResult:
    upstream_id: str
    text: str
    reasoning_text: str
    finish_reason: str
    usage: Usage
    upstream_model: str
    structured_output: dict[str, Any] | None = None
    status: str = "completed"
    incomplete_reason: str | None = None


@dataclass(slots=True)
class StreamChunk:
    kind: str  # delta | reasoning | done
    text: str = ""
    usage: Usage | None = None
    finish_reason: str | None = None
    structured_output: dict[str, Any] | None = None
    upstream_id: str | None = None
    incomplete_reason: str | None = None


class BaseAdapter(ABC):
    adapter_name: ClassVar[str]
    protocol: ClassVar[str]

    def __init__(self, model_name: str, config: ModelConfig, gateway: GatewayConfig) -> None:
        self.model_name = model_name
        self.cfg = config
        self.gateway = gateway

    # ------------------------------------------------------------- HTTP 组装
    @property
    def timeout_s(self) -> float:
        return self.cfg.timeout_s or self.gateway.http.read_timeout_s

    def build_request(self, req: NormalizedRequest, *, stream: bool) -> httpx.Request:
        payload = self.build_payload(req, stream=stream)
        headers = self.build_headers(stream=stream)
        return httpx.Request("POST", self.cfg.url, json=payload, headers=headers)

    def build_headers(self, *, stream: bool) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
            "User-Agent": "llm-protocol-gateway/1.0",
            **self.cfg.headers,
        }
        headers.update(self.auth_headers())
        return headers

    @abstractmethod
    def auth_headers(self) -> dict[str, str]:
        ...

    @abstractmethod
    def build_payload(self, req: NormalizedRequest, *, stream: bool) -> dict[str, Any]:
        ...

    @abstractmethod
    def parse_response(self, data: dict[str, Any], req: NormalizedRequest) -> AdapterResult:
        ...

    @abstractmethod
    def iter_stream(
        self, response: httpx.Response, req: NormalizedRequest
    ) -> AsyncIterator[StreamChunk]:
        ...

    # ------------------------------------------------------------- 结构化输出
    def structured_schema(self, req: NormalizedRequest) -> dict[str, Any] | None:
        fmt = req.response_format
        if fmt is None or fmt.type == "text":
            return None
        if fmt.type == "json_schema" and fmt.json_schema is not None:
            return fmt.json_schema.schema_definition
        return {"type": "object", "additionalProperties": True}

    def is_structured(self, req: NormalizedRequest) -> bool:
        return self.structured_schema(req) is not None

    def validate_request(self, req: NormalizedRequest) -> None:
        schema = self.structured_schema(req)
        if schema is None:
            return
        try:
            Draft202012Validator.check_schema(schema)
        except SchemaError as exc:
            raise GatewayError(
                "INVALID_REQUEST",
                f"response_format.json_schema 不是合法 JSON Schema: {exc.message}",
                details={"path": list(exc.path)},
            ) from exc

    def validate_structured(self, value: Any, req: NormalizedRequest) -> dict[str, Any]:
        if not isinstance(value, dict):
            raise GatewayError(
                "STRUCTURED_OUTPUT_INVALID",
                "结构化输出不是 JSON 对象",
                details={"actual_type": type(value).__name__},
            )
        schema = self.structured_schema(req)
        if schema is not None:
            errors = sorted(
                Draft202012Validator(schema).iter_errors(value),
                key=lambda error: list(error.absolute_path),
            )
            if errors:
                raise GatewayError(
                    "STRUCTURED_OUTPUT_INVALID",
                    "结构化输出不符合 JSON Schema",
                    details={
                        "errors": [
                            {
                                "path": "/".join(str(item) for item in error.absolute_path),
                                "message": error.message,
                            }
                            for error in errors[:5]
                        ]
                    },
                )
        return value

    def parse_structured_text(self, text: str, req: NormalizedRequest) -> dict[str, Any]:
        raw = text.strip()
        if raw.startswith("```"):
            raw = _strip_code_fence(raw)
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise GatewayError(
                "STRUCTURED_OUTPUT_INVALID",
                "模型返回的内容不是合法 JSON",
                details={"error": str(exc), "preview": text[:300]},
            ) from exc
        return self.validate_structured(value, req)


def _strip_code_fence(text: str) -> str:
    lines = text.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip().startswith("```"):
        lines = lines[:-1]
    return "\n".join(lines).strip()


# ------------------------------------------------------------------ 流式解析
async def iter_sse(response: httpx.Response) -> AsyncIterator[tuple[str | None, str]]:
    """把 SSE 字节流解析为 (event, data)，正确处理多行 data 与心跳注释。"""
    event: str | None = None
    data_lines: list[str] = []
    async for line in response.aiter_lines():
        if line == "":
            if data_lines:
                yield event, "\n".join(data_lines)
            event = None
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].lstrip())
        # id:/retry: 字段对当前用途无意义，忽略
    if data_lines:
        yield event, "\n".join(data_lines)


def sse_json(event: str | None, data: str) -> dict[str, Any]:
    if data.strip() == "[DONE]":
        return {"type": "done"}
    try:
        value = json.loads(data)
    except json.JSONDecodeError as exc:
        raise GatewayError(
            "UPSTREAM_PROTOCOL_ERROR",
            f"上游 SSE 数据不是合法 JSON: {data[:200]}",
            details={"event": event},
        ) from exc
    if not isinstance(value, dict):
        raise GatewayError("UPSTREAM_PROTOCOL_ERROR", "上游 SSE data 不是 JSON 对象")
    if event and "type" not in value:
        value["type"] = event
    return value


# ------------------------------------------------------------------ Usage 归一
def _int(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def usage_from_responses(raw: dict[str, Any] | None) -> Usage:
    raw = raw or {}
    input_tokens = _int(raw.get("input_tokens"))
    output_tokens = _int(raw.get("output_tokens"))
    input_details = raw.get("input_tokens_details") or {}
    output_details = raw.get("output_tokens_details") or {}
    cached = _int(input_details.get("cached_tokens"))
    reasoning = _int(output_details.get("reasoning_tokens"))
    total = _int(raw.get("total_tokens")) or input_tokens + output_tokens
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total,
        cached_input_tokens=cached,
        cache_write_input_tokens=0,
        cache_read_input_tokens=0,
        reasoning_tokens=reasoning,
        visible_output_tokens=max(0, output_tokens - reasoning),
    )


def usage_from_anthropic(raw: dict[str, Any] | None) -> Usage:
    raw = raw or {}
    uncached_input = _int(raw.get("input_tokens"))
    cache_write = _int(raw.get("cache_creation_input_tokens"))
    cache_read = _int(raw.get("cache_read_input_tokens"))
    input_tokens = uncached_input + cache_write + cache_read
    output_tokens = _int(raw.get("output_tokens"))
    details = raw.get("output_tokens_details") or {}
    reasoning = _int(details.get("thinking_tokens"))
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=input_tokens + output_tokens,
        cached_input_tokens=cache_read,
        cache_write_input_tokens=cache_write,
        cache_read_input_tokens=cache_read,
        reasoning_tokens=reasoning,
        visible_output_tokens=max(0, output_tokens - reasoning),
    )


def usage_dict(usage: Usage) -> dict[str, int]:
    return usage.model_dump()
