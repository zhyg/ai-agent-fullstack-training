"""OpenAI Responses API 适配器（DeepSeek V4 Pro 走此协议）。"""

from __future__ import annotations

from typing import Any, AsyncIterator

import httpx

from ..errors import GatewayError
from ..schemas import Usage
from .base import (
    AdapterResult,
    BaseAdapter,
    NormalizedRequest,
    StreamChunk,
    iter_sse,
    sse_json,
    usage_from_responses,
)


class OpenAIResponsesAdapter(BaseAdapter):
    adapter_name = "openai_responses"
    protocol = "OpenAI Responses API"

    def auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.cfg.resolve_api_key()}"}

    # ------------------------------------------------------------------ 请求
    def build_payload(self, req: NormalizedRequest, *, stream: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": req.upstream_model,
            "input": [
                {
                    "role": role,
                    "content": [
                        {
                            "type": "input_text" if role == "user" else "output_text",
                            "text": content,
                        }
                    ],
                }
                for role, content in req.messages
            ],
            "max_output_tokens": req.max_tokens,
            "stream": stream,
            "store": False,
        }
        if req.system:
            payload["instructions"] = req.system
        if req.temperature is not None:
            payload["temperature"] = req.temperature
        if req.top_p is not None:
            payload["top_p"] = req.top_p
        if req.metadata:
            payload["metadata"] = req.metadata
        if req.reasoning_effort and req.reasoning_effort != "none":
            payload["reasoning"] = {"effort": req.reasoning_effort}

        fmt = req.response_format
        if fmt is not None and fmt.type != "text":
            if fmt.type == "json_schema" and fmt.json_schema is not None:
                payload["text"] = {
                    "format": {
                        "type": "json_schema",
                        "name": fmt.json_schema.name,
                        "schema": fmt.json_schema.schema_definition,
                        "strict": fmt.json_schema.strict,
                    }
                }
            else:
                payload["text"] = {"format": {"type": "json_object"}}
        return payload

    # ------------------------------------------------------------------ 响应
    def parse_response(self, data: dict[str, Any], req: NormalizedRequest) -> AdapterResult:
        if data.get("error"):
            raise GatewayError(
                "UPSTREAM_ERROR",
                "上游在 200 响应中返回 error 字段",
                details={"upstream_error": data["error"]},
            )
        status = data.get("status") or "completed"
        if status in ("failed", "cancelled"):
            raise GatewayError(
                "UPSTREAM_ERROR",
                f"上游响应状态为 {status}",
                details={"status": status, "error": data.get("error")},
            )

        text, reasoning = _extract_output(data)
        if not text and self.is_structured(req):
            raise GatewayError(
                "STRUCTURED_OUTPUT_INVALID",
                "结构化输出为空",
                details={"status": status, "incomplete": data.get("incomplete_details")},
            )

        structured = None
        if self.is_structured(req):
            structured = self.parse_structured_text(text, req)
            text = _json_text(structured)

        return AdapterResult(
            upstream_id=str(data.get("id") or ""),
            text=text,
            reasoning_text=reasoning,
            finish_reason=_finish_reason(status, data.get("incomplete_details")),
            usage=usage_from_responses(data.get("usage")),
            upstream_model=str(data.get("model") or req.upstream_model),
            structured_output=structured,
            status=status,
            incomplete_reason=(data.get("incomplete_details") or {}).get("reason"),
        )

    # ------------------------------------------------------------------ 流式
    async def iter_stream(
        self, response: httpx.Response, req: NormalizedRequest
    ) -> AsyncIterator[StreamChunk]:
        text_parts: list[str] = []
        reasoning_parts: list[str] = []
        upstream_id = ""
        usage = Usage()
        completed = False
        status = "completed"
        incomplete_details: dict[str, Any] | None = None

        async for event_name, raw in iter_sse(response):
            data = sse_json(event_name, raw)
            etype = str(data.get("type") or event_name or "")

            if etype == "response.created":
                upstream_id = str((data.get("response") or {}).get("id") or upstream_id)
            elif etype == "response.output_text.delta":
                delta = data.get("delta") or ""
                if delta:
                    text_parts.append(delta)
                    yield StreamChunk("delta", text=delta)
            elif etype == "response.reasoning_text.delta":
                delta = data.get("delta") or ""
                if delta:
                    reasoning_parts.append(delta)
                    yield StreamChunk("reasoning", text=delta)
            elif etype == "response.output_text.done":
                full = data.get("text") or ""
                if full and not text_parts:
                    text_parts.append(full)
            elif etype == "response.reasoning_text.done":
                full = data.get("text") or ""
                if full and not reasoning_parts:
                    reasoning_parts.append(full)
            elif etype in ("response.completed", "response.incomplete"):
                upstream = data.get("response") or {}
                upstream_id = str(upstream.get("id") or upstream_id)
                status = str(upstream.get("status") or ("completed" if etype.endswith("completed") else "incomplete"))
                incomplete_details = upstream.get("incomplete_details")
                usage = usage_from_responses(upstream.get("usage"))
                full_text, full_reasoning = _extract_output(upstream)
                if full_text and not text_parts:
                    text_parts.append(full_text)
                if full_reasoning and not reasoning_parts:
                    reasoning_parts.append(full_reasoning)
                completed = True
            elif etype == "response.failed":
                upstream = data.get("response") or {}
                raise GatewayError(
                    "UPSTREAM_ERROR",
                    "上游流式响应失败",
                    details={"error": upstream.get("error") or data.get("error")},
                )
            elif etype == "error":
                raise GatewayError(
                    "UPSTREAM_ERROR", "上游流式响应返回 error 事件", details={"error": data}
                )

        if not completed:
            raise GatewayError(
                "STREAM_INTERRUPTED", "上游流在 response.completed 之前结束", retryable=False
            )

        text = "".join(text_parts)
        reasoning = "".join(reasoning_parts)
        structured = None
        if self.is_structured(req):
            structured = self.parse_structured_text(text, req)
            text = _json_text(structured)

        yield StreamChunk(
            "done",
            text=text,
            usage=usage,
            finish_reason=_finish_reason(status, incomplete_details),
            structured_output=structured,
            upstream_id=upstream_id,
            incomplete_reason=(incomplete_details or {}).get("reason"),
        )


def _extract_output(data: dict[str, Any]) -> tuple[str, str]:
    text_parts: list[str] = []
    reasoning_parts: list[str] = []
    for item in data.get("output") or []:
        if not isinstance(item, dict):
            continue
        item_type = item.get("type")
        for block in item.get("content") or []:
            if not isinstance(block, dict):
                continue
            block_type = block.get("type")
            if item_type == "message" and block_type in ("output_text", "text"):
                text_parts.append(str(block.get("text") or ""))
            elif item_type == "reasoning" and block_type in ("reasoning_text", "text"):
                reasoning_parts.append(str(block.get("text") or ""))
    return "".join(text_parts), "".join(reasoning_parts)


def _finish_reason(status: str, incomplete_details: dict[str, Any] | None) -> str:
    if status == "incomplete":
        reason = (incomplete_details or {}).get("reason")
        if reason == "content_filter":
            return "content_filter"
        return "length"
    if status == "completed":
        return "stop"
    return "stop"


def _json_text(value: dict[str, Any]) -> str:
    import json

    return json.dumps(value, ensure_ascii=False)
