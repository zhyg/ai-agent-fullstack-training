"""按模型独立的令牌桶限流。"""

from __future__ import annotations

import asyncio
import math
import time
from dataclasses import dataclass
from typing import Callable

from .config import RateLimitConfig


@dataclass(slots=True)
class RateLimitDecision:
    allowed: bool
    limit: int
    remaining: float
    retry_after_s: float
    reset_after_s: float

    def headers(self, retry_after_s: float | None = None) -> dict[str, str]:
        headers = {
            "X-RateLimit-Limit": str(self.limit),
            "X-RateLimit-Remaining": str(max(0, int(self.remaining))),
            "X-RateLimit-Reset": str(max(0, math.ceil(self.reset_after_s))),
        }
        wait = self.retry_after_s if retry_after_s is None else retry_after_s
        if not self.allowed:
            headers["Retry-After"] = str(max(1, math.ceil(wait)))
        return headers


class ModelRateLimiter:
    """单个模型的令牌桶；rpm=0 表示关闭限流。"""

    def __init__(
        self,
        config: RateLimitConfig,
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.config = config
        self.limit = config.requests_per_minute
        self.capacity = float(config.burst or max(1, config.requests_per_minute))
        self.rate_per_second = self.limit / 60.0 if self.limit else 0.0
        self._clock = clock
        self._tokens = self.capacity
        self._updated = clock()
        self._lock = asyncio.Lock()

    async def acquire(self) -> RateLimitDecision:
        if self.limit <= 0:
            return RateLimitDecision(True, 0, -1, 0.0, 0.0)

        async with self._lock:
            now = self._clock()
            elapsed = max(0.0, now - self._updated)
            self._tokens = min(self.capacity, self._tokens + elapsed * self.rate_per_second)
            self._updated = now

            if self._tokens >= 1.0:
                self._tokens -= 1.0
                retry_after = 0.0
                allowed = True
            else:
                allowed = False
                retry_after = (1.0 - self._tokens) / self.rate_per_second

            reset_after = (self.capacity - self._tokens) / self.rate_per_second
            return RateLimitDecision(
                allowed=allowed,
                limit=self.limit,
                remaining=self._tokens,
                retry_after_s=retry_after,
                reset_after_s=reset_after,
            )

    def reset(self) -> None:
        self._tokens = self.capacity
        self._updated = self._clock()


class RateLimiterRegistry:
    """每个模型一个独立桶，模型之间互不影响。"""

    def __init__(self, configs: dict[str, RateLimitConfig]) -> None:
        self._limiters = {name: ModelRateLimiter(cfg) for name, cfg in configs.items()}

    def get(self, model: str) -> ModelRateLimiter | None:
        return self._limiters.get(model)

    async def acquire(self, model: str) -> RateLimitDecision:
        limiter = self._limiters.get(model)
        if limiter is None:
            return RateLimitDecision(True, 0, -1, 0.0, 0.0)
        return await limiter.acquire()

    def reset(self) -> None:
        for limiter in self._limiters.values():
            limiter.reset()
