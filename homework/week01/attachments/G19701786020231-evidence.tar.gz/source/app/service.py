"""核心编排：准备请求、模板渲染、限流、重试、观测、SSE。"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass
from typing import Any, AsyncIterator

import httpx
from starlette.responses import StreamingResponse

from .adapters import build_adapter
from .adapters.base import AdapterResult, BaseAdapter, NormalizedRequest
from .config import GatewayConfig, ModelConfig
from .errors import GatewayError, from_upstream
from .observability import CallRecord, ObservabilityStore
from .ratelimit import RateLimitDecision, RateLimiterRegistry
from .retry import run_with_retry
from .schemas import ChatRequest, Message, Usage
from .templates import TemplateStore

logger = logging.getLogger("gateway.service")


@dataclass(slots=True)
class Prepared:
    request_id: str
    payload: ChatRequest
    model: str
    model_config: ModelConfig
    adapter: BaseAdapter
    normalized: NormalizedRequest
    template_meta: dict[str, Any] | None
    rate_decision: RateLimitDecision
    started_at: float
    client_ip: str | None = None


class GatewayService:
    def __init__(
        self,
        config: GatewayConfig,
        client: httpx.AsyncClient,
        templates: TemplateStore,
        observability: ObservabilityStore,
        limiters: RateLimiterRegistry,
    ) -> None:
        self.config = config
        self.client = client
        self.templates = templates
        self.observability = observability
        self.limiters = limiters
        self.adapters = {
            name: build_adapter(name, model_config, config)
            for name, model_config in config.models.items()
        }
        self._default_timeout = httpx.Timeout(
            connect=config.http.connect_timeout_s,
            read=config.http.read_timeout_s,
            write=config.http.write_timeout_s,
            pool=config.http.connect_timeout_s,
        )

    # ------------------------------------------------------------------ 准备
    async def prepare(
        self,
        payload: ChatRequest,
        request_id: str,
        *,
        client_ip: str | None = None,
        started_at: float | None = None,
    ) -> Prepared:
        started_at = started_at or time.perf_counter()
        model_config = self.config.models.get(payload.model)
        adapter: BaseAdapter | None = self.adapters.get(payload.model)
        template_meta: dict[str, Any] | None = None

        try:
            if model_config is None or adapter is None:
                raise GatewayError(
                    "MODEL_NOT_FOUND",
                    f"未知模型: {payload.model!r}",
                    details={"available_models": sorted(self.config.models)},
                )

            messages: list[Message] = list(payload.messages)
            if payload.template is not None:
                rendered = self.templates.render(
                    payload.template.name,
                    payload.template.version,
                    payload.template.variables,
                )
                prompt = rendered["rendered"]
                if not prompt.strip():
                    raise GatewayError("TEMPLATE_RENDER_ERROR", "模板渲染结果为空")
                if messages and messages[-1].role == "user":
                    # 模板作为“最后一条用户指令”拼接到现有 user 消息，避免连续 user 角色
                    messages[-1] = Message(
                        role="user", content=f"{messages[-1].content}\n\n{prompt}"
                    )
                else:
                    messages.append(Message(role="user", content=prompt))
                template_meta = {
                    "name": rendered["template"]["name"],
                    "version": rendered["template"]["version"],
                    "requested_version": rendered["template"]["requested_version"],
                    "checksum": rendered["template"]["checksum"],
                    "variables": rendered["template"]["variables"],
                    "used_variables": rendered["used_variables"],
                }

            normalized = self._normalize(payload, model_config, messages)
            adapter.validate_request(normalized)

            rate_decision = await self.limiters.acquire(payload.model)
            if not rate_decision.allowed:
                raise GatewayError(
                    "RATE_LIMITED",
                    f"模型 {payload.model!r} 触发本地限流："
                    f"{rate_decision.limit} 请求/分钟，请 {rate_decision.retry_after_s:.1f}s 后重试",
                    details={
                        "model": payload.model,
                        "limit_requests_per_minute": rate_decision.limit,
                        "retry_after_s": round(rate_decision.retry_after_s, 3),
                        "scope": "per_model",
                    },
                    headers=rate_decision.headers(),
                )

            return Prepared(
                request_id=request_id,
                payload=payload,
                model=payload.model,
                model_config=model_config,
                adapter=adapter,
                normalized=normalized,
                template_meta=template_meta,
                rate_decision=rate_decision,
                started_at=started_at,
                client_ip=client_ip,
            )
        except GatewayError as exc:
            adapter_name = adapter.adapter_name if adapter else "unknown"
            self._record_error(
                request_id=request_id,
                model=payload.model,
                adapter=adapter_name,
                stream=payload.stream,
                exc=exc,
                latency_ms=(time.perf_counter() - started_at) * 1000,
                template_meta=template_meta,
                client_ip=client_ip,
            )
            exc.recorded = True
            raise

    def _normalize(
        self, payload: ChatRequest, model_config: ModelConfig, messages: list[Message]
    ) -> NormalizedRequest:
        system_parts = [message.content for message in messages if message.role == "system"]
        conversation = [(m.role, m.content) for m in messages if m.role != "system"]
        if not conversation or not any(role == "user" for role, _ in conversation):
            raise GatewayError("INVALID_REQUEST", "至少需要一条 user 消息或 template")

        defaults = model_config.defaults
        return NormalizedRequest(
            model=payload.model,
            upstream_model=model_config.upstream_model or payload.model,
            system="\n\n".join(system_parts) if system_parts else None,
            messages=conversation,
            max_tokens=payload.max_tokens or defaults.max_tokens,
            temperature=(
                payload.temperature if payload.temperature is not None else defaults.temperature
            ),
            top_p=payload.top_p if payload.top_p is not None else defaults.top_p,
            response_format=payload.response_format,
            reasoning_effort=(
                payload.reasoning_effort
                if payload.reasoning_effort is not None
                else defaults.reasoning_effort
            ),
            metadata=payload.metadata,
        )

    # ------------------------------------------------------------------ 非流式
    async def complete(self, prepared: Prepared) -> dict[str, Any]:
        started = prepared.started_at
        retry_trace: list[dict[str, Any]] = []
        try:
            request = prepared.adapter.build_request(prepared.normalized, stream=False)

            async def operation() -> dict[str, Any]:
                response = await self._send(request, prepared, stream=False)
                try:
                    return response.json()
                except json.JSONDecodeError as exc:
                    raise GatewayError(
                        "UPSTREAM_PROTOCOL_ERROR",
                        "上游响应不是合法 JSON",
                        details={"preview": response.text[:300]},
                    ) from exc

            data, retry_trace = await run_with_retry(
                operation, self.config.retry, model=prepared.model
            )
            result = prepared.adapter.parse_response(data, prepared.normalized)
            latency_ms = (time.perf_counter() - started) * 1000
            attempts = len(retry_trace) + 1

            self._record_success(
                prepared,
                result,
                latency_ms=latency_ms,
                ttft_ms=None,
                attempts=attempts,
                retry_trace=retry_trace,
            )
            return self._response_body(prepared, result, latency_ms, attempts, retry_trace)
        except GatewayError as exc:
            if exc.attempts == 0:
                exc.attempts = len(retry_trace) + 1
            if not exc.retry_trace:
                exc.retry_trace = retry_trace
            latency_ms = (time.perf_counter() - started) * 1000
            if not exc.recorded:
                self._record_error(
                    request_id=prepared.request_id,
                    model=prepared.model,
                    adapter=prepared.adapter.adapter_name,
                    stream=False,
                    exc=exc,
                    latency_ms=latency_ms,
                    template_meta=prepared.template_meta,
                    client_ip=prepared.client_ip,
                )
                exc.recorded = True
            raise
        except Exception as exc:
            logger.exception("unexpected error model=%s", prepared.model)
            error = GatewayError("INTERNAL_ERROR", f"网关内部错误: {exc}")
            latency_ms = (time.perf_counter() - started) * 1000
            self._record_error(
                request_id=prepared.request_id,
                model=prepared.model,
                adapter=prepared.adapter.adapter_name,
                stream=False,
                exc=error,
                latency_ms=latency_ms,
                template_meta=prepared.template_meta,
                client_ip=prepared.client_ip,
            )
            error.recorded = True
            raise error from exc

    def _response_body(
        self,
        prepared: Prepared,
        result: AdapterResult,
        latency_ms: float,
        attempts: int,
        retry_trace: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return {
            "id": result.upstream_id or prepared.request_id,
            "object": "chat.completion",
            "created": int(time.time()),
            "model": prepared.model,
            "adapter": prepared.adapter.adapter_name,
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": result.text,
                        **(
                            {"reasoning": result.reasoning_text}
                            if result.reasoning_text
                            else {}
                        ),
                    },
                    "finish_reason": result.finish_reason,
                }
            ],
            "output_text": result.text,
            "structured_output": result.structured_output,
            "reasoning_text": result.reasoning_text or None,
            "usage": result.usage.model_dump(),
            "meta": {
                "request_id": prepared.request_id,
                "adapter": prepared.adapter.adapter_name,
                "protocol": prepared.adapter.protocol,
                "upstream_model": result.upstream_model,
                "latency_ms": round(latency_ms, 2),
                "ttft_ms": None,
                "attempts": attempts,
                "retries": retry_trace,
                "template": prepared.template_meta,
                "rate_limit": {
                    "limit": prepared.rate_decision.limit,
                    "remaining": max(0, int(prepared.rate_decision.remaining)),
                },
            },
        }

    # ------------------------------------------------------------------ 流式
    async def stream_response(self, prepared: Prepared) -> StreamingResponse:
        request = prepared.adapter.build_request(prepared.normalized, stream=True)

        async def operation() -> httpx.Response:
            return await self._send(request, prepared, stream=True)

        try:
            response, retry_trace = await run_with_retry(
                operation, self.config.retry, model=prepared.model
            )
        except GatewayError as exc:
            if not exc.recorded:
                self._record_error(
                    request_id=prepared.request_id,
                    model=prepared.model,
                    adapter=prepared.adapter.adapter_name,
                    stream=True,
                    exc=exc,
                    latency_ms=(time.perf_counter() - prepared.started_at) * 1000,
                    template_meta=prepared.template_meta,
                    client_ip=prepared.client_ip,
                )
                exc.recorded = True
            raise

        return StreamingResponse(
            self._stream_generator(prepared, response, retry_trace),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
                "Connection": "keep-alive",
                **prepared.rate_decision.headers(),
            },
        )

    async def _stream_generator(
        self,
        prepared: Prepared,
        response: httpx.Response,
        retry_trace: list[dict[str, Any]],
    ) -> AsyncIterator[str]:
        started = prepared.started_at
        first_token_at: float | None = None
        usage = Usage()
        finish_reason: str | None = None
        structured_output: dict[str, Any] | None = None
        upstream_id = ""
        recorded = False

        try:
            yield _sse(
                "meta",
                {
                    "request_id": prepared.request_id,
                    "model": prepared.model,
                    "adapter": prepared.adapter.adapter_name,
                    "protocol": prepared.adapter.protocol,
                    "upstream_model": prepared.normalized.upstream_model,
                    "stream": True,
                    "template": prepared.template_meta,
                },
            )

            async for chunk in prepared.adapter.iter_stream(response, prepared.normalized):
                now = time.perf_counter()
                if chunk.kind in ("delta", "reasoning"):
                    if first_token_at is None:
                        first_token_at = now
                    event = "reasoning" if chunk.kind == "reasoning" else "delta"
                    yield _sse(event, {"text": chunk.text})
                elif chunk.kind == "done":
                    usage = chunk.usage or usage
                    finish_reason = chunk.finish_reason
                    structured_output = chunk.structured_output
                    upstream_id = chunk.upstream_id or upstream_id

            latency_ms = (time.perf_counter() - started) * 1000
            ttft_ms = (first_token_at - started) * 1000 if first_token_at else None
            attempts = len(retry_trace) + 1

            done_payload = {
                "id": upstream_id or prepared.request_id,
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": prepared.model,
                "adapter": prepared.adapter.adapter_name,
                "finish_reason": finish_reason or "stop",
                "usage": usage.model_dump(),
                "structured_output": structured_output,
                "meta": {
                    "request_id": prepared.request_id,
                    "adapter": prepared.adapter.adapter_name,
                    "protocol": prepared.adapter.protocol,
                    "upstream_model": prepared.normalized.upstream_model,
                    "latency_ms": round(latency_ms, 2),
                    "ttft_ms": None if ttft_ms is None else round(ttft_ms, 2),
                    "attempts": attempts,
                    "retries": retry_trace,
                    "template": prepared.template_meta,
                    "rate_limit": {
                        "limit": prepared.rate_decision.limit,
                        "remaining": max(0, int(prepared.rate_decision.remaining)),
                    },
                },
            }
            self._record_success(
                prepared,
                AdapterResult(
                    upstream_id=upstream_id,
                    text="",
                    reasoning_text="",
                    finish_reason=finish_reason or "stop",
                    usage=usage,
                    upstream_model=prepared.normalized.upstream_model,
                    structured_output=structured_output,
                ),
                latency_ms=latency_ms,
                ttft_ms=ttft_ms,
                attempts=attempts,
                retry_trace=retry_trace,
            )
            recorded = True
            yield _sse("done", done_payload)
        except asyncio.CancelledError:
            latency_ms = (time.perf_counter() - started) * 1000
            ttft_ms = (first_token_at - started) * 1000 if first_token_at else None
            self._record_cancelled(prepared, latency_ms, ttft_ms, retry_trace)
            recorded = True
            raise
        except GatewayError as exc:
            if exc.attempts == 0:
                exc.attempts = len(retry_trace) + 1
            if not exc.retry_trace:
                exc.retry_trace = retry_trace
            latency_ms = (time.perf_counter() - started) * 1000
            ttft_ms = (first_token_at - started) * 1000 if first_token_at else None
            if not exc.recorded:
                self._record_error(
                    request_id=prepared.request_id,
                    model=prepared.model,
                    adapter=prepared.adapter.adapter_name,
                    stream=True,
                    exc=exc,
                    latency_ms=latency_ms,
                    template_meta=prepared.template_meta,
                    client_ip=prepared.client_ip,
                    http_status=200,
                    ttft_ms=ttft_ms,
                    attempts=exc.attempts or len(retry_trace) + 1,
                    retry_trace=exc.retry_trace or retry_trace,
                )
                exc.recorded = True
            recorded = True
            yield _sse("error", exc.envelope(prepared.request_id))
        except Exception as exc:  # pragma: no cover - 防御性兜底
            logger.exception("stream failed model=%s", prepared.model)
            latency_ms = (time.perf_counter() - started) * 1000
            error = GatewayError("STREAM_INTERRUPTED", f"流式响应中断: {exc}")
            self._record_error(
                request_id=prepared.request_id,
                model=prepared.model,
                adapter=prepared.adapter.adapter_name,
                stream=True,
                exc=error,
                latency_ms=latency_ms,
                template_meta=prepared.template_meta,
                client_ip=prepared.client_ip,
                http_status=200,
                ttft_ms=(first_token_at - started) * 1000 if first_token_at else None,
                attempts=len(retry_trace) + 1,
                retry_trace=retry_trace,
            )
            recorded = True
            yield _sse("error", error.envelope(prepared.request_id))
        finally:
            await response.aclose()
            if not recorded:
                latency_ms = (time.perf_counter() - started) * 1000
                self._record_cancelled(prepared, latency_ms, None, retry_trace)

    # ------------------------------------------------------------------ HTTP
    async def _send(
        self, request: httpx.Request, prepared: Prepared, *, stream: bool
    ) -> httpx.Response:
        timeout = self._timeout_for(prepared.model_config)
        request.extensions["timeout"] = {
            "connect": timeout.connect,
            "read": timeout.read,
            "write": timeout.write,
            "pool": timeout.pool,
        }
        try:
            response = await self.client.send(request, stream=stream)
        except httpx.TimeoutException as exc:
            raise GatewayError(
                "UPSTREAM_TIMEOUT",
                f"上游请求超时: {exc.__class__.__name__}",
                details={"model": prepared.model},
            ) from exc
        except (httpx.ConnectError, httpx.NetworkError, httpx.RemoteProtocolError) as exc:
            raise GatewayError(
                "UPSTREAM_UNAVAILABLE",
                f"无法连接上游: {exc.__class__.__name__}: {exc}",
                details={"model": prepared.model},
            ) from exc
        except httpx.HTTPError as exc:
            raise GatewayError(
                "UPSTREAM_UNAVAILABLE",
                f"上游 HTTP 客户端错误: {exc.__class__.__name__}: {exc}",
                details={"model": prepared.model},
            ) from exc

        if response.status_code >= 400:
            try:
                body = await response.aread()
            except httpx.HTTPError:
                body = b""
            headers = {key.lower(): value for key, value in response.headers.items()}
            await response.aclose()
            raise from_upstream(
                response.status_code, body, headers, model=prepared.model
            )

        return response

    def _timeout_for(self, model_config: ModelConfig) -> httpx.Timeout:
        if model_config.timeout_s is None:
            return self._default_timeout
        return httpx.Timeout(
            connect=self.config.http.connect_timeout_s,
            read=model_config.timeout_s,
            write=self.config.http.write_timeout_s,
            pool=self.config.http.connect_timeout_s,
        )

    # ------------------------------------------------------------------ 记录
    def _record_success(
        self,
        prepared: Prepared,
        result: AdapterResult,
        *,
        latency_ms: float,
        ttft_ms: float | None,
        attempts: int,
        retry_trace: list[dict[str, Any]],
    ) -> None:
        record = CallRecord(
            request_id=prepared.request_id,
            model=prepared.model,
            adapter=prepared.adapter.adapter_name,
            stream=prepared.payload.stream,
            status="success",
            http_status=200,
            input_tokens=result.usage.input_tokens,
            output_tokens=result.usage.output_tokens,
            total_tokens=result.usage.total_tokens,
            cached_input_tokens=result.usage.cached_input_tokens,
            cache_write_input_tokens=result.usage.cache_write_input_tokens,
            cache_read_input_tokens=result.usage.cache_read_input_tokens,
            reasoning_tokens=result.usage.reasoning_tokens,
            visible_output_tokens=result.usage.visible_output_tokens,
            latency_ms=latency_ms,
            ttft_ms=ttft_ms,
            attempts=attempts,
            finish_reason=result.finish_reason,
            template_name=prepared.template_meta["name"] if prepared.template_meta else None,
            template_version=prepared.template_meta["version"] if prepared.template_meta else None,
            retry_trace=retry_trace,
            client_ip=prepared.client_ip,
        )
        self.observability.record(record)
        self._log_call(record)

    def _record_error(
        self,
        *,
        request_id: str,
        model: str,
        adapter: str,
        stream: bool,
        exc: GatewayError,
        latency_ms: float,
        template_meta: dict[str, Any] | None,
        client_ip: str | None,
        http_status: int | None = None,
        ttft_ms: float | None = None,
        attempts: int | None = None,
        retry_trace: list[dict[str, Any]] | None = None,
    ) -> None:
        record = CallRecord(
            request_id=request_id,
            model=model,
            adapter=adapter,
            stream=stream,
            status="error",
            http_status=http_status if http_status is not None else exc.http_status,
            error_code=exc.code,
            latency_ms=latency_ms,
            ttft_ms=ttft_ms,
            attempts=exc.attempts if attempts is None else attempts,
            finish_reason=None,
            template_name=template_meta["name"] if template_meta else None,
            template_version=template_meta["version"] if template_meta else None,
            retry_trace=retry_trace if retry_trace is not None else exc.retry_trace,
            client_ip=client_ip,
        )
        self.observability.record(record)
        self._log_call(record)

    def _record_cancelled(
        self,
        prepared: Prepared,
        latency_ms: float,
        ttft_ms: float | None,
        retry_trace: list[dict[str, Any]],
    ) -> None:
        record = CallRecord(
            request_id=prepared.request_id,
            model=prepared.model,
            adapter=prepared.adapter.adapter_name,
            stream=True,
            status="cancelled",
            http_status=200,
            error_code="CLIENT_DISCONNECTED",
            latency_ms=latency_ms,
            ttft_ms=ttft_ms,
            attempts=len(retry_trace) + 1,
            template_name=prepared.template_meta["name"] if prepared.template_meta else None,
            template_version=prepared.template_meta["version"] if prepared.template_meta else None,
            retry_trace=retry_trace,
            client_ip=prepared.client_ip,
        )
        self.observability.record(record)
        self._log_call(record)

    @staticmethod
    def _log_call(record: CallRecord) -> None:
        logger.info(
            "call request_id=%s model=%s adapter=%s stream=%s status=%s code=%s "
            "tokens=%d/%d/%d reasoning=%d latency_ms=%s ttft_ms=%s attempts=%d",
            record.request_id,
            record.model,
            record.adapter,
            record.stream,
            record.status,
            record.error_code,
            record.input_tokens,
            record.output_tokens,
            record.total_tokens,
            record.reasoning_tokens,
            None if record.latency_ms is None else round(record.latency_ms, 1),
            None if record.ttft_ms is None else round(record.ttft_ms, 1),
            record.attempts,
        )

    # ------------------------------------------------------------------ 其他
    def list_models(self) -> list[dict[str, Any]]:
        items = []
        for name, config in self.config.models.items():
            adapter = self.adapters[name]
            items.append(
                {
                    "id": name,
                    "object": "model",
                    "adapter": config.adapter,
                    "protocol": adapter.protocol,
                    "upstream_model": config.upstream_model,
                    "rate_limit": {
                        "requests_per_minute": config.rate_limit.requests_per_minute,
                        "burst": config.rate_limit.burst,
                    },
                    "defaults": config.defaults.model_dump(),
                }
            )
        return items

    def ready(self) -> dict[str, Any]:
        return {
            "status": "ready",
            "models": len(self.config.models),
            "adapters": sorted({cfg.adapter for cfg in self.config.models.values()}),
            "database": str(self.config.storage.db_path),
        }


def _sse(event: str, payload: dict[str, Any]) -> str:
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    return f"event: {event}\ndata: {data}\n\n"
