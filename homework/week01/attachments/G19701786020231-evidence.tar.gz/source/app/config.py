"""配置加载：YAML + 环境变量插值 + 启动期校验。"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Literal
from urllib.parse import urlparse

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

EnvName = str
AdapterName = Literal["openai_responses", "anthropic_messages"]
Effort = Literal["none", "low", "high", "max"]

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class ConfigError(RuntimeError):
    """配置文件或环境变量不合法。"""


class RateLimitConfig(BaseModel):
    """按模型独立的令牌桶配置。requests_per_minute=0 表示不限流。"""

    model_config = ConfigDict(extra="forbid")

    requests_per_minute: int = Field(default=60, ge=0, le=100_000)
    burst: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def _default_burst(self) -> "RateLimitConfig":
        if self.burst is None:
            self.burst = max(1, self.requests_per_minute)
        return self


class DefaultsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max_tokens: int = Field(default=1024, ge=1, le=131_072)
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    top_p: float | None = Field(default=None, ge=0.0, le=1.0)
    reasoning_effort: Effort | None = None


class ModelConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    adapter: AdapterName
    base_url: str
    path: str | None = None
    upstream_model: str | None = None
    api_key_env: EnvName | None = None
    api_key: str | None = Field(default=None, repr=False)
    anthropic_version: str = "2023-06-01"
    timeout_s: float | None = Field(default=None, gt=0)
    headers: dict[str, str] = Field(default_factory=dict)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)
    defaults: DefaultsConfig = Field(default_factory=DefaultsConfig)

    @field_validator("base_url")
    @classmethod
    def _valid_base_url(cls, value: str) -> str:
        parsed = urlparse(value)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError(f"base_url 必须是 http(s) URL，收到: {value!r}")
        return value.rstrip("/")

    @model_validator(mode="after")
    def _fill_defaults(self) -> "ModelConfig":
        if self.path is None:
            self.path = "/responses" if self.adapter == "openai_responses" else "/v1/messages"
        if not self.path.startswith("/"):
            self.path = "/" + self.path
        if self.upstream_model is None:
            self.upstream_model = ""
        if not self.api_key and not self.api_key_env:
            raise ValueError("必须配置 api_key_env（推荐）或 api_key")
        return self

    @property
    def url(self) -> str:
        return f"{self.base_url}{self.path}"

    def resolve_api_key(self) -> str:
        if self.api_key_env:
            value = os.environ.get(self.api_key_env, "").strip()
            if not value:
                raise ConfigError(
                    f"模型 {self.upstream_model or self.url} 需要环境变量 {self.api_key_env}，"
                    "但当前为空；请写入 .env 或进程环境。"
                )
            return value
        assert self.api_key is not None
        return self.api_key


class RetryConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max_attempts: int = Field(default=3, ge=1, le=10)
    base_delay_s: float = Field(default=0.5, ge=0, le=30)
    max_delay_s: float = Field(default=8.0, ge=0, le=120)
    jitter_s: float = Field(default=0.2, ge=0, le=5)

    @model_validator(mode="after")
    def _check_delay(self) -> "RetryConfig":
        if self.max_delay_s < self.base_delay_s:
            raise ValueError("retry.max_delay_s 不能小于 retry.base_delay_s")
        return self


class HttpConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    connect_timeout_s: float = Field(default=15.0, gt=0)
    read_timeout_s: float = Field(default=300.0, gt=0)
    write_timeout_s: float = Field(default=30.0, gt=0)


class StorageConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    db_path: Path = Path("data/gateway.db")
    log_path: Path = Path("data/gateway.log")


class ServerConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    host: str = "127.0.0.1"
    port: int = Field(default=8000, ge=1, le=65535)


class GatewayConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    server: ServerConfig = Field(default_factory=ServerConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    http: HttpConfig = Field(default_factory=HttpConfig)
    retry: RetryConfig = Field(default_factory=RetryConfig)
    models: dict[str, ModelConfig] = Field(min_length=1)

    config_path: Path | None = Field(default=None, exclude=True)

    @model_validator(mode="after")
    def _complete_models(self) -> "GatewayConfig":
        for name, model in self.models.items():
            if not model.upstream_model:
                # 默认把网关对外模型名透传给上游
                model.upstream_model = name
        return self

    @property
    def config_dir(self) -> Path:
        return self.config_path.parent if self.config_path else Path.cwd()

    def validate_runtime(self) -> None:
        """启动期检查所有模型凭据，避免首个请求才暴露配置错误。"""
        for name, model in self.models.items():
            try:
                model.resolve_api_key()
            except ConfigError as exc:
                raise ConfigError(f"模型 {name!r} 配置错误: {exc}") from exc


def _expand_env(value: Any, missing: set[str]) -> Any:
    if isinstance(value, str):
        def replace(match: re.Match[str]) -> str:
            name = match.group(1)
            env_value = os.environ.get(name)
            if env_value is None:
                missing.add(name)
                return match.group(0)
            return env_value

        return _ENV_PATTERN.sub(replace, value)
    if isinstance(value, list):
        return [_expand_env(item, missing) for item in value]
    if isinstance(value, dict):
        return {key: _expand_env(item, missing) for key, item in value.items()}
    return value


def load_config(path: str | Path | None = None) -> GatewayConfig:
    """加载配置；先读同目录 .env，再展开 ${VAR}，最后做 Pydantic 校验。"""
    config_path = Path(path or os.environ.get("GATEWAY_CONFIG", "config.yaml")).resolve()
    if not config_path.is_file():
        raise ConfigError(f"找不到配置文件: {config_path}")

    load_dotenv(config_path.parent / ".env", override=False)
    load_dotenv(override=False)

    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ConfigError(f"YAML 解析失败: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError("配置文件根节点必须是对象")

    missing: set[str] = set()
    expanded = _expand_env(raw, missing)
    if missing:
        names = ", ".join(sorted(missing))
        raise ConfigError(f"配置引用了未定义的环境变量: {names}")

    try:
        config = GatewayConfig.model_validate(expanded)
    except Exception as exc:  # pydantic.ValidationError
        raise ConfigError(f"配置校验失败: {exc}") from exc

    config.config_path = config_path
    config.storage.db_path = _resolve_path(config.storage.db_path, config_path.parent)
    config.storage.log_path = _resolve_path(config.storage.log_path, config_path.parent)

    if os.environ.get("GATEWAY_HOST"):
        config.server.host = os.environ["GATEWAY_HOST"]
    if os.environ.get("GATEWAY_PORT"):
        try:
            config.server.port = int(os.environ["GATEWAY_PORT"])
        except ValueError as exc:
            raise ConfigError("GATEWAY_PORT 必须是整数") from exc

    config.validate_runtime()
    return config


def _resolve_path(value: Path, base: Path) -> Path:
    return value if value.is_absolute() else (base / value).resolve()
