"""统一错误码与错误信封。"""

from __future__ import annotations

import email.utils
import json
from datetime import datetime, timezone
from typing import Any

ERROR_SPECS: dict[str, tuple[int, str, bool]] = {
    # code: (http_status, error_type, retryable)
    "INVALID_REQUEST": (400, "invalid_request_error", False),
    "UNAUTHORIZED": (401, "authentication_error", False),
    "FORBIDDEN": (403, "permission_error", False),
    "NOT_FOUND": (404, "not_found_error", False),
    "MODEL_NOT_FOUND": (404, "model_not_found_error", False),
    "TEMPLATE_NOT_FOUND": (404, "template_not_found_error", False),
    "TEMPLATE_VERSION_NOT_FOUND": (404, "template_version_not_found_error", False),
    "TEMPLATE_CONFLICT": (409, "template_conflict_error", False),
    "TEMPLATE_VARIABLE_MISSING": (422, "template_variable_missing_error", False),
    "TEMPLATE_RENDER_ERROR": (422, "template_render_error", False),
    "TEMPLATE_SYNTAX_ERROR": (422, "template_syntax_error", False),
    "RATE_LIMITED": (429, "rate_limit_error", True),
    "UPSTREAM_ERROR": (502, "upstream_error", True),
    "UPSTREAM_AUTH_ERROR": (502, "upstream_auth_error", False),
    "UPSTREAM_PROTOCOL_ERROR": (502, "upstream_protocol_error", False),
    "STRUCTURED_OUTPUT_INVALID": (502, "structured_output_invalid_error", False),
    "STREAM_INTERRUPTED": (502, "stream_interrupted_error", False),
    "UPSTREAM_UNAVAILABLE": (503, "upstream_unavailable_error", True),
    "UPSTREAM_TIMEOUT": (504, "upstream_timeout_error", True),
    "INTERNAL_ERROR": (500, "internal_error", False),
    "METHOD_NOT_ALLOWED": (405, "method_not_allowed_error", False),
}


class GatewayError(Exception):
    """所有对外错误都收敛为该类型。"""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        http_status: int | None = None,
        retryable: bool | None = None,
        details: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        if code not in ERROR_SPECS:
            code = "INTERNAL_ERROR"
        spec_status, error_type, spec_retryable = ERROR_SPECS[code]
        super().__init__(message)
        self.code = code
        self.message = message
        self.error_type = error_type
        self.http_status = http_status if http_status is not None else spec_status
        self.retryable = spec_retryable if retryable is None else retryable
        self.details = details or {}
        self.headers = headers or {}
        self.attempts = 0
        self.retry_trace: list[dict[str, Any]] = []
        self.upstream_status: int | None = None
        self.recorded = False

    def envelope(self, request_id: str | None) -> dict[str, Any]:
        details = dict(self.details)
        if self.attempts:
            details.setdefault("attempts", self.attempts)
        if self.retry_trace:
            details.setdefault("retry_trace", self.retry_trace)
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "type": self.error_type,
                "retryable": self.retryable,
                "details": details,
                "request_id": request_id,
            }
        }


def invalid_request(message: str, **details: Any) -> GatewayError:
    return GatewayError("INVALID_REQUEST", message, details=details)


def parse_retry_after(value: str | None) -> float | None:
    """解析 Retry-After：秒数或 HTTP 日期。"""
    if not value:
        return None
    value = value.strip()
    try:
        seconds = float(value)
        return max(0.0, seconds)
    except ValueError:
        pass
    try:
        when = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return max(0.0, (when - datetime.now(timezone.utc)).total_seconds())


def _extract_message(body: Any) -> str:
    if isinstance(body, bytes):
        try:
            body = body.decode("utf-8", errors="replace")
        except Exception:
            return ""
    if isinstance(body, str):
        text = body.strip()
        try:
            body = json.loads(text)
        except json.JSONDecodeError:
            return text[:800]
    if isinstance(body, dict):
        error = body.get("error")
        if isinstance(error, dict):
            for key in ("message", "detail", "error"):
                if error.get(key):
                    return str(error[key])[:800]
            return json.dumps(error, ensure_ascii=False)[:800]
        for key in ("message", "detail", "error"):
            if body.get(key):
                return str(body[key])[:800]
        return json.dumps(body, ensure_ascii=False)[:800]
    return str(body)[:800]


def from_upstream(
    status: int,
    body: Any,
    headers: dict[str, str] | None = None,
    *,
    model: str | None = None,
) -> GatewayError:
    """把上游 HTTP 错误映射为统一错误码。"""
    message = _extract_message(body) or f"上游返回 HTTP {status}"
    headers = headers or {}
    retry_after = parse_retry_after(headers.get("retry-after"))
    details: dict[str, Any] = {"upstream_status": status, "upstream_message": message}
    if model:
        details["model"] = model
    if retry_after is not None:
        details["upstream_retry_after_s"] = round(retry_after, 3)

    if status == 400:
        error = GatewayError("INVALID_REQUEST", f"上游拒绝了请求: {message}", details=details)
    elif status == 422:
        error = GatewayError(
            "INVALID_REQUEST", f"上游无法处理该请求: {message}", http_status=422, details=details
        )
    elif status in (401, 403):
        error = GatewayError(
            "UPSTREAM_AUTH_ERROR", f"上游鉴权失败（请检查 API Key）: {message}", details=details
        )
    elif status == 404:
        error = GatewayError("MODEL_NOT_FOUND", f"上游找不到模型或路径: {message}", details=details)
    elif status == 429:
        error = GatewayError("RATE_LIMITED", f"上游限流: {message}", details=details)
    elif status >= 500:
        error = GatewayError("UPSTREAM_ERROR", f"上游服务异常: {message}", details=details)
    else:
        error = GatewayError("UPSTREAM_ERROR", f"上游返回 HTTP {status}: {message}", details=details)

    error.upstream_status = status
    error.headers = {"Retry-After": str(int(retry_after) + 1)} if retry_after is not None else {}
    return error
