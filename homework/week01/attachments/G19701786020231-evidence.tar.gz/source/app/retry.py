"""指数退避重试。"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import Any, Awaitable, Callable, TypeVar

from .config import RetryConfig
from .errors import GatewayError

T = TypeVar("T")
logger = logging.getLogger("gateway.retry")


async def run_with_retry(
    operation: Callable[[], Awaitable[T]],
    policy: RetryConfig,
    *,
    model: str,
    sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
) -> tuple[T, list[dict[str, Any]]]:
    """执行 operation；只对 retryable 的 GatewayError 做指数退避重试。

    返回 (结果, 重试轨迹)。最终失败时把 attempts / retry_trace 挂到异常上。
    """
    trace: list[dict[str, Any]] = []
    last_error: GatewayError | None = None

    for attempt in range(1, policy.max_attempts + 1):
        try:
            result = await operation()
            return result, trace
        except GatewayError as exc:
            last_error = exc
            exc.attempts = attempt
            exc.retry_trace = list(trace)
            if not exc.retryable or attempt >= policy.max_attempts:
                raise

            upstream_wait = exc.details.get("upstream_retry_after_s")
            if isinstance(upstream_wait, (int, float)) and upstream_wait > 0:
                delay = min(float(upstream_wait), 60.0)
            else:
                backoff = policy.base_delay_s * (2 ** (attempt - 1))
                delay = min(backoff, policy.max_delay_s)
                if policy.jitter_s:
                    delay += random.uniform(0, policy.jitter_s)

            trace.append(
                {
                    "attempt": attempt,
                    "delay_ms": round(delay * 1000, 1),
                    "error_code": exc.code,
                    "http_status": exc.upstream_status,
                }
            )
            logger.warning(
                "retry model=%s attempt=%d/%d code=%s delay_ms=%.1f",
                model,
                attempt,
                policy.max_attempts,
                exc.code,
                delay * 1000,
            )
            await sleep(delay)

    assert last_error is not None  # pragma: no cover
    raise last_error
