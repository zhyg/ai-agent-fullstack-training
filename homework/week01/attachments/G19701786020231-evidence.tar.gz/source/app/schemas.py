"""对外 API 的请求模型。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Role = Literal["system", "user", "assistant"]
Effort = Literal["none", "low", "high", "max"]

_NAME_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$"
_VAR_PATTERN = r"^[A-Za-z_][A-Za-z0-9_]*$"


class Message(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={"example": {"role": "user", "content": "用一句话解释什么是 SSE"}},
    )

    role: Role
    content: str = Field(min_length=1)


class Usage(BaseModel):
    """统一 Token 口径。

    - input_tokens: 总输入（Anthropic 已把 cache_write/cache_read 加回）
    - cached_input_tokens: 命中缓存的输入（Responses 的 cached_tokens；
      Messages 的 cache_read_input_tokens）
    - cache_write_input_tokens: 写入缓存的输入（仅 Messages）
    - reasoning_tokens: 思维链 token（Responses 的 reasoning_tokens；
      Messages 的 thinking_tokens）
    - visible_output_tokens: output_tokens - reasoning_tokens
    """

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    cached_input_tokens: int = 0
    cache_write_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    reasoning_tokens: int = 0
    visible_output_tokens: int = 0


class TemplateRef(BaseModel):
    """对话请求内联引用模板：name + version + variables。"""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(pattern=_NAME_PATTERN)
    version: int | Literal["latest"] = "latest"
    variables: dict[str, Any] = Field(default_factory=dict)

    @field_validator("version")
    @classmethod
    def _check_version(cls, value: int | str) -> int | str:
        if isinstance(value, int) and value < 1:
            raise ValueError("version 必须 >= 1 或为 'latest'")
        if isinstance(value, str) and value != "latest":
            raise ValueError("version 必须是整数或 'latest'")
        return value


class JsonSchemaSpec(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    name: str = Field(default="output", pattern=r"^[A-Za-z0-9_-]{1,64}$")
    schema_definition: dict[str, Any] = Field(alias="schema", serialization_alias="schema")
    strict: bool = True

    @field_validator("schema_definition")
    @classmethod
    def _check_schema(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(value, dict) or not value:
            raise ValueError("json_schema.schema 必须是非空 JSON Schema 对象")
        return value


class ResponseFormat(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["text", "json_object", "json_schema"] = "text"
    json_schema: JsonSchemaSpec | None = None

    @model_validator(mode="after")
    def _check(self) -> "ResponseFormat":
        if self.type == "json_schema" and self.json_schema is None:
            raise ValueError("response_format.type=json_schema 时必须提供 json_schema")
        if self.type != "json_schema" and self.json_schema is not None:
            raise ValueError("只有 response_format.type=json_schema 才能提供 json_schema")
        return self


class ChatRequest(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "model": "deepseek-v4-pro",
                "messages": [{"role": "user", "content": "用一句话解释什么是 SSE"}],
                "stream": False,
                "response_format": {"type": "text"},
                "max_tokens": 512,
            }
        },
    )

    model: str = Field(min_length=1, description="网关模型名，见 GET /v1/models")
    messages: list[Message] = Field(default_factory=list, max_length=200)
    template: TemplateRef | None = None
    stream: bool = False
    max_tokens: int | None = Field(default=None, ge=1, le=131_072)
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    top_p: float | None = Field(default=None, ge=0.0, le=1.0)
    response_format: ResponseFormat | None = None
    reasoning_effort: Effort | None = Field(
        default=None,
        description="none/low/high/max。Responses 映射为 reasoning.effort；"
        "Messages 的 none 会关闭 thinking。",
    )
    metadata: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_content(self) -> "ChatRequest":
        if not self.messages and self.template is None:
            raise ValueError("messages 与 template 至少提供一个")
        if self.template is None and not any(m.role == "user" for m in self.messages):
            raise ValueError("messages 中至少需要一条 user 消息")
        return self


class TemplateVariable(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(pattern=_VAR_PATTERN)
    required: bool = True
    default: Any = None
    description: str = ""


class TemplateCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(pattern=_NAME_PATTERN)
    description: str = ""
    content: str = Field(min_length=1)
    variables: list[TemplateVariable] = Field(default_factory=list)

    @field_validator("variables")
    @classmethod
    def _unique_variables(cls, value: list[TemplateVariable]) -> list[TemplateVariable]:
        names = [item.name for item in value]
        if len(names) != len(set(names)):
            raise ValueError("variables 中变量名不能重复")
        return value


class TemplateVersionCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1)
    variables: list[TemplateVariable] | None = None


class TemplateRenderRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: int | Literal["latest"] = "latest"
    variables: dict[str, Any] = Field(default_factory=dict)

    @field_validator("version")
    @classmethod
    def _check_version(cls, value: int | str) -> int | str:
        if isinstance(value, int) and value < 1:
            raise ValueError("version 必须 >= 1 或为 'latest'")
        if isinstance(value, str) and value != "latest":
            raise ValueError("version 必须是整数或 'latest'")
        return value
