"""调用观测：SQLite 持久化 + 聚合统计。"""

from __future__ import annotations

import json
import math
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

_TOKEN_FIELDS = (
    "input_tokens",
    "output_tokens",
    "total_tokens",
    "cached_input_tokens",
    "cache_write_input_tokens",
    "cache_read_input_tokens",
    "reasoning_tokens",
    "visible_output_tokens",
)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_utc(value: datetime | None = None) -> str:
    value = value or utc_now()
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


@dataclass(slots=True)
class CallRecord:
    request_id: str
    model: str
    adapter: str
    stream: bool
    status: str
    http_status: int | None = None
    error_code: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    cached_input_tokens: int = 0
    cache_write_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    reasoning_tokens: int = 0
    visible_output_tokens: int = 0
    latency_ms: float | None = None
    ttft_ms: float | None = None
    attempts: int = 0
    finish_reason: str | None = None
    template_name: str | None = None
    template_version: int | None = None
    retry_trace: list[dict[str, Any]] = field(default_factory=list)
    client_ip: str | None = None
    created_at: str = field(default_factory=iso_utc)


class ObservabilityStore:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._create_schema()

    def _create_schema(self) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS calls (
                    request_id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    model TEXT NOT NULL,
                    adapter TEXT NOT NULL,
                    stream INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    http_status INTEGER,
                    error_code TEXT,
                    input_tokens INTEGER NOT NULL DEFAULT 0,
                    output_tokens INTEGER NOT NULL DEFAULT 0,
                    total_tokens INTEGER NOT NULL DEFAULT 0,
                    cached_input_tokens INTEGER NOT NULL DEFAULT 0,
                    cache_write_input_tokens INTEGER NOT NULL DEFAULT 0,
                    cache_read_input_tokens INTEGER NOT NULL DEFAULT 0,
                    reasoning_tokens INTEGER NOT NULL DEFAULT 0,
                    visible_output_tokens INTEGER NOT NULL DEFAULT 0,
                    latency_ms REAL,
                    ttft_ms REAL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    finish_reason TEXT,
                    template_name TEXT,
                    template_version INTEGER,
                    retry_trace TEXT,
                    client_ip TEXT
                )
                """
            )
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_calls_created_at ON calls(created_at)"
            )
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_calls_model ON calls(model)")

    def record(self, record: CallRecord) -> None:
        values = {
            "request_id": record.request_id,
            "created_at": record.created_at,
            "model": record.model,
            "adapter": record.adapter,
            "stream": 1 if record.stream else 0,
            "status": record.status,
            "http_status": record.http_status,
            "error_code": record.error_code,
            **{name: int(getattr(record, name) or 0) for name in _TOKEN_FIELDS},
            "latency_ms": None if record.latency_ms is None else round(record.latency_ms, 3),
            "ttft_ms": None if record.ttft_ms is None else round(record.ttft_ms, 3),
            "attempts": record.attempts,
            "finish_reason": record.finish_reason,
            "template_name": record.template_name,
            "template_version": record.template_version,
            "retry_trace": json.dumps(record.retry_trace, ensure_ascii=False),
            "client_ip": record.client_ip,
        }
        columns = ", ".join(values)
        placeholders = ", ".join(f":{key}" for key in values)
        with self._lock, self._conn:
            self._conn.execute(
                f"INSERT OR REPLACE INTO calls ({columns}) VALUES ({placeholders})", values
            )

    def get_call(self, request_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM calls WHERE request_id = ?", (request_id,)
            ).fetchone()
        return self._row_to_dict(row) if row else None

    def list_calls(
        self,
        *,
        limit: int = 50,
        model: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if model:
            clauses.append("model = ?")
            params.append(model)
        if status:
            clauses.append("status = ?")
            params.append(status)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        with self._lock:
            rows = self._conn.execute(
                f"SELECT * FROM calls {where} ORDER BY created_at DESC, rowid DESC LIMIT ?",
                params,
            ).fetchall()
        return [self._row_to_dict(row) for row in rows]

    def summary(self, window_minutes: int = 60) -> dict[str, Any]:
        since = iso_utc(utc_now() - timedelta(minutes=window_minutes))
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM calls WHERE created_at >= ?", (since,)
            ).fetchall()
        records = [dict(row) for row in rows]
        return {
            "window_minutes": window_minutes,
            "since": since,
            "generated_at": iso_utc(),
            "totals": _aggregate(records),
            "by_model": _group(records, "model"),
            "by_adapter": _group(records, "adapter"),
        }

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
        data = dict(row)
        data["stream"] = bool(data["stream"])
        try:
            data["retry_trace"] = json.loads(data["retry_trace"] or "[]")
        except json.JSONDecodeError:
            data["retry_trace"] = []
        return data


def _group(records: list[dict[str, Any]], key: str) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        grouped.setdefault(str(record.get(key)), []).append(record)
    return {name: _aggregate(items) for name, items in sorted(grouped.items())}


def _aggregate(records: list[dict[str, Any]]) -> dict[str, Any]:
    calls = len(records)
    success = sum(1 for row in records if row["status"] == "success")
    cancelled = sum(1 for row in records if row["status"] == "cancelled")
    rate_limited = sum(1 for row in records if row.get("error_code") == "RATE_LIMITED")
    tokens = {name: sum(int(row.get(name) or 0) for row in records) for name in _TOKEN_FIELDS}
    latencies = [float(row["latency_ms"]) for row in records if row.get("latency_ms") is not None]
    ttfts = [float(row["ttft_ms"]) for row in records if row.get("ttft_ms") is not None]
    retries = sum(max(0, int(row.get("attempts") or 0) - 1) for row in records)
    return {
        "calls": calls,
        "success": success,
        "errors": calls - success,
        "cancelled": cancelled,
        "rate_limited": rate_limited,
        **tokens,
        "avg_latency_ms": _avg(latencies),
        "p95_latency_ms": _p95(latencies),
        "avg_ttft_ms": _avg(ttfts),
        "p95_ttft_ms": _p95(ttfts),
        "total_retries": retries,
    }


def _avg(values: list[float]) -> float | None:
    if not values:
        return None
    return round(sum(values) / len(values), 2)


def _p95(values: list[float]) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, math.ceil(0.95 * len(ordered)) - 1)
    return round(ordered[index], 2)
