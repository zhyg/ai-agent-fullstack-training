"""提示词模板：持久化、不可变版本、Jinja2 变量渲染。"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import threading
from pathlib import Path
from typing import Any

from jinja2 import StrictUndefined, TemplateSyntaxError, UndefinedError, meta
from jinja2.sandbox import SandboxedEnvironment

from .errors import GatewayError

_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


def _checksum(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]


class TemplateStore:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self.env = SandboxedEnvironment(
            undefined=StrictUndefined,
            autoescape=False,
            keep_trailing_newline=True,
        )
        self._create_schema()

    def _create_schema(self) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS templates (
                    name TEXT PRIMARY KEY,
                    description TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS template_versions (
                    name TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    variables TEXT NOT NULL DEFAULT '[]',
                    checksum TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY (name, version),
                    FOREIGN KEY (name) REFERENCES templates(name) ON DELETE CASCADE
                )
                """
            )

    # ------------------------------------------------------------------ 写入
    def create(
        self,
        name: str,
        content: str,
        *,
        description: str = "",
        variables: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        if not _NAME_RE.match(name):
            raise GatewayError("INVALID_REQUEST", f"非法模板名: {name!r}")
        self._validate_content(content)
        variables = variables or []
        self._validate_variables(variables)

        from .observability import iso_utc

        now = iso_utc()
        try:
            with self._lock, self._conn:
                self._conn.execute(
                    "INSERT INTO templates(name, description, created_at, updated_at) VALUES (?,?,?,?)",
                    (name, description, now, now),
                )
                self._conn.execute(
                    """
                    INSERT INTO template_versions(name, version, content, variables, checksum, created_at)
                    VALUES (?,?,?,?,?,?)
                    """,
                    (name, 1, content, json.dumps(variables, ensure_ascii=False), _checksum(content), now),
                )
        except sqlite3.IntegrityError as exc:
            raise GatewayError(
                "TEMPLATE_CONFLICT", f"模板 {name!r} 已存在，使用 POST /v1/templates/{name}/versions 追加版本"
            ) from exc
        return self.get_version(name, 1)

    def add_version(
        self,
        name: str,
        content: str,
        *,
        variables: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        self._validate_content(content)
        current = self.get(name)
        next_version = int(current["latest_version"]) + 1
        if variables is None:
            variables = current["versions"][-1]["variables"]
        self._validate_variables(variables)

        from .observability import iso_utc

        now = iso_utc()
        try:
            with self._lock, self._conn:
                self._conn.execute(
                    """
                    INSERT INTO template_versions(name, version, content, variables, checksum, created_at)
                    VALUES (?,?,?,?,?,?)
                    """,
                    (
                        name,
                        next_version,
                        content,
                        json.dumps(variables, ensure_ascii=False),
                        _checksum(content),
                        now,
                    ),
                )
                self._conn.execute("UPDATE templates SET updated_at = ? WHERE name = ?", (now, name))
        except sqlite3.IntegrityError as exc:
            raise GatewayError(
                "TEMPLATE_CONFLICT", f"模板 {name!r} 版本并发冲突，请重试"
            ) from exc
        return self.get_version(name, next_version)

    # ------------------------------------------------------------------ 查询
    def list_templates(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT t.name, t.description, t.created_at, t.updated_at,
                       v.version AS latest_version, v.checksum, v.variables
                FROM templates t
                JOIN template_versions v
                  ON v.name = t.name
                 AND v.version = (SELECT MAX(version) FROM template_versions WHERE name = t.name)
                ORDER BY t.name
                """
            ).fetchall()
        return [
            {
                "name": row["name"],
                "description": row["description"],
                "latest_version": row["latest_version"],
                "checksum": row["checksum"],
                "variables": json.loads(row["variables"]),
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def get(self, name: str) -> dict[str, Any]:
        with self._lock:
            template = self._conn.execute(
                "SELECT * FROM templates WHERE name = ?", (name,)
            ).fetchone()
            versions = self._conn.execute(
                "SELECT * FROM template_versions WHERE name = ? ORDER BY version", (name,)
            ).fetchall()
        if template is None or not versions:
            raise GatewayError("TEMPLATE_NOT_FOUND", f"模板不存在: {name!r}")

        return {
            "name": template["name"],
            "description": template["description"],
            "latest_version": versions[-1]["version"],
            "created_at": template["created_at"],
            "updated_at": template["updated_at"],
            "versions": [self._version_dict(row) for row in versions],
        }

    def get_version(self, name: str, version: int | str = "latest") -> dict[str, Any]:
        resolved = self.resolve_version(name, version)
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM template_versions WHERE name = ? AND version = ?",
                (name, resolved),
            ).fetchone()
        if row is None:
            raise GatewayError(
                "TEMPLATE_VERSION_NOT_FOUND", f"模板 {name!r} 不存在版本 {version!r}"
            )
        result = self._version_dict(row)
        result["latest_version"] = self._latest_version(name)
        return result

    def resolve_version(self, name: str, version: int | str) -> int:
        latest = self._latest_version(name)
        if version == "latest":
            return latest
        try:
            version_int = int(version)
        except (TypeError, ValueError) as exc:
            raise GatewayError(
                "TEMPLATE_VERSION_NOT_FOUND", f"非法模板版本: {version!r}"
            ) from exc
        if version_int < 1 or version_int > latest:
            raise GatewayError(
                "TEMPLATE_VERSION_NOT_FOUND",
                f"模板 {name!r} 只有版本 1..{latest}，请求的是 {version_int}",
            )
        return version_int

    # ------------------------------------------------------------------ 渲染
    def render(
        self,
        name: str,
        version: int | str,
        variables: dict[str, Any],
    ) -> dict[str, Any]:
        resolved = self.resolve_version(name, version)
        row = self.get_version(name, resolved)
        definitions = row["variables"]
        values = dict(variables)
        missing: list[str] = []

        for definition in definitions:
            var_name = definition["name"]
            if var_name not in values or values[var_name] is None:
                if definition.get("default") is not None:
                    values[var_name] = definition["default"]
                elif definition.get("required", True):
                    missing.append(var_name)

        if missing:
            raise GatewayError(
                "TEMPLATE_VARIABLE_MISSING",
                f"模板 {name!r} v{resolved} 缺少必需变量: {', '.join(missing)}",
                details={"missing": missing, "template": name, "version": resolved},
            )

        try:
            template = self.env.from_string(row["content"])
            rendered = template.render(**values)
        except UndefinedError as exc:
            missing_names = self._undefined_names(row["content"], values)
            raise GatewayError(
                "TEMPLATE_VARIABLE_MISSING",
                f"模板变量未提供: {', '.join(missing_names) or exc.message}",
                details={
                    "missing": missing_names,
                    "template": name,
                    "version": resolved,
                },
            ) from exc
        except TemplateSyntaxError as exc:  # pragma: no cover - create 时已校验
            raise GatewayError("TEMPLATE_SYNTAX_ERROR", f"模板语法错误: {exc}") from exc

        used = sorted(meta.find_undeclared_variables(self.env.parse(row["content"])))
        return {
            "template": {
                "name": name,
                "version": resolved,
                "requested_version": version,
                "checksum": row["checksum"],
                "variables": [item["name"] for item in definitions],
            },
            "rendered": rendered,
            "used_variables": used,
        }

    # ------------------------------------------------------------------ 内部
    def _latest_version(self, name: str) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT MAX(version) AS version FROM template_versions WHERE name = ?", (name,)
            ).fetchone()
        if row is None or row["version"] is None:
            raise GatewayError("TEMPLATE_NOT_FOUND", f"模板不存在: {name!r}")
        return int(row["version"])

    def _validate_content(self, content: str) -> None:
        try:
            self.env.parse(content)
        except TemplateSyntaxError as exc:
            raise GatewayError(
                "TEMPLATE_SYNTAX_ERROR", f"模板语法错误（第 {exc.lineno} 行）: {exc.message}"
            ) from exc

    @staticmethod
    def _validate_variables(variables: list[dict[str, Any]]) -> None:
        names = []
        for item in variables:
            if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                raise GatewayError("INVALID_REQUEST", "variables 中每项必须包含 name")
            names.append(item["name"])
        if len(names) != len(set(names)):
            raise GatewayError("INVALID_REQUEST", "variables 中变量名不能重复")

    def _undefined_names(self, content: str, values: dict[str, Any]) -> list[str]:
        ast = self.env.parse(content)
        return sorted(name for name in meta.find_undeclared_variables(ast) if name not in values)

    @staticmethod
    def _version_dict(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "name": row["name"],
            "version": row["version"],
            "content": row["content"],
            "variables": json.loads(row["variables"]),
            "checksum": row["checksum"],
            "created_at": row["created_at"],
        }

    def close(self) -> None:
        with self._lock:
            self._conn.close()
