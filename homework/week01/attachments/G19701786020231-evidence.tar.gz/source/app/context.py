"""请求级上下文（request_id）。"""

from __future__ import annotations

import re
import secrets
from contextvars import ContextVar

_REQUEST_ID_PATTERN = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)


def new_request_id() -> str:
    return "req_" + secrets.token_hex(12)


def sanitize_request_id(value: str | None) -> str:
    if value and _REQUEST_ID_PATTERN.match(value):
        return value
    return new_request_id()


def current_request_id() -> str:
    return request_id_var.get() or new_request_id()
