param(
    [int]$Port = 8000,
    [string]$Config = "config.yaml"
)

$ErrorActionPreference = "Stop"
$env:GATEWAY_CONFIG = $Config
$env:GATEWAY_PORT = $Port

Write-Host "Starting LLM gateway on http://127.0.0.1:$Port (config: $Config)"
py -m uvicorn app.main:app --host 127.0.0.1 --port $Port
