from __future__ import annotations

import asyncio

import pytest

from app.config import RetryConfig
from app.errors import GatewayError
from app.retry import run_with_retry


def test_retries_twice_then_success() -> None:
    attempts = 0
    sleeps: list[float] = []

    async def operation():
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise GatewayError("UPSTREAM_ERROR", "temporary")
        return "ok"

    async def fake_sleep(delay: float) -> None:
        sleeps.append(delay)

    result, trace = asyncio.run(
        run_with_retry(
            operation,
            RetryConfig(max_attempts=3, base_delay_s=0.1, max_delay_s=1, jitter_s=0),
            model="test",
            sleep=fake_sleep,
        )
    )
    assert result == "ok"
    assert attempts == 3
    assert [item["delay_ms"] for item in trace] == [100.0, 200.0]
    assert sleeps == [0.1, 0.2]


def test_exhaustion_attaches_trace() -> None:
    async def operation():
        raise GatewayError("UPSTREAM_ERROR", "still broken")

    async def fake_sleep(delay: float) -> None:
        return None

    with pytest.raises(GatewayError) as exc:
        asyncio.run(
            run_with_retry(
                operation,
                RetryConfig(max_attempts=3, base_delay_s=0.01, jitter_s=0),
                model="test",
                sleep=fake_sleep,
            )
        )
    assert exc.value.attempts == 3
    assert len(exc.value.retry_trace) == 2


def test_non_retryable_error_stops_immediately() -> None:
    attempts = 0

    async def operation():
        nonlocal attempts
        attempts += 1
        raise GatewayError("INVALID_REQUEST", "bad input")

    async def fake_sleep(delay: float) -> None:
        raise AssertionError("不应重试")

    with pytest.raises(GatewayError):
        asyncio.run(
            run_with_retry(
                operation,
                RetryConfig(max_attempts=3),
                model="test",
                sleep=fake_sleep,
            )
        )
    assert attempts == 1


def test_honors_upstream_retry_after() -> None:
    sleeps: list[float] = []

    async def operation():
        raise GatewayError(
            "RATE_LIMITED", "slow down", details={"upstream_retry_after_s": 2.5}
        )

    async def fake_sleep(delay: float) -> None:
        sleeps.append(delay)

    with pytest.raises(GatewayError):
        asyncio.run(
            run_with_retry(
                operation,
                RetryConfig(max_attempts=2, base_delay_s=0.01, jitter_s=0),
                model="test",
                sleep=fake_sleep,
            )
        )
    assert sleeps == [2.5]
