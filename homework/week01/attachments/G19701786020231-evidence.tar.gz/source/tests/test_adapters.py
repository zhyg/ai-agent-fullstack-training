from __future__ import annotations

import pytest

from app.adapters import AnthropicMessagesAdapter, OpenAIResponsesAdapter
from app.adapters.base import NormalizedRequest, usage_from_anthropic, usage_from_responses
from app.config import GatewayConfig
from app.errors import GatewayError
from app.schemas import JsonSchemaSpec, ResponseFormat


def make_gateway() -> GatewayConfig:
    return GatewayConfig.model_validate(
        {
            "models": {
                "pro": {
                    "adapter": "openai_responses",
                    "base_url": "https://example.com",
                    "api_key": "test",
                    "upstream_model": "upstream-pro",
                },
                "flash": {
                    "adapter": "anthropic_messages",
                    "base_url": "https://example.com/anthropic",
                    "api_key": "test",
                    "upstream_model": "upstream-flash",
                },
            }
        }
    )


def structured_format() -> ResponseFormat:
    return ResponseFormat(
        type="json_schema",
        json_schema=JsonSchemaSpec.model_validate(
            {
                "name": "weather",
                "schema": {
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                    "required": ["city"],
                    "additionalProperties": False,
                },
            }
        ),
    )


def base_request(**overrides) -> NormalizedRequest:
    values = dict(
        model="pro",
        upstream_model="upstream-pro",
        system="You are terse.",
        messages=[("user", "hi")],
        max_tokens=128,
    )
    values.update(overrides)
    return NormalizedRequest(**values)


def test_responses_payload_uses_responses_protocol() -> None:
    gateway = make_gateway()
    adapter = OpenAIResponsesAdapter("pro", gateway.models["pro"], gateway)
    request = base_request(
        messages=[("user", "hi"), ("assistant", "hello"), ("user", "again")],
        response_format=structured_format(),
        reasoning_effort="low",
    )
    payload = adapter.build_payload(request, stream=False)

    assert payload["instructions"] == "You are terse."
    assert [item["role"] for item in payload["input"]] == ["user", "assistant", "user"]
    assert payload["input"][0]["content"][0]["type"] == "input_text"
    assert payload["input"][1]["content"][0]["type"] == "output_text"
    assert payload["text"]["format"]["type"] == "json_schema"
    assert payload["text"]["format"]["strict"] is True
    assert payload["reasoning"] == {"effort": "low"}
    assert payload["max_output_tokens"] == 128


def test_messages_payload_uses_forced_tool_for_structured_output() -> None:
    gateway = make_gateway()
    adapter = AnthropicMessagesAdapter("flash", gateway.models["flash"], gateway)
    request = base_request(
        model="flash",
        upstream_model="upstream-flash",
        response_format=structured_format(),
        reasoning_effort="low",
    )
    payload = adapter.build_payload(request, stream=True)

    assert payload["system"] == "You are terse."
    assert payload["messages"] == [{"role": "user", "content": "hi"}]
    assert payload["tools"][0]["name"] == "emit_structured_output"
    assert payload["tool_choice"] == {"type": "tool", "name": "emit_structured_output"}
    assert payload["thinking"] == {"type": "disabled"}
    assert payload["stream"] is True


def test_parse_responses_usage_and_content() -> None:
    gateway = make_gateway()
    adapter = OpenAIResponsesAdapter("pro", gateway.models["pro"], gateway)
    data = {
        "id": "resp_1",
        "model": "deepseek-v4-pro",
        "status": "completed",
        "output": [
            {
                "type": "reasoning",
                "content": [{"type": "reasoning_text", "text": "thinking"}],
            },
            {
                "type": "message",
                "content": [{"type": "output_text", "text": "OK"}],
            },
        ],
        "usage": {
            "input_tokens": 20,
            "output_tokens": 15,
            "total_tokens": 35,
            "input_tokens_details": {"cached_tokens": 4},
            "output_tokens_details": {"reasoning_tokens": 10},
        },
    }
    result = adapter.parse_response(data, base_request())
    assert result.text == "OK"
    assert result.reasoning_text == "thinking"
    assert result.finish_reason == "stop"
    assert result.usage.input_tokens == 20
    assert result.usage.cached_input_tokens == 4
    assert result.usage.reasoning_tokens == 10
    assert result.usage.visible_output_tokens == 5


def test_parse_messages_usage_adds_cache_to_input() -> None:
    gateway = make_gateway()
    adapter = AnthropicMessagesAdapter("flash", gateway.models["flash"], gateway)
    data = {
        "id": "msg_1",
        "model": "deepseek-flash",
        "type": "message",
        "content": [
            {"type": "thinking", "thinking": "hmm"},
            {"type": "text", "text": "OK"},
        ],
        "stop_reason": "end_turn",
        "usage": {
            "input_tokens": 34,
            "cache_creation_input_tokens": 10,
            "cache_read_input_tokens": 20,
            "output_tokens": 12,
            "output_tokens_details": {"thinking_tokens": 5},
        },
    }
    result = adapter.parse_response(data, base_request(model="flash"))
    assert result.text == "OK"
    assert result.reasoning_text == "hmm"
    assert result.usage.input_tokens == 64
    assert result.usage.cache_write_input_tokens == 10
    assert result.usage.cache_read_input_tokens == 20
    assert result.usage.total_tokens == 76
    assert result.usage.visible_output_tokens == 7


def test_structured_output_must_match_schema() -> None:
    gateway = make_gateway()
    adapter = OpenAIResponsesAdapter("pro", gateway.models["pro"], gateway)
    data = {
        "id": "resp_1",
        "model": "pro",
        "status": "completed",
        "output": [
            {"type": "message", "content": [{"type": "output_text", "text": '{"city": 1}'}]}
        ],
        "usage": {},
    }
    with pytest.raises(GatewayError) as exc:
        adapter.parse_response(data, base_request(response_format=structured_format()))
    assert exc.value.code == "STRUCTURED_OUTPUT_INVALID"


def test_usage_normalizers_are_tolerant_to_missing_fields() -> None:
    assert usage_from_responses(None).total_tokens == 0
    assert usage_from_anthropic({}).total_tokens == 0
