from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from app.errors import GatewayError
from app.templates import TemplateStore


@pytest.fixture()
def store():
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "templates.db"
        instance = TemplateStore(db)
        yield instance
        instance.close()


def test_create_version_and_render(store: TemplateStore) -> None:
    v1 = store.create(
        "brief",
        "V1-{{topic}} for {{audience}}",
        variables=[
            {"name": "topic", "required": True},
            {"name": "audience", "required": False, "default": "engineers"},
        ],
    )
    assert v1["version"] == 1
    assert v1["checksum"]

    v2 = store.add_version("brief", "V2-{{topic}}")
    assert v2["version"] == 2

    rendered_v1 = store.render("brief", 1, {"topic": "SSE"})
    assert rendered_v1["rendered"] == "V1-SSE for engineers"
    assert rendered_v1["template"]["version"] == 1
    assert rendered_v1["used_variables"] == ["audience", "topic"]

    rendered_latest = store.render("brief", "latest", {"topic": "retry"})
    assert rendered_latest["rendered"] == "V2-retry"
    assert rendered_latest["template"]["version"] == 2

    detail = store.get("brief")
    assert detail["latest_version"] == 2
    assert [item["version"] for item in detail["versions"]] == [1, 2]


def test_missing_required_variable(store: TemplateStore) -> None:
    store.create(
        "brief", "Hello {{name}}", variables=[{"name": "name", "required": True}]
    )
    with pytest.raises(GatewayError) as exc:
        store.render("brief", 1, {})
    assert exc.value.code == "TEMPLATE_VARIABLE_MISSING"
    assert exc.value.details["missing"] == ["name"]


def test_duplicate_name_conflict(store: TemplateStore) -> None:
    store.create("brief", "v1")
    with pytest.raises(GatewayError) as exc:
        store.create("brief", "v2")
    assert exc.value.code == "TEMPLATE_CONFLICT"


def test_unknown_version(store: TemplateStore) -> None:
    store.create("brief", "v1")
    with pytest.raises(GatewayError) as exc:
        store.render("brief", 9, {})
    assert exc.value.code == "TEMPLATE_VERSION_NOT_FOUND"


def test_syntax_error_rejected(store: TemplateStore) -> None:
    with pytest.raises(GatewayError) as exc:
        store.create("bad", "{% if x %}")
    assert exc.value.code == "TEMPLATE_SYNTAX_ERROR"
