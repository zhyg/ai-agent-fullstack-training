from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.errors import parse_retry_after


def test_retry_after_seconds() -> None:
    assert parse_retry_after("30") == 30.0
    assert parse_retry_after("0.5") == 0.5


def test_retry_after_http_date() -> None:
    future = datetime.now(timezone.utc) + timedelta(seconds=10)
    value = future.strftime("%a, %d %b %Y %H:%M:%S GMT")
    parsed = parse_retry_after(value)
    assert parsed is not None and 0 < parsed <= 10.5


def test_retry_after_invalid() -> None:
    assert parse_retry_after(None) is None
    assert parse_retry_after("not-a-date") is None
