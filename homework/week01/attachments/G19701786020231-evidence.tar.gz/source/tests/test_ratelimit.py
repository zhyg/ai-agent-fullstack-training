from __future__ import annotations

import asyncio

from app.config import RateLimitConfig
from app.ratelimit import ModelRateLimiter, RateLimiterRegistry


def test_token_bucket_burst_then_retry_after() -> None:
    now = [0.0]
    limiter = ModelRateLimiter(
        RateLimitConfig(requests_per_minute=2, burst=2), clock=lambda: now[0]
    )

    async def scenario():
        first = await limiter.acquire()
        second = await limiter.acquire()
        third = await limiter.acquire()
        return first, second, third

    first, second, third = asyncio.run(scenario())
    assert first.allowed and second.allowed
    assert not third.allowed
    assert third.retry_after_s == 30.0

    # 30 秒后正好补满 1 个 token
    now[0] = 30.0
    assert asyncio.run(limiter.acquire()).allowed


def test_models_have_independent_buckets() -> None:
    registry = RateLimiterRegistry(
        {
            "a": RateLimitConfig(requests_per_minute=1, burst=1),
            "b": RateLimitConfig(requests_per_minute=1, burst=1),
        }
    )

    async def scenario():
        assert (await registry.acquire("a")).allowed
        assert not (await registry.acquire("a")).allowed
        # a 被限流不影响 b
        assert (await registry.acquire("b")).allowed

    asyncio.run(scenario())


def test_zero_rpm_disables_limit() -> None:
    limiter = ModelRateLimiter(RateLimitConfig(requests_per_minute=0, burst=1))

    async def scenario():
        for _ in range(5):
            assert (await limiter.acquire()).allowed

    asyncio.run(scenario())
