#!/usr/bin/env python
"""端到端验收脚本：启动 mock 上游 + 网关，真实调用 DeepSeek 两个协议。

用法：
    py scripts/verify.py

产出：
    - 控制台 PASS/FAIL 表格
    - evidence/verification-<timestamp>.json
    - evidence/verification-<timestamp>.md

覆盖：双协议路由、流式 SSE、结构化输出、模板版本、可观测性、
指数退避重试、按模型限流、统一错误码。
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import httpx
import jsonschema
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE_DIR = ROOT / "evidence"
LOG_DIR = EVIDENCE_DIR / "logs"
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace")

WEATHER_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "city": {"type": "string"},
        "temp_c": {"type": "number"},
        "conditions": {"type": "string"},
    },
    "required": ["city", "temp_c", "conditions"],
    "additionalProperties": False,
}

BASE = ""
MOCK = ""
RUN_ID = datetime.now().strftime("%H%M%S")


# --------------------------------------------------------------------- 工具
def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def short(value: Any, limit: int = 500) -> Any:
    if isinstance(value, str):
        return value if len(value) <= limit else value[:limit] + "…"
    if isinstance(value, list):
        return [short(item, limit) for item in value[:10]]
    if isinstance(value, dict):
        return {key: short(item, limit) for key, item in value.items()}
    return value


def wait_http(url: str, timeout_s: float = 90) -> None:
    deadline = time.time() + timeout_s
    last_error: Exception | None = None
    while time.time() < deadline:
        try:
            response = httpx.get(url, timeout=3)
            if response.status_code == 200:
                return
        except Exception as exc:  # noqa: BLE001
            last_error = exc
        time.sleep(0.4)
    raise RuntimeError(f"等待 {url} 超时: {last_error}")


def start_process(cmd: list[str], env: dict[str, str], log_path: Path) -> tuple[subprocess.Popen, Any]:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = open(log_path, "w", encoding="utf-8")
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        env=env,
        stdout=log_file,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return proc, log_file


def stop_process(proc: subprocess.Popen | None, log_file: Any) -> None:
    if proc is not None and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)
    if log_file is not None:
        log_file.close()


class Api:
    def __init__(self, base: str, timeout: float = 180) -> None:
        self.client = httpx.Client(base_url=base, timeout=timeout)

    def close(self) -> None:
        self.client.close()

    def post(self, path: str, body: dict[str, Any], *, timeout: float | None = None) -> httpx.Response:
        return self.client.post(path, json=body, timeout=timeout or self.client.timeout)

    def get(self, path: str, params: dict[str, Any] | None = None) -> httpx.Response:
        return self.client.get(path, params=params)

    def sse(self, path: str, body: dict[str, Any]) -> tuple[int, list[dict[str, Any]], bytes]:
        events: list[dict[str, Any]] = []
        with self.client.stream("POST", path, json=body) as response:
            if response.status_code != 200:
                return response.status_code, events, response.read()
            event: str | None = None
            data_lines: list[str] = []
            for line in response.iter_lines():
                if line == "":
                    if data_lines:
                        events.append(
                            {
                                "event": event,
                                "data": json.loads("\n".join(data_lines)),
                            }
                        )
                    event = None
                    data_lines = []
                elif line.startswith(":"):
                    continue
                elif line.startswith("event:"):
                    event = line[6:].strip()
                elif line.startswith("data:"):
                    data_lines.append(line[5:].lstrip())
            if data_lines:
                events.append({"event": event, "data": json.loads("\n".join(data_lines))})
        return 200, events, b""


def expect(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def status_is(response: httpx.Response, expected: int) -> Any:
    expect(
        response.status_code == expected,
        f"HTTP {response.status_code} != {expected}: {response.text[:700]}",
    )
    return response.json() if response.content else None


def error_code(body: dict[str, Any]) -> str | None:
    return (body.get("error") or {}).get("code")


def request_id_of(response: httpx.Response, body: dict[str, Any] | None = None) -> str | None:
    rid = response.headers.get("x-request-id")
    if rid:
        return rid
    if body:
        return (body.get("meta") or {}).get("request_id") or (body.get("error") or {}).get(
            "request_id"
        )
    return None


@dataclass
class CheckResult:
    name: str
    description: str
    status: str
    duration_ms: float
    evidence: dict[str, Any] = field(default_factory=dict)
    error: str | None = None


CHECKS: list[CheckResult] = []


def run_check(name: str, description: str, fn: Callable[[], dict[str, Any]]) -> None:
    started = time.perf_counter()
    try:
        evidence = fn()
        status = "PASS"
        error = None
    except Exception as exc:  # noqa: BLE001
        evidence = {}
        status = "FAIL"
        error = f"{exc.__class__.__name__}: {exc}"
    duration = (time.perf_counter() - started) * 1000
    CHECKS.append(
        CheckResult(
            name=name,
            description=description,
            status=status,
            duration_ms=round(duration, 1),
            evidence=evidence,
            error=error,
        )
    )
    print(f"[{status}] {name} ({duration:.0f} ms)" + (f" -> {error}" if error else ""))


# --------------------------------------------------------------------- 检查
def main() -> int:
    global BASE, MOCK

    load_dotenv(ROOT / ".env", override=False)
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if not api_key:
        print("缺少 DEEPSEEK_API_KEY：请写入 llm-protocol-gateway/.env 或进程环境。", file=sys.stderr)
        return 2

    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    for suffix in ("", "-wal", "-shm"):
        candidate = (ROOT / "data" / f"test-gateway.db{suffix}").resolve()
        if ROOT not in candidate.parents:
            raise RuntimeError(f"拒绝删除工作区外的路径: {candidate}")
        if candidate.exists():
            candidate.unlink()

    mock_port = free_port()
    gateway_port = free_port()
    MOCK = f"http://127.0.0.1:{mock_port}"
    BASE = f"http://127.0.0.1:{gateway_port}"
    print(f"mock={MOCK} gateway={BASE}")

    base_env = os.environ.copy()
    base_env["PYTHONPATH"] = str(ROOT) + os.pathsep + base_env.get("PYTHONPATH", "")
    base_env["PYTHONUNBUFFERED"] = "1"

    mock_proc = gateway_proc = None
    mock_log = gateway_log = None
    api: Api | None = None
    started_at = datetime.now()

    try:
        mock_proc, mock_log = start_process(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "mock.upstream:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(mock_port),
                "--log-level",
                "warning",
            ],
            base_env,
            LOG_DIR / "mock.log",
        )
        wait_http(MOCK + "/healthz", timeout_s=30)

        gateway_env = base_env.copy()
        gateway_env["MOCK_BASE_URL"] = MOCK
        gateway_env["GATEWAY_CONFIG"] = str(ROOT / "config.test.yaml")
        gateway_proc, gateway_log = start_process(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "app.main:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(gateway_port),
                "--log-level",
                "info",
            ],
            gateway_env,
            LOG_DIR / "gateway.log",
        )
        wait_http(BASE + "/healthz", timeout_s=60)
        api = Api(BASE)

        ctx: dict[str, Any] = {"request_ids": {}, "template": f"verify_brief_{RUN_ID}"}

        run_check("health_ready", "健康检查与就绪检查", lambda: check_health(api))
        run_check("models_routing", "两个模型按 model 字段路由到不同协议", lambda: check_models(api))
        run_check("upstream_models", "真实上游可用且包含目标模型", check_upstream_models)
        run_check(
            "non_stream_responses",
            "OpenAI Responses 协议非流式调用",
            lambda: check_non_stream(api, ctx, "deepseek-v4-pro", "PRO-OK", "openai_responses"),
        )
        run_check(
            "non_stream_messages",
            "Anthropic Messages 协议非流式调用",
            lambda: check_non_stream(api, ctx, "deepseek-flash", "FLASH-OK", "anthropic_messages"),
        )
        run_check(
            "stream_responses",
            "Responses 协议 SSE 流式 + 首 Token 延迟",
            lambda: check_stream(api, ctx, "deepseek-v4-pro", "low"),
        )
        run_check(
            "stream_messages",
            "Messages 协议 SSE 流式 + 首 Token 延迟",
            lambda: check_stream(api, ctx, "deepseek-flash", "none"),
        )
        run_check(
            "structured_responses",
            "Responses 协议 json_schema 结构化输出",
            lambda: check_structured(api, ctx, "deepseek-v4-pro", "low"),
        )
        run_check(
            "structured_messages",
            "Messages 协议强制 tool_use 结构化输出",
            lambda: check_structured(api, ctx, "deepseek-flash", "none"),
        )
        run_check("templates", "模板创建、不可变版本、变量替换、版本引用", lambda: check_templates(api, ctx))
        run_check("error_mapping", "统一错误码：未知模型 / 非法 Schema", lambda: check_errors(api))
        run_check("retry_backoff", "指数退避重试两次后成功", lambda: check_retry(api, ctx))
        run_check("retry_exhaustion", "重试次数上限 3 次后返回统一错误", lambda: check_retry_exhaustion(api, ctx))
        run_check("rate_limit", "按模型独立限流，超限 429", lambda: check_rate_limit(api, ctx))
        run_check("observability", "Token 分类统计 / 延迟 / 首 Token / 重试轨迹", lambda: check_observability(api, ctx))

    except Exception as exc:  # noqa: BLE001
        print(f"验证过程异常: {exc}", file=sys.stderr)
        return 1
    finally:
        if api is not None:
            api.close()
        stop_process(gateway_proc, gateway_log)
        stop_process(mock_proc, mock_log)
        print("已停止 mock 与网关进程")

    passed = sum(1 for item in CHECKS if item.status == "PASS")
    total = len(CHECKS)
    finished_at = datetime.now()
    report = {
        "started_at": started_at.isoformat(timespec="seconds"),
        "finished_at": finished_at.isoformat(timespec="seconds"),
        "duration_s": round((finished_at - started_at).total_seconds(), 2),
        "gateway": BASE,
        "mock": MOCK,
        "summary": {"passed": passed, "failed": total - passed, "total": total},
        "checks": [
            {
                "name": item.name,
                "description": item.description,
                "status": item.status,
                "duration_ms": item.duration_ms,
                "evidence": item.evidence,
                "error": item.error,
            }
            for item in CHECKS
        ],
    }
    stamp = finished_at.strftime("%Y%m%d-%H%M%S")
    json_path = EVIDENCE_DIR / f"verification-{stamp}.json"
    md_path = EVIDENCE_DIR / f"verification-{stamp}.md"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(render_markdown(report), encoding="utf-8")
    (EVIDENCE_DIR / "latest.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (EVIDENCE_DIR / "latest.md").write_text(render_markdown(report), encoding="utf-8")

    print("\n" + "=" * 72)
    for item in CHECKS:
        print(f"{item.status:4}  {item.name:24} {item.description}")
    print("=" * 72)
    print(f"结果: {passed}/{total} PASS")
    print(f"证据: {json_path.relative_to(ROOT)}")
    print(f"报告: {md_path.relative_to(ROOT)}")
    return 0 if passed == total else 1


# --------------------------------------------------------------------- 各项
def check_health(api: Api) -> dict[str, Any]:
    health = status_is(api.get("/healthz"), 200)
    ready = status_is(api.get("/readyz"), 200)
    expect(health["status"] == "ok", "healthz 状态异常")
    expect(ready["models"] >= 2, "readyz 模型数不足")
    return {"healthz": health, "readyz": ready}


def check_models(api: Api) -> dict[str, Any]:
    body = status_is(api.get("/v1/models"), 200)
    mapping = {item["id"]: item for item in body["data"]}
    expect(mapping["deepseek-v4-pro"]["adapter"] == "openai_responses", "pro 适配器错误")
    expect(mapping["deepseek-flash"]["adapter"] == "anthropic_messages", "flash 适配器错误")
    expect(
        mapping["deepseek-v4-pro"]["protocol"] == "OpenAI Responses API",
        "pro 协议描述错误",
    )
    expect(
        mapping["deepseek-flash"]["protocol"] == "Anthropic Messages API",
        "flash 协议描述错误",
    )
    return {
        "models": {
            key: {
                "adapter": value["adapter"],
                "protocol": value["protocol"],
                "rate_limit": value["rate_limit"],
            }
            for key, value in mapping.items()
        }
    }


def check_upstream_models() -> dict[str, Any]:
    response = httpx.get(
        "https://api.deepseek.com/models",
        headers={"Authorization": f"Bearer {os.environ['DEEPSEEK_API_KEY']}"},
        timeout=60,
    )
    body = status_is(response, 200)
    ids = [item["id"] for item in body.get("data", [])]
    expect("deepseek-v4-pro" in ids, f"上游缺少 deepseek-v4-pro: {ids}")
    expect("deepseek-flash" in ids, f"上游缺少 deepseek-flash: {ids}")
    return {"upstream_model_ids": ids}


def check_non_stream(
    api: Api, ctx: dict[str, Any], model: str, marker: str, adapter: str
) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [{"role": "user", "content": f"Reply with exactly: {marker}"}],
        "max_tokens": 512 if model == "deepseek-v4-pro" else 200,
        "reasoning_effort": "low" if model == "deepseek-v4-pro" else "none",
    }
    response = api.post("/v1/chat", body)
    data = status_is(response, 200)
    rid = request_id_of(response, data)
    ctx["request_ids"][f"non_stream_{model}"] = rid

    expect(data["adapter"] == adapter, f"adapter={data['adapter']} 期望 {adapter}")
    expect(marker in data["output_text"], f"输出未包含 {marker}: {data['output_text']!r}")
    expect(data["usage"]["total_tokens"] > 0, "usage.total_tokens 未统计")
    expect(data["meta"]["latency_ms"] > 0, "latency_ms 未统计")
    expect(data["meta"]["ttft_ms"] is None, "非流式请求不应有 ttft_ms")
    expect(data["meta"]["attempts"] == 1, "首次调用不应有重试")

    return {
        "request_id": rid,
        "model": model,
        "adapter": data["adapter"],
        "output_text": data["output_text"],
        "usage": data["usage"],
        "latency_ms": data["meta"]["latency_ms"],
        "attempts": data["meta"]["attempts"],
    }


def check_stream(api: Api, ctx: dict[str, Any], model: str, effort: str) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {"role": "user", "content": "Count from 1 to 3, separated by commas. No other text."}
        ],
        "max_tokens": 300 if model == "deepseek-v4-pro" else 100,
        "reasoning_effort": effort,
        "stream": True,
    }
    status, events, raw = api.sse("/v1/chat", body)
    expect(status == 200, f"HTTP {status}: {raw[:500]}")
    expect(bool(events), "没有收到 SSE 事件")
    expect(events[0]["event"] == "meta", f"首个事件应为 meta，实际 {events[0]['event']}")
    expect(events[-1]["event"] == "done", f"最后一个事件应为 done，实际 {events[-1]['event']}")

    deltas = [item for item in events if item["event"] == "delta"]
    text = "".join(item["data"].get("text", "") for item in deltas)
    done = events[-1]["data"]
    rid = done["meta"]["request_id"]
    ctx["request_ids"][f"stream_{model}"] = rid

    expect(len(deltas) >= 1, "delta 事件数量为 0")
    expect(text.strip() != "", "流式文本为空")
    expect(done["usage"]["total_tokens"] > 0, "done.usage.total_tokens 未统计")
    expect(done["meta"]["ttft_ms"] is not None, "缺少首 Token 延迟")
    expect(
        done["meta"]["ttft_ms"] <= done["meta"]["latency_ms"],
        "ttft_ms 大于 latency_ms",
    )
    expect(done["finish_reason"] == "stop", f"finish_reason={done['finish_reason']}")

    return {
        "request_id": rid,
        "model": model,
        "event_count": len(events),
        "delta_count": len(deltas),
        "reasoning_event_count": sum(1 for item in events if item["event"] == "reasoning"),
        "streamed_text": short(text, 300),
        "usage": done["usage"],
        "ttft_ms": done["meta"]["ttft_ms"],
        "latency_ms": done["meta"]["latency_ms"],
        "first_events": [
            {"event": item["event"], "data": short(item["data"], 160)} for item in events[:4]
        ],
    }


def check_structured(api: Api, ctx: dict[str, Any], model: str, effort: str) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": "Return a JSON weather report for Hangzhou with plausible values.",
            }
        ],
        "max_tokens": 900,
        "reasoning_effort": effort,
        "response_format": {
            "type": "json_schema",
            "json_schema": {"name": "weather", "schema": WEATHER_SCHEMA, "strict": True},
        },
    }
    response = api.post("/v1/chat", body)
    data = status_is(response, 200)
    rid = request_id_of(response, data)
    ctx["request_ids"][f"structured_{model}"] = rid

    structured = data["structured_output"]
    expect(isinstance(structured, dict), "structured_output 不是对象")
    jsonschema.validate(structured, WEATHER_SCHEMA)
    parsed_content = json.loads(data["output_text"])
    expect(parsed_content == structured, "message.content 与 structured_output 不一致")
    expect(isinstance(parsed_content["temp_c"], (int, float)), "temp_c 不是数字")

    return {
        "request_id": rid,
        "model": model,
        "adapter": data["adapter"],
        "structured_output": structured,
        "content_is_json": True,
        "usage": data["usage"],
    }


def check_templates(api: Api, ctx: dict[str, Any]) -> dict[str, Any]:
    name = ctx["template"]
    v1 = status_is(
        api.post(
            "/v1/templates",
            {
                "name": name,
                "description": "验收模板",
                "content": "Reply with exactly: TPL-V1-{{topic}}",
                "variables": [{"name": "topic", "required": True, "description": "主题"}],
            },
        ),
        201,
    )
    expect(v1["version"] == 1, "模板初始版本不是 1")

    duplicate = api.post(
        "/v1/templates",
        {"name": name, "content": "duplicate", "variables": []},
    )
    duplicate_body = status_is(duplicate, 409)
    expect(error_code(duplicate_body) == "TEMPLATE_CONFLICT", "重复创建未返回 TEMPLATE_CONFLICT")

    v2 = status_is(
        api.post(
            f"/v1/templates/{name}/versions",
            {"content": "Reply with exactly: TPL-V2-{{topic}}"},
        ),
        201,
    )
    expect(v2["version"] == 2, "第二版版本号不是 2")

    preview = status_is(
        api.post(
            f"/v1/templates/{name}/render",
            {"version": 1, "variables": {"topic": "preview"}},
        ),
        200,
    )
    expect(preview["rendered"] == "Reply with exactly: TPL-V1-preview", "v1 渲染结果错误")
    expect(preview["used_variables"] == ["topic"], "used_variables 未识别 topic")

    detail = status_is(api.get(f"/v1/templates/{name}"), 200)
    expect(detail["latest_version"] == 2, "latest_version 不是 2")
    expect([item["version"] for item in detail["versions"]] == [1, 2], "版本列表不是 [1,2]")

    missing = api.post(f"/v1/templates/{name}/render", {"version": 2, "variables": {}})
    missing_body = status_is(missing, 422)
    expect(
        error_code(missing_body) == "TEMPLATE_VARIABLE_MISSING",
        "缺变量未返回 TEMPLATE_VARIABLE_MISSING",
    )

    bad_version = api.get(f"/v1/templates/{name}/versions/99")
    bad_body = status_is(bad_version, 404)
    expect(
        error_code(bad_body) == "TEMPLATE_VERSION_NOT_FOUND",
        "非法版本未返回 TEMPLATE_VERSION_NOT_FOUND",
    )

    chat_v1 = api.post(
        "/v1/chat",
        {
            "model": "deepseek-flash",
            "template": {"name": name, "version": 1, "variables": {"topic": "alpha"}},
            "max_tokens": 100,
            "reasoning_effort": "none",
        },
    )
    chat_v1_body = status_is(chat_v1, 200)
    expect("TPL-V1-alpha" in chat_v1_body["output_text"], "v1 引用未渲染正确变量")
    expect(chat_v1_body["meta"]["template"]["version"] == 1, "v1 引用元数据错误")
    ctx["request_ids"]["template_v1"] = request_id_of(chat_v1, chat_v1_body)

    chat_latest = api.post(
        "/v1/chat",
        {
            "model": "deepseek-flash",
            "template": {"name": name, "version": "latest", "variables": {"topic": "beta"}},
            "max_tokens": 100,
            "reasoning_effort": "none",
        },
    )
    chat_latest_body = status_is(chat_latest, 200)
    expect("TPL-V2-beta" in chat_latest_body["output_text"], "latest 未引用 v2")
    expect(chat_latest_body["meta"]["template"]["version"] == 2, "latest 版本解析错误")
    ctx["request_ids"]["template_latest"] = request_id_of(chat_latest, chat_latest_body)

    return {
        "template": name,
        "versions": [1, 2],
        "preview_v1": preview["rendered"],
        "chat_v1_output": chat_v1_body["output_text"],
        "chat_latest_output": chat_latest_body["output_text"],
        "v1_checksum": v1["checksum"],
        "v2_checksum": v2["checksum"],
        "duplicate_create": error_code(duplicate_body),
        "missing_variable": error_code(missing_body),
        "bad_version": error_code(bad_body),
        "request_ids": {
            "v1": ctx["request_ids"]["template_v1"],
            "latest": ctx["request_ids"]["template_latest"],
        },
    }


def check_errors(api: Api) -> dict[str, Any]:
    unknown = api.post(
        "/v1/chat", {"model": "no-such-model", "messages": [{"role": "user", "content": "hi"}]}
    )
    unknown_body = status_is(unknown, 404)
    expect(error_code(unknown_body) == "MODEL_NOT_FOUND", "未知模型未返回 MODEL_NOT_FOUND")

    invalid_schema = api.post(
        "/v1/chat",
        {
            "model": "deepseek-flash",
            "messages": [{"role": "user", "content": "hi"}],
            "response_format": {
                "type": "json_schema",
                "json_schema": {"name": "bad", "schema": {"type": "not-a-type"}},
            },
        },
    )
    invalid_body = status_is(invalid_schema, 400)
    expect(
        error_code(invalid_body) == "INVALID_REQUEST",
        "非法 JSON Schema 未返回 INVALID_REQUEST",
    )
    return {
        "unknown_model": {
            "status": unknown.status_code,
            "code": error_code(unknown_body),
            "request_id": request_id_of(unknown, unknown_body),
        },
        "invalid_schema": {
            "status": invalid_schema.status_code,
            "code": error_code(invalid_body),
        },
    }


def _mock_reset() -> None:
    response = httpx.post(MOCK + "/_control/reset", timeout=10)
    expect(response.status_code == 200, f"mock reset 失败: {response.text}")


def _mock_config(**kwargs: Any) -> None:
    response = httpx.post(MOCK + "/_control/config", json=kwargs, timeout=10)
    expect(response.status_code == 200, f"mock config 失败: {response.text}")


def _mock_state() -> dict[str, Any]:
    return httpx.get(MOCK + "/_control/state", timeout=10).json()


def check_retry(api: Api, ctx: dict[str, Any]) -> dict[str, Any]:
    _mock_reset()
    _mock_config(fail_responses=2)
    started = time.perf_counter()
    response = api.post(
        "/v1/chat",
        {
            "model": "probe-retry",
            "messages": [{"role": "user", "content": "retry probe"}],
            "max_tokens": 50,
        },
        timeout=30,
    )
    elapsed_ms = (time.perf_counter() - started) * 1000
    data = status_is(response, 200)
    rid = request_id_of(response, data)
    ctx["request_ids"]["retry_success"] = rid
    retries = data["meta"]["retries"]
    state = _mock_state()

    expect(data["meta"]["attempts"] == 3, f"attempts={data['meta']['attempts']} != 3")
    expect(len(retries) == 2, f"retry 轨迹长度={len(retries)} != 2")
    expect(
        retries[0]["delay_ms"] < retries[1]["delay_ms"],
        "退避延迟不是递增",
    )
    expect(state["responses_requests"] == 3, f"mock 收到 {state['responses_requests']} 次请求 != 3")
    expect(state["failures_served"] == 2, "mock 失败注入次数不是 2")
    expect(elapsed_ms >= 400, f"总耗时 {elapsed_ms:.0f}ms 不符合指数退避")

    record = status_is(api.get(f"/v1/observability/calls/{rid}"), 200)
    expect(record["attempts"] == 3, "观测记录 attempts 不是 3")
    expect(len(record["retry_trace"]) == 2, "观测记录 retry_trace 长度不是 2")

    return {
        "request_id": rid,
        "attempts": data["meta"]["attempts"],
        "retry_delays_ms": [item["delay_ms"] for item in retries],
        "elapsed_ms": round(elapsed_ms, 1),
        "mock_requests": state["responses_requests"],
        "mock_failures_served": state["failures_served"],
        "observability_attempts": record["attempts"],
    }


def check_retry_exhaustion(api: Api, ctx: dict[str, Any]) -> dict[str, Any]:
    _mock_reset()
    _mock_config(fail_responses=5)
    response = api.post(
        "/v1/chat",
        {
            "model": "probe-retry",
            "messages": [{"role": "user", "content": "retry exhaust"}],
            "max_tokens": 50,
        },
        timeout=30,
    )
    body = status_is(response, 502)
    error = body["error"]
    state = _mock_state()
    ctx["request_ids"]["retry_exhausted"] = request_id_of(response, body)

    expect(error["code"] == "UPSTREAM_ERROR", f"错误码={error['code']} != UPSTREAM_ERROR")
    expect(error["details"].get("attempts") == 3, "错误详情缺少 attempts=3")
    expect(len(error["details"].get("retry_trace", [])) == 2, "错误详情缺少 retry_trace")
    expect(state["responses_requests"] == 3, f"mock 请求数={state['responses_requests']} != 3")

    record = status_is(
        api.get(f"/v1/observability/calls/{ctx['request_ids']['retry_exhausted']}"), 200
    )
    expect(record["status"] == "error", "观测记录状态不是 error")
    expect(record["error_code"] == "UPSTREAM_ERROR", "观测记录错误码错误")

    return {
        "status": response.status_code,
        "error_code": error["code"],
        "attempts": error["details"]["attempts"],
        "retry_trace": error["details"]["retry_trace"],
        "mock_requests": state["responses_requests"],
    }


def check_rate_limit(api: Api, ctx: dict[str, Any]) -> dict[str, Any]:
    _mock_reset()
    body = {
        "model": "probe-ratelimit",
        "messages": [{"role": "user", "content": "rate probe"}],
        "max_tokens": 30,
    }
    first = api.post("/v1/chat", body, timeout=30)
    second = api.post("/v1/chat", body, timeout=30)
    third = api.post("/v1/chat", body, timeout=30)
    status_is(first, 200)
    status_is(second, 200)
    third_body = status_is(third, 429)
    error = third_body["error"]
    retry_after = third.headers.get("retry-after")

    expect(error["code"] == "RATE_LIMITED", f"错误码={error['code']} != RATE_LIMITED")
    expect(error["details"].get("scope") == "per_model", "限流范围不是 per_model")
    expect(retry_after is not None and int(retry_after) >= 1, "429 缺少 Retry-After")
    expect(
        third.headers.get("x-ratelimit-limit") == "2",
        "429 缺少 X-RateLimit-Limit=2",
    )
    ctx["request_ids"]["rate_limited"] = request_id_of(third, third_body)

    isolated = api.post(
        "/v1/chat",
        {
            "model": "deepseek-flash",
            "messages": [{"role": "user", "content": "Reply with exactly: ISOLATED"}],
            "max_tokens": 80,
            "reasoning_effort": "none",
        },
        timeout=60,
    )
    isolated_body = status_is(isolated, 200)
    ctx["request_ids"]["rate_isolation"] = request_id_of(isolated, isolated_body)
    expect("ISOLATED" in isolated_body["output_text"], "隔离验证模型调用失败")

    summary = status_is(api.get("/v1/observability/summary"), 200)
    probe = summary["by_model"].get("probe-ratelimit", {})
    expect(probe.get("rate_limited", 0) >= 1, "观测聚合未统计 rate_limited")

    return {
        "first_two": [first.status_code, second.status_code],
        "third": third.status_code,
        "error_code": error["code"],
        "retry_after": retry_after,
        "rate_limit_limit": third.headers.get("x-ratelimit-limit"),
        "rate_limit_remaining": third.headers.get("x-ratelimit-remaining"),
        "isolated_model_call": isolated.status_code,
        "isolated_output": isolated_body["output_text"],
        "summary_rate_limited": probe.get("rate_limited"),
    }


def check_observability(api: Api, ctx: dict[str, Any]) -> dict[str, Any]:
    calls = status_is(api.get("/v1/observability/calls", params={"limit": 200}), 200)
    by_id = {item["request_id"]: item for item in calls["data"]}

    missing = [
        name
        for name, rid in ctx["request_ids"].items()
        if rid and rid not in by_id
    ]
    expect(not missing, f"以下调用缺少观测记录: {missing}")

    token_fields = [
        "input_tokens",
        "output_tokens",
        "total_tokens",
        "cached_input_tokens",
        "cache_write_input_tokens",
        "cache_read_input_tokens",
        "reasoning_tokens",
        "visible_output_tokens",
    ]
    checked = 0
    stream_ttft = []
    for name, rid in ctx["request_ids"].items():
        if rid is None:
            continue
        record = by_id.get(rid)
        if record is None:
            continue
        checked += 1
        for field_name in token_fields:
            expect(field_name in record, f"{name} 缺少 token 字段 {field_name}")
            expect(isinstance(record[field_name], int), f"{name}.{field_name} 不是整数")
        expect(
            record["visible_output_tokens"]
            == max(0, record["output_tokens"] - record["reasoning_tokens"]),
            f"{name} 可见输出 token 计算不一致",
        )
        if record["stream"] and record["status"] == "success":
            expect(record["ttft_ms"] is not None, f"{name} 流式记录缺少 ttft_ms")
            expect(record["latency_ms"] >= record["ttft_ms"], f"{name} latency < ttft")
            stream_ttft.append(record["ttft_ms"])
        if record["status"] == "success" and not record["stream"]:
            expect(record["ttft_ms"] is None, f"{name} 非流式不应有 ttft_ms")

    template_record = by_id.get(ctx["request_ids"].get("template_latest"))
    expect(template_record is not None, "缺少模板调用观测记录")
    expect(template_record["template_name"] == ctx["template"], "模板名未记录")
    expect(template_record["template_version"] == 2, "模板版本未记录")

    summary = status_is(api.get("/v1/observability/summary", params={"window_minutes": 60}), 200)
    totals = summary["totals"]
    expect(totals["calls"] >= checked, "聚合 calls 小于明细数")
    expect(totals["p95_latency_ms"] is not None, "缺少 P95 延迟")
    expect(summary["by_adapter"].get("openai_responses", {}).get("calls", 0) > 0, "缺少 Responses 聚合")
    expect(
        summary["by_adapter"].get("anthropic_messages", {}).get("calls", 0) > 0,
        "缺少 Messages 聚合",
    )
    expect(summary["by_model"].get("probe-retry", {}).get("total_retries", 0) >= 2, "未统计重试次数")
    expect(
        summary["by_model"].get("probe-ratelimit", {}).get("rate_limited", 0) >= 1,
        "未统计限流次数",
    )

    return {
        "checked_calls": checked,
        "stream_ttft_ms": stream_ttft,
        "template_recorded": {
            "name": template_record["template_name"],
            "version": template_record["template_version"],
        },
        "totals": totals,
        "by_model": {
            key: {
                "calls": value["calls"],
                "total_tokens": value["total_tokens"],
                "avg_latency_ms": value["avg_latency_ms"],
                "p95_latency_ms": value["p95_latency_ms"],
                "avg_ttft_ms": value["avg_ttft_ms"],
                "total_retries": value["total_retries"],
                "rate_limited": value["rate_limited"],
            }
            for key, value in summary["by_model"].items()
        },
    }


# --------------------------------------------------------------------- 报告
def render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# LLM Protocol Gateway · 验证明细",
        "",
        f"- 开始：`{report['started_at']}`",
        f"- 结束：`{report['finished_at']}`，耗时 {report['duration_s']}s",
        f"- 结果：**{report['summary']['passed']}/{report['summary']['total']} PASS**",
        f"- 网关：`{report['gateway']}`，mock 上游：`{report['mock']}`",
        f"- 复现：`py scripts/verify.py`（日志见 `evidence/logs/`）",
        "",
        "| # | 检查项 | 结果 | 耗时 | 关键证据 |",
        "| --- | --- | --- | --- | --- |",
    ]
    for index, check in enumerate(report["checks"], 1):
        if check["status"] == "PASS":
            evidence = check["evidence"]
            summary = evidence.get("output_text") or evidence.get("structured_output") or ""
            if check["name"] == "retry_backoff":
                summary = f"attempts={evidence.get('attempts')}, delays={evidence.get('retry_delays_ms')}"
            elif check["name"] == "retry_exhaustion":
                summary = f"attempts={evidence.get('attempts')}, code={evidence.get('error_code')}"
            elif check["name"] == "rate_limit":
                summary = f"前两次={evidence.get('first_two')}, 第三次={evidence.get('third')}, Retry-After={evidence.get('retry_after')}"
            elif check["name"] == "templates":
                summary = f"{evidence.get('chat_v1_output')} / {evidence.get('chat_latest_output')}"
            elif check["name"] == "observability":
                summary = f"checked={evidence.get('checked_calls')}, ttft={evidence.get('stream_ttft_ms')}"
            elif check["name"] == "models_routing":
                summary = ", ".join(
                    f"{key}→{value['adapter']}" for key, value in evidence.get("models", {}).items()
                )
            elif check["name"].startswith("stream_"):
                summary = (
                    f"events={evidence.get('event_count')}, delta={evidence.get('delta_count')}, "
                    f"text={evidence.get('streamed_text')}, ttft={evidence.get('ttft_ms')}ms"
                )
            elif check["name"] == "upstream_models":
                summary = ", ".join(evidence.get("upstream_model_ids", []))
            elif check["name"] == "error_mapping":
                summary = (
                    f"{evidence.get('unknown_model', {}).get('code')} / "
                    f"{evidence.get('invalid_schema', {}).get('code')}"
                )
            elif check["name"] == "health_ready":
                summary = f"models={evidence.get('readyz', {}).get('models')}"
            text = str(summary)
            key = text[:120].replace("|", "\\|").replace("\n", " ")
        else:
            key = (check.get("error") or "")[:160].replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| {index} | {check['description']} | **{check['status']}** | "
            f"{check['duration_ms']} ms | {key} |"
        )

    lines += [
        "",
        "## 证据说明",
        "",
        "- 每个检查项的完整请求/响应摘要位于同名 JSON 报告的 `checks[].evidence`。",
        "- 流式检查同时验证了 SSE 事件序列、累计文本、done.usage 与 `ttft_ms <= latency_ms`。",
        "- 重试检查由 mock 上游注入 2 次 503，验证 3 次尝试、两次递增退避以及观测记录。",
        "- 限流检查使用 `probe-ratelimit`（2 请求/分钟）触发 429，并立刻调用 `deepseek-flash` 证明限流互不影响。",
        "- 所有真实调用均为小 `max_tokens` 请求，Key 仅从 `.env` 读取，不写入报告。",
        "",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    raise SystemExit(main())
