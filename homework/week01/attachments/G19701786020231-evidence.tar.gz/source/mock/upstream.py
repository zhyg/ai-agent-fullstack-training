"""协议级 mock 上游：用于可重复验证重试与限流。

不是业务服务的一部分，只在 scripts/verify.py 中启动。它分别实现：
- POST /responses            OpenAI Responses API（含 SSE）
- POST /v1/messages          Anthropic Messages API（含 SSE）
- POST /_control/config      注入失败次数 / 延迟
- GET  /_control/state       查看请求计数
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Any, AsyncIterator

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI(title="mock upstream", docs_url=None, redoc_url=None)

_state: dict[str, Any] = {
    "fail_responses": 0,
    "fail_messages": 0,
    "fail_status": 503,
    "delay_ms": 0,
    "responses_requests": 0,
    "messages_requests": 0,
    "failures_served": 0,
    "last_paths": [],
}
_lock = asyncio.Lock()


async def _consume_failure(key: str) -> int | None:
    async with _lock:
        if _state[key] > 0:
            _state[key] -= 1
            _state["failures_served"] += 1
            return int(_state["fail_status"])
        return None


async def _delay() -> None:
    if _state["delay_ms"]:
        await asyncio.sleep(float(_state["delay_ms"]) / 1000)


def _last_user_text(body: dict[str, Any]) -> str:
    raw = body.get("input")
    if isinstance(raw, str):
        return raw
    items = body.get("messages") or []
    if raw and isinstance(raw, list):
        items = raw
    for item in reversed(items):
        if not isinstance(item, dict) or item.get("role") != "user":
            continue
        content = item.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            texts = [
                str(block.get("text") or "")
                for block in content
                if isinstance(block, dict)
            ]
            return " ".join(texts)
    return ""


def _sse(event: str, payload: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


@app.post("/_control/config")
async def control_config(request: Request) -> dict[str, Any]:
    body = await request.json()
    async with _lock:
        for key in ("fail_responses", "fail_messages", "fail_status", "delay_ms"):
            if key in body:
                _state[key] = int(body[key])
        return dict(_state)


@app.post("/_control/reset")
async def control_reset() -> dict[str, Any]:
    async with _lock:
        _state.update(
            fail_responses=0,
            fail_messages=0,
            fail_status=503,
            delay_ms=0,
            responses_requests=0,
            messages_requests=0,
            failures_served=0,
            last_paths=[],
        )
        return dict(_state)


@app.get("/_control/state")
async def control_state() -> dict[str, Any]:
    async with _lock:
        return dict(_state)


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


# --------------------------------------------------------------------- Responses
@app.post("/responses")
async def responses(request: Request):
    body = await request.json()
    async with _lock:
        _state["responses_requests"] += 1
        _state["last_paths"].append("/responses")
        _state["last_paths"] = _state["last_paths"][-20:]

    status = await _consume_failure("fail_responses")
    if status is not None:
        return JSONResponse(
            status_code=status,
            content={"error": {"message": "mock injected failure", "type": "server_error"}},
        )
    await _delay()

    text = "MOCK-RESPONSES: " + (_last_user_text(body)[:120] or "ok")
    response_id = "mock_resp_" + uuid.uuid4().hex[:12]
    usage = {
        "input_tokens": 12,
        "output_tokens": 8,
        "total_tokens": 20,
        "input_tokens_details": {"cached_tokens": 0},
        "output_tokens_details": {"reasoning_tokens": 0},
    }
    if body.get("stream"):
        return StreamingResponse(
            _responses_stream(response_id, text, usage, str(body.get("model") or "mock")),
            media_type="text/event-stream",
        )
    return {
        "id": response_id,
        "object": "response",
        "created_at": int(time.time()),
        "status": "completed",
        "model": body.get("model") or "mock-responses",
        "output": [
            {
                "type": "message",
                "id": "mock_msg_" + uuid.uuid4().hex[:8],
                "status": "completed",
                "role": "assistant",
                "content": [{"type": "output_text", "text": text, "annotations": []}],
            }
        ],
        "usage": usage,
        "error": None,
        "incomplete_details": None,
    }


async def _responses_stream(
    response_id: str, text: str, usage: dict[str, Any], model: str
) -> AsyncIterator[str]:
    yield _sse(
        "response.created",
        {
            "type": "response.created",
            "response": {
                "id": response_id,
                "object": "response",
                "status": "in_progress",
                "model": model,
            },
        },
    )
    for part in [text[i : i + 12] for i in range(0, len(text), 12)]:
        yield _sse(
            "response.output_text.delta",
            {"type": "response.output_text.delta", "delta": part},
        )
        await asyncio.sleep(0.01)
    yield _sse(
        "response.completed",
        {
            "type": "response.completed",
            "response": {
                "id": response_id,
                "object": "response",
                "status": "completed",
                "model": model,
                "output": [
                    {
                        "type": "message",
                        "id": "mock_msg_stream",
                        "status": "completed",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": text}],
                    }
                ],
                "usage": usage,
                "incomplete_details": None,
            },
        },
    )


# --------------------------------------------------------------------- Messages
@app.post("/v1/messages")
async def messages(request: Request):
    body = await request.json()
    async with _lock:
        _state["messages_requests"] += 1
        _state["last_paths"].append("/v1/messages")
        _state["last_paths"] = _state["last_paths"][-20:]

    status = await _consume_failure("fail_messages")
    if status is not None:
        return JSONResponse(
            status_code=status,
            content={"type": "error", "error": {"type": "api_error", "message": "mock failure"}},
        )
    await _delay()

    text = "MOCK-MESSAGES: " + (_last_user_text(body)[:120] or "ok")
    message_id = "mock_msg_" + uuid.uuid4().hex[:12]
    usage = {
        "input_tokens": 12,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "output_tokens": 8,
        "output_tokens_details": {"thinking_tokens": 0},
    }
    if body.get("tools"):
        tool_name = (body.get("tools") or [{}])[0].get("name", "mock_tool")
        content = [
            {
                "type": "tool_use",
                "id": "mock_tool_" + uuid.uuid4().hex[:8],
                "name": tool_name,
                "input": {"mock": True},
            }
        ]
        stop_reason = "tool_use"
    else:
        content = [{"type": "text", "text": text}]
        stop_reason = "end_turn"

    if body.get("stream"):
        return StreamingResponse(
            _messages_stream(message_id, content, usage, stop_reason, str(body.get("model") or "mock")),
            media_type="text/event-stream",
        )
    return {
        "id": message_id,
        "type": "message",
        "role": "assistant",
        "model": body.get("model") or "mock-messages",
        "content": content,
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "usage": usage,
    }


async def _messages_stream(
    message_id: str,
    content: list[dict[str, Any]],
    usage: dict[str, Any],
    stop_reason: str,
    model: str,
) -> AsyncIterator[str]:
    yield _sse(
        "message_start",
        {
            "type": "message_start",
            "message": {
                "id": message_id,
                "type": "message",
                "role": "assistant",
                "model": model,
                "content": [],
                "stop_reason": None,
                "usage": {**usage, "output_tokens": 0},
            },
        },
    )
    text = str(content[0].get("text") or "") if content else ""
    yield _sse(
        "content_block_start",
        {
            "type": "content_block_start",
            "index": 0,
            "content_block": {"type": "text", "text": ""},
        },
    )
    for part in [text[i : i + 12] for i in range(0, len(text), 12)]:
        yield _sse(
            "content_block_delta",
            {
                "type": "content_block_delta",
                "index": 0,
                "delta": {"type": "text_delta", "text": part},
            },
        )
        await asyncio.sleep(0.01)
    yield _sse(
        "content_block_stop", {"type": "content_block_stop", "index": 0}
    )
    yield _sse(
        "message_delta",
        {
            "type": "message_delta",
            "delta": {"stop_reason": stop_reason, "stop_sequence": None},
            "usage": usage,
        },
    )
    yield _sse("message_stop", {"type": "message_stop"})
