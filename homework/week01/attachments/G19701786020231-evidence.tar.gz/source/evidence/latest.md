# LLM Protocol Gateway · 验证明细

- 开始：`2026-11-26T22:41:46`
- 结束：`2026-11-26T22:42:05`，耗时 19.79s
- 结果：**15/15 PASS**
- 网关：`http://127.0.0.1:50148`，mock 上游：`http://127.0.0.1:50147`
- 复现：`py scripts/verify.py`（日志见 `evidence/logs/`）

| # | 检查项 | 结果 | 耗时 | 关键证据 |
| --- | --- | --- | --- | --- |
| 1 | 健康检查与就绪检查 | **PASS** | 6.1 ms | models=4 |
| 2 | 两个模型按 model 字段路由到不同协议 | **PASS** | 2.3 ms | deepseek-v4-pro→openai_responses, deepseek-flash→anthropic_messages, probe-retry→openai_responses, probe-ratelimit→opena |
| 3 | 真实上游可用且包含目标模型 | **PASS** | 689.6 ms | deepseek-flash, deepseek-v4-pro |
| 4 | OpenAI Responses 协议非流式调用 | **PASS** | 1298.7 ms | PRO-OK |
| 5 | Anthropic Messages 协议非流式调用 | **PASS** | 577.0 ms | FLASH-OK |
| 6 | Responses 协议 SSE 流式 + 首 Token 延迟 | **PASS** | 1141.1 ms | events=26, delta=7, text=1, 2, 3, ttft=660.13ms |
| 7 | Messages 协议 SSE 流式 + 首 Token 延迟 | **PASS** | 709.4 ms | events=9, delta=7, text=1, 2, 3, ttft=592.45ms |
| 8 | Responses 协议 json_schema 结构化输出 | **PASS** | 2143.4 ms | {'city': 'Hangzhou', 'temp_c': 18.5, 'conditions': 'partly cloudy'} |
| 9 | Messages 协议强制 tool_use 结构化输出 | **PASS** | 757.8 ms | {'city': 'Hangzhou', 'temp_c': 23.5, 'conditions': 'Partly cloudy'} |
| 10 | 模板创建、不可变版本、变量替换、版本引用 | **PASS** | 1022.7 ms | TPL-V1-alpha / TPL-V2-beta |
| 11 | 统一错误码：未知模型 / 非法 Schema | **PASS** | 6.8 ms | MODEL_NOT_FOUND / INVALID_REQUEST |
| 12 | 指数退避重试两次后成功 | **PASS** | 2410.3 ms | attempts=3, delays=[190.9, 341.0] |
| 13 | 重试次数上限 3 次后返回统一错误 | **PASS** | 2285.6 ms | attempts=3, code=UPSTREAM_ERROR |
| 14 | 按模型独立限流，超限 429 | **PASS** | 1087.4 ms | 前两次=[200, 200], 第三次=429, Retry-After=30 |
| 15 | Token 分类统计 / 延迟 / 首 Token / 重试轨迹 | **PASS** | 15.1 ms | checked=12, ttft=[660.127, 592.449] |

## 证据说明

- 每个检查项的完整请求/响应摘要位于同名 JSON 报告的 `checks[].evidence`。
- 流式检查同时验证了 SSE 事件序列、累计文本、done.usage 与 `ttft_ms <= latency_ms`。
- 重试检查由 mock 上游注入 2 次 503，验证 3 次尝试、两次递增退避以及观测记录。
- 限流检查使用 `probe-ratelimit`（2 请求/分钟）触发 429，并立刻调用 `deepseek-flash` 证明限流互不影响。
- 所有真实调用均为小 `max_tokens` 请求，Key 仅从 `.env` 读取，不写入报告。
