# 第一周作业评测附件

- 学员：陵宴；学号：G19701786020231；平台记录号：19553。
- 仓库：https://github.com/Ninshar/llm-protocol-gateway （提交原文无子目录、无指定提交）。
- 分支与提交号：默认分支 `main`，本 orb 实际克隆时最新提交 `d12350e58661103adf68f72a7a629bdc2d51b31f`，提交时间 `2026-11-26T22:43:19+08:00`。
- 课程仓库：`zhyg/ai-agent-fullstack-training`；已执行 `git fetch origin feat/guide && git checkout feat/guide`，HEAD 为 `cd7c2e08510aac4ab56b4d4ef2ffc1eb33b22893`，祖先核对退出码 0。
- 评测日期：2026-11-27，Asia/Singapore（UTC+08:00）；日志原始时间为 UTC。真实原验收于 UTC 06:56 左右执行。
- 总分：**94/100**，非暂评分。
- 作业等级：**优秀**（仅按总分 ≥80 判断）。
- 验收结论：**通过，需修复**。双模型、双协议与六项功能均具可复现运行证据，存在下述边界缺陷。
- 实施边界：本人独立完成；未创建子线程或子代理，未提交/推送，未回填平台，未写课程 `homework/`；未改学员业务源码、原测或可信原始断言。原脚本会自行更新其克隆目录下的 `evidence/`，归档快照仍取原提交。

## 评分明细

按评分标准 2.1、3.1、第 5 节和第 8 节最后八条同类口径核分；测试通过率不换算成分数。

| 评分项 | 得分 | 子项拆分与依据、扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 15/15 | 统一入口 3/3；model 路由 4/4；双协议 4/4；统一结果 4/4。真实请求分别走 `/responses` 的 input/text.format 与 `/anthropic/v1/messages` 的 messages/tools；未知模型 404。 |
| 流式输出 | 15/15 | 双模型 SSE 5/5；真实增量 5/5；终止与错误 3/3；输出后不重试 2/2。真实流式成功；教师门控等待下游收到首块才释放上游终态，双协议均通过；EOF/显式 error 均 error、无 done、仅一次上游调用。 |
| 结构化输出 | 10/10 | 双协议正常流程 4/4；JSON 校验 3/3；失败处理 3/3。真实 Schema 输出通过；离线 json_object、非法/空/截断 JSON、字段类型错误均正确处理。不因引用异常重复扣结构化分。 |
| 提示词版本管理 | 10/10 | 存储 3/3；变量替换 3/3；旧版本 2/2；缺失处理 2/2。原验收与补测证明 v1/v2 实际进入上游请求、缺失项不调用上游。 |
| 可观测性 | 13/15 | Token 3/5；总延迟及 TTFT 4/4；请求关联与查询 3/3；失败记录 3/3。已知失败用量丢失扣 1；未知用量未作未知区分扣 1。失败记录本身存在，不再扣失败记录分。 |
| 统一错误与重试 | 12/15 | 错误结构/映射 2/4（上游 401/403→502 同根因合扣 1；无效本地引用→500 扣 1）；指数退避 3/4（正向抖动超上限扣 1）；次数上限 3/3；不可重试处理 3/3；轨迹可验证 1/1。 |
| 按模型独立限流 | 10/10 | 独立计数 4/4；429 3/3；恢复 2/2；可配置 1/1。受控 HTTP 验证限额 A 后 B 可用，按令牌补充恢复。 |
| 源码、README 与验证脚本 | 9/10 | 源码依赖 2/2；启动指南 2/3（pytest 安装指引缺失扣 1）；curl 2/2；六项断言脚本 3/3。requirements-dev.txt 实际存在，仅文档未指明；不因同根因再扣依赖或断言分。 |
| **合计** | **94/100** | **15+15+10+10+13+12+10+9=94；共扣 6 分。** |

## 环境、导入路径与命令

实际工作目录：`/home/user/workspace/repo/.amp/in/orb-backup/lingyan/source`；独立 venv：同级 `../venv`。没有使用课程仓库同名 app 包。实际导入：

`/home/user/workspace/repo/.amp/in/orb-backup/lingyan/source/app/__init__.py`

Linux x86_64，Python 3.13.5，FastAPI 0.165.0，httpx 0.29.0，Pydantic 2.14.4，pytest 9.2.0，jsonschema 4.26.0，uvicorn 0.54.0。README 要求 Python 3.11+，此次版本满足。全量依赖见包内 `logs/dependencies.txt`。

| 实际执行命令或检查 | 退出码 | 结果及证据（以下为证据包内路径） |
| --- | ---: | --- |
| `git fetch origin feat/guide && git checkout feat/guide`；`git rev-parse HEAD`；`git merge-base --is-ancestor cd7c2e08510aac4ab56b4d4ef2ffc1eb33b22893 HEAD` | 0 | 指定课程基线；`metadata.json` 与 `course/` 保存依据。 |
| `git clone https://github.com/Ninshar/llm-protocol-gateway .amp/in/orb-backup/lingyan/source` | 0 | 实际 clone，默认分支 main，提交号如首节。 |
| `python3 -m venv ../venv`；`../venv/bin/python -m pip install -r requirements.txt` | 0 | 干净隔离环境安装成功，`logs/install.log`。 |
| `../venv/bin/python -m pytest -q`（仅安装 requirements.txt 后） | 1 | `No module named pytest`，`logs/pytest-readme.log`。 |
| `../venv/bin/python -m pip install -r requirements-dev.txt` | 0 | `logs/install-dev.log`。 |
| `../venv/bin/python -m pytest -q`（补装后、原断言不变） | 0 | **21 passed in 0.35s**，`logs/pytest.log`。 |
| `../venv/bin/python scripts/verify.py` | 0 | **15/15 PASS**，`logs/verify.log`、`logs/verify-exit.log` 与 `real-run/verification-20261127-065606.{json,md}`。 |
| `venv/bin/python supplement.py`（父目录执行） | 0 | 37 个探针：30 PASS、7 个缺陷触发记录；同根因合并后如评分表，`logs/supplement.log`、`supplement-results.json`。退出码 0 表示探针执行完成，不代表没有缺陷。 |
| 导入原 verify.py，调用原 `run_check` 与原 `expect(False, ...)` 作受控失败注入 | 0 | 原断言报告 `[FAIL] ... injected failed assertion`；教师检查其状态确为 FAIL，见 `logs/failure-injection.log`。未修改断言。 |
| `git -C source diff --exit-code -- app tests scripts` | 0 | 原业务、原测与验收脚本未改；另以提交 blob 对比校验，见 `integrity.json`。 |

## 验证结果

### 启动与双协议真实调用

原验收脚本按 README 的 `app.main:app` 启动 uvicorn，健康和就绪检查通过。真实调用只使用环境内 `DEEPSEEK_API_KEY` 和 DeepSeek 官方域名；密钥存在，无需刷新进程，没有打印或归档密钥。原验收涉及真实流程的调用保留；教师离线补测完全不访问真实模型。

| 模型别名 → 实际上游模型 | 协议与地址 | 本次真实调用证据 |
| --- | --- | --- |
| deepseek-v4-pro → deepseek-v4-pro | Responses，`https://api.deepseek.com/responses` | 普通输出 `PRO-OK`；request_id `req_4219af324150d4e937d15a06`；HTTP 200、attempts=1；输入/输出/总 Token=11/16/27、reasoning=12；总延迟 1294.85ms。 |
| deepseek-flash → deepseek-flash | Anthropic Messages，`https://api.deepseek.com/anthropic/v1/messages` | 普通输出 `FLASH-OK`；request_id `req_0c860da56aa0a4683b3345c8`；HTTP 200、attempts=1；输入/输出/总 Token=12/4/16；总延迟 773.79ms。 |

- 真实流式：Responses request_id `req_9979eafb08f0edcbe63eaf74`，正文 `1, 2, 3`，62 事件/7 delta，TTFT 795.28ms、总延迟 1852.51ms；Messages request_id `req_cd51813ebbc716aacaa48180`，同正文，9 事件/7 delta，TTFT 484.11ms、总延迟 663.76ms。
- TTFT 按 README 明示的首个非空 delta/reasoning 记录；不因先有推理再有正文扣分。
- 真实结构化：Responses request_id `req_6d60c8844218b071acfef37f`、Messages request_id `req_baf0d7e292275c049e85abfd` 均经原脚本 JSON 解析及 weather Schema 校验通过，细节见 real-run JSON。
- 原脚本不是静态截图或既有 passed 报告：本次重新执行产生了上述新 request_id、日志与报告。原提交已有的 `source/evidence/` 仅作快照，不作为本次运行替代。

### 六项功能的受控验证

- **流式**：补测启动真实 uvicorn 网关和 HTTP 下游客户端，只将上游 transport 替换为受控 httpx 流。首内容“先A”由客户端实际读到后才释放上游终态，随后才到“后B”与 done。双协议都通过，排除了全量缓冲伪流式。元数据和空 delta 没有当首 Token。两个协议的 EOF 和显式 error 均仅一次调用、只下发 error、不发成功 done，账本记 error。Messages 累计输出快照 7→9 最终输出 9 而不是 16。
- **结构化**：统一 response_format 的 json_object 正常流程、json_schema 正常流程、非法正文 `not-json`、空正文、`{"city":` 截断正文和 city 数值型均覆盖；后四者均被拒为 STRUCTURED_OUTPUT_INVALID。合法本地引用正常；无效本地引用见缺陷 D2。
- **模板**：创建 v1、追加 v2，显式引用都核对真实组装的上游 input 文本；无模板、无版本、缺变量均明确拒绝且无上游请求。
- **可观测**：正常两协议非对称 Token、分类、总量和流式快照检查通过；成功、失败与限流记录可按 request_id 查询。失败已知用量和未知语义见 D4。
- **重试**：前两次 503 后成功，共 3 次上游实际调用；持续 503 到 3 次结束；400/401/403/422 均一次即停。无 SDK 重试叠加。退避正向抖动缺陷见 D3。
- **限流**：教师配置 A 为 burst=1、60/min；请求 A、A、B、等待 1.05s 后 A，HTTP 顺序 **200、429、200、200**；429 带错误码和 Retry-After。没有用真实上游额度制造异常。
- **脚本失败检测**：只在运行时调用原断言报告入口注入失败，原 CHECKS 为 FAIL 且有清晰输出；没有修改可信测试，也没有为失败退出码另设扣分。

### 状态划分

- **已确认缺陷**：D1–D5 如下，均有实际运行证据；双协议或多个输入复现的同根因只计一次。
- **未执行/被接口阻断**：本次核心验收没有该类阻断。第二协议可用 DeepSeek 官方接口真实调用，不需要暂评或把环境原因计为缺陷。
- **未验证**：未遍历全部 JSON Schema 关键字、所有消息组合、客户端主动断开的释放时序，以及服务端多进程/分布式场景。未声称全面证明这些扩展；不据此扣分。非标准 JSON 常量按标准 B01 不设额外门槛。

## 待修复问题与最小复现

统一最小复现入口：解压证据包后，在包根目录创建 venv、安装 `source/requirements-dev.txt`，运行 `python supplement.py`；脚本自动导入相邻 `source/app`，使用独立临时配置/数据库，运行后停止网关。只需依赖，不需真实密钥。完整输入与响应见 `supplement-results.json` 中同名记录。

### D1：上游鉴权错误映射为 502（已确认）

- 所属评分项：统一错误与重试 → 错误结构/状态映射。
- 触发条件：上游返回 401 或 403，JSON `{"error":{"message":"controlled rejection"}}`。
- 预期：明确统一 4xx 错误；不可重试。
- 实际：HTTP 502，code=UPSTREAM_AUTH_ERROR、retryable=false，每个场景仅一次上游调用。
- 复现：`supplement.py` 的 `upstream-401-mapping` / `upstream-403-mapping`。源码 `source/app/errors.py:155–158` 采用默认 502。
- 扣分：**1**。严格采用第 8 节上游 4xx→502 的同类口径；两种状态不叠扣，也不扣统一接口和不可重试子项。

### D2：无效 Schema 本地引用导致内部 500（已确认）

- 所属评分项：统一错误与重试 → 错误处理。
- 触发条件：统一入口 response_format 为 `{"type":"json_schema","json_schema":{"schema":{"type":"object","properties":{"city":{"$ref":"#/$defs/missing"}}}}}`；受控上游正文 `{"city":"Singapore"}`。
- 预期：明确的无效 Schema/引用 4xx，而非内部 500。
- 实际：HTTP 500、code=INTERNAL_ERROR，包含 PointerToNowhere 引用解析异常；对照 `#/$defs/city` 配置有效 `$defs` 时 HTTP 200。
- 复现：`badref` / `goodref`；异常堆栈在 `logs/supplement.log` 与 `logs/supplement-gateway.log`。源码 `source/app/adapters/base.py:128–151` 仅检查 schema 结构，没有拦截引用解析异常；`source/app/service.py` 将其兜底为 INTERNAL_ERROR。
- 扣分：**1**。按第 8 节本地引用示例，不在结构化子项重复扣分。

### D3：正向抖动超过当次等待上限（已确认）

- 所属评分项：统一错误与重试 → 指数退避。
- 触发条件：base=0.5s、cap=0.5s、jitter=0.2s，受控随机来源返回合法上界 0.2；前两次失败、第三次成功。
- 预期：第 n 次等待不超过 `min(cap, base*2^(n-1))`，两次均 ≤0.5s。
- 实际：等待记录 **[0.7, 0.7]**，共 3 次尝试。只注入随机值和记录 sleep，不修改业务公式。
- 复现：`backoff-cap`；源码 `source/app/retry.py:46–49` 先 min 后加抖动；README 也明示该公式。
- 扣分：**1**，按本批统一口径；尝试次数与轨迹正常，保留相应分值。

### D4：用量账本不完整且未知语义不明确（已确认）

- 所属评分项：可观测性 → Token 总量及分类。
- 触发 A：上游 HTTP 200，正文非法 JSON（结构化调用），但携带已知 usage。Responses 输入/输出=17/9；Messages 归一后同为17/9。
- 预期：请求应失败，但账本仍保留已知 Token=17/9/26。
- 实际：错误处理正确，记录状态 error、请求关联正常；账本输入/输出/总 Token 全为 0，丢失已知消耗。`pro-known-usage-on-failure` 和 `flash-known-usage-on-failure` 为同根因，仅扣 **1**。
- 触发 B：普通成功调用的上游缺少 usage。
- 预期：null 或文档明示 0 表示“未提供”。
- 实际：所有分类返回 0；README Token 口径未定义未知语义，容易与真实零消耗混淆。`missing-usage-is-unknown`，扣 **1**。
- 源码：`source/app/service.py:206–238,599–615` 在解析失败时未携带 usage；`source/app/adapters/base.py` 的归一与 `source/app/schemas.py` 默认零；README 473–479 为 Token 文档。
- 合扣：**2**。不重复扣“失败调用记录”，因为失败记录本身存在。该问题不同于 EOF 假成功（本项目 EOF 处理正确）。

### D5：README 未指明测试依赖安装步骤（已确认）

- 所属评分项：源码、README 与验证脚本 → 启动指南。
- 触发：新 venv 只按 README 安装 `requirements.txt`，执行 README 的 `python -m pytest -q`。
- 预期：文档覆盖运行其单元测试所需依赖。
- 实际：退出码 1、`No module named pytest`；补装仓库已有的 `requirements-dev.txt` 后，可信原测 **21 passed**、退出码 0。
- 复现证据：`logs/pytest-readme.log`、`logs/install-dev.log`、`logs/pytest.log`；README 93–96、130–135。
- 扣分：**1**。只扣指南；应用本身可启动，依赖文件实际存在，不额外扣源码依赖、验证断言或整个启动项。

## 补交要求与复验条件

- 必须修复：D1 的 4xx 映射，D2 的无效引用错误处理，D3 的退避抖动边界，D4 的失败及未知用量口径，D5 的测试安装指引。
- 必须补充：相应回归断言；无效引用需有有效引用对照；用量需分别验证“已知但正文失败”和“上游未提供”；退避采用可控随机来源验证上限。
- 复验通过：上述缺陷探针达到预期，原 21 项离线断言与六项验收保持通过；无需用真实 API 重复制造离线异常。
- 本次真实双协议正常流程证据已齐，无需以“缺少第二协议凭据”为由补交或暂评。

## 证据包说明

- `source/`：从原提交 git archive 导出的完整可信源码、README、配置及原测，未包含 .git、虚拟环境、依赖目录或运行生成文件。原提交自带 evidence 保留，并明确不冒充本次证据。
- `source/tests/`：可信原测，未修改断言；课程 week01 没有另附原始统一测试文件，不虚构原测数量。
- `real-run/`：本次原脚本运行的新报告、日志；`logs/`：安装、原测、补测及失败注入记录。
- `supplement.py`、`supplement-results.json`：独立补测脚本和完整结果；只注入测试上游和可控随机来源。
- `course/`：本次完整阅读的题目、标准、反馈模板。
- `metadata.json`、`integrity.json`、`SHA256SUMS`：评测元数据、原文件完整性与包内逐文件校验。
- `feedback.md`、`evaluation.md`：与交付的两份 Markdown 同版。
- 包内无真实密钥、.env、venv、node_modules。打包前按当前真实密钥值做精确匹配扫描；不输出密钥。仅包含明确的离线假凭据占位符和原仓库 env 示例。
