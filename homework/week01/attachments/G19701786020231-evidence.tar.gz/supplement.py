"""Teacher-controlled HTTP acceptance; no edits to student source or original assertions."""
import asyncio
import collections
import contextlib
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "source"))
import httpx
import uvicorn
import yaml
from app.main import app, lifespan
from app.config import RetryConfig
from app.errors import GatewayError
from app.retry import run_with_retry

counts = collections.Counter()
requests = []
gate = threading.Event()
results = []

def emit(name, passed, evidence):
    item = {"name": name, "status": "PASS" if passed else "CONFIRMED_DEFECT", "evidence": evidence}
    results.append(item)
    print(json.dumps(item, ensure_ascii=False), flush=True)

def event(kind, data):
    return f"event: {kind}\ndata: {json.dumps(data)}\n\n".encode()

def upstream_body(protocol, text="OK", usage=True):
    if protocol == "responses":
        body = {"id": "resp-teacher", "model": "offline-pro", "status": "completed",
                "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}]}
        if usage:
            body["usage"] = {"input_tokens": 17, "output_tokens": 9, "total_tokens": 26,
                             "input_tokens_details": {"cached_tokens": 3},
                             "output_tokens_details": {"reasoning_tokens": 2}}
    else:
        body = {"id": "msg-teacher", "model": "offline-flash", "type": "message",
                "content": [{"type": "text", "text": text}], "stop_reason": "end_turn"}
        if usage:
            body["usage"] = {"input_tokens": 11, "output_tokens": 9,
                             "cache_creation_input_tokens": 2, "cache_read_input_tokens": 4,
                             "output_tokens_details": {"thinking_tokens": 2}}
    return body

class ControlledStream(httpx.AsyncByteStream):
    def __init__(self, protocol, scenario):
        self.protocol, self.scenario = protocol, scenario

    async def __aiter__(self):
        # Include metadata and empty deltas before the first effective content.
        if self.protocol == "responses":
            yield event("response.created", {"response": {"id": "resp-stream"}})
            yield event("response.output_text.delta", {"delta": ""})
            yield event("response.output_text.delta", {"delta": "先A"})
        else:
            yield event("message_start", {"message": {"id": "msg-stream", "usage": upstream_body("messages")["usage"]}})
            yield event("content_block_delta", {"delta": {"type": "text_delta", "text": ""}})
            yield event("content_block_delta", {"delta": {"type": "text_delta", "text": "先A"}})
        if self.scenario == "gate":
            released = await asyncio.to_thread(gate.wait, 4)
            if not released:
                raise httpx.ReadError("teacher gate timeout")
        if self.scenario == "eof":
            return
        if self.scenario == "error":
            yield event("error", {"error": {"message": "controlled stream failure"}})
            return
        if self.protocol == "responses":
            yield event("response.output_text.delta", {"delta": "后B"})
            yield event("response.completed", {"response": upstream_body("responses", "先A后B")})
        else:
            yield event("content_block_delta", {"delta": {"type": "text_delta", "text": "后B"}})
            yield event("message_delta", {"delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 7}})
            yield event("message_delta", {"delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 9}})
            yield event("message_stop", {})

async def transport(req):
    body = json.loads(req.content)
    protocol = "responses" if req.url.path == "/responses" else "messages"
    if protocol == "responses":
        prompt = " ".join(b["text"] for m in body["input"] for b in m["content"])
    else:
        prompt = " ".join(m["content"] for m in body["messages"])
    scenario = prompt
    counts[(body["model"], scenario)] += 1
    n = counts[(body["model"], scenario)]
    requests.append({"path": req.url.path, "body": body})
    if scenario in ("400", "401", "403", "422"):
        return httpx.Response(int(scenario), json={"error": {"message": "controlled rejection"}})
    if scenario == "always503" or (scenario == "retry" and n <= 2):
        return httpx.Response(503, json={"error": {"message": "controlled temporary failure"}})
    if body.get("stream"):
        return httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=ControlledStream(protocol, scenario))
    text = {"invalid": "not-json", "empty": "", "truncated": '{"city":',
            "schema-invalid": '{"city": 8}', "json": '{"city":"Singapore"}',
            "badref": '{"city":"Singapore"}', "goodref": '{"city":"Singapore"}'}.get(scenario, "OK")
    return httpx.Response(200, json=upstream_body(protocol, text, usage=scenario != "missing-usage"))

config = {"storage": {"db_path": str(ROOT / "supplement.db"), "log_path": str(ROOT / "supplement-gateway.log")},
          "retry": {"max_attempts": 3, "base_delay_s": .001, "max_delay_s": .01, "jitter_s": 0},
          "models": {}}
for name, protocol in [("pro", "openai_responses"), ("flash", "anthropic_messages"), ("limited", "openai_responses")]:
    config["models"][name] = {"adapter": protocol, "base_url": "http://teacher.invalid", "api_key": "offline-placeholder",
        "upstream_model": name, "rate_limit": {"requests_per_minute": 60 if name == "limited" else 0, "burst": 1}}
config_path = ROOT / "supplement-config.yaml"
config_path.write_text(yaml.safe_dump(config))
os.environ["GATEWAY_CONFIG"] = str(config_path)
for suffix in ("", "-wal", "-shm"):
    (ROOT / ("supplement.db" + suffix)).unlink(missing_ok=True)

@contextlib.asynccontextmanager
async def controlled_lifespan(a):
    async with lifespan(a):
        async with httpx.AsyncClient(transport=httpx.MockTransport(transport)) as controlled:
            a.state.service.client = controlled
            yield

app.router.lifespan_context = controlled_lifespan
sock = socket.socket()
sock.bind(("127.0.0.1", 0))
port = sock.getsockname()[1]
server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
thread = threading.Thread(target=server.run, kwargs={"sockets": [sock]})
thread.start()
for _ in range(100):
    if server.started:
        break
    time.sleep(.02)

client = httpx.Client(base_url=f"http://127.0.0.1:{port}", timeout=8)

def chat(model="pro", prompt="OK", **fields):
    return client.post("/v1/chat", json={"model": model, "messages": [{"role": "user", "content": prompt}], **fields})

def record(response):
    return client.get("/v1/observability/calls/" + response.headers["x-request-id"]).json()

try:
    r = chat(model="unknown")
    emit("unknown-model", r.status_code == 404 and r.json()["error"]["code"] == "MODEL_NOT_FOUND", r.json())
    for model in ("pro", "flash"):
        r = chat(model)
        obs = record(r)
        emit(f"{model}-normal", r.status_code == 200 and r.json()["output_text"] == "OK" and obs["total_tokens"] == 26,
             {"response": r.json(), "record": obs, "upstream": requests[-1]})
        r = chat(model, "json", response_format={"type": "json_object"})
        emit(f"{model}-structured", r.status_code == 200 and json.loads(r.json()["output_text"]) == {"city": "Singapore"}, r.json())
        for prompt in ("invalid", "empty", "truncated", "schema-invalid"):
            fmt = {"type": "json_schema", "json_schema": {"name": "city", "schema": {
                "type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}}}
            r = chat(model, prompt, response_format=fmt)
            emit(f"{model}-{prompt}-rejection", r.status_code == 502 and r.json()["error"]["code"] == "STRUCTURED_OUTPUT_INVALID", r.json())
            if prompt == "invalid":
                obs = record(r)
                emit(f"{model}-known-usage-on-failure", obs["input_tokens"] == 17 and obs["output_tokens"] == 9,
                     {"known_upstream_usage": upstream_body("responses" if model == "pro" else "messages")["usage"], "record": obs})
        for scenario in ("gate", "eof", "error"):
            gate.clear()
            events = []
            saw_before_terminal = False
            started = time.perf_counter()
            with client.stream("POST", "/v1/chat", json={"model": model, "messages": [{"role": "user", "content": scenario}], "stream": True}) as r:
                kind = None
                for line in r.iter_lines():
                    if line.startswith("event:"):
                        kind = line.split(":", 1)[1].strip()
                    elif line.startswith("data:"):
                        events.append({"event": kind, "data": json.loads(line[5:]), "elapsed_ms": round((time.perf_counter()-started)*1000, 2)})
                        if kind == "delta" and not gate.is_set():
                            saw_before_terminal = True
                            gate.set()
                rid = r.headers["x-request-id"]
            obs = client.get("/v1/observability/calls/" + rid).json()
            kinds = [e["event"] for e in events]
            ok = (saw_before_terminal and kinds.count("delta") == 2 and kinds[-1] == "done" and obs["total_tokens"] == 26) if scenario == "gate" else (kinds[-1] == "error" and "done" not in kinds and obs["status"] == "error")
            emit(f"{model}-stream-{scenario}", ok and counts[(model, scenario)] == 1, {"events": events, "record": obs, "upstream_attempts": counts[(model, scenario)]})
    for status in (400, 401, 403, 422):
        r = chat(prompt=str(status))
        emit(f"upstream-{status}-mapping", 400 <= r.status_code < 500 and counts[("pro", str(status))] == 1,
             {"http_status": r.status_code, "response": r.json(), "upstream_attempts": counts[("pro", str(status))]})
    for prompt, expected_status in [("retry", 200), ("always503", 502)]:
        r = chat(prompt=prompt)
        emit(prompt, r.status_code == expected_status and counts[("pro", prompt)] == 3, {"status": r.status_code, "body": r.json(), "record": record(r), "actual_calls": counts[("pro", prompt)]})
    for name, schema in [("goodref", {"type": "object", "properties": {"city": {"$ref": "#/$defs/city"}}, "$defs": {"city": {"type": "string"}}}),
                         ("badref", {"type": "object", "properties": {"city": {"$ref": "#/$defs/missing"}}})]:
        r = chat(prompt=name, response_format={"type": "json_schema", "json_schema": {"schema": schema}})
        emit(name, r.status_code == 200 if name == "goodref" else 400 <= r.status_code < 500, {"http_status": r.status_code, "body": r.json()})
    a = chat("limited")
    b = chat("limited")
    c = chat("flash")
    time.sleep(1.05)
    d = chat("limited")
    emit("rate-limit-isolation-recovery", [a.status_code,b.status_code,c.status_code,d.status_code] == [200,429,200,200], {"statuses": [a.status_code,b.status_code,c.status_code,d.status_code], "limited": b.json()})
    client.post("/v1/templates", json={"name": "teacher", "content": "V1-{{who}}"}).raise_for_status()
    client.post("/v1/templates/teacher/versions", json={"content": "V2-{{who}}"}).raise_for_status()
    for version in (1, 2):
        r = client.post("/v1/chat", json={"model": "pro", "template": {"name": "teacher", "version": version, "variables": {"who": "Singapore"}}})
        emit(f"template-v{version}-to-upstream", r.status_code == 200 and requests[-1]["body"]["input"][0]["content"][0]["text"] == f"V{version}-Singapore", {"upstream": requests[-1], "template": r.json().get("meta",{}).get("template")})
    for ref in [{"name": "absent"}, {"name": "teacher", "version": 99}, {"name": "teacher", "version": 1}]:
        before = len(requests)
        r = client.post("/v1/chat", json={"model": "pro", "template": ref})
        emit("template-missing-" + str(ref), r.status_code in (404,422) and len(requests) == before, r.json())
    r = chat(prompt="missing-usage")
    emit("missing-usage-is-unknown", r.json()["usage"]["total_tokens"] is None, {"upstream_usage": "absent", "returned_usage": r.json()["usage"], "note": "README does not define zero as unknown"})
    async def check_backoff():
        calls = 0
        sleeps = []
        async def operation():
            nonlocal calls
            calls += 1
            if calls < 3:
                raise GatewayError("UPSTREAM_ERROR", "teacher temporary")
            return "ok"
        async def sleep(delay):
            sleeps.append(delay)
        with patch("app.retry.random.uniform", return_value=.2):
            await run_with_retry(operation, RetryConfig(max_attempts=3, base_delay_s=.5, max_delay_s=.5, jitter_s=.2), model="teacher", sleep=sleep)
        return calls, sleeps
    calls, sleeps = asyncio.run(check_backoff())
    emit("backoff-cap", all(s <= .5 for s in sleeps), {"calls": calls, "sleeps": sleeps, "allowed_cap": .5})
finally:
    gate.set()
    client.close()
    server.should_exit = True
    thread.join(10)
    (ROOT / "supplement-results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(f"SUMMARY checks={len(results)} confirmed_defect_probes={sum(r['status'] != 'PASS' for r in results)}")
