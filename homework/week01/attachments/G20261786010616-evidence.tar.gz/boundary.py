import asyncio, json, os, sys
from pathlib import Path
import httpx
import probe as p
from app.config import load_config
from app.main import create_app
from pydantic import SecretStr

async def main():
    servers=[]
    try:
        servers.append(await p.start(p.mock,18617))
        app=create_app(p.cfg());servers.append(await p.start(app,18618))
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18618') as c:
            before=(await c.get('/v1/usage/recent')).json()
            for ref in [{'id':'absent'},{'id':'absent','version':2}]:
                r=await c.post('/v1/chat/completions',json=p.body(gateway_prompt=ref))
                p.log('missing-template-ledger',status=r.status_code,request_id=r.headers.get('x-request-id'),response=r.json())
            after=(await c.get('/v1/usage/recent')).json()
            p.log('missing-template-ledger-count',before=len(before),after=len(after))
        real=load_config(p.ROOT/'student/gateway.example.yaml')
        real.database_url=str(p.ROOT/'default-real.db')
        real.retry.max_attempts_per_route=1
        for x in real.providers.values():x.api_key=SecretStr(os.environ['DEEPSEEK_API_KEY'])
        servers.append(await p.start(create_app(real),18619))
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18619',timeout=30) as c:
            for name in ['smart','fast']:
                r=await c.post('/v1/chat/completions',json=p.body(name,max_tokens=32,thinking={'type':'disabled'}))
                p.log('default-alias-real',model=name,status=r.status_code,response=r.json())
    finally:
        for s,t in reversed(servers):s.should_exit=True
        for s,t in reversed(servers):await t
        (p.OUT/'boundary.json').write_text(json.dumps(p.records,ensure_ascii=False,indent=2))
if __name__=='__main__':asyncio.run(main())
