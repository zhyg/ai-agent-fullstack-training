from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request, Response, status
from fastapi.responses import JSONResponse, StreamingResponse

from app.core.errors import GatewayError
from app.core.security import authenticate
from app.schemas import (
    ChatCompletionRequest,
    ModelList,
    ModelObject,
    PromptCreate,
    PromptRecord,
    PromptReference,
    PromptRender,
    ResponsesRequest,
)
from app.services.gateway import GatewayService

router = APIRouter()

# SSE 必须禁缓存并关闭代理缓冲，否则反向代理会攒包导致首 token 变慢
STREAM_HEADERS = {
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


# 路由层只拿服务实例，仓储通过 service.prompts / service.usage 读取，避免状态重复挂载
def get_service(request: Request) -> GatewayService:
    return request.app.state.service


ServiceDep = Annotated[GatewayService, Depends(get_service)]
IdentityDep = Annotated[str, Depends(authenticate)]


# 两个入口协议共用同一套编排：注入提示词 → 流式透传或非流式返回
async def _dispatch(
    api: str,
    body: dict[str, Any],
    prompt_ref: PromptReference | None,
    stream: bool,
    request: Request,
    service: GatewayService,
    identity: str,
) -> Response:
    # gateway_prompt 是网关私有字段，无论是否注入模板都不能透传给上游
    body.pop("gateway_prompt", None)
    body, prompt_meta = await service.prepare_body(api, body, prompt_ref)
    if stream:
        chunks, request_id = await service.stream(api, body, identity, prompt_meta, request)
        return StreamingResponse(
            chunks,
            media_type="text/event-stream",
            headers={"X-Request-ID": request_id, **STREAM_HEADERS},
        )
    result, request_id = await service.call_json(api, body, identity, prompt_meta)
    return JSONResponse(result, headers={"X-Request-ID": request_id})


@router.post("/v1/chat/completions")
async def chat_completions(
    payload: ChatCompletionRequest,
    request: Request,
    service: ServiceDep,
    identity: IdentityDep,
) -> Response:
    body = payload.model_dump(exclude_none=True)
    return await _dispatch(
        "chat", body, payload.gateway_prompt, payload.stream, request, service, identity,
    )


@router.post("/v1/responses")
async def create_response(
    payload: ResponsesRequest,
    request: Request,
    service: ServiceDep,
    identity: IdentityDep,
) -> Response:
    body = payload.model_dump(exclude_none=True)
    return await _dispatch(
        "responses", body, payload.gateway_prompt, payload.stream, request, service, identity,
    )


# 模型列表只暴露配置里的别名，真实模型名与供应商属于内部信息
@router.get("/v1/models", response_model=ModelList)
async def list_models(request: Request, service: ServiceDep, _identity: IdentityDep) -> ModelList:
    created = getattr(request.app.state, "created_at", 0)
    return ModelList(
        data=[
            ModelObject(id=alias, created=created, owned_by=service.config.service_name)
            for alias in service.config.models
        ]
    )


# 存活探针不鉴权，方便容器编排在无密钥环境下探测
@router.get("/healthz", include_in_schema=False)
async def healthz(service: ServiceDep) -> dict[str, str]:
    return {"status": "ok", "service": service.config.service_name}


@router.post("/v1/prompts", response_model=PromptRecord, status_code=status.HTTP_201_CREATED)
async def create_prompt(
    payload: PromptCreate, service: ServiceDep, _identity: IdentityDep,
) -> PromptRecord:
    return await service.prompts.create_version(payload)


@router.get("/v1/prompts", response_model=list[PromptRecord])
async def list_prompts(service: ServiceDep, _identity: IdentityDep) -> list[PromptRecord]:
    return await service.prompts.list()


@router.get("/v1/prompts/{prompt_id}", response_model=PromptRecord)
async def get_prompt(
    prompt_id: str,
    service: ServiceDep,
    _identity: IdentityDep,
    version: int | None = Query(default=None, ge=1),
) -> PromptRecord:
    return await service.prompts.get(prompt_id, version)


# 渲染只回正文与版本，调用方拿不到数据库中其它字段
@router.post("/v1/prompts/{prompt_id}/render")
async def render_prompt(
    prompt_id: str, payload: PromptRender, service: ServiceDep, _identity: IdentityDep,
) -> dict[str, Any]:
    prompt, content = await service.prompts.render(prompt_id, payload.variables, payload.version)
    return {"id": prompt.id, "version": prompt.version, "content": content}


@router.get("/v1/usage/recent")
async def recent_usage(
    service: ServiceDep,
    _identity: IdentityDep,
    limit: int = Query(default=100, ge=1, le=1000),
) -> list[dict[str, Any]]:
    return await service.usage.recent(limit)


@router.get("/v1/router/status")
async def router_status(
    service: ServiceDep, _identity: IdentityDep,
) -> dict[str, dict[str, object]]:
    return service.router.status()


# 断线续传入口：没开快照或记录不存在都按 404 处理
@router.get("/v1/streams/{request_id}")
async def stream_checkpoint(
    request_id: str, service: ServiceDep, _identity: IdentityDep,
) -> dict[str, Any]:
    checkpoint = await service.usage.get_checkpoint(request_id)
    if checkpoint is None:
        raise GatewayError(
            f"Stream checkpoint {request_id!r} was not found",
            status_code=404,
            error_type="invalid_request_error",
            code="checkpoint_not_found",
        )
    return checkpoint

