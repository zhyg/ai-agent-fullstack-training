from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from app.config import Dialect
from app.services.adapters import STOP_REASONS


# 有状态解码器：SSE 行可能被拆到多个 chunk，必须自行缓冲
@dataclass
class StreamDecoder:
    dialect: Dialect
    _buffer: bytes = b""
    _event: str = ""
    _pending: dict[str, int] = field(default_factory=dict)

    # 累积字节并按行切分，返回本次可解析出的归一化事件
    def feed(self, chunk: bytes) -> list[dict[str, Any]]:
        self._buffer += chunk
        *lines, self._buffer = self._buffer.split(b"\n")
        events: list[dict[str, Any]] = []
        for line in lines:
            event = self._decode(line)
            if event is not None:
                events.append(event)
        return events

    # 连接结束时冲刷残留的半行
    def flush(self) -> list[dict[str, Any]]:
        if not self._buffer:
            return []
        rest, self._buffer = self._buffer, b""
        event = self._decode(rest)
        return [event] if event is not None else []

    def _decode(self, line: bytes) -> dict[str, Any] | None:
        text = line.decode("utf-8", "ignore").strip()
        if not text or text.startswith(":"):
            return None
        if text.startswith("event:"):
            self._event = text[6:].strip()
            return None
        if not text.startswith("data:"):
            return None
        data = text[5:].strip()
        if self.dialect == "openai":
            return self._openai(data)
        return self._anthropic(data)

    # OpenAI：data: [DONE] 收尾，其余从 choices[0].delta 取增量
    def _openai(self, data: str) -> dict[str, Any] | None:
        if data == "[DONE]":
            return {"type": "done"}
        payload = _loads(data)
        if payload is None:
            return None
        if payload.get("error"):
            return {"type": "error", "message": _message(payload)}
        if payload.get("usage"):
            return _usage_event(payload["usage"])
        choices = payload.get("choices") or [{}]
        text = (choices[0].get("delta") or {}).get("content")
        return {"type": "delta", "text": text} if text else None

    # Anthropic：按事件名分派，最终 usage 只认 message_delta
    def _anthropic(self, data: str) -> dict[str, Any] | None:
        payload = _loads(data)
        if payload is None:
            return None
        # 超时帧可能没有事件名，只有一个 error 对象
        if "error" in payload and "type" not in payload:
            return {"type": "error", "message": _message(payload)}
        event = payload.get("type") or self._event
        if event == "message_start":
            usage = (payload.get("message") or {}).get("usage") or {}
            cached = usage.get("cache_read_input_tokens") or 0
            self._pending = {
                # 缓存写入也属于输入成本，与 usage_from_payload 的统计口径保持一致
                "input_tokens": (
                    (usage.get("input_tokens") or 0)
                    + cached
                    + (usage.get("cache_creation_input_tokens") or 0)
                ),
                "cached_tokens": cached,
            }
            return None
        if event == "content_block_delta":
            delta = payload.get("delta") or {}
            if delta.get("type") == "text_delta" and delta.get("text"):
                return {"type": "delta", "text": delta["text"]}
            return None
        if event == "message_delta":
            usage = payload.get("usage") or {}
            finish = (payload.get("delta") or {}).get("stop_reason")
            return {
                "type": "usage",
                "input_tokens": self._pending.get("input_tokens", 0),
                "output_tokens": usage.get("output_tokens") or 0,
                "cached_tokens": self._pending.get("cached_tokens", 0),
                "finish_reason": STOP_REASONS.get(finish, finish),
            }
        if event == "message_stop":
            return {"type": "done"}
        if event == "error":
            return {"type": "error", "message": _message(payload)}
        return None


# 解析 JSON 失败时返回 None，单个坏帧不应打断整条流
def _loads(data: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(data)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


# 两种方言的错误体都能取到 message
def _message(payload: dict[str, Any]) -> str:
    error = payload.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error)
    return str(error or payload)


# SSE 帧编码：可选 event 行，data 一律 JSON
def sse_event(payload: dict[str, Any], event: str | None = None) -> bytes:
    prefix = f"event: {event}\n" if event else ""
    return f"{prefix}data: {json.dumps(payload, ensure_ascii=False)}\n\n".encode()


# 把 Anthropic 事件重编码成 OpenAI 流：chat 用 completion.chunk，responses 用 response 事件
@dataclass
class OpenAIStreamEncoder:
    api: str
    model: str
    request_id: str
    created: int
    content: str = ""
    _usage: dict[str, int] | None = None
    _finish_reason: str | None = None
    _role_sent: bool = False
    _finish_sent: bool = False
    _created_sent: bool = False

    # 输入是 StreamDecoder 的归一化事件，输出可直接写给客户端的字节
    def feed(self, event: dict[str, Any]) -> list[bytes]:
        kind = event.get("type")
        if kind == "delta":
            return self._delta(str(event.get("text") or ""))
        if kind == "usage":
            self._finish_reason = event.get("finish_reason") or self._finish_reason
            self._usage = {
                "input_tokens": int(event.get("input_tokens") or 0),
                "output_tokens": int(event.get("output_tokens") or 0),
                "cached_tokens": int(event.get("cached_tokens") or 0),
            }
            # responses 的 usage 只在最终 completed 事件里给一次
            return self._finish() if self.api == "chat" else []
        if kind == "done":
            return self._done()
        if kind == "error":
            payload = {
                "error": {
                    "message": event.get("message") or "upstream stream error",
                    "type": "upstream_error",
                    "code": "upstream_stream_error",
                }
            }
            return [sse_event(payload)]
        return []

    def _delta(self, text: str) -> list[bytes]:
        self.content += text
        if self.api == "responses":
            frames = [] if self._created_sent else [self._created_event()]
            self._created_sent = True
            payload = {
                "type": "response.output_text.delta",
                "item_id": self._item_id,
                "output_index": 0,
                "content_index": 0,
                "delta": text,
            }
            return [*frames, sse_event(payload, event="response.output_text.delta")]
        frames = []
        if not self._role_sent:  # 首个增量前先发 role，与 OpenAI 客户端预期一致
            self._role_sent = True
            frames.append(self._chunk({"role": "assistant"}))
        frames.append(self._chunk({"content": text}))
        return frames

    # chat 的收尾块：finish_reason 单独一帧，usage 再单独一帧（choices 为空）
    def _finish(self) -> list[bytes]:
        if self._finish_sent:
            return []
        self._finish_sent = True
        frames = []
        if not self._role_sent:
            self._role_sent = True
            frames.append(self._chunk({"role": "assistant"}))
        frames.append(self._chunk({}, self._finish_reason or "stop"))
        frames.append(self._usage_chunk())
        return frames

    def _done(self) -> list[bytes]:
        if self.api == "chat":
            return [*self._finish(), b"data: [DONE]\n\n"]
        frames = [] if self._created_sent else [self._created_event()]
        self._created_sent = True
        payload = {"type": "response.completed", "response": self._response()}
        return [*frames, sse_event(payload, event="response.completed")]

    def _chunk(self, delta: dict[str, Any], finish_reason: str | None = None) -> bytes:
        return sse_event(
            {
                "id": self._completion_id,
                "object": "chat.completion.chunk",
                "created": self.created,
                "model": self.model,
                "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}],
            }
        )

    def _usage_chunk(self) -> bytes:
        return sse_event(
            {
                "id": self._completion_id,
                "object": "chat.completion.chunk",
                "created": self.created,
                "model": self.model,
                "choices": [],
                "usage": self._openai_usage(),
            }
        )

    def _created_event(self) -> bytes:
        response = {
            "id": self._response_id,
            "object": "response",
            "created_at": self.created,
            "status": "in_progress",
            "model": self.model,
            "output": [],
            "output_text": "",
            "usage": None,
        }
        return sse_event({"type": "response.created", "response": response}, event="response.created")

    def _response(self) -> dict[str, Any]:
        usage = self._openai_usage()
        return {
            "id": self._response_id,
            "object": "response",
            "created_at": self.created,
            "status": "completed",
            "model": self.model,
            "output": [
                {
                    "id": self._item_id,
                    "type": "message",
                    "role": "assistant",
                    "status": "completed",
                    "content": [{"type": "output_text", "text": self.content, "annotations": []}],
                }
            ],
            "output_text": self.content,
            "usage": {
                "input_tokens": usage["prompt_tokens"],
                "input_tokens_details": {"cached_tokens": usage["prompt_tokens_details"]["cached_tokens"]},
                "output_tokens": usage["completion_tokens"],
                "output_tokens_details": {"reasoning_tokens": 0},
                "total_tokens": usage["total_tokens"],
            },
        }

    # decoder 已把缓存命中并入 input_tokens，这里只做字段改名
    def _openai_usage(self) -> dict[str, Any]:
        usage = self._usage or {"input_tokens": 0, "output_tokens": 0, "cached_tokens": 0}
        prompt, completion = usage["input_tokens"], usage["output_tokens"]
        return {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "total_tokens": prompt + completion,
            "prompt_tokens_details": {"cached_tokens": usage["cached_tokens"]},
        }

    @property
    def _completion_id(self) -> str:
        return f"chatcmpl-{self.request_id}"

    @property
    def _response_id(self) -> str:
        return f"resp_{self.request_id}"

    @property
    def _item_id(self) -> str:
        return f"msg_{self.request_id}"


# usage 归一化：OpenAI 用 prompt/completion，Anthropic 用 input/output
def _usage_event(usage: dict[str, Any]) -> dict[str, Any]:
    cached = (
        usage.get("cached_tokens")
        or (usage.get("prompt_tokens_details") or {}).get("cached_tokens")
        or usage.get("cache_read_input_tokens")
        or 0
    )
    return {
        "type": "usage",
        "input_tokens": usage.get("input_tokens") or usage.get("prompt_tokens") or 0,
        "output_tokens": usage.get("output_tokens") or usage.get("completion_tokens") or 0,
        "cached_tokens": cached,
    }
