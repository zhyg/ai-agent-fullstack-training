from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass

from app.config import RateLimitConfig


# 单个模型桶：剩余令牌数与上次补充时刻
@dataclass
class _Bucket:
    tokens: float
    updated_at: float


# 按模型别名独立分桶的令牌桶：不同模型互不抢占额度
class RateLimiter:
    def __init__(
        self, config: RateLimitConfig, clock: Callable[[], float] = time.monotonic
    ) -> None:
        self.config = config
        self._clock = clock
        self._buckets: dict[str, _Bucket] = {}

    # 取到令牌返回 None；额度不足返回建议等待秒数，供 Retry-After 使用
    def acquire(self, key: str) -> float | None:
        if not self.config.enabled:
            return None
        rate = self.config.requests_per_minute / 60
        burst = float(self.config.burst)
        now = self._clock()
        bucket = self._buckets.get(key)
        if bucket is None:
            bucket = _Bucket(tokens=burst, updated_at=now)
            self._buckets[key] = bucket
        # 按经过时间线性补充，但不超过桶容量，避免长时间空闲后攒出无限额度
        bucket.tokens = min(burst, bucket.tokens + (now - bucket.updated_at) * rate)
        bucket.updated_at = now
        if bucket.tokens >= 1:
            bucket.tokens -= 1
            return None
        return max(0.0, (1 - bucket.tokens) / rate)

    # 运维观察用：返回每个模型当前可用令牌数（会顺带完成补充）
    def status(self) -> dict[str, float]:
        now = self._clock()
        rate = self.config.requests_per_minute / 60
        burst = float(self.config.burst)
        snapshot: dict[str, float] = {}
        for key, bucket in self._buckets.items():
            tokens = min(burst, bucket.tokens + (now - bucket.updated_at) * rate)
            snapshot[key] = round(tokens, 3)
        return snapshot
