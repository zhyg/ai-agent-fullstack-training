from __future__ import annotations

import asyncio
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jinja2 import StrictUndefined
from jinja2.sandbox import SandboxedEnvironment

from app.config import GatewayConfig
from app.core.errors import GatewayError
from app.schemas import PromptCreate, PromptRecord

_SELECT = "SELECT id, version, name, description, role, content, is_active, created_at FROM prompts"
# 复合主键 (id, version)：同一模板可存多版；索引让"查激活版"不必全表扫
_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS prompts (id TEXT NOT NULL, version INTEGER NOT NULL, "
    "name TEXT NOT NULL, description TEXT, role TEXT NOT NULL, content TEXT NOT NULL, "
    "is_active INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, PRIMARY KEY (id, version))",
    "CREATE INDEX IF NOT EXISTS idx_prompts_active ON prompts(id, is_active)",
)


# 统一管理模板读写与渲染：建版本、按 id 查、渲染变量，避免逻辑散落到路由层
class PromptRepository:
    # 复用全局配置：database_url 与用量表共用同一个库文件
    def __init__(self, config: GatewayConfig, database_path: str | None = None) -> None:
        self.config = config
        self.database_path = database_path or config.database_url
        # 沙箱 + StrictUndefined：禁任意代码执行，且缺变量报错而非静默变空串
        self.env = SandboxedEnvironment(undefined=StrictUndefined, autoescape=False)

    # 建表建索引：重复调用安全，父目录缺失时自动创建
    async def initialize(self) -> None:
        Path(self.database_path).parent.mkdir(parents=True, exist_ok=True)
        for statement in _SCHEMA:
            await self._run(statement)

    # 每次发布都新增一版：旧版保留可回溯，activate 时保证同 id 只有一个激活版
    async def create_version(self, prompt: PromptCreate) -> PromptRecord:
        now = datetime.now(timezone.utc).isoformat()
        values = (prompt.id, prompt.name, prompt.description, prompt.role, prompt.content, now)
        version = await asyncio.to_thread(self._create_sync, values, prompt.activate)
        return PromptRecord(
            id=prompt.id, version=version, name=prompt.name, description=prompt.description,
            role=prompt.role, content=prompt.content, is_active=prompt.activate, created_at=now,
        )

    # 查模板：不传版本取激活版（调用方默认行为），传版本取历史版，查不到抛 404
    async def get(self, prompt_id: str, version: int | None = None) -> PromptRecord:
        query = _SELECT + " WHERE id = ?"
        params: tuple[Any, ...] = (prompt_id,)
        if version is None:
            query += " AND is_active = 1 ORDER BY version DESC LIMIT 1"
        else:
            query += " AND version = ?"
            params = (prompt_id, version)
        rows = await self._query(query, params)
        if not rows:
            label = "active" if version is None else str(version)
            raise GatewayError(
                f"Prompt {prompt_id!r} version {label} was not found",
                status_code=404,
                error_type="invalid_request_error",
                code="prompt_not_found",
            )
        return _to_record(rows[0])

    # 全量列表：id 升序、版本降序，保证控制台顺序稳定
    async def list(self) -> list[PromptRecord]:
        rows = await self._query(_SELECT + " ORDER BY id, version DESC")
        return [_to_record(row) for row in rows]

    # 渲染：缺变量或语法错误统一转 422，调用方拿到可读原因；不修改库中原文
    async def render(
        self, prompt_id: str, variables: dict[str, Any], version: int | None = None
    ) -> tuple[PromptRecord, str]:
        prompt = await self.get(prompt_id, version)
        try:
            rendered = self.env.from_string(prompt.content).render(**variables)
        except Exception as exc:
            raise GatewayError(
                f"Prompt rendering failed: {exc}",
                status_code=422,
                error_type="invalid_request_error",
                code="prompt_render_error",
            ) from exc
        return prompt, rendered

    # 版本号分配与插入放在同一事务：抢写锁后 MAX+1，并发下不会撞主键
    def _create_sync(self, values: tuple[Any, ...], activate: bool) -> int:
        prompt_id, name, description, role, content, now = values
        conn = sqlite3.connect(self.database_path, isolation_level=None)
        try:
            conn.execute("BEGIN IMMEDIATE")
            version = conn.execute(
                "SELECT COALESCE(MAX(version), 0) + 1 FROM prompts WHERE id = ?", (prompt_id,)
            ).fetchone()[0]
            if activate:
                conn.execute("UPDATE prompts SET is_active = 0 WHERE id = ?", (prompt_id,))
            conn.execute(
                "INSERT INTO prompts (id, version, name, description, role, content, "
                "is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (prompt_id, version, name, description, role, content, int(activate), now),
            )
            conn.commit()
            return int(version)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # 同步执行：每次新建连接并立即关闭，fetch=True 返回 dict 列表，否则提交写操作
    def _sync(self, sql: str, params: tuple[Any, ...], fetch: bool) -> list[dict[str, Any]]:
        conn = sqlite3.connect(self.database_path)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                cursor = conn.execute(sql, params)
                return [dict(row) for row in cursor.fetchall()] if fetch else []
        finally:
            conn.close()

    async def _run(self, sql: str, params: tuple[Any, ...] = ()) -> None:
        await asyncio.to_thread(self._sync, sql, params, False)

    async def _query(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._sync, sql, params, True)


# 行转模型：is_active 在库里是 0/1，出参必须是布尔
def _to_record(row: dict[str, Any]) -> PromptRecord:
    return PromptRecord(**{**row, "is_active": bool(row["is_active"])})

