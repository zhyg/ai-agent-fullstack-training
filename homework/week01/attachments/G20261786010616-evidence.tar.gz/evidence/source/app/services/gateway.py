from __future__ import annotations

import asyncio
import json
import logging
import random
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any

import httpx
from fastapi import Request

from app.config import Dialect, GatewayConfig
from app.core.errors import GatewayError, StructuredOutputError, UpstreamError, error_payload
from app.schemas import PromptReference
from app.services.adapters import to_client_response
from app.services.prompts import PromptRepository
from app.services.rate_limit import RateLimiter
from app.services.router import ModelRouter
from app.services.stream_adapters import OpenAIStreamEncoder, StreamDecoder
from app.services.structured import repair_instruction, schema_from_request, validate_response
from app.services.upstream import OpenStream, UpstreamClient
from app.services.usage import UsageEvent, UsageRepository, usage_from_payload

logger = logging.getLogger(__name__)

# 客户端协议 → 记账用的入口路径；实际上游路径由 adapters.request_path 按方言决定
ENDPOINTS = {"chat": "/v1/chat/completions", "responses": "/v1/responses"}


# 请求 ID 同时用于响应头、上游追踪头与用量主键，必须一次生成全程复用
def _new_request_id() -> str:
    return f"req_{uuid.uuid4().hex}"


# 延迟统一按毫秒保留三位，便于与上游耗时对齐比较
def _elapsed(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 3)


# 流已开始后无法再改状态码，只能把错误塞进 SSE 帧让客户端感知
def _sse_error(error: GatewayError) -> bytes:
    return f"data: {json.dumps(error_payload(error), ensure_ascii=False)}\n\n".encode()


# 网关编排层：选路 → 上游调用 → 结构化校验 → 计费记账，协议与路由细节都下沉到各服务
class GatewayService:
    def __init__(
        self,
        config: GatewayConfig,
        router: ModelRouter,
        upstream: UpstreamClient,
        prompts: PromptRepository,
        usage: UsageRepository,
    ) -> None:
        self.config = config
        self.router = router
        self.upstream = upstream
        self.prompts = prompts
        self.usage = usage
        self.rate_limiter = RateLimiter(config.rate_limit)

    # 限流在进入上游前执行，超限直接 429，避免无效调用挤占供应商配额
    def _check_rate_limit(self, model: str) -> None:
        wait = self.rate_limiter.acquire(model)
        if wait is None:
            return
        raise GatewayError(
            f"Rate limit exceeded for model {model!r}",
            status_code=429,
            error_type="rate_limit_error",
            code="rate_limited",
            param="model",
            details={"retry_after_seconds": wait},
        )

    # 实际使用的上游方言由命中的供应商决定
    def _dialect(self, provider: str | None) -> Dialect:
        return self.config.providers[provider].dialect if provider else "openai"

    # 注入提示词模板：chat 追加 system 消息，responses 合并进 instructions
    async def prepare_body(
        self, api: str, raw_body: dict[str, Any], prompt_ref: PromptReference | None
    ) -> tuple[dict[str, Any], tuple[str | None, int | None]]:
        body = {key: value for key, value in raw_body.items() if key != "gateway_prompt"}
        if prompt_ref is None:
            return body, (None, None)
        prompt, rendered = await self.prompts.render(
            prompt_ref.id, prompt_ref.variables, prompt_ref.version
        )
        if api == "chat":
            message = {"role": prompt.role, "content": rendered}
            messages = list(body.get("messages") or [])
            if prompt_ref.position == "append":
                messages.append(message)
            else:
                messages.insert(0, message)
            body["messages"] = messages
        else:
            existing = body.get("instructions")
            body["instructions"] = f"{rendered}\n\n{existing}" if existing else rendered
        return body, (prompt.id, prompt.version)

    # 非流式入口：返回上游原始体与请求 ID；声明了 JSON Schema 时本地校验并按需修复
    async def call_json(
        self,
        api: str,
        body: dict[str, Any],
        identity: str,
        prompt_meta: tuple[str | None, int | None],
    ) -> tuple[dict[str, Any], str]:
        request_id = _new_request_id()
        started = time.perf_counter()
        event = self._make_event(request_id, api, body, identity, prompt_meta)
        schema = schema_from_request(api, body)
        working = dict(body)
        repaired = 0
        try:
            self._check_rate_limit(event.requested_model)
            while True:
                result = await self._call_with_fallback(api, working, request_id, event)
                # 上游方言不是 OpenAI 时先翻译再校验，失败定位才与客户端协议一致
                result = to_client_response(
                    api, self._dialect(event.provider), result, model=event.requested_model
                )
                if schema is None:
                    return result, request_id
                try:
                    validate_response(api, result, schema)
                    return result, request_id
                except StructuredOutputError as exc:
                    if repaired >= self.config.structured_output_retries:
                        raise
                    repaired += 1
                    event.retries += 1
                    working = self._body_with_repair(
                        api, working, result, repair_instruction(exc, schema)
                    )
        except GatewayError as exc:
            self._mark_error(event, exc)
            raise
        finally:
            event.latency_ms = _elapsed(started)
            await self._record(event)

    # 流式入口：立即返回异步生成器与请求 ID，选路、重试与降级都在生成器内部完成
    async def stream(
        self, api: str, body: dict[str, Any], identity: str,
        prompt_meta: tuple[str | None, int | None], client_request: Request,
    ) -> tuple[AsyncIterator[bytes], str]:
        request_id = _new_request_id()
        event = self._make_event(request_id, api, body, identity, prompt_meta)
        event.status = "aborted"  # 中途被关闭也要落账，成功分支会覆盖成 success
        started = time.perf_counter()
        try:
            # 必须在返回生成器之前检查，否则限流错误只能塞进 SSE 帧而拿不到 429
            self._check_rate_limit(event.requested_model)
        except GatewayError as exc:
            self._mark_error(event, exc)
            event.latency_ms = _elapsed(started)
            await self._record(event)
            raise
        return self._generate(api, body, request_id, event, started, client_request), request_id

    # 流式主体：同方言字节透传，跨方言用编码器改写成 OpenAI SSE；旁路解析用于记账与快照
    async def _generate(
        self, api: str, body: dict[str, Any], request_id: str, event: UsageEvent,
        started: float, client_request: Request,
    ) -> AsyncIterator[bytes]:
        model = str(body["model"])
        checkpoint, limit = "", self.config.stream_checkpoint.max_chars
        last_flush, emitted = time.monotonic(), False
        opened: OpenStream | None = None
        try:
            async for _, opened in self._route_attempts(api, body, request_id, event, stream=True):
                dialect = self._dialect(event.provider)
                decoder = StreamDecoder(dialect)
                # 跨方言才重编码；同方言保持原样透传，避免无谓的解析与重写
                encoder = (
                    None
                    if dialect == "openai"
                    else OpenAIStreamEncoder(api, model, request_id, int(time.time()))
                )
                try:
                    async for chunk in opened.iter_bytes():
                        if encoder is None and not emitted:  # 首块即首 token
                            emitted, event.first_token_ms = True, _elapsed(started)
                        items = decoder.feed(chunk)
                        for item in items:
                            if item["type"] == "usage":
                                event.input_tokens = int(item.get("input_tokens") or 0)
                                event.output_tokens = int(item.get("output_tokens") or 0)
                                event.cached_tokens = int(item.get("cached_tokens") or 0)
                            elif item["type"] == "delta":
                                checkpoint = (checkpoint + (item.get("text") or ""))[-limit:]
                                last_flush = await self._flush_checkpoint(
                                    request_id, api, model, checkpoint, last_flush
                                )
                        if encoder is None:
                            yield chunk
                        else:
                            for item in items:
                                for frame in encoder.feed(item):
                                    if not emitted:  # 首个真正写出的帧才算首 token
                                        emitted, event.first_token_ms = True, _elapsed(started)
                                    yield frame
                        if await client_request.is_disconnected():
                            event.status, event.status_code = "cancelled", 499
                            return
                except (httpx.HTTPError, UpstreamError) as exc:
                    self.router.record_failure(event.provider)
                    if isinstance(exc, UpstreamError):
                        exc.retryable = exc.retryable and not emitted
                        error = exc
                    else:
                        error = UpstreamError(str(exc), status_code=502, retryable=not emitted)
                    if error.retryable:  # 尚未写出内容，重试或换路都安全
                        continue
                    self._mark_error(event, error)
                    yield _sse_error(error)
                    yield b"data: [DONE]\n\n"
                    return
                event.status, event.status_code = "success", 200
                return
        except asyncio.CancelledError:
            event.status, event.status_code = "cancelled", 499
            raise
        except GatewayError as exc:
            self._mark_error(event, exc)
            yield _sse_error(exc)
            yield b"data: [DONE]\n\n"
        finally:
            if opened is not None:  # 正常结束、异常与断连都要释放上游连接
                await opened.aclose()
            event.latency_ms = _elapsed(started)
            if self.config.stream_checkpoint.enabled:
                try:
                    await self.usage.save_checkpoint(
                        request_id, api, model, event.status, checkpoint
                    )
                except Exception:
                    logger.exception("Failed to save stream checkpoint %s", request_id)
            await self._record(event)

    # 按"路由优先、路内重试"的顺序产出上游响应；耗尽时抛出最后一次错误
    async def _route_attempts(
        self, api: str, body: dict[str, Any], request_id: str, event: UsageEvent, stream: bool
    ) -> AsyncIterator[tuple[Any, Any]]:
        last_error: GatewayError | None = None
        for index, route in enumerate(self.router.candidates(body["model"], api)):
            event.fallbacks = index
            for attempt in range(self.config.retry.max_attempts_per_route):
                if attempt:
                    event.retries += 1
                    await self._backoff(attempt)
                call = self.upstream.open_stream if stream else self.upstream.request_json
                try:
                    opened = await call(route.provider, None, body, request_id, api=api)
                except UpstreamError as exc:
                    self.router.record_failure(route.provider)
                    last_error = exc
                    if not exc.retryable:  # 4xx 属于参数问题，换路重试同样会失败
                        break
                    continue
                self.router.record_success(route.provider)
                event.provider, event.upstream_model = route.provider, route.model
                yield route, opened
        if last_error is not None:
            raise last_error
        raise GatewayError("All routes failed", status_code=502, code="all_routes_failed")

    async def _call_with_fallback(
        self, api: str, body: dict[str, Any], request_id: str, event: UsageEvent
    ) -> dict[str, Any]:
        async for _, result in self._route_attempts(api, body, request_id, event, stream=False):
            input_tokens, output_tokens, cached_tokens = usage_from_payload(result)
            event.input_tokens += input_tokens
            event.output_tokens += output_tokens
            event.cached_tokens += cached_tokens
            return result
        raise GatewayError("No upstream response", status_code=502, code="all_routes_failed")

    # 修复轮：把上一轮回答与失败原因追加回去，只要求模型改错处
    @staticmethod
    def _body_with_repair(
        api: str, body: dict[str, Any], result: dict[str, Any], instruction: str
    ) -> dict[str, Any]:
        repaired = dict(body)
        try:
            previous = result["choices"][0]["message"]["content"] if api == "chat" else ""
            previous = previous or result.get("output_text") or ""
        except (KeyError, IndexError, TypeError):
            previous = ""  # 结构异常时也要继续修复，不能让解析失败掩盖 422
        replies = [{"role": "assistant", "content": previous}, {"role": "user", "content": instruction}]
        if api == "chat":
            repaired["messages"] = [*(repaired.get("messages") or []), *replies]
        else:
            original = repaired.get("input") or []
            items = original if isinstance(original, list) else [{"role": "user", "content": original}]
            repaired["input"] = [*items, *replies]
        return repaired

    # 构造用量事件：prompt 版本写进 metadata，避免为两个字段扩表
    def _make_event(
        self, request_id: str, api: str, body: dict[str, Any], identity: str,
        prompt_meta: tuple[str | None, int | None],
    ) -> UsageEvent:
        return UsageEvent(
            request_id=request_id, api_key_hash=identity,
            endpoint=ENDPOINTS.get(api, ENDPOINTS["chat"]),
            requested_model=str(body.get("model", "")), stream=bool(body.get("stream")),
            metadata={"prompt_id": prompt_meta[0], "prompt_version": prompt_meta[1]},
        )

    # 统一记录失败终态，状态码与错误类型直接取自异常
    @staticmethod
    def _mark_error(event: UsageEvent, error: GatewayError) -> None:
        event.status, event.status_code = "error", error.status_code
        event.error_type, event.error_message = error.error_type, error.message

    # 按间隔落快照：未开启或未到间隔时原样返回上次时间，避免每帧都写库
    async def _flush_checkpoint(
        self, request_id: str, api: str, model: str, content: str, last_flush: float
    ) -> float:
        checkpoint = self.config.stream_checkpoint
        if not checkpoint.enabled or time.monotonic() - last_flush < checkpoint.flush_interval_seconds:
            return last_flush
        try:
            await self.usage.save_checkpoint(request_id, api, model, "streaming", content)
        except Exception:
            logger.exception("Failed to save streaming checkpoint %s", request_id)
        return time.monotonic()

    # 记账失败只记日志：响应已经成功，统计问题不该变成用户可见错误
    async def _record(self, event: UsageEvent) -> None:
        try:
            await self.usage.record(event)
        except Exception:
            logger.exception("Failed to record usage for %s", event.request_id)

    # 指数退避加抖动，避免同一供应商被重试风暴同时打满
    async def _backoff(self, attempt: int) -> None:
        delay = self.config.retry.base_delay_seconds * 2 ** (attempt - 1)
        delay = min(delay, self.config.retry.max_delay_seconds) * (0.5 + random.random() / 2)
        if delay > 0:
            await asyncio.sleep(delay)  # 基础延迟为 0 时直接重试，测试不必等

