from __future__ import annotations

import asyncio
import json
import sqlite3
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.config import GatewayConfig

# 用量仓储：一次请求一行账，另存流式快照；只负责落库与计价，不参与选路与重试。
# 连接策略：每个操作新建 sqlite3 连接并扔进线程池，因此不支持 ":memory:"（连接各自独立）。
_COLUMNS = (
    "request_id", "api_key_hash", "endpoint", "requested_model", "provider", "upstream_model",
    "stream", "status", "status_code", "input_tokens", "output_tokens", "cached_tokens",
    "cost_usd", "latency_ms", "first_token_ms", "retries", "fallbacks", "error_type",
    "error_message", "metadata_json",
)

# 列名显式拼接占位符，后续加列也不会出现参数错位
_INSERT_SQL = (
    "INSERT OR REPLACE INTO usage_events(created_at, " + ", ".join(_COLUMNS) + ") "
    "VALUES (" + ", ".join(["?"] * (len(_COLUMNS) + 1)) + ")"
)

_SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS usage_events (
        request_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, api_key_hash TEXT NOT NULL,
        endpoint TEXT NOT NULL, requested_model TEXT NOT NULL, provider TEXT,
        upstream_model TEXT, stream INTEGER NOT NULL, status TEXT NOT NULL,
        status_code INTEGER NOT NULL, input_tokens INTEGER NOT NULL,
        output_tokens INTEGER NOT NULL, cached_tokens INTEGER NOT NULL,
        cost_usd REAL NOT NULL, latency_ms REAL NOT NULL, first_token_ms REAL,
        retries INTEGER NOT NULL, fallbacks INTEGER NOT NULL, error_type TEXT,
        error_message TEXT, metadata_json TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_usage_created ON usage_events(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_usage_model ON usage_events(requested_model)",
    """
    CREATE TABLE IF NOT EXISTS stream_checkpoints (
        request_id TEXT PRIMARY KEY, api TEXT NOT NULL, model TEXT NOT NULL,
        status TEXT NOT NULL, content TEXT NOT NULL, updated_at TEXT NOT NULL
    )
    """,
)


# 一条用量事件：字段与表列一一对应，方便 asdict 直接落库
@dataclass
class UsageEvent:
    request_id: str  # 唯一标识，同时返回给调用方做追踪
    api_key_hash: str  # 调用方指纹，不存明文密钥
    endpoint: str  # 入口协议，否则分不清 chat 与 responses
    requested_model: str  # 公开别名，否则看不出用户要谁
    provider: str | None = None  # 实际供应商，否则无法评估各家稳定性
    upstream_model: str | None = None  # 真实模型名，计费的唯一依据
    stream: bool = False
    status: str = "success"  # success / error / aborted 终态
    status_code: int = 200
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0  # 缓存命中部分，单独按缓存价计费
    cost_usd: float | None = None  # None 表示写库时按价目自动折算
    latency_ms: float = 0
    first_token_ms: float | None = None  # 仅流式有值
    retries: int = 0
    fallbacks: int = 0
    error_type: str | None = None
    error_message: str | None = None
    metadata: dict[str, Any] | None = None  # 扩展字段，加指标不必改表


class UsageRepository:
    # 复用全局配置：database_url 决定库位置，pricing 决定单价，max_chars 限制快照体积
    def __init__(self, config: GatewayConfig, database_path: str | None = None) -> None:
        self.config = config
        self.database_path = database_path or config.database_url

    # 建库建表：重复调用安全，父目录缺失时自动创建
    async def initialize(self) -> None:
        Path(self.database_path).parent.mkdir(parents=True, exist_ok=True)
        for statement in _SCHEMA:
            await self._run(statement)

    # 按真实模型名查价目：先扣缓存命中再算新输入，避免缓存部分被原价重复计费
    def calculate_cost(
        self, model: str, input_tokens: int, output_tokens: int, cached_tokens: int = 0
    ) -> float:
        price = self.config.pricing.get(model)
        if price is None:
            return 0.0
        cached = max(0, min(cached_tokens, input_tokens))
        fresh = max(0, input_tokens - cached)
        rate = price.cached_input_per_million
        cost = fresh * price.input_per_million / 1_000_000
        cost += cached * (rate if rate is not None else price.input_per_million) / 1_000_000
        cost += output_tokens * price.output_per_million / 1_000_000
        return round(cost, 10)

    # 写一条用量：cost_usd 为 None 时按价目折算，显式传入则以调用方为准
    async def record(self, event: UsageEvent) -> None:
        cost = event.cost_usd
        if cost is None:
            model = event.upstream_model or event.requested_model
            cost = self.calculate_cost(model, event.input_tokens, event.output_tokens,
                                       event.cached_tokens)
        values = asdict(event)
        values["cost_usd"] = cost
        values["metadata_json"] = json.dumps(event.metadata, ensure_ascii=False) if event.metadata else None
        row = tuple(int(values[key]) if key == "stream" else values[key] for key in _COLUMNS)
        await self._run(_INSERT_SQL, (datetime.now(timezone.utc).isoformat(), *row))

    # 倒序取最近记录：limit 夹到 1..1000，避免一次拉全表
    async def recent(self, limit: int = 100) -> list[dict[str, Any]]:
        safe_limit = max(1, min(int(limit), 1000))
        sql = "SELECT * FROM usage_events ORDER BY created_at DESC, rowid DESC LIMIT ?"
        return await self._query(sql, (safe_limit,))

    # 覆盖写快照：同一 request_id 只留最新状态与正文，断线后可按 id 续传
    async def save_checkpoint(
        self, request_id: str, api: str, model: str, status: str, content: str
    ) -> None:
        # 正文按配置上限截断，避免单条快照把库撑爆
        clipped = content[: self.config.stream_checkpoint.max_chars]
        updated_at = datetime.now(timezone.utc).isoformat()
        sql = (
            "INSERT INTO stream_checkpoints(request_id, api, model, status, content, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(request_id) DO UPDATE SET "
            "status = excluded.status, content = excluded.content, updated_at = excluded.updated_at"
        )
        await self._run(sql, (request_id, api, model, status, clipped, updated_at))

    # 按请求读快照：没有则返回 None，前端据此判断能否续传
    async def get_checkpoint(self, request_id: str) -> dict[str, Any] | None:
        sql = (
            "SELECT request_id, api, model, status, content, updated_at "
            "FROM stream_checkpoints WHERE request_id = ?"
        )
        rows = await self._query(sql, (request_id,))
        return rows[0] if rows else None

    # 同步执行：每次新建连接并立即关闭，fetch=True 返回 dict 列表，否则提交写操作
    def _sync(self, sql: str, params: tuple[Any, ...], fetch: bool) -> list[dict[str, Any]]:
        conn = sqlite3.connect(self.database_path, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                cursor = conn.execute(sql, params)
                return [dict(row) for row in cursor.fetchall()] if fetch else []
        finally:
            conn.close()

    async def _run(self, sql: str, params: tuple[Any, ...] = ()) -> None:
        await asyncio.to_thread(self._sync, sql, params, False)

    async def _query(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._sync, sql, params, True)


# 兼容两套字段名，否则换协议归零：OpenAI 用 prompt/completion，Anthropic 用 input/output
def usage_from_payload(payload: dict[str, Any] | None) -> tuple[int, int, int]:
    usage = (payload or {}).get("usage")
    if not isinstance(usage, dict):
        return 0, 0, 0
    details = usage.get("prompt_tokens_details") or usage.get("input_tokens_details") or {}
    cache_read = _as_int(usage.get("cache_read_input_tokens"))
    cached = cache_read or _as_int(details.get("cached_tokens")) or _as_int(usage.get("cached_tokens"))
    total = _as_int(usage.get("prompt_tokens")) or _as_int(usage.get("input_tokens"))
    # Anthropic 的 input_tokens 不含缓存命中，补回后与 prompt_tokens 语义一致
    total += cache_read
    # 缓存写入无独立价目字段，先按普通输入计价，宁可略高也不漏量
    total += _as_int(usage.get("cache_creation_input_tokens"))
    output = _as_int(usage.get("completion_tokens")) or _as_int(usage.get("output_tokens"))
    return total, output, cached


# usage 里的数字可能是字符串或 None，统一容错成非负整数，坏数据不拖垮请求
def _as_int(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0
