import asyncio, json, os, sys, time, tempfile
from pathlib import Path
import httpx, uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'student'))
from app.config import GatewayConfig
from app.main import create_app

OUT = ROOT/'evidence'
OUT.mkdir(exist_ok=True)
records=[]
def log(name, **data):
    records.append({'case':name, **data})
    print(json.dumps(records[-1],ensure_ascii=False), flush=True)
def cfg(real=False):
    return GatewayConfig.model_validate({
        'database_url': str(ROOT/('real.db' if real else 'controlled.db')),
        'structured_output_retries':1,
        'retry':{'max_attempts_per_route':3,'base_delay_seconds':0.1,'max_delay_seconds':0.4},
        'rate_limit':{'enabled':False},
        'circuit_breaker':{'failure_threshold':100},
        'providers':{
            'a':{'dialect':'openai','base_url':'https://api.deepseek.com' if real else 'http://127.0.0.1:18617'},
            'b':{'dialect':'anthropic','base_url':'https://api.deepseek.com/anthropic' if real else 'http://127.0.0.1:18617/anthropic'},
        },
        'models':{name:{'routes':[{'provider':p,'model':m,'api':'chat'}]} for name,p,m in
                  [('A','a','deepseek-v4-flash'),('B','b','deepseek-v4-pro'),('deepseek-v4-flash','a','deepseek-v4-flash'),('deepseek-v4-pro','b','deepseek-v4-pro')]}
    })

state={'mode':'ok','calls':[]}
gate=asyncio.Event()
mock=FastAPI()
@mock.post('/v1/chat/completions')
@mock.post('/anthropic/v1/messages')
async def upstream(req:Request):
    b=await req.json(); anth='anthropic' in req.url.path
    state['calls'].append({'path':req.url.path,'body':b,'time':time.monotonic()})
    n=len(state['calls']); mode=state['mode']
    if mode=='500' or (mode=='retry' and n<3):return JSONResponse({'error':{'message':'controlled failure'}},status_code=500)
    if mode=='400':return JSONResponse({'error':{'message':'controlled bad request'}},status_code=400)
    text={'invalid':'not JSON','empty':'','truncated':'{"ok":','fence':'```json\n{"ok":true}\n```'}.get(mode,'{"ok":true}')
    if b.get('stream'):
        async def chunks():
            if anth:
                yield b'event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":11,"cache_read_input_tokens":3,"cache_creation_input_tokens":2}}}\n\n'
            else:yield b': heartbeat\n\n'
            await asyncio.sleep(.15)
            if anth:yield b'event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"type":"text_delta","text":"FIRST"}}\n\n'
            else:yield b'data: {"choices":[{"delta":{"content":"FIRST"}}]}\n\n'
            await gate.wait()
            if mode=='disconnect':
                raise RuntimeError('controlled transport disconnect')
            if mode=='error-event':
                yield b'data: {"type":"error","error":{"message":"controlled stream failure"}}\n\n'
                return
            if anth:
                yield b'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":7}}\n\n'
                yield b'event: message_stop\ndata: {"type":"message_stop"}\n\n'
            else:
                yield b'data: {"choices":[],"usage":{"prompt_tokens":16,"completion_tokens":7,"prompt_tokens_details":{"cached_tokens":3},"completion_tokens_details":{"reasoning_tokens":2}}}\n\ndata: [DONE]\n\n'
        return StreamingResponse(chunks(),media_type='text/event-stream')
    if anth:return {'id':'controlled','content':[{'type':'text','text':text}], 'stop_reason':'max_tokens' if mode=='truncated' else 'end_turn','usage':{'input_tokens':11,'cache_read_input_tokens':3,'cache_creation_input_tokens':2,'output_tokens':7}}
    return {'id':'controlled','model':b['model'],'choices':[{'message':{'role':'assistant','content':text},'finish_reason':'length' if mode=='truncated' else 'stop'}],'usage':{'prompt_tokens':16,'completion_tokens':7,'total_tokens':23,'prompt_tokens_details':{'cached_tokens':3},'completion_tokens_details':{'reasoning_tokens':2}}}

def body(model='A',**kw):return {'model':model,'messages':[{'role':'system','content':'System test'},{'role':'user','content':'Return JSON {"ok":true} only.'}],**kw}
async def start(app,port):
    s=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='critical',access_log=False))
    t=asyncio.create_task(s.serve())
    while not s.started:
        if t.done():await t
        await asyncio.sleep(.02)
    return s,t
async def main():
    servers=[]
    try:
        servers.append(await start(mock,18617))
        app=create_app(cfg()); servers.append(await start(app,18618))
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18618',timeout=10) as c:
            log('A01-health',response=(await c.get('/healthz')).json())
            for model in ['A','B','unknown']:
                state.update(mode='ok',calls=[])
                r=await c.post('/v1/chat/completions',json=body(model));log('A03-A04',model=model,status=r.status_code,response=r.json(),upstream=state['calls'])
            for model in ['A','B']:
                for mode in ['ok','invalid','empty','truncated','fence']:
                    for fmt in ['json_object','json_schema']:
                        state.update(mode=mode,calls=[])
                        f={'type':fmt}
                        if fmt=='json_schema':f['json_schema']={'schema':{'type':'object','required':['ok'],'properties':{'ok':{'type':'boolean'}}}}
                        r=await c.post('/v1/chat/completions',json=body(model,response_format=f))
                        log('F03-F04',model=model,mode=mode,format=fmt,status=r.status_code,response=r.json(),calls=len(state['calls']))
            for v in [1,2]:
                r=await c.post('/v1/prompts',json={'id':'probe','name':'probe','content':f'v{v} {{{{ name }}}}'})
                log('F05-create',response=r.json())
            for version in [1,2,9]:
                state.update(mode='ok',calls=[])
                r=await c.post('/v1/chat/completions',json=body(gateway_prompt={'id':'probe','version':version,'variables':{'name':'Ada'}}))
                log('F05-reference',version=version,status=r.status_code,response=r.json(),upstream=state['calls'])
            for ref in [{'id':'absent'},{'id':'probe','version':1}]:
                r=await c.post('/v1/chat/completions',json=body(gateway_prompt=ref));log('F06',ref=ref,status=r.status_code,response=r.json())
            for mode in ['retry','500','400']:
                state.update(mode=mode,calls=[])
                r=await c.post('/v1/chat/completions',json=body())
                times=[x['time'] for x in state['calls']]
                log('F08-F09',mode=mode,status=r.status_code,calls=len(times),intervals=[round(b-a,3) for a,b in zip(times,times[1:])],response=r.json())
            for model in ['A','B']:
                for mode in ['ok','disconnect','error-event']:
                    state.update(mode=mode,calls=[]);gate.clear();parts=[];first=None;started=time.monotonic()
                    async with c.stream('POST','/v1/chat/completions',json=body(model,stream=True)) as r:
                        async for chunk in r.aiter_text():
                            parts.append(chunk)
                            if 'FIRST' in chunk and first is None:
                                first=time.monotonic()-started
                                log('F01-gate',model=model,mode=mode,content_before_terminal_release=not gate.is_set(),first_content_seconds=round(first,3))
                                gate.set()
                    await asyncio.sleep(.03)
                    ledger=(await c.get('/v1/usage/recent')).json()[0]
                    log('F01-F02-F07',model=model,mode=mode,calls=len(state['calls']),stream=''.join(parts),ledger=ledger)
            state.update(mode='ok',calls=[])
            app.state.service.rate_limiter.config.enabled=True
            app.state.service.rate_limiter.config.requests_per_minute=60
            app.state.service.rate_limiter.config.burst=1
            app.state.service.rate_limiter._buckets.clear()
            statuses=[]
            for m in ['A','A','B']:statuses.append((await c.post('/v1/chat/completions',json=body(m))).status_code)
            await asyncio.sleep(1.05)
            statuses.append((await c.post('/v1/chat/completions',json=body('A'))).status_code)
            log('F10-F11',models=['A','A','B','A-after-1.05s'],statuses=statuses,calls=len(state['calls']))
            ledger=(await c.get('/v1/usage/recent?limit=1000')).json()
            (OUT/'controlled-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
        real=cfg(True)
        for p in real.providers.values():
            from pydantic import SecretStr
            p.api_key=SecretStr(os.environ['DEEPSEEK_API_KEY']);p.timeout_seconds=65
        real.retry.max_attempts_per_route=1
        real.structured_output_retries=0
        realapp=create_app(real);servers.append(await start(realapp,18619))
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18619',timeout=75) as c:
            for model in ['deepseek-v4-flash','deepseek-v4-pro']:
                for kind in ['normal','stream','json']:
                    b=body(model,max_tokens=128,thinking={'type':'disabled'})
                    b['messages']=[{'role':'user','content':'Return only JSON {"ok":true}.' if kind=='json' else 'Reply OK only.'}]
                    if kind=='json':b['response_format']={'type':'json_object'}
                    if kind=='stream':b['stream']=True;b['stream_options']={'include_usage':True}
                    started=time.monotonic()
                    try:
                        r=await c.post('/v1/chat/completions',json=b)
                        log('A02-real',model=model,protocol=real.providers['a' if 'flash' in model else 'b'].dialect,kind=kind,status=r.status_code,request_id=r.headers.get('x-request-id'),elapsed=round(time.monotonic()-started,3),response=r.text)
                    except Exception as e:log('A02-real',model=model,kind=kind,error=type(e).__name__)
            r=await c.post('/v1/chat/completions',json=body('A',max_tokens=32,thinking={'type':'disabled'}))
            log('A02-real-alias-control',status=r.status_code,response=r.json())
            (OUT/'real-ledger.json').write_text(json.dumps((await c.get('/v1/usage/recent')).json(),ensure_ascii=False,indent=2))
    finally:
        for s,t in reversed(servers):s.should_exit=True
        for s,t in reversed(servers):await t
        (OUT/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
        log('shutdown',servers_stopped=len(servers))
if __name__=='__main__':asyncio.run(main())
