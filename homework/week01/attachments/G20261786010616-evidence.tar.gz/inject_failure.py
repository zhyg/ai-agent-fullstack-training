import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'student'))
import scripts.verify_all_features as v
# 只改变独立测试进程的返回夹具，不改业务或学生文件。
v.CHAT_OK['choices'][0]['message']['content']='INTENTIONAL_BAD_FIXTURE'
raise SystemExit(v.main(['--filter','CHAT-01']))
