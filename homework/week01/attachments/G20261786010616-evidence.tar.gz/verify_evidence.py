import json, re
from pathlib import Path

root=Path(__file__).resolve().parent
r=json.loads((root/'evidence/results.json').read_text())
def select(case,**kw):return [x for x in r if x['case']==case and all(x.get(k)==v for k,v in kw.items())]
for m in ['A','B']:
    assert select('F01-gate',model=m,mode='ok')[0]['content_before_terminal_release']
    assert select('F01-F02-F07',model=m,mode='disconnect')[0]['calls']==1
    assert select('F01-F02-F07',model=m,mode='disconnect')[0]['ledger']['status']=='error'
    assert select('F01-F02-F07',model=m,mode='error-event')[0]['ledger']['status']=='success'
    for mode in ['invalid','empty','truncated']:
        assert select('F03-F04',model=m,mode=mode,format='json_object')[0]['status']==200
        assert select('F03-F04',model=m,mode=mode,format='json_schema')[0]['status']==422
    text=select('F03-F04',model=m,mode='fence',format='json_schema')[0]['response']['choices'][0]['message']['content']
    try:json.loads(text)
    except json.JSONDecodeError:pass
    else:raise AssertionError('fenced response unexpectedly valid')
for mode,count in [('retry',3),('500',3),('400',1)]:
    assert select('F08-F09',mode=mode)[0]['calls']==count
assert select('F10-F11')[0]['statuses']==[200,429,200,200]
for x in select('A02-real',kind='json'):
    text=json.loads(x['response'])['choices'][0]['message']['content']
    try:value=json.loads(text);valid=True
    except json.JSONDecodeError:valid=False
    print('真实JSON直接解析',x['model'],valid)
    assert valid==('pro' in x['model'])
ledger=json.loads((root/'evidence/real-ledger.json').read_text())
success=[x for x in ledger if x['status']=='success']
assert len(success)==6
inputs=sum(x['input_tokens'] for x in success);outputs=sum(x['output_tokens'] for x in success)
assert (inputs,outputs)==(80,15)
print('六次成功HTTP调用已知Token',inputs,outputs,inputs+outputs)
repo=root.parents[3]
feedback=(repo/'homework/week01/G20261786010616.md').read_text()
for n in [2,3,4]:
    part=feedback.split(f'**{n}. ')[1].split('**',1)[1].split('\n**',1)[0]
    bullets=[s for s in part.splitlines() if s.startswith('- ')]
    assert 3<=len(bullets)<=5
    assert len(''.join(bullets))<=500
    assert not any(w in part for w in ['扣分','评分标准','扣除'])
    print('反馈节',n,'条数',len(bullets),'含标点字符',len(''.join(bullets)))
scores=[11,15,5,10,8,15,10,8]
assert sum(scores)==82
print('八项合计82，等级优秀；证据断言全部通过')
