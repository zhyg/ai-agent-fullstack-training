# 风禾尽起第一次提交复核

固定对象：HTTPS clone https://gitee.com/wujingin/mini-llm-gateway.git ，main 的 e70d65b56afd0e73b1f74e64b1a3f5ebc50202eb。clone 成功；tree.txt 是本次取得对象的 blob 清单。源码摘录为原文件逐字副本，其他源码需从固定提交取得。无业务修改。

在空目录解包后执行（已装 uv；只需在安全环境预置 DEEPSEEK_API_KEY，不要写入归档或终端历史）：

```bash
git clone https://gitee.com/wujingin/mini-llm-gateway.git student
git -C student checkout --detach e70d65b56afd0e73b1f74e64b1a3f5ebc50202eb
uv venv venv
uv pip install --python venv/bin/python 'aiosqlite>=0.20,<1' 'fastapi>=0.115,<1' 'httpx>=0.27,<1' 'jinja2>=3.1,<4' 'jsonschema>=4.23,<5' 'pydantic>=2.9,<3' 'pyyaml>=6,<7' 'uvicorn[standard]>=0.30,<1'
venv/bin/python student/scripts/verify_all_features.py
venv/bin/python inject_failure.py
# 上一条预期退出 1：只在测试进程修改夹具，不是业务代码。
venv/bin/python probe.py
venv/bin/python boundary.py
ss -ltn '( sport = :18617 or sport = :18618 or sport = :18619 or sport = :18620 )'
```

probe.py 先启动本地受控 HTTP 上游与真实学生网关，后实际访问官方两个模型。真实模式6次请求上限128输出Token，另有1次模型别名失败对照；boundary.py另对原始smart/fast各做失败对照，可能fallback到第二路。只访问DeepSeek官方，不使用其他模型供应商。真实模型每路只尝试1次，修复0次；受控重试总3次、退避0.1/0.2秒上限及抖动。所有秘密仅在进程内注入。configs.json不含任何secret值，真实密钥由脚本运行时读取。

首次复核前确保本目录无旧controlled.db/real.db/default-real.db；重复运行请移走此前评测生成的这三个数据库，避免模板版本或账本积累。probe.py、boundary.py用finally正常关闭所有有限测试服务。若人为中断，先确认占用PID再关闭本次进程，不要杀其他服务。

verify_evidence.py对已保存运行结果做独立断言，包括JSON正文直接解析、实际请求数、门控时序、失败账与限流。其报告格式检查默认寻找课程仓库路径；在证据包独立目录复跑时，可只复用前半段证据断言，或放回原课程仓库的.amp/in/orb-backup/grading10616目录。validation.log保留本次已执行结果。

详细评分和所有限制见课程仓库附件G20261786010616.md；本证据不是“全部验收通过”的证明。原公开别名失败、Flash真实JSON非法，不能用替代配置掩盖。
