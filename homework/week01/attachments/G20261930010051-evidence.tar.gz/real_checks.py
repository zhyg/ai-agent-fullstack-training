import json
import time
from pathlib import Path
import httpx

out = []
base = 'http://127.0.0.1:8126'
for model in ['deepseek-v4-pro', 'deepseek-v4-flash']:
    for kind in ['ordinary', 'stream', 'json']:
        payload = {'model': model, 'max_tokens': 256,
                   'messages': [{'role': 'user', 'content': 'No reasoning needed. Reply only OK.'}]}
        if kind == 'stream':
            payload['stream'] = True
        if kind == 'json':
            payload['messages'][0]['content'] = 'No reasoning needed. Output only this JSON object: {"ok":true}'
            payload['response_format'] = {'type': 'json_object'}
        start = time.monotonic()
        rec = {'model_alias': model, 'upstream_model': model,
               'protocol': 'responses' if model.endswith('pro') else 'anthropic',
               'official_origin': 'https://api.deepseek.com', 'kind': kind, 'max_tokens': 256}
        try:
            with httpx.Client(timeout=160) as c:
                if kind == 'stream':
                    with c.stream('POST', base + '/v1/chat/completions', headers={'Authorization': 'Bearer dev-key'}, json=payload) as r:
                        rec['status'] = r.status_code
                        rec['gateway_request_id'] = r.headers.get('x-request-id')
                        rec['events'] = []
                        for line in r.iter_lines():
                            if line:
                                rec['events'].append({'t_ms': round((time.monotonic()-start)*1000, 2), 'line': line})
                else:
                    r = c.post(base + '/v1/chat/completions', headers={'Authorization': 'Bearer dev-key'}, json=payload)
                    rec['status'] = r.status_code
                    rec['response'] = r.json()
        except Exception as e:
            rec['exception'] = type(e).__name__
        rec['elapsed_ms'] = round((time.monotonic()-start)*1000, 2)
        out.append(rec)
        Path(__file__).with_name('real-results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2))
        print(json.dumps(rec, ensure_ascii=False), flush=True)
