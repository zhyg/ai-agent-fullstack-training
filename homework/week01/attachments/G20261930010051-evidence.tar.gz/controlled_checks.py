import concurrent.futures
import json
import subprocess
import time
from pathlib import Path
import httpx

OUT = Path(__file__).parent
BASE = 'http://127.0.0.1:8125'
MOCK = 'http://127.0.0.1:8124'
AUTH = {'Authorization': 'Bearer dev-key'}
MODELS = ['deepseek-v4-pro', 'deepseek-v4-flash']
c = httpx.Client(timeout=45)
records = []

def mode(m):
    c.post(MOCK + '/control', json={'mode': m}).raise_for_status()

def stats():
    return c.get(MOCK + '/stats').json()

def chat(model, **kw):
    return c.post(BASE + '/v1/chat/completions', headers=AUTH,
                  json=dict(model=model, messages=[{'role': 'user', 'content': 'short probe'}], max_tokens=64, **kw))

def ledger():
    return c.get(BASE + '/admin/usage', headers=AUTH, params={'limit': 1000}).json()['records']

def save(name, **data):
    r = dict(case=name, **data)
    records.append(r)
    print(json.dumps(r, ensure_ascii=False), flush=True)

for model in MODELS:
    mode('normal')
    r = chat(model)
    save('A02-A03-controlled-' + model, status=r.status_code, response=r.json(), calls=stats()['calls'], ledger=ledger()[0])
mode('normal')
before = len(ledger())
r = chat('unknown')
save('A04', status=r.status_code, response=r.json(), calls=stats()['calls'], ledger_added=len(ledger())-before)

schema = {'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok'], 'additionalProperties': False}
for model in MODELS:
    for m in ['json', 'invalid', 'empty', 'truncated', 'schema_bad', 'repair', 'fenced']:
        mode(m)
        r = chat(model, response_format={'type': 'json_schema', 'json_schema': {'name': 'probe', 'schema': schema}})
        valid = False
        if r.status_code == 200:
            try:
                json.loads(r.json()['choices'][0]['message']['content'])
                valid = True
            except ValueError:
                pass
        save('F03-F04-' + model + '-' + m, status=r.status_code, returned_content_valid_json=valid,
             response=r.json(), calls=len(stats()['calls']), ledger=ledger()[0])

for model in MODELS:
    for m in ['gate', 'gate_error', 'gate_eof', 'gate_disconnect']:
        mode(m)
        observed = []
        def consume():
            try:
                with httpx.stream('POST', BASE + '/v1/chat/completions', headers=AUTH, timeout=25,
                                  json={'model': model, 'messages': [{'role': 'user', 'content': 'hi'}], 'stream': True}) as r:
                    observed.append({'status': r.status_code, 'rid': r.headers.get('x-request-id')})
                    for line in r.iter_lines():
                        if line:
                            observed.append({'line': line, 't': time.monotonic()})
            except Exception as e:
                observed.append({'transport_error': type(e).__name__})
        with concurrent.futures.ThreadPoolExecutor() as ex:
            f = ex.submit(consume)
            until = time.monotonic() + 10
            while not any('FIRST' in x.get('line', '') for x in observed) and time.monotonic() < until:
                time.sleep(.02)
            before_release = list(observed)
            released = time.monotonic()
            c.post(MOCK + '/control', json={'release': True})
            f.result()
        time.sleep(.05)
        rid = observed[0].get('rid')
        rec = [x for x in ledger() if x['request_id'] == rid]
        save('F01-F02-' + model + '-' + m, incremental_before_release=any('FIRST' in x.get('line', '') for x in before_release),
             released= released, observed=observed, upstream_calls=len(stats()['calls']), ledger=rec)

mode('normal')
for v in [1, 2]:
    r = c.post(BASE + '/v1/prompts', headers=AUTH, json={'id': 'teacher-probe', 'name': 'probe', 'content': 'v' + str(v) + ' {{name}}'})
    save('F05-publish', response=r.json())
for ref in [{'id': 'teacher-probe', 'version': 1, 'variables': {'name': 'Ada'}},
            {'id': 'teacher-probe', 'version': 2, 'variables': {'name': 'Bob'}},
            {'id': 'missing'}, {'id': 'teacher-probe', 'version': 999}, {'id': 'teacher-probe', 'version': 1}]:
    before = len(ledger())
    n = len(stats()['calls'])
    r = chat(MODELS[0], gateway_prompt=ref)
    save('F05-F06', ref=ref, status=r.status_code, response=r.json(), calls=stats()['calls'][n:], ledger_added=len(ledger())-before)

for model in MODELS:
    for m in ['retry', '503', '401', '400', '429']:
        mode(m)
        r = chat(model)
        calls = stats()['calls']
        save('F07-F09-' + model + '-' + m, status=r.status_code, response=r.json(), count=len(calls),
             intervals=[round(calls[i]['time']-calls[i-1]['time'], 3) for i in range(1, len(calls))], ledger=ledger()[0])

mode('normal')
p = subprocess.run(['/tmp/tiger-venv/bin/python', '/tmp/tiger-submission/verify_all.py'],
                   env={**__import__('os').environ, 'GATEWAY_BASE': BASE, 'GATEWAY_API_KEY': 'dev-key'}, capture_output=True, text=True)
(OUT / 'student-script-normal.log').write_text(p.stdout + p.stderr)
save('F12-script-normal', exit_code=p.returncode)
mode('401')
p = subprocess.run(['/tmp/tiger-venv/bin/python', '/tmp/tiger-submission/verify_all.py'],
                   env={**__import__('os').environ, 'GATEWAY_BASE': BASE, 'GATEWAY_API_KEY': 'dev-key'}, capture_output=True, text=True)
(OUT / 'student-script-failure.log').write_text(p.stdout + p.stderr)
save('F12-script-fault', exit_code=p.returncode)
(OUT / 'controlled-results.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
