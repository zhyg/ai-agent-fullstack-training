# G20261930010051 第一周第一次提交：评测证据

对象：https://github.com/helloTigerR/Tiger-AgentProjects

固定提交：551e19b724f830cd8e41e8f58a51b6a5d45b1b54（main clone，detached）。日期 2026-11-14 Asia/Singapore。

## 文件索引与安全边界

- source/：从固定提交导出的 app、tests、README、requirements、verify_all.py 和原示例配置；没有修改业务逻辑。源码内保留构造鉴权的方法，但没有捕获的真实请求鉴权头。
- controlled.yaml：纯本地模拟上游，不是真实模型。upstream-pro/upstream-flash 仅为模拟映射。
- real.yaml：原模型、原协议、DeepSeek 官方 origin；只引用 DEEPSEEK_API_KEY 环境变量，不含 secret。没有替代其他供应商。
- controlled_checks.py / mock_upstream.py：经过 TCP 的协议、JSON、门控流、失败、模板、重试实际实收计数、脚本故障验证。
- extra_checks.py：HTTP 接口的可控时钟限流恢复、角色丢失、错误 Schema；最后一段会真实补测 pro 显式 Schema，运行前知悉会消耗少量额度。
- boundary_checks.py：只在测试进程替换 transport、随机值、等待记录器，测 Schema 正常引用对照和精确睡眠入参；不改变业务函数。
- real_checks.py：真实短 Prompt 普通/SSE/JSON 请求。其输出只是网关返回用量，不是完整计费账单。
- controlled-results.json：初次完整受控运行原始输出；F12-script-normal 指固定返回 OK（因此两条 JSON 应失败），与 student-script-normal.log 对应。
- student-script-valid-person.log：后续设 mode=student 返回合法 name/age，12/12、退出 0；student-script-failure.log 为强制 401，5/12、退出 1；student-script-real.log 为官方真调用，12/12、退出 0。
- ledger*.json：两个网关曾共用 clone 下的 SQLite，快照含真实及受控记录，按结果内 request_id/时间核对，不把总和当真实消费。未收录数据库。

没有收录 .env、真实请求鉴权头、secret、.git、venv。占位本地演示口令来自学生公开 README，非真实供应商凭据。测试脚本不会输出凭据或请求头。

## 原实际命令与重放

本次独立 clone 在 /tmp/tiger-submission，venv 在 /tmp/tiger-venv，测试文件在课程仓库 .amp/in/orb-backup/tiger-eval。若移动证据目录，先替换脚本中这两条绝对路径及配置路径；不要更改 source/app 逻辑。extra/boundary 在单独临时工作目录运行，以免 TestClient 初始化使用正在运行的数据库。

1. git clone 仓库并 git checkout --detach 固定提交。
2. python -m venv /tmp/tiger-venv；/tmp/tiger-venv/bin/pip install -r requirements.txt。
3. 学生根目录执行 /tmp/tiger-venv/bin/python -m pytest tests/ -v，13 passed。
4. supervised service 启动 mock_upstream:app，--app-dir 指向证据脚本目录，--port 8124；启动原 app.main:app，GATEWAY_CONFIG 指向 controlled.yaml，--port 8125。
5. 等 healthz 成功后执行 controlled_checks.py，保留 controlled-results.json 和日志。门控先等客户端读取 FIRST，才释放上游终态；非仅依据时间早晚猜测增量。
6. 本地 mock /control POST JSON 设置 mode=student 后，GATEWAY_BASE 指向 8125，执行原 verify_all.py，得到 12/12。mode=401 会产生清晰 FAIL；mode=normal 固定 OK，JSON 检查必须失败，属于负向对照。
7. 在另一工作目录，GATEWAY_CONFIG 指向 controlled.yaml；mock /control 设 mode=json，再执行 extra_checks.py。限流测试时钟仅存在当前 TestClient 进程；上游 transport 在该段为受控 MockTransport。
8. 同样在单独工作目录执行 boundary_checks.py，记录固定抖动 0.05 时的 sleep 入参、实收请求数与有效本地引用。
9. 真实验证仅在已有 DEEPSEEK_API_KEY secret 时启用：用 real.yaml 启动原 app.main:app 到 8126，运行 real_checks.py、extra_checks.py 最后的显式 Schema 段，以及 GATEWAY_BASE 指向 8126 的学生 verify_all.py。只允许 api.deepseek.com，不打印环境变量值、不将配置插值后写盘。
10. 停止 tiger-real、tiger-controlled、tiger-mock，确认状态。见 services-final.log。

上述 extra_checks.py 最后补测真实 Schema，所以无凭据的完全离线复现需跳过该段，并明确记为跳过，而非真实成功。正文详细扣分和逐用例预期见同名评测附件。
