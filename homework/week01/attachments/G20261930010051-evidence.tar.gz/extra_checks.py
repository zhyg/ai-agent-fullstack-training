import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace
import httpx
from fastapi.testclient import TestClient

sys.path.insert(0, '/tmp/tiger-submission')
import app.main as main

OUT = Path(__file__).parent
AUTH = {'Authorization': 'Bearer dev-key'}
PRO, FLASH = 'deepseek-v4-pro', 'deepseek-v4-flash'
results = []
original_client = httpx.AsyncClient
calls = []

def handle(req):
    body = json.loads(req.content)
    calls.append({'path': req.url.path, 'body': body})
    if req.url.path.endswith('responses'):
        return httpx.Response(200, json={'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': 'OK'}]}], 'usage': {'input_tokens': 5, 'output_tokens': 3}})
    return httpx.Response(200, json={'content': [{'type': 'text', 'text': 'OK'}], 'usage': {'input_tokens': 5, 'output_tokens': 3}})

class ControlledClient(original_client):
    def __init__(self, *a, **kw):
        kw['transport'] = httpx.MockTransport(handle)
        super().__init__(*a, **kw)

with TestClient(main.app, raise_server_exceptions=False) as c:
    def chat(model=PRO, **kw):
        return c.post('/v1/chat/completions', headers=AUTH,
                      json={'model': model, 'messages': [{'role': 'user', 'content': 'hi'}], **kw})
    original_time = main.time
    now = [1000.0]
    main.time = SimpleNamespace(monotonic=lambda: now[0])
    main.LIMITER = main.RateLimiter({PRO: 2, FLASH: 3})
    httpx.AsyncClient = ControlledClient
    statuses = [chat().status_code for _ in range(3)]
    other = chat(FLASH).status_code
    now[0] += 29.99
    pre = chat().status_code
    now[0] += .02
    post = chat().status_code
    results.append({'case': 'F10-F11-clock-controlled', 'initial_statuses': statuses, 'other_model': other,
                    'after_29_99_seconds': pre, 'after_30_01_seconds': post,
                    'pass': statuses == [200, 200, 429] and other == 200 and pre == 429 and post == 200})
    main.time = original_time
    main.LIMITER = main.RateLimiter({PRO: 600, FLASH: 600})
    r = c.post('/v1/chat/completions', headers=AUTH, json={'model': PRO,
        'messages': [{'role': 'user', 'content': 'first user'}, {'role': 'assistant', 'content': 'previous answer'}, {'role': 'user', 'content': 'next user'}]})
    results.append({'case': 'responses-multiturn', 'status': r.status_code, 'actual_upstream_request': calls[-1]})
    httpx.AsyncClient = original_client
    for schema in [{'type': 'INVALID'}, {'$ref': '#/$defs/missing'}]:
        r = chat(response_format={'type': 'json_schema', 'json_schema': {'name': 'bad', 'schema': schema}})
        results.append({'case': 'invalid-schema', 'schema': schema, 'status': r.status_code, 'response': r.text[:1000]})

with httpx.Client(timeout=100) as c:
    r = c.post('http://127.0.0.1:8126/v1/chat/completions', headers=AUTH, json={
        'model': PRO, 'max_tokens': 256,
        'messages': [{'role': 'user', 'content': 'No reasoning needed. Output JSON: {"ok":true}'}],
        'response_format': {'type': 'json_schema', 'json_schema': {'name': 'probe', 'schema': {
            'type': 'object', 'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok'], 'additionalProperties': False}}}})
    results.append({'case': 'real-pro-explicit-schema', 'status': r.status_code, 'response': r.json(),
                    'mapping': 'deepseek-v4-pro -> deepseek-v4-pro / Responses / https://api.deepseek.com/v1/responses'})
    recs = c.get('http://127.0.0.1:8126/admin/usage', headers=AUTH, params={'limit': 1000}).json()
    (OUT / 'ledger-snapshot.json').write_text(json.dumps(recs, ensure_ascii=False, indent=2))

(OUT / 'extra-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
print(json.dumps(results, ensure_ascii=False, indent=2))
