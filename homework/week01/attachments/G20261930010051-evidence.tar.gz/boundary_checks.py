import asyncio
import json
import sys
from pathlib import Path
from types import SimpleNamespace
import httpx
from fastapi.testclient import TestClient

sys.path.insert(0, '/tmp/tiger-submission')
import app.main as main

results = []
calls, waits = [], []
original_client = httpx.AsyncClient
status = [200]
def handle(req):
    calls.append({'path': req.url.path, 'body': json.loads(req.content)})
    if status[0] != 200:
        return httpx.Response(status[0], text='controlled failure')
    return httpx.Response(200, json={'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': '{"ok":true}'}]}],
                                   'usage': {'input_tokens': 11, 'output_tokens': 7}})
class ControlledClient(original_client):
    def __init__(self, *a, **kw):
        kw['transport'] = httpx.MockTransport(handle)
        super().__init__(*a, **kw)
async def sleep(delay):
    waits.append(delay)

with TestClient(main.app, raise_server_exceptions=False) as c:
    httpx.AsyncClient = ControlledClient
    auth = {'Authorization': 'Bearer dev-key'}
    schema = {'type': 'object', 'properties': {'ok': {'$ref': '#/$defs/flag'}}, 'required': ['ok'], '$defs': {'flag': {'type': 'boolean'}}}
    r = c.post('/v1/chat/completions', headers=auth, json={'model': 'deepseek-v4-pro', 'messages': [{'role': 'user', 'content': 'hi'}],
        'response_format': {'type': 'json_schema', 'json_schema': {'name': 'reference', 'schema': schema}}})
    results.append({'case': 'B03-valid-local-ref', 'status': r.status_code, 'response': r.json()})
    original_asyncio, original_random = main.asyncio, main.random
    main.asyncio = SimpleNamespace(sleep=sleep)
    main.random = SimpleNamespace(uniform=lambda a, b: .05)
    for code in [503, 400]:
        for stream in [False, True]:
            calls.clear(); waits.clear(); status[0] = code
            r = c.post('/v1/chat/completions', headers=auth, json={'model': 'deepseek-v4-pro', 'stream': stream,
                'messages': [{'role': 'user', 'content': 'hi'}]})
            results.append({'case': 'F08-F09-recorded-waits', 'upstream_status': code, 'stream': stream, 'status': r.status_code,
                'received_requests': len(calls), 'sleep_delays': list(waits), 'response': r.text})
    main.asyncio, main.random = original_asyncio, original_random
    httpx.AsyncClient = original_client

Path(__file__).with_name('boundary-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
print(json.dumps(results, ensure_ascii=False, indent=2))
