from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class UnifiedRequest:
    """统一内部请求表示：上层只构造它，协议差异由适配器消化。"""

    model: str
    system: str | None = None
    messages: list[dict[str, str]] = field(default_factory=list)
    max_tokens: int = 1024
    temperature: float | None = None
    stream: bool = False
    json_schema: dict[str, Any] | None = None


@dataclass
class UnifiedResult:
    text: str = ""
    finish_reason: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    request_id: str | None = None


@dataclass
class UnifiedEvent:
    """流式统一事件：message_start / delta / message_end。"""

    kind: str
    text_delta: str | None = None
    finish_reason: str | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    request_id: str | None = None


class BaseAdapter(ABC):
    """适配器契约：封装端点、鉴权、请求体、响应与流式事件的协议差异。"""

    protocol: str

    @abstractmethod
    def endpoint(self, base_url: str) -> str: ...

    @abstractmethod
    def headers(self, api_key: str) -> dict[str, str]: ...

    @abstractmethod
    def build_body(self, req: UnifiedRequest) -> dict[str, Any]: ...

    @abstractmethod
    def parse_result(self, payload: dict[str, Any]) -> UnifiedResult: ...

    @abstractmethod
    def parse_sse(self, event: str | None, data: dict[str, Any]) -> UnifiedEvent | None: ...


class OpenAIResponsesAdapter(BaseAdapter):
    """DeepSeek v4-pro 走的 OpenAI Responses API。"""

    protocol = "responses"

    def endpoint(self, base_url: str) -> str:
        return base_url.rstrip("/") + "/v1/responses"

    def headers(self, api_key: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    def build_body(self, req: UnifiedRequest) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": req.model,
            "max_output_tokens": req.max_tokens,
            "stream": req.stream,
        }
        if req.system:
            body["instructions"] = req.system
        if req.messages:
            body["input"] = "\n\n".join(m["content"] for m in req.messages)
        if req.temperature is not None:
            body["temperature"] = req.temperature
        if req.json_schema:
            body["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": str(req.json_schema.get("title", "response")),
                    "schema": req.json_schema,
                    "strict": True,
                }
            }
        return body

    def parse_result(self, payload: dict[str, Any]) -> UnifiedResult:
        text = ""
        for item in payload.get("output", []):
            if item.get("type") == "message":
                for part in item.get("content", []):
                    if part.get("type") == "output_text":
                        text += part.get("text", "")
        usage = payload.get("usage") or {}
        return UnifiedResult(
            text=text,
            finish_reason=payload.get("status") or "completed",
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
            request_id=payload.get("id"),
        )

    def parse_sse(self, event: str | None, data: dict[str, Any]) -> UnifiedEvent | None:
        etype = data.get("type", event or "")
        if etype == "response.created":
            resp = data.get("response") or {}
            return UnifiedEvent("message_start", request_id=resp.get("id"))
        if etype == "response.output_text.delta":
            return UnifiedEvent("delta", text_delta=data.get("delta", ""))
        if etype == "response.completed":
            resp = data.get("response") or {}
            usage = resp.get("usage") or {}
            result = self.parse_result(resp)
            return UnifiedEvent(
                "message_end",
                finish_reason=result.finish_reason,
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                request_id=resp.get("id"),
            )
        return None


class AnthropicAdapter(BaseAdapter):
    """DeepSeek v4-flash 走的 Anthropic Messages API。"""

    protocol = "anthropic"

    def __init__(self, version: str = "2023-06-01", path: str = "/anthropic/v1/messages"):
        self.version = version
        self.path = path

    def endpoint(self, base_url: str) -> str:
        return base_url.rstrip("/") + self.path

    def headers(self, api_key: str) -> dict[str, str]:
        return {
            "x-api-key": api_key,
            "anthropic-version": self.version,
            "Content-Type": "application/json",
        }

    def build_body(self, req: UnifiedRequest) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": req.model,
            "max_tokens": req.max_tokens,
            "messages": req.messages or [{"role": "user", "content": ""}],
        }
        if req.system:
            body["system"] = req.system
        if req.temperature is not None:
            body["temperature"] = req.temperature
        if req.stream:
            body["stream"] = True
        return body

    def parse_result(self, payload: dict[str, Any]) -> UnifiedResult:
        text = "".join(
            part.get("text", "")
            for part in payload.get("content", [])
            if part.get("type") == "text"
        )
        usage = payload.get("usage") or {}
        return UnifiedResult(
            text=text,
            finish_reason=payload.get("stop_reason") or "end_turn",
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
            request_id=payload.get("id"),
        )

    def parse_sse(self, event: str | None, data: dict[str, Any]) -> UnifiedEvent | None:
        etype = event or data.get("type", "")
        if etype == "message_start":
            message = data.get("message") or {}
            usage = message.get("usage") or {}
            return UnifiedEvent(
                "message_start",
                request_id=message.get("id"),
                input_tokens=usage.get("input_tokens", 0),
            )
        if etype == "content_block_delta":
            delta = data.get("delta") or {}
            if delta.get("type") == "text_delta":
                return UnifiedEvent("delta", text_delta=delta.get("text", ""))
            return None
        if etype == "message_delta":
            delta = data.get("delta") or {}
            usage = data.get("usage") or {}
            return UnifiedEvent(
                "message_end",
                finish_reason=delta.get("stop_reason"),
                output_tokens=usage.get("output_tokens", 0),
            )
        return None


ADAPTERS: dict[str, BaseAdapter] = {
    "responses": OpenAIResponsesAdapter(),
    "anthropic": AnthropicAdapter(),
}


def get_adapter(protocol: str) -> BaseAdapter:
    if protocol not in ADAPTERS:
        raise ValueError(f"Unknown protocol: {protocol}")
    return ADAPTERS[protocol]


def encode_openai_chunk(
    model: str,
    request_id: str | None,
    text_delta: str | None = None,
    finish_reason: str | None = None,
    usage: dict[str, int] | None = None,
) -> str:
    """把统一事件编码为 OpenAI chunk 格式的 SSE 数据行。客户端只见这一种协议。"""
    delta: dict[str, Any] = {}
    if text_delta is not None:
        delta["content"] = text_delta
    choice: dict[str, Any] = {"index": 0, "delta": delta}
    if finish_reason:
        choice["finish_reason"] = finish_reason
    chunk: dict[str, Any] = {
        "id": request_id or "chatcmpl-gateway",
        "object": "chat.completion.chunk",
        "model": model,
        "choices": [choice],
    }
    if usage is not None:
        chunk["usage"] = usage
    return "data: " + json.dumps(chunk, ensure_ascii=False) + "\n\n"
