from __future__ import annotations


class GatewayError(Exception):
    """统一错误对象：所有错误出网前必须归一化为 OpenAI 风格 error 结构。"""

    def __init__(
        self,
        message: str,
        status_code: int = 500,
        error_type: str = "api_error",
        code: str | None = None,
        param: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_type = error_type
        self.code = code
        self.param = param

    def to_payload(self) -> dict:
        error: dict[str, str] = {
            "message": self.message,
            "type": self.error_type,
        }
        if self.code:
            error["code"] = self.code
        if self.param:
            error["param"] = self.param
        return {"error": error}


def upstream_error(message: str, status_code: int = 502, code: str = "upstream_error") -> GatewayError:
    return GatewayError(message, status_code=status_code, error_type="upstream_error", code=code)
