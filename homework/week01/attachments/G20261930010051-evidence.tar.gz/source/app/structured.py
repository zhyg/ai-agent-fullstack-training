from __future__ import annotations

import json
import re
from typing import Any

import jsonschema


SCHEMA_INSTRUCTION = (
    "你必须只输出一个符合以下 JSON Schema 的 JSON 对象。"
    "不要输出任何解释文字，不要输出 markdown 代码块标记，只输出 JSON 本身。\n"
    "JSON Schema:\n{schema}"
)

REPAIR_INSTRUCTION = (
    "你上一次的输出未通过 JSON Schema 校验。\n"
    "校验错误：{error}\n"
    "请严格按 JSON Schema 重新输出，只输出 JSON 本身，不要任何其他文字。\n"
    "JSON Schema:\n{schema}"
)


def schema_instruction(schema: dict[str, Any]) -> str:
    """注入到 system 的 Schema 约束指令（供不支持原生 schema 的协议使用）。"""
    return SCHEMA_INSTRUCTION.format(schema=json.dumps(schema, ensure_ascii=False))


def extract_json(text: str) -> Any:
    """三级降级提取 JSON：直接解析 → 剥 markdown 围栏 → 截取首尾大括号。"""
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    if fenced:
        try:
            return json.loads(fenced.group(1).strip())
        except json.JSONDecodeError:
            pass
    start = min((i for i in (text.find("{"), text.find("[")) if i != -1), default=-1)
    end = max(text.rfind("}"), text.rfind("]"))
    if start != -1 and end > start:
        return json.loads(text[start : end + 1])
    raise json.JSONDecodeError("no json found", text, 0)


def validate_json(text: str, schema: dict[str, Any]) -> tuple[Any | None, str | None]:
    """返回 (数据, None) 或 (None, 错误描述)。错误描述将回喂给模型做修复。"""
    try:
        data = extract_json(text)
    except (json.JSONDecodeError, ValueError) as exc:
        return None, f"输出不是合法 JSON: {exc}"
    try:
        jsonschema.validate(data, schema)
    except jsonschema.ValidationError as exc:
        path = "/".join(str(p) for p in exc.absolute_path)
        return None, f"JSON Schema 校验失败（路径: {path or '根'}）: {exc.message}"
    return data, None
