from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any

from jinja2 import StrictUndefined
from jinja2.exceptions import TemplateError
from jinja2.sandbox import SandboxedEnvironment

from app.errors import GatewayError


class UsageLedger:
    """调用账本：token 分类统计、延迟、TTFT、重试次数、状态（success/cancelled/error）。"""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn
        self._lock = threading.Lock()
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT NOT NULL,
                created_at TEXT NOT NULL,
                model TEXT NOT NULL,
                protocol TEXT NOT NULL,
                input_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0,
                total_ms REAL NOT NULL DEFAULT 0,
                ttft_ms REAL,
                retries INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL,
                error_code TEXT,
                prompt_id TEXT,
                prompt_version INTEGER
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_usage_request_id ON usage(request_id)"
        )
        conn.commit()

    def record(
        self,
        request_id: str,
        model: str,
        protocol: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        total_ms: float = 0.0,
        ttft_ms: float | None = None,
        retries: int = 0,
        status: str = "success",
        error_code: str | None = None,
        prompt_id: str | None = None,
        prompt_version: int | None = None,
    ) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO usage (
                    request_id, created_at, model, protocol,
                    input_tokens, output_tokens, total_ms, ttft_ms,
                    retries, status, error_code, prompt_id, prompt_version
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    request_id,
                    datetime.now(timezone.utc).isoformat(),
                    model,
                    protocol,
                    input_tokens,
                    output_tokens,
                    total_ms,
                    ttft_ms,
                    retries,
                    status,
                    error_code,
                    prompt_id,
                    prompt_version,
                ),
            )
            self._conn.commit()

    def query(self, limit: int = 20, request_id: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            if request_id:
                rows = self._conn.execute(
                    "SELECT * FROM usage WHERE request_id = ? ORDER BY id DESC",
                    (request_id,),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM usage ORDER BY id DESC LIMIT ?", (limit,)
                ).fetchall()
        return [dict(row) for row in rows]


class PromptStore:
    """提示词版本管理：存储、版本引用、激活版本、Jinja2 严格渲染。"""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn
        self._lock = threading.Lock()
        self._env = SandboxedEnvironment(undefined=StrictUndefined)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS prompts (
                prompt_id TEXT NOT NULL,
                version INTEGER NOT NULL,
                name TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                PRIMARY KEY (prompt_id, version)
            )
            """
        )
        conn.commit()

    def upsert(
        self,
        prompt_id: str,
        name: str,
        role: str,
        content: str,
        activate: bool = True,
    ) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT MAX(version) AS v FROM prompts WHERE prompt_id = ?",
                (prompt_id,),
            ).fetchone()
            version = (row["v"] or 0) + 1
            now = datetime.now(timezone.utc).isoformat()
            if activate:
                self._conn.execute(
                    "UPDATE prompts SET active = 0 WHERE prompt_id = ?", (prompt_id,)
                )
            self._conn.execute(
                """
                INSERT INTO prompts (prompt_id, version, name, role, content, active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (prompt_id, version, name, role, content, 1 if activate else 0, now),
            )
            self._conn.commit()
        return version

    def get(self, prompt_id: str, version: int | None = None) -> dict[str, Any]:
        with self._lock:
            if version is not None:
                row = self._conn.execute(
                    "SELECT * FROM prompts WHERE prompt_id = ? AND version = ?",
                    (prompt_id, version),
                ).fetchone()
            else:
                row = self._conn.execute(
                    "SELECT * FROM prompts WHERE prompt_id = ? AND active = 1",
                    (prompt_id,),
                ).fetchone()
        if row is None:
            raise GatewayError(
                f"Prompt not found: {prompt_id}"
                + (f" version {version}" if version is not None else " (no active version)"),
                status_code=404,
                error_type="invalid_request_error",
                code="prompt_not_found",
                param="gateway_prompt",
            )
        return dict(row)

    def render(self, prompt: dict[str, Any], variables: dict[str, Any] | None) -> str:
        try:
            template = self._env.from_string(prompt["content"])
            return template.render(**(variables or {}))
        except TemplateError as exc:
            raise GatewayError(
                f"Template render failed for prompt '{prompt['prompt_id']}' "
                f"v{prompt['version']}: {exc}",
                status_code=422,
                error_type="invalid_request_error",
                code="template_error",
            ) from exc
