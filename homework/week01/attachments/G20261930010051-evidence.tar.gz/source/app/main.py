from __future__ import annotations

import asyncio
import json
import os
import random
import re
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator

import httpx
import uvicorn
import yaml
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app.adapters import UnifiedRequest, encode_openai_chunk, get_adapter
from app.errors import GatewayError
from app.store import PromptStore, UsageLedger
from app.structured import REPAIR_INSTRUCTION, schema_instruction, validate_json

RETRYABLE_STATUS = {429, 500, 502, 503, 504}
MAX_RETRIES = 3
BASE_DELAY = 0.5

DEFAULT_CONFIG: dict[str, Any] = {
    "gateway_api_key": "dev-key",
    "rate_limit_rpm": {"deepseek-v4-pro": 10, "deepseek-v4-flash": 30},
    "providers": {
        "deepseek": {"base_url": "https://api.deepseek.com", "api_key": ""}
    },
    "models": {
        "deepseek-v4-pro": {
            "provider": "deepseek",
            "model": "deepseek-v4-pro",
            "protocol": "responses",
        },
        "deepseek-v4-flash": {
            "provider": "deepseek",
            "model": "deepseek-v4-flash",
            "protocol": "anthropic",
        },
    },
}


def _interpolate_env(raw: str) -> str:
    """把配置里的 ${VAR} 替换为环境变量值，密钥不落盘。"""
    return re.sub(
        r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}",
        lambda m: os.environ.get(m.group(1), ""),
        raw,
    )


def load_config(path: str) -> dict[str, Any]:
    raw = Path(path).read_text(encoding="utf-8")
    return yaml.safe_load(_interpolate_env(raw))


_config_path = os.environ.get("GATEWAY_CONFIG", "")
CONFIG = (
    load_config(_config_path)
    if _config_path and Path(_config_path).exists()
    else DEFAULT_CONFIG
)


class RateLimiter:
    """按模型别名的独立令牌桶（进程内）。"""

    def __init__(self, rpm_config: dict[str, int]) -> None:
        self._rpm = rpm_config
        self._state: dict[str, tuple[float, float]] = {}

    def acquire(self, model: str) -> float | None:
        rpm = self._rpm.get(model)
        if not rpm:
            return None
        now = time.monotonic()
        tokens, ts = self._state.get(model, (float(rpm), now))
        tokens = min(float(rpm), tokens + (now - ts) * rpm / 60.0)
        if tokens >= 1.0:
            self._state[model] = (tokens - 1.0, now)
            return None
        self._state[model] = (tokens, now)
        return max(1.0, (1.0 - tokens) * 60.0 / rpm)


class GatewayPromptRef(BaseModel):
    id: str
    variables: dict[str, Any] | None = None
    version: int | None = None


class ChatRequest(BaseModel):
    model: str
    messages: list[dict[str, str]] = []
    stream: bool = False
    max_tokens: int = 1024
    temperature: float | None = None
    response_format: dict[str, Any] | None = None
    gateway_prompt: GatewayPromptRef | None = None


class PromptUpsert(BaseModel):
    id: str
    name: str
    role: str = "system"
    content: str
    activate: bool = True


@asynccontextmanager
async def lifespan(_: FastAPI):
    global LEDGER, PROMPTS, LIMITER
    Path("data").mkdir(exist_ok=True)
    conn = sqlite3.connect("data/gateway.db", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    LEDGER = UsageLedger(conn)
    PROMPTS = PromptStore(conn)
    LIMITER = RateLimiter(CONFIG.get("rate_limit_rpm", {}))
    yield


app = FastAPI(title="Unified LLM Gateway", lifespan=lifespan)


@app.exception_handler(GatewayError)
async def gateway_error_handler(_: Request, exc: GatewayError) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content=exc.to_payload())


def check_auth(request: Request) -> None:
    expected = f"Bearer {CONFIG['gateway_api_key']}"
    if request.headers.get("authorization", "") != expected:
        raise GatewayError(
            "Invalid gateway API key",
            status_code=401,
            error_type="invalid_request_error",
            code="invalid_api_key",
        )


def resolve_route(model: str) -> dict[str, Any]:
    """动态路由：按请求 model 别名查配置表，决定协议与真实模型。"""
    route = CONFIG["models"].get(model)
    if route is None:
        raise GatewayError(
            f"Unknown model alias: {model}",
            status_code=404,
            error_type="invalid_request_error",
            code="model_not_found",
            param="model",
        )
    return route


def extract_schema(response_format: dict[str, Any] | None) -> dict[str, Any] | None:
    if not response_format:
        return None
    rtype = response_format.get("type")
    if rtype == "json_schema":
        return (response_format.get("json_schema") or {}).get("schema")
    if rtype == "json_object":
        return {"type": "object"}
    return None


async def upstream_post(
    client: httpx.AsyncClient,
    adapter: Any,
    ureq: UnifiedRequest,
    provider: dict[str, Any],
) -> tuple[dict[str, Any], int]:
    """非流式上游调用，含指数退避重试（仅 429/5xx/网络错误）。"""
    url = adapter.endpoint(provider["base_url"])
    headers = adapter.headers(provider["api_key"])
    body = adapter.build_body(ureq)
    retries = 0
    last_exc: Exception | None = None
    for attempt in range(MAX_RETRIES + 1):
        resp = None
        try:
            resp = await client.post(url, headers=headers, json=body)
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            last_exc = exc
        if resp is not None and resp.status_code < 400:
            return resp.json(), retries
        if resp is not None and resp.status_code not in RETRYABLE_STATUS:
            code = "upstream_auth" if resp.status_code == 401 else "upstream_error"
            raise GatewayError(
                f"upstream {resp.status_code}: {resp.text[:200]}",
                status_code=502,
                error_type="upstream_error",
                code=code,
            )
        if attempt >= MAX_RETRIES:
            break
        delay = BASE_DELAY * (2**retries) + random.uniform(0, 0.1)
        retries += 1
        await asyncio.sleep(delay)
    raise GatewayError(
        f"upstream unreachable after {retries} retries: {last_exc}",
        status_code=502,
        error_type="upstream_error",
        code="upstream_error",
    )


async def call_non_stream(
    client: httpx.AsyncClient,
    route: dict[str, Any],
    ureq: UnifiedRequest,
) -> tuple[Any, int, int]:
    """非流式调用 + 结构化输出修复循环（最多 2 轮，失败 422）。"""
    provider = CONFIG["providers"][route["provider"]]
    adapter = get_adapter(route["protocol"])
    data, retries = await upstream_post(client, adapter, ureq, provider)
    result = adapter.parse_result(data)
    repair_rounds = 0
    if ureq.json_schema:
        _, err = validate_json(result.text, ureq.json_schema)
        while err is not None and repair_rounds < 2:
            repair_text = REPAIR_INSTRUCTION.format(
                error=err,
                schema=json.dumps(ureq.json_schema, ensure_ascii=False),
            )
            # 合并进最后一条 user 消息，避免违反 Anthropic 的角色交替约束
            if ureq.messages and ureq.messages[-1]["role"] == "user":
                ureq.messages[-1]["content"] += "\n\n" + repair_text
            else:
                ureq.messages.append({"role": "user", "content": repair_text})
            data, r = await upstream_post(client, adapter, ureq, provider)
            retries += r
            result = adapter.parse_result(data)
            repair_rounds += 1
            _, err = validate_json(result.text, ureq.json_schema)
        if err is not None:
            raise GatewayError(
                f"structured output failed schema validation after "
                f"{repair_rounds} repairs: {err}",
                status_code=422,
                error_type="invalid_request_error",
                code="schema_violation",
            )
    return result, retries, repair_rounds


def chat_response(model: str, result: Any) -> dict[str, Any]:
    return {
        "id": result.request_id or "chatcmpl-gateway",
        "object": "chat.completion",
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": result.text},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": result.input_tokens,
            "completion_tokens": result.output_tokens,
            "total_tokens": result.input_tokens + result.output_tokens,
        },
    }


async def connect_stream(
    client: httpx.AsyncClient,
    route: dict[str, Any],
    ureq: UnifiedRequest,
) -> tuple[httpx.Response, int]:
    """建立流式上游连接。只在首块到达前重试；进入流后不再重试。"""
    provider = CONFIG["providers"][route["provider"]]
    adapter = get_adapter(route["protocol"])
    url = adapter.endpoint(provider["base_url"])
    headers = adapter.headers(provider["api_key"])
    body = adapter.build_body(ureq)
    retries = 0
    last_exc: Exception | None = None
    for attempt in range(MAX_RETRIES + 1):
        resp = None
        try:
            req = client.build_request("POST", url, headers=headers, json=body)
            resp = await client.send(req, stream=True)
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            last_exc = exc
        if resp is not None and resp.status_code < 400:
            return resp, retries
        if resp is not None:
            snippet = (await resp.aread()).decode("utf-8", "replace")[:200]
            await resp.aclose()
            if resp.status_code not in RETRYABLE_STATUS:
                code = "upstream_auth" if resp.status_code == 401 else "upstream_error"
                raise GatewayError(
                    f"upstream {resp.status_code}: {snippet}",
                    status_code=502,
                    error_type="upstream_error",
                    code=code,
                )
        if attempt >= MAX_RETRIES:
            break
        delay = BASE_DELAY * (2**retries) + random.uniform(0, 0.1)
        retries += 1
        await asyncio.sleep(delay)
    raise GatewayError(
        f"upstream unreachable after {retries} retries: {last_exc}",
        status_code=502,
        error_type="upstream_error",
        code="upstream_error",
    )


async def sse_stream(
    chat_req: ChatRequest,
    ureq: UnifiedRequest,
    route: dict[str, Any],
    request: Request,
    rid: str,
    prompt_id: str | None,
    prompt_version: int | None,
    start: float,
) -> AsyncIterator[str]:
    """SSE 转发主循环：协议翻译、TTFT、断开取消、finally 落库。"""
    status = "success"
    error_code: str | None = None
    upstream_id: str | None = None
    input_tokens = 0
    output_tokens = 0
    est_out = 0
    ttft_ms: float | None = None
    retries = 0
    client = httpx.AsyncClient(timeout=httpx.Timeout(60.0, read=120.0))
    resp: httpx.Response | None = None
    try:
        resp, retries = await connect_stream(client, route, ureq)
        adapter = get_adapter(route["protocol"])
        event_name: str | None = None
        async for line in resp.aiter_lines():
            if await request.is_disconnected():
                status = "cancelled"
                break
            if line.startswith("event:"):
                event_name = line[6:].strip() or None
                continue
            if not line.startswith("data:"):
                continue
            data_str = line[5:].strip()
            if data_str == "[DONE]":
                event_name = None
                continue
            try:
                data = json.loads(data_str)
            except json.JSONDecodeError:
                continue
            ev = adapter.parse_sse(event_name, data)
            event_name = None
            if ev is None:
                continue
            if ev.kind == "message_start":
                upstream_id = ev.request_id or upstream_id
                if ev.input_tokens:
                    input_tokens = ev.input_tokens
                yield encode_openai_chunk(chat_req.model, upstream_id or rid)
            elif ev.kind == "delta":
                if ttft_ms is None:
                    ttft_ms = (time.monotonic() - start) * 1000
                est_out += max(1, len(ev.text_delta or "") // 4)
                yield encode_openai_chunk(
                    chat_req.model, upstream_id or rid, text_delta=ev.text_delta
                )
            elif ev.kind == "message_end":
                if ev.input_tokens is not None:
                    input_tokens = ev.input_tokens
                if ev.output_tokens:
                    output_tokens = ev.output_tokens
                upstream_id = ev.request_id or upstream_id
                yield encode_openai_chunk(
                    chat_req.model,
                    upstream_id or rid,
                    finish_reason="stop",
                    usage={
                        "prompt_tokens": input_tokens,
                        "completion_tokens": output_tokens or est_out,
                        "total_tokens": input_tokens + (output_tokens or est_out),
                    },
                )
        if status != "cancelled":
            yield "data: [DONE]\n\n"
    except GatewayError as exc:
        status = "error"
        error_code = exc.code
        payload = json.dumps(exc.to_payload(), ensure_ascii=False)
        yield f"data: {payload}\n\n"
        yield "data: [DONE]\n\n"
    except (asyncio.CancelledError, GeneratorExit):
        status = "cancelled"
        raise
    finally:
        # 三个保障：关闭上游（DeepSeek 停止生成）、关闭客户端、兜底落库
        if resp is not None:
            await resp.aclose()
        await client.aclose()
        total_ms = (time.monotonic() - start) * 1000
        LEDGER.record(
            request_id=rid,
            model=chat_req.model,
            protocol=route["protocol"],
            input_tokens=input_tokens,
            output_tokens=output_tokens or est_out,
            total_ms=round(total_ms, 2),
            ttft_ms=round(ttft_ms, 2) if ttft_ms is not None else None,
            retries=retries,
            status=status,
            error_code=error_code,
            prompt_id=prompt_id,
            prompt_version=prompt_version,
        )


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/v1/models")
async def list_models(request: Request) -> dict[str, Any]:
    check_auth(request)
    return {
        "object": "list",
        "data": [{"id": m, "object": "model"} for m in CONFIG["models"]],
    }


@app.post("/v1/prompts")
async def create_prompt(payload: PromptUpsert, request: Request) -> dict[str, Any]:
    check_auth(request)
    version = PROMPTS.upsert(
        payload.id, payload.name, payload.role, payload.content, payload.activate
    )
    return {"id": payload.id, "version": version, "active": payload.activate}


@app.get("/admin/usage")
async def admin_usage(
    request: Request,
    limit: int = 20,
    request_id: str | None = None,
) -> dict[str, Any]:
    check_auth(request)
    return {"records": LEDGER.query(limit=limit, request_id=request_id)}


@app.post("/v1/chat/completions")
async def chat_completions(chat_req: ChatRequest, request: Request) -> Any:
    check_auth(request)
    start = time.monotonic()
    rid = "req_" + uuid.uuid4().hex[:12]

    retry_after = LIMITER.acquire(chat_req.model)
    if retry_after is not None:
        raise GatewayError(
            f"rate limit exceeded for model {chat_req.model}, retry after {retry_after:.1f}s",
            status_code=429,
            error_type="rate_limit_error",
            code="rate_limited",
        )

    route = resolve_route(chat_req.model)

    prompt_id: str | None = None
    prompt_version: int | None = None
    rendered_prompt: str | None = None
    if chat_req.gateway_prompt:
        ref = chat_req.gateway_prompt
        prompt = PROMPTS.get(ref.id, ref.version)
        rendered_prompt = PROMPTS.render(prompt, ref.variables)
        prompt_id = prompt["prompt_id"]
        prompt_version = prompt["version"]
        if prompt["role"] != "system":
            chat_req.messages.insert(0, {"role": prompt["role"], "content": rendered_prompt})
            rendered_prompt = None

    client_system = "\n".join(
        m["content"] for m in chat_req.messages if m.get("role") == "system"
    )
    messages = [m for m in chat_req.messages if m.get("role") != "system"]
    system_parts = [s for s in (client_system, rendered_prompt) if s]
    system = "\n\n".join(system_parts) or None

    schema = extract_schema(chat_req.response_format)
    ureq = UnifiedRequest(
        model=route["model"],
        system=system,
        messages=messages,
        max_tokens=chat_req.max_tokens,
        temperature=chat_req.temperature,
        stream=chat_req.stream,
        json_schema=schema,  # 所有协议都做本地校验；responses 另走原生 text.format
    )
    if schema and route["protocol"] != "responses":
        # Anthropic 协议无原生 schema：注入到 system，配合修复循环
        ureq.system = ((system or "") + "\n\n" + schema_instruction(schema)).strip()

    if chat_req.stream:
        return StreamingResponse(
            sse_stream(
                chat_req, ureq, route, request, rid, prompt_id, prompt_version, start
            ),
            media_type="text/event-stream",
            headers={
                "X-Request-ID": rid,
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    retries = 0
    status = "success"
    error_code: str | None = None
    result = None
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            result, retries, _repair = await call_non_stream(client, route, ureq)
    except GatewayError as exc:
        status = "error"
        error_code = exc.code
        LEDGER.record(
            request_id=rid,
            model=chat_req.model,
            protocol=route["protocol"],
            total_ms=round((time.monotonic() - start) * 1000, 2),
            retries=retries,
            status=status,
            error_code=error_code,
            prompt_id=prompt_id,
            prompt_version=prompt_version,
        )
        raise
    LEDGER.record(
        request_id=rid,
        model=chat_req.model,
        protocol=route["protocol"],
        input_tokens=result.input_tokens,
        output_tokens=result.output_tokens,
        total_ms=round((time.monotonic() - start) * 1000, 2),
        retries=retries,
        status=status,
        error_code=error_code,
        prompt_id=prompt_id,
        prompt_version=prompt_version,
    )
    return JSONResponse(chat_response(chat_req.model, result))


_static_dir = Path(__file__).resolve().parent.parent / "static"
if _static_dir.exists():
    app.mount("/", StaticFiles(directory=str(_static_dir), html=True), name="static")


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
