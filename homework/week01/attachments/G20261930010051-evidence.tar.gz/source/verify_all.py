from __future__ import annotations

import json
import os
import sys
import time

import httpx

BASE = os.environ.get("GATEWAY_BASE", "http://localhost:8000")
KEY = os.environ.get("GATEWAY_API_KEY", "dev-key")
AUTH = {"Authorization": f"Bearer {KEY}"}
PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"

results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  ({detail})" if detail else ""))


def main() -> int:
    c = httpx.Client(timeout=90)

    try:
        r = c.get(f"{BASE}/healthz")
        check("T0.0 健康检查", r.status_code == 200)
    except Exception as exc:
        check("T0.0 健康检查", False, str(exc))
        return 1

    r = c.get(f"{BASE}/v1/models", headers=AUTH)
    ids = {m["id"] for m in r.json().get("data", [])} if r.status_code == 200 else set()
    check("T0.1 模型列表", {PRO, FLASH} <= ids, ",".join(sorted(ids)))

    for model in (PRO, FLASH):
        r = c.post(
            f"{BASE}/v1/chat/completions",
            headers=AUTH,
            json={"model": model, "max_tokens": 100,
                  "messages": [{"role": "user", "content": "用一句话介绍你自己"}]},
        )
        ok = r.status_code == 200 and bool(r.json()["choices"][0]["message"]["content"])
        usage = r.json().get("usage", {}) if ok else {}
        check(f"T0.2 冒烟 {model}", ok,
              f"in={usage.get('prompt_tokens')} out={usage.get('completion_tokens')}")

    for model in (PRO, FLASH):
        chunks = 0
        rid = ""
        try:
            with c.stream(
                "POST", f"{BASE}/v1/chat/completions", headers=AUTH,
                json={"model": model, "stream": True, "max_tokens": 100,
                      "messages": [{"role": "user", "content": "从1数到5"}]},
            ) as resp:
                rid = resp.headers.get("X-Request-ID", "")
                for line in resp.iter_lines():
                    if line.startswith("data:") and line != "data: [DONE]":
                        chunks += 1
            check(f"T1 流式 {model}", chunks >= 2, f"chunks={chunks} rid={rid}")
        except Exception as exc:
            check(f"T1 流式 {model}", False, str(exc))

    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        "required": ["name", "age"], "additionalProperties": False,
    }
    for model in (PRO, FLASH):
        try:
            r = c.post(
                f"{BASE}/v1/chat/completions", headers=AUTH,
                json={"model": model, "max_tokens": 200,
                      "messages": [{"role": "user", "content": "提取：Ada 36岁"}],
                      "response_format": {"type": "json_schema",
                                          "json_schema": {"name": "person", "schema": schema}}},
            )
            ok = r.status_code == 200
            data = None
            if ok:
                try:
                    data = json.loads(r.json()["choices"][0]["message"]["content"])
                except json.JSONDecodeError:
                    ok = False
            check(f"T2 结构化 {model}", ok and isinstance(data, dict)
                  and bool(data.get("name")) and isinstance(data.get("age"), int), str(data))
        except Exception as exc:
            check(f"T2 结构化 {model}", False, str(exc))

    try:
        r = c.post(f"{BASE}/v1/prompts", headers=AUTH, json={
            "id": "verify-reviewer", "name": "验证模板",
            "content": "你是 {{ language }} 资深代码审查助手，只输出一句话结论。",
        })
        version = r.json().get("version") if r.status_code == 200 else None
        check("T3.1 模板创建", version is not None, f"v{version}")

        r = c.post(
            f"{BASE}/v1/chat/completions", headers=AUTH,
            json={"model": PRO, "max_tokens": 100,
                  "messages": [{"role": "user", "content": "审查: eval(input())"}],
                  "gateway_prompt": {"id": "verify-reviewer",
                                     "variables": {"language": "Python"}}},
        )
        check("T3.2 模板引用", r.status_code == 200)
    except Exception as exc:
        check("T3 模板", False, str(exc))

    try:
        r = c.get(f"{BASE}/admin/usage", headers=AUTH, params={"limit": 5})
        recs = r.json().get("records", []) if r.status_code == 200 else []
        ok = bool(recs) and all(
            {"input_tokens", "output_tokens", "total_ms", "status"} <= set(rec.keys())
            for rec in recs[:3]
        )
        check("T4 可观测账本", ok, f"{len(recs)} 条记录")

        if recs:
            rid = recs[0]["request_id"]
            r = c.get(f"{BASE}/admin/usage", headers=AUTH, params={"request_id": rid})
            check("T4.1 Trace 按 request_id 查询",
                  r.status_code == 200 and len(r.json()["records"]) >= 1, rid)
    except Exception as exc:
        check("T4 可观测账本", False, str(exc))

    print("\n—— 以下两项需人工验证，见 README ——")
    print("· T6 限流：config.yaml 中 pro 的 rpm 改为 2 后重启，1 秒内连发 3 个请求，第 3 个应 429")
    print("· T7 停止生成：浏览器打开首页 → 发起流式 → 收到几段后点停止 → 点 Trace 链接应看到 status=cancelled")

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n合计: {passed}/{len(results)} PASS")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
