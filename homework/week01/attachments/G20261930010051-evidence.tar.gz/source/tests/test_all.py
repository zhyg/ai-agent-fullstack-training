from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

import app.main as main
from app.adapters import UnifiedRequest
from app.errors import GatewayError
from app.main import ChatRequest, RateLimiter, app, sse_stream

PRO = "deepseek-v4-pro"
FLASH = "deepseek-v4-flash"
RESP = "/v1/responses"
ANTH = "/anthropic/v1/messages"
AUTH = {"Authorization": "Bearer dev-key"}
PERSON_SCHEMA = {
    "type": "object",
    "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
    "required": ["name", "age"],
    "additionalProperties": False,
}


class MockUpstream:
    """按剧本回放上游响应：on(path, 结果1, 结果2, ...) 顺序消费，耗尽后重复最后一个。"""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.calls: list[dict] = []
        self.script: dict[str, list[dict]] = {}

    def on(self, path: str, *outcomes: dict) -> None:
        self.script[path] = list(outcomes)

    def __call__(self, request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content.decode("utf-8") or "{}")
        self.calls.append(
            {"path": request.url.path, "body": body, "t": time.monotonic()}
        )
        outcomes = self.script.get(request.url.path) or self.script.get("*")
        if not outcomes:
            raise RuntimeError(f"unexpected upstream call: {request.url.path}")
        outcome = outcomes.pop(0) if len(outcomes) > 1 else outcomes[0]
        return render_outcome(outcome)


def render_outcome(o: dict) -> httpx.Response:
    if "sse" in o:
        first_delay = o.get("first_delay", 0.0)

        async def gen():
            if first_delay:
                await asyncio.sleep(first_delay)
            for ev, data in o["sse"]:
                if ev:
                    yield f"event: {ev}\n".encode()
                yield ("data: " + json.dumps(data) + "\n\n").encode()
            yield b"data: [DONE]\n\n"

        return httpx.Response(
            200, content=gen(), headers={"content-type": "text/event-stream"}
        )
    status = o.get("status", 200)
    if "json" in o:
        return httpx.Response(status, json=o["json"])
    return httpx.Response(status, text=o.get("text", "upstream error"))


def resp_json(text: str, i: int = 100, o: int = 50) -> dict:
    return {
        "json": {
            "id": "resp_mock",
            "status": "completed",
            "output": [
                {"type": "message", "content": [{"type": "output_text", "text": text}]}
            ],
            "usage": {"input_tokens": i, "output_tokens": o},
        }
    }


def anth_json(text: str, i: int = 100, o: int = 50) -> dict:
    return {
        "json": {
            "id": "msg_mock",
            "content": [{"type": "text", "text": text}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": i, "output_tokens": o},
        }
    }


def resp_sse(deltas: list[str], i: int = 100, o: int = 50) -> dict:
    events = [(None, {"type": "response.created", "response": {"id": "resp_mock"}})]
    events += [
        (None, {"type": "response.output_text.delta", "delta": d}) for d in deltas
    ]
    events.append(
        (
            None,
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_mock",
                    "status": "completed",
                    "usage": {"input_tokens": i, "output_tokens": o},
                },
            },
        )
    )
    return {"sse": events}


def anth_sse(
    deltas: list[str], i: int = 100, o: int = 50, first_delay: float = 0.0
) -> dict:
    events = [
        (
            "message_start",
            {
                "type": "message_start",
                "message": {"id": "msg_mock", "usage": {"input_tokens": i}},
            },
        )
    ]
    events += [
        (
            "content_block_delta",
            {"type": "content_block_delta", "delta": {"type": "text_delta", "text": d}},
        )
        for d in deltas
    ]
    events.append(
        (
            "message_delta",
            {
                "type": "message_delta",
                "delta": {"stop_reason": "end_turn"},
                "usage": {"output_tokens": o},
            },
        )
    )
    return {"sse": events, "first_delay": first_delay}


UPSTREAM = MockUpstream()


@pytest.fixture()
def upstream(monkeypatch):
    UPSTREAM.reset()

    class PatchedClient(httpx.AsyncClient):
        def __init__(self, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(UPSTREAM)
            super().__init__(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", PatchedClient)
    return UPSTREAM


@pytest.fixture()
def client():
    # 每次测试会话重置数据库，避免跨运行的状态污染（版本号漂移等）
    db = Path(__file__).resolve().parent.parent / "data" / "gateway.db"
    for suffix in ("", "-journal", "-wal", "-shm"):
        p = Path(str(db) + suffix)
        if p.exists():
            p.unlink()
    with TestClient(app) as c:
        yield c


def post_chat(client: TestClient, model: str, **kwargs) -> httpx.Response:
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "hi"}],
        "max_tokens": 100,
    }
    payload.update(kwargs)
    return client.post("/v1/chat/completions", json=payload, headers=AUTH)


def latest_record(client: TestClient, request_id: str | None = None) -> dict:
    params = {"request_id": request_id} if request_id else {"limit": 1}
    resp = client.get("/admin/usage", params=params, headers=AUTH)
    return resp.json()["records"][0]


# ---------- T0 冒烟 ----------

def test_t0_smoke_both_models(client, upstream):
    upstream.on(RESP, resp_json("你好"))
    upstream.on(ANTH, anth_json("你好"))
    r1 = post_chat(client, PRO)
    r2 = post_chat(client, FLASH)
    assert r1.status_code == r2.status_code == 200
    assert r1.json()["choices"][0]["message"]["content"] == "你好"
    assert r2.json()["choices"][0]["message"]["content"] == "你好"
    assert r1.json()["usage"] == {
        "prompt_tokens": 100,
        "completion_tokens": 50,
        "total_tokens": 150,
    }
    assert upstream.calls[0]["path"] == RESP
    assert upstream.calls[1]["path"] == ANTH


# ---------- T1 流式 ----------

def test_t1_stream_anthropic_translated_to_openai_chunks(client, upstream):
    upstream.on(ANTH, anth_sse(["统一", "网关", "!"]))
    with client.stream(
        "POST",
        "/v1/chat/completions",
        json={"model": FLASH, "stream": True, "messages": [{"role": "user", "content": "hi"}]},
        headers=AUTH,
    ) as resp:
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("text/event-stream")
        rid = resp.headers["x-request-id"]
        body = "".join(resp.iter_text())
    assert rid.startswith("req_")
    assert '"object": "chat.completion.chunk"' in body
    # 协议屏蔽：客户端看不到任何 Anthropic 原始事件
    assert "content_block_delta" not in body
    assert "message_start" not in body
    assert body.rstrip().endswith("data: [DONE]")
    text = "".join(
        json.loads(chunk[5:])["choices"][0]["delta"].get("content", "")
        for chunk in body.split("\n\n")
        if chunk.startswith("data:") and chunk != "data: [DONE]" and "delta" in chunk
    )
    assert text == "统一网关!"


# ---------- T2 结构化输出 ----------

def test_t2_flash_repair_loop_succeeds(client, upstream):
    upstream.on(
        ANTH,
        anth_json('前缀 {"name": 缺了引号} 后缀'),
        anth_json('{"name": "Ada", "age": 36}'),
    )
    r = post_chat(
        client,
        FLASH,
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "person", "schema": PERSON_SCHEMA},
        },
    )
    assert r.status_code == 200
    assert json.loads(r.json()["choices"][0]["message"]["content"]) == {
        "name": "Ada",
        "age": 36,
    }
    assert len(upstream.calls) == 2
    repair_msg = upstream.calls[1]["body"]["messages"][-1]["content"]
    assert "校验错误" in repair_msg


def test_t2_unrepairable_returns_422(client, upstream):
    upstream.on(ANTH, anth_json("无法输出JSON"))
    r = post_chat(client, FLASH, response_format={"type": "json_object"})
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "schema_violation"
    # 初始 1 次 + 2 轮修复
    assert len(upstream.calls) == 3


# ---------- T3 提示词版本管理 ----------

def test_t3_template_variables_versions_and_injection(client, upstream):
    upstream.on(RESP, resp_json("ok"))
    upstream.on(ANTH, anth_json("ok"))
    r = client.post(
        "/v1/prompts",
        headers=AUTH,
        json={
            "id": "rev",
            "name": "审查",
            "content": "你是 {{ language }} 代码审查助手",
        },
    )
    assert r.json() == {"id": "rev", "version": 1, "active": True}

    ref = {"id": "rev", "variables": {"language": "Python"}}
    # 注入位置随协议分流：responses → instructions；anthropic → system
    post_chat(client, PRO, gateway_prompt=ref)
    body = upstream.calls[-1]["body"]
    assert "你是 Python 代码审查助手" in body["instructions"]
    assert "system" not in body

    post_chat(client, FLASH, gateway_prompt=ref)
    body = upstream.calls[-1]["body"]
    assert "你是 Python 代码审查助手" in body["system"]
    assert "instructions" not in body

    # 版本管理：再创建一次即 v2 并激活；显式 version 引用旧版
    client.post(
        "/v1/prompts",
        headers=AUTH,
        json={"id": "rev", "name": "审查", "content": "v2 模板 {{ language }}"},
    )
    post_chat(
        client,
        PRO,
        gateway_prompt={"id": "rev", "version": 1, "variables": {"language": "X"}},
    )
    assert "代码审查助手" in upstream.calls[-1]["body"]["instructions"]
    post_chat(client, PRO, gateway_prompt={"id": "rev", "variables": {"language": "X"}})
    assert "v2 模板" in upstream.calls[-1]["body"]["instructions"]

    # StrictUndefined：漏传变量 422 且请求不出网
    calls_before = len(upstream.calls)
    client.post(
        "/v1/prompts",
        headers=AUTH,
        json={"id": "strict", "name": "s", "content": "{{ missing_var }}"},
    )
    r = post_chat(client, PRO, gateway_prompt={"id": "strict"})
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "template_error"
    assert len(upstream.calls) == calls_before


# ---------- T4 可观测性 ----------

def test_t4_usage_ledger_tokens_latency_ttft(client, upstream):
    upstream.on(RESP, resp_json("ok"))
    r = post_chat(client, PRO)
    assert r.status_code == 200
    rec = latest_record(client)
    assert rec["model"] == PRO and rec["protocol"] == "responses"
    assert rec["input_tokens"] == 100 and rec["output_tokens"] == 50
    assert rec["status"] == "success" and rec["total_ms"] > 0

    upstream.on(ANTH, anth_sse(["流", "式"], first_delay=0.2))
    with client.stream(
        "POST",
        "/v1/chat/completions",
        json={"model": FLASH, "stream": True, "messages": [{"role": "user", "content": "hi"}]},
        headers=AUTH,
    ) as resp:
        rid = resp.headers["x-request-id"]
        _ = "".join(resp.iter_text())
    rec = latest_record(client, rid)
    assert rec["protocol"] == "anthropic"
    assert rec["ttft_ms"] >= 120
    assert rec["ttft_ms"] <= rec["total_ms"]


# ---------- T5 重试 ----------

def test_t5_retry_backoff_then_success(client, upstream):
    upstream.on(RESP, {"status": 503, "text": "down"}, {"status": 503, "text": "down"}, resp_json("ok"))
    r = post_chat(client, PRO)
    assert r.status_code == 200
    assert r.json()["choices"][0]["message"]["content"] == "ok"
    assert len(upstream.calls) == 3
    # 指数退避：两次重试间隔 ≈ 0.5s / 1.0s（含 jitter 容差）
    assert upstream.calls[1]["t"] - upstream.calls[0]["t"] >= 0.45
    assert upstream.calls[2]["t"] - upstream.calls[1]["t"] >= 0.95
    rec = latest_record(client)
    assert rec["retries"] == 2 and rec["status"] == "success"


def test_t5_retry_exhausted(client, upstream):
    upstream.on(RESP, {"status": 503, "text": "down"})
    r = post_chat(client, PRO)
    assert r.status_code == 502
    assert r.json()["error"]["code"] == "upstream_error"
    assert len(upstream.calls) == 4  # 初始 + 3 次重试
    assert latest_record(client)["status"] == "error"


def test_t5_no_retry_on_auth_error(client, upstream):
    upstream.on(RESP, {"status": 401, "text": "bad key"})
    r = post_chat(client, PRO)
    assert r.status_code == 502
    assert r.json()["error"]["code"] == "upstream_auth"
    assert len(upstream.calls) == 1  # 401 不重试


# ---------- T6 按模型独立限流 ----------

def test_t6_rate_limit_isolated_per_model(client, upstream, monkeypatch):
    monkeypatch.setattr(main, "LIMITER", RateLimiter({PRO: 2, FLASH: 5}))
    upstream.on(RESP, resp_json("ok"))
    upstream.on(ANTH, anth_json("ok"))
    statuses = [post_chat(client, PRO).status_code for _ in range(3)]
    assert statuses == [200, 200, 429]  # pro 配额 2/min，第 3 个被拒
    r429 = post_chat(client, PRO)
    err = r429.json()["error"]
    assert err["type"] == "rate_limit_error" and err["code"] == "rate_limited"
    # flash 独立配额，互不影响
    assert {post_chat(client, FLASH).status_code for _ in range(3)} == {200}


# ---------- T7 停止生成（取消链路） ----------

class FakeRequest:
    def __init__(self, disconnect_after: int) -> None:
        self.n = 0
        self.disconnect_after = disconnect_after

    async def is_disconnected(self) -> bool:
        self.n += 1
        return self.n > self.disconnect_after


def test_t7_cancel_records_trace(client, upstream):
    upstream.on(ANTH, anth_sse(["a", "b", "c"]))
    route = main.CONFIG["models"][FLASH]
    ureq = UnifiedRequest(
        model=route["model"],
        messages=[{"role": "user", "content": "hi"}],
        stream=True,
    )
    chat_req = ChatRequest(
        model=FLASH, messages=[{"role": "user", "content": "hi"}], stream=True
    )
    rid = "req_cancel_test"

    async def consume():
        chunks = []
        agen = sse_stream(
            chat_req, ureq, route, FakeRequest(disconnect_after=3), rid, None, None,
            time.monotonic(),
        )
        async for chunk in agen:
            chunks.append(chunk)
        return chunks

    chunks = asyncio.run(consume())
    # 收到过 OpenAI chunk，但流被中途取消（没有 [DONE]）
    assert any("chat.completion.chunk" in c for c in chunks)
    assert not any("[DONE]" in c for c in chunks)
    # Trace 可查：账本落了 cancelled 记录
    rec = latest_record(client, rid)
    assert rec["status"] == "cancelled"
    assert rec["model"] == FLASH and rec["protocol"] == "anthropic"


# ---------- 统一错误格式 ----------

def test_error_envelope_is_uniform(client):
    r = client.post(
        "/v1/chat/completions", json={"model": "nope", "messages": []}, headers=AUTH
    )
    assert r.status_code == 404
    err = r.json()["error"]
    assert set(err.keys()) == {"message", "type", "code", "param"}
    assert err["code"] == "model_not_found"


def test_gateway_error_payload_shape():
    exc = GatewayError(
        "x", status_code=429, error_type="rate_limit_error", code="rate_limited"
    )
    assert exc.to_payload() == {
        "error": {"message": "x", "type": "rate_limit_error", "code": "rate_limited"}
    }
