# LLM 统一模型调用服务

适配器模式的统一网关：对上暴露唯一的 OpenAI 风格 API，对下按请求中的 `model` 字段动态路由到两种协议，屏蔽鉴权、请求体和返回格式的差异。

| 模型别名                | 路由协议                   | 上游端点                                                               |
| ------------------- | ---------------------- | ------------------------------------------------------------------ |
| `deepseek-v4-pro`   | OpenAI Responses API   | `POST {base}/v1/responses`（Bearer 鉴权）                              |
| `deepseek-v4-flash` | Anthropic Messages API | `POST {base}/anthropic/v1/messages`（x-api-key + anthropic-version） |

<br />

## 功能对照

| 作业要求           | 实现                                                                 | 验证                                                                        |
| -------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------- |
| 统一抽象 + 动态路由    | `app/adapters.py` 适配器注册表 + `main.py:resolve_route`                 | `test_t0_smoke_both_models`                                               |
| 流式输出（SSE）      | 上游事件统一翻译为 OpenAI chunk，客户端只见一种协议                                   | `test_t1_stream_anthropic_translated_to_openai_chunks`                    |
| 结构化输出          | pro 原生 json\_schema；flash 注入提示 + 本地校验 + 错误回喂修复（≤2 轮），失败 422        | `test_t2_flash_repair_loop_succeeds` / `test_t2_unrepairable_returns_422` |
| 提示词版本管理        | SQLite 存储版本 + 激活位；Jinja2 StrictUndefined；按协议注入 instructions/system | `test_t3_template_variables_versions_and_injection`                       |
| 可观测性           | SQLite 账本：token 分类、total\_ms、ttft\_ms、retries、status               | `test_t4_usage_ledger_tokens_latency_ttft`                                |
| 错误封装 + 重试 + 限流 | 统一 error 对象；指数退避（0.5s·2ⁿ+jitter，≤3 次，仅 429/5xx/超时）；令牌桶按模型独立        | `test_t5_*` / `test_t6_rate_limit_isolated_per_model`                     |
| 停止生成           | 前端 AbortController → 网关检测断开 → 关闭上游 → 账本落 `cancelled`               | `test_t7_cancel_records_trace`                                            |

## 目录结构

```text
gateway-service/
├── app/
│   ├── adapters.py     # UnifiedRequest/Event/Result + 两个协议适配器 + OpenAI chunk 编码
│   ├── errors.py       # 统一错误对象 {error:{message,type,code,param}}
│   ├── store.py        # UsageLedger 账本 + PromptStore 版本模板（StrictUndefined）
│   ├── structured.py   # JSON 提取 + jsonschema 校验 + 修复指令
│   └── main.py         # FastAPI：鉴权/限流/路由/SSE/重试/修复循环/Trace 查询
├── static/index.html   # 对话前端（发送 / 停止 / Trace 弹窗）
├── tests/              # T0–T7 全量 Mock 测试（不消耗真实额度）
├── config.example.yaml # 配置模板（${VAR} 从环境变量注入）
├── verify_all.py       # 真实 API 一键验证
└── requirements.txt
```

## 快速开始

### 1. 安装依赖

要求 Python 3.10+（推荐 3.12；代码使用了 PEP 604 类型语法）。

```bash
cd gateway-service          # 克隆后进入仓库根目录
python -m pip install -r requirements.txt
```

### 2. 配置

```bash
cp config.example.yaml config.yaml
export DEEPSEEK_API_KEY="sk-你的key"
export GATEWAY_API_KEY="dev-key"          # 客户端访问网关用的口令
export GATEWAY_CONFIG="$PWD/config.yaml"  # 必须设置；不设则启动时走内置默认配置，config.yaml 不生效
```

> 环境变量只在当前终端有效，重开终端需重新导出；启动网关和运行 verify_all.py 应在同一环境。

模型别名、协议、限流都在 `config.yaml` 里改，无需动代码。

### 3. 先跑 Mock 测试（免费，验证全部逻辑）

```bash
python -m pytest tests/ -v
```

预期全部 PASS。故障注入（503 重试、401 不重试、限流 429、修复循环）都在这一层覆盖。

### 4. 启动网关

```bash
python -m uvicorn app.main:app --port 8000
```

### 5. 打真实请求验证

```bash
python verify_all.py
```

逐项输出 PASS/FAIL，覆盖冒烟、流式、结构化、模板、Trace 五类；限流与停止生成按脚本末尾提示人工验证。

人工验证效果举例如下：

如下图为将rate\_limit\_rpm修改为2后连续发送3次第三次触发限流

![](assets/verify_1.png)如下图为停止效果，

![](assets/verify_2.png)![](assets/verify_3.png)查询到消耗记录

![](assets/verify_4.png)

## curl 示例

### 普通调用（两种协议同一入口）

```bash
curl http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer dev-key" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","max_tokens":100,"messages":[{"role":"user","content":"你好"}]}'

curl http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer dev-key" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","max_tokens":100,"messages":[{"role":"user","content":"你好"}]}'
```

### 流式

```bash
curl -N http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer dev-key" -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","stream":true,"max_tokens":100,"messages":[{"role":"user","content":"从1数到5"}]}'
```

响应头 `X-Request-ID` 即本次调用的 Trace ID。

### 结构化输出

```bash
curl http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer dev-key" -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","max_tokens":200,"messages":[{"role":"user","content":"提取：Ada 36岁"}],"response_format":{"type":"json_schema","json_schema":{"name":"person","schema":{"type":"object","properties":{"name":{"type":"string"},"age":{"type":"integer"}},"required":["name","age"],"additionalProperties":false}}}}'
```

### 提示词：创建版本 → 引用旧版本

```bash
# 创建 v1
curl http://localhost:8000/v1/prompts -H "Authorization: Bearer dev-key" -H "Content-Type: application/json" \
  -d '{"id":"reviewer","name":"审查","content":"你是 {{ language }} 代码审查助手"}'

# 再创建一次即 v2（自动激活）
curl http://localhost:8000/v1/prompts -H "Authorization: Bearer dev-key" -H "Content-Type: application/json" \
  -d '{"id":"reviewer","name":"审查","content":"v2：你是 {{ language }} 严格审查助手"}'

# 显式引用 v1；不传 version 则用激活版
curl http://localhost:8000/v1/chat/completions -H "Authorization: Bearer dev-key" -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-pro","max_tokens":100,"messages":[{"role":"user","content":"审查: eval(input())"}],"gateway_prompt":{"id":"reviewer","version":1,"variables":{"language":"Python"}}}'
```

### Trace 查询

```bash
curl "http://localhost:8000/admin/usage?limit=20" -H "Authorization: Bearer dev-key"
curl "http://localhost:8000/admin/usage?request_id=req_xxxxxxxxxxxx" -H "Authorization: Bearer dev-key"
```

每条记录：`model / protocol / input_tokens / output_tokens / total_ms / ttft_ms / retries / status(success|cancelled|error) / error_code / prompt_id / prompt_version`。

## 停止生成全链路演示（验收场景）

1. 浏览器打开 `http://localhost:8000/`，选模型，输入问题，点发送；
2. 流式输出几个字后点 **■ 停止**：前端立即停止追加并标记"已停止"；
3. 点消息尾部的 `Trace: req_xxx` 链接：弹出的记录 `status` 为 **`cancelled`**，`output_tokens` 为取消前累计值。

链路：`abort()` 断 TCP → 网关在 SSE 循环内逐块 `is_disconnected` 检测 → `finally` 中 `aclose()` 关闭上游（DeepSeek 停止生成、token 止损）→ 账本兜底落库。

## 错误码一览

| HTTP | code                                   | 场景                 |
| ---- | -------------------------------------- | ------------------ |
| 401  | `invalid_api_key`                      | 网关口令错误             |
| 404  | `model_not_found` / `prompt_not_found` | 别名或模板不存在           |
| 422  | `template_error`                       | 模板变量缺失（请求不出网，零成本）  |
| 422  | `schema_violation`                     | 结构化输出 2 轮修复后仍不合规   |
| 429  | `rate_limited`                         | 该模型限流              |
| 502  | `upstream_error` / `upstream_auth`     | 上游失败 / 鉴权失败（后者不重试） |

## 生产化说明

- 限流为进程内存态：多副本部署需换 Redis（接口已隔离在 `RateLimiter`）；
- Uvicorn 单进程即满足演示；上 Gunicorn 必须用 `-k uvicorn.workers.UvicornWorker`（sync worker 会占死 SSE 长连接）；
- 前置 nginx 时加 `proxy_buffering off`（响应已带 `X-Accel-Buffering: no`）；
- 密钥只经环境变量注入，`config.yaml` 不要提交真实 Key。
