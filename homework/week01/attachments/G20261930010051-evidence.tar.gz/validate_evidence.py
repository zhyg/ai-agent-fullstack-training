import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/user/workspace/repo')
E = Path(__file__).parent
feedback = ROOT / 'homework/week01/G20261930010051.md'
detail = ROOT / 'homework/week01/attachments/G20261930010051.md'
archive = ROOT / 'homework/week01/attachments/G20261930010051-evidence.tar.gz'
text = feedback.read_text()
checks = []
for n, label in [(2, '作业优点'), (3, '作业不足'), (4, '改进方案')]:
    part = text.split(f'**{n}. {label}**\n\n')[1].split('\n**')[0]
    count = len(re.findall(r'^- ', part, re.M))
    chars = len(re.sub(r'\s', '', part))
    assert 3 <= count <= 5 and chars <= 500
    assert not any(x in part for x in ['扣分', '评分项', '评分依据'])
    checks.append({'section': label, 'items': count, 'non_whitespace_chars_including_list_markers': chars})
scores = [(int(a), int(b)) for a,b in re.findall(r'^\| (?!合计)[^|]+\| (\d+)/(\d+) \|', detail.read_text(), re.M)]
assert len(scores) == 8 and sum(b for a,b in scores) == 100 and sum(a for a,b in scores) == 82
assert '优秀（82分）' in text
assert 'No orb services are running.' in (E/'services-final.log').read_text()
assert '13 passed' in (E/'student-pytest.log').read_text()
assert '合计: 12/12 PASS' in (E/'student-script-real.log').read_text()
assert '合计: 12/12 PASS' in (E/'student-script-valid-person.log').read_text()
assert '合计: 5/12 PASS' in (E/'student-script-failure.log').read_text()
subprocess.run(['git', '-C', '/tmp/tiger-submission', 'diff', '--exit-code'], check=True)
assert subprocess.check_output(['git', '-C', '/tmp/tiger-submission', 'rev-parse', 'HEAD'], text=True).strip() == '551e19b724f830cd8e41e8f58a51b6a5d45b1b54'
source_files = [f for f in (E/'source').rglob('*') if f.is_file()]
for f in source_files:
    rel = f.relative_to(E/'source').as_posix()
    expected = subprocess.check_output(['git', '-C', '/tmp/tiger-submission', 'show', 'HEAD:' + rel])
    assert expected == f.read_bytes(), rel

secrets = [v.encode() for k,v in os.environ.items() if len(v) >= 12 and re.search(r'(API_KEY|TOKEN|PASSWORD|SECRET|PRIVATE_KEY)$',k)]
files = [f for f in E.rglob('*') if f.is_file() and '__pycache__' not in f.parts and not f.name.endswith('.pyc')]
for f in files + [feedback, detail]:
    raw = f.read_bytes()
    assert not any(v in raw for v in secrets), 'Secret detected; refusing package'
    assert f.name != '.env' and not f.name.endswith(('.db', '.sqlite'))
    if f.suffix in ['.json', '.log']:
        assert not re.search(rb'(?i)(?:"authorization"|"x-api-key")\s*:',raw), 'Captured authentication header detected'

manifest = '\n'.join(hashlib.sha256(f.read_bytes()).hexdigest() + '  ' + f.relative_to(E).as_posix() for f in sorted(files)) + '\n'
(E/'SHA256SUMS.txt').write_text(manifest)
(E/'validation-summary.json').write_text(json.dumps({'score': 82, 'max': 100, 'grade': '优秀', 'sections': checks,
    'source_snapshot_exact_files': len(source_files), 'secret_scan': 'passed', 'captured_auth_headers': 'none',
    'services': 'stopped', 'source_logic': 'unchanged', 'git_delivery': 'not committed or pushed'}, ensure_ascii=False, indent=2))
assert not archive.exists(), 'Refusing to overwrite existing evidence'
with tarfile.open(archive, 'x:gz') as tar:
    for f in sorted(E.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts and not f.name.endswith('.pyc'):
            tar.add(f, arcname=f.relative_to(E).as_posix(), recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    for m in members:
        assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
        raw = tar.extractfile(m).read()
        assert not any(v in raw for v in secrets)
print(json.dumps({'score': 82, 'sections': checks, 'source_exact_files': len(source_files),
    'tar_members': len(members), 'archive_bytes': archive.stat().st_size, 'secret_scan': 'PASS',
    'format_and_total': 'PASS', 'services': 'STOPPED',
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
