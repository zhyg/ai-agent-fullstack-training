import asyncio
import json
import time
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI()
state = {'mode': 'normal', 'calls': [], 'release': False}

@app.post('/control')
async def control(req: Request):
    body = await req.json()
    if body.get('release'):
        state['release'] = True
    else:
        state.update(mode=body['mode'], calls=[], release=False)
    return {'ok': True}

@app.get('/stats')
async def stats():
    return state

@app.post('/{path:path}')
async def upstream(path: str, req: Request):
    body = await req.json()
    state['calls'].append({'path': '/' + path, 'body': body, 'time': time.monotonic()})
    n = len(state['calls'])
    mode = state['mode']
    if mode in ('503', '400', '401', '429') or (mode == 'retry' and n < 3):
        return JSONResponse({'error': {'message': 'controlled upstream failure'}}, status_code=int(mode) if mode.isdigit() else 503)
    responses = path.endswith('responses')
    text = {'normal': 'OK', 'invalid': 'not JSON', 'empty': '', 'truncated': '{"ok":',
            'fenced': '```json\n{"ok":true}\n```', 'schema_bad': '{"ok":"wrong"}',
            'json': '{"ok":true}', 'student': '{"name":"Ada","age":36}'}.get(mode, 'OK')
    if mode == 'repair':
        text = 'not JSON' if n == 1 else '{"ok":true}'
    usage = {'input_tokens': 11, 'output_tokens': 7,
             'input_tokens_details': {'cached_tokens': 3},
             'output_tokens_details': {'reasoning_tokens': 2},
             'cache_read_input_tokens': 3, 'cache_creation_input_tokens': 2}
    if body.get('stream'):
        async def events():
            def ev(t, data):
                return 'event: ' + t + '\ndata: ' + json.dumps(dict(type=t, **data)) + '\n\n'
            if responses:
                yield ev('response.created', {'response': {'id': 'controlled-response'}})
                yield ev('response.output_text.delta', {'delta': ''})
                await asyncio.sleep(0.05)
                yield ev('response.output_text.delta', {'delta': 'FIRST'})
            else:
                yield ev('message_start', {'message': {'id': 'controlled-message', 'usage': usage}})
                yield ev('content_block_delta', {'delta': {'type': 'text_delta', 'text': ''}})
                await asyncio.sleep(0.05)
                yield ev('content_block_delta', {'delta': {'type': 'text_delta', 'text': 'FIRST'}})
            if mode.startswith('gate'):
                until = time.monotonic() + 15
                while not state['release'] and time.monotonic() < until:
                    await asyncio.sleep(0.01)
            if mode == 'gate_error':
                yield ev('error', {'error': {'type': 'overloaded_error', 'message': 'controlled SSE error'}})
                return
            if mode == 'gate_eof':
                return
            if mode == 'gate_disconnect':
                raise RuntimeError('controlled transport interruption')
            if responses:
                yield ev('response.completed', {'response': {'id': 'controlled-response', 'status': 'completed', 'usage': usage}})
            else:
                yield ev('message_delta', {'delta': {'stop_reason': 'end_turn'}, 'usage': {'output_tokens': 7}})
                yield ev('message_stop', {})
        return StreamingResponse(events(), media_type='text/event-stream')
    if responses:
        result = {'id': 'controlled-response', 'status': 'incomplete' if mode == 'truncated' else 'completed',
                  'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}], 'usage': usage}
    else:
        result = {'id': 'controlled-message', 'stop_reason': 'max_tokens' if mode == 'truncated' else 'end_turn',
                  'content': [{'type': 'text', 'text': text}], 'usage': usage}
    return result
