# LLM Gateway

生产可用的模块化 LLM 网关：统一收敛 Agent 的模型调用，提供双协议入口、fallback 链、弹性治理与可观测能力。

- **双协议**：自有 `/v1/llm` 协议 + OpenAI 兼容 `/v1/chat/completions`（SDK 零改动直连，含 SSE 流式）
- **按模型上游协议**：统一入口按模型配置 `protocol`（chat|responses）由 Adapter 完成请求/响应转换，同一入口只改 `model` 即切换上游协议
- **配置外部化**：模型、fallback 链、限流、密钥引用全部由 YAML + 环境变量驱动，换供应商零代码改动
- **弹性治理**：按模型可配的指数退避重试、熔断器与模型级独立限流、按 Key 令牌桶限流、网关 API Key 鉴权
- **可观测**：`request_id` 全链路审计（JSONL 持久化，重启不丢）、`/healthz`、Prometheus 格式 `/metrics`

## 架构

```mermaid
flowchart LR
    A[OpenAI SDK / curl] -->|/v1/chat/completions| M1[HttpMetrics 中间件]
    B[业务 Agent] -->|/v1/llm| M1
    M1 --> M2[ApiKey 鉴权中间件]
    M2 --> M3[令牌桶限流中间件]
    M3 --> R[路由层 app/api]
    R --> S[GatewayService app/services/gateway]
    S --> CB[熔断器 CircuitBreaker]
    S --> P[Provider Protocol]
    P --> U1[主模型上游]
    P -.fallback 链.-> U2[备用模型上游]
    S --> T[TraceStore traces.jsonl]
    S --> MT[MetricsRegistry /metrics]
```

分层与依赖约束（单向向下，无环）：

| 层 | 目录 | 职责 | 依赖 |
|---|---|---|---|
| API | `app/api` | 双协议入口、SSE 编码 | FastAPI + services |
| 服务 | `app/services` | fallback/重试/校验业务流 | 只依赖 Provider 协议与 domain |
| 核心 | `app/core` | 鉴权/限流/熔断/指标中间件 | 无 HTTP 业务概念 |
| 领域 | `app/schemas.py` | 统一消息/请求/响应/审计模型 | 零依赖（仅 pydantic） |
| 配置 | `app/config.py` | YAML 加载与环境变量替换 | 零依赖 |

## 安装与启动

```bash
# 先安装 uv（https://docs.astral.sh/uv/），然后：
uv sync --extra dev        # 按 uv.lock 创建 .venv，安装运行 + 开发依赖

cp config.example.yaml config.yaml
cp .env.example .env          # 填写 DEEPSEEK_API_KEY 等，启动时自动加载
uv run uvicorn app.main:app --port 8000
```

配置文件查找顺序：`GATEWAY_CONFIG_FILE` 环境变量 → `config.yaml` → `config.example.yaml`。
启动时自动加载项目根目录的 `.env` 补齐缺失的环境变量（已存在的系统环境变量优先，不被覆盖）；
模型字段中的 `${VAR}` 在加载时替换为环境变量值；网关自身鉴权 Key 在 YAML 的 `auth.keys` 中配置。

## 端点与 curl 示例

网关 API Key 通过 `Authorization: Bearer <key>` 或 `x-api-key` 传入；除 `/healthz` 外所有端点均需鉴权。

### 自有协议

```bash
# 非流式
curl http://127.0.0.1:8000/v1/llm \
  -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  -d '{"model":"general-primary","messages":[{"role":"user","content":"解释什么是 LLM Gateway"}]}'

# Structured Output（jsonschema 双重校验）
curl http://127.0.0.1:8000/v1/llm \
  -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  -d '{"model":"general-primary","messages":[{"role":"user","content":"返回一个答案"}],"response_schema":{"type":"object","properties":{"answer":{"type":"string"}},"required":["answer"],"additionalProperties":false}}'

# 流式（SSE 事件：content.delta / response.completed / response.failed；
#      completed 携带实际模型与 token 用量）
curl -N http://127.0.0.1:8000/v1/llm/stream \
  -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  -d '{"model":"general-primary","messages":[{"role":"user","content":"用一句话解释流式输出"}]}'

# Prompt 模板（调用方只能传 name/version/variables，不能上传正文）
curl http://127.0.0.1:8000/v1/llm \
  -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  -d '{"model":"general-primary","messages":[{"role":"user","content":"..."}],"prompt":{"name":"knowledge_decision","version":"v1","variables":{"product_name":"差旅助手"}}}'
```

### OpenAI 兼容协议

```python
from openai import OpenAI
client = OpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-gateway-demo")
resp = client.chat.completions.create(
    model="general-primary",
    messages=[{"role": "user", "content": "hi"}],
)
print(resp.choices[0].message.content)

stream = client.chat.completions.create(model="general-primary", messages=[...], stream=True)
for chunk in stream:
    print(chunk.choices[0].delta.content, end="")
```

原生 `response_format` 会映射到本地 JSON 校验（复用结构化输出的自修复→切备用机制）：

```bash
curl http://127.0.0.1:8000/v1/chat/completions \
  -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  -d '{"model":"general-primary","messages":[{"role":"user","content":"返回 JSON"}],"response_format":{"type":"json_object"}}'
```

除 chat completions 外还提供：

- `GET /v1/models`：白名单模型清单（不泄露上游真实模型名）
- `POST /v1/responses`：Responses API 透传（非流式 JSON 透传 / 流式 `event: {type}` SSE），
  要求模型声明 `supports_responses: true`，SDK 直接可用：

```python
resp = client.responses.create(model="general-primary", input="hi")
print(resp.output_text)
```

Responses 的 `text.format` 结构化约束与 chat 同语义：`json_object` / `json_schema` 映射到本地 JSON
校验（校验失败切备用，失败保留 `invalid_json` / `schema_validation_failed`），约束原样转发上游；
未知格式类型 400，流式 + 结构化格式组合 400（流式无法在发送前完成整体校验）。

（config.example.yaml 的 `general-primary` 已开 `supports_responses: true` 且 `protocol: responses`；上游需真实支持 Responses API。）

兼容能力边界（未支持参数在调模型前处理，不会静默吞掉）：

- 支持：非流式/流式 chat completions；`system` / `user` / `assistant` 角色；
  `response_format`（`json_object` / `json_schema`，映射到本地 JSON 校验，流式 + response_format 组合返回 400）
- 语义参数拒绝（400 `unsupported_param`，错误体指名参数与原因）：`n>1`、`tools`、消息内 `tool_calls`、`developer` 角色（422）
- 抽样参数丢弃并标记：`temperature`、`top_p`、`max_tokens` 等不转发上游，但通过响应头
  `X-Gateway-Dropped-Params: temperature, top_p` 显式披露，并写入审计 `dropped_params` 字段；
  `n=1` 与未知字段同样丢弃并标记
- 验收模式：配置 `strict_params: true` 后，所有未支持参数一律 400（含抽样参数）
- 流内错误：上游流式失败时发送 OpenAI 兼容的 error 事件，SDK 客户端会抛出 `APIError`

错误体（OpenAI 兼容格式）：

```json
{"error": {"message": "模型不在 Gateway 允许列表中", "type": "unknown_model", "code": "unknown_model"}}
```

### 治理端点

```bash
curl http://127.0.0.1:8000/healthz                       # 免鉴权，探活
curl -H 'authorization: Bearer sk-gateway-demo' http://127.0.0.1:8000/v1/traces   # 调用审计
curl -H 'authorization: Bearer sk-gateway-demo' http://127.0.0.1:8000/metrics     # Prometheus 指标
curl -H 'authorization: Bearer sk-gateway-demo' http://127.0.0.1:8000/admin/usage  # SQLite 用量账本
curl -H 'authorization: Bearer sk-gateway-demo' 'http://127.0.0.1:8000/admin/usage/stats?group_by=model'  # 按模型聚合（tenant / model / prompt_version）
curl -H 'authorization: Bearer sk-gateway-demo' http://127.0.0.1:8000/admin/routes # 熔断状态与路由快照
```

Prompt 资产（SQLite 管理，服务端递增版本号，同 id 同时只一个 active 版本）：

```bash
curl -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  http://127.0.0.1:8000/v1/prompts \
  -d '{"id":"knowledge_decision","content":"你是{{ product_name }}的知识库决策器。","activate":true}'
curl -H 'authorization: Bearer sk-gateway-demo' -H 'content-type: application/json' \
  http://127.0.0.1:8000/v1/prompts/knowledge_decision/render \
  -d '{"variables":{"product_name":"差旅助手"}}'
```

## 可靠性与治理语义

- **fallback 链**：请求模型失败后按配置顺序切换备用模型。可重试错误（上游不可达/超时/限流）先按退避参数重试再切换；以下错误同样触发切换：
  - 结构化输出校验失败（`invalid_json` / `schema_validation_failed`）
  - 上游凭据未配置（`gateway_misconfigured`）
  - 模型处于熔断状态（`circuit_open`）
  仅请求模型自身配置错误（`unknown_model` / `structured_output_unsupported`）直接返回，不切换。
- **重试**：非流式请求按模型 `retry` 配置指数退避 + 抖动重试；流式请求仅在首块内容发出前重试，首块后断流不再切备用模型（直接流内 error 事件，避免文本重复），且只有收到适配层成功终态（空增量结束块 / `response.completed`）才宣告流完成。供应商 SDK 异常在 Provider 适配层归一化为网关自有异常类型，gateway 只判自有类型、不导入任何供应商 SDK：限流/超时/连接可重试；上游 HTTP 400/404/422、401/403、5xx 不可重试、只作为切换信号，并保留可识别错误码（见错误码表）。
- **按模型上游协议**：`/v1/llm`、`/v1/chat/completions` 等统一入口按模型配置 `protocol`（chat|responses，缺省 chat）选择上游协议，消息→Responses input、流式事件→增量文本的转换全部收在 Adapter 内，gateway 业务循环零协议分支；主备协议可混合，fallback 切换自动适配各模型自身协议（见 config.example.yaml）。
- **Run 预算**：单次请求的重试、自修复与备用切换共用同一计数（`run_budget`，默认 12），超限直接终态 `run_budget_exhausted`，防止一个请求无限消耗上游。
- **熔断器**：连续重试失败达阈值打开，冷却期后放行**单个**半开探测（探测在途时并发请求被拒绝并走备用模型），探测成功即恢复。
- **按模型独立限流**：模型级 `rate_limit`（可选，见 config.example.yaml）与全局按 Key 限流叠加；模型配额超限直接 429，不切备用模型（避免过载传导给备用）；模型名取自请求体，检查前置到 API 层（流式在首字节前返回 429，而非 200 + 断流）。
- **审计语义**：每次调用只落一条最终结果记录（成功或失败），`attempts` 字段保留重试与切换次数；`routing_reason` 记录首次切换备用模型的错误码，`schema_hash` 定位 Structured Output Schema（sha256 摘要，不记录内容），`price_snapshot` 记录成本计算所依据的价格版本；不记录消息内容；`/v1/traces` 重启后仍可查询。用量按逐次尝试累积已知 Token 并叠加各次实际价格，失败尝试无用量时以 `usage_unknown=true` 标记账本不完整；未知模型、模板缺项、参数拒绝等入口失败同样落一条 failed 审计记录（attempts=0）。
- **request_id**：`X-Request-Id` 响应头、响应体 `request_id` 与审计记录三者一致，可用于全链路排查。

## 错误码

| code | HTTP | 说明 |
|---|---|---|
| unknown_model | 400 | 模型不在白名单 |
| unsupported_param | 400 | 未支持参数：语义参数（n>1/tools/tool_calls）或 strict_params 验收模式 |
| unknown_prompt_template | 400 | Prompt 模板不存在 |
| missing_prompt_variable | 400 | 模板变量缺失 |
| invalid_json / schema_validation_failed | 502 | 结构化输出校验失败（主备模型均未通过） |
| structured_output_unsupported | 400 | 模型不支持 Structured Output |
| model_unavailable | 502 | 主备模型均不可用 |
| upstream_invalid_request | 400 | 上游拒绝请求（400/404/422），主备均失败 |
| upstream_auth_failed | 502 | 上游鉴权失败（401/403），主备均失败 |
| upstream_rate_limited | 429 | 上游限流（429），主备重试后仍限流 |
| upstream_server_error | 502 | 上游服务错误（5xx，含 504），主备均失败 |
| circuit_open | 503 | 请求模型处于熔断状态且无可用备用模型 |
| gateway_misconfigured | 503 | 上游凭据未配置（主备模型均未配置） |
| unauthorized | 401 | 网关 API Key 缺失或无效 |
| rate_limit_exceeded | 429 | 令牌桶超限（按 Key 或按模型） |
| run_budget_exhausted | 502 | Run 级总预算耗尽（重试/修复/切换共用上限） |

## 测试

```bash
uv run pytest -v
uv run ruff check app/ tests/
```

全部用例通过 `FakeProvider` 注入 + `httpx.ASGITransport` 完成，**无需任何真实 API Key、无网络依赖**。

### 验收清单（由 tests/ 覆盖）

| 验收项 | 结果 |
|---|---|
| pytest 全部通过，无需真实 API Key | ✅ 179 个用例 |
| OpenAI Python SDK 指向本网关：chat 与 responses 的 create / stream 均正常 | ✅ test_openai_sdk_direct / test_responses_sdk_direct |
| /v1/models 只暴露白名单模型 | ✅ test_list_models_exposes_only_allowlist |
| 主模型故障 → 自动重试 + 切换备用模型，响应标出实际模型与 attempts | ✅ test_fallback_after_retries（model=general-backup, attempts=3） |
| 结构化校验失败 / 凭据未配置 → 切换备用模型 | ✅ test_invalid_json_falls_back_to_backup / test_gateway_misconfigured_falls_back |
| 结构化自修复：校验错误喂回同模型重试，耗尽才切备用 | ✅ test_repair_recovers_on_same_model / test_repair_exhausted_falls_back_to_backup |
| Prompt CRUD + 版本 + Jinja2 沙箱渲染 | ✅ tests/test_prompts.py（8 用例，含 `{{ ''.__class__ }}` 拦截） |
| OpenAI 兼容 response_format → 本地 JSON 校验 + 自修复 + 备用切换 | ✅ tests/test_openai_json_format.py（7 用例） |
| Chat 空正文统一 invalid_json 失败处理；截断 JSON 自修复/切备用/全链失败保留错误码 | ✅ tests/test_structured_output_gaps.py（5 用例） |
| Responses text.format 映射校验：非法 JSON 切备用、缺 schema 400、流式组合 400、未知格式 400 | ✅ tests/test_structured_output_gaps.py（7 用例） |
| 未支持参数语义：语义参数 400，抽样参数丢弃 + 响应头/审计标记，strict_params 全拒 | ✅ tests/test_openai_unsupported_params.py（11 用例） |
| 按模型独立限流：超限 429 不切备用，流式前置拒绝 | ✅ tests/test_model_rate_limit.py（4 用例） |
| reasoning_tokens 提取入审计与账本，老库缺列自动迁移 | ✅ tests/test_reasoning_tokens.py（4 用例） |
| Run 级总预算：重试/修复/切换共用计数，超限终态并审计 | ✅ tests/test_run_budget.py（6 用例） |
| Trace 可定位：routing_reason（首次切换错误码）、schema 摘要、价格快照 | ✅ tests/test_trace_fields.py（10 用例） |
| SQLite 用量账本：TTFT / cached tokens / key 指纹 / /admin/usage | ✅ tests/test_ledger.py（7 用例） |
| 用量聚合：/admin/usage/stats 按租户/模型/Prompt 版本聚合 Token、成本、TTFT、延迟 | ✅ tests/test_usage_stats.py（8 用例） |
| 用量账本修正：修复成功累积逐次已知用量、失败保留已知用量并标记 usage_unknown、入口失败落审计 | ✅ tests/test_usage_accounting.py（8 用例） |
| 统一入口按模型协议分流：同一入口只改 model 即产生 Chat/Responses 两种上游请求，主备协议可混合 | ✅ tests/test_protocol_selection.py（10 用例） |
| SDK 异常下沉：适配层归一化为网关自有异常（幂等直通），gateway 只判自有类型 | ✅ tests/test_provider_errors.py（9 用例） |
| 上游错误码区分：400/401/429/5xx 可识别码 + 合理状态；不可重试错误不反复请求 | ✅ tests/test_upstream_error_codes.py（11 用例） |
| 流式客户端断开 → 关闭上游流并审计 client_disconnected | ✅ tests/test_disconnect.py（3 用例） |
| /admin/routes 熔断状态快照（只读不迁移状态） | ✅ tests/test_admin_routes.py（4 用例） |
| 无 key 访问任意端点 → 401；高频访问 → 429 | ✅ test_no_key_401_on_all_endpoints / test_rate_limit_429 |
| 重启进程后 /v1/traces 仍能查到历史记录 | ✅ test_traces_survive_restart |
| X-Request-Id 响应头与审计 request_id 一致 | ✅ test_metrics_traces_and_request_id |
| 流式 trace 记录 token 用量，request_id 与响应一致 | ✅ test_stream_trace_uses_same_request_id |
| 流式失败发送 error 事件，SDK 客户端抛出 APIError | ✅ test_openai_stream_error_event / test_openai_sdk_raises_on_stream_error |
| 已输出内容后断流：不切备用重播，直接流内 error 事件 | ✅ tests/test_stream_termination.py（5 用例） |
| 流必须收到成功终态才宣告完成，静默断流视为失败 | ✅ tests/test_stream_termination.py（5 用例） |
| 熔断半开状态只放行单个探测 | ✅ test_half_open_allows_single_probe |
| 修改 YAML 即可更换供应商或 fallback 链 | ✅ 配置完全外部化（config.example.yaml） |

## 真实接入验证清单

上述用例全部用 FakeProvider 离线跑通，不触网。接入真实上游后，按以下清单逐项验证（替换为自己的 Key 与内容）：

| # | 验证项 | 命令/方式 | 期望 |
|---|---|---|---|
| 1 | 主模型真实调用 | 上文“自有协议”非流式 curl | 200 + 真实内容 |
| 2 | 备用模型切换 | 临时把主模型 key 改错，重复 #1 | 200，`model=general-backup`，`attempts>=2` |
| 3 | /v1/responses 实网 | 上文 SDK `client.responses.create` | 返回 `output_text`（上游需支持 Responses API） |
| 4 | 结构化输出实网 | 上文 `response_schema` curl | 返回通过校验的 JSON |
| 5 | OpenAI SDK 直连 | `OpenAI(base_url=..., api_key=...)` chat create/stream | SDK 正常解析 |
| 6 | 流式真实用量 | `curl -N ... /v1/llm/stream` 看 `response.completed` | 事件携带真实 token 用量 |
| 7 | 审计与账本 | 完成 #1–#6 后查 `/v1/traces` 与 `/admin/usage` | 每条调用一条记录：request_id、cached/reasoning tokens、总耗时、首 token 耗时、成功/失败状态 |
| 8 | 限流生效 | 调小 `rate_limit.capacity` 重启后高频请求 | 按 Key 429；配模型级 `rate_limit` 后仅该模型 429 |
| 9 | 上游超时/异常 | 临时模型配一个不可达 base_url | 重试 → 切备用 → 审计记录失败原因 |

## 容器部署

```bash
docker compose up --build   # 镜像内用 uv sync --frozen 安装，非 root 用户运行
```

- `config.yaml` 只读挂载进容器；`./data` 持久化 SQLite 用量账本
- `.env` 由 compose 注入，`${VAR}` 引用在启动时解析
- 健康检查探 `/healthz`（15s 间隔，3 次失败判不健康）

## 依赖说明（pyproject.toml 唯一清单，uv.lock 锁定）

`fastapi`/`pydantic v2`/`uvicorn`：Web 框架与校验；`openai`：上游 OpenAI 兼容 SDK；`jsonschema`：结构化输出校验；`PyYAML`：配置加载；`jinja2`：Prompt 沙箱渲染；`httpx`：测试传输层；dev 组：`pytest`/`pytest-asyncio`/`ruff`。审计双写：JSONL 保不可变审计，SQLite 保查询投影，均零外部服务依赖。
