"""OpenAI 兼容入口：/v1/chat/completions（含 SSE 流式），SDK 零改动直连。"""

import json
import time
from collections.abc import AsyncIterator
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from app.context import GatewayContext
from app.errors import GatewayError, openai_error_body
from app.schemas import LLMRequest, Message, OpenAIChatRequest, OpenAIResponsesRequest
from app.services.gateway import (
    call_with_fallback,
    enforce_model_quota,
    record_entry_failure,
    responses_stream_with_fallback,
    responses_with_fallback,
    stream_with_fallback,
)
from app.services.prompts import build_messages

router = APIRouter()


def encode_sse(obj: dict[str, Any]) -> str:
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"


def response_schema_from_format(response_format: dict[str, Any] | None) -> dict[str, Any] | None:
    # 把 OpenAI 兼容的 response_format 映射为本地校验 Schema：
    # json_object → 任意 JSON 对象；json_schema → 携带的 Schema；text/缺省 → 不校验。
    if not response_format:
        return None
    fmt = response_format.get("type")
    if fmt == "json_object":
        return {"type": "object"}
    if fmt == "json_schema":
        schema = (response_format.get("json_schema") or {}).get("schema")
        if not schema:
            raise GatewayError("invalid_response_format", "response_format.json_schema 缺少 schema", 400)
        return schema
    return None


def responses_schema_from_text(text: Any) -> dict[str, Any] | None:
    # 把 Responses 的 text.format 映射为本地校验 Schema（与 response_format 同语义）：
    # json_object → 任意 JSON 对象；json_schema → 携带的 Schema；text/缺省 → 不校验。
    if not text or not isinstance(text, dict):
        return None
    fmt = text.get("format") or {}
    fmt_type = fmt.get("type", "text")
    if fmt_type == "text":
        return None
    if fmt_type == "json_object":
        return {"type": "object"}
    if fmt_type == "json_schema":
        schema = fmt.get("schema")
        if not schema:
            raise GatewayError("invalid_response_format", "text.format.json_schema 缺少 schema", 400)
        return schema
    raise GatewayError(
        "unsupported_param", f"text.format.type={fmt_type} 不支持", 400, param="text.format.type"
    )


# 语义参数：网关不实现会改变调用方预期的行为，必须显式拒绝。
_SEMANTIC_PARAMS: dict[str, str] = {
    "tools": "网关未实现工具调用（function calling）",
}


def resolve_unsupported_params(body: OpenAIChatRequest, strict: bool) -> list[str]:
    """分类未支持参数：语义参数与严格模式一律 400；其余参数丢弃并标记。

    抽样参数（temperature/top_p 等）与未知参数不转发上游，但会在响应头
    X-Gateway-Dropped-Params 与审计记录中标记，避免调用方无感知地得到
    与预期不同的行为；strict_params 验收模式下所有未支持参数一律 400。

    返回按请求体出现顺序收集的丢弃参数名，供响应头与审计记录使用。
    """
    rejected: list[tuple[str, str]] = []
    dropped: list[str] = []
    extra = dict(body.model_extra or {})

    n_value = extra.pop("n", None)
    if n_value is not None:
        if n_value != 1:
            rejected.append(("n", "网关仅支持 n=1，多候选生成（n>1）未实现"))
        else:
            dropped.append("n")

    for name, reason in _SEMANTIC_PARAMS.items():
        value = extra.pop(name, None)
        if value not in (None, [], {}):
            rejected.append((name, reason))

    # 消息内的工具调用史：网关无法延续多轮工具调用，同样显式拒绝
    for item in body.messages:
        tool_calls = (item.model_extra or {}).get("tool_calls")
        if tool_calls:
            rejected.append(("messages[].tool_calls", "网关未实现工具调用（function calling）"))
            break

    for name in extra:
        if strict:
            rejected.append((name, "网关不支持的参数（strict_params 验收模式）"))
        else:
            dropped.append(name)

    if rejected:
        name, reason = rejected[0]
        raise GatewayError("unsupported_param", f"参数 {name} 不支持：{reason}", 400, param=name)
    return dropped


def to_internal(body: OpenAIChatRequest) -> LLMRequest:
    return LLMRequest(
        model=body.model,
        messages=[Message(role=item.role, content=item.content) for item in body.messages],
        response_schema=response_schema_from_format(body.response_format),
    )


def chunk_event(
    chat_id: str, created: int, model: str, delta: dict[str, Any], finish_reason: str | None
) -> dict[str, Any]:
    return {
        "id": chat_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}],
    }


def validate_openai_entry(body: OpenAIChatRequest, internal: LLMRequest, ctx: GatewayContext) -> None:
    # 流式响应开始后无法再改状态码，因此模型白名单、模板与组合校验必须前置。
    if body.model not in ctx.config.models:
        raise GatewayError("unknown_model", "模型不在 Gateway 允许列表中", 400)
    if body.stream and internal.response_schema is not None:
        # 流式下无法在发送前完成整体 JSON 校验；与 /v1/llm/stream 的组合语义保持一致
        raise GatewayError("unsupported_combination", "流式输出不支持 response_format 的本地 JSON 校验", 400)
    build_messages(internal, ctx.config.prompts, ctx.prompt_store)


async def openai_stream(
    body: OpenAIChatRequest,
    internal: LLMRequest,
    ctx: GatewayContext,
    request_id: str | None,
    api_key_hash: str | None,
    disconnected,
    dropped_params: list[str] | None = None,
) -> StreamingResponse:
    chat_id = f"chatcmpl-{uuid4().hex[:24]}"
    created = int(time.time())

    async def event_stream() -> AsyncIterator[str]:
        async for kind, payload in stream_with_fallback(
            internal, ctx, request_id, api_key_hash, disconnected=disconnected
        ):
            if kind == "delta":
                yield encode_sse(chunk_event(chat_id, created, body.model, {"content": payload}, None))
            elif kind == "completed":
                yield encode_sse(chunk_event(chat_id, created, body.model, {}, "stop"))
                usage = payload.get("usage")
                if usage is not None:
                    yield encode_sse(
                        {
                            "id": chat_id,
                            "object": "chat.completion.chunk",
                            "created": created,
                            "model": body.model,
                            "choices": [],
                            "usage": {
                                "prompt_tokens": usage.input_tokens,
                                "completion_tokens": usage.output_tokens,
                                "total_tokens": usage.input_tokens + usage.output_tokens,
                            },
                        }
                    )
                yield "data: [DONE]\n\n"
            else:
                # 流式开始后无法改状态码；按 OpenAI 兼容约定发送 error 事件，
                # SDK 解析到 {"error": ...} 会抛出 APIError，而非静默截断
                yield encode_sse(
                    {
                        "error": {
                            "message": f"上游流式调用失败（{payload}）",
                            "type": payload,
                            "code": payload,
                            "request_id": request_id,
                        }
                    }
                )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"X-Gateway-Dropped-Params": ", ".join(dropped_params)} if dropped_params else None,
    )


@router.get("/v1/models")
async def list_models(http: Request) -> dict[str, Any]:
    # OpenAI 兼容模型清单：只暴露白名单内的模型，避免上游真实模型名泄漏给客户端。
    ctx: GatewayContext = http.app.state.ctx
    created = int(time.time())
    return {
        "object": "list",
        "data": [
            {"id": name, "object": "model", "created": created, "owned_by": "gateway"}
            for name in sorted(ctx.config.models)
        ],
    }


@router.post("/v1/chat/completions")
async def chat_completions(body: OpenAIChatRequest, http: Request):
    ctx: GatewayContext = http.app.state.ctx
    state = http.scope.get("state", {})
    request_id = state.get("request_id")
    internal: LLMRequest | None = None
    try:
        internal = to_internal(body)
        validate_openai_entry(body, internal, ctx)
        dropped = resolve_unsupported_params(body, ctx.config.strict_params)
        internal.dropped_params = dropped
        enforce_model_quota(ctx, body.model, internal, request_id, state.get("api_key_hash"))
    except GatewayError as exc:
        # 入口失败（未知模型/模板缺项/参数拒绝等）进入统一审计出口；配额 429 已由 enforce_model_quota 自审计
        if exc.code != "rate_limit_exceeded":
            record_entry_failure(
                ctx,
                request_id,
                state.get("api_key_hash"),
                internal
                if internal is not None
                else LLMRequest(model=body.model, messages=[Message(role="user", content="chat-entry")]),
                exc,
                stream=body.stream,
            )
        # OpenAI 协议错误体必须是 {"error": {...}}，不能包在 HTTPException 的 detail 里。
        return JSONResponse(
            status_code=exc.status_code,
            content=openai_error_body(
                exc.message, exc.code, exc.code, request_id=request_id, param=exc.param
            ),
        )
    # 丢弃的参数在响应头显式标记，调用方不会无感知地得到与预期不同的行为
    dropped_headers = {"X-Gateway-Dropped-Params": ", ".join(dropped)} if dropped else None
    if body.stream:
        return await openai_stream(
            body,
            internal,
            ctx,
            request_id,
            state.get("api_key_hash"),
            http.is_disconnected,
            dropped_params=dropped,
        )
    try:
        response = await call_with_fallback(internal, ctx, request_id, state.get("api_key_hash"))
    except GatewayError as exc:
        return JSONResponse(
            status_code=exc.status_code,
            content=openai_error_body(exc.message, exc.code, exc.code, request_id=request_id),
            headers=dropped_headers,
        )
    usage = response.usage
    return JSONResponse(
        content={
            "id": f"chatcmpl-{uuid4().hex[:24]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": body.model,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": response.content},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": usage.input_tokens,
                "completion_tokens": usage.output_tokens,
                "total_tokens": usage.input_tokens + usage.output_tokens,
            },
            "system_fingerprint": "fp_mini_gateway",
            "request_id": response.request_id,
        },
        headers=dropped_headers,
    )


def validate_responses_entry(body: OpenAIResponsesRequest, ctx: GatewayContext) -> None:
    # 流式响应开始后无法再改状态码，能力开关与模型白名单必须前置校验。
    model_config = ctx.config.models.get(body.model)
    if model_config is None:
        raise GatewayError("unknown_model", "模型不在 Gateway 允许列表中", 400)
    if not model_config.supports_responses:
        raise GatewayError("responses_unsupported", f"模型 {body.model} 未启用 Responses API", 400)


async def responses_stream(
    body: OpenAIResponsesRequest,
    ctx: GatewayContext,
    request_id: str | None,
    api_key_hash: str | None,
    disconnected,
    text: dict[str, Any] | None = None,
) -> StreamingResponse:
    # Responses 流式：上游事件按 `event: {type}` 原样透传；失败发 error 事件后终止。
    async def event_stream() -> AsyncIterator[str]:
        async for kind, payload in responses_stream_with_fallback(
            body, ctx, request_id, api_key_hash, disconnected=disconnected, text=text
        ):
            if kind == "sse_event":
                event_type, data = payload
                yield f"event: {event_type}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
            else:
                yield (
                    "event: error\ndata: "
                    + json.dumps(
                        {
                            "error": {
                                "message": f"上游流式调用失败（{payload}）",
                                "type": payload,
                                "code": payload,
                                "request_id": request_id,
                            }
                        },
                        ensure_ascii=False,
                    )
                    + "\n\n"
                )

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.post("/v1/responses")
async def create_responses(body: OpenAIResponsesRequest, http: Request):
    ctx: GatewayContext = http.app.state.ctx
    state = http.scope.get("state", {})
    request_id = state.get("request_id")
    api_key_hash = state.get("api_key_hash")
    try:
        validate_responses_entry(body, ctx)
        text = (body.model_extra or {}).get("text")
        response_schema = responses_schema_from_text(text)
        if body.stream and response_schema is not None:
            # 流式下无法在发送前完成整体 JSON 校验；与 chat 流式组合语义保持一致
            raise GatewayError(
                "unsupported_combination", "流式 Responses 不支持 text.format 的本地 JSON 校验", 400
            )
        enforce_model_quota(
            ctx,
            body.model,
            LLMRequest(model=body.model, messages=[Message(role="user", content="responses-api")]),
            request_id,
            api_key_hash,
        )
    except GatewayError as exc:
        # 入口失败进入统一审计出口；配额 429 已由 enforce_model_quota 自审计
        if exc.code != "rate_limit_exceeded":
            record_entry_failure(
                ctx,
                request_id,
                api_key_hash,
                LLMRequest(model=body.model, messages=[Message(role="user", content="responses-api")]),
                exc,
                stream=body.stream,
            )
        return JSONResponse(
            status_code=exc.status_code,
            content=openai_error_body(
                exc.message, exc.code, exc.code, request_id=request_id, param=exc.param
            ),
        )
    if body.stream:
        return await responses_stream(body, ctx, request_id, api_key_hash, http.is_disconnected, text=text)
    try:
        payload, _usage = await responses_with_fallback(
            body, ctx, request_id, api_key_hash, text=text, response_schema=response_schema
        )
    except GatewayError as exc:
        return JSONResponse(
            status_code=exc.status_code,
            content=openai_error_body(exc.message, exc.code, exc.code, request_id=request_id),
        )
    return payload
