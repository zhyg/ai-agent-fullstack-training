"""自有 /v1/llm 协议与治理端点（traces/healthz/metrics）。"""

import json
from collections.abc import AsyncIterator
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import PlainTextResponse, StreamingResponse

from app.errors import GatewayError, gateway_detail
from app.schemas import CallTrace, LLMRequest, LLMResponse, PromptCreate, PromptRenderRequest
from app.services.gateway import (
    call_with_fallback,
    enforce_model_quota,
    record_entry_failure,
    stream_with_fallback,
)
from app.services.prompt_store import render_db_prompt
from app.services.prompts import build_messages

router = APIRouter()


def encode_sse(event: dict[str, Any]) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"


@router.post("/v1/llm", response_model=LLMResponse)
async def create_llm_response(body: LLMRequest, http: Request) -> LLMResponse:
    # FastAPI 在入口校验请求、在 response_model 校验统一响应出口。
    ctx = http.app.state.ctx
    state = http.scope.get("state", {})
    if body.stream:
        raise HTTPException(
            status_code=400, detail=gateway_detail("use_stream_endpoint", "流式请求请使用 /v1/llm/stream")
        )
    try:
        enforce_model_quota(ctx, body.model, body, state.get("request_id"), state.get("api_key_hash"))
        return await call_with_fallback(body, ctx, state.get("request_id"), state.get("api_key_hash"))
    except GatewayError as exc:
        raise HTTPException(
            status_code=exc.status_code, detail=gateway_detail(exc.code, exc.message)
        ) from exc


@router.post("/v1/llm/stream")
async def create_stream(body: LLMRequest, http: Request) -> StreamingResponse:
    # 提供独立流式入口，明确禁止与 Structured Output 混用。
    ctx = http.app.state.ctx
    state = http.scope.get("state", {})
    if body.response_schema is not None:
        raise HTTPException(
            status_code=400,
            detail=gateway_detail("unsupported_combination", "流式输出不支持 response_schema"),
        )
    try:
        if body.model not in ctx.config.models:
            raise GatewayError("unknown_model", "模型不在 Gateway 允许列表中", 400)
        build_messages(body, ctx.config.prompts, ctx.prompt_store)
        # 流式限流拒绝必须前置：开始后无法改状态码，不能靠流内错误表达 429
        enforce_model_quota(ctx, body.model, body, state.get("request_id"), state.get("api_key_hash"))
    except GatewayError as exc:
        # 入口失败（未知模型/模板缺项等）进入统一审计出口；配额 429 已由 enforce_model_quota 自审计
        if exc.code != "rate_limit_exceeded":
            record_entry_failure(
                ctx,
                state.get("request_id"),
                state.get("api_key_hash"),
                body,
                exc,
                stream=True,
            )
        raise HTTPException(
            status_code=exc.status_code, detail=gateway_detail(exc.code, exc.message)
        ) from exc

    async def event_stream() -> AsyncIterator[str]:
        async for kind, payload in stream_with_fallback(
            body, ctx, state.get("request_id"), state.get("api_key_hash"), disconnected=http.is_disconnected
        ):
            if kind == "delta":
                yield encode_sse({"type": "content.delta", "delta": payload})
            elif kind == "completed":
                event: dict[str, Any] = {"type": "response.completed", "model": payload["model"]}
                if payload.get("usage") is not None:
                    event["usage"] = payload["usage"].model_dump()
                yield encode_sse(event)
            else:
                yield encode_sse({"type": "response.failed", "error": payload})

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.get("/v1/traces", response_model=list[CallTrace])
async def list_traces(http: Request) -> list[CallTrace]:
    # 暴露调用审计记录，供成本分析与故障排查使用。
    return http.app.state.ctx.traces.list()


@router.post("/v1/prompts")
async def create_prompt(body: PromptCreate, http: Request) -> dict:
    # 新建版本；activate 时自动停用同 id 旧版本。版本号由服务端递增，调用方不可指定。
    return http.app.state.ctx.prompt_store.create(
        prompt_id=body.id, content=body.content, description=body.description, activate=body.activate
    )


@router.get("/v1/prompts")
async def list_prompts(http: Request) -> dict:
    # 资产清单：不含模板正文，避免大列表拖慢调用。
    return {"data": http.app.state.ctx.prompt_store.list_all()}


@router.get("/v1/prompts/{prompt_id}")
async def get_prompt(prompt_id: str, http: Request, version: int | None = None) -> dict:
    row = http.app.state.ctx.prompt_store.get(prompt_id, version)
    if row is None:
        raise HTTPException(status_code=404, detail=gateway_detail("prompt_not_found", "Prompt 版本不存在"))
    return row


@router.post("/v1/prompts/{prompt_id}/render")
async def render_prompt_endpoint(prompt_id: str, body: PromptRenderRequest, http: Request) -> dict:
    # 沙箱渲染预览：与请求链路共用同一渲染函数，保证所见即所得。
    row = http.app.state.ctx.prompt_store.get(prompt_id, body.version)
    if row is None:
        raise HTTPException(status_code=404, detail=gateway_detail("prompt_not_found", "Prompt 版本不存在"))
    try:
        rendered = render_db_prompt(row["content"], body.variables)
    except GatewayError as exc:
        raise HTTPException(
            status_code=exc.status_code, detail=gateway_detail(exc.code, exc.message)
        ) from exc
    return {"id": prompt_id, "version": row["version"], "rendered": rendered}


@router.get("/admin/usage")
async def admin_usage(http: Request, limit: int = 100) -> dict[str, Any]:
    # SQLite 账本查询投影：按时间倒序返回最近 N 条用量事件（不含消息内容与原始 Key）。
    return {"data": http.app.state.ctx.ledger.recent(limit=limit)}


@router.get("/admin/usage/stats")
async def admin_usage_stats(http: Request, group_by: str = "model", limit: int = 100) -> dict[str, Any]:
    # 聚合视图：按租户（Key 指纹）/模型/Prompt 版本统计 Token、成本、TTFT 与延迟。
    try:
        rows = http.app.state.ctx.ledger.aggregate(group_by, limit)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=gateway_detail("invalid_group_by", str(exc))) from exc
    return {"group_by": group_by, "data": rows}


@router.get("/admin/routes")
async def admin_routes(http: Request, model: str | None = None) -> dict[str, Any]:
    # 运营视图：每模型熔断状态与路由配置快照，只读不触发状态迁移。
    ctx = http.app.state.ctx
    rows = []
    for name, model_config in ctx.config.models.items():
        if model is not None and name != model:
            continue
        breaker = ctx.breakers.get(name)
        row: dict[str, Any] = {"model": name}
        if breaker is not None:
            row.update(breaker.snapshot())
        row.update(
            {
                "provider_model": model_config.provider_model,
                "protocol": model_config.protocol,
                "fallback": list(model_config.fallback),
                "supports_structured_output": model_config.supports_structured_output,
                "supports_responses": model_config.supports_responses,
            }
        )
        rows.append(row)
    if model is not None and not rows:
        raise HTTPException(
            status_code=404, detail=gateway_detail("unknown_model", "模型不在 Gateway 允许列表中")
        )
    return {"data": rows}


@router.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/metrics")
async def metrics(http: Request) -> PlainTextResponse:
    return PlainTextResponse(http.app.state.ctx.metrics.render(), media_type="text/plain; version=0.0.4")
