"""YAML + 环境变量驱动的配置加载：模型、fallback 链、限流、密钥引用全部外部化。"""

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

_ENV_PATTERN = re.compile(r"\$\{(\w+)\}")


def _resolve_env(value: str) -> str:
    """将 ${VAR} 替换为环境变量值；未设置时保留原文。"""
    return _ENV_PATTERN.sub(lambda match: os.getenv(match.group(1), match.group(0)), value)


@dataclass(frozen=True)
class RetryConfig:
    max_retries: int = 1
    backoff_base: float = 0.5
    jitter: float = 0.1


@dataclass(frozen=True)
class CircuitBreakerConfig:
    failure_threshold: int = 5
    cooldown_seconds: float = 30.0


@dataclass(frozen=True)
class RateLimitConfig:
    """模型级令牌桶参数：某模型独立于其他模型的请求配额。"""

    capacity: float = 60.0
    refill_per_second: float = 1.0


@dataclass(frozen=True)
class ModelConfig:
    """平台模型名 → 供应商模型、地址、密钥环境变量与能力/价格配置。"""

    provider_model: str
    base_url: str
    api_key_env: str
    supports_structured_output: bool = True
    structured_output_mode: str = "json_schema"
    # 上游协议（chat|responses）：统一入口由 Adapter 按此选择上游协议并完成请求/响应转换
    protocol: str = "chat"
    supports_responses: bool = False
    fallback: tuple[str, ...] = ()
    retry: RetryConfig = field(default_factory=RetryConfig)
    circuit_breaker: CircuitBreakerConfig = field(default_factory=CircuitBreakerConfig)
    rate_limit: RateLimitConfig | None = None
    price_input: float = 0.0
    price_output: float = 0.0


@dataclass(frozen=True)
class PromptTemplate:
    name: str
    version: str
    system_template: str


@dataclass(frozen=True)
class GatewayConfig:
    auth_keys: tuple[str, ...] = ()
    auth_enabled: bool = True
    rate_limit_capacity: float = 60.0
    rate_limit_refill_per_second: float = 1.0
    trace_file: str = "traces.jsonl"
    database_path: str = "data/gateway.db"
    structured_output_repair_attempts: int = 2
    # OpenAI 兼容入口未知参数策略：true 时所有未支持参数一律 400（验收模式）
    strict_params: bool = False
    # Run 级总预算：单次请求的重试、修复与备用切换共用的上游尝试上限
    run_budget: int = 12
    models: dict[str, ModelConfig] = field(default_factory=dict)
    prompts: dict[tuple[str, str], PromptTemplate] = field(default_factory=dict)


def _parse_retry(raw: dict[str, Any] | None) -> RetryConfig:
    return RetryConfig(**raw) if raw else RetryConfig()


def _parse_breaker(raw: dict[str, Any] | None) -> CircuitBreakerConfig:
    return CircuitBreakerConfig(**raw) if raw else CircuitBreakerConfig()


def _parse_rate_limit(raw: dict[str, Any] | None) -> RateLimitConfig | None:
    return RateLimitConfig(**raw) if raw else None


def _parse_model(raw: dict[str, Any]) -> ModelConfig:
    return ModelConfig(
        provider_model=_resolve_env(str(raw["provider_model"])),
        base_url=_resolve_env(str(raw["base_url"])),
        api_key_env=_resolve_env(str(raw["api_key_env"])),
        supports_structured_output=bool(raw.get("supports_structured_output", True)),
        structured_output_mode=raw.get("structured_output_mode", "json_schema"),
        protocol=str(raw.get("protocol", "chat")),
        supports_responses=bool(raw.get("supports_responses", False)),
        fallback=tuple(raw.get("fallback") or []),
        retry=_parse_retry(raw.get("retry")),
        circuit_breaker=_parse_breaker(raw.get("circuit_breaker")),
        rate_limit=_parse_rate_limit(raw.get("rate_limit")),
        price_input=float(raw.get("price_input", 0)),
        price_output=float(raw.get("price_output", 0)),
    )


def _parse_prompts(raw: dict[str, Any] | None) -> dict[tuple[str, str], PromptTemplate]:
    prompts: dict[tuple[str, str], PromptTemplate] = {}
    for name, versions in (raw or {}).items():
        for version, template in versions.items():
            prompts[(name, version)] = PromptTemplate(
                name=name, version=version, system_template=str(template)
            )
    return prompts


def _parse(raw: dict[str, Any]) -> GatewayConfig:
    auth = raw.get("auth") or {}
    rate_limit = raw.get("rate_limit") or {}
    traces = raw.get("traces") or {}
    storage = raw.get("storage") or {}
    structured_output = raw.get("structured_output") or {}
    return GatewayConfig(
        auth_keys=tuple(auth.get("keys") or []),
        auth_enabled=bool(auth.get("enabled", True)),
        rate_limit_capacity=float(rate_limit.get("capacity", 60)),
        rate_limit_refill_per_second=float(rate_limit.get("refill_per_second", 1)),
        trace_file=str(traces.get("file", "traces.jsonl")),
        database_path=str(storage.get("database", "data/gateway.db")),
        structured_output_repair_attempts=int(structured_output.get("repair_attempts", 2)),
        strict_params=bool(raw.get("strict_params", False)),
        run_budget=int(raw.get("run_budget", 12)),
        models={name: _parse_model(item) for name, item in (raw.get("models") or {}).items()},
        prompts=_parse_prompts(raw.get("prompts")),
    )


def _load_dotenv(path: str = ".env") -> None:
    """加载 .env 到进程环境：仅填充尚不存在的变量，系统环境变量优先。

    只支持简单行 KEY=value：跳过空行与 # 开头的注释行，剥离值首尾引号；
    不做多行值、转义与行尾注释处理。
    """
    dotenv_file = Path(path)
    if not dotenv_file.exists():
        return
    for line in dotenv_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, _, value = line.partition("=")
        name = name.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        os.environ.setdefault(name, value)


def load_config(path: str | None = None) -> GatewayConfig:
    """加载 YAML 配置：优先显式路径，其次 GATEWAY_CONFIG_FILE，最后 config.yaml / config.example.yaml。

    先自动加载 .env 补齐缺失的环境变量（系统环境变量优先，不被覆盖）。
    """
    _load_dotenv()
    explicit = path or os.getenv("GATEWAY_CONFIG_FILE")
    candidates = [explicit] if explicit else ["config.yaml", "config.example.yaml"]
    for candidate in candidates:
        file_path = Path(candidate)
        if file_path.exists():
            raw = yaml.safe_load(file_path.read_text(encoding="utf-8")) or {}
            return _parse(raw)
    raise FileNotFoundError(f"未找到网关配置文件，尝试过: {', '.join(candidates)}")
