"""SQLite 用量账本：JSONL 审计的查询投影。

分工约定：JSONL（traces.jsonl）是不可变审计流水，逐条追加、重启可回放；
SQLite 是同一批事件的可查询投影，服务运营查询与聚合（按 Key 指纹、模型、时间）。
账本写入是尽力而为：查询层故障绝不允许影响模型调用主链路。
"""

import logging
import sqlite3
import threading
from pathlib import Path
from typing import Any

from app.schemas import CallTrace

logger = logging.getLogger("llm_gateway")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS usage_events (
    request_id      TEXT PRIMARY KEY,
    created_at      TEXT NOT NULL,
    api_key_hash    TEXT,
    requested_model TEXT NOT NULL,
    actual_model    TEXT,
    prompt_name     TEXT,
    prompt_version  TEXT,
    stream          INTEGER NOT NULL DEFAULT 0,
    status          TEXT NOT NULL,
    status_code     INTEGER NOT NULL,
    input_tokens    INTEGER NOT NULL,
    output_tokens   INTEGER NOT NULL,
    cached_tokens   INTEGER NOT NULL DEFAULT 0,
    reasoning_tokens INTEGER NOT NULL DEFAULT 0,
    usage_unknown   INTEGER NOT NULL DEFAULT 0,
    cost_usd        REAL NOT NULL,
    latency_ms      INTEGER NOT NULL,
    first_token_ms  INTEGER,
    attempts        INTEGER NOT NULL,
    error_code      TEXT
);
CREATE INDEX IF NOT EXISTS idx_usage_created ON usage_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_usage_key_hash ON usage_events(api_key_hash);
CREATE INDEX IF NOT EXISTS idx_usage_model ON usage_events(requested_model);
"""

_AGGREGATE_DIMENSIONS: dict[str, dict[str, str]] = {
    # 聚合维度白名单：select 生成输出列，group 为分组表达式，where 为可选过滤。
    # 对应验收「按租户、模型和 Prompt 版本聚合」；表达式不拼接任何调用方输入。
    "tenant": {"select": "COALESCE(api_key_hash, 'unknown') AS tenant", "group": "api_key_hash"},
    "model": {"select": "requested_model AS model", "group": "requested_model"},
    "prompt_version": {
        "select": "prompt_name AS prompt_name, prompt_version AS prompt_version",
        "group": "prompt_name, prompt_version",
        "where": "prompt_name IS NOT NULL",
    },
}


class UsageLedger:
    def __init__(self, path: str) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()

    def initialize(self) -> None:
        # 启动时建表建索引；目录不存在则创建。旧库缺列时按需补列（增量迁移）。
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(self._path) as conn:
                conn.executescript(_SCHEMA)
                self._migrate(conn)

    def _migrate(self, conn: sqlite3.Connection) -> None:
        # 账本字段随审计扩展演进：缺列补列（默认值回填历史行），不重建表。
        columns = {row[1] for row in conn.execute("PRAGMA table_info(usage_events)")}
        if "reasoning_tokens" not in columns:
            conn.execute("ALTER TABLE usage_events ADD COLUMN reasoning_tokens INTEGER NOT NULL DEFAULT 0")
        if "usage_unknown" not in columns:
            conn.execute("ALTER TABLE usage_events ADD COLUMN usage_unknown INTEGER NOT NULL DEFAULT 0")

    def record(self, trace: CallTrace) -> None:
        # 尽力而为写入：INSERT OR REPLACE 以 request_id 幂等，重复审计不会产生重复行。
        try:
            with self._lock:
                with sqlite3.connect(self._path) as conn:
                    conn.execute(
                        """
                        INSERT OR REPLACE INTO usage_events (
                            request_id, created_at, api_key_hash, requested_model, actual_model,
                            prompt_name, prompt_version, stream, status, status_code,
                            input_tokens, output_tokens, cached_tokens, reasoning_tokens, usage_unknown,
                            cost_usd, latency_ms, first_token_ms, attempts, error_code
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            trace.request_id,
                            trace.timestamp.isoformat(),
                            trace.api_key_hash,
                            trace.requested_model,
                            trace.actual_model,
                            trace.prompt_name,
                            trace.prompt_version,
                            1 if trace.stream else 0,
                            trace.status,
                            trace.status_code,
                            trace.input_tokens,
                            trace.output_tokens,
                            trace.cached_tokens,
                            trace.reasoning_tokens,
                            1 if trace.usage_unknown else 0,
                            trace.cost_usd,
                            trace.latency_ms,
                            trace.first_token_ms,
                            trace.attempts,
                            trace.error_code,
                        ),
                    )
        except sqlite3.Error:
            logger.exception("usage ledger write failed for request_id=%s", trace.request_id)

    def recent(self, limit: int = 100) -> list[dict[str, Any]]:
        # 按时间倒序返回最近 N 条，供 /admin/usage 查询。
        if not self._path.exists():
            return []
        with self._lock:
            with sqlite3.connect(self._path) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    "SELECT * FROM usage_events ORDER BY created_at DESC, rowid DESC LIMIT ?",
                    (max(1, min(limit, 1000)),),
                ).fetchall()
        return [dict(row) for row in rows]

    def aggregate(self, group_by: str, limit: int = 100) -> list[dict[str, Any]]:
        # 按租户（Key 指纹）/模型/Prompt 版本聚合 Token、成本、TTFT 与延迟，
        # 供 /admin/usage/stats 查询；TTFT 只对首个流式首块时间非空的行取平均。
        dimension = _AGGREGATE_DIMENSIONS.get(group_by)
        if dimension is None:
            raise ValueError(f"未知聚合维度: {group_by}，可选 {', '.join(_AGGREGATE_DIMENSIONS)}")
        if not self._path.exists():
            return []
        where = f"WHERE {dimension['where']}" if dimension.get("where") else ""
        query = (
            f"SELECT {dimension['select']}, COUNT(*) AS calls, "
            "SUM(input_tokens) AS input_tokens, SUM(output_tokens) AS output_tokens, "
            "SUM(cached_tokens) AS cached_tokens, SUM(reasoning_tokens) AS reasoning_tokens, "
            "ROUND(SUM(cost_usd), 8) AS cost_usd, "
            "ROUND(AVG(first_token_ms), 1) AS avg_ttft_ms, "
            "SUM(latency_ms) AS total_latency_ms, ROUND(AVG(latency_ms), 1) AS avg_latency_ms "
            f"FROM usage_events {where} GROUP BY {dimension['group']} "
            "ORDER BY calls DESC, cost_usd DESC LIMIT ?"
        )
        with self._lock:
            with sqlite3.connect(self._path) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(query, (max(1, min(limit, 1000)),)).fetchall()
        return [dict(row) for row in rows]
