"""统一错误定义与错误响应体构造。"""

from typing import Any


class GatewayError(Exception):
    """将内部错误标准化为可安全暴露给调用方的稳定错误码和 HTTP 状态。

    detail 供自修复流程内部使用（如 JSON 校验原始错误），不直接暴露给调用方。
    """

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 502,
        detail: str | None = None,
        param: str | None = None,
    ) -> None:
        self.code = code
        self.message = message
        self.status_code = status_code
        self.detail = detail
        # 触发错误的请求参数名（如 unsupported_param 的 n / tools）
        self.param = param
        super().__init__(message)


class ProviderError(Exception):
    """上游供应商调用失败的网关自有异常：适配层把 SDK 异常归一化到这里。

    gateway 只判这类类型（is_retryable/_error_code），不导入供应商 SDK；
    code 是审计字段（routing_reason / error_code）使用的稳定错误码。
    """

    code: str = "transport_error"
    retryable: bool = False


class UpstreamTimeoutError(ProviderError):
    code = "timeout"
    retryable = True


class UpstreamRateLimitedError(ProviderError):
    code = "upstream_rate_limited"
    retryable = True


class UpstreamConnectionError(ProviderError):
    code = "connection_error"
    retryable = True


class UpstreamInvalidRequestError(ProviderError):
    """上游 400/404/422：请求本身有问题，重试与切备用都无法改变结果。"""

    code = "upstream_invalid_request"
    retryable = False


class UpstreamAuthError(ProviderError):
    """上游 401/403：凭据问题；不可重试，但备用模型可能有不同凭据，仍是切换信号。"""

    code = "upstream_auth_failed"
    retryable = False


class UpstreamServerError(ProviderError):
    """上游 5xx（含 504）：服务端错误，统一不可重试、只作为切换信号。"""

    code = "upstream_server_error"
    retryable = False


def gateway_detail(code: str, message: str) -> dict[str, str]:
    """自有 /v1/llm 协议的错误 detail。"""
    return {"code": code, "message": message}


def openai_error_body(
    message: str,
    error_type: str,
    code: str,
    request_id: str | None = None,
    param: str | None = None,
) -> dict[str, Any]:
    """OpenAI 兼容协议的错误响应体。"""
    body: dict[str, Any] = {"message": message, "type": error_type, "code": code}
    if request_id:
        body["request_id"] = request_id
    if param:
        body["param"] = param
    return {"error": body}
