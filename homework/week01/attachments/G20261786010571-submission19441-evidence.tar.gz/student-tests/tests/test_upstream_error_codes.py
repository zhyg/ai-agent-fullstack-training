"""⑤ 上游错误码区分：400/401/404/422/429/5xx 归一化为可识别错误码与合理状态映射。

验收不变量：上游参数错误、鉴权失败、限流与 5xx 不再塌缩为同一 model_unavailable，
调用方可按错误码区分原因；不可重试错误不会在同一上游反复请求。
"""

import httpx
from openai import APIStatusError

from app.errors import (
    UpstreamAuthError,
    UpstreamInvalidRequestError,
    UpstreamRateLimitedError,
    UpstreamServerError,
)
from app.main import create_app
from app.services.provider import normalize_upstream_error
from tests.conftest import AUTH_KEY, FakeProvider, make_config


def _status_error(status: int) -> APIStatusError:
    response = httpx.Response(status, request=httpx.Request("POST", "https://upstream.invalid/v1"))
    return APIStatusError(f"upstream http {status}", response=response, body=None)


# ---------- 适配层归一化 ----------


def test_normalize_http_400_404_422_invalid_request():
    for status in (400, 404, 422):
        normalized = normalize_upstream_error(_status_error(status))
        assert isinstance(normalized, UpstreamInvalidRequestError)
        assert normalized.code == "upstream_invalid_request"
        assert normalized.retryable is False


def test_normalize_http_401_403_auth_failed():
    for status in (401, 403):
        normalized = normalize_upstream_error(_status_error(status))
        assert isinstance(normalized, UpstreamAuthError)
        assert normalized.code == "upstream_auth_failed"
        assert normalized.retryable is False


def test_normalize_http_429_rate_limited_retryable():
    normalized = normalize_upstream_error(_status_error(429))
    assert isinstance(normalized, UpstreamRateLimitedError)
    assert normalized.code == "upstream_rate_limited"
    assert normalized.retryable is True


def test_normalize_http_5xx_server_error_not_retryable():
    for status in (500, 503, 504):
        normalized = normalize_upstream_error(_status_error(status))
        assert isinstance(normalized, UpstreamServerError)
        assert normalized.code == "upstream_server_error"
        assert normalized.retryable is False


# ---------- 网关链尾映射 ----------


class AuthFailingStream(FakeProvider):
    """流式上游恒定鉴权失败。"""

    async def stream(self, config, messages, timeout_seconds):
        self.stream_calls.append(config.provider_model)
        raise UpstreamAuthError("上游鉴权失败")
        yield "", None  # pragma: no cover — 保证函数是异步生成器，异常在首次迭代时抛出


async def _post_json(app, path, body):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        return await client.post(path, json=body)


def _chat_body() -> dict:
    return {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}


async def test_upstream_400_terminal_distinct_no_retry(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(
        errors={
            "primary-model": UpstreamInvalidRequestError("上游拒绝请求（HTTP 400）"),
            "backup-model": UpstreamInvalidRequestError("上游拒绝请求（HTTP 400）"),
        }
    )
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/chat/completions", _chat_body())
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "upstream_invalid_request"
    # 不可重试错误不在同一上游反复请求：主备各一次
    assert provider.complete_calls == ["primary-model", "backup-model"]
    trace = app.state.ctx.traces.list()[-1]
    assert trace.error_code == "upstream_invalid_request"
    assert trace.routing_reason == "upstream_invalid_request"


async def test_upstream_401_terminal_distinct_no_retry(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(
        errors={
            "primary-model": UpstreamAuthError("上游鉴权失败（HTTP 401）"),
            "backup-model": UpstreamAuthError("上游鉴权失败（HTTP 401）"),
        }
    )
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/chat/completions", _chat_body())
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "upstream_auth_failed"
    assert provider.complete_calls == ["primary-model", "backup-model"]
    trace = app.state.ctx.traces.list()[-1]
    assert trace.error_code == "upstream_auth_failed"


async def test_upstream_429_terminal_retries_each_upstream_then_429(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(
        errors={
            "primary-model": UpstreamRateLimitedError("上游限流（HTTP 429）"),
            "backup-model": UpstreamRateLimitedError("上游限流（HTTP 429）"),
        }
    )
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/chat/completions", _chat_body())
    assert response.status_code == 429
    assert response.json()["error"]["code"] == "upstream_rate_limited"
    # 429 可重试：主备各重试 1 次后终态，调用方可据此退避
    assert provider.complete_calls == ["primary-model", "primary-model", "backup-model", "backup-model"]
    trace = app.state.ctx.traces.list()[-1]
    assert trace.error_code == "upstream_rate_limited"


async def test_upstream_503_terminal_server_error_502(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(
        errors={
            "primary-model": UpstreamServerError("上游服务错误（HTTP 503）"),
            "backup-model": UpstreamServerError("上游服务错误（HTTP 503）"),
        }
    )
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/chat/completions", _chat_body())
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "upstream_server_error"
    assert provider.complete_calls == ["primary-model", "backup-model"]


async def test_upstream_401_primary_falls_back_to_backup(tmp_path):
    # 鉴权失败仍是切换信号：备用模型有不同凭据时可救回，routing_reason 记录具体原因
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(errors={"primary-model": UpstreamAuthError("上游鉴权失败（HTTP 401）")})
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/chat/completions", _chat_body())
    assert response.status_code == 200
    # OpenAI 兼容响应体的 model 保持请求模型名；实际模型以审计为准
    trace = app.state.ctx.traces.list()[-1]
    assert trace.actual_model == "general-backup"
    assert trace.routing_reason == "upstream_auth_failed"


async def test_upstream_401_responses_path_distinct(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(
        errors={
            "primary-model": UpstreamAuthError("上游鉴权失败（HTTP 401）"),
            "backup-model": UpstreamAuthError("上游鉴权失败（HTTP 401）"),
        }
    )
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/responses", {"model": "general-primary", "input": "hi"})
    assert response.status_code == 502
    assert response.json()["error"]["code"] == "upstream_auth_failed"


async def test_upstream_401_stream_error_event_distinct(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = AuthFailingStream()
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        body = {**_chat_body(), "stream": True}
        async with client.stream("POST", "/v1/chat/completions", json=body) as response:
            text = ""
            async for line in response.aiter_lines():
                text += line + "\n"
    # 流内 error 事件携带可识别错误码，且不发送 [DONE]
    assert '"code": "upstream_auth_failed"' in text
    assert "data: [DONE]" not in text
    trace = app.state.ctx.traces.list()[-1]
    assert trace.error_code == "upstream_auth_failed"
