"""① 统一入口按模型配置选择上游协议：同一入口只改 model 即产生两种协议的上游请求。

验收不变量：
- 上游协议由统一模型配置（protocol: chat|responses）确定；
- 消息→Responses input、响应/流式事件→正文+用量的转换全部由 Adapter 完成，gateway 循环零改动；
- /v1/llm 同一入口只改 model：chat 模型走 chat.completions.create，responses 模型走 responses.create；
- 主备协议可混合：fallback 切换自动适配各模型自身协议。
"""

from dataclasses import replace
from types import SimpleNamespace

import httpx
import pytest

from app.config import ModelConfig
from app.errors import UpstreamConnectionError, UpstreamTimeoutError
from app.main import create_app
from app.schemas import Message, Usage
from app.services.provider import (
    OpenAICompatibleProvider,
    _messages_to_responses_input,
    responses_output_text,
)
from tests.conftest import AUTH_KEY, make_config


def _chat_completion() -> SimpleNamespace:
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content="chat 文本"))],
        usage=SimpleNamespace(
            prompt_tokens=10,
            completion_tokens=5,
            prompt_tokens_details=None,
            completion_tokens_details=None,
        ),
    )


def _responses_payload() -> dict:
    return {
        "id": "resp_fake",
        "object": "response",
        "model": "resp-upstream",
        "output": [{"type": "message", "content": [{"type": "output_text", "text": "responses 文本"}]}],
        "usage": {
            "input_tokens": 20,
            "output_tokens": 8,
            "total_tokens": 28,
            "input_tokens_details": {"cached_tokens": 3},
            "output_tokens_details": {"reasoning_tokens": 2},
        },
    }


def _event(event_type: str, **extra) -> SimpleNamespace:
    return SimpleNamespace(type=event_type, model_dump=lambda **kw: {"type": event_type, **extra}, **extra)


def _default_stream_events() -> list[SimpleNamespace]:
    return [
        _event("response.output_text.delta", delta="第"),
        _event("response.output_text.delta", delta="二块"),
        _event(
            "response.completed",
            response={
                "id": "resp_s",
                "usage": {"input_tokens": 20, "output_tokens": 8, "total_tokens": 28},
            },
        ),
    ]


class FakeResponsesStream:
    def __init__(self, events: list[SimpleNamespace]):
        self.events = list(events)
        self.closed = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self.events:
            raise StopAsyncIteration
        return self.events.pop(0)

    async def close(self):
        self.closed += 1


class FakeChatCompletions:
    def __init__(self):
        self.calls: list[dict] = []

    async def create(self, **kwargs):
        self.calls.append(kwargs)
        return _chat_completion()


class FakeResponses:
    def __init__(self):
        self.calls: list[dict] = []
        self.failures = 0
        self.stream_events: list[SimpleNamespace] | None = None

    async def create(self, **kwargs):
        self.calls.append(kwargs)
        if self.failures:
            self.failures -= 1
            raise UpstreamTimeoutError("responses 协议暂时超时")
        if kwargs.get("stream"):
            return FakeResponsesStream(self.stream_events or _default_stream_events())
        return SimpleNamespace(model_dump=lambda **kw: _responses_payload())


class FakeOpenAIClient:
    def __init__(self):
        # 与 AsyncOpenAI 客户端同构：chat.completions.create / responses.create
        self.chat = SimpleNamespace(completions=FakeChatCompletions())
        self.responses = FakeResponses()


def _model_config(protocol: str, structured_output_mode: str = "json_object") -> ModelConfig:
    return ModelConfig(
        provider_model="upstream-model",
        base_url="https://upstream.invalid",
        api_key_env="DEEPSEEK_API_KEY",
        structured_output_mode=structured_output_mode,
        protocol=protocol,
    )


def _seeded_provider(monkeypatch, fake_client: FakeOpenAIClient) -> OpenAICompatibleProvider:
    monkeypatch.setenv("DEEPSEEK_API_KEY", "sk-seed")
    provider = OpenAICompatibleProvider()
    provider._clients[("https://upstream.invalid", "sk-seed")] = fake_client
    return provider


async def _post_json(app, path, body):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        return await client.post(path, json=body)


# ---------- ①-1 Adapter 协议转换单元 ----------


def test_messages_to_responses_input_conversion():
    messages = [
        Message(role="system", content="系统"),
        Message(role="user", content="问题"),
        Message(role="assistant", content="回答"),
    ]
    assert _messages_to_responses_input(messages) == [
        {"role": "system", "content": "系统"},
        {"role": "user", "content": "问题"},
        {"role": "assistant", "content": "回答"},
    ]


def test_responses_output_text_extracts_first_text_block():
    payload = {
        "output": [
            {"type": "message", "content": [{"type": "output_text", "text": "你好"}]},
            {"type": "message", "content": [{"type": "output_text", "text": "忽略"}]},
        ]
    }
    assert responses_output_text(payload) == "你好"
    assert responses_output_text({"output": []}) is None
    assert responses_output_text({"output": [{"type": "message", "content": []}]}) is None


async def test_complete_chat_protocol_calls_chat_completions(monkeypatch):
    fake = FakeOpenAIClient()
    provider = _seeded_provider(monkeypatch, fake)
    content, usage = await provider.complete(
        _model_config("chat"), [Message(role="user", content="hi")], 30.0, None
    )
    assert content == "chat 文本"
    assert usage.input_tokens == 10
    assert usage.output_tokens == 5
    assert fake.chat.completions.calls == [
        {"model": "upstream-model", "messages": [{"role": "user", "content": "hi"}], "timeout": 30.0}
    ]
    assert fake.responses.calls == []


async def test_complete_responses_protocol_converts_and_extracts(monkeypatch):
    fake = FakeOpenAIClient()
    provider = _seeded_provider(monkeypatch, fake)
    messages = [Message(role="system", content="系统"), Message(role="user", content="hi")]
    content, usage = await provider.complete(_model_config("responses"), messages, 30.0, None)
    assert content == "responses 文本"
    assert usage.input_tokens == 20
    assert usage.output_tokens == 8
    assert usage.cached_tokens == 3
    assert usage.reasoning_tokens == 2
    assert fake.chat.completions.calls == []
    assert fake.responses.calls == [
        {
            "model": "upstream-model",
            "input": [{"role": "system", "content": "系统"}, {"role": "user", "content": "hi"}],
            "timeout": 30.0,
        }
    ]


async def test_complete_responses_protocol_maps_schema_to_text_format(monkeypatch):
    fake = FakeOpenAIClient()
    provider = _seeded_provider(monkeypatch, fake)
    schema = {"type": "object", "properties": {"ok": {"type": "boolean"}}}
    await provider.complete(
        _model_config("responses", "json_schema"), [Message(role="user", content="hi")], 30.0, schema
    )
    assert fake.responses.calls[0]["text"] == {
        "format": {"type": "json_schema", "name": "agent_response", "strict": True, "schema": schema}
    }
    await provider.complete(
        _model_config("responses", "json_object"), [Message(role="user", content="hi")], 30.0, schema
    )
    assert fake.responses.calls[1]["text"] == {"format": {"type": "json_object"}}


async def test_stream_responses_protocol_yields_deltas_and_terminal(monkeypatch):
    fake = FakeOpenAIClient()
    provider = _seeded_provider(monkeypatch, fake)
    chunks = []
    async for delta, usage in provider.stream(
        _model_config("responses"), [Message(role="user", content="hi")], 30.0
    ):
        chunks.append((delta, usage))
    assert chunks[0] == ("第", None)
    assert chunks[1] == ("二块", None)
    assert chunks[2] == ("", Usage(input_tokens=20, output_tokens=8))
    assert fake.chat.completions.calls == []
    assert fake.responses.calls[0]["stream"] is True
    assert fake.responses.calls[0]["include"] == ["message.output_text"]


async def test_stream_responses_missing_completed_raises_connection_error(monkeypatch):
    fake = FakeOpenAIClient()
    fake.responses.stream_events = [_event("response.output_text.delta", delta="断")]
    provider = _seeded_provider(monkeypatch, fake)
    with pytest.raises(UpstreamConnectionError):
        async for _delta, _usage in provider.stream(
            _model_config("responses"), [Message(role="user", content="hi")], 30.0
        ):
            pass


# ---------- ①-2 同一入口只改 model 产生两种协议的上游请求 ----------


async def test_same_entry_switches_upstream_protocol_by_model(tmp_path, monkeypatch):
    config = make_config(tmp_path)
    chat_model = replace(
        config.models["general-primary"], provider_model="chat-upstream", fallback=(), protocol="chat"
    )
    resp_model = replace(
        config.models["general-primary"], provider_model="resp-upstream", fallback=(), protocol="responses"
    )
    config = replace(config, models={"chat-model": chat_model, "resp-model": resp_model})
    app = create_app(config)
    fake = FakeOpenAIClient()
    app.state.ctx.provider = _seeded_provider(monkeypatch, fake)
    body = {"messages": [{"role": "user", "content": "同一个问题"}]}
    chat_response = await _post_json(app, "/v1/llm", {**body, "model": "chat-model"})
    resp_response = await _post_json(app, "/v1/llm", {**body, "model": "resp-model"})
    assert chat_response.status_code == 200
    assert resp_response.status_code == 200
    # 同一入口、同一消息，只改 model：上游分别收到 Chat 与 Responses 两种协议的请求
    assert fake.chat.completions.calls == [
        {"model": "chat-upstream", "messages": [{"role": "user", "content": "同一个问题"}], "timeout": 30.0}
    ]
    assert fake.responses.calls == [
        {
            "model": "resp-upstream",
            "input": [{"role": "user", "content": "同一个问题"}],
            "timeout": 30.0,
        }
    ]
    # 统一响应出口不受协议影响：两者都是 200 + 正文 + 用量
    assert chat_response.json()["content"] == "chat 文本"
    assert resp_response.json()["content"] == "responses 文本"
    assert resp_response.json()["usage"]["input_tokens"] == 20


async def test_stream_entry_uses_responses_protocol_by_model(tmp_path, monkeypatch):
    config = make_config(tmp_path)
    resp_model = replace(
        config.models["general-primary"], provider_model="resp-upstream", fallback=(), protocol="responses"
    )
    config = replace(config, models={"resp-model": resp_model})
    app = create_app(config)
    fake = FakeOpenAIClient()
    app.state.ctx.provider = _seeded_provider(monkeypatch, fake)
    response = await _post_json(
        app, "/v1/llm/stream", {"model": "resp-model", "messages": [{"role": "user", "content": "hi"}]}
    )
    assert response.status_code == 200
    assert '"type": "content.delta"' in response.text
    assert "第" in response.text and "二块" in response.text
    assert '"type": "response.completed"' in response.text
    assert '"usage"' in response.text
    assert fake.chat.completions.calls == []
    assert fake.responses.calls[0]["stream"] is True
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "success"
    assert trace.actual_model == "resp-model"


# ---------- ①-3 主备协议可混合：fallback 切换自动适配各自协议 ----------


async def test_fallback_switches_between_protocols(tmp_path, monkeypatch):
    config = make_config(tmp_path)
    primary = replace(config.models["general-primary"], provider_model="resp-upstream", protocol="responses")
    backup = replace(config.models["general-backup"], provider_model="chat-upstream", protocol="chat")
    config = replace(config, models={"general-primary": primary, "general-backup": backup})
    app = create_app(config)
    fake = FakeOpenAIClient()
    fake.responses.failures = 2  # 原请求 + 1 次重试均失败 → 切备用
    app.state.ctx.provider = _seeded_provider(monkeypatch, fake)
    response = await _post_json(
        app, "/v1/llm", {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert response.status_code == 200
    assert response.json()["model"] == "general-backup"
    # 主模型走 Responses（重试也走 Responses），备用走 Chat：切换自动适配各模型协议
    assert [call["model"] for call in fake.responses.calls] == ["resp-upstream", "resp-upstream"]
    assert [call["model"] for call in fake.chat.completions.calls] == ["chat-upstream"]
    trace = app.state.ctx.traces.list()[-1]
    assert trace.routing_reason == "timeout"
    assert trace.attempts == 3
