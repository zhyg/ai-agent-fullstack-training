"""② 结构化输出缺口补测：
- Chat 空正文（None / 空串）统一走 invalid_json 失败处理（不误判为 transport_error、不做自修复）
- Chat 截断 JSON：自修复后成功 / 修复耗尽切备用 / 全链失败保留 invalid_json
- Responses text.format：json_schema 校验、非法 JSON、缺 schema、流式组合、未知格式类型、text 透传
"""

import httpx
import pytest

from app.schemas import Usage
from tests.conftest import AUTH_KEY, FakeProvider

SCHEMA = {
    "type": "object",
    "properties": {"ok": {"type": "boolean"}},
    "required": ["ok"],
}
VALID_JSON = '{"ok": true}'


class SequenceContent(FakeProvider):
    """按调用顺序返回指定正文（用于截断→自修复→成功）。"""

    def __init__(self, contents: list[str | None]):
        super().__init__()
        self.contents = contents

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        content = self.contents.pop(0) if self.contents else "正常结果"
        return content, Usage(input_tokens=1, output_tokens=1)


class PerModelContent(FakeProvider):
    """按供应商模型名返回不同正文。"""

    def __init__(self, content_by_model: dict[str, str | None]):
        super().__init__()
        self.content_by_model = content_by_model

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        if config.provider_model in self.content_by_model:
            return self.content_by_model[config.provider_model], Usage(input_tokens=1, output_tokens=1)
        return await super().complete(config, messages, timeout_seconds, response_schema)


class PerModelResponses(FakeProvider):
    """按供应商模型名返回不同 Responses 正文。"""

    def __init__(self, content_by_model: dict[str, str]):
        super().__init__()
        self.content_by_model = content_by_model

    async def responses(self, config, input_data, timeout_seconds, text=None):
        self.responses_calls.append(config.provider_model)
        self.last_text = text
        content = self.content_by_model.get(config.provider_model, "正常结果")
        usage = Usage(input_tokens=1, output_tokens=1)
        return {
            "id": "resp_fake",
            "object": "response",
            "model": config.provider_model,
            "output": [{"type": "message", "content": [{"type": "output_text", "text": content}]}],
            "usage": {"input_tokens": 1, "output_tokens": 1},
        }, usage


def _json_object_body(model: str = "general-primary") -> dict:
    return {
        "model": model,
        "messages": [{"role": "user", "content": "hi"}],
        "response_format": {"type": "json_object"},
    }


# ---------- Chat 空正文 ----------


@pytest.mark.parametrize("empty", [None, ""])
async def test_chat_empty_content_invalid_json_falls_back(app, empty):
    provider = PerModelContent({"primary-model": empty, "backup-model": VALID_JSON})
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/chat/completions", json=_json_object_body())
    assert response.status_code == 200
    # 空正文不误判为 transport_error、不自修复：一次失败后直接切备用
    assert provider.complete_calls == ["primary-model", "backup-model"]
    traces = app.state.ctx.traces.list()
    assert traces[-1].actual_model == "general-backup"
    assert traces[-1].routing_reason == "invalid_json"


# ---------- Chat 截断 / 修复 ----------


async def test_chat_truncated_json_repairs_same_model(app):
    provider = SequenceContent(['{"a":', VALID_JSON])
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/chat/completions", json=_json_object_body())
    assert response.status_code == 200
    # 截断 JSON 属可修复：同一模型自修复后成功，不切备用
    assert provider.complete_calls == ["primary-model", "primary-model"]
    traces = app.state.ctx.traces.list()
    assert traces[-1].actual_model == "general-primary"
    assert traces[-1].attempts == 2


async def test_chat_truncated_repair_exhausted_falls_back(app):
    provider = PerModelContent({"primary-model": '{"a":', "backup-model": VALID_JSON})
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/chat/completions", json=_json_object_body())
    assert response.status_code == 200
    # 3 次主模型（1 次原请求 + 2 次自修复）耗尽后切备用
    assert provider.complete_calls == ["primary-model", "primary-model", "primary-model", "backup-model"]
    traces = app.state.ctx.traces.list()
    assert traces[-1].actual_model == "general-backup"
    assert traces[-1].routing_reason == "invalid_json"


async def test_chat_invalid_repair_fails_all_models(app):
    provider = PerModelContent({"primary-model": "不是JSON", "backup-model": "也不是JSON"})
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/chat/completions", json=_json_object_body())
    assert response.status_code == 502
    # 修复后仍失败：全链失败保留最具体的 invalid_json（而非 model_unavailable）
    assert response.json()["error"]["code"] == "invalid_json"
    traces = app.state.ctx.traces.list()
    assert traces[-1].error_code == "invalid_json"
    assert traces[-1].status == "failed"


# ---------- Responses text.format ----------


def _responses_body(**extra) -> dict:
    body: dict = {"model": "general-primary", "input": "hi"}
    body.update(extra)
    return body


async def test_responses_json_schema_valid_passes(app):
    fake = FakeProvider(content=VALID_JSON)
    app.state.ctx.provider = fake
    text = {"format": {"type": "json_schema", "name": "x", "schema": SCHEMA, "strict": True}}
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/responses", json=_responses_body(text=text))
    assert response.status_code == 200
    # 约束原样转发上游；审计记录 Schema 指纹
    assert fake.last_text == text
    traces = app.state.ctx.traces.list()
    assert traces[-1].schema_hash is not None


async def test_responses_json_schema_invalid_all_models_fail(app):
    provider = PerModelResponses({"primary-model": '{"nope": 1}', "backup-model": '{"nope": 1}'})
    app.state.ctx.provider = provider
    text = {"format": {"type": "json_schema", "name": "x", "schema": SCHEMA}}
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/responses", json=_responses_body(text=text))
    assert response.status_code == 502
    # 违反 Schema 不再是静默成功：切备用后仍失败，保留具体错误码
    assert response.json()["error"]["code"] == "schema_validation_failed"
    assert provider.responses_calls == ["primary-model", "backup-model"]


async def test_responses_malformed_json_falls_back(app):
    provider = PerModelResponses({"primary-model": "not json{{", "backup-model": VALID_JSON})
    app.state.ctx.provider = provider
    text = {"format": {"type": "json_schema", "name": "x", "schema": SCHEMA}}
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/responses", json=_responses_body(text=text))
    assert response.status_code == 200
    traces = app.state.ctx.traces.list()
    assert traces[-1].actual_model == "general-backup"
    assert traces[-1].routing_reason == "invalid_json"


async def test_responses_json_schema_missing_schema_400(client):
    response = await client.post(
        "/v1/responses", json=_responses_body(text={"format": {"type": "json_schema"}})
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "invalid_response_format"


async def test_responses_stream_with_format_400(client):
    response = await client.post(
        "/v1/responses",
        json=_responses_body(stream=True, text={"format": {"type": "json_object"}}),
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "unsupported_combination"


async def test_responses_unknown_format_type_400(client):
    response = await client.post("/v1/responses", json=_responses_body(text={"format": {"type": "yaml"}}))
    assert response.status_code == 400
    body = response.json()["error"]
    assert body["code"] == "unsupported_param"
    assert body["param"] == "text.format.type"


async def test_responses_text_format_type_text_passthrough(app):
    fake = FakeProvider(content="这不是JSON的普通文本")
    app.state.ctx.provider = fake
    text = {"format": {"type": "text"}}
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post("/v1/responses", json=_responses_body(text=text))
    # text 类型不做本地 JSON 校验：普通文本透传成功，约束原样转发
    assert response.status_code == 200
    assert fake.last_text == text
