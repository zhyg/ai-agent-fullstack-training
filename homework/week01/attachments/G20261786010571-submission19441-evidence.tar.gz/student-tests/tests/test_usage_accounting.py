"""④ 用量账本修正：已知用量累积、未知部分标记、入口失败进入统一审计出口。

验收不变量：
- 修复成功累积每次已知用量（而非只记最后一次），成本按逐次尝试的实际价格叠加；
- 校验失败不把已知用量记零；失败尝试无用量时用 usage_unknown 标记账本不完整；
- 未知模型、模板缺项、参数拒绝等入口失败同样落一条 failed 审计记录（attempts=0）。
"""

from dataclasses import replace

import httpx
import pytest

from app.errors import UpstreamTimeoutError
from app.main import create_app
from app.schemas import Usage
from tests.conftest import AUTH_KEY, FakeProvider, make_config


def _json_object_body() -> dict:
    return {
        "model": "general-primary",
        "messages": [{"role": "user", "content": "x"}],
        "response_schema": {"type": "object"},
    }


async def _post_json(app, path, body):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        return await client.post(path, json=body)


# ---------- ④-1 修复成功累积用量 ----------


class RepairUsageProvider(FakeProvider):
    """按顺序返回正文与用量：第一次非法（触发自修复），第二次合法。"""

    def __init__(self, contents: list[str], usages: list[Usage]):
        super().__init__()
        self.contents = list(contents)
        self.usages = list(usages)

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        content = self.contents.pop(0) if self.contents else "正常结果"
        usage = self.usages.pop(0) if self.usages else Usage(input_tokens=0, output_tokens=0)
        return content, usage


async def test_repair_success_accumulates_usage(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = RepairUsageProvider(
        contents=['{"a":', '{"ok": true}'],
        usages=[Usage(input_tokens=100, output_tokens=50), Usage(input_tokens=20, output_tokens=10)],
    )
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/llm", _json_object_body())
    assert response.status_code == 200
    # 审计与账本记录两次尝试的累计用量，而非只记最后一次
    trace = app.state.ctx.traces.list()[-1]
    assert trace.attempts == 2
    assert trace.input_tokens == 120
    assert trace.output_tokens == 60
    assert trace.usage_unknown is False
    # 成本按每次尝试的实际价格叠加：100/50 + 20/10，均按 primary 价格 1.0/4.0 美元每百万
    assert trace.cost_usd == pytest.approx((120 * 1.0 + 60 * 4.0) / 1_000_000)
    row = app.state.ctx.ledger.recent()[0]
    assert row["input_tokens"] == 120
    assert row["output_tokens"] == 60
    assert row["usage_unknown"] == 0


# ---------- ④-2 校验失败保留已知用量并标记未知 ----------


class PrimaryInvalidBackupTimeout(FakeProvider):
    """主模型恒定非法 JSON（已知用量），备用恒定超时（无用量）。"""

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        if config.provider_model == "primary-model":
            return '{"a":', Usage(input_tokens=100, output_tokens=50)
        raise UpstreamTimeoutError("backup down")


class BothModelsInvalid(FakeProvider):
    """主备均返回非法 JSON，且各自带回已知用量。"""

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        if config.provider_model == "primary-model":
            return "不是JSON", Usage(input_tokens=100, output_tokens=50)
        return "也不是JSON", Usage(input_tokens=20, output_tokens=10)


async def test_failure_keeps_known_usage_and_marks_unknown(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = PrimaryInvalidBackupTimeout()
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/llm", _json_object_body())
    assert response.status_code == 502
    # 终态反映最后一次错误（备用超时 → model_unavailable）；首次切换原因保留在 routing_reason
    assert response.json()["detail"]["code"] == "model_unavailable"
    # 主模型 3 次（1 次原请求 + 2 次修复）的已知用量保留，不再记零；
    # 备用超时尝试无用量 → usage_unknown 标记账本不完整
    trace = app.state.ctx.traces.list()[-1]
    assert trace.error_code == "model_unavailable"
    assert trace.routing_reason == "invalid_json"
    assert trace.input_tokens == 300
    assert trace.output_tokens == 150
    assert trace.usage_unknown is True
    assert trace.cost_usd == pytest.approx((300 * 1.0 + 150 * 4.0) / 1_000_000)
    row = app.state.ctx.ledger.recent()[0]
    assert row["input_tokens"] == 300
    assert row["usage_unknown"] == 1


async def test_failure_all_attempts_known_usage(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = BothModelsInvalid()
    app.state.ctx.provider = provider
    response = await _post_json(app, "/v1/llm", _json_object_body())
    assert response.status_code == 502
    # 主备各 3 次尝试（原请求 + 2 次修复）均带回用量：累计而非记零，未知标记为假
    trace = app.state.ctx.traces.list()[-1]
    assert trace.input_tokens == 360
    assert trace.output_tokens == 180
    assert trace.usage_unknown is False
    primary_cost = 3 * (100 * 1.0 + 50 * 4.0) / 1_000_000
    backup_cost = 3 * (20 * 0.8 + 10 * 3.2) / 1_000_000
    assert trace.cost_usd == pytest.approx(primary_cost + backup_cost)


async def test_stream_failure_marks_usage_unknown(tmp_path):
    app = create_app(make_config(tmp_path))
    provider = FakeProvider(stream_failures=5)
    app.state.ctx.provider = provider
    response = await _post_json(
        app, "/v1/llm/stream", {"model": "general-primary", "messages": [{"role": "user", "content": "x"}]}
    )
    assert response.status_code == 200
    assert "response.failed" in response.text
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.usage_unknown is True


# ---------- ④-3 入口失败进入统一审计出口 ----------


async def test_unknown_model_entry_failure_audited(tmp_path):
    app = create_app(make_config(tmp_path))
    response = await _post_json(
        app,
        "/v1/chat/completions",
        {"model": "not-allowed", "messages": [{"role": "user", "content": "x"}]},
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "unknown_model"
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "unknown_model"
    assert trace.status_code == 400
    assert trace.attempts == 0
    assert trace.requested_model == "not-allowed"
    assert trace.actual_model is None
    row = app.state.ctx.ledger.recent()[0]
    assert row["error_code"] == "unknown_model"
    assert row["attempts"] == 0


async def test_missing_prompt_variable_entry_failure_audited(tmp_path):
    app = create_app(make_config(tmp_path))
    body = {
        "model": "general-primary",
        "messages": [{"role": "user", "content": "x"}],
        # knowledge_decision 模板要求 ${product_name}，此处缺失
        "prompt": {"name": "knowledge_decision", "version": "v1"},
    }
    response = await _post_json(app, "/v1/llm", body)
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "missing_prompt_variable"
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "missing_prompt_variable"
    assert trace.attempts == 0
    assert trace.prompt_name == "knowledge_decision"


async def test_unsupported_param_entry_failure_audited(tmp_path):
    app = create_app(make_config(tmp_path))
    response = await _post_json(
        app,
        "/v1/chat/completions",
        {"model": "general-primary", "messages": [{"role": "user", "content": "x"}], "n": 2},
    )
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "unsupported_param"
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "unsupported_param"
    assert trace.attempts == 0


async def test_responses_unsupported_entry_failure_audited(tmp_path):
    config = make_config(tmp_path)
    primary = replace(config.models["general-primary"], supports_responses=False)
    app = create_app(replace(config, models={"general-primary": primary}))
    response = await _post_json(app, "/v1/responses", {"model": "general-primary", "input": "hi"})
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "responses_unsupported"
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "responses_unsupported"
    assert trace.attempts == 0
