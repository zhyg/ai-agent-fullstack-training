"""测试夹具：FakeProvider 注入 + 可覆盖的临时配置，全程无网络依赖。"""

from collections.abc import AsyncIterator
from dataclasses import replace

import httpx
import pytest

from app.config import CircuitBreakerConfig, GatewayConfig, ModelConfig, PromptTemplate, RetryConfig
from app.errors import UpstreamTimeoutError
from app.main import create_app
from app.schemas import Usage

AUTH_KEY = "sk-test-key"


class FakeProvider:
    """内存版上游供应商：可注入失败次数、恒定异常与流式失败，全程无网络。"""

    def __init__(
        self,
        content: str = "正常结果",
        failures: int = 0,
        error: Exception | None = None,
        stream_failures: int = 0,
        cached_tokens: int = 0,
        reasoning_tokens: int = 0,
        errors: dict[str, Exception] | None = None,
    ) -> None:
        self.content = content
        self.failures = failures
        self.error = error
        self.stream_failures = stream_failures
        self.cached_tokens = cached_tokens
        self.reasoning_tokens = reasoning_tokens
        # 按供应商模型名注入确定性异常（优先于全局 error/failures），用于多模型差异化故障
        self.errors = errors or {}
        self.complete_calls: list[str] = []
        self.stream_calls: list[str] = []
        self.responses_calls: list[str] = []
        self.last_messages: list = []
        self.stream_closed = 0
        self.responses_stream_closed = 0

    def _responses_payload(self, provider_model: str) -> dict:
        return {
            "id": "resp_fake_123",
            "object": "response",
            "model": provider_model,
            "output": [{"type": "message", "content": [{"type": "output_text", "text": self.content}]}],
            "usage": {
                "input_tokens": 11,
                "output_tokens": 7,
                "total_tokens": 18,
                "input_tokens_details": {"cached_tokens": self.cached_tokens},
            },
        }

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        self.last_messages = messages
        per_model = self.errors.get(config.provider_model)
        if per_model is not None:
            raise per_model
        if self.error is not None:
            raise self.error
        if self.failures:
            self.failures -= 1
            raise UpstreamTimeoutError("temporary upstream timeout")
        return self.content, Usage(
            input_tokens=11,
            output_tokens=7,
            cached_tokens=self.cached_tokens,
            reasoning_tokens=self.reasoning_tokens,
        )

    async def stream(self, config, messages, timeout_seconds) -> AsyncIterator[tuple[str, Usage | None]]:
        self.stream_calls.append(config.provider_model)
        self.last_messages = messages
        if self.stream_failures:
            self.stream_failures -= 1
            raise UpstreamTimeoutError("stream timeout before first delta")
        try:
            yield "第", None
            yield "一块", Usage(input_tokens=9, output_tokens=4, reasoning_tokens=self.reasoning_tokens)
            yield "", None  # 成功终态标记：网关据此判定流正常完成
        finally:
            # 无论正常耗尽还是客户端断开（GeneratorExit），都会进入清理路径
            self.stream_closed += 1

    async def responses(self, config, input_data, timeout_seconds, text=None):
        self.responses_calls.append(config.provider_model)
        self.last_text = text
        per_model = self.errors.get(config.provider_model)
        if per_model is not None:
            raise per_model
        if self.error is not None:
            raise self.error
        if self.failures:
            self.failures -= 1
            raise UpstreamTimeoutError("temporary upstream timeout")
        usage = Usage(
            input_tokens=11,
            output_tokens=7,
            cached_tokens=self.cached_tokens,
            reasoning_tokens=self.reasoning_tokens,
        )
        return self._responses_payload(config.provider_model), usage

    async def responses_stream(self, config, input_data, timeout_seconds, text=None):
        self.responses_calls.append(config.provider_model)
        self.last_text = text
        if self.stream_failures:
            self.stream_failures -= 1
            raise UpstreamTimeoutError("stream timeout before first delta")
        try:
            yield "response.output_text.delta", {"type": "response.output_text.delta", "delta": "第"}, None
            yield "response.output_text.delta", {"type": "response.output_text.delta", "delta": "一块"}, None
            completed = {
                "type": "response.completed",
                "response": {
                    "id": "resp_fake_stream",
                    "object": "response",
                    "model": config.provider_model,
                    "usage": {"input_tokens": 9, "output_tokens": 4, "total_tokens": 13},
                },
            }
            yield (
                "response.completed",
                completed,
                Usage(input_tokens=9, output_tokens=4, reasoning_tokens=self.reasoning_tokens),
            )
        finally:
            self.responses_stream_closed += 1


def make_config(tmp_path, **overrides) -> GatewayConfig:
    retry = RetryConfig(max_retries=1, backoff_base=0.01, jitter=0.0)
    breaker = CircuitBreakerConfig(failure_threshold=3, cooldown_seconds=30.0)
    primary = ModelConfig(
        provider_model="primary-model",
        base_url="https://upstream.invalid",
        api_key_env="DEEPSEEK_API_KEY",
        supports_structured_output=True,
        structured_output_mode="json_object",
        supports_responses=True,
        fallback=("general-backup",),
        retry=retry,
        circuit_breaker=breaker,
        price_input=1.0,
        price_output=4.0,
    )
    backup = replace(primary, provider_model="backup-model", fallback=(), price_input=0.8, price_output=3.2)
    config = GatewayConfig(
        auth_keys=(AUTH_KEY,),
        rate_limit_capacity=100.0,
        rate_limit_refill_per_second=100.0,
        trace_file=str(tmp_path / "traces.jsonl"),
        database_path=str(tmp_path / "gateway.db"),
        models={"general-primary": primary, "general-backup": backup},
        prompts={
            ("knowledge_decision", "v1"): PromptTemplate(
                name="knowledge_decision", version="v1", system_template="你是${product_name}的知识库决策器。"
            )
        },
    )
    return replace(config, **overrides)


@pytest.fixture
def app(tmp_path):
    return create_app(make_config(tmp_path))


@pytest.fixture
async def client(app):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as async_client:
        yield async_client


@pytest.fixture
def fake(app) -> FakeProvider:
    provider = FakeProvider()
    app.state.ctx.provider = provider
    return provider
