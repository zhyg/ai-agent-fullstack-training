"""自有 /v1/llm 协议：模板、结构化输出、fallback、流式、熔断与校验。"""

import json
from dataclasses import replace

import httpx
import pytest

from app.config import CircuitBreakerConfig, RetryConfig
from app.errors import GatewayError, UpstreamRateLimitedError, UpstreamTimeoutError
from app.main import create_app
from app.schemas import Usage
from tests.conftest import AUTH_KEY, FakeProvider, make_config


class PerModelProvider:
    """按上游模型名返回不同内容，用于验证特定错误码触发 fallback。"""

    def __init__(self, contents: dict[str, str]) -> None:
        self.contents = contents

    async def complete(self, config, messages, timeout_seconds, response_schema):
        return self.contents.get(config.provider_model, ""), Usage(input_tokens=1, output_tokens=1)

    async def stream(self, config, messages, timeout_seconds):
        yield self.contents.get(config.provider_model, ""), Usage(input_tokens=1, output_tokens=1)
        yield "", None  # 成功终态标记


class MisconfiguredPrimaryProvider:
    """主模型凭据缺失、备用模型正常，验证 gateway_misconfigured 触发 fallback。"""

    async def complete(self, config, messages, timeout_seconds, response_schema):
        if config.provider_model == "primary-model":
            raise GatewayError("gateway_misconfigured", "Gateway 模型凭据未配置", 503)
        return "备用正常", Usage(input_tokens=1, output_tokens=1)

    async def stream(self, config, messages, timeout_seconds):
        yield "备用正常", Usage(input_tokens=1, output_tokens=1)
        yield "", None  # 成功终态标记


async def test_non_stream_with_prompt_template(client, fake):
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "prompt": {
                "name": "knowledge_decision",
                "version": "v1",
                "variables": {"product_name": "测试助手"},
            },
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["content"] == "正常结果"
    assert body["usage"] == {
        "input_tokens": 11,
        "output_tokens": 7,
        "cached_tokens": 0,
        "reasoning_tokens": 0,
    }
    assert body["attempts"] == 1
    assert body["model"] == "general-primary"


async def test_structured_output_invalid_json(client, fake):
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "response_schema": {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
                "additionalProperties": False,
            },
        },
    )
    assert response.status_code == 502
    assert response.json()["detail"]["code"] == "invalid_json"


async def test_structured_output_valid(client, app):
    app.state.ctx.provider = FakeProvider(content=json.dumps({"answer": "ok"}))
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "response_schema": {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
                "additionalProperties": False,
            },
        },
    )
    assert response.status_code == 200, response.text
    assert response.json()["parsed"] == {"answer": "ok"}


async def test_fallback_after_retries(client, app):
    app.state.ctx.provider = FakeProvider(failures=2)
    response = await client.post(
        "/v1/llm",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "retry"}]},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model"] == "general-backup"
    assert body["attempts"] == 3


async def test_stream(client, fake):
    response = await client.post(
        "/v1/llm/stream",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "stream"}]},
    )
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert '"type": "content.delta"' in response.text
    assert '"type": "response.completed"' in response.text
    # completed 事件携带实际模型与 token 用量
    assert '"model": "general-primary"' in response.text
    assert '"input_tokens": 9' in response.text


async def test_unknown_field_rejected(client, fake):
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "unexpected": True,
        },
    )
    assert response.status_code == 422


async def test_stream_with_schema_rejected(client, fake):
    response = await client.post(
        "/v1/llm/stream",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "x"}],
            "response_schema": {"type": "object"},
        },
    )
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "unsupported_combination"


async def test_unknown_model(client, fake):
    response = await client.post(
        "/v1/llm",
        json={"model": "not-allowed", "messages": [{"role": "user", "content": "x"}]},
    )
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "unknown_model"


async def test_circuit_breaker_skips_open_model(tmp_path):
    # 主模型熔断阈值 1、重试 0 次：首次调用触发熔断，后续调用直接走备用模型。
    config = make_config(tmp_path)
    primary = replace(
        config.models["general-primary"],
        retry=RetryConfig(max_retries=0, backoff_base=0.01, jitter=0.0),
        circuit_breaker=CircuitBreakerConfig(failure_threshold=1, cooldown_seconds=30.0),
    )
    config = replace(
        config, models={"general-primary": primary, "general-backup": config.models["general-backup"]}
    )
    app = create_app(config)
    provider = FakeProvider(failures=1)
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        for _ in range(2):
            response = await client.post(
                "/v1/llm",
                json={"model": "general-primary", "messages": [{"role": "user", "content": "cb"}]},
            )
            assert response.status_code == 200, response.text
            assert response.json()["model"] == "general-backup"
    assert provider.complete_calls == ["primary-model", "backup-model", "backup-model"]


async def test_invalid_json_falls_back_to_backup(client, app):
    # 主模型返回非法 JSON 时不再直接 502，而是切换备用模型
    app.state.ctx.provider = PerModelProvider(
        {"primary-model": "不是JSON", "backup-model": json.dumps({"answer": "ok"})}
    )
    response = await client.post(
        "/v1/llm",
        json={
            "model": "general-primary",
            "messages": [{"role": "user", "content": "hello"}],
            "response_schema": {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
                "additionalProperties": False,
            },
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model"] == "general-backup"
    assert body["parsed"] == {"answer": "ok"}


async def test_gateway_misconfigured_falls_back(client, app):
    # 主模型凭据未配置（gateway_misconfigured）也走 fallback，而非直接失败
    app.state.ctx.provider = MisconfiguredPrimaryProvider()
    response = await client.post(
        "/v1/llm",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 200, response.text
    assert response.json()["model"] == "general-backup"


class SleepShim:
    """替代 gateway 模块内的 asyncio.sleep，记录退避等待参数而不真正睡眠。"""

    def __init__(self) -> None:
        self.calls: list[float] = []

    async def sleep(self, seconds: float) -> None:
        self.calls.append(seconds)


class RateLimitedPrimaryProvider:
    """主模型恒定 429、备用模型正常，验证限流属于可重试错误并触发 fallback。"""

    def __init__(self) -> None:
        self.complete_calls: list[str] = []

    async def complete(self, config, messages, timeout_seconds, response_schema):
        self.complete_calls.append(config.provider_model)
        if config.provider_model == "primary-model":
            raise UpstreamRateLimitedError("rate limited")
        return "备用正常", Usage(input_tokens=1, output_tokens=1)

    async def stream(self, config, messages, timeout_seconds):
        yield "备用正常", Usage(input_tokens=1, output_tokens=1)
        yield "", None  # 成功终态标记


async def test_retry_waits_exponential_backoff(client, app, monkeypatch):
    # 超时重试前必须等待指数退避（backoff_base * 2^attempt），jitter=0 时精确断言
    shim = SleepShim()
    monkeypatch.setattr("app.services.gateway.asyncio", shim)
    app.state.ctx.provider = FakeProvider(failures=1)
    response = await client.post(
        "/v1/llm",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "backoff"}]},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model"] == "general-primary"
    assert body["attempts"] == 2
    assert shim.calls == [pytest.approx(0.01)]


async def test_rate_limit_429_falls_back_after_retries(client, app, monkeypatch):
    # 429 限流按可重试错误退避重试，耗尽后切换备用模型
    shim = SleepShim()
    monkeypatch.setattr("app.services.gateway.asyncio", shim)
    provider = RateLimitedPrimaryProvider()
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/llm",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "429"}]},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model"] == "general-backup"
    assert body["attempts"] == 3
    assert provider.complete_calls == ["primary-model", "primary-model", "backup-model"]
    assert shim.calls == [pytest.approx(0.01)]


async def test_all_models_down_records_failed_trace(tmp_path):
    # 主备全挂：返回 model_unavailable，审计 trace 记录 failed 状态且用量归零
    config = make_config(tmp_path)
    app = create_app(config)
    app.state.ctx.provider = FakeProvider(error=UpstreamTimeoutError("upstream down"))
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        response = await client.post(
            "/v1/llm",
            json={"model": "general-primary", "messages": [{"role": "user", "content": "down"}]},
        )
        assert response.status_code == 502
        assert response.json()["detail"]["code"] == "model_unavailable"
    trace = app.state.ctx.traces.list()[-1]
    assert trace.status == "failed"
    assert trace.error_code == "model_unavailable"
    assert trace.input_tokens == 0
    assert trace.output_tokens == 0
    assert trace.attempts == 4


async def test_circuit_open_preserved_when_all_breakers_open(tmp_path):
    # 主备全部熔断后，最终错误码保留最具体的 circuit_open（503），而非塌缩为 model_unavailable
    config = make_config(tmp_path)
    no_retry = RetryConfig(max_retries=0, backoff_base=0.01, jitter=0.0)
    sensitive = CircuitBreakerConfig(failure_threshold=1, cooldown_seconds=30.0)
    primary = replace(config.models["general-primary"], retry=no_retry, circuit_breaker=sensitive)
    backup = replace(config.models["general-backup"], retry=no_retry, circuit_breaker=sensitive)
    config = replace(config, models={"general-primary": primary, "general-backup": backup})
    app = create_app(config)
    provider = FakeProvider(error=UpstreamTimeoutError("upstream down"))
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "down"}]}
        first = await client.post("/v1/llm", json=payload)
        assert first.status_code == 502
        assert first.json()["detail"]["code"] == "model_unavailable"
        second = await client.post("/v1/llm", json=payload)
        assert second.status_code == 503
        assert second.json()["detail"]["code"] == "circuit_open"
    # 第二次请求主备均被熔断跳过，不再产生任何上游调用
    assert provider.complete_calls == ["primary-model", "backup-model"]
    assert app.state.ctx.traces.list()[-1].error_code == "circuit_open"


async def test_breaker_half_open_probe_recovers_primary(tmp_path):
    # 熔断打开且冷却期过后，网关放行一个探测请求；探测成功即恢复主模型
    config = make_config(tmp_path)
    no_retry = RetryConfig(max_retries=0, backoff_base=0.01, jitter=0.0)
    primary = replace(
        config.models["general-primary"],
        retry=no_retry,
        circuit_breaker=CircuitBreakerConfig(failure_threshold=1, cooldown_seconds=0.0),
    )
    config = replace(
        config, models={"general-primary": primary, "general-backup": config.models["general-backup"]}
    )
    app = create_app(config)
    provider = FakeProvider(failures=1)
    app.state.ctx.provider = provider
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {AUTH_KEY}"}
    ) as client:
        payload = {"model": "general-primary", "messages": [{"role": "user", "content": "probe"}]}
        first = await client.post("/v1/llm", json=payload)
        assert first.status_code == 200, first.text
        assert first.json()["model"] == "general-backup"
        assert app.state.ctx.breakers["general-primary"].state == "open"
        second = await client.post("/v1/llm", json=payload)
        assert second.status_code == 200, second.text
        assert second.json()["model"] == "general-primary"
    assert provider.complete_calls == ["primary-model", "backup-model", "primary-model"]
    assert app.state.ctx.breakers["general-primary"].state == "closed"


async def test_stream_retries_before_first_delta(client, app, monkeypatch):
    # 流式首块前上游失败允许重试；首块之后才禁止重试，避免文本重复
    shim = SleepShim()
    monkeypatch.setattr("app.services.gateway.asyncio", shim)
    provider = FakeProvider(stream_failures=1)
    app.state.ctx.provider = provider
    response = await client.post(
        "/v1/llm/stream",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "stream-retry"}]},
    )
    assert response.status_code == 200
    assert '"type": "content.delta"' in response.text
    assert '"type": "response.completed"' in response.text
    assert '"model": "general-primary"' in response.text
    assert '"input_tokens": 9' in response.text
    assert provider.stream_calls == ["primary-model", "primary-model"]
    assert shim.calls == [pytest.approx(0.01)]
    assert app.state.ctx.traces.list()[-1].attempts == 2
