"""③ 断流治理验收：已输出内容后断流不再切备用（防重复输出）；
流未收到成功终态即视为失败（不宣告成功）。"""

import json
from collections.abc import AsyncIterator

from app.errors import UpstreamTimeoutError
from app.schemas import Usage

from .conftest import FakeProvider


class EmitThenBreak(FakeProvider):
    """主模型输出内容后断流；备用模型完全正常（若被调用即证明发生了切换）。"""

    async def stream(self, config, messages, timeout_seconds) -> AsyncIterator[tuple[str, Usage | None]]:
        self.stream_calls.append(config.provider_model)
        if config.provider_model == "primary-model":
            try:
                yield "第一段", None
                raise UpstreamTimeoutError("首块后断流")
            finally:
                self.stream_closed += 1
        try:
            yield "备用内容", None
            yield "", None
        finally:
            self.stream_closed += 1


class SilentEndStream(FakeProvider):
    """产出内容后静默耗尽：不带任何成功终态。"""

    async def stream(self, config, messages, timeout_seconds) -> AsyncIterator[tuple[str, Usage | None]]:
        self.stream_calls.append(config.provider_model)
        yield "无终态内容", None


class AbortOnceThenOk(FakeProvider):
    """第一次首块前静默断流（可重试），第二次正常带终态。"""

    def __init__(self) -> None:
        super().__init__()
        self.attempts = 0

    async def stream(self, config, messages, timeout_seconds) -> AsyncIterator[tuple[str, Usage | None]]:
        self.attempts += 1
        self.stream_calls.append(config.provider_model)
        if self.attempts == 1:
            return  # 无终态静默结束
        yield "恢复内容", None
        yield "", None


class ResponsesEmitThenBreak(FakeProvider):
    """Responses：已发事件后断流；备用若被调用即证明发生了切换。"""

    async def responses_stream(self, config, input_data, timeout_seconds, text=None):
        self.responses_calls.append(config.provider_model)
        if config.provider_model == "primary-model":
            try:
                yield (
                    "response.output_text.delta",
                    {"type": "response.output_text.delta", "delta": "第一段"},
                    None,
                )
                raise UpstreamTimeoutError("事件后断流")
            finally:
                self.responses_stream_closed += 1
        try:
            yield (
                "response.output_text.delta",
                {"type": "response.output_text.delta", "delta": "备用"},
                None,
            )
            completed = {
                "type": "response.completed",
                "response": {"id": "r1", "usage": {"input_tokens": 1, "output_tokens": 1}},
            }
            yield "response.completed", completed, Usage(input_tokens=1, output_tokens=1)
        finally:
            self.responses_stream_closed += 1


class ResponsesNoCompleted(FakeProvider):
    """Responses：只发增量事件，不发 response.completed。"""

    async def responses_stream(self, config, input_data, timeout_seconds, text=None):
        self.responses_calls.append(config.provider_model)
        yield (
            "response.output_text.delta",
            {"type": "response.output_text.delta", "delta": "无终态"},
            None,
        )


async def _read_sse(res):
    """收集 SSE 数据行：返回 (deltas, 是否错误事件, 是否 [DONE])。"""
    deltas: list[str] = []
    saw_error = None
    done = False
    async for line in res.aiter_lines():
        if line == "data: [DONE]":
            done = True
            continue
        if not line.startswith("data: "):
            continue
        payload = json.loads(line[6:])
        if "error" in payload:
            saw_error = payload["error"].get("code")
            continue
        choices = payload.get("choices")
        if choices:
            delta = choices[0]["delta"].get("content")
            if delta:
                deltas.append(delta)
    return deltas, saw_error, done


async def test_chat_post_emit_break_does_not_switch_backup(client, app):
    # 已输出内容后断流：不切备用模型，直接流内错误事件，客户端不收到重复内容
    provider = EmitThenBreak()
    app.state.ctx.provider = provider
    async with client.stream(
        "POST",
        "/v1/chat/completions",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "hi"}], "stream": True},
    ) as res:
        deltas, saw_error, done = await _read_sse(res)
    assert provider.stream_calls == ["primary-model"]  # 备用模型从未被调用
    assert deltas == ["第一段"]
    assert saw_error == "upstream_stream_failed"
    assert not done
    traces = app.state.ctx.traces.list()
    assert traces[-1].status == "failed"
    assert traces[-1].error_code == "upstream_stream_failed"


async def test_chat_silent_end_without_terminal_is_failure(client, app):
    # 上游无成功终态地结束：不宣告成功、不发 [DONE]，按失败处理
    app.state.ctx.provider = SilentEndStream()
    async with client.stream(
        "POST",
        "/v1/chat/completions",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "hi"}], "stream": True},
    ) as res:
        deltas, saw_error, done = await _read_sse(res)
    assert deltas == ["无终态内容"]
    assert saw_error == "upstream_stream_failed"
    assert not done
    traces = app.state.ctx.traces.list()
    assert traces[-1].status == "failed"


async def test_chat_silent_end_before_first_delta_retries(client, app):
    # 首块前静默断流属于可重试故障：退避重试后带终态成功
    provider = AbortOnceThenOk()
    app.state.ctx.provider = provider
    async with client.stream(
        "POST",
        "/v1/chat/completions",
        json={"model": "general-primary", "messages": [{"role": "user", "content": "hi"}], "stream": True},
    ) as res:
        deltas, saw_error, done = await _read_sse(res)
    assert deltas == ["恢复内容"]
    assert saw_error is None
    assert done
    assert provider.stream_calls == ["primary-model", "primary-model"]
    traces = app.state.ctx.traces.list()
    assert traces[-1].status == "success"
    assert traces[-1].attempts == 2


async def test_responses_post_emit_break_does_not_switch_backup(client, app):
    # Responses：已发事件后断流不切备用，直接流内 error 事件
    provider = ResponsesEmitThenBreak()
    app.state.ctx.provider = provider
    events: list[str] = []
    async with client.stream(
        "POST",
        "/v1/responses",
        json={"model": "general-primary", "input": "hi", "stream": True},
    ) as res:
        async for line in res.aiter_lines():
            if line.startswith("event: "):
                events.append(line)
    assert provider.responses_calls == ["primary-model"]
    assert events == ["event: response.output_text.delta", "event: error"]
    traces = app.state.ctx.traces.list()
    assert traces[-1].status == "failed"


async def test_responses_without_completed_terminal_is_failure(client, app):
    # Responses 未收到 response.completed：视为失败而非成功
    app.state.ctx.provider = ResponsesNoCompleted()
    events: list[str] = []
    async with client.stream(
        "POST",
        "/v1/responses",
        json={"model": "general-primary", "input": "hi", "stream": True},
    ) as res:
        async for line in res.aiter_lines():
            if line.startswith("event: "):
                events.append(line)
    assert events == ["event: response.output_text.delta", "event: error"]
    traces = app.state.ctx.traces.list()
    assert traces[-1].status == "failed"
    assert traces[-1].error_code == "upstream_stream_failed"
