"""Extra rechecks: stream failure usage, quota recovery, gated SSE, fence, max_tokens drop."""
import asyncio, json, sys, time
from pathlib import Path
sys.path.insert(0, "/home/user/workspace/repo/.amp/in/orb-backup/mini-llm-gateway")
import httpx
from app.config import RateLimitConfig
from app.errors import UpstreamConnectionError
from app.main import create_app
from app.schemas import Usage

# reuse helpers by exec? keep local copies small
exec(open("/home/user/workspace/repo/.amp/in/orb-backup/grading-scripts/recheck_week01.py").read().split("async def main")[0])

async def extra():
    root = Path("/tmp/grading-run/recheck-extra")
    root.mkdir(parents=True, exist_ok=True)

    # 1 stream failure after content drops known usage
    provider = ScriptedStreamProvider({
        "upstream-pro": [[("已经输出", Usage(input_tokens=9, output_tokens=4, reasoning_tokens=3)), UpstreamConnectionError("cut")]],
        "upstream-flash": [[("no", None), ("", None)]],
    })
    cfg = make_config(root / "su")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r = await post(app, "/v1/llm/stream", {"model": "model-a", "messages": [{"role": "user", "content": "hi"}]})
    t = app.state.ctx.traces.list()[-1]
    print("STREAM_FAIL_USAGE", r.status_code, t.status, t.error_code, "in", t.input_tokens, "out", t.output_tokens, "reason", t.reasoning_tokens, "unknown", t.usage_unknown, "body_has_delta", "已经输出" in r.text)

    # 2 quota recovery
    provider = RecordingProvider()
    cfg = make_config(root / "rec", primary_limit=RateLimitConfig(capacity=1, refill_per_second=5))
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r1 = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "1"}]})
    r2 = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "2"}]})
    await asyncio.sleep(0.25)
    r3 = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "3"}]})
    print("QUOTA_RECOVERY", r1.status_code, r2.status_code, r3.status_code)

    # 3 gated incremental SSE
    class Gated:
        def __init__(self):
            self.calls = []
        async def complete(self, *a, **k):
            raise RuntimeError("no")
        async def stream(self, config, messages, timeout_seconds):
            self.calls.append(config.provider_model)
            yield "第一块", None
            await asyncio.sleep(0.4)
            yield "第二块", Usage(input_tokens=2, output_tokens=2)
            yield "", None
        async def responses(self, *a, **k):
            raise RuntimeError("no")
        async def responses_stream(self, *a, **k):
            if False:
                yield "", {}, None
    gated = Gated()
    cfg = make_config(root / "gate")
    app = create_app(cfg)
    app.state.ctx.provider = gated
    transport = httpx.ASGITransport(app=app)
    times = []
    async with httpx.AsyncClient(transport=transport, base_url="http://gw") as client:
        async with client.stream("POST", "/v1/llm/stream", json={"model": "model-a", "messages": [{"role": "user", "content": "hi"}]}, headers={"Authorization": "Bearer sk-test"}) as resp:
            t0 = time.perf_counter()
            buf = ""
            async for chunk in resp.aiter_text():
                buf += chunk
                while "\n\n" in buf:
                    block, buf = buf.split("\n\n", 1)
                    times.append((round((time.perf_counter()-t0)*1000), block[:80]))
    print("GATED", times)

    # 4 fenced JSON success path
    provider = RecordingProvider()
    provider.complete_script = {"upstream-pro": [{"content": "```json\n{\"answer\":\"ok\"}\n```"}]}
    cfg = make_config(root / "fence", repair=0)
    # no fallback so we see primary result
    cfg.models["model-a"] = replace(cfg.models["model-a"], fallback=())
    app = create_app(cfg)
    app.state.ctx.provider = provider
    schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
    r = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "json"}], "response_schema": schema})
    print("FENCE", r.status_code, r.text[:250])

    # 5 max_tokens dropped on live chat? local
    provider = RecordingProvider()
    cfg = make_config(root / "drop")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r = await post(app, "/v1/chat/completions", {"model": "model-a", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 16, "temperature": 0})
    print("DROPPED", r.status_code, r.headers.get("x-gateway-dropped-params"), "calls", provider.calls)

asyncio.run(extra())
