"""Local gated upstream for SSE increment proof. No secrets."""
import os
from dataclasses import replace

from app.config import load_config
from app.main import create_app
import uvicorn

class Gated:
    async def complete(self, config, messages, timeout_seconds, response_schema):
        from app.schemas import Usage
        return "完成", Usage(input_tokens=1, output_tokens=1)

    async def stream(self, config, messages, timeout_seconds):
        import asyncio
        from app.schemas import Usage
        yield "第一块", None
        await asyncio.sleep(0.6)
        yield "第二块", Usage(input_tokens=2, output_tokens=2)
        yield "", None

    async def responses(self, config, input_data, timeout_seconds, text=None):
        from app.schemas import Usage
        return {"output": [{"type": "message", "content": [{"type": "output_text", "text": "完成"}]}]}, Usage(input_tokens=1, output_tokens=1)

    async def responses_stream(self, config, input_data, timeout_seconds, text=None):
        if False:
            yield "", {}, None

cfg = load_config("/tmp/grading-run/config.yaml")
# point traces away
cfg = replace(cfg, trace_file="/tmp/grading-run/gated-traces.jsonl", database_path="/tmp/grading-run/gated.db")
app = create_app(cfg)
app.state.ctx.provider = Gated()
uvicorn.run(app, host="127.0.0.1", port=int(os.environ.get("PORT", "8011")))
