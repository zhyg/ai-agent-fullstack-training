import asyncio, json, sys, time
from pathlib import Path
sys.path.insert(0, "/home/user/workspace/repo/.amp/in/orb-backup/mini-llm-gateway")
import httpx
from app.main import create_app

exec(open("/home/user/workspace/repo/.amp/in/orb-backup/grading-scripts/recheck_week01.py").read().split("async def main")[0])

async def extra():
    root = Path("/tmp/grading-run/recheck-extra2")
    root.mkdir(parents=True, exist_ok=True)

    class Gated:
        async def complete(self, *a, **k):
            raise RuntimeError("no")
        async def stream(self, config, messages, timeout_seconds):
            yield "第一块", None
            await asyncio.sleep(0.35)
            yield "第二块", Usage(input_tokens=2, output_tokens=2)
            yield "", None
        async def responses(self, *a, **k):
            raise RuntimeError("no")
        async def responses_stream(self, *a, **k):
            if False:
                yield "", {}, None

    cfg = make_config(root / "gate")
    app = create_app(cfg)
    app.state.ctx.provider = Gated()
    transport = httpx.ASGITransport(app=app)
    times = []
    async with httpx.AsyncClient(transport=transport, base_url="http://gw") as client:
        async with client.stream(
            "POST", "/v1/llm/stream",
            json={"model": "model-a", "messages": [{"role": "user", "content": "hi"}]},
            headers={"Authorization": "Bearer sk-test"},
        ) as resp:
            print("ctype", resp.headers.get("content-type"))
            t0 = time.perf_counter()
            buf = ""
            async for chunk in resp.aiter_text():
                now = round((time.perf_counter() - t0) * 1000)
                buf += chunk
                while "\n\n" in buf:
                    block, buf = buf.split("\n\n", 1)
                    times.append((now, block[:70].replace("\n", " ")))
    print("GATED_BYTE", times)
    t = app.state.ctx.traces.list()[-1]
    print("TTFT", t.first_token_ms, "lat", t.latency_ms)

    # responses stream: heartbeat / created event counts as first token
    class RespStream:
        async def complete(self, *a, **k):
            raise RuntimeError("no")
        async def stream(self, *a, **k):
            if False:
                yield "", None
        async def responses(self, *a, **k):
            raise RuntimeError("no")
        async def responses_stream(self, config, input_data, timeout_seconds, text=None):
            await asyncio.sleep(0.05)
            yield "response.created", {"type": "response.created"}, None
            await asyncio.sleep(0.3)
            yield "response.output_text.delta", {"type": "response.output_text.delta", "delta": "完成"}, Usage(input_tokens=3, output_tokens=1)
            yield "response.completed", {"type": "response.completed", "response": {"usage": {"input_tokens": 3, "output_tokens": 1}}}, Usage(input_tokens=3, output_tokens=1)

    cfg = make_config(root / "rs")
    app = create_app(cfg)
    app.state.ctx.provider = RespStream()
    from app.schemas import OpenAIResponsesRequest
    # call responses stream endpoint
    transport = httpx.ASGITransport(app=app)
    times = []
    async with httpx.AsyncClient(transport=transport, base_url="http://gw") as client:
        async with client.stream(
            "POST", "/v1/responses",
            json={"model": "model-a", "input": "hi", "stream": True},
            headers={"Authorization": "Bearer sk-test"},
        ) as resp:
            t0 = time.perf_counter()
            buf = ""
            async for chunk in resp.aiter_text():
                now = round((time.perf_counter() - t0) * 1000)
                buf += chunk
                while "\n\n" in buf:
                    block, buf = buf.split("\n\n", 1)
                    times.append((now, block.splitlines()[0][:60]))
    t = app.state.ctx.traces.list()[-1]
    print("RESP_STREAM_TIMES", times)
    print("RESP_TTFT", t.first_token_ms, "lat", t.latency_ms, "status", t.status)

    # responses missing completed after delta
    class RespNoTerm:
        async def complete(self, *a, **k):
            raise RuntimeError("no")
        async def stream(self, *a, **k):
            if False:
                yield "", None
        async def responses(self, *a, **k):
            raise RuntimeError("no")
        async def responses_stream(self, config, input_data, timeout_seconds, text=None):
            yield "response.output_text.delta", {"delta": "半截"}, Usage(input_tokens=8, output_tokens=2)
            return

    cfg = make_config(root / "rnt")
    app = create_app(cfg)
    app.state.ctx.provider = RespNoTerm()
    r = await post(app, "/v1/responses", {"model": "model-a", "input": "hi", "stream": True})
    t = app.state.ctx.traces.list()[-1]
    print("RESP_NO_TERM", r.status_code, "failed" in r.text, t.status, t.error_code, t.input_tokens, t.usage_unknown, r.text[:180].replace("\n"," | "))

asyncio.run(extra())
