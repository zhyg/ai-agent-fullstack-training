"""Independent recheck of first-submission defects. Does not modify student code."""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from collections.abc import AsyncIterator
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, "/home/user/workspace/repo/.amp/in/orb-backup/mini-llm-gateway")
os.chdir("/tmp/grading-run")

import httpx
from openai import APIStatusError

from app.config import CircuitBreakerConfig, GatewayConfig, ModelConfig, RateLimitConfig, RetryConfig
from app.errors import (
    ProviderError,
    UpstreamAuthError,
    UpstreamConnectionError,
    UpstreamInvalidRequestError,
    UpstreamRateLimitedError,
    UpstreamServerError,
)
from app.main import create_app
from app.schemas import Usage
from app.services.gateway import backoff_delay
from app.services.provider import OpenAICompatibleProvider, normalize_upstream_error

OUT = Path("/tmp/grading-run/recheck")
OUT.mkdir(parents=True, exist_ok=True)
results: list[dict] = []


def rec(name: str, ok: bool, detail: str, extra: dict | None = None) -> None:
    row = {"name": name, "ok": ok, "detail": detail, **(extra or {})}
    results.append(row)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")


class RecordingProvider:
    """Captures which provider method and payload each model uses."""

    def __init__(self) -> None:
        self.calls: list[dict] = []
        self.content = '{"answer":"ok"}'
        self.complete_script: dict[str, list] = {}
        self.stream_script: dict[str, list] = {}

    def _pop(self, script, key):
        items = script.get(key) or []
        if not items:
            return None
        return items.pop(0)

    async def complete(self, config, messages, timeout_seconds, response_schema):
        action = self._pop(self.complete_script, config.provider_model)
        self.calls.append(
            {
                "method": "complete",
                "protocol": config.protocol,
                "model": config.provider_model,
                "schema": response_schema,
                "messages": [m.model_dump() for m in messages],
                "action": type(action).__name__ if isinstance(action, Exception) else action,
            }
        )
        if isinstance(action, Exception):
            raise action
        usage = Usage(input_tokens=11, output_tokens=7, reasoning_tokens=2)
        if isinstance(action, dict) and "usage" in action:
            usage = action["usage"]
        content = self.content if not isinstance(action, dict) else action.get("content", self.content)
        return content, usage

    async def stream(self, config, messages, timeout_seconds):
        action = self._pop(self.stream_script, config.provider_model)
        self.calls.append({"method": "stream", "protocol": config.protocol, "model": config.provider_model})
        if isinstance(action, Exception):
            raise action
        events = action if isinstance(action, list) else [("A", Usage(input_tokens=3, output_tokens=1)), ("", None)]
        try:
            for delta, usage in events:
                yield delta, usage
        finally:
            self.calls.append({"method": "stream_closed", "model": config.provider_model})

    async def responses(self, config, input_data, timeout_seconds, text=None):
        self.calls.append(
            {
                "method": "responses",
                "protocol": config.protocol,
                "model": config.provider_model,
                "text": text,
                "input": input_data,
            }
        )
        payload = {
            "id": "resp_1",
            "object": "response",
            "model": config.provider_model,
            "output": [{"type": "message", "content": [{"type": "output_text", "text": self.content}]}],
            "usage": {"input_tokens": 5, "output_tokens": 3},
        }
        return payload, Usage(input_tokens=5, output_tokens=3)

    async def responses_stream(self, config, input_data, timeout_seconds, text=None):
        self.calls.append({"method": "responses_stream", "model": config.provider_model, "text": text})
        if False:
            yield "", {}, None


def make_config(tmp: Path, *, primary_protocol="responses", backup_protocol="chat", **kw) -> GatewayConfig:
    retry = kw.get("retry", RetryConfig(max_retries=1, backoff_base=0.01, jitter=0.0))
    breaker = CircuitBreakerConfig(failure_threshold=5, cooldown_seconds=30)
    primary = ModelConfig(
        provider_model="upstream-pro",
        base_url="https://api.deepseek.com",
        api_key_env="DEEPSEEK_API_KEY",
        supports_structured_output=True,
        structured_output_mode="json_object",
        protocol=primary_protocol,
        supports_responses=True,
        fallback=("model-b",),
        retry=retry,
        circuit_breaker=breaker,
        rate_limit=kw.get("primary_limit"),
        price_input=1.0,
        price_output=4.0,
    )
    backup = replace(
        primary,
        provider_model="upstream-flash",
        protocol=backup_protocol,
        fallback=(),
        rate_limit=kw.get("backup_limit"),
        price_input=0.8,
        price_output=3.2,
    )
    return GatewayConfig(
        auth_keys=("sk-test",),
        rate_limit_capacity=100,
        rate_limit_refill_per_second=100,
        trace_file=str(tmp / "traces.jsonl"),
        database_path=str(tmp / "gateway.db"),
        structured_output_repair_attempts=kw.get("repair", 2),
        run_budget=kw.get("run_budget", 12),
        models={"model-a": primary, "model-b": backup},
        prompts={},
    )


async def post(app, path, body):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://gw") as client:
        return await client.post(path, json=body, headers={"Authorization": "Bearer sk-test"})


async def case_protocol_by_model(tmp: Path) -> None:
    provider = RecordingProvider()
    cfg = make_config(tmp / "proto")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r1 = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "hi"}]})
    r2 = await post(app, "/v1/llm", {"model": "model-b", "messages": [{"role": "user", "content": "hi"}]})
    methods = [(c["model"], c["method"], c["protocol"]) for c in provider.calls]
    ok = (
        r1.status_code == 200
        and r2.status_code == 200
        and methods == [
            ("upstream-pro", "complete", "responses"),
            ("upstream-flash", "complete", "chat"),
        ]
    )
    rec(
        "unified-entry-protocol-by-model",
        ok,
        f"status {r1.status_code}/{r2.status_code} methods={methods}",
    )


class CapturingClient:
    def __init__(self) -> None:
        self.chat_calls = []
        self.responses_calls = []
        self.chat = self
        self.completions = self
        self.responses = self

    async def create(self, **kwargs):
        if "messages" in kwargs:
            self.chat_calls.append(kwargs)
            return _ChatCompletion()
        self.responses_calls.append(kwargs)
        return _ResponsesResult()


class _Msg:
    content = '{"answer":"ok"}'


class _Choice:
    message = _Msg()
    delta = type("D", (), {"content": "x"})()


class _Usage:
    prompt_tokens = 4
    completion_tokens = 2
    prompt_tokens_details = None
    completion_tokens_details = None


class _ChatCompletion:
    choices = [_Choice()]
    usage = _Usage()


class _ResponsesResult:
    def model_dump(self, exclude_unset=True):
        return {
            "output": [{"type": "message", "content": [{"type": "output_text", "text": '{"answer":"ok"}'}]}],
            "usage": {"input_tokens": 4, "output_tokens": 2},
        }


def case_adapter_sends_different_paths() -> None:
    client = CapturingClient()
    provider = OpenAICompatibleProvider()
    provider.create_client = lambda config: client  # type: ignore
    schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
    from app.schemas import Message

    chat_cfg = ModelConfig(
        provider_model="deepseek-flash",
        base_url="https://api.deepseek.com",
        api_key_env="DEEPSEEK_API_KEY",
        protocol="chat",
        structured_output_mode="json_object",
    )
    resp_cfg = replace(chat_cfg, provider_model="deepseek-v4-pro", protocol="responses")
    msgs = [Message(role="user", content="返回 JSON")]

    async def run():
        await provider.complete(resp_cfg, msgs, 10, schema)
        await provider.complete(chat_cfg, msgs, 10, schema)

    asyncio.get_event_loop().run_until_complete(run()) if False else None
    # caller awaits
    return client, provider, resp_cfg, chat_cfg, msgs, schema


async def case_adapter_paths() -> None:
    client = CapturingClient()
    provider = OpenAICompatibleProvider()
    provider.create_client = lambda config: client  # type: ignore
    schema = {"type": "object"}
    from app.schemas import Message

    chat_cfg = ModelConfig(
        provider_model="deepseek-flash",
        base_url="https://api.deepseek.com",
        api_key_env="DEEPSEEK_API_KEY",
        protocol="chat",
        structured_output_mode="json_object",
    )
    resp_cfg = replace(chat_cfg, provider_model="deepseek-v4-pro", protocol="responses")
    msgs = [Message(role="user", content="返回 JSON")]
    await provider.complete(resp_cfg, msgs, 10, schema)
    await provider.complete(chat_cfg, msgs, 10, schema)
    ok = (
        len(client.responses_calls) == 1
        and len(client.chat_calls) == 1
        and "text" in client.responses_calls[0]
        and client.responses_calls[0]["text"]["format"]["type"] == "json_object"
        and client.chat_calls[0]["response_format"] == {"type": "json_object"}
        and "messages" not in client.responses_calls[0]
        and "input" not in client.chat_calls[0]
    )
    rec(
        "adapters-send-different-protocols",
        ok,
        f"responses_keys={sorted(client.responses_calls[0])} chat_keys={sorted(client.chat_calls[0])}",
    )


async def case_empty_and_invalid_json(tmp: Path) -> None:
    provider = RecordingProvider()
    provider.complete_script = {
        "upstream-pro": [{"content": ""}, {"content": "not-json"}, {"content": '{"answer":'}],
        "upstream-flash": [{"content": "still-bad"}, {"content": "also-bad"}, {"content": "{"}],
    }
    cfg = make_config(tmp / "json", repair=0)
    app = create_app(cfg)
    app.state.ctx.provider = provider
    schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
    statuses = []
    codes = []
    for content_label in ("empty", "illegal", "truncated"):
        r = await post(
            app,
            "/v1/llm",
            {
                "model": "model-a",
                "messages": [{"role": "user", "content": content_label}],
                "response_schema": schema,
            },
        )
        statuses.append(r.status_code)
        body = r.json()
        codes.append(body.get("detail", body.get("error", {})).get("code") if isinstance(body, dict) else None)
    # empty should not 500
    no_500 = all(s != 500 for s in statuses)
    traces = app.state.ctx.traces.list()
    rec(
        "structured-empty-illegal-truncated-not-success",
        no_500 and all(s in (400, 502) for s in statuses) and all(c == "invalid_json" for c in codes),
        f"statuses={statuses} codes={codes} traces={[(t.status, t.error_code, t.input_tokens) for t in traces[-3:]]}",
    )


async def case_responses_ignores_format(tmp: Path) -> None:
    provider = RecordingProvider()
    provider.content = "not json at all"
    cfg = make_config(tmp / "respfmt")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r = await post(
        app,
        "/v1/responses",
        {
            "model": "model-a",
            "input": "返回 JSON",
            "text": {"format": {"type": "json_object"}},
        },
    )
    body = r.json()
    code = None
    if isinstance(body, dict):
        code = (body.get("error") or {}).get("code") or (body.get("detail") or {}).get("code")
    text_forwarded = any(c.get("text") for c in provider.calls if c["method"] == "responses")
    rec(
        "responses-text-format-rejects-illegal-json",
        r.status_code != 200 and code == "invalid_json",
        f"status={r.status_code} code={code} forwarded={text_forwarded} calls={len(provider.calls)}",
    )


class _StreamBreak:
    def __init__(self, events):
        self.events = events
        self.closed = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self.events:
            raise StopAsyncIteration
        item = self.events.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    async def aclose(self):
        self.closed = True


class ScriptedStreamProvider(RecordingProvider):
    def __init__(self, sequences):
        super().__init__()
        self.sequences = sequences  # provider_model -> list of sequences

    async def stream(self, config, messages, timeout_seconds):
        seq = self.sequences[config.provider_model].pop(0)
        self.calls.append({"method": "stream", "model": config.provider_model})
        emitted_terminal = False
        try:
            for item in seq:
                if isinstance(item, Exception):
                    raise item
                delta, usage = item
                if delta == "" and not isinstance(item, Exception):
                    emitted_terminal = True
                yield delta, usage
            if not emitted_terminal:
                return
        finally:
            self.calls.append({"method": "closed", "model": config.provider_model})


async def case_post_output_no_fallback(tmp: Path) -> None:
    provider = ScriptedStreamProvider(
        {
            "upstream-pro": [[("已经输出", Usage(input_tokens=4, output_tokens=2)), UpstreamConnectionError("cut")]],
            "upstream-flash": [[("备用不该出现", None), ("", None)]],
        }
    )
    cfg = make_config(tmp / "dup")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r = await post(app, "/v1/llm/stream", {"model": "model-a", "messages": [{"role": "user", "content": "hi"}]})
    text = r.text
    models = [c["model"] for c in provider.calls if c["method"] == "stream"]
    ok = "已经输出" in text and "备用不该出现" not in text and models == ["upstream-pro"] and "response.failed" in text
    rec("post-output-no-fallback-repeat", ok, f"models={models} body={text[:300]!r}")


async def case_eof_without_terminal(tmp: Path) -> None:
    provider = ScriptedStreamProvider(
        {
            "upstream-pro": [[("半截", Usage(input_tokens=2, output_tokens=1))]],  # no empty terminal
            "upstream-flash": [[("不该成功", None), ("", None)]],
        }
    )
    cfg = make_config(tmp / "eof")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r = await post(app, "/v1/llm/stream", {"model": "model-a", "messages": [{"role": "user", "content": "hi"}]})
    text = r.text
    traces = app.state.ctx.traces.list()
    failed = any(t.status == "failed" for t in traces)
    success_event = "response.completed" in text
    rec(
        "eof-without-terminal-is-failure",
        (not success_event) and "response.failed" in text and failed and "不该成功" not in text,
        f"status={r.status_code} completed={success_event} failed_event={'response.failed' in text} traces={[(t.status, t.error_code) for t in traces]} body={text[:250]!r}",
    )


async def case_usage_accounting(tmp: Path) -> None:
    provider = RecordingProvider()
    provider.complete_script = {
        "upstream-pro": [
            {"content": "not-json", "usage": Usage(input_tokens=10, output_tokens=3)},
            {"content": '{"answer":"ok"}', "usage": Usage(input_tokens=8, output_tokens=4)},
        ]
    }
    cfg = make_config(tmp / "usage", repair=2)
    app = create_app(cfg)
    app.state.ctx.provider = provider
    schema = {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]}
    r = await post(
        app,
        "/v1/llm",
        {"model": "model-a", "messages": [{"role": "user", "content": "json"}], "response_schema": schema},
    )
    traces = app.state.ctx.traces.list()
    t = traces[-1]
    body = r.json()
    accumulated = t.input_tokens == 18 and t.output_tokens == 7
    response_last_only = body.get("usage", {}).get("input_tokens") == 8
    rec(
        "repair-success-accumulates-known-usage",
        r.status_code == 200 and accumulated,
        f"status={r.status_code} trace_in={t.input_tokens} trace_out={t.output_tokens} response_in={body.get('usage')} unknown={t.usage_unknown}",
        {"response_reports_last_attempt_only": response_last_only},
    )

    provider2 = RecordingProvider()
    provider2.complete_script = {
        "upstream-pro": [{"content": "bad", "usage": Usage(input_tokens=9, output_tokens=2)}],
        "upstream-flash": [UpstreamAuthError("no")],
    }
    cfg2 = make_config(tmp / "usage2", repair=0)
    app2 = create_app(cfg2)
    app2.state.ctx.provider = provider2
    r2 = await post(
        app2,
        "/v1/llm",
        {"model": "model-a", "messages": [{"role": "user", "content": "json"}], "response_schema": schema},
    )
    t2 = app2.state.ctx.traces.list()[-1]
    rec(
        "validation-failure-keeps-known-usage",
        r2.status_code != 200 and t2.input_tokens == 9 and t2.output_tokens == 2 and t2.usage_unknown is True,
        f"status={r2.status_code} code={r2.json().get('detail',{}).get('code')} in={t2.input_tokens} out={t2.output_tokens} unknown={t2.usage_unknown} status_trace={t2.status}",
    )

    r3 = await post(app2, "/v1/llm", {"model": "missing", "messages": [{"role": "user", "content": "x"}]})
    traces3 = app2.state.ctx.traces.list()
    entry = [t for t in traces3 if t.requested_model == "missing"]
    rec(
        "entry-failure-audited",
        r3.status_code == 400 and len(entry) == 1 and entry[0].status == "failed" and entry[0].error_code == "unknown_model",
        f"status={r3.status_code} entry={[(t.error_code, t.attempts, t.status) for t in entry]}",
    )


def case_error_mapping() -> None:
    class FakeResp:
        request = None
        headers = {}

        def __init__(self, code):
            self.status_code = code

    mapped = {}
    for code in (400, 401, 429, 500, 502):
        exc = APIStatusError("x", response=FakeResp(code), body=None)
        norm = normalize_upstream_error(exc)
        mapped[code] = (type(norm).__name__, norm.code, norm.retryable)
    rec(
        "normalize-400-401-429-5xx",
        mapped[400][1] == "upstream_invalid_request"
        and mapped[401][1] == "upstream_auth_failed"
        and mapped[429][1] == "upstream_rate_limited"
        and mapped[429][2] is True
        and mapped[500][1] == "upstream_server_error"
        and mapped[400][2] is False
        and mapped[401][2] is False,
        str(mapped),
    )


async def case_terminal_status_distinct(tmp: Path) -> None:
    outcomes = {}
    for label, err in (
        ("400", UpstreamInvalidRequestError("bad")),
        ("401", UpstreamAuthError("auth")),
        ("429", UpstreamRateLimitedError("slow")),
    ):
        provider = RecordingProvider()
        provider.complete_script = {
            "upstream-pro": [err, err, err],
            "upstream-flash": [err, err, err],
        }
        retry = RetryConfig(max_retries=2, backoff_base=0.0, jitter=0.0)
        cfg = make_config(tmp / label, retry=retry)
        app = create_app(cfg)
        app.state.ctx.provider = provider
        t0 = time.perf_counter()
        r = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "x"}]})
        body = r.json()
        outcomes[label] = {
            "status": r.status_code,
            "code": body.get("detail", {}).get("code"),
            "calls": len(provider.calls),
            "ms": round((time.perf_counter() - t0) * 1000),
        }
    distinct = {outcomes[k]["code"] for k in outcomes} == {
        "upstream_invalid_request",
        "upstream_auth_failed",
        "upstream_rate_limited",
    }
    no_retry_4xx = outcomes["400"]["calls"] == 2 and outcomes["401"]["calls"] == 2  # one per model, no retry
    retry_429 = outcomes["429"]["calls"] == 6  # 1+2 retries each model
    rec(
        "upstream-errors-distinct-and-retry-policy",
        distinct and no_retry_4xx and retry_429 and outcomes["400"]["status"] == 400 and outcomes["429"]["status"] == 429,
        json.dumps(outcomes, ensure_ascii=False),
    )


async def case_rate_limit_independent(tmp: Path) -> None:
    provider = RecordingProvider()
    cfg = make_config(
        tmp / "rl",
        primary_limit=RateLimitConfig(capacity=1, refill_per_second=0),
        backup_limit=RateLimitConfig(capacity=5, refill_per_second=1),
    )
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r1 = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "1"}]})
    r2 = await post(app, "/v1/llm", {"model": "model-a", "messages": [{"role": "user", "content": "2"}]})
    r3 = await post(app, "/v1/llm", {"model": "model-b", "messages": [{"role": "user", "content": "3"}]})
    rec(
        "model-independent-429",
        r1.status_code == 200 and r2.status_code == 429 and r3.status_code == 200,
        f"A1={r1.status_code} A2={r2.status_code} body2={r2.text[:180]} B={r3.status_code}",
    )


def case_backoff_formula() -> None:
    cfg = ModelConfig(
        provider_model="m",
        base_url="https://x",
        api_key_env="K",
        retry=RetryConfig(max_retries=3, backoff_base=0.5, jitter=0.1),
    )
    samples = []
    over = 0
    for attempt in range(3):
        cap = 0.5 * (2**attempt)
        waits = [backoff_delay(attempt, cfg) for _ in range(200)]
        mx = max(waits)
        if mx > cap + 1e-9:
            over += 1
        samples.append({"attempt": attempt, "cap": cap, "min": min(waits), "max": mx})
    rec(
        "backoff-positive-jitter-can-exceed-cap",
        over > 0,
        json.dumps(samples),
    )


class HeartbeatProvider(RecordingProvider):
    async def stream(self, config, messages, timeout_seconds):
        self.calls.append({"method": "stream", "model": config.provider_model})
        yield "", None  # empty / heartbeat-like before content
        yield "正文", Usage(input_tokens=1, output_tokens=1)
        yield "", None


async def case_ttft_empty_delta(tmp: Path) -> None:
    provider = HeartbeatProvider()
    cfg = make_config(tmp / "ttft")
    app = create_app(cfg)
    app.state.ctx.provider = provider
    r = await post(app, "/v1/llm/stream", {"model": "model-a", "messages": [{"role": "user", "content": "hi"}]})
    t = app.state.ctx.traces.list()[-1]
    empty_as_delta = '"delta": ""' in r.text or '"delta":""' in r.text
    rec(
        "empty-delta-not-first-token",
        r.status_code == 200 and "正文" in r.text and t.first_token_ms is not None and not empty_as_delta,
        f"ttft={t.first_token_ms} status={t.status} empty_delta_forwarded={empty_as_delta} body={r.text[:220]!r}",
    )


async def case_prompt_live() -> None:
    # uses running server
    import urllib.request

    def req(path, body):
        r = urllib.request.Request(
            "http://127.0.0.1:8000" + path,
            data=json.dumps(body).encode(),
            headers={"Authorization": "Bearer sk-gateway-demo", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(r, timeout=40) as resp:
                return resp.status, resp.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    import urllib.error

    s1, b1 = req(
        "/v1/prompts",
        {"id": "grade_probe", "content": "只回复：{{ product_name }}-{{ word }}", "activate": True},
    )
    s2, b2 = req(
        "/v1/prompts",
        {"id": "grade_probe", "content": "新版本只回复：{{ product_name }}", "activate": True},
    )
    s3, b3 = req(
        "/v1/llm",
        {
            "model": "general-backup",
            "messages": [{"role": "user", "content": "按系统指令回复"}],
            "prompt": {"name": "grade_probe", "version": "1", "variables": {"product_name": "差旅", "word": "完成"}},
            "timeout_seconds": 40,
        },
    )
    s4, b4 = req(
        "/v1/llm",
        {
            "model": "general-backup",
            "messages": [{"role": "user", "content": "x"}],
            "prompt": {"name": "missing_tpl", "version": "v9", "variables": {}},
        },
    )
    s5, b5 = req(
        "/v1/llm",
        {
            "model": "general-backup",
            "messages": [{"role": "user", "content": "x"}],
            "prompt": {"name": "knowledge_decision", "version": "v1", "variables": {}},
        },
    )
    rec("prompt-v1-v2-and-missing", s1 == 200 and s2 == 200 and s3 == 200 and "差旅" in b3 and "完成" in b3, f"create={s1}/{s2} oldver={s3} body={b3[:180]} missing={s4} {b4[:120]} yaml_missing_var={s5} {b5[:160]}")


async def case_chat_response_format_rejected_or_mapped() -> None:
    # native /v1/llm has no response_format field
    import urllib.request, urllib.error

    def req(body):
        r = urllib.request.Request(
            "http://127.0.0.1:8000/v1/llm",
            data=json.dumps(body).encode(),
            headers={"Authorization": "Bearer sk-gateway-demo", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(r, timeout=20) as resp:
                return resp.status, resp.read().decode()[:200]
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()[:300]

    status, body = req(
        {
            "model": "general-backup",
            "messages": [{"role": "user", "content": "hi"}],
            "response_format": {"type": "json_object"},
        }
    )
    rec("native-entry-rejects-response_format-field", status in (400, 422), f"status={status} body={body}")


async def main() -> None:
    root = Path("/tmp/grading-run/recheck-tmp")
    root.mkdir(exist_ok=True)
    await case_protocol_by_model(root)
    await case_adapter_paths()
    await case_empty_and_invalid_json(root)
    await case_responses_ignores_format(root)
    await case_post_output_no_fallback(root)
    await case_eof_without_terminal(root)
    await case_usage_accounting(root)
    case_error_mapping()
    await case_terminal_status_distinct(root)
    await case_rate_limit_independent(root)
    case_backoff_formula()
    await case_ttft_empty_delta(root)
    await case_prompt_live()
    await case_chat_response_format_rejected_or_mapped()
    (OUT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print("WROTE", OUT / "results.json", "fails", sum(1 for r in results if not r["ok"]))


if __name__ == "__main__":
    asyncio.run(main())
