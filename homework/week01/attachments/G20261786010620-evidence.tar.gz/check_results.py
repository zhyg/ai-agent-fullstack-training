"""Assert recorded observations, not an acceptance-pass test suite."""
import json
from pathlib import Path

root = Path(__file__).parent
rows = [json.loads(s) for s in (root/'controlled.jsonl').read_text().splitlines()]
by = {r['case']: r for r in rows}
assert all(by['A03 protocol '+m]['upstream_calls'][0]['path']=='/v1/chat/completions' for m in ['DeepSeek-V4-Pro','DeepSeek-V4.1-Flash'])
assert by['A04 unknown']['status']==404 and not by['A04 unknown']['upstream_calls']
for r in rows:
    if 'gated SSE' in r['case']:
        assert r['status']==400 and r['upstream_calls']==[]
for text in ['not json', '', '{"ok":', '{"ok":"wrong-type"}']:
    assert by['F04 '+repr(text)]['status']==502
assert by['F04 OpenAI wrapper wrong type']['status']==200
assert by['F12 README curl semantic payload']['status']==422
assert by['F06 unknown template']['status']==400
assert by['F06 missing variable']['upstream_calls'][0]['body']['messages'][0]['content']=='请回答用户的问题：'
retry=by['F08 first two fail third succeeds via fallback']
assert retry['status']==200 and len(retry['upstream_calls'])==3
assert [c['body']['model'] for c in retry['upstream_calls']]==['deepseek-v4-pro','deepseek-v4-pro','deepseek-flash']
for status in [500,429,400,401]:
    r=by['F08/F09 upstream '+str(status)]
    assert r['status']==502 and len(r['upstream_calls'])==4
    gaps=[b['time']-a['time'] for a,b in zip(r['upstream_calls'],r['upstream_calls'][1:])]
    print('controlled status',status,'requests=4 (2/model), inter-request seconds=',gaps)
assert by['F09 connection error']['status']==500
assert by['F08/F09 upstream 500']['trace_count']==by['F06 missing variable']['trace_count']
assert set(by['F07 final status inventory']['statuses'])=={'success'}
assert all(v==[200]*25 for v in by['F10/F11']['statuses'].values())
real=[json.loads(s) for s in (root/'real.jsonl').read_text().splitlines()]
assert sum(r.get('status')==200 for r in real)==2
assert sum(r.get('status')==400 for r in real)==2
assert sum(r.get('status')==502 for r in real)==4
print('Observation assertions passed; this is NOT full acceptance.')
print('Score: 11+0+5+8+12+6+0+4 =',sum([11,0,5,8,12,6,0,4]))
