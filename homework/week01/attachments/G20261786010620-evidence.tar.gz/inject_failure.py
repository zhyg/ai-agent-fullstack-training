"""F12: controlled failure in the student's mocked upstream, no source edits."""
import httpx
import pytest

@pytest.fixture(autouse=True)
def controlled_upstream_failure(monkeypatch):
    async def failed(self, request):
        return httpx.Response(500, json={'error': {'message': 'teacher F12 injected upstream failure'}})
    monkeypatch.setattr(httpx.MockTransport, 'handle_async_request', failed)
