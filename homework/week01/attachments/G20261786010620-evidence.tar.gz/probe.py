"""Diagnostic only: run original API body without its missing type-only import.
Not a repair, startup success, nor a substitute for end-to-end acceptance.
Run from student cwd with ../venv/bin/python ../evidence/probe.py [real].
No credentials, request headers or databases are written to evidence.
"""
import ast
import asyncio
import json
import os
import sys
import time
from pathlib import Path
import httpx
from llmgateway.config import load_config
from llmgateway.providers.openai_compat import OpenAICompatProvider
from llmgateway.tracing.store import TraceStore

tree = ast.parse(Path('llmgateway/api.py').read_text())
tree.body = [n for n in tree.body if not (isinstance(n, ast.ImportFrom) and n.module == 'llmgateway.keystore')]
ns = {'ApiKeyStore': object, '__name__': 'diagnostic_api'}
exec(compile(tree, 'llmgateway/api.py', 'exec'), ns)

def emit(label, **data):
    print(json.dumps({'case': label, **data}, ensure_ascii=False), flush=True)

class Keys:
    def get(self, name):
        return None
    def has(self, name):
        return False

async def main():
    real = 'real' in sys.argv
    cfg = load_config('config.yaml')
    names = list(cfg.models)
    calls = []
    mode = {'status': 200, 'content': '{"ok":true}', 'finish': 'stop', 'fail_remaining': 0, 'network_error': False}
    async def handler(req):
        body = json.loads(req.content)
        calls.append({'time': time.monotonic(), 'path': req.url.path, 'body': body})
        if mode['network_error']:
            raise httpx.ConnectError('controlled connection error', request=req)
        if mode['fail_remaining']:
            mode['fail_remaining'] -= 1
            return httpx.Response(500, json={'error': {'message': 'controlled transient failure'}})
        if mode['status'] >= 400:
            return httpx.Response(mode['status'], json={'error': {'message': 'controlled failure'}})
        return httpx.Response(200, json={'choices': [{'message': {'content': mode['content']}, 'finish_reason': mode['finish']}], 'usage': {'prompt_tokens': 11, 'completion_tokens': 7, 'total_tokens': 18, 'prompt_cache_hit_tokens': 3, 'prompt_cache_miss_tokens': 8, 'completion_tokens_details': {'reasoning_tokens': 2}}})
    if real:
        key = os.environ.get('DEEPSEEK_API_KEY')
        if not key:
            emit('real', status='unverified: missing DEEPSEEK_API_KEY')
            return
        for m in cfg.models.values():
            assert m.base_url == 'https://api.deepseek.com/v1'
            m.fallback = []
        provider = OpenAICompatProvider(timeout=45, api_key_resolver=lambda name: key)
    else:
        provider = OpenAICompatProvider(transport=httpx.MockTransport(handler))
    store = TraceStore(':memory:')
    app = ns['create_app'](cfg, store, provider, Keys())
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app, raise_app_exceptions=False), base_url='http://diagnostic') as client:
        async def post(label, **overrides):
            payload = {'model': names[0], 'messages': [{'role': 'user', 'content': 'Return only JSON {"ok":true}.'}], 'max_tokens': 256}
            if real:
                payload['thinking'] = {'type': 'disabled'}
            payload.update(overrides)
            before = len(calls)
            t = time.monotonic()
            resp = await client.post('/v1/chat/completions', json=payload)
            try:
                result = resp.json()
            except ValueError:
                result = resp.text
            emit(label, status=resp.status_code, elapsed=round(time.monotonic()-t, 4), response=result, upstream_calls=calls[before:] if not real else 'not instrumented; provider has no SDK', trace_count=len(store.list(limit=10000)))
            return resp
        if real:
            for name in names:
                await post('REAL ordinary '+name, model=name)
                await post('REAL stream attempt '+name, model=name, stream=True)
                await post('REAL JSON '+name, model=name, response_format={'type':'json_schema','json_schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok']}})
                await post('REAL JSON OpenAI wrapper '+name, model=name, response_format={'type':'json_schema','json_schema':{'name':'check','strict':True,'schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}})
            emit('real traces', records=[t.model_dump() for t in store.list()])
        else:
            for name in names:
                await post('A03 protocol '+name, model=name)
                await post('F01/F02 gated SSE cannot enter upstream '+name, model=name, stream=True)
                await post('F03 valid JSON '+name, model=name, response_format={'type':'json_schema','json_schema':{'type':'object'}})
            curl_resp = await client.post('/v1/chat/completions', json={'model':names[0], 'template':'qa', 'variables':{'question':'什么是 LLM Gateway？'}})
            emit('F12 README curl semantic payload', status=curl_resp.status_code, response=curl_resp.json())
            await post('A04 unknown', model='missing')
            fmt={'type':'json_schema','json_schema':{'type':'object','required':['ok'],'properties':{'ok':{'type':'boolean'}}}}
            for text in ['not json', '', '{"ok":', '{"ok":"wrong-type"}']:
                mode['content'] = text
                await post('F04 '+repr(text), response_format=fmt)
            mode.update(content='{"ok":true}', finish='length')
            await post('F04 valid JSON but upstream length', response_format=fmt)
            mode['finish']='stop'
            await post('F05 v1 ignored', template='qa', variables={'question':'v1-marker'}, version='v1')
            await post('F05 nonexistent version ignored', template='qa', variables={'question':'v2-marker'}, version='does-not-exist')
            await post('F06 unknown template', template='missing')
            await post('F06 missing variable', template='qa', variables={})
            emit('F07 traces before failures', records=[t.model_dump() for t in store.list(limit=3)])
            for status in [500, 429, 400, 401]:
                mode['status']=status
                await post('F08/F09 upstream '+str(status))
            mode['status']=200
            mode['fail_remaining']=2
            await post('F08 first two fail third succeeds via fallback')
            mode['network_error']=True
            await post('F09 connection error')
            mode['network_error']=False
            mode['content']='{"ok":"wrong-type"}'
            await post('F04 OpenAI wrapper wrong type', response_format={'type':'json_schema','json_schema':{'name':'check','strict':True,'schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok']}}})
            mode['content']='{"ok":true}'
            # No rate-limit config exists. Burst both models then check again.
            counts={}
            for name in names:
                values=[]
                for _ in range(25):
                    resp=await client.post('/v1/chat/completions', json={'model':name,'messages':[{'role':'user','content':'rate probe'}]})
                    values.append(resp.status_code)
                counts[name]=values
            emit('F10/F11', statuses=counts, note='No limit/window setting or limiter exists; recovery is not applicable, not passed')
            emit('F07 final status inventory', statuses=[t.status for t in store.list(limit=10000)])
    await provider._client.aclose()

asyncio.run(main())
