     1	# AI Agent 全栈工程师训练营 · 作业一
     2	
     3	使用 **Python + FastAPI** 实现 LLM 统一调用服务。调用方使用相同请求格式，通过 `model` 选择两种不同协议：
     4	
     5	| 网关 model | 上游协议 | 默认上游地址 | 鉴权 |
     6	|---|---|---|---|
     7	| `deepseek-v4-pro` | OpenAI Responses | `https://api.deepseek.com/responses` | Bearer |
     8	| `deepseek-v4-flash` | Anthropic Messages | `https://api.deepseek.com/anthropic/v1/messages` | x-api-key |
     9	
    10	**模型版本说明（2026-10-27 核实）：** [DeepSeek 官方](https://api-docs.deepseek.com/quick_start/pricing/)仍接受 `deepseek-v4-flash`，但原 V4 Flash 已退役，由 V4.1 Flash 承接。这里保留题目的请求名称；`PRO_MODEL` / `FLASH_MODEL` 可以显式修改实际发送给上游的名称，`GET /v1/models` 可检查映射。官方服务现已无法用于验证原版 V4 Flash 权重。
    11	
    12	## 1. 安装与启动
    13	
    14	需要 Python 3.12+。推荐使用 [uv](https://docs.astral.sh/uv/)。
    15	
    16	```bash
    17	cd AI-Agent-Training/week-01
    18	uv sync --frozen
    19	cp .env.example .env
    20	```
    21	
    22	在本地编辑 `.env`，填写你自己的 `DEEPSEEK_API_KEY`。两个适配器使用同一个 DeepSeek 密钥，无需 OpenAI 或 Anthropic 平台密钥。`.env` 已被 Git 忽略，请勿把密钥放进请求、截图或验证报告。
    23	
    24	```bash
    25	uv run uvicorn gateway.app:app --host 127.0.0.1 --port 8000
    26	```
    27	
    28	- 接口文档：http://127.0.0.1:8000/docs
    29	- 健康检查：`curl http://127.0.0.1:8000/health`
    30	- 模型映射：`curl http://127.0.0.1:8000/v1/models`
    31	- SQLite：默认 `week-01/data/gateway.sqlite3`，首次启动自动创建并导入示例模板。
    32	
    33	没有密钥时可以启动和运行离线验收，但模型请求会明确返回 `503 PROVIDER_NOT_CONFIGURED`。
    34	
    35	也可不用 uv：
    36	
    37	```bash
    38	python3 -m venv .venv
    39	source .venv/bin/activate
    40	python -m pip install -e . pytest ruff
    41	python -m uvicorn gateway.app:app --host 127.0.0.1 --port 8000
    42	python scripts/verify.py
    43	```
    44	
    45	### 项目移动或改名后无法启动
    46	
    47	如果报错中的 Python 路径仍指向旧目录，原因是 `.venv/bin` 的启动脚本保存了创建环境时的绝对路径。请在当前 `week-01` 目录重建虚拟环境，再按锁文件恢复依赖：
    48	
    49	```bash
    50	uv venv --clear --python 3.12 .venv
    51	uv sync --frozen
    52	uv run uvicorn gateway.app:app --host 127.0.0.1 --port 8000
    53	```
    54	
    55	这只重建 `.venv`，保留源码、`.env` 和数据库；已有 `.env` 时无需重新复制示例文件。
    56	
    57	## 2. 统一接口
    58	
    59	`POST /v1/llm` 的主要字段：
    60	
    61	| 字段 | 含义 |
    62	|---|---|
    63	| `model` | 上表中的网关模型名，决定适配器 |
    64	| `messages` | `role` 为 system/user/assistant，`content` 为字符串 |
    65	| `prompt` | 模板引用：name、version、variables；可代替 messages |
    66	| `stream` | 默认 false；true 返回 SSE |
    67	| `response_format` | json_object 或 json_schema |
    68	| `max_tokens` | 统一输出上限，默认 1024，范围 1–16384 |
    69	| `temperature` | 默认 0.7，范围 0–2；思考模式下上游可能忽略 |
    70	
    71	模板消息会放在请求 messages 前面，合并后至少有一条 user 消息。未知字段、非法参数和非法 Schema 都返回统一错误。
    72	
    73	### 普通调用：两个模型
    74	
    75	```bash
    76	curl -sS http://127.0.0.1:8000/v1/llm \
    77	  -H 'Content-Type: application/json' \
    78	  -d '{"model":"deepseek-v4-pro","max_tokens":4096,"messages":[{"role":"user","content":"用一句话解释适配器模式。"}]}'
    79	
    80	curl -sS http://127.0.0.1:8000/v1/llm \
    81	  -H 'Content-Type: application/json' \
    82	  -d '{"model":"deepseek-v4-flash","max_tokens":4096,"messages":[{"role":"user","content":"用一句话解释适配器模式。"}]}'
    83	```
    84	
    85	响应包含 `request_id`、`model`、`protocol`、`content`、`parsed`、`usage`、`metrics`、`prompt` 和 `finish_reason`。普通文本的 `parsed` 为 null。请求 ID 也在 HTTP `X-Request-ID` 响应头中。
    86	
    87	### 流式输出
    88	
    89	```bash
    90	curl -N http://127.0.0.1:8000/v1/llm \
    91	  -H 'Content-Type: application/json' \
    92	  -d '{"model":"deepseek-v4-flash","stream":true,"max_tokens":4096,"messages":[{"role":"user","content":"用三句话解释 SSE。"}]}'
    93	```
    94	
    95	统一事件格式：
    96	
    97	```text
    98	event: content.delta
    99	data: {"type":"content.delta","request_id":"...","model":"deepseek-v4-flash","delta":"SSE"}
   100	
   101	event: response.completed
   102	data: {"type":"response.completed","request_id":"...","content":"SSE ...","usage":{...},"metrics":{...},...}
   103	```
   104	
   105	`response.completed` 是正常结束标记，不额外发送 `[DONE]`。思考文本不转发为用户答案。收到首个有效事件之前的错误保留 HTTP 4xx/5xx；已经发出文本之后的错误通过 `event: error` 返回，此时 HTTP 状态已是 200，客户端必须检查结束事件。缺少结束事件或达到输出上限都视为失败。用户断开时关闭上游连接，记录 cancelled。
   106	
   107	### JSON 与 JSON Schema
   108	
   109	两个模型都支持同一 `response_format`：
   110	
   111	```bash
   112	curl -sS http://127.0.0.1:8000/v1/llm \
   113	  -H 'Content-Type: application/json' \
   114	  -d '{"model":"deepseek-v4-pro","max_tokens":4096,"messages":[{"role":"user","content":"返回 JSON，包含 answer 字符串，解释 SSE。"}],"response_format":{"type":"json_object"}}'
   115	
   116	curl -sS http://127.0.0.1:8000/v1/llm \
   117	  -H 'Content-Type: application/json' \
   118	  -d '{"model":"deepseek-v4-flash","max_tokens":4096,"messages":[{"role":"user","content":"返回 JSON，answer 为字符串 OK。"}],"response_format":{"type":"json_schema","json_schema":{"name":"answer","schema":{"type":"object","properties":{"answer":{"type":"string"}},"required":["answer"],"additionalProperties":false}}}}'
   119	```
   120	
   121	- Responses：转换为上游 `text.format`，Schema 模式使用 `strict=true`。
   122	- Messages：DeepSeek 不支持 `output_config.format`，使用强制 `emit_json` 工具调用和 `input_schema`，并关闭思考模式以兼容强制工具选择。工具参数转换成 JSON 正文，无需实际执行工具。
   123	- 网关再次解析 JSON 并校验 Schema，成功响应的 `parsed` 一定合法；非法结果返回 `502 INVALID_STRUCTURED_OUTPUT`。
   124	- 为统一两个协议，Schema 顶层要求 `type: object`；只允许文档内 `$ref`，不请求远程 Schema。
   125	- `stream=true` 可与结构化输出组合：缓冲上游 JSON，校验后发送一个 `content.delta` 及完成事件。这样保留 SSE 接口，同时避免向用户输出无效 JSON；它不会逐字展示未验证的 JSON。
   126	
   127	### 提示词模板与版本
   128	
   129	内置 `explain/v1`（变量 topic）和 `explain/v2`（变量 topic、audience）。
   130	
   131	```bash
   132	curl -sS http://127.0.0.1:8000/v1/prompts
   133	
   134	curl -sS http://127.0.0.1:8000/v1/llm \
   135	  -H 'Content-Type: application/json' \
   136	  -d '{"model":"deepseek-v4-flash","max_tokens":4096,"prompt":{"name":"explain","version":"v2","variables":{"topic":"LLM Gateway","audience":"Python 初学者"}}}'
   137	
   138	curl -sS http://127.0.0.1:8000/v1/prompts \
   139	  -H 'Content-Type: application/json' \
   140	  -d '{"name":"review","version":"v1","messages":[{"role":"system","content":"你是代码审查员。"},{"role":"user","content":"解释 ${concept} 的常见错误。"}]}'
   141	
   142	curl -sS http://127.0.0.1:8000/v1/prompts/review/v1
   143	```
   144	
   145	占位符使用 `${name}`，字面量 `$` 写作 `$$`。变量必须是字符串，缺失、多余，或替换后消息为空/超过 200000 字符，均返回 `400 PROMPT_VARIABLE_ERROR`；替换不会执行表达式，也不会递归解释变量内容。name/version 唯一，已有版本不可覆盖，重复创建返回 `409 PROMPT_VERSION_EXISTS`；修改提示词须发布新版本。请求必须显式指定版本，避免 latest 漂移。模板保存在 SQLite，响应与审计中记录实际引用版本。
   146	
   147	## 3. 观测、重试与限流
   148	
   149	```bash
   150	curl -sS 'http://127.0.0.1:8000/v1/traces?limit=20&model=deepseek-v4-flash'
   151	curl -sS http://127.0.0.1:8000/v1/metrics
   152	```
   153	
   154	每次通过请求格式校验的模型调用（含失败、未知模型、模板错误、429、客户端取消）保存一条 trace；请求体格式错误在框架校验阶段返回 422，不进入模型调用审计。
   155	
   156	| 观测字段 | 定义 |
   157	|---|---|
   158	| `input_tokens` | 包含缓存命中的总输入量 |
   159	| `output_tokens` | 供应商报告的总输出量，可能包含 reasoning |
   160	| `total_tokens` | input + output，不能再叠加下面的分类量 |
   161	| `cache_read_tokens` / `cache_write_tokens` | 输入的缓存子分类 |
   162	| `reasoning_tokens` | 输出的思考子分类；上游不披露时为 null |
   163	| `reported` | 上游是否报告过用量；未报告时用 null，不假装是 0 |
   164	| `latency_ms` | 进入网关调用逻辑到最终处理结果的时间，包含重试和退避 |
   165	| `ttft_ms` | 流式为首个文本/工具参数增量耗时；不计算心跳或 reasoning |
   166	| `ttft_kind` | 流式 first_delta；非流式 response_complete，是完成耗时代理值 |
   167	| `attempt_details` | 每次尝试的用量、耗时、错误码、退避时间 |
   168	| `usage_complete` | 所有尝试是否都有完整 input/output，用量缺失时为 false |
   169	
   170	Anthropic `input_tokens` 不含缓存读写，因此归一化时加回；Responses `input_tokens` 已经包含缓存命中，不重复相加。Messages 的累计 `message_delta.usage` 覆盖前值，不逐块累加。分类口径见[官方缓存文档](https://platform.claude.com/docs/en/build-with-claude/prompt-caching)。
   171	
   172	单次成功响应的 `usage` 是最后成功尝试的用量；trace 的 `usage` 汇总每次尝试中**已知**的用量，避免漏记失败尝试已披露的消耗。聚合指标同时提供 `calls_with_unknown_usage`。供应商未报告的失败消耗无法精确还原。
   173	
   174	审计不保存用户消息、模板变量、生成正文和密钥。模板正文按功能需求存储在独立 prompts 表中。
   175	
   176	**重试：** 首次调用 + 最多 3 次重试 = 最多 4 次上游请求。对网络错误、超时、HTTP 408/429/500/502/503/504/529 及明确的临时 SSE 错误重试；鉴权错误、上游 400、无效 JSON 等不重试。等待时间为 `base × 2^n + [0, 20%] 抖动`；如有 Retry-After，至少等待该时间，上限 60 秒。已向用户输出文本后不重试，防止重复输出。
   177	
   178	**限流：** 按网关 `model` 独立维护滑动窗口，默认 Pro 20 次/分钟，Flash 60 次/分钟。一个请求占一个名额，内部重试不额外占名额。超限立即返回 `429 RATE_LIMITED` 和 `Retry-After`，不请求上游。
   179	
   180	可用 `.env` 的 `PRO_RPM=1` / `FLASH_RPM=60`，重启后在窗口内对 Pro 连续请求两次验证 429，再调用 Flash 验证隔离。自动化离线测试会验证这一点，无需重复付费调用。
   181	
   182	统一错误示例：
   183	
   184	```json
   185	{"error":{"code":"RATE_LIMITED","message":"该模型请求过于频繁，请稍后重试。","retryable":false},"request_id":"..."}
   186	```
   187	
   188	本地 429 的 retryable=false 表示网关内部不会对它重试；客户端可在 Retry-After 后重新发起请求。上游鉴权/参数错误对客户端映射为 502，上游限流映射为 429，临时不可用为 503，超时为 504；不会原样泄漏供应商错误正文。
   189	
   190	## 4. 验证与交付证据
   191	
   192	### 离线：覆盖所有功能与故障场景
   193	
   194	```bash
   195	uv run python scripts/verify.py
   196	uv run ruff check .
   197	```
   198	
   199	脚本执行完整 pytest，写入 `evidence/offline.json` 和 `evidence/offline.junit.xml`。JSON 报告包含功能对应的测试名称、结果，以及 Token、重试次数、429 的实际测试观测值。HTTP 上游由 MockTransport 替换；路由、适配器、SSE 解析、数据库、重试和限流均运行真实代码。
   200	
   201	**离线通过不代表真实模型连通。** 报告明确标记 `mode=offline` 和 `live_verified=false`。
   202	
   203	### 真实 API：两个模型
   204	
   205	配置密钥、启动服务后，另开终端：
   206	
   207	```bash
   208	uv run python scripts/verify.py --live
   209	# 自定义地址与报告文件：
   210	uv run python scripts/verify.py --live --base-url http://127.0.0.1:8000 --output evidence/live.json
   211	```
   212	
   213	真实模式产生 10 次模型调用（每模型：普通、SSE、Schema、Schema+SSE、模板），会消耗额度。检查 JSON Schema、增量拼接、用量、首 Token 延迟、模板版本及持久化 trace，将结果写入 `evidence/live.json`，失败时非零退出。重试和限流的可控故障证据来自 offline 报告。真实报告可随源码提交；`.env`、`.venv` 和本地数据库仍被 Git 忽略。
   214	
   215	### 本次提交前检查（2026-11-02）
   216	
   217	完整离线测试 **62 项通过**，Ruff 代码和格式检查通过。现有真实验收报告中，两个模型的 **10 个场景全部通过**，包含对应的 10 条持久化 trace。提交前还修复了模板渲染边界、Responses 临时错误分类、JSON 数值溢出三处问题，并新增 10 个回归用例。详细范围与复现方法见[提交说明](docs/提交说明.md)。
   218	
   219	| 验收点 | 自动化测试/报告证据 |
   220	|---|---|
   221	| 两个协议及鉴权 | `test_protocol_routing_auth_and_token_categories` |
   222	| 流式输出 | `test_stream_sse_deltas_completion_usage_ttft`、字节拆包与取消测试 |
   223	| 结构化输出 | `test_structured_output_uses_protocol_schema_and_validates`、非法结果拒绝测试 |
   224	| 模板版本 | `test_prompt_version_immutable_substitution_and_persistence` |
   225	| 可观测数据 | Token 分类、TTFT 真正早于结束、SQLite 重启持久化测试 |
   226	| 重试 | `test_retry_max_three_retries_and_sanitized_error`、指数退避与超时测试 |
   227	| 限流 | `test_rate_limit_independent_models_and_retry_after`、并发准入与窗口过期测试 |
   228	
   229	## 5. 代码结构与阅读顺序
   230	
   231	```text
   232	gateway/
   233	  models.py       # 统一请求、用量、内部事件
   234	  adapters.py     # Responses / Messages 鉴权、请求、响应、SSE 差异
   235	  service.py      # 路由、模板、重试、JSON 校验、观测、取消
   236	  policies.py     # 按模型限流、退避算法
   237	  storage.py      # SQLite 模板版本与调用记录
   238	  app.py          # HTTP 路由、统一错误、SSE 转发
   239	  config.py       # 环境变量和配置校验
   240	prompts/          # 初始模板
   241	tests/            # 完整离线功能与故障验证
   242	scripts/verify.py # 离线/真实验收入口
   243	docs/学习指南.md  # 边实现边讲解的配套说明
   244	evidence/         # 已生成的离线验收证据
   245	```
   246	
   247	建议按 models → adapters → service → app 阅读，再看 policies/storage。详见[学习指南](docs/学习指南.md)。
   248	
   249	这是单进程本地作业服务，启动时使用一个 worker。限流状态在内存中，重启清空；多 worker 或多实例需要共享存储。管理接口用于本地练习，默认只监听 127.0.0.1；没有加入多租户鉴权、分布式限流或完整计费系统。
   250	
   251	协议参考：[DeepSeek Responses](https://api-docs.deepseek.com/guides/responses_api/)、[DeepSeek Anthropic 兼容](https://api-docs.deepseek.com/guides/anthropic_api/)。
