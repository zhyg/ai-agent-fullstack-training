import json
import time
from pathlib import Path
import httpx

OUT = Path('/tmp/grade-G20261786020129')
c = httpx.Client(base_url='http://127.0.0.1:8129', timeout=12, trust_env=False)
models = ['deepseek-v4-pro', 'deepseek-v4-flash']
report = []
schema = {'type': 'json_schema', 'json_schema': {'name': 'answer', 'schema': {'type': 'object', 'properties': {'answer': {'type': 'string'}}, 'required': ['answer']}}}
def body(model, **kw): return dict(model=model, messages=[{'role':'system','content':'teacher system'}, {'role':'user','content':'teacher question'}], max_tokens=128, **kw)
def reset(mode='ok'): c.post('/teacher/control', json={'mode': mode}).raise_for_status()
def note(case, observed): report.append({'case':case, 'observed':observed}); print(case, json.dumps(observed, ensure_ascii=False), flush=True)
def post(model, **kw): return c.post('/v1/llm', json=body(model, **kw))
def trace(rid): return next(t for t in c.get('/v1/traces?limit=1000').json()['data'] if t['request_id']==rid)

for model in models:
    reset()
    r=post(model); assert r.status_code==200
    d=r.json(); t=trace(d['request_id']); assert t['usage']['total_tokens']==(26 if model==models[0] else 25)
    assert t['usage']['cache_read_tokens']==3 and t['status']=='completed'
    req=c.get('/teacher/state').json()['calls'][0]
    assert ('input' in req['body']) != ('messages' in req['body'])
    assert d['request_id']==r.headers['x-request-id']
    note('A03/F07 '+model, {'wire':req,'result':d,'trace':t})
    reset(); r=post(model,response_format=schema); assert r.status_code==200 and r.json()['parsed']=={'answer':'OK'}
    note('F03 '+model, {'result':r.json(),'wire':c.get('/teacher/state').json()['calls']})
    for mode in ['illegal','empty','schema','truncated']:
        reset(mode); r=post(model,response_format=schema); assert r.status_code==502
        t=trace(r.json()['request_id']); assert t['status']=='failed' and t['attempts']==1
        note('F04 '+model+' '+mode, {'status':r.status_code,'error':r.json(),'trace':t})
    for mode in ['ok','cut']:
        reset(mode)
        events=[]; first=None; started=time.monotonic()
        with c.stream('POST','/v1/llm',json=body(model,stream=True)) as r:
            assert r.status_code==200
            for line in r.iter_lines():
                if not line.startswith('data: '): continue
                e=json.loads(line[6:]); events.append(e)
                if e['type']=='content.delta' and first is None:
                    first=(time.monotonic()-started)*1000
                    s=httpx.get('http://127.0.0.1:8129/teacher/state',trust_env=False).json()
                    assert not s['released'] and e['delta']=='Alpha'
                    httpx.post('http://127.0.0.1:8129/teacher/release',trust_env=False)
        t=trace(events[0]['request_id']); calls=c.get('/teacher/state').json()['calls']
        assert len(calls)==1 and first is not None and t['ttft_ms']>=30
        assert events[-1]['type']==('response.completed' if mode=='ok' else 'error')
        if mode=='ok':
            assert ''.join(e['delta'] for e in events if e['type']=='content.delta')=='Alpha尾'
            assert t['usage']['total_tokens']==(26 if model==models[0] else 25)
        else: assert t['status']=='failed'
        note(('F01' if mode=='ok' else 'F02')+' '+model, {'first_delta_before_release':True,'client_first_ms':first,'calls':len(calls),'events':events,'trace':t})
    for mode, expected_calls, status in [('retry',3,200),('always',4,503),('auth',1,502),('bad400',1,502)]:
        reset(mode); r=post(model); assert r.status_code==status
        calls=c.get('/teacher/state').json()['calls']; assert len(calls)==expected_calls
        t=trace(r.json()['request_id']); delays=[a['backoff_ms'] for a in t['attempt_details']]
        for i,d in enumerate(delays[:-1]): assert 10*2**i<=d<=12*2**i
        note('F08/F09 '+model+' '+mode, {'status':status,'actual_wire_calls':len(calls),'backoff_ms':delays,'trace':t})

reset(); r=post('unknown-model'); assert r.status_code==404 and not c.get('/teacher/state').json()['calls']; note('A04',r.json())
for v in ['v1','v2']:
    p={'name':'teacher','version':v,'messages':[{'role':'user','content':v+' ${topic}'}]}
    assert c.post('/v1/prompts',json=p).status_code==201
for v in ['v1','v2']:
    reset(); r=c.post('/v1/llm',json={'model':models[0],'prompt':{'name':'teacher','version':v,'variables':{'topic':'XYZ'}}}); assert r.status_code==200
    calls=c.get('/teacher/state').json()['calls']; assert calls[0]['body']['input'][0]['content']==v+' XYZ'; note('F05 '+v,calls)
for name,version,variables,status in [('absent','v1',{},404),('teacher','v9',{},404),('teacher','v1',{},400)]:
    reset(); r=c.post('/v1/llm',json={'model':models[0],'prompt':{'name':name,'version':version,'variables':variables}}); assert r.status_code==status and not c.get('/teacher/state').json()['calls']; note('F06',r.json())
reset(); statuses=[post(models[0]).status_code,post(models[0]).status_code,post(models[1]).status_code]; assert statuses==[200,429,200]
time.sleep(.33); recovered=post(models[0]); assert recovered.status_code==200; note('F10/F11',{'statuses':statuses,'after_window':recovered.status_code})
(OUT/'teacher-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS independent controlled checks')
