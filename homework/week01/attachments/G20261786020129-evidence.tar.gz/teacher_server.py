import asyncio
import json
import os
import time
from pathlib import Path

import httpx
from gateway.app import create_app
from gateway.config import Settings

OUT = Path('/tmp/grade-G20261786020129')
live = os.getenv('GRADE_MODE') == 'live'
state = {'mode': 'ok', 'calls': [], 'released': False}
gate = asyncio.Event()

def final(proto, text='Alpha尾', structured=False):
    if proto == 'responses':
        return {'id': 'teacher-response', 'status': 'completed', 'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}], 'usage': {'input_tokens': 17, 'output_tokens': 9, 'input_tokens_details': {'cached_tokens': 3}, 'output_tokens_details': {'reasoning_tokens': 4}}}
    return {'id': 'teacher-message', 'stop_reason': 'tool_use' if structured else 'end_turn', 'content': [{'type': 'tool_use', 'name': 'emit_json', 'input': json.loads(text)}] if structured else [{'type': 'text', 'text': text}], 'usage': {'input_tokens': 11, 'output_tokens': 9, 'cache_read_input_tokens': 3, 'cache_creation_input_tokens': 2}}

def wire(event):
    return ('data: ' + json.dumps(event, ensure_ascii=False) + '\n\n').encode()

class Chunks(httpx.AsyncByteStream):
    def __init__(self, proto, mode):
        self.proto, self.mode = proto, mode
    async def __aiter__(self):
        yield b': heartbeat\n\n'
        await asyncio.sleep(.04)
        if self.proto == 'responses':
            yield wire({'type': 'response.output_text.delta', 'delta': 'Alpha'})
        else:
            yield wire({'type': 'message_start', 'message': {'usage': {'input_tokens': 11, 'output_tokens': 0, 'cache_read_input_tokens': 3, 'cache_creation_input_tokens': 2}}})
            yield wire({'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'text', 'text': ''}})
            yield wire({'type': 'content_block_delta', 'index': 0, 'delta': {'type': 'text_delta', 'text': 'Alpha'}})
        await asyncio.wait_for(gate.wait(), 8)
        if self.mode == 'cut':
            yield wire({'type': 'error', 'error': {'type': 'overloaded_error', 'code': 'server_error'}})
            return
        if self.proto == 'responses':
            yield wire({'type': 'response.output_text.delta', 'delta': '尾'})
            yield wire({'type': 'response.completed', 'response': final(self.proto)})
        else:
            yield wire({'type': 'content_block_delta', 'index': 0, 'delta': {'type': 'text_delta', 'text': '尾'}})
            yield wire({'type': 'message_delta', 'delta': {}, 'usage': {'output_tokens': 5}})
            yield wire({'type': 'message_delta', 'delta': {'stop_reason': 'end_turn'}, 'usage': {'output_tokens': 9}})
            yield wire({'type': 'message_stop'})

def mock(request):
    body = json.loads(request.content)
    proto = 'responses' if request.url.path == '/responses' else 'messages'
    state['calls'].append({'path': request.url.path, 'body': body, 'auth_header_names': [h for h in ('authorization', 'x-api-key', 'anthropic-version') if h in request.headers], 'time': time.monotonic()})
    mode = state['mode']
    if mode in ('retry', 'always', 'bad400', 'auth'):
        status = 503 if mode in ('retry', 'always') else 400 if mode == 'bad400' else 401
        if mode != 'retry' or len(state['calls']) <= 2:
            return httpx.Response(status, json={'error': {'message': 'controlled failure'}})
    if body.get('stream'):
        return httpx.Response(200, headers={'content-type': 'text/event-stream'}, stream=Chunks(proto, mode))
    structured = 'text' in body or 'tools' in body
    text = '{"answer":"OK"}' if structured else 'Alpha尾'
    if mode == 'illegal': text = '{broken'
    if mode == 'empty': text = ''
    if mode == 'schema': text = '{"answer":7}'
    if proto == 'messages' and structured and mode in ('illegal', 'empty'):
        data = final(proto)
        data['content'] = [{'type': 'tool_use', 'name': 'emit_json', 'input': [] if mode == 'empty' else 'not object'}]
        data['stop_reason'] = 'tool_use'
    else:
        data = final(proto, text, structured)
    if mode == 'truncated':
        data['status' if proto == 'responses' else 'stop_reason'] = 'incomplete' if proto == 'responses' else 'max_tokens'
    return httpx.Response(200, json=data)

class Capture(httpx.AsyncBaseTransport):
    def __init__(self): self.inner = httpx.AsyncHTTPTransport(retries=0)
    async def handle_async_request(self, request):
        record = {'path': request.url.path, 'host': request.url.host, 'body': json.loads(request.content), 'auth_header_names': [h for h in ('authorization', 'x-api-key', 'anthropic-version') if h in request.headers]}
        started = time.monotonic()
        try:
            response = await self.inner.handle_async_request(request)
            record.update(status=response.status_code, upstream_request_id=response.headers.get('x-request-id'), upstream_response_id=response.headers.get('request-id'))
            return response
        except Exception as error:
            record['exception'] = type(error).__name__
            raise
        finally:
            record['headers_latency_ms'] = (time.monotonic()-started)*1000
            with (OUT/'live-wire.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
    async def aclose(self): await self.inner.aclose()

config = Settings(_env_file=None, database_path=str(OUT/('live.sqlite3' if live else 'controlled.sqlite3')), max_retries=0 if live else 3, retry_base_seconds=.01, request_timeout_seconds=25, pro_rpm=100 if live else 1, flash_rpm=100, rate_window_seconds=.3, **({} if live else {'deepseek_api_key': 'teacher-dummy'}))
app = create_app(config, Capture() if live else httpx.MockTransport(mock))

@app.post('/teacher/control')
async def control(body: dict):
    state.update(mode=body.get('mode', 'ok'), calls=[], released=False)
    gate.clear()
    app.state.gateway.limiter.buckets.clear()
    return {'ok': True}

@app.post('/teacher/release')
async def release():
    state['released'] = True
    gate.set()
    return {'ok': True}

@app.get('/teacher/state')
async def inspect(): return state
