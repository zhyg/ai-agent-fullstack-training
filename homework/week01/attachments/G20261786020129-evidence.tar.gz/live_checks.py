import json
import time
from pathlib import Path
import httpx

out=Path('/tmp/grade-G20261786020129')
c=httpx.Client(base_url='http://127.0.0.1:8131',timeout=32,trust_env=False)
report={'official_only':True,'max_retries':0,'timeout_seconds':25,'max_tokens':2048,'cases':[]}
for model in ['deepseek-v4-pro','deepseek-v4-flash']:
    blocked=False
    for feature in ['basic','structured','stream']:
        if blocked:
            report['cases'].append({'model':model,'feature':feature,'status':'unverified','reason':'earlier upstream failure; no repeated pressure'})
            continue
        body={'model':model,'max_tokens':2048,'messages':[{'role':'user','content':'Reply only OK. Do not explain.'}]}
        if feature=='structured':
            body.update(messages=[{'role':'user','content':'Return JSON {"answer":"OK"} only.'}],response_format={'type':'json_object'})
        if feature=='stream': body['stream']=True
        started=time.monotonic()
        record={'model':model,'feature':feature,'request':body}
        try:
            r=c.post('/v1/llm',json=body)
            record.update(http_status=r.status_code,request_id=r.headers.get('x-request-id'),wall_ms=(time.monotonic()-started)*1000)
            if feature!='stream' or r.status_code!=200:
                record['response']=r.json()
                record['status']='passed' if r.status_code==200 and bool(r.json().get('content')) else 'unverified'
            else:
                events=[json.loads(line[6:]) for line in r.text.splitlines() if line.startswith('data: ')]
                record['events']=events
                record['status']='passed' if events[-1]['type']=='response.completed' else 'unverified'
            blocked=record['status']!='passed'
        except httpx.HTTPError as e:
            blocked=True
            record.update(status='unverified',exception=type(e).__name__,wall_ms=(time.monotonic()-started)*1000)
        report['cases'].append(record)
        print(model,feature,record['status'],record.get('http_status'),flush=True)
report['traces']=c.get('/v1/traces?limit=1000').json()['data']
report['models']=c.get('/v1/models').json()['data']
(out/'teacher-live.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
