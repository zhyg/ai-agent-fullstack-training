# G20261786020129 evidence

Pinned repository https://github.com/includeYou/AI-Agent-Training.git, main 29b7e258cb693d83ec163b8b4909feadffacccb9, week-01.
Date 2026-11-07 Asia/Singapore. No student business source modifications.

Extract this archive into /tmp/grade-G20261786020129. Clone the pinned student tree to /tmp/student-G20261786020129. Run uv sync --frozen in week-01.

Commands below were supervised with amp orb service start; execute from week-01. Use fresh controlled.sqlite3 and live.sqlite3 on replay; teacher_checks creates immutable prompt versions.

```bash
amp orb service start grade-readme --command 'DATABASE_PATH=/tmp/grade-G20261786020129/readme.sqlite3 MAX_RETRIES=0 REQUEST_TIMEOUT_SECONDS=25 /tmp/student-G20261786020129/week-01/.venv/bin/python -m uvicorn gateway.app:app --host 127.0.0.1 --port 8130' --port 8130
amp orb service start grade-controlled --command 'PYTHONPATH=/tmp/student-G20261786020129/week-01:/tmp/grade-G20261786020129 /tmp/student-G20261786020129/week-01/.venv/bin/python -m uvicorn teacher_server:app --host 127.0.0.1 --port 8129' --port 8129
uv run python scripts/verify.py --output /tmp/grade-G20261786020129/student-offline.json
uv run python /tmp/grade-G20261786020129/teacher_checks.py
uv run python /tmp/grade-G20261786020129/boundary_checks.py
curl -sS -X POST http://127.0.0.1:8129/teacher/control -H 'Content-Type: application/json' -d '{"mode":"bad400"}'
uv run python scripts/verify.py --live --base-url http://127.0.0.1:8129 --output /tmp/grade-G20261786020129/student-injected-failure.json
```

The injected verifier failure is mock-only and exits 1 as expected. boundary_checks exits 0 when it reproduces the known 502 mapping; its JSON explicitly records passed=false for that requirement. Do not call this entire suite acceptance-passed.

Controlled settings: dummy credential, Pro quota1, Flash100, window0.3 seconds, max_retries3, retry_base0.01 seconds. HTTP counts measure actual adapter requests; direct httpx has no SDK retry multiplier. Positive jitter follows student's documented 20% interval.

Optional real upstream replay ONLY when healthy and authorized for model calls. Existing environment DEEPSEEK_API_KEY required, never place it in these files. No alternate models used. Real calls keep original upstream models and endpoints, timeout25s, max_retries0, transport retries0, max_tokens2048. Each route stops after its first failure; the original run made exactly 2 attempts total. HTTP200 recorded in live-wire is response headers only, followed by body read timeouts, NOT successful completion.

```bash
amp orb service start grade-live --command 'GRADE_MODE=live PYTHONPATH=/tmp/student-G20261786020129/week-01:/tmp/grade-G20261786020129 /tmp/student-G20261786020129/week-01/.venv/bin/python -m uvicorn teacher_server:app --host 127.0.0.1 --port 8131' --port 8131
uv run python /tmp/grade-G20261786020129/live_checks.py
amp orb service stop grade-readme
amp orb service stop grade-controlled
amp orb service stop grade-live
```

No database, environment secrets, raw credential headers or virtual environment included. source-lines contains numbered snapshots at the fixed SHA; source-sha256 hashes original source files. Full grading rationale is in the adjacent course attachment.
