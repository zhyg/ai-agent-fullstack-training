import json
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from gateway.app import create_app
from gateway.config import Settings

out=Path('/tmp/grade-G20261786020129')
results=[]
for protocol,model in [('responses','deepseek-v4-pro'),('messages','deepseek-v4-flash')]:
    for raw in ['', '{broken', '{"answer":', '{"answer":7}', '{"answer":"OK"}']:
        calls=[]
        def upstream(request):
            calls.append(json.loads(request.content))
            if protocol=='responses':
                events=[{'type':'response.output_text.delta','delta':raw}, {'type':'response.completed','response':{'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':raw}]}],'usage':{'input_tokens':7,'output_tokens':3}}}]
            else:
                events=[{'type':'message_start','message':{'usage':{'input_tokens':7,'output_tokens':0}}}, {'type':'content_block_start','index':0,'content_block':{'type':'tool_use','name':'emit_json','input':{}}}, {'type':'content_block_delta','index':0,'delta':{'type':'input_json_delta','partial_json':raw}}, {'type':'message_delta','delta':{'stop_reason':'tool_use'},'usage':{'output_tokens':3}}, {'type':'message_stop'}]
            return httpx.Response(200,headers={'content-type':'text/event-stream'},text=''.join('data: '+json.dumps(e)+'\n\n' for e in events))
        config=Settings(_env_file=None,deepseek_api_key='teacher-dummy',database_path=':memory:',retry_base_seconds=0)
        with TestClient(create_app(config,httpx.MockTransport(upstream))) as c:
            r=c.post('/v1/llm',json={'model':model,'stream':True,'messages':[{'role':'user','content':'JSON'}],'response_format':{'type':'json_schema','json_schema':{'schema':{'type':'object','properties':{'answer':{'type':'string'}},'required':['answer']}}}})
            good=raw=='{"answer":"OK"}'
            assert r.status_code==(200 if good else 502) and len(calls)==1
            if good: assert 'response.completed' in r.text
            else: assert 'content.delta' not in r.text
            trace=c.get('/v1/traces').json()['data'][0]
            assert trace['status']==('completed' if good else 'failed') and trace['usage']['total_tokens']==10
            results.append({'case':'F04 structured stream','protocol':protocol,'raw':raw,'status':r.status_code,'response':r.text,'wire':calls,'trace':trace,'passed':True})
    def unsupported(request):
        return httpx.Response(400,json={'error':{'type':'invalid_request_error','message':'Requested output format is not supported'}})
    with TestClient(create_app(config,httpx.MockTransport(unsupported))) as c:
        r=c.post('/v1/llm',json={'model':model,'messages':[{'role':'user','content':'JSON'}],'response_format':{'type':'json_object'}})
        assert r.status_code==502 and r.json()['error']['code']=='UPSTREAM_BAD_REQUEST'
        results.append({'case':'F03 unsupported format mapping','protocol':protocol,'expected':'unified 4xx','status':r.status_code,'response':r.json(),'passed':400<=r.status_code<500,'source':'gateway/errors.py:7,31'})
(out/'boundary-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('F04: 10/10 passed; F03 unsupported format: 2/2 reproduced HTTP 502 instead of 4xx (one root cause)')
