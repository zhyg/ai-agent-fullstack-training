import asyncio, json
from pathlib import Path
import httpx

async def main():
    out=[]
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8182',timeout=10) as c:
        for model in ['deepseek-v4-pro','deepseek-v4-flash']:
            for mode in ['retry','always500','bad401']:
                await c.post('/teacher/reset',json={'mode':mode})
                events=[]; err=None
                try:
                    async with c.stream('POST','/v1/chat/completions',json={'model':model,'stream':True,'messages':[{'role':'user','content':'hi'}]}) as r:
                        status=r.status_code
                        async for line in r.aiter_lines():
                            if line.startswith('data: '): events.append(json.loads(line[6:]))
                except Exception as e: err=type(e).__name__
                state=(await c.get('/teacher/state')).json()
                ledger=(await c.get('/v1/admin/usage')).json()
                n=len(state['calls']); expected=1 if mode=='bad401' else 3
                out.append({'case':'F08/F09-stream-'+mode,'model':model,'expected_calls':expected,'actual_calls':n,'http_status':status,'transport_error':err,'events':events,'ledger':ledger,'pass':n==expected and (bool(events) and events[-1]['type']=='done' if mode=='retry' else err is not None)})
    Path('/tmp/ming-grade/stream-retry-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__': asyncio.run(main())
