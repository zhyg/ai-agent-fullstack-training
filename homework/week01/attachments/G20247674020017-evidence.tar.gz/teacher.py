import asyncio, json, time
from pathlib import Path
import httpx

ROOT=Path('/tmp/ming-grade')
MODELS=['deepseek-v4-pro','deepseek-v4-flash']
results=[]
async def main():
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8182',timeout=12) as c:
        async def reset(mode='normal',**kw): await c.post('/teacher/reset',json={'mode':mode,**kw})
        async def state(): return (await c.get('/teacher/state')).json()
        async def usage(): return (await c.get('/v1/admin/usage')).json()['data']
        async def chat(model=MODELS[0],**kw):
            return await c.post('/v1/chat/completions',json={'model':model,'messages':[{'role':'system','content':'sys'},{'role':'user','content':'hi'}],**kw})
        def save(case,expected,actual,ok):
            results.append({'case':case,'expected':expected,'actual':actual,'pass':bool(ok)})
            (ROOT/'teacher-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
            print(case, 'PASS' if ok else 'FAIL',flush=True)
        await reset()
        for m in MODELS:
            r=await chat(m); s=await state(); call=s['calls'][-1]
            pro=m==MODELS[0]
            ok=r.status_code==200 and r.json()['content']=='{"ok":true}' and call['path']==('/responses' if pro else '/v1/messages') and ('input' if pro else 'messages') in call['body']
            save('A03-'+m,'different path/body and nested output parsed',{'response':r.json(),'wire':call},ok)
        r=await chat('missing'); save('A04','404 uniform error',{'status':r.status_code,'body':r.json()},r.status_code==404)
        r=await chat('v4-pro'); s=await state()
        save('A03-alias','registered alias maps to configured upstream name',s['calls'][-1],s['calls'][-1]['body']['model']=='deepseek-v4-pro')
        for m in MODELS:
            await reset('gate')
            start=time.monotonic(); lines=[]
            async with c.stream('POST','/v1/chat/completions',json={'model':m,'stream':True,'messages':[{'role':'user','content':'hi'}]}) as r:
                async for line in r.aiter_lines():
                    if not line.startswith('data: '): continue
                    item=json.loads(line[6:]); lines.append(item)
                    if item['type']=='chunk':
                        s=await state(); early=not s['released']; first_ms=(time.monotonic()-start)*1000
                        await c.post('/teacher/release')
            records=await usage()
            save('F01-'+m,'content arrives before terminal released; heartbeat excluded from TTFT',{'events':lines,'first_ms':first_ms,'pre_release':early,'usage':records},early and lines[-1]['type']=='done' and records[0]['ttft_ms']>=140)
            for mode in ['disconnect','error_event','eof']:
                await reset(mode); events=[]; error=None
                try:
                    async with c.stream('POST','/v1/chat/completions',json={'model':m,'stream':True,'messages':[{'role':'user','content':'hi'}]}) as r:
                        async for line in r.aiter_lines():
                            if line.startswith('data: '): events.append(json.loads(line[6:]))
                except Exception as e: error=type(e).__name__
                s=await state(); rec=await usage()
                save('F02-'+mode+'-'+m,'detect failure, no success done, one upstream request',{'events':events,'transport_error':error,'calls':len(s['calls']),'usage':rec},len(s['calls'])==1 and error is not None and rec[0]['status']=='error')
        for m in MODELS:
            for mode in ['normal','invalid','empty','truncated','schema']:
                await reset(mode)
                rf={'type':'json_schema','json_schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok']}}
                r=await chat(m,response_format=rf); s=await state()
                save(('F03-' if mode=='normal' else 'F04-')+mode+'-'+m,'valid JSON succeeds; invalid/empty/truncated/schema mismatch =>422',{'status':r.status_code,'response':r.json(),'wire':s['calls'],'usage':await usage()},r.status_code==(200 if mode=='normal' else 422))
        await reset()
        bodies=[]
        for v in ['v1','v2','v1']:
            p={'name':'summarize','version':v,'variables':{'text':'teacher unique text',('max_sentences' if v=='v1' else 'max_bullets'):'2'}}
            r=await chat(prompt=p); s=await state(); bodies.append(s['calls'][-1]['body'])
        texts=[x['input'][0]['content'][0]['text'] for x in bodies]
        save('F05','v1/v2/v1 explicit reference retained and substituted upstream',texts,texts[0]==texts[2] and texts[0]!=texts[1] and all('teacher unique text' in t and '{text}' not in t for t in texts))
        for name,v,variables in [('absent','v1',{}),('summarize','v999',{}),('summarize','v1',{'text':'x'})]:
            await reset(); r=await chat(prompt={'name':name,'version':v,'variables':variables}); s=await state()
            save('F06-'+name+'-'+v,'explicit 4xx; no upstream call',{'status':r.status_code,'body':r.json(),'calls':s['calls'],'records':await usage()},400<=r.status_code<500 and not s['calls'])
        for mode in ['normal','invalid','bad400']:
            await reset(mode); r=await chat(response_format={'type':'json_object'} if mode=='invalid' else None)
            records=await usage()
            expected_tokens=13 if mode!='bad400' else 0
            save('F07-'+mode,'record returned/known token usage including failed validation',{'status':r.status_code,'body':r.json(),'records':records},len(records)==1 and records[0]['input_tokens']==expected_tokens and records[0]['status']==('success' if mode=='normal' else 'error'))
            if mode=='normal':
                save('F07-correlation','ledger stores response/request identifier',records,any(k in records[0] for k in ['request_id','response_id','trace_id']))
        for mode in ['retry','always500','bad400','bad401']:
            await reset(mode); r=await chat(); s=await state(); times=[x['time'] for x in s['calls']]; intervals=[times[i+1]-times[i] for i in range(len(times)-1)]
            expected_n=3 if mode in ['retry','always500'] else 1
            save(('F08-' if mode=='retry' else 'F09-')+mode,'3 total for transient; 1 for 400/401; finite exponential delays',{'status':r.status_code,'response':r.json(),'count':len(times),'intervals_seconds':intervals,'records':await usage()},len(times)==expected_n and r.status_code==(200 if mode=='retry' else 502))
        await reset('bad400'); r=await chat(response_format={'type':'json_object'})
        save('F03-unsupported-format','unsupported requested format => uniform 4xx',{'status':r.status_code,'body':r.json()},400<=r.status_code<500)
        await reset(rate=True)
        codes=[(await chat()).status_code for _ in range(3)]; b=(await chat(MODELS[1])).status_code
        save('F10','A 200,200,429; B unaffected',{'A':codes,'B':b},codes==[200,200,429] and b==200)
        await asyncio.sleep(30.2)
        r=await chat(); save('F11','real 30s refill for capacity2/rpm2 restores quota',{'status':r.status_code},r.status_code==200)
        # Verify HTTP status for pre-stream local errors, including exhausted quota.
        await chat()
        events=[]; err=None
        try:
            async with c.stream('POST','/v1/chat/completions',json={'model':MODELS[0],'stream':True}) as r:
                status=r.status_code
                async for line in r.aiter_lines(): events.append(line)
        except Exception as e: err=type(e).__name__
        save('F10-stream','local exhaustion returns HTTP429 before SSE starts',{'status':status,'events':events,'error':err},status==429)

if __name__=='__main__': asyncio.run(main())
