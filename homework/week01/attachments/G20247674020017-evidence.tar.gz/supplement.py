import asyncio, json, tempfile
from pathlib import Path
import httpx, yaml
from app.main import create_app
from app.config import load_config
from app.services.prompts import PromptService
from app.services.usage import UsageService

async def main():
    captures=[]; cfg=load_config(); cfg.rate_limit.enabled=False
    def handler(r):
        b=json.loads(r.content); captures.append(b)
        if 'input' in b:
            data={'id':'resp_supplement','output':[{'type':'message','content':[{'type':'output_text','text':'OK'}]}],'usage':{'input_tokens':13,'output_tokens':7,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2},'total_tokens':20}}
        else:
            data={'id':'msg_supplement','content':[{'type':'text','text':'OK'}],'usage':{'input_tokens':13,'output_tokens':7,'cache_read_input_tokens':3,'cache_creation_input_tokens':2}}
        return httpx.Response(200,json=data)
    app=create_app(cfg,transport=httpx.MockTransport(handler))
    app.state.usage=app.state.gateway.usage=UsageService('/tmp/ming-grade/supplement-usage.db')
    out={}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://student') as c:
        for m in ['deepseek-v4-pro','deepseek-v4-flash']:
            r=await c.post('/v1/chat/completions',json={'model':m,'messages':[{'role':'user','content':'hi'}]})
            out[m]={'actual':r.json(),'expected':{'input_tokens':13 if m.endswith('pro') else 18,'output_tokens':7,'cached_input_tokens':3,'reasoning_tokens':2 if m.endswith('pro') else 'not supplied','cache_creation_tokens':2 if m.endswith('flash') else 'not supplied'}}
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'teacher.yaml'
            versions={'v1':{'template':'OLD {topic}'}}
            path.write_text(yaml.safe_dump({'versions':versions}))
            app.state.gateway.prompt_service=PromptService(d)
            async def render(v):
                r=await c.post('/v1/chat/completions',json={'model':'deepseek-v4-pro','prompt':{'name':'teacher','version':v,'variables':{'topic':'cobalt'}}})
                return {'status':r.status_code,'upstream_system':captures[-1]['input'][0]['content'][0]['text']}
            before=await render('v1')
            versions['v2']={'template':'NEW {topic}'}
            path.write_text(yaml.safe_dump({'versions':versions}))
            after2=await render('v2'); after1=await render('v1')
            out['F05-publication']={'before':before,'after_v2':after2,'after_v1':after1,'pass':before==after1 and after2['upstream_system']=='NEW cobalt'}
    out['ledger']=[x.model_dump() for x in app.state.usage.list()]
    Path('/tmp/ming-grade/supplement-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    await app.state.http_client.aclose()

if __name__=='__main__': asyncio.run(main())
