import asyncio, json, time, os
from pathlib import Path
import httpx
from app.main import create_app
from app.config import load_config
from app.services.usage import UsageService

OUT=Path('/tmp/ming-grade')
async def main():
    cfg=load_config()
    cfg.providers[1].base_url='https://api.deepseek.com/anthropic'
    cfg.providers[1].api_key_env='DEEPSEEK_API_KEY'
    cfg.providers[1].models[0].name='deepseek-flash'
    cfg.retry.max_attempts=1
    cfg.rate_limit.enabled=False
    (OUT/'real-config.json').write_text(cfg.model_dump_json(indent=2))
    app=create_app(cfg)
    app.state.gateway.usage=app.state.usage=UsageService(OUT/'real-usage.db')
    wire=[]
    async def request_hook(r):
        wire.append({'path':str(r.url),'body':json.loads(r.content),'started':time.time()})
    async def response_hook(r):
        wire[-1]['status']=r.status_code
        wire[-1]['request_id']=r.headers.get('x-request-id') or r.headers.get('request-id')
        if not wire[-1]['body'].get('stream'):
            await r.aread()
            try: wire[-1]['response']=r.json()
            except Exception: wire[-1]['response']=r.text[:1000]
    app.state.http_client.event_hooks={'request':[request_hook],'response':[response_hook]}
    results=[]
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app,raise_app_exceptions=False),base_url='http://test') as c:
        for model in ['deepseek-v4-pro','deepseek-flash']:
            for kind in ['plain','stream','json']:
                payload={'model':model,'messages':[{'role':'user','content':'Return only '+('{"ok":true}' if kind=='json' else 'OK')+'. Keep it brief.'}],'max_tokens':1024}
                if kind=='stream': payload['stream']=True
                if kind=='json': payload['response_format']={'type':'json_object'}
                start=time.monotonic()
                try:
                    r=await asyncio.wait_for(c.post('/v1/chat/completions',json=payload),45)
                    result={'model':model,'kind':kind,'status':r.status_code,'body':r.text,'elapsed_ms':(time.monotonic()-start)*1000}
                except Exception as e:
                    result={'model':model,'kind':kind,'unverified':type(e).__name__,'elapsed_ms':(time.monotonic()-start)*1000}
                results.append(result)
                (OUT/'real-results.json').write_text(json.dumps({'results':results,'wire':wire,'usage':[x.model_dump() for x in app.state.usage.list()]},ensure_ascii=False,indent=2))
                print(json.dumps(result,ensure_ascii=False),flush=True)
                if result.get('unverified') or result.get('status',0)>=500:
                    break
    await app.state.http_client.aclose()

if __name__=='__main__': asyncio.run(main())
