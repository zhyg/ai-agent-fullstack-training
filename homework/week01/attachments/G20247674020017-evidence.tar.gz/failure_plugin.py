import pytest, httpx

@pytest.fixture(autouse=True)
def injected_upstream_failure(monkeypatch):
    async def fail(self, request):
        return httpx.Response(400,request=request,json={'error':'teacher deliberate failure'})
    monkeypatch.setattr(httpx.MockTransport,'handle_async_request',fail)
