# 第一周作业评测附件

## A. 固定对象与评测边界

- 学员：ming，G20247674020017。
- 仓库：https://github.com/rxm9010/my-llm-gateway.git
- 分支：main；固定提交：`db9e4fe36ed867f219d81f26ce63544913e74fbb`。
- 评测日期：2026-11-07，Asia/Singapore；真实调用发生于 20:45–20:49，最终复核约 20:51 后。
- 总分：**86/100**；作业等级：**优秀**；验收结论：**通过，需修复**。本次真实接入已验证，不属于环境阻塞暂评；仍需修复下列已复现问题。
- 依据：课程《第一周作业评分标准》v1.1、作业原文、反馈报告模板v1.0。未扩展到部署、鉴权服务、分布式存储等题外要求。
- 在本独立 orb 亲自 clone、安装、启动和执行，无额外线程或代理。学生受版本控制源码未修改，结束时 `git diff --exit-code` 为0、`git status --porcelain` 为空。
- README 方式：`python3 -m venv .venv`、`.venv/bin/pip install -e '.[dev]'`、复制示例配置；以受监督服务运行 `uvicorn app.main:app --host 0.0.0.0 --port 8181`。仅换端口并省略开发热重载，不改变逻辑；模型列表 HTTP 200。
- 真实调用仅 `https://api.deepseek.com`：Responses 保留 `deepseek-v4-pro`；Messages 的独立配置改为 `/anthropic` 基址、`DEEPSEEK_API_KEY` 环境变量引用及当前官方模型 `deepseek-flash`。未声称原示例 `api.anthropic.com + deepseek-v4-flash` 已真实通过；未向 Anthropic 发请求。替代模型直接配置为本名，不用别名转换绕过 D1。
- 真实验收每请求最多1次、45秒外层超时、输出上限1024（补充流式512）；本次无超时或真实500。受控重试仍保持学生默认**总尝试3次**，HTTPX 无 OpenAI/Anthropic SDK 重试叠加。
- 教师注入仅使用学生公开 `create_app(config, transport)` 和服务依赖（独立 SQLite、模板目录、限流配置）；重试探针仅记录实际 sleep 参数并照常等待、固定随机源，不替换业务结果。真实 SSE 追踪追加 `Accept-Encoding: identity` 仅用于保存可读原始事件。

## B. 八项评分

| 评分项 | 得分 | 依据与扣分原因 |
| --- | ---: | --- |
| 统一接口与适配器 | 14/15 | 统一入口3、路由3、双协议4、统一结果4；别名未映射 D1 −1。 |
| 流式输出 | 12/15 | 双模型SSE5、真实增量5、终止错误0、输出后不重试2；错误事件/EOF假成功 D2 −3。 |
| 结构化输出 | 10/10 | 正常双协议4、本地JSON校验3、失败拒绝与Schema校验3；不重复扣错误状态映射。 |
| 提示词版本管理 | 10/10 | 存储3、替换3、旧版本2、缺失项2；动态发布及旧版引用均实际验证。 |
| 可观测性 | 8/15 | 分类2、延迟4、关联查询1、失败记录1；分类映射 D3 −3、关联 D4 −2、校验失败已知用量 D5 −2。 |
| 统一错误与重试 | 13/15 | 错误映射3、退避3、实际次数3、不可重试3、过程证据1；格式错误状态 D6 −1、抖动越界 D7 −1。 |
| 按模型独立限流 | 9/10 | 独立计数4、HTTP状态2、恢复2、配置1；流式超限HTTP200 D8 −1。 |
| 源码、README 与验证脚本 | 10/10 | 源码依赖2、启动3、curl示例2、六功能断言3；不因同一业务缺陷缺少回归测试再扣分。 |
| **合计** | **86/100** | **扣分14分：1+3+3+2+2+1+1+1。** |

## C. A01–A04、F01–F12 实际验收

证据下列文件均在同名 evidence.tar.gz 根目录；源码行号见 `source-lines/`，对应固定提交。教师 HTTP 实测端口8182使用真实 uvicorn/TCP，避免 ASGI 测试客户端缓冲造成“伪门控”。

| 编号 | 方式与结果 | 证据 |
| --- | --- | --- |
| A01 | 通过：按README安装，默认示例配置可启动，模型列表200。首次紧接启动的curl遇到尚未监听，待ready重试后成功，不扣分。 | install.log、readme-start.json、readme-service.log |
| A02 | 通过（独立配置）：两真实模型普通响应均200且正文OK。 | real-config.json、real-results.json |
| A03 | 双协议通过：`/responses` 使用 `input[].content[].input_text`，解析 `output[].content[].text`；`/anthropic/v1/messages` 使用独立system及messages，解析text块；模拟同时验证鉴权种类但不记录密钥。别名另有 D1。 | teacher-results.json 中 A03-*；real-results.json 的 wire |
| A04 | 通过：不存在的model返回404、MODEL_NOT_FOUND，不调用默认模型。 | teacher-results.json / A04 |
| F01 | 通过：双真实SSE均有正文chunk/done；双协议门控均在释放终态前收到Alpha，非一次性缓冲。先发心跳、等待150ms后发文本，TTFT≥140ms，未把心跳当Token。 | real-results.json；real-stream-results.json；teacher-results.json / F01-* |
| F02 | 部分失败：双协议输出Alpha后抛ReadError，均只有1次上游请求，下游传输异常、账本error，不重试；但协议错误事件或EOF被正常done掩盖，D2。 | teacher-results.json / F02-*；teacher-service.log |
| F03 | 通过基本JSON流程：双真实JSON正文可解析为 `{"ok":true}`；双模拟Schema布尔字段校验成功。模拟上游格式400却成为502，D6。Responses原生约束字段写成response_format而非text.format，但本地校验有效，按允许的“提示+本地校验”口径不另扣分。 | real-results.json；teacher-results.json / F03-* |
| F04 | 通过：双协议非法文本、空正文、截断 `{"ok":`、合法JSON但字段类型错误均422/STRUCTURED_OUTPUT_FAILED。无自动修复实现，修复后再次校验分支不适用；未将“不支持修复”当缺陷。 | teacher-results.json / F04-* |
| F05 | 通过：原模板v1/v2/v1实际进入上游且替换正确；教师独立模板先发布v1，再增添v2，再引v1，OLD cobalt保留、NEW cobalt可用。 | teacher-results.json / F05；supplement-results.json / F05-publication |
| F06 | 通过：缺模板404，缺版本400，漏必要变量400；均没有上游请求或未替换占位符泄漏。 | teacher-results.json / F06-* |
| F07 | 部分失败：普通/流式/上游失败均可查账；真实总耗时与正文TTFT有值。推理/缓存分类及Anthropic最终输入累计量丢失 D3，缺请求关联 D4，结构校验失败已知Token清零 D5。模板前置错误账本为空仅记录观察，不追加扣分。 | teacher-results.json / F07-* 与 F01-*；supplement-results.json；real-results.json |
| F08 | 基本通过：前2次500后成功，实际3次，间隔约41/82ms；双协议流式首chunk前同样3次后成功。精确sleep探针证明正向jitter越界，D7。 | teacher-results.json / F08-retry；stream-retry-results.json；retry-probe.json |
| F09 | 通过次数与不可重试：持续500实际3次停止；400/401实际1次；流式持续失败及401也按3/1次停止。无SDK隐式重试。 | teacher-results.json / F09-*；stream-retry-results.json；upstream.py.txt；dependencies.txt |
| F10 | 部分通过：RPM=2，A依次200/200/429、B仍200；流式耗尽额度却HTTP200后断开，D8。未耗尽真实上游额度。 | teacher-results.json / F10、F10-stream |
| F11 | 通过：容量2、补充速率2/60，真实等待30.2秒（未改时钟），A恢复200。 | teacher.py；teacher-results.json / F11 |
| F12 | 通过范围：学生 `pytest tests/ -v` 为8 passed，覆盖六功能且有内容/次数断言；外部pytest插件将模拟上游改为400，原路由测试明确FAILED、显示502≠200，退出1。没有修改学生测试。不能把这8项通过视为所有边界都通过。 | student-tests.log；failure_plugin.py；student-deliberate-failure.log |

## D. 扣分证据（按根因去重）

以下命令在已安装的固定学生仓库下执行；先依 F 节启动教师服务，脚本结果保存在 `/tmp/ming-grade`。所有行号均为学生提交，不是教师脚本行号。

### D1. 别名不转换为上游本名：统一接口与适配器 −1

- 触发：配置注册 `deepseek-v4-pro` 的别名 `v4-pro`，入口model使用该别名。
- 期望：仍路由到正确适配器，并发出上游 `model=deepseek-v4-pro`。
- 实际：选择正确适配器，但上游请求仍为 `model=v4-pro`；模拟宽松返回不代表真实上游支持此别名。
- 命令：`.venv/bin/python /tmp/ming-grade/teacher.py`，定位 `A03-alias`。
- 证据：teacher-results.json / A03-alias 的 wire body；不声称已将该错误别名发至真实上游。
- 源码：`app/services/router.py:52–61` 解析后未转换；`app/services/adapters/openai_responses.py:84–89`、`anthropic_messages.py:96–100` 使用req.model。

### D2. 协议失败事件/无终态EOF被成功done掩盖：流式输出 −3

- 触发：两协议先输出Alpha，再发 `response.failed` / Anthropic `error`，或直接结束字节流而不发成功终态。
- 期望：客户端能识别失败，账本error；不得输出正常完成。输出后只允许1次上游请求。
- 实际：两协议都发正常 `done, finish_reason=stop`，账本success；请求数均1。真正ReadError则会报断流并记error，故保留“不重试”2分。
- 命令：同上，定位 `F02-error_event-*`、`F02-eof-*`，对照 `F02-disconnect-*`。
- 证据：teacher-results.json 上述条目的 events、usage、calls。
- 源码：`app/services/adapters/openai_responses.py:58–73`、`anthropic_messages.py:58–73` 仅分支识别正常事件，循环结束无条件done。错误记账是同一假成功根因，不在可观测性再次扣分。

### D3. Token分类及累计快照映射不全：可观测性 −3

- 触发：Responses给input13/output7/cached3/reasoning2；Anthropic给input13/cache_read3/cache_creation2/output7；流式最终快照再给input17/cache_read5/output7。
- 期望：保留上游实际提供的缓存和推理分类，区分子集，Anthropic总输入应含未缓存及缓存；流式以最终累计快照为准、不累加快照。
- 实际：Responses推理2消失；Anthropic缓存恒0，非流式输入13而非18，流式仍为初始13而非最终输入22（17+5），输出7。统一类只能表示3个字段，未说明被丢弃分类的计量口径。
- 命令：`PYTHONPATH=/tmp/ming-grade/student .venv/bin/python /tmp/ming-grade/supplement.py`；teacher.py 的 F01-flash 账本作流式对照。
- 证据：supplement-results.json；teacher-results.json / F01-deepseek-v4-flash；真实pro普通调用也有reasoning26/36但统一账本不含该分类。
- 源码：`app/schemas.py:52–62,84–95`；`openai_responses.py:154–161`；`anthropic_messages.py:59–73,127–134`。总量可由输入输出相加推导，不因未序列化total_tokens另扣分。

### D4. 账本没有调用关联标识：可观测性 −2

- 触发：响应id为resp_teacher，查询本次独立SQLite账本；真实调用返回UUID也同样检查。
- 期望：账本携带可与请求/响应对应的ID，而不只依靠模型和时间猜测。
- 实际：仅有自增行号id=1、模型、时间、用量等；响应id未入账，也无request_id/trace_id。
- 命令：teacher.py，定位 `F07-correlation`；真实对照real-results.json 的response.id与usage列表。
- 证据：teacher-results.json / F07-correlation；real-results.json。
- 源码：`app/services/gateway.py:311–332`；`app/services/usage.py:36–46,70–84`。保留记录查询与自增行号的1分。

### D5. 结构校验失败清空已知用量：可观测性 −2

- 触发：上游200，返回非法正文但已给input13/output7/cached3；本地JSON校验失败。
- 期望：返回422且记失败，仍保留这次真实已发生的已知用量。
- 实际：422正确，但失败记录全部Token为0；不能把“上游没提供”用于解释已提供的用量丢失。
- 命令：teacher.py，定位 `F07-invalid`；对应F04响应含已知usage作对照。
- 证据：teacher-results.json / F07-invalid；teacher_server.py 的response固定用量。
- 源码：`app/services/gateway.py:87–94,107–116` 用空Usage替换已获取响应。失败记录仍存在，保留1分；与D3的字段映射缺失是不同根因。

### D6. 不支持的结构化格式400被映射为502：统一错误与重试 −1

- 触发：带response_format的请求遇到受控上游HTTP400。
- 期望：统一错误结构及明确4xx（评分标准F03）；不可重试。
- 实际：`502 / UPSTREAM_ERROR / 上游返回400`，仅调用1次；错误包装和不重试正确，HTTP类别错误。
- 命令：teacher.py，定位 `F03-unsupported-format`。
- 证据：teacher-results.json / F03-unsupported-format。
- 源码：`app/services/gateway.py:237–244` 把所有不可重试HTTP错误统一设502。仅扣状态映射，不再扣JSON功能。

### D7. 正向jitter超出退避上界：统一错误与重试 −1

- 触发：总尝试3，base=0.04秒，cap=0.08秒，固定Random(0)；受控500、500、成功。
- 期望：第1/2次重试等待分别不超过0.04/0.08秒。不得仅凭请求间隔含调度开销认定越界。
- 实际：记录到传给真实asyncio.sleep的参数为0.0433776874、0.0860636352；实际上游3次，间隔约0.04495/0.08927秒。持续失败也是3次，400为1次。
- 命令：`PYTHONPATH=/tmp/ming-grade/student .venv/bin/python /tmp/ming-grade/retry_probe.py`。
- 证据：retry-probe.json，wait_requested与rubric_caps；teacher-results.json / F08及F09佐证实际次数。
- 源码：`app/services/gateway.py:252–255,307–309` 先min再加正向jitter。指数增长及次数上限均保留，仅扣上界部分1分。

### D8. 流式本地超限不返回HTTP429：按模型独立限流 −1

- 触发：模型A的RPM2额度耗尽后发送stream=true。
- 期望：在SSE响应头发送前返回HTTP429及统一错误。
- 实际：HTTP200、无事件、随后RemoteProtocolError；服务日志为response started后异常。非流式同状态为429、B仍200、30.2秒恢复均通过。
- 命令：teacher.py，定位 `F10-stream`。
- 证据：teacher-results.json / F10、F11、F10-stream；teacher-service.log。
- 源码：`app/api/routes.py:39–48` 直接返回StreamingResponse；`app/services/gateway.py:121–133` 在异步生成器执行时才检查限流。只在限流HTTP子项扣1，不再扣通用错误或流式终止分。

## E. 真实调用、模型协议ID、用量与延迟

仅DeepSeek官方，共10次有限请求，全部HTTP200、正文OK或合法JSON，无其他真实供应商。原配置flash改用当前官方 `deepseek-flash`，不是证明原别名可用。P=Responses `POST /responses`，F=Messages `POST /anthropic/v1/messages`。普通/JSON均使用上游response.id；所有上游x-request-id/request-id响应头均未提供，记为未知，不编造。

| 请求 | 协议/实际上游模型 | 上游响应ID | 输入/输出/总Token | 客户端总耗时ms | 学生账本总耗时/正文TTFT ms |
| --- | --- | --- | --- | ---: | --- |
| 普通P | P / deepseek-v4-pro | 5059403d-4897-48e6-aac9-17f4fcccacb5 | 91/28/119 | 1539.77 | 1531.70/— |
| 首轮流式P | P / deepseek-v4-pro | 未采集（学生done不暴露ID） | 91/30/121 | 1911.41 | 1907.73/1850.09 |
| JSON P | P / deepseek-v4-pro | 656908a5-c2b2-4f82-813c-8ec6e7f28fb9 | 115/42/157 | 1509.32 | 1504.58/— |
| 普通F | F / deepseek-flash | 9e5aba43-7cbf-4e57-82fe-f0cda465c461 | 38/2/40 | 811.52 | 807.42/— |
| 首轮流式F | F / deepseek-flash | 未采集（学生done不暴露ID） | 38/18/56 | 608.68 | 605.17/604.45 |
| JSON F | F / deepseek-flash | 12416401-18fb-4278-9893-e48349b06b97 | 62/6/68 | 773.13 | 769.45/— |
| 流追踪初轮P | P / deepseek-v4-pro | 未采集（教师未解压gzip，见限制） | 87/18/105 | 1729.07 | 1712.13/1711.01 |
| 流追踪初轮F | F / deepseek-flash | 未采集（教师未解压gzip，见限制） | 34/20/54 | 983.93 | 980.36/978.12 |
| 流追踪复测P | P / deepseek-v4-pro | b2bf9b6f-8b2e-48a5-a73d-64278352004e | 87/13/100 | 1778.63 | 1760.66/1709.18 |
| 流追踪复测F | F / deepseek-flash | 2fade709-1e13-4229-88ff-94357b9127e5 | 34/11/45 | 832.22 | 828.43/827.61 |

- 用量合计：输入677、输出188、总865（包含所有已知尝试；总量按上游/统一响应输入+输出，不将推理子集再次相加）。本批缓存均0，不用真实零缓存请求证明D3；D3另用非零缓存模拟。已提供的推理分类：普通P26、JSON P36、流追踪复测P11；学生均未保留分类。其他未直接采集的推理数量不反推。
- `real-results.json` 保存首6次上下游正文、路径/请求结构及独立账本；`real-stream-results.json` 保存复测2次原始可读SSE，终态包含用量与ID；`real-stream-initial-results.json` 保留中间2次成功下游及账本（不可读压缩追踪已替换说明）。原始ID缺口不当作真实调用失败，不扣学生环境分。
- 初轮教师SSE追踪误把gzip原始字节当UTF-8，不能恢复ID；诊断后只通过HTTP压缩协商关闭压缩，补测2次成功，未修改适配器。上述10次全部披露，不把早期缺失字段伪造为已采集。
- 真实请求的schema原生硬约束未验证；已验证json_object最终输出和本地Schema校验。结构化stream组合原题未强制，本次未测不扣分；非标准NaN、坏Schema引用等选做项未作为扣分门槛。
- TTFT按代码实际为首个非空正文增量，不是握手、心跳或reasoning；总延迟含实际上游及内部重试等待（真实批次每请求1次）。速度仅作观测，不用于排名扣分。
- 官方协议依据（2026-11-07读取）：https://api-docs.deepseek.com/guides/responses_api ，https://api-docs.deepseek.com/guides/anthropic_api 。官方支持当前模型名及不同路径/请求/流事件；Anthropic最终usage为累计快照，缓存输入需单独计入。

## F. 复现入口、交付复核与补交要求

### 复现

1. 将证据解包到 `/tmp/ming-grade`；学生源码在student-source.tar，解到 `/tmp/ming-grade/student`，或clone上述仓库并checkout固定提交。按README创建.venv并安装；`dependencies.txt` 记录本次实际版本。
2. 在学生目录运行 `cp gateway.example.yaml gateway.yaml`、`.venv/bin/pytest tests/ -v`。注入失败命令：`PYTHONPATH=/tmp/ming-grade:/tmp/ming-grade/student .venv/bin/pytest tests/test_gateway.py::test_ac1_dual_protocol_routing -v -p failure_plugin`，预期1 failed、退出1。
3. 启动教师受控服务：`amp orb service start ming-teacher --command 'PYTHONPATH=/tmp/ming-grade:/tmp/ming-grade/student /tmp/ming-grade/student/.venv/bin/uvicorn teacher_server:app --host 0.0.0.0 --port 8182' --port 8182`。确认ready后运行 `.venv/bin/python /tmp/ming-grade/teacher.py`、`.venv/bin/python /tmp/ming-grade/stream_retry.py`；前者包含真实等待30.2秒的恢复检查。
4. 独立探针：`PYTHONPATH=/tmp/ming-grade/student .venv/bin/python /tmp/ming-grade/supplement.py` 与同方式运行retry_probe.py。教师脚本的pass字段是具体断言，不按通过比例换算分数。
5. 真实调用需用户已有个人环境变量；不将值写入配置或命令。运行同方式的real.py及stream_real.py（会新增真实费用）。real-config.json只含变量名称，不含凭据；数据库路径均为独立教师数据，不依赖学生本机隐藏文件。
6. 使用 `amp orb service stop ming-teacher` 停服务。本次README服务和教师服务均已停止；未提交、推送或部署。

### 复核与归档

- 归档：`G20247674020017-evidence.tar.gz`，包含教师脚本、无密钥配置、日志、JSON结果、固定源码快照和编号源码、依赖与命令说明、SHA256SUMS。
- 不打包.venv、.git、环境转储、密钥文件或认证头值；对全部交付文件及嵌套源码tar进行实际密钥值与常见凭据模式扫描。扫描结果及格式/分数自动核对见archive中的validation.json。
- 简明报告各节3–5条且≤500字；8项分数合计86，扣分合计14，等级按≥80为优秀。真实和模拟证据分开，模拟500不冒充真实上游故障。
- 必须修复：D1–D8。应补充关联ID、非零缓存与推理分类、校验失败用量、SSE错误/EOF、流式429、上游格式400及退避上界回归证据。复验保持两种协议真实接入，且上述断言全部符合预期。
- 本次代码逻辑未改；报告与证据仅为工作区新增文件，未提交推送。环境替代配置、未采集ID及未测组合均已明确，不扣环境分。
