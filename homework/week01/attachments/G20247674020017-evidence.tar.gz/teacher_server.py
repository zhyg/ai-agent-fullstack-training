import asyncio, json, time
from pathlib import Path
import httpx
from fastapi import Request
from app.main import create_app
from app.config import load_config
from app.services.usage import UsageService
from app.services.prompts import PromptService
from app.core.rate_limit import RateLimiter

state={'mode':'normal','calls':[]}
gate=asyncio.Event()
cfg=load_config()
cfg.rate_limit.enabled=False
cfg.retry.initial_backoff_seconds=.04
cfg.retry.max_backoff_seconds=.08
for p in cfg.providers:
    p.base_url='https://mock.invalid'
    p.api_key_env='TEACHER_UNUSED_KEY'

def event(data): return ('data: '+json.dumps(data)+'\n\n').encode()
def response(body,text='{"ok":true}',finish=None):
    if 'input' in body:
        return {'id':'resp_teacher','status':finish or 'completed','output':[{'type':'message','content':[{'type':'output_text','text':text}]}],'usage':{'input_tokens':13,'output_tokens':7,'input_tokens_details':{'cached_tokens':3},'output_tokens_details':{'reasoning_tokens':2},'total_tokens':20}}
    return {'id':'msg_teacher','content':[{'type':'text','text':text}],'stop_reason':finish or 'end_turn','usage':{'input_tokens':13,'output_tokens':7,'cache_read_input_tokens':3,'cache_creation_input_tokens':2}}

class Stream(httpx.AsyncByteStream):
    def __init__(self,body): self.body=body
    async def __aiter__(self):
        pro='input' in self.body
        yield b': heartbeat\n\n'
        await asyncio.sleep(.15)
        if not pro:
            yield event({'type':'message_start','message':{'usage':{'input_tokens':13,'cache_read_input_tokens':3}}})
        yield event({'type':'response.output_text.delta','delta':'Alpha'} if pro else {'type':'content_block_delta','delta':{'type':'text_delta','text':'Alpha'}})
        if state['mode']=='gate':
            await asyncio.wait_for(gate.wait(),8)
        if state['mode']=='disconnect': raise httpx.ReadError('teacher injected disconnect')
        if state['mode']=='eof': return
        if state['mode']=='error_event':
            yield event({'type':'response.failed','response':{'error':{'message':'teacher failed'}}} if pro else {'type':'error','error':{'type':'overloaded_error','message':'teacher failed'}})
            return
        if pro:
            yield event({'type':'response.completed','response':response(self.body)})
        else:
            yield event({'type':'message_delta','usage':{'input_tokens':17,'output_tokens':7,'cache_read_input_tokens':5},'delta':{'stop_reason':'end_turn'}})
            yield event({'type':'message_stop'})

async def handler(r):
    body=json.loads(r.content)
    state['calls'].append({'time':time.monotonic(),'path':r.url.path,'body':body,'auth_scheme':'Bearer' if 'authorization' in r.headers else 'x-api-key'})
    mode=state['mode']; n=len(state['calls'])
    code=500 if mode=='always500' or mode=='retry' and n<3 else 400 if mode=='bad400' else 401 if mode=='bad401' else 200
    if code!=200: return httpx.Response(code,json={'error':{'message':'teacher injected'}})
    if body.get('stream'): return httpx.Response(200,headers={'content-type':'text/event-stream'},stream=Stream(body))
    text={'invalid':'not JSON','empty':'','truncated':'{"ok":','schema':'{"ok":"wrong"}'}.get(mode,'{"ok":true}')
    return httpx.Response(200,json=response(body,text,'incomplete' if mode=='truncated' and 'input' in body else 'max_tokens' if mode=='truncated' else None))

app=create_app(cfg,transport=httpx.MockTransport(handler))
@app.post('/teacher/reset')
async def reset(r:Request):
    options=await r.json(); state.update(mode=options.get('mode','normal'),calls=[])
    gate.clear()
    conf=cfg.model_copy(deep=True); conf.rate_limit.enabled=options.get('rate',False)
    for p in conf.providers:
        for m in p.models: m.rate_limit_per_minute=2
    app.state.rate_limiter=app.state.gateway.rate_limiter=RateLimiter(conf)
    db=Path('/tmp/ming-grade')/('teacher-usage-'+str(time.time_ns())+'.db')
    app.state.usage=app.state.gateway.usage=UsageService(db)
    return {'reset':True}
@app.post('/teacher/release')
async def release(): gate.set(); return {'released':True}
@app.get('/teacher/state')
async def get_state(): return {'mode':state['mode'],'calls':state['calls'],'released':gate.is_set()}
