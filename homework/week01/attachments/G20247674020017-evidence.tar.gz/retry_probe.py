import asyncio, json, random, types, time
from pathlib import Path
import httpx
import app.services.gateway as module
from app.main import create_app
from app.config import load_config
from app.schemas import GatewayRequest, Message
from app.services.usage import UsageService

async def main():
    cfg=load_config(); cfg.rate_limit.enabled=False
    cfg.retry.initial_backoff_seconds=.04; cfg.retry.max_backoff_seconds=.08
    records=[]; waits=[]; calls=[]
    async def sleep(delay):
        waits.append(delay); await asyncio.sleep(delay)
    module.asyncio=types.SimpleNamespace(sleep=sleep)
    module.random=random.Random(0)
    for mode in ['recover','exhaust','bad400']:
        waits.clear(); calls.clear()
        def handler(r):
            calls.append(time.monotonic())
            code=400 if mode=='bad400' else 500 if mode=='exhaust' or len(calls)<3 else 200
            return httpx.Response(code,json={'id':'retry_probe','output_text':'OK','usage':{'input_tokens':2,'output_tokens':1}})
        app=create_app(cfg,transport=httpx.MockTransport(handler))
        app.state.gateway.usage=UsageService('/tmp/ming-grade/retry-probe.db')
        try:
            await app.state.gateway.chat(GatewayRequest(model='deepseek-v4-pro',messages=[Message(role='user',content='hi')]))
            outcome='success'
        except Exception as e: outcome=type(e).__name__
        records.append({'mode':mode,'outcome':outcome,'actual_upstream_calls':len(calls),'wait_requested':list(waits),'call_intervals':[b-a for a,b in zip(calls,calls[1:])],'rubric_caps':[.04,.08][:len(waits)]})
        await app.state.http_client.aclose()
    Path('/tmp/ming-grade/retry-probe.json').write_text(json.dumps(records,indent=2))

if __name__=='__main__': asyncio.run(main())
