import asyncio, json, time
from pathlib import Path
import httpx
from app.config import GatewayConfig
from app.main import create_app
from app.services.usage import UsageService

ROOT=Path('/tmp/ming-grade')
class Tap(httpx.AsyncByteStream):
    def __init__(self,inner,record): self.inner=inner; self.record=record
    async def __aiter__(self):
        async for b in self.inner:
            self.record['raw_sse']+=b.decode('utf-8',errors='replace')
            yield b
    async def aclose(self): await self.inner.aclose()

async def main():
    app=create_app(GatewayConfig(**json.loads((ROOT/'real-config.json').read_text())))
    app.state.http_client.headers['accept-encoding']='identity'
    app.state.gateway.usage=app.state.usage=UsageService(ROOT/'real-stream-usage.db')
    records=[]
    async def hook(r):
        rec={'model':json.loads(r.request.content)['model'],'url':str(r.url),'http_status':r.status_code,'raw_sse':''}
        records.append(rec); r.stream=Tap(r.stream,rec)
    app.state.http_client.event_hooks={'response':[hook]}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://student') as c:
        for m in ['deepseek-v4-pro','deepseek-flash']:
            start=time.monotonic()
            try:
                r=await asyncio.wait_for(c.post('/v1/chat/completions',json={'model':m,'messages':[{'role':'user','content':'Return only OK.'}],'stream':True,'max_tokens':512}),45)
                records[-1]['downstream']=r.text
            except Exception as e:
                if records: records[-1]['unverified']=type(e).__name__
            if records: records[-1]['elapsed_ms']=(time.monotonic()-start)*1000
            (ROOT/'real-stream-results.json').write_text(json.dumps({'wire':records,'ledger':[x.model_dump() for x in app.state.usage.list()]},ensure_ascii=False,indent=2))
    await app.state.http_client.aclose()

if __name__=='__main__': asyncio.run(main())
