import base64, hashlib, io, json, os, re, shutil, subprocess, tarfile
from pathlib import Path

ROOT=Path('/tmp/ming-grade')
REPO=Path('/home/user/workspace/repo')
FEEDBACK=REPO/'homework/week01/G20247674020017.md'
ASSESSMENT=REPO/'homework/week01/attachments/G20247674020017.md'
DEST=ROOT/'evidence'
ARCHIVE=ASSESSMENT.with_name('G20247674020017-evidence.tar.gz')

files=['real.py','teacher_server.py','teacher.py','failure_plugin.py','stream_real.py','retry_probe.py','supplement.py','stream_retry.py','pack_validate.py','real-config.json','real-results.json','real-stream-results.json','real-stream-initial-results.json','teacher-results.json','retry-probe.json','stream-retry-results.json','supplement-results.json','install.log','student-tests.log','student-deliberate-failure.log','dependencies.txt','readme-start.json','readme-service.log','teacher-service.log','teacher.log','real.log','real-stream.log','commit.txt','student-worktree.txt','student-source.tar']
DEST.mkdir(exist_ok=True)
for name in files:
    src=ROOT/name
    assert src.exists(),name
    if name=='real-stream-initial-results.json':
        data=json.loads(src.read_text())
        for wire in data['wire']:
            wire['raw_sse']='[Not captured: teacher decoded gzip transport bytes as UTF-8; downstream/ledger remain valid; see identity-encoding rerun.]'
        (DEST/name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
    else: shutil.copy2(src,DEST/name)
shutil.copy2(FEEDBACK,DEST/'feedback.md')
shutil.copy2(ASSESSMENT,DEST/'assessment.md')

feedback=FEEDBACK.read_text(); assessment=ASSESSMENT.read_text()
sections={}
for n,title in [(2,'作业优点'),(3,'作业不足'),(4,'改进方案')]:
    text=feedback.split(f'**{n}. {title}**')[1].split('**')[0]
    items=[line for line in text.splitlines() if line.startswith('- ')]
    count=len(re.sub(r'\s+','',text))
    assert 3<=len(items)<=5 and count<=500,(title,len(items),count)
    sections[title]={'items':len(items),'characters_without_whitespace':count}
scores=[(int(a),int(b)) for a,b in re.findall(r'^\| (?!\*\*合计)[^|]+ \| (\d+)/(\d+) \|',assessment,re.M)]
assert len(scores)==8 and sum(x for x,y in scores)==86 and sum(y for x,y in scores)==100,scores
assert '作业等级：优秀（86分）' in feedback
deductions=[int(n) for n in re.findall(r'^### D\d\..*? −(\d+)$',assessment,re.M)]
assert len(deductions)==8 and sum(deductions)==14
for code in [f'A{i:02}' for i in range(1,5)]+[f'F{i:02}' for i in range(1,13)]:
    assert f'| {code} |' in assessment,code
for letter in 'ABCDEF': assert f'## {letter}.' in assessment
for p in DEST.glob('*.py'): compile(p.read_text(),str(p),'exec')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'student',text=True).strip()=='db9e4fe36ed867f219d81f26ce63544913e74fbb'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/'student',text=True).strip()
services=subprocess.check_output(['amp','orb','service','list'],text=True)
assert 'No orb services are running' in services,services

real=json.loads((ROOT/'real-results.json').read_text())
assert len(real['results'])==6 and all(x['status']==200 for x in real['results'])
for r in real['results']:
    if r['kind']=='plain': assert json.loads(r['body'])['content']=='OK'
    if r['kind']=='json': assert json.loads(json.loads(r['body'])['content'])=={'ok':True}
    if r['kind']=='stream': assert '"type": "chunk"' in r['body'] and '"type": "done"' in r['body']
ledger=list(real['usage'])
for f in ['real-stream-initial-results.json','real-stream-results.json']:
    x=json.loads((ROOT/f).read_text()); ledger+=x['ledger']
    assert len(x['wire'])==2 and all(w['http_status']==200 for w in x['wire'])
assert len(ledger)==10
total_in=sum(r['input_tokens'] for r in ledger); total_out=sum(r['output_tokens'] for r in ledger)
assert (total_in,total_out)==(677,188),(total_in,total_out)
teacher=json.loads((ROOT/'teacher-results.json').read_text())
stream_retry=json.loads((ROOT/'stream-retry-results.json').read_text())
assert len(stream_retry)==6 and all(r['pass'] for r in stream_retry)

secrets=[]
for name,value in os.environ.items():
    # Secret-name metadata contains symbolic variable names, not credentials.
    if not name.endswith('_NAMES') and re.search(r'(KEY|TOKEN|PASSWORD|SECRET)',name,re.I) and len(value)>=12:
        raw=value.encode(); secrets.extend([raw,base64.b64encode(raw)])
assert os.environ.get('DEEPSEEK_API_KEY'),'existing key missing during scan'
patterns=[re.compile(rb'sk-[A-Za-z0-9_-]{20,}'),re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}'),re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'https?://[^/\s:@]+:[^/\s@]+@')]
scanned=0; hits=[]
def scan(name,data):
    global scanned
    scanned+=1
    if any(v in data for v in secrets) or any(p.search(data) for p in patterns): hits.append(name)
    if name.endswith('.tar'):
        with tarfile.open(fileobj=io.BytesIO(data)) as nested:
            for m in nested.getmembers():
                if m.isfile(): scan(name+'!'+m.name,nested.extractfile(m).read())
for p in DEST.rglob('*'):
    if p.is_file() and p.name not in ['SHA256SUMS','validation.json']: scan(str(p.relative_to(DEST)),p.read_bytes())
assert not hits,{'credential_hit_files':hits}
validation={'score':86,'max_score':100,'deduction_total':14,'grade':'优秀','conclusion':'通过，需修复','sections':sections,'A01_A04_F01_F12_documented':True,'teacher_assertions':{'total':len(teacher),'pass':sum(r['pass'] for r in teacher),'failed':sum(not r['pass'] for r in teacher)},'stream_retry_checks':6,'student_tests':'8 passed','injected_failure':'1 failed, exit 1 (expected)','real_requests':10,'input_tokens':total_in,'output_tokens':total_out,'total_tokens':total_in+total_out,'secret_scan':{'scanned_files_including_nested_source':scanned,'actual_key_value_and_encoded_scan':True,'pattern_scan':True,'credential_hits':0},'student_tracked_source_unchanged':True,'services_stopped':True,'committed':False,'pushed':False}
(DEST/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
manifest=[]
for p in sorted(DEST.rglob('*')):
    if p.is_file() and p.name!='SHA256SUMS': manifest.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(DEST)))
(DEST/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
with tarfile.open(ARCHIVE,'w:gz') as tar:
    for p in sorted(DEST.iterdir()): tar.add(p,arcname=p.name)
with tarfile.open(ARCHIVE,'r:gz') as tar:
    names=tar.getnames()
    assert not any('/.git/' in n or '/.venv/' in n for n in names)
    for m in tar.getmembers():
        if m.isfile(): scan('archive!'+m.name,tar.extractfile(m).read())
assert not hits,{'credential_hit_files':hits}
print(json.dumps(validation,ensure_ascii=False,indent=2))
print('Archive verified:',ARCHIVE.name,ARCHIVE.stat().st_size,'bytes')
