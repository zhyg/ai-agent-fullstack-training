     1	# my-llm-gateway
     2	
     3	统一大模型网关，通过**适配器模式**封装两种不同 API 协议（OpenAI Responses API 与 Anthropic Messages API），对外提供一致的 Chat 接口，支持流式输出、结构化输出、Prompt 版本管理、可观测性与韧性能力。
     4	
     5	## 特性
     6	
     7	- **统一抽象层**：根据 `model` 字段动态路由到对应协议适配器，屏蔽鉴权、请求体、返回格式差异
     8	- **流式输出**：`stream=true` 以 SSE 格式逐块返回
     9	- **结构化输出**：`response_format` 约束返回合法 JSON，自动提取与 Schema 校验
    10	- **Prompt 版本管理**：模板存储、变量替换、版本引用
    11	- **可观测性**：Token 分类消耗（input/output/cached）+ 总延迟 + 首 Token 延迟（TTFT）
    12	- **韧性**：统一错误码 + 指数退避重试（≤3 次）+ 按模型独立限流（超限 429）
    13	
    14	## 快速开始
    15	
    16	### 1. 安装依赖
    17	
    18	```bash
    19	python3 -m venv .venv
    20	source .venv/bin/activate
    21	pip install -e ".[dev]"
    22	```
    23	
    24	### 2. 配置
    25	
    26	复制示例配置并填入你的 API Key：
    27	
    28	```bash
    29	cp gateway.example.yaml gateway.yaml
    30	export DEEPSEEK_API_KEY="your-deepseek-key"
    31	export ANTHROPIC_API_KEY="your-anthropic-key"
    32	```
    33	
    34	配置文件中注册了两个模型，分别使用不同协议：
    35	
    36	| 模型 | 协议 | 说明 |
    37	|------|------|------|
    38	| `deepseek-v4-pro` | OpenAI Responses API | `POST /responses` |
    39	| `deepseek-v4-flash` | Anthropic Messages API | `POST /v1/messages` |
    40	
    41	### 3. 启动服务
    42	
    43	```bash
    44	uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
    45	```
    46	
    47	或使用 Docker：
    48	
    49	```bash
    50	docker-compose up --build
    51	```
    52	
    53	## API 接口
    54	
    55	### 聊天补全
    56	
    57	`POST /v1/chat/completions`
    58	
    59	#### 普通调用
    60	
    61	```bash
    62	curl -X POST http://localhost:8000/v1/chat/completions \
    63	  -H "Content-Type: application/json" \
    64	  -d '{
    65	    "model": "deepseek-v4-pro",
    66	    "messages": [{"role": "user", "content": "你好，请介绍一下你自己"}]
    67	  }'
    68	```
    69	
    70	响应：
    71	
    72	```json
    73	{
    74	  "id": "resp_xxx",
    75	  "model": "deepseek-v4-pro",
    76	  "content": "你好！我是...",
    77	  "usage": {
    78	    "input_tokens": 10,
    79	    "output_tokens": 20,
    80	    "cached_input_tokens": 0
    81	  },
    82	  "finish_reason": "stop"
    83	}
    84	```
    85	
    86	#### 流式输出
    87	
    88	```bash
    89	curl -N -X POST http://localhost:8000/v1/chat/completions \
    90	  -H "Content-Type: application/json" \
    91	  -d '{
    92	    "model": "deepseek-v4-pro",
    93	    "messages": [{"role": "user", "content": "写一首短诗"}],
    94	    "stream": true
    95	  }'
    96	```
    97	
    98	响应为 SSE 格式：
    99	
   100	```
   101	data: {"type": "chunk", "delta": "春"}
   102	data: {"type": "chunk", "delta": "眠"}
   103	...
   104	data: {"type": "done", "usage": {"input_tokens": 5, "output_tokens": 20, "cached_input_tokens": 0}, "finish_reason": "stop"}
   105	```
   106	
   107	#### 结构化输出
   108	
   109	```bash
   110	curl -X POST http://localhost:8000/v1/chat/completions \
   111	  -H "Content-Type: application/json" \
   112	  -d '{
   113	    "model": "deepseek-v4-pro",
   114	    "messages": [{"role": "user", "content": "提取用户信息"}],
   115	    "response_format": {
   116	      "type": "json_schema",
   117	      "json_schema": {
   118	        "type": "object",
   119	        "properties": {
   120	          "name": {"type": "string"},
   121	          "age": {"type": "integer"}
   122	        },
   123	        "required": ["name", "age"]
   124	      }
   125	    }
   126	  }'
   127	```
   128	
   129	#### Prompt 模板引用
   130	
   131	```bash
   132	curl -X POST http://localhost:8000/v1/chat/completions \
   133	  -H "Content-Type: application/json" \
   134	  -d '{
   135	    "model": "deepseek-v4-pro",
   136	    "messages": [{"role": "user", "content": "请总结"}],
   137	    "prompt": {
   138	      "name": "summarize",
   139	      "version": "v1",
   140	      "variables": {
   141	        "text": "这是一段很长的文章内容...",
   142	        "max_sentences": "3"
   143	      }
   144	    }
   145	  }'
   146	```
   147	
   148	模板定义在 `prompts/summarize.yaml`，缺失或多余变量会返回 400 错误。
   149	
   150	### Responses 接口（OpenAI Responses API 兼容）
   151	
   152	`POST /v1/responses`
   153	
   154	使用 `input` 字段（而非 `messages`），返回 `output_text`、`output`、`usage`。
   155	
   156	```bash
   157	curl -X POST http://localhost:8000/v1/responses \
   158	  -H "Content-Type: application/json" \
   159	  -d '{
   160	    "model": "deepseek-v4-pro",
   161	    "input": "你好，请介绍一下你自己"
   162	  }'
   163	```
   164	
   165	响应：
   166	
   167	```json
   168	{
   169	  "id": "resp_xxx",
   170	  "object": "response",
   171	  "model": "deepseek-v4-pro",
   172	  "output_text": "你好！我是...",
   173	  "output": [
   174	    {
   175	      "type": "message",
   176	      "role": "assistant",
   177	      "content": [{"type": "output_text", "text": "你好！我是..."}]
   178	    }
   179	  ],
   180	  "usage": {
   181	    "input_tokens": 10,
   182	    "output_tokens": 20,
   183	    "cached_input_tokens": 0
   184	  }
   185	}
   186	```
   187	
   188	`input` 支持三种形式：纯字符串、消息列表（content 为字符串）、消息列表（content 为 content 块数组）。也支持 `stream: true` 返回 SSE。
   189	
   190	### 模型列表
   191	
   192	`GET /v1/models`
   193	
   194	```bash
   195	curl http://localhost:8000/v1/models
   196	```
   197	
   198	### 用量查询
   199	
   200	`GET /v1/admin/usage?limit=10`
   201	
   202	```bash
   203	curl http://localhost:8000/v1/admin/usage
   204	```
   205	
   206	返回每条调用的 model、provider、input/output/cached tokens、total_ms、ttft_ms（流式）、status。
   207	
   208	## 错误响应
   209	
   210	所有错误返回统一结构：
   211	
   212	```json
   213	{
   214	  "code": "MODEL_NOT_FOUND",
   215	  "message": "未找到模型: unknown",
   216	  "type": "MODEL_NOT_FOUND"
   217	}
   218	```
   219	
   220	限流超限时返回 `429` 并附带 `Retry-After` 头。
   221	
   222	## 运行测试
   223	
   224	测试使用 `httpx.MockTransport` 模拟上游，无需真实网络：
   225	
   226	```bash
   227	pytest tests/ -v
   228	```
   229	
   230	## 项目结构
   231	
   232	```
   233	app/
   234	├── api/routes.py              # HTTP 路由
   235	├── core/
   236	│   ├── errors.py              # 统一错误码
   237	│   └── rate_limit.py          # 按模型限流
   238	├── services/
   239	│   ├── adapters/
   240	│   │   ├── base.py            # 适配器抽象基类
   241	│   │   ├── openai_responses.py# OpenAI Responses API 适配器
   242	│   │   └── anthropic_messages.py  # Anthropic Messages API 适配器
   243	│   ├── gateway.py             # 编排：重试、分流、Trace
   244	│   ├── upstream.py            # httpx 客户端
   245	│   ├── router.py              # 模型路由
   246	│   ├── prompts.py             # Prompt 版本管理
   247	│   ├── structured.py          # JSON 提取与校验
   248	│   └── usage.py               # SQLite 用量记录
   249	├── config.py                  # 配置加载
   250	├── schemas.py                 # Pydantic 模型
   251	└── main.py                    # 应用入口
   252	prompts/                       # Prompt 模板
   253	tests/                         # 自动化测试
   254	```
