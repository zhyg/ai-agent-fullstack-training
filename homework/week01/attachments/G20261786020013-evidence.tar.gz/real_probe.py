"""Run against the unchanged gateway. Output excludes all HTTP auth headers."""
import asyncio
import json
import os
import time
from pathlib import Path

import httpx


async def main():
    results = []
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18713', timeout=180,
                                headers={'Authorization': 'Bearer ' + os.environ['GRADE_LOCAL_KEY']}) as c:
        print('health', (await c.get('/healthz')).text, flush=True)
        for model in ('pro', 'flash'):
            for mode in ('plain', 'stream', 'json'):
                rid = f'real-{model}-{mode}'
                body = {'model': model, 'messages': [{'role': 'user', 'content':
                        'Return only {"ok":true} as JSON. No explanation.' if mode == 'json'
                        else 'Reply only OK. No explanation.'}], 'max_tokens': 1024}
                if mode == 'json':
                    body['response_format'] = {'type': 'json_object'}
                if mode == 'stream':
                    body['stream'] = True
                start = time.perf_counter()
                item = {'id': rid, 'model': model, 'mode': mode, 'request': body}
                try:
                    if mode == 'stream':
                        events = []
                        async with c.stream('POST', '/v1/chat/completions', json=body,
                                            headers={'X-Request-ID': rid}) as r:
                            item['http_status'] = r.status_code
                            async for line in r.aiter_lines():
                                if line.startswith('data: '):
                                    events.append({'ms': round((time.perf_counter()-start)*1000, 2),
                                                   'data': line[6:]})
                        item['events'] = events
                        content = ''
                        error = False
                        for e in events:
                            if e['data'] == '[DONE]':
                                continue
                            d = json.loads(e['data'])
                            error |= 'error' in d
                            content += d.get('choices', [{}])[0].get('delta', {}).get('content', '')
                        item['valid'] = bool(content) and not error and events[-1]['data'] == '[DONE]'
                        item['content'] = content
                    else:
                        r = await c.post('/v1/chat/completions', json=body, headers={'X-Request-ID': rid})
                        item['http_status'] = r.status_code
                        item['response'] = r.json()
                        content = r.json().get('choices', [{}])[0].get('message', {}).get('content', '')
                        item['valid'] = r.status_code == 200 and bool(content)
                        if mode == 'json' and item['valid']:
                            item['valid'] = json.loads(content) == {'ok': True}
                except Exception as exc:
                    item['exception_type'] = type(exc).__name__
                    item['valid'] = False
                item['elapsed_ms'] = round((time.perf_counter()-start)*1000, 2)
                results.append(item)
                print(json.dumps(item, ensure_ascii=False), flush=True)
        usage = (await c.get('/admin/usage', params={'limit': 200})).json()
        Path(__file__).with_name('real-results.json').write_text(
            json.dumps({'calls': results, 'usage': usage}, ensure_ascii=False, indent=2))


asyncio.run(main())
