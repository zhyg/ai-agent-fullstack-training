"""Validate the two reports and scan evidence without exposing secret values."""
import json
import os
from pathlib import Path
import re
import sys
import tarfile

root = Path(sys.argv[1]).resolve()
evidence = Path(__file__).parent
feedback = root / 'homework/week01/G20261786020013.md'
detail = root / 'homework/week01/attachments/G20261786020013.md'
archive = detail.with_name('G20261786020013-evidence.tar.gz')
text = feedback.read_text()
full = detail.read_text()
sections = {}
for n, label in [(2, '作业优点'), (3, '作业不足'), (4, '改进方案')]:
    marker = f'**{n}. {label}**\n\n'
    assert marker in text
    body = text.split(marker)[1].split('\n**')[0]
    bullets = [line[2:] for line in body.splitlines() if line.startswith('- ')]
    count = sum(len(b) for b in bullets)
    assert 3 <= len(bullets) <= 5 and count <= 500
    assert not re.search(r'扣分|评分标准|评分依据', body)
    sections[label] = {'items': len(bullets), 'characters': count}

rows = re.findall(r'^\| ([^|]+) \| (\d+) \| (\d+) \|', full, re.M)
score_rows = [(name.strip(), int(maximum), int(score)) for name, maximum, score in rows if name.strip() != '合计']
assert len(score_rows) == 8
assert sum(r[1] for r in score_rows) == 100
assert sum(r[2] for r in score_rows) == 85
assert '优秀（85分）' in text
assert len(re.findall(r'^### D\d+ ', full, re.M)) == 10
assert sum(map(int, re.findall(r'^### D\d+ .*?扣(\d+)', full, re.M))) == 15
for i in range(1, 5):
    assert f'A{i:02}' in full
for i in range(1, 13):
    assert f'F{i:02}' in full
real = json.loads((evidence/'real-results.json').read_text())
assert len(real['calls']) == 6 and all(x['valid'] for x in real['calls'])
for row in real['usage']['data']:
    assert row['total_tokens'] == row['input_tokens'] + row['output_tokens']
    assert f"{row['latency_ms']:.3f}" in full

secrets = [v.encode() for k, v in os.environ.items() if
           k != 'AMP_SECRET_ENV_NAMES' and
           re.search(r'(API_KEY|TOKEN|PASSWORD|SECRET|CREDENTIAL)', k, re.I) and len(v) > 10]
paths = [feedback, detail] + [p for p in evidence.iterdir() if p.is_file()]
for path in paths:
    data = path.read_bytes()
    assert not any(s in data for s in secrets), f'secret detected in {path.name}'
    if path.suffix in ('.log', '.json', '.txt'):
        assert not re.search(rb'(?i)(?:authorization|x-api-key)["\x27]?\s*:\s*["\x27]?(?:Bearer\s+)?[A-Za-z0-9_-]{15,}', data), path.name

result = {'feedback_sections': sections, 'scores': score_rows, 'sum': 85, 'level': '优秀',
          'deductions': 15, 'real_validated': 6, 'secret_scan': 'passed', 'archive': 'pending'}
if archive.exists():
    with tarfile.open(archive) as tar:
        names = tar.getnames()
        assert not any(Path(n).name.startswith('.env') or n.endswith(('.db', '.sqlite3')) for n in names)
        for entry in tar.getmembers():
            if entry.isfile():
                assert not any(s in tar.extractfile(entry).read() for s in secrets), entry.name
        result['archive'] = {'members': len(names), 'no_env_database_credentials': True}
(evidence/'validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False, indent=2))
