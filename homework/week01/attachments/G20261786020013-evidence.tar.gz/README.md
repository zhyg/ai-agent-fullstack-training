# 雷锋剑第一次提交独立评测证据

仓库 https://github.com/zheng0324jian/ai-agent-llm-gateway.git ，固定作业分支提交 f44b998791f0d286e0e7c83eb61127f55ba833e4。

本次评测的完整判分与边界见课程仓库 `homework/week01/attachments/G20261786020013.md`，反馈见同级上层学员报告。禁止把受控测试当真实模型证明。

## 文件

- install.log / dependencies.txt：本次干净venv安装及版本。
- pytest.log / ruff.log / verify.log：学生脚本本次执行输出，不是学生提交的历史输出。
- controlled_probe.py / controlled.log / controlled-results.json：受控双协议请求、JSON、模板、重试、账本、实际TCP SSE门控、断流、UTF-8分片、限流隔离恢复及脚本故障注入。
- real-config.yaml / real_probe.py / real.log / real-results.json：只调用DeepSeek官方的真实双协议双模型普通/流式/JSON，含模型映射、用量、耗时与请求ID；没有鉴权头记录。
- server.log：真实Uvicorn启动与官方上游路径/HTTP状态日志。
- source-review.txt：固定提交中按文件名/行号摘录的源码，供复核异常分支。
- provenance-and-cleanup.txt：固定提交、文件清单、无源码改动及最终无监听。
- validation.json：报告字数、条数、分数合计、秘密扫描与归档检查结果。

## 复现

在独立目录clone仓库，checkout上述提交，创建venv后按README安装 `pip install -e '.[dev]'`，运行pytest、ruff和scripts/verify.py。

将本目录作为evidence保留在student旁，设置 `PYTHONPATH=student` 后运行 `venv/bin/python evidence/controlled_probe.py`。此脚本不访问网络模型，有限期创建18714测试监听并在finally关闭；`passed`只代表该条明确的断言，未作断言的观察为null，不能计算通过率作为作业分数。

真实复现需要在进程环境提供DEEPSEEK_API_KEY及自行选择的GRADE_LOCAL_KEY。将real-config.yaml的database_url改成可写临时路径，以GATEWAY_CONFIG指向配置启动学生Uvicorn端口18713，再运行real_probe.py。真实测试消耗Token，不能把本次成功推断为未来上游永远可用；所有headers只在内存构造，不写日志。不需要.env，不接受其他供应商密钥。
