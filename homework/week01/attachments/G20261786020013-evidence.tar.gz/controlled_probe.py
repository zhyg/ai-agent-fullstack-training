"""Independent finite tests; MockTransport only, never connects model vendors.
Run with PYTHONPATH=student <venv>/bin/python evidence/controlled_probe.py.
The TCP gate uses the real ASGI app and Uvicorn, not ASGITransport buffering.
"""
import asyncio
import importlib.util
import json
import logging
import sys
import time
from pathlib import Path

import httpx
import uvicorn

from app.main import create_app
from tests.conftest import (anthropic_payload, auth_headers, gateway_client,
                            make_config, responses_payload, sse_bytes)

logging.getLogger('httpx').setLevel(logging.WARNING)
OUT = Path(__file__).parent
observations = []


def save(name, actual, passed=None):
    item = {'case': name, 'actual': actual, 'passed': passed}
    observations.append(item)
    print(json.dumps(item, ensure_ascii=False), flush=True)


async def chat(c, model='pro', **extra):
    return await c.post('/v1/chat/completions', headers=auth_headers(), json={
        'model': model, 'messages': [{'role': 'user', 'content': 'hello'}], **extra})


async def records(c):
    return (await c.get('/admin/usage', headers=auth_headers(), params={'limit': 200})).json()['data']


async def basic():
    calls = []
    def handler(req):
        calls.append({'path': req.url.path, 'body': json.loads(req.content)})
        return httpx.Response(200, json=responses_payload() if req.url.path.endswith('responses')
                              else anthropic_payload())
    async with gateway_client(handler) as (c, _):
        for m in ('pro', 'flash'):
            r = await chat(c, m)
            save('A03-'+m, {'response': r.json(), 'sent': calls[-1]}, r.status_code == 200)
        before = len(calls)
        r = await chat(c, 'unknown')
        rows = await records(c)
        save('A04', {'status': r.status_code, 'error': r.json(), 'extra_calls': len(calls)-before,
                     'failure_record_present': any(x['request_id'] == r.headers['x-request-id'] for x in rows)},
             r.status_code == 404 and len(calls) == before)
        for v in (1, 2):
            await c.post('/v1/prompts', headers=auth_headers(), json={
                'id': 't', 'content': 'version'+str(v)+' {{ who }}', 'activate': True})
        for v in (1, 2):
            for m in ('pro', 'flash'):
                r = await chat(c, m, gateway_prompt={'id': 't', 'version': v, 'variables': {'who': 'Ada'}})
                sent = calls[-1]['body']
                text = sent.get('instructions', sent.get('system', ''))
                save(f'F05-{m}-v{v}', {'status': r.status_code, 'sent_system': text}, text == f'version{v} Ada')
        for ref in ({'id': 'missing'}, {'id': 't', 'version': 999}, {'id': 't', 'version': 1}):
            before = len(calls)
            r = await chat(c, gateway_prompt=ref)
            save('F06', {'reference': ref, 'status': r.status_code, 'response': r.json(),
                         'extra_calls': len(calls)-before}, r.status_code in (404, 422) and len(calls) == before)


async def structured():
    for m in ('pro', 'flash'):
        for label, text in [('valid', '{"ok":true}'), ('illegal', 'not json'), ('empty', ''),
                            ('truncated', '{"ok":'), ('truncated_nested', '{"outer":{"x":1}'),
                            ('markdown', '```json\n{"ok":true}\n```')]:
            calls = []
            def handler(req):
                calls.append(json.loads(req.content))
                body = responses_payload(text) if m == 'pro' else anthropic_payload(text)
                if label.startswith('truncated'):
                    if m == 'pro':
                        body.update(status='incomplete', incomplete_details={'reason': 'max_output_tokens'})
                    else:
                        body['stop_reason'] = 'max_tokens'
                return httpx.Response(200, json=body)
            async with gateway_client(handler) as (c, _):
                r = await chat(c, m, response_format={'type': 'json_object'})
                valid_content = False
                if r.status_code == 200:
                    try:
                        json.loads(r.json()['choices'][0]['message']['content'])
                        valid_content = True
                    except ValueError:
                        pass
                rows = await records(c)
                save(f'F04-{m}-{label}', {'status': r.status_code, 'response': r.json(),
                     'calls': len(calls), 'record': rows[0], 'content_is_json': valid_content},
                     valid_content if label == 'valid' else (r.status_code != 200 or valid_content))
        # Schema mismatch and a valid reference control, plus unresolved reference.
        for label, schema in [('type_mismatch', {'type': 'object', 'required': ['n'], 'properties': {'n': {'type': 'integer'}}}),
                              ('ref_valid', {'$defs': {'answer': {'type': 'object'}}, '$ref': '#/$defs/answer'}),
                              ('ref_missing', {'$ref': '#/$defs/missing'})]:
            def handler(req):
                return httpx.Response(200, json=responses_payload('{"n":"wrong"}') if m == 'pro'
                                      else anthropic_payload('{"n":"wrong"}'))
            async with gateway_client(handler) as (c, app):
                # A fresh ASGITransport surfaces real 500 responses rather than raising server exceptions.
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app, raise_app_exceptions=False), base_url='http://gateway') as raw:
                    r = await chat(raw, m, response_format={'type': 'json_schema', 'json_schema': {'schema': schema}})
                    save(f'B02-{m}-{label}', {'status': r.status_code, 'body': r.text, 'records': await records(c)},
                         r.status_code == (200 if label == 'ref_valid' else 422))


async def retry_and_usage():
    for m in ('pro', 'flash'):
        for label, status in [('recover', 503), ('exhaust', 503), ('param', 400), ('auth', 401), ('upstream429', 429)]:
            calls, waits = [], []
            def handler(req):
                calls.append(time.perf_counter())
                if label == 'recover' and len(calls) == 3:
                    return httpx.Response(200, json=responses_payload('ok') if m == 'pro' else anthropic_payload('ok'))
                return httpx.Response(status, json={'error': {'message': 'controlled fault'}})
            async def sleeper(delay):
                waits.append(delay)
            cfg = make_config(retry={'max_attempts': 3, 'base_delay_seconds': 0.1, 'max_delay_seconds': 0.2})
            async with gateway_client(handler, cfg) as (c, app):
                app.state.container.gateway._sleep = sleeper  # documented injection seam, not business patch
                r = await chat(c, m)
                row = (await records(c))[0]
                save(f'F08-F09-{m}-{label}', {'status': r.status_code, 'response': r.json(),
                     'calls': len(calls), 'waits': waits, 'record': row,
                     'strict_cap_ok': all(w <= min(.2, .1*2**n) for n, w in enumerate(waits))},
                     len(calls) == (1 if status in (400, 401) else 3))
        for label, usage in [('details', {'input_tokens': 11, 'output_tokens': 5, 'total_tokens': 16,
                                         'input_tokens_details': {'cached_tokens': 7},
                                         'output_tokens_details': {'reasoning_tokens': 3}}),
                             ('missing', {})]:
            if m == 'flash' and usage:
                usage = {'input_tokens': 11, 'output_tokens': 5, 'cache_read_input_tokens': 7,
                         'cache_creation_input_tokens': 3}
            def handler(req):
                body = responses_payload('ok') if m == 'pro' else anthropic_payload('ok')
                body['usage'] = usage
                return httpx.Response(200, json=body)
            async with gateway_client(handler) as (c, _):
                r = await chat(c, m)
                save(f'F07-{m}-{label}', {'upstream_usage': usage, 'result': r.json(), 'records': await records(c)})


class Gate(httpx.AsyncByteStream):
    def __init__(self, model, mode, release):
        self.model, self.mode, self.release = model, mode, release
    async def __aiter__(self):
        m = self.model
        event = ('response.output_text.delta', {'delta': 'hello'}) if m == 'pro' else (
            'content_block_delta', {'delta': {'type': 'text_delta', 'text': 'hello'}})
        yield b': heartbeat\n\n'
        yield sse_bytes([event])
        if self.mode == 'gate':
            await self.release.wait()
        if self.mode == 'drop':
            raise httpx.ReadError('controlled drop after content')
        if self.mode == 'eof':
            return
        if self.mode == 'error_event':
            yield sse_bytes([('error', {'error': {'message': 'controlled error'}})])
            return
        if self.mode == 'utf8':
            text_event = ('response.output_text.delta', {'delta': '汉字'}) if m == 'pro' else (
                'content_block_delta', {'delta': {'type': 'text_delta', 'text': '汉字'}})
            data = sse_bytes([text_event])
            ix = data.index('汉'.encode()) + 1
            yield data[:ix]
            yield data[ix:]
        if m == 'pro':
            yield sse_bytes([('response.completed', {'response': {'usage': {'input_tokens': 11, 'output_tokens': 5,
                'input_tokens_details': {'cached_tokens': 7}, 'output_tokens_details': {'reasoning_tokens': 3}}}})])
        else:
            yield sse_bytes([('message_delta', {'delta': {'stop_reason': 'end_turn'}, 'usage': {'output_tokens': 5}}),
                              ('message_stop', {})])


async def stream_tcp():
    state = {'mode': 'gate', 'release': asyncio.Event(), 'calls': []}
    def handler(req):
        body = json.loads(req.content)
        state['calls'].append({'path': req.url.path, 'body': body})
        m = 'pro' if req.url.path.endswith('responses') else 'flash'
        return httpx.Response(200, stream=Gate(m, state['mode'], state['release']), headers={'Content-Type': 'text/event-stream'})
    upstream = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    app = create_app(config=make_config(), http_client=upstream)
    server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=18714, log_level='warning'))
    task = asyncio.create_task(server.serve())
    try:
        while not server.started:
            if task.done():
                await task
            await asyncio.sleep(.01)
        async with httpx.AsyncClient(base_url='http://127.0.0.1:18714', timeout=5) as c:
            for m in ('pro', 'flash'):
                for mode in ('gate', 'drop', 'error_event', 'eof', 'utf8'):
                    state.update(mode=mode, release=asyncio.Event())
                    before = len(state['calls'])
                    start = time.perf_counter()
                    events = []
                    gate_ok = None
                    async with c.stream('POST', '/v1/chat/completions', headers=auth_headers(), json={
                        'model': m, 'stream': True, 'messages': [{'role': 'user', 'content': 'hi'}]}) as r:
                        async for line in r.aiter_lines():
                            if not line.startswith('data: '):
                                continue
                            events.append({'ms': round((time.perf_counter()-start)*1000, 3), 'data': line[6:]})
                            if mode == 'gate' and 'hello' in line:
                                gate_ok = not state['release'].is_set()
                                state['release'].set()
                    rid = r.headers['x-request-id']
                    rows = await records(c)
                    row = next(x for x in rows if x['request_id'] == rid)
                    save(f'F01-F02-{m}-{mode}', {'http_status': r.status_code, 'gate_before_terminal': gate_ok,
                        'calls': len(state['calls'])-before, 'events': events, 'record': row},
                         gate_ok if mode == 'gate' else (
                             row['status'] == 'error' and len(state['calls'])-before == 1
                             if mode in ('drop', 'error_event', 'eof') else
                             any('汉字' in e['data'] for e in events)))
    finally:
        server.should_exit = True
        await task
        await upstream.aclose()


async def rate():
    def handler(req):
        return httpx.Response(200, json=responses_payload() if req.url.path.endswith('responses') else anthropic_payload())
    cfg = make_config(rate_limit={'enabled': True, 'requests_per_minute': 120, 'burst': 1})
    async with gateway_client(handler, cfg) as (c, _):
        a, b, other = await chat(c), await chat(c), await chat(c, 'flash')
        sr = await chat(c, stream=True)
        await asyncio.sleep(.55)
        recovered = await chat(c)
        save('F10-F11', {'first': a.status_code, 'limited': b.status_code, 'other': other.status_code,
                         'stream_limited': sr.status_code, 'stream_body': sr.text, 'recovered': recovered.status_code},
             [a.status_code, b.status_code, other.status_code, recovered.status_code] == [200, 429, 200, 200]
             and sr.status_code == 429)


async def fault_verify():
    spec = importlib.util.spec_from_file_location('student_verify', Path(__import__('app').__file__).parent.parent / 'scripts/verify.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    original = module.MockUpstream._responses
    def bad(self, body):
        if not body.get('stream') and 'text' not in body:
            return httpx.Response(400, json={'error': {'message': 'teacher injected failure'}})
        return original(self, body)
    module.MockUpstream._responses = bad  # mutate test fixture only, never student business code
    code = await module.main()
    save('F12-injected-failure', {'exit_code': code}, code != 0)


async def combined_budget():
    for model in ('pro', 'flash'):
        calls = []
        def handler(req):
            calls.append(json.loads(req.content))
            if len(calls) not in (3, 6):
                return httpx.Response(503, json={'error': {'message': 'controlled transient'}})
            text = 'invalid' if len(calls) == 3 else '{"ok":true}'
            return httpx.Response(200, json=responses_payload(text) if model == 'pro' else anthropic_payload(text))
        async with gateway_client(handler) as (c, _):
            r = await chat(c, model, response_format={'type': 'json_object'})
            save('B06-combined-'+model, {'status': r.status_code, 'calls': len(calls),
                'response': r.json(), 'record': (await records(c))[0]}, r.status_code == 200 and len(calls) == 6)


async def main():
    for fn in (basic, structured, retry_and_usage, stream_tcp, rate, combined_budget, fault_verify):
        await fn()
    OUT.joinpath('controlled-results.json').write_text(json.dumps(observations, ensure_ascii=False, indent=2))


asyncio.run(main())
