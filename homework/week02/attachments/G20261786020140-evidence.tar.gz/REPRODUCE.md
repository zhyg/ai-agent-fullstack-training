# 离线复现

学员仓库 main 提交：60200a4cd7de2d877c445c1deac81c4f082d98cf。
课程仓库 feat/guide 提交：4877fc52195dbac72d1fa9caca6f1f9d7d972efc。
源码快照未改动；不含任何.env、凭据、虚拟环境或依赖目录。

在解压后的本目录运行；自行创建的虚拟环境放在包外：

```bash
python -m pip install -r student/requirements.txt
export PYTHONPATH="$PWD/student/src"
python -c 'import tool_governance_demo as d; print(d.__file__)'
python -m pytest trusted/tests/test_tool_governance.py -v -k transfer
python -m pytest test_additional.py -v -s
python student/run.py
sha256sum -c SHA256SUMS
```

可信五测5通过、补测10通过；原展示成功但缺转账关联审计打印，详见评测报告。补测打印显式标注TEACHER，不属于原提交展示。原题/原测/原始无答案源码在trusted/hw2/，可信执行副本在trusted/tests/，两者断言完全相同。

logs/ 保存原始执行结果及退出码；packaged-rerun.log 记录打包快照的再执行验证。日志中的安装是环境准备，不是模型调用。clone命令及退出码在评测报告，environment.log记录导入路径、版本、提交、工作区状态及原测哈希。
