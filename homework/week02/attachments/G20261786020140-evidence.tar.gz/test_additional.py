import ast
import asyncio
import inspect
import json
import time
from dataclasses import asdict, replace
from pathlib import Path

import pytest
import tool_governance_demo as d

ROOT = Path(__file__).resolve().parents[4]
BASE = {'from_account': 'ACC-A-123456', 'to_account': 'ACC-A-654321', 'amount': 1200.0}
INITIAL = {('tenant_a', 'ACC-A-123456'): 100000.0, ('tenant_a', 'ACC-A-654321'): 5000.0,
           ('tenant_a', 'ACC-A-888888'): 20000.0, ('tenant_b', 'ACC-B-111111'): 50000.0}

@pytest.fixture(autouse=True)
def isolated():
    snapshot = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(snapshot)

async def invoke(rt, args, approval=None, call='extra_123456', **ctx):
    return await rt.invoke(d.ToolCall(call, 'transfer', args), d.base_context(approval_id=approval, **ctx))

def run(coro):
    return asyncio.run(coro)

def test_A01_initial():
    assert d.ACCOUNTS == INITIAL
    assert all(type(v) is float for v in d.ACCOUNTS.values())
    print('A01', d.ACCOUNTS)

def test_A02_schema():
    async def scenario():
        cases = [{k:v for k,v in BASE.items() if k != missing} for missing in BASE]
        cases += [{**BASE, 'approved': True}, {**BASE, 'user_id': 'admin'}]
        cases += [{**BASE, 'amount': value} for value in (-1.0, '12.0', 0.0, 100000.01)]
        cases += [{**BASE, key: value} for key in ('from_account', 'to_account')
                  for value in ('ACC-A-12345', 'ACC-aa-123456', 'ACC-A-1234567', 123456)]
        for args in cases:
            rt, _, audit = d.build_runtime()
            result = await invoke(rt,args)
            assert result.code == 'INVALID_ARGUMENT'
            assert audit.records[-1].phase == 'decision'
            assert d.ACCOUNTS == INITIAL
        print('A02 rejected',len(cases),'invalid variants',d.TransferArgs.model_config)
    run(scenario())

def test_A03_boundaries():
    async def scenario():
        for amount, code, action in [(50000.,'APPROVAL_REQUIRED','confirm'),(50000.01,'EXCEED_LIMIT','deny'),
                                    (80000.,'EXCEED_LIMIT','deny'),(80000.01,'APPROVAL_REQUIRED','confirm'),
                                    (100000.,'APPROVAL_REQUIRED','confirm'),(100000.01,'INVALID_ARGUMENT','deny')]:
            rt, _, audit = d.build_runtime()
            result = await invoke(rt,{**BASE,'amount':amount})
            print('A03',amount,result.code,result.action)
            assert (result.code,result.action) == (code,action)
            assert audit.records[-1].phase == 'decision'
            assert d.ACCOUNTS == INITIAL
        for amount in (80000.01,100000.):
            rt, approvals, audit = d.build_runtime()
            args = {**BASE,'amount':amount}
            approvals.approve('a',d.base_context(),'transfer',args)
            start = time.perf_counter()
            result = await invoke(rt,args,'a')
            elapsed = time.perf_counter()-start
            print('A03 approved',amount,result.code,'elapsed',elapsed)
            assert result.code == 'TIMEOUT_UNKNOWN' and 1.8 < elapsed < 3
            assert d.ACCOUNTS == INITIAL
            assert audit.records[-1].phase == 'execution'
    run(scenario())

def test_A04_precheck_order_approval_retained():
    async def scenario():
        for amount,code in [(30000.,'INSUFFICIENT_BALANCE'),(60000.,'EXCEED_LIMIT')]:
            args = {**BASE,'from_account':'ACC-A-888888','amount':amount}
            for approved in (False,True):
                rt, approvals, audit = d.build_runtime()
                approvals.approve('a',d.base_context(),'transfer',args)
                result = await invoke(rt,args,'a' if approved else None)
                assert result.action == 'deny' and result.code == code
                assert audit.records[-1].phase == 'decision'
                assert not approvals._records['a'].used
                assert d.ACCOUNTS == INITIAL
                print('A04',amount,approved,code,'approval_used=False')
    run(scenario())

def test_A05_exact_balance():
    async def scenario():
        rt, approvals, _ = d.build_runtime()
        args = {**BASE,'from_account':'ACC-A-888888','amount':20000.}
        approvals.approve('a',d.base_context(),'transfer',args)
        result = await invoke(rt,args,'a')
        assert result.ok and d.ACCOUNTS[('tenant_a','ACC-A-888888')] == 0.
        assert d.ACCOUNTS[('tenant_a','ACC-A-654321')] == 25000.
        print('A05',asdict(result),d.ACCOUNTS)
    run(scenario())

def test_A06_missing_destination():
    async def scenario():
        rt, approvals, _ = d.build_runtime()
        args = {**BASE,'to_account':'ACC-A-999999'}
        approvals.approve('a',d.base_context(),'transfer',args)
        result = await invoke(rt,args,'a')
        assert (result.code,result.content) == ('ACCOUNT_NOT_FOUND','转入账户不存在')
        assert d.ACCOUNTS == INITIAL
        print('A06',asdict(result),'unchanged balances')
    run(scenario())

def test_A07_tenant_and_missing_source():
    async def scenario():
        for field,value,expected in [('from_account','ACC-B-111111','DEBIT_ACCOUNT_NOT_FOUND'),
                                      ('to_account','ACC-B-111111','ACCOUNT_NOT_FOUND'),
                                      ('from_account','ACC-A-999999','DEBIT_ACCOUNT_NOT_FOUND')]:
            rt, approvals, audit = d.build_runtime()
            args = {**BASE,field:value}
            approvals.approve('a',d.base_context(),'transfer',args)
            result = await invoke(rt,args,'a')
            assert result.code == expected and d.ACCOUNTS == INITIAL
            print('A07',field,value,result.code,audit.records[-1].phase)
    run(scenario())

def test_A08_policy():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    p = tool.policy
    assert p.effect == 'write' and (p.requires_approval or p.risk == 'high')
    assert p.permission == 'transfer:execute' and 0 < p.timeout_seconds < 3
    assert not p.idempotent and p.max_retries == 0
    variants = [BASE,{**BASE,'from_account':'ACC-A-888888'},
                {**BASE,'to_account':'ACC-A-888888'},{**BASE,'amount':1201.}]
    targets = [tool.canonical_target(d.TransferArgs.model_validate(args)) for args in variants]
    assert len(set(targets)) == 4
    print('A08',asdict(p),targets)

def test_A09_redaction_and_associated_audit():
    async def scenario():
        rt, approvals, audit = d.build_runtime()
        result = await invoke(rt,BASE,call='confirm_123456',trace_id='trace_extra')
        assert result.action == 'confirm'
        print('TEACHER supplementary confirmation',asdict(result))
        approvals.approve('a',d.base_context(),'transfer',BASE)
        result = await invoke(rt,BASE,'a',trace_id='trace_extra')
        assert result.content == {'txn_id':'123456','from':'ACC-A-****3456','to':'ACC-A-****4321','amount':1200.,'status':'accepted'}
        assert [(x.phase,x.code) for x in audit.records] == [('decision','APPROVAL_REQUIRED'),('decision','APPROVED'),('execution','OK')]
        assert all(x.trace_id == 'trace_extra' for x in audit.records)
        assert audit.records[-1].tool_call_id == 'extra_123456'
        print('TEACHER supplementary result',asdict(result))
        print('TEACHER supplementary audit',[asdict(x) for x in audit.records])
        replay = await invoke(rt,BASE,'a')
        assert replay.action == 'confirm'
        order = await rt.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),d.base_context())
        assert order.content['customer_email'] == '***@***' and order.content['access_token'] == '***'
        assert d._redact({'nested':[{'email':'foo@example.com','Authorization':'fake','account':'ACC-B-111111'}]}) == {'nested':[{'email':'***@***','Authorization':'***','account':'ACC-B-****1111'}]}
        print('A09 original order',asdict(order))
    run(scenario())

def test_A10_fixed_engine_and_test_entry():
    source = ROOT/'hw-guide/week02/hw2/tool_governance_demo-无答案.py'
    if not source.is_file():
        source = Path(__file__).parent/'trusted/hw2/tool_governance_demo-无答案.py'
    def method(text):
        tree = ast.parse(text)
        cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'PermissionEngine')
        return next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name == 'decide')
    baseline = source.read_text()
    student = Path(d.__file__).read_text()
    assert ast.get_source_segment(baseline,method(baseline)) == ast.get_source_segment(student,method(student))
    test = Path(d.__file__).parents[1]/'tests/test_tool_governance.py'
    assert test.read_bytes() == (source.parent/'test_tool_governance.py').read_bytes()
    assert 'transfer_handler(' not in test.read_text()
    print('A10 decide source byte-identical; submitted tests byte-identical; runtime.invoke entry')
