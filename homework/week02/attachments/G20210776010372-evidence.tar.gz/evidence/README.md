# 19547 离线评测证据

- 学员 Geek_122fe2，G20210776010372，main@7acbcd04cb072d2f64af30ca4aea54312c8417cf。
- 评测依据与完整评分见 reports/；trusted/ 是课程标准及可信原件，student/ 是指定 work/02 的 Python 源码及学员自测快照。
- logs/original.log：可信五测均为 setup ERROR，业务断言未执行，不是五个业务失败。
- logs/student_tests.log：学员自测 10 passed；logs/student_demo.log：学员自己提供的展示，直接执行所得。
- logs/supplement.log：教师直接调用学员原生 Runtime 的补充观察；脚本对已确认契约差异也作事实断言，因此脚本退出 0 不表示所有作业要求通过。
- logs/permission-engine.diff：固定权限引擎实际差异；logs/integrity.log：源码无改动、可信测试一致、版本和依赖清单。
- logs/preparation.log 为工具会话中环境准备输出的转录，其他执行日志为 subprocess 原始捕获。
- SHA256SUMS 对包内交付内容提供校验；不包含自身。

## 解包后复现

使用 Python 3.11.16，安装 pydantic==2.14.4、pytest==9.2.0（其他版本不作相同性保证）。在 evidence 目录运行：

```bash
PYTHONPATH="$PWD/student/work/02" python -m pytest trusted/tests/test_tool_governance.py -v -k transfer
PYTHONPATH="$PWD/student/work/02" python -m pytest student/work/02/tests/test_tool_governance.py -v -k transfer
PYTHONPATH="$PWD/student/work/02" python student/work/02/tests/test_tool_governance.py
PYTHONPATH="$PWD/student/work/02" python scripts/supplement.py
sha256sum -c SHA256SUMS
```

预期退出码依次为 1、0、0、0、0。无需真实模型或密钥，不使用替身，不转换结果；审批仅通过学员 ApprovalStore 模拟人工已确认。每个独立补测恢复账户并新建 Runtime，最后恢复初值。

scripts/run_checks.py 保留本 orb 原执行路径，供核查原命令；跨目录复现请使用上面的相对路径命令。
