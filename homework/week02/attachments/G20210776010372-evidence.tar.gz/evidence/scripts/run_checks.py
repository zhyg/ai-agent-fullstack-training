"""Record exact commands, output and exit codes without modifying student code."""
import os
import pathlib
import shlex
import subprocess
import sys

base = pathlib.Path(__file__).resolve().parents[2]
evidence = base / 'evidence'
student = base / 'student/work/02'
python = base / 'venv/bin/python'
env = dict(os.environ, PYTHONPATH=str(student))
commands = [
    ('environment', [str(python), '-c', 'import sys,pydantic,pytest,tool_governance_demo as d; print(sys.version); print("Pydantic",pydantic.__version__); print("pytest",pytest.__version__); print("module",d.__file__)']),
    ('original', [str(python), '-m', 'pytest', str(evidence / 'trusted/tests/test_tool_governance.py'), '-v', '-k', 'transfer']),
    ('student_tests', [str(python), '-m', 'pytest', 'tests/test_tool_governance.py', '-v', '-k', 'transfer']),
    ('student_demo', [str(python), 'tests/test_tool_governance.py']),
    ('supplement', [str(python), str(evidence / 'scripts/supplement.py')]),
]
for name, command in commands:
    result = subprocess.run(command, cwd=student, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    text = f'CWD={student}\nPYTHONPATH={student}\nCOMMAND={shlex.join(command)}\n{result.stdout}\nEXIT_CODE={result.returncode}\n'
    (evidence / 'logs' / f'{name}.log').write_text(text)
    print(f'{name}: EXIT_CODE={result.returncode}')
    print(result.stdout[-2000:])
