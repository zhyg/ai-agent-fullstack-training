"""Native student Runtime probes. No wrappers, substitutions or result conversion."""
import asyncio
import ast
import dataclasses
import difflib
import inspect
import json
import pathlib
import time
import tool_governance_demo as d

ROOT = pathlib.Path(__file__).resolve().parents[1]
INITIAL = dict(d.ACCOUNTS)
BASE = dict(from_account='ACC-A-123456', to_account='ACC-A-654321', amount=1200.0)

def ctx(**overrides):
    values = dict(trace_id='teacher-trace', user_id='teacher', tenant_id='tenant_a', permissions=frozenset({'transfer:create', 'order:read'}), allowed_tools=frozenset({'create_transfer', 'get_order'}))
    return d.ExecutionContext(**(values | overrides))

def emit(label, value):
    print(label, json.dumps(value, ensure_ascii=False, default=str))

async def probe(label, arguments, approved=False, **overrides):
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(INITIAL)
    runtime, approvals, audit = d.build_governance()
    context = ctx(**overrides)
    if approved:
        approvals.approve('teacher-approval', user_id=context.user_id, tenant_id=context.tenant_id, tool_name='create_transfer', args=d.TransferArgs.model_validate(arguments))
        context = dataclasses.replace(context, approval_id='teacher-approval')
    started = time.perf_counter()
    result = await runtime.invoke(d.ToolCall('teacher_000003', 'create_transfer', arguments), context)
    elapsed = time.perf_counter() - started
    emit(label, dict(result=dataclasses.asdict(result), elapsed=elapsed, balances={str(k): v for k,v in d.ACCOUNTS.items()}, audit=audit.records))
    return result, elapsed, audit

async def main():
    emit('module', d.__file__)
    emit('initial', {str(k):v for k,v in INITIAL.items()})
    assert INITIAL == {('tenant_a','ACC-A-123456'):100000.0, ('tenant_a','ACC-A-654321'):5000.0, ('tenant_a','ACC-A-888888'):20000.0, ('tenant_b','ACC-B-111111'):50000.0}
    assert all(type(x) is float for x in INITIAL.values())
    emit('strict_config', d.TransferArgs.model_config)
    for name, args in [
        ('extra', BASE | {'approved':True}), ('missing', {'from_account':BASE['from_account'], 'amount':10.0}),
        ('bad_from', BASE | {'from_account':'ACC-123456'}), ('bad_to', BASE | {'to_account':'acc-a-654321'}),
        ('zero', BASE | {'amount':0.0}), ('negative', BASE | {'amount':-1.0}), ('over', BASE | {'amount':100000.01}),
        ('numeric_string', BASE | {'amount':'1200.0'}),
    ]:
        r, _, _ = await probe(name, args)
        assert r.error_code == ('APPROVAL_REQUIRED' if name == 'numeric_string' else 'INVALID_ARGUMENT')
        assert d.ACCOUNTS == INITIAL
    for amount, code in [(50000.0,'APPROVAL_REQUIRED'),(50000.01,'EXCEED_LIMIT'),(80000.0,'EXCEED_LIMIT'),(80000.01,'APPROVAL_REQUIRED'),(100000.0,'APPROVAL_REQUIRED'),(100000.01,'INVALID_ARGUMENT')]:
        r, _, _ = await probe(f'boundary-{amount}', BASE | {'amount':amount})
        assert r.error_code == code and d.ACCOUNTS == INITIAL
    for amount, code in [(30000.0,'INSUFFICIENT_BALANCE'),(60000.0,'EXCEED_LIMIT')]:
        r,_,_ = await probe(f'small-{amount}', BASE | {'from_account':'ACC-A-888888','amount':amount})
        assert r.error_code == code and d.ACCOUNTS == INITIAL
    for source in ['ACC-A-000000','ACC-B-111111']:
        r,_,_ = await probe(f'missing-source-{source}', BASE | {'from_account':source})
        assert r.error_code == 'INSUFFICIENT_BALANCE' and d.ACCOUNTS == INITIAL
    for target in ['ACC-A-000000','ACC-B-111111']:
        r,_,_ = await probe(f'missing-target-{target}', BASE | {'to_account':target}, approved=True)
        assert r.error_code == 'ACCOUNT_NOT_FOUND' and r.content['message'] == '转入账户不存在' and d.ACCOUNTS == INITIAL
    r,_,_ = await probe('exact-balance', BASE | {'from_account':'ACC-A-888888', 'amount':20000.0}, approved=True)
    assert r.ok and d.ACCOUNTS[('tenant_a','ACC-A-888888')] == 0.0 and d.ACCOUNTS[('tenant_a','ACC-A-654321')] == 25000.0
    r,_,_ = await probe('same-account', BASE | {'to_account':BASE['from_account']}, approved=True)
    assert r.ok and d.ACCOUNTS == INITIAL
    for amount in [80000.01,90000.0,100000.0]:
        r,elapsed,_ = await probe(f'timeout-{amount}', BASE | {'amount':amount}, approved=True)
        assert r.error_code == 'TIMEOUT_UNKNOWN' and elapsed < 3.0 and d.ACCOUNTS == INITIAL
    for name, over, code in [('permission',{'permissions':frozenset()},'PERMISSION_DENIED'), ('whitelist',{'allowed_tools':frozenset()},'TOOL_NOT_ALLOWED'), ('plan',{'mode':d.PermissionMode.PLAN},'PLAN_MODE_DENIED')]:
        r,_,_ = await probe(name, BASE, approved=True, **over)
        assert r.error_code == code and d.ACCOUNTS == INITIAL
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(INITIAL)
    runtime, approvals, audit = d.build_governance()
    context = ctx()
    result = await runtime.invoke(d.ToolCall('teacher_pending','create_transfer',BASE),context)
    emit('native-pending',dataclasses.asdict(result))
    approvals.approve('approval',user_id=context.user_id,tenant_id=context.tenant_id,tool_name='create_transfer',args=d.TransferArgs(**BASE))
    context = dataclasses.replace(context,approval_id='approval')
    for key, value in [('amount',9000.0),('to_account','ACC-A-888888')]:
        r = await runtime.invoke(d.ToolCall('teacher_tamper','create_transfer',BASE | {key:value}),context)
        assert r.error_code == 'APPROVAL_REQUIRED' and d.ACCOUNTS == INITIAL
    result = await runtime.invoke(d.ToolCall('teacher_000003','create_transfer',BASE),context)
    emit('native-success', dataclasses.asdict(result))
    assert result.ok and result.content == dict(txn_id='000003', **{'from':'ACC-A-****3456','to':'ACC-A-****4321'}, amount=1200.0,status='completed')
    assert d.ACCOUNTS[('tenant_a',BASE['from_account'])] == 98800.0 and d.ACCOUNTS[('tenant_a',BASE['to_account'])] == 6200.0
    result = await runtime.invoke(d.ToolCall('teacher_replay','create_transfer',BASE),context)
    assert result.error_code == 'APPROVAL_REQUIRED'
    emit('native-audit',audit.records)
    emit('pending-approval-decision',audit.records[0]['decision'])
    # Precheck rejection must not consume matching approval.
    d.ACCOUNTS.clear();d.ACCOUNTS.update(INITIAL)
    runtime, approvals, audit = d.build_governance()
    args = BASE | {'amount':60000.0}
    approvals.approve('unused',user_id='teacher',tenant_id='tenant_a',tool_name='create_transfer',args=d.TransferArgs(**args))
    r = await runtime.invoke(d.ToolCall('teacher_precheck','create_transfer',args),ctx(approval_id='unused'))
    assert r.error_code == 'EXCEED_LIMIT' and not approvals._items['unused'].used
    tool = runtime._tools['create_transfer']
    emit('tool-policy', dataclasses.asdict(tool.policy))
    assert tool.parameters_model is d.TransferArgs and tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    targets = [tool.canonical_target(d.TransferArgs(**x),ctx()) for x in [BASE,BASE | {'from_account':'ACC-A-888888'},BASE | {'to_account':'ACC-A-888888'},BASE | {'amount':999.0}]]
    emit('canonical-targets-base-source-target-amount', targets)
    assert targets[0] != targets[1] and targets[0] != targets[2] and targets[0] == targets[3]
    r = await runtime.invoke(d.ToolCall('teacher_order','get_order',{'order_id':'ord_1001'}),ctx())
    emit('order-redaction',dataclasses.asdict(r))
    assert r.content['customer_email'] == '***@***' and r.content['access_token'] == '***'
    nested = d.redact({'nest':[{'account':'ACC-B-111111','email':'a@b.com','password':'abc'}]})
    emit('nested-redaction',nested)
    assert nested == {'nest':[{'account':'ACC-B-****1111','email':'***@***','password':'***'}]}
    emit('missing-original-interfaces', [name for name in ['build_runtime','base_context','reset_side_effects','DecisionAction'] if not hasattr(d,name)])
    r = await runtime.invoke(d.ToolCall('teacher_expected_name','transfer',BASE),ctx(permissions=frozenset({'transfer:execute'}),allowed_tools=frozenset({'transfer'})))
    emit('expected-tool-name',dataclasses.asdict(r))
    assert r.error_code == 'TOOL_NOT_ALLOWED'
    r = await runtime.invoke(d.ToolCall('teacher_expected_permission','create_transfer',BASE),ctx(permissions=frozenset({'transfer:execute'})))
    emit('expected-permission-name',dataclasses.asdict(r))
    assert r.error_code == 'PERMISSION_DENIED'
    trusted = (ROOT / 'trusted/tool_governance_demo-无答案.py').read_text()
    actual = pathlib.Path(d.__file__).read_text()
    def decide_source(text):
        tree = ast.parse(text)
        cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'PermissionEngine')
        func = next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name == 'decide')
        return ast.get_source_segment(text,func)
    original_decide,student_decide = decide_source(trusted),decide_source(actual)
    assert original_decide != student_decide
    (ROOT / 'logs/permission-engine.diff').write_text('\n'.join(difflib.unified_diff(original_decide.splitlines(),student_decide.splitlines(),fromfile='trusted.decide',tofile='student.decide')))
    emit('checks','ALL NATIVE PROBES PASSED; contract differences explicitly asserted, not corrected')
    d.ACCOUNTS.clear();d.ACCOUNTS.update(INITIAL)

asyncio.run(main())
