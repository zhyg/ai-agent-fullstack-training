#!/usr/bin/env bash
# 在解压后的evidence目录执行；仅运行本地模拟，不读取真实凭据。
set -u
BASE="$(cd "$(dirname "$0")" && pwd)"
PYTHON="${PYTHON:-python3}"
export PYTHONPATH="$BASE/source"
run() {
  printf '\nCOMMAND:'
  printf ' %q' "$@"
  printf '\n'
  "$@"
  rc=$?
  printf 'EXIT_CODE=%s\n' "$rc"
}
# 请在独立环境安装source/requirements.txt，推荐Python 3.11。
run "$PYTHON" -c 'import sys,tool_governance_demo as d; print(sys.version); print(d.__file__)'
run "$PYTHON" -m pytest "$BASE/trusted/test_tool_governance.py" -v -k transfer
run "$PYTHON" "$BASE/supplement.py"
run "$PYTHON" -m pytest "$BASE/source/test_tool_governance_demo.py" -q
printf 'y\n' | "$PYTHON" "$BASE/source/tool_governance_demo.py" tenant_a u_100 transfer-normal
printf 'DEMO_NORMAL_EXIT_CODE=%s\n' "${PIPESTATUS[1]}"
run "$PYTHON" "$BASE/source/tool_governance_demo.py" tenant_a u_100 transfer-limit
