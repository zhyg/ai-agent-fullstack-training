"""独立补证：不适配/修改可信五测，不修改学生实现，所有业务经 invoke。"""
import ast
import asyncio
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import sys
import tempfile
import time
from dataclasses import asdict, replace

import tool_governance_demo as d

ROOT = Path(__file__).resolve().parent
INITIAL = dict(d.ACCOUNTS)
F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
VALID = dict(from_account=F, to_account=T, amount=1200.0)
checks = []

def emit(label, **data):
    print(json.dumps(dict(label=label, **data), ensure_ascii=False, default=str), flush=True)

def check(label, condition, **data):
    checks.append((label, bool(condition)))
    emit(label, passed=bool(condition), **data)

def reset():
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(INITIAL)
    d.REFUNDS.clear()
    d.TRANSFERS.clear()

async def yes(message):
    emit('模拟人工同意', prompt=message)
    return True

async def run(args, *, ctx=None, confirm=None, call_id='call_tr_000003'):
    reset()
    with tempfile.TemporaryDirectory(dir=ROOT / 'runtime') as td:
        rt, store, audit = d.build_governance(store_dir=Path(td))
        ctx = ctx or d.resolve_context('tenant_a', 'u_100')
        before = dict(d.ACCOUNTS)
        start = time.perf_counter()
        result = await rt.invoke(d.ToolCall(call_id, 'transfer', args), ctx, ask_confirmation=confirm)
        return result, dict(d.ACCOUNTS), audit.records, time.perf_counter()-start, before, store.records()

async def main():
    (ROOT / 'runtime').mkdir(exist_ok=True)
    emit('环境', python=sys.version, executable=sys.executable, module=d.__file__,
         dependencies={p: importlib.metadata.version(p) for p in ['pydantic','pytest','pytest-asyncio','openai']},
         source_sha256=hashlib.sha256(Path(d.__file__).read_bytes()).hexdigest())
    expected = {('tenant_a',F):100000.0, ('tenant_a',T):5000.0, ('tenant_a',S):20000.0, ('tenant_b',B):50000.0}
    check('A01 初始账户', INITIAL == expected and all(type(v) is float for v in INITIAL.values()), accounts=list(INITIAL.items()))
    check('A02 extra保留', d.TransferArgs.model_config.get('extra') == 'forbid', config=d.TransferArgs.model_config)
    check('A02 模型strict配置', d.TransferArgs.model_config.get('strict') is True, config=d.TransferArgs.model_config)
    cases = [(f'missing_{k}', {x:v for x,v in VALID.items() if x!=k}) for k in VALID]
    cases += [('approved', {**VALID,'approved':True}), ('user_id',{**VALID,'user_id':'admin'})]
    cases += [(f'amount_{v}',{**VALID,'amount':v}) for v in [-1,0,100000.01,'1200',True]]
    cases += [(k,{**VALID,k:'ACC-123456'}) for k in ['from_account','to_account']]
    for label,args in cases:
        r,after,audit,_,before,_ = await run(args)
        check('A02 '+label, r.error_code=='INVALID_ARGUMENT' and after==before, result=asdict(r))
    for amount,code in [(50000.0,'CONFIRMATION_UNAVAILABLE'),(50000.01,'EXCEED_LIMIT'),(80000.0,'EXCEED_LIMIT'),(80000.01,'CONFIRMATION_UNAVAILABLE'),(100000.0,'CONFIRMATION_UNAVAILABLE'),(100000.01,'INVALID_ARGUMENT')]:
        r,after,audit,_,before,records=await run({**VALID,'amount':amount})
        check('A03 边界 '+str(amount), r.error_code==code and after==before and not records, result=asdict(r), audit=audit)
    for amount,code in [(30000.0,'INSUFFICIENT_BALANCE'),(60000.0,'EXCEED_LIMIT')]:
        asked=[]
        async def prompt(msg):
            asked.append(msg)
            return True
        r,after,audit,_,before,records=await run({**VALID,'from_account':S,'amount':amount},confirm=prompt)
        check('A04 预检顺序只读 '+str(amount),r.error_code==code and after==before and not asked and not records,result=asdict(r),audit=audit)
    r,after,audit,_,_,_=await run({**VALID,'from_account':S,'amount':20000.0},confirm=yes)
    check('A05 满额转出',r.ok and after[('tenant_a',S)]==0 and after[('tenant_a',T)]==25000,result=asdict(r),balances=list(after.items()),audit=audit)
    for label,args,code in [('A06 缺失目标',{**VALID,'to_account':'ACC-A-000000'},'ACCOUNT_NOT_FOUND'),('A07 跨租户转出',{**VALID,'from_account':B},'INSUFFICIENT_BALANCE'),('A07 跨租户转入',{**VALID,'to_account':B},'ACCOUNT_NOT_FOUND')]:
        r,after,audit,_,before,_=await run(args,confirm=yes)
        check(label,r.error_code==code and after==before,result=asdict(r),audit=audit)
    r,after,audit,_,before,records=await run(VALID,confirm=yes)
    check('T04补证 成功余额脱敏审计',r.ok and r.content['from']=='ACC-A-****3456' and r.content['to']=='ACC-A-****4321' and after[('tenant_a',F)]==98800 and after[('tenant_a',T)]==6200 and all(x['tool_call_id']=='call_tr_000003' for x in audit), result=asdict(r),audit=audit,approval_records=records)
    check('任务4 txn_id',r.content.get('txn_id')=='000003',result=asdict(r))
    check('任务4 status',r.content.get('status')=='accepted',result=asdict(r))
    for label,ctx in [('无权限',replace(d.resolve_context('tenant_a','u_100'),permissions=frozenset())),('无白名单',replace(d.resolve_context('tenant_a','u_100'),allowed_tools=frozenset())),('plan',replace(d.resolve_context('tenant_a','u_100'),mode=d.PermissionMode.PLAN))]:
        r,after,audit,_,before,_=await run(VALID,ctx=ctx,confirm=yes)
        code={'无权限':'PERMISSION_DENIED','无白名单':'TOOL_NOT_ALLOWED','plan':'PLAN_MODE_DENIED'}[label]
        check('T03补证 '+label,r.error_code==code and after==before,result=asdict(r),audit=audit)
    ctx=replace(d.resolve_context('tenant_a','u_100'),permissions=frozenset({'transfer:execute'}))
    r,*_=await run(VALID,ctx=ctx,confirm=yes)
    check('A08 题目权限名',r.ok,result=asdict(r))
    reset()
    with tempfile.TemporaryDirectory(dir=ROOT/'runtime') as td:
        rt,store,audit=d.build_governance(store_dir=Path(td))
        tool=rt._tools['transfer']
        ctx=d.resolve_context('tenant_a','u_100')
        targets=[tool.canonical_target(d.TransferArgs(**x),ctx) for x in [VALID,{**VALID,'from_account':S},{**VALID,'to_account':S},{**VALID,'amount':1201.0}]]
        check('A08 target完整区分',len(set(targets))==4,targets=targets)
        emit('A08 注册绑定',model=tool.parameters_model.__name__,handler=tool.handler.__name__,precheck=tool.precheck.__name__,policy=asdict(tool.policy))
        pending=await rt.invoke(d.ToolCall('pending','transfer',VALID),ctx)
        check('T04补证 CONFIRM协议',not pending.ok and getattr(pending,'action',None)==getattr(d.PermissionDecision,'CONFIRM'),result=asdict(pending))
        args=dict(VALID)
        async def mutate(message):
            args['amount']=9000.0
            return True
        result=await rt.invoke(d.ToolCall('tampered','transfer',args),ctx,ask_confirmation=mutate)
        check('T04补证 确认中参数篡改拒绝',result.error_code=='CONFIRMATION_INVALID' and d.ACCOUNTS==INITIAL,result=asdict(result))
        asked=[]
        async def count_prompt(message):
            asked.append(message)
            return True
        for i in range(2):
            await rt.invoke(d.ToolCall('repeat','transfer',VALID),ctx,ask_confirmation=count_prompt)
        check('T04补证 小额重复调用需新确认',len(asked)==2 and d.ACCOUNTS[('tenant_a',F)]==97600,confirm_count=len(asked),balances=list(d.ACCOUNTS.items()))
    for amount in [80000.01,90000.0,100000.0]:
        reset()
        with tempfile.TemporaryDirectory(dir=ROOT/'runtime') as td:
            rt,store,audit=d.build_governance(store_dir=Path(td))
            ctx=d.resolve_context('tenant_a','u_100')
            args={**VALID,'amount':amount}
            submitted=await rt.invoke(d.ToolCall('large','transfer',args),ctx,ask_confirmation=yes)
            request_id=submitted.content['request_id']
            reviewer=d.resolve_context('tenant_a','u_200',human=True)
            # Python profiler只观测原handler入口，不替换handler/sleep/策略。
            entries=[]
            def profile(frame,event,arg):
                if event=='call' and frame.f_code is d.transfer_handler.__code__:
                    entries.append(frame.f_locals['args'].amount)
            sys.setprofile(profile)
            start=time.perf_counter()
            result=await rt.invoke(d.ToolCall('approve','decide_approval',{'request_id':request_id,'decision':'approve'}),reviewer)
            elapsed=time.perf_counter()-start
            sys.setprofile(None)
            saved=store.read(request_id)
            check('A03/T05 真实handler超时 '+str(amount),saved['error_code']=='TIMEOUT_UNKNOWN' and saved['execution_status']=='UNKNOWN' and 1.8<elapsed<3 and d.ACCOUNTS==INITIAL and bool(entries),elapsed=elapsed,handler_entries=entries,result=asdict(result),record=saved,audit=audit.records)
            before=dict(d.ACCOUNTS)
            replay=await rt.invoke(d.ToolCall('approve-again','decide_approval',{'request_id':request_id,'decision':'approve'}),reviewer)
            check('T05补证 审批重放无再次执行 '+str(amount),d.ACCOUNTS==before and store.read(request_id)['execution_status']=='UNKNOWN',result=asdict(replay))
            conflict=await rt.invoke(d.ToolCall('large','transfer',{**args,'to_account':S}),ctx,ask_confirmation=yes)
            check('T04补证 审批参数绑定 '+str(amount),conflict.error_code=='CALL_ID_CONFLICT',result=asdict(conflict))
    nested={'password':'not-a-real-password','items':[{'email':'alice@example.com','account':F}]}
    check('A09 递归脱敏',d.redact(nested)=={'password':'***','items':[{'email':'***@***','account':'ACC-A-****3456'}]},result=d.redact(nested))
    reset()
    with tempfile.TemporaryDirectory(dir=ROOT/'runtime') as td:
        rt,_,audit=d.build_governance(store_dir=Path(td))
        result=await rt.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),d.resolve_context('tenant_a','u_100'))
        check('A09 订单回归',result.ok and result.content['access_token']=='***' and result.content['customer_email']=='***@***',result=asdict(result),audit=audit.records)
    baseline=ast.parse((ROOT/'trusted'/'tool_governance_demo-无答案.py').read_text())
    student=ast.parse(Path(d.__file__).read_text())
    def method(tree):
        c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PermissionEngine')
        return next(n for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='decide')
    bm,sm=method(baseline),method(student)
    same=ast.dump(bm,include_attributes=False)==ast.dump(sm,include_attributes=False)
    check('A10 固定方法AST',same,baseline_kind=type(bm).__name__,student_kind=type(sm).__name__,student_source=ast.get_source_segment(Path(d.__file__).read_text(),sm))
    emit('汇总',checks=len(checks),passed=sum(v for _,v in checks),contract_differences=[k for k,v in checks if not v])
    # 退出0表明补证脚本完成，不代表全部题目契约通过；逐条passed保留真实差异。

asyncio.run(main())
