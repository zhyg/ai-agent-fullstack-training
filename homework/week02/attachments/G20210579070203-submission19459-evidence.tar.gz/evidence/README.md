# G20210579070203（记录19459）独立评测证据

结论：83/100，优秀；验收未通过。详见 G20210579070203-evaluation.md。

目录：source为学生原始作业快照；trusted为教师原始附件；standards为课程题目、标准与模板；scripts为独立补测和命令运行器；logs为真实输出、退出码、元数据及固定权限引擎源码对照。

复跑示例（解包后的目录执行）：

```bash
python3 -m venv /path/to/external-venv
/path/to/external-venv/bin/pip install pydantic==2.14.3 pytest==9.2.0
PYTHON=/path/to/external-venv/bin/python bash evidence/scripts/run_checks.sh
```

默认导入包内source/tool_governance_demo.py；若要测原克隆，请设置STUDENT_DIR为其homework/02-practical-agent-runtime绝对路径。runner继续执行全部命令，各自结果看日志EXIT_CODE，不能用runner总退出码判断通过。

原始五测因reset_side_effects缺失在fixture阻断，未改其断言或伪造学生业务。教师补测使用学生真实接口，指定权限名另行验证，不将其修改为通过；明确使用实际transfer:create权限仅为了探测下游行为。每个独立场景重置账户和Runtime。

logs/bootstrap为教师初次环境指向/日志序列化问题，已经修正，不用于学生扣分。SHA256SUMS排除本身，包内无venv或依赖、密钥、.env、缓存及.git。
