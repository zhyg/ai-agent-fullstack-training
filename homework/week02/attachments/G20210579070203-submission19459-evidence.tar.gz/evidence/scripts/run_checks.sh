#!/usr/bin/env bash
set -u
ROOT=$(realpath "$(dirname "$0")/..")
PY=${PYTHON:-$ROOT/../venv/bin/python}
STUDENT=${STUDENT_DIR:-$ROOT/source}
run() { name=$1; shift; printf 'COMMAND:' > "$ROOT/logs/$name.log"; printf ' %q' "$@" >> "$ROOT/logs/$name.log"; printf '\n' >> "$ROOT/logs/$name.log"; "$@" >> "$ROOT/logs/$name.log" 2>&1; rc=$?; printf '\nEXIT_CODE=%s\n' "$rc" >> "$ROOT/logs/$name.log"; echo "$name exit=$rc"; }
export PYTHONPATH="$STUDENT"
run environment "$PY" -c 'import sys,platform,pydantic,pytest,tool_governance_demo as d; print(sys.version); print(platform.platform()); print("pydantic",pydantic.__version__,"pytest",pytest.__version__); print("IMPORTED",d.__file__)'
run trusted "$PY" -m pytest "$ROOT/trusted/test_tool_governance.py" -v -k transfer
run student "$PY" -m pytest "$STUDENT/tests/test_tool_governance.py" -v -s -k transfer
run demo "$PY" "$STUDENT/tool_governance_demo.py"
run supplementary "$PY" "$ROOT/scripts/supplementary.py"
