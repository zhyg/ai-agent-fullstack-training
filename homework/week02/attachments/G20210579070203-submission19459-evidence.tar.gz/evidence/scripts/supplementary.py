"""Independent evidence probes; no monkeypatching, no student edits, no model calls.
Every business call uses the student's ToolRuntime.invoke. Independent cases reset stores.
Native transfer:create is used only to reach downstream paths; expected transfer:execute
is independently checked and NEVER translated inside student code or trusted assertions.
"""
import asyncio
import ast
import dataclasses
import inspect
import json
import time
import traceback
from pathlib import Path
import tool_governance_demo as d

INITIAL = {('tenant_a','ACC-A-123456'):100000.0,('tenant_a','ACC-A-654321'):5000.0,('tenant_a','ACC-A-888888'):20000.0,('tenant_b','ACC-B-111111'):50000.0}
BASE = {'from_account':'ACC-A-123456','to_account':'ACC-A-654321','amount':1200.0}
RESULTS=[]
def check(label, expected, actual):
    ok=expected==actual
    RESULTS.append((label,ok))
    print(json.dumps({'check':label,'pass':ok,'expected':repr(expected),'actual':repr(actual)},ensure_ascii=False,default=str))
def env(permission='transfer:create'):
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(INITIAL)
    rt, ap, audit=d.build_governance()
    ctx=d.ExecutionContext('trace_grade','user_grade','tenant_a',frozenset({permission}),frozenset({'transfer','get_order'}))
    return rt,ap,audit,ctx
async def call(rt,ctx,args=BASE,ident='call_tr_000003'):
    return await rt.invoke(d.ToolCall(ident,'transfer',args),ctx)
def approve(ap,ctx,args=BASE):
    ap.approve('grade_approval',user_id=ctx.user_id,tenant_id=ctx.tenant_id,tool_name='transfer',args=d.TransferArgs.model_validate(args))
    return dataclasses.replace(ctx,approval_id='grade_approval')
def stage(audit):
    r=audit.records[-1]
    return r.get('phase',r.get('stage','<missing>'))
async def probe(label,fn):
    try: await fn()
    except Exception as e:
        check(label+' uncaught exception','no exception',type(e).__name__+': '+str(e))
        traceback.print_exc()
async def main():
    check('A01 initial accounts',INITIAL,d.ACCOUNTS)
    check('A01 float balances',True,all(type(v) is float for v in d.ACCOUNTS.values()))
    print('IMPORTED',d.__file__)
    print('SCHEMA',json.dumps(d.TransferArgs.model_json_schema(),ensure_ascii=False))
    invalid=[{k:v for k,v in BASE.items() if k!=field} for field in BASE]
    invalid += [{**BASE,'approved':True},{**BASE,'user_id':'admin'},{**BASE,'amount':-1.0},{**BASE,'amount':'1200.0'},{**BASE,'from_account':'bad'},{**BASE,'to_account':'bad'},{**BASE,'amount':0.0},{**BASE,'amount':100000.01}]
    for i,args in enumerate(invalid):
        rt,ap,audit,ctx=env(); result=await call(rt,ctx,args)
        check(f'A02 invalid {i} code','INVALID_ARGUMENT',result.error_code)
        check(f'A02 invalid {i} read-only',INITIAL,d.ACCOUNTS)
    for amount,expected in [(50000.0,'APPROVAL_REQUIRED'),(50000.01,'EXCEED_LIMIT'),(80000.0,'EXCEED_LIMIT'),(80000.01,'APPROVAL_REQUIRED'),(100000.0,'APPROVAL_REQUIRED'),(100000.01,'INVALID_ARGUMENT')]:
        rt,ap,audit,ctx=env(); args={**BASE,'amount':amount}; result=await call(rt,ctx,args)
        check(f'A03 {amount} code',expected,result.error_code)
        check(f'A03 {amount} read-only',INITIAL,d.ACCOUNTS)
        check(f'A03 {amount} decision stage','decision',stage(audit))
        if expected=='APPROVAL_REQUIRED': check(f'A03 {amount} confirmation audit','confirm',audit.records[-1]['decision'])
    for amount,expected in [(30000.0,'INSUFFICIENT_BALANCE'),(60000.0,'EXCEED_LIMIT')]:
        rt,ap,audit,ctx=env(); args={**BASE,'from_account':'ACC-A-888888','amount':amount}
        approved=approve(ap,ctx,args)
        for label,c in [('noapproval',ctx),('approved',approved)]:
            result=await call(rt,c,args)
            check(f'A04 {amount} {label}',expected,result.error_code)
            check(f'A04 {amount} {label} untouched',INITIAL,d.ACCOUNTS)
            check(f'A04 {amount} {label} approval unused',False,ap._items['grade_approval'].used)
    rt,ap,audit,ctx=env(); args={**BASE,'from_account':'ACC-A-888888','amount':20000.0}
    result=await call(rt,approve(ap,ctx,args),args)
    check('A05 full balance success',True,result.ok)
    check('A05 full balance amounts',(0.0,25000.0),(d.ACCOUNTS[('tenant_a','ACC-A-888888')],d.ACCOUNTS[('tenant_a','ACC-A-654321')]))
    rt,ap,audit,ctx=env(); args={**BASE,'to_account':'ACC-A-999999'}
    result=await call(rt,approve(ap,ctx,args),args)
    check('A06 missing destination',('ACCOUNT_NOT_FOUND',{'message':'转入账户不存在'}),(result.error_code,result.content))
    check('A06 no partial writes',INITIAL,d.ACCOUNTS)
    for field in ['from_account','to_account']:
        async def tenant_case():
            rt,ap,audit,ctx=env(); args={**BASE,field:'ACC-B-111111'}
            try:
                result=await call(rt,approve(ap,ctx,args),args)
                check(f'A07 cross-tenant {field} controlled denial',True,(not result.ok and result.error_code in ['ACCOUNT_NOT_FOUND','INSUFFICIENT_BALANCE']))
                print('CROSS_TENANT_RESULT',result)
            finally: check(f'A07 cross-tenant {field} untouched',INITIAL,d.ACCOUNTS)
        await probe('A07 '+field,tenant_case)
    async def missing_source():
        rt,ap,audit,ctx=env(); args={**BASE,'from_account':'ACC-A-999999'}
        try:
            result=await call(rt,ctx,args)
            check('missing source controlled denial',True,not result.ok and result.error_code in ['ACCOUNT_NOT_FOUND','INSUFFICIENT_BALANCE'])
        finally: check('missing source untouched',INITIAL,d.ACCOUNTS)
    await probe('missing source',missing_source)
    rt,ap,audit,ctx=env(); tool=rt._tools['transfer']; p=tool.policy
    check('A08 binding',(d.TransferArgs,d.transfer_handler,d.transfer_precheck),(tool.parameters_model,tool.handler,tool.precheck))
    check('A08 write/high/approval/nonidem/retry',('write','high',True,False,0),(p.effect,p.risk,p.requires_approval,p.idempotent,p.max_retries))
    check('A08 permission','transfer:execute',p.permission)
    check('A08 timeout less than sleep',True,0<p.timeout_seconds<3.0)
    targets=[tool.canonical_target(d.TransferArgs.model_validate(a),ctx) for a in [BASE,{**BASE,'from_account':'ACC-A-888888'},{**BASE,'to_account':'ACC-A-888888'},{**BASE,'amount':1201.0}]]
    check('A08 all business parameter targets differ',4,len(set(targets)))
    print('TARGETS',targets)
    rt,ap,audit,ctx=env('transfer:execute'); result=await call(rt,ctx)
    check('expected permission reaches confirmation','APPROVAL_REQUIRED',result.error_code)
    # Permissions, whitelist and plan are exercised with valid native approval.
    for label,changes,code in [('rbac',{'permissions':frozenset()},'PERMISSION_DENIED'),('whitelist',{'allowed_tools':frozenset()},'TOOL_NOT_ALLOWED'),('plan',{'mode':d.PermissionMode.PLAN},'PLAN_MODE_DENIED')]:
        rt,ap,audit,ctx=env(); ctx=approve(ap,ctx)
        result=await call(rt,dataclasses.replace(ctx,**changes))
        check('T03-equivalent '+label,code,result.error_code)
    rt,ap,audit,ctx=env(); pending=await call(rt,ctx,ident='call_tr_000001')
    check('T04 pending code','APPROVAL_REQUIRED',pending.error_code)
    check('T04 pending real confirm decision','confirm',audit.records[-1]['decision'])
    approved=approve(ap,ctx)
    for label,args in [('amount',{**BASE,'amount':9000.0}),('destination',{**BASE,'to_account':'ACC-A-888888'})]:
        result=await call(rt,approved,args,ident='call_tr_000002'); check('T04 binding '+label,'APPROVAL_REQUIRED',result.error_code)
        check('T04 binding '+label+' does not consume',False,ap._items['grade_approval'].used)
    result=await call(rt,approved)
    check('T04 success',True,result.ok)
    check('T04 txn_id','000003',result.content.get('txn_id'))
    check('T04 status','accepted',result.content.get('status'))
    check('T04 amount',1200.0,result.content.get('amount'))
    check('A09 masked from/to',('ACC-A-****3456','ACC-A-****4321'),(result.content.get('from'),result.content.get('to')))
    check('T04 balances',(98800.0,6200.0),(d.ACCOUNTS[('tenant_a',BASE['from_account'])],d.ACCOUNTS[('tenant_a',BASE['to_account'])]))
    print('T04_AUDIT',json.dumps(audit.records,ensure_ascii=False,default=str))
    check('T04 audit success decision phase/code',('decision','APPROVED'),(audit.records[-2].get('phase'),audit.records[-2].get('code')))
    check('T04 audit success execution phase/code',('execution','OK'),(audit.records[-1].get('phase'),audit.records[-1].get('code')))
    check('A09 audit linked',True,all(r['trace_id']==ctx.trace_id and r['tool_name']=='transfer' and r['tool_call_id'] for r in audit.records))
    result=await call(rt,approved); check('T04 approval replay denied','APPROVAL_REQUIRED',result.error_code)
    rt,ap,audit,ctx=env(); query=await rt.invoke(d.ToolCall('order_read','get_order',{'order_id':'ord_1001'}),dataclasses.replace(ctx,permissions=frozenset({'order:read'})))
    check('A09 order redaction',('***@***','***'),(query.content['customer_email'],query.content['access_token']))
    check('A09 nested redaction',{'nested':[{'email':'***@***','password':'***','account':'ACC-A-****3456'}]},d.redact({'nested':[{'email':'alice@example.com','password':'hidden','account':'ACC-A-123456'}]}))
    for amount in [80000.01,90000.0,100000.0]:
        rt,ap,audit,ctx=env(); args={**BASE,'amount':amount}; ctx=approve(ap,ctx,args)
        start=time.perf_counter(); result=await call(rt,ctx,args); elapsed=time.perf_counter()-start
        check(f'T05/A03 {amount} timeout','TIMEOUT_UNKNOWN',result.error_code)
        check(f'T05/A03 {amount} elapsed<3',True,elapsed<3.0)
        print('TIMEOUT',amount,'elapsed',elapsed,'audit',audit.records)
        check(f'T05/A03 {amount} unchanged',INITIAL,d.ACCOUNTS)
        check(f'T05/A03 {amount} audit error','TIMEOUT_UNKNOWN',audit.records[-1]['error_code'])
        check(f'T05/A03 {amount} execution audit phase','execution',stage(audit))
    rt,ap,audit,ctx=env(); args={**BASE,'to_account':BASE['from_account']}; result=await call(rt,approve(ap,ctx,args),args)
    check('same account net zero',INITIAL,d.ACCOUNTS)
    reference=ast.parse((Path(__file__).resolve().parents[1]/'trusted/tool_governance_demo-无答案.py').read_text())
    submitted=ast.parse(Path(d.__file__).read_text())
    def engine(tree):
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PermissionEngine')
        return next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='decide')
    check('A10 fixed PermissionEngine AST unchanged',ast.dump(engine(reference),include_attributes=False),ast.dump(engine(submitted),include_attributes=False))
    for label,tree in [('reference',reference),('student',submitted)]:
        node=engine(tree); text=ast.get_source_segment((Path(__file__).resolve().parents[1]/'trusted/tool_governance_demo-无答案.py').read_text() if label=='reference' else Path(d.__file__).read_text(),node)
        (Path(__file__).resolve().parents[1]/'logs'/f'{label}-PermissionEngine.txt').write_text(text+'\n')
    print('SUMMARY',json.dumps({'checks':len(RESULTS),'passed':sum(ok for _,ok in RESULTS),'failed':[name for name,ok in RESULTS if not ok]},ensure_ascii=False))
    return int(any(not ok for _,ok in RESULTS))
if __name__=='__main__': raise SystemExit(asyncio.run(main()))
