# ToolGovernance

Agent 工具治理框架教学项目：把模型发起的工具调用收口到唯一入口 `ToolRuntime.invoke`，在其上串起一条**确定性**治理链路，让「模型能做什么」由代码而不是提示词决定。

```
Pydantic 参数校验 → 权限状态机 → 业务预检 → 一次性参数绑定审批
        → 超时恢复 → 结果脱敏 → 审计追踪
```

## 核心能力

| 环节 | 实现要点 |
| --- | --- |
| 参数校验 | `StrictArgs` 开启 `extra="forbid"`，模型多传 `approved`/`user_id` 直接 `INVALID_ARGUMENT` |
| 权限状态机 | `PermissionEngine.decide` 固定 9 级优先级：deny-first → plan → 白名单 → RBAC → 预检 → 审批 → bypass → allow → 危险 Shell |
| 业务预检 | `precheck` 在 handler 之前只读校验，失败返回 `PolicyDenied`，不产生副作用 |
| 一次性审批 | 审批票绑定用户、租户、工具与**参数摘要**，消费一次即失效，改参数或重放都回到 `CONFIRM` |
| 超时处理 | `asyncio.timeout` 掐断执行；非幂等写超时返回 `TIMEOUT_UNKNOWN` 而非假装失败 |
| 结果脱敏 | 出口统一 `_redact`：邮箱、token/secret 类字段、账号（`ACC-A-123456` → `ACC-A-****3456`） |
| 审计追踪 | decision / execution 两阶段记录 trace、工具、参数 key、决策码与耗时 |

内置四个工具：`get_order`（读）、`create_refund`（高危写，需审批）、`run_shell`（模拟 Shell）、`transfer`（租户内转账，需审批，含超时演示）。

## 目录结构

```
ToolGovernance/
├── tool_governance_demo.py      # 治理框架 + 4 个工具 + 离线演示
├── pyproject.toml               # uv 项目声明
├── uv.lock                      # 依赖锁文件
├── tests/
│   ├── conftest.py              # 注入项目根到 sys.path
│   └── test_tool_governance.py  # transfer 链路 5 个验收用例
└── docs/
    ├── transfer-implementation-plan.md  # 需求分析与分步开发文档
    ├── dev-and-test-guide.md            # 开发与测试说明
    └── test-report.md                   # 测试文档（用例矩阵 + 执行记录）
```

## 环境要求

- Python `>= 3.11`（使用 `StrEnum`、`asyncio.timeout`）
- [uv](https://docs.astral.sh/uv/) 管理依赖与虚拟环境
- 依赖：pydantic 2.14+

## 快速开始

```bash
# 1. 同步依赖（创建项目内 .venv）
uv sync

# 2. 跑离线演示
uv run python tool_governance_demo.py

# 3. 跑测试
uv run pytest tests/test_tool_governance.py -v -k "transfer"
```

可选：接入真实模型跑 Agent Loop（工具调用仍然全部经过 `ToolRuntime.invoke`）。

```bash
uv pip install openai
export DEEPSEEK_API_KEY=sk-xxx
uv run python tool_governance_demo.py --agent --input "请查询订单 ord_1001 的状态和可退金额"
```

## 离线演示输出（节选）

```json
{"tool_call_id": "call_02", "tool_name": "create_refund", "ok": false, "action": "confirm", "code": "APPROVAL_REQUIRED"}
{"tool_call_id": "call_03", "tool_name": "create_refund", "ok": true,  "action": "allow",   "code": "OK"}
{"tool_call_id": "call_04", "tool_name": "create_refund", "ok": false, "action": "deny",    "code": "INVALID_ARGUMENT"}
{"tool_call_id": "call_05", "tool_name": "run_shell",     "ok": false, "action": "deny",    "code": "DENY_RULE"}
{"tool_call_id": "call_06", "tool_name": "create_refund", "ok": false, "action": "deny",    "code": "PLAN_MODE_DENIED"}
{"tool_call_id": "call_07", "tool_name": "transfer",      "ok": false, "action": "confirm", "code": "APPROVAL_REQUIRED"}
{"tool_call_id": "call_08", "tool_name": "transfer",      "ok": true,  "action": "allow",   "code": "OK",
 "content": {"txn_id": "all_08", "from": "ACC-A-****3456", "to": "ACC-A-****4321", "amount": 1200.0, "status": "accepted"}}
```

## 测试

5 个用例覆盖参数注入、教学金额区间、余额不足、越权（缺权限 / 非白名单 / plan 模式）、审批绑定与重放、超时语义、脱敏与审计序列。

```
uv run pytest tests/test_tool_governance.py -q   →   5 passed
```

用例明细与补充场景（边界值、跨租户、他人审批票、`dontAsk` 模式）见 [docs/test-report.md](./docs/test-report.md)。

## 设计约定（改代码前必读）

1. `PermissionEngine.decide` 的优先级顺序不可改，新工具只允许插入。
2. 所有调用必须走 `ToolRuntime.invoke`，不直接调用 handler。
3. 不删除 `TransferArgs` 继承的 `extra="forbid"`——它是防注入的最后屏障。
4. `ACCOUNTS` 必须保持模块级可变 dict，测试依赖快照还原做用例隔离。

## 已知限制

- 教学窗口 `(50000, 80000]` 是刻意制造的拒绝窗口，不是真实单笔限额。
- `sleep(3.0)` 仅用于演示「非幂等写超时后状态未知」，生产应使用幂等键 + 对账。
- `ACCOUNTS` 是进程内状态，并发场景需加锁或换事务存储。
- `amount` 使用 `float`，涉及真实金额应改用 `Decimal` 或整数分。
- 脱敏只覆盖返回值字符串；日志、异常消息与审计正文需另行处理。

## 文档

- [需求分析与分步开发](./docs/transfer-implementation-plan.md)
- [开发与测试说明](./docs/dev-and-test-guide.md)
- [测试文档](./docs/test-report.md)
