# 开发与测试说明

> 适用项目：Agent Tool 治理框架教学项目（`tool_governance_demo.py` + `transfer` 工具接入）
> 文档定位：给后续开发者/助教看的**工程操作手册**——环境怎么起、代码怎么改、测试怎么跑、失败怎么查。
> 需求与设计理由见 [transfer-implementation-plan.md](./transfer-implementation-plan.md)。

---

## 一、项目概览

一个纯 Python、零第三方框架依赖（除 Pydantic 外）的教学用 Agent 工具治理实现，核心是把模型发起的工具调用**收口到唯一入口** `ToolRuntime.invoke`，在其上串起确定性治理链路。

| 项 | 说明 |
| --- | --- |
| 主文件 | `tool_governance_demo.py`（单文件演示，约 930 行） |
| 测试 | `tests/test_tool_governance.py`（5 个链路用例）+ `tests/conftest.py`（注入项目根到 `sys.path`） |
| 依赖 | `pydantic>=2.14`；开发依赖 `pytest>=9.2`（见 `pyproject.toml` / `uv.lock`） |
| Python | `requires-python >= 3.11`（用到 `StrEnum`、`asyncio.timeout`） |
| 包管理 | **uv**，虚拟环境为项目内 `.venv`（已加入 `.gitignore`） |

### 目录结构

```
ToolGovernance/
├── tool_governance_demo.py          # 治理框架 + 3 个基础工具 + transfer
├── pyproject.toml                   # uv 项目声明（依赖、Python 版本）
├── uv.lock                          # 锁定版本，随代码提交
├── .gitignore
├── docs/
│   ├── transfer-implementation-plan.md   # 需求分析与分步开发文档
│   └── dev-and-test-guide.md             # 本文档
└── tests/
    ├── conftest.py                  # PROJECT_ROOT = 上一级，注入 sys.path
    └── test_tool_governance.py      # 5 个 transfer 验收用例
```

> `conftest.py` 里的 `PROJECT_ROOT = Path(__file__).resolve().parent.parent` 依赖「conftest 位于 `tests/` 一级」这一结构。**不要**把测试文件挪回项目根，否则 `import tool_governance_demo` 会指向错误目录。

---

## 二、开发环境

### 2.1 运行位置

代码在 Windows 本地编辑、经 git 管理；**实际运行与测试在远程 Linux 编译机**上完成。

| 项 | 值 |
| --- | --- |
| 主机 | `root@192.168.10.136:22` |
| 项目目录 | `/root/toolgovernance` |
| uv | 0.13.8，二进制在 `/root/.venv-tg/bin/uv`，已软链到 `/usr/local/bin/uv`（因此在 PATH 上） |
| 虚拟环境 | `/root/toolgovernance/.venv`，Python 3.13.14 |
| 已装依赖 | pydantic 2.14.3、pytest 9.2.0 |

> 本机（Windows）**不安装 uv、不建虚拟环境**。所有 Python 命令都在远程项目目录内用 `uv run` 执行，保证解释器与依赖一致。

### 2.2 首次初始化 / 重建环境

```bash
cd /root/toolgovernance
uv sync            # 按 pyproject.toml + uv.lock 创建/同步 .venv
uv run python -V   # 期望：Python 3.13.14
```

### 2.3 日常开发同步

本地改完代码后同步到远端（在本地项目根执行）：

```powershell
scp tool_governance_demo.py root@192.168.10.136:/root/toolgovernance/
scp -r tests root@192.168.10.136:/root/toolgovernance/
```

依赖变更（改了 `pyproject.toml`）时：远端执行 `uv sync`，再把远端 `uv.lock` 取回本地提交，保证锁文件与代码同源。

```powershell
scp root@192.168.10.136:/root/toolgovernance/uv.lock .
```

### 2.4 提交规范

- 一个任务一个 commit，提交信息用英文、带任务编号，例如：
  `feat: register transfer tool with write/high-risk approval policy (task 5)`
- 只提交源码、测试、文档、`pyproject.toml`、`uv.lock`；`.venv/`、`__pycache__/`、`.pytest_cache/` 已在 `.gitignore` 中。

---

## 三、治理链路与代码落点

`PermissionEngine.decide` 的 9 级优先级是**固定框架**，新工具只允许插入，不允许重排。

| 阶段 | 承载位置 | transfer 的实现 |
| --- | --- | --- |
| ① 参数校验 | `ToolRuntime.invoke` → `parameters_model.model_validate` | `TransferArgs`：账号正则、`gt=0, le=100_000`、继承 `extra="forbid"` |
| ② 权限判断 | `decide` 第 1–4 步：deny 规则 → plan → 白名单 → RBAC | `Effect.WRITE`（plan 模式天然被拒）、`permission="transfer:execute"` |
| ③ 业务预检 | `decide` 第 5 步 → `tool.precheck(...)` | `transfer_precheck`：教学窗口 + 余额，只读不写 |
| ④ 人工审批 | `decide` 第 6 步 + `ApprovalStore` | `requires_approval=True`、`risk=HIGH`、摘要绑定参数 |
| ⑤ 超时处理 | `_execute_with_recovery` 的 `asyncio.timeout` | `timeout_seconds=2.0`，`amount>80000` 时 handler `sleep(3.0)` |
| ⑥ 结果脱敏 | `invoke` 的 `finalize` → `_redact(dict(raw))` | 账号 `ACC-A-123456` → `ACC-A-****3456` |
| ⑦ 审计追踪 | `AuditSink`（decision / execution 两阶段） | 无需改动，接入即自动产生 |

两个必须记住的顺序性质：

1. **②在③之前**：无权限、不在白名单、plan 模式的调用拿不到任何业务信息，余额不会被探测。
2. **③在④之前**：预检失败时一次性审批尚未被消费，不会浪费审批票据。

---

## 四、已实现内容（任务 0–7）

| 任务 | 内容 | 代码位置 | commit |
| --- | --- | --- | --- |
| 0 | 测试归位 `tests/` | `tests/conftest.py`、`tests/test_tool_governance.py` | `3a13cca` |
| 1 | 模拟账户数据 | `ACCOUNTS`（模块级可变 dict，key 带 `tenant_id`） | `a2275e2` |
| 2 | 参数模型 | `TransferArgs` | `eecb81d` |
| 3 | 业务预检 | `transfer_precheck` | `c5f78ee` |
| 4 | 转账处理 | `transfer_handler` | `41796c5` |
| 5 | 工具注册 | `build_tools()` 中 `ToolDefinition(name="transfer", ...)` | `67c50ed` |
| 6 | 账号脱敏 | `_redact` 字符串分支追加 `re.sub` | `e73fac3` |
| 7 | 离线演示 | `run_offline_demo` 追加 `call_07` / `call_08` 并打印审计记录 | `133d5ce` |

关键实现约束（改代码前必读）：

- `ACCOUNTS` 必须是**可变 dict**，测试 fixture 用 `store.clear(); store.update(...)` 做用例隔离；换成 `MappingProxyType` 会直接报错。
- `transfer_handler` 里的 `await asyncio.sleep(3.0)` **必须写在扣款之前**，否则超时用例会看到余额已被修改。
- 转入账户不存在要抛 `PolicyDenied("ACCOUNT_NOT_FOUND", ...)`；若放任 `KeyError`，会被框架兜底成 `TOOL_ERROR`，用例拿不到预期错误码。
- `canonical_target` 必须能区分参数组合（当前拼 `from:to:amount`），审批摘要绑定依赖它防「改金额复用审批」。
- `timeout_seconds` 必须小于 3.0，否则超时演示不成立。

---

## 五、测试说明

### 5.1 运行方式

```bash
cd /root/toolgovernance
uv run pytest tests/test_tool_governance.py -v -k "transfer"   # 只跑 transfer 链路
uv run pytest tests/test_tool_governance.py -v                 # 全部用例
```

### 5.2 用例矩阵

| # | 用例 | 覆盖环节 | 期望结果 |
| --- | --- | --- | --- |
| 1 | `test_transfer_rejects_injected_arguments_and_invalid_amount` | 参数校验 | 注入 `approved`/`user_id`、非法账号、金额 0、金额 100000.1 → 全部 `INVALID_ARGUMENT`，余额不变 |
| 2 | `test_transfer_precheck_blocks_over_limit_and_insufficient_balance` | 业务预检 | 60000 → `EXCEED_LIMIT`；20000 账户转 30000 → `INSUFFICIENT_BALANCE`；即使已审批也被预检挡住 |
| 3 | `test_transfer_is_denied_without_permission_or_whitelist_and_in_plan_mode` | 权限判断 | `PERMISSION_DENIED` / `TOOL_NOT_ALLOWED` / `PLAN_MODE_DENIED`，带审批也越不过 |
| 4 | `test_transfer_requires_approval_bound_to_arguments_and_masks_accounts` | 审批 + 脱敏 + 审计 | 未审批 `CONFIRM` → 改金额后审批失效 → 原参数 `OK`；余额 100000→98800 / 5000→6200；`from=ACC-A-****3456`；审计 `[CONFIRM, CONFIRM, APPROVED, OK]`；重放回 `CONFIRM` |
| 5 | `test_transfer_timeout_is_reported_as_unknown_and_leaves_balances_untouched` | 超时处理 | 90000 转账 → `TIMEOUT_UNKNOWN`，耗时 < 3s，双方余额不变，审计末条 `execution/TIMEOUT_UNKNOWN` |

### 5.3 测试脚手架的两个设计点

- **不依赖 pytest-asyncio**：`async_test` 装饰器用 `asyncio.run(...)` 包一层，任何 pytest 环境都能跑。
- **用例隔离**：`isolated_accounts` fixture 在每个用例前后快照/还原 `ACCOUNTS`，并 `reset_side_effects()`，保证可重复运行、互不污染。

### 5.4 三条不可违反的约定

1. 不修改 `PermissionEngine.decide` 的任何一行（优先级顺序是固定框架）。
2. 测试不允许绕过 `ToolRuntime.invoke` 直接调 handler。
3. 不删除 `TransferArgs` 继承来的 `extra="forbid"`（防注入最后屏障）。

---

## 六、验收步骤

```bash
# 1. 结构自检：测试必须在 tests/ 下
ls tool_governance_demo.py tests/conftest.py tests/test_tool_governance.py

# 2. 依赖同步（首次或 pyproject.toml 变更后）
uv sync

# 3. 跑链路测试
uv run pytest tests/test_tool_governance.py -v -k "transfer"

# 4. 跑离线演示，肉眼确认 CONFIRM 与脱敏
uv run python tool_governance_demo.py
```

**通过标准**

- 测试输出 `5 passed`；
- 演示输出中 `call_07` 为 `confirm / APPROVAL_REQUIRED`；
- `call_08` 为 `allow / OK`，且 `content` 里 `from` 为 `ACC-A-****3456`、`to` 为 `ACC-A-****4321`；
- `side_effects` 为 `{"refund_executions": 1, "shell_executions": 0}`，审计记录 11 条；
- 审计记录中 decision 阶段出现 `APPROVAL_REQUIRED → APPROVED`，execution 阶段出现 `OK`。

**最近一次验证结果**（2026-11-15，远端 `/root/toolgovernance`）

```
uv 0.13.8 / Python 3.13.14
uv run pytest tests/test_tool_governance.py -q  →  5 passed in 2.19s
```

---

## 七、常见问题排查

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 5 个用例全 FAIL，`code == "TOOL_NOT_FOUND"` | `transfer` 未注册到 `build_tools()`（任务 5 未做） | 检查 `build_tools()` 返回值是否含 `name="transfer"` |
| `ModuleNotFoundError: tool_governance_demo` | 测试文件被挪出 `tests/`，`conftest` 的 `PROJECT_ROOT` 指错 | 恢复 `tests/conftest.py` + `tests/test_tool_governance.py` 结构 |
| 超时用例拿到 `TIMEOUT` 而非 `TIMEOUT_UNKNOWN` | 策略被标成幂等，或 `effect` 不是 `WRITE` | 确认 `idempotent=False`、`Effect.WRITE` |
| 超时用例失败且余额已变化 | `sleep(3.0)` 写在扣款之后 | 把 `sleep` 移到 `ACCOUNTS[from_key] -= ...` 之前 |
| `executed.content["from"]` 仍是明文账号 | `_redact` 未追加账号正则替换（任务 6 未做） | 在邮箱脱敏之后追加 `ACC-[A-Z]-[0-9]{6}` 的函数式替换 |
| 用例单独跑通过、连跑失败 | `ACCOUNTS` 被上一个用例改脏 | 确认 `isolated_accounts` fixture 生效，且 `ACCOUNTS` 是普通 dict |
| `uv: command not found` | 远程 PATH 未包含 uv | 用 `/root/.venv-tg/bin/uv`，或确认 `/usr/local/bin/uv` 软链存在 |
| 依赖与本地不一致 | 未用锁文件同步 | 远端 `uv sync`，并把 `uv.lock` 取回提交 |

---

## 八、已知限制

- 教学拦截区间 `(50000, 80000]` 是**刻意制造的拒绝窗口**，不是真实单笔限额；真实系统应把额度、日累计、反洗钱下沉到风控服务。
- `sleep(3.0)` 仅用于演示「非幂等写超时后状态未知」，生产应引入幂等键 + 对账，而不是靠超时兜底。
- `ACCOUNTS` 是进程内可变状态，并发场景需加锁或换成带事务的存储；测试靠 fixture 快照隔离。
- 脱敏是出口最后一道，仅覆盖字符串值；日志、异常消息、审计正文若另有机密字段，同样需要过 `_redact`。
- `amount` 与余额使用 `float`，全框架一致；涉及真实金额时应改用 `Decimal` 或整数分。
- `txn_id` 取 `tool_call_id` 后 6 位，教学场景唯一；生产应使用独立生成的全局唯一交易号。

---

## 九、提交历史（实现阶段）

| commit | 说明 |
| --- | --- |
| `507dc06` | 项目基线（框架 + 作业说明） |
| `7ad2bdb` | 改为远端 uv 管理项目 |
| `3a13cca` | 任务 0：测试归位 `tests/` |
| `a2275e2` | 任务 1：ACCOUNTS 模拟账户 |
| `eecb81d` | 任务 2：`TransferArgs` |
| `c5f78ee` | 任务 3：`transfer_precheck` |
| `41796c5` | 任务 4：`transfer_handler` |
| `67c50ed` | 任务 5：注册 transfer 工具 |
| `e73fac3` | 任务 6：账号脱敏 |
| `133d5ce` | 任务 7：离线演示转账链路 |
| `0f6ed12` | 文档：修正解释器版本 |
