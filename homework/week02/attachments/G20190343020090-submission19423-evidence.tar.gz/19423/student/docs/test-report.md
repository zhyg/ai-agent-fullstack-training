# 测试文档

> 被测对象：`tool_governance_demo.py` 中 `transfer` 工具接入后的完整治理链路
> 文档性质：测试计划 + 用例明细 + 执行记录（结果均为 2026-11-15 实测）
> 工程操作说明见 [dev-and-test-guide.md](./dev-and-test-guide.md)，需求与设计见 [transfer-implementation-plan.md](./transfer-implementation-plan.md)。

---

## 1. 测试范围

| 范围 | 说明 |
| --- | --- |
| 在测功能 | `transfer` 工具：参数校验 → 权限判断 → 业务预检 → 人工审批 → 执行/超时 → 结果脱敏 → 审计 |
| 入口约定 | 全部调用经 `ToolRuntime.invoke`，不直接调用 handler |
| 不在测范围 | `get_order` / `create_refund` / `run_shell` 的既有行为；真实 DeepSeek Agent Loop（`--agent` 需 API Key）；并发与持久化 |
| 不变更约束 | `PermissionEngine.decide` 优先级顺序、`StrictArgs.extra="forbid"` |

---

## 2. 测试环境

| 项 | 值 |
| --- | --- |
| 主机 | `root@192.168.10.136`（Linux） |
| 项目目录 | `/root/toolgovernance` |
| 包管理 | uv 0.13.8（`/usr/local/bin/uv`） |
| 解释器 | `uv run python` → Python 3.13.14（项目 `.venv`） |
| 依赖 | pydantic 2.14.3、pytest 9.2.0（`uv.lock` 锁定） |
| 代码版本 | commit `299bbdf`（含任务 0–7 全部实现） |

---

## 3. 测试策略

| 层次 | 方法 | 说明 |
| --- | --- | --- |
| 黑盒链路测试 | 构造 `ExecutionContext` + `ToolCall`，只走 `runtime.invoke` | 断言返回的 `ok/action/code/content`，与实现细节解耦 |
| 状态断言 | 直接读 `ACCOUNTS` 余额 | 验证「拒绝不产生副作用」「超时不扣款」 |
| 审计断言 | 读 `AuditSink.records` | 验证 decision / execution 两阶段记录序列 |
| 时间断言 | `time.perf_counter()` | 验证超时在 `sleep(3.0)` 之前触发（耗时 < 3s） |
| 隔离 | fixture 快照还原 `ACCOUNTS` + `reset_side_effects()` | 用例可重复、互不污染 |
| 补充探索 | 临时脚本覆盖边界值与越权场景 | 补齐自动化用例未覆盖的 7 类场景 |

---

## 4. 用例总览

- **TC-01 ~ TC-05**：仓库内自动化用例（`tests/test_tool_governance.py`），可重复执行。
- **TC-06 ~ TC-12**：补充验证用例，用临时脚本执行（见附录 A），不随仓库提交。

| ID | 场景 | 期望 code | 实测结果 | 结论 |
| --- | --- | --- | --- | --- |
| TC-01 | 参数注入 / 非法账号 / 金额 0 / 超 schema 上限 | `INVALID_ARGUMENT` ×4 | 一致，余额未变 | PASS |
| TC-02 | 60000 命中教学区间；20000 账户转 30000 | `EXCEED_LIMIT` / `INSUFFICIENT_BALANCE` | 一致，三方余额未变 | PASS |
| TC-03 | 缺权限 / 不在白名单 / plan 模式（均带审批） | `PERMISSION_DENIED` / `TOOL_NOT_ALLOWED` / `PLAN_MODE_DENIED` | 一致 | PASS |
| TC-04 | 未审批 → 改金额 → 原参数 → 重放 | `CONFIRM` → `CONFIRM` → `OK` → `CONFIRM` | 一致，余额 100000→98800 / 5000→6200，账号已脱敏，审计 `[CONFIRM, CONFIRM, APPROVED, OK]` | PASS |
| TC-05 | 90000 转账触发超时 | `TIMEOUT_UNKNOWN` | 一致，耗时 < 3s，余额不变，审计末条 execution/`TIMEOUT_UNKNOWN` | PASS |
| TC-06 | 边界值 amount = 50000（左开区间端点） | 预检放行 → 未审批 `CONFIRM` | `confirm / APPROVAL_REQUIRED` | PASS |
| TC-07 | 边界值 amount = 80000（闭区间右端点） | `EXCEED_LIMIT` | `deny / EXCEED_LIMIT` | PASS |
| TC-08 | 跨租户转出（tenant_a 上下文使用 tenant_b 账户） | `INSUFFICIENT_BALANCE` | 一致，无余额探测差异 | PASS |
| TC-09 | 跨租户转入（已审批） | `ACCOUNT_NOT_FOUND` | 一致，转出余额仍 100000.0 | PASS |
| TC-10 | 他人审批（u_admin 的票被 u_100 使用） | 审批不匹配 → `CONFIRM` | `confirm / APPROVAL_REQUIRED` | PASS |
| TC-11 | `dontAsk` 模式下的高风险写 | `APPROVAL_REQUIRED`（deny） | `deny / APPROVAL_REQUIRED` | PASS |
| TC-12 | 一次性审批重复使用 | 首次 `OK`，重放 `CONFIRM` | 首次 `allow/OK`，重放 `confirm`；余额 99600.0 / 5400.0（仅执行一次） | PASS |

---

## 5. 用例明细

### TC-01 参数校验（`extra="forbid"` + Field 约束）

- **前置**：`ACCOUNTS[("tenant_a","ACC-A-123456")] = 100000.0`
- **输入**：合法参数基础上分别注入 `approved=true, user_id=u_admin`；`from_account=ACC-123456`；`amount=0.0`；`amount=100000.1`
- **期望**：4 次调用全部 `action=deny, code=INVALID_ARGUMENT`，handler 未执行
- **实测**：4 次均返回 `INVALID_ARGUMENT`，`Extra inputs are not permitted`（注入字段）与约束错误同时出现，余额 100000.0 未变
- **说明**：注入被 Schema 层拦截，不进入权限判断与预检

### TC-02 业务预检（先窗口后余额）

- **输入 A**：`60000.0`，已预先审批
- **期望 A**：`EXCEED_LIMIT`，且审批票不被消费
- **实测 A**：`deny / EXCEED_LIMIT`
- **输入 B**：余额 20000 的账户转 `30000.0`，已预先审批
- **期望 B**：`INSUFFICIENT_BALANCE`
- **实测 B**：`deny / INSUFFICIENT_BALANCE`
- **副作用**：三个账户余额均未变化，证明预检只读

### TC-03 权限判断（审批不能越权）

- **输入**：`permissions` 去掉 `transfer:execute`；`allowed_tools` 去掉 `transfer`；`mode=PLAN`；三者都携带有效审批
- **期望**：分别 `PERMISSION_DENIED`、`TOOL_NOT_ALLOWED`、`PLAN_MODE_DENIED`
- **实测**：完全一致；余额未变
- **说明**：证明 decide 的第 2–4 级先于第 6 级审批

### TC-04 审批绑定 + 成功路径 + 脱敏 + 审计

- **步骤**：
  1. 未审批调用 → 期望 `CONFIRM`
  2. 对 `amount=1200` 审批后，改 `amount=9000` 调用 → 期望 `CONFIRM`（摘要不匹配）
  3. 原参数重试 → 期望 `OK`
  4. 同一审批再重放 → 期望 `CONFIRM`
- **实测**：`CONFIRM` → `CONFIRM` → `OK` → `CONFIRM`；`txn_id=000003`；`from=ACC-A-****3456`、`to=ACC-A-****4321`；余额 98800.0 / 6200.0；审计序列 `[(decision, APPROVAL_REQUIRED), (decision, APPROVAL_REQUIRED), (decision, APPROVED), (execution, OK)]`

### TC-05 非幂等写超时

- **输入**：`90000.0`（>80000，不落入教学区间），已审批
- **期望**：`TIMEOUT_UNKNOWN`，耗时 < 3.0s，余额不变
- **实测**：`TIMEOUT_UNKNOWN`，`elapsed < 3.0`，余额 100000.0 / 5000.0 未变，审计末条 `execution / TIMEOUT_UNKNOWN`
- **说明**：证明 `sleep(3.0)` 位于扣款之前，`timeout_seconds=2.0` 先掐断

### TC-06 ~ TC-12 补充验证

| ID | 输入要点 | 期望 | 实测 |
| --- | --- | --- | --- |
| TC-06 | `amount=50000`，无审批 | 预检放行（`50000 < amount` 为假）→ `CONFIRM` | `confirm / APPROVAL_REQUIRED` |
| TC-07 | `amount=80000`，无审批 | 命中 `(50000, 80000]` → `EXCEED_LIMIT` | `deny / EXCEED_LIMIT` |
| TC-08 | `from_account=ACC-B-111111`（tenant_b 账户），上下文 tenant_a | `INSUFFICIENT_BALANCE`（不泄露账户是否存在） | `deny / INSUFFICIENT_BALANCE` |
| TC-09 | `to_account=ACC-B-111111`，已审批 | `ACCOUNT_NOT_FOUND`，扣款前失败 | `deny / ACCOUNT_NOT_FOUND`，from 余额 100000.0 |
| TC-10 | 审批以 `u_admin` 签发，调用身份 `u_100` | 用户不匹配 → `CONFIRM` | `confirm / APPROVAL_REQUIRED` |
| TC-11 | `mode=DONT_ASK`，无审批 | 非交互无法确认 → deny `APPROVAL_REQUIRED` | `deny / APPROVAL_REQUIRED` |
| TC-12 | 同一审批连续调用两次（400.0） | 首次成功，二次 `CONFIRM`；余额只变一次 | `OK` → `CONFIRM`；99600.0 / 5400.0 |

---

## 6. 执行记录

### 6.1 自动化用例

```bash
cd /root/toolgovernance
uv run pytest tests/test_tool_governance.py -v -k "transfer"
```

```
tests/test_tool_governance.py::test_transfer_rejects_injected_arguments_and_invalid_amount PASSED
tests/test_tool_governance.py::test_transfer_precheck_blocks_over_limit_and_insufficient_balance PASSED
tests/test_tool_governance.py::test_transfer_is_denied_without_permission_or_whitelist_and_in_plan_mode PASSED
tests/test_tool_governance.py::test_transfer_requires_approval_bound_to_arguments_and_masks_accounts PASSED
tests/test_tool_governance.py::test_transfer_timeout_is_reported_as_unknown_and_leaves_balances_untouched PASSED
============================== 5 passed in 2.19s ===============================
```

### 6.2 补充验证

```bash
scp tg_supp_check.py root@192.168.10.136:/tmp/
ssh root@192.168.10.136 'cd /root/toolgovernance && PYTHONPATH=/root/toolgovernance uv run python /tmp/tg_supp_check.py'
```

```
{"case": "amount=50000", "ok": false, "action": "confirm", "code": "APPROVAL_REQUIRED"}
{"case": "amount=80000", "ok": false, "action": "deny", "code": "EXCEED_LIMIT"}
{"case": "cross-tenant from", "ok": false, "action": "deny", "code": "INSUFFICIENT_BALANCE"}
{"case": "cross-tenant to", "ok": false, "action": "deny", "code": "ACCOUNT_NOT_FOUND", "extra": {"from_balance": 100000.0}}
{"case": "approval owned by other user", "ok": false, "action": "confirm", "code": "APPROVAL_REQUIRED"}
{"case": "dontAsk mode", "ok": false, "action": "deny", "code": "APPROVAL_REQUIRED"}
{"case": "approval first use", "ok": true, "action": "allow", "code": "OK"}
{"case": "approval replay", "ok": false, "action": "confirm", "code": "APPROVAL_REQUIRED"}
{"case": "balances after replay", "from": 99600.0, "to": 5400.0}
```

### 6.3 离线演示

```bash
uv run python tool_governance_demo.py
```

关键输出：

```
{"tool_call_id": "call_07", "tool_name": "transfer", "ok": false, "action": "confirm", "code": "APPROVAL_REQUIRED", ...}
{"tool_call_id": "call_08", "tool_name": "transfer", "ok": true, "action": "allow", "code": "OK", "content": {"txn_id": "all_08", "from": "ACC-A-****3456", "to": "ACC-A-****4321", ...}}
{"side_effects": {"refund_executions": 1, "shell_executions": 0}, "audit_records": 11}
```

---

## 7. 结果统计

| 指标 | 结果 |
| --- | --- |
| 自动化用例 | 5 / 5 PASSED（2.19s） |
| 补充用例 | 7 / 7 符合预期 |
| 合计 | 12 / 12 通过 |
| 缺陷 | 0 |
| 阻塞项 | 0 |

---

## 8. 缺陷与观察项

| 编号 | 类型 | 描述 | 级别 | 处理 |
| --- | --- | --- | --- | --- |
| OBS-01 | 代码观察项 | 教学窗口边界 `50_000/80_000` 在 `transfer_precheck` 与 `transfer_handler` 两处硬编码，无命名常量，边界漂移时需同步修改 | minor | 代码评审后决定保持现状：计划文档规定了字面量写法，教学场景风险低 |
| — | 功能缺陷 | 未发现 | — | — |

---

## 9. 测试结论

1. `transfer` 已完整接入治理链路，7 个环节均在测试中被触发并有断言覆盖。
2. 关键安全性质得到验证：拒绝路径无副作用、预检先于审批、审批参数绑定且一次性、超时早于扣款、账号出口脱敏、审计两阶段留痕。
3. 跨租户与跨用户越权场景在补充验证中被正确拒绝，未出现账户存在性信息泄露。
4. 5 个自动化用例可重复执行（`ACCOUNTS` fixture 隔离），满足验收命令 `5 passed`。

---

## 附录 A：补充验证脚本（`tg_supp_check.py`）

> 临时脚本，位于远端 `/tmp/`，不纳入仓库；依赖 `PYTHONPATH` 指向项目根。

```python
"""补充验证脚本（不入库）：覆盖现有 5 个用例之外的边界与越权场景。"""

import asyncio
import json

import tool_governance_demo as demo

FROM_A = "ACC-A-123456"  # tenant_a，100000.0
TO_A = "ACC-A-654321"  # tenant_a，5000.0
FOREIGN = "ACC-B-111111"  # tenant_b，50000.0


def ctx(**overrides):
    defaults = dict(
        permissions=frozenset({"order:read", "refund:create", "shell:run", "transfer:execute"}),
        allowed_tools=frozenset({"get_order", "create_refund", "run_shell", "transfer"}),
    )
    return demo.base_context(**{**defaults, **overrides})


async def invoke(runtime, call_id, arguments, **overrides):
    return await runtime.invoke(demo.ToolCall(call_id, "transfer", arguments), ctx(**overrides))


def row(case, result, extra=None):
    payload = {"case": case, "ok": result.ok, "action": str(result.action), "code": result.code}
    if extra is not None:
        payload["extra"] = extra
    print(json.dumps(payload, ensure_ascii=False, default=str))


async def main():
    runtime, approvals, _audit = demo.build_runtime()

    # TC-06 边界：50000 不在拦截区间（左开），未审批 → CONFIRM
    row("amount=50000", await invoke(runtime, "call_supp_01", {"from_account": FROM_A, "to_account": TO_A, "amount": 50_000.0}))

    # TC-07 边界：80000 命中闭区间右端点 → EXCEED_LIMIT
    row("amount=80000", await invoke(runtime, "call_supp_02", {"from_account": FROM_A, "to_account": TO_A, "amount": 80_000.0}))

    # TC-08 跨租户转出：tenant_a 下不存在 ACC-B-111111 → INSUFFICIENT_BALANCE
    row("cross-tenant from", await invoke(runtime, "call_supp_03", {"from_account": FOREIGN, "to_account": TO_A, "amount": 100.0}))

    # TC-09 跨租户转入：审批通过后 handler 抛 ACCOUNT_NOT_FOUND，且余额未动
    args = {"from_account": FROM_A, "to_account": FOREIGN, "amount": 100.0}
    approvals.approve("ap_supp_01", ctx(), "transfer", args)
    row(
        "cross-tenant to",
        await invoke(runtime, "call_supp_04", args, approval_id="ap_supp_01"),
        {"from_balance": demo.ACCOUNTS[("tenant_a", FROM_A)]},
    )

    # TC-10 审批跨用户复用：u_admin 的审批被 u_100 使用 → 不匹配 → CONFIRM
    args = {"from_account": FROM_A, "to_account": TO_A, "amount": 200.0}
    approvals.approve("ap_supp_02", ctx(user_id="u_admin"), "transfer", args)
    row("approval owned by other user", await invoke(runtime, "call_supp_05", args, approval_id="ap_supp_02"))

    # TC-11 dontAsk 模式：高风险写需审批，非交互 → DENY/APPROVAL_REQUIRED
    row(
        "dontAsk mode",
        await invoke(
            runtime,
            "call_supp_06",
            {"from_account": FROM_A, "to_account": TO_A, "amount": 300.0},
            mode=demo.PermissionMode.DONT_ASK,
        ),
    )

    # TC-12 一次性审批：同一审批第二次使用被拒
    runtime2, approvals2, _ = demo.build_runtime()
    args = {"from_account": FROM_A, "to_account": TO_A, "amount": 400.0}
    approvals2.approve("ap_supp_03", ctx(), "transfer", args)
    first = await invoke(runtime2, "call_supp_07", args, approval_id="ap_supp_03")
    second = await invoke(runtime2, "call_supp_08", args, approval_id="ap_supp_03")
    row("approval first use", first)
    row("approval replay", second)
    print(
        json.dumps(
            {
                "case": "balances after replay",
                "from": demo.ACCOUNTS[("tenant_a", FROM_A)],
                "to": demo.ACCOUNTS[("tenant_a", TO_A)],
            },
            ensure_ascii=False,
        )
    )


asyncio.run(main())
```
