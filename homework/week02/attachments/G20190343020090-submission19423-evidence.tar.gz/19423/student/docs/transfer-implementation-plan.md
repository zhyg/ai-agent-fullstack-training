# 转账工具（transfer）接入开发文档

> 目标：在 `tool_governance_demo.py` 的既有治理框架上接入 `transfer` 工具，跑通
> **参数校验 → 业务预检 → 权限判断 → 人工审批 → 超时处理 → 结果脱敏 → 审计追踪** 完整链路。
> 验收命令：`uv run pytest tests/test_tool_governance.py -v -k transfer`，5 个用例全 PASSED。

---

## 一、需求分析

### 1.1 现状基线（第一步已执行）

| 检查项 | 结果 |
| --- | --- |
| 环境管理 | 远程 Linux `/root/toolgovernance`，uv 0.13.8（`/root/.venv-tg/bin/uv`）；依赖由 `uv sync` 写入项目内 `.venv`，解释器统一走 `uv run` |
| 解释器 | `uv run python` → Python 3.13.14（项目 `.venv`） |
| 依赖 | pydantic 2.14.3、pytest 9.2.0（声明在 `pyproject.toml`） |
| `uv run python tool_governance_demo.py` | 正常退出，输出 6 条结果 + side_effects/audit 统计 |
| `uv run pytest -k transfer`（改造前） | 5 failed，失败原因为 `TOOL_NOT_FOUND`（transfer 尚未注册），不是导入错误 |

结论：框架本身可运行，测试脚手架（`tests/conftest.py` 把项目根注入 `sys.path`）工作正常，缺的只是 6 个待补位置。

### 1.2 治理链路与代码落点

框架的确定性顺序**不能改**，`PermissionEngine.decide` 已有 9 级固定优先级。新工具只是插进去，不重排：

| 阶段 | 承载位置（不可改） | transfer 需要做什么 |
| --- | --- | --- |
| ① 参数校验 | `ToolRuntime.invoke` → `parameters_model.model_validate` | 任务 2：`TransferArgs` 用 `Field` 声明账号正则与金额区间；继承 `StrictArgs` 获得 `extra="forbid"` |
| ② 权限判断 | `decide` 第 1–4 步（deny 规则 → plan → 白名单 → RBAC） | 任务 5：`permission="transfer:execute"`、`effect=WRITE`（使 plan 模式天然被拒） |
| ③ 业务预检 | `decide` 第 5 步 `await tool.precheck(...)`，抛 `PolicyDenied` 即 DENY | 任务 3：`transfer_precheck` 只判断、不改余额 |
| ④ 人工审批 | `decide` 第 6 步（`requires_approval` 或 `risk=HIGH`）+ `ApprovalStore` 参数摘要绑定、一次性消费 | 任务 5：`requires_approval=True` + `risk=HIGH`；返回 `CONFIRM/APPROVAL_REQUIRED` |
| ⑤ 超时处理 | `_execute_with_recovery` 的 `asyncio.timeout(policy.timeout_seconds)` | 任务 4：`amount > 80000` 时 `sleep(3.0)`；任务 5：`timeout_seconds=2.0 < 3.0`，非幂等 → `TIMEOUT_UNKNOWN` |
| ⑥ 结果脱敏 | `invoke` 的 `finalize` → `_redact(dict(raw))` | 任务 6：账号 `ACC-A-123456` → `ACC-A-****3456` |
| ⑦ 审计追踪 | `AuditSink`：decision 阶段记 deny/confirm/approved，execution 阶段记 OK/超时 | 无需改动，靠工具正确接进链路自动产生 |

关键洞察：**②在③之前，③在④之前**。所以
- 无权限 / 不在白名单 / plan 模式的调用，拿不到任何业务信息（余额不会被探测）；
- 预检失败时一次性审批**尚未被消费**（`decide` 第 5 步先于第 6 步），不会浪费审批票据。

### 1.3 需求约束转译（逐条落到实现）

| 需求 | 实现约束 | 违反后果 |
| --- | --- | --- |
| 金额 50000 < amount ≤ 80000 报 `EXCEED_LIMIT` | 区间上界必须是**闭区间 80000**、下界开区间 50000；`amount > 80000` 必须放行预检 | 写成 `amount > 50000` 会把 90000 也拦掉，超时用例无法触发 |
| 余额检查 | 从 `ACCOUNTS[(tenant_id, from_account)]` 取值比金额 | 跨租户越权（tenant_a 花 tenant_b 的钱） |
| 超时点必须在扣款之前 | `sleep` 写在扣款语句前 | `asyncio.timeout` 掐断时已扣款，余额被改，用例断言失败 |
| 转入账户不存在报 `ACCOUNT_NOT_FOUND` | handler 内 `to_key not in ACCOUNTS` 抛 `PolicyDenied` | 用例拿不到该错误码；KeyError 会被兜底成 `TOOL_ERROR` |
| 审批参数绑定 | `canonical_target` 需区分不同参数组合；摘要用完整参数 dict | 改金额后同一审批仍可用（越权放行） |
| 一次性审批 | 靠框架 `ApprovalRecord.used` | 同一审批重放成功（重放攻击） |
| 脱敏保留前缀与末 4 位 | 正则 `ACC-[A-Z]-[0-9]{6}`，替换后形如 `ACC-A-****3456` | 用例断言 `executed.content["from"]` 失败 |
| ACCOUNTS 可被测试快照还原 | 必须是模块级**可变 dict**，不能是 `MappingProxyType`/常量 | fixture `store.clear(); store.update(...)` 抛错，用例互相污染 |

### 1.4 验收矩阵（5 个用例 ↔ 链路环节）

| # | 用例 | 校验要点 | 期望 |
| --- | --- | --- | --- |
| 1 | `rejects_injected_arguments_and_invalid_amount` | 注入 `approved`/`user_id`、账号格式非法、金额 0、金额 10 万+ | 全部 `INVALID_ARGUMENT`，余额不变（`extra="forbid"` + `Field` 双重拦截，handler 未执行） |
| 2 | `precheck_blocks_over_limit_and_insufficient_balance` | 60000 命中教学区间；20000 账户转 30000 | `EXCEED_LIMIT` / `INSUFFICIENT_BALANCE`，且**已批审批也被业务预检挡住**，三方余额不变 |
| 3 | `denied_without_permission_or_whitelist_and_in_plan_mode` | 缺 `transfer:execute`、不在白名单、plan 模式 | `PERMISSION_DENIED` / `TOOL_NOT_ALLOWED` / `PLAN_MODE_DENIED`，带上审批也越不过 |
| 4 | `requires_approval_bound_to_arguments_and_masks_accounts` | 未审批→`CONFIRM`；改金额→审批失效；原参数→成功；审计序列；重放 | 余额 100000→98800 / 5000→6200，`from=ACC-A-****3456`，审计 `[CONFIRM, CONFIRM, APPROVED, OK]`，重放回 `CONFIRM` |
| 5 | `timeout...` | 90000 转账 | `TIMEOUT_UNKNOWN`，耗时 < 3s，双方余额不变，审计末条 execution/`TIMEOUT_UNKNOWN` |

### 1.5 三条红线（本次不改）

1. `PermissionEngine.decide` 一行都不动。
2. 测试只走 `ToolRuntime.invoke`，不直接调 handler。
3. 不删 `TransferArgs` 继承来的 `extra="forbid"`。

---

## 二、分步开发

### 任务 0：目录准备（验收命令的前置条件）

验收命令是 `python -m pytest tests/test_tool_governance.py`，而当前 `conftest.py` 与
`test_tool_governance.py` 都在项目根目录。`conftest.py` 里 `PROJECT_ROOT = Path(__file__).resolve().parent.parent`
的设计意图就是让 conftest 位于 `tests/` 一级、向上取到项目根并把根目录注入 `sys.path`（否则取到的是上一层目录，`import tool_governance_demo` 不可靠）。因此动手前先归位：

```bash
mkdir tests
mv conftest.py test_tool_governance.py tests/
```

`tool_governance_demo.py` 保持在项目根不动。此调整只动位置、不改测试内容。

### 任务 1：模拟账户数据（ACCOUNTS）

位置：`ORDERS` 之后（原 `ACCOUNTS: dict[...] = {}` 占位处）。

```python
ACCOUNTS: dict[tuple[str, str], float] = {
    ("tenant_a", "ACC-A-123456"): 100_000.0,
    ("tenant_a", "ACC-A-654321"): 5_000.0,
    ("tenant_a", "ACC-A-888888"): 20_000.0,
    ("tenant_b", "ACC-B-111111"): 50_000.0,
}
```

要点：Key 带 `tenant_id`，余额查询与扣款都必须用 `context.tenant_id` 组 key，天然隔离租户；必须保持可变 dict。

验证：`ACCOUNTS[("tenant_a", "ACC-A-123456")] == 100000.0`。

### 任务 2：`TransferArgs` 参数模型

```python
class TransferArgs(StrictArgs):
    from_account: str = Field(pattern=r"^ACC-[A-Z]-[0-9]{6}$")
    to_account: str = Field(pattern=r"^ACC-[A-Z]-[0-9]{6}$")
    amount: float = Field(gt=0, le=100_000)
```

要点：`StrictArgs` 已带 `extra="forbid"` 与 `strict=True`，模型多传 `approved`/`user_id` 直接 `ValidationError`；
`le=100_000` 是 schema 层上限（100000.1 在此被拒），与任务 3 的教学区间是两回事。

验证：`TransferArgs.model_validate({...})` 非法参数抛 `ValidationError`；`model_json_schema()` 能投影给模型。

### 任务 3：`transfer_precheck` 业务预检

```python
async def transfer_precheck(raw_arguments: ArgsModel, context: ExecutionContext) -> None:
    arguments = raw_arguments
    assert isinstance(arguments, TransferArgs)
    if 50_000 < arguments.amount <= 80_000:
        raise PolicyDenied("EXCEED_LIMIT", "金额命中教学拦截区间 (50000, 80000]")
    balance = ACCOUNTS.get((context.tenant_id, arguments.from_account))
    if balance is None or balance < arguments.amount:
        raise PolicyDenied("INSUFFICIENT_BALANCE", "转出账户余额不足")
```

要点：顺序固定（先区间后余额）；**只读不写**；`balance is None` 归入 `INSUFFICIENT_BALANCE`（转出账户在本租户不存在等同于不可支付，也避免跨租户探测到「账户存在但余额不足」的差异）。

验证：60000 → `EXCEED_LIMIT`；20000 转 30000 → `INSUFFICIENT_BALANCE`；90000 → 通过（余额 100000 充足）。

### 任务 4：`transfer_handler` 转账处理

```python
async def transfer_handler(tool_call_id, raw_arguments, context) -> Mapping[str, Any]:
    arguments = raw_arguments
    assert isinstance(arguments, TransferArgs)
    if arguments.amount > 80_000:
        await asyncio.sleep(3.0)          # 必须在扣款之前
    from_key = (context.tenant_id, arguments.from_account)
    to_key = (context.tenant_id, arguments.to_account)
    if to_key not in ACCOUNTS:
        raise PolicyDenied("ACCOUNT_NOT_FOUND", "转入账户不存在")
    ACCOUNTS[from_key] -= arguments.amount
    ACCOUNTS[to_key] += arguments.amount
    return {
        "txn_id": tool_call_id[-6:],
        "from": arguments.from_account,
        "to": arguments.to_account,
        "amount": arguments.amount,
        "status": "accepted",
    }
```

要点：
- `sleep` 放在最前面，`asyncio.timeout` 掐断时余额尚未变动（这是用例 5 的核心断言）；
- 只有预检通过才会进 handler，所以 `from_key` 必然存在，扣款不会 KeyError；
- 返回值 key 名固定（`txn_id/from/to/amount/status`），脱敏在框架侧做，handler 不自己打码。

验证：`txn_id == "000003"`（`call_tr_000003` 后 6 位）；余额 100000→98800 / 5000→6200。

### 任务 5：注册到 `build_tools()`

```python
ToolDefinition(
    name="transfer",
    description="在当前租户的账户之间转账（教学模拟，需人工审批）",
    parameters_model=TransferArgs,
    policy=ToolPolicy(
        Effect.WRITE, Risk.HIGH, "transfer:execute",
        True,      # requires_approval
        2.0,       # timeout_seconds < 3.0，先于 sleep 掐断
        0,         # max_retries
        False,     # idempotent=False → 超时映射 TIMEOUT_UNKNOWN
    ),
    handler=transfer_handler,
    precheck=transfer_precheck,
    canonical_target=lambda args: (
        f"{getattr(args, 'from_account')}:{getattr(args, 'to_account')}:{getattr(args, 'amount')}"
    ),
),
```

要点：`effect=WRITE` 让 plan 模式被第 2 步拒绝；`requires_approval=True` 与 `risk=HIGH` 双重触发第 6 步审批；
`timeout_seconds=2.0` 是超时演示成立的硬条件（必须 < 3.0）。

验证：`TOOL_NOT_FOUND` 消失；未审批返回 `CONFIRM/APPROVAL_REQUIRED`。

### 任务 6：账号脱敏

在 `_redact` 的字符串分支、邮箱脱敏之后追加：

```python
        value = re.sub(
            r"ACC-[A-Z]-[0-9]{6}",
            lambda match: f"{match.group(0)[:6]}****{match.group(0)[-4:]}",
            value,
        )
```

要点：`ACC-A-123456` 前 6 位是 `ACC-A-`，末 4 位 `3456` → `ACC-A-****3456`；用函数式替换避免反斜杠转义问题。
注意脱敏只作用于「值」，映射的 key 只对 `token|secret|password|authorization` 打码，所以 `from`/`to` 的值会被处理而字段名保留。

验证：`executed.content["from"] == "ACC-A-****3456"`、`["to"] == "ACC-A-****4321"`。

### 任务 7（补充）：`run_offline_demo` 展示转账链路

在 demo 里追加 3 次 transfer 调用，让离线输出直接可见「先 CONFIRM → 审批后成功 → 账号已脱敏」，并打印审计记录。
需要一份带 `transfer:execute` 权限与白名单的 context（`base_context` 不动，用 `replace` 派生）。

验证：输出中 `call_07` 为 `confirm/APPROVAL_REQUIRED`，`call_08` 为 `allow/OK` 且 content 里账号已打码。

---

## 三、验收步骤

```bash
# 1. 结构（验收命令要求测试在 tests/ 下）
ToolGovernance/
├── tool_governance_demo.py
└── tests/
    ├── conftest.py            # 把项目根注入 sys.path，供 import tool_governance_demo
    └── test_tool_governance.py

# 2. 同步依赖（首次或 pyproject.toml 变更后）
uv sync

# 3. 跑 5 个链路测试
uv run pytest tests/test_tool_governance.py -v -k "transfer"

# 4. 跑离线演示，肉眼确认 CONFIRM 与脱敏
uv run python tool_governance_demo.py
```

通过标准：
- `5 passed`；
- 演示输出存在 `"action": "confirm"`（transfer 未审批）、成功后 `"from": "ACC-A-****3456"`；
- 审计记录中 decision 阶段出现 `APPROVAL_REQUIRED → APPROVED`，execution 阶段出现 `OK` / `TIMEOUT_UNKNOWN`。

## 四、风险与已知限制

- 教学区间 `(50000, 80000]` 是刻意制造的拒绝窗口，不是真实单笔限额；真实系统应把额度、日累计、反洗钱规则下沉到风控服务。
- `sleep(3.0)` 只用来说明「非幂等写超时后状态未知」，生产应引入幂等键 + 对账，而不是靠超时兜底。
- `ACCOUNTS` 是进程内可变状态，并发场景需加锁或换成带事务的存储；测试用 fixture 快照隔离。
- 脱敏是「出口最后一道」，仅覆盖字符串值；日志、异常消息、审计正文若另有机密字段，需同样过 `_redact`。
