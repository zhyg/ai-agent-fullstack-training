#!/usr/bin/env bash
# From any directory: bash /path/to/19423/run_checks.sh /path/to/python
# The supplied interpreter must have Pydantic 2.14.3 and pytest 9.2.0.
set -u
ROOT="$(dirname "$(realpath "$0")")"
PY="$(realpath -s "${1:-$ROOT/venv/bin/python}")"
export PYTHONPATH="$ROOT/student"
mkdir -p "$ROOT/logs"
run() {
    local name="$1"
    shift
    printf 'COMMAND: ' > "$ROOT/logs/$name.log"
    printf '%q ' "$@" >> "$ROOT/logs/$name.log"
    printf '\n' >> "$ROOT/logs/$name.log"
    "$@" >> "$ROOT/logs/$name.log" 2>&1
    local rc=$?
    printf '\nEXIT_CODE=%s\n' "$rc" >> "$ROOT/logs/$name.log"
    cat "$ROOT/logs/$name.log"
    return "$rc"
}
run environment "$PY" -c 'import sys,pydantic,pytest,tool_governance_demo as d; print(sys.version); print("Pydantic",pydantic.__version__,"pytest",pytest.__version__); print("IMPORTED",d.__file__)' || exit $?
run original "$PY" -m pytest -p no:cacheprovider "$ROOT/baseline/test_tool_governance.py" -v -k transfer || exit $?
# Keep demo.log as pure JSON lines for independent output assertions.
printf 'COMMAND: %q %q\n' "$PY" "$ROOT/student/tool_governance_demo.py" > "$ROOT/logs/demo-command.log"
"$PY" "$ROOT/student/tool_governance_demo.py" > "$ROOT/logs/demo.log" 2>&1
rc=$?
printf 'EXIT_CODE=%s\n' "$rc" >> "$ROOT/logs/demo-command.log"
cat "$ROOT/logs/demo-command.log" "$ROOT/logs/demo.log"
if [ "$rc" != 0 ]; then exit "$rc"; fi
run supplement "$PY" -m pytest -p no:cacheprovider "$ROOT/test_supplement.py" -v -s || exit $?
run submitted "$PY" -m pytest -p no:cacheprovider "$ROOT/student/tests/test_tool_governance.py" -v -k transfer || exit $?
