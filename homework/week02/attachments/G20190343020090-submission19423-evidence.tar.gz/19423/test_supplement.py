"""教师独立补测：只调用学生 Runtime；不改学生实现或可信原测断言。"""
import ast
import asyncio
import functools
import inspect
import json
import time
from dataclasses import asdict, replace
from pathlib import Path

import pytest
import tool_governance_demo as d

ROOT = Path(__file__).resolve().parent
F, T, S, B = "ACC-A-123456", "ACC-A-654321", "ACC-A-888888", "ACC-B-111111"
INITIAL = {("tenant_a", F): 100000.0, ("tenant_a", T): 5000.0,
           ("tenant_a", S): 20000.0, ("tenant_b", B): 50000.0}
VALID = dict(from_account=F, to_account=T, amount=1200.0)

def sync(fn):
    @functools.wraps(fn)
    def run(*a, **kw):
        return asyncio.run(fn(*a, **kw))
    return run

@pytest.fixture(autouse=True)
def isolate():
    old = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(old)

def ctx(**kw):
    return d.base_context(permissions=frozenset({"transfer:execute", "order:read"}),
                          allowed_tools=frozenset({"transfer", "get_order"}), **kw)

async def invoke(rt, args, context=None, call_id="teacher_000123"):
    result = await rt.invoke(d.ToolCall(call_id, "transfer", args), context or ctx())
    print(json.dumps({"input": args, "result": asdict(result)}, ensure_ascii=False))
    return result

def approve(store, args, context=None):
    context = context or ctx()
    store.approve("teacher_approval", context, "transfer", d.TransferArgs.model_validate(args))
    return replace(context, approval_id="teacher_approval")

def test_A01_initial_and_A10_fixed_engine():
    assert d.ACCOUNTS == INITIAL
    assert all(isinstance(v, float) for v in d.ACCOUNTS.values())
    student = Path(d.__file__).read_text()
    original = (ROOT / "baseline/tool_governance_demo-无答案.py").read_text()
    def method(text):
        tree = ast.parse(text)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "PermissionEngine")
        return next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "decide")
    a, b = method(original), method(student)
    source_a = ast.get_source_segment(original, a)
    source_b = ast.get_source_segment(student, b)
    print("IMPORTED", d.__file__)
    print("PermissionEngine.decide source_equal=", source_a == source_b,
          "AST_equal=", ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False))
    assert source_a == source_b
    assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)
    print("TransferArgs config", d.TransferArgs.model_config)
    assert issubclass(d.TransferArgs, d.StrictArgs)
    assert d.TransferArgs.model_config["strict"] is True
    assert d.TransferArgs.model_config["extra"] == "forbid"

INVALID = [
    {k: v for k, v in VALID.items() if k != missing}
    for missing in ("from_account", "to_account", "amount")
] + [{**VALID, **change} for change in (
    {"approved": True}, {"user_id": "admin"}, {"amount": -1.0}, {"amount": "1200"},
    {"amount": True}, {"from_account": "ACC-123456"}, {"to_account": "ACC-a-123456"},
    {"from_account": 123456}, {"to_account": "ACC-A-1234567"},
)]

@pytest.mark.parametrize("args", INVALID)
@sync
async def test_A02_strict_arguments(args):
    rt, _, audit = d.build_runtime()
    r = await invoke(rt, args)
    assert (r.ok, r.action, r.code) == (False, d.DecisionAction.DENY, "INVALID_ARGUMENT")
    assert d.ACCOUNTS == INITIAL
    assert [(x.phase, x.code) for x in audit.records] == [("decision", "INVALID_ARGUMENT")]

@pytest.mark.parametrize("amount,code,action", [
    (50000.0, "APPROVAL_REQUIRED", "confirm"), (50000.01, "EXCEED_LIMIT", "deny"),
    (80000.0, "EXCEED_LIMIT", "deny"), (80000.01, "APPROVAL_REQUIRED", "confirm"),
    (100000.0, "APPROVAL_REQUIRED", "confirm"), (100000.01, "INVALID_ARGUMENT", "deny"),
])
@sync
async def test_A03_unapproved_boundaries(amount, code, action):
    rt, _, audit = d.build_runtime()
    r = await invoke(rt, {**VALID, "amount": amount})
    assert (r.code, r.action) == (code, action)
    assert d.ACCOUNTS == INITIAL
    assert len(audit.records) == 1 and audit.records[-1].phase == "decision"

@pytest.mark.parametrize("amount", [80000.01, 100000.0])
@sync
async def test_A03_approved_timeout(amount):
    rt, store, audit = d.build_runtime()
    args = {**VALID, "amount": amount}
    context = approve(store, args)
    start = time.perf_counter()
    r = await invoke(rt, args, context)
    elapsed = time.perf_counter() - start
    print("TIMEOUT_ELAPSED", elapsed, "BALANCES_UNCHANGED", d.ACCOUNTS == INITIAL)
    assert r.code == "TIMEOUT_UNKNOWN" and not r.ok and not r.retryable
    assert 1.8 <= elapsed < 3
    assert d.ACCOUNTS == INITIAL
    assert [(x.phase, x.code) for x in audit.records] == [("decision", "APPROVED"), ("execution", "TIMEOUT_UNKNOWN")]
    assert (await invoke(rt, args, context)).action == d.DecisionAction.CONFIRM

@pytest.mark.parametrize("amount,code", [(30000.0, "INSUFFICIENT_BALANCE"), (60000.0, "EXCEED_LIMIT")])
@sync
async def test_A04_order_readonly_and_unconsumed_approval(amount, code):
    rt, store, audit = d.build_runtime()
    args = {**VALID, "from_account": S, "amount": amount}
    # 有效审批先创建，但第一轮不携带；第二轮携带，预检仍须先拒绝且不消费。
    context = approve(store, args)
    for c in (ctx(), context):
        r = await invoke(rt, args, c)
        assert (r.code, r.action) == (code, d.DecisionAction.DENY)
        assert d.ACCOUNTS == INITIAL
        assert audit.records[-1].phase == "decision"
    assert len(audit.records) == 2
    assert store._records["teacher_approval"].used is False
    print("APPROVAL_UNCONSUMED", True)

@sync
async def test_A05_full_balance_and_transaction():
    rt, store, audit = d.build_runtime()
    args = {**VALID, "from_account": S, "amount": 20000.0}
    r = await invoke(rt, args, approve(store, args), "call_tr_000003")
    assert r.ok and r.code == "OK"
    assert r.content == {"txn_id": "000003", "from": "ACC-A-****8888", "to": "ACC-A-****4321", "amount": 20000.0, "status": "accepted"}
    assert d.ACCOUNTS == {**INITIAL, ("tenant_a", S): 0.0, ("tenant_a", T): 25000.0}
    assert [(x.phase, x.code) for x in audit.records] == [("decision", "APPROVED"), ("execution", "OK")]

@pytest.mark.parametrize("target", ["ACC-A-999999", B])
@sync
async def test_A06_A07_missing_or_foreign_destination(target):
    rt, store, audit = d.build_runtime()
    args = {**VALID, "to_account": target}
    r = await invoke(rt, args, approve(store, args))
    assert (r.code, r.content) == ("ACCOUNT_NOT_FOUND", "转入账户不存在")
    assert not r.ok and d.ACCOUNTS == INITIAL
    assert [(x.phase, x.code) for x in audit.records] == [("decision", "APPROVED"), ("execution", "ACCOUNT_NOT_FOUND")]

@sync
async def test_A07_foreign_source():
    rt, _, audit = d.build_runtime()
    r = await invoke(rt, {**VALID, "from_account": B})
    assert (r.code, r.action) == ("INSUFFICIENT_BALANCE", d.DecisionAction.DENY)
    assert d.ACCOUNTS == INITIAL
    assert len(audit.records) == 1 and audit.records[-1].phase == "decision"

def test_A08_registration_and_complete_target():
    tool = next(t for t in d.build_tools() if t.name == "transfer")
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    p = tool.policy
    assert p.effect is d.Effect.WRITE and p.permission == "transfer:execute"
    assert p.requires_approval or p.risk is d.Risk.HIGH
    assert 0 < p.timeout_seconds < 3 and p.idempotent is False and p.max_retries == 0
    variants = [VALID, {**VALID, "from_account": S}, {**VALID, "to_account": S}, {**VALID, "amount": 1200.01}]
    targets = [tool.canonical_target(d.TransferArgs.model_validate(a)) for a in variants]
    assert len(set(targets)) == 4
    print("POLICY", asdict(p), "TARGETS", targets)
    source = inspect.getsource(d.transfer_handler)
    assert "await asyncio.sleep(3.0)" in source
    assert source.index("await asyncio.sleep(3.0)") < source.index("ACCOUNTS[from_key] -=")
    assert source.index("if to_key not in ACCOUNTS") < source.index("ACCOUNTS[from_key] -=")

@sync
async def test_A09_redaction_and_order_regression():
    rt, _, _ = d.build_runtime()
    r = await rt.invoke(d.ToolCall("order_000001", "get_order", {"order_id": "ord_1001"}), ctx())
    assert r.ok and r.content["customer_email"] == "***@***" and r.content["access_token"] == "***"
    raw = {"nested": [{"account": F, "email": "alice@example.com", "PASSWORD": "sensitive"}], "authorization": "sensitive", "pair": (T, 12)}
    expected = {"nested": [{"account": "ACC-A-****3456", "email": "***@***", "PASSWORD": "***"}], "authorization": "***", "pair": ["ACC-A-****4321", 12]}
    assert d._redact(raw) == expected
    print("REDACTED", json.dumps(d._redact(raw), ensure_ascii=False))

def test_A10_submitted_demo_output():
    lines = [json.loads(x) for x in (ROOT / "logs/demo.log").read_text().splitlines()]
    results = {x["tool_call_id"]: x for x in lines if x.get("tool_name") == "transfer" and "ok" in x}
    assert results["call_07"]["action"] == "confirm"
    assert results["call_08"]["ok"] is True
    assert results["call_08"]["content"]["from"] == "ACC-A-****3456"
    assert results["call_08"]["content"]["to"] == "ACC-A-****4321"
    audit = [x for x in lines if x.get("tool_name") == "transfer" and "phase" in x]
    assert [(x["tool_call_id"], x["phase"], x["code"]) for x in audit] == [
        ("call_07", "decision", "APPROVAL_REQUIRED"), ("call_08", "decision", "APPROVED"), ("call_08", "execution", "OK")]
    assert {x["trace_id"] for x in audit} == {"trace_demo"}
    print("SUBMITTED_DEMO_CONFIRM_SUCCESS_REDACTION_AUDIT", True)
