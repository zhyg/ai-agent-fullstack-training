#!/bin/bash
set -u
ROOT=/home/user/workspace/repo
BASE=$ROOT/.amp/in/orb-backup/grading19502
PY=$BASE/venv/bin/python
export PYTHONPATH=$BASE/student
export PYTHONDONTWRITEBYTECODE=1
run() {
  local name=$1
  shift
  { printf 'COMMAND: '; printf '%q ' "$@"; printf '\n'; "$@"; code=$?; echo "EXIT_CODE=$code"; } > "$BASE/evidence/logs/$name.log" 2>&1
  cat "$BASE/evidence/logs/$name.log"
}
run environment "$PY" -c 'import sys,platform,pydantic,pytest,tool_governance_demo as d; print(sys.version); print(platform.platform()); print("Pydantic",pydantic.__version__,"pytest",pytest.__version__); print("IMPORTED",d.__file__)'
run trusted "$PY" -m pytest "$BASE/evidence/trusted/test_tool_governance.py" -v -k transfer -p no:cacheprovider
run supplemental "$PY" -m pytest "$BASE/evidence/supplemental/test_supplemental.py" -v -s -p no:cacheprovider
run original_demo "$PY" "$BASE/student/tool_governance_demo.py"
