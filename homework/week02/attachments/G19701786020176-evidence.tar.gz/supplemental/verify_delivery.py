from pathlib import Path
import hashlib
import re
import tarfile

root=Path('/home/user/workspace/repo')
base=root/'.amp/in/orb-backup/grading19502/evidence'
out=root/'.amp/in/week-grading'
prefix='G19701786020176-19502'
feedback=(out/f'{prefix}-feedback.md').read_text()
evaluation=(out/f'{prefix}-evaluation.md').read_text()
scores=[int(x) for x in re.findall(r'\| (\d+)/\d+ \|',evaluation)]
assert scores==[10,15,20,20,15,10,7],scores
assert sum(scores)==97
sections=re.split(r'\*\*[234]\. [^\n]+\*\*',feedback)[1:]
assert len(sections)==3
for section in sections:
    assert len(section.strip())<=500
assert '扣分' not in feedback and '97分' in feedback
for name in ['feedback','evaluation']:
    file=f'{prefix}-{name}.md'
    assert (base/'reports'/file).read_bytes()==(out/file).read_bytes()
with tarfile.open(out/f'{prefix}-evidence.tar.gz') as archive:
    names=archive.getnames()
    assert not any(re.search(r'(^|/)(\.git|\.venv|venv|node_modules|__pycache__)(/|$)',n) for n in names)
    for line in (base/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        data=archive.extractfile(name).read()
        assert hashlib.sha256(data).hexdigest()==digest,name
    assert archive.extractfile('./trusted/test_tool_governance.py').read()==(root/'hw-guide/week02/hw2/test_tool_governance.py').read_bytes()
    assert archive.extractfile('./source/tool_governance_demo.py').read()==(root/'.amp/in/orb-backup/grading19502/student/tool_governance_demo.py').read_bytes()
print('PASS: seven scores sum to 97; feedback sections <=500 chars; reports match; archive hashes match; trusted tests and student code unchanged; no dependencies or credential files')
