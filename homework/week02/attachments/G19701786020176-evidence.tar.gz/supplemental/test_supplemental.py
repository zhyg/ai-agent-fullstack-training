import ast
import asyncio
import dataclasses
import inspect
import json
from pathlib import Path
import subprocess
import sys
import textwrap
import time

import pytest
import tool_governance_demo as d

ROOT = Path(__file__).resolve().parents[1]
INITIAL = dict(d.ACCOUNTS)
BASE = dict(from_account='ACC-A-123456', to_account='ACC-A-654321', amount=100.0)

@pytest.fixture(autouse=True)
def isolate():
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(INITIAL)
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(INITIAL)

def ctx(**kw):
    return d.base_context(permissions=frozenset({'order:read', 'transfer:execute'}), allowed_tools=frozenset({'transfer', 'get_order'}), **kw)

def run(args, approved=False, context=None):
    rt, approvals, audit = d.build_runtime()
    c = context or ctx()
    if approved:
        approvals.approve('a', c, 'transfer', d.TransferArgs.model_validate(args))
        c = dataclasses.replace(c, approval_id='a')
    started = time.perf_counter()
    result = asyncio.run(rt.invoke(d.ToolCall('supp_123456', 'transfer', args), c))
    print(json.dumps({'args':args, 'result':dataclasses.asdict(result), 'elapsed':time.perf_counter()-started, 'audit':[dataclasses.asdict(x) for x in audit.records]}, ensure_ascii=False))
    return result, audit

def test_A01():
    assert d.ACCOUNTS == {('tenant_a','ACC-A-123456'):100000.0, ('tenant_a','ACC-A-654321'):5000.0, ('tenant_a','ACC-A-888888'):20000.0, ('tenant_b','ACC-B-111111'):50000.0}
    assert all(type(v) is float for v in d.ACCOUNTS.values())

def test_A02():
    cases = [{k:v for k,v in BASE.items() if k != missing} for missing in BASE]
    cases += [{**BASE, key:value} for key,value in [('approved',True), ('user_id','admin'), ('amount',-1.0), ('amount','100'), ('from_account','ACC-123456'), ('to_account','ACC-A-12345'), ('to_account',123)]]
    for args in cases:
        r,a = run(args)
        assert r.code == 'INVALID_ARGUMENT'
        assert d.ACCOUNTS == INITIAL

def test_A03():
    for amount,code,action in [(50000.,'APPROVAL_REQUIRED','confirm'),(50000.01,'EXCEED_LIMIT','deny'),(80000.,'EXCEED_LIMIT','deny'),(80000.01,'APPROVAL_REQUIRED','confirm'),(100000.,'APPROVAL_REQUIRED','confirm'),(100000.01,'INVALID_ARGUMENT','deny')]:
        r,a=run({**BASE,'amount':amount})
        assert (r.code,r.action)==(code,action)
        assert a.records[-1].phase=='decision'
        assert d.ACCOUNTS==INITIAL
    for amount in [80000.01,100000.]:
        r,a=run({**BASE,'amount':amount},True)
        assert r.code=='TIMEOUT_UNKNOWN'
        assert d.ACCOUNTS==INITIAL

def test_A04():
    for amount,code in [(30000.,'INSUFFICIENT_BALANCE'),(60000.,'EXCEED_LIMIT')]:
        args={**BASE,'from_account':'ACC-A-888888','amount':amount}
        r,a=run(args)
        assert (r.action,r.code,a.records[-1].phase)==('deny',code,'decision')
        rt, approvals, audit=d.build_runtime()
        c=ctx(approval_id='unused')
        approvals.approve('unused',c,'transfer',args)
        result=asyncio.run(rt.invoke(d.ToolCall('precheck','transfer',args),c))
        assert result.code==code
        assert not approvals._records['unused'].used
        assert d.ACCOUNTS==INITIAL

def test_A05():
    r,a=run({**BASE,'from_account':'ACC-A-888888','amount':20000.},True)
    assert r.ok
    assert d.ACCOUNTS[('tenant_a','ACC-A-888888')]==0.
    assert d.ACCOUNTS[('tenant_a','ACC-A-654321')]==25000.

def test_A06():
    r,a=run({**BASE,'to_account':'ACC-A-999999'},True)
    assert (r.code,r.content)==('ACCOUNT_NOT_FOUND','转入账户不存在')
    assert d.ACCOUNTS==INITIAL

def test_A07():
    for source in ['ACC-B-111111','ACC-A-999999']:
        r,a=run({**BASE,'from_account':source})
        assert r.code=='INSUFFICIENT_BALANCE'
        assert d.ACCOUNTS==INITIAL
    r,a=run({**BASE,'to_account':'ACC-B-111111'},True)
    assert r.code=='ACCOUNT_NOT_FOUND'
    assert d.ACCOUNTS==INITIAL

def test_A08():
    t=next(t for t in d.build_tools() if t.name=='transfer')
    assert t.parameters_model is d.TransferArgs and t.handler is d.transfer_handler and t.precheck is d.transfer_precheck
    p=t.policy
    assert (p.effect,p.permission,p.idempotent,p.max_retries)==(d.Effect.WRITE,'transfer:execute',False,0)
    assert p.requires_approval or p.risk is d.Risk.HIGH
    assert 0 < p.timeout_seconds < 3
    targets=[t.canonical_target(d.TransferArgs.model_validate(args)) for args in [BASE,{**BASE,'from_account':'ACC-A-888888'},{**BASE,'to_account':'ACC-A-888888'},{**BASE,'amount':101.}]]
    print('policy=',p,'canonical_targets=',targets)
    assert len(set(targets))==4
    assert d.TransferArgs.model_config['extra']=='forbid' and d.TransferArgs.model_config['strict']

def test_A09():
    r,a=run(BASE,True)
    assert r.content=={'txn_id':'123456','from':'ACC-A-****3456','to':'ACC-A-****4321','amount':100.,'status':'accepted'}
    rt,_,audit=d.build_runtime()
    order=asyncio.run(rt.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),ctx()))
    assert order.content['customer_email']=='***@***' and order.content['access_token']=='***'
    assert d._redact({'rows':[{'email':'foo@example.com','password':'not-a-credential','account':'ACC-B-111111'}]})=={'rows':[{'email':'***@***','password':'***','account':'ACC-B-****1111'}]}
    assert [(x.phase,x.code) for x in a.records]==[('decision','APPROVED'),('execution','OK')]
    assert all(x.tool_call_id=='supp_123456' and x.trace_id=='trace_demo' for x in a.records)

def test_A10():
    original=ast.parse((ROOT/'trusted'/'tool_governance_demo-无答案.py').read_text())
    current=ast.parse(Path(d.__file__).read_text())
    def method(tree):
        cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='PermissionEngine')
        return next(x for x in cls.body if isinstance(x,ast.AsyncFunctionDef) and x.name=='decide')
    assert ast.dump(method(original))==ast.dump(method(current))
    baseline_text=(ROOT/'trusted'/'tool_governance_demo-无答案.py').read_text()
    node=method(original)
    baseline_method=textwrap.dedent('\n'.join(baseline_text.splitlines()[node.lineno-1:node.end_lineno]))
    assert baseline_method == textwrap.dedent(inspect.getsource(d.PermissionEngine.decide)).rstrip()
    assert (ROOT/'trusted'/'test_tool_governance.py').read_bytes()==(ROOT/'source'/'test_tool_governance.py').read_bytes()
    print('PermissionEngine.decide AST identical; original tests byte-identical; calls use runtime.invoke')
    output=subprocess.run([sys.executable,d.__file__],capture_output=True,text=True,check=True).stdout
    print('ORIGINAL OFFLINE DEMO:\n'+output)
    # 原提交应提供展示，不能以本补测打印的 transfer 结果代替。
    assert '"tool_name": "transfer"' in output, '原离线展示没有 transfer；原测试也无打印；缺少转账确认、脱敏结果及关联审计展示'
