# 工具治理与权限状态机演示

一个单文件的教学示例，完整演示 Agent 工具调用在真正产生副作用之前需要经过的治理链路：

```
Pydantic 参数校验 → 权限状态机 → 业务预检 → 一次性审批
→ 超时与重试恢复 → 结果脱敏 → 审计追踪
```

脚本内置四个工具：`get_order`（读）、`create_refund`（写，需审批）、`run_shell`（模拟 Shell）和 `transfer`（转账，需审批），并附带一份模拟的订单与账户数据。所有调用都必须经过同一个入口 `ToolRuntime.invoke()`。

> 说明：这是教学模拟，不会发起真实转账，`run_shell` 也不会创建真实子进程。

---

## 1. 环境准备

需要 Python 3.12+。

```bash
cd tool-governance-homework

python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

pip install pydantic openai pytest
```

依赖说明：

| 包 | 用途 |
|---|---|
| `pydantic` | 参数模型与 Schema 校验（必装） |
| `pytest` | 运行验收测试（必装） |
| `openai` | 仅 `--agent` 模式需要，用 OpenAI 兼容协议调用 DeepSeek |

---

## 2. 离线运行（不需要 API Key）

直接执行脚本即可，全程无网络请求：

```bash
python tool_governance_demo.py
```

它会依次发起 6 次调用，覆盖治理框架的主要分支：

| 调用 | 工具 | 预期结果 | 演示点 |
|---|---|---|---|
| `call_01` | `get_order` | `OK` | 邮箱和 `access_token` 被脱敏 |
| `call_02` | `create_refund` | `APPROVAL_REQUIRED` | 高风险写操作暂停等待审批 |
| `call_03` | `create_refund` | `OK` | 审批与用户、租户、工具、参数绑定后放行 |
| `call_04` | `create_refund` | `INVALID_ARGUMENT` | 模型偷塞 `user_id` / `approved` 被 `extra="forbid"` 拒绝 |
| `call_05` | `run_shell` | `DENY_RULE` | 即使 `bypassPermissions` 也无法绕过 `rm -rf` 的 deny 规则 |
| `call_06` | `create_refund` | `PLAN_MODE_DENIED` | plan 模式禁止写操作，审批也不能覆盖 |

最后一行会输出副作用计数和审计记录条数，例如：

```json
{"side_effects": {"refund_executions": 1, "shell_executions": 0}, "audit_records": 8}
```

离线演示主要覆盖退款与 Shell 分支；`transfer` 工具通过测试或 `--agent` 模式验证。

---

## 3. 使用真实 Agent 运行（DeepSeek）

需要先配置 API Key：

```bash
export DEEPSEEK_API_KEY="sk-你的密钥"
```

可选环境变量：

| 变量 | 默认值 | 说明 |
|---|---|---|
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com` | OpenAI 兼容接口地址 |
| `DEEPSEEK_MODEL` | `deepseek-v4-flash` | 使用的模型 |

运行：

```bash
python tool_governance_demo.py --agent --input "请从账户ACC-A-123456向账户ACC-A-654321转账1000"
```

`--agent` 模式下的行为：

- 每轮把 `runtime.model_tools(context)` 投影出的工具 Schema 交给模型，模型只看到描述和参数 Schema，看不到 handler 和治理策略。
- 当前 Agent 的工具白名单是 `get_order` 和 `transfer`，权限为 `order:read` 与 `transfer:execute`。
- 所有模型发起的工具调用仍然经过 `ToolRuntime.invoke()`，与离线演示完全同一条链路。
- Agent Loop 最多 8 轮，超过则报错。

### 3.1 如何完成转账审批

转账需要人工确认。模型发起 `transfer` 调用后，脚本会在终端暂停并询问：

```text
[approval] transfer {"from_account": "ACC-A-123456", "to_account": "ACC-A-654321", "amount": 1000.0}
是否允许本次操作？[y/N]
```

输入 `y` 或 `yes` 才会执行；其他输入按拒绝处理，模型会收到 `USER_DENIED` 的工具结果。

审批机制的几个约束：

- **一次性**：同一个 `approval_id` 用过即失效。
- **参数绑定**：审批摘要由工具名和完整参数计算，模型换个金额或账户后必须重新确认。
- **有有效期**：默认 300 秒。
- **非交互环境自动拒绝**：stdin 不是终端（例如管道、CI）时不会挂起等待，直接按拒绝处理。
- **只在进程内有效**：审批库和账户余额都在内存里，重新运行脚本会重置。

### 3.2 你可能遇到的业务规则

脚本内置的模拟数据：

| 租户 | 账户 | 余额 |
|---|---|---|
| `tenant_a` | `ACC-A-123456` | 100000.0 |
| `tenant_a` | `ACC-A-654321` | 5000.0 |
| `tenant_a` | `ACC-A-888888` | 20000.0 |
| `tenant_b` | `ACC-B-111111` | 50000.0 |

转账时的确定性检查：

| 条件 | 结果 |
|---|---|
| `50000 < amount <= 80000` | `EXCEED_LIMIT`（教学专用拦截区间，不是真实限额） |
| 转出账户余额 < 金额 | `INSUFFICIENT_BALANCE` |
| 转入账户在当前租户下不存在 | `ACCOUNT_NOT_FOUND` |
| `amount > 80000` | 通过预检，但 handler 中模拟 3 秒延迟，触发 2 秒超时 → `TIMEOUT_UNKNOWN`，且不会扣款 |

工具返回结果中的账号会被脱敏成 `ACC-A-****3456` 的形式。

---

## 4. 运行测试

测试文件位于仓库根目录：

```bash
python -m pytest test_tool_governance.py -v -k "transfer"
```

如果后续把测试移动到了 `tests/` 目录，则改为：

```bash
python -m pytest tests/test_tool_governance.py -v -k "transfer"
```

测试通过 `ToolRuntime.invoke()` 驱动，不直接调用 handler；`ACCOUNTS` 是可变的模块级状态，测试应在每个用例前后做快照与还原。

---

## 5. 命令行参数

| 参数 | 说明 |
|---|---|
| `--agent` | 使用 DeepSeek 运行真实 Agent Loop（需要 `DEEPSEEK_API_KEY`） |
| `--input TEXT` | 传给 Agent 的用户输入，默认是查询订单 `ord_1001` |

不带 `--agent` 时 `--input` 会被忽略，运行的是离线演示。

---

## 6. 文件结构

```text
.
├── tool_governance_demo.py   # 治理框架 + 四个工具 + 两种运行模式
├── test_tool_governance.py   # 验收测试
├── README.md
└── .gitignore
```

---

## 7. 关于作业约束

本项目来自「为治理框架增加转账工具」的实战作业。以下约束仍然成立：

1. 不修改 `PermissionEngine.decide`，它的优先级顺序是固定框架。
2. 测试与演示不绕过 `ToolRuntime.invoke()`。
3. 不删除 `TransferArgs` 从 `StrictArgs` 继承的 `extra="forbid"`，它是防注入的最后屏障。
