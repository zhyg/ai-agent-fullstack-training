"""Teacher supplemental checks. Business calls only through student Runtime."""
import ast
import asyncio
import inspect
import time
from dataclasses import replace
from pathlib import Path

import pytest
import tool_governance_demo as d

ROOT = Path(__file__).resolve().parents[1]
F, T, SMALL = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888'
BASE = dict(from_account=F, to_account=T, amount=1200.0)


def context(**kwargs):
    return d.base_context(permissions=frozenset({'transfer:execute', 'order:read'}),
                          allowed_tools=frozenset({'transfer', 'get_order'}), **kwargs)


async def invoke(args, approved=False, **kwargs):
    runtime, approvals, audit = d.build_runtime()
    ctx = context(**kwargs)
    if approved:
        approvals.approve('supplement', ctx, 'transfer', args)
        ctx = replace(ctx, approval_id='supplement')
    start = time.perf_counter()
    result = await runtime.invoke(d.ToolCall('supplement_123456', 'transfer', args), ctx)
    print({'args': args, 'result': result, 'elapsed': time.perf_counter()-start,
           'audit': audit.records, 'balances': d.ACCOUNTS})
    return result, approvals, audit


@pytest.fixture(autouse=True)
def isolation():
    snapshot = dict(d.ACCOUNTS)
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(snapshot)


def test_A01_initial_accounts():
    assert d.ACCOUNTS == {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
                          ('tenant_a', SMALL): 20000.0, ('tenant_b', 'ACC-B-111111'): 50000.0}
    assert all(type(v) is float for v in d.ACCOUNTS.values())


def test_A02_strict_arguments():
    async def run():
        invalid = [{k: v for k, v in BASE.items() if k != field} for field in BASE]
        invalid += [{**BASE, 'approved': True}, {**BASE, 'user_id': 'admin'}]
        invalid += [{**BASE, 'amount': v} for v in [-1.0, '1200.0', 0.0, 100000.01]]
        invalid += [{**BASE, field: val} for field in ['from_account', 'to_account']
                    for val in ['ACC-a-123456', 'ACC-A-12345', 'ACC-A-1234567', 123456]]
        before = dict(d.ACCOUNTS)
        for args in invalid:
            result, _, audit = await invoke(args)
            assert result.code == 'INVALID_ARGUMENT'
            assert audit.records[-1].phase == 'decision'
            assert d.ACCOUNTS == before
    asyncio.run(run())


def test_A03_amount_boundaries():
    async def run():
        before = dict(d.ACCOUNTS)
        for amount, code in [(50000.0, 'APPROVAL_REQUIRED'), (50000.01, 'EXCEED_LIMIT'),
                             (80000.0, 'EXCEED_LIMIT'), (80000.01, 'APPROVAL_REQUIRED'),
                             (100000.0, 'APPROVAL_REQUIRED'), (100000.01, 'INVALID_ARGUMENT')]:
            r, _, a = await invoke({**BASE, 'amount': amount})
            assert r.code == code
            assert a.records[-1].phase == 'decision'
            assert r.action == ('confirm' if code == 'APPROVAL_REQUIRED' else 'deny')
        for amount in [80000.01, 100000.0]:
            start = time.perf_counter()
            r, _, a = await invoke({**BASE, 'amount': amount}, True)
            assert r.code == 'TIMEOUT_UNKNOWN'
            assert .8 < time.perf_counter() - start < 3
            assert a.records[-1].phase == 'execution'
        assert d.ACCOUNTS == before
    asyncio.run(run())


def test_A04_precheck_order_and_approval_not_consumed():
    async def run():
        before = dict(d.ACCOUNTS)
        for amount, code in [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')]:
            for approved in [False, True]:
                r, approvals, audit = await invoke({**BASE, 'from_account': SMALL, 'amount': amount}, approved)
                assert r.code == code and r.action == 'deny'
                assert audit.records[-1].phase == 'decision'
                if approved:
                    assert not approvals._records['supplement'].used
                assert d.ACCOUNTS == before
    asyncio.run(run())


def test_A05_exact_balance():
    async def run():
        r, _, _ = await invoke({**BASE, 'from_account': SMALL, 'amount': 20000.0}, True)
        assert r.ok and r.content['txn_id'] == '123456'
        assert d.ACCOUNTS[('tenant_a', SMALL)] == 0.0
        assert d.ACCOUNTS[('tenant_a', T)] == 25000.0
    asyncio.run(run())


def test_A06_missing_destination():
    async def run():
        before = dict(d.ACCOUNTS)
        r, _, _ = await invoke({**BASE, 'to_account': 'ACC-A-999999'}, True)
        assert r.code == 'ACCOUNT_NOT_FOUND' and r.content == '转入账户不存在'
        assert d.ACCOUNTS == before
    asyncio.run(run())


def test_A07_tenant_isolation():
    async def run():
        before = dict(d.ACCOUNTS)
        for field in ['from_account', 'to_account']:
            r, _, _ = await invoke({**BASE, field: 'ACC-B-111111'}, True)
            assert not r.ok and r.code == 'ACCOUNT_NOT_FOUND'
            assert d.ACCOUNTS == before
    asyncio.run(run())


def test_A08_registration():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert inspect.iscoroutinefunction(tool.precheck)
    p = tool.policy
    assert p.effect is d.Effect.WRITE and (p.requires_approval or p.risk is d.Risk.HIGH)
    assert p.permission == 'transfer:execute' and 0 < p.timeout_seconds < 3
    assert not p.idempotent and p.max_retries == 0
    variants = [BASE, {**BASE, 'from_account': SMALL}, {**BASE, 'to_account': SMALL}, {**BASE, 'amount': 1201.0}]
    assert len({tool.canonical_target(d.TransferArgs(**a)) for a in variants}) == 4
    print('policy:', p, 'schema:', d.TransferArgs.model_json_schema())


def test_A09_redaction_regression():
    async def run():
        r, _, _ = await invoke(BASE, True)
        assert r.content['from'] == 'ACC-A-****3456' and r.content['to'] == 'ACC-A-****4321'
        runtime, _, _ = d.build_runtime()
        order = await runtime.invoke(d.ToolCall('order_check', 'get_order', {'order_id': 'ord_1001'}), context())
        assert order.content['customer_email'] == '***@***' and order.content['access_token'] == '***'
        print('order:', order)
    asyncio.run(run())
    assert d._redact({'nested': [{'email': 'x@example.com', 'account': F, 'password': 'dummy'}]}) == {
        'nested': [{'email': '***@***', 'account': 'ACC-A-****3456', 'password': '***'}]}


def test_A10_fixed_engine_and_trusted_tests():
    original = (ROOT / 'trusted/tool_governance_demo-无答案.py').read_text()
    student = Path(d.__file__).read_text()
    def method(source):
        tree = ast.parse(source)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
        node = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
        return ast.get_source_segment(source, node)
    assert method(original) == method(student)
    assert (ROOT / 'trusted/test_tool_governance.py').read_bytes() == (ROOT / 'source/tool_governance_demo/tests/test_tool_governance.py').read_bytes()
    print('PermissionEngine.decide exact source equality; trusted/student tests byte-identical; imported:', d.__file__)
