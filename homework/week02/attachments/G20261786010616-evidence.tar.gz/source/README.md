完成工具治理 transfer 作业

- 新增 ACCOUNTS 模拟账户与 TransferArgs 参数模型
- 实现 transfer_precheck 业务预检（EXCEED_LIMIT / INSUFFICIENT_BALANCE）
- 实现 transfer_handler（超时模拟、余额变更、参数脱敏出口）
- 注册 transfer 工具：WRITE/HIGH/transfer:execute/一次性审批/非幂等
- _redact 追加账号脱敏 ACC-A-****3456
- run_offline_demo 增加 transfer 全链路演示与审计日志输出
- 5 个 transfer 链路测试全部通过"