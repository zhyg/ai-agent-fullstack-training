#!/usr/bin/env bash
# Evidence extraction directory must be /tmp/vita-evidence for static reference paths.
# Clones only student code; never substitutes a teacher implementation.
set -euxo pipefail
if [ ! -d /tmp/vita-week2/.git ]; then
  git clone https://gitee.com/vita__chaochao/week2 /tmp/vita-week2
fi
test "$(git -C /tmp/vita-week2 rev-parse HEAD)" = 02fa9b5536e272a687a9ae5ae189aebaa1ef2a27
if [ ! -x /tmp/vita-venv/bin/python ]; then
  python -m venv /tmp/vita-venv
fi
/tmp/vita-venv/bin/pip install -r /tmp/vita-evidence/requirements-evaluated.txt
export PYTHONPATH=/tmp/vita-week2/homework
/tmp/vita-venv/bin/python -c 'import tool_governance_demo as d; print(d.__file__)'
/tmp/vita-venv/bin/python -m pytest /tmp/vita-evidence/trusted/test_tool_governance.py -v -k transfer
/tmp/vita-venv/bin/python -m pytest /tmp/vita-evidence/test_supplement.py -v -s
/tmp/vita-venv/bin/python /tmp/vita-week2/homework/tool_governance_demo.py
/tmp/vita-venv/bin/python -m pytest /tmp/vita-week2/homework/test_tool_governance.py -v -s -k transfer
