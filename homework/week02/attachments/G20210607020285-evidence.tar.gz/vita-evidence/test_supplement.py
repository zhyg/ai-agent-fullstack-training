import asyncio
import ast
import dataclasses
import inspect
import json
import pathlib
import time

import pytest
import tool_governance_demo as d

F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}


@pytest.fixture(autouse=True)
def isolation():
    before = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(before)


def args(**kw):
    return dict(from_account=F, to_account=T, amount=100.0) | kw


def ctx(**kw):
    return d.base_context(permissions=frozenset({'transfer:execute', 'order:read', 'refund:create'}),
                          allowed_tools=frozenset({'transfer', 'get_order', 'create_refund'}), **kw)


async def invoke(rt, a, **kw):
    return await rt.invoke(d.ToolCall('supplement_000123', 'transfer', a), ctx(**kw))


def emit(label, result, audit, elapsed=None):
    print(json.dumps({'label': label, 'result': dataclasses.asdict(result),
                      'audit': [dataclasses.asdict(x) for x in audit.records],
                      'elapsed': elapsed}, ensure_ascii=False, default=str))


def test_static_contracts():
    assert pathlib.Path(d.__file__).resolve() == pathlib.Path('/tmp/vita-week2/homework/tool_governance_demo.py')
    assert d.ACCOUNTS == INITIAL and all(type(v) is float for v in d.ACCOUNTS.values())
    assert issubclass(d.TransferArgs, d.StrictArgs)
    assert d.TransferArgs.model_config['extra'] == 'forbid' and d.TransferArgs.model_config['strict']
    original = pathlib.Path('/tmp/vita-evidence/trusted/tool_governance_demo-无答案.py').read_text()
    student = pathlib.Path(d.__file__).read_text()
    def decide(src):
        tree = ast.parse(src)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
        fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
        return '\n'.join(src.splitlines()[fn.lineno-1:fn.end_lineno])
    assert decide(original) == decide(student)
    assert inspect.iscoroutinefunction(d.transfer_precheck)
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs and tool.handler is d.transfer_handler
    assert tool.precheck is d.transfer_precheck
    p = tool.policy
    assert p.effect is d.Effect.WRITE and (p.requires_approval or p.risk is d.Risk.HIGH)
    assert p.permission == 'transfer:execute' and 0 < p.timeout_seconds < 3
    assert p.max_retries == 0 and p.idempotent is False
    targets = [tool.canonical_target(d.TransferArgs(**a)) for a in
               [args(), args(from_account=S), args(to_account=S), args(amount=101.0)]]
    assert len(set(targets)) == 4
    print('IMPORT', d.__file__, 'FIXED_DECIDE_EXACT=True', 'POLICY', p, 'TARGETS', targets)


@pytest.mark.parametrize('a', [args(**{k: None}) for k in ('from_account', 'to_account', 'amount')] +
                         [{k:v for k,v in args().items() if k != missing} for missing in args()] +
                         [args(approved=True), args(user_id='admin'), args(amount=-1.0),
                          args(amount='100.0'), args(from_account='ACC-123456'),
                          args(to_account='ACC-A-12345X')])
def test_strict_invalid(a):
    async def run():
        rt, _, audit = d.build_runtime()
        r = await invoke(rt, a)
        assert r.code == 'INVALID_ARGUMENT' and r.action is d.DecisionAction.DENY
        assert d.ACCOUNTS == INITIAL and audit.records[-1].phase == 'decision'
    asyncio.run(run())


@pytest.mark.parametrize('amount,expected', [(50000.0, 'APPROVAL_REQUIRED'), (50000.01, 'EXCEED_LIMIT'),
    (80000.0, 'EXCEED_LIMIT'), (80000.01, 'APPROVAL_REQUIRED'), (100000.0, 'APPROVAL_REQUIRED'),
    (100000.01, 'INVALID_ARGUMENT')])
def test_boundaries(amount, expected):
    async def run():
        rt, _, audit = d.build_runtime()
        r = await invoke(rt, args(amount=amount))
        assert r.code == expected
        assert r.action == (d.DecisionAction.CONFIRM if expected == 'APPROVAL_REQUIRED' else d.DecisionAction.DENY)
        assert audit.records[-1].phase == 'decision' and len(audit.records) == 1
        assert d.ACCOUNTS == INITIAL
        emit('boundary '+str(amount), r, audit)
    asyncio.run(run())


@pytest.mark.parametrize('amount,code', [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')])
def test_precheck_before_approval(amount, code):
    async def run():
        for approved in (False, True):
            rt, approvals, audit = d.build_runtime()
            a = args(from_account=S, amount=amount)
            approvals.approve('p', ctx(), 'transfer', a)
            r = await invoke(rt, a, approval_id='p' if approved else None)
            assert r.action is d.DecisionAction.DENY and r.code == code
            assert audit.records[-1].phase == 'decision' and len(audit.records) == 1
            assert approvals._records['p'].used is False and d.ACCOUNTS == INITIAL
            emit('precheck approved='+str(approved), r, audit)
    asyncio.run(run())


@pytest.mark.parametrize('amount', [80000.01, 100000.0])
def test_approved_timeout(amount):
    async def run():
        rt, approvals, audit = d.build_runtime()
        a = args(amount=amount)
        approvals.approve('p', ctx(), 'transfer', a)
        start = time.perf_counter()
        r = await invoke(rt, a, approval_id='p')
        elapsed = time.perf_counter()-start
        assert r.code == 'TIMEOUT_UNKNOWN' and 2.3 < elapsed < 3.0
        assert [(x.phase, x.code) for x in audit.records] == [('decision','APPROVED'),('execution','TIMEOUT_UNKNOWN')]
        assert d.ACCOUNTS == INITIAL
        emit('timeout '+str(amount), r, audit, elapsed)
    asyncio.run(run())


@pytest.mark.parametrize('a,code', [(args(to_account='ACC-A-999999'), 'ACCOUNT_NOT_FOUND'),
    (args(to_account=B), 'ACCOUNT_NOT_FOUND'), (args(from_account=B), 'INSUFFICIENT_BALANCE')])
def test_missing_and_tenant(a, code):
    async def run():
        rt, approvals, audit = d.build_runtime()
        approvals.approve('p', ctx(), 'transfer', a)
        r = await invoke(rt, a, approval_id='p')
        assert r.code == code and d.ACCOUNTS == INITIAL
        if code == 'ACCOUNT_NOT_FOUND':
            assert r.content == '转入账户不存在'
        emit('missing/isolation', r, audit)
    asyncio.run(run())


def test_full_balance_and_same_account():
    async def run():
        rt, approvals, audit = d.build_runtime()
        a = args(from_account=S, amount=20000.0)
        approvals.approve('p', ctx(), 'transfer', a)
        r = await invoke(rt, a, approval_id='p')
        assert r.ok and d.ACCOUNTS[('tenant_a', S)] == 0.0 and d.ACCOUNTS[('tenant_a', T)] == 25000.0
        a = args(to_account=F)
        approvals.approve('q', ctx(), 'transfer', a)
        r = await invoke(rt, a, approval_id='q')
        assert r.ok and d.ACCOUNTS[('tenant_a', F)] == 100000.0
    asyncio.run(run())


def test_offline_transfer_display_and_redaction_regression():
    async def run():
        rt, approvals, audit = d.build_runtime()
        a = args(amount=1200.0)
        r = await invoke(rt, a)
        assert r.action is d.DecisionAction.CONFIRM
        emit('TEACHER DEMO: pending', r, audit)
        # Simulated human approval; not model-supplied approval.
        approvals.approve('p', ctx(), 'transfer', a)
        altered = await invoke(rt, args(to_account=S, amount=1200.0), approval_id='p')
        assert altered.action is d.DecisionAction.CONFIRM
        r = await invoke(rt, a, approval_id='p')
        assert r.content == {'txn_id':'000123','from':'ACC-A-****3456','to':'ACC-A-****4321','amount':1200.0,'status':'accepted'}
        assert d.ACCOUNTS[('tenant_a', F)] == 98800.0 and d.ACCOUNTS[('tenant_a', T)] == 6200.0
        assert [(x.phase,x.code) for x in audit.records] == [('decision','APPROVAL_REQUIRED'),('decision','APPROVAL_REQUIRED'),('decision','APPROVED'),('execution','OK')]
        assert all(x.trace_id == 'trace_demo' for x in audit.records)
        emit('TEACHER DEMO: executed', r, audit)
        assert (await invoke(rt, a, approval_id='p')).action is d.DecisionAction.CONFIRM
        order = await rt.invoke(d.ToolCall('regression_order','get_order',{'order_id':'ord_1001'}),ctx())
        assert order.ok and order.content['customer_email'] == '***@***' and order.content['access_token'] == '***'
        assert d._redact({'nested':[{'email':'a@b.com','account':F,'password':'x'}]}) == {'nested':[{'email':'***@***','account':'ACC-A-****3456','password':'***'}]}
        refund = {'order_id':'ord_1001','amount':10.0,'reason':'regression check'}
        approvals.approve('r',ctx(),'create_refund',refund)
        rr = await rt.invoke(d.ToolCall('refund','create_refund',refund),ctx(approval_id='r'))
        assert rr.ok and d.SIDE_EFFECTS['refund_executions'] == 1
    asyncio.run(run())
