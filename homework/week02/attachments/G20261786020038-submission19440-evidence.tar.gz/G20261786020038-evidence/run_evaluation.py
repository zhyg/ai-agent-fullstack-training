"""Run isolated evaluations; save command, exit code, provenance, and raw output."""
import ast
import copy
import difflib
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PY = sys.executable
COMMANDS = []


def run(label, command, source):
    env = os.environ.copy()
    env['PYTHONPATH'] = str(source)
    env['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
    p = subprocess.run(command, cwd=source, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    text = f'CWD={source}\nPYTHONPATH={source}\nCOMMAND={command!r}\nEXIT_CODE={p.returncode}\n\n{p.stdout}'
    (ROOT / 'logs' / f'{label}.log').write_text(text)
    COMMANDS.append(dict(label=label, command=command, cwd=str(source), exit_code=p.returncode))
    print(label, 'exit=', p.returncode, '\n', p.stdout[-1000:])


def method(path):
    text = path.read_text()
    tree = ast.parse(text)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
    node = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
    lines = text.splitlines(keepends=True)
    return node, ''.join(lines[node.lineno - 1:node.end_lineno])


def strip_reason(node):
    node = copy.deepcopy(node)
    for n in ast.walk(node):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'PermissionDecision':
            if len(n.args) >= 3 and isinstance(n.args[2], (ast.Constant, ast.JoinedStr)):
                # Only reason text is normalized. Code, action, source, conditions and calls are untouched.
                if isinstance(n.args[2], ast.Constant):
                    n.args[2].value = '<reason text>'
                else:
                    for part in n.args[2].values:
                        if isinstance(part, ast.Constant):
                            part.value = '<reason text>'
    return ast.dump(node, include_attributes=False)


def main():
    import pydantic, pytest
    print('ENV', platform.platform(), sys.version, 'pydantic', pydantic.__version__, 'pytest', pytest.__version__)
    (ROOT / 'logs' / 'environment.json').write_text(json.dumps(dict(
        python=sys.version, executable=PY, platform=platform.platform(), pydantic=pydantic.__version__,
        pytest=pytest.__version__, course_commit='4a9c26d93b63e8171db33fbb5be6b7403246b2d9',
        current_commit='f6827515d002c3d1d07e2d16acc907af136ac477',
        specified_commit='773dfbb208193a790800f61707d8914dbd798912'), indent=2))
    for label, source in [('current', ROOT / 'source-current'), ('specified', ROOT / 'source-specified')]:
        run(label + '-provenance', [PY, '-c',
            'import inspect,tool_governance_demo as d; print("ENTRY",d.__file__); '
            'print("HANDLER",inspect.getsourcefile(d.transfer_handler)); '
            'print("ENGINE",inspect.getsourcefile(d.PermissionEngine)); '
            'print("RUNTIME",inspect.getsourcefile(d.ToolRuntime)); print("STRICT",d.TransferArgs.model_config)'], source)
        run(label + '-trusted-five', [PY, '-m', 'pytest', str(ROOT / 'trusted/test_tool_governance.py'), '-v', '-k', 'transfer'], source)
        run(label + '-supplemental', [PY, '-m', 'pytest', str(ROOT / 'supplemental/test_independent.py'), '-v', '-s'], source)
        run(label + '-submitted-demo', [PY, 'tool_governance_demo.py'], source)
    run('current-submitted-suite', [PY, '-m', 'pytest', '-v', '-s'], ROOT / 'source-current')
    ref = ROOT / 'reference/exercise.py'
    cur = ROOT / 'source-current/tool_governance/policy.py'
    old = ROOT / 'source-specified/tool_governance_demo.py'
    rn, rt = method(ref)
    cn, ct = method(cur)
    on, ot = method(old)
    diff = ''.join(difflib.unified_diff(rt.splitlines(True), ct.splitlines(True), fromfile='course-decide', tofile='current-decide'))
    (ROOT / 'logs/permission-engine.diff').write_text(diff)
    comparison = dict(course_vs_current_text_equal=rt == ct,
                      course_vs_current_AST_equal=ast.dump(rn, include_attributes=False) == ast.dump(cn, include_attributes=False),
                      course_vs_current_equal_after_reason_text_normalization=strip_reason(rn) == strip_reason(cn),
                      specified_vs_current_text_equal=ot == ct,
                      specified_vs_current_AST_equal=ast.dump(on, include_attributes=False) == ast.dump(cn, include_attributes=False))
    print('ENGINE', comparison)
    for name in ['trusted/test_tool_governance.py', 'source-current/test_tool_governance.py']:
        tree = ast.parse((ROOT / name).read_text())
        comparison[name + '_assert_count'] = sum(isinstance(n, ast.Assert) for n in ast.walk(tree))
    comparison['student_vs_trusted_test_AST_equal'] = ast.dump(ast.parse((ROOT/'trusted/test_tool_governance.py').read_text()), include_attributes=False) == ast.dump(ast.parse((ROOT/'source-current/test_tool_governance.py').read_text()), include_attributes=False)
    (ROOT / 'logs/static-comparison.json').write_text(json.dumps(comparison, indent=2))
    (ROOT / 'logs/commands.json').write_text(json.dumps(COMMANDS, indent=2))
    hashes = []
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and '__pycache__' not in str(p) and '.pytest_cache' not in str(p) and p.name != 'SHA256SUMS':
            hashes.append(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + str(p.relative_to(ROOT)))
    (ROOT / 'SHA256SUMS').write_text('\n'.join(hashes) + '\n')


if __name__ == '__main__':
    main()
