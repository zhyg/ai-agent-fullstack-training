# Sunny 第二周评测证据

主评：G20261786020038，记录19440，当前 f6827515d002c3d1d07e2d16acc907af136ac477。
结果：93/100，优秀，验收未通过（固定方法文案修改）；可信五测5通过，补测33通过1失败。
指定原版773dfbb208193a790800f61707d8914dbd798912独立运行，结果相同，仅作对照。

## 复现

用Python 3.11+创建隔离环境，安装Pydantic与pytest。原评测精确版本见logs/dependencies.txt。
在本包根目录执行：

```bash copy Copy Evaluation Command
python run_evaluation.py
```

脚本不使用API或密钥，未改变业务或可信测试断言。每个版本单独进程及PYTHONPATH；测试调用均经Runtime。
运行器保存各子命令退出码后继续运行，所以运行器退出0不代表补测全绿。完整结果见logs/commands.json。
原始环境、实际导入路径、命令和退出码见logs/environment.json及各日志头。

仅复现当前版指定消息问题（将PY设置为隔离环境解释器的绝对路径）：

```bash copy Copy Message Regression
E="$PWD"
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH="$E/source-current" "$PY" -m pytest "$E/supplemental/test_independent.py" -v -s -k A06_exact_required_message
```

预期本提交返回ACCOUNT_NOT_FOUND但英文消息，测试退出1；余额保护另测通过。

## 文件

- source-current：当前提交原样git archive快照；source-specified：指定原版原样快照。
- trusted：课程原始五测，逐字节保留；reference：固定方法源码、课程题目/标准/反馈要求及原始conftest。
- supplemental：教师独立补测；教师打印仅作观察，不能替代学生缺少的转账演示。
- logs：两版测试、演示、实际导入证明、固定方法diff/AST对比、环境、依赖和命令记录。
- G20261786020038-feedback.md、G20261786020038-evaluation.md：学员简明反馈及内部评分依据。
- SHA256SUMS：本包全部文件校验值（不含该校验清单本身）。

固定方法文本与AST不等于课程附件；只归一化返回reason文案后AST相同。属于运行时文案改动而非空白/注释格式差异，未发现权限控制流程变化。
没有将拆包或目录变化视作缺陷，不要求模型、真实支付或额外基础设施。包中不含.git、密钥、虚拟环境、依赖目录和缓存。
