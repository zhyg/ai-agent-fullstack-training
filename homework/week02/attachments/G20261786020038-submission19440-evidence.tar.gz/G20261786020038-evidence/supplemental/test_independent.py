"""Teacher checks; student code and trusted five-test assertions are unchanged."""
import asyncio
import inspect
import json
import time
from dataclasses import asdict

import pytest
import tool_governance_demo as d

F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}


def ctx(**kw):
    return d.base_context(**({'permissions': frozenset({'transfer:execute', 'order:read', 'refund:create'}),
                             'allowed_tools': frozenset({'transfer', 'get_order', 'create_refund'})} | kw))


def args(**kw):
    return dict(from_account=F, to_account=T, amount=1200.0) | kw


@pytest.fixture(autouse=True)
def isolate():
    snapshot = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(snapshot)


async def invoke(r, a, c=None, call='teacher_000003'):
    return await r.invoke(d.ToolCall(call, 'transfer', a), c or ctx())


def emit(label, result, audit, **more):
    print(json.dumps(dict(case=label, result=asdict(result), audit=[asdict(x) for x in audit.records],
                          balances={str(k): v for k, v in d.ACCOUNTS.items()}, **more),
                     ensure_ascii=False, default=str))


def test_A01_initial_accounts():
    assert d.ACCOUNTS == INITIAL
    assert all(type(v) is float for v in d.ACCOUNTS.values())


@pytest.mark.parametrize('bad', [
    {'from_account': None}, {'to_account': None}, {'amount': None},
    {'approved': True}, {'user_id': 'u_admin'}, {'amount': -1.0}, {'amount': '100.0'},
    {'from_account': 'ACC-A-12345'}, {'to_account': 'ACC-a-123456'},
    {'from_account': 123456}, {'to_account': 123456},
])
def test_A02_strict_runtime(bad):
    a = args(**bad)
    a = {k: v for k, v in a.items() if v is not None}
    r, _, audit = d.build_runtime()
    out = asyncio.run(invoke(r, a))
    emit('A02', out, audit, input=a)
    assert out.code == 'INVALID_ARGUMENT'
    assert d.ACCOUNTS == INITIAL
    assert len(audit.records) == 1 and audit.records[-1].phase == 'decision'


@pytest.mark.parametrize('amount,code,action', [
    (50000.0, 'APPROVAL_REQUIRED', 'confirm'), (50000.01, 'EXCEED_LIMIT', 'deny'),
    (80000.0, 'EXCEED_LIMIT', 'deny'), (80000.01, 'APPROVAL_REQUIRED', 'confirm'),
    (100000.0, 'APPROVAL_REQUIRED', 'confirm'), (100000.01, 'INVALID_ARGUMENT', 'deny'),
])
def test_A03_unapproved_boundary(amount, code, action):
    r, _, audit = d.build_runtime()
    out = asyncio.run(invoke(r, args(amount=amount)))
    emit('A03-unapproved', out, audit, amount=amount)
    assert (out.code, out.action.value) == (code, action)
    assert audit.records[-1].phase == 'decision'
    assert d.ACCOUNTS == INITIAL


@pytest.mark.parametrize('amount', [80000.01, 100000.0])
def test_A03_approved_timeout(amount):
    r, ap, audit = d.build_runtime()
    a = args(amount=amount)
    ap.approve('a', ctx(), 'transfer', a)
    t = time.perf_counter()
    out = asyncio.run(invoke(r, a, ctx(approval_id='a')))
    elapsed = time.perf_counter() - t
    emit('A03-approved', out, audit, amount=amount, elapsed=elapsed)
    assert out.code == 'TIMEOUT_UNKNOWN' and elapsed < 3
    assert d.ACCOUNTS == INITIAL
    assert [(x.phase, x.code) for x in audit.records] == [('decision', 'APPROVED'), ('execution', 'TIMEOUT_UNKNOWN')]


@pytest.mark.parametrize('amount,code', [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')])
@pytest.mark.parametrize('approved', [False, True])
def test_A04_precheck_order_readonly_and_approval(amount, code, approved):
    r, ap, audit = d.build_runtime()
    a = args(from_account=S, amount=amount)
    ap.approve('a', ctx(), 'transfer', a)
    out = asyncio.run(invoke(r, a, ctx(approval_id='a' if approved else None)))
    emit('A04', out, audit, amount=amount, approved=approved, approval_used=ap._records['a'].used)
    assert (out.code, out.action.value) == (code, 'deny')
    assert d.ACCOUNTS == INITIAL
    assert not ap._records['a'].used
    assert len(audit.records) == 1 and audit.records[-1].phase == 'decision'


def test_A05_full_balance():
    r, ap, audit = d.build_runtime()
    a = args(from_account=S, amount=20000.0)
    ap.approve('a', ctx(), 'transfer', a)
    out = asyncio.run(invoke(r, a, ctx(approval_id='a')))
    emit('A05', out, audit)
    assert out.ok and out.content['amount'] == 20000.0
    assert d.ACCOUNTS == INITIAL | {('tenant_a', S): 0.0, ('tenant_a', T): 25000.0}


@pytest.mark.parametrize('dest', ['ACC-A-999999', B])
def test_A06_A07_missing_target_safety(dest):
    r, ap, audit = d.build_runtime()
    a = args(to_account=dest, amount=100.0)
    ap.approve('a', ctx(), 'transfer', a)
    out = asyncio.run(invoke(r, a, ctx(approval_id='a')))
    emit('A06-A07-safety', out, audit, target=dest)
    assert not out.ok and out.code == 'ACCOUNT_NOT_FOUND'
    assert d.ACCOUNTS == INITIAL
    assert audit.records[-1].phase == 'execution'


def test_A06_exact_required_message():
    r, ap, audit = d.build_runtime()
    a = args(to_account='ACC-A-999999', amount=100.0)
    ap.approve('a', ctx(), 'transfer', a)
    out = asyncio.run(invoke(r, a, ctx(approval_id='a')))
    emit('A06-message', out, audit)
    assert out.content == '转入账户不存在'


@pytest.mark.parametrize('source,tenant', [(B, 'tenant_a'), (F, 'tenant_b'), ('ACC-A-999999', 'tenant_a')])
def test_A07_source_tenant_isolation(source, tenant):
    r, _, audit = d.build_runtime()
    out = asyncio.run(invoke(r, args(from_account=source), ctx(tenant_id=tenant)))
    emit('A07-source', out, audit, source=source, tenant=tenant)
    assert out.code == 'INSUFFICIENT_BALANCE' and out.action.value == 'deny'
    assert d.ACCOUNTS == INITIAL


def test_A08_registration_schema_and_targets():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs and issubclass(d.TransferArgs, d.StrictArgs)
    assert d.TransferArgs.model_config['strict'] is True
    assert d.TransferArgs.model_config['extra'] == 'forbid'
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert inspect.iscoroutinefunction(tool.precheck)
    p = tool.policy
    assert p.effect is d.Effect.WRITE and (p.requires_approval or p.risk is d.Risk.HIGH)
    assert p.permission == 'transfer:execute' and 0 < p.timeout_seconds < 3
    assert p.idempotent is False and p.max_retries == 0
    targets = [tool.canonical_target(d.TransferArgs(**a)) for a in
               [args(), args(from_account=S), args(to_account=S), args(amount=1200.01)]]
    assert len(set(targets)) == 4
    print('A08', asdict(p), targets, d.TransferArgs.model_json_schema())


def test_A09_A10_teacher_observation_not_student_demo():
    async def scenario():
        r, ap, audit = d.build_runtime()
        a = args()
        pending = await invoke(r, a, call='teacher_000001')
        emit('teacher-confirm', pending, audit)
        ap.approve('a', ctx(), 'transfer', a)
        executed = await invoke(r, a, ctx(approval_id='a'), call='teacher_000003')
        emit('teacher-executed', executed, audit)
        assert pending.action is d.DecisionAction.CONFIRM
        assert executed.content == {'txn_id': '000003', 'from': 'ACC-A-****3456', 'to': 'ACC-A-****4321',
                                    'amount': 1200.0, 'status': 'accepted'}
        assert [(x.phase, x.code) for x in audit.records] == [('decision', 'APPROVAL_REQUIRED'),
                                                             ('decision', 'APPROVED'), ('execution', 'OK')]
        assert [x.tool_call_id for x in audit.records] == ['teacher_000001', 'teacher_000003', 'teacher_000003']
        assert all(x.trace_id == 'trace_demo' for x in audit.records)
        assert all('ACC-' not in json.dumps(asdict(x)) for x in audit.records)
    asyncio.run(scenario())


def test_A09_existing_order_and_nested_redaction():
    r, _, audit = d.build_runtime()
    order = asyncio.run(r.invoke(d.ToolCall('order', 'get_order', {'order_id': 'ord_1001'}), ctx()))
    print('A09-order', asdict(order))
    assert order.ok and '***@***' in json.dumps(order.content)
    # Direct pure-function inspection is not a business/handler invocation.
    value = {'nested': [{'from': F}, (T, 'alice@example.com')], 'access_token': 'placeholder',
             'credentials': {'password': 'placeholder', 'authorization': 'placeholder'}}
    assert d._redact(value) == {'nested': [{'from': 'ACC-A-****3456'}, ['ACC-A-****4321', '***@***']],
                                'access_token': '***', 'credentials': {'password': '***', 'authorization': '***'}}
