"""Chapter 2 transfer tests: original acceptance cases and step-specific coverage.

Coverage by implementation step:
    Step 1: Shared account fixtures and balance assertions throughout the suite.
    Step 2: Argument validation and discovery schema.
    Step 3: Business prechecks, including the same-account extension.
    Step 4: Balance updates, destination validation, and timeout behavior.
    Step 5: Registration, permissions, approval binding, and audit integration.
    Step 6: Account masking and nested-output redaction regressions.

All tool executions pass through ToolRuntime.invoke; tests observe
PermissionEngine.decide without changing its priority order. Registration tests
also inspect metadata directly. Some acceptance cases cover multiple steps.
"""

from __future__ import annotations

import asyncio
import functools
import time
from collections.abc import Awaitable, Callable, Iterator, Mapping
from typing import Any

import pytest

import tool_governance_demo as demo

TRANSFER = "transfer"
APPROVAL_ID = "approval_transfer"
FROM_ACCOUNT = "ACC-A-123456"  # tenant_a, balance 100000.0
TO_ACCOUNT = "ACC-A-654321"  # tenant_a, balance 5000.0
SMALL_ACCOUNT = "ACC-A-888888"  # tenant_a, balance 20000.0
SLEEP_SECONDS = 3.0  # intentional slow call in transfer_handler


def async_test(test: Callable[..., Awaitable[None]]) -> Callable[..., None]:
    """Run async tests without depending on pytest-asyncio."""

    @functools.wraps(test)
    def run(*args: Any, **kwargs: Any) -> None:
        asyncio.run(test(*args, **kwargs))

    return run


def transfer_context(**overrides: Any) -> demo.ExecutionContext:
    """Context with transfer:execute permission and transfer whitelisted."""

    defaults: dict[str, Any] = {
        "permissions": frozenset({"order:read", "refund:create", "shell:run", "transfer:execute"}),
        "allowed_tools": frozenset({"get_order", "create_refund", "run_shell", "transfer"}),
    }
    return demo.base_context(**{**defaults, **overrides})


def accounts() -> dict[tuple[str, str], float]:
    store = getattr(demo, "ACCOUNTS", None)
    assert isinstance(store, dict), "Task 1 incomplete: tool_governance_demo.ACCOUNTS does not exist"
    return store


def balance(account: str, tenant_id: str = "tenant_a") -> float:
    store = accounts()
    assert (tenant_id, account) in store, f"Task 1 incomplete: ACCOUNTS is missing {(tenant_id, account)}"
    return store[(tenant_id, account)]


def approve(approvals: demo.ApprovalStore, arguments: Mapping[str, Any]) -> None:
    """Approve these exact arguments once; the digest must match at invocation."""

    approvals.approve(APPROVAL_ID, transfer_context(), TRANSFER, dict(arguments))


async def transfer(
    runtime: demo.ToolRuntime,
    tool_call_id: str,
    arguments: Mapping[str, Any],
    **context_overrides: Any,
) -> demo.ToolResult:
    return await runtime.invoke(
        demo.ToolCall(tool_call_id, TRANSFER, arguments),
        transfer_context(**context_overrides),
    )


@pytest.fixture(autouse=True)
def isolated_accounts() -> Iterator[None]:
    """Step 1 support: restore the mutable ACCOUNTS state after each test."""

    store = getattr(demo, "ACCOUNTS", None)
    snapshot = dict(store) if isinstance(store, dict) else None
    demo.reset_side_effects()
    yield
    if snapshot is not None:
        store.clear()
        store.update(snapshot)


@async_test
async def test_transfer_rejects_injected_arguments_and_invalid_amount() -> None:
    """Step 2: validate extra fields, account formats, and amount constraints."""

    runtime, _approvals, _audit = demo.build_runtime()
    valid = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 100.0}
    before = dict(accounts())

    def assert_invalid(result: demo.ToolResult) -> None:
        assert result.ok is False
        assert result.action is demo.DecisionAction.DENY
        assert result.code == "INVALID_ARGUMENT"
        assert accounts() == before

    injected = await transfer(runtime, "call_tr_inject", {**valid, "approved": True, "user_id": "u_admin"})
    assert_invalid(injected)

    malformed = await transfer(runtime, "call_tr_format", {**valid, "from_account": "ACC-123456"})
    assert_invalid(malformed)

    malformed_destination = await transfer(
        runtime, "call_tr_destination_format", {**valid, "to_account": "ACC-654321"}
    )
    assert_invalid(malformed_destination)

    zero = await transfer(runtime, "call_tr_zero", {**valid, "amount": 0.0})
    assert_invalid(zero)

    over_schema = await transfer(runtime, "call_tr_schema", {**valid, "amount": 100_000.1})
    assert_invalid(over_schema)

    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_precheck_blocks_over_limit_and_insufficient_balance() -> None:
    """Step 3: reject the teaching amount range and insufficient balance."""

    runtime, approvals, _audit = demo.build_runtime()
    before = dict(accounts())

    over_limit = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 60_000.0}
    approve(approvals, over_limit)
    rejected = await transfer(runtime, "call_tr_limit", over_limit, approval_id=APPROVAL_ID)
    assert rejected.ok is False
    assert rejected.action is demo.DecisionAction.DENY
    assert rejected.code == "EXCEED_LIMIT"
    assert accounts() == before

    short = {"from_account": SMALL_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 30_000.0}
    approve(approvals, short)
    rejected = await transfer(runtime, "call_tr_balance", short, approval_id=APPROVAL_ID)
    assert rejected.ok is False
    assert rejected.action is demo.DecisionAction.DENY
    assert rejected.code == "INSUFFICIENT_BALANCE"
    assert accounts() == before

    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(SMALL_ACCOUNT) == 20_000.0
    assert balance(TO_ACCOUNT) == 5_000.0


@async_test
async def test_transfer_is_denied_without_permission_or_whitelist_and_in_plan_mode() -> None:
    """Step 5: approval cannot bypass RBAC, the whitelist, or plan mode."""

    runtime, approvals, _audit = demo.build_runtime()
    before = dict(accounts())
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_000.0}
    approve(approvals, arguments)
    approved: dict[str, Any] = {"approval_id": APPROVAL_ID}

    no_permission = await transfer(
        runtime,
        "call_tr_rbac",
        arguments,
        permissions=frozenset({"order:read", "refund:create", "shell:run"}),
        **approved,
    )
    assert no_permission.action is demo.DecisionAction.DENY
    assert no_permission.ok is False
    assert no_permission.code == "PERMISSION_DENIED"
    assert accounts() == before

    not_whitelisted = await transfer(
        runtime,
        "call_tr_whitelist",
        arguments,
        allowed_tools=frozenset({"get_order", "create_refund", "run_shell"}),
        **approved,
    )
    assert not_whitelisted.code == "TOOL_NOT_ALLOWED"
    assert not_whitelisted.ok is False
    assert not_whitelisted.action is demo.DecisionAction.DENY
    assert accounts() == before

    plan_mode = await transfer(
        runtime,
        "call_tr_plan",
        arguments,
        mode=demo.PermissionMode.PLAN,
        **approved,
    )
    assert plan_mode.code == "PLAN_MODE_DENIED"
    assert plan_mode.ok is False
    assert plan_mode.action is demo.DecisionAction.DENY
    assert accounts() == before

    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_requires_approval_bound_to_arguments_and_masks_accounts() -> None:
    """Steps 4-6: verify execution, approval binding, redaction, and auditing."""

    runtime, approvals, audit = demo.build_runtime()
    before = dict(accounts())
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_200.0}

    pending = await transfer(runtime, "call_tr_000001", arguments)
    assert pending.ok is False
    assert pending.action is demo.DecisionAction.CONFIRM
    assert pending.code == "APPROVAL_REQUIRED"
    assert accounts() == before
    assert balance(FROM_ACCOUNT) == 100_000.0

    approve(approvals, arguments)
    tampered = await transfer(
        runtime, "call_tr_000002", {**arguments, "amount": 9_000.0}, approval_id=APPROVAL_ID
    )
    assert tampered.action is demo.DecisionAction.CONFIRM
    assert tampered.ok is False
    assert tampered.code == "APPROVAL_REQUIRED"
    assert accounts() == before

    executed = await transfer(runtime, "call_tr_000003", arguments, approval_id=APPROVAL_ID)
    assert executed.ok is True
    assert executed.action is demo.DecisionAction.ALLOW
    assert executed.code == "OK"
    assert executed.content["txn_id"] == "000003"
    assert executed.content["amount"] == 1_200.0
    assert executed.content["status"] == "accepted"
    assert executed.content["from"] == "ACC-A-****3456"
    assert executed.content["to"] == "ACC-A-****4321"
    assert balance(FROM_ACCOUNT) == 98_800.0
    assert balance(TO_ACCOUNT) == 6_200.0

    assert [(record.phase, record.code) for record in audit.records] == [
        ("decision", "APPROVAL_REQUIRED"),
        ("decision", "APPROVAL_REQUIRED"),
        ("decision", "APPROVED"),
        ("execution", "OK"),
    ]

    after = dict(accounts())
    replay = await transfer(runtime, "call_tr_000004", arguments, approval_id=APPROVAL_ID)
    assert replay.action is demo.DecisionAction.CONFIRM
    assert replay.ok is False
    assert replay.code == "APPROVAL_REQUIRED"
    assert accounts() == after


@async_test
async def test_transfer_timeout_is_reported_as_unknown_and_leaves_balances_untouched() -> None:
    """Steps 4-5: a non-idempotent write timeout precedes debiting and is audited."""

    runtime, approvals, audit = demo.build_runtime()
    # Amounts above 80000 pass the teaching range and trigger sleep after checks and approval.
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 90_000.0}
    approve(approvals, arguments)

    started = time.perf_counter()
    result = await transfer(runtime, "call_tr_timeout", arguments, approval_id=APPROVAL_ID)
    elapsed = time.perf_counter() - started

    assert result.ok is False
    assert result.code == "TIMEOUT_UNKNOWN"
    assert elapsed < SLEEP_SECONDS
    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(TO_ACCOUNT) == 5_000.0
    assert audit.records[-1].phase == "execution"
    assert audit.records[-1].code == "TIMEOUT_UNKNOWN"


def handler_runtime() -> tuple[demo.ToolRuntime, demo.ApprovalStore]:
    """Steps 4-5 support: use permanent registration for handler verification."""
    runtime, approvals, _ = demo.build_runtime()
    return runtime, approvals


@pytest.mark.parametrize("amount", [100.0, 60_000.0, 90_000.0])
@async_test
async def test_same_account_precheck(amount: float) -> None:
    """Step 3 extension: reject self-transfers before approval, range, or timeout."""
    runtime, _ = handler_runtime()
    before = dict(accounts())
    result = await transfer(runtime, "call_same", {
        "from_account": FROM_ACCOUNT, "to_account": FROM_ACCOUNT, "amount": amount,
    })
    assert result.code == "SAME_ACCOUNT"
    assert result.action is demo.DecisionAction.DENY
    assert accounts() == before


@async_test
async def test_handler_success_before_redaction() -> None:
    """Step 4: verify balance updates and transaction fields independently of masking.

    The runtime still applies Step 6 redaction; this test does not assert its format.
    """
    runtime, approvals = handler_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_200.0}
    approve(approvals, arguments)
    before = dict(accounts())
    result = await transfer(runtime, "call_tr_000003", arguments, approval_id=APPROVAL_ID)
    assert result.ok and result.code == "OK"
    assert result.content["txn_id"] == "000003"
    assert result.content["amount"] == 1_200.0
    assert result.content["status"] == "accepted"
    assert "from" in result.content and "to" in result.content
    before[("tenant_a", FROM_ACCOUNT)] -= 1_200.0
    before[("tenant_a", TO_ACCOUNT)] += 1_200.0
    assert accounts() == before


@pytest.mark.parametrize("destination", ["ACC-A-999999", "ACC-B-111111"])
@async_test
async def test_handler_missing_destination(destination: str) -> None:
    """Step 4: reject absent or other-tenant destinations without balance changes."""
    runtime, approvals = handler_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": destination, "amount": 100.0}
    approve(approvals, arguments)
    before = dict(accounts())
    result = await transfer(runtime, "call_missing", arguments, approval_id=APPROVAL_ID)
    assert result.code == "ACCOUNT_NOT_FOUND"
    assert not result.ok
    assert accounts() == before


@pytest.mark.parametrize("destination", [TO_ACCOUNT, "ACC-A-999999"])
@async_test
async def test_handler_timeout_before_mutation(destination: str) -> None:
    """Step 4: timeout precedes destination validation and balance mutation."""
    runtime, approvals = handler_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": destination, "amount": 90_000.0}
    approve(approvals, arguments)
    before = dict(accounts())
    started = time.perf_counter()
    result = await transfer(runtime, "call_slow", arguments, approval_id=APPROVAL_ID)
    assert result.code == "TIMEOUT_UNKNOWN"
    assert not result.ok
    assert time.perf_counter() - started < SLEEP_SECONDS
    assert accounts() == before


def test_transfer_discovery_and_registration() -> None:
    """Step 5: verify visibility, schema, policy, wiring, and canonical targets."""
    runtime, _, _ = demo.build_runtime()
    visible = {tool['function']['name']: tool for tool in runtime.model_tools(transfer_context())}
    assert visible[TRANSFER]['function']['parameters'] == demo.TransferArgs.model_json_schema()
    assert TRANSFER not in {tool['function']['name'] for tool in runtime.model_tools(demo.base_context())}
    tool = next(tool for tool in demo.build_tools() if tool.name == TRANSFER)
    assert tool.handler is demo.transfer_handler
    assert tool.precheck is demo.transfer_precheck
    assert tool.policy.effect is demo.Effect.WRITE
    assert tool.policy.risk is demo.Risk.HIGH
    assert tool.policy.permission == 'transfer:execute'
    assert tool.policy.requires_approval
    assert not tool.policy.idempotent and tool.policy.max_retries == 0
    assert 0 < tool.policy.timeout_seconds < SLEEP_SECONDS
    args = {'from_account': FROM_ACCOUNT, 'to_account': TO_ACCOUNT, 'amount': 100.0}
    variations = [args, {**args, 'from_account': SMALL_ACCOUNT},
                  {**args, 'to_account': SMALL_ACCOUNT}, {**args, 'amount': 200.0}]
    assert len({tool.canonical_target(demo.TransferArgs(**item)) for item in variations}) == 4


@async_test
async def test_transfer_approval_lifecycle_without_redaction() -> None:
    """Step 5: verify argument binding, one-time approval, and audit ordering.

    Redaction still runs; these assertions focus on the approval lifecycle.
    """
    runtime, approvals, audit = demo.build_runtime()
    args = {'from_account': FROM_ACCOUNT, 'to_account': TO_ACCOUNT, 'amount': 1_200.0}
    before = dict(accounts())
    pending = await transfer(runtime, 'pending', args)
    assert pending.code == 'APPROVAL_REQUIRED'
    approve(approvals, args)
    tampered = await transfer(runtime, 'tampered', {**args, 'amount': 9_000.0}, approval_id=APPROVAL_ID)
    assert tampered.code == 'APPROVAL_REQUIRED'
    assert accounts() == before
    executed = await transfer(runtime, 'approved', args, approval_id=APPROVAL_ID)
    assert executed.ok
    after = dict(accounts())
    replay = await transfer(runtime, 'replay', args, approval_id=APPROVAL_ID)
    assert replay.action is demo.DecisionAction.CONFIRM
    assert accounts() == after
    assert [(r.phase, r.code) for r in audit.records] == [
        ('decision', 'APPROVAL_REQUIRED'), ('decision', 'APPROVAL_REQUIRED'),
        ('decision', 'APPROVED'), ('execution', 'OK'), ('decision', 'APPROVAL_REQUIRED'),
    ]


@async_test
async def test_runtime_redacts_nested_account_output() -> None:
    """Step 6: verify nested account masking and existing redaction behavior."""
    payload = {
        'nested': [{'account': FROM_ACCOUNT}, (TO_ACCOUNT,)],
        'message': f'From {FROM_ACCOUNT} to {TO_ACCOUNT}; contact alice@example.com.',
        'access_token': 'demo-token',
        'credentials': {'password': 'demo-password', 'authorization': 'demo-auth'},
        'amount': 100.0,
        'status': 'accepted',
        'txn_id': '000003',
        'already_masked': 'ACC-A-****3456',
        'unrelated': 'ACC-A-1234567',
    }

    async def output_handler(*args: Any) -> Mapping[str, Any]:
        return payload

    tool = demo.ToolDefinition(
        name='get_order', description='Redaction verification',
        parameters_model=demo.GetOrderArgs,
        policy=demo.ToolPolicy(demo.Effect.READ, demo.Risk.LOW, 'order:read', False, 1.0, 0, True),
        handler=output_handler,
        canonical_target=lambda args: args.order_id,
    )
    runtime = demo.ToolRuntime([tool], demo.PermissionEngine((), demo.ApprovalStore()), demo.AuditSink())
    before = dict(accounts())
    result = await runtime.invoke(
        demo.ToolCall('redaction', 'get_order', {'order_id': 'ord_1001'}), demo.base_context(),
    )
    assert result.ok
    assert result.content == {
        'nested': [{'account': 'ACC-A-****3456'}, ['ACC-A-****4321']],
        'message': 'From ACC-A-****3456 to ACC-A-****4321; contact ***@***.',
        'access_token': '***',
        'credentials': {'password': '***', 'authorization': '***'},
        'amount': 100.0,
        'status': 'accepted',
        'txn_id': '000003',
        'already_masked': 'ACC-A-****3456',
        'unrelated': 'ACC-A-1234567',
    }
    assert payload['nested'][0]['account'] == FROM_ACCOUNT
    assert accounts() == before
