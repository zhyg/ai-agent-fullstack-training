# Transfer Tool Exercise

Implement the missing transfer tool in `tool_governance_demo.py` so that it runs through the existing tool governance pipeline.

## 1. Add simulated account data

Create a module-level, mutable `ACCOUNTS` dictionary after `ORDERS`. Keys are `(tenant_id, account_id)` tuples and values are balances as floats. Initialize it with:

| Tenant | Account | Balance |
| --- | --- | ---: |
| `tenant_a` | `ACC-A-123456` | 100,000.0 |
| `tenant_a` | `ACC-A-654321` | 5,000.0 |
| `tenant_a` | `ACC-A-888888` | 20,000.0 |
| `tenant_b` | `ACC-B-111111` | 50,000.0 |

The tests snapshot and restore this mutable dictionary between cases.

## 2. Define the argument model

Create `TransferArgs` inheriting from `StrictArgs` with:

- `from_account: str` and `to_account: str`, each matching `^ACC-[A-Z]-[0-9]{6}$`.
- `amount: float`, greater than zero and no more than 100,000.

Keep the inherited `extra="forbid"` behavior to reject injected fields.

## 3. Implement the business precheck

Implement the asynchronous `transfer_precheck(args, context)`. It must only check conditions, without changing balances. Check in this order:

1. If `from_account == to_account`, raise `PolicyDenied("SAME_ACCOUNT", "Source and destination accounts must differ")`. This check precedes the amount-range and balance checks and does not require approval.
2. If `50000 < amount <= 80000`, raise `PolicyDenied` with code `EXCEED_LIMIT`. This is a teaching-only blocked range, not a real single-transfer limit. Amounts above 80,000 must pass this check so the timeout scenario can be exercised.
3. Look up the source account balance using `(context.tenant_id, from_account)`. If the balance is less than the amount, raise `PolicyDenied` with code `INSUFFICIENT_BALANCE`. Treat a missing source account as having zero available funds.

## 4. Implement the transfer handler

Implement the asynchronous `transfer_handler(tool_call_id, args, context)`:

1. If the amount is greater than 80,000, first `await asyncio.sleep(3.0)`. This must happen before debiting so the runtime timeout can interrupt execution first.
2. If `(context.tenant_id, to_account)` is not in `ACCOUNTS`, raise `PolicyDenied("ACCOUNT_NOT_FOUND", "Destination account does not exist")`.
3. Subtract the amount from the source balance and add it to the destination balance.
4. Return a dictionary containing `txn_id` (the last six characters of `tool_call_id`), `from`, `to`, `amount`, and `status="accepted"`.

## 5. Register the tool

Append a `ToolDefinition` to `build_tools()` with:

- Name `transfer` and an appropriate description.
- `parameters_model=TransferArgs`, `handler=transfer_handler`, and `precheck=transfer_precheck`.
- A `canonical_target` that distinguishes different argument combinations.
- A write policy requiring human approval, permission `transfer:execute`, non-idempotent behavior, and `max_retries=0`.
- A timeout shorter than the three-second delay used in the timeout demonstration.

## 6. Mask account numbers

Extend `_redact` to mask account numbers in strings. The TODO gives `ACC-A-123456` becoming `ACC-A-****3456` as its example: preserve the prefix and last four digits.

## Constraints and acceptance

- Do not modify the priority order or any line in `PermissionEngine.decide`.
- All test calls must go through `ToolRuntime.invoke()`; do not bypass it.
- Do not remove `extra="forbid"` from `TransferArgs` (it is inherited from `StrictArgs`).
- Run the transfer acceptance tests:

```bash
python -m pytest test_tool_governance.py -v -k transfer
```

The command above uses the test file's actual location in this directory; the source file's original comment refers to `tests/test_tool_governance.py`.
