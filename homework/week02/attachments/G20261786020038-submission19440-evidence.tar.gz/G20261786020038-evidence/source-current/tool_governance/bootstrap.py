"""Construct tool definitions, execution contexts, and the runtime."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import replace
from typing import Any

from .arguments import CreateRefundArgs, GetOrderArgs, RunShellArgs, TransferArgs
from .domain import Effect, ExecutionContext, PermissionMode, PermissionRule, Risk, ToolDefinition, ToolPolicy
from .policy import PermissionEngine
from .runtime import ToolRuntime
from .stores import ApprovalStore, AuditSink
from .tools.orders import create_refund_handler, get_order_handler, refund_precheck
from .tools.shell import simulated_shell_handler
from .tools.transfer import transfer_handler, transfer_precheck


def build_tools() -> list[ToolDefinition]:
    return [
        ToolDefinition(
            name="get_order",
            description="Look up order status and refundable amount for the current tenant",
            parameters_model=GetOrderArgs,
            policy=ToolPolicy(Effect.READ, Risk.MEDIUM, "order:read", False, 1.0, 2, True),
            handler=get_order_handler,
            canonical_target=lambda args: str(getattr(args, "order_id")),
        ),
        ToolDefinition(
            name="create_refund",
            description="Create a refund for a paid order belonging to the current tenant",
            parameters_model=CreateRefundArgs,
            policy=ToolPolicy(Effect.WRITE, Risk.HIGH, "refund:create", True, 2.0, 0, False),
            handler=create_refund_handler,
            precheck=refund_precheck,
            canonical_target=lambda args: f"{getattr(args, 'order_id')}:{getattr(args, 'amount')}",
        ),
        ToolDefinition(
            name="run_shell",
            description="Simulated shell for teaching; does not execute real system commands",
            parameters_model=RunShellArgs,
            policy=ToolPolicy(Effect.SHELL, Risk.MEDIUM, "shell:run", False, 1.0, 0, False),
            handler=simulated_shell_handler,
            canonical_target=lambda args: str(getattr(args, "command")),
        ),
        # ===== IMPLEMENTED(Task 5): Register the transfer tool =====
        ToolDefinition(
            name="transfer",
            description="Transfer funds between accounts belonging to the current tenant",
            parameters_model=TransferArgs,
            policy=ToolPolicy(Effect.WRITE, Risk.HIGH, "transfer:execute", True, 2.0, 0, False),
            handler=transfer_handler,
            precheck=transfer_precheck,
            canonical_target=lambda args: (
                f"{getattr(args, 'from_account')}:{getattr(args, 'to_account')}:{getattr(args, 'amount')}"
            ),
        ),
    ]


DEFAULT_RULES = (
    PermissionRule("deny", "run_shell", "rm -rf"),
    PermissionRule("deny", "run_shell", "git push --force"),
    PermissionRule("allow", "run_shell", "pytest"),
)


def base_context(**overrides: Any) -> ExecutionContext:
    context = ExecutionContext(
        trace_id="trace_demo",
        user_id="u_100",
        tenant_id="tenant_a",
        mode=PermissionMode.DEFAULT,
        permissions=frozenset({"order:read", "refund:create", "shell:run"}),
        allowed_tools=frozenset({"get_order", "create_refund", "run_shell"}),
    )
    return replace(context, **overrides)


def build_runtime(
    *,
    approvals: ApprovalStore | None = None,
    audit: AuditSink | None = None,
    rules: Sequence[PermissionRule] = DEFAULT_RULES,
) -> tuple[ToolRuntime, ApprovalStore, AuditSink]:
    approval_store = approvals or ApprovalStore()
    audit_sink = audit or AuditSink()
    engine = PermissionEngine(rules, approval_store)
    return ToolRuntime(build_tools(), engine, audit_sink), approval_store, audit_sink
