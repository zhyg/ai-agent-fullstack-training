"""Simulated shell tool; no real subprocesses are created."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..arguments import ArgsModel, RunShellArgs
from ..domain import ExecutionContext
from .state import SIDE_EFFECTS


async def simulated_shell_handler(
    _tool_call_id: str,
    raw_arguments: ArgsModel,
    _context: ExecutionContext,
) -> Mapping[str, Any]:
    arguments = raw_arguments
    assert isinstance(arguments, RunShellArgs)
    SIDE_EFFECTS["shell_executions"] += 1
    return {
        "simulated": True,
        "command": arguments.command,
        "stdout": "Teaching simulation: no real subprocess was created",
    }
