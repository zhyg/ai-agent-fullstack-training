"""Business tools and their in-memory teaching data."""
