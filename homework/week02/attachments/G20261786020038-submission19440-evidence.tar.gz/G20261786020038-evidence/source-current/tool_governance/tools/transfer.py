"""Transfer business checks and execution with simulated accounts."""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
from typing import Any

from ..arguments import ArgsModel, TransferArgs
from ..domain import ExecutionContext, PolicyDenied


# ===== IMPLEMENTED(Task 1): Add simulated account data =====
# Tests snapshot and restore this module-level mutable state.
ACCOUNTS: dict[tuple[str, str], float] = {
    ("tenant_a", "ACC-A-123456"): 100_000.0,
    ("tenant_a", "ACC-A-654321"): 5_000.0,
    ("tenant_a", "ACC-A-888888"): 20_000.0,
    ("tenant_b", "ACC-B-111111"): 50_000.0,
}


# ===== IMPLEMENTED(Task 3): Implement the business precheck =====
async def transfer_precheck(raw_arguments: ArgsModel, context: ExecutionContext) -> None:
    arguments = raw_arguments
    assert isinstance(arguments, TransferArgs)
    # Extension to the original exercise: reject transfers to the same account.
    # Check before the amount range and balance so these return SAME_ACCOUNT;
    # the permission engine runs this precheck before requesting approval.
    if arguments.from_account == arguments.to_account:
        raise PolicyDenied("SAME_ACCOUNT", "Source and destination accounts must differ")
    # This teaching-only range leaves amounts above 80,000 for the timeout scenario.
    if 50_000 < arguments.amount <= 80_000:
        raise PolicyDenied("EXCEED_LIMIT", "Transfer amount falls within the blocked teaching range")
    balance = ACCOUNTS.get((context.tenant_id, arguments.from_account), 0.0)
    if balance < arguments.amount:
        raise PolicyDenied("INSUFFICIENT_BALANCE", "Insufficient source account balance")


# ===== IMPLEMENTED(Task 4): Implement the transfer handler =====
async def transfer_handler(
    tool_call_id: str,
    raw_arguments: ArgsModel,
    context: ExecutionContext,
) -> Mapping[str, Any]:
    arguments = raw_arguments
    assert isinstance(arguments, TransferArgs)
    if arguments.amount > 80_000:
        await asyncio.sleep(3.0)
    source = (context.tenant_id, arguments.from_account)
    destination = (context.tenant_id, arguments.to_account)
    if destination not in ACCOUNTS:
        raise PolicyDenied("ACCOUNT_NOT_FOUND", "Destination account does not exist")
    ACCOUNTS[source] -= arguments.amount
    ACCOUNTS[destination] += arguments.amount
    return {
        "txn_id": tool_call_id[-6:],
        "from": arguments.from_account,
        "to": arguments.to_account,
        "amount": arguments.amount,
        "status": "accepted",
    }
