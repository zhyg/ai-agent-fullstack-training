"""Shared side-effect counters used by the offline demonstration."""

from __future__ import annotations




SIDE_EFFECTS = {"refund_executions": 0, "shell_executions": 0}


def reset_side_effects() -> None:
    SIDE_EFFECTS.update(refund_executions=0, shell_executions=0)
