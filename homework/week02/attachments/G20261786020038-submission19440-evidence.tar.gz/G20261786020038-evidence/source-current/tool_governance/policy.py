"""Permission decisions with the original fixed priority order."""

from __future__ import annotations

import re
from collections.abc import Sequence

from .arguments import ArgsModel
from .domain import (
    DecisionAction, Effect, ExecutionContext, PermissionDecision, PermissionMode,
    PermissionRule, PolicyDenied, Risk, ToolDefinition,
)
from .stores import ApprovalStore


DANGEROUS_SHELL_PATTERNS = (
    re.compile(r"\brm\s+-rf\b", re.I),
    re.compile(r"\bgit\s+push\s+--force\b", re.I),
    re.compile(r"\bgit\s+reset\s+--hard\b", re.I),
    re.compile(r"\bsudo\b", re.I),
    re.compile(r"\bmkfs\b", re.I),
    re.compile(r">\s*/dev/", re.I),
)


def _is_dangerous_shell(command: str) -> bool:
    return any(pattern.search(command) for pattern in DANGEROUS_SHELL_PATTERNS)


class PermissionEngine:
    """Three-state permission engine with fixed priority."""

    def __init__(self, rules: Sequence[PermissionRule], approvals: ApprovalStore) -> None:
        self._rules = tuple(rules)
        self._approvals = approvals

    def _rule_matches(self, rule: PermissionRule, tool: ToolDefinition, arguments: ArgsModel) -> bool:
        if rule.tool_name != tool.name:
            return False
        if rule.target_prefix is None:
            return True
        return tool.canonical_target(arguments).startswith(rule.target_prefix)

    async def decide(
        self,
        tool: ToolDefinition,
        arguments: ArgsModel,
        context: ExecutionContext,
    ) -> PermissionDecision:
        # 1. Deny first: allow or bypass cannot override a hard denial.
        if any(
            rule.effect == "deny" and self._rule_matches(rule, tool, arguments)
            for rule in self._rules
        ):
            return PermissionDecision(DecisionAction.DENY, "DENY_RULE", "Matched a deny rule", "rule")

        # 2. Plan mode enforces read-only execution.
        if context.mode is PermissionMode.PLAN and tool.policy.effect is not Effect.READ:
            return PermissionDecision(
                DecisionAction.DENY,
                "PLAN_MODE_DENIED",
                "Plan mode prohibits writes and shell operations",
                "mode",
            )

        # 3. Recheck the whitelist at execution even after discovery filtering.
        if tool.name not in context.allowed_tools:
            return PermissionDecision(
                DecisionAction.DENY,
                "TOOL_NOT_ALLOWED",
                "Tool is not in the execution whitelist for this round",
                "whitelist",
            )

        # 4. Trust only the ExecutionContext produced by authentication.
        if tool.policy.permission not in context.permissions:
            return PermissionDecision(
                DecisionAction.DENY,
                "PERMISSION_DENIED",
                f"Missing business permission {tool.policy.permission}",
                "rbac",
            )

        # 5. Check resource ownership, status, and limits before the handler.
        try:
            if tool.precheck:
                await tool.precheck(arguments, context)
        except PolicyDenied as error:
            return PermissionDecision(DecisionAction.DENY, error.code, str(error), "business")

        # 6. High-risk writes require one-time, argument-bound approval.
        if tool.policy.requires_approval or tool.policy.risk is Risk.HIGH:
            if self._approvals.consume(context.approval_id, context, tool.name, arguments):
                return PermissionDecision(
                    DecisionAction.ALLOW,
                    "APPROVED",
                    "Approval exactly matches the current user, tenant, tool, and arguments",
                    "approval",
                )
            if context.mode is PermissionMode.DONT_ASK:
                return PermissionDecision(
                    DecisionAction.DENY,
                    "APPROVAL_REQUIRED",
                    "Non-interactive mode cannot confirm high-risk operations",
                    "approval",
                )
            return PermissionDecision(
                DecisionAction.CONFIRM,
                "APPROVAL_REQUIRED",
                "Confirmation is required for this specific action",
                "approval",
            )

        # 7. Bypass skips ordinary confirmation, not the preceding hard boundaries.
        if context.mode is PermissionMode.BYPASS_PERMISSIONS:
            return PermissionDecision(
                DecisionAction.ALLOW,
                "BYPASS_ALLOWED",
                "Skipping ordinary confirmation; all hard boundary checks have passed",
                "mode",
            )

        # 8. Apply allow rules only after deny, plan, whitelist, RBAC, and approval.
        if any(
            rule.effect == "allow" and self._rule_matches(rule, tool, arguments)
            for rule in self._rules
        ):
            return PermissionDecision(DecisionAction.ALLOW, "ALLOW_RULE", "Matched an allow rule", "rule")

        # 9. Regex is a teaching fallback; production also needs narrow tools, ASTs, and sandboxing.
        if tool.policy.effect is Effect.SHELL and _is_dangerous_shell(
            str(getattr(arguments, "command", ""))
        ):
            if context.mode is PermissionMode.DONT_ASK:
                return PermissionDecision(
                    DecisionAction.DENY,
                    "DANGEROUS_OPERATION",
                    "Dangerous shell operations are denied in non-interactive mode",
                    "risk",
                )
            return PermissionDecision(
                DecisionAction.CONFIRM,
                "DANGEROUS_OPERATION",
                "Dangerous shell operations require user confirmation",
                "risk",
            )

        return PermissionDecision(
            DecisionAction.ALLOW,
            "DEFAULT_ALLOWED",
            "All deterministic checks have passed",
            "default",
        )
