"""Strict argument schemas shared by the registered tools."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class StrictArgs(BaseModel):
    """The model may submit only candidate business arguments allowed by the schema."""

    model_config = ConfigDict(extra="forbid", strict=True)


class GetOrderArgs(StrictArgs):
    order_id: str = Field(pattern=r"^ord_[0-9]{4}$")


class CreateRefundArgs(StrictArgs):
    order_id: str = Field(pattern=r"^ord_[0-9]{4}$")
    amount: float = Field(gt=0, le=10_000)
    reason: str = Field(min_length=4, max_length=200)


class RunShellArgs(StrictArgs):
    command: str = Field(min_length=1, max_length=200)


# ===== IMPLEMENTED(Task 2): Define the transfer argument model =====
class TransferArgs(StrictArgs):
    from_account: str = Field(pattern=r"^ACC-[A-Z]-[0-9]{6}$")
    to_account: str = Field(pattern=r"^ACC-[A-Z]-[0-9]{6}$")
    amount: float = Field(gt=0, le=100_000)


ArgsModel = GetOrderArgs | CreateRefundArgs | RunShellArgs | TransferArgs
