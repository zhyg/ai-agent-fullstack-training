"""Shared test setup; all tool executions use ToolRuntime.invoke."""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Awaitable, Callable, Mapping
from typing import Any

import tool_governance_demo as demo

TRANSFER = "transfer"
APPROVAL_ID = "approval_transfer"
FROM_ACCOUNT = "ACC-A-123456"  # tenant_a, balance 100000.0
TO_ACCOUNT = "ACC-A-654321"  # tenant_a, balance 5000.0
SMALL_ACCOUNT = "ACC-A-888888"  # tenant_a, balance 20000.0
SLEEP_SECONDS = 3.0  # intentional slow call in transfer_handler


def async_test(test: Callable[..., Awaitable[None]]) -> Callable[..., None]:
    """Run async tests without depending on pytest-asyncio."""

    @functools.wraps(test)
    def run(*args: Any, **kwargs: Any) -> None:
        asyncio.run(test(*args, **kwargs))

    return run


def transfer_context(**overrides: Any) -> demo.ExecutionContext:
    """Context with transfer:execute permission and transfer whitelisted."""

    defaults: dict[str, Any] = {
        "permissions": frozenset({"order:read", "refund:create", "shell:run", "transfer:execute"}),
        "allowed_tools": frozenset({"get_order", "create_refund", "run_shell", "transfer"}),
    }
    return demo.base_context(**{**defaults, **overrides})


def accounts() -> dict[tuple[str, str], float]:
    store = getattr(demo, "ACCOUNTS", None)
    assert isinstance(store, dict), "Task 1 incomplete: tool_governance_demo.ACCOUNTS does not exist"
    return store


def balance(account: str, tenant_id: str = "tenant_a") -> float:
    store = accounts()
    assert (tenant_id, account) in store, f"Task 1 incomplete: ACCOUNTS is missing {(tenant_id, account)}"
    return store[(tenant_id, account)]


def approve(approvals: demo.ApprovalStore, arguments: Mapping[str, Any]) -> None:
    """Approve these exact arguments once; the digest must match at invocation."""

    approvals.approve(APPROVAL_ID, transfer_context(), TRANSFER, dict(arguments))


async def transfer(
    runtime: demo.ToolRuntime,
    tool_call_id: str,
    arguments: Mapping[str, Any],
    **context_overrides: Any,
) -> demo.ToolResult:
    return await runtime.invoke(
        demo.ToolCall(tool_call_id, TRANSFER, arguments),
        transfer_context(**context_overrides),
    )


def handler_runtime() -> tuple[demo.ToolRuntime, demo.ApprovalStore]:
    """Steps 4-5 support: use permanent registration for handler verification."""
    runtime, approvals, _ = demo.build_runtime()
    return runtime, approvals
