"""Supplementary regression tests and shared test helpers."""
