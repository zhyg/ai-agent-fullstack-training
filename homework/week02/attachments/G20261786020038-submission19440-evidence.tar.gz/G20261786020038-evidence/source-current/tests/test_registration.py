"""Step 5 discovery, registration, approval binding, and audit integration."""

from __future__ import annotations

import tool_governance_demo as demo
from tests.helpers import (
    TRANSFER, APPROVAL_ID, FROM_ACCOUNT, TO_ACCOUNT, SMALL_ACCOUNT, SLEEP_SECONDS,
    accounts, approve, async_test, transfer, transfer_context,
)


def test_transfer_discovery_and_registration() -> None:
    """Step 5: verify visibility, schema, policy, wiring, and canonical targets."""
    runtime, _, _ = demo.build_runtime()
    visible = {tool['function']['name']: tool for tool in runtime.model_tools(transfer_context())}
    assert visible[TRANSFER]['function']['parameters'] == demo.TransferArgs.model_json_schema()
    assert TRANSFER not in {tool['function']['name'] for tool in runtime.model_tools(demo.base_context())}
    tool = next(tool for tool in demo.build_tools() if tool.name == TRANSFER)
    assert tool.handler is demo.transfer_handler
    assert tool.precheck is demo.transfer_precheck
    assert tool.policy.effect is demo.Effect.WRITE
    assert tool.policy.risk is demo.Risk.HIGH
    assert tool.policy.permission == 'transfer:execute'
    assert tool.policy.requires_approval
    assert not tool.policy.idempotent and tool.policy.max_retries == 0
    assert 0 < tool.policy.timeout_seconds < SLEEP_SECONDS
    args = {'from_account': FROM_ACCOUNT, 'to_account': TO_ACCOUNT, 'amount': 100.0}
    variations = [args, {**args, 'from_account': SMALL_ACCOUNT},
                  {**args, 'to_account': SMALL_ACCOUNT}, {**args, 'amount': 200.0}]
    assert len({tool.canonical_target(demo.TransferArgs(**item)) for item in variations}) == 4


@async_test
async def test_transfer_approval_lifecycle_without_redaction() -> None:
    """Step 5: verify argument binding, one-time approval, and audit ordering.

    Redaction still runs; these assertions focus on the approval lifecycle.
    """
    runtime, approvals, audit = demo.build_runtime()
    args = {'from_account': FROM_ACCOUNT, 'to_account': TO_ACCOUNT, 'amount': 1_200.0}
    before = dict(accounts())
    pending = await transfer(runtime, 'pending', args)
    assert pending.code == 'APPROVAL_REQUIRED'
    approve(approvals, args)
    tampered = await transfer(runtime, 'tampered', {**args, 'amount': 9_000.0}, approval_id=APPROVAL_ID)
    assert tampered.code == 'APPROVAL_REQUIRED'
    assert accounts() == before
    executed = await transfer(runtime, 'approved', args, approval_id=APPROVAL_ID)
    assert executed.ok
    after = dict(accounts())
    replay = await transfer(runtime, 'replay', args, approval_id=APPROVAL_ID)
    assert replay.action is demo.DecisionAction.CONFIRM
    assert accounts() == after
    assert [(r.phase, r.code) for r in audit.records] == [
        ('decision', 'APPROVAL_REQUIRED'), ('decision', 'APPROVAL_REQUIRED'),
        ('decision', 'APPROVED'), ('execution', 'OK'), ('decision', 'APPROVAL_REQUIRED'),
    ]
