"""Step 3 same-account extension and Step 4 handler edge cases."""

from __future__ import annotations

import time

import pytest
import tool_governance_demo as demo
from tests.helpers import (
    APPROVAL_ID, FROM_ACCOUNT, TO_ACCOUNT, SLEEP_SECONDS,
    accounts, approve, async_test, handler_runtime, transfer,
)


@pytest.mark.parametrize("amount", [100.0, 60_000.0, 90_000.0])
@async_test
async def test_same_account_precheck(amount: float) -> None:
    """Step 3 extension: reject self-transfers before approval, range, or timeout."""
    runtime, _ = handler_runtime()
    before = dict(accounts())
    result = await transfer(runtime, "call_same", {
        "from_account": FROM_ACCOUNT, "to_account": FROM_ACCOUNT, "amount": amount,
    })
    assert result.code == "SAME_ACCOUNT"
    assert result.action is demo.DecisionAction.DENY
    assert accounts() == before


@async_test
async def test_handler_success_before_redaction() -> None:
    """Step 4: verify balance updates and transaction fields independently of masking.

    The runtime still applies Step 6 redaction; this test does not assert its format.
    """
    runtime, approvals = handler_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_200.0}
    approve(approvals, arguments)
    before = dict(accounts())
    result = await transfer(runtime, "call_tr_000003", arguments, approval_id=APPROVAL_ID)
    assert result.ok and result.code == "OK"
    assert result.content["txn_id"] == "000003"
    assert result.content["amount"] == 1_200.0
    assert result.content["status"] == "accepted"
    assert "from" in result.content and "to" in result.content
    before[("tenant_a", FROM_ACCOUNT)] -= 1_200.0
    before[("tenant_a", TO_ACCOUNT)] += 1_200.0
    assert accounts() == before


@pytest.mark.parametrize("destination", ["ACC-A-999999", "ACC-B-111111"])
@async_test
async def test_handler_missing_destination(destination: str) -> None:
    """Step 4: reject absent or other-tenant destinations without balance changes."""
    runtime, approvals = handler_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": destination, "amount": 100.0}
    approve(approvals, arguments)
    before = dict(accounts())
    result = await transfer(runtime, "call_missing", arguments, approval_id=APPROVAL_ID)
    assert result.code == "ACCOUNT_NOT_FOUND"
    assert not result.ok
    assert accounts() == before


@pytest.mark.parametrize("destination", [TO_ACCOUNT, "ACC-A-999999"])
@async_test
async def test_handler_timeout_before_mutation(destination: str) -> None:
    """Step 4: timeout precedes destination validation and balance mutation."""
    runtime, approvals = handler_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": destination, "amount": 90_000.0}
    approve(approvals, arguments)
    before = dict(accounts())
    started = time.perf_counter()
    result = await transfer(runtime, "call_slow", arguments, approval_id=APPROVAL_ID)
    assert result.code == "TIMEOUT_UNKNOWN"
    assert not result.ok
    assert time.perf_counter() - started < SLEEP_SECONDS
    assert accounts() == before
