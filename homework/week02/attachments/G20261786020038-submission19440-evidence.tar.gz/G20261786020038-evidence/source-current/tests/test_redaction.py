"""Step 6 nested output and redaction regression coverage."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import tool_governance_demo as demo
from tests.helpers import FROM_ACCOUNT, TO_ACCOUNT, accounts, async_test


@async_test
async def test_runtime_redacts_nested_account_output() -> None:
    """Step 6: verify nested account masking and existing redaction behavior."""
    payload = {
        'nested': [{'account': FROM_ACCOUNT}, (TO_ACCOUNT,)],
        'message': f'From {FROM_ACCOUNT} to {TO_ACCOUNT}; contact alice@example.com.',
        'access_token': 'demo-token',
        'credentials': {'password': 'demo-password', 'authorization': 'demo-auth'},
        'amount': 100.0,
        'status': 'accepted',
        'txn_id': '000003',
        'already_masked': 'ACC-A-****3456',
        'unrelated': 'ACC-A-1234567',
    }

    async def output_handler(*args: Any) -> Mapping[str, Any]:
        return payload

    tool = demo.ToolDefinition(
        name='get_order', description='Redaction verification',
        parameters_model=demo.GetOrderArgs,
        policy=demo.ToolPolicy(demo.Effect.READ, demo.Risk.LOW, 'order:read', False, 1.0, 0, True),
        handler=output_handler,
        canonical_target=lambda args: args.order_id,
    )
    runtime = demo.ToolRuntime([tool], demo.PermissionEngine((), demo.ApprovalStore()), demo.AuditSink())
    before = dict(accounts())
    result = await runtime.invoke(
        demo.ToolCall('redaction', 'get_order', {'order_id': 'ord_1001'}), demo.base_context(),
    )
    assert result.ok
    assert result.content == {
        'nested': [{'account': 'ACC-A-****3456'}, ['ACC-A-****4321']],
        'message': 'From ACC-A-****3456 to ACC-A-****4321; contact ***@***.',
        'access_token': '***',
        'credentials': {'password': '***', 'authorization': '***'},
        'amount': 100.0,
        'status': 'accepted',
        'txn_id': '000003',
        'already_masked': 'ACC-A-****3456',
        'unrelated': 'ACC-A-1234567',
    }
    assert payload['nested'][0]['account'] == FROM_ACCOUNT
    assert accounts() == before
