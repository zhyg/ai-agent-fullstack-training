"""Step 1 account isolation for acceptance and supplementary tests."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
import tool_governance_demo as demo


@pytest.fixture(autouse=True)
def isolated_accounts() -> Iterator[None]:
    """Step 1 support: restore the mutable ACCOUNTS state after each test."""

    store = getattr(demo, "ACCOUNTS", None)
    snapshot = dict(store) if isinstance(store, dict) else None
    demo.reset_side_effects()
    yield
    if snapshot is not None:
        store.clear()
        store.update(snapshot)
