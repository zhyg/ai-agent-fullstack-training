"""Original five transfer acceptance tests.

Steps 2-3 cover schema and business validation; Steps 4-6 cover execution,
permissions, approval, timeout, redaction, and audit integration. The Step 1
account-isolation fixture lives in root conftest.py. Supplementary cases live
in tests/. All tool executions continue through ToolRuntime.invoke.

Acceptance: python -m pytest test_tool_governance.py -v -k transfer
"""

from __future__ import annotations

import time
from typing import Any

import tool_governance_demo as demo
from tests.helpers import (
    APPROVAL_ID, FROM_ACCOUNT, TO_ACCOUNT, SMALL_ACCOUNT, SLEEP_SECONDS,
    accounts, approve, async_test, balance, transfer,
)


@async_test
async def test_transfer_rejects_injected_arguments_and_invalid_amount() -> None:
    """Step 2: validate extra fields, account formats, and amount constraints."""

    runtime, _approvals, _audit = demo.build_runtime()
    valid = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 100.0}
    before = dict(accounts())

    def assert_invalid(result: demo.ToolResult) -> None:
        assert result.ok is False
        assert result.action is demo.DecisionAction.DENY
        assert result.code == "INVALID_ARGUMENT"
        assert accounts() == before

    injected = await transfer(runtime, "call_tr_inject", {**valid, "approved": True, "user_id": "u_admin"})
    assert_invalid(injected)

    malformed = await transfer(runtime, "call_tr_format", {**valid, "from_account": "ACC-123456"})
    assert_invalid(malformed)

    malformed_destination = await transfer(
        runtime, "call_tr_destination_format", {**valid, "to_account": "ACC-654321"}
    )
    assert_invalid(malformed_destination)

    zero = await transfer(runtime, "call_tr_zero", {**valid, "amount": 0.0})
    assert_invalid(zero)

    over_schema = await transfer(runtime, "call_tr_schema", {**valid, "amount": 100_000.1})
    assert_invalid(over_schema)

    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_precheck_blocks_over_limit_and_insufficient_balance() -> None:
    """Step 3: reject the teaching amount range and insufficient balance."""

    runtime, approvals, _audit = demo.build_runtime()
    before = dict(accounts())

    over_limit = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 60_000.0}
    approve(approvals, over_limit)
    rejected = await transfer(runtime, "call_tr_limit", over_limit, approval_id=APPROVAL_ID)
    assert rejected.ok is False
    assert rejected.action is demo.DecisionAction.DENY
    assert rejected.code == "EXCEED_LIMIT"
    assert accounts() == before

    short = {"from_account": SMALL_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 30_000.0}
    approve(approvals, short)
    rejected = await transfer(runtime, "call_tr_balance", short, approval_id=APPROVAL_ID)
    assert rejected.ok is False
    assert rejected.action is demo.DecisionAction.DENY
    assert rejected.code == "INSUFFICIENT_BALANCE"
    assert accounts() == before

    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(SMALL_ACCOUNT) == 20_000.0
    assert balance(TO_ACCOUNT) == 5_000.0


@async_test
async def test_transfer_is_denied_without_permission_or_whitelist_and_in_plan_mode() -> None:
    """Step 5: approval cannot bypass RBAC, the whitelist, or plan mode."""

    runtime, approvals, _audit = demo.build_runtime()
    before = dict(accounts())
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_000.0}
    approve(approvals, arguments)
    approved: dict[str, Any] = {"approval_id": APPROVAL_ID}

    no_permission = await transfer(
        runtime,
        "call_tr_rbac",
        arguments,
        permissions=frozenset({"order:read", "refund:create", "shell:run"}),
        **approved,
    )
    assert no_permission.action is demo.DecisionAction.DENY
    assert no_permission.ok is False
    assert no_permission.code == "PERMISSION_DENIED"
    assert accounts() == before

    not_whitelisted = await transfer(
        runtime,
        "call_tr_whitelist",
        arguments,
        allowed_tools=frozenset({"get_order", "create_refund", "run_shell"}),
        **approved,
    )
    assert not_whitelisted.code == "TOOL_NOT_ALLOWED"
    assert not_whitelisted.ok is False
    assert not_whitelisted.action is demo.DecisionAction.DENY
    assert accounts() == before

    plan_mode = await transfer(
        runtime,
        "call_tr_plan",
        arguments,
        mode=demo.PermissionMode.PLAN,
        **approved,
    )
    assert plan_mode.code == "PLAN_MODE_DENIED"
    assert plan_mode.ok is False
    assert plan_mode.action is demo.DecisionAction.DENY
    assert accounts() == before

    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_requires_approval_bound_to_arguments_and_masks_accounts() -> None:
    """Steps 4-6: verify execution, approval binding, redaction, and auditing."""

    runtime, approvals, audit = demo.build_runtime()
    before = dict(accounts())
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_200.0}

    pending = await transfer(runtime, "call_tr_000001", arguments)
    assert pending.ok is False
    assert pending.action is demo.DecisionAction.CONFIRM
    assert pending.code == "APPROVAL_REQUIRED"
    assert accounts() == before
    assert balance(FROM_ACCOUNT) == 100_000.0

    approve(approvals, arguments)
    tampered = await transfer(
        runtime, "call_tr_000002", {**arguments, "amount": 9_000.0}, approval_id=APPROVAL_ID
    )
    assert tampered.action is demo.DecisionAction.CONFIRM
    assert tampered.ok is False
    assert tampered.code == "APPROVAL_REQUIRED"
    assert accounts() == before

    executed = await transfer(runtime, "call_tr_000003", arguments, approval_id=APPROVAL_ID)
    assert executed.ok is True
    assert executed.action is demo.DecisionAction.ALLOW
    assert executed.code == "OK"
    assert executed.content["txn_id"] == "000003"
    assert executed.content["amount"] == 1_200.0
    assert executed.content["status"] == "accepted"
    assert executed.content["from"] == "ACC-A-****3456"
    assert executed.content["to"] == "ACC-A-****4321"
    assert balance(FROM_ACCOUNT) == 98_800.0
    assert balance(TO_ACCOUNT) == 6_200.0

    assert [(record.phase, record.code) for record in audit.records] == [
        ("decision", "APPROVAL_REQUIRED"),
        ("decision", "APPROVAL_REQUIRED"),
        ("decision", "APPROVED"),
        ("execution", "OK"),
    ]

    after = dict(accounts())
    replay = await transfer(runtime, "call_tr_000004", arguments, approval_id=APPROVAL_ID)
    assert replay.action is demo.DecisionAction.CONFIRM
    assert replay.ok is False
    assert replay.code == "APPROVAL_REQUIRED"
    assert accounts() == after


@async_test
async def test_transfer_timeout_is_reported_as_unknown_and_leaves_balances_untouched() -> None:
    """Steps 4-5: a non-idempotent write timeout precedes debiting and is audited."""

    runtime, approvals, audit = demo.build_runtime()
    # Amounts above 80000 pass the teaching range and trigger sleep after checks and approval.
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 90_000.0}
    approve(approvals, arguments)

    started = time.perf_counter()
    result = await transfer(runtime, "call_tr_timeout", arguments, approval_id=APPROVAL_ID)
    elapsed = time.perf_counter() - started

    assert result.ok is False
    assert result.code == "TIMEOUT_UNKNOWN"
    assert elapsed < SLEEP_SECONDS
    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(TO_ACCOUNT) == 5_000.0
    assert audit.records[-1].phase == "execution"
    assert audit.records[-1].code == "TIMEOUT_UNKNOWN"
