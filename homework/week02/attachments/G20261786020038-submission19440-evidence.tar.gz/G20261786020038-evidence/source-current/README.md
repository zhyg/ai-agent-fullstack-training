# Tool Governance: Transfer Implementation

This Python implementation adds a simulated transfer tool to an agent tool runtime. Every tool execution goes through `ToolRuntime.invoke()`, which validates arguments, applies permissions and business rules, enforces one-time approval, executes within a timeout, redacts results, and records audit events. The project also includes order lookup, a simulated refund, and a simulated shell.

Accounts, approvals, and audit records are held in memory for teaching. No real money is transferred, and the shell tool does not execute system commands. Balances reset when the process ends; tests restore the account dictionary after each case.

## Transfer flow

```mermaid
flowchart TD
    A[Transfer tool call] --> B{Tool exists and arguments valid?}
    B -- No --> C[Reject: TOOL_NOT_FOUND or INVALID_ARGUMENT]
    B -- Yes --> D{Deny rules, plan mode, whitelist, permission}
    D -- Rejected --> E[Record decision and deny]
    D -- Passed --> F{Business precheck}
    F -- Same account, blocked range, or insufficient funds --> E
    F -- Passed --> G{Matching unused approval?}
    G -- No --> H[Confirm, or deny in dontAsk mode]
    G -- Yes --> I[Consume approval and run handler]
    I --> J{Amount above 80,000?}
    J -- Yes --> K[Sleep 3 seconds]
    K --> L[Runtime timeout after 2 seconds: TIMEOUT_UNKNOWN]
    J -- No --> M{Destination exists in tenant?}
    M -- No --> N[ACCOUNT_NOT_FOUND]
    M -- Yes --> O[Debit source and credit destination]
    O --> P[Redact account numbers and return result]
    L --> Q[Record execution outcome]
    N --> Q
    P --> Q
```

The business precheck rejects the same source and destination with `SAME_ACCOUNT`, then blocks the teaching-only range `50,000 < amount <= 80,000` with `EXCEED_LIMIT`, then checks the source balance within the current tenant. Missing source accounts produce `INSUFFICIENT_BALANCE`. Amounts above 80,000 can pass the precheck if funds are sufficient, but the handler sleeps before changing balances, so the two-second runtime timeout produces `TIMEOUT_UNKNOWN`. Destination validation occurs after that sleep.

Approval is bound to the user, tenant, tool, and exact arguments, expires, and can be consumed once. A modified amount cannot use the approval, but the original arguments may still use it until it is consumed. Successful output masks account numbers, for example `ACC-A-123456` becomes `ACC-A-****3456`.

## Project structure

```text
.
├── tool_governance_demo.py    # CLI entry point and compatibility exports
├── tool_governance/
│   ├── arguments.py           # Strict tool argument models
│   ├── domain.py              # Shared contracts, records, and exceptions
│   ├── policy.py              # Permission decisions and shell-risk checks
│   ├── runtime.py             # Tool execution, recovery, and redaction
│   ├── stores.py              # In-memory approval and audit stores
│   ├── bootstrap.py           # Tool registration and runtime construction
│   ├── demo.py                # Scripted offline demonstration
│   ├── agent.py               # Optional DeepSeek agent loop
│   └── tools/
│       ├── orders.py          # Order and refund tools
│       ├── transfer.py        # Accounts, transfer precheck, and handler
│       ├── shell.py           # Simulated shell
│       └── state.py           # Shared demo side-effect counters
├── test_tool_governance.py    # Five required acceptance tests
├── conftest.py                # Account isolation for all tests
├── tests/                     # Supplementary tests and shared helpers
└── prd/                       # Requirements, test cases, and structure notes
```

See [project structure](prd/project-structure.md) for module details and completed task locations.

## Setup and verification

Python 3.11 or later is required. Create a virtual environment and install the dependencies needed for the offline demo and tests:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install 'pydantic>=2,<3' pytest
```

Run the offline demo:

```bash
python tool_governance_demo.py
```

It prints six scripted order, refund, and shell results, followed by side-effect counts and an audit-record count. It does **not** run a transfer. A typical last line reports one simulated refund execution, zero shell executions, and eight audit records.

Run the five required transfer acceptance tests:

```bash
python -m pytest test_tool_governance.py -v -k transfer
```

Run all 16 acceptance and supplementary cases:

```bash
python -m pytest -v
```

Run specific edge cases:

```bash
# Same-account rejection at three amounts
python -m pytest tests/test_transfer_edges.py -v -k same_account

# Missing or cross-tenant destination; timeout before mutation
python -m pytest tests/test_transfer_edges.py -v -k 'missing_destination or timeout_before_mutation'

# Nested account masking and existing email/secret masking
python -m pytest tests/test_redaction.py -v
```

For an optional live DeepSeek agent loop, install `openai`, set `DEEPSEEK_API_KEY`, and run `python tool_governance_demo.py --agent`. `DEEPSEEK_BASE_URL` and `DEEPSEEK_MODEL` can override the defaults. This agent is configured to expose only `get_order`, not `transfer`.

## Test coverage

| Test file | Cases | Coverage |
| --- | ---: | --- |
| `test_tool_governance.py` | 5 | Argument validation; business prechecks; permissions and plan mode; approval, successful transfer, redaction and audit; timeout |
| `tests/test_transfer_edges.py` | 8 | Same-account rejection, successful balance updates, absent/cross-tenant destinations, and timeout ordering |
| `tests/test_registration.py` | 2 | Discovery, schema and policy wiring, canonical targets, approval binding and replay, audit order |
| `tests/test_redaction.py` | 1 | Nested account masking and existing email and sensitive-field masking |

Test executions use `ToolRuntime.invoke()`. The root fixture snapshots and restores the shared accounts after every case. Detailed scenarios and expected outcomes are in [transfer test cases](prd/transfer-test-cases.md).
