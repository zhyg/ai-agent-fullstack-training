"""Chapter 2 exercise: add a transfer tool to the governance framework.

The framework already supports validation, permissions, one-time approval,
timeout recovery, redaction, and auditing. Task markers identify all six steps:
IMPLEMENTED(Task N) marks completed work; TODO(Task N) marks remaining work.

Acceptance: python -m pytest test_tool_governance.py -v -k transfer

Do not change PermissionEngine.decide, bypass ToolRuntime.invoke in tests,
or remove the extra="forbid" behavior inherited by TransferArgs.

Implementation lives in the tool_governance package. Imports below preserve
the original exercise API and shared mutable objects.
"""

from __future__ import annotations

import argparse
import asyncio

from tool_governance.arguments import (
    StrictArgs,
    GetOrderArgs,
    CreateRefundArgs,
    RunShellArgs,
    TransferArgs,
    ArgsModel,
)
from tool_governance.domain import (
    PermissionMode,
    Effect,
    Risk,
    DecisionAction,
    Permission,
    ExecutionContext,
    ToolPolicy,
    Handler,
    Precheck,
    CanonicalTarget,
    ToolDefinition,
    PermissionRule,
    PermissionDecision,
    ToolCall,
    ToolResult,
    AuditRecord,
    ApprovalRecord,
    PolicyDenied,
    TransientToolError,
)
from tool_governance.stores import (
    _stable_value,
    _approval_digest,
    ApprovalStore,
    AuditSink,
)
from tool_governance.policy import (
    DANGEROUS_SHELL_PATTERNS,
    _is_dangerous_shell,
    PermissionEngine,
)
from tool_governance.runtime import (
    _redact,
    ToolRuntime,
)
from tool_governance.tools.state import (
    SIDE_EFFECTS,
    reset_side_effects,
)
from tool_governance.tools.orders import (
    ORDERS,
    get_order_handler,
    refund_precheck,
    create_refund_handler,
)
from tool_governance.tools.transfer import (
    ACCOUNTS,
    transfer_precheck,
    transfer_handler,
)
from tool_governance.tools.shell import (
    simulated_shell_handler,
)
from tool_governance.bootstrap import (
    build_tools,
    DEFAULT_RULES,
    base_context,
    build_runtime,
)
from tool_governance.demo import (
    run_offline_demo,
)
from tool_governance.agent import (
    run_deepseek_agent,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Python tool governance and permission state machine demo")
    parser.add_argument("--agent", action="store_true", help="Run a live agent loop using DeepSeek")
    parser.add_argument("--input", default="Please look up the status and refundable amount for order ord_1001")
    return parser.parse_args()


if __name__ == "__main__":
    cli_args = parse_args()
    asyncio.run(run_deepseek_agent(cli_args.input) if cli_args.agent else run_offline_demo())
