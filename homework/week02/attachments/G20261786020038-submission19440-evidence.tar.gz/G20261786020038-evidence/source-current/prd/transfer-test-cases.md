# Transfer Test Cases

This document tracks verification for the transfer feature. All six implementation
steps are complete, and the final suite passes all 16 tests. Earlier results below
describe verification at each step; any coverage limits are stated explicitly.

Current test layout: the original five acceptance tests remain in
`test_tool_governance.py`; supplementary cases live in `tests/`. Required
acceptance uses `python -m pytest test_tool_governance.py -v -k transfer` (five
cases). Optional full regression coverage uses `python -m pytest -v` (16 cases).

## Step 3: Business precheck (passed)

These 10 checks verify `transfer_precheck()` through `ToolRuntime.invoke()`.
All checks passed after Step 3 was implemented.

### Setup

- Use the initial `ACCOUNTS` balances from Step 1.
- Temporarily register a transfer tool using `TransferArgs`, `transfer_precheck`,
  and a write policy requiring approval and `transfer:execute` permission.
- Give each execution context that permission and whitelist `transfer`.
- Use default permission mode and no approval. A successful precheck therefore
  returns `APPROVAL_REQUIRED` with action `confirm`, without executing a transfer.
- Use `ACC-A-654321` as the destination in all cases. Destination validation is
  part of Step 4 and is not reached by these checks.
- Supply a placeholder handler that raises if called; no case should reach it.
- Snapshot `ACCOUNTS` before the checks and assert it remains identical after
  every invocation.

The temporary registration exists only in the verification setup. Permanent
registration in `build_tools()` remains Step 5.

### Cases

| # | Tenant | Source account | Amount | Expected code | Action | What it verifies |
| --- | --- | --- | ---: | --- | --- | --- |
| 1 | `tenant_a` | `ACC-A-123456` | 50,000.00 | `APPROVAL_REQUIRED` | `confirm` | The lower boundary is allowed. |
| 2 | `tenant_a` | `ACC-A-123456` | 50,000.01 | `EXCEED_LIMIT` | `deny` | Amounts just above the lower boundary are blocked. |
| 3 | `tenant_a` | `ACC-A-123456` | 80,000.00 | `EXCEED_LIMIT` | `deny` | The upper boundary is included in the blocked range. |
| 4 | `tenant_a` | `ACC-A-123456` | 80,000.01 | `APPROVAL_REQUIRED` | `confirm` | Amounts above the blocked range can proceed toward the timeout scenario. |
| 5 | `tenant_a` | `ACC-A-123456` | 100,000.00 | `APPROVAL_REQUIRED` | `confirm` | The schema maximum and full source balance pass the precheck. |
| 6 | `tenant_a` | `ACC-A-888888` | 20,000.00 | `APPROVAL_REQUIRED` | `confirm` | An amount equal to the available balance is allowed. |
| 7 | `tenant_a` | `ACC-A-888888` | 20,000.01 | `INSUFFICIENT_BALANCE` | `deny` | An amount just above the available balance is rejected. |
| 8 | `tenant_a` | `ACC-A-888888` | 60,000.00 | `EXCEED_LIMIT` | `deny` | The blocked-range check takes priority over insufficient funds. |
| 9 | `tenant_a` | `ACC-A-999999` | 1.00 | `INSUFFICIENT_BALANCE` | `deny` | A missing source account is treated as having zero available funds. |
| 10 | `tenant_b` | `ACC-A-123456` | 1.00 | `INSUFFICIENT_BALANCE` | `deny` | Another tenant's account balance cannot be used. |

### Results and scope

Each check asserted the expected result code, decision action, and unchanged
account dictionary. All 10 passed. Both Python files also passed syntax
compilation.

These checks validate the precheck through the governance runtime. They do not
verify transfer execution, destination validation, or actual timeout behavior;
those depend on later implementation steps.

## Same-account rule (passed)

Three additional runtime cases submit identical source and destination accounts
with amounts of 100.0, 60,000.0, and 90,000.0, without approval. All return
`SAME_ACCOUNT` with action `deny` and leave every balance unchanged. This verifies
that the new precheck takes priority over approval and the teaching amount range.

## Step 4: Transfer handler (passed)

Use a temporary tool registration with the real precheck and handler, a write
policy requiring approval, a timeout shorter than three seconds, no retries,
and non-idempotent behavior. Invoke every case through `ToolRuntime.invoke()`
with an approval bound to its exact arguments. Restore account data between
independent cases.

| ID | Case | Expected result |
| --- | --- | --- |
| 4.1 | Transfer 1,200.0 from `ACC-A-123456` to `ACC-A-654321` as `tenant_a`, using call ID `call_tr_000003`. | `OK`, action `allow`; balances become 98,800.0 and 6,200.0. Result contains `txn_id="000003"`, `amount=1200.0`, `status="accepted"`, and source/destination fields. |
| 4.2 | Transfer 100.0 to an absent destination, `ACC-A-999999`. | `ACCOUNT_NOT_FOUND`; all balances remain unchanged. |
| 4.3 | As `tenant_a`, transfer 100.0 to `ACC-B-111111`, which exists only for `tenant_b`. | `ACCOUNT_NOT_FOUND`; neither tenant's balances change. |
| 4.4 | Transfer 90,000.0 between the valid tenant_a accounts. | `TIMEOUT_UNKNOWN` before the three-second sleep completes; all balances remain unchanged. |
| 4.5 | Transfer 90,000.0 to absent destination `ACC-A-999999`. | `TIMEOUT_UNKNOWN`, because the sleep precedes destination validation; all balances remain unchanged. |

Account output masking is verified in Step 6. Step 4 verification must not
require masking before it is implemented.

### Results

All five handler cases and all three same-account cases passed. These are now
repeatable tests, originally in `test_tool_governance.py` and now in
`tests/test_transfer_edges.py`. At Step 4 they used temporary registration with
a 0.1-second timeout to verify cancellation of the three-second handler sleep.
Both Python files also passed syntax compilation.

```bash
.venv/bin/python -m pytest tests/test_transfer_edges.py -v
```

The original five acceptance tests were deselected for this check: permanent
registration and output redaction remain unfinished. Execution audit assertions
remain covered by those acceptance tests once the remaining steps are complete.

## Step 5: Tool registration (implemented)

Switch from temporary registration to `build_runtime()` and the transfer-enabled
execution context used by the existing test file. Do not change the permission
engine's decision order.

| ID | Case | Expected result |
| --- | --- | --- |
| 5.1 | Discover tools with transfer allowed, then with transfer excluded. | Transfer appears only in the allowed discovery result, with its argument schema. |
| 5.2 | Inspect the registered tool definition. | Uses `TransferArgs`, the real handler and precheck, write effect, required approval, `transfer:execute`, non-idempotent behavior, zero retries, and a positive timeout below three seconds. |
| 5.3 | Change the source, destination, or amount independently. | The canonical target distinguishes each argument combination. Approval binding is separately verified below. |
| 5.4 | Submit extra fields, malformed account IDs, zero amount, or an amount above 100,000. | `INVALID_ARGUMENT`; balances unchanged. |
| 5.5 | Invoke without the permission, outside the whitelist, or in plan mode, even with approval. | `PERMISSION_DENIED`, `TOOL_NOT_ALLOWED`, or `PLAN_MODE_DENIED`, respectively; balances unchanged. |
| 5.6 | Invoke valid arguments without approval. | `APPROVAL_REQUIRED`, action `confirm`; balances unchanged. |
| 5.7 | Approve 1,200.0, then invoke with 9,000.0 using that approval. | `APPROVAL_REQUIRED`; balances unchanged. The original arguments can still use the approval. |
| 5.8 | Invoke the originally approved arguments, then replay the consumed approval. | First call succeeds once; replay requires approval and causes no additional balance change. |
| 5.9 | Repeat Step 3 and Step 4 cases using permanent registration. | The same precheck, execution, and timeout outcomes occur through `build_runtime()`. |

### Results

The full suite now reports **14 passed, 1 failed**. The remaining failure is the
account-masking assertion in the original combined approval/redaction test,
which depends on Step 6. No assertion was relaxed or marked as an expected failure.

The handler tests now use `build_runtime()` and the permanent two-second timeout
instead of temporary registration. All eight Step 4/same-account cases passed
again, along with the existing validation, business-rule, permission, and timeout
tests. New tests passed for discovery, registration policy, canonical targets,
approval argument binding, one-time consumption, and audit ordering. The latter
approval lifecycle test independently verifies assertions that the original
combined test cannot yet reach because of its masking failure.

Both Python files passed syntax compilation. The original 10-case Step 3 boundary
matrix has not been rerun in full with permanent registration; its existing
acceptance-test subset passed. Earlier temporary-registration results above are
retained as historical verification records.

## Step 6: Account redaction and final acceptance (passed)

Inspect results returned by the runtime, after its redaction stage. Use temporary
handlers for nested-output coverage where necessary, still invoking them through
`ToolRuntime.invoke()`.

| ID | Case | Expected result |
| --- | --- | --- |
| 6.1 | Execute the approved 1,200.0 transfer. | Result source is `ACC-A-****3456` and destination is `ACC-A-****4321`; raw account identifiers are absent from the result content. |
| 6.2 | Return account identifiers inside nested dictionaries, lists, and surrounding text. | Each account identifier is masked while its prefix and last four digits remain. |
| 6.3 | Return email and sensitive-key data alongside account identifiers. | Existing email and sensitive-key masking still works. |
| 6.4 | Inspect balances and other result fields after masking. | Stored account keys remain intact; amounts, transaction ID, and status retain their values. |
| 6.5 | Run the existing five acceptance tests. | All pass, including approval binding, audit ordering, masking, and timeout behavior. |

Final acceptance command:

```bash
.venv/bin/python -m pytest test_tool_governance.py -v -k transfer
```

Also compile both Python files to validate syntax after implementation changes.

### Final results

All 16 tests passed, including the original five acceptance tests. The runtime
redaction test covers nested dictionaries, lists and tuples, multiple accounts
in surrounding text, existing email and sensitive-field masking, already-masked
values, and an unrelated longer identifier. Redaction preserves the handler's
original output and stored account data. The successful-transfer acceptance test
checks masked source/destination fields together with transaction values and
updated balances.

Both Python files passed syntax compilation. The offline demo also completed
with its original six results, one refund execution, zero shell executions, and
eight audit records. All six task markers now read `IMPLEMENTED(Task N)`.

## Acceptance-criteria review

Compared the suite with the five required acceptance categories supplied in the
course screenshot: argument validation, business prechecks, permissions/mode,
approval and successful transfer, and timeout handling. All categories were
already represented; the following assertions were strengthened:

- Step 2: added a malformed destination account case alongside the malformed
  source case. Every invalid-input invocation now checks `ok=False`, action
  `deny`, `INVALID_ARGUMENT`, and an unchanged snapshot of all account balances.
- Step 3: each blocked-range or insufficient-funds rejection now independently
  checks that all balances remain unchanged, rather than only checking at the
  end of the combined test. Both also assert `ok=False`.
- Step 5: each permission, whitelist, and plan-mode rejection now consistently
  checks `ok=False`, action `deny`, its specific error code, and all balances.
- Steps 4-6: the original approval acceptance test now checks all balances after
  the pending and tampered calls, and checks `ok=False`, `APPROVAL_REQUIRED`, and
  unchanged post-transfer balances when replaying a consumed approval. It no
  longer relies on the supplementary lifecycle test for replay balance coverage.

Approval argument binding means modified arguments cannot use the approval;
the original arguments can still use it until it is successfully consumed.
No business rules changed in this review.

Before the test split, the required acceptance command retained `-k transfer`
and selected seven cases while deselecting nine. The additional tests
are supplementary regression coverage, not an extension of the required
acceptance criteria. After the split, run the optional full suite with
`python -m pytest -v`; the root file contains only the five acceptance tests.
The new invalid-destination scenario is inside an existing test, so the total
collected case count remains 16.

Post-review validation: all 16 tests passed; both Python files passed syntax
compilation, and `git diff --check` reported no whitespace errors.

### Exercise constraints verified

- `PermissionEngine.decide` matches its source in initial commit `7ec14ae`
  exactly, including its decision order.
- All test tool executions use `ToolRuntime.invoke()`, either through the
  `transfer()` helper or directly in the nested-output test. No test calls a
  handler or precheck directly. The registration test inspects metadata and
  constructs argument models without executing a tool.
- `TransferArgs` still inherits `StrictArgs`, including `extra="forbid"` and
  `strict=True`; the injected-argument acceptance case passes.

After restoring the required `-k transfer` filter, acceptance reported seven
passed and nine deselected before the split. Both Python files passed syntax compilation.

### Test split validation

The small test split preserved every test/helper body, decorator, and assertion
exactly once. Shared helpers moved to `tests/helpers.py`; account isolation moved
to root `conftest.py` so it applies to both locations. The required acceptance
command now passes all five original tests; the full suite passes all 16 cases.
Python syntax and whitespace checks also passed.
