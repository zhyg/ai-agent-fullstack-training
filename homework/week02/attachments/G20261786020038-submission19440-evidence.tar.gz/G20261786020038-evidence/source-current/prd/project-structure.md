# Project Structure

The completed exercise is organized into a Python package. The root
`tool_governance_demo.py` remains the CLI entry point and compatibility import
module. `test_tool_governance.py` remains in place with the original five
acceptance tests. Supplementary tests were subsequently extracted as described below.

## Module responsibilities

| Module | Responsibility |
| --- | --- |
| `tool_governance/arguments.py` | `StrictArgs`, the four tool argument models, and their union |
| `tool_governance/domain.py` | Shared execution types, tool definitions, records, and exceptions |
| `tool_governance/policy.py` | Permission engine and dangerous-shell checks |
| `tool_governance/runtime.py` | Tool execution, validation, recovery, auditing, and output redaction |
| `tool_governance/stores.py` | In-memory approvals, approval digests, and audit collection |
| `tool_governance/bootstrap.py` | Tool registration, default rules, execution context, and runtime construction |
| `tool_governance/demo.py` | Scripted offline demonstration |
| `tool_governance/agent.py` | Optional DeepSeek agent loop |
| `tool_governance/tools/orders.py` | Order data, order lookup, refunds, and refund precheck |
| `tool_governance/tools/transfer.py` | Account data, transfer precheck, and transfer handler |
| `tool_governance/tools/shell.py` | Simulated shell handler |
| `tool_governance/tools/state.py` | Shared demonstration side-effect counters and reset helper |

Argument models have no dependencies on the runtime or business tools. Domain
types depend on argument models; stores and policies depend on those shared
contracts. The bootstrap module connects the runtime, policies, stores, and
business tools. Package modules never import the root compatibility module.

## Completed task locations

| Task | Location |
| --- | --- |
| 1: Account data | `tools/transfer.py`: `ACCOUNTS` |
| 2: Argument model | `arguments.py`: `TransferArgs` |
| 3: Business precheck and same-account extension | `tools/transfer.py`: `transfer_precheck` |
| 4: Transfer handler | `tools/transfer.py`: `transfer_handler` |
| 5: Registration | `bootstrap.py`: `build_tools` |
| 6: Redaction | `runtime.py`: `_redact` |

All locations are relative to `tool_governance/`. Search for `IMPLEMENTED(Task`
to find the preserved task markers.

## Compatibility and verification

The root module explicitly re-exports the original exercise's defined classes,
functions, constants, and private helpers. These are references to the package
objects, not copies. In particular, the test fixtures and handlers share the
same `ACCOUNTS`, `ORDERS`, and `SIDE_EFFECTS` dictionaries. Mutate shared state
in place; rebinding a compatibility export does not replace a package global.

The required acceptance command remains:

```bash
python -m pytest test_tool_governance.py -v -k transfer
```

Optional full regression suite and offline demonstration:

```bash
python -m pytest -v
python tool_governance_demo.py
```

Initial implementation-package refactor verification results (before the test split):

- Required acceptance: seven passed, nine deselected.
- Supplementary full suite: all 16 passed, with the test file byte-for-byte unchanged.
- All original class and function bodies retain their original syntax trees.
- `PermissionEngine.decide` exactly matches its source in initial commit `7ec14ae`.
- `TransferArgs` retains inherited `extra="forbid"` and `strict=True`.
- Shared mutable state identity checks passed.
- Offline demo output is byte-for-byte identical before and after extraction.
- All Python files compile and contain only ASCII characters; CLI help works.

The optional live DeepSeek request was not run. Its agent-loop implementation
was moved unchanged, and its `openai` dependency remains lazily imported.

## Test organization

| File | Responsibility | Collected cases |
| --- | --- | ---: |
| `test_tool_governance.py` | Original five required acceptance tests | 5 |
| `conftest.py` | Autouse account-isolation fixture for both test locations | 0 |
| `tests/helpers.py` | Constants, async wrapper, context, approval, and runtime invocation helpers | 0 |
| `tests/test_transfer_edges.py` | Same-account rejection and transfer handler edge cases | 8 |
| `tests/test_registration.py` | Discovery, registration, approval lifecycle, and auditing | 2 |
| `tests/test_redaction.py` | Nested-output redaction regressions | 1 |

The root fixture applies to both the acceptance file and supplementary tests.
Tool execution still goes through `ToolRuntime.invoke()`. The split preserved
every test/helper function body, decorator, and assertion exactly once, including
step comments. No production code changed during the test split.

After the split, the required acceptance command reports **5 passed**; the full
`python -m pytest -v` command reports **16 passed**. Running just the root test
file no longer runs supplementary coverage.
