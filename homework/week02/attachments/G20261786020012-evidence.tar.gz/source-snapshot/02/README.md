# 作业二：为治理框架增加“转账”工具

在课程附录 `tool_governance_demo.py` 基础上接入 `transfer` 工具，跑通参数校验 → 业务预检 → 权限判断 → 人工审批 → 超时处理 → 结果脱敏 → 审计追踪整条链路。

## 实现

- 账户数据：新增 `ACCOUNTS`，按 `(tenant_id, account_id)` 保存四个预设账户余额。
- 参数模型：`TransferArgs` 约束账号格式、金额区间，并保留 `StrictArgs` 的 `extra="forbid"`。
- 业务预检：`transfer_precheck` 先拦截 `50000 < amount <= 80000` 的 `EXCEED_LIMIT`，再检查转出账户是否存在及余额是否充足。
- 转账处理：`transfer_handler` 在 `amount > 80000` 时先 `sleep(3.0)`，再校验转入账户并更新双方余额，返回 `txn_id` 等信息。
- 工具注册：在 `build_tools()` 注册 `transfer`，写操作、高风险、需要人工审批、权限 `transfer:execute`、非幂等、超时 2 秒。
- 结果脱敏：`_redact` 把账号处理为 `ACC-A-****3456` 形式。

`PermissionEngine.decide` 未改动，测试全部通过 `ToolRuntime.invoke()` 调用。

## 运行

要求 Python 3.11+（`StrEnum`、`asyncio.timeout`）。

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python tool_governance_demo.py
```

## 验收

```bash
.venv/bin/python -m pytest tests/test_tool_governance.py -v -k "transfer"
```

结果：**5 passed**。覆盖参数注入与非法额度、预检拦截、RBAC / 白名单 / plan 模式拒绝、审批绑定与账号脱敏、超时未扣款。
