#!/usr/bin/env bash
# Run from the extracted evidence directory. Supply an interpreter with requirements installed.
set -u
PYTHON=${PYTHON:-python}
export PYTHONPATH="$PWD/source-snapshot/02"
run() {
    printf '\nCOMMAND:'
    printf ' %q' "$@"
    printf '\n'
    "$@"
    code=$?
    echo "exit_code=$code"
    return "$code"
}
run "$PYTHON" -c 'import sys,pydantic,pytest,tool_governance_demo as d; print(sys.version); print(pydantic.__version__,pytest.__version__); print(d.__file__)'
run "$PYTHON" -m pytest trusted/test_tool_governance.py -v -k transfer
run "$PYTHON" -m pytest test_supplement.py -v -s
run "$PYTHON" source-snapshot/02/tool_governance_demo.py
run "$PYTHON" test_supplement.py
