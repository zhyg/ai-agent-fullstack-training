import ast
import asyncio
import contextlib
import dataclasses
import io
import json
import pathlib
import time

import pytest
import tool_governance_demo as d

ROOT = pathlib.Path(__file__).resolve().parent
F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}


@pytest.fixture(autouse=True)
def isolated():
    before = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(before)


def args(amount=100.0, **kw):
    return dict(from_account=F, to_account=T, amount=amount, **kw)


def context(**kw):
    return d.base_context(permissions=frozenset({'transfer:execute', 'order:read'}),
                          allowed_tools=frozenset({'transfer', 'get_order'}), **kw)


async def invoke(a, approved=False, **kw):
    runtime, approvals, audit = d.build_runtime()
    ctx = context(**kw)
    if approved:
        approvals.approve('supplement', ctx, 'transfer', d.TransferArgs.model_validate(a))
        ctx = dataclasses.replace(ctx, approval_id='supplement')
    start = time.perf_counter()
    result = await runtime.invoke(d.ToolCall('call_supp_123456', 'transfer', a), ctx)
    print(json.dumps({'arguments': a, 'result': dataclasses.asdict(result),
                      'elapsed': time.perf_counter() - start,
                      'audit': [dataclasses.asdict(x) for x in audit.records],
                      'approval_used': approvals._records['supplement'].used if approved else None},
                     ensure_ascii=False, default=str))
    return result, audit, approvals


def test_A01_initial_accounts():
    assert d.ACCOUNTS == INITIAL
    assert all(type(x) is float for x in d.ACCOUNTS.values())


def test_A02_strict_schema():
    cases = [{k: v for k, v in args().items() if k != missing}
             for missing in ('from_account', 'to_account', 'amount')]
    cases += [{**args(), k: v} for k, v in [('approved', True), ('user_id', 'admin'),
              ('amount', -1.0), ('amount', '100.0'), ('from_account', 'bad'),
              ('to_account', 'ACC-A-12345'), ('to_account', 123456)]]
    for a in cases:
        result, audit, _ = asyncio.run(invoke(a))
        assert result.code == 'INVALID_ARGUMENT'
        assert audit.records[-1].phase == 'decision'
        assert d.ACCOUNTS == INITIAL


def test_A03_boundaries_and_timeout():
    for amount, expected in [(50000.0, 'APPROVAL_REQUIRED'), (50000.01, 'EXCEED_LIMIT'),
                              (80000.0, 'EXCEED_LIMIT'), (80000.01, 'APPROVAL_REQUIRED'),
                              (100000.0, 'APPROVAL_REQUIRED'), (100000.01, 'INVALID_ARGUMENT')]:
        r, audit, _ = asyncio.run(invoke(args(amount)))
        assert r.code == expected
        assert r.action == ('confirm' if expected == 'APPROVAL_REQUIRED' else 'deny')
        assert audit.records[-1].phase == 'decision'
    for amount in (80000.01, 100000.0):
        start = time.perf_counter()
        r, audit, _ = asyncio.run(invoke(args(amount), True))
        assert r.code == 'TIMEOUT_UNKNOWN'
        assert 1.8 < time.perf_counter() - start < 3.0
        assert audit.records[-1].phase == 'execution'
        assert d.ACCOUNTS == INITIAL


def test_A04_precheck_order_and_approval_not_consumed():
    for amount, code in [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')]:
        a = {**args(amount), 'from_account': S}
        for approved in (False, True):
            r, audit, approvals = asyncio.run(invoke(a, approved))
            assert r.code == code and r.action == 'deny'
            assert audit.records[-1].phase == 'decision'
            assert not approved or not approvals._records['supplement'].used
            assert d.ACCOUNTS == INITIAL


def test_A05_exact_balance():
    r, _, _ = asyncio.run(invoke({**args(20000.0), 'from_account': S}, True))
    assert r.ok and r.content['txn_id'] == '123456'
    assert d.ACCOUNTS == {**INITIAL, ('tenant_a', S): 0.0, ('tenant_a', T): 25000.0}


def test_A06_missing_destination():
    r, _, _ = asyncio.run(invoke({**args(), 'to_account': 'ACC-A-999999'}, True))
    assert r.code == 'ACCOUNT_NOT_FOUND' and r.content == '转入账户不存在'
    assert d.ACCOUNTS == INITIAL


def test_A07_tenant_isolation():
    for field in ('from_account', 'to_account'):
        r, _, _ = asyncio.run(invoke({**args(), field: B}, True))
        assert not r.ok and r.code == 'ACCOUNT_NOT_FOUND'
        assert d.ACCOUNTS == INITIAL


def test_A08_registration_and_targets():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert tool.parameters_model is d.TransferArgs
    p = tool.policy
    assert p.effect == d.Effect.WRITE and p.permission == 'transfer:execute'
    assert p.requires_approval or p.risk == d.Risk.HIGH
    assert 0 < p.timeout_seconds < 3 and not p.idempotent and p.max_retries == 0
    variants = [args(), {**args(), 'from_account': S}, {**args(), 'to_account': S}, args(101.0)]
    assert len({tool.canonical_target(d.TransferArgs(**a)) for a in variants}) == 4


def test_A09_redaction_and_order_regression():
    r, _, _ = asyncio.run(invoke(args(), True))
    assert r.content['from'] == 'ACC-A-****3456' and r.content['to'] == 'ACC-A-****4321'
    assert d._redact({'nested': [{'email': 'a@example.com', 'account': B}],
                       'authorization': 'fixture'}) == {
                       'nested': [{'email': '***@***', 'account': 'ACC-B-****1111'}],
                       'authorization': '***'}
    runtime, _, _ = d.build_runtime()
    r = asyncio.run(runtime.invoke(d.ToolCall('order', 'get_order', {'order_id': 'ord_1001'}), context()))
    assert r.ok and r.content['customer_email'] == '***@***' and r.content['access_token'] == '***'


def test_A10_engine_and_submitted_display():
    original = ast.parse((ROOT / 'trusted/tool_governance_demo-无答案.py').read_text())
    student = ast.parse(pathlib.Path(d.__file__).read_text())
    def decide(tree):
        cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'PermissionEngine')
        return next(x for x in cls.body if isinstance(x, ast.AsyncFunctionDef) and x.name == 'decide')
    assert ast.dump(decide(original)) == ast.dump(decide(student))
    assert ast.get_source_segment((ROOT / 'trusted/tool_governance_demo-无答案.py').read_text(), decide(original)) == ast.get_source_segment(pathlib.Path(d.__file__).read_text(), decide(student))
    capture = io.StringIO()
    with contextlib.redirect_stdout(capture):
        asyncio.run(d.run_offline_demo())
    output = capture.getvalue()
    print('submitted_demo_output:', output)
    print('submitted_transfer_display:', 'ACC-A-****3456' in output)
    print('submitted_audit_detail:', '"phase"' in output)
    print('import_path:', d.__file__)
    # This test records the submission as-is, not a teacher-added demonstration as student credit.
    assert '"action": "confirm"' in output
    assert 'ACC-A-****3456' not in output
    assert '"phase"' not in output


if __name__ == '__main__':
    print('Teacher-only offline transfer display; approval simulates human confirmation.')
    asyncio.run(invoke(args()))
    asyncio.run(invoke(args(), True))
