import ast
import asyncio
import dataclasses
import inspect
import json
from pathlib import Path
import sys
import time

import pydantic
import pytest
import tool_governance_demo as d

ROOT = Path('/home/user/workspace/repo')
BASE = dict(d.ACCOUNTS)
ARGS = {'from_account': 'ACC-A-123456', 'to_account': 'ACC-A-654321', 'amount': 100.0}
CTX = d.base_context(permissions=frozenset({'transfer:execute', 'order:read'}), allowed_tools=frozenset({'transfer', 'get_order'}))

def emit(label, value):
    print(label, json.dumps(value, ensure_ascii=False, default=str))

async def call(label, args, code, approved=False, **overrides):
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(BASE)
    rt, approvals, audit = d.build_runtime()
    ctx = dataclasses.replace(CTX, **overrides)
    if approved:
        approvals.approve('supplement', ctx, 'transfer', args)
        ctx = dataclasses.replace(ctx, approval_id='supplement')
    start = time.perf_counter()
    result = await rt.invoke(d.ToolCall('case_123456', 'transfer', args), ctx)
    elapsed = time.perf_counter() - start
    emit(label, {'result': dataclasses.asdict(result), 'elapsed': elapsed, 'balances': {str(k): v for k, v in d.ACCOUNTS.items()}, 'audit': [dataclasses.asdict(r) for r in audit.records]})
    assert result.code == code
    if code != 'OK':
        assert d.ACCOUNTS == BASE
    if code in {'EXCEED_LIMIT', 'INSUFFICIENT_BALANCE'}:
        assert audit.records[-1].phase == 'decision'
        if approved:
            assert not approvals._records['supplement'].used
    if code == 'TIMEOUT_UNKNOWN':
        assert elapsed < 3
    return result

async def main():
    emit('environment', {'python': sys.version, 'pydantic': pydantic.__version__, 'pytest': pytest.__version__, 'import': d.__file__})
    assert BASE == {('tenant_a', 'ACC-A-123456'): 100000.0, ('tenant_a', 'ACC-A-654321'): 5000.0, ('tenant_a', 'ACC-A-888888'): 20000.0, ('tenant_b', 'ACC-B-111111'): 50000.0}
    assert all(type(v) is float for v in BASE.values())
    emit('initial_accounts', {str(k): v for k, v in BASE.items()})
    original = (ROOT / 'hw-guide/week02/hw2/tool_governance_demo-无答案.py').read_text()
    student = Path(d.__file__).read_text()
    def method(source):
        cls = next(n for n in ast.parse(source).body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
        node = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
        return ast.get_source_segment(source, node)
    assert method(original) == method(student)
    emit('fixed_engine_exact_source_equal', True)
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs and tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert issubclass(d.TransferArgs, d.StrictArgs)
    assert inspect.iscoroutinefunction(d.transfer_precheck)
    assert tool.policy == d.ToolPolicy(d.Effect.WRITE, d.Risk.HIGH, 'transfer:execute', True, 1.0, 0, False)
    targets = [tool.canonical_target(d.TransferArgs(**args)) for args in [ARGS, {**ARGS, 'from_account': 'ACC-A-888888'}, {**ARGS, 'to_account': 'ACC-B-111111'}, {**ARGS, 'amount': 101.0}]]
    assert len(set(targets)) == 4
    emit('policy_and_targets', {'policy': dataclasses.asdict(tool.policy), 'targets': targets})
    for field in ARGS:
        await call('missing_'+field, {k:v for k,v in ARGS.items() if k != field}, 'INVALID_ARGUMENT')
    for field, value in [('amount', -1.0), ('amount', '100.0'), ('amount', True), ('from_account', 123456), ('to_account', 'ACC-A-12345'), ('approved', True), ('user_id', 'admin')]:
        await call('schema_'+field+'_'+str(value), {**ARGS, field: value}, 'INVALID_ARGUMENT')
    for amount, code in [(50000.0, 'APPROVAL_REQUIRED'), (50000.01, 'EXCEED_LIMIT'), (80000.0, 'EXCEED_LIMIT'), (80000.01, 'APPROVAL_REQUIRED'), (100000.0, 'APPROVAL_REQUIRED'), (100000.01, 'INVALID_ARGUMENT')]:
        await call('boundary_'+str(amount), {**ARGS, 'amount': amount}, code)
    for amount in [80000.01, 100000.0]:
        await call('timeout_'+str(amount), {**ARGS, 'amount': amount}, 'TIMEOUT_UNKNOWN', True)
    for amount, code in [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')]:
        for approved in [False, True]:
            await call('short_'+str(amount)+'_'+str(approved), {**ARGS, 'from_account': 'ACC-A-888888', 'amount': amount}, code, approved)
    await call('exact_balance', {**ARGS, 'from_account': 'ACC-A-888888', 'amount': 20000.0}, 'OK', True)
    assert d.ACCOUNTS[('tenant_a', 'ACC-A-888888')] == 0.0
    assert d.ACCOUNTS[('tenant_a', 'ACC-A-654321')] == 25000.0
    missing = await call('missing_target', {**ARGS, 'to_account': 'ACC-A-999999'}, 'ACCOUNT_NOT_FOUND', True)
    assert missing.content == '转入账户不存在'
    await call('missing_source', {**ARGS, 'from_account': 'ACC-A-999999'}, 'INSUFFICIENT_BALANCE')
    await call('foreign_source', {**ARGS, 'from_account': 'ACC-B-111111'}, 'INSUFFICIENT_BALANCE')
    await call('foreign_target', {**ARGS, 'to_account': 'ACC-B-111111'}, 'ACCOUNT_NOT_FOUND', True)
    await call('tenant_b_own', {'from_account': 'ACC-B-111111', 'to_account': 'ACC-B-111111', 'amount': 100.0}, 'OK', True, tenant_id='tenant_b')
    assert d.ACCOUNTS == BASE
    nested = {'list': ['ACC-B-111111', {'email':'alice@example.com', 'password':'hidden'}], 'authorization':'hidden'}
    expected = {'list': ['ACC-B-****1111', {'email':'***@***', 'password':'***'}], 'authorization':'***'}
    assert d._redact(nested) == expected
    emit('nested_redaction', d._redact(nested))
    rt, _, _ = d.build_runtime()
    order = await rt.invoke(d.ToolCall('order', 'get_order', {'order_id':'ord_1001'}), CTX)
    assert order.content['customer_email'] == '***@***' and order.content['access_token'] == '***'
    emit('order_regression', dataclasses.asdict(order))
    emit('supplement', 'ALL CHECKS PASSED')

asyncio.run(main())
