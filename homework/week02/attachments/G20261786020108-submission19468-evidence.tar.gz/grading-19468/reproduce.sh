#!/usr/bin/env bash
# Run from any directory after extracting the evidence archive.
set -u
HERE="$(dirname "$(realpath "$0")")"
STUDENT="$(realpath "$HERE/../chenguox-week2")"
uv venv "$HERE/venv"
uv pip install --python "$HERE/venv/bin/python" pydantic==2.14.3 pytest==9.2.0 pytest-asyncio==1.5.0
mkdir -p "$HERE/rerun-logs"
export PYTHONPATH="$STUDENT"
PY="$HERE/venv/bin/python"
run() {
    name="$1"; shift
    printf 'COMMAND:' > "$HERE/rerun-logs/$name.log"
    printf ' %q' "$@" >> "$HERE/rerun-logs/$name.log"
    printf '\n' >> "$HERE/rerun-logs/$name.log"
    "$@" >> "$HERE/rerun-logs/$name.log" 2>&1
    printf 'exit=%s\n' "$?" >> "$HERE/rerun-logs/$name.log"
}
run trusted "$PY" -m pytest "$HERE/trusted/test_tool_governance.py" -v -k transfer
run student-tests "$PY" -m pytest "$STUDENT/tests/test_tool_governance.py" -v -s
run student-demo "$PY" "$STUDENT/tool_governance_demo.py"
run supplement "$PY" "$HERE/supplement.py"
# supplement records expectation mismatches without aborting; its process exit 0 is not all-pass.
