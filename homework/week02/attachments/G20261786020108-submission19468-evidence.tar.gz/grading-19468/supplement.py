import asyncio
import ast
import difflib
import inspect
import json
import platform
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
STUDENT = Path(__file__).resolve().parent.parent / 'chenguox-week2'
sys.path.insert(0, str(STUDENT))
import tool_governance_demo as d
import pydantic, pytest, pytest_asyncio

BASE = dict(d.ACCOUNTS)
ARGS = dict(from_account='ACC-A-123456', to_account='ACC-A-654321', amount=1200.0)
checks = []

def emit(label, **values):
    print(json.dumps(dict(label=label, **values), ensure_ascii=False, default=str))

def check(label, actual, expected):
    good = actual == expected
    checks.append(good)
    emit(label, passed=good, actual=repr(actual), expected=repr(expected))

def env(permission='transfer:create'):
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(BASE)
    rt, approvals, audit = d.build_governance()
    ctx = d.ExecutionContext(trace_id='trace_A', user_id='u_A', tenant_id='tenant_a',
        permissions=frozenset({permission, 'order:read'}), allowed_tools=frozenset({'transfer', 'get_order'}))
    return rt, approvals, audit, ctx

async def call(rt, ctx, args, label):
    start = time.perf_counter()
    result = await rt.invoke(d.ToolCall(label, 'transfer', args), ctx)
    emit(label, result=asdict(result), action=result.action, elapsed=time.perf_counter()-start,
         balances=list(d.ACCOUNTS.items()), audit=rt.audit.records)
    return result

def approve(store, ctx, args):
    store.approve('approval_A', user_id=ctx.user_id, tenant_id=ctx.tenant_id,
                  tool_name='transfer', args=d.TransferArgs.model_validate(args))
    return replace(ctx, approval_id='approval_A')

async def main():
    emit('environment', python=platform.python_version(), pydantic=pydantic.__version__,
         pytest=pytest.__version__, pytest_asyncio=pytest_asyncio.__version__, imported=d.__file__)
    check('A01 initial', BASE, {('tenant_a','ACC-A-123456'):100000.0,
        ('tenant_a','ACC-A-654321'):5000.0,('tenant_a','ACC-A-888888'):20000.0,
        ('tenant_b','ACC-B-111111'):50000.0})
    check('A01 float', all(type(x) is float for x in BASE.values()), True)
    invalid = [dict(ARGS, approved=True),dict(ARGS,user_id='admin'),dict(ARGS,amount=-1.0),
        dict(ARGS,amount='1200.0'),dict(ARGS,from_account='ACC-123456'),dict(ARGS,to_account='ACC-a-123456')]
    invalid += [{k:v for k,v in ARGS.items() if k != missing} for missing in ARGS]
    for i,args in enumerate(invalid):
        rt,ap,au,ctx=env()
        r=await call(rt,ctx,args,f'A02_{i}')
        check(f'A02_{i} code',r.error_code,'INVALID_ARGUMENT')
        check(f'A02_{i} unchanged',d.ACCOUNTS,BASE)
    for amount,code in [(50000.,'APPROVAL_REQUIRED'),(50000.01,'EXCEED_LIMIT'),
        (80000.,'EXCEED_LIMIT'),(80000.01,'APPROVAL_REQUIRED'),(100000.,'APPROVAL_REQUIRED'),
        (100000.01,'INVALID_ARGUMENT')]:
        rt,ap,au,ctx=env(); args=dict(ARGS,amount=amount)
        r=await call(rt,ctx,args,f'A03_pending_{amount}')
        check(f'A03_{amount}',r.error_code,code)
    for amount in [80000.01,90000.,100000.]:
        rt,ap,au,ctx=env(); args=dict(ARGS,amount=amount)
        ctx=approve(ap,ctx,args); start=time.perf_counter()
        r=await call(rt,ctx,args,f'A03_timeout_{amount}')
        check(f'A03_timeout_{amount}',(r.error_code, d.ACCOUNTS==BASE, time.perf_counter()-start<3),('TIMEOUT_UNKNOWN',True,True))
    for amount,code in [(30000.,'INSUFFICIENT_BALANCE'),(60000.,'EXCEED_LIMIT')]:
        for approved in [False,True]:
            rt,ap,au,ctx=env(); args=dict(ARGS,from_account='ACC-A-888888',amount=amount)
            if approved: ctx=approve(ap,ctx,args)
            r=await call(rt,ctx,args,f'A04_{amount}_{approved}')
            check('A04 preapproval business denial',(r.error_code,d.ACCOUNTS==BASE), (code,True))
            if approved: check('A04 approval not used',ap._items['approval_A'].used,False)
    rt,ap,au,ctx=env(); args=dict(ARGS,from_account='ACC-A-888888',amount=20000.)
    r=await call(rt,approve(ap,ctx,args),args,'A05_full_balance')
    check('A05',(r.ok,d.ACCOUNTS[('tenant_a','ACC-A-888888')],d.ACCOUNTS[('tenant_a','ACC-A-654321')]),(True,0.,25000.))
    for label,changes,code in [('A06',{'to_account':'ACC-A-000000'},'ACCOUNT_NOT_FOUND'),
        ('A07_source',{'from_account':'ACC-B-111111'},'INSUFFICIENT_BALANCE'),
        ('A07_dest',{'to_account':'ACC-B-111111'},'ACCOUNT_NOT_FOUND'),
        ('A07_missing_source',{'from_account':'ACC-A-000000'},'INSUFFICIENT_BALANCE')]:
        rt,ap,au,ctx=env(); args=dict(ARGS,**changes)
        r=await call(rt,approve(ap,ctx,args),args,label)
        check(label,(r.error_code,d.ACCOUNTS==BASE),(code,True))
        if code=='ACCOUNT_NOT_FOUND': check(label+' message',r.content,{'message':'转入账户不存在'})
    rt,ap,au,ctx=env(permission='transfer:execute')
    r=await call(rt,approve(ap,ctx,ARGS),ARGS,'A08_required_permission')
    check('A08 required permission',r.ok,True)
    tool=next(x for x in d.build_tools() if x.name=='transfer')
    emit('A08 registration',policy=asdict(tool.policy),model=tool.parameters_model.__name__,
        handler=tool.handler.__name__,precheck=tool.precheck.__name__,schema=d.TransferArgs.model_json_schema())
    targets=[tool.canonical_target(d.TransferArgs(**args),ctx) for args in [ARGS,
        dict(ARGS,from_account='ACC-A-888888'),dict(ARGS,to_account='ACC-A-888888'),dict(ARGS,amount=1300.)]]
    check('A08 canonical distinguish',len(set(targets)),4); emit('A08 targets',targets=targets)
    rt,ap,au,ctx=env(); approved=approve(ap,ctx,ARGS)
    for changes in [dict(amount=9000.),dict(to_account='ACC-A-888888')]:
        r=await call(rt,approved,dict(ARGS,**changes),'A09_tampered')
        check('A09 bound',r.error_code,'APPROVAL_REQUIRED')
    r=await call(rt,approved,ARGS,'call_tr_000003')
    check('A09 success',r.ok,True)
    check('A09 txn_id',r.content['txn_id'],'000003')
    check('A09 mask',(r.content['from'],r.content['to']),('ACC-A-****3456','ACC-A-****4321'))
    check('A09 balances',(d.ACCOUNTS[('tenant_a','ACC-A-123456')],d.ACCOUNTS[('tenant_a','ACC-A-654321')]),(98800.,6200.))
    r=await call(rt,approved,ARGS,'A09_replay'); check('A09 replay',r.error_code,'APPROVAL_REQUIRED')
    order=await rt.invoke(d.ToolCall('A09_order','get_order',{'order_id':'ord_1001'}),ctx)
    emit('A09_order',result=asdict(order)); check('A09 order masks',(order.content['customer_email'],order.content['access_token']),('***@***','***'))
    check('A09 nested',d.redact({'x':[{'password':'secret','v':('a@example.com','ACC-A-123456')}]}),
        {'x':[{'password':'***','v':('***@***','ACC-A-****3456')}]})
    rt,ap,au,ctx=env()
    r=await call(rt,replace(ctx,mode=d.PermissionMode.DONT_ASK),ARGS,'A10_dontask')
    check('A10 dontask action',r.action.value,'deny')
    original=Path(__file__).resolve().parent/'trusted/attachment.py'
    def decide(path):
        tree=ast.parse(path.read_text())
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PermissionEngine')
        node=next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='decide')
        return ast.get_source_segment(path.read_text(),node)
    before,after=decide(original),decide(STUDENT/'tool_governance_demo.py')
    check('A10 fixed engine source',before==after,True)
    print(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='attachment.decide',tofile='student.decide')))
    emit('SUMMARY',passed=sum(checks),failed=len(checks)-sum(checks),note='failed checks are independent observations, not score deductions')
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(BASE)

asyncio.run(main())
