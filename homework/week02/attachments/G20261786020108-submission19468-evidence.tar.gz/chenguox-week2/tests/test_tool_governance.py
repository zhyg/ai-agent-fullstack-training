from __future__ import annotations

import asyncio
import json
from collections.abc import Iterator
from dataclasses import replace
from typing import Any

import pytest

from tool_governance_demo import (
    ACCOUNT,
    ACCOUNTS,
    ApprovalStore,
    AuditSink,
    ExecutionContext,
    PermissionDecision,
    PermissionMode,
    ToolCall,
    ToolRuntime,
    TransferArgs,
    build_governance,
)


# 共用的合法转账参数；测试异常情况时，在此基础上覆盖个别字段。
TRANSFER_ARGUMENTS = {
    "from_account": "ACC-A-123456",
    "to_account": "ACC-A-654321",
    "amount": 1000.0,
}


@pytest.fixture
def transfer_environment() -> Iterator[tuple[ToolRuntime, ApprovalStore, AuditSink, ExecutionContext]]:
    # fixture 默认在每个测试前执行；保存余额快照，避免测试之间相互影响。
    balances = dict(ACCOUNTS)
    runtime, approvals, audit = build_governance()
    # 业务权限与工具白名单是两道独立检查，上下文同时限定当前用户和租户。
    context = ExecutionContext(
        trace_id="trace_transfer",
        user_id="u_100",
        tenant_id="tenant_a",
        permissions=frozenset({"transfer:create"}),
        allowed_tools=frozenset({"transfer"}),
    )
    try:
        # yield 将环境交给测试；测试结束后，即使断言失败也会执行 finally。
        yield runtime, approvals, audit, context
    finally:
        # 原地恢复余额字典，保留 ACCOUNT 等别名对该字典的引用。
        ACCOUNTS.clear()
        ACCOUNTS.update(balances)


def approve_transfer(
    approvals: ApprovalStore,
    context: ExecutionContext,
    approval_id: str,
    arguments: dict[str, Any],
) -> ExecutionContext:
    # 先校验参数，再将审批绑定到用户、租户、工具和本次转账的完整参数。
    approvals.approve(
        approval_id,
        user_id=context.user_id,
        tenant_id=context.tenant_id,
        tool_name="transfer",
        args=TransferArgs.model_validate(arguments),
    )
    # replace 创建带审批编号的新上下文，原上下文仍可用于未审批的场景。
    return replace(context, approval_id=approval_id)


@pytest.mark.asyncio
async def test_transfer_argument_validation(transfer_environment) -> None:
    # asyncio 标记让 pytest 执行异步测试；同名参数用于接收 fixture 提供的环境。
    runtime, _, audit, context = transfer_environment
    balances = dict(ACCOUNTS)
    # 覆盖伪造审批/身份、账户格式错误，以及金额为零、负数、超限或非有限值。
    invalid_arguments = [
        {"approved": True},
        {"user_id": "admin"},
        {"approved": True, "user_id": "admin"},
        {"from_account": "ACC-A-12345"},
        {"to_account": "ACC-a-654321"},
        {"amount": 0},
        {"amount": -1},
        {"amount": 100000.01},
        {"amount": float("nan")},
        {"amount": float("inf")},
    ]
    for index, changes in enumerate(invalid_arguments):
        # changes 覆盖同名字段，所有案例均通过运行时的统一调用入口验证。
        result = await runtime.invoke(
            ToolCall(f"invalid_transfer_{index}", "transfer", {**TRANSFER_ARGUMENTS, **changes}),
            context,
        )
        assert not result.ok
        assert result.error_code == "INVALID_ARGUMENT"
        # 参数校验失败不得改变余额，并且必须留下对应的错误审计。
        assert ACCOUNTS == balances
        assert audit.records[-1]["error_code"] == "INVALID_ARGUMENT"
    # 兼容别名必须指向同一字典；提供给模型的工具定义也应禁止额外参数。
    assert ACCOUNT is ACCOUNTS
    model_tools = runtime.model_tools(context)
    assert [tool["function"]["name"] for tool in model_tools] == ["transfer"]
    assert model_tools[0]["function"]["parameters"]["additionalProperties"] is False


@pytest.mark.asyncio
async def test_transfer_business_precheck(transfer_environment) -> None:
    runtime, approvals, audit, context = transfer_environment
    balances = dict(ACCOUNTS)
    # 教学限额区间为 (50000, 80000]；同时触发限额和余额不足时，先报限额错误。
    # tenant_b 的账户不能作为当前 tenant_a 的转出账户使用。
    cases = [
        ({"amount": 50000.01}, "EXCEED_LIMIT"),
        ({"amount": 80000.0}, "EXCEED_LIMIT"),
        ({"from_account": "ACC-A-654321", "amount": 60000.0}, "EXCEED_LIMIT"),
        ({"from_account": "ACC-A-654321", "amount": 5000.01}, "INSUFFICIENT_BALANCE"),
        ({"from_account": "ACC-B-111111"}, "INSUFFICIENT_BALANCE"),
    ]
    for index, (changes, expected_code) in enumerate(cases):
        arguments = {**TRANSFER_ARGUMENTS, **changes}
        # 提供有效审批，验证业务预检仍会拦截，且不消耗审批、不改变余额。
        approved_context = approve_transfer(approvals, context, f"precheck_{index}", arguments)
        result = await runtime.invoke(ToolCall(f"precheck_{index}", "transfer", arguments), approved_context)
        assert result.error_code == expected_code
        assert ACCOUNTS == balances
        assert not approvals._items[approved_context.approval_id].used
        assert audit.records[-1]["error_code"] == expected_code

    # 转入账户不存在或属于其他租户时，处理器应在扣款前返回错误。
    for index, to_account in enumerate(("ACC-A-000000", "ACC-B-111111")):
        arguments = {**TRANSFER_ARGUMENTS, "to_account": to_account}
        approved_context = approve_transfer(approvals, context, f"missing_target_{index}", arguments)
        result = await runtime.invoke(
            ToolCall(f"missing_target_{index}", "transfer", arguments), approved_context
        )
        assert result.error_code == "ACCOUNT_NOT_FOUND"
        assert result.content == {"message": "转入账户不存在"}
        assert ACCOUNTS == balances
        assert audit.records[-1]["error_code"] == "ACCOUNT_NOT_FOUND"


@pytest.mark.asyncio
async def test_transfer_permissions_and_modes(transfer_environment) -> None:
    runtime, approvals, audit, context = transfer_environment
    balances = dict(ACCOUNTS)
    approved_context = approve_transfer(approvals, context, "permission_approval", TRANSFER_ARGUMENTS)
    # 已有审批也必须通过权限与模式检查；同时缺少权限和白名单时，先报白名单错误。
    # PLAN 模式禁止转账，BYPASS_PERMISSIONS 模式仍然要检查业务权限。
    cases = [
        (replace(approved_context, permissions=frozenset()), "PERMISSION_DENIED"),
        (replace(approved_context, allowed_tools=frozenset()), "TOOL_NOT_ALLOWED"),
        (
            replace(approved_context, permissions=frozenset(), allowed_tools=frozenset()),
            "TOOL_NOT_ALLOWED",
        ),
        (replace(approved_context, mode=PermissionMode.PLAN), "PLAN_MODE_DENIED"),
        (
            replace(approved_context, mode=PermissionMode.BYPASS_PERMISSIONS, permissions=frozenset()),
            "PERMISSION_DENIED",
        ),
    ]
    for index, (restricted_context, expected_code) in enumerate(cases):
        result = await runtime.invoke(
            ToolCall(f"restricted_{index}", "transfer", TRANSFER_ARGUMENTS), restricted_context
        )
        assert result.action is PermissionDecision.DENY
        assert result.error_code == expected_code
        assert ACCOUNTS == balances
        # 权限阶段拒绝时，尚未消耗一次性审批。
        assert not approvals._items[approved_context.approval_id].used
        assert audit.records[-1]["decision"] is PermissionDecision.DENY


@pytest.mark.asyncio
async def test_transfer_approval_execution_redaction_and_audit(transfer_environment) -> None:
    runtime, approvals, audit, context = transfer_environment
    balances = dict(ACCOUNTS)
    # 未审批时返回 CONFIRM，要求用户确认，此时余额保持不变。
    pending = await runtime.invoke(ToolCall("pending_transfer", "transfer", TRANSFER_ARGUMENTS), context)
    assert pending.error_code == "APPROVAL_REQUIRED"
    assert pending.action is PermissionDecision.CONFIRM
    assert ACCOUNTS == balances
    # 运行 pytest 时加 -s，可以看到此状态及后面的审计输出。
    print(json.dumps({"status": pending.action.name, "code": pending.error_code}))

    # BYPASS_PERMISSIONS 模式仍不能绕过转账审批。
    bypass = await runtime.invoke(
        ToolCall("bypass_transfer", "transfer", TRANSFER_ARGUMENTS),
        replace(context, mode=PermissionMode.BYPASS_PERMISSIONS),
    )
    assert bypass.error_code == "APPROVAL_REQUIRED"
    assert ACCOUNTS == balances

    approved_context = approve_transfer(approvals, context, "transfer_approval", TRANSFER_ARGUMENTS)
    # 确认后修改金额或收款账户，原审批不再匹配，但不会因此被消耗。
    for index, changes in enumerate(({"amount": 2000.0}, {"to_account": "ACC-A-888888"})):
        changed = await runtime.invoke(
            ToolCall(f"changed_transfer_{index}", "transfer", {**TRANSFER_ARGUMENTS, **changes}),
            approved_context,
        )
        assert changed.error_code == "APPROVAL_REQUIRED"
        assert ACCOUNTS == balances
        assert not approvals._items[approved_context.approval_id].used

    # 其他用户不能使用当前用户的审批。
    wrong_user = await runtime.invoke(
        ToolCall("wrong_user_transfer", "transfer", TRANSFER_ARGUMENTS),
        replace(approved_context, user_id="another_user"),
    )
    assert wrong_user.error_code == "APPROVAL_REQUIRED"
    assert ACCOUNTS == balances

    # 使用原用户、原参数和有效审批转账；交易编号取调用编号的末六位。
    success = await runtime.invoke(
        ToolCall("transfer_123456", "transfer", TRANSFER_ARGUMENTS), approved_context
    )
    assert success.ok
    assert success.action is PermissionDecision.ALLOW
    assert success.content == {
        "txn_id": "txn_123456",
        "from": "ACC-A-****3456",
        "to": "ACC-A-****4321",
        "amount": 1000.0,
        "status": "accepted",
    }
    # 转出账户减少 1000，转入账户增加 1000，其余账户余额保持不变。
    expected_balances = {
        **balances,
        ("tenant_a", "ACC-A-123456"): 99000.0,
        ("tenant_a", "ACC-A-654321"): 6000.0,
    }
    assert ACCOUNTS == expected_balances
    assert approvals._items[approved_context.approval_id].used
    # 同一次成功调用应有授权与最终结果两条审计，通过 tool_call_id 关联。
    success_records = [record for record in audit.records if record["tool_call_id"] == "transfer_123456"]
    assert len(success_records) == 2
    assert success_records[0]["stage"] == "authorized"
    assert success_records[-1]["ok"] is True
    assert success_records[-1]["error_code"] is None
    assert success_records[-1]["trace_id"] == context.trace_id
    # 返回结果与审计参数都应脱敏，审计记录中不能出现完整账号。
    assert success_records[-1]["arguments"] == {
        "from_account": "ACC-A-****3456",
        "to_account": "ACC-A-****4321",
    }
    assert "ACC-A-123456" not in json.dumps(audit.records)
    assert "ACC-A-654321" not in json.dumps(audit.records)
    print(json.dumps(success_records, ensure_ascii=False, default=str))

    # 一次性审批已被消耗，重复使用必须被拒绝，不能再次扣款。
    replay = await runtime.invoke(ToolCall("replay_transfer", "transfer", TRANSFER_ARGUMENTS), approved_context)
    assert replay.error_code == "APPROVAL_REQUIRED"
    assert ACCOUNTS == expected_balances

    # 转出余额为 99000，两个各转 50000 的请求分别取得独立审批。
    concurrent_arguments = {**TRANSFER_ARGUMENTS, "amount": 50000.0}
    concurrent_contexts = [
        approve_transfer(approvals, context, f"concurrent_approval_{index}", concurrent_arguments)
        for index in range(2)
    ]
    # gather 并发执行请求；账户锁和锁内预检应保证只有一笔成功，避免透支。
    results = await asyncio.gather(*(
        runtime.invoke(ToolCall(f"concurrent_transfer_{index}", "transfer", concurrent_arguments), approved)
        for index, approved in enumerate(concurrent_contexts)
    ))
    assert sum(result.ok for result in results) == 1
    assert {result.error_code for result in results} == {None, "INSUFFICIENT_BALANCE"}
    assert ACCOUNTS[("tenant_a", "ACC-A-123456")] == 49000.0
    assert ACCOUNTS[("tenant_a", "ACC-A-654321")] == 56000.0


@pytest.mark.asyncio
async def test_transfer_timeout_before_debit(transfer_environment) -> None:
    runtime, approvals, audit, context = transfer_environment
    balances = dict(ACCOUNTS)
    # 金额超过 80000 时，处理器在扣款前等待 3 秒，超过工具的 2 秒超时限制。
    arguments = {**TRANSFER_ARGUMENTS, "amount": 90000.0}
    approved_context = approve_transfer(approvals, context, "timeout_approval", arguments)
    result = await runtime.invoke(ToolCall("timeout_transfer", "transfer", arguments), approved_context)
    assert not result.ok
    assert result.error_code == "TIMEOUT_UNKNOWN"
    # 本案例在扣款前超时，余额不变；进入执行阶段后，审批仍会被消耗。
    assert ACCOUNTS == balances
    assert approvals._items[approved_context.approval_id].used
    # 超时也应保留授权与失败审计，并对记录中的账号进行脱敏。
    assert len(audit.records) == 2
    assert audit.records[0]["stage"] == "authorized"
    assert audit.records[-1]["tool_call_id"] == "timeout_transfer"
    assert audit.records[-1]["ok"] is False
    assert audit.records[-1]["error_code"] == "TIMEOUT_UNKNOWN"
    assert audit.records[-1]["arguments"]["from_account"] == "ACC-A-****3456"
