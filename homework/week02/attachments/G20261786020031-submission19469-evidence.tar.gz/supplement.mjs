// Read-only grader: imports only built student code, no business edits or substitutes.
import { loadConfig } from '../tool-platform/runtime/dist/src/config.js';
import { ToolRegistry } from '../tool-platform/runtime/dist/src/registry.js';
import { PolicyEngine } from '../tool-platform/runtime/dist/src/policy.js';
import { ToolRuntime, redact } from '../tool-platform/runtime/dist/src/runtime.js';
import { PlatformStore } from '../tool-platform/runtime/dist/src/store.js';
import { createOrderTool } from '../tool-platform/runtime/dist/src/tools/order.js';
import { createTicketTool } from '../tool-platform/runtime/dist/src/tools/ticket.js';
const config = loadConfig('../config/platform.yaml');
const valid = {from_account:'ACC-A-123456', to_account:'ACC-A-654321', amount:100};
const cases = [];
for (const key of Object.keys(valid)) { const args={...valid}; delete args[key]; cases.push(['A02 missing '+key,args]); }
for (const args of [{...valid,approved:true},{...valid,user_id:'admin'},{...valid,amount:-1},{...valid,amount:'100'},{...valid,from_account:'bad'},{...valid,to_account:'bad'}]) cases.push(['A02 strict',args]);
for (const amount of [50000,50000.01,80000,80000.01,100000,100000.01]) cases.push(['A03 boundary unapproved',{...valid,amount}]);
for (const amount of [30000,60000]) cases.push(['A04 precheck unapproved',{...valid,from_account:'ACC-A-888888',amount}]);
cases.push(['A05 full balance',{...valid,from_account:'ACC-A-888888',amount:20000}]);
cases.push(['A06 missing target',{...valid,to_account:'ACC-A-999999'}]);
cases.push(['A07 foreign source',{...valid,from_account:'ACC-B-111111'}]);
cases.push(['A07 foreign target',{...valid,to_account:'ACC-B-111111'}]);
cases.push(['A07 missing source',{...valid,from_account:'ACC-A-999999'}]);
cases.push(['A09 transfer result',valid]);
console.log('Student imports:', import.meta.resolve('../tool-platform/runtime/dist/src/runtime.js'));
for (const [label,args] of cases) {
  const store = new PlatformStore(':memory:');
  const registry = new ToolRegistry();
  registry.register(createOrderTool(config)); registry.register(createTicketTool(store));
  const runtime = new ToolRuntime(registry,new PolicyEngine(config.policy),store);
  const context={traceId:label,requestId:label,userId:'trainer-1',tenantId:'tenant_a',roles:['supervisor'],agentName:'support-agent',mode:'execute'};
  const started=performance.now();
  const result=await runtime.invoke({context,toolCallId:label,modelName:'transfer',args});
  console.log(JSON.stringify({label,args,result,elapsedMs:performance.now()-started,assessment:'BLOCKED: transfer not registered; downstream behavior NOT verified'}));
  if (result.code!=='TOOL_NOT_FOUND') throw new Error('Unexpected probe result; re-evaluate');
  store.close();
}
console.log('A08 local registry source: platform.ts registers order.get_status and ticket.create only; no transfer, precheck or canonical_target.');
console.log('A09 independent existing utility (not transfer end-to-end):',JSON.stringify(redact({nested:[{from:'ACC-A-123456',email:'alice@example.com',api_key:'dummy-test-value'}]})));
console.log('A03 approved high amounts; A04 approval not consumed; A05 approved full balance; A06 approved missing target; A07 approved tenant cases; A09 transfer audit; A10 original engine: NOT VERIFIED, required implementation absent. No fake approvals or replacement framework inserted.');
