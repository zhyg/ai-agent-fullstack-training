import { mkdtempSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it, vi } from "vitest";
import { Type } from "typebox";
import { loadEnvFiles, type PlatformConfig } from "../../src/config.js";
import type { ExecutionContext, ManagedTool } from "../../src/domain.js";
import { ToolRuntimeError } from "../../src/domain.js";
import { PolicyEngine } from "../../src/policy.js";
import { ToolRegistry } from "../../src/registry.js";
import { ToolRuntime } from "../../src/runtime.js";
import { PlatformStore } from "../../src/store.js";
import { renderSystemPrompt } from "../../src/pi/prompt-client.js";
import { runManagedAgent } from "../../src/pi/agent-runner.js";
import type { Platform } from "../../src/platform.js";
import { createOrderTool } from "../../src/tools/order.js";

function context(roles: string[] = ["support"], mode: "plan" | "execute" = "execute"): ExecutionContext {
  return {
    traceId: `trace-${roles.join("-")}`,
    requestId: "request-runtime",
    userId: "user-1",
    tenantId: "tenant_a",
    roles,
    agentName: "support-agent",
    mode,
  };
}

function createHarness(tools: ManagedTool[]) {
  const registry = new ToolRegistry();
  tools.forEach((tool) => registry.register(tool));
  const policy = new PolicyEngine({
    rolePermissions: {
      support: ["order:read"],
      supervisor: ["order:read", "ticket:create", "coffee:order"],
    },
    agentToolAllowlist: {
      "support-agent": tools.map((tool) => tool.metadata.internalName),
    },
    resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
  });
  const directory = mkdtempSync(join(tmpdir(), "pi-runtime-test-"));
  const store = new PlatformStore(join(directory, "platform.db"));
  const runtime = new ToolRuntime(registry, policy, store);
  return { registry, policy, store, runtime };
}

describe("ToolRuntime public invocation seam", () => {
  it("denies RBAC and plan mode before a write side effect", async () => {
    let writes = 0;
    const ticket = ticketTool(async () => {
      writes += 1;
      return { ticket_id: "T-1" };
    });
    const { runtime } = createHarness([ticket]);

    const rbacDenied = await runtime.invoke({
      context: context(["support"]),
      toolCallId: "call-rbac",
      modelName: "ticket__create",
      args: { order_id: "ORD-A-1001", title: "Need help" },
    });
    expect(rbacDenied).toMatchObject({ ok: false, action: "deny", code: "RBAC_DENIED" });

    const planDenied = await runtime.invoke({
      context: context(["supervisor"], "plan"),
      toolCallId: "call-plan",
      modelName: "ticket__create",
      args: { order_id: "ORD-A-1001", title: "Need help" },
    });
    expect(planDenied).toMatchObject({ ok: false, action: "deny", code: "PLAN_MODE_DENIED" });
    expect(writes).toBe(0);
  });

  it("enforces tenant order prefixes on internal order tools without blocking Luckin MCP order_id", async () => {
    const coffeeRead: ManagedTool = {
      metadata: {
        internalName: "mcp.my-coffee.get_order_detail",
        description: "Query Luckin order",
        version: "mcp",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["coffee:order"],
        requiresConfirmation: false,
        timeoutMs: 1_000,
        maxRetries: 0,
        idempotent: true,
        source: "mcp",
      },
      async handler({ args }) {
        return { luckin_order: args.order_id, status: "paid" };
      },
    };
    const orderRead: ManagedTool = {
      metadata: {
        internalName: "order.get_status",
        description: "Read tenant order",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["order:read"],
        requiresConfirmation: false,
        timeoutMs: 1_000,
        maxRetries: 0,
        idempotent: true,
        source: "python",
      },
      async handler() {
        return { status: "shipped" };
      },
    };
    const { runtime } = createHarness([coffeeRead, orderRead]);

    const crossTenant = await runtime.invoke({
      context: context(["supervisor"]),
      toolCallId: "call-scope-deny",
      modelName: "order__get_status",
      args: { order_id: "ORD-B-1001" },
    });
    expect(crossTenant).toMatchObject({ ok: false, action: "deny", code: "RESOURCE_SCOPE_DENIED" });

    const luckin = await runtime.invoke({
      context: context(["supervisor"]),
      toolCallId: "call-luckin",
      modelName: "mcp__my-coffee__get_order_detail",
      args: { order_id: "LK202611160001" },
    });
    expect(luckin).toMatchObject({ ok: true, code: "OK", content: { luckin_order: "LK202611160001", status: "paid" } });
  });

  it("binds approval to exact arguments and consumes it once", async () => {
    let writes = 0;
    const ticket = ticketTool(async () => {
      writes += 1;
      return { ticket_id: "T-1" };
    });
    const { runtime, store } = createHarness([ticket]);
    const args = { order_id: "ORD-A-1001", title: "Need help" };
    const pending = await runtime.invoke({
      context: context(["supervisor"]),
      toolCallId: "call-approval",
      modelName: "ticket__create",
      args,
    });
    expect(pending).toMatchObject({ ok: false, action: "confirm", code: "APPROVAL_REQUIRED" });
    expect(pending.approvalId).toBeTruthy();
    store.decideApproval(pending.approvalId!, "approve", "manager-1");

    const changed = await runtime.executeApproval(pending.approvalId!, {
      order_id: "ORD-A-1001",
      title: "Changed after approval",
    });
    expect(changed.code).toBe("APPROVAL_BINDING_MISMATCH");
    expect(writes).toBe(0);

    const executed = await runtime.executeApproval(pending.approvalId!, args);
    expect(executed).toMatchObject({ ok: true, action: "allow", code: "OK" });
    expect(writes).toBe(1);

    const repeated = await runtime.executeApproval(pending.approvalId!, args);
    expect(repeated.code).toBe("APPROVAL_NOT_EXECUTABLE");
    expect(writes).toBe(1);
    expect(runtime.pendingApproval(context(["supervisor"]).traceId)).toBeUndefined();
  });

  it("retries a transient read with fallback and never retries a non-idempotent write", async () => {
    let reads = 0;
    const readTool: ManagedTool = {
      metadata: {
        internalName: "order.get_status",
        description: "Read an order",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["order:read"],
        requiresConfirmation: false,
        timeoutMs: 1_000,
        maxRetries: 2,
        idempotent: true,
        source: "local",
      },
      async handler() {
        reads += 1;
        if (reads === 1) throw new ToolRuntimeError("UPSTREAM_UNAVAILABLE", "temporary", true);
        return { status: "paid" };
      },
    };
    let writes = 0;
    const unsafeWrite = ticketTool(async () => {
      writes += 1;
      throw new ToolRuntimeError("UPSTREAM_UNAVAILABLE", "temporary", true);
    });
    unsafeWrite.metadata.requiresConfirmation = false;
    const { runtime } = createHarness([readTool, unsafeWrite]);

    const read = await runtime.invoke({
      context: context(["support"]),
      toolCallId: "call-read-retry",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1001" },
    });
    const write = await runtime.invoke({
      context: context(["supervisor"]),
      toolCallId: "call-write-no-retry",
      modelName: "ticket__create",
      args: { order_id: "ORD-A-1001", title: "Need help" },
    });

    expect(read).toMatchObject({ ok: true, attempts: 2 });
    expect(reads).toBe(2);
    expect(write).toMatchObject({ ok: false, code: "UPSTREAM_UNAVAILABLE", attempts: 1 });
    expect(writes).toBe(1);
  });

  it("redacts model output and keeps trace/audit correlation", async () => {
    const readTool: ManagedTool = {
      metadata: {
        internalName: "order.get_status",
        description: "Read an order",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["order:read"],
        requiresConfirmation: false,
        timeoutMs: 1_000,
        maxRetries: 0,
        idempotent: true,
        source: "local",
        sensitiveFields: ["customer_email", "access_token"],
      },
      async handler() {
        return {
          status: "paid",
          customer_email: "alice@example.com",
          access_token: "secret-token",
          note: "contact bob@example.com with Bearer tok_12345",
        };
      },
    };
    const { runtime, store } = createHarness([readTool]);
    const result = await runtime.invoke({
      context: context(),
      toolCallId: "call-redact",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1001" },
    });

    expect(result.content).toEqual({
      status: "paid",
      customer_email: "***",
      access_token: "***",
      note: "contact ***@*** with Bearer ***",
    });
    const audit = store.listAudit(context().traceId);
    expect(JSON.stringify(audit)).not.toContain("alice@example.com");
    expect(JSON.stringify(audit)).not.toContain("bob@example.com");
    expect(JSON.stringify(audit)).not.toContain("tok_12345");
    expect(JSON.stringify(audit)).not.toContain("secret-token");
    expect(store.getTrace(context().traceId).every((event) => event.trace_id === context().traceId)).toBe(true);
  });

  it("enforces the deadline even when a handler ignores AbortSignal", async () => {
    const slowTool: ManagedTool = {
      metadata: {
        internalName: "order.slow_status",
        description: "Never completes in time",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["order:read"],
        requiresConfirmation: false,
        timeoutMs: 15,
        maxRetries: 0,
        idempotent: true,
        source: "local",
      },
      async handler() {
        await new Promise((resolve) => setTimeout(resolve, 250));
        return { status: "too-late" };
      },
    };
    const { runtime } = createHarness([slowTool]);
    const started = Date.now();
    const result = await runtime.invoke({
      context: context(),
      toolCallId: "call-hard-timeout",
      modelName: "order__slow_status",
      args: { order_id: "ORD-A-1001" },
    });

    expect(result).toMatchObject({ ok: false, code: "TOOL_TIMEOUT" });
    expect(Date.now() - started).toBeLessThan(150);
  });

  it("never retries a write tool on timeout even if misconfigured as idempotent", async () => {
    let calls = 0;
    const flakyWrite: ManagedTool = {
      metadata: {
        internalName: "ticket.create_slow",
        description: "Simulates a write that times out",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "write",
        permissions: ["ticket:create"],
        requiresConfirmation: false,
        timeoutMs: 15,
        maxRetries: 3,
        idempotent: true,
        source: "local",
      },
      async handler() {
        calls += 1;
        await new Promise((resolve) => setTimeout(resolve, 250));
        return { created: true };
      },
    };
    const { runtime } = createHarness([flakyWrite]);
    const result = await runtime.invoke({
      context: context(["supervisor"]),
      toolCallId: "call-write-timeout-no-retry",
      modelName: "ticket__create_slow",
      args: { order_id: "ORD-A-1001" },
    });

    expect(calls).toBe(1);
    expect(result).toMatchObject({ ok: false, code: "TOOL_TIMEOUT", attempts: 1 });
  });

  it("renders prompt from Phase-1 Gateway messages format", async () => {
    process.env.TEST_GW_KEY = "gw-secret";
    const originalFetch = globalThis.fetch;
    globalThis.fetch = vi.fn(async () =>
      new Response(
        JSON.stringify({
          messages: [
            { role: "system", content: "你是 support-agent，用户 user-1" },
            { role: "user", content: "render" },
          ],
          model: "agent-default",
          output_schema: null,
        }),
        { status: 200, headers: { "content-type": "application/json" } },
      ),
    ) as typeof fetch;

    try {
      const fakeConfig = {
        gateway: {
          baseUrl: "http://127.0.0.1:8003/v1",
          apiKeyEnv: "TEST_GW_KEY",
          promptName: "agent.default",
          promptVersion: 2,
        },
      } as PlatformConfig;
      const rendered = await renderSystemPrompt(fakeConfig, context());
      expect(rendered.prompt).toBe("你是 support-agent，用户 user-1");
      expect(rendered.version).toBe(2);
      expect(rendered.contentHash).toHaveLength(64);
    } finally {
      globalThis.fetch = originalFetch;
      delete process.env.TEST_GW_KEY;
    }
  });

  it("sends strictly whitelisted chat payloads from pi and stops loop on APPROVAL_REQUIRED", async () => {
    const allowedKeys = new Set([
      "model",
      "stream",
      "temperature",
      "top_p",
      "tools",
      "tool_choice",
      "prompt",
      "messages",
      "max_tokens",
      "max_completion_tokens",
      "response_format",
      "stream_options",
    ]);
    const seenBodies: Record<string, unknown>[] = [];
    const server = createServer(async (req, res) => {
      const chunks: Buffer[] = [];
      for await (const chunk of req) chunks.push(Buffer.from(chunk));
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8")) as Record<string, unknown>;
      if (req.url === "/v1/prompts/agent.default/render") {
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify({ messages: [{ role: "system", content: "你是受控助手" }] }));
        return;
      }
      if (req.url === "/v1/chat/completions") {
        seenBodies.push(body);
        const disallowed = Object.keys(body).filter((k) => !allowedKeys.has(k));
        if (disallowed.length > 0) {
          res.writeHead(400, { "content-type": "application/json" });
          res.end(JSON.stringify({ error: { code: "unsupported_parameter", disallowed } }));
          return;
        }
        res.writeHead(200, { "content-type": "text/event-stream" });
        const sse = [
          {
            id: "chat_1",
            choices: [
              {
                index: 0,
                delta: {
                  tool_calls: [
                    {
                      index: 0,
                      id: "call_coffee_1",
                      type: "function",
                      function: { name: "mcp__my-coffee__create_order", arguments: '{"item":"iced_americano"}' },
                    },
                  ],
                },
              },
            ],
          },
          { id: "chat_1", choices: [{ index: 0, delta: {}, finish_reason: "tool_calls" }] },
          { id: "chat_1", choices: [], usage: { prompt_tokens: 10, completion_tokens: 5 } },
        ]
          .map((item) => `data: ${JSON.stringify(item)}\n\n`)
          .join("");
        res.end(`${sse}data: [DONE]\n\n`);
        return;
      }
      res.writeHead(404).end();
    });

    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
    const address = server.address() as { port: number };
    process.env.TEST_PI_GW_KEY = "gw-test-key";

    let coffeeCalls = 0;
    const coffeeCreate: ManagedTool = {
      metadata: {
        internalName: "mcp.my-coffee.create_order",
        description: "Create Luckin coffee order",
        version: "mcp",
        parameters: Type.Object({ item: Type.String() }, { additionalProperties: false }),
        risk: "high",
        permissions: ["coffee:order"],
        requiresConfirmation: true,
        timeoutMs: 1_000,
        maxRetries: 0,
        idempotent: false,
        source: "mcp",
      },
      async handler() {
        coffeeCalls += 1;
        return { order_no: "LK-1" };
      },
    };
    const { registry, store, runtime } = createHarness([coffeeCreate]);
    const policy = new PolicyEngine({
      rolePermissions: { supervisor: ["coffee:order"] },
      agentToolAllowlist: { "support-agent": ["mcp.my-coffee.*"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const config: PlatformConfig = {
      gateway: {
        baseUrl: `http://127.0.0.1:${address.port}/v1`,
        apiKeyEnv: "TEST_PI_GW_KEY",
        promptName: "agent.default",
        promptVersion: 2,
      },
      model: {
        providerId: "phase-gateway",
        id: "agent-default",
        name: "DeepSeek via Phase-One Gateway",
        contextWindow: 131072,
        maxTokens: 4096,
        inputPerMillion: 0.44,
        outputPerMillion: 1.32,
        cacheReadPerMillion: 0.014,
      },
      runtime: {
        database: ":memory:",
        maxTurns: 4,
        maxToolCalls: 4,
        maxRepeatedCall: 2,
        maxTotalTokens: 10_000,
        maxCostUsd: 1,
        maxDurationMs: 30_000,
      },
      approvalApi: { host: "127.0.0.1", port: 0, apiKeyEnv: "APPROVAL_API_KEY" },
      policy: {
        rolePermissions: { supervisor: ["coffee:order"] },
        agentToolAllowlist: { "support-agent": ["mcp.my-coffee.*"] },
        resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
      },
      tools: { orderServiceUrl: "http://127.0.0.1:8004/internal/tools/order.get_status", orderSchema: "" },
      mcpServers: [],
    };
    const platform: Platform = {
      config,
      store,
      registry,
      policy,
      runtime,
      async close() {
        store.close();
      },
    };

    try {
      const outcome = await runManagedAgent(platform, {
        prompt: "帮我点一杯冰美式",
        userId: "u1",
        tenantId: "tenant_a",
        roles: ["supervisor"],
      });
      expect(seenBodies).toHaveLength(1);
      expect(seenBodies[0]).not.toHaveProperty("store");
      expect(seenBodies[0]).toHaveProperty("max_tokens", 4096);
      expect(outcome.stop.code).toBe("AWAITING_APPROVAL");
      expect(outcome.pending_approval_id).toBeTruthy();
      expect(coffeeCalls).toBe(0);
    } finally {
      delete process.env.TEST_PI_GW_KEY;
      await platform.close();
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  });

  it("runManagedAgent surfaces upstream gateway errors instead of returning CONTINUE with empty answer", async () => {
    const server = createServer(async (req, res) => {
      if (req.url === "/v1/prompts/agent.default/render") {
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify({ messages: [{ role: "system", content: "你是受控助手" }] }));
        return;
      }
      if (req.url === "/v1/chat/completions") {
        res.writeHead(502, { "content-type": "application/json" });
        res.end(
          JSON.stringify({
            error: {
              code: "upstream_network_error",
              message: "上游网络失败",
              stage: "upstream",
            },
          }),
        );
        return;
      }
      res.writeHead(404).end();
    });

    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
    const address = server.address() as { port: number };
    process.env.TEST_PI_GW_KEY = "gw-test-key";

    const { registry, store, runtime } = createHarness([]);
    const policy = new PolicyEngine({
      rolePermissions: { supervisor: ["order:read"] },
      agentToolAllowlist: { "support-agent": ["order.*"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const config: PlatformConfig = {
      gateway: {
        baseUrl: `http://127.0.0.1:${address.port}/v1`,
        apiKeyEnv: "TEST_PI_GW_KEY",
        promptName: "agent.default",
        promptVersion: 2,
      },
      model: {
        providerId: "phase-gateway",
        id: "agent-default",
        name: "DeepSeek via Phase-One Gateway",
        contextWindow: 131072,
        maxTokens: 4096,
        inputPerMillion: 0.44,
        outputPerMillion: 1.32,
        cacheReadPerMillion: 0.014,
      },
      runtime: {
        database: ":memory:",
        maxTurns: 4,
        maxToolCalls: 4,
        maxRepeatedCall: 2,
        maxTotalTokens: 10_000,
        maxCostUsd: 1,
        maxDurationMs: 30_000,
      },
      approvalApi: { host: "127.0.0.1", port: 0, apiKeyEnv: "APPROVAL_API_KEY" },
      policy: {
        rolePermissions: { supervisor: ["order:read"] },
        agentToolAllowlist: { "support-agent": ["order.*"] },
        resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
      },
      tools: { orderServiceUrl: "http://127.0.0.1:8004/internal/tools/order.get_status", orderSchema: "" },
      mcpServers: [],
    };
    const platform: Platform = {
      config,
      store,
      registry,
      policy,
      runtime,
      async close() {
        store.close();
      },
    };

    try {
      const outcome = await runManagedAgent(platform, {
        prompt: "帮我查订单",
        userId: "u1",
        tenantId: "tenant_a",
        roles: ["supervisor"],
      });
      expect(outcome.final_answer).toBe("");
      expect(outcome.stop.stop).toBe(true);
      expect(outcome.stop.code).toBe("LLM_ERROR");
      expect(outcome.stop.reason).toContain("502");
      expect(outcome.error).toContain("502");
      const traces = store.getTrace(outcome.trace_id);
      const payloads = traces
        .filter((event) => event.event_type === "pi.message_end")
        .map((event) => JSON.parse(String(event.payload_json)) as { role?: string; stop_reason?: string; error_message?: string });
      const assistantEnd = payloads.find((payload) => payload.role === "assistant");
      expect(assistantEnd?.stop_reason).toBe("error");
      expect(assistantEnd?.error_message).toContain("502");
    } finally {
      delete process.env.TEST_PI_GW_KEY;
      await platform.close();
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  });

  it("maps non-idempotent write timeouts to TIMEOUT_UNKNOWN with unknown audit status", async () => {
    let calls = 0;
    const slowCreate: ManagedTool = {
      metadata: {
        internalName: "mcp.my-coffee.createOrder",
        description: "Create coffee order",
        version: "mcp",
        parameters: Type.Object({ deptId: Type.Integer() }, { additionalProperties: false }),
        risk: "high",
        permissions: ["coffee:order"],
        requiresConfirmation: true,
        timeoutMs: 25,
        maxRetries: 0,
        idempotent: false,
        source: "mcp",
      },
      async handler() {
        calls += 1;
        await new Promise((resolve) => setTimeout(resolve, 80));
        return { orderId: "LK-SLOW" };
      },
    };
    const store = new PlatformStore(":memory:");
    const policy = new PolicyEngine({
      rolePermissions: { supervisor: ["coffee:order"] },
      agentToolAllowlist: { "support-agent": ["mcp.my-coffee.*"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const registry = new ToolRegistry();
    registry.register(slowCreate);
    const governedRuntime = new ToolRuntime(registry, policy, store);
    const ctx = context(["supervisor"]);
    const first = await governedRuntime.invoke({
      context: ctx,
      toolCallId: "call-timeout-unknown",
      modelName: "mcp__my-coffee__createOrder",
      args: { deptId: 612691 },
    });
    expect(first.code).toBe("APPROVAL_REQUIRED");
    store.decideApproval(first.approvalId!, "approve", "owner");
    const result = await governedRuntime.executeApproval(first.approvalId!);

    expect(calls).toBe(1);
    expect(result.ok).toBe(false);
    expect(result.code).toBe("TIMEOUT_UNKNOWN");
    const audits = store.listAudit(ctx.traceId);
    expect(audits.some((row) => row.status === "unknown" && row.code === "TIMEOUT_UNKNOWN")).toBe(true);
    expect(store.getApproval(first.approvalId!)?.status).toBe("failed");
    store.close();
  });

  it("preserves business success on post-execution audit failure and blocks high-risk tools if audit is unavailable beforehand", async () => {
    let executed = 0;
    const writeTool = ticketTool(async () => {
      executed += 1;
      return { ticket_id: "T-POST-AUDIT", mobile: "13812345678" };
    });
    const { store, runtime } = createHarness([writeTool]);
    const ctx = context(["supervisor"]);
    const confirm = await runtime.invoke({
      context: ctx,
      toolCallId: "call-audit-resilience",
      modelName: "ticket__create",
      args: { order_id: "ORD-A-1001", title: "测试审计降级" },
    });
    store.decideApproval(confirm.approvalId!, "approve", "owner");

    // Simulate audit write failure AFTER the handler will succeed.
    store.addAudit = () => {
      throw new Error("disk full");
    };
    const result = await runtime.executeApproval(confirm.approvalId!);
    expect(executed).toBe(1);
    expect(result.ok).toBe(true);
    expect(result.auditWarning).toContain("AUDIT_WRITE_FAILED");
    expect(result.content).toEqual({ ticket_id: "T-POST-AUDIT", mobile: "***" });

    // High-risk side effect must fail closed BEFORE execution if audit store is unhealthy.
    let highRiskCalls = 0;
    const highTool: ManagedTool = {
      metadata: {
        internalName: "mcp.my-coffee.cancelOrder",
        description: "Cancel coffee order",
        version: "mcp",
        parameters: Type.Object({ orderId: Type.String() }, { additionalProperties: false }),
        risk: "high",
        permissions: ["coffee:order"],
        requiresConfirmation: false,
        timeoutMs: 1_000,
        maxRetries: 0,
        idempotent: false,
        source: "mcp",
      },
      async handler() {
        highRiskCalls += 1;
        return { cancelled: true };
      },
    };
    const reg = new ToolRegistry();
    reg.register(highTool);
    const closedStore = new PlatformStore(":memory:");
    const highPolicy = new PolicyEngine({
      rolePermissions: { supervisor: ["coffee:order"] },
      agentToolAllowlist: { "support-agent": ["mcp.my-coffee.*"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const blockedRuntime = new ToolRuntime(reg, highPolicy, closedStore);
    closedStore.close();

    const blocked = await blockedRuntime.invoke({
      context: ctx,
      toolCallId: "call-audit-down",
      modelName: "mcp__my-coffee__cancelOrder",
      args: { orderId: "LK-1" },
    });
    expect(highRiskCalls).toBe(0);
    expect(blocked.ok).toBe(false);
    expect(blocked.code).toBe("AUDIT_UNAVAILABLE");
    store.close();
  });

  it("enforces Run snapshot isolation, emergency tool disablement, run deadline clamping, and mobile masking", async () => {
    let calls = 0;
    const readTool: ManagedTool = {
      metadata: {
        internalName: "order.get_status",
        description: "Read order",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["order:read"],
        requiresConfirmation: false,
        timeoutMs: 5_000,
        maxRetries: 0,
        idempotent: true,
        source: "local",
      },
      async handler() {
        calls += 1;
        return { phone_note: "联系 13812345678", status: "shipped" };
      },
    };
    const { registry, policy, store, runtime } = createHarness([readTool]);
    const ctx = context(["support"]);
    const snapshot = registry.createSnapshot(ctx, policy);

    // Tool registered AFTER snapshot creation must not be callable inside that snapshot.
    registry.register({
      ...readTool,
      metadata: { ...readTool.metadata, internalName: "order.extra" },
    });
    const outOfSnapshot = await runtime.invoke({
      context: ctx,
      toolCallId: "call-out-of-snap",
      modelName: "order__extra",
      args: { order_id: "ORD-A-1001" },
      snapshot,
    });
    expect(outOfSnapshot.ok).toBe(false);
    expect(outOfSnapshot.code).toBe("TOOL_NOT_IN_SNAPSHOT");

    // In-snapshot call succeeds and masks phone numbers.
    const okRes = await runtime.invoke({
      context: ctx,
      toolCallId: "call-snap-ok",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1001" },
      snapshot,
      deadlineAtMs: Date.now() + 2_000,
    });
    expect(okRes.ok).toBe(true);
    expect(okRes.content).toEqual({ phone_note: "联系 138****5678", status: "shipped" });

    // Expired run deadline stops before running handler.
    const expiredRes = await runtime.invoke({
      context: ctx,
      toolCallId: "call-expired-deadline",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1001" },
      snapshot,
      deadlineAtMs: Date.now() - 10,
    });
    expect(expiredRes.ok).toBe(false);
    expect(expiredRes.code).toBe("MAX_DURATION");
    expect(calls).toBe(1);

    // Dynamic emergency disablement blocks tool even if present in snapshot.
    policy.disableTool("order.get_status");
    const disabledRes = await runtime.invoke({
      context: ctx,
      toolCallId: "call-disabled",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1001" },
      snapshot,
    });
    expect(disabledRes.ok).toBe(false);
    expect(disabledRes.code).toBe("TOOL_DISABLED");
    expect(calls).toBe(1);
    store.close();
  });

  it("samples bounded exponential backoff within [cap*0.5, cap] across success, fallback, and non-retryable failure", async () => {
    const waits: number[] = [];
    let attemptIndex = 0;
    const readTool: ManagedTool = {
      metadata: {
        internalName: "order.get_status",
        description: "Read order",
        version: "1.0.0",
        parameters: Type.Object({ order_id: Type.String() }, { additionalProperties: false }),
        risk: "read",
        permissions: ["order:read"],
        requiresConfirmation: false,
        timeoutMs: 1_000,
        maxRetries: 2,
        idempotent: true,
        source: "python",
      },
      async handler({ args }) {
        attemptIndex += 1;
        if (args.order_id === "ORD-A-1001" && attemptIndex < 3) {
          throw new ToolRuntimeError("ORDER_SERVICE_UNAVAILABLE", "503", true);
        }
        if (args.order_id === "ORD-A-1002") {
          throw new ToolRuntimeError("ORDER_SERVICE_UNAVAILABLE", "still down", true);
        }
        if (args.order_id === "ORD-A-1003") {
          throw new ToolRuntimeError("ORDER_LOOKUP_FAILED", "auth denied", false);
        }
        return { order_id: args.order_id, status: "shipped" };
      },
      async fallbackHandler({ args }) {
        return { order_id: args.order_id, status: "unknown", source: "fallback-cache" };
      },
    };
    const registry = new ToolRegistry();
    registry.register(readTool);
    const policy = new PolicyEngine({
      rolePermissions: { support: ["order:read"] },
      agentToolAllowlist: { "support-agent": ["order.get_status"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const store = new PlatformStore(":memory:");
    const runtime = new ToolRuntime(registry, policy, store, async (ms) => {
      waits.push(ms);
    });
    const ctx = context(["support"]);

    // 1) Transient errors then success: 2 waits bounded by caps 25ms and 50ms.
    const okRes = await runtime.invoke({
      context: ctx,
      toolCallId: "call-backoff-ok",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1001" },
    });
    expect(okRes.ok).toBe(true);
    expect(okRes.attempts).toBe(3);
    expect(waits).toHaveLength(2);
    expect(waits[0]).toBeGreaterThanOrEqual(12.5);
    expect(waits[0]).toBeLessThanOrEqual(25);
    expect(waits[1]).toBeGreaterThanOrEqual(25);
    expect(waits[1]).toBeLessThanOrEqual(50);
    expect(okRes.backoffWaitsMs).toEqual(waits);

    // 2) Persistent transient error exhausts retries and triggers fallback.
    waits.length = 0;
    const fallbackRes = await runtime.invoke({
      context: ctx,
      toolCallId: "call-backoff-fallback",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1002" },
    });
    expect(fallbackRes.ok).toBe(true);
    expect(fallbackRes.code).toBe("FALLBACK_OK");
    expect(fallbackRes.attempts).toBe(3);
    expect(waits).toHaveLength(2);

    // 3) Non-retryable error never retries or sleeps.
    waits.length = 0;
    const authRes = await runtime.invoke({
      context: ctx,
      toolCallId: "call-backoff-nonretry",
      modelName: "order__get_status",
      args: { order_id: "ORD-A-1003" },
    });
    expect(authRes.ok).toBe(false);
    expect(authRes.code).toBe("ORDER_LOOKUP_FAILED");
    expect(authRes.attempts).toBe(1);
    expect(waits).toHaveLength(0);
    store.close();
  });

  it("wraps fetch network failures in createOrderTool as retryable and rejects expired approvals", async () => {
    const dir = mkdtempSync(join(tmpdir(), "pi-order-tool-"));
    const schemaPath = join(dir, "order.json");
    writeFileSync(
      schemaPath,
      JSON.stringify({
        type: "object",
        properties: { order_id: { type: "string" } },
        required: ["order_id"],
        additionalProperties: false,
      }),
    );
    process.env.TEST_ORDER_KEY = "order-secret";
    const originalFetch = globalThis.fetch;
    let fetchCalls = 0;
    globalThis.fetch = vi.fn(async () => {
      fetchCalls += 1;
      throw new TypeError("fetch failed: ECONNREFUSED");
    }) as typeof fetch;

    try {
      const orderTool = createOrderTool({
        gateway: { apiKeyEnv: "TEST_ORDER_KEY" },
        tools: { orderServiceUrl: "http://127.0.0.1:1/internal/tools/order.get_status", orderSchema: schemaPath },
      } as PlatformConfig);
      const { store, runtime } = createHarness([orderTool]);
      const res = await runtime.invoke({
        context: context(["support"]),
        toolCallId: "call-fetch-down",
        modelName: "order__get_status",
        args: { order_id: "ORD-A-1001" },
      });
      expect(fetchCalls).toBe(3);
      expect(res.ok).toBe(true);
      expect(res.code).toBe("FALLBACK_OK");
      expect(res.content).toMatchObject({ order_id: "ORD-A-1001", status: "unknown", source: "fallback-cache" });

      // Expired approval TTL is rejected without calling handler.
      const approval = store.createApproval({
        context: context(["supervisor"]),
        toolCallId: "call-expired",
        toolName: "ticket__create",
        args: { order_id: "ORD-A-1001", title: "过期测试" },
        ttlSeconds: -1,
      });
      expect(() => store.decideApproval(approval.id, "approve", "owner")).toThrow(/expired/i);
      store.close();
    } finally {
      globalThis.fetch = originalFetch;
      delete process.env.TEST_ORDER_KEY;
    }
  });

  it("loads .env files cleanly without overriding explicit process environment variables", () => {
    const dir = mkdtempSync(join(tmpdir(), "pi-env-load-"));
    const primaryEnv = join(dir, "primary.env");
    const fallbackEnv = join(dir, "fallback.env");
    writeFileSync(primaryEnv, "TEST_LOAD_ENV_A=from_primary\nTEST_LOAD_ENV_PRESET=from_file\n");
    writeFileSync(fallbackEnv, "TEST_LOAD_ENV_A=from_fallback\nTEST_LOAD_ENV_B='quoted_val'\n");
    process.env.TEST_LOAD_ENV_PRESET = "explicit_process_value";
    try {
      loadEnvFiles([primaryEnv, fallbackEnv]);
      expect(process.env.TEST_LOAD_ENV_A).toBe("from_primary");
      expect(process.env.TEST_LOAD_ENV_B).toBe("quoted_val");
      expect(process.env.TEST_LOAD_ENV_PRESET).toBe("explicit_process_value");
    } finally {
      delete process.env.TEST_LOAD_ENV_A;
      delete process.env.TEST_LOAD_ENV_B;
      delete process.env.TEST_LOAD_ENV_PRESET;
    }
  });
});

function ticketTool(handler: ManagedTool["handler"]): ManagedTool {
  return {
    metadata: {
      internalName: "ticket.create",
      description: "Create a support ticket",
      version: "1.0.0",
      parameters: Type.Object(
        { order_id: Type.String(), title: Type.String({ minLength: 3 }) },
        { additionalProperties: false },
      ),
      risk: "write",
      permissions: ["ticket:create"],
      requiresConfirmation: true,
      timeoutMs: 1_000,
      maxRetries: 2,
      idempotent: false,
      source: "local",
      executionMode: "sequential",
    },
    handler,
  };
}
