import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, describe, expect, it } from "vitest";
import { loadConfig } from "../../src/config.js";
import type { ExecutionContext } from "../../src/domain.js";
import { McpAdapterPlugin } from "../../src/mcp/adapter.js";
import { PolicyEngine } from "../../src/policy.js";
import { ToolRegistry } from "../../src/registry.js";
import { ToolRuntime } from "../../src/runtime.js";
import { PlatformStore } from "../../src/store.js";

const adapter = new McpAdapterPlugin([
  {
    id: "demo",
    type: "stdio",
    command: process.execPath,
    args: ["--import", "tsx", "src/mcp/demo-server.ts"],
    trust: "trusted",
    defaultRisk: "read",
    permissions: ["knowledge:read"],
  },
]);

afterAll(async () => {
  await adapter.close();
});

describe("MCP adapter public seam", () => {
  it("discovers a remote tool and executes it through ToolRuntime", async () => {
    const registry = new ToolRegistry();
    await adapter.attach(registry);
    const policy = new PolicyEngine({
      rolePermissions: { support: ["knowledge:read"] },
      agentToolAllowlist: { "support-agent": ["mcp.demo.knowledge_search"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const directory = mkdtempSync(join(tmpdir(), "pi-mcp-test-"));
    const store = new PlatformStore(join(directory, "platform.db"));
    const runtime = new ToolRuntime(registry, policy, store);
    const context: ExecutionContext = {
      traceId: "trace-mcp",
      requestId: "request-mcp",
      userId: "user-1",
      tenantId: "tenant_a",
      roles: ["support"],
      agentName: "support-agent",
      mode: "execute",
    };

    const result = await runtime.invoke({
      context,
      toolCallId: "call-mcp",
      modelName: "mcp__demo__knowledge_search",
      args: { query: "退款处理" },
    });

    expect(result.ok).toBe(true);
    expect(JSON.stringify(result.content)).toContain("人工确认");
    expect(store.listAudit("trace-mcp")).toHaveLength(1);
    store.close();
  });

  it("loads Luckin MCP governance rules from platform.yaml with read/write separation and fail-closed defaults", () => {
    const config = loadConfig("../config/platform.yaml");
    const myCoffee = config.mcpServers.find((server) => server.id === "my-coffee");
    expect(myCoffee).toBeDefined();
    expect(myCoffee?.defaultRisk).toBe("high");
    expect(myCoffee?.readOnlyPermissions).toEqual(["coffee:read"]);
    expect(myCoffee?.readOnlyTools).toEqual(
      expect.arrayContaining([
        "queryShopList",
        "searchProductForMcp",
        "queryProductDetailInfo",
        "switchProduct",
        "previewOrder",
        "queryOrderDetailInfo",
      ]),
    );
    expect(myCoffee?.toolPolicies?.createOrder).toMatchObject({
      risk: "high",
      requiresConfirmation: true,
      idempotent: false,
      timeoutMs: 20_000,
    });
    expect(config.policy.rolePermissions.support).toContain("coffee:read");
    expect(config.policy.rolePermissions.support).not.toContain("coffee:order");
    expect(config.policy.rolePermissions.supervisor).toContain("coffee:order");
  });

  it("parses JSON text MCP envelopes, propagates tool errors, and requires approval for unknown/write tools", async () => {
    const inlineServerScript = `
      import { Server } from "@modelcontextprotocol/sdk/server/index.js";
      import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
      import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
      const server = new Server({ name: "coffee-sim", version: "1.0.0" }, { capabilities: { tools: {} } });
      server.setRequestHandler(ListToolsRequestSchema, async () => ({
        tools: [
          {
            name: "queryShopList",
            description: "Query shops",
            inputSchema: { type: "object", properties: { longitude: { type: "number" } }, required: ["longitude"], returnDirect: false }
          },
          {
            name: "createOrder",
            description: "Create order",
            inputSchema: { type: "object", properties: { deptId: { type: "integer" } }, required: ["deptId"], returnDirect: false }
          },
          {
            name: "unexpectedRemoteTool",
            description: "Unlisted tool must fail closed",
            inputSchema: { type: "object", properties: {} }
          }
        ]
      }));
      server.setRequestHandler(CallToolRequestSchema, async (req) => {
        if (req.params.name === "queryShopList") {
          return { content: [{ type: "text", text: JSON.stringify({ code: 0, msg: "success", data: [{ deptId: 612691, mobile: "13812345678" }] }) }] };
        }
        return { isError: true, content: [{ type: "text", text: "shop closed" }] };
      });
      await server.connect(new StdioServerTransport());
    `;
    const coffeeSim = new McpAdapterPlugin([
      {
        id: "my-coffee",
        type: "stdio",
        command: process.execPath,
        args: ["--input-type=module", "-e", inlineServerScript],
        trust: "trusted",
        defaultRisk: "high",
        permissions: ["coffee:order"],
        readOnlyPermissions: ["coffee:read"],
        readOnlyTools: ["queryShopList"],
        toolPolicies: {
          createOrder: {
            risk: "high",
            permissions: ["coffee:order"],
            requiresConfirmation: true,
            idempotent: false,
            timeoutMs: 20_000,
          },
        },
      },
    ]);
    const registry = new ToolRegistry();
    await coffeeSim.attach(registry);
    const directory = mkdtempSync(join(tmpdir(), "pi-coffee-sim-"));
    const store = new PlatformStore(join(directory, "platform.db"));
    const policy = new PolicyEngine({
      rolePermissions: { support: ["coffee:read"], supervisor: ["coffee:read", "coffee:order"] },
      agentToolAllowlist: { "support-agent": ["mcp.my-coffee.*"] },
      resourceTenantPrefixes: { tenant_a: ["ORD-A-"] },
    });
    const runtime = new ToolRuntime(registry, policy, store);
    try {
      const supportCtx: ExecutionContext = {
        traceId: "trace-coffee-sim",
        requestId: "req-1",
        userId: "u1",
        tenantId: "tenant_a",
        roles: ["support"],
        agentName: "support-agent",
        mode: "execute",
      };
      // Read tool works without approval for support role and strips returnDirect / parses JSON / redacts mobile.
      const shopTool = registry.get("mcp.my-coffee.queryShopList");
      expect(shopTool.metadata.parameters).not.toHaveProperty("returnDirect");
      const shopRes = await runtime.invoke({
        context: supportCtx,
        toolCallId: "call-shop",
        modelName: "mcp__my-coffee__queryShopList",
        args: { longitude: 116.397 },
      });
      expect(shopRes.ok).toBe(true);
      expect(shopRes.content).toEqual({
        code: 0,
        msg: "success",
        data: [{ deptId: 612691, mobile: "***" }],
        server_id: "my-coffee",
      });

      // support role is denied on createOrder (RBAC_DENIED).
      const deniedCreate = await runtime.invoke({
        context: supportCtx,
        toolCallId: "call-create-denied",
        modelName: "mcp__my-coffee__createOrder",
        args: { deptId: 612691 },
      });
      expect(deniedCreate.ok).toBe(false);
      expect(deniedCreate.code).toBe("RBAC_DENIED");

      // Unknown unlisted MCP tool fails closed as high-risk requiring confirmation for supervisor.
      const supervisorCtx = { ...supportCtx, roles: ["supervisor"] };
      const unlisted = await runtime.invoke({
        context: supervisorCtx,
        toolCallId: "call-unlisted",
        modelName: "mcp__my-coffee__unexpectedRemoteTool",
        args: {},
      });
      expect(unlisted.ok).toBe(false);
      expect(unlisted.code).toBe("APPROVAL_REQUIRED");

      // Approved createOrder that returns isError propagates MCP_TOOL_ERROR cleanly.
      const pendingCreate = await runtime.invoke({
        context: supervisorCtx,
        toolCallId: "call-create-err",
        modelName: "mcp__my-coffee__createOrder",
        args: { deptId: 612691 },
      });
      expect(pendingCreate.code).toBe("APPROVAL_REQUIRED");
      store.decideApproval(pendingCreate.approvalId!, "approve", "owner");
      const errExec = await runtime.executeApproval(pendingCreate.approvalId!);
      expect(errExec.ok).toBe(false);
      expect(errExec.code).toBe("MCP_TOOL_ERROR");
      expect(errExec.content).toBe("shop closed");
    } finally {
      await coffeeSim.close();
      store.close();
    }
  });
});
