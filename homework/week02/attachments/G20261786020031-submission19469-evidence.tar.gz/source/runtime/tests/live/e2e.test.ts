import { describe, expect, it } from "vitest";
import { loadConfig } from "../../src/config.js";
import { buildPlatform } from "../../src/platform.js";
import { runManagedAgent } from "../../src/pi/agent-runner.js";

describe("Live Gateway + my-coffee Luckin MCP acceptance", () => {
  it("requires LUCKIN_MCP_TOKEN and discovers real my-coffee MCP tools with read/high split", async () => {
    loadConfig("../config/platform.yaml");
    if (!process.env.LUCKIN_MCP_TOKEN) {
      throw new Error("LIVE_PRECONDITION_FAILED: 请设置 LUCKIN_MCP_TOKEN 后再运行真实瑞幸 MCP 验收");
    }
    const platform = await buildPlatform({ configPath: "../config/platform.yaml", connectMcp: true });
    try {
      const mcpTools = platform.registry.list().filter((t) => t.metadata.internalName.startsWith("mcp.my-coffee."));
      expect(mcpTools.length).toBeGreaterThanOrEqual(8);
      const shopTool = platform.registry.get("mcp.my-coffee.queryShopList");
      const createTool = platform.registry.get("mcp.my-coffee.createOrder");
      expect(shopTool.metadata.risk).toBe("read");
      expect(shopTool.metadata.requiresConfirmation).toBe(false);
      expect(createTool.metadata.risk).toBe("high");
      expect(createTool.metadata.requiresConfirmation).toBe(true);
    } finally {
      await platform.close();
    }
  }, 30_000);

  it("runs a real Gateway + pi agent loop for internal order status and plan mode denial", async () => {
    loadConfig("../config/platform.yaml");
    if (!process.env.GATEWAY_API_KEY) {
      throw new Error("LIVE_PRECONDITION_FAILED: 请设置 GATEWAY_API_KEY 后再运行真实 Gateway 验收");
    }
    const platform = await buildPlatform({ configPath: "../config/platform.yaml", connectMcp: Boolean(process.env.LUCKIN_MCP_TOKEN) });
    try {
      const orderResult = await runManagedAgent(platform, {
        prompt: "查询订单 ORD-A-1001 的状态。",
        userId: "trainer-1",
        tenantId: "tenant_a",
        roles: ["supervisor"],
      });
      expect(orderResult.final_answer.length).toBeGreaterThan(0);

      const planResult = await runManagedAgent(platform, {
        prompt: "帮我给 ORD-A-1001 建一个工单，标题是包装破损",
        userId: "trainer-1",
        tenantId: "tenant_a",
        roles: ["supervisor"],
        mode: "plan",
      });
      const audits = platform.store.listAudit(planResult.trace_id);
      expect(audits.every((row) => row.status !== "success")).toBe(true);
    } finally {
      await platform.close();
    }
  }, 60_000);
});
