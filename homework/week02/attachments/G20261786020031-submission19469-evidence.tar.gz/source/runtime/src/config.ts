import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { parse } from "yaml";
import type { PolicyConfig } from "./domain.js";
import type { LoopBudgetConfig } from "./loop-guard.js";
import type { McpServerConfig, McpToolPolicyOverride } from "./mcp/adapter.js";

export interface PlatformConfig {
  gateway: {
    baseUrl: string;
    apiKeyEnv: string;
    promptName: string;
    promptVersion: number;
  };
  model: {
    providerId: string;
    id: string;
    name: string;
    contextWindow: number;
    maxTokens: number;
    inputPerMillion: number;
    outputPerMillion: number;
    cacheReadPerMillion: number;
  };
  runtime: LoopBudgetConfig & { database: string };
  approvalApi: { host: string; port: number; apiKeyEnv: string };
  policy: PolicyConfig;
  tools: { orderServiceUrl: string; orderSchema: string };
  mcpServers: McpServerConfig[];
}

export function loadConfig(path = process.env.PLATFORM_CONFIG ?? "../config/platform.yaml"): PlatformConfig {
  const absolutePath = resolve(path);
  const directory = dirname(absolutePath);
  loadEnvFiles([resolve(directory, "../.env"), resolve(directory, "../../.env")]);
  const raw = parse(readFileSync(absolutePath, "utf8")) as any;
  const rawPromptVersion = raw.gateway.prompt_version;
  const promptVersion =
    typeof rawPromptVersion === "number"
      ? rawPromptVersion
      : Number(String(rawPromptVersion ?? "1").replace(/^v/i, ""));

  return {
    gateway: {
      baseUrl: process.env.GATEWAY_BASE_URL ?? raw.gateway.base_url,
      apiKeyEnv: raw.gateway.api_key_env,
      promptName: raw.gateway.prompt_name,
      promptVersion,
    },
    model: {
      providerId: raw.model.provider_id,
      id: raw.model.id,
      name: raw.model.name,
      contextWindow: raw.model.context_window,
      maxTokens: raw.model.max_tokens,
      inputPerMillion: raw.model.input_per_million,
      outputPerMillion: raw.model.output_per_million,
      cacheReadPerMillion: raw.model.cache_read_per_million,
    },
    runtime: {
      database: resolve(directory, raw.runtime.database),
      maxTurns: raw.runtime.max_turns,
      maxToolCalls: raw.runtime.max_tool_calls,
      maxRepeatedCall: raw.runtime.max_repeated_call,
      maxTotalTokens: raw.runtime.max_total_tokens,
      maxCostUsd: raw.runtime.max_cost_usd,
      maxDurationMs: raw.runtime.max_duration_ms,
    },
    approvalApi: {
      host: raw.approval_api.host,
      port: raw.approval_api.port,
      apiKeyEnv: raw.approval_api.api_key_env,
    },
    policy: {
      rolePermissions: raw.policy.role_permissions,
      agentToolAllowlist: raw.policy.agent_tool_allowlist,
      resourceTenantPrefixes: raw.policy.resource_tenant_prefixes,
    },
    tools: {
      orderServiceUrl: process.env.ORDER_SERVICE_URL ?? raw.tools.order_service_url,
      orderSchema: resolve(directory, raw.tools.order_schema),
    },
    mcpServers: (raw.mcp_servers ?? []).map((server: any): McpServerConfig => {
      const common = {
        id: server.id,
        trust: server.trust,
        defaultRisk: server.default_risk,
        permissions: server.permissions ?? [],
        readOnlyTools: server.read_only_tools ?? [],
        readOnlyPermissions: server.read_only_permissions,
        toolPolicies: mapToolPolicies(server.tool_policies),
        timeoutMs: server.timeout_ms,
        maxResultChars: server.max_result_chars,
      };
      if (server.type === "streamablehttp") {
        return {
          ...common,
          type: "streamablehttp",
          url: server.url,
          headers: server.headers ?? {},
        };
      }
      return {
        ...common,
        type: "stdio",
        command: server.command,
        args: server.args ?? [],
        cwd: server.cwd ? resolve(directory, server.cwd) : undefined,
      };
    }),
  };
}

function mapToolPolicies(rawPolicies: any): Record<string, McpToolPolicyOverride> | undefined {
  if (!rawPolicies || typeof rawPolicies !== "object") return undefined;
  return Object.fromEntries(
    Object.entries(rawPolicies).map(([toolName, policy]: [string, any]) => [
      toolName,
      {
        risk: policy.risk,
        permissions: policy.permissions,
        requiresConfirmation: policy.requires_confirmation,
        timeoutMs: policy.timeout_ms,
        maxRetries: policy.max_retries,
        idempotent: policy.idempotent,
        sensitiveFields: policy.sensitive_fields,
        executionMode: policy.execution_mode,
      },
    ]),
  );
}

export function loadEnvFiles(paths: string[]): void {
  for (const envPath of paths) {
    if (!existsSync(envPath)) continue;
    const content = readFileSync(envPath, "utf8");
    for (const rawLine of content.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) continue;
      const cleaned = line.startsWith("export ") ? line.slice(7).trim() : line;
      const eqIndex = cleaned.indexOf("=");
      if (eqIndex <= 0) continue;
      const key = cleaned.slice(0, eqIndex).trim();
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
      let value = cleaned.slice(eqIndex + 1).trim();
      if (
        (value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))
      ) {
        value = value.slice(1, -1);
      }
      if (!process.env[key]) {
        process.env[key] = value;
      }
    }
  }
}
