import { createHash } from "node:crypto";
import type { ExecutionContext } from "../domain.js";
import type { PlatformConfig } from "../config.js";

export async function renderSystemPrompt(config: PlatformConfig, context: ExecutionContext): Promise<{
  prompt: string;
  version: number;
  contentHash: string;
}> {
  const apiKey = process.env[config.gateway.apiKeyEnv];
  if (!apiKey) throw new Error(`Missing ${config.gateway.apiKeyEnv}`);
  const base = config.gateway.baseUrl.replace(/\/$/, "").replace(/\/v1$/, "");
  const response = await fetch(`${base}/v1/prompts/${encodeURIComponent(config.gateway.promptName)}/render`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      version: config.gateway.promptVersion,
      variables: {
        tenant_id: context.tenantId,
        user_id: context.userId,
        agent_name: context.agentName,
      },
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(
      `Prompt Registry returned ${response.status} (请确认已在 Gateway 注册模板 ${config.gateway.promptName}): ${body}`,
    );
  }
  const payload = (await response.json()) as {
    prompt?: string;
    version?: number | string;
    content_hash?: string;
    messages?: Array<{ role?: string; content?: string }>;
  };
  const prompt =
    payload.prompt ??
    payload.messages?.find((item) => item.role === "system")?.content ??
    "";
  if (!prompt) {
    throw new Error(`Prompt ${config.gateway.promptName} 渲染结果缺少 system 提示词`);
  }
  const contentHash =
    payload.content_hash ??
    createHash("sha256").update(prompt).digest("hex");
  const version =
    typeof payload.version === "number"
      ? payload.version
      : config.gateway.promptVersion;
  return { prompt, version, contentHash };
}
