import { randomUUID } from "node:crypto";
import { runAgentLoop, type AgentEvent, type AgentTool } from "@earendil-works/pi-agent-core";
import type { AssistantMessage, Message, UserMessage } from "@earendil-works/pi-ai";
import { LoopGuard } from "../loop-guard.js";
import type { Platform } from "../platform.js";
import { executionContext } from "../platform.js";
import { createGatewayModels } from "./provider.js";
import { renderSystemPrompt } from "./prompt-client.js";

export interface RunAgentInput {
  prompt: string;
  userId: string;
  tenantId: string;
  roles: string[];
  agentName?: string;
  mode?: "plan" | "execute";
  history?: Message[];
  onMessages?: (messages: Message[]) => void;
  onText?: (delta: string) => void;
}

export async function runManagedAgent(platform: Platform, input: RunAgentInput) {
  const traceId = randomUUID();
  const context = executionContext({
    traceId,
    requestId: randomUUID(),
    userId: input.userId,
    tenantId: input.tenantId,
    roles: input.roles,
    agentName: input.agentName,
    mode: input.mode,
  });
  const promptBundle = await renderSystemPrompt(platform.config, context);
  const { models, model } = createGatewayModels(platform.config);
  const guard = new LoopGuard(platform.config.runtime);
  const snapshot = platform.registry.createSnapshot(context, platform.policy);
  const tools = snapshot.tools.map<AgentTool>((tool) => ({
    name: tool.modelName,
    label: tool.metadata.internalName,
    description: tool.metadata.description,
    parameters: tool.metadata.parameters,
    executionMode: tool.metadata.executionMode,
    async execute(toolCallId, args) {
      const result = await platform.runtime.executePreparedById(
        context,
        toolCallId,
        tool.modelName,
        args as Record<string, unknown>,
        { snapshot, deadlineAtMs: guard.deadlineAtMs },
      );
      if (!result.ok) throw new Error(`${result.code}: ${String(result.content)}`);
      return {
        content: [{ type: "text", text: JSON.stringify(result.content) }],
        details: {
          code: result.code,
          attempts: result.attempts,
          governed: true,
          snapshot_id: snapshot.id,
          ...(result.auditWarning ? { audit_warning: result.auditWarning } : {}),
        },
      };
    },
  }));

  const userMessage: UserMessage = { role: "user", content: input.prompt, timestamp: Date.now() };
  let stop = { stop: false, code: "CONTINUE", reason: "预算允许继续" };

  const messages = await runAgentLoop(
    [userMessage],
    { systemPrompt: promptBundle.prompt, messages: input.history ?? [], tools },
    {
      model,
      convertToLlm: (items) => items.filter(isLlmMessage),
      reasoning: undefined,
      maxTokens: platform.config.model.maxTokens,
      beforeToolCall: async ({ toolCall, args }) => {
        const guardDecision = guard.beforeToolCall(toolCall.name, args as Record<string, unknown>);
        if (!guardDecision.allow) {
          platform.runtime.recordPiImmediateFailure({
            context,
            toolCallId: toolCall.id,
            modelName: toolCall.name,
            args: args as Record<string, unknown>,
            message: `${guardDecision.code}: ${guardDecision.reason}`,
          });
          return { block: true, reason: `${guardDecision.code}: ${guardDecision.reason}` };
        }
        const decision = platform.runtime.beforePiCall({
          context,
          toolCallId: toolCall.id,
          modelName: toolCall.name,
          args: args as Record<string, unknown>,
          snapshot,
          deadlineAtMs: guard.deadlineAtMs,
        });
        return decision.block ? { block: true, reason: decision.reason } : undefined;
      },
      afterToolCall: async ({ result, isError }) => ({
        details: { ...asRecord(result.details), governed: true, trace_id: traceId },
        isError,
      }),
      shouldStopAfterTurn: async () => {
        stop = guard.shouldStop(platform.runtime.pendingApproval(traceId));
        return stop.stop;
      },
    },
    async (event) => observeEvent(platform, context, guard, event, input.onText),
    undefined,
    (targetModel, targetContext, streamOptions) =>
      models.streamSimple(targetModel, targetContext, { ...streamOptions, maxRetries: 0 }),
  );

  input.onMessages?.(messages.filter(isLlmMessage));
  const lastAssistant = [...messages].reverse().find((message): message is AssistantMessage => message.role === "assistant");
  const assistantFailed = lastAssistant?.stopReason === "error" || lastAssistant?.stopReason === "aborted";
  const assistantError = assistantFailed ? lastAssistant.errorMessage || "模型调用失败" : undefined;
  if (assistantFailed && !stop.stop) {
    stop = {
      stop: true,
      code: lastAssistant.stopReason === "aborted" ? "LLM_ABORTED" : "LLM_ERROR",
      reason: assistantError ?? "模型调用失败",
    };
  }
  const finalAnswer = lastAssistant?.content
    .filter((part) => part.type === "text")
    .map((part) => part.text)
    .join("") ?? "";
  return {
    trace_id: traceId,
    snapshot_id: snapshot.id,
    prompt_version: promptBundle.version,
    prompt_hash: promptBundle.contentHash,
    final_answer: finalAnswer,
    ...(assistantError ? { error: assistantError } : {}),
    stop,
    pending_approval_id: platform.runtime.pendingApproval(traceId),
    budget: guard.snapshot(),
    message_count: messages.length,
  };
}

async function observeEvent(
  platform: Platform,
  context: ReturnType<typeof executionContext>,
  guard: LoopGuard,
  event: AgentEvent,
  onText?: (delta: string) => void,
): Promise<void> {
  if (event.type === "message_update" && event.assistantMessageEvent.type === "text_delta") {
    onText?.(event.assistantMessageEvent.delta);
  }
  if (event.type === "message_end" && event.message.role === "assistant") {
    guard.observeAssistantUsage({
      totalTokens: event.message.usage?.totalTokens ?? 0,
      costUsd: event.message.usage?.cost?.total ?? 0,
    });
  }
  if (event.type === "turn_end") guard.observeTurn();
  if (event.type === "tool_execution_end" && event.isError && !platform.runtime.wasAudited(event.toolCallId)) {
    platform.runtime.recordPiImmediateFailure({
      context,
      toolCallId: event.toolCallId,
      modelName: event.toolName,
      args: {},
      message: event.result.content
        .map((part: { type: string; text?: string }) => (part.type === "text" ? part.text ?? "" : "[image]"))
        .join("\n"),
    });
  }
  platform.store.addTrace({
    traceId: context.traceId,
    eventType: `pi.${event.type}`,
    payload: summarizeEvent(event),
  });
}

function summarizeEvent(event: AgentEvent): Record<string, unknown> {
  if (event.type === "tool_execution_start" || event.type === "tool_execution_end") {
    return { tool_call_id: event.toolCallId, tool_name: event.toolName, is_error: "isError" in event ? event.isError : false };
  }
  if (event.type === "turn_end") return { tool_result_count: event.toolResults.length };
  if (event.type === "message_end") {
    if (event.message.role === "assistant" && (event.message.stopReason === "error" || event.message.stopReason === "aborted")) {
      return {
        role: event.message.role,
        stop_reason: event.message.stopReason,
        error_message: event.message.errorMessage ?? "模型调用失败",
      };
    }
    return { role: event.message.role };
  }
  return { type: event.type };
}

function isLlmMessage(message: any): message is Message {
  return message.role === "user" || message.role === "assistant" || message.role === "toolResult";
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : {};
}
