#!/usr/bin/env node
import { randomUUID } from "node:crypto";
import { createInterface } from "node:readline/promises";
import type { Message } from "@earendil-works/pi-ai";
import { Command } from "commander";
import { buildPlatform, executionContext } from "./platform.js";
import { runManagedAgent } from "./pi/agent-runner.js";

const program = new Command();
program.name("agent-runtime").description("pi 0.84.4 Agent Tool Runtime CLI").version("2.0.0");
program.option("--config <path>", "平台配置文件", process.env.PLATFORM_CONFIG ?? "../config/platform.yaml");

program
  .command("tools")
  .description("发现并列出模型当前可见的工具")
  .option("--without-mcp", "不连接正式 MCP 服务器")
  .action(async (options) => {
    await withPlatform(!options.withoutMcp, async (platform) => {
      const context = defaultContext();
      print(platform.registry.snapshot(context, platform.policy).map((tool) => ({
        internal_name: tool.metadata.internalName,
        model_name: tool.modelName,
        risk: tool.metadata.risk,
        permissions: tool.metadata.permissions,
        idempotent: tool.metadata.idempotent,
        timeout_ms: tool.metadata.timeoutMs,
        source: tool.metadata.source,
        requires_confirmation: tool.metadata.requiresConfirmation,
      })));
    });
  });

program
  .command("agent")
  .description("使用真实 Gateway/DeepSeek 运行受治理的 pi Agent Loop")
  .argument("<prompt>", "用户任务")
  .option("--user-id <id>", "用户 ID", "trainer-1")
  .option("--tenant-id <id>", "租户 ID", "tenant_a")
  .option("--roles <roles>", "逗号分隔角色", "supervisor")
  .option("--mode <mode>", "plan 或 execute", "execute")
  .option("--without-mcp", "不连接正式 MCP 服务器")
  .action(async (prompt, options) => {
    await withPlatform(!options.withoutMcp, async (platform) => {
      const result = await runManagedAgent(platform, {
        prompt,
        userId: options.userId,
        tenantId: options.tenantId,
        roles: splitList(options.roles),
        mode: options.mode,
        onText: (delta) => process.stdout.write(delta),
      });
      const approvalRecord = result.pending_approval_id
        ? platform.store.getApproval(result.pending_approval_id)
        : undefined;
      const auditRecords = platform.store.listAudit(result.trace_id).map(formatAuditRow);
      const traceEvents = platform.store
        .getTrace(result.trace_id)
        .filter((event) => event.event_type !== "pi.message_update")
        .map(formatTraceRow);
      process.stdout.write("\n");
      print({
        ...result,
        ...(approvalRecord
          ? {
              pending_approval: {
                id: approvalRecord.id,
                tool_name: approvalRecord.tool_name,
                args: safeParseJson(approvalRecord.args_json),
                expires_at: approvalRecord.expires_at,
                next_commands: [
                  `npm run cli -- approvals decide ${approvalRecord.id} --decision approve --actor owner`,
                  `npm run cli -- approvals execute ${approvalRecord.id}`,
                ],
              },
            }
          : {}),
        audit_records: auditRecords,
        trace_events: traceEvents,
      });
    });
  });

program
  .command("chat")
  .description("多轮交互模式（保留上下文，并可在终端直接确认执行待审批动作）")
  .option("--user-id <id>", "用户 ID", "trainer-1")
  .option("--tenant-id <id>", "租户 ID", "tenant_a")
  .option("--roles <roles>", "逗号分隔角色", "supervisor")
  .option("--mode <mode>", "plan 或 execute", "execute")
  .option("--actor <actor>", "审批人", process.env.USER ?? "owner")
  .option("--without-mcp", "不连接正式 MCP 服务器")
  .action(async (options) => {
    await withPlatform(!options.withoutMcp, async (platform) => {
      const rl = createInterface({ input: process.stdin, output: process.stdout });
      let history: Message[] = [];
      process.stdout.write("已进入多轮交互模式（输入 exit / quit 退出）。\n");
      try {
        while (true) {
          const line = (await rl.question("\n你> ")).trim();
          if (!line) continue;
          if (line === "exit" || line === "quit") break;

          process.stdout.write("助手> ");
          const result = await runManagedAgent(platform, {
            prompt: line,
            userId: options.userId,
            tenantId: options.tenantId,
            roles: splitList(options.roles),
            mode: options.mode,
            history,
            onMessages: (msgs) => {
              history = msgs;
            },
            onText: (delta) => process.stdout.write(delta),
          });
          process.stdout.write("\n");
          if (result.error) {
            process.stdout.write(`[错误] ${result.stop.code}: ${result.error}\n`);
          }

          const audits = platform.store.listAudit(result.trace_id).map(formatAuditRow);
          if (audits.length > 0) {
            process.stdout.write(`[审计记录] ${JSON.stringify(audits)}\n`);
          }

          if (result.pending_approval_id) {
            const approval = platform.store.getApproval(result.pending_approval_id);
            if (approval) {
              process.stdout.write(
                `\n[待人工审批] id=${approval.id} tool=${approval.tool_name} args=${approval.args_json}\n`,
              );
              const answer = (await rl.question("是否批准并立即执行？(y 批准执行 / n 拒绝 / 其他跳过): "))
                .trim()
                .toLowerCase();
              if (answer === "y" || answer === "yes") {
                platform.store.decideApproval(approval.id, "approve", options.actor);
                const execResult = await platform.runtime.executeApproval(approval.id);
                print({ approval_execution: execResult });
                history = history.map((msg) =>
                  msg.role === "toolResult" && msg.toolCallId === approval.tool_call_id
                    ? {
                        ...msg,
                        content: [{ type: "text", text: JSON.stringify(execResult.content) }],
                        isError: !execResult.ok,
                      }
                    : msg,
                );
              } else if (answer === "n" || answer === "no") {
                platform.store.decideApproval(approval.id, "reject", options.actor);
                process.stdout.write(`[已拒绝审批] ${approval.id}\n`);
              } else {
                process.stdout.write(
                  `[已跳过] 稍后可执行:\n  npm run cli -- approvals decide ${approval.id} --decision approve --actor ${options.actor}\n  npm run cli -- approvals execute ${approval.id}\n`,
                );
              }
            }
          }
        }
      } finally {
        rl.close();
      }
    });
  });

const approvals = program.command("approvals").description("查看与处理持久化审批");
approvals
  .command("list")
  .option("--status <status>", "按状态过滤", "pending")
  .action(async (options) => {
    await withPlatform(false, async (platform) => print(platform.store.listApprovals(options.status)));
  });
approvals
  .command("decide")
  .argument("<approval-id>")
  .requiredOption("--decision <decision>", "approve 或 reject")
  .option("--actor <actor>", "审批人", process.env.USER ?? "operator")
  .action(async (id, options) => {
    if (options.decision !== "approve" && options.decision !== "reject") {
      throw new Error("--decision 只能是 approve 或 reject");
    }
    await withPlatform(false, async (platform) => {
      print(platform.store.decideApproval(id, options.decision, options.actor));
    });
  });
approvals
  .command("execute")
  .argument("<approval-id>")
  .option("--without-mcp", "审批目标不是 MCP 工具时可跳过远端连接")
  .action(async (id, options) => {
    await withPlatform(!options.withoutMcp, async (platform) => print(await platform.runtime.executeApproval(id)));
  });

program
  .command("audit")
  .description("查看持久化的工具调用审计日志")
  .option("--trace-id <traceId>", "按 trace_id 过滤")
  .option("--limit <n>", "最多显示条数", "20")
  .action(async (options) => {
    await withPlatform(false, async (platform) => {
      const limit = Math.max(1, Number.parseInt(options.limit, 10) || 20);
      print(platform.store.listAudit(options.traceId).slice(0, limit).map(formatAuditRow));
    });
  });

program
  .command("trace")
  .description("查看一次 Agent Run 的 Trace")
  .argument("<trace-id>")
  .option("--raw", "包含流式 pi.message_update 事件")
  .action(async (traceId, options) => {
    await withPlatform(false, async (platform) => {
      const rows = platform.store.getTrace(traceId);
      const filtered = options.raw ? rows : rows.filter((event) => event.event_type !== "pi.message_update");
      print(filtered.map(formatTraceRow));
    });
  });

program
  .command("invoke")
  .description("绕过模型但不绕过 Runtime，便于确定性验收")
  .argument("<model-tool-name>")
  .argument("<json-args>")
  .option("--with-mcp", "连接正式 MCP 服务器")
  .action(async (modelName, rawArgs, options) => {
    await withPlatform(Boolean(options.withMcp), async (platform) => {
      const result = await platform.runtime.invoke({
        context: defaultContext(),
        toolCallId: randomUUID(),
        modelName,
        args: parseObject(rawArgs),
      });
      print(result);
    });
  });

await program.parseAsync();

function defaultContext() {
  return executionContext({
    traceId: randomUUID(),
    requestId: randomUUID(),
    userId: "trainer-1",
    tenantId: "tenant_a",
    roles: ["supervisor"],
  });
}

async function withPlatform(connectMcp: boolean, work: (platform: Awaited<ReturnType<typeof buildPlatform>>) => Promise<void>) {
  const platform = await buildPlatform({ configPath: program.opts().config, connectMcp });
  try {
    await work(platform);
  } finally {
    await platform.close();
  }
}

function splitList(value: string): string[] {
  return value.split(",").map((item) => item.trim()).filter(Boolean);
}

function parseObject(value: string): Record<string, unknown> {
  const parsed = JSON.parse(value);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("参数必须是 JSON 对象");
  return parsed;
}

function print(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function formatAuditRow(row: Record<string, unknown>): Record<string, unknown> {
  return {
    id: row.id,
    event_type: row.event_type,
    trace_id: row.trace_id,
    tool_call_id: row.tool_call_id,
    tool_name: row.tool_name,
    user_id: row.user_id,
    tenant_id: row.tenant_id,
    status: row.status,
    code: row.code,
    input: safeParseJson(row.input_json),
    output: safeParseJson(row.output_json),
    latency_ms: row.latency_ms,
    created_at: row.created_at,
  };
}

function formatTraceRow(row: Record<string, unknown>): Record<string, unknown> {
  return {
    id: row.id,
    trace_id: row.trace_id,
    event_type: row.event_type,
    payload: safeParseJson(row.payload_json),
    created_at: row.created_at,
  };
}

function safeParseJson(raw: unknown): unknown {
  if (typeof raw !== "string") return raw ?? null;
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}
