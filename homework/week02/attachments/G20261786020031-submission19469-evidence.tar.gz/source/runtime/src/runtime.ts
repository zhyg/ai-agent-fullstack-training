import { validateToolArguments } from "@earendil-works/pi-ai";
import type { Tool, ToolCall } from "@earendil-works/pi-ai";
import type {
  DecisionAction,
  ExecutionContext,
  RegisteredTool,
} from "./domain.js";
import { ToolRuntimeError } from "./domain.js";
import type { PolicyEngine } from "./policy.js";
import type { ToolRegistry, ToolSnapshot } from "./registry.js";
import { approvalDigest, canonicalJson, type PlatformStore } from "./store.js";

export interface InvokeRequest {
  context: ExecutionContext;
  toolCallId: string;
  modelName: string;
  args: Record<string, unknown>;
  snapshot?: ToolSnapshot;
  deadlineAtMs?: number;
}

export interface InvocationResult {
  ok: boolean;
  action: DecisionAction;
  code: string;
  content: unknown;
  attempts: number;
  approvalId?: string;
  auditWarning?: string;
  backoffWaitsMs?: number[];
}

interface PreparedCall extends InvokeRequest {
  tool: RegisteredTool;
  validatedArgs: Record<string, unknown>;
}

const GENERIC_SENSITIVE_KEYS = /(?:token|secret|password|api[_-]?key|authorization|cookie|session|mobile|user_?phone|customer_?phone)/i;

export class ToolRuntime {
  private readonly prepared = new Map<string, PreparedCall>();
  private readonly auditedCalls = new Set<string>();
  private readonly pendingApprovalByTrace = new Map<string, string>();

  constructor(
    private readonly registry: ToolRegistry,
    private readonly policy: PolicyEngine,
    private readonly store: PlatformStore,
    private readonly sleep: (ms: number) => Promise<void> = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
  ) {}

  async invoke(request: InvokeRequest): Promise<InvocationResult> {
    const prepared = this.prepare(request);
    if (!("tool" in prepared)) return prepared;
    return this.executePrepared(prepared);
  }

  beforePiCall(request: InvokeRequest): { block: boolean; reason?: string } {
    const prepared = this.prepare(request);
    if ("tool" in prepared) return { block: false };
    return {
      block: true,
      reason: JSON.stringify({
        code: prepared.code,
        message: prepared.content,
        approval_id: prepared.approvalId,
      }),
    };
  }

  prepare(request: InvokeRequest): PreparedCall | InvocationResult {
    let tool: RegisteredTool;
    try {
      tool = request.snapshot
        ? request.snapshot.getByModelName(request.modelName)
        : this.registry.getByModelName(request.modelName);
    } catch {
      return this.reject(
        request,
        request.snapshot ? "TOOL_NOT_IN_SNAPSHOT" : "TOOL_NOT_FOUND",
        request.snapshot ? "工具不在当前 Run 快照中" : "没有注册该工具",
      );
    }

    let validatedArgs: Record<string, unknown>;
    try {
      validatedArgs = validateToolArguments(
        toolToPi(tool),
        callToPi(request.toolCallId, request.modelName, request.args),
      ) as Record<string, unknown>;
    } catch (error) {
      return this.reject(
        request,
        "INVALID_ARGUMENT",
        error instanceof Error ? error.message : "参数校验失败",
      );
    }

    const decision = this.policy.evaluate(request.context, tool, validatedArgs);
    if (decision.action === "deny") return this.reject(request, decision.code, decision.reason, validatedArgs);
    if (tool.metadata.risk === "high") {
      try {
        this.store.checkHealth();
      } catch {
        return failure("AUDIT_UNAVAILABLE", "审计存储不可用，高风险动作拒绝执行");
      }
    }
    if (decision.action === "confirm") {
      const approval = this.store.createApproval({
        context: request.context,
        toolCallId: request.toolCallId,
        toolName: request.modelName,
        args: validatedArgs,
      });
      this.pendingApprovalByTrace.set(request.context.traceId, approval.id);
      this.store.addAudit({
        eventType: "policy_decision",
        context: request.context,
        toolCallId: request.toolCallId,
        toolName: tool.metadata.internalName,
        status: "confirm",
        code: decision.code,
        input: redact(validatedArgs, tool.metadata.sensitiveFields),
      });
      this.auditedCalls.add(request.toolCallId);
      this.store.addTrace({
        traceId: request.context.traceId,
        eventType: "tool.approval_requested",
        payload: { tool_call_id: request.toolCallId, tool_name: request.modelName, approval_id: approval.id },
      });
      return {
        ok: false,
        action: "confirm",
        code: decision.code,
        content: decision.reason,
        attempts: 0,
        approvalId: approval.id,
      };
    }

    const prepared: PreparedCall = { ...request, tool, validatedArgs };
    this.prepared.set(request.toolCallId, prepared);
    return prepared;
  }

  async executePreparedById(
    context: ExecutionContext,
    toolCallId: string,
    modelName: string,
    args: Record<string, unknown>,
    options: { snapshot?: ToolSnapshot; deadlineAtMs?: number } = {},
  ): Promise<InvocationResult> {
    const prepared = this.prepared.get(toolCallId);
    if (!prepared) {
      return this.invoke({
        context,
        toolCallId,
        modelName,
        args,
        snapshot: options.snapshot,
        deadlineAtMs: options.deadlineAtMs,
      });
    }
    this.prepared.delete(toolCallId);
    return this.executePrepared(prepared);
  }

  async executeApproval(id: string, suppliedArgs?: Record<string, unknown>): Promise<InvocationResult> {
    const approval = this.store.getApproval(id);
    if (!approval || approval.status !== "approved") {
      return failure("APPROVAL_NOT_EXECUTABLE", "审批不存在、已过期或已被消费");
    }
    const context = JSON.parse(approval.context_json) as ExecutionContext;
    const storedArgs = JSON.parse(approval.args_json) as Record<string, unknown>;
    const args = suppliedArgs ?? storedArgs;
    const expected = approvalDigest({
      traceId: approval.trace_id,
      toolCallId: approval.tool_call_id,
      toolName: approval.tool_name,
      context,
      args,
    });
    if (expected !== approval.args_digest || canonicalJson(args) !== canonicalJson(storedArgs)) {
      return failure("APPROVAL_BINDING_MISMATCH", "工具参数已变化，旧审批失效");
    }
    if (!this.store.claimApproval(id)) return failure("APPROVAL_NOT_EXECUTABLE", "审批已被其他执行者占用");

    let tool: RegisteredTool;
    let validatedArgs: Record<string, unknown>;
    try {
      tool = this.registry.getByModelName(approval.tool_name);
      validatedArgs = validateToolArguments(
        toolToPi(tool),
        callToPi(approval.tool_call_id, approval.tool_name, args),
      ) as Record<string, unknown>;
      const policy = this.policy.evaluate(context, tool, validatedArgs, { approvalSatisfied: true });
      if (policy.action !== "allow") {
        this.store.finishApproval(id, "failed", policy.code);
        return failure(policy.code, policy.reason);
      }
      if (tool.metadata.risk === "high") {
        this.store.checkHealth();
      }
    } catch (error) {
      const code = error instanceof Error && /database|sqlite/i.test(error.message) ? "AUDIT_UNAVAILABLE" : "INVALID_ARGUMENT";
      try {
        this.store.finishApproval(id, "failed", code);
      } catch {
        // Store unavailable; error still blocks execution before side effect.
      }
      return failure(code, error instanceof Error ? error.message : "参数校验失败");
    }

    const result = await this.executePrepared({
      context,
      toolCallId: approval.tool_call_id,
      modelName: approval.tool_name,
      args,
      tool,
      validatedArgs,
    });
    this.store.finishApproval(id, result.ok ? "consumed" : "failed", result.ok ? undefined : result.code);
    if (this.pendingApprovalByTrace.get(approval.trace_id) === id) {
      this.pendingApprovalByTrace.delete(approval.trace_id);
    }
    return result;
  }

  pendingApproval(traceId: string): string | undefined {
    return this.pendingApprovalByTrace.get(traceId);
  }

  wasAudited(toolCallId: string): boolean {
    return this.auditedCalls.has(toolCallId);
  }

  recordPiImmediateFailure(input: {
    context: ExecutionContext;
    toolCallId: string;
    modelName: string;
    args: Record<string, unknown>;
    message: string;
  }): void {
    if (this.wasAudited(input.toolCallId)) return;
    this.reject(
      {
        context: input.context,
        toolCallId: input.toolCallId,
        modelName: input.modelName,
        args: input.args,
      },
      "PI_PREFLIGHT_REJECTED",
      input.message,
    );
  }

  private reject(
    request: InvokeRequest,
    code: string,
    reason: string,
    validatedArgs: Record<string, unknown> = request.args,
  ): InvocationResult {
    let internalName = request.modelName;
    let sensitiveFields: string[] | undefined;
    try {
      const tool = this.registry.getByModelName(request.modelName);
      internalName = tool.metadata.internalName;
      sensitiveFields = tool.metadata.sensitiveFields;
    } catch {
      // Unknown calls still need an audit record.
    }
    this.store.addAudit({
      eventType: "policy_decision",
      context: request.context,
      toolCallId: request.toolCallId,
      toolName: internalName,
      status: "deny",
      code,
      input: redact(validatedArgs, sensitiveFields),
    });
    this.auditedCalls.add(request.toolCallId);
    this.store.addTrace({
      traceId: request.context.traceId,
      eventType: "tool.denied",
      payload: { tool_call_id: request.toolCallId, tool_name: request.modelName, code },
    });
    return { ok: false, action: "deny", code, content: reason, attempts: 0 };
  }

  private async executePrepared(prepared: PreparedCall): Promise<InvocationResult> {
    const startedAt = Date.now();
    const { tool } = prepared;
    const dynamicDecision = this.policy.evaluate(prepared.context, tool, prepared.validatedArgs, {
      approvalSatisfied: true,
    });
    if (dynamicDecision.action !== "allow") {
      return this.reject(prepared, dynamicDecision.code, dynamicDecision.reason, prepared.validatedArgs);
    }
    if (tool.metadata.risk === "high") {
      try {
        this.store.checkHealth();
      } catch {
        return failure("AUDIT_UNAVAILABLE", "审计存储不可用，高风险动作拒绝执行");
      }
    }

    const maxAttempts = tool.metadata.idempotent ? tool.metadata.maxRetries + 1 : 1;
    let lastError: unknown;
    let attemptsUsed = 0;
    const backoffWaitsMs: number[] = [];

    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      const attemptTimeoutMs = remainingAttemptTimeout(tool.metadata.timeoutMs, prepared.deadlineAtMs);
      if (attemptTimeoutMs <= 0) {
        lastError = new ToolRuntimeError("MAX_DURATION", "Agent Run 总时限已耗尽", false);
        break;
      }
      attemptsUsed = attempt;
      const timeoutController = new AbortController();
      let output: unknown;
      try {
        output = await runWithDeadline(
          () => tool.handler({
            toolCallId: prepared.toolCallId,
            args: prepared.validatedArgs,
            context: prepared.context,
            signal: timeoutController.signal,
          }),
          attemptTimeoutMs,
          timeoutController,
          tool.metadata.risk === "read",
        );
      } catch (error) {
        lastError = error;
        const retryable = lastError instanceof ToolRuntimeError && lastError.retryable;
        if (!retryable || attempt >= maxAttempts) break;
        const capMs = Math.min(25 * 2 ** (attempt - 1), 100);
        const jitteredMs = capMs * (0.5 + Math.random() * 0.5);
        const remainingAfterFailure = remainingAttemptTimeout(jitteredMs, prepared.deadlineAtMs);
        if (remainingAfterFailure <= 0) {
          lastError = new ToolRuntimeError("MAX_DURATION", "Agent Run 总时限已耗尽", false);
          break;
        }
        backoffWaitsMs.push(remainingAfterFailure);
        await this.sleep(remainingAfterFailure);
        continue;
      }
      return this.success(prepared, output, attempt, Date.now() - startedAt, "OK", backoffWaitsMs);
    }

    if (tool.fallbackHandler && lastError instanceof ToolRuntimeError && lastError.retryable) {
      const fallbackTimeoutMs = remainingAttemptTimeout(tool.metadata.timeoutMs, prepared.deadlineAtMs);
      if (fallbackTimeoutMs > 0) {
        let fallbackOutput: unknown;
        let fallbackSucceeded = false;
        try {
          const fallbackController = new AbortController();
          fallbackOutput = await runWithDeadline(
            () => tool.fallbackHandler!({
              toolCallId: prepared.toolCallId,
              args: prepared.validatedArgs,
              context: prepared.context,
              signal: fallbackController.signal,
            }),
            fallbackTimeoutMs,
            fallbackController,
            false,
          );
          fallbackSucceeded = true;
        } catch (fallbackError) {
          lastError = fallbackError;
        }
        if (fallbackSucceeded) {
          return this.success(prepared, fallbackOutput, attemptsUsed, Date.now() - startedAt, "FALLBACK_OK", backoffWaitsMs);
        }
      }
    }

    const rawCode = lastError instanceof ToolRuntimeError ? lastError.code : "TOOL_EXECUTION_FAILED";
    const isUnknownWrite =
      !tool.metadata.idempotent &&
      (rawCode === "TOOL_TIMEOUT" || (lastError instanceof ToolRuntimeError && lastError.unknownOutcome));
    const code = isUnknownWrite ? "TIMEOUT_UNKNOWN" : rawCode;
    const message = isUnknownWrite
      ? "写操作执行状态未知（超时或连接中断），严禁自动重试，请先查询状态对账"
      : lastError instanceof Error
        ? lastError.message
        : "工具执行失败";
    const auditStatus = isUnknownWrite ? "unknown" : "error";
    try {
      this.store.addAudit({
        eventType: "tool_execution",
        context: prepared.context,
        toolCallId: prepared.toolCallId,
        toolName: tool.metadata.internalName,
        status: auditStatus,
        code,
        input: redact(prepared.validatedArgs, tool.metadata.sensitiveFields),
        output: { message },
        latencyMs: Date.now() - startedAt,
      });
      this.auditedCalls.add(prepared.toolCallId);
      this.store.addTrace({
        traceId: prepared.context.traceId,
        eventType: isUnknownWrite ? "tool.unknown" : "tool.failed",
        payload: { tool_call_id: prepared.toolCallId, tool_name: tool.modelName, code },
      });
    } catch (auditError) {
      process.stderr.write(`[audit-alert] failed to record ${auditStatus} audit for ${prepared.toolCallId}: ${String(auditError)}\n`);
    }
    return {
      ok: false,
      action: "deny",
      code,
      content: message,
      attempts: attemptsUsed,
      ...(backoffWaitsMs.length > 0 ? { backoffWaitsMs } : {}),
    };
  }

  private success(
    prepared: PreparedCall,
    rawOutput: unknown,
    attempts: number,
    latencyMs: number,
    code = "OK",
    backoffWaitsMs: number[] = [],
  ): InvocationResult {
    const output = redact(rawOutput, prepared.tool.metadata.sensitiveFields);
    let auditWarning: string | undefined;
    try {
      this.store.addAudit({
        eventType: "tool_execution",
        context: prepared.context,
        toolCallId: prepared.toolCallId,
        toolName: prepared.tool.metadata.internalName,
        status: "success",
        code,
        input: redact(prepared.validatedArgs, prepared.tool.metadata.sensitiveFields),
        output,
        latencyMs,
      });
      this.auditedCalls.add(prepared.toolCallId);
      this.store.addTrace({
        traceId: prepared.context.traceId,
        eventType: "tool.completed",
        payload: {
          tool_call_id: prepared.toolCallId,
          tool_name: prepared.modelName,
          attempts,
          latency_ms: latencyMs,
          code,
        },
      });
    } catch (auditError) {
      auditWarning = `AUDIT_WRITE_FAILED: ${auditError instanceof Error ? auditError.message : String(auditError)}`;
      process.stderr.write(`[audit-alert] ${auditWarning} (tool_call_id=${prepared.toolCallId})\n`);
    }
    return {
      ok: true,
      action: "allow",
      code,
      content: output,
      attempts,
      ...(auditWarning ? { auditWarning } : {}),
      ...(backoffWaitsMs.length > 0 ? { backoffWaitsMs } : {}),
    };
  }
}

function remainingAttemptTimeout(configuredTimeoutMs: number, deadlineAtMs?: number): number {
  if (deadlineAtMs === undefined) return configuredTimeoutMs;
  return Math.min(configuredTimeoutMs, deadlineAtMs - Date.now());
}

async function runWithDeadline<T>(
  work: () => Promise<T>,
  timeoutMs: number,
  controller: AbortController,
  retryOnTimeout = true,
): Promise<T> {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  const deadline = new Promise<never>((_resolve, reject) => {
    timeout = setTimeout(() => {
      controller.abort();
      reject(new ToolRuntimeError("TOOL_TIMEOUT", "工具执行超时", retryOnTimeout));
    }, timeoutMs);
  });
  try {
    return await Promise.race([work(), deadline]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

function toolToPi(tool: RegisteredTool): Tool {
  return {
    name: tool.modelName,
    description: tool.metadata.description,
    parameters: tool.metadata.parameters,
  };
}

function callToPi(id: string, name: string, args: Record<string, unknown>): ToolCall {
  return { type: "toolCall", id, name, arguments: structuredClone(args) };
}

function failure(code: string, message: string): InvocationResult {
  return { ok: false, action: "deny", code, content: message, attempts: 0 };
}

const EMAIL_PATTERN = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
const BEARER_PATTERN = /\bBearer\s+[A-Za-z0-9._~+/=-]+/gi;
const MOBILE_PATTERN = /(?<!\d)(1[3-9]\d)\d{4}(\d{4})(?!\d)/g;

export function redact(value: unknown, configured: string[] = []): unknown {
  const sensitive = new Set(configured.map((item) => item.toLowerCase()));
  if (typeof value === "string") {
    return value
      .replace(EMAIL_PATTERN, "***@***")
      .replace(BEARER_PATTERN, "Bearer ***")
      .replace(MOBILE_PATTERN, "$1****$2");
  }
  if (Array.isArray(value)) return value.map((item) => redact(item, configured));
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, item]) => [
        key,
        sensitive.has(key.toLowerCase()) || GENERIC_SENSITIVE_KEYS.test(key) ? "***" : redact(item, configured),
      ]),
    );
  }
  return value;
}
