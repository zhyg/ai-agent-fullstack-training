import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import type { RiskLevel } from "../domain.js";
import { ToolRuntimeError } from "../domain.js";
import type { ToolRegistry } from "../registry.js";

const DEFAULT_MAX_MCP_RESULT_CHARS = 32_000;
const DEFAULT_MCP_TIMEOUT_MS = 15_000;

export interface McpToolPolicyOverride {
  risk?: RiskLevel;
  permissions?: string[];
  requiresConfirmation?: boolean;
  timeoutMs?: number;
  maxRetries?: number;
  idempotent?: boolean;
  sensitiveFields?: string[];
  executionMode?: "parallel" | "sequential";
}

interface McpServerBaseConfig {
  id: string;
  trust: "trusted" | "untrusted";
  defaultRisk: RiskLevel;
  permissions: string[];
  readOnlyTools?: string[];
  readOnlyPermissions?: string[];
  toolPolicies?: Record<string, McpToolPolicyOverride>;
  timeoutMs?: number;
  maxResultChars?: number;
}

export type McpServerConfig = McpServerBaseConfig & (
  | {
      type: "stdio";
      command: string;
      args: string[];
      cwd?: string;
    }
  | {
      type: "streamablehttp";
      url: string;
      headers: Record<string, string>;
    }
);

interface Connection {
  client: Client;
}

export class McpAdapterPlugin {
  private readonly connections: Connection[] = [];

  constructor(private readonly servers: McpServerConfig[]) {}

  async attach(registry: ToolRegistry): Promise<void> {
    for (const server of this.servers) {
      if (server.trust !== "trusted") {
        throw new Error(`MCP server is not trusted: ${server.id}`);
      }
      const client = new Client({ name: "agent-tool-runtime", version: "2.0.0" }, { capabilities: {} });
      const transport = server.type === "stdio"
        ? new StdioClientTransport({ command: server.command, args: server.args, cwd: server.cwd })
        : new StreamableHTTPClientTransport(new URL(server.url), {
            requestInit: { headers: resolveHeaders(server.headers) },
          });
      await client.connect(transport);
      this.connections.push({ client });
      const discovered = await client.listTools();
      const readOnlySet = new Set(server.readOnlyTools ?? []);
      const maxResultChars = server.maxResultChars ?? DEFAULT_MAX_MCP_RESULT_CHARS;

      for (const remoteTool of discovered.tools) {
        const internalName = `mcp.${server.id}.${remoteTool.name}`;
        const policy = resolveToolPolicy(server, remoteTool.name, readOnlySet);
        const baseDescription = remoteTool.description ?? `MCP tool ${remoteTool.name}`;
        const description = policy.requiresConfirmation
          ? `${baseDescription}（高风险受控动作：当用户明确要执行时请直接发起工具调用，平台会自动拦截并生成人工审批单）`
          : baseDescription;
        registry.register({
          metadata: {
            internalName,
            description,
            version: "mcp",
            parameters: sanitizeJsonSchema(remoteTool.inputSchema) as never,
            risk: policy.risk,
            permissions: policy.permissions,
            requiresConfirmation: policy.requiresConfirmation,
            timeoutMs: policy.timeoutMs,
            maxRetries: policy.maxRetries,
            idempotent: policy.idempotent,
            source: "mcp",
            sensitiveFields: policy.sensitiveFields,
            executionMode: policy.executionMode,
          },
          async handler({ args, signal }) {
            try {
              const result = await client.callTool(
                { name: remoteTool.name, arguments: args },
                undefined,
                { signal, timeout: policy.timeoutMs },
              );
              return normalizeMcpResult(result, server.id, maxResultChars);
            } catch (error) {
              if (error instanceof ToolRuntimeError) throw error;
              const unknownOutcome = !policy.idempotent;
              throw new ToolRuntimeError(
                "MCP_UNAVAILABLE",
                error instanceof Error ? error.message : "MCP 调用失败",
                policy.idempotent,
                unknownOutcome,
              );
            }
          },
        });
      }
    }
  }

  async close(): Promise<void> {
    await Promise.all(this.connections.map(({ client }) => client.close()));
    this.connections.length = 0;
  }
}

function resolveToolPolicy(
  server: McpServerBaseConfig,
  remoteToolName: string,
  readOnlySet: Set<string>,
): {
  risk: RiskLevel;
  permissions: string[];
  requiresConfirmation: boolean;
  timeoutMs: number;
  maxRetries: number;
  idempotent: boolean;
  sensitiveFields?: string[];
  executionMode: "parallel" | "sequential";
} {
  const override = server.toolPolicies?.[remoteToolName];
  const risk: RiskLevel = override?.risk ?? (readOnlySet.has(remoteToolName) ? "read" : server.defaultRisk);
  const permissions =
    override?.permissions ??
    (risk === "read" && server.readOnlyPermissions ? server.readOnlyPermissions : server.permissions);
  const requiresConfirmation = override?.requiresConfirmation ?? risk !== "read";
  const idempotent = override?.idempotent ?? risk === "read";
  const maxRetries = idempotent ? (override?.maxRetries ?? 1) : 0;
  const timeoutMs = override?.timeoutMs ?? server.timeoutMs ?? DEFAULT_MCP_TIMEOUT_MS;
  const executionMode = override?.executionMode ?? (risk === "read" ? "parallel" : "sequential");
  return {
    risk,
    permissions,
    requiresConfirmation,
    timeoutMs,
    maxRetries,
    idempotent,
    sensitiveFields: override?.sensitiveFields,
    executionMode,
  };
}

function sanitizeJsonSchema(raw: unknown): Record<string, unknown> {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { type: "object", properties: {} };
  }
  const { returnDirect: _ignored, ...rest } = raw as Record<string, unknown>;
  return rest;
}

function normalizeMcpResult(result: Record<string, unknown>, serverId: string, maxResultChars: number): unknown {
  if (result.isError) {
    throw new ToolRuntimeError("MCP_TOOL_ERROR", normalizeMcpText(result.content), false);
  }
  let normalized: unknown;
  if ("structuredContent" in result && result.structuredContent !== undefined && result.structuredContent !== null) {
    normalized = attachServerId(result.structuredContent, serverId);
  } else {
    normalized = parseMcpContent(result.content, serverId);
  }
  if (JSON.stringify(normalized).length > maxResultChars) {
    throw new ToolRuntimeError("RESULT_TOO_LARGE", "MCP 返回结果超过大小上限", false);
  }
  return normalized;
}

function parseMcpContent(content: unknown, serverId: string): unknown {
  const text = normalizeMcpText(content);
  const trimmed = text.trim();
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        const record = parsed as Record<string, unknown>;
        if (
          typeof record.code === "number" &&
          record.code !== 0 &&
          record.code !== 200 &&
          (record.data === undefined || record.data === null)
        ) {
          throw new ToolRuntimeError("MCP_TOOL_ERROR", String(record.msg ?? record.message ?? trimmed), false);
        }
      }
      return attachServerId(parsed, serverId);
    } catch (error) {
      if (error instanceof ToolRuntimeError) throw error;
    }
  }
  return { content: text, server_id: serverId };
}

function attachServerId(value: unknown, serverId: string): unknown {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return { ...(value as Record<string, unknown>), server_id: serverId };
  }
  return { data: value, server_id: serverId };
}

function resolveHeaders(headers: Record<string, string>): Record<string, string> {
  return Object.fromEntries(Object.entries(headers).map(([name, template]) => [
    name,
    template.replace(/\$\{([A-Z][A-Z0-9_]*)\}/g, (_match, envName: string) => {
      const value = process.env[envName];
      if (!value) throw new Error(`MCP_AUTH_MISSING: 请设置环境变量 ${envName}`);
      return value;
    }),
  ]));
}

function normalizeMcpText(content: unknown): string {
  if (!Array.isArray(content)) return JSON.stringify(content ?? "");
  if (content.length === 0) return "";
  return content
    .map((item) => {
      if (item && typeof item === "object" && "text" in item) return String(item.text);
      return JSON.stringify(item);
    })
    .join("\n");
}
