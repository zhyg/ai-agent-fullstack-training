from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from app.export_schemas import DEFAULT_OUTPUT
from app.main import app
from app.schemas import OrderStatusInput
from app.seed_prompt import PROMPT_ID, build_bundles


def test_exported_schema_matches_pydantic_model() -> None:
    exported = json.loads(Path(DEFAULT_OUTPUT).read_text(encoding="utf-8"))
    assert exported == OrderStatusInput.model_json_schema()
    assert exported["additionalProperties"] is False


def test_order_service_requires_auth_and_tenant_scope(monkeypatch) -> None:
    monkeypatch.setenv("GATEWAY_API_KEY", "test-key")
    client = TestClient(app)

    unauth = client.post(
        "/internal/tools/order.get_status",
        json={"order_id": "ORD-A-1001"},
        headers={"X-Tenant-Id": "tenant_a", "X-User-Id": "u1"},
    )
    assert unauth.status_code == 401

    headers = {
        "Authorization": "Bearer test-key",
        "X-Tenant-Id": "tenant_a",
        "X-User-Id": "u1",
    }
    ok = client.post("/internal/tools/order.get_status", json={"order_id": "ORD-A-1001"}, headers=headers)
    assert ok.status_code == 200
    assert ok.json()["status"] == "shipped"

    exc_order = client.post("/internal/tools/order.get_status", json={"order_id": "ORD-A-9001"}, headers=headers)
    assert exc_order.status_code == 200
    assert exc_order.json()["status"] == "exception"

    cross_tenant = client.post("/internal/tools/order.get_status", json={"order_id": "ORD-B-1001"}, headers=headers)
    assert cross_tenant.status_code == 403
    assert cross_tenant.json()["detail"]["code"] == "RESOURCE_SCOPE_DENIED"

    forged = client.post(
        "/internal/tools/order.get_status",
        json={"order_id": "ORD-A-1001", "user_id": "admin", "approved": True},
        headers=headers,
    )
    assert forged.status_code == 422

    bad_pattern = client.post(
        "/internal/tools/order.get_status",
        json={"order_id": "../../etc/passwd"},
        headers=headers,
    )
    assert bad_pattern.status_code == 422


def test_seed_prompt_bundles_are_valid_and_safe() -> None:
    bundles = build_bundles()
    assert len(bundles) == 2
    assert all(b["id"] == PROMPT_ID and b["default_model"] == "agent-default" for b in bundles)
    assert set(bundles[-1]["input_schema"]["required"]) == {"tenant_id", "user_id", "agent_name"}
    assert "mcp__my-coffee__*" in bundles[-1]["system"]

