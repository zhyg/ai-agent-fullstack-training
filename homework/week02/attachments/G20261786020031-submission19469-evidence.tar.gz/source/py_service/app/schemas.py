from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class OrderStatusInput(BaseModel):
    """Single source of truth for order.get_status input validation."""

    model_config = ConfigDict(extra="forbid")

    order_id: str = Field(
        pattern=r"^ORD-[A-Z]-[0-9]{4,12}$",
        description="待查询的订单编号，例如 ORD-A-1001",
    )


class OrderStatusOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    order_id: str
    status: str
    source: str
    customer_email: str
