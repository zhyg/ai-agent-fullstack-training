"""Week 2 Python business tool service & single-source Pydantic schema exporter."""
