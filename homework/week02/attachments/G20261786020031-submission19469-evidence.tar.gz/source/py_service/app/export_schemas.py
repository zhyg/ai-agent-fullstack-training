from __future__ import annotations

import json
from pathlib import Path

from .schemas import OrderStatusInput

DEFAULT_OUTPUT = Path(__file__).resolve().parents[2] / "config" / "schemas" / "order.get_status.json"


def export_order_schema(output_path: Path = DEFAULT_OUTPUT) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    schema = OrderStatusInput.model_json_schema()
    output_path.write_text(json.dumps(schema, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return output_path


if __name__ == "__main__":
    written = export_order_schema()
    print(f"exported {written}")
