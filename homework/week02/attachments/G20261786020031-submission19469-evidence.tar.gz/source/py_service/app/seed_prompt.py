"""Register the managed Week 2 system prompt bundle in Phase-1 LLM Gateway."""
from __future__ import annotations

import argparse
import json
import os
import sys

import httpx

PROMPT_ID = "agent.default"

V1_SYSTEM = (
    "你是企业客服 Agent。租户为 {{ tenant_id }}，当前用户为 {{ user_id }}。"
    "需要事实时先调用工具，不要编造订单状态。"
)

V2_SYSTEM = """你是 {{ agent_name }}，代表用户 {{ user_id }} 在租户 {{ tenant_id }} 内执行任务。

## 工具与边界规则
1. 查询内部企业订单状态必须调用 `order__get_status`，不得编造订单状态。
2. 创建客服工单必须调用 `ticket__create`，写操作需等待人工审批。
3. 购买或查询瑞幸咖啡优先调用已接入的 `mcp__my-coffee__*` 工具；首次调用前先确认工具参数 Schema。
4. 创建或取消咖啡订单会触发真实业务写入或支付，当用户明确提出下单/取消需求且参数已就绪时，直接发起工具调用由平台 Runtime 拦截并生成人工审批单（不要只在纯文本中让用户回复“确认”）；回复时只保留必要订单与支付信息。
5. 绝不在回复中输出任何 API Key、Authorization 或 MCP Token。"""

INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "tenant_id": {"type": "string", "minLength": 1},
        "user_id": {"type": "string", "minLength": 1},
        "agent_name": {"type": "string", "minLength": 1},
    },
    "required": ["tenant_id", "user_id", "agent_name"],
    "additionalProperties": False,
}


def build_bundles() -> list[dict]:
    return [
        {
            "id": PROMPT_ID,
            "system": V1_SYSTEM,
            "input_schema": {
                "type": "object",
                "properties": {
                    "tenant_id": {"type": "string", "minLength": 1},
                    "user_id": {"type": "string", "minLength": 1},
                },
                "required": ["tenant_id", "user_id"],
                "additionalProperties": False,
            },
            "default_model": "agent-default",
            "status": "published",
            "change_note": "Week 2 v1 basic support prompt",
        },
        {
            "id": PROMPT_ID,
            "system": V2_SYSTEM,
            "input_schema": INPUT_SCHEMA,
            "default_model": "agent-default",
            "status": "published",
            "change_note": "Week 2 v2 support + my-coffee MCP prompt",
        },
    ]


def seed(base_url: str, api_key: str) -> dict:
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    root = base_url.rstrip("/").removesuffix("/v1")
    with httpx.Client(base_url=root, headers=headers, timeout=15) as client:
        versions = []
        for bundle in build_bundles():
            resp = client.post("/v1/prompts", json=bundle)
            resp.raise_for_status()
            versions.append(resp.json()["version"])
        active_version = versions[-1]
        act = client.post(f"/v1/prompts/{PROMPT_ID}/activate", json={"version": active_version})
        act.raise_for_status()
        return {"prompt_id": PROMPT_ID, "versions": versions, "active_version": active_version}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gateway-url", default=os.environ.get("GATEWAY_BASE_URL", "http://127.0.0.1:8003"))
    args = parser.parse_args()
    api_key = os.environ.get("GATEWAY_API_KEY", "").strip()
    if not api_key:
        print("GATEWAY_API_KEY is required", file=sys.stderr)
        return 1
    result = seed(args.gateway_url, api_key)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
