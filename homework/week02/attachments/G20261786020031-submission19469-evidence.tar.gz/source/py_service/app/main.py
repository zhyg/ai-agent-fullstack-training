from __future__ import annotations

import os
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException

from .schemas import OrderStatusInput, OrderStatusOutput

TENANT_PREFIXES = {
    "tenant_a": "ORD-A-",
    "tenant_b": "ORD-B-",
}


def require_service_key(authorization: Annotated[str | None, Header()] = None) -> None:
    expected = os.getenv("TOOL_SERVICE_API_KEY") or os.getenv("GATEWAY_API_KEY")
    if not expected:
        raise HTTPException(503, {"code": "SERVICE_CREDENTIAL_MISSING"})
    if authorization != f"Bearer {expected}":
        raise HTTPException(401, {"code": "UNAUTHORIZED"})


app = FastAPI(title="Week 2 Business Tool Service", version="2.0.0")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post(
    "/internal/tools/order.get_status",
    response_model=OrderStatusOutput,
    dependencies=[Depends(require_service_key)],
)
async def order_status(
    request: OrderStatusInput,
    x_tenant_id: Annotated[str, Header(alias="X-Tenant-Id")],
    _x_user_id: Annotated[str, Header(alias="X-User-Id")],
    _x_trace_id: Annotated[str | None, Header(alias="X-Trace-Id")] = None,
) -> OrderStatusOutput:
    expected_prefix = TENANT_PREFIXES.get(x_tenant_id)
    if not expected_prefix or not request.order_id.startswith(expected_prefix):
        raise HTTPException(403, {"code": "RESOURCE_SCOPE_DENIED"})
    status = "exception" if request.order_id.endswith("9001") else "shipped"
    return OrderStatusOutput(
        order_id=request.order_id,
        status=status,
        source="order-service",
        customer_email="customer@example.com",
    )
