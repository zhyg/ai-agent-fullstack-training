# 作业二：Agent Tool Runtime (Python + TypeScript pi)

在第一单元 `llm_gateway` 之上实现第二单元「Agent 工具调用基础设施 v2」，包含：
- **统一工具注册、Snapshot 冻结与唯一 `ToolRuntime.invoke` 入口**
- **Python 业务服务 + JSON Schema 单一事实来源导出**（`order.get_status`）
- **本地有副作用工单工具**（`ticket.create`：RBAC、租户前缀隔离、参数绑定审批、幂等键）
- **真实瑞幸咖啡 Streamable HTTP MCP 接入**（`my-coffee`：6 个只读工具免审批直通，2 个高风险下单/取消工具强制绑定参数审批，未知远端工具默认 Fail-Closed）
- **非幂等写超时/断连映射 `TIMEOUT_UNKNOWN`、审计与 Trace 持久化、LoopGuard 预算保护**

---

## 1. 克隆后零假设安装与测试（离线可跑）

所有命令均在仓库根目录 `tool_platform/` 下以相对路径执行。

### 1.1 配置环境变量

```bash
cd tool_platform
cp .env.example .env
# 编辑 .env 填入 GATEWAY_API_KEY / APPROVAL_API_KEY / LUCKIN_MCP_TOKEN（如跑离线测试可先留空）
```

> 环境变量加载优先级：**当前进程已导出的环境变量 > `tool_platform/.env` > 上级目录 `.env`**，不会覆盖外部显式传入的变量。

### 1.2 安装并测试 Python 业务服务（`py_service`）

```bash
cd py_service
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m app.export_schemas
.venv/bin/python -m pytest -q tests
```

### 1.3 安装、构建并测试 TypeScript + pi Runtime（需 Node.js >= 22.19）

```bash
cd ../runtime
npm install
npm run build
npm test                 # 离线单元测试（策略、审批、重试退避、TIMEOUT_UNKNOWN、审计降级、LoopGuard）
npm run test:mcp         # 本地 stdio MCP 集成测试 + platform.yaml 瑞幸治理契约校验
```

---

## 2. 启动联调服务（需接入第一单元 Gateway）

> 启动前请先按第一单元 `llm_gateway/README.md` 启动或指向可用的 `llm_gateway`（默认地址 `http://127.0.0.1:8003/v1`）。若同一工作区下同级存在 `../llm_gateway`，可直接如下启动：

**终端 1 — 第一单元统一模型网关（:8003）：**

```bash
cd ../llm_gateway
GATEWAY_CONFIG=../tool_platform/config/gateway.example.json \
  .venv/bin/python -m app.main
```

**终端 2 — 注册受控 Prompt 并启动 Python 订单服务（:8004）：**

```bash
cd tool_platform/py_service
set -a && . ../.env && set +a
.venv/bin/python -m app.seed_prompt --gateway-url http://127.0.0.1:8003
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8004
```

**终端 3 — 运行 Runtime CLI 与审批 API：**

```bash
cd tool_platform/runtime
npm run cli -- tools                               # 查看本地/Python/瑞幸 MCP 工具与风险分级
npm run cli -- tools --without-mcp                 # 不连接外部 MCP，仅看本地与 Python 工具
npm run approval-api                               # 可选：启动 HTTP 审批与审计查询 API（:8787）
```

---

## 3. 真实瑞幸咖啡 MCP（`my-coffee`）与人工审批用法

[platform.yaml](config/platform.yaml) 对 `my-coffee` 实施按副作用分层治理：
- **只读工具（`coffee:read`，免审批直通，`idempotent: true`）**：`queryShopList`、`searchProductForMcp`、`queryProductDetailInfo`、`switchProduct`、`previewOrder`、`queryOrderDetailInfo`
- **高风险写工具（`coffee:order`，`high` 风险，`idempotent: false`，强制参数绑定审批）**：`createOrder`、`cancelOrder`
- **未列入的未知远端工具**：默认按 `default_risk: high` + `requires_confirmation: true` 拦截。

### 方式 A：多轮交互模式（推荐，支持上下文记忆与终端直接确认）

```bash
cd tool_platform/runtime
npm run cli -- chat
# 示例输入：在东华门大街店(deptId=612691)帮我下单一杯大杯冰生椰拿铁，经度116.397纬度39.908
# 触发 createOrder 时终端会提示输入 y 批准并立即执行
```

### 方式 B：单轮命令行 + 独立审批指令

```bash
# 1. 只读查门店（无需审批，终端会一并打印 audit_records 与 trace_events）
npm run cli -- agent "帮我查一下经度 116.397 纬度 39.908 附近的瑞幸咖啡门店"

# 2. Plan 模式拒绝写操作（零副作用）
npm run cli -- agent "帮我给 ORD-A-1001 建一个工单，标题是包装破损" --mode plan

# 3. 发起下单，Runtime 会暂停并返回 pending_approval_id 与下一步审批命令
npm run cli -- agent "在东华门大街店(deptId=612691)帮我下单一杯大杯冰生椰拿铁，经度116.397纬度39.908"
npm run cli -- approvals list
npm run cli -- approvals decide <approval-id> --decision approve --actor owner
npm run cli -- approvals execute <approval-id>

# 4. 查询审计与链路 Trace
npm run cli -- audit
npm run cli -- trace <trace-id>
```

### 实时联调验收（需配置真实 `GATEWAY_API_KEY` 与 `LUCKIN_MCP_TOKEN`）

```bash
cd tool_platform/runtime
npm run test:live
```
