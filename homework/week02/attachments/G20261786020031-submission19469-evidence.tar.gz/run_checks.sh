#!/usr/bin/env bash
set -u
ROOT=/home/user/workspace/repo
E="$ROOT/.amp/in/orb-backup/grading-19469"
S="$ROOT/.amp/in/orb-backup/tool-platform"
PY="$E/venv/bin/python"
run() {
  name="$1"; shift
  printf 'cwd=%s\ncommand=' "$PWD" > "$E/logs/$name.log"
  printf '%q ' "$@" >> "$E/logs/$name.log"; printf '\n' >> "$E/logs/$name.log"
  "$@" >> "$E/logs/$name.log" 2>&1
  code=$?; printf '\nexit_code=%s\n' "$code" >> "$E/logs/$name.log"
  echo "$name exit_code=$code" 
}
cd "$S"
run metadata git log -1 --format=fuller
run branches git branch -a
run inventory git ls-tree -r --name-only HEAD
run original-five env PYTHONPATH="$S:$S/py_service" PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 "$PY" -m pytest "$E/tests/test_tool_governance.py" -v -k transfer
run module-resolution env PYTHONPATH="$S:$S/py_service" "$PY" -c 'import sys,importlib.util,platform,pydantic,pytest,fastapi; print("Python",platform.python_version()); print("pydantic",pydantic.__version__,"pytest",pytest.__version__,"fastapi",fastapi.__version__); print("sys.path",sys.path); print("tool_governance_demo spec",importlib.util.find_spec("tool_governance_demo"))'
cd "$S/py_service"
run python-submitted env PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 "$PY" -m pytest -v tests
cd "$S/runtime"
run npm-build npm run build
run npm-unit npm test
run npm-mcp npm run test:mcp
run demo-tools npm run cli -- tools --without-mcp
run demo-transfer npm run cli -- invoke transfer '{"from_account":"ACC-A-123456","to_account":"ACC-A-654321","amount":1200.0}'
run npm-versions npm ls --depth=0
