import ast, hashlib, pathlib, subprocess
root=pathlib.Path('/home/user/workspace/repo')
s=root/'.amp/in/orb-backup/tool-platform'
e=root/'.amp/in/orb-backup/grading-19469'
files=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=s,text=True).splitlines()
print('tracked_files',len(files))
for token in ['ACCOUNTS','TransferArgs','transfer_precheck','transfer_handler','canonical_target','PermissionEngine','StrictArgs','tool_governance_demo']:
    hits=[f for f in files if token in (s/f).read_text(errors='replace')]
    print(token,'matches:',hits)
baseline=e/'baseline/tool_governance_demo-无答案.py'
source=baseline.read_text()
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='PermissionEngine')
method=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='decide')
text='\n'.join(source.splitlines()[method.lineno-1:method.end_lineno])+'\n'
(e/'baseline/PermissionEngine.decide.txt').write_text(text)
print('Attachment PermissionEngine.decide lines',method.lineno,method.end_lineno,'sha256',hashlib.sha256(text.encode()).hexdigest())
print('Student counterpart absent. Comparison status: MISSING, cannot certify unchanged; not evidence of modified lines.')
a=root/'hw-guide/week02/hw2/test_tool_governance.py'; b=e/'tests/test_tool_governance.py'
assert a.read_bytes()==b.read_bytes()
print('Trusted test byte-for-byte identical SHA256',hashlib.sha256(b.read_bytes()).hexdigest())
print('A01 no account store; A02 no transfer schema; A03/A04 no transfer precheck; A05/A06/A07 no transfer handler; A08 no transfer registration; A09 no transfer output; A10 no original PermissionEngine or transfer demo.')
