import ast
import asyncio
import inspect
import platform
import sys
import time
from pathlib import Path
from dataclasses import replace
import pydantic
import pytest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'student'))
import tool_governance_demo as d

def method_text(path):
    text = path.read_text()
    tree = ast.parse(text)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
    fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
    return '\n'.join(text.splitlines()[fn.lineno-1:fn.end_lineno])

print('Python', platform.python_version(), 'Pydantic', pydantic.__version__, 'pytest', pytest.__version__)
print('IMPORT', d.__file__)
assert method_text(Path(d.__file__)) == method_text(ROOT / 'trusted/tool_governance_demo-无答案.py')
print('PermissionEngine.decide exact source MATCH')
initial = {('tenant_a','ACC-A-123456'):100000.0, ('tenant_a','ACC-A-654321'):5000.0,
           ('tenant_a','ACC-A-888888'):20000.0, ('tenant_b','ACC-B-111111'):50000.0}
assert d.ACCOUNTS == initial and all(type(v) is float for v in d.ACCOUNTS.values())
assert issubclass(d.TransferArgs, d.StrictArgs)
assert d.TransferArgs.model_config['strict'] is True and d.TransferArgs.model_config['extra'] == 'forbid'
tool = next(t for t in d.build_tools() if t.name == 'transfer')
assert tool.parameters_model is d.TransferArgs and tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
assert inspect.iscoroutinefunction(tool.precheck)
p = tool.policy
assert p.effect is d.Effect.WRITE and (p.requires_approval or p.risk is d.Risk.HIGH)
assert p.permission == 'transfer:execute' and 0 < p.timeout_seconds < 3 and not p.idempotent and p.max_retries == 0
base = {'from_account':'ACC-A-123456','to_account':'ACC-A-654321','amount':100.0}
targets = [tool.canonical_target(d.TransferArgs(**a)) for a in
           [base, {**base,'from_account':'ACC-A-888888'}, {**base,'to_account':'ACC-A-888888'}, {**base,'amount':101.0}]]
assert len(set(targets)) == 4
print('A01/A08 initial accounts, strict config, bindings, policy, canonical targets PASS', targets)

async def case(name, args, expected, approved=False, **ctx):
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(initial)
    rt, approvals, audit = d.build_runtime()
    c = d.base_context(**ctx)
    if approved:
        approvals.approve('teacher', c, 'transfer', d.TransferArgs(**args))
        c = replace(c, approval_id='teacher')
    start = time.perf_counter()
    result = await rt.invoke(d.ToolCall('teacher_000123','transfer',args), c)
    elapsed = time.perf_counter() - start
    assert result.code == expected, (name, result)
    if expected != 'OK':
        assert d.ACCOUNTS == initial, name
    if expected in {'EXCEED_LIMIT','INSUFFICIENT_BALANCE'}:
        assert audit.records[-1].phase == 'decision'
        if approved:
            assert not approvals._records['teacher'].used
    if expected == 'TIMEOUT_UNKNOWN':
        assert elapsed < 3 and audit.records[-1].phase == 'execution'
    print(name, result.action, result.code, result.content, 'elapsed', round(elapsed,3),
          'audit', [(r.phase,r.code) for r in audit.records])
    return result

async def main():
    for key in base:
        await case('A02 missing '+key, {k:v for k,v in base.items() if k!=key}, 'INVALID_ARGUMENT')
    for patch in [{'approved':True}, {'user_id':'admin'}, {'amount':-1.0}, {'amount':'100'},
                  {'from_account':'ACC-123456'}, {'to_account':'ACC-A-12345x'}]:
        await case('A02 '+repr(patch), {**base,**patch}, 'INVALID_ARGUMENT')
    for amount, expected in [(50000.0,'APPROVAL_REQUIRED'), (50000.01,'EXCEED_LIMIT'),
                             (80000.0,'EXCEED_LIMIT'), (80000.01,'APPROVAL_REQUIRED'),
                             (100000.0,'APPROVAL_REQUIRED'), (100000.01,'INVALID_ARGUMENT')]:
        await case('A03 '+str(amount), {**base,'amount':amount}, expected)
    for amount in [80000.01, 100000.0]:
        await case('A03 approved '+str(amount), {**base,'amount':amount}, 'TIMEOUT_UNKNOWN', True)
    for amount, expected in [(30000.0,'INSUFFICIENT_BALANCE'),(60000.0,'EXCEED_LIMIT')]:
        for approved in [False,True]:
            await case('A04 '+str((amount,approved)), {**base,'from_account':'ACC-A-888888','amount':amount}, expected, approved)
    await case('A05 full balance', {**base,'from_account':'ACC-A-888888','amount':20000.0}, 'OK', True)
    assert d.ACCOUNTS[('tenant_a','ACC-A-888888')] == 0.0
    assert d.ACCOUNTS[('tenant_a','ACC-A-654321')] == 25000.0
    for target in ['ACC-A-999999','ACC-B-111111']:
        await case('A06/A07 missing/cross tenant destination', {**base,'to_account':target}, 'ACCOUNT_NOT_FOUND', True)
    for source in ['ACC-A-999999','ACC-B-111111']:
        await case('A07 missing/cross tenant source', {**base,'from_account':source}, 'INSUFFICIENT_BALANCE')
    result = await case('A09 masked transfer', base, 'OK', True)
    assert result.content == {'txn_id':'000123','from':'ACC-A-****3456','to':'ACC-A-****4321','amount':100.0,'status':'accepted'}
    rt, _, _ = d.build_runtime()
    order = await rt.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),d.base_context())
    assert order.content['customer_email'] == '***@***' and order.content['access_token'] == '***'
    assert d._redact({'nested':[{'email':'a@example.com','password':'x','account':'ACC-B-111111'}]}) == {'nested':[{'email':'***@***','password':'***','account':'ACC-B-****1111'}]}
    print('A09 order and nested redaction PASS')
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(initial)
    print('ALL SUPPLEMENTAL CHECKS PASS')

asyncio.run(main())
