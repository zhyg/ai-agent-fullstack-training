# AI Agent 全栈工程师训练营-作业二

来源：https://geekbang.feishu.cn/docx/Vxprd4TiqoRJfsxzST8cPq37nVh

# 第二章实战作业：为治理框架增加“转账”工具

## 一、作业目标

在 `tool_governance_demo.py`（附录一）基础上，新增一个“转账”工具，

目的是把第二章讲的 参数校验 → 业务预检 → 权限判断 → 人工审批 → 超时处理 → 结果脱敏 → 审计追踪 这整条链路亲手跑通一遍。

---

## 二、准备工作

- 确保 `tool_governance_demo.py` 可以正常运行

---

## 三、完成 6 个任务（按顺序做）

### 任务 1：新增模拟账户数据

在 `ORDERS` 字典后面，新建一个 `ACCOUNTS` 字典，Key 为 `(tenant_id, account_id)`，Value 为余额（浮点数）。

预设数据：

- `tenant_a` 有三个账户：

  - `ACC-A-123456`：余额 100000.0

  - `ACC-A-654321`：余额 5000.0

  - `ACC-A-888888`：余额 20000.0

- `tenant_b` 有一个账户：

  - `ACC-B-111111`：余额 50000.0

---

### 任务 2：定义转账参数模型（Pydantic）

新建 `TransferArgs` 类，继承 `StrictArgs`（已存在）。

三个字段：

- `from_account`：`str`，正则约束 `^ACC-[A-Z]-[0-9]{6}$`

- `to_account`：`str`，正则同上

- `amount`：`float`，大于 0 且不超过 100000

---

### 任务 3：实现业务预检函数

编写异步函数 `transfer_precheck(args, context)`，只做判断，不改余额，按以下顺序检查，不满足就 `raise PolicyDenied`：

1. 金额区间拦截：`50000 < amount <= 80000` 时报错，错误码 `EXCEED_LIMIT`。这是教学专用规则，不是真实业务的单笔限额；超过 80000 的金额仍须通过余额检查与审批，随后用于任务 4 的超时演示。

1. 余额充足：从 `ACCOUNTS` 查 `(context.tenant_id, from_account)` 的余额，小于 `amount` 时报错，错误码 `INSUFFICIENT_BALANCE`。

---

### 任务 4：实现转账处理函数

编写异步函数 `transfer_handler(tool_call_id, args, context)`：

- 超时模拟：如果 `amount > 80000`，执行 `await asyncio.sleep(3.0)`（故意制造超时）。

- 修改余额：从转出账户扣钱，给转入账户加钱（若转入账户不存在报错，即在 `transfer_handler` 里，如果 `to_key not in ACCOUNTS`，应该 `raise PolicyDenied("ACCOUNT_NOT_FOUND", "转入账户不存在")`。 ）。

- 返回结果：包含 `txn_id`（可用 `tool_call_id` 后 6 位）、`from`、`to`、`amount`、`status`。

---

### 任务 5：注册工具到 `build_tools()`

在 `return` 列表末尾追加一个 `ToolDefinition`：

---

### 任务 6：修改脱敏函数

在现有邮箱脱敏逻辑后面，追加对账号的脱敏处理：

- 匹配 `ACC-A-123456`，处理后的结果形如 `ACC-A-****3456`）

提示：Python 的 `re.sub` 可以传字符串替换，也可以传函数。你选一种实现即可。

---

## 四、必须通过的 5 个测试

---

## 五、不能改动的地方

1. 不要改 `PermissionEngine.decide` 里面的任何一行代码。它的优先级顺序是固定框架。

1. 测试里不要绕过 `ToolRuntime.invoke`。所有调用必须走 `runtime.invoke()`，不能直接调 `transfer_handler`。

1. 不要删除 `TransferArgs` 里的 `extra="forbid"`。这是防止模型注入额外参数的最后屏障。

---

## 六、验收命令与标准

完成上述任务后，在项目根目录运行：

python -m pytest tests/test_tool_governance.py -v -k "transfer"

预期结果：5 个测试全部 `PASSED`。

同时，在任意测试或 `run_offline_demo` 中打印审计日志，应看到账号已被脱敏（`ACC-A-****3456`），且审批流程执行前会返回 `CONFIRM` 状态。

---

## 七、提示

- 参考 `CreateRefundArgs` 怎么写 `Field` 约束。

- 参考 `refund_precheck` 怎么写 `PolicyDenied`。

- 参考 `create_refund_handler` 怎么写副作用和返回结构。

- 参考 `test_approval_is_bound_to_canonical_arguments` 怎么写审批绑定测试。

## 附录一：tool_governance_demo.py

[tool_governance_demo-无答案.py](tool_governance_demo-无答案.py)

## 附录二：test_tool_governance.py

[test_tool_governance.py](test_tool_governance.py)

[conftest.py](conftest.py)
