"""第二章作业验收：转账工具（transfer）的 5 个链路测试。

约法三章（作业"不能改动的地方"）：
- 所有调用都经过 `ToolRuntime.invoke`，不直接调 handler。
- 不改 `PermissionEngine.decide` 的优先级顺序，测试只观察它的输出。

未完成对应任务时，测试给的是"哪一步没做"的失败信息，而不是导入错误：
缺少 `ACCOUNTS` 会命中 `accounts()` 的断言，没注册 transfer 工具会拿到 `TOOL_NOT_FOUND`。
"""

from __future__ import annotations

import asyncio
import functools
import json
import socket
import sys
import time
from collections import UserDict
from collections.abc import Awaitable, Callable, Iterator, Mapping
from contextlib import asynccontextmanager
from copy import deepcopy
from types import SimpleNamespace
from typing import Any

import pytest

import tool_governance_demo as demo

TRANSFER = "transfer"
APPROVAL_ID = "approval_transfer"
FROM_ACCOUNT = "ACC-A-123456"  # tenant_a，余额 100000.0
TO_ACCOUNT = "ACC-A-654321"  # tenant_a，余额 5000.0
SMALL_ACCOUNT = "ACC-A-888888"  # tenant_a，余额 20000.0
SLEEP_SECONDS = 3.0  # transfer_handler 里刻意制造的慢调用


def async_test(test: Callable[..., Awaitable[None]]) -> Callable[..., None]:
    """不依赖 pytest-asyncio，让 async 测试在任何 pytest 环境下都能跑。"""

    @functools.wraps(test)
    def run(*args: Any, **kwargs: Any) -> None:
        asyncio.run(test(*args, **kwargs))

    return run


def transfer_context(**overrides: Any) -> demo.ExecutionContext:
    """带 transfer:execute 权限和 transfer 执行白名单的上下文。"""

    defaults: dict[str, Any] = {
        "permissions": frozenset({"order:read", "refund:create", "shell:run", "transfer:execute"}),
        "allowed_tools": frozenset({"get_order", "create_refund", "run_shell", "transfer"}),
    }
    return demo.base_context(**{**defaults, **overrides})


def accounts() -> dict[tuple[str, str], float]:
    store = getattr(demo, "ACCOUNTS", None)
    assert isinstance(store, dict), "任务 1 未完成：tool_governance_demo.ACCOUNTS 不存在"
    return store


def balance(account: str, tenant_id: str = "tenant_a") -> float:
    store = accounts()
    assert (tenant_id, account) in store, f"任务 1 未完成：ACCOUNTS 缺少 {(tenant_id, account)}"
    return store[(tenant_id, account)]


def approve(approvals: demo.ApprovalStore, arguments: Mapping[str, Any]) -> None:
    """对同一份参数做一次性审批（摘要绑定，值必须与调用时逐字节一致）。"""

    approvals.approve(APPROVAL_ID, transfer_context(), TRANSFER, dict(arguments))


async def transfer(
    runtime: demo.ToolRuntime,
    tool_call_id: str,
    arguments: Mapping[str, Any],
    **context_overrides: Any,
) -> demo.ToolResult:
    return await runtime.invoke(
        demo.ToolCall(tool_call_id, TRANSFER, arguments),
        transfer_context(**context_overrides),
    )


@pytest.fixture(autouse=True)
def isolated_accounts() -> Iterator[None]:
    store = getattr(demo, "ACCOUNTS", None)
    snapshot = dict(store) if isinstance(store, dict) else None
    side_effects_snapshot = dict(demo.SIDE_EFFECTS)
    demo.reset_side_effects()
    try:
        yield
    finally:
        if snapshot is not None:
            store.clear()
            store.update(snapshot)
        demo.SIDE_EFFECTS.clear()
        demo.SIDE_EFFECTS.update(side_effects_snapshot)


@async_test
async def test_transfer_rejects_injected_arguments_and_invalid_amount() -> None:
    """参数校验：extra="forbid" 挡住模型注入，Field 约束挡住非法账号与额度。"""

    runtime, _approvals, _audit = demo.build_runtime()
    valid = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 100.0}

    injected = await transfer(runtime, "call_tr_inject", {**valid, "approved": True, "user_id": "u_admin"})
    assert injected.ok is False
    assert injected.code == "INVALID_ARGUMENT"

    malformed = await transfer(runtime, "call_tr_format", {**valid, "from_account": "ACC-123456"})
    assert malformed.code == "INVALID_ARGUMENT"

    zero = await transfer(runtime, "call_tr_zero", {**valid, "amount": 0.0})
    assert zero.code == "INVALID_ARGUMENT"

    over_schema = await transfer(runtime, "call_tr_schema", {**valid, "amount": 100_000.1})
    assert over_schema.code == "INVALID_ARGUMENT"

    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_precheck_blocks_over_limit_and_insufficient_balance() -> None:
    """业务预检：教学金额区间拦截与余额不足都在 handler 之前拒绝。"""

    runtime, approvals, _audit = demo.build_runtime()

    over_limit = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 60_000.0}
    approve(approvals, over_limit)
    rejected = await transfer(runtime, "call_tr_limit", over_limit, approval_id=APPROVAL_ID)
    assert rejected.ok is False
    assert rejected.action is demo.DecisionAction.DENY
    assert rejected.code == "EXCEED_LIMIT"

    short = {"from_account": SMALL_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 30_000.0}
    approve(approvals, short)
    rejected = await transfer(runtime, "call_tr_balance", short, approval_id=APPROVAL_ID)
    assert rejected.action is demo.DecisionAction.DENY
    assert rejected.code == "INSUFFICIENT_BALANCE"

    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(SMALL_ACCOUNT) == 20_000.0
    assert balance(TO_ACCOUNT) == 5_000.0


@async_test
async def test_transfer_is_denied_without_permission_or_whitelist_and_in_plan_mode() -> None:
    """权限判断：带上审批也越不过 RBAC、执行白名单和 plan 只读契约。"""

    runtime, approvals, _audit = demo.build_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_000.0}
    approve(approvals, arguments)
    approved: dict[str, Any] = {"approval_id": APPROVAL_ID}

    no_permission = await transfer(
        runtime,
        "call_tr_rbac",
        arguments,
        permissions=frozenset({"order:read", "refund:create", "shell:run"}),
        **approved,
    )
    assert no_permission.action is demo.DecisionAction.DENY
    assert no_permission.code == "PERMISSION_DENIED"

    not_whitelisted = await transfer(
        runtime,
        "call_tr_whitelist",
        arguments,
        allowed_tools=frozenset({"get_order", "create_refund", "run_shell"}),
        **approved,
    )
    assert not_whitelisted.code == "TOOL_NOT_ALLOWED"

    plan_mode = await transfer(
        runtime,
        "call_tr_plan",
        arguments,
        mode=demo.PermissionMode.PLAN,
        **approved,
    )
    assert plan_mode.code == "PLAN_MODE_DENIED"

    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_requires_approval_bound_to_arguments_and_masks_accounts() -> None:
    """人工审批 + 成功路径 + 结果脱敏 + 审计追踪。"""

    runtime, approvals, audit = demo.build_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 1_200.0}

    pending = await transfer(runtime, "call_tr_000001", arguments)
    assert pending.ok is False
    assert pending.action is demo.DecisionAction.CONFIRM
    assert pending.code == "APPROVAL_REQUIRED"
    assert balance(FROM_ACCOUNT) == 100_000.0

    approve(approvals, arguments)
    tampered = await transfer(
        runtime, "call_tr_000002", {**arguments, "amount": 9_000.0}, approval_id=APPROVAL_ID
    )
    assert tampered.action is demo.DecisionAction.CONFIRM
    assert tampered.code == "APPROVAL_REQUIRED"

    executed = await transfer(runtime, "call_tr_000003", arguments, approval_id=APPROVAL_ID)
    assert executed.ok is True
    assert executed.action is demo.DecisionAction.ALLOW
    assert executed.code == "OK"
    assert executed.content["txn_id"] == "000003"
    assert executed.content["amount"] == 1_200.0
    assert executed.content["status"] == "accepted"
    assert executed.content["from"] == "ACC-A-****3456"
    assert executed.content["to"] == "ACC-A-****4321"
    assert balance(FROM_ACCOUNT) == 98_800.0
    assert balance(TO_ACCOUNT) == 6_200.0

    assert [(record.phase, record.code) for record in audit.records] == [
        ("decision", "APPROVAL_REQUIRED"),
        ("decision", "APPROVAL_REQUIRED"),
        ("decision", "APPROVED"),
        ("execution", "OK"),
    ]

    replay = await transfer(runtime, "call_tr_000004", arguments, approval_id=APPROVAL_ID)
    assert replay.action is demo.DecisionAction.CONFIRM


@async_test
async def test_transfer_timeout_is_reported_as_unknown_and_leaves_balances_untouched() -> None:
    """超时处理：非幂等写超时是 TIMEOUT_UNKNOWN，且超时点必须早于扣款。"""

    runtime, approvals, audit = demo.build_runtime()
    # 超过 80000 不命中教学拦截区间，通过余额检查与审批后触发 sleep(3.0)。
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 90_000.0}
    approve(approvals, arguments)

    started = time.perf_counter()
    result = await transfer(runtime, "call_tr_timeout", arguments, approval_id=APPROVAL_ID)
    elapsed = time.perf_counter() - started

    assert result.ok is False
    assert result.code == "TIMEOUT_UNKNOWN"
    assert elapsed < SLEEP_SECONDS
    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(TO_ACCOUNT) == 5_000.0
    assert audit.records[-1].phase == "execution"
    assert audit.records[-1].code == "TIMEOUT_UNKNOWN"


@async_test
async def test_transfer_rejects_self_transfer_without_changing_balance() -> None:
    """同一账户不能向自己转账，避免产生无资金变化的成功交易。"""

    runtime, _approvals, _audit = demo.build_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": FROM_ACCOUNT, "amount": 100.0}

    result = await transfer(runtime, "call_tr_self", arguments)

    assert result.ok is False
    assert result.action is demo.DecisionAction.DENY
    assert result.code == "SAME_ACCOUNT"
    assert balance(FROM_ACCOUNT) == 100_000.0


@async_test
async def test_transfer_rejects_missing_target_and_cross_tenant_access() -> None:
    """不存在的转入账户和其他租户账户都不能接收或提供资金。"""

    runtime, approvals, _audit = demo.build_runtime()
    missing_arguments = {
        "from_account": FROM_ACCOUNT,
        "to_account": "ACC-A-999999",
        "amount": 1_000.0,
    }
    approve(approvals, missing_arguments)
    missing = await transfer(
        runtime, "call_tr_missing", missing_arguments, approval_id=APPROVAL_ID
    )
    assert missing.ok is False
    assert missing.code == "ACCOUNT_NOT_FOUND"

    runtime, approvals, _audit = demo.build_runtime()
    cross_tenant_target = {
        "from_account": FROM_ACCOUNT,
        "to_account": "ACC-B-111111",
        "amount": 1_000.0,
    }
    approve(approvals, cross_tenant_target)
    rejected_target = await transfer(
        runtime, "call_tr_cross_target", cross_tenant_target, approval_id=APPROVAL_ID
    )
    assert rejected_target.code == "ACCOUNT_NOT_FOUND"

    cross_tenant_source = {
        "from_account": "ACC-B-111111",
        "to_account": TO_ACCOUNT,
        "amount": 1_000.0,
    }
    rejected_source = await transfer(runtime, "call_tr_cross_source", cross_tenant_source)
    assert rejected_source.code == "INSUFFICIENT_BALANCE"

    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(TO_ACCOUNT) == 5_000.0
    assert balance("ACC-B-111111", tenant_id="tenant_b") == 50_000.0


@async_test
async def test_transfer_amount_boundaries_follow_precheck_contract() -> None:
    """区间端点必须明确：50000 放行，80000 拦截，超过 80000 留给审批与超时链路。"""

    runtime, _approvals, _audit = demo.build_runtime()
    cases = [
        (50_000.0, demo.DecisionAction.CONFIRM, "APPROVAL_REQUIRED"),
        (50_000.01, demo.DecisionAction.DENY, "EXCEED_LIMIT"),
        (80_000.0, demo.DecisionAction.DENY, "EXCEED_LIMIT"),
        (80_000.01, demo.DecisionAction.CONFIRM, "APPROVAL_REQUIRED"),
        (100_000.0, demo.DecisionAction.CONFIRM, "APPROVAL_REQUIRED"),
    ]

    for index, (amount, expected_action, expected_code) in enumerate(cases):
        arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": amount}
        result = await transfer(runtime, f"call_tr_boundary_{index}", arguments)
        assert result.action is expected_action
        assert result.code == expected_code

    assert balance(FROM_ACCOUNT) == 100_000.0
    assert balance(TO_ACCOUNT) == 5_000.0


@async_test
async def test_transfer_approval_uses_validated_integer_amount() -> None:
    """模型常把金额写成整数；审批摘要必须与 Runtime 校验后的浮点参数一致。"""

    runtime, approvals, _audit = demo.build_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 100}
    call = demo.ToolCall("call_tr_integer", TRANSFER, arguments)

    pending = await runtime.invoke(call, transfer_context())
    assert pending.code == "APPROVAL_REQUIRED"

    approvals.approve(
        APPROVAL_ID,
        transfer_context(),
        TRANSFER,
        runtime.validated_arguments(call),
    )
    executed = await runtime.invoke(
        call,
        transfer_context(approval_id=APPROVAL_ID),
    )

    assert executed.ok is True
    assert executed.code == "OK"
    assert executed.content["amount"] == 100.0
    assert balance(FROM_ACCOUNT) == 99_900.0
    assert balance(TO_ACCOUNT) == 5_100.0


def stream_chunk(
    *,
    content: str | None = None,
    calls: list[SimpleNamespace] | None = None,
    finish_reason: str | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(content=content, tool_calls=calls),
                finish_reason=finish_reason,
            )
        ]
    )


def stream_call(
    index: int,
    *,
    call_id: str | None = None,
    name: str | None = None,
    arguments: str | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        index=index,
        id=call_id,
        function=SimpleNamespace(name=name, arguments=arguments),
    )


def agent_transfer_arguments() -> dict[str, Any]:
    return {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 100}


def transfer_stream(*call_ids: str) -> list[SimpleNamespace]:
    return [
        stream_chunk(
            calls=[
                stream_call(
                    index,
                    call_id=call_id,
                    name=TRANSFER,
                    arguments=json.dumps(agent_transfer_arguments()),
                )
                for index, call_id in enumerate(call_ids)
            ]
        ),
        stream_chunk(finish_reason="tool_calls"),
    ]


def order_stream() -> list[SimpleNamespace]:
    return [
        stream_chunk(
            calls=[
                stream_call(
                    0,
                    call_id="call_order_before_error",
                    name="get_order",
                    arguments='{"order_id":"ord_1001"}',
                )
            ]
        ),
        stream_chunk(finish_reason="tool_calls"),
    ]


class FakeSDK:
    """只提供流式 SDK 边界；审批、Runtime、handler 均使用真实代码。"""

    def __init__(self, monkeypatch: pytest.MonkeyPatch) -> None:
        self.rounds: list[list[SimpleNamespace | BaseException] | BaseException] = []
        self.requests: list[dict[str, Any]] = []
        self.client_arguments: list[dict[str, Any]] = []
        self.lifecycle: list[str] = []
        self.close_errors: list[BaseException | None] = []
        self.prompts: list[str] = []
        self.answers: list[str | BaseException] = []
        self.tty = False
        self.invocations: list[tuple[demo.ToolCall, demo.ExecutionContext, demo.ToolResult]] = []
        self.runtimes: list[demo.ToolRuntime] = []
        self.audits: list[demo.AuditSink] = []
        self.account_snapshot = dict(accounts())
        self.side_effect_snapshot = dict(demo.SIDE_EFFECTS)

        async def create(**kwargs: Any) -> Any:
            self.requests.append(deepcopy(kwargs))
            assert self.rounds, "FakeSDK 没有更多响应，Agent 不应继续请求"
            response = self.rounds.pop(0)
            if isinstance(response, BaseException):
                raise response

            async def chunks() -> Any:
                for chunk in response:
                    if isinstance(chunk, BaseException):
                        raise chunk
                    yield chunk

            return chunks()

        @asynccontextmanager
        async def client(**kwargs: Any) -> Any:
            self.client_arguments.append(deepcopy(kwargs))
            self.lifecycle.append("open")
            error: BaseException | None = None
            try:
                yield SimpleNamespace(
                    chat=SimpleNamespace(completions=SimpleNamespace(create=create))
                )
            except BaseException as caught:
                error = caught
                raise
            finally:
                self.close_errors.append(error)
                self.lifecycle.append("close")

        def input_answer(prompt: str = "") -> str:
            self.prompts.append(prompt)
            assert self.answers, "未经测试安排，不应读取 input"
            answer = self.answers.pop(0)
            if isinstance(answer, BaseException):
                raise answer
            return answer

        original_build = demo.build_runtime
        original_invoke = demo.ToolRuntime.invoke

        def build_runtime(**kwargs: Any) -> Any:
            runtime, approvals, audit = original_build(**kwargs)
            self.runtimes.append(runtime)
            self.audits.append(audit)
            return runtime, approvals, audit

        async def invoke(
            runtime: demo.ToolRuntime, call: demo.ToolCall, context: demo.ExecutionContext
        ) -> demo.ToolResult:
            result = await original_invoke(runtime, call, context)
            self.invocations.append((call, context, result))
            return result

        def forbid_network(*args: Any, **kwargs: Any) -> Any:
            raise AssertionError("测试禁止网络访问")

        monkeypatch.setitem(sys.modules, "openai", SimpleNamespace(AsyncOpenAI=client))
        monkeypatch.setenv("DEEPSEEK_API_KEY", "fake-test-key-do-not-use")
        monkeypatch.setenv("DEEPSEEK_BASE_URL", "https://fake-sdk.invalid")
        monkeypatch.setattr(sys, "stdin", SimpleNamespace(isatty=lambda: self.tty))
        monkeypatch.setattr("builtins.input", input_answer)
        monkeypatch.setattr(demo, "build_runtime", build_runtime)
        monkeypatch.setattr(demo.ToolRuntime, "invoke", invoke)
        monkeypatch.setattr(socket, "create_connection", forbid_network)
        monkeypatch.setattr(socket, "getaddrinfo", forbid_network)
        monkeypatch.setattr(socket.socket, "connect", forbid_network)
        monkeypatch.setattr(socket.socket, "connect_ex", forbid_network)

    def tool_messages(self) -> list[dict[str, Any]]:
        return [message for message in self.requests[-1]["messages"] if message["role"] == "tool"]

    def assert_closed(self, error: BaseException | None = None) -> None:
        assert self.lifecycle == ["open", "close"]
        assert self.close_errors == [error]
        assert self.client_arguments[0]["api_key"] == "fake-test-key-do-not-use"

    def assert_untouched(self) -> None:
        assert accounts() == self.account_snapshot
        assert demo.SIDE_EFFECTS == self.side_effect_snapshot


@pytest.fixture
def fake_sdk(monkeypatch: pytest.MonkeyPatch) -> FakeSDK:
    return FakeSDK(monkeypatch)


@pytest.mark.parametrize(
    "arguments",
    [
        None,
        100,
        [],
        [{"amount": 100}],
        "not an object",
        json.dumps(agent_transfer_arguments()),
        True,
        False,
        {**agent_transfer_arguments(), 1: "mixed-key"},
        UserDict({**agent_transfer_arguments(), 1: "mixed-key"}),
    ],
    ids=["null", "integer", "empty-array", "array", "string", "json-string", "true", "false", "mixed-dict", "mixed-mapping"],
)
@async_test
async def test_runtime_invalid_argument_roots_preserve_id_and_safe_audit(arguments: Any) -> None:
    runtime, _approvals, audit = demo.build_runtime()
    snapshot = dict(accounts())
    side_effects = dict(demo.SIDE_EFFECTS)
    call_id = "call_invalid_root"

    result = await runtime.invoke(demo.ToolCall(call_id, TRANSFER, arguments), transfer_context())

    assert result.ok is False
    assert result.action is demo.DecisionAction.DENY
    assert result.code == "INVALID_ARGUMENT"
    assert result.tool_call_id == call_id
    assert result.to_tool_message()["tool_call_id"] == call_id
    assert accounts() == snapshot
    assert demo.SIDE_EFFECTS == side_effects
    assert len(audit.records) == 1
    record = audit.records[0]
    assert (record.tool_call_id, record.phase, record.code) == (call_id, "decision", "INVALID_ARGUMENT")
    assert all(isinstance(key, str) for key in record.argument_keys)
    assert record.argument_keys == tuple(sorted(record.argument_keys))
    if not isinstance(arguments, Mapping):
        assert record.argument_keys == ()
    for account in (FROM_ACCOUNT, TO_ACCOUNT):
        assert account not in repr(record)


@pytest.mark.parametrize(
    "arguments",
    [None, 100, [], [agent_transfer_arguments()], "not an object", True, False],
    ids=["null", "integer", "empty-array", "array", "string", "true", "false"],
)
@async_test
async def test_agent_invalid_json_roots_are_rejected_by_runtime(
    fake_sdk: FakeSDK, arguments: Any
) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = ["y"]
    fake_sdk.rounds = [
        [
            stream_chunk(calls=[stream_call(
                0, call_id="call_agent_invalid_root", name=TRANSFER, arguments=json.dumps(arguments)
            )]),
            stream_chunk(finish_reason="tool_calls"),
        ],
        [stream_chunk(content="非法参数未执行。", finish_reason="stop")],
    ]

    await demo.run_deepseek_agent("模型提交的参数根不一定是 JSON 对象")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    assert fake_sdk.prompts == []
    assert len(fake_sdk.invocations) == 1
    call, _context, result = fake_sdk.invocations[0]
    assert call.arguments == arguments
    assert call.tool_call_id == "call_agent_invalid_root"
    assert result.code == "INVALID_ARGUMENT"
    assert result.action is demo.DecisionAction.DENY
    assert fake_sdk.tool_messages() == [result.to_tool_message()]


@pytest.mark.parametrize("raw_arguments", ["", "{", "{amount:100}"], ids=["empty", "truncated", "unquoted-key"])
@async_test
async def test_agent_invalid_json_is_rejected_without_approval(
    fake_sdk: FakeSDK, raw_arguments: str
) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = ["y"]
    fake_sdk.rounds = [
        [
            stream_chunk(calls=[stream_call(
                0, call_id="call_invalid_json", name=TRANSFER, arguments=raw_arguments
            )]),
            stream_chunk(finish_reason="tool_calls"),
        ],
        [stream_chunk(content="非法 JSON 未执行。", finish_reason="stop")],
    ]

    await demo.run_deepseek_agent("非法 JSON 不能触发审批或执行")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    assert fake_sdk.prompts == []
    assert len(fake_sdk.invocations) == 1
    result = fake_sdk.invocations[0][2]
    assert result.code == "INVALID_ARGUMENT"
    assert result.action is demo.DecisionAction.DENY
    assert fake_sdk.tool_messages() == [result.to_tool_message()]
    assert [(record.phase, record.code) for record in fake_sdk.audits[0].records] == [
        ("decision", "INVALID_ARGUMENT")
    ]


@async_test
async def test_agent_round_limit_closes_client(fake_sdk: FakeSDK) -> None:
    fake_sdk.rounds = [order_stream() for _round in range(8)]

    with pytest.raises(RuntimeError, match="超过最大轮数 8") as caught:
        await demo.run_deepseek_agent("持续发起工具调用也必须在轮数上限退出")

    fake_sdk.assert_closed(caught.value)
    fake_sdk.assert_untouched()
    assert len(fake_sdk.requests) == 8
    assert len(fake_sdk.invocations) == 8
    assert all(call.name == "get_order" and result.ok for call, _context, result in fake_sdk.invocations)


@pytest.mark.parametrize("answer", ["y", "yes", " Y "], ids=["y", "yes", "normalized-y"])
@async_test
async def test_agent_fragmented_integer_transfer_approved_in_tty(
    fake_sdk: FakeSDK, capsys: pytest.CaptureFixture[str], answer: str
) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = [answer]
    raw = json.dumps(agent_transfer_arguments())
    fake_sdk.rounds = [
        [
            SimpleNamespace(choices=[]),
            stream_chunk(calls=[stream_call(0, call_id="call_fragmented", name="trans", arguments=raw[:20])]),
            stream_chunk(calls=[stream_call(0, name="fer", arguments=raw[20:60])]),
            stream_chunk(calls=[stream_call(0, arguments=raw[60:])]),
            stream_chunk(finish_reason="tool_calls"),
        ],
        [stream_chunk(content="已依据工具结果完成。"), stream_chunk(finish_reason="stop")],
    ]

    await demo.run_deepseek_agent("模拟转账，金额为整数 100")

    fake_sdk.assert_closed()
    assert len(fake_sdk.prompts) == 1
    assert [result.code for _call, _context, result in fake_sdk.invocations] == ["APPROVAL_REQUIRED", "OK"]
    assert all(call.tool_call_id == "call_fragmented" for call, _context, _result in fake_sdk.invocations)
    executed = fake_sdk.invocations[-1][2]
    assert executed.ok is True
    assert executed.content["amount"] == 100.0
    assert type(executed.content["amount"]) is float
    assert fake_sdk.tool_messages() == [executed.to_tool_message()]
    assert balance(FROM_ACCOUNT) == fake_sdk.account_snapshot[("tenant_a", FROM_ACCOUNT)] - 100
    assert balance(TO_ACCOUNT) == fake_sdk.account_snapshot[("tenant_a", TO_ACCOUNT)] + 100
    assert demo.SIDE_EFFECTS == fake_sdk.side_effect_snapshot
    assert len(fake_sdk.requests[0]["messages"]) == 2, "请求必须快照，不能保留后来突变的 messages 引用"
    assistant = next(message for message in fake_sdk.requests[1]["messages"] if message.get("tool_calls"))
    assert assistant["tool_calls"][0] == {
        "id": "call_fragmented",
        "type": "function",
        "function": {"name": TRANSFER, "arguments": raw},
    }
    output = capsys.readouterr().out
    for account in (FROM_ACCOUNT, TO_ACCOUNT):
        assert account not in json.dumps(fake_sdk.tool_messages())
        assert account not in fake_sdk.prompts[0]
        assert account not in output
        assert account not in repr(fake_sdk.audits[0].records)


@pytest.mark.parametrize(
    "tty,answer,expected_code",
    [
        (True, "n", "USER_REJECTED"),
        (True, "", "USER_REJECTED"),
        (True, EOFError("fake EOF"), "USER_REJECTED"),
        (False, "y", "INTERACTIVE_APPROVAL_REQUIRED"),
    ],
    ids=["tty-n", "tty-blank", "tty-eof", "non-tty-y"],
)
@pytest.mark.parametrize("repeat_location", ["same-round", "later-round"])
@async_test
async def test_agent_rejection_removes_transfer_and_never_asks_again(
    fake_sdk: FakeSDK, tty: bool, answer: str | BaseException, expected_code: str, repeat_location: str
) -> None:
    fake_sdk.tty = tty
    fake_sdk.answers = [answer]
    final = [stream_chunk(content="转账未执行。", finish_reason="stop")]
    if repeat_location == "same-round":
        fake_sdk.rounds = [transfer_stream("call_reject", "call_after_reject"), final]
    else:
        fake_sdk.rounds = [transfer_stream("call_reject"), transfer_stream("call_after_reject"), final]

    await demo.run_deepseek_agent("拒绝后模型继续尝试同一次请求的转账")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    assert len(fake_sdk.prompts) == (1 if tty else 0)
    assert len(fake_sdk.answers) == (0 if tty else 1)
    messages = fake_sdk.tool_messages()
    assert [message["tool_call_id"] for message in messages] == ["call_reject", "call_after_reject"]
    payloads = [json.loads(message["content"]) for message in messages]
    assert [payload["code"] for payload in payloads] == [expected_code, "TOOL_NOT_ALLOWED"]
    assert all(payload["ok"] is False and payload["action"] == "deny" for payload in payloads)
    if tty:
        assert "未执行" in str(payloads[0]["content"])
    assert [result.code for _call, _context, result in fake_sdk.invocations] == ["APPROVAL_REQUIRED", "TOOL_NOT_ALLOWED"]
    repeated_call, repeated_context, repeated_result = fake_sdk.invocations[-1]
    assert repeated_call.tool_call_id == "call_after_reject"
    assert repeated_context.allowed_tools == frozenset({"get_order"})
    assert messages[-1] == repeated_result.to_tool_message(), "后续拒绝必须来自真实 Runtime"
    for request in fake_sdk.requests[1:]:
        assert {tool["function"]["name"] for tool in request["tools"]} == {"get_order"}
    assert all(record.phase == "decision" for record in fake_sdk.audits[0].records)


@async_test
async def test_agent_text_only_stop_closes_client_without_tools(
    fake_sdk: FakeSDK, capsys: pytest.CaptureFixture[str]
) -> None:
    fake_sdk.rounds = [[stream_chunk(content="无需"), stream_chunk(content="调用工具。"), stream_chunk(finish_reason="stop")]]

    await demo.run_deepseek_agent("仅说明，不操作账户")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    assert capsys.readouterr().out == "无需调用工具。\n"
    assert len(fake_sdk.requests) == 1
    assert fake_sdk.invocations == []
    assert fake_sdk.prompts == []


@pytest.mark.parametrize("split", ["single-chunk", "character-chunks", *range(1, len(FROM_ACCOUNT))])
@async_test
async def test_agent_model_output_masks_accounts_across_stream_fragments(
    fake_sdk: FakeSDK, monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str], split: str | int,
) -> None:
    prefix = "转账未执行："
    middle = " → "
    suffix = "；其他账户 ACC-B-111111，联系 alice@example.com，订单 ord_1001。"
    text = prefix + FROM_ACCOUNT + middle + TO_ACCOUNT + suffix
    expected = (
        "转账未执行：ACC-A-****3456 → ACC-A-****4321；其他账户 ACC-B-****1111，"
        "联系 ***@***，订单 ord_1001。\n"
    )
    if split == "single-chunk":
        fragments = [text]
    elif split == "character-chunks":
        fragments = list(text)
    else:
        fragments = [
            prefix + FROM_ACCOUNT[:split],
            FROM_ACCOUNT[split:] + middle + TO_ACCOUNT[:split],
            TO_ACCOUNT[split:] + suffix,
        ]
    fake_sdk.rounds = [[
        *[stream_chunk(content=fragment) for fragment in fragments],
        stream_chunk(finish_reason="stop"),
    ]]
    printed: list[str] = []
    original_print = print

    def checked_print(*args: Any, **kwargs: Any) -> None:
        printed.append(kwargs.get("sep", " ").join(map(str, args)) + kwargs.get("end", "\n"))
        for account in (FROM_ACCOUNT, TO_ACCOUNT, "ACC-B-111111"):
            assert account[:8] not in "".join(printed)
        original_print(*args, **kwargs)

    monkeypatch.setattr("builtins.print", checked_print)

    await demo.run_deepseek_agent("模型可能复述原始账户")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    assert capsys.readouterr().out == expected
    assert "".join(printed) == expected
    assert fake_sdk.invocations == []


@pytest.mark.parametrize("tty", [True, False], ids=["user-rejected", "non-interactive"])
@async_test
async def test_agent_rejected_transfer_masks_model_reply(
    fake_sdk: FakeSDK, capsys: pytest.CaptureFixture[str], tty: bool,
) -> None:
    fake_sdk.tty = tty
    fake_sdk.answers = ["n" if tty else "y"]
    reply = f"转账未执行：从 {FROM_ACCOUNT} 到 {TO_ACCOUNT} 的 100 元转账没有发生。"
    fake_sdk.rounds = [
        transfer_stream("call_rejected_masking"),
        [*[stream_chunk(content=character) for character in reply], stream_chunk(finish_reason="stop")],
    ]

    await demo.run_deepseek_agent("请求模拟转账")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    expected_code = "USER_REJECTED" if tty else "INTERACTIVE_APPROVAL_REQUIRED"
    assert capsys.readouterr().out == (
        f"[tool_result] transfer {expected_code}\n"
        "转账未执行：从 ACC-A-****3456 到 ACC-A-****4321 的 100 元转账没有发生。\n"
    )
    assert len(fake_sdk.prompts) == (1 if tty else 0)
    assert all(record.phase == "decision" for record in fake_sdk.audits[0].records)
    assert json.loads(fake_sdk.tool_messages()[0]["content"])["code"] == expected_code


@async_test
async def test_agent_masks_text_before_tools_without_changing_provider_messages(
    fake_sdk: FakeSDK, capsys: pytest.CaptureFixture[str],
) -> None:
    raw_text = f"正在核对 {FROM_ACCOUNT} 的请求。"
    fake_sdk.rounds = [
        [*[stream_chunk(content=character) for character in raw_text], *order_stream()],
        [stream_chunk(content="已查询订单。", finish_reason="stop")],
    ]

    await demo.run_deepseek_agent("先说明再查询")

    fake_sdk.assert_closed()
    fake_sdk.assert_untouched()
    assert capsys.readouterr().out == "正在核对 ACC-A-****3456 的请求。\n[tool_result] get_order OK\n已查询订单。\n"
    assistant = next(message for message in fake_sdk.requests[1]["messages"] if message.get("tool_calls"))
    assert assistant["content"] == raw_text
    assert fake_sdk.invocations[0][2].code == "OK"


@pytest.mark.parametrize("ending", [None, "length", "content_filter", "exception"])
@async_test
async def test_agent_incomplete_model_text_never_prints_raw_accounts(
    fake_sdk: FakeSDK, capsys: pytest.CaptureFixture[str], ending: str | None,
) -> None:
    text = f"正在转账 {FROM_ACCOUNT} 到 {TO_ACCOUNT}"
    chunks = [stream_chunk(content=character) for character in text]
    chunks.append(RuntimeError("fake interrupted stream") if ending == "exception" else stream_chunk(finish_reason=ending))
    fake_sdk.rounds = [chunks]

    with pytest.raises(RuntimeError) as caught:
        await demo.run_deepseek_agent("不完整的模型输出")

    fake_sdk.assert_closed(caught.value)
    fake_sdk.assert_untouched()
    assert capsys.readouterr().out == ""
    assert fake_sdk.invocations == []


@pytest.mark.parametrize("finish_reason", [None, "length", "content_filter"], ids=["missing", "length", "content-filter"])
@pytest.mark.parametrize("response_kind", ["transfer", "text", "second-round-transfer"])
@async_test
async def test_agent_incomplete_stream_never_parses_or_executes_pending_calls(
    fake_sdk: FakeSDK, finish_reason: str | None, response_kind: str
) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = ["y"]
    if response_kind == "text":
        incomplete = [stream_chunk(content="尚未完整结束"), stream_chunk(finish_reason=finish_reason)]
    else:
        incomplete = transfer_stream("call_incomplete")
        incomplete[-1] = stream_chunk(finish_reason=finish_reason)
    fake_sdk.rounds = [order_stream(), incomplete] if response_kind == "second-round-transfer" else [incomplete]

    with pytest.raises(RuntimeError, match="流式响应未完整结束") as caught:
        await demo.run_deepseek_agent("完整 JSON 也不能绕过流完整性检查")

    fake_sdk.assert_closed(caught.value)
    fake_sdk.assert_untouched()
    assert fake_sdk.prompts == []
    assert all(call.name == "get_order" for call, _context, _result in fake_sdk.invocations)
    assert len(fake_sdk.invocations) == (1 if response_kind == "second-round-transfer" else 0)


@pytest.mark.parametrize("stage", ["first-stream", "second-stream", "request"])
@async_test
async def test_agent_sdk_exception_closes_client_without_executing_partial_transfer(
    fake_sdk: FakeSDK, stage: str
) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = ["y"]
    failure = RuntimeError("fake SDK interruption")
    partial: list[SimpleNamespace | BaseException] = [transfer_stream("call_interrupted")[0], failure]
    if stage == "request":
        fake_sdk.rounds = [failure]
    elif stage == "second-stream":
        fake_sdk.rounds = [order_stream(), partial]
    else:
        fake_sdk.rounds = [partial]

    with pytest.raises(RuntimeError, match="fake SDK interruption") as caught:
        await demo.run_deepseek_agent("中途异常不能执行已拼完参数的工具")

    assert caught.value is failure
    fake_sdk.assert_closed(failure)
    fake_sdk.assert_untouched()
    assert fake_sdk.prompts == []
    assert all(call.name == "get_order" for call, _context, _result in fake_sdk.invocations)
    assert len(fake_sdk.invocations) == (1 if stage == "second-stream" else 0)


@pytest.mark.parametrize("missing", ["id", "name"])
@async_test
async def test_agent_complete_tool_call_requires_id_and_name(fake_sdk: FakeSDK, missing: str) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = ["y"]
    fake_sdk.rounds = [[
        stream_chunk(calls=[stream_call(
            0,
            call_id=None if missing == "id" else "call_missing_name",
            name=None if missing == "name" else TRANSFER,
            arguments=json.dumps(agent_transfer_arguments()),
        )]),
        stream_chunk(finish_reason="tool_calls"),
    ]]

    with pytest.raises(RuntimeError, match="工具调用缺少") as caught:
        await demo.run_deepseek_agent("完整流中缺失标识不能伪造工具调用")

    fake_sdk.assert_closed(caught.value)
    fake_sdk.assert_untouched()
    assert fake_sdk.invocations == []
    assert fake_sdk.prompts == []


@async_test
async def test_agent_interleaved_multiple_calls_keep_runtime_result_ids(fake_sdk: FakeSDK) -> None:
    fake_sdk.tty = True
    fake_sdk.answers = ["yes"]
    raw_transfer = json.dumps(agent_transfer_arguments())
    fake_sdk.rounds = [
        [
            stream_chunk(content="先核对，再模拟转账。", calls=[stream_call(1, call_id="call_multi_order", name="get_", arguments='{"order_')]),
            stream_chunk(calls=[stream_call(0, call_id="call_multi_transfer", name="trans", arguments=raw_transfer[:40])]),
            stream_chunk(calls=[stream_call(1, name="order", arguments='id":"ord_1001"}')]),
            stream_chunk(calls=[stream_call(0, name="fer", arguments=raw_transfer[40:])]),
            stream_chunk(finish_reason="tool_calls"),
        ],
        [stream_chunk(content="已获得两个工具结果。", finish_reason="stop")],
    ]

    await demo.run_deepseek_agent("一次响应含多个交错碎片的工具调用")

    fake_sdk.assert_closed()
    assert len(fake_sdk.prompts) == 1
    assistant = next(message for message in fake_sdk.requests[1]["messages"] if message.get("tool_calls"))
    calls = assistant["tool_calls"]
    assert assistant["content"] == "先核对，再模拟转账。"
    assert [call["id"] for call in calls] == ["call_multi_transfer", "call_multi_order"]
    assert [call["function"]["name"] for call in calls] == [TRANSFER, "get_order"]
    assert json.loads(calls[0]["function"]["arguments"]) == agent_transfer_arguments()
    assert json.loads(calls[1]["function"]["arguments"]) == {"order_id": "ord_1001"}
    completed = [result for _call, _context, result in fake_sdk.invocations if result.ok]
    assert [result.tool_call_id for result in completed] == ["call_multi_transfer", "call_multi_order"]
    assert fake_sdk.tool_messages() == [result.to_tool_message() for result in completed]
    payloads = {message["tool_call_id"]: json.loads(message["content"]) for message in fake_sdk.tool_messages()}
    assert payloads["call_multi_transfer"]["content"]["amount"] == 100.0
    assert payloads["call_multi_order"]["content"]["status"] == "paid"
    assert all(payload["code"] == "OK" for payload in payloads.values())
    assert len(fake_sdk.requests[0]["messages"]) == 2
    assert balance(FROM_ACCOUNT) == fake_sdk.account_snapshot[("tenant_a", FROM_ACCOUNT)] - 100
    assert balance(TO_ACCOUNT) == fake_sdk.account_snapshot[("tenant_a", TO_ACCOUNT)] + 100


@async_test
async def test_offline_demo_repeated_runs_restore_state_and_mask_summaries(
    capsys: pytest.CaptureFixture[str],
) -> None:
    account_store = accounts()
    side_effect_store = demo.SIDE_EFFECTS
    account_store[("tenant_a", FROM_ACCOUNT)] += 777
    account_store[("tenant_c", "ACC-C-222222")] = 321.0
    side_effect_store.update(refund_executions=7, shell_executions=9, existing_marker=13)
    account_snapshot = dict(account_store)
    side_effect_snapshot = dict(side_effect_store)
    summaries = []

    for _run in range(2):
        await demo.run_offline_demo()
        output = capsys.readouterr().out
        documents = [json.loads(line) for line in output.splitlines() if line.strip()]
        summary = next(document for document in documents if "balances" in document)
        audit = next(document for document in documents if "audit_log" in document)
        summaries.append(summary)
        assert summary["balances"]["tenant_a/ACC-A-****3456"] == account_snapshot[("tenant_a", FROM_ACCOUNT)] - 1_200
        assert summary["balances"]["tenant_a/ACC-A-****4321"] == account_snapshot[("tenant_a", TO_ACCOUNT)] + 1_200
        assert summary["balances"]["tenant_c/ACC-C-****2222"] == 321.0
        assert any(record["phase"] == "execution" and record["tool_name"] == TRANSFER for record in audit["audit_log"])
        for _tenant, account in account_snapshot:
            assert account not in json.dumps(summary)
            assert account not in json.dumps(audit)
            assert account not in output
        assert accounts() is account_store and demo.SIDE_EFFECTS is side_effect_store
        assert account_store == account_snapshot
        assert side_effect_store == side_effect_snapshot

    assert summaries[0] == summaries[1], "离线演示重复运行不能累积扣款或副作用"


@pytest.mark.parametrize("failure_stage", ["execution", "report"])
@async_test
async def test_offline_demo_exception_restores_preexisting_accounts_and_side_effects(
    monkeypatch: pytest.MonkeyPatch, failure_stage: str
) -> None:
    account_store = accounts()
    side_effect_store = demo.SIDE_EFFECTS
    account_store[("tenant_a", FROM_ACCOUNT)] += 333
    account_store[("tenant_c", "ACC-C-222222")] = 456.0
    side_effect_store.update(refund_executions=4, shell_executions=6, existing_marker=8)
    account_snapshot = dict(account_store)
    side_effect_snapshot = dict(side_effect_store)
    original_invoke = demo.ToolRuntime.invoke
    failure = RuntimeError("fake offline failure after side effects")
    mutations_seen: list[bool] = []

    async def invoke(
        runtime: demo.ToolRuntime, call: demo.ToolCall, context: demo.ExecutionContext
    ) -> demo.ToolResult:
        result = await original_invoke(runtime, call, context)
        if call.name == TRANSFER and result.ok:
            assert account_store != account_snapshot
            assert side_effect_store["refund_executions"] == 1
            mutations_seen.append(True)
            if failure_stage == "execution":
                raise failure
        return result

    monkeypatch.setattr(demo.ToolRuntime, "invoke", invoke)
    if failure_stage == "report":
        original_print = print

        def print_with_failure(*args: Any, **kwargs: Any) -> None:
            if args and isinstance(args[0], str) and '"balances"' in args[0]:
                raise failure
            original_print(*args, **kwargs)

        monkeypatch.setattr("builtins.print", print_with_failure)

    with pytest.raises(RuntimeError, match="fake offline failure after side effects") as caught:
        await demo.run_offline_demo()

    assert caught.value is failure
    assert mutations_seen == [True]
    assert accounts() is account_store and demo.SIDE_EFFECTS is side_effect_store
    assert account_store == account_snapshot
    assert side_effect_store == side_effect_snapshot


@pytest.mark.parametrize("binding", ["expired", "user", "tenant", "recipient", "amount"])
@async_test
async def test_transfer_rejects_stale_or_mismatched_approval_binding(binding: str) -> None:
    runtime, approvals, audit = demo.build_runtime()
    arguments = {"from_account": FROM_ACCOUNT, "to_account": TO_ACCOUNT, "amount": 100.0}
    approvals.approve(
        APPROVAL_ID,
        transfer_context(),
        TRANSFER,
        arguments,
        ttl_seconds=-1 if binding == "expired" else 300,
    )
    overrides: dict[str, Any] = {"approval_id": APPROVAL_ID}
    attempted = dict(arguments)
    if binding == "user":
        overrides["user_id"] = "u_other"
    elif binding == "tenant":
        overrides["tenant_id"] = "tenant_b"
        # 同 ID 账户在另一租户也有余额，确保失败源于审批绑定而非余额预检。
        accounts()[("tenant_b", FROM_ACCOUNT)] = 100_000.0
        accounts()[("tenant_b", TO_ACCOUNT)] = 5_000.0
    elif binding == "recipient":
        attempted["to_account"] = SMALL_ACCOUNT
    elif binding == "amount":
        attempted["amount"] = 101.0
    snapshot = dict(accounts())

    result = await transfer(runtime, f"call_binding_{binding}", attempted, **overrides)

    assert result.ok is False
    assert result.action is demo.DecisionAction.CONFIRM
    assert result.code == "APPROVAL_REQUIRED"
    assert accounts() == snapshot
    assert [(record.phase, record.code) for record in audit.records] == [("decision", "APPROVAL_REQUIRED")]
    if binding != "expired":
        valid = await transfer(runtime, "call_binding_valid", arguments, approval_id=APPROVAL_ID)
        assert valid.ok is True, "参数或身份不匹配不能消耗原本有效的一次性审批"


@pytest.mark.parametrize(
    "mode,expected_action",
    [
        (demo.PermissionMode.BYPASS_PERMISSIONS, demo.DecisionAction.CONFIRM),
        (demo.PermissionMode.DONT_ASK, demo.DecisionAction.DENY),
    ],
)
@async_test
async def test_transfer_high_risk_approval_cannot_be_bypassed_by_modes(
    mode: demo.PermissionMode, expected_action: demo.DecisionAction
) -> None:
    runtime, _approvals, audit = demo.build_runtime()
    snapshot = dict(accounts())

    result = await transfer(runtime, "call_mode_no_approval", agent_transfer_arguments(), mode=mode)

    assert result.ok is False
    assert result.code == "APPROVAL_REQUIRED"
    assert result.action is expected_action
    assert accounts() == snapshot
    assert all(record.phase == "decision" for record in audit.records)
