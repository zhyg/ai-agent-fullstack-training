# Governed Transfer Tool

一个基于 Python 的工具治理教学项目，演示如何为 Agent 工具调用增加确定性治理边界，并接入一个模拟转账工具。

## 核心链路

所有工具调用统一经过 `ToolRuntime.invoke()`：

```text
参数校验 → 权限判断 → 业务预检 → 人工审批 → 超时与重试 → 结果脱敏 → 审计追踪
```

治理框架包括：

- Pydantic 严格参数模型，拒绝额外字段和非法参数。
- 固定优先级的权限状态机，覆盖 deny 规则、plan 只读模式、工具白名单和 RBAC。
- 与用户、租户、工具及参数摘要绑定的一次性审批。
- 按工具策略控制超时与重试，非幂等写操作不自动重试。
- 对工具结果中的令牌、邮箱和账号进行脱敏。
- 分别记录决策阶段与执行阶段的审计信息。

内置 `get_order`、`create_refund`、`run_shell` 和 `transfer` 四个工具。其中 Shell 与转账均为教学模拟，不执行真实系统命令或资金操作。

## 环境准备

需要 Python 3.11 或更高版本。

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 运行离线演示

离线演示不需要 API Key：

```bash
python tool_governance_demo.py
```

输出包含以下典型场景：

- 订单查询成功，敏感字段被脱敏。
- 高风险退款先返回 `CONFIRM / APPROVAL_REQUIRED`。
- 参数与审批一致时执行成功，篡改参数或重放审批会被拒绝。
- 额外注入参数返回 `INVALID_ARGUMENT`。
- deny 规则和 plan 只读模式能够阻止相应操作。
- 转账经过审批后更新模拟余额，工具结果、审计视图和余额摘要均使用脱敏账号。

离线演示仅临时修改模拟状态，成功或异常退出后均恢复运行前的账户余额与副作用计数；同一进程可以重复运行。

## 运行测试

运行完整回归测试：

```bash
python -m pytest tests -v
```

原题转账验收命令仍可使用：

```bash
python -m pytest tests/test_tool_governance.py -v -k "transfer"
```

保留原题 5 个验收测试，并覆盖账户与金额边界、审批绑定、整数金额规范化、非法参数根节点、流式分片、交互审批与拒绝、非交互输入、未完整结束的响应、资源关闭和离线状态恢复。

Agent 入口测试使用本地假 SDK，不需要 API Key，也不访问网络。测试会还原账户与输入环境，可重复运行；真实 DeepSeek 服务仍需单独验证。

## 可选：运行 DeepSeek Agent Loop

设置环境变量后运行：

```bash
export DEEPSEEK_API_KEY="你的密钥"
python tool_governance_demo.py --agent --input "请查询订单 ord_1001 的状态和可退金额"
```

可选环境变量：

- `DEEPSEEK_BASE_URL`：默认 `https://api.deepseek.com`
- `DEEPSEEK_MODEL`：默认 `deepseek-v4-flash`

这是单次请求入口，不是持续聊天会话；模型最终回答后程序结束。转账示例：

```bash
python tool_governance_demo.py --agent --input "请从 ACC-A-123456 转 100 元到 ACC-A-654321"
```

真实 Agent 入口只向模型开放 `get_order` 和 `transfer`，不会开放退款或 Shell。模型发起转账时，Runtime 先返回 `APPROVAL_REQUIRED`：

- 仅在标准输入为终端时展示脱敏参数，接受 `y` 或 `yes` 人工确认；审批与校验后的参数绑定，再经 Runtime 执行。
- 输入 `n`、直接回车、其他内容或 EOF，回填 `DENY / USER_REJECTED`，明确交易未执行。
- 管道、重定向等非交互输入返回 `DENY / INTERACTIVE_APPROVAL_REQUIRED`，即使输入内容为 `y` 也不批准。
- 拒绝后，本次请求移除转账能力，不会再次提示批准或执行转账；如需转账，请重新运行命令。

模型文本每轮完整拼接后，统一对账号和邮箱脱敏再打印，避免跨流式分片泄露；终端不再逐片显示模型文本。此规则同时覆盖最终回答和工具调用前的说明，不改变发给 SDK 的内部消息。响应异常时，本轮缓存文本不输出。

非法 JSON 或非对象工具参数返回 `INVALID_ARGUMENT`。流式响应只有收到正常结束标记后才允许执行工具；响应中断、达到长度限制或缺少工具调用 ID/名称时，本轮不执行工具并报错。客户端在正常与异常退出时均关闭。

## 项目结构

```text
.
├── tool_governance_demo.py       # 治理框架、工具实现与运行入口
├── tests/
│   ├── conftest.py               # 测试导入路径
│   └── test_tool_governance.py   # 转账工具验收测试
├── requirements.txt
└── pytest.ini
```

## 教学边界

本项目使用模块级内存字典保存账户余额，不具备持久化、数据库事务、分布式并发控制或业务幂等能力。金额使用 `float`，交易号也是演示实现。一次性审批只防止同一份审批被重放，不等同于交易幂等。它适合学习 Agent 工具治理，不应直接用于真实资金系统。
