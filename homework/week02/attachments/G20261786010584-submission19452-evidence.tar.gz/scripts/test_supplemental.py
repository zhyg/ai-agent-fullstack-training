"""Teacher supplemental contract checks; student source and original assertions unchanged."""
import asyncio
import dataclasses
import inspect
import json
import time

import pytest
import tool_governance_demo as d

F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}


@pytest.fixture(autouse=True)
def isolated():
    before = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(before)


def ctx(**kw):
    return d.base_context(**{'permissions': frozenset({'transfer:execute', 'order:read'}),
                            'allowed_tools': frozenset({'transfer', 'get_order'}), **kw})


def args(**kw):
    return {'from_account': F, 'to_account': T, 'amount': 1200.0, **kw}


def invoke(a, approved=False, **context):
    runtime, approvals, audit = d.build_runtime()
    c = ctx(**context)
    if approved:
        approvals.approve('a1', c, 'transfer', a)
        c = dataclasses.replace(c, approval_id='a1')
    started = time.perf_counter()
    result = asyncio.run(runtime.invoke(d.ToolCall('probe_000003', 'transfer', a), c))
    elapsed = time.perf_counter() - started
    print(json.dumps({'args': a, 'approved': approved, 'result': dataclasses.asdict(result),
                      'action': result.action.value, 'code': result.code, 'elapsed': elapsed,
                      'audit': [dataclasses.asdict(x) for x in audit.records],
                      'balances': {str(k): v for k, v in d.ACCOUNTS.items()},
                      'approval': approvals._records}, ensure_ascii=False, default=str))
    return result, audit, approvals, elapsed


def test_A01_initial():
    assert d.ACCOUNTS == INITIAL
    assert all(type(x) is float for x in d.ACCOUNTS.values())


@pytest.mark.parametrize('change', [
    {'from_account': None}, {'to_account': None}, {'amount': None},
    {'approved': True}, {'user_id': 'admin'}, {'amount': -1.0},
    {'amount': '1200'}, {'amount': True}, {'from_account': 'ACC-123456'},
    {'to_account': 'ACC-a-123456'}, {'to_account': 'ACC-A-1234567'},
    {'from_account': 'ACC-A-123456\n'}])
def test_A02_strict_and_schema(change):
    a = args(**change)
    a = {k: v for k, v in a.items() if v is not None}
    r, _, _, _ = invoke(a)
    assert d.ACCOUNTS == INITIAL
    assert r.code == 'INVALID_ARGUMENT'


@pytest.mark.parametrize('amount,expected', [
    (50000.0, 'APPROVAL_REQUIRED'), (50000.01, 'EXCEED_LIMIT'),
    (80000.0, 'EXCEED_LIMIT'), (80000.01, 'APPROVAL_REQUIRED'),
    (100000.0, 'APPROVAL_REQUIRED'), (100000.01, 'INVALID_ARGUMENT')])
def test_A03_unapproved_boundaries(amount, expected):
    r, audit, _, _ = invoke(args(amount=amount))
    assert d.ACCOUNTS == INITIAL
    assert r.code == expected
    assert audit.records[-1].phase == 'decision'


@pytest.mark.parametrize('amount', [80000.01, 100000.0])
def test_A03_approved_timeout(amount):
    r, audit, _, elapsed = invoke(args(amount=amount), approved=True)
    assert r.code == 'TIMEOUT_UNKNOWN'
    assert 0.4 <= elapsed < 3.0
    assert d.ACCOUNTS == INITIAL
    assert (audit.records[-1].phase, audit.records[-1].code) == ('execution', 'TIMEOUT_UNKNOWN')


@pytest.mark.parametrize('amount,expected', [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')])
@pytest.mark.parametrize('approved', [False, True])
def test_A04_precheck_order_and_read_only(amount, expected, approved):
    r, audit, approvals, _ = invoke(args(from_account=S, amount=amount), approved=approved)
    assert d.ACCOUNTS == INITIAL
    assert r.code == expected
    assert audit.records[-1].phase == 'decision'
    if approved:
        assert approvals._records['a1']['used'] is False


def test_A04_independent_consumption_evidence():
    r, _, approvals, _ = invoke(args(from_account=S, amount=30000.0), approved=True)
    assert r.code == 'INSUFFICIENT_BALANCE'
    assert approvals._records['a1']['used'] is False


def test_A05_full_balance():
    r, _, _, _ = invoke(args(from_account=S, amount=20000.0), approved=True)
    assert r.ok
    assert d.ACCOUNTS[('tenant_a', S)] == 0.0
    assert d.ACCOUNTS[('tenant_a', T)] == 25000.0


def test_A06_missing_destination():
    r, _, _, _ = invoke(args(to_account='ACC-A-999999'), approved=True)
    assert r.code == 'ACCOUNT_NOT_FOUND'
    assert d.ACCOUNTS == INITIAL
    # Error text is verified independently in static review: PolicyDenied's message is not exported.


@pytest.mark.parametrize('change,expected', [
    ({'from_account': B}, 'INSUFFICIENT_BALANCE'),
    ({'to_account': B}, 'ACCOUNT_NOT_FOUND')])
def test_A07_tenant_isolation(change, expected):
    r, _, _, _ = invoke(args(**change), approved=True)
    assert r.code == expected
    assert d.ACCOUNTS == INITIAL


def test_A07_tenant_b_success():
    d.ACCOUNTS[('tenant_b', 'ACC-B-222222')] = 700.0
    r, _, _, _ = invoke(args(from_account=B, to_account='ACC-B-222222', amount=3100.0),
                         approved=True, tenant_id='tenant_b')
    assert r.ok
    assert d.ACCOUNTS[('tenant_b', B)] == 46900.0
    assert d.ACCOUNTS[('tenant_b', 'ACC-B-222222')] == 3800.0
    assert d.ACCOUNTS[('tenant_a', F)] == 100000.0


def test_A08_binding_and_policy():
    r, _, _ = d.build_runtime()
    tool = next(t for t in r._tools if t.name == 'transfer')
    print('registration', tool, inspect.getsource(tool.handler))
    assert tool.parameters_model is d.TransferArgs
    assert tool.precheck is d.transfer_precheck
    assert tool.policy.effect is d.Effect.WRITE
    assert tool.policy.risk is d.Risk.HIGH
    assert tool.policy.permission == 'transfer:execute'
    assert tool.policy.max_retries == 0


@pytest.mark.parametrize('change', [{'from_account': S}, {'to_account': S}, {'amount': 1201.0}])
def test_A08_target_distinguishes_parameters(change):
    runtime, _, _ = d.build_runtime()
    tool = next(t for t in runtime._tools if t.name == 'transfer')
    first = tool.canonical_target(d.TransferArgs(**args()), ctx())
    second = tool.canonical_target(d.TransferArgs(**args(**change)), ctx())
    print('targets', first, second)
    assert first != second


def test_A09_transfer_and_order_redaction():
    r, _, _, _ = invoke(args(), approved=True)
    assert r.content == {'txn_id': '000003', 'from': 'ACC-A-****3456',
                         'to': 'ACC-A-****4321', 'amount': 1200.0, 'status': 'accepted'}
    runtime, _, _ = d.build_runtime()
    order = asyncio.run(runtime.invoke(d.ToolCall('query_1', 'get_order', {'order_id': 'ord_1001'}), ctx()))
    print('order', order.content)
    assert order.content['customer_email'] == '***@***'
    assert order.content['access_token'] == '***'


@pytest.mark.parametrize('payload,expected', [
    ({'note': '联系 buyer@example.com'}, {'note': '联系 ***@***'}),
    ({'nested': ['buyer@example.com']}, {'nested': ['***@***']}),
    ({'nested': [{'customer_email': 'buyer@example.com', 'password': 'example'}]},
     {'nested': [{'customer_email': '***@***', 'password': '***'}]}),
    ({'nested': ('buyer@example.com',)}, {'nested': ['***@***']}),
    ({'token': 'ACC-A-123456'}, {'token': '***'})])
def test_A09_original_recursive_redaction(payload, expected):
    actual = d._redact(payload)
    print('redaction', payload, actual, expected)
    assert actual == expected


def test_A09_account_in_nested_text():
    # Diagnostic of the same string-recursion defect, not a separate deduction.
    payload = {'rows': ['ACC-A-123456', {'note': '转入 ACC-A-654321'}]}
    actual = d._redact(payload)
    print('redaction', payload, actual)
    assert actual == {'rows': ['ACC-A-****3456', {'note': '转入 ACC-A-****4321'}]}


def test_A10_fixed_engine_present():
    assert hasattr(d.PermissionEngine, 'decide'), 'Fixed method removed, not a formatting change'


def test_A10_audit_correlation():
    _, audit, _, _ = invoke(args(), approved=True)
    fields = {x.name for x in dataclasses.fields(d.AuditRecord)}
    print('audit_fields', sorted(fields))
    assert {'tool_call_id', 'trace_id', 'tool_name', 'user_id', 'tenant_id'} <= fields


def test_approval_account_binding_and_replay():
    runtime, approvals, audit = d.build_runtime()
    approvals.approve('a1', ctx(), 'transfer', args())
    approved = ctx(approval_id='a1')
    async def run():
        tampered = await runtime.invoke(d.ToolCall('change_1', 'transfer', args(to_account=S)), approved)
        success = await runtime.invoke(d.ToolCall('probe_000003', 'transfer', args()), approved)
        replay = await runtime.invoke(d.ToolCall('replay_1', 'transfer', args()), approved)
        assert tampered.code == 'APPROVAL_REQUIRED'
        assert success.ok
        assert replay.code == 'APPROVAL_REQUIRED'
        assert d.ACCOUNTS[('tenant_a', F)] == 98800.0
    asyncio.run(run())
