import ast
import dataclasses
import hashlib
import importlib.metadata
import inspect
import json
from pathlib import Path
import platform

import tool_governance_demo as d

root = Path(__file__).resolve().parents[1]
student = Path(d.__file__).resolve()
reference = root / 'reference' / 'tool_governance_demo-无答案.py'

def method(path, cls, name):
    tree = ast.parse(path.read_text())
    node = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == cls)
    return next((x for x in node.body if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef))
                 and x.name == name), None)

original = method(reference, 'PermissionEngine', 'decide')
submitted = method(student, 'PermissionEngine', 'decide')
same_tests = ast.dump(ast.parse((root / 'source/student_test_tool_governance.py').read_text())) == ast.dump(
    ast.parse((root / 'reference/test_tool_governance.py').read_text()))
print(json.dumps({
    'python': platform.python_version(), 'platform': platform.platform(),
    'pydantic': importlib.metadata.version('pydantic'), 'pytest': importlib.metadata.version('pytest'),
    'actual_import': str(student),
    'source_sha256': hashlib.sha256(student.read_bytes()).hexdigest(),
    'source_equals_snapshot': student.read_bytes() == (root / 'source/tool_governance_demo.py').read_bytes(),
    'original_method_lines': [original.lineno, original.end_lineno],
    'submitted_decide_exists': submitted is not None,
    'normalized_decide_AST_equal': submitted is not None and ast.dump(original) == ast.dump(submitted),
    'student_tests_AST_equal_original': same_tests,
    'StrictArgs_config': d.StrictArgs.model_config, 'TransferArgs_config': d.TransferArgs.model_config,
    'AuditRecord_fields': [x.name for x in dataclasses.fields(d.AuditRecord)],
    'ToolPolicy_fields': [x.name for x in dataclasses.fields(d.ToolPolicy)],
    'run_offline_demo_exists': hasattr(d, 'run_offline_demo'),
}, ensure_ascii=False, indent=2))
for name in ['StrictArgs', 'TransferArgs', 'transfer_precheck', 'transfer_handler', '_run_transfer',
             '_builtin_tools', 'PermissionEngine', 'ToolRuntime', '_redact', '_redact_field', 'AuditRecord']:
    obj = getattr(d, name)
    print('\n###', name, 'line', inspect.getsourcelines(obj)[1])
    print(inspect.getsource(obj))
