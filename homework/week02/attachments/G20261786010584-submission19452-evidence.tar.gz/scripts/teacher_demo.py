"""Teacher-created observation, not a demo submitted by the student."""
import asyncio
import dataclasses
import json
import tool_governance_demo as d

async def main():
    d.reset_side_effects()
    runtime, approvals, audit = d.build_runtime()
    c = d.base_context(permissions=frozenset({'transfer:execute'}), allowed_tools=frozenset({'transfer'}))
    a = {'from_account': 'ACC-A-123456', 'to_account': 'ACC-A-654321', 'amount': 1200.0}
    pending = await runtime.invoke(d.ToolCall('demo_000001', 'transfer', a), c)
    print('pending', pending.action.value, pending.code)
    approvals.approve('manual_simulated', c, 'transfer', a)
    result = await runtime.invoke(d.ToolCall('demo_000003', 'transfer', a),
                                  dataclasses.replace(c, approval_id='manual_simulated'))
    print('result', json.dumps(result.to_model_payload(), ensure_ascii=False))
    print('audit', json.dumps([dataclasses.asdict(x) for x in audit.records], ensure_ascii=False))
    assert pending.action is d.DecisionAction.CONFIRM
    assert result.content['txn_id'] == '000003'
    assert result.content['from'] == 'ACC-A-****3456'
    assert result.content['to'] == 'ACC-A-****4321'
    d.reset_side_effects()

asyncio.run(main())
