#!/usr/bin/env bash
# Run from any directory, with Python environment containing requirements.txt.
# Every nonzero test exit is recorded; no failed assertion is modified or suppressed.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="${PYTHON:-python}"
export PYTHONPATH="$ROOT/source"
export PYTHONDONTWRITEBYTECODE=1
mkdir -p "$ROOT/logs"
run() {
    local label="$1"; shift
    printf 'COMMAND:' > "$ROOT/logs/$label.log"
    printf ' %q' "$@" >> "$ROOT/logs/$label.log"
    printf '\n' >> "$ROOT/logs/$label.log"
    "$@" >> "$ROOT/logs/$label.log" 2>&1
    local rc=$?
    echo "EXIT_CODE=$rc" >> "$ROOT/logs/$label.log"
    echo "$label EXIT_CODE=$rc"
}
run inspect "$PYTHON" "$ROOT/scripts/inspect_submission.py"
run original-five "$PYTHON" -m pytest -p no:cacheprovider "$ROOT/reference/test_tool_governance.py" -v -k transfer
run supplemental "$PYTHON" -m pytest -p no:cacheprovider "$ROOT/scripts/test_supplemental.py" -v -s
run submitted-demo "$PYTHON" "$ROOT/source/tool_governance_demo.py"
run teacher-demo "$PYTHON" "$ROOT/scripts/teacher_demo.py"
