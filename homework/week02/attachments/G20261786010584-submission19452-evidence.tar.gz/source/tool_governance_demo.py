"""本模块是工具调用治理运行时，负责决定模型调用能否执行。
已按代码更正：检查顺序为拒绝规则、白名单、计划模式、权限、参数校验、一次性审批、前置检查、处理函数。
写入副作用只在全部检查通过后写入内存退款账本。
返回内容会脱敏，含指令口吻时标记为不可信输出。
每次调用结束都记审计，包含调用编号、用户、租户和错误码。
命令执行类名称和未登记工具在授权之前就被拒绝。
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import re
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class PermissionMode(Enum):
    """区分可以执行和只能计划的两种模式。
    AGENT: 检查通过后允许读取和写入。
    PLAN: 允许读取，拒绝写入工具。
    """

    AGENT = "agent"
    PLAN = "plan"


class DecisionAction(Enum):
    """把一次调用结果归成放行、待确认或拒绝。
    ALLOW: 处理函数已成功执行。
    CONFIRM: 还需要一次性审批。
    DENY: 规则、权限或业务检查拒绝。
    """

    ALLOW = "allow"
    CONFIRM = "confirm"
    DENY = "deny"


class Effect(Enum):
    """表示工具会读取还是写入业务数据。
    READ: 只读取，不产生写入副作用。
    WRITE: 会新增或修改业务数据。
    """

    READ = "read"
    WRITE = "write"


class Risk(Enum):
    """表示工具操作的风险等级。
    LOW: 低风险，写入也不强制审批。
    MEDIUM: 中风险写入同样需要审批。
    HIGH: 高风险写入必须一次性审批。
    """

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PolicyDenied(Exception):
    """表示策略或业务规则拒绝本次执行。
    code: 返回给调用方的错误码。
    message: 写入异常信息的拒绝原因。
    content: 附加内容，返回前会脱敏。
    """

    def __init__(self, code: str, message: str, content: dict[str, Any] | None = None) -> None:
        """保存拒绝码、原因和附加内容。
        code: 返回给调用方的错误码。
        message: 写入异常信息的拒绝原因。
        content: 附加内容；空则存为空字典。
        """
        super().__init__(message)
        self.code = code
        self.message = message
        self.content = content or {}


class TransientToolError(Exception):
    """表示短时故障；写入工具不会因此重试。"""


@dataclass(frozen=True)
class ExecutionContext:
    """保存一次工具调用的调用者上下文。
    trace_id: 写入审计的链路编号。
    user_id: 发起调用的用户编号。
    tenant_id: 调用所属的租户编号。
    permissions: 调用者持有的权限点。
    allowed_tools: 本次允许调用的工具名。
    approval_id: 一次性审批编号，可为空。
    mode: 代理执行或计划模式。
    """

    trace_id: str
    user_id: str
    tenant_id: str
    permissions: frozenset[str]
    allowed_tools: frozenset[str]
    approval_id: str | None = None
    mode: PermissionMode = PermissionMode.AGENT
    tool_call_id: str = ""


@dataclass(frozen=True)
class ToolCall:
    """表示模型发出的一次工具调用。
    tool_call_id: 本次调用的唯一编号。
    name: 要调用的工具名。
    arguments: 模型给出的原始参数。
    """

    tool_call_id: str
    name: str
    arguments: dict[str, Any]


@dataclass(frozen=True)
class ToolPolicy:
    """描述单个工具的治理策略。
    effect: 读取或写入。
    risk: 低、中或高风险。
    permission: 执行所需的权限点。
    max_retries: 只读失败时的额外重试次数。
    """

    effect: Effect
    risk: Risk
    permission: str
    max_retries: int = 0


class StrictArgs(BaseModel):
    """参数模型基类，未声明字段会被拒绝。"""

    model_config = ConfigDict(extra="forbid")


class CreateRefundArgs(StrictArgs):
    """限定创建退款可以接收的字段。
    order_id: 要退款的订单编号。
    amount: 本次退款金额。
    reason: 本次退款原因。
    """

    order_id: str
    amount: float
    reason: str


class GetOrderArgs(StrictArgs):
    """限定查询订单可以接收的字段。
    order_id: 要查询的订单编号。
    """

    order_id: str


class TransferArgs(StrictArgs):
    """限定转账可以接收的字段。
    from_account: 转出账户编号，必须匹配 ^ACC-[A-Z]-[0-9]{6}$。
    to_account: 转入账户编号，必须匹配 ^ACC-[A-Z]-[0-9]{6}$。
    amount: 转账金额，必须大于 0 且不超过 100000。
    """

    from_account: str = Field(pattern=r"^ACC-[A-Z]-[0-9]{6}$")
    to_account: str = Field(pattern=r"^ACC-[A-Z]-[0-9]{6}$")
    amount: float = Field(gt=0, le=100000)


# 检查通过后执行的同步或异步处理函数。
Handler = Callable[..., dict[str, Any] | None | Awaitable[dict[str, Any] | None]]
# 执行前的同步或异步业务检查，失败时抛出策略拒绝。
Precheck = Callable[..., None | Awaitable[None]]
# 根据参数和上下文生成规范化操作目标。
CanonicalTarget = Callable[..., str]


@dataclass(frozen=True)
class ToolDefinition:
    """登记一个由运行时治理的工具。
    name: 工具名，也是调用时的查找键。
    description: 展示给模型的功能说明。
    parameters_model: 用来校验参数的模型。
    policy: 该工具的作用、风险和权限。
    handler: 全部检查通过后执行的函数。
    canonical_target: 生成规范化操作目标。
    precheck: 执行前的业务检查，可为空。
    """

    name: str
    description: str
    parameters_model: type[BaseModel]
    policy: ToolPolicy
    handler: Handler
    canonical_target: CanonicalTarget
    precheck: Precheck | None = None


@dataclass
class ToolResult:
    """表示一次工具调用的最终结果。
    ok: 为真表示处理函数已成功。
    content: 已脱敏的结果或错误内容。
    error_code: 失败时的错误码，成功为空。
    """

    ok: bool
    content: Any = None
    error_code: str | None = None

    @property
    def code(self) -> str | None:
        """对外错误码；成功且未另给码时为 OK。"""
        if self.ok and self.error_code is None:
            return "OK"
        return self.error_code

    @property
    def action(self) -> DecisionAction:
        """按成败和错误码映射放行、待确认或拒绝。"""
        if self.ok:
            return DecisionAction.ALLOW
        if self.code == "APPROVAL_REQUIRED":
            return DecisionAction.CONFIRM
        return DecisionAction.DENY

    def to_model_payload(self) -> dict[str, Any]:
        """组装交回模型的结果载荷。
        返回值: 含来源、不可信标记和内容。
        """
        return {
            "source": "tool",
            "untrusted": _contains_instruction(self.content),
            "content": self.content,
        }


@dataclass(frozen=True)
class AuditRecord:
    """一条可按阶段读取的审计记录。
    phase: decision 表示治理决定，execution 表示处理函数结果。
    code: 该阶段的错误码或 OK、APPROVED。
    """

    phase: str
    code: str


class AuditLog:
    """按调用结束的顺序保存审计记录。"""

    def __init__(self) -> None:
        """创建空的审计记录列表。"""
        self.records: list[AuditRecord] = []

    def add(self, record: AuditRecord) -> None:
        """追加一条调用审计记录。
        record: 含阶段和结果码。
        """
        self.records.append(record)


class ApprovalStore:
    """保存一次性审批，摘要绑定工具、调用者与参数。"""

    def __init__(self) -> None:
        """创建按审批编号索引的记录表。"""
        self._records: dict[str, dict[str, Any]] = {}

    def approve(
        self,
        approval_id: str,
        context: ExecutionContext,
        tool_name: str,
        arguments: Mapping[str, Any],
    ) -> None:
        """登记一条尚未使用的审批。
        approval_id: 审批编号。
        context: 提供获批的用户和租户。
        tool_name: 获批的工具名。
        arguments: 获批时的参数，摘要与调用时一致。
        """
        self._records[approval_id] = {
            "user_id": context.user_id,
            "tenant_id": context.tenant_id,
            "tool_name": tool_name,
            "digest": _approval_digest(tool_name, arguments),
            "used": False,
        }

    def consume(
        self,
        approval_id: str | None,
        *,
        user_id: str,
        tenant_id: str,
        tool_name: str,
        args: BaseModel,
    ) -> bool:
        """核销与本次调用完全匹配的审批。
        approval_id: 调用携带的审批编号。
        user_id: 当前用户编号。
        tenant_id: 当前租户编号。
        tool_name: 当前工具名。
        args: 本次校验后的参数。
        返回值: 匹配并成功核销时为真。
        """
        # 审批阶段，没有审批编号就不能核销。
        if not approval_id:
            # 缺少审批编号，本次消费失败。
            return False
        record = self._records.get(approval_id)
        # 审批阶段，缺失或已使用的记录不能再用。
        if record is None or record["used"]:
            # 审批不存在或已核销，拒绝本次消费。
            return False
        # 审批阶段，用户、租户或工具不一致则拒绝。
        if (
            record["user_id"] != user_id
            or record["tenant_id"] != tenant_id
            or record["tool_name"] != tool_name
        ):
            # 审批绑定的对象与本次调用不同。
            return False
        # 审批阶段，参数摘要变化说明确认后又改过。
        if record["digest"] != _approval_digest(tool_name, args):
            # 参数与获批时的摘要不一致。
            return False
        record["used"] = True
        return True


class PermissionEngine:
    """检查已登记工具的白名单、计划模式和权限。"""

    def authorize(self, tool: ToolDefinition, context: ExecutionContext) -> str | None:
        """判断已登记工具能否在当前上下文执行。
        tool: 已经登记的工具定义。
        context: 本次调用的身份和模式。
        返回值: 通过时为空，否则是错误码。
        """
        # 白名单阶段，工具名不在允许集合中。
        if tool.name not in context.allowed_tools:
            # 白名单未通过，返回不允许调用。
            return "TOOL_NOT_ALLOWED"
        # 计划模式阶段，写入工具不能真正执行。
        if context.mode is PermissionMode.PLAN and tool.policy.effect is Effect.WRITE:
            # 计划模式拒绝写入，避免产生副作用。
            return "PLAN_MODE_DENIED"
        # 权限阶段，调用者缺少该工具要求的权限点。
        if tool.policy.permission not in context.permissions:
            # 权限点不匹配，返回权限不足。
            return "PERMISSION_DENIED"
        return None


# 字段名含这些词时，值替换为固定掩码。
_SECRET_MARKERS = (
    "token",
    "api_key",
    "apikey",
    "cookie",
    "password",
    "secret",
    "authorization",
    "credential",
)
# 返回文本含这些词时，结果标记为不可信。
_INSTRUCTION_MARKERS = (
    "忽略",
    "此前指令",
    "系统提示",
    "ignore previous",
    "ignore all",
    "disregard",
)
# 这些名称，或名称中含 shell 时，直接拒绝。
_DENY_TOOL_NAMES = {"run_shell", "shell", "exec", "bash", "powershell"}

# 创建退款成功后写入的内存账本。
REFUNDS: dict[str, dict[str, Any]] = {}

_INITIAL_ACCOUNTS: dict[tuple[str, str], float] = {
    ("tenant_a", "ACC-A-123456"): 100000.0,
    ("tenant_a", "ACC-A-654321"): 5000.0,
    ("tenant_a", "ACC-A-888888"): 20000.0,
    ("tenant_b", "ACC-B-111111"): 50000.0,
}

# 查询订单使用的内存订单，含需要脱敏的字段。
_ORDERS: dict[str, dict[str, Any]] = {
    "ord_1001": {
        "order_id": "ord_1001",
        "status": "paid",
        "refundable": "399.00",
        "customer_email": "buyer@example.com",
        "access_token": "tok_live_secret",
    }
}

# 模拟账户余额，键为租户编号和账户编号。
ACCOUNTS: dict[tuple[str, str], float] = dict(_INITIAL_ACCOUNTS)


def _approval_digest(tool_name: str, args: Mapping[str, Any] | BaseModel) -> str:
    """计算审批要绑定的参数摘要。
    tool_name: 参与摘要的工具名。
    args: 模型或字典形式的参数。
    返回值: 规范化参数的十六进制摘要。
    """
    payload = {"tool": tool_name, "args": _json_ready(args)}
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _json_ready(args: Mapping[str, Any] | BaseModel) -> Any:
    """把参数变成键序稳定的可序列化对象。
    args: 参数模型或普通映射。
    返回值: 可按键排序后序列化的数据。
    """
    # 参数模型先导出，避免摘要受对象类型影响。
    if isinstance(args, BaseModel):
        # 导出为普通数据后参与摘要计算。
        return args.model_dump(mode="json")
    # 普通字典经排序序列化后再解析，消除键顺序差异。
    return json.loads(json.dumps(dict(args), ensure_ascii=False, sort_keys=True))


def _needs_approval(policy: ToolPolicy) -> bool:
    """判断该策略是否必须先取得审批。
    policy: 工具的治理策略。
    返回值: 写入且风险不是低时为真。
    """
    return policy.effect is Effect.WRITE and policy.risk is not Risk.LOW


def _is_deny_rule(tool_name: str) -> bool:
    """判断工具名是否命中内置拒绝规则。
    tool_name: 模型请求的工具名。
    返回值: 命令执行类名称命中时为真。
    """
    lowered = tool_name.lower()
    return lowered in _DENY_TOOL_NAMES or "shell" in lowered


def _redact(value: Any) -> Any:
    """按结构递归脱敏字典和列表。
    value: 待脱敏的任意结果。
    返回值: 脱敏后的同结构数据。
    """
    # 脱敏阶段，字典按字段名递归处理。
    if isinstance(value, dict):
        # 返回每个字段脱敏后的新字典。
        return {str(key): _redact_field(str(key), item) for key, item in value.items()}
    # 脱敏阶段，列表逐项递归处理。
    if isinstance(value, list):
        # 返回逐项脱敏后的新列表。
        return [_redact(item) for item in value]
    return value


def _redact_field(key: str, value: Any) -> Any:
    """按字段名决定一个字典项是否掩码。
    key: 字段名。
    value: 字段原值。
    返回值: 掩码，或继续递归后的值。
    """
    lowered = key.lower()
    # 脱敏阶段，邮箱字段替换为固定掩码。
    if "email" in lowered:
        # 不回传可识别的邮箱地址。
        return "***@***"
    # 脱敏阶段，整段账号保留前缀和末 4 位。
    if isinstance(value, str):
        masked = re.sub(
            r"^ACC-([A-Z])-\d{2}(\d{4})$",
            r"ACC-\g<1>-****\g<2>",
            value,
        )
        if masked != value:
            return masked
    # 脱敏阶段，密钥类字段名替换为固定掩码。
    if any(marker in lowered for marker in _SECRET_MARKERS):
        # 不回传令牌、密码或密钥原文。
        return "***"
    # 其他字段按原结构继续递归脱敏。
    return _redact(value)


def _contains_instruction(value: Any) -> bool:
    """检查内容是否含提示注入标记。
    value: 字符串或嵌套的字典、列表。
    返回值: 任一文本命中标记时为真。
    """
    # 字符串转成小写后匹配注入标记。
    if isinstance(value, str):
        lowered = value.lower()
        # 任一标记出现就视为不可信文本。
        return any(marker in lowered for marker in _INSTRUCTION_MARKERS)
    # 字典只要有一个值含标记即命中。
    if isinstance(value, dict):
        # 递归检查全部字段值。
        return any(_contains_instruction(item) for item in value.values())
    # 列表只要有一项含标记即命中。
    if isinstance(value, list):
        # 递归检查全部列表项。
        return any(_contains_instruction(item) for item in value)
    return False


async def _maybe_await(value: Any) -> Any:
    """执行可等待对象，普通值原样返回。
    value: 处理函数或前置检查的返回值。
    返回值: 等待完成后的实际结果。
    """
    # 协程或其他可等待对象要先取出结果。
    if inspect.isawaitable(value):
        # 等待结束后把实际结果交回调用方。
        return await value
    return value


async def _get_order(args: GetOrderArgs, _context: ExecutionContext) -> dict[str, Any]:
    """按订单号读取内置订单。
    args: 已校验的查询参数。
    _context: 本次调用上下文，此处不用。
    返回值: 订单字段的副本。
    异常 PolicyDenied: 订单不存在时抛出。
    """
    order = _ORDERS.get(args.order_id)
    # 查询阶段，订单不存在则按策略拒绝。
    if order is None:
        raise PolicyDenied("NOT_FOUND", "订单不存在", {})
    return dict(order)


async def _create_refund(args: CreateRefundArgs, context: ExecutionContext) -> dict[str, Any]:
    """在内存账本中新增一条退款。
    args: 已校验的退款参数。
    context: 提供用户和租户编号。
    返回值: 新退款编号和已创建状态。
    """
    refund_id = f"rf_{args.order_id}_{len(REFUNDS) + 1}"
    REFUNDS[refund_id] = {
        "refund_id": refund_id,
        "order_id": args.order_id,
        "amount": f"{args.amount:.2f}",
        "reason": args.reason,
        "user_id": context.user_id,
        "tenant_id": context.tenant_id,
    }
    return {"refund_id": refund_id, "status": "created"}


async def transfer_precheck(args: TransferArgs, context: ExecutionContext) -> None:
    """转账执行前的业务预检，只判断不改余额。
    args: 已校验的转账参数。
    context: 提供租户编号，用于定位账户。
    异常 PolicyDenied: 金额落在教学拦截区间，或转出账户余额不足。
    """
    if 50000 < args.amount <= 80000:
        raise PolicyDenied("EXCEED_LIMIT", "金额超过教学限额", {})
    balance = ACCOUNTS.get((context.tenant_id, args.from_account), 0.0)
    if balance < args.amount:
        raise PolicyDenied("INSUFFICIENT_BALANCE", "余额不足", {})


async def transfer_handler(
    tool_call_id: str,
    args: TransferArgs,
    context: ExecutionContext,
) -> dict[str, Any]:
    """执行转账并返回交易结果。
    tool_call_id: 本次调用编号，后 6 位作为交易号。
    args: 已校验的转账参数。
    context: 提供租户编号，用于定位账户。
    返回值: 含 txn_id、from、to、amount、status。
    异常 PolicyDenied: 转入账户不存在。
    """
    if args.amount > 80000:
        await asyncio.sleep(3.0)
    to_key = (context.tenant_id, args.to_account)
    if to_key not in ACCOUNTS:
        raise PolicyDenied("ACCOUNT_NOT_FOUND", "转入账户不存在")
    from_key = (context.tenant_id, args.from_account)
    ACCOUNTS[from_key] -= args.amount
    ACCOUNTS[to_key] += args.amount
    return {
        "txn_id": tool_call_id[-6:],
        "from": args.from_account,
        "to": args.to_account,
        "amount": args.amount,
        "status": "accepted",
    }


async def _run_transfer(args: TransferArgs, context: ExecutionContext) -> dict[str, Any]:
    """按运行时的两参数调用约定执行转账。
    args: 已校验的转账参数。
    context: 调用上下文，tool_call_id 用作交易号来源。
    返回值: transfer_handler 的交易结果。
    """
    return await transfer_handler(context.tool_call_id, args, context)


def _builtin_tools() -> list[ToolDefinition]:
    """返回查询订单、创建退款和转账三个内置工具。
    返回值: 供运行时登记的工具列表。
    """
    return [
        ToolDefinition(
            name="get_order",
            description="查询订单状态与可退金额。",
            parameters_model=GetOrderArgs,
            policy=ToolPolicy(effect=Effect.READ, risk=Risk.LOW, permission="order:read"),
            handler=_get_order,
            canonical_target=lambda args, _context: f"order:{args.order_id}",
        ),
        ToolDefinition(
            name="create_refund",
            description="为订单创建退款。",
            parameters_model=CreateRefundArgs,
            policy=ToolPolicy(
                effect=Effect.WRITE,
                risk=Risk.HIGH,
                permission="refund:create",
            ),
            handler=_create_refund,
            canonical_target=lambda args, context: f"refund:{context.tenant_id}:{args.order_id}",
        ),
        ToolDefinition(
            name="transfer",
            description="在同一租户的两个账户之间转账。",
            parameters_model=TransferArgs,
            policy=ToolPolicy(
                effect=Effect.WRITE,
                risk=Risk.HIGH,
                permission="transfer:execute",
            ),
            handler=_run_transfer,
            canonical_target=lambda args, context: f"transfer:{context.tenant_id}:{args.from_account}:{args.to_account}",
            precheck=transfer_precheck,
        ),
    ]


class ToolRuntime:
    """按固定顺序治理并执行工具调用。"""

    def __init__(
        self,
        tools: list[ToolDefinition],
        engine: PermissionEngine,
        approvals: ApprovalStore,
        audit: AuditLog,
    ) -> None:
        """保存工具表、授权器、审批存储和审计。
        tools: 允许登记的工具列表。
        engine: 白名单、计划和权限检查器。
        approvals: 一次性审批存储。
        audit: 调用审计日志。
        """
        self._tools = list(tools)
        self._by_name = {tool.name: tool for tool in self._tools}
        self._engine = engine
        self._approvals = approvals
        self._audit = audit

    def model_tools(self, context: ExecutionContext) -> list[dict[str, Any]]:
        """列出当前上下文可展示给模型的工具。
        context: 决定白名单的调用上下文。
        返回值: 不含实现和策略的函数规格。
        """
        visible: list[dict[str, Any]] = []
        # 发现阶段，逐个检查已登记工具能否展示。
        for tool in self._tools:
            # 不在白名单或命中拒绝规则的工具要跳过。
            if tool.name not in context.allowed_tools or _is_deny_rule(tool.name):
                continue
            visible.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.parameters_model.model_json_schema(),
                    },
                }
            )
        return visible

    async def invoke(self, call: ToolCall, context: ExecutionContext) -> ToolResult:
        """按治理顺序执行一次工具调用。
        call: 模型给出的工具名和原始参数。
        context: 身份、权限、模式和审批编号。
        返回值: 成功或失败的工具结果。
        """
        # 拒绝规则阶段，命令类或未登记工具直接失败。
        if _is_deny_rule(call.name) or call.name not in self._by_name:
            # 不进入授权和执行，直接返回拒绝规则。
            return self._finish(call, context, ok=False, error_code="DENY_RULE", content={})

        tool = self._by_name[call.name]
        denied = self._engine.authorize(tool, context)
        # 白名单、计划模式或权限有一项未通过。
        if denied is not None:
            # 授权失败，不校验参数，也不执行处理函数。
            return self._finish(call, context, ok=False, error_code=denied, content={})

        # 参数校验阶段，模型不接受就停止后续步骤。
        try:
            args = tool.parameters_model.model_validate(call.arguments)
        # 参数不合法时改为非法参数错误。
        except ValidationError:
            # 不消耗审批，也不写入退款账本。
            return self._finish(call, context, ok=False, error_code="INVALID_ARGUMENT", content={})

        # 审批阶段，高风险写入必须核销匹配的审批。
        if _needs_approval(tool.policy) and not self._approvals.consume(
            context.approval_id,
            user_id=context.user_id,
            tenant_id=context.tenant_id,
            tool_name=tool.name,
            args=args,
        ):
            # 审批缺失或不匹配，处理函数不会运行。
            return self._finish(call, context, ok=False, error_code="APPROVAL_REQUIRED", content={})

        if _needs_approval(tool.policy):
            self._audit.add(AuditRecord(phase="decision", code="APPROVED"))

        # 前置检查阶段，只有登记了检查函数才进入。
        if tool.precheck is not None:
            # 等待同步或异步前置检查完成。
            try:
                await _maybe_await(tool.precheck(args, context))
            # 业务拒绝在此截获，避免进入处理函数。
            except PolicyDenied as exc:
                # 脱敏拒绝内容后结束本次调用。
                return self._finish(
                    call,
                    context,
                    ok=False,
                    error_code=exc.code,
                    content=_redact(exc.content),
                    phase="execution",
                )

        # 计算规范化目标；当前实现没有使用返回值。
        tool.canonical_target(args, context)
        return await self._execute(tool, args, call, replace(context, tool_call_id=call.tool_call_id))

    async def _execute(
        self,
        tool: ToolDefinition,
        args: BaseModel,
        call: ToolCall,
        context: ExecutionContext,
    ) -> ToolResult:
        """在检查通过后调用处理函数。
        tool: 已选中的工具定义。
        args: 已通过校验的参数。
        call: 原始调用，用于记录调用编号。
        context: 传给处理函数的上下文。
        返回值: 成功、业务拒绝或临时失败。
        """
        retryable = tool.policy.effect is not Effect.WRITE
        # 写入只执行一次；只读次数为重试上限加一。
        attempts = tool.policy.max_retries + 1 if retryable else 1
        # 处理函数阶段，按上面算出的次数尝试执行。
        for _ in range(attempts):
            # 区分临时失败、业务拒绝和正常返回。
            try:
                produced = tool.handler(args, context)
                if inspect.isawaitable(produced):
                    outcome = await asyncio.wait_for(produced, timeout=0.5)
                else:
                    outcome = produced
            except asyncio.TimeoutError:
                return self._finish(
                    call,
                    context,
                    ok=False,
                    error_code="TIMEOUT_UNKNOWN",
                    content={},
                    phase="execution",
                )
            # 临时失败时，写入停止，只读继续下一次。
            except TransientToolError:
                # 写入不是幂等操作，不能再次执行。
                if not retryable:
                    break
                continue
            # 处理函数的业务拒绝要脱敏后立即返回。
            except PolicyDenied as exc:
                # 业务拒绝不再重试。
                return self._finish(
                    call,
                    context,
                    ok=False,
                    error_code=exc.code,
                    content=_redact(exc.content),
                    phase="execution",
                )
            # 非字典结果不回传，只对空内容脱敏。
            content = _redact(outcome if isinstance(outcome, dict) else {})
            # 执行成功后立即返回，不再消耗剩余次数。
            return self._finish(call, context, ok=True, error_code=None, content=content, phase="execution")
        # 重试次数用尽，或写入遇临时失败后返回。
        return self._finish(
            call,
            context,
            ok=False,
            error_code="TEMPORARY_UNAVAILABLE",
            content={},
            phase="execution",
        )

    def _finish(
        self,
        call: ToolCall,
        context: ExecutionContext,
        *,
        ok: bool,
        error_code: str | None,
        content: Any,
        phase: str = "decision",
    ) -> ToolResult:
        """写审计记录并返回最终工具结果。
        call: 提供调用编号和工具名。
        context: 提供链路、用户和租户。
        ok: 本次调用是否成功。
        error_code: 失败错误码，成功时为空。
        content: 已经准备好的返回内容。
        phase: decision 为治理决定，execution 为处理结果。
        返回值: 带同样成败和内容的结果。
        """
        result = ToolResult(ok=ok, error_code=error_code, content=content)
        self._audit.add(AuditRecord(phase=phase, code=result.code or ""))
        return result


def base_context(**overrides: Any) -> ExecutionContext:
    """构造一次调用的执行上下文。
    overrides: 覆盖权限、白名单、审批编号或模式。
    返回值: 带默认用户和租户的上下文。
    """
    values: dict[str, Any] = {
        "trace_id": "trace_test",
        "user_id": "u_100",
        "tenant_id": "tenant_a",
        "permissions": frozenset(),
        "allowed_tools": frozenset(),
    }
    values.update(overrides)
    return ExecutionContext(**values)


def reset_side_effects() -> None:
    """清空退款账本，并把模拟账户余额恢复为初始值。"""
    REFUNDS.clear()
    ACCOUNTS.clear()
    ACCOUNTS.update(_INITIAL_ACCOUNTS)


def build_runtime() -> tuple[ToolRuntime, ApprovalStore, AuditLog]:
    """组装运行时、审批存储和审计日志。
    返回值: 运行时、审批存储、审计日志。
    """
    return build_governance()


def build_governance() -> tuple[ToolRuntime, ApprovalStore, AuditLog]:
    """组装运行时、审批存储和审计日志。
    返回值: 运行时、审批存储、审计日志。
    """
    approvals = ApprovalStore()
    audit = AuditLog()
    runtime = ToolRuntime(_builtin_tools(), PermissionEngine(), approvals, audit)
    return runtime, approvals, audit
