"""自研工具治理运行时。

以职责划分与门禁顺序为语义规范，独立实现的最小治理闭环：
参数契约、策略声明、四种执行模式、一次性审批、写串行化、
副作用感知重试、结果脱敏与审计落盘。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping, Sequence
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Any, Protocol

from pydantic import BaseModel, ConfigDict, ValidationError


class StrictToolArgs(BaseModel):
    """全部受治理工具的参数契约基类：拒绝未声明字段并清理字符串空白。"""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class SideEffect(StrEnum):
    """副作用分类：读操作可安全重试，写操作必须串行并慎重重试。"""

    READ_ONLY = "read"
    MUTATING = "write"
    SYSTEM = "system"


class HazardLevel(StrEnum):
    """风险分级：为审批与审计策略提供依据。"""

    LOW = "low"
    HIGH = "high"


# 审批层级的全序：凭证层级必须不低于调用所需层级。
APPROVAL_LEVEL_ORDER = ("low", "high")


@dataclass(frozen=True)
class ApprovalTier:
    """金额分层审批阈值：参数金额达到阈值即要求对应层级。"""

    amount_field: str
    threshold: Decimal
    level: str


class GoverningMode(StrEnum):
    """执行模式：只能由服务端写入会话上下文，模型参数无权变更。"""

    STANDARD = "default"
    PLAN_ONLY = "plan"
    AUTO_BYPASS = "bypassConfirmation"
    SILENT = "dontAsk"


class OutcomeCode:
    """对外稳定的错误码契约，调用方与测试只依赖这些取值。"""

    INVALID_CALL = "INVALID_CALL"
    INVALID_CONTEXT = "INVALID_CONTEXT"
    INVALID_ARGUMENT = "INVALID_ARGUMENT"
    TOOL_NOT_ALLOWED = "TOOL_NOT_ALLOWED"
    DENY_RULE = "DENY_RULE"
    PLAN_MODE_DENIED = "PLAN_MODE_DENIED"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    APPROVAL_REQUIRED = "APPROVAL_REQUIRED"
    APPROVAL_FLOW_UNAVAILABLE = "APPROVAL_FLOW_UNAVAILABLE"
    APPROVAL_DECISION_DENIED = "APPROVAL_DECISION_DENIED"
    CONFIRMATION_REQUIRED = "CONFIRMATION_REQUIRED"
    CONFIRMATION_FLOW_UNAVAILABLE = "CONFIRMATION_FLOW_UNAVAILABLE"
    BUSINESS_RULE_DENIED = "BUSINESS_RULE_DENIED"
    IDEMPOTENCY_CONFLICT = "IDEMPOTENCY_CONFLICT"
    RATE_LIMITED = "RATE_LIMITED"
    TIMEOUT = "TIMEOUT"
    TIMEOUT_UNKNOWN = "TIMEOUT_UNKNOWN"
    TEMPORARY_UNAVAILABLE = "TEMPORARY_UNAVAILABLE"
    TOOL_ERROR = "TOOL_ERROR"


@dataclass(frozen=True)
class ToolCallRequest:
    """调用方传入的原始请求：调用标识、工具名与模型生成的参数。"""

    id: str
    name: str
    arguments: Mapping[str, Any]


@dataclass(frozen=True)
class SessionContext:
    """每次调用携带的可信身份与授权上下文，不接受模型自行声明权限。

    权限为（租户, 权限名）元组：授权是租户维度的，跨租户不生效。
    """

    trace_id: str
    user_id: str
    tenant_id: str
    permissions: frozenset[tuple[str, str]]
    allowed_tools: frozenset[str]
    approval_id: str | None = None
    idempotency_key: str | None = None
    mode: GoverningMode = GoverningMode.STANDARD


@dataclass(frozen=True)
class ToolGovernancePolicy:
    """单个工具的治理策略：副作用、风险、权限、审批、确认、超时与重试。"""

    effect: SideEffect
    risk: HazardLevel
    required_permission: str
    enabled: bool = True
    force_denied: bool = False
    needs_user_confirmation: bool = False
    needs_approval: bool = False
    approval_tiers: tuple[ApprovalTier, ...] = ()
    rate_limit: int | None = None
    rate_window_seconds: float = 60.0
    daily_cap_amount_field: str | None = None
    daily_cap: Decimal | None = None
    timeout_seconds: float = 3.0
    retry_budget: int = 0
    idempotent: bool = False

    def required_approval_level(self, args: StrictToolArgs) -> str:
        """按金额分层阈值计算本次调用所需的审批层级，默认最低层级。"""
        level = "low"
        for tier in self.approval_tiers:
            value = getattr(args, tier.amount_field, None)
            if isinstance(value, Decimal) and value >= tier.threshold:
                if APPROVAL_LEVEL_ORDER.index(tier.level) > APPROVAL_LEVEL_ORDER.index(level):
                    level = tier.level
        return level


ToolAction = Callable[[StrictToolArgs, SessionContext], Awaitable[dict[str, Any]]]
PrecheckFn = Callable[[StrictToolArgs, SessionContext], Awaitable[None]]
TargetKeyFn = Callable[[StrictToolArgs, SessionContext], str]
LockKeysFn = Callable[[StrictToolArgs, SessionContext], Sequence[str]]


@dataclass(frozen=True)
class RegisteredTool:
    """受控能力实体：契约、策略与处理器绑定后经注册表对外提供。

    写操作必须声明 `lock_keys`（多键串行化）或 `target_key`（单键快捷方式）
    之一：运行时按字典序统一加锁，处理器不自行加锁。
    """

    name: str
    description: str
    parameters_model: type[StrictToolArgs]
    policy: ToolGovernancePolicy
    action: ToolAction
    target_key: TargetKeyFn | None = None
    lock_keys: LockKeysFn | None = None
    precheck: PrecheckFn | None = None

    def public_projection(self) -> dict[str, Any]:
        """仅导出公开描述与参数 Schema，供模型发现可调用的受控工具。"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters_model.model_json_schema(),
            },
        }


@dataclass(frozen=True)
class AdmittedCall:
    """通过全部门禁后的内部对象：解析参数与已授权的工具定义。"""

    call: ToolCallRequest
    tool: RegisteredTool
    args: StrictToolArgs


@dataclass(frozen=True)
class ToolInvocationOutcome:
    """返回给调用方的安全结果：内容已脱敏，错误码为稳定契约。"""

    tool_call_id: str
    tool_name: str
    ok: bool
    content: Any
    error_code: str | None = None

    def to_model_message(self) -> dict[str, Any]:
        """工具结果是供模型参考的不可信数据，不能成为新的控制指令。"""
        return {
            "source": "tool",
            "tool_name": self.tool_name,
            "untrusted": True,
            "ok": self.ok,
            "error_code": self.error_code,
            "content": condense_for_model(self.content),
        }


class GovernanceViolation(Exception):
    """治理拒绝异常：携带稳定错误码，中断不满足门禁或业务规则的调用。"""

    def __init__(self, code: str, message: str, payload: Any | None = None):
        super().__init__(message)
        self.code = code
        self.payload = payload if payload is not None else {"message": message}


class TransientDependencyError(Exception):
    """瞬态依赖故障标记：仅在幂等边界内驱动退避重试。"""


def _canonicalize(value: Any) -> Any:
    """递归规范化参数，消除键序与 Decimal 表示差异，生成稳定摘要。"""
    if isinstance(value, BaseModel):
        # 使用 python 模式保留 Decimal 类型，交由下方分支做两位小数归一化。
        return _canonicalize(value.model_dump(mode="python"))
    if isinstance(value, Mapping):
        return {str(key): _canonicalize(value[key]) for key in sorted(value, key=str)}
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    if isinstance(value, Decimal):
        # 金额按两位小数归一化：300.0 与 300.00 生成同一摘要。
        try:
            return str(value.quantize(Decimal("0.01")))
        except InvalidOperation:
            return str(value)
    return value


def request_digest(tool_name: str, args: StrictToolArgs | Mapping[str, Any], level: str = "low") -> str:
    """将工具名、审批层级与全部参数绑定：金额、收款方或层级任何变化都会使摘要失配。"""
    canonical = json.dumps(_canonicalize(args), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(f"{tool_name}:{level}:{canonical}".encode()).hexdigest()


class AccessDecision(StrEnum):
    ALLOWED = "allow"
    BLOCKED = "deny"


class AccessDecider:
    """调用前授权决策：白名单与 RBAC 是任何模式都不可跳过的硬边界。"""

    def decide(self, tool: RegisteredTool, ctx: SessionContext) -> AccessDecision:
        if tool.name not in ctx.allowed_tools:
            return AccessDecision.BLOCKED
        if (ctx.tenant_id, tool.policy.required_permission) not in ctx.permissions:
            return AccessDecision.BLOCKED
        return AccessDecision.ALLOWED


# 识别令牌、密钥、密码与会话等敏感字段的匹配规则。
SENSITIVE_FIELD = re.compile(
    r"token|secret|password|authorization|api_?key|credential|cookie|session|private_?key|access_?key|phone|mobile|id_?card|passport",
    re.IGNORECASE,
)
# 字符串值级的高敏模式：邮箱、18 位身份证号、中国大陆手机号。
EMAIL_PATTERN = re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}")
ID_CARD_PATTERN = re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)")
PHONE_PATTERN = re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")
# 模型投影中剥离一切控制字符，防止不可见载荷进入模型上下文。
CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
MODEL_PROJECTION_MAX_DEPTH = 8
MODEL_PROJECTION_MAX_ITEMS = 50
MODEL_PROJECTION_MAX_TEXT = 2_000


def argument_key_names(arguments: Any) -> list[str]:
    """审计只保留参数键名；畸形请求也不能因记录审计再次触发内部异常。"""
    if isinstance(arguments, Mapping):
        return sorted(str(key) for key in arguments)
    return []


def mask_sensitive(value: Any) -> Any:
    """递归脱敏：敏感键置为掩码，字符串中的邮箱被打码。"""
    if isinstance(value, Mapping):
        return {
            str(key): "***" if SENSITIVE_FIELD.search(str(key)) else mask_sensitive(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [mask_sensitive(item) for item in value]
    if isinstance(value, tuple):
        return tuple(mask_sensitive(item) for item in value)
    if isinstance(value, str):
        masked = ID_CARD_PATTERN.sub("***", value)
        masked = PHONE_PATTERN.sub("***", masked)
        return EMAIL_PATTERN.sub("***@***", masked)
    return value


def condense_for_model(value: Any, *, depth: int = 0) -> Any:
    """对不可信工具结果脱敏并限制规模，防止挤占上下文或伪装为指令。"""
    if depth >= MODEL_PROJECTION_MAX_DEPTH:
        return "[内容嵌套过深，已截断]"
    if isinstance(value, Mapping):
        items = list(value.items())
        projected = {
            str(key): condense_for_model(item, depth=depth + 1)
            for key, item in items[:MODEL_PROJECTION_MAX_ITEMS]
        }
        if len(items) > MODEL_PROJECTION_MAX_ITEMS:
            projected["_truncated"] = "[字段过多，已截断]"
        return mask_sensitive(projected)
    if isinstance(value, (list, tuple)):
        projected = [
            condense_for_model(item, depth=depth + 1)
            for item in list(value)[:MODEL_PROJECTION_MAX_ITEMS]
        ]
        if len(value) > MODEL_PROJECTION_MAX_ITEMS:
            projected.append("[项目过多，已截断]")
        return mask_sensitive(projected)
    if isinstance(value, str):
        text = CONTROL_CHARS.sub("", value)
        projected = text[:MODEL_PROJECTION_MAX_TEXT]
        if len(text) > MODEL_PROJECTION_MAX_TEXT:
            projected += "[文本过长，已截断]"
        return mask_sensitive(projected)
    return mask_sensitive(value)


class LockPort(Protocol):
    """写串行化端口契约：运行时只依赖此协议，实现可替换。

    语义约定：键去重并按字典序排序、全部键获取成功才持有（任一失败即
    释放已获键并重试）、持有带 TTL 且过期后可被接管、释放只对持有者生效、
    获取超时抛 TEMPORARY_UNAVAILABLE。
    """

    @asynccontextmanager
    async def locked(self, keys: Sequence[str]) -> AsyncIterator[None]: ...


class InProcessLockManager:
    """进程内写串行化端口实现：按字典序获取多把锁，引用计数回收锁表。"""

    def __init__(self) -> None:
        self._locks: dict[str, asyncio.Lock] = {}
        self._refs: dict[str, int] = {}

    @asynccontextmanager
    async def locked(self, keys: Sequence[str]) -> AsyncIterator[None]:
        ordered = sorted(set(keys))
        for key in ordered:
            self._refs[key] = self._refs.get(key, 0) + 1
        try:
            async with AsyncExitStack() as stack:
                for key in ordered:
                    await stack.enter_async_context(self._locks.setdefault(key, asyncio.Lock()))
                yield
        finally:
            for key in ordered:
                self._refs[key] -= 1
                if self._refs[key] <= 0:
                    self._refs.pop(key, None)
                    self._locks.pop(key, None)


class GovernedToolRuntime:
    """治理运行时：编排发现、门禁、受控执行、结果保护与审计闭环。"""

    def __init__(
        self,
        tools: Sequence[RegisteredTool],
        access: AccessDecider,
        approvals,
        audit,
        locks: LockPort | None = None,
        limits=None,
    ) -> None:
        names = [tool.name for tool in tools]
        if not all(isinstance(name, str) and name for name in names) or len(names) != len(set(names)):
            raise ValueError("工具名称必须非空且唯一")
        for tool in tools:
            if not issubclass(tool.parameters_model, StrictToolArgs):
                raise ValueError(f"工具 {tool.name} 的参数模型必须继承 StrictToolArgs")
            if tool.policy.timeout_seconds <= 0 or tool.policy.retry_budget < 0:
                raise ValueError(f"工具 {tool.name} 的超时或重试配置无效")
            if tool.policy.effect is not SideEffect.READ_ONLY:
                if (tool.target_key is None) == (tool.lock_keys is None):
                    raise ValueError(
                        f"工具 {tool.name} 的写操作必须且只能声明 lock_keys 或 target_key 之一"
                    )
            if (tool.policy.daily_cap is None) != (tool.policy.daily_cap_amount_field is None):
                raise ValueError(f"工具 {tool.name} 的日累计限额配置不完整")
            if tool.policy.rate_limit is not None and tool.policy.rate_limit <= 0:
                raise ValueError(f"工具 {tool.name} 的限频配置无效")
            if (
                tool.policy.rate_limit is not None or tool.policy.daily_cap is not None
            ) and limits is None:
                raise ValueError(f"工具 {tool.name} 声明了风控限额但未注入限额存储")
        self._tools: dict[str, RegisteredTool] = {tool.name: tool for tool in tools}
        self.access = access
        self.approvals = approvals
        self.audit = audit
        self.locks = locks if locks is not None else InProcessLockManager()
        self.limits = limits

    def visible_tools(self, ctx: SessionContext) -> list[dict[str, Any]]:
        """只向模型暴露当前上下文下可调用的工具，避免能力泄露。"""
        return [
            tool.public_projection()
            for tool in self._tools.values()
            if self.access.decide(tool, ctx) is AccessDecision.ALLOWED
        ]

    async def invoke(self, call: ToolCallRequest, ctx: SessionContext) -> ToolInvocationOutcome:
        """单次调用总编排：门禁 -> 受控执行 -> 异常归一化 -> 保护与审计。"""
        started_at = time.monotonic()
        try:
            prepared = await self._admit(call, ctx)
        except GovernanceViolation as exc:
            await self._record_rejection(call, ctx, exc, started_at)
            return ToolInvocationOutcome(
                tool_call_id=call.id,
                tool_name=call.name,
                ok=False,
                content=mask_sensitive(exc.payload),
                error_code=exc.code,
            )

        try:
            content = await self._dispatch(prepared, ctx)
        except GovernanceViolation as exc:
            return await self._conclude(prepared, ctx, ok=False, content=exc.payload, code=exc.code, started_at=started_at)
        except TimeoutError:
            if prepared.tool.policy.effect is SideEffect.READ_ONLY:
                code, message = OutcomeCode.TIMEOUT, "查询超时，可稍后重试"
            else:
                code, message = OutcomeCode.TIMEOUT_UNKNOWN, "写操作结果未知，请按业务单号查询或转人工"
            return await self._conclude(prepared, ctx, ok=False, content={"message": message}, code=code, started_at=started_at)
        except TransientDependencyError:
            return await self._conclude(
                prepared, ctx, ok=False,
                content={"message": "依赖暂时不可用，请稍后重试"},
                code=OutcomeCode.TEMPORARY_UNAVAILABLE, started_at=started_at,
            )
        except Exception:
            return await self._conclude(
                prepared, ctx, ok=False,
                content={"message": "工具执行失败，请联系人工处理"},
                code=OutcomeCode.TOOL_ERROR, started_at=started_at,
            )
        return await self._conclude(prepared, ctx, ok=True, content=content, code=None, started_at=started_at)

    async def invoke_batch(
        self, calls: Sequence[ToolCallRequest], ctx: SessionContext
    ) -> list[ToolInvocationOutcome]:
        """批量调度：纯读并发执行；混入写操作时保持调用方给定的因果顺序。"""
        has_write = any(
            (tool := self._tools.get(call.name)) is not None
            and tool.policy.effect is not SideEffect.READ_ONLY
            for call in calls
        )
        if has_write:
            return [await self.invoke(call, ctx) for call in calls]
        return list(await asyncio.gather(*(self.invoke(call, ctx) for call in calls)))

    async def _admit(self, call: ToolCallRequest, ctx: SessionContext) -> AdmittedCall:
        """门禁顺序：调用形状 -> deny/plan -> 白名单/RBAC -> 限频与日累计 -> 审批校验(不核销) -> 预检 -> 审批核销 -> 确认。"""
        if not isinstance(call.id, str) or not call.id or not isinstance(call.name, str) or not call.name:
            raise GovernanceViolation(OutcomeCode.INVALID_CALL, "工具调用标识和名称必须为非空字符串")
        if not isinstance(call.arguments, Mapping):
            raise GovernanceViolation(OutcomeCode.INVALID_ARGUMENT, "工具参数必须为对象")
        if not isinstance(ctx.mode, GoverningMode):
            raise GovernanceViolation(OutcomeCode.INVALID_CONTEXT, "执行模式无效")

        tool = self._tools.get(call.name)
        if tool is None:
            raise GovernanceViolation(OutcomeCode.TOOL_NOT_ALLOWED, f"工具 {call.name} 不在本轮白名单")

        try:
            args = tool.parameters_model.model_validate(call.arguments)
        except ValidationError as exc:
            errors = [
                {"path": ".".join(str(item) for item in item["loc"]), "message": item["msg"]}
                for item in exc.errors()
            ]
            raise GovernanceViolation(OutcomeCode.INVALID_ARGUMENT, "参数校验失败", errors) from exc

        if tool.policy.force_denied or not tool.policy.enabled:
            raise GovernanceViolation(OutcomeCode.DENY_RULE, "命中拒绝规则")
        if ctx.mode is GoverningMode.PLAN_ONLY and tool.policy.effect is not SideEffect.READ_ONLY:
            raise GovernanceViolation(OutcomeCode.PLAN_MODE_DENIED, "plan 模式禁止写操作")

        if self.access.decide(tool, ctx) is AccessDecision.BLOCKED:
            if tool.name not in ctx.allowed_tools:
                raise GovernanceViolation(OutcomeCode.TOOL_NOT_ALLOWED, f"工具 {call.name} 不在本轮白名单")
            raise GovernanceViolation(
                OutcomeCode.PERMISSION_DENIED, f"缺少权限 {tool.policy.required_permission}"
            )

        if self.limits is not None and tool.policy.rate_limit is not None:
            self.limits.check_rate(
                ctx.tenant_id, tool.name,
                limit=tool.policy.rate_limit,
                window_seconds=tool.policy.rate_window_seconds,
            )
        if self.limits is not None and tool.policy.daily_cap is not None:
            amount = getattr(args, tool.policy.daily_cap_amount_field, None)
            if (
                isinstance(amount, Decimal)
                and self.limits.daily_total(ctx.tenant_id) + amount > tool.policy.daily_cap
            ):
                raise GovernanceViolation(
                    OutcomeCode.RATE_LIMITED, "超出租户日累计转账限额"
                )

        if tool.policy.needs_approval:
            # 强制审批是硬边界：任何模式（含 bypassConfirmation）都不免除核销。
            if ctx.mode is GoverningMode.SILENT:
                raise GovernanceViolation(
                    OutcomeCode.APPROVAL_FLOW_UNAVAILABLE, "当前模式无法请求审批"
                )
            # 先只验不销：无有效凭证的调用在业务预检之前即被拒绝，
            # 避免预检错误信息向未授权调用方泄露账户存在性与余额线索。
            approval_replay = self.approvals.validate(
                ctx.approval_id,
                tool_name=tool.name,
                args=args,
                user_id=ctx.user_id,
                tenant_id=ctx.tenant_id,
                required_level=tool.policy.required_approval_level(args),
                idempotency_key=ctx.idempotency_key,
            )

        if tool.precheck is not None:
            await tool.precheck(args, ctx)

        if tool.policy.needs_approval and not approval_replay:
            # 预检通过后才核销；已落库的同键重放只返回原结果，不重复核销。
            # 核销先于资金执行且不回滚，保证同一凭证不会产生第二次副作用。
            self.approvals.consume(ctx.approval_id)

        if tool.policy.needs_user_confirmation:
            if ctx.mode is GoverningMode.SILENT:
                raise GovernanceViolation(
                    OutcomeCode.CONFIRMATION_FLOW_UNAVAILABLE, "当前模式无法请求用户确认"
                )
            if ctx.mode is not GoverningMode.AUTO_BYPASS:
                raise GovernanceViolation(OutcomeCode.CONFIRMATION_REQUIRED, "该操作需要用户确认")

        return AdmittedCall(call=call, tool=tool, args=args)

    async def _dispatch(self, prepared: AdmittedCall, ctx: SessionContext) -> dict[str, Any]:
        """读操作直接执行；写操作按策略声明的锁键经锁端口统一串行化。"""
        policy = prepared.tool.policy
        if policy.effect is SideEffect.READ_ONLY:
            return await self._run_with_retries(prepared, ctx)
        if prepared.tool.lock_keys is not None:
            keys = list(prepared.tool.lock_keys(prepared.args, ctx))
        else:
            keys = [prepared.tool.target_key(prepared.args, ctx)]
        async with self.locks.locked(keys):
            return await self._run_with_retries(prepared, ctx)

    async def _run_with_retries(self, prepared: AdmittedCall, ctx: SessionContext) -> dict[str, Any]:
        """只重试读操作或显式幂等的写操作，避免重复产生不可逆副作用。"""
        policy = prepared.tool.policy
        budget = policy.retry_budget if policy.effect is SideEffect.READ_ONLY or policy.idempotent else 0
        for attempt in range(budget + 1):
            try:
                return await self._run_once(prepared, ctx)
            except TransientDependencyError:
                if attempt == budget:
                    raise
                await asyncio.sleep(min(0.05 * (2**attempt), 0.4))
        raise AssertionError("unreachable")

    async def _run_once(self, prepared: AdmittedCall, ctx: SessionContext) -> dict[str, Any]:
        """在策略时限内执行一次处理器调用。"""
        async with asyncio.timeout(prepared.tool.policy.timeout_seconds):
            return await prepared.tool.action(prepared.args, ctx)

    async def _conclude(
        self,
        prepared: AdmittedCall,
        ctx: SessionContext,
        *,
        ok: bool,
        content: Mapping[str, Any],
        code: str | None,
        started_at: float,
    ) -> ToolInvocationOutcome:
        """脱敏、写结构化审计，并封装为安全的返回结果。"""
        policy = prepared.tool.policy
        safe_content = mask_sensitive(content)
        await self.audit.write(
            {
                "trace_id": ctx.trace_id,
                "tool_call_id": prepared.call.id,
                "tool_name": prepared.tool.name,
                "user_id": ctx.user_id,
                "tenant_id": ctx.tenant_id,
                "mode": ctx.mode.value,
                "effect": policy.effect.value,
                "risk": policy.risk.value,
                "ok": ok,
                "error_code": code,
                "duration_ms": round((time.monotonic() - started_at) * 1000, 2),
                "argument_keys": argument_key_names(prepared.call.arguments),
            }
        )
        return ToolInvocationOutcome(
            tool_call_id=prepared.call.id,
            tool_name=prepared.tool.name,
            ok=ok,
            content=safe_content,
            error_code=code,
        )

    async def _record_rejection(
        self,
        call: ToolCallRequest,
        ctx: SessionContext,
        exc: GovernanceViolation,
        started_at: float,
    ) -> None:
        """被门禁拒绝的调用同样落审计，保证失败路径可追踪。"""
        record = {
            "trace_id": ctx.trace_id,
            "tool_call_id": call.id,
            "tool_name": call.name,
            "user_id": ctx.user_id,
            "tenant_id": ctx.tenant_id,
            "mode": ctx.mode.value if isinstance(ctx.mode, GoverningMode) else str(ctx.mode),
            "ok": False,
            "error_code": exc.code,
            "duration_ms": round((time.monotonic() - started_at) * 1000, 2),
            "argument_keys": argument_key_names(call.arguments),
        }
        if exc.code == OutcomeCode.RATE_LIMITED:
            record["event"] = "rate_limited"
        await self.audit.write(record)
