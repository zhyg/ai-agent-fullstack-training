"""审批接入层：治理运行时对外 HTTP 服务，身份来自验证过的 OIDC 令牌。

裁决人身份一律取自已验证令牌的主体，请求体中的 decided_by 被忽略并落审计；
会话上下文（用户、租户、权限、模式）全部由服务端从令牌声明构建，
客户端不可自封权限，也不可指定执行模式。
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
import uuid
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Literal

import jwt
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from governance import (
    GoverningMode,
    GovernanceViolation,
    OutcomeCode,
    SessionContext,
    ToolCallRequest,
)
from signing import Ed25519GrantSigner
from storage import AccountLedger
from transfer_tool import (
    ReverseInstruction,
    TransferInstruction,
    TransferSystem,
    compose_transfer_system,
)

# 治理拒绝 -> HTTP 状态：授权类 403，参数 400，冲突 409，限频 429，业务规则 422。
_GOVERNANCE_HTTP_STATUS: dict[str, int] = {
    OutcomeCode.INVALID_CALL: 400,
    OutcomeCode.INVALID_CONTEXT: 400,
    OutcomeCode.INVALID_ARGUMENT: 400,
    OutcomeCode.TOOL_NOT_ALLOWED: 403,
    OutcomeCode.DENY_RULE: 403,
    OutcomeCode.PLAN_MODE_DENIED: 403,
    OutcomeCode.PERMISSION_DENIED: 403,
    OutcomeCode.APPROVAL_REQUIRED: 403,
    OutcomeCode.APPROVAL_FLOW_UNAVAILABLE: 403,
    OutcomeCode.APPROVAL_DECISION_DENIED: 403,
    OutcomeCode.CONFIRMATION_REQUIRED: 403,
    OutcomeCode.CONFIRMATION_FLOW_UNAVAILABLE: 403,
    OutcomeCode.BUSINESS_RULE_DENIED: 422,
    OutcomeCode.IDEMPOTENCY_CONFLICT: 409,
    OutcomeCode.RATE_LIMITED: 429,
    OutcomeCode.TIMEOUT: 503,
    OutcomeCode.TIMEOUT_UNKNOWN: 503,
    OutcomeCode.TEMPORARY_UNAVAILABLE: 503,
    OutcomeCode.TOOL_ERROR: 500,
}

_ARGS_MODELS: dict[str, type[BaseModel]] = {
    "execute_transfer": TransferInstruction,
    "reverse_transfer": ReverseInstruction,
}


class OidcVerifier:
    """OIDC 令牌验证端口：RS256 + issuer/audience/exp 校验，JWKS 带 TTL 缓存。

    缓存是验证器自身语义（与 fetcher 来源无关）：TTL 内重复验签复用缓存
    密钥集，过期后重新拉取；未知 kid 立即强制刷新一次以支持及时轮换。
    jwks_fetcher 可注入（测试用本地密钥充当身份提供者）；默认实现按
    jwks_uri 经 HTTP 拉取并设置请求超时，并发缓存刷新单飞。
    """

    def __init__(
        self,
        issuer: str,
        audience: str,
        *,
        jwks_uri: str | None = None,
        jwks_fetcher: Callable[[], Awaitable[dict[str, Any]]] | None = None,
        cache_ttl_seconds: float = 300.0,
        request_timeout_seconds: float = 5.0,
    ) -> None:
        if jwks_fetcher is None:
            if jwks_uri is None:
                raise ValueError("必须提供 jwks_uri 或 jwks_fetcher 之一")
            jwks_fetcher = self._make_http_fetcher(jwks_uri, request_timeout_seconds)
        self._issuer = issuer
        self._audience = audience
        self._fetch_jwks = jwks_fetcher
        self._cache_ttl = cache_ttl_seconds
        self._cache: dict[str, Any] = {"jwks": None, "at": 0.0}
        self._cache_lock = asyncio.Lock()

    def _make_http_fetcher(
        self, jwks_uri: str, timeout_seconds: float
    ) -> Callable[[], Awaitable[dict[str, Any]]]:
        import httpx

        async def fetch() -> dict[str, Any]:
            async with httpx.AsyncClient(timeout=timeout_seconds) as client:
                response = await client.get(jwks_uri)
                response.raise_for_status()
                return response.json()

        return fetch

    async def fetch_jwks(self, *, force_refresh: bool = False) -> dict[str, Any]:
        """拉取带 TTL 缓存的 JWKS，并发刷新单飞，避免缓存过期时请求风暴。"""
        now = time.monotonic()
        if (
            not force_refresh
            and self._cache["jwks"] is not None
            and now - self._cache["at"] <= self._cache_ttl
        ):
            return self._cache["jwks"]
        async with self._cache_lock:
            now = time.monotonic()
            if (
                not force_refresh
                and self._cache["jwks"] is not None
                and now - self._cache["at"] <= self._cache_ttl
            ):
                return self._cache["jwks"]
            jwks = await self._fetch_jwks()
            if not isinstance(jwks.get("keys"), list):
                raise jwt.InvalidKeyError("JWKS 缺少有效 keys 列表")
            self._cache["jwks"] = jwks
            self._cache["at"] = now
            return jwks

    @staticmethod
    def _select_key(jwks: dict[str, Any], kid: str | None) -> dict[str, Any] | None:
        keys = jwks.get("keys", [])
        key = next((item for item in keys if item.get("kid") == kid), None)
        if key is None and kid is None and len(keys) == 1:
            key = keys[0]
        return key

    async def verify(self, token: str) -> dict[str, Any]:
        """验证令牌；未知 kid 立即刷新一次 JWKS，以及时发现 IdP 密钥轮换。"""
        header = jwt.get_unverified_header(token)
        jwks = await self.fetch_jwks()
        key = self._select_key(jwks, header.get("kid"))
        if key is None:
            jwks = await self.fetch_jwks(force_refresh=True)
            key = self._select_key(jwks, header.get("kid"))
        if key is None:
            raise jwt.InvalidKeyError("令牌签名密钥不在 JWKS 中")
        public_key = jwt.algorithms.RSAAlgorithm.from_jwk(key)
        return jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            issuer=self._issuer,
            audience=self._audience,
            options={"verify_exp": True, "require": ["exp", "sub", "iss", "aud"]},
        )


@dataclass(frozen=True)
class Principal:
    """从已验证令牌声明构建的服务端身份：权限与租户全部来自声明映射。"""

    user_id: str
    tenant_id: str
    permissions: frozenset[tuple[str, str]]
    allowed_tools: frozenset[str]
    scopes: frozenset[str]


def principal_from_claims(claims: dict[str, Any], *, tenant_claim: str = "tenant_id") -> Principal:
    sub = claims.get("sub")
    tenant_id = claims.get(tenant_claim)
    if not isinstance(sub, str) or not sub or not isinstance(tenant_id, str) or not tenant_id:
        raise ValueError("令牌缺少有效的主体或租户声明")
    permissions = claims.get("permissions") or []
    tools = claims.get("tools") or []
    scopes = claims.get("scope") or ""
    return Principal(
        user_id=sub,
        tenant_id=tenant_id,
        permissions=frozenset((tenant_id, str(item)) for item in permissions),
        allowed_tools=frozenset(str(item) for item in tools),
        scopes=frozenset(item for item in str(scopes).split() if item),
    )


class InvokeBody(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    id: str = Field(min_length=1, max_length=128)
    name: str = Field(min_length=1, max_length=128)
    arguments: dict[str, Any]
    approval_id: str | None = Field(default=None, min_length=1, max_length=128)
    idempotency_key: str | None = Field(default=None, min_length=1, max_length=128)


class ApprovalRequestBody(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    grant_id: str = Field(min_length=1, max_length=128)
    tool_name: Literal["execute_transfer", "reverse_transfer"]
    args: dict[str, Any]
    ttl_seconds: int = Field(default=300, ge=1, le=86400)


class DecisionBody(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    # decided_by 允许出现在请求体中，但一律被忽略并以令牌主体裁决。
    decision: Literal["approved", "revoked"]
    reason: str = Field(min_length=1, max_length=500)
    decided_by: str | None = Field(default=None, min_length=1, max_length=128)


class ApproverBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max_level: Literal["low", "high"] = "high"
    active: bool = True


def create_app(
    system: TransferSystem,
    verifier: OidcVerifier,
    *,
    mode: GoverningMode | None = None,
    admin_scope: str = "approval.admin",
    tenant_claim: str = "tenant_id",
) -> FastAPI:
    """接入层应用工厂：注入组合根与身份验证器，模式来自服务端配置。"""
    if mode is None:
        mode = GoverningMode(os.environ.get("GOVERNING_MODE", GoverningMode.STANDARD.value))
    app = FastAPI(title="受治理转账工具接入层")

    @app.exception_handler(RequestValidationError)
    async def _invalid_body(request: Request, exc: RequestValidationError):
        # 请求体校验失败与运行时参数契约统一为 INVALID_ARGUMENT + 400。
        return JSONResponse(
            status_code=400,
            content={
                "ok": False,
                "error_code": OutcomeCode.INVALID_ARGUMENT,
                "content": {"message": "参数校验失败"},
            },
        )

    async def principal_from_request(request: Request) -> Principal:
        authorization = request.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="缺少 Bearer 令牌")
        try:
            claims = await verifier.verify(authorization[len("Bearer "):])
            return principal_from_claims(claims, tenant_claim=tenant_claim)
        except Exception as exc:  # jwt 各类异常统一 401，不泄露内部细节
            raise HTTPException(status_code=401, detail="令牌无效或已过期") from exc

    def session(
        principal: Principal = Depends(principal_from_request),
        approval_id: str | None = None,
        idempotency_key: str | None = None,
    ) -> SessionContext:
        return SessionContext(
            trace_id=f"http_{uuid.uuid4().hex[:12]}",
            user_id=principal.user_id,
            tenant_id=principal.tenant_id,
            permissions=principal.permissions,
            allowed_tools=principal.allowed_tools,
            approval_id=approval_id,
            idempotency_key=idempotency_key,
            mode=mode,
        )

    @app.get("/health/live")
    async def live():
        return {"status": "ok"}

    @app.get("/health/ready")
    async def ready():
        try:
            system.ledger.connection.execute("SELECT 1").fetchone()
        except Exception as exc:
            raise HTTPException(status_code=503, detail="账本存储不可用") from exc
        return {"status": "ready"}

    @app.get("/tools")
    async def list_tools(principal: Principal = Depends(principal_from_request)):
        ctx = session(principal)
        return {"tools": system.runtime.visible_tools(ctx)}

    @app.post("/invoke")
    async def invoke(body: InvokeBody, principal: Principal = Depends(principal_from_request)):
        ctx = session(principal, body.approval_id, body.idempotency_key)
        outcome = await system.runtime.invoke(
            ToolCallRequest(body.id, body.name, body.arguments), ctx
        )
        if outcome.ok:
            return {"ok": True, "error_code": None, "content": outcome.content}
        status = _GOVERNANCE_HTTP_STATUS.get(outcome.error_code, 500)
        return JSONResponse(
            status_code=status,
            content={"ok": False, "error_code": outcome.error_code, "content": outcome.content},
        )

    @app.post("/approvals/requests")
    async def request_approval(
        body: ApprovalRequestBody, principal: Principal = Depends(principal_from_request)
    ):
        model = _ARGS_MODELS.get(body.tool_name)
        if model is None:
            raise HTTPException(status_code=400, detail="未知的审批绑定工具")
        try:
            args = model.model_validate(body.args)
        except ValidationError as exc:
            raise HTTPException(status_code=400, detail="参数校验失败") from exc
        try:
            await system.request_approval(
                body.grant_id,
                user_id=principal.user_id,
                tenant_id=principal.tenant_id,
                args=args,
                tool_name=body.tool_name,
                ttl_seconds=body.ttl_seconds,
                requested_by=principal.user_id,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"grant_id": body.grant_id, "state": "pending"}

    @app.post("/approvals/{grant_id}/decision")
    async def decide_approval(
        grant_id: str, body: DecisionBody, principal: Principal = Depends(principal_from_request)
    ):
        if body.decided_by is not None and body.decided_by != principal.user_id:
            # 客户端试图声明裁决人：忽略并落审计，保证四眼原则绑定令牌身份。
            await system.audit.write(
                {
                    "event": "ignored_client_claim",
                    "claim": "decided_by",
                    "claimed_value": body.decided_by,
                    "decided_by_from_token": principal.user_id,
                    "grant_id": grant_id,
                    "tenant_id": principal.tenant_id,
                }
            )
        try:
            await system.decide_approval(
                grant_id, decision=body.decision, decided_by=principal.user_id, reason=body.reason
            )
        except GovernanceViolation as exc:
            raise HTTPException(
                status_code=403, detail={"error_code": exc.code, "message": str(exc)}
            ) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"grant_id": grant_id, "decision": body.decision}

    @app.put("/approvers/{approver_id}")
    async def manage_approver(
        approver_id: str, body: ApproverBody, principal: Principal = Depends(principal_from_request)
    ):
        if admin_scope not in principal.scopes:
            raise HTTPException(
                status_code=403,
                detail={"error_code": OutcomeCode.PERMISSION_DENIED, "message": "需要审批管理 scope"},
            )
        if body.active:
            try:
                system.register_approver(approver_id, principal.tenant_id, max_level=body.max_level)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        else:
            system.deactivate_approver(approver_id, principal.tenant_id)
        await system.audit.write(
            {
                "event": "approver_registered" if body.active else "approver_deactivated",
                "approver_id": approver_id,
                "tenant_id": principal.tenant_id,
                "decided_by": principal.user_id,
            }
        )
        return {"approver_id": approver_id, "active": body.active}

    return app


def build_signer_from_env() -> Ed25519GrantSigner:
    """按环境变量装配凭证签名器：GOVERNED_SIGNING_KEY 为 64 位十六进制
    Ed25519 私钥（可选 GOVERNED_SIGNING_KID 指定标识）。未配置时生成
    临时密钥并向 stderr 警告：重启后存量凭证将无法验签，多实例共享库
    必须注入同一私钥。
    """
    raw = os.environ.get("GOVERNED_SIGNING_KEY", "")
    if raw:
        kid = os.environ.get("GOVERNED_SIGNING_KID", "ed25519_001")
        try:
            return Ed25519GrantSigner(keys={kid: bytes.fromhex(raw)})
        except (ValueError, TypeError) as exc:
            raise ValueError(
                "GOVERNED_SIGNING_KEY 必须是 64 位十六进制 Ed25519 私钥"
            ) from exc
    print(
        "警告：未配置 GOVERNED_SIGNING_KEY，使用临时签名密钥——"
        "重启后既有审批凭证将无法验签，多实例部署必须注入同一私钥",
        file=sys.stderr,
    )
    return Ed25519GrantSigner.generate()


def build_app_from_env() -> FastAPI:
    """按环境变量装配生产应用：数据库路径、签名私钥与 OIDC 配置均来自部署环境。"""
    ledger = AccountLedger(db_path=os.environ.get("GOVERNED_DB_PATH") or None)
    system = compose_transfer_system(ledger, signer=build_signer_from_env())
    verifier = OidcVerifier(
        issuer=os.environ["OIDC_ISSUER"],
        audience=os.environ["OIDC_AUDIENCE"],
        jwks_uri=os.environ["OIDC_JWKS_URI"],
    )
    return create_app(system, verifier)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        build_app_from_env(),
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "8000")),
    )
