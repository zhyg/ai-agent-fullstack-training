"""治理端口的 SQLite 持久化实现。

账本与流水、幂等键、审批凭证、审计记录、咨询锁、风控计数与外发事件表共用
同一数据库文件；单笔转账的扣款、入账、借贷分录、流水、幂等键、日累计计数与
外发事件在同一事务内完成，失败即整体回滚。锁端口负责跨进程串行化，事务负责
原子性，二者职责分离。审批凭证签发时由签名端口对不可变字段签名，验签先于
状态判定。存储只经组合根注入，治理运行时与工具代码不感知存储介质。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import time
from collections.abc import Callable
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, AsyncIterator, Sequence
from uuid import uuid4

from governance import (
    APPROVAL_LEVEL_ORDER,
    GovernanceViolation,
    InProcessLockManager,
    OutcomeCode,
    request_digest,
)
from signing import GrantSigner, grant_signature_payload

SCHEMA_VERSION = 6
ACTIVE = "active"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    tenant_id TEXT NOT NULL,
    account TEXT NOT NULL,
    balance TEXT NOT NULL,
    status TEXT NOT NULL,
    opening TEXT NOT NULL DEFAULT '0',
    PRIMARY KEY (tenant_id, account)
);
CREATE TABLE IF NOT EXISTS transfers (
    tenant_id TEXT NOT NULL,
    transfer_id TEXT NOT NULL,
    business_ref TEXT NOT NULL,
    from_account TEXT NOT NULL,
    to_account TEXT NOT NULL,
    amount TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    original_transfer_id TEXT,
    PRIMARY KEY (tenant_id, transfer_id)
);
CREATE INDEX IF NOT EXISTS idx_transfers_business_ref ON transfers (tenant_id, business_ref);
CREATE INDEX IF NOT EXISTS idx_transfers_original ON transfers (tenant_id, original_transfer_id);
CREATE TABLE IF NOT EXISTS idempotency_keys (
    tenant_id TEXT NOT NULL,
    idempotency_key TEXT NOT NULL,
    params_digest TEXT NOT NULL,
    transfer_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (tenant_id, idempotency_key)
);
CREATE TABLE IF NOT EXISTS approval_grants (
    grant_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    digest TEXT NOT NULL,
    level TEXT NOT NULL,
    expires_at REAL NOT NULL,
    used INTEGER NOT NULL DEFAULT 0,
    state TEXT NOT NULL DEFAULT 'approved',
    issued_by TEXT NOT NULL,
    issued_at TEXT NOT NULL,
    decided_by TEXT,
    decided_at TEXT,
    reason TEXT,
    signature TEXT NOT NULL DEFAULT '',
    kid TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS audit_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    payload TEXT NOT NULL,
    prev_hash TEXT NOT NULL DEFAULT '',
    hash TEXT NOT NULL DEFAULT ''
);
CREATE TRIGGER IF NOT EXISTS audit_records_immutable_update
BEFORE UPDATE ON audit_records
BEGIN
    SELECT RAISE(ABORT, 'audit_records 不可修改');
END;
CREATE TRIGGER IF NOT EXISTS audit_records_immutable_delete
BEFORE DELETE ON audit_records
BEGIN
    SELECT RAISE(ABORT, 'audit_records 不可删除');
END;
CREATE TABLE IF NOT EXISTS seqs (
    name TEXT PRIMARY KEY,
    value INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS locks (
    scope_key TEXT PRIMARY KEY,
    owner TEXT NOT NULL,
    expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id TEXT NOT NULL,
    account TEXT NOT NULL,
    side TEXT NOT NULL,
    amount TEXT NOT NULL,
    transfer_id TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entries_account ON ledger_entries (tenant_id, account, id);
CREATE TABLE IF NOT EXISTS rate_limits (
    tenant_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    window_start REAL NOT NULL,
    count INTEGER NOT NULL,
    PRIMARY KEY (tenant_id, tool_name)
);
CREATE TABLE IF NOT EXISTS daily_usage (
    tenant_id TEXT NOT NULL,
    day TEXT NOT NULL,
    total TEXT NOT NULL,
    PRIMARY KEY (tenant_id, day)
);
CREATE TABLE IF NOT EXISTS approval_authorities (
    approver_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL,
    max_level TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (approver_id, tenant_id)
);
CREATE TABLE IF NOT EXISTS outbox_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL,
    published INTEGER NOT NULL DEFAULT 0,
    published_at TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    dead INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS replay_checkpoint (
    stream TEXT PRIMARY KEY,
    last_entry_id TEXT,
    snapshot_watermark INTEGER NOT NULL DEFAULT 0
);
"""

# v1 -> v2：新增咨询锁、分录与风控表，并为审批凭证补充生命周期列。
_MIGRATIONS: dict[int, list[str]] = {
    1: [
        "CREATE TABLE IF NOT EXISTS locks (scope_key TEXT PRIMARY KEY, owner TEXT NOT NULL, expires_at REAL NOT NULL)",
        "CREATE TABLE IF NOT EXISTS ledger_entries ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL, account TEXT NOT NULL, "
        "side TEXT NOT NULL, amount TEXT NOT NULL, transfer_id TEXT NOT NULL, created_at TEXT NOT NULL)",
        "CREATE INDEX IF NOT EXISTS idx_entries_account ON ledger_entries (tenant_id, account, id)",
        "CREATE TABLE IF NOT EXISTS rate_limits ("
        "tenant_id TEXT NOT NULL, tool_name TEXT NOT NULL, window_start REAL NOT NULL, count INTEGER NOT NULL, "
        "PRIMARY KEY (tenant_id, tool_name))",
        "CREATE TABLE IF NOT EXISTS daily_usage ("
        "tenant_id TEXT NOT NULL, day TEXT NOT NULL, total TEXT NOT NULL, PRIMARY KEY (tenant_id, day))",
        "ALTER TABLE approval_grants ADD COLUMN state TEXT NOT NULL DEFAULT 'approved'",
        "ALTER TABLE approval_grants ADD COLUMN decided_by TEXT",
        "ALTER TABLE approval_grants ADD COLUMN decided_at TEXT",
        "ALTER TABLE approval_grants ADD COLUMN reason TEXT",
    ],
    2: [
        "CREATE TABLE IF NOT EXISTS approval_authorities ("
        "approver_id TEXT NOT NULL, tenant_id TEXT NOT NULL, max_level TEXT NOT NULL, "
        "active INTEGER NOT NULL DEFAULT 1, PRIMARY KEY (approver_id, tenant_id))",
        "ALTER TABLE audit_records ADD COLUMN prev_hash TEXT NOT NULL DEFAULT ''",
        "ALTER TABLE audit_records ADD COLUMN hash TEXT NOT NULL DEFAULT ''",
    ],
    # v3 -> v4：转账流水补充冲正关联列，账户补充期初余额列。
    3: [
        "ALTER TABLE transfers ADD COLUMN original_transfer_id TEXT",
        "ALTER TABLE accounts ADD COLUMN opening TEXT NOT NULL DEFAULT '0'",
        "CREATE INDEX IF NOT EXISTS idx_transfers_original ON transfers (tenant_id, original_transfer_id)",
    ],
    # v4 -> v5：审批凭证补充签名列（存量凭证回填空签名，验签时一律拒绝），
    # 并新增事件外发表（Outbox 模式，与业务变更同事务写入）。
    4: [
        "ALTER TABLE approval_grants ADD COLUMN signature TEXT NOT NULL DEFAULT ''",
        "ALTER TABLE approval_grants ADD COLUMN kid TEXT NOT NULL DEFAULT ''",
        "CREATE TABLE IF NOT EXISTS outbox_events ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT NOT NULL UNIQUE, "
        "event_type TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL, "
        "published INTEGER NOT NULL DEFAULT 0, published_at TEXT)",
    ],
    # v5 -> v6：审计表安装不可变触发器（存储层拒绝 UPDATE/DELETE），外发表
    # 补充中继失败观测列，新增副本回放检查点表。
    5: [
        "ALTER TABLE outbox_events ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE outbox_events ADD COLUMN last_error TEXT",
        "ALTER TABLE outbox_events ADD COLUMN dead INTEGER NOT NULL DEFAULT 0",
        "CREATE TABLE IF NOT EXISTS replay_checkpoint ("
        "stream TEXT PRIMARY KEY, last_entry_id TEXT, snapshot_watermark INTEGER NOT NULL DEFAULT 0)",
        "CREATE TRIGGER IF NOT EXISTS audit_records_immutable_update "
        "BEFORE UPDATE ON audit_records BEGIN SELECT RAISE(ABORT, 'audit_records 不可修改'); END",
        "CREATE TRIGGER IF NOT EXISTS audit_records_immutable_delete "
        "BEFORE DELETE ON audit_records BEGIN SELECT RAISE(ABORT, 'audit_records 不可删除'); END",
    ],
}


def _audit_hash(prev_hash: str, payload: str) -> str:
    """审计哈希链单步：当前记录哈希 = sha256(前序哈希 + 规范化载荷)。"""
    return hashlib.sha256(f"{prev_hash}{payload}".encode("utf-8")).hexdigest()


def _storage_day(conn: sqlite3.Connection) -> str:
    """当前 UTC 日由存储侧时钟生成，与审批 TTL 和限频窗口保持一致。"""
    return conn.execute("SELECT strftime('%Y-%m-%d', 'now')").fetchone()[0]


def _backfill_audit_chain(conn: sqlite3.Connection) -> None:
    """迁移钩子：为存量审计记录按 id 顺序回填哈希链。"""
    rows = conn.execute("SELECT id, payload FROM audit_records ORDER BY id").fetchall()
    prev = ""
    with conn:
        for row in rows:
            digest = _audit_hash(prev, row["payload"])
            conn.execute(
                "UPDATE audit_records SET prev_hash = ?, hash = ? WHERE id = ?",
                (prev, digest, row["id"]),
            )
            prev = digest


def _backfill_openings(conn: sqlite3.Connection) -> None:
    """迁移钩子：回填期初余额 = 当前余额 - 既有分录净额，保证对账恒等式成立。

    无分录的账户期初即当前余额；有历史分录的账户期初为「分录记账起点时的余额」，
    这样「余额 = 期初 + 贷方 - 借方」对迁移前后的数据都成立。
    """
    rows = conn.execute("SELECT tenant_id, account, balance FROM accounts").fetchall()
    with conn:
        for row in rows:
            net = conn.execute(
                "SELECT COALESCE(SUM(CASE side WHEN 'credit' THEN amount ELSE -amount END), 0) "
                "AS net FROM ledger_entries WHERE tenant_id = ? AND account = ?",
                (row["tenant_id"], row["account"]),
            ).fetchone()
            opening = Decimal(row["balance"]) - Decimal(net["net"])
            conn.execute(
                "UPDATE accounts SET opening = ? WHERE tenant_id = ? AND account = ?",
                (format(opening, "f"), row["tenant_id"], row["account"]),
            )


# 每级迁移的语句列表之后执行的代码钩子（如存量数据回填）。
_POST_MIGRATIONS: dict[int, list[Callable[[sqlite3.Connection], None]]] = {
    2: [_backfill_audit_chain],
    3: [_backfill_openings],
}


def _write_outbox_event(conn: sqlite3.Connection, event_type: str, payload: dict[str, Any]) -> str:
    """在调用方事务内写入外发事件：与业务变更同事务提交，保证不漏发不幻发。"""
    event_id = f"evt_{uuid4().hex}"
    conn.execute(
        "INSERT INTO outbox_events (event_id, event_type, payload, created_at) "
        "VALUES (?, ?, ?, ?)",
        (
            event_id,
            event_type,
            json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
            datetime.now(timezone.utc).isoformat(),
        ),
    )
    return event_id


def _ensure_schema(conn: sqlite3.Connection) -> None:
    """初始化表结构并迁移 schema 版本，版本不匹配且无迁移路径时给出明确错误。"""
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version == 0:
        conn.executescript(_SCHEMA)
        conn.execute("INSERT OR IGNORE INTO seqs (name, value) VALUES ('transfer', 0)")
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.commit()
    elif version < SCHEMA_VERSION:
        while version < SCHEMA_VERSION:
            for stmt in _MIGRATIONS.get(version, []):
                try:
                    conn.execute(stmt)
                except sqlite3.OperationalError as exc:
                    if "duplicate column" not in str(exc):
                        raise
            for hook in _POST_MIGRATIONS.get(version, []):
                hook(conn)
            version += 1
            conn.execute(f"PRAGMA user_version = {version}")
        conn.commit()
    elif version != SCHEMA_VERSION:
        raise RuntimeError(
            f"存储 schema 版本不支持: {version}（当前实现要求 {SCHEMA_VERSION}）"
        )


def _connect(db_path: str | None) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path or ":memory:", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 5000")
    if db_path:
        conn.execute("PRAGMA journal_mode = WAL")
    _ensure_schema(conn)
    return conn


class AuditJournal:
    """审计输出端口的 SQLite 实现：写入持久化并链式哈希，读取按时间序还原。"""

    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn if conn is not None else _connect(None)

    @property
    def connection(self) -> sqlite3.Connection:
        return self._conn

    async def write(self, record: dict[str, Any]) -> None:
        payload = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        with self._conn:
            last = self._conn.execute(
                "SELECT hash FROM audit_records ORDER BY id DESC LIMIT 1"
            ).fetchone()
            prev = "" if last is None else last["hash"]
            digest = _audit_hash(prev, payload)
            self._conn.execute(
                "INSERT INTO audit_records (ts, payload, prev_hash, hash) VALUES (?, ?, ?, ?)",
                (datetime.now(timezone.utc).isoformat(), payload, prev, digest),
            )

    @property
    def records(self) -> list[dict[str, Any]]:
        rows = self._conn.execute("SELECT payload FROM audit_records ORDER BY id").fetchall()
        return [json.loads(row["payload"]) for row in rows]

    def verify_chain(self) -> int | None:
        """校验哈希链完整性：返回首个断裂记录 id，链完整返回 None。"""
        rows = self._conn.execute(
            "SELECT id, prev_hash, hash, payload FROM audit_records ORDER BY id"
        ).fetchall()
        prev = ""
        for row in rows:
            if row["prev_hash"] != prev or row["hash"] != _audit_hash(prev, row["payload"]):
                return row["id"]
            prev = row["hash"]
        return None


class ApprovalLedger:
    """审批凭证的 SQLite 实现：签发与请求落库，校验与核销分离，状态机驱动。

    凭证签发时对不可变字段签名（签名器经组合根注入，无签名器时签发直接
    失败，不允许无签名降级路径）；validate 先验签再验状态，签名无效与
    凭证不存在/已用/过期同等对待。
    """

    def __init__(
        self,
        conn: sqlite3.Connection | None = None,
        signer: GrantSigner | None = None,
    ) -> None:
        self._conn = conn if conn is not None else _connect(None)
        self._signer = signer

    @property
    def connection(self) -> sqlite3.Connection:
        return self._conn

    def _insert_grant(
        self,
        grant_id: str,
        *,
        user_id: str,
        tenant_id: str,
        tool_name: str,
        args,
        level: str,
        state: str,
        ttl_seconds: int,
        issued_by: str,
    ) -> str:
        digest = request_digest(tool_name, args, level=level)
        # 过期时间统一由存储侧时钟生成，避免多主机本地时钟漂移。
        now = self._conn.execute("SELECT unixepoch()").fetchone()[0]
        expires_at = now + ttl_seconds
        if self._signer is None:
            raise RuntimeError("未注入凭证签名器，无法签发审批凭证")
        kid, signature = self._signer.sign(
            grant_signature_payload(
                grant_id=grant_id,
                user_id=user_id,
                tenant_id=tenant_id,
                tool_name=tool_name,
                digest=digest,
                level=level,
                expires_at=expires_at,
            )
        )
        with self._conn:
            try:
                self._conn.execute(
                    "INSERT INTO approval_grants "
                    "(grant_id, user_id, tenant_id, tool_name, digest, level, expires_at, used, "
                    "state, issued_by, issued_at, signature, kid) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)",
                    (
                        grant_id,
                        user_id,
                        tenant_id,
                        tool_name,
                        digest,
                        level,
                        expires_at,
                        state,
                        issued_by or user_id,
                        datetime.now(timezone.utc).isoformat(),
                        signature,
                        kid,
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise ValueError(f"审批凭证标识已存在: {grant_id}") from exc
            # 审批事件与凭证状态变更同事务写入外发表（负载只含业务字段，
            # 不含参数与备注文本）；通知类消费方经中继订阅同一流。
            _write_outbox_event(
                self._conn,
                "approval_requested" if state == "pending" else "approval_issued",
                {
                    "tenant_id": tenant_id,
                    "grant_id": grant_id,
                    "tool_name": tool_name,
                    "level": level,
                    "decided_by": None,
                    "kid": kid,
                },
            )
        return kid

    def request(
        self,
        grant_id: str,
        *,
        user_id: str,
        tenant_id: str,
        tool_name: str,
        args,
        level: str = "low",
        ttl_seconds: int = 300,
        requested_by: str | None = None,
    ) -> str:
        """发起审批请求：凭证以 pending 状态落库，需显式批准后才可核销。"""
        return self._insert_grant(
            grant_id,
            user_id=user_id,
            tenant_id=tenant_id,
            tool_name=tool_name,
            args=args,
            level=level,
            state="pending",
            ttl_seconds=ttl_seconds,
            issued_by=requested_by,
        )

    def issue(
        self,
        grant_id: str,
        *,
        user_id: str,
        tenant_id: str,
        tool_name: str,
        args,
        level: str = "low",
        ttl_seconds: int = 300,
        issued_by: str | None = None,
    ) -> str:
        """直接签发已批准的审批凭证（无需二次裁决的快速通道）。"""
        return self._insert_grant(
            grant_id,
            user_id=user_id,
            tenant_id=tenant_id,
            tool_name=tool_name,
            args=args,
            level=level,
            state="approved",
            ttl_seconds=ttl_seconds,
            issued_by=issued_by,
        )

    def kid_of(self, grant_id: str) -> str | None:
        """查询凭证的签名密钥标识：供签发与裁决审计追溯。"""
        row = self._conn.execute(
            "SELECT kid FROM approval_grants WHERE grant_id = ?", (grant_id,)
        ).fetchone()
        return None if row is None else row["kid"]

    def register_authority(self, approver_id: str, tenant_id: str, max_level: str) -> None:
        """注册或恢复审批人授权：（租户, 最高可批层级）粒度。"""
        if max_level not in APPROVAL_LEVEL_ORDER:
            raise ValueError(f"未知审批层级: {max_level}")
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO approval_authorities "
                "(approver_id, tenant_id, max_level, active) VALUES (?, ?, ?, 1)",
                (approver_id, tenant_id, max_level),
            )

    def deactivate_authority(self, approver_id: str, tenant_id: str) -> None:
        """停用审批人授权：该租户内不再具备裁决资格。"""
        with self._conn:
            self._conn.execute(
                "UPDATE approval_authorities SET active = 0 "
                "WHERE approver_id = ? AND tenant_id = ?",
                (approver_id, tenant_id),
            )

    def _grant_row(self, grant_id: str):
        return self._conn.execute(
            "SELECT * FROM approval_grants WHERE grant_id = ?", (grant_id,)
        ).fetchone()

    def _check_decider(self, row, decided_by: str, *, require_four_eyes: bool) -> None:
        """裁决授权校验：活跃审批人 + 租户匹配 + 层级足够；批准另需四眼原则。"""
        authority = self._conn.execute(
            "SELECT max_level FROM approval_authorities "
            "WHERE approver_id = ? AND tenant_id = ? AND active = 1",
            (decided_by, row["tenant_id"]),
        ).fetchone()
        if authority is not None and APPROVAL_LEVEL_ORDER.index(
            authority["max_level"]
        ) >= APPROVAL_LEVEL_ORDER.index(row["level"]):
            if require_four_eyes and decided_by == row["issued_by"]:
                raise GovernanceViolation(
                    OutcomeCode.APPROVAL_DECISION_DENIED, "违反四眼原则：请求人与批准人不能是同一人"
                )
            return
        if not require_four_eyes and row["state"] == "pending" and decided_by == row["issued_by"]:
            return  # 请求人自助撤回自己的待决凭证
        raise GovernanceViolation(
            OutcomeCode.APPROVAL_DECISION_DENIED, "裁决人无该租户的授权或授权层级不足"
        )

    def approve(self, grant_id: str, *, decided_by: str, reason: str) -> None:
        """批准待决凭证：裁决人授权校验通过后，仅 pending 状态可批准。"""
        with self._conn:
            row = self._grant_row(grant_id)
            if row is None:
                raise ValueError(f"审批凭证不存在: {grant_id}")
            self._check_decider(row, decided_by, require_four_eyes=True)
            cursor = self._conn.execute(
                "UPDATE approval_grants SET state = 'approved', decided_by = ?, decided_at = ?, reason = ? "
                "WHERE grant_id = ? AND state = 'pending'",
                (decided_by, datetime.now(timezone.utc).isoformat(), reason, grant_id),
            )
            if cursor.rowcount > 0:
                _write_outbox_event(
                    self._conn,
                    "approval_approved",
                    {
                        "tenant_id": row["tenant_id"],
                        "grant_id": grant_id,
                        "tool_name": row["tool_name"],
                        "level": row["level"],
                        "decided_by": decided_by,
                        "kid": row["kid"],
                    },
                )
        if cursor.rowcount == 0:
            raise ValueError(f"审批凭证不存在或状态不允许批准: {grant_id}")

    def revoke(self, grant_id: str, *, decided_by: str, reason: str) -> None:
        """撤销凭证：请求人自助撤回 pending，或授权审批人撤销本租户凭证。"""
        with self._conn:
            row = self._grant_row(grant_id)
            if row is None:
                raise ValueError(f"审批凭证不存在: {grant_id}")
            self._check_decider(row, decided_by, require_four_eyes=False)
            cursor = self._conn.execute(
                "UPDATE approval_grants SET state = 'revoked', decided_by = ?, decided_at = ?, reason = ? "
                "WHERE grant_id = ? AND state IN ('pending', 'approved')",
                (decided_by, datetime.now(timezone.utc).isoformat(), reason, grant_id),
            )
            if cursor.rowcount > 0:
                _write_outbox_event(
                    self._conn,
                    "approval_revoked",
                    {
                        "tenant_id": row["tenant_id"],
                        "grant_id": grant_id,
                        "tool_name": row["tool_name"],
                        "level": row["level"],
                        "decided_by": decided_by,
                        "kid": row["kid"],
                    },
                )
        if cursor.rowcount == 0:
            raise ValueError(f"审批凭证不存在或状态不允许撤销: {grant_id}")

    def validate(
        self,
        grant_id: str | None,
        *,
        tool_name: str,
        args,
        user_id: str,
        tenant_id: str,
        required_level: str,
        idempotency_key: str | None = None,
    ) -> bool:
        """只验不销，返回是否为已落库幂等重放。

        常规执行要求凭证已批准、未使用、未过期，签名、身份、工具、层级与
        参数摘要全部匹配。已使用凭证仅在同幂等键已绑定同参数流水时允许
        重放：该路径只返回原结果，不再次核销，也不产生资金副作用。
        签名无效与凭证不存在/已用/过期同码拒绝，不泄露区分。
        """
        row = self._conn.execute(
            "SELECT * FROM approval_grants WHERE grant_id = ?", (grant_id or "",)
        ).fetchone()
        # 过期判定与签发统一使用存储侧时钟。
        now = self._conn.execute("SELECT unixepoch()").fetchone()[0]
        signature_ok = (
            row is not None
            and self._signer is not None
            and self._signer.verify(
                grant_signature_payload(
                    grant_id=row["grant_id"],
                    user_id=row["user_id"],
                    tenant_id=row["tenant_id"],
                    tool_name=row["tool_name"],
                    digest=row["digest"],
                    level=row["level"],
                    expires_at=row["expires_at"],
                ),
                row["signature"],
                row["kid"],
            )
        )
        valid = (
            signature_ok
            and row["state"] == "approved"
            and row["expires_at"] >= now
            and row["user_id"] == user_id
            and row["tenant_id"] == tenant_id
            and row["tool_name"] == tool_name
            and APPROVAL_LEVEL_ORDER.index(row["level"]) >= APPROVAL_LEVEL_ORDER.index(required_level)
            and row["digest"] == request_digest(tool_name, args, level=row["level"])
        )
        replay = False
        if valid and idempotency_key:
            stored = self._conn.execute(
                "SELECT params_digest FROM idempotency_keys "
                "WHERE tenant_id = ? AND idempotency_key = ?",
                (tenant_id, idempotency_key),
            ).fetchone()
            replay = (
                stored is not None
                and stored["params_digest"] == request_digest(tool_name, args)
            )
        if not valid or (row["used"] and not replay):
            raise GovernanceViolation(
                OutcomeCode.APPROVAL_REQUIRED,
                "请提供与本次收款账户和金额一致的一次性审批凭证",
            )
        return replay

    def consume(self, grant_id: str | None) -> None:
        """原子核销：仅当凭证仍为已批准且未使用时生效，并发消费只会成功一次。"""
        with self._conn:
            cursor = self._conn.execute(
                "UPDATE approval_grants SET used = 1 WHERE grant_id = ? AND used = 0 AND state = 'approved'",
                (grant_id or "",),
            )
        if cursor.rowcount == 0:
            raise GovernanceViolation(
                OutcomeCode.APPROVAL_REQUIRED,
                "请提供与本次收款账户和金额一致的一次性审批凭证",
            )


class SqliteLockManager:
    """跨进程写串行化：进程内锁先行，SQLite 咨询锁表协调跨连接/跨进程竞争。

    按字典序整体获取多把锁，全部成功才持有，避免死锁；持有带过期时间，
    进程崩溃遗留的锁在过期后可被接管。
    """

    def __init__(
        self,
        conn: sqlite3.Connection | None = None,
        *,
        lock_ttl_seconds: float = 30.0,
        acquire_timeout_seconds: float = 10.0,
    ) -> None:
        self._conn = conn if conn is not None else _connect(None)
        self._owner = uuid4().hex
        self._lock_ttl = lock_ttl_seconds
        self._acquire_timeout = acquire_timeout_seconds
        self._local = InProcessLockManager()

    @asynccontextmanager
    async def locked(self, keys: Sequence[str]) -> AsyncIterator[None]:
        ordered = sorted(set(keys))
        async with self._local.locked(ordered):
            rows: list[str] = []
            deadline = time.monotonic() + self._acquire_timeout
            while True:
                acquired: list[str] = []
                for key in ordered:
                    if self._try_acquire(key):
                        acquired.append(key)
                    else:
                        break
                if len(acquired) == len(ordered):
                    rows = acquired
                    break
                self._release_rows(acquired)
                if time.monotonic() >= deadline:
                    raise GovernanceViolation(
                        OutcomeCode.TEMPORARY_UNAVAILABLE, "获取串行化锁超时，请稍后重试"
                    )
                await asyncio.sleep(0.02)
            try:
                yield
            finally:
                self._release_rows(rows)

    def _try_acquire(self, key: str) -> bool:
        # 单条 UPSERT 原子完成「无锁或已过期则写入/接管，持有中则不动」，
        # 过期判定由 SQLite 存储侧时钟（unixepoch）完成。
        self._conn.execute("BEGIN IMMEDIATE")
        try:
            cursor = self._conn.execute(
                "INSERT INTO locks (scope_key, owner, expires_at) VALUES (?, ?, unixepoch() + ?) "
                "ON CONFLICT(scope_key) DO UPDATE SET owner = excluded.owner, "
                "expires_at = excluded.expires_at WHERE locks.expires_at < unixepoch()",
                (key, self._owner, self._lock_ttl),
            )
            self._conn.commit()
            return cursor.rowcount == 1
        except Exception:
            self._conn.rollback()
            raise

    def _release_rows(self, keys: Sequence[str]) -> None:
        if not keys:
            return
        with self._conn:
            self._conn.executemany(
                "DELETE FROM locks WHERE scope_key = ? AND owner = ?",
                [(key, self._owner) for key in keys],
            )


class RateLimiter:
    """风控计数端口：限频窗口与租户日累计的持久化计数。"""

    def __init__(self, conn: sqlite3.Connection | None = None) -> None:
        self._conn = conn if conn is not None else _connect(None)

    def check_rate(self, tenant_id: str, tool_name: str, *, limit: int, window_seconds: float) -> None:
        """固定窗口限频：窗口起点与重置判定统一由存储侧时钟驱动。"""
        now = self._conn.execute("SELECT unixepoch()").fetchone()[0]
        with self._conn:
            row = self._conn.execute(
                "SELECT window_start, count FROM rate_limits WHERE tenant_id = ? AND tool_name = ?",
                (tenant_id, tool_name),
            ).fetchone()
            if row is None or now - row["window_start"] >= window_seconds:
                self._conn.execute(
                    "INSERT OR REPLACE INTO rate_limits (tenant_id, tool_name, window_start, count) "
                    "VALUES (?, ?, ?, 1)",
                    (tenant_id, tool_name, now),
                )
            elif row["count"] >= limit:
                raise GovernanceViolation(
                    OutcomeCode.RATE_LIMITED, "调用过于频繁，请稍后重试"
                )
            else:
                self._conn.execute(
                    "UPDATE rate_limits SET count = count + 1 WHERE tenant_id = ? AND tool_name = ?",
                    (tenant_id, tool_name),
                )

    def daily_total(self, tenant_id: str) -> Decimal:
        """当前 UTC 日该租户已累计的金额（仅含已提交的事务）。"""
        day = _storage_day(self._conn)
        row = self._conn.execute(
            "SELECT total FROM daily_usage WHERE tenant_id = ? AND day = ?", (tenant_id, day)
        ).fetchone()
        return Decimal("0") if row is None else Decimal(row["total"])


class AccountLedger:
    """账户、流水与分录的 SQLite 实现：事务性转账变更与幂等防重。"""

    def __init__(
        self,
        db_path: str | None = None,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        self._conn = conn if conn is not None else _connect(db_path)

    @property
    def connection(self) -> sqlite3.Connection:
        return self._conn

    def close(self) -> None:
        self._conn.close()

    def open_account(self, tenant_id: str, account: str, balance: str, status: str = ACTIVE) -> None:
        amount = Decimal(balance)
        if amount < 0:
            raise ValueError("初始余额不能为负")
        with self._conn:
            try:
                self._conn.execute(
                    "INSERT INTO accounts (tenant_id, account, balance, status, opening) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (tenant_id, account, format(amount, "f"), status, format(amount, "f")),
                )
            except sqlite3.IntegrityError as exc:
                raise ValueError(f"账户已存在: {account}") from exc
            _write_outbox_event(
                self._conn,
                "account_opened",
                {
                    "tenant_id": tenant_id,
                    "account": account,
                    "opening": format(amount, "f"),
                    "status": status,
                },
            )

    def entry(self, tenant_id: str, account: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT balance, status FROM accounts WHERE tenant_id = ? AND account = ?",
            (tenant_id, account),
        ).fetchone()
        if row is None:
            return None
        return {"balance": Decimal(row["balance"]), "status": row["status"]}

    def balance(self, tenant_id: str, account: str) -> Decimal:
        entry = self.entry(tenant_id, account)
        if entry is None:
            raise KeyError(f"账户不存在: {account}")
        return entry["balance"]

    def status(self, tenant_id: str, account: str) -> str | None:
        entry = self.entry(tenant_id, account)
        return None if entry is None else str(entry["status"])

    def total_of(self, tenant_id: str, accounts: list[str]) -> Decimal:
        return sum((self.balance(tenant_id, item) for item in accounts), Decimal("0"))

    def statement(self, tenant_id: str, account: str, limit: int = 100) -> list[dict[str, Any]]:
        """账户对账单：按时间倒序返回借贷分录。"""
        rows = self._conn.execute(
            "SELECT id, side, amount, transfer_id, created_at FROM ledger_entries "
            "WHERE tenant_id = ? AND account = ? ORDER BY id DESC LIMIT ?",
            (tenant_id, account, limit),
        ).fetchall()
        return [dict(row) for row in rows]

    def _next_transfer_id(self) -> str:
        self._conn.execute("UPDATE seqs SET value = value + 1 WHERE name = 'transfer'")
        value = self._conn.execute("SELECT value FROM seqs WHERE name = 'transfer'").fetchone()[0]
        return f"trf_{value:06d}"

    def apply_transfer(
        self,
        tenant_id: str,
        from_account: str,
        to_account: str,
        amount: Decimal,
        idempotency_key: str | None,
        params_digest: str,
        daily_cap: Decimal | None = None,
    ) -> dict[str, Any]:
        """单事务内完成幂等判定、日累计校验、余额变更、分录与流水落库，失败整体回滚。"""
        with self._conn:
            if idempotency_key:
                existing = self._conn.execute(
                    "SELECT * FROM idempotency_keys WHERE tenant_id = ? AND idempotency_key = ?",
                    (tenant_id, idempotency_key),
                ).fetchone()
                if existing is not None:
                    if existing["params_digest"] != params_digest:
                        raise GovernanceViolation(
                            OutcomeCode.IDEMPOTENCY_CONFLICT,
                            "幂等键已被不同参数的调用占用",
                        )
                    settled = self._conn.execute(
                        "SELECT * FROM transfers WHERE tenant_id = ? AND transfer_id = ?",
                        (tenant_id, existing["transfer_id"]),
                    ).fetchone()
                    return dict(settled)

            source = self._conn.execute(
                "SELECT balance, status FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, from_account),
            ).fetchone()
            if source is None:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, f"出账账户不存在: {from_account}"
                )
            if source["status"] != ACTIVE:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, f"出账账户当前状态不可用: {from_account}"
                )
            target = self._conn.execute(
                "SELECT balance, status FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, to_account),
            ).fetchone()
            if target is None:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, f"入账账户不存在: {to_account}"
                )
            if target["status"] != ACTIVE:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, f"入账账户当前状态不可用: {to_account}"
                )
            if amount > Decimal(source["balance"]):
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, "转账金额超过出账账户余额"
                )

            day = _storage_day(self._conn)
            usage = self._conn.execute(
                "SELECT total FROM daily_usage WHERE tenant_id = ? AND day = ?", (tenant_id, day)
            ).fetchone()
            used = Decimal("0") if usage is None else Decimal(usage["total"])
            if daily_cap is not None and used + amount > daily_cap:
                raise GovernanceViolation(
                    OutcomeCode.RATE_LIMITED, "超出租户日累计转账限额"
                )

            transfer_id = self._next_transfer_id()
            self._conn.execute(
                "UPDATE accounts SET balance = ? WHERE tenant_id = ? AND account = ?",
                (format(Decimal(source["balance"]) - amount, "f"), tenant_id, from_account),
            )
            self._conn.execute(
                "UPDATE accounts SET balance = ? WHERE tenant_id = ? AND account = ?",
                (format(Decimal(target["balance"]) + amount, "f"), tenant_id, to_account),
            )
            record = {
                "transfer_id": transfer_id,
                "business_ref": idempotency_key or transfer_id,
                "tenant_id": tenant_id,
                "from_account": from_account,
                "to_account": to_account,
                "amount": format(amount, "f"),
                "status": "settled",
            }
            created_at = datetime.now(timezone.utc).isoformat()
            self._conn.execute(
                "INSERT INTO transfers "
                "(tenant_id, transfer_id, business_ref, from_account, to_account, amount, status, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tenant_id,
                    transfer_id,
                    record["business_ref"],
                    from_account,
                    to_account,
                    record["amount"],
                    record["status"],
                    created_at,
                ),
            )
            for account, side in ((from_account, "debit"), (to_account, "credit")):
                self._conn.execute(
                    "INSERT INTO ledger_entries (tenant_id, account, side, amount, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        tenant_id,
                        account,
                        side,
                        record["amount"],
                        transfer_id,
                        created_at,
                    ),
                )
            if idempotency_key:
                self._conn.execute(
                    "INSERT INTO idempotency_keys "
                    "(tenant_id, idempotency_key, params_digest, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (
                        tenant_id,
                        idempotency_key,
                        params_digest,
                        transfer_id,
                        created_at,
                    ),
                )
            if daily_cap is not None:
                self._conn.execute(
                    "INSERT OR REPLACE INTO daily_usage (tenant_id, day, total) VALUES (?, ?, ?)",
                    (tenant_id, day, format(used + amount, "f")),
                )
            _write_outbox_event(
                self._conn,
                "transfer_settled",
                {
                    "tenant_id": tenant_id,
                    "transfer_id": transfer_id,
                    "business_ref": record["business_ref"],
                    "from_account": from_account,
                    "to_account": to_account,
                    "amount": record["amount"],
                    "status": "settled",
                    "created_at": created_at,
                    "idempotency_key": idempotency_key,
                    "params_digest": params_digest,
                    "daily_cap_applied": daily_cap is not None,
                    "day": day,
                },
            )
            return record

    def get_transfer_by_business_ref(self, tenant_id: str, business_ref: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM transfers WHERE tenant_id = ? AND business_ref = ? "
            "ORDER BY created_at DESC, transfer_id DESC LIMIT 1",
            (tenant_id, business_ref),
        ).fetchone()
        return None if row is None else dict(row)

    def get_transfer(self, tenant_id: str, transfer_id: str) -> dict[str, Any] | None:
        """按单号取流水：含冲正关联列（普通转账为 NULL，冲正单指向原单号）。"""
        row = self._conn.execute(
            "SELECT * FROM transfers WHERE tenant_id = ? AND transfer_id = ?",
            (tenant_id, transfer_id),
        ).fetchone()
        return None if row is None else dict(row)

    def reversal_of(self, tenant_id: str, transfer_id: str) -> dict[str, Any] | None:
        """查询指定转账的冲正单（不存在或未冲正返回 None）。"""
        row = self._conn.execute(
            "SELECT * FROM transfers WHERE tenant_id = ? AND original_transfer_id = ?",
            (tenant_id, transfer_id),
        ).fetchone()
        return None if row is None else dict(row)

    def reversed_total(self, tenant_id: str, transfer_id: str) -> Decimal:
        """指定转账的累计已冲正金额（部分冲正剩余额 = 原单金额 - 该值）。"""
        row = self._conn.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM transfers "
            "WHERE tenant_id = ? AND original_transfer_id = ?",
            (tenant_id, transfer_id),
        ).fetchone()
        return Decimal(row["total"])

    def idempotent_transfer(self, tenant_id: str, idempotency_key: str | None) -> dict[str, Any] | None:
        """按幂等键查已落库的流水：预检据此识别重放并跳过业务校验。"""
        if not idempotency_key:
            return None
        row = self._conn.execute(
            "SELECT t.* FROM idempotency_keys k "
            "JOIN transfers t ON t.tenant_id = k.tenant_id AND t.transfer_id = k.transfer_id "
            "WHERE k.tenant_id = ? AND k.idempotency_key = ?",
            (tenant_id, idempotency_key),
        ).fetchone()
        return None if row is None else dict(row)

    def apply_reversal(
        self,
        tenant_id: str,
        original_transfer_id: str,
        declared_amount: Decimal,
        idempotency_key: str | None,
        params_digest: str,
    ) -> dict[str, Any]:
        """单事务内完成冲正：幂等判定、原单校验、余额原路变更、流水、
        反向借贷分录与当日额度回补，失败整体回滚。

        冲正只针对 status='settled' 的转账；冲正本身不可再被冲正。
        声明金额不超过原单未冲正余额（部分冲正），可多次冲正直至累计
        等于原单金额；审批摘要绑定声明金额，治理语义与资金移动量强绑定。
        """
        with self._conn:
            if idempotency_key:
                existing = self._conn.execute(
                    "SELECT * FROM idempotency_keys WHERE tenant_id = ? AND idempotency_key = ?",
                    (tenant_id, idempotency_key),
                ).fetchone()
                if existing is not None:
                    if existing["params_digest"] != params_digest:
                        raise GovernanceViolation(
                            OutcomeCode.IDEMPOTENCY_CONFLICT,
                            "幂等键已被不同参数的调用占用",
                        )
                    settled = self._conn.execute(
                        "SELECT * FROM transfers WHERE tenant_id = ? AND transfer_id = ?",
                        (tenant_id, existing["transfer_id"]),
                    ).fetchone()
                    return dict(settled)

            original = self._conn.execute(
                "SELECT * FROM transfers WHERE tenant_id = ? AND transfer_id = ?",
                (tenant_id, original_transfer_id),
            ).fetchone()
            if original is None:
                raise GovernanceViolation(OutcomeCode.BUSINESS_RULE_DENIED, "原转账不存在")
            if original["status"] != "settled":
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, "原转账状态不允许冲正"
                )
            # 剩余额 = 原单金额 - SUM(既有冲正分录)：锁内二次校验与预检一致，
            # 部分冲正累计上限在此拒绝。
            remaining = Decimal(original["amount"]) - self.reversed_total(
                tenant_id, original_transfer_id
            )
            if remaining <= 0:
                raise GovernanceViolation(OutcomeCode.BUSINESS_RULE_DENIED, "该转账已全部冲正")
            if declared_amount > remaining:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, "冲正金额超过原转账未冲正余额"
                )

            from_account, to_account = original["to_account"], original["from_account"]

            source = self._conn.execute(
                "SELECT balance, status FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, from_account),
            ).fetchone()
            if source is None or source["status"] != ACTIVE:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, f"原入账账户不可用: {from_account}"
                )
            target = self._conn.execute(
                "SELECT balance, status FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, to_account),
            ).fetchone()
            if target is None or target["status"] != ACTIVE:
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, f"原出账账户不可用: {to_account}"
                )
            if declared_amount > Decimal(source["balance"]):
                raise GovernanceViolation(
                    OutcomeCode.BUSINESS_RULE_DENIED, "原入账账户余额不足以冲正"
                )

            reversal_id = self._next_transfer_id()
            self._conn.execute(
                "UPDATE accounts SET balance = ? WHERE tenant_id = ? AND account = ?",
                (format(Decimal(source["balance"]) - declared_amount, "f"), tenant_id, from_account),
            )
            self._conn.execute(
                "UPDATE accounts SET balance = ? WHERE tenant_id = ? AND account = ?",
                (format(Decimal(target["balance"]) + declared_amount, "f"), tenant_id, to_account),
            )
            record = {
                "transfer_id": reversal_id,
                "business_ref": idempotency_key or reversal_id,
                "tenant_id": tenant_id,
                "from_account": from_account,
                "to_account": to_account,
                "amount": format(declared_amount, "f"),
                "status": "reversed",
                "original_transfer_id": original_transfer_id,
            }
            created_at = datetime.now(timezone.utc).isoformat()
            self._conn.execute(
                "INSERT INTO transfers "
                "(tenant_id, transfer_id, business_ref, from_account, to_account, amount, "
                "status, created_at, original_transfer_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tenant_id,
                    reversal_id,
                    record["business_ref"],
                    from_account,
                    to_account,
                    record["amount"],
                    record["status"],
                    created_at,
                    original_transfer_id,
                ),
            )
            for account, side in ((from_account, "debit"), (to_account, "credit")):
                self._conn.execute(
                    "INSERT INTO ledger_entries (tenant_id, account, side, amount, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        tenant_id,
                        account,
                        side,
                        record["amount"],
                        reversal_id,
                        created_at,
                    ),
                )
            if idempotency_key:
                self._conn.execute(
                    "INSERT INTO idempotency_keys "
                    "(tenant_id, idempotency_key, params_digest, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (
                        tenant_id,
                        idempotency_key,
                        params_digest,
                        reversal_id,
                        created_at,
                    ),
                )
            # 冲正回补当日已用额度（下限为零，按声明金额）：撤销的资金移动不挤占后续转账。
            day = _storage_day(self._conn)
            usage = self._conn.execute(
                "SELECT total FROM daily_usage WHERE tenant_id = ? AND day = ?", (tenant_id, day)
            ).fetchone()
            if usage is not None:
                refunded = max(Decimal(usage["total"]) - declared_amount, Decimal("0"))
                self._conn.execute(
                    "UPDATE daily_usage SET total = ? WHERE tenant_id = ? AND day = ?",
                    (format(refunded, "f"), tenant_id, day),
                )
            _write_outbox_event(
                self._conn,
                "transfer_reversed",
                {
                    "tenant_id": tenant_id,
                    "transfer_id": reversal_id,
                    "business_ref": record["business_ref"],
                    "from_account": from_account,
                    "to_account": to_account,
                    "amount": record["amount"],
                    "status": "reversed",
                    "original_transfer_id": original_transfer_id,
                    "created_at": created_at,
                    "idempotency_key": idempotency_key,
                    "params_digest": params_digest,
                    "day": day,
                },
            )
            return record

    def reconcile_account(self, tenant_id: str, account: str) -> dict[str, Any]:
        """单账户对账：余额应等于「期初 + 贷方 - 借方」，返回差异报告。"""
        entry = self._conn.execute(
            "SELECT balance, status, opening FROM accounts WHERE tenant_id = ? AND account = ?",
            (tenant_id, account),
        ).fetchone()
        if entry is None:
            raise KeyError(f"账户不存在: {account}")
        sums = self._conn.execute(
            "SELECT COALESCE(SUM(CASE side WHEN 'credit' THEN amount ELSE 0 END), 0) AS credits, "
            "COALESCE(SUM(CASE side WHEN 'debit' THEN amount ELSE 0 END), 0) AS debits "
            "FROM ledger_entries WHERE tenant_id = ? AND account = ?",
            (tenant_id, account),
        ).fetchone()
        opening = Decimal(entry["opening"])
        credits, debits = Decimal(sums["credits"]), Decimal(sums["debits"])
        expected = opening + credits - debits
        actual = Decimal(entry["balance"])
        return {
            "tenant_id": tenant_id,
            "account": account,
            "opening": format(opening, "f"),
            "credits": format(credits, "f"),
            "debits": format(debits, "f"),
            "expected": format(expected, "f"),
            "balance": format(actual, "f"),
            "consistent": expected == actual,
            "discrepancy": format(expected - actual, "f"),
        }

    def outbox_events(self) -> list[dict[str, Any]]:
        """读取外发事件表（含未外发）：供演示与测试核对事件序列。"""
        rows = self._conn.execute(
            "SELECT id, event_id, event_type, payload, published, attempts, last_error, dead "
            "FROM outbox_events ORDER BY id"
        ).fetchall()
        return [
            {
                "event_id": row["event_id"],
                "event_type": row["event_type"],
                "payload": json.loads(row["payload"]),
                "published": bool(row["published"]),
                "attempts": row["attempts"],
                "last_error": row["last_error"],
                "dead": bool(row["dead"]),
            }
            for row in rows
        ]

    def outbox_backlog(self) -> dict[str, int]:
        """外发积压观测：未外发（非死信）与死信行数，供积压告警。"""
        pending = self._conn.execute(
            "SELECT COUNT(*) AS n FROM outbox_events WHERE published = 0 AND dead = 0"
        ).fetchone()["n"]
        dead = self._conn.execute(
            "SELECT COUNT(*) AS n FROM outbox_events WHERE dead = 1"
        ).fetchone()["n"]
        return {"pending": pending, "dead": dead}

    def replay_checkpoint(self, stream: str) -> dict[str, Any] | None:
        """读取副本回放检查点：该流最后消费的条目位置与快照水印。"""
        row = self._conn.execute(
            "SELECT last_entry_id, snapshot_watermark FROM replay_checkpoint WHERE stream = ?",
            (stream,),
        ).fetchone()
        if row is None:
            return None
        return {
            "last_entry_id": row["last_entry_id"],
            "snapshot_watermark": int(row["snapshot_watermark"]),
        }

    def set_replay_checkpoint(
        self,
        stream: str,
        *,
        last_entry_id: str | None = None,
        snapshot_watermark: int | None = None,
    ) -> None:
        """更新副本回放检查点：未提供的字段保留现值，热续读与快照水印共用。"""
        with self._conn:
            current = self._conn.execute(
                "SELECT last_entry_id, snapshot_watermark FROM replay_checkpoint WHERE stream = ?",
                (stream,),
            ).fetchone()
            entry = (
                last_entry_id
                if last_entry_id is not None
                else (current["last_entry_id"] if current is not None else None)
            )
            watermark = (
                snapshot_watermark
                if snapshot_watermark is not None
                else (current["snapshot_watermark"] if current is not None else 0)
            )
            self._conn.execute(
                "INSERT OR REPLACE INTO replay_checkpoint (stream, last_entry_id, snapshot_watermark) "
                "VALUES (?, ?, ?)",
                (stream, entry, watermark),
            )

    def export_snapshot(self) -> dict[str, Any]:
        """导出全量快照与事件高水位：账户（含期初）、流水、分录、幂等键、
        当日额度、流水序号与外发表最大 id；副本导入后按水印增量回放。"""
        def dump(table: str, columns: str) -> list[dict[str, Any]]:
            return [
                dict(row)
                for row in self._conn.execute(f"SELECT {columns} FROM {table}").fetchall()
            ]

        seqs = {
            row["name"]: row["value"]
            for row in self._conn.execute("SELECT name, value FROM seqs").fetchall()
        }
        watermark = self._conn.execute("SELECT MAX(id) AS m FROM outbox_events").fetchone()["m"]
        return {
            "schema_version": SCHEMA_VERSION,
            "accounts": dump("accounts", "tenant_id, account, balance, status, opening"),
            "transfers": dump(
                "transfers",
                "tenant_id, transfer_id, business_ref, from_account, to_account, "
                "amount, status, created_at, original_transfer_id",
            ),
            "ledger_entries": dump(
                "ledger_entries", "tenant_id, account, side, amount, transfer_id, created_at"
            ),
            "idempotency_keys": dump(
                "idempotency_keys", "tenant_id, idempotency_key, params_digest, transfer_id, created_at"
            ),
            "daily_usage": dump("daily_usage", "tenant_id, day, total"),
            "seqs": seqs,
            "outbox_high_water": int(watermark or 0),
        }

    def import_snapshot(
        self, snapshot: dict[str, Any], *, checkpoint_stream: str = "governed:transfers"
    ) -> None:
        """导入快照重建副本基线：目标账本必须为空（避免覆盖本地数据）；
        快照水印写入回放检查点，此后只回放高水位之后的流事件。"""
        if snapshot.get("schema_version") != SCHEMA_VERSION:
            raise ValueError(f"快照 schema 版本不匹配: {snapshot.get('schema_version')}")
        for table in ("accounts", "transfers", "ledger_entries", "idempotency_keys", "daily_usage"):
            count = self._conn.execute(
                f"SELECT COUNT(*) AS n FROM {table}"
            ).fetchone()["n"]
            if count:
                raise ValueError(f"目标账本非空（{table}），拒绝导入快照")
        with self._conn:
            for row in snapshot["accounts"]:
                self._conn.execute(
                    "INSERT INTO accounts (tenant_id, account, balance, status, opening) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (row["tenant_id"], row["account"], row["balance"], row["status"], row["opening"]),
                )
            for row in snapshot["transfers"]:
                self._conn.execute(
                    "INSERT INTO transfers (tenant_id, transfer_id, business_ref, from_account, "
                    "to_account, amount, status, created_at, original_transfer_id) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        row["tenant_id"],
                        row["transfer_id"],
                        row["business_ref"],
                        row["from_account"],
                        row["to_account"],
                        row["amount"],
                        row["status"],
                        row["created_at"],
                        row["original_transfer_id"],
                    ),
                )
            for row in snapshot["ledger_entries"]:
                self._conn.execute(
                    "INSERT INTO ledger_entries (tenant_id, account, side, amount, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        row["tenant_id"],
                        row["account"],
                        row["side"],
                        row["amount"],
                        row["transfer_id"],
                        row["created_at"],
                    ),
                )
            for row in snapshot["idempotency_keys"]:
                self._conn.execute(
                    "INSERT INTO idempotency_keys (tenant_id, idempotency_key, params_digest, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (
                        row["tenant_id"],
                        row["idempotency_key"],
                        row["params_digest"],
                        row["transfer_id"],
                        row["created_at"],
                    ),
                )
            for row in snapshot["daily_usage"]:
                self._conn.execute(
                    "INSERT INTO daily_usage (tenant_id, day, total) VALUES (?, ?, ?)",
                    (row["tenant_id"], row["day"], row["total"]),
                )
            for name, value in snapshot["seqs"].items():
                self._conn.execute(
                    "INSERT OR REPLACE INTO seqs (name, value) VALUES (?, ?)", (name, value)
                )
            self._conn.execute(
                "INSERT OR REPLACE INTO replay_checkpoint (stream, last_entry_id, snapshot_watermark) "
                "VALUES (?, NULL, ?)",
                (checkpoint_stream, int(snapshot["outbox_high_water"])),
            )

    def diff_ledgers(
        self, other: "AccountLedger", tenant_id: str, accounts: Sequence[str]
    ) -> list[dict[str, Any]]:
        """跨实例对账：对比两份账本同租户账户集的余额与分录数，输出差异清单。"""
        diffs: list[dict[str, Any]] = []
        for account in accounts:
            mine = self.entry(tenant_id, account)
            theirs = other.entry(tenant_id, account)
            if mine is None and theirs is None:
                continue
            if mine is None or theirs is None:
                diffs.append(
                    {
                        "account": account,
                        "kind": "account_presence",
                        "mine": None if mine is None else "present",
                        "theirs": None if theirs is None else "present",
                    }
                )
                continue
            if mine["balance"] != theirs["balance"]:
                diffs.append(
                    {
                        "account": account,
                        "kind": "balance",
                        "mine": str(mine["balance"]),
                        "theirs": str(theirs["balance"]),
                    }
                )
            mine_count = self._conn.execute(
                "SELECT COUNT(*) AS n FROM ledger_entries WHERE tenant_id = ? AND account = ?",
                (tenant_id, account),
            ).fetchone()["n"]
            theirs_count = other.connection.execute(
                "SELECT COUNT(*) AS n FROM ledger_entries WHERE tenant_id = ? AND account = ?",
                (tenant_id, account),
            ).fetchone()["n"]
            if mine_count != theirs_count:
                diffs.append(
                    {
                        "account": account,
                        "kind": "entry_count",
                        "mine": mine_count,
                        "theirs": theirs_count,
                    }
                )
        return diffs
