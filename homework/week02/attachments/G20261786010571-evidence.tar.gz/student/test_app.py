"""审批接入层验收测试：TestClient 驱动真实组合根 + 本地签名 OIDC 令牌。

身份提供者由本地生成的 RSA 密钥对模拟：验证器经注入的 jwks_fetcher
返回本地公钥 JWKS，CI 不依赖真实 IdP；断言只观察 HTTP 状态、错误码、
账本终态与审计记录。
"""

from __future__ import annotations

import asyncio
import json
import os
import time

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient
from jwt.algorithms import RSAAlgorithm

from app import OidcVerifier, build_signer_from_env, create_app
from signing import Ed25519GrantSigner, grant_signature_payload
from test_transfer import TENANT, make_ledger
from transfer_tool import compose_transfer_system

ISSUER = "https://idp.test.example"
AUDIENCE = "governed-transfer"

_PRIVATE_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_LOCAL_JWK = json.loads(RSAAlgorithm.to_jwk(_PRIVATE_KEY.public_key()))
_LOCAL_JWK["kid"] = "local-test-key"
_PUBLIC_JWKS = {"keys": [_LOCAL_JWK]}
_KID = _LOCAL_JWK["kid"]


def sign_token(claims: dict) -> str:
    return jwt.encode(claims, _PRIVATE_KEY, algorithm="RS256", headers={"kid": _KID})


def base_claims(
    *,
    sub: str = "u_100",
    tenant: str = TENANT,
    permissions: list[str] | None = None,
    tools: list[str] | None = None,
    scope: str = "",
    exp_delta: int = 300,
) -> dict:
    claims = {
        "iss": ISSUER,
        "aud": AUDIENCE,
        "sub": sub,
        "tenant_id": tenant,
        "exp": int(time.time()) + exp_delta,
    }
    if permissions is not None:
        claims["permissions"] = permissions
    if tools is not None:
        claims["tools"] = tools
    if scope:
        claims["scope"] = scope
    return claims


FULL_PERMS = ["transfer:execute", "transfer:reverse", "account:read"]
FULL_TOOLS = ["execute_transfer", "reverse_transfer", "get_account_balance"]


@pytest.fixture
def client():
    ledger = make_ledger()
    system = compose_transfer_system(ledger)

    async def fetch_jwks() -> dict:
        return _PUBLIC_JWKS

    verifier = OidcVerifier(ISSUER, AUDIENCE, jwks_fetcher=fetch_jwks)
    with TestClient(create_app(system, verifier)) as test_client:
        test_client.system = system
        test_client.ledger = ledger
        yield test_client


def auth(**claims_overrides) -> dict:
    claims = base_claims(**claims_overrides)
    return {"Authorization": f"Bearer {sign_token(claims)}"}


# ---- 身份与令牌 --------------------------------------------------------------


def test_http_health_probes_do_not_require_token(client):
    live = client.get("/health/live")
    ready = client.get("/health/ready")
    assert live.status_code == 200 and live.json() == {"status": "ok"}
    assert ready.status_code == 200 and ready.json() == {"status": "ready"}


def test_http_missing_token_returns_401(client):
    assert client.get("/tools").status_code == 401
    assert client.post("/invoke", json={"id": "c1", "name": "get_account_balance", "arguments": {}}).status_code == 401


def test_http_garbage_token_returns_401(client):
    response = client.get("/tools", headers={"Authorization": "Bearer not-a-jwt"})
    assert response.status_code == 401


def test_http_expired_token_returns_401(client):
    response = client.get("/tools", headers=auth(exp_delta=-60))
    assert response.status_code == 401


def test_http_wrong_issuer_token_returns_401(client):
    claims = base_claims()
    claims["iss"] = "https://evil.example"
    response = client.get("/tools", headers={"Authorization": f"Bearer {sign_token(claims)}"})
    assert response.status_code == 401


def test_http_tools_filtered_by_token_permissions(client):
    full = client.get("/tools", headers=auth(permissions=FULL_PERMS, tools=FULL_TOOLS))
    assert full.status_code == 200
    names = {item["function"]["name"] for item in full.json()["tools"]}
    assert names == {"execute_transfer", "reverse_transfer", "get_account_balance"}

    restricted = client.get(
        "/tools", headers=auth(permissions=["account:read"], tools=["get_account_balance"])
    )
    assert restricted.status_code == 200
    names = {item["function"]["name"] for item in restricted.json()["tools"]}
    assert names == {"get_account_balance"}


# ---- 转账全流程经 HTTP -------------------------------------------------------


def test_http_full_transfer_flow_with_decision(client):
    system, ledger = client.system, client.ledger
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    approver = auth(sub="u_admin", permissions=FULL_PERMS, tools=FULL_TOOLS, scope="approval.admin")

    registered = client.put(
        "/approvers/u_admin", json={"max_level": "high", "active": True}, headers=approver
    )
    assert registered.status_code == 200

    requested = client.post(
        "/approvals/requests",
        json={
            "grant_id": "g_http_1",
            "tool_name": "execute_transfer",
            "args": {
                "from_account": "acc_1001",
                "to_account": "acc_1002",
                "amount": "300.00",
                "remark": "HTTP 流程货款",
            },
        },
        headers=requester,
    )
    assert requested.status_code == 200
    assert requested.json() == {"grant_id": "g_http_1", "state": "pending"}

    decided = client.post(
        "/approvals/g_http_1/decision",
        json={"decision": "approved", "reason": "HTTP 裁决"},
        headers=approver,
    )
    assert decided.status_code == 200

    invoked = client.post(
        "/invoke",
        json={
            "id": "c_http_1",
            "name": "execute_transfer",
            "arguments": {
                "from_account": "acc_1001",
                "to_account": "acc_1002",
                "amount": "300.00",
                "remark": "HTTP 流程货款",
            },
            "approval_id": "g_http_1",
            "idempotency_key": "biz_http_1",
        },
        headers=requester,
    )
    assert invoked.status_code == 200
    body = invoked.json()
    assert body["ok"] is True
    assert body["content"]["status"] == "settled"
    assert ledger.balance(TENANT, "acc_1001").to_eng_string() == "700.00"
    assert ledger.balance(TENANT, "acc_1002").to_eng_string() == "800.00"
    assert system.audit.verify_chain() is None


def test_http_reverse_flow_restores_balances(client):
    system, ledger = client.system, client.ledger
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    approver = auth(sub="u_admin", permissions=FULL_PERMS, tools=FULL_TOOLS, scope="approval.admin")
    client.put("/approvers/u_admin", json={"max_level": "high", "active": True}, headers=approver)

    def approve_and_invoke(grant_id: str, tool: str, args: dict, idem: str) -> dict:
        requested = client.post(
            "/approvals/requests",
            json={"grant_id": grant_id, "tool_name": tool, "args": args},
            headers=requester,
        )
        assert requested.status_code == 200
        decided = client.post(
            f"/approvals/{grant_id}/decision",
            json={"decision": "approved", "reason": "HTTP 裁决"},
            headers=approver,
        )
        assert decided.status_code == 200
        invoked = client.post(
            "/invoke",
            json={
                "id": f"c_{grant_id}",
                "name": tool,
                "arguments": args,
                "approval_id": grant_id,
                "idempotency_key": idem,
            },
            headers=requester,
        )
        assert invoked.status_code == 200
        return invoked.json()

    transfer_args = {
        "from_account": "acc_1001",
        "to_account": "acc_1002",
        "amount": "300.00",
        "remark": "HTTP 冲正演示",
    }
    settled = approve_and_invoke("g_http_t", "execute_transfer", transfer_args, "biz_http_t")
    reverse_args = {
        "original_transfer_id": settled["content"]["transfer_id"],
        "amount": "300.00",
        "remark": "HTTP 冲正退回",
    }
    reversed_outcome = approve_and_invoke("g_http_r", "reverse_transfer", reverse_args, "biz_http_r")
    assert reversed_outcome["content"]["status"] == "reversed"
    assert ledger.balance(TENANT, "acc_1001").to_eng_string() == "1000.00"
    assert ledger.balance(TENANT, "acc_1002").to_eng_string() == "500.00"
    assert ledger.reconcile_account(TENANT, "acc_1001")["consistent"] is True


# ---- 裁决身份与四眼原则 -------------------------------------------------------


def test_http_decision_ignores_body_decided_by(client):
    system = client.system
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    approver = auth(sub="u_admin", permissions=FULL_PERMS, tools=FULL_TOOLS, scope="approval.admin")
    client.put("/approvers/u_admin", json={"max_level": "high", "active": True}, headers=approver)
    client.post(
        "/approvals/requests",
        json={
            "grant_id": "g_ignore",
            "tool_name": "execute_transfer",
            "args": {
                "from_account": "acc_1001",
                "to_account": "acc_1002",
                "amount": "300.00",
                "remark": "伪造裁决人演示",
            },
        },
        headers=requester,
    )

    # 请求体自称 u_evil 裁决：被忽略，实际裁决人为令牌主体 u_admin。
    decided = client.post(
        "/approvals/g_ignore/decision",
        json={"decision": "approved", "reason": "令牌主体裁决", "decided_by": "u_evil"},
        headers=approver,
    )
    assert decided.status_code == 200
    ignored = [
        record
        for record in system.audit.records
        if record.get("event") == "ignored_client_claim"
    ]
    assert len(ignored) == 1
    assert ignored[0]["claimed_value"] == "u_evil"
    assert ignored[0]["decided_by_from_token"] == "u_admin"


def test_http_four_eyes_enforced_regardless_of_body(client):
    system = client.system
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    client.post(
        "/approvals/requests",
        json={
            "grant_id": "g_four_eyes",
            "tool_name": "execute_transfer",
            "args": {
                "from_account": "acc_1001",
                "to_account": "acc_1002",
                "amount": "300.00",
                "remark": "四眼原则演示",
            },
        },
        headers=requester,
    )
    # 请求人持自己的令牌裁决（即使请求体伪造他人身份）→ 四眼原则拒绝。
    decided = client.post(
        "/approvals/g_four_eyes/decision",
        json={"decision": "approved", "reason": "自批", "decided_by": "u_admin"},
        headers=requester,
    )
    assert decided.status_code == 403
    assert decided.json()["detail"]["error_code"] == "APPROVAL_DECISION_DENIED"


# ---- 授权管理与治理拒绝映射 ---------------------------------------------------


def test_http_approver_management_requires_admin_scope(client):
    no_scope = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    denied = client.put(
        "/approvers/u_100", json={"max_level": "high", "active": True}, headers=no_scope
    )
    assert denied.status_code == 403
    assert denied.json()["detail"]["error_code"] == "PERMISSION_DENIED"

    admin = auth(sub="u_admin", permissions=FULL_PERMS, tools=FULL_TOOLS, scope="approval.admin")
    registered = client.put(
        "/approvers/u_admin", json={"max_level": "low", "active": True}, headers=admin
    )
    assert registered.status_code == 200
    deactivated = client.put(
        "/approvers/u_admin", json={"max_level": "low", "active": False}, headers=admin
    )
    assert deactivated.status_code == 200
    events = [
        record.get("event")
        for record in client.system.audit.records
        if record.get("event") in {"approver_registered", "approver_deactivated"}
    ]
    assert events == ["approver_registered", "approver_deactivated"]


def test_http_governance_rejection_maps_status_and_error_code(client):
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    no_approval = client.post(
        "/invoke",
        json={
            "id": "c_no_grant",
            "name": "execute_transfer",
            "arguments": {
                "from_account": "acc_1001",
                "to_account": "acc_1002",
                "amount": "300.00",
                "remark": "无凭证调用",
            },
        },
        headers=requester,
    )
    assert no_approval.status_code == 403
    assert no_approval.json()["error_code"] == "APPROVAL_REQUIRED"

    bad_args = client.post(
        "/invoke",
        json={"id": "c_bad", "name": "execute_transfer", "arguments": {"from_account": "???"}},
        headers=requester,
    )
    assert bad_args.status_code == 400
    assert bad_args.json()["error_code"] == "INVALID_ARGUMENT"


def test_http_invoke_rejects_client_mode_field(client):
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    response = client.post(
        "/invoke",
        json={
            "id": "c_mode",
            "name": "get_account_balance",
            "arguments": {"account": "acc_1001"},
            "mode": "bypassConfirmation",
        },
        headers=requester,
    )
    assert response.status_code == 400
    assert response.json()["error_code"] == "INVALID_ARGUMENT"


def test_http_approval_input_boundaries(client):
    requester = auth(sub="u_100", permissions=FULL_PERMS, tools=FULL_TOOLS)
    invalid_ttl = client.post(
        "/approvals/requests",
        json={
            "grant_id": "g_ttl",
            "tool_name": "execute_transfer",
            "args": {},
            "ttl_seconds": 86401,
        },
        headers=requester,
    )
    invalid_decision = client.post(
        "/approvals/g_ttl/decision",
        json={"decision": "maybe", "reason": "无效决策"},
        headers=requester,
    )
    assert invalid_ttl.status_code == 400
    assert invalid_ttl.json()["error_code"] == "INVALID_ARGUMENT"
    assert invalid_decision.status_code == 400
    assert invalid_decision.json()["error_code"] == "INVALID_ARGUMENT"


# ---- JWKS TTL 缓存轮换与签名密钥注入（Round-6） -------------------------------


def test_jwks_unknown_kid_refreshes_rotation():
    key1 = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    key2 = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    jwk1 = json.loads(RSAAlgorithm.to_jwk(key1.public_key()))
    jwk1["kid"] = "rotating-key-1"
    jwk2 = json.loads(RSAAlgorithm.to_jwk(key2.public_key()))
    jwk2["kid"] = "rotating-key-2"
    state = {"jwks": {"keys": [jwk1]}}

    async def fetch() -> dict:
        return state["jwks"]

    verifier = OidcVerifier(ISSUER, AUDIENCE, jwks_fetcher=fetch, cache_ttl_seconds=0.2)
    token1 = jwt.encode(base_claims(), key1, algorithm="RS256", headers={"kid": "rotating-key-1"})
    assert asyncio.run(verifier.verify(token1))["sub"] == "u_100"

    # IdP 轮换密钥：未知 kid 立即刷新，无需等待缓存 TTL；旧 kid 随新 JWKS 失效。
    state["jwks"] = {"keys": [jwk2]}
    token2 = jwt.encode(base_claims(), key2, algorithm="RS256", headers={"kid": "rotating-key-2"})
    assert asyncio.run(verifier.verify(token2))["sub"] == "u_100"
    with pytest.raises(jwt.PyJWTError):
        asyncio.run(verifier.verify(token1))


def test_signer_from_env_injects_persistent_key(monkeypatch):
    generated = Ed25519GrantSigner.generate()
    raw_hex = generated.private_bytes("ed25519_001").hex()
    monkeypatch.setenv("GOVERNED_SIGNING_KEY", raw_hex)
    monkeypatch.setenv("GOVERNED_SIGNING_KID", "prod_key_01")
    signer = build_signer_from_env()
    assert signer.primary_kid == "prod_key_01"
    payload = grant_signature_payload(
        grant_id="g", user_id="u", tenant_id=TENANT, tool_name="execute_transfer",
        digest="0" * 64, level="low", expires_at=9999.0,
    )
    kid, signature = signer.sign(payload)
    # 模拟重启：同环境变量重建签名器后，存量凭证仍可验签（持久化注入路径）。
    restarted = build_signer_from_env()
    assert restarted.verify(payload, signature, kid) is True


def test_signer_from_env_warns_and_generates_temp_key(monkeypatch, capsys):
    monkeypatch.delenv("GOVERNED_SIGNING_KEY", raising=False)
    signer = build_signer_from_env()
    assert signer.primary_kid == "ed25519_001"
    assert "GOVERNED_SIGNING_KEY" in capsys.readouterr().err


def test_signer_from_env_rejects_malformed_key(monkeypatch):
    monkeypatch.setenv("GOVERNED_SIGNING_KEY", "zz-not-hex")
    with pytest.raises(ValueError, match="GOVERNED_SIGNING_KEY"):
        build_signer_from_env()


# ---- 真实 IdP 冒烟（环境变量开关） -------------------------------------------


TEST_OIDC_ISSUER = os.environ.get("TEST_OIDC_ISSUER", "")
TEST_OIDC_AUDIENCE = os.environ.get("TEST_OIDC_AUDIENCE", "")
TEST_OIDC_JWKS_URI = os.environ.get("TEST_OIDC_JWKS_URI", "")


@pytest.mark.skipif(
    not (TEST_OIDC_ISSUER and TEST_OIDC_JWKS_URI), reason="未配置 TEST_OIDC_* 时跳过真实 IdP 冒烟"
)
def test_real_oidc_jwks_fetch_smoke():
    verifier = OidcVerifier(
        TEST_OIDC_ISSUER, TEST_OIDC_AUDIENCE or "smoke", jwks_uri=TEST_OIDC_JWKS_URI
    )
    jwks = asyncio.run(verifier.fetch_jwks())
    assert jwks.get("keys")
