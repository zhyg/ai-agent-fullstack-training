"""治理运行时与转账工具闭环的确定性验收测试。

全部用例只从运行时公开入口进，断言三类可观察结果：
返回结果对象（成功标记 / 错误码 / 内容）、账本终态余额、审计记录。
端口契约套件（锁、签名器）为既有例外：验证端口自身语义，与运行时门禁无关。
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone
from decimal import Decimal

import fakeredis.aioredis
import pytest

from governance import (
    AccessDecider,
    GoverningMode,
    GovernedToolRuntime,
    GovernanceViolation,
    HazardLevel,
    OutcomeCode,
    RegisteredTool,
    SessionContext,
    SideEffect,
    StrictToolArgs,
    ToolCallRequest,
    ToolGovernancePolicy,
    TransientDependencyError,
    request_digest,
)
from outbox import (
    DEFAULT_STREAM,
    EventRelay,
    ReplicaApplier,
    read_stream_events,
)
from redis_locks import RedisLockManager
from signing import Ed25519GrantSigner, RotationPolicy, grant_signature_payload
from storage import AccountLedger, ApprovalLedger, AuditJournal, RateLimiter, SqliteLockManager
from transfer_tool import (
    ReverseInstruction,
    ToolPolicyTransfer,
    TransferInstruction,
    compose_transfer_system,
    make_transfer_action,
)


TENANT = "tenant_a"
PERMS_FULL = frozenset({
    ("tenant_a", "transfer:execute"),
    ("tenant_a", "transfer:reverse"),
    ("tenant_a", "account:read"),
    ("tenant_a", "test:write"),
    ("tenant_a", "test:confirm"),
})
TOOLS_FULL = frozenset({
    "execute_transfer", "reverse_transfer", "get_account_balance",
    "slow_write", "flaky_read", "note_jot",
})


def make_ledger() -> AccountLedger:
    ledger = AccountLedger()
    ledger.open_account(TENANT, "acc_1001", "1000.00")
    ledger.open_account(TENANT, "acc_1002", "500.00")
    ledger.open_account(TENANT, "acc_1003", "100.00")
    ledger.open_account(TENANT, "acc_1004", "100.00", status="frozen")
    return ledger


def make_ctx(
    *,
    trace_id: str = "trace_001",
    user_id: str = "u_100",
    tenant_id: str = TENANT,
    permissions: frozenset[tuple[str, str]] = PERMS_FULL,
    allowed_tools: frozenset[str] = TOOLS_FULL,
    approval_id: str | None = None,
    idempotency_key: str | None = None,
    mode: GoverningMode = GoverningMode.STANDARD,
) -> SessionContext:
    return SessionContext(
        trace_id=trace_id,
        user_id=user_id,
        tenant_id=tenant_id,
        permissions=permissions,
        allowed_tools=allowed_tools,
        approval_id=approval_id,
        idempotency_key=idempotency_key,
        mode=mode,
    )


def transfer_call(
    call_id: str,
    *,
    source: str = "acc_1001",
    target: str = "acc_1002",
    amount: str = "300.00",
    remark: str = "货款结算",
    extra: dict | None = None,
) -> ToolCallRequest:
    arguments: dict = {
        "from_account": source,
        "to_account": target,
        "amount": amount,
        "remark": remark,
    }
    if extra:
        arguments.update(extra)
    return ToolCallRequest(call_id, "execute_transfer", arguments)


async def approve(
    system,
    args,
    *,
    grant_id: str = "grant_01",
    user_id: str = "u_100",
    tenant_id: str = TENANT,
    ttl_seconds: int = 300,
    tool_name: str = "execute_transfer",
) -> None:
    await system.issue_approval(
        grant_id,
        user_id=user_id,
        tenant_id=tenant_id,
        args=args,
        ttl_seconds=ttl_seconds,
        tool_name=tool_name,
    )


def reverse_call(
    call_id: str,
    *,
    original: str = "trf_000001",
    amount: str = "300.00",
    remark: str = "冲正退回",
    extra: dict | None = None,
) -> ToolCallRequest:
    arguments: dict = {
        "original_transfer_id": original,
        "amount": amount,
        "remark": remark,
    }
    if extra:
        arguments.update(extra)
    return ToolCallRequest(call_id, "reverse_transfer", arguments)


async def settle_transfer(
    system,
    *,
    source: str = "acc_1001",
    target: str = "acc_1002",
    amount: str = "300.00",
    remark: str = "货款结算",
    grant_id: str = "grant_01",
    idempotency_key: str = "biz_001",
) -> dict:
    """经公开入口结算一笔转账并返回其流水内容（含 transfer_id）。"""
    args = TransferInstruction.model_validate({
        "from_account": source,
        "to_account": target,
        "amount": amount,
        "remark": remark,
    })
    await approve(system, args, grant_id=grant_id)
    outcome = await system.runtime.invoke(
        ToolCallRequest("call_settle", "execute_transfer", args.model_dump(mode="python")),
        make_ctx(approval_id=grant_id, idempotency_key=idempotency_key),
    )
    assert outcome.ok is True
    return outcome.content


@pytest.fixture
def ledger() -> AccountLedger:
    return make_ledger()


@pytest.fixture
def system(ledger: AccountLedger):
    return compose_transfer_system(ledger)


# ---- 用例 1：正常转账 -------------------------------------------------------


async def test_approved_transfer_settles_both_balances(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args)
    outcome = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(approval_id="grant_01", idempotency_key="biz_001"),
    )
    assert outcome.ok is True
    assert outcome.content["status"] == "settled"
    assert outcome.content["business_ref"] == "biz_001"
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("800.00")
    record = system.audit.records[-1]
    assert record["ok"] is True
    assert record["risk"] == "high"
    assert record["mode"] == "default"
    assert record["duration_ms"] >= 0
    assert "from_account" in record["argument_keys"]


# ---- 用例 2：无审批凭证 -----------------------------------------------------


async def test_transfer_without_approval_is_rejected(system, ledger):
    outcome = await system.runtime.invoke(transfer_call("call_01"), make_ctx())
    assert outcome.ok is False
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


# ---- 用例 3：审批凭证与金额、收款方强绑定 ------------------------------------


async def test_approval_rejects_tampered_amount_and_payee(system, ledger):
    original = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, original)
    tampered_amount = await system.runtime.invoke(
        transfer_call("call_01", amount="500.00"),
        make_ctx(approval_id="grant_01"),
    )
    tampered_payee = await system.runtime.invoke(
        transfer_call("call_01", target="acc_1003"),
        make_ctx(approval_id="grant_01"),
    )
    assert tampered_amount.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert tampered_payee.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")
    assert ledger.balance(TENANT, "acc_1003") == Decimal("100.00")


# ---- 用例 4：审批凭证一次性 -------------------------------------------------


async def test_approval_grant_is_single_use(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args)
    first = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_01")
    )
    second = await system.runtime.invoke(
        transfer_call("call_02"), make_ctx(approval_id="grant_01")
    )
    assert first.ok is True
    assert second.error_code == OutcomeCode.APPROVAL_REQUIRED
    # 第二次被拒后不得重复扣款。
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("800.00")


# ---- 用例 5：余额不足与冻结账户 ---------------------------------------------


async def test_insufficient_funds_is_denied(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01", amount="1000.01").arguments)
    await approve(system, args)
    outcome = await system.runtime.invoke(
        transfer_call("call_01", amount="1000.01"), make_ctx(approval_id="grant_01")
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


async def test_frozen_source_account_is_denied(system, ledger):
    args = TransferInstruction.model_validate(
        transfer_call("call_01", source="acc_1004", target="acc_1002", amount="50.00").arguments
    )
    await approve(system, args)
    outcome = await system.runtime.invoke(
        transfer_call("call_01", source="acc_1004", target="acc_1002", amount="50.00"),
        make_ctx(approval_id="grant_01"),
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1004") == Decimal("100.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


# ---- 用例 6：参数夹带越权字段 -----------------------------------------------


async def test_smuggled_self_authorization_fields_are_rejected(system, ledger):
    outcome = await system.runtime.invoke(
        transfer_call("call_01", extra={"approved": True, "user_id": "u_100"}),
        make_ctx(),
    )
    assert outcome.ok is False
    assert outcome.error_code == OutcomeCode.INVALID_ARGUMENT
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


# ---- 用例 7：双向并发不死锁、不超扣 ------------------------------------------


async def test_bidirectional_concurrent_transfers_stay_consistent(system, ledger):
    forward_args = TransferInstruction.model_validate(
        transfer_call("fwd", amount="300.00").arguments
    )
    backward_args = TransferInstruction.model_validate(
        transfer_call("bwd", source="acc_1002", target="acc_1001", amount="200.00").arguments
    )
    await approve(system, forward_args, grant_id="grant_fwd")
    await approve(system, backward_args, grant_id="grant_bwd")

    results = await asyncio.wait_for(
        asyncio.gather(
            system.runtime.invoke(
                transfer_call("fwd", amount="300.00"),
                make_ctx(trace_id="trace_fwd", approval_id="grant_fwd"),
            ),
            system.runtime.invoke(
                transfer_call("bwd", source="acc_1002", target="acc_1001", amount="200.00"),
                make_ctx(trace_id="trace_bwd", approval_id="grant_bwd"),
            ),
        ),
        timeout=5.0,
    )
    assert all(r.ok for r in results)
    assert ledger.balance(TENANT, "acc_1001") == Decimal("900.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("600.00")
    total = ledger.total_of(TENANT, ["acc_1001", "acc_1002"])
    assert total == Decimal("1500.00")


# ---- 用例 8：同账户并发多笔串行执行 ------------------------------------------


async def test_same_account_concurrent_transfers_serialize(system, ledger):
    first_args = TransferInstruction.model_validate(
        transfer_call("t1", target="acc_1002", amount="300.00").arguments
    )
    second_args = TransferInstruction.model_validate(
        transfer_call("t2", target="acc_1003", amount="300.00").arguments
    )
    await approve(system, first_args, grant_id="grant_t1")
    await approve(system, second_args, grant_id="grant_t2")

    results = await asyncio.wait_for(
        asyncio.gather(
            system.runtime.invoke(
                transfer_call("t1", target="acc_1002", amount="300.00"),
                make_ctx(trace_id="trace_t1", approval_id="grant_t1"),
            ),
            system.runtime.invoke(
                transfer_call("t2", target="acc_1003", amount="300.00"),
                make_ctx(trace_id="trace_t2", approval_id="grant_t2"),
            ),
        ),
        timeout=5.0,
    )
    assert all(r.ok for r in results)
    # 两笔共用同一出账账户：串行执行后余额恰好扣减 600，不超扣、不丢钱。
    assert ledger.balance(TENANT, "acc_1001") == Decimal("400.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("800.00")
    assert ledger.balance(TENANT, "acc_1003") == Decimal("400.00")
    assert ledger.total_of(TENANT, ["acc_1001", "acc_1002", "acc_1003"]) == Decimal("1600.00")


# ---- 用例 9：出账等于入账 ---------------------------------------------------


async def test_self_transfer_is_rejected_by_schema(system, ledger):
    outcome = await system.runtime.invoke(
        transfer_call("call_01", source="acc_1001", target="acc_1001"),
        make_ctx(approval_id="grant_01"),
    )
    assert outcome.error_code == OutcomeCode.INVALID_ARGUMENT
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


# ---- 用例 10：写操作超时返回「结果未知」且绝不重试 ---------------------------


class _EmptyArgs(StrictToolArgs):
    pass


async def test_write_timeout_reports_unknown_and_never_retries():
    attempts: list[int] = []

    async def slow_action(args, ctx):
        attempts.append(1)
        await asyncio.sleep(0.3)
        return {}

    tool = RegisteredTool(
        name="slow_write",
        description="用于验证写操作超时语义的慢速工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.MUTATING,
            risk=HazardLevel.LOW,
            required_permission="test:write",
            timeout_seconds=0.05,
            retry_budget=3,
            idempotent=False,
        ),
        action=slow_action,
        target_key=lambda args, ctx: f"{ctx.tenant_id}:slow",
    )
    runtime = GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    outcome = await runtime.invoke(
        ToolCallRequest("call_01", "slow_write", {}), make_ctx()
    )
    assert outcome.ok is False
    assert outcome.error_code == OutcomeCode.TIMEOUT_UNKNOWN
    assert "结果未知" in outcome.content["message"]
    assert len(attempts) == 1  # 非幂等写操作不自动重试


# ---- 用例 11：plan 模式拒绝写操作 -------------------------------------------


async def test_plan_mode_blocks_transfer(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args)
    outcome = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(approval_id="grant_01", mode=GoverningMode.PLAN_ONLY),
    )
    assert outcome.error_code == OutcomeCode.PLAN_MODE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


# ---- 用例 12：dontAsk 模式无法请求审批与确认 ---------------------------------


async def test_silent_mode_cannot_request_approval_or_confirmation(system):
    denied_approval = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(mode=GoverningMode.SILENT),
    )
    assert denied_approval.error_code == OutcomeCode.APPROVAL_FLOW_UNAVAILABLE

    class _NoteArgs(StrictToolArgs):
        text: str

    async def note_action(args, ctx):
        return {"saved": True}

    tool = RegisteredTool(
        name="note_jot",
        description="用于验证确认类门禁的工具。",
        parameters_model=_NoteArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.MUTATING,
            risk=HazardLevel.LOW,
            required_permission="test:confirm",
            needs_user_confirmation=True,
        ),
        action=note_action,
        target_key=lambda args, ctx: f"{ctx.tenant_id}:note",
    )
    runtime = GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    denied_confirmation = await runtime.invoke(
        ToolCallRequest("call_02", "note_jot", {"text": "备注内容"}),
        make_ctx(mode=GoverningMode.SILENT),
    )
    assert denied_confirmation.error_code == OutcomeCode.CONFIRMATION_FLOW_UNAVAILABLE


# ---- 用例 13：bypassPermissions 跳过确认但不可绕过审批 ------------------------


async def test_bypass_mode_skips_confirmation_but_not_approval():
    class _NoteArgs(StrictToolArgs):
        text: str

    async def note_action(args, ctx):
        return {"saved": True}

    confirm_tool = RegisteredTool(
        name="note_jot",
        description="仅要求用户确认的写工具。",
        parameters_model=_NoteArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.MUTATING,
            risk=HazardLevel.LOW,
            required_permission="test:confirm",
            needs_user_confirmation=True,
        ),
        action=note_action,
        target_key=lambda args, ctx: f"{ctx.tenant_id}:note",
    )
    runtime = GovernedToolRuntime([confirm_tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    bypassed = await runtime.invoke(
        ToolCallRequest("call_01", "note_jot", {"text": "自动化备注"}),
        make_ctx(mode=GoverningMode.AUTO_BYPASS),
    )
    assert bypassed.ok is True

    # 强制审批在 bypass 模式下仍必须核销：无凭证的转账被拒。
    ledger = make_ledger()
    system = compose_transfer_system(ledger)
    still_blocked = await system.runtime.invoke(
        transfer_call("call_02"),
        make_ctx(mode=GoverningMode.AUTO_BYPASS, allowed_tools=frozenset({"execute_transfer"}),
                 permissions=frozenset({("tenant_a", "transfer:execute")})),
    )
    assert still_blocked.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


# ---- 用例 14：白名单与 RBAC 错误码可区分 --------------------------------------


async def test_whitelist_and_rbac_errors_are_distinct(system):
    not_in_whitelist = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(allowed_tools=frozenset({"get_account_balance"})),
    )
    missing_permission = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(permissions=frozenset({("tenant_a", "account:read")})),
    )
    assert not_in_whitelist.error_code == OutcomeCode.TOOL_NOT_ALLOWED
    assert missing_permission.error_code == OutcomeCode.PERMISSION_DENIED
    assert not_in_whitelist.error_code != missing_permission.error_code


# ---- 用例 15：工具投影按授权收敛 ---------------------------------------------


async def test_projection_hides_unauthorized_tools(system):
    restricted_ctx = make_ctx(
        permissions=frozenset({("tenant_a", "account:read")}),
        allowed_tools=frozenset({"execute_transfer", "get_account_balance"}),
    )
    visible = system.runtime.visible_tools(restricted_ctx)
    names = [item["function"]["name"] for item in visible]
    assert names == ["get_account_balance"]
    schema = visible[0]["function"]["parameters"]
    assert "account" in schema["properties"]

    empty_ctx = make_ctx(permissions=frozenset(), allowed_tools=frozenset())
    assert system.runtime.visible_tools(empty_ctx) == []


# ---- 用例 16：审计完整性与敏感字段脱敏 ----------------------------------------


async def test_audit_trail_is_complete_and_redacted(system, ledger):
    balance_outcome = await system.runtime.invoke(
        ToolCallRequest("call_01", "get_account_balance", {"account": "acc_1001"}),
        make_ctx(),
    )
    assert balance_outcome.ok is True
    assert balance_outcome.content["session_token"] == "***"

    denied = await system.runtime.invoke(transfer_call("call_02"), make_ctx())
    assert denied.error_code == OutcomeCode.APPROVAL_REQUIRED

    records = {r["tool_call_id"]: r for r in system.audit.records}
    read_record = records["call_01"]
    assert read_record["ok"] is True
    assert read_record["mode"] == "default"
    assert read_record["risk"] == "low"
    assert read_record["duration_ms"] >= 0
    assert read_record["argument_keys"] == ["account"]
    denied_record = records["call_02"]
    assert denied_record["ok"] is False
    assert denied_record["error_code"] == OutcomeCode.APPROVAL_REQUIRED

    # 审计通道不承载任何明文敏感值。
    assert "do-not-leak" not in json.dumps(system.audit.records, ensure_ascii=False)


# ---- 补充：读操作瞬态故障按预算退避重试 ----------------------------------------


async def test_read_tool_retries_transient_failures_within_budget():
    attempts: list[int] = []

    async def flaky_action(args, ctx):
        attempts.append(1)
        if len(attempts) < 3:
            raise TransientDependencyError("下游闪断")
        return {"value": "recovered"}

    tool = RegisteredTool(
        name="flaky_read",
        description="用于验证读操作重试语义的工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.READ_ONLY,
            risk=HazardLevel.LOW,
            required_permission="test:write",
            timeout_seconds=1.0,
            retry_budget=2,
            idempotent=True,
        ),
        action=flaky_action,
        target_key=lambda args, ctx: f"{ctx.tenant_id}:flaky",
    )
    runtime = GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    outcome = await runtime.invoke(ToolCallRequest("call_01", "flaky_read", {}), make_ctx())
    assert outcome.ok is True
    assert outcome.content["value"] == "recovered"
    assert len(attempts) == 3


# ---- 用例 18：重启后账本、流水、审计与审批凭证全部保留 -----------------------


def test_restart_preserves_balances_transfers_audit_and_approvals(tmp_path):
    db_path = str(tmp_path / "ledger.db")
    ledger = AccountLedger(db_path=db_path)
    ledger.open_account(TENANT, "acc_1001", "1000.00")
    ledger.open_account(TENANT, "acc_1002", "500.00")
    # 签名密钥经组合根注入：多实例/跨重启共享同一签名器是部署契约。
    signer = Ed25519GrantSigner.generate()
    system = compose_transfer_system(ledger, signer=signer)
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)

    async def first() -> None:
        await approve(system, args, grant_id="grant_restart")

    asyncio.run(first())
    ledger.close()

    # 模拟进程重启：同一数据库文件重建组合根，注入同一签名器后凭证跨重启仍可核销。
    reopened = AccountLedger(db_path=db_path)
    system2 = compose_transfer_system(reopened, signer=signer)

    async def second():
        outcome = await system2.runtime.invoke(
            transfer_call("call_01"),
            make_ctx(approval_id="grant_restart", idempotency_key="biz_restart"),
        )
        assert outcome.ok is True
        return outcome

    outcome = asyncio.run(second())
    assert reopened.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert reopened.balance(TENANT, "acc_1002") == Decimal("800.00")
    matched = reopened.get_transfer_by_business_ref(TENANT, "biz_restart")
    assert matched is not None and matched["transfer_id"] == outcome.content["transfer_id"]
    assert any(r.get("tool_call_id") == "call_01" for r in system2.audit.records)


# ---- 用例 19：幂等键防重与冲突 -------------------------------------------------


async def test_idempotent_replay_returns_same_transfer(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_replay_1")
    first = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(approval_id="grant_replay_1", idempotency_key="biz_replay"),
    )
    # 原凭证虽一次性核销，仍可与原幂等键组合安全重放，不重复扣款。
    second = await system.runtime.invoke(
        transfer_call("call_02"),
        make_ctx(approval_id="grant_replay_1", idempotency_key="biz_replay"),
    )
    assert first.ok is True and second.ok is True
    assert first.content["transfer_id"] == second.content["transfer_id"]
    assert second.content["business_ref"] == "biz_replay"
    # 余额只变动一次。
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("800.00")
    # 换幂等键不能复用已核销凭证，防止把重放通道变成第二次授权。
    rejected = await system.runtime.invoke(
        transfer_call("call_03"),
        make_ctx(approval_id="grant_replay_1", idempotency_key="biz_other"),
    )
    assert rejected.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")


async def test_idempotency_conflict_on_different_params(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_conflict_1")
    first = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(approval_id="grant_conflict_1", idempotency_key="biz_conflict"),
    )
    assert first.ok is True

    tampered = TransferInstruction.model_validate(transfer_call("call_02", amount="400.00").arguments)
    await approve(system, tampered, grant_id="grant_conflict_2")
    second = await system.runtime.invoke(
        transfer_call("call_02", amount="400.00"),
        make_ctx(approval_id="grant_conflict_2", idempotency_key="biz_conflict"),
    )
    assert second.error_code == OutcomeCode.IDEMPOTENCY_CONFLICT
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("800.00")


# ---- 用例 20：无凭证调用得不到任何账户线索（余额 oracle 关闭） -----------------


async def test_unapproved_calls_reveal_no_account_details(system, ledger):
    probes = [
        transfer_call("p1", source="acc_9999"),                 # 账户不存在
        transfer_call("p2", amount="50000.00"),                 # 余额不足（低于日累计上限）
        transfer_call("p3", source="acc_1004"),                 # 冻结账户
    ]
    for probe in probes:
        outcome = await system.runtime.invoke(probe, make_ctx())
        assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
        serialized = json.dumps(outcome.content, ensure_ascii=False)
        assert "acc_" not in serialized
        assert "余额" not in serialized

    # 持有与参数一致的凭证后，业务细节才对调用方可见。
    args = TransferInstruction.model_validate(transfer_call("p4", source="acc_9999").arguments)
    await approve(system, args, grant_id="grant_probe")
    outcome = await system.runtime.invoke(
        transfer_call("p4", source="acc_9999"), make_ctx(approval_id="grant_probe")
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED


# ---- 用例 21：金额分层审批 ----------------------------------------------------


async def test_high_amount_requires_high_level_approval(system, ledger):
    ledger.open_account(TENANT, "acc_1005", "50000.00")
    args = TransferInstruction.model_validate(
        transfer_call("t1", source="acc_1005", target="acc_1002", amount="10000.00").arguments
    )
    # 低级凭证无法覆盖超阈值转账。
    system.approvals.issue(
        "grant_low", user_id="u_100", tenant_id=TENANT,
        tool_name="execute_transfer", args=args, level="low",
    )
    rejected = await system.runtime.invoke(
        transfer_call("t1", source="acc_1005", target="acc_1002", amount="10000.00"),
        make_ctx(approval_id="grant_low"),
    )
    assert rejected.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1005") == Decimal("50000.00")

    # 组合根签发按金额自动定级为 high。
    await approve(system, args, grant_id="grant_high")
    accepted = await system.runtime.invoke(
        transfer_call("t2", source="acc_1005", target="acc_1002", amount="10000.00"),
        make_ctx(approval_id="grant_high"),
    )
    assert accepted.ok is True
    assert ledger.balance(TENANT, "acc_1005") == Decimal("40000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("10500.00")


async def test_high_level_approval_accepts_low_tier_transfer(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("t1").arguments)
    system.approvals.issue(
        "grant_high", user_id="u_100", tenant_id=TENANT,
        tool_name="execute_transfer", args=args, level="high",
    )
    outcome = await system.runtime.invoke(
        transfer_call("t1"), make_ctx(approval_id="grant_high")
    )
    assert outcome.ok is True
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")


# ---- 用例 22：签发审计 -------------------------------------------------------


async def test_approval_issuance_is_audited(system):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_audited")
    events = [r for r in system.audit.records if r.get("event") == "approval_issued"]
    assert len(events) == 1
    event = events[0]
    assert event["grant_id"] == "grant_audited"
    assert event["issued_by"] == "u_100"
    assert event["tenant_id"] == TENANT
    assert event["tool_name"] == "execute_transfer"
    assert event["level"] == "low"
    assert event["digest"] == request_digest("execute_transfer", args, level="low")
    # 审计不承载参数明文。
    assert "from_account" not in event


# ---- 用例 23：租户隔离 -------------------------------------------------------


async def test_cross_tenant_permission_is_denied(system, ledger):
    ctx = make_ctx(
        tenant_id="tenant_b",
        permissions=frozenset({("tenant_a", "transfer:execute"), ("tenant_a", "account:read")}),
        allowed_tools=frozenset({"execute_transfer", "get_account_balance"}),
    )
    outcome = await system.runtime.invoke(transfer_call("call_01"), ctx)
    assert outcome.error_code == OutcomeCode.PERMISSION_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


async def test_tenant_accounts_are_isolated(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_b", tenant_id="tenant_b")
    ctx = make_ctx(
        tenant_id="tenant_b",
        permissions=frozenset({("tenant_b", "transfer:execute"), ("tenant_b", "account:read")}),
        approval_id="grant_b",
    )
    outcome = await system.runtime.invoke(transfer_call("call_01"), ctx)
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


# ---- 用例 24：账本约束与 schema 版本 ------------------------------------------


def test_duplicate_open_account_is_rejected(ledger):
    with pytest.raises(ValueError, match="账户已存在"):
        ledger.open_account(TENANT, "acc_1001", "50.00")
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


def test_schema_version_mismatch_is_rejected(tmp_path):
    db_path = str(tmp_path / "v.db")
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA user_version = 99")
    conn.close()
    with pytest.raises(RuntimeError, match="schema 版本不支持"):
        AccountLedger(db_path=db_path)


# ---- 用例 25：等价金额表示共享同一摘要 ----------------------------------------


async def test_equivalent_amount_representations_share_digest(system, ledger):
    args_two = TransferInstruction.model_validate(transfer_call("call_01", amount="300.00").arguments)
    args_one = TransferInstruction.model_validate(transfer_call("call_01", amount="300.0").arguments)
    assert request_digest("execute_transfer", args_two) == request_digest("execute_transfer", args_one)

    await approve(system, args_two, grant_id="grant_norm")
    outcome = await system.runtime.invoke(
        transfer_call("call_02", amount="300.0"), make_ctx(approval_id="grant_norm")
    )
    assert outcome.ok is True
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")


# ---- 用例 26：跨实例跨连接并发由 SQLite 咨询锁串行化 -------------------------


def test_cross_instance_concurrent_transfers_serialize(tmp_path):
    db_path = str(tmp_path / "shared.db")
    ledger_a = AccountLedger(db_path=db_path)
    ledger_a.open_account(TENANT, "acc_1001", "1000.00")
    ledger_a.open_account(TENANT, "acc_1002", "500.00")
    # 多实例共享库须注入同一签名器，凭证才能跨实例验签。
    signer = Ed25519GrantSigner.generate()
    system_a = compose_transfer_system(ledger_a, signer=signer)
    # 第二个组合根独立连接同一数据库文件，模拟另一进程/实例。
    system_b = compose_transfer_system(AccountLedger(db_path=db_path), signer=signer)

    async def run():
        forward_args = TransferInstruction.model_validate(
            transfer_call("fwd", amount="300.00").arguments
        )
        backward_args = TransferInstruction.model_validate(
            transfer_call("bwd", source="acc_1002", target="acc_1001", amount="200.00").arguments
        )
        await approve(system_a, forward_args, grant_id="grant_fwd")
        await approve(system_a, backward_args, grant_id="grant_bwd")
        results = await asyncio.wait_for(
            asyncio.gather(
                system_a.runtime.invoke(
                    transfer_call("fwd", amount="300.00"),
                    make_ctx(trace_id="trace_fwd", approval_id="grant_fwd"),
                ),
                system_b.runtime.invoke(
                    transfer_call("bwd", source="acc_1002", target="acc_1001", amount="200.00"),
                    make_ctx(trace_id="trace_bwd", approval_id="grant_bwd"),
                ),
            ),
            timeout=5.0,
        )
        return results

    results = asyncio.run(run())
    assert all(r.ok for r in results)
    assert ledger_a.balance(TENANT, "acc_1001") == Decimal("900.00")
    assert ledger_a.balance(TENANT, "acc_1002") == Decimal("600.00")
    assert ledger_a.total_of(TENANT, ["acc_1001", "acc_1002"]) == Decimal("1500.00")


# ---- 用例 27：复式分录借贷两腿 ---------------------------------------------


async def test_double_entry_records_both_sides(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args)
    outcome = await system.runtime.invoke(
        transfer_call("call_01"),
        make_ctx(approval_id="grant_01", idempotency_key="biz_de"),
    )
    assert outcome.ok is True
    transfer_id = outcome.content["transfer_id"]

    source_entry = next(
        row for row in ledger.statement(TENANT, "acc_1001") if row["transfer_id"] == transfer_id
    )
    target_entry = next(
        row for row in ledger.statement(TENANT, "acc_1002") if row["transfer_id"] == transfer_id
    )
    assert source_entry["side"] == "debit"
    assert target_entry["side"] == "credit"
    assert Decimal(source_entry["amount"]) == Decimal("300.00")
    # 借贷恒等：同一流水号的两腿金额相等。
    assert Decimal(source_entry["amount"]) == Decimal(target_entry["amount"])


# ---- 用例 28：审批生命周期（请求 -> 裁决 -> 核销） ---------------------------


async def test_approval_lifecycle_pending_then_approved_is_consumable(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_life", user_id="u_100", tenant_id=TENANT, args=args)

    pending = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_life")
    )
    assert pending.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")

    system.register_approver("u_admin", TENANT, max_level="high")
    await system.decide_approval(
        "grant_life", decision="approved", decided_by="u_admin", reason="合规复核通过"
    )
    accepted = await system.runtime.invoke(
        transfer_call("call_02"), make_ctx(approval_id="grant_life")
    )
    assert accepted.ok is True
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")

    events = {r.get("event") for r in system.audit.records}
    assert {"approval_requested", "approval_approved"} <= events


async def test_revoked_approval_is_rejected(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_rev", user_id="u_100", tenant_id=TENANT, args=args)
    system.register_approver("u_admin", TENANT, max_level="high")
    await system.decide_approval(
        "grant_rev", decision="revoked", decided_by="u_admin", reason="风控拦截"
    )

    outcome = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_rev")
    )
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert "approval_revoked" in {r.get("event") for r in system.audit.records}


# ---- 用例 29：审批凭证 TTL 过期 ---------------------------------------------


async def test_expired_approval_grant_is_rejected(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_ttl", ttl_seconds=-1)
    outcome = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_ttl")
    )
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


# ---- 用例 30：固定窗口限频 ---------------------------------------------------


async def test_rate_limit_rejects_burst_and_audits():
    async def quick_read(args, ctx):
        return {"value": "ok"}

    tool = RegisteredTool(
        name="rate_limited_read",
        description="用于验证固定窗口限频的读工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.READ_ONLY,
            risk=HazardLevel.LOW,
            required_permission="account:read",
            rate_limit=2,
            rate_window_seconds=60.0,
        ),
        action=quick_read,
    )
    runtime = GovernedToolRuntime(
        [tool], AccessDecider(), ApprovalLedger(), AuditJournal(), limits=RateLimiter()
    )
    first = await runtime.invoke(
        ToolCallRequest("r1", "rate_limited_read", {}),
        make_ctx(allowed_tools=frozenset({"rate_limited_read"})),
    )
    second = await runtime.invoke(
        ToolCallRequest("r2", "rate_limited_read", {}),
        make_ctx(allowed_tools=frozenset({"rate_limited_read"})),
    )
    third = await runtime.invoke(
        ToolCallRequest("r3", "rate_limited_read", {}),
        make_ctx(allowed_tools=frozenset({"rate_limited_read"})),
    )
    assert first.ok is True and second.ok is True
    assert third.error_code == OutcomeCode.RATE_LIMITED
    events = [r for r in runtime.audit.records if r.get("event") == "rate_limited"]
    assert len(events) == 1
    assert events[0]["tool_call_id"] == "r3"


# ---- 用例 31：租户日累计限额 -------------------------------------------------


async def test_daily_cap_boundary_fast_fails_before_approval(system, ledger):
    ledger.open_account(TENANT, "acc_2001", "100000.00")
    big = TransferInstruction.model_validate(
        transfer_call("d1", source="acc_2001", target="acc_1002", amount="100000.00").arguments
    )
    await approve(system, big, grant_id="grant_daily")
    first = await system.runtime.invoke(
        transfer_call("d1", source="acc_2001", target="acc_1002", amount="100000.00"),
        make_ctx(approval_id="grant_daily"),
    )
    assert first.ok is True
    assert ledger.balance(TENANT, "acc_2001") == Decimal("0.00")

    # 超过日累计：门禁在审批校验之前即拒绝，未持凭证同样命中 RATE_LIMITED。
    over = await system.runtime.invoke(
        transfer_call("d2", amount="0.01"), make_ctx()
    )
    assert over.error_code == OutcomeCode.RATE_LIMITED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


async def test_business_denied_transfer_does_not_consume_daily_cap(system, ledger):
    args = TransferInstruction.model_validate(
        transfer_call("d1", amount="50000.00").arguments  # 低于日累计上限但超过余额
    )
    await approve(system, args, grant_id="grant_denied")
    outcome = await system.runtime.invoke(
        transfer_call("d1", amount="50000.00"), make_ctx(approval_id="grant_denied")
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    # 业务拒绝不消耗日累计额度，也不核销审批凭证。
    assert RateLimiter(conn=ledger.connection).daily_total(TENANT) == Decimal("0")
    used = ledger.connection.execute(
        "SELECT used FROM approval_grants WHERE grant_id = 'grant_denied'"
    ).fetchone()[0]
    assert used == 0
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


# ---- 用例 32：批量调度 -------------------------------------------------------


async def test_lock_in_business_denial_keeps_approval_consumed(system, ledger):
    # 省略锁外预检以直接驱动锁内余额校验：核销与执行分离时不得自动恢复凭证，
    # 否则另一个并发调用可能在恢复前完成第二次资金副作用。
    tool = RegisteredTool(
        name="execute_transfer",
        description="锁内业务失败语义验证",
        parameters_model=TransferInstruction,
        policy=ToolPolicyTransfer,
        action=make_transfer_action(ledger),
        lock_keys=lambda args, ctx: [
            f"{ctx.tenant_id}:account:{args.from_account}",
            f"{ctx.tenant_id}:account:{args.to_account}",
        ],
    )
    runtime = GovernedToolRuntime(
        [tool], AccessDecider(), system.approvals, system.audit,
        locks=SqliteLockManager(conn=ledger.connection),
        limits=RateLimiter(conn=ledger.connection),
    )
    args = TransferInstruction.model_validate(transfer_call("d1", amount="1000.01").arguments)
    await approve(system, args, grant_id="grant_lock_denied")
    outcome = await runtime.invoke(
        transfer_call("d1", amount="1000.01"),
        make_ctx(approval_id="grant_lock_denied"),
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    used = ledger.connection.execute(
        "SELECT used FROM approval_grants WHERE grant_id = 'grant_lock_denied'"
    ).fetchone()[0]
    assert used == 1


async def test_batch_reads_run_concurrently_and_preserve_order(system, ledger):
    calls = [
        ToolCallRequest("b1", "get_account_balance", {"account": "acc_1001"}),
        ToolCallRequest("b2", "get_account_balance", {"account": "acc_1002"}),
        ToolCallRequest("b3", "get_account_balance", {"account": "acc_1003"}),
    ]
    outcomes = await system.runtime.invoke_batch(calls, make_ctx())
    assert [o.tool_call_id for o in outcomes] == ["b1", "b2", "b3"]
    assert all(o.ok for o in outcomes)
    assert outcomes[0].content["balance"] == "1000.00"
    assert outcomes[2].content["balance"] == "100.00"


async def test_batch_with_write_preserves_call_order(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("w1").arguments)
    await approve(system, args, grant_id="grant_batch")
    calls = [
        ToolCallRequest("b1", "get_account_balance", {"account": "acc_1001"}),
        ToolCallRequest("b2", "execute_transfer", transfer_call("w1").arguments),
        ToolCallRequest("b3", "get_account_balance", {"account": "acc_1001"}),
    ]
    outcomes = await system.runtime.invoke_batch(
        calls, make_ctx(approval_id="grant_batch", idempotency_key="biz_batch")
    )
    assert [o.tool_call_id for o in outcomes] == ["b1", "b2", "b3"]
    assert all(o.ok for o in outcomes)
    # 混入写操作时按调用方顺序串行执行：读后余额已含转账结果。
    assert outcomes[2].content["balance"] == "700.00"


# ---- 用例 33：读超时与重试预算耗尽 -------------------------------------------


async def test_read_timeout_reports_retryable_timeout():
    async def slow_read(args, ctx):
        await asyncio.sleep(0.3)
        return {"value": "late"}

    tool = RegisteredTool(
        name="slow_read",
        description="用于验证读操作超时语义的工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.READ_ONLY,
            risk=HazardLevel.LOW,
            required_permission="account:read",
            timeout_seconds=0.05,
            retry_budget=2,
            idempotent=True,
        ),
        action=slow_read,
    )
    runtime = GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    outcome = await runtime.invoke(
        ToolCallRequest("call_01", "slow_read", {}),
        make_ctx(allowed_tools=frozenset({"slow_read"})),
    )
    assert outcome.error_code == OutcomeCode.TIMEOUT
    assert outcome.content["message"]


async def test_transient_failures_exhaust_retry_budget():
    attempts: list[int] = []

    async def always_flaky(args, ctx):
        attempts.append(1)
        raise TransientDependencyError("持续闪断")

    tool = RegisteredTool(
        name="flaky_read",
        description="用于验证重试预算耗尽语义的工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.READ_ONLY,
            risk=HazardLevel.LOW,
            required_permission="account:read",
            timeout_seconds=1.0,
            retry_budget=2,
            idempotent=True,
        ),
        action=always_flaky,
    )
    runtime = GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    outcome = await runtime.invoke(ToolCallRequest("call_01", "flaky_read", {}), make_ctx())
    assert outcome.error_code == OutcomeCode.TEMPORARY_UNAVAILABLE
    assert len(attempts) == 3


# ---- 用例 34：备注控制字符拒绝 -------------------------------------------------


async def test_control_characters_in_remark_are_rejected(system, ledger):
    outcome = await system.runtime.invoke(
        transfer_call("call_01", remark="货款\x00结算"), make_ctx()
    )
    assert outcome.error_code == OutcomeCode.INVALID_ARGUMENT
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


# ---- 用例 35：敏感模式脱敏与模型投影净化 ---------------------------------------


async def test_sensitive_patterns_masked_in_content_and_projection():
    async def expose(args, ctx):
        return {
            "contact": "手机 13812345678，证件 110101199003078515，邮箱 a.b@example.com",
            "note": "含控制字符\x00的说明",
            "session_token": "do-not-leak",
        }

    tool = RegisteredTool(
        name="sensitive_read",
        description="用于验证脱敏与投影净化的工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.READ_ONLY,
            risk=HazardLevel.LOW,
            required_permission="account:read",
        ),
        action=expose,
    )
    runtime = GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())
    outcome = await runtime.invoke(
        ToolCallRequest("call_01", "sensitive_read", {}),
        make_ctx(allowed_tools=frozenset({"sensitive_read"})),
    )
    assert outcome.ok is True
    serialized_content = json.dumps(outcome.content, ensure_ascii=False)
    assert "13812345678" not in serialized_content
    assert "110101199003078515" not in serialized_content
    assert "a.b@example.com" not in serialized_content
    assert outcome.content["session_token"] == "***"

    serialized_projection = json.dumps(outcome.to_model_message(), ensure_ascii=False)
    assert "\x00" not in serialized_projection
    assert "do-not-leak" not in serialized_projection


# ---- 用例 36：写工具必须声明串行化键 ------------------------------------------


def test_mutating_tool_without_lock_declaration_is_rejected():
    async def no_lock_write(args, ctx):
        return {"saved": True}

    tool = RegisteredTool(
        name="bad_write",
        description="未声明串行化键的写工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.MUTATING,
            risk=HazardLevel.LOW,
            required_permission="test:write",
        ),
        action=no_lock_write,
    )
    with pytest.raises(ValueError, match="lock_keys"):
        GovernedToolRuntime([tool], AccessDecider(), ApprovalLedger(), AuditJournal())


# ---- 用例 37：v1 数据库自动迁移到最新版 ---------------------------------------

V1_SCHEMA = """
CREATE TABLE accounts (
    tenant_id TEXT NOT NULL, account TEXT NOT NULL, balance TEXT NOT NULL, status TEXT NOT NULL,
    PRIMARY KEY (tenant_id, account)
);
CREATE TABLE transfers (
    tenant_id TEXT NOT NULL, transfer_id TEXT NOT NULL, business_ref TEXT NOT NULL,
    from_account TEXT NOT NULL, to_account TEXT NOT NULL, amount TEXT NOT NULL,
    status TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (tenant_id, transfer_id)
);
CREATE TABLE idempotency_keys (
    tenant_id TEXT NOT NULL, idempotency_key TEXT NOT NULL, params_digest TEXT NOT NULL,
    transfer_id TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (tenant_id, idempotency_key)
);
CREATE TABLE approval_grants (
    grant_id TEXT PRIMARY KEY, user_id TEXT NOT NULL, tenant_id TEXT NOT NULL,
    tool_name TEXT NOT NULL, digest TEXT NOT NULL, level TEXT NOT NULL,
    expires_at REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0,
    issued_by TEXT NOT NULL, issued_at TEXT NOT NULL
);
CREATE TABLE audit_records (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE seqs (name TEXT PRIMARY KEY, value INTEGER NOT NULL);
INSERT INTO seqs (name, value) VALUES ('transfer', 0);
"""


def test_v1_database_migrates_to_latest_and_stays_usable(tmp_path):
    db_path = str(tmp_path / "v1.db")
    conn = sqlite3.connect(db_path)
    conn.executescript(V1_SCHEMA)
    conn.execute("PRAGMA user_version = 1")
    conn.commit()
    conn.close()

    ledger = AccountLedger(db_path=db_path)
    version = ledger.connection.execute("PRAGMA user_version").fetchone()[0]
    assert version == 6

    ledger.open_account(TENANT, "acc_1001", "1000.00")
    ledger.open_account(TENANT, "acc_1002", "500.00")
    system = compose_transfer_system(ledger)

    async def run():
        args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
        # 模拟 v4 存量凭证：迁移回填空签名，即使字段全部正确也不可核销。
        legacy_digest = request_digest("execute_transfer", args, level="low")
        ledger.connection.execute(
            "INSERT INTO approval_grants (grant_id, user_id, tenant_id, tool_name, digest, "
            "level, expires_at, used, state, issued_by, issued_at, signature, kid) "
            "VALUES ('grant_legacy', 'u_100', ?, 'execute_transfer', ?, 'low', "
            "unixepoch() + 300, 0, 'approved', 'legacy', ?, '', '')",
            (TENANT, legacy_digest, datetime.now(timezone.utc).isoformat()),
        )
        ledger.connection.commit()
        legacy = await system.runtime.invoke(
            transfer_call("call_01"), make_ctx(approval_id="grant_legacy")
        )
        assert legacy.error_code == OutcomeCode.APPROVAL_REQUIRED

        await system.request_approval("grant_mig", user_id="u_100", tenant_id=TENANT, args=args)
        system.register_approver("u_admin", TENANT, max_level="high")
        await system.decide_approval(
            "grant_mig", decision="approved", decided_by="u_admin", reason="迁移验证"
        )
        outcome = await system.runtime.invoke(
            transfer_call("call_01"),
            make_ctx(approval_id="grant_mig", idempotency_key="biz_mig"),
        )
        assert outcome.ok is True
        return outcome

    outcome = asyncio.run(run())
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    rows = ledger.statement(TENANT, "acc_1001")
    assert len(rows) == 1
    assert rows[0]["side"] == "debit"
    assert rows[0]["transfer_id"] == outcome.content["transfer_id"]
    # 迁移回填的期初余额使对账恒等式在迁移库上同样成立。
    report = ledger.reconcile_account(TENANT, "acc_1001")
    assert report["consistent"] is True
    assert report["expected"] == "700.00"
    # v5 迁移后外发表可用：开户与转账事件已随业务同事务落表。
    events = ledger.outbox_events()
    assert any(e["event_type"] == "transfer_settled" for e in events)
    assert any(
        e["event_type"] == "account_opened" and e["payload"]["account"] == "acc_1001"
        for e in events
    )
    # 迁移链（含审计哈希回填钩子）后哈希链保持完整。
    assert system.audit.verify_chain() is None
    # v6 迁移：审计不可变触发器与回放检查点表在存量库同样生效。
    with pytest.raises(sqlite3.IntegrityError):
        with ledger.connection:
            ledger.connection.execute("UPDATE audit_records SET payload = '{}' WHERE id = 1")
    with pytest.raises(sqlite3.IntegrityError):
        with ledger.connection:
            ledger.connection.execute("DELETE FROM audit_records WHERE id = 1")
    assert ledger.replay_checkpoint("any-stream") is None
    ledger.set_replay_checkpoint("any-stream", last_entry_id="1-1", snapshot_watermark=7)
    assert ledger.replay_checkpoint("any-stream") == {
        "last_entry_id": "1-1",
        "snapshot_watermark": 7,
    }


# ---- 用例 38：锁端口契约套件（参数化驱动全部实现） ----------------------------


@pytest.fixture(params=["sqlite", "redis"])
def lock_factory(request):
    """两种锁实现共享同一份协调状态：SQLite 共享连接、Redis 共享 FakeRedis。"""
    if request.param == "sqlite":
        shared_conn = AccountLedger().connection

        def build(*, lock_ttl_seconds: float = 30.0, acquire_timeout_seconds: float = 10.0):
            return SqliteLockManager(
                conn=shared_conn,
                lock_ttl_seconds=lock_ttl_seconds,
                acquire_timeout_seconds=acquire_timeout_seconds,
            )
    else:
        shared_server = fakeredis.aioredis.FakeRedis()

        def build(*, lock_ttl_seconds: float = 30.0, acquire_timeout_seconds: float = 10.0):
            return RedisLockManager(
                shared_server,
                lock_ttl_seconds=lock_ttl_seconds,
                acquire_timeout_seconds=acquire_timeout_seconds,
            )

    return build


async def test_lock_contract_serializes_contenders(lock_factory):
    locks = lock_factory()
    entered: list[str] = []

    async def holder():
        async with locks.locked(["k1"]):
            entered.append("holder")
            await asyncio.sleep(0.05)

    async def contender():
        await asyncio.sleep(0.01)
        async with locks.locked(["k1"]):
            entered.append("contender")

    await asyncio.wait_for(asyncio.gather(holder(), contender()), timeout=5.0)
    assert entered == ["holder", "contender"]


async def test_lock_contract_multikey_opposite_order_no_deadlock(lock_factory):
    locks = lock_factory()
    started = asyncio.Event()
    done: list[str] = []

    async def first():
        async with locks.locked(["x", "y"]):
            done.append("first")
            started.set()
            await asyncio.sleep(0.05)

    async def second():
        await started.wait()
        async with locks.locked(["y", "x"]):  # 反向键序：字典序获取保证不死锁
            done.append("second")

    await asyncio.wait_for(asyncio.gather(first(), second()), timeout=5.0)
    assert done == ["first", "second"]


async def test_lock_contract_multikey_all_or_nothing(lock_factory):
    locks = lock_factory(acquire_timeout_seconds=0.3)
    first_held = asyncio.Event()
    partial = asyncio.Event()

    async def first():
        async with locks.locked(["a", "b"]):
            first_held.set()
            await asyncio.sleep(0.2)

    async def second():
        await first_held.wait()
        async with locks.locked(["b", "c"]):  # b 被占，整体等待；c 不得残留占用
            partial.set()

    async def third():
        await first_held.wait()
        await asyncio.sleep(0.05)
        try:
            async with locks.locked(["c"]):
                return "got_c"
        except GovernanceViolation:
            return "blocked"

    t1 = asyncio.create_task(first())
    t2 = asyncio.create_task(second())
    result = await asyncio.wait_for(third(), timeout=5.0)
    await t1
    await t2
    assert result == "got_c"
    assert partial.is_set()


async def test_lock_contract_expired_lock_taken_over(lock_factory):
    first = lock_factory(lock_ttl_seconds=0.05)
    second = lock_factory(lock_ttl_seconds=30.0, acquire_timeout_seconds=2.0)

    async def crash_holder():
        # 获取后永不释放，模拟进程崩溃遗留的锁。
        cm = first.locked(["k"])
        await cm.__aenter__()
        await asyncio.sleep(3600)

    async def taker():
        await asyncio.sleep(0.05)
        async with second.locked(["k"]):
            pass

    crashed = asyncio.create_task(crash_holder())
    # 锁过期后应被接管，否则获取超时、用例失败。
    await asyncio.wait_for(taker(), timeout=5.0)
    crashed.cancel()
    try:
        await crashed
    except asyncio.CancelledError:
        pass


async def test_lock_contract_acquire_timeout_reports_temporary_unavailable(lock_factory):
    holder = lock_factory()
    waiter = lock_factory(acquire_timeout_seconds=0.15)

    async def hold():
        async with holder.locked(["k"]):
            await asyncio.sleep(0.4)

    async def contend():
        await asyncio.sleep(0.05)
        with pytest.raises(GovernanceViolation) as exc_info:
            async with waiter.locked(["k"]):
                pass
        return exc_info.value.code

    held = asyncio.create_task(hold())
    code = await asyncio.wait_for(contend(), timeout=5.0)
    await held
    assert code == OutcomeCode.TEMPORARY_UNAVAILABLE


# ---- 用例 39：Redis 锁端口端到端串行转账 --------------------------------------


async def test_redis_lock_port_serializes_transfers_end_to_end():
    ledger = make_ledger()
    shared = fakeredis.aioredis.FakeRedis()
    signer = Ed25519GrantSigner.generate()
    system_a = compose_transfer_system(ledger, locks=RedisLockManager(shared), signer=signer)
    system_b = compose_transfer_system(ledger, locks=RedisLockManager(shared), signer=signer)

    forward_args = TransferInstruction.model_validate(transfer_call("fwd", amount="300.00").arguments)
    backward_args = TransferInstruction.model_validate(
        transfer_call("bwd", source="acc_1002", target="acc_1001", amount="200.00").arguments
    )
    await approve(system_a, forward_args, grant_id="grant_rf")
    await approve(system_a, backward_args, grant_id="grant_rb")

    results = await asyncio.wait_for(
        asyncio.gather(
            system_a.runtime.invoke(
                transfer_call("fwd", amount="300.00"),
                make_ctx(trace_id="trace_rf", approval_id="grant_rf"),
            ),
            system_b.runtime.invoke(
                transfer_call("bwd", source="acc_1002", target="acc_1001", amount="200.00"),
                make_ctx(trace_id="trace_rb", approval_id="grant_rb"),
            ),
        ),
        timeout=5.0,
    )
    assert all(r.ok for r in results)
    assert ledger.balance(TENANT, "acc_1001") == Decimal("900.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("600.00")


# ---- 用例 40：审批裁决授权 ---------------------------------------------------


async def test_unauthorized_decider_is_denied_and_audited(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_unauth", user_id="u_100", tenant_id=TENANT, args=args)

    with pytest.raises(GovernanceViolation) as exc_info:
        await system.decide_approval("grant_unauth", decision="approved", decided_by="u_rogue", reason="越权尝试")
    assert exc_info.value.code == OutcomeCode.APPROVAL_DECISION_DENIED

    denied = [r for r in system.audit.records if r.get("event") == "approval_decision_denied"]
    assert len(denied) == 1
    assert denied[0]["decided_by"] == "u_rogue"
    # 凭证仍为 pending，不可核销。
    outcome = await system.runtime.invoke(transfer_call("call_01"), make_ctx(approval_id="grant_unauth"))
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


async def test_low_level_decider_cannot_approve_high_tier(system, ledger):
    ledger.open_account(TENANT, "acc_2002", "50000.00")
    system.register_approver("u_low", TENANT, max_level="low")
    system.register_approver("u_admin", TENANT, max_level="high")
    args = TransferInstruction.model_validate(
        transfer_call("h1", source="acc_2002", target="acc_1002", amount="10000.00").arguments
    )
    await system.request_approval("grant_high_tier", user_id="u_100", tenant_id=TENANT, args=args)

    with pytest.raises(GovernanceViolation) as exc_info:
        await system.decide_approval("grant_high_tier", decision="approved", decided_by="u_low", reason="低层级尝试")
    assert exc_info.value.code == OutcomeCode.APPROVAL_DECISION_DENIED

    await system.decide_approval("grant_high_tier", decision="approved", decided_by="u_admin", reason="合规复核通过")
    outcome = await system.runtime.invoke(
        transfer_call("h1", source="acc_2002", target="acc_1002", amount="10000.00"),
        make_ctx(approval_id="grant_high_tier"),
    )
    assert outcome.ok is True
    assert ledger.balance(TENANT, "acc_2002") == Decimal("40000.00")


async def test_four_eyes_blocks_self_approval(system, ledger):
    system.register_approver("u_100", TENANT, max_level="high")
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_self", user_id="u_100", tenant_id=TENANT, args=args)

    with pytest.raises(GovernanceViolation) as exc_info:
        await system.decide_approval("grant_self", decision="approved", decided_by="u_100", reason="自批尝试")
    assert exc_info.value.code == OutcomeCode.APPROVAL_DECISION_DENIED

    system.register_approver("u_admin", TENANT, max_level="high")
    await system.decide_approval("grant_self", decision="approved", decided_by="u_admin", reason="代批")
    outcome = await system.runtime.invoke(transfer_call("call_01"), make_ctx(approval_id="grant_self"))
    assert outcome.ok is True
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")


async def test_cross_tenant_decider_is_denied(system, ledger):
    system.register_approver("u_admin", TENANT, max_level="high")
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_x", user_id="u_100", tenant_id="tenant_b", args=args)

    with pytest.raises(GovernanceViolation) as exc_info:
        await system.decide_approval("grant_x", decision="approved", decided_by="u_admin", reason="跨租户尝试")
    assert exc_info.value.code == OutcomeCode.APPROVAL_DECISION_DENIED


async def test_requester_can_self_revoke_pending_grant(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_cancel", user_id="u_100", tenant_id=TENANT, args=args)
    await system.decide_approval("grant_cancel", decision="revoked", decided_by="u_100", reason="误提交，撤回")
    outcome = await system.runtime.invoke(transfer_call("call_01"), make_ctx(approval_id="grant_cancel"))
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert "approval_revoked" in {r.get("event") for r in system.audit.records}
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


async def test_deactivated_approver_is_denied(system, ledger):
    system.register_approver("u_admin", TENANT, max_level="high")
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_dec", user_id="u_100", tenant_id=TENANT, args=args)
    system.deactivate_approver("u_admin", TENANT)

    with pytest.raises(GovernanceViolation) as exc_info:
        await system.decide_approval("grant_dec", decision="approved", decided_by="u_admin", reason="离职后尝试")
    assert exc_info.value.code == OutcomeCode.APPROVAL_DECISION_DENIED


# ---- 用例 41：审计哈希链 -----------------------------------------------------


async def test_audit_chain_detects_tampering(system, ledger):
    await system.runtime.invoke(
        ToolCallRequest("c1", "get_account_balance", {"account": "acc_1001"}), make_ctx()
    )
    await system.runtime.invoke(
        ToolCallRequest("c2", "get_account_balance", {"account": "acc_1002"}), make_ctx()
    )
    assert system.audit.verify_chain() is None

    # 不可变审计表：UPDATE/DELETE 在存储层被触发器拒绝，链保持完整。
    with pytest.raises(sqlite3.IntegrityError):
        with system.audit.connection:
            system.audit.connection.execute(
                "UPDATE audit_records SET payload = '{\"tampered\": true}' WHERE id = 2"
            )
    with pytest.raises(sqlite3.IntegrityError):
        with system.audit.connection:
            system.audit.connection.execute("DELETE FROM audit_records WHERE id = 2")
    assert system.audit.verify_chain() is None

    # 插入伪造记录（哈希不接前链）：哈希链校验定位首个断裂记录。
    with system.audit.connection:
        system.audit.connection.execute(
            "INSERT INTO audit_records (ts, payload, prev_hash, hash) "
            "VALUES (?, ?, 'deadbeef', 'deadbeef')",
            (datetime.now(timezone.utc).isoformat(), '{"forged": true}'),
        )
    assert system.audit.verify_chain() == 3


def test_audit_chain_backfilled_during_migration(tmp_path):
    db_path = str(tmp_path / "v1chain.db")
    conn = sqlite3.connect(db_path)
    conn.executescript(V1_SCHEMA)
    for payload in ('{"event": "a"}', '{"event": "b"}'):
        conn.execute(
            "INSERT INTO audit_records (ts, payload) VALUES (?, ?)",
            ("2026-01-01T00:00:00+00:00", payload),
        )
    conn.execute("PRAGMA user_version = 1")
    conn.commit()
    conn.close()

    ledger = AccountLedger(db_path=db_path)
    audit = AuditJournal(conn=ledger.connection)
    assert audit.verify_chain() is None  # 迁移回填后链从头闭合

    async def append():
        await audit.write({"event": "c"})

    asyncio.run(append())
    assert audit.verify_chain() is None

    # 迁移后的存量库同样受不可变触发器保护；插入伪造记录则由哈希链定位。
    with pytest.raises(sqlite3.IntegrityError):
        with audit.connection:
            audit.connection.execute("UPDATE audit_records SET payload = '{\"x\":1}' WHERE id = 2")
    assert audit.verify_chain() is None
    with audit.connection:
        audit.connection.execute(
            "INSERT INTO audit_records (ts, payload, prev_hash, hash) "
            "VALUES (?, ?, 'forged', 'forged')",
            (datetime.now(timezone.utc).isoformat(), '{"forged": true}'),
        )
    assert audit.verify_chain() == 4


# ---- 用例 42：限频窗口由存储侧时钟重置 ---------------------------------------


async def test_rate_window_resets_on_storage_clock():
    async def quick_read(args, ctx):
        return {"value": "ok"}

    tool = RegisteredTool(
        name="windowed_read",
        description="用于验证限频窗口重置的工具。",
        parameters_model=_EmptyArgs,
        policy=ToolGovernancePolicy(
            effect=SideEffect.READ_ONLY,
            risk=HazardLevel.LOW,
            required_permission="account:read",
            rate_limit=1,
            rate_window_seconds=0.3,
        ),
        action=quick_read,
    )
    runtime = GovernedToolRuntime(
        [tool], AccessDecider(), ApprovalLedger(), AuditJournal(), limits=RateLimiter()
    )
    ctx = make_ctx(allowed_tools=frozenset({"windowed_read"}))
    first = await runtime.invoke(ToolCallRequest("w1", "windowed_read", {}), ctx)
    second = await runtime.invoke(ToolCallRequest("w2", "windowed_read", {}), ctx)
    assert first.ok is True
    assert second.error_code == OutcomeCode.RATE_LIMITED

    # 存储侧时钟为整数秒粒度，跨过下一秒边界后窗口重置。
    await asyncio.sleep(1.2)
    third = await runtime.invoke(ToolCallRequest("w3", "windowed_read", {}), ctx)
    assert third.ok is True


# ---- 用例 43：真实 Redis 冒烟（无环境自动跳过） -------------------------------

REDIS_URL = os.environ.get("TEST_REDIS_URL", "")


@pytest.mark.skipif(not REDIS_URL, reason="未设置 TEST_REDIS_URL 时跳过真实 Redis 冒烟")
async def test_real_redis_lock_smoke():
    import redis.asyncio as aioredis

    client = aioredis.from_url(REDIS_URL)
    try:
        await client.ping()
    except Exception:
        pytest.skip("TEST_REDIS_URL 指向的 Redis 不可达")
    locks = RedisLockManager(client, acquire_timeout_seconds=2.0)
    async with locks.locked(["smoke:transfer:1"]):
        pass


# ---- 用例 46：冲正闭环（Saga 补偿） -------------------------------------------


async def test_reverse_without_approval_is_rejected(system, ledger):
    outcome = await system.runtime.invoke(
        reverse_call("r1", original="trf_000001"), make_ctx()
    )
    assert outcome.ok is False
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


async def test_reverse_settles_back_balances_with_mirrored_entries(system, ledger):
    settled = await settle_transfer(system)
    original_id = settled["transfer_id"]

    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=original_id).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=original_id),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert outcome.ok is True
    assert outcome.content["status"] == "reversed"
    assert outcome.content["original_transfer_id"] == original_id
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")

    # 反向借贷分录：原入账账户 debit、原出账账户 credit，金额与原转账一致。
    statement_1002 = ledger.statement(TENANT, "acc_1002", limit=2)
    assert statement_1002[0]["side"] == "debit"
    assert statement_1002[0]["transfer_id"] == outcome.content["transfer_id"]
    assert statement_1002[0]["amount"] == "300.00"
    assert ledger.reversal_of(TENANT, original_id) is not None
    assert ledger.reversal_of(TENANT, outcome.content["transfer_id"]) is None

    record = system.audit.records[-1]
    assert record["ok"] is True
    assert record["tool_name"] == "reverse_transfer"


async def test_reverse_twice_is_denied(system, ledger):
    settled = await settle_transfer(system)
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    first = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert first.ok is True

    args2 = ReverseInstruction.model_validate(
        reverse_call("r2", original=settled["transfer_id"]).arguments
    )
    await approve(system, args2, grant_id="grant_rev2", tool_name="reverse_transfer")
    second = await system.runtime.invoke(
        reverse_call("r2", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev2", idempotency_key="biz_rev2"),
    )
    assert second.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


async def test_reverse_insufficient_funds_at_original_target_is_denied(system, ledger):
    settled = await settle_transfer(system)
    # 原入账账户把资金转走大半，剩余不足以支撑全额冲正。
    await settle_transfer(
        system,
        source="acc_1002",
        target="acc_1003",
        amount="600.00",
        grant_id="grant_spend",
        idempotency_key="biz_spend",
    )
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    # 冲正失败不回滚任何账户状态。
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("200.00")
    assert ledger.balance(TENANT, "acc_1003") == Decimal("700.00")


async def test_partial_reverse_allowed_up_to_remaining(system, ledger):
    settled = await settle_transfer(system, amount="300.00")
    # 第一次部分冲正 100：按声明金额原路退回。
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"], amount="100.00").arguments
    )
    await approve(system, args, grant_id="grant_rev1", tool_name="reverse_transfer")
    first = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="100.00"),
        make_ctx(approval_id="grant_rev1", idempotency_key="biz_rev1"),
    )
    assert first.ok is True
    assert first.content["amount"] == "100.00"
    assert ledger.balance(TENANT, "acc_1001") == Decimal("800.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("700.00")
    assert ledger.reversed_total(TENANT, settled["transfer_id"]) == Decimal("100.00")

    # 第二次部分冲正 200：累计恰好等于原单金额。
    args2 = ReverseInstruction.model_validate(
        reverse_call("r2", original=settled["transfer_id"], amount="200.00").arguments
    )
    await approve(system, args2, grant_id="grant_rev2", tool_name="reverse_transfer")
    second = await system.runtime.invoke(
        reverse_call("r2", original=settled["transfer_id"], amount="200.00"),
        make_ctx(approval_id="grant_rev2", idempotency_key="biz_rev2"),
    )
    assert second.ok is True
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")
    # 原单流水保持 settled，冲正本身不可再被冲正。
    original = ledger.get_transfer(TENANT, settled["transfer_id"])
    assert original["status"] == "settled"
    assert ledger.reversal_of(TENANT, second.content["transfer_id"]) is None

    # 已全部冲正：任何金额的继续冲正都被拒绝。
    args3 = ReverseInstruction.model_validate(
        reverse_call("r3", original=settled["transfer_id"], amount="0.01").arguments
    )
    await approve(system, args3, grant_id="grant_rev3", tool_name="reverse_transfer")
    third = await system.runtime.invoke(
        reverse_call("r3", original=settled["transfer_id"], amount="0.01"),
        make_ctx(approval_id="grant_rev3", idempotency_key="biz_rev3"),
    )
    assert third.error_code == OutcomeCode.BUSINESS_RULE_DENIED


async def test_reverse_exceeding_remaining_is_denied(system, ledger):
    settled = await settle_transfer(system, amount="300.00")
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"], amount="300.01").arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="300.01"),
        make_ctx(approval_id="grant_rev"),
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("800.00")
    assert ledger.reversed_total(TENANT, settled["transfer_id"]) == Decimal("0.00")


async def test_partial_reverse_refunds_daily_usage_by_declared_amount(system, ledger):
    settled = await settle_transfer(system)
    limits = RateLimiter(conn=ledger.connection)
    assert limits.daily_total(TENANT) == Decimal("300.00")

    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"], amount="120.00").arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="120.00"),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert outcome.ok is True
    assert limits.daily_total(TENANT) == Decimal("180.00")


async def test_partial_reverse_entries_and_insufficient_funds_follow_declared_amount(
    system, ledger,
):
    settled = await settle_transfer(system)
    # 原入账账户把资金转走大半：剩余 200 不足以冲 250，但足够冲 100。
    await settle_transfer(
        system,
        source="acc_1002",
        target="acc_1003",
        amount="600.00",
        grant_id="grant_spend",
        idempotency_key="biz_spend",
    )
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"], amount="250.00").arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    denied = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="250.00"),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert denied.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("200.00")

    args2 = ReverseInstruction.model_validate(
        reverse_call("r2", original=settled["transfer_id"], amount="100.00").arguments
    )
    await approve(system, args2, grant_id="grant_rev2", tool_name="reverse_transfer")
    partial = await system.runtime.invoke(
        reverse_call("r2", original=settled["transfer_id"], amount="100.00"),
        make_ctx(approval_id="grant_rev2", idempotency_key="biz_rev2"),
    )
    assert partial.ok is True
    assert ledger.balance(TENANT, "acc_1001") == Decimal("800.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("100.00")
    # 反向借贷分录金额与声明金额一致。
    statement = ledger.statement(TENANT, "acc_1002", limit=1)
    assert statement[0]["side"] == "debit"
    assert statement[0]["amount"] == "100.00"
    # 对账恒等式在部分冲正后仍然成立。
    for account in ("acc_1001", "acc_1002"):
        assert ledger.reconcile_account(TENANT, account)["consistent"] is True


async def test_reverse_is_idempotent_by_key(system, ledger):
    settled = await settle_transfer(system)
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    first = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert first.ok is True
    # 原凭证 + 原幂等键可直接重放，返回同一冲正单且不重复移动资金。
    replay = await system.runtime.invoke(
        reverse_call("r2", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert replay.ok is True
    assert replay.content["transfer_id"] == first.content["transfer_id"]
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("500.00")


async def test_reverse_refunds_daily_usage(system, ledger):
    settled = await settle_transfer(system)
    limits = RateLimiter(conn=ledger.connection)
    assert limits.daily_total(TENANT) == Decimal("300.00")

    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert outcome.ok is True
    assert limits.daily_total(TENANT) == Decimal("0.00")


async def test_reverse_approval_binds_original_id_and_amount(system, ledger):
    settled = await settle_transfer(system)
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    tampered_id = await system.runtime.invoke(
        reverse_call("r1", original="trf_999999"),
        make_ctx(approval_id="grant_rev"),
    )
    tampered_amount = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="299.99"),
        make_ctx(approval_id="grant_rev"),
    )
    assert tampered_id.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert tampered_amount.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")


async def test_reverse_of_missing_transfer_is_denied_only_after_approval(system, ledger):
    # 门禁顺序：无凭证先被拒，持凭证才走到预检得知原单不存在。
    unapproved = await system.runtime.invoke(
        reverse_call("r1", original="trf_999999"), make_ctx()
    )
    assert unapproved.error_code == OutcomeCode.APPROVAL_REQUIRED

    args = ReverseInstruction.model_validate(
        reverse_call("r1", original="trf_999999").arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    outcome = await system.runtime.invoke(
        reverse_call("r1", original="trf_999999"),
        make_ctx(approval_id="grant_rev"),
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    # 预检失败不核销审批凭证。
    used = ledger.connection.execute(
        "SELECT used FROM approval_grants WHERE grant_id = 'grant_rev'"
    ).fetchone()[0]
    assert used == 0


async def test_reverse_cross_tenant_is_denied(system, ledger):
    settled = await settle_transfer(system)
    other = "tenant_b"
    ledger.open_account(other, "acc_1001", "1000.00")
    ledger.open_account(other, "acc_1002", "500.00")
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(
        system, args, grant_id="grant_rev", tenant_id=other, tool_name="reverse_transfer"
    )
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(
            tenant_id=other,
            permissions=frozenset({("tenant_b", "transfer:reverse")}),
            allowed_tools=frozenset({"reverse_transfer"}),
            approval_id="grant_rev",
        ),
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("700.00")


async def test_high_amount_reverse_requires_high_level_decider(system, ledger):
    ledger.open_account(TENANT, "acc_2001", "50000.00")
    settled = await settle_transfer(
        system, source="acc_2001", target="acc_1002", amount="20000.00",
        grant_id="grant_big", idempotency_key="biz_big",
    )
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"], amount="20000.00").arguments
    )
    await system.request_approval(
        "grant_rev_big", user_id="u_100", tenant_id=TENANT, args=args,
        tool_name="reverse_transfer",
    )
    system.register_approver("u_low", TENANT, max_level="low")
    with pytest.raises(GovernanceViolation) as exc_info:
        await system.decide_approval(
            "grant_rev_big", decision="approved", decided_by="u_low", reason="层级不足"
        )
    assert exc_info.value.code == OutcomeCode.APPROVAL_DECISION_DENIED

    system.register_approver("u_high", TENANT, max_level="high")
    await system.decide_approval(
        "grant_rev_big", decision="approved", decided_by="u_high", reason="高层级裁决"
    )
    outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="20000.00"),
        make_ctx(approval_id="grant_rev_big", idempotency_key="biz_rev_big"),
    )
    assert outcome.ok is True
    assert ledger.balance(TENANT, "acc_2001") == Decimal("50000.00")


async def test_reverse_and_transfer_share_account_locks_across_instances():
    ledger = make_ledger()
    system_a = compose_transfer_system(ledger)
    system_b = compose_transfer_system(ledger)

    async def run():
        settled = await settle_transfer(system_a)
        args = ReverseInstruction.model_validate(
            reverse_call("r1", original=settled["transfer_id"]).arguments
        )
        await approve(system_b, args, grant_id="grant_rev", tool_name="reverse_transfer")
        fwd = TransferInstruction.model_validate(
            transfer_call("fwd", source="acc_1002", target="acc_1001", amount="200.00").arguments
        )
        await approve(system_a, fwd, grant_id="grant_fwd")
        reverse_outcome, forward_outcome = await asyncio.gather(
            system_b.runtime.invoke(
                reverse_call("r1", original=settled["transfer_id"]),
                make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
            ),
            system_a.runtime.invoke(
                transfer_call("fwd", source="acc_1002", target="acc_1001", amount="200.00"),
                make_ctx(approval_id="grant_fwd", idempotency_key="biz_fwd"),
            ),
        )
        assert reverse_outcome.ok is True and forward_outcome.ok is True

    await asyncio.wait_for(run(), timeout=5.0)
    # 无论调度顺序，终态守恒：1001 回到 1000 再加 200 转账，1002 相应减少。
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1200.00")
    assert ledger.balance(TENANT, "acc_1002") == Decimal("300.00")
    assert ledger.total_of(TENANT, ["acc_1001", "acc_1002", "acc_1003", "acc_1004"]) == Decimal("1700.00")


# ---- 用例 47：对账与跨实例差异 -------------------------------------------------


async def test_reconcile_account_consistent_through_transfer_and_reversal(system, ledger):
    settled = await settle_transfer(system)
    after_transfer = ledger.reconcile_account(TENANT, "acc_1001")
    assert after_transfer["consistent"] is True
    assert after_transfer["expected"] == after_transfer["balance"] == "700.00"

    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    after_reversal = ledger.reconcile_account(TENANT, "acc_1001")
    assert after_reversal["consistent"] is True
    assert after_reversal["expected"] == after_reversal["balance"] == "1000.00"


def test_reconcile_detects_injected_discrepancy(ledger):
    report = ledger.reconcile_account(TENANT, "acc_1001")
    assert report["consistent"] is True
    with ledger.connection:
        ledger.connection.execute(
            "UPDATE accounts SET balance = '500.00' WHERE tenant_id = ? AND account = ?",
            (TENANT, "acc_1001"),
        )
    tampered = ledger.reconcile_account(TENANT, "acc_1001")
    assert tampered["consistent"] is False
    assert tampered["discrepancy"] == "500.00"


def test_diff_ledgers_reports_drift_and_is_clean_when_identical():
    ledger_a, ledger_b = make_ledger(), make_ledger()
    assert ledger_a.diff_ledgers(ledger_b, TENANT, ["acc_1001", "acc_1002"]) == []

    with ledger_b.connection:
        ledger_b.connection.execute(
            "UPDATE accounts SET balance = '900.00' WHERE tenant_id = ? AND account = ?",
            (TENANT, "acc_1001"),
        )
        ledger_b.connection.execute(
            "INSERT INTO ledger_entries (tenant_id, account, side, amount, transfer_id, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (TENANT, "acc_1001", "debit", "100.00", "trf_drift", "2026-11-22T00:00:00+00:00"),
        )
    diffs = ledger_a.diff_ledgers(ledger_b, TENANT, ["acc_1001", "acc_1002"])
    kinds = {(item["account"], item["kind"]) for item in diffs}
    assert ("acc_1001", "balance") in kinds
    assert ("acc_1001", "entry_count") in kinds
    assert ("acc_1002", "balance") not in kinds


# ---- 用例 48：审批凭证密码学签名（Round-5 轨道一） -----------------------------


async def test_grant_signature_binds_immutable_fields(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_tampered")
    with ledger.connection:
        ledger.connection.execute(
            "UPDATE approval_grants SET digest = ? WHERE grant_id = 'grant_tampered'",
            ("0" * 64,),
        )
    outcome = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_tampered")
    )
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED

    await approve(system, args, grant_id="grant_identity")
    with ledger.connection:
        ledger.connection.execute(
            "UPDATE approval_grants SET user_id = 'u_hacker' WHERE grant_id = 'grant_identity'"
        )
    outcome = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_identity")
    )
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED

    # 过期时间参与签名：整秒级篡改不破坏过期判定，但使验签失败。
    await approve(system, args, grant_id="grant_expiry")
    with ledger.connection:
        ledger.connection.execute(
            "UPDATE approval_grants SET expires_at = expires_at + 1 WHERE grant_id = 'grant_expiry'"
        )
    outcome = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_expiry")
    )
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED
    assert ledger.balance(TENANT, "acc_1001") == Decimal("1000.00")


async def test_unsigned_legacy_grant_is_rejected(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    digest = request_digest("execute_transfer", args, level="low")
    with ledger.connection:
        ledger.connection.execute(
            "INSERT INTO approval_grants (grant_id, user_id, tenant_id, tool_name, digest, "
            "level, expires_at, used, state, issued_by, issued_at, signature, kid) "
            "VALUES ('grant_unsigned', 'u_100', ?, 'execute_transfer', ?, 'low', "
            "unixepoch() + 300, 0, 'approved', 'legacy', ?, '', '')",
            (TENANT, digest, datetime.now(timezone.utc).isoformat()),
        )
    outcome = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_unsigned")
    )
    assert outcome.error_code == OutcomeCode.APPROVAL_REQUIRED


async def test_issuance_and_decision_audits_include_kid(system):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await approve(system, args, grant_id="grant_kid_1")
    issued = [r for r in system.audit.records if r.get("event") == "approval_issued"][-1]
    assert issued["kid"] == system.approvals.kid_of("grant_kid_1")
    assert issued["kid"].startswith("ed25519_")

    await system.request_approval("grant_kid_2", user_id="u_100", tenant_id=TENANT, args=args)
    requested = [r for r in system.audit.records if r.get("event") == "approval_requested"][-1]
    assert requested["kid"] == system.approvals.kid_of("grant_kid_2")
    system.register_approver("u_admin", TENANT, max_level="high")
    await system.decide_approval(
        "grant_kid_2", decision="approved", decided_by="u_admin", reason="kid 审计"
    )
    decided = [r for r in system.audit.records if r.get("event") == "approval_approved"][-1]
    assert decided["kid"] == system.approvals.kid_of("grant_kid_2")


async def test_key_rotation_and_deactivation_through_public_seam(ledger):
    signer = Ed25519GrantSigner.generate("ed25519_001")
    system = compose_transfer_system(ledger, signer=signer)
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)

    await approve(system, args, grant_id="grant_k1")
    await approve(system, args, grant_id="grant_k1b")
    signer.add_key("ed25519_002", make_primary=True)
    await approve(system, args, grant_id="grant_k2")

    # 轮换期间新旧密钥签发的凭证都可核销。
    first = await system.runtime.invoke(
        transfer_call("call_01"), make_ctx(approval_id="grant_k1")
    )
    assert first.ok is True
    second = await system.runtime.invoke(
        transfer_call("call_02"), make_ctx(approval_id="grant_k2")
    )
    assert second.ok is True

    # 停用旧密钥：其签发的未核销凭证立即失效，新密钥签发的不受影响。
    signer.deactivate("ed25519_001")
    rejected = await system.runtime.invoke(
        transfer_call("call_03"), make_ctx(approval_id="grant_k1b")
    )
    assert rejected.error_code == OutcomeCode.APPROVAL_REQUIRED
    await approve(system, args, grant_id="grant_k3")
    assert system.approvals.kid_of("grant_k3") == "ed25519_002"
    third = await system.runtime.invoke(
        transfer_call("call_04"), make_ctx(approval_id="grant_k3")
    )
    assert third.ok is True


# ---- 签名器端口契约套件（新增端口缝，与锁端口契约套件同级） -------------------


def test_signer_contract_sign_verify_tamper():
    signer = Ed25519GrantSigner.generate("ed25519_001")
    payload = grant_signature_payload(
        grant_id="g1", user_id="u", tenant_id="t", tool_name="x",
        digest="d", level="low", expires_at=100.0,
    )
    kid, signature = signer.sign(payload)
    assert kid == "ed25519_001"
    assert signer.verify(payload, signature, kid) is True
    assert signer.verify(payload + b"x", signature, kid) is False
    assert signer.verify(payload, "00" * 64, kid) is False
    assert signer.verify(payload, signature, "ed25519_unknown") is False


def test_signer_contract_rotation_and_deactivation():
    signer = Ed25519GrantSigner.generate("k1")
    payload = b"canonical-bytes"
    _, sig1 = signer.sign(payload)
    signer.add_key("k2", make_primary=True)
    assert signer.primary_kid == "k2"
    _, sig2 = signer.sign(payload)
    assert signer.verify(payload, sig1, "k1") is True
    assert signer.verify(payload, sig2, "k2") is True
    signer.deactivate("k1")
    assert signer.verify(payload, sig1, "k1") is False
    assert signer.verify(payload, sig2, "k2") is True


# ---- 用例 49：Outbox 事件外发与副本回放（Round-5 轨道二） ----------------------


async def test_outbox_writes_events_with_business_transaction(system, ledger):
    settled = await settle_transfer(system)
    events = ledger.outbox_events()
    business = [
        e for e in events if e["event_type"] in {"account_opened", "transfer_settled"}
    ]
    assert [e["event_type"] for e in business] == ["account_opened"] * 4 + ["transfer_settled"]
    settled_event = business[-1]
    assert settled_event["published"] is False
    payload = settled_event["payload"]
    assert payload["transfer_id"] == settled["transfer_id"]
    assert payload["amount"] == "300.00"
    # 事件负载纪律：只含业务字段，不含备注文本与用户身份。
    serialized = json.dumps(payload, ensure_ascii=False)
    assert "货款" not in serialized
    assert "u_100" not in serialized


async def test_failed_transfer_writes_no_event(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("f1", amount="99999.00").arguments)
    await approve(system, args, grant_id="grant_fail")
    outcome = await system.runtime.invoke(
        transfer_call("f1", amount="99999.00"), make_ctx(approval_id="grant_fail")
    )
    assert outcome.error_code == OutcomeCode.BUSINESS_RULE_DENIED
    # 业务拒绝不产生业务事件；签发审批凭证的 approval_issued 事件与凭证同事务。
    business = [
        e
        for e in ledger.outbox_events()
        if e["event_type"] in {"transfer_settled", "transfer_reversed"}
    ]
    assert business == []


async def test_relay_publishes_pending_events_once(system, ledger):
    await settle_transfer(system)
    client = fakeredis.aioredis.FakeRedis()
    relay = EventRelay(ledger.connection, client)
    assert await relay.publish_pending() == 6  # 4 开户 + 1 签发审批 + 1 转账
    assert await relay.publish_pending() == 0
    stream_events = await read_stream_events(client, DEFAULT_STREAM)
    assert len(stream_events) == 6
    assert [e["event_id"] for e in stream_events] == [
        e["event_id"] for e in ledger.outbox_events()
    ]
    assert [e["event_type"] for e in stream_events] == [
        "account_opened",
        "account_opened",
        "account_opened",
        "account_opened",
        "approval_issued",
        "transfer_settled",
    ]
    assert all(e["published"] is True for e in ledger.outbox_events())
    # 流条目携带外发表行号：副本据此做快照水印过滤。
    assert [e["outbox_id"] for e in stream_events] == [1, 2, 3, 4, 5, 6]


async def test_duplicate_delivery_is_deduplicated_on_replay(system, ledger):
    await settle_transfer(system)
    client = fakeredis.aioredis.FakeRedis()
    relay = EventRelay(ledger.connection, client)
    await relay.publish_pending()
    # 模拟中继在标记提交前崩溃：重置外发标记后重发，流中出现重复事件。
    with ledger.connection:
        ledger.connection.execute("UPDATE outbox_events SET published = 0, published_at = NULL")
    await relay.publish_pending()
    stream_events = await read_stream_events(client, DEFAULT_STREAM)
    assert len(stream_events) == 12
    replica = make_ledger()
    applied = ReplicaApplier(replica).apply_events(stream_events)
    # 重复事件全部去重；审批事件跳过；开户事件因账户已存在跳过，仅转账事件实际应用。
    assert applied == 1
    assert ledger.diff_ledgers(replica, TENANT, ["acc_1001", "acc_1002"]) == []


async def test_replica_replay_converges_with_origin(system, ledger):
    settled = await settle_transfer(system)
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"]).arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    reversed_outcome = await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"]),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    assert reversed_outcome.ok is True
    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    replica = make_ledger()
    ReplicaApplier(replica).apply_events(await read_stream_events(client, DEFAULT_STREAM))
    accounts = ["acc_1001", "acc_1002", "acc_1003", "acc_1004"]
    assert ledger.diff_ledgers(replica, TENANT, accounts) == []
    for account in accounts:
        assert replica.balance(TENANT, account) == ledger.balance(TENANT, account)


async def test_replica_replay_is_idempotent_across_restart(system, ledger):
    await settle_transfer(system)
    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    events = await read_stream_events(client, DEFAULT_STREAM)
    replica = make_ledger()
    first = ReplicaApplier(replica).apply_events(events)
    assert first >= 1
    # 模拟重启：新回放器从头重放同一流，全部跳过且对账仍零差异。
    restarted = ReplicaApplier(replica).apply_events(events)
    assert restarted == 0
    assert ledger.diff_ledgers(replica, TENANT, ["acc_1001", "acc_1002"]) == []


def test_replay_rejects_unknown_event_type(ledger):
    applier = ReplicaApplier(ledger)
    with pytest.raises(ValueError, match="事件格式无效"):
        applier.apply_event({"event_id": "evt_x", "event_type": "teleport", "payload": {}})


def test_replay_missing_account_fails_loudly():
    replica = AccountLedger()
    applier = ReplicaApplier(replica)
    with pytest.raises(ValueError, match="副本缺少事件涉及的账户"):
        applier.apply_event(
            {
                "event_id": "evt_1",
                "event_type": "transfer_settled",
                "payload": {
                    "tenant_id": TENANT,
                    "transfer_id": "trf_000001",
                    "business_ref": "trf_000001",
                    "from_account": "acc_1001",
                    "to_account": "acc_1002",
                    "amount": "300.00",
                    "status": "settled",
                    "created_at": "2026-11-22T00:00:00+00:00",
                },
            }
        )


async def test_replay_preserves_replica_local_transfer_sequence(system, ledger):
    await settle_transfer(system)
    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    replica = make_ledger()
    ReplicaApplier(replica).apply_events(await read_stream_events(client, DEFAULT_STREAM))
    # 回放同步了流水序号：副本自行记账不与回放单号冲突。
    replica_system = compose_transfer_system(replica)
    args = TransferInstruction.model_validate(transfer_call("local").arguments)
    await approve(replica_system, args, grant_id="grant_local")
    outcome = await replica_system.runtime.invoke(
        transfer_call("local"), make_ctx(approval_id="grant_local")
    )
    assert outcome.ok is True
    assert outcome.content["transfer_id"] == "trf_000002"


@pytest.mark.skipif(not REDIS_URL, reason="未设置 TEST_REDIS_URL 时跳过真实 Redis 冒烟")
async def test_real_redis_stream_relay_and_replay_smoke(system, ledger):
    import redis.asyncio as aioredis

    client = aioredis.from_url(REDIS_URL)
    try:
        await client.ping()
    except Exception:
        pytest.skip("TEST_REDIS_URL 指向的 Redis 不可达")
    stream = "governed:smoke:events"
    await settle_transfer(system)
    published = await EventRelay(ledger.connection, client, stream=stream).publish_pending()
    assert published == 6
    replica = make_ledger()
    ReplicaApplier(replica).apply_events(await read_stream_events(client, stream))
    assert ledger.diff_ledgers(replica, TENANT, ["acc_1001", "acc_1002"]) == []
    await client.delete(stream)


# ---- 用例 50：审批事件入 Outbox（Round-6 轨道二） ------------------------------


async def test_approval_events_follow_state_transitions_in_outbox(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_flow", user_id="u_100", tenant_id=TENANT, args=args)
    system.register_approver("u_admin", TENANT, max_level="high")
    await system.decide_approval(
        "grant_flow", decision="approved", decided_by="u_admin", reason="批准"
    )

    events = [e for e in ledger.outbox_events() if e["event_type"].startswith("approval_")]
    assert [e["event_type"] for e in events] == ["approval_requested", "approval_approved"]
    requested, approved_event = events
    assert requested["payload"] == {
        "tenant_id": TENANT,
        "grant_id": "grant_flow",
        "tool_name": "execute_transfer",
        "level": "low",
        "decided_by": None,
        "kid": requested["payload"]["kid"],
    }
    assert requested["payload"]["kid"]  # 签发审计可追溯密钥标识
    assert approved_event["payload"]["decided_by"] == "u_admin"
    assert approved_event["payload"]["grant_id"] == "grant_flow"
    # 事件负载不含参数与备注文本。
    serialized = json.dumps(requested["payload"], ensure_ascii=False)
    assert "货款" not in serialized
    assert "acc_1001" not in serialized

    # 未授权裁决失败不产生批准事件；请求人自助撤回产生 approval_revoked。
    await system.request_approval("grant_deny", user_id="u_100", tenant_id=TENANT, args=args)
    with pytest.raises(GovernanceViolation):
        await system.decide_approval(
            "grant_deny", decision="approved", decided_by="u_evil", reason="未授权"
        )
    before = len(ledger.outbox_events())
    await system.decide_approval(
        "grant_deny", decision="revoked", decided_by="u_100", reason="误提交撤回"
    )
    assert [e["event_type"] for e in ledger.outbox_events()[before:]] == ["approval_revoked"]

    # 信任编排快速通道签发 approval_issued，与凭证同事务落表。
    await approve(system, args, grant_id="grant_issue")
    assert ledger.outbox_events()[-1]["event_type"] == "approval_issued"


async def test_approval_events_replay_is_skipped_by_replica(system, ledger):
    args = TransferInstruction.model_validate(transfer_call("call_01").arguments)
    await system.request_approval("grant_r1", user_id="u_100", tenant_id=TENANT, args=args)
    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    replica = AccountLedger()  # 空副本：开户事件实际应用
    applied = ReplicaApplier(replica).apply_events(
        await read_stream_events(client, DEFAULT_STREAM)
    )
    # 4 开户事件实际应用，审批事件跳过不计入。
    assert applied == 4
    assert replica.reversed_total(TENANT, "trf_000001") == Decimal("0.00")


# ---- 用例 51：密钥轮换策略端口契约（Round-6 轨道一） ---------------------------


def test_rotation_policy_rotates_by_signature_count():
    signer = Ed25519GrantSigner(
        keys={"ed25519_001": None},
        policy=RotationPolicy(max_signatures=3, grace_signatures=2),
    )
    first_kid, first_sig = signer.sign(b"a")
    assert first_kid == "ed25519_001"
    signer.sign(b"b")
    signer.sign(b"c")
    # 第 4 次签发触发轮换：新主密钥接管签发，旧密钥进入宽限期。
    new_kid, new_sig = signer.sign(b"d")
    assert new_kid == "ed25519_002"
    assert signer.primary_kid == "ed25519_002"
    assert signer.verify(b"a", first_sig, "ed25519_001") is True
    signer.sign(b"e")
    assert signer.verify(b"a", first_sig, "ed25519_001") is True  # 宽限内（差 2 次）
    signer.sign(b"f")
    assert signer.verify(b"a", first_sig, "ed25519_001") is False  # 宽限后停用
    assert signer.verify(b"d", new_sig, "ed25519_002") is True


def test_rotation_policy_rotates_by_age_with_injected_clock():
    now = {"t": 0.0}
    signer = Ed25519GrantSigner(
        keys={"ed25519_001": None},
        clock=lambda: now["t"],
        policy=RotationPolicy(max_age_seconds=10.0, grace_seconds=5.0),
    )
    kid1, sig1 = signer.sign(b"a")
    assert kid1 == "ed25519_001"
    now["t"] = 10.0
    kid2, _ = signer.sign(b"b")  # 主密钥年龄达到阈值：轮换
    assert kid2 == "ed25519_002"
    now["t"] = 14.0
    assert signer.verify(b"a", sig1, kid1) is True  # 停用后 4 秒仍在宽限
    now["t"] = 15.1
    assert signer.verify(b"a", sig1, kid1) is False  # 宽限结束自动停用


def test_signer_without_policy_never_auto_rotates():
    signer = Ed25519GrantSigner.generate()
    kid, _ = signer.sign(b"x")
    for _ in range(9):
        signer.sign(b"x")
    assert signer.primary_kid == kid == "ed25519_001"


def test_signer_private_bytes_roundtrip_for_persistence():
    original = Ed25519GrantSigner.generate()
    raw = original.private_bytes("ed25519_001")
    assert len(raw) == 32
    restored = Ed25519GrantSigner(keys={"ed25519_001": raw})
    payload = grant_signature_payload(
        grant_id="g", user_id="u", tenant_id=TENANT, tool_name="execute_transfer",
        digest="0" * 64, level="low", expires_at=1234.9,
    )
    kid, sig = original.sign(payload)
    assert restored.verify(payload, sig, kid) is True


# ---- 用例 52：快照导出/导入与水印增量回放（Round-6 轨道二） ---------------------


async def test_snapshot_export_import_preserves_full_state(system, ledger):
    settled = await settle_transfer(system)
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled["transfer_id"], amount="100.00").arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    await system.runtime.invoke(
        reverse_call("r1", original=settled["transfer_id"], amount="100.00"),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )

    snapshot = ledger.export_snapshot()
    assert snapshot["schema_version"] == 6
    assert snapshot["outbox_high_water"] == len(ledger.outbox_events())

    replica = AccountLedger()
    replica.import_snapshot(snapshot, checkpoint_stream=DEFAULT_STREAM)
    accounts = ["acc_1001", "acc_1002", "acc_1003", "acc_1004"]
    assert ledger.diff_ledgers(replica, TENANT, accounts) == []
    for account in accounts:
        assert replica.balance(TENANT, account) == ledger.balance(TENANT, account)
    # 流水、幂等键、当日额度与序号全量复制。
    for table in ("transfers", "ledger_entries", "idempotency_keys", "daily_usage"):
        main_rows = {
            tuple(row) for row in ledger.connection.execute(f"SELECT * FROM {table}").fetchall()
        }
        replica_rows = {
            tuple(row)
            for row in replica.connection.execute(f"SELECT * FROM {table}").fetchall()
        }
        assert main_rows == replica_rows
    replica_seq = replica.connection.execute(
        "SELECT value FROM seqs WHERE name = 'transfer'"
    ).fetchone()[0]
    main_seq = ledger.connection.execute(
        "SELECT value FROM seqs WHERE name = 'transfer'"
    ).fetchone()[0]
    assert replica_seq == main_seq
    # 快照水印写入回放检查点：此后只回放高水位之后的流事件。
    checkpoint = replica.replay_checkpoint(DEFAULT_STREAM)
    assert checkpoint["snapshot_watermark"] == snapshot["outbox_high_water"]


def test_import_snapshot_rejects_nonempty_ledger(ledger):
    snapshot = {
        "schema_version": 6,
        "accounts": [],
        "transfers": [],
        "ledger_entries": [],
        "idempotency_keys": [],
        "daily_usage": [],
        "seqs": {"transfer": 0},
        "outbox_high_water": 0,
    }
    with pytest.raises(ValueError, match="非空"):
        ledger.import_snapshot(snapshot)


async def test_snapshot_then_incremental_replay_converges_without_replaying_old_events(
    system, ledger,
):
    await settle_transfer(system, grant_id="grant_1", idempotency_key="biz_1")
    snapshot = ledger.export_snapshot()
    replica = AccountLedger()
    replica.import_snapshot(snapshot, checkpoint_stream=DEFAULT_STREAM)

    # 快照之后主库继续产生事件（转账 + 部分冲正），中继发布增量。
    settled2 = await settle_transfer(
        system, source="acc_1003", target="acc_1001", amount="50.00",
        grant_id="grant_2", idempotency_key="biz_2",
    )
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=settled2["transfer_id"], amount="50.00").arguments
    )
    await approve(system, args, grant_id="grant_rev2", tool_name="reverse_transfer")
    await system.runtime.invoke(
        reverse_call("r1", original=settled2["transfer_id"], amount="50.00"),
        make_ctx(approval_id="grant_rev2", idempotency_key="biz_rev2"),
    )
    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    # 本批发布全部未外发事件（含快照前的旧事件）：副本按水印过滤旧事件。
    stream_events = await read_stream_events(client, DEFAULT_STREAM)
    watermark = replica.replay_checkpoint(DEFAULT_STREAM)["snapshot_watermark"]
    stale = [e for e in stream_events if e["outbox_id"] <= watermark]
    fresh = [e for e in stream_events if e["outbox_id"] > watermark]
    assert stale and fresh  # 两种事件同批在流中

    applied = ReplicaApplier(replica).apply_events(stream_events)
    assert applied == 2  # 水印内旧事件被过滤，只有转账与冲正两个业务事件生效
    accounts = ["acc_1001", "acc_1002", "acc_1003", "acc_1004"]
    assert ledger.diff_ledgers(replica, TENANT, accounts) == []


# ---- 用例 53：副本回放检查点续读（Round-6 轨道二） ------------------------------


class _SpyXrange:
    """记录 xrange 起始参数的代理客户端：锚定续读不从流头扫描。"""

    def __init__(self, inner):
        self._inner = inner
        self.starts: list[str] = []

    async def xrange(self, stream, min="-", max="+", count=None):
        self.starts.append(min)
        return await self._inner.xrange(stream, min=min, max=max, count=count)


async def test_replay_checkpoint_resumes_stream_without_rescanning(system, ledger):
    await settle_transfer(system, grant_id="grant_1", idempotency_key="biz_1")
    client = fakeredis.aioredis.FakeRedis()
    spy = _SpyXrange(client)
    await EventRelay(ledger.connection, client).publish_pending()

    replica = AccountLedger()
    applier = ReplicaApplier(replica)
    assert await applier.replay_stream(spy, DEFAULT_STREAM) == 5  # 4 开户 + 1 转账
    checkpoint = replica.replay_checkpoint(DEFAULT_STREAM)
    first_entry = checkpoint["last_entry_id"]
    assert first_entry is not None
    assert spy.starts == ["-"]

    # 主库继续产生事件并发布，副本按检查点续读（不再从 "-" 开始）。
    await settle_transfer(system, source="acc_1003", target="acc_1001", amount="50.00",
                          grant_id="grant_2", idempotency_key="biz_2")
    await EventRelay(ledger.connection, client).publish_pending()
    assert await applier.replay_stream(spy, DEFAULT_STREAM) == 1
    assert spy.starts[-1] == first_entry
    assert replica.replay_checkpoint(DEFAULT_STREAM)["last_entry_id"] != first_entry
    accounts = ["acc_1001", "acc_1002", "acc_1003", "acc_1004"]
    assert ledger.diff_ledgers(replica, TENANT, accounts) == []
    # 再次续读：无新事件，进度不变。
    assert await applier.replay_stream(spy, DEFAULT_STREAM) == 0


# ---- 用例 54：中继失败标记、死信与租约单飞（Round-6 轨道二） ---------------------


class _FailingXadd:
    async def xadd(self, *args, **kwargs):
        raise ConnectionError("redis down")


async def test_relay_failure_counts_attempts_and_dead_letters(system, ledger):
    await settle_transfer(system)
    relay = EventRelay(ledger.connection, _FailingXadd(), max_attempts=3)
    assert await relay.publish_pending() == 0
    assert await relay.publish_pending() == 0
    assert await relay.publish_pending() == 0
    rows = ledger.outbox_events()
    assert all(e["attempts"] == 3 for e in rows)
    assert all(e["dead"] is True for e in rows)
    assert all(e["last_error"] and "redis down" in e["last_error"] for e in rows)
    backlog = ledger.outbox_backlog()
    assert backlog == {"pending": 0, "dead": 6}
    # 死信不再参与发布：正常客户端下积压仍为零待发。
    healthy = EventRelay(ledger.connection, fakeredis.aioredis.FakeRedis())
    assert await healthy.publish_pending() == 0


async def test_relay_backlog_observes_pending(system, ledger):
    assert ledger.outbox_backlog() == {"pending": 4, "dead": 0}  # 开户事件待外发
    await settle_transfer(system)
    assert ledger.outbox_backlog() == {"pending": 6, "dead": 0}
    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    assert ledger.outbox_backlog() == {"pending": 0, "dead": 0}


async def test_relay_lease_serializes_concurrent_publishers(tmp_path):
    db_path = str(tmp_path / "relay.db")
    ledger_a = AccountLedger(db_path=db_path)
    ledger_b = AccountLedger(db_path=db_path)
    for account, balance in (("acc_1001", "1000.00"), ("acc_1002", "500.00"),
                             ("acc_1003", "100.00"), ("acc_1004", "100.00")):
        ledger_a.open_account(TENANT, account, balance)
    system = compose_transfer_system(ledger_a)
    await settle_transfer(system)

    client = fakeredis.aioredis.FakeRedis()
    lease_a = SqliteLockManager(conn=ledger_a.connection, acquire_timeout_seconds=5.0)
    lease_b = SqliteLockManager(conn=ledger_b.connection, acquire_timeout_seconds=5.0)
    relay_a = EventRelay(ledger_a.connection, client, lease=lease_a)
    relay_b = EventRelay(ledger_a.connection, client, lease=lease_b)
    results = await asyncio.gather(relay_a.publish_pending(), relay_b.publish_pending())
    assert sorted(results) == [0, 6]  # 租约互斥：只有一个实例发布
    stream_events = await read_stream_events(client, DEFAULT_STREAM)
    assert len(stream_events) == 6  # 单飞后流中无重复投递
    assert all(e["published"] is True for e in ledger_a.outbox_events())


# ---- 用例 55：副本回放补齐写侧状态（Round-6 轨道二） ----------------------------


async def test_replica_replay_replicates_idempotency_keys_and_daily_usage(system, ledger):
    await settle_transfer(system)
    limits = RateLimiter(conn=ledger.connection)
    assert limits.daily_total(TENANT) == Decimal("300.00")

    client = fakeredis.aioredis.FakeRedis()
    await EventRelay(ledger.connection, client).publish_pending()
    replica = make_ledger()
    ReplicaApplier(replica).apply_events(await read_stream_events(client, DEFAULT_STREAM))

    # 幂等键与当日额度随事件回放，与主库一致。
    main_keys = {
        tuple(row)
        for row in ledger.connection.execute(
            "SELECT tenant_id, idempotency_key, params_digest, transfer_id FROM idempotency_keys"
        ).fetchall()
    }
    replica_keys = {
        tuple(row)
        for row in replica.connection.execute(
            "SELECT tenant_id, idempotency_key, params_digest, transfer_id FROM idempotency_keys"
        ).fetchall()
    }
    assert main_keys == replica_keys and main_keys
    main_usage = {
        tuple(row)
        for row in ledger.connection.execute("SELECT tenant_id, day, total FROM daily_usage").fetchall()
    }
    replica_usage = {
        tuple(row)
        for row in replica.connection.execute(
            "SELECT tenant_id, day, total FROM daily_usage"
        ).fetchall()
    }
    assert main_usage == replica_usage and main_usage
    # 副本对既有幂等键的读取语义与主库一致。
    same_ref = ledger.idempotent_transfer(TENANT, "biz_001")
    replica_ref = replica.idempotent_transfer(TENANT, "biz_001")
    assert same_ref["transfer_id"] == replica_ref["transfer_id"]

    # 部分冲正回补当日额度：主副本计数继续一致。
    args = ReverseInstruction.model_validate(
        reverse_call("r1", original=same_ref["transfer_id"], amount="120.00").arguments
    )
    await approve(system, args, grant_id="grant_rev", tool_name="reverse_transfer")
    await system.runtime.invoke(
        reverse_call("r1", original=same_ref["transfer_id"], amount="120.00"),
        make_ctx(approval_id="grant_rev", idempotency_key="biz_rev"),
    )
    await EventRelay(ledger.connection, client).publish_pending()
    ReplicaApplier(replica).apply_events(await read_stream_events(client, DEFAULT_STREAM))
    assert limits.daily_total(TENANT) == Decimal("180.00")
    replica_limits = RateLimiter(conn=replica.connection)
    assert replica_limits.daily_total(TENANT) == Decimal("180.00")


# ---- 用例 56：v3-with-data 迁移的期初回填（Round-6 测试缺口） -------------------

V3_SCHEMA = """
CREATE TABLE accounts (
    tenant_id TEXT NOT NULL, account TEXT NOT NULL, balance TEXT NOT NULL, status TEXT NOT NULL,
    PRIMARY KEY (tenant_id, account)
);
CREATE TABLE transfers (
    tenant_id TEXT NOT NULL, transfer_id TEXT NOT NULL, business_ref TEXT NOT NULL,
    from_account TEXT NOT NULL, to_account TEXT NOT NULL, amount TEXT NOT NULL,
    status TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (tenant_id, transfer_id)
);
CREATE INDEX idx_transfers_business_ref ON transfers (tenant_id, business_ref);
CREATE TABLE idempotency_keys (
    tenant_id TEXT NOT NULL, idempotency_key TEXT NOT NULL, params_digest TEXT NOT NULL,
    transfer_id TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (tenant_id, idempotency_key)
);
CREATE TABLE approval_grants (
    grant_id TEXT PRIMARY KEY, user_id TEXT NOT NULL, tenant_id TEXT NOT NULL,
    tool_name TEXT NOT NULL, digest TEXT NOT NULL, level TEXT NOT NULL,
    expires_at REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0,
    state TEXT NOT NULL DEFAULT 'approved', issued_by TEXT NOT NULL, issued_at TEXT NOT NULL,
    decided_by TEXT, decided_at TEXT, reason TEXT
);
CREATE TABLE audit_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, payload TEXT NOT NULL,
    prev_hash TEXT NOT NULL DEFAULT '', hash TEXT NOT NULL DEFAULT ''
);
CREATE TABLE seqs (name TEXT PRIMARY KEY, value INTEGER NOT NULL);
CREATE TABLE locks (scope_key TEXT PRIMARY KEY, owner TEXT NOT NULL, expires_at REAL NOT NULL);
CREATE TABLE ledger_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL, account TEXT NOT NULL,
    side TEXT NOT NULL, amount TEXT NOT NULL, transfer_id TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX idx_entries_account ON ledger_entries (tenant_id, account, id);
CREATE TABLE rate_limits (
    tenant_id TEXT NOT NULL, tool_name TEXT NOT NULL, window_start REAL NOT NULL,
    count INTEGER NOT NULL, PRIMARY KEY (tenant_id, tool_name)
);
CREATE TABLE daily_usage (
    tenant_id TEXT NOT NULL, day TEXT NOT NULL, total TEXT NOT NULL, PRIMARY KEY (tenant_id, day)
);
CREATE TABLE approval_authorities (
    approver_id TEXT NOT NULL, tenant_id TEXT NOT NULL, max_level TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1, PRIMARY KEY (approver_id, tenant_id)
);
INSERT INTO seqs (name, value) VALUES ('transfer', 1);
"""


def test_v3_with_data_migrates_to_v6_with_reconciled_openings(tmp_path):
    db_path = str(tmp_path / "v3data.db")
    conn = sqlite3.connect(db_path)
    conn.executescript(V3_SCHEMA)
    conn.execute(
        "INSERT INTO accounts (tenant_id, account, balance, status) "
        "VALUES ('tenant_v3', 'acc_a', '300.00', 'active')"
    )
    conn.execute(
        "INSERT INTO accounts (tenant_id, account, balance, status) "
        "VALUES ('tenant_v3', 'acc_b', '100.00', 'active')"
    )
    conn.execute(
        "INSERT INTO transfers (tenant_id, transfer_id, business_ref, from_account, "
        "to_account, amount, status, created_at) "
        "VALUES ('tenant_v3', 'trf_000001', 'biz_v3', 'acc_a', 'acc_b', '50.00', "
        "'settled', '2026-01-01T00:00:00+00:00')"
    )
    for account, side, amount, transfer_id in (
        ("acc_a", "credit", "100.00", "trf_initial"),
        ("acc_a", "debit", "50.00", "trf_000001"),
        ("acc_b", "credit", "50.00", "trf_000001"),
    ):
        conn.execute(
            "INSERT INTO ledger_entries (tenant_id, account, side, amount, transfer_id, created_at) "
            "VALUES ('tenant_v3', ?, ?, ?, ?, '2026-01-01T00:00:00+00:00')",
            (account, side, amount, transfer_id),
        )
    # v3 时代审计链已存在（v2 迁移回填产物）：数据自带完整哈希链。
    payload = '{"event": "open"}'
    conn.execute(
        "INSERT INTO audit_records (ts, payload, prev_hash, hash) VALUES (?, ?, '', ?)",
        (
            "2026-01-01T00:00:00+00:00",
            payload,
            hashlib.sha256(payload.encode("utf-8")).hexdigest(),
        ),
    )
    conn.execute("PRAGMA user_version = 3")
    conn.commit()
    conn.close()

    ledger = AccountLedger(db_path=db_path)
    assert ledger.connection.execute("PRAGMA user_version").fetchone()[0] == 6
    # 期初回填数学：期初 = 余额 - 分录净额，对账恒等式在迁移库上成立。
    report_a = ledger.reconcile_account("tenant_v3", "acc_a")
    report_b = ledger.reconcile_account("tenant_v3", "acc_b")
    assert report_a["consistent"] is True and report_b["consistent"] is True
    assert report_a["opening"] == "250.00"  # 300 - (100 - 50)
    assert report_b["opening"] == "50.00"  # 100 - 50
    # 冲正关联列与签名列随迁移就位，存量审计受不可变触发器保护。
    assert ledger.get_transfer("tenant_v3", "trf_000001")["original_transfer_id"] is None
    with pytest.raises(sqlite3.IntegrityError):
        with ledger.connection:
            ledger.connection.execute(
                "UPDATE audit_records SET payload = '{}' WHERE id = 1"
            )
    audit = AuditJournal(conn=ledger.connection)
    assert audit.verify_chain() is None
    # 迁移库可继续正常记账。
    ledger.open_account("tenant_v3", "acc_c", "10.00")
    ledger.apply_transfer("tenant_v3", "acc_a", "acc_c", Decimal("20.00"), None,
                          request_digest("execute_transfer",
                                         TransferInstruction.model_validate(
                                             transfer_call("c1").arguments
                                         )))
    assert ledger.balance("tenant_v3", "acc_c") == Decimal("30.00")
