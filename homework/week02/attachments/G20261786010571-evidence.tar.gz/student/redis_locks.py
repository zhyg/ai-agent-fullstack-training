"""Redis 分布式锁端口实现：多主机共享 Redis 时的写串行化。

获取用 SET NX PX 原子完成、随机令牌标识持有者、释放用 WATCH/MULTI 事务
比较后删除（防止过期被接管后误删新持有者的锁）；TTL 由 Redis 自身时钟
管理，主机本地时钟不参与过期判定。依赖 redis-py 异步客户端，未安装本
依赖时模块不可用，组合根默认仍装配 SQLite 锁实现。
"""

from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Sequence
from uuid import uuid4

from governance import GovernanceViolation, InProcessLockManager, OutcomeCode

try:
    from redis.exceptions import WatchError
except ImportError:  # redis-py 未安装时模块仅作类型参考，WatchError 仅在释放时兜底
    WatchError = Exception


class RedisLockManager:
    """LockPort 的 Redis 实现：多键按字典序全部获取成功才持有。"""

    def __init__(
        self,
        client: Any,
        *,
        lock_ttl_seconds: float = 30.0,
        acquire_timeout_seconds: float = 10.0,
        retry_interval: float = 0.02,
    ) -> None:
        self._client = client
        self._owner = uuid4().hex
        self._lock_ttl_ms = max(int(lock_ttl_seconds * 1000), 1)
        self._acquire_timeout = acquire_timeout_seconds
        self._retry_interval = retry_interval
        self._local = InProcessLockManager()

    @asynccontextmanager
    async def locked(self, keys: Sequence[str]) -> AsyncIterator[None]:
        ordered = sorted(set(keys))
        async with self._local.locked(ordered):
            held: list[tuple[str, str]] = []
            deadline = time.monotonic() + self._acquire_timeout
            while True:
                acquired: list[tuple[str, str]] = []
                for key in ordered:
                    token = f"{self._owner}:{uuid4().hex}"
                    ok = await self._client.set(key, token, nx=True, px=self._lock_ttl_ms)
                    if ok:
                        acquired.append((key, token))
                    else:
                        break
                if len(acquired) == len(ordered):
                    held = acquired
                    break
                await self._release(acquired)
                if time.monotonic() >= deadline:
                    raise GovernanceViolation(
                        OutcomeCode.TEMPORARY_UNAVAILABLE, "获取串行化锁超时，请稍后重试"
                    )
                await asyncio.sleep(self._retry_interval)
            try:
                yield
            finally:
                await self._release(held)

    async def _release(self, tokens: Sequence[tuple[str, str]]) -> None:
        for key, token in tokens:
            await self._release_one(key, token)

    async def _release_one(self, key: str, token: str) -> None:
        """仅当键仍由本持有者令牌持有时删除；键被接管时静默跳过。"""
        try:
            pipe = self._client.pipeline(transaction=True)
            await pipe.watch(key)
            current = await pipe.get(key)
            if isinstance(current, bytes):
                current = current.decode()
            if current == token:
                pipe.multi()
                pipe.delete(key)
                await pipe.execute()
            else:
                await pipe.unwatch()
        except WatchError:
            pass
