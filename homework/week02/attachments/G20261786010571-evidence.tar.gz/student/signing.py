"""审批凭证签名端口：Ed25519 实现与规范载荷构造。

签名绑定凭证的不可变字段（标识、身份、租户、工具、摘要、层级、过期时间），
状态字段（used/state/decided_by 等）由数据库事务与审计哈希链保证，不参与
签名——签名防的是凭证伪造与内容篡改，而非对拥有数据库写权限者的状态篡改。
密钥按 kid 命名并支持轮换：签发用主密钥，验签在活跃密钥集合内解析，
停用某 kid 后该密钥签发的凭证立即失效。可选轮换策略按签发次数或主密钥
年龄自动轮换新主密钥，旧密钥保留宽限期（次数或时长）后自动停用。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Callable, Mapping, Protocol

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

_RAW_PRIVATE = serialization.Encoding.Raw
_RAW_FORMAT = serialization.PrivateFormat.Raw
_NO_ENCRYPTION = serialization.NoEncryption()


def grant_signature_payload(
    *,
    grant_id: str,
    user_id: str,
    tenant_id: str,
    tool_name: str,
    digest: str,
    level: str,
    expires_at: float,
) -> bytes:
    """构造凭证签名规范载荷：键排序、紧凑分隔、过期时间取整数秒。

    签发与验签都从同一批字段重算，任何字段被篡改都会导致验签失败；
    过期时间取整数秒消除浮点表示差异，亚秒级截断不影响语义。
    """
    canonical = {
        "grant_id": grant_id,
        "user_id": user_id,
        "tenant_id": tenant_id,
        "tool_name": tool_name,
        "digest": digest,
        "level": level,
        "expires_at": int(float(expires_at)),
    }
    return json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")


class GrantSigner(Protocol):
    """凭证签名端口：签发用主密钥，验签按 kid 在活跃密钥集合中解析。"""

    def sign(self, payload: bytes) -> tuple[str, str]: ...

    def verify(self, payload: bytes, signature: str, kid: str) -> bool: ...


@dataclass(frozen=True)
class RotationPolicy:
    """自动轮换策略：签发次数或主密钥年龄触发新主密钥，旧密钥宽限期后停用。

    - max_signatures：主密钥累计签发次数达到该值即轮换（None 不按次数触发）；
    - max_age_seconds：主密钥年龄达到该值即轮换（None 不按年龄触发）；
    - grace_signatures / grace_seconds：旧密钥停用后的宽限（以先到者判定），
      均为 0 时旧密钥立即停用；
    - key_prefix：自动生成的新主密钥 kid 前缀。
    """

    max_signatures: int | None = None
    max_age_seconds: float | None = None
    grace_signatures: int = 0
    grace_seconds: float = 0.0
    key_prefix: str = "ed25519"


def _kid_serial(kid: str) -> int:
    """从 kid 尾部解析编号（如 ed25519_001 -> 1），不可解析按 0 处理。"""
    parts = kid.rsplit("_", 1)
    try:
        return int(parts[-1])
    except (ValueError, IndexError):
        return 0


class Ed25519GrantSigner:
    """GrantSigner 的 Ed25519 实现：多把活跃密钥、主密钥签发、停用即失效。

    注入 RotationPolicy 后按签发次数或主密钥年龄自动轮换：旧主密钥移出
    活跃集合（仅保留公钥供宽限验签），宽限期过后自动停用。时钟函数可
    注入（默认 time.monotonic），年龄与宽限判定不依赖主机墙钟。
    """

    def __init__(
        self,
        keys: Mapping[str, bytes | None] | None = None,
        *,
        primary: str | None = None,
        clock: Callable[[], float] = time.monotonic,
        policy: RotationPolicy | None = None,
    ) -> None:
        if keys is None:
            keys = {"ed25519_001": None}
        self._keys: dict[str, Ed25519PrivateKey] = {}
        for kid, raw in keys.items():
            self._keys[kid] = (
                Ed25519PrivateKey.generate()
                if raw is None
                else Ed25519PrivateKey.from_private_bytes(raw)
            )
        first = next(iter(self._keys))
        self._primary = primary if primary is not None else first
        if self._primary not in self._keys:
            raise ValueError(f"主密钥未注册: {self._primary}")
        self._clock = clock
        self._policy = policy
        self._issue_count = 0
        self._total_signed = 0
        self._primary_since = clock()
        self._next_serial = max(_kid_serial(kid) for kid in self._keys) + 1
        self._retiring: dict[str, Ed25519PublicKey] = {}
        self._retired_at: dict[str, tuple[float, int]] = {}

    @classmethod
    def generate(cls, kid: str = "ed25519_001") -> "Ed25519GrantSigner":
        """生成单把密钥的签名器：测试与单实例装配的默认形态。"""
        return cls(keys={kid: None})

    @property
    def primary_kid(self) -> str:
        return self._primary

    def private_bytes(self, kid: str) -> bytes:
        """返回活跃密钥的原始私钥字节：持久化注入（KMS/密钥文件）的读取面。"""
        key = self._keys.get(kid)
        if key is None:
            raise KeyError(f"密钥未注册: {kid}")
        return key.private_bytes(_RAW_PRIVATE, _RAW_FORMAT, _NO_ENCRYPTION)

    def add_key(
        self, kid: str, *, private_bytes: bytes | None = None, make_primary: bool = False
    ) -> None:
        """注册新密钥（或注入既有私钥字节），可选立即设为主密钥。"""
        if kid in self._keys:
            raise ValueError(f"密钥标识已存在: {kid}")
        self._keys[kid] = (
            Ed25519PrivateKey.generate()
            if private_bytes is None
            else Ed25519PrivateKey.from_private_bytes(private_bytes)
        )
        self._next_serial = max(self._next_serial, _kid_serial(kid) + 1)
        if make_primary or len(self._keys) == 1:
            self._primary = kid

    def rotate_to(self, kid: str) -> None:
        """切换签发主密钥：轮换期间旧密钥仍在活跃集合内继续验签。"""
        if kid not in self._keys:
            raise ValueError(f"密钥未注册: {kid}")
        self._primary = kid
        self._issue_count = 0
        self._primary_since = self._clock()

    def deactivate(self, kid: str) -> None:
        """停用密钥：其签发的凭证立即无法通过验签；主密钥被停用时顺延。"""
        self._keys.pop(kid, None)
        self._retiring.pop(kid, None)
        self._retired_at.pop(kid, None)
        if self._primary == kid:
            self._primary = next(iter(self._keys), "")

    def _maybe_rotate(self) -> None:
        """策略触发时生成新主密钥并把旧主密钥移入宽限集合。"""
        policy = self._policy
        assert policy is not None
        trigger = False
        if policy.max_signatures is not None and self._issue_count >= policy.max_signatures:
            trigger = True
        if (
            policy.max_age_seconds is not None
            and self._clock() - self._primary_since >= policy.max_age_seconds
        ):
            trigger = True
        if not trigger or not self._primary:
            return
        old = self._primary
        new_kid = f"{policy.key_prefix}_{self._next_serial:03d}"
        self._next_serial += 1
        self._keys[new_kid] = Ed25519PrivateKey.generate()
        if policy.grace_seconds > 0 or policy.grace_signatures > 0:
            self._retiring[old] = self._keys[old].public_key()
            self._retired_at[old] = (self._clock(), self._total_signed)
        self._keys.pop(old)
        self._primary = new_kid
        self._issue_count = 0
        self._primary_since = self._clock()

    def _within_grace(self, kid: str) -> bool:
        """宽限期判定：时长与签发次数先到者生效；宽限已过从集合移除。"""
        policy = self._policy
        if policy is None:
            return False
        retired_at, signed_at = self._retired_at[kid]
        now = self._clock()
        expired = (
            (policy.grace_seconds > 0 and now - retired_at > policy.grace_seconds)
            or (
                policy.grace_signatures > 0
                and self._total_signed - signed_at > policy.grace_signatures
            )
        )
        if expired:
            self._retiring.pop(kid, None)
            self._retired_at.pop(kid, None)
            return False
        return True

    def sign(self, payload: bytes) -> tuple[str, str]:
        if self._policy is not None:
            self._maybe_rotate()
        key = self._keys.get(self._primary)
        if key is None:
            raise RuntimeError("签名器没有可用的主密钥")
        signature = key.sign(payload).hex()
        self._issue_count += 1
        self._total_signed += 1
        return self._primary, signature

    def verify(self, payload: bytes, signature: str, kid: str) -> bool:
        key = self._keys.get(kid)
        if key is None:
            # 轮换退出的旧密钥仅在宽限期内以公钥验签，宽限过后自动停用。
            public = self._retiring.get(kid)
            if public is None or not self._within_grace(kid):
                return False
            try:
                public.verify(bytes.fromhex(signature), payload)
            except (ValueError, InvalidSignature):
                return False
            return True
        try:
            key.public_key().verify(bytes.fromhex(signature), payload)
        except (ValueError, InvalidSignature):
            return False
        return True
