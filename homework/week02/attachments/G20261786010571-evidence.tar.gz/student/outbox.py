"""事件外发端口：Outbox 模式的中继与副本回放。

业务变更（开户、转账结算、冲正）与事件写外发表在同一事务内完成；中继把
未外发事件按创建顺序发布到 Redis Stream，发布成功才标记已外发（at-least-once，
进程在标记提交前崩溃会把同一事件再次发布）；消费者按事件标识与业务键双重
幂等去重。副本回放端口把事件序列应用到副本账本，配合 diff_ledgers 完成
「回放 → 对账」的增量修复闭环。审批事件与凭证状态变更同事务写入外发表，
经同一中继发布给通知类消费方；副本回放跳过审批事件（不影响账本）。

中继发布失败记录尝试次数与最后错误、超阈值转死信，多主机经锁端口租约
互斥（单飞）；副本消费进度持久化为回放检查点，快照水印过滤已含事件，
副本回放同时补齐幂等键与当日额度计数。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

EVENT_ACCOUNT_OPENED = "account_opened"
EVENT_TRANSFER_SETTLED = "transfer_settled"
EVENT_TRANSFER_REVERSED = "transfer_reversed"
EVENT_TYPES = frozenset({EVENT_ACCOUNT_OPENED, EVENT_TRANSFER_SETTLED, EVENT_TRANSFER_REVERSED})

EVENT_APPROVAL_REQUESTED = "approval_requested"
EVENT_APPROVAL_ISSUED = "approval_issued"
EVENT_APPROVAL_APPROVED = "approval_approved"
EVENT_APPROVAL_REVOKED = "approval_revoked"
# 审批事件供通知类消费方使用，副本回放按类型跳过、不影响账本状态。
APPROVAL_EVENT_TYPES = frozenset(
    {
        EVENT_APPROVAL_REQUESTED,
        EVENT_APPROVAL_ISSUED,
        EVENT_APPROVAL_APPROVED,
        EVENT_APPROVAL_REVOKED,
    }
)

DEFAULT_STREAM = "governed:transfers"


class EventRelay:
    """中继端口：把未外发事件发布到 Redis Stream，发布成功后标记已外发。

    发布失败逐行记录尝试次数与最后错误，超过 max_attempts 转死信（不再
    参与发布）；注入锁端口租约后，多主机同时运行的中继在租约内互斥单飞，
    重复投递从源头收敛。
    """

    def __init__(
        self,
        conn,
        client,
        *,
        stream: str = DEFAULT_STREAM,
        max_batch: int = 100,
        lease=None,
        max_attempts: int = 5,
    ) -> None:
        self._conn = conn
        self._client = client
        self._stream = stream
        self._max_batch = max_batch
        self._lease = lease
        self._max_attempts = max_attempts

    async def publish_pending(self) -> int:
        """发布一批（按创建顺序）未外发事件，返回本批发布数量。

        发布成功的行在批末一次性标记已外发：标记提交前崩溃会重复发布，
        消费端按事件标识去重，属 at-least-once 投递语义；单行发布失败
        只影响该行（记录尝试/置死信），不阻塞同批其他事件。
        """
        if self._lease is not None:
            async with self._lease.locked([f"relay:{self._stream}"]):
                return await self._publish_batch()
        return await self._publish_batch()

    async def _publish_batch(self) -> int:
        rows = self._conn.execute(
            "SELECT id, event_id, event_type, payload FROM outbox_events "
            "WHERE published = 0 AND dead = 0 ORDER BY id LIMIT ?",
            (self._max_batch,),
        ).fetchall()
        if not rows:
            return 0
        published_ids: list[int] = []
        for row in rows:
            try:
                await self._client.xadd(
                    self._stream,
                    {
                        "event_id": row["event_id"],
                        "event_type": row["event_type"],
                        "payload": row["payload"],
                        "outbox_id": str(row["id"]),
                    },
                    maxlen=10_000,
                )
            except Exception as exc:  # 发布失败落观测标记，不中断同批其他行
                with self._conn:
                    self._conn.execute(
                        "UPDATE outbox_events SET attempts = attempts + 1, last_error = ?, "
                        "dead = CASE WHEN attempts + 1 >= ? THEN 1 ELSE 0 END WHERE id = ?",
                        (str(exc)[:500], self._max_attempts, row["id"]),
                    )
                continue
            published_ids.append(row["id"])
        if published_ids:
            published_at = datetime.now(timezone.utc).isoformat()
            with self._conn:
                self._conn.executemany(
                    "UPDATE outbox_events SET published = 1, published_at = ? WHERE id = ?",
                    [(published_at, outbox_id) for outbox_id in published_ids],
                )
        return len(published_ids)

    async def publish_until_drained(self) -> int:
        """分批发布全部未外发事件：批间独立提交，进度可断点续跑。"""
        total = 0
        while True:
            count = await self.publish_pending()
            if count == 0:
                return total
            total += count


def _decode(value: Any) -> str:
    return value.decode() if isinstance(value, bytes) else str(value)


async def read_stream_events(
    client, stream: str, *, start: str = "-", count: int | None = None
) -> list[dict[str, Any]]:
    """按流序读取事件：解码字段并解析负载，保留流条目位置与外发表行号。"""
    entries = await client.xrange(stream, min=start, max="+", count=count)
    events: list[dict[str, Any]] = []
    for entry_id, fields in entries:
        decoded = {_decode(key): _decode(value) for key, value in fields.items()}
        outbox_id = decoded.get("outbox_id")
        events.append(
            {
                "entry_id": _decode(entry_id),
                "outbox_id": int(outbox_id) if outbox_id is not None else None,
                "event_id": decoded["event_id"],
                "event_type": decoded["event_type"],
                "payload": json.loads(decoded["payload"]),
            }
        )
    return events


class ReplicaApplier:
    """副本回放端口：按事件序列把变更应用到副本账本，双重幂等。

    事件标识去重（进程内）叠加业务键去重（账户/流水已存在即跳过）：重放
    同一序列任意次结果一致，重启后从头重放也安全。每个事件在单事务内
    应用，崩溃不留下半应用状态；副本缺少事件涉及的账户时大声失败，
    不静默产生错误余额。回放同步流水序号，副本后续自行记账不与回放单号冲突。

    快照水印（outbox 行号）以内的事件一律跳过，副本从快照起步后只回放
    增量；审批事件不影响账本，按类型跳过。转账/冲正事件负载携带参数摘要
    与当日信息，回放同时补齐幂等键与当日额度计数（写侧状态复制）。
    """

    def __init__(self, ledger, *, watermark: int = 0) -> None:
        self._ledger = ledger
        self._conn = ledger.connection
        self._seen: set[str] = set()
        self._watermark = watermark

    def apply_events(self, events) -> int:
        """按序应用事件列表，返回实际生效（非跳过）的事件数。"""
        return sum(1 for event in events if self.apply_event(event))

    def apply_event(self, event: dict[str, Any]) -> bool:
        event_id = event.get("event_id")
        event_type = event.get("event_type")
        payload = event.get("payload")
        if (
            not isinstance(event_id, str)
            or not event_id
            or not isinstance(payload, dict)
            or (event_type not in EVENT_TYPES and event_type not in APPROVAL_EVENT_TYPES)
        ):
            raise ValueError(f"事件格式无效: {event_type!r}")
        if event_type in APPROVAL_EVENT_TYPES:
            return False  # 审批事件供通知消费方，回放不影响账本
        outbox_id = event.get("outbox_id")
        if outbox_id is not None and int(outbox_id) <= self._watermark:
            return False  # 快照水印以内的事件已被快照覆盖
        if event_id in self._seen:
            return False
        applied = self._apply(event_type, payload)
        self._seen.add(event_id)
        return applied

    async def replay_stream(self, client, stream: str = DEFAULT_STREAM) -> int:
        """从回放检查点续读流并应用事件：消费成功后持久化进度，重启续读
        不再从头扫描；快照导入写入的水印随检查点生效。"""
        checkpoint = self._ledger.replay_checkpoint(stream)
        start = "-"
        if checkpoint is not None:
            if checkpoint["last_entry_id"]:
                start = checkpoint["last_entry_id"]
            self._watermark = max(self._watermark, checkpoint["snapshot_watermark"])
        events = await read_stream_events(client, stream, start=start)
        applied = 0
        last_entry: str | None = None
        for event in events:
            if self.apply_event(event):
                applied += 1
            last_entry = event["entry_id"]
        if last_entry is not None:
            self._ledger.set_replay_checkpoint(stream, last_entry_id=last_entry)
        return applied

    def _apply(self, event_type: str, payload: dict[str, Any]) -> bool:
        if event_type == EVENT_ACCOUNT_OPENED:
            return self._apply_account(payload)
        status = "settled" if event_type == EVENT_TRANSFER_SETTLED else "reversed"
        return self._apply_transfer(payload, status=status)

    def _apply_account(self, payload: dict[str, Any]) -> bool:
        tenant_id, account = payload["tenant_id"], payload["account"]
        with self._conn:
            exists = self._conn.execute(
                "SELECT 1 FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, account),
            ).fetchone()
            if exists is not None:
                return False
            self._conn.execute(
                "INSERT INTO accounts (tenant_id, account, balance, status, opening) "
                "VALUES (?, ?, ?, ?, ?)",
                (tenant_id, account, payload["opening"], payload["status"], payload["opening"]),
            )
        return True

    def _apply_transfer(self, payload: dict[str, Any], *, status: str) -> bool:
        tenant_id, transfer_id = payload["tenant_id"], payload["transfer_id"]
        with self._conn:
            exists = self._conn.execute(
                "SELECT 1 FROM transfers WHERE tenant_id = ? AND transfer_id = ?",
                (tenant_id, transfer_id),
            ).fetchone()
            if exists is not None:
                return False
            amount = Decimal(payload["amount"])
            source = self._conn.execute(
                "SELECT balance FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, payload["from_account"]),
            ).fetchone()
            target = self._conn.execute(
                "SELECT balance FROM accounts WHERE tenant_id = ? AND account = ?",
                (tenant_id, payload["to_account"]),
            ).fetchone()
            if source is None or target is None:
                raise ValueError(f"副本缺少事件涉及的账户: {transfer_id}")
            if amount > Decimal(source["balance"]):
                raise ValueError(f"副本余额不足以应用事件: {transfer_id}")
            self._conn.execute(
                "UPDATE accounts SET balance = ? WHERE tenant_id = ? AND account = ?",
                (format(Decimal(source["balance"]) - amount, "f"), tenant_id, payload["from_account"]),
            )
            self._conn.execute(
                "UPDATE accounts SET balance = ? WHERE tenant_id = ? AND account = ?",
                (format(Decimal(target["balance"]) + amount, "f"), tenant_id, payload["to_account"]),
            )
            created_at = payload.get("created_at") or datetime.now(timezone.utc).isoformat()
            self._conn.execute(
                "INSERT INTO transfers (tenant_id, transfer_id, business_ref, from_account, "
                "to_account, amount, status, created_at, original_transfer_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tenant_id,
                    transfer_id,
                    payload["business_ref"],
                    payload["from_account"],
                    payload["to_account"],
                    payload["amount"],
                    status,
                    created_at,
                    payload.get("original_transfer_id"),
                ),
            )
            for account, side in ((payload["from_account"], "debit"), (payload["to_account"], "credit")):
                self._conn.execute(
                    "INSERT INTO ledger_entries (tenant_id, account, side, amount, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (tenant_id, account, side, payload["amount"], transfer_id, created_at),
                )
            # 同步流水序号：副本后续自行记账不与回放的流水单号冲突。
            numeric = int(transfer_id.removeprefix("trf_"))
            self._conn.execute(
                "UPDATE seqs SET value = MAX(value, ?) WHERE name = 'transfer'", (numeric,)
            )
            # 写侧状态复制：幂等键（business_ref 与单号不同即为携带键的调用）
            # 与当日额度计数随事件回放，副本读侧状态与主库一致。
            business_ref = payload["business_ref"]
            if business_ref != transfer_id:
                self._conn.execute(
                    "INSERT OR IGNORE INTO idempotency_keys "
                    "(tenant_id, idempotency_key, params_digest, transfer_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (
                        tenant_id,
                        business_ref,
                        payload.get("params_digest") or "",
                        transfer_id,
                        created_at,
                    ),
                )
            day = payload.get("day")
            if day and status == "settled" and payload.get("daily_cap_applied"):
                usage = self._conn.execute(
                    "SELECT total FROM daily_usage WHERE tenant_id = ? AND day = ?",
                    (tenant_id, day),
                ).fetchone()
                used = Decimal("0") if usage is None else Decimal(usage["total"])
                self._conn.execute(
                    "INSERT OR REPLACE INTO daily_usage (tenant_id, day, total) VALUES (?, ?, ?)",
                    (tenant_id, day, format(used + amount, "f")),
                )
            elif day and status == "reversed":
                usage = self._conn.execute(
                    "SELECT total FROM daily_usage WHERE tenant_id = ? AND day = ?",
                    (tenant_id, day),
                ).fetchone()
                if usage is not None:
                    refunded = max(Decimal(usage["total"]) - amount, Decimal("0"))
                    self._conn.execute(
                        "UPDATE daily_usage SET total = ? WHERE tenant_id = ? AND day = ?",
                        (format(refunded, "f"), tenant_id, day),
                    )
        return True
