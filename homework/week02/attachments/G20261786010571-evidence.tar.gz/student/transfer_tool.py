"""账户间转账与冲正工具：在治理运行时上接入的高风险双写目标工具。

接入遵循标准模式：声明参数契约、声明治理策略（含金额分层审批）、
实现业务预检；双账户串行化由运行时按策略声明的账户锁键经锁端口统一完成
（冲正按原单号解析出同一对账户键），余额变更、分录与幂等键落库在
账本存储的同一事务内原子提交。
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from pydantic import Field, field_validator, model_validator

from governance import (
    AccessDecider,
    ApprovalTier,
    GovernedToolRuntime,
    GovernanceViolation,
    HazardLevel,
    OutcomeCode,
    RegisteredTool,
    SessionContext,
    SideEffect,
    StrictToolArgs,
    ToolCallRequest,
    ToolGovernancePolicy,
    request_digest,
)
from storage import AccountLedger, ApprovalLedger, AuditJournal, RateLimiter, SqliteLockManager
from signing import Ed25519GrantSigner, GrantSigner

# 转账策略：写操作、高风险、独立权限、强制审批、金额分层、日累计限额、不自动重试。
# 幂等防重已由账本存储的幂等键落库实现，工具侧仍声明为非幂等以保持重试边界保守。
ToolPolicyTransfer = ToolGovernancePolicy(
    effect=SideEffect.MUTATING,
    risk=HazardLevel.HIGH,
    required_permission="transfer:execute",
    needs_approval=True,
    approval_tiers=(
        ApprovalTier(amount_field="amount", threshold=Decimal("10000"), level="high"),
    ),
    daily_cap_amount_field="amount",
    daily_cap=Decimal("100000"),
    timeout_seconds=2.0,
    retry_budget=0,
    idempotent=False,
)
# 冲正策略：与转账同等安全等级，独立权限、强制审批、金额分层；
# 不声明日累计字段——冲正是资金回退，不消耗额度（事务内还会回补当日额度）。
ToolPolicyReverse = ToolGovernancePolicy(
    effect=SideEffect.MUTATING,
    risk=HazardLevel.HIGH,
    required_permission="transfer:reverse",
    needs_approval=True,
    approval_tiers=(
        ApprovalTier(amount_field="amount", threshold=Decimal("10000"), level="high"),
    ),
    timeout_seconds=2.0,
    retry_budget=0,
    idempotent=False,
)
ToolPolicyBalance = ToolGovernancePolicy(
    effect=SideEffect.READ_ONLY,
    risk=HazardLevel.LOW,
    required_permission="account:read",
    timeout_seconds=1.0,
    retry_budget=2,
    idempotent=True,
)

ACCOUNT_ID_PATTERN = r"^acc_[0-9]{4}$"
TRANSFER_ID_PATTERN = r"^trf_[0-9]{6}$"
ACTIVE = "active"


class TransferInstruction(StrictToolArgs):
    """转账参数契约：格式受限的账号、精确到分的金额与转账备注。"""

    from_account: str = Field(pattern=ACCOUNT_ID_PATTERN)
    to_account: str = Field(pattern=ACCOUNT_ID_PATTERN)
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    remark: str = Field(min_length=4, max_length=200)

    @field_validator("remark")
    @classmethod
    def _remark_no_control_chars(cls, value: str) -> str:
        if any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
            raise ValueError("备注不能包含控制字符")
        return value

    @model_validator(mode="after")
    def _accounts_must_differ(self) -> "TransferInstruction":
        if self.from_account == self.to_account:
            raise ValueError("出账与入账账户不能相同")
        return self


class BalanceQuery(StrictToolArgs):
    """余额查询参数契约：仅接受格式受限的账号。"""

    account: str = Field(pattern=ACCOUNT_ID_PATTERN)


class ReverseInstruction(StrictToolArgs):
    """冲正参数契约：原转账单号、与审批绑定的声明金额与备注。

    声明金额必须与原转账金额一致（存储层锁内校验），审批分层按声明金额计算，
    因此凭证层级与实际冲正金额强绑定。
    """

    original_transfer_id: str = Field(pattern=TRANSFER_ID_PATTERN)
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    remark: str = Field(min_length=4, max_length=200)

    @field_validator("remark")
    @classmethod
    def _remark_no_control_chars(cls, value: str) -> str:
        if any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
            raise ValueError("备注不能包含控制字符")
        return value


def _require_usable(ledger: AccountLedger, tenant_id: str, account: str, label: str) -> dict[str, Any]:
    entry = ledger.entry(tenant_id, account)
    if entry is None:
        raise GovernanceViolation(OutcomeCode.BUSINESS_RULE_DENIED, f"{label}账户不存在: {account}")
    if entry["status"] != ACTIVE:
        raise GovernanceViolation(
            OutcomeCode.BUSINESS_RULE_DENIED, f"{label}账户当前状态不可用: {account}"
        )
    return entry


def make_transfer_precheck(ledger: AccountLedger):
    """门禁阶段预检：账户存在、状态正常、余额充足（锁外初步校验）。

    预检只会在审批凭证校验通过之后执行，未授权调用方得不到任何账户细节。
    """

    async def precheck(args: StrictToolArgs, ctx: SessionContext) -> None:
        assert isinstance(args, TransferInstruction)
        # 幂等重放跳过业务预检：重放不得因当前余额或账户状态变化而失败，
        # 由事务内幂等分支返回原结果。
        if ledger.idempotent_transfer(ctx.tenant_id, ctx.idempotency_key) is not None:
            return
        source = _require_usable(ledger, ctx.tenant_id, args.from_account, "出账")
        _require_usable(ledger, ctx.tenant_id, args.to_account, "入账")
        if args.amount > source["balance"]:
            raise GovernanceViolation(
                OutcomeCode.BUSINESS_RULE_DENIED, "转账金额超过出账账户余额"
            )

    return precheck


def make_transfer_action(ledger: AccountLedger):
    """转账处理器：串行化由运行时按策略声明的账户锁键统一保证。"""

    async def action(args: StrictToolArgs, ctx: SessionContext) -> dict[str, Any]:
        assert isinstance(args, TransferInstruction)
        # 单事务：幂等判定、锁内二次校验、日累计、余额变更、分录与流水原子完成。
        return ledger.apply_transfer(
            ctx.tenant_id,
            args.from_account,
            args.to_account,
            args.amount,
            ctx.idempotency_key,
            request_digest("execute_transfer", args),
            daily_cap=ToolPolicyTransfer.daily_cap,
        )

    return action


def make_reverse_precheck(ledger: AccountLedger):
    """门禁阶段预检：原转账存在、同租户、声明金额不超过未冲正余额。

    预检只会在审批凭证校验通过之后执行，未授权调用方不能探测任意单号；
    余额类业务细节留到锁内事务二次校验。
    """

    async def precheck(args: StrictToolArgs, ctx: SessionContext) -> None:
        assert isinstance(args, ReverseInstruction)
        # 幂等重放跳过业务预检：重放不得因「已冲正」等状态变化而失败，
        # 由事务内幂等分支返回原结果。
        if ledger.idempotent_transfer(ctx.tenant_id, ctx.idempotency_key) is not None:
            return
        original = ledger.get_transfer(ctx.tenant_id, args.original_transfer_id)
        if original is None or original["status"] != "settled":
            raise GovernanceViolation(OutcomeCode.BUSINESS_RULE_DENIED, "原转账不存在或不可冲正")
        remaining = Decimal(original["amount"]) - ledger.reversed_total(
            ctx.tenant_id, args.original_transfer_id
        )
        if remaining <= 0:
            raise GovernanceViolation(OutcomeCode.BUSINESS_RULE_DENIED, "该转账已全部冲正")
        if args.amount > remaining:
            raise GovernanceViolation(
                OutcomeCode.BUSINESS_RULE_DENIED, "冲正金额超过原转账未冲正余额"
            )

    return precheck


def make_reverse_action(ledger: AccountLedger):
    """冲正处理器：串行化由运行时按原账户对锁键统一保证。"""

    async def action(args: StrictToolArgs, ctx: SessionContext) -> dict[str, Any]:
        assert isinstance(args, ReverseInstruction)
        # 单事务：幂等判定、原单校验、余额原路变更、反向分录、流水与额度回补原子完成。
        return ledger.apply_reversal(
            ctx.tenant_id,
            args.original_transfer_id,
            args.amount,
            ctx.idempotency_key,
            request_digest("reverse_transfer", args),
        )

    return action


def make_reverse_lock_keys(ledger: AccountLedger):
    """冲正锁键：按原单号解析出原账户对，与转账共用同一套账户锁。"""

    def lock_keys(args: StrictToolArgs, ctx: SessionContext) -> list[str]:
        assert isinstance(args, ReverseInstruction)
        original = ledger.get_transfer(ctx.tenant_id, args.original_transfer_id)
        if original is None:
            raise GovernanceViolation(OutcomeCode.BUSINESS_RULE_DENIED, "原转账不存在")
        return [
            f"{ctx.tenant_id}:account:{original['from_account']}",
            f"{ctx.tenant_id}:account:{original['to_account']}",
        ]

    return lock_keys


def make_balance_action(ledger: AccountLedger):
    """余额查询处理器：读取租户隔离的账户余额。"""

    async def action(args: StrictToolArgs, ctx: SessionContext) -> dict[str, Any]:
        assert isinstance(args, BalanceQuery)
        entry = _require_usable(ledger, ctx.tenant_id, args.account, "查询")
        return {
            "account": args.account,
            "balance": str(entry["balance"]),
            "status": str(entry["status"]),
            "session_token": "do-not-leak",
        }

    return action


@dataclass
class TransferSystem:
    """组合根产物：暴露运行时、审批、审计与账本，供测试与演示装配使用。"""

    runtime: GovernedToolRuntime
    approvals: ApprovalLedger
    audit: AuditJournal
    ledger: AccountLedger

    def register_approver(self, approver_id: str, tenant_id: str, max_level: str = "high") -> None:
        """注册可裁决审批人：授权按（租户, 最高可批层级）粒度生效。"""
        self.approvals.register_authority(approver_id, tenant_id, max_level)

    def deactivate_approver(self, approver_id: str, tenant_id: str) -> None:
        """停用审批人：该租户内不再具备裁决资格。"""
        self.approvals.deactivate_authority(approver_id, tenant_id)

    async def request_approval(
        self,
        grant_id: str,
        *,
        user_id: str,
        tenant_id: str,
        args: TransferInstruction | ReverseInstruction,
        tool_name: str = "execute_transfer",
        ttl_seconds: int = 300,
        requested_by: str | None = None,
    ) -> None:
        """提交待审批凭证（pending），并落提交审计。"""
        level = _policy_for(tool_name).required_approval_level(args)
        kid = self.approvals.request(
            grant_id,
            user_id=user_id,
            tenant_id=tenant_id,
            tool_name=tool_name,
            args=args,
            level=level,
            ttl_seconds=ttl_seconds,
            requested_by=requested_by,
        )
        await self.audit.write(
            {
                "event": "approval_requested",
                "grant_id": grant_id,
                "requested_by": requested_by or user_id,
                "user_id": user_id,
                "tenant_id": tenant_id,
                "tool_name": tool_name,
                "digest": request_digest(tool_name, args, level=level),
                "level": level,
                "ttl_seconds": ttl_seconds,
                "kid": kid,
            }
        )

    async def decide_approval(
        self,
        grant_id: str,
        *,
        decision: str,
        decided_by: str,
        reason: str,
    ) -> None:
        """审批流转：批准或撤销一笔待审批凭证，并落决策审计。

        批准需裁决人具备该租户的授权层级且与请求人不是同一人（四眼原则），
        未授权裁决被拒绝并落 approval_decision_denied 审计。
        """
        try:
            if decision == "approved":
                self.approvals.approve(grant_id, decided_by=decided_by, reason=reason)
                event = "approval_approved"
            elif decision == "revoked":
                self.approvals.revoke(grant_id, decided_by=decided_by, reason=reason)
                event = "approval_revoked"
            else:
                raise ValueError(f"未知审批决策: {decision}")
        except GovernanceViolation as exc:
            await self.audit.write(
                {
                    "event": "approval_decision_denied",
                    "grant_id": grant_id,
                    "decided_by": decided_by,
                    "reason": reason,
                    "error_code": exc.code,
                    "kid": self.approvals.kid_of(grant_id),
                }
            )
            raise
        await self.audit.write(
            {
                "event": event,
                "grant_id": grant_id,
                "decided_by": decided_by,
                "reason": reason,
                "kid": self.approvals.kid_of(grant_id),
            }
        )

    async def issue_approval(
        self,
        grant_id: str,
        *,
        user_id: str,
        tenant_id: str,
        args: TransferInstruction | ReverseInstruction,
        tool_name: str = "execute_transfer",
        ttl_seconds: int = 300,
        issued_by: str | None = None,
    ) -> None:
        """信任编排方专用：直接签发已批准凭证并落签发审计，不经裁决流转。

        该通道不校验审批人授权与四眼原则，仅限服务端受信编排使用；
        人工审批路径必须走 request_approval -> decide_approval。
        """
        level = _policy_for(tool_name).required_approval_level(args)
        kid = self.approvals.issue(
            grant_id,
            user_id=user_id,
            tenant_id=tenant_id,
            tool_name=tool_name,
            args=args,
            level=level,
            ttl_seconds=ttl_seconds,
            issued_by=issued_by,
        )
        await self.audit.write(
            {
                "event": "approval_issued",
                "grant_id": grant_id,
                "issued_by": issued_by or user_id,
                "user_id": user_id,
                "tenant_id": tenant_id,
                "tool_name": tool_name,
                "digest": request_digest(tool_name, args, level=level),
                "level": level,
                "ttl_seconds": ttl_seconds,
                "kid": kid,
            }
        )


def _policy_for(tool_name: str) -> ToolGovernancePolicy:
    if tool_name == "reverse_transfer":
        return ToolPolicyReverse
    if tool_name == "execute_transfer":
        return ToolPolicyTransfer
    raise ValueError(f"未知的审批绑定工具: {tool_name}")


def compose_transfer_system(
    ledger: AccountLedger | None = None,
    locks=None,
    signer: GrantSigner | None = None,
) -> TransferSystem:
    """组合根：注册转账、冲正与余额查询工具，装配共享连接的持久化治理端口。

    锁端口默认为 SQLite 咨询锁实现；传入其他 LockPort 实现（如
    redis_locks.RedisLockManager）即可在多主机部署形态下复用同一运行时。
    签名器默认为本实例新生成的 Ed25519 密钥：多实例共享同一账本库时
    必须注入共享签名器（密钥来自 KMS/密钥文件），否则其他实例签发的
    凭证无法通过本实例验签。
    """
    ledger = ledger if ledger is not None else AccountLedger()
    tools = [
        RegisteredTool(
            name="execute_transfer",
            description="在当前租户的两个账户之间转账，需一次性审批凭证。",
            parameters_model=TransferInstruction,
            policy=ToolPolicyTransfer,
            action=make_transfer_action(ledger),
            lock_keys=lambda args, ctx: [
                f"{ctx.tenant_id}:account:{args.from_account}",
                f"{ctx.tenant_id}:account:{args.to_account}",
            ],
            precheck=make_transfer_precheck(ledger),
        ),
        RegisteredTool(
            name="reverse_transfer",
            description="按原转账单号原路退回（声明金额不超过未冲正余额，可多次部分冲正），需一次性审批凭证。",
            parameters_model=ReverseInstruction,
            policy=ToolPolicyReverse,
            action=make_reverse_action(ledger),
            lock_keys=make_reverse_lock_keys(ledger),
            precheck=make_reverse_precheck(ledger),
        ),
        RegisteredTool(
            name="get_account_balance",
            description="查询当前租户内指定账户的余额与状态。",
            parameters_model=BalanceQuery,
            policy=ToolPolicyBalance,
            action=make_balance_action(ledger),
            target_key=lambda args, ctx: f"{ctx.tenant_id}:balance:{args.account}",
        ),
    ]
    signer = signer if signer is not None else Ed25519GrantSigner.generate()
    approvals = ApprovalLedger(conn=ledger.connection, signer=signer)
    audit = AuditJournal(conn=ledger.connection)
    locks = locks if locks is not None else SqliteLockManager(conn=ledger.connection)
    limits = RateLimiter(conn=ledger.connection)
    runtime = GovernedToolRuntime(tools, AccessDecider(), approvals, audit, locks=locks, limits=limits)
    return TransferSystem(runtime=runtime, approvals=approvals, audit=audit, ledger=ledger)


def seed_default_accounts(ledger: AccountLedger, tenant_id: str = "tenant_a") -> None:
    """演示用示例账本：租户隔离的两活一冻账户。"""
    ledger.open_account(tenant_id, "acc_1001", "1000.00")
    ledger.open_account(tenant_id, "acc_1002", "500.00")
    ledger.open_account(tenant_id, "acc_1003", "100.00", status="frozen")


async def main() -> None:
    """演示入口：无审批被拦 -> 签发审批 -> 转账成功 -> 幂等核对与审计。"""
    ledger = AccountLedger()
    seed_default_accounts(ledger)
    system = compose_transfer_system(ledger)
    ctx = SessionContext(
        trace_id="trace_001",
        user_id="u_100",
        tenant_id="tenant_a",
        permissions=frozenset({
            ("tenant_a", "transfer:execute"),
            ("tenant_a", "transfer:reverse"),
            ("tenant_a", "account:read"),
        }),
        allowed_tools=frozenset({"execute_transfer", "reverse_transfer", "get_account_balance"}),
    )

    blocked = await system.runtime.invoke(
        ToolCallRequest("call_01", "execute_transfer", {
            "from_account": "acc_1001", "to_account": "acc_1002",
            "amount": "300.00", "remark": "货款结算",
        }),
        ctx,
    )
    print(json.dumps({"stage": "无审批", "ok": blocked.ok, "code": blocked.error_code}, ensure_ascii=False))

    args = TransferInstruction.model_validate({
        "from_account": "acc_1001", "to_account": "acc_1002",
        "amount": "300.00", "remark": "货款结算",
    })
    await system.issue_approval("grant_01", user_id=ctx.user_id, tenant_id=ctx.tenant_id, args=args)
    approved_ctx = SessionContext(
        trace_id=ctx.trace_id,
        user_id=ctx.user_id,
        tenant_id=ctx.tenant_id,
        permissions=ctx.permissions,
        allowed_tools=ctx.allowed_tools,
        approval_id="grant_01",
        idempotency_key="biz_20261120_001",
    )
    settled = await system.runtime.invoke(
        ToolCallRequest("call_02", "execute_transfer", {
            "from_account": "acc_1001", "to_account": "acc_1002",
            "amount": "300.00", "remark": "货款结算",
        }),
        approved_ctx,
    )
    print(json.dumps({"stage": "审批后转账", "ok": settled.ok, "content": settled.content}, ensure_ascii=False, default=str))

    matched = ledger.get_transfer_by_business_ref(ctx.tenant_id, "biz_20261120_001")
    print(json.dumps({
        "stage": "余额与幂等核对",
        "acc_1001": str(ledger.balance("tenant_a", "acc_1001")),
        "acc_1002": str(ledger.balance("tenant_a", "acc_1002")),
        "business_ref_matches": bool(matched) and matched["transfer_id"] == settled.content["transfer_id"],
        "audit_records": len(system.audit.records),
    }, ensure_ascii=False))

    print(json.dumps({
        "stage": "复式对账单",
        "acc_1001_statement": ledger.statement("tenant_a", "acc_1001", limit=5),
    }, ensure_ascii=False, default=str))

    system.register_approver("u_admin", ctx.tenant_id, max_level="high")
    flow_args = TransferInstruction.model_validate({
        "from_account": "acc_1002", "to_account": "acc_1001",
        "amount": "100.00", "remark": "流程演示回款",
    })
    await system.request_approval("grant_02", user_id=ctx.user_id, tenant_id=ctx.tenant_id, args=flow_args)
    await system.decide_approval("grant_02", decision="approved", decided_by="u_admin", reason="演示裁决")
    flow_ctx = SessionContext(
        trace_id=ctx.trace_id,
        user_id=ctx.user_id,
        tenant_id=ctx.tenant_id,
        permissions=ctx.permissions,
        allowed_tools=ctx.allowed_tools,
        approval_id="grant_02",
        idempotency_key="biz_20261120_002",
    )
    flowed = await system.runtime.invoke(
        ToolCallRequest("call_03", "execute_transfer", {
            "from_account": "acc_1002", "to_account": "acc_1001",
            "amount": "100.00", "remark": "流程演示回款",
        }),
        flow_ctx,
    )
    print(json.dumps({
        "stage": "审批流转（请求->裁决->核销）",
        "ok": flowed.ok,
        "acc_1001": str(ledger.balance("tenant_a", "acc_1001")),
        "audit_chain_intact": system.audit.verify_chain() is None,
    }, ensure_ascii=False, default=str))

    reversed_args = ReverseInstruction.model_validate({
        "original_transfer_id": settled.content["transfer_id"],
        "amount": "300.00",
        "remark": "冲正演示退回",
    })
    await system.request_approval("grant_03", user_id=ctx.user_id, tenant_id=ctx.tenant_id,
                                  args=reversed_args, tool_name="reverse_transfer")
    await system.decide_approval("grant_03", decision="approved", decided_by="u_admin",
                                 reason="演示冲正裁决")
    reversed_ctx = SessionContext(
        trace_id=ctx.trace_id,
        user_id=ctx.user_id,
        tenant_id=ctx.tenant_id,
        permissions=ctx.permissions,
        allowed_tools=ctx.allowed_tools,
        approval_id="grant_03",
        idempotency_key="biz_20261120_003",
    )
    reversed_outcome = await system.runtime.invoke(
        ToolCallRequest("call_04", "reverse_transfer", reversed_args.model_dump(mode="python")),
        reversed_ctx,
    )
    reconcile = ledger.reconcile_account(ctx.tenant_id, "acc_1001")
    print(json.dumps({
        "stage": "冲正（审批后原路退回）",
        "ok": reversed_outcome.ok,
        "reversal_status": reversed_outcome.content.get("status") if reversed_outcome.ok else None,
        "acc_1001": str(ledger.balance("tenant_a", "acc_1001")),
        "acc_1002": str(ledger.balance("tenant_a", "acc_1002")),
        "reconcile_consistent": reconcile["consistent"],
        "audit_chain_intact": system.audit.verify_chain() is None,
        "outbox_events": len(ledger.outbox_events()),
    }, ensure_ascii=False, default=str))


if __name__ == "__main__":
    asyncio.run(main())
