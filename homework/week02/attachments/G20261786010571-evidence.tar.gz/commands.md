# 复现命令与退出码

所有命令在 Linux orb 实际执行，未调用模型、外部转账或平台写接口。
工作基目录 B=/home/user/workspace/repo/.amp/in/orb-backup/19536。

| 工作目录 | 命令 | 退出码 | 证据 |
| --- | --- | ---: | --- |
| 课程根目录 | `git clone https://gitee.com/libuzuan/governed-transfer-tool .amp/in/orb-backup/19536/student` | 0 | clone.log |
| 课程根目录 | `python -m venv .amp/in/orb-backup/19536/venv` | 0 | 环境建立成功 |
| 课程根目录 | `.amp/in/orb-backup/19536/venv/bin/pip install -r .amp/in/orb-backup/19536/student/requirements.txt` | 0 | logs/install.log |
| B/student | `PYTHONPATH="$PWD" ../venv/bin/python -m pytest ../trusted/test_tool_governance.py -v -k transfer` | 2 | logs/trusted-tests.log |
| B/student | `../venv/bin/python -m pytest -q` | 0 | logs/student-tests.log |
| B/student | `../venv/bin/python transfer_tool.py` | 0 | logs/offline-demo.log |
| B | `venv/bin/python supplement.py > logs/supplement.jsonl 2> logs/supplement-stderr.log` | 0 | logs/supplement.jsonl |
| B | `venv/bin/python -m pip freeze` | 0 | logs/dependency-versions.txt |

可信测试与课程附件 SHA256 均为
6288fb2c25fad9e0b09d341f449b4ce2c9297aa7469901dff123306ff92f33e2。
可信 conftest 原样复制，仅提供测试路径，不创建同名实现、不用课程练习冒充学员实现。
`supplement.py` 是只读评测驱动，使用学员原生类名、工具名和参数格式；不是原测适配器。
其退出码 0 只表示观察脚本完整运行，不表示 A01–A10 符合题目。
每个业务观察独立新建内存 SQLite、Runtime、审批与审计；A10 参数绑定及重放序列有意复用一次审批。
补测开户属于隔离测试数据，不是修改学员源码，也不冒充学员预设账户。

包解开后把 student、trusted、supplement.py 放在同级目录，按 requirements.txt 新建 venv，重复以上相对命令。
依赖包与 venv 未打包；完整安装版本见 dependency-versions.txt。
