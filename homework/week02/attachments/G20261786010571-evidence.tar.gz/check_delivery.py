"""Validate report arithmetic, measured claims, trusted hashes and bundle safety."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

base = Path(__file__).resolve().parent
repo = base.parents[3]
delivery = repo / '.amp/in/week-grading'
stem = 'G20261786010571-19536'
feedback = (delivery / (stem+'-feedback.md')).read_text()
evaluation = (delivery / (stem+'-evaluation.md')).read_text()
rows = re.findall(r'^\| (?:任务\d [^|]+|治理链路与验收展示) \| (\d+)/(\d+) \|', evaluation, re.M)
assert len(rows) == 7, rows
assert [int(n) for n,d in rows] == [0,4,7,9,11,4,1]
assert sum(int(n) for n,d in rows) == 36
assert sum(int(d) for n,d in rows) == 100
assert '暂评36分' in feedback and '不及格' in feedback
assert '暂评36/100' in evaluation
for number in ['2','3','4']:
    section = feedback.split('**'+number+'. ')[1].split('**',1)[1].split('\n**',1)[0]
    items = re.findall(r'^- ',section,re.M)
    assert len(items) == 4
    assert len(section) <= 500
    assert not re.search('扣分|评分标准|分值',section)
    print('Feedback section',number,'characters',len(section),'items',len(items))
observations = {r['case']:r for r in map(json.loads,(base/'logs/supplement.jsonl').read_text().splitlines())}
assert observations['environment']['requested_module_spec'] == 'None'
assert observations['A03_approved_60000.00']['after'][:2] == ['40000.00','65000.00']
assert observations['A03_approved_90000.00']['result']['ok'] is True
assert observations['A03_approved_90000.00']['elapsed'] < 3
assert observations['A05_exact_balance']['after'] == ['100000.00','25000.00','0.00','50000.00']
for case in ['A06_missing_target','A07_cross_source','A07_cross_target']:
    assert observations[case]['before'] == observations[case]['after']
assert observations['A09_recursive']['actual']['from'] == 'ACC-A-123456'
assert observations['A10_tamper_amount']['result']['error_code'] == 'APPROVAL_REQUIRED'
assert observations['A10_replay']['result']['error_code'] == 'APPROVAL_REQUIRED'
assert observations['A10_success']['result']['ok'] is True
trusted = base/'trusted/test_tool_governance.py'
assert trusted.read_bytes() == (repo/'hw-guide/week02/hw2/test_tool_governance.py').read_bytes()
assert not subprocess.check_output(['git','-C',str(base/'student'),'status','--porcelain']).strip()
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain']).strip()
print('Score, grade, measured claims, trusted assertions, source integrity: OK')
archive = delivery/(stem+'-evidence.tar.gz')
if archive.exists():
    with tarfile.open(archive) as bundle:
        files = [p for p in bundle.getnames() if bundle.getmember(p).isfile()]
        assert not any(re.search(r'(^|/)(venv|\.venv|\.git|site-packages|__pycache__|node_modules)(/|$)',p) for p in files)
        assert not any(p.endswith(('.pem','.key','.db','.sqlite','.pyc')) for p in files)
        assert any(p.endswith('student/transfer_tool.py') for p in files)
        assert any(p.endswith('trusted/test_tool_governance.py') for p in files)
        assert any(p.endswith(stem+'-evaluation.md') for p in files)
        for suffix in ['feedback.md','evaluation.md']:
            name = stem+'-'+suffix
            member = next(p for p in files if p.endswith('/'+name))
            assert bundle.extractfile(member).read() == (delivery/name).read_bytes()
        member = next(p for p in files if p.endswith('/check_delivery.py'))
        assert bundle.extractfile(member).read() == Path(__file__).read_bytes()
        print('Bundle inclusion/exclusion: OK;',len(files),'files')
print('VALIDATION_EXIT_CODE=0')
