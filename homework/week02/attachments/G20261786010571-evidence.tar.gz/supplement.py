"""Read-only evaluator: native-interface observations, never an adapter for trusted tests."""
import asyncio
import ast
import dataclasses
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time
from decimal import Decimal

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'student'))
import governance as g
import transfer_tool as t
import storage as s
import pydantic
import pytest

def emit(label, **data):
    print(json.dumps({'case': label, **data}, ensure_ascii=False, default=str))

def fresh():
    ledger = s.AccountLedger()
    for tenant, account, balance in [
        ('tenant_a', 'acc_1001', '100000.00'),
        ('tenant_a', 'acc_1002', '5000.00'),
        ('tenant_a', 'acc_1003', '20000.00'),
        ('tenant_b', 'acc_1004', '50000.00'),
    ]:
        ledger.open_account(tenant, account, balance)
    system = t.compose_transfer_system(ledger)
    ctx = g.SessionContext('trace_eval', 'u_eval', 'tenant_a',
        frozenset({('tenant_a', 'transfer:execute'), ('tenant_a', 'account:read')}),
        frozenset({'execute_transfer', 'get_account_balance', 'transfer'}))
    return system, ctx

def args(amount='100.00', **kw):
    return dict(from_account='acc_1001', to_account='acc_1002', amount=amount, remark='离线补测', **kw)

def balances(system):
    return [str(system.ledger.balance(tenant, account)) for tenant, account in [
        ('tenant_a', 'acc_1001'), ('tenant_a', 'acc_1002'),
        ('tenant_a', 'acc_1003'), ('tenant_b', 'acc_1004')]]

async def invoke(label, arguments, approved=False, **ctx_changes):
    system, ctx = fresh()
    ctx = dataclasses.replace(ctx, **ctx_changes)
    before = balances(system)
    if approved:
        model = t.TransferInstruction.model_validate(arguments)
        await system.issue_approval('eval_grant', user_id=ctx.user_id, tenant_id=ctx.tenant_id, args=model)
        ctx = dataclasses.replace(ctx, approval_id='eval_grant')
    started = time.perf_counter()
    result = await system.runtime.invoke(g.ToolCallRequest('call_eval_000003', 'execute_transfer', arguments), ctx)
    emit(label, arguments=arguments, approved=approved, result=dataclasses.asdict(result),
         elapsed=round(time.perf_counter()-started, 6), before=before, after=balances(system),
         audit=system.audit.records)
    return result

async def main():
    emit('environment', python=platform.python_version(), pydantic=pydantic.__version__, pytest=pytest.__version__,
         module_paths={m.__name__: m.__file__ for m in [t,g,s]},
         requested_module_spec=str(importlib.util.find_spec('tool_governance_demo')))
    system, ctx = fresh()
    emit('A01', ACCOUNTS_present=hasattr(t,'ACCOUNTS'), default_ledger_snapshot=t.compose_transfer_system().ledger.export_snapshot(),
         note='Evaluator fixture is not claimed as student default data')
    emit('A08', visible_tools=system.runtime.visible_tools(ctx), policy=dataclasses.asdict(t.ToolPolicyTransfer))
    result = await system.runtime.invoke(g.ToolCallRequest('call_orig_name', 'transfer',
        {'from_account':'ACC-A-123456','to_account':'ACC-A-654321','amount':100.0}), ctx)
    emit('A08_original_tool_name', result=dataclasses.asdict(result))
    await invoke('A02_original_three_fields', {'from_account':'ACC-A-123456','to_account':'ACC-A-654321','amount':100.0})
    valid = args()
    for field in ['from_account','to_account','amount','remark']:
        await invoke('A02_missing_'+field, {k:v for k,v in valid.items() if k != field})
    for field in ['approved','user_id']:
        await invoke('A02_extra_'+field, {**valid,field:True})
    for key, value in [('amount','-1.00'),('amount','0.00'),('amount','100.00'),('amount','100000.01'),
                       ('from_account','ACC-A-123456'),('to_account','bad')]:
        await invoke('A02_schema_'+key+'_'+value,{**valid,key:value})
    for amount in ['50000.00','50000.01','80000.00','80000.01','100000.00','100000.01']:
        await invoke('A03_pending_'+amount,args(amount))
    for amount in ['50000.01','60000.00','80000.01','90000.00','100000.00']:
        await invoke('A03_approved_'+amount,args(amount),True)
    for amount in ['30000.00','60000.00']:
        await invoke('A04_pending_'+amount,{**args(amount),'from_account':'acc_1003'})
        await invoke('A04_approved_'+amount,{**args(amount),'from_account':'acc_1003'},True)
    await invoke('A05_exact_balance',{**args('20000.00'),'from_account':'acc_1003'},True)
    await invoke('A06_missing_target',{**args(),'to_account':'acc_9999'},True)
    await invoke('A07_cross_source',{**args(),'from_account':'acc_1004'},True)
    await invoke('A07_cross_target',{**args(),'to_account':'acc_1004'},True)
    for overrides in [dict(permissions=frozenset()),dict(allowed_tools=frozenset()),dict(mode=g.GoverningMode.PLAN_ONLY)]:
        await invoke('native_permission_'+str(overrides),args(),True,**overrides)
    payload = {'from':'ACC-A-123456','to':'ACC-A-654321','email':'alice@example.com',
               'nested':[{'token':'synthetic-demo-value','text':'bob@example.com ACC-A-888888'}]}
    emit('A09_recursive', input=payload, actual=g.mask_sensitive(payload))
    await invoke('A09_native_success',args('1200.00'),True)
    source = (ROOT/'student/governance.py').read_text()
    tree = ast.parse(source)
    emit('A10_fixed_engine', PermissionEngine_present=any(isinstance(n,ast.ClassDef) and n.name=='PermissionEngine' for n in tree.body),
         original_method_preserved=False,
         note='Self-developed AccessDecider and GovernedToolRuntime replace fixed framework; no compatibility module exists')
    system,ctx=fresh()
    original=args('1200.00')
    model=t.TransferInstruction.model_validate(original)
    await system.issue_approval('bound',user_id=ctx.user_id,tenant_id=ctx.tenant_id,args=model)
    approved=dataclasses.replace(ctx,approval_id='bound')
    for name,values in [('tamper_amount',{**original,'amount':'1300.00'}),('tamper_target',{**original,'to_account':'acc_1003'}),
                         ('success',original),('replay',original)]:
        result=await system.runtime.invoke(g.ToolCallRequest('binding_'+name,'execute_transfer',values),approved)
        emit('A10_'+name,result=dataclasses.asdict(result),balances=balances(system))
    emit('A10_associated_audit',records=system.audit.records)
    for module in ['transfer_tool.py','governance.py']:
        emit('source_contract', module=module, sleep3_present='sleep(3' in (ROOT/'student'/module).read_text())

asyncio.run(main())
