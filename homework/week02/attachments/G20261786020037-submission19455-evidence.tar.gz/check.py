import ast, asyncio, dataclasses, hashlib, inspect, json, pathlib, platform, sys, time
import pydantic, pytest
import tool_governance_demo as d
ROOT=pathlib.Path(__file__).resolve().parent
base=(ROOT/'baseline/tool_governance_demo-无答案.py').read_text()
student=pathlib.Path(d.__file__).read_text()
def method(text,cls,name):
    tree=ast.parse(text)
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    fn=next(n for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    return '\n'.join(text.splitlines()[fn.lineno-1:fn.end_lineno])
assert method(base,'PermissionEngine','decide')==method(student,'PermissionEngine','decide')
# Compare assertion ASTs, allowing student's fixture output additions only.
def assertions(text):
    return [ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Assert)]
assert assertions((ROOT/'baseline/test_tool_governance.py').read_text())==assertions((ROOT/'source/student_tests.py').read_text())
print(json.dumps({'python':platform.python_version(),'pydantic':pydantic.__version__,'pytest':pytest.__version__,'module':d.__file__,'PermissionEngine.decide':'exact text unchanged','test_assertions':'identical AST','strict':d.TransferArgs.model_config},ensure_ascii=False))
INITIAL={('tenant_a','ACC-A-123456'):100000.0,('tenant_a','ACC-A-654321'):5000.0,('tenant_a','ACC-A-888888'):20000.0,('tenant_b','ACC-B-111111'):50000.0}
F='ACC-A-123456'; T='ACC-A-654321'; S='ACC-A-888888'; B='ACC-B-111111'
assert d.ACCOUNTS==INITIAL and all(type(v) is float for v in d.ACCOUNTS.values())
print('A01 PASS exact initial float dictionary')
def context(**kw):
    return d.base_context(**{'permissions':frozenset({'transfer:execute','order:read','refund:create'}),'allowed_tools':frozenset({'transfer','get_order','create_refund'}),**kw})
def args(amount=100.0,source=F,target=T):return dict(from_account=source,to_account=target,amount=amount)
async def case(label,a,code,approved=False,**kw):
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(INITIAL)
    r,p,u=d.build_runtime(); c=context(**kw)
    if approved:p.approve('a',c,'transfer',a); c=dataclasses.replace(c,approval_id='a')
    started=time.perf_counter(); result=await r.invoke(d.ToolCall('call_tr_000003','transfer',a),c); elapsed=time.perf_counter()-started
    assert result.code==code,(label,result)
    if code!='OK':assert d.ACCOUNTS==INITIAL
    print(json.dumps({'case':label,'result':dataclasses.asdict(result),'elapsed':elapsed,'audit':[dataclasses.asdict(x) for x in u.records],'balances':{str(k):v for k,v in d.ACCOUNTS.items()}},ensure_ascii=False))
    return r,p,u,result
async def main():
    invalid=[{k:v for k,v in args().items() if k!=missing} for missing in args()]
    invalid += [{**args(),key:value} for key,value in [('approved',True),('user_id','admin'),('amount',-1.0),('amount','100.0'),('from_account','ACC-123456'),('to_account','ACC-a-123456'),('to_account',123456)]]
    for i,a in enumerate(invalid):await case(f'A02-{i}',a,'INVALID_ARGUMENT')
    for amount,code in [(50000.,'APPROVAL_REQUIRED'),(50000.01,'EXCEED_LIMIT'),(80000.,'EXCEED_LIMIT'),(80000.01,'APPROVAL_REQUIRED'),(100000.,'APPROVAL_REQUIRED'),(100000.01,'INVALID_ARGUMENT')]:
        _,_,u,x=await case(f'A03-{amount}',args(amount),code)
        assert u.records[-1].phase=='decision'
        assert x.action==('confirm' if code=='APPROVAL_REQUIRED' else 'deny')
    for amount in [80000.01,100000.]:
        _,_,u,x=await case(f'A03-approved-{amount}',args(amount),'TIMEOUT_UNKNOWN',True)
        assert u.records[-1].phase=='execution'
    for amount,code in [(30000.,'INSUFFICIENT_BALANCE'),(60000.,'EXCEED_LIMIT')]:
        a=args(amount,source=S)
        _,_,u,x=await case('A04-unapproved',a,code)
        assert x.action=='deny' and u.records[-1].phase=='decision'
        _,p,u,x=await case('A04-approved',a,code,True)
        assert p._records['a'].used is False
    _,_,_,x=await case('A05-full-balance',args(20000.,source=S),'OK',True)
    assert d.ACCOUNTS[('tenant_a',S)]==0. and d.ACCOUNTS[('tenant_a',T)]==25000.
    assert x.content['txn_id']=='000003' and x.content['status']=='accepted' and x.content['amount']==20000.
    _,_,_,x=await case('A06-missing-target',args(target='ACC-A-999999'),'ACCOUNT_NOT_FOUND',True)
    assert x.content=='转入账户不存在'
    await case('A07-foreign-source',args(source=B),'INSUFFICIENT_BALANCE')
    _,_,_,x=await case('A07-foreign-target',args(target=B),'ACCOUNT_NOT_FOUND',True)
    assert x.content=='转入账户不存在'
    tool=next(t for t in d.build_tools() if t.name=='transfer')
    assert tool.parameters_model is d.TransferArgs and tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert tool.policy.effect is d.Effect.WRITE and tool.policy.permission=='transfer:execute'
    assert tool.policy.requires_approval or tool.policy.risk is d.Risk.HIGH
    assert 0<tool.policy.timeout_seconds<3 and not tool.policy.idempotent and tool.policy.max_retries==0
    targets=[tool.canonical_target(d.TransferArgs(**a)) for a in [args(),args(source=S),args(target=S),args(101.)]]
    assert len(set(targets))==4
    assert inspect.iscoroutinefunction(d.transfer_precheck)
    handler=inspect.getsource(d.transfer_handler)
    assert handler.index('await asyncio.sleep(3.0)') < handler.index(' -= ')
    print('A08 PASS',dataclasses.asdict(tool.policy),targets)
    _,_,_,x=await case('A09-masked-result',args(),'OK',True)
    assert x.content['from']=='ACC-A-****3456' and x.content['to']=='ACC-A-****4321'
    nested={'nested':[{'email':'alice@example.com','secret':'demo','account':B}], 'password':'demo'}
    assert d._redact(nested)=={'nested':[{'email':'***@***','secret':'***','account':'ACC-B-****1111'}],'password':'***'}
    r,_,_=d.build_runtime(); x=await r.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),context())
    assert x.ok and x.content['customer_email']=='***@***' and x.content['access_token']=='***'
    print('A09 PASS nested redaction and original order regression')
    # A10: submitted demonstration is executed separately; teacher output above is not submitted evidence.
    print('A10 PASS fixed engine, valid original assertions, runtime-only business calls; see submitted logs for presentation')
    # Added note only: free-text account embedding is outside current output fields.
    print('NON-SCORING NOTE free-text redaction:',d._redact('转账 ACC-A-123456 已完成'))
    d.ACCOUNTS.clear();d.ACCOUNTS.update(INITIAL)
asyncio.run(main())
print('ALL SUPPLEMENTAL ASSERTIONS PASSED')
