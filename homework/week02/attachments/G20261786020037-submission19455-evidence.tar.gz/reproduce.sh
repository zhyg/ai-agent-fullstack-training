#!/usr/bin/env bash
# Run from an extracted evidence directory; python must provide pinned dependencies below.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="$ROOT/source"
PY="${PYTHON:-python}"
run() { printf '\nCOMMAND:'; printf ' %q' "$@"; printf '\n'; "$@"; rc=$?; echo "EXIT_CODE=$rc"; return "$rc"; }
run "$PY" -c 'import sys,pydantic,pytest,tool_governance_demo as d; print(sys.version); print(pydantic.__version__,pytest.__version__,d.__file__)'
run "$PY" -m pytest "$ROOT/baseline/test_tool_governance.py" -v -k transfer
run "$PY" -m pytest "$ROOT/source/student_tests.py" -v -s -k transfer
run "$PY" "$ROOT/check.py"
run "$PY" "$ROOT/source/tool_governance_demo.py"
