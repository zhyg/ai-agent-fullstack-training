# G20261786020088 / 提交19466 / week02证据

结论：94分，优秀；验收标签未通过。业务五测及 A01–A09 通过；固定方法只发生格式化改写（AST一致），以及缺转账打印展示，各扣3分。详细依据见同包 evaluation 文件。

本包只有目标目录源码、可信题目附件、教师补测、元数据和日志，不含虚拟环境、真实凭据或 git 数据库。`student/` 为提交 `6b160ac16b5a4648fecced634ce2c22249c312d8` 的目标目录，不代表全仓库。

## 解包后复现

在本 README 所在目录执行。需 Python 3.11 或更新版本；建议按原评测版本创建环境。

```bash
python -m venv .venv
.venv/bin/python -m pip install 'pydantic==2.14.3' 'pytest==9.2.0'
sha256sum -c SHA256SUMS
PYTHONPATH="$PWD/student" .venv/bin/python -c 'import tool_governance_demo as d; print(d.__file__)'
PYTHONPATH="$PWD/student" .venv/bin/python -m pytest trusted/test_tool_governance.py -v -s -k transfer -p no:cacheprovider
PYTHONPATH="$PWD/student" .venv/bin/python -m pytest supplement/test_additional.py -v -s -p no:cacheprovider
.venv/bin/python student/tool_governance_demo.py
```

预期：可信五测退出0；补测11项中9项通过，A10固定原文与展示两项失败，退出1；CLI退出0但无转账打印展示。不得删除失败断言来制造全绿。`run_evaluation.py` 是本次真实运行的历史驱动，使用其所在 orb 的原始目录布局；便携复验请使用上面命令。

最小复现可在补测命令后加 `-k fixed_permission` 或 `-k submission_display`（各退出1）。所有业务操作都通过 Runtime；模型、注册元数据及脱敏函数的静态/纯函数核查不属于业务绕过。

`logs/supplement-initial.log` 保留教师初次补测的一个错误预期：满额转出后重放应先被余额预检拒绝，而非再次 confirm。最终脚本已纠正此项，最终结果见 `logs/supplement.log`，不以初始教师误报扣学生分。可信原始测试和学生源码在整个评测期间未变。

`logs/metadata.log` 记录真实绝对导入路径；`manifest.json` 记录完整命令及退出码；包内 SHA256SUMS 不包含自身。测试日志内的账号及 token 字面量均来自题目内存模拟，不是真实凭据。
