"""复现驱动：固定导入目录、记录命令与退出码，不修改学生文件或可信测试。"""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
E = ROOT / 'evidence'
STUDENT = ROOT / 'student/02Function Calling、Tool Runtime与MCP/Post-class exercises'
env = {**os.environ, 'PYTHONPATH': str(STUDENT), 'PYTHONDONTWRITEBYTECODE': '1'}
commands = [
    ('metadata', [sys.executable, '-c', 'import sys,pydantic,pytest,tool_governance_demo as d; print("Python",sys.version); print("Pydantic",pydantic.__version__); print("pytest",pytest.__version__); print("module",d.__file__)']),
    ('original-five', [sys.executable, '-m', 'pytest', str(E / 'trusted/test_tool_governance.py'), '-v', '-s', '-k', 'transfer', '-p', 'no:cacheprovider']),
    ('supplement', [sys.executable, '-m', 'pytest', str(E / 'supplement/test_additional.py'), '-v', '-s', '-p', 'no:cacheprovider']),
    ('student-five', [sys.executable, '-m', 'pytest', 'tests/test_tool_governance.py', '-v', '-s', '-k', 'transfer', '-p', 'no:cacheprovider']),
    ('offline-demo', [sys.executable, 'tool_governance_demo.py']),
]
manifest = {'repository': 'https://github.com/BboyXing/AI-Agent', 'branch': 'main',
            'commit': subprocess.check_output(['git', '-C', str(ROOT / 'student'), 'rev-parse', 'HEAD'], text=True).strip(),
            'source_directory': str(STUDENT), 'commands': []}
for label, command in commands:
    print('RUN', label, flush=True)
    result = subprocess.run(command, cwd=STUDENT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (E / f'logs/{label}.log').write_text('COMMAND: ' + json.dumps(command, ensure_ascii=False) + '\nCWD: ' + str(STUDENT) + '\nPYTHONPATH: ' + str(STUDENT) + '\n' + result.stdout + f'\nEXIT_CODE: {result.returncode}\n')
    manifest['commands'].append({'label': label, 'argv': command, 'exit_code': result.returncode})
    print(label, 'EXIT_CODE', result.returncode, result.stdout[-1200:], flush=True)
(E / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
