"""教师补测；所有业务调用只经 Runtime，逐例重建治理容器并还原余额。"""
import ast
import asyncio
import contextlib
import inspect
import io
import json
import time
from dataclasses import asdict, replace
from pathlib import Path

import pytest
import tool_governance_demo as d

F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
VALID = dict(from_account=F, to_account=T, amount=1200.0)
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}


@pytest.fixture(autouse=True)
def isolate():
    before = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(before)


def context(**kw):
    return d.base_context(**dict(permissions=frozenset({'order:read', 'refund:create', 'shell:run', 'transfer:execute'}),
                                allowed_tools=frozenset({'get_order', 'create_refund', 'run_shell', 'transfer'}), **kw))


async def invoke(runtime, args, ctx=None, call='teacher_000003'):
    result = await runtime.invoke(d.ToolCall(call, 'transfer', args), ctx or context())
    print(json.dumps(asdict(result), ensure_ascii=False, default=str))
    return result


def audit_pairs(audit):
    print('AUDIT', json.dumps([asdict(r) for r in audit.records], ensure_ascii=False, default=str))
    return [(r.phase, r.code) for r in audit.records]


def test_A01_initial_accounts():
    print('INITIAL', d.ACCOUNTS)
    assert d.ACCOUNTS == INITIAL
    assert all(type(v) is float for v in d.ACCOUNTS.values())


def test_A02_strict_arguments():
    async def run():
        variants = [{k: v for k, v in VALID.items() if k != field} for field in VALID]
        variants += [{**VALID, 'approved': True}, {**VALID, 'user_id': 'admin'}]
        variants += [{**VALID, 'amount': v} for v in [-1.0, '1200', True, 0.0, 100000.01]]
        variants += [{**VALID, field: v} for field in ['from_account', 'to_account']
                     for v in ['ACC-123456', 'ACC-a-123456', 'ACC-A-1234567', 123456]]
        for args in variants:
            runtime, approvals, audit = d.build_runtime()
            r = await invoke(runtime, args)
            assert r.code == 'INVALID_ARGUMENT' and r.action == d.DecisionAction.DENY
            assert audit_pairs(audit) == [('decision', 'INVALID_ARGUMENT')]
            assert d.ACCOUNTS == INITIAL
        assert issubclass(d.TransferArgs, d.StrictArgs)
        assert d.TransferArgs.model_config['extra'] == 'forbid'
        assert d.TransferArgs.model_config['strict'] is True
    asyncio.run(run())


def test_A03_exact_boundaries_and_real_timeout():
    async def run():
        for amount, code, action in [(50000.0, 'APPROVAL_REQUIRED', 'confirm'),
                                     (50000.01, 'EXCEED_LIMIT', 'deny'),
                                     (80000.0, 'EXCEED_LIMIT', 'deny'),
                                     (80000.01, 'APPROVAL_REQUIRED', 'confirm'),
                                     (100000.0, 'APPROVAL_REQUIRED', 'confirm'),
                                     (100000.01, 'INVALID_ARGUMENT', 'deny')]:
            runtime, approvals, audit = d.build_runtime()
            r = await invoke(runtime, {**VALID, 'amount': amount})
            assert (r.code, r.action.value) == (code, action)
            assert audit_pairs(audit) == [('decision', code)]
            assert d.ACCOUNTS == INITIAL
        for amount in [80000.01, 100000.0]:
            runtime, approvals, audit = d.build_runtime()
            args = {**VALID, 'amount': amount}
            approvals.approve('approval', context(), 'transfer', args)
            started = time.perf_counter()
            r = await invoke(runtime, args, context(approval_id='approval'))
            elapsed = time.perf_counter() - started
            print('TIMEOUT_SECONDS', amount, elapsed)
            assert r.code == 'TIMEOUT_UNKNOWN' and 1.8 < elapsed < 3.0
            assert d.ACCOUNTS == INITIAL
            assert audit_pairs(audit) == [('decision', 'APPROVED'), ('execution', 'TIMEOUT_UNKNOWN')]
            replay = await invoke(runtime, args, context(approval_id='approval'))
            assert replay.action == d.DecisionAction.CONFIRM
    asyncio.run(run())


def test_A04_precheck_order_readonly_and_approval_not_consumed():
    async def run():
        for amount, code in [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')]:
            args = {**VALID, 'from_account': S, 'amount': amount}
            runtime, approvals, audit = d.build_runtime()
            r = await invoke(runtime, args)
            assert (r.action, r.code) == (d.DecisionAction.DENY, code)
            assert audit_pairs(audit) == [('decision', code)]
            approvals.approve('untouched', context(), 'transfer', args)
            r = await invoke(runtime, args, context(approval_id='untouched'))
            assert r.code == code and not approvals._records['untouched'].used
            assert d.ACCOUNTS == INITIAL
        assert inspect.iscoroutinefunction(d.transfer_precheck)
    asyncio.run(run())


def test_A05_full_balance_and_success_audit_replay():
    async def run():
        args = {**VALID, 'from_account': S, 'amount': 20000.0}
        runtime, approvals, audit = d.build_runtime()
        assert (await invoke(runtime, args)).action == d.DecisionAction.CONFIRM
        approvals.approve('full', context(), 'transfer', args)
        r = await invoke(runtime, args, context(approval_id='full'))
        assert r.ok and r.content == {'txn_id': '000003', 'from': 'ACC-A-****8888',
                                     'to': 'ACC-A-****4321', 'amount': 20000.0, 'status': 'accepted'}
        expected = {**INITIAL, ('tenant_a', S): 0.0, ('tenant_a', T): 25000.0}
        assert d.ACCOUNTS == expected
        assert audit_pairs(audit) == [('decision', 'APPROVAL_REQUIRED'), ('decision', 'APPROVED'), ('execution', 'OK')]
        assert all(r.trace_id == 'trace_demo' and r.tool_call_id == 'teacher_000003' for r in audit.records)
        # 满额转出后余额为零，固定引擎先做余额预检，故重放应被业务拒绝。
        replay = await invoke(runtime, args, context(approval_id='full'))
        assert (replay.action, replay.code) == (d.DecisionAction.DENY, 'INSUFFICIENT_BALANCE')
        assert d.ACCOUNTS == expected
    asyncio.run(run())


def test_A06_missing_destination():
    async def run():
        args = {**VALID, 'to_account': 'ACC-A-999999'}
        runtime, approvals, audit = d.build_runtime()
        approvals.approve('missing', context(), 'transfer', args)
        r = await invoke(runtime, args, context(approval_id='missing'))
        assert (r.code, r.content) == ('ACCOUNT_NOT_FOUND', '转入账户不存在')
        assert d.ACCOUNTS == INITIAL
        assert audit_pairs(audit) == [('decision', 'APPROVED'), ('execution', 'ACCOUNT_NOT_FOUND')]
    asyncio.run(run())


def test_A07_tenant_isolation():
    async def run():
        for tenant, source, destination, code in [('tenant_a', B, T, 'INSUFFICIENT_BALANCE'),
                                                   ('tenant_a', F, B, 'ACCOUNT_NOT_FOUND'),
                                                   ('tenant_b', F, B, 'INSUFFICIENT_BALANCE'),
                                                   ('tenant_b', B, F, 'ACCOUNT_NOT_FOUND')]:
            runtime, approvals, audit = d.build_runtime()
            args = {**VALID, 'from_account': source, 'to_account': destination}
            ctx = context(tenant_id=tenant)
            approvals.approve('tenant', ctx, 'transfer', args)
            r = await invoke(runtime, args, replace(ctx, approval_id='tenant'))
            assert r.code == code and d.ACCOUNTS == INITIAL
    asyncio.run(run())


def test_A08_registration_targets_and_approval_binding():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert (tool.parameters_model, tool.handler, tool.precheck) == (d.TransferArgs, d.transfer_handler, d.transfer_precheck)
    p = tool.policy
    print('POLICY', asdict(p))
    assert p.effect == d.Effect.WRITE and (p.requires_approval or p.risk == d.Risk.HIGH)
    assert p.permission == 'transfer:execute' and 0 < p.timeout_seconds < 3
    assert p.idempotent is False and p.max_retries == 0
    variants = [VALID, {**VALID, 'from_account': S}, {**VALID, 'to_account': S}, {**VALID, 'amount': 1200.01}]
    targets = [tool.canonical_target(d.TransferArgs(**a)) for a in variants]
    print('TARGETS', targets)
    assert len(set(targets)) == 4
    async def run():
        for changed in variants[1:]:
            runtime, approvals, audit = d.build_runtime()
            approvals.approve('bound', context(), 'transfer', VALID)
            r = await invoke(runtime, changed, context(approval_id='bound'))
            assert r.action == d.DecisionAction.CONFIRM and not approvals._records['bound'].used
            assert d.ACCOUNTS == INITIAL
    asyncio.run(run())


def test_A09_redaction_recursive_and_order_regression():
    raw = {'nested': [{'text': 'ACC-A-123456 alice@example.com', 'Authorization': 'fake'},
                      ('ACC-B-111111', {'password': 'fake', 'api_secret': 'fake'})], 'token': 'fake'}
    expected = {'nested': [{'text': 'ACC-A-****3456 ***@***', 'Authorization': '***'},
                           ['ACC-B-****1111', {'password': '***', 'api_secret': '***'}]], 'token': '***'}
    result = d._redact(raw)
    print('RECURSIVE_REDACTION', result)
    assert result == expected and raw['token'] == 'fake'
    async def run():
        runtime, approvals, audit = d.build_runtime()
        r = await runtime.invoke(d.ToolCall('order', 'get_order', {'order_id': 'ord_1001'}), context())
        print('ORDER_RESULT', asdict(r))
        assert r.ok and r.content['customer_email'] == '***@***' and r.content['access_token'] == '***'
    asyncio.run(run())


def test_A10_fixed_permission_engine_and_original_tests():
    trusted = Path(__file__).resolve().parents[1] / 'trusted'
    def method(source):
        tree = ast.parse(source)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
        fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
        return '\n'.join(source.splitlines()[fn.lineno - 1:fn.end_lineno])
    student = Path(d.__file__).read_text()
    original = (trusted / 'tool_governance_demo-无答案.py').read_text()
    submitted_tests = Path(d.__file__).parent / 'tests/test_tool_governance.py'
    assert submitted_tests.read_bytes() == (trusted / 'test_tool_governance.py').read_bytes()
    print('Student tests == trusted tests byte-for-byte; no skip/xfail or direct handler calls')
    import textwrap
    import difflib
    a, b = method(original), method(student)
    same_ast = ast.dump(ast.parse(textwrap.dedent(a))) == ast.dump(ast.parse(textwrap.dedent(b)))
    print('PermissionEngine.decide AST equal:', same_ast)
    print('PermissionEngine.decide exact source equal:', a == b)
    print(''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile='trusted', tofile='student')))
    assert same_ast, '权限引擎逻辑发生变化'
    assert a == b, '固定方法内存在格式化换行改动（AST一致，不是权限逻辑缺陷）'


def test_A10_submission_display():
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        asyncio.run(d.run_offline_demo())
    print('STUDENT_OFFLINE_DEMO\n' + output.getvalue())
    # 展示须来自提交本身；教师补测打印不能替代学员展示。
    rows = [json.loads(line) for line in output.getvalue().splitlines() if line.startswith('{')]
    transfers = [row for row in rows if row.get('tool_name') == 'transfer']
    assert transfers, '提交的离线展示没有 transfer 调用；提交测试也没有打印转账结果和逐条关联审计'
