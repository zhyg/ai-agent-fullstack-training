#!/usr/bin/env bash
# 解压 evidence.tar.gz 后执行。仅离线业务测试，不会请求模型。
# pip 获取第三方依赖需要网络；学生源码和可用SDK源码已随包保留。
set -eu
E=$(realpath "$(dirname "$0")/..")
WORK=${1:?Usage: bash scripts/reproduce.sh /absolute/path/to/new-work-directory}
mkdir -p "$WORK/student" "$WORK/provider-sdk" "$WORK/logs"
WORK=$(realpath "$WORK")
tar -xf "$E/student-source.tar" -C "$WORK/student"
tar -xf "$E/provider-sdk-fallback-source.tar" -C "$WORK/provider-sdk"
python3 -m venv "$WORK/venv"
P="$WORK/venv/bin/python"
# 与现场一致：先安装学生requirements，再将浮动SDK替换为保留的可用提交。
"$P" -m pip install -r "$WORK/student/requirements.txt"
"$P" -m pip install --no-deps "$WORK/provider-sdk"
export PYTHONPATH="$WORK/student"
cd "$WORK/student"
run() {
    local name=$1
    shift
    set +e
    "$@" > "$WORK/logs/$name.log" 2>&1
    local code=$?
    set -e
    printf '%s\n' "$code" > "$WORK/logs/$name.exit"
    printf '%s EXIT_CODE=%s\n' "$name" "$code"
    tail -12 "$WORK/logs/$name.log"
}
run trusted-five "$P" -m pytest "$E/trusted/test_tool_governance.py" -v -k transfer
run student-five-demo "$P" -m pytest tests/test_tool_governance.py -v -s -k transfer
run independent "$P" -m pytest "$E/scripts/test_independent.py" -v -s -o asyncio_mode=auto
run readme-demo "$P" "$E/scripts/readme_example.py"
printf '预期：原测setup errors/exit1；学生五测5passed/exit0；补测33passed7failed/exit1；README/exit0。\n'
