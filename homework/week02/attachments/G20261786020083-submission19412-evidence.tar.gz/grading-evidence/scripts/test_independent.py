"""教师独立补测。仅适配提交的公开接口，不改业务、不修补原测或预期。

运行：PYTHONPATH=<student> <venv>/bin/python -m pytest <this file> -v -s
      -o asyncio_mode=auto
"""
import ast
import asyncio
import difflib
import inspect
import json
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

import pytest
import tool_governance_demo as d
from opentelemetry.sdk.trace import TracerProvider

BASE = {"from_account": "ACC-A-123456", "to_account": "ACC-A-654321", "amount": 1200.0}
SEED = {("tenant_a", "ACC-A-123456"): 100000.0,
        ("tenant_a", "ACC-A-654321"): 5000.0,
        ("tenant_a", "ACC-A-888888"): 20000.0,
        ("tenant_b", "ACC-B-111111"): 50000.0}


def emit(label, value):
    print(label, json.dumps(value, ensure_ascii=False, default=str))


@pytest.fixture(autouse=True)
def isolated():
    d.reset_demo_state()
    yield
    d.reset_demo_state()


def ctx(**kw):
    return replace(d.ExecutionContext(run_id="run_teacher", user_id="u_teacher", tenant_id="tenant_a",
                   permissions=frozenset({"account:transfer", "order:read"}),
                   allowed_tools=frozenset({"transfer", "get_order"})), **kw)


def approve(store, arguments, context=None):
    context = context or ctx()
    store.approve("teacher_approval", user_id=context.user_id, tenant_id=context.tenant_id,
                  tool_name="transfer", args=d.TransferArgs.model_validate(arguments), approver_id="teacher")
    return replace(context, approval_id="teacher_approval")


async def invoke(rt, arguments, context=None, call_id="call_tr_000003"):
    result = await rt.invoke(d.ToolCall(call_id, "transfer", arguments), context or ctx())
    emit("RESULT", {"call": call_id, "args": arguments, "ok": result.ok,
                    "decision": result.decision, "status": result.status,
                    "code": result.error_code, "content": result.content,
                    "invocation_id": result.invocation_id})
    return result


def test_A01_initial_accounts():
    emit("ACCOUNTS", sorted((list(k), v, type(v).__name__) for k, v in d.ACCOUNTS.items()))
    assert d.ACCOUNTS == SEED
    assert all(type(v) is float for v in d.ACCOUNTS.values())


@pytest.mark.parametrize("change", [
    {"approved": True}, {"user_id": "admin"}, {"amount": -1.0}, {"amount": 0.0},
    {"amount": 100000.01}, {"from_account": "ACC-123456"}, {"to_account": "ACC-A-12345"},
    {"amount": "1200.0"},
])
async def test_A02_invalid_inputs(change):
    rt, _, sink = d.build_governance()
    r = await invoke(rt, {**BASE, **change})
    assert r.error_code == "INVALID_ARGUMENT"
    assert d.ACCOUNTS == SEED
    assert not sink.of_type(d.AuditEventType.TOOL_EXECUTION_STARTED)


@pytest.mark.parametrize("field", list(BASE))
async def test_A02_missing(field):
    rt, _, _ = d.build_governance()
    r = await invoke(rt, {k: v for k, v in BASE.items() if k != field})
    assert r.error_code == "INVALID_ARGUMENT"


async def test_A02_amount_float_contract():
    emit("MODEL_CONFIG", d.TransferArgs.model_config)
    emit("SCHEMA", d.TransferArgs.model_json_schema())
    rt, _, _ = d.build_governance()
    r = await invoke(rt, {**BASE, "amount": 0.001})
    assert r.error_code == "APPROVAL_REQUIRED", "题目允许任意满足范围的 float，未要求最多两位小数"


@pytest.mark.parametrize("amount,code", [
    (50000.0, "APPROVAL_REQUIRED"), (50000.01, "EXCEED_LIMIT"),
    (80000.0, "EXCEED_LIMIT"), (80000.01, "APPROVAL_REQUIRED"),
    (100000.0, "APPROVAL_REQUIRED"), (100000.01, "INVALID_ARGUMENT"),
])
async def test_A03_boundaries(amount, code):
    rt, _, sink = d.build_governance()
    r = await invoke(rt, {**BASE, "amount": amount})
    assert r.error_code == code
    assert d.ACCOUNTS == SEED
    assert not sink.of_type(d.AuditEventType.TOOL_EXECUTION_STARTED)
    emit("AUDIT", sink.records)


@pytest.mark.parametrize("amount,code", [(30000.0, "INSUFFICIENT_BALANCE"), (60000.0, "EXCEED_LIMIT")])
async def test_A04_precheck_priority_readonly_unconsumed(amount, code):
    rt, store, sink = d.build_governance()
    args = {**BASE, "from_account": "ACC-A-888888", "amount": amount}
    approved = approve(store, args)
    for context in (ctx(), approved):
        r = await invoke(rt, args, context)
        assert r.error_code == code
        assert r.status == d.InvocationStatus.DENIED
        assert d.ACCOUNTS == SEED
        assert not store.get("teacher_approval").used
    assert not sink.of_type(d.AuditEventType.TOOL_EXECUTION_STARTED)
    emit("AUDIT", sink.records)


async def test_A05_exact_balance():
    rt, store, _ = d.build_governance()
    args = {**BASE, "from_account": "ACC-A-888888", "amount": 20000.0}
    r = await invoke(rt, args, approve(store, args))
    assert r.ok
    assert d.ACCOUNTS == {**SEED, ("tenant_a", "ACC-A-888888"): 0.0,
                         ("tenant_a", "ACC-A-654321"): 25000.0}


@pytest.mark.parametrize("destination", ["ACC-A-000000", "ACC-B-111111"])
async def test_A06_A07_missing_destination_tenant(destination):
    rt, store, _ = d.build_governance()
    args = {**BASE, "to_account": destination}
    r = await invoke(rt, args, approve(store, args))
    assert r.error_code == "ACCOUNT_NOT_FOUND"
    assert r.content["message"] == "转入账户不存在"
    assert d.ACCOUNTS == SEED


async def test_A07_other_tenant_source():
    rt, _, _ = d.build_governance()
    r = await invoke(rt, {**BASE, "from_account": "ACC-B-111111"})
    assert r.error_code == "INSUFFICIENT_BALANCE"
    assert d.ACCOUNTS == SEED


def test_A08_registration():
    tool = next(t for t in d.build_tools() if t.name == "transfer")
    emit("POLICY", asdict(tool.policy))
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert tool.pass_tool_call_id
    assert tool.policy.effect == d.Effect.WRITE
    assert tool.policy.requires_approval
    assert 0 < tool.policy.timeout_seconds < 3
    assert not tool.policy.idempotent and tool.policy.max_retries == 0


async def test_A08_required_permission_name():
    rt, _, _ = d.build_governance()
    r = await invoke(rt, BASE, ctx(permissions=frozenset({"transfer:execute"})))
    assert r.error_code == "APPROVAL_REQUIRED"


def test_A08_target_full_arguments():
    tool = next(t for t in d.build_tools() if t.name == "transfer")
    variants = [BASE, {**BASE, "from_account": "ACC-A-888888"},
                {**BASE, "to_account": "ACC-A-888888"}, {**BASE, "amount": 1201.0}]
    targets = [tool.canonical_target(d.TransferArgs.model_validate(a), ctx()) for a in variants]
    emit("TARGETS", targets)
    assert len(set(targets)) == 4


@pytest.mark.parametrize("overrides,code", [
    ({"permissions": frozenset()}, "PERMISSION_DENIED"),
    ({"allowed_tools": frozenset()}, "TOOL_NOT_ALLOWED"),
    ({"mode": d.PermissionMode.PLAN}, "PLAN_MODE_DENIED"),
    ({"permissions": frozenset(), "mode": d.PermissionMode.BYPASS_PERMISSIONS}, "PERMISSION_DENIED"),
])
async def test_T03_native_api_gates(overrides, code):
    rt, store, _ = d.build_governance()
    context = approve(store, BASE)
    r = await invoke(rt, BASE, replace(context, **overrides))
    assert r.error_code == code
    assert not store.get("teacher_approval").used
    assert d.ACCOUNTS == SEED


async def test_T04_A09_A10_success_approval_audit():
    provider = TracerProvider()
    rt, store, sink = d.build_governance(tracer=provider.get_tracer("teacher"))
    pending = await invoke(rt, BASE, call_id="call_tr_000001")
    assert pending.decision is d.PermissionDecision.CONFIRM
    approved = approve(store, BASE)
    tampered = await invoke(rt, {**BASE, "amount": 9000.0}, approved, "call_tr_000002")
    assert tampered.error_code == "APPROVAL_REQUIRED"
    assert not store.get("teacher_approval").used and d.ACCOUNTS == SEED
    result = await invoke(rt, BASE, approved)
    assert result.ok
    assert result.content["from"] == "ACC-A-****3456"
    assert result.content["to"] == "ACC-A-****4321"
    assert result.content["amount"] == 1200.0
    assert d.ACCOUNTS == {**SEED, ("tenant_a", "ACC-A-123456"): 98800.0,
                         ("tenant_a", "ACC-A-654321"): 6200.0}
    replay = await invoke(rt, BASE, approved, "call_tr_000004")
    assert replay.error_code == "APPROVAL_REQUIRED"
    emit("AUDIT", sink.records)
    records = [e for e in sink.records if e.get("invocation_id") == result.invocation_id]
    names = [e["event_type"] for e in records]
    assert names.index("tool.execution.started") < names.index("approval.consumed") < names.index("tool.execution.attempt")
    assert names[-1] == "tool.invocation.finished" and records[-1]["outcome"] == "succeeded"
    assert all(e.get("tool_call_id") == "call_tr_000003" for e in records)
    assert all(e.get("trace_id") for e in records)
    assert len({e["trace_id"] for e in records}) == 1
    audit_json = json.dumps(sink.records)
    assert "ACC-A-123456" not in audit_json and "ACC-A-654321" not in audit_json
    provider.shutdown()


@pytest.mark.parametrize("field,expected", [("txn_id", "000003"), ("status", "accepted")])
async def test_T04_return_contract(field, expected):
    rt, store, _ = d.build_governance()
    result = await invoke(rt, BASE, approve(store, BASE))
    assert result.content[field] == expected


async def test_A09_order_nested_redaction():
    rt, _, _ = d.build_governance()
    r = await rt.invoke(d.ToolCall("order_teacher", "get_order", {"order_id": "ord_1001"}), ctx())
    emit("ORDER", r.to_model_payload())
    assert r.ok and r.content["customer_email"] == "***@***" and r.content["access_token"] == "***"
    value = {"nested": [{"email": "alice@example.com", "password": "test", "account": "ACC-A-123456"}],
             "authorization": "test"}
    assert d.redact(value) == {"nested": [{"email": "***@***", "password": "***", "account": "ACC-A-****3456"}],
                               "authorization": "***"}


@pytest.mark.parametrize("amount", [80000.01, 90000.0, 100000.0])
async def test_T05_A03_real_handler_timeout(amount):
    rt, store, sink = d.build_governance()
    args = {**BASE, "amount": amount}
    approved = approve(store, args)
    profile = []
    handler_code = d.transfer_handler.__code__

    def record(frame, event, arg):
        if event == "call" and frame.f_code is handler_code:
            profile.append({"function": "transfer_handler", "event": event})
        if event == "call" and frame.f_code is asyncio.sleep.__code__:
            profile.append({"function": "asyncio.sleep", "delay": frame.f_locals.get("delay")})

    start = time.perf_counter()
    sys.setprofile(record)
    try:
        r = await invoke(rt, args, approved)
    finally:
        sys.setprofile(None)
    elapsed = time.perf_counter() - start
    emit("TIMEOUT", {"elapsed": elapsed, "profile": profile, "audit": sink.records})
    assert r.error_code == "TIMEOUT_UNKNOWN" and r.status == d.InvocationStatus.UNKNOWN
    assert 1.8 <= elapsed < 3
    assert any(e.get("function") == "transfer_handler" for e in profile)
    assert any(e.get("function") == "asyncio.sleep" and e.get("delay") == 3.0 for e in profile)
    assert len(sink.of_type(d.AuditEventType.TOOL_ATTEMPT)) == 1
    assert sink.records[-1]["reason_code"] == "TIMEOUT_UNKNOWN"
    assert sink.records[-1]["error_class"] == "TimeoutError"
    assert d.ACCOUNTS == SEED


def test_A10_fixed_engine_ast():
    reference = Path(__file__).resolve().parent.parent / "reference" / "tool_governance_demo-无答案.py"
    actual = Path(inspect.getfile(d))

    def method(path):
        source = path.read_text()
        cls = next(n for n in ast.parse(source).body if isinstance(n, ast.ClassDef) and n.name == "PermissionEngine")
        node = next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == "decide")
        return ast.get_source_segment(source, node), ast.dump(node, include_attributes=False)

    before, before_ast = method(reference)
    after, after_ast = method(actual)
    emit("ENGINE_COMPARISON", {"reference": str(reference), "student": str(actual),
                              "text_equal": before == after, "ast_equal": before_ast == after_ast})
    print("".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="fixed", tofile="student")))
    assert before_ast == after_ast, "非格式变化：async 状态机被同步白名单/RBAC方法替换"
