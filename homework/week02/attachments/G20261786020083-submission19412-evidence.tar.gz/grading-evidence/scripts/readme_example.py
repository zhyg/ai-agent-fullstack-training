import asyncio
from dataclasses import replace
from tool_governance_demo import (
    ExecutionContext, ToolCall, TransferArgs, build_governance,
)


async def demo():
    runtime, approvals, _sink = build_governance()
    ctx = ExecutionContext(
        run_id="run_example", user_id="u_100", tenant_id="tenant_a",
        permissions=frozenset({"order:read", "refund:create", "account:transfer"}),
        allowed_tools=frozenset({"get_order", "create_refund", "transfer"}),
    )
    order = await runtime.invoke(
        ToolCall("call_order", "get_order", {"order_id": "ord_1001"}), ctx,
    )
    print(order.content)

    refund = await runtime.invoke(ToolCall("call_refund", "create_refund", {
        "order_id": "ord_1001", "amount": "399.00", "reason": "临时改变购买计划",
    }), ctx)
    print(refund.decision.name)  # CONFIRM，尚未执行退款

    args = {
        "from_account": "ACC-A-123456", "to_account": "ACC-A-654321", "amount": "1000.00",
    }
    call = ToolCall("call_transfer_123456", "transfer", args)
    pending = await runtime.invoke(call, ctx)
    print(pending.decision.name)  # CONFIRM，尚未修改余额

    approvals.approve(
        "approval_example", user_id=ctx.user_id, tenant_id=ctx.tenant_id,
        tool_name="transfer", args=TransferArgs.model_validate(args), approver_id="ops_1",
    )
    result = await runtime.invoke(call, replace(ctx, approval_id="approval_example"))
    print(result.content)  # 成功结果中的账号已脱敏


asyncio.run(demo())
