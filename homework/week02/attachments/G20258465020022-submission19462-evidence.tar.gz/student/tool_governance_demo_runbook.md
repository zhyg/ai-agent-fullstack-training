# Runbook：`tool_governance_demo.py`

第二章实战作业脚本：在完整的工具治理框架上接入 `transfer`（转账）工具。
本手册说明脚本实现了什么、如何运行、以及内部运行流程。

---

## 1. 脚本实现的功能

脚本内置一个**工具治理框架**，所有工具调用都必须穿过同一条治理链路：

> Pydantic 严格校验 → 权限状态机决策 → 一次性审批 → 超时/重试恢复 → 结果脱敏 → 审计追踪

### 1.1 治理的 4 个工具

| 工具 | 效应 | 风险 | 权限 | 需审批 | 说明 |
|---|---|---|---|---|---|
| `get_order` | read | medium | `order:read` | 否 | 查询订单（可重试、幂等） |
| `create_refund` | write | high | `refund:create` | 是 | 创建退款（带业务预检） |
| `run_shell` | shell | medium | `shell:run` | 否 | 模拟 Shell，不产生真实子进程 |
| `transfer` | write | high | `transfer:execute` | 是 | 账户转账（作业任务 1–6 接入） |

### 1.2 核心组件

- **`StrictArgs` 参数模型族**（`GetOrderArgs` / `CreateRefundArgs` / `RunShellArgs` / `TransferArgs`）：
  `extra="forbid"` + `strict=True` + 正则/数值约束，拒绝模型注入额外字段（如 `{"approved": true}`）。
- **`PermissionEngine.decide`**：固定优先级的三态权限状态机，返回 `allow` / `deny` / `confirm`（详见 §4.3）。
- **`ApprovalStore`**：一次性审批。审批记录绑定 用户 + 租户 + 工具名 + 参数摘要（SHA-256 canonical JSON），消费一次即失效，默认 TTL 300 秒。
- **`ToolRuntime.invoke`**：模型、CLI、测试共用的唯一执行入口，串起校验、决策、超时、重试、脱敏、审计（详见 §4.2）。
- **`_redact` 脱敏**：`token/secret/password/authorization` 字段 → `***`；邮箱 → `***@***`；账号 → `ACC-A-****3456`。
- **`AuditSink`**：每个调用写入 decision / execution 两类 `AuditRecord`。
- **模拟数据**：`ORDERS`（订单）、`ACCOUNTS`（`(tenant_id, account_id) → 余额`，模块级可变 dict）、`SIDE_EFFECTS`（副作用计数器）。
- **两种运行模式**：离线演示（默认）与真实 DeepSeek Agent Loop（`--agent`，可选）。

### 1.3 作业任务（6 个 TODO，当前均已实现）

任务 1 `ACCOUNTS` 数据 · 任务 2 `TransferArgs` · 任务 3 `transfer_precheck`（限额区间 + 转出账户存在性 + 余额检查）·
任务 4 `transfer_handler`（超时演示 + 扣款/入账）· 任务 5 `build_tools()` 注册 · 任务 6 `_redact` 账号脱敏。

---

## 2. 运行环境与依赖

- **Python ≥ 3.11**（使用 `enum.StrEnum` 与 `asyncio.timeout`；仓库 `.venv` 为 3.12.15，系统 Python 3.7 无法运行）。
- 必装依赖：`pydantic`（v2）、`pytest`。
- 仅 `--agent` 模式需要：`openai` SDK + 环境变量 `DEEPSEEK_API_KEY`（可选 `DEEPSEEK_BASE_URL`、`DEEPSEEK_MODEL`，默认 `https://api.deepseek.com` / `deepseek-v4-flash`）。

---

## 3. 如何运行脚本

以下命令均在 `chapter2/` 目录下、用仓库 venv 解释器执行（Windows PowerShell）：

```powershell
cd chapter2

# ① 离线演示（默认模式，无需 API Key，直接跑通全部治理路径）
..\.venv\Scripts\python.exe tool_governance_demo.py

# ② 作业验收（5 个 transfer 链路测试，当前全部通过，约 2s）
..\.venv\Scripts\python.exe -m pytest test_tool_governance.py -v -k "transfer"

# ③ 真实模型闭环（可选；所有模型发起的工具调用仍走同一个 ToolRuntime.invoke）
$env:DEEPSEEK_API_KEY = "sk-..."
..\.venv\Scripts\python.exe tool_governance_demo.py --agent --input "请查询订单 ord_1001 的状态和可退金额"
```

> 注：脚本 docstring 写的验收命令是 `pytest tests/test_tool_governance.py`，实际测试文件与本脚本同目录（`chapter2/test_tool_governance.py`），按上面 ② 运行即可。

CLI 参数（`parse_args`）：

| 参数 | 作用 |
|---|---|
| `--agent` | 启用 DeepSeek 真实 Agent Loop，否则跑 `run_offline_demo()` |
| `--input TEXT` | Agent 模式的用户输入，默认"请查询订单 ord_1001 的状态和可退金额" |

**关键环境变量**：无 Key 时 `--agent` 抛 `RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")`。

---

## 4. 脚本运行流程

### 4.1 入口

```
__main__ (第 982 行)
  └─ parse_args()
       ├─ 无 --agent → asyncio.run(run_offline_demo())
       └─ 有 --agent → asyncio.run(run_deepseek_agent(args.input))
```

### 4.2 单次工具调用的治理管线（`ToolRuntime.invoke`，第 488 行）

每一次调用——无论来自演示、测试还是真实模型——都走同一条路：

```
invoke(call, context)
  │
  ├─ 1. 查工具表        未注册 → deny TOOL_NOT_FOUND
  ├─ 2. Pydantic 校验   参数不合 schema / 多余字段 → deny INVALID_ARGUMENT（防注入）
  ├─ 3. PermissionEngine.decide(...)      ← 九级优先级决策，见 §4.3
  │       └─ 写审计记录（phase=decision）
  │       ├─ deny   → 直接返回拒绝结果（handler 绝不被调用，零副作用）
  │       └─ confirm→ 返回"需要一次性审批"，提示带 approval_id 重试
  ├─ 4. 执行 _execute_with_recovery：
  │       asyncio.timeout(policy.timeout_seconds) 包住 handler
  │       仅 read/幂等工具才按 max_retries 指数退避重试 TransientToolError
  │       超时 → TIMEOUT（非幂等写操作 → TIMEOUT_UNKNOWN，结果未知态）
  ├─ 5. _redact(raw)  字段脱敏 + 邮箱脱敏 + 账号掩码
  └─ 6. 写审计记录（phase=execution，含 latency_ms）→ 返回 ToolResult
```

### 4.3 权限状态机优先级（`PermissionEngine.decide`，第 354 行，顺序固定不可改）

| # | 检查 | 不通过的返回 |
|---|---|---|
| 1 | deny 规则（硬拒绝，bypass 也压不过） | `DENY_RULE` |
| 2 | plan 模式下禁止非 read 操作 | `PLAN_MODE_DENIED` |
| 3 | 工具是否在 `allowed_tools` 白名单 | `TOOL_NOT_ALLOWED` |
| 4 | RBAC：context 是否持有 policy.permission | `PERMISSION_DENIED` |
| 5 | 业务 precheck（订单状态/额度、转账限额/转出账户存在性/余额） | `BUSINESS_RULE_DENIED` / `EXCEED_LIMIT` / `ACCOUNT_NOT_FOUND` / `INSUFFICIENT_BALANCE` |
| 6 | 高风险写：一次性审批必须命中，否则 `CONFIRM`（dontAsk 下直接 deny） | `APPROVAL_REQUIRED` |
| 7 | bypassPermissions 仅跳过普通确认 | `BYPASS_ALLOWED` |
| 8 | allow 规则 | `ALLOW_RULE` |
| 9 | 危险 Shell 正则兜底（rm -rf、sudo 等） | `DANGEROUS_OPERATION` |
| 10 | 全部通过 | `DEFAULT_ALLOWED` |

### 4.4 离线演示流程（`run_offline_demo`，第 846 行）

依次发起 6 个调用，专门覆盖各条决策分支（实测输出即各 code）：

| 调用 | 场景 | 触发路径 | 结果 |
|---|---|---|---|
| call_01 | 查订单 ord_1001 | read，直接放行 | `OK`（邮箱/token 已脱敏） |
| call_02 | 退款 399，未审批 | 第 6 级审批缺失 | `confirm / APPROVAL_REQUIRED` |
| call_03 | 同参数 + `approval_01` | 审批摘要匹配并一次性消费 | `OK`（refund_executions=1） |
| call_04 | 退款参数注入 `user_id`/`approved` | 第 2 级 Pydantic forbid | `deny / INVALID_ARGUMENT` |
| call_05 | `rm -rf /tmp/demo`（bypass 模式） | 第 1 级 deny 规则优先于 bypass | `deny / DENY_RULE`（零副作用） |
| call_06 | 带旧审批但 plan 模式退款 | 第 2 级 plan 只读契约 | `deny / PLAN_MODE_DENIED` |

最后打印每条 `ToolResult` 的 JSON、`SIDE_EFFECTS` 计数与审计记录总数（正常输出 `audit_records: 8`）。

### 4.5 Agent 模式流程（`run_deepseek_agent`，第 896 行）

```
构建 runtime（白名单只放开 get_order）
  └─ 最多 8 轮循环：
       流式调用 DeepSeek（tools=runtime.model_tools(context)，只投影 name/description/JSON Schema）
       ├─ 无 tool_calls → 打印回答，结束
       └─ 有 tool_calls → 逐个 JSON 解析参数 → runtime.invoke(...)（仍走 §4.2 全链路）
                          把脱敏后的 ToolResult 作为 tool message 回填，继续下一轮
     超过 8 轮 → RuntimeError("Agent Loop 超过最大轮数 8")
```

---

## 5. 预期输出与验证

- 离线演示：7 行 JSON（6 个结果 + 1 行 side_effects/audit 汇总），退出码 0；中文 reason 在非 UTF-8 控制台（如 GBK）显示乱码属编码问题，不影响逻辑。
- 验收测试：`5 passed in ~2s`（覆盖转账成功+审批、注入拒绝、余额不足、限额拦截、超时 TIMEOUT_UNKNOWN 等链路）。
