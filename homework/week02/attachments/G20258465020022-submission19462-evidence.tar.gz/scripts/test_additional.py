import ast
import asyncio
import inspect
import json
import time
from dataclasses import asdict, replace
from pathlib import Path

import pytest
import tool_governance_demo as d

ROOT = Path(__file__).resolve().parents[1]
F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}

def ctx(**kw):
    return d.base_context(**{'permissions': frozenset({'transfer:execute', 'order:read'}),
                            'allowed_tools': frozenset({'transfer', 'get_order'}), **kw})

def args(**kw):
    return {'from_account': F, 'to_account': T, 'amount': 1200.0, **kw}

@pytest.fixture(autouse=True)
def isolated():
    snapshot = dict(d.ACCOUNTS)
    d.reset_side_effects()
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(snapshot)

def run(coro):
    return asyncio.run(coro)

async def invoke(rt, a, c=None, call='supplement_123789'):
    result = await rt.invoke(d.ToolCall(call, 'transfer', a), c or ctx())
    print(json.dumps({'call': call, 'arguments': a, 'result': asdict(result)}, ensure_ascii=False, default=str))
    return result

def approved(store, a, c=None):
    c = c or ctx()
    store.approve('test_approval', c, 'transfer', d.TransferArgs.model_validate(a))
    return replace(c, approval_id='test_approval')

def test_A01_initial():
    assert d.ACCOUNTS == INITIAL
    assert all(type(v) is float for v in d.ACCOUNTS.values())

def test_A02_strict():
    assert issubclass(d.TransferArgs, d.StrictArgs)
    assert d.TransferArgs.model_config['strict'] is True
    assert d.TransferArgs.model_config['extra'] == 'forbid'
    bad = [args(**{k: v}) for k, v in [('approved', True), ('user_id', 'admin'),
           ('amount', -1.0), ('amount', '1200'), ('amount', True),
           ('from_account', 'ACC-a-123456'), ('to_account', 'ACC-A-12345'),
           ('from_account', 123456), ('to_account', 123456)]]
    bad += [{k: v for k, v in args().items() if k != missing} for missing in args()]
    for a in bad:
        rt, _, audit = d.build_runtime()
        assert run(invoke(rt, a)).code == 'INVALID_ARGUMENT'
        assert d.ACCOUNTS == INITIAL
        assert audit.records[-1].phase == 'decision'

@pytest.mark.parametrize('amount,code,action', [
    (50000.0, 'APPROVAL_REQUIRED', 'confirm'), (50000.01, 'EXCEED_LIMIT', 'deny'),
    (80000.0, 'EXCEED_LIMIT', 'deny'), (80000.01, 'APPROVAL_REQUIRED', 'confirm'),
    (100000.0, 'APPROVAL_REQUIRED', 'confirm'), (100000.01, 'INVALID_ARGUMENT', 'deny')])
def test_A03_pending_boundaries(amount, code, action):
    rt, _, audit = d.build_runtime()
    result = run(invoke(rt, args(amount=amount)))
    assert (result.code, result.action.value) == (code, action)
    assert audit.records[-1].phase == 'decision'
    assert d.ACCOUNTS == INITIAL

@pytest.mark.parametrize('amount', [80000.01, 100000.0])
def test_A03_approved_timeout(amount):
    rt, store, audit = d.build_runtime()
    a = args(amount=amount)
    start = time.perf_counter()
    result = run(invoke(rt, a, approved(store, a)))
    elapsed = time.perf_counter() - start
    print('elapsed_seconds=', elapsed)
    assert result.code == 'TIMEOUT_UNKNOWN'
    assert 1.8 < elapsed < 3.0
    assert d.ACCOUNTS == INITIAL
    assert [(r.phase, r.code) for r in audit.records] == [('decision', 'APPROVED'), ('execution', 'TIMEOUT_UNKNOWN')]

@pytest.mark.parametrize('amount,code', [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')])
def test_A04_order_readonly_unconsumed(amount, code):
    for has_approval in [False, True]:
        rt, store, audit = d.build_runtime()
        a = args(from_account=S, amount=amount)
        c = approved(store, a) if has_approval else ctx()
        result = run(invoke(rt, a, c))
        assert result.code == code and result.action.value == 'deny'
        assert d.ACCOUNTS == INITIAL
        assert [(r.phase, r.code) for r in audit.records] == [('decision', code)]
        if has_approval:
            assert store.consume('test_approval', c, 'transfer', d.TransferArgs.model_validate(a)) is True

def test_A05_full_balance():
    rt, store, _ = d.build_runtime()
    a = args(from_account=S, amount=20000.0)
    assert run(invoke(rt, a, approved(store, a))).ok
    assert d.ACCOUNTS == {**INITIAL, ('tenant_a', S): 0.0, ('tenant_a', T): 25000.0}

def test_A06_missing_target():
    rt, store, audit = d.build_runtime()
    a = args(to_account='ACC-A-999999')
    result = run(invoke(rt, a, approved(store, a)))
    assert result.code == 'ACCOUNT_NOT_FOUND'
    assert '转入账户不存在' in str(result.content)
    assert d.ACCOUNTS == INITIAL
    assert audit.records[-1].phase == 'execution'

def test_A07_tenant_isolation():
    for tenant, a in [('tenant_a', args(from_account=B)), ('tenant_a', args(to_account=B)),
                      ('tenant_b', args(from_account=F, to_account=B)), ('tenant_b', args(from_account=B, to_account=T))]:
        rt, store, _ = d.build_runtime()
        result = run(invoke(rt, a, approved(store, a, ctx(tenant_id=tenant))))
        assert not result.ok
        assert result.code in {'ACCOUNT_NOT_FOUND', 'INSUFFICIENT_BALANCE'}
        assert d.ACCOUNTS == INITIAL

def test_A08_registration_target():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    assert inspect.iscoroutinefunction(tool.precheck)
    p = tool.policy
    print('policy=', asdict(p))
    assert p.effect is d.Effect.WRITE and p.permission == 'transfer:execute'
    assert p.requires_approval or p.risk is d.Risk.HIGH
    assert 0 < p.timeout_seconds < 3 and not p.idempotent and p.max_retries == 0
    targets = [tool.canonical_target(d.TransferArgs.model_validate(a)) for a in
               [args(), args(from_account=S), args(to_account=S), args(amount=1201.0)]]
    print('targets=', targets)
    assert len(set(targets)) == 4
    source = inspect.getsource(d.transfer_handler)
    assert 'await asyncio.sleep(3.0)' in source
    assert source.index('await asyncio.sleep(3.0)') < source.index('-=')

def test_A09_result_recursive_regression():
    rt, store, audit = d.build_runtime()
    a = args()
    result = run(invoke(rt, a, approved(store, a)))
    assert result.content == {'txn_id': '123789', 'from': 'ACC-A-****3456', 'to': 'ACC-A-****4321', 'amount': 1200.0, 'status': 'accepted'}
    order = run(rt.invoke(d.ToolCall('order_regression', 'get_order', {'order_id': 'ord_1001'}), ctx()))
    print('order=', asdict(order))
    assert order.ok and '***@***' in str(order.content)
    assert order.content['access_token'] == '***'
    nested = {'rows': [{'account': F, 'email': 'person@example.com', 'Password': 'fake'}], 'tuple': (T, {'Authorization': 'fake', 'secret': 'fake', 'token': 'fake'})}
    masked = d._redact(nested)
    print('recursive=', masked)
    assert masked == {'rows': [{'account': 'ACC-A-****3456', 'email': '***@***', 'Password': '***'}], 'tuple': ['ACC-A-****4321', {'Authorization': '***', 'secret': '***', 'token': '***'}]}

def test_A10_fixed_engine_and_tests():
    original = (ROOT / 'trusted/tool_governance_demo-无答案.py').read_text()
    student = Path(d.__file__).read_text()
    def extract(text):
        tree = ast.parse(text)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
        method = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
        return '\n'.join(text.splitlines()[method.lineno-1:method.end_lineno])
    assert extract(original) == extract(student)
    assert (ROOT / 'trusted/test_tool_governance.py').read_bytes() == (ROOT / 'student/test_tool_governance.py').read_bytes()
    print('PermissionEngine.decide exact source equality: True; student tests byte equality: True')
    print('module_absolute_path=', d.__file__)

def test_A10_teacher_evidence_not_student_demo():
    async def scenario():
        rt, store, audit = d.build_runtime()
        a = args()
        pending = await invoke(rt, a, call='teacher_pending')
        assert pending.action is d.DecisionAction.CONFIRM
        c = approved(store, a)
        changed = await invoke(rt, args(to_account=S), c, call='teacher_tamper')
        assert changed.action is d.DecisionAction.CONFIRM
        result = await invoke(rt, a, c, call='teacher_000003')
        assert result.ok and result.content['txn_id'] == '000003'
        replay = await invoke(rt, a, c, call='teacher_replay')
        assert replay.action is d.DecisionAction.CONFIRM
        print('TEACHER_SUPPLEMENT_AUDIT=', json.dumps([asdict(r) for r in audit.records], ensure_ascii=False))
        assert [(r.phase, r.code) for r in audit.records] == [('decision', 'APPROVAL_REQUIRED'), ('decision', 'APPROVAL_REQUIRED'), ('decision', 'APPROVED'), ('execution', 'OK'), ('decision', 'APPROVAL_REQUIRED')]
        assert all(r.trace_id == ctx().trace_id for r in audit.records)
    run(scenario())
