import ast
import hashlib
import json
import os
from pathlib import Path

import tool_governance_demo as d

root = Path(__file__).resolve().parents[1]
student = Path(d.__file__)
original = root / 'trusted/tool_governance_demo-无答案.py'

def method(path):
    text = path.read_text()
    tree = ast.parse(text)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
    node = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
    return '\n'.join(text.splitlines()[node.lineno-1:node.end_lineno])

print('module_absolute_path:', student)
for label, path in [('trusted', original), ('student', student)]:
    source = method(path)
    (root / f'{label}-PermissionEngine.decide.txt').write_text(source + '\n')
    print(label, 'decide SHA256:', hashlib.sha256(source.encode()).hexdigest())
print('exact_source_equal:', method(original) == method(student))
for path in [root / 'trusted/test_tool_governance.py', student.parent / 'test_tool_governance.py']:
    print('test_SHA256:', path, hashlib.sha256(path.read_bytes()).hexdigest())
tree = ast.parse((student.parent / 'test_tool_governance.py').read_text())
print('submitted_test_print_calls:', sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'print' for n in ast.walk(tree)))
for name in ['TransferArgs', 'transfer_precheck', 'transfer_handler', '_redact', 'build_tools', 'run_offline_demo']:
    tree = ast.parse(student.read_text())
    node = next(n for n in tree.body if getattr(n, 'name', '') == name)
    print(f'\nSOURCE {name} lines {node.lineno}-{node.end_lineno}:')
    print('\n'.join(student.read_text().splitlines()[node.lineno-1:node.end_lineno]))
log = (root / 'logs/submitted_demo.log').read_text()
objects = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
print('\nsubmitted_demo_tool_names:', [o.get('tool_name') for o in objects if 'tool_name' in o])
print('submitted_demo_transfer_result_count:', sum(o.get('tool_name') == 'transfer' for o in objects))
print('submitted_demo_audit_record_details_count:', sum('phase' in o and 'trace_id' in o for o in objects))
print('submitted_demo_audit_summary:', [o for o in objects if 'audit_records' in o])
