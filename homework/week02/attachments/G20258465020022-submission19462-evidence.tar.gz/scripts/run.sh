#!/usr/bin/env bash
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
REPO=$(git rev-parse --show-toplevel)
PY=${PYTHON:-"$REPO/.amp/in/orb-backup/week02-venv/bin/python"}
STUDENT=${STUDENT_DIR:-"$REPO/.amp/in/orb-backup/G20258465020022-student/chapter2"}
export PYTHONPATH="$STUDENT"
export PYTHONDONTWRITEBYTECODE=1
record() {
  local name=$1
  shift
  { printf 'COMMAND: '; printf '%q ' "$@"; printf '\n'; "$@"; rc=$?; printf '\nEXIT_CODE=%s\n' "$rc"; } > "$ROOT/logs/$name.log" 2>&1
  cat "$ROOT/logs/$name.log"
}
record environment "$PY" -c 'import sys,platform,pydantic,pytest,tool_governance_demo as d; print("Python",sys.version);print("Platform",platform.platform());print("Pydantic",pydantic.__version__);print("pytest",pytest.__version__);print("module_absolute_path",d.__file__)'
record trusted "$PY" -m pytest "$ROOT/trusted/test_tool_governance.py" -v -s -k transfer -p no:cacheprovider
record additional "$PY" -m pytest "$ROOT/scripts/test_additional.py" -v -s -p no:cacheprovider
record submitted_tests "$PY" -m pytest "$STUDENT/test_tool_governance.py" -v -s -k transfer -p no:cacheprovider
record submitted_demo "$PY" "$STUDENT/tool_governance_demo.py"
record source_inspection "$PY" "$ROOT/scripts/inspect_source.py"
record git_identity git -C "$STUDENT" log -1 --format=fuller
record student_status git -C "$STUDENT" status --short
