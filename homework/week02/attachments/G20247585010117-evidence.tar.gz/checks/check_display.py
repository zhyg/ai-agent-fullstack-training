"""Observe submitted offline demo, without modifying student code."""
import ast
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).parents[1]
student = root / 'source/W2'
result = subprocess.run([sys.executable, str(student / 'tool_governance_demo.py')],
                        capture_output=True, text=True, check=True)
records = [json.loads(line) for line in result.stdout.splitlines()]
tree = ast.parse((student / 'tests/test_tool_governance.py').read_text())
print(json.dumps({
    'student_demo_exit': result.returncode,
    'transfer_result_count': sum(r.get('tool_name') == 'transfer' for r in records),
    'masked_transfer_account_displayed': 'ACC-A-****3456' in result.stdout,
    'detailed_audit_with_trace_id_displayed': 'trace_id' in result.stdout,
    'audit_count_only': records[-1].get('audit_records'),
    'student_test_print_calls': sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                                    and n.func.id == 'print' for n in ast.walk(tree)),
    'selftest_bytes': (student / '_selftest.py').stat().st_size,
}, ensure_ascii=False, indent=2))
