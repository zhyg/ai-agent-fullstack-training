"""Teacher boundary checks; business calls only through student's Runtime."""
import ast
import asyncio
import dataclasses
import inspect
import json
from pathlib import Path
import time

import pytest
import tool_governance_demo as d

F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}


@pytest.fixture(autouse=True)
def isolate():
    saved = dict(d.ACCOUNTS)
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(saved)


def args(amount=1200.0, source=F, target=T):
    return dict(from_account=source, to_account=target, amount=amount)


def context(**kw):
    return d.base_context(permissions=frozenset({'order:read', 'transfer:execute'}),
                          allowed_tools=frozenset({'get_order', 'transfer'}), **kw)


async def case(arguments, approved=False, call_id='call_tr_000003', **kw):
    runtime, approvals, audit = d.build_runtime()
    ctx = context(**kw)
    if approved:
        approvals.approve('teacher_simulated_human_confirmation', ctx, 'transfer', arguments)
        ctx = dataclasses.replace(ctx, approval_id='teacher_simulated_human_confirmation')
    before = dict(d.ACCOUNTS)
    start = time.perf_counter()
    result = await runtime.invoke(d.ToolCall(call_id, 'transfer', arguments), ctx)
    elapsed = time.perf_counter() - start
    print(json.dumps(dict(arguments=arguments, approved=approved, result=dataclasses.asdict(result),
                          elapsed=elapsed, unchanged=d.ACCOUNTS == before,
                          audit=[dataclasses.asdict(r) for r in audit.records]), ensure_ascii=False))
    return result, audit, elapsed


def run(coro):
    return asyncio.run(coro)


def test_A01_initial_accounts():
    assert d.ACCOUNTS == INITIAL
    assert all(type(v) is float for v in d.ACCOUNTS.values())


def test_A02_strict_model():
    async def check():
        valid = args()
        variants = [{k: v for k, v in valid.items() if k != field} for field in valid]
        variants += [{**valid, 'approved': True}, {**valid, 'user_id': 'admin'},
                     args(-0.01), args('1200.0'), args(source='ACC-123456'),
                     args(target='ACC-a-654321'), args(source=123456), args(target=None)]
        for item in variants:
            result, audit, _ = await case(item)
            assert result.code == 'INVALID_ARGUMENT'
            assert d.ACCOUNTS == INITIAL
            assert audit.records[-1].phase == 'decision'
    run(check())
    assert issubclass(d.TransferArgs, d.StrictArgs)
    assert d.TransferArgs.model_config['strict'] is True
    assert d.TransferArgs.model_config['extra'] == 'forbid'


def test_A03_boundaries_and_timeouts():
    async def check():
        for amount, code in [(50000.0, 'APPROVAL_REQUIRED'), (50000.01, 'EXCEED_LIMIT'),
                             (80000.0, 'EXCEED_LIMIT'), (80000.01, 'APPROVAL_REQUIRED'),
                             (100000.0, 'APPROVAL_REQUIRED'), (100000.01, 'INVALID_ARGUMENT')]:
            result, audit, _ = await case(args(amount))
            assert result.code == code
            assert result.action.value == ('confirm' if code == 'APPROVAL_REQUIRED' else 'deny')
            assert audit.records[-1].phase == 'decision'
            assert d.ACCOUNTS == INITIAL
        for amount in [80000.01, 100000.0]:
            result, audit, elapsed = await case(args(amount), approved=True)
            assert result.code == 'TIMEOUT_UNKNOWN'
            assert 1.8 <= elapsed < 3.0
            assert audit.records[-1].phase == 'execution'
            assert d.ACCOUNTS == INITIAL
    run(check())


def test_A04_precheck_before_approval():
    async def check():
        for amount, code in [(30000.0, 'INSUFFICIENT_BALANCE'), (60000.0, 'EXCEED_LIMIT')]:
            item = args(amount, source=S)
            result, audit, _ = await case(item)
            assert result.code == code and result.action.value == 'deny'
            assert audit.records[-1].phase == 'decision'
            runtime, approvals, audit = d.build_runtime()
            ctx = context(approval_id='precheck_keeps_approval')
            approvals.approve(ctx.approval_id, ctx, 'transfer', item)
            result = await runtime.invoke(d.ToolCall('call_precheck', 'transfer', item), ctx)
            assert result.code == code
            assert approvals._records[ctx.approval_id].used is False
            assert d.ACCOUNTS == INITIAL
    run(check())


def test_A05_exact_balance():
    result, _, _ = run(case(args(20000.0, source=S), approved=True))
    assert result.ok
    assert d.ACCOUNTS[('tenant_a', S)] == 0.0
    assert d.ACCOUNTS[('tenant_a', T)] == 25000.0


def test_A06_missing_target():
    result, _, _ = run(case(args(target='ACC-A-999999'), approved=True))
    assert result.code == 'ACCOUNT_NOT_FOUND' and result.content == '转入账户不存在'
    assert d.ACCOUNTS == INITIAL


def test_A07_tenant_isolation():
    result, _, _ = run(case(args(source=B)))
    assert result.code == 'INSUFFICIENT_BALANCE'
    result, _, _ = run(case(args(target=B), approved=True))
    assert result.code == 'ACCOUNT_NOT_FOUND'
    assert d.ACCOUNTS == INITIAL


def test_A08_registration():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    p = tool.policy
    assert p.effect is d.Effect.WRITE
    assert p.requires_approval or p.risk is d.Risk.HIGH
    assert p.permission == 'transfer:execute'
    assert 0 < p.timeout_seconds < 3 and p.idempotent is False and p.max_retries == 0
    targets = [tool.canonical_target(d.TransferArgs(**item)) for item in
               [args(), args(source=S), args(target=S), args(1201.0)]]
    assert len(set(targets)) == 4
    print('REGISTRATION', p, targets)


def test_A09_redaction_and_order_regression():
    result, _, _ = run(case(args(), approved=True))
    assert result.content == {'txn_id': '000003', 'from': 'ACC-A-****3456',
                              'to': 'ACC-A-****4321', 'amount': 1200.0, 'status': 'accepted'}
    assert d._redact({'nested': [{'account': B, 'email': 'j@example.com',
                                 'password': 'sample'}], 'authorization': 'sample'}) == {
        'nested': [{'account': 'ACC-B-****1111', 'email': '***@***', 'password': '***'}],
        'authorization': '***'}
    async def check_order():
        runtime, _, _ = d.build_runtime()
        result = await runtime.invoke(d.ToolCall('order_read', 'get_order', {'order_id': 'ord_1001'}), context())
        assert result.ok and result.content['customer_email'] == '***@***'
        assert result.content['access_token'] == '***'
    run(check_order())


def test_A10_fixed_engine_and_teacher_demonstration():
    original = Path(__file__).parents[1] / 'trusted/tool_governance_demo-无答案.py'
    tree = ast.parse(original.read_text())
    engine = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
    method = next(n for n in engine.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
    import textwrap
    actual = ast.parse(textwrap.dedent(inspect.getsource(d.PermissionEngine.decide))).body[0]
    assert ast.dump(method, include_attributes=False) == ast.dump(actual, include_attributes=False)
    original_lines = original.read_text().splitlines()
    # Exact method source, including comments, compared independently of source line numbers.
    expected = '\n'.join(original_lines[method.lineno-1:method.end_lineno])
    assert textwrap.dedent(expected).strip() == textwrap.dedent(inspect.getsource(d.PermissionEngine.decide)).strip()
    print('FIXED_ENGINE_TEXT_IDENTICAL=True', 'ACTUAL_IMPORT=', d.__file__)
    async def demonstrate():
        runtime, approvals, audit = d.build_runtime()
        ctx = context(trace_id='trace_teacher_transfer_demo')
        item = args()
        pending = await runtime.invoke(d.ToolCall('demo_000001', 'transfer', item), ctx)
        assert pending.action is d.DecisionAction.CONFIRM
        # Teacher simulation of human confirmation, not a real approval UI.
        approvals.approve('teacher_human_simulation', ctx, 'transfer', item)
        result = await runtime.invoke(d.ToolCall('demo_000002', 'transfer', item),
                                      dataclasses.replace(ctx, approval_id='teacher_human_simulation'))
        assert result.ok and result.content['from'] == 'ACC-A-****3456'
        assert [(r.phase, r.code) for r in audit.records] == [
            ('decision', 'APPROVAL_REQUIRED'), ('decision', 'APPROVED'), ('execution', 'OK')]
        assert all(r.trace_id == ctx.trace_id for r in audit.records)
        print('TEACHER_OFFLINE_DEMO', json.dumps(dict(
            pending=dataclasses.asdict(pending), executed=dataclasses.asdict(result),
            audit=[dataclasses.asdict(r) for r in audit.records]), ensure_ascii=False))
    run(demonstrate())
