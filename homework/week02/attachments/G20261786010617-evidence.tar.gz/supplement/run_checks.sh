#!/usr/bin/env bash
set -u
ROOT=/home/user/workspace/repo
BASE=$ROOT/.amp/in/orb-backup/grade19521
PY=$BASE/venv/bin/python
export PYTHONPATH=$BASE/student
export PYTHONDONTWRITEBYTECODE=1
run() {
  name=$1; shift
  printf 'COMMAND:' > "$BASE/evidence/logs/$name.log"
  printf ' %q' "$@" >> "$BASE/evidence/logs/$name.log"
  printf '\n' >> "$BASE/evidence/logs/$name.log"
  "$@" >> "$BASE/evidence/logs/$name.log" 2>&1
  code=$?
  echo "EXIT_CODE=$code" >> "$BASE/evidence/logs/$name.log"
  cat "$BASE/evidence/logs/$name.log"
}
run environment "$PY" -c 'import sys,platform,pydantic,pytest,tool_governance_demo as d;print(sys.version); print(platform.platform());print("pydantic",pydantic.__version__,"pytest",pytest.__version__);print("IMPORTED",d.__file__);print("strict",d.TransferArgs.model_config)'
run trusted "$PY" -m pytest "$BASE/evidence/trusted/test_tool_governance.py" -v -k transfer -p no:cacheprovider
run supplements "$PY" -m pytest "$BASE/evidence/supplement/test_additional.py" -v -s -p no:cacheprovider
run student_demo "$PY" "$BASE/student/tool_governance_demo.py"
