import ast
import asyncio
import inspect
import json
import time
from dataclasses import asdict
from pathlib import Path

import pytest
import tool_governance_demo as d

F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'
INITIAL = {('tenant_a', F): 100000.0, ('tenant_a', T): 5000.0,
           ('tenant_a', S): 20000.0, ('tenant_b', B): 50000.0}

@pytest.fixture(autouse=True)
def isolate():
    snapshot = dict(d.ACCOUNTS)
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(INITIAL)
    yield
    d.ACCOUNTS.clear()
    d.ACCOUNTS.update(snapshot)

def ctx(**kw):
    return d.base_context(**dict(permissions=frozenset({'transfer:execute', 'order:read'}),
                                allowed_tools=frozenset({'transfer', 'get_order'}), **kw))

async def invoke(args, approved=False, label='supp_123456'):
    r, approvals, audit = d.build_runtime()
    c = ctx()
    if approved:
        approvals.approve('supp', c, 'transfer', args)
        c = ctx(approval_id='supp')
    start = time.perf_counter()
    try:
        result = await r.invoke(d.ToolCall(label, 'transfer', args), c)
    except Exception as e:
        print('UNHANDLED', type(e).__name__, str(e), 'balances=', d.ACCOUNTS,
              'audit=', [asdict(x) for x in audit.records])
        raise
    print(label, asdict(result), 'elapsed=', time.perf_counter()-start,
          'balances=', d.ACCOUNTS, 'audit=', [asdict(x) for x in audit.records])
    return result, audit, approvals

def args(amount=100.0, source=F, target=T):
    return dict(from_account=source, to_account=target, amount=amount)

def test_A01_initial():
    # Read initial source state independently of fixture's normalized balances.
    print('ACTUAL_TEST_IMPORT', d.__file__)
    tree = ast.parse(Path(d.__file__).read_text())
    node = next(n for n in tree.body if isinstance(n, ast.AnnAssign) and getattr(n.target, 'id', '') == 'ACCOUNTS')
    original = ast.literal_eval(node.value)
    assert original == INITIAL
    assert all(type(v) is float for v in original.values())

@pytest.mark.parametrize('variant', [
    {k:v for k,v in args().items() if k != missing} for missing in args()
] + [{**args(), 'approved': True}, {**args(), 'user_id':'admin'}, args(-1.0),
     args('100'), args(source='ACC-123456'), args(target='ACC-A-12345X'), args(source=123)])
def test_A02_validation(variant):
    result, _, _ = asyncio.run(invoke(variant))
    assert result.code == 'INVALID_ARGUMENT'
    assert d.ACCOUNTS == INITIAL

@pytest.mark.parametrize('amount,code', [(50000.0,'APPROVAL_REQUIRED'),(50000.01,'EXCEED_LIMIT'),
    (80000.0,'EXCEED_LIMIT'),(80000.01,'APPROVAL_REQUIRED'),(100000.0,'APPROVAL_REQUIRED'),
    (100000.01,'INVALID_ARGUMENT')])
def test_A03_boundaries(amount, code):
    result, audit, _ = asyncio.run(invoke(args(amount)))
    assert result.code == code
    assert audit.records[-1].phase == 'decision'
    assert d.ACCOUNTS == INITIAL

@pytest.mark.parametrize('amount', [80000.01,100000.0])
def test_A03_approved_timeout(amount):
    start = time.perf_counter()
    result, audit, _ = asyncio.run(invoke(args(amount), True))
    assert result.code == 'TIMEOUT_UNKNOWN'
    assert 1.8 < time.perf_counter()-start < 3
    assert audit.records[-1].phase == 'execution'
    assert d.ACCOUNTS == INITIAL

@pytest.mark.parametrize('amount,code', [(30000.0,'INSUFFICIENT_BALANCE'), (60000.0,'EXCEED_LIMIT')])
def test_A04_order_and_approval(amount, code):
    for approved in (False, True):
        result, audit, approvals = asyncio.run(invoke(args(amount, S), approved))
        assert result.code == code
        assert result.action == d.DecisionAction.DENY
        assert audit.records[-1].phase == 'decision'
        if approved:
            assert not approvals._records['supp'].used
        assert d.ACCOUNTS == INITIAL

def test_A05_exact_balance():
    result, _, _ = asyncio.run(invoke(args(20000.0, S), True))
    assert result.ok
    assert d.ACCOUNTS[('tenant_a', S)] == 0
    assert d.ACCOUNTS[('tenant_a', T)] == 25000

def test_A06_missing_destination():
    result, _, _ = asyncio.run(invoke(args(target='ACC-A-999999'), True))
    assert (result.code, result.content, d.ACCOUNTS) == ('ACCOUNT_NOT_FOUND','转入账户不存在',INITIAL)

@pytest.mark.parametrize('source', [B, 'ACC-A-999999'])
def test_A07_cross_tenant_source(source):
    result, _, _ = asyncio.run(invoke(args(source=source)))
    assert not result.ok and result.action == d.DecisionAction.DENY
    assert result.code in ('INSUFFICIENT_BALANCE','ACCOUNT_NOT_FOUND')
    assert d.ACCOUNTS == INITIAL

def test_A07_cross_tenant_destination():
    result, _, _ = asyncio.run(invoke(args(target=B), True))
    assert (result.code, result.content, d.ACCOUNTS) == ('ACCOUNT_NOT_FOUND','转入账户不存在',INITIAL)

def test_A08_policy_binding():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    print('POLICY', asdict(tool.policy))
    assert tool.parameters_model is d.TransferArgs
    assert tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    p = tool.policy
    assert p.effect == d.Effect.WRITE and p.permission == 'transfer:execute'
    assert p.requires_approval or p.risk == d.Risk.HIGH
    assert 0 < p.timeout_seconds < 3 and not p.idempotent and p.max_retries == 0

def test_A08_canonical_target():
    tool = next(t for t in d.build_tools() if t.name == 'transfer')
    targets = [tool.canonical_target(d.TransferArgs(**a)) for a in
               [args(),args(source=S),args(target=S),args(101.0)]]
    print('TARGETS', targets)
    assert len(set(targets)) == 4

def test_A09_redaction_and_order():
    result, _, _ = asyncio.run(invoke(args(), True))
    assert result.content['from'] == 'ACC-A-****3456'
    assert result.content['to'] == 'ACC-A-****4321'
    r, _, _ = d.build_runtime()
    order = asyncio.run(r.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),ctx()))
    assert order.content['customer_email'] == '***@***'
    assert order.content['access_token'] == '***'
    assert d._redact({'nest':[{'password':'not-a-secret','v':('a@b.com',F)}]}) == {
        'nest':[{'password':'***','v':['***@***','ACC-A-****3456']}]}

def test_A10_fixed_engine():
    trusted = Path(__file__).resolve().parents[1] / 'trusted/tool_governance_demo-无答案.py'
    def method(text):
        tree = ast.parse(text)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PermissionEngine')
        return next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'decide')
    current = Path(d.__file__).read_text()
    orig = trusted.read_text()
    assert ast.get_source_segment(current, method(current)) == ast.get_source_segment(orig, method(orig))
    print('PermissionEngine.decide byte-for-byte source segment identical')

def test_A10_teacher_demo():
    # Simulated human confirmation; no model or real payment.
    async def demo():
        r, approvals, audit = d.build_runtime()
        c = ctx()
        a = args(1200.0)
        pending = await r.invoke(d.ToolCall('demo_pending','transfer',a),c)
        approvals.approve('human_simulation',c,'transfer',a)
        done = await r.invoke(d.ToolCall('demo_000003','transfer',a),ctx(approval_id='human_simulation'))
        print('TEACHER_DEMO', json.dumps({'confirmation':asdict(pending),'result':asdict(done),
              'audit':[asdict(x) for x in audit.records]},ensure_ascii=False,default=str))
        assert pending.action == d.DecisionAction.CONFIRM and done.ok
        assert [x.code for x in audit.records] == ['APPROVAL_REQUIRED','APPROVED','OK']
        assert {x.trace_id for x in audit.records} == {c.trace_id}
    asyncio.run(demo())
