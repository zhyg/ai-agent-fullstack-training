"""Check captured observations, not assignment pass/fail conversion."""
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
rows=[json.loads(s) for s in (root/"logs/supplemental.jsonl").read_text().splitlines()]
cases={r["case"]:r for r in rows}
assert cases["environment"]["module"].endswith(("student/tool_governance_demo.py", "source/tool_governance_demo.py"))
assert cases["environment"]["transfer_module"].endswith(("student/tools/transfer.py", "source/tools/transfer.py"))
assert cases["A10_fixed_engine"]["identical"] is False
assert len(set(cases["A08"]["targets"])) == 1
assert cases["A08"]["policy"]["permission"] == "transfer:create"
assert cases["N_numeric_string"]["result"]["ok"] is True
assert cases["N_permission_execute"]["result"]["error_code"] == "PERMISSION_DENIED"
assert cases["N_original_accounts_with_reason"]["result"]["error_code"] == "INVALID_ARGUMENT"
assert cases["N_missing_extra_reason"]["result"]["error_code"] == "INVALID_ARGUMENT"
assert cases["N_confirm"]["audit"][-1]["decision"] == "confirm"
assert cases["N_success_000003"]["result"]["content"]["status"] == "completed"
assert "txn_id" not in cases["N_success_000003"]["result"]["content"]
assert cases["N_success_000003"]["balances"]["('tenant_a', 'acc_1001')"]["balance"] == "750.00"
assert cases["N_full_balance"]["balances"]["('tenant_a', 'acc_1001')"]["balance"] == "0.00"
assert cases["N_success_000003:replay"]["result"]["error_code"] == "APPROVAL_REQUIRED"
for name in ["N_missing_target","N_missing_source","N_cross_from_account","N_cross_to_account","N_insufficient"]:
    assert cases[name]["result"]["error_code"] == "BUSINESS_RULE_DENIED"
    assert cases[name]["balances_unchanged"] is True
assert cases["N_missing_target"]["approval_used"]["grading_approval"] is False
assert cases["N_insufficient"]["approval_used"]["grading_approval"] is False
assert cases["A09_direct_redaction"]["result"]["from"] == "ACC-A-123456"
assert cases["A09_direct_redaction"]["result"]["nested"][0]["email"] == "***@***"
assert cases["A09_order"]["result"]["content"]["access_token"] == "***"
for label in ["A03_50000.0","A03_50000.01","A03_80000.0","A03_80000.01","A03_100000.0","A03_100000.01"]:
    assert cases[label]["result"]["error_code"] == "INVALID_ARGUMENT"
    assert cases[label]["balances_unchanged"] is True
print(f"Observation consistency OK: {len(rows)} captured records; assignment cases remain blocked, not passed")
