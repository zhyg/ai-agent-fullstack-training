#!/usr/bin/env bash
# Run from any directory after unpacking evidence. Use a preinstalled Python
# with source/requirements.txt dependencies; never needs model credentials.
set -u
ROOT="$(dirname "$(dirname "$(realpath "$0")")")"
PYTHON="${PYTHON:-python}"
export PYTHONPATH="$ROOT/source"
"$PYTHON" -m pytest "$ROOT/trusted/test_tool_governance.py" -v -k transfer
echo "TRUSTED_EXIT=$? (expected 1: five setup errors, not five assertion failures)"
"$PYTHON" "$ROOT/supplemental/probe.py" > "$ROOT/logs/supplemental.jsonl"
echo "PROBE_EXIT=$?"
"$PYTHON" "$ROOT/supplemental/check_observations.py"
echo "OBSERVATION_CHECK_EXIT=$?"
(cd "$ROOT/source" && "$PYTHON" -m pytest tests/test_tool_governance.py tests/test_transfer_governance.py -v)
echo "STUDENT_TEST_EXIT=$?"
(cd "$ROOT/source" && "$PYTHON" tool_governance_demo.py)
echo "ORIGINAL_DEMO_EXIT=$?"
