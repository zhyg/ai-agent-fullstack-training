"""Read-only grading probes. Business calls only through student's original Runtime.

No aliases, monkeypatches, model_construct, account seeding, or handler replacements.
Native-contract cases are controls, never substitutes for assignment-contract cases.
"""
import ast
import asyncio
import copy
import importlib
import inspect
import json
import platform
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

import pydantic
import pytest
import tool_governance_demo as d

t = importlib.import_module("tools.transfer")
ROOT = Path(__file__).resolve().parents[1]
F, T, S, B = "ACC-A-123456", "ACC-A-654321", "ACC-A-888888", "ACC-B-111111"
original = {"from_account": F, "to_account": T, "amount": 100.0}
native = {"from_account": "acc_1001", "to_account": "acc_1002", "amount": "250.00", "reason": "离线复核"}


def emit(label, **values):
    print(json.dumps({"case": label, **values}, ensure_ascii=False, default=str))


def context(native_permission=False):
    return d.ExecutionContext(
        trace_id="trace_grading_19489", user_id="u_100", tenant_id="tenant_a",
        permissions=frozenset({"order:read", "transfer:create" if native_permission else "transfer:execute"}),
        allowed_tools=frozenset({"transfer", "get_order"}),
    )


async def call(label, args, *, native_permission=False, approve=False, followup=None):
    t.reset_accounts()
    rt, approvals, audit = d.build_governance()
    ctx = context(native_permission)
    before = copy.deepcopy(t.ACCOUNTS)
    if approve:
        try:
            model = t.TransferArgs.model_validate(args)
        except pydantic.ValidationError as error:
            emit(label + ":approval_blocked", errors=error.errors(include_url=False))
        else:
            approvals.approve("grading_approval", user_id=ctx.user_id, tenant_id=ctx.tenant_id,
                              tool_name="transfer", args=model)
            ctx = replace(ctx, approval_id="grading_approval")
    start = time.perf_counter()
    result = await rt.invoke(d.ToolCall(label, "transfer", args), ctx)
    emit(label, arguments=args, result=asdict(result), elapsed=time.perf_counter()-start,
         balances_unchanged=t.ACCOUNTS == before, balances={str(k): v for k, v in t.ACCOUNTS.items()},
         audit=audit.records, approval_used={k:v.used for k,v in approvals._items.items()})
    if followup:
        replay = await rt.invoke(d.ToolCall(label + "_replay", "transfer", args), ctx)
        emit(label + ":replay", result=asdict(replay), audit=audit.records)
    return result


async def main():
    emit("environment", python=platform.python_version(), pydantic=pydantic.__version__,
         pytest=pytest.__version__, executable=sys.executable, module=d.__file__, transfer_module=t.__file__)
    emit("interface", missing=[x for x in ["build_runtime", "base_context", "reset_side_effects", "DecisionAction", "transfer_precheck", "transfer_handler"] if not hasattr(d,x)],
         strict_config=d.StrictArgs.model_config, schema=t.TransferArgs.model_json_schema())
    emit("A01", accounts={str(k):v for k,v in t.ACCOUNTS.items()},
         expected={str(k):v for k,v in {("tenant_a",F):100000.0,("tenant_a",T):5000.0,("tenant_a",S):20000.0,("tenant_b",B):50000.0}.items()})
    for key in original:
        await call("A02_missing_"+key, {k:v for k,v in original.items() if k != key})
    for key, value in [("approved", True), ("user_id", "u_admin"), ("amount", -1.0),
                       ("amount", "100.0"), ("from_account", "bad"), ("to_account", "bad")]:
        await call("A02_"+key+"_"+str(value), {**original, key:value})
    for amount in [50000.0,50000.01,80000.0,80000.01,100000.0,100000.01]:
        await call("A03_"+str(amount), {**original,"amount":amount})
    for amount in [80000.01,100000.0]:
        await call("A03_approved_"+str(amount), {**original,"amount":amount}, approve=True)
    for amount in [30000.0,60000.0]:
        await call("A04_"+str(amount), {**original,"from_account":S,"amount":amount}, approve=True)
    await call("A05_original_full", {**original,"from_account":S,"amount":20000.0}, approve=True)
    await call("A06_original_missing", {**original,"to_account":"ACC-A-999999"}, approve=True)
    for key in ["from_account","to_account"]:
        await call("A07_original_"+key, {**original,key:B}, approve=True)
    tool=t.build_transfer_tool()
    model=t.TransferArgs.model_validate(native)
    targets=[tool.canonical_target(t.TransferArgs.model_validate({**native,**change}),context(True))
             for change in [{},{"from_account":"acc_1003"},{"to_account":"acc_1003"},{"amount":"251.00"}]]
    emit("A08", policy=asdict(tool.policy), handler=tool.handler.__module__+":"+tool.handler.__name__,
         precheck=tool.precheck.__module__+":"+tool.precheck.__name__, targets=targets)
    emit("A09_direct_redaction", result=d.redact({"from":F,"to":T,"nested":[{"email":"alice@example.com","password":"synthetic","text":F}],"from_account":F}))
    rt,_,audit=d.build_governance()
    order=await rt.invoke(d.ToolCall("A09_order","get_order",{"order_id":"ord_1001"}),context())
    emit("A09_order",result=asdict(order),audit=audit.records)
    def method(path):
        text=path.read_text()
        tree=ast.parse(text)
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="PermissionEngine")
        node=next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=="decide")
        return ast.get_source_segment(text,node)
    ref=method(ROOT/"trusted"/"tool_governance_demo-无答案.py")
    actual=method(Path(d.__file__))
    (ROOT/"logs"/"fixed-engine-reference.txt").write_text(ref)
    (ROOT/"logs"/"fixed-engine-student.txt").write_text(actual)
    emit("A10_fixed_engine", identical=ref==actual, reference_lines=len(ref.splitlines()), actual_lines=len(actual.splitlines()))
    # Independent native-contract controls. These do not repair the assignment schema.
    await call("N_permission_execute",native)
    await call("N_confirm",native,native_permission=True)
    await call("N_original_accounts_with_reason",{**original,"reason":"离线复核"},native_permission=True)
    await call("N_missing_extra_reason",{k:v for k,v in native.items() if k != "reason"},native_permission=True)
    for key,value in [("approved",True),("user_id","u_admin"),("amount",-1.0),("to_account","bad")]:
        await call("N_schema_"+key,{**native,key:value},native_permission=True)
    await call("N_success_000003",native,native_permission=True,approve=True,followup=True)
    await call("N_full_balance",{**native,"amount":"1000.00"},native_permission=True,approve=True)
    await call("N_missing_target",{**native,"to_account":"acc_9999"},native_permission=True,approve=True)
    await call("N_missing_source",{**native,"from_account":"acc_9999"},native_permission=True)
    for key in ["from_account","to_account"]:
        await call("N_cross_"+key,{**native,key:"acc_2001"},native_permission=True)
    await call("N_insufficient",{**native,"amount":"1000.01"},native_permission=True,approve=True)
    await call("N_numeric_string",{**native,"amount":"1.00"},native_permission=True,approve=True)
    for amount in ["50000.01","80000.01","90000.00","100000.00"]:
        await call("N_amount_"+amount,{**native,"amount":amount},native_permission=True)
    emit("static_timeout", registered_handler_source=inspect.getsource(tool.handler))
    t.reset_accounts()


asyncio.run(main())
