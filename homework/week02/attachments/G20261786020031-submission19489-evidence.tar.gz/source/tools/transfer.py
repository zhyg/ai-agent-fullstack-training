from __future__ import annotations

import asyncio
import json
from dataclasses import asdict
from decimal import Decimal
from typing import Any

from pydantic import Field, field_validator, model_validator

from tool_governance_demo import (
    ApprovalStore,
    AuditSink,
    Effect,
    ExecutionContext,
    PermissionDecision,
    PermissionEngine,
    PolicyDenied,
    Risk,
    StrictArgs,
    ToolCall,
    ToolDefinition,
    ToolPolicy,
    ToolResult,
    ToolRuntime,
)

TRANSFER_MIN_AMOUNT = Decimal("0.01")
TRANSFER_MAX_AMOUNT = Decimal("10000.00")


class TransferArgs(StrictArgs):
    # 转账工具的参数契约：仅接受业务候选字段，拒绝身份/审批伪造与同账户互转，并限定教学金额区间 (0, 10000.00]。
    from_account: str = Field(pattern=r"^acc_[0-9]{4}$")
    to_account: str = Field(pattern=r"^acc_[0-9]{4}$")
    amount: Decimal = Field(
        gt=0,
        le=TRANSFER_MAX_AMOUNT,
        max_digits=10,
        decimal_places=2,
    )
    reason: str = Field(min_length=2, max_length=200)

    @field_validator("amount", mode="after")
    @classmethod
    def _normalize_amount_scale(cls, value: Decimal) -> Decimal:
        # 统一规范为两位小数，确保 250 / 250.0 / "250.00" 的审批摘要完全一致。
        return value.quantize(Decimal("0.01"))

    @model_validator(mode="after")
    def _reject_same_account(self) -> TransferArgs:
        if self.from_account == self.to_account:
            raise ValueError("转出账户与转入账户不能相同")
        return self


def _default_accounts() -> dict[tuple[str, str], dict[str, Any]]:
    return {
        ("tenant_a", "acc_1001"): {
            "owner": "alice",
            "account_no": "6222021001001001",
            "balance": "1000.00",
            "status": "active",
        },
        ("tenant_a", "acc_1002"): {
            "owner": "bob",
            "account_no": "6222021001001002",
            "balance": "200.00",
            "status": "active",
        },
        ("tenant_b", "acc_2001"): {
            "owner": "charlie",
            "account_no": "6222022002002001",
            "balance": "500.00",
            "status": "active",
        },
    }


# 示例转账账户数据源：按 (tenant_id, account_id) 严格隔离租户资金边界。
ACCOUNTS: dict[tuple[str, str], dict[str, Any]] = _default_accounts()
# 示例转账流水记录：用于核对真实副作用次数与对账追踪。
TRANSFERS: dict[str, dict[str, Any]] = {}


def reset_accounts() -> None:
    # 重置转账账户余额与流水，供测试和离线演示复现干净初始状态。
    ACCOUNTS.clear()
    ACCOUNTS.update(_default_accounts())
    TRANSFERS.clear()


async def check_transfer(args: StrictArgs, ctx: ExecutionContext) -> None:
    # 转账审批前业务预检：校验同租户账户存在性、状态和可用余额（允许满余额转出至 0.00）。
    assert isinstance(args, TransferArgs)
    source = ACCOUNTS.get((ctx.tenant_id, args.from_account))
    if source is None:
        raise PolicyDenied("BUSINESS_RULE_DENIED", "转出账户不存在或不属于当前租户")
    target = ACCOUNTS.get((ctx.tenant_id, args.to_account))
    if target is None:
        raise PolicyDenied("BUSINESS_RULE_DENIED", "转入账户不存在或不属于当前租户")
    if source.get("status") != "active" or target.get("status") != "active":
        raise PolicyDenied("BUSINESS_RULE_DENIED", "转出或转入账户当前状态不可转账")
    if args.amount > Decimal(source["balance"]):
        raise PolicyDenied("BUSINESS_RULE_DENIED", "转出账户余额不足")


async def transfer(
    args: StrictArgs,
    ctx: ExecutionContext,
    *,
    simulated_delay_seconds: float = 0.0,
) -> dict[str, Any]:
    # 转账写入处理器：在锁保护下再次校验余额；若提交前超时则绝不扣款，提交时原子更新双方余额与流水。
    assert isinstance(args, TransferArgs)
    if simulated_delay_seconds > 0:
        await asyncio.sleep(simulated_delay_seconds)

    source = ACCOUNTS.get((ctx.tenant_id, args.from_account))
    target = ACCOUNTS.get((ctx.tenant_id, args.to_account))
    if source is None or target is None:
        raise PolicyDenied("BUSINESS_RULE_DENIED", "账户不存在或不属于当前租户")

    amount = args.amount.quantize(Decimal("0.01"))
    source_balance = Decimal(source["balance"])
    target_balance = Decimal(target["balance"])
    if amount > source_balance:
        raise PolicyDenied("BUSINESS_RULE_DENIED", "转出账户余额不足")

    new_source_balance = (source_balance - amount).quantize(Decimal("0.01"))
    new_target_balance = (target_balance + amount).quantize(Decimal("0.01"))
    transfer_id = f"trf_{len(TRANSFERS) + 1:04d}"

    # 同步原子提交：确保前面任意 await 超时取消时不会留下半扣款脏状态。
    source["balance"] = str(new_source_balance)
    target["balance"] = str(new_target_balance)

    record = {
        "transfer_id": transfer_id,
        "idempotency_key": ctx.idempotency_key,
        "tenant_id": ctx.tenant_id,
        "from_account": args.from_account,
        "to_account": args.to_account,
        "from_account_no": source["account_no"],
        "to_account_no": target["account_no"],
        "amount": str(amount),
        "remaining_balance": str(new_source_balance),
        "status": "completed",
    }
    TRANSFERS[transfer_id] = record
    return dict(record)


def build_transfer_tool() -> ToolDefinition:
    # 组装受控转账工具定义，挂载至统一 ToolRuntime。
    return ToolDefinition(
        name="transfer",
        description="在当前租户账户间发起受控转账（需业务预检与一次性参数绑定审批）。",
        parameters_model=TransferArgs,
        policy=ToolPolicy(
            effect=Effect.WRITE,
            risk=Risk.HIGH,
            permission="transfer:create",
            requires_approval=True,
            timeout_seconds=2,
            max_retries=0,
            idempotent=False,
        ),
        handler=transfer,
        precheck=check_transfer,
        canonical_target=lambda _args, ctx: f"{ctx.tenant_id}:transfer",
    )


def _format_result(result: ToolResult) -> dict[str, Any]:
    action = (
        PermissionDecision.ALLOW
        if result.ok
        else PermissionDecision.CONFIRM
        if result.error_code in {"APPROVAL_REQUIRED", "CONFIRMATION_REQUIRED"}
        else PermissionDecision.DENY
    )
    return {
        "tool_call_id": result.tool_call_id,
        "tool_name": result.tool_name,
        "ok": result.ok,
        "action": action,
        "code": result.error_code or "OK",
        "content": result.content,
    }


async def run_transfer_demo(
    runtime: ToolRuntime | None = None,
    approvals: ApprovalStore | None = None,
    audit: AuditSink | None = None,
) -> None:
    # 无需模型的离线转账治理全链路演示：confirm -> 审批执行 + 脱敏 + 关联审计 -> 重放拒绝 -> 超时不扣款。
    reset_accounts()
    if runtime is None or approvals is None or audit is None:
        from tool_governance_demo import build_governance

        runtime, approvals, audit = build_governance()

    transfer_ctx = ExecutionContext(
        trace_id="trace_transfer_demo",
        user_id="u_100",
        tenant_id="tenant_a",
        permissions=frozenset({"transfer:create"}),
        allowed_tools=frozenset({"transfer"}),
    )
    transfer_arguments = {
        "from_account": "acc_1001",
        "to_account": "acc_1002",
        "amount": "250.00",
        "reason": "支付供应商货款",
    }

    print("=== 转账工具离线治理演示（无需模型） ===")
    # 1. 未审批先调用 -> confirm (APPROVAL_REQUIRED)，余额不变
    confirm_result = await runtime.invoke(ToolCall("trf_call_01", "transfer", transfer_arguments), transfer_ctx)
    print(json.dumps({"step": "1_confirm_required", **_format_result(confirm_result)}, ensure_ascii=False, default=str))

    # 2. 审批前预检拒绝（超余额与跨租户） -> deny (BUSINESS_RULE_DENIED)
    overdraft_result = await runtime.invoke(
        ToolCall("trf_call_02", "transfer", {**transfer_arguments, "amount": "9999.00"}),
        transfer_ctx,
    )
    print(json.dumps({"step": "2_precheck_overdraft_denied", **_format_result(overdraft_result)}, ensure_ascii=False, default=str))

    cross_tenant_result = await runtime.invoke(
        ToolCall("trf_call_03", "transfer", {**transfer_arguments, "to_account": "acc_2001"}),
        transfer_ctx,
    )
    print(json.dumps({"step": "3_precheck_cross_tenant_denied", **_format_result(cross_tenant_result)}, ensure_ascii=False, default=str))

    # 3. 签发参数绑定审批并执行 -> allow (OK)，输出账号脱敏结果与关联审计
    validated_args = TransferArgs.model_validate(transfer_arguments)
    approvals.approve(
        "approval_trf_01",
        user_id=transfer_ctx.user_id,
        tenant_id=transfer_ctx.tenant_id,
        tool_name="transfer",
        args=validated_args,
    )
    approved_ctx = ExecutionContext(
        **{**asdict(transfer_ctx), "approval_id": "approval_trf_01", "idempotency_key": "trf_call_04"}
    )
    executed_result = await runtime.invoke(ToolCall("trf_call_04", "transfer", transfer_arguments), approved_ctx)
    print(json.dumps({"step": "4_approved_transfer_redacted", **_format_result(executed_result)}, ensure_ascii=False, default=str))

    correlated_audits = [r for r in audit.records if r["tool_call_id"] == "trf_call_04"]
    print(json.dumps({"step": "4_correlated_audit", "records": correlated_audits}, ensure_ascii=False, default=str))

    # 4. 重放同一审批单 -> confirm (APPROVAL_REQUIRED)，余额不二次扣款
    replay_result = await runtime.invoke(ToolCall("trf_call_05", "transfer", transfer_arguments), approved_ctx)
    print(json.dumps({"step": "5_approval_replay_blocked", **_format_result(replay_result)}, ensure_ascii=False, default=str))

    # 5. 超时验证（超时前未提交记账 -> TIMEOUT_UNKNOWN，不扣款、不重试）
    balance_before_timeout = ACCOUNTS[("tenant_a", "acc_1001")]["balance"]

    async def slow_transfer(args: StrictArgs, ctx: ExecutionContext) -> dict[str, Any]:
        return await transfer(args, ctx, simulated_delay_seconds=0.2)

    timeout_approvals = ApprovalStore()
    timeout_audit = AuditSink()
    timeout_tool = ToolDefinition(
        name="transfer",
        description="超时验证用受控转账。",
        parameters_model=TransferArgs,
        policy=ToolPolicy(
            effect=Effect.WRITE,
            risk=Risk.HIGH,
            permission="transfer:create",
            requires_approval=True,
            timeout_seconds=0.05,
            max_retries=0,
            idempotent=False,
        ),
        handler=slow_transfer,
        precheck=check_transfer,
        canonical_target=lambda _args, ctx: f"{ctx.tenant_id}:transfer",
    )
    timeout_runtime = ToolRuntime([timeout_tool], PermissionEngine(), timeout_approvals, timeout_audit)
    timeout_approvals.approve(
        "approval_trf_timeout",
        user_id=transfer_ctx.user_id,
        tenant_id=transfer_ctx.tenant_id,
        tool_name="transfer",
        args=validated_args,
    )
    timeout_ctx = ExecutionContext(
        **{**asdict(transfer_ctx), "approval_id": "approval_trf_timeout", "idempotency_key": "trf_call_06"}
    )
    timeout_result = await timeout_runtime.invoke(ToolCall("trf_call_06", "transfer", transfer_arguments), timeout_ctx)
    balance_after_timeout = ACCOUNTS[("tenant_a", "acc_1001")]["balance"]
    print(
        json.dumps(
            {
                "step": "6_timeout_no_deduction",
                **_format_result(timeout_result),
                "balance_before": balance_before_timeout,
                "balance_after": balance_after_timeout,
                "deducted": balance_before_timeout != balance_after_timeout,
            },
            ensure_ascii=False,
            default=str,
        )
    )
    print(
        json.dumps(
            {
                "transfer_summary": {
                    "transfer_executions": len(TRANSFERS),
                    "acc_1001_balance": ACCOUNTS[("tenant_a", "acc_1001")]["balance"],
                    "acc_1002_balance": ACCOUNTS[("tenant_a", "acc_1002")]["balance"],
                    "audit_records": len(audit.records),
                }
            },
            ensure_ascii=False,
        )
    )
