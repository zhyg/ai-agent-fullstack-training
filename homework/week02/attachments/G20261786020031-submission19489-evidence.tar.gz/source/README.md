# 作业二：为治理框架增加“转账”工具 + Agent Tool Runtime 平台

本仓库采用清晰分层结构，同时包含：
1. **作业二必做（根目录兼容入口 + `tools/` 工具模块 + `tests/` 测试集）**：
   - [tool_governance_demo.py](tool_governance_demo.py)：原课程治理框架入口，**原样保留 `PermissionEngine.decide`** 及固定门禁顺序，装配并向根目录兼容转发 `tools.transfer`；
   - [tools/transfer.py](tools/transfer.py)：独立封装的高风险 **`transfer` 转账工具模块**（`TransferArgs`、`ACCOUNTS`、`TRANSFERS`、`check_transfer`、`transfer`、`build_transfer_tool`、`run_transfer_demo`）；
   - [tests/test_tool_governance.py](tests/test_tool_governance.py) & [tests/test_transfer_governance.py](tests/test_transfer_governance.py)：原 14 项治理测试 + 13 项转账专项测试。
2. **阶段二综合平台（`py_service/` + `runtime/`）**：在第一单元 `llm_gateway` 之上实现的双语言「Agent 工具调用基础设施 v2」（Python 订单服务 + TypeScript `pi` ToolRuntime + 真实瑞幸咖啡 Streamable HTTP MCP 分层治理）。

---

## 0. 作业二必做：转账工具治理（无需模型 / 离线一键验证）

```bash
# 安装依赖（仅需 pydantic、pytest、pytest-asyncio）
python3 -m pip install -r requirements.txt

# 1. 语法编译检查
python3 -m py_compile tool_governance_demo.py tools/transfer.py tests/test_tool_governance.py tests/test_transfer_governance.py

# 2. 无需模型的离线演示（含原有治理流程 + 转账 confirm -> 预检拒绝 -> 审批执行与账号脱敏 + 关联审计 -> 审批防重放 -> 超时不扣款）
python3 tool_governance_demo.py

# 3. 运行原始 14 项治理测试 + 新增 13 项转账专项验收测试
python3 -m pytest tests/test_tool_governance.py tests/test_transfer_governance.py -v
```

### 转账工具治理关键契约一览
- **工具名与权限**：`transfer`（`Effect.WRITE`、`Risk.HIGH`、`permission="transfer:create"`、`requires_approval=True`、`idempotent=False`、`max_retries=0`、`timeout_seconds=2`）。
- **固定权限引擎**：`PermissionEngine.decide` 与原附件保持逐字节一致，未做任何绕过修改。
- **严格参数契约（`TransferArgs(StrictArgs)`）**：`extra="forbid"` 拒绝伪造 `user_id`/`tenant_id`/`approved`；账户格式 `^acc_[0-9]{4}$` 且禁止同账户互转；教学金额区间 `(0, 10000.00]`（最多两位小数）。
- **审批前预检（`check_transfer`）**：在 `ApprovalStore.consume` 之前校验 `(tenant_id, from_account)` 与 `(tenant_id, to_account)` 归属、账户激活状态与余额（允许满余额转出至 `0.00`；余额不足、缺失账户或跨租户均在审批前返回 `BUSINESS_RULE_DENIED`）。
- **脱敏、关联审计与超时安全**：`redact()` 对账户号与银行账号做不可逆掩码（如 `acc_**01`、`6222********1001`）；`AuditSink` 记录统一关联 `trace_id`、`tool_call_id`、`approval_id` 与 `argument_keys`；提交前超时返回 `TIMEOUT_UNKNOWN` 且原子不扣款、不重试。

---

## 1. 阶段二综合平台：克隆后零假设安装与测试（离线可跑）

所有命令均在仓库根目录 `tool_platform/` 下以相对路径执行。

### 1.1 配置环境变量

```bash
cd tool_platform
cp .env.example .env
# 编辑 .env 填入 GATEWAY_API_KEY / APPROVAL_API_KEY / LUCKIN_MCP_TOKEN（如跑离线测试可先留空）
```

> 环境变量加载优先级：**当前进程已导出的环境变量 > `tool_platform/.env` > 上级目录 `.env`**，不会覆盖外部显式传入的变量。

### 1.2 安装并测试 Python 业务服务（`py_service`）

```bash
cd py_service
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m app.export_schemas
.venv/bin/python -m pytest -q tests
```

### 1.3 安装、构建并测试 TypeScript + pi Runtime（需 Node.js >= 22.19）

```bash
cd ../runtime
npm install
npm run build
npm test                 # 离线单元测试（策略、审批、重试退避、TIMEOUT_UNKNOWN、审计降级、LoopGuard）
npm run test:mcp         # 本地 stdio MCP 集成测试 + platform.yaml 瑞幸治理契约校验
```

---

## 2. 启动联调服务（需接入第一单元 Gateway）

> 启动前请先按第一单元 `llm_gateway/README.md` 启动或指向可用的 `llm_gateway`（默认地址 `http://127.0.0.1:8003/v1`）。若同一工作区下同级存在 `../llm_gateway`，可直接如下启动：

**终端 1 — 第一单元统一模型网关（:8003）：**

```bash
cd ../llm_gateway
GATEWAY_CONFIG=../tool_platform/config/gateway.example.json \
  .venv/bin/python -m app.main
```

**终端 2 — 注册受控 Prompt 并启动 Python 订单服务（:8004）：**

```bash
cd tool_platform/py_service
set -a && . ../.env && set +a
.venv/bin/python -m app.seed_prompt --gateway-url http://127.0.0.1:8003
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8004
```

**终端 3 — 运行 Runtime CLI 与审批 API：**

```bash
cd tool_platform/runtime
npm run cli -- tools                               # 查看本地/Python/瑞幸 MCP 工具与风险分级
npm run cli -- tools --without-mcp                 # 不连接外部 MCP，仅看本地与 Python 工具
npm run approval-api                               # 可选：启动 HTTP 审批与审计查询 API（:8787）
```

---

## 3. 真实瑞幸咖啡 MCP（`my-coffee`）与人工审批用法

[platform.yaml](config/platform.yaml) 对 `my-coffee` 实施按副作用分层治理：
- **只读工具（`coffee:read`，免审批直通，`idempotent: true`）**：`queryShopList`、`searchProductForMcp`、`queryProductDetailInfo`、`switchProduct`、`previewOrder`、`queryOrderDetailInfo`
- **高风险写工具（`coffee:order`，`high` 风险，`idempotent: false`，强制参数绑定审批）**：`createOrder`、`cancelOrder`
- **未列入的未知远端工具**：默认按 `default_risk: high` + `requires_confirmation: true` 拦截。

### 方式 A：多轮交互模式（推荐，支持上下文记忆与终端直接确认）

```bash
cd tool_platform/runtime
npm run cli -- chat
# 示例输入：在东华门大街店(deptId=612691)帮我下单一杯大杯冰生椰拿铁，经度116.397纬度39.908
# 触发 createOrder 时终端会提示输入 y 批准并立即执行
```

### 方式 B：单轮命令行 + 独立审批指令

```bash
# 1. 只读查门店（无需审批，终端会一并打印 audit_records 与 trace_events）
npm run cli -- agent "帮我查一下经度 116.397 纬度 39.908 附近的瑞幸咖啡门店"

# 2. Plan 模式拒绝写操作（零副作用）
npm run cli -- agent "帮我给 ORD-A-1001 建一个工单，标题是包装破损" --mode plan

# 3. 发起下单，Runtime 会暂停并返回 pending_approval_id 与下一步审批命令
npm run cli -- agent "在东华门大街店(deptId=612691)帮我下单一杯大杯冰生椰拿铁，经度116.397纬度39.908"
npm run cli -- approvals list
npm run cli -- approvals decide <approval-id> --decision approve --actor owner
npm run cli -- approvals execute <approval-id>

# 4. 查询审计与链路 Trace
npm run cli -- audit
npm run cli -- trace <trace-id>
```

### 实时联调验收（需配置真实 `GATEWAY_API_KEY` 与 `LUCKIN_MCP_TOKEN`）

```bash
cd tool_platform/runtime
npm run test:live
```
