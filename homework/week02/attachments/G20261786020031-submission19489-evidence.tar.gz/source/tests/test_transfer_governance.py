from __future__ import annotations

import asyncio
import inspect
from dataclasses import replace
from decimal import Decimal
from typing import Any

from tool_governance_demo import (
    ACCOUNTS,
    TRANSFERS,
    ApprovalStore,
    AuditSink,
    Effect,
    ExecutionContext,
    PermissionDecision,
    PermissionEngine,
    PermissionMode,
    Risk,
    StrictArgs,
    ToolCall,
    ToolDefinition,
    ToolPolicy,
    ToolRuntime,
    TransferArgs,
    TransientToolError,
    _approval_digest,
    build_governance,
    check_transfer,
    redact,
    reset_accounts,
    transfer,
)


TRANSFER_ARGUMENTS: dict[str, Any] = {
    "from_account": "acc_1001",
    "to_account": "acc_1002",
    "amount": "250.00",
    "reason": "支付供应商货款",
}


def transfer_context(
    *,
    tenant_id: str = "tenant_a",
    permissions: frozenset[str] = frozenset({"transfer:create"}),
    allowed_tools: frozenset[str] = frozenset({"transfer"}),
    mode: PermissionMode = PermissionMode.DEFAULT,
    approval_id: str | None = None,
    idempotency_key: str | None = None,
) -> ExecutionContext:
    return ExecutionContext(
        trace_id="trace_transfer_test",
        user_id="u_100",
        tenant_id=tenant_id,
        permissions=permissions,
        allowed_tools=allowed_tools,
        mode=mode,
        approval_id=approval_id,
        idempotency_key=idempotency_key,
    )


def approve_transfer(
    approvals: ApprovalStore,
    approval_id: str,
    ctx: ExecutionContext,
    arguments: dict[str, Any],
) -> None:
    approvals.approve(
        approval_id,
        user_id=ctx.user_id,
        tenant_id=ctx.tenant_id,
        tool_name="transfer",
        args=TransferArgs.model_validate(arguments),
    )


def test_permission_engine_decide_remains_unchanged() -> None:
    source = inspect.getsource(PermissionEngine.decide)
    assert "if tool.name not in ctx.allowed_tools:" in source
    assert "if tool.policy.permission not in ctx.permissions:" in source
    assert "return PermissionDecision.ALLOW" in source
    assert "transfer" not in source


def test_transfer_strict_schema_rejects_forged_fields_and_invalid_ranges() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, _, _ = build_governance()
        ctx = transfer_context()

        invalid_cases = [
            {**TRANSFER_ARGUMENTS, "user_id": "admin", "approved": True},
            {**TRANSFER_ARGUMENTS, "tenant_id": "tenant_b"},
            {**TRANSFER_ARGUMENTS, "from_account": "acc_1001", "to_account": "acc_1001"},
            {**TRANSFER_ARGUMENTS, "amount": "0"},
            {**TRANSFER_ARGUMENTS, "amount": "-50.00"},
            {**TRANSFER_ARGUMENTS, "amount": "10000.01"},
            {**TRANSFER_ARGUMENTS, "amount": "12.345"},
            {**TRANSFER_ARGUMENTS, "from_account": "bad_acc"},
        ]
        for idx, args in enumerate(invalid_cases, 1):
            result = await runtime.invoke(ToolCall(f"schema_{idx}", "transfer", args), ctx)
            assert result.ok is False
            assert result.error_code == "INVALID_ARGUMENT"

        assert TRANSFERS == {}
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "1000.00"

    asyncio.run(run())


def test_transfer_teaching_amount_upper_bound_is_allowed() -> None:
    async def run() -> None:
        reset_accounts()
        ACCOUNTS[("tenant_a", "acc_1001")]["balance"] = "10000.00"
        runtime, approvals, _ = build_governance()
        args = {**TRANSFER_ARGUMENTS, "amount": "10000.00"}
        ctx = transfer_context()
        approve_transfer(approvals, "app_max", ctx, args)

        result = await runtime.invoke(
            ToolCall("trf_max", "transfer", args),
            replace(ctx, approval_id="app_max", idempotency_key="trf_max"),
        )
        assert result.ok is True
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "0.00"
        assert ACCOUNTS[("tenant_a", "acc_1002")]["balance"] == "10200.00"

    asyncio.run(run())


def test_transfer_precheck_denies_before_approval_for_balance_missing_and_cross_tenant() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, _, _ = build_governance()
        ctx = transfer_context()  # 故意不传 approval_id，证明在审批前即被业务预检拒绝

        # 余额不足
        r_balance = await runtime.invoke(
            ToolCall("pre_bal", "transfer", {**TRANSFER_ARGUMENTS, "amount": "1000.01"}),
            ctx,
        )
        assert r_balance.error_code == "BUSINESS_RULE_DENIED"

        # 转出账户缺失
        r_missing_src = await runtime.invoke(
            ToolCall("pre_src", "transfer", {**TRANSFER_ARGUMENTS, "from_account": "acc_9999"}),
            ctx,
        )
        assert r_missing_src.error_code == "BUSINESS_RULE_DENIED"

        # 转入账户缺失
        r_missing_dst = await runtime.invoke(
            ToolCall("pre_dst", "transfer", {**TRANSFER_ARGUMENTS, "to_account": "acc_9999"}),
            ctx,
        )
        assert r_missing_dst.error_code == "BUSINESS_RULE_DENIED"

        # 跨租户转入（tenant_a -> tenant_b 的 acc_2001）
        r_cross_dst = await runtime.invoke(
            ToolCall("pre_cross_dst", "transfer", {**TRANSFER_ARGUMENTS, "to_account": "acc_2001"}),
            ctx,
        )
        assert r_cross_dst.error_code == "BUSINESS_RULE_DENIED"

        # 跨租户转出（tenant_a 试图操作 tenant_b 的 acc_2001）
        r_cross_src = await runtime.invoke(
            ToolCall("pre_cross_src", "transfer", {**TRANSFER_ARGUMENTS, "from_account": "acc_2001"}),
            ctx,
        )
        assert r_cross_src.error_code == "BUSINESS_RULE_DENIED"

        assert TRANSFERS == {}
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "1000.00"
        assert ACCOUNTS[("tenant_b", "acc_2001")]["balance"] == "500.00"

    asyncio.run(run())


def test_transfer_exact_full_balance_succeeds_to_zero() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, approvals, _ = build_governance()
        args = {**TRANSFER_ARGUMENTS, "amount": "1000.00"}
        ctx = transfer_context()
        approve_transfer(approvals, "app_full", ctx, args)

        result = await runtime.invoke(
            ToolCall("trf_full", "transfer", args),
            replace(ctx, approval_id="app_full", idempotency_key="trf_full"),
        )
        assert result.ok is True
        assert result.content["remaining_balance"] == "0.00"
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "0.00"
        assert ACCOUNTS[("tenant_a", "acc_1002")]["balance"] == "1200.00"

    asyncio.run(run())


def test_transfer_requires_confirm_binds_parameters_and_blocks_replay() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, approvals, audit = build_governance()
        ctx = transfer_context()

        # 1. 无审批返回 confirm (APPROVAL_REQUIRED)
        r_confirm = await runtime.invoke(ToolCall("trf_01", "transfer", TRANSFER_ARGUMENTS), ctx)
        assert r_confirm.ok is False
        assert r_confirm.error_code == "APPROVAL_REQUIRED"
        assert audit.records[-1]["decision"] == PermissionDecision.CONFIRM
        assert TRANSFERS == {}

        # 2. 审批绑定 100.00，但调用传 250.00 -> 拒绝
        approve_transfer(approvals, "app_100", ctx, {**TRANSFER_ARGUMENTS, "amount": "100.00"})
        r_tamper = await runtime.invoke(
            ToolCall("trf_02", "transfer", TRANSFER_ARGUMENTS),
            replace(ctx, approval_id="app_100"),
        )
        assert r_tamper.error_code == "APPROVAL_REQUIRED"
        assert TRANSFERS == {}

        # 3. 匹配审批执行成功，且账号已脱敏、审计关联 trace_id / tool_call_id / approval_id
        approve_transfer(approvals, "app_250", ctx, TRANSFER_ARGUMENTS)
        approved_ctx = replace(ctx, approval_id="app_250", idempotency_key="trf_03")
        r_ok = await runtime.invoke(ToolCall("trf_03", "transfer", TRANSFER_ARGUMENTS), approved_ctx)
        assert r_ok.ok is True
        assert r_ok.content["from_account"] == "acc_**01"
        assert r_ok.content["to_account"] == "acc_**02"
        assert r_ok.content["from_account_no"] == "6222********1001"
        assert r_ok.content["to_account_no"] == "6222********1002"
        assert "acc_1001" not in str(r_ok.content)
        assert "6222021001001001" not in str(r_ok.content)

        payload = r_ok.to_model_payload()
        assert payload["untrusted"] is True
        assert "acc_1001" not in str(payload)

        trf_audits = [r for r in audit.records if r["tool_call_id"] == "trf_03"]
        assert len(trf_audits) == 2
        assert all(r["trace_id"] == "trace_transfer_test" for r in trf_audits)
        assert all(r["approval_id"] == "app_250" for r in trf_audits)
        assert trf_audits[-1]["ok"] is True

        # 4. 重放同一审批单 -> 拒绝，余额不二次扣除
        r_replay = await runtime.invoke(ToolCall("trf_04", "transfer", TRANSFER_ARGUMENTS), approved_ctx)
        assert r_replay.ok is False
        assert r_replay.error_code == "APPROVAL_REQUIRED"
        assert len(TRANSFERS) == 1
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "750.00"
        assert ACCOUNTS[("tenant_a", "acc_1002")]["balance"] == "450.00"

    asyncio.run(run())


def test_transfer_rbac_allowlist_and_plan_mode_keep_zero_side_effects() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, _, _ = build_governance()

        r_plan = await runtime.invoke(
            ToolCall("trf_plan", "transfer", TRANSFER_ARGUMENTS),
            transfer_context(mode=PermissionMode.PLAN),
        )
        assert r_plan.error_code == "PLAN_MODE_DENIED"

        r_rbac = await runtime.invoke(
            ToolCall("trf_rbac", "transfer", TRANSFER_ARGUMENTS),
            transfer_context(permissions=frozenset({"order:read"})),
        )
        assert r_rbac.error_code == "PERMISSION_DENIED"

        r_allow = await runtime.invoke(
            ToolCall("trf_allow", "transfer", TRANSFER_ARGUMENTS),
            transfer_context(allowed_tools=frozenset({"get_order"})),
        )
        assert r_allow.error_code == "TOOL_NOT_ALLOWED"

        assert TRANSFERS == {}
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "1000.00"

    asyncio.run(run())


def test_transfer_timeout_returns_timeout_unknown_without_deduction_or_retry() -> None:
    async def run() -> None:
        reset_accounts()
        attempts = 0

        async def slow_handler(args: StrictArgs, ctx: ExecutionContext) -> dict[str, Any]:
            nonlocal attempts
            attempts += 1
            return await transfer(args, ctx, simulated_delay_seconds=0.2)

        approvals = ApprovalStore()
        audit = AuditSink()
        tool = ToolDefinition(
            name="transfer",
            description="超时转账测试。",
            parameters_model=TransferArgs,
            policy=ToolPolicy(
                effect=Effect.WRITE,
                risk=Risk.HIGH,
                permission="transfer:create",
                requires_approval=True,
                timeout_seconds=0.05,
                max_retries=2,  # 非幂等写操作即使误配 max_retries，Runtime 也绝不重试
                idempotent=False,
            ),
            handler=slow_handler,
            precheck=check_transfer,
            canonical_target=lambda args, ctx: f"{ctx.tenant_id}:transfer:{args.from_account}",
        )
        runtime = ToolRuntime([tool], PermissionEngine(), approvals, audit)
        ctx = transfer_context()
        approve_transfer(approvals, "app_timeout", ctx, TRANSFER_ARGUMENTS)

        result = await runtime.invoke(
            ToolCall("trf_timeout", "transfer", TRANSFER_ARGUMENTS),
            replace(ctx, approval_id="app_timeout", idempotency_key="trf_timeout"),
        )
        assert result.ok is False
        assert result.error_code == "TIMEOUT_UNKNOWN"
        assert attempts == 1
        assert TRANSFERS == {}
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "1000.00"
        assert ACCOUNTS[("tenant_a", "acc_1002")]["balance"] == "200.00"

        # 超时后也不得把一次性审批单重置为未使用（重放必须拒绝）
        replay_after_timeout = await runtime.invoke(
            ToolCall("trf_timeout_replay", "transfer", TRANSFER_ARGUMENTS),
            replace(ctx, approval_id="app_timeout", idempotency_key="trf_timeout_replay"),
        )
        assert replay_after_timeout.error_code == "APPROVAL_REQUIRED"
        assert attempts == 1

        # 非幂等写操作瞬态失败同样不重试
        transient_attempts = 0

        async def flaky_handler(_args: StrictArgs, _ctx: ExecutionContext) -> dict[str, Any]:
            nonlocal transient_attempts
            transient_attempts += 1
            raise TransientToolError("bank gateway transient error")

        flaky_tool = replace(tool, handler=flaky_handler)
        flaky_approvals = ApprovalStore()
        flaky_runtime = ToolRuntime([flaky_tool], PermissionEngine(), flaky_approvals, AuditSink())
        approve_transfer(flaky_approvals, "app_flaky", ctx, TRANSFER_ARGUMENTS)
        r_flaky = await flaky_runtime.invoke(
            ToolCall("trf_flaky", "transfer", TRANSFER_ARGUMENTS),
            replace(ctx, approval_id="app_flaky"),
        )
        assert r_flaky.error_code == "TEMPORARY_UNAVAILABLE"
        assert transient_attempts == 1
        assert Decimal(ACCOUNTS[("tenant_a", "acc_1001")]["balance"]) == Decimal("1000.00")

    asyncio.run(run())


def test_transfer_amount_canonicalization_produces_identical_approval_digest() -> None:
    a_int = TransferArgs.model_validate({**TRANSFER_ARGUMENTS, "amount": 250})
    a_one_dec = TransferArgs.model_validate({**TRANSFER_ARGUMENTS, "amount": "250.0"})
    a_two_dec = TransferArgs.model_validate({**TRANSFER_ARGUMENTS, "amount": "250.00"})
    assert a_int.amount == a_one_dec.amount == a_two_dec.amount == Decimal("250.00")
    assert _approval_digest("transfer", a_int) == _approval_digest("transfer", a_one_dec)
    assert _approval_digest("transfer", a_int) == _approval_digest("transfer", a_two_dec)


def test_transfer_approval_rejects_expired_wrong_user_and_target_tamper() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, approvals, _ = build_governance()
        ctx = transfer_context()

        # 过期审批
        approvals.approve(
            "app_expired",
            user_id=ctx.user_id,
            tenant_id=ctx.tenant_id,
            tool_name="transfer",
            args=TransferArgs.model_validate(TRANSFER_ARGUMENTS),
            ttl_seconds=-1,
        )
        r_exp = await runtime.invoke(
            ToolCall("trf_exp", "transfer", TRANSFER_ARGUMENTS),
            replace(ctx, approval_id="app_expired"),
        )
        assert r_exp.error_code == "APPROVAL_REQUIRED"

        # 跨用户盗用审批单
        approve_transfer(approvals, "app_other_user", ctx, TRANSFER_ARGUMENTS)
        r_other = await runtime.invoke(
            ToolCall("trf_other", "transfer", TRANSFER_ARGUMENTS),
            replace(ctx, user_id="u_999", approval_id="app_other_user"),
        )
        assert r_other.error_code == "APPROVAL_REQUIRED"

        # 改原因后审批失效
        r_reason = await runtime.invoke(
            ToolCall("trf_reason", "transfer", {**TRANSFER_ARGUMENTS, "reason": "篡改后的转账备注"}),
            replace(ctx, approval_id="app_other_user"),
        )
        assert r_reason.error_code == "APPROVAL_REQUIRED"
        assert TRANSFERS == {}

    asyncio.run(run())


def test_transfer_cannot_bypass_approval_in_bypass_or_dont_ask_mode() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, _, _ = build_governance()

        r_bypass = await runtime.invoke(
            ToolCall("trf_bypass", "transfer", TRANSFER_ARGUMENTS),
            transfer_context(mode=PermissionMode.BYPASS_PERMISSIONS),
        )
        assert r_bypass.error_code == "APPROVAL_REQUIRED"

        r_dont_ask = await runtime.invoke(
            ToolCall("trf_dont_ask", "transfer", TRANSFER_ARGUMENTS),
            transfer_context(mode=PermissionMode.DONT_ASK),
        )
        assert r_dont_ask.error_code == "APPROVAL_REQUIRED"
        assert TRANSFERS == {}

    asyncio.run(run())


def test_transfer_precheck_denies_frozen_account_and_redact_masks_inline_bank_no() -> None:
    async def run() -> None:
        reset_accounts()
        ACCOUNTS[("tenant_a", "acc_1001")]["status"] = "frozen"
        runtime, _, _ = build_governance()
        r_frozen = await runtime.invoke(ToolCall("trf_frozen", "transfer", TRANSFER_ARGUMENTS), transfer_context())
        assert r_frozen.error_code == "BUSINESS_RULE_DENIED"
        assert TRANSFERS == {}

        masked = redact("从 acc_1001 向银行卡 6222021001001002 转账")
        assert "acc_1001" not in masked
        assert "6222021001001002" not in masked
        assert "acc_**01" in masked
        assert "6222********1002" in masked

    asyncio.run(run())


def test_concurrent_transfers_in_same_tenant_cannot_overdraft() -> None:
    async def run() -> None:
        reset_accounts()
        runtime, approvals, _ = build_governance()
        args = {**TRANSFER_ARGUMENTS, "amount": "600.00"}
        ctx = transfer_context()
        approve_transfer(approvals, "app_c1", ctx, args)
        approve_transfer(approvals, "app_c2", ctx, args)

        r1, r2 = await asyncio.gather(
            runtime.invoke(ToolCall("c1", "transfer", args), replace(ctx, approval_id="app_c1", idempotency_key="c1")),
            runtime.invoke(ToolCall("c2", "transfer", args), replace(ctx, approval_id="app_c2", idempotency_key="c2")),
        )
        ok_count = sum(1 for r in (r1, r2) if r.ok)
        denied_codes = [r.error_code for r in (r1, r2) if not r.ok]
        assert ok_count == 1
        assert denied_codes == ["BUSINESS_RULE_DENIED"]
        assert ACCOUNTS[("tenant_a", "acc_1001")]["balance"] == "400.00"
        assert ACCOUNTS[("tenant_a", "acc_1002")]["balance"] == "800.00"

    asyncio.run(run())
