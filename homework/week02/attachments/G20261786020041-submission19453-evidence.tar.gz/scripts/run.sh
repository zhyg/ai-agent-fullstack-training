#!/usr/bin/env bash
set -u
HERE=$(cd "$(dirname "$0")/.." && pwd)
STUDENT=${1:-"$HERE/source"}
PYTHON=${PYTHON:-python}
mkdir -p "$HERE/logs"
run() {
  local name=$1; shift
  printf 'COMMAND:' > "$HERE/logs/$name.log"
  printf ' %q' "$@" >> "$HERE/logs/$name.log"
  printf '\nCWD: %s\n' "$PWD" >> "$HERE/logs/$name.log"
  "$@" >> "$HERE/logs/$name.log" 2>&1
  local result=$?
  printf '\nEXIT_CODE: %s\n' "$result" >> "$HERE/logs/$name.log"
  printf '%s exit=%s\n' "$name" "$result"
}
run environment bash -c 'set -e; date -Iseconds; node --version; npm --version; "$1" --version; "$1" -c "import importlib.metadata as m; print({k:m.version(k) for k in [\"pydantic\",\"pytest\"]})"; realpath "$2/src/index.js"' _ "$PYTHON" "$STUDENT"
run original-five "$PYTHON" -m pytest "$HERE/original-tests/test_tool_governance.py" -v -k transfer
run student-tests npm --prefix "$STUDENT" test
run student-demo npm --prefix "$STUDENT" start
run independent-probes node "$HERE/scripts/probes.mjs" "$STUDENT"
