// Read-only source evaluation: no source rewriting, no handler calls.
// Native interface evidence is NOT a pass of the original Python tests.
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const source = resolve(process.argv[2] ?? '../student');
const d = await import(pathToFileURL(resolve(source, 'src/index.js')));
const json = x => JSON.stringify(x, (_, v) => typeof v === 'bigint' ? `${v}n` : v);
console.log('IMPORT', resolve(source, 'src/index.js'));
let failed = 0, passed = 0;
function check(id, actual, expected) {
  try { assert.deepEqual(actual, expected); passed++; console.log('PASS', id, json(actual)); }
  catch { failed++; console.log('FAIL', id, 'actual=', json(actual), 'expected=', json(expected)); }
}
const ctx = overrides => new d.ExecutionContext({traceId:'grading_trace',userId:'grading_user',tenantId:'tenant_a',permissions:['transfer:create','order:read'],allowedTools:['create_transfer','get_order'],...overrides});
const args = (amount=100, extra={}) => ({from_account:'acc_2001',to_account:'acc_2002',amount,currency:'CNY',...extra});
const snapshot = () => json([...d.ACCOUNTS]);
let sequence = 0;
function fresh(seed=false) {
  d.resetBusinessData();
  if (seed) {
    // Explicit fixture for balance / tenant cases absent from student initial data.
    d.ACCOUNTS.set('tenant_a:acc_2003',{status:'active',balance_cents:2000000n});
    d.ACCOUNTS.set('tenant_b:acc_9001',{status:'active',balance_cents:5000000n});
  }
  return d.buildGovernance();
}
async function invoke(s, a, options={}) {
  const id=options.id ?? `call_probe_${++sequence}`;
  const c=ctx(options.context);
  if (options.approve) s.approvals.approve('grading_approval',{userId:c.userId,tenantId:c.tenantId,toolName:'create_transfer',args:d.TransferArgs.validate(a)});
  const start=performance.now();
  const r=await s.runtime.invoke(new d.ToolCall({id,name:options.name??'create_transfer',arguments:a}),c.with({...(options.approve?{approvalId:'grading_approval'}:{}),...(options.key?{idempotencyKey:options.key}: {})}));
  console.log('OBS',json({id,args:a,result:r,elapsed_ms:performance.now()-start,accounts:[...d.ACCOUNTS],audit:s.audit.records}));
  return r;
}
let s=fresh();
console.log('A01_INITIAL',snapshot());
check('A01 initial account keys',[...d.ACCOUNTS.keys()],['tenant_a:ACC-A-123456','tenant_a:ACC-A-654321','tenant_a:ACC-A-888888','tenant_b:ACC-B-111111']);
const original={from_account:'ACC-A-123456',to_account:'ACC-A-654321',amount:100};
check('T-interface original tool registered',s.runtime.tools.has('transfer'),true);
check('A02 original args on native tool',(await invoke(s,original)).errorCode,'APPROVAL_REQUIRED');
for (const field of ['from_account','to_account','amount']) {
  const a=args(); delete a[field];
  check(`A02 missing ${field}`,(await invoke(fresh(),a)).errorCode,'INVALID_ARGUMENT');
}
for (const [name,patch] of [['approved',{approved:true}],['user_id',{user_id:'admin'}],['zero',{amount:0}],['negative',{amount:-1}],['bad from',{from_account:'broken'}],['bad to',{to_account:'broken'}]]) {
  s=fresh(); const before=snapshot();
  check(`A02 ${name}`,(await invoke(s,args(100,patch))).errorCode,'INVALID_ARGUMENT');
  check(`A02 ${name} no writes`,snapshot(),before);
}
check('A02 strict numeric string',(await invoke(fresh(),args('100.00'))).errorCode,'INVALID_ARGUMENT');
for (const [amount,expected] of [[50000,'APPROVAL_REQUIRED'],[50000.01,'EXCEED_LIMIT'],[80000,'EXCEED_LIMIT'],[80000.01,'APPROVAL_REQUIRED'],[100000,'APPROVAL_REQUIRED'],[100000.01,'INVALID_ARGUMENT']]) {
  s=fresh(); const before=snapshot();
  check(`A03 boundary ${amount}`,(await invoke(s,args(amount))).errorCode,expected);
  check(`A03 readonly ${amount}`,snapshot(),before);
}
for (const amount of [80000.01,90000,100000]) {
  s=fresh(); const before=snapshot();
  check(`T05/A03 approved timeout ${amount}`,(await invoke(s,args(amount),{approve:true,key:`timeout_${amount}`})).errorCode,'TIMEOUT_UNKNOWN');
  check(`T05 unchanged ${amount}`,snapshot(),before);
}
for (const amount of [30000,60000]) {
  s=fresh(true); const a=args(amount,{from_account:'acc_2003'}),before=snapshot();
  const pending=await invoke(s,a);
  check(`A04 unapproved precedence ${amount}`,pending.errorCode,amount===60000?'EXCEED_LIMIT':'INSUFFICIENT_BALANCE');
  s.approvals.approve('grading_approval',{userId:'grading_user',tenantId:'tenant_a',toolName:'create_transfer',args:d.TransferArgs.validate(a)});
  const r=await invoke(s,a,{context:{approvalId:'grading_approval'}});
  check(`A04 precedence ${amount}`,r.errorCode,amount===60000?'EXCEED_LIMIT':'INSUFFICIENT_BALANCE');
  check(`A04 no writes ${amount}`,snapshot(),before);
  check(`A04 approval unused ${amount}`,s.approvals.items.get('grading_approval').used,false);
}
s=fresh(true);
check('A05 full balance success',(await invoke(s,args(20000,{from_account:'acc_2003'}),{approve:true,key:'full'})).ok,true);
check('A05 balances',[d.ACCOUNTS.get('tenant_a:acc_2003').balance_cents,d.ACCOUNTS.get('tenant_a:acc_2002').balance_cents],[0n,2000000n]);
s=fresh(); let before=snapshot();
const missing=await invoke(s,args(100,{to_account:'acc_9999'}),{approve:true,key:'missing'});
check('A06 missing target code',missing.errorCode,'ACCOUNT_NOT_FOUND');
check('A06 missing target message',missing.content.message,'转入账户不存在');
check('A06 missing target readonly',snapshot(),before);
for (const field of ['from_account','to_account']) {
  s=fresh(true); before=snapshot();
  const r=await invoke(s,args(100,{[field]:'acc_9001'}),{approve:true,key:`tenant_${field}`});
  check(`A07 ${field} denied`,r.ok,false);
  check(`A07 ${field} tenant balances intact`,snapshot(),before);
}
s=fresh();
const t=s.runtime.tools.get('create_transfer');
console.log('A08_POLICY',json(t.policy));
check('A08 write/approval/timeout/idempotent/retries',[t.policy.effect,t.policy.requiresApproval,t.policy.timeoutSeconds<3,t.policy.idempotent,t.policy.maxRetries],['write',true,true,false,0]);
check('A08 permission',t.policy.permission,'transfer:execute');
check('A08 bound implementations',[t.parametersModel===d.TransferArgs,t.handler===d.createTransfer,t.precheck===d.checkTransfer],[true,true,true]);
const targets=[args(),args(100,{from_account:'acc_2003'}),args(100,{to_account:'acc_2003'}),args(101)].map(a=>t.canonicalTarget(d.TransferArgs.validate(a),ctx()));
console.log('A08_TARGETS',json(targets)); check('A08 distinguish all business args',new Set(targets).size,4);
s=fresh();
check('T04 native pending',(await invoke(s,args())).errorCode,'APPROVAL_REQUIRED');
s.approvals.approve('grading_approval',{userId:'grading_user',tenantId:'tenant_a',toolName:'create_transfer',args:d.TransferArgs.validate(args())});
check('T04 changed amount approval rejected',(await invoke(s,args(101),{context:{approvalId:'grading_approval'},key:'tamper'})).errorCode,'APPROVAL_REQUIRED');
const success=await invoke(s,args(),{context:{approvalId:'grading_approval'},key:'success',id:'call_tr_000003'});
check('T04 native approved success',success.ok,true);
check('T04 txn_id',success.content.txn_id,'000003');
check('T04 amount/status',[success.content.amount,success.content.status],[100,'accepted']);
check('A09 native raw accounts absent from model output',json(success.toModelPayload()).includes('acc_2001'),false);
check('T04 balances',[d.ACCOUNTS.get('tenant_a:acc_2001').balance_cents,d.ACCOUNTS.get('tenant_a:acc_2002').balance_cents],[9990000n,10000n]);
check('T04 approval replay rejected',(await invoke(s,args(),{context:{approvalId:'grading_approval'},key:'success'})).errorCode,'APPROVAL_REQUIRED');
check('A10 audit correlated',s.audit.records.every(r=>r.trace_id==='grading_trace'&&typeof r.tool_call_id==='string'),true);
check('A10 audit values not stored',json(s.audit.records).includes('acc_2001'),false);
// Additional requirement introduced by submission, not present in assignment.
s=fresh(); before=snapshot();
check('T04 approval without extra idempotency context',(await invoke(s,args(),{approve:true})).ok,true);
check('T04 missing idempotency no writes',snapshot(),before);
for (const [label,context,expected] of [['rbac',{permissions:[]},'PERMISSION_DENIED'],['whitelist',{allowedTools:[]},'TOOL_NOT_ALLOWED'],['plan',{mode:'plan'},'PLAN_MODE_DENIED']]) {
  s=fresh(); before=snapshot();
  check(`T03 ${label}`,(await invoke(s,args(),{approve:true,key:label,context})).errorCode,expected);
  check(`T03 ${label} readonly`,snapshot(),before);
}
check('A09 specified account recursive mask',d.redact({nested:['ACC-A-123456',{account:'ACC-A-654321'}]}),{nested:['ACC-A-****3456',{account:'ACC-A-****4321'}]});
check('A09 email/secret/recursive preserved',d.redact({nested:['alice@example.com',{access_token:'fake',password:'fake'}]}),{nested:['***@***',{access_token:'***',password:'***'}]});
s=fresh();
const order=await s.runtime.invoke(new d.ToolCall({id:'order_regression',name:'get_order',arguments:{order_id:'ord_1001'}}),ctx());
check('A09 order email/token',[order.content.customer_email,order.content.access_token],['***@***','***']);
console.log('SUMMARY',json({passed,failed,note:'Independent native-interface requirement checks; not original Python test pass counts. Fixtures explicitly seeded only in A04/A05/A07.'}));
process.exitCode=failed?1:0;
