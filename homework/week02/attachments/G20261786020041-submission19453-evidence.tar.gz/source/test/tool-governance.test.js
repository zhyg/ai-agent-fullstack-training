import assert from "node:assert/strict";
import test from "node:test";
import {
  ACCOUNTS,
  approvalDigest,
  AuditSink,
  ApprovalStore,
  buildGovernance,
  checkTransfer,
  createTransfer,
  CreateRefundArgs,
  Effect,
  ExecutionContext,
  GetOrderArgs,
  PermissionEngine,
  PermissionMode,
  PolicyDenied,
  REFUNDS,
  resetBusinessData,
  Risk,
  ToolCall,
  ToolDefinition,
  ToolPolicy,
  ToolRuntime,
  TransientToolError,
  TransferArgs,
  TRANSFERS,
  ValidationError,
} from "../src/index.js";

function createContext(overrides = {}) {
  return new ExecutionContext({
    traceId: "trace_test",
    userId: "u_100",
    tenantId: "tenant_a",
    permissions: ["order:read", "refund:create", "shell:run"],
    allowedTools: ["get_order", "create_refund", "run_shell"],
    ...overrides,
  });
}

test("reproduces the six governance scenarios and audit counts", async () => {
  resetBusinessData();
  const { runtime, approvals, audit } = buildGovernance();
  const context = createContext();

  const read = await runtime.invoke(
    new ToolCall({
      id: "call_01",
      name: "get_order",
      arguments: { order_id: "ord_1001" },
    }),
    context,
  );
  assert.equal(read.ok, true);
  assert.equal(read.content.customer_email, "***@***");
  assert.equal(read.content.access_token, "***");

  const refundArgs = {
    order_id: "ord_1001",
    amount: "399.00",
    reason: "退款商品存在质量问题",
  };
  const unapproved = await runtime.invoke(
    new ToolCall({
      id: "call_02",
      name: "create_refund",
      arguments: refundArgs,
    }),
    context,
  );
  assert.equal(unapproved.errorCode, "APPROVAL_REQUIRED");

  approvals.approve("approval_01", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_refund",
    args: CreateRefundArgs.validate(refundArgs),
  });
  const approved = await runtime.invoke(
    new ToolCall({
      id: "call_03",
      name: "create_refund",
      arguments: refundArgs,
    }),
    context.with({ approvalId: "approval_01", idempotencyKey: "call_03" }),
  );
  assert.equal(approved.ok, true);
  assert.equal(approved.content.refund_id, "ref_9001");

  const invalid = await runtime.invoke(
    new ToolCall({
      id: "call_04",
      name: "create_refund",
      arguments: {
        ...refundArgs,
        user_id: "u_100",
        approved: true,
      },
    }),
    context,
  );
  assert.equal(invalid.errorCode, "INVALID_ARGUMENT");

  const shell = await runtime.invoke(
    new ToolCall({
      id: "call_05",
      name: "run_shell",
      arguments: { command: "whoami" },
    }),
    context,
  );
  assert.equal(shell.errorCode, "DENY_RULE");

  const plan = await runtime.invoke(
    new ToolCall({
      id: "call_06",
      name: "create_refund",
      arguments: refundArgs,
    }),
    context.with({ mode: PermissionMode.PLAN }),
  );
  assert.equal(plan.errorCode, "PLAN_MODE_DENIED");

  assert.equal(REFUNDS.size, 1);
  assert.equal(audit.records.length, 8);
});

test("model tool discovery filters disabled, denied, and plan-forbidden tools", () => {
  const { runtime } = buildGovernance();
  const names = runtime
    .modelTools(createContext())
    .map((tool) => tool.function.name);
  assert.deepEqual(names, ["get_order", "create_refund"]);

  const planNames = runtime
    .modelTools(createContext({ mode: PermissionMode.PLAN }))
    .map((tool) => tool.function.name);
  assert.deepEqual(planNames, ["get_order"]);
});

test("transfer requires approval, enforces business rules, and replays idempotently", async () => {
  resetBusinessData();
  const { runtime, approvals } = buildGovernance();
  const context = createContext({
    permissions: ["transfer:create"],
    allowedTools: ["create_transfer"],
  });
  const transferArgs = {
    from_account: "acc_2001",
    to_account: "acc_2002",
    amount: "100.00",
    currency: "CNY",
  };
  const callTransfer = (id, args) =>
    runtime.invoke(new ToolCall({ id, name: "create_transfer", arguments: args }), context);

  const unapproved = await callTransfer("call_tr_1", transferArgs);
  assert.equal(unapproved.errorCode, "APPROVAL_REQUIRED");

  const selfTransfer = await callTransfer("call_tr_2", {
    ...transferArgs,
    to_account: "acc_2001",
  });
  assert.equal(selfTransfer.errorCode, "BUSINESS_RULE_DENIED");

  const overLimit = await callTransfer("call_tr_3", {
    ...transferArgs,
    amount: "900000.00",
  });
  assert.equal(overLimit.errorCode, "BUSINESS_RULE_DENIED");

  approvals.approve("approval_tr_tamper", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_transfer",
    args: TransferArgs.validate(transferArgs),
  });
  const tampered = await callTransfer("call_tr_4", {
    ...transferArgs,
    amount: "10000.00",
  });
  assert.equal(tampered.errorCode, "APPROVAL_REQUIRED");
  assert.equal(TRANSFERS.size, 0);

  approvals.approve("approval_tr", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_transfer",
    args: TransferArgs.validate(transferArgs),
  });
  const approved = await runtime.invoke(
    new ToolCall({
      id: "call_tr_5",
      name: "create_transfer",
      arguments: transferArgs,
    }),
    context.with({ approvalId: "approval_tr", idempotencyKey: "idemo_transfer_01" }),
  );
  assert.equal(approved.ok, true);
  assert.equal(approved.content.transfer_id, "trf_0001");
  assert.equal(ACCOUNTS.get("tenant_a:acc_2001").balance_cents, 99_900_00n);
  assert.equal(ACCOUNTS.get("tenant_a:acc_2002").balance_cents, 100_00n);
  assert.equal(TRANSFERS.size, 1);

  approvals.approve("approval_tr_replay", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_transfer",
    args: TransferArgs.validate(transferArgs),
  });
  const replay = await runtime.invoke(
    new ToolCall({
      id: "call_tr_6",
      name: "create_transfer",
      arguments: transferArgs,
    }),
    context.with({ approvalId: "approval_tr_replay", idempotencyKey: "idemo_transfer_01" }),
  );
  assert.equal(replay.ok, true);
  assert.equal(replay.content.transfer_id, "trf_0001");
  assert.equal(ACCOUNTS.get("tenant_a:acc_2001").balance_cents, 99_900_00n);
  assert.equal(TRANSFERS.size, 1);

  assert.throws(
    () => TransferArgs.validate({ ...transferArgs, approved: true }),
    (error) => {
      assert.equal(error.name, "ValidationError");
      assert.equal(error.issues[0].path[0], "approved");
      return true;
    },
  );
});

test("TransferArgs normalizes input and rejects invalid parameters", () => {
  const parsed = TransferArgs.validate({
    from_account: " acc_2001 ",
    to_account: "acc_2002",
    amount: 100.5,
    currency: "CNY",
  });
  assert.equal(parsed.from_account, "acc_2001");
  assert.equal(parsed.to_account, "acc_2002");
  assert.equal(parsed.amount, "100.50");
  assert.equal(parsed.amount_cents, 10050n);
  assert.equal(parsed.currency, "CNY");
  assert.equal(parsed.memo, undefined);

  assert.throws(
    () =>
      TransferArgs.validate({
        from_account: "acc_2001",
        amount: "1.00",
        currency: "CNY",
      }),
    ValidationError,
    "missing required to_account",
  );

  assert.throws(
    () =>
      TransferArgs.validate({
        from_account: "acc_1",
        to_account: "acc_2002",
        amount: "1.00",
        currency: "CNY",
      }),
    ValidationError,
    "invalid account pattern",
  );

  assert.throws(
    () =>
      TransferArgs.validate({
        from_account: "acc_2001",
        to_account: "acc_2002",
        amount: "0.00",
        currency: "CNY",
      }),
    ValidationError,
    "zero amount",
  );

  assert.throws(
    () =>
      TransferArgs.validate({
        from_account: "acc_2001",
        to_account: "acc_2002",
        amount: "1.999",
        currency: "CNY",
      }),
    ValidationError,
    "three decimal places",
  );

  assert.throws(
    () =>
      TransferArgs.validate({
        from_account: "acc_2001",
        to_account: "acc_2002",
        amount: "1.00",
        currency: "USD",
      }),
    ValidationError,
    "unsupported currency",
  );

  assert.throws(
    () =>
      TransferArgs.validate({
        from_account: "acc_2001",
        to_account: "acc_2002",
        amount: "1.00",
        currency: "CNY",
        memo: "长".repeat(101),
      }),
    ValidationError,
    "memo too long",
  );
});

test("checkTransfer enforces account, self, limit, and balance rules", async () => {
  resetBusinessData();
  const baseArgs = {
    from_account: "acc_2001",
    to_account: "acc_2002",
    amount_cents: 100_00n,
  };

  await assert.doesNotReject(
    () => checkTransfer({ ...baseArgs }, { tenantId: "tenant_a" }),
    "valid transfer passes precheck",
  );

  await assert.rejects(
    () =>
      checkTransfer(
        { ...baseArgs, from_account: "acc_9999" },
        { tenantId: "tenant_a" },
      ),
    (error) =>
      error instanceof PolicyDenied && error.code === "BUSINESS_RULE_DENIED",
    "missing from account",
  );

  await assert.rejects(
    () =>
      checkTransfer({ ...baseArgs }, { tenantId: "tenant_b" }),
    (error) => error.code === "BUSINESS_RULE_DENIED",
    "tenant isolation blocks cross-tenant accounts",
  );

  const frozen = ACCOUNTS.get("tenant_a:acc_2002");
  frozen.status = "frozen";
  await assert.rejects(
    () => checkTransfer({ ...baseArgs }, { tenantId: "tenant_a" }),
    (error) => error.code === "BUSINESS_RULE_DENIED",
    "frozen to account",
  );
  frozen.status = "active";

  await assert.rejects(
    () =>
      checkTransfer(
        { ...baseArgs, to_account: "acc_2001" },
        { tenantId: "tenant_a" },
      ),
    (error) => error.code === "BUSINESS_RULE_DENIED",
    "self transfer",
  );

  await assert.rejects(
    () =>
      checkTransfer(
        { ...baseArgs, amount_cents: 5_000_001n },
        { tenantId: "tenant_a" },
      ),
    (error) => error.code === "BUSINESS_RULE_DENIED",
    "amount over single transfer limit",
  );

  const account = ACCOUNTS.get("tenant_a:acc_2001");
  const originalBalance = account.balance_cents;
  account.balance_cents = 50_00n;
  await assert.rejects(
    () => checkTransfer({ ...baseArgs }, { tenantId: "tenant_a" }),
    (error) => error.code === "BUSINESS_RULE_DENIED",
    "insufficient balance",
  );
  account.balance_cents = originalBalance;
});

test("createTransfer requires idempotency key and books balances once", async () => {
  resetBusinessData();
  const args = {
    from_account: "acc_2001",
    to_account: "acc_2002",
    amount_cents: 250_00n,
    currency: "CNY",
    memo: "单元测试",
  };
  const context = { tenantId: "tenant_a", idempotencyKey: "idem_unit_01" };

  await assert.rejects(
    () =>
      createTransfer(args, { tenantId: "tenant_a", idempotencyKey: null }),
    /idempotency key/,
    "missing idempotency key",
  );

  const first = await createTransfer(args, context);
  assert.equal(first.transfer_id, "trf_0001");
  assert.equal(first.idempotency_key, "idem_unit_01");
  assert.equal(first.tenant_id, "tenant_a");
  assert.equal(first.amount, 250);
  assert.equal(first.status, "accepted");
  assert.equal(first.memo, "单元测试");
  assert.equal(ACCOUNTS.get("tenant_a:acc_2001").balance_cents, 99_750_00n);
  assert.equal(ACCOUNTS.get("tenant_a:acc_2002").balance_cents, 250_00n);

  const replay = await createTransfer(args, context);
  assert.deepEqual(replay, first);
  assert.equal(ACCOUNTS.get("tenant_a:acc_2001").balance_cents, 99_750_00n);
  assert.equal(ACCOUNTS.get("tenant_a:acc_2002").balance_cents, 250_00n);
  assert.equal(TRANSFERS.size, 1);

  const second = await createTransfer(args, {
    tenantId: "tenant_a",
    idempotencyKey: "idem_unit_02",
  });
  assert.equal(second.transfer_id, "trf_0002");
  assert.equal(ACCOUNTS.get("tenant_a:acc_2001").balance_cents, 99_500_00n);
  assert.equal(ACCOUNTS.get("tenant_a:acc_2002").balance_cents, 500_00n);
  assert.equal(TRANSFERS.size, 2);
});

test("create_transfer is discoverable only when permitted and outside plan mode", () => {
  const { runtime } = buildGovernance();
  const permitted = createContext({
    permissions: ["transfer:create"],
    allowedTools: ["create_transfer"],
  });

  const names = runtime
    .modelTools(permitted)
    .map((tool) => tool.function.name);
  assert.deepEqual(names, ["create_transfer"]);

  const planNames = runtime
    .modelTools(permitted.with({ mode: PermissionMode.PLAN }))
    .map((tool) => tool.function.name);
  assert.deepEqual(planNames, []);
});

test("transfer audit records store argument keys but never values", async () => {
  resetBusinessData();
  const { runtime, approvals, audit } = buildGovernance();
  const context = createContext({
    permissions: ["transfer:create"],
    allowedTools: ["create_transfer"],
  });
  const transferArgs = {
    from_account: "acc_2001",
    to_account: "acc_2002",
    amount: "100.00",
    currency: "CNY",
  };
  approvals.approve("approval_audit", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_transfer",
    args: TransferArgs.validate(transferArgs),
  });

  const result = await runtime.invoke(
    new ToolCall({
      id: "call_tr_audit",
      name: "create_transfer",
      arguments: transferArgs,
    }),
    context.with({ approvalId: "approval_audit", idempotencyKey: "idem_audit_01" }),
  );
  assert.equal(result.ok, true);

  const records = audit.records.filter(
    (record) => record.tool_call_id === "call_tr_audit",
  );
  assert.equal(records.length, 2);
  for (const record of records) {
    assert.equal(record.tool_name, "create_transfer");
    assert.ok(record.argument_keys.includes("from_account"));
    assert.ok(record.argument_keys.includes("to_account"));
    assert.ok(record.argument_keys.includes("amount"));
  }

  const serialized = JSON.stringify(audit.records);
  assert.equal(serialized.includes("acc_2001"), false);
  assert.equal(serialized.includes("acc_2002"), false);
  assert.equal(serialized.includes("100.00"), false);
});

test("approval digest binds transfer arguments and is order-insensitive", () => {
  const normalized = TransferArgs.validate({
    to_account: "acc_2002",
    amount: "100.00",
    from_account: "acc_2001",
    currency: "CNY",
  });
  const reordered = TransferArgs.validate({
    from_account: "acc_2001",
    to_account: "acc_2002",
    amount: "100.00",
    currency: "CNY",
  });

  assert.equal(
    approvalDigest("create_transfer", normalized),
    approvalDigest("create_transfer", reordered),
  );
  assert.notEqual(
    approvalDigest("create_transfer", normalized),
    approvalDigest("create_transfer", {
      ...normalized,
      amount_cents: 1_000_000n,
    }),
  );
  assert.notEqual(
    approvalDigest("create_transfer", normalized),
    approvalDigest("create_refund", normalized),
  );
});

test("approval is bound to normalized arguments and can be used once", async () => {
  resetBusinessData();
  const { runtime, approvals } = buildGovernance();
  const context = createContext();
  const validArgs = {
    order_id: "ord_1001",
    amount: "399.00",
    reason: "退款商品存在质量问题",
  };

  approvals.approve("approval_bound", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_refund",
    args: CreateRefundArgs.validate({ ...validArgs, amount: "398.00" }),
  });

  const mismatch = await runtime.invoke(
    new ToolCall({
      id: "call_mismatch",
      name: "create_refund",
      arguments: validArgs,
    }),
    context.with({ approvalId: "approval_bound" }),
  );
  assert.equal(mismatch.errorCode, "APPROVAL_REQUIRED");

  approvals.approve("approval_once", {
    userId: context.userId,
    tenantId: context.tenantId,
    toolName: "create_refund",
    args: CreateRefundArgs.validate(validArgs),
  });
  const onceContext = context.with({ approvalId: "approval_once" });
  const firstUse = await runtime.invoke(
    new ToolCall({
      id: "call_once_1",
      name: "create_refund",
      arguments: validArgs,
    }),
    onceContext,
  );
  assert.equal(firstUse.ok, true);

  const reused = await runtime.invoke(
    new ToolCall({
      id: "call_once_2",
      name: "create_refund",
      arguments: validArgs,
    }),
    onceContext,
  );
  assert.equal(reused.errorCode, "APPROVAL_REQUIRED");
});

test("strict schemas reject unknown model-provided authorization fields", () => {
  assert.throws(
    () =>
      CreateRefundArgs.validate({
        order_id: "ord_1001",
        amount: "399.00",
        reason: "退款商品存在质量问题",
        approved: true,
      }),
    (error) => {
      assert.equal(error.name, "ValidationError");
      assert.equal(error.issues[0].path[0], "approved");
      return true;
    },
  );
});

test("tool payload marks content untrusted and projects oversized strings", async () => {
  resetBusinessData();
  const { runtime } = buildGovernance();
  const result = await runtime.invoke(
    new ToolCall({
      id: "call_payload",
      name: "get_order",
      arguments: { order_id: "ord_1001" },
    }),
    createContext(),
  );
  const payload = result.toModelPayload();
  assert.equal(payload.untrusted, true);
  assert.equal(payload.source, "tool");
});

test("approval store keeps independent instances", () => {
  assert.notEqual(new ApprovalStore(), new ApprovalStore());
});

test("retries transient read failures within the policy limit", async () => {
  let attempts = 0;
  const tool = new ToolDefinition({
    name: "retry_tool",
    description: "测试瞬态故障重试。",
    parametersModel: GetOrderArgs,
    policy: new ToolPolicy({
      effect: Effect.READ,
      risk: Risk.LOW,
      permission: "test:read",
      maxRetries: 2,
      idempotent: true,
    }),
    handler: async () => {
      attempts += 1;
      if (attempts < 2) {
        throw new TransientToolError();
      }
      return { recovered: true };
    },
    canonicalTarget: () => "retry",
  });
  const runtime = new ToolRuntime({
    tools: [tool],
    permissions: new PermissionEngine(),
    approvals: new ApprovalStore(),
    audit: new AuditSink(),
  });
  const result = await runtime.invoke(
    new ToolCall({
      id: "call_retry",
      name: "retry_tool",
      arguments: { order_id: "ord_1001" },
    }),
    createContext({
      permissions: ["test:read"],
      allowedTools: ["retry_tool"],
    }),
  );

  assert.equal(result.ok, true);
  assert.equal(result.content.recovered, true);
  assert.equal(attempts, 2);
});

test("marks a write timeout as an unknown result", async () => {
  const tool = new ToolDefinition({
    name: "slow_write",
    description: "测试写操作超时。",
    parametersModel: GetOrderArgs,
    policy: new ToolPolicy({
      effect: Effect.WRITE,
      risk: Risk.HIGH,
      permission: "test:write",
      timeoutSeconds: 0.02,
    }),
    handler: async (_args, _context, { signal }) =>
      new Promise((_resolve, reject) => {
        signal.addEventListener(
          "abort",
          () => reject(signal.reason),
          { once: true },
        );
      }),
    canonicalTarget: () => "slow",
  });
  const runtime = new ToolRuntime({
    tools: [tool],
    permissions: new PermissionEngine(),
    approvals: new ApprovalStore(),
    audit: new AuditSink(),
  });
  const result = await runtime.invoke(
    new ToolCall({
      id: "call_timeout",
      name: "slow_write",
      arguments: { order_id: "ord_1001" },
    }),
    createContext({
      permissions: ["test:write"],
      allowedTools: ["slow_write"],
    }),
  );

  assert.equal(result.ok, false);
  assert.equal(result.errorCode, "TIMEOUT_UNKNOWN");
});

test("serializes concurrent writes for the same canonical target", async () => {
  let active = 0;
  let maxActive = 0;
  const tool = new ToolDefinition({
    name: "serial_write",
    description: "测试同资源写操作串行化。",
    parametersModel: GetOrderArgs,
    policy: new ToolPolicy({
      effect: Effect.WRITE,
      risk: Risk.HIGH,
      permission: "test:write",
    }),
    handler: async () => {
      active += 1;
      maxActive = Math.max(maxActive, active);
      await new Promise((resolve) => setTimeout(resolve, 10));
      active -= 1;
      return { ok: true };
    },
    canonicalTarget: (args) => args.order_id,
  });
  const runtime = new ToolRuntime({
    tools: [tool],
    permissions: new PermissionEngine(),
    approvals: new ApprovalStore(),
    audit: new AuditSink(),
  });
  const context = createContext({
    permissions: ["test:write"],
    allowedTools: ["serial_write"],
  });

  await Promise.all([
    runtime.invoke(
      new ToolCall({
        id: "call_serial_1",
        name: "serial_write",
        arguments: { order_id: "ord_1001" },
      }),
      context,
    ),
    runtime.invoke(
      new ToolCall({
        id: "call_serial_2",
        name: "serial_write",
        arguments: { order_id: "ord_1001" },
      }),
      context,
    ),
  ]);

  assert.equal(maxActive, 1);
});
