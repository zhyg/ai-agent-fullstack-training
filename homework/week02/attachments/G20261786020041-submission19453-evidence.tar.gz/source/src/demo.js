/**
 * 治理运行时演示入口。
 * 顺序复现十个调用场景：正常读、未审批退款写、已审批退款写、篡改参数写、
 * 禁用 Shell、plan 模式写，以及转账的未审批、自转账拒绝、已审批和幂等重放，
 * 最后输出副作用与审计记录统计。
 */
import { resetBusinessData, REFUNDS, TRANSFERS } from "./business.js";
import { PermissionDecision } from "./constants.js";
import { CreateRefundArgs, TransferArgs } from "./schema.js";
import { buildGovernance } from "./governance.js";
import { ExecutionContext, ToolCall } from "./tool-runtime.js";
import { pathToFileURL } from "node:url";

/**
 * 以单行 JSON 输出一次调用结果，并把结果映射为 allow/confirm/deny 动作。
 * @param {import("./tool-runtime.js").ToolResult} result 工具调用结果
 * @returns {void}
 */
function printResult(result) {
  const action = result.ok
    ? PermissionDecision.ALLOW
    : result.errorCode === "APPROVAL_REQUIRED"
      ? PermissionDecision.CONFIRM
      : PermissionDecision.DENY;
  process.stdout.write(
    `${JSON.stringify(
      {
        tool_call_id: result.toolCallId,
        tool_name: result.toolName,
        ok: result.ok,
        action,
        code: result.errorCode ?? "OK",
        content: result.content,
      },
      null,
      0,
    )}\n`,
  );
}

/**
 * 运行演示：重置数据、装配治理运行时并依次发起十个工具调用。
 * 涵盖权限放行、审批拦截与核销、参数越权拒绝、禁用工具拒绝、plan 模式拒绝，
 * 以及转账的业务预检拒绝、审批放行和幂等重放。
 * @returns {Promise<void>}
 */
export async function main() {
  resetBusinessData();
  const { runtime, approvals, audit } = buildGovernance();
  const baseContext = new ExecutionContext({
    traceId: "trace_001",
    userId: "u_100",
    tenantId: "tenant_a",
    permissions: ["order:read", "refund:create", "transfer:create", "shell:run"],
    allowedTools: [
      "get_order",
      "create_refund",
      "create_transfer",
      "run_shell",
    ],
  });

  const readCall = new ToolCall({
    id: "call_01",
    name: "get_order",
    arguments: { order_id: "ord_1001" },
  });
  const refundCall = new ToolCall({
    id: "call_02",
    name: "create_refund",
    arguments: {
      order_id: "ord_1001",
      amount: "399.00",
      reason: "退款商品存在质量问题",
    },
  });
  const approvedRefundCall = new ToolCall({
    id: "call_03",
    name: "create_refund",
    arguments: {
      order_id: "ord_1001",
      amount: "399.00",
      reason: "退款商品存在质量问题",
    },
  });
  const invalidRefundCall = new ToolCall({
    id: "call_04",
    name: "create_refund",
    arguments: {
      order_id: "ord_1001",
      amount: "399.00",
      reason: "退款商品存在质量问题",
      user_id: "u_100",
      approved: true,
    },
  });
  const shellCall = new ToolCall({
    id: "call_05",
    name: "run_shell",
    arguments: { command: "whoami" },
  });
  const planRefundCall = new ToolCall({
    id: "call_06",
    name: "create_refund",
    arguments: {
      order_id: "ord_1001",
      amount: "399.00",
      reason: "退款商品存在质量问题",
    },
  });
  const transferCall = new ToolCall({
    id: "call_07",
    name: "create_transfer",
    arguments: {
      from_account: "acc_2001",
      to_account: "acc_2002",
      amount: "100.00",
      currency: "CNY",
      memo: "演示转账",
    },
  });
  const selfTransferCall = new ToolCall({
    id: "call_08",
    name: "create_transfer",
    arguments: {
      from_account: "acc_2001",
      to_account: "acc_2001",
      amount: "100.00",
      currency: "CNY",
    },
  });
  const approvedTransferCall = new ToolCall({
    id: "call_09",
    name: "create_transfer",
    arguments: {
      from_account: "acc_2001",
      to_account: "acc_2002",
      amount: "100.00",
      currency: "CNY",
      memo: "演示转账",
    },
  });
  const replayTransferCall = new ToolCall({
    id: "call_10",
    name: "create_transfer",
    arguments: {
      from_account: "acc_2001",
      to_account: "acc_2002",
      amount: "100.00",
      currency: "CNY",
      memo: "演示转账",
    },
  });

  printResult(await runtime.invoke(readCall, baseContext));
  printResult(await runtime.invoke(refundCall, baseContext));

  const refundArgs = CreateRefundArgs.validate(refundCall.arguments);
  approvals.approve("approval_01", {
    userId: baseContext.userId,
    tenantId: baseContext.tenantId,
    toolName: refundCall.name,
    args: refundArgs,
  });
  const approvedContext = baseContext.with({
    approvalId: "approval_01",
    idempotencyKey: approvedRefundCall.id,
  });
  printResult(await runtime.invoke(approvedRefundCall, approvedContext));
  printResult(await runtime.invoke(invalidRefundCall, baseContext));
  printResult(await runtime.invoke(shellCall, baseContext));
  printResult(
    await runtime.invoke(
      planRefundCall,
      baseContext.with({ mode: "plan" }),
    ),
  );

  // 转账演示：未审批 → 业务预检拒绝（自转账）→ 已审批放行 → 幂等重放
  printResult(await runtime.invoke(transferCall, baseContext));
  printResult(await runtime.invoke(selfTransferCall, baseContext));

  const transferArgs = TransferArgs.validate(transferCall.arguments);
  approvals.approve("approval_02", {
    userId: baseContext.userId,
    tenantId: baseContext.tenantId,
    toolName: transferCall.name,
    args: transferArgs,
  });
  approvals.approve("approval_03", {
    userId: baseContext.userId,
    tenantId: baseContext.tenantId,
    toolName: transferCall.name,
    args: transferArgs,
  });
  printResult(
    await runtime.invoke(
      approvedTransferCall,
      baseContext.with({
        approvalId: "approval_02",
        idempotencyKey: "idemo_transfer_01",
      }),
    ),
  );
  printResult(
    await runtime.invoke(
      replayTransferCall,
      baseContext.with({
        approvalId: "approval_03",
        idempotencyKey: "idemo_transfer_01",
      }),
    ),
  );

  process.stdout.write(
    `${JSON.stringify({
      side_effects: {
        refund_executions: REFUNDS.size,
        transfer_executions: TRANSFERS.size,
        shell_executions: 0,
      },
      audit_records: audit.records.length,
    })}\n`,
  );

  // 逐条输出审计明细：成功与失败调用各阶段（deny / authorized / 完成）均有记录；
  // argument_keys 只含参数键名，不含参数值，敏感参数不会落盘。
  // for (const record of audit.records) {
  //   process.stdout.write(
  //     `'out:'${JSON.stringify({ audit_record: record }, null, 0)}\n`,
  //   );
  // }
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}
