/**
 * 工具治理运行时使用的错误类型集合。
 * 运行时依据错误类型区分：参数校验失败、策略拒绝（不重试）、
 * 临时依赖故障（可重试）和执行超时（写操作需要人工确认结果）。
 */

/**
 * 参数校验失败。
 * 由 schema.js 中的参数模型抛出，issues 中保留逐字段的校验问题，
 * 运行时据此生成返回给模型的 INVALID_ARGUMENT 明细。
 */
export class ValidationError extends Error {
  /**
   * @param {Array<{path: string[], message: string, type: string}>} issues 逐字段校验问题列表
   */
  constructor(issues) {
    super("参数校验失败");
    this.name = "ValidationError";
    this.issues = issues;
  }
}

/**
 * 策略拒绝错误。
 * 覆盖工具白名单、RBAC 权限、plan 模式、审批缺失、确认缺失和业务规则等门禁失败场景；
 * code 作为稳定错误码写入审计并返回给模型，content 为可安全透出的结构化内容。
 */
export class PolicyDenied extends Error {
  /**
   * @param {string} code 稳定错误码，如 APPROVAL_REQUIRED、PERMISSION_DENIED
   * @param {string} message 面向使用者的提示信息
   * @param {unknown} [content] 返回给模型的内容，默认降级为 { message }
   */
  constructor(code, message, content = null) {
    super(message);
    this.name = "PolicyDenied";
    this.code = code;
    this.content = content ?? { message };
  }
}

/**
 * 临时依赖故障。
 * 只有读操作或显式幂等操作会在该错误下按策略进行退避重试。
 */
export class TransientToolError extends Error {
  /**
   * @param {string} [message] 错误描述
   */
  constructor(message = "临时依赖故障") {
    super(message);
    this.name = "TransientToolError";
  }
}

/**
 * 工具执行超时。
 * 写操作超时时运行时会返回 TIMEOUT_UNKNOWN，提示结果未知并引导查询或转人工。
 */
export class ToolTimeoutError extends Error {
  /**
   * @param {string} [message] 错误描述
   */
  constructor(message = "工具执行超时") {
    super(message);
    this.name = "TimeoutError";
  }
}
