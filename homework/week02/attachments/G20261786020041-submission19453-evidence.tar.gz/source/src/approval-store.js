/**
 * 审批存储：把“用户确认”绑定到具体工具和具体参数上。
 * 审批记录采用一次性核销，并带 TTL；核销时同时校验用户、租户、工具名
 * 和规范化参数摘要，防止审批被挪用或参数被篡改。
 */
import { createHash } from "node:crypto";
import { PolicyDenied } from "./errors.js";

/**
 * 递归生成稳定值：对象键排序、BigInt 转字符串，
 * 保证相同语义的参数得到相同的序列化结果。
 * @param {unknown} value 任意值
 * @returns {unknown} 键序稳定的新值
 */
function stableValue(value) {
  if (typeof value === "bigint") {
    return value.toString();
  }
  if (Array.isArray(value)) {
    return value.map(stableValue);
  }
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((key) => [key, stableValue(value[key])]),
    );
  }
  return value;
}

/**
 * 计算审批绑定的参数摘要：对“工具名 + 规范化参数 JSON”取 SHA-256。
 * @param {string} toolName 工具名称
 * @param {unknown} argumentsValue 工具参数
 * @returns {string} 十六进制摘要
 */
export function approvalDigest(toolName, argumentsValue) {
  const canonical = JSON.stringify(stableValue(argumentsValue));
  return createHash("sha256").update(`${toolName}:${canonical}`).digest("hex");
}

export class ApprovalStore {
  constructor() {
    /** @type {Map<string, {approvalId: string, userId: string, tenantId: string, toolName: string, digest: string, expiresAt: number, used: boolean}>} 审批记录表 */
    this.items = new Map();
  }

  /**
   * 登记一条审批：绑定用户、租户、工具名和参数摘要，并设置有效期。
   * @param {string} approvalId 审批标识
   * @param {{userId: string, tenantId: string, toolName: string, args: unknown, ttlSeconds?: number}} input 审批信息
   * @returns {void}
   */
  approve(approvalId, { userId, tenantId, toolName, args, ttlSeconds = 300 }) {
    this.items.set(approvalId, {
      approvalId,
      userId,
      tenantId,
      toolName,
      digest: approvalDigest(toolName, args),
      expiresAt: Date.now() + ttlSeconds * 1000,
      used: false,
    });
  }

  /**
   * 核销审批：要求审批存在、未使用、未过期，且用户、租户、工具名和参数摘要全部匹配。
   * 核销成功后标记为已使用，确保一次性。
   * @param {string|null} approvalId 上下文携带的审批标识
   * @param {{tool: {name: string}, args: unknown}} prepared 已校验的工具调用准备对象
   * @param {{userId: string, tenantId: string}} context 当前执行上下文
   * @returns {void}
   * @throws {PolicyDenied} 审批无效时抛出 APPROVAL_REQUIRED
   */
  consume(approvalId, prepared, context) {
    const approval = this.items.get(approvalId ?? "");
    const valid =
      approval !== undefined &&
      !approval.used &&
      approval.expiresAt >= Date.now() &&
      approval.userId === context.userId &&
      approval.tenantId === context.tenantId &&
      approval.toolName === prepared.tool.name &&
      approval.digest === approvalDigest(prepared.tool.name, prepared.args);

    if (!valid) {
      throw new PolicyDenied(
        "APPROVAL_REQUIRED",
        "该操作需要用户审批：请确认本次调用的工具、金额和参数",
      );
    }
    approval.used = true;
  }
}
