/**
 * 工具调用运行时核心。
 * 负责工具定义与策略校验、调用前门禁（参数校验、白名单、权限、plan 模式、审批、确认）、
 * 限定超时执行、读/幂等操作的退避重试、写操作按目标串行加锁、
 * 审计落盘以及返回给模型的脱敏与规模投影。
 */
import { performance } from "node:perf_hooks";
import {
  Effect,
  EFFECT_VALUES,
  PERMISSION_MODE_VALUES,
  PermissionDecision,
  PermissionMode,
  Risk,
  RISK_VALUES,
} from "./constants.js";
import {
  PolicyDenied,
  ToolTimeoutError,
  TransientToolError,
  ValidationError,
} from "./errors.js";
import { argumentKeys, projectForModel, redact } from "./redaction.js";
import { isRecord } from "./schema.js";

/**
 * 断言字段为非空字符串，失败时抛出策略拒绝。
 * @param {unknown} value 待校验的值
 * @param {string} field 字段名称，用于错误信息
 * @param {string} [code] 错误码，默认 INVALID_ARGUMENT
 * @throws {PolicyDenied} 非字符串或空字符串时抛出
 */
function assertNonEmptyString(value, field, code = "INVALID_ARGUMENT") {
  if (typeof value !== "string" || value.length === 0) {
    throw new PolicyDenied(code, `${field} 必须为非空字符串`);
  }
}

/**
 * 工具治理策略。
 * 描述工具的副作用、风险、所需权限，以及是否禁用、需要确认或强制审批；
 * 同时声明超时、重试和幂等属性。构造后即冻结，避免运行中被篡改。
 */
export class ToolPolicy {
  /**
   * @param {object} options 策略选项
   * @param {string} options.effect 副作用类型，见 Effect
   * @param {string} options.risk 风险等级，见 Risk
   * @param {string} options.permission 所需 RBAC 权限
   * @param {boolean} [options.denied] 是否命中 deny 规则
   * @param {boolean} [options.requiresConfirmation] 是否需要用户确认
   * @param {boolean} [options.requiresApproval] 是否需要一次性审批
   * @param {number} [options.timeoutSeconds] 执行超时时间（秒）
   * @param {number} [options.maxRetries] 最大重试次数
   * @param {boolean} [options.idempotent] 是否幂等（非读操作也可重试）
   * @param {boolean} [options.enabled] 是否启用
   * @throws {TypeError} effect 或 risk 非法时抛出
   */
  constructor({
    effect,
    risk,
    permission,
    denied = false,
    requiresConfirmation = false,
    requiresApproval = false,
    timeoutSeconds = 3,
    maxRetries = 0,
    idempotent = false,
    enabled = true,
  }) {
    if (!EFFECT_VALUES.has(effect)) {
      throw new TypeError(`无效的 effect: ${effect}`);
    }
    if (!RISK_VALUES.has(risk)) {
      throw new TypeError(`无效的 risk: ${risk}`);
    }
    Object.assign(this, {
      effect,
      risk,
      permission,
      denied,
      requiresConfirmation,
      requiresApproval,
      timeoutSeconds,
      maxRetries,
      idempotent,
      enabled,
    });
    Object.freeze(this);
  }
}

/**
 * 校验工具策略各字段的类型与取值范围。
 * @param {ToolPolicy} policy 待校验的策略
 * @returns {void}
 * @throws {TypeError} 任一字段类型或取值非法时抛出
 */
function assertPolicy(policy) {
  for (const field of [
    "denied",
    "requiresConfirmation",
    "requiresApproval",
    "idempotent",
    "enabled",
  ]) {
    if (typeof policy[field] !== "boolean") {
      throw new TypeError(`工具策略 ${field} 必须为布尔值`);
    }
  }
  if (typeof policy.timeoutSeconds !== "number" || policy.timeoutSeconds <= 0) {
    throw new TypeError("工具超时必须为正数");
  }
  if (!Number.isInteger(policy.maxRetries) || policy.maxRetries < 0) {
    throw new TypeError("工具最大重试次数必须为非负整数");
  }
  if (!EFFECT_VALUES.has(policy.effect) || !RISK_VALUES.has(policy.risk)) {
    throw new TypeError("工具副作用或风险等级无效");
  }
}

/**
 * 工具定义。
 * 聚合名称、描述、参数模型、治理策略、处理函数、业务预检和目标标识函数，
 * 并在构造时做完整性校验。
 */
export class ToolDefinition {
  /**
   * @param {object} options 工具定义选项
   * @param {string} options.name 工具名称（唯一）
   * @param {string} options.description 工具描述
   * @param {{validate: Function, jsonSchema: object}} options.parametersModel 参数模型
   * @param {ToolPolicy} options.policy 治理策略
   * @param {Function} options.handler 实际处理函数
   * @param {(args: unknown, context: ExecutionContext) => string} options.canonicalTarget 生成写操作加锁目标标识
   * @param {Function|null} [options.precheck] 业务预检函数
   * @throws {TypeError} 任一必填项缺失或类型错误时抛出
   */
  constructor({
    name,
    description,
    parametersModel,
    policy,
    handler,
    canonicalTarget,
    precheck = null,
  }) {
    assertNonEmptyString(name, "工具名称");
    assertNonEmptyString(description, "工具描述");
    if (
      parametersModel === null ||
      typeof parametersModel !== "object" ||
      typeof parametersModel.validate !== "function" ||
      typeof parametersModel.jsonSchema !== "object"
    ) {
      throw new TypeError(`工具 ${name} 缺少参数模型`);
    }
    if (
      policy === null ||
      typeof policy !== "object" ||
      !(policy instanceof ToolPolicy)
    ) {
      throw new TypeError(`工具 ${name} 的策略必须为 ToolPolicy`);
    }
    assertPolicy(policy);
    if (typeof handler !== "function") {
      throw new TypeError(`工具 ${name} 缺少 handler`);
    }
    if (typeof canonicalTarget !== "function") {
      throw new TypeError(`工具 ${name} 缺少 canonicalTarget`);
    }
    if (precheck !== null && typeof precheck !== "function") {
      throw new TypeError(`工具 ${name} 的 precheck 必须为函数`);
    }

    Object.assign(this, {
      name,
      description,
      parametersModel,
      policy,
      handler,
      canonicalTarget,
      precheck,
    });
  }

  /**
   * 转换为模型可识别的 function calling 工具描述。
   * @returns {{type: string, function: {name: string, description: string, parameters: object}}} 模型侧工具定义
   */
  toModelTool() {
    return {
      type: "function",
      function: {
        name: this.name,
        description: this.description,
        parameters: this.parametersModel.jsonSchema,
      },
    };
  }
}

/**
 * 模型发起的一次工具调用请求。
 */
export class ToolCall {
  /**
   * @param {{id: string, name: string, arguments: unknown}} input 调用标识、工具名和原始参数
   */
  constructor({ id, name, arguments: argumentsValue }) {
    this.id = id;
    this.name = name;
    this.arguments = argumentsValue;
  }
}

/**
 * 执行上下文：承载调用方的身份、租户、权限白名单、审批信息和执行模式。
 * permissions 与 allowedTools 内部转为 Set，便于 O(1) 判断。
 */
export class ExecutionContext {
  /**
   * @param {object} options 上下文选项
   * @param {string} options.traceId 链路追踪 ID
   * @param {string} options.userId 用户 ID
   * @param {string} options.tenantId 租户 ID
   * @param {string[]} [options.permissions] RBAC 权限列表
   * @param {string[]} [options.allowedTools] 本轮工具白名单
   * @param {string|null} [options.approvalId] 审批标识
   * @param {string|null} [options.idempotencyKey] 幂等键
   * @param {string} [options.mode] 执行模式，见 PermissionMode
   */
  constructor({
    traceId,
    userId,
    tenantId,
    permissions = [],
    allowedTools = [],
    approvalId = null,
    idempotencyKey = null,
    mode = PermissionMode.DEFAULT,
  }) {
    this.traceId = traceId;
    this.userId = userId;
    this.tenantId = tenantId;
    this.permissions = new Set(permissions);
    this.allowedTools = new Set(allowedTools);
    this.approvalId = approvalId;
    this.idempotencyKey = idempotencyKey;
    this.mode = mode;
  }

  /**
   * 基于当前上下文派生一个新上下文，仅覆盖指定字段。
   * 用于为同一次调用追加审批 ID、幂等键或切换执行模式。
   * @param {object} overrides 需要覆盖的字段
   * @returns {ExecutionContext} 新的上下文实例
   */
  with(overrides) {
    return new ExecutionContext({
      traceId: this.traceId,
      userId: this.userId,
      tenantId: this.tenantId,
      permissions: this.permissions,
      allowedTools: this.allowedTools,
      approvalId: this.approvalId,
      idempotencyKey: this.idempotencyKey,
      mode: this.mode,
      ...overrides,
    });
  }
}

/**
 * 工具调用结果：区分成功/失败、稳定错误码和安全内容。
 */
export class ToolResult {
  /**
   * @param {{toolCallId: string, toolName: string, ok: boolean, content: unknown, errorCode?: string|null}} input 结果字段
   */
  constructor({ toolCallId, toolName, ok, content, errorCode = null }) {
    this.toolCallId = toolCallId;
    this.toolName = toolName;
    this.ok = ok;
    this.content = content;
    this.errorCode = errorCode;
  }

  /**
   * 转换为回填给模型的工具消息载荷。
   * 显式标记 untrusted: true，并在投影阶段完成脱敏和规模限制。
   * @returns {object} 模型侧工具消息载荷
   */
  toModelPayload() {
    return {
      source: "tool",
      tool_name: this.toolName,
      untrusted: true,
      ok: this.ok,
      error_code: this.errorCode,
      content: projectForModel(this.content),
    };
  }
}

/**
 * 审计落盘接口。
 * 演示实现写入内存数组；生产环境可替换为异步日志或审计服务。
 */
export class AuditSink {
  constructor() {
    /** @type {object[]} 审计记录列表 */
    this.records = [];
  }

  /**
   * 写入一条审计记录（复制后追加，避免外部修改影响已存记录）。
   * @param {object} record 审计记录
   * @returns {Promise<void>}
   */
  async write(record) {
    this.records.push({ ...record });
  }
}

/**
 * 简易异步互斥锁：用于写操作按目标串行执行。
 */
class AsyncLock {
  constructor() {
    this.locked = false;
    /** @type {Array<() => void>} 等待锁释放的队列 */
    this.waiters = [];
  }

  /**
   * 获取锁；已被占用时挂起，直到前一个持有者释放。
   * @returns {Promise<void>}
   */
  async acquire() {
    if (!this.locked) {
      this.locked = true;
      return;
    }
    await new Promise((resolve) => this.waiters.push(resolve));
  }

  /**
   * 释放锁：优先唤醒等待队列中的下一个持有者，否则标记为空闲。
   * @returns {void}
   */
  release() {
    const next = this.waiters.shift();
    if (next) {
      next();
      return;
    }
    this.locked = false;
  }

  /**
   * 在锁内执行回调，无论成功或失败都会释放锁。
   * @template T
   * @param {() => Promise<T>} callback 待执行的回调
   * @returns {Promise<T>} 回调结果
   */
  async run(callback) {
    await this.acquire();
    try {
      return await callback();
    } finally {
      this.release();
    }
  }
}

/**
 * 延时指定毫秒数，用于重试之间的退避。
 * @param {number} milliseconds 延时毫秒数
 * @returns {Promise<void>}
 */
function sleep(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

/**
 * 在指定超时时间内执行工具处理函数。
 * 超时后通过 AbortController 发出中止信号并抛出 ToolTimeoutError。
 * @param {Function} handler 工具处理函数
 * @param {unknown} args 已校验的参数
 * @param {ExecutionContext} context 执行上下文
 * @param {number} timeoutSeconds 超时时间（秒）
 * @returns {Promise<unknown>} 处理函数返回值
 * @throws {ToolTimeoutError} 超时后抛出
 */
function runWithTimeout(handler, args, context, timeoutSeconds) {
  const controller = new AbortController();
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const error = new ToolTimeoutError();
      controller.abort(error);
      reject(error);
    }, timeoutSeconds * 1000);
  });

  const execution = Promise.resolve().then(() =>
    handler(args, context, { signal: controller.signal }),
  );

  return Promise.race([execution, timeout]).finally(() => clearTimeout(timer));
}

/**
 * 工具运行时：对外提供工具清单、单次调用和批量调用入口。
 * 内部串起“门禁 → 预检 → 审批/确认 → 执行（超时、重试、加锁）→ 脱敏 → 审计”的完整链路。
 */
export class ToolRuntime {
  /**
   * @param {object} options 运行时依赖
   * @param {ToolDefinition[]} options.tools 工具定义列表
   * @param {import("./permission-engine.js").PermissionEngine} options.permissions 权限引擎
   * @param {import("./approval-store.js").ApprovalStore} options.approvals 审批存储
   * @param {AuditSink} options.audit 审计落盘
   * @throws {Error} 工具名重复或为空时抛出
   * @throws {TypeError} 工具类型或策略非法时抛出
   */
  constructor({ tools, permissions, approvals, audit }) {
    const names = tools.map((tool) => tool.name);
    if (
      names.some((name) => typeof name !== "string" || name.length === 0) ||
      names.length !== new Set(names).size
    ) {
      throw new Error("工具名称必须非空且唯一");
    }
    for (const tool of tools) {
      if (!(tool instanceof ToolDefinition)) {
        throw new TypeError(`工具 ${tool?.name ?? "<unknown>"} 必须为 ToolDefinition`);
      }
      assertPolicy(tool.policy);
    }

    this.tools = new Map(tools.map((tool) => [tool.name, tool]));
    this.permissions = permissions;
    this.approvals = approvals;
    this.audit = audit;
    this.locks = new Map();
  }

  /**
   * 生成当前上下文可见的模型工具清单。
   * 过滤掉禁用、deny、权限不足的工具，以及 plan 模式下的写操作和 Shell 工具。
   * @param {ExecutionContext} context 执行上下文
   * @returns {object[]} 模型侧工具定义数组
   */
  modelTools(context) {
    return [...this.tools.values()]
      .filter((tool) => tool.policy.enabled && !tool.policy.denied)
      .filter((tool) => {
        if (
          context.mode === PermissionMode.PLAN &&
          (tool.policy.effect === Effect.WRITE || tool.policy.effect === Effect.SHELL)
        ) {
          return false;
        }
        return this.permissions.decide(tool, context) !== PermissionDecision.DENY;
      })
      .map((tool) => tool.toModelTool());
  }

  /**
   * 调用前门禁：依次检查调用格式、执行模式、工具是否存在、参数模型、
   * deny/禁用状态、plan 模式限制、白名单与 RBAC 权限，再执行业务预检和审批/确认核销。
   * @param {ToolCall} call 工具调用
   * @param {ExecutionContext} context 执行上下文
   * @returns {Promise<{call: ToolCall, tool: ToolDefinition, args: unknown, decision: string}>} 已授权的调用准备对象
   * @throws {PolicyDenied} 任一检查不通过时抛出对应错误码
   */
  async beforeToolCall(call, context) {
    assertNonEmptyString(call?.id, "工具调用标识");
    assertNonEmptyString(call?.name, "工具名称");
    if (!isRecord(call.arguments)) {
      throw new PolicyDenied("INVALID_ARGUMENT", "工具参数必须为对象");
    }
    if (!PERMISSION_MODE_VALUES.has(context?.mode)) {
      throw new PolicyDenied("INVALID_CONTEXT", "执行模式无效");
    }

    const tool = this.tools.get(call.name);
    if (!tool) {
      throw new PolicyDenied(
        "TOOL_NOT_ALLOWED",
        `工具 ${call.name} 不在本轮白名单`,
      );
    }

    let args;
    try {
      args = tool.parametersModel.validate(call.arguments);
    } catch (error) {
      if (error instanceof ValidationError) {
        throw new PolicyDenied(
          "INVALID_ARGUMENT",
          "参数校验失败",
          error.issues.map((item) => ({
            path: item.path.join("."),
            message: item.message,
          })),
        );
      }
      throw error;
    }

    if (tool.policy.denied || !tool.policy.enabled) {
      throw new PolicyDenied("DENY_RULE", "命中 deny 规则");
    }
    if (
      context.mode === PermissionMode.PLAN &&
      (tool.policy.effect === Effect.WRITE || tool.policy.effect === Effect.SHELL)
    ) {
      throw new PolicyDenied("PLAN_MODE_DENIED", "plan 模式禁止写操作和 Shell");
    }

    const decision = this.permissions.decide(tool, context);
    if (decision === PermissionDecision.DENY) {
      if (!context.allowedTools.has(tool.name)) {
        throw new PolicyDenied(
          "TOOL_NOT_ALLOWED",
          `工具 ${call.name} 不在本轮白名单`,
        );
      }
      throw new PolicyDenied(
        "PERMISSION_DENIED",
        `缺少权限 ${tool.policy.permission}`,
      );
    }

    const prepared = {
      call,
      tool,
      args,
      decision,
    };

    if (tool.precheck) {
      await tool.precheck(args, context);
    }
    if (tool.policy.requiresApproval) {
      if (context.mode === PermissionMode.DONT_ASK) {
        throw new PolicyDenied("APPROVAL_REQUIRED", "当前模式无法请求强制审批");
      }
      this.approvals.consume(context.approvalId, prepared, context);
    }
    if (tool.policy.requiresConfirmation) {
      if (context.mode === PermissionMode.DONT_ASK) {
        throw new PolicyDenied(
          "CONFIRMATION_REQUIRED",
          "当前模式无法请求用户确认",
        );
      }
      if (context.mode !== PermissionMode.BYPASS_PERMISSIONS) {
        throw new PolicyDenied(
          "CONFIRMATION_REQUIRED",
          "该操作需要用户确认",
        );
      }
    }
    return prepared;
  }

  /**
   * 执行一次工具处理函数（不重试），受策略超时约束。
   * @param {{tool: ToolDefinition, args: unknown}} prepared 调用准备对象
   * @param {ExecutionContext} context 执行上下文
   * @returns {Promise<unknown>} 工具返回内容
   */
  async executeOnce(prepared, context) {
    return runWithTimeout(
      prepared.tool.handler,
      prepared.args,
      context,
      prepared.tool.policy.timeoutSeconds,
    );
  }

  /**
   * 带退避重试的执行。
   * 仅读操作或显式幂等操作允许重试，且只对 TransientToolError 重试；
   * 第 n 次重试等待 50 * 2^n 毫秒。
   * @param {object} prepared 调用准备对象
   * @param {ExecutionContext} context 执行上下文
   * @returns {Promise<unknown>} 工具返回内容
   */
  async executeWithRecovery(prepared, context) {
    const policy = prepared.tool.policy;
    const retries =
      policy.effect === Effect.READ || policy.idempotent ? policy.maxRetries : 0;

    for (let attempt = 0; attempt <= retries; attempt += 1) {
      try {
        return await this.executeOnce(prepared, context);
      } catch (error) {
        if (!(error instanceof TransientToolError) || attempt === retries) {
          throw error;
        }
        await sleep(50 * 2 ** attempt);
      }
    }
    throw new Error("unreachable");
  }

  /**
   * 执行工具。
   * 读操作直接执行；写操作和 Shell 按 canonicalTarget 生成的业务键串行加锁，
   * 避免同一订单等目标上的并发写冲突。
   * @param {object} prepared 调用准备对象
   * @param {ExecutionContext} context 执行上下文
   * @returns {Promise<unknown>} 工具返回内容
   */
  async execute(prepared, context) {
    const policy = prepared.tool.policy;
    if (policy.effect === Effect.READ) {
      return this.executeWithRecovery(prepared, context);
    }

    const key = prepared.tool.canonicalTarget(prepared.args, context);
    if (!this.locks.has(key)) {
      this.locks.set(key, new AsyncLock());
    }
    return this.locks.get(key).run(() =>
      this.executeWithRecovery(prepared, context),
    );
  }

  /**
   * 调用后处理：写入审计记录（只记录参数键名，不记录参数值），
   * 并对返回内容脱敏后封装为 ToolResult。
   * @param {object} prepared 调用准备对象
   * @param {ExecutionContext} context 执行上下文
   * @param {{ok: boolean, content: unknown, errorCode: string|null, startedAt: number}} outcome 执行结果
   * @returns {Promise<ToolResult>} 工具调用结果
   */
  async afterToolCall(
    prepared,
    context,
    { ok, content, errorCode, startedAt },
  ) {
    const safeContent = redact(content);
    await this.audit.write({
      trace_id: context.traceId,
      tool_call_id: prepared.call.id,
      tool_name: prepared.tool.name,
      user_id: context.userId,
      tenant_id: context.tenantId,
      decision: prepared.decision,
      effect: prepared.tool.policy.effect,
      risk: prepared.tool.policy.risk,
      ok,
      error_code: errorCode,
      duration_ms: Math.round((performance.now() - startedAt) * 100) / 100,
      argument_keys: argumentKeys(prepared.call.arguments),
    });

    return new ToolResult({
      toolCallId: prepared.call.id,
      toolName: prepared.tool.name,
      ok,
      content: safeContent,
      errorCode,
    });
  }

  /**
   * 调用单个工具的统一入口。
   * 门禁失败时记录拒绝审计并返回失败结果；门禁通过后记录授权审计，
   * 再执行并把超时、临时故障和其他异常映射为稳定错误码返回。
   * @param {ToolCall} call 工具调用
   * @param {ExecutionContext} context 执行上下文
   * @returns {Promise<ToolResult>} 工具调用结果
   */
  async invoke(call, context) {
    const startedAt = performance.now();
    let prepared;

    try {
      prepared = await this.beforeToolCall(call, context);
    } catch (error) {
      if (!(error instanceof PolicyDenied)) {
        throw error;
      }
      await this.audit.write({
        trace_id: context.traceId,
        tool_call_id: call.id,
        tool_name: call.name,
        user_id: context.userId,
        tenant_id: context.tenantId,
        decision: PermissionDecision.DENY,
        ok: false,
        error_code: error.code,
        duration_ms: Math.round((performance.now() - startedAt) * 100) / 100,
        argument_keys: argumentKeys(call.arguments),
      });
      return new ToolResult({
        toolCallId: call.id,
        toolName: call.name,
        ok: false,
        content: redact(error.content),
        errorCode: error.code,
      });
    }

    await this.audit.write({
      trace_id: context.traceId,
      tool_call_id: call.id,
      tool_name: call.name,
      user_id: context.userId,
      tenant_id: context.tenantId,
      decision: prepared.decision,
      stage: "authorized",
      duration_ms: Math.round((performance.now() - startedAt) * 100) / 100,
      argument_keys: argumentKeys(call.arguments),
    });

    try {
      const content = await this.execute(prepared, context);
      return await this.afterToolCall(prepared, context, {
        ok: true,
        content,
        errorCode: null,
        startedAt,
      });
    } catch (error) {
      let code;
      let message;
      if (error instanceof PolicyDenied) {
        code = error.code;
        message = error.message;
      } else if (error instanceof ToolTimeoutError || error.name === "TimeoutError") {
        code =
          prepared.tool.policy.effect === Effect.WRITE
            ? "TIMEOUT_UNKNOWN"
            : "TIMEOUT";
        message =
          code === "TIMEOUT_UNKNOWN"
            ? "写操作结果未知，请按业务 ID 查询或转人工"
            : "查询超时，可稍后重试";
      } else if (error instanceof TransientToolError) {
        code = "TEMPORARY_UNAVAILABLE";
        message = "依赖暂时不可用，请稍后重试";
      } else {
        code = "TOOL_ERROR";
        message = "工具执行失败，请联系人工处理";
      }

      return this.afterToolCall(prepared, context, {
        ok: false,
        content: { message },
        errorCode: code,
        startedAt,
      });
    }
  }

  /**
   * 批量调用工具。
   * 只要批次中包含写操作就串行执行，保证顺序与副作用可控；
   * 纯读批次可并发执行。
   * @param {ToolCall[]} calls 工具调用列表
   * @param {ExecutionContext} context 执行上下文
   * @returns {Promise<ToolResult[]>} 与入参顺序对应的结果列表
   */
  async invokeBatch(calls, context) {
    const hasWrite = calls.some((call) => {
      const tool = this.tools.get(call.name);
      return tool?.policy.effect === Effect.WRITE;
    });
    if (hasWrite) {
      const results = [];
      for (const call of calls) {
        results.push(await this.invoke(call, context));
      }
      return results;
    }
    return Promise.all(calls.map((call) => this.invoke(call, context)));
  }
}

export { Risk };
