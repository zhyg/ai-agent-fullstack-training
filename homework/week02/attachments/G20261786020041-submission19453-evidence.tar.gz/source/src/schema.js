/**
 * 工具参数模型定义。
 * 以“手写校验 + JSON Schema”的方式实现与 Pydantic 等价的严格校验：
 * 拒绝未知字段、规范化字符串、将金额统一转换为“元 + 分”表示，
 * 并让模型侧看到的 schema 与实际校验规则保持一致。
 */
import { ValidationError } from "./errors.js";

/**
 * 判断值是否为普通对象（排除 null、数组）。
 * @param {unknown} value 待判断的值
 * @returns {boolean} 是普通对象时返回 true
 */
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

/**
 * 构造一条校验问题。
 * @param {string[]} path 字段路径
 * @param {string} message 问题描述
 * @param {string} [type] 问题类型，与典型校验库的错误类型对齐
 * @returns {{path: string[], message: string, type: string}} 校验问题对象
 */
function issue(path, message, type = "value_error") {
  return { path, message, type };
}

/**
 * 校验并规范化字符串：去首尾空白，按字符数检查长度并匹配正则。
 * @param {unknown} value 待校验的值
 * @param {string[]} path 字段路径，用于生成错误信息
 * @param {{minLength?: number, maxLength?: number, pattern?: RegExp}} [options] 约束条件
 * @returns {string} 规范化后的字符串
 * @throws {ValidationError} 类型、长度或格式不满足时抛出
 */
function validateString(value, path, { minLength = 0, maxLength = Infinity, pattern } = {}) {
  if (typeof value !== "string") {
    throw new ValidationError([issue(path, "Input should be a valid string", "string_type")]);
  }

  const normalized = value.trim();
  const length = [...normalized].length;
  if (length < minLength) {
    throw new ValidationError([
      issue(path, `String should have at least ${minLength} character${minLength === 1 ? "" : "s"}`, "string_too_short"),
    ]);
  }
  if (length > maxLength) {
    throw new ValidationError([
      issue(path, `String should have at most ${maxLength} characters`, "string_too_long"),
    ]);
  }
  if (pattern && !pattern.test(normalized)) {
    throw new ValidationError([
      issue(path, `String should match pattern '${pattern.source}'`, "string_pattern_mismatch"),
    ]);
  }
  return normalized;
}

/**
 * 校验对象类型并拒绝未知字段（additionalProperties: false 的运行时等价实现）。
 * @param {unknown} input 待校验的输入
 * @param {Set<string>} allowedKeys 允许出现的字段集合
 * @throws {ValidationError} 非对象或存在未知字段时抛出
 */
function strictObject(input, allowedKeys) {
  if (!isRecord(input)) {
    throw new ValidationError([issue([], "Input should be a valid object", "model_type")]);
  }

  const extras = Object.keys(input).filter((key) => !allowedKeys.has(key));
  if (extras.length > 0) {
    throw new ValidationError(
      extras.map((key) => issue([key], "Extra inputs are not permitted", "extra_forbidden")),
    );
  }
}

/**
 * 校验并规范化金额。
 * 接受数字或字符串，要求大于 0、最多两位小数、总有效位数不超过 10 位，
 * 使用 BigInt 计算分值以避免浮点误差。
 * @param {unknown} value 金额输入
 * @returns {{amount: string, amountCents: bigint}} 规范化金额（如 "399.00"）及对应分值
 * @throws {ValidationError} 金额格式、精度或范围不合法时抛出
 */
function validateAmount(value) {
  if (typeof value !== "string" && typeof value !== "number") {
    throw new ValidationError([issue(["amount"], "Input should be a valid decimal", "decimal_type")]);
  }
  if (typeof value === "number" && !Number.isFinite(value)) {
    throw new ValidationError([issue(["amount"], "Input should be a valid finite number", "decimal_type")]);
  }

  const text = String(value).trim();
  const match = /^([+-]?)(\d*)(?:\.(\d*))?$/.exec(text);
  if (!match || (!match[2] && !match[3])) {
    throw new ValidationError([issue(["amount"], "Input should be a valid decimal", "decimal_parsing")]);
  }

  const sign = match[1] === "-" ? -1n : 1n;
  const integerPart = (match[2] || "0").replace(/^0+(?=\d)/, "");
  const fractionPart = match[3] || "";

  if (fractionPart.length > 2) {
    throw new ValidationError([
      issue(["amount"], "Decimal input should have no more than 2 decimal places", "decimal_max_places"),
    ]);
  }

  const significantInteger = integerPart.replace(/^0+/, "") || "0";
  if (significantInteger.length + fractionPart.length > 10) {
    throw new ValidationError([
      issue(["amount"], "Decimal input should have no more than 10 digits", "decimal_max_digits"),
    ]);
  }

  const cents =
    sign * (BigInt(significantInteger) * 100n + BigInt(fractionPart.padEnd(2, "0") || "0"));
  if (cents <= 0n) {
    throw new ValidationError([issue(["amount"], "Input should be greater than 0", "greater_than")]);
  }

  const whole = cents / 100n;
  const fraction = String(cents % 100n).padStart(2, "0");
  return {
    amount: `${whole}.${fraction}`,
    amountCents: cents,
  };
}

/**
 * 校验订单号格式（ord_ 前缀加 4 位数字）。
 * @param {unknown} value 订单号输入
 * @returns {string} 规范化后的订单号
 * @throws {ValidationError} 不符合格式时抛出
 */
function validateOrderId(value) {
  return validateString(value, ["order_id"], {
    pattern: /^ord_[0-9]{4}$/,
  });
}

/**
 * 查询订单（get_order）的参数模型。
 * 仅接受 order_id 一个字段。
 */
export const GetOrderArgs = Object.freeze({
  name: "GetOrderArgs",
  jsonSchema: {
    type: "object",
    additionalProperties: false,
    properties: {
      order_id: { type: "string", pattern: "^ord_[0-9]{4}$" },
    },
    required: ["order_id"],
  },
  validate(input) {
    strictObject(input, new Set(["order_id"]));
    return { order_id: validateOrderId(input.order_id) };
  },
});

/**
 * 创建退款（create_refund）的参数模型。
 * 校验通过后额外输出 amount_cents（BigInt 分值），供业务预检和审计使用；
 * 任何额外的“已审批”“用户 ID”等字段都会被拒绝，防止越权参数注入。
 */
export const CreateRefundArgs = Object.freeze({
  name: "CreateRefundArgs",
  jsonSchema: {
    type: "object",
    additionalProperties: false,
    properties: {
      order_id: { type: "string", pattern: "^ord_[0-9]{4}$" },
      amount: {
        anyOf: [{ type: "number" }, { type: "string" }],
        exclusiveMinimum: 0,
      },
      reason: { type: "string", minLength: 4, maxLength: 200 },
    },
    required: ["order_id", "amount", "reason"],
  },
  validate(input) {
    strictObject(input, new Set(["order_id", "amount", "reason"]));
    const parsedAmount = validateAmount(input.amount);
    return {
      order_id: validateOrderId(input.order_id),
      amount: parsedAmount.amount,
      amount_cents: parsedAmount.amountCents,
      reason: validateString(input.reason, ["reason"], { minLength: 4, maxLength: 200 }),
    };
  },
});

/**
 * 搜索订单（search_orders）的参数模型。
 * status 限定为枚举值，limit 默认为 20 且限制在 1 到 50 之间。
 */
export const SearchOrdersArgs = Object.freeze({
  name: "SearchOrdersArgs",
  jsonSchema: {
    type: "object",
    additionalProperties: false,
    properties: {
      status: { type: "string", enum: ["paid", "shipped", "refunded"] },
      limit: { type: "integer", minimum: 1, maximum: 50, default: 20 },
    },
    required: ["status"],
  },
  validate(input) {
    strictObject(input, new Set(["status", "limit"]));
    const status = validateString(input.status, ["status"]);
    if (!["paid", "shipped", "refunded"].includes(status)) {
      throw new ValidationError([
        issue(["status"], "Input should be 'paid', 'shipped' or 'refunded'", "literal_error"),
      ]);
    }

    const limit = input.limit ?? 20;
    if (!Number.isInteger(limit)) {
      throw new ValidationError([issue(["limit"], "Input should be a valid integer", "int_type")]);
    }
    if (limit < 1 || limit > 50) {
      throw new ValidationError([
        issue(["limit"], "Input should be between 1 and 50", "int_range"),
      ]);
    }
    return { status, limit };
  },
});

/**
 * 执行 Shell（run_shell）的参数模型。
 * 仅在工具被启用且通过权限门禁时才会走到该模型。
 */
export const RunShellArgs = Object.freeze({
  name: "RunShellArgs",
  jsonSchema: {
    type: "object",
    additionalProperties: false,
    properties: {
      command: { type: "string", minLength: 1, maxLength: 200 },
    },
    required: ["command"],
  },
  validate(input) {
    strictObject(input, new Set(["command"]));
    return {
      command: validateString(input.command, ["command"], { minLength: 1, maxLength: 200 }),
    };
  },
});

/**
 * 创建转账（create_transfer）的参数模型。
 * 金额复用 validateAmount 统一转换为“元 + 分”；币种当前仅支持 CNY；
 * “自转账禁止”“单笔限额”等业务规则放在业务预检中，schema 只负责结构与格式。
 */
export const TransferArgs = Object.freeze({
  name: "TransferArgs",
  jsonSchema: {
    type: "object",
    additionalProperties: false,
    properties: {
      from_account: { type: "string", pattern: "^acc_[0-9]{4}$" },
      to_account: { type: "string", pattern: "^acc_[0-9]{4}$" },
      amount: {
        anyOf: [{ type: "number" }, { type: "string" }],
        exclusiveMinimum: 0,
      },
      currency: { type: "string", enum: ["CNY"] },
      memo: { type: "string", maxLength: 100 },
    },
    required: ["from_account", "to_account", "amount", "currency"],
  },
  validate(input) {
    strictObject(
      input,
      new Set(["from_account", "to_account", "amount", "currency", "memo"]),
    );
    const parsedAmount = validateAmount(input.amount);
    const currency = validateString(input.currency, ["currency"]);
    if (currency !== "CNY") {
      throw new ValidationError([
        issue(["currency"], "Input should be 'CNY'", "literal_error"),
      ]);
    }
    const result = {
      from_account: validateString(input.from_account, ["from_account"], {
        pattern: /^acc_[0-9]{4}$/,
      }),
      to_account: validateString(input.to_account, ["to_account"], {
        pattern: /^acc_[0-9]{4}$/,
      }),
      amount: parsedAmount.amount,
      amount_cents: parsedAmount.amountCents,
      currency,
    };
    if (input.memo !== undefined) {
      result.memo = validateString(input.memo, ["memo"], { maxLength: 100 });
    }
    return result;
  },
});

export { isRecord };
