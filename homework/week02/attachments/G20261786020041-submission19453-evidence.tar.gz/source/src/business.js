/**
 * 示例业务域：订单查询、退款预检和退款写入。
 * 使用内存 Map 模拟租户隔离的订单与退款数据，供治理运行时演示调用。
 */
import assert from "node:assert/strict";
import { PolicyDenied } from "./errors.js";

/** 初始订单数据（键为 tenantId:orderId），用于每次演示前重置 */
const INITIAL_ORDERS = [
  [
    "tenant_a:ord_1001",
    {
      status: "paid",
      refundable: "399.00",
      customer_email: "alice@example.com",
    },
  ],
];

/** 订单表：键为 `${tenantId}:${orderId}` */
export const ORDERS = new Map(INITIAL_ORDERS);
/** 退款表：键为 `${tenantId}:${orderId}`，用于模拟幂等写入 */
export const REFUNDS = new Map();

/** 初始账户数据：余额以“分”（bigint）记账，键为 `${tenantId}:${accountId}` */
const INITIAL_ACCOUNTS = [
  ["tenant_a:acc_2001", { status: "active", balance_cents: 100_000_00n }],
  ["tenant_a:acc_2002", { status: "active", balance_cents: 0n }],
];

/** 账户表：键为 `${tenantId}:${accountId}` */
export const ACCOUNTS = new Map(INITIAL_ACCOUNTS);
/** 转账台账：键为幂等键，用于防重放 */
export const TRANSFERS = new Map();

/** 单笔转账上限：5 万元（以分计） */
const SINGLE_TRANSFER_LIMIT_CENTS = 5_000_000n;

/**
 * 重置业务数据到初始状态（清空退款与转账记录，恢复初始订单和账户）。
 * @returns {void}
 */
export function resetBusinessData() {
  ORDERS.clear();
  for (const [key, value] of INITIAL_ORDERS) {
    ORDERS.set(key, { ...value });
  }
  REFUNDS.clear();
  ACCOUNTS.clear();
  for (const [key, value] of INITIAL_ACCOUNTS) {
    ACCOUNTS.set(key, { ...value });
  }
  TRANSFERS.clear();
}

/**
 * 生成租户隔离的订单键。
 * @param {string} tenantId 租户 ID
 * @param {string} orderId 订单 ID
 * @returns {string} `${tenantId}:${orderId}`
 */
function orderKey(tenantId, orderId) {
  return `${tenantId}:${orderId}`;
}

/**
 * 查询订单（读操作，幂等）。
 * @param {{order_id: string}} args 已校验的参数
 * @param {{tenantId: string}} context 执行上下文，用于租户隔离
 * @returns {Promise<{order_id: string, status: string, refundable: string, customer_email: string, access_token: string}>} 订单信息
 * @throws {Error} 订单不存在时抛出
 */
export async function getOrder(args, context) {
  assert.equal(args.constructor, Object);
  const order = ORDERS.get(orderKey(context.tenantId, args.order_id));
  if (!order) {
    throw new Error("order not found");
  }
  return {
    order_id: args.order_id,
    ...order,
    access_token: "do-not-leak",
  };
}

/**
 * 退款业务预检：订单必须存在且已支付，退款金额不得超过可退金额。
 * 该函数作为 create_refund 的 precheck，在审批核销和真正写入之前执行。
 * @param {{order_id: string, amount_cents: bigint}} args 已校验的参数
 * @param {{tenantId: string}} context 执行上下文
 * @returns {Promise<void>}
 * @throws {PolicyDenied} 订单不可退款或金额超限时抛出 BUSINESS_RULE_DENIED
 */
export async function checkRefund(args, context) {
  const order = ORDERS.get(orderKey(context.tenantId, args.order_id));
  if (!order || order.status !== "paid") {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "订单不存在或当前状态不可退款",
    );
  }

  const refundableCents = BigInt(order.refundable.replace(".", ""));
  if (args.amount_cents > refundableCents) {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "退款金额超过可退金额",
    );
  }
}

/**
 * 创建退款（写操作）。
 * 同一租户下的同一订单只写入一次，重复调用返回已有结果；返回值中记录幂等键便于追踪。
 * @param {{order_id: string, amount_cents: bigint}} args 已校验的参数
 * @param {{tenantId: string, idempotencyKey: string}} context 执行上下文
 * @returns {Promise<{refund_id: string, idempotency_key: string, tenant_id: string, order_id: string, amount: number, status: string}>} 退款结果
 */
export async function createRefund(args, context) {
  const key = orderKey(context.tenantId, args.order_id);
  if (REFUNDS.has(key)) {
    return { ...REFUNDS.get(key) };
  }

  const result = {
    refund_id: "ref_9001",
    idempotency_key: context.idempotencyKey,
    tenant_id: context.tenantId,
    order_id: args.order_id,
    amount: Number(args.amount_cents) / 100,
    status: "accepted",
  };
  REFUNDS.set(key, result);
  return { ...result };
}

/**
 * 生成租户隔离的账户键。
 * @param {string} tenantId 租户 ID
 * @param {string} accountId 账户 ID
 * @returns {string} `${tenantId}:${accountId}`
 */
function accountKey(tenantId, accountId) {
  return `${tenantId}:${accountId}`;
}

/**
 * 转账业务预检：账户必须存在且可用、禁止自转账、单笔限额、余额充足。
 * 该函数作为 create_transfer 的 precheck，在审批核销和真正扣款之前执行。
 * @param {{from_account: string, to_account: string, amount_cents: bigint}} args 已校验的参数
 * @param {{tenantId: string}} context 执行上下文
 * @returns {Promise<void>}
 * @throws {PolicyDenied} 任一业务规则不满足时抛出 BUSINESS_RULE_DENIED
 */
export async function checkTransfer(args, context) {
  const from = ACCOUNTS.get(accountKey(context.tenantId, args.from_account));
  const to = ACCOUNTS.get(accountKey(context.tenantId, args.to_account));
  if (!from || from.status !== "active") {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "转出账户不存在或已冻结",
    );
  }
  if (!to || to.status !== "active") {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "转入账户不存在或已冻结",
    );
  }
  if (args.from_account === args.to_account) {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "转出与转入账户不能相同",
    );
  }
  if (args.amount_cents > SINGLE_TRANSFER_LIMIT_CENTS) {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "单笔转账金额超过限额",
    );
  }
  if (args.amount_cents > from.balance_cents) {
    throw new PolicyDenied(
      "BUSINESS_RULE_DENIED",
      "转出账户余额不足",
    );
  }
}

/**
 * 创建转账（写操作）。
 * 以幂等键防重：同一幂等键重复调用返回首次结果；扣款用 BigInt 分记账。
 * @param {{from_account: string, to_account: string, amount_cents: bigint, currency: string, memo?: string}} args 已校验的参数
 * @param {{tenantId: string, idempotencyKey: string|null}} context 执行上下文
 * @returns {Promise<{transfer_id: string, idempotency_key: string|null, tenant_id: string, from_account: string, to_account: string, amount: number, currency: string, status: string}>} 转账结果
 * @throws {Error} 缺少幂等键或转出账户不存在时抛出
 */
export async function createTransfer(args, context) {
  if (!context.idempotencyKey) {
    throw new Error("transfer requires an idempotency key");
  }
  if (TRANSFERS.has(context.idempotencyKey)) {
    return { ...TRANSFERS.get(context.idempotencyKey) };
  }

  const from = ACCOUNTS.get(accountKey(context.tenantId, args.from_account));
  const to = ACCOUNTS.get(accountKey(context.tenantId, args.to_account));
  if (!from || !to) {
    throw new Error("account not found");
  }

  from.balance_cents -= args.amount_cents;
  to.balance_cents += args.amount_cents;

  const result = {
    transfer_id: `trf_${String(TRANSFERS.size + 1).padStart(4, "0")}`,
    idempotency_key: context.idempotencyKey,
    tenant_id: context.tenantId,
    from_account: args.from_account,
    to_account: args.to_account,
    amount: Number(args.amount_cents) / 100,
    currency: args.currency,
    status: "accepted",
  };
  if (args.memo !== undefined) {
    result.memo = args.memo;
  }
  TRANSFERS.set(context.idempotencyKey, result);
  return { ...result };
}

/**
 * 被禁用的 Shell 工具处理函数。
 * 正常情况下不应被调用；若被调用则直接抛错，用于验证禁用工具无法执行。
 * @returns {Promise<never>}
 * @throws {Error} 始终抛出
 */
export async function runShell() {
  throw new Error("disabled shell tool must not execute");
}
