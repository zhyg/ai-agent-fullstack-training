/**
 * 工具注册与运行时装配。
 * 在此集中声明各工具的描述、参数模型、治理策略和处理函数，
 * 并组装 PermissionEngine、ApprovalStore、AuditSink 与 ToolRuntime。
 */
import { ApprovalStore } from "./approval-store.js";
import {
  checkRefund,
  checkTransfer,
  createRefund,
  createTransfer,
  getOrder,
  runShell,
} from "./business.js";
import { Effect, Risk } from "./constants.js";
import { PermissionEngine } from "./permission-engine.js";
import {
  CreateRefundArgs,
  GetOrderArgs,
  RunShellArgs,
  TransferArgs,
} from "./schema.js";
import {
  AuditSink,
  ToolDefinition,
  ToolPolicy,
  ToolRuntime,
} from "./tool-runtime.js";

/**
 * 构建一套可直接使用的治理运行时。
 * 注册 get_order（只读低风险）、create_refund（写操作高风险、需审批、先业务预检）、
 * create_transfer（租户内转账，写操作高风险、需审批、先业务预检）
 * 和 run_shell（高风险但默认禁用）四个工具。
 * @returns {{runtime: ToolRuntime, approvals: ApprovalStore, audit: AuditSink}} 运行时及其依赖
 */
export function buildGovernance() {
  const approvals = new ApprovalStore();
  const audit = new AuditSink();
  const tools = [
    new ToolDefinition({
      name: "get_order",
      description: "查询订单当前状态和可退款金额。",
      parametersModel: GetOrderArgs,
      policy: new ToolPolicy({
        effect: Effect.READ,
        risk: Risk.LOW,
        permission: "order:read",
        timeoutSeconds: 1,
        maxRetries: 2,
        idempotent: true,
      }),
      handler: getOrder,
      canonicalTarget: (args, context) =>
        `${context.tenantId}:${args.order_id}`,
    }),
    new ToolDefinition({
      name: "create_refund",
      description: "为已支付订单创建退款申请。",
      parametersModel: CreateRefundArgs,
      policy: new ToolPolicy({
        effect: Effect.WRITE,
        risk: Risk.HIGH,
        permission: "refund:create",
        requiresApproval: true,
        timeoutSeconds: 2,
        maxRetries: 0,
        idempotent: false,
      }),
      handler: createRefund,
      precheck: checkRefund,
      canonicalTarget: (args, context) =>
        `${context.tenantId}:${args.order_id}`,
    }),
    new ToolDefinition({
      name: "create_transfer",
      description: "在当前租户内的两个账户之间转账。",
      parametersModel: TransferArgs,
      policy: new ToolPolicy({
        effect: Effect.WRITE,
        risk: Risk.HIGH,
        permission: "transfer:create",
        requiresApproval: true,
        timeoutSeconds: 2,
        maxRetries: 0,
        idempotent: false,
      }),
      handler: createTransfer,
      precheck: checkTransfer,
      canonicalTarget: (args, context) =>
        `${context.tenantId}:${args.from_account}`,
    }),
    new ToolDefinition({
      name: "run_shell",
      description: "执行受控 Shell 命令。",
      parametersModel: RunShellArgs,
      policy: new ToolPolicy({
        effect: Effect.SHELL,
        risk: Risk.HIGH,
        permission: "shell:run",
        enabled: false,
      }),
      handler: runShell,
      canonicalTarget: () => "shell",
    }),
  ];

  return {
    runtime: new ToolRuntime({
      tools,
      permissions: new PermissionEngine(),
      approvals,
      audit,
    }),
    approvals,
    audit,
  };
}
