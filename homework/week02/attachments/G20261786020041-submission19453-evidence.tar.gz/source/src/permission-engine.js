/**
 * 权限引擎：执行硬权限（工具白名单 + RBAC）判断。
 * 只有工具在调用方白名单内且上下文具备工具声明的权限时才放行。
 */
import { PermissionDecision } from "./constants.js";

export class PermissionEngine {
  /**
   * 判定一次工具调用是否被允许。
   * @param {import("./tool-runtime.js").ToolDefinition} tool 目标工具定义
   * @param {import("./tool-runtime.js").ExecutionContext} context 当前执行上下文
   * @returns {string} PermissionDecision.ALLOW 或 PermissionDecision.DENY
   */
  decide(tool, context) {
    if (!context.allowedTools.has(tool.name)) {
      return PermissionDecision.DENY;
    }
    if (!context.permissions.has(tool.policy.permission)) {
      return PermissionDecision.DENY;
    }
    return PermissionDecision.ALLOW;
  }
}
