/**
 * 工具治理的枚举常量。
 * 集中定义工具的副作用类型、风险等级、权限判定结果和执行模式，
 * 并提供用于运行时校验的取值集合。
 */

/** 工具副作用类型：read 只读、write 写操作、shell 命令执行 */
export const Effect = Object.freeze({
  READ: "read",
  WRITE: "write",
  SHELL: "shell",
});

/** 工具风险等级：low 低风险、high 高风险 */
export const Risk = Object.freeze({
  LOW: "low",
  HIGH: "high",
});

/** 权限引擎的判定结果：allow 放行、deny 拒绝、confirm 需要确认 */
export const PermissionDecision = Object.freeze({
  ALLOW: "allow",
  DENY: "deny",
  CONFIRM: "confirm",
});

/**
 * 执行模式：
 * default 默认模式；plan 只读规划模式（禁止写操作和 Shell）；
 * bypassPermissions 跳过确认检查；dontAsk 无法发起审批或确认。
 */
export const PermissionMode = Object.freeze({
  DEFAULT: "default",
  PLAN: "plan",
  BYPASS_PERMISSIONS: "bypassPermissions",
  DONT_ASK: "dontAsk",
});

/** effect 合法取值集合，用于 ToolPolicy 构造时校验 */
export const EFFECT_VALUES = new Set(Object.values(Effect));
/** risk 合法取值集合，用于 ToolPolicy 构造时校验 */
export const RISK_VALUES = new Set(Object.values(Risk));
/** 执行模式合法取值集合，用于调用前校验上下文 */
export const PERMISSION_MODE_VALUES = new Set(Object.values(PermissionMode));
