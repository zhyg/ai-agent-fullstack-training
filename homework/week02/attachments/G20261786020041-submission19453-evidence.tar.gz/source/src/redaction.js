/**
 * 结果脱敏与规模投影。
 * 在工具结果返回给模型或写入日志前做两层处理：
 * 1) redact：按键名和正则脱敏敏感信息（密钥、令牌、邮箱等）；
 * 2) projectForModel：限制嵌套深度、条目数和字符串长度，避免上下文被撑爆或注入过深结构。
 */

/** 敏感键名匹配规则：命中后整个值替换为 "***" */
const SENSITIVE_KEY =
  /token|secret|password|authorization|api_?key|credential|cookie|session|private_?key|access_?key/i;
/** 邮箱地址匹配规则：命中后做局部脱敏 */
const EMAIL = /[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g;

/** 返回给模型的内容最大嵌套深度 */
export const MODEL_MAX_DEPTH = 8;
/** 返回给模型的对象字段数 / 数组元素数上限 */
export const MODEL_MAX_ITEMS = 50;
/** 返回给模型的单字符串最大长度 */
export const MODEL_MAX_STRING_LENGTH = 2_000;

/**
 * 提取对象参数的可审计键名（排序后返回，不含任何值）。
 * 审计日志只记录键名，避免敏感参数值落盘。
 * @param {unknown} argumentsValue 工具调用参数
 * @returns {string[]} 排序后的键名列表；非对象输入返回空数组
 */
export function argumentKeys(argumentsValue) {
  if (argumentsValue === null || typeof argumentsValue !== "object" || Array.isArray(argumentsValue)) {
    return [];
  }
  return Object.keys(argumentsValue)
    .map(String)
    .sort();
}

/**
 * 递归脱敏：敏感键名的值替换为 "***"，字符串中的邮箱替换为 "***@***"。
 * 数组和对象保持原有结构，不修改入参。
 * @param {unknown} value 原始值
 * @returns {unknown} 脱敏后的新值
 */
export function redact(value) {
  if (Array.isArray(value)) {
    return value.map(redact);
  }
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        SENSITIVE_KEY.test(String(key)) ? "***" : redact(item),
      ]),
    );
  }
  if (typeof value === "string") {
    return value.replace(EMAIL, "***@***");
  }
  return value;
}

/**
 * 将任意结果投影为适合发送给模型的形态。
 * 超过深度、条目数或字符串长度上限的部分会被截断并附中文提示标记，
 * 最后统一执行一次脱敏，确保模型侧拿不到敏感内容。
 * @param {unknown} value 原始结果
 * @param {number} [depth] 当前递归深度（内部使用）
 * @returns {unknown} 投影并脱敏后的新值
 */
export function projectForModel(value, depth = 0) {
  if (depth >= MODEL_MAX_DEPTH) {
    return "[内容嵌套过深，已截断]";
  }
  if (Array.isArray(value)) {
    const projected = value
      .slice(0, MODEL_MAX_ITEMS)
      .map((item) => projectForModel(item, depth + 1));
    if (value.length > MODEL_MAX_ITEMS) {
      projected.push("[项目过多，已截断]");
    }
    return redact(projected);
  }
  if (value !== null && typeof value === "object") {
    const entries = Object.entries(value);
    const projected = Object.fromEntries(
      entries
        .slice(0, MODEL_MAX_ITEMS)
        .map(([key, item]) => [String(key), projectForModel(item, depth + 1)]),
    );
    if (entries.length > MODEL_MAX_ITEMS) {
      projected._truncated = "[字段过多，已截断]";
    }
    return redact(projected);
  }
  if (typeof value === "string") {
    const text = value.slice(0, MODEL_MAX_STRING_LENGTH);
    return redact(
      value.length > MODEL_MAX_STRING_LENGTH ? `${text}[文本过长，已截断]` : text,
    );
  }
  return redact(value);
}
