# Tool Governance Demo for Node.js

这是 `tool_governance_demo.py` 的 Node.js 等价实现。项目不依赖第三方包，要求 Node.js 20 或更高版本。

## 运行

```bash
npm start
npm test
```

也可以直接运行：

```bash
node src/demo.js
```

## 模块

| 模块 | 职责 |
|---|---|
| `src/schema.js` | 严格参数对象、未知字段拒绝、字符串清理和金额规范化 |
| `src/tool-runtime.js` | 工具定义、调用总编排、门禁、执行、超时、重试、并发和结果封装 |
| `src/permission-engine.js` | 工具白名单和 RBAC 硬权限判断 |
| `src/approval-store.js` | 参数摘要绑定、TTL 和一次性审批核销 |
| `src/redaction.js` | 敏感字段脱敏、邮箱脱敏和模型上下文规模投影 |
| `src/business.js` | 订单查询、退款预检和退款写入示例 |
| `src/governance.js` | 工具注册与运行时依赖装配 |
| `src/demo.js` | 复现 Python 示例的六个调用场景 |

## 公共入口

```javascript
import {
  buildGovernance,
  ExecutionContext,
  ToolCall,
} from "./src/index.js";

const { runtime } = buildGovernance();
const context = new ExecutionContext({
  traceId: "trace_001",
  userId: "u_100",
  tenantId: "tenant_a",
  permissions: ["order:read"],
  allowedTools: ["get_order"],
});

const result = await runtime.invoke(
  new ToolCall({
    id: "call_01",
    name: "get_order",
    arguments: { order_id: "ord_1001" },
  }),
  context,
);
```

## 安全行为

- 模型参数采用 `additionalProperties: false` 等价校验。
- `bypassPermissions` 只跳过确认检查。
- 审批绑定用户、租户、工具和规范化参数摘要。
- 写操作按 `tenantId:orderId` 加锁。
- 读操作和显式幂等操作才进入重试。
- 写操作超时返回 `TIMEOUT_UNKNOWN`。
- 结果返回模型前设置 `untrusted: true`。
- 审计记录参数键名，不记录参数值。

与 Python 示例相比，`modelTools()` 还过滤了禁用、deny 和 plan 模式禁止写操作的工具。
