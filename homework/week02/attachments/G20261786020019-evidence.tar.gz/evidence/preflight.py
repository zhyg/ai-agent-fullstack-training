"""取得真实学员工作树后检查导入对象；目前仅记录阻塞，不替代补测。"""
import importlib.util
import pathlib
import sys

root = pathlib.Path(sys.argv[1]).resolve()
print("student_root:", root)
if not (root / ".git").exists():
    print("BLOCKED: no successfully cloned student repository")
    raise SystemExit(2)
sys.path.insert(0, str(root))
spec = importlib.util.find_spec("tool_governance_demo")
print("module_origin:", spec.origin if spec else None)
if not spec or not spec.origin or not pathlib.Path(spec.origin).is_relative_to(root):
    print("BLOCKED: no verified student import; do not run business tests")
    raise SystemExit(2)
