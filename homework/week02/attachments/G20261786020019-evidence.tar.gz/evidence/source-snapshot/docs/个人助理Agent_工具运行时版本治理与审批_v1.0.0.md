# 个人助理 Agent 工具运行时：版本治理与审批

> 目标：个人助理 Agent
> 版本特性：工具运行时（工具定义、注册与版本、每轮快照、三段式执行、审批、审计）
> 版本：v1.0.0
>
> 适用范围：`backend/app/core/tools` 及 Agent Loop 的工具调用链路。
> 文档状态：设计已定稿并已在仓库落地。第 1 节与第 2.5 节保留迁移前基线，用于说明改造来源；第 12 节为当前实现现状与验证结果。

---

## 0. 结论摘要

1. 新增独立的 `tool runtime` 层，把「工具定义」「注册与版本」「每轮快照」「三段式执行」「结果与审计」拆成单向依赖的模块，避免工具实现、循环、提示词三者互相耦合。
2. **模型只能看到 `ToolSnapshot` 的元数据视图，永远拿不到 handler**。handler 只由 `ToolRuntime` 在唯一执行入口中解析和调用。
3. 每轮 LLM 调用前构建一次 `ToolSnapshot`，模型看到的工具集与回调执行时校验的版本完全来自同一快照；`ToolRuntime` 在真正执行前再读一次注册表实时状态，用于拦截快照构建后发生的禁用 / kill switch / 版本硬禁用 / 指纹变化。
4. 执行严格分三段：**校验 → 执行 → 输出**。失败以 `ToolResultMessage` 返回并回灌模型，不用异常打断主循环；只有取消等控制流才抛出异常。
5. 重试按错误分类决策，不采用「统一重试 N 次」。幂等性由 `ToolEffect` + handler 上报的错误阶段（`PRE_SIDE_EFFECT` / `POST_SIDE_EFFECT`）共同判定，非幂等写操作默认不重试。
6. 与现有能力对齐：沿用 `EventBuffer` 的单调 `seq`、`RunningTask` 的暂停/取消信号、`TaskService.wait_confirmation` 的二次确认、`error_traces` 异常链路、structlog 脱敏日志；只扩展字段，不另起事件体系。
7. 现有 3 个工具 `web_search` / `send_email` / `get_current_time` **一次性迁移为 handler**，不做长期兼容双轨；旧 `BaseTool` / `TOOL_REGISTRY` / `LegacyToolAdapter` 在迁移完成后已全部删除。

### 0.1 定稿决策

| # | 决策项 | 定稿结论 |
| --- | --- | --- |
| 1 | 旧工具迁移方式 | 一次性改写为新的 `ToolDefinition` + handler，不做长期兼容双轨；legacy 适配层不作为交付物保留 |
| 2 | kill switch 持久化 | 暂只存内存、即时生效，不做跨进程/重启持久化 |
| 3 | 非幂等工具重试 | 默认一律不重试（含邮件类写操作）；只有明确处于 `PRE_SIDE_EFFECT` 且分类可重放时才允许极小窗口，默认策略仍为 0 |
| 4 | 审批能力 | 收敛为通用「需审批」能力，挂在 `ToolRuntime`（`ApprovalGate`），不是只给危险工具开特例 |
| 5 | 权限来源 | 只从 `users` + `user_permissions` 两张表读取；不再假设单 Token 全量授权 |
| 6 | 其余设计项 | 按原第 11 节建议默认值执行（semver、task_id 灰度分桶、每轮快照、审计落库、`/runs` 同步接入等） |

---

## 1. 现状摸底

### 1.1 两套 Loop，工具调用路径不同（迁移前基线）

> 本节描述改造前的实现，仅用于说明设计来源；当前两套链路均已改为每轮 `build_snapshot()` + `runtime.execute()`。

| 组件 | 位置 | 工具声明 | 模型协议 | 工具执行 |
| --- | --- | --- | --- | --- |
| `AgentLoop`（任务 SSE 主链路） | `backend/app/core/loop.py` | 启动时 `TOOL_REGISTRY` 全量 `to_tool_def()` | JSON 决策 `action=tool_call` | `get_tool()` → 可选确认 → `tool.execute(args)` |
| `AgentRunner`（可复用 `/runs`） | `backend/app/core/runner.py` | `available_tools(tool_names)` | 原生 `tool_calls` | `_execute_tool()` → 可选 `confirm_handler` → `tool.execute()` |

关键落点：

- `AgentLoop.run()` 在进入循环前一次性生成 `tool_defs`：
  `backend/app/core/loop.py:75` `tool_defs = [t.to_tool_def() for t in TOOL_REGISTRY.values()]`
- 提示词只把工具清单拼进 System Prompt，不通过 `LLMRequest.tools` 传原生工具：
  `loop.py:233-241` → `build_system_message(tool_defs)`；
  `backend/app/core/prompt/renderer.py:80-87`。
- 工具名解析、确认、执行集中在 `loop.py:136-188`；结果通过 `tool_result` SSE 事件回传，并写入 `StepRecord` 供下一轮决策。
- `AgentRunner` 的做法不同：`runner.py:139-146` 取工具并生成 `tool_defs`；`runner.py:320-329` 把 `tools` 传给 `LLMRequest`；流式合并 `ToolCallDelta`；`runner.py:232-259` 回填 `assistant.tool_calls` 与 `role=tool` 消息。

> 设计必须同时兼容这两种模型协议。方案引入统一的 `ToolCallRequest` 归一化层，不为 AgentLoop 强行改成原生 tool calling，避免改动提示词协议与现有前端行为。

### 1.2 工具定义与注册现状（迁移前基线）

> 下列 `BaseTool` / `TOOL_REGISTRY` 代码已在实现阶段删除；当前定义见 `definition.py` 与 `catalog.py`。

`backend/app/core/tools/base.py`（已删除）：

```python
class ToolResult(BaseModel):
    tool_name: str
    success: bool
    data: dict = {}
    summary: str = ""
    error: str | None = None

class BaseTool(ABC):
    name: str
    description: str
    args_schema: type[BaseModel]
    requires_confirmation: bool = False

    async def execute(self, args: dict) -> ToolResult: ...
    def validate_args(self, args: dict) -> BaseModel: ...
    def to_tool_def(self) -> ToolDef: ...
```

`backend/app/core/tools/__init__.py` 使用模块级单例：

```python
TOOL_REGISTRY: dict[str, BaseTool] = {
    t.name: t for t in (WebSearchTool(), SendEmailTool(), GetCurrentTimeTool())
}
def get_tool(name: str) -> BaseTool: ...
```

限制：没有版本、权限、风险级别、依赖、并行能力、超时、重试、审计策略；同名多版本无法表达；禁用需要改代码重启。

### 1.3 现有基础设施（可直接复用）

| 能力 | 现有实现 | 复用方式 |
| --- | --- | --- |
| 事件序列 | `services/event_buffer.py`：`publish()` 分配单调 `seq`，内存 + SQLite + Condition 通知 | Runtime 通过 `ToolObserver` 回调，由 Loop 调 `_publish()`，不直接依赖 EventBuffer |
| 暂停/恢复 | `services/task_service.py` `RunningTask.pause/resume/wait_if_paused`；`loop.py` 在循环边界、读帧前、发布前、工具执行前检查 | 封装成 `ToolControl.checkpoint()`，Runtime 在审批前、每次尝试前、重试之间调用 |
| 取消 | `RunningTask.cancel_event`；`_stream_content` 抛 `asyncio.CancelledError` | `ToolControl` 检测到取消抛 `ToolCancelledError`，Loop 沿用现有终止逻辑 |
| 危险工具确认 | `loop.py:148-174` 发 `tool_confirmation_request` → `TaskService.wait_confirmation()`；`orchestrator.confirm()` → `resolve_confirmation()` | 封装成 `ApprovalGate`，确认接口保持 `step + tool_name` 兼容，新增可选 `tool_call_id` |
| 异常体系 | `core/exceptions.py`：`ErrorCode` 16xx 工具段、`AppException.retryable`、`get_error_stage()` | 扩展 16xx 错误码；Runtime 失败写 `error_traces` |
| 日志 | `infra/logger.py` structlog，`_mask_sensitive` 递归脱敏 | 新增 `tool_executed` / `tool_retry` / `tool_rejected` 事件；输入先脱敏再记录 |
| 数据库 | `infra/db.py` SQLite，`_SCHEMA` 用 `CREATE TABLE IF NOT EXISTS` | 新增 `tool_calls` 审计表；复用 `error_traces` |
| 输出脱敏 | `core/prompt/security.py` `sanitize_output()` 正则脱敏 | 扩展为结构化递归脱敏 `redaction.py` |
| 配置热加载 | `core/prompt/config.py` 按 mtime 热加载 JSON | 新增 `config/tools.json` 策略文件；当前为启动时加载，未实现 mtime 热加载（遗留项） |

### 1.4 需要解决的差距

1. 工具从「执行函数」升级为「定义 + 治理 + handler」，且模型层与执行层必须隔离。
2. 每轮工具集/版本要可冻结，且禁用要即时生效，需要快照 + 实时状态双层校验。
3. 工具失败要可分类、可重试、可审计，不再只是把异常字符串塞进 `ToolResult.error`。
4. `send_email` 这类非幂等副作用工具必须禁止盲目重试。
5. 现有 `ToolResult` 被前端和 `StepRecord` 依赖，新结果对象必须保留 `success` / `summary` / `error` 兼容字段。

---

## 2. 总体设计

### 2.1 设计原则

- **单向依赖**：`definition → registry → snapshot → runtime → loop`，禁止反向依赖；`handlers` 只被 `catalog` 与 `runtime` 引用。
- **模型视图最小化**：模型只拿到 `name / version / description / input_schema`，拿不到 handler、权限、重试、审计细节。
- **快照负责一致性，实时状态负责安全**：快照保证同一轮模型看到的工具与执行时解析的版本一致；实时状态保证构建快照后的紧急禁用立即拦截。
- **失败结果化**：业务/校验/超时/权限失败全部转成 `ToolResultMessage` 回灌模型；只有取消、进程级错误才抛出。
- **可观测优先**：每次调用都有 `tool_call_id + audit_id + snapshot_id + registry_revision`，可按 `trace_id` 串联。

### 2.2 分层与依赖方向

```
┌──────────────────────────────────────────────────────────────┐
│ api/routes/admin.py        api/routes/tasks.py               │
│        │                           │                         │
│        ▼                           ▼                         │
│  ToolRegistry（管理面）       Orchestrator / AgentLoop        │
│        │                           │                         │
│        │                           ▼                         │
│        │                    ToolRuntime（唯一执行入口）       │
│        │                     │      │      │                 │
│        ▼                     ▼      ▼      ▼                 │
│   RegistryState          snapshot validation retry          │
│        │                     │      │      │                 │
│        └──────────┬──────────┘      │      │                 │
│                   ▼                 ▼      ▼                 │
│              definition/enums     result  redaction/audit    │
│                   ▲                                          │
│                   │                                          │
│                    handlers/*（业务动作，不导出给模型层）      │
└──────────────────────────────────────────────────────────────┘
```

依赖规则：

- `enums.py`：只放枚举，被所有模块依赖。
- `definition.py`：依赖 `enums.py`、`pydantic`、`llm.schemas.ToolDef`；不依赖 registry/runtime。
- `snapshot.py`：依赖 `definition.py`、`llm.schemas`；纯不可变数据，不含 handler。
- `registry.py`：依赖 `definition.py`、`snapshot.py`；不依赖 runtime。
- `validation.py` / `retry.py` / `result.py` / `redaction.py` / `audit.py`：只依赖 `enums`、`definition`、`errors`，不依赖 registry/runtime。
- `runtime.py`：依赖 registry、snapshot、validation、retry、result、redaction、audit、session；不依赖 loop/api。
- `handlers/*`：只依赖 `definition`、`errors`、`session.HandlerContext`；禁止依赖 gateway/prompt/loop。
- 旧 `BaseTool` / `TOOL_REGISTRY` / legacy 适配层已删除，不存在第二套注册源，也不存在绕过 Runtime 的执行入口。
- `loop.py` / `runner.py`：只依赖 `runtime`、`snapshot`、`result`，**禁止 import handlers**。

### 2.3 实际文件清单

```
backend/app/core/tools/
├── __init__.py                 # 模块说明；不再导出旧 BaseTool / TOOL_REGISTRY
├── enums.py                    # RiskLevel / ToolEffect / ToolPermission / VersionStatus / ToolExecutionStatus / ToolErrorCategory / ErrorPhase / ApprovalStatus
├── definition.py               # ToolSpec / ToolErrorSpec / ToolDependency / ToolRetryPolicy / ToolAuditPolicy / ToolGovernance / HandlerOutput / ToolDefinition
├── snapshot.py                 # ToolRef / SnapshotSelection / ToolSnapshot（不含 handler）
├── session.py                  # ActorContext / ToolDependencyState / ToolControl / ApprovalGate / ToolObserver / ToolCallRequest / HandlerContext / ToolSession
├── validation.py               # 第一段：快照、版本、实时状态、权限、依赖、入参 schema
├── retry.py                    # 错误分类 + 重试对照表 + 退避/副作用判定
├── result.py                   # ToolResultMessage / ToolErrorInfo / ToolAuditRecord
├── redaction.py                # 结构化递归脱敏 + 稳定哈希 + 预览
├── audit.py                    # ToolAuditor：tool_calls 落库 + error_traces + structlog
├── runtime.py                  # ToolRuntime：open_session / build_snapshot / execute / execute_batch
├── errors.py                   # ToolBusinessError / ToolCancelledError / 注册表异常
├── policy.py                   # config/tools.json 启动加载与治理覆盖
├── catalog.py                  # build_default_registry()：注册 9 个工具
└── handlers/
    ├── __init__.py
    ├── get_current_time.py     # 迁移
    ├── web_search.py           # 迁移
    ├── send_email.py           # 迁移；非幂等写，0 重试
    ├── bills.py                # 电费/水费/燃气费查询（mock）
    └── shopping.py             # 购物申请 / 审批 / 查询（mock，进程内）
```

新增的非 tools 文件（均已落地）：

| 文件 | 职责 |
| --- | --- |
| `backend/app/core/tools/policy.py` | `config/tools.json` 启动加载，覆盖 governance（权限、超时、重试、风险、敏感字段） |
| `backend/app/api/routes/admin.py`（改造） | 工具列表 / kill switch / 版本切换 / 灰度 / 审计查询接口 |
| `backend/app/infra/db.py`（改造） | `users` / `user_permissions` / `tool_calls` 表、审计写入、用户权限查询 |
| `backend/app/api/schemas/sse.py`（改造） | `ToolCallData` / `ToolConfirmationRequestData` / `ToolResultData` 扩展可选字段 |
| `backend/app/api/schemas/task.py`（改造） | `ConfirmToolRequest` 增加可选 `tool_call_id` |
| `backend/app/services/task_service.py`（改造） | `PendingConfirmation.tool_call_id`，匹配逻辑兼容旧调用 |
| `backend/app/services/permission_service.py`（新增） | 从 `users` / `user_permissions` 解析权限 |
| `backend/app/core/loop.py` / `runner.py`（改造） | 接入 `ToolRuntime`，删除 `get_tool()` / `tool.execute()` 直调 |
| `backend/app/container.py`（改造） | 启动时构建 `ToolRegistry` / `ToolRuntime` / `ToolAuditor` / `PermissionService` |
| `backend/app/config.py`（改造） | 新增 `default_user_id`、`tool_runtime_enabled`、`tool_config_path`、快照 TTL、超时、审计开关 |
| `backend/config/tools.json`（新增） | 治理策略与静态 kill 配置 |

### 2.4 调用流程图

```mermaid
sequenceDiagram
    participant U as 用户
    participant L as AgentLoop
    participant R as ToolRegistry
    participant M as LLM
    participant RT as ToolRuntime
    participant H as Handler

    U->>L: start(task)
    loop 每一轮
        L->>L: 取消/暂停检查 + 步数检查
        L->>R: build_snapshot(task_id, round, tool_names)
        R-->>L: ToolSnapshot(元数据 + 版本 + 指纹)
        L->>M: System Prompt + snapshot.to_tool_defs()
        M-->>L: function call / JSON action=tool_call
        L->>L: 归一化为 ToolCallRequest(tool_call_id)
        L->>RT: execute(snapshot, call, session)
        RT->>RT: ① 校验：快照/版本/实时禁用/权限/依赖/入参 schema
        RT->>RT: ② 拦截：审批 Gate（危险工具）
        RT->>RT: ③ 执行：超时 + 并发 + 分类重试 + handler
        RT->>H: handler(validated_input, HandlerContext)
        H-->>RT: typed output / ToolBusinessError
        RT->>RT: ④ 输出：结果 schema 校验 + 脱敏 + 审计落库
        RT-->>L: ToolResultMessage(tool_call_id, status, audit_id)
        L->>L: 发布 tool_result（EventBuffer 分配 seq）
        L->>L: 注入 StepRecord / tool 消息
    end
```

### 2.5 需求中的 8 步与现有代码落点

| 步骤 | 现有落点 | 改造方式 |
| --- | --- | --- |
| 1. 读取注册工具 | `loop.py:75` 全量 `TOOL_REGISTRY`；`runner.py:139` `available_tools()` | 改为 `runtime.build_snapshot(session, round=...)`，由 registry 过滤可用工具 |
| 2. 构建 ToolSnapshot | 无 | 新增；每轮 LLM 调用前构建，`snapshot.to_tool_defs()` 供模型 |
| 3. 和提示词一起交给模型 | `loop.py:233-241` `build_system_message`；`runner.py:320-329` `LLMRequest.tools` | 传入快照的 `to_tool_defs()`；AgentLoop 保持 JSON 协议，Runner 保持原生 tool_calls |
| 4. 模型返回 function call | `loop.py:122-135` `AgentDecisionOutput`；`runner.py:309-354` 合并 `ToolCallDelta` | 新增归一化函数 `normalize_tool_call()`，统一成 `ToolCallRequest` |
| 5. ToolRuntime 处理 | `loop.py:142-188`；`runner.py:377-410` | 替换为 `await runtime.execute(snapshot, call, session)` |
| 6. 执行 handler | 迁移前 `BaseTool.execute()` | 当前为 `definition.handler`，只在 `ToolRuntime` 内部被调用；模型层无法引用 |
| 7. 返回 ToolResultMessage | `loop.py:181-196`；`runner.py:244-259` | 发布扩展后的 `tool_result`；写入 `StepRecord` / `role=tool` 消息；保留 `tool_call_id` |
| 8. 继续 loop | 循环体不变 | 只调整失败计数规则与快照重建时机 |

---

## 3. 关键数据结构

> 约定：注册表内部与快照使用 `dataclass(frozen=True)`，保证不可变；跨 API / 事件 / DB 的边界对象使用 Pydantic，便于校验与 JSON 序列化。所有含 `datetime` 的对象在发布 SSE / 写 JSON 时必须使用 `model_dump(mode="json")`。

### 3.1 枚举 `enums.py`

```python
class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ToolEffect(str, Enum):
    READ_ONLY = "read_only"                 # 可重放
    IDEMPOTENT_WRITE = "idempotent_write"   # 有幂等键时可重放
    NON_IDEMPOTENT_WRITE = "non_idempotent_write"  # 默认不可重放

class ToolPermission(str, Enum):
    TOOL_USE = "tool.use"
    NETWORK = "net.network"
    EMAIL_SEND = "email.send"
    FILE_WRITE = "file.write"
    ADMIN = "admin"

class ToolExecutionStatus(str, Enum):
    SUCCESS = "success"
    INVALID_INPUT = "invalid_input"
    PERMISSION_DENIED = "permission_denied"
    APPROVAL_DENIED = "approval_denied"
    APPROVAL_TIMEOUT = "approval_timeout"
    TOOL_DISABLED = "tool_disabled"
    VERSION_STALE = "version_stale"
    SNAPSHOT_EXPIRED = "snapshot_expired"
    DEPENDENCY_NOT_MET = "dependency_not_met"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    FAILED = "failed"
    OUTPUT_INVALID = "output_invalid"

class ToolErrorCategory(str, Enum):
    VALIDATION = "validation"
    PERMISSION = "permission"
    NOT_FOUND = "not_found"
    KILL_SWITCH = "kill_switch"
    VERSION_STALE = "version_stale"
    DEPENDENCY = "dependency"
    APPROVAL = "approval"
    TIMEOUT = "timeout"
    NETWORK = "network"
    RATE_LIMIT = "rate_limit"
    UPSTREAM = "upstream"
    AUTH = "auth"
    BUSINESS = "business"
    OUTPUT_SCHEMA = "output_schema"
    CANCELLED = "cancelled"
    INTERNAL = "internal"

class ErrorPhase(str, Enum):
    PRE_SIDE_EFFECT = "pre_side_effect"     # 确定未产生副作用，可安全重放
    POST_SIDE_EFFECT = "post_side_effect"   # 已产生副作用，不可重放
    UNKNOWN = "unknown"                     # 默认按不可重放处理

class ApprovalStatus(str, Enum):
    NOT_REQUIRED = "not_required"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"

class VersionStatus(str, Enum):
    ACTIVE = "active"       # 可执行
    DISABLED = "disabled"   # 硬禁用，立即不可执行
    DEPRECATED = "deprecated"  # 仍可执行但不再作为新快照默认版本
```

### 3.2 工具定义三部分 `definition.py`

#### 3.2.1 第一部分：实现信息 + schema + 异常声明 `ToolSpec`

```python
@dataclass(frozen=True)
class ToolErrorSpec:
    code: str                    # 业务错误码，如 "EMAIL_AUTH_FAILED"
    category: ToolErrorCategory
    retryable: bool
    model_message: str           # 给模型看的可行动信息
    audit_message: str           # 给审计/排障看的详细信息（写入前脱敏）

@dataclass(frozen=True)
class ToolSpec:
    name: str
    version: str                 # 建议 semver，如 "1.0.0"
    display_name: str
    description: str
    input_model: type[BaseModel]                 # 入参校验模型
    input_schema: dict[str, Any]                 # 由 input_model.model_json_schema() 预计算
    output_model: type[BaseModel] | None         # 输出校验模型；None 表示只要求 JSON 可序列化
    output_schema: dict[str, Any] | None         # 由 output_model.model_json_schema() 预计算
    error_specs: tuple[ToolErrorSpec, ...] = ()  # 该工具可能返回的业务错误
    examples: tuple[dict[str, Any], ...] = ()    # 可选，给文档/模型示例
```

说明：

- `input_schema` / `output_schema` 在注册时计算一次，快照直接复制，避免每轮重复生成 JSON Schema。
- `error_specs` 是「异常信息」的定义层声明；handler 实际抛出的异常必须能映射到某个 spec 或通用分类，未声明的异常会被归为 `INTERNAL` 并告警。

#### 3.2.2 第二部分：治理信息 `ToolGovernance`

```python
@dataclass(frozen=True)
class ToolDependency:
    tool_name: str
    version: str | None = None   # None = 不限制；否则必须与快照版本一致
    required: bool = True

@dataclass(frozen=True)
class ToolRetryPolicy:
    max_retries: int = 0
    base_delay: float = 0.5
    max_delay: float = 10.0
    jitter: bool = True
    retry_on: frozenset[ToolErrorCategory] = frozenset()
    respect_retry_after: bool = True

@dataclass(frozen=True)
class ToolAuditPolicy:
    enabled: bool = True
    include_input: bool = True
    input_preview_chars: int = 512
    include_output: bool = True
    output_preview_chars: int = 512
    sensitive_fields: frozenset[str] = frozenset()
    sample_rate: float = 1.0

@dataclass(frozen=True)
class ToolGovernance:
    permissions: frozenset[ToolPermission]
    risk_level: RiskLevel
    # None = 按风险级别推导：HIGH/CRITICAL 需要确认，LOW/MEDIUM 不需要
    requires_confirmation: bool | None = None
    parallelizable: bool = False
    effect: ToolEffect = ToolEffect.READ_ONLY
    dependencies: tuple[ToolDependency, ...] = ()
    timeout_seconds: float = 30.0          # 单次尝试超时
    total_timeout_seconds: float | None = None  # 总预算；None = timeout * (max_retries + 1)
    max_concurrency: int = 4               # 单工具并发上限
    retry_policy: ToolRetryPolicy = ToolRetryPolicy()
    audit_policy: ToolAuditPolicy = ToolAuditPolicy()
    allowed_tenants: frozenset[str] | None = None  # None = 所有租户

    @property
    def needs_approval(self) -> bool:
        if self.requires_confirmation is not None:
            return self.requires_confirmation
        return self.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)
```

关于 `tool_call_id`：

> 需求把 `tool_call_id` 放在定义第二部分。工程上它是「一次调用」的属性，不是「工具定义」的属性；同一工具会被并发调用多次，定义里不应固化某个 ID。因此本方案把 `tool_call_id` 放在 `ToolCallContext`、`ToolResultMessage`、`ToolAuditRecord`，定义层只在 `ToolGovernance` 保留可选的 `call_id_policy`（见下），运行时永远以调用上下文为准。
>
> 如果后续必须保留字段名，可在 `ToolGovernance` 增加只读的 `call_id_policy: Literal["server_generated", "prefer_model_id"]`，但不存具体 ID。

```python
# 可选补充到 ToolGovernance
call_id_policy: Literal["server_generated", "prefer_model_id"] = "server_generated"
```

#### 3.2.3 第三部分：handler 绑定 `ToolDefinition`

```python
class ToolHandler(Protocol):
    async def __call__(
        self,
        input: BaseModel,               # 已校验的入参模型，不是原始 dict
        ctx: HandlerContext,            # 只读上下文：tool_call_id/task_id/trace_id/attempt/idempotency_key/checkpoint()
    ) -> BaseModel | dict[str, Any] | None: ...

@dataclass(frozen=True)
class ToolDefinition:
    spec: ToolSpec
    governance: ToolGovernance
    handler: ToolHandler
    handler_id: str                  # 稳定标识，如 "handlers.send_email:send_email"

    @property
    def fingerprint(self) -> str:
        """执行身份指纹：spec + handler_id。治理策略变化不参与指纹。"""

    def to_model_view(self) -> ToolDef:
        """只输出模型可见字段，绝不包含 handler/governance。"""
        return ToolDef(
            name=self.spec.name,
            description=self.spec.description,
            parameters=self.spec.input_schema,
        )
```

### 3.3 快照 `snapshot.py`

```python
@dataclass(frozen=True)
class ToolRef:
    name: str
    version: str
    fingerprint: str
    handler_id: str
    risk_level: RiskLevel
    requires_confirmation: bool
    parallelizable: bool
    effect: ToolEffect
    dependencies: tuple[ToolDependency, ...]
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] | None

@dataclass(frozen=True)
class SnapshotSelection:
    requested_names: tuple[str, ...] | None
    actor_id: str | None
    tenant_id: str | None
    canary_names: tuple[str, ...] = ()   # 本轮命中的灰度工具，仅用于观测

@dataclass(frozen=True)
class ToolSnapshot:
    snapshot_id: str                     # uuid，审计关联键
    task_id: str
    trace_id: str
    round: int                           # 本轮步骤号，与 StepRecord.step 对齐
    registry_revision: int               # 构建时的注册表修订号
    created_at: datetime
    expires_at: datetime                 # 默认 created_at + tool_snapshot_ttl_seconds
    refs: tuple[ToolRef, ...]
    selection: SnapshotSelection

    def to_tool_defs(self) -> list[ToolDef]: ...
    def get(self, name: str) -> ToolRef | None: ...
    def names(self) -> tuple[str, ...]: ...
```

#### 快照生命周期

| 阶段 | 行为 |
| --- | --- |
| 创建 | 每轮 LLM 调用前，`runtime.build_snapshot(session, round=step, tool_names=...)`；从 registry 的实时 `RegistryState` 复制元数据 |
| 使用 | 同一轮的 `to_tool_defs()` 注入 System Prompt / `LLMRequest.tools`；同一轮回调的每次 `runtime.execute()` 都用这个快照解析工具名和版本 |
| 正常失效 | 本轮所有工具调用结束、进入下一轮前，不再使用；不显式持久化完整对象 |
| 暂停 | 原地暂停不失效；同一轮、同一条 LLM 流恢复后继续用同一快照 |
| 冷恢复 | 内存快照随进程丢失；下一轮重新构建（`TaskRuntime` 只恢复 `executed_steps`，不恢复快照） |
| 超时失效 | 超过 `expires_at`（默认 600s）后执行会被拒绝为 `SNAPSHOT_EXPIRED`；Loop 收到后重新构建快照（新快照仍包含该工具则重试本轮，否则让模型重新决策） |
| 紧急禁用 | 快照不失效，但 `runtime.execute()` 每次尝试前读实时状态，发现 kill switch / 硬禁用 / 指纹变化即拦截 |
| 审计 | `snapshot_id + registry_revision + 每个 ToolRef.version` 写入 `tool_calls`，可按快照复现当轮工具集 |

快照不含 handler，因此即使快照对象被日志、事件或调试代码序列化，也不会暴露可执行能力。

### 3.4 会话与调用上下文 `session.py`

`ToolSession` 是「一个任务一次」的上下文；`ToolCallContext` 是「一次调用一次」的上下文。这样依赖状态、暂停/取消、审批、观测器都按任务注入，而 `ToolRuntime` 本身可以是单例。

```python
@dataclass(frozen=True)
class ActorContext:
    actor_id: str | None
    tenant_id: str | None
    granted_permissions: frozenset[ToolPermission]

@dataclass
class ToolDependencyState:
    completed: dict[str, ToolRef]        # 本任务内成功完成的工具
    failed: set[str]
    def mark_completed(self, ref: ToolRef) -> None: ...
    def is_satisfied(self, dep: ToolDependency) -> bool: ...

class ToolControl(Protocol):
    def is_cancelled(self) -> bool: ...
    def is_paused(self) -> bool: ...
    async def checkpoint(self) -> None:
        """暂停时挂起等待；已取消时抛 ToolCancelledError。"""

class ApprovalGate(Protocol):
    async def request(self, req: ToolApprovalRequest) -> ApprovalDecision: ...

class ToolObserver(Protocol):
    async def on_retry(self, event: ToolRetryEvent) -> None: ...
    async def on_rejected(self, event: ToolRejectedEvent) -> None: ...
    # 最终结果由 Loop 统一发布 tool_result，避免 Runtime 直接依赖 EventBuffer

@dataclass
class ToolSession:
    session_id: str
    task_id: str
    trace_id: str
    actor: ActorContext
    control: ToolControl
    approval_gate: ApprovalGate
    observer: ToolObserver | None
    dependencies: ToolDependencyState
    idempotency_key: str | None = None

@dataclass(frozen=True)
class ToolCallRequest:
    tool_name: str
    arguments: dict[str, Any]
    tool_call_id: str                    # 服务端生成或模型提供，但不可信
    round: int

@dataclass(frozen=True)
class HandlerContext:
    tool_call_id: str
    task_id: str
    trace_id: str
    attempt: int                         # 从 0 开始
    idempotency_key: str | None
    deadline: float | None
    # 长时间 handler 可主动检查；不强制
    checkpoint: Callable[[], Awaitable[None]]

@dataclass(frozen=True)
class ToolApprovalRequest:
    task_id: str
    step: int
    round: int
    tool_call_id: str
    tool_name: str
    tool_version: str
    tool_args: dict[str, Any]
    risk_level: RiskLevel
    snapshot_id: str
    message: str

@dataclass(frozen=True)
class ApprovalDecision:
    approved: bool
    status: ApprovalStatus
    reason: str | None = None
```

### 3.5 结果与审计 `result.py`

```python
class ToolErrorInfo(BaseModel):
    category: ToolErrorCategory
    code: str                          # ErrorCode 或 ToolErrorSpec.code
    message: str                       # 审计用（已脱敏）
    model_message: str                 # 回灌模型用，简短、可行动
    retryable: bool
    retry_count: int = 0
    retry_strategy: str | None = None  # "retry_exhausted(2)" / "no_retry_non_idempotent" ...
    phase: ErrorPhase = ErrorPhase.UNKNOWN

class ToolResultMessage(BaseModel):
    # 调用身份
    tool_call_id: str
    tool_name: str
    tool_version: str
    snapshot_id: str
    audit_id: str

    # 结果
    status: ToolExecutionStatus
    success: bool                      # 兼容现有前端/StepRecord 的字段
    data: dict[str, Any] = Field(default_factory=dict)
    summary: str = ""
    error: str | None = None           # 兼容现有前端的字符串错误
    error_info: ToolErrorInfo | None = None

    # 执行/观测
    duration_ms: int = 0
    retry_count: int = 0
    redaction_applied: bool = False
    possible_side_effect: bool = False # 非幂等工具超时/5xx 时提示结果不确定
    created_at: datetime

    def to_llm_content(self) -> str:
        """压缩后的 JSON 字符串，用于 role=tool 内容或 StepRecord 摘要。"""
        ...

    def to_publish_payload(self) -> dict[str, Any]:
        """model_dump(mode="json")，供 SSE tool_result。"""
        ...

class ToolAuditRecord(BaseModel):
    audit_id: str
    trace_id: str
    task_id: str | None
    snapshot_id: str
    registry_revision: int
    step: int
    round: int
    tool_call_id: str
    tool_name: str
    tool_version: str

    actor_id: str | None
    tenant_id: str | None
    permission_decision: Literal["granted", "denied"]
    risk_level: RiskLevel
    approval_status: ApprovalStatus
    effect: ToolEffect
    idempotency_key: str | None

    status: ToolExecutionStatus
    error_category: ToolErrorCategory | None
    error_code: str | None
    retry_count: int = 0
    retry_strategy: str | None = None
    possible_side_effect: bool = False

    duration_ms: int
    input_hash: str                    # sha256(规范化 JSON)，用于复现
    input_preview: str | None          # 已脱敏 + 截断
    output_hash: str | None
    output_preview: str | None         # 已脱敏 + 截断
    redaction_applied: bool = False
    created_at: datetime
```

> `success` / `error` 是刻意保留的兼容字段：现有前端 `useTask.ts` 读取 `result.success` 与 `result.error`，`AgentRunner._execute_tool` 也返回 `(content, result.success)`。新结果对象通过这两个字段保持旧行为，同时增加结构化 `error_info`。

### 3.6 审计表 DDL（`infra/db.py` 追加）

```sql
CREATE TABLE IF NOT EXISTS tool_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_id TEXT NOT NULL UNIQUE,
    trace_id TEXT NOT NULL,
    task_id TEXT,
    snapshot_id TEXT NOT NULL,
    registry_revision INTEGER NOT NULL,
    step INTEGER NOT NULL,
    round INTEGER NOT NULL,
    tool_call_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    tool_version TEXT NOT NULL,
    actor_id TEXT,
    tenant_id TEXT,
    risk_level TEXT NOT NULL,
    permission_decision TEXT NOT NULL,
    approval_status TEXT NOT NULL,
    effect TEXT NOT NULL,
    idempotency_key TEXT,
    status TEXT NOT NULL,
    error_category TEXT,
    error_code TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    retry_strategy TEXT,
    possible_side_effect INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER NOT NULL,
    input_hash TEXT NOT NULL,
    input_preview TEXT,
    output_hash TEXT,
    output_preview TEXT,
    redaction_applied INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_trace ON tool_calls(trace_id);
CREATE INDEX IF NOT EXISTS idx_tool_calls_task ON tool_calls(task_id, step);
CREATE INDEX IF NOT EXISTS idx_tool_calls_tool ON tool_calls(tool_name, tool_version, status);
```

可选（审计要求严格时再建）：`tool_snapshots(snapshot_id, task_id, trace_id, round, registry_revision, tools_json, created_at, closed_at)`。第一阶段不做，避免增加写入量；`tool_calls` 已能还原每轮工具集。

---

## 4. ToolRegistry 与版本管理

### 4.1 注册表状态模型

```python
@dataclass(frozen=True)
class VersionRecord:
    definition: ToolDefinition
    status: VersionStatus
    registered_at: datetime
    fingerprint: str
    metadata: dict[str, Any]

@dataclass(frozen=True)
class CanaryConfig:
    version: str
    ratio: int                         # 0~100
    allowlist: frozenset[str] = frozenset()  # actor_id 白名单
    enabled: bool = True

@dataclass(frozen=True)
class ToolEntry:
    name: str
    versions: Mapping[str, VersionRecord]
    stable_version: str | None
    canary: CanaryConfig | None
    killed: bool
    kill_reason: str | None
    killed_versions: frozenset[str]    # 针对单版本的紧急禁用
    allowed_tenants: frozenset[str] | None

@dataclass(frozen=True)
class RegistryState:
    revision: int
    tools: Mapping[str, ToolEntry]
    updated_at: datetime
    updated_by: str | None
```

`ToolRegistry` 内部持有 `_state: RegistryState`，所有写操作用 `asyncio.Lock` 保护，然后**整体替换** `_state`（copy-on-write）。读操作（快照构建、Runtime 实时校验）直接读当前不可变 `_state`，无需加锁，保证 kill switch 即时生效且不阻塞任务。

### 4.2 注册与同名多版本

```python
class ToolRegistry:
    def register(
        self,
        definition: ToolDefinition,
        *,
        activate: bool = False,       # 是否设为 stable
        replace: bool = False,        # 仅管理面允许覆盖同版本
        actor: str | None = None,
    ) -> None: ...

    def unregister(self, name: str, version: str, *, actor: str | None = None) -> None: ...

    def get_active(self, name: str, *, ctx: SelectionContext) -> ToolDefinition | None: ...
    def list_active(self, *, ctx: SelectionContext) -> list[ToolDefinition]: ...
```

规则：

1. `(name, version)` 唯一。重复注册：
   - 指纹相同 → 幂等 no-op，不增加 revision。
   - 指纹不同且 `replace=False` → 抛 `ToolVersionConflictError`。
   - `replace=True` → 覆盖并 `revision += 1`；旧快照执行时因指纹不一致被拦截为 `VERSION_STALE`。
2. `activate=True` 时设置 `stable_version`；否则若该工具还没有 stable，默认把第一个成功注册的 ACTIVE 版本设为 stable。
3. `allowed_tenants` 在注册时与 `policy.py` 合并；不在允许租户内时工具不进入快照。
4. 版本号建议 semver；不要求模型可见。模型只看到 `name`，版本由快照在服务端解析，避免模型伪造版本。

### 4.3 默认版本、灰度与选择算法

选择发生在**快照构建时**，每个任务每轮一次：

```text
candidates = 注册表中 status=ACTIVE 且未被 kill、租户允许、actor 权限允许的工具
for name in candidates:
    version = stable_version
    if canary.enabled and canary.version is ACTIVE and not killed:
        bucket = int(sha256(f"{task_id}:{name}").hexdigest()[:8], 16) % 100
        if bucket < canary.ratio or actor_id in canary.allowlist:
            version = canary.version
    ref = ToolRef(version, fingerprint, ...)
```

要点：

- 灰度按 `task_id + name` 哈希分桶，**同一任务的同一工具在整个任务生命周期内稳定命中同一版本**，避免同一任务内来回切换。
- 灰度版本被硬禁用或 kill 时自动回退 stable。
- 显式 `tool_names` 只限制工具集合，不改变版本选择；模型不能指定版本。
- 快照记录 `SnapshotSelection.canary_names`，审计和日志可追踪灰度命中。

### 4.4 禁用与紧急禁用（kill switch）

| 操作 | 语义 | 生效范围 | 是否立即生效 |
| --- | --- | --- | --- |
| `disable_version(name, version)` | 硬禁用某版本，不可执行 | 该版本的所有快照 | 是，Runtime 每次尝试前读实时状态 |
| `enable_version(name, version)` | 恢复某版本 | 之后可执行 | 是 |
| `set_active(name, version)` | 切换默认 stable 版本 | 只影响**之后构建的快照** | 当前轮不变 |
| `set_canary(name, cfg)` | 调整灰度 | 只影响之后构建的快照 | 当前轮不变 |
| `kill(name, reason)` | 紧急禁用该工具所有版本 | 所有快照、所有任务 | 是，立即拦截 |
| `kill_version(name, version, reason)` | 紧急禁用单版本 | 该版本快照 | 是 |
| `kill_all(reason)` | 全工具紧急禁用 | 全局 | 是 |
| `revive(name)` / `revive_version()` | 解除 | 之后可执行 | 是 |

实现细节：

- `kill` / `disable_version` 与 `set_active` / `set_canary` 语义不同：前两者是**安全硬拦截**，需要 Runtime 实时检查；后两者是**版本选择变更**，只影响下一轮快照。
- 写操作创建新的 `RegistryState` 并原子替换；同时写入 structlog `tool_kill_switch` 事件，包含 `name/version/reason/actor/revision`。
- `kill` 不会中断已经进入 handler 的非协作副作用调用（无法撤销邮件已发出的动作）；但会在**下一次尝试、下一次重试、下一次输出提交前**检查并停止。handler 可通过 `HandlerContext.checkpoint()` 主动响应。
- 定稿：kill switch 只存内存、即时生效，进程重启后不保留；`config/tools.json` 的 `kill_switch` 仅在启动时作为静态初值。跨进程持久化（`tool_states` 表）明确推迟，不在本期实现。

### 4.5 快照与 Runtime 双层拦截

| 层 | 时机 | 检查内容 | 作用 |
| --- | --- | --- | --- |
| 第一层：快照构建 | 每轮 LLM 调用前 | kill、版本 status、租户、权限、工具集合、依赖闭包 | 模型看不到被禁用工具；冻结本轮工具集与版本 |
| 第二层：Runtime 校验 | 每次 `execute` 开始、每次重试前、输出提交前 | 实时 kill、版本是否被硬禁用、指纹是否变化、快照是否过期 | 拦截「快照构建后工具被紧急禁用/替换」 |

第二层校验必须直接读 `registry.state()`，不能复用快照里的布尔值，否则 kill switch 无法即时生效。若 `state.revision != snapshot.registry_revision` 但只是 `set_active`/`set_canary`，不拦截；只有以下情况拦截：

```text
state.tools[name].killed                         -> TOOL_DISABLED / KILL_SWITCH
version in state.tools[name].killed_versions     -> TOOL_DISABLED / KILL_SWITCH
state.tools[name].versions[version].status == DISABLED -> VERSION_STALE
state.tools[name].versions[version].fingerprint != ref.fingerprint -> VERSION_STALE
now > snapshot.expires_at                        -> SNAPSHOT_EXPIRED
```

### 4.6 管理面接口（已实现）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/v1/admin/tools` | 工具、版本、stable/canary、kill 状态、revision |
| POST | `/api/v1/admin/tools/kill-all` | body：`reason`；全局紧急禁用 |
| POST | `/api/v1/admin/tools/revive-all` | 解除全局禁用 |
| POST | `/api/v1/admin/tools/{name}/kill` | body：`reason`，可选 `version`；紧急禁用 |
| POST | `/api/v1/admin/tools/{name}/revive` | 解除 kill |
| POST | `/api/v1/admin/tools/{name}/active` | body：`version`；切换 stable |
| POST | `/api/v1/admin/tools/{name}/canary` | body：`version/ratio/allowlist/enabled` |
| POST | `/api/v1/admin/tools/{name}/versions/{version}/disable` | 硬禁用版本 |
| POST | `/api/v1/admin/tools/{name}/versions/{version}/enable` | 恢复版本 |
| GET | `/api/v1/admin/tool-calls` | 按 `trace_id/task_id/tool_name/status` 分页查询审计记录 |

这些接口复用现有 Bearer 鉴权中间件，不新增鉴权体系；当前无角色校验（见第 12 节已知限制）。设计稿中的 `GET /tools/{name}` 单工具详情与 `POST /tools/reload` 未实现。

### 4.7 策略配置加载 `policy.py`（启动时）

`config/tools.json` 只放**可运维调整的治理项**，不放 handler 代码：

```json
{
  "version": "1",
  "defaults": {
    "timeout_seconds": 30,
    "total_timeout_seconds": 60,
    "max_concurrency": 4,
    "snapshot_ttl_seconds": 600
  },
  "tools": {
    "web_search": {
      "risk_level": "low",
      "effect": "read_only",
      "permissions": ["tool.use", "net.network"],
      "timeout_seconds": 30,
      "retry_policy": {
        "max_retries": 2,
        "retry_on": ["timeout", "network", "rate_limit", "upstream"]
      }
    },
    "send_email": {
      "risk_level": "high",
      "requires_confirmation": true,
      "effect": "non_idempotent_write",
      "permissions": ["tool.use", "email.send"],
      "timeout_seconds": 30,
      "retry_policy": {"max_retries": 0},
      "audit_policy": {
        "sensitive_fields": ["to", "cc", "body"],
        "input_preview_chars": 256
      }
    },
    "get_current_time": {
      "risk_level": "low",
      "effect": "read_only",
      "permissions": ["tool.use"],
      "retry_policy": {"max_retries": 0}
    }
  },
  "kill_switch": {
    "send_email": false
  }
}
```

> 实际 `backend/config/tools.json` 只覆盖 `send_email` / `web_search` / `approve_shopping_request`，其余工具使用 `catalog.py` 的内置治理。

- 当前实现在容器启动时读取一次 `config/tools.json`，写入 `ToolRegistry` 的治理覆盖；**未实现 mtime 热加载**（遗留项）。
- 启动加载只更新治理字段（权限、风险、超时、重试、敏感字段、静态 kill 初值），不改变指纹；运行中的 kill/revive 通过管理面接口即时生效（内存态）。
- 输入 schema / output schema / handler_id 变化属于代码变更，必须通过注册（新版本号）发生，不能由配置文件修改。

---

## 5. ToolRuntime 三段式执行

```python
class ToolRuntime:
    def __init__(
        self,
        registry: ToolRegistry,
        auditor: ToolAuditor,
        logger,
        *,
        default_max_concurrency: int = 8,
    ): ...

    def open_session(
        self,
        *,
        task_id: str,
        trace_id: str,
        actor: ActorContext,
        control: ToolControl,
        approval_gate: ApprovalGate,
        observer: ToolObserver | None = None,
    ) -> ToolSession: ...

    def build_snapshot(
        self,
        session: ToolSession,
        *,
        round: int,
        tool_names: list[str] | None = None,
        now: datetime | None = None,
    ) -> ToolSnapshot: ...

    async def execute(
        self,
        snapshot: ToolSnapshot,
        call: ToolCallRequest,
        session: ToolSession,
    ) -> ToolResultMessage: ...

    async def execute_batch(
        self,
        snapshot: ToolSnapshot,
        calls: list[ToolCallRequest],
        session: ToolSession,
    ) -> list[ToolResultMessage]: ...
```

### 5.1 第一段：校验（validate）

执行顺序与失败返回：

| 顺序 | 检查项 | 规则 | 失败返回 |
| --- | --- | --- | --- |
| 1 | 快照归属 | `snapshot.task_id == session.task_id`；`snapshot_id` 非空 | `FAILED / INTERNAL`（编程错误） |
| 2 | 快照过期 | `now > snapshot.expires_at` | `SNAPSHOT_EXPIRED / VERSION_STALE` |
| 3 | 工具在快照中 | `snapshot.get(call.tool_name)` 必须存在 | `FAILED / NOT_FOUND`，model_message 提示工具不存在 |
| 4 | 实时 kill | `registry.state()` 检查工具级/版本级 kill | `TOOL_DISABLED / KILL_SWITCH` |
| 5 | 版本可执行 | 版本 status != DISABLED；`fingerprint` 与快照一致 | `VERSION_STALE / VERSION_STALE` |
| 6 | 权限 | `governance.permissions ⊆ actor.granted_permissions` | `PERMISSION_DENIED / PERMISSION` |
| 7 | 依赖 | 每个 `required=True` 的依赖在 `session.dependencies.completed` 中且版本匹配；可选依赖可缺失 | `DEPENDENCY_NOT_MET / DEPENDENCY` |
| 8 | 入参 schema | `input_model.model_validate(call.arguments)`；忽略未声明字段（`model_config.extra="ignore"` 或显式 `forbid`，按工具定义） | `INVALID_INPUT / VALIDATION`，附 pydantic 错误位置（脱敏） |
| 9 | 审批 | 见 5.2 拦截；审批不是校验失败，但失败时同样返回结果 | `APPROVAL_DENIED` / `APPROVAL_TIMEOUT` |

失败处理原则：

- 第 3-8 项失败**不抛异常**，直接构造 `ToolResultMessage` 返回，让模型看到可行动错误（例如参数错误提示字段名）。
- 第 1 项属于 Runtime 自身编程错误，记录 `INTERNAL` + stack trace，但仍返回结果避免主循环崩溃。
- 校验阶段不产生任何副作用，因此这些失败都不写入 `possible_side_effect`。
- 校验失败也要写审计记录（`status` 为对应失败状态），便于统计「模型幻觉调用」和「权限拒绝」。

依赖校验的补充规则：

- 快照构建时对 `required` 依赖做**闭包补齐**：请求工具 A 时若 A 依赖 B 且 B 可用，则自动把 B 放入快照；若 B 不可用（被 kill/无权限/不存在），则 A 不进入快照，模型看不到 A。
- 执行时再检查依赖是否**已成功完成**；仅出现在快照中不算满足。
- 依赖版本不一致（`ToolDependency.version` 指定时）视为 `DEPENDENCY_NOT_MET`。

### 5.2 第二段：执行（execute）

#### 拦截：审批 Gate

在校验通过、真正调用 handler 之前：

```python
if definition.governance.needs_approval:
    decision = await session.approval_gate.request(ToolApprovalRequest(...))
    if not decision.approved:
        return denied_result(decision.status)   # APPROVAL_DENIED / APPROVAL_TIMEOUT
```

- 审批发生在权限检查之后：无权限的工具不会弹确认框。
- 审批发生在 kill 检查之后：已紧急禁用的工具不打扰用户。
- 审批期间 `ApprovalGate` 内部继续受 `ToolControl` 的暂停/取消信号控制（现有 `wait_confirmation` 会被 `stop` 暂停逻辑影响的方式需在适配器中保持：暂停只停止输出，不取消确认等待；取消则终止）。
- `CRITICAL` 风险工具可在 Gate 中要求二次确认或管理员令牌，第一阶段至少与 HIGH 一样确认。

#### 超时与并发

```python
attempt_timeout = min(
    governance.timeout_seconds,
    remaining_total_budget,
    remaining_task_deadline,   # ToolCallContext.deadline 若存在
)
output = await asyncio.wait_for(
    definition.handler(validated_input, handler_ctx),
    timeout=attempt_timeout,
)
```

- `total_timeout_seconds` 默认 `timeout_seconds * (max_retries + 1)`；每次尝试前重新计算剩余预算。
- 单工具并发：`_tool_semaphores[(name, version)] = asyncio.Semaphore(max_concurrency)`，懒加载，避免在非事件循环中创建。
- 全局并发：`_global_semaphore = asyncio.Semaphore(tool_max_concurrency)`。
- 获取并发令牌本身也受剩余预算限制；获取超时视为 `TIMEOUT`，且确定未产生副作用。
- `execute_batch`：
  - 所有工具 `parallelizable=True`、无审批、无依赖 → `asyncio.gather` 并发执行（受全局/单工具信号量限制）。
  - 任一工具需要审批、`parallelizable=False`、有依赖 → 按声明顺序串行，保证确认弹窗与依赖顺序可解释。
  - 单个失败不影响同批其他调用；结果按 `calls` 原顺序返回。

#### 重试分类策略

错误分类来源：

1. handler 主动抛 `ToolBusinessError(category, code, message, phase)`；
2. runtime 把基础设施异常映射为分类（`httpx.TimeoutException`、`ConnectError`、`asyncio.TimeoutError`、`aiosmtplib` 异常等）；
3. 未识别异常 → `INTERNAL`。

| 错误分类 | 典型来源 | 是否重试 | 最大次数 | 退避 | 非幂等写操作 | 说明 |
| --- | --- | --- | --- | --- | --- | --- |
| `VALIDATION` | 入参 schema 失败 | 否 | 0 | - | 否 | 模型参数错误，回灌让模型修正 |
| `PERMISSION` | actor 缺少 scope | 否 | 0 | - | 否 | 配置/授权问题，不自动重试 |
| `NOT_FOUND` | 快照无此工具 | 否 | 0 | - | 否 | 模型幻觉调用 |
| `KILL_SWITCH` | 运维 kill | 否 | 0 | - | 否 | 立即拦截 |
| `VERSION_STALE` | 版本硬禁用/指纹变化/快照过期 | 否 | 0 | - | 否 | 下一轮重建快照 |
| `DEPENDENCY` | 依赖未成功 | 否 | 0 | - | 否 | 让模型先调用依赖 |
| `APPROVAL` | 用户拒绝/超时 | 否 | 0 | - | 否 | 跳过该调用 |
| `TIMEOUT` | handler 超时 | 只读/幂等是；非幂等否 | 2（只读/幂等） | 指数 + jitter，0.5s 起 | 否 | 非幂等超时 = 结果未知，标记 `possible_side_effect` |
| `NETWORK` | `ConnectError` / DNS / 连接失败（请求未发出） | 是 | 3 | 指数 + jitter | 仅 `PRE_SIDE_EFFECT` | 可安全重放 |
| `RATE_LIMIT` | 429 / 供应商限流 | 是 | 2 | 遵守 `Retry-After` | 仅 `PRE_SIDE_EFFECT` | 请求被拒绝，无副作用 |
| `UPSTREAM` | 502/503/504 | 只读/幂等是 | 2 | 指数 + jitter | 否（除非 `PRE_SIDE_EFFECT`） | 5xx 可能已执行 |
| `AUTH` | 401/403/配置缺失 | 否 | 0 | - | 否 | 需人工修配置/密钥 |
| `BUSINESS` | 业务拒绝（SMTP 535、搜索鉴权失败等） | 否 | 0 | - | 否 | 确定性失败 |
| `OUTPUT_SCHEMA` | handler 输出不符合 `output_model` | 否 | 0 | - | 否 | 代码缺陷，告警 |
| `CANCELLED` | 用户取消 | 否 | 0 | - | 否 | 中断 |
| `INTERNAL` | 未捕获异常 | 否（默认） | 0 | - | 否 | 记录 stack，待修复 |

退避公式复用 `app/llm/retry.py` 的思路：

```text
delay = min(base_delay * 2^attempt, max_delay)
if jitter: delay *= uniform(0.5, 1.5)
if retry_after is not None and respect_retry_after: delay = min(retry_after, max_delay)
```

#### 幂等性与可重放判定

```text
replay_safe =
    effect == READ_ONLY
    or (effect == IDEMPOTENT_WRITE and idempotency_key is not None)
    or (effect == NON_IDEMPOTENT_WRITE and error.phase == PRE_SIDE_EFFECT)
```

- `idempotency_key` 由 Runtime 在**第一次尝试前**生成（`uuid4`），所有重试复用同一个 key，传给 `HandlerContext`；handler 若无法利用该 key 实现幂等，则应把自身声明为 `NON_IDEMPOTENT_WRITE`。
- `send_email` 必须声明 `NON_IDEMPOTENT_WRITE`，默认 `max_retries=0`；只有 `SMTPConnectError` 这类确定未发出的错误才允许最多 1 次重试（handler 必须标记 `PRE_SIDE_EFFECT`）。
- 超时与 5xx 对非幂等工具一律不自动重试，返回 `TIMEOUT` / `UPSTREAM`，并在 `ToolResultMessage.possible_side_effect=True` 与审计中标记，让模型/用户人工核对。
- 重试次数与策略写入 `ToolErrorInfo.retry_count/retry_strategy` 和审计，便于排障。

#### 暂停/取消

- Runtime 在以下位置调用 `session.control.checkpoint()`：
  1. 校验开始前；
  2. 审批请求前；
  3. 每次 handler 尝试前；
  4. 每次重试等待前；
  5. 输出提交前。
- `checkpoint()` 语义：
  - 暂停中 → `await wait_if_paused()` 挂起，不抛异常；
  - 已取消 → 抛 `ToolCancelledError`，Loop 捕获后沿用现有 `CancelledError` 处理（`_terminate(CANCELLED)` 或 Runner 的 `RunCancelledError`）。
- 暂停不终止正在执行的 handler（与现有「不终止 LLM 流」一致）；但保证**暂停期间不会发起新的副作用调用**。
- 取消同理：只能阻止下一次尝试；已经开始且不可撤销的副作用（如邮件已提交）无法回滚，审计记录会保留。
- handler 若为长时间任务，可在内部循环调用 `HandlerContext.checkpoint()` 协作响应取消；非协作 handler 不强制中断。

### 5.3 第三段：输出（finalize）

1. **结果 schema 校验**
   - handler 返回 `BaseModel`：用 `model_dump(mode="json")` 得到 `data`；若定义了 `output_model`，再 `output_model.model_validate(data)`。
   - handler 返回 `dict`：若定义了 `output_model`，执行 `output_model.model_validate`；否则只要求可 JSON 序列化。
   - handler 返回 `None`：视为空数据。
   - 校验失败 → `OUTPUT_INVALID / OUTPUT_SCHEMA`，不重试，记录 stack 与 output 摘要（脱敏后）。
2. **摘要生成**
   - 优先使用 `HandlerOutput.summary`（建议 handler 返回 `ToolHandlerOutput(data, summary)`），否则按工具名生成默认摘要。
   - `sanitize_output()` + 截断到 `audit_policy` 或全局 `tool_summary_max_chars`（建议 2000），避免提示词膨胀。
3. **脱敏**
   - `redaction.py`：
     - 对 `data` 递归处理：命中 `SENSITIVE_KEYS`（复用 logger 的 key 集合）或 `audit_policy.sensitive_fields` 的字段替换为 `***REDACTED***`；
     - 对所有字符串值应用 `sanitize_output()`（API Key、Bearer、password 等正则）；
     - 输入与输出分别生成 `hash`（原始规范化 JSON 的 sha256）和 `preview`（脱敏 + 截断）。
   - `redaction_applied` 记录是否发生替换。
4. **审计落库**
   - 构造 `ToolAuditRecord`；
   - `auditor.record(record)`：先写 structlog `tool_executed`，再 `db.insert_tool_audit(record)`；
   - 审计写入失败不改变工具结果，只记 `tool_audit_write_failed` 错误日志（避免审计系统故障导致业务失败）；
   - 失败调用额外写 `error_traces`：
     - `stage`: `tool_validation` / `tool_execution` / `tool_output`
     - `error_type`: 16xx 错误码
     - `strategy`: `retry_exhausted(n)` / `no_retry_non_idempotent` / `killed` / `approval_denied` 等
     - `retry_count`: 实际重试次数
5. **返回 `ToolResultMessage`**
   - `success = (status == SUCCESS)`；
   - `error` 保留字符串兼容；
   - `error_info` 提供结构化分类；
   - `data/summary` 已脱敏；
   - `tool_call_id` 始终保留。

### 5.4 结果状态与主循环失败计数

| status | 是否回灌模型 | 是否计入连续失败 | 说明 |
| --- | --- | --- | --- |
| `SUCCESS` | 是 | 否 | 正常 |
| `INVALID_INPUT` | 是 | 是（建议） | 模型可修正参数 |
| `PERMISSION_DENIED` | 是 | 否 | 配置问题，重试无意义 |
| `APPROVAL_DENIED` / `APPROVAL_TIMEOUT` | 是 | 否 | 保持现有「跳过继续」语义 |
| `TOOL_DISABLED` / `VERSION_STALE` / `SNAPSHOT_EXPIRED` | 是 | 否 | 下一轮重建快照或模型换工具 |
| `DEPENDENCY_NOT_MET` | 是 | 是 | 让模型先调用依赖 |
| `TIMEOUT` / `FAILED` / `OUTPUT_INVALID` | 是 | 是 | 连续失败达上限终止 |
| `CANCELLED` | 否（终止任务） | - | 走取消流程 |

建议保留现有 `MAX_CONSECUTIVE_FAILURES = 3`，只按上表调整计数范围。

### 5.5 Runtime 伪代码

```python
async def execute(self, snapshot, call, session):
    await session.control.checkpoint()
    audit_id = gen_audit_id()
    start = time.perf_counter()

    # ── ① 校验 ──
    checked = validation.check(snapshot, call, session)
    if isinstance(checked, ValidationFailure):
        return await self._finalize_failure(
            checked, snapshot, call, session, audit_id, start
        )

    definition = checked.definition
    validated_input = checked.input

    # ── ② 拦截：审批 ──
    if definition.governance.needs_approval:
        decision = await session.approval_gate.request(build_approval_request(...))
        if not decision.approved:
            return await self._finalize_failure(
                approval_failure(decision), snapshot, call, session, audit_id, start
            )

    # ── ③ 执行：超时 + 并发 + 重试 ──
    attempts = 0
    last_error = None
    while True:
        await session.control.checkpoint()
        self._check_live_registry(snapshot, definition)   # kill/disable/fingerprint
        try:
            async with self._semaphores(definition):
                output = await asyncio.wait_for(
                    definition.handler(
                        validated_input,
                        HandlerContext(... attempt=attempts ...),
                    ),
                    timeout=attempt_timeout,
                )
            break
        except ToolBusinessError as e:
            last_error = classify(e)
        except asyncio.TimeoutError as e:
            last_error = classify_timeout(e, definition)
        except Exception as e:
            last_error = classify_internal(e)

        if not decide_retry(definition, last_error, attempts):
            break
        attempts += 1
        await asyncio.sleep(compute_delay(definition.governance.retry_policy, attempts))

    # ── ④ 输出：校验 + 脱敏 + 审计 ──
    return await self._finalize(
        output_or_error=last_error or output,
        snapshot=snapshot,
        definition=definition,
        call=call,
        session=session,
        audit_id=audit_id,
        attempts=attempts,
        start=start,
    )
```

---

## 6. 与 Loop 的接入

### 6.1 `AgentLoop`（任务主链路）

改造位置：`backend/app/core/loop.py`

```python
class AgentLoop:
    def __init__(
        self,
        gateway, event_buffer, task_service, logger,
        tool_runtime: ToolRuntime | None = None,   # 新增
        tool_runtime_enabled: bool = True,          # 新增，便于灰度回滚
    ):
        ...

    async def run(self, running: RunningTask) -> None:
        rt = running.runtime
        session = self._tool_runtime.open_session(
            task_id=rt.task_id,
            trace_id=rt.trace_id,
            actor=build_actor_from_task(rt),
            control=TaskControlAdapter(running),
            approval_gate=TaskApprovalGate(running, self._task_service, self._publish),
            observer=TaskToolObserver(running, self._publish),
        )
        consecutive_failures = 0

        while True:
            # ① 取消/暂停/步数检查保持原样
            ...
            rt.current_step += 1
            step = rt.current_step

            # ② 本轮快照（新增）
            snapshot = self._tool_runtime.build_snapshot(session, round=step)
            tool_defs = snapshot.to_tool_defs()

            # ③ LLM 决策（沿用 build_system_message）
            decision, usage = await self._decide(running, snapshot, consecutive_failures)
            ...
            # ④ 模型返回 tool_call 后
            call = normalize_decision_call(decision, task_id=rt.task_id, round=step)
            await self._publish(TOOL_CALL, ToolCallData(...))

            # ⑤ ToolRuntime 统一处理（替换原 get_tool/确认/_execute_tool）
            result = await self._tool_runtime.execute(snapshot, call, session)

            # ⑥ 发布结果（扩展字段，仍用 EventBuffer.seq）
            await self._publish(TOOL_RESULT, ToolResultData(
                step=step,
                tool_name=result.tool_name,
                result=result.to_publish_payload(),
                duration_ms=result.duration_ms,
                tool_call_id=result.tool_call_id,
                tool_version=result.tool_version,
                status=result.status.value,
                error_category=result.error_info.category.value if result.error_info else None,
                retry_count=result.retry_count,
                audit_id=result.audit_id,
                snapshot_id=result.snapshot_id,
            ).model_dump(mode="json"))

            # ⑦ 注入上下文
            rt.executed_steps.append(StepRecord(
                step=step, thought=decision.thought, action=decision.action.value,
                tool_name=result.tool_name, tool_args=decision.tool_args,
                tool_summary=result.summary if result.success else (result.error or "工具执行失败"),
                tool_call_id=result.tool_call_id,
                tool_version=result.tool_version,
                tool_status=result.status.value,
                audit_id=result.audit_id,
            ))
            ...
```

具体删除/替换：

- 删除 `loop.py:75` 的 `tool_defs = [t.to_tool_def() for t in TOOL_REGISTRY.values()]`，改到每轮快照。
- `_decide()` 签名由 `tool_defs` 改为 `snapshot`，内部仍调用 `build_system_message(snapshot.to_tool_defs())`。
- 删除 `loop.py:142-174` 的 `get_tool` + `requires_confirmation` + `wait_confirmation` 代码；确认逻辑移入 `TaskApprovalGate`。
- 删除 `_execute_tool()`（`loop.py:317-332`）；由 `ToolRuntime.execute()` 承担异常分类、重试、审计。
- 保留 `tool_call` 事件在 Runtime 之前发布，保持现有前端展示顺序；确认事件由 Gate 内部发布，顺序为 `tool_call` → `tool_confirmation_request` → `tool_result`。

`TaskApprovalGate` 适配器（新增在 `loop.py` 或 `adapters/task_gate.py`）：

```python
async def request(self, req: ToolApprovalRequest) -> ApprovalDecision:
    await self._publish(TOOL_CONFIRMATION_REQUEST, ToolConfirmationRequestData(
        step=req.step, tool_name=req.tool_name, tool_args=req.tool_args,
        message=f"请确认是否执行 {req.tool_name}",
        tool_call_id=req.tool_call_id, risk_level=req.risk_level.value,
        tool_version=req.tool_version, snapshot_id=req.snapshot_id,
    ).model_dump(mode="json"))
    ok = await self._task_service.wait_confirmation(
        running, step=req.step, tool_name=req.tool_name,
        tool_args=req.tool_args, tool_call_id=req.tool_call_id,
    )
    return ApprovalDecision(approved=ok,
        status=ApprovalStatus.APPROVED if ok else ApprovalStatus.DENIED)
```

### 6.2 `AgentRunner`（原生 tool calls）

改造位置：`backend/app/core/runner.py`

- 每轮开始前构建快照：

```python
snapshot = runtime.build_snapshot(session, round=rounds)
tool_defs = snapshot.to_tool_defs()
content, calls, usage = await self._llm_round(..., tool_defs=tool_defs, ...)
```

- `_execute_tool()`（`runner.py:377-410`）替换为：

```python
result = await runtime.execute(
    snapshot,
    ToolCallRequest(
        tool_name=call.name,
        arguments=call.arguments,
        tool_call_id=call.id or gen_tool_call_id(...),
        round=rounds,
    ),
    session,
)
content = result.to_llm_content()
```

- 回填 `Message(role="tool", tool_call_id=call_id, name=call.name, content=content)` 保持原协议。
- `confirm_handler` 参数可保留为兼容；新实现由 `ApprovalGate` 注入：`/runs` 默认 `AutoDenyApprovalGate`（危险工具返回拒绝，保持现有「无确认处理器则跳过」行为），需要确认时由路由层传入 `RunApprovalGate`。
- `available_tools()` 改为调用 registry 的 `validate_names()` 或在构建临时快照时校验；错误信息保持 `ValidationException`。

### 6.3 `Orchestrator` / `Container` / 配置

`backend/app/container.py` 启动顺序追加：

```python
# DB 初始化之后
self.tool_registry = build_default_registry(policy=load_tool_policy(settings.tool_config_path))
self.tool_auditor = ToolAuditor(self.db, self.logger)
self.tool_runtime = ToolRuntime(self.tool_registry, self.tool_auditor, self.logger)
# Orchestrator 接收 tool_runtime
self.orchestrator = Orchestrator(..., tool_runtime=self.tool_runtime)
```

`Orchestrator._run()` 构造 `AgentLoop` 时传入 `self._tool_runtime`；`runs.py` 构造 `AgentRunner` 时同样传入。

`config.py` 新增：

```python
tool_runtime_enabled: bool = True
tool_config_path: str = "./config/tools.json"
tool_audit_enabled: bool = True
tool_default_timeout_seconds: float = 30.0
tool_total_timeout_seconds: float = 60.0
tool_max_concurrency: int = 8
tool_snapshot_ttl_seconds: int = 600
tool_summary_max_chars: int = 2000
tool_retry_max_attempts: int = 3
```

> 定稿：`tool_runtime_enabled` 默认 `True`，两套链路直接接入 Runtime，不再保留 passthrough / legacy 路径；回滚通过关闭开关并重启完成。

### 6.4 现有工具迁移结果

**已按「一次性迁移、无双轨」完成：**

- `web_search` / `send_email` / `get_current_time` 已改写为 `handlers/*`：
  - 入参模型保留，作为 `input_model`；
  - 新增 typed output（如 `WebSearchOutput` / `SendEmailOutput` / `GetCurrentTimeOutput`）；
  - 业务异常改为 `ToolBusinessError(category, code, phase)`，不再抛 `ToolExecutionException`；
  - `send_email` 的 SMTP 凭据只从 `settings` 读取，handler 不接收密钥参数。
- 新增 mock 工具：`query_electricity_bill` / `query_water_bill` / `query_gas_bill`、`submit_shopping_request` / `approve_shopping_request` / `get_shopping_request`。
- `catalog.py` 显式声明每个工具的 `effect`、风险、权限、审批与重试策略：`send_email=NON_IDEMPOTENT_WRITE`、`web_search/get_current_time/账单查询=READ_ONLY`、购物写操作=非幂等。
- `adapters/legacy.py`、`base.py`、`TOOL_REGISTRY` / `get_tool` 已删除，`tools/__init__.py` 只保留模块说明。

---

## 7. 安全边界：模型无法绕过 Runtime 调用 handler

机制清单：

1. **视图隔离**
   - `ToolDefinition.to_model_view()` 只返回 `name/description/input_schema`；
   - `ToolSnapshot` 只存 `ToolRef` 元数据，不存 `handler`、`handler_id` 也不暴露给模型；
   - Prompt 渲染只接收 `list[ToolDef]`，`ToolDef` 中没有 handler 字段。
2. **唯一执行入口**
   - `ToolRuntime.execute()` / `execute_batch()` 是唯一会调用 handler 的公开方法；
   - `ToolRegistry` 不提供 `call()` / `get_handler()` 公开方法；handler 解析只发生在 `runtime.py` 内部。
3. **工具名只从快照解析**
   - 模型返回的 `tool_name` 必须命中 `snapshot.refs`；
   - 禁止用 `registry.get(name)` 兜底，避免模型调用快照外工具（包括被 kill 的工具）。
4. **版本与参数不可信**
   - 模型提供的 `tool_call_id` / 版本提示只用于审计，不作为权限或版本依据；
   - 参数必须经过 `input_model` 校验后才能进入 handler。
5. **权限服务端判定**
   - `ActorContext.granted_permissions` 来自服务端任务上下文/鉴权信息；
   - 模型和提示词无法修改权限；确认弹窗也不能绕过权限（先权限校验，后审批）。
6. **handler 上下文最小化**
   - `HandlerContext` 不包含 gateway、prompt、event_buffer、registry；
   - handler 只能做业务动作，无法再次调用 LLM 或读取注册表。
7. **工程约束（建议加入 CI）**
   - `tests/test_tool_boundary.py`：
     - 断言 `app/core/loop.py` / `runner.py` / `prompt/*` 不 import `app.core.tools.handlers`；
     - 断言 `ToolSnapshot` 实例没有 `handler` 属性；
     - 断言 `ToolDefinition.__repr__` 不包含 handler 源码。
   - `handlers/__init__.py` 的 `__all__` 只导出函数名；不导出 `BaseTool`。

> Python 的“私有”是约定级，真正可验证的边界是：模型侧数据对象不携带可调用引用 + 唯一执行入口 + 测试扫描 import。三者同时成立，才能防止后续重构把 handler 泄露回 prompt/loop。

---

## 8. 权限、风险级别与审批

### 8.1 风险级别

| 风险级别 | 默认行为 | 适用工具示例 |
| --- | --- | --- |
| LOW | 自动执行；基础审计 | `get_current_time`、只读搜索 |
| MEDIUM | 自动执行；完整审计 | 外部只读 API、可能产生成本的查询 |
| HIGH | 必须二次确认；完整审计 | `send_email`、写文件、外部写操作 |
| CRITICAL | 二次确认 + 可扩展管理员复核；禁止并行 | 删除、支付、批量发送 |

### 8.2 权限

- 工具声明 `permissions`（如 `tool.use`、`net.network`、`email.send`、`bill.query`、`shopping.request`、`shopping.approve`）。
- 权限来源固定为 SQLite `users` + `user_permissions`：`PermissionService.resolve(actor_id)` 读取用户状态与权限集合，非 active 用户返回空权限。
- 默认种子：`user_default`（admin，含 `tool.use/net.network/email.send/bill.query/shopping.request/shopping.approve`）、`user_guest`（仅 `tool.use`）。
- `ActorContext` 由任务/请求上下文构造；当前单 Token 入口固定映射到 `settings.default_user_id`，尚无多用户登录切换。
- 权限失败返回 `PERMISSION_DENIED`，不弹确认框，不调用 handler。

### 8.3 与现有确认流程的衔接（通用审批门）

现有流程（迁移前）：

```text
AgentLoop 检测 requires_confirmation
  → 发布 tool_confirmation_request
  → TaskService.wait_confirmation()（300s 超时）
  → Orchestrator.confirm() → resolve_confirmation(step, tool_name)
  → 确认后执行 / 取消后跳过该步骤
```

新流程：

```text
ToolRuntime 校验通过
  → definition.governance.needs_approval
  → ApprovalGate.request()
      → TaskApprovalGate 发布 tool_confirmation_request（新增 tool_call_id/risk/snapshot）
      → TaskService.wait_confirmation(step, tool_name, tool_call_id)
  → approved ? 执行 : 返回 APPROVAL_DENIED / APPROVAL_TIMEOUT
```

兼容改造：

- `ConfirmToolRequest` 增加可选 `tool_call_id`、`snapshot_id`；
- `PendingConfirmation` 增加 `tool_call_id`；
- `resolve_confirmation` 匹配规则：
  - 请求带 `tool_call_id` → 精确匹配 `(step, tool_name, tool_call_id)`；
  - 未带 → 回退现有 `(step, tool_name)`，保证旧前端/脚本可用；
- 确认超时仍按「未确认」处理，Loop 继续下一轮，不终止任务；
- 取消（用户点击暂停）不影响已挂起的确认等待；真正取消任务时 `ToolControl` 使等待退出。

---

## 9. 可观测性

### 9.1 审计字段

每次调用必须有：

```text
trace_id, task_id, step, round, snapshot_id, registry_revision,
tool_call_id, audit_id, tool_name, tool_version,
actor_id, tenant_id, permission_decision,
risk_level, approval_status, effect, idempotency_key,
status, error_category, error_code, retry_count, retry_strategy,
possible_side_effect, duration_ms,
input_hash, input_preview(脱敏+截断),
output_hash, output_preview(脱敏+截断),
redaction_applied, created_at
```

落库：`tool_calls` 表；失败同时写 `error_traces`（stage 扩展为 `tool_validation` / `tool_execution` / `tool_output`）。

### 9.2 日志

structlog 事件建议：

| 事件 | 级别 | 字段 |
| --- | --- | --- |
| `tool_snapshot_built` | debug | trace_id, task_id, round, snapshot_id, revision, tools[name,version], canary |
| `tool_executed` | info | 审计核心字段（不含原始敏感值） |
| `tool_retry` | warning | trace_id, tool_call_id, tool_name, attempt, category, delay_ms |
| `tool_rejected` | warning | tool_call_id, reason（权限/审批/禁用） |
| `tool_kill_switch` | warning | name, version, reason, actor, revision |
| `tool_audit_write_failed` | error | trace_id, audit_id, error |

注意：`input_preview` / `output_preview` 必须先经 `redaction.py` 处理，再交给 structlog；不要依赖 logger 的 key 脱敏来做内容级脱敏。

### 9.3 SSE 事件与 seq

沿用现有 `EventBuffer.publish()`，所有事件自动获得单调 `seq`，不新增独立事件通道。

扩展现有 `ToolResultData`（全部为可选字段，保证旧前端兼容）：

```python
class ToolResultData(BaseModel):
    step: int
    tool_name: str
    result: dict
    duration_ms: int
    tool_call_id: str | None = None
    tool_version: str | None = None
    status: str | None = None
    error_category: str | None = None
    retry_count: int = 0
    audit_id: str | None = None
    snapshot_id: str | None = None
```

`result` 为 `ToolResultMessage.model_dump(mode="json")`，其中保留 `success/summary/error` 兼容字段，前端现有展示逻辑无需改动。

可选新增事件：

- `tool_retry`：每次重试时发布，`data={step, tool_call_id, tool_name, attempt, error_category, delay_ms}`；
- `tool_snapshot`：仅 debug 模式发布，默认关闭，避免噪声。

新增事件类型需要在 `SSEEventType` 与前端 `types/index.ts` 联合类型中同步；现有 `useTask.ts` 的 `switch` 未覆盖未知事件时不会崩溃，但仍建议显式处理 `tool_retry`。

### 9.4 暂停/取消与事件顺序

- 暂停：Runtime 在 `checkpoint()` 处等待；Loop 在发布 `tool_result` 前也会 `wait_if_paused()`（新增），保证暂停期间不推送新事件。
- 恢复：原地恢复继续使用同一 `snapshot`，`seq` 连续；冷恢复重建快照，从最新 `seq` 继续。
- 取消：`ToolCancelledError` → Loop 现有 `except asyncio.CancelledError` → `_terminate(CANCELLED)`；不发布半截 `tool_result`。
- 重试事件按 attempt 逐次发布，不做批量聚合，保持与现有流式事件一致。

---

## 10. 实施步骤（分阶段、可独立验证）

| 阶段 | 内容 | 验收方式 |
| --- | --- | --- |
| 0. 基线 | 为现有 3 个工具补契约测试：入参 schema、确认、异常映射、`ToolResult` 兼容字段；记录当前 `test_e2e.py` 通过 | `python -m pytest tests/test_tools_baseline.py -q`；`python scripts/test_e2e.py` |
| 1. 定义与注册表 | `enums/definition/registry/snapshot/policy` + `LegacyToolAdapter` + `catalog`；仅构建 registry，不接入 loop | 单测：同名多版本、重复注册冲突、灰度分桶稳定、disable/kill 实时读取、快照过滤 |
| 2. Loop 接入（passthrough） | `AgentLoop` / `AgentRunner` 每轮构建快照，Runtime 仅做查找 + 入参校验 + 直接调用 handler；不改执行策略 | 现有 E2E 行为不变；日志中能确认 `snapshot_id/revision`；工具列表与旧版一致 |
| 3. 校验与输出 | 实现 validate 全部规则、结果 schema 校验、脱敏、审计落库、`tool_calls` 表 | 单测：权限/版本/kill/依赖/参数失败返回正确 status；审计字段完整；kill after snapshot 被拦截 |
| 4. 执行策略 | 超时、并发信号量、错误分类、重试表、幂等判定、暂停/取消 checkpoint | 单测使用 fake flaky handler 验证每类错误重试次数；非幂等工具 0 重试；暂停期间不发起新调用；取消终止 |
| 5. Handler 迁移 | 将 3 个工具改为 `handlers/*` + typed output + `ToolBusinessError`；删除旧 `_execute_tool` 依赖 | `test_e2e.py` 全链路通过；SMTP 未配置时返回 `AUTH` 而非崩溃；搜索超时按策略重试 |
| 6. 管理面与前端 | 工具列表/禁用/kill/版本/灰度接口；`config/tools.json` 热加载；SSE 字段与 `tool_retry`（可选） | 手工：任务运行中调用 kill，下一次调用返回 `tool_disabled` 且 handler 未执行；重启后配置状态符合预期 |
| 7. 清理 | 移除 `TOOL_REGISTRY/get_tool/BaseTool` 兼容导出；更新 README 与架构文档 | 全局搜索无旧入口引用；CI 边界测试通过 |

建议新增开发依赖（当前 `requirements.txt` 无 pytest）：`pytest`、`pytest-asyncio`，放在 `requirements-dev.txt`，不混入生产依赖。

---

## 11. 需要用户确认的开放问题

| # | 问题 | 建议默认值 | 影响 |
| --- | --- | --- | --- |
| 1 | 是否保留旧 `BaseTool` / `TOOL_REGISTRY` 兼容层，还是全量迁移？ | 全量迁移 3 个内置工具，仅保留 `LegacyToolAdapter` 一个版本的窗口 | 决定阶段 5-7 的工作量与外部插件兼容性 |
| 2 | 版本号格式与是否需要模型可见？ | semver；模型只看到 name，版本由快照服务端解析 | 影响 prompt 与审计展示 |
| 3 | 灰度分桶键用 `task_id`、`business_id` 还是租户/用户？ | `task_id + name`，同任务稳定；管理面可再用 `business_id` 灰度 | 影响灰度命中一致性 |
| 4 | kill switch 是否需要跨进程/重启持久化？ | 第一阶段内存即时生效；第二阶段加 `tool_states` 表或写入 `config/tools.json` | 影响运维可靠性与实现量 |
| 5 | 非幂等工具（邮件）是否允许任何自动重试？ | 默认 0 次；只有 handler 明确标记 `PRE_SIDE_EFFECT` 的连接失败允许 1 次 | 影响重复发送风险 |
| 6 | 审批接口是否新增 `tool_call_id`？旧前端是否同步修改？ | 增加可选字段，匹配逻辑兼容旧 `(step, tool_name)` | 影响并发/并行工具确认的准确性 |
| 7 | 权限来源：继续单 Token 全量授权，还是引入 RBAC/租户？ | 第一阶段默认全量授权，预留 `ActorContext` 扩展 | 影响权限失败的可测试性 |
| 8 | 快照粒度：每轮 LLM 调用一次，还是每任务一次？ | 每轮一次，保证模型看到的工具集与该轮执行一致 | 影响工具热更新与灰度生效速度 |
| 9 | 审计表是否必须落库，还是只写结构化日志？ | `tool_calls` 落库，日志作为兜底 | 影响存储量与排障能力 |
| 10 | `/runs`（AgentRunner）是否与任务链路同步接入 Runtime？ | 是，阶段 2 一起接入；确认策略默认拒绝危险工具 | 影响两套 loop 的一致性 |
| 11 | 是否需要 `execute_batch` 并行执行原生多 tool_calls？ | 阶段 4 后再做；默认串行，满足 `parallelizable` 且无审批/依赖时才并行 | 影响性能与确认交互复杂度 |
| 12 | 输出摘要长度与是否允许模型看到结构化 data？ | 摘要 2000 字符；模型看到脱敏后的 `data + summary` | 影响提示词 token 与信息完整性 |

---

## 附录 A：错误码建议（扩展 `ErrorCode` 16xx）

| 错误码 | 名称 | 用途 |
| --- | --- | --- |
| `1604` | `TOOL_PERMISSION_DENIED` | 权限不足 |
| `1605` | `TOOL_DISABLED` | kill switch / 硬禁用 |
| `1606` | `TOOL_VERSION_STALE` | 版本硬禁用/指纹变化/快照过期 |
| `1607` | `TOOL_DEPENDENCY_NOT_MET` | 依赖未满足 |
| `1608` | `TOOL_TIMEOUT` | 执行超时 |
| `1609` | `TOOL_OUTPUT_INVALID` | 输出 schema 校验失败 |
| `1610` | `TOOL_RATE_LIMITED` | 工具侧限流 |
| `1611` | `TOOL_CANCELLED` | 取消 |
| `1612` | `TOOL_SNAPSHOT_EXPIRED` | 快照过期 |

现有 `1600 TOOL_NOT_FOUND`、`1601 TOOL_EXECUTION_FAILED`、`1602 TOOL_ARGS_VALIDATION_FAILED`、`1603 TOOL_NEEDS_CONFIRMATION` 保留。

## 附录 B：验收清单

- [ ] 模型 prompt / 原生 tools 参数中不出现 handler、权限、审计策略。
- [ ] 同名多版本可注册；重复注册冲突；`set_active` 只影响下一轮。
- [ ] 快照构建后 kill 工具，下一次调用返回 `tool_disabled`，handler 未被执行。
- [ ] `disable_version` 对已构建快照立即生效；`set_active` 不影响当前轮。
- [ ] 灰度按 `task_id + name` 稳定命中；灰度版本被禁用后自动回退 stable。
- [ ] 参数校验失败返回字段级错误，不执行 handler。
- [ ] 依赖未成功时返回 `dependency_not_met`，不执行 handler。
- [ ] 非幂等工具超时/5xx 不自动重试，`possible_side_effect=True`。
- [ ] 只读工具超时按策略重试，`retry_count/retry_strategy` 可查。
- [ ] 暂停期间不发起新工具调用；恢复后快照可继续使用。
- [ ] 取消时终止循环，不产生半截 `tool_result`。
- [ ] `tool_calls` 表可按 `trace_id/task_id` 查到完整审计字段。
- [ ] 失败调用同时写入 `error_traces`，stage 可区分 validate/execute/output。
- [ ] 前端现有 `tool_result` 展示不受影响（`success/summary/error` 兼容）。
- [ ] CI 边界测试通过：loop/runner/prompt 不 import handlers。
