# 个人助理 Agent 工具平台二期：订单审批、MCP 与插件管理

> 目标：个人助理 Agent
> 版本特性：工具平台二期（订单工具、票据化审批、MCP 注册、插件上下架）
> 版本：v2.0.0
> 前置版本：v1.0.0（工具运行时，见 `docs/个人助理Agent_工具运行时版本治理与审批_v1.0.0.md`）
>
> 基于当前版本（已具备 Tool Runtime / ToolRegistry / Snapshot / 审计 / 重试 / kill switch）的增量设计方案。
> 目标：在不推翻现有分层的前提下，补齐订单类工具、用户审批唯一码、MCP 工具注册、插件上下架、角色校验与模型可识别的错误结构。

---

## 1. 目标与结论

### 1.1 本期要解决的问题

| 编号 | 需求 | 本期结论 |
| --- | --- | --- |
| 1 | 多个 mock 工具：生成订单、付款、退款、查询订单 | 新增 `create_order` / `pay_order` / `refund_order` / `query_order` |
| 2 | 用户审批过程，抽象对应对象 | 新增 `ApprovalTicket` + `ApprovalStore`，替代 `PendingConfirmation` |
| 3 | MCP 调用（mock），MCP 作为工具注册 | 新增 `McpClient` / `MockMcpClient` / `McpToolProvider`，启动时转为 `ToolDefinition` 注册 |
| 4 | 启动时注册工具，每个工具有权限与治理字段 | 补充 `origin` / `plugin_id` / `allowed_roles`；治理覆盖必须在注册前合并 |
| 5 | 每次请求构建 `ToolSnapshot`，调用模型前转换模型视图 | 复用 `ToolSnapshot.to_tool_defs()` 与现有 `ToolDef`，不新增平行视图 |
| 6 | 模型返回 toolCall 后转统一调用对象 | 复用 `ToolCallRequest`，由 Loop / Runner 各自适配 |
| 7 | 执行前判断权限是否变化、工具是否已下架 | 已有 `check_live`；补充实时身份刷新、角色校验与显式下架语义 |
| 8 | 工具加版本 | 已完成（`ToolSpec.version` + `VersionRecord` + 灰度 + kill） |
| 9 | 每次请求有 context，包含工具运行能力 | 扩展 `ToolSession`，由 `AgentLoop` / `AgentRunner` 持有 `ToolRuntime`，不新增平行上下文 |
| 10 | 审批唯一码：绑定工具、版本、用户和参数，确认后继续执行 | 票据化审批 + 随机 `approval_token`，见第 6 章 |
| 11 | 执行前中后校验：参数、权限、角色、超时、脱敏、审计 | 保留三段式，补充审批后复核与取消唤醒 |
| 12 | 按不同错误决定重试、日志或终止 | 复用 `retry.py` 的副作用决策；增加模型动作约束 |
| 13 | 可解决的错误给模型，不可解决的错误记日志并终止 | 新增 `ToolErrorSchema`；`resolvable_by_model` 默认关闭 |
| 14 | plug 功能管理（下架、注册） | 新增 `PluginManager` + 管理员 HTTP API，批量操作单次提交 |

### 1.2 设计边界与已确认选择

- **订单工具集**：`create_order`、`pay_order`、`refund_order`、`query_order`。
- **审批等待方式**：同任务内挂起等待，票据只保存在进程内存；任务必须可真正取消，重启后不得停留在无出口的等待状态。
- **部署边界**：本期票据与动态插件均为单进程能力，只支持单 worker；不宣称支持多实例共享或重启后确认原票据。
- **管理面解释变更**：需求 14 的“plug 功能管理工具”解释为管理员 HTTP 管理面，而不是暴露给模型的工具。该取舍实施前需产品显式确认；未确认前不得把它当作已验收需求。
- **协议变更**：`/tasks/{task_id}/confirm` 与前端在同一版本一次性切换为 token 必填，不保留按 `step + tool_name` 确认的双轨路径。

---

## 2. 现状梳理

### 2.1 已具备能力（直接复用）

| 能力 | 代码位置 | 说明 |
| --- | --- | --- |
| 工具定义三段式 | `backend/app/core/tools/definition.py` | `ToolSpec` + `ToolGovernance` + handler 绑定；含权限、风险、副作用、确认、超时、重试、审计、租户 |
| 注册表与版本 | `backend/app/core/tools/registry.py` | 多版本、stable、灰度、禁用、kill switch、copy-on-write 不可变状态；同指纹注册为 no-op |
| 启动注册 | `backend/app/core/tools/catalog.py` | 当前已在注册前合并 `config/tools.json`，该顺序必须保持 |
| 请求快照 | `backend/app/core/tools/runtime.py` | `build_snapshot()` 冻结本轮工具元数据 |
| 模型可见工具 | `backend/app/core/tools/snapshot.py` | `to_tool_defs()` 仅输出 name / description / parameters |
| 三段式执行 | `backend/app/core/tools/runtime.py` | 校验 → 审批 → 执行（超时/并发/重试）→ 输出校验/脱敏/审计 |
| 实时状态拦截 | `backend/app/core/tools/validation.py` | `check_live()`：kill、版本禁用、版本 kill、指纹变化 |
| 错误分类与重试 | `backend/app/core/tools/retry.py` | 只负责按 category + effect + phase + 幂等安全性决策，不负责业务日志路由或最终异常处理 |
| 审计 | `backend/app/core/tools/audit.py` | `tool_calls` 落库 + structlog + 失败写 `error_traces` |
| 审批抽象 | `backend/app/core/tools/session.py` | `ApprovalGate` / `ToolApprovalRequest` / `ApprovalDecision` |
| Runner 审批 | `backend/app/core/runner.py` | 程序化 `confirm_handler` 使用回调审批；未提供回调时 `AutoDenyApprovalGate` 拒绝 |
| 治理管理面 | `backend/app/api/routes/admin.py` | kill / revive / active / canary / disable / enable |

### 2.2 本期真正的缺口

1. 缺少订单类工具与对应权限位，订单写操作还缺少服务端业务去重规则。
2. 审批只有挂起句柄：`PendingConfirmation` 按 `step + tool_name` 匹配，没有唯一码、TTL、单次消费，也没有绑定参数哈希、工具版本和用户。
3. 没有 MCP：所有工具都硬编码在 `catalog.py`。
4. 没有按插件批量原子提交的管理层。
5. `users.role` 未进入 `ActorContext` 和工具治理；HTTP 单 token 又总映射为默认管理员，无法形成真实身份边界。
6. `ToolSession` 缺少角色与实时身份刷新能力，快照后降权无法可靠拦截。
7. 错误缺少“模型可解决性”与安全的模型动作约束。
8. `task_events` 持久化完整事件，若直接加入 token 会形成敏感凭据落库。
9. 任务缺少真正取消接口，审批等待、过期清扫和进程重启没有完整状态出口。

---

## 3. 总体架构

在现有分层上扩展，不增加另一套执行入口：

```text
API / AgentLoop / AgentRunner
        │
        │  ToolSession（身份、控制、审批、观察器、依赖状态）
        ▼
ToolRuntime（唯一执行入口）
   ├─ 校验：快照 / 实时状态 / 最新权限与角色 / 租户 / 依赖 / 参数
   ├─ 审批：ApprovalStore（签发、归属校验、等待、确认、单次消费）
   ├─ 执行：超时 / 并发 / 暂停与取消检查 / 分类重试
   └─ 收口：输出校验 / 脱敏 / 审计 / ToolErrorSchema
        │
        ▼
ToolRegistry（版本 / 灰度 / 上下架，批量单次 copy-on-write commit）
   ├─ BuiltinPlugin（订单、账单、邮件、搜索、时间…）
   ├─ McpToolProvider（mock MCP server → ToolDefinition）
   └─ PluginManager（安装 / 卸载 / 下架 / 上架）
```

依赖方向：

```text
api → core.loop / core.runner → core.tools.runtime
                              → session / snapshot / validation
                              → registry → definition / enums
                              → approval / error_schema / plugin / mcp
```

约束保持不变：**模型只能拿到 `ToolSnapshot.to_tool_defs()` 生成的 `ToolDef`，handler 只能由 `ToolRuntime` 解析调用。**

---

## 4. 关键对象设计

### 4.1 ToolDefinition 扩展

```python
class ToolOrigin(str, Enum):
    BUILTIN = "builtin"
    MCP = "mcp"
    PLUGIN = "plugin"


@dataclass(frozen=True)
class ToolSpec:
    # 现有字段保持不变
    name: str
    version: str
    display_name: str
    description: str
    input_model: type[BaseModel]
    input_schema: dict[str, Any]
    output_model: type[BaseModel] | None = None
    output_schema: dict[str, Any] | None = None
    error_specs: tuple[ToolErrorSpec, ...] = ()
    examples: tuple[dict[str, Any], ...] = ()
    # 新增：所有来源都必须有稳定归属
    origin: ToolOrigin = ToolOrigin.BUILTIN
    plugin_id: str = "builtin.core"


@dataclass(frozen=True)
class ToolGovernance:
    permissions: frozenset[ToolPermission]
    risk_level: RiskLevel
    requires_confirmation: bool | None = None
    # 新增：None 表示不限角色，空集合表示任何角色都不可用
    allowed_roles: frozenset[str] | None = None
    # 其余字段保持不变
    ...
```

- 内置工具按模块使用 `builtin.orders`、`builtin.shopping` 等稳定 `plugin_id`，`origin=BUILTIN`。
- MCP 工具使用 `plugin_id=server_id`、`origin=MCP`。
- 外部 `ToolPlugin` 使用自身 `plugin_id`、`origin=PLUGIN`。
- `ToolErrorSpec` 同步扩展 `model_action` 与安全提示语；不允许只改错误 Schema 而遗漏工具声明。
- `fingerprint` 继续只覆盖 `spec + handler_id`。`allowed_roles` 等治理字段不进入执行指纹，因此必须在注册前完成覆盖，不能依赖同指纹注册更新治理。

### 4.2 模型视图与调用对象

直接复用现有类型：

- `ToolSnapshot.to_tool_defs()` 是唯一模型视图转换入口；如供应商要求 `strict`，直接给 `app.llm.schemas.ToolDef` 增加可选字段。
- `ToolCallRequest` 继续作为 `ToolRuntime.execute()` 的入参，不新增同名或别名类型。
- `AgentLoop` 将 JSON decision 转为 `ToolCallRequest`；`AgentRunner` 将原生 `tool_calls` 转为同一类型。适配函数放在各自模块，不进入 registry/runtime。
- 工具名不在快照时返回安全的 `NOT_FOUND` / `TOOL_NOT_IN_SNAPSHOT` 结果，不暴露被权限过滤工具是否真实存在。

### 4.3 ToolSession 扩展

```python
ActorRefresher = Callable[[str], Awaitable[ActorContext]]


@dataclass(frozen=True)
class ActorContext:
    actor_id: str | None
    tenant_id: str | None
    granted_permissions: frozenset[ToolPermission] = frozenset()
    roles: frozenset[str] = frozenset()


@dataclass
class ToolSession:
    # 现有字段保持不变
    session_id: str
    task_id: str
    trace_id: str
    actor: ActorContext
    control: ToolControl
    approval_gate: ApprovalGate
    observer: ToolObserver | None = None
    dependencies: ToolDependencyState = field(default_factory=ToolDependencyState)
    idempotency_key: str | None = None
    # 新增：从数据库重新读取用户状态、权限和角色
    refresh_actor: ActorRefresher | None = None

    async def refresh_identity(self) -> ActorContext:
        if self.refresh_actor is not None and self.actor.actor_id is not None:
            self.actor = await self.refresh_actor(self.actor.actor_id)
        return self.actor
```

- Loop / Runner 在每次 `build_snapshot()` 前 `await session.refresh_identity()`。
- `ToolRuntime.execute()` 开始时、审批唤醒后、副作用前再次刷新身份。
- `PermissionService.resolve()` 必须读取角色；外部调用必须显式传 `actor_id`，不再把空身份静默替换为默认管理员。
- `HandlerContext` 增加 `request_id`，便于 handler 日志串联。

### 4.4 HTTP 身份、任务归属与角色边界

1. 新增 `AUTH_IDENTITIES_JSON`：Bearer token 到 `user_id` 的服务端映射。token 只来自环境/密钥配置，不写数据库、日志或事件。
2. `AuthMiddleware` 校验 token 后将对应 `user_id` 写入 `request.state.actor_id`；未命中返回 401，**不再回退到 `default_user_id`**。启动时校验映射格式，空映射拒绝启动。
3. 用户是否 active、权限和角色仍以 `users` / `user_permissions` 为准；token 映射只负责认证，不直接授予权限。
4. 任务创建时把 `actor_id` 写入 `TaskRuntime` 和 `tasks` 表。start / stop / resume / cancel / confirm / events 等任务接口均校验任务所有者，冷恢复使用持久化所有者，不使用默认用户。
5. 所有 `/admin/*` 路由增加 `require_admin` 依赖：根据当前 `actor_id` 实时读取用户，要求 `status=active` 且 `role=admin`。不能只在启动时缓存角色。
6. 审批必须同时匹配 token、`task_id` 和票据原 `actor_id`；管理员身份不能代替其他用户确认。

### 4.5 快照可见性与执行期权限

- 构建快照时继续过滤权限或角色不满足的工具。因此普通用户一开始看不到 `refund_order`，这是有意设计，而不是执行期错误。
- 系统提示词明确：“只能使用当前列出的工具；未列出表示当前不可用，不得猜测工具名。若用户目标需要不可用能力，应说明需要权限或请求管理员协助。”
- `PERMISSION` / `TOOL_ROLE_DENIED` 执行错误只覆盖“快照生成后被降权”或“审批后被降权”等竞态，不承担解释所有不可见工具的职责。
- `ToolRef` 增加 `required_permissions` 与 `allowed_roles`，审计同时记录快照值和执行时实时值。

---

## 5. 订单工具（需求 1）

### 5.1 工具清单

| 工具 | 入参 | 权限 | 风险 | 副作用 | 需确认 | 超时 | 重试 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `create_order` | `product_id`, `product_name`, `quantity`, `unit_price`, `currency`, `client_order_no` | `order.create` | MEDIUM | `IDEMPOTENT_WRITE` | 否 | 10s | 仅幂等安全时重试 |
| `pay_order` | `order_id`, `amount?`, `method`(balance/card), `client_payment_no` | `order.pay` | HIGH | `NON_IDEMPOTENT_WRITE` | **是** | 15s | 不自动重试 |
| `refund_order` | `order_id`, `amount?`, `reason` | `order.refund` | CRITICAL | `NON_IDEMPOTENT_WRITE` | **是** | 15s | 不自动重试 |
| `query_order` | `order_id?`, `status?`, `limit=20` | `order.query` | LOW | `READ_ONLY` | 否 | 10s | 网络类可重试 |

约束：

- `refund_order` 配置 `allowed_roles={"admin"}`。
- `client_order_no` 与 `client_payment_no` 均必填，只作为业务去重号；服务端以 `actor_id` 隔离作用域，不能信任模型自行保证全局唯一。
- `query_order` 用 `model_validator` 要求 `order_id`、`status` 至少一个非空；`limit` 范围 1–100，默认 20，禁止 `{}` 全量扫描。
- mock 订单记录保存 `owner_actor_id`，查询和写操作默认限定当前用户，不能仅凭知道 `order_id` 跨用户读取或操作。

### 5.2 Mock 实现与幂等

新增 `backend/app/core/tools/handlers/orders.py`：

```python
_orders: dict[str, dict] = {}
_create_requests: dict[tuple[str, str], dict] = {}
_payment_requests: dict[tuple[str, str], dict] = {}
_lock = asyncio.Lock()
```

状态流转（本期没有取消订单工具，不定义无入口的转换）：

```text
created ──pay──→ paid ──refund──→ refunded
```

业务与去重规则：

| 场景 | 结果 |
| --- | --- |
| 订单不存在或不属于当前用户 | `NOT_FOUND`，不泄露其他用户订单信息 |
| 支付金额与订单金额不一致 | `BUSINESS`，模型可修正参数 |
| 同一 `(actor_id, client_order_no)`、规范化参数哈希相同 | 返回首次下单结果，不重复建单 |
| 同一 `(actor_id, client_order_no)`、参数哈希不同 | `BUSINESS / IDEMPOTENCY_CONFLICT`，不得返回其他参数的历史结果 |
| 同一 `(actor_id, client_payment_no)`、参数哈希相同 | 返回首次支付结果 |
| 同一支付去重号但参数不同 | `BUSINESS / IDEMPOTENCY_CONFLICT` |
| 使用不同支付去重号支付已支付订单 | `BUSINESS`：“订单已支付” |
| 退款金额超过已付金额或对非 paid 订单退款 | `BUSINESS` |

- 查重、参数哈希比较、写入结果必须在同一个 `_lock` 临界区内完成，避免并发重复建单/支付。
- Runtime 自动生成的 `idempotency_key` 只用于一次执行及其内部重试关联，不能替代上述业务去重。
- 测试故障注入 `_FAULT_INJECT = {"timeout": False, "network": False}` 仅由测试设置，不进入模型可见 input schema。

### 5.3 注册与权限种子

- `catalog.py` 增加四个定义，归属 `builtin.orders`。
- `ToolPermission` 增加 `ORDER_CREATE` / `ORDER_PAY` / `ORDER_REFUND` / `ORDER_QUERY`。
- 默认管理员种子增加 `order.*`；访客仍只有显式授予的权限。
- `_seed_default_users()` 对每条权限使用 `INSERT OR IGNORE`，因此新增权限会补入已有默认用户；不得误写为“旧用户无法获得新权限”。migration 负责列变更，seed 负责权限补齐，二者分别验收。
- `config/tools.json` 可覆盖风险、确认、超时、重试和 `allowed_roles`，但都在注册前生效。

---

## 6. 审批票据与唯一码（需求 2 / 10）

### 6.1 对象与接口

新增 `backend/app/core/tools/approval.py`：

```python
class ApprovalTicketStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    EXPIRED = "expired"
    CONSUMED = "consumed"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class ApprovalTicket:
    token: str
    task_id: str
    trace_id: str
    snapshot_id: str
    tool_call_id: str
    tool_name: str
    tool_version: str
    fingerprint: str
    arguments: dict[str, Any]
    args_hash: str
    actor_id: str
    roles: frozenset[str]
    risk_level: RiskLevel
    round: int
    created_at: datetime
    expires_at: datetime


@dataclass(frozen=True)
class ApprovalResolution:
    task_id: str
    tool_call_id: str
    tool_name: str
    tool_version: str
    status: ApprovalTicketStatus
    decided_by: str | None
    decided_at: datetime | None
    comment: str | None


class ApprovalStore:
    def issue(self, request: ToolApprovalRequest, *, ttl_seconds: float) -> ApprovalTicket: ...
    async def wait(self, token: str) -> ApprovalResolution: ...
    def resolve(self, token: str, *, task_id: str, actor_id: str,
                approved: bool, comment: str | None) -> ApprovalResolution: ...
    def consume(self, token: str, *, task_id: str,
                tool_call_id: str) -> ApprovalTicket: ...
    def revoke_task(self, task_id: str, *, reason: str) -> int: ...
    def sweep_expired(self, now: datetime) -> int: ...
```

`ToolApprovalRequest` 显式补充签发票据所需的 `trace_id`、`fingerprint`、`args_hash`、`actor_id`、`roles`、`snapshot_expires_at`。不得依靠闭包隐式获取 task 或 actor。

内部结构为 `dict[token, _TicketRecord]`；record 持有票据、`asyncio.Event`、`status`、`decided_by`、`comment`、`decided_at`。`ApprovalResolution` 是确认接口和等待方使用的安全返回对象，不包含 token，并能提供 `status/decided_at`。

**原子性约束**：`issue / resolve / consume / revoke_task / sweep_expired` 均为无 `await` 的同步状态迁移，在单个 event loop 内完成“检查当前状态 + 修改 + 唤醒”。只有 `wait()` 挂起；不得在状态检查与修改之间引入异步锁等待。

### 6.2 唯一码、TTL 与敏感信息

```python
token = "apr_" + secrets.token_urlsafe(32)
canonical_arguments = validated_input.model_dump(mode="json")
args_hash = sha256(stable_json(canonical_arguments)).hexdigest()
approval_token_hash = sha256(token.encode()).hexdigest()
expires_at = min(
    created_at + timedelta(seconds=configured_ttl),
    request.snapshot_expires_at,
)
```

- token 使用密码学随机数，不引入额外签名 secret、轮换或多进程一致性问题；随机碰撞时重新生成。
- 默认 TTL 300 秒且必须大于 0；若快照剩余有效期不足，按更短值截止。快照已过期时不得签发票据。
- token 明文只允许出现在服务端内存票据、当前进程内 SSE 数据、前端内存和确认请求中；数据库与审计只保存 `approval_token_hash`，确认响应和日志不记录 token 或其 hash。
- `args_preview` 必须先走 `redact_value()` 和长度限制，再进入事件；服务端执行始终使用票据内的权威 `arguments`，前端不能修改。
- `tool_confirmation_request` 发布时构造两份数据：内存/SSE 数据含 token；持久化数据删除 token、加入 hash。`EventBuffer.publish()` 必须对这两份数据分别处理，不能只清理日志而仍将原对象写入 `task_events`。
- 进程重启后持久化事件只显示“曾有审批请求”，不能用于确认；前端在 token 缺失时禁用确认按钮。

### 6.3 确认与执行校验链

确认分为“决策受理”和“执行准入”两道门，不能把确认成功等同于工具已成功执行。

**`ApprovalStore.resolve()` 原子校验：**

1. token 存在且状态为 `PENDING`；
2. 路径 `task_id`、当前 `actor_id` 与票据完全一致；
3. 未过期；
4. 通过则转为 `APPROVED` 或 `DENIED`，记录决定人/时间/备注并唤醒等待方；
5. 已确认、已拒绝、已消费、已过期或已取消的请求返回对应冲突错误，重复确认不得再次生效。

**Runtime 被唤醒后的执行准入：**

1. 重新读取票据，确认任务未取消；
2. 检查快照属于本任务、未过期，调用 ID、版本、指纹和 `args_hash` 均一致；票据保存的是首次 Pydantic 校验后的规范化参数，唤醒后再次校验该参数，handler 只能使用票据中的权威参数；
3. `refresh_identity()` 后重新校验权限、角色、用户 active 状态和租户；
4. `check_live()` 检查工具未卸载/下架、版本未禁用、未 kill、指纹未变化；
5. 在真正进入有副作用的 handler 前再次执行实时校验，然后 `consume(token, task_id, tool_call_id)` 校验仍未过期，并原子地从 `APPROVED` 转为 `CONSUMED`；消费失败不得执行；
6. 任一复核失败，记录工具失败与审计，不调用 handler。

确认接口返回 `APPROVED` 仅表示审批决策已受理；若随后发现快照过期、下架或降权，工具结果以执行复核错误为准。

### 6.4 Runtime 接入

`AgentLoop` 使用 `TicketApprovalGate`，`ApprovalGate` 协议保持为 Runtime 的唯一审批入口：

```text
校验通过 → needs_approval
  → refresh_identity() 后构造完整 ToolApprovalRequest
  → store.issue(request, ttl) 得到 token
  → 发布 tool_confirmation_request（SSE 含 token，DB 仅含 hash 与脱敏预览）
  → RUNNING → WAITING_APPROVAL，并持久化任务状态
  → await store.wait(token)
  → 用户 POST /tasks/{task_id}/confirm 带 token → store.resolve()
  → 唤醒后先把 WAITING_APPROVAL → RUNNING（取消/不可恢复失败除外）并持久化
  → 复核快照 / 实时状态 / 最新权限角色
  → consume → 执行 handler → 发布 tool_result
  → 审计写 approval_token_hash / approved_by / decided_at / comment
```

异常路径：

| 情况 | 结果 |
| --- | --- |
| 用户拒绝 | `APPROVAL_DENIED`，`model_action=STOP`，不自动重试、不再次追问同一审批 |
| 等待超时或定期清扫发现过期 | `APPROVAL_TIMEOUT`，票据置 `EXPIRED` 并唤醒 |
| token 非法 | `APPROVAL_TOKEN_INVALID`，不执行工具 |
| token 已消费或重复确认 | `APPROVAL_TOKEN_CONSUMED` / 状态冲突 |
| 任务取消 | `revoke_task()` 置 `CANCELLED` 并立即唤醒，Runtime 抛 `ToolCancelledError` |
| 复核发现降权/下架/快照过期 | 对应权限、版本或快照错误，不执行 handler |

### 6.5 任务状态、取消与重启闭环

在 `VALID_STATUS_TRANSITIONS` 中显式增加：

```text
pending → running → completed / failed / cancelled
running ↔ paused
running → waiting_approval → running
running / paused / waiting_approval → cancelled
waiting_approval → failed
```

- 新增真正的 `POST /tasks/{task_id}/cancel`：设置 `cancel_event`，同时唤醒 pause 等待与 `approval_store.revoke_task(task_id)` 的审批等待，再让 Loop 在安全检查点退出并持久化 `CANCELLED`。现有 `stop` 仍是暂停，不再兼任取消。
- `WAITING_APPROVAL` 期间 `stop` 暂停请求返回 409，提示使用 cancel 或先完成审批；不定义含糊的 `WAITING_APPROVAL → PAUSED`。
- 同进程 `resume` 一个仍在等待的任务返回 409；不能重复启动 Loop。
- `Container.startup()` 启动一个定期清扫任务调用 `sweep_expired()`，将已到期的 `PENDING/APPROVED` 未消费票据置为 `EXPIRED` 并唤醒；`Container.shutdown()` 取消清扫并 revoke 所有未消费票据。等待自身也有 TTL，清扫不是唯一超时机制。
- 进程重启时，启动恢复流程先把数据库中仍为 `WAITING_APPROVAL` 的任务标记为 `FAILED`（原因 `approval_lost_on_restart`），再开放查询/恢复。旧 token 无效；用户走现有冷恢复，重做中断步骤并获取新票据，数据库不存在永久卡死状态。
- 取消与确认竞态由同步状态迁移决定：只有第一个合法状态迁移成功；已 `CONSUMED` 后不能撤销已开始的副作用，只能继续协作式取消后续步骤。

### 6.6 AgentRunner 边界

- `AgentRunner` 复用扩展后的 `ToolSession`、`ToolCallRequest`、身份刷新和错误 Schema，但不使用 `TicketApprovalGate`，不签发票据，也不进入 `WAITING_APPROVAL`。
- 程序化调用提供 `confirm_handler` 时继续使用 `_CallbackApprovalGate`，回调可真实批准或拒绝；新增审批请求字段一并传给回调。
- HTTP `/runs` 未提供确认通道时继续 `AutoDenyApprovalGate`，需要审批的工具明确拒绝。本期不新增无人能确认的 `/runs` token 流程。

---

## 7. 执行校验（需求 11）

| 阶段 | 校验项 | 现有落点 | 本期补充 |
| --- | --- | --- | --- |
| 快照前 | 最新用户状态、权限、角色 | `PermissionService` | `session.refresh_identity()` |
| 执行前 | 快照属于本任务、未过期 | `validation.check` | 票据到期不得超过快照到期 |
| 执行前 | 工具在快照内 | `validation.check` | 不泄露被过滤工具是否存在 |
| 执行前 | kill / 版本禁用 / 版本 kill / 指纹变化 | `check_live` | 工具整个卸载或下架返回 `TOOL_OFFLINE` |
| 执行前 | 权限与角色 | `check` + `_select_ref` | 执行时重新解析，不只使用快照身份 |
| 执行前 | 租户 | `_select_ref` | 刷新身份后复核 |
| 执行前 | 依赖工具已完成 | `check` + `ToolDependencyState` | — |
| 执行前 | 入参 Pydantic 校验 | `check` | 订单查询至少一个过滤条件 |
| 审批后 | 快照、参数哈希、权限、角色、版本、下架 | Runtime + `check_live` | 复核通过后原子 consume |
| 执行中 | 单次超时 / 总超时 | `_run_with_policy` | — |
| 执行中 | 并发信号量 | `_semaphore_for` + 全局信号量 | — |
| 执行中 | 暂停/取消检查 | `session.control.checkpoint()` | 审批等待也必须能被取消唤醒 |
| 执行中 | 异常分类与重试 | `retry.py` | 同时遵守 effect 与副作用不确定性 |
| 执行后 | 输出 schema 校验 | `_validate_output` | — |
| 执行后 | 脱敏 | `redact_value` / `redact_text` | 审批 `args_preview` 同样脱敏 |
| 执行后 | 审计 | `ToolAuditor` | 增加审批 hash 与决定信息，不记 token |
| 执行后 | 副作用不确定性标记 | `possible_side_effect` | 非幂等写超时禁止模型盲目重试 |

`TOOL_OFFLINE` 只是错误码：`category=VERSION_STALE`、`status=TOOL_DISABLED`，不新增同名 `ToolErrorCategory`。

---

## 8. 错误处理与 ToolErrorSchema（需求 12 / 13）

### 8.1 错误路由

```text
handler 异常
  → classify_exception() 得到 category / phase / retryable
  → decide_retry() 按 effect / phase / possible_side_effect / 幂等安全性判断
       ├─ 可安全重试且未耗尽 → 退避重试（tool_retry 日志 + on_retry 事件）
       └─ 不可重试 / 耗尽
            ├─ resolvable_by_model=True → 安全 ToolErrorSchema 回灌模型
            └─ False → 日志 + error_traces + 通用失败文案，终止当前运行
取消 → ToolCancelledError 直接向上抛，不包装成工具失败
```

### 8.2 错误分类与副作用矩阵

| 分类 / 错误码 | 自动重试 | 模型可解决 | 模型动作 | 日志 |
| --- | --- | --- | --- | --- |
| `VALIDATION` | 否 | 是 | `FIX_ARGUMENTS` | INFO |
| `PERMISSION` / `TOOL_ROLE_DENIED`（快照后降权） | 否 | 是 | `ASK_USER` | INFO |
| `NOT_FOUND` | 否 | 是 | `USE_ALTERNATIVE` | INFO |
| `TOOL_OFFLINE` / `VERSION_STALE` / `SNAPSHOT_EXPIRED` | 否 | 是 | `USE_ALTERNATIVE`，重新规划 | INFO |
| `DEPENDENCY` | 否 | 是 | `USE_ALTERNATIVE`，先完成依赖 | INFO |
| `APPROVAL` + 用户拒绝 | 否 | 是 | `STOP` | INFO |
| `APPROVAL` + 等待超时 | 否 | 是 | `ASK_USER`，由用户决定是否重新发起 | INFO |
| `TIMEOUT` / `NETWORK` / `RATE_LIMIT` / `UPSTREAM`，只读 | 按策略 | 耗尽后是 | `RETRY_SAME` 或 `USE_ALTERNATIVE` | WARN |
| 同上，幂等写且业务去重已保证、参数哈希相同 | 按策略 | 耗尽后是 | `RETRY_SAME` 或 `ASK_USER` | WARN |
| 同上，`NON_IDEMPOTENT_WRITE`，或 `possible_side_effect=True` 且未证明幂等重放安全 | **否** | 是 | `ASK_USER` 查询状态，或 `STOP`；**禁止 `RETRY_SAME`** | WARN |
| `AUTH` | 否 | 否 | `NONE` | ERROR |
| `INTERNAL` | 否 | 否 | `NONE`，通用文案 | ERROR + stack |
| `OUTPUT_SCHEMA` | 否 | 否 | `NONE` | ERROR |
| `CANCELLED` | 否 | — | 向上抛 | INFO |

任何映射都不得覆盖 `retry.py` 的副作用安全判断。尤其是支付、退款超时：可能已经产生副作用，不能仅因 category 是 `TIMEOUT` 就建议原样重试。

### 8.3 ToolErrorSchema

新增 `backend/app/core/tools/error_schema.py`：

```python
class ModelAction(str, Enum):
    FIX_ARGUMENTS = "fix_arguments"
    RETRY_SAME = "retry_same"
    ASK_USER = "ask_user"
    USE_ALTERNATIVE = "use_alternative"
    STOP = "stop"
    NONE = "none"


class ToolErrorSchema(BaseModel):
    code: str
    category: ToolErrorCategory
    phase: ErrorPhase
    retryable: bool
    model_action: ModelAction
    model_message: str
    hint: str = ""
    fields: dict[str, Any] = Field(default_factory=dict)
    resolvable_by_model: bool = False
    retry_after: float | None = None
    possible_side_effect: bool = False
```

- `ToolResultMessage` 增加 `error_schema`；`to_llm_content()` 只序列化安全字段，永不输出内部 `message`、堆栈或 token。
- `resolvable_by_model=False` 是默认值，只有显式声明且包含安全 `model_message` 的错误才能回灌模型。
- `ToolErrorSpec` 增加 `model_action`；通用映射也必须满足 8.2 的副作用约束。

### 8.4 模型动作执行语义与循环终止

`ModelAction` 是工具结果的路由建议，不新增第四种 LLM `ActionType`：

| 工具错误动作 | Loop 行为 |
| --- | --- |
| `FIX_ARGUMENTS` / `USE_ALTERNATIVE` | 将安全 Schema 回灌模型；下一次合法决策使用现有 `TOOL_CALL`，也可选择 `FINAL_ANSWER` 放弃 |
| `RETRY_SAME` | 只回灌建议，不由 Loop 隐式调用；模型再次发起时必须生成新的 `tool_call_id`，Runtime 与 handler 仍按业务去重号防重 |
| `ASK_USER` | 映射为现有 `NEED_CLARIFICATION`，向用户提出安全问题；用户答复前不调用同一工具 |
| `STOP` | 映射为现有 `FINAL_ANSWER`，说明当前目标无法继续；不得再次请求同一审批或原样重试 |
| `NONE` / 不可模型解决 | 不回灌内部细节，任务以 `FAILED` 或安全通用响应结束 |

连续失败计数必须确定：所有回灌模型的 `FIX_ARGUMENTS / USE_ALTERNATIVE / RETRY_SAME` 都计入连续工具失败，成功工具调用后清零，达到配置上限即 `STOP`；`ASK_USER` 挂起当前规划，`STOP/NONE` 直接终止当前规划。不得再把某类可恢复错误永久排除在计数外，避免无限循环。若错误带 `possible_side_effect=True` 且未证明相同业务去重键可安全重放，只能查询状态或终止，不能自动重放原写操作。

---

## 9. MCP 工具注册（需求 3）

### 9.1 目录与配置

```text
backend/app/core/tools/mcp/
├── __init__.py
├── client.py      # McpClient 协议 + MockMcpClient
└── provider.py    # MCP → ToolDefinition 注册器
```

`backend/config/mcp_servers.json`：

```json
{
  "servers": [
    {
      "id": "mock_crm",
      "version": "1.0.0",
      "transport": "mock",
      "tools": [
        {
          "name": "query_inventory",
          "description": "查询商品库存（MCP mock）",
          "input_schema": {
            "type": "object",
            "properties": {
              "sku": {"type": "string", "description": "商品 SKU"}
            },
            "required": ["sku"]
          },
          "read_only": true,
          "risk_level": "low"
        }
      ]
    }
  ]
}
```

### 9.2 注册规则与冲突边界

- 工具名为 `mcp_{server_id}_{tool_name}`，归一化为小写下划线，长度不超过 64；超长拒绝，不静默截断。
- `origin=MCP`，`plugin_id=server_id`，版本取 `server.version`。
- `readOnlyHint=true` 映射 `READ_ONLY`；否则保守映射 `NON_IDEMPOTENT_WRITE` 并要求确认。
- handler 闭包只调用 `client.call_tool(remote_name, args)`；超时、连接失败、服务端错误分别分类为 `TIMEOUT / NETWORK / UPSTREAM`，重试仍受副作用矩阵约束。
- 输入模型优先从 JSON Schema 基础类型生成；失败则拒绝该 server 并记录配置错误，不把未校验的任意 dict 直接传给远端。
- 所有注册使用 `replace_existing=False`。同一 server 的相同工具版本若 schema、handler 或其他 spec 指纹漂移，必须提升 `server.version`；不得用运行期覆盖制造执行身份歧义。
- 单个 server 先完整构造、校验并应用治理，再用一次 `registry.register_batch()` 提交。该 server 内任何重名、版本冲突、schema 漂移或注册异常都回滚本批次，按 server 捕获并记 WARN 后跳过，不影响其他 server。
- 内置工具冲突属于应用自身配置错误，启动失败；MCP server 失败不得扩大为整个应用失败。捕获范围必须限定在单个 provider/server，不能用全启动流程的裸异常吞噬。

---

## 10. 插件管理（需求 14）

### 10.1 对象与批量注册表 API

新增 `backend/app/core/tools/plugin.py`：

```python
class ToolPlugin(Protocol):
    plugin_id: str
    version: str

    def definitions(self) -> list[ToolDefinition]: ...
    async def startup(self) -> None: ...
    async def shutdown(self) -> None: ...


class PluginManager:
    async def install(self, plugin: ToolPlugin, *, activate: bool = True) -> int: ...
    async def uninstall(self, plugin_id: str) -> int: ...
    def offline(self, plugin_id: str, *, tool_name: str | None = None,
                reason: str = "") -> int: ...
    def online(self, plugin_id: str, *, tool_name: str | None = None) -> int: ...
    def list(self) -> list[dict]: ...
```

`ToolRegistry` 提供面向一次 copy-on-write 提交的批量原语：

- `register_batch(definitions, activate=...)`：先验证整批，再替换一次 state，revision 只增加 1；
- `unregister_plugin(plugin_id)`：整插件版本一次移除；
- `disable_scope(plugin_id, tool_name=None)`：范围内**所有版本**一次禁用，防止旧快照落到仍启用的历史版本；
- `enable_latest_scope(plugin_id, tool_name=None)`：每个工具只启用并激活最新注册版本，其他版本保持禁用，一次提交。

`PluginManager` 串行化管理操作。install 在 `startup()` 成功后才提交；提交失败调用 `shutdown()` 补偿。uninstall 先原子移除注册项，再执行资源清理；清理失败只记错误，不恢复半套装态。任何并发快照只能看到操作前或操作后的完整 revision，不能看到“半个插件”。

### 10.2 状态语义

| 操作 | 实现与结果 |
| --- | --- |
| 注册插件 | 整批定义一次 `register_batch` |
| 注销插件 | 整插件一次 `unregister_plugin`；历史审计保留 |
| 下架插件/工具 | 范围内所有版本一次 disable；新快照不可见，旧快照执行被拦截 |
| 上架插件/工具 | 每个工具只 enable + activate 最新版本；其他版本不意外恢复 |
| 紧急熔断 | 继续复用 `kill` / `kill_version` |

下架/卸载后，旧快照返回 `TOOL_OFFLINE`；已经开始且有副作用的 handler 不承诺强制回滚，管理操作只保证后续执行准入与后续快照。

### 10.3 管理面接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/admin/plugins` | 插件、来源、工具、版本、上架状态 |
| POST | `/admin/plugins/{id}/install` | 动态安装已注册到服务端的插件工厂，整批原子提交 |
| POST | `/admin/plugins/{id}/uninstall` | 整插件原子卸载 |
| POST | `/admin/plugins/{id}/offline` | 整插件下架 |
| POST | `/admin/plugins/{id}/online` | 整插件按最新版本上架 |
| POST | `/admin/tools/{name}/offline` | 单工具全版本下架 |
| POST | `/admin/tools/{name}/online` | 单工具按指定版本或最新版本上架 |
| GET | `/admin/tools` | 增加 `origin` / `plugin_id` / `required_permissions` / `allowed_roles` / `online` |

所有接口必须使用 4.4 的实时 admin 授权。请求体不能指定任意模块路径或任意 Python 导入字符串，只能引用服务端预注册插件工厂。

动态安装/卸载仅用于受控调试和运行时实验，**不持久化**。响应必须包含：

```json
{
  "revision": 12,
  "persistence": "memory_only",
  "restart_behavior": "rebuild_from_config"
}
```

启动真相源仍是内置目录与配置文件，避免把该接口宣传为“重启后仍保持”的管理承诺。不将注册/下架能力暴露为模型工具。

---

## 11. 关键流程

### 11.1 启动注册

```text
Container.startup
  → 初始化 Database schema migrations，再执行用户/权限 seed
  → 读取并严格校验 config/tools.json、AUTH_IDENTITIES_JSON、mcp_servers.json
  → ToolRegistry()
  → 构造内置插件定义
  → 对每个定义先应用治理覆盖（含 allowed_roles）
  → 内置定义 register_batch；冲突或非法配置启动失败
  → 每个 MCP server 独立构造 → 注册前应用治理 → register_batch
       ├─ 成功：提交完整 server
       └─ 冲突/漂移/连接失败：本 server 不提交，WARN 后跳过
  → 校验空 schema / 非法角色 / 名称长度 / plugin_id
  → 启动审批过期清扫与 WAITING_APPROVAL 重启恢复
  → 输出最终 revision + 工具清单（origin / plugin_id / version）
```

**顺序约束**：不得在 `register()` 后才应用 `tools.json`。由于 fingerprint 不包含治理字段且同指纹注册是 no-op，后置覆盖会静默失效。

### 11.2 单次请求

```text
POST /tasks/start（认证得到 actor_id）
  → 持久化 task.actor_id
  → PermissionService.resolve(actor_id) → ToolSession
  → AgentLoop 每轮：
      await session.refresh_identity()
      snapshot = runtime.build_snapshot(session, round)
      tool_defs = snapshot.to_tool_defs()
      decision = LLM
      call = ToolCallRequest(...)
      result = runtime.execute(snapshot, call, session)
      → 发布 tool_call / tool_result 事件
```

### 11.3 审批交互

```text
前端收到 tool_confirmation_request：
  {
    "approval_token": "apr_xxx",
    "tool_name": "pay_order",
    "tool_version": "1.0.0",
    "risk_level": "high",
    "args_preview": {"order_id": "...", "method": "balance"},
    "expires_at": "...",
    "snapshot_id": "snap_xxx",
    "message": "请确认是否执行 付款"
  }

用户确认：
POST /tasks/{task_id}/confirm
  { "approval_token": "apr_xxx", "confirmed": true, "comment": "同意" }

后端：
  认证与任务所有者校验
  → orchestrator.confirm → approval_store.resolve(token, task_id, actor_id, ...)
  → 返回 ApprovalResolution 的安全字段
  → Runtime 唤醒 → 最新身份/快照/版本/下架复核 → consume → handler
  → tool_result 事件
```

---

## 12. 接口、配置与数据库变更

### 12.1 API 与事件

| 位置 | 变更 |
| --- | --- |
| `SSEEventType.TOOL_CONFIRMATION_REQUEST` | 内存/SSE 新增 `approval_token`、`expires_at`、`snapshot_id`、脱敏 `args_preview`；持久化副本以 `approval_token_hash` 替代 token |
| `ConfirmToolRequest` | `approval_token: str`、`confirmed: bool`、`comment: Optional[str]`；token 必填，删除 `step/tool_name/tool_call_id` 匹配方式 |
| `ConfirmToolResponse` | 返回 `task_id`、`tool_call_id`、`tool_name`、`tool_version`、`status`、`decided_at`；不返回 token，字段来自 `ApprovalResolution` |
| `TaskStatus` | 新增 `WAITING_APPROVAL`；更新全部合法转换 |
| 任务取消 | 新增 `POST /tasks/{task_id}/cancel`，与暂停 `stop` 分离 |
| 任务归属 | start / stop / resume / cancel / confirm / events 校验当前 `actor_id` 与任务所有者 |
| Admin | 新增 plugins / offline / online；全部要求实时 admin 角色 |
| 审计字段 | `approval_token_hash`、`approval_requested_at`、`approval_resolved_at`、`approved_by`、`approval_comment` |
| 错误码 | `APPROVAL_TOKEN_INVALID`、`APPROVAL_TOKEN_EXPIRED`、`APPROVAL_TOKEN_CONSUMED`、`TOOL_OFFLINE`、`TOOL_ROLE_DENIED` |

前端改动：

- `types/index.ts` 增加审批票据字段和 `WAITING_APPROVAL`；
- `composables/useTask.ts` 只在内存保存 token，处理无 token 的历史事件为不可确认；
- `api/task.ts` 一次性改为 token 请求，并增加 cancel API；
- `App.vue` 展示工具、版本、脱敏参数、到期时间和审批状态；过期/已消费/无 token 时禁用按钮，并提供取消任务入口。

### 12.2 配置

新增：

- `AUTH_IDENTITIES_JSON`：token → user_id 映射，启动严格校验；
- `tool_approval_ttl_seconds=300`；
- `tool_approval_sweep_interval_seconds=1`；
- `mcp_config_path=backend/config/mcp_servers.json`。

不增加票据签名 secret。旧 `AUTH_TOKEN` 不再作为所有请求的默认管理员身份；部署迁移必须同时配置身份映射和前端 token。

### 12.3 SQLite 迁移与回填

当前 `_SCHEMA` 的 `CREATE TABLE IF NOT EXISTS` 不会给旧表增加列，因此必须新增版本化 migration，而不是只改建表字符串：

1. 建立 `schema_migrations(version PRIMARY KEY, applied_at)`；migration 按版本在事务中执行并记录。
2. 通过 `PRAGMA table_info` 检查并迁移：`tasks.actor_id`、`tool_calls.approval_token_hash`、`approval_requested_at`、`approval_resolved_at`、`approved_by`、`approval_comment`。
3. 旧 `tasks` 行的 `actor_id` 回填为历史默认用户，保持旧任务可查询；新任务必须由应用强制提供 actor，不允许新增匿名任务。
4. 权限 seed 在 migration 后运行；逐条 `INSERT OR IGNORE` 为已有默认管理员补齐 `order.*`，不覆盖既有用户角色或撤销历史授权。
5. 新库直接执行完整 schema 与全部 migration；旧库升级测试必须验证列、索引、回填和幂等重复启动。

---

## 13. 文件清单

### 13.1 新增

```text
backend/app/core/tools/approval.py             # 票据、Store、TicketApprovalGate、ApprovalResolution
backend/app/core/tools/error_schema.py         # ToolErrorSchema 与安全动作映射
backend/app/core/tools/plugin.py               # ToolPlugin / PluginManager
backend/app/core/tools/mcp/client.py           # McpClient 协议 + MockMcpClient
backend/app/core/tools/mcp/provider.py         # MCP → ToolDefinition
backend/app/core/tools/handlers/orders.py      # 订单 mock 与业务去重
backend/app/infra/migrations.py                # 版本化 SQLite migrations
backend/config/mcp_servers.json
backend/tests/test_tool_platform.py            # pytest 平台、负向与并发用例
```

### 13.2 修改

```text
backend/app/core/runtime.py                    # WAITING_APPROVAL、cancel、合法状态转换、task.actor_id
backend/app/core/tools/enums.py                # ToolOrigin / ApprovalTicketStatus / ModelAction / 订单权限
backend/app/core/tools/definition.py           # origin / plugin_id / allowed_roles / ToolErrorSpec.model_action
backend/app/core/tools/policy.py               # 注册前合并 allowed_roles，严格校验治理配置
backend/app/core/tools/registry.py             # 角色过滤、来源索引、批量单次 commit API
backend/app/core/tools/snapshot.py             # ToolRef 权限角色字段；继续复用 to_tool_defs
backend/app/core/tools/session.py              # ActorContext.roles、refresh_actor、完整审批请求字段、request_id
backend/app/core/tools/runtime.py              # 票据审批、审批后复核、error_schema、副作用路由
backend/app/core/tools/validation.py           # 最新身份角色、下架、权限差异
backend/app/core/tools/retry.py                # 与模型动作共享副作用安全约束
backend/app/core/tools/result.py               # error_schema + 审批审计字段
backend/app/core/tools/catalog.py              # 订单工具；注册前治理；内置/MCP 分批注册
backend/app/container.py                       # Store / PluginManager / MCP / sweeper / 启动恢复组装
backend/app/core/loop.py                       # ToolSession、token 事件、等待状态、模型动作路由
backend/app/core/runner.py                     # 同一调用类型与身份刷新；保留回调/AutoDeny 审批
backend/app/core/orchestrator.py               # token confirm、任务所有者、真正 cancel、重启恢复
backend/app/services/task_service.py           # PendingConfirmation 下线、取消信号、所有者持久化
backend/app/services/permission_service.py     # roles、active 用户、取消隐式默认身份
backend/app/services/event_buffer.py           # SSE 数据与持久化脱敏副本分离
backend/app/api/middleware/auth.py             # token→actor 映射，禁止默认管理员回退
backend/app/api/routes/tasks.py                # 所有者校验、cancel、token confirm
backend/app/api/routes/runs.py                 # actor 透传；保持无票据审批边界
backend/app/api/routes/admin.py                # 实时 admin 依赖、插件管理
backend/app/api/schemas/{sse,task,admin}.py
backend/app/config.py                          # 身份映射、审批 TTL/清扫、MCP 配置
backend/config/tools.json                      # 订单工具治理覆盖
backend/app/infra/db.py                        # actor/审计字段、migration 调用、权限 seed
backend/scripts/test_tool_runtime.py           # 断言迁移到 pytest 或由 pytest 调用
frontend/src/types/index.ts
frontend/src/api/task.ts
frontend/src/composables/useTask.ts
frontend/src/App.vue
README.md                                      # 部署身份配置和协议破坏式变更说明
docs/个人助理Agent_工具运行时版本治理与审批_v1.0.0.md
```

---

## 14. 实施计划与验收

所有新增测试使用 pytest，不以“手写脚本运行结束”代替断言。基础命令：`python -m pytest backend/tests -q`；现有回归脚本迁移后纳入同一测试入口。

| 阶段 | 内容 | 必须通过的验收 |
| --- | --- | --- |
| P1 身份与平台基础 | 扩展 Session / Spec / Ref、身份映射、任务所有者、迁移框架、批量注册表 | guest 快照无退款工具，admin 有；未映射 token 为 401；非 admin 管理接口为 403；快照后降权执行被拒；批量操作 revision 仅 +1 |
| P2 订单工具 | 4 个 handler、权限 seed、治理配置 | 下单/支付/退款/查询全通过；空查询条件为 422；limit 上限生效；同去重号同参数仅建单一次，不同参数返回冲突；非本人订单为 NOT_FOUND |
| P3 审批与状态闭环 | Store、token 事件、confirm、cancel、等待状态、sweeper、重启恢复 | 覆盖确认、拒绝、超时、重复确认、跨用户、跨 task、过期、快照失效、审批后降权、下架竞态、取消与重启；所有路径 handler 是否执行均有明确断言 |
| P4 错误 Schema | 安全映射、日志/异常分流、模型动作计数 | 内部错误不回灌细节；默认不可模型解决；拒绝审批为 STOP；非幂等写超时绝不产生 RETRY_SAME；连续可恢复失败达到上限后终止 |
| P5 MCP 与插件 | mock MCP、原子 install/uninstall/offline/online、实时 admin | `/admin/tools` 可见来源；同版本 schema 漂移只跳过该 server 并 WARN；内置冲突启动失败；下架后旧快照不能执行；动态接口明确返回 memory_only |
| P6 迁移、并发与端到端回归 | 旧库升级、两套 Loop、前端、并发 | 旧库重复迁移幂等且默认管理员补齐 order.*；AgentLoop 票据可用；Runner 回调可批准、HTTP /runs 默认拒绝；pytest 与 e2e 全部通过 |

### 14.1 必做负向与并发用例

1. **原子确认**：对同一 token 并发发起 100 次 confirm，最多一次完成 `PENDING → APPROVED/DENIED`，其余均为状态冲突；最终至多一次 consume，handler 调用次数为 0 或 1。
2. **归属隔离**：其他用户、其他 task、管理员代办均不能确认；跨用户订单查询同样失败。
3. **取消唤醒**：等待审批时 cancel，`revoke_task()` 立即使 `wait()` 返回并抛 `ToolCancelledError`，测试用短 `asyncio.wait_for` 验证，不等待 300 秒自然超时。
4. **TTL 与快照**：票据 `expires_at <= snapshot.expires_at`；快照过期后即使决策被受理，也不得 consume 或执行 handler。
5. **降权与下架**：分别在快照后、审批后撤销权限/角色和下架版本，执行前复核必须拦截。
6. **敏感信息**：发布审批事件后查询 `task_events.data`、审计、确认响应和捕获日志，均不得包含原始 token 或未脱敏参数。
7. **重启出口**：构造数据库中 `WAITING_APPROVAL` 任务，重启后为 `FAILED`，可冷恢复并签发新 token；旧 token 无效。
8. **插件原子性**：并发构建 50 次快照并执行整插件 offline/online，每个快照只能包含插件全部工具或全部不包含，revision 每次操作只增加 1，不允许半插件状态。
9. **MCP 漂移**：同版本 schema 变化使整个该 server 不注册，其他 server 与内置工具数量不变。
10. **旧库迁移**：使用缺少新增列和订单权限的 SQLite 文件升级，列与权限补齐，旧任务 owner 回填，第二次启动无重复变更。
11. **副作用安全**：pay/refund 注入超时，Runtime 自动重试次数为 0，错误动作不是 `RETRY_SAME`，handler 业务状态不会被盲目重复推进。

---

## 15. 风险与约定

1. **票据只在内存**：仅支持单 worker；token 明文不落库是强制安全边界，持久化事件只存 hash。进程重启后等待任务先转 `FAILED`，不是让数据库永久等待。
2. **确认不等于执行成功**：Store 负责原子审批决策，Runtime 负责最终执行准入；以后者结果为准。
3. **确认接口不接受前端参数**：一律以票据中的参数和参数哈希为准，执行前原子 consume。
4. **MCP 工具名与版本**：超长拒绝；同版本 spec 漂移必须升 `server.version`，单 server 失败隔离。
5. **动态插件不持久化**：只用于调试/实验，响应明确标注重启行为；配置仍是启动真相源。
6. **批量操作原子提交**：offline/online/install/uninstall 都使用单次 copy-on-write commit，不逐个版本独立提交。
7. **两套执行链共享校验但审批通道不同**：AgentLoop 使用票据；Runner 使用程序化回调或 AutoDeny，不制造无人可确认的 token。
8. **角色与权限成对校验**：快照时过滤不可见工具；执行前和审批后读取最新身份，处理快照后的变化。
9. **副作用优先于错误类别**：任何模型动作建议都不能绕开 effect、phase、possible_side_effect 与业务去重判断。
10. **审计不阻断业务结果**：审计失败记 ERROR，但敏感信息脱敏不能失败开放；无法生成安全事件/结果时应拒绝发布敏感内容。

---

## 附录 A：审批状态机

```text
PENDING ──approve──→ APPROVED ──consume（未过期）──→ CONSUMED
   │                   │
   │                   ├──revoke（consume 前）──→ CANCELLED
   │                   └──expire───────────────→ EXPIRED
   ├──deny───────────→ DENIED
   ├──expire─────────→ EXPIRED
   └──revoke─────────→ CANCELLED
```

状态迁移与唤醒同步完成；`CONSUMED` 是执行前一次性门槛，不是审批决定本身。

## 附录 B：工具快照与执行的身份字段

| 字段 | 快照 | 执行前校验 | 说明 |
| --- | --- | --- | --- |
| `tool_name` | ✓ | ✓ | 必须命中快照 |
| `tool_version` | ✓ | ✓ | 版本不存在、禁用或被 kill 时拒绝 |
| `fingerprint` | ✓ | ✓ | 变化说明 spec 或 handler 变化 |
| `required_permissions` | ✓ | ✓（最新身份与实时定义） | 权限被回收时拒绝 |
| `allowed_roles` | ✓ | ✓（最新身份与实时定义） | 角色不符时拒绝 |
| `actor_id` | ✓ | ✓ | 任务、票据、执行身份必须一致 |
| `args_hash` | 票据 | ✓ | 防止确认 A、执行 B |
| `snapshot_id` | ✓ | ✓ | 票据与结果均记录 |
| `registry_revision` | ✓ | 记录 | 用于审计追溯，不能替代实时状态校验 |
