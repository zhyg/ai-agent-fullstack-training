# 个人助理 Agent

一个端到端的个人助理 Agent 应用：用户在网页上输入任务，后端以大模型驱动 **"思考 → 行动 → 观察"** 循环自动执行（联网搜索、发送邮件等工具），中间过程通过 **SSE（Server-Sent Events）** 实时流式推送到前端；支持**暂停 / 恢复**——暂停只停止输出与消费，会话不结束，恢复后顺着原来的序列号在同一条模型流上继续输出。

## 功能特性

- **流式输出**：大模型逐 token 生成，后端逐帧转发为 SSE `token` 事件，前端实时渲染。
- **暂停 / 原地续流**：点击"暂停"后任务状态为 `paused`，不终止循环、不发终止事件；点击"恢复"后从同一 `seq` 继续推送，前端在同一行接续文字。进程重启后退化为冷恢复（重做被中断的步骤）。
- **Agent 主循环**：LLM 输出 JSON 决策（`thought/action/tool_name/tool_args/answer`），经 Schema 校验与自动纠错，最多执行 `max_steps` 步。
- **工具系统**：内置 `web_search`、`send_email`、生活缴费查询、购物审批流与订单工具（下单/支付/退款/查询）；危险工具使用 **一次性审批票据** 二次确认，支持超时、拒绝、取消唤醒与单次消费。
- **插件 / MCP**：工具统一带 `origin` 与 `plugin_id`，支持 MCP server 批量注册、插件整包上下架；运行中 kill switch 与旧快照拦截。
- **可取消**：`cancel` 立即终止任务、撤销审批票据并唤醒审批等待，与"暂停"语义区分。
- **多模型**：通过统一 LLM Gateway 接入 OpenAI / DeepSeek / Anthropic，支持任务运行中切换模型（下一轮调用生效）。
- **可观测**：SQLite 持久化任务快照、事件流、请求日志与异常链路；结构化日志（structlog），日志自动脱敏。
- **安全**：Bearer Token 鉴权、令牌桶限流、提示词注入防护与输出脱敏。

## 技术栈

| 层 | 技术 |
| --- | --- |
| 前端 | Vue 3 + TypeScript + Vite，原生 `fetch + ReadableStream` 解析 SSE |
| 后端 | Python 3.13 + FastAPI + uvicorn，全异步（asyncio） |
| 存储 | SQLite（aiosqlite） |
| 模型 | OpenAI SDK（OpenAI / DeepSeek 兼容协议）、httpx 直连（Anthropic SSE） |

## 目录结构

```
myAgent/
├── backend/
│   ├── app/
│   │   ├── api/            # 路由、中间件（鉴权/限流/trace/异常）、DTO（task/sse/admin）
│   │   ├── core/           # Agent 核心：loop 主循环、orchestrator 生命周期、runtime 状态机、
│   │   │                   #   prompt（渲染/模板/注入防护）、tools（runtime/approval/orders/mcp/plugin）
│   │   ├── llm/            # Gateway、模型注册表、重试、供应商适配器
│   │   ├── services/       # event_buffer（事件缓冲+订阅通知）、task_service（注册表+快照+确认）
│   │   ├── infra/          # db（SQLite）、logger、tracing
│   │   ├── config.py       # 配置（环境变量）
│   │   ├── container.py    # 依赖容器（启动组装/关闭清理）
│   │   └── main.py         # FastAPI 入口
│   ├── tests/              # pytest：审批票据、身份/角色、错误动作、订单、MCP、迁移
│   ├── scripts/test_e2e.py # 全链路验证脚本（真实调用 LLM）
│   ├── .env.example        # 环境变量模板（复制为 .env 使用）
│   └── requirements.txt
└── frontend/
    └── src/
        ├── api/            # task.ts（REST 封装）、sse.ts（SSE 订阅解析）
        ├── composables/    # useTask.ts（任务状态机 + 事件处理）
        ├── components/     # ChatInput / StreamOutput / ModelSelector
        └── types/          # 类型定义
```

## 快速开始

### 1. 后端

```bash
cd backend
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env   # 然后填入真实值（见下表）
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### 2. 前端

```bash
cd frontend
npm install
npm run dev        # http://localhost:5173（已代理 /api → 8000）
```

打开页面后先在顶部输入 `AUTH_IDENTITIES_JSON` 中配置的某个 Token 并保存，即可开始使用；不同 Token 对应不同 `actor_id`，只能访问自己的任务。

## 环境变量

| 变量 | 说明 | 必填 |
| --- | --- | --- |
| `HOST` / `PORT` / `DEBUG` | 服务监听与调试开关 | 否 |
| `AUTH_TOKEN` | API 鉴权 Token（前端请求需携带） | **是** |
| `AUTH_IDENTITIES_JSON` | Token→`actor_id` 映射，如 `{"token-a":"user_a"}`；**空映射拒绝启动** | **是** |
| `RATE_LIMIT_PER_MINUTE` | 限流：每 Token 每分钟请求数 | 否 |
| `DEFAULT_MODEL` | 默认模型 ID（如 `gpt-4o` / `deepseek-flash`） | 否 |
| `OPENAI_API_KEY` / `OPENAI_BASE_URL` | OpenAI 及兼容协议供应商 | **至少配一家** |
| `DEEPSEEK_API_KEY` / `DEEPSEEK_BASE_URL` | DeepSeek | 同上 |
| `ANTHROPIC_API_KEY` / `ANTHROPIC_BASE_URL` | Anthropic（不配则 Claude 模型不可用） | 同上 |
| `DATABASE_URL` | SQLite 连接串，默认 `sqlite:///./agent.db` | 否 |
| `AGENT_MAX_STEPS` / `LLM_MAX_RETRIES` / `LLM_BASE_DELAY` / `LLM_MAX_TOKENS` | Agent 与 LLM 调参 | 否 |
| `SEND_EMAIL_SMTP_*` | 邮件工具：SMTP 主机/端口/SSL/账号/授权码/发件名 | 用发邮件时必填 |
| `WEB_SEARCH_API_KEY` | 联网搜索工具 API Key | 用搜索时必填 |
| `TOOL_CONFIG_PATH` / `MCP_CONFIG_PATH` | 工具治理覆盖 / MCP server 配置路径 | 否 |
| `APPROVAL_TTL_SECONDS` / `APPROVAL_SWEEP_INTERVAL_SECONDS` | 审批票据有效期 / 过期清扫间隔 | 否 |
| `DEFAULT_USER_ID` | 历史默认用户，仅用于旧任务回填与种子用户 | 否 |

> 敏感值只放在 `backend/.env`（已在 `.gitignore` 中），`.env.example` 为模板，请勿提交真实 Key。

## API 一览（`/api/v1`，均需 `Authorization: Bearer <AUTH_TOKEN>`）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/tasks/start` | 开始任务，立即返回 `task_id` / `trace_id` |
| GET | `/tasks/{id}/events?last_seq=n` | **SSE 事件流**：推送 `seq > last_seq` 的事件，支持断点续传与心跳（`: ping`） |
| POST | `/tasks/{id}/stop` | **暂停**任务：停止输出与消费，任务不结束 |
| POST | `/tasks/{id}/cancel` | **取消**任务：置取消信号、撤销审批票据、唤醒审批等待 |
| POST | `/tasks/{id}/resume` | **恢复**任务：暂停中走原地续流（`in_place=true`），否则冷恢复 |
| POST | `/tasks/{id}/confirm` | 审批确认：`approval_token` + `confirmed` + `comment`（仅任务所有者） |
| PUT | `/tasks/{id}/model` | 切换模型（下一轮 LLM 调用生效） |
| GET | `/models` | 可用模型列表 |
| GET | `/admin/plugins` | 插件/工具版本与在线状态 |
| POST | `/admin/plugins/{id}/install\|uninstall\|offline\|online` | 插件整包管理（动态操作仅内存生效） |
| GET | `/admin/requests` | 请求日志分页查询 |
| GET | `/admin/traces/{trace_id}` | 异常链路查询 |

> `/admin/*` 每次请求实时校验数据库角色，必须为 `active` 且 `role=admin`。

### SSE 事件协议

帧格式为三段式 `id / event / data`，`id` 即单调递增的 `seq`（前端按 `task_id + seq` 去重）：

```
id: 12
event: token
data: {"content": "你好"}
```

事件类型：`task_started` → `token`（流式增量）→ `thought` → `tool_call` / `tool_confirmation_request` / `tool_result` → `final_answer` → `task_finished`（终态，`error` 为错误事件）。

## 核心机制

### 任务状态机

```
pending → running → completed / failed / cancelled
running ↔ paused                 # 暂停/原地续流
running ↔ waiting_approval       # 审批等待（仅回到运行或终止）
waiting_approval → failed        # 重启后票据丢失，统一失败
cancelled/failed → running       # 冷恢复（重做被中断步骤）
```

### 审批票据

1. 校验通过且 `requires_confirmation=true` → 刷新用户状态/权限/角色 → 签发一次性 token（TTL 与快照过期时间取小）。
2. SSE 推送 `tool_confirmation_request`（含 `approval_token`、`expires_at`、`snapshot_id`、脱敏 `args_preview`）；**数据库只保存 token hash**。
3. 任务进入 `waiting_approval`；确认接口按 token 绑定任务/工具调用/所有者，拒绝或重复确认返回明确错误码。
4. 批准后再次刷新身份并复核快照、kill switch、权限与角色，通过后 **原子 consume** 才执行 handler；失败绝不执行副作用。
5. 超时 / 拒绝 / 取消分别映射为 `ASK_USER` / `STOP` / 取消异常；非幂等写不会收到 `RETRY_SAME` 建议。

### 暂停 / 恢复（原地续流）

- **暂停**：`stop` 清空运行任务的"继续消费"信号；循环在**每读一帧前、每发布一帧前、每轮循环边界、每次工具执行前**都会等待该信号，因此在下一个帧边界停住；不发 `cancelled`/`task_finished`，SSE 连接靠心跳保持。
- **恢复**：内存中任务仍处于 `paused` 时直接唤醒同一条 LLM 流（`in_place=true`），`seq` 连续、前端同一行接续；否则按 DB 快照冷恢复（`in_place=false`，回退重做被中断的步骤）。
- 注意：各模型供应商均不支持"从第 N 个 token 续写"，所以原地续流的前提是**底层 HTTP 流未被真正中断**；长时间暂停导致供应商流超时、或服务端进程重启时，只能走冷恢复。

### Agent 主循环

每步：构建系统/决策提示词 → LLM 流式输出 JSON → Schema 校验（失败自动追加纠错消息重试，连续失败达上限终止）→ 发布思考 → 按决策执行工具或产出最终答案 → 注入上下文快照。需审批工具签发一次性票据并挂起等待；超时/拒绝按 `ToolErrorSchema.model_action` 映射为询问或停止，不执行副作用。

## 测试

```bash
cd backend
pip install -r requirements-dev.txt
python -m pytest -q
```

`tests/test_tool_platform.py` 覆盖：审批 token 绑定/过期/单次消费、取消唤醒、错误动作映射、订单审批与副作用、身份角色刷新、插件上下架与旧快照拦截、MCP 注册、SQLite 迁移回填、SSE 持久化脱敏、空身份映射拒绝启动等。

真实全链路（会调用 LLM）：

```bash
cd backend
python scripts/test_e2e.py
```

真实调用 LLM，分四个阶段验证：直连 → Gateway 适配层 → Agent 全链路（含 SSE 与 DB 一致性）→ 暂停/原地续流（会话不结束、`seq` 连续、步骤不重做）。

## 安全说明

- 所有 `/api` 接口要求 `Authorization: Bearer`；Token 必须命中 `AUTH_IDENTITIES_JSON`，未命中返回 401，**不回退默认管理员**。
- 任务所有者、事件流、暂停/恢复/取消/确认/切模型均校验 `actor_id`；角色在每次执行前从数据库实时刷新。
- 审批 token 只存在于内存票据、SSE 与确认请求；数据库与审计仅保存 SHA-256 摘要，确认后单次消费。
- `/admin/*` 实时校验 `active` 且 `role=admin`；动态插件安装仅允许服务端预注册工厂。
- 限流按 Token 分桶；结构化日志对 key/token/邮箱等敏感字段脱敏。
- LLM 输出经 `sanitize_output` 脱敏后再推送；提示词模板含注入防护。
