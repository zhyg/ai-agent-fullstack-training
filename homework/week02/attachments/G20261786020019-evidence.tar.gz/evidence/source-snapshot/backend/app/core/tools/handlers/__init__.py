"""内置 handler 包：只包含业务动作，不依赖 gateway / loop / registry。"""
