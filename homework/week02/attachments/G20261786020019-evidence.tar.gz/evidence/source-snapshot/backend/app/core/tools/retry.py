"""错误分类与重试决策：按异常分类选择策略，不统一重试 N 次。"""
import asyncio
import random
from typing import Any

from app.core.exceptions import AppException
from app.core.tools.definition import ToolDefinition
from app.core.tools.enums import ErrorPhase, ToolEffect, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError
from app.core.tools.result import ToolErrorInfo

# 分类对应的全局重试上限（与治理策略取较小值）
CATEGORY_MAX_RETRIES: dict[ToolErrorCategory, int] = {
    ToolErrorCategory.TIMEOUT: 2,
    ToolErrorCategory.NETWORK: 3,
    ToolErrorCategory.RATE_LIMIT: 2,
    ToolErrorCategory.UPSTREAM: 2,
}

# 非幂等写操作允许“确定未产生副作用”的极小重试窗口，默认策略仍为 0
_REPLAY_ONLY_PRE_EFFECT = {
    ToolErrorCategory.NETWORK,
    ToolErrorCategory.RATE_LIMIT,
    ToolErrorCategory.UPSTREAM,
    ToolErrorCategory.TIMEOUT,
}


def _error(
    *,
    category: ToolErrorCategory,
    code: str,
    message: str,
    model_message: str,
    phase: ErrorPhase = ErrorPhase.UNKNOWN,
    retryable: bool = False,
    retry_after: float | None = None,
) -> ToolErrorInfo:
    info = ToolErrorInfo(
        category=category,
        code=code,
        message=message,
        model_message=model_message,
        retryable=retryable,
        phase=phase,
        retry_after=retry_after,
    )
    return info


def classify_exception(exc: BaseException, *, tool_name: str,
                       effect: ToolEffect) -> ToolErrorInfo:
    """把 handler 抛出的异常映射为统一错误分类。"""
    if isinstance(exc, ToolBusinessError):
        return _error(
            category=exc.category,
            code=exc.code,
            message=exc.message,
            model_message=exc.model_message,
            phase=exc.phase,
            retryable=exc.category in CATEGORY_MAX_RETRIES,
            retry_after=exc.retry_after,
        )

    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        phase = (
            ErrorPhase.PRE_SIDE_EFFECT
            if effect != ToolEffect.NON_IDEMPOTENT_WRITE
            else ErrorPhase.POST_SIDE_EFFECT
        )
        return _error(
            category=ToolErrorCategory.TIMEOUT,
            code="1608",
            message=f"工具 {tool_name} 执行超时",
            model_message="工具执行超时，结果可能未完成",
            phase=phase,
            retryable=True,
        )

    # httpx / aiosmtplib 等基础设施异常：延迟导入，避免强依赖
    module = type(exc).__module__
    name = type(exc).__name__

    if module.startswith("httpx"):
        return _classify_httpx(exc, tool_name=tool_name, name=name)
    if module.startswith("aiosmtplib"):
        return _classify_smtp(exc, tool_name=tool_name, name=name)

    if isinstance(exc, AppException):
        if exc.code.value == "1602":
            return _error(
                category=ToolErrorCategory.VALIDATION,
                code=exc.code.value,
                message=exc.message,
                model_message=exc.message,
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        if exc.code.value == "1600":
            return _error(
                category=ToolErrorCategory.NOT_FOUND,
                code=exc.code.value,
                message=exc.message,
                model_message=exc.message,
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        return _error(
            category=ToolErrorCategory.INTERNAL,
            code=exc.code.value,
            message=exc.message,
            model_message=exc.message,
            phase=ErrorPhase.UNKNOWN,
        )

    return _error(
        category=ToolErrorCategory.INTERNAL,
        code="1601",
        message=f"工具 {tool_name} 执行异常: {exc}",
        model_message="工具执行发生内部错误",
        phase=ErrorPhase.UNKNOWN,
    )


def _classify_httpx(exc: BaseException, *, tool_name: str, name: str) -> ToolErrorInfo:
    if name in {"TimeoutException", "ReadTimeout", "ConnectTimeout", "WriteTimeout",
                "PoolTimeout"}:
        return _error(
            category=ToolErrorCategory.TIMEOUT,
            code="1608",
            message=f"工具 {tool_name} 请求超时",
            model_message="外部请求超时，请稍后重试",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
            retryable=True,
        )
    if name in {"ConnectError", "NetworkError", "ConnectTimeout"}:
        return _error(
            category=ToolErrorCategory.NETWORK,
            code="TOOL_NETWORK_ERROR",
            message=f"工具 {tool_name} 网络连接失败",
            model_message="外部服务连接失败",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
            retryable=True,
        )
    status = getattr(getattr(exc, "response", None), "status_code", None)
    if status == 429:
        retry_after = None
        try:
            retry_after = float(exc.response.headers.get("Retry-After", ""))
        except (TypeError, ValueError):
            pass
        return _error(
            category=ToolErrorCategory.RATE_LIMIT,
            code="1610",
            message=f"工具 {tool_name} 被限流",
            model_message="外部服务限流，请稍后重试",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
            retryable=True,
            retry_after=retry_after,
        )
    if status in (401, 403):
        return _error(
            category=ToolErrorCategory.AUTH,
            code="TOOL_AUTH_FAILED",
            message=f"工具 {tool_name} 鉴权失败: HTTP {status}",
            model_message="外部服务鉴权失败，请检查配置",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    if isinstance(status, int) and status >= 500:
        return _error(
            category=ToolErrorCategory.UPSTREAM,
            code="TOOL_UPSTREAM_ERROR",
            message=f"工具 {tool_name} 上游异常: HTTP {status}",
            model_message="外部服务暂不可用",
            phase=ErrorPhase.UNKNOWN,
            retryable=True,
        )
    return _error(
        category=ToolErrorCategory.BUSINESS,
        code="TOOL_HTTP_ERROR",
        message=f"工具 {tool_name} 请求失败: {exc}",
        model_message="外部请求失败",
        phase=ErrorPhase.PRE_SIDE_EFFECT,
    )


def _classify_smtp(exc: BaseException, *, tool_name: str, name: str) -> ToolErrorInfo:
    if name == "SMTPAuthenticationError":
        return _error(
            category=ToolErrorCategory.BUSINESS,
            code="EMAIL_AUTH_FAILED",
            message=f"工具 {tool_name} SMTP 认证失败",
            model_message="邮件认证失败，请检查 SMTP 授权码与账号配置",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    if name == "SMTPConnectError":
        return _error(
            category=ToolErrorCategory.NETWORK,
            code="EMAIL_CONNECT_FAILED",
            message=f"工具 {tool_name} SMTP 连接失败",
            model_message="邮件服务连接失败",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    if name == "SMTPTimeoutError":
        return _error(
            category=ToolErrorCategory.TIMEOUT,
            code="1608",
            message=f"工具 {tool_name} SMTP 超时",
            model_message="邮件发送超时，结果可能不确定",
            phase=ErrorPhase.POST_SIDE_EFFECT,
        )
    return _error(
        category=ToolErrorCategory.BUSINESS,
        code="EMAIL_SEND_FAILED",
        message=f"工具 {tool_name} 邮件发送失败: {exc}",
        model_message="邮件发送失败",
        phase=ErrorPhase.UNKNOWN,
    )


def replay_safe(effect: ToolEffect, phase: ErrorPhase,
                idempotency_key: str | None) -> bool:
    if effect == ToolEffect.READ_ONLY:
        return True
    if effect == ToolEffect.IDEMPOTENT_WRITE:
        return idempotency_key is not None
    return phase == ErrorPhase.PRE_SIDE_EFFECT


def decide_retry(definition: ToolDefinition, error: ToolErrorInfo,
                 attempt: int, idempotency_key: str | None) -> bool:
    """attempt 为已进行的重试次数（首次执行失败后 attempt=0）。"""
    policy = definition.governance.retry_policy
    cap = CATEGORY_MAX_RETRIES.get(error.category, 0)
    if cap <= 0:
        return False
    if error.category not in policy.retry_on:
        return False
    if attempt >= min(policy.max_retries, cap):
        return False
    if not replay_safe(definition.governance.effect, error.phase, idempotency_key):
        return False
    if (definition.governance.effect == ToolEffect.NON_IDEMPOTENT_WRITE
            and error.category not in _REPLAY_ONLY_PRE_EFFECT):
        return False
    return True


def compute_delay(policy, attempt: int, error: ToolErrorInfo) -> float:
    delay = min(policy.base_delay * (2 ** attempt), policy.max_delay)
    if policy.jitter and delay > 0:
        delay *= random.uniform(0.5, 1.5)
    retry_after = getattr(error, "retry_after", None)
    if retry_after and policy.respect_retry_after:
        delay = min(float(retry_after), policy.max_delay)
    return max(delay, 0.0)


def mark_retryable(error: ToolErrorInfo, retryable: bool) -> None:
    """按治理策略覆盖分类默认的可重试标记（用于审计展示）。"""
    error.retryable = retryable


def possible_side_effect(effect: ToolEffect, error: ToolErrorInfo | None) -> bool:
    if effect != ToolEffect.NON_IDEMPOTENT_WRITE or error is None:
        return False
    if error.phase == ErrorPhase.POST_SIDE_EFFECT:
        return True
    return error.category in {
        ToolErrorCategory.TIMEOUT,
        ToolErrorCategory.UPSTREAM,
        ToolErrorCategory.INTERNAL,
    }


def retry_strategy_text(error: ToolErrorInfo, retry_count: int,
                        effect: ToolEffect) -> str:
    if retry_count > 0:
        return f"retry_exhausted({retry_count})"
    if effect != ToolEffect.READ_ONLY and error.category in _REPLAY_ONLY_PRE_EFFECT:
        return "no_retry_non_idempotent"
    if error.category in CATEGORY_MAX_RETRIES:
        return "no_retry_policy"
    return "no_retry"
