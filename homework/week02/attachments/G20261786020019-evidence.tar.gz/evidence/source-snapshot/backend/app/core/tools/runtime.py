"""ToolRuntime：唯一执行入口（校验 → 执行 → 输出）。"""
import asyncio
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from app.core.tools.approval import ApprovalError, ApprovalStore, token_hash
from app.core.tools.audit import ToolAuditor
from app.core.tools.definition import HandlerOutput, ToolDefinition
from app.core.tools.enums import (
    ApprovalStatus,
    ErrorPhase,
    RiskLevel,
    ToolEffect,
    ToolErrorCategory,
    ToolExecutionStatus,
)
from app.core.tools.error_schema import build_tool_error_schema
from app.core.tools.errors import ToolCancelledError
from app.core.tools.redaction import (
    preview,
    redact_text,
    redact_value,
    stable_hash,
)
from app.core.tools.registry import ToolRegistry
from app.core.tools.result import ToolAuditRecord, ToolErrorInfo, ToolResultMessage
from app.core.tools.retry import (
    classify_exception,
    compute_delay,
    decide_retry,
    mark_retryable,
    possible_side_effect,
    retry_strategy_text,
)
from app.core.tools.session import (
    HandlerContext,
    ToolApprovalRequest,
    ToolCallRequest,
    ToolSession,
)
from app.core.tools.snapshot import SnapshotSelection, ToolRef, ToolSnapshot
from app.core.tools.validation import (
    CheckedCall,
    ValidationFailure,
    check,
    check_live,
)


def gen_tool_call_id() -> str:
    return f"call_{uuid.uuid4().hex[:24]}"


def gen_audit_id() -> str:
    return f"ta_{uuid.uuid4().hex[:24]}"


def gen_snapshot_id() -> str:
    return f"snap_{uuid.uuid4().hex[:24]}"


class ToolRuntime:
    """单例运行时：模型层只能拿到 ToolSnapshot，handler 只在这里被解析调用。"""

    def __init__(
        self,
        registry: ToolRegistry,
        auditor: ToolAuditor,
        logger,
        *,
        snapshot_ttl_seconds: int = 600,
        max_concurrency: int = 8,
        approval_store: ApprovalStore | None = None,
    ):
        self._registry = registry
        self._auditor = auditor
        self._logger = logger
        self._snapshot_ttl = snapshot_ttl_seconds
        self._global_sem = asyncio.Semaphore(max_concurrency)
        self._semaphores: dict[str, asyncio.Semaphore] = {}
        self._approval_store = approval_store

    @property
    def registry(self) -> ToolRegistry:
        return self._registry

    # ── 会话与快照 ──
    def open_session(self, *, task_id: str, trace_id: str, actor,
                     control, approval_gate, observer=None,
                     refresh_actor=None) -> ToolSession:
        return ToolSession(
            session_id=f"sess_{uuid.uuid4().hex[:16]}",
            task_id=task_id,
            trace_id=trace_id,
            actor=actor,
            control=control,
            approval_gate=approval_gate,
            observer=observer,
            idempotency_key=f"{trace_id}:{uuid.uuid4().hex[:12]}",
            refresh_actor=refresh_actor,
        )

    def build_snapshot(
        self,
        session: ToolSession,
        *,
        round: int,
        tool_names: list[str] | None = None,
    ) -> ToolSnapshot:
        state = self._registry.state()
        refs = self._registry.build_refs(
            names=tool_names,
            task_id=session.task_id,
            actor=session.actor,
            tenant_id=session.actor.tenant_id,
        )
        now = datetime.now(timezone.utc)
        return ToolSnapshot(
            snapshot_id=gen_snapshot_id(),
            task_id=session.task_id,
            trace_id=session.trace_id,
            round=round,
            registry_revision=state.revision,
            created_at=now,
            expires_at=now + timedelta(seconds=self._snapshot_ttl),
            refs=tuple(refs),
            selection=SnapshotSelection(
                requested_names=tuple(tool_names) if tool_names else None,
                actor_id=session.actor.actor_id,
                tenant_id=session.actor.tenant_id,
            ),
        )

    # ── 唯一执行入口 ──
    async def execute(
        self, snapshot: ToolSnapshot, call: ToolCallRequest, session: ToolSession
    ) -> ToolResultMessage:
        audit_id = gen_audit_id()
        started = time.perf_counter()
        approval_status = ApprovalStatus.NOT_REQUIRED
        checked: CheckedCall | None = None
        ref = snapshot.get(call.tool_name)
        idempotency_key: str | None = None
        retry_count = 0
        approval_meta: dict[str, Any] | None = None

        try:
            await session.control.checkpoint()
            # 快照前先刷新最新用户状态 / 权限 / 角色
            await session.refresh_identity()

            outcome = check(
                state=self._registry.state(),
                snapshot=snapshot,
                call=call,
                session=session,
            )
            if isinstance(outcome, ValidationFailure):
                session.dependencies.mark_failed(call.tool_name)
                return await self._finish(
                    snapshot=snapshot, call=call, session=session,
                    status=outcome.status, error=outcome.error,
                    audit_id=audit_id, started=started, ref=ref, checked=None,
                    approval_status=approval_status, retry_count=0,
                    possible_effect=None,
                )

            checked = outcome
            definition = checked.definition
            idempotency_key = self._make_idempotency_key(
                session, call, definition.governance.effect
            )

            # 审批门：通用能力，不限于危险工具
            if checked.approval_required:
                await session.refresh_identity()
                decision = await session.approval_gate.request(ToolApprovalRequest(
                    task_id=session.task_id,
                    step=call.round,
                    round=call.round,
                    tool_call_id=call.tool_call_id,
                    tool_name=ref.name,
                    tool_version=ref.version,
                    tool_args=call.arguments,
                    risk_level=ref.risk_level,
                    snapshot_id=snapshot.snapshot_id,
                    message=f"请确认是否执行 {ref.display_name or ref.name}",
                    trace_id=snapshot.trace_id,
                    fingerprint=ref.fingerprint,
                    args_hash=stable_hash(
                        checked.input_model.model_dump(mode="json")
                    ),
                    actor_id=session.actor.actor_id or "",
                    roles=session.actor.roles,
                    snapshot_expires_at=snapshot.expires_at,
                ))
                approval_status = decision.status
                approval_meta = {
                    "token": decision.token,
                    "requested_at": decision.requested_at,
                    "resolved_at": decision.decided_at,
                    "approved_by": decision.decided_by,
                    "comment": decision.comment,
                }
                if not decision.approved:
                    timed_out = decision.status == ApprovalStatus.TIMEOUT
                    status = (
                        ToolExecutionStatus.APPROVAL_TIMEOUT
                        if timed_out
                        else ToolExecutionStatus.APPROVAL_DENIED
                    )
                    error = ToolErrorInfo(
                        category=ToolErrorCategory.APPROVAL,
                        code=(
                            "APPROVAL_TIMEOUT" if timed_out else "APPROVAL_DENIED"
                        ),
                        message=decision.reason or "用户拒绝执行",
                        model_message=(
                            "审批等待超时，是否重新发起由用户决定"
                            if timed_out
                            else "用户未批准该工具调用"
                        ),
                        retryable=False,
                        phase=ErrorPhase.PRE_SIDE_EFFECT,
                    )
                    session.dependencies.mark_failed(call.tool_name)
                    if session.observer is not None:
                        await session.observer.on_rejected({
                            "tool_name": ref.name,
                            "tool_call_id": call.tool_call_id,
                            "reason": decision.reason,
                            "status": status.value,
                        })
                    return await self._finish(
                        snapshot=snapshot, call=call, session=session,
                        status=status, error=error, audit_id=audit_id,
                        started=started, ref=ref, checked=checked,
                        approval_status=approval_status, retry_count=0,
                        possible_effect=None, approval_meta=approval_meta,
                    )
                await session.control.checkpoint()

                # ── 审批后执行准入复核 ──
                await session.refresh_identity()
                recheck = check(
                    state=self._registry.state(), snapshot=snapshot,
                    call=call, session=session,
                )
                if isinstance(recheck, ValidationFailure):
                    session.dependencies.mark_failed(call.tool_name)
                    return await self._finish(
                        snapshot=snapshot, call=call, session=session,
                        status=recheck.status, error=recheck.error,
                        audit_id=audit_id, started=started, ref=ref,
                        checked=checked, approval_status=approval_status,
                        retry_count=0, possible_effect=None,
                        approval_meta=approval_meta,
                    )
                checked = recheck
                definition = checked.definition
                ref = checked.ref
                live = check_live(self._registry.state(), snapshot, ref)
                if live is not None:
                    session.dependencies.mark_failed(call.tool_name)
                    return await self._finish(
                        snapshot=snapshot, call=call, session=session,
                        status=live.status, error=live.error,
                        audit_id=audit_id, started=started, ref=ref,
                        checked=checked, approval_status=approval_status,
                        retry_count=0, possible_effect=None,
                        approval_meta=approval_meta,
                    )
                # 进入副作用前原子 consume；失败不得执行 handler
                if decision.token is not None and self._approval_store is not None:
                    try:
                        self._approval_store.consume(
                            decision.token, task_id=session.task_id,
                            tool_call_id=call.tool_call_id,
                        )
                    except ApprovalError as exc:
                        session.dependencies.mark_failed(call.tool_name)
                        error = ToolErrorInfo(
                            category=ToolErrorCategory.APPROVAL,
                            code=exc.code,
                            message=exc.message,
                            model_message="审批票据已失效，请重新发起调用",
                            retryable=False,
                            phase=ErrorPhase.PRE_SIDE_EFFECT,
                        )
                        status = (
                            ToolExecutionStatus.APPROVAL_TIMEOUT
                            if "EXPIRED" in exc.code
                            else ToolExecutionStatus.FAILED
                        )
                        return await self._finish(
                            snapshot=snapshot, call=call, session=session,
                            status=status, error=error, audit_id=audit_id,
                            started=started, ref=ref, checked=checked,
                            approval_status=approval_status,
                            retry_count=0, possible_effect=None,
                            approval_meta=approval_meta,
                        )
                await session.control.checkpoint()

            # 执行（含超时与分类重试）
            retry_holder = [0]
            try:
                execution_error, raw_output = await self._run_with_policy(
                    definition=definition, checked=checked, snapshot=snapshot,
                    call=call, session=session, audit_id=audit_id,
                    idempotency_key=idempotency_key,
                    retry_count_holder=retry_holder,
                )
            except _ExecutionRejected as rejected:
                session.dependencies.mark_failed(call.tool_name)
                return await self._finish(
                    snapshot=snapshot, call=call, session=session,
                    status=rejected.failure.status,
                    error=rejected.failure.error,
                    audit_id=audit_id, started=started, ref=ref,
                    checked=checked, approval_status=approval_status,
                    retry_count=retry_holder[0], possible_effect=None,
                    approval_meta=approval_meta,
                )
            retry_count = retry_holder[0]

            if execution_error is not None:
                session.dependencies.mark_failed(call.tool_name)
                return await self._finish(
                    snapshot=snapshot, call=call, session=session,
                    status=self._status_from_category(
                        execution_error, definition.governance.effect
                    ),
                    error=execution_error, audit_id=audit_id,
                    started=started, ref=ref, checked=checked,
                    approval_status=approval_status,
                    retry_count=retry_count,
                    possible_effect=possible_side_effect(
                        definition.governance.effect, execution_error
                    ),
                    approval_meta=approval_meta,
                )

            # 输出阶段
            try:
                data, summary, redaction_applied = self._validate_output(
                    definition=definition, raw_output=raw_output
                )
            except Exception as exc:
                error = ToolErrorInfo(
                    category=ToolErrorCategory.OUTPUT_SCHEMA,
                    code="1606",
                    message=f"工具输出校验失败: {exc}",
                    model_message="工具返回结果格式异常",
                    retryable=False,
                    phase=ErrorPhase.POST_SIDE_EFFECT,
                )
                return await self._finish(
                    snapshot=snapshot, call=call, session=session,
                    status=ToolExecutionStatus.OUTPUT_INVALID,
                    error=error, audit_id=audit_id, started=started,
                    ref=ref, checked=checked,
                    approval_status=approval_status,
                    retry_count=retry_count,
                    possible_effect=possible_side_effect(
                        definition.governance.effect, error
                    ),
                    approval_meta=approval_meta,
                )

            await session.control.checkpoint()
            session.dependencies.mark_completed(ref)
            result = ToolResultMessage(
                tool_call_id=call.tool_call_id,
                tool_name=ref.name,
                tool_version=ref.version,
                snapshot_id=snapshot.snapshot_id,
                audit_id=audit_id,
                status=ToolExecutionStatus.SUCCESS,
                success=True,
                data=data,
                summary=summary,
                error=None,
                error_info=None,
                duration_ms=int((time.perf_counter() - started) * 1000),
                retry_count=retry_count,
                redaction_applied=redaction_applied,
                possible_side_effect=False,
            )
            await self._audit(
                result=result, snapshot=snapshot, call=call, session=session,
                ref=ref, checked=checked, approval_status=approval_status,
                idempotency_key=idempotency_key, error=None,
                possible_effect=False, approval_meta=approval_meta,
            )
            return result

        except ToolCancelledError:
            error = ToolErrorInfo(
                category=ToolErrorCategory.CANCELLED,
                code="TOOL_CANCELLED",
                message="任务已取消，工具执行中断",
                model_message="任务已取消",
                retryable=False,
                phase=ErrorPhase.UNKNOWN,
            )
            await self._finish(
                snapshot=snapshot, call=call, session=session,
                status=ToolExecutionStatus.CANCELLED, error=error,
                audit_id=audit_id, started=started, ref=ref, checked=checked,
                approval_status=approval_status, retry_count=retry_count,
                possible_effect=None, approval_meta=approval_meta,
            )
            raise

    async def execute_batch(
        self, snapshot: ToolSnapshot, calls: list[ToolCallRequest],
        session: ToolSession,
    ) -> list[ToolResultMessage]:
        """批量执行：仅全部可并行且无需审批时并发，否则按顺序执行。"""
        refs = [snapshot.get(c.tool_name) for c in calls]
        can_parallel = all(
            ref is not None
            and ref.parallelizable
            and not ref.requires_confirmation
            and not ref.dependencies
            for ref in refs
        )
        if not can_parallel:
            return [await self.execute(snapshot, c, session) for c in calls]
        return list(await asyncio.gather(*(
            self.execute(snapshot, c, session) for c in calls
        )))

    # ── 执行 + 重试 ──
    async def _run_with_policy(
        self, *, definition: ToolDefinition, checked: CheckedCall,
        snapshot: ToolSnapshot, call: ToolCallRequest, session: ToolSession,
        audit_id: str, idempotency_key: str | None,
        retry_count_holder: list[int],
    ) -> tuple[ToolErrorInfo | None, Any]:
        gov = definition.governance
        total_deadline = time.monotonic() + (
            gov.total_timeout_seconds or gov.timeout_seconds * 4
        )
        semaphore = self._semaphore_for(definition)
        attempt = 0
        error: ToolErrorInfo | None = None

        while True:
            await session.control.checkpoint()
            await session.refresh_identity()
            self._check_still_valid(snapshot, checked.ref)

            remaining = total_deadline - time.monotonic()
            if remaining <= 0:
                retry_count_holder[0] = attempt
                return (
                    ToolErrorInfo(
                        category=ToolErrorCategory.TIMEOUT,
                        code="1608",
                        message=f"工具 {definition.name} 总超时",
                        model_message="工具执行超时",
                        retryable=False,
                        phase=ErrorPhase.UNKNOWN,
                    ),
                    None,
                )

            ctx = HandlerContext(
                tool_call_id=call.tool_call_id,
                task_id=session.task_id,
                trace_id=session.trace_id,
                attempt=attempt,
                idempotency_key=idempotency_key,
                deadline=total_deadline,
                actor_id=session.actor.actor_id,
                tenant_id=session.actor.tenant_id,
                request_id=audit_id,
                checkpoint=session.control.checkpoint,
            )
            per_attempt = min(gov.timeout_seconds, remaining)
            try:
                async with semaphore:
                    async with self._global_sem:
                        raw = await asyncio.wait_for(
                            definition.handler(checked.input_model, ctx),
                            timeout=per_attempt,
                        )
                return None, raw
            except ToolCancelledError:
                raise
            except Exception as exc:
                error = classify_exception(
                    exc, tool_name=definition.name, effect=gov.effect,
                )
                can_retry = decide_retry(
                    definition, error, attempt, idempotency_key,
                )
                mark_retryable(error, can_retry)
                retry_count_holder[0] = attempt
                if not can_retry:
                    error.retry_count = attempt
                    error.retry_strategy = retry_strategy_text(
                        error, attempt, gov.effect
                    )
                    return error, None

                delay = compute_delay(gov.retry_policy, attempt, error)
                if session.observer is not None:
                    await session.observer.on_retry({
                        "tool_name": definition.name,
                        "tool_call_id": call.tool_call_id,
                        "attempt": attempt + 1,
                        "category": error.category.value,
                        "delay": delay,
                        "audit_id": audit_id,
                    })
                self._logger.warning(
                    "tool_retry",
                    tool_name=definition.name,
                    tool_call_id=call.tool_call_id,
                    audit_id=audit_id,
                    attempt=attempt + 1,
                    category=error.category.value,
                    code=error.code,
                    delay=round(delay, 3),
                )
                attempt += 1
                retry_count_holder[0] = attempt
                await session.control.checkpoint()
                await asyncio.sleep(delay)

    def _check_still_valid(self, snapshot: ToolSnapshot, ref: ToolRef) -> None:
        live = check_live(self._registry.state(), snapshot, ref)
        if live is not None:
            raise _ExecutionRejected(live)

    def _semaphore_for(self, definition: ToolDefinition) -> asyncio.Semaphore:
        key = f"{definition.name}@{definition.version}"
        sem = self._semaphores.get(key)
        if sem is None:
            sem = asyncio.Semaphore(definition.governance.max_concurrency)
            self._semaphores[key] = sem
        return sem

    # ── 输出 ──
    def _validate_output(
        self, *, definition: ToolDefinition, raw_output: Any
    ) -> tuple[dict[str, Any], str, bool]:
        spec = definition.spec
        summary = ""
        if isinstance(raw_output, HandlerOutput):
            payload: Any = raw_output.data
            summary = raw_output.summary
        elif isinstance(raw_output, dict):
            payload = raw_output
        elif raw_output is None:
            payload = {}
        else:
            payload = raw_output

        if spec.output_model is not None:
            if isinstance(payload, spec.output_model):
                model = payload
            else:
                model = spec.output_model.model_validate(payload)
            data = model.model_dump(mode="json")
        elif hasattr(payload, "model_dump"):
            data = payload.model_dump(mode="json")
        elif isinstance(payload, dict):
            data = payload
        else:
            raise ValueError(f"handler 返回类型不合法: {type(payload).__name__}")

        extra = definition.governance.audit_policy.sensitive_fields
        data, applied = redact_value(data, extra=extra)
        if not summary:
            summary = f"{spec.display_name} 执行成功"
        summary = redact_text(summary, limit=300)
        return data, summary, applied

    # ── 结果收口与审计 ──
    async def _finish(
        self, *, snapshot: ToolSnapshot, call: ToolCallRequest,
        session: ToolSession, status: ToolExecutionStatus,
        error: ToolErrorInfo, audit_id: str, started: float,
        ref: ToolRef | None, checked: CheckedCall | None,
        approval_status: ApprovalStatus, retry_count: int,
        possible_effect: bool | None,
        approval_meta: dict[str, Any] | None = None,
    ) -> ToolResultMessage:
        definition = checked.definition if checked else None
        extra = (
            definition.governance.audit_policy.sensitive_fields
            if definition else frozenset()
        )
        redacted_args, redacted = redact_value(call.arguments, extra=extra)
        model_message = redact_text(error.model_message, limit=300)
        effect = (
            definition.governance.effect if definition
            else (ref.effect if ref else ToolEffect.READ_ONLY)
        )
        error_schema = build_tool_error_schema(
            code=error.code,
            category=error.category,
            phase=error.phase,
            model_message=model_message,
            retryable=error.retryable,
            effect=effect,
            possible_side_effect=bool(possible_effect),
            status=status,
            retry_after=error.retry_after,
        )
        result = ToolResultMessage(
            tool_call_id=call.tool_call_id,
            tool_name=call.tool_name,
            tool_version=ref.version if ref else "",
            snapshot_id=snapshot.snapshot_id,
            audit_id=audit_id,
            status=status,
            success=False,
            data={},
            summary=model_message,
            error=model_message,
            error_info=error,
            error_schema=error_schema,
            duration_ms=int((time.perf_counter() - started) * 1000),
            retry_count=retry_count,
            redaction_applied=redacted,
            possible_side_effect=bool(possible_effect),
        )
        await self._audit(
            result=result, snapshot=snapshot, call=call, session=session,
            ref=ref, checked=checked, approval_status=approval_status,
            idempotency_key=(
                f"{session.idempotency_key}:{call.tool_call_id}"
                if definition and definition.governance.effect
                != ToolEffect.READ_ONLY else None
            ),
            error=error, possible_effect=bool(possible_effect),
            approval_meta=approval_meta,
        )
        return result

    async def _audit(
        self, *, result: ToolResultMessage, snapshot: ToolSnapshot,
        call: ToolCallRequest, session: ToolSession, ref: ToolRef | None,
        checked: CheckedCall | None, approval_status: ApprovalStatus,
        idempotency_key: str | None, error: ToolErrorInfo | None,
        possible_effect: bool,
        approval_meta: dict[str, Any] | None = None,
    ) -> None:
        definition = checked.definition if checked else None
        extra = (
            definition.governance.audit_policy.sensitive_fields
            if definition else frozenset()
        )
        input_data, _ = redact_value(call.arguments, extra=extra)
        output_data, _ = redact_value(result.data, extra=extra)
        approval_meta = approval_meta or {}
        approval_token = approval_meta.get("token")
        record = ToolAuditRecord(
            audit_id=result.audit_id,
            trace_id=snapshot.trace_id,
            task_id=session.task_id,
            snapshot_id=snapshot.snapshot_id,
            registry_revision=snapshot.registry_revision,
            step=call.round,
            round=call.round,
            tool_call_id=call.tool_call_id,
            tool_name=call.tool_name,
            tool_version=ref.version if ref else "",
            actor_id=session.actor.actor_id,
            tenant_id=session.actor.tenant_id,
            permission_decision=(
                "denied"
                if result.status == ToolExecutionStatus.PERMISSION_DENIED
                else "granted"
            ),
            risk_level=ref.risk_level if ref else RiskLevel.MEDIUM,
            approval_status=approval_status,
            # 只落 token 摘要，不记录明文
            approval_token_hash=(
                token_hash(approval_token) if approval_token else None
            ),
            approval_requested_at=approval_meta.get("requested_at"),
            approval_resolved_at=approval_meta.get("resolved_at"),
            approved_by=approval_meta.get("approved_by"),
            approval_comment=approval_meta.get("comment"),
            effect=(
                definition.governance.effect if definition
                else (ref.effect if ref else ToolEffect.READ_ONLY)
            ),
            idempotency_key=idempotency_key,
            status=result.status,
            error_category=error.category if error else None,
            error_code=error.code if error else None,
            retry_count=result.retry_count,
            retry_strategy=error.retry_strategy if error else None,
            possible_side_effect=possible_effect,
            duration_ms=result.duration_ms,
            input_hash=stable_hash(call.arguments),
            input_preview=preview(input_data, 512),
            output_hash=stable_hash(result.data) if result.success else None,
            output_preview=preview(output_data, 512) if result.success else None,
            redaction_applied=result.redaction_applied,
            created_at=result.created_at,
        )
        await self._auditor.record(record)

    @staticmethod
    def _status_from_category(error: ToolErrorInfo, effect: ToolEffect) -> ToolExecutionStatus:
        mapping = {
            ToolErrorCategory.TIMEOUT: ToolExecutionStatus.TIMEOUT,
            ToolErrorCategory.CANCELLED: ToolExecutionStatus.CANCELLED,
            ToolErrorCategory.VALIDATION: ToolExecutionStatus.INVALID_INPUT,
            ToolErrorCategory.PERMISSION: ToolExecutionStatus.PERMISSION_DENIED,
            ToolErrorCategory.NOT_FOUND: ToolExecutionStatus.FAILED,
            ToolErrorCategory.KILL_SWITCH: ToolExecutionStatus.TOOL_DISABLED,
            ToolErrorCategory.VERSION_STALE: ToolExecutionStatus.VERSION_STALE,
            ToolErrorCategory.DEPENDENCY: ToolExecutionStatus.DEPENDENCY_NOT_MET,
            ToolErrorCategory.APPROVAL: ToolExecutionStatus.APPROVAL_DENIED,
            ToolErrorCategory.OUTPUT_SCHEMA: ToolExecutionStatus.OUTPUT_INVALID,
        }
        return mapping.get(error.category, ToolExecutionStatus.FAILED)

    @staticmethod
    def _make_idempotency_key(
        session: ToolSession, call: ToolCallRequest, effect: ToolEffect
    ) -> str | None:
        if effect == ToolEffect.READ_ONLY:
            return None
        return f"{session.idempotency_key}:{call.tool_call_id}"


class _ExecutionRejected(Exception):
    """执行中被实时状态拦截（kill switch / 版本禁用），由 runtime 转换为结果。"""

    def __init__(self, failure: ValidationFailure):
        self.failure = failure
