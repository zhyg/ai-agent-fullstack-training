"""MCP 客户端协议与 mock 实现。"""
import asyncio
from typing import Any, Protocol

from app.core.tools.enums import ErrorPhase, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError


class McpClient(Protocol):
    async def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]: ...


class MockMcpClient:
    """内存 mock MCP server：按工具名返回确定性结果，支持故障注入。"""

    def __init__(
        self,
        server_id: str,
        tool_names: list[str],
        *,
        fault_inject: dict[str, bool] | None = None,
    ):
        self.server_id = server_id
        self._tool_names = set(tool_names)
        self._fault = fault_inject or {"timeout": False, "network": False, "upstream": False}

    async def call_tool(
        self, name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        if self._fault.get("timeout"):
            raise asyncio.TimeoutError("injected mcp timeout")
        if self._fault.get("network"):
            raise ToolBusinessError(
                category=ToolErrorCategory.NETWORK,
                code="TOOL_NETWORK_ERROR",
                message=f"MCP {self.server_id} 连接失败",
                model_message="MCP 服务连接失败",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        if self._fault.get("upstream"):
            raise ToolBusinessError(
                category=ToolErrorCategory.UPSTREAM,
                code="TOOL_UPSTREAM_ERROR",
                message=f"MCP {self.server_id} 服务端错误",
                model_message="MCP 服务暂不可用",
                phase=ErrorPhase.UNKNOWN,
            )
        if name not in self._tool_names:
            raise ToolBusinessError(
                category=ToolErrorCategory.UPSTREAM,
                code="TOOL_UPSTREAM_ERROR",
                message=f"MCP 未注册工具: {name}",
                model_message="MCP 服务未提供该工具",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        if name == "query_inventory":
            sku = str(arguments.get("sku", ""))
            seed = sum(ord(ch) for ch in sku) % 50
            return {
                "sku": sku,
                "available": seed + 5,
                "warehouse": "WH-MOCK",
                "server": self.server_id,
            }
        return {"server": self.server_id, "tool": name, "echo": arguments}
