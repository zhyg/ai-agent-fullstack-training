"""数据库：aiosqlite 原生 SQL，开发用 SQLite（生产可替换 PostgreSQL）。"""
import asyncio
import json
from datetime import datetime, timezone

import aiosqlite


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


_SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    task_id TEXT PRIMARY KEY,
    trace_id TEXT NOT NULL,
    input TEXT NOT NULL,
    model_id TEXT NOT NULL,
    max_steps INTEGER NOT NULL,
    status TEXT NOT NULL,
    business_id TEXT,
    actor_id TEXT,
    current_step INTEGER NOT NULL DEFAULT 0,
    conversation_history TEXT NOT NULL DEFAULT '[]',
    executed_steps TEXT NOT NULL DEFAULT '[]',
    last_seq INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS task_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    seq INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    data TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(task_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_task_events_task ON task_events(task_id, seq);

CREATE TABLE IF NOT EXISTS llm_request_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    business_id TEXT,
    model_id TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    status TEXT NOT NULL,
    latency_ms INTEGER NOT NULL,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    retry_count INTEGER NOT NULL DEFAULT 0,
    error_type TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_request_logs_trace ON llm_request_logs(trace_id);
CREATE INDEX IF NOT EXISTS idx_request_logs_created ON llm_request_logs(created_at);

CREATE TABLE IF NOT EXISTS error_traces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    request_id TEXT,
    stage TEXT NOT NULL,
    error_type TEXT NOT NULL,
    message TEXT NOT NULL,
    stack_trace TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    strategy TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_error_traces_trace ON error_traces(trace_id);

CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    role TEXT NOT NULL DEFAULT 'member',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    permission TEXT NOT NULL,
    granted_by TEXT,
    created_at TEXT NOT NULL,
    UNIQUE(user_id, permission)
);
CREATE INDEX IF NOT EXISTS idx_user_permissions_user ON user_permissions(user_id);

CREATE TABLE IF NOT EXISTS tool_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_id TEXT NOT NULL UNIQUE,
    trace_id TEXT NOT NULL,
    task_id TEXT,
    snapshot_id TEXT NOT NULL,
    registry_revision INTEGER NOT NULL,
    step INTEGER NOT NULL,
    round INTEGER NOT NULL,
    tool_call_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    tool_version TEXT NOT NULL,
    actor_id TEXT,
    tenant_id TEXT,
    permission_decision TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    approval_status TEXT NOT NULL,
    approval_token_hash TEXT,
    approval_requested_at TEXT,
    approval_resolved_at TEXT,
    approved_by TEXT,
    approval_comment TEXT,
    effect TEXT NOT NULL,
    idempotency_key TEXT,
    status TEXT NOT NULL,
    error_category TEXT,
    error_code TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    retry_strategy TEXT,
    possible_side_effect INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    input_hash TEXT NOT NULL,
    input_preview TEXT,
    output_hash TEXT,
    output_preview TEXT,
    redaction_applied INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_trace ON tool_calls(trace_id);
CREATE INDEX IF NOT EXISTS idx_tool_calls_task ON tool_calls(task_id);
CREATE INDEX IF NOT EXISTS idx_tool_calls_tool ON tool_calls(tool_name, created_at);
"""


class Database:
    """SQLite 异步访问层：单连接 + 写锁串行化。"""

    def __init__(self, url: str):
        # 支持 sqlite:///path 与 sqlite:///:memory:
        self._path = url.removeprefix("sqlite:///")
        self._conn: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    async def init(self) -> None:
        from app.infra.migrations import run_migrations

        self._conn = await aiosqlite.connect(self._path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.executescript(_SCHEMA)
        await self._conn.commit()
        # 旧库补列 + 任务所有者回填；新库直接执行全部 migration
        await run_migrations(self._conn)
        await self._seed_default_users()

    async def _seed_default_users(self) -> None:
        """默认用户与权限种子：权限校验的唯一来源是这两张表。"""
        from app.config import settings

        now = _now()
        default_permissions = (
            "tool.use", "net.network", "email.send",
            "bill.query", "shopping.request", "shopping.approve",
            "order.create", "order.pay", "order.refund", "order.query",
        )
        guest_permissions = ("tool.use",)
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                "INSERT OR IGNORE INTO users (user_id, name, email, role, status, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (settings.default_user_id, "默认用户", "default@example.com",
                 "admin", "active", now),
            )
            await conn.execute(
                "INSERT OR IGNORE INTO users (user_id, name, email, role, status, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                ("user_guest", "受限访客", "guest@example.com", "guest", "active", now),
            )
            for permission in default_permissions:
                await conn.execute(
                    "INSERT OR IGNORE INTO user_permissions "
                    "(user_id, permission, granted_by, created_at) VALUES (?, ?, ?, ?)",
                    (settings.default_user_id, permission, "system", now),
                )
            for permission in guest_permissions:
                await conn.execute(
                    "INSERT OR IGNORE INTO user_permissions "
                    "(user_id, permission, granted_by, created_at) VALUES (?, ?, ?, ?)",
                    ("user_guest", permission, "system", now),
                )
            await conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    def _require_conn(self) -> aiosqlite.Connection:
        assert self._conn is not None, "Database 未初始化，请先调用 init()"
        return self._conn

    # ── 任务快照 ──
    async def upsert_task(self, task: dict) -> None:
        """持久化任务快照（task_id 为主键，存在则覆盖）。"""
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT OR REPLACE INTO tasks (
                    task_id, trace_id, input, model_id, max_steps, status,
                    business_id, actor_id, current_step, conversation_history,
                    executed_steps, last_seq, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    task["task_id"], task["trace_id"], task["input"],
                    task["model_id"], task["max_steps"], task["status"],
                    task.get("business_id"), task.get("actor_id"),
                    task.get("current_step", 0),
                    json.dumps(task.get("conversation_history", []), ensure_ascii=False),
                    json.dumps(task.get("executed_steps", []), ensure_ascii=False),
                    task.get("last_seq", 0),
                    task.get("created_at", _now()), _now(),
                ),
            )
            await conn.commit()

    async def get_task(self, task_id: str) -> dict | None:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT * FROM tasks WHERE task_id = ?", (task_id,)
        ) as cur:
            row = await cur.fetchone()
        if row is None:
            return None
        d = dict(row)
        d["conversation_history"] = json.loads(d["conversation_history"])
        d["executed_steps"] = json.loads(d["executed_steps"])
        return d

    async def fail_tasks_with_status(
        self, status: str, *, new_status: str = "failed"
    ) -> int:
        """批量状态迁移（重启恢复：WAITING_APPROVAL → FAILED）。"""
        conn = self._require_conn()
        async with self._write_lock:
            async with conn.execute(
                "SELECT task_id FROM tasks WHERE status = ?", (status,)
            ) as cur:
                rows = await cur.fetchall()
            if not rows:
                return 0
            await conn.execute(
                "UPDATE tasks SET status = ?, updated_at = ? WHERE status = ?",
                (new_status, _now(), status),
            )
            await conn.commit()
            return len(rows)

    # ── SSE 事件持久化 ──
    async def insert_event(self, task_id: str, seq: int, event_type: str, data_json: str) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT OR IGNORE INTO task_events (task_id, seq, event_type, data, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (task_id, seq, event_type, data_json, _now()),
            )
            await conn.commit()

    async def get_events(self, task_id: str, after_seq: int = 0) -> list[dict]:
        """按 seq 升序返回 task_id 下 seq > after_seq 的全部事件。"""
        conn = self._require_conn()
        async with conn.execute(
            "SELECT seq, event_type, data FROM task_events "
            "WHERE task_id = ? AND seq > ? ORDER BY seq ASC",
            (task_id, after_seq),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # ── 请求记录 ──
    async def insert_request_log(
        self,
        *,
        request_id: str,
        trace_id: str,
        business_id: str | None,
        model_id: str,
        endpoint: str,
        status: str,
        latency_ms: int,
        prompt_tokens: int,
        completion_tokens: int,
        total_tokens: int,
        retry_count: int,
        error_type: str | None,
        error_message: str | None,
    ) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT INTO llm_request_logs (
                    request_id, trace_id, business_id, model_id, endpoint,
                    status, latency_ms, prompt_tokens, completion_tokens,
                    total_tokens, retry_count, error_type, error_message, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    request_id, trace_id, business_id, model_id, endpoint,
                    status, latency_ms, prompt_tokens, completion_tokens,
                    total_tokens, retry_count, error_type, error_message, _now(),
                ),
            )
            await conn.commit()

    async def query_request_logs(self, query) -> tuple[int, list[dict]]:
        """分页查询请求记录，返回 (total, rows)。query 为 RequestLogQuery。"""
        conn = self._require_conn()
        conditions: list[str] = []
        params: list = []
        if query.trace_id:
            conditions.append("trace_id = ?")
            params.append(query.trace_id)
        if query.model_id:
            conditions.append("model_id = ?")
            params.append(query.model_id)
        if query.status:
            conditions.append("status = ?")
            params.append(query.status)
        if query.start_time:
            conditions.append("created_at >= ?")
            params.append(query.start_time)
        if query.end_time:
            conditions.append("created_at <= ?")
            params.append(query.end_time)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        async with conn.execute(
            f"SELECT COUNT(*) AS c FROM llm_request_logs {where}", params
        ) as cur:
            total = (await cur.fetchone())["c"]

        offset = (query.page - 1) * query.page_size
        async with conn.execute(
            f"SELECT * FROM llm_request_logs {where} "
            "ORDER BY id DESC LIMIT ? OFFSET ?",
            (*params, query.page_size, offset),
        ) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
        return total, rows

    # ── 用量统计 ──
    async def query_usage_stats(
        self, start_time: str | None = None, end_time: str | None = None
    ) -> dict:
        """按模型聚合调用次数、token、失败数与平均延迟。"""
        conn = self._require_conn()
        conditions: list[str] = []
        params: list = []
        if start_time:
            conditions.append("created_at >= ?")
            params.append(start_time)
        if end_time:
            conditions.append("created_at <= ?")
            params.append(end_time)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        totals_sql = (
            "SELECT COUNT(*) AS calls, "
            "COALESCE(SUM(prompt_tokens), 0) AS prompt_tokens, "
            "COALESCE(SUM(completion_tokens), 0) AS completion_tokens, "
            "COALESCE(SUM(total_tokens), 0) AS total_tokens, "
            "COALESCE(AVG(latency_ms), 0) AS avg_latency_ms, "
            "COALESCE(SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END), 0) AS failed_calls "
            f"FROM llm_request_logs {where}"
        )
        async with conn.execute(totals_sql, params) as cur:
            totals = dict(await cur.fetchone())

        models_sql = (
            "SELECT model_id, COUNT(*) AS calls, "
            "COALESCE(SUM(prompt_tokens), 0) AS prompt_tokens, "
            "COALESCE(SUM(completion_tokens), 0) AS completion_tokens, "
            "COALESCE(SUM(total_tokens), 0) AS total_tokens, "
            "COALESCE(AVG(latency_ms), 0) AS avg_latency_ms, "
            "COALESCE(SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END), 0) AS failed_calls "
            f"FROM llm_request_logs {where} GROUP BY model_id ORDER BY total_tokens DESC"
        )
        async with conn.execute(models_sql, params) as cur:
            models = [dict(r) for r in await cur.fetchall()]

        totals["avg_latency_ms"] = int(totals.get("avg_latency_ms") or 0)
        for item in models:
            item["avg_latency_ms"] = int(item.get("avg_latency_ms") or 0)
        return {"totals": totals, "models": models}

    # ── 异常链路 ──
    async def insert_error_trace(
        self,
        *,
        trace_id: str,
        request_id: str | None,
        stage: str,
        error_type: str,
        message: str,
        stack_trace: str | None,
        retry_count: int,
        strategy: str | None,
    ) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT INTO error_traces (
                    trace_id, request_id, stage, error_type, message,
                    stack_trace, retry_count, strategy, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trace_id, request_id, stage, error_type, message,
                    stack_trace, retry_count, strategy, _now(),
                ),
            )
            await conn.commit()

    async def get_error_traces(self, trace_id: str) -> list[dict]:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT * FROM error_traces WHERE trace_id = ? ORDER BY id ASC",
            (trace_id,),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # ── 用户与权限 ──
    async def get_user(self, user_id: str) -> dict | None:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def get_user_permissions(self, user_id: str) -> list[str]:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT permission FROM user_permissions WHERE user_id = ? ORDER BY permission",
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
        return [r["permission"] for r in rows]

    async def list_users(self) -> list[dict]:
        conn = self._require_conn()
        async with conn.execute(
            "SELECT * FROM users ORDER BY created_at ASC"
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]

    async def grant_user_permission(
        self, user_id: str, permission: str, granted_by: str | None = None
    ) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                "INSERT OR IGNORE INTO user_permissions "
                "(user_id, permission, granted_by, created_at) VALUES (?, ?, ?, ?)",
                (user_id, permission, granted_by, _now()),
            )
            await conn.commit()

    async def revoke_user_permission(self, user_id: str, permission: str) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                "DELETE FROM user_permissions WHERE user_id = ? AND permission = ?",
                (user_id, permission),
            )
            await conn.commit()

    # ── 工具审计 ──
    async def insert_tool_audit(self, record: dict) -> None:
        conn = self._require_conn()
        async with self._write_lock:
            await conn.execute(
                """
                INSERT OR IGNORE INTO tool_calls (
                    audit_id, trace_id, task_id, snapshot_id, registry_revision,
                    step, round, tool_call_id, tool_name, tool_version,
                    actor_id, tenant_id, permission_decision, risk_level,
                    approval_status, approval_token_hash, approval_requested_at,
                    approval_resolved_at, approved_by, approval_comment,
                    effect, idempotency_key, status,
                    error_category, error_code, retry_count, retry_strategy,
                    possible_side_effect, duration_ms, input_hash, input_preview,
                    output_hash, output_preview, redaction_applied, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record["audit_id"], record["trace_id"], record.get("task_id"),
                    record["snapshot_id"], record["registry_revision"],
                    record["step"], record["round"], record["tool_call_id"],
                    record["tool_name"], record["tool_version"],
                    record.get("actor_id"), record.get("tenant_id"),
                    record.get("permission_decision", "granted"),
                    record["risk_level"], record.get("approval_status", "not_required"),
                    record.get("approval_token_hash"),
                    record.get("approval_requested_at"),
                    record.get("approval_resolved_at"),
                    record.get("approved_by"),
                    record.get("approval_comment"),
                    record.get("effect", "read_only"), record.get("idempotency_key"),
                    record["status"], record.get("error_category"),
                    record.get("error_code"), record.get("retry_count", 0),
                    record.get("retry_strategy"),
                    1 if record.get("possible_side_effect") else 0,
                    record.get("duration_ms", 0), record["input_hash"],
                    record.get("input_preview"), record.get("output_hash"),
                    record.get("output_preview"),
                    1 if record.get("redaction_applied") else 0,
                    record.get("created_at") or _now(),
                ),
            )
            await conn.commit()

    async def query_tool_calls(
        self, *, trace_id: str | None = None, task_id: str | None = None,
        tool_name: str | None = None, limit: int = 50,
    ) -> list[dict]:
        conn = self._require_conn()
        conditions: list[str] = []
        params: list = []
        if trace_id:
            conditions.append("trace_id = ?")
            params.append(trace_id)
        if task_id:
            conditions.append("task_id = ?")
            params.append(task_id)
        if tool_name:
            conditions.append("tool_name = ?")
            params.append(tool_name)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        async with conn.execute(
            f"SELECT * FROM tool_calls {where} ORDER BY id DESC LIMIT ?",
            (*params, limit),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]
