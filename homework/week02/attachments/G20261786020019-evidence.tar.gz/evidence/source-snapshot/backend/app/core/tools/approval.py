"""审批票据：唯一码、TTL、归属校验、单次消费与取消唤醒。

设计约束：
- `issue / resolve / consume / revoke_task / sweep_expired` 均为无 await 的同步状态迁移，
  只有 `wait()` 挂起；不得在状态检查与修改之间引入异步等待。
- token 明文只存在于进程内存票据、SSE/前端与确认请求中；审计与持久化只保存 hash。
"""
import asyncio
import hashlib
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Awaitable

from app.core.tools.enums import (
    ApprovalStatus,
    ApprovalTicketStatus,
    RiskLevel,
)
from app.core.tools.errors import ToolCancelledError
from app.core.tools.redaction import preview, redact_value
from app.core.tools.session import ApprovalDecision, ToolApprovalRequest


class ApprovalError(Exception):
    """审批状态冲突 / 非法 token。"""

    def __init__(self, code: str, message: str, http_status: int = 409):
        self.code = code
        self.message = message
        self.http_status = http_status
        super().__init__(message)


def token_hash(token: str) -> str:
    """审计与持久化使用的 token 摘要。"""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ApprovalTicket:
    token: str
    task_id: str
    trace_id: str
    snapshot_id: str
    tool_call_id: str
    tool_name: str
    tool_version: str
    fingerprint: str
    arguments: dict[str, Any]
    args_hash: str
    actor_id: str
    roles: frozenset[str]
    risk_level: RiskLevel
    round: int
    created_at: datetime
    expires_at: datetime


@dataclass(frozen=True)
class ApprovalResolution:
    """确认接口与等待方使用的安全返回对象，不包含 token。"""

    task_id: str
    tool_call_id: str
    tool_name: str
    tool_version: str
    status: ApprovalTicketStatus
    decided_by: str | None = None
    decided_at: datetime | None = None
    comment: str | None = None
    expires_at: datetime | None = None


@dataclass
class _TicketRecord:
    ticket: ApprovalTicket
    status: ApprovalTicketStatus = ApprovalTicketStatus.PENDING
    decided_by: str | None = None
    decided_at: datetime | None = None
    comment: str | None = None
    event: asyncio.Event = field(default_factory=asyncio.Event)


class ApprovalStore:
    """进程内票据表；所有状态迁移同步完成，wait 负责挂起。"""

    def __init__(self, *, clock: Callable[[], datetime] | None = None):
        self._records: dict[str, _TicketRecord] = {}
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    # ── 签发 ──
    def issue(
        self, request: ToolApprovalRequest, *, ttl_seconds: float
    ) -> ApprovalTicket:
        if ttl_seconds <= 0:
            raise ApprovalError("APPROVAL_TTL_INVALID", "审批有效期必须大于 0", 500)
        now = self._clock()
        snapshot_expires = request.snapshot_expires_at
        if snapshot_expires is not None and now > snapshot_expires:
            raise ApprovalError(
                "APPROVAL_SNAPSHOT_EXPIRED", "工具快照已过期，无法签发票据", 409
            )
        expires_at = now + timedelta(seconds=ttl_seconds)
        if snapshot_expires is not None and snapshot_expires < expires_at:
            expires_at = snapshot_expires

        token = self._new_token()
        ticket = ApprovalTicket(
            token=token,
            task_id=request.task_id,
            trace_id=request.trace_id,
            snapshot_id=request.snapshot_id,
            tool_call_id=request.tool_call_id,
            tool_name=request.tool_name,
            tool_version=request.tool_version,
            fingerprint=request.fingerprint,
            arguments=dict(request.tool_args),
            args_hash=request.args_hash,
            actor_id=request.actor_id,
            roles=frozenset(request.roles),
            risk_level=request.risk_level,
            round=request.round,
            created_at=now,
            expires_at=expires_at,
        )
        self._records[token] = _TicketRecord(ticket=ticket)
        return ticket

    def _new_token(self) -> str:
        while True:
            token = "apr_" + secrets.token_urlsafe(32)
            if token not in self._records:
                return token

    # ── 等待 ──
    async def wait(self, token: str) -> ApprovalResolution:
        record = self._records.get(token)
        if record is None:
            raise ApprovalError("APPROVAL_TOKEN_INVALID", "审批票据不存在", 400)

        remaining = (record.ticket.expires_at - self._clock()).total_seconds()
        if remaining > 0 and record.status in (
            ApprovalTicketStatus.PENDING,
            ApprovalTicketStatus.APPROVED,
        ):
            try:
                await asyncio.wait_for(record.event.wait(), timeout=remaining)
            except asyncio.TimeoutError:
                pass
        # 超时仍未决策则置 EXPIRED（同步迁移）
        if record.status in (
            ApprovalTicketStatus.PENDING,
            ApprovalTicketStatus.APPROVED,
        ) and self._clock() >= record.ticket.expires_at:
            record.status = ApprovalTicketStatus.EXPIRED
            record.decided_at = record.ticket.expires_at
            record.event.set()
        return _resolution(record)

    # ── 确认 / 消费 / 取消 / 清扫（全部同步）──
    def resolve(
        self,
        token: str,
        *,
        task_id: str,
        actor_id: str | None,
        approved: bool,
        comment: str | None = None,
    ) -> ApprovalResolution:
        record = self._records.get(token)
        if record is None:
            raise ApprovalError("APPROVAL_TOKEN_INVALID", "审批票据不存在", 400)
        ticket = record.ticket
        if ticket.task_id != task_id:
            raise ApprovalError("APPROVAL_TOKEN_INVALID", "审批票据不属于该任务", 400)
        if actor_id is None or ticket.actor_id != actor_id:
            raise ApprovalError("APPROVAL_TOKEN_INVALID", "审批票据不属于当前用户", 403)
        if record.status != ApprovalTicketStatus.PENDING:
            raise _status_conflict(record.status)
        now = self._clock()
        if now >= ticket.expires_at:
            record.status = ApprovalTicketStatus.EXPIRED
            record.decided_at = ticket.expires_at
            record.event.set()
            raise ApprovalError("APPROVAL_TOKEN_EXPIRED", "审批票据已过期", 409)

        record.status = (
            ApprovalTicketStatus.APPROVED if approved else ApprovalTicketStatus.DENIED
        )
        record.decided_by = actor_id
        record.decided_at = now
        record.comment = comment
        record.event.set()
        return _resolution(record)

    def consume(self, token: str, *, task_id: str, tool_call_id: str) -> ApprovalTicket:
        record = self._records.get(token)
        if record is None:
            raise ApprovalError("APPROVAL_TOKEN_INVALID", "审批票据不存在", 400)
        ticket = record.ticket
        if ticket.task_id != task_id or ticket.tool_call_id != tool_call_id:
            raise ApprovalError("APPROVAL_TOKEN_INVALID", "审批票据与调用不匹配", 400)
        if self._clock() >= ticket.expires_at:
            record.status = ApprovalTicketStatus.EXPIRED
            record.decided_at = ticket.expires_at
            record.event.set()
            raise ApprovalError("APPROVAL_TOKEN_EXPIRED", "审批票据已过期", 409)
        if record.status == ApprovalTicketStatus.CONSUMED:
            raise ApprovalError("APPROVAL_TOKEN_CONSUMED", "审批票据已被消费", 409)
        if record.status != ApprovalTicketStatus.APPROVED:
            raise _status_conflict(record.status)
        record.status = ApprovalTicketStatus.CONSUMED
        record.event.set()
        return ticket

    def revoke_task(self, task_id: str, *, reason: str = "task_cancelled") -> int:
        count = 0
        now = self._clock()
        for record in self._records.values():
            if record.ticket.task_id != task_id:
                continue
            if record.status in (
                ApprovalTicketStatus.PENDING,
                ApprovalTicketStatus.APPROVED,
            ):
                record.status = ApprovalTicketStatus.CANCELLED
                record.decided_at = now
                record.comment = reason
                record.event.set()
                count += 1
        return count

    def sweep_expired(self, now: datetime) -> int:
        count = 0
        for record in self._records.values():
            if record.status in (
                ApprovalTicketStatus.PENDING,
                ApprovalTicketStatus.APPROVED,
            ) and now >= record.ticket.expires_at:
                record.status = ApprovalTicketStatus.EXPIRED
                record.decided_at = record.ticket.expires_at
                record.event.set()
                count += 1
        return count

    def get(self, token: str) -> ApprovalTicket | None:
        record = self._records.get(token)
        return record.ticket if record else None

    def status_of(self, token: str) -> ApprovalTicketStatus | None:
        record = self._records.get(token)
        return record.status if record else None

    def pending_count(self) -> int:
        return sum(
            1
            for r in self._records.values()
            if r.status in (ApprovalTicketStatus.PENDING, ApprovalTicketStatus.APPROVED)
        )


def _resolution(record: _TicketRecord) -> ApprovalResolution:
    ticket = record.ticket
    return ApprovalResolution(
        task_id=ticket.task_id,
        tool_call_id=ticket.tool_call_id,
        tool_name=ticket.tool_name,
        tool_version=ticket.tool_version,
        status=record.status,
        decided_by=record.decided_by,
        decided_at=record.decided_at,
        comment=record.comment,
        expires_at=ticket.expires_at,
    )


def _status_conflict(status: ApprovalTicketStatus) -> ApprovalError:
    mapping = {
        ApprovalTicketStatus.APPROVED: "APPROVAL_STATE_CONFLICT",
        ApprovalTicketStatus.DENIED: "APPROVAL_STATE_CONFLICT",
        ApprovalTicketStatus.CONSUMED: "APPROVAL_TOKEN_CONSUMED",
        ApprovalTicketStatus.EXPIRED: "APPROVAL_TOKEN_EXPIRED",
        ApprovalTicketStatus.CANCELLED: "APPROVAL_STATE_CONFLICT",
    }
    code = mapping.get(status, "APPROVAL_STATE_CONFLICT")
    return ApprovalError(code, f"审批票据状态不可重复操作: {status.value}", 409)


EmitApprovalEvent = Callable[[dict, dict], Awaitable[None]]


class TicketApprovalGate:
    """AgentLoop 使用的票据审批门：签发 → 发布事件 → 挂起等待 → 决策。"""

    def __init__(
        self,
        store: ApprovalStore,
        *,
        ttl_seconds: float,
        emit: EmitApprovalEvent,
        set_waiting: Callable[[], Awaitable[None]],
        set_running: Callable[[], Awaitable[None]],
    ):
        self._store = store
        self._ttl = ttl_seconds
        self._emit = emit
        self._set_waiting = set_waiting
        self._set_running = set_running

    async def request(self, req: ToolApprovalRequest) -> ApprovalDecision:
        ticket = self._store.issue(req, ttl_seconds=self._ttl)
        redacted_args, _ = redact_value(req.tool_args)
        args_preview = _preview_dict(redacted_args)
        sse_data = {
            "step": req.round,
            "tool_name": req.tool_name,
            "tool_args": redacted_args,
            "message": req.message,
            "tool_call_id": req.tool_call_id,
            "tool_version": req.tool_version,
            "risk_level": req.risk_level.value,
            "approval_token": ticket.token,
            "expires_at": ticket.expires_at.isoformat(),
            "snapshot_id": req.snapshot_id,
            "args_preview": args_preview,
        }
        persist_data = {
            **{k: v for k, v in sse_data.items() if k != "approval_token"},
            "approval_token_hash": token_hash(ticket.token),
        }
        await self._emit(sse_data, persist_data)
        await self._set_waiting()
        try:
            resolution = await self._store.wait(ticket.token)
        finally:
            await self._set_running()

        if resolution.status == ApprovalTicketStatus.CANCELLED:
            raise ToolCancelledError("任务已取消，审批等待中止")
        if resolution.status == ApprovalTicketStatus.APPROVED:
            return ApprovalDecision(
                approved=True,
                status=ApprovalStatus.APPROVED,
                token=ticket.token,
                decided_by=resolution.decided_by,
                decided_at=resolution.decided_at,
                comment=resolution.comment,
                requested_at=ticket.created_at,
            )
        if resolution.status == ApprovalTicketStatus.DENIED:
            return ApprovalDecision(
                approved=False,
                status=ApprovalStatus.DENIED,
                reason="用户拒绝执行",
                token=ticket.token,
                decided_by=resolution.decided_by,
                decided_at=resolution.decided_at,
                comment=resolution.comment,
                requested_at=ticket.created_at,
            )
        return ApprovalDecision(
            approved=False,
            status=ApprovalStatus.TIMEOUT,
            reason="审批等待超时",
            token=ticket.token,
            requested_at=ticket.created_at,
        )


def _preview_dict(value: Any, limit: int = 1000) -> dict[str, Any]:
    """审批参数预览：先脱敏再限制长度，保持 dict 结构。"""
    if not isinstance(value, dict):
        return {}
    trimmed: dict[str, Any] = {}
    for key, item in value.items():
        if isinstance(item, str) and len(item) > limit:
            trimmed[key] = item[:limit] + "…(truncated)"
        else:
            trimmed[key] = item
    raw = preview(trimmed, limit)
    if len(raw) >= limit:
        return {"_preview": raw}
    return trimmed
