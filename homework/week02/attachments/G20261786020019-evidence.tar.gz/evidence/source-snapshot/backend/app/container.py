"""依赖容器：全局单例，负责启动初始化与关闭清理。"""
import asyncio
from datetime import datetime, timezone

from app.config import settings, validate_sensitive_config
from app.core.orchestrator import Orchestrator
from app.core.prompt.renderer import get_prompt_manager
from app.core.tools.approval import ApprovalStore
from app.core.tools.audit import ToolAuditor
from app.core.tools.catalog import build_default_registry
from app.core.tools.plugin import PluginManager
from app.core.tools.registry import ToolRegistry
from app.core.tools.runtime import ToolRuntime
from app.infra.db import Database
from app.infra.logger import get_logger
from app.llm.adapter.anthropic_adapter import AnthropicAdapter
from app.llm.adapter.base import BaseLLMAdapter
from app.llm.adapter.openai_adapter import DeepSeekAdapter, OllamaAdapter, OpenAIAdapter
from app.llm.gateway import LLMGateway
from app.llm.retry import RetryConfig
from app.llm.routing import SceneRouter
from app.services.event_buffer import EventBuffer
from app.services.permission_service import PermissionService
from app.services.run_service import RunService
from app.services.task_service import TaskService


class Container:
    """组装各层依赖：配置校验 → DB → 适配器 → Gateway → 服务 → 编排器。"""

    def __init__(self) -> None:
        self.db: Database | None = None
        self.gateway: LLMGateway | None = None
        self.router: SceneRouter | None = None
        self.prompt_manager = get_prompt_manager()
        self.event_buffer: EventBuffer | None = None
        self.task_service: TaskService | None = None
        self.run_service = RunService()
        self.orchestrator: Orchestrator | None = None
        self.tool_registry: ToolRegistry | None = None
        self.tool_runtime: ToolRuntime | None = None
        self.approval_store: ApprovalStore | None = None
        self.plugin_manager: PluginManager | None = None
        self.permission_service: PermissionService | None = None
        self._sweeper: asyncio.Task | None = None
        self.logger = get_logger("agent")

    async def startup(self) -> None:
        # ① 敏感配置校验，缺失则终止
        validate_sensitive_config(settings)

        # ② 数据库初始化
        self.db = Database(settings.database_url)
        await self.db.init()

        # ③ 提示词配置与场景路由（文件缺失时安全降级）
        try:
            self.prompt_manager.load()
        except Exception as e:  # 配置错误不阻塞启动，回退内置模板
            self.logger.warning("prompt_config_load_failed", error=str(e))
        self.router = SceneRouter(
            settings.llm_routing_path, settings.default_model, settings.default_scene
        )
        try:
            self.router.load()
        except Exception as e:
            self.logger.warning("routing_config_load_failed", error=str(e))

        # ④ 构建供应商适配器（openai 必有，其余按 Key 配置）
        retry_config = RetryConfig(
            max_retries=settings.llm_max_retries,
            base_delay=settings.llm_base_delay,
        )
        timeout = settings.llm_timeout_seconds
        adapters: dict[str, BaseLLMAdapter] = {
            "openai": OpenAIAdapter(
                api_key=settings.openai_api_key,
                base_url=settings.openai_base_url,
                retry_config=retry_config,
                timeout=timeout,
            ),
        }
        if settings.anthropic_api_key:
            adapters["anthropic"] = AnthropicAdapter(
                api_key=settings.anthropic_api_key,
                base_url=settings.anthropic_base_url,
                retry_config=retry_config,
                timeout=timeout,
            )
        if settings.deepseek_api_key:
            adapters["deepseek"] = DeepSeekAdapter(
                api_key=settings.deepseek_api_key,
                base_url=settings.deepseek_base_url,
                retry_config=retry_config,
                timeout=timeout,
            )
        if settings.ollama_base_url:
            adapters["ollama"] = OllamaAdapter(
                base_url=settings.ollama_base_url,
                api_key=settings.ollama_api_key,
                retry_config=retry_config,
                timeout=timeout,
            )

        # ⑤ Gateway / 服务 / 编排器
        self.gateway = LLMGateway(
            adapters, self.db, self.logger,
            router=self.router, timeout_seconds=timeout,
        )
        self.event_buffer = EventBuffer(self.db)
        self.task_service = TaskService(self.db)
        self.run_service = RunService()
        self.event_buffer.set_active_probe(
            lambda task_id: self.task_service.get(task_id) is not None
        )

        # ⑥ Tool Runtime：注册表 + 审计 + 权限服务
        self.permission_service = PermissionService(self.db)
        self.tool_registry = build_default_registry(
            settings.tool_config_path, actor="system",
            mcp_config_path=settings.mcp_config_path,
            logger=self.logger,
        )
        self.approval_store = ApprovalStore()
        self.tool_runtime = ToolRuntime(
            self.tool_registry,
            ToolAuditor(self.db, self.logger, enabled=settings.tool_audit_enabled),
            self.logger,
            snapshot_ttl_seconds=settings.tool_snapshot_ttl_seconds,
            approval_store=self.approval_store,
        )
        self.plugin_manager = PluginManager(self.tool_registry, self.logger)
        self.orchestrator = Orchestrator(
            self.gateway, self.task_service, self.event_buffer, self.logger,
            tool_runtime=self.tool_runtime,
            permission_service=self.permission_service,
            approval_store=self.approval_store,
            approval_ttl_seconds=settings.approval_ttl_seconds,
        )

        # ⑦ 重启恢复：内存票据已丢失，等待审批的任务统一失败
        failed = await self.db.fail_tasks_with_status("waiting_approval")
        if failed:
            self.logger.warning(
                "waiting_approval_tasks_failed_on_restart", count=failed,
            )
        self._sweeper = asyncio.create_task(self._sweep_approvals())
        self.logger.info(
            "container_started",
            providers=list(adapters.keys()),
            default_model=settings.default_model,
            default_scene=settings.default_scene,
            tool_registry_revision=self.tool_registry.revision,
            tool_runtime_enabled=settings.tool_runtime_enabled,
        )

    async def _sweep_approvals(self) -> None:
        """定时清扫过期票据；票据 wait 自身也有超时兜底。"""
        while True:
            await asyncio.sleep(settings.approval_sweep_interval_seconds)
            if self.approval_store is None:
                continue
            expired = self.approval_store.sweep_expired(
                datetime.now(timezone.utc)
            )
            if expired:
                self.logger.info("approval_tickets_swept", count=expired)

    async def shutdown(self) -> None:
        if self._sweeper is not None:
            self._sweeper.cancel()
            try:
                await self._sweeper
            except asyncio.CancelledError:
                pass
            self._sweeper = None
        if self.gateway is not None:
            await self.gateway.aclose()
        if self.db is not None:
            await self.db.close()
        self.logger.info("container_shutdown")


# 全局单例
container = Container()
