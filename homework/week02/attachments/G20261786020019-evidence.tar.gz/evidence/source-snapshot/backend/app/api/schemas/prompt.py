"""Prompt 配置查看接口 Schema。"""
from pydantic import BaseModel, Field


class PromptSceneSummary(BaseModel):
    name: str
    description: str = ""
    active: str
    versions: list[str] = Field(default_factory=list)
    templates: list[str] = Field(default_factory=list)


class PromptSummary(BaseModel):
    path: str
    version: str
    scenes: list[PromptSceneSummary] = Field(default_factory=list)


class PromptSceneDetail(BaseModel):
    scene: str
    version: str
    active: bool
    description: str = ""
    versions: list[str] = Field(default_factory=list)
    templates: dict[str, str] = Field(default_factory=dict)


class PromptReloadResponse(BaseModel):
    reloaded: bool
    summary: PromptSummary
