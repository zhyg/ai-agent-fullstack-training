"""校验阶段：快照一致性 + 注册表实时状态 + 权限 + 依赖 + 入参 schema。"""
from dataclasses import dataclass
from datetime import datetime, timezone

from pydantic import BaseModel, ValidationError

from app.core.tools.definition import ToolDefinition
from app.core.tools.enums import ErrorPhase, ToolErrorCategory, ToolExecutionStatus
from app.core.tools.registry import RegistryState
from app.core.tools.session import ToolCallRequest, ToolSession
from app.core.tools.snapshot import ToolRef, ToolSnapshot
from app.core.tools.result import ToolErrorInfo


@dataclass(frozen=True)
class ValidationFailure:
    status: ToolExecutionStatus
    error: ToolErrorInfo


@dataclass(frozen=True)
class CheckedCall:
    definition: ToolDefinition
    ref: ToolRef
    input_model: BaseModel
    approval_required: bool


def failure(
    *,
    status: ToolExecutionStatus,
    category: ToolErrorCategory,
    code: str,
    message: str,
    model_message: str,
    phase: ErrorPhase = ErrorPhase.UNKNOWN,
) -> ValidationFailure:
    return ValidationFailure(
        status=status,
        error=ToolErrorInfo(
            category=category,
            code=code,
            message=message,
            model_message=model_message,
            retryable=False,
            phase=phase,
        ),
    )


def check(
    *,
    state: RegistryState,
    snapshot: ToolSnapshot,
    call: ToolCallRequest,
    session: ToolSession,
    now: datetime | None = None,
) -> CheckedCall | ValidationFailure:
    now = now or datetime.now(timezone.utc)

    if snapshot.task_id != session.task_id:
        return failure(
            status=ToolExecutionStatus.FAILED,
            category=ToolErrorCategory.INTERNAL,
            code="TOOL_SNAPSHOT_MISMATCH",
            message="快照与任务不匹配",
            model_message="工具快照与当前任务不匹配",
        )

    if snapshot.is_expired(now):
        return failure(
            status=ToolExecutionStatus.SNAPSHOT_EXPIRED,
            category=ToolErrorCategory.VERSION_STALE,
            code="TOOL_SNAPSHOT_EXPIRED",
            message=f"快照已过期: {snapshot.snapshot_id}",
            model_message="本轮工具快照已过期，请重新发起调用",
        )

    ref = snapshot.get(call.tool_name)
    if ref is None:
        return failure(
            status=ToolExecutionStatus.FAILED,
            category=ToolErrorCategory.NOT_FOUND,
            code="1600",
            message=f"工具不在本轮快照中: {call.tool_name}",
            model_message=f"工具不可用: {call.tool_name}",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    live_failure = check_live(state, snapshot, ref)
    if live_failure is not None:
        return live_failure

    entry = state.tools[ref.name]
    record = entry.versions[ref.version]
    definition = record.definition

    # 权限与角色以执行时的实时定义为准（覆盖快照后降权竞态）
    missing_permissions = (
        definition.governance.permissions - session.actor.granted_permissions
    )
    if missing_permissions:
        codes = ", ".join(sorted(p.value for p in missing_permissions))
        return failure(
            status=ToolExecutionStatus.PERMISSION_DENIED,
            category=ToolErrorCategory.PERMISSION,
            code="PERMISSION_DENIED",
            message=f"缺少权限: {codes}",
            model_message="当前用户无权调用该工具",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    role_failure = _check_roles(definition, session)
    if role_failure is not None:
        return role_failure

    for dep in definition.governance.dependencies:
        if not session.dependencies.is_satisfied(dep):
            return failure(
                status=ToolExecutionStatus.DEPENDENCY_NOT_MET,
                category=ToolErrorCategory.DEPENDENCY,
                code="TOOL_DEPENDENCY_NOT_MET",
                message=f"依赖未满足: {dep.tool_name}",
                model_message=f"请先成功调用依赖工具: {dep.tool_name}",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )

    try:
        input_model = definition.spec.input_model.model_validate(call.arguments)
    except ValidationError as exc:
        detail = "; ".join(
            f"{'.'.join(str(p) for p in err['loc'])}: {err['msg']}"
            for err in exc.errors()[:5]
        )
        return failure(
            status=ToolExecutionStatus.INVALID_INPUT,
            category=ToolErrorCategory.VALIDATION,
            code="1602",
            message=f"参数校验失败: {detail}",
            model_message=f"工具参数不合法: {detail}",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    return CheckedCall(
        definition=definition,
        ref=ref,
        input_model=input_model,
        approval_required=definition.governance.needs_approval,
    )


def check_live(
    state: RegistryState,
    snapshot: ToolSnapshot,
    ref: ToolRef,
) -> ValidationFailure | None:
    """执行前实时状态检查：拦截快照构建后的 kill switch / 硬禁用 / 指纹变化。"""
    if state.killed_all:
        return failure(
            status=ToolExecutionStatus.TOOL_DISABLED,
            category=ToolErrorCategory.KILL_SWITCH,
            code="TOOL_KILL_SWITCH",
            message=f"全部工具已被紧急禁用: {state.kill_all_reason or ''}",
            model_message="工具服务当前已被紧急停用，请稍后再试",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    entry = state.tools.get(ref.name)
    if entry is None:
        # 工具整体卸载/下架：不暴露被过滤工具是否存在，统一 TOOL_OFFLINE
        return failure(
            status=ToolExecutionStatus.TOOL_DISABLED,
            category=ToolErrorCategory.VERSION_STALE,
            code="TOOL_OFFLINE",
            message=f"工具已下架: {ref.name}",
            model_message="该工具已不可用，请重新规划",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    if entry.killed:
        return failure(
            status=ToolExecutionStatus.TOOL_DISABLED,
            category=ToolErrorCategory.KILL_SWITCH,
            code="TOOL_KILL_SWITCH",
            message=f"工具已被紧急禁用: {ref.name} {entry.kill_reason or ''}".strip(),
            model_message="该工具当前已被紧急停用",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    if ref.version in entry.killed_versions:
        return failure(
            status=ToolExecutionStatus.TOOL_DISABLED,
            category=ToolErrorCategory.KILL_SWITCH,
            code="TOOL_VERSION_KILLED",
            message=f"工具版本已被紧急禁用: {ref.name}@{ref.version}",
            model_message="该工具版本当前已被紧急停用",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    if entry.offline:
        return failure(
            status=ToolExecutionStatus.TOOL_DISABLED,
            category=ToolErrorCategory.VERSION_STALE,
            code="TOOL_OFFLINE",
            message=f"工具已下架: {ref.name}",
            model_message="该工具已不可用，请重新规划",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    record = entry.versions.get(ref.version)
    if record is None or record.status.value == "disabled":
        return failure(
            status=ToolExecutionStatus.VERSION_STALE,
            category=ToolErrorCategory.VERSION_STALE,
            code="TOOL_VERSION_DISABLED",
            message=f"工具版本已被禁用: {ref.name}@{ref.version}",
            model_message="该工具版本已不可用，请重新发起调用",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    if record.fingerprint != ref.fingerprint:
        return failure(
            status=ToolExecutionStatus.VERSION_STALE,
            category=ToolErrorCategory.VERSION_STALE,
            code="TOOL_VERSION_STALE",
            message=f"工具版本指纹变化: {ref.name}@{ref.version}",
            model_message="工具版本已更新，请在本轮重新发起调用",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    return None


def _check_roles(
    definition: ToolDefinition, session: ToolSession
) -> ValidationFailure | None:
    """角色边界：None 不限角色；空集合表示任何角色都不可用。"""
    allowed = definition.governance.allowed_roles
    if allowed is None:
        return None
    if allowed & set(session.actor.roles):
        return None
    return failure(
        status=ToolExecutionStatus.PERMISSION_DENIED,
        category=ToolErrorCategory.PERMISSION,
        code="TOOL_ROLE_DENIED",
        message=f"角色不满足: {definition.name}",
        model_message="当前用户角色无权调用该工具",
        phase=ErrorPhase.PRE_SIDE_EFFECT,
    )
