"""Tool Runtime 包。

公共入口：
- 运行时：`app.core.tools.runtime.ToolRuntime`
- 注册表：`app.core.tools.registry.ToolRegistry`
- 结果：`app.core.tools.result.ToolResultMessage`
- 目录：`app.core.tools.catalog.build_default_registry`
"""
