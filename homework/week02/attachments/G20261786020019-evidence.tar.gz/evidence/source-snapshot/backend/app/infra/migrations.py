"""版本化 SQLite migrations：按版本在事务中执行并记录。

`CREATE TABLE IF NOT EXISTS` 不会给旧表补列，因此列变更必须走 PRAGMA 检查 + ALTER TABLE。
"""
import aiosqlite

from app.config import settings

_MIGRATIONS: list[tuple[int, str]] = [
    (1, "task_owner_and_approval_audit_columns"),
]


async def _columns(conn: aiosqlite.Connection, table: str) -> set[str]:
    async with conn.execute(f"PRAGMA table_info({table})") as cur:
        rows = await cur.fetchall()
    return {row[1] for row in rows}


async def _add_column_if_missing(
    conn: aiosqlite.Connection, table: str, column: str, ddl: str
) -> None:
    columns = await _columns(conn, table)
    if column in columns:
        return
    await conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


async def _migration_1(conn: aiosqlite.Connection) -> None:
    await _add_column_if_missing(conn, "tasks", "actor_id", "TEXT")
    await _add_column_if_missing(conn, "tool_calls", "approval_token_hash", "TEXT")
    await _add_column_if_missing(conn, "tool_calls", "approval_requested_at", "TEXT")
    await _add_column_if_missing(conn, "tool_calls", "approval_resolved_at", "TEXT")
    await _add_column_if_missing(conn, "tool_calls", "approved_by", "TEXT")
    await _add_column_if_missing(conn, "tool_calls", "approval_comment", "TEXT")
    # 旧任务回填历史默认用户，保持可查询；新任务由应用强制提供 actor
    await conn.execute(
        "UPDATE tasks SET actor_id = ? WHERE actor_id IS NULL OR actor_id = ''",
        (settings.default_user_id,),
    )


async def run_migrations(conn: aiosqlite.Connection) -> None:
    await conn.execute(
        "CREATE TABLE IF NOT EXISTS schema_migrations ("
        "version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)"
    )
    async with conn.execute("SELECT version FROM schema_migrations") as cur:
        applied = {row[0] for row in await cur.fetchall()}

    handlers = {1: _migration_1}
    for version, _name in _MIGRATIONS:
        if version in applied:
            continue
        handler = handlers[version]
        await handler(conn)
        await conn.execute(
            "INSERT OR IGNORE INTO schema_migrations (version, applied_at) "
            "VALUES (?, datetime('now'))",
            (version,),
        )
    await conn.commit()
