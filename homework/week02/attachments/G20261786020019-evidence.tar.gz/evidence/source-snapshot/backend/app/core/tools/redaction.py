"""结构化脱敏：字段名命中敏感集合 + 字符串值正则脱敏 + 哈希/预览。"""
import hashlib
import json
from typing import Any

from app.core.prompt.security import sanitize_output
from app.infra.logger import SENSITIVE_KEYS

MASK = "***REDACTED***"

_EXTRA_SENSITIVE_KEYS = {
    "to", "cc", "bcc", "body", "account_no", "account", "phone", "address",
}


def _is_sensitive_key(key: str, extra: frozenset[str]) -> bool:
    key_lower = str(key).lower()
    if key_lower in extra:
        return True
    return any(s in key_lower for s in SENSITIVE_KEYS)


def redact_value(value: Any, *, extra: frozenset[str] = frozenset()) -> tuple[Any, bool]:
    """递归脱敏，返回 (脱敏后的值, 是否发生替换)。"""
    applied = False
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for k, v in value.items():
            if _is_sensitive_key(str(k), extra):
                result[k] = MASK
                applied = True
            else:
                redacted, changed = redact_value(v, extra=extra)
                result[k] = redacted
                applied = applied or changed
        return result, applied
    if isinstance(value, list):
        items = []
        for item in value:
            redacted, changed = redact_value(item, extra=extra)
            items.append(redacted)
            applied = applied or changed
        return items, applied
    if isinstance(value, str):
        cleaned = sanitize_output(value)
        return cleaned, cleaned != value
    return value, False


def redact_text(text: str, limit: int) -> str:
    cleaned = sanitize_output(text)
    if len(cleaned) > limit:
        return cleaned[:limit] + "…(truncated)"
    return cleaned


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def preview(value: Any, limit: int) -> str:
    payload = json.dumps(value, ensure_ascii=False, default=str)
    if len(payload) > limit:
        return payload[:limit] + "…(truncated)"
    return payload
