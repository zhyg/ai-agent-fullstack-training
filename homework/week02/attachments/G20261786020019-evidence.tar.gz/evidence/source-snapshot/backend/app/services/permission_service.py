"""用户与权限解析：权限来源为 users / user_permissions 两张表。"""
from app.core.tools.enums import ToolPermission
from app.core.tools.session import ActorContext
from app.infra.db import Database


class PermissionService:
    def __init__(self, db: Database):
        self._db = db

    async def resolve(self, actor_id: str | None) -> ActorContext:
        """按显式 actor_id 解析权限与角色；不再隐式替换为默认管理员。"""
        if not actor_id:
            return ActorContext(
                actor_id=None,
                tenant_id=None,
                granted_permissions=frozenset(),
                roles=frozenset(),
            )
        user = await self._db.get_user(actor_id)
        if user is None or user.get("status") != "active":
            return ActorContext(
                actor_id=actor_id,
                tenant_id=None,
                granted_permissions=frozenset(),
                roles=frozenset(),
            )

        raw_permissions = await self._db.get_user_permissions(actor_id)
        granted: set[ToolPermission] = set()
        for name in raw_permissions:
            try:
                granted.add(ToolPermission(name))
            except ValueError:
                continue
        role = user.get("role")
        return ActorContext(
            actor_id=actor_id,
            tenant_id=user.get("org_id"),
            granted_permissions=frozenset(granted),
            roles=frozenset({role}) if role else frozenset(),
        )

    async def is_admin(self, actor_id: str | None) -> bool:
        """实时读取用户，要求 active 且 role=admin；不缓存启动时角色。"""
        if not actor_id:
            return False
        user = await self._db.get_user(actor_id)
        return bool(
            user
            and user.get("status") == "active"
            and user.get("role") == "admin"
        )
