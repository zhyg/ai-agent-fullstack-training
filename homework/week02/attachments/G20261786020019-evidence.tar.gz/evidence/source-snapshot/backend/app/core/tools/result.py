"""工具执行结果与审计记录（跨 API / 事件 / DB 的边界对象）。"""
import json
from datetime import datetime, timezone
from typing import Annotated, Any

from pydantic import BaseModel, Field

from app.core.tools.enums import (
    ApprovalStatus,
    ErrorPhase,
    RiskLevel,
    ToolEffect,
    ToolErrorCategory,
    ToolExecutionStatus,
)
from app.core.tools.error_schema import ToolErrorSchema


class ToolErrorInfo(BaseModel):
    category: ToolErrorCategory
    code: str
    message: str = ""
    model_message: str = ""
    retryable: bool = False
    retry_count: int = 0
    retry_strategy: str | None = None
    retry_after: float | None = None
    phase: ErrorPhase = ErrorPhase.UNKNOWN


class ToolResultMessage(BaseModel):
    """工具执行结果；success/summary/error 保留旧前端兼容字段。"""

    tool_call_id: str
    tool_name: str
    tool_version: str = ""
    snapshot_id: str = ""
    audit_id: str = ""

    status: ToolExecutionStatus
    success: bool
    data: dict[str, Any] = Field(default_factory=dict)
    summary: str = ""
    error: str | None = None
    error_info: ToolErrorInfo | None = None
    error_schema: ToolErrorSchema | None = None

    duration_ms: int = 0
    retry_count: int = 0
    redaction_applied: bool = False
    possible_side_effect: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_llm_content(self) -> str:
        """压缩后的 JSON 字符串，用于 role=tool 内容或 StepRecord 摘要。"""
        payload: dict[str, Any] = {
            "success": self.success,
            "status": self.status.value,
            "tool_name": self.tool_name,
            "tool_version": self.tool_version,
            "summary": self.summary,
            "data": self.data,
        }
        if self.error:
            payload["error"] = self.error
        if self.error_schema is not None:
            # 只回灌安全字段，绝不输出内部 message / 堆栈 / token
            payload["error_schema"] = self.error_schema.to_llm_dict()
        elif self.error_info is not None:
            payload["error_info"] = {
                "category": self.error_info.category.value,
                "code": self.error_info.code,
                "model_message": self.error_info.model_message,
                "retryable": self.error_info.retryable,
                "retry_count": self.error_info.retry_count,
            }
        if self.possible_side_effect:
            payload["possible_side_effect"] = True
        return json.dumps(payload, ensure_ascii=False, default=str)

    def to_publish_payload(self) -> dict[str, Any]:
        """SSE 事件载荷：复用安全序列化，不输出内部 error_info.message。"""
        payload = json.loads(self.to_llm_content())
        payload.update({
            "tool_call_id": self.tool_call_id,
            "snapshot_id": self.snapshot_id,
            "audit_id": self.audit_id,
            "duration_ms": self.duration_ms,
            "retry_count": self.retry_count,
            "redaction_applied": self.redaction_applied,
        })
        return payload


class ToolAuditRecord(BaseModel):
    audit_id: str
    trace_id: str
    task_id: str | None = None
    snapshot_id: str
    registry_revision: int
    step: int
    round: int
    tool_call_id: str
    tool_name: str
    tool_version: str

    actor_id: str | None = None
    tenant_id: str | None = None
    permission_decision: str = "granted"
    risk_level: RiskLevel
    approval_status: ApprovalStatus = ApprovalStatus.NOT_REQUIRED
    approval_token_hash: str | None = None
    approval_requested_at: datetime | None = None
    approval_resolved_at: datetime | None = None
    approved_by: str | None = None
    approval_comment: str | None = None
    effect: ToolEffect = ToolEffect.READ_ONLY
    idempotency_key: str | None = None

    status: ToolExecutionStatus
    error_category: ToolErrorCategory | None = None
    error_code: str | None = None
    retry_count: int = 0
    retry_strategy: str | None = None
    possible_side_effect: bool = False

    duration_ms: int = 0
    input_hash: str = ""
    input_preview: str | None = None
    output_hash: str | None = None
    output_preview: str | None = None
    redaction_applied: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
