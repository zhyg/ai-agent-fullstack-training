"""ToolSnapshot：每轮工具执行时冻结的元数据视图，不包含 handler。

依赖方向：snapshot -> definition + llm.schemas，纯不可变数据。
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.core.tools.definition import ToolDependency
from app.core.tools.enums import RiskLevel, ToolEffect, ToolOrigin, ToolPermission
from app.llm.schemas import ToolDef


@dataclass(frozen=True)
class ToolRef:
    """快照中对一个工具的引用（只有元数据，没有 handler）。"""

    name: str
    version: str
    fingerprint: str
    handler_id: str
    risk_level: RiskLevel
    requires_confirmation: bool
    parallelizable: bool
    effect: ToolEffect
    dependencies: tuple[ToolDependency, ...]
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] | None
    description: str = ""
    display_name: str = ""
    # 身份边界：快照值与执行时实时值都会用于校验与审计
    required_permissions: frozenset[ToolPermission] = frozenset()
    allowed_roles: frozenset[str] | None = None
    origin: ToolOrigin = ToolOrigin.BUILTIN
    plugin_id: str = "builtin.core"


@dataclass(frozen=True)
class SnapshotSelection:
    requested_names: tuple[str, ...] | None
    actor_id: str | None
    tenant_id: str | None
    canary_names: tuple[str, ...] = ()


@dataclass(frozen=True)
class ToolSnapshot:
    snapshot_id: str
    task_id: str
    trace_id: str
    round: int
    registry_revision: int
    created_at: datetime
    expires_at: datetime
    refs: tuple[ToolRef, ...] = ()
    selection: SnapshotSelection | None = None

    def to_tool_defs(self) -> list[ToolDef]:
        """模型可见工具定义：仅 name / description / input_schema。"""
        return [
            ToolDef(
                name=ref.name,
                description=ref.description or ref.display_name or ref.name,
                parameters=ref.input_schema,
            )
            for ref in self.refs
        ]

    def get(self, name: str) -> ToolRef | None:
        for ref in self.refs:
            if ref.name == name:
                return ref
        return None

    def names(self) -> tuple[str, ...]:
        return tuple(ref.name for ref in self.refs)

    def is_expired(self, now: datetime) -> bool:
        return now > self.expires_at
