"""Tool Runtime 异常：业务错误（可分类）与控制流错误。"""
from app.core.tools.enums import ErrorPhase, ToolErrorCategory


class ToolBusinessError(Exception):
    """handler 主动抛出的业务错误，Runtime 据此分类与决定是否重试。"""

    def __init__(
        self,
        *,
        category: ToolErrorCategory,
        code: str,
        message: str,
        model_message: str | None = None,
        phase: ErrorPhase = ErrorPhase.UNKNOWN,
        retry_after: float | None = None,
    ):
        self.category = category
        self.code = code
        self.message = message
        self.model_message = model_message or message
        self.phase = phase
        self.retry_after = retry_after
        super().__init__(message)


class ToolCancelledError(Exception):
    """任务取消：唯一允许打断主循环的工具执行异常。"""


class ToolRegistryError(Exception):
    """注册表操作错误。"""


class ToolVersionConflictError(ToolRegistryError):
    def __init__(self, name: str, version: str):
        super().__init__(f"工具版本已存在且指纹不同: {name}@{version}")
        self.name = name
        self.version = version


class ToolNotFoundInRegistryError(ToolRegistryError):
    def __init__(self, name: str):
        super().__init__(f"工具不存在: {name}")
        self.name = name
