"""工具定义三部分：实现信息(ToolSpec) / 治理信息(ToolGovernance) / handler 绑定(ToolDefinition)。

依赖方向：definition -> enums + llm.schemas，不依赖 registry / snapshot / runtime。
"""
import hashlib
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

from app.core.tools.enums import (
    ModelAction,
    RiskLevel,
    ToolEffect,
    ToolErrorCategory,
    ToolOrigin,
    ToolPermission,
)
from app.llm.schemas import ToolDef

if TYPE_CHECKING:
    from app.core.tools.session import HandlerContext


# ── 第一部分：实现信息 + schema + 异常声明 ──
@dataclass(frozen=True)
class ToolErrorSpec:
    """工具可能返回的业务错误声明。"""

    code: str
    category: ToolErrorCategory
    retryable: bool = False
    model_message: str = ""
    audit_message: str = ""
    model_action: ModelAction = ModelAction.NONE


@dataclass(frozen=True)
class ToolSpec:
    name: str
    version: str
    display_name: str
    description: str
    input_model: type[BaseModel]
    input_schema: dict[str, Any]
    output_model: type[BaseModel] | None = None
    output_schema: dict[str, Any] | None = None
    error_specs: tuple[ToolErrorSpec, ...] = ()
    examples: tuple[dict[str, Any], ...] = ()
    # 稳定归属：所有来源都必须有 plugin_id 与 origin
    origin: ToolOrigin = ToolOrigin.BUILTIN
    plugin_id: str = "builtin.core"

    @classmethod
    def create(
        cls,
        *,
        name: str,
        version: str,
        description: str,
        input_model: type[BaseModel],
        output_model: type[BaseModel] | None = None,
        display_name: str | None = None,
        error_specs: tuple[ToolErrorSpec, ...] = (),
        examples: tuple[dict[str, Any], ...] = (),
        origin: ToolOrigin = ToolOrigin.BUILTIN,
        plugin_id: str = "builtin.core",
    ) -> "ToolSpec":
        return cls(
            name=name,
            version=version,
            display_name=display_name or name,
            description=description,
            input_model=input_model,
            input_schema=input_model.model_json_schema(),
            output_model=output_model,
            output_schema=(
                output_model.model_json_schema() if output_model else None
            ),
            error_specs=error_specs,
            examples=examples,
            origin=origin,
            plugin_id=plugin_id,
        )


# ── 第二部分：治理信息 ──
@dataclass(frozen=True)
class ToolDependency:
    tool_name: str
    version: str | None = None
    required: bool = True


@dataclass(frozen=True)
class ToolRetryPolicy:
    max_retries: int = 0
    base_delay: float = 0.5
    max_delay: float = 10.0
    jitter: bool = True
    retry_on: frozenset[ToolErrorCategory] = field(default_factory=frozenset)
    respect_retry_after: bool = True


@dataclass(frozen=True)
class ToolAuditPolicy:
    enabled: bool = True
    include_input: bool = True
    input_preview_chars: int = 512
    include_output: bool = True
    output_preview_chars: int = 512
    sensitive_fields: frozenset[str] = field(default_factory=frozenset)
    sample_rate: float = 1.0


@dataclass(frozen=True)
class ToolGovernance:
    permissions: frozenset[ToolPermission]
    risk_level: RiskLevel
    requires_confirmation: bool | None = None
    parallelizable: bool = False
    effect: ToolEffect = ToolEffect.READ_ONLY
    dependencies: tuple[ToolDependency, ...] = ()
    timeout_seconds: float = 30.0
    total_timeout_seconds: float | None = None
    max_concurrency: int = 4
    retry_policy: ToolRetryPolicy = field(default_factory=ToolRetryPolicy)
    audit_policy: ToolAuditPolicy = field(default_factory=ToolAuditPolicy)
    allowed_tenants: frozenset[str] | None = None
    # None 表示不限角色；空集合表示任何角色都不可用
    allowed_roles: frozenset[str] | None = None

    @property
    def needs_approval(self) -> bool:
        """未显式声明时按风险等级推导：HIGH/CRITICAL 需要审批。"""
        if self.requires_confirmation is not None:
            return self.requires_confirmation
        return self.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)


# ── 第三部分：handler 绑定 ──
class HandlerOutput:
    """handler 返回的结构化输出（data + 供模型阅读的摘要）。"""

    __slots__ = ("data", "summary")

    def __init__(self, data: dict[str, Any] | None = None, summary: str = ""):
        self.data = data or {}
        self.summary = summary

    @classmethod
    def of(cls, model: BaseModel, summary: str = "") -> "HandlerOutput":
        return cls(data=model.model_dump(mode="json"), summary=summary)


ToolHandler = Callable[[BaseModel, "HandlerContext"], Awaitable[Any]]


@dataclass(frozen=True)
class ToolDefinition:
    spec: ToolSpec
    governance: ToolGovernance
    handler: ToolHandler
    handler_id: str

    @property
    def name(self) -> str:
        return self.spec.name

    @property
    def version(self) -> str:
        return self.spec.version

    @property
    def fingerprint(self) -> str:
        """执行身份指纹：spec + handler_id。治理策略变化不改变指纹。"""
        payload = json.dumps(
            {
                "name": self.spec.name,
                "version": self.spec.version,
                "display_name": self.spec.display_name,
                "description": self.spec.description,
                "input_schema": self.spec.input_schema,
                "output_schema": self.spec.output_schema,
                "handler_id": self.handler_id,
            },
            ensure_ascii=False,
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]

    def to_model_view(self) -> ToolDef:
        """只输出模型可见字段，绝不包含 handler / governance。"""
        return ToolDef(
            name=self.spec.name,
            description=self.spec.description,
            parameters=self.spec.input_schema,
        )

    def __repr__(self) -> str:  # 避免调试输出泄露 handler 源码
        return (
            f"ToolDefinition(name={self.spec.name!r}, version={self.spec.version!r}, "
            f"handler_id={self.handler_id!r})"
        )
