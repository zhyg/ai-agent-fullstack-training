"""场景 / 模型别名路由：从配置文件读取，支持 mtime 热更新。"""
import json
from dataclasses import dataclass
from pathlib import Path

from app.core.exceptions import ConfigurationError, ValidationException


@dataclass(frozen=True)
class SceneInfo:
    """对外暴露的场景信息。"""

    name: str
    model_id: str
    description: str = ""


class SceneRouter:
    """把「场景名」或「模型别名」解析为真实注册表模型 ID。

    配置文件结构（JSON）：
    {
      "default_scene": "agent",
      "aliases": {"fast": "gpt-4o-mini", "smart": "gpt-4o"},
      "scenes": {
        "agent": {"model": "smart", "description": "多步 Agent 循环"},
        "chat": {"model": "fast", "description": "普通对话"}
      }
    }
    配置文件缺失时使用空别名表，所有解析退化为原值 / 默认模型。
    """

    def __init__(self, path: str, default_model: str, default_scene: str = "agent"):
        self._path = Path(path)
        self._default_model = default_model
        self._default_scene = default_scene
        self._aliases: dict[str, str] = {}
        self._scenes: dict[str, SceneInfo] = {}
        self._mtime: float = -1.0

    # ── 加载 ──
    def load(self, force: bool = False) -> None:
        """读取配置；未变化时跳过（mtime 热加载）。"""
        try:
            mtime = self._path.stat().st_mtime
        except FileNotFoundError:
            self._aliases, self._scenes, self._mtime = {}, {}, -1.0
            return
        if not force and mtime == self._mtime:
            return

        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise ConfigurationError(f"场景路由配置读取失败: {self._path}: {e}") from e

        aliases = data.get("aliases") or {}
        scenes = data.get("scenes") or {}
        if not isinstance(aliases, dict) or not isinstance(scenes, dict):
            raise ConfigurationError("场景路由配置格式错误：aliases/scenes 必须为对象")

        self._aliases = {str(k): str(v) for k, v in aliases.items()}
        parsed: dict[str, SceneInfo] = {}
        for name, spec in scenes.items():
            if isinstance(spec, str):
                model = spec
                desc = ""
            elif isinstance(spec, dict):
                model = spec.get("model")
                desc = spec.get("description", "")
            else:
                raise ConfigurationError(f"场景 {name} 配置格式错误")
            if not model:
                raise ConfigurationError(f"场景 {name} 缺少 model 字段")
            parsed[str(name)] = SceneInfo(name=str(name), model_id=str(model), description=desc)

        self._scenes = parsed
        self._default_scene = str(data.get("default_scene") or self._default_scene)
        self._mtime = mtime

    # ── 解析 ──
    def resolve(self, model_id: str | None = None, scene: str | None = None) -> str:
        """优先级：显式 model_id > 场景映射 > 默认场景 > 默认模型。

        model_id 会先按别名表展开（支持多级别名，带环检测）。
        """
        self.load()
        if model_id:
            return self._expand_alias(model_id)
        name = scene or self._default_scene
        info = self._scenes.get(name)
        if info is None:
            if scene:
                raise ValidationException(f"未知场景: {scene}")
            return self._default_model
        return self._expand_alias(info.model_id)

    def list_scenes(self) -> list[SceneInfo]:
        """返回全部场景（按配置顺序）。"""
        self.load()
        return list(self._scenes.values())

    def default_scene(self) -> str:
        self.load()
        return self._default_scene

    def _expand_alias(self, value: str) -> str:
        seen: set[str] = set()
        current = value
        while current in self._aliases:
            if current in seen:
                raise ConfigurationError(f"模型别名存在循环引用: {value}")
            seen.add(current)
            current = self._aliases[current]
        return current
