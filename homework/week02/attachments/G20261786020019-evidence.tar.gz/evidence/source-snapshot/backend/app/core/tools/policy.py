"""工具治理策略文件（config/tools.json）读取与覆盖。"""
import json
from dataclasses import replace
from pathlib import Path
from typing import Any

from app.core.exceptions import ConfigurationError
from app.core.tools.definition import ToolAuditPolicy, ToolGovernance, ToolRetryPolicy
from app.core.tools.enums import RiskLevel, ToolEffect, ToolErrorCategory, ToolPermission


def _invalid(tool: str | None, message: str) -> ConfigurationError:
    prefix = f"工具 {tool} " if tool else ""
    return ConfigurationError(f"{prefix}治理配置非法: {message}")


def load_policy(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    file_path = Path(path)
    if not file_path.exists():
        return {}
    try:
        return json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def apply_governance(policy: dict[str, Any], base: ToolGovernance) -> ToolGovernance:
    """按策略文件覆盖治理字段；未知/非法配置忽略并保留默认值。"""
    if not policy:
        return base

    updates: dict[str, Any] = {}
    # allowed_roles：None=不限角色；[]=任何角色都不可用
    if "allowed_roles" in policy:
        raw_roles = policy["allowed_roles"]
        if raw_roles is None:
            updates["allowed_roles"] = None
        elif isinstance(raw_roles, list) and all(
            isinstance(item, str) and item for item in raw_roles
        ):
            updates["allowed_roles"] = frozenset(raw_roles)
        else:
            raise _invalid(None, "allowed_roles 必须是字符串数组或 null")

    if "risk_level" in policy:
        try:
            updates["risk_level"] = RiskLevel(policy["risk_level"])
        except ValueError as exc:
            raise _invalid(None, f"risk_level 非法: {policy['risk_level']}") from exc
    if "requires_confirmation" in policy:
        updates["requires_confirmation"] = bool(policy["requires_confirmation"])
    if "parallelizable" in policy:
        updates["parallelizable"] = bool(policy["parallelizable"])
    if "effect" in policy:
        try:
            updates["effect"] = ToolEffect(policy["effect"])
        except ValueError as exc:
            raise _invalid(None, f"effect 非法: {policy['effect']}") from exc
    if "permissions" in policy:
        permissions = set()
        for item in policy["permissions"]:
            try:
                permissions.add(ToolPermission(item))
            except ValueError as exc:
                raise _invalid(None, f"permissions 含未知权限: {item}") from exc
        updates["permissions"] = frozenset(permissions)
    if "timeout_seconds" in policy:
        updates["timeout_seconds"] = float(policy["timeout_seconds"])
    if "total_timeout_seconds" in policy:
        updates["total_timeout_seconds"] = float(policy["total_timeout_seconds"])
    if "max_concurrency" in policy:
        updates["max_concurrency"] = int(policy["max_concurrency"])

    retry = policy.get("retry")
    if isinstance(retry, dict):
        retry_on = set()
        for item in retry.get("retry_on", []):
            try:
                retry_on.add(ToolErrorCategory(item))
            except ValueError:
                continue
        updates["retry_policy"] = ToolRetryPolicy(
            max_retries=int(retry.get("max_retries", base.retry_policy.max_retries)),
            base_delay=float(retry.get("base_delay", base.retry_policy.base_delay)),
            max_delay=float(retry.get("max_delay", base.retry_policy.max_delay)),
            jitter=bool(retry.get("jitter", base.retry_policy.jitter)),
            retry_on=frozenset(retry_on),
            respect_retry_after=bool(
                retry.get("respect_retry_after", base.retry_policy.respect_retry_after)
            ),
        )

    audit = policy.get("audit")
    if isinstance(audit, dict):
        updates["audit_policy"] = replace(
            base.audit_policy,
            enabled=bool(audit.get("enabled", base.audit_policy.enabled)),
            include_input=bool(audit.get("include_input", base.audit_policy.include_input)),
            include_output=bool(audit.get("include_output", base.audit_policy.include_output)),
            sensitive_fields=frozenset(
                audit.get("sensitive_fields", base.audit_policy.sensitive_fields)
            ),
        )

    return replace(base, **updates)
