"""可复用的 Agent 循环执行器：原生 tool calls 解析与回填、轮次/超时/预算/取消。"""
import asyncio
import json
import time
from collections.abc import Awaitable
from dataclasses import dataclass, field
from typing import Protocol

from app.core.exceptions import AppException, ConfigurationError, ValidationException
from app.core.prompt.renderer import build_run_system_message
from app.core.runtime import gen_run_id, gen_trace_id
from app.core.tools.enums import ApprovalStatus
from app.core.tools.errors import ToolCancelledError
from app.core.tools.runtime import ToolRuntime, gen_tool_call_id
from app.core.tools.session import (
    ApprovalDecision,
    AutoDenyApprovalGate,
    EventControl,
    ToolApprovalRequest,
    ToolCallRequest,
)
from app.llm.gateway import LLMGateway
from app.llm.schemas import (
    LLMRequest,
    Message,
    TokenUsage,
    ToolCall,
    ToolCallDelta,
    ToolDef,
)
from app.services.permission_service import PermissionService


class EventEmitter(Protocol):
    async def __call__(self, event_type: str, data: dict) -> None: ...


class ConfirmHandler(Protocol):
    async def __call__(self, tool_name: str, args: dict) -> bool: ...


# ── 运行期异常 ──
class RunError(Exception):
    """Runner 内部错误，携带对外错误类型。"""

    error_type = "run_error"
    retryable = False

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)


class RunMaxRoundsError(RunError):
    error_type = "max_rounds_exceeded"


class RunTimeoutError(RunError):
    error_type = "run_timeout"


class RunBudgetExceededError(RunError):
    error_type = "token_budget_exceeded"


class RunCancelledError(RunError):
    error_type = "cancelled"


class RunEmptyAnswerError(RunError):
    error_type = "empty_answer"


@dataclass
class RunLimits:
    """运行上限。"""

    max_rounds: int = 8
    timeout_seconds: float = 300.0
    token_budget: int = 100000  # 0 表示不限制


@dataclass
class RunResult:
    """一次完整运行的结果。"""

    run_id: str
    trace_id: str
    status: str
    answer: str = ""
    rounds: int = 0
    tool_calls: int = 0
    usage: TokenUsage = field(default_factory=TokenUsage)
    elapsed_ms: int = 0
    error_type: str | None = None
    error_message: str | None = None


class AgentRunner:
    """可复用的 Agent 循环执行器。

    调用方只需提供消息、模型与上限；通过 on_event 获取中间过程事件。
    工具调用使用供应商原生 tool calls 协议，自动解析增量、执行并回填 tool 消息。
    """

    def __init__(
        self,
        gateway: LLMGateway,
        *,
        tool_runtime: ToolRuntime | None = None,
        permission_service: PermissionService | None = None,
        stream_output: bool = True,
    ):
        self._gateway = gateway
        self._tool_runtime = tool_runtime
        self._permission_service = permission_service
        self._stream_output = stream_output

    def available_tools(self, names: list[str] | None = None) -> list[str]:
        """兼容旧调用：只做工具名校验，返回名称列表。"""
        if self._tool_runtime is None:
            return list(names or [])
        self._tool_runtime.registry.validate_names(names)
        return list(names) if names is not None else self._tool_runtime.registry.names()

    async def run(
        self,
        *,
        user_input: str,
        model_id: str,
        scene: str | None = None,
        system_prompt: str | None = None,
        tool_names: list[str] | None = None,
        limits: RunLimits | None = None,
        cancel_event: asyncio.Event | None = None,
        on_event: EventEmitter | None = None,
        confirm_handler: ConfirmHandler | None = None,
        business_id: str | None = None,
        run_id: str | None = None,
        actor_id: str | None = None,
    ) -> RunResult:
        limits = limits or RunLimits()
        if limits.max_rounds < 1:
            raise ValidationException("max_rounds 必须 >= 1")
        if limits.token_budget < 0:
            raise ValidationException("token_budget 必须 >= 0")
        if self._tool_runtime is None:
            raise ConfigurationError("ToolRuntime 未初始化，拒绝执行工具调用链路")

        run_id = run_id or gen_run_id()
        trace_id = gen_trace_id()
        actor = await self._resolve_actor(actor_id)
        session = self._tool_runtime.open_session(
            task_id=run_id, trace_id=trace_id, actor=actor,
            control=EventControl(cancel_event),
            approval_gate=(
                _CallbackApprovalGate(confirm_handler)
                if confirm_handler else AutoDenyApprovalGate()
            ),
            refresh_actor=(
                self._permission_service.resolve
                if self._permission_service is not None else None
            ),
        )
        initial_snapshot = self._tool_runtime.build_snapshot(
            session, round=1, tool_names=tool_names
        )

        messages: list[Message] = []
        if system_prompt:
            messages.append(Message(role="system", content=system_prompt))
        else:
            messages.append(Message(
                role="system",
                content=build_run_system_message(initial_snapshot.to_tool_defs()),
            ))
        messages.append(Message(role="user", content=user_input))

        usage = TokenUsage()
        deadline = time.monotonic() + limits.timeout_seconds
        started = time.perf_counter()
        rounds = 0
        total_tool_calls = 0

        await self._emit(on_event, "run_started", {
            "run_id": run_id,
            "trace_id": trace_id,
            "model_id": model_id,
            "scene": scene,
            "max_rounds": limits.max_rounds,
            "timeout_seconds": limits.timeout_seconds,
            "token_budget": limits.token_budget,
            "tools": list(initial_snapshot.names()),
        })

        try:
            while rounds < limits.max_rounds:
                self._check_cancel(cancel_event)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise RunTimeoutError("运行超时")
                rounds += 1
                # 每轮先刷新最新身份，再重新冻结工具快照
                await session.refresh_identity()
                snapshot = self._tool_runtime.build_snapshot(
                    session, round=rounds, tool_names=tool_names
                )
                tool_defs = snapshot.to_tool_defs()
                if system_prompt is None:
                    messages[0] = Message(
                        role="system",
                        content=build_run_system_message(tool_defs),
                    )
                await self._emit(on_event, "round_started", {"round": rounds})

                try:
                    content, calls, round_usage = await asyncio.wait_for(
                        self._llm_round(
                            model_id=model_id,
                            scene=scene,
                            messages=messages,
                            tool_defs=tool_defs,
                            trace_id=trace_id,
                            business_id=business_id,
                            on_event=on_event,
                        ),
                        timeout=remaining,
                    )
                except asyncio.TimeoutError as e:
                    raise RunTimeoutError("运行超时") from e
                except asyncio.CancelledError as e:
                    raise RunCancelledError("运行已取消") from e
                except AppException:
                    raise
                except RunError:
                    raise
                except Exception as e:  # 适配层外的未知错误
                    raise RunError(f"运行失败: {e}") from e

                usage = TokenUsage(
                    prompt_tokens=usage.prompt_tokens + round_usage.prompt_tokens,
                    completion_tokens=usage.completion_tokens + round_usage.completion_tokens,
                    total_tokens=usage.total_tokens + round_usage.total_tokens,
                )
                if limits.token_budget and usage.total_tokens > limits.token_budget:
                    raise RunBudgetExceededError(
                        f"token 预算超限: {usage.total_tokens} > {limits.token_budget}"
                    )

                if not calls:
                    answer = content.strip()
                    if not answer:
                        raise RunEmptyAnswerError("模型未返回任何内容")
                    elapsed = int((time.perf_counter() - started) * 1000)
                    await self._emit(on_event, "final", {
                        "answer": answer,
                        "rounds": rounds,
                        "usage": usage.model_dump(),
                        "elapsed_ms": elapsed,
                    })
                    return RunResult(
                        run_id=run_id,
                        trace_id=trace_id,
                        status="completed",
                        answer=answer,
                        rounds=rounds,
                        tool_calls=total_tool_calls,
                        usage=usage,
                        elapsed_ms=elapsed,
                    )

                # 回填 assistant tool_calls 与工具结果
                messages.append(Message(role="assistant", content=content, tool_calls=calls))
                for call in calls:
                    self._check_cancel(cancel_event)
                    total_tool_calls += 1
                    call_id = call.id or gen_tool_call_id()
                    call.id = call_id
                    await self._emit(on_event, "tool_call", {
                        "round": rounds,
                        "call_id": call_id,
                        "tool_name": call.name,
                        "arguments": call.arguments,
                    })
                    try:
                        result = await self._tool_runtime.execute(
                            snapshot,
                            ToolCallRequest(
                                tool_name=call.name,
                                arguments=call.arguments,
                                tool_call_id=call_id,
                                round=rounds,
                            ),
                            session,
                        )
                    except ToolCancelledError as exc:
                        raise RunCancelledError("运行已取消") from exc
                    result_text = result.to_llm_content()
                    await self._emit(on_event, "tool_result", {
                        "round": rounds,
                        "call_id": call_id,
                        "tool_name": call.name,
                        "success": result.success,
                        "status": result.status.value,
                        "content": result_text,
                        "audit_id": result.audit_id,
                        "tool_version": result.tool_version,
                        "retry_count": result.retry_count,
                    })
                    messages.append(Message(
                        role="tool",
                        tool_call_id=call_id,
                        name=call.name,
                        content=result_text,
                    ))

            raise RunMaxRoundsError(f"超过最大轮次 {limits.max_rounds}")
        except RunError as e:
            elapsed = int((time.perf_counter() - started) * 1000)
            await self._emit(on_event, "error", {
                "error_type": e.error_type,
                "message": e.message,
                "retryable": e.retryable,
            })
            return RunResult(
                run_id=run_id,
                trace_id=trace_id,
                status="cancelled" if isinstance(e, RunCancelledError) else "failed",
                rounds=rounds,
                tool_calls=total_tool_calls,
                usage=usage,
                elapsed_ms=elapsed,
                error_type=e.error_type,
                error_message=e.message,
            )
        except AppException as e:
            elapsed = int((time.perf_counter() - started) * 1000)
            await self._emit(on_event, "error", {
                "error_type": e.code.value,
                "message": e.message,
                "retryable": e.retryable,
            })
            return RunResult(
                run_id=run_id,
                trace_id=trace_id,
                status="failed",
                rounds=rounds,
                tool_calls=total_tool_calls,
                usage=usage,
                elapsed_ms=elapsed,
                error_type=e.code.value,
                error_message=e.message,
            )
        finally:
            elapsed = int((time.perf_counter() - started) * 1000)
            await self._emit(on_event, "run_finished", {
                "run_id": run_id,
                "rounds": rounds,
                "tool_calls": total_tool_calls,
                "usage": usage.model_dump(),
                "elapsed_ms": elapsed,
            })

    # ── 单轮 LLM 调用 ──
    async def _llm_round(
        self,
        *,
        model_id: str,
        scene: str | None,
        messages: list[Message],
        tool_defs: list[ToolDef],
        trace_id: str,
        business_id: str | None,
        on_event: EventEmitter | None,
    ) -> tuple[str, list[ToolCall], TokenUsage]:
        req = LLMRequest(
            model_id=model_id,
            messages=messages,
            tools=tool_defs or None,
            stream=self._stream_output,
            scene=scene,
        )
        if not self._stream_output:
            resp = await self._gateway.invoke(req, trace_id=trace_id, business_id=business_id)
            return resp.content, list(resp.tool_calls or []), resp.usage

        content_parts: list[str] = []
        deltas: dict[int, dict] = {}
        usage = TokenUsage()
        async for chunk in self._gateway.stream(
            req, trace_id=trace_id, business_id=business_id
        ):
            if chunk.content:
                content_parts.append(chunk.content)
                await self._emit(on_event, "token", {"content": chunk.content})
            if chunk.tool_calls:
                for d in chunk.tool_calls:
                    self._merge_tool_delta(deltas, d)
            if chunk.usage is not None:
                usage = chunk.usage

        calls = [
            ToolCall(
                id=item.get("id") or "",
                name=item.get("name") or "",
                arguments=self._parse_arguments(item.get("arguments", "")),
            )
            for _, item in sorted(deltas.items())
        ]
        return "".join(content_parts), calls, usage

    @staticmethod
    def _merge_tool_delta(deltas: dict[int, dict], delta: ToolCallDelta) -> None:
        item = deltas.setdefault(delta.index, {"id": "", "name": "", "arguments": ""})
        if delta.id:
            item["id"] = delta.id
        if delta.name:
            item["name"] += delta.name
        if delta.arguments:
            item["arguments"] += delta.arguments

    @staticmethod
    def _parse_arguments(raw: str) -> dict:
        if not raw:
            return {}
        try:
            parsed = json.loads(raw)
        except (ValueError, TypeError):
            return {"_raw": raw}
        return parsed if isinstance(parsed, dict) else {"value": parsed}

    # ── 调用者权限 ──
    async def _resolve_actor(self, actor_id: str | None):
        if self._permission_service is None:
            raise ConfigurationError("PermissionService 未初始化")
        # 显式身份；无 actor 时解析为空权限，不回退默认管理员
        return await self._permission_service.resolve(actor_id)

    # ── 取消检查 ──
    @staticmethod
    def _check_cancel(cancel_event: asyncio.Event | None) -> None:
        if cancel_event is not None and cancel_event.is_set():
            raise RunCancelledError("运行已取消")

    @staticmethod
    async def _emit(on_event: EventEmitter | None, event_type: str, data: dict) -> None:
        if on_event is None:
            return
        result = on_event(event_type, data)
        if isinstance(result, Awaitable):  # 兼容同步/异步回调
            await result


class _CallbackApprovalGate:
    """把调用方 confirm_handler 适配为 Runtime ApprovalGate。"""

    def __init__(self, confirm_handler: ConfirmHandler):
        self._handler = confirm_handler

    async def request(self, req: ToolApprovalRequest) -> ApprovalDecision:
        approved = await self._handler(req.tool_name, req.tool_args)
        if approved:
            return ApprovalDecision(
                approved=True, status=ApprovalStatus.APPROVED,
            )
        return ApprovalDecision(
            approved=False,
            status=ApprovalStatus.DENIED,
            reason="用户拒绝执行该工具",
        )
