"""ToolErrorSchema：面向模型的安全错误结构 + 模型动作建议。

约束：
- 默认 `resolvable_by_model=False`，只有明确安全且带 `model_message` 的错误才回灌模型；
- 任何映射都不得覆盖重试模块的副作用安全判断，尤其是 NON_IDEMPOTENT_WRITE 禁止 RETRY_SAME。
"""
from typing import Any

from pydantic import BaseModel, Field

from app.core.tools.enums import (
    ErrorPhase,
    ModelAction,
    ToolEffect,
    ToolErrorCategory,
    ToolExecutionStatus,
)

__all__ = ["ModelAction", "ToolErrorSchema", "build_tool_error_schema"]


class ToolErrorSchema(BaseModel):
    """回灌模型的错误结构：只包含安全字段，不含内部 message / 堆栈 / token。"""

    code: str
    category: ToolErrorCategory
    phase: ErrorPhase
    retryable: bool = False
    model_action: ModelAction = ModelAction.NONE
    model_message: str = ""
    hint: str = ""
    fields: dict[str, Any] = Field(default_factory=dict)
    resolvable_by_model: bool = False
    retry_after: float | None = None
    possible_side_effect: bool = False

    def to_llm_dict(self) -> dict[str, Any]:
        """只序列化安全字段。"""
        return self.model_dump(mode="json")


_DEFAULT_MESSAGES: dict[ToolErrorCategory, str] = {
    ToolErrorCategory.VALIDATION: "工具参数不合法，请按提示修正后重试",
    ToolErrorCategory.PERMISSION: "当前用户无权调用该工具，请向用户说明或请求授权",
    ToolErrorCategory.NOT_FOUND: "目标对象或工具不存在，请改用其他方式",
    ToolErrorCategory.KILL_SWITCH: "该工具当前已被停用，请改用其他方式",
    ToolErrorCategory.VERSION_STALE: "工具或快照已变更，请重新发起调用",
    ToolErrorCategory.DEPENDENCY: "请先完成依赖工具调用",
    ToolErrorCategory.APPROVAL: "该操作未获得用户批准",
    ToolErrorCategory.TIMEOUT: "工具执行超时，结果可能未完成",
    ToolErrorCategory.NETWORK: "外部服务连接失败",
    ToolErrorCategory.RATE_LIMIT: "外部服务限流，请稍后重试",
    ToolErrorCategory.UPSTREAM: "外部服务暂不可用",
    ToolErrorCategory.AUTH: "外部服务鉴权失败",
    ToolErrorCategory.BUSINESS: "业务规则校验失败，请调整参数",
    ToolErrorCategory.OUTPUT_SCHEMA: "工具返回结果格式异常",
    ToolErrorCategory.CANCELLED: "任务已取消",
    ToolErrorCategory.INTERNAL: "工具执行发生内部错误",
}

_TRANSIENT = {
    ToolErrorCategory.TIMEOUT,
    ToolErrorCategory.NETWORK,
    ToolErrorCategory.RATE_LIMIT,
    ToolErrorCategory.UPSTREAM,
}


def _resolve_action(
    *,
    category: ToolErrorCategory,
    status: ToolExecutionStatus | None,
    effect: ToolEffect,
    possible_side_effect: bool,
    retryable: bool,
) -> tuple[ModelAction, bool]:
    """返回 (model_action, resolvable_by_model)。"""
    if category == ToolErrorCategory.APPROVAL:
        timed_out = (
            status == ToolExecutionStatus.APPROVAL_TIMEOUT
        )
        return (ModelAction.ASK_USER if timed_out else ModelAction.STOP), True

    if category == ToolErrorCategory.VALIDATION:
        return ModelAction.FIX_ARGUMENTS, True
    if category == ToolErrorCategory.BUSINESS:
        return ModelAction.FIX_ARGUMENTS, True
    if category == ToolErrorCategory.PERMISSION:
        return ModelAction.ASK_USER, True
    if category in (
        ToolErrorCategory.NOT_FOUND,
        ToolErrorCategory.KILL_SWITCH,
        ToolErrorCategory.VERSION_STALE,
        ToolErrorCategory.DEPENDENCY,
    ):
        return ModelAction.USE_ALTERNATIVE, True

    if category in _TRANSIENT:
        # 副作用优先：非幂等写或不确定是否已产生副作用时，绝不建议原样重试
        if possible_side_effect or effect == ToolEffect.NON_IDEMPOTENT_WRITE:
            return ModelAction.ASK_USER, True
        if retryable:
            return ModelAction.RETRY_SAME, True
        return ModelAction.USE_ALTERNATIVE, True

    if category in (
        ToolErrorCategory.AUTH,
        ToolErrorCategory.INTERNAL,
        ToolErrorCategory.OUTPUT_SCHEMA,
        ToolErrorCategory.CANCELLED,
    ):
        return ModelAction.NONE, False

    return ModelAction.NONE, False


def build_tool_error_schema(
    *,
    code: str,
    category: ToolErrorCategory,
    phase: ErrorPhase,
    model_message: str = "",
    retryable: bool = False,
    effect: ToolEffect = ToolEffect.READ_ONLY,
    possible_side_effect: bool = False,
    status: ToolExecutionStatus | None = None,
    retry_after: float | None = None,
    fields: dict[str, Any] | None = None,
    hint: str = "",
) -> ToolErrorSchema:
    action, resolvable = _resolve_action(
        category=category,
        status=status,
        effect=effect,
        possible_side_effect=possible_side_effect,
        retryable=retryable,
    )
    message = (model_message or "").strip() or _DEFAULT_MESSAGES.get(
        category, "工具执行失败"
    )
    return ToolErrorSchema(
        code=code,
        category=category,
        phase=phase,
        retryable=retryable,
        model_action=action,
        model_message=message,
        hint=hint,
        fields=fields or {},
        resolvable_by_model=resolvable,
        retry_after=retry_after,
        possible_side_effect=possible_side_effect,
    )
