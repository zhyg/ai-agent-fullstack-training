"""插件管理：ToolPlugin 协议与串行化 PluginManager。

动态安装/卸载仅用于受控调试与运行时实验，不持久化；启动真相源仍是内置目录与配置文件。
"""
import asyncio
from typing import Callable, Protocol

from app.core.exceptions import ConfigurationError
from app.core.tools.definition import ToolDefinition
from app.core.tools.registry import ToolRegistry


class ToolPlugin(Protocol):
    plugin_id: str
    version: str

    def definitions(self) -> list[ToolDefinition]: ...

    async def startup(self) -> None: ...

    async def shutdown(self) -> None: ...


PluginFactory = Callable[[], ToolPlugin]


class PluginManager:
    """串行化管理操作；install/uninstall/offline/online 都走单次 copy-on-write 提交。"""

    def __init__(self, registry: ToolRegistry, logger=None):
        self._registry = registry
        self._logger = logger
        self._factories: dict[str, PluginFactory] = {}
        self._active: dict[str, ToolPlugin] = {}
        self._lock = asyncio.Lock()

    def register_factory(self, plugin_id: str, factory: PluginFactory) -> None:
        """登记服务端预注册插件工厂；接口不允许传入任意导入字符串。"""
        self._factories[plugin_id] = factory

    async def install(self, plugin_id: str, *, activate: bool = True) -> int:
        factory = self._factories.get(plugin_id)
        if factory is None:
            raise ConfigurationError(f"插件工厂未注册: {plugin_id}")
        async with self._lock:
            plugin = factory()
            if plugin.plugin_id != plugin_id:
                raise ConfigurationError(
                    f"插件工厂 {plugin_id} 返回了不匹配的 plugin_id: {plugin.plugin_id}"
                )
            await plugin.startup()
            try:
                revision = self._registry.register_batch(
                    plugin.definitions(), activate=activate, actor="admin",
                )
            except Exception:
                # 提交失败补偿资源
                try:
                    await plugin.shutdown()
                except Exception as exc:  # 补偿失败只记日志
                    self._warn("plugin_install_rollback_failed", plugin_id, exc)
                raise
            self._active[plugin_id] = plugin
            return revision

    async def uninstall(self, plugin_id: str) -> int:
        async with self._lock:
            revision = self._registry.unregister_plugin(plugin_id, actor="admin")
            plugin = self._active.pop(plugin_id, None)
            if plugin is not None:
                try:
                    await plugin.shutdown()
                except Exception as exc:
                    # 清理失败只记错误，不恢复半套装态
                    self._warn("plugin_shutdown_failed", plugin_id, exc)
            return revision

    def offline(
        self, plugin_id: str, *, tool_name: str | None = None, reason: str = ""
    ) -> int:
        return self._registry.disable_scope(
            plugin_id, tool_name=tool_name, reason=reason, actor="admin",
        )

    def online(self, plugin_id: str, *, tool_name: str | None = None) -> int:
        return self._registry.enable_latest_scope(
            plugin_id, tool_name=tool_name, actor="admin",
        )

    def list(self) -> list[dict]:
        plugins = self._registry.plugin_summary()
        for plugin in plugins:
            plugin["dynamic"] = plugin["plugin_id"] in self._active
        return plugins

    def _warn(self, event: str, plugin_id: str, exc: Exception) -> None:
        if self._logger is not None:
            self._logger.error(event, plugin_id=plugin_id, error=str(exc))
