"""MCP 工具接入：mock client 与 ToolDefinition 注册器。"""
