"""互联网搜索 handler（百度千帆 AI 搜索，原 WebSearchTool 迁移）。"""
from typing import Annotated

import httpx
from pydantic import BaseModel, Field, field_validator

from app.config import settings
from app.core.tools.definition import HandlerOutput
from app.core.tools.enums import ErrorPhase, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError
from app.core.tools.session import HandlerContext

API_URL = "https://qianfan.baidubce.com/v2/ai_search/web_search"
TIMEOUT = 30.0


class WebSearchArgs(BaseModel):
    query: Annotated[str, Field(..., min_length=1, max_length=500, description="搜索关键词")]
    max_results: Annotated[int, Field(5, ge=1, le=20, description="返回结果条数，1~20")] = 5
    recency_filter: Annotated[str, Field("week", description="时间范围过滤")] = "week"

    @field_validator("recency_filter")
    @classmethod
    def validate_recency(cls, v: str) -> str:
        allowed = {"day", "week", "month", "year", "no_limit"}
        if v not in allowed:
            raise ValueError(f"recency_filter 必须为 {allowed} 之一")
        return v


class SearchItem(BaseModel):
    title: str = ""
    url: str = ""
    snippet: str = ""
    source: str = ""
    date: str = ""


class WebSearchOutput(BaseModel):
    items: list[SearchItem]


async def handle(args: WebSearchArgs, ctx: HandlerContext) -> HandlerOutput:
    if not settings.web_search_api_key:
        raise ToolBusinessError(
            category=ToolErrorCategory.AUTH,
            code="WEB_SEARCH_KEY_MISSING",
            message="搜索 API Key 未配置",
            model_message="搜索服务未配置，无法执行搜索",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    payload = {
        "messages": [{"role": "user", "content": args.query}],
        "edition": "standard",
        "search_source": "baidu_search_v2",
        "search_recency_filter": args.recency_filter,
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {settings.web_search_api_key}",
    }

    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            resp = await client.post(API_URL, json=payload, headers=headers)
    except httpx.TimeoutException as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.TIMEOUT,
            code="1608",
            message="搜索请求超时",
            model_message="搜索请求超时，请稍后重试",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        ) from exc
    except httpx.ConnectError as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.NETWORK,
            code="TOOL_NETWORK_ERROR",
            message="搜索服务连接失败",
            model_message="搜索服务连接失败",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        ) from exc

    if resp.status_code != 200:
        category = ToolErrorCategory.UPSTREAM if resp.status_code >= 500 else (
            ToolErrorCategory.RATE_LIMIT if resp.status_code == 429 else (
                ToolErrorCategory.AUTH if resp.status_code in (401, 403)
                else ToolErrorCategory.BUSINESS
            )
        )
        raise ToolBusinessError(
            category=category,
            code=f"WEB_SEARCH_HTTP_{resp.status_code}",
            message=f"搜索接口返回 {resp.status_code}: {resp.text[:200]}",
            model_message=f"搜索服务返回异常状态 {resp.status_code}",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    content_type = resp.headers.get("Content-Type", "")
    if "application/json" not in content_type:
        raise ToolBusinessError(
            category=ToolErrorCategory.UPSTREAM,
            code="WEB_SEARCH_BAD_CONTENT_TYPE",
            message=f"响应非 JSON (Content-Type={content_type})",
            model_message="搜索服务返回格式异常",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    try:
        data = resp.json()
    except ValueError as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.UPSTREAM,
            code="WEB_SEARCH_BAD_JSON",
            message="响应 JSON 解析失败",
            model_message="搜索服务返回内容无法解析",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        ) from exc

    refs = data.get("references") or []
    items = [
        SearchItem(
            title=r.get("title", ""),
            url=r.get("url", ""),
            snippet=(r.get("content") or "")[:500],
            source=r.get("web_anchor", r.get("source", "")),
            date=r.get("date", ""),
        )
        for r in refs[: args.max_results]
    ]
    output = WebSearchOutput(items=items)
    return HandlerOutput.of(output, summary=f"搜索到 {len(items)} 条结果")
