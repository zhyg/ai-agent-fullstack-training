"""ToolRegistry：注册、版本、灰度、禁用与 kill switch（copy-on-write 不可变状态）。

依赖方向：registry -> definition + snapshot + session + enums，不依赖 runtime。
"""
import hashlib
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Any

from app.core.exceptions import ConfigurationError, ValidationException
from app.core.tools.definition import ToolDefinition, ToolDependency, ToolGovernance
from app.core.tools.enums import RiskLevel, ToolEffect, VersionStatus
from app.core.tools.errors import ToolVersionConflictError
from app.core.tools.session import ActorContext
from app.core.tools.snapshot import ToolRef


@dataclass(frozen=True)
class VersionRecord:
    definition: ToolDefinition
    status: VersionStatus
    registered_at: datetime
    fingerprint: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CanaryConfig:
    version: str
    ratio: int = 0
    allowlist: frozenset[str] = field(default_factory=frozenset)
    enabled: bool = True


@dataclass(frozen=True)
class ToolEntry:
    name: str
    versions: dict[str, VersionRecord]
    stable_version: str | None
    canary: CanaryConfig | None = None
    killed: bool = False
    kill_reason: str | None = None
    killed_versions: frozenset[str] = field(default_factory=frozenset)
    # 整工具/插件范围下架（disable_scope），用于区分单版本禁用
    offline: bool = False


@dataclass(frozen=True)
class RegistryState:
    revision: int
    tools: dict[str, ToolEntry]
    updated_at: datetime
    updated_by: str | None = None
    killed_all: bool = False
    kill_all_reason: str | None = None


class ToolRegistry:
    """工具注册表：所有写操作整体替换不可变状态，读操作永远拿当前状态。"""

    def __init__(self) -> None:
        self._state = RegistryState(
            revision=0,
            tools={},
            updated_at=datetime.now(timezone.utc),
        )

    # ── 读 ──
    def state(self) -> RegistryState:
        return self._state

    @property
    def revision(self) -> int:
        return self._state.revision

    def get_entry(self, name: str) -> ToolEntry | None:
        return self._state.tools.get(name)

    def get_definition(self, name: str, version: str) -> ToolDefinition | None:
        entry = self._state.tools.get(name)
        if entry is None:
            return None
        record = entry.versions.get(version)
        return record.definition if record else None

    def names(self) -> list[str]:
        return sorted(self._state.tools.keys())

    def validate_names(self, names: list[str] | None) -> None:
        if names is None:
            return
        missing = [n for n in names if n not in self._state.tools]
        if missing:
            raise ValidationException(f"工具不存在: {', '.join(missing)}")

    # ── 注册 / 版本 ──
    def register(
        self,
        definition: ToolDefinition,
        *,
        activate: bool = False,
        replace_existing: bool = False,
        actor: str | None = None,
    ) -> int:
        name = definition.name
        version = definition.version
        entry = self._state.tools.get(name)

        if entry is None:
            entry = ToolEntry(
                name=name, versions={}, stable_version=None, canary=None,
            )

        existing = entry.versions.get(version)
        if existing is not None:
            if existing.fingerprint == definition.fingerprint:
                return self._state.revision  # 幂等 no-op
            if not replace_existing:
                raise ToolVersionConflictError(name, version)

        versions = dict(entry.versions)
        versions[version] = VersionRecord(
            definition=definition,
            status=VersionStatus.ACTIVE,
            registered_at=datetime.now(timezone.utc),
            fingerprint=definition.fingerprint,
        )
        stable = entry.stable_version
        if activate or stable is None:
            stable = version

        new_entry = replace(entry, versions=versions, stable_version=stable)
        return self._commit(
            {**self._state.tools, name: new_entry}, actor=actor, event="tool_registered",
            detail={"name": name, "version": version},
        )

    def unregister(self, name: str, version: str, *, actor: str | None = None) -> int:
        entry = self._state.tools.get(name)
        if entry is None or version not in entry.versions:
            return self._state.revision
        versions = {k: v for k, v in entry.versions.items() if k != version}
        if not versions:
            tools = dict(self._state.tools)
            tools.pop(name, None)
            return self._commit(tools, actor=actor, event="tool_unregistered",
                                detail={"name": name, "version": version})
        stable = entry.stable_version
        if stable == version:
            stable = sorted(versions.keys())[0]
        new_entry = replace(entry, versions=versions, stable_version=stable)
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_unregistered",
                            detail={"name": name, "version": version})

    # ── 版本选择 / 灰度 ──
    def set_active(self, name: str, version: str, *, actor: str | None = None) -> int:
        entry = self._require_entry(name)
        if version not in entry.versions:
            raise ValidationException(f"版本不存在: {name}@{version}")
        new_entry = replace(entry, stable_version=version)
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_active_changed",
                            detail={"name": name, "version": version})

    def set_canary(
        self,
        name: str,
        *,
        version: str,
        ratio: int,
        allowlist: list[str] | None = None,
        enabled: bool = True,
        actor: str | None = None,
    ) -> int:
        entry = self._require_entry(name)
        if version not in entry.versions:
            raise ValidationException(f"版本不存在: {name}@{version}")
        if not 0 <= ratio <= 100:
            raise ValidationException("灰度比例必须在 0~100")
        new_entry = replace(entry, canary=CanaryConfig(
            version=version,
            ratio=ratio,
            allowlist=frozenset(allowlist or []),
            enabled=enabled,
        ))
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_canary_changed",
                            detail={"name": name, "version": version, "ratio": ratio})

    def disable_version(self, name: str, version: str, *, reason: str = "",
                       actor: str | None = None) -> int:
        entry = self._require_entry(name)
        record = entry.versions.get(version)
        if record is None:
            raise ValidationException(f"版本不存在: {name}@{version}")
        versions = dict(entry.versions)
        versions[version] = replace(record, status=VersionStatus.DISABLED)
        new_entry = replace(entry, versions=versions)
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_version_disabled",
                            detail={"name": name, "version": version, "reason": reason})

    def enable_version(self, name: str, version: str, *, actor: str | None = None) -> int:
        entry = self._require_entry(name)
        record = entry.versions.get(version)
        if record is None:
            raise ValidationException(f"版本不存在: {name}@{version}")
        versions = dict(entry.versions)
        versions[version] = replace(record, status=VersionStatus.ACTIVE)
        new_entry = replace(entry, versions=versions)
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_version_enabled",
                            detail={"name": name, "version": version})

    # ── 紧急禁用 / kill switch ──
    def kill(self, name: str, reason: str = "", *, actor: str | None = None) -> int:
        entry = self._require_entry(name)
        new_entry = replace(entry, killed=True, kill_reason=reason)
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_kill_switch",
                            detail={"name": name, "reason": reason})

    def revive(self, name: str, *, actor: str | None = None) -> int:
        entry = self._require_entry(name)
        new_entry = replace(entry, killed=False, kill_reason=None)
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_revived", detail={"name": name})

    def kill_version(self, name: str, version: str, reason: str = "",
                     *, actor: str | None = None) -> int:
        entry = self._require_entry(name)
        if version not in entry.versions:
            raise ValidationException(f"版本不存在: {name}@{version}")
        new_entry = replace(entry, killed_versions=entry.killed_versions | {version})
        tools = dict(self._state.tools)
        tools[name] = new_entry
        if reason:
            self._logger_event("tool_kill_switch", {
                "name": name, "version": version, "reason": reason, "actor": actor,
            })
        return self._commit(tools, actor=actor, event="tool_version_killed",
                            detail={"name": name, "version": version, "reason": reason})

    def revive_version(self, name: str, version: str, *, actor: str | None = None) -> int:
        entry = self._require_entry(name)
        new_entry = replace(entry, killed_versions=entry.killed_versions - {version})
        tools = dict(self._state.tools)
        tools[name] = new_entry
        return self._commit(tools, actor=actor, event="tool_version_revived",
                            detail={"name": name, "version": version})

    def kill_all(self, reason: str = "", *, actor: str | None = None) -> int:
        self._state = replace(
            self._state,
            revision=self._state.revision + 1,
            updated_at=datetime.now(timezone.utc),
            updated_by=actor,
            killed_all=True,
            kill_all_reason=reason,
        )
        self._logger_event("tool_kill_switch", {
            "name": "*", "reason": reason, "actor": actor,
            "revision": self._state.revision,
        })
        return self._state.revision

    def revive_all(self, *, actor: str | None = None) -> int:
        self._state = replace(
            self._state,
            revision=self._state.revision + 1,
            updated_at=datetime.now(timezone.utc),
            updated_by=actor,
            killed_all=False,
            kill_all_reason=None,
        )
        return self._state.revision

    # ── 批量原子提交（revision 只 +1）──
    def register_batch(
        self,
        definitions: list[ToolDefinition],
        *,
        activate: bool = True,
        replace_existing: bool = False,
        actor: str | None = None,
    ) -> int:
        """先验证整批，再替换一次 state；任一冲突则不提交。"""
        for definition in definitions:
            spec = definition.spec
            if not spec.name or len(spec.name) > 64:
                raise ConfigurationError(f"工具名非法或超过 64 字符: {spec.name!r}")
            if not spec.plugin_id:
                raise ConfigurationError(f"工具缺少 plugin_id: {spec.name}")
            if not spec.version:
                raise ConfigurationError(f"工具缺少版本: {spec.name}")
        tools = dict(self._state.tools)
        now = datetime.now(timezone.utc)
        changed = False
        for definition in definitions:
            name, version = definition.name, definition.version
            entry = tools.get(name)
            if entry is None:
                entry = ToolEntry(name=name, versions={}, stable_version=None, canary=None)
            existing = entry.versions.get(version)
            if existing is not None:
                if existing.fingerprint == definition.fingerprint:
                    continue
                if not replace_existing:
                    raise ToolVersionConflictError(name, version)
            versions = dict(entry.versions)
            versions[version] = VersionRecord(
                definition=definition,
                status=VersionStatus.ACTIVE,
                registered_at=now,
                fingerprint=definition.fingerprint,
            )
            stable = entry.stable_version
            if activate or stable is None:
                stable = version
            tools[name] = replace(entry, versions=versions, stable_version=stable)
            changed = True
        if not changed:
            return self._state.revision
        return self._commit(
            tools, actor=actor, event="tools_registered_batch",
            detail={"count": len(definitions)},
        )

    def unregister_plugin(self, plugin_id: str, *, actor: str | None = None) -> int:
        """整插件一次移除（所有工具、所有版本）。"""
        tools = {
            name: entry
            for name, entry in self._state.tools.items()
            if not self._entry_belongs(entry, plugin_id)
        }
        if len(tools) == len(self._state.tools):
            return self._state.revision
        return self._commit(
            tools, actor=actor, event="plugin_unregistered",
            detail={"plugin_id": plugin_id},
        )

    def disable_scope(
        self,
        plugin_id: str,
        *,
        tool_name: str | None = None,
        reason: str = "",
        actor: str | None = None,
    ) -> int:
        """范围内所有版本一次禁用，防止旧快照落到仍启用的历史版本。"""
        tools = dict(self._state.tools)
        changed = False
        for name, entry in tools.items():
            if tool_name is not None and name != tool_name:
                continue
            if not self._entry_belongs(entry, plugin_id):
                continue
            versions = {
                v: replace(record, status=VersionStatus.DISABLED)
                for v, record in entry.versions.items()
            }
            tools[name] = replace(entry, versions=versions, offline=True)
            changed = True
        if not changed:
            return self._state.revision
        return self._commit(
            tools, actor=actor, event="tools_offline",
            detail={"plugin_id": plugin_id, "tool_name": tool_name, "reason": reason},
        )

    def enable_latest_scope(
        self,
        plugin_id: str,
        *,
        tool_name: str | None = None,
        actor: str | None = None,
    ) -> int:
        """每个工具只启用并激活最新注册版本，其他版本保持禁用。"""
        tools = dict(self._state.tools)
        changed = False
        for name, entry in tools.items():
            if tool_name is not None and name != tool_name:
                continue
            if not self._entry_belongs(entry, plugin_id):
                continue
            if not entry.versions:
                continue
            latest = max(
                entry.versions.values(), key=lambda record: record.registered_at
            )
            latest_version = latest.definition.version
            versions = dict(entry.versions)
            versions[latest_version] = replace(
                versions[latest_version], status=VersionStatus.ACTIVE
            )
            tools[name] = replace(
                entry, versions=versions, stable_version=latest_version,
                offline=False,
            )
            changed = True
        if not changed:
            return self._state.revision
        return self._commit(
            tools, actor=actor, event="tools_online",
            detail={"plugin_id": plugin_id, "tool_name": tool_name},
        )

    @staticmethod
    def _entry_belongs(entry: ToolEntry, plugin_id: str) -> bool:
        return any(
            record.definition.spec.plugin_id == plugin_id
            for record in entry.versions.values()
        )

    # ── 快照选择 ──
    def build_refs(
        self,
        *,
        names: list[str] | None,
        task_id: str,
        actor: ActorContext,
        tenant_id: str | None = None,
    ) -> list[ToolRef]:
        wanted = list(names) if names is not None else sorted(self._state.tools.keys())
        refs: dict[str, ToolRef] = {}
        visiting: set[str] = set()

        def add(name: str) -> bool:
            if name in refs:
                return True
            if name in visiting:
                return True
            visiting.add(name)
            ref = self._select_ref(name, task_id=task_id, actor=actor, tenant_id=tenant_id)
            if ref is None:
                return False
            for dep in ref.dependencies:
                if dep.tool_name in refs:
                    continue
                dep_ok = add(dep.tool_name)
                if dep.required and not dep_ok:
                    return False
                if not dep.required:
                    continue
            refs[name] = ref
            return True

        for name in wanted:
            add(name)
        return [refs[n] for n in sorted(refs.keys())]

    def _select_ref(
        self,
        name: str,
        *,
        task_id: str,
        actor: ActorContext,
        tenant_id: str | None,
    ) -> ToolRef | None:
        if self._state.killed_all:
            return None
        entry = self._state.tools.get(name)
        if entry is None or entry.killed:
            return None

        version = entry.stable_version
        canary_hit = False
        if entry.canary and entry.canary.enabled:
            canary = entry.canary
            record = entry.versions.get(canary.version)
            if (
                record is not None
                and record.status == VersionStatus.ACTIVE
                and canary.version not in entry.killed_versions
                and self._canary_hit(task_id, name, canary, actor)
            ):
                version = canary.version
                canary_hit = True

        if version is None:
            return None
        record = entry.versions.get(version)
        if record is None:
            if entry.stable_version is None:
                return None
            record = entry.versions.get(entry.stable_version)
            version = entry.stable_version
            canary_hit = False
        if record is None:
            return None
        if version in entry.killed_versions or record.status == VersionStatus.DISABLED:
            # 灰度版本不可用自动回退 stable
            if canary_hit and entry.stable_version:
                record = entry.versions.get(entry.stable_version)
                version = entry.stable_version
                canary_hit = False
                if record is None or record.status == VersionStatus.DISABLED:
                    return None
            else:
                return None

        definition = record.definition
        gov = definition.governance
        if not gov.permissions.issubset(actor.granted_permissions):
            return None
        if gov.allowed_roles is not None and not (gov.allowed_roles & actor.roles):
            return None
        if gov.allowed_tenants is not None and tenant_id not in gov.allowed_tenants:
            return None

        return ToolRef(
            name=definition.name,
            version=definition.version,
            fingerprint=record.fingerprint,
            handler_id=definition.handler_id,
            risk_level=gov.risk_level,
            requires_confirmation=gov.needs_approval,
            parallelizable=gov.parallelizable,
            effect=gov.effect,
            dependencies=gov.dependencies,
            input_schema=definition.spec.input_schema,
            output_schema=definition.spec.output_schema,
            description=definition.spec.description,
            display_name=definition.spec.display_name,
            required_permissions=gov.permissions,
            allowed_roles=gov.allowed_roles,
            origin=definition.spec.origin,
            plugin_id=definition.spec.plugin_id,
        )

    @staticmethod
    def _canary_hit(task_id: str, name: str, canary: CanaryConfig,
                    actor: ActorContext) -> bool:
        if actor.actor_id and actor.actor_id in canary.allowlist:
            return True
        if canary.ratio <= 0:
            return False
        digest = hashlib.sha256(f"{task_id}:{name}".encode("utf-8")).hexdigest()[:8]
        return int(digest, 16) % 100 < canary.ratio

    # ── 管理面视图 ──
    def summary(self) -> dict[str, Any]:
        tools = []
        for name in sorted(self._state.tools.keys()):
            entry = self._state.tools[name]
            tools.append({
                "name": name,
                "stable_version": entry.stable_version,
                "canary": (
                    {
                        "version": entry.canary.version,
                        "ratio": entry.canary.ratio,
                        "allowlist": sorted(entry.canary.allowlist),
                        "enabled": entry.canary.enabled,
                    }
                    if entry.canary else None
                ),
                "killed": entry.killed,
                "kill_reason": entry.kill_reason,
                "killed_versions": sorted(entry.killed_versions),
                "origin": next(
                    (v.definition.spec.origin.value
                     for v in entry.versions.values()), "builtin"
                ),
                "plugin_id": next(
                    (v.definition.spec.plugin_id
                     for v in entry.versions.values()), "builtin.core"
                ),
                "online": any(
                    v.status == VersionStatus.ACTIVE
                    and v.definition.version not in entry.killed_versions
                    for v in entry.versions.values()
                ) and not entry.killed,
                "versions": [
                    {
                        "version": v.definition.version,
                        "status": v.status.value,
                        "fingerprint": v.fingerprint,
                        "risk_level": v.definition.governance.risk_level.value,
                        "requires_confirmation": v.definition.governance.needs_approval,
                        "effect": v.definition.governance.effect.value,
                        "origin": v.definition.spec.origin.value,
                        "plugin_id": v.definition.spec.plugin_id,
                        "required_permissions": sorted(
                            p.value for p in v.definition.governance.permissions
                        ),
                        "allowed_roles": (
                            sorted(v.definition.governance.allowed_roles)
                            if v.definition.governance.allowed_roles is not None
                            else None
                        ),
                    }
                    for v in sorted(entry.versions.values(),
                                    key=lambda item: item.definition.version)
                ],
            })
        return {
            "revision": self._state.revision,
            "killed_all": self._state.killed_all,
            "kill_all_reason": self._state.kill_all_reason,
            "updated_at": self._state.updated_at.isoformat(),
            "tools": tools,
        }

    def plugin_summary(self) -> list[dict[str, Any]]:
        """按 plugin_id 聚合的插件视图（启动真相源为 config 与内置目录）。"""
        plugins: dict[str, dict[str, Any]] = {}
        for name, entry in sorted(self._state.tools.items()):
            for record in entry.versions.values():
                spec = record.definition.spec
                plugin = plugins.setdefault(
                    spec.plugin_id,
                    {
                        "plugin_id": spec.plugin_id,
                        "origin": spec.origin.value,
                        "tools": {},
                    },
                )
                tool = plugin["tools"].setdefault(
                    name, {"name": name, "online": False, "versions": []}
                )
                online = (
                    record.status == VersionStatus.ACTIVE
                    and record.definition.version not in entry.killed_versions
                    and not entry.killed
                )
                tool["online"] = tool["online"] or online
                tool["versions"].append({
                    "version": record.definition.version,
                    "status": record.status.value,
                    "fingerprint": record.fingerprint,
                })
        result = []
        for plugin in plugins.values():
            plugin["tools"] = sorted(
                plugin["tools"].values(), key=lambda item: item["name"]
            )
            result.append(plugin)
        return sorted(result, key=lambda item: item["plugin_id"])

    # ── 内部 ──
    def _require_entry(self, name: str) -> ToolEntry:
        entry = self._state.tools.get(name)
        if entry is None:
            raise ValidationException(f"工具不存在: {name}")
        return entry

    def _commit(self, tools: dict[str, ToolEntry], *, actor: str | None,
                event: str, detail: dict) -> int:
        self._state = replace(
            self._state,
            revision=self._state.revision + 1,
            tools=tools,
            updated_at=datetime.now(timezone.utc),
            updated_by=actor,
        )
        self._logger_event(event, {
            **detail, "actor": actor, "revision": self._state.revision,
        })
        return self._state.revision

    @staticmethod
    def _logger_event(event: str, payload: dict) -> None:
        """注册表不主动依赖 logger，由审计/管理面记录；这里留空钩子避免循环依赖。"""
        return None


def governance_with_defaults(
    *,
    permissions: set[str] | frozenset,
    risk_level: RiskLevel,
    effect: ToolEffect,
    requires_confirmation: bool | None = None,
    parallelizable: bool = False,
    dependencies: tuple[ToolDependency, ...] = (),
    timeout_seconds: float = 30.0,
    total_timeout_seconds: float | None = None,
    retry_policy=None,
    audit_policy=None,
    allowed_tenants: frozenset[str] | None = None,
    allowed_roles: frozenset[str] | None = None,
) -> ToolGovernance:
    from app.core.tools.enums import ToolPermission
    from app.core.tools.definition import ToolAuditPolicy, ToolRetryPolicy

    return ToolGovernance(
        permissions=frozenset(
            p if isinstance(p, ToolPermission) else ToolPermission(p) for p in permissions
        ),
        risk_level=risk_level,
        effect=effect,
        requires_confirmation=requires_confirmation,
        parallelizable=parallelizable,
        dependencies=dependencies,
        timeout_seconds=timeout_seconds,
        total_timeout_seconds=total_timeout_seconds,
        retry_policy=retry_policy or ToolRetryPolicy(),
        audit_policy=audit_policy or ToolAuditPolicy(),
        allowed_tenants=allowed_tenants,
        allowed_roles=allowed_roles,
    )
