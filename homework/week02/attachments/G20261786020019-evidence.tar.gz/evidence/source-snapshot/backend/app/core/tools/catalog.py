"""内置工具目录：组装 ToolDefinition，注册前合并治理覆盖，再批量注册。

顺序约束：不得在 register() 后才应用 tools.json；fingerprint 不含治理字段且同指纹注册是 no-op，
后置覆盖会静默失效。
"""
from dataclasses import replace
from typing import Any

from app.core.exceptions import ConfigurationError
from app.core.tools.definition import ToolAuditPolicy, ToolDefinition, ToolRetryPolicy, ToolSpec
from app.core.tools.enums import (
    ModelAction,
    RiskLevel,
    ToolEffect,
    ToolErrorCategory,
    ToolOrigin,
    ToolPermission,
)
from app.core.tools.handlers import (
    bills,
    get_current_time,
    orders,
    send_email,
    shopping,
    web_search,
)
from app.core.tools.mcp.provider import register_mcp_servers
from app.core.tools.policy import apply_governance, load_policy
from app.core.tools.registry import ToolRegistry, governance_with_defaults

VERSION = "1.0.0"

_READ_RETRY = ToolRetryPolicy(
    max_retries=2,
    base_delay=0.5,
    retry_on=frozenset({
        ToolErrorCategory.TIMEOUT,
        ToolErrorCategory.NETWORK,
        ToolErrorCategory.RATE_LIMIT,
        ToolErrorCategory.UPSTREAM,
    }),
)

_ORDER_WRITE_RETRY = ToolRetryPolicy(
    max_retries=1,
    base_delay=0.5,
    retry_on=frozenset({ToolErrorCategory.NETWORK, ToolErrorCategory.UPSTREAM}),
)


def _make(
    *,
    name: str,
    description: str,
    input_model,
    handler,
    governance,
    plugin_id: str = "builtin.core",
    origin: ToolOrigin = ToolOrigin.BUILTIN,
    output_model=None,
    error_specs=(),
) -> ToolDefinition:
    spec = ToolSpec.create(
        name=name,
        version=VERSION,
        description=description,
        input_model=input_model,
        output_model=output_model,
        error_specs=error_specs,
        origin=origin,
        plugin_id=plugin_id,
    )
    return ToolDefinition(
        spec=spec,
        governance=governance,
        handler=handler,
        handler_id=f"{handler.__module__}.{handler.__name__}",
    )


def _builtin_definitions() -> list[ToolDefinition]:
    return [
        _make(
            name="get_current_time",
            description="获取指定时区的当前日期时间（无需联网）",
            input_model=get_current_time.GetCurrentTimeArgs,
            output_model=get_current_time.GetCurrentTimeOutput,
            handler=get_current_time.handle,
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE},
                risk_level=RiskLevel.LOW,
                effect=ToolEffect.READ_ONLY,
                parallelizable=True,
                timeout_seconds=5.0,
            ),
        ),
        _make(
            name="web_search",
            description="搜索互联网获取最新信息，支持按时间范围过滤",
            input_model=web_search.WebSearchArgs,
            output_model=web_search.WebSearchOutput,
            handler=web_search.handle,
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE, ToolPermission.NETWORK},
                risk_level=RiskLevel.LOW,
                effect=ToolEffect.READ_ONLY,
                parallelizable=True,
                timeout_seconds=30.0,
                total_timeout_seconds=90.0,
                retry_policy=_READ_RETRY,
            ),
        ),
        _make(
            name="send_email",
            description="发送邮件给指定收件人（需用户二次确认）",
            input_model=send_email.SendEmailArgs,
            output_model=send_email.SendEmailOutput,
            handler=send_email.handle,
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE, ToolPermission.EMAIL_SEND},
                risk_level=RiskLevel.HIGH,
                effect=ToolEffect.NON_IDEMPOTENT_WRITE,
                requires_confirmation=True,
                timeout_seconds=60.0,
                retry_policy=ToolRetryPolicy(max_retries=0),
                audit_policy=ToolAuditPolicy(
                    sensitive_fields=frozenset({"to", "cc", "body"}),
                ),
            ),
        ),
        # ── 生活缴费查询（mock）──
        *[
            _make(
                name=name,
                description=description,
                input_model=bills.BillQueryArgs,
                output_model=bills.BillOutput,
                handler=handler,
                plugin_id="builtin.bills",
                governance=governance_with_defaults(
                    permissions={ToolPermission.TOOL_USE, ToolPermission.BILL_QUERY},
                    risk_level=RiskLevel.LOW,
                    effect=ToolEffect.READ_ONLY,
                    parallelizable=True,
                    timeout_seconds=10.0,
                    retry_policy=ToolRetryPolicy(
                        max_retries=1,
                        retry_on=frozenset({
                            ToolErrorCategory.TIMEOUT, ToolErrorCategory.NETWORK,
                        }),
                    ),
                ),
            )
            for name, description, handler in (
                ("query_electricity_bill", "查询电费账单（mock 数据）", bills.handle_electricity),
                ("query_water_bill", "查询水费账单（mock 数据）", bills.handle_water),
                ("query_gas_bill", "查询燃气费账单（mock 数据）", bills.handle_gas),
            )
        ],
        # ── 购物审批流（mock）──
        _make(
            name="submit_shopping_request",
            description="提交购物申请，等待审批",
            input_model=shopping.SubmitShoppingRequestArgs,
            output_model=shopping.ShoppingRequestOutput,
            handler=shopping.handle_submit,
            plugin_id="builtin.shopping",
            governance=governance_with_defaults(
                permissions={
                    ToolPermission.TOOL_USE, ToolPermission.SHOPPING_REQUEST,
                },
                risk_level=RiskLevel.MEDIUM,
                effect=ToolEffect.NON_IDEMPOTENT_WRITE,
                requires_confirmation=False,
                timeout_seconds=10.0,
            ),
        ),
        _make(
            name="approve_shopping_request",
            description="审批购物申请（通过/拒绝，需用户二次确认）",
            input_model=shopping.ApproveShoppingRequestArgs,
            output_model=shopping.ShoppingRequestOutput,
            handler=shopping.handle_approve,
            plugin_id="builtin.shopping",
            governance=governance_with_defaults(
                permissions={
                    ToolPermission.TOOL_USE, ToolPermission.SHOPPING_APPROVE,
                },
                risk_level=RiskLevel.HIGH,
                effect=ToolEffect.NON_IDEMPOTENT_WRITE,
                requires_confirmation=True,
                timeout_seconds=10.0,
            ),
        ),
        _make(
            name="get_shopping_request",
            description="查询购物申请审批结果",
            input_model=shopping.GetShoppingRequestArgs,
            output_model=shopping.ShoppingRequestOutput,
            handler=shopping.handle_get,
            plugin_id="builtin.shopping",
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE},
                risk_level=RiskLevel.LOW,
                effect=ToolEffect.READ_ONLY,
                parallelizable=True,
                timeout_seconds=10.0,
            ),
        ),
        # ── 订单工具（mock）──
        _make(
            name="create_order",
            description="创建订单（幂等写，使用客户端去重号避免重复下单）",
            input_model=orders.CreateOrderArgs,
            output_model=orders.OrderOutput,
            handler=orders.handle_create_order,
            plugin_id="builtin.orders",
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE, ToolPermission.ORDER_CREATE},
                risk_level=RiskLevel.MEDIUM,
                effect=ToolEffect.IDEMPOTENT_WRITE,
                requires_confirmation=False,
                timeout_seconds=10.0,
                retry_policy=_ORDER_WRITE_RETRY,
            ),
            error_specs=(
                _err("IDEMPOTENCY_CONFLICT", ToolErrorCategory.BUSINESS,
                     "相同业务去重号的请求参数不一致", ModelAction.FIX_ARGUMENTS),
            ),
        ),
        _make(
            name="pay_order",
            description="支付订单（需用户二次确认，不可自动重试）",
            input_model=orders.PayOrderArgs,
            output_model=orders.OrderOutput,
            handler=orders.handle_pay_order,
            plugin_id="builtin.orders",
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE, ToolPermission.ORDER_PAY},
                risk_level=RiskLevel.HIGH,
                effect=ToolEffect.NON_IDEMPOTENT_WRITE,
                requires_confirmation=True,
                timeout_seconds=15.0,
                retry_policy=ToolRetryPolicy(max_retries=0),
            ),
            error_specs=(
                _err("PAYMENT_AMOUNT_MISMATCH", ToolErrorCategory.BUSINESS,
                     "支付金额与订单金额不一致", ModelAction.FIX_ARGUMENTS),
            ),
        ),
        _make(
            name="refund_order",
            description="订单退款（仅管理员，需用户二次确认，不可自动重试）",
            input_model=orders.RefundOrderArgs,
            output_model=orders.OrderOutput,
            handler=orders.handle_refund_order,
            plugin_id="builtin.orders",
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE, ToolPermission.ORDER_REFUND},
                risk_level=RiskLevel.CRITICAL,
                effect=ToolEffect.NON_IDEMPOTENT_WRITE,
                requires_confirmation=True,
                timeout_seconds=15.0,
                retry_policy=ToolRetryPolicy(max_retries=0),
                allowed_roles=frozenset({"admin"}),
            ),
            error_specs=(
                _err("REFUND_AMOUNT_EXCEEDED", ToolErrorCategory.BUSINESS,
                     "退款金额超过已付金额", ModelAction.FIX_ARGUMENTS),
            ),
        ),
        _make(
            name="query_order",
            description="查询订单（按订单号或状态，至少提供一个过滤条件）",
            input_model=orders.QueryOrderArgs,
            output_model=orders.QueryOrderOutput,
            handler=orders.handle_query_order,
            plugin_id="builtin.orders",
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE, ToolPermission.ORDER_QUERY},
                risk_level=RiskLevel.LOW,
                effect=ToolEffect.READ_ONLY,
                parallelizable=True,
                timeout_seconds=10.0,
                retry_policy=_READ_RETRY,
            ),
        ),
    ]


def _err(code: str, category: ToolErrorCategory, message: str,
         action: ModelAction):
    from app.core.tools.definition import ToolErrorSpec

    return ToolErrorSpec(
        code=code, category=category, model_message=message, model_action=action,
    )


def _validate_definitions(definitions: list[ToolDefinition]) -> None:
    seen: set[tuple[str, str]] = set()
    for definition in definitions:
        spec = definition.spec
        if not spec.name or len(spec.name) > 64:
            raise ConfigurationError(f"工具名非法或超过 64 字符: {spec.name!r}")
        if not spec.plugin_id:
            raise ConfigurationError(f"工具缺少 plugin_id: {spec.name}")
        if not isinstance(spec.input_schema, dict):
            raise ConfigurationError(f"工具 input_schema 非法: {spec.name}")
        key = (spec.name, spec.version)
        if key in seen:
            raise ConfigurationError(f"重复的工具定义: {spec.name}@{spec.version}")
        seen.add(key)


def build_default_registry(
    policy_path: str | None = None,
    actor: str | None = None,
    *,
    mcp_config_path: str | None = None,
    logger=None,
) -> ToolRegistry:
    """构建内置工具 + MCP 工具注册表；治理覆盖在注册前合并。"""
    registry = ToolRegistry()
    policy = load_policy(policy_path)
    overrides: dict[str, Any] = policy.get("tools", {}) if isinstance(policy, dict) else {}

    prepared: list[ToolDefinition] = []
    for definition in _builtin_definitions():
        override = overrides.get(definition.name, {})
        if override:
            definition = replace(
                definition,
                governance=apply_governance(override, definition.governance),
            )
        prepared.append(definition)

    _validate_definitions(prepared)
    registry.register_batch(prepared, activate=True, actor=actor)

    for definition in prepared:
        override = overrides.get(definition.name, {})
        if override.get("kill"):
            registry.kill(
                definition.name, override.get("kill_reason", "policy"), actor=actor,
            )
        if override.get("disabled"):
            registry.disable_version(
                definition.name, definition.version, reason="policy", actor=actor,
            )

    if policy.get("kill_all"):
        registry.kill_all(policy.get("kill_all_reason", "policy"), actor=actor)

    register_mcp_servers(
        registry, mcp_config_path, logger=logger,
        governance_overrides=overrides, actor=actor,
    )
    return registry


def registry_tool_names() -> list[str]:
    return [d.name for d in _builtin_definitions()]
