"""运行期注册表：支持按 run_id 取消正在执行的 Agent 循环。"""
import asyncio
from dataclasses import dataclass


@dataclass
class RunHandle:
    run_id: str
    cancel_event: asyncio.Event
    task: asyncio.Task | None = None


class RunService:
    """进程内运行注册表（单实例部署足够；多实例需外部状态存储）。"""

    def __init__(self) -> None:
        self._handles: dict[str, RunHandle] = {}

    def register(self, run_id: str, cancel_event: asyncio.Event) -> None:
        self._handles[run_id] = RunHandle(run_id=run_id, cancel_event=cancel_event)

    def attach_task(self, run_id: str, task: asyncio.Task) -> None:
        handle = self._handles.get(run_id)
        if handle:
            handle.task = task

    def cancel(self, run_id: str) -> bool:
        handle = self._handles.get(run_id)
        if handle is None:
            return False
        handle.cancel_event.set()
        if handle.task is not None and not handle.task.done():
            handle.task.cancel()
        return True

    def finish(self, run_id: str) -> None:
        self._handles.pop(run_id, None)

    def active_count(self) -> int:
        return len(self._handles)

    def is_active(self, run_id: str) -> bool:
        return run_id in self._handles
