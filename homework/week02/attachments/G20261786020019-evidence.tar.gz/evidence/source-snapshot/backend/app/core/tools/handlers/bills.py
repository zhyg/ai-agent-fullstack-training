"""水 / 电 / 燃气费查询 handler（mock 数据，只读）。"""
import hashlib
from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, Field, field_validator

from app.core.tools.definition import HandlerOutput
from app.core.tools.session import HandlerContext

BillKind = Literal["electricity", "water", "gas"]

_KIND_CONFIG: dict[str, dict] = {
    "electricity": {
        "display": "电费",
        "unit": "kWh",
        "usage_range": (80.0, 420.0),
        "price": 0.55,
        "company": "国家电网",
    },
    "water": {
        "display": "水费",
        "unit": "吨",
        "usage_range": (5.0, 30.0),
        "price": 3.2,
        "company": "城市供水公司",
    },
    "gas": {
        "display": "燃气费",
        "unit": "立方米",
        "usage_range": (8.0, 45.0),
        "price": 2.6,
        "company": "城市燃气公司",
    },
}


class BillQueryArgs(BaseModel):
    account_no: Annotated[str, Field(..., pattern=r"^\d{6,20}$", description="缴费户号，6~20 位数字")]
    month: Annotated[str, Field(..., description="账期，格式 YYYY-MM")]

    @field_validator("month")
    @classmethod
    def validate_month(cls, v: str) -> str:
        try:
            year_str, month_str = v.split("-")
            year, month = int(year_str), int(month_str)
        except (ValueError, AttributeError) as exc:
            raise ValueError("账期必须为 YYYY-MM") from exc
        if not 1 <= month <= 12 or not 2000 <= year <= 2100:
            raise ValueError("账期超出范围")
        return f"{year:04d}-{month:02d}"


class BillOutput(BaseModel):
    kind: BillKind
    account_no: str
    month: str
    usage: float
    usage_unit: str
    amount: float
    currency: str = "CNY"
    company: str
    status: str
    due_date: str


def _mock_bill(kind: BillKind, args: BillQueryArgs) -> BillOutput:
    config = _KIND_CONFIG[kind]
    digest = hashlib.sha256(
        f"{kind}:{args.account_no}:{args.month}".encode("utf-8")
    ).hexdigest()
    lo, hi = config["usage_range"]
    usage = round(lo + (int(digest[:8], 16) % 1000) / 1000.0 * (hi - lo), 2)
    amount = round(usage * config["price"], 2)
    year, month = (int(x) for x in args.month.split("-"))
    if month == 12:
        due = date(year + 1, 1, 15)
    else:
        due = date(year, month + 1, 15)
    paid = int(digest[8:10], 16) % 3 != 0
    return BillOutput(
        kind=kind,
        account_no=args.account_no,
        month=args.month,
        usage=usage,
        usage_unit=config["unit"],
        amount=amount,
        company=config["company"],
        status="paid" if paid else "unpaid",
        due_date=due.isoformat(),
    )


async def handle_electricity(args: BillQueryArgs, ctx: HandlerContext) -> HandlerOutput:
    return _handle("electricity", args)


async def handle_water(args: BillQueryArgs, ctx: HandlerContext) -> HandlerOutput:
    return _handle("water", args)


async def handle_gas(args: BillQueryArgs, ctx: HandlerContext) -> HandlerOutput:
    return _handle("gas", args)


def _handle(kind: BillKind, args: BillQueryArgs) -> HandlerOutput:
    bill = _mock_bill(kind, args)
    display = _KIND_CONFIG[kind]["display"]
    return HandlerOutput.of(
        bill,
        summary=(
            f"{args.month} {display}账单：用量 {bill.usage}{bill.usage_unit}，"
            f"应缴 {bill.amount} 元，状态 {bill.status}，截止 {bill.due_date}"
        ),
    )
