"""可复用 AgentRunner 接口 Schema。"""
from typing import Annotated, Literal

from pydantic import BaseModel, Field


class AgentRunRequest(BaseModel):
    """一次 Agent 运行请求。"""

    input: Annotated[str, Field(..., min_length=1, max_length=4000, description="用户输入")]
    model_id: Annotated[str | None, Field(None, max_length=64, description="模型 ID / 别名")] = None
    scene: Annotated[str | None, Field(None, max_length=64, description="场景名（model_id 为空时生效）")] = None
    system_prompt: Annotated[str | None, Field(None, max_length=8000, description="自定义 System Prompt")] = None
    tools: Annotated[list[str] | None, Field(None, description="启用的工具名，空表示全部")] = None
    max_rounds: Annotated[int | None, Field(None, ge=1, le=20, description="最大轮次")] = None
    timeout_seconds: Annotated[float | None, Field(None, ge=1.0, le=600.0, description="总超时（秒）")] = None
    token_budget: Annotated[int | None, Field(None, ge=0, description="token 预算，0 不限制")] = None
    stream: Annotated[bool, Field(True, description="LLM 是否流式输出（均返回最终结果）")] = True


class TokenUsageOut(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class AgentRunResponse(BaseModel):
    """非流式运行结果。"""

    run_id: str
    trace_id: str
    status: Literal["completed", "failed", "cancelled"]
    answer: str = ""
    rounds: int = 0
    tool_calls: int = 0
    usage: TokenUsageOut = Field(default_factory=TokenUsageOut)
    elapsed_ms: int = 0
    error_type: str | None = None
    error_message: str | None = None


class RunCancelResponse(BaseModel):
    run_id: str
    cancelled: bool
    active_runs: int = 0


class RunEventItem(BaseModel):
    """SSE 事件（type 为事件名，data 为载荷）。"""

    type: Literal[
        "run_started", "round_started", "token", "tool_call",
        "tool_result", "final", "error", "run_finished",
    ]
    data: dict = Field(default_factory=dict)
