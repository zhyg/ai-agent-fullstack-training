"""运维接口：请求记录查询 + 异常链路查询 + token 用量统计 + 工具治理。"""
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query, Request

from app.api.schemas.admin import (
    ErrorTraceItem,
    ErrorTraceList,
    RequestLogItem,
    RequestLogPage,
    RequestLogQuery,
    ToolActiveRequest,
    ToolCanaryRequest,
    ToolCallsResponse,
    ToolKillRequest,
    UsageStatItem,
    UsageStatsResponse,
)
from app.api.schemas.admin import (
    PluginInstallRequest,
    PluginScopeRequest,
)
from app.api.schemas.common import ApiResponse, ok
from app.container import container
from app.core.exceptions import ForbiddenException, UnauthorizedException


async def require_admin(request: Request) -> str:
    """实时读取数据库角色；不信任启动时角色，`/admin` 全部接口强制校验。"""
    actor_id = getattr(request.state, "actor_id", None)
    if not actor_id:
        raise UnauthorizedException("缺少调用者身份")
    permission_service = container.permission_service
    if permission_service is None or not await permission_service.is_admin(actor_id):
        raise ForbiddenException("需要管理员角色")
    return actor_id


router = APIRouter(
    prefix="/admin", tags=["admin"], dependencies=[Depends(require_admin)]
)

ToolNamePath = Annotated[
    str, Path(..., pattern=r"^[a-z][a-z0-9_]{1,63}$", description="工具名")
]
ToolVersionPath = Annotated[
    str, Path(..., pattern=r"^[0-9A-Za-z._-]{1,32}$", description="工具版本")
]


def _query_params(
    trace_id: Annotated[str | None, Query(description="按 trace_id 过滤")] = None,
    model_id: Annotated[str | None, Query(description="按模型过滤")] = None,
    status: Annotated[str | None, Query(description="按状态过滤 success/failed/cancelled")] = None,
    start_time: Annotated[str | None, Query(description="开始时间 ISO8601")] = None,
    end_time: Annotated[str | None, Query(description="结束时间 ISO8601")] = None,
    page: Annotated[int, Query(ge=1, description="页码，从 1 开始")] = 1,
    page_size: Annotated[int, Query(ge=1, le=100, description="每页条数")] = 20,
) -> RequestLogQuery:
    return RequestLogQuery(
        trace_id=trace_id, model_id=model_id, status=status,
        start_time=start_time, end_time=end_time,
        page=page, page_size=page_size,
    )


@router.get("/requests", response_model=ApiResponse[RequestLogPage])
async def query_requests(query: RequestLogQuery = Depends(_query_params)):
    """请求记录分页查询。"""
    total, rows = await container.db.query_request_logs(query)
    return ok(RequestLogPage(
        total=total,
        page=query.page,
        page_size=query.page_size,
        items=[RequestLogItem(**r) for r in rows],
    ))


@router.get("/traces/{trace_id}", response_model=ApiResponse[ErrorTraceList])
async def get_error_traces(
    trace_id: Annotated[str, Path(..., min_length=1, max_length=64, description="追踪 ID")],
):
    """异常链路：该 trace_id 下所有阶段的异常列表。"""
    rows = await container.db.get_error_traces(trace_id)
    return ok(ErrorTraceList(
        trace_id=trace_id,
        items=[ErrorTraceItem(**r) for r in rows],
    ))


@router.get("/usage", response_model=ApiResponse[UsageStatsResponse])
async def usage_stats(
    start_time: Annotated[str | None, Query(description="开始时间 ISO8601")] = None,
    end_time: Annotated[str | None, Query(description="结束时间 ISO8601")] = None,
):
    """token 用量统计：总量 + 按模型聚合。"""
    stats = await container.db.query_usage_stats(start_time, end_time)
    return ok(UsageStatsResponse(
        totals=UsageStatItem(**stats["totals"]),
        models=[UsageStatItem(**m) for m in stats["models"]],
    ))


# ── 工具注册表治理 ──
def _registry():
    if container.tool_registry is None:
        from app.core.exceptions import ConfigurationError
        raise ConfigurationError("工具注册表未初始化")
    return container.tool_registry


def _actor(request: Request) -> str | None:
    return getattr(request.state, "actor_id", None)


@router.get("/tools")
async def list_tools():
    """工具列表：版本、灰度、kill 状态与当前 revision。"""
    return ok(_registry().summary())


@router.post("/tools/kill-all")
async def kill_all_tools(req: ToolKillRequest, request: Request):
    """全局 kill switch：立即拦截所有工具执行（内存生效）。"""
    registry = _registry()
    revision = registry.kill_all(req.reason, actor=_actor(request))
    return ok({"revision": revision, "killed_all": True})


@router.post("/tools/revive-all")
async def revive_all_tools(request: Request):
    registry = _registry()
    revision = registry.revive_all(actor=_actor(request))
    return ok({"revision": revision, "killed_all": False})


@router.post("/tools/{tool_name}/kill")
async def kill_tool(
    tool_name: ToolNamePath, req: ToolKillRequest, request: Request,
):
    """紧急禁用工具或指定版本，已构建快照的下一次执行会被拦截。"""
    registry = _registry()
    if req.version:
        revision = registry.kill_version(
            tool_name, req.version, req.reason, actor=_actor(request),
        )
    else:
        revision = registry.kill(
            tool_name, req.reason, actor=_actor(request),
        )
    return ok({"revision": revision, "tool": tool_name, "version": req.version})


@router.post("/tools/{tool_name}/revive")
async def revive_tool(tool_name: ToolNamePath, request: Request):
    registry = _registry()
    revision = registry.revive(tool_name, actor=_actor(request))
    return ok({"revision": revision, "tool": tool_name})


@router.post("/tools/{tool_name}/active")
async def set_tool_active(
    tool_name: ToolNamePath, req: ToolActiveRequest, request: Request,
):
    """切换默认版本：下一轮快照生效。"""
    registry = _registry()
    revision = registry.set_active(
        tool_name, req.version, actor=_actor(request),
    )
    return ok({"revision": revision, "tool": tool_name, "version": req.version})


@router.post("/tools/{tool_name}/canary")
async def set_tool_canary(
    tool_name: ToolNamePath, req: ToolCanaryRequest, request: Request,
):
    registry = _registry()
    revision = registry.set_canary(
        tool_name, version=req.version, ratio=req.ratio,
        allowlist=req.allowlist, enabled=req.enabled,
        actor=_actor(request),
    )
    return ok({"revision": revision, "tool": tool_name, "version": req.version})


@router.post("/tools/{tool_name}/versions/{version}/disable")
async def disable_tool_version(
    tool_name: ToolNamePath, version: ToolVersionPath, request: Request,
):
    registry = _registry()
    revision = registry.disable_version(
        tool_name, version, reason="admin", actor=_actor(request),
    )
    return ok({"revision": revision, "tool": tool_name, "version": version})


@router.post("/tools/{tool_name}/versions/{version}/enable")
async def enable_tool_version(
    tool_name: ToolNamePath, version: ToolVersionPath, request: Request,
):
    registry = _registry()
    revision = registry.enable_version(
        tool_name, version, actor=_actor(request),
    )
    return ok({"revision": revision, "tool": tool_name, "version": version})


# ── 插件管理（内置目录 / MCP / 动态插件）──
PluginIdPath = Annotated[
    str, Path(..., pattern=r"^[A-Za-z0-9._-]{1,64}$", description="插件 ID")
]


def _plugin_manager():
    if container.plugin_manager is None:
        from app.core.exceptions import ConfigurationError
        raise ConfigurationError("插件管理器未初始化")
    return container.plugin_manager


@router.get("/plugins")
async def list_plugins():
    """插件列表：来源、工具版本与在线状态。"""
    return ok({"plugins": _plugin_manager().list()})


@router.post("/plugins/{plugin_id}/install")
async def install_plugin(plugin_id: PluginIdPath, req: PluginInstallRequest):
    """安装：仅允许服务端预注册工厂；动态安装不持久化。"""
    revision = await _plugin_manager().install(plugin_id, activate=req.activate)
    return ok({
        "revision": revision,
        "plugin_id": plugin_id,
        "persistence": "memory_only",
    })


@router.post("/plugins/{plugin_id}/uninstall")
async def uninstall_plugin(plugin_id: PluginIdPath):
    revision = await _plugin_manager().uninstall(plugin_id)
    return ok({
        "revision": revision,
        "plugin_id": plugin_id,
        "persistence": "memory_only",
    })


@router.post("/plugins/{plugin_id}/offline")
async def offline_plugin(plugin_id: PluginIdPath, req: PluginScopeRequest):
    """插件或单工具下架：范围内所有版本立即失效。"""
    revision = _plugin_manager().offline(
        plugin_id, tool_name=req.tool_name, reason=req.reason,
    )
    return ok({
        "revision": revision,
        "plugin_id": plugin_id,
        "tool": req.tool_name,
        "online": False,
        "persistence": "memory_only",
    })


@router.post("/plugins/{plugin_id}/online")
async def online_plugin(plugin_id: PluginIdPath, req: PluginScopeRequest):
    """上架：每个工具只启用并激活最新注册版本。"""
    revision = _plugin_manager().online(plugin_id, tool_name=req.tool_name)
    return ok({
        "revision": revision,
        "plugin_id": plugin_id,
        "tool": req.tool_name,
        "online": True,
        "persistence": "memory_only",
    })


@router.get("/tool-calls", response_model=ApiResponse[ToolCallsResponse])
async def list_tool_calls(
    trace_id: Annotated[str | None, Query(description="按 trace_id 过滤")] = None,
    task_id: Annotated[str | None, Query(description="按 task_id 过滤")] = None,
    tool_name: Annotated[str | None, Query(description="按工具名过滤")] = None,
    limit: Annotated[int, Query(ge=1, le=200, description="返回条数")] = 50,
):
    """工具审计记录：按 trace / task / tool 查询。"""
    rows = await container.db.query_tool_calls(
        trace_id=trace_id, task_id=task_id, tool_name=tool_name, limit=limit,
    )
    return ok(ToolCallsResponse(items=rows))
