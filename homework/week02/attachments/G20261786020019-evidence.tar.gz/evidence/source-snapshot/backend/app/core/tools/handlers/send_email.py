"""邮件发送 handler（原 SendEmailTool 迁移；非幂等写操作）。"""
from email.message import EmailMessage
from typing import Annotated

import aiosmtplib
from pydantic import BaseModel, EmailStr, Field

from app.config import settings
from app.core.tools.definition import HandlerOutput
from app.core.tools.enums import ErrorPhase, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError
from app.core.tools.session import HandlerContext


class SendEmailArgs(BaseModel):
    to: Annotated[EmailStr, Field(..., description="收件人邮箱")]
    subject: Annotated[str, Field(..., min_length=1, max_length=200, description="邮件主题")]
    body: Annotated[str, Field(..., min_length=1, description="邮件正文")]
    cc: Annotated[list[EmailStr] | None, Field(None, description="抄送人列表")] = None


class SendEmailOutput(BaseModel):
    to: str
    subject: str
    accepted: bool = True


async def handle(args: SendEmailArgs, ctx: HandlerContext) -> HandlerOutput:
    if not all([
        settings.send_email_smtp_host,
        settings.send_email_smtp_user,
        settings.send_email_smtp_password,
    ]):
        raise ToolBusinessError(
            category=ToolErrorCategory.AUTH,
            code="EMAIL_CONFIG_MISSING",
            message="邮件 SMTP 配置不完整",
            model_message="邮件服务配置不完整，无法发送",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    auth_code = settings.send_email_smtp_password.strip()
    if " " in auth_code:
        raise ToolBusinessError(
            category=ToolErrorCategory.AUTH,
            code="EMAIL_CONFIG_INVALID",
            message="SMTP 授权码包含非法空格",
            model_message="邮件服务配置不正确",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )

    msg = EmailMessage()
    msg["From"] = (
        f"{settings.send_email_from_name} <{settings.send_email_smtp_user}>"
        if settings.send_email_from_name
        else settings.send_email_smtp_user
    )
    msg["To"] = args.to
    if args.cc:
        msg["Cc"] = ", ".join(args.cc)
    msg["Subject"] = args.subject
    msg.set_content(args.body)

    kwargs = {
        "hostname": settings.send_email_smtp_host,
        "port": settings.send_email_smtp_port,
        "username": settings.send_email_smtp_user,
        "password": auth_code,
        "timeout": 30.0,
    }
    if settings.send_email_smtp_use_ssl:
        kwargs["use_tls"] = True
    else:
        kwargs["start_tls"] = True

    try:
        await aiosmtplib.send(msg, **kwargs)
    except aiosmtplib.SMTPAuthenticationError as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.BUSINESS,
            code="EMAIL_AUTH_FAILED",
            message=f"SMTP 认证失败: {exc.code} {exc.message}",
            model_message="邮件认证失败，请检查 SMTP 授权码与账号配置",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        ) from exc
    except aiosmtplib.SMTPConnectError as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.NETWORK,
            code="EMAIL_CONNECT_FAILED",
            message=f"SMTP 连接失败: {exc.code} {exc.message}",
            model_message="邮件服务连接失败",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        ) from exc
    except aiosmtplib.SMTPTimeoutError as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.TIMEOUT,
            code="1608",
            message="SMTP 连接超时",
            model_message="邮件发送超时，结果可能不确定",
            phase=ErrorPhase.POST_SIDE_EFFECT,
        ) from exc
    except aiosmtplib.SMTPException as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.BUSINESS,
            code="EMAIL_SEND_FAILED",
            message=f"邮件发送失败: {exc}",
            model_message="邮件发送失败",
            phase=ErrorPhase.UNKNOWN,
        ) from exc

    output = SendEmailOutput(to=args.to, subject=args.subject, accepted=True)
    return HandlerOutput.of(output, summary=f"邮件已发送至 {args.to}")
