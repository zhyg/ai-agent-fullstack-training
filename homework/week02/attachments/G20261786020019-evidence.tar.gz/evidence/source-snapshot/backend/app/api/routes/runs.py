"""可复用 AgentRunner 接口：非流式 / SSE 流式运行与取消。"""
import asyncio
import json

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from app.api.schemas.run import (
    AgentRunRequest,
    AgentRunResponse,
    RunCancelResponse,
    TokenUsageOut,
)
from app.config import settings
from app.container import container
from app.core.exceptions import AppException, ModelNotAvailableException
from app.core.runner import AgentRunner, RunLimits, RunResult
from app.core.runtime import gen_run_id
from app.llm.registry import get_model_info

router = APIRouter(prefix="/runs", tags=["runs"])


def _limits(req: AgentRunRequest) -> RunLimits:
    return RunLimits(
        max_rounds=req.max_rounds or settings.run_max_rounds,
        timeout_seconds=req.timeout_seconds or settings.run_timeout_seconds,
        token_budget=(
            settings.run_token_budget if req.token_budget is None else req.token_budget
        ),
    )


def _resolve_model(req: AgentRunRequest) -> str:
    model_id = container.gateway.resolve_model(req.model_id, req.scene) or settings.default_model
    if get_model_info(model_id) is None:
        raise ModelNotAvailableException(model_id)
    # 提前校验工具名，避免 SSE 建立后才报错
    if container.tool_registry is not None:
        container.tool_registry.validate_names(req.tools)
    return model_id


def _response(result: RunResult) -> AgentRunResponse:
    return AgentRunResponse(
        run_id=result.run_id,
        trace_id=result.trace_id,
        status=result.status,
        answer=result.answer,
        rounds=result.rounds,
        tool_calls=result.tool_calls,
        usage=TokenUsageOut(**result.usage.model_dump()),
        elapsed_ms=result.elapsed_ms,
        error_type=result.error_type,
        error_message=result.error_message,
    )


@router.post("", response_model=AgentRunResponse)
async def run_once(req: AgentRunRequest, request: Request):
    """非流式运行：阻塞直到循环结束，返回最终结果与用量。"""
    model_id = _resolve_model(req)
    actor_id = getattr(request.state, "actor_id", None)
    run_id = gen_run_id()
    cancel_event = asyncio.Event()
    container.run_service.register(run_id, cancel_event)
    runner = AgentRunner(
        container.gateway,
        tool_runtime=container.tool_runtime,
        permission_service=container.permission_service,
        stream_output=req.stream,
    )
    try:
        result = await runner.run(
            user_input=req.input,
            model_id=model_id,
            scene=None,
            system_prompt=req.system_prompt,
            tool_names=req.tools,
            limits=_limits(req),
            cancel_event=cancel_event,
            run_id=run_id,
            actor_id=actor_id,
        )
        return _response(result)
    finally:
        container.run_service.finish(run_id)


@router.post("/stream")
async def run_stream(req: AgentRunRequest, request: Request):
    """SSE 流式运行：输出 token / tool_call / tool_result / final / error / run_finished。"""
    model_id = _resolve_model(req)
    actor_id = getattr(request.state, "actor_id", None)
    run_id = gen_run_id()
    cancel_event = asyncio.Event()
    queue: asyncio.Queue = asyncio.Queue()
    runner = AgentRunner(
        container.gateway,
        tool_runtime=container.tool_runtime,
        permission_service=container.permission_service,
        stream_output=req.stream,
    )
    service = container.run_service
    service.register(run_id, cancel_event)

    async def emit(event_type: str, data: dict) -> None:
        await queue.put((event_type, data))

    async def produce() -> None:
        try:
            await runner.run(
                user_input=req.input,
                model_id=model_id,
                scene=None,
                system_prompt=req.system_prompt,
                tool_names=req.tools,
                limits=_limits(req),
                cancel_event=cancel_event,
                on_event=emit,
                run_id=run_id,
                actor_id=actor_id,
            )
        except asyncio.CancelledError:
            await emit("error", {
                "error_type": "cancelled",
                "message": "运行已取消",
                "retryable": False,
            })
            await emit("run_finished", {"run_id": run_id, "status": "cancelled"})
        except AppException as e:
            await emit("error", {
                "error_type": e.code.value,
                "message": e.message,
                "retryable": e.retryable,
            })
            await emit("run_finished", {"run_id": run_id, "status": "failed"})
        except Exception as e:  # 兜底，保证 SSE 一定收尾
            await emit("error", {
                "error_type": "internal_error",
                "message": str(e),
                "retryable": False,
            })
            await emit("run_finished", {"run_id": run_id, "status": "failed"})
        finally:
            await queue.put(None)
            service.finish(run_id)

    task = asyncio.create_task(produce())
    service.attach_task(run_id, task)

    async def gen():
        try:
            while True:
                item = await queue.get()
                if item is None:
                    break
                event_type, data = item
                yield f"event: {event_type}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
        finally:
            # 客户端断开时取消后台运行
            service.cancel(run_id)

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/{run_id}/cancel", response_model=RunCancelResponse)
async def cancel_run(run_id: str):
    """取消正在运行的循环（流式任务会立即中断）。"""
    cancelled = container.run_service.cancel(run_id)
    return RunCancelResponse(
        run_id=run_id,
        cancelled=cancelled,
        active_runs=container.run_service.active_count(),
    )
