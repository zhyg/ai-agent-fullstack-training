"""审计：tool_calls 落库 + structlog 事件 + 失败时 error_traces。"""
from app.core.tools.enums import ToolExecutionStatus
from app.core.tools.result import ToolAuditRecord
from app.infra.db import Database

_ECHO_EVENTS = {
    ToolExecutionStatus.SUCCESS: "tool_executed",
    ToolExecutionStatus.INVALID_INPUT: "tool_rejected",
    ToolExecutionStatus.PERMISSION_DENIED: "tool_rejected",
    ToolExecutionStatus.APPROVAL_DENIED: "tool_rejected",
    ToolExecutionStatus.APPROVAL_TIMEOUT: "tool_rejected",
    ToolExecutionStatus.TOOL_DISABLED: "tool_rejected",
    ToolExecutionStatus.VERSION_STALE: "tool_rejected",
    ToolExecutionStatus.SNAPSHOT_EXPIRED: "tool_rejected",
    ToolExecutionStatus.DEPENDENCY_NOT_MET: "tool_rejected",
    ToolExecutionStatus.TIMEOUT: "tool_failed",
    ToolExecutionStatus.CANCELLED: "tool_failed",
    ToolExecutionStatus.FAILED: "tool_failed",
    ToolExecutionStatus.OUTPUT_INVALID: "tool_failed",
}


def audit_stage(status: ToolExecutionStatus) -> str:
    if status in {
        ToolExecutionStatus.INVALID_INPUT,
        ToolExecutionStatus.PERMISSION_DENIED,
        ToolExecutionStatus.APPROVAL_DENIED,
        ToolExecutionStatus.APPROVAL_TIMEOUT,
        ToolExecutionStatus.TOOL_DISABLED,
        ToolExecutionStatus.VERSION_STALE,
        ToolExecutionStatus.SNAPSHOT_EXPIRED,
        ToolExecutionStatus.DEPENDENCY_NOT_MET,
    }:
        return "tool_validation"
    if status == ToolExecutionStatus.OUTPUT_INVALID:
        return "tool_output"
    return "tool_execution"


class ToolAuditor:
    def __init__(self, db: Database | None, logger, *, enabled: bool = True):
        self._db = db
        self._logger = logger
        self._enabled = enabled

    async def record(self, record: ToolAuditRecord) -> None:
        payload = record.model_dump(mode="json")

        event = _ECHO_EVENTS.get(record.status, "tool_executed")
        self._logger.info(
            event,
            audit_id=record.audit_id,
            trace_id=record.trace_id,
            task_id=record.task_id,
            tool_call_id=record.tool_call_id,
            tool_name=record.tool_name,
            tool_version=record.tool_version,
            status=record.status.value,
            error_category=(
                record.error_category.value if record.error_category else None
            ),
            error_code=record.error_code,
            retry_count=record.retry_count,
            duration_ms=record.duration_ms,
            actor_id=record.actor_id,
            snapshot_id=record.snapshot_id,
            registry_revision=record.registry_revision,
            possible_side_effect=record.possible_side_effect,
        )

        if not self._enabled or self._db is None:
            return

        try:
            await self._db.insert_tool_audit(payload)
        except Exception:  # 审计失败不阻断工具结果回灌
            self._logger.error(
                "tool_audit_persist_failed",
                audit_id=record.audit_id,
                tool_call_id=record.tool_call_id,
                exc_info=True,
            )

        if record.status != ToolExecutionStatus.SUCCESS:
            try:
                await self._db.insert_error_trace(
                    trace_id=record.trace_id,
                    request_id=None,
                    stage=audit_stage(record.status),
                    error_type=(
                        record.error_code or record.status.value
                    ),
                    message=record.output_preview or record.status.value,
                    stack_trace=None,
                    retry_count=record.retry_count,
                    strategy=record.retry_strategy,
                )
            except Exception:
                self._logger.error(
                    "tool_error_trace_persist_failed",
                    audit_id=record.audit_id,
                    exc_info=True,
                )
