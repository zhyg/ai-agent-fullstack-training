"""订单工具 handler（mock 数据，内存存储 + 业务去重）。

状态流转：created ──pay──→ paid ──refund──→ refunded
所有查重、参数哈希比较与写入都在同一个 `_lock` 临界区内完成。
"""
import asyncio
import uuid
from datetime import datetime, timezone
from typing import Annotated, Literal

from pydantic import BaseModel, Field, model_validator

from app.core.tools.definition import HandlerOutput
from app.core.tools.enums import ErrorPhase, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError
from app.core.tools.redaction import stable_hash
from app.core.tools.session import HandlerContext

_orders: dict[str, dict] = {}
_create_requests: dict[tuple[str, str], dict] = {}
_payment_requests: dict[tuple[str, str], dict] = {}
_lock = asyncio.Lock()

# 仅由测试设置，不进入模型可见 input schema
_FAULT_INJECT = {"timeout": False, "network": False}

OrderStatus = Literal["created", "paid", "refunded"]


# ── 入参 / 出参 ──
class CreateOrderArgs(BaseModel):
    product_id: Annotated[str, Field(..., min_length=1, max_length=64, description="商品 ID")]
    product_name: Annotated[str, Field(..., min_length=1, max_length=200, description="商品名称")]
    quantity: Annotated[int, Field(1, ge=1, le=999, description="购买数量")]
    unit_price: Annotated[float, Field(..., gt=0, le=1_000_000, description="单价")]
    currency: Annotated[Literal["CNY", "USD"], Field("CNY", description="币种")] = "CNY"
    client_order_no: Annotated[
        str, Field(..., min_length=1, max_length=64, description="客户端下单去重号")
    ]


class PayOrderArgs(BaseModel):
    order_id: Annotated[str, Field(..., min_length=1, max_length=64, description="订单 ID")]
    amount: Annotated[float | None, Field(None, gt=0, description="支付金额，缺省为订单金额")] = None
    method: Annotated[Literal["balance", "card"], Field(..., description="支付方式")]
    client_payment_no: Annotated[
        str, Field(..., min_length=1, max_length=64, description="客户端支付去重号")
    ]


class RefundOrderArgs(BaseModel):
    order_id: Annotated[str, Field(..., min_length=1, max_length=64, description="订单 ID")]
    amount: Annotated[float | None, Field(None, gt=0, description="退款金额，缺省为已付金额")] = None
    reason: Annotated[str, Field(..., min_length=1, max_length=500, description="退款原因")]


class QueryOrderArgs(BaseModel):
    order_id: Annotated[str | None, Field(None, min_length=1, max_length=64, description="订单 ID")] = None
    status: Annotated[OrderStatus | None, Field(None, description="按状态过滤")] = None
    limit: Annotated[int, Field(20, ge=1, le=100, description="返回条数上限")] = 20

    @model_validator(mode="after")
    def require_filter(self) -> "QueryOrderArgs":
        if not self.order_id and not self.status:
            raise ValueError("order_id 与 status 至少提供一个")
        return self


class OrderOutput(BaseModel):
    order_id: str
    status: OrderStatus
    product_id: str
    product_name: str
    quantity: int
    unit_price: float
    currency: str
    amount: float
    client_order_no: str
    created_at: str
    updated_at: str
    paid_amount: float = 0.0
    payment_method: str | None = None
    refunded_amount: float = 0.0
    refund_reason: str | None = None


class QueryOrderOutput(BaseModel):
    orders: list[OrderOutput]
    total: int


# ── 内部工具 ──
def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _amount(record: dict) -> float:
    return round(record["quantity"] * record["unit_price"], 2)


def _to_output(record: dict) -> OrderOutput:
    return OrderOutput(
        order_id=record["order_id"],
        status=record["status"],
        product_id=record["product_id"],
        product_name=record["product_name"],
        quantity=record["quantity"],
        unit_price=record["unit_price"],
        currency=record["currency"],
        amount=record["amount"],
        client_order_no=record["client_order_no"],
        created_at=record["created_at"],
        updated_at=record["updated_at"],
        paid_amount=record["paid_amount"],
        payment_method=record.get("payment_method"),
        refunded_amount=record["refunded_amount"],
        refund_reason=record.get("refund_reason"),
    )


def _require_actor(ctx: HandlerContext) -> str:
    if not ctx.actor_id:
        raise ToolBusinessError(
            category=ToolErrorCategory.PERMISSION,
            code="ORDER_ACTOR_REQUIRED",
            message="订单操作需要已认证用户",
            model_message="当前会话缺少用户身份，无法操作订单",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    return ctx.actor_id


def _args_hash(model: BaseModel) -> str:
    return stable_hash(model.model_dump(mode="json"))


def _maybe_fault() -> None:
    if _FAULT_INJECT.get("timeout"):
        raise asyncio.TimeoutError("injected timeout")
    if _FAULT_INJECT.get("network"):
        raise ToolBusinessError(
            category=ToolErrorCategory.NETWORK,
            code="TOOL_NETWORK_ERROR",
            message="注入的网络故障",
            model_message="外部服务连接失败",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )


def _not_found() -> ToolBusinessError:
    return ToolBusinessError(
        category=ToolErrorCategory.NOT_FOUND,
        code="ORDER_NOT_FOUND",
        message="订单不存在或不属于当前用户",
        model_message="订单不存在",
        phase=ErrorPhase.PRE_SIDE_EFFECT,
    )


def _conflict() -> ToolBusinessError:
    return ToolBusinessError(
        category=ToolErrorCategory.BUSINESS,
        code="IDEMPOTENCY_CONFLICT",
        message="相同业务去重号使用了不同参数",
        model_message="相同业务去重号的请求参数不一致，请核对后重试",
        phase=ErrorPhase.PRE_SIDE_EFFECT,
    )


# ── handlers ──
async def handle_create_order(
    args: CreateOrderArgs, ctx: HandlerContext
) -> HandlerOutput:
    actor = _require_actor(ctx)
    key = (actor, args.client_order_no)
    digest = _args_hash(args)
    async with _lock:
        _maybe_fault()
        existing = _create_requests.get(key)
        if existing is not None:
            if existing["hash"] != digest:
                raise _conflict()
            record = _orders[existing["order_id"]]
            return HandlerOutput.of(
                _to_output(record),
                summary=f"订单已存在（幂等返回）：{record['order_id']}，状态 {record['status']}",
            )

        timestamp = _now()
        order_id = f"ord_{uuid.uuid4().hex[:12]}"
        record = {
            "order_id": order_id,
            "owner_actor_id": actor,
            "status": "created",
            "product_id": args.product_id,
            "product_name": args.product_name,
            "quantity": args.quantity,
            "unit_price": args.unit_price,
            "currency": args.currency,
            "amount": _amount(args.model_dump()),
            "client_order_no": args.client_order_no,
            "created_at": timestamp,
            "updated_at": timestamp,
            "paid_amount": 0.0,
            "payment_method": None,
            "refunded_amount": 0.0,
            "refund_reason": None,
        }
        _orders[order_id] = record
        _create_requests[key] = {"hash": digest, "order_id": order_id}
    return HandlerOutput.of(
        _to_output(record),
        summary=(
            f"订单已创建：{args.product_name} × {args.quantity}，"
            f"金额 {record['amount']} {args.currency}，单号 {order_id}"
        ),
    )


async def handle_pay_order(args: PayOrderArgs, ctx: HandlerContext) -> HandlerOutput:
    actor = _require_actor(ctx)
    key = (actor, args.client_payment_no)
    digest = _args_hash(args)
    async with _lock:
        _maybe_fault()
        existing = _payment_requests.get(key)
        if existing is not None:
            if existing["hash"] != digest:
                raise _conflict()
            record = _orders[existing["order_id"]]
            return HandlerOutput.of(
                _to_output(record),
                summary=f"支付已处理（幂等返回）：{record['order_id']}，状态 {record['status']}",
            )

        record = _orders.get(args.order_id)
        if record is None or record["owner_actor_id"] != actor:
            raise _not_found()
        if record["status"] == "paid":
            raise ToolBusinessError(
                category=ToolErrorCategory.BUSINESS,
                code="ORDER_ALREADY_PAID",
                message="订单已支付",
                model_message="该订单已支付，无需重复支付",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        if record["status"] != "created":
            raise ToolBusinessError(
                category=ToolErrorCategory.BUSINESS,
                code="ORDER_NOT_PAYABLE",
                message=f"订单状态不可支付: {record['status']}",
                model_message="当前订单状态不可支付",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )

        pay_amount = record["amount"] if args.amount is None else args.amount
        if round(pay_amount, 2) != round(record["amount"], 2):
            raise ToolBusinessError(
                category=ToolErrorCategory.BUSINESS,
                code="PAYMENT_AMOUNT_MISMATCH",
                message=f"支付金额与订单金额不一致: {pay_amount} != {record['amount']}",
                model_message="支付金额与订单金额不一致，请修正金额",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )

        record["status"] = "paid"
        record["paid_amount"] = round(pay_amount, 2)
        record["payment_method"] = args.method
        record["updated_at"] = _now()
        _payment_requests[key] = {"hash": digest, "order_id": record["order_id"]}
    return HandlerOutput.of(
        _to_output(record),
        summary=(
            f"支付成功：订单 {record['order_id']}，金额 {record['paid_amount']} "
            f"{record['currency']}，方式 {args.method}"
        ),
    )


async def handle_refund_order(
    args: RefundOrderArgs, ctx: HandlerContext
) -> HandlerOutput:
    actor = _require_actor(ctx)
    async with _lock:
        _maybe_fault()
        record = _orders.get(args.order_id)
        if record is None or record["owner_actor_id"] != actor:
            raise _not_found()
        if record["status"] != "paid":
            raise ToolBusinessError(
                category=ToolErrorCategory.BUSINESS,
                code="ORDER_NOT_REFUNDABLE",
                message=f"订单状态不可退款: {record['status']}",
                model_message="当前订单状态不可退款",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        refundable = round(record["paid_amount"] - record["refunded_amount"], 2)
        refund_amount = refundable if args.amount is None else round(args.amount, 2)
        if refund_amount > refundable:
            raise ToolBusinessError(
                category=ToolErrorCategory.BUSINESS,
                code="REFUND_AMOUNT_EXCEEDED",
                message=f"退款金额超过可退金额: {refund_amount} > {refundable}",
                model_message="退款金额超过已付金额，请修正金额",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        record["refunded_amount"] = round(
            record["refunded_amount"] + refund_amount, 2
        )
        record["refund_reason"] = args.reason
        record["status"] = "refunded"
        record["updated_at"] = _now()
    return HandlerOutput.of(
        _to_output(record),
        summary=(
            f"退款成功：订单 {record['order_id']}，退款金额 {refund_amount} "
            f"{record['currency']}，原因 {args.reason}"
        ),
    )


async def handle_query_order(
    args: QueryOrderArgs, ctx: HandlerContext
) -> HandlerOutput:
    actor = _require_actor(ctx)
    async with _lock:
        _maybe_fault()
        if args.order_id:
            record = _orders.get(args.order_id)
            if record is None or record["owner_actor_id"] != actor:
                raise _not_found()
            matched = [record]
        else:
            matched = [
                record for record in _orders.values()
                if record["owner_actor_id"] == actor
                and record["status"] == args.status
            ]
        matched = sorted(matched, key=lambda item: item["created_at"], reverse=True)[
            : args.limit
        ]
        orders = [_to_output(record) for record in matched]
    return HandlerOutput.of(
        QueryOrderOutput(orders=orders, total=len(orders)),
        summary=f"订单查询返回 {len(orders)} 条记录",
    )
