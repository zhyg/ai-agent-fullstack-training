"""当前时间 handler（原 GetCurrentTimeTool 迁移）。"""
from datetime import datetime
from typing import Annotated
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, Field, field_validator

from app.core.tools.definition import HandlerOutput
from app.core.tools.enums import ErrorPhase, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError
from app.core.tools.session import HandlerContext


class GetCurrentTimeArgs(BaseModel):
    timezone: Annotated[str, Field("Asia/Shanghai", description="IANA 时区名，如 Asia/Shanghai")] = "Asia/Shanghai"

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, v: str) -> str:
        try:
            ZoneInfo(v)
        except ZoneInfoNotFoundError as e:
            raise ValueError(f"未知时区: {v}") from e
        return v


class GetCurrentTimeOutput(BaseModel):
    timezone: str
    datetime: str


async def handle(args: GetCurrentTimeArgs, ctx: HandlerContext) -> HandlerOutput:
    try:
        now = datetime.now(ZoneInfo(args.timezone))
    except ZoneInfoNotFoundError as exc:
        raise ToolBusinessError(
            category=ToolErrorCategory.VALIDATION,
            code="TIMEZONE_INVALID",
            message=f"未知时区: {args.timezone}",
            model_message=f"未知时区: {args.timezone}",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        ) from exc

    iso = now.isoformat(timespec="seconds")
    output = GetCurrentTimeOutput(timezone=args.timezone, datetime=iso)
    return HandlerOutput.of(
        output, summary=f"{args.timezone} 当前时间: {iso}"
    )
