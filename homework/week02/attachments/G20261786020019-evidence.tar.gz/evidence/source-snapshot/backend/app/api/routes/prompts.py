"""Prompt 配置接口：查看场景/版本模板，手动触发热加载。"""
from fastapi import APIRouter, Query

from app.api.schemas.prompt import (
    PromptReloadResponse,
    PromptSceneDetail,
    PromptSummary,
)
from app.container import container

router = APIRouter(prefix="/prompts", tags=["prompts"])


@router.get("", response_model=PromptSummary)
async def list_prompts():
    """全部场景及其激活版本、可用模板键。"""
    return container.prompt_manager.summary()


@router.get("/{scene}", response_model=PromptSceneDetail)
async def get_prompt_scene(
    scene: str,
    version: str | None = Query(None, max_length=32, description="版本号，默认激活版本"),
):
    """场景模板详情（含原始模板文本）。"""
    return container.prompt_manager.scene_detail(scene, version)


@router.post("/reload", response_model=PromptReloadResponse)
async def reload_prompts():
    """强制重新读取提示词配置文件。"""
    return {"reloaded": True, "summary": container.prompt_manager.reload()}
