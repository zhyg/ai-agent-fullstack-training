"""Agent Loop：思考 → 行动 → 观察 循环，直到完成/达上限/被取消。"""
import asyncio
import json
import traceback

from pydantic import ValidationError

from app.api.schemas.sse import (
    CancelledData,
    ErrorData,
    FinalAnswerData,
    SSEEventType,
    TaskFinishedData,
    ThoughtData,
    TokenData,
    ToolCallData,
    ToolResultData,
)
from app.api.schemas.task import TaskStatus
from app.config import settings
from app.core.exceptions import AppException, ConfigurationError, get_error_stage
from app.core.prompt.renderer import (
    build_correction_message,
    build_decision_message,
    build_system_message,
)
from app.core.prompt.security import sanitize_output
from app.core.runtime import transition_status
from app.core.tools.approval import ApprovalStore, TicketApprovalGate
from app.core.tools.enums import ModelAction
from app.core.tools.errors import ToolCancelledError
from app.core.tools.runtime import ToolRuntime, gen_tool_call_id
from app.core.tools.session import (
    ActorContext,
    AutoDenyApprovalGate,
    ToolCallRequest,
)
from app.core.tools.snapshot import ToolSnapshot
from app.llm.gateway import LLMGateway
from app.llm.schemas import (
    ActionType,
    AgentDecisionOutput,
    LLMRequest,
    Message,
    ResponseFormat,
    StepRecord,
    TokenUsage,
)
from app.services.event_buffer import EventBuffer
from app.services.permission_service import PermissionService
from app.services.task_service import RunningTask, TaskService

MAX_CONSECUTIVE_FAILURES = 3   # 连续可恢复工具失败上限，防死循环
MAX_CORRECTION_RETRIES = 1     # 单次输出的纠错重试上限（附带错误信息）

# 回灌模型并计入连续失败的动作；ASK_USER / STOP 会直接结束当前规划
_COUNTED_MODEL_ACTIONS = {
    ModelAction.FIX_ARGUMENTS,
    ModelAction.USE_ALTERNATIVE,
    ModelAction.RETRY_SAME,
}


def _failure_summary(result) -> str:
    """只把安全的错误码/提示/动作建议注入下一轮上下文。"""
    schema = result.error_schema
    if schema is None:
        return result.error or "工具执行失败"
    return (
        f"[{schema.code}] {schema.model_message}"
        f"（建议动作: {schema.model_action.value}）"
    )


class AgentLoop:
    """单任务循环执行器：构建提示词 → LLM 决策 → 执行工具 → 注入上下文。"""

    def __init__(
        self,
        gateway: LLMGateway,
        event_buffer: EventBuffer,
        task_service: TaskService,
        logger,
        *,
        tool_runtime: ToolRuntime | None = None,
        permission_service: PermissionService | None = None,
        approval_store: ApprovalStore | None = None,
        approval_ttl_seconds: float = 300.0,
    ):
        self._gateway = gateway
        self._event_buffer = event_buffer
        self._task_service = task_service
        self._logger = logger
        self._tool_runtime = tool_runtime
        self._permission_service = permission_service
        self._approval_store = approval_store
        self._approval_ttl = approval_ttl_seconds

    # ── 事件发布 ──
    async def _publish(
        self, running: RunningTask, event_type: SSEEventType, data: dict,
        *, persist_data: dict | None = None,
    ) -> int:
        rt = running.runtime
        seq = await self._event_buffer.publish(
            rt.task_id, event_type, data, persist_data=persist_data,
        )
        rt.last_seq = seq
        return seq

    # ── 主循环 ──
    async def run(self, running: RunningTask) -> None:
        rt = running.runtime
        if self._tool_runtime is None:
            raise ConfigurationError("ToolRuntime 未初始化，拒绝执行工具调用链路")
        actor = await self._resolve_actor(running)
        approval_gate = (
            _TicketTaskApprovalGate(self, running, self._approval_store)
            if self._approval_store is not None
            else AutoDenyApprovalGate()
        )
        session = self._tool_runtime.open_session(
            task_id=rt.task_id, trace_id=rt.trace_id, actor=actor,
            control=_TaskControl(running),
            approval_gate=approval_gate,
            refresh_actor=(
                self._permission_service.resolve
                if self._permission_service is not None else None
            ),
        )
        consecutive_failures = 0
        tool_failures = 0
        total_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        snapshot: ToolSnapshot | None = None

        try:
            while True:
                # ① 用户取消检查（每轮循环边界）
                if running.cancel_event.is_set():
                    await self._terminate(running, TaskStatus.CANCELLED)
                    return
                # ② 暂停等待：暂停期间不进入下一轮（不发起新的 LLM 调用）
                await running.wait_if_paused()
                # ③ 最大步数检查
                if rt.current_step >= rt.max_steps:
                    await self._fail(
                        running,
                        error_type="max_steps_exceeded",
                        message=f"达到最大步数 {rt.max_steps}，任务终止",
                    )
                    return

                rt.current_step += 1
                step = rt.current_step

                # ③ 构建快照前刷新最新身份；模型可见工具集与执行校验使用同一版本
                await session.refresh_identity()
                snapshot = self._tool_runtime.build_snapshot(session, round=step)

                # ③ 构建提示词并请求 LLM 决策（含纠错重试）
                try:
                    decision, usage = await self._decide(
                        running, snapshot, consecutive_failures
                    )
                except _SchemaFailuresExhausted:
                    await self._fail(
                        running,
                        error_type="schema_validation_failed",
                        message="连续 Schema 校验失败，任务终止",
                    )
                    return

                consecutive_failures = 0
                for k in total_usage:
                    total_usage[k] += getattr(usage, k, 0)

                # ④ 发布思考事件（输出脱敏）
                await self._publish(
                    running, SSEEventType.THOUGHT,
                    ThoughtData(step=step, content=sanitize_output(decision.thought)).model_dump(),
                )

                # ⑤ 判断动作
                if decision.action in (ActionType.FINAL_ANSWER, ActionType.NEED_CLARIFICATION):
                    answer = decision.answer or decision.thought
                    await self._publish(
                        running, SSEEventType.FINAL_ANSWER,
                        FinalAnswerData(answer=sanitize_output(answer), usage=total_usage).model_dump(),
                    )
                    rt.executed_steps.append(StepRecord(
                        step=step, thought=decision.thought,
                        action=decision.action.value,
                    ))
                    await self._terminate(running, TaskStatus.COMPLETED)
                    return

                # ⑥ 工具调用：模型只能拿快照，执行只能走 ToolRuntime
                ref = snapshot.get(decision.tool_name)
                tool_call_id = gen_tool_call_id()
                await self._publish(
                    running, SSEEventType.TOOL_CALL,
                    ToolCallData(
                        step=step, tool_name=decision.tool_name,
                        tool_args=decision.tool_args or {},
                        tool_call_id=tool_call_id,
                        tool_version=ref.version if ref else None,
                    ).model_dump(),
                )

                call = ToolCallRequest(
                    tool_name=decision.tool_name,
                    arguments=decision.tool_args or {},
                    tool_call_id=tool_call_id,
                    round=step,
                )
                # 执行工具（暂停期间不发起新的副作用操作）
                await running.wait_if_paused()
                result = await self._tool_runtime.execute(snapshot, call, session)
                await running.wait_if_paused()

                await self._publish(
                    running, SSEEventType.TOOL_RESULT,
                    ToolResultData(
                        step=step, tool_name=result.tool_name,
                        result=result.to_publish_payload(),
                        duration_ms=result.duration_ms,
                        tool_call_id=result.tool_call_id,
                        tool_version=result.tool_version,
                        status=result.status.value,
                        success=result.success,
                        retry_count=result.retry_count,
                    ).model_dump(),
                )

                # ⑦ 注入上下文
                rt.executed_steps.append(StepRecord(
                    step=step, thought=decision.thought,
                    action=decision.action.value, tool_name=result.tool_name,
                    tool_args=decision.tool_args,
                    tool_summary=(
                        result.summary if result.success
                        else _failure_summary(result)
                    ),
                    tool_call_id=result.tool_call_id,
                    tool_version=result.tool_version,
                    tool_status=result.status.value,
                    audit_id=result.audit_id,
                ))
                if result.success:
                    tool_failures = 0
                else:
                    action = (
                        result.error_schema.model_action
                        if result.error_schema is not None else ModelAction.NONE
                    )
                    if action == ModelAction.ASK_USER:
                        # 映射为 NEED_CLARIFICATION：挂起当前规划，向用户提出安全问题
                        await self._finish_with_answer(
                            running,
                            result.error_schema.model_message
                            if result.error_schema else "需要用户补充信息后才能继续",
                        )
                        return
                    if action == ModelAction.STOP:
                        # 映射为 FINAL_ANSWER：说明当前目标无法继续
                        await self._finish_with_answer(
                            running,
                            result.error_schema.model_message
                            if result.error_schema else "当前目标无法继续执行",
                        )
                        return
                    if action in _COUNTED_MODEL_ACTIONS:
                        tool_failures += 1
                        if tool_failures >= MAX_CONSECUTIVE_FAILURES:
                            await self._fail(
                                running,
                                error_type="tool_execution_failed",
                                message=(
                                    f"工具连续可恢复失败 {MAX_CONSECUTIVE_FAILURES} 次，"
                                    "任务终止"
                                ),
                            )
                            return
                    else:
                        # NONE / 不可模型解决：不回灌内部细节，安全终止
                        await self._fail(
                            running,
                            error_type="tool_execution_failed",
                            message="工具执行失败，任务终止",
                        )
                        return
                await self._task_service.snapshot(rt)

        except ToolCancelledError:
            await self._terminate(running, TaskStatus.CANCELLED)
        except asyncio.CancelledError:
            # 外部取消（停止接口取消 runner task）
            await self._terminate(running, TaskStatus.CANCELLED)
        except AppException as e:
            self._logger.error(
                "agent_loop_failed",
                trace_id=rt.trace_id, task_id=rt.task_id,
                error_type=e.code.value, message=e.message,
            )
            await self._fail(running, error_type=e.code.value, message=e.message, exc=e)
        except Exception as e:  # 未预期异常兜底
            self._logger.error(
                "agent_loop_unexpected_error",
                trace_id=rt.trace_id, task_id=rt.task_id, exc_info=True,
            )
            await self._fail(running, error_type="internal_error", message=str(e), exc=e)

    # ── LLM 决策（流式增量 + 纠错重试）──
    async def _decide(
        self,
        running: RunningTask,
        snapshot: ToolSnapshot,
        consecutive_failures: int,
    ) -> tuple[AgentDecisionOutput, TokenUsage]:
        rt = running.runtime
        messages = [
            build_system_message(snapshot.to_tool_defs()),
            build_decision_message(
                task=rt.input,
                current_step=rt.current_step,
                max_steps=rt.max_steps,
                executed_steps=[s.model_dump() for s in rt.executed_steps],
            ),
        ]
        failures = consecutive_failures
        correction_used = 0

        while True:
            if running.cancel_event.is_set():
                raise asyncio.CancelledError()
            await running.wait_if_paused()
            content, usage = await self._stream_content(running, messages)
            try:
                decision = AgentDecisionOutput.model_validate(json.loads(content))
                return decision, usage
            except (json.JSONDecodeError, ValidationError) as e:
                failures += 1
                if failures >= MAX_CONSECUTIVE_FAILURES or correction_used >= MAX_CORRECTION_RETRIES:
                    raise _SchemaFailuresExhausted() from e
                correction_used += 1
                errors = (
                    e.errors(include_context=False)
                    if isinstance(e, ValidationError)
                    else [{"msg": f"JSON 解析失败: {e}"}]
                )
                messages.append(Message(role="assistant", content=content))
                messages.append(build_correction_message(
                    errors=json.loads(json.dumps(errors, default=str)),
                    original_output=content[:2000],
                ))

    # ── 流式调用：每个增量立即发 token 事件，返回完整文本与用量 ──
    async def _stream_content(
        self,
        running: RunningTask,
        messages: list[Message],
    ) -> tuple[str, TokenUsage]:
        rt = running.runtime
        req = LLMRequest(
            model_id=rt.model_id,
            messages=messages,
            response_format=ResponseFormat(type="json_object"),
            max_tokens=settings.llm_max_tokens,
            stream=True,
        )

        chunks: list[str] = []
        usage = TokenUsage()
        stream = self._gateway.stream(
            req, trace_id=rt.trace_id, business_id=rt.business_id
        )
        iterator = stream.__aiter__()
        try:
            while True:
                # 暂停：不再读取下一个增量（不消费=不发布），底层流保持不动；
                # 恢复后从同一位置继续读，seq 与内容都接着往下走。
                await running.wait_if_paused()
                if running.cancel_event.is_set():
                    raise asyncio.CancelledError()
                try:
                    chunk = await iterator.__anext__()
                except StopAsyncIteration:
                    break
                if chunk.usage is not None:
                    usage = chunk.usage
                if not chunk.content:
                    continue
                chunks.append(chunk.content)
                # 发布前再确认一次暂停：避免"暂停瞬间已读到的帧"继续输出
                await running.wait_if_paused()
                await self._publish(
                    running, SSEEventType.TOKEN,
                    TokenData(content=chunk.content).model_dump(),
                )
        finally:
            await stream.aclose()
        return "".join(chunks), usage

    # ── 调用者权限解析 ──
    async def _resolve_actor(self, running: RunningTask) -> ActorContext:
        if self._permission_service is None:
            return ActorContext(
                actor_id=running.actor_id,
                tenant_id=None,
                granted_permissions=frozenset(),
            )
        # 显式身份，不再静默替换为默认管理员
        return await self._permission_service.resolve(running.actor_id)

    # ── 以最终答复结束（STOP / ASK_USER 映射）──
    async def _finish_with_answer(self, running: RunningTask, answer: str) -> None:
        await self._publish(
            running, SSEEventType.FINAL_ANSWER,
            FinalAnswerData(
                answer=sanitize_output(answer),
                usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            ).model_dump(),
        )
        await self._terminate(running, TaskStatus.COMPLETED)

    # ── 终止处理 ──
    async def _terminate(self, running: RunningTask, status: TaskStatus) -> None:
        rt = running.runtime
        if status == TaskStatus.CANCELLED:
            await self._publish(
                running, SSEEventType.CANCELLED,
                CancelledData(last_seq=rt.last_seq).model_dump(),
            )
        transition_status(rt.status, status)
        rt.status = status
        await self._publish(
            running, SSEEventType.TASK_FINISHED,
            TaskFinishedData(status=status.value, total_steps=rt.current_step).model_dump(),
        )
        await self._task_service.snapshot(rt)
        self._logger.info(
            "task_finished", task_id=rt.task_id, trace_id=rt.trace_id,
            status=status.value, total_steps=rt.current_step,
        )

    async def _fail(
        self,
        running: RunningTask,
        *,
        error_type: str,
        message: str,
        exc: AppException | None = None,
    ) -> None:
        rt = running.runtime
        await self._publish(
            running, SSEEventType.ERROR,
            ErrorData(error_type=error_type, message=message,
                      retryable=exc.retryable if exc else False).model_dump(),
        )
        if exc is not None:
            await self._task_service.db.insert_error_trace(
                trace_id=rt.trace_id,
                request_id=None,
                stage=get_error_stage(exc),
                error_type=error_type,
                message=message,
                stack_trace=traceback.format_exc(),
                retry_count=0,
                strategy="terminated",
            )
        await self._terminate(running, TaskStatus.FAILED)


class _SchemaFailuresExhausted(Exception):
    """连续 Schema 校验失败达到上限。"""


class _TaskControl:
    """把 RunningTask 的暂停/取消信号适配为 ToolControl。"""

    def __init__(self, running: RunningTask):
        self._running = running

    def is_cancelled(self) -> bool:
        return self._running.cancel_event.is_set()

    def is_paused(self) -> bool:
        return not self._running.resume_event.is_set()

    async def checkpoint(self) -> None:
        if self.is_cancelled():
            raise ToolCancelledError("任务已取消")
        try:
            await self._running.wait_if_paused()
        except asyncio.CancelledError as exc:
            raise ToolCancelledError("任务已取消") from exc
        if self.is_cancelled():
            raise ToolCancelledError("任务已取消")


class _TicketTaskApprovalGate:
    """AgentLoop 的票据审批门：签发 token → 发布事件 → WAITING_APPROVAL → 等待。"""

    def __init__(
        self, loop: "AgentLoop", running: RunningTask, store: ApprovalStore,
    ):
        self._loop = loop
        self._running = running
        self._gate = TicketApprovalGate(
            store,
            ttl_seconds=loop._approval_ttl,
            emit=self._emit,
            set_waiting=self._set_waiting,
            set_running=self._set_running,
        )

    async def request(self, req):
        return await self._gate.request(req)

    async def _emit(self, sse_data: dict, persist_data: dict) -> None:
        await self._loop._publish(
            self._running,
            SSEEventType.TOOL_CONFIRMATION_REQUEST,
            sse_data,
            persist_data=persist_data,
        )

    async def _set_waiting(self) -> None:
        rt = self._running.runtime
        if rt.status == TaskStatus.WAITING_APPROVAL:
            return
        transition_status(rt.status, TaskStatus.WAITING_APPROVAL)
        rt.status = TaskStatus.WAITING_APPROVAL
        await self._loop._task_service.snapshot(rt)

    async def _set_running(self) -> None:
        rt = self._running.runtime
        if rt.status != TaskStatus.WAITING_APPROVAL:
            return
        transition_status(rt.status, TaskStatus.RUNNING)
        rt.status = TaskStatus.RUNNING
        await self._loop._task_service.snapshot(rt)

