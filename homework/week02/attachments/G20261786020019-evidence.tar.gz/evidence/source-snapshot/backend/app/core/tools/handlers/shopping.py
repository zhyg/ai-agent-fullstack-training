"""购物申请审批流 handler（mock 数据，内存存储）。

流程：submit_shopping_request（发起）→ approve_shopping_request（审批）→
get_shopping_request（查询结果回灌模型）。
"""
import asyncio
import uuid
from datetime import datetime, timezone
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from app.core.tools.definition import HandlerOutput
from app.core.tools.enums import ErrorPhase, ToolErrorCategory
from app.core.tools.errors import ToolBusinessError
from app.core.tools.session import HandlerContext

_lock = asyncio.Lock()
_requests: dict[str, dict] = {}


class SubmitShoppingRequestArgs(BaseModel):
    item: Annotated[str, Field(..., min_length=1, max_length=200, description="商品名称")]
    quantity: Annotated[int, Field(1, ge=1, le=99, description="数量，1~99")] = 1
    budget: Annotated[float, Field(..., gt=0, le=100000, description="预算金额（元）")]
    reason: Annotated[str, Field("", max_length=500, description="申请理由")] = ""


class ShoppingRequestOutput(BaseModel):
    request_id: str
    status: str
    item: str
    quantity: int
    budget: float
    reason: str = ""
    created_at: str
    decided_at: str | None = None
    decided_by: str | None = None
    comment: str | None = None


class GetShoppingRequestArgs(BaseModel):
    request_id: Annotated[str, Field(..., min_length=1, description="购物申请单号")]


class ApproveShoppingRequestArgs(BaseModel):
    request_id: Annotated[str, Field(..., min_length=1, description="购物申请单号")]
    decision: Annotated[Literal["approve", "reject"], Field(..., description="审批结论")]
    comment: Annotated[str, Field("", max_length=500, description="审批意见")] = ""


def _to_output(record: dict) -> ShoppingRequestOutput:
    return ShoppingRequestOutput(**record)


async def handle_submit(args: SubmitShoppingRequestArgs,
                        ctx: HandlerContext) -> HandlerOutput:
    request_id = f"shop_{uuid.uuid4().hex[:12]}"
    record = {
        "request_id": request_id,
        "status": "pending_approval",
        "item": args.item,
        "quantity": args.quantity,
        "budget": args.budget,
        "reason": args.reason,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "decided_at": None,
        "decided_by": None,
        "comment": None,
    }
    async with _lock:
        _requests[request_id] = record
    return HandlerOutput.of(
        _to_output(record),
        summary=(
            f"购物申请已提交：{args.item} × {args.quantity}，预算 {args.budget} 元，"
            f"单号 {request_id}，状态 pending_approval"
        ),
    )


async def handle_approve(args: ApproveShoppingRequestArgs,
                         ctx: HandlerContext) -> HandlerOutput:
    async with _lock:
        record = _requests.get(args.request_id)
        if record is None:
            raise ToolBusinessError(
                category=ToolErrorCategory.NOT_FOUND,
                code="SHOPPING_REQUEST_NOT_FOUND",
                message=f"购物申请不存在: {args.request_id}",
                model_message="购物申请单号不存在",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        if record["status"] != "pending_approval":
            raise ToolBusinessError(
                category=ToolErrorCategory.BUSINESS,
                code="SHOPPING_REQUEST_ALREADY_DECIDED",
                message=f"购物申请已处理: {record['status']}",
                model_message="该购物申请已审批过，不能重复审批",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        record["status"] = "approved" if args.decision == "approve" else "rejected"
        record["decided_at"] = datetime.now(timezone.utc).isoformat()
        record["decided_by"] = ctx.actor_id
        record["comment"] = args.comment or None

    return HandlerOutput.of(
        _to_output(record),
        summary=(
            f"购物申请 {args.request_id} 审批完成：{record['status']}"
            + (f"，意见：{args.comment}" if args.comment else "")
        ),
    )


async def handle_get(args: GetShoppingRequestArgs,
                     ctx: HandlerContext) -> HandlerOutput:
    async with _lock:
        record = _requests.get(args.request_id)
    if record is None:
        raise ToolBusinessError(
            category=ToolErrorCategory.NOT_FOUND,
            code="SHOPPING_REQUEST_NOT_FOUND",
            message=f"购物申请不存在: {args.request_id}",
            model_message="购物申请单号不存在",
            phase=ErrorPhase.PRE_SIDE_EFFECT,
        )
    return HandlerOutput.of(
        _to_output(record),
        summary=(
            f"购物申请 {args.request_id}：{record['item']} × {record['quantity']}，"
            f"状态 {record['status']}"
        ),
    )
