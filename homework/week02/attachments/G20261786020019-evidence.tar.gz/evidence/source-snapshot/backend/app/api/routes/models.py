"""模型接口：可用模型列表。"""
from fastapi import APIRouter

from app.api.schemas.common import ApiResponse, ok
from app.config import settings
from app.container import container

router = APIRouter(prefix="/models", tags=["models"])


@router.get("", response_model=ApiResponse[dict])
async def list_models():
    """可用模型列表（供应商适配器已就绪的），default 跟随配置。"""
    models = [
        {
            "id": m.id,
            "name": m.name,
            "provider": m.provider,
            "default": m.id == settings.default_model,
        }
        for m in container.gateway.available_models()
    ]
    return ok({"models": models})


@router.get("/scenes", response_model=ApiResponse[dict])
async def list_scenes():
    """场景列表：场景 → 实际模型映射，供前端场景选择。"""
    if container.router is None:
        return ok({"scenes": [], "default_scene": settings.default_scene})
    available_ids = {m.id for m in container.gateway.available_models()}
    default_scene = container.router.default_scene()
    scenes = []
    for scene in container.router.list_scenes():
        resolved = container.gateway.resolve_model(scene.model_id)
        scenes.append({
            "name": scene.name,
            "model_id": resolved,
            "description": scene.description,
            "default": scene.name == default_scene,
            "available": resolved in available_ids,
        })
    return ok({"scenes": scenes, "default_scene": default_scene})
