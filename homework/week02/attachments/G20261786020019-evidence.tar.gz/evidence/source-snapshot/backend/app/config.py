"""全局配置：敏感信息从环境变量读取，不写入代码。"""
import json

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core.exceptions import ConfigurationError


class Settings(BaseSettings):
    """全局配置，敏感字段从环境变量读取，不写入代码。"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── 服务配置（非敏感）──
    host: str = Field("0.0.0.0", description="服务监听地址")
    port: int = Field(8000, ge=1, le=65535, description="服务端口")
    debug: bool = Field(False, description="调试模式")

    # ── 鉴权（敏感）──
    auth_token: str = Field(..., description="API 鉴权 Token，从环境变量读取")
    auth_identities_json: str = Field(
        "{}",
        description="Token→actor_id 映射 JSON，如 {\"token-1\":\"user_a\"}；空映射拒绝启动",
    )

    # ── 限流（非敏感）──
    rate_limit_per_minute: int = Field(10, ge=1, le=1000, description="每分钟限流次数")

    # ── 模型配置（混合）──
    default_model: str = Field("gpt-4o", description="默认模型 ID")
    openai_api_key: str = Field(..., description="OpenAI API Key，敏感，从环境变量读取")
    openai_base_url: str = Field("https://api.openai.com/v1", description="OpenAI Base URL")
    anthropic_api_key: str | None = Field(None, description="Anthropic API Key，敏感")
    anthropic_base_url: str = Field("https://api.anthropic.com", description="Anthropic Base URL")
    deepseek_api_key: str | None = Field(None, description="DeepSeek API Key，敏感")
    deepseek_base_url: str = Field("https://api.deepseek.com/v1", description="DeepSeek Base URL")
    ollama_base_url: str | None = Field(None, description="Ollama Base URL（如 http://localhost:11434，配置后启用本地模型）")
    ollama_api_key: str = Field("ollama", description="Ollama 兼容接口占位 Key（Ollama 校验不严格）")

    # ── 路由 / Prompt 配置（非敏感）──
    llm_routing_path: str = Field("./config/llm_routing.json", description="模型别名与场景路由配置路径")
    prompt_config_path: str = Field("./config/prompts.json", description="提示词模板配置路径（支持热加载）")
    default_scene: str = Field("agent", description="未指定模型/场景时的默认场景")

    # ── 数据库（敏感）──
    database_url: str = Field("sqlite:///./agent.db", description="数据库连接串，含密码时为敏感")

    # ── Agent 运行参数（非敏感）──
    agent_max_steps: int = Field(20, ge=1, le=50, description="Agent 最大循环步数")
    llm_max_retries: int = Field(3, ge=0, le=10, description="LLM 最大重试次数")
    llm_base_delay: float = Field(1.0, ge=0.1, le=60.0, description="重试退避基数（秒）")
    llm_max_tokens: int = Field(4096, ge=1, le=128000, description="LLM 最大输出 token")
    llm_timeout_seconds: float = Field(
        120.0, ge=1.0, le=600.0, description="单次 LLM 调用/单个流分片的超时（秒）"
    )

    # ── 可复用 AgentRunner 默认上限（非敏感）──
    run_max_rounds: int = Field(8, ge=1, le=20, description="Runner 默认最大轮次")
    run_timeout_seconds: float = Field(300.0, ge=1.0, le=600.0, description="Runner 默认总超时（秒）")
    run_token_budget: int = Field(100000, ge=0, description="Runner 默认 token 预算，0 表示不限制")

    # ── 工具配置（敏感）──
    send_email_smtp_host: str | None = Field(None, description="SMTP 主机，如 smtp.qq.com")
    send_email_smtp_port: int = Field(465, ge=1, le=65535, description="SMTP 端口，465(SSL)/587(STARTTLS)")
    send_email_smtp_use_ssl: bool = Field(True, description="是否使用 SSL，465 端口通常为 True")
    send_email_smtp_user: str | None = Field(None, description="SMTP 用户名，须为完整邮箱地址")
    send_email_smtp_password: str | None = Field(None, description="SMTP 授权码（非登录密码），敏感")
    send_email_from_name: str | None = Field(None, description="发件人显示名称")
    web_search_api_key: str | None = Field(None, description="搜索 API Key，敏感")

    # ── Tool Runtime（非敏感）──
    default_user_id: str = Field(
        "user_default",
        description="历史默认用户 ID（仅用于旧数据迁移回填与种子用户）",
    )
    tool_runtime_enabled: bool = Field(True, description="是否启用新 Tool Runtime")
    tool_config_path: str = Field("./config/tools.json", description="工具治理策略配置路径")
    mcp_config_path: str = Field("./config/mcp_servers.json", description="MCP server 配置路径")
    tool_snapshot_ttl_seconds: int = Field(600, ge=30, le=3600, description="单轮工具快照有效期（秒）")
    tool_default_timeout_seconds: float = Field(30.0, ge=1.0, le=300.0, description="工具执行默认超时（秒）")
    tool_audit_enabled: bool = Field(True, description="是否落库工具审计记录")

    # ── 审批票据（非敏感）──
    approval_ttl_seconds: float = Field(300.0, ge=1.0, le=3600.0, description="审批票据默认 TTL（秒）")
    approval_sweep_interval_seconds: float = Field(60.0, ge=5.0, le=600.0, description="审批票据过期清扫间隔（秒）")

    def auth_identities(self) -> dict[str, str]:
        """解析 Token→actor 映射；格式错误或空映射直接视为配置错误。"""
        try:
            payload = json.loads(self.auth_identities_json or "{}")
        except json.JSONDecodeError as exc:
            raise ConfigurationError(f"AUTH_IDENTITIES_JSON 不是合法 JSON: {exc}") from exc
        if not isinstance(payload, dict) or not payload:
            raise ConfigurationError(
                "AUTH_IDENTITIES_JSON 为空：必须配置至少一个 token→actor_id 映射"
            )
        mapping: dict[str, str] = {}
        for token, actor_id in payload.items():
            if not isinstance(token, str) or not token:
                raise ConfigurationError("AUTH_IDENTITIES_JSON 包含非法 token")
            if not isinstance(actor_id, str) or not actor_id:
                raise ConfigurationError(
                    f"AUTH_IDENTITIES_JSON 中 token 对应的 actor_id 非法: {token}"
                )
            mapping[token] = actor_id
        return mapping



settings = Settings()


def validate_sensitive_config(s: Settings) -> None:
    """启动时校验敏感配置，缺失则终止。"""
    missing: list[str] = []
    if not s.auth_token:
        missing.append("AUTH_TOKEN")
    if not s.openai_api_key:
        missing.append("OPENAI_API_KEY")
    if missing:
        raise ConfigurationError(
            f"缺少必填敏感配置: {', '.join(missing)}，"
            f"请通过环境变量或 .env 文件设置，切勿写入代码"
        )
    # 空映射 / 非法映射拒绝启动
    s.auth_identities()
