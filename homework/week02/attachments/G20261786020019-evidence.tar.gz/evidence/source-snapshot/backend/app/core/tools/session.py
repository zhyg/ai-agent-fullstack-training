"""会话与调用上下文：Actor / Control / ApprovalGate / HandlerContext。

依赖方向：session -> enums + definition + snapshot（仅类型），不依赖 registry / runtime / loop。
"""
import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Protocol

from app.core.tools.enums import ApprovalStatus, RiskLevel, ToolPermission
from app.core.tools.snapshot import ToolRef
from app.core.tools.definition import ToolDependency


ActorRefresher = Callable[[str], Awaitable["ActorContext"]]


@dataclass(frozen=True)
class ActorContext:
    """服务端判定的调用者身份与权限，模型无法修改。"""

    actor_id: str | None
    tenant_id: str | None
    granted_permissions: frozenset[ToolPermission] = field(default_factory=frozenset)
    roles: frozenset[str] = field(default_factory=frozenset)

    @classmethod
    def anonymous(cls) -> "ActorContext":
        return cls(actor_id=None, tenant_id=None, granted_permissions=frozenset())


@dataclass
class ToolDependencyState:
    """本任务内的依赖完成状态。"""

    completed: dict[str, ToolRef] = field(default_factory=dict)
    failed: set[str] = field(default_factory=set)

    def mark_completed(self, ref: ToolRef) -> None:
        self.completed[ref.name] = ref
        self.failed.discard(ref.name)

    def mark_failed(self, name: str) -> None:
        self.failed.add(name)

    def is_satisfied(self, dep: ToolDependency) -> bool:
        ref = self.completed.get(dep.tool_name)
        if ref is None:
            return not dep.required
        if dep.version is not None and ref.version != dep.version:
            return False
        return True


class ToolControl(Protocol):
    """暂停/取消控制信号，由 loop/runner 适配。"""

    def is_cancelled(self) -> bool: ...

    def is_paused(self) -> bool: ...

    async def checkpoint(self) -> None:
        """暂停时挂起等待；已取消时抛 ToolCancelledError。"""


class ApprovalGate(Protocol):
    async def request(self, req: "ToolApprovalRequest") -> "ApprovalDecision": ...


class ToolObserver(Protocol):
    async def on_retry(self, event: dict) -> None: ...

    async def on_rejected(self, event: dict) -> None: ...


@dataclass(frozen=True)
class ToolCallRequest:
    tool_name: str
    arguments: dict[str, Any]
    tool_call_id: str
    round: int


@dataclass(frozen=True)
class HandlerContext:
    """handler 能看到的全部上下文：只读、不含 gateway/registry/event_buffer。"""

    tool_call_id: str
    task_id: str
    trace_id: str
    attempt: int = 0
    idempotency_key: str | None = None
    deadline: float | None = None
    actor_id: str | None = None
    tenant_id: str | None = None
    request_id: str | None = None
    checkpoint: Callable[[], Awaitable[None]] | None = None

    async def pause_check(self) -> None:
        if self.checkpoint is not None:
            await self.checkpoint()


@dataclass
class ToolSession:
    """一个任务一次的运行上下文；ToolRuntime 本身可为单例。"""

    session_id: str
    task_id: str
    trace_id: str
    actor: ActorContext
    control: ToolControl
    approval_gate: ApprovalGate
    observer: ToolObserver | None = None
    dependencies: ToolDependencyState = field(default_factory=ToolDependencyState)
    idempotency_key: str | None = None
    # 从数据库重新读取用户状态、权限和角色
    refresh_actor: ActorRefresher | None = None

    async def refresh_identity(self) -> ActorContext:
        if self.refresh_actor is not None and self.actor.actor_id is not None:
            self.actor = await self.refresh_actor(self.actor.actor_id)
        return self.actor


@dataclass(frozen=True)
class ToolApprovalRequest:
    task_id: str
    step: int
    round: int
    tool_call_id: str
    tool_name: str
    tool_version: str
    tool_args: dict[str, Any]
    risk_level: RiskLevel
    snapshot_id: str
    message: str
    # 签发票据所需的显式身份与绑定字段，不再依赖闭包隐式获取
    trace_id: str = ""
    fingerprint: str = ""
    args_hash: str = ""
    actor_id: str = ""
    roles: frozenset[str] = field(default_factory=frozenset)
    snapshot_expires_at: Any = None


@dataclass(frozen=True)
class ApprovalDecision:
    approved: bool
    status: ApprovalStatus
    reason: str | None = None
    # 票据审批成功时回传，供 Runtime 复核后原子 consume；其他审批通道为 None
    token: str | None = None
    decided_by: str | None = None
    decided_at: Any = None
    comment: str | None = None
    requested_at: Any = None


class NoopControl:
    """无暂停/取消信号的默认控制（测试与 /runs 适配）。"""

    def is_cancelled(self) -> bool:
        return False

    def is_paused(self) -> bool:
        return False

    async def checkpoint(self) -> None:
        return None


class AutoDenyApprovalGate:
    """未提供审批通道时：需要审批的工具一律拒绝。"""

    async def request(self, req: ToolApprovalRequest) -> ApprovalDecision:
        return ApprovalDecision(
            approved=False,
            status=ApprovalStatus.DENIED,
            reason="当前运行未提供审批通道",
        )


class AutoApproveApprovalGate:
    """测试/受信内部调用使用：直接批准。"""

    async def request(self, req: ToolApprovalRequest) -> ApprovalDecision:
        return ApprovalDecision(approved=True, status=ApprovalStatus.APPROVED)


class EventControl:
    """基于 asyncio.Event 的简单控制：cancel 抛 ToolCancelledError。"""

    def __init__(self, cancel_event: asyncio.Event | None = None):
        self._cancel = cancel_event

    def is_cancelled(self) -> bool:
        return bool(self._cancel and self._cancel.is_set())

    def is_paused(self) -> bool:
        return False

    async def checkpoint(self) -> None:
        from app.core.tools.errors import ToolCancelledError

        if self.is_cancelled():
            raise ToolCancelledError("任务已取消")
