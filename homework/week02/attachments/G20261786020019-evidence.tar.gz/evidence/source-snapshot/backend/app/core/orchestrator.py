"""任务编排器：任务生命周期管理（开始/暂停/恢复/切换模型/工具确认）。"""
import asyncio
import contextlib
from datetime import datetime, timezone

from app.api.schemas.task import (
    ConfirmToolRequest,
    ConfirmToolResponse,
    SwitchModelRequest,
    SwitchModelResponse,
    TaskCancelResponse,
    TaskResumeRequest,
    TaskResumeResponse,
    TaskStartRequest,
    TaskStartResponse,
    TaskStatus,
    TaskStopResponse,
)
from app.api.schemas.sse import SSEEventType, TaskStartedData
from app.config import settings
from app.core.exceptions import (
    AppException,
    ErrorCode,
    ForbiddenException,
    ModelNotAvailableException,
    ResourceNotFoundException,
    TaskStateException,
    ValidationException,
)
from app.core.loop import AgentLoop
from app.core.tools.approval import ApprovalError, ApprovalStore
from app.core.runtime import TaskRuntime, gen_task_id, gen_trace_id, transition_status
from app.core.tools.runtime import ToolRuntime
from app.llm.gateway import LLMGateway
from app.llm.registry import get_model_info
from app.services.event_buffer import EventBuffer
from app.services.permission_service import PermissionService
from app.services.task_service import RunningTask, TaskService


class Orchestrator:
    """生成 task_id/trace_id，异步启动 Agent Loop，协调取消/恢复/确认。"""

    def __init__(
        self,
        gateway: LLMGateway,
        task_service: TaskService,
        event_buffer: EventBuffer,
        logger,
        *,
        tool_runtime: ToolRuntime | None = None,
        permission_service: PermissionService | None = None,
        approval_store: ApprovalStore | None = None,
        approval_ttl_seconds: float = 300.0,
    ):
        self._gateway = gateway
        self._task_service = task_service
        self._event_buffer = event_buffer
        self._logger = logger
        self._tool_runtime = tool_runtime
        self._permission_service = permission_service
        self._approval_store = approval_store
        self._approval_ttl = approval_ttl_seconds

    # ── 开始任务 ──
    async def start(
        self, req: TaskStartRequest, *, business_id: str | None = None,
        actor_id: str | None = None,
    ) -> TaskStartResponse:
        # 新任务必须显式携带调用者，不再静默替换为默认管理员
        if not actor_id:
            raise ValidationException("缺少任务所有者 actor_id")
        # 场景 / 模型别名 → 注册表模型 ID
        model_id = self._gateway.resolve_model(req.model_id, req.scene) or settings.default_model
        if get_model_info(model_id) is None:
            raise ModelNotAvailableException(model_id)

        now = datetime.now(timezone.utc)
        runtime = TaskRuntime(
            task_id=gen_task_id(),
            trace_id=gen_trace_id(),
            input=req.input,
            model_id=model_id,
            max_steps=req.max_steps,
            status=TaskStatus.PENDING,
            actor_id=actor_id,
            business_id=business_id,
            created_at=now,
            updated_at=now,
        )
        running = RunningTask(runtime=runtime, actor_id=actor_id)
        self._task_service.register(running)
        await self._event_buffer.open_task(runtime.task_id)

        transition_status(runtime.status, TaskStatus.RUNNING)
        runtime.status = TaskStatus.RUNNING
        seq = await self._event_buffer.publish(
            runtime.task_id, SSEEventType.TASK_STARTED,
            TaskStartedData(
                task_id=runtime.task_id,
                trace_id=runtime.trace_id,
                model_id=model_id,
            ).model_dump(),
        )
        runtime.last_seq = seq
        await self._task_service.snapshot(runtime)

        # 异步启动任务循环，立即返回 task_id
        running.runner = asyncio.create_task(self._run(running))
        self._logger.info(
            "task_started", task_id=runtime.task_id,
            trace_id=runtime.trace_id, model_id=model_id,
        )
        return TaskStartResponse(
            task_id=runtime.task_id,
            trace_id=runtime.trace_id,
            status=runtime.status,
        )

    async def _run(self, running: RunningTask) -> None:
        try:
            loop = AgentLoop(
                self._gateway, self._event_buffer, self._task_service, self._logger,
                tool_runtime=self._tool_runtime,
                permission_service=self._permission_service,
                approval_store=self._approval_store,
                approval_ttl_seconds=self._approval_ttl,
            )
            await loop.run(running)
        finally:
            self._task_service.unregister(running.runtime.task_id)

    # ── 暂停任务（保留会话，不终止循环）──
    async def stop(self, task_id: str) -> TaskStopResponse:
        running = self._task_service.get(task_id)
        if running is None:
            # 内存中不存在：区分"任务不存在"与"任务已结束"
            rt = await self._task_service.load_runtime(task_id)
            if rt is None:
                raise ResourceNotFoundException("任务", task_id)
            raise TaskStateException(
                f"任务未在运行: {rt.status.value}", ErrorCode.TASK_NOT_RUNNING
            )
        rt = running.runtime
        if rt.status == TaskStatus.PAUSED:
            # 幂等：已暂停直接返回
            return TaskStopResponse(
                task_id=task_id, status=rt.status, last_seq=rt.last_seq
            )
        if rt.status == TaskStatus.WAITING_APPROVAL:
            raise TaskStateException(
                "任务正在等待审批，请先确认/拒绝审批再暂停",
                ErrorCode.TASK_NOT_RUNNING,
            )
        if rt.status != TaskStatus.RUNNING:
            raise TaskStateException(
                f"任务未在运行: {rt.status.value}", ErrorCode.TASK_NOT_RUNNING
            )
        # 暂停：只清恢复信号，不取消 runner、不发终止事件，循环在下一个帧边界停住
        running.pause()
        # 等循环真正停在帧边界（最多 1s），保证 stop 返回时输出已停止
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(running.paused_ack.wait(), timeout=1.0)
        transition_status(rt.status, TaskStatus.PAUSED)
        rt.status = TaskStatus.PAUSED
        await self._task_service.snapshot(rt)
        self._logger.info(
            "task_paused", task_id=task_id, trace_id=rt.trace_id, last_seq=rt.last_seq,
        )
        return TaskStopResponse(
            task_id=task_id, status=rt.status, last_seq=rt.last_seq
        )

    # ── 恢复任务 ──
    async def resume(self, task_id: str, req: TaskResumeRequest) -> TaskResumeResponse:
        running = self._task_service.get(task_id)
        if running is not None:
            return await self._resume_in_place(running, req)

        # 冷恢复：进程内已无该任务（重启/已结束），按快照重做中断步骤
        rt = await self._task_service.load_runtime(task_id)
        if rt is None:
            raise ResourceNotFoundException("任务", task_id)
        if rt.status == TaskStatus.WAITING_APPROVAL:
            raise TaskStateException(
                "任务处于审批等待中，不能冷恢复",
                ErrorCode.TASK_CANNOT_RESUME,
            )
        if rt.status not in (TaskStatus.PAUSED, TaskStatus.CANCELLED, TaskStatus.FAILED):
            raise TaskStateException(
                f"当前状态 {rt.status.value} 不可恢复（仅 paused/cancelled/failed 可恢复）",
                ErrorCode.TASK_CANNOT_RESUME,
            )
        if req.model_id:
            if get_model_info(req.model_id) is None:
                raise ModelNotAvailableException(req.model_id)
            rt.model_id = req.model_id

        # 断点可能落在未完成的步骤内：回退到最后一个已执行步骤，恢复后重做该步骤
        rt.current_step = rt.executed_steps[-1].step if rt.executed_steps else 0

        transition_status(rt.status, TaskStatus.RUNNING)
        rt.status = TaskStatus.RUNNING
        running = RunningTask(runtime=rt, actor_id=rt.actor_id)
        self._task_service.register(running)
        await self._event_buffer.open_task(task_id)
        await self._task_service.snapshot(rt)

        # 续传起点以服务端真实最新 seq 为准，避免重放上一轮残留的终止事件
        start_seq = await self._event_buffer.latest_seq(task_id) + 1

        # 重新触发任务循环，从断点继续（对话历史/已执行步骤已恢复）
        running.runner = asyncio.create_task(self._run(running))
        self._logger.info(
            "task_resumed", task_id=task_id, trace_id=rt.trace_id,
            from_seq=req.last_seq, start_seq=start_seq, in_place=False,
        )
        return TaskResumeResponse(
            task_id=task_id, status=rt.status, start_seq=start_seq, in_place=False
        )

    async def _resume_in_place(
        self, running: RunningTask, req: TaskResumeRequest
    ) -> TaskResumeResponse:
        """原地续流：任务仍在内存中且处于暂停，直接唤醒同一个循环。"""
        task_id = running.runtime.task_id
        rt = running.runtime
        if rt.status == TaskStatus.RUNNING:
            raise TaskStateException(
                "任务已在运行中", ErrorCode.TASK_ALREADY_RUNNING
            )
        if rt.status == TaskStatus.WAITING_APPROVAL:
            raise TaskStateException(
                "任务处于审批等待中，不能恢复", ErrorCode.TASK_CANNOT_RESUME,
            )
        if rt.status != TaskStatus.PAUSED:
            raise TaskStateException(
                f"当前状态 {rt.status.value} 不可原地恢复", ErrorCode.TASK_CANNOT_RESUME,
            )
        if req.model_id:
            if get_model_info(req.model_id) is None:
                raise ModelNotAvailableException(req.model_id)
            rt.model_id = req.model_id

        transition_status(rt.status, TaskStatus.RUNNING)
        rt.status = TaskStatus.RUNNING
        running.resume()
        await self._task_service.snapshot(rt)
        start_seq = await self._event_buffer.latest_seq(task_id) + 1
        self._logger.info(
            "task_resumed_in_place", task_id=task_id, trace_id=rt.trace_id,
            from_seq=req.last_seq, start_seq=start_seq,
        )
        return TaskResumeResponse(
            task_id=task_id, status=rt.status, start_seq=start_seq, in_place=True
        )

    # ── 切换模型（下一轮 LLM 调用生效）──
    async def switch_model(self, task_id: str, req: SwitchModelRequest) -> SwitchModelResponse:
        running = self._require_running(task_id)
        if get_model_info(req.model_id) is None:
            raise ModelNotAvailableException(req.model_id)
        running.runtime.model_id = req.model_id
        await self._task_service.snapshot(running.runtime)
        self._logger.info(
            "model_switched", task_id=task_id, model_id=req.model_id
        )
        return SwitchModelResponse(
            task_id=task_id, model_id=req.model_id, effective_on="next_llm_call"
        )

    # ── 审批确认（token 制，任务所有者为唯一确认人）──
    async def confirm(
        self, task_id: str, req: ConfirmToolRequest, *, actor_id: str | None,
    ) -> ConfirmToolResponse:
        await self.ensure_owner(task_id, actor_id)
        if self._approval_store is None:
            raise TaskStateException("审批存储不可用")
        try:
            resolution = self._approval_store.resolve(
                req.approval_token,
                task_id=task_id,
                actor_id=actor_id,
                approved=req.confirmed,
                comment=req.comment,
            )
        except ApprovalError as exc:
            raise AppException(
                ErrorCode.VALIDATION_ERROR,
                f"{exc.code}: {exc.message}",
                http_status=exc.http_status,
                details={"approval_code": exc.code},
            ) from exc
        self._logger.info(
            "tool_approval_resolved", task_id=task_id,
            tool_call_id=resolution.tool_call_id,
            status=resolution.status.value, decided_by=resolution.decided_by,
        )
        return ConfirmToolResponse(
            task_id=task_id,
            tool_name=resolution.tool_name,
            tool_call_id=resolution.tool_call_id,
            tool_version=resolution.tool_version,
            status=resolution.status.value,
            decided_by=resolution.decided_by,
            decided_at=resolution.decided_at,
            comment=resolution.comment,
            expires_at=resolution.expires_at,
        )

    # ── 取消任务 ──
    async def cancel(
        self, task_id: str, *, actor_id: str | None,
    ) -> TaskCancelResponse:
        await self.ensure_owner(task_id, actor_id)
        running = self._task_service.get(task_id)
        if running is None:
            rt = await self._task_service.load_runtime(task_id)
            if rt is None:
                raise ResourceNotFoundException("任务", task_id)
            if rt.status in (
                TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED,
            ):
                return TaskCancelResponse(
                    task_id=task_id, status=rt.status, last_seq=rt.last_seq
                )
            transition_status(rt.status, TaskStatus.CANCELLED)
            rt.status = TaskStatus.CANCELLED
            await self._task_service.snapshot(rt)
            return TaskCancelResponse(
                task_id=task_id, status=rt.status, last_seq=rt.last_seq
            )

        rt = running.runtime
        if rt.status in (
            TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED,
        ):
            return TaskCancelResponse(
                task_id=task_id, status=rt.status, last_seq=rt.last_seq
            )
        # 1) 置取消信号并唤醒暂停等待；2) 撤销该任务全部审批票据唤醒审批等待
        running.request_cancel()
        if self._approval_store is not None:
            self._approval_store.revoke_task(task_id, reason="task_cancelled")
        if running.runner is not None:
            # 等待循环在检查点自行退出（含审批等待被撤销唤醒）
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(
                    asyncio.shield(running.runner), timeout=5.0
                )
            if not running.runner.done():
                # 兜底：注入 CancelledError，让循环走 _terminate(CANCELLED)
                running.runner.cancel()
                with contextlib.suppress(
                    asyncio.CancelledError, asyncio.TimeoutError,
                ):
                    await asyncio.wait_for(running.runner, timeout=2.0)
        runner_alive = running.runner is not None and not running.runner.done()
        if runner_alive:
            self._logger.warning(
                "task_cancel_runner_still_alive", task_id=task_id,
                status=rt.status.value,
            )
        elif rt.status not in (
            TaskStatus.CANCELLED, TaskStatus.COMPLETED, TaskStatus.FAILED,
        ):
            transition_status(rt.status, TaskStatus.CANCELLED)
            rt.status = TaskStatus.CANCELLED
            await self._task_service.snapshot(rt)
        self._logger.info(
            "task_cancelled", task_id=task_id, trace_id=rt.trace_id,
            last_seq=rt.last_seq,
        )
        return TaskCancelResponse(
            task_id=task_id, status=rt.status, last_seq=rt.last_seq
        )

    # ── 任务所有者校验 ──
    async def ensure_owner(self, task_id: str, actor_id: str | None) -> str:
        owner = await self._task_service.owner_of(task_id)
        if owner is None:
            rt = await self._task_service.load_runtime(task_id)
            if rt is None:
                raise ResourceNotFoundException("任务", task_id)
            owner = rt.actor_id
        if not actor_id or owner != actor_id:
            raise ForbiddenException("无权访问该任务")
        return owner

    # ── 内部 ──
    def _require_running(self, task_id: str) -> RunningTask:
        running = self._task_service.get(task_id)
        if running is None:
            raise ResourceNotFoundException("任务", task_id)
        return running
