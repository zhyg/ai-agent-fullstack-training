"""LLM Gateway：所有大模型调用的唯一入口，负责 ID 生成、路由、记录、追踪。"""
import asyncio
import time
import traceback
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from app.core.exceptions import (
    AppException,
    LLMTimeoutException,
    ModelNotAvailableException,
    get_error_stage,
)
from app.core.runtime import gen_request_id
from app.llm.adapter.base import BaseLLMAdapter
from app.llm.registry import MODEL_REGISTRY, ModelInfo, get_model_info
from app.llm.routing import SceneRouter
from app.llm.schemas import LLMChunk, LLMRequest, LLMResponse, TokenUsage

if TYPE_CHECKING:
    from app.infra.db import Database


class LLMGateway:
    """场景/别名路由 + 请求记录 + 异常链路写入。"""

    def __init__(
        self,
        adapters: dict[str, BaseLLMAdapter],
        db: "Database",
        logger,
        router: SceneRouter | None = None,
        timeout_seconds: float = 120.0,
    ):
        self._adapters = adapters
        self._db = db
        self._logger = logger
        self._router = router
        self._timeout = timeout_seconds

    def available_models(self) -> list[ModelInfo]:
        """可用模型列表（供应商适配器已就绪的）。"""
        return [m for m in MODEL_REGISTRY.values() if m.provider in self._adapters]

    def resolve_model(self, model_id: str | None = None, scene: str | None = None) -> str:
        """解析场景 / 别名到注册表模型 ID；无 router 时回退为原值。"""
        if self._router is None:
            return model_id or ""
        return self._router.resolve(model_id=model_id, scene=scene)

    def _route(self, model_id: str, scene: str | None = None) -> tuple[BaseLLMAdapter, ModelInfo]:
        resolved = self._router.resolve(model_id=model_id, scene=scene) if self._router else model_id
        info = get_model_info(resolved)
        if info is None:
            raise ModelNotAvailableException(resolved)
        adapter = self._adapters.get(info.provider)
        if adapter is None:
            raise ModelNotAvailableException(
                f"{resolved}（供应商 {info.provider} 未配置 API Key）"
            )
        return adapter, info

    async def invoke(
        self,
        req: LLMRequest,
        *,
        trace_id: str,
        business_id: str | None = None,
    ) -> LLMResponse:
        """统一调用入口：生成 request_id → 路由适配器 → 记录请求日志/异常链路。"""
        request_id = gen_request_id()
        resolved = self.resolve_model(req.model_id, req.scene)
        adapter, info = self._route(resolved)
        provider_req = req.model_copy(update={"model_id": info.provider_model})

        start = time.perf_counter()
        status = "success"
        error_type: str | None = None
        error_message: str | None = None
        usage = None
        resp: LLMResponse | None = None

        try:
            resp = await asyncio.wait_for(adapter.invoke(provider_req), timeout=self._timeout)
            usage = resp.usage
            return resp
        except asyncio.CancelledError:
            status = "cancelled"
            raise
        except asyncio.TimeoutError:
            status = "failed"
            error_type = "1501"
            error_message = f"LLM 调用超时（>{self._timeout}s）"
            await self._db.insert_error_trace(
                trace_id=trace_id,
                request_id=request_id,
                stage="in_transit",
                error_type=error_type,
                message=error_message,
                stack_trace=None,
                retry_count=adapter.last_retry_count,
                strategy="timeout_terminated",
            )
            raise LLMTimeoutException(error_message)
        except AppException as e:
            status = "failed"
            error_type = e.code.value
            error_message = e.message
            strategy = (
                f"retry_exhausted({adapter.last_retry_count})"
                if e.retryable else "no_retry_terminated"
            )
            await self._db.insert_error_trace(
                trace_id=trace_id,
                request_id=request_id,
                stage=get_error_stage(e),
                error_type=error_type,
                message=e.message,
                stack_trace=traceback.format_exc(),
                retry_count=adapter.last_retry_count,
                strategy=strategy,
            )
            self._logger.error(
                "llm_invoke_failed",
                trace_id=trace_id,
                request_id=request_id,
                model_id=resolved,
                error_type=error_type,
                message=e.message,
            )
            raise
        finally:
            latency_ms = int((time.perf_counter() - start) * 1000)
            await self._db.insert_request_log(
                request_id=request_id,
                trace_id=trace_id,
                business_id=business_id,
                model_id=resolved,
                endpoint=f"{info.provider}/chat",
                status=status,
                latency_ms=latency_ms,
                prompt_tokens=usage.prompt_tokens if usage else 0,
                completion_tokens=usage.completion_tokens if usage else 0,
                total_tokens=usage.total_tokens if usage else 0,
                retry_count=adapter.last_retry_count,
                error_type=error_type,
                error_message=error_message,
            )

    async def stream(
        self,
        req: LLMRequest,
        *,
        trace_id: str,
        business_id: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        """流式调用（记录日志但不重试，重试边界在非流式 invoke）。

        每个分片读取都受 timeout 限制，避免供应商长时间无输出导致挂死。
        """
        request_id = gen_request_id()
        resolved = self.resolve_model(req.model_id, req.scene)
        adapter, info = self._route(resolved)
        provider_req = req.model_copy(update={"model_id": info.provider_model})
        start = time.perf_counter()
        status = "success"
        error_type: str | None = None
        error_message: str | None = None
        usage = TokenUsage()
        stream = adapter.stream(provider_req)
        iterator = stream.__aiter__()
        try:
            while True:
                try:
                    chunk = await asyncio.wait_for(iterator.__anext__(), timeout=self._timeout)
                except StopAsyncIteration:
                    break
                except asyncio.TimeoutError:
                    status = "failed"
                    error_type = "1501"
                    error_message = f"LLM 流式响应超时（>{self._timeout}s 无分片）"
                    raise LLMTimeoutException(error_message)
                if chunk.usage is not None:
                    usage = chunk.usage
                yield chunk
        except asyncio.CancelledError:
            status = "cancelled"
            raise
        except AppException as e:
            status = "failed"
            error_type = e.code.value
            error_message = e.message
            await self._db.insert_error_trace(
                trace_id=trace_id,
                request_id=request_id,
                stage=get_error_stage(e),
                error_type=error_type,
                message=e.message,
                stack_trace=traceback.format_exc(),
                retry_count=0,
                strategy="stream_terminated",
            )
            raise
        finally:
            try:
                await stream.aclose()
            except Exception:  # 关闭异常不影响主流程
                pass
            latency_ms = int((time.perf_counter() - start) * 1000)
            await self._db.insert_request_log(
                request_id=request_id,
                trace_id=trace_id,
                business_id=business_id,
                model_id=resolved,
                endpoint=f"{info.provider}/chat_stream",
                status=status,
                latency_ms=latency_ms,
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                total_tokens=usage.total_tokens,
                retry_count=0,
                error_type=error_type,
                error_message=error_message,
            )

    async def aclose(self) -> None:
        for adapter in self._adapters.values():
            await adapter.aclose()
