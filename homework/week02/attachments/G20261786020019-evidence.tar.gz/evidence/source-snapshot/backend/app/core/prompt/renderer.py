"""模板渲染：构建决策消息与纠错消息。模板优先从配置文件读取，失败时回退内置默认。"""
import json

from app.config import settings
from app.core.prompt.config import PromptConfigManager
from app.core.prompt.security import escape_user_input
from app.core.prompt.templates import (
    CORRECTION_PROMPT,
    DECISION_PROMPT,
    OUTPUT_FORMAT_DESCRIPTION,
    SYSTEM_PROMPT,
)
from app.llm.schemas import Message, ToolDef

# 全局 Prompt 配置管理器（支持文件热加载）
prompt_manager = PromptConfigManager(settings.prompt_config_path)


def get_prompt_manager() -> PromptConfigManager:
    return prompt_manager


def _templates_available() -> bool:
    try:
        prompt_manager.load()
        return True
    except Exception:
        return False


def _render(scene: str, key: str, variables: dict, fallback: str) -> str:
    """优先使用配置模板，配置不可用时回退内置默认模板。"""
    if _templates_available():
        try:
            return prompt_manager.render(scene, key, variables)
        except Exception:
            pass
    try:
        return fallback.format_map(variables)
    except KeyError:
        return fallback


def _raw_template(scene: str, key: str, fallback: str) -> str:
    if _templates_available():
        try:
            return prompt_manager.get_template(scene, key)
        except Exception:
            pass
    return fallback


def _format_tools_description(tools: list[ToolDef]) -> str:
    """生成工具清单文本，供模型理解。"""
    if not tools:
        return "（无可用工具）"
    lines = []
    for t in tools:
        params = json.dumps(t.parameters, ensure_ascii=False)
        lines.append(f"- {t.name}: {t.description}，参数 Schema: {params}")
    return "\n".join(lines)


def _format_executed_steps(steps: list[dict]) -> str:
    if not steps:
        return "（尚无已执行步骤）"
    lines = []
    for s in steps:
        line = f"步骤 {s.get('step')}: action={s.get('action')}"
        if s.get("thought"):
            line += f"，思考: {s['thought']}"
        if s.get("tool_name"):
            line += f"，工具: {s['tool_name']}({json.dumps(s.get('tool_args') or {}, ensure_ascii=False)})"
        if s.get("tool_summary"):
            line += f"，结果: {s['tool_summary']}"
        lines.append(line)
    return "\n".join(lines)


def build_system_message(tools: list[ToolDef]) -> Message:
    """System Prompt：角色、准则、可用工具。"""
    content = _render(
        "agent", "system",
        {"tools_description": _format_tools_description(tools)},
        SYSTEM_PROMPT,
    )
    return Message(role="system", content=content)


def build_run_system_message(tools: list[ToolDef]) -> Message:
    """可复用 AgentRunner 的 System Prompt（原生 tool calls 模式）。"""
    content = _render(
        "run", "system",
        {"tools_description": _format_tools_description(tools)},
        SYSTEM_PROMPT,
    )
    return Message(role="system", content=content)


def build_decision_message(
    *,
    task: str,
    current_step: int,
    max_steps: int,
    executed_steps: list[dict],
) -> Message:
    """决策请求消息：用户输入（转义防注入）+ 运行时上下文 + 输出格式。"""
    content = _render(
        "agent", "decision",
        {
            "task": escape_user_input(task),
            "current_step": current_step,
            "max_steps": max_steps,
            "executed_steps": _format_executed_steps(executed_steps),
            "output_format": _raw_template("agent", "output_format", OUTPUT_FORMAT_DESCRIPTION),
        },
        DECISION_PROMPT,
    )
    return Message(role="user", content=content)


def build_correction_message(*, errors: list[dict], original_output: str) -> Message:
    """纠错消息：附带校验错误与原始输出，要求重新输出。"""
    content = _render(
        "agent", "correction",
        {
            "errors": json.dumps(errors, ensure_ascii=False, indent=2),
            "original_output": original_output,
        },
        CORRECTION_PROMPT,
    )
    return Message(role="user", content=content)
