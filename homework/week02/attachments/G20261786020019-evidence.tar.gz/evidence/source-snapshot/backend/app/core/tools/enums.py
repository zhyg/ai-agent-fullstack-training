"""Tool Runtime 枚举：风险、副作用、权限、状态、错误分类、审批状态。"""
from enum import Enum


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ToolEffect(str, Enum):
    """工具的副作用类型，决定是否可安全重放。"""

    READ_ONLY = "read_only"                       # 只读，可重放
    IDEMPOTENT_WRITE = "idempotent_write"         # 有幂等键时可重放
    NON_IDEMPOTENT_WRITE = "non_idempotent_write"  # 默认不可重放


class ToolPermission(str, Enum):
    TOOL_USE = "tool.use"
    NETWORK = "net.network"
    EMAIL_SEND = "email.send"
    FILE_WRITE = "file.write"
    BILL_QUERY = "bill.query"
    SHOPPING_REQUEST = "shopping.request"
    SHOPPING_APPROVE = "shopping.approve"
    ORDER_CREATE = "order.create"
    ORDER_PAY = "order.pay"
    ORDER_REFUND = "order.refund"
    ORDER_QUERY = "order.query"
    ADMIN = "admin"


class ToolOrigin(str, Enum):
    """工具来源：内置 / MCP / 外部插件。"""

    BUILTIN = "builtin"
    MCP = "mcp"
    PLUGIN = "plugin"


class VersionStatus(str, Enum):
    ACTIVE = "active"          # 可执行
    DISABLED = "disabled"      # 硬禁用，立即不可执行
    DEPRECATED = "deprecated"  # 仍可执行，但不再作为新快照默认版本


class ToolExecutionStatus(str, Enum):
    SUCCESS = "success"
    INVALID_INPUT = "invalid_input"
    PERMISSION_DENIED = "permission_denied"
    APPROVAL_DENIED = "approval_denied"
    APPROVAL_TIMEOUT = "approval_timeout"
    TOOL_DISABLED = "tool_disabled"
    VERSION_STALE = "version_stale"
    SNAPSHOT_EXPIRED = "snapshot_expired"
    DEPENDENCY_NOT_MET = "dependency_not_met"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    FAILED = "failed"
    OUTPUT_INVALID = "output_invalid"


class ToolErrorCategory(str, Enum):
    VALIDATION = "validation"
    PERMISSION = "permission"
    NOT_FOUND = "not_found"
    KILL_SWITCH = "kill_switch"
    VERSION_STALE = "version_stale"
    DEPENDENCY = "dependency"
    APPROVAL = "approval"
    TIMEOUT = "timeout"
    NETWORK = "network"
    RATE_LIMIT = "rate_limit"
    UPSTREAM = "upstream"
    AUTH = "auth"
    BUSINESS = "business"
    OUTPUT_SCHEMA = "output_schema"
    CANCELLED = "cancelled"
    INTERNAL = "internal"


class ErrorPhase(str, Enum):
    PRE_SIDE_EFFECT = "pre_side_effect"    # 确定未产生副作用，可安全重放
    POST_SIDE_EFFECT = "post_side_effect"  # 已产生副作用，不可重放
    UNKNOWN = "unknown"                    # 默认按不可重放处理


class ApprovalStatus(str, Enum):
    NOT_REQUIRED = "not_required"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"


class ApprovalTicketStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    EXPIRED = "expired"
    CONSUMED = "consumed"
    CANCELLED = "cancelled"


class ModelAction(str, Enum):
    """工具错误回灌模型时允许的动作建议（不是 LLM 的 ActionType）。"""

    FIX_ARGUMENTS = "fix_arguments"
    RETRY_SAME = "retry_same"
    ASK_USER = "ask_user"
    USE_ALTERNATIVE = "use_alternative"
    STOP = "stop"
    NONE = "none"
