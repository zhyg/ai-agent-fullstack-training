"""提示词配置管理：从 JSON 文件读取模板，支持场景/版本选择与 mtime 热加载。"""
import json
from pathlib import Path

from app.core.exceptions import ConfigurationError


class PromptConfigManager:
    """提示词模板配置器。

    配置结构（JSON）：
    {
      "version": "1",
      "scenes": {
        "agent": {
          "description": "多步 Agent 决策循环",
          "active": "v1",
          "versions": {
            "v1": {"system": [...], "decision": [...], "correction": [...], "output_format": [...]}
          }
        }
      }
    }
    模板值可以是字符串，也可以是字符串数组（按行拼接，便于维护多行模板）。
    """

    def __init__(self, path: str):
        self._path = Path(path)
        self._raw: dict = {}
        self._mtime: float = -1.0

    # ── 加载 ──
    def load(self, force: bool = False) -> None:
        """读取配置文件；未变化时跳过（基于 mtime 的热加载）。"""
        try:
            mtime = self._path.stat().st_mtime
        except FileNotFoundError:
            self._raw, self._mtime = {}, -1.0
            return
        if not force and mtime == self._mtime:
            return
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise ConfigurationError(f"提示词配置读取失败: {self._path}: {e}") from e
        self._validate(data)
        self._raw = data
        self._mtime = mtime

    @staticmethod
    def _validate(data: dict) -> None:
        scenes = data.get("scenes")
        if not isinstance(scenes, dict) or not scenes:
            raise ConfigurationError("提示词配置格式错误：scenes 必须为非空对象")
        for name, scene in scenes.items():
            if not isinstance(scene, dict):
                raise ConfigurationError(f"场景 {name} 配置格式错误")
            versions = scene.get("versions")
            if not isinstance(versions, dict) or not versions:
                raise ConfigurationError(f"场景 {name} 缺少 versions")
            active = scene.get("active") or next(iter(versions))
            if active not in versions:
                raise ConfigurationError(f"场景 {name} 的 active 版本 {active} 不存在")
            for ver, templates in versions.items():
                if not isinstance(templates, dict) or not templates:
                    raise ConfigurationError(f"场景 {name}/{ver} 模板为空")

    def _ensure_loaded(self) -> None:
        self.load()

    @staticmethod
    def _normalize_template(value) -> str:
        if isinstance(value, list):
            return "\n".join(str(v) for v in value)
        return str(value)

    # ── 查询 ──
    def reload(self) -> dict:
        """强制重载，返回摘要。"""
        self.load(force=True)
        return self.summary()

    def summary(self) -> dict:
        self._ensure_loaded()
        scenes = self._raw.get("scenes") or {}
        return {
            "path": str(self._path),
            "version": str(self._raw.get("version", "1")),
            "scenes": [
                {
                    "name": name,
                    "description": scene.get("description", ""),
                    "active": scene.get("active") or next(iter(scene.get("versions", {}))),
                    "versions": list((scene.get("versions") or {}).keys()),
                    "templates": list(
                        ((scene.get("versions") or {}).get(
                            scene.get("active") or next(iter(scene.get("versions", {})))
                        ) or {}).keys()
                    ),
                }
                for name, scene in scenes.items()
            ],
        }

    def scene_detail(self, scene: str, version: str | None = None) -> dict:
        """返回场景指定版本的模板文本。"""
        self._ensure_loaded()
        scenes = self._raw.get("scenes") or {}
        spec = scenes.get(scene)
        if spec is None:
            raise ConfigurationError(f"提示词场景不存在: {scene}")
        versions = spec.get("versions") or {}
        ver = version or spec.get("active") or next(iter(versions))
        templates = versions.get(ver)
        if templates is None:
            raise ConfigurationError(f"提示词版本不存在: {scene}/{ver}")
        rendered = {
            key: self._normalize_template(value) for key, value in templates.items()
        }
        return {
            "scene": scene,
            "version": ver,
            "active": ver == (spec.get("active") or next(iter(versions))),
            "description": spec.get("description", ""),
            "versions": list(versions.keys()),
            "templates": rendered,
        }

    def get_template(self, scene: str, key: str, version: str | None = None) -> str:
        """取原始模板（不做变量渲染）。"""
        detail = self.scene_detail(scene, version)
        templates = detail["templates"]
        if key not in templates:
            raise KeyError(f"模板不存在: {scene}/{detail['version']}/{key}")
        return templates[key]

    def render(
        self,
        scene: str,
        key: str,
        variables: dict | None = None,
        version: str | None = None,
    ) -> str:
        """渲染模板变量；缺失变量保留原占位符，避免运行时崩溃。"""
        template = self.get_template(scene, key, version)
        if variables is None:
            return template

        class _SafeDict(dict):
            def __missing__(self, k):
                return "{" + k + "}"

        return template.format_map(_SafeDict(variables))
