"""MCP → ToolDefinition 注册器：每个 server 先完整构造，再一次 register_batch 提交。"""
import json
import re
from pathlib import Path
from typing import Any

from pydantic import Field, create_model

from app.core.exceptions import ConfigurationError
from app.core.tools.definition import (
    HandlerOutput,
    ToolDefinition,
    ToolGovernance,
    ToolSpec,
)
from app.core.tools.enums import RiskLevel, ToolEffect, ToolOrigin, ToolPermission
from app.core.tools.mcp.client import McpClient, MockMcpClient
from app.core.tools.policy import apply_governance
from app.core.tools.registry import ToolRegistry, governance_with_defaults
from app.core.tools.session import HandlerContext

_NAME_LIMIT = 64
_INVALID_CHARS = re.compile(r"[^a-z0-9_]+")
_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "array": list,
    "object": dict,
}


def normalize_tool_name(server_id: str, tool_name: str) -> str:
    """mcp_{server_id}_{tool_name}，小写下划线，长度超 64 直接拒绝（不静默截断）。"""
    raw = f"mcp_{server_id}_{tool_name}".lower()
    normalized = _INVALID_CHARS.sub("_", raw).strip("_")
    if len(normalized) > _NAME_LIMIT:
        raise ConfigurationError(
            f"MCP 工具名超过 {_NAME_LIMIT} 字符: {normalized}"
        )
    return normalized


def _build_input_model(tool_name: str, schema: dict[str, Any]) -> type:
    """从 JSON Schema 基础类型生成 Pydantic 输入模型；不支持的类型拒绝该 server。"""
    properties = schema.get("properties") or {}
    required = set(schema.get("required") or [])
    fields: dict[str, Any] = {}
    for prop, spec in properties.items():
        json_type = (spec or {}).get("type")
        if json_type not in _TYPE_MAP:
            raise ConfigurationError(
                f"MCP 工具 {tool_name} 字段 {prop} 类型不受支持: {json_type}"
            )
        base = _TYPE_MAP[json_type]
        description = (spec or {}).get("description", "")
        if prop in required:
            fields[prop] = (base, Field(..., description=description))
        else:
            fields[prop] = (base | None, Field(None, description=description))
    model_name = re.sub(r"[^0-9a-zA-Z]", "_", tool_name).title().replace("_", "") or "Mcp"
    return create_model(f"{model_name}Args", **fields)


def _make_handler(client: McpClient, remote_name: str):
    async def handler(args, ctx: HandlerContext) -> HandlerOutput:
        payload = args.model_dump(mode="json", exclude_none=True)
        data = await client.call_tool(remote_name, payload)
        if not isinstance(data, dict):
            data = {"result": data}
        return HandlerOutput(data=data, summary=f"MCP 工具 {remote_name} 调用完成")

    return handler


class McpToolProvider:
    """单个 MCP server 的工具定义构造器。"""

    def __init__(
        self,
        *,
        server_id: str,
        version: str,
        tools: list[dict[str, Any]],
        client: McpClient,
        origin: ToolOrigin = ToolOrigin.MCP,
    ):
        self.server_id = server_id
        self.version = version
        self._tools = tools
        self._client = client
        self._origin = origin

    def definitions(self) -> list[ToolDefinition]:
        result: list[ToolDefinition] = []
        for tool in self._tools:
            remote_name = tool.get("name")
            if not remote_name:
                raise ConfigurationError(f"MCP server {self.server_id} 存在无名工具")
            schema = tool.get("input_schema") or {"type": "object", "properties": {}}
            if schema.get("type") != "object":
                raise ConfigurationError(
                    f"MCP 工具 {remote_name} input_schema 必须为 object"
                )
            local_name = normalize_tool_name(self.server_id, remote_name)
            input_model = _build_input_model(local_name, schema)
            read_only = bool(tool.get("read_only", False))
            risk = _parse_risk(tool.get("risk_level"), read_only)
            governance = governance_with_defaults(
                permissions={ToolPermission.TOOL_USE},
                risk_level=risk,
                effect=ToolEffect.READ_ONLY if read_only else ToolEffect.NON_IDEMPOTENT_WRITE,
                requires_confirmation=None if read_only else True,
                timeout_seconds=15.0,
            )
            spec = ToolSpec(
                name=local_name,
                version=self.version,
                display_name=remote_name,
                description=tool.get("description", f"MCP 工具 {remote_name}"),
                input_model=input_model,
                input_schema=schema,
                origin=self._origin,
                plugin_id=self.server_id,
            )
            result.append(ToolDefinition(
                spec=spec,
                governance=governance,
                handler=_make_handler(self._client, remote_name),
                handler_id=f"mcp.{self.server_id}.{remote_name}",
            ))
        return result


def _parse_risk(value: Any, read_only: bool) -> RiskLevel:
    if value is None:
        return RiskLevel.LOW if read_only else RiskLevel.HIGH
    try:
        return RiskLevel(str(value))
    except ValueError as exc:
        raise ConfigurationError(f"MCP 工具 risk_level 非法: {value}") from exc


def load_mcp_config(path: str | Path | None) -> list[dict[str, Any]]:
    if not path:
        return []
    file_path = Path(path)
    if not file_path.exists():
        return []
    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigurationError(f"MCP 配置读取失败: {exc}") from exc
    servers = payload.get("servers", [])
    if not isinstance(servers, list):
        raise ConfigurationError("MCP 配置 servers 必须为数组")
    return servers


def build_mcp_client(server: dict[str, Any]) -> McpClient:
    transport = server.get("transport", "mock")
    if transport != "mock":
        raise ConfigurationError(f"不支持的 MCP transport: {transport}")
    tool_names = [t.get("name") for t in server.get("tools", []) if t.get("name")]
    return MockMcpClient(server["id"], tool_names)


def register_mcp_servers(
    registry: ToolRegistry,
    config_path: str | Path | None,
    *,
    logger=None,
    governance_overrides: dict[str, Any] | None = None,
    actor: str | None = "system",
) -> list[str]:
    """每个 server 独立构造并一次性提交；失败只跳过该 server。"""
    registered: list[str] = []
    for server in load_mcp_config(config_path):
        server_id = server.get("id")
        try:
            if not server_id:
                raise ConfigurationError("MCP server 缺少 id")
            client = build_mcp_client(server)
            provider = McpToolProvider(
                server_id=server_id,
                version=str(server.get("version", "1.0.0")),
                tools=server.get("tools", []),
                client=client,
            )
            definitions = provider.definitions()
            overrides = (governance_overrides or {})
            prepared = []
            for definition in definitions:
                override = overrides.get(definition.name, {})
                if override:
                    definition = ToolDefinition(
                        spec=definition.spec,
                        governance=apply_governance(override, definition.governance),
                        handler=definition.handler,
                        handler_id=definition.handler_id,
                    )
                prepared.append(definition)
            registry.register_batch(prepared, activate=True, actor=actor)
            registered.append(server_id)
        except Exception as exc:  # 单 server 失败隔离
            if logger is not None:
                logger.warning(
                    "mcp_server_skipped", server_id=server_id, error=str(exc)
                )
    return registered
