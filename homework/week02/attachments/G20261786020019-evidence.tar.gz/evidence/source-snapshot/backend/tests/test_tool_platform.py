"""工具平台二期验收测试：审批票据、身份/角色、错误动作、订单、MCP、插件与迁移。"""
import asyncio
import json
import uuid
from datetime import datetime, timedelta, timezone

import aiosqlite
import pytest
from pydantic import BaseModel

from app.config import Settings, settings
from app.core.exceptions import ConfigurationError
from app.core.tools.approval import (
    ApprovalError,
    ApprovalStore,
    TicketApprovalGate,
    token_hash,
)
from app.core.tools.catalog import build_default_registry
from app.core.tools.definition import (
    HandlerOutput,
    ToolDefinition,
    ToolSpec,
)
from app.core.tools.enums import (
    ApprovalStatus,
    ApprovalTicketStatus,
    ErrorPhase,
    ModelAction,
    RiskLevel,
    ToolEffect,
    ToolErrorCategory,
    ToolExecutionStatus,
    ToolPermission,
)
from app.core.tools.error_schema import build_tool_error_schema
from app.core.tools.errors import ToolBusinessError, ToolCancelledError, ToolVersionConflictError
from app.core.tools.handlers import orders
from app.core.tools.registry import ToolRegistry, governance_with_defaults
from app.core.tools.runtime import ToolRuntime
from app.core.tools.session import (
    ActorContext,
    AutoApproveApprovalGate,
    HandlerContext,
    NoopControl,
    ToolApprovalRequest,
    ToolCallRequest,
)
from app.api.schemas.task import TaskStatus
from app.core.runtime import TaskRuntime, gen_task_id
from app.infra.db import Database
from app.infra.migrations import run_migrations
from app.services.event_buffer import EventBuffer
from app.services.permission_service import PermissionService
from app.services.task_service import RunningTask, TaskService
from app.api.schemas.sse import SSEEventType

ALL_PERMISSIONS = frozenset(ToolPermission)


class NullLogger:
    def __getattr__(self, _name):
        def _noop(*_args, **_kwargs):
            return None

        return _noop


class FakeAuditor:
    def __init__(self):
        self.records = []

    async def record(self, record):
        self.records.append(record)


def make_actor(actor_id: str, roles=("admin",)) -> ActorContext:
    return ActorContext(
        actor_id=actor_id,
        tenant_id=None,
        granted_permissions=ALL_PERMISSIONS,
        roles=frozenset(roles),
    )


def make_approval_request(
    *, task_id="task_x", tool_call_id="tc_1", actor_id="user_a",
    snapshot_expires_at=None,
) -> ToolApprovalRequest:
    return ToolApprovalRequest(
        task_id=task_id,
        step=1,
        round=1,
        tool_call_id=tool_call_id,
        tool_name="pay_order",
        tool_version="1.0.0",
        tool_args={"order_id": "ord_1"},
        risk_level=RiskLevel.HIGH,
        snapshot_id="snap_x",
        message="确认支付",
        trace_id="trace_x",
        fingerprint="fp",
        args_hash="hash",
        actor_id=actor_id,
        roles=frozenset({"admin"}),
        snapshot_expires_at=snapshot_expires_at,
    )


@pytest.fixture()
def registry() -> ToolRegistry:
    return build_default_registry(
        "./config/tools.json", "system",
        mcp_config_path="./config/mcp_servers.json",
        logger=NullLogger(),
    )


async def _new_order(actor_id: str, client_order_no: str) -> str:
    result = await orders.handle_create_order(
        orders.CreateOrderArgs(
            product_id="sku_1",
            product_name="测试商品",
            quantity=1,
            unit_price=9.9,
            client_order_no=client_order_no,
        ),
        HandlerContext(
            tool_call_id="create_1", task_id="task_x",
            trace_id="trace_x", actor_id=actor_id,
        ),
    )
    return result.data["order_id"]


async def _wait_for_token(events: list, timeout: float = 2.0) -> str:
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        if events:
            return events[0]["approval_token"]
        await asyncio.sleep(0.01)
    raise AssertionError("未等到审批事件")


# ── 审批票据 ──
async def test_approval_token_binding_and_single_consume():
    store = ApprovalStore()
    req = make_approval_request()
    ticket = store.issue(req, ttl_seconds=60)

    with pytest.raises(ApprovalError) as wrong_actor:
        store.resolve(
            ticket.token, task_id="task_x", actor_id="other",
            approved=True,
        )
    assert wrong_actor.value.code == "APPROVAL_TOKEN_INVALID"

    resolution = store.resolve(
        ticket.token, task_id="task_x", actor_id="user_a", approved=True,
    )
    assert resolution.status == ApprovalTicketStatus.APPROVED
    assert resolution.decided_by == "user_a"

    consumed = store.consume(
        ticket.token, task_id="task_x", tool_call_id="tc_1",
    )
    assert consumed.tool_name == "pay_order"
    assert store.status_of(ticket.token) == ApprovalTicketStatus.CONSUMED

    with pytest.raises(ApprovalError) as second:
        store.consume(ticket.token, task_id="task_x", tool_call_id="tc_1")
    assert second.value.code == "APPROVAL_TOKEN_CONSUMED"


async def test_approval_snapshot_expired_rejected():
    store = ApprovalStore()
    req = make_approval_request(
        snapshot_expires_at=datetime.now(timezone.utc) - timedelta(seconds=1)
    )
    with pytest.raises(ApprovalError) as exc:
        store.issue(req, ttl_seconds=60)
    assert exc.value.code == "APPROVAL_SNAPSHOT_EXPIRED"


async def test_approval_wait_expires_and_revoke_wakes():
    store = ApprovalStore()
    ticket = store.issue(make_approval_request(), ttl_seconds=0.02)
    resolution = await store.wait(ticket.token)
    assert resolution.status == ApprovalTicketStatus.EXPIRED

    ticket2 = store.issue(
        make_approval_request(tool_call_id="tc_2"), ttl_seconds=60
    )
    task = asyncio.create_task(store.wait(ticket2.token))
    await asyncio.sleep(0)
    assert store.revoke_task("task_x", reason="cancelled") == 1
    resolution2 = await task
    assert resolution2.status == ApprovalTicketStatus.CANCELLED


# ── 模型动作映射 ──
@pytest.mark.parametrize(
    "category,effect,retryable,status,expected",
    [
        (ToolErrorCategory.VALIDATION, ToolEffect.READ_ONLY, False, None,
         ModelAction.FIX_ARGUMENTS),
        (ToolErrorCategory.PERMISSION, ToolEffect.READ_ONLY, False, None,
         ModelAction.ASK_USER),
        (ToolErrorCategory.NOT_FOUND, ToolEffect.READ_ONLY, False, None,
         ModelAction.USE_ALTERNATIVE),
        (ToolErrorCategory.TIMEOUT, ToolEffect.READ_ONLY, True, None,
         ModelAction.RETRY_SAME),
        (ToolErrorCategory.TIMEOUT, ToolEffect.NON_IDEMPOTENT_WRITE, True, None,
         ModelAction.ASK_USER),
        (ToolErrorCategory.INTERNAL, ToolEffect.READ_ONLY, False, None,
         ModelAction.NONE),
        (ToolErrorCategory.APPROVAL, ToolEffect.NON_IDEMPOTENT_WRITE, False,
         ToolExecutionStatus.APPROVAL_TIMEOUT, ModelAction.ASK_USER),
        (ToolErrorCategory.APPROVAL, ToolEffect.NON_IDEMPOTENT_WRITE, False,
         ToolExecutionStatus.APPROVAL_DENIED, ModelAction.STOP),
    ],
)
def test_error_schema_model_action(category, effect, retryable, status, expected):
    schema = build_tool_error_schema(
        code="E",
        category=category,
        phase=ErrorPhase.PRE_SIDE_EFFECT,
        retryable=retryable,
        effect=effect,
        status=status,
        model_message="安全提示",
    )
    assert schema.model_action == expected
    assert "token" not in schema.to_llm_dict()
    if category in (ToolErrorCategory.INTERNAL,):
        assert schema.resolvable_by_model is False


# ── 运行时审批 ──
async def test_pay_order_requires_ticket_approval_then_consumes(registry):
    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    order_id = await _new_order(actor_id, f"c_{uuid.uuid4().hex[:8]}")
    store = ApprovalStore()
    auditor = FakeAuditor()
    runtime = ToolRuntime(
        registry, auditor, NullLogger(), approval_store=store,
    )
    events: list[dict] = []
    persisted: list[dict] = []

    async def emit(sse_data, persist_data):
        events.append(sse_data)
        persisted.append(persist_data)

    async def noop():
        return None

    gate = TicketApprovalGate(
        store, ttl_seconds=5, emit=emit,
        set_waiting=noop, set_running=noop,
    )
    session = runtime.open_session(
        task_id="task_x", trace_id="trace_x",
        actor=make_actor(actor_id), control=NoopControl(),
        approval_gate=gate,
    )
    snapshot = runtime.build_snapshot(session, round=1)
    call = ToolCallRequest(
        tool_name="pay_order",
        arguments={
            "order_id": order_id, "method": "balance",
            "client_payment_no": f"pay_{uuid.uuid4().hex[:8]}",
        },
        tool_call_id="tc_pay", round=1,
    )
    task = asyncio.create_task(runtime.execute(snapshot, call, session))
    token = await _wait_for_token(events)
    assert "approval_token" not in persisted[0]
    assert persisted[0]["approval_token_hash"] == token_hash(token)

    store.resolve(
        token, task_id="task_x", actor_id=actor_id,
        approved=True, comment="同意",
    )
    result = await task
    assert result.success
    assert result.data["status"] == "paid"
    assert store.status_of(token) == ApprovalTicketStatus.CONSUMED

    record = auditor.records[-1]
    assert record.approval_status == ApprovalStatus.APPROVED
    assert record.approval_token_hash == token_hash(token)
    assert record.approved_by == actor_id
    assert record.approval_comment == "同意"
    assert record.approval_requested_at is not None


async def test_denied_approval_stops_without_side_effect(registry):
    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    order_id = await _new_order(actor_id, f"c_{uuid.uuid4().hex[:8]}")
    store = ApprovalStore()
    runtime = ToolRuntime(
        registry, FakeAuditor(), NullLogger(), approval_store=store,
    )
    events: list[dict] = []

    async def emit(sse_data, persist_data):
        events.append(sse_data)

    async def noop():
        return None

    gate = TicketApprovalGate(
        store, ttl_seconds=5, emit=emit,
        set_waiting=noop, set_running=noop,
    )
    session = runtime.open_session(
        task_id="task_x", trace_id="trace_x",
        actor=make_actor(actor_id), control=NoopControl(),
        approval_gate=gate,
    )
    snapshot = runtime.build_snapshot(session, round=1)
    call = ToolCallRequest(
        tool_name="pay_order",
        arguments={
            "order_id": order_id, "method": "card",
            "client_payment_no": f"pay_{uuid.uuid4().hex[:8]}",
        },
        tool_call_id="tc_pay", round=1,
    )
    task = asyncio.create_task(runtime.execute(snapshot, call, session))
    token = await _wait_for_token(events)
    store.resolve(
        token, task_id="task_x", actor_id=actor_id, approved=False,
        comment="拒绝",
    )
    result = await task
    assert result.status == ToolExecutionStatus.APPROVAL_DENIED
    assert result.error_schema is not None
    assert result.error_schema.model_action == ModelAction.STOP
    assert result.error_schema.resolvable_by_model is True

    queried = await orders.handle_query_order(
        orders.QueryOrderArgs(order_id=order_id),
        HandlerContext(
            tool_call_id="q", task_id="task_x",
            trace_id="trace_x", actor_id=actor_id,
        ),
    )
    assert queried.data["orders"][0]["status"] == "created"


async def test_cancel_while_waiting_approval_raises(registry):
    store = ApprovalStore()
    runtime = ToolRuntime(
        registry, FakeAuditor(), NullLogger(), approval_store=store,
    )
    events: list[dict] = []

    async def emit(sse_data, persist_data):
        events.append(sse_data)

    async def noop():
        return None

    gate = TicketApprovalGate(
        store, ttl_seconds=60, emit=emit,
        set_waiting=noop, set_running=noop,
    )
    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    session = runtime.open_session(
        task_id="task_cancel", trace_id="trace_x",
        actor=make_actor(actor_id), control=NoopControl(),
        approval_gate=gate,
    )
    snapshot = runtime.build_snapshot(session, round=1)
    call = ToolCallRequest(
        tool_name="pay_order",
        arguments={
            "order_id": "ord_missing", "method": "balance",
            "client_payment_no": "pay_x",
        },
        tool_call_id="tc_cancel", round=1,
    )
    task = asyncio.create_task(runtime.execute(snapshot, call, session))
    await _wait_for_token(events)
    store.revoke_task("task_cancel", reason="task_cancelled")
    with pytest.raises(ToolCancelledError):
        await task


# ── 身份 / 角色 ──
async def test_refund_role_denied_after_identity_refresh(registry):
    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    admin = make_actor(actor_id, roles=("admin",))
    runtime = ToolRuntime(registry, FakeAuditor(), NullLogger())

    async def refresh(_actor_id: str) -> ActorContext:
        return make_actor(actor_id, roles=("staff",))

    session = runtime.open_session(
        task_id="task_role", trace_id="trace_role",
        actor=admin, control=NoopControl(),
        approval_gate=AutoApproveApprovalGate(),
        refresh_actor=refresh,
    )
    snapshot = runtime.build_snapshot(session, round=1)
    result = await runtime.execute(
        snapshot,
        ToolCallRequest(
            tool_name="refund_order",
            arguments={"order_id": "ord_1", "reason": "测试"},
            tool_call_id="tc_role", round=1,
        ),
        session,
    )
    assert result.status == ToolExecutionStatus.PERMISSION_DENIED
    assert result.error_info is not None
    assert result.error_info.code == "TOOL_ROLE_DENIED"


async def test_permission_service_has_no_implicit_default(tmp_path):
    db = Database(f"sqlite:///{(tmp_path / 'perm.db').as_posix()}")
    await db.init()
    try:
        service = PermissionService(db)
        anonymous = await service.resolve(None)
        assert anonymous.granted_permissions == frozenset()
        assert anonymous.roles == frozenset()

        ghost = await service.resolve("ghost_user")
        assert ghost.granted_permissions == frozenset()

        admin = await service.resolve(settings.default_user_id)
        assert "admin" in admin.roles
        assert ToolPermission.ORDER_REFUND in admin.granted_permissions
        assert await service.is_admin(settings.default_user_id) is True
    finally:
        await db.close()


# ── 订单业务 ──
async def test_create_order_idempotency_and_conflict():
    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    client_no = f"c_{uuid.uuid4().hex[:8]}"
    ctx = HandlerContext(
        tool_call_id="c", task_id="task_x", trace_id="trace_x",
        actor_id=actor_id,
    )
    args = orders.CreateOrderArgs(
        product_id="sku", product_name="商品", quantity=2,
        unit_price=3.5, client_order_no=client_no,
    )
    first = await orders.handle_create_order(args, ctx)
    second = await orders.handle_create_order(args, ctx)
    assert first.data["order_id"] == second.data["order_id"]

    changed = args.model_copy(update={"quantity": 3})
    with pytest.raises(ToolBusinessError) as exc:
        await orders.handle_create_order(changed, ctx)
    assert exc.value.code == "IDEMPOTENCY_CONFLICT"


# ── 注册表 / 插件 ──
async def test_plugin_offline_blocks_old_snapshot_then_online(registry):
    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    runtime = ToolRuntime(registry, FakeAuditor(), NullLogger())
    session = runtime.open_session(
        task_id="task_scope", trace_id="trace_scope",
        actor=make_actor(actor_id), control=NoopControl(),
        approval_gate=AutoApproveApprovalGate(),
    )
    snapshot = runtime.build_snapshot(session, round=1)

    registry.disable_scope("builtin.orders")
    blocked = await runtime.execute(
        snapshot,
        ToolCallRequest(
            tool_name="query_order", arguments={"status": "created"},
            tool_call_id="tc_off", round=1,
        ),
        session,
    )
    assert blocked.status == ToolExecutionStatus.TOOL_DISABLED
    assert blocked.error_schema.code == "TOOL_OFFLINE"
    assert blocked.error_schema.model_action == ModelAction.USE_ALTERNATIVE

    registry.enable_latest_scope("builtin.orders")
    fresh = runtime.build_snapshot(session, round=2)
    allowed = await runtime.execute(
        fresh,
        ToolCallRequest(
            tool_name="query_order", arguments={"status": "created"},
            tool_call_id="tc_on", round=2,
        ),
        session,
    )
    assert allowed.success


def test_register_batch_is_atomic_and_revision_once():
    class Args(BaseModel):
        value: int

    async def handler(args, ctx):
        return HandlerOutput(data={})

    def definition(description: str) -> ToolDefinition:
        return ToolDefinition(
            spec=ToolSpec.create(
                name="tmp_batch_tool", version="1.0.0",
                description=description, input_model=Args,
            ),
            governance=governance_with_defaults(
                permissions={ToolPermission.TOOL_USE},
                risk_level=RiskLevel.LOW,
                effect=ToolEffect.READ_ONLY,
            ),
            handler=handler,
            handler_id="tests.tmp",
        )

    reg = ToolRegistry()
    reg.register_batch([definition("v1")])
    assert reg.revision == 1
    reg.register_batch([definition("v1")])
    assert reg.revision == 1
    with pytest.raises(ToolVersionConflictError):
        reg.register_batch([definition("changed")])
    assert reg.revision == 1


async def test_mcp_tools_registered_and_readonly_invocation(registry):
    summary = registry.summary()
    by_name = {tool["name"]: tool for tool in summary["tools"]}
    assert "mcp_mock_erp_query_inventory" in by_name
    purchase = by_name["mcp_mock_erp_create_purchase"]["versions"][0]
    assert purchase["requires_confirmation"] is True
    assert purchase["origin"] == "mcp"

    actor_id = f"user_{uuid.uuid4().hex[:8]}"
    runtime = ToolRuntime(registry, FakeAuditor(), NullLogger())
    session = runtime.open_session(
        task_id="task_mcp", trace_id="trace_mcp",
        actor=make_actor(actor_id), control=NoopControl(),
        approval_gate=AutoApproveApprovalGate(),
    )
    snapshot = runtime.build_snapshot(session, round=1)
    result = await runtime.execute(
        snapshot,
        ToolCallRequest(
            tool_name="mcp_mock_erp_query_inventory",
            arguments={"sku": "SKU-1"},
            tool_call_id="tc_mcp", round=1,
        ),
        session,
    )
    assert result.success
    assert result.data["sku"] == "SKU-1"


# ── 迁移 / 审计脱敏 / 配置 ──
async def test_migration_adds_columns_and_backfills_actor(tmp_path):
    path = tmp_path / "legacy.db"
    async with aiosqlite.connect(path) as conn:
        await conn.executescript(
            "CREATE TABLE tasks (task_id TEXT PRIMARY KEY, status TEXT);"
            "CREATE TABLE tool_calls (audit_id TEXT PRIMARY KEY);"
        )
        await conn.execute("INSERT INTO tasks VALUES ('t1', 'failed')")
        await conn.commit()

        await run_migrations(conn)
        await run_migrations(conn)  # 幂等

        async with conn.execute("PRAGMA table_info(tasks)") as cur:
            task_columns = {row[1] for row in await cur.fetchall()}
        async with conn.execute("PRAGMA table_info(tool_calls)") as cur:
            call_columns = {row[1] for row in await cur.fetchall()}
        assert "actor_id" in task_columns
        assert {
            "approval_token_hash", "approval_requested_at",
            "approval_resolved_at", "approved_by", "approval_comment",
        } <= call_columns

        async with conn.execute(
            "SELECT actor_id FROM tasks WHERE task_id = 't1'"
        ) as cur:
            row = await cur.fetchone()
        assert row[0] == settings.default_user_id

        async with conn.execute("SELECT version FROM schema_migrations") as cur:
            versions = {row[0] for row in await cur.fetchall()}
        assert versions == {1}


async def test_sse_persisted_copy_drops_token(tmp_path):
    db = Database(f"sqlite:///{(tmp_path / 'events.db').as_posix()}")
    await db.init()
    try:
        buffer = EventBuffer(db)
        await buffer.open_task("task_evt")
        await buffer.publish(
            "task_evt",
            SSEEventType.TOOL_CONFIRMATION_REQUEST,
            {"approval_token": "secret-token", "tool_name": "pay_order"},
            persist_data={
                "approval_token_hash": "hashed",
                "tool_name": "pay_order",
            },
        )
        rows = await db.get_events("task_evt")
        payload = json.loads(rows[0]["data"])
        assert "approval_token" not in payload
        assert "secret-token" not in rows[0]["data"]
        assert payload["approval_token_hash"] == "hashed"
    finally:
        await db.close()


async def test_task_snapshot_roundtrip_and_owner(tmp_path):
    db = Database(f"sqlite:///{(tmp_path / 'tasks.db').as_posix()}")
    await db.init()
    try:
        service = TaskService(db)
        now = datetime.now(timezone.utc)
        runtime = TaskRuntime(
            task_id=gen_task_id(), trace_id=f"trace_{uuid.uuid4().hex[:8]}",
            input="测试", model_id="gpt-4o", max_steps=5,
            status=TaskStatus.PENDING, actor_id="user_owner",
            created_at=now, updated_at=now,
        )
        service.register(RunningTask(runtime=runtime, actor_id="user_owner"))
        await service.snapshot(runtime)

        loaded = await service.load_runtime(runtime.task_id)
        assert loaded is not None
        assert loaded.actor_id == "user_owner"
        assert await service.owner_of(runtime.task_id) == "user_owner"

        # 重启恢复：WAITING_APPROVAL → FAILED
        runtime.status = TaskStatus.WAITING_APPROVAL
        await service.snapshot(runtime)
        assert await db.fail_tasks_with_status("waiting_approval") == 1
        reloaded = await service.load_runtime(runtime.task_id)
        assert reloaded.status == TaskStatus.FAILED
    finally:
        await db.close()


def test_auth_identities_reject_empty_and_invalid():
    base = {"auth_token": "t", "openai_api_key": "k"}
    parsed = Settings(**base, auth_identities_json='{"a":"b"}')
    assert parsed.auth_identities() == {"a": "b"}
    for bad in ("{}", "not-json", '{"a":""}'):
        with pytest.raises(ConfigurationError):
            Settings(**base, auth_identities_json=bad).auth_identities()
