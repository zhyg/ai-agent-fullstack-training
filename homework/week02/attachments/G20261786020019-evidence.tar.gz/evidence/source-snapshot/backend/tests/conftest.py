"""测试环境：在导入 app 前补齐必填配置，避免读取真实 .env。"""
import os

os.environ.setdefault("AUTH_TOKEN", "test-token")
os.environ.setdefault("OPENAI_API_KEY", "sk-test")
os.environ.setdefault("AUTH_IDENTITIES_JSON", '{"test-token":"user_default"}')
os.environ.setdefault("DATABASE_URL", "sqlite:///./test_agent.db")
