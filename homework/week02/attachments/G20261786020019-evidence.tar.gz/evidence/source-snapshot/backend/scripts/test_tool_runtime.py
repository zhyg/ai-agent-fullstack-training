"""Tool Runtime 自测脚本（不依赖真实 LLM / 网络）。

运行：cd backend && python scripts/test_tool_runtime.py
"""
import asyncio
import sys
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pydantic import BaseModel

from app.api.schemas.sse import SSEEventType
from app.api.schemas.task import TaskStatus
from app.core.loop import _TaskControl
from app.core.runtime import TaskRuntime
from app.core.tools.audit import ToolAuditor
from app.core.tools.catalog import build_default_registry
from app.core.tools.definition import (
    HandlerOutput,
    ToolAuditPolicy,
    ToolDefinition,
    ToolRetryPolicy,
    ToolSpec,
)
from app.core.tools.enums import (
    ErrorPhase,
    RiskLevel,
    ToolEffect,
    ToolErrorCategory,
    ToolExecutionStatus,
    ToolPermission,
    VersionStatus,
)
from app.core.tools.errors import ToolBusinessError, ToolCancelledError
from app.core.tools.registry import ToolRegistry, governance_with_defaults
from app.core.tools.result import ToolResultMessage
from app.core.tools.runtime import ToolRuntime, gen_tool_call_id
from app.core.tools.session import (
    ActorContext,
    AutoApproveApprovalGate,
    AutoDenyApprovalGate,
    NoopControl,
    ToolCallRequest,
)
from app.infra.db import Database
from app.infra.logger import get_logger
from app.services.event_buffer import EventBuffer
from app.services.permission_service import PermissionService
from app.services.task_service import RunningTask, TaskService

ALL_PERMISSIONS = frozenset({ToolPermission.TOOL_USE, ToolPermission.BILL_QUERY})


class EchoArgs(BaseModel):
    text: str


class EchoOut(BaseModel):
    text: str
    secret: str


def make_runtime(db: Database, registry: ToolRegistry) -> ToolRuntime:
    logger = get_logger("tool-runtime-test")
    return ToolRuntime(registry, ToolAuditor(db, logger), logger, snapshot_ttl_seconds=60)


def make_def(
    name: str,
    handler,
    *,
    effect: ToolEffect = ToolEffect.READ_ONLY,
    permissions=ALL_PERMISSIONS,
    retry: ToolRetryPolicy | None = None,
    requires_confirmation: bool = False,
    output_model=None,
    audit: ToolAuditPolicy | None = None,
    timeout: float = 5.0,
) -> ToolDefinition:
    return ToolDefinition(
        spec=ToolSpec.create(
            name=name,
            version="1.0.0",
            description=f"测试工具 {name}",
            input_model=EchoArgs,
            output_model=output_model,
        ),
        governance=governance_with_defaults(
            permissions=permissions,
            risk_level=(
                RiskLevel.HIGH if requires_confirmation else RiskLevel.LOW
            ),
            effect=effect,
            requires_confirmation=requires_confirmation,
            retry_policy=retry,
            audit_policy=audit,
            timeout_seconds=timeout,
        ),
        handler=handler,
        handler_id=f"test.{name}",
    )


def call(name: str, args: dict | None = None, round_no: int = 1) -> ToolCallRequest:
    return ToolCallRequest(
        tool_name=name, arguments=args or {}, tool_call_id=gen_tool_call_id(),
        round=round_no,
    )


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print(f"  PASS  {message}")


async def test_snapshot_and_defaults(db, actor, default_registry, runtime):
    print("[1] 默认注册表与快照元数据")
    names = set(default_registry.names())
    expected = set(default_registry.names())
    check(names == expected, f"注册工具齐全: {len(names)} 个")

    session = runtime.open_session(
        task_id="task_snapshot", trace_id="trace_snapshot", actor=actor,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    snap = runtime.build_snapshot(session, round=1)
    check(len(snap.refs) == len(expected), "快照包含全部有权限工具")
    check(not hasattr(snap.refs[0], "handler"), "快照引用不含 handler")
    tool_defs = snap.to_tool_defs()
    check(all(set(d.model_dump().keys()) <= {
        "name", "description", "parameters"
    } for d in tool_defs), "模型可见字段只有 name/description/parameters")
    check(snap.registry_revision == default_registry.revision, "快照绑定注册表 revision")

    guest = await PermissionService(db).resolve("user_guest")
    guest_snap = runtime.build_snapshot(
        runtime.open_session(
            task_id="task_guest", trace_id="trace_guest", actor=guest,
            control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
        ),
        round=1,
    )
    check("query_electricity_bill" not in guest_snap.names(),
          "快照按权限过滤工具（guest 看不到账单查询）")
    check(guest_snap.names() == ("get_current_time", "get_shopping_request"),
          "guest 只看到 tool.use 工具")


async def test_validation_and_kill(db, actor, runtime):
    print("[2] 校验阶段：参数 / kill switch / 版本禁用 / 快照过期 / 权限")
    registry = ToolRegistry()
    calls = {"n": 0}

    async def handler(args, ctx):
        calls["n"] += 1
        return HandlerOutput.of(EchoOut(text=args.text, secret=""), summary="ok")

    registry.register(make_def("echo", handler))
    rt = make_runtime(db, registry)
    session = rt.open_session(
        task_id="task_validation", trace_id="trace_validation", actor=actor,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    snap = rt.build_snapshot(session, round=1)

    bad = await rt.execute(snap, call("echo", {"wrong": 1}), session)
    check(bad.status == ToolExecutionStatus.INVALID_INPUT, "非法参数返回 INVALID_INPUT")
    check(calls["n"] == 0, "参数非法时 handler 未被调用")

    registry.kill("echo", "test kill")
    killed = await rt.execute(snap, call("echo", {"text": "x"}), session)
    check(killed.status == ToolExecutionStatus.TOOL_DISABLED, "快照后 kill switch 立即拦截")
    check(calls["n"] == 0, "kill 后 handler 未被调用")

    registry.revive("echo")
    registry.disable_version("echo", "1.0.0")
    disabled = await rt.execute(snap, call("echo", {"text": "x"}), session)
    check(disabled.status == ToolExecutionStatus.VERSION_STALE, "版本硬禁用返回 VERSION_STALE")
    check(calls["n"] == 0, "版本禁用后 handler 未被调用")

    registry.enable_version("echo", "1.0.0")
    expired = replace(snap, expires_at=snap.created_at)
    expired_res = await rt.execute(expired, call("echo", {"text": "x"}), session)
    check(expired_res.status == ToolExecutionStatus.SNAPSHOT_EXPIRED, "过期快照被拒绝")

    guest = ActorContext(actor_id="user_guest", tenant_id=None, granted_permissions=frozenset())
    guest_session = rt.open_session(
        task_id="task_validation", trace_id="trace_guest_perm", actor=guest,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    denied = await rt.execute(snap, call("echo", {"text": "x"}), guest_session)
    check(denied.status == ToolExecutionStatus.PERMISSION_DENIED, "权限不足返回 PERMISSION_DENIED")
    check(calls["n"] == 0, "权限不足时 handler 未被调用")

    ok = await rt.execute(snap, call("echo", {"text": "x"}), session)
    check(ok.success and calls["n"] == 1, "恢复后正常执行")


async def test_retry(db, actor, runtime):
    print("[3] 重试策略：只读可重试 / 非幂等默认不重试")
    registry = ToolRegistry()
    counts = {"ro": 0, "write": 0}

    async def ro_handler(args, ctx):
        counts["ro"] += 1
        if counts["ro"] <= 2:
            raise ToolBusinessError(
                category=ToolErrorCategory.TIMEOUT, code="1608",
                message="timeout", model_message="timeout",
                phase=ErrorPhase.PRE_SIDE_EFFECT,
            )
        return HandlerOutput(data={"ok": True}, summary="ok")

    async def write_handler(args, ctx):
        counts["write"] += 1
        raise ToolBusinessError(
            category=ToolErrorCategory.TIMEOUT, code="1608",
            message="timeout", model_message="timeout",
            phase=ErrorPhase.POST_SIDE_EFFECT,
        )

    retry = ToolRetryPolicy(
        max_retries=2, base_delay=0.01, max_delay=0.01, jitter=False,
        retry_on=frozenset({ToolErrorCategory.TIMEOUT}),
    )
    registry.register(make_def("ro_tool", ro_handler, retry=retry))
    registry.register(make_def(
        "write_tool", write_handler, effect=ToolEffect.NON_IDEMPOTENT_WRITE,
        retry=retry,
    ))
    rt = make_runtime(db, registry)
    session = rt.open_session(
        task_id="task_retry", trace_id="trace_retry", actor=actor,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    snap = rt.build_snapshot(session, round=1)

    ro = await rt.execute(snap, call("ro_tool", {"text": "x"}), session)
    check(ro.success and counts["ro"] == 3, "只读工具按分类重试 2 次后成功")
    check(ro.retry_count == 2, "结果记录 retry_count=2")

    write = await rt.execute(snap, call("write_tool", {"text": "x"}), session)
    check(not write.success, "非幂等写操作失败")
    check(counts["write"] == 1, "非幂等写操作默认不重试（handler 只调用 1 次）")
    check(write.retry_count == 0, "非幂等结果 retry_count=0")
    check(write.possible_side_effect is True, "非幂等超时标记 possible_side_effect")

    check(write.error_info is not None and write.error_info.category == ToolErrorCategory.TIMEOUT,
          "错误分类为 timeout")


async def test_output_and_redaction(db, actor, runtime):
    print("[4] 输出阶段：schema 校验与脱敏")
    registry = ToolRegistry()

    async def bad_output(args, ctx):
        return {"text": args.text}

    async def secret_output(args, ctx):
        return {
            "text": args.text,
            "secret": "sk-super-secret",
            "body": "mail body with token=abc123",
        }

    registry.register(make_def("bad_output", bad_output, output_model=EchoOut))
    registry.register(make_def(
        "secret_output", secret_output,
        audit=ToolAuditPolicy(sensitive_fields=frozenset({"body"})),
    ))
    rt = make_runtime(db, registry)
    session = rt.open_session(
        task_id="task_output", trace_id="trace_output", actor=actor,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    snap = rt.build_snapshot(session, round=1)

    bad = await rt.execute(snap, call("bad_output", {"text": "x"}), session)
    check(bad.status == ToolExecutionStatus.OUTPUT_INVALID, "输出 schema 不合法返回 OUTPUT_INVALID")

    secret = await rt.execute(snap, call("secret_output", {"text": "x"}), session)
    check(secret.success, "脱敏工具执行成功")
    check(secret.redaction_applied, "标记 redaction_applied")
    check(secret.data["secret"] != "sk-super-secret", "敏感字段值被脱敏")
    check(secret.data["body"] != "mail body with token=abc123", "body 被脱敏")


async def test_approval_and_shopping(db, actor, runtime):
    print("[5] 通用审批 + 购物审批流（mock）")
    registry = build_default_registry("config/tools.json")
    rt = make_runtime(db, registry)
    session = rt.open_session(
        task_id="task_shop", trace_id="trace_shop", actor=actor,
        control=NoopControl(), approval_gate=AutoDenyApprovalGate(),
    )
    snap = rt.build_snapshot(session, round=1)
    deny_session = session

    submit = await rt.execute(
        snap,
        call("submit_shopping_request", {
            "item": "机械键盘", "quantity": 1, "budget": 399.0,
            "reason": "办公需要",
        }),
        deny_session,
    )
    check(submit.success, "提交购物申请成功")
    request_id = submit.data["request_id"]
    check(submit.data["status"] == "pending_approval", "申请状态为 pending_approval")

    denied = await rt.execute(
        snap,
        call("approve_shopping_request", {
            "request_id": request_id, "decision": "approve",
        }),
        deny_session,
    )
    check(denied.status == ToolExecutionStatus.APPROVAL_DENIED, "审批门拒绝后返回 APPROVAL_DENIED")

    pending = await rt.execute(
        snap, call("get_shopping_request", {"request_id": request_id}), deny_session,
    )
    check(pending.data["status"] == "pending_approval", "审批被拒绝后状态保持 pending")

    approve_session = rt.open_session(
        task_id="task_shop", trace_id="trace_shop", actor=actor,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    approved = await rt.execute(
        snap,
        call("approve_shopping_request", {
            "request_id": request_id, "decision": "approve", "comment": "同意",
        }),
        approve_session,
    )
    check(approved.success and approved.data["status"] == "approved", "审批通过")

    final = await rt.execute(
        snap, call("get_shopping_request", {"request_id": request_id}), approve_session,
    )
    check(final.data["status"] == "approved", "查询结果回灌模型为 approved")


async def test_audit_and_cancel(db, actor, runtime):
    print("[6] 审计字段、tool_call_id 与取消路径")
    registry = ToolRegistry()

    async def handler(args, ctx):
        return HandlerOutput(data={"ok": True}, summary="ok")

    registry.register(make_def("audit_tool", handler))
    rt = make_runtime(db, registry)
    session = rt.open_session(
        task_id="task_audit", trace_id="trace_audit", actor=actor,
        control=NoopControl(), approval_gate=AutoApproveApprovalGate(),
    )
    snap = rt.build_snapshot(session, round=1)
    req = call("audit_tool", {"text": "x"})
    result = await rt.execute(snap, req, session)
    check(result.tool_call_id == req.tool_call_id, "结果保留 tool_call_id")
    check(bool(result.audit_id), "结果带 audit_id")

    rows = await db.query_tool_calls(trace_id="trace_audit")
    check(len(rows) == 1, "审计记录已落库")
    check(rows[0]["tool_call_id"] == req.tool_call_id, "审计记录保留 tool_call_id")
    check(rows[0]["snapshot_id"] == snap.snapshot_id, "审计记录保留 snapshot_id")
    check(rows[0]["status"] == "success", "审计状态 success")

    class CancelControl:
        def is_cancelled(self): return True
        def is_paused(self): return False
        async def checkpoint(self):
            raise ToolCancelledError("cancelled")

    cancel_session = rt.open_session(
        task_id="task_cancel", trace_id="trace_cancel", actor=actor,
        control=CancelControl(), approval_gate=AutoApproveApprovalGate(),
    )
    cancel_snap = rt.build_snapshot(cancel_session, round=1)
    try:
        await rt.execute(cancel_snap, call("audit_tool", {"text": "x"}), cancel_session)
        raise AssertionError("取消未抛出 ToolCancelledError")
    except ToolCancelledError:
        pass
    rows = await db.query_tool_calls(trace_id="trace_cancel")
    check(rows and rows[0]["status"] == "cancelled", "取消路径写入审计记录")


async def test_pause_resume_and_event_seq(db, actor):
    print("[7] 暂停/取消检查与 EventBuffer 单调 seq")
    now = datetime.now(timezone.utc)
    runtime = TaskRuntime(
        task_id="task_pause", trace_id="trace_pause", input="x", model_id="m",
        max_steps=5, status=TaskStatus.RUNNING, created_at=now, updated_at=now,
    )
    running = RunningTask(runtime=runtime, actor_id=actor.actor_id)
    control = _TaskControl(running)

    running.pause()
    task = asyncio.create_task(control.checkpoint())
    await asyncio.sleep(0.05)
    check(not task.done(), "暂停时 checkpoint 挂起，不进入下一轮")
    running.resume()
    await asyncio.wait_for(task, timeout=1)
    check(task.done(), "恢复后 checkpoint 继续")

    running.cancel_event.set()
    try:
        await control.checkpoint()
        raise AssertionError("取消未抛出 ToolCancelledError")
    except ToolCancelledError:
        pass
    check(True, "取消时 checkpoint 抛出 ToolCancelledError")

    buffer = EventBuffer(db)
    seqs = [
        await buffer.publish("task_pause", SSEEventType.THOUGHT, {"i": i})
        for i in range(3)
    ]
    check(seqs == sorted(seqs) and seqs[0] > 0, "EventBuffer seq 单调递增")


async def main() -> None:
    db = Database("sqlite:///:memory:")
    await db.init()
    try:
        actor = await PermissionService(db).resolve("user_default")
        default_registry = build_default_registry("config/tools.json")
        runtime = ToolRuntime(
            default_registry, ToolAuditor(db, get_logger("tool-runtime-test")),
            get_logger("tool-runtime-test"), snapshot_ttl_seconds=60,
        )

        await test_snapshot_and_defaults(db, actor, default_registry, runtime)
        await test_validation_and_kill(db, actor, runtime)
        await test_retry(db, actor, runtime)
        await test_output_and_redaction(db, actor, runtime)
        await test_approval_and_shopping(db, actor, runtime)
        await test_audit_and_cancel(db, actor, runtime)
        await test_pause_resume_and_event_seq(db, actor)
    finally:
        await db.close()
    print("\n全部自测通过")


if __name__ == "__main__":
    asyncio.run(main())
