<script setup lang="ts">
// 主页面：模型切换 + 流式输出区 + 输入区 + 二次确认弹窗
import { onMounted, ref } from 'vue'
import { getToken, setToken } from './api/task'
import ChatInput from './components/ChatInput.vue'
import ModelSelector from './components/ModelSelector.vue'
import StreamOutput from './components/StreamOutput.vue'
import { useTask } from './composables/useTask'

const {
  status,
  taskId,
  traceId,
  modelId,
  models,
  lines,
  errorMsg,
  confirmation,
  canStart,
  canStop,
  canResume,
  canCancel,
  loadModels,
  start,
  stop,
  cancelTask,
  resume,
  switchModel,
  resolveConfirmation,
} = useTask()

const tokenInput = ref(getToken())
const STATUS_LABEL: Record<string, string> = {
  idle: '空闲',
  running: '运行中',
  paused: '已暂停',
  cancelled: '已取消',
  finished: '已完成',
}

onMounted(loadModels)

function saveToken() {
  setToken(tokenInput.value.trim())
  loadModels()
}

async function onStart(input: string) {
  try {
    await start(input)
  } catch (e) {
    errorMsg.value = (e as Error).message
  }
}

async function onStop() {
  try {
    await stop()
  } catch (e) {
    errorMsg.value = (e as Error).message
  }
}

async function onResume() {
  try {
    await resume()
  } catch (e) {
    errorMsg.value = (e as Error).message
  }
}

async function onModelChange(next: string) {
  try {
    await switchModel(next)
  } catch (e) {
    errorMsg.value = (e as Error).message
  }
}

async function onCancelTask() {
  try {
    await cancelTask()
  } catch (e) {
    errorMsg.value = (e as Error).message
  }
}

async function onConfirm(confirmed: boolean) {
  try {
    await resolveConfirmation(confirmed)
  } catch (e) {
    errorMsg.value = (e as Error).message
  }
}
</script>

<template>
  <div class="page">
    <header class="header">
      <h1>个人助理 Agent</h1>
      <ModelSelector :models="models" :model-id="modelId" @change="onModelChange" />
    </header>

    <section class="token-bar">
      <input
        v-model="tokenInput"
        type="password"
        placeholder="API Token（Authorization Bearer）"
      />
      <button @click="saveToken">保存 Token</button>
    </section>

    <StreamOutput :lines="lines" />

    <div v-if="canCancel" class="cancel-bar">
      <button class="danger-outline" @click="onCancelTask">取消任务</button>
    </div>

    <ChatInput
      :can-start="canStart"
      :can-stop="canStop"
      :can-resume="canResume"
      @start="onStart"
      @stop="onStop"
      @resume="onResume"
    />

    <footer class="status-bar">
      <span>状态: {{ STATUS_LABEL[status] }}</span>
      <span v-if="taskId">task_id: {{ taskId }}</span>
      <span v-if="traceId">trace_id: {{ traceId }}</span>
    </footer>
    <p v-if="errorMsg" class="error-msg">{{ errorMsg }}</p>

    <!-- 危险工具二次确认弹窗 -->
    <div v-if="confirmation" class="modal-mask">
      <div class="modal">
        <h3>确认执行工具</h3>
        <p>{{ confirmation.message }}</p>
        <div class="tool-detail">
          <div><b>工具:</b> {{ confirmation.tool_name }}</div>
          <div v-if="confirmation.tool_version">
            <b>版本:</b> {{ confirmation.tool_version }}
          </div>
          <div v-for="(v, k) in confirmation.tool_args" :key="k">
            <b>{{ k }}:</b> {{ v }}
          </div>
          <div v-if="confirmation.expires_at">
            <b>有效期至:</b> {{ confirmation.expires_at }}
          </div>
        </div>
        <div class="modal-actions">
          <button class="primary" @click="onConfirm(true)">确认执行</button>
          <button class="danger" @click="onConfirm(false)">取消执行</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page {
  max-width: 860px;
  margin: 0 auto;
  padding: 24px 16px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.header h1 {
  font-size: 20px;
  margin: 0;
}
.token-bar {
  display: flex;
  gap: 8px;
}
.token-bar input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  font-size: 13px;
}
.token-bar button {
  padding: 8px 16px;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
}
.cancel-bar {
  display: flex;
  justify-content: flex-end;
}
.cancel-bar .danger-outline {
  padding: 6px 14px;
  border: 1px solid #cf222e;
  color: #cf222e;
  background: #fff;
  border-radius: 8px;
  cursor: pointer;
  font-size: 13px;
}
.status-bar {
  display: flex;
  gap: 16px;
  color: #57606a;
  font-size: 13px;
  flex-wrap: wrap;
}
.error-msg {
  color: #cf222e;
  font-size: 13px;
  margin: 0;
}
.modal-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
}
.modal {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  width: 420px;
  max-width: 90vw;
}
.modal h3 {
  margin: 0 0 8px;
}
.tool-detail {
  background: #f6f8fa;
  border-radius: 8px;
  padding: 12px;
  margin: 12px 0;
  font-size: 13px;
  word-break: break-all;
  max-height: 200px;
  overflow-y: auto;
}
.modal-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}
.modal-actions button {
  padding: 8px 20px;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  cursor: pointer;
}
.modal-actions .primary {
  background: #1f6feb;
  border-color: #1f6feb;
  color: #fff;
}
.modal-actions .danger {
  background: #cf222e;
  border-color: #cf222e;
  color: #fff;
}
</style>
