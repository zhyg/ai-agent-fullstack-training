<script setup lang="ts">
// 流式输出区：渲染 SSE 事件（思考、工具调用、结果、错误）
import { nextTick, ref, watch } from 'vue'
import type { OutputLine } from '../types'

const props = defineProps<{
  lines: OutputLine[]
}>()

const box = ref<HTMLElement | null>(null)

watch(
  () => props.lines.length,
  async () => {
    await nextTick()
    box.value?.scrollTo({ top: box.value.scrollHeight })
  },
)

const KIND_LABEL: Record<string, string> = {
  task_started: '任务',
  thought: '思考',
  tool_call: '工具',
  tool_confirmation_request: '确认',
  tool_result: '结果',
  token: '输出',
  final_answer: '答案',
  error: '错误',
  cancelled: '暂停',
  task_finished: '结束',
}
</script>

<template>
  <div ref="box" class="stream-output">
    <div v-if="lines.length === 0" class="empty">暂无输出，输入任务后点击「开始」。</div>
    <div v-for="(line, i) in lines" :key="i" class="line" :class="line.kind">
      <span class="time">[{{ line.time }}]</span>
      <span class="kind">{{ KIND_LABEL[line.kind] ?? line.kind }}</span>
      <span class="text">{{ line.text }}</span>
    </div>
  </div>
</template>

<style scoped>
.stream-output {
  height: 420px;
  overflow-y: auto;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  padding: 12px;
  background: #f6f8fa;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
}
.empty {
  color: #57606a;
}
.line {
  display: flex;
  gap: 8px;
  padding: 2px 0;
  white-space: pre-wrap;
  word-break: break-word;
}
.time {
  color: #57606a;
  flex-shrink: 0;
}
.kind {
  flex-shrink: 0;
  font-weight: 600;
  color: #0969da;
}
.text {
  flex: 1;
}
.line.error .kind,
.line.error .text {
  color: #cf222e;
}
.line.final_answer .kind,
.line.final_answer .text {
  color: #1a7f37;
  font-weight: 600;
}
.line.thought .text {
  color: #57606a;
}
</style>
