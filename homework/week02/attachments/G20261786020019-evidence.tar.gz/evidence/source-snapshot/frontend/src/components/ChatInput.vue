<script setup lang="ts">
// 输入框 + 开始/暂停/恢复按钮
import { ref } from 'vue'

const props = defineProps<{
  canStart: boolean
  canStop: boolean
  canResume: boolean
}>()

const emit = defineEmits<{
  start: [input: string]
  stop: []
  resume: []
}>()

const input = ref('')

function onStart() {
  if (!input.value.trim()) return
  emit('start', input.value.trim())
}
</script>

<template>
  <div class="chat-input">
    <textarea
      v-model="input"
      rows="3"
      placeholder="输入任务描述..."
      :disabled="!props.canStart"
      @keydown.ctrl.enter="onStart"
    />
    <div class="actions">
      <button class="primary" :disabled="!props.canStart || !input.trim()" @click="onStart">
        开始
      </button>
      <button class="danger" :disabled="!props.canStop" @click="emit('stop')">
        暂停
      </button>
      <button :disabled="!props.canResume" @click="emit('resume')">
        恢复
      </button>
    </div>
  </div>
</template>

<style scoped>
.chat-input {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
textarea {
  width: 100%;
  resize: vertical;
  padding: 10px;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  box-sizing: border-box;
}
.actions {
  display: flex;
  gap: 8px;
}
button {
  padding: 8px 20px;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 14px;
}
button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
button.primary {
  background: #1f6feb;
  border-color: #1f6feb;
  color: #fff;
}
button.danger {
  background: #cf222e;
  border-color: #cf222e;
  color: #fff;
}
</style>
