<script setup lang="ts">
// 模型切换下拉框
import type { ModelInfo } from '../types'

defineProps<{
  models: ModelInfo[]
  modelId: string
}>()

const emit = defineEmits<{
  change: [modelId: string]
}>()

function onChange(e: Event) {
  emit('change', (e.target as HTMLSelectElement).value)
}
</script>

<template>
  <select class="model-selector" :value="modelId" @change="onChange">
    <option v-for="m in models" :key="m.id" :value="m.id">
      {{ m.name }} ({{ m.provider }}){{ m.default ? ' · 默认' : '' }}
    </option>
  </select>
</template>

<style scoped>
.model-selector {
  padding: 6px 12px;
  border: 1px solid var(--border, #d0d7de);
  border-radius: 8px;
  background: #fff;
  font-size: 14px;
  cursor: pointer;
}
</style>
