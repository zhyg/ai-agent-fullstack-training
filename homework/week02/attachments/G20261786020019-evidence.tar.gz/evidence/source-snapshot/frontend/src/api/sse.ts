// SSE 订阅：fetch + ReadableStream 解析（EventSource 无法携带 Authorization 头）
import { getToken } from './task'
import type { SSEEvent, SSEEventType } from '../types'

export interface SSESubscription {
  close: () => void
}

/**
 * 订阅任务事件流。
 * @param taskId 任务 ID
 * @param lastSeq 从该序列号之后开始接收
 * @param onEvent 每条事件回调
 * @param onError 连接错误回调（可选）
 */
export function subscribeEvents(
  taskId: string,
  lastSeq: number,
  onEvent: (ev: SSEEvent) => void,
  onError?: (err: Error) => void,
): SSESubscription {
  const controller = new AbortController()

  const run = async () => {
    try {
      const resp = await fetch(`/api/v1/tasks/${taskId}/events?last_seq=${lastSeq}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
        signal: controller.signal,
      })
      if (!resp.ok || !resp.body) {
        throw new Error(`SSE 连接失败 (${resp.status})`)
      }

      const reader = resp.body.pipeThrough(new TextDecoderStream()).getReader()
      let buffer = ''

      // SSE 帧解析状态
      let curId = ''
      let curEvent = ''
      let curData = ''

      const dispatch = () => {
        if (!curData) return
        try {
          onEvent({
            seq: Number(curId) || 0,
            event: (curEvent || 'message') as SSEEventType,
            data: JSON.parse(curData),
          })
        } catch {
          // 忽略无法解析的帧
        }
        curId = ''
        curEvent = ''
        curData = ''
      }

      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += value
        // 按行处理，空行表示一帧结束
        let idx: number
        while ((idx = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, idx).replace(/\r$/, '')
          buffer = buffer.slice(idx + 1)
          if (line === '') {
            dispatch()
          } else if (line.startsWith(':')) {
            // 心跳注释行，忽略
          } else if (line.startsWith('id:')) {
            curId = line.slice(3).trim()
          } else if (line.startsWith('event:')) {
            curEvent = line.slice(6).trim()
          } else if (line.startsWith('data:')) {
            curData += (curData ? '\n' : '') + line.slice(5).trim()
          }
        }
      }
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        onError?.(err as Error)
      }
    }
  }

  void run()
  return { close: () => controller.abort() }
}
