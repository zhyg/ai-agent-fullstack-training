// REST 接口封装：统一携带 Authorization Token
import type {
  ApiResponse,
  ConfirmToolResponse,
  ModelInfo,
  SwitchModelResponse,
  TaskCancelResponse,
  TaskResumeResponse,
  TaskStartResponse,
  TaskStopResponse,
} from '../types'

const BASE = '/api/v1'

export function getToken(): string {
  return localStorage.getItem('agent_token') ?? ''
}

export function setToken(token: string): void {
  localStorage.setItem('agent_token', token)
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const resp = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getToken()}`,
      ...(init?.headers ?? {}),
    },
  })
  const body = (await resp.json()) as ApiResponse<T> & {
    retryable?: boolean
    details?: Record<string, any>
  }
  if (!resp.ok) {
    throw new Error(body.message || `请求失败 (${resp.status})`)
  }
  return body.data as T
}

export const taskApi = {
  start(input: string, modelId: string | null, maxSteps = 20) {
    return request<TaskStartResponse>('/tasks/start', {
      method: 'POST',
      body: JSON.stringify({ input, model_id: modelId, max_steps: maxSteps }),
    })
  },

  stop(taskId: string) {
    return request<TaskStopResponse>(`/tasks/${taskId}/stop`, { method: 'POST' })
  },

  cancel(taskId: string) {
    return request<TaskCancelResponse>(`/tasks/${taskId}/cancel`, { method: 'POST' })
  },

  resume(taskId: string, lastSeq: number, modelId?: string | null) {
    return request<TaskResumeResponse>(`/tasks/${taskId}/resume`, {
      method: 'POST',
      body: JSON.stringify({ last_seq: lastSeq, model_id: modelId ?? null }),
    })
  },

  confirm(taskId: string, approvalToken: string, confirmed: boolean, comment?: string) {
    return request<ConfirmToolResponse>(`/tasks/${taskId}/confirm`, {
      method: 'POST',
      body: JSON.stringify({
        approval_token: approvalToken,
        confirmed,
        comment: comment ?? null,
      }),
    })
  },

  switchModel(taskId: string, modelId: string) {
    return request<SwitchModelResponse>(`/tasks/${taskId}/model`, {
      method: 'PUT',
      body: JSON.stringify({ model_id: modelId }),
    })
  },

  async models(): Promise<ModelInfo[]> {
    const data = await request<{ models: ModelInfo[] }>('/models')
    return data.models
  },
}
