// ── 统一响应 ──
export interface ApiResponse<T> {
  code: number | string
  message: string
  data: T | null
}

// ── 任务 ──
export type TaskStatus =
  | 'pending'
  | 'running'
  | 'paused'
  | 'waiting_approval'
  | 'cancelled'
  | 'completed'
  | 'failed'

export interface TaskStartResponse {
  task_id: string
  trace_id: string
  status: TaskStatus
}

export interface TaskStopResponse {
  task_id: string
  status: TaskStatus
  last_seq: number
}

export interface TaskResumeResponse {
  task_id: string
  status: TaskStatus
  start_seq: number
  /** true=原地续流（同一 LLM 流继续）；false=冷恢复（重做中断步骤） */
  in_place: boolean
}

export interface SwitchModelResponse {
  task_id: string
  model_id: string
  effective_on: string
}

export interface TaskCancelResponse {
  task_id: string
  status: TaskStatus
  last_seq: number
}

export interface ConfirmToolResponse {
  task_id: string
  tool_name: string
  tool_call_id: string
  tool_version: string
  status: string
  decided_by: string | null
  decided_at: string | null
  comment: string | null
  expires_at: string | null
}

export interface ModelInfo {
  id: string
  name: string
  provider: string
  default?: boolean
}

// ── SSE 事件 ──
export type SSEEventType =
  | 'task_started'
  | 'thought'
  | 'tool_call'
  | 'tool_confirmation_request'
  | 'tool_result'
  | 'token'
  | 'final_answer'
  | 'error'
  | 'cancelled'
  | 'task_finished'

export interface SSEEvent {
  seq: number
  event: SSEEventType
  data: Record<string, any>
}

// 流式输出区展示行
export interface OutputLine {
  seq: number
  time: string
  kind: SSEEventType
  text: string
  closed?: boolean
}
