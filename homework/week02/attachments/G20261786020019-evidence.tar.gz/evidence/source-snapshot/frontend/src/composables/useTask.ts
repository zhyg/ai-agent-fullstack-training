// 任务状态管理：状态机 idle/running/paused/cancelled/finished + SSE 事件处理
import { computed, reactive, ref } from 'vue'
import { subscribeEvents, type SSESubscription } from '../api/sse'
import { taskApi } from '../api/task'
import type { ModelInfo, OutputLine, SSEEvent } from '../types'

// 前端状态机：idle ─start→ running ─stop→ paused ─resume→ running
//                        running ─done/error→ finished
export type UIStatus = 'idle' | 'running' | 'paused' | 'cancelled' | 'finished'

export interface PendingConfirmation {
  step: number
  tool_name: string
  tool_args: Record<string, any>
  message: string
  /** 审批票据，确认接口唯一依据；历史事件回放时可能缺失 */
  approval_token: string
  expires_at?: string
  tool_version?: string
  args_preview?: Record<string, any>
}

const status = ref<UIStatus>('idle')
const taskId = ref('')
const traceId = ref('')
const lastSeq = ref(0)
const modelId = ref('')
const models = ref<ModelInfo[]>([])
const lines = ref<OutputLine[]>([])
const errorMsg = ref('')
const confirmation = ref<PendingConfirmation | null>(null)

let sub: SSESubscription | null = null
const state = reactive({})

function now(): string {
  return new Date().toLocaleTimeString('zh-CN', { hour12: false })
}

function push(kind: OutputLine['kind'], text: string, seq: number) {
  lines.value.push({ seq, time: now(), kind, text })
}

function closeSub() {
  sub?.close()
  sub = null
}

/** 将未完成的 token 行标记为中断，避免恢复后残留半截输出 */
function closeTokenLine(reason: string) {
  const last = lines.value[lines.value.length - 1]
  if (last && last.kind === 'token' && !last.closed) {
    last.closed = true
    last.text += `\n（${reason}）`
  }
}

function handleEvent(ev: SSEEvent) {
  if (ev.seq > 0) {
    // 按 task_id + seq 去重：只接收本地尚未应用过的序号
    if (ev.seq <= lastSeq.value) return
    lastSeq.value = ev.seq
  }
  switch (ev.event) {
    case 'task_started':
      push('task_started', `任务开始 (model: ${ev.data.model_id})`, ev.seq)
      break
    case 'thought':
      push('thought', `思考: ${ev.data.content}`, ev.seq)
      break
    case 'tool_call':
      push('tool_call', `调用工具: ${ev.data.tool_name}(${JSON.stringify(ev.data.tool_args)})`, ev.seq)
      break
    case 'tool_confirmation_request':
      confirmation.value = {
        step: ev.data.step,
        tool_name: ev.data.tool_name,
        tool_args: ev.data.args_preview ?? ev.data.tool_args ?? {},
        message: ev.data.message,
        approval_token: ev.data.approval_token ?? '',
        expires_at: ev.data.expires_at,
        tool_version: ev.data.tool_version,
        args_preview: ev.data.args_preview,
      }
      push('tool_confirmation_request', `等待确认: ${ev.data.message}`, ev.seq)
      break
    case 'tool_result': {
      const r = ev.data.result ?? {}
      const text = r.success
        ? `工具结果: ${r.summary || '成功'} (${ev.data.duration_ms}ms)`
        : `工具失败: ${r.error || '未知错误'}`
      push('tool_result', text, ev.seq)
      break
    }
    case 'token': {
      // 连续 token 增量合并为一行，避免逐字产生大量行
      const text = ev.data.content ?? ''
      if (!text) break
      const last = lines.value[lines.value.length - 1]
      if (last && last.kind === 'token' && !last.closed) {
        last.text += text
      } else {
        push('token', text, ev.seq)
      }
      break
    }
    case 'final_answer':
      push('final_answer', `最终答案: ${ev.data.answer}`, ev.seq)
      break
    case 'error':
      closeTokenLine('模型输出被中断，内容不完整')
      push('error', `错误 [${ev.data.error_type}]: ${ev.data.message}`, ev.seq)
      break
    case 'cancelled':
      closeTokenLine('任务已暂停，本次输出未完成')
      push('cancelled', '任务已暂停', ev.seq)
      break
    case 'task_finished':
      push('task_finished', `任务结束 (status: ${ev.data.status}, steps: ${ev.data.total_steps})`, ev.seq)
      status.value = ev.data.status === 'cancelled' ? 'cancelled' : 'finished'
      closeSub()
      break
  }
}

function connect(fromSeq: number) {
  closeSub()
  sub = subscribeEvents(taskId.value, fromSeq, handleEvent, (err) => {
    errorMsg.value = err.message
    closeTokenLine('连接中断，内容不完整')
    push('error', `连接中断: ${err.message}`, lastSeq.value)
  })
}

export function useTask() {
  const canStart = computed(() => status.value === 'idle' || status.value === 'finished')
  const canStop = computed(() => status.value === 'running')
  const canResume = computed(
    () => (status.value === 'paused' || status.value === 'cancelled') && !!taskId.value,
  )
  const canCancel = computed(
    () => (status.value === 'running' || status.value === 'paused') && !!taskId.value,
  )

  async function loadModels() {
    try {
      models.value = await taskApi.models()
      if (!modelId.value) {
        modelId.value = models.value.find((m) => m.default)?.id ?? models.value[0]?.id ?? ''
      }
    } catch (e) {
      errorMsg.value = (e as Error).message
    }
  }

  async function start(input: string) {
    errorMsg.value = ''
    lines.value = []
    lastSeq.value = 0
    confirmation.value = null
    const data = await taskApi.start(input, modelId.value || null)
    taskId.value = data.task_id
    traceId.value = data.trace_id
    status.value = 'running'
    connect(0)
  }

  async function stop() {
    if (!taskId.value) return
    await taskApi.stop(taskId.value)
    // 暂停：保持 SSE 订阅与当前未完成输出行，服务端不再推新帧
    status.value = 'paused'
  }

  async function resume() {
    if (!taskId.value) return
    errorMsg.value = ''
    let data
    try {
      data = await taskApi.resume(taskId.value, lastSeq.value)
    } catch (e) {
      errorMsg.value = (e as Error).message
      push('error', `恢复失败: ${(e as Error).message}`, lastSeq.value)
      return
    }
    status.value = 'running'
    if (data.in_place) {
      // 原地续流：同一条 LLM 流继续，token 接着追加到同一行，不封口、不跳序号
      connect(lastSeq.value)
    } else {
      // 冷恢复：服务端已丢失内存流，只能重做中断步骤，旧输出需封口
      lastSeq.value = data.start_seq - 1
      closeTokenLine('服务端流已中断，恢复后重新执行该步骤')
      connect(lastSeq.value)
    }
  }

  async function switchModel(next: string) {
    modelId.value = next
    if (status.value === 'running' && taskId.value) {
      await taskApi.switchModel(taskId.value, next)
      push('task_started', `模型已切换为 ${next}（下一轮调用生效）`, lastSeq.value)
    }
  }

  async function cancelTask() {
    if (!taskId.value) return
    await taskApi.cancel(taskId.value)
    confirmation.value = null
    status.value = 'cancelled'
  }

  async function resolveConfirmation(confirmed: boolean) {
    const c = confirmation.value
    if (!c || !taskId.value) return
    if (!c.approval_token) {
      errorMsg.value = '审批票据缺失或已过期，请重新发起任务'
      return
    }
    confirmation.value = null
    await taskApi.confirm(taskId.value, c.approval_token, confirmed)
    push(
      'tool_result',
      confirmed ? `已批准执行 ${c.tool_name}` : `已拒绝执行 ${c.tool_name}`,
      lastSeq.value,
    )
  }

  return {
    // 状态
    status,
    taskId,
    traceId,
    lastSeq,
    modelId,
    models,
    lines,
    errorMsg,
    confirmation,
    // 计算
    canStart,
    canStop,
    canResume,
    canCancel,
    // 动作
    loadModels,
    start,
    stop,
    cancelTask,
    resume,
    switchModel,
    resolveConfirmation,
  }
}
