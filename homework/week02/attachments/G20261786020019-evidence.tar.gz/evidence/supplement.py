"""A01–A10 availability and native platform probes; never changes student code.

Missing course interfaces are reported BLOCKED, not fabricated business failures.
Native execute() probes do not substitute for trusted ToolRuntime.invoke tests.
"""
import asyncio
import importlib.util
import inspect
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "backend"))
sys.path.insert(0, str(root))


class QuietLogger:
    def __getattr__(self, name):
        return lambda *a, **kw: None


class AuditCollector:
    def __init__(self):
        self.records = []

    async def record(self, record):
        self.records.append(record)


async def main():
    from app.core.tools.catalog import build_default_registry
    from app.core.tools.runtime import ToolRuntime
    from app.core.tools.redaction import redact_value
    from app.core.tools.enums import ToolPermission
    from app.core.tools.session import (
        ActorContext, AutoDenyApprovalGate, NoopControl, ToolCallRequest,
    )

    spec = importlib.util.find_spec("tool_governance_demo")
    print("course_module_origin", spec.origin if spec else None)
    print("native_runtime_origin", inspect.getfile(ToolRuntime))
    print("native_runtime_has_invoke", hasattr(ToolRuntime, "invoke"))
    registry = build_default_registry(str(root / "backend/config/tools.json"))
    print("native_registered_tools", sorted(registry.names()))
    print("native_transfer_registered", "transfer" in registry.names())
    sources = [p for p in root.rglob("*.py") if ".git" not in p.parts]
    identifiers = ["ACCOUNTS", "TransferArgs", "transfer_precheck", "transfer_handler",
                   "PermissionEngine", "run_offline_demo"]
    for name in identifiers:
        hits = [str(p.relative_to(root)) for p in sources if name in p.read_text()]
        print("identifier", name, hits)
    for n in range(1, 11):
        print(f"A{n:02d} BLOCKED: course transfer module/interfaces absent; not a business assertion failure")

    payload = {"from": "ACC-A-123456", "to": "ACC-A-654321",
               "nested": [{"email": "alice@example.com", "access_token": "demo-token"}],
               "password": "demo-password"}
    print("A09_native_redaction", json.dumps(redact_value(payload), ensure_ascii=False))
    auditor = AuditCollector()
    runtime = ToolRuntime(registry, auditor, QuietLogger())
    session = runtime.open_session(
        task_id="grading_native_probe", trace_id="grading_trace",
        actor=ActorContext(actor_id="grading_actor", tenant_id="tenant_a",
                           granted_permissions=frozenset(ToolPermission), roles=frozenset({"admin"})),
        control=NoopControl(), approval_gate=AutoDenyApprovalGate(),
    )
    snapshot = runtime.build_snapshot(session, round=1)
    result = await runtime.execute(
        snapshot,
        ToolCallRequest(tool_name="transfer", tool_call_id="call_grading_000001",
                        arguments={"from_account": "ACC-A-123456",
                                   "to_account": "ACC-A-654321", "amount": 1200.0}, round=1),
        session,
    )
    print("native_execute_transfer", result.model_dump_json())
    print("native_audit", [r.model_dump(mode="json") for r in auditor.records])
    print("SUMMARY: source inventory confirmed; course A01-A10 business execution unavailable")


asyncio.run(main())
