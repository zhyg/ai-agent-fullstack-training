"""Independent checks of recorded observations, not a replacement for trusted tests."""
import json
from pathlib import Path

rows={r['label']:r for r in map(json.loads,(Path(__file__).parent/'logs/probes.jsonl').read_text().splitlines())}
def code(label): return rows[label]['result']['error_code']
assert code('A02_amount_1200.0')=='APPROVAL_REQUIRED'  # Demonstrates unwanted string coercion.
for suffix in ['50000.01','80000.0']: assert code('A03_unapproved_'+suffix)=='EXCEED_LIMIT'
for suffix in ['50000.0','80000.01','100000.0']: assert code('A03_unapproved_'+suffix)=='APPROVAL_REQUIRED'
assert code('A03_unapproved_100000.01')=='INVALID_ARGUMENT'
for suffix in ['80000.01','100000.0']:
    r=rows['A03_approved_'+suffix]
    assert r['result']['error_code']=='TIMEOUT_UNKNOWN' and r['unchanged'] and 0.9<r['elapsed']<3
for suffix,expected in [('30000.0','INSUFFICIENT_BALANCE'),('60000.0','EXCEED_LIMIT')]:
    for kind in ['unapproved','approved']:
        r=rows['A04_'+kind+'_'+suffix]
        assert r['result']['error_code']==expected and r['unchanged']
        assert len(r['audit'])==1 and 'stage' not in r['audit'][0] and 'content' not in r['audit'][0]
        if kind=='approved': assert not r['approval_used']
assert rows['A05_full_balance']['balances']["('tenant_a', 'ACC-A-888888')"]==0.0
assert rows['A05_full_balance']['balances']["('tenant_a', 'ACC-A-654321')"]==25000.0
for label in ['A06_missing_target','A07_cross_tenant_from_account','A07_cross_tenant_to_account']:
    assert code(label)=='ACCOUNT_NOT_FOUND' and rows[label]['unchanged']
assert rows['A06_missing_target']['result']['content']['message']=='转入账户不存在'
assert rows['A08']['targets'][0]==rows['A08']['targets'][2]==rows['A08']['targets'][3]
assert rows['A09_A10_success_and_txn']['result']['content']['txn_id']=='txn__probe'
assert code('replay')=='APPROVAL_REQUIRED'
for key in ['amount','to_account','from_account']: assert code('binding_'+key)=='APPROVAL_REQUIRED'
assert rows['A09_order']['result']['content']['customer_email']=='***@***'
assert rows['A09_order']['result']['content']['access_token']=='***'
assert rows['A09_recursive']['redacted']['list'][0]==dict(email='***@***',account='ACC-A-****3456',password='***')
assert not rows['A10_fixed_engine']['ast_equal']
assert rows['rounding_precision']['balances']["('tenant_a', 'ACC-A-123456')"]==99999.99
assert rows['rounding_precision']['balances']["('tenant_a', 'ACC-A-654321')"]==5000.02
print('Recorded A01-A10 observations and independent failure evidence verified')
