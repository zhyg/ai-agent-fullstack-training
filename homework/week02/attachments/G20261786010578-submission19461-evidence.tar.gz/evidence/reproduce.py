"""Minimal native-runtime repro: python reproduce.py strict|txn|rounding|permission|target."""
import asyncio
import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'source'))
import tool_governance_demo_transfer as s

async def main():
    mode=sys.argv[1]
    args=dict(from_account='ACC-A-123456',to_account='ACC-A-654321',amount=1200.0)
    c=s.ExecutionContext('trace_probe','u_100','tenant_a',frozenset({'transfer:create'}),frozenset({'transfer'}))
    r,ap,a=s.build_governance()
    if mode=='strict': args['amount']='1200.0'
    elif mode=='rounding': args['amount']=0.015
    elif mode=='permission': c=replace(c,permissions=frozenset({'transfer:execute'}))
    elif mode=='target':
        tool=r._tools['transfer']
        for values in [args,{**args,'to_account':'ACC-A-888888'},{**args,'amount':99.0}]:
            print(values,tool.canonical_target(s.TransferArgs.model_validate(values),c))
        return
    if mode in {'txn','rounding'}:
        ap.approve('ok',user_id=c.user_id,tenant_id=c.tenant_id,tool_name='transfer',args=s.TransferArgs(**args))
        c=replace(c,approval_id='ok')
    out=await r.invoke(s.ToolCall('call_tr_000003','transfer',args),c)
    print(json.dumps(dict(module=s.__file__,result=asdict(out),balances={str(k):v for k,v in s.ACCOUNTS.items()},audit=a.records),ensure_ascii=False,default=str))

asyncio.run(main())
