"""Interface-only bridge. Never changes student permissions, arguments, decisions or audit.

Student audit's decision is retained (including DENY for APPROVAL_REQUIRED).
No missing successful decision code is synthesized as APPROVED.
"""
import sys
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'source'))
import tool_governance_demo_transfer as student

ACCOUNTS = student.ACCOUNTS
ExecutionContext = student.ExecutionContext
PermissionMode = student.PermissionMode
DecisionAction = student.PermissionDecision
ToolCall = student.ToolCall
ToolResult = student.ToolResult

def base_context(**overrides):
    values = dict(trace_id='trace_transfer', user_id='u_100', tenant_id='tenant_a',
                  permissions=frozenset(), allowed_tools=frozenset())
    values.update(overrides)
    return ExecutionContext(**values)

def reset_side_effects():
    student.REFUNDS.clear()

class ApprovalStore:
    def __init__(self, raw):
        self.raw = raw

    def approve(self, approval_id, context, tool_name, arguments):
        self.raw.approve(approval_id, user_id=context.user_id, tenant_id=context.tenant_id,
                         tool_name=tool_name, args=student.TransferArgs.model_validate(arguments))

class AuditView:
    def __init__(self, raw):
        self.raw = raw

    @property
    def records(self):
        return [SimpleNamespace(**r, phase=('execution' if 'content' in r else 'decision'),
                                code=(r.get('error_code') or ('OK' if r.get('ok') else r.get('stage'))))
                for r in self.raw.records]

class RuntimeView:
    def __init__(self, raw, audit):
        self.raw, self.audit = raw, audit

    async def invoke(self, call, context):
        result = await self.raw.invoke(call, context)
        return SimpleNamespace(ok=result.ok, action=self.audit.records[-1]['decision'],
                               code=result.error_code or 'OK', content=result.content)

def build_runtime():
    runtime, approvals, audit = student.build_governance()
    return RuntimeView(runtime, audit), ApprovalStore(approvals), AuditView(audit)
