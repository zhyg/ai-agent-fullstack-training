"""A01-A10 independent native-interface probes; calls always use runtime.invoke."""
import asyncio
import ast
import difflib
import inspect
import json
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))
import tool_governance_demo_transfer as s

INITIAL = dict(s.ACCOUNTS)
BASE = dict(from_account='ACC-A-123456', to_account='ACC-A-654321', amount=1200.0)

def emit(label, **data):
    print(json.dumps(dict(label=label, **data), ensure_ascii=False, default=str))

def ctx(**kw):
    values = dict(trace_id='trace_probe', user_id='u_100', tenant_id='tenant_a',
                  permissions=frozenset({'transfer:create', 'order:read'}),
                  allowed_tools=frozenset({'transfer', 'get_order'}))
    values.update(kw)
    return s.ExecutionContext(**values)

async def case(label, args=None, approved=False, context=None, call_id='call_tr_000003'):
    s.ACCOUNTS.clear(); s.ACCOUNTS.update(INITIAL)
    runtime, approvals, audit = s.build_governance()
    c = context or ctx()
    args = BASE if args is None else args
    if approved:
        approvals.approve('probe', user_id=c.user_id, tenant_id=c.tenant_id,
                          tool_name='transfer', args=s.TransferArgs.model_validate(args))
        c = replace(c, approval_id='probe')
    start = time.monotonic()
    result = await runtime.invoke(s.ToolCall(call_id, 'transfer', args), c)
    emit(label, result=asdict(result), elapsed=time.monotonic()-start,
         balances={str(k):v for k,v in s.ACCOUNTS.items()}, unchanged=s.ACCOUNTS==INITIAL,
         approval_used=approvals._items['probe'].used if approved else None, audit=audit.records)
    return runtime, approvals, audit, c

async def main():
    emit('environment', imported=str(Path(s.__file__).resolve()), python=sys.version,
         strict=s.TransferArgs.model_config)
    emit('A01', accounts={str(k):v for k,v in INITIAL.items()}, types=[type(v).__name__ for v in INITIAL.values()])
    for key in BASE:
        await case('A02_missing_'+key, {k:v for k,v in BASE.items() if k!=key})
    for key,value in [('approved',True),('user_id','admin'),('amount',-1.0),('amount','1200.0'),
                      ('from_account','bad'),('to_account','bad')]:
        await case('A02_'+key+'_'+str(value), {**BASE,key:value})
    for amount in [50000.0,50000.01,80000.0,80000.01,100000.0,100000.01]:
        await case('A03_unapproved_'+str(amount),{**BASE,'amount':amount})
    for amount in [80000.01,100000.0]:
        await case('A03_approved_'+str(amount),{**BASE,'amount':amount},True)
    for amount in [30000.0,60000.0]:
        args={**BASE,'from_account':'ACC-A-888888','amount':amount}
        await case('A04_unapproved_'+str(amount),args)
        await case('A04_approved_'+str(amount),args,True)
    await case('A05_full_balance',{**BASE,'from_account':'ACC-A-888888','amount':20000.0},True)
    await case('A06_missing_target',{**BASE,'to_account':'ACC-A-999999'},True)
    for key in ['from_account','to_account']:
        await case('A07_cross_tenant_'+key,{**BASE,key:'ACC-B-111111'},True)
    runtime, _, _ = s.build_governance()
    tool=runtime._tools['transfer']
    targets=[tool.canonical_target(s.TransferArgs.model_validate(a),ctx()) for a in
             [BASE,{**BASE,'from_account':'ACC-A-888888'},{**BASE,'to_account':'ACC-A-888888'},{**BASE,'amount':99.0}]]
    emit('A08', policy=asdict(tool.policy), model=tool.parameters_model.__name__,
         handler=tool.handler.__name__,precheck=tool.precheck.__name__,targets=targets)
    r,ap,a,c=await case('A09_A10_success_and_txn',approved=True)
    replay=await r.invoke(s.ToolCall('call_tr_replay','transfer',BASE),c)
    emit('replay', result=asdict(replay),audit=a.records)
    order=await r.invoke(s.ToolCall('order','get_order',{'order_id':'ord_1001'}),ctx())
    emit('A09_order', result=asdict(order))
    nested={'list':[{'email':'alice@example.com','account':'ACC-A-123456','password':'secret'}],
            'tuple':({'authorization':'secret','account':'ACC-B-111111'},)}
    emit('A09_recursive',redacted=s.redact(nested),projected=s.project_for_model(nested))
    for key,value in [('amount',9000.0),('to_account','ACC-A-888888'),('from_account','ACC-A-888888')]:
        s.ACCOUNTS.clear();s.ACCOUNTS.update(INITIAL)
        r,ap,a=s.build_governance(); c=ctx()
        ap.approve('bind',user_id=c.user_id,tenant_id=c.tenant_id,tool_name='transfer',args=s.TransferArgs(**BASE))
        out=await r.invoke(s.ToolCall('bind','transfer',{**BASE,key:value}),replace(c,approval_id='bind'))
        emit('binding_'+key,result=asdict(out),used=ap._items['bind'].used)
    await case('rounding_precision',{**BASE,'amount':0.015},True)
    # Fixed-method source comparison (both source text and AST).
    original=ROOT/'source'/'original.py'
    def method(path):
        text=path.read_text(); tree=ast.parse(text)
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PermissionEngine')
        fn=next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='decide')
        return ast.get_source_segment(text,fn),ast.dump(fn,include_attributes=False)
    before,ba=method(original);after,aa=method(Path(s.__file__))
    (ROOT/'logs'/'permission.diff').write_text('\n'.join(difflib.unified_diff(before.splitlines(),after.splitlines(),fromfile='original.decide',tofile='student.decide')))
    emit('A10_fixed_engine',source_equal=before==after,ast_equal=ba==aa)

asyncio.run(main())
