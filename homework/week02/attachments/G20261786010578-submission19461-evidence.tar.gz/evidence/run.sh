#!/usr/bin/env bash
# Run from any directory after creating an environment from requirements.txt.
# Usage: bash run.sh /absolute/path/to/python
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
PY="${1:-python}"
mkdir -p "$ROOT/logs"
run() {
  local name="$1"; shift
  "$PY" "$@" > "$ROOT/logs/$name.log" 2>&1
  echo "$name exit=$?"
}
run trusted-five -m pytest "$ROOT/trusted/test_tool_governance.py" -v
run student-five -m pytest "$ROOT/source/test_tool_governance_transfer.py" -v
"$PY" "$ROOT/probes.py" > "$ROOT/logs/probes.jsonl" 2>&1
echo "probes exit=$?"
run student-demo "$ROOT/source/tool_governance_demo_transfer.py"
run verification "$ROOT/verify_observations.py"
for mode in strict txn rounding permission target; do
  run "repro-$mode" "$ROOT/reproduce.py" "$mode"
done
