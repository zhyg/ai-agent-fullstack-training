import ast
import asyncio
import inspect
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

import tool_governance_demo as d

ROOT = Path('/tmp/kevin-agent-training/homework/week02')
BASE = Path(__file__).parent
INITIAL = dict(d.ACCOUNTS)
F, T, S, B = 'ACC-A-123456', 'ACC-A-654321', 'ACC-A-888888', 'ACC-B-111111'

def ctx(**kw):
    return d.base_context(**dict(permissions=frozenset({'order:read', 'refund:create', 'shell:run', 'transfer:execute'}), allowed_tools=frozenset({'get_order','create_refund','run_shell','transfer'}), **kw))

def args(amount=100.0, source=F, target=T):
    return dict(from_account=source, to_account=target, amount=amount)

async def invoke(a, code, approved=False, unchanged=True, **overrides):
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(INITIAL)
    runtime, approvals, audit = d.build_runtime()
    c = ctx(**overrides)
    if approved:
        approvals.approve('a', c, 'transfer', d.TransferArgs.model_validate(a))
        c = ctx(approval_id='a', **overrides)
    start = time.perf_counter()
    r = await runtime.invoke(d.ToolCall('supp_000123','transfer',a),c)
    elapsed = time.perf_counter()-start
    print(json.dumps(dict(input=a, result=asdict(r), elapsed=elapsed, balances=list(d.ACCOUNTS.items()), audit=[asdict(x) for x in audit.records]), ensure_ascii=False, default=str))
    assert r.code == code, (a, r)
    if unchanged:
        assert d.ACCOUNTS == INITIAL
    if code in {'EXCEED_LIMIT','INSUFFICIENT_BALANCE'}:
        assert audit.records[-1].phase == 'decision'
        if approved:
            assert not approvals._records['a'].used
    if code == 'TIMEOUT_UNKNOWN':
        assert .4 < elapsed < 3
        assert audit.records[-1].phase == 'execution'
    return r

async def main():
    print('IMPORT', d.__file__)
    assert Path(d.__file__).resolve() == ROOT/'tool_governance_demo.py'
    assert INITIAL == {('tenant_a',F):100000.0,('tenant_a',T):5000.0,('tenant_a',S):20000.0,('tenant_b',B):50000.0}
    assert all(type(v) is float for v in INITIAL.values())
    original = ast.parse((BASE/'trusted/tool_governance_demo-无答案.py').read_text())
    submitted = ast.parse((ROOT/'tool_governance_demo.py').read_text())
    def method(tree):
        cls = next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='PermissionEngine')
        return next(x for x in cls.body if isinstance(x,ast.AsyncFunctionDef) and x.name=='decide')
    assert ast.get_source_segment((BASE/'trusted/tool_governance_demo-无答案.py').read_text(),method(original)) == ast.get_source_segment((ROOT/'tool_governance_demo.py').read_text(),method(submitted))
    print('PermissionEngine.decide exact source equality: PASS')
    assert d.TransferArgs.model_config['strict'] and d.TransferArgs.model_config['extra']=='forbid'
    assert inspect.iscoroutinefunction(d.transfer_precheck)
    for key in args():
        a=args(); del a[key]
        await invoke(a,'INVALID_ARGUMENT')
    for key in ['approved','user_id']:
        await invoke({**args(),key:True},'INVALID_ARGUMENT')
    for amount in [-1.0, '100', True]:
        await invoke(args(amount),'INVALID_ARGUMENT')
    for key in ['from_account','to_account']:
        for value in ['ACC-a-123456','ACC-A-12345',123456]:
            await invoke({**args(),key:value},'INVALID_ARGUMENT')
    for amount,code in [(50000.0,'APPROVAL_REQUIRED'),(50000.01,'EXCEED_LIMIT'),(80000.0,'EXCEED_LIMIT'),(80000.01,'APPROVAL_REQUIRED'),(100000.0,'APPROVAL_REQUIRED'),(100000.01,'INVALID_ARGUMENT')]:
        await invoke(args(amount),code)
    for amount in [80000.01,100000.0]:
        await invoke(args(amount),'TIMEOUT_UNKNOWN',approved=True)
    for approved in [False,True]:
        await invoke(args(30000.0,S),'INSUFFICIENT_BALANCE',approved=approved)
        await invoke(args(60000.0,S),'EXCEED_LIMIT',approved=approved)
    await invoke(args(20000.0,S),'OK',approved=True,unchanged=False)
    assert d.ACCOUNTS['tenant_a',S]==0 and d.ACCOUNTS['tenant_a',T]==25000
    missing=await invoke(args(target='ACC-A-999999'),'ACCOUNT_NOT_FOUND',approved=True)
    assert '转入账户不存在' in str(missing.content)
    await invoke(args(source=B),'INSUFFICIENT_BALANCE')
    await invoke(args(target=B),'ACCOUNT_NOT_FOUND',approved=True)
    await invoke(args(target=F),'OK',approved=True)
    tool=next(t for t in d.build_tools() if t.name=='transfer')
    assert tool.parameters_model is d.TransferArgs and tool.handler is d.transfer_handler and tool.precheck is d.transfer_precheck
    p=tool.policy
    print('POLICY',asdict(p))
    assert p.effect==d.Effect.WRITE and (p.requires_approval or p.risk==d.Risk.HIGH)
    assert p.permission=='transfer:execute' and 0<p.timeout_seconds<3 and p.max_retries==0 and p.idempotent is False
    variants=[args(),args(101.0),args(source=S),args(target=S)]
    assert len({tool.canonical_target(d.TransferArgs(**a)) for a in variants})==4
    nested={'items':[F,{'email':'alice@example.com','password':'unsafe','child':(B,)}]}
    assert d._redact(nested)=={'items':['ACC-A-****3456',{'email':'***@***','password':'***','child':['ACC-B-****1111']}]}
    runtime,approvals,audit=d.build_runtime()
    r=await runtime.invoke(d.ToolCall('order','get_order',{'order_id':'ord_1001'}),ctx())
    assert r.ok and r.content['customer_email']=='***@***'
    print('A01-A09 PASS; order regression PASS; recursive redaction PASS')
    # Independent teacher demonstration, not counted as student-provided display.
    d.ACCOUNTS.clear(); d.ACCOUNTS.update(INITIAL)
    runtime,approvals,audit=d.build_runtime()
    for name in ['demo_000001','demo_000002']:
        if name.endswith('2'):
            approvals.approve('a',ctx(),'transfer',args(1200.0))
        r=await runtime.invoke(d.ToolCall(name,'transfer',args(1200.0)),ctx(**({'approval_id':'a'} if name.endswith('2') else {})))
        print('TEACHER_DEMO_RESULT',json.dumps(asdict(r),ensure_ascii=False,default=str))
    print('TEACHER_DEMO_AUDIT',json.dumps([asdict(r) for r in audit.records],ensure_ascii=False,default=str))
    print('ALL SUPPLEMENTAL CHECKS PASS')

asyncio.run(main())
