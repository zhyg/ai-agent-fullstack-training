# 第二周作业：为工具治理 Runtime 接入「转账」工具

在既有治理框架（`tool_governance_demo.py`）上新增 `transfer` 工具，让「参数校验 → 业务预检 → 权限判断 → 人工审批 → 超时处理 → 结果脱敏 → 审计追踪」这条链路完整跑通。

已完成的任务（对应 `plan.md`）：

| 任务 | 实现位置 | 内容 |
|---|---|---|
| 任务 1 | `ACCOUNTS` | 4 个模拟账户：`tenant_a` 三个（100000.0 / 5000.0 / 20000.0）、`tenant_b` 一个（50000.0） |
| 任务 2 | `TransferArgs` | `from_account` / `to_account`（`^ACC-[A-Z]-[0-9]{6}$`）、`amount`（`0 < amount <= 100000`），继承 `StrictArgs`（`extra="forbid"` + 严格类型） |
| 任务 3 | `transfer_precheck` | 只判断不改余额：`50000 < amount <= 80000` → `EXCEED_LIMIT`；余额不足 → `INSUFFICIENT_BALANCE` |
| 任务 4 | `transfer_handler` | `amount > 80000` 先 `sleep(3.0)` 制造超时；转入账户不存在 → `ACCOUNT_NOT_FOUND`；扣减/增加余额；返回 `txn_id`/`from`/`to`/`amount`/`status` |
| 任务 5 | `build_tools()` | 注册 `transfer`：`Effect.WRITE`、`Risk.HIGH`、`transfer:execute`、`requires_approval=True`、`timeout=0.5s`、`max_retries=0`、`idempotent=False` |
| 任务 6 | `_redact()` | 账号脱敏：`ACC-A-123456` → `ACC-A-****3456`（保留租户字符与末 4 位） |

未改动：`PermissionEngine.decide` 的 10 步优先级、所有调用仍走 `ToolRuntime.invoke()`、`TransferArgs` 的 `extra="forbid"`。

---

## 1. 程序架构图

```mermaid
flowchart TB
    subgraph L1[① 不可信输入层]
        U[用户输入] --> LLM[LLM / DeepSeek Provider]
        LLM -->|Provider Tool Call<br/>name + arguments| TC[ToolCall<br/>tool_call_id / name / arguments]
        OFF[离线演示 / pytest<br/>直接构造 ToolCall] --> TC
    end

    subgraph L2[② 治理 Runtime —— 唯一执行入口]
        RT["ToolRuntime.invoke()"]
        RT --> P1["prepare<br/>工具查找 + Pydantic 校验"]
        P1 --> P2["prepare<br/>PermissionEngine.decide() 三态决策"]
        P2 --> EX["execute<br/>仅 allow 才调用 handler<br/>asyncio.timeout + 有限重试"]
        EX --> FI["finalize<br/>字段投影 + 递归脱敏 + 审计"]
        FI --> TR[ToolResult<br/>保留原始 tool_call_id]
    end

    subgraph L3[③ 确定性治理组件]
        PE["PermissionEngine<br/>allow / deny / confirm<br/>固定优先级，不执行 handler"]
        AS["ApprovalStore<br/>一次性审批<br/>SHA-256 参数摘要绑定"]
        AU["AuditSink<br/>trace_id / 阶段 / 错误码 / 延迟"]
    end

    subgraph L4[④ 工具注册表 ToolDefinition]
        T1["get_order<br/>READ / order:read"]
        T2["create_refund<br/>WRITE HIGH / refund:create"]
        T3["run_shell<br/>SHELL / shell:run"]
        T4["transfer<br/>WRITE HIGH / transfer:execute<br/>需审批 · 非幂等 · 0.5s 超时"]
    end

    subgraph L5[⑤ 副作用数据（模拟）]
        D1[ORDERS]
        D2["ACCOUNTS<br/>余额只有 handler 能改"]
        D3[SIDE_EFFECTS]
    end

    subgraph L6[⑥ 服务端可信上下文]
        CTX["ExecutionContext<br/>trace_id / user_id / tenant_id<br/>mode / permissions<br/>allowed_tools / approval_id"]
    end

    TC --> RT
    P2 <--> PE
    PE <--> AS
    FI --> AU
    P1 -.->|parameters_model| L4
    EX -->|handler + precheck| L4
    L4 --> L5
    CTX -.->|只读注入| RT
    CTX -.-> PE
    TR -->|role=tool 回填| LLM
    RT -.->|model_tools 只投影<br/>name + description + JSON Schema| LLM
```

架构要点：

- **单一入口**：模型 Agent Loop、CLI 离线演示、pytest 全部调用同一个 `ToolRuntime.invoke()`，不存在旁路 Fake Runtime。
- **模型可见面最小**：`to_model_tool()` 只投影 `name` / `description` / Pydantic JSON Schema；handler、权限集合、审批记录、内部策略都不出网。
- **身份只来自服务端**：`user_id`、`tenant_id`、`permissions`、`allowed_tools`、`approval_id` 由 `ExecutionContext` 提供，模型无法通过参数注入（`extra="forbid"` 直接拒绝）。
- **副作用收敛**：只有 handler 能改 `ACCOUNTS`；deny / confirm / 参数非法 / 审批不匹配 / 超时都保证 handler 零调用。

---

## 2. 治理流程图（PermissionEngine 三态决策）

```mermaid
flowchart TD
    S([ToolCall 进入 Runtime]) --> V{"Pydantic 校验<br/>StrictArgs + extra=forbid"}
    V -->|失败| R1["DENY · INVALID_ARGUMENT<br/>handler 零调用"]
    V -->|通过| D1{"1. deny 规则命中?"}
    D1 -->|是| RD["DENY · DENY_RULE<br/>不可被 allow / bypass 覆盖"]
    D1 -->|否| D2{"2. plan 模式且非只读?"}
    D2 -->|是| RP["DENY · PLAN_MODE_DENIED"]
    D2 -->|否| D3{"3. 在 allowed_tools 白名单?"}
    D3 -->|否| RW["DENY · TOOL_NOT_ALLOWED"]
    D3 -->|是| D4{"4. RBAC 有 tool.permission?"}
    D4 -->|否| RR["DENY · PERMISSION_DENIED"]
    D4 -->|是| D5{"5. 业务 precheck 通过?<br/>归属 / 状态 / 额度 / 余额"}
    D5 -->|PolicyDenied| RB["DENY · 业务错误码<br/>EXCEED_LIMIT / INSUFFICIENT_BALANCE"]
    D5 -->|通过| D6{"6. 高风险或 requires_approval?"}
    D6 -->|否| D7{"7. bypassPermissions?"}
    D6 -->|是| A1{"审批与 用户/租户/工具/参数摘要<br/>完全匹配且未使用未过期?"}
    A1 -->|是| AL["ALLOW · APPROVED<br/>审批置 used，不可重放"]
    A1 -->|否| A2{"mode = dontAsk?"}
    A2 -->|是| RA2["DENY · APPROVAL_REQUIRED"]
    A2 -->|否| CF["CONFIRM · APPROVAL_REQUIRED<br/>等待人工确认"]
    D7 -->|是| AB["ALLOW · BYPASS_ALLOWED<br/>仅跳过普通确认"]
    D7 -->|否| D8{"8. 命中 allow 规则?"}
    D8 -->|是| AR["ALLOW · ALLOW_RULE"]
    D8 -->|否| D9{"9. Shell 且命中危险模式?"}
    D9 -->|是| RC["CONFIRM / DENY · DANGEROUS_OPERATION"]
    D9 -->|否| D10["10. ALLOW · DEFAULT_ALLOWED"]

    AL --> EX
    AB --> EX
    AR --> EX
    D10 --> EX
    EX["execute: asyncio.timeout + 重试策略<br/>只读 / 幂等才允许有限重试"]
    EX -->|成功| FIN["finalize: 投影 → 脱敏 → 审计"]
    EX -->|超时且非幂等写| FT["TIMEOUT_UNKNOWN<br/>禁止自动重放 · 余额不变"]
    EX -->|超时且只读/幂等| FT2["TIMEOUT"]
    EX -->|PolicyDenied / 异常| FE["failed · 业务码 / TOOL_ERROR<br/>不回传 traceback"]
    FIN --> RES([ToolResult 回填 role=tool])
    FT --> RES
    FT2 --> RES
    FE --> RES
    RD --> RES
    RP --> RES
    RW --> RES
    RR --> RES
    RB --> RES
    RA2 --> RES
    CF --> RES
    RC --> RES
    R1 --> RES
```

治理要点：

- 顺序固定：deny → plan → 白名单 → RBAC → 业务预检 → 审批 → bypass → allow → 危险 Shell → 默认允许，**不可交换**。
- 三态：`allow` 才可能产生副作用；`deny`/`confirm` 一律零 handler 调用。
- 参数、权限、审批、deny 失败**不重试**；`transfer` 是非幂等写，`max_retries=0`，超时统一报 `TIMEOUT_UNKNOWN`。
- 审批是「一次性 + 参数绑定」：摘要 = `sha256(tool_name + 递归排序稳定 JSON)`，绑定 `user_id`/`tenant_id`/`tool_name`/参数/过期时间/`used`，改金额即失效，成功执行一次后不可重放。

---

## 3. 「转账」工具调用流程图

```mermaid
sequenceDiagram
    autonumber
    participant M as 模型 / 测试
    participant R as ToolRuntime.invoke
    participant P as Pydantic TransferArgs
    participant E as PermissionEngine
    participant S as ApprovalStore
    participant H as transfer_handler
    participant A as ACCOUNTS
    participant Z as _redact + AuditSink

    Note over M,Z: ① 参数校验（注入与非法值在 Runtime 门口就被挡住）
    M->>R: ToolCall(transfer, {from,to,amount, approved/user_id})
    R->>P: model_validate(arguments)
    P-->>R: ValidationError（extra="forbid"）
    R-->>M: DENY · INVALID_ARGUMENT（余额 100000.0 不变）

    Note over M,Z: ② 业务预检（handler 之前，零副作用）
    M->>R: ToolCall(transfer, amount=60000)
    R->>E: decide()
    E->>E: precheck: 50000 < 60000 <= 80000
    E-->>R: DENY · EXCEED_LIMIT
    R-->>M: 余额不变
    M->>R: ToolCall(transfer, from=ACC-A-888888, amount=30000)
    E->>E: precheck: 余额 20000 < 30000
    E-->>R: DENY · INSUFFICIENT_BALANCE

    Note over M,Z: ③ 权限边界（带审批也越不过）
    M->>R: 缺 transfer:execute 权限
    E-->>R: DENY · PERMISSION_DENIED
    M->>R: 不在 allowed_tools
    E-->>R: DENY · TOOL_NOT_ALLOWED
    M->>R: mode=plan
    E-->>R: DENY · PLAN_MODE_DENIED

    Note over M,Z: ④ 人工审批（三态中的 confirm）
    M->>R: ToolCall(transfer, amount=1200) 无 approval_id
    E->>S: consume(None)
    S-->>E: 不匹配
    E-->>R: CONFIRM · APPROVAL_REQUIRED
    R-->>M: 等待确认（余额仍未变动）
    M->>S: 人工批准 approval_transfer（绑定 user/tenant/tool/参数摘要）
    M->>R: 篡改金额 1200 -> 9000 复用同一审批
    E->>S: consume(approval_transfer)
    S-->>E: 摘要不匹配 → 审批不生效
    E-->>R: CONFIRM · APPROVAL_REQUIRED

    Note over M,Z: ⑤ 执行 + 超时 + 脱敏 + 审计
    M->>R: ToolCall(transfer, amount=1200, approval_id)
    E->>S: consume(approval_transfer)
    S-->>E: 匹配 → 置 used
    E-->>R: ALLOW · APPROVED
    R->>H: execute（timeout=0.5s，非幂等写不重试）
    H->>A: from 100000.0-1200 → to 5000.0+1200
    A-->>H: 余额已变更
    H-->>R: {txn_id, from, to, amount, status}
    R->>Z: 脱敏邮箱/密钥 + ACC-A-123456 → ACC-A-****3456
    Z->>Z: 追加审计 (decision APPROVED → execution OK)
    R-->>M: OK · from=ACC-A-****3456, to=ACC-A-****4321
    M->>R: 同一审批重放
    E->>S: consume(approval_transfer)
    S-->>E: used=True → 失效
    E-->>R: CONFIRM · APPROVAL_REQUIRED（不可重放）

    Note over M,Z: ⑥ 超时分支：amount=90000（>80000 不落拦截区间）
    M->>R: 审批通过 → ALLOW
    R->>H: execute
    H->>H: await asyncio.sleep(3.0) ← 早于任何扣款
    R-->>H: asyncio.timeout(0.5s) 掐断
    R-->>M: TIMEOUT_UNKNOWN（<3s 返回，余额 100000.0 / 5000.0 原样）
```

转账链路关键取值：

| 场景 | action | code | 副作用 |
|---|---|---|---|
| 注入 `user_id` / `approved`、账号格式错、`amount=0`、`amount=100000.1` | deny | `INVALID_ARGUMENT` | 零 |
| `50000 < amount <= 80000` | deny | `EXCEED_LIMIT` | 零 |
| 转出账户余额不足 | deny | `INSUFFICIENT_BALANCE` | 零 |
| 缺 `transfer:execute` / 不在白名单 / plan 模式 | deny | `PERMISSION_DENIED` / `TOOL_NOT_ALLOWED` / `PLAN_MODE_DENIED` | 零 |
| 无审批 / 参数被篡改 / 审批已用 | confirm | `APPROVAL_REQUIRED` | 零 |
| 审批匹配执行成功 | allow | `OK`（`txn_id=000003`，账号脱敏） | `from 100000.0→98800.0`，`to 5000.0→6200.0` |
| `amount=90000` 慢调用 | deny | `TIMEOUT_UNKNOWN`（<3s） | 零（sleep 早于扣款） |

---

## 4. 运行与验收

```bash
cd homework/week02
python3 -m py_compile tool_governance_demo.py test_tool_governance.py
python3 tool_governance_demo.py
python3 -m pytest test_tool_governance.py -v -k "transfer"
```

说明：本仓库中测试文件位于 `week02/test_tool_governance.py`（与 `tool_governance_demo.py` 同级，便于 `import tool_governance_demo`）；若按 `plan.md` 的目录约定放在 `tests/` 下，命令等价为 `python3 -m pytest tests/test_tool_governance.py -v -k "transfer"`。

实测结果：5 个转账用例全部 PASSED（0.71s）。

> **本机环境坑（ROS Humble）**：若直接 `python3 -m pytest ...` 报
> `ModuleNotFoundError: No module named 'lark'`（栈里出现 `/opt/ros/humble/lib/python3.10/site-packages/launch/...`），
> 本机已在 `~/.bashrc` 中把 `source /opt/ros/humble/setup.bash` 改为按需加载（备份见 `~/.bashrc.bak.*`），
> 新终端可直接 `python3 -m pytest ...`；需要 ROS 时在终端先执行 `rosenv`，`ros2` 即恢复可用。
> 若在其他机器/未改 `.bashrc` 的环境下仍报该错，用下面两条之一绕过（均已实测通过）：
>
> ```bash
> # 方案 1：临时清掉 PYTHONPATH（ROS 路径就是它带进来的）
> env -u PYTHONPATH python3 -m pytest test_tool_governance.py -v -k "transfer"
>
> # 方案 2：禁止 pytest 自动加载第三方插件（本测试自带 asyncio.run 包装，不依赖任何插件）
> PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest test_tool_governance.py -v -k "transfer"
> ```
>
> 不建议用 `-p no:launch_testing`：ROS 还有一个 `launch_testing_ros_pytest_entrypoint`，
> 只禁用前者会退化成 `unknown hook 'pytest_launch_collect_makemodule'` 的 INTERNALERROR。

| 测试 | 覆盖环节 |
|---|---|
| `test_transfer_rejects_injected_arguments_and_invalid_amount` | 参数校验（`extra="forbid"` 挡注入、正则挡非法账号、`gt/le` 挡额度） |
| `test_transfer_precheck_blocks_over_limit_and_insufficient_balance` | 业务预检（`EXCEED_LIMIT`、`INSUFFICIENT_BALANCE`，余额不变） |
| `test_transfer_is_denied_without_permission_or_whitelist_and_in_plan_mode` | 权限判断（RBAC、执行白名单、plan 只读契约，带审批也越不过） |
| `test_transfer_requires_approval_bound_to_arguments_and_masks_accounts` | 人工审批（confirm → 参数绑定 → 一次性） + 脱敏（`ACC-A-****3456` / `ACC-A-****4321`） + 审计四段 `APPROVAL_REQUIRED → APPROVAL_REQUIRED → APPROVED → OK` |
| `test_transfer_timeout_is_reported_as_unknown_and_leaves_balances_untouched` | 超时处理（`TIMEOUT_UNKNOWN`，<3s 返回，余额原样，审计落 `execution` 阶段） |

审计记录只保存 `trace_id`、`tool_call_id`、工具名、用户/租户、阶段、决策、稳定错误码、**参数键名**与延迟，不含 Token、完整 Prompt、未脱敏客户资料与 Python traceback。
