# Report
auth.py:31 verify compares hashes; login calls verify.