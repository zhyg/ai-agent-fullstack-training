from calc import add
def test_add(): assert add(2,5)==7
