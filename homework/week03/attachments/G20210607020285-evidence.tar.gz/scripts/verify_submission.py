"""Check upstream identity and cross-reference the submitted real-run artifacts."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import importlib.metadata

root = Path(__file__).parent
student = root / "vita-smolagents"
upstream = root / "upstream-smolagents"
reference = "96f33faaf028479119ec8d34507b47694cf14e34"
print("Student HEAD", subprocess.check_output(["git","-C",str(student),"rev-parse","HEAD"],text=True).strip())
print("Official upstream reference", reference)
print("Python",sys.version)
for name in ("smolagents","pytest"):
    module=__import__(name)
    print(name,importlib.metadata.version(name),module.__file__)
import harness
print("harness",harness.__file__)
paths=subprocess.check_output(["git","-C",str(upstream),"ls-tree","-r","--name-only",reference,"src/smolagents"],text=True).splitlines()
same=[];different=[]
for path in paths:
    expected=subprocess.check_output(["git","-C",str(upstream),"show",reference+":"+path])
    actual=(student/path).read_bytes()
    equal=actual==expected
    (same if equal else different).append(path)
    print("UPSTREAM_FILE",path,"SAME" if equal else "DIFFERENT",hashlib.sha256(actual).hexdigest())
print("Upstream comparison",len(same),"same",len(different),"different")
for directory in ("demo_workspace","harness-analysis-r72y2qpx","harness-analysis-v124qr4y"):
    base=student/directory
    for state_path in (base/"storage/runs").glob("*.json"):
        state=json.loads(state_path.read_text())
        events=[json.loads(x) for x in (base/"storage/audit"/(state_path.stem+".jsonl")).read_text().splitlines()]
        print("SUBMITTED_RUN",directory,"run_id",state["run_id"],"state",state["status"],"step",state["current_step"],"events",len(events))
        print("EVENT_TYPES",[e["event_type"] for e in events])
        print("MODEL_METADATA_FIELDS",[k for k in state if "model" in k.lower()])
        if directory=="harness-analysis-r72y2qpx":
            approval=state["pending_approvals"][0]
            report=(base/"workspace/analysis_report.md").read_text()
            print("REPORT_EQUALS_APPROVED_CONTENT",report==approval["arguments"]["content"])
            print("REPORT_NONEMPTY",bool(report.strip()),"sha256",hashlib.sha256(report.encode()).hexdigest())
            print("WRITE_CALL_ID",approval["tool_call_id"],"APPROVER",approval["decided_by"])
            print("WRITE_EXECUTION_COUNT",sum(e["event_type"]=="TOOL_EXECUTED" and e["tool_call_id"]==approval["tool_call_id"] for e in events))
            print("SOURCE_UNCHANGED_BETWEEN_SNAPSHOTS",all((base/"workspace"/p).read_bytes()==(student/"demo_workspace/workspace"/p).read_bytes() for p in ("auth.py","math_utils.py")))
        print("CHECKPOINTS",len(list((base/"storage/checkpoints").glob("*.json"))))
print("Student tracked changes",repr(subprocess.check_output(["git","-C",str(student),"status","--short"],text=True)))
