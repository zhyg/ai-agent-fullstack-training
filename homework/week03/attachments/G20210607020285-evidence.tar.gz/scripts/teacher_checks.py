"""Independent offline probes; student sources and assertions stay unchanged."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import pytest
from smolagents.models import Model, ChatMessage, ChatMessageToolCall, ChatMessageToolCallFunction, MessageRole, TokenUsage
from harness import GuardedHarness, HarnessConfig, SandboxConfig, ToolPolicy, ToolCapability, CommandPolicy, RunStatus
from harness.audit import AuditLogger
from harness.sandbox import Sandbox
from harness.models import AuditEventType, EvidenceKind, PlanStep, StepStatus
from examples.user_approval import create_harness, TASK
from examples.real_code_analysis import file_read, create_config

class ScriptModel(Model):
    def __init__(self, calls):
        super().__init__()
        self.calls = iter(calls)
        self.messages_seen = []

    def generate(self, messages, **kwargs):
        self.messages_seen.append(messages)
        item = next(self.calls)
        name, arguments, call_id = item() if callable(item) else item
        return ChatMessage(role=MessageRole.ASSISTANT, content=None,
            tool_calls=[ChatMessageToolCall(id=call_id, type="function",
                function=ChatMessageToolCallFunction(name=name, arguments=arguments))],
            token_usage=TokenUsage(input_tokens=7, output_tokens=3))

def call(name, args, call_id):
    return name, args, call_id

def final(text="Done", call_id="final"):
    return call("final_answer", {"answer": text}, call_id)

def report_model(extra=()):
    return ScriptModel([call("read_sample", {"filename":"auth.py"}, "read"),
        call("write_report", {"content":"# Report\nauth.py:31 verify compares hashes; login calls verify."}, "write"), *extra])

def sandbox(base, argv=None, **overrides):
    workspace = base / "workspace"
    workspace.mkdir(exist_ok=True)
    values = dict(workspace_root=str(workspace), allowed_dirs=["."], sensitive_dirs=[".env"],
        allowed_env_vars=["PATH"], command_timeout=1, max_output_bytes=20)
    if argv:
        values["allowed_commands"] = {"probe":CommandPolicy(executable=argv[0], argv_template=argv[1:], path_arguments=[])}
    values.update(overrides)
    return Sandbox(SandboxConfig(**values), AuditLogger(base / "storage"))

def test_gate_final_and_unknown(tmp_path):
    h=create_harness(tmp_path, ScriptModel([call("nonexistent",{},"unknown"), final()]))
    r=h.run(TASK)
    gates=[e.tool_call_id for e in h.get_audit() if e.event_type in (AuditEventType.GATE_ALLOW,AuditEventType.GATE_DENY)]
    print("state",r.state,"gate_ids",gates)
    assert {"unknown","final"}.issubset(gates)

@pytest.mark.parametrize("args", [{}, {"filename":123}])
def test_g1_observation(tmp_path,args):
    model=ScriptModel([call("read_sample",args,"call_g1"),final()])
    h=create_harness(tmp_path,model);h.run(TASK)
    cp=h.get_checkpoint()
    observation=cp.memory_steps[0]["observations"]
    print("observation",observation,"audit",[(e.tool_call_id,e.rule) for e in h.get_audit()])
    assert "call_g1" in observation and "parameter_validation" in observation

def test_g2_three_calls(tmp_path):
    h=create_harness(tmp_path,ScriptModel([call("read_sample",{"filename":"auth.py"},f"r{i}") for i in range(3)]+[final()]))
    h.run(TASK)
    events=h.get_audit()
    assert sum(e.event_type==AuditEventType.TOOL_EXECUTED for e in events)==2
    assert any(e.tool_call_id=="r2" and e.rule=="repeat_detection" for e in events)

def test_g3_g4_approval_and_replay(tmp_path):
    h=create_harness(tmp_path,report_model([call("write_report",{"content":"# Report\nauth.py:31 verify compares hashes; login calls verify."},"write"),final()]))
    r=h.run(TASK); rid=r.run_state.run_id
    assert r.state==RunStatus.WAITING_APPROVAL
    assert not (tmp_path/"workspace/analysis_report.md").exists()
    cp=h.get_checkpoint()
    assert cp.run_state.pending_approvals and cp.run_state.pending_tool_batches
    h.approve(rid,r.run_state.pending_approvals[0].approval_id,approver="teacher")
    r=h.run(TASK,reset=False,resume_run_id=rid)
    assert r.state==RunStatus.COMPLETED
    assert sum(e.tool_call_id=="write" and e.event_type==AuditEventType.TOOL_EXECUTED for e in h.get_audit())==1
    assert any(e.rule=="post_approval_replay" for e in h.get_audit())
    print("checkpoint step",cp.step_number,"state step_records",len(r.run_state.step_records))

def test_g3_model_cannot_approve(tmp_path):
    h=create_harness(tmp_path,ScriptModel([call("write_report",{"content":"bad","approved":True},"attack"),final()]))
    h.run(TASK)
    assert not (tmp_path/"workspace/analysis_report.md").exists()
    assert any(e.tool_call_id=="attack" and e.rule=="parameter_validation" for e in h.get_audit())

def test_s1_s2_symlink_and_paths(tmp_path):
    sb=sandbox(tmp_path)
    outside=tmp_path/"outside";outside.write_text("synthetic")
    (tmp_path/"workspace/link").symlink_to(outside)
    for target in [str(tmp_path/"workspace/artifacts/../../outside"),str(outside),str(tmp_path/"workspace/link")]:
        with pytest.raises(Exception): sb.validate_path(target)
    print("sandbox denial events",len(sb._audit.query()))
    assert len(sb._audit.query())==3

def test_s2_real_example_sensitive_file(tmp_path,monkeypatch):
    ws=tmp_path/"workspace";ws.mkdir()
    (ws/".env").write_text("SYNTHETIC_ONLY=visible")
    monkeypatch.setenv("HARNESS_WORKSPACE",str(ws))
    model=ScriptModel([call("file_read",{"path":".env"},"secret"),final()])
    config=create_config(ws,tmp_path/"storage")
    config.tool_policies.pop("list_files")
    h=GuardedHarness(model,[file_read],config);h.run("Do not read secrets")
    obs=h.get_checkpoint().memory_steps[0]["observations"]
    print("synthetic env in observation",obs)
    assert "SYNTHETIC_ONLY=visible" not in obs

def test_s3_command_no_process(tmp_path):
    marker=tmp_path/"pwned";sb=sandbox(tmp_path,[sys.executable,"-c","print('ok')"])
    for command in ["rm -rf .",f"pytest; touch {marker}","python -c pass"]:
        with pytest.raises(Exception):sb.execute_command(command,{})
    assert not marker.exists()
    assert sb.execute_command("probe",{}).exit_code==0

def test_e1_environment_and_output(tmp_path,monkeypatch):
    monkeypatch.setenv("FAKE_SECRET_TOKEN","SYNTHETIC")
    sb=sandbox(tmp_path,[sys.executable,"-c","import os;print(os.getenv('FAKE_SECRET_TOKEN','ABSENT'));print('x'*200)"])
    r=sb.execute_command("probe",{})
    print("stdout",repr(r.stdout),"truncated",r.truncated)
    assert "SYNTHETIC" not in r.stdout and "ABSENT" in r.stdout
    assert r.truncated or "truncat" in r.stdout.lower() or "omitted" in r.stdout.lower()

def test_s4_term_resistant_grandchild(tmp_path):
    marker=tmp_path/"survived"
    child=f"import signal,time,pathlib;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(2);pathlib.Path({str(marker)!r}).touch()"
    parent=f"import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',{child!r}]);time.sleep(10)"
    sb=sandbox(tmp_path,[sys.executable,"-c",parent]);start=time.monotonic()
    r=sb.execute_command("probe",{},timeout=0.4)
    print("timeout",r.timed_out,"elapsed",time.monotonic()-start,"marker",marker.exists())
    assert r.timed_out and not marker.exists()

def test_state_business_steps(tmp_path):
    h=create_harness(tmp_path,ScriptModel([call("read_sample",{"filename":"auth.py"},"read"),final()]))
    r=h.run(TASK);cp=h.get_checkpoint()
    print("current step",r.run_state.current_step,"business records",r.run_state.step_records,
        "checkpoint memory steps",len(cp.memory_steps))
    assert len(r.run_state.step_records)>=2

def test_h1_no_artifact(tmp_path):
    h=create_harness(tmp_path,ScriptModel([final("Report written and tests passed")]))
    r=h.run(TASK)
    print("state",r.state,"report exists",(tmp_path/"workspace/analysis_report.md").exists())
    assert r.state!=RunStatus.COMPLETED

def test_h3_total_token_budget(tmp_path):
    h=create_harness(tmp_path,ScriptModel([final()]))
    h._runner._config.max_tokens=5
    r=h.run(TASK)
    print("input_tokens=7 output_tokens=3 limit=5",r.state,"recorded",r.run_state.budget.used_tokens)
    assert r.state!=RunStatus.COMPLETED

def test_repair_normal_and_h2(tmp_path,monkeypatch):
    ws=tmp_path/"workspace";ws.mkdir()
    (ws/"calc.py").write_text("def add(a,b): return a-b\n")
    (ws/"test_calc.py").write_text("from calc import add\ndef test_add(): assert add(2,5)==7\n")
    monkeypatch.setenv("HARNESS_WORKSPACE",str(ws))
    config=HarnessConfig(workspace_root=str(ws),storage_path=str(tmp_path/"storage"),
        sandbox_config=SandboxConfig(workspace_root=str(ws),allowed_dirs=["."],sensitive_dirs=[".env"],
            allowed_env_vars=["PATH"],fingerprint_patterns=["*.py"],
            allowed_commands={"run_test":CommandPolicy(sys.executable,["-m","pytest","{test_path}","-q"],["test_path"])}),
        approval_checkpointer_path=str(tmp_path/"approval.sqlite"),max_steps=20,
        tool_policies={"file_read":ToolPolicy("file_read",{ToolCapability.READ},True,False),
            "create_test":ToolPolicy("create_test",{ToolCapability.WRITE},True,True),
            "run_test":ToolPolicy("run_test",{ToolCapability.EXECUTE},True,True)})
    h=None
    def revise():
        return call("revise_plan",{"plan_id":h.get_state().active_plan_id,
            "new_steps":json.dumps([{"id":"verify","objective":"Fix and test add","required_evidence_kinds":["test"]}])},"revise")
    fixed="def add(a,b): return a+b\n"
    model=ScriptModel([call("file_read",{"path":"calc.py"},"read"),
        call("create_plan",{"goal":"Fix calc","constraints":"[]"},"plan"),revise,
        lambda:call("update_plan_step",{"plan_id":h.get_state().active_plan_id,"step_id":"verify","updates":'{"status":"in_progress"}'},"begin-step"),
        call("run_test",{"test_path":"test_calc.py","step_id":"verify"},"test-fail"),
        call("create_test",{"path":"calc.py","content":fixed},"fix"),
        call("run_test",{"test_path":"test_calc.py","step_id":"verify"},"test-pass"),
        call("create_test",{"path":"calc.py","content":fixed+"# source changed\n"},"change-again"),
        final("fixed", "first-final"),
        call("run_test",{"test_path":"test_calc.py","step_id":"verify"},"test-rerun"),final("fixed","accepted-final")])
    h=GuardedHarness(model,[file_read],config)
    r=h.run("Fix calc.py without changing tests")
    pauses=0
    while r.state==RunStatus.WAITING_APPROVAL:
        pauses+=1
        h.approve(r.run_state.run_id,next(a.approval_id for a in r.run_state.pending_approvals if a.status.value=="PENDING"),approver="teacher")
        r=h.run("Fix calc.py without changing tests",reset=False,resume_run_id=r.run_state.run_id)
    print("repair state",r.state,"pauses",pauses,"evidence",[(e.status.value,e.payload.get("exit_code")) for e in r.run_state.evidence_store.values()])
    print("repair observations",[s.get("observations") for s in h.get_checkpoint().memory_steps if s.get("observations")])
    assert r.state==RunStatus.COMPLETED
    assert (ws/"calc.py").read_text()==fixed+"# source changed\n"
    assert (ws/"test_calc.py").read_text()=="from calc import add\ndef test_add(): assert add(2,5)==7\n"
    assert any(e.tool_call_id=="first-final" and e.event_type==AuditEventType.FINAL_ANSWER_REJECTED for e in h.get_audit())
    assert any(e.status.value=="valid" and e.payload.get("exit_code")==0 for e in r.run_state.evidence_store.values())

def test_s4_cancel_running_command(tmp_path):
    from smolagents.tools import Tool
    marker=tmp_path/"should-not-exist";ready=tmp_path/"ready"
    sb=sandbox(tmp_path,[sys.executable,"-c",f"import pathlib,time;pathlib.Path({str(ready)!r}).touch();time.sleep(1.5);pathlib.Path({str(marker)!r}).touch()"])
    class RunCommand(Tool):
        name="run_command"
        description="Execute the configured teacher fixture command"
        inputs={}
        output_type="string"
        def forward(self):
            return str(sb.execute_command("probe",{},timeout=5))
    config=HarnessConfig(workspace_root=str(tmp_path/"workspace"),storage_path=str(tmp_path/"harness-storage"),
        sandbox_config=sb._config,approval_checkpointer_path=str(tmp_path/"approval.sqlite"),enable_plan_tools=False,
        tool_policies={"run_command":ToolPolicy("run_command",{ToolCapability.EXECUTE},True,True)})
    h=GuardedHarness(ScriptModel([call("run_command",{},"execute"),final()]),[RunCommand()],config)
    r=h.run("Run fixture");h.approve(r.run_state.run_id,r.run_state.pending_approvals[0].approval_id,approver="teacher")
    results=[]
    thread=threading.Thread(target=lambda:results.append(h.run("Run fixture",reset=False,resume_run_id=r.run_state.run_id)))
    thread.start()
    deadline=time.monotonic()+3
    while not ready.exists() and time.monotonic()<deadline:time.sleep(.01)
    assert ready.exists()
    h.cancel();thread.join(4)
    print("cancel marker",marker.exists(),"returned state",results[0].state if results else None)
    assert not marker.exists() and results[0].state==RunStatus.CANCELLED

def process_worker(mode,base):
    """Each invocation is a new interpreter with independent module state."""
    base=Path(base)
    if mode in ("c2start","c2untrackedstart","c3start","c3approvedstart","c4start"):
        h=create_harness(base,report_model())
        if mode=="c2untrackedstart":
            h._runner._config.sandbox_config.fingerprint_patterns=["*.py"]
        r=h.run(TASK);rid=r.run_state.run_id;(base/"rid").write_text(rid)
        print("start",os.getpid(),rid,r.state,"step",r.run_state.current_step,flush=True)
        if mode in ("c2start","c2untrackedstart","c3approvedstart"):
            h.approve(rid,r.run_state.pending_approvals[0].approval_id,approver="teacher")
        if mode.startswith("c2"):
            original=h._audit.log
            def exit_after_write(event):
                if event.event_type==AuditEventType.TOOL_EXECUTED and event.tool_call_id=="write":
                    print("crash after actual write before result persistence",flush=True)
                    os._exit(77)
                original(event)
            h._audit.log=exit_after_write
            h.run(TASK,reset=False,resume_run_id=rid)
        return
    rid=(base/"rid").read_text()
    # Rebuild the public assembly against the SAME persisted storage, no rewriting state.
    from harness.models import ToolPolicy,ToolCapability
    from examples.user_approval import ReadSampleTool,WriteReportTool
    cfg=HarnessConfig(workspace_root=str(base/"workspace"),storage_path=str(base/"storage"),
        sandbox_config=SandboxConfig(workspace_root=str(base/"workspace"),allowed_dirs=["."],sensitive_dirs=[],
            allowed_env_vars=["PATH"],fingerprint_patterns=["*.py"] if mode=="c2untrackedresume" else ["*"]),
        approval_checkpointer_path=str(base/"storage/approval.sqlite"),max_steps=20,enable_plan_tools=False,
        tool_policies={"read_sample":ToolPolicy("read_sample",{ToolCapability.READ},True,False),
            "write_report":ToolPolicy("write_report",{ToolCapability.WRITE},True,True)})
    h=GuardedHarness(ScriptModel([final()]),[ReadSampleTool(base/"workspace"),WriteReportTool(base/"workspace")],cfg)
    if mode=="c3resume":
        approval=h._state_store.get_run(rid).pending_approvals[0]
        try:h.approve(rid,approval.approval_id,approver="teacher")
        except Exception as e:
            print("approve error",type(e).__name__,str(e),flush=True)
            raise
    r=h.run(TASK,reset=False,resume_run_id=rid)
    print("resume",os.getpid(),r.state,r.stop_reason,"step",r.run_state.current_step,
        "tokens",r.run_state.budget.used_tokens,"write count",sum(e.tool_call_id=="write" and e.event_type==AuditEventType.TOOL_STARTED for e in h.get_audit()),flush=True)
    (base/"outcome.json").write_text(json.dumps({"state":r.state.value,"step":r.run_state.current_step,
        "tokens":r.run_state.budget.used_tokens,"stop":r.stop_reason.value if r.stop_reason else None}))

def worker(mode,base):
    result=subprocess.run([sys.executable,__file__,mode,str(base)],text=True,capture_output=True)
    print("worker",mode,"exit",result.returncode,"stdout",result.stdout,"stderr",result.stderr)
    (base/(mode+".log")).write_text(result.stdout+result.stderr)
    return result

@pytest.mark.parametrize("tracked",[True,False])
def test_c2_independent_process(tmp_path,tracked):
    start="c2start" if tracked else "c2untrackedstart"
    end="c2resume" if tracked else "c2untrackedresume"
    assert worker(start,tmp_path).returncode==77
    target=tmp_path/"workspace/analysis_report.md";before=target.read_bytes()
    assert worker(end,tmp_path).returncode==0
    outcome=json.loads((tmp_path/"outcome.json").read_text())
    assert target.read_bytes()==before
    assert outcome["state"]=="UNKNOWN_RESULT"

def test_c3_pending_approval_new_process(tmp_path):
    assert worker("c3start",tmp_path).returncode==0
    assert worker("c3resume",tmp_path).returncode==0
    assert json.loads((tmp_path/"outcome.json").read_text())["state"]=="COMPLETED"

def test_c3_preapproved_new_process(tmp_path):
    assert worker("c3approvedstart",tmp_path).returncode==0
    assert worker("c3approvedresume",tmp_path).returncode==0
    o=json.loads((tmp_path/"outcome.json").read_text())
    assert o["state"]=="COMPLETED" and o["step"]==3 and o["tokens"]==9

def test_c4_new_process_workspace_changed(tmp_path):
    assert worker("c4start",tmp_path).returncode==0
    (tmp_path/"workspace/auth.py").write_text("changed")
    assert worker("c4resume",tmp_path).returncode==0
    o=json.loads((tmp_path/"outcome.json").read_text())
    assert o["stop"]=="WORKSPACE_CHANGED" and not (tmp_path/"workspace/analysis_report.md").exists()

if __name__=="__main__":
    process_worker(sys.argv[1],sys.argv[2])
