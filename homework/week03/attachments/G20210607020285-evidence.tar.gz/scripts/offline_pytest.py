"""Run unchanged student tests without credentials or Internet sockets."""
import os
import socket
import sys

for key in list(os.environ):
    if any(part in key.upper() for part in ("KEY", "TOKEN", "SECRET", "PASSWORD")):
        os.environ.pop(key, None)
original_connect = socket.socket.connect
original_connect_ex = socket.socket.connect_ex

def blocked_connect(self, address):
    if self.family in (socket.AF_INET, socket.AF_INET6):
        raise OSError("Teacher offline policy: Internet sockets disabled")
    return original_connect(self, address)

def blocked_connect_ex(self, address):
    if self.family in (socket.AF_INET, socket.AF_INET6):
        return 101
    return original_connect_ex(self, address)

socket.socket.connect = blocked_connect
socket.socket.connect_ex = blocked_connect_ex
sys.path.insert(0, os.getcwd())
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
