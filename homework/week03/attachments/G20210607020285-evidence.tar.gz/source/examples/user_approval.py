"""真实代码分析与用户审批示例。

使用 DeepSeek、OpenAI、Anthropic 或 Together AI；API Key 的配置与
real_code_analysis.py 相同。程序创建独立的临时工作区，读取示例代码，
并在模型请求写入分析报告时暂停，让用户批准或拒绝。

    PYTHONPATH=src python examples/user_approval.py

示例代码和模型收到的工具结果会发送给所配置的模型服务商。
工作区会创建在项目目录下并保留，方便检查；报告不会覆盖已有文件。
"""

from __future__ import annotations

import argparse
import tempfile
from pathlib import Path
from typing import Literal

from harness.harness import GuardedHarness
from harness.models import ApprovalStatus, HarnessConfig, RunStatus, SandboxConfig, ToolCapability, ToolPolicy
from smolagents.tools import Tool

import sys

if __package__:
    from .real_code_analysis import SAMPLE_CODE_AUTH, SAMPLE_CODE_MATH, create_model
else:
    # 直接运行时，将 examples/ 目录加入 sys.path
    _examples_dir = str(Path(__file__).resolve().parent)
    if _examples_dir not in sys.path:
        sys.path.insert(0, _examples_dir)
    from real_code_analysis import SAMPLE_CODE_AUTH, SAMPLE_CODE_MATH, create_model


Decision = Literal["approve", "reject"]
TASK = (
    "分析工作区中的 auth.py 和 math_utils.py，找出潜在 bug 和安全问题，"
    "对每个问题给出文件名、行号、原因和修复建议。"
    "先使用 read_sample 读取两个文件，再调用 write_report 保存完整中文分析报告。"
    "写入可能需要用户审批；如果用户拒绝，不要再次尝试写入。"
    "最后调用 final_answer，说明报告内容和写入是否成功。"
)


class ReadSampleTool(Tool):
    name = "read_sample"
    description = "Read auth.py or math_utils.py from the sample workspace, with line numbers."
    inputs = {"filename": {"type": "string", "description": "Either auth.py or math_utils.py."}}
    output_type = "string"

    def __init__(self, workspace: Path) -> None:
        self._workspace = workspace
        super().__init__()

    def forward(self, filename: str) -> str:
        if filename not in {"auth.py", "math_utils.py"}:
            raise ValueError(f"只能读取示例文件: {filename}")
        lines = (self._workspace / filename).read_text(encoding="utf-8").splitlines()
        return "\n".join(f"{number}: {line}" for number, line in enumerate(lines, 1))


class WriteReportTool(Tool):
    name = "write_report"
    description = "Write the complete analysis report to analysis_report.md; requires user approval."
    inputs = {"content": {"type": "string", "description": "Complete analysis report in Markdown."}}
    output_type = "string"

    def __init__(self, workspace: Path) -> None:
        self._workspace = workspace
        super().__init__()

    def forward(self, content: str) -> str:
        if not content.strip():
            raise ValueError("分析报告不能为空")
        target = self._workspace / "analysis_report.md"
        with target.open("x", encoding="utf-8") as file:
            file.write(content)
        return f"报告已写入 {target.name}"


def create_harness(base_dir: Path, model) -> GuardedHarness:
    workspace = base_dir / "workspace"
    storage = base_dir / "storage"
    workspace.mkdir()
    storage.mkdir()
    (workspace / "auth.py").write_text(SAMPLE_CODE_AUTH, encoding="utf-8")
    (workspace / "math_utils.py").write_text(SAMPLE_CODE_MATH, encoding="utf-8")
    config = HarnessConfig(
        workspace_root=str(workspace),
        storage_path=str(storage),
        sandbox_config=SandboxConfig(
            workspace_root=str(workspace),
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            fingerprint_patterns=["*"],
        ),
        approval_checkpointer_path=str(storage / "approval.sqlite"),
        max_steps=20,
        enable_plan_tools=False,
        approval_mode="auto_read",
        tool_policies={
            "read_sample": ToolPolicy(
                tool_name="read_sample", capabilities={ToolCapability.READ},
                controlled=True, requires_approval=False,
            ),
            "write_report": ToolPolicy(
                tool_name="write_report", capabilities={ToolCapability.WRITE},
                controlled=True, requires_approval=True,
            ),
        },
    )
    return GuardedHarness(
        model=model, tools=[ReadSampleTool(workspace), WriteReportTool(workspace)], config=config,
    )


def read_decision() -> Decision:
    while True:
        choice = input("是否批准写入报告？输入 y 批准，n 拒绝: ").strip().lower()
        if choice in {"y", "yes"}:
            return "approve"
        if choice in {"n", "no"}:
            return "reject"
        print("请输入 y 或 n。")


def run_demo(base_dir: Path, model, decision: Decision | None = None):
    harness = create_harness(base_dir, model)
    print(f"工作区: {base_dir / 'workspace'}")
    print("正在调用真实模型分析示例代码；写入报告前会请求审批。")
    result = harness.run(TASK)
    requested_approval = False

    while result.state == RunStatus.WAITING_APPROVAL:
        requested_approval = True
        pending = [a for a in result.run_state.pending_approvals if a.status == ApprovalStatus.PENDING]
        if len(pending) != 1:
            raise RuntimeError(f"预期恰好有一个待审批请求，实际数量: {len(pending)}")
        approval = pending[0]
        print(f"\n审批请求: {approval.tool_name}（{approval.risk_level}）")
        print("目标: analysis_report.md")
        print("待写入内容:\n" + str(approval.arguments.get("content", "")))
        selected = decision or read_decision()
        if selected == "approve":
            harness.approve(result.run_state.run_id, approval.approval_id, approver="demo-user")
        elif selected == "reject":
            harness.reject_approval(
                result.run_state.run_id, approval.approval_id, approver="demo-user", reason="用户拒绝写入"
            )
        else:
            raise ValueError(f"未知审批决定: {selected}")
        result = harness.run(TASK, reset=False, resume_run_id=result.run_state.run_id)

    print(f"\n运行状态: {result.state.value}")
    if result.final_answer:
        print("最终答案:\n" + result.final_answer)
    report = base_dir / "workspace" / "analysis_report.md"
    print(f"报告文件: {report if report.exists() else '未生成'}")
    if result.state != RunStatus.COMPLETED:
        raise RuntimeError(f"分析未完成: {result.state.value}, 原因: {result.stop_reason}")
    if not requested_approval:
        raise RuntimeError("模型未请求写入报告，本次没有触发用户审批；请重新运行或更换模型。")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="真实代码分析和用户审批")
    parser.add_argument("--decision", choices=("approve", "reject"), help="非交互测试时指定审批决定")
    args = parser.parse_args()
    model = create_model()
    project_dir = Path(__file__).resolve().parent.parent
    base_dir = Path(tempfile.mkdtemp(prefix="harness-analysis-", dir=project_dir))
    print(f"工作目录（运行结束后保留）: {base_dir}")
    run_demo(base_dir, model, decision=args.decision)


if __name__ == "__main__":
    main()
