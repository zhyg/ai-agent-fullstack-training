"""实际代码分析示例 —— 使用真实 LLM 通过 GuardedHarness 运行。

使用方法：
    # 1. 设置 API Key（选择其一）
    export DEEPSEEK_API_KEY="sk-xxx"
    # 或
    export OPENAI_API_KEY="sk-xxx"
    # 或
    export ANTHROPIC_API_KEY="sk-ant-xxx"
    # 或
    export HF_TOKEN="hf_xxx"

    # 2. 运行
    PYTHONPATH=src python examples/real_code_analysis.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

# 自动加载 examples/.env 中的 API Key
try:
    from dotenv import load_dotenv
    _env_file = Path(__file__).parent / ".env"
    if _env_file.exists():
        load_dotenv(_env_file, override=True)
except ImportError:
    pass  # 未安装 python-dotenv 则跳过，使用环境变量

from harness.harness import GuardedHarness
from harness.models import (
    HarnessConfig,
    RunStatus,
    SandboxConfig,
    ToolCapability,
    ToolPolicy,
)
from smolagents import tool
from smolagents.models import LiteLLMModel


# ══════════════════════════════════════════════
# 自定义工具
# ══════════════════════════════════════════════


def workspace_path(path: str) -> Path:
    """解析工作区内的路径，拒绝越界和符号链接逃逸。"""
    workspace = Path(os.environ["HARNESS_WORKSPACE"]).resolve()
    full_path = (workspace / path).resolve()
    if not full_path.is_relative_to(workspace):
        raise ValueError(f"路径超出工作区: {path}")
    return full_path


@tool
def file_read(path: str) -> str:
    """读取指定路径的文件内容。

    Args:
        path: 文件路径（相对于工作区根目录）。

    Returns:
        带行号的文件内容字符串。
    """
    # 安全限制：只读工作区内文件
    full_path = workspace_path(path)
    if not full_path.exists():
        return f"Error: file not found: {path}"
    lines = full_path.read_text(encoding="utf-8").splitlines()
    return "\n".join(f"{number}: {line}" for number, line in enumerate(lines, start=1))


@tool
def list_files(directory: str = ".") -> str:
    """列出工作区中所有 Python 文件。

    Args:
        directory: 目录路径（相对于工作区根目录）。

    Returns:
        文件列表字符串，每行一个文件名。
    """
    workspace = Path(os.environ["HARNESS_WORKSPACE"]).resolve()
    full_path = workspace_path(directory)
    if not full_path.exists():
        return f"Error: directory not found: {directory}"
    files = sorted(full_path.rglob("*.py"))
    if not files:
        return "No Python files found."
    return "\n".join(str(f.relative_to(workspace)) for f in files)


# ══════════════════════════════════════════════
# 示例待分析代码（写入工作区）
# ══════════════════════════════════════════════


SAMPLE_CODE_AUTH = '''\
"""用户认证模块。"""

import hashlib
import secrets


class UserStore:
    """简单的内存用户存储。"""

    def __init__(self):
        self._users = {}  # {username: {"salt": ..., "pw_hash": ...}}

    def register(self, username: str, password: str) -> bool:
        """注册新用户，密码使用 salt + SHA256 哈希存储。"""
        if username in self._users:
            return False
        salt = secrets.token_hex(16)
        pw_hash = hashlib.sha256((salt + password).encode()).hexdigest()
        self._users[username] = {"salt": salt, "pw_hash": pw_hash}
        return True

    def verify(self, username: str, password: str) -> bool:
        """验证用户密码。"""
        user = self._users.get(username)
        if not user:
            return False
        pw_hash = hashlib.sha256(
            (user["salt"] + password).encode()
        ).hexdigest()
        # BUG: 使用 == 而非 hmac.compare_digest，存在时序攻击风险
        return pw_hash == user["pw_hash"]

    def delete_user(self, username: str) -> bool:
        """删除用户。"""
        if username not in self._users:
            return False
        del self._users[username]
        return True


class SessionManager:
    """会话管理器（简化版）。"""

    def __init__(self, user_store: UserStore):
        self._store = user_store
        self._sessions = {}  # {token: username}

    def login(self, username: str, password: str) -> str | None:
        """登录并返回 session token。"""
        if not self._store.verify(username, password):
            return None
        token = secrets.token_urlsafe(32)
        self._sessions[token] = username
        return token

    def logout(self, token: str) -> None:
        """登出（注销 session）。"""
        self._sessions.pop(token, None)

    def get_current_user(self, token: str) -> str | None:
        """根据 token 获取当前登录用户名。"""
        return self._sessions.get(token)
'''

SAMPLE_CODE_MATH = '''\
"""数学工具函数。"""


def add(a: float, b: float) -> float:
    """两数相加。"""
    return a + b


def subtract(a: float, b: float) -> float:
    """两数相减。"""
    return a - b


def multiply(a: float, b: float) -> float:
    """两数相乘。"""
    return a * b


def divide(a: float, b: float) -> float:
    """两数相除。

    BUG: 未检查除数为 0 的情况。
    """
    return a / b


def average(numbers: list[float]) -> float:
    """计算列表平均值。

    BUG: 空列表时会抛出 ZeroDivisionError。
    """
    return sum(numbers) / len(numbers)
'''


# ══════════════════════════════════════════════
# 主入口
# ══════════════════════════════════════════════


def create_model() -> LiteLLMModel:
    """根据环境变量创建 LLM 模型实例。

    优先级：DEEPSEEK_API_KEY > OPENAI_API_KEY > ANTHROPIC_API_KEY > TOGETHER_API_KEY

    DeepSeek 配置说明：
    - 注册地址：https://platform.deepseek.com
    - API Base：https://api.deepseek.com
    - 模型：deepseek-chat（V3）、deepseek-reasoner（R1）
    """
    if os.getenv("DEEPSEEK_API_KEY"):
        return LiteLLMModel(
            model_id="deepseek/deepseek-chat",
            api_base="https://api.deepseek.com",
            api_key=os.getenv("DEEPSEEK_API_KEY"),
            max_completion_tokens=4096,
        )
    elif os.getenv("OPENAI_API_KEY"):
        return LiteLLMModel(model_id="gpt-4o-mini", max_completion_tokens=4096)
    elif os.getenv("ANTHROPIC_API_KEY"):
        return LiteLLMModel(
            model_id="anthropic/claude-3-5-haiku-20241022",
            max_completion_tokens=4096,
        )
    elif os.getenv("TOGETHER_API_KEY"):
        return LiteLLMModel(
            model_id="together_ai/meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
            max_completion_tokens=4096,
        )
    else:
        raise RuntimeError(
            "请设置至少一个 API Key 环境变量：\n"
            "  export DEEPSEEK_API_KEY='sk-xxx'    # DeepSeek（推荐）\n"
            "  export OPENAI_API_KEY='sk-xxx'       # OpenAI\n"
            "  export ANTHROPIC_API_KEY='sk-ant-xxx' # Anthropic Claude\n"
            "  export TOGETHER_API_KEY='xxx'        # Together AI (Llama)"
        )


def setup_workspace(tmp_dir: Path) -> Path:
    """在工作区写入示例代码文件。"""
    workspace = tmp_dir / "workspace"
    workspace.mkdir(exist_ok=True)

    (workspace / "auth.py").write_text(SAMPLE_CODE_AUTH, encoding="utf-8")
    (workspace / "math_utils.py").write_text(SAMPLE_CODE_MATH, encoding="utf-8")

    # 设置环境变量供工具使用
    os.environ["HARNESS_WORKSPACE"] = str(workspace)
    return workspace


def create_config(workspace: Path, storage: Path) -> HarnessConfig:
    """创建 HarnessConfig。"""
    return HarnessConfig(
        workspace_root=str(workspace),
        storage_path=str(storage),
        sandbox_config=SandboxConfig(
            workspace_root=str(workspace),
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=1_000_000,
        ),
        approval_checkpointer_path=str(storage / "approval.sqlite"),
        max_steps=20,
        enable_plan_tools=True,
        max_tokens=None,       # 不限制 token
        max_wall_time=None,    # 不限制时间
        repeat_threshold=3,
        approval_mode="auto_read",
        tool_policies={
            "file_read": ToolPolicy(
                tool_name="file_read",
                capabilities={ToolCapability.READ},
                controlled=True,
                requires_approval=False,
            ),
            "list_files": ToolPolicy(
                tool_name="list_files",
                capabilities={ToolCapability.READ},
                controlled=True,
                requires_approval=False,
            ),
            # 注意：final_answer 是 HarnessRunner 内置工具，
            # 无需注册 tool_policy，它直接走 acceptance check
        },
    )


def print_result(result) -> None:
    """打印运行结果和审计轨迹摘要。"""
    print("\n" + "=" * 60)
    print("运行结果")
    print("=" * 60)
    print(f"  状态      : {result.state.value}")
    print(f"  停止原因  : {result.stop_reason.value if result.stop_reason else 'N/A'}")
    print(f"  总步数    : {result.run_state.current_step}")
    print()

    # 打印计划状态
    run_state = result.run_state
    if run_state.plans:
        print("计划状态：")
        print("-" * 60)
        for pid, plan in run_state.plans.items():
            active = " [ACTIVE]" if pid == run_state.active_plan_id else ""
            print(f"  Plan: {pid}{active}")
            print(f"    目标: {plan.goal}")
            print(f"    版本: v{plan.version} (修订 {plan.revision_count} 次)")
            for step in plan.steps:
                evidence_count = len(step.evidence_ids)
                print(f"    [{step.status.value:>11}] {step.id}: {step.objective} (证据: {evidence_count} 条)")
        print()

    if result.final_answer:
        print("最终答案：")
        print("-" * 60)
        print(result.final_answer)
        print("-" * 60)
    else:
        print("（无最终答案）")


def main():
    """运行实际代码分析示例。"""
    print("=" * 60)
    print(" Guarded Coding Harness - 代码分析示例")
    print("=" * 60)

    # 在项目目录下创建工作目录（方便查看）
    project_root = Path(__file__).resolve().parent.parent
    tmp_dir = project_root / "demo_workspace"
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)
    tmp_dir.mkdir()
    print(f"\n工作目录: {tmp_dir}")

    try:
        # 1. 准备工作区
        workspace = setup_workspace(tmp_dir)
        storage = tmp_dir / "storage"
        storage.mkdir(exist_ok=True)

        print(f"工作区文件:")
        for f in workspace.rglob("*"):
            if f.is_file():
                print(f"  - {f.relative_to(workspace)}")

        # 2. 创建 LLM 模型
        model = create_model()
        print(f"\nLLM 模型: {model.__class__.__name__}")

        # 3. 创建配置
        config = create_config(workspace, storage)

        # 4. 构建 GuardedHarness
        harness = GuardedHarness(
            model=model,
            tools=[file_read, list_files],
            config=config,
        )
        print("GuardedHarness 初始化完成\n")

        # 5. 运行代码分析任务
        task = (
            "请分析工作区中的 auth.py 和 math_utils.py 文件，"
            "找出其中所有的潜在 bug 和安全问题，"
            "给出每个问题的具体位置和修复建议。\n"
            "只读取文件，不要创建文件或运行测试。\n"
            "你必须先使用 create_plan 创建分析计划，"
            "然后使用 revise_plan 添加分析步骤（每个步骤的 required_evidence_kinds 设置为 [\"inspection\"]），"
            "再逐步使用 file_read 读取每个文件，"
            "分析完成后调用 final_answer 输出完整报告。"
        )
        print(f"任务: {task}")
        print("-" * 60)

        result = harness.run(task)

        # 6. 打印结果
        print_result(result)

        # 7. 打印审计轨迹
        events = harness.get_audit()
        print(f"\n审计轨迹（共 {len(events)} 条）：")
        for ev in events:
            print(f"  [{ev.event_type.value}] {ev.detail[:80] if ev.detail else ''}")

    finally:
        # 保留工作目录供查看，不自动清理
        print(f"\n工作目录已保留: {tmp_dir}")
        print("下次运行会自动清理并重建")


if __name__ == "__main__":
    main()
