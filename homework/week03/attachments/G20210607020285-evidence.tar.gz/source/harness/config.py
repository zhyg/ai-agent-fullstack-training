"""TOML configuration loading and strict validation for the Guarded Coding Harness.

Loads configuration from an explicit file path (no implicit search), converts
to HarnessConfig, and validates all required fields at startup.
"""

from __future__ import annotations

import os
import platform
import sys
from pathlib import Path
from typing import Any

from .models import (
    CommandPolicy,
    ConfigurationError,
    HarnessConfig,
    SandboxConfig,
    ToolCapability,
    ToolPolicy,
)

# Python 3.11+ has tomllib in stdlib; Python 3.10 needs tomli
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        raise ImportError(
            "tomli is required on Python < 3.11. Install with: pip install tomli"
        )


# ──────────────────────────────────────────────
# Known config keys (for unknown-field detection)
# ──────────────────────────────────────────────

_HARNESS_KEYS = {
    "workspace_root",
    "storage_path",
    "max_steps",
    "max_tokens",
    "max_wall_time",
    "approval_mode",
    "repeat_threshold",
    "required_artifacts",
    "llm_retry_max",
    "llm_retry_initial_delay",
    "enable_plan_tools",
}

_APPROVAL_KEYS = {"checkpointer_path"}

_SANDBOX_KEYS = {
    "workspace_root",
    "allowed_dirs",
    "sensitive_dirs",
    "allowed_commands",
    "allowed_env_vars",
    "blocked_env_vars",
    "max_file_size",
    "command_timeout",
    "max_output_bytes",
    "fingerprint_patterns",
}

_COMMAND_KEYS = {"executable", "argv_template", "path_arguments"}

_TOOL_KEYS = {"capabilities", "controlled", "requires_approval"}


# ──────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────


def load_and_validate_toml(path: str | Path) -> HarnessConfig:
    """Load and validate a HarnessConfig from a TOML file.

    Parameters
    ----------
    path : str | Path
        Absolute path to the TOML configuration file.

    Returns
    -------
    HarnessConfig
        Fully validated configuration.

    Raises
    ------
    ConfigurationError
        If the file is missing, unparseable, or fails any validation check.
    """
    path = Path(path)

    # ── File existence ──
    if not path.is_file():
        raise ConfigurationError(f"Configuration file not found: {path}")

    # ── Parse TOML ──
    try:
        with open(path, "rb") as fh:
            raw = tomllib.load(fh)
    except Exception as exc:
        raise ConfigurationError(f"Failed to parse TOML file {path}: {exc}") from exc

    return _build_config(raw, config_path=path)


def validate_config(config: HarnessConfig, registered_tool_names: set[str] | None = None) -> None:
    """Validate a programmatically constructed HarnessConfig.

    Call this after building a HarnessConfig without from_toml().

    Parameters
    ----------
    config : HarnessConfig
        Configuration to validate.
    registered_tool_names : set[str] | None
        If provided, tool policies must exactly match these tool names.
    """
    _validate_platform()
    _validate_workspace_consistency(config)
    _validate_sandbox(config.sandbox_config)
    _validate_approval_path(config)
    if not isinstance(config.enable_plan_tools, bool):
        raise ConfigurationError("enable_plan_tools must be a boolean")
    if registered_tool_names is not None:
        _validate_tool_policies(config.tool_policies, registered_tool_names)


# ──────────────────────────────────────────────
# Internal builders and validators
# ──────────────────────────────────────────────


def _build_config(raw: dict[str, Any], *, config_path: Path) -> HarnessConfig:
    """Convert raw TOML dict to HarnessConfig with full validation."""
    _validate_platform()

    # ── Check top-level unknown sections ──
    known_sections = {"harness", "approval", "sandbox", "tools"}
    for key in raw:
        if key not in known_sections:
            raise ConfigurationError(f"Unknown top-level section: [{key}]")

    # ── [harness] ──
    harness_raw = raw.get("harness")
    if harness_raw is None:
        raise ConfigurationError("Missing required section: [harness]")
    _check_unknown_keys(harness_raw, _HARNESS_KEYS, "[harness]")

    workspace_root = _require_str(harness_raw, "workspace_root", "[harness]")
    storage_path = _require_str(harness_raw, "storage_path", "[harness]")
    max_steps = harness_raw.get("max_steps", 20)
    max_tokens = harness_raw.get("max_tokens")
    max_wall_time = harness_raw.get("max_wall_time")
    approval_mode = harness_raw.get("approval_mode", "auto_read")
    repeat_threshold = harness_raw.get("repeat_threshold", 3)
    required_artifacts = harness_raw.get("required_artifacts", [])
    llm_retry_max = harness_raw.get("llm_retry_max", 3)
    llm_retry_initial_delay = harness_raw.get("llm_retry_initial_delay", 1.0)
    enable_plan_tools = harness_raw.get("enable_plan_tools", True)

    if not isinstance(enable_plan_tools, bool):
        raise ConfigurationError("[harness].enable_plan_tools must be a boolean")

    if approval_mode not in ("auto_read", "manual_all"):
        raise ConfigurationError(
            f"[harness].approval_mode must be 'auto_read' or 'manual_all', got '{approval_mode}'"
        )
    if not isinstance(max_steps, int) or max_steps <= 0:
        raise ConfigurationError(f"[harness].max_steps must be a positive integer, got {max_steps}")
    if max_tokens is not None and (not isinstance(max_tokens, int) or max_tokens <= 0):
        raise ConfigurationError(f"[harness].max_tokens must be a positive integer or null, got {max_tokens}")
    if max_wall_time is not None and (not isinstance(max_wall_time, int) or max_wall_time <= 0):
        raise ConfigurationError(f"[harness].max_wall_time must be a positive integer or null, got {max_wall_time}")
    if not isinstance(repeat_threshold, int) or repeat_threshold <= 0:
        raise ConfigurationError(f"[harness].repeat_threshold must be a positive integer, got {repeat_threshold}")

    # ── [approval] ──
    approval_raw = raw.get("approval", {})
    _check_unknown_keys(approval_raw, _APPROVAL_KEYS, "[approval]")
    approval_checkpointer_path = _require_str(approval_raw, "checkpointer_path", "[approval]")

    # ── [sandbox] ──
    sandbox_raw = raw.get("sandbox")
    if sandbox_raw is None:
        raise ConfigurationError("Missing required section: [sandbox]")
    _check_unknown_keys(sandbox_raw, _SANDBOX_KEYS, "[sandbox]")
    sandbox_config = _build_sandbox_config(sandbox_raw)

    # ── workspace_root consistency ──
    ws_harness = str(Path(workspace_root).resolve())
    ws_sandbox = str(Path(sandbox_config.workspace_root).resolve())
    if ws_harness != ws_sandbox:
        raise ConfigurationError(
            f"workspace_root mismatch: [harness] = '{ws_harness}', [sandbox] = '{ws_sandbox}'"
        )

    # ── checkpointer_path validation ──
    _validate_approval_path_raw(approval_checkpointer_path, ws_harness)

    # ── [tools.*] ──
    tool_policies = _build_tool_policies(raw.get("tools", {}))

    return HarnessConfig(
        workspace_root=ws_harness,
        storage_path=storage_path,
        sandbox_config=sandbox_config,
        approval_checkpointer_path=approval_checkpointer_path,
        max_steps=max_steps,
        max_tokens=max_tokens,
        max_wall_time=max_wall_time,
        repeat_threshold=repeat_threshold,
        approval_mode=approval_mode,
        required_artifacts=required_artifacts,
        tool_policies=tool_policies,
        llm_retry_max=llm_retry_max,
        llm_retry_initial_delay=llm_retry_initial_delay,
        enable_plan_tools=enable_plan_tools,
    )


def _build_sandbox_config(raw: dict[str, Any]) -> SandboxConfig:
    """Build and validate SandboxConfig from raw TOML dict."""
    workspace_root = _require_str(raw, "workspace_root", "[sandbox]")
    allowed_dirs = _require_list(raw, "allowed_dirs", "[sandbox]")
    sensitive_dirs = _require_list(raw, "sensitive_dirs", "[sandbox]")
    allowed_env_vars = raw.get("allowed_env_vars", [])
    blocked_env_vars = raw.get("blocked_env_vars", [])
    max_file_size = raw.get("max_file_size", 10_485_760)
    command_timeout = raw.get("command_timeout", 60)
    max_output_bytes = raw.get("max_output_bytes", 1_048_576)
    fingerprint_patterns = raw.get("fingerprint_patterns", ["*.py"])

    # Validate positive numbers
    if not isinstance(max_file_size, (int, float)) or max_file_size <= 0:
        raise ConfigurationError(f"[sandbox].max_file_size must be a positive number, got {max_file_size}")
    if not isinstance(command_timeout, (int, float)) or command_timeout <= 0:
        raise ConfigurationError(f"[sandbox].command_timeout must be a positive number, got {command_timeout}")
    if not isinstance(max_output_bytes, (int, float)) or max_output_bytes <= 0:
        raise ConfigurationError(f"[sandbox].max_output_bytes must be a positive number, got {max_output_bytes}")

    # Env var overlap
    env_overlap = set(allowed_env_vars) & set(blocked_env_vars)
    if env_overlap:
        raise ConfigurationError(
            f"[sandbox].allowed_env_vars and blocked_env_vars overlap: {sorted(env_overlap)}"
        )

    # Build command policies
    allowed_commands: dict[str, CommandPolicy] = {}
    for profile_name, cmd_raw in raw.get("allowed_commands", {}).items():
        if not isinstance(cmd_raw, dict):
            raise ConfigurationError(
                f"[sandbox.allowed_commands.{profile_name}] must be a table"
            )
        _check_unknown_keys(cmd_raw, _COMMAND_KEYS, f"[sandbox.allowed_commands.{profile_name}]")
        executable = _require_str(cmd_raw, "executable", f"[sandbox.allowed_commands.{profile_name}]")
        if not Path(executable).is_absolute():
            raise ConfigurationError(
                f"[sandbox.allowed_commands.{profile_name}].executable must be an absolute path, got '{executable}'"
            )
        allowed_commands[profile_name] = CommandPolicy(
            executable=executable,
            argv_template=cmd_raw.get("argv_template", []),
            path_arguments=cmd_raw.get("path_arguments", []),
        )

    return SandboxConfig(
        workspace_root=workspace_root,
        allowed_dirs=allowed_dirs,
        sensitive_dirs=sensitive_dirs,
        allowed_commands=allowed_commands,
        allowed_env_vars=allowed_env_vars,
        blocked_env_vars=blocked_env_vars,
        max_file_size=int(max_file_size),
        command_timeout=int(command_timeout),
        max_output_bytes=int(max_output_bytes),
        fingerprint_patterns=fingerprint_patterns,
    )


def _build_tool_policies(raw: dict[str, Any]) -> dict[str, ToolPolicy]:
    """Build tool policies from [tools.*] sections."""
    policies: dict[str, ToolPolicy] = {}
    for tool_name, tool_raw in raw.items():
        if not isinstance(tool_raw, dict):
            raise ConfigurationError(f"[tools.{tool_name}] must be a table")
        _check_unknown_keys(tool_raw, _TOOL_KEYS, f"[tools.{tool_name}]")

        caps_raw = _require_list(tool_raw, "capabilities", f"[tools.{tool_name}]")
        try:
            capabilities = {ToolCapability(c) for c in caps_raw}
        except ValueError as exc:
            raise ConfigurationError(
                f"[tools.{tool_name}].capabilities contains invalid value: {exc}"
            ) from exc

        controlled = tool_raw.get("controlled", True)
        requires_approval = tool_raw.get("requires_approval", False)

        if not isinstance(controlled, bool):
            raise ConfigurationError(
                f"[tools.{tool_name}].controlled must be a boolean, got {type(controlled).__name__}"
            )
        if not isinstance(requires_approval, bool):
            raise ConfigurationError(
                f"[tools.{tool_name}].requires_approval must be a boolean, got {type(requires_approval).__name__}"
            )

        policies[tool_name] = ToolPolicy(
            tool_name=tool_name,
            capabilities=capabilities,
            controlled=controlled,
            requires_approval=requires_approval,
        )
    return policies


# ──────────────────────────────────────────────
# Validators used by validate_config()
# ──────────────────────────────────────────────


def _validate_platform() -> None:
    """Reject non-POSIX platforms."""
    if platform.system() == "Windows":
        raise ConfigurationError("Harness requires a POSIX platform (macOS/Linux). Windows is not supported.")


def _validate_workspace_consistency(config: HarnessConfig) -> None:
    ws_harness = str(Path(config.workspace_root).resolve())
    ws_sandbox = str(Path(config.sandbox_config.workspace_root).resolve())
    if ws_harness != ws_sandbox:
        raise ConfigurationError(
            f"workspace_root mismatch: HarnessConfig = '{ws_harness}', "
            f"SandboxConfig = '{ws_sandbox}'"
        )


def _validate_sandbox(sc: SandboxConfig) -> None:
    env_overlap = set(sc.allowed_env_vars) & set(sc.blocked_env_vars)
    if env_overlap:
        raise ConfigurationError(
            f"allowed_env_vars and blocked_env_vars overlap: {sorted(env_overlap)}"
        )
    if sc.max_file_size <= 0:
        raise ConfigurationError(f"max_file_size must be positive, got {sc.max_file_size}")
    if sc.command_timeout <= 0:
        raise ConfigurationError(f"command_timeout must be positive, got {sc.command_timeout}")
    if sc.max_output_bytes <= 0:
        raise ConfigurationError(f"max_output_bytes must be positive, got {sc.max_output_bytes}")


def _validate_approval_path(config: HarnessConfig) -> None:
    _validate_approval_path_raw(config.approval_checkpointer_path, config.workspace_root)


def _validate_approval_path_raw(checkpointer_path: str, workspace_root: str) -> None:
    ws = Path(workspace_root).resolve()
    cp = Path(checkpointer_path).resolve()
    try:
        cp.relative_to(ws)
        raise ConfigurationError(
            f"approval_checkpointer_path must be outside workspace_root: '{cp}' is inside '{ws}'"
        )
    except ValueError:
        pass  # Good — not inside workspace


def _validate_tool_policies(
    policies: dict[str, ToolPolicy], registered_tool_names: set[str]
) -> None:
    policy_names = set(policies.keys())
    missing = registered_tool_names - policy_names
    extra = policy_names - registered_tool_names - {"create_test", "run_test"}
    if missing:
        raise ConfigurationError(
            f"Tool policies missing for registered tools: {sorted(missing)}"
        )
    if extra:
        raise ConfigurationError(
            f"Tool policies declared for unknown tools: {sorted(extra)}"
        )
    for name, capability in (("create_test", ToolCapability.WRITE), ("run_test", ToolCapability.EXECUTE)):
        if name in policies and name not in registered_tool_names:
            policy = policies[name]
            if capability not in policy.capabilities or not policy.controlled:
                raise ConfigurationError(f"Built-in {name} requires a controlled {capability.value} policy")


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────


def _require_str(d: dict[str, Any], key: str, section: str) -> str:
    val = d.get(key)
    if val is None:
        raise ConfigurationError(f"Missing required field: {section}.{key}")
    if not isinstance(val, str) or not val.strip():
        raise ConfigurationError(f"{section}.{key} must be a non-empty string, got {val!r}")
    return val


def _require_list(d: dict[str, Any], key: str, section: str) -> list:
    val = d.get(key)
    if val is None:
        raise ConfigurationError(f"Missing required field: {section}.{key}")
    if not isinstance(val, list):
        raise ConfigurationError(f"{section}.{key} must be a list, got {type(val).__name__}")
    return val


def _check_unknown_keys(d: dict[str, Any], known: set[str], section: str) -> None:
    unknown = set(d.keys()) - known
    if unknown:
        raise ConfigurationError(f"Unknown fields in {section}: {sorted(unknown)}")
