"""CheckpointManager — save and restore agent state at step boundaries.

Checkpoints enable fault recovery: if the agent process is interrupted,
a new process can resume from the last checkpoint without repeating
completed work.

Per PRD §2.4.
"""

from __future__ import annotations

import fcntl
import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from smolagents.memory import ActionStep, MemoryStep, ToolCall
from smolagents.monitoring import Timing

from .models import Checkpoint, RunState
from .state_store import PlanContextStep, _deserialize_run_state, _serialize


class CheckpointManager:
    """Manages checkpoint save/load for fault recovery.

    Checkpoints are stored as JSON files at
    ``{storage_path}/checkpoints/checkpoint_{run_id}_{seq:06d}.json``.

    A run lock at ``{storage_path}/locks/{run_id}.lock`` ensures only
    one process can hold the run at a time.
    """

    def __init__(self, storage_path: str | Path) -> None:
        self._cp_dir = Path(storage_path) / "checkpoints"
        self._cp_dir.mkdir(parents=True, exist_ok=True)
        self._locks_dir = Path(storage_path) / "locks"
        self._locks_dir.mkdir(parents=True, exist_ok=True)
        self._lock_file = None
        self._lock_fd = None

    # ── Run lock ──────────────────────────────

    def acquire_run_lock(self, run_id: str) -> None:
        """Acquire exclusive lock for a run_id. Raises if already held."""
        lock_path = self._locks_dir / f"{run_id}.lock"
        fd = open(lock_path, "w")
        try:
            fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (IOError, OSError):
            fd.close()
            from .models import RunAlreadyActiveError
            raise RunAlreadyActiveError(
                f"Run {run_id} is already active (locked by another process)"
            )
        self._lock_file = lock_path
        self._lock_fd = fd

    def release_run_lock(self, run_id: str) -> None:
        """Release the run lock."""
        if self._lock_fd is not None:
            try:
                fcntl.flock(self._lock_fd.fileno(), fcntl.LOCK_UN)
                self._lock_fd.close()
            except Exception:
                pass
            self._lock_fd = None
            self._lock_file = None

    # ── Save ──────────────────────────────────

    def save(
        self,
        run_id: str,
        step_number: int,
        run_state: RunState,
        memory_steps: list[dict[str, Any]],
        workspace_fingerprint: str,
    ) -> Checkpoint:
        """Save a checkpoint at the given step boundary."""
        # Determine sequence number
        existing = self.list_checkpoints(run_id)
        seq = (max(existing) + 1) if existing else 0

        cp = Checkpoint(
            run_id=run_id,
            checkpoint_seq=seq,
            step_number=step_number,
            run_state=run_state,
            memory_steps=memory_steps,
            workspace_fingerprint=workspace_fingerprint,
        )

        data = {
            "run_id": cp.run_id,
            "checkpoint_seq": cp.checkpoint_seq,
            "step_number": cp.step_number,
            "run_state": _serialize(cp.run_state),
            "memory_steps": cp.memory_steps,
            "workspace_fingerprint": cp.workspace_fingerprint,
            "created_at": cp.created_at.isoformat(),
        }

        path = self._cp_path(run_id, seq)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
        return cp

    # ── Load ──────────────────────────────────

    def load_latest(self, run_id: str) -> Checkpoint | None:
        """Load the latest checkpoint for a run."""
        seqs = self.list_checkpoints(run_id)
        if not seqs:
            return None
        return self.load(run_id, max(seqs))

    def load(self, run_id: str, seq: int) -> Checkpoint | None:
        """Load a specific checkpoint."""
        path = self._cp_path(run_id, seq)
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return Checkpoint(
            run_id=data["run_id"],
            checkpoint_seq=data["checkpoint_seq"],
            step_number=data["step_number"],
            run_state=_deserialize_run_state(data["run_state"]),
            memory_steps=data.get("memory_steps", []),
            workspace_fingerprint=data.get("workspace_fingerprint", ""),
            created_at=datetime.fromisoformat(data["created_at"]),
        )

    def list_checkpoints(self, run_id: str) -> list[int]:
        """List all checkpoint sequence numbers for a run."""
        pattern = f"checkpoint_{run_id}_*.json"
        seqs: list[int] = []
        for path in self._cp_dir.glob(pattern):
            # Extract seq from filename
            name = path.stem  # checkpoint_{run_id}_{seq:06d}
            parts = name.rsplit("_", 1)
            if len(parts) == 2:
                try:
                    seqs.append(int(parts[1]))
                except ValueError:
                    pass
        return sorted(seqs)

    # ── Workspace fingerprint ─────────────────

    def compute_workspace_fingerprint(
        self, workspace_root: str, patterns: list[str] | None = None
    ) -> str:
        """Compute a SHA-256 fingerprint of workspace files."""
        import hashlib

        ws = Path(workspace_root)
        if not ws.exists():
            return "empty"

        file_patterns = patterns or ["*.py"]
        hasher = hashlib.sha256()
        for pattern in file_patterns:
            for p in sorted(ws.rglob(pattern)):
                try:
                    hasher.update(str(p.relative_to(ws)).encode())
                    hasher.update(p.read_bytes())
                except (OSError, PermissionError):
                    pass
        return hasher.hexdigest()[:16]

    def validate_workspace(self, checkpoint: Checkpoint, current_fingerprint: str) -> bool:
        """Check if workspace fingerprint matches the checkpoint."""
        return checkpoint.workspace_fingerprint == current_fingerprint

    # ── Memory restoration ────────────────────

    def restore_memory_steps(self, serialized_steps: list[dict]) -> list[MemoryStep]:
        """Reconstruct MemoryStep objects from serialized dicts.

        Uses a type whitelist for safe deserialization.
        """
        steps: list[MemoryStep] = []
        for data in serialized_steps:
            step = self._restore_step(data)
            if step is not None:
                steps.append(step)
        return steps

    def _restore_step(self, data: dict) -> MemoryStep | None:
        """Restore a single memory step from dict."""
        # Try PlanContextStep first
        if "plan_summary" in data:
            return PlanContextStep(plan_summary=data["plan_summary"])

        # Try ActionStep
        if "step_number" in data and "timing" in data:
            # Simplified restoration — in production this would fully
            # reconstruct ActionStep with all fields
            return ActionStep(
                step_number=data["step_number"],
                timing=Timing(start_time=0.0, end_time=0.0),
                model_output=data.get("model_output"),
                observations=data.get("observations"),
                is_final_answer=data.get("is_final_answer", False),
                action_output=data.get("action_output"),
                tool_calls=[
                    ToolCall(id=tc["id"], name=tc["function"]["name"], arguments=tc["function"]["arguments"])
                    for tc in data.get("tool_calls", [])
                ] or None,
            )

        return None

    # ── Internal helpers ──────────────────────

    def _cp_path(self, run_id: str, seq: int) -> Path:
        return self._cp_dir / f"checkpoint_{run_id}_{seq:06d}.json"
