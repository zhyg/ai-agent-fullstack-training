"""Sandbox module — constrains file paths, commands, environment, and output.

All file operations and command executions pass through the Sandbox to
enforce workspace boundaries, command whitelisting, environment filtering,
timeout/size limits, and output truncation.

Per PRD §2.2.
"""

from __future__ import annotations

import os
import signal
import subprocess
import uuid
from datetime import datetime
from pathlib import Path

from .audit import AuditLogger
from .models import (
    AuditEvent,
    AuditEventType,
    CommandPolicy,
    CommandResult,
    SandboxConfig,
    SandboxViolation,
    SandboxViolationError,
)


class Sandbox:
    """Enforces sandbox constraints on file paths, commands, and environment.

    Parameters
    ----------
    config : SandboxConfig
        Sandbox configuration with workspace, allowed dirs, commands, etc.
    audit : AuditLogger
        Audit logger for recording sandbox decisions.
    """

    def __init__(self, config: SandboxConfig, audit: AuditLogger) -> None:
        self._config = config
        self._audit = audit
        self._workspace_root = Path(config.workspace_root).resolve()
        self._allowed_dirs = self._resolve_dirs(config.allowed_dirs)
        self._sensitive_dirs = self._resolve_dirs(config.sensitive_dirs)

    # ── Path validation ─────────────────────────────

    def validate_path(self, path: str) -> str:
        """Validate path safety and return the resolved absolute path.

        Raises :class:`SandboxViolation` if the path escapes the workspace,
        falls within a sensitive directory, or is outside allowed dirs.
        """
        resolved = Path(path).resolve()

        # Check: must be within workspace_root
        try:
            resolved.relative_to(self._workspace_root)
        except ValueError:
            violation = SandboxViolation(
                type="PATH_ESCAPE",
                path=str(resolved),
                message=f"Path escapes workspace_root: {resolved}",
            )
            self._log_violation("PATH_ESCAPE", str(resolved),
                                f"Path escapes workspace: {resolved}")
            raise SandboxViolationError(violation)

        # Check: must not be in sensitive_dirs
        for sd in self._sensitive_dirs:
            try:
                resolved.relative_to(sd)
                violation = SandboxViolation(
                    type="SYMLINK_ESCAPE",
                    path=str(resolved),
                    real_path=str(resolved),
                    message=f"Path is within sensitive directory: {sd}",
                )
                self._log_violation("SYMLINK_ESCAPE", str(resolved),
                                    f"Path is within sensitive dir: {sd}")
                raise SandboxViolationError(violation)
            except ValueError:
                pass  # Good — not within this sensitive dir

        if not any(resolved == directory or directory in resolved.parents for directory in self._allowed_dirs):
            violation = SandboxViolation(
                type="PATH_NOT_ALLOWED",
                path=str(resolved),
                message=f"Path is outside allowed directories: {resolved}",
            )
            self._log_violation("PATH_NOT_ALLOWED", str(resolved), violation.message)
            raise SandboxViolationError(violation)

        return str(resolved)

    # ── Command validation ──────────────────────────

    def validate_command(self, command_name: str, arguments: dict[str, str]) -> list[str]:
        """Validate a command against its profile and return the argv list.

        Raises :class:`SandboxViolation` if the command profile is unknown,
        arguments don't match the template, or path arguments escape the
        workspace.
        """
        policies = self._config.allowed_commands

        if command_name not in policies:
            violation = SandboxViolation(
                type="COMMAND_NOT_ALLOWED",
                message=f"Command profile not in allowed_commands: '{command_name}'",
            )
            self._log_violation("COMMAND_NOT_ALLOWED", None,
                                f"Unknown command profile: {command_name}")
            raise SandboxViolationError(violation)

        policy = policies[command_name]

        # Check for unapproved arguments
        # Extract placeholder names from argv_template
        template_placeholders = set()
        for arg in policy.argv_template:
            if arg.startswith("{") and arg.endswith("}"):
                template_placeholders.add(arg[1:-1])

        provided_keys = set(arguments.keys())
        extra_keys = provided_keys - template_placeholders
        if extra_keys:
            violation = SandboxViolation(
                type="COMMAND_NOT_ALLOWED",
                message=f"Unapproved arguments for '{command_name}': {sorted(extra_keys)}",
            )
            self._log_violation("COMMAND_NOT_ALLOWED", None,
                                f"Unapproved arguments: {sorted(extra_keys)}")
            raise SandboxViolationError(violation)

        # Check all template placeholders are provided
        missing_keys = template_placeholders - provided_keys
        if missing_keys:
            raise SandboxViolationError(SandboxViolation(
                type="COMMAND_NOT_ALLOWED",
                message=f"Missing required arguments for '{command_name}': {sorted(missing_keys)}",
            ))

        # Validate path arguments through Sandbox path check
        for path_arg_name in policy.path_arguments:
            if path_arg_name in arguments:
                self.validate_path(arguments[path_arg_name])

        # Build argv from template
        argv = [policy.executable]
        for template_arg in policy.argv_template:
            if template_arg.startswith("{") and template_arg.endswith("}"):
                key = template_arg[1:-1]
                argv.append(arguments[key])
            else:
                argv.append(template_arg)

        return argv

    # ── Command execution ───────────────────────────

    def execute_command(
        self,
        command_name: str,
        arguments: dict[str, str],
        timeout: int | None = None,
        env: dict[str, str] | None = None,
    ) -> CommandResult:
        """Execute a validated command in the sandbox with timeout handling.

        Uses ``subprocess.Popen`` with ``start_new_session=True`` to create a
        process group.  On timeout, ``os.killpg`` terminates the entire group.
        """
        argv = self.validate_command(command_name, arguments)
        effective_timeout = timeout if timeout is not None else self._config.command_timeout

        # Filter environment
        process_env = self.filter_env(env if env is not None else dict(os.environ))

        process = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=process_env,
            start_new_session=True,
            cwd=str(self._workspace_root),
        )

        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=effective_timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            # Kill the entire process group
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            # Give it a moment to terminate gracefully
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=5)
            stdout, stderr = process.stdout.read(), process.stderr.read()

        stdout_str = stdout.decode("utf-8", errors="replace") if stdout else ""
        stderr_str = stderr.decode("utf-8", errors="replace") if stderr else ""

        # Truncate output
        stdout_str, _ = self.truncate_output(stdout_str)
        stderr_str, _ = self.truncate_output(stderr_str)

        return CommandResult(
            exit_code=process.returncode if process.returncode is not None else -1,
            stdout=stdout_str,
            stderr=stderr_str,
            timed_out=timed_out,
        )

    # ── Environment filtering ───────────────────────

    def filter_env(self, env: dict[str, str]) -> dict[str, str]:
        """Filter environment variables according to sandbox config.

        Only variables listed in ``allowed_env_vars`` AND NOT listed in
        ``blocked_env_vars`` are kept.
        """
        allowed = set(self._config.allowed_env_vars)
        blocked = set(self._config.blocked_env_vars)
        return {
            key: value
            for key, value in env.items()
            if key in allowed and key not in blocked
        }

    # ── Output truncation ───────────────────────────

    def truncate_output(self, output: str) -> tuple[str, bool]:
        """Truncate output to ``max_output_bytes``.

        Returns ``(content, was_truncated)``.
        """
        max_bytes = self._config.max_output_bytes
        encoded = output.encode("utf-8")
        if len(encoded) <= max_bytes:
            return output, False
        truncated = encoded[:max_bytes].decode("utf-8", errors="ignore")
        return truncated, True

    # ── File size check ─────────────────────────────

    def check_file_size(self, content: str) -> None:
        """Check that content does not exceed ``max_file_size``.

        Raises :class:`SandboxViolation` if the UTF-8 encoded content
        exceeds the limit.
        """
        byte_len = len(content.encode("utf-8"))
        if byte_len > self._config.max_file_size:
            violation = SandboxViolation(
                type="FILE_TOO_LARGE",
                message=f"Content size ({byte_len} bytes) exceeds max_file_size "
                        f"({self._config.max_file_size} bytes)",
            )
            self._log_violation("FILE_TOO_LARGE", None,
                                f"Content size {byte_len} exceeds max {self._config.max_file_size}")
            raise SandboxViolationError(violation)

    # ── Internal helpers ────────────────────────────

    def _resolve_dirs(self, dirs: list[str]) -> list[Path]:
        """Resolve directory paths relative to workspace_root.

        ``~`` is expanded to the user's home directory.  Relative paths
        are resolved against workspace_root.
        """
        resolved = []
        for d in dirs:
            expanded = os.path.expanduser(d)
            p = Path(expanded)
            if not p.is_absolute():
                p = self._workspace_root / p
            resolved.append(p.resolve())
        return resolved

    def _log_violation(
        self, violation_type: str, path: str | None, message: str
    ) -> None:
        """Record a sandbox violation in the audit log."""
        self._audit.log(
            AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.SANDBOX_VIOLATION,
                run_id="",  # Will be set by the caller context
                tool_call_id=None,
                step_number=None,
                tool_name=None,
                arguments=None,
                rule=f"sandbox.{violation_type}",
                decision="DENY",
                actor="system",
                detail=message,
            )
        )
