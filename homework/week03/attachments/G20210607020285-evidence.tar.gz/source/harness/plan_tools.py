"""Plan tools — smolagents Tool subclasses exposing StateStore to the Agent.

Each tool wraps a StateStore operation and enforces harness constraints
(e.g. model cannot set step status to COMPLETED).

Per PRD §2.3.3.
"""

from __future__ import annotations

import json
import uuid
from collections.abc import Callable
from datetime import datetime
from typing import Any
from pathlib import Path

from smolagents.tools import Tool

from .models import (
    Evidence,
    EvidenceKind,
    PlanStep,
    StepStatus,
)
from .state_store import StateStore
from .sandbox import Sandbox


# ──────────────────────────────────────────────
# create_plan
# ──────────────────────────────────────────────


class CreatePlanTool(Tool):
    """Create a structured execution plan for the current task."""

    name = "create_plan"
    description = (
        "Creates a new execution plan with a goal, optional constraints, "
        "and ordered steps. Returns the plan ID and initial step list."
    )
    inputs: dict[str, dict[str, str | type | bool]] = {
        "goal": {
            "type": "string",
            "description": "The overall goal this plan aims to achieve.",
        },
        "constraints": {
            "type": "string",
            "description": (
                "JSON array of constraint strings (global limits/red lines). "
                'Example: ["Do not modify DB schema"]'
            ),
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, state_store: StateStore, run_id: str, **kwargs: Any) -> None:
        self._state_store = state_store
        self._run_id = run_id
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        goal = kwargs.get("goal", "")
        constraints_str = kwargs.get("constraints", "[]")
        try:
            constraints = json.loads(constraints_str)
        except (json.JSONDecodeError, TypeError):
            constraints = []

        plan = self._state_store.create_plan(
            self._run_id,
            goal=goal,
            constraints=constraints,
        )
        self._state_store.set_active_plan(self._run_id, list(self._state_store.list_plans(self._run_id))[-1])
        return json.dumps({"plan_id": self._state_store.get_run(self._run_id).active_plan_id, "goal": plan.goal})


# ──────────────────────────────────────────────
# get_plan
# ──────────────────────────────────────────────


class GetPlanTool(Tool):
    """Get the full details of a Plan including all steps and their status."""

    name = "get_plan"
    description = "Returns the full plan with all steps, status, and evidence."
    inputs: dict[str, dict[str, str | type | bool]] = {
        "plan_id": {
            "type": "string",
            "description": "The ID of the plan to retrieve.",
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, state_store: StateStore, run_id: str, **kwargs: Any) -> None:
        self._state_store = state_store
        self._run_id = run_id
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        plan_id = kwargs.get("plan_id", "")
        plan = self._state_store.get_plan(self._run_id, plan_id)
        if plan is None:
            return json.dumps({"error": f"Plan not found: {plan_id}"})
        steps = [
            {
                "id": s.id,
                "objective": s.objective,
                "status": s.status.value,
                "depends_on": s.depends_on,
                "evidence_ids": s.evidence_ids,
            }
            for s in plan.steps
        ]
        return json.dumps({
            "plan_id": plan_id,
            "goal": plan.goal,
            "version": plan.version,
            "steps": steps,
        })


# ──────────────────────────────────────────────
# update_plan_step
# ──────────────────────────────────────────────


class UpdatePlanStepTool(Tool):
    """Update a plan step's objective, status, or other allowed fields.

    IMPORTANT: Model must NOT set status to 'completed'. Completion is
    determined by the Harness acceptance checker.
    """

    name = "update_plan_step"
    description = (
        "Updates a plan step's allowed fields: objective, status, attempts, last_error. "
        "You can NOT set status to 'completed' — completion is determined by the Harness "
        "acceptance checker. You can NOT update evidence_ids, depends_on, or required_evidence_kinds."
    )
    inputs: dict[str, dict[str, str | type | bool]] = {
        "plan_id": {
            "type": "string",
            "description": "The plan containing the step.",
        },
        "step_id": {
            "type": "string",
            "description": "The step to update.",
        },
        "updates": {
            "type": "string",
            "description": (
                "JSON object of field updates. Allowed fields: objective, status, attempts, last_error. "
                "Do NOT set status to 'completed'. "
                'Example: {"status": "in_progress", "attempts": 1}'
            ),
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, state_store: StateStore, run_id: str, **kwargs: Any) -> None:
        self._state_store = state_store
        self._run_id = run_id
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        plan_id = kwargs.get("plan_id", "")
        step_id = kwargs.get("step_id", "")
        updates_str = kwargs.get("updates", "{}")
        try:
            updates = json.loads(updates_str)
        except (json.JSONDecodeError, TypeError):
            raise ValueError("updates must be a JSON object")
        if not isinstance(updates, dict):
            raise ValueError("updates must be a JSON object")
        disallowed = set(updates) - {"objective", "status", "attempts", "last_error"}
        if disallowed:
            raise ValueError(f"Plan step fields cannot be updated by the model: {sorted(disallowed)}")

        # Constraint: model must NOT set status to COMPLETED
        if updates.get("status") == "completed" or updates.get("status") == StepStatus.COMPLETED.value:
            return json.dumps({
                "error": "Model cannot set step status to 'completed'. "
                         "Completion is determined by the Harness acceptance checker."
            })

        # Convert status string to enum if present
        if "status" in updates:
            try:
                updates["status"] = StepStatus(updates["status"])
            except ValueError:
                pass

        step = self._state_store.update_plan_step(self._run_id, plan_id, step_id, **updates)
        return json.dumps({"step_id": step.id, "status": step.status.value})


# ──────────────────────────────────────────────
# revise_plan
# ──────────────────────────────────────────────


class RevisePlanTool(Tool):
    """Revise a plan by adding new steps, updating existing steps, or changing constraints."""

    name = "revise_plan"
    description = (
        "Revises an existing plan by adding new steps or updating existing ones. "
        "Each step must specify required_evidence_kinds. "
        "Use ['inspection'] for read-only analysis steps, "
        "['test'] for steps that run tests, "
        "['diff'] for steps that modify source code. "
        "Revision count is limited by max_revisions."
    )
    inputs: dict[str, dict[str, str | type | bool]] = {
        "plan_id": {
            "type": "string",
            "description": "The plan to revise.",
        },
        "new_steps": {
            "type": "string",
            "description": (
                "JSON array of new step objects. Each must have 'id' and 'objective'. "
                'Each step must specify required_evidence_kinds and may specify depends_on. '
                'Use ["inspection"] for read-only analysis, ["test"] for test execution, '
                '["diff"] for code changes. '
                'Example (analysis): [{"id": "analyze-auth", "objective": "Analyze auth.py for security issues", '
                '"required_evidence_kinds": ["inspection"]}]. '
                'Example (test): [{"id": "step-3", "objective": "Run tests", '
                '"required_evidence_kinds": ["test"]}]'
            ),
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, state_store: StateStore, run_id: str, **kwargs: Any) -> None:
        self._state_store = state_store
        self._run_id = run_id
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        plan_id = kwargs.get("plan_id", "")
        new_steps_str = kwargs.get("new_steps", "[]")
        try:
            new_steps_data = json.loads(new_steps_str)
        except (json.JSONDecodeError, TypeError):
            raise ValueError("new_steps must be a JSON array")
        if not isinstance(new_steps_data, list) or not all(isinstance(s, dict) for s in new_steps_data):
            raise ValueError("new_steps must be a JSON array of objects")
        if any(not s.get("required_evidence_kinds") for s in new_steps_data):
            raise ValueError(
                "Each plan step needs required_evidence_kinds for automatic acceptance. "
                'Use ["inspection"] for read-only analysis, ["test"] for test steps, '
                '["diff"] for code change steps.'
            )

        new_steps = [
            PlanStep(
                id=s.get("id", str(uuid.uuid4())),
                objective=s.get("objective", ""),
                depends_on=s.get("depends_on", []),
                required_evidence_kinds=[EvidenceKind(k) for k in s.get("required_evidence_kinds", [])],
            )
            for s in new_steps_data
        ]

        try:
            plan = self._state_store.revise_plan(
                self._run_id, plan_id, new_steps=new_steps,
            )
            return json.dumps({
                "plan_id": plan_id,
                "version": plan.version,
                "revision_count": plan.revision_count,
                "steps_count": len(plan.steps),
            })
        except Exception as e:
            return json.dumps({"error": str(e)})


# ──────────────────────────────────────────────
# delete_plan
# ──────────────────────────────────────────────


class DeletePlanTool(Tool):
    """Delete a plan and all its steps."""

    name = "delete_plan"
    description = "Deletes an entire plan and its steps."
    inputs: dict[str, dict[str, str | type | bool]] = {
        "plan_id": {
            "type": "string",
            "description": "The plan to delete.",
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, state_store: StateStore, run_id: str, **kwargs: Any) -> None:
        self._state_store = state_store
        self._run_id = run_id
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        plan_id = kwargs.get("plan_id", "")
        try:
            self._state_store.delete_plan(self._run_id, plan_id)
            return json.dumps({"deleted": plan_id})
        except Exception as e:
            return json.dumps({"error": str(e)})


# ──────────────────────────────────────────────
# list_plans
# ──────────────────────────────────────────────


class ListPlansTool(Tool):
    """List all plans in the current run."""

    name = "list_plans"
    description = "Returns a list of all plan IDs in the current run."
    inputs: dict[str, dict[str, str | type | bool]] = {
        "dummy": {
            "type": "string",
            "description": "Unused placeholder. Pass an empty string.",
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, state_store: StateStore, run_id: str, **kwargs: Any) -> None:
        self._state_store = state_store
        self._run_id = run_id
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        plan_ids = self._state_store.list_plans(self._run_id)
        run = self._state_store.get_run(self._run_id)
        return json.dumps({
            "plans": plan_ids,
            "active_plan_id": run.active_plan_id if run else None,
        })


# ──────────────────────────────────────────────
# create_test
# ──────────────────────────────────────────────


class CreateTestTool(Tool):
    """Create a test file in the workspace."""

    name = "create_test"
    description = "Creates a test file at the given path with the specified content."
    inputs: dict[str, dict[str, str | type | bool]] = {
        "path": {
            "type": "string",
            "description": "The file path for the test (relative to workspace).",
        },
        "content": {
            "type": "string",
            "description": "The Python test file content.",
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(self, workspace_root: str, sandbox: Sandbox, **kwargs: Any) -> None:
        self._workspace_root = workspace_root
        self._sandbox = sandbox
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        target = Path(self._sandbox.validate_path(str(Path(self._workspace_root) / path)))
        self._sandbox.check_file_size(content)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return json.dumps({"path": str(target), "bytes": len(content.encode("utf-8"))})


# ──────────────────────────────────────────────
# run_test
# ──────────────────────────────────────────────


class RunTestTool(Tool):
    """Run a test and generate Evidence for a PlanStep."""

    name = "run_test"
    description = (
        "Runs a test command and generates TEST evidence linked to a plan step. "
        "The test path must be within the workspace."
    )
    inputs: dict[str, dict[str, str | type | bool]] = {
        "test_path": {
            "type": "string",
            "description": "The test file or directory path to run.",
        },
        "step_id": {
            "type": "string",
            "description": "The PlanStep ID to link the evidence to.",
        },
    }
    output_type = "string"
    skip_forward_signature_validation = True

    def __init__(
        self,
        state_store: StateStore,
        run_id: str,
        sandbox: Sandbox,
        workspace_root: str,
        artifact_version: str | Callable[[], str] = "v0",
        **kwargs: Any,
    ) -> None:
        self._state_store = state_store
        self._run_id = run_id
        self._artifact_version = artifact_version
        self._sandbox = sandbox
        self._workspace_root = workspace_root
        super().__init__(**kwargs)

    def forward(self, **kwargs: Any) -> str:
        test_path = kwargs.get("test_path", "")
        step_id = kwargs.get("step_id", "")
        if not test_path:
            raise ValueError("test_path must not be empty")

        run = self._state_store.get_run(self._run_id)
        plan = run.plans.get(run.active_plan_id) if run and run.active_plan_id else None
        if plan is None or not any(step.id == step_id for step in plan.steps):
            raise ValueError(f"Step not found in active plan: {step_id}")
        target = self._sandbox.validate_path(str(Path(self._workspace_root) / test_path))
        if not Path(target).exists():
            raise ValueError(f"Test path does not exist: {test_path}")
        policy = self._sandbox._config.allowed_commands.get("run_test")
        if policy is None or "test_path" not in policy.path_arguments:
            raise ValueError("run_test requires a sandbox command profile with test_path as a path argument")
        before = self._artifact_version() if callable(self._artifact_version) else self._artifact_version
        result = self._sandbox.execute_command("run_test", {"test_path": target})
        artifact_version = self._artifact_version() if callable(self._artifact_version) else self._artifact_version
        if before != artifact_version:
            self._state_store.invalidate_stale_evidence(self._run_id, artifact_version)
        if result.timed_out or result.exit_code != 0:
            raise RuntimeError(
                f"Test failed: exit_code={result.exit_code}, timed_out={result.timed_out}\n"
                f"{result.stdout}\n{result.stderr}"
            )

        evidence_id = str(uuid.uuid4())
        evidence = Evidence(
            id=evidence_id,
            step_id=step_id,
            tool_call_id=f"tc-{evidence_id}",
            artifact_version=artifact_version,
            kind=EvidenceKind.TEST,
            summary=f"Test run for {test_path}",
            payload={"test_path": test_path, "exit_code": result.exit_code, "stdout": result.stdout, "stderr": result.stderr},
            created_at=datetime.now(),
        )
        self._state_store.add_evidence(self._run_id, evidence)

        return json.dumps({
            "evidence_id": evidence_id,
            "step_id": step_id,
            "kind": "test",
            "artifact_version": artifact_version,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
        })


# ──────────────────────────────────────────────
# Factory: create all Plan tools at once
# ──────────────────────────────────────────────


def create_plan_tools(
    state_store: StateStore,
    run_id: str,
    workspace_root: str,
    sandbox: Sandbox,
    artifact_version: str | Callable[[], str] = "v0",
    include_test_tools: set[str] | None = None,
) -> list[Tool]:
    """Create and return all Plan-related tools for the agent."""
    tools = [
        CreatePlanTool(state_store, run_id),
        GetPlanTool(state_store, run_id),
        UpdatePlanStepTool(state_store, run_id),
        RevisePlanTool(state_store, run_id),
        DeletePlanTool(state_store, run_id),
        ListPlansTool(state_store, run_id),
    ]
    if "create_test" in (include_test_tools or set()):
        tools.append(CreateTestTool(workspace_root, sandbox))
    if "run_test" in (include_test_tools or set()):
        tools.append(RunTestTool(state_store, run_id, sandbox, workspace_root, artifact_version))
    return tools
