"""Guarded Coding Harness for smolagents ToolCallingAgent.

Public API surface for the harness package.  All user-facing symbols are
re-exported here so consumers can write::

    from harness import GuardedHarness, HarnessConfig
"""

from __future__ import annotations

# ── Enums ────────────────────────────────────────────────────────────
from .models import (
    ApprovalStatus,
    AuditEventType,
    EvidenceKind,
    EvidenceStatus,
    RunStatus,
    StepStatus,
    StopReason,
    ToolCapability,
)

# ── Data classes ─────────────────────────────────────────────────────
from .models import (
    AcceptanceCheck,
    ApprovalRequest,
    AuditEvent,
    BudgetInfo,
    Checkpoint,
    CommandPolicy,
    CommandResult,
    Evidence,
    GateDecision,
    HarnessConfig,
    HarnessRunResult,
    PendingToolBatch,
    Plan,
    PlanStep,
    RunState,
    SandboxConfig,
    SandboxViolation,
    StepRecord,
    ToolCallFingerprint,
    ToolPolicy,
)

# ── Error hierarchy ──────────────────────────────────────────────────
from .models import (
    HarnessError,
    ApprovalAlreadyDecidedError,
    ApprovalNotFoundError,
    CheckpointRecoveryError,
    ConfigurationError,
    PlanRevisionLimitError,
    RunAlreadyActiveError,
    SandboxViolationError,
    UnauthorizedApproverError,
    WorkspaceChangedError,
)

# ── Configuration loading & validation ───────────────────────────────
from .config import load_and_validate_toml, validate_config

# ── Core services ────────────────────────────────────────────────────
from .audit import AuditLogger
from .checkpoint import CheckpointManager
from .gate import Gate
from .state_store import StateStore
from .approval import ApprovalWorkflow

# ── Harness (main entry point) ──────────────────────────────────────
from .harness import GuardedHarness, HarnessRunner

__all__ = [
    # Assembly
    "GuardedHarness",
    "HarnessRunner",
    # Configuration helpers
    "load_and_validate_toml",
    "validate_config",
    # Enums
    "ApprovalStatus",
    "AuditEventType",
    "EvidenceKind",
    "EvidenceStatus",
    "RunStatus",
    "StepStatus",
    "StopReason",
    "ToolCapability",
    # Data classes
    "AcceptanceCheck",
    "ApprovalRequest",
    "AuditEvent",
    "BudgetInfo",
    "Checkpoint",
    "CommandPolicy",
    "CommandResult",
    "Evidence",
    "GateDecision",
    "HarnessConfig",
    "HarnessRunResult",
    "PendingToolBatch",
    "Plan",
    "PlanStep",
    "RunState",
    "SandboxConfig",
    "SandboxViolation",
    "StepRecord",
    "ToolCallFingerprint",
    "ToolPolicy",
    # Errors
    "HarnessError",
    "ApprovalAlreadyDecidedError",
    "ApprovalNotFoundError",
    "CheckpointRecoveryError",
    "ConfigurationError",
    "PlanRevisionLimitError",
    "RunAlreadyActiveError",
    "SandboxViolationError",
    "UnauthorizedApproverError",
    "WorkspaceChangedError",
    # Services
    "ApprovalWorkflow",
    "AuditLogger",
    "CheckpointManager",
    "Gate",
    "StateStore",
]
