"""ApprovalWorkflow — LangGraph-based human approval for write operations.

Uses LangGraph StateGraph with interrupt/resume to manage the approval
lifecycle. The graph contains only approval-request and decision-receive
nodes — no side effects are performed inside graph nodes.

Per PRD §2.1.5.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt
from typing_extensions import TypedDict

from .models import (
    ApprovalAlreadyDecidedError,
    ApprovalNotFoundError,
    ApprovalRequest,
    ApprovalStatus,
    UnauthorizedApproverError,
)


# ──────────────────────────────────────────────
# Graph state
# ──────────────────────────────────────────────


class ApprovalGraphState(TypedDict):
    """State carried through the LangGraph approval sub-graph."""

    approval_id: str
    run_id: str
    graph_thread_id: str
    approval_view: dict  # Sanitised display data for the approver
    decision: Literal["APPROVE", "REJECT"] | None
    decided_by: str | None
    decision_reason: str | None


# ──────────────────────────────────────────────
# Graph nodes (pure, no side-effects)
# ──────────────────────────────────────────────


def _request_node(state: ApprovalGraphState) -> dict:
    """Emit the approval request and suspend execution via ``interrupt()``.

    The interrupt payload is the approval view (sanitised tool info).
    When the graph is resumed with a ``Command(resume=...)``, the
    resume value is returned from ``interrupt()``.
    """
    resume_value = interrupt(state["approval_view"])
    # resume_value is expected to be a dict with decision, approver, reason
    if isinstance(resume_value, dict):
        return {
            "decision": resume_value.get("decision"),
            "decided_by": resume_value.get("approver"),
            "decision_reason": resume_value.get("reason"),
        }
    return {
        "decision": resume_value,
        "decided_by": None,
        "decision_reason": None,
    }


def _receive_node(state: ApprovalGraphState) -> dict:
    """Receive and record the decision. No side-effects."""
    # The state is already updated by the request_node return value.
    # This node just passes through to END.
    return {}


# ──────────────────────────────────────────────
# ApprovalWorkflow
# ──────────────────────────────────────────────


class ApprovalWorkflow:
    """Manages human-approval requests via LangGraph interrupt/resume.

    Parameters
    ----------
    checkpointer : object
        A LangGraph BaseCheckpointSaver instance (e.g. MemorySaver for
        testing, SqliteSaver for production).
    """

    def __init__(self, checkpointer: Any | None = None) -> None:
        if checkpointer is None:
            from langgraph.checkpoint.memory import MemorySaver

            checkpointer = MemorySaver()

        self._checkpointer = checkpointer

        # Build the approval sub-graph
        builder = StateGraph(ApprovalGraphState)
        builder.add_node("request", _request_node)
        builder.add_node("receive", _receive_node)
        builder.add_edge(START, "request")
        builder.add_edge("request", "receive")
        builder.add_edge("receive", END)

        self._graph = builder.compile(checkpointer=checkpointer)

        # In-memory index: approval_id → {thread_id, state}
        self._index: dict[str, dict[str, Any]] = {}

    # ── Public API ──────────────────────────────────

    def request(self, approval: ApprovalRequest) -> ApprovalRequest:
        """Run the graph to the interrupt point and return the approval.

        Idempotent: if the approval_id is already registered, returns the
        existing request without re-interrupting.
        """
        if approval.approval_id in self._index:
            return approval

        # Build a sanitised view for the approver
        approval_view = {
            "approval_id": approval.approval_id,
            "tool_name": approval.tool_name,
            "tool_call_id": approval.tool_call_id,
            "arguments_summary": _sanitize_for_display(approval.arguments),
            "risk_level": approval.risk_level,
            "workspace_fingerprint": approval.workspace_fingerprint,
        }

        initial_state: ApprovalGraphState = {
            "approval_id": approval.approval_id,
            "run_id": approval.approval_id,  # unused by graph
            "graph_thread_id": approval.graph_thread_id,
            "approval_view": approval_view,
            "decision": None,
            "decided_by": None,
            "decision_reason": None,
        }

        config = {"configurable": {"thread_id": approval.graph_thread_id}}

        self._graph.invoke(initial_state, config)

        self._index[approval.approval_id] = {
            "thread_id": approval.graph_thread_id,
            "approval": approval,
        }

        return approval

    def resume(
        self,
        approval_id: str,
        *,
        decision: Literal["APPROVE", "REJECT"],
        approver: str,
        reason: str | None = None,
    ) -> ApprovalRequest:
        """Resume the approval graph with a decision.

        Idempotent for the same decision; raises on conflicting decisions.
        """
        entry = self._index.get(approval_id)
        if entry is None:
            raise ApprovalNotFoundError(f"Approval not found: {approval_id}")

        approval = entry["approval"]

        # Idempotency / conflict check
        if approval.status == ApprovalStatus.APPROVED and decision == "APPROVE":
            return approval
        if approval.status == ApprovalStatus.REJECTED and decision == "REJECT":
            return approval
        if approval.status != ApprovalStatus.PENDING:
            raise ApprovalAlreadyDecidedError(
                f"Approval {approval_id} already decided as {approval.status.value}, "
                f"cannot apply {decision}"
            )

        config = {"configurable": {"thread_id": approval.graph_thread_id}}

        resume_value = {
            "decision": decision,
            "approver": approver,
            "reason": reason,
        }

        self._graph.invoke(Command(resume=resume_value), config)

        # Update approval state
        if decision == "APPROVE":
            approval.status = ApprovalStatus.APPROVED
        else:
            approval.status = ApprovalStatus.REJECTED
        approval.decided_by = approver
        approval.decided_at = datetime.now()
        approval.decision_reason = reason

        return approval

    def invalidate(self, approval_id: str, *, reason: str) -> None:
        """Invalidate a PENDING approval.

        After invalidation, any resume attempt will reject.
        """
        entry = self._index.get(approval_id)
        if entry is None:
            raise ApprovalNotFoundError(f"Approval not found: {approval_id}")

        approval = entry["approval"]
        if approval.status != ApprovalStatus.PENDING:
            return  # Already decided — nothing to invalidate

        approval.status = ApprovalStatus.INVALIDATED
        approval.decision_reason = reason
        approval.decided_at = datetime.now()

    def get_approval(self, approval_id: str) -> ApprovalRequest | None:
        """Look up an approval by ID."""
        entry = self._index.get(approval_id)
        return entry["approval"] if entry else None


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────


def _sanitize_for_display(arguments: Any) -> dict:
    """Produce a safe summary of arguments for the approval view."""
    if not isinstance(arguments, dict):
        return {"_value": str(arguments)[:200]}
    result: dict[str, Any] = {}
    for k, v in arguments.items():
        if isinstance(v, str) and len(v) > 200:
            result[k] = v[:200] + "...[truncated]"
        else:
            result[k] = v
    return result
