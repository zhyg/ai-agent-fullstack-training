"""StateStore — persistent storage for Run, Plan, Evidence, and Approval state.

All data is stored as JSON files with atomic writes (``.tmp`` + ``os.replace``).
Plans and evidence are embedded in the Run state file.

Per PRD §2.3.
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import asdict, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from smolagents.memory import MemoryStep
from smolagents.models import ChatMessage, MessageRole

from .models import (
    AcceptanceCheck,
    ApprovalRequest,
    ApprovalStatus,
    BudgetInfo,
    Evidence,
    EvidenceKind,
    EvidenceStatus,
    Plan,
    PlanRevisionLimitError,
    PlanStep,
    PendingToolBatch,
    RunState,
    RunStatus,
    StepRecord,
    StepStatus,
    StopReason,
    ToolCallFingerprint,
)


# ──────────────────────────────────────────────
# Serialization helpers
# ──────────────────────────────────────────────


def _serialize(obj: Any) -> Any:
    """Recursively convert dataclasses / enums / datetimes to JSON-safe values."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, set):
        return sorted(obj)
    if isinstance(obj, dict):
        return {k: _serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_serialize(v) for v in obj]
    if hasattr(obj, "__dataclass_fields__"):
        return {k: _serialize(v) for k, v in asdict(obj).items()}
    return obj


def _deserialize_run_state(data: dict) -> RunState:
    """Reconstruct a RunState from a parsed JSON dict."""

    def _evidence(d: dict) -> Evidence:
        return Evidence(
            id=d["id"],
            step_id=d["step_id"],
            tool_call_id=d["tool_call_id"],
            artifact_version=d["artifact_version"],
            kind=EvidenceKind(d["kind"]),
            summary=d["summary"],
            payload=d.get("payload", {}),
            created_at=datetime.fromisoformat(d["created_at"]),
            status=EvidenceStatus(d.get("status", "valid")),
        )

    def _step(d: dict) -> PlanStep:
        return PlanStep(
            id=d["id"],
            objective=d["objective"],
            depends_on=d.get("depends_on", []),
            success_criteria=d.get("success_criteria", []),
            status=StepStatus(d.get("status", "pending")),
            evidence_ids=d.get("evidence_ids", []),
            required_evidence_kinds=[EvidenceKind(k) for k in d.get("required_evidence_kinds", [])],
            acceptance_checks=[
                AcceptanceCheck(kind=c["kind"], parameters=c["parameters"])
                for c in d.get("acceptance_checks", [])
            ],
            attempts=d.get("attempts", 0),
            last_error=d.get("last_error"),
        )

    def _plan(d: dict) -> Plan:
        return Plan(
            version=d.get("version", 1),
            goal=d.get("goal", ""),
            constraints=d.get("constraints", []),
            steps=[_step(s) for s in d.get("steps", [])],
            revision_count=d.get("revision_count", 0),
            max_revisions=d.get("max_revisions", 5),
        )

    def _approval(d: dict) -> ApprovalRequest:
        return ApprovalRequest(
            approval_id=d["approval_id"],
            graph_thread_id=d["graph_thread_id"],
            tool_call_id=d["tool_call_id"],
            tool_name=d["tool_name"],
            arguments=d.get("arguments", {}),
            arguments_hash=d.get("arguments_hash", ""),
            workspace_fingerprint=d.get("workspace_fingerprint", ""),
            risk_level=d.get("risk_level", ""),
            requested_at=datetime.fromisoformat(d["requested_at"]),
            status=ApprovalStatus(d.get("status", "PENDING")),
            decided_by=d.get("decided_by"),
            decided_at=datetime.fromisoformat(d["decided_at"]) if d.get("decided_at") else None,
            decision_reason=d.get("decision_reason"),
        )

    def _batch(d: dict) -> PendingToolBatch:
        return PendingToolBatch(
            step_number=d["step_number"],
            model_response=d.get("model_response", {}),
            tool_calls=d.get("tool_calls", []),
            next_call_index=d.get("next_call_index", 0),
            waiting_tool_call_id=d.get("waiting_tool_call_id"),
        )

    def _fp(d: dict) -> ToolCallFingerprint:
        return ToolCallFingerprint(tool_name=d["tool_name"], arguments_hash=d["arguments_hash"])

    def _record(d: dict) -> StepRecord:
        return StepRecord(
            step_number=d["step_number"],
            tool_calls=d.get("tool_calls", []),
            observations=d.get("observations"),
            error=d.get("error"),
            is_final_answer=d.get("is_final_answer", False),
            plan_step_id=d.get("plan_step_id"),
        )

    def _budget(d: dict) -> BudgetInfo:
        return BudgetInfo(
            max_tokens=d.get("max_tokens"),
            used_tokens=d.get("used_tokens", 0),
            max_wall_time=d.get("max_wall_time"),
            elapsed_time=d.get("elapsed_time", 0.0),
        )

    return RunState(
        run_id=data["run_id"],
        task=data["task"],
        status=RunStatus(data["status"]),
        stop_reason=StopReason(data["stop_reason"]) if data.get("stop_reason") else None,
        current_step=data.get("current_step", 0),
        max_steps=data.get("max_steps", 20),
        plans={pid: _plan(p) for pid, p in data.get("plans", {}).items()},
        active_plan_id=data.get("active_plan_id"),
        step_records=[_record(r) for r in data.get("step_records", [])],
        evidence_store={eid: _evidence(e) for eid, e in data.get("evidence_store", {}).items()},
        budget=_budget(data.get("budget", {})),
        pending_approvals=[_approval(a) for a in data.get("pending_approvals", [])],
        pending_tool_batches=[_batch(b) for b in data.get("pending_tool_batches", [])],
        recent_calls=[_fp(f) for f in data.get("recent_calls", [])],
        workspace_fingerprint=data.get("workspace_fingerprint", ""),
        created_at=datetime.fromisoformat(data["created_at"]),
        updated_at=datetime.fromisoformat(data["updated_at"]),
    )


# ──────────────────────────────────────────────
# StateStore
# ──────────────────────────────────────────────


class StateStore:
    """Persistent JSON-file storage for Run, Plan, Evidence, and Approval state.

    Each run is stored as a single file at
    ``{storage_path}/runs/{run_id}.json`` with atomic writes.
    """

    def __init__(self, storage_path: str | Path) -> None:
        self._runs_dir = Path(storage_path) / "runs"
        self._runs_dir.mkdir(parents=True, exist_ok=True)

    def _run_file(self, run_id: str) -> Path:
        return self._runs_dir / f"{run_id}.json"

    def _save_run(self, run: RunState) -> None:
        """Atomic write: write to .tmp then os.replace."""
        run.updated_at = datetime.now()
        data = _serialize(run)
        path = self._run_file(run.run_id)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)

    def _load_run(self, run_id: str) -> RunState | None:
        path = self._run_file(run_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return _deserialize_run_state(data)

    # ══════════════════════════════════════════
    # Run-level operations
    # ══════════════════════════════════════════

    def create_run(
        self,
        task: str,
        max_steps: int,
        budget: BudgetInfo,
        workspace_fingerprint: str,
        run_id: str | None = None,
    ) -> RunState:
        """Create a new Run."""
        rid = run_id or str(uuid.uuid4())
        run = RunState(
            run_id=rid,
            task=task,
            status=RunStatus.PENDING,
            current_step=0,
            max_steps=max_steps,
            budget=budget,
            workspace_fingerprint=workspace_fingerprint,
        )
        self._save_run(run)
        return run

    def get_run(self, run_id: str) -> RunState | None:
        return self._load_run(run_id)

    def update_run(self, run_id: str, **updates: Any) -> RunState:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        for key, value in updates.items():
            if hasattr(run, key):
                setattr(run, key, value)
        self._save_run(run)
        return run

    def list_runs(self) -> list[str]:
        return [p.stem for p in self._runs_dir.glob("*.json")]

    # ══════════════════════════════════════════
    # Plan-level operations
    # ══════════════════════════════════════════

    def create_plan(
        self,
        run_id: str,
        goal: str,
        constraints: list[str] | None = None,
        max_revisions: int = 5,
        plan_id: str | None = None,
    ) -> Plan:
        """Create a new Plan and associate it with a Run."""
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        pid = plan_id or str(uuid.uuid4())
        plan = Plan(
            goal=goal,
            constraints=constraints or [],
            max_revisions=max_revisions,
        )
        run.plans[pid] = plan
        self._save_run(run)
        return plan

    def get_plan(self, run_id: str, plan_id: str) -> Plan | None:
        run = self._load_run(run_id)
        if run is None:
            return None
        return run.plans.get(plan_id)

    def list_plans(self, run_id: str) -> list[str]:
        run = self._load_run(run_id)
        if run is None:
            return []
        return list(run.plans.keys())

    def set_active_plan(self, run_id: str, plan_id: str) -> None:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        if plan_id not in run.plans:
            raise ValueError(f"Plan not found: {plan_id}")
        run.active_plan_id = plan_id
        self._save_run(run)

    def delete_plan(self, run_id: str, plan_id: str) -> None:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        if plan_id not in run.plans:
            raise ValueError(f"Plan not found: {plan_id}")
        del run.plans[plan_id]
        if run.active_plan_id == plan_id:
            run.active_plan_id = None
        self._save_run(run)

    def revise_plan(
        self,
        run_id: str,
        plan_id: str,
        new_steps: list[PlanStep] | None = None,
        updated_steps: list[dict] | None = None,
        updated_constraints: list[str] | None = None,
    ) -> Plan:
        """Revise a Plan: add steps, update existing steps, change constraints.

        Raises PlanRevisionLimitError if revision_count >= max_revisions.
        """
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        plan = run.plans.get(plan_id)
        if plan is None:
            raise ValueError(f"Plan not found: {plan_id}")

        if plan.revision_count >= plan.max_revisions:
            raise PlanRevisionLimitError(
                f"Plan {plan_id} has reached max revisions ({plan.max_revisions})"
            )

        # Add new steps
        if new_steps:
            plan.steps.extend(new_steps)

        # Update existing steps
        if updated_steps:
            for upd in updated_steps:
                step_id = upd.get("id") or upd.get("step_id")
                for step in plan.steps:
                    if step.id == step_id:
                        for k, v in upd.items():
                            if k not in ("id", "step_id") and hasattr(step, k):
                                setattr(step, k, v)

        # Update constraints
        if updated_constraints is not None:
            plan.constraints = updated_constraints

        plan.revision_count += 1
        plan.version += 1
        self._save_run(run)
        return plan

    # ══════════════════════════════════════════
    # PlanStep-level operations
    # ══════════════════════════════════════════

    def add_plan_step(self, run_id: str, plan_id: str, step: PlanStep) -> PlanStep:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        plan = run.plans.get(plan_id)
        if plan is None:
            raise ValueError(f"Plan not found: {plan_id}")
        plan.steps.append(step)
        self._save_run(run)
        return step

    def update_plan_step(
        self, run_id: str, plan_id: str, step_id: str, **updates: Any
    ) -> PlanStep:
        """Update a PlanStep.

        Model must NOT directly set status to COMPLETED — that is handled by
        evaluate_step_acceptance via the Harness.
        """
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        plan = run.plans.get(plan_id)
        if plan is None:
            raise ValueError(f"Plan not found: {plan_id}")
        step = self._find_step(plan, step_id)
        for k, v in updates.items():
            if hasattr(step, k):
                setattr(step, k, v)
        self._save_run(run)
        return step

    def evaluate_step_acceptance(self, run_id: str, plan_id: str, step_id: str) -> bool:
        """Run acceptance checks and verify valid evidence.

        Returns True only when all required evidence kinds are present and
        dependencies are complete. Unverified acceptance checks fail closed.
        """
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        plan = run.plans.get(plan_id)
        if plan is None:
            raise ValueError(f"Plan not found: {plan_id}")
        step = self._find_step(plan, step_id)

        # Check required evidence kinds
        step_evidence = [run.evidence_store[eid] for eid in step.evidence_ids
                         if eid in run.evidence_store]
        valid_evidence = [e for e in step_evidence if e.status == EvidenceStatus.VALID]
        valid_kinds = {e.kind for e in valid_evidence}

        for req_kind in step.required_evidence_kinds:
            if req_kind not in valid_kinds:
                return False

        # Checks cannot count as passed until a verifier executes them.
        if step.acceptance_checks:
            return False

        # Both lists empty → cannot auto-complete
        if not step.required_evidence_kinds:
            return False

        if any(
            not any(s.id == dep and s.status == StepStatus.COMPLETED for s in plan.steps)
            for dep in step.depends_on
        ):
            return False
        return True

    def get_next_executable_steps(self, run_id: str, plan_id: str) -> list[PlanStep]:
        """Return PENDING steps whose dependencies are all COMPLETED."""
        run = self._load_run(run_id)
        if run is None:
            return []
        plan = run.plans.get(plan_id)
        if plan is None:
            return []

        step_map = {s.id: s for s in plan.steps}
        executable: list[PlanStep] = []

        for step in plan.steps:
            if step.status != StepStatus.PENDING:
                continue
            # Check dependencies
            deps_met = True
            for dep_id in step.depends_on:
                dep = step_map.get(dep_id)
                if dep is None or dep.status != StepStatus.COMPLETED:
                    deps_met = False
                    break
            if deps_met:
                executable.append(step)

        return executable

    # ══════════════════════════════════════════
    # Evidence-level operations
    # ══════════════════════════════════════════

    def add_evidence(self, run_id: str, evidence: Evidence) -> Evidence:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        run.evidence_store[evidence.id] = evidence
        # Update the step's evidence_ids
        for plan in run.plans.values():
            for step in plan.steps:
                if step.id == evidence.step_id:
                    if evidence.id not in step.evidence_ids:
                        step.evidence_ids.append(evidence.id)
        self._save_run(run)
        return evidence

    def get_evidence(self, run_id: str, evidence_id: str) -> Evidence | None:
        run = self._load_run(run_id)
        if run is None:
            return None
        return run.evidence_store.get(evidence_id)

    def get_step_evidence(self, run_id: str, step_id: str) -> list[Evidence]:
        run = self._load_run(run_id)
        if run is None:
            return []
        return [e for e in run.evidence_store.values() if e.step_id == step_id]

    def invalidate_stale_evidence(
        self,
        run_id: str,
        current_artifact_version: str,
        step_id: str | None = None,
    ) -> list[str]:
        """Mark TEST/DIFF evidence with mismatched artifact_version as STALE.

        If stale evidence is in a COMPLETED step's required_evidence_kinds,
        rollback that step to IN_PROGRESS.
        """
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")

        stale_ids: list[str] = []

        for eid, evidence in run.evidence_store.items():
            if evidence.status == EvidenceStatus.STALE:
                continue
            if evidence.kind not in (EvidenceKind.TEST, EvidenceKind.DIFF):
                continue
            if step_id is not None and evidence.step_id != step_id:
                continue
            if evidence.artifact_version != current_artifact_version:
                evidence.status = EvidenceStatus.STALE
                stale_ids.append(eid)

        # Rollback COMPLETED steps whose required evidence is stale
        if stale_ids:
            for plan in run.plans.values():
                for step in plan.steps:
                    if step.status != StepStatus.COMPLETED:
                        continue
                    required = set(step.required_evidence_kinds)
                    if not required:
                        continue
                    step_evidence = [
                        run.evidence_store[eid]
                        for eid in step.evidence_ids
                        if eid in run.evidence_store
                    ]
                    valid_kinds = {
                        e.kind for e in step_evidence
                        if e.status == EvidenceStatus.VALID
                    }
                    if not required.issubset(valid_kinds):
                        step.status = StepStatus.IN_PROGRESS

        self._save_run(run)
        return stale_ids

    # ══════════════════════════════════════════
    # StepRecord operations
    # ══════════════════════════════════════════

    def add_step_record(self, run_id: str, record: StepRecord) -> None:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        run.step_records.append(record)
        self._save_run(run)

    # ══════════════════════════════════════════
    # Approval operations
    # ══════════════════════════════════════════

    def add_approval(self, run_id: str, approval: ApprovalRequest) -> None:
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        run.pending_approvals.append(approval)
        self._save_run(run)

    def get_approval(self, run_id: str, approval_id: str) -> ApprovalRequest | None:
        run = self._load_run(run_id)
        if run is None:
            return None
        for a in run.pending_approvals:
            if a.approval_id == approval_id:
                return a
        return None

    def resolve_approval(
        self,
        run_id: str,
        approval_id: str,
        *,
        status: ApprovalStatus,
        decided_by: str,
        decision_reason: str | None = None,
    ) -> None:
        """Resolve an approval: PENDING → APPROVED/REJECTED.

        Idempotent for same decision; raises on conflicting decision.
        """
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        approval = None
        for a in run.pending_approvals:
            if a.approval_id == approval_id:
                approval = a
                break
        if approval is None:
            raise ValueError(f"Approval not found: {approval_id}")

        if approval.status == status:
            return  # Idempotent
        if approval.status != ApprovalStatus.PENDING:
            raise ValueError(
                f"Approval {approval_id} already decided as {approval.status.value}, "
                f"cannot change to {status.value}"
            )

        approval.status = status
        approval.decided_by = decided_by
        approval.decided_at = datetime.now()
        approval.decision_reason = decision_reason
        self._save_run(run)

    def invalidate_pending_approvals(self, run_id: str, *, reason: str) -> list[str]:
        """Invalidate all PENDING approvals and return their IDs."""
        run = self._load_run(run_id)
        if run is None:
            raise ValueError(f"Run not found: {run_id}")
        invalidated: list[str] = []
        for a in run.pending_approvals:
            if a.status == ApprovalStatus.PENDING:
                a.status = ApprovalStatus.INVALIDATED
                a.decision_reason = reason
                a.decided_at = datetime.now()
                invalidated.append(a.approval_id)
        self._save_run(run)
        return invalidated

    # ══════════════════════════════════════════
    # Internal helpers
    # ══════════════════════════════════════════

    @staticmethod
    def _find_step(plan: Plan, step_id: str) -> PlanStep:
        for step in plan.steps:
            if step.id == step_id:
                return step
        raise ValueError(f"PlanStep not found: {step_id}")


# ──────────────────────────────────────────────
# PlanContextStep (PRD §2.3.5)
# ──────────────────────────────────────────────


class PlanContextStep(MemoryStep):
    """Custom MemoryStep that injects Plan status into the model context.

    HarnessRunner appends this after each ActionStep so the model always
    sees the latest Plan state.
    """

    def __init__(self, plan_summary: str) -> None:
        self.plan_summary = plan_summary

    def to_messages(self, summary_mode: bool = False) -> list[ChatMessage]:
        if summary_mode:
            return []
        return [
            ChatMessage(
                role=MessageRole.USER,
                content=[{"type": "text", "text": self.plan_summary}],
            )
        ]

    def dict(self) -> dict[str, Any]:
        return {"plan_summary": self.plan_summary}


def prepare_plan_context(run_id: str, state_store: StateStore) -> str:
    """Generate a human-readable Plan status summary from StateStore."""
    run = state_store.get_run(run_id)
    if run is None or not run.plans:
        return "=== 当前无活跃计划 ==="

    lines: list[str] = ["=== 当前计划状态 ==="]

    for pid, plan in run.plans.items():
        active_marker = " [ACTIVE]" if pid == run.active_plan_id else ""
        lines.append(
            f"Plan: {pid}{active_marker} (v{plan.version}, "
            f"已修订 {plan.revision_count} 次, 最多 {plan.max_revisions} 次)"
        )
        lines.append(f"目标: {plan.goal}")
        if plan.constraints:
            lines.append(f"约束: {', '.join(plan.constraints)}")
        lines.append("")
        lines.append("Steps:")

        for step in plan.steps:
            evidence_count = len(step.evidence_ids)
            dep_str = f" (依赖: {', '.join(step.depends_on)})" if step.depends_on else ""
            lines.append(
                f"  [{step.status.value}] {step.id}: {step.objective}{dep_str} "
                f"(证据: {evidence_count} 条)"
            )

        # Executable steps
        executable = state_store.get_next_executable_steps(run_id, pid)
        if executable:
            lines.append("")
            next_ids = ", ".join(s.id for s in executable)
            lines.append(f"下一步可执行: {next_ids}")

    return "\n".join(lines)
