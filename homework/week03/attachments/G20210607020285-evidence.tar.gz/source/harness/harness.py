"""HarnessRunner — step-by-step agent execution loop with gating, budget, and acceptance.

The HarnessRunner manages the agent's main loop:
1. Generate model response
2. Budget check (pre-model, post-model, pre-tool)
3. Process tool calls sequentially through Gate → Sandbox → Audit
4. Handle final_answer with completion acceptance
5. Save checkpoint after each step

Per PRD §2.6.
"""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime
from typing import Any

from smolagents.memory import ActionStep, MemoryStep
from smolagents.default_tools import FinalAnswerTool
from smolagents.models import (
    ChatMessage,
    ChatMessageToolCall,
    ChatMessageToolCallFunction,
    MessageRole,
    parse_json_if_needed,
)
from smolagents.monitoring import Timing
from smolagents.tools import Tool

from .audit import AuditLogger
from .checkpoint import CheckpointManager
from .gate import Gate, _hash_arguments
from .models import (
    AuditEvent,
    AuditEventType,
    ApprovalStatus,
    BudgetInfo,
    EvidenceKind,
    EvidenceStatus,
    GateDecision,
    HarnessConfig,
    HarnessRunResult,
    RunState,
    RunStatus,
    StopReason,
    StepStatus,
    ToolCallFingerprint,
    ToolCapability,
    ToolPolicy,
)
from .plan_tools import create_plan_tools
from .sandbox import Sandbox
from .state_store import PlanContextStep, StateStore, prepare_plan_context


class HarnessRunner:
    """Manages the agent's step-by-step execution loop.

    Each step:
    1. Budget check (pre-model)
    2. Generate model response
    3. Budget check (post-model)
    4. Process tool calls sequentially: Gate → execute → audit
    5. Handle final_answer with acceptance checks
    6. Append ActionStep + PlanContextStep to memory
    7. Save checkpoint

    Parameters
    ----------
    model : Model
        The LLM model (or FakeModel for testing).
    tools : list[Tool]
        Registered tools available to the agent.
    config : HarnessConfig
        Harness configuration.
    gate : Gate | None
        Gate module (created from config if None).
    sandbox : Sandbox | None
        Sandbox module (created from config if None).
    state_store : StateStore | None
        State store (created from config if None).
    audit : AuditLogger | None
        Audit logger (created from config if None).
    """

    def __init__(
        self,
        model: Any,
        tools: list[Tool],
        config: HarnessConfig,
        *,
        gate: Gate | None = None,
        sandbox: Sandbox | None = None,
        state_store: StateStore | None = None,
        audit: AuditLogger | None = None,
        checkpoint_manager: Any | None = None,
        approval_workflow: Any | None = None,
    ) -> None:
        self._model = model
        self._config = config
        self._tools: dict[str, Tool] = {}
        self._memory_steps: list[MemoryStep] = []
        self._run_state: RunState | None = None
        self._checkpoint_manager = checkpoint_manager
        self._approval_workflow = approval_workflow
        self._start_time: float = 0.0

        # Register tools
        for tool in tools:
            self._tools[tool.name] = tool
        self._provided_tool_names = set(self._tools)
        self._tools["final_answer"] = FinalAnswerTool()

        # Initialize modules
        self._audit = audit or AuditLogger(config.storage_path)
        self._state_store = state_store or StateStore(config.storage_path)
        self._sandbox = sandbox or Sandbox(config=config.sandbox_config, audit=self._audit)

        # Build tool policies from config
        tool_policies = dict(config.tool_policies)

        self._gate = gate or Gate(
            tool_policies=tool_policies,
            approval_mode=config.approval_mode,
            repeat_threshold=config.repeat_threshold,
            audit_logger=self._audit,
            run_id="",  # Set during run()
        )

    # ══════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════

    def run(
        self,
        task: str,
        *,
        reset: bool = True,
        resume_run_id: str | None = None,
    ) -> HarnessRunResult:
        """Execute the agent loop for the given task.

        Parameters
        ----------
        task : str
            The task description.
        reset : bool
            If True, create a new run. If False, resume an existing run.
        resume_run_id : str | None
            The run_id to resume (required when reset=False).
        """
        self._start_time = time.monotonic()

        # Flag: skip the main loop if resume detected a blocking issue
        _skip_loop = False

        if reset and resume_run_id is None:
            # New run
            self._run_state = self._state_store.create_run(
                task=task,
                max_steps=self._config.max_steps,
                budget=BudgetInfo(
                    max_tokens=self._config.max_tokens,
                    max_wall_time=self._config.max_wall_time,
                ),
                workspace_fingerprint=self._compute_workspace_fingerprint(),
            )
            self._gate._run_id = self._run_state.run_id
            self._gate.reset_for_run()
            self._memory_steps = []
            self._audit.log(AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.RUN_STARTED,
                run_id=self._run_state.run_id,
                actor="system",
                detail=f"Run started: {task}",
            ))
        elif not reset and resume_run_id is not None:
            # Resume
            self._run_state = self._state_store.get_run(resume_run_id)
            if self._run_state is None:
                raise ValueError(f"Run not found for resume: {resume_run_id}")
            self._gate._run_id = resume_run_id

            # C4: Check workspace change on resume
            if self._checkpoint_manager is not None:
                latest_cp = self._checkpoint_manager.load_latest(resume_run_id)
                if latest_cp is not None:
                    current_fp = self._compute_workspace_fingerprint()
                    if not self._checkpoint_manager.validate_workspace(
                        latest_cp, current_fp
                    ):
                        # Workspace changed — invalidate evidence and approvals
                        self._state_store.invalidate_stale_evidence(
                            resume_run_id, current_fp
                        )
                        self._state_store.invalidate_pending_approvals(
                            resume_run_id,
                            reason="Workspace fingerprint mismatch on resume",
                        )
                        # Rollback completed steps whose evidence is stale
                        self._state_store.update_run(
                            resume_run_id,
                            status=RunStatus.FAILED,
                            stop_reason=StopReason.WORKSPACE_CHANGED,
                            workspace_fingerprint=current_fp,
                        )
                        self._audit.log(AuditEvent(
                            event_id=str(uuid.uuid4()),
                            event_type=AuditEventType.WORKSPACE_CHANGE_RESOLVED,
                            run_id=resume_run_id,
                            actor="system",
                            detail="Workspace fingerprint mismatch detected on resume",
                        ))
                        # Build result and return
                        self._run_state = self._state_store.get_run(resume_run_id)
                        _skip_loop = True
                    else:
                        self._memory_steps = self._checkpoint_manager.restore_memory_steps(latest_cp.memory_steps)

            # C2: Check unknown results on resume
            if not _skip_loop:
                unknown_tc_ids = self.detect_unknown_results(resume_run_id)
                if unknown_tc_ids:
                    self._state_store.update_run(
                        resume_run_id,
                        status=RunStatus.UNKNOWN_RESULT,
                    )
                    self._audit.log(AuditEvent(
                        event_id=str(uuid.uuid4()),
                        event_type=AuditEventType.UNKNOWN_RESULT_RESOLVED,
                        run_id=resume_run_id,
                        actor="system",
                        detail=f"Detected {len(unknown_tc_ids)} unknown results on resume: {unknown_tc_ids}",
                    ))
                    # Build result — run stays UNKNOWN_RESULT
                    self._run_state = self._state_store.get_run(resume_run_id)
                    _skip_loop = True
            if not _skip_loop and self._run_state.pending_tool_batches:
                batch = self._run_state.pending_tool_batches[0]
                matching = [
                    a for a in self._run_state.pending_approvals
                    if a.tool_call_id == batch.waiting_tool_call_id
                ]
                if len(matching) != 1:
                    raise ValueError("Pending tool call does not have exactly one approval")
                if matching[0].status == ApprovalStatus.PENDING:
                    _skip_loop = True
        else:
            raise ValueError(
                "Invalid argument combination: reset=True requires no resume_run_id; "
                "reset=False requires resume_run_id"
            )

        # Inject Plan tools
        test_tools = set()
        for name, capability in (("create_test", ToolCapability.WRITE), ("run_test", ToolCapability.EXECUTE)):
            policy = self._config.tool_policies.get(name)
            if policy and name not in self._provided_tool_names:
                if capability not in policy.capabilities or not policy.controlled:
                    raise ValueError(f"Built-in {name} requires a controlled {capability.value} policy")
                test_tools.add(name)
        plan_tools = create_plan_tools(
            self._state_store,
            self._run_state.run_id,
            self._config.workspace_root,
            self._sandbox,
            self._compute_workspace_fingerprint,
            include_test_tools=test_tools,
        ) if self._config.enable_plan_tools else []
        for pt in plan_tools:
            if pt.name not in self._provided_tool_names:
                self._tools[pt.name] = pt

        # Register tool policies for plan tools if not already present
        for pt in plan_tools:
            if pt.name not in self._gate._tool_policies:
                self._gate._tool_policies[pt.name] = ToolPolicy(
                    tool_name=pt.name,
                    capabilities=set(),
                    controlled=False,
                    requires_approval=False,
                )

        # Update run status (only if not skipping loop)
        if not _skip_loop:
            self._state_store.update_run(self._run_state.run_id, status=RunStatus.RUNNING)

        # Main loop
        if not _skip_loop:
            try:
                self._run_loop(task)
            except Exception as e:
                self._state_store.update_run(
                    self._run_state.run_id,
                    status=RunStatus.FAILED,
                    stop_reason=StopReason.FATAL_ERROR,
                )
                self._audit.log(AuditEvent(
                    event_id=str(uuid.uuid4()),
                    event_type=AuditEventType.RUN_FAILED,
                    run_id=self._run_state.run_id,
                    actor="system",
                    detail=str(e),
                ))

        # Build result
        self._run_state = self._state_store.get_run(self._run_state.run_id)
        final_answer = self._extract_final_answer()

        self._audit.log(AuditEvent(
            event_id=str(uuid.uuid4()),
            event_type=AuditEventType.RUN_COMPLETED,
            run_id=self._run_state.run_id,
            actor="system",
            detail=f"Run completed: status={self._run_state.status.value}",
        ))

        return HarnessRunResult(
            state=self._run_state.status,
            stop_reason=self._run_state.stop_reason,
            run_state=self._run_state,
            final_answer=final_answer,
        )

    # ══════════════════════════════════════════
    # Main loop
    # ══════════════════════════════════════════

    def _run_loop(self, task: str) -> None:
        """Execute the step-by-step agent loop."""
        run = self._run_state

        while True:
            # ── Pre-model budget check ──
            budget_status = self._check_budget_pre_model()
            if budget_status is not None:
                return  # Budget exceeded, loop exits

            run = self._state_store.get_run(run.run_id)
            batch = run.pending_tool_batches[0] if run.pending_tool_batches else None
            if batch:
                tool_calls = [
                    ChatMessageToolCall(
                        id=tc["id"], type="function",
                        function=ChatMessageToolCallFunction(name=tc["name"], arguments=tc["arguments"]),
                    )
                    for tc in batch.tool_calls
                ]
                model_text = batch.model_response.get("text")
                observations_parts = list(batch.model_response.get("observations", []))
                start_index = batch.next_call_index
            else:
                messages = self._build_messages(task)
                try:
                    response = self._model.generate(
                        messages,
                        tools_to_call_from=list(self._tools.values()),
                    )
                except Exception as e:
                    self._state_store.update_run(
                        run.run_id, status=RunStatus.FAILED, stop_reason=StopReason.FATAL_ERROR
                    )
                    self._audit.log(AuditEvent(
                        event_id=str(uuid.uuid4()), event_type=AuditEventType.RUN_FAILED,
                        run_id=run.run_id, actor="system", detail=f"Model generation failed: {e}",
                    ))
                    return

                if response.token_usage:
                    run = self._state_store.update_run(
                        run.run_id,
                        budget=BudgetInfo(
                            max_tokens=run.budget.max_tokens,
                            used_tokens=run.budget.used_tokens + response.token_usage.output_tokens,
                            max_wall_time=run.budget.max_wall_time,
                            elapsed_time=time.monotonic() - self._start_time,
                        ),
                    )
                budget_status = self._check_budget_post_model()
                if budget_status is not None:
                    return
                tool_calls = response.tool_calls or []
                seen_call_ids: set[str] = set()
                for call in tool_calls:
                    call.id = call.id or str(uuid.uuid4())
                    if call.id in seen_call_ids:
                        raise ValueError(f"Duplicate tool call ID in model response: {call.id}")
                    seen_call_ids.add(call.id)
                model_text = self._extract_text(response)
                observations_parts = []
                start_index = 0

            is_final = False
            final_answer_text = None
            from smolagents.memory import ToolCall as SmolagentsToolCall
            recorded_calls = [
                SmolagentsToolCall(
                    name=tc.function.name,
                    arguments=parse_json_if_needed(tc.function.arguments),
                    id=tc.id,
                )
                for tc in tool_calls[:start_index]
            ]

            for index in range(start_index, len(tool_calls)):
                tc = tool_calls[index]
                tool_name = tc.function.name
                arguments = parse_json_if_needed(tc.function.arguments)
                if not isinstance(arguments, dict):
                    arguments = {}
                tc_id = tc.id or str(uuid.uuid4())
                recorded_calls.append(SmolagentsToolCall(name=tool_name, arguments=arguments, id=tc_id))

                # ── Budget check pre-tool ──
                if self._check_budget_pre_tool():
                    return

                if batch and index == start_index:
                    approval = next(
                        (a for a in run.pending_approvals if a.tool_call_id == batch.waiting_tool_call_id), None
                    )
                    if (
                        approval is None or approval.tool_call_id != tc_id or approval.tool_name != tool_name
                        or approval.arguments_hash != _hash_arguments(arguments)
                        or approval.arguments_hash != _hash_arguments(approval.arguments)
                        or approval.workspace_fingerprint != self._compute_workspace_fingerprint()
                    ):
                        raise ValueError("Pending tool call no longer matches its approval or workspace")
                    if approval.status == ApprovalStatus.REJECTED:
                        observations_parts.append(f"Tool {tool_name} rejected by user")
                        continue
                    if approval.status != ApprovalStatus.APPROVED:
                        raise ValueError(f"Approval is not resolved: {approval.status.value}")
                    if any(
                        event.tool_call_id == tc_id
                        for event_type in (AuditEventType.TOOL_EXECUTED, AuditEventType.TOOL_ERROR)
                        for event in self._audit.query(run_id=run.run_id, event_type=event_type)
                    ):
                        raise ValueError(f"Approved tool call has already been attempted: {tc_id}")
                    self._gate.add_approved_tool_call(tc_id)

                # ── Gate check ──
                tool = self._tools.get(tool_name)

                # Special handling for final_answer (built-in tool)
                if tool_name == "final_answer":
                    is_final = True
                    final_answer_text = str(arguments.get("answer", ""))
                    # Acceptance check
                    accepted, rejection_reason = self._check_acceptance(final_answer_text)
                    if not accepted:
                        observations_parts.append(
                            f"final_answer REJECTED: {rejection_reason}"
                        )
                        self._audit.log(AuditEvent(
                            event_id=str(uuid.uuid4()),
                            event_type=AuditEventType.FINAL_ANSWER_REJECTED,
                            run_id=run.run_id,
                            tool_call_id=tc_id,
                            actor="system",
                            detail=rejection_reason,
                        ))
                        is_final = False
                        continue
                    else:
                        observations_parts.append(f"final_answer ACCEPTED: {final_answer_text}")
                        break

                if tool is None:
                    observations_parts.append(f"Error: unknown tool '{tool_name}'")
                    continue

                # Build a ToolCall-like object for Gate
                gate_tc = SmolagentsToolCall(name=tool_name, arguments=arguments, id=tc_id)
                decision = self._gate.check(gate_tc, tool)

                if decision.decision == "DENY":
                    observations_parts.append(f"Gate DENIED: {decision.reason}")
                    continue

                if decision.decision == "WAITING_APPROVAL":
                    # Save approval request + pending batch + checkpoint
                    if self._approval_workflow is not None:
                        approval_id = str(uuid.uuid4())
                        thread_id = f"approval-{approval_id}"
                        from .models import ApprovalRequest as ApprovalReq

                        approval_req = ApprovalReq(
                            approval_id=approval_id,
                            graph_thread_id=thread_id,
                            tool_call_id=tc_id,
                            tool_name=tool_name,
                            arguments=arguments,
                            arguments_hash=_hash_arguments(arguments),
                            workspace_fingerprint=self._compute_workspace_fingerprint(),
                            risk_level="high" if (
                                ToolCapability.WRITE in (self._gate._tool_policies.get(tool_name, ToolPolicy(tool_name="", capabilities=set(), controlled=False, requires_approval=False)).capabilities)
                                or ToolCapability.EXECUTE in (self._gate._tool_policies.get(tool_name, ToolPolicy(tool_name="", capabilities=set(), controlled=False, requires_approval=False)).capabilities)
                            ) else "low",
                            requested_at=datetime.now(),
                            status=ApprovalStatus.PENDING,
                        )

                        # Save to StateStore
                        self._state_store.add_approval(run.run_id, approval_req)

                        # Save pending tool batch
                        from .models import PendingToolBatch
                        batch = PendingToolBatch(
                            step_number=run.current_step + 1,
                            model_response={"text": model_text or "", "observations": observations_parts},
                            tool_calls=[
                                {"id": call.id, "name": call.function.name, "arguments": call.function.arguments}
                                for call in tool_calls
                            ],
                            next_call_index=index,
                            waiting_tool_call_id=tc_id,
                        )
                        self._state_store.update_run(
                            run.run_id,
                            pending_tool_batches=[batch],
                            status=RunStatus.WAITING_APPROVAL,
                        )

                        # Trigger approval workflow
                        self._approval_workflow.request(approval_req)

                        # Audit
                        self._audit.log(AuditEvent(
                            event_id=str(uuid.uuid4()),
                            event_type=AuditEventType.APPROVAL_REQUESTED,
                            run_id=run.run_id,
                            tool_call_id=tc_id,
                            actor="system",
                            detail=f"Approval requested for {tool_name}: {approval_id}",
                        ))

                        # Save checkpoint
                        if self._checkpoint_manager is not None:
                            self._checkpoint_manager.save(
                                run_id=run.run_id,
                                step_number=run.current_step,
                                run_state=self._state_store.get_run(run.run_id),
                                memory_steps=[s.dict() for s in self._memory_steps],
                                workspace_fingerprint=self._compute_workspace_fingerprint(),
                            )

                        # Return immediately with WAITING_APPROVAL
                        return
                    else:
                        # No approval workflow configured — treat as denied
                        observations_parts.append(
                            f"WAITING_APPROVAL for {tool_name}: {decision.reason}"
                        )
                        continue

                # ── Execute tool ──
                # Write TOOL_STARTED WAL for side-effect tools (C2)
                if tool is not None:
                    policy = self._gate._tool_policies.get(tool_name)
                    if policy and (
                        ToolCapability.WRITE in policy.capabilities
                        or ToolCapability.EXECUTE in policy.capabilities
                    ):
                        self._audit.log(AuditEvent(
                            event_id=str(uuid.uuid4()),
                            event_type=AuditEventType.TOOL_STARTED,
                            run_id=run.run_id,
                            tool_call_id=tc_id,
                            tool_name=tool_name,
                            actor="system",
                            detail=f"WAL: tool_started for {tool_name}",
                        ))

                try:
                    result = tool(**arguments)
                    observations_parts.append(
                        f"Tool {tool_name}({arguments}): {result}"
                    )
                    self._gate.mark_executed(tc_id, tool_name)
                    # Invalidate stale evidence after workspace-modifying tools (H2)
                    if tool is not None:
                        policy = self._gate._tool_policies.get(tool_name)
                        if policy and ToolCapability.WRITE in policy.capabilities:
                            self.invalidate_evidence_after_workspace_change(
                                str(uuid.uuid4())[:8]
                            )
                    self._complete_accepted_plan_steps(run.run_id)
                except Exception as e:
                    observations_parts.append(
                        f"Tool {tool_name} ERROR: {e}"
                    )
                    self._audit.log(AuditEvent(
                        event_id=str(uuid.uuid4()),
                        event_type=AuditEventType.TOOL_ERROR,
                        run_id=run.run_id,
                        tool_call_id=tc_id,
                        tool_name=tool_name,
                        actor="system",
                        detail=str(e),
                    ))

            # ── Build ActionStep ──
            run = self._state_store.get_run(run.run_id)
            step_number = run.current_step + 1
            self._state_store.update_run(run.run_id, current_step=step_number, pending_tool_batches=[])

            action_step = ActionStep(
                step_number=step_number,
                timing=Timing(start_time=0.0, end_time=0.0),
                model_output=model_text,
                tool_calls=recorded_calls or None,
                observations="\n".join(observations_parts),
                is_final_answer=is_final,
                action_output=final_answer_text if is_final else None,
            )
            self._memory_steps.append(action_step)

            # ── Append PlanContextStep ──
            plan_context = prepare_plan_context(run.run_id, self._state_store)
            self._memory_steps.append(PlanContextStep(plan_summary=plan_context))

            # ── Save checkpoint ──
            if self._checkpoint_manager is not None:
                self._checkpoint_manager.save(
                    run_id=run.run_id,
                    step_number=step_number,
                    run_state=self._state_store.get_run(run.run_id),
                    memory_steps=[s.dict() for s in self._memory_steps],
                    workspace_fingerprint=self._compute_workspace_fingerprint(),
                )

            # ── Handle final answer ──
            if is_final:
                self._state_store.update_run(
                    run.run_id,
                    status=RunStatus.COMPLETED,
                    stop_reason=StopReason.FINAL_ANSWER,
                )
                self._audit.log(AuditEvent(
                    event_id=str(uuid.uuid4()),
                    event_type=AuditEventType.FINAL_ANSWER_ACCEPTED,
                    run_id=run.run_id,
                    actor="system",
                    detail=final_answer_text or "",
                ))
                return

            # ── Max steps check ──
            run = self._state_store.get_run(run.run_id)
            if run.current_step >= run.max_steps:
                self._state_store.update_run(
                    run.run_id,
                    status=RunStatus.MAX_STEPS,
                    stop_reason=StopReason.MAX_STEPS_REACHED,
                )
                return

    # ══════════════════════════════════════════
    # Budget enforcement (H3)
    # ══════════════════════════════════════════

    def _check_budget_pre_model(self) -> str | None:
        """Check budget before model call. Returns None if OK, status string if exceeded."""
        run = self._state_store.get_run(self._run_state.run_id)
        self._run_state = run

        # Check max_steps
        if run.max_steps is not None and run.current_step >= run.max_steps:
            self._state_store.update_run(
                run.run_id,
                status=RunStatus.MAX_STEPS,
                stop_reason=StopReason.MAX_STEPS_REACHED,
            )
            return "MAX_STEPS"

        # Check wall time
        elapsed = time.monotonic() - self._start_time
        if run.budget.max_wall_time is not None and elapsed >= run.budget.max_wall_time:
            self._state_store.update_run(
                run.run_id,
                status=RunStatus.BUDGET_EXCEEDED,
                stop_reason=StopReason.BUDGET_EXCEEDED,
            )
            return "BUDGET_EXCEEDED"

        return None

    def _check_budget_post_model(self) -> str | None:
        """Check budget after model response. Returns None if OK."""
        run = self._state_store.get_run(self._run_state.run_id)

        # Check token budget
        if run.budget.max_tokens is not None and run.budget.used_tokens >= run.budget.max_tokens:
            self._state_store.update_run(
                run.run_id,
                status=RunStatus.BUDGET_EXCEEDED,
                stop_reason=StopReason.BUDGET_EXCEEDED,
            )
            return "BUDGET_EXCEEDED"

        # Check wall time
        elapsed = time.monotonic() - self._start_time
        if run.budget.max_wall_time is not None and elapsed >= run.budget.max_wall_time:
            self._state_store.update_run(
                run.run_id,
                status=RunStatus.BUDGET_EXCEEDED,
                stop_reason=StopReason.BUDGET_EXCEEDED,
            )
            return "BUDGET_EXCEEDED"

        return None

    def _check_budget_pre_tool(self) -> bool:
        """Check budget before tool execution. Returns True if budget exceeded."""
        return self._check_budget_post_model() is not None

    # ══════════════════════════════════════════
    # Completion acceptance (H1)
    # ══════════════════════════════════════════

    def _check_acceptance(self, final_answer: str | None) -> tuple[bool, str]:
        """Check if the final_answer meets completion acceptance criteria.

        Returns (accepted, rejection_reason).

        For steps that require only 'inspection' evidence (read-only analysis),
        the step is considered acceptable if it is IN_PROGRESS and the agent
        has produced a final_answer — no formal Evidence artifact is required.
        """
        if not final_answer or not final_answer.strip():
            return False, "final_answer is empty"

        run = self._state_store.get_run(self._run_state.run_id)

        # Check active plan: all steps must be COMPLETED
        if run.active_plan_id:
            plan = run.plans.get(run.active_plan_id)
            if plan is not None:
                incomplete = []
                for s in plan.steps:
                    if s.status.value == "completed":
                        continue
                    # Inspection-only steps are acceptable when IN_PROGRESS
                    if (
                        s.status == StepStatus.IN_PROGRESS
                        and s.required_evidence_kinds
                        and all(k == EvidenceKind.INSPECTION for k in s.required_evidence_kinds)
                    ):
                        continue
                    incomplete.append(s)

                if incomplete:
                    incomplete_ids = [s.id for s in incomplete]
                    return False, f"Incomplete plan steps: {incomplete_ids}"

                # Check evidence validity for completed steps
                for step in plan.steps:
                    if step.status.value != "completed":
                        continue
                    # Verify required evidence kinds have valid evidence
                    step_evidence = [
                        run.evidence_store[eid]
                        for eid in step.evidence_ids
                        if eid in run.evidence_store
                    ]
                    valid_evidence = [
                        e for e in step_evidence
                        if e.status == EvidenceStatus.VALID
                    ]
                    valid_kinds = {e.kind for e in valid_evidence}
                    for req_kind in step.required_evidence_kinds:
                        if req_kind not in valid_kinds:
                            return False, (
                                f"Step {step.id} missing valid evidence of kind "
                                f"{req_kind.value}"
                            )

        return True, ""

    def _complete_accepted_plan_steps(self, run_id: str) -> None:
        run = self._state_store.get_run(run_id)
        if not run or not run.active_plan_id:
            return
        plan = run.plans.get(run.active_plan_id)
        if not plan:
            return
        for step in plan.steps:
            if step.status == StepStatus.IN_PROGRESS and self._state_store.evaluate_step_acceptance(
                run_id, run.active_plan_id, step.id
            ):
                self._state_store.update_plan_step(
                    run_id, run.active_plan_id, step.id, status=StepStatus.COMPLETED
                )

    # ══════════════════════════════════════════
    # Approval integration
    # ══════════════════════════════════════════

    def approve(
        self, run_id: str, approval_id: str, approver: str, reason: str | None = None
    ) -> None:
        """Approve a pending approval and resume the run."""
        if self._approval_workflow is None:
            raise ValueError("No approval workflow configured")
        self._validate_pending_approval(run_id, approval_id)

        self._approval_workflow.resume(
            approval_id, decision="APPROVE", approver=approver, reason=reason
        )

        # Update StateStore
        self._state_store.resolve_approval(
            run_id, approval_id,
            status=ApprovalStatus.APPROVED,
            decided_by=approver,
            decision_reason=reason,
        )

        approval = self._state_store.get_approval(run_id, approval_id)

        self._audit.log(AuditEvent(
            event_id=str(uuid.uuid4()),
            event_type=AuditEventType.APPROVAL_GRANTED,
            run_id=run_id,
            tool_call_id=approval.tool_call_id if approval else None,
            actor=approver,
            detail=f"Approval granted: {approval_id}",
        ))

    def reject_approval(
        self, run_id: str, approval_id: str, approver: str, reason: str | None = None
    ) -> None:
        """Reject a pending approval."""
        if self._approval_workflow is None:
            raise ValueError("No approval workflow configured")
        self._validate_pending_approval(run_id, approval_id)

        self._approval_workflow.resume(
            approval_id, decision="REJECT", approver=approver, reason=reason
        )

        # Update StateStore
        self._state_store.resolve_approval(
            run_id, approval_id,
            status=ApprovalStatus.REJECTED,
            decided_by=approver,
            decision_reason=reason,
        )

        approval = self._state_store.get_approval(run_id, approval_id)

        self._audit.log(AuditEvent(
            event_id=str(uuid.uuid4()),
            event_type=AuditEventType.APPROVAL_DENIED,
            run_id=run_id,
            tool_call_id=approval.tool_call_id if approval else None,
            actor=approver,
            detail=f"Approval rejected: {approval_id}",
        ))

    def _validate_pending_approval(self, run_id: str, approval_id: str) -> None:
        run = self._state_store.get_run(run_id)
        if run is None or len(run.pending_tool_batches) != 1:
            raise ValueError("Run has no pending tool batch")
        approval = next((a for a in run.pending_approvals if a.approval_id == approval_id), None)
        batch = run.pending_tool_batches[0]
        if approval is None or approval.tool_call_id != batch.waiting_tool_call_id:
            raise ValueError("Approval does not belong to the pending tool call")
        if not 0 <= batch.next_call_index < len(batch.tool_calls):
            raise ValueError("Pending tool call index is invalid")
        call = batch.tool_calls[batch.next_call_index]
        arguments = parse_json_if_needed(call["arguments"])
        if (
            call["id"] != approval.tool_call_id or call["name"] != approval.tool_name
            or not isinstance(arguments, dict)
            or _hash_arguments(arguments) != approval.arguments_hash
            or _hash_arguments(approval.arguments) != approval.arguments_hash
            or self._compute_workspace_fingerprint() != approval.workspace_fingerprint
        ):
            raise ValueError("Pending tool call no longer matches its approval or workspace")

    # ══════════════════════════════════════════
    # Evidence invalidation (H2)
    # ══════════════════════════════════════════

    def invalidate_evidence_after_workspace_change(
        self, new_artifact_version: str
    ) -> list[str]:
        """Invalidate stale TEST/DIFF evidence after workspace change."""
        stale = self._state_store.invalidate_stale_evidence(
            self._run_state.run_id,
            new_artifact_version,
        )
        for eid in stale:
            self._audit.log(AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.EVIDENCE_INVALIDATED,
                run_id=self._run_state.run_id,
                actor="system",
                detail=f"Evidence {eid} invalidated (stale artifact_version)",
            ))
        return stale

    # ══════════════════════════════════════════
    # Unknown result detection (C2)
    # ══════════════════════════════════════════

    def detect_unknown_results(self, run_id: str) -> list[str]:
        """Detect tool calls with TOOL_STARTED but no result event.

        Returns a list of tool_call_ids whose execution outcome is unknown.
        """
        started_events = self._audit.query(
            run_id=run_id, event_type=AuditEventType.TOOL_STARTED
        )
        result_types = {
            AuditEventType.TOOL_EXECUTED,
            AuditEventType.TOOL_ERROR,
            AuditEventType.SANDBOX_VIOLATION,
        }
        result_tc_ids: set[str] = set()
        for rt in result_types:
            for ev in self._audit.query(run_id=run_id, event_type=rt):
                if ev.tool_call_id:
                    result_tc_ids.add(ev.tool_call_id)

        unknown: list[str] = []
        for ev in started_events:
            if ev.tool_call_id and ev.tool_call_id not in result_tc_ids:
                unknown.append(ev.tool_call_id)
        return unknown

    def resolve_unknown_result(
        self,
        run_id: str,
        tool_call_id: str,
        outcome: str,
        resolver: str,
        result: str | None = None,
    ) -> None:
        """Resolve an unknown result for a tool call.

        Parameters
        ----------
        outcome : str
            ``"EXECUTED"`` (skip replay) or ``"NOT_EXECUTED"`` (re-enter Gate).
        resolver : str
            Identity of the person resolving the outcome.
        result : str | None
            Result summary (for EXECUTED outcomes).
        """
        self._audit.log(AuditEvent(
            event_id=str(uuid.uuid4()),
            event_type=AuditEventType.UNKNOWN_RESULT_RESOLVED,
            run_id=run_id,
            tool_call_id=tool_call_id,
            actor=resolver,
            detail=f"Resolved as {outcome}" + (f": {result}" if result else ""),
        ))

        # If EXECUTED, log a synthetic TOOL_EXECUTED so detection won't flag it again
        if outcome == "EXECUTED":
            self._audit.log(AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.TOOL_EXECUTED,
                run_id=run_id,
                tool_call_id=tool_call_id,
                actor=resolver,
                detail=f"Human-confirmed EXECUTED: {result or '(no detail)'}",
            ))

        # Check if all unknown results are resolved
        remaining = self.detect_unknown_results(run_id)
        if not remaining:
            # All resolved — allow run to continue
            run = self._state_store.get_run(run_id)
            if run and run.status == RunStatus.UNKNOWN_RESULT:
                self._state_store.update_run(
                    run_id, status=RunStatus.RUNNING
                )

    # ══════════════════════════════════════════
    # Workspace change detection (C4)
    # ══════════════════════════════════════════

    def detect_workspace_change(self, run_id: str) -> bool:
        """Check if workspace fingerprint has changed since last checkpoint.

        Returns True if workspace has changed.
        """
        run = self._state_store.get_run(run_id)
        if run is None:
            return False
        current_fp = self._compute_workspace_fingerprint()
        return run.workspace_fingerprint != current_fp

    def resolve_workspace_change(
        self,
        run_id: str,
        continue_run: bool,
        resolver: str,
    ) -> None:
        """Resolve a workspace change detection.

        Parameters
        ----------
        continue_run : bool
            If True, rebuild fingerprint and allow explicit resume.
            If False, keep run in terminated state.
        resolver : str
            Identity of the person resolving the change.
        """
        if continue_run:
            # Rebuild fingerprint with current workspace
            new_fp = self._compute_workspace_fingerprint()

            # Invalidate stale evidence
            self.invalidate_evidence_after_workspace_change(new_fp)

            # Invalidate all pending approvals
            invalidated = self._state_store.invalidate_pending_approvals(
                run_id, reason=f"Workspace changed (resolved by {resolver})"
            )

            # Update workspace fingerprint
            self._state_store.update_run(
                run_id,
                workspace_fingerprint=new_fp,
                status=RunStatus.RUNNING,
            )

            self._audit.log(AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.WORKSPACE_CHANGE_RESOLVED,
                run_id=run_id,
                actor=resolver,
                detail=(
                    f"Workspace change resolved: fingerprint rebuilt, "
                    f"{len(invalidated)} approvals invalidated"
                ),
            ))
        # If not continue_run, run stays in FAILED/WORKSPACE_CHANGED state

    # ══════════════════════════════════════════
    # Internal helpers
    # ══════════════════════════════════════════

    def _build_messages(self, task: str) -> list[ChatMessage]:
        """Build the message list for the model from memory steps."""
        messages: list[ChatMessage] = [
            ChatMessage(
                role=MessageRole.USER,
                content=[{"type": "text", "text": (
                    f"Task:\n{task}\n\nWhen finished, call final_answer with your answer. "
                    "You are encouraged to create a plan using create_plan and revise_plan "
                    "to organize your work before executing tools. "
                    "For read-only analysis steps, use required_evidence_kinds=['inspection']."
                )}],
            )
        ]
        for step in self._memory_steps:
            messages.extend(step.to_messages())
        return messages

    def _extract_text(self, response: ChatMessage) -> str | None:
        """Extract text content from a ChatMessage."""
        if response.content is None:
            return None
        if isinstance(response.content, str):
            return response.content
        if isinstance(response.content, list):
            texts = [
                item.get("text", "")
                for item in response.content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return "\n".join(texts) if texts else None
        return str(response.content)

    def _extract_final_answer(self) -> str | None:
        """Extract the final answer from memory steps."""
        for step in reversed(self._memory_steps):
            if isinstance(step, ActionStep) and step.is_final_answer:
                return step.action_output
        return None

    def _compute_workspace_fingerprint(self) -> str:
        """Compute a simple fingerprint of the workspace."""
        import hashlib
        from pathlib import Path

        ws = Path(self._config.workspace_root)
        if not ws.exists():
            return "empty"
        hasher = hashlib.sha256()
        patterns = self._config.sandbox_config.fingerprint_patterns if self._config.sandbox_config else ["*.py"]
        for pat in patterns:
            for p in sorted(ws.rglob(pat)):
                hasher.update(str(p.relative_to(ws)).encode())
                if p.is_symlink():
                    hasher.update(str(p.readlink()).encode())
                elif p.is_file():
                    hasher.update(p.read_bytes())
        return hasher.hexdigest()[:16]


# ══════════════════════════════════════════
# GuardedHarness — public assembly class
# ══════════════════════════════════════════


class GuardedHarness:
    """Public entry point: wires all harness components together.

    Performs startup validation (platform, tool policy coverage,
    config consistency) and exposes the full run/approve/reject API.

    Parameters
    ----------
    model : Model
        LLM model instance (or FakeModel for testing).
    tools : list[Tool]
        Registered tool list.
    config : HarnessConfig
        Harness configuration.
    """

    def __init__(
        self,
        model: Any,
        tools: list[Tool],
        config: HarnessConfig,
    ) -> None:
        from .config import validate_config

        # Startup validation
        tool_names = {t.name for t in tools}
        validate_config(config, registered_tool_names=tool_names)

        # Build components
        self._audit = AuditLogger(config.storage_path)
        self._state_store = StateStore(config.storage_path)
        self._sandbox = Sandbox(config=config.sandbox_config, audit=self._audit)
        self._checkpoint_manager = CheckpointManager(config.storage_path)

        # ApprovalWorkflow (optional — create if checkpointer_path configured)
        self._approval_workflow: Any | None = None
        if config.approval_checkpointer_path:
            from .approval import ApprovalWorkflow

            self._approval_workflow = ApprovalWorkflow()

        # Build runner
        self._runner = HarnessRunner(
            model=model,
            tools=tools,
            config=config,
            gate=None,
            sandbox=self._sandbox,
            state_store=self._state_store,
            audit=self._audit,
            checkpoint_manager=self._checkpoint_manager,
            approval_workflow=self._approval_workflow,
        )

    # ── Public API ──────────────────────────────

    def run(
        self,
        task: str,
        *,
        reset: bool = True,
        resume_run_id: str | None = None,
    ) -> HarnessRunResult:
        """Create a new run or resume an existing one."""
        return self._runner.run(task, reset=reset, resume_run_id=resume_run_id)

    def approve(
        self, run_id: str, approval_id: str, *, approver: str
    ) -> None:
        """Approve a pending approval request."""
        self._runner.approve(run_id, approval_id, approver)

    def reject_approval(
        self,
        run_id: str,
        approval_id: str,
        *,
        approver: str,
        reason: str | None = None,
    ) -> None:
        """Reject a pending approval request."""
        self._runner.reject_approval(run_id, approval_id, approver, reason)

    def resolve_workspace_change(
        self,
        run_id: str,
        *,
        continue_run: bool,
        resolver: str = "user",
    ) -> None:
        """Resolve workspace change detection."""
        self._runner.resolve_workspace_change(run_id, continue_run, resolver)

    def resolve_unknown_result(
        self,
        run_id: str,
        tool_call_id: str,
        *,
        outcome: str,
        resolver: str = "user",
        result: str | None = None,
    ) -> None:
        """Resolve unknown tool execution result."""
        self._runner.resolve_unknown_result(
            run_id, tool_call_id, outcome, resolver, result
        )

    def cancel(self) -> None:
        """Cancel the current run."""
        if self._runner._run_state is not None:
            self._state_store.update_run(
                self._runner._run_state.run_id,
                status=RunStatus.CANCELLED,
                stop_reason=StopReason.USER_CANCELLED,
            )
            self._audit.log(AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.RUN_CANCELLED,
                run_id=self._runner._run_state.run_id,
                actor="system",
                detail="Run cancelled by user",
            ))

    def get_state(self) -> RunState:
        """Get current run state snapshot."""
        if self._runner._run_state is None:
            raise ValueError("No active run")
        return self._state_store.get_run(self._runner._run_state.run_id)

    def get_audit(self, run_id: str | None = None) -> list[AuditEvent]:
        """Get audit events for the given (or current) run."""
        rid = run_id or (
            self._runner._run_state.run_id
            if self._runner._run_state
            else None
        )
        if rid is None:
            return []
        return self._audit.query(run_id=rid)

    def get_checkpoint(self, run_id: str | None = None) -> Any | None:
        """Get latest checkpoint for the given (or current) run."""
        rid = run_id or (
            self._runner._run_state.run_id
            if self._runner._run_state
            else None
        )
        if rid is None:
            return None
        return self._checkpoint_manager.load_latest(rid)
