"""Append-only audit logger for the Guarded Coding Harness.

All gate decisions, tool executions, approval events, checkpoint operations,
and run state changes are recorded as JSONL entries. The logger provides no
delete or modify API — entries are append-only.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from .models import AuditEvent, AuditEventType


def _serialize_event(event: AuditEvent) -> dict:
    """Convert an AuditEvent to a JSON-safe dict."""
    d: dict = {
        "event_id": event.event_id,
        "event_type": event.event_type.value,
        "run_id": event.run_id,
        "tool_call_id": event.tool_call_id,
        "step_number": event.step_number,
        "tool_name": event.tool_name,
        "arguments": event.arguments,
        "rule": event.rule,
        "decision": event.decision,
        "actor": event.actor,
        "detail": event.detail,
        "timestamp": event.timestamp.isoformat(),
    }
    return d


def _deserialize_event(data: dict) -> AuditEvent:
    """Reconstruct an AuditEvent from a parsed JSON dict."""
    return AuditEvent(
        event_id=data["event_id"],
        event_type=AuditEventType(data["event_type"]),
        run_id=data["run_id"],
        tool_call_id=data.get("tool_call_id"),
        step_number=data.get("step_number"),
        tool_name=data.get("tool_name"),
        arguments=data.get("arguments"),
        rule=data.get("rule"),
        decision=data.get("decision"),
        actor=data.get("actor", "system"),
        detail=data.get("detail", ""),
        timestamp=datetime.fromisoformat(data["timestamp"]),
    )


class AuditLogger:
    """Append-only audit logger.

    Events are written as JSONL (one JSON object per line) to
    ``{storage_path}/audit/{run_id}.jsonl``.  Each event is flushed
    to disk immediately.
    """

    def __init__(self, storage_path: str | Path) -> None:
        self._audit_dir = Path(storage_path) / "audit"
        self._audit_dir.mkdir(parents=True, exist_ok=True)

    def _run_file(self, run_id: str) -> Path:
        return self._audit_dir / f"{run_id}.jsonl"

    # ── write ────────────────────────────────────

    def log(self, event: AuditEvent) -> None:
        """Append a single audit event and flush to disk."""
        line = json.dumps(_serialize_event(event), ensure_ascii=False)
        path = self._run_file(event.run_id)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
            fh.flush()
            os.fsync(fh.fileno())

    # ── read ─────────────────────────────────────

    def query(
        self,
        *,
        run_id: str | None = None,
        tool_call_id: str | None = None,
        event_type: AuditEventType | None = None,
    ) -> list[AuditEvent]:
        """Query audit events with optional filters.

        If *run_id* is given, only that run's log is read; otherwise all
        run logs are scanned.  Results are returned in chronological order.
        """
        events = self._load_events(run_id)
        if tool_call_id is not None:
            events = [e for e in events if e.tool_call_id == tool_call_id]
        if event_type is not None:
            events = [e for e in events if e.event_type == event_type]
        return events

    def get_decision_chain(self, tool_call_id: str) -> list[AuditEvent]:
        """Return all audit events related to a specific tool_call_id."""
        return self.query(tool_call_id=tool_call_id)

    def get_run_audit(self, run_id: str) -> list[AuditEvent]:
        """Return all audit events for a specific run."""
        return self.query(run_id=run_id)

    # ── internal ─────────────────────────────────

    def _load_events(self, run_id: str | None) -> list[AuditEvent]:
        """Load events from one or all run files."""
        if run_id is not None:
            return self._read_file(self._run_file(run_id))
        events: list[AuditEvent] = []
        for path in sorted(self._audit_dir.glob("*.jsonl")):
            events.extend(self._read_file(path))
        return events

    @staticmethod
    def _read_file(path: Path) -> list[AuditEvent]:
        if not path.exists():
            return []
        events: list[AuditEvent] = []
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                events.append(_deserialize_event(json.loads(line)))
        return events
