"""Data classes and enums for the Guarded Coding Harness."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Literal


# ──────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────


class RunStatus(str, Enum):
    """Run lifecycle states."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    MAX_STEPS = "MAX_STEPS"
    BUDGET_EXCEEDED = "BUDGET_EXCEEDED"
    CANCELLED = "CANCELLED"
    UNKNOWN_RESULT = "UNKNOWN_RESULT"


class StopReason(str, Enum):
    """Why a run stopped."""

    FINAL_ANSWER = "FINAL_ANSWER"
    MAX_STEPS_REACHED = "MAX_STEPS_REACHED"
    BUDGET_EXCEEDED = "BUDGET_EXCEEDED"
    USER_CANCELLED = "USER_CANCELLED"
    FATAL_ERROR = "FATAL_ERROR"
    APPROVAL_TIMEOUT = "APPROVAL_TIMEOUT"
    WORKSPACE_CHANGED = "WORKSPACE_CHANGED"


class StepStatus(str, Enum):
    """PlanStep business status."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"
    FAILED = "failed"


class EvidenceKind(str, Enum):
    """Type of evidence produced by tool execution."""

    TOOL = "tool"
    TEST = "test"
    DIFF = "diff"
    INSPECTION = "inspection"


class EvidenceStatus(str, Enum):
    """Whether evidence is still valid."""

    VALID = "valid"
    STALE = "stale"


class ApprovalStatus(str, Enum):
    """Approval lifecycle states."""

    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    INVALIDATED = "INVALIDATED"


class AuditEventType(str, Enum):
    """All audit event types."""

    # Gate
    GATE_ALLOW = "GATE_ALLOW"
    GATE_DENY = "GATE_DENY"
    GATE_WAITING_APPROVAL = "GATE_WAITING_APPROVAL"

    # Approval
    APPROVAL_REQUESTED = "APPROVAL_REQUESTED"
    APPROVAL_GRANTED = "APPROVAL_GRANTED"
    APPROVAL_DENIED = "APPROVAL_DENIED"
    APPROVAL_GRAPH_RECOVERY_FAILED = "APPROVAL_GRAPH_RECOVERY_FAILED"

    # Tool execution
    TOOL_EXECUTED = "TOOL_EXECUTED"
    TOOL_STARTED = "TOOL_STARTED"
    TOOL_ERROR = "TOOL_ERROR"
    SANDBOX_VIOLATION = "SANDBOX_VIOLATION"

    # Checkpoint
    CHECKPOINT_SAVED = "CHECKPOINT_SAVED"
    CHECKPOINT_LOADED = "CHECKPOINT_LOADED"

    # Run lifecycle
    RUN_STARTED = "RUN_STARTED"
    RUN_COMPLETED = "RUN_COMPLETED"
    RUN_FAILED = "RUN_FAILED"
    RUN_CANCELLED = "RUN_CANCELLED"

    # Human resolution
    UNKNOWN_RESULT_RESOLVED = "UNKNOWN_RESULT_RESOLVED"
    WORKSPACE_CHANGE_RESOLVED = "WORKSPACE_CHANGE_RESOLVED"

    # Completion acceptance
    FINAL_ANSWER_ACCEPTED = "FINAL_ANSWER_ACCEPTED"
    FINAL_ANSWER_REJECTED = "FINAL_ANSWER_REJECTED"

    # Plan
    PLAN_CREATED = "PLAN_CREATED"
    PLAN_REVISED = "PLAN_REVISED"
    PLAN_REVISION_REJECTED = "PLAN_REVISION_REJECTED"
    PLAN_DELETED = "PLAN_DELETED"
    PLAN_STEP_STATUS_CHANGED = "PLAN_STEP_STATUS_CHANGED"

    # Evidence
    EVIDENCE_ADDED = "EVIDENCE_ADDED"
    EVIDENCE_INVALIDATED = "EVIDENCE_INVALIDATED"


class ToolCapability(str, Enum):
    """Capability declared for a tool."""

    READ = "READ"
    WRITE = "WRITE"
    EXECUTE = "EXECUTE"


# ──────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────


@dataclass
class AcceptanceCheck:
    """Machine-verifiable acceptance check for a PlanStep."""

    kind: Literal["TEST_EXIT_CODE", "PATH_EXISTS", "DIFF_PRESENT"]
    parameters: dict[str, Any]


@dataclass
class Evidence:
    """Structured evidence produced by tool execution."""

    id: str
    step_id: str
    tool_call_id: str
    artifact_version: str
    kind: EvidenceKind
    summary: str
    payload: dict[str, Any]
    created_at: datetime
    status: EvidenceStatus = EvidenceStatus.VALID


@dataclass
class PlanStep:
    """A single step in an execution plan."""

    id: str
    objective: str
    depends_on: list[str] = field(default_factory=list)
    success_criteria: list[str] = field(default_factory=list)
    status: StepStatus = StepStatus.PENDING
    evidence_ids: list[str] = field(default_factory=list)
    required_evidence_kinds: list[EvidenceKind] = field(default_factory=list)
    acceptance_checks: list[AcceptanceCheck] = field(default_factory=list)
    attempts: int = 0
    last_error: str | None = None


@dataclass
class Plan:
    """Structured execution plan with ordered steps."""

    version: int = 1
    goal: str = ""
    constraints: list[str] = field(default_factory=list)
    steps: list[PlanStep] = field(default_factory=list)
    revision_count: int = 0
    max_revisions: int = 5


@dataclass
class PendingToolBatch:
    """Unfinished batch of model tool calls from one response."""

    step_number: int
    model_response: dict[str, Any]
    tool_calls: list[dict[str, Any]]
    next_call_index: int
    waiting_tool_call_id: str | None = None


@dataclass
class ToolCallFingerprint:
    """Normalized call summary for repeat detection across steps."""

    tool_name: str
    arguments_hash: str


@dataclass
class BudgetInfo:
    """Budget tracking for a run."""

    max_tokens: int | None = None
    used_tokens: int = 0
    max_wall_time: int | None = None  # seconds, None = unlimited
    elapsed_time: float = 0.0


@dataclass
class ApprovalRequest:
    """A request for human approval of a tool call."""

    approval_id: str
    graph_thread_id: str
    tool_call_id: str
    tool_name: str
    arguments: dict[str, Any]
    arguments_hash: str
    workspace_fingerprint: str
    risk_level: str
    requested_at: datetime
    status: ApprovalStatus = ApprovalStatus.PENDING
    decided_by: str | None = None
    decided_at: datetime | None = None
    decision_reason: str | None = None


@dataclass
class StepRecord:
    """Agent main-loop step record (distinct from PlanStep)."""

    step_number: int
    tool_calls: list[dict[str, Any]]
    observations: str | None = None
    error: str | None = None
    is_final_answer: bool = False
    plan_step_id: str | None = None


@dataclass
class RunState:
    """Complete business state of a single run."""

    run_id: str
    task: str
    status: RunStatus
    stop_reason: StopReason | None = None
    current_step: int = 0
    max_steps: int = 20
    plans: dict[str, Plan] = field(default_factory=dict)
    active_plan_id: str | None = None
    step_records: list[StepRecord] = field(default_factory=list)
    evidence_store: dict[str, Evidence] = field(default_factory=dict)
    budget: BudgetInfo = field(default_factory=BudgetInfo)
    pending_approvals: list[ApprovalRequest] = field(default_factory=list)
    pending_tool_batches: list[PendingToolBatch] = field(default_factory=list)
    recent_calls: list[ToolCallFingerprint] = field(default_factory=list)
    workspace_fingerprint: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


# ──────────────────────────────────────────────
# Gate / Sandbox result types
# ──────────────────────────────────────────────


@dataclass
class GateDecision:
    """Decision result from the Gate module."""

    tool_call_id: str
    tool_name: str
    decision: Literal["ALLOW", "DENY", "WAITING_APPROVAL"]
    reason: str
    rule: str
    actor: str
    approved_by: str | None = None


@dataclass
class ToolPolicy:
    """Capability and approval policy for a registered tool."""

    tool_name: str
    capabilities: set[ToolCapability]
    controlled: bool
    requires_approval: bool


@dataclass
class CommandPolicy:
    """Fixed invocation policy for a single executable command."""

    executable: str  # absolute path to trusted executable
    argv_template: list[str]  # argument template with constrained placeholders
    path_arguments: list[str]  # placeholder names that require Sandbox path validation


@dataclass
class SandboxConfig:
    """Sandbox constraints configuration."""

    workspace_root: str
    allowed_dirs: list[str]
    sensitive_dirs: list[str]
    allowed_commands: dict[str, CommandPolicy] = field(default_factory=dict)
    allowed_env_vars: list[str] = field(default_factory=list)
    blocked_env_vars: list[str] = field(default_factory=list)
    max_file_size: int = 10_485_760  # 10 MB
    command_timeout: int = 60  # seconds
    max_output_bytes: int = 1_048_576  # 1 MB
    fingerprint_patterns: list[str] = field(default_factory=lambda: ["*.py"])


@dataclass
class SandboxViolation:
    """Record of a sandbox constraint violation."""

    type: str  # PATH_ESCAPE, SYMLINK_ESCAPE, COMMAND_NOT_ALLOWED, FILE_TOO_LARGE, etc.
    path: str | None = None
    message: str = ""
    real_path: str | None = None


@dataclass
class CommandResult:
    """Result of a sandboxed command execution."""

    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool = False
    truncated: bool = False


# ──────────────────────────────────────────────
# Audit
# ──────────────────────────────────────────────


@dataclass
class AuditEvent:
    """Immutable audit log entry."""

    event_id: str
    event_type: AuditEventType
    run_id: str
    tool_call_id: str | None = None
    step_number: int | None = None
    tool_name: str | None = None
    arguments: dict[str, Any] | None = None  # sanitized summary only
    rule: str | None = None
    decision: str | None = None
    actor: str = "system"
    detail: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


# ──────────────────────────────────────────────
# Checkpoint
# ──────────────────────────────────────────────


@dataclass
class Checkpoint:
    """Checkpoint snapshot for recovery."""

    run_id: str
    checkpoint_seq: int
    step_number: int
    run_state: RunState
    memory_steps: list[dict[str, Any]]
    workspace_fingerprint: str
    created_at: datetime = field(default_factory=datetime.now)


# ──────────────────────────────────────────────
# Harness configuration
# ──────────────────────────────────────────────


@dataclass
class HarnessConfig:
    """Top-level Harness configuration."""

    workspace_root: str
    storage_path: str
    sandbox_config: SandboxConfig
    approval_checkpointer_path: str
    max_steps: int = 20
    max_tokens: int | None = None
    max_wall_time: int | None = None
    repeat_threshold: int = 3
    approval_mode: Literal["auto_read", "manual_all"] = "auto_read"
    required_artifacts: list[str] = field(default_factory=list)
    tool_policies: dict[str, ToolPolicy] = field(default_factory=dict)
    llm_retry_max: int = 3
    llm_retry_initial_delay: float = 1.0
    enable_plan_tools: bool = True

    @classmethod
    def from_toml(cls, path: str | Path) -> HarnessConfig:
        """Load configuration from a TOML file at the given absolute path.

        Raises ConfigurationError if the file is missing, unparseable, or fails validation.
        """
        from .config import load_and_validate_toml

        return load_and_validate_toml(path)


# ──────────────────────────────────────────────
# Harness run result
# ──────────────────────────────────────────────


@dataclass
class HarnessRunResult:
    """Return value of GuardedHarness.run()."""

    state: RunStatus
    stop_reason: StopReason | None
    run_state: RunState
    final_answer: str | None = None


# ──────────────────────────────────────────────
# Custom exceptions
# ──────────────────────────────────────────────


class HarnessError(Exception):
    """Base exception for all harness errors."""


class ConfigurationError(HarnessError):
    """Configuration validation failed at startup."""


class RunAlreadyActiveError(HarnessError):
    """Another process already holds the run lock for this run_id."""


class ApprovalNotFoundError(HarnessError):
    """The specified approval_id does not exist."""


class ApprovalAlreadyDecidedError(HarnessError):
    """The approval has already been decided with a conflicting decision."""


class UnauthorizedApproverError(HarnessError):
    """The approver identity was not authorized by the host application."""


class CheckpointRecoveryError(HarnessError):
    """Checkpoint recovery failed — data corrupted or unknown type."""


class WorkspaceChangedError(HarnessError):
    """Workspace fingerprint mismatch detected on resume."""


class PlanRevisionLimitError(HarnessError):
    """Plan has reached its maximum revision count."""


class SandboxViolationError(HarnessError):
    """Sandbox constraint violation (path escape, command not allowed, etc.)."""

    def __init__(self, violation: SandboxViolation) -> None:
        self.violation = violation
        super().__init__(violation.message)
