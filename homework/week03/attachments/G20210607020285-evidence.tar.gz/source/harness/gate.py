"""Gate module — the single entry point for all tool call pre-execution checks.

Every tool call (including ``final_answer``) must pass through :meth:`Gate.check`
before execution.  The Gate performs checks in a fixed order and returns a
:class:`~harness.models.GateDecision` describing the outcome.

Check order (per PRD §2.1.2):

1. Tool existence
2. Parameter completeness
3. Parameter type
4. Capability / permission
5. Risk assessment
6. Approval verification
7. Repeat detection (sliding window)
8. Post-approval replay detection
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime
from typing import Any, Literal

from smolagents.memory import ToolCall
from smolagents.tools import Tool, validate_tool_arguments

from .audit import AuditLogger
from .models import (
    AuditEvent,
    AuditEventType,
    GateDecision,
    ToolCapability,
    ToolPolicy,
)


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────


def _hash_arguments(arguments: Any) -> str:
    """Produce a deterministic SHA-256 hash of tool call arguments."""
    canonical = json.dumps(arguments, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _audit_event_type_for_decision(decision: str) -> AuditEventType:
    """Map a decision string to the corresponding audit event type."""
    mapping = {
        "ALLOW": AuditEventType.GATE_ALLOW,
        "DENY": AuditEventType.GATE_DENY,
        "WAITING_APPROVAL": AuditEventType.GATE_WAITING_APPROVAL,
    }
    return mapping[decision]


# ──────────────────────────────────────────────
# Gate
# ──────────────────────────────────────────────


class Gate:
    """Pre-execution gate that all tool calls must pass through.

    Parameters
    ----------
    tool_policies : dict[str, ToolPolicy]
        Registered tool policies keyed by tool name.
    approval_mode : str
        ``"auto_read"`` or ``"manual_all"``.
    repeat_threshold : int
        Number of consecutive identical calls before repeat detection triggers.
    audit_logger : AuditLogger
        Append-only audit logger for recording decisions.
    run_id : str
        Current run identifier for audit events.
    """

    def __init__(
        self,
        *,
        tool_policies: dict[str, ToolPolicy],
        approval_mode: str = "auto_read",
        repeat_threshold: int = 3,
        audit_logger: AuditLogger,
        run_id: str,
    ) -> None:
        self._tool_policies = dict(tool_policies)
        self._approval_mode = approval_mode
        self._repeat_threshold = repeat_threshold
        self._audit = audit_logger
        self._run_id = run_id

        # Internal state
        self._recent_calls: list[tuple[str, str]] = []  # (tool_name, args_hash)
        self._executed_call_ids: set[str] = set()
        self._approved_call_ids: set[str] = set()
        self._step_number: int = 0

    # ── Public API ──────────────────────────────────

    def check(self, tool_call: ToolCall, tool: Tool) -> GateDecision:
        """Run all pre-execution checks and return a decision.

        Checks are executed in a fixed order.  The first failing check
        short-circuits the remaining checks.
        """
        tool_name = tool_call.name
        arguments = tool_call.arguments
        call_id = tool_call.id
        args_hash = _hash_arguments(arguments)

        # 1. Tool existence
        decision = self._check_tool_existence(tool_name, call_id, arguments)
        if decision is not None:
            return decision

        # 2+3. Parameter validation (completeness + type)
        decision = self._check_parameters(tool, tool_name, call_id, arguments)
        if decision is not None:
            return decision

        policy = self._tool_policies[tool_name]

        # 4. Capability / permission
        # (Currently covered by approval check — capabilities inform the decision)

        # 5. Risk assessment
        # (Simplified: WRITE/EXECUTE capabilities are treated as higher risk)

        # 6. Post-approval replay detection (before approval — already-executed calls
        #    must be blocked even if the approval was consumed)
        decision = self._check_replay(tool_name, call_id, arguments)
        if decision is not None:
            return decision

        # 7. Approval verification
        decision = self._check_approval(tool_name, call_id, arguments, args_hash, policy)
        if decision is not None:
            return decision

        # 8. Repeat detection
        decision = self._check_repeat(tool_name, call_id, arguments, args_hash)
        if decision is not None:
            return decision

        # All checks passed → ALLOW
        allow_decision = self._make_decision(
            call_id=call_id,
            tool_name=tool_name,
            decision="ALLOW",
            reason="All checks passed",
            rule="all_passed",
            arguments=arguments,
        )
        # Record fingerprint for repeat tracking
        self._recent_calls.append((tool_name, args_hash))
        return allow_decision

    def mark_executed(self, tool_call_id: str, tool_name: str | None = None) -> None:
        """Record that a tool_call_id has been executed.

        Call this after successful tool execution.  It prevents post-approval
        replay and logs an audit event.
        """
        self._executed_call_ids.add(tool_call_id)
        # Remove from approved set — approval is single-use
        self._approved_call_ids.discard(tool_call_id)
        self._audit.log(
            AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=AuditEventType.TOOL_EXECUTED,
                run_id=self._run_id,
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                step_number=self._step_number,
                actor="system",
                detail=f"Tool call {tool_call_id} executed successfully",
            )
        )

    def reset_repeat_tracker(self) -> None:
        """Clear the repeat detection window.

        Call only when creating a **new** Run — never at step boundaries.
        """
        self._recent_calls.clear()

    def reset_for_run(self) -> None:
        """Clear per-run replay, approval, and repeat tracking."""
        self._recent_calls.clear()
        self._executed_call_ids.clear()
        self._approved_call_ids.clear()

    def add_approved_tool_call(self, tool_call_id: str) -> None:
        """Register a pre-approved tool_call_id.

        The HarnessRunner calls this after a successful approval workflow
        before re-entering the Gate.
        """
        self._approved_call_ids.add(tool_call_id)

    def set_step_number(self, step_number: int) -> None:
        """Update the current step number for audit events."""
        self._step_number = step_number

    def set_run_id(self, run_id: str) -> None:
        """Update the run ID (e.g., on resume)."""
        self._run_id = run_id

    # ── Internal checks ─────────────────────────────

    def _check_tool_existence(
        self, tool_name: str, call_id: str, arguments: Any
    ) -> GateDecision | None:
        """Check 1: tool must be registered in tool_policies."""
        if tool_name not in self._tool_policies:
            return self._make_decision(
                call_id=call_id,
                tool_name=tool_name,
                decision="DENY",
                reason=f"Tool not registered: '{tool_name}'",
                rule="tool_existence",
                arguments=arguments,
            )
        return None

    def _check_parameters(
        self, tool: Tool, tool_name: str, call_id: str, arguments: Any
    ) -> GateDecision | None:
        """Checks 2+3: parameter completeness and type validation."""
        try:
            validate_tool_arguments(tool, arguments)
        except (ValueError, TypeError) as exc:
            return self._make_decision(
                call_id=call_id,
                tool_name=tool_name,
                decision="DENY",
                reason=f"Parameter validation failed: {exc}",
                rule="parameter_validation",
                arguments=arguments,
            )
        return None

    def _check_approval(
        self,
        tool_name: str,
        call_id: str,
        arguments: Any,
        args_hash: str,
        policy: ToolPolicy,
    ) -> GateDecision | None:
        """Check 6: approval verification based on approval_mode and tool policy."""
        # final_answer never requires approval
        if tool_name == "final_answer":
            return None

        needs_approval = False

        if self._approval_mode == "manual_all":
            # All non-final_answer calls need approval
            needs_approval = True
        elif self._approval_mode == "auto_read":
            # WRITE/EXECUTE capabilities or explicit requires_approval
            if ToolCapability.WRITE in policy.capabilities:
                needs_approval = True
            if ToolCapability.EXECUTE in policy.capabilities:
                needs_approval = True
            if policy.requires_approval:
                needs_approval = True

        if needs_approval and call_id not in self._approved_call_ids:
            return self._make_decision(
                call_id=call_id,
                tool_name=tool_name,
                decision="WAITING_APPROVAL",
                reason=f"Tool call requires approval: '{tool_name}' "
                f"(capabilities={{{', '.join(c.value for c in policy.capabilities)}}}, "
                f"requires_approval={policy.requires_approval})",
                rule="approval_required",
                arguments=arguments,
            )
        return None

    def _check_repeat(
        self, tool_name: str, call_id: str, arguments: Any, args_hash: str
    ) -> GateDecision | None:
        """Check 7: consecutive identical calls exceed threshold."""
        # Count consecutive calls with same (tool_name, args_hash) at the end
        count = 0
        for tn, ah in reversed(self._recent_calls):
            if tn == tool_name and ah == args_hash:
                count += 1
            else:
                break

        if count >= self._repeat_threshold - 1:
            # This would be the Nth call (threshold reached)
            return self._make_decision(
                call_id=call_id,
                tool_name=tool_name,
                decision="DENY",
                reason=f"Repeated call detected: {tool_name} with same args, "
                f"count={count + 1} (threshold={self._repeat_threshold})",
                rule="repeat_detection",
                arguments=arguments,
            )
        return None

    def _check_replay(
        self, tool_name: str, call_id: str, arguments: Any
    ) -> GateDecision | None:
        """Check 8: already-executed approved call must not replay."""
        if call_id in self._executed_call_ids:
            return self._make_decision(
                call_id=call_id,
                tool_name=tool_name,
                decision="DENY",
                reason=f"Already executed after approval: {call_id}",
                rule="post_approval_replay",
                arguments=arguments,
            )
        return None

    # ── Decision factory with audit logging ─────────

    def _make_decision(
        self,
        *,
        call_id: str,
        tool_name: str,
        decision: Literal["ALLOW", "DENY", "WAITING_APPROVAL"],
        reason: str,
        rule: str,
        arguments: Any,
    ) -> GateDecision:
        """Create a GateDecision and log it to the audit trail."""
        gd = GateDecision(
            tool_call_id=call_id,
            tool_name=tool_name,
            decision=decision,
            reason=reason,
            rule=rule,
            actor="system",
        )

        # Audit log
        self._audit.log(
            AuditEvent(
                event_id=str(uuid.uuid4()),
                event_type=_audit_event_type_for_decision(decision),
                run_id=self._run_id,
                tool_call_id=call_id,
                step_number=self._step_number,
                tool_name=tool_name,
                arguments=self._sanitize_arguments(arguments),
                rule=rule,
                decision=decision,
                actor="system",
                detail=reason,
            )
        )

        return gd

    @staticmethod
    def _sanitize_arguments(arguments: Any) -> dict[str, Any] | None:
        """Produce a sanitized summary of arguments for audit logging.

        Truncates long string values to prevent audit log bloat.
        """
        if not isinstance(arguments, dict):
            return {"_value": str(arguments)[:200]}
        sanitized: dict[str, Any] = {}
        for key, value in arguments.items():
            if isinstance(value, str) and len(value) > 200:
                sanitized[key] = value[:200] + "...[truncated]"
            else:
                sanitized[key] = value
        return sanitized
