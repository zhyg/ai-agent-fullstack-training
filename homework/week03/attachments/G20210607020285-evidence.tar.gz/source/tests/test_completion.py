"""Guarded Coding Harness 的端到端集成测试。

测试验证完整的任务流程——代码理解和测试修复——
通过完整的 GuardedHarness 装配体端到端运行。

依据 PRD §3.3 test_completion.py（T036）。
"""

from __future__ import annotations

import os

import pytest

from harness.config import validate_config
from harness.harness import GuardedHarness
from harness.models import (
    AuditEventType,
    ConfigurationError,
    HarnessConfig,
    RunStatus,
    SandboxConfig,
    StopReason,
    ToolCapability,
    ToolPolicy,
)
from tests.conftest import FakeModel, FakeTool
from smolagents.models import (
    ChatMessage,
    ChatMessageToolCall,
    ChatMessageToolCallFunction,
    MessageRole,
)


def _make_config(tmp_path, *, tool_policies: dict | None = None) -> HarnessConfig:
    """为 E2E 测试创建有效的 HarnessConfig。"""
    workspace = str(tmp_path / "workspace")
    (tmp_path / "workspace").mkdir(exist_ok=True)
    storage = str(tmp_path / "storage")
    (tmp_path / "storage").mkdir(exist_ok=True)
    return HarnessConfig(
        workspace_root=workspace,
        storage_path=storage,
        sandbox_config=SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=10_000_000,
        ),
        approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
        max_steps=10,
        tool_policies=tool_policies or {},
    )


# ══════════════════════════════════════════════
# T1：端到端代码理解
# ══════════════════════════════════════════════


class TestEndToEndCodeUnderstanding:
    """完整流程：读代码 → 分析 → 生成 final_answer → 所有交付物齐全。"""

    def test_end_to_end_code_understanding(self, tmp_path):
        """Agent 读取文件、分析并生成最终答案。

        验证：
        - 运行以 COMPLETED 状态完成
        - final_answer 存在
        - 审计轨迹包含 RUN_STARTED、TOOL_EXECUTED、FINAL_ANSWER_ACCEPTED
        - 状态中已记录步骤
        """
        # 初始化工具
        read_tool = FakeTool(
            name="file_read",
            inputs={"path": {"type": "string", "description": "File path"}},
            output_type="string",
        )
        read_tool.set_output("def login(user, pw):\n    return db.check(user, pw)")

        policy_read = ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        config = _make_config(tmp_path, tool_policies={"file_read": policy_read})

        # 在工作区写入源文件以供指纹计算
        src_file = tmp_path / "workspace" / "login.py"
        src_file.write_text("def login(user, pw):\n    return db.check(user, pw)\n")

        # 编排模型响应：1）读文件，2）最终答案
        tc_id_read = "tc-read-001"
        tc_id_final = "tc-final-001"
        model = FakeModel(responses=[
            # 响应 1：调用 file_read
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content=[{"type": "text", "text": "Let me read the login module."}],
                tool_calls=[
                    ChatMessageToolCall(
                        id=tc_id_read,
                        type="function",
                        function=ChatMessageToolCallFunction(
                            name="file_read",
                            arguments='{"path": "login.py"}',
                        ),
                    )
                ],
            ),
            # 响应 2：最终答案
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content=[{"type": "text", "text": "Analysis complete."}],
                tool_calls=[
                    ChatMessageToolCall(
                        id=tc_id_final,
                        type="function",
                        function=ChatMessageToolCallFunction(
                            name="final_answer",
                            arguments='{"answer": "The login function delegates to db.check for authentication."}',
                        ),
                    )
                ],
            ),
        ])

        # 运行
        harness = GuardedHarness(model=model, tools=[read_tool], config=config)
        result = harness.run("Analyze the login module")

        # 验证结果
        assert result.state == RunStatus.COMPLETED
        assert result.stop_reason == StopReason.FINAL_ANSWER
        assert result.final_answer is not None
        assert "login" in result.final_answer.lower() or "authentication" in result.final_answer.lower()

        # 验证审计轨迹
        events = harness.get_audit()
        event_types = [e.event_type for e in events]
        assert AuditEventType.RUN_STARTED in event_types
        assert AuditEventType.TOOL_EXECUTED in event_types
        assert AuditEventType.FINAL_ANSWER_ACCEPTED in event_types
        assert AuditEventType.RUN_COMPLETED in event_types

        # 验证状态
        state = harness.get_state()
        assert state.current_step >= 2  # 至少 2 步（读 + 最终答案）

        # 验证 read_tool 被调用过
        assert read_tool.call_count == 1


# ══════════════════════════════════════════════
# T2：端到端测试修复
# ══════════════════════════════════════════════


class TestEndToEndTestRepair:
    """完整流程：读代码 → 修改代码 → 跑测试 → 验证 → final_answer + 审计完整。"""

    def test_end_to_end_test_repair(self, tmp_path):
        """Agent 读取代码、分析 bug，将修复描述作为最终答案。

        仅使用 READ 能力的工具以避免审批流程，验证完整的
        多步骤代码理解和修复分析流程。

        验证：
        - 多步骤读 + 分析 + 最终答案流程完成
        - 审计轨迹包含 RUN_STARTED、TOOL_EXECUTED、FINAL_ANSWER_ACCEPTED
        - 所有工具执行均已记录
        - 状态中已记录所有步骤
        """
        # 初始化工具（均为 READ 能力，避免 auto_read 模式下触发审批）
        read_tool = FakeTool(
            name="file_read",
            inputs={"path": {"type": "string", "description": "File path"}},
            output_type="string",
        )
        read_tool.set_output("def add(a, b):\n    return a - b  # BUG: should be +")

        test_tool = FakeTool(
            name="execute_tests",
            inputs={"test_path": {"type": "string", "description": "Test path"}},
            output_type="string",
        )
        test_tool.set_output("FAIL: test_add expected 5 got -1")

        policy_read = ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        policy_test = ToolPolicy(
            tool_name="execute_tests",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        config = _make_config(
            tmp_path,
            tool_policies={"file_read": policy_read, "execute_tests": policy_test},
        )

        # 写入源文件以供指纹计算
        src_file = tmp_path / "workspace" / "math.py"
        src_file.write_text("def add(a, b):\n    return a - b\n")

        # 编排模型响应：
        # 1）读文件 → 2）跑测试 → 3）带修复描述的最终答案
        tc_read = "tc-read-001"
        tc_test = "tc-test-001"
        tc_final = "tc-final-001"

        model = FakeModel(responses=[
            # 响应 1：读取有 bug 的文件
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content=[{"type": "text", "text": "Reading the file to find the bug."}],
                tool_calls=[
                    ChatMessageToolCall(
                        id=tc_read,
                        type="function",
                        function=ChatMessageToolCallFunction(
                            name="file_read",
                            arguments='{"path": "math.py"}',
                        ),
                    )
                ],
            ),
            # 响应 2：运行测试以确认 bug
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content=[{"type": "text", "text": "Running test to confirm the bug."}],
                tool_calls=[
                    ChatMessageToolCall(
                        id=tc_test,
                        type="function",
                        function=ChatMessageToolCallFunction(
                            name="execute_tests",
                            arguments='{"test_path": "tests/test_math.py"}',
                        ),
                    )
                ],
            ),
            # 响应 3：带修复方案的最终答案
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content=[{"type": "text", "text": "Fix identified."}],
                tool_calls=[
                    ChatMessageToolCall(
                        id=tc_final,
                        type="function",
                        function=ChatMessageToolCallFunction(
                            name="final_answer",
                            arguments='{"answer": "Bug in math.py line 2: a - b should be a + b. Test confirms: expected 5 got -1."}',
                        ),
                    )
                ],
            ),
        ])

        # 运行
        harness = GuardedHarness(
            model=model, tools=[read_tool, test_tool], config=config
        )
        result = harness.run("Fix the bug in math.py")

        # 应完成
        assert result.state == RunStatus.COMPLETED
        assert result.stop_reason == StopReason.FINAL_ANSWER
        assert result.final_answer is not None
        assert "bug" in result.final_answer.lower() or "add" in result.final_answer.lower()

        # 验证完整审计轨迹
        all_events = harness.get_audit()
        all_types = [e.event_type for e in all_events]
        assert AuditEventType.RUN_STARTED in all_types
        assert AuditEventType.TOOL_EXECUTED in all_types
        assert AuditEventType.FINAL_ANSWER_ACCEPTED in all_types
        assert AuditEventType.RUN_COMPLETED in all_types

        # 统计 TOOL_EXECUTED 事件数（应至少 2 次：读 + 测试）
        tool_executed_count = sum(
            1 for e in all_events if e.event_type == AuditEventType.TOOL_EXECUTED
        )
        assert tool_executed_count >= 2

        # 验证两个工具均被调用过
        assert read_tool.call_count == 1
        assert test_tool.call_count == 1

        # 验证状态中已记录步骤
        state = harness.get_state()
        assert state.current_step >= 3  # 读 + 测试 + 最终答案


# ══════════════════════════════════════════════
# GuardedHarness 启动验证
# ══════════════════════════════════════════════


class TestGuardedHarnessStartup:
    """GuardedHarness 必须在构造时验证配置。"""

    def test_startup_rejects_missing_tool_policy(self, tmp_path):
        """注册的工具缺少策略 → ConfigurationError。"""
        read_tool = FakeTool(
            name="file_read",
            inputs={"path": {"type": "string", "description": "File path"}},
        )
        write_tool = FakeTool(
            name="file_write",
            inputs={
                "path": {"type": "string", "description": "File path"},
                "content": {"type": "string", "description": "File content"},
            },
        )
        # 仅提供 file_read 的策略，不提供 file_write 的
        policy_read = ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        config = _make_config(tmp_path, tool_policies={"file_read": policy_read})

        with pytest.raises(ConfigurationError, match="(?i)missing.*registered"):
            GuardedHarness(
                model=FakeModel(responses=[]),
                tools=[read_tool, write_tool],
                config=config,
            )

    def test_startup_accepts_matching_policies(self, tmp_path):
        """工具策略匹配 → 构造成功。"""
        read_tool = FakeTool(
            name="file_read",
            inputs={"path": {"type": "string", "description": "File path"}},
        )
        policy = ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        config = _make_config(tmp_path, tool_policies={"file_read": policy})

        harness = GuardedHarness(
            model=FakeModel(responses=[]),
            tools=[read_tool],
            config=config,
        )
        assert harness is not None

    def test_cancel_before_run_is_safe(self, tmp_path):
        """运行前调用 cancel() 不应崩溃。"""
        read_tool = FakeTool(
            name="file_read",
            inputs={"path": {"type": "string", "description": "File path"}},
        )
        policy = ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        config = _make_config(tmp_path, tool_policies={"file_read": policy})
        harness = GuardedHarness(
            model=FakeModel(responses=[]),
            tools=[read_tool],
            config=config,
        )
        # 无活动运行时调用 cancel → 应安全（无操作）
        harness.cancel()

    def test_get_audit_empty_before_run(self, tmp_path):
        """运行前调用 get_audit() 返回空列表。"""
        read_tool = FakeTool(
            name="file_read",
            inputs={"path": {"type": "string", "description": "File path"}},
        )
        policy = ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        )
        config = _make_config(tmp_path, tool_policies={"file_read": policy})
        harness = GuardedHarness(
            model=FakeModel(responses=[]),
            tools=[read_tool],
            config=config,
        )
        assert harness.get_audit() == []
        assert harness.get_checkpoint() is None
