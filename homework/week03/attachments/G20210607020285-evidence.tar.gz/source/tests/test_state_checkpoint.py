"""Guarded Coding Harness 的检查点测试。

测试覆盖检查点保存/恢复（C1）、运行锁（C3）
以及跨进程恢复（C3）。

依据 PRD §3.3 test_state_checkpoint.py（T023）。
"""

from __future__ import annotations

import uuid

import pytest

from harness.checkpoint import CheckpointManager
from harness.models import (
    BudgetInfo,
    Plan,
    PlanStep,
    RunAlreadyActiveError,
    RunState,
    RunStatus,
    StepStatus,
)
from harness.state_store import StateStore


def _make_store(tmp_path) -> StateStore:
    return StateStore(str(tmp_path / "storage"))


def _make_cp_manager(tmp_path) -> CheckpointManager:
    return CheckpointManager(str(tmp_path / "storage"))


def _make_run(store: StateStore, *, run_id: str | None = None) -> str:
    rid = run_id or str(uuid.uuid4())
    store.create_run(
        task="test task",
        max_steps=10,
        budget=BudgetInfo(),
        workspace_fingerprint="fp-001",
        run_id=rid,
    )
    return rid


# ══════════════════════════════════════════════
# C1：每步保存检查点
# ══════════════════════════════════════════════


class TestC1CheckpointSave:
    """每步保存检查点的测试。"""

    def test_checkpoint_saved_each_step(self, tmp_path):
        """3 步 → 至少 3 个检查点。"""
        store = _make_store(tmp_path)
        cp = _make_cp_manager(tmp_path)
        rid = _make_run(store)

        for i in range(1, 4):
            run_state = store.update_run(rid, current_step=i)
            cp.save(
                run_id=rid,
                step_number=i,
                run_state=run_state,
                memory_steps=[],
                workspace_fingerprint="fp-001",
            )

        seqs = cp.list_checkpoints(rid)
        assert len(seqs) >= 3

    def test_checkpoint_includes_plan_state(self, tmp_path):
        """检查点包含计划步骤、状态及 evidence_ids。"""
        store = _make_store(tmp_path)
        cp = _make_cp_manager(tmp_path)
        rid = _make_run(store)

        # 添加计划及其步骤
        store.create_plan(rid, goal="fix bug", plan_id="p1")
        store.add_plan_step(
            rid, "p1",
            PlanStep(id="s1", objective="Step 1", status=StepStatus.COMPLETED),
        )
        store.add_plan_step(
            rid, "p1",
            PlanStep(id="s2", objective="Step 2", depends_on=["s1"]),
        )

        run_state = store.get_run(rid)
        saved_cp = cp.save(
            run_id=rid,
            step_number=1,
            run_state=run_state,
            memory_steps=[],
            workspace_fingerprint="fp-001",
        )

        # 加载并验证
        loaded = cp.load(rid, saved_cp.checkpoint_seq)
        assert loaded is not None
        assert "p1" in loaded.run_state.plans
        plan = loaded.run_state.plans["p1"]
        assert len(plan.steps) == 2
        assert plan.steps[0].status == StepStatus.COMPLETED
        assert plan.steps[1].depends_on == ["s1"]


# ══════════════════════════════════════════════
# C3：跨进程恢复
# ══════════════════════════════════════════════


class TestC3CrossProcessResume:
    """跨进程检查点恢复测试。"""

    def test_checkpoint_resume_new_process(self, tmp_path):
        """运行过程中被中断（如进程被杀、系统崩溃），新进程启动后通过 checkpoint 恢复之前的运行状态，已完成的步骤进度保留，步数计数器（step_number）从中断处继续累加，而非从 0 重新开始。"""
        store = _make_store(tmp_path)
        cp = _make_cp_manager(tmp_path)
        rid = "test-run-resume"
        _make_run(store, run_id=rid)

        # 模拟已执行 3 步的进度
        for i in range(1, 4):
            run_state = store.update_run(rid, current_step=i)
            cp.save(
                run_id=rid,
                step_number=i,
                run_state=run_state,
                memory_steps=[{"step_number": i, "timing": {"start_time": 0, "end_time": 0}, "observations": f"step {i}"}],
                workspace_fingerprint="fp-001",
            )

        # “新进程”加载最新检查点
        latest = cp.load_latest(rid)
        assert latest is not None
        assert latest.step_number == 3
        # 步数计数应从 4 继续（step_number + 1）
        assert latest.step_number + 1 == 4

    def test_checkpoint_run_lock_allows_only_one_resumer(self, tmp_path):
        """：同一时刻，只有一个进程能持有运行锁"""
        cp = _make_cp_manager(tmp_path)
        rid = "test-run-lock"

        # 进程 1 获取锁
        cp.acquire_run_lock(rid)

        # 进程 2 应失败
        cp2 = CheckpointManager(str(tmp_path / "storage"))
        with pytest.raises(RunAlreadyActiveError):
            cp2.acquire_run_lock(rid)

        # 释放后再次尝试
        cp.release_run_lock(rid)
        cp2.acquire_run_lock(rid)
        cp2.release_run_lock(rid)

    def test_checkpoint_resume_plan_progress_preserved(self, tmp_path):
        """复运行后，已完成的计划步骤仍然保持"""
        store = _make_store(tmp_path)
        cp = _make_cp_manager(tmp_path)
        rid = "test-plan-resume"
        _make_run(store, run_id=rid)

        # 创建计划及其步骤
        store.create_plan(rid, goal="build feature", plan_id="p1")
        store.add_plan_step(
            rid, "p1",
            PlanStep(id="s1", objective="Step 1", status=StepStatus.COMPLETED),
        )
        store.add_plan_step(
            rid, "p1",
            PlanStep(id="s2", objective="Step 2", depends_on=["s1"], status=StepStatus.IN_PROGRESS),
        )

        run_state = store.get_run(rid)
        cp.save(
            run_id=rid,
            step_number=2,
            run_state=run_state,
            memory_steps=[],
            workspace_fingerprint="fp-001",
        )

        # “新进程”恢复
        latest = cp.load_latest(rid)
        assert latest is not None
        plan = latest.run_state.plans["p1"]
        assert plan.steps[0].status == StepStatus.COMPLETED
        assert plan.steps[1].status == StepStatus.IN_PROGRESS


# ══════════════════════════════════════════════
# C2：未知结果恢复
# ══════════════════════════════════════════════


class TestC2UnknownResult:
    """未知结果检测与恢复测试。"""

    def test_checkpoint_unknown_result(self, tmp_path):
        """TOOL_STARTED without result → UNKNOWN_RESULT, no auto-replay."""
        from harness.audit import AuditLogger
        from harness.harness import HarnessRunner
        from harness.models import (
            AuditEvent,
            AuditEventType,
            HarnessConfig,
            StopReason,
            ToolCapability,
            ToolPolicy,
        )
        from harness.state_store import StateStore
        from tests.conftest import FakeModel, FakeTool
        import uuid as _uuid

        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir()
        storage = str(tmp_path / "storage")

        from harness.models import SandboxConfig

        sandbox_cfg = SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=10_000_000,
        )
        config = HarnessConfig(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox_cfg,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=5,
        )

        audit = AuditLogger(storage)
        store = StateStore(storage)

        # 初始化：创建运行并模拟 TOOL_STARTED 但无结果
        rid = "test-unknown-result"
        store.create_run(
            task="test", max_steps=5,
            budget=BudgetInfo(), workspace_fingerprint="fp",
            run_id=rid,
        )

        # 模拟 TOOL_STARTED WAL，但没有对应的结果事件
        tc_id = "tc-write-001"
        audit.log(AuditEvent(
            event_id=str(_uuid.uuid4()),
            event_type=AuditEventType.TOOL_STARTED,
            run_id=rid,
            tool_call_id=tc_id,
            tool_name="file_write",
            actor="system",
            detail="WAL: tool_started for file_write",
        ))

        tool = FakeTool(name="file_write")
        policy = ToolPolicy(
            tool_name="file_write",
            capabilities={ToolCapability.WRITE},
            controlled=True, requires_approval=False,
        )
        config.tool_policies = {"file_write": policy}

        model = FakeModel(responses=[])
        runner = HarnessRunner(
            model=model, tools=[tool], config=config,
            audit=audit, state_store=store,
        )
        runner._run_state = store.get_run(rid)

        # 检测未知结果
        unknown = runner.detect_unknown_results(rid)
        assert tc_id in unknown

    def test_checkpoint_unknown_result_confirmed_executed(self, tmp_path):
        """人工确认"已执行" → 记录结果，不重放"""
        from harness.audit import AuditLogger
        from harness.harness import HarnessRunner
        from harness.models import (
            AuditEventType,
            HarnessConfig,
            RunStatus,
            ToolCapability,
            ToolPolicy,
        )
        from harness.state_store import StateStore
        from tests.conftest import FakeModel, FakeTool

        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir()
        storage = str(tmp_path / "storage")

        from harness.models import SandboxConfig

        sandbox_cfg = SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=10_000_000,
        )
        config = HarnessConfig(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox_cfg,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=5,
        )

        audit = AuditLogger(storage)
        store = StateStore(storage)

        # 初始化：创建运行并模拟 TOOL_STARTED 但无结果
        rid = "test-unknown-executed"
        store.create_run(
            task="test", max_steps=5,
            budget=BudgetInfo(), workspace_fingerprint="fp",
            run_id=rid,
        )

        # 写入 TOOL_STARTED 但不写入结果
        from harness.models import AuditEvent
        import uuid as _uuid

        tc_id = "tc-001"
        audit.log(AuditEvent(
            event_id=str(_uuid.uuid4()),
            event_type=AuditEventType.TOOL_STARTED,
            run_id=rid,
            tool_call_id=tc_id,
            tool_name="file_write",
            actor="system",
            detail="WAL",
        ))

        tool = FakeTool(name="file_write")
        policy = ToolPolicy(
            tool_name="file_write",
            capabilities={ToolCapability.WRITE},
            controlled=True, requires_approval=False,
        )
        config.tool_policies = {"file_write": policy}

        model = FakeModel(responses=[])
        runner = HarnessRunner(
            model=model, tools=[tool], config=config,
            audit=audit, state_store=store,
        )
        runner._run_state = store.get_run(rid)

        # 检测
        unknown = runner.detect_unknown_results(rid)
        assert tc_id in unknown

        # 确认为已执行（EXECUTED）
        runner.resolve_unknown_result(
            rid, tc_id, "EXECUTED", "admin", "File was written successfully"
        )

        # 不再有未知结果
        unknown2 = runner.detect_unknown_results(rid)
        assert tc_id not in unknown2

        # 审计日志应包含 UNKNOWN_RESULT_RESOLVED + 合成的 TOOL_EXECUTED
        events = audit.query(tool_call_id=tc_id)
        types = [e.event_type for e in events]
        assert AuditEventType.UNKNOWN_RESULT_RESOLVED in types
        assert AuditEventType.TOOL_EXECUTED in types

    def test_checkpoint_unknown_result_confirmed_not_executed(self, tmp_path):
        """人工确认"未执行" → 重新进入关卡"""
        from harness.audit import AuditLogger
        from harness.harness import HarnessRunner
        from harness.models import (
            AuditEvent,
            AuditEventType,
            HarnessConfig,
            ToolCapability,
            ToolPolicy,
        )
        from harness.state_store import StateStore
        from tests.conftest import FakeModel, FakeTool
        import uuid as _uuid

        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir()
        storage = str(tmp_path / "storage")

        from harness.models import SandboxConfig

        sandbox_cfg = SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=10_000_000,
        )
        config = HarnessConfig(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox_cfg,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=5,
        )

        audit = AuditLogger(storage)
        store = StateStore(storage)

        rid = "test-unknown-not-executed"
        store.create_run(
            task="test", max_steps=5,
            budget=BudgetInfo(), workspace_fingerprint="fp",
            run_id=rid,
        )

        tc_id = "tc-002"
        audit.log(AuditEvent(
            event_id=str(_uuid.uuid4()),
            event_type=AuditEventType.TOOL_STARTED,
            run_id=rid,
            tool_call_id=tc_id,
            tool_name="file_write",
            actor="system",
            detail="WAL",
        ))

        tool = FakeTool(name="file_write")
        policy = ToolPolicy(
            tool_name="file_write",
            capabilities={ToolCapability.WRITE},
            controlled=True, requires_approval=False,
        )
        config.tool_policies = {"file_write": policy}

        model = FakeModel(responses=[])
        runner = HarnessRunner(
            model=model, tools=[tool], config=config,
            audit=audit, state_store=store,
        )
        runner._run_state = store.get_run(rid)

        # 确认为未执行（NOT_EXECUTED）
        runner.resolve_unknown_result(
            rid, tc_id, "NOT_EXECUTED", "admin"
        )

        # 审计日志应包含 UNKNOWN_RESULT_RESOLVED，但不含合成的 TOOL_EXECUTED
        events = audit.query(tool_call_id=tc_id)
        types = [e.event_type for e in events]
        assert AuditEventType.UNKNOWN_RESULT_RESOLVED in types
        # NOT_EXECUTED：无合成的 TOOL_EXECUTED → 检测仍会标记
        # （恢复时将重新进入 Gate）
        assert AuditEventType.TOOL_EXECUTED not in types

    def test_checkpoint_preserves_pending_tool_batch_on_approval(self, tmp_path):
        """：审批暂停时，未完成的工具调用批次被保存 → 恢复后继续处理剩余调用"""
        from harness.models import PendingToolBatch

        store = _make_store(tmp_path)
        cp = _make_cp_manager(tmp_path)
        rid = "test-pending-batch"
        _make_run(store, run_id=rid)

        # 添加待处理的工具调用批次
        batch = PendingToolBatch(
            step_number=1,
            model_response={"text": "calling tools"},
            tool_calls=[
                {"id": "tc-1", "name": "tool_a", "arguments": {}},
                {"id": "tc-2", "name": "tool_b", "arguments": {}},
            ],
            next_call_index=1,  # 第一个工具已完成，第二个待处理
            waiting_tool_call_id="tc-2",
        )
        store.update_run(rid, pending_tool_batches=[batch])

        run_state = store.get_run(rid)
        cp.save(
            run_id=rid, step_number=1,
            run_state=run_state, memory_steps=[],
            workspace_fingerprint="fp-001",
        )

        # 恢复
        latest = cp.load_latest(rid)
        assert latest is not None
        assert len(latest.run_state.pending_tool_batches) == 1
        batch_loaded = latest.run_state.pending_tool_batches[0]
        assert batch_loaded.next_call_index == 1
        assert batch_loaded.waiting_tool_call_id == "tc-2"
        assert len(batch_loaded.tool_calls) == 2


# ══════════════════════════════════════════════
# C4：工作区变更检测
# ══════════════════════════════════════════════


class TestC4WorkspaceChange:
    """恢复时工作区变更检测测试。"""

    def test_checkpoint_workspace_changed(self, tmp_path):
        """恢复时工作区指纹不同 → FAILED + WORKSPACE_CHANGED。"""
        from harness.harness import HarnessRunner
        from harness.models import (
            HarnessConfig,
            RunStatus,
            SandboxConfig,
            StopReason,
        )
        from tests.conftest import FakeModel, FakeTool
        from smolagents.models import ChatMessage, MessageRole

        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir()
        storage = str(tmp_path / "storage")

        sandbox_cfg = SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=10_000_000,
        )
        config = HarnessConfig(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox_cfg,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=5,
        )

        # 第 1 步：以初始指纹运行，保存检查点（max_steps=1 以快速结束）
        config_run1 = HarnessConfig(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox_cfg,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=1,
        )
        model1 = FakeModel(responses=[
            ChatMessage(
                role=MessageRole.ASSISTANT,
                content=[{"type": "text", "text": "working"}],
                tool_calls=[],
            ),
        ])
        tool = FakeTool(name="file_read")
        from harness.models import ToolPolicy, ToolCapability
        config_run1.tool_policies = {"file_read": ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True, requires_approval=False,
        )}

        cp_manager = CheckpointManager(storage)
        runner1 = HarnessRunner(
            model=model1, tools=[tool], config=config_run1,
            checkpoint_manager=cp_manager,
        )
        result1 = runner1.run("task1")
        rid = result1.run_state.run_id

        # 第 2 步：修改工作区以改变指纹
        (tmp_path / "workspace" / "new_file.py").write_text("# changed")

        # 第 3 步：以不同指纹恢复运行
        model2 = FakeModel(responses=[])
        tool2 = FakeTool(name="file_read")
        config.tool_policies = {"file_read": ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True, requires_approval=False,
        )}
        cp_manager2 = CheckpointManager(storage)
        runner2 = HarnessRunner(
            model=model2, tools=[tool2], config=config,
            checkpoint_manager=cp_manager2,
        )
        result2 = runner2.run("task1", reset=False, resume_run_id=rid)

        # 应检测到工作区变更并停止
        assert result2.state == RunStatus.FAILED
        assert result2.stop_reason == StopReason.WORKSPACE_CHANGED

    def test_checkpoint_workspace_changed_invalidates_evidence(self, tmp_path):
        """工作区变更 → TEST/DIFF 证据失效为 STALE；仅回滚有必需证据的步骤。"""
        from harness.harness import HarnessRunner
        from harness.models import (
            Evidence,
            EvidenceKind,
            EvidenceStatus,
            HarnessConfig,
            PlanStep,
            RunStatus,
            SandboxConfig,
            StepStatus,
            StopReason,
            ToolCapability,
            ToolPolicy,
        )
        from harness.state_store import StateStore
        from tests.conftest import FakeModel, FakeTool
        from smolagents.models import ChatMessage, MessageRole
        from datetime import datetime

        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir()
        storage = str(tmp_path / "storage")

        sandbox_cfg = SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=[],
            allowed_env_vars=["PATH"],
            blocked_env_vars=[],
            max_file_size=10_000_000,
        )
        config = HarnessConfig(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox_cfg,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=5,
        )

        store = StateStore(storage)
        cp_manager = CheckpointManager(storage)

        # 初始化：创建运行、计划、证据并保存检查点
        rid = "ws-change-evidence"
        run = store.create_run(
            task="test", max_steps=5,
            budget=BudgetInfo(), workspace_fingerprint="fp-old",
            run_id=rid,
        )

        # 创建计划及其步骤
        store.create_plan(rid, goal="fix", plan_id="p1")
        store.set_active_plan(rid, "p1")

        # 步骤 s1：COMPLETED，需要 TEST 类型证据
        store.add_plan_step(rid, "p1", PlanStep(
            id="s1", objective="test step",
            status=StepStatus.COMPLETED,
            required_evidence_kinds=[EvidenceKind.TEST],
            evidence_ids=["ev1"],
        ))
        # 步骤 s2：COMPLETED，证据类型为 INSPECTION（非必需 TEST 类型）
        store.add_plan_step(rid, "p1", PlanStep(
            id="s2", objective="inspect step",
            status=StepStatus.COMPLETED,
            required_evidence_kinds=[],
            evidence_ids=["ev2"],
        ))

        # 添加证据
        store.add_evidence(rid, Evidence(
            id="ev1", step_id="s1", tool_call_id="tc1",
            artifact_version="v1",
            kind=EvidenceKind.TEST,
            summary="test passed",
            payload={},
            created_at=datetime.now(),
        ))
        store.add_evidence(rid, Evidence(
            id="ev2", step_id="s2", tool_call_id="tc2",
            artifact_version="v1",
            kind=EvidenceKind.INSPECTION,
            summary="inspection done",
            payload={},
            created_at=datetime.now(),
        ))

        # 保存检查点
        run_state = store.get_run(rid)
        cp_manager.save(
            run_id=rid, step_number=2,
            run_state=run_state, memory_steps=[],
            workspace_fingerprint="fp-old",
        )

        # 修改工作区
        (tmp_path / "workspace" / "changed.py").write_text("# modified")

        # 恢复 — 应检测到工作区变更
        model = FakeModel(responses=[])
        tool = FakeTool(name="file_read")
        config.tool_policies = {"file_read": ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True, requires_approval=False,
        )}
        cp_manager2 = CheckpointManager(storage)
        runner = HarnessRunner(
            model=model, tools=[tool], config=config,
            checkpoint_manager=cp_manager2,
        )
        result = runner.run("test", reset=False, resume_run_id=rid)

        # 验证工作区变更已检测
        assert result.state == RunStatus.FAILED
        assert result.stop_reason == StopReason.WORKSPACE_CHANGED

        # 验证证据失效处理
        run_after = store.get_run(rid)
        ev1 = run_after.evidence_store["ev1"]
        ev2 = run_after.evidence_store["ev2"]

        # TEST 证据应失效为 STALE（artifact_version 不匹配）
        assert ev1.status == EvidenceStatus.STALE
        # INSPECTION 证据应保持有效（非 TEST/DIFF 类型）
        assert ev2.status == EvidenceStatus.VALID

        # 步骤 s1 应回滚为 IN_PROGRESS（所需的 TEST 证据已失效）
        plan = run_after.plans["p1"]
        s1 = next(s for s in plan.steps if s.id == "s1")
        assert s1.status == StepStatus.IN_PROGRESS

        # 步骤 s2 应保持 COMPLETED（无必需的证据类型受影响）
        s2 = next(s for s in plan.steps if s.id == "s2")
        assert s2.status == StepStatus.COMPLETED


# ══════════════════════════════════════════════
# 测试辅助函数
# ══════════════════════════════════════════════


def _remove_audit_events(storage_path: str, run_id: str, event_types: set) -> None:
    """从 JSONL 文件中移除指定类型的审计事件（仅供测试使用）。"""
    import json
    from pathlib import Path

    audit_file = Path(storage_path) / "audit" / f"{run_id}.jsonl"
    if not audit_file.exists():
        return
    lines = audit_file.read_text(encoding="utf-8").strip().split("\n")
    kept = []
    for line in lines:
        if not line.strip():
            continue
        data = json.loads(line)
        if data.get("event_type") not in {et.value for et in event_types}:
            kept.append(line)
    audit_file.write_text("\n".join(kept) + "\n" if kept else "", encoding="utf-8")
