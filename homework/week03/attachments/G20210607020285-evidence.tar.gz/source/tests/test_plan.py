"""Plan module tests for the Guarded Coding Harness.

Tests cover Plan creation, dependency scheduling, evidence-based acceptance,
revision control, and PlanContextStep injection.

Per PRD §3.3 test_plan.py (T014).
"""

from __future__ import annotations

import uuid
from datetime import datetime

import pytest

from harness.models import (
    AcceptanceCheck,
    BudgetInfo,
    Evidence,
    EvidenceKind,
    EvidenceStatus,
    Plan,
    PlanRevisionLimitError,
    PlanStep,
    StepStatus,
)
from harness.state_store import (
    PlanContextStep,
    StateStore,
    prepare_plan_context,
)


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────


def _make_store(tmp_path) -> StateStore:
    return StateStore(str(tmp_path / "storage"))


def _make_run(store: StateStore, *, run_id: str | None = None) -> str:
    """Create a minimal Run and return its run_id."""
    rid = run_id or str(uuid.uuid4())
    store.create_run(
        task="test task",
        max_steps=10,
        budget=BudgetInfo(),
        workspace_fingerprint="fp-001",
        run_id=rid,
    )
    return rid


def _step(sid: str, *, depends_on=None, required_kinds=None, status=None) -> PlanStep:
    return PlanStep(
        id=sid,
        objective=f"Objective for {sid}",
        depends_on=depends_on or [],
        required_evidence_kinds=required_kinds or [],
        status=status or StepStatus.PENDING,
    )


def _evidence(
    eid: str,
    step_id: str,
    kind: EvidenceKind = EvidenceKind.TEST,
    version: str = "v1",
    status: EvidenceStatus = EvidenceStatus.VALID,
) -> Evidence:
    return Evidence(
        id=eid,
        step_id=step_id,
        tool_call_id=f"tc-{eid}",
        artifact_version=version,
        kind=kind,
        summary=f"Evidence for {eid}",
        payload={},
        created_at=datetime.now(),
        status=status,
    )


# ══════════════════════════════════════════════
# P1: Plan creation
# ══════════════════════════════════════════════


class TestP1PlanCreation:
    """Tests for creating Plans."""

    def test_create_plan(self, tmp_path):
        store = _make_store(tmp_path)
        rid = _make_run(store)

        plan = store.create_plan(rid, goal="Build feature X", plan_id="plan-1")
        assert plan.goal == "Build feature X"
        assert plan.version == 1
        assert plan.revision_count == 0

        # Retrieve it
        loaded = store.get_plan(rid, "plan-1")
        assert loaded is not None
        assert loaded.goal == "Build feature X"

    def test_create_plan_with_constraints(self, tmp_path):
        store = _make_store(tmp_path)
        rid = _make_run(store)

        plan = store.create_plan(
            rid,
            goal="Fix auth bug",
            constraints=["Don't modify DB schema", "No new dependencies"],
            plan_id="plan-2",
        )
        assert len(plan.constraints) == 2
        assert "Don't modify DB schema" in plan.constraints


# ══════════════════════════════════════════════
# P2: Dependency scheduling
# ══════════════════════════════════════════════


class TestP2DependencyScheduling:
    """Tests for step dependency rules."""

    def test_plan_step_no_dependency_executable(self, tmp_path):
        """Steps with no dependencies → immediately executable."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1"))

        executable = store.get_next_executable_steps(rid, pid)
        assert len(executable) == 1
        assert executable[0].id == "step-1"

    def test_plan_step_dependency_not_met(self, tmp_path):
        """Steps with unmet dependencies → not executable."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1"))
        store.add_plan_step(rid, pid, _step("step-2", depends_on=["step-1"]))

        executable = store.get_next_executable_steps(rid, pid)
        ids = [s.id for s in executable]
        assert "step-1" in ids
        assert "step-2" not in ids

    def test_plan_step_all_dependencies_completed(self, tmp_path):
        """Steps whose dependencies are all COMPLETED → executable."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", status=StepStatus.COMPLETED))
        store.add_plan_step(rid, pid, _step("step-2", depends_on=["step-1"]))

        executable = store.get_next_executable_steps(rid, pid)
        ids = [s.id for s in executable]
        assert "step-2" in ids

    def test_plan_step_dependency_failed(self, tmp_path):
        """Steps with a FAILED dependency → not executable."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", status=StepStatus.FAILED))
        store.add_plan_step(rid, pid, _step("step-2", depends_on=["step-1"]))

        executable = store.get_next_executable_steps(rid, pid)
        ids = [s.id for s in executable]
        assert "step-2" not in ids

    def test_plan_step_unblocked_when_dependencies_complete(self, tmp_path):
        """BLOCKED step unblocks when all dependencies become COMPLETED."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", status=StepStatus.IN_PROGRESS))
        store.add_plan_step(rid, pid, _step("step-2", depends_on=["step-1"]))

        # step-2 should not be executable yet
        assert "step-2" not in [s.id for s in store.get_next_executable_steps(rid, pid)]

        # Complete step-1
        store.update_plan_step(rid, pid, "step-1", status=StepStatus.COMPLETED)

        # step-2 should now be executable
        assert "step-2" in [s.id for s in store.get_next_executable_steps(rid, pid)]


# ══════════════════════════════════════════════
# P3: Evidence-based acceptance
# ══════════════════════════════════════════════


class TestP3EvidenceAcceptance:
    """Tests for evidence-based step completion."""

    def test_evidence_from_run_test(self, tmp_path):
        """run_test generates TEST evidence linked to step."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", required_kinds=[EvidenceKind.TEST]))

        ev = _evidence("ev-1", "step-1", kind=EvidenceKind.TEST)
        store.add_evidence(rid, ev)

        retrieved = store.get_step_evidence(rid, "step-1")
        assert len(retrieved) == 1
        assert retrieved[0].kind == EvidenceKind.TEST

    def test_plan_step_completed_with_evidence(self, tmp_path):
        """Step with required evidence kinds and valid evidence → acceptance passes."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", required_kinds=[EvidenceKind.TEST]))

        ev = _evidence("ev-1", "step-1", kind=EvidenceKind.TEST)
        store.add_evidence(rid, ev)

        assert store.evaluate_step_acceptance(rid, pid, "step-1") is True

    def test_plan_step_requires_machine_acceptance_checks(self, tmp_path):
        """Step without evidence → acceptance fails."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", required_kinds=[EvidenceKind.TEST]))

        # No evidence added → should fail
        assert store.evaluate_step_acceptance(rid, pid, "step-1") is False

    def test_evidence_invalidated_on_code_change(self, tmp_path):
        """TEST evidence with stale artifact_version → marked STALE."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1", required_kinds=[EvidenceKind.TEST]))

        ev = _evidence("ev-1", "step-1", kind=EvidenceKind.TEST, version="v1")
        store.add_evidence(rid, ev)

        # Mark step as completed
        store.update_plan_step(rid, pid, "step-1", status=StepStatus.COMPLETED)

        # Code changes → v2
        stale = store.invalidate_stale_evidence(rid, "v2")
        assert "ev-1" in stale

        # Step should be rolled back to IN_PROGRESS
        run = store.get_run(rid)
        step = run.plans[pid].steps[0]
        assert step.status == StepStatus.IN_PROGRESS

    def test_stale_non_required_evidence_does_not_reopen_step(self, tmp_path):
        """Non-required stale evidence does NOT reopen a COMPLETED step."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        # Step requires TEST evidence only
        store.add_plan_step(rid, pid, _step("step-1", required_kinds=[EvidenceKind.TEST]))

        # Add TEST evidence (required) and DIFF evidence (not required)
        ev_test = _evidence("ev-test", "step-1", kind=EvidenceKind.TEST, version="v1")
        ev_diff = _evidence("ev-diff", "step-1", kind=EvidenceKind.DIFF, version="v1")
        store.add_evidence(rid, ev_test)
        store.add_evidence(rid, ev_diff)

        store.update_plan_step(rid, pid, "step-1", status=StepStatus.COMPLETED)

        # Invalidate: both become stale, but only TEST is required
        # Since TEST is required and becomes stale, step should rollback
        stale = store.invalidate_stale_evidence(rid, "v2")
        assert "ev-test" in stale
        assert "ev-diff" in stale

        run = store.get_run(rid)
        step = run.plans[pid].steps[0]
        # Step should be rolled back because required TEST evidence is stale
        assert step.status == StepStatus.IN_PROGRESS


# ══════════════════════════════════════════════
# P4: Plan revision
# ══════════════════════════════════════════════


class TestP4PlanRevision:
    """Tests for plan revision."""

    def test_revise_plan_add_step(self, tmp_path):
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid)
        store.add_plan_step(rid, pid, _step("step-1"))

        revised = store.revise_plan(
            rid, pid,
            new_steps=[_step("step-2")],
        )
        assert len(revised.steps) == 2
        assert revised.version == 2
        assert revised.revision_count == 1

    def test_revise_plan_max_revisions(self, tmp_path):
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="test", plan_id=pid, max_revisions=2)

        # Revise twice (at limit)
        store.revise_plan(rid, pid, new_steps=[_step("s1")])
        store.revise_plan(rid, pid, new_steps=[_step("s2")])

        # Third revision should fail
        with pytest.raises(PlanRevisionLimitError):
            store.revise_plan(rid, pid, new_steps=[_step("s3")])


# ══════════════════════════════════════════════
# P5: PlanContextStep injection
# ══════════════════════════════════════════════


class TestP5PlanContextStep:
    """Tests for PlanContextStep and prepare_plan_context."""

    def test_plan_context_step_injected_by_harness_runner(self, tmp_path):
        """PlanContextStep produces a message with Plan summary."""
        summary = "=== Plan: fix auth bug ==="
        step = PlanContextStep(plan_summary=summary)
        messages = step.to_messages()
        assert len(messages) == 1
        assert summary in messages[0].content[0]["text"]

    def test_plan_context_step_contains_executable_steps(self, tmp_path):
        """prepare_plan_context includes executable step IDs."""
        store = _make_store(tmp_path)
        rid = _make_run(store)
        pid = "plan-1"
        store.create_plan(rid, goal="Build feature", plan_id=pid)
        store.set_active_plan(rid, pid)
        store.add_plan_step(rid, pid, _step("step-1"))
        store.add_plan_step(rid, pid, _step("step-2", depends_on=["step-1"]))

        context = prepare_plan_context(rid, store)
        assert "step-1" in context
        assert "下一步可执行" in context
