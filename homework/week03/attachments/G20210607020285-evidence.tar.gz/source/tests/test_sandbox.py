"""Config validation and Sandbox module tests for the Guarded Coding Harness.

Tests verify that load_and_validate_toml() and validate_config() reject
invalid configurations, and that the Sandbox enforces path safety,
command whitelisting, environment filtering, timeouts, and size limits.

Per PRD §3.3 test_sandbox.py — config validation (T008) + sandbox (T012).
"""

from __future__ import annotations

import textwrap
from pathlib import Path
from unittest.mock import patch

import pytest

from harness.config import load_and_validate_toml, validate_config
from harness.models import (
    CommandPolicy,
    ConfigurationError,
    HarnessConfig,
    SandboxConfig,
    ToolCapability,
    ToolPolicy,
)


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────


def _write_toml(tmp_path: Path, content: str) -> Path:
    """Write TOML content to a temp file and return its path."""
    p = tmp_path / "config.toml"
    p.write_text(textwrap.dedent(content), encoding="utf-8")
    return p


def _minimal_valid_toml(tmp_path: Path) -> str:
    """Return a minimal valid TOML string using tmp_path for all paths."""
    workspace = tmp_path / "workspace"
    workspace.mkdir(exist_ok=True)
    storage = tmp_path / "storage"
    storage.mkdir(exist_ok=True)
    # checkpointer must be OUTSIDE workspace
    checkpointer = tmp_path / "approval.sqlite"
    return f"""\
        [harness]
        workspace_root = "{workspace}"
        storage_path = "{storage}"
        max_steps = 10

        [approval]
        checkpointer_path = "{checkpointer}"

        [sandbox]
        workspace_root = "{workspace}"
        allowed_dirs = ["."]
        sensitive_dirs = ["/etc"]
    """


# ──────────────────────────────────────────────
# Missing required fields
# ──────────────────────────────────────────────


class TestMissingRequiredFields:
    """Config must reject missing required sections and fields."""

    def test_missing_harness_section(self, tmp_path):
        toml = _write_toml(
            tmp_path,
            f"""\
            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{tmp_path}/workspace"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="Missing required section.*harness"):
            load_and_validate_toml(toml)

    def test_missing_sandbox_section(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"
            """,
        )
        with pytest.raises(ConfigurationError, match="Missing required section.*sandbox"):
            load_and_validate_toml(toml)

    def test_missing_workspace_root_in_harness(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="workspace_root"):
            load_and_validate_toml(toml)

    def test_missing_storage_path(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="storage_path"):
            load_and_validate_toml(toml)

    def test_missing_checkpointer_path(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"

            [approval]

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="checkpointer_path"):
            load_and_validate_toml(toml)

    def test_missing_allowed_dirs(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="allowed_dirs"):
            load_and_validate_toml(toml)

    def test_missing_sensitive_dirs(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            """,
        )
        with pytest.raises(ConfigurationError, match="sensitive_dirs"):
            load_and_validate_toml(toml)

    def test_empty_string_field_rejected(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = ""
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="non-empty string"):
            load_and_validate_toml(toml)


# ──────────────────────────────────────────────
# Workspace root mismatch
# ──────────────────────────────────────────────


class TestWorkspaceRootMismatch:
    """Config must reject mismatched workspace_root between [harness] and [sandbox]."""

    def test_workspace_root_mismatch_rejected(self, tmp_path):
        ws1 = tmp_path / "workspace_a"
        ws1.mkdir(exist_ok=True)
        ws2 = tmp_path / "workspace_b"
        ws2.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{ws1}"
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{ws2}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="workspace_root mismatch"):
            load_and_validate_toml(toml)

    def test_workspace_root_match_accepted(self, tmp_path):
        """Valid config with matching workspace_root should load without error."""
        toml_path = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        config = load_and_validate_toml(toml_path)
        assert config.workspace_root == str((tmp_path / "workspace").resolve())


# ──────────────────────────────────────────────
# Env var overlap
# ──────────────────────────────────────────────


class TestEnvVarOverlap:
    """Config must reject overlapping allowed_env_vars and blocked_env_vars."""

    def test_env_var_overlap_rejected(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            allowed_env_vars = ["PATH", "SECRET_KEY"]
            blocked_env_vars = ["SECRET_KEY", "API_KEY"]
            """,
        )
        with pytest.raises(ConfigurationError, match="overlap.*SECRET_KEY"):
            load_and_validate_toml(toml)

    def test_env_var_no_overlap_accepted(self, tmp_path):
        """Valid config with non-overlapping env vars should load."""
        toml_path = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        config = load_and_validate_toml(toml_path)
        assert isinstance(config.sandbox_config.allowed_env_vars, list)


# ──────────────────────────────────────────────
# Tool policy mismatch
# ──────────────────────────────────────────────


class TestToolPolicyMismatch:
    """validate_config() must reject tool policies that don't match registered tools."""

    def _make_config_with_policies(self, tmp_path, policies: dict) -> HarnessConfig:
        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir(exist_ok=True)
        sandbox = SandboxConfig(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=["/etc"],
        )
        return HarnessConfig(
            workspace_root=workspace,
            storage_path=str(tmp_path / "storage"),
            sandbox_config=sandbox,
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            tool_policies=policies,
        )

    def test_missing_policy_for_registered_tool(self, tmp_path):
        config = self._make_config_with_policies(tmp_path, {})
        registered = {"file_read", "file_write"}
        with pytest.raises(ConfigurationError, match="missing.*registered"):
            validate_config(config, registered_tool_names=registered)

    def test_extra_policy_for_unknown_tool(self, tmp_path):
        policies = {
            "file_read": ToolPolicy(
                tool_name="file_read",
                capabilities={ToolCapability.READ},
                controlled=True,
                requires_approval=False,
            ),
            "ghost_tool": ToolPolicy(
                tool_name="ghost_tool",
                capabilities={ToolCapability.READ},
                controlled=True,
                requires_approval=False,
            ),
        }
        config = self._make_config_with_policies(tmp_path, policies)
        registered = {"file_read"}
        with pytest.raises(ConfigurationError, match="unknown tools"):
            validate_config(config, registered_tool_names=registered)

    def test_exact_match_accepted(self, tmp_path):
        policies = {
            "file_read": ToolPolicy(
                tool_name="file_read",
                capabilities={ToolCapability.READ},
                controlled=True,
                requires_approval=False,
            ),
        }
        config = self._make_config_with_policies(tmp_path, policies)
        # Should not raise
        validate_config(config, registered_tool_names={"file_read"})

    def test_no_registered_tools_skips_check(self, tmp_path):
        """When registered_tool_names is None, tool policy check is skipped."""
        config = self._make_config_with_policies(tmp_path, {})
        validate_config(config, registered_tool_names=None)  # should not raise


# ──────────────────────────────────────────────
# Unknown fields
# ──────────────────────────────────────────────


class TestUnknownFields:
    """Config must report unknown fields in any section."""

    def test_unknown_top_level_section(self, tmp_path):
        toml_content = _minimal_valid_toml(tmp_path) + "\n[mystery]\nfoo = 1\n"
        toml = _write_toml(tmp_path, toml_content)
        with pytest.raises(ConfigurationError, match="Unknown top-level section.*mystery"):
            load_and_validate_toml(toml)

    def test_unknown_field_in_harness(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml_content = _minimal_valid_toml(tmp_path) + "\n"
        # Inject unknown key into [harness] by rewriting
        toml_content = toml_content.replace(
            "max_steps = 10",
            'max_steps = 10\nmystery_field = "oops"',
        )
        toml = _write_toml(tmp_path, toml_content)
        with pytest.raises(ConfigurationError, match="Unknown fields.*harness.*mystery_field"):
            load_and_validate_toml(toml)

    def test_unknown_field_in_sandbox(self, tmp_path):
        toml_content = _minimal_valid_toml(tmp_path)
        toml_content += 'mystery_sandbox_key = "bad"\n'
        toml = _write_toml(tmp_path, toml_content)
        with pytest.raises(ConfigurationError, match="Unknown fields.*sandbox.*mystery_sandbox_key"):
            load_and_validate_toml(toml)

    def test_unknown_field_in_approval(self, tmp_path):
        toml_content = _minimal_valid_toml(tmp_path)
        toml_content += '\n[approval]\nextra_key = "bad"\n'
        # The minimal toml already has [approval], so we need to append under it.
        # Let's build from scratch instead:
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml_content = f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"
            max_steps = 10

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"
            extra_key = "bad"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
        """
        toml = _write_toml(tmp_path, toml_content)
        with pytest.raises(ConfigurationError, match="Unknown fields.*approval.*extra_key"):
            load_and_validate_toml(toml)


# ──────────────────────────────────────────────
# Windows platform check
# ──────────────────────────────────────────────


class TestPlatformCheck:
    """Config must reject non-POSIX (Windows) platforms."""

    def test_windows_platform_rejected(self, tmp_path):
        toml = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        with patch("harness.config.platform") as mock_platform:
            mock_platform.system.return_value = "Windows"
            with pytest.raises(ConfigurationError, match="POSIX"):
                load_and_validate_toml(toml)

    def test_linux_platform_accepted(self, tmp_path):
        toml = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        with patch("harness.config.platform") as mock_platform:
            mock_platform.system.return_value = "Linux"
            config = load_and_validate_toml(toml)
            assert config is not None

    def test_macos_platform_accepted(self, tmp_path):
        toml = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        with patch("harness.config.platform") as mock_platform:
            mock_platform.system.return_value = "Darwin"
            config = load_and_validate_toml(toml)
            assert config is not None


# ──────────────────────────────────────────────
# Checkpointer path inside workspace
# ──────────────────────────────────────────────


class TestCheckpointerPathInWorkspace:
    """Config must reject checkpointer_path that is inside workspace_root."""

    def test_checkpointer_path_in_workspace_rejected(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        # checkpointer INSIDE workspace → should fail
        checkpointer = workspace / "approval.sqlite"
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"

            [approval]
            checkpointer_path = "{checkpointer}"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            """,
        )
        with pytest.raises(ConfigurationError, match="outside workspace_root"):
            load_and_validate_toml(toml)

    def test_checkpointer_path_outside_workspace_accepted(self, tmp_path):
        """Valid config with checkpointer outside workspace should load."""
        toml_path = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        config = load_and_validate_toml(toml_path)
        assert config.approval_checkpointer_path == str(tmp_path / "approval.sqlite")


# ──────────────────────────────────────────────
# Validation of numeric fields
# ──────────────────────────────────────────────


class TestNumericFieldValidation:
    """Config must reject invalid numeric values."""

    def _toml_with(self, tmp_path, harness_extras: str = "", sandbox_extras: str = "") -> Path:
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        content = f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"
            max_steps = 10
            {harness_extras}

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]
            {sandbox_extras}
        """
        return _write_toml(tmp_path, content)

    def test_max_steps_zero_rejected(self, tmp_path):
        toml = self._toml_with(tmp_path, harness_extras="max_steps = 0")
        # Override the max_steps = 10 with max_steps = 0 by using replace
        content = toml.read_text().replace("max_steps = 10\nmax_steps = 0", "max_steps = 0")
        toml.write_text(content)
        with pytest.raises(ConfigurationError, match="max_steps.*positive"):
            load_and_validate_toml(toml)

    def test_max_steps_negative_rejected(self, tmp_path):
        content = self._toml_with(tmp_path).read_text()
        content = content.replace("max_steps = 10", "max_steps = -5")
        toml = _write_toml(tmp_path, content)
        with pytest.raises(ConfigurationError, match="max_steps.*positive"):
            load_and_validate_toml(toml)

    def test_invalid_approval_mode_rejected(self, tmp_path):
        content = self._toml_with(tmp_path).read_text()
        content = content.replace("max_steps = 10", 'max_steps = 10\napproval_mode = "bogus"')
        toml = _write_toml(tmp_path, content)
        with pytest.raises(ConfigurationError, match="approval_mode"):
            load_and_validate_toml(toml)


# ──────────────────────────────────────────────
# Valid config loads successfully
# ──────────────────────────────────────────────


class TestValidConfigLoads:
    """A well-formed config must load without errors."""

    def test_minimal_valid_config(self, tmp_path):
        toml_path = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        config = load_and_validate_toml(toml_path)
        assert config.max_steps == 10
        assert config.approval_mode == "auto_read"
        assert config.repeat_threshold == 3

    def test_full_valid_config(self, tmp_path):
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        toml = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{tmp_path}/storage"
            max_steps = 20
            max_tokens = 100000
            max_wall_time = 3600
            approval_mode = "manual_all"
            repeat_threshold = 5

            [approval]
            checkpointer_path = "{tmp_path}/approval.sqlite"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc", "~/.ssh"]
            allowed_env_vars = ["PATH", "LANG"]
            blocked_env_vars = ["API_KEY", "TOKEN"]
            max_file_size = 10485760
            command_timeout = 60
            max_output_bytes = 1048576
            fingerprint_patterns = ["*.py", "src/**"]

            [sandbox.allowed_commands.pytest]
            executable = "/usr/bin/pytest"
            argv_template = ["{{test_path}}", "-v"]
            path_arguments = ["test_path"]

            [tools.file_read]
            capabilities = ["READ"]
            controlled = true
            requires_approval = false

            [tools.file_write]
            capabilities = ["WRITE"]
            controlled = true
            requires_approval = true
            """,
        )
        config = load_and_validate_toml(toml)
        assert config.approval_mode == "manual_all"
        assert config.max_tokens == 100000
        assert config.repeat_threshold == 5
        assert "pytest" in config.sandbox_config.allowed_commands
        assert "file_read" in config.tool_policies
        assert "file_write" in config.tool_policies
        assert config.tool_policies["file_write"].requires_approval is True

    def test_file_not_found_raises(self, tmp_path):
        with pytest.raises(ConfigurationError, match="not found"):
            load_and_validate_toml(tmp_path / "nonexistent.toml")

    def test_invalid_toml_raises(self, tmp_path):
        toml = _write_toml(tmp_path, "this is not [valid toml content {{{")
        with pytest.raises(ConfigurationError, match="Failed to parse"):
            load_and_validate_toml(toml)

    def test_harness_config_from_toml_classmethod(self, tmp_path):
        """HarnessConfig.from_toml() should work as an alternative entry point."""
        toml_path = _write_toml(tmp_path, _minimal_valid_toml(tmp_path))
        config = HarnessConfig.from_toml(toml_path)
        assert config.max_steps == 10


# ══════════════════════════════════════════════
# Sandbox module tests (T012)
# ══════════════════════════════════════════════


import os
import shutil
import signal
import time

from harness.audit import AuditLogger
from harness.models import CommandResult, SandboxViolationError
from harness.sandbox import Sandbox


def _make_sandbox(
    tmp_path,
    *,
    allowed_dirs=None,
    sensitive_dirs=None,
    allowed_commands=None,
    allowed_env_vars=None,
    blocked_env_vars=None,
    max_file_size=10_485_760,
    command_timeout=60,
    max_output_bytes=1_048_576,
):
    """Create a Sandbox with sensible defaults for testing."""
    workspace = tmp_path / "workspace"
    workspace.mkdir(exist_ok=True)
    config = SandboxConfig(
        workspace_root=str(workspace),
        allowed_dirs=allowed_dirs if allowed_dirs is not None else ["."],
        sensitive_dirs=sensitive_dirs if sensitive_dirs is not None else [],
        allowed_commands=allowed_commands or {},
        allowed_env_vars=allowed_env_vars if allowed_env_vars is not None else ["PATH", "LANG"],
        blocked_env_vars=blocked_env_vars if blocked_env_vars is not None else ["API_KEY", "TOKEN"],
        max_file_size=max_file_size,
        command_timeout=command_timeout,
        max_output_bytes=max_output_bytes,
    )
    audit = AuditLogger(str(tmp_path / "storage"))
    return Sandbox(config=config, audit=audit)


# ──────────────────────────────────────────────
# S1: Path escape detection
# ──────────────────────────────────────────────


class TestS1PathEscape:
    """Sandbox must deny paths that escape the workspace."""

    def test_sandbox_deny_path_escape(self, tmp_path):
        """artifacts/../../.env → 拒绝, handler 不执行"""
        sb = _make_sandbox(tmp_path)
        workspace = tmp_path / "workspace"

        # Path that escapes workspace via ..
        escape_path = str(workspace / "artifacts" / ".." / ".." / ".env")
        with pytest.raises(SandboxViolationError, match="(?i)path.*escape|outside"):
            sb.validate_path(escape_path)

    def test_sandbox_allow_safe_path(self, tmp_path):
        """artifacts/report.md → 允许"""
        sb = _make_sandbox(tmp_path)
        workspace = tmp_path / "workspace"

        safe_path = str(workspace / "artifacts" / "report.md")
        result = sb.validate_path(safe_path)
        # Should return the resolved absolute path
        assert result == str(Path(safe_path).resolve())

    def test_sandbox_deny_absolute_outside_workspace(self, tmp_path):
        """Absolute path outside workspace → deny"""
        sb = _make_sandbox(tmp_path)
        with pytest.raises(SandboxViolationError):
            sb.validate_path("/tmp/outside_file.txt")


# ──────────────────────────────────────────────
# S2: Symlink escape
# ──────────────────────────────────────────────


class TestS2SymlinkEscape:
    """Sandbox must deny symlinks that point to sensitive directories."""

    def test_sandbox_deny_symlink_escape(self, tmp_path):
        """软链接指向 ~/.ssh → 拒绝, 审计留痕"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)

        # Create a target outside workspace
        secret_dir = tmp_path / "secrets"
        secret_dir.mkdir()
        secret_file = secret_dir / "id_rsa"
        secret_file.write_text("secret")

        # Create symlink inside workspace pointing to secret
        link_path = workspace / "link_to_secret"
        link_path.symlink_to(secret_file)

        # Configure sensitive_dirs to include the secrets dir
        sb = _make_sandbox(tmp_path, sensitive_dirs=[str(secret_dir)])

        with pytest.raises(SandboxViolationError, match="(?i)symlink|escape|sensitive"):
            sb.validate_path(str(link_path))


# ──────────────────────────────────────────────
# S3: Command whitelist
# ──────────────────────────────────────────────


class TestS3CommandWhitelist:
    """Sandbox must enforce command whitelist profiles."""

    def test_sandbox_deny_unknown_command(self, tmp_path):
        """未配置的 profile → 拒绝"""
        sb = _make_sandbox(tmp_path)

        with pytest.raises(SandboxViolationError, match="(?i)command.*not.*allow|unknown.*command"):
            sb.validate_command("unknown_cmd", {})

    def test_sandbox_allow_whitelisted_command(self, tmp_path):
        """pytest tests/ → 允许"""
        # Find a real executable for the test
        python_exe = shutil.which("python3") or shutil.which("python") or "/usr/bin/python3"
        policies = {
            "python": CommandPolicy(
                executable=python_exe,
                argv_template=["-c", "{code}"],
                path_arguments=[],
            ),
        }
        sb = _make_sandbox(tmp_path, allowed_commands=policies)

        argv = sb.validate_command("python", {"code": "print('hello')"})
        assert python_exe in argv[0]
        assert "-c" in argv
        assert "print('hello')" in argv

    def test_sandbox_command_profile_rejects_unapproved_arguments(self, tmp_path):
        """命令 profile 不接受模板外参数"""
        python_exe = shutil.which("python3") or "/usr/bin/python3"
        policies = {
            "pytest": CommandPolicy(
                executable=python_exe,
                argv_template=["{test_path}", "-v"],
                path_arguments=["test_path"],
            ),
        }
        sb = _make_sandbox(tmp_path, allowed_commands=policies)

        # Extra argument not in template → deny
        with pytest.raises(SandboxViolationError, match="(?i)argument|unapproved|unknown"):
            sb.validate_command("pytest", {"test_path": "tests/", "extra": "--evil"})


# ──────────────────────────────────────────────
# S4: Command timeout
# ──────────────────────────────────────────────


class TestS4CommandTimeout:
    """Sandbox must kill process group on timeout."""

    def test_sandbox_kill_on_timeout(self, tmp_path):
        """sleep 100 (timeout=2) → 进程组真实终止"""
        sleep_exe = shutil.which("sleep")
        if sleep_exe is None:
            pytest.skip("sleep command not found")

        policies = {
            "sleep": CommandPolicy(
                executable=sleep_exe,
                argv_template=["{seconds}"],
                path_arguments=[],
            ),
        }
        sb = _make_sandbox(tmp_path, allowed_commands=policies, command_timeout=2)

        start = time.monotonic()
        result = sb.execute_command("sleep", {"seconds": "100"}, timeout=2)
        elapsed = time.monotonic() - start

        assert result.timed_out is True
        assert elapsed < 10, f"Process should have been killed within 10s, took {elapsed:.1f}s"


# ──────────────────────────────────────────────
# S5: File size limit
# ──────────────────────────────────────────────


class TestS5FileSizeLimit:
    """Sandbox must reject writes that exceed max_file_size before truncation."""

    def test_sandbox_rejects_file_size_before_truncate(self, tmp_path):
        """超过 max_file_size → 拒绝，既有目标文件未被创建或截断"""
        sb = _make_sandbox(tmp_path, max_file_size=100)
        workspace = tmp_path / "workspace"

        target = workspace / "big_file.txt"
        content = "x" * 200  # 200 bytes > 100 byte limit

        with pytest.raises(SandboxViolationError, match="(?i)file.*large|size"):
            sb.check_file_size(content)

        # Target file should NOT have been created
        assert not target.exists()


# ──────────────────────────────────────────────
# Environment filtering
# ──────────────────────────────────────────────


class TestEnvironmentFiltering:
    """Sandbox must filter environment variables for subprocesses."""

    def test_sandbox_filters_inherited_environment(self, tmp_path):
        """子进程不继承宿主环境，只收到明确允许且未被 block 的变量"""
        sb = _make_sandbox(
            tmp_path,
            allowed_env_vars=["PATH", "LANG", "HOME"],
            blocked_env_vars=["API_KEY", "TOKEN", "SECRET"],
        )

        # Simulate a full environment
        full_env = {
            "PATH": "/usr/bin",
            "LANG": "en_US.UTF-8",
            "HOME": "/home/user",
            "API_KEY": "secret123",
            "TOKEN": "abc",
            "SECRET": "hidden",
            "SHELL": "/bin/bash",
            "USER": "testuser",
        }

        filtered = sb.filter_env(full_env)

        # Only allowed vars that are not blocked should pass
        assert "PATH" in filtered
        assert "LANG" in filtered
        assert "HOME" in filtered
        # Blocked vars must be removed
        assert "API_KEY" not in filtered
        assert "TOKEN" not in filtered
        assert "SECRET" not in filtered
        # Non-allowed vars must be removed
        assert "SHELL" not in filtered
        assert "USER" not in filtered


# ──────────────────────────────────────────────
# Output truncation
# ──────────────────────────────────────────────


class TestOutputTruncation:
    """Sandbox must truncate output that exceeds max_output_bytes."""

    def test_truncate_output_within_limit(self, tmp_path):
        sb = _make_sandbox(tmp_path, max_output_bytes=1000)
        output = "hello world"
        result, truncated = sb.truncate_output(output)
        assert result == output
        assert truncated is False

    def test_truncate_output_exceeds_limit(self, tmp_path):
        sb = _make_sandbox(tmp_path, max_output_bytes=10)
        output = "a" * 100
        result, truncated = sb.truncate_output(output)
        assert len(result.encode("utf-8")) <= 10
        assert truncated is True


# ──────────────────────────────────────────────
# Sensitive dirs override
# ──────────────────────────────────────────────


class TestSensitiveDirsOverride:
    """Sensitive dirs must take priority over allowed dirs."""

    def test_sandbox_config_sensitive_dirs_override_allowed_dirs(self, tmp_path):
        """敏感目录与 allowed_dirs 重叠时仍拒绝访问"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        sensitive_sub = workspace / "secret"
        sensitive_sub.mkdir()

        sb = _make_sandbox(
            tmp_path,
            allowed_dirs=["."],
            sensitive_dirs=[str(sensitive_sub)],
        )

        # Even though allowed_dirs=["."] covers the workspace,
        # sensitive_dirs should deny access
        target = sensitive_sub / "data.txt"
        with pytest.raises(SandboxViolationError, match="(?i)sensitive"):
            sb.validate_path(str(target))


# ──────────────────────────────────────────────
# T034: TOML tool policy coverage validation
# ──────────────────────────────────────────────


class TestTOMLToolPolicyCoverage:
    """TOML config must enforce tool policy coverage for registered tools (T034)."""

    def test_harness_config_from_toml_requires_tool_policy_coverage(self, tmp_path):
        """Missing policy, extra policy, and type errors → explicit ConfigurationError.

        This test exercises the full TOML → HarnessConfig → validate_config pipeline
        to ensure tool policy coverage is enforced at startup.
        """
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        storage = tmp_path / "storage"
        storage.mkdir(exist_ok=True)
        checkpointer = tmp_path / "approval.sqlite"

        # --- Case 1: Missing policy for a registered tool ---
        toml_missing = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{storage}"
            max_steps = 10

            [approval]
            checkpointer_path = "{checkpointer}"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]

            [tools.file_read]
            capabilities = ["READ"]
            controlled = true
            requires_approval = false
            """,
        )
        config = load_and_validate_toml(toml_missing)
        # file_write is registered but has no policy in TOML
        with pytest.raises(ConfigurationError, match="(?i)missing.*registered"):
            validate_config(
                config,
                registered_tool_names={"file_read", "file_write"},
            )

        # --- Case 2: Extra/unknown policy ---
        toml_extra = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{storage}"
            max_steps = 10

            [approval]
            checkpointer_path = "{checkpointer}"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]

            [tools.file_read]
            capabilities = ["READ"]
            controlled = true
            requires_approval = false

            [tools.ghost_tool]
            capabilities = ["READ"]
            controlled = true
            requires_approval = false
            """,
        )
        config2 = load_and_validate_toml(toml_extra)
        with pytest.raises(ConfigurationError, match="(?i)unknown tools"):
            validate_config(
                config2,
                registered_tool_names={"file_read"},
            )

        # --- Case 3: Invalid capability type ---
        toml_bad_type = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{storage}"
            max_steps = 10

            [approval]
            checkpointer_path = "{checkpointer}"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]

            [tools.file_read]
            capabilities = ["INVALID_CAPABILITY"]
            controlled = true
            requires_approval = false
            """,
        )
        with pytest.raises(ConfigurationError, match="(?i)invalid"):
            load_and_validate_toml(toml_bad_type)

        # --- Case 4: Exact match succeeds ---
        toml_ok = _write_toml(
            tmp_path,
            f"""\
            [harness]
            workspace_root = "{workspace}"
            storage_path = "{storage}"
            max_steps = 10

            [approval]
            checkpointer_path = "{checkpointer}"

            [sandbox]
            workspace_root = "{workspace}"
            allowed_dirs = ["."]
            sensitive_dirs = ["/etc"]

            [tools.file_read]
            capabilities = ["READ"]
            controlled = true
            requires_approval = false

            [tools.file_write]
            capabilities = ["WRITE"]
            controlled = true
            requires_approval = true
            """,
        )
        config_ok = load_and_validate_toml(toml_ok)
        # Should not raise
        validate_config(
            config_ok,
            registered_tool_names={"file_read", "file_write"},
        )
        assert config_ok.tool_policies["file_write"].requires_approval is True
