"""Regression tests for completion, plan acceptance, and test execution."""

import importlib.util
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from harness.models import (
    AcceptanceCheck,
    BudgetInfo,
    CommandPolicy,
    EvidenceKind,
    PlanStep,
    RunStatus,
    StepStatus,
    SandboxViolationError,
    ToolCapability,
    ToolPolicy,
)
from harness.plan_tools import CreateTestTool, RevisePlanTool, RunTestTool, UpdatePlanStepTool
from harness.sandbox import Sandbox
from smolagents.models import LiteLLMModel
from tests.conftest import FakeModel
from tests.test_harness_loop import _make_final_answer, _make_response, _make_runner, _make_tool_call


class InspectingModel(FakeModel):
    def __init__(self, responses):
        super().__init__(responses)
        self.offered_tools = []

    def generate(self, messages, stop_sequences=None, response_format=None, tools_to_call_from=None):
        self.offered_tools.append({tool.name for tool in tools_to_call_from})
        return super().generate(messages, stop_sequences, response_format, tools_to_call_from)


def _test_policy(runner):
    runner._config.tool_policies["run_test"] = ToolPolicy(
        tool_name="run_test", capabilities={ToolCapability.EXECUTE}, controlled=True, requires_approval=False
    )
    runner._gate._tool_policies["run_test"] = runner._config.tool_policies["run_test"]
    runner._config.sandbox_config.allowed_commands["run_test"] = CommandPolicy(
        executable=sys.executable, argv_template=["{test_path}"], path_arguments=["test_path"]
    )


def test_read_only_run_exposes_final_answer_without_plan_or_test_tools(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    runner._config.enable_plan_tools = False
    model = InspectingModel([
        _make_response(tool_calls=[_make_tool_call("file_read", {"path": "auth.py"})]),
        _make_final_answer("analysis report"),
    ])
    runner._model = model
    result = runner.run("Review code")

    assert result.state == RunStatus.COMPLETED
    assert result.final_answer == "analysis report"
    assert all("final_answer" in tools for tools in model.offered_tools)
    assert all(not {"create_plan", "create_test", "run_test"} & tools for tools in model.offered_tools)


def test_litellm_receives_final_answer_schema_and_tool_history(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    runner._config.enable_plan_tools = False
    client = MagicMock()

    def response(name, arguments):
        result = MagicMock()
        result.choices[0].message.content = None
        result.choices[0].message.role = "assistant"
        result.choices[0].message.tool_calls = [
            {"id": "call", "type": "function", "function": {"name": name, "arguments": arguments}}
        ]
        result.usage.prompt_tokens = 1
        result.usage.completion_tokens = 1
        return result

    client.completion.side_effect = [
        response("file_read", '{"path":"auth.py"}'),
        response("final_answer", '{"answer":"report"}'),
    ]
    with patch.object(LiteLLMModel, "create_client", return_value=client):
        runner._model = LiteLLMModel(model_id="deepseek/deepseek-chat", api_key="test-key")
        result = runner.run("review")

    assert result.state == RunStatus.COMPLETED
    assert result.final_answer == "report"
    first_request = client.completion.call_args_list[0].kwargs
    assert "final_answer" in {tool["function"]["name"] for tool in first_request["tools"]}
    second_request = client.completion.call_args_list[1].kwargs
    assert "file_read" in str(second_request["messages"])
    assert "file contents" in str(second_request["messages"])


def test_unapproved_test_tools_are_not_offered_and_policies_do_not_mutate(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    model = InspectingModel([_make_final_answer("done")])
    runner._model = model
    original_policies = set(runner._config.tool_policies)

    assert runner.run("test").state == RunStatus.COMPLETED
    assert "create_plan" in model.offered_tools[0]
    assert not {"create_test", "run_test"} & model.offered_tools[0]
    assert set(runner._config.tool_policies) == original_policies


def test_plan_step_completes_only_after_successful_test(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    _test_policy(runner)
    workspace = tmp_path / "workspace"
    (workspace / "test_script.py").write_text("print('actually executed')\n")
    store = runner._state_store
    store.create_run(task="test", max_steps=5, budget=BudgetInfo(), workspace_fingerprint="fp", run_id="run")
    store.create_plan("run", goal="test", plan_id="plan")
    store.set_active_plan("run", "plan")
    store.add_plan_step("run", "plan", PlanStep(
        id="step", objective="run test", status=StepStatus.IN_PROGRESS,
        required_evidence_kinds=[EvidenceKind.TEST],
    ))
    runner._model = FakeModel([
        _make_response(tool_calls=[_make_tool_call("run_test", {"test_path": "test_script.py", "step_id": "step"}, "tc")]),
        _make_final_answer("done"),
    ])
    runner._gate.add_approved_tool_call("tc")

    result = runner.run("test", reset=False, resume_run_id="run")
    assert result.state == RunStatus.COMPLETED
    assert result.run_state.plans["plan"].steps[0].status == StepStatus.COMPLETED
    evidence = next(iter(result.run_state.evidence_store.values()))
    assert evidence.payload["exit_code"] == 0
    assert "actually executed" in evidence.payload["stdout"]
    assert evidence.artifact_version == runner._compute_workspace_fingerprint()


def test_failed_test_produces_no_evidence_or_completion(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    _test_policy(runner)
    (tmp_path / "workspace" / "fail.py").write_text("raise SystemExit(7)\n")
    store = runner._state_store
    store.create_run(task="test", max_steps=2, budget=BudgetInfo(), workspace_fingerprint="fp", run_id="run")
    store.create_plan("run", goal="test", plan_id="plan")
    store.set_active_plan("run", "plan")
    store.add_plan_step("run", "plan", PlanStep(
        id="step", objective="run test", status=StepStatus.IN_PROGRESS,
        required_evidence_kinds=[EvidenceKind.TEST],
    ))
    runner._model = FakeModel([
        _make_response(tool_calls=[_make_tool_call("run_test", {"test_path": "fail.py", "step_id": "step"}, "tc")]),
        _make_final_answer("done"),
    ])
    runner._gate.add_approved_tool_call("tc")
    result = runner.run("test", reset=False, resume_run_id="run")

    assert result.state == RunStatus.MAX_STEPS
    assert not result.run_state.evidence_store
    assert result.run_state.plans["plan"].steps[0].status == StepStatus.IN_PROGRESS
    assert "exit_code=7" in runner._memory_steps[0].observations


def test_unexecuted_acceptance_check_does_not_pass(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    store = runner._state_store
    store.create_run(task="test", max_steps=2, budget=BudgetInfo(), workspace_fingerprint="fp", run_id="run")
    store.create_plan("run", goal="test", plan_id="plan")
    store.add_plan_step("run", "plan", PlanStep(
        id="step", objective="test", acceptance_checks=[AcceptanceCheck(kind="PATH_EXISTS", parameters={"path": "no"})]
    ))
    assert not store.evaluate_step_acceptance("run", "plan", "step")


def test_test_tool_requires_configured_command_and_workspace_paths(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    store = runner._state_store
    store.create_run(task="test", max_steps=2, budget=BudgetInfo(), workspace_fingerprint="fp", run_id="run")
    store.create_plan("run", goal="test", plan_id="plan")
    store.set_active_plan("run", "plan")
    store.add_plan_step("run", "plan", PlanStep(id="step", objective="test"))
    sandbox = Sandbox(runner._config.sandbox_config, runner._audit)
    run_test = RunTestTool(store, "run", sandbox, str(tmp_path / "workspace"))
    create_test = CreateTestTool(str(tmp_path / "workspace"), sandbox)
    (tmp_path / "workspace" / "test.py").write_text("pass\n")

    with pytest.raises(ValueError, match="command profile"):
        run_test(test_path="test.py", step_id="step")
    with pytest.raises(SandboxViolationError, match="escapes workspace"):
        create_test(path="../outside.py", content="pass")
    assert not (tmp_path / "outside.py").exists()
    assert not store.get_run("run").evidence_store


def test_test_tool_respects_allowed_directories(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    runner._config.sandbox_config.allowed_dirs = ["allowed"]
    sandbox = Sandbox(runner._config.sandbox_config, runner._audit)
    create_test = CreateTestTool(str(tmp_path / "workspace"), sandbox)
    with pytest.raises(SandboxViolationError, match="outside allowed directories"):
        create_test(path="outside.py", content="pass")


def test_plan_tools_require_evidence_and_disallow_forged_evidence(tmp_path):
    runner = _make_runner(tmp_path, responses=[])
    store = runner._state_store
    store.create_run(task="test", max_steps=2, budget=BudgetInfo(), workspace_fingerprint="fp", run_id="run")
    store.create_plan("run", goal="test", plan_id="plan")
    revise = RevisePlanTool(store, "run")
    update = UpdatePlanStepTool(store, "run")

    with pytest.raises(ValueError, match="required_evidence_kinds"):
        revise(plan_id="plan", new_steps='[{"id":"s","objective":"review"}]')
    revise(plan_id="plan", new_steps='[{"id":"s","objective":"test","required_evidence_kinds":["test"]}]')
    assert store.get_plan("run", "plan").steps[0].required_evidence_kinds == [EvidenceKind.TEST]
    with pytest.raises(ValueError, match="cannot be updated"):
        update(plan_id="plan", step_id="s", updates='{"evidence_ids":["fake"]}')


def test_plan_tools_rebound_for_each_run(tmp_path):
    runner = _make_runner(tmp_path, responses=[
        _make_response(tool_calls=[_make_tool_call("create_plan", {"goal": "first", "constraints": "[]"})]),
        _make_final_answer("first"),
        _make_response(tool_calls=[_make_tool_call("create_plan", {"goal": "second", "constraints": "[]"})]),
        _make_final_answer("second"),
    ])
    first = runner.run("first")
    second = runner.run("second")
    assert first.state == second.state == RunStatus.COMPLETED
    assert next(iter(first.run_state.plans.values())).goal == "first"
    assert next(iter(second.run_state.plans.values())).goal == "second"


def test_example_read_tools_enforce_workspace_and_include_line_numbers(tmp_path, monkeypatch):
    dotenv = types.ModuleType("dotenv")
    dotenv.load_dotenv = lambda *args, **kwargs: None
    monkeypatch.setitem(sys.modules, "dotenv", dotenv)
    spec = importlib.util.spec_from_file_location(
        "real_code_analysis_example", Path(__file__).resolve().parents[1] / "examples" / "real_code_analysis.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "auth.py").write_text("first\nsecond\n")
    (tmp_path / "outside.py").write_text("secret\n")
    (workspace / "link.py").symlink_to(tmp_path / "outside.py")
    monkeypatch.setenv("HARNESS_WORKSPACE", str(workspace))

    assert module.file_read(path="auth.py") == "1: first\n2: second"
    with pytest.raises(ValueError, match="超出工作区"):
        module.file_read(path="../outside.py")
    with pytest.raises(ValueError, match="超出工作区"):
        module.file_read(path="link.py")
    with pytest.raises(ValueError, match="超出工作区"):
        module.list_files(directory="..")
