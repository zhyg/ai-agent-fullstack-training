"""Guarded Coding Harness 的审计日志测试。

测试验证审计查询能为单个工具调用提供完整的决策链，
以及为整个运行提供完整的可追溯性。

依据 PRD §3.3 test_audit.py（T018）。
"""

from __future__ import annotations

import uuid
from datetime import datetime

import pytest

from harness.audit import AuditLogger
from harness.models import AuditEvent, AuditEventType


def _make_audit(tmp_path) -> AuditLogger:
    return AuditLogger(str(tmp_path / "storage"))


def _make_event(
    *,
    run_id: str,
    event_type: AuditEventType,
    tool_call_id: str | None = None,
    rule: str | None = None,
    decision: str | None = None,
    actor: str = "system",
    detail: str = "",
) -> AuditEvent:
    return AuditEvent(
        event_id=str(uuid.uuid4()),
        event_type=event_type,
        run_id=run_id,
        tool_call_id=tool_call_id,
        step_number=None,
        tool_name=None,
        arguments=None,
        rule=rule,
        decision=decision,
        actor=actor,
        detail=detail,
    )


# ══════════════════════════════════════════════
# A1：按 tool_call_id 查询被拒绝的调用
# ══════════════════════════════════════════════


class TestA1QueryDeniedCall:
    """按 tool_call_id 查询审计，返回 rule、decision 和 actor。"""

    def test_audit_query_denied_call(self, tmp_path):
        """按 tool_call_id 查询 → 返回 GATE_DENY，包含 rule、decision、actor。"""
        audit = _make_audit(tmp_path)
        run_id = "run-a1"
        tc_id = "tc-denied-001"

        # 记录一条 Gate 拒绝事件
        audit.log(_make_event(
            run_id=run_id,
            event_type=AuditEventType.GATE_DENY,
            tool_call_id=tc_id,
            rule="gate.parameter_missing",
            decision="DENY",
            actor="system",
            detail="Missing required field: path",
        ))

        # 按 tool_call_id 查询
        events = audit.query(tool_call_id=tc_id)
        assert len(events) == 1
        ev = events[0]
        assert ev.event_type == AuditEventType.GATE_DENY
        assert ev.rule == "gate.parameter_missing"
        assert ev.decision == "DENY"
        assert ev.actor == "system"

        # get_decision_chain 同样应生效
        chain = audit.get_decision_chain(tc_id)
        assert len(chain) == 1
        assert chain[0].tool_call_id == tc_id


# ══════════════════════════════════════════════
# A2：查询完整运行的审计链
# ══════════════════════════════════════════════


class TestA2QueryFullRun:
    """按 run_id 查询审计，关联 Gate、Sandbox、State 及执行结果。"""

    def test_audit_query_full_run(self, tmp_path):
        """按 run_id 查询 → 按时间顺序返回所有事件。"""
        audit = _make_audit(tmp_path)
        run_id = "run-a2"

        # 模拟一次完整运行的审计轨迹
        events_to_log = [
            # 运行开始
            _make_event(
                run_id=run_id,
                event_type=AuditEventType.RUN_STARTED,
                actor="system",
                detail="Run started",
            ),
            # Gate 放行读工具
            _make_event(
                run_id=run_id,
                event_type=AuditEventType.GATE_ALLOW,
                tool_call_id="tc-001",
                rule="gate.auto_read",
                decision="ALLOW",
                actor="system",
            ),
            # 工具执行成功
            _make_event(
                run_id=run_id,
                event_type=AuditEventType.TOOL_EXECUTED,
                tool_call_id="tc-001",
                actor="system",
                detail="file_read executed successfully",
            ),
            # 沙箱违规尝试
            _make_event(
                run_id=run_id,
                event_type=AuditEventType.SANDBOX_VIOLATION,
                tool_call_id="tc-002",
                rule="sandbox.PATH_ESCAPE",
                decision="DENY",
                actor="system",
                detail="Path escapes workspace",
            ),
            # 计划创建
            _make_event(
                run_id=run_id,
                event_type=AuditEventType.PLAN_CREATED,
                actor="model",
                detail="Plan created: fix auth bug",
            ),
            # 运行结束
            _make_event(
                run_id=run_id,
                event_type=AuditEventType.RUN_COMPLETED,
                actor="system",
                detail="Run completed with final_answer",
            ),
        ]

        for event in events_to_log:
            audit.log(event)

        # 查询完整运行
        all_events = audit.query(run_id=run_id)
        assert len(all_events) == 6

        # 验证各事件类型均存在
        types = {e.event_type for e in all_events}
        assert AuditEventType.RUN_STARTED in types
        assert AuditEventType.GATE_ALLOW in types
        assert AuditEventType.TOOL_EXECUTED in types
        assert AuditEventType.SANDBOX_VIOLATION in types
        assert AuditEventType.PLAN_CREATED in types
        assert AuditEventType.RUN_COMPLETED in types

        # get_run_audit 应返回相同结果
        run_audit = audit.get_run_audit(run_id)
        assert len(run_audit) == 6

        # 按 event_type 过滤
        gate_events = audit.query(run_id=run_id, event_type=AuditEventType.GATE_ALLOW)
        assert len(gate_events) == 1
        assert gate_events[0].decision == "ALLOW"

        # 按 run 内的 tool_call_id 过滤
        tc_events = audit.query(run_id=run_id, tool_call_id="tc-001")
        assert len(tc_events) == 2  # GATE_ALLOW + TOOL_EXECUTED
