"""HarnessLoop 主循环测试，用于 Guarded Coding Harness。

测试覆盖完成验收（H1）、证据失效（H2）
和预算执行（H3）。

依据 PRD §3.3 test_harness_loop.py（T019）。
"""

from __future__ import annotations

import json
import uuid

import pytest

from smolagents.models import (
    ChatMessage,
    ChatMessageToolCall,
    ChatMessageToolCallFunction,
    MessageRole,
)

from harness.harness import HarnessRunner
from harness.models import (
    BudgetInfo,
    Evidence,
    EvidenceKind,
    EvidenceStatus,
    HarnessConfig,
    PlanStep,
    RunStatus,
    SandboxConfig,
    StepStatus,
    StopReason,
    ToolCapability,
    ToolPolicy,
)
from harness.state_store import StateStore

# 从 conftest 导入测试辅助工具
from tests.conftest import FakeModel, FakeTool


# ──────────────────────────────────────────────
# 辅助函数
# ──────────────────────────────────────────────


def _make_tool_call(name: str, arguments: dict, tc_id: str | None = None) -> ChatMessageToolCall:
    return ChatMessageToolCall(
        id=tc_id or str(uuid.uuid4()),
        type="function",
        function=ChatMessageToolCallFunction(
            name=name,
            arguments=json.dumps(arguments),
        ),
    )


def _make_response(
    text: str = "",
    tool_calls: list[ChatMessageToolCall] | None = None,
    output_tokens: int = 100,
) -> ChatMessage:
    from smolagents.models import TokenUsage

    return ChatMessage(
        role=MessageRole.ASSISTANT,
        content=[{"type": "text", "text": text}],
        tool_calls=tool_calls,
        token_usage=TokenUsage(input_tokens=50, output_tokens=output_tokens),
    )


def _make_final_answer(answer: str = "", tc_id: str | None = None) -> ChatMessage:
    return _make_response(
        text=f"Final answer: {answer}",
        tool_calls=[_make_tool_call("final_answer", {"answer": answer}, tc_id)],
    )


def _make_runner(
    tmp_path,
    *,
    responses: list[ChatMessage],
    tools: list | None = None,
    max_steps: int = 20,
    max_tokens: int | None = None,
    max_wall_time: int | None = None,
) -> HarnessRunner:
    """创建带有 FakeModel 和最小化配置的 HarnessRunner。"""
    workspace = tmp_path / "workspace"
    workspace.mkdir(exist_ok=True)
    storage = tmp_path / "storage"
    storage.mkdir(exist_ok=True)

    model = FakeModel(responses=responses)

    # 创建简单工具
    read_tool = FakeTool(
        name="file_read",
        description="Read a file",
        inputs={"path": {"type": "string", "description": "File path"}},
        output_type="string",
    )
    read_tool.set_output("file contents")

    write_tool = FakeTool(
        name="file_write",
        description="Write a file",
        inputs={
            "path": {"type": "string", "description": "File path"},
            "content": {"type": "string", "description": "Content"},
        },
        output_type="string",
    )
    write_tool.set_output("ok")

    all_tools = tools if tools is not None else [read_tool, write_tool]

    config = HarnessConfig(
        workspace_root=str(workspace),
        storage_path=str(storage),
        sandbox_config=SandboxConfig(
            workspace_root=str(workspace),
            allowed_dirs=["."],
            sensitive_dirs=["/etc"],
            allowed_env_vars=["PATH"],
            blocked_env_vars=["API_KEY"],
        ),
        approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
        max_steps=max_steps,
        max_tokens=max_tokens,
        max_wall_time=max_wall_time,
        repeat_threshold=3,
        approval_mode="auto_read",
        tool_policies={
            "file_read": ToolPolicy(
                tool_name="file_read",
                capabilities={ToolCapability.READ},
                controlled=True,
                requires_approval=False,
            ),
            "file_write": ToolPolicy(
                tool_name="file_write",
                capabilities={ToolCapability.WRITE},
                controlled=True,
                requires_approval=False,
            ),
            "final_answer": ToolPolicy(
                tool_name="final_answer",
                capabilities=set(),
                controlled=False,
                requires_approval=False,
            ),
        },
    )

    return HarnessRunner(model=model, tools=all_tools, config=config)


# ══════════════════════════════════════════════
# H1：完成验收
# ══════════════════════════════════════════════


class TestH1CompletionAcceptance:
    """final_answer 接受与拒绝的测试。"""

    def test_harness_reject_empty_final_answer(self, tmp_path):
        """模型调用 final_answer 但 answer 为空 → 被拒绝，不会 COMPLETED。"""
        runner = _make_runner(
            tmp_path,
            responses=[
                _make_final_answer(""),  # 空答案 → 被拒绝
                _make_final_answer("Real answer"),  # 被接受
            ],
            max_steps=5,
        )
        result = runner.run("test task")
        assert result.state == RunStatus.COMPLETED
        # 第一个空的 final_answer 被拒绝，第二个被接受

    def test_harness_reject_incomplete_plan(self, tmp_path):
        """活动计划中有未完成步骤 → final_answer 被拒绝。"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        storage = tmp_path / "storage"
        storage.mkdir(exist_ok=True)

        config = HarnessConfig(
            workspace_root=str(workspace),
            storage_path=str(storage),
            sandbox_config=SandboxConfig(
                workspace_root=str(workspace),
                allowed_dirs=["."],
                sensitive_dirs=["/etc"],
                allowed_env_vars=["PATH"],
                blocked_env_vars=["API_KEY"],
            ),
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=5,
            tool_policies={
                "file_read": ToolPolicy(
                    tool_name="file_read",
                    capabilities={ToolCapability.READ},
                    controlled=True,
                    requires_approval=False,
                ),
                "final_answer": ToolPolicy(
                    tool_name="final_answer",
                    capabilities=set(),
                    controlled=False,
                    requires_approval=False,
                ),
            },
        )

        # 创建一个 state_store 中包含未完成计划的 runner
        state_store = StateStore(str(storage))
        run = state_store.create_run(
            task="test",
            max_steps=5,
            budget=BudgetInfo(),
            workspace_fingerprint="fp1",
            run_id="test-run",
        )
        plan = state_store.create_plan("test-run", goal="fix bug", plan_id="plan-1")
        state_store.set_active_plan("test-run", "plan-1")
        state_store.add_plan_step(
            "test-run", "plan-1",
            PlanStep(id="step-1", objective="Step 1", status=StepStatus.IN_PROGRESS),
        )

        model = FakeModel(responses=[
            _make_final_answer("done"),  # 因计划未完成而被拒绝
            _make_final_answer("done"),  # 再次被拒绝
            _make_final_answer("done"),  # 再次被拒绝
            _make_final_answer("done"),  # 再次被拒绝
            _make_final_answer("done"),  # 被拒绝，达到最大步数
        ])
        read_tool = FakeTool(name="file_read", inputs={"path": {"type": "string", "description": "p"}})
        read_tool.set_output("ok")

        runner = HarnessRunner(
            model=model, tools=[read_tool], config=config,
            state_store=state_store,
        )

        # 预填充运行状态以便恢复
        result = runner.run("test", reset=False, resume_run_id="test-run")
        # 由于计划步骤未完成，不应为 COMPLETED
        assert result.state in (RunStatus.MAX_STEPS, RunStatus.FAILED)


# ══════════════════════════════════════════════
# H2：证据失效
# ══════════════════════════════════════════════


class TestH2EvidenceInvalidation:
    """代码变更后证据失效的测试。"""

    def test_harness_invalidate_stale_test(self, tmp_path):
        """TEST 证据的 artifact_version 过期 → 标记为 STALE。"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        storage = tmp_path / "storage"
        storage.mkdir(exist_ok=True)

        state_store = StateStore(str(storage))
        run = state_store.create_run(
            task="test", max_steps=5, budget=BudgetInfo(),
            workspace_fingerprint="fp1", run_id="test-run",
        )
        plan = state_store.create_plan("test-run", goal="fix", plan_id="p1")
        state_store.add_plan_step(
            "test-run", "p1",
            PlanStep(
                id="s1", objective="Run tests",
                required_evidence_kinds=[EvidenceKind.TEST],
                status=StepStatus.COMPLETED,
            ),
        )

        # 在版本 v1 添加有效的 TEST 证据
        from datetime import datetime

        ev = Evidence(
            id="ev-1", step_id="s1", tool_call_id="tc-1",
            artifact_version="v1", kind=EvidenceKind.TEST,
            summary="tests pass", payload={},
            created_at=datetime.now(),
        )
        state_store.add_evidence("test-run", ev)

        # 工作区变更到 v2
        config = HarnessConfig(
            workspace_root=str(workspace),
            storage_path=str(storage),
            sandbox_config=SandboxConfig(
                workspace_root=str(workspace),
                allowed_dirs=["."],
                sensitive_dirs=["/etc"],
                allowed_env_vars=["PATH"],
                blocked_env_vars=["API_KEY"],
            ),
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=1,
            tool_policies={},
        )

        model = FakeModel(responses=[
            _make_response(text="thinking"),
        ])

        runner = HarnessRunner(
            model=model, tools=[], config=config,
            state_store=state_store,
        )
        runner._run_state = run
        runner._gate._run_id = "test-run"

        # 使证据失效
        stale = runner.invalidate_evidence_after_workspace_change("v2")
        assert "ev-1" in stale

        # 检查证据已失效为 STALE
        ev_check = state_store.get_evidence("test-run", "ev-1")
        assert ev_check.status == EvidenceStatus.STALE

    def test_harness_stale_evidence_blocks_completion(self, tmp_path):
        """步骤的必需证据已失效 → 无法完成。"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        storage = tmp_path / "storage"
        storage.mkdir(exist_ok=True)

        state_store = StateStore(str(storage))
        state_store.create_run(
            task="test", max_steps=5, budget=BudgetInfo(),
            workspace_fingerprint="fp1", run_id="test-run",
        )
        state_store.create_plan("test-run", goal="fix", plan_id="p1")
        state_store.add_plan_step(
            "test-run", "p1",
            PlanStep(
                id="s1", objective="Run tests",
                required_evidence_kinds=[EvidenceKind.TEST],
                status=StepStatus.COMPLETED,
            ),
        )

        from datetime import datetime

        ev = Evidence(
            id="ev-1", step_id="s1", tool_call_id="tc-1",
            artifact_version="v1", kind=EvidenceKind.TEST,
            summary="tests pass", payload={},
            created_at=datetime.now(),
        )
        state_store.add_evidence("test-run", ev)

        # 使证据失效
        state_store.invalidate_stale_evidence("test-run", "v2")

        # 步骤应被回滚
        run = state_store.get_run("test-run")
        step = run.plans["p1"].steps[0]
        assert step.status == StepStatus.IN_PROGRESS


# ══════════════════════════════════════════════
# H3：预算执行
# ══════════════════════════════════════════════


class TestH3BudgetEnforcement:
    """预算执行限制测试。"""

    def test_harness_max_steps_stop(self, tmp_path):
        """达到 max_steps → StopReason=MAX_STEPS_REACHED。"""
        runner = _make_runner(
            tmp_path,
            responses=[
                _make_response("step 1"),
                _make_response("step 2"),
                _make_response("step 3"),
                _make_response("step 4"),  # 不应被执行
            ],
            max_steps=3,
        )
        result = runner.run("test")
        assert result.state == RunStatus.MAX_STEPS
        assert result.stop_reason == StopReason.MAX_STEPS_REACHED

    def test_harness_budget_exceeded(self, tmp_path):
        """Token 预算超限 → BUDGET_EXCEEDED。"""
        runner = _make_runner(
            tmp_path,
            responses=[
                _make_response("step 1", output_tokens=500),
                _make_response("step 2", output_tokens=500),
            ],
            max_tokens=600,
            max_steps=10,
        )
        result = runner.run("test")
        assert result.state == RunStatus.BUDGET_EXCEEDED
        assert result.stop_reason == StopReason.BUDGET_EXCEEDED

    def test_harness_budget_exceeded_after_model_response_skips_tools(self, tmp_path):
        """模型响应后预算超限 → 工具调用不执行。"""
        read_tool = FakeTool(name="file_read", inputs={"path": {"type": "string", "description": "p"}})
        read_tool.set_output("ok")

        # 模型返回工具调用，但 token 超出预算
        response_with_tools = _make_response(
            "calling tool",
            tool_calls=[_make_tool_call("file_read", {"path": "/test.txt"})],
            output_tokens=600,
        )
        runner = _make_runner(
            tmp_path,
            responses=[response_with_tools],
            tools=[read_tool],
            max_tokens=500,
            max_steps=10,
        )
        result = runner.run("test")
        assert result.state == RunStatus.BUDGET_EXCEEDED
        # 工具不应被执行
        assert read_tool.call_count == 0

    def test_harness_unlimited_optional_budgets(self, tmp_path):
        """max_tokens=None 且 max_wall_time=None → 跳过这些检查。"""
        runner = _make_runner(
            tmp_path,
            responses=[
                _make_response("step 1", output_tokens=999999),
                _make_final_answer("done"),
            ],
            max_tokens=None,
            max_wall_time=None,
            max_steps=10,
        )
        result = runner.run("test")
        assert result.state == RunStatus.COMPLETED

    def test_harness_plan_revision_limit(self, tmp_path):
        """达到计划修订次数上限 → 修订被拒绝，运行继续。"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        storage = tmp_path / "storage"
        storage.mkdir(exist_ok=True)

        state_store = StateStore(str(storage))
        state_store.create_run(
            task="test", max_steps=5, budget=BudgetInfo(),
            workspace_fingerprint="fp1", run_id="test-run",
        )
        state_store.create_plan("test-run", goal="fix", plan_id="p1", max_revisions=1)

        # 第一次修订成功
        state_store.revise_plan("test-run", "p1")
        # 第二次应失败
        from harness.models import PlanRevisionLimitError

        with pytest.raises(PlanRevisionLimitError):
            state_store.revise_plan("test-run", "p1")

    def test_harness_resume_arguments_are_explicit(self, tmp_path):
        """reset=True + resume_run_id → ValueError。"""
        runner = _make_runner(
            tmp_path,
            responses=[_make_response("step")],
        )
        with pytest.raises(ValueError, match="Invalid argument combination"):
            runner.run("test", reset=True, resume_run_id="some-id")

        with pytest.raises(ValueError, match="Invalid argument combination"):
            runner.run("test", reset=False, resume_run_id=None)

    def test_harness_approval_returns_waiting_and_resumes(self, tmp_path):
        """写工具需要审批 → WAITING_APPROVAL → 工具不执行。"""
        write_tool = FakeTool(
            name="file_write",
            inputs={
                "path": {"type": "string", "description": "p"},
                "content": {"type": "string", "description": "c"},
            },
        )
        write_tool.set_output("ok")

        response_with_write = _make_response(
            "writing file",
            tool_calls=[_make_tool_call("file_write", {"path": "/test.txt", "content": "hello"})],
        )
        runner = _make_runner(
            tmp_path,
            responses=[
                response_with_write,
                _make_final_answer("done"),
            ],
            tools=[write_tool],
            max_steps=5,
        )
        # 覆盖配置，要求写操作需审批
        runner._config.approval_mode = "manual_all"
        runner._gate._approval_mode = "manual_all"

        result = runner.run("test")
        # 写操作应被阻止（WAITING_APPROVAL 在当前实现中按拒绝处理）
        assert write_tool.call_count == 0

    def test_harness_final_answer_is_gated_and_validated(self, tmp_path):
        """final_answer 须经过 Gate 和验收检查。"""
        runner = _make_runner(
            tmp_path,
            responses=[
                _make_final_answer("Valid answer here"),
            ],
            max_steps=5,
        )
        result = runner.run("test")
        assert result.state == RunStatus.COMPLETED
        assert result.stop_reason == StopReason.FINAL_ANSWER

    def test_harness_workspace_change_requires_human_resolution(self, tmp_path):
        """检测到工作区变更 → 证据失效。"""
        workspace = tmp_path / "workspace"
        workspace.mkdir(exist_ok=True)
        storage = tmp_path / "storage"
        storage.mkdir(exist_ok=True)

        state_store = StateStore(str(storage))
        state_store.create_run(
            task="test", max_steps=5, budget=BudgetInfo(),
            workspace_fingerprint="fp1", run_id="test-run",
        )
        state_store.create_plan("test-run", goal="fix", plan_id="p1")
        state_store.add_plan_step(
            "test-run", "p1",
            PlanStep(
                id="s1", objective="Test",
                required_evidence_kinds=[EvidenceKind.TEST],
                status=StepStatus.COMPLETED,
            ),
        )

        from datetime import datetime

        state_store.add_evidence("test-run", Evidence(
            id="ev-1", step_id="s1", tool_call_id="tc-1",
            artifact_version="v1", kind=EvidenceKind.TEST,
            summary="pass", payload={},
            created_at=datetime.now(),
        ))

        config = HarnessConfig(
            workspace_root=str(workspace),
            storage_path=str(storage),
            sandbox_config=SandboxConfig(
                workspace_root=str(workspace),
                allowed_dirs=["."],
                sensitive_dirs=["/etc"],
                allowed_env_vars=["PATH"],
                blocked_env_vars=["API_KEY"],
            ),
            approval_checkpointer_path=str(tmp_path / "approval.sqlite"),
            max_steps=1,
            tool_policies={},
        )

        runner = HarnessRunner(
            model=FakeModel(responses=[_make_response("hi")]),
            tools=[], config=config,
            state_store=state_store,
        )
        runner._run_state = state_store.get_run("test-run")
        runner._gate._run_id = "test-run"

        stale = runner.invalidate_evidence_after_workspace_change("v2")
        assert "ev-1" in stale

        # 步骤被回滚
        run = state_store.get_run("test-run")
        assert run.plans["p1"].steps[0].status == StepStatus.IN_PROGRESS
