"""Gate module tests for the Guarded Coding Harness.

Tests verify that Gate enforces all pre-execution checks:
parameter validation (G1), repeat detection (G2), approval (G3),
and post-approval replay detection (G4).

Per PRD §3.3 test_gate.py (T009).
"""

from __future__ import annotations

import pytest

from smolagents.memory import ToolCall

from harness.audit import AuditLogger
from harness.gate import Gate
from harness.models import (
    AuditEventType,
    GateDecision,
    ToolCapability,
    ToolPolicy,
)

from tests.conftest import FakeTool


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────


def _make_gate(
    tmp_path,
    *,
    tool_policies: dict[str, ToolPolicy] | None = None,
    approval_mode: str = "auto_read",
    repeat_threshold: int = 3,
) -> Gate:
    """Create a Gate with the given policies and an AuditLogger."""
    audit = AuditLogger(str(tmp_path / "storage"))
    return Gate(
        tool_policies=tool_policies or {},
        approval_mode=approval_mode,
        repeat_threshold=repeat_threshold,
        audit_logger=audit,
        run_id="test-run-001",
    )


def _make_tool(
    name: str = "file_read",
    inputs: dict | None = None,
) -> FakeTool:
    """Create a FakeTool with the given name and inputs schema."""
    return FakeTool(
        name=name,
        description=f"Fake {name} tool",
        inputs=inputs or {"path": {"type": "string", "description": "File path"}},
        output_type="string",
    )


def _make_tool_call(
    name: str = "file_read",
    arguments: dict | None = None,
    call_id: str = "tc-001",
) -> ToolCall:
    """Create a ToolCall with the given parameters."""
    return ToolCall(
        name=name,
        arguments=arguments if arguments is not None else {"path": "/some/file.py"},
        id=call_id,
    )


def _standard_policies() -> dict[str, ToolPolicy]:
    """Create a standard set of tool policies for testing."""
    return {
        "file_read": ToolPolicy(
            tool_name="file_read",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        ),
        "file_write": ToolPolicy(
            tool_name="file_write",
            capabilities={ToolCapability.WRITE},
            controlled=True,
            requires_approval=True,
        ),
        "final_answer": ToolPolicy(
            tool_name="final_answer",
            capabilities={ToolCapability.READ},
            controlled=True,
            requires_approval=False,
        ),
    }


# ──────────────────────────────────────────────
# G1: Parameter validation
# ──────────────────────────────────────────────


class TestG1ParameterValidation:
    """Gate must deny tool calls with missing or incorrectly typed parameters."""

    def test_gate_deny_missing_field(self, tmp_path):
        """缺少必填字段 → DENY, handler 调用次数 = 0"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies)
        tool = _make_tool("file_read")
        # Missing required 'path' field
        tc = _make_tool_call("file_read", arguments={}, call_id="tc-missing")

        decision = gate.check(tc, tool)

        assert decision.decision == "DENY"
        assert "path" in decision.reason.lower() or "required" in decision.reason.lower()
        assert decision.rule == "parameter_validation"

    def test_gate_deny_wrong_type(self, tmp_path):
        """参数类型错误 → DENY, handler 调用次数 = 0"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies)
        tool = _make_tool("file_read")
        # Wrong type: path should be string, not integer
        tc = _make_tool_call("file_read", arguments={"path": 12345}, call_id="tc-wrongtype")

        decision = gate.check(tc, tool)

        assert decision.decision == "DENY"
        assert "type" in decision.reason.lower() or "mismatch" in decision.reason.lower()
        assert decision.rule == "parameter_validation"

    def test_gate_deny_unknown_tool(self, tmp_path):
        """未知工具 → DENY"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies)
        tool = _make_tool("ghost_tool")
        tc = _make_tool_call("ghost_tool", arguments={"input": "test"}, call_id="tc-unknown")

        decision = gate.check(tc, tool)

        assert decision.decision == "DENY"
        assert "unknown" in decision.reason.lower() or "not registered" in decision.reason.lower()
        assert decision.rule == "tool_existence"

    def test_gate_allow_valid_arguments(self, tmp_path):
        """参数正确 → ALLOW"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies)
        tool = _make_tool("file_read")
        tc = _make_tool_call("file_read", arguments={"path": "/some/file.py"}, call_id="tc-valid")

        decision = gate.check(tc, tool)

        assert decision.decision == "ALLOW"
        assert decision.tool_call_id == "tc-valid"


# ──────────────────────────────────────────────
# Gate coverage: final_answer
# ──────────────────────────────────────────────


class TestGateCoverage:
    """All registered tools including final_answer must pass through Gate."""

    def test_gate_covers_all_registered_tools(self, tmp_path):
        """所有工具含 final_answer 均先经 Gate"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies)

        # Test file_read (regular tool)
        read_tool = _make_tool("file_read")
        read_tc = _make_tool_call("file_read", {"path": "/file.py"}, "tc-read")
        read_decision = gate.check(read_tc, read_tool)
        assert read_decision.decision == "ALLOW"

        # Test final_answer (special tool) — also goes through Gate
        fa_tool = _make_tool(
            "final_answer",
            inputs={"answer": {"type": "string", "description": "Final answer"}},
        )
        fa_tc = _make_tool_call("final_answer", {"answer": "done"}, "tc-fa")
        fa_decision = gate.check(fa_tc, fa_tool)
        # final_answer passes Gate (registration + params + repeat only, no approval)
        assert fa_decision.decision == "ALLOW"


# ──────────────────────────────────────────────
# G2: Repeat detection
# ──────────────────────────────────────────────


class TestG2RepeatDetection:
    """Gate must deny repeated calls after reaching the threshold."""

    def test_gate_deny_repeated_call(self, tmp_path):
        """连续 3 次相同调用 → 第 3 次 DENY"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, repeat_threshold=3)
        tool = _make_tool("file_read")
        args = {"path": "/some/file.py"}

        # Call 1: ALLOW
        tc1 = _make_tool_call("file_read", args, "tc-r1")
        d1 = gate.check(tc1, tool)
        assert d1.decision == "ALLOW"
        gate.mark_executed("tc-r1")

        # Call 2: ALLOW (same args, 2nd time)
        tc2 = _make_tool_call("file_read", args, "tc-r2")
        d2 = gate.check(tc2, tool)
        assert d2.decision == "ALLOW"
        gate.mark_executed("tc-r2")

        # Call 3: DENY (same args, 3rd time — threshold reached)
        tc3 = _make_tool_call("file_read", args, "tc-r3")
        d3 = gate.check(tc3, tool)
        assert d3.decision == "DENY"
        assert "repeat" in d3.reason.lower() or "repeated" in d3.reason.lower()
        assert d3.rule == "repeat_detection"

    def test_gate_allow_different_args(self, tmp_path):
        """参数不同的连续调用 → 全部 ALLOW"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, repeat_threshold=3)
        tool = _make_tool("file_read")

        for i in range(5):
            tc = _make_tool_call("file_read", {"path": f"/file_{i}.py"}, f"tc-d{i}")
            decision = gate.check(tc, tool)
            assert decision.decision == "ALLOW", f"Call {i} should be ALLOW"
            gate.mark_executed(f"tc-d{i}")


# ──────────────────────────────────────────────
# G3: Approval for write operations
# ──────────────────────────────────────────────


class TestG3Approval:
    """Gate must require approval for write operations based on approval mode."""

    def test_gate_waiting_approval_write(self, tmp_path):
        """auto_read 模式：写操作无审批 → WAITING_APPROVAL"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, approval_mode="auto_read")
        tool = _make_tool(
            "file_write",
            inputs={"path": {"type": "string", "description": "File path"},
                    "content": {"type": "string", "description": "Content"}},
        )
        tc = _make_tool_call("file_write", {"path": "/out.py", "content": "code"}, "tc-w1")

        decision = gate.check(tc, tool)

        assert decision.decision == "WAITING_APPROVAL"
        assert "approval" in decision.reason.lower()
        assert decision.rule == "approval_required"

    def test_gate_allow_read_without_approval(self, tmp_path):
        """auto_read 模式：读操作无需审批 → ALLOW"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, approval_mode="auto_read")
        tool = _make_tool("file_read")
        tc = _make_tool_call("file_read", {"path": "/file.py"}, "tc-rd")

        decision = gate.check(tc, tool)

        assert decision.decision == "ALLOW"

    def test_gate_manual_all_requires_approval_for_read(self, tmp_path):
        """manual_all 模式下只读调用也进入 WAITING_APPROVAL"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, approval_mode="manual_all")
        tool = _make_tool("file_read")
        tc = _make_tool_call("file_read", {"path": "/file.py"}, "tc-manual")

        decision = gate.check(tc, tool)

        assert decision.decision == "WAITING_APPROVAL"
        assert decision.rule == "approval_required"

    def test_gate_final_answer_no_approval_in_manual_all(self, tmp_path):
        """manual_all 模式：final_answer 不需要审批"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, approval_mode="manual_all")
        fa_tool = _make_tool(
            "final_answer",
            inputs={"answer": {"type": "string", "description": "Answer"}},
        )
        tc = _make_tool_call("final_answer", {"answer": "done"}, "tc-fa-ma")

        decision = gate.check(tc, fa_tool)

        assert decision.decision == "ALLOW"

    def test_gate_allow_write_with_pre_approval(self, tmp_path):
        """写操作有预审批 → ALLOW"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, approval_mode="auto_read")
        tool = _make_tool(
            "file_write",
            inputs={"path": {"type": "string", "description": "File path"},
                    "content": {"type": "string", "description": "Content"}},
        )
        tc = _make_tool_call("file_write", {"path": "/out.py", "content": "code"}, "tc-pre-ap")

        # Pre-approve this tool_call_id
        gate.add_approved_tool_call("tc-pre-ap")

        decision = gate.check(tc, tool)
        assert decision.decision == "ALLOW"


# ──────────────────────────────────────────────
# G4: Post-approval replay detection
# ──────────────────────────────────────────────


class TestG4ReplayDetection:
    """Gate must deny replay of an already-executed approved call."""

    def test_gate_deny_replay_after_approval(self, tmp_path):
        """审批后第一次执行成功，第二次拒绝"""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, approval_mode="auto_read")
        tool = _make_tool(
            "file_write",
            inputs={"path": {"type": "string", "description": "File path"},
                    "content": {"type": "string", "description": "Content"}},
        )
        args = {"path": "/out.py", "content": "code"}

        # Pre-approve the tool_call_id
        gate.add_approved_tool_call("tc-replay")

        # First call: ALLOW (approved)
        tc1 = _make_tool_call("file_write", args, "tc-replay")
        d1 = gate.check(tc1, tool)
        assert d1.decision == "ALLOW"
        gate.mark_executed("tc-replay")

        # Second call with same tool_call_id: DENY (already executed)
        tc2 = _make_tool_call("file_write", args, "tc-replay")
        d2 = gate.check(tc2, tool)
        assert d2.decision == "DENY"
        assert "already executed" in d2.reason.lower() or "replay" in d2.reason.lower()
        assert d2.rule == "post_approval_replay"


# ──────────────────────────────────────────────
# Reset and lifecycle
# ──────────────────────────────────────────────


class TestGateLifecycle:
    """Gate tracker reset and lifecycle management."""

    def test_reset_repeat_tracker(self, tmp_path):
        """reset_repeat_tracker() clears the repeat window."""
        policies = _standard_policies()
        gate = _make_gate(tmp_path, tool_policies=policies, repeat_threshold=3)
        tool = _make_tool("file_read")
        args = {"path": "/file.py"}

        # Build up 2 calls
        for i in range(2):
            tc = _make_tool_call("file_read", args, f"tc-reset{i}")
            gate.check(tc, tool)
            gate.mark_executed(f"tc-reset{i}")

        # Reset
        gate.reset_repeat_tracker()

        # Same args should be allowed again
        tc = _make_tool_call("file_read", args, "tc-after-reset")
        decision = gate.check(tc, tool)
        assert decision.decision == "ALLOW"
