from unittest.mock import patch
from typing import Any

import pytest

from smolagents.agents import MultiStepAgent
from smolagents.models import ChatMessage, ChatMessageToolCall, MessageRole, Model
from smolagents.monitoring import LogLevel
from smolagents.tools import Tool


# Import fixture modules as plugins
pytest_plugins = ["tests.fixtures.agents", "tests.fixtures.tools"]


# ──────────────────────────────────────────────
# Harness test fixtures
# ──────────────────────────────────────────────


class FakeModel(Model):
    """Configurable fake LLM that returns scripted ChatMessage responses.

    Usage::

        model = FakeModel(responses=[
            ChatMessage(role=MessageRole.ASSISTANT, content=[{"type": "text", "text": "thinking..."}]),
        ])
    """

    def __init__(self, responses: list[ChatMessage] | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._responses = list(responses or [])
        self._call_index = 0
        self.call_count = 0

    def generate(self, messages, stop_sequences=None, response_format=None, tools_to_call_from=None):
        self.call_count += 1
        if self._call_index >= len(self._responses):
            raise RuntimeError(f"FakeModel: no more scripted responses (called {self.call_count} times)")
        response = self._responses[self._call_index]
        self._call_index += 1
        return response

    def generate_stream(self, *args, **kwargs):
        raise NotImplementedError("FakeModel does not support streaming")


class FakeTool(Tool):
    """Controllable tool with configurable inputs schema and call tracking.

    Usage::

        tool = FakeTool(
            name="file_read",
            description="Read a file",
            inputs={"path": {"type": "string", "description": "File path"}},
            output_type="string",
        )
        tool.set_output("file contents")
    """

    def __init__(
        self,
        name: str = "fake_tool",
        description: str = "A fake tool for testing",
        inputs: dict | None = None,
        output_type: str = "string",
    ) -> None:
        self.name = name
        self.description = description
        self.inputs = inputs or {"input": {"type": "string", "description": "input"}}
        self.output_type = output_type
        self._output: Any = "fake output"
        self._error: Exception | None = None
        self.call_count = 0
        self.call_args: list[dict] = []
        self.skip_forward_signature_validation = True
        super().__init__()

    def set_output(self, output: Any) -> None:
        self._output = output

    def set_error(self, error: Exception) -> None:
        self._error = error

    def forward(self, **kwargs: Any) -> Any:
        self.call_count += 1
        self.call_args.append(kwargs)
        if self._error is not None:
            raise self._error
        return self._output

original_multi_step_agent_init = MultiStepAgent.__init__


@pytest.fixture(autouse=True)
def patch_multi_step_agent_with_suppressed_logging():
    with patch.object(MultiStepAgent, "__init__", autospec=True) as mock_init:

        def init_with_suppressed_logging(self, *args, verbosity_level=LogLevel.OFF, **kwargs):
            original_multi_step_agent_init(self, *args, verbosity_level=verbosity_level, **kwargs)

        mock_init.side_effect = init_with_suppressed_logging
        yield


@pytest.fixture
def make_sandbox_config(tmp_path):
    """Factory fixture: create a valid SandboxConfig with tmp_path as workspace."""
    from harness.models import CommandPolicy, SandboxConfig

    def _factory(**overrides: Any) -> SandboxConfig:
        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir(exist_ok=True)
        defaults = dict(
            workspace_root=workspace,
            allowed_dirs=["."],
            sensitive_dirs=["/etc", "~/.ssh"],
            allowed_commands={},
            allowed_env_vars=["PATH", "LANG"],
            blocked_env_vars=["API_KEY", "TOKEN"],
            max_file_size=10_485_760,
            command_timeout=60,
            max_output_bytes=1_048_576,
            fingerprint_patterns=["*.py"],
        )
        defaults.update(overrides)
        return SandboxConfig(**defaults)

    return _factory


@pytest.fixture
def make_harness_config(tmp_path, make_sandbox_config):
    """Factory fixture: create a valid HarnessConfig with tmp_path storage."""
    from harness.models import HarnessConfig, SandboxConfig, ToolPolicy, ToolCapability

    def _factory(**overrides: Any) -> HarnessConfig:
        workspace = str(tmp_path / "workspace")
        (tmp_path / "workspace").mkdir(exist_ok=True)
        storage = str(tmp_path / "storage")
        (tmp_path / "storage").mkdir(exist_ok=True)
        sandbox = overrides.pop("sandbox_config", None) or make_sandbox_config()
        checkpointer = overrides.pop("approval_checkpointer_path", None) or str(
            tmp_path / "approval.sqlite"
        )
        defaults = dict(
            workspace_root=workspace,
            storage_path=storage,
            sandbox_config=sandbox,
            approval_checkpointer_path=checkpointer,
            max_steps=20,
            max_tokens=None,
            max_wall_time=None,
            repeat_threshold=3,
            approval_mode="auto_read",
            tool_policies={},
        )
        defaults.update(overrides)
        return HarnessConfig(**defaults)

    return _factory
