"""Approval recovery and real-analysis example tests without network calls."""

import json
from unittest.mock import MagicMock, patch

import pytest

from examples.user_approval import TASK, create_harness, read_decision, run_demo
from harness.models import ApprovalStatus, AuditEvent, AuditEventType, RunStatus, StopReason
from smolagents.models import ChatMessage, ChatMessageToolCall, ChatMessageToolCallFunction, LiteLLMModel, MessageRole
from tests.conftest import FakeModel


def response(*calls):
    return ChatMessage(
        role=MessageRole.ASSISTANT,
        content=None,
        tool_calls=[
            ChatMessageToolCall(
                id=call_id,
                type="function",
                function=ChatMessageToolCallFunction(name=name, arguments=json.dumps(arguments)),
            )
            for call_id, name, arguments in calls
        ],
    )


def make_model():
    return FakeModel(responses=[
        response(("read-1", "read_sample", {"filename": "auth.py"}),
                 ("read-2", "read_sample", {"filename": "math_utils.py"})),
        response(("write-1", "write_report", {"content": "# 报告\n潜在问题。\n"})),
        response(("final-1", "final_answer", {"answer": "分析完成。"})),
    ])


@pytest.mark.parametrize(("decision", "exists"), [("approve", True), ("reject", False)])
def test_real_analysis_example_approval(tmp_path, capsys, decision, exists):
    result = run_demo(tmp_path, make_model(), decision)
    target = tmp_path / "workspace" / "analysis_report.md"
    assert result.state == RunStatus.COMPLETED
    assert target.exists() is exists
    if exists:
        assert target.read_text(encoding="utf-8") == "# 报告\n潜在问题。\n"
    assert result.run_state.pending_approvals[0].status == (
        ApprovalStatus.APPROVED if exists else ApprovalStatus.REJECTED
    )
    assert "待写入内容" in capsys.readouterr().out


@pytest.mark.parametrize(("answer", "expected"), [("y", "approve"), ("NO", "reject")])
def test_interactive_decision_retries_invalid_input(monkeypatch, capsys, answer, expected):
    responses = iter(["invalid", answer])
    monkeypatch.setattr("builtins.input", lambda prompt: next(responses))
    assert read_decision() == expected
    assert "请输入 y 或 n" in capsys.readouterr().out


def test_resume_before_decision_stays_waiting(tmp_path):
    model = make_model()
    harness = create_harness(tmp_path, model)
    first = harness.run(TASK)
    resumed = harness.run(TASK, reset=False, resume_run_id=first.run_state.run_id)
    assert resumed.state == RunStatus.WAITING_APPROVAL
    assert model.call_count == 2
    assert not (tmp_path / "workspace" / "analysis_report.md").exists()


def test_workspace_change_prevents_approval(tmp_path):
    harness = create_harness(tmp_path, make_model())
    first = harness.run(TASK)
    approval = first.run_state.pending_approvals[0]
    (tmp_path / "workspace" / "auth.py").write_text("changed")
    with pytest.raises(ValueError, match="workspace"):
        harness.approve(first.run_state.run_id, approval.approval_id, approver="user")
    resumed = harness.run(TASK, reset=False, resume_run_id=first.run_state.run_id)
    assert resumed.stop_reason == StopReason.WORKSPACE_CHANGED
    assert not (tmp_path / "workspace" / "analysis_report.md").exists()


def test_modified_approval_arguments_are_rejected(tmp_path):
    harness = create_harness(tmp_path, make_model())
    first = harness.run(TASK)
    run_id = first.run_state.run_id
    approval = first.run_state.pending_approvals[0]
    run = harness._state_store.get_run(run_id)
    run.pending_tool_batches[0].tool_calls[0]["arguments"] = '{"content": "tampered"}'
    harness._state_store.update_run(run_id, pending_tool_batches=run.pending_tool_batches)
    with pytest.raises(ValueError, match="does not match|no longer matches"):
        harness.approve(run_id, approval.approval_id, approver="user")
    assert not (tmp_path / "workspace" / "analysis_report.md").exists()


def test_previously_attempted_approved_call_is_not_replayed(tmp_path):
    harness = create_harness(tmp_path, make_model())
    first = harness.run(TASK)
    run_id = first.run_state.run_id
    approval = first.run_state.pending_approvals[0]
    harness.approve(run_id, approval.approval_id, approver="user")
    harness._audit.log(AuditEvent(
        event_id="already-executed", event_type=AuditEventType.TOOL_EXECUTED,
        run_id=run_id, tool_call_id=approval.tool_call_id,
    ))
    result = harness.run(TASK, reset=False, resume_run_id=run_id)
    assert result.state == RunStatus.FAILED
    assert not (tmp_path / "workspace" / "analysis_report.md").exists()
    assert any("already been attempted" in event.detail for event in harness.get_audit(run_id))


def test_approval_workflow_error_does_not_record_decision(tmp_path, monkeypatch):
    harness = create_harness(tmp_path, make_model())
    first = harness.run(TASK)
    approval = first.run_state.pending_approvals[0]
    workflow = harness._runner._approval_workflow

    def fail(*args, **kwargs):
        raise RuntimeError("graph failed")

    monkeypatch.setattr(workflow._graph, "invoke", fail)
    with pytest.raises(RuntimeError, match="graph failed"):
        harness.approve(first.run_state.run_id, approval.approval_id, approver="user")
    assert harness._state_store.get_approval(first.run_state.run_id, approval.approval_id).status == ApprovalStatus.PENDING


def test_multi_tool_batch_resumes_without_repeating_earlier_calls(tmp_path):
    model = FakeModel(responses=[
        response(("read-1", "read_sample", {"filename": "auth.py"}),
                 ("write-1", "write_report", {"content": "report"}),
                 ("read-2", "read_sample", {"filename": "math_utils.py"})),
        response(("final", "final_answer", {"answer": "done"})),
    ])
    harness = create_harness(tmp_path, model)
    first = harness.run(TASK)
    run_id = first.run_state.run_id
    harness.approve(run_id, first.run_state.pending_approvals[0].approval_id, approver="user")
    result = harness.run(TASK, reset=False, resume_run_id=run_id)
    assert result.state == RunStatus.COMPLETED
    events = harness.get_audit(run_id)
    executed = {call_id: sum(e.tool_call_id == call_id and e.event_type.value == "TOOL_STARTED" for e in events)
                for call_id in ("write-1",)}
    assert executed["write-1"] == 1
    assert sum(e.tool_call_id == "read-1" and e.event_type.value == "GATE_ALLOW" for e in events) == 1
    assert model.call_count == 2


def test_second_approval_in_same_batch_preserves_previous_execution(tmp_path):
    model = FakeModel(responses=[
        response(("write-1", "write_report", {"content": "first"}),
                 ("write-2", "write_report", {"content": "second"})),
        response(("final", "final_answer", {"answer": "done"})),
    ])
    harness = create_harness(tmp_path, model)
    first = harness.run(TASK)
    run_id = first.run_state.run_id
    harness.approve(run_id, first.run_state.pending_approvals[0].approval_id, approver="user")
    second = harness.run(TASK, reset=False, resume_run_id=run_id)
    assert second.state == RunStatus.WAITING_APPROVAL
    assert (tmp_path / "workspace" / "analysis_report.md").read_text() == "first"
    pending = [a for a in second.run_state.pending_approvals if a.status == ApprovalStatus.PENDING]
    harness.reject_approval(run_id, pending[0].approval_id, approver="user")
    result = harness.run(TASK, reset=False, resume_run_id=run_id)
    assert result.state == RunStatus.COMPLETED
    assert sum(e.tool_call_id == "write-1" and e.event_type.value == "TOOL_STARTED"
               for e in harness.get_audit(run_id)) == 1
    assert not any(e.tool_call_id == "write-2" and e.event_type.value == "TOOL_STARTED"
                   for e in harness.get_audit(run_id))


def test_litellm_resume_contains_rejected_observation(tmp_path):
    client = MagicMock()

    def api_response(name, arguments):
        result = MagicMock()
        result.choices[0].message.content = None
        result.choices[0].message.role = "assistant"
        result.choices[0].message.tool_calls = [
            {"id": name, "type": "function", "function": {"name": name, "arguments": json.dumps(arguments)}}
        ]
        result.usage.prompt_tokens = 1
        result.usage.completion_tokens = 1
        return result

    client.completion.side_effect = [
        api_response("read_sample", {"filename": "auth.py"}),
        api_response("write_report", {"content": "report"}),
        api_response("final_answer", {"answer": "未写入报告"}),
    ]
    with patch.object(LiteLLMModel, "create_client", return_value=client):
        model = LiteLLMModel(model_id="deepseek/deepseek-chat", api_key="test-key")
        result = run_demo(tmp_path, model, "reject")
    assert result.state == RunStatus.COMPLETED
    messages = client.completion.call_args_list[-1].kwargs["messages"]
    assert "rejected by user" in str(messages)
    assert "read_sample" in str(messages)
