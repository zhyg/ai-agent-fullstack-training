# Commands and provenance

Original cwd: `/home/user/workspace/repo` for cloning; all commands below then run from
`/home/user/workspace/repo/.amp/in/orb-backup/vita-smolagents` unless noted.
No student source or assertion was edited. No API calls were made by the teacher.
Teacher test scripts are original fixtures, not patches to student business code.

## Object and installation

- `git clone --branch master https://gitee.com/vita__chaochao/smolagents.git .amp/in/orb-backup/vita-smolagents` (course root cwd): exit 0.
- `git rev-parse HEAD`: exit 0, `5dd167bcd5fcfb0a9196c41a5477f94053187092`.
- `uv venv ../venv`: exit 0, Python 3.11.16.
- `uv pip install --python ../venv/bin/python -e '.[harness]' pytest pytest-mock pytest-timeout pytest-datadir openai numpy pandas`: exit 0; log `logs/vita-install.log`.
- `uv pip install --python ../venv/bin/python mcp docker ipython helium mcpadapt 'litellm>=1.60.2'`: exit 0; log `logs/vita-extra.log`.
- `uv pip show --python ../venv/bin/python --files smolagents`: exit 0; `logs/smolagents-install.txt`.
- `uv pip freeze --python ../venv/bin/python`: exit 0; `logs/dependencies.txt`.
- `../venv/bin/python -m pip --version`: exit 1 (uv venv has no pip module); no reliance on pip for verification.
- Official clone: `git clone --depth 1 https://github.com/huggingface/smolagents.git ../upstream-smolagents`, exit 0; `git -C ../upstream-smolagents fetch --quiet --unshallow origin main`, exit 0.
- Compared official historical revision `96f33faaf028479119ec8d34507b47694cf14e34` against all student tracked `src/smolagents` files: 21 identical, zero differences. This accounts for legitimate newer upstream changes after the student's commit.

## Unchanged student pytest

Initial full run (before optional dependency repair):

`env -u OPENAI_API_KEY -u ANTHROPIC_API_KEY -u HF_TOKEN -u DEEPSEEK_API_KEY ../venv/bin/python -m pytest -q`

exit 2, 1 skipped / 8 collection errors. `logs/student-full.log`.

Offline full run after dependency repair:

`PYTHONPATH=src:. ../venv/bin/python ../offline_pytest.py -q --basetemp=../offline-full-exact`

exit 1, 1017 passed / 70 failed / 74 skipped / 3 errors, 36.33s. `logs/student-full-exact.log`.
Earlier equivalent run with `--timeout=5 --basetemp=../offline-full` also exit 1 with the same counts; no timeout failure was used for scoring. `logs/student-full-offline.log`.

Offline homework tests, complete ten-file scope:

`PYTHONPATH=src:. ../venv/bin/python ../offline_pytest.py -q tests/test_gate.py tests/test_sandbox.py tests/test_state_checkpoint.py tests/test_audit.py tests/test_harness_loop.py tests/test_completion.py tests/test_user_approval_example.py tests/test_harness_finish.py tests/test_plan.py tests/test_approval_workflow.py --basetemp=../offline-harness-all-1`

exit 0, 142 passed / 0 failed / 0 skipped / 0 errors. Repeat replacing only basetemp with `../offline-harness-all-2`: exit 0, same counts. Logs `logs/student-all-harness-1.log`, `logs/student-all-harness-2.log`.

Earlier seven-file scope excluding test_harness_finish.py/test_plan.py/test_approval_workflow.py: two runs, each exit 0 / 105 passed / 0 failed / 0 skipped. Retained as preliminary evidence only.

`offline_pytest.py` removes secret-like environment variable names, blocks IPv4/IPv6 connect/connect_ex, and invokes original pytest. No assertions, markers, collection selection, or expectations are changed by this script. Full default scope is distinct from explicit homework-only scope. Optional-library and upstream tests explain many full-scope failures and skips; they are not each scored as independent homework defects.

## Teacher independent probes

`PYTHONPATH=src:. ../venv/bin/python ../offline_pytest.py -q -s ../teacher_checks.py --basetemp=../teacher-temp-report`

exit 1, 9 passed / 12 failed / 0 skipped, 16.09s. `logs/teacher-report.log` is authoritative.
The earlier teacher.log and teacher-final.log are iteration logs; teacher-final's repair fixture omitted the model's normal update_plan_step(in_progress) action, which was corrected in the final fixture. Do not score that intermediate fixture failure. In the final run real repair/H2 passed without changing student code.

Each pytest tmp_path is a new independent workspace. C2/C3/C4 launch `sys.executable teacher_checks.py <mode> <new workspace>`, with captured stdout/stderr and explicit exit codes. Crash code 77 is intentional only at the teacher hook between the completed write and TOOL_EXECUTED persistence; no production student source is edited. Unknown-result and pending-approval failures are student behavior, not import or API blocks.

To reproduce from the archive, clone the exact student commit, install the listed dependencies in a fresh environment, and run its Python against `scripts/offline_pytest.py` and `scripts/teacher_checks.py`, with cwd at the clone and `PYTHONPATH=src:.`. Worker processes use the same executable and script path. Use a fresh basetemp for every run. Never use the teacher's source snapshots as a modified replacement implementation.

`PYTHONPATH=src:. ../venv/bin/python ../verify_submission.py`: exit 0. `logs/submission-verification.txt` records environment paths, full official hashes, report/approval equality and run/ID/state correspondence. In original layout this script expects sibling vita-smolagents/upstream-smolagents checkouts. It only reads them.

## Package contents and exclusions

- `source/`: harness implementation, relevant tests, two runnable examples and pyproject snapshot.
- `submitted/`: original docx, extracted text, and the three submitted runtime storage/workspace trees. No teacher evidence is represented as a student submission.
- `teacher-workspaces/`: final teacher fixtures' workspace/state/audit/cp/log snapshots; only synthetic content used.
- `logs/`: actual commands' outputs, including failures.
- `scripts/`: teacher scripts exactly as finally run.
- `reports/`: final feedback and evaluation copies.
- No virtual environment, site-packages, dependency tree, .git directory, pycache, pytest cache or symlink target is packaged. Manifest lists SHA-256 of every included regular file.

## Review revision (no new evaluation run)

The review applies the common T2 rule: LiteLLMModel is only a wrapper class name, MODEL_METADATA_FIELDS is empty, and the submitted artifacts cannot confirm a real-model run. T2 changes from 4/5 to 0/5; testing/evidence changes from 11.5/15 to 7.5/15; the revised total is 65.50, grade 良好, acceptance 未通过. All other scores, original test logs, source snapshots and findings remain unchanged. This is a scoring-policy correction for the same evidence gap, not a newly discovered independent defect. Only the reports, their packaged copies and the manifest/archive are updated; no tests are rerun and no student code is changed.
