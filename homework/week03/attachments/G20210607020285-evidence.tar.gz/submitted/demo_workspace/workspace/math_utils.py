"""数学工具函数。"""


def add(a: float, b: float) -> float:
    """两数相加。"""
    return a + b


def subtract(a: float, b: float) -> float:
    """两数相减。"""
    return a - b


def multiply(a: float, b: float) -> float:
    """两数相乘。"""
    return a * b


def divide(a: float, b: float) -> float:
    """两数相除。

    BUG: 未检查除数为 0 的情况。
    """
    return a / b


def average(numbers: list[float]) -> float:
    """计算列表平均值。

    BUG: 空列表时会抛出 ZeroDivisionError。
    """
    return sum(numbers) / len(numbers)
