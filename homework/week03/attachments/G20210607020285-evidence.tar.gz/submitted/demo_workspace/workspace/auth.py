"""用户认证模块。"""

import hashlib
import secrets


class UserStore:
    """简单的内存用户存储。"""

    def __init__(self):
        self._users = {}  # {username: {"salt": ..., "pw_hash": ...}}

    def register(self, username: str, password: str) -> bool:
        """注册新用户，密码使用 salt + SHA256 哈希存储。"""
        if username in self._users:
            return False
        salt = secrets.token_hex(16)
        pw_hash = hashlib.sha256((salt + password).encode()).hexdigest()
        self._users[username] = {"salt": salt, "pw_hash": pw_hash}
        return True

    def verify(self, username: str, password: str) -> bool:
        """验证用户密码。"""
        user = self._users.get(username)
        if not user:
            return False
        pw_hash = hashlib.sha256(
            (user["salt"] + password).encode()
        ).hexdigest()
        # BUG: 使用 == 而非 hmac.compare_digest，存在时序攻击风险
        return pw_hash == user["pw_hash"]

    def delete_user(self, username: str) -> bool:
        """删除用户。"""
        if username not in self._users:
            return False
        del self._users[username]
        return True


class SessionManager:
    """会话管理器（简化版）。"""

    def __init__(self, user_store: UserStore):
        self._store = user_store
        self._sessions = {}  # {token: username}

    def login(self, username: str, password: str) -> str | None:
        """登录并返回 session token。"""
        if not self._store.verify(username, password):
            return None
        token = secrets.token_urlsafe(32)
        self._sessions[token] = username
        return token

    def logout(self, token: str) -> None:
        """登出（注销 session）。"""
        self._sessions.pop(token, None)

    def get_current_user(self, token: str) -> str | None:
        """根据 token 获取当前登录用户名。"""
        return self._sessions.get(token)
