# 19380 命令与证据索引

工作目录（除注明外）：`/home/user/workspace/repo`。
Python：`.amp/in/orb-backup/venv/bin/python`，下文缩写为 `$PY`。

1. `git clone https://gitee.com/huangke0802/agent-training.git .amp/in/orb-backup/kevin`，exit 0。
2. `git -C .amp/in/orb-backup/kevin rev-parse HEAD`，exit 0，`6e5ff556460418b6e2e1236b33386ab647eaf49f`。
3. `git -C .amp/in/orb-backup/kevin branch --show-current`，exit 0，master。
4. `python3 -m venv .amp/in/orb-backup/venv`，exit 0。
5. `.amp/in/orb-backup/venv/bin/pip install pytest smolagents==1.26.0`，exit 0。安装日志未包含认证信息；证据只需版本与 RECORD 校验，不打包依赖。
6. `$PY .amp/in/orb-backup/offline_run.py`，exit 0。内部两个新副本用 socket 阻断运行，exit 0 / 0；原源码目录以 sanitized env 运行 `$PY -m pytest -q`，exit 0。全部通过 33 项；详见三份 pytest 日志。
7. `$PY -m pip show -f smolagents`，exit 0，见 pip-show-smolagents.log。
8. `$PY -m pytest -v -s -p no:cacheprovider .amp/in/orb-backup/probes.py --basetemp=.amp/in/orb-backup/probe-workspaces-verified`，exit 1；16 项，7 failed / 9 passed。每例 tmp_path 独立。最终教师脚本、真实断言和原始日志均保留，不修改学生代码。
9. `$PY .amp/in/orb-backup/verify_records.py`，exit 0；完整记录交叉核对日志 record-check.log。
10. `git diff --exit-code` 和 `git -C .amp/in/orb-backup/kevin diff --exit-code`，均 exit 0。课程与学生 tracked files 都没有修改。

探索日志：probes.log（exit 1，6 failed/7 passed）、probes-final.log（exit 1，8 failed/8 passed）是中间状态，不是最终判分数据。中间 H2 失败源于教师未沿用 demo 的禁写字节码配置及使用第三次相同累计命令，已诊断并改用原 demo 配置/允许的不同参数，未修改可信测试断言。最终 H2 通过。

## 独立进程退出码

- C2：`$PY probes.py c2-first <新工作区>` exit 19（after_execute 主动 os._exit）；`c2-second` exit 0，结果 UNKNOWN_RESULT，writes.jsonl 一行。
- C3：`c3-first` exit 23（after_checkpoint 主动 os._exit）；`c3-second` exit 0，COMPLETED，轮数 5、工具数 4、写入 1。
- C4：第一进程 exit 23，修改 module.py，第二进程 exit 0 但业务 reason=WORKSPACE_CHANGED，工具数保持 3，不继续执行。

## 解包后独立复验

包不包含虚拟环境或依赖。安装 Python 3.13、pytest 9.2.0、smolagents 1.26.0。
在解包根目录执行 `mkdir -p scripts/kevin/homework && cp -a student-week03 scripts/kevin/homework/week03`，使原教师脚本的相对目录布局可用。
再执行 `python -m pytest -v -s -p no:cacheprovider scripts/probes.py --basetemp=<一个新的空目录>`；学生缺陷仍存在时预期退出 1，7 failed / 9 passed。
`python scripts/verify_records.py` 预期 exit 0。
`python scripts/offline_run.py` 应在 scripts/ 下不存在 offline-workspace-1/2 时执行，重复运行改用新的解包目录。

所有模型调用均离线 Fake；真实 API 未调用，未读取或输出密钥。S4 清理针对教师创建的隔离进程组，不改变学员实现。
