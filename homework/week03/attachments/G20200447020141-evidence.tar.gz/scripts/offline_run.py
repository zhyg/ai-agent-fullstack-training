import os, sys, socket, shutil, pathlib, subprocess, json, importlib.metadata, hashlib, base64

BASE = pathlib.Path(__file__).resolve().parent
SOURCE = BASE / 'kevin/homework/week03'
OUT = BASE / 'evidence'
OUT.mkdir(exist_ok=True)
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ('KEY', 'TOKEN', 'SECRET', 'PASSWORD', 'COOKIE'))}
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HTTP_PROXY='http://127.0.0.1:9', HTTPS_PROXY='http://127.0.0.1:9', ALL_PROXY='http://127.0.0.1:9')
if len(sys.argv) > 1:
    def deny(*a, **kw):
        raise RuntimeError('OFFLINE_NETWORK_BLOCKED')
    socket.socket.connect = deny
    socket.create_connection = deny
    import pytest
    sys.exit(pytest.main(['-q', '-p', 'no:cacheprovider']))

import smolagents, pytest
dist = importlib.metadata.distribution('smolagents')
checked = 0
bad = []
for f in dist.files:
    if f.hash and str(f).startswith('smolagents/'):
        path = dist.locate_file(f)
        actual = base64.urlsafe_b64encode(hashlib.sha256(path.read_bytes()).digest()).decode().rstrip('=')
        checked += 1
        if actual != f.hash.value:
            bad.append(str(f))
meta = {'python':sys.version,'smolagents':smolagents.__version__, 'pytest':pytest.__version__, 'smolagents_path':smolagents.__file__, 'pytest_path':pytest.__file__, 'smolagents_record_files_checked':checked,'mismatches':bad}
(OUT/'environment.json').write_text(json.dumps(meta,indent=2))
for i in (1,2):
    target = BASE / f'offline-workspace-{i}'
    shutil.copytree(SOURCE, target)
    proc = subprocess.run([sys.executable, str(__file__), 'child'], cwd=target,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (OUT/f'pytest-{i}.log').write_text('COMMAND: sanitized-env python offline_run.py child -> pytest.main([-q, -p, no:cacheprovider]); socket connects blocked\n'+proc.stdout+f'\nEXIT_CODE={proc.returncode}\n')
    print(i, proc.returncode,proc.stdout)
proc = subprocess.run([sys.executable,'-m','pytest','-q'],cwd=SOURCE,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'pytest-exact.log').write_text('COMMAND: sanitized-env python -m pytest -q; proxies point to closed local port; HF offline\n'+proc.stdout+f'\nEXIT_CODE={proc.returncode}\n')
print('exact',proc.returncode,proc.stdout)
