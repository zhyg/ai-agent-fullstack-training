import os, sys, json, signal, time, subprocess, threading
from pathlib import Path
import pytest

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'kevin/homework/week03'
sys.path.insert(0, str(SOURCE))
from harness import Harness, HarnessConfig, TaskSpec, ToolCallAction, FinalAnswerAction
from gate import ToolCall, GateHooks
from smolagents.models import Model, ChatMessage, ChatMessageToolCall, ChatMessageToolCallFunction

class Fake(Model):
    """Teacher model: real smolagents message objects, bridge to submitted decide API.
    This bridge DOES NOT turn the student's loop into ToolCallingAgent.run().
    """
    def __init__(self, actions):
        super().__init__(model_id='teacher-offline')
        self.actions = actions
    def generate(self, messages, **kwargs):
        i = int(messages[0]['content'])
        action = self.actions[i] if i < len(self.actions) else FinalAnswerAction('done')
        if isinstance(action, FinalAnswerAction):
            return ChatMessage(role='assistant',content=action.content)
        return ChatMessage(role='assistant',content=None,tool_calls=[ChatMessageToolCall(id=action.tool_call_id,type='function',function=ChatMessageToolCallFunction(name=action.tool_name,arguments=action.args))])
    def decide(self, view):
        msg = self.generate([{'role':'user','content':str(view.model_cursor)}])
        if not msg.tool_calls:
            return FinalAnswerAction(msg.content)
        c = msg.tool_calls[0]
        return ToolCallAction(c.id,c.function.name,c.function.arguments)

def setup(root, actions=(), auto=True, **kw):
    repo = root/'repo'
    if not repo.exists():
        repo.mkdir(parents=True)
        (repo/'app.py').write_text('def add(a,b):\n    return a-b\n')
        (repo/'module.py').write_text('from app import add\ndef caller(): return add(2,3)\n')
        (root/'artifacts').mkdir()
    task = TaskSpec(kind='code_understanding',title='Explain module.caller -> app.add',repo_root=repo,project_root=root,tracked_files=('app.py','module.py'),max_turns=8,max_tool_calls=8,**kw)
    return Harness(model=Fake(list(actions)),task=task,run_id='probe',config=HarnessConfig(auto_approve=auto))

def reads():
    return [ToolCallAction('r1','read_file',{'path':'app.py'}), ToolCallAction('r2','read_file',{'path':'module.py'})]

def write(content='module.caller calls app.add(2,3) which returns a-b.'):
    return ToolCallAction('w','write_file',{'path':'artifacts/report.md','content':content})

def test_g1_g2_harness(tmp_path):
    actions = [ToolCallAction('bad1','read_file',{}),ToolCallAction('bad2','read_file',{'path':123}),ToolCallAction('unknown','missing_tool',{}),ToolCallAction('s1','search_code',{'query':'add','path':'.'}),ToolCallAction('s2','search_code',{'path':'.','query':'add'}),ToolCallAction('s3','search_code',{'query':'add','path':'.'})]
    h=setup(tmp_path,actions)
    result=h.run()
    obs=[json.loads(json.dumps(m)) for m in result.state.messages]
    assert result.stop_reason=='REPEATED_ACTION'
    assert [c.tool_call_id for c in result.state.tool_calls]==['s1','s2']
    assert all(any(k in str(m) for m in obs) for k in ('bad1','bad2','unknown','INVALID_ARGUMENTS','TOOL_NOT_FOUND'))

def test_g3_model_cannot_approve(tmp_path):
    h=setup(tmp_path,[ToolCallAction('hack','write_file',{'path':'artifacts/report.md','content':'bad','approved':True}),write()],auto=False)
    r=h.run()
    assert r.stop_reason=='WAITING_APPROVAL' and not (tmp_path/'artifacts/report.md').exists()
    assert not r.state.tool_calls
    assert h.checkpoint.load().payload['pendingApproval']['toolCallId']=='w'

def test_g4_changed_arguments_cannot_use_approval(tmp_path):
    h=setup(tmp_path,auto=False);h.prepare()
    call=ToolCall('approved-id','write_file',{'path':'artifacts/report.md','content':'APPROVED'})
    pending=h.gate.invoke(call);h.approve(pending.action_id)
    altered=ToolCall('approved-id','write_file',{'path':'artifacts/report.md','content':'NOT APPROVED'})
    result=h.gate.invoke(altered)
    print('G4',result.code,result.ok,(tmp_path/'artifacts/report.md').read_text() if (tmp_path/'artifacts/report.md').exists() else None)
    assert not result.ok, 'Changed arguments reused approval solely through identical call ID'

def test_s1_s3_direct_denials(tmp_path):
    h=setup(tmp_path);h.prepare()
    for i,path in enumerate(('artifacts/../../.env',str(tmp_path.parent/'outside'))):
        r=h.gate.invoke(ToolCall('escape'+str(i),'read_file',{'path':path}))
        assert not r.executed and not r.ok
    r=h.gate.invoke(ToolCall('badcmd','run_test',{'command':'pytest; touch marker'}))
    assert not r.executed and not r.ok

def test_s2_recursive_search_cannot_read_outside_symlink(tmp_path):
    h=setup(tmp_path)
    outside=tmp_path/'outside.py';outside.write_text('OUTSIDE_SENTINEL = 42\n')
    (tmp_path/'repo/leak.py').symlink_to(outside)
    h.model=Fake([ToolCallAction('search','search_code',{'path':'.','query':'OUTSIDE_SENTINEL'})])
    result=h.run()
    observation=result.state.messages[0]['content']
    print('S2',observation)
    assert 'OUTSIDE_SENTINEL = 42' not in observation, 'Recursive child paths bypass Sandbox.resolve_path'

def test_s2_recursive_search_cannot_read_sensitive_directory(tmp_path):
    h=setup(tmp_path)
    (tmp_path/'repo/.git').mkdir();(tmp_path/'repo/.git/config.json').write_text('{"SENSITIVE_SENTINEL":42}')
    h.model=Fake([ToolCallAction('search','search_code',{'path':'.','query':'SENSITIVE_SENTINEL'})])
    result=h.run()
    print('S2_sensitive',result.state.messages[0]['content'])
    assert '"SENSITIVE_SENTINEL":42' not in result.state.messages[0]['content']

def test_h1_empty_artifact_rejected(tmp_path):
    h=setup(tmp_path,reads()+[write(''),FinalAnswerAction('done')])
    r=h.run();print('H1',r.status,r.stop_reason,'bytes=',(tmp_path/'artifacts/report.md').stat().st_size)
    assert not r.completed, 'Empty artifact accepted as completed'

def test_gate_final_answer_is_not_bypassed(tmp_path):
    h=setup(tmp_path,reads()+[write(),FinalAnswerAction('done')])
    seen=[];orig=h.gate.invoke
    def track(call):
        seen.append(call.tool_name);return orig(call)
    h.gate.invoke=track
    r=h.run();print('Gate calls:',seen,'status',r.status)
    assert 'final_answer' in seen

def test_normal_understanding_and_append_only(tmp_path):
    h=setup(tmp_path,reads()+[write(),FinalAnswerAction('done')],auto=False)
    r=h.run();assert r.stop_reason=='WAITING_APPROVAL'
    before=h.audit.path.read_bytes()
    h.approve(r.state.pending_approval.action_id)
    r=h.resume();assert r.completed and r.state.budget.tool_calls==3
    assert h.audit.path.read_bytes().startswith(before)
    assert 'module.caller calls app.add' in (tmp_path/'artifacts/report.md').read_text()
    records=h.audit.read_all()
    assert {'gate','sandbox','state','approval','execution','checkpoint'}<={x.phase for x in records}

@pytest.mark.parametrize('mode',['timeout','cancel'])
def test_s4_term_resistant_grandchild(tmp_path,mode):
    h=setup(tmp_path)
    pidfile=tmp_path/'pid'
    child="import signal,time,os;signal.signal(signal.SIGTERM,signal.SIG_IGN);open(%r,'w').write(str(os.getpid()));time.sleep(20)" % str(pidfile)
    parent="import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',%r]);time.sleep(20)" % child
    cancel=threading.Event()
    timer=threading.Timer(.5,cancel.set)
    if mode=='cancel':timer.start()
    result=h.sandbox.run_command((sys.executable,'-c',parent),timeout=.5 if mode=='timeout' else 10,cancel_event=cancel)
    pid=int(pidfile.read_text())
    def alive(pid):
        try:return Path(f'/proc/{pid}/stat').read_text().split()[2]!='Z'
        except FileNotFoundError:return False
    live=alive(pid)
    print('S4',result.to_dict(),'grandchild_alive',live)
    # Cleanup the isolated probe group, not a student-side fix.
    if live:
        os.killpg(result.pgid,signal.SIGKILL)
    assert not live and result.group_exited, 'Leader exited on TERM; surviving grandchild never receives KILL'

def test_h2_real_test_fix_stale_rejected_then_rerun_completes(tmp_path):
    import run_demo
    run_demo.reset_workspace(tmp_path/'task')
    task=run_demo.build_task(tmp_path/'task')
    # Match demo's bytecode policy. Use configured command for failure reproduction,
    # then two scope calls, respecting the submitted cumulative repeat limit of two.
    actions=[ToolCallAction('read','read_file',{'path':'app.py'}),ToolCallAction('before','run_test',{'scope':'target','command':list(run_demo.PYTEST_COMMAND)}),run_demo.patch_action('patch1'),ToolCallAction('after','run_test',{'scope':'target'}),write('Fixed app.add; real target pytest passed.'),ToolCallAction('patch2','apply_patch',{'path':'app.py','search':'return a + b','replace':'return a + b  # version 2'}),FinalAnswerAction('premature'),ToolCallAction('rerun','run_test',{'scope':'target'}),ToolCallAction('report2','write_file',{'path':'artifacts/report.md','content':'Fixed app.add version 2; target pytest rerun passed.'}),FinalAnswerAction('done')]
    h=Harness(model=Fake(actions),task=task,run_id='fix',config=HarnessConfig(auto_approve=True,extra_env=run_demo.EXTRA_ENV))
    r=h.run()
    tests=[e for e in r.state.evidence if e.kind=='test']
    print('H2',r.status,'test_exit_codes',[e.payload['exitCode'] for e in tests])
    assert r.completed
    assert [e.payload['exitCode'] for e in tests]==[1,0,0]
    assert tests[1].stale and not tests[2].stale
    rejected=[x for x in h.audit.read_all() if x.event=='FINAL_REJECTED']
    assert len(rejected)==1 and any('测试' in x for x in rejected[0].detail['missing'])

def test_e1_environment_and_output(tmp_path,monkeypatch):
    h=setup(tmp_path)
    monkeypatch.setenv('FAKE_SECRET_TOKEN','SYNTHETIC_ONLY')
    r=h.sandbox.run_command((sys.executable,'-c',"import os;print(os.getenv('FAKE_SECRET_TOKEN','ABSENT'));print('z'*10000)"))
    assert 'ABSENT' in r.output and 'SYNTHETIC_ONLY' not in r.output
    assert 'OUTPUT_TRUNCATED' in r.output and len(r.output)<8300

def child(mode, root):
    actions=reads()+[write(),ToolCallAction('r3','list_files',{'path':'.'}),FinalAnswerAction('done')]
    h=setup(root,actions)
    if mode=='c2-first':
        h.config.hooks=GateHooks(after_execute=lambda c,r: os._exit(19) if c.tool_name=='write_file' else None)
        h.gate.hooks=h.config.hooks
    elif mode=='c3-first':
        h.config.after_checkpoint=lambda s:os._exit(23) if s.budget.tool_calls==3 else None
    # Each process appends actual write-handler invocations to a durable counter.
    original=h.registry.get('write_file')
    def counted(call,context):
        with (root/'writes.jsonl').open('a') as f:f.write(json.dumps(call.to_dict())+'\n')
        return original(call,context)
    h.registry.register('write_file',counted)
    r=h.resume() if mode.endswith('second') else h.run()
    (root/'outcome.json').write_text(json.dumps({'status':str(r.status),'reason':str(r.stop_reason),'budget':r.state.budget.to_dict(),'unknown':r.state.unknown_results}))

@pytest.mark.parametrize('scenario,exit_code',[('c2',19),('c3',23)])
def test_c2_c3_independent_processes(tmp_path,scenario,exit_code):
    first=subprocess.run([sys.executable,__file__,scenario+'-first',str(tmp_path)],capture_output=True,text=True)
    assert first.returncode==exit_code,first.stderr
    second=subprocess.run([sys.executable,__file__,scenario+'-second',str(tmp_path)],capture_output=True,text=True)
    assert second.returncode==0,second.stderr
    data=json.loads((tmp_path/'outcome.json').read_text())
    writes=(tmp_path/'writes.jsonl').read_text().splitlines()
    print(scenario,data,'writes',len(writes))
    assert len(writes)==1
    if scenario=='c2':
        assert data['reason']=='UNKNOWN_RESULT' and data['unknown']==['w']
    else:
        assert data['reason']=='COMPLETED' and data['budget']['toolCalls']==4 and data['budget']['turns']==5

def test_c4_independent_processes(tmp_path):
    first=subprocess.run([sys.executable,__file__,'c3-first',str(tmp_path)],capture_output=True,text=True)
    assert first.returncode==23,first.stderr
    (tmp_path/'repo/module.py').write_text('EXTERNAL CHANGE\n')
    second=subprocess.run([sys.executable,__file__,'c3-second',str(tmp_path)],capture_output=True,text=True)
    assert second.returncode==0,second.stderr
    data=json.loads((tmp_path/'outcome.json').read_text())
    assert data['reason']=='WORKSPACE_CHANGED' and data['budget']['toolCalls']==3
    assert len((tmp_path/'writes.jsonl').read_text().splitlines())==1

if __name__=='__main__':
    child(sys.argv[1],Path(sys.argv[2]))
