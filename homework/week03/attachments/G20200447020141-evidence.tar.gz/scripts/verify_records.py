import json, sys, hashlib
from pathlib import Path
BASE=Path(__file__).resolve().parent
src=BASE/'kevin/homework/week03'
sys.path.insert(0,str(src))
from audit import AuditLog
from harness import Harness, ScriptedModel
import run_demo
records=src/'records'
d=json.loads((records/'complete_run.json').read_text())
workspace=records/'workspace/complete'
state=json.loads((workspace/'.agent-runs/run-complete-001/state.json').read_text())
checkpoint=json.loads((workspace/'.agent-runs/run-complete-001/checkpoint.json').read_text())
audit=AuditLog(records/'audit.jsonl')
raw=audit.read_all()
artifact=(workspace/'artifacts/report.md').read_bytes()
source=(workspace/'repo/app.py').read_bytes()
tests=(workspace/'repo/tests/test_app.py').read_bytes()
def digest(data):return hashlib.sha256(data).hexdigest()
aggregate=hashlib.sha256()
for name,content in [('app.py',source),('tests/test_app.py',tests)]:
    aggregate.update(f'repo:{name}\n'.encode());aggregate.update(content);aggregate.update(b'\n')
checks={
    'model':d['model'],
    'record_count':len(raw),
    'chain_valid':audit.verify_chain(),
    'artifact_bytes_match':len(artifact)==d['deliverables']['artifact']['bytes'],
    'artifact_hash_match':digest(artifact)==d['deliverables']['artifact']['sha256'],
    'source_after_hash_match':digest(source)==d['deliverables']['diff']['afterDigest'],
    'source_before_hash_match':digest(run_demo.SOURCE_BROKEN.encode())==d['deliverables']['diff']['beforeDigest'],
    'test_source_unchanged':tests.decode()==run_demo.TEST_FILE,
    'test_version_digest_matches':aggregate.hexdigest()==d['deliverables']['tests'][-1]['contentDigest'],
    'test_exit_codes':[x['exitCode'] for x in d['deliverables']['tests']],
    'tool_ids_match_audit':all(any(r.tool_call_id==c['toolCallId'] for r in raw) for c in state['toolCalls']),
    'state_and_checkpoint_match':checkpoint['payload']['state']==state,
    'audit_snapshot_matches':(records/'audit.jsonl').read_bytes()==(workspace/'.agent-runs/run-complete-001/audit.jsonl').read_bytes(),
    'resume':json.loads((records/'resume.json').read_text())['afterResume'],
}
print(json.dumps(checks,ensure_ascii=False,indent=2))
assert all(v is True for k,v in checks.items() if k.endswith(('match','matches','unchanged')))
assert checks['record_count']==65 and checks['chain_valid']
