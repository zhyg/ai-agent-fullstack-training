from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import shutil, tarfile, json, hashlib

ROOT=Path('/home/user/workspace/repo')
BASE=ROOT/'.amp/in/orb-backup'
OUT=ROOT/'.amp/in/week-grading'
PREFIX='G20200447020141-19380'
stage=BASE/'evidence-package'
stage.mkdir(exist_ok=True)
ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','*.pyc')
shutil.copytree(BASE/'kevin/homework/week03',stage/'student-week03',ignore=ignore,dirs_exist_ok=True)
shutil.copytree(BASE/'probe-workspaces-verified',stage/'teacher-workspaces',ignore=ignore,symlinks=True,dirs_exist_ok=True)
shutil.copytree(BASE/'evidence',stage/'logs',dirs_exist_ok=True)
shutil.copyfile(BASE/'commands.md',stage/'logs/commands.md')
(stage/'scripts').mkdir(exist_ok=True)
for name in ('offline_run.py','probes.py','verify_records.py','package_evidence.py'):
    shutil.copyfile(BASE/name,stage/'scripts'/name)
for name in ('feedback','evaluation'):
    shutil.copyfile(OUT/f'{PREFIX}-{name}.md',stage/f'{PREFIX}-{name}.md')
(stage/'standards').mkdir(exist_ok=True)
for name in ('第三周作业评分标准.md','AI Agent 全栈工程师训练营-作业三.md'):
    shutil.copyfile(ROOT/'hw-guide/week03'/name,stage/'standards'/name)
shutil.copyfile(ROOT/'hw-guide/学员作业反馈报告模板与要求.md',stage/'standards/学员作业反馈报告模板与要求.md')

score=(Decimal(1143)/Decimal(14)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
assert str(score)=='81.64'
feedback=(OUT/f'{PREFIX}-feedback.md').read_text()
assert feedback.startswith('<!-- submission:19380 -->\n# 第3周作业反馈')
sections=feedback.split('**')[4:]
for title in ('2. 作业优点','3. 作业不足','4. 改进方案'):
    text=feedback.split(f'**{title}**')[1].split('**')[0]
    assert len(text)<500,(title,len(text))
    assert 3<=sum(x.startswith('- ') for x in text.splitlines())<=5
    assert '扣分' not in text
files={}
for p in sorted(stage.rglob('*')):
    if p.is_file() and not p.is_symlink():
        assert not any(part in ('site-packages','venv','node_modules') for part in p.parts)
        files[str(p.relative_to(stage))]=hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'student':'Kevin','student_id':'G20200447020141','submission':'19380','student_head':'6e5ff556460418b6e2e1236b33386ab647eaf49f','course_head':'2422166b1af4b38f6835a85b303e01c442c1791a','score_exact':'1143/14','score':str(score),'grade':'优秀','acceptance':'未通过','student_pytest':{'passed':33,'failed':0,'skipped':0,'exit_code':0},'teacher_probes':{'passed':9,'failed':7,'exit_code':1},'sha256':files}
(stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
archive=OUT/f'{PREFIX}-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(stage.iterdir()):tar.add(p,arcname=p.name)
with tarfile.open(archive,'r:gz') as tar:
    names=tar.getnames()
    assert any('records/complete_run.json' in x for x in names)
    assert any('records/resume.json' in x for x in names)
    assert not any('/site-packages/' in x or '/venv/' in x or '/__pycache__/' in x for x in names)
print(json.dumps({'archive':str(archive),'files':len(names),'bytes':archive.stat().st_size,'score':str(score),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
