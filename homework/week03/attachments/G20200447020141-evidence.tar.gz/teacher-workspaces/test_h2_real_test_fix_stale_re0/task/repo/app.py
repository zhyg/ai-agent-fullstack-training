def add(a, b):
    return a + b  # version 2
