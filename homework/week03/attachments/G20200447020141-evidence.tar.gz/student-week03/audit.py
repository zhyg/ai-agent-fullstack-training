"""Audit：append-only 决策链日志。

每次 Tool Call 都会留下 Gate / Sandbox / Approval / State / Execution /
Checkpoint 各阶段的记录；拒绝记录一定带 ``rule``、``decision``、``actor``
和原始的 ``toolCallId``。文件为 JSONL，只能追加；每条记录带序号与前一条
哈希，可用 ``verify_chain`` 检查是否被篡改。日志只写元数据，不写完整
prompt、Token 或未脱敏正文。"""

from __future__ import annotations

import hashlib
import json
import os
import threading
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Iterable

try:  # POSIX 文件锁；非 POSIX 环境退化为进程内锁。
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None  # type: ignore[assignment]

REDACT_KEYS = ("token", "secret", "password", "authorization", "api_key")


class AuditPhase(StrEnum):
    GATE = "gate"
    SANDBOX = "sandbox"
    APPROVAL = "approval"
    STATE = "state"
    EXECUTION = "execution"
    CHECKPOINT = "checkpoint"
    COMPLETION = "completion"
    RESUME = "resume"
    MODEL = "model"


class AuditDecision(StrEnum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    NEEDS_APPROVAL = "NEEDS_APPROVAL"
    UNKNOWN_RESULT = "UNKNOWN_RESULT"
    INFO = "INFO"
    ERROR = "ERROR"


@dataclass(frozen=True, slots=True)
class AuditRecord:
    seq: int
    run_id: str
    tool_call_id: str
    phase: str
    event: str
    rule: str
    decision: str
    actor: str
    timestamp: str
    tool: str = ""
    detail: dict[str, Any] = field(default_factory=dict)
    prev_hash: str = ""
    record_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        """落盘使用 camelCase，与 toolCallId / runId 的审计契约一致。"""
        return {
            "seq": self.seq,
            "runId": self.run_id,
            "toolCallId": self.tool_call_id,
            "phase": self.phase,
            "event": self.event,
            "rule": self.rule,
            "decision": self.decision,
            "actor": self.actor,
            "timestamp": self.timestamp,
            "tool": self.tool,
            "detail": dict(self.detail),
            "prevHash": self.prev_hash,
            "hash": self.record_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditRecord:
        return cls(
            seq=int(data["seq"]),
            run_id=str(data["runId"]),
            tool_call_id=str(data["toolCallId"]),
            phase=str(data["phase"]),
            event=str(data["event"]),
            rule=str(data["rule"]),
            decision=str(data["decision"]),
            actor=str(data["actor"]),
            timestamp=str(data["timestamp"]),
            tool=str(data.get("tool", "")),
            detail=dict(data.get("detail", {})),
            prev_hash=str(data.get("prevHash", "")),
            record_hash=str(data.get("hash", "")),
        )

    def without_hash(self) -> dict[str, Any]:
        data = self.to_dict()
        data.pop("hash")
        return data

    def __getitem__(self, key: str) -> Any:
        """同时支持审计契约的 camelCase 与 Python 侧 snake_case 读取。"""
        data = self.to_dict()
        if key in data:
            return data[key]
        aliases = {
            "run_id": "runId",
            "tool_call_id": "toolCallId",
            "prev_hash": "prevHash",
            "record_hash": "hash",
        }
        if key in aliases:
            return data[aliases[key]]
        if hasattr(self, key):
            return getattr(self, key)
        raise KeyError(key)

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self[key]
        except KeyError:
            return default


def _canonical(data: dict[str, Any]) -> str:
    return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _hash_record(record: AuditRecord) -> str:
    return hashlib.sha256(
        (_canonical(record.without_hash())).encode("utf-8")
    ).hexdigest()


def _redact(detail: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in detail.items():
        if any(marker in key.lower() for marker in REDACT_KEYS):
            result[key] = "[REDACTED]"
        elif isinstance(value, str) and len(value) > 512:
            result[key] = value[:512] + "..."
        else:
            result[key] = value
    return result


class AuditLog:
    """单次运行的追加日志；也作为恢复时判断「未闭合操作」的 journal。"""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def append(
        self,
        *,
        run_id: str,
        phase: AuditPhase | str,
        event: str,
        rule: str,
        decision: AuditDecision | str,
        actor: str,
        tool_call_id: str = "",
        tool: str = "",
        detail: dict[str, Any] | None = None,
    ) -> AuditRecord:
        with self._lock:
            with open(self.path, "a+", encoding="utf-8") as handle:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                handle.seek(0)
                lines = [line for line in handle.read().splitlines() if line.strip()]
                last_seq = 0
                last_hash = ""
                if lines:
                    try:
                        previous = AuditRecord.from_dict(json.loads(lines[-1]))
                        last_seq = previous.seq
                        last_hash = previous.record_hash
                    except (ValueError, KeyError, TypeError):
                        last_seq = len(lines)
                record = AuditRecord(
                    seq=last_seq + 1,
                    run_id=run_id,
                    tool_call_id=tool_call_id,
                    phase=str(phase),
                    event=event,
                    rule=rule,
                    decision=str(decision),
                    actor=actor,
                    timestamp=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                    tool=tool,
                    detail=_redact(dict(detail or {})),
                    prev_hash=last_hash,
                )
                record = replace(record, record_hash=_hash_record(record))
                handle.seek(0, os.SEEK_END)
                handle.write(_canonical(record.to_dict()) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        return record

    def read_all(self) -> list[AuditRecord]:
        if not self.path.exists():
            return []
        records: list[AuditRecord] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                records.append(AuditRecord.from_dict(json.loads(line)))
        return records

    def records(
        self,
        *,
        run_id: str | None = None,
        tool_call_id: str | None = None,
        phase: str | None = None,
        event: str | None = None,
        decision: str | None = None,
        rule: str | None = None,
    ) -> list[AuditRecord]:
        result: list[AuditRecord] = []
        for record in self.read_all():
            if run_id is not None and record.run_id != run_id:
                continue
            if tool_call_id is not None and record.tool_call_id != tool_call_id:
                continue
            if phase is not None and record.phase != str(phase):
                continue
            if event is not None and record.event != event:
                continue
            if decision is not None and record.decision != str(decision):
                continue
            if rule is not None and record.rule != rule:
                continue
            result.append(record)
        return result

    def trace(self, run_id: str, tool_call_id: str) -> list[AuditRecord]:
        """还原一次调用的完整决策链（含 run 级记录）。"""
        return [
            record
            for record in self.read_all()
            if record.run_id == run_id
            and record.tool_call_id in {tool_call_id, ""}
        ]

    def open_write_operations(self, run_id: str) -> list[AuditRecord]:
        """有 TOOL_STARTED（replay=never）却无 TOOL_FINISHED 的写操作 = 结果不明。"""
        records = self.records(run_id=run_id)
        finished = {
            record.tool_call_id
            for record in records
            if record.event == "TOOL_FINISHED"
        }
        return [
            record
            for record in records
            if record.event == "TOOL_STARTED"
            and record.detail.get("replay") == "never"
            and record.tool_call_id not in finished
        ]

    def verify_chain(self) -> bool:
        previous_hash = ""
        for index, record in enumerate(self.read_all(), start=1):
            if record.seq != index or record.prev_hash != previous_hash:
                return False
            if record.record_hash != _hash_record(record):
                return False
            previous_hash = record.record_hash
        return True


def phases_of(records: Iterable[AuditRecord]) -> set[str]:
    return {record.phase for record in records}
