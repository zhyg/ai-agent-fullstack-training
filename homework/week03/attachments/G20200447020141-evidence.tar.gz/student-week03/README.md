# week03 — 可恢复的 Guarded Coding Harness

在不改写 smolagents 核心的前提下，为 ToolCallingAgent 的决策层套一层程序侧
门禁。模型只决定「下一步做什么」；参数、权限、风险、审批、重复动作、执行
边界、状态、审计、恢复与最终验收全部由程序负责。实现只用 Python 标准库，
`pytest -q` 不需要真实模型、网络或 smolagents。

## 运行

```bash
cd /home/linux/agent-training/homework/week03
python3 -m pytest -q
# 若 ROS 环境的 pytest 插件冲突：
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q
```

## 运行项目并获取三类记录

```bash
cd /home/linux/agent-training/homework/week03
python3 run_demo.py                  # 生成到 ./records（可重复执行，结果确定）
python3 run_demo.py --out /tmp/week03-records   # 指定输出目录
```

`run_demo.py` 是项目的运行入口：用 `ScriptedModel` 驱动一次真实的「测试修复」
任务（真实文件读写 + 真实 `pytest` 子进程），再模拟一次跨进程中断恢复，并
把三类记录写到 `records/`：

| 需求 | 文件 | 内容 |
| ---- | ---- | ---- |
| 至少一条完整运行记录 | `records/complete_run.json`、`records/complete_run.md` | `Harness.run()` 从 `RUN_STARTED` 到 `COMPLETED` 的全量时间线；每个 Tool Call 的 Gate/Sandbox/Approval/Execution/Evidence；交付物 sha256、源码 Diff 前后摘要、两次真实测试 exit=1→exit=0、最终答复、预算与计划状态 |
| 一份审计记录 | `records/audit.jsonl`（原始 append-only 日志）、`records/audit.json`、`records/audit.md` | 65 条记录、哈希链校验、按 `run_id`/`tool_call_id` 的 `byToolCall` 索引、含 `rule`/`decision`/`actor`/`toolCallId` 的拒绝记录、`trace()` 决策链还原示例 |
| 一份 Checkpoint 恢复记录 | `records/resume.json`、`records/resume.md` | 第一进程在安全边界 `os._exit(9)` 的存档 seq、第二进程的 `RESUME_ACCEPTED` 现场核对、恢复后计数不清零、`r2` 写入只执行一次；另附 `UNKNOWN_RESULT` 阻断对照 |

`records/records.json` 是三份记录的索引；`records/workspace/<场景>/.agent-runs/<run_id>/`
保留原始 `state.json`、`checkpoint.json`、`audit.jsonl` 以及产物、修复后源码，
可以按 `run_id` + `tool_call_id` 交叉印证。`tests/test_state_checkpoint.py`
中的 `test_run_demo_generates_all_three_records` 会在临时目录重跑这个入口并
校验三份记录，保证命令可复现。

## 交付物

| 文件 | 职责 |
| ---- | ---- |
| `gate.py` | 所有 Tool Call 的唯一入口 `Gate.invoke`；拒绝时返回带原 `tool_call_id` 的结构化结果，handler 零调用 |
| `sandbox.py` | realpath 真实落点、敏感目录、命令白名单、独立进程组超时/取消、环境变量与输出上限、内容摘要 |
| `state_store.py` | Run / 计划 / 步骤 / 证据 / 预算 / 审批 / 停止原因，原子写入 `state.json` |
| `checkpoint.py` | `schemaVersion + checksum` 存档、原子替换、恢复前现场核对、三态与 `UNKNOWN_RESULT` |
| `audit.py` | append-only JSONL 决策链（`rule`/`decision`/`actor`/`toolCallId`），带序号与哈希链 |
| `harness.py` | 装配 + 唯一运行入口 `Harness.run(resume=...)` + 完成契约 + StopReason；内置 Fake Model 与可选 smolagents 适配器 |
| `run_demo.py` | 项目运行入口：离线生成完整运行记录、审计记录、Checkpoint 恢复记录 |
| `records/` | 运行入口实际产出的三类记录及可复查的工作区状态 |
| `tests/` | 6 个指定测试文件，Fake Model 驱动全部正常/失败路径 |

运行产物位于 `<project_root>/.agent-runs/<run_id>/`：`state.json`、
`checkpoint.json`、`audit.jsonl`。

## 项目运行架构图

实线是主执行流，虚线是拒绝、状态回灌与安全步骤边界；模型只产出动作，
所有工具执行都必须通过 `Gate.invoke`。

```mermaid
flowchart TB
    subgraph ENTRY["运行入口 · run_demo.py"]
        CLI["CLI：python3 run_demo.py<br/>--child 用于跨进程恢复"]
        CFG["TaskSpec + HarnessConfig<br/>Model = ScriptedModel 或 SmolagentsModel"]
    end

    subgraph CORE["编排层 · harness.py"]
        RUN["Harness.run · 唯一运行入口"]
        PREP["prepare：创建 RunState<br/>写入初始存档"]
        LOOP["主循环：轮数 / 预算 / 取消检查"]
        DECIDE["Model.decide ModelView<br/>ToolCallAction 或 FinalAnswerAction"]
        EVID["_record_evidence + _sync_plan<br/>证据绑定代码版本与内容摘要"]
        CONTRACT["CompletionContract.verify<br/>交付物 / Diff / 最新有效测试 / 计划"]
        STOP["StopReason + 终态<br/>COMPLETED 或明确停止原因"]
    end

    subgraph GUARD["门禁与执行边界"]
        GATE["Gate.invoke<br/>所有 Tool Call 的唯一入口"]
        CHECKS["参数 → 权限 → 风险与重复动作 → 计划步骤"]
        SBX["Sandbox.validate_tool_call<br/>realpath / 敏感目录 / 命令白名单<br/>进程组超时 / 环境变量 / 输出上限"]
        APPR["一次性审批<br/>auto 或 WAITING_APPROVAL"]
        HDL["HandlerRegistry → 内置 handler<br/>真实文件 IO / pytest 子进程"]
    end

    subgraph PERSIST["状态 · 存档 · 审计"]
        ST["StateStore + RunState<br/>state.json"]
        CK["CheckpointManager<br/>checkpoint.json：版本 + 校验和 + 原子替换"]
        AU["AuditLog<br/>audit.jsonl：append-only + 哈希链"]
    end

    subgraph OUT["产物与证据"]
        WS["artifacts/*.md / 修复后源码 / 测试证据"]
        REC["records/：完整运行 / 审计 / 恢复 / pytest 结果"]
    end

    CLI --> CFG --> RUN --> PREP --> LOOP --> DECIDE
    DECIDE -->|"工具动作"| GATE
    GATE --> CHECKS --> SBX --> APPR
    APPR -->|"放行：先记 TOOL_STARTED"| HDL
    HDL -->|"ToolResult"| EVID
    EVID --> ST --> CK --> AU
    CK -.->|"每个安全步骤后存档"| LOOP
    CHECKS -.->|"拒绝"| AU
    SBX -.->|"越界或配置外命令"| AU
    APPR -.->|"待审批"| ST
    GATE -.->|"结构化错误 + 原 toolCallId，handler 零调用"| DECIDE
    DECIDE -->|"最终答复"| CONTRACT
    CONTRACT -->|"缺项：FINAL_REJECTED + follow-up"| LOOP
    CONTRACT -->|"验收通过"| STOP
    LOOP -->|"轮数 / 预算 / 取消"| STOP
    STOP --> REC
    HDL --> WS --> REC
    AU --> REC
```

### 恢复路径与证据出口

```mermaid
flowchart LR
    subgraph P1["进程 1：正常运行"]
        A1["Harness.run"] --> A2["工具调用闭合后 checkpoint.save"]
        A2 --> A3["安全步骤边界中断<br/>os._exit 9"]
    end

    subgraph DISK["落盘 · .agent-runs/runId/"]
        F1["state.json<br/>完整业务状态"]
        F2["checkpoint.json<br/>run / plan / steps / evidence<br/>budget / approvals / pendingApproval"]
        F3["audit.jsonl<br/>TOOL_STARTED ↔ TOOL_FINISHED"]
    end

    subgraph P2["进程 2：resume"]
        B1["Harness.run resume=True"] --> B2["inspect_resume<br/>存档校验 → 工作区摘要<br/>→ 未闭合操作 → 旧证据与审批"]
        B2 -->|"WORKSPACE_CHANGED / STALE_APPROVAL"| B3["停止并等待人工核对"]
        B2 -->|"UNKNOWN_RESULT"| B4["标记结果不明<br/>绝不自动重放写操作"]
        B2 -->|"全部通过"| B5["还原 RunState<br/>轮数与计数不清零"]
        B5 --> B6["重放已批准动作一次<br/>→ 续跑 → COMPLETED"]
    end

    subgraph REPORTS["records/ 可复查证据"]
        O1["complete_run.json / .md"]
        O2["audit.jsonl / audit.json / .md"]
        O3["resume.json / .md"]
        O4["pytest-result.txt"]
    end

    A3 --> F1
    A3 --> F2
    A3 --> F3
    F1 --> B2
    F2 --> B2
    F3 --> B2
    B6 --> O1
    B6 --> O3
    F2 --> O3
    F3 --> O2
    TESTS["tests/ 六个测试文件<br/>pytest -q：33 passed"] --> O4
```

读图要点：

- 业务规则集中在 `Gate`、`Sandbox`、`CompletionContract` 与 `Harness`，内置 handler 只做 IO。
- 任何一层拒绝都直接回灌模型并写 `AuditLog`，不进入 handler、不改变工作区。
- 每个工具调用闭合后写 Checkpoint；恢复必须先通过 `inspect_resume` 的现场核对。
- 完成由契约裁决，模型自述不能进入 `COMPLETED`；停止一律带明确 `StopReason`。

## 关键规则

- 参数/权限/重复动作/计划步骤/Sandbox 预检都在 handler 之前；写操作必须
  有一次性审批，审批绑定 `tool_call_id`、动作指纹和工作区摘要。
- 每个工具调用闭合后（含进入等待审批前）写 Checkpoint；写操作开始前先记
  `TOOL_STARTED`，正常结束才记 `TOOL_FINISHED`。有启动无闭合即
  `UNKNOWN_RESULT`，恢复时停止自动推进、绝不重放。
- 测试证据绑定「受测文件 + 目标源码」的内容摘要与代码版本；源码变化后
  旧证据立即失效，完成契约只认每个范围最新一条有效且通过的证据。
- 模型 self-report 的 final answer 必须由完成契约验收；达到轮数/预算上限
  以明确 `StopReason` 停止，不伪装成功。

## 恢复与人工审批

```python
h = Harness(model=model, task=task, run_id="run-1")
first = h.run()                         # WAITING_APPROVAL
h.approve(first.state.pending_approval.action_id)
h2 = Harness(model=model, task=task, run_id="run-1")
result = h2.run(resume=True)            # 重放已批准动作一次，继续后续步骤
```

## 验收映射

| 编号 | 覆盖测试 |
| ---- | ---- |
| G1–G4 | `tests/test_gate.py` |
| S1–S4 | `tests/test_sandbox.py`（S4 用真实孙进程核实进程组退出） |
| C1–C4 | `tests/test_state_checkpoint.py`（C3 用真正的 `subprocess` 新进程恢复） |
| A1–A2 | `tests/test_audit.py` |
| H1/H3、Loop | `tests/test_harness_loop.py` |
| H1/H2、完成契约 | `tests/test_completion.py` |
| 三类记录可复现 | `tests/test_state_checkpoint.py::test_run_demo_generates_all_three_records` |

## T2（真实模型，P1，本环境未执行）

`harness.SmolagentsModel` 惰性导入 smolagents，借用 `ToolCallingAgent` 的
`model`、系统提示与工具声明做决策，工具执行仍只经 `Gate.invoke`。接入方式：

```bash
pip install smolagents
```

```python
from smolagents import ToolCallingAgent, OpenAIServerModel  # 或任意受支持模型
model = SmolagentsModel(ToolCallingAgent(model=OpenAIServerModel(...), tools=[]))
# 默认是人工审批；演示可直接自动审批，生产环境应保留 WAITING_APPROVAL 流程
result = Harness(
    model=model, task=task, run_id="run-live",
    config=HarnessConfig(auto_approve=True),
).run()
```

本环境未安装 smolagents、也没有模型凭据，因此「真实模型」这一步未实际跑通；
`python3 run_demo.py` 已用 `ScriptedModel` 产出一条可复查的完整离线运行记录，
产物、diff 证据、真实测试记录和 `records/audit.jsonl` 可按 `run_id` +
`tool_call_id` 相互印证。把上面代码里的 `Harness` 换成同一套装配后重跑，即可
生成同格式的真实模型记录。本机若遇 ROS pytest 插件冲突，使用上面的
`PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` 命令。
