"""week03 项目运行入口：离线生成三条可复查的交付记录。

    python3 run_demo.py                 # 生成到 ./records
    python3 run_demo.py --out <目录>    # 指定输出目录
    python3 run_demo.py --child <参数>  # 内部使用：跨进程恢复的子进程

产出：
    1. complete_run.json / .md  —— 一条从启动到 COMPLETED 的完整运行记录
    2. audit.jsonl / audit.json / .md —— 全量 append-only 审计记录与决策链还原
    3. resume.json / .md —— 安全边界中断 → 新进程恢复 → 完成（含结果不明对照）

全部使用 ScriptedModel（确定性 Fake Model）+ 真实文件 IO + 真实测试子进程，
不需要网络、API Key 或 smolagents；因此每次运行都可复现。
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import shutil
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audit import AuditLog  # noqa: E402
from gate import GateHooks  # noqa: E402
from harness import (  # noqa: E402
    KIND_TEST_FIX,
    FinalAnswerAction,
    Harness,
    HarnessConfig,
    ScriptedModel,
    TaskSpec,
    ToolCallAction,
)

SOURCE_BROKEN = "def add(a, b):\n    return a - b\n"
SOURCE_FIXED = "def add(a, b):\n    return a + b\n"
TEST_FILE = (
    "import sys\n"
    "from pathlib import Path\n"
    "sys.path.insert(0, str(Path(__file__).resolve().parents[1]))\n"
    "from app import add\n"
    "\n"
    "def test_add():\n"
    "    assert add(2, 2) == 4\n"
)
PYTEST_COMMAND = (
    sys.executable,
    "-m",
    "pytest",
    "-q",
    "-p",
    "no:cacheprovider",
    "tests/test_app.py",
)
COMPLETE_RUN_ID = "run-complete-001"
RESUME_RUN_ID = "run-resume-001"
UNKNOWN_RUN_ID = "run-unknown-001"
EXTRA_ENV = {"PYTHONDONTWRITEBYTECODE": "1"}


# ----------------------------------------------------------------- 工作区与任务

def reset_workspace(workspace: Path) -> None:
    if workspace.exists():
        shutil.rmtree(workspace)
    (workspace / "repo" / "tests").mkdir(parents=True)
    (workspace / "artifacts").mkdir(parents=True)
    (workspace / "repo" / "app.py").write_text(SOURCE_BROKEN, encoding="utf-8")
    (workspace / "repo" / "tests" / "test_app.py").write_text(
        TEST_FILE, encoding="utf-8"
    )
    # 固定 pytest rootdir，避免向上误读 week03/pytest.ini。
    (workspace / "repo" / "pytest.ini").write_text(
        "[pytest]\ntestpaths = tests\n", encoding="utf-8"
    )


def build_task(workspace: Path) -> TaskSpec:
    return TaskSpec(
        kind=KIND_TEST_FIX,
        title="修复 add() 并生成交付说明",
        repo_root=workspace / "repo",
        project_root=workspace,
        target_source="app.py",
        artifact="artifacts/report.md",
        required_scopes=("target",),
        suite_files={"target": ("tests/test_app.py",)},
        allowed_commands={"pytest": PYTEST_COMMAND},
        test_scopes={"target": "pytest"},
        tracked_files=("app.py", "tests/test_app.py"),
        min_read_files=1,
        max_turns=12,
        max_tool_calls=12,
        timeout_seconds=30.0,
        kill_grace_seconds=0.5,
    )


def patch_action(call_id: str) -> ToolCallAction:
    return ToolCallAction(
        call_id,
        "apply_patch",
        {
            "path": "app.py",
            "search": "return a - b",
            "replace": "return a + b",
        },
    )


def artifact_action(call_id: str) -> ToolCallAction:
    return ToolCallAction(
        call_id,
        "write_file",
        {
            "path": "artifacts/report.md",
            "content": "修复说明：add(a, b) 由减法改为加法，测试已重跑通过。\n",
        },
    )


def complete_actions() -> list[Any]:
    """一次完整修复闭环，并在同一条审计链里留下三种被拒绝的调用。

    拒绝动作不进入 handler、不改变工作区，用来证明 A1 的
    rule / decision / actor / toolCallId 与 S1/S3 的执行前拦截。
    """
    return [
        ToolCallAction("c0-invalid", "read_file", {"path": 123}),
        ToolCallAction(
            "c0-escape",
            "write_file",
            {"path": "artifacts/../../.env", "content": "must not be written"},
        ),
        ToolCallAction("c0-command", "run_test", {"command": "rm -rf /"}),
        ToolCallAction("c1", "read_file", {"path": "app.py"}),
        ToolCallAction("c2", "run_test", {"scope": "target"}),
        patch_action("c3"),
        ToolCallAction("c4", "run_test", {"scope": "target"}),
        artifact_action("c5"),
        FinalAnswerAction("修复完成：当前版本测试通过并生成交付说明"),
    ]


def resume_actions() -> list[Any]:
    return [
        ToolCallAction("r1", "read_file", {"path": "app.py"}),
        patch_action("r2"),
        ToolCallAction("r3", "run_test", {"scope": "target"}),
        ToolCallAction("r4", "read_file", {"path": "tests/test_app.py"}),
        artifact_action("r5"),
        FinalAnswerAction("恢复后续跑完成"),
    ]


def wrap_handlers(harness: Harness, sink: Path) -> None:
    """给真实 handler 加一层调用留痕，用于跨进程核对写入是否重复。"""
    for name in (
        "read_file", "list_files", "search_code", "write_file",
        "apply_patch", "run_test",
    ):
        original = harness.registry.get(name)
        if original is None:
            continue

        def make(tool_name: str, handler: Any):
            def wrapped(call: Any, context: Any):
                with open(sink, "a", encoding="utf-8") as handle:
                    handle.write(
                        json.dumps(
                            {"tool": tool_name, "toolCallId": call.tool_call_id}
                        )
                        + "\n"
                    )
                return handler(call, context)

            return wrapped

        harness.registry.register(name, make(name, original))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def display_path(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT))
    except ValueError:
        return str(path.resolve())


def _cell(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", "<br>")


def md_table(headers: list[str], rows: list[list[Any]]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(_cell(item) for item in row) + " |")
    return "\n".join(lines)


# --------------------------------------------------------------- 1. 完整运行记录

def build_complete_run(out: Path) -> dict[str, Any]:
    workspace = out / "workspace" / "complete"
    reset_workspace(workspace)
    source_before = (workspace / "repo" / "app.py").read_text(encoding="utf-8")
    harness = Harness(
        model=ScriptedModel(complete_actions()),
        task=build_task(workspace),
        run_id=COMPLETE_RUN_ID,
        config=HarnessConfig(auto_approve=True, extra_env=EXTRA_ENV),
    )
    result = harness.run()
    if not result.completed:
        raise RuntimeError(f"完整运行未进入完成态：{result.stop_reason} {result.missing}")

    run_dir = harness.state_store.run_dir(COMPLETE_RUN_ID)
    audit_path = run_dir / "audit.jsonl"
    records = read_jsonl(audit_path)
    state = result.state
    source_after = (workspace / "repo" / "app.py").read_text(encoding="utf-8")
    artifact_path = workspace / "artifacts" / "report.md"
    artifact_text = artifact_path.read_text(encoding="utf-8")

    by_call: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        if record["toolCallId"]:
            by_call[record["toolCallId"]].append(record)

    tool_calls: list[dict[str, Any]] = []
    for call_id, events in by_call.items():
        tool_calls.append(
            {
                "toolCallId": call_id,
                "tool": events[0]["tool"],
                "gateDecision": next(
                    (
                        item["decision"]
                        for item in events
                        if item["event"] == "GATE_DECISION"
                    ),
                    None,
                ),
                "sandboxRule": next(
                    (
                        item["rule"]
                        for item in events
                        if item["event"] == "SANDBOX_CHECK"
                    ),
                    None,
                ),
                "approvalEvents": [
                    item["event"] for item in events if item["phase"] == "approval"
                ],
                "executionEvents": [
                    item["event"]
                    for item in events
                    if item["event"]
                    in {"TOOL_STARTED", "TOOL_FINISHED", "EXECUTION_RESULT"}
                ],
                "evidence": [
                    {
                        "kind": str(item.kind),
                        "revision": item.revision,
                        "stale": item.stale,
                        "payload": item.payload,
                    }
                    for item in state.evidence
                    if item.tool_call_id == call_id
                ],
            }
        )

    diff_evidence = next(
        item for item in state.evidence if str(item.kind) == "diff"
    )
    test_evidences = [
        item for item in state.evidence if str(item.kind) == "test"
    ]
    deliverables = {
        "artifact": {
            "path": "artifacts/report.md",
            "bytes": len(artifact_text.encode("utf-8")),
            "sha256": sha256_text(artifact_text),
            "content": artifact_text.strip(),
        },
        "diff": {
            "path": "app.py",
            "beforeDigest": diff_evidence.payload["beforeDigest"],
            "afterDigest": diff_evidence.payload["afterDigest"],
            "sourceBefore": source_before.strip(),
            "sourceAfter": source_after.strip(),
        },
        "tests": [
            {
                "scope": item.payload.get("scope"),
                "exitCode": item.payload.get("exitCode"),
                "passed": item.payload.get("passed"),
                "contentDigest": item.content_digest,
                "files": item.payload.get("files"),
                "stale": item.stale,
                "command": list(item.payload.get("command", ())),
                "output": item.payload.get("output", ""),
            }
            for item in test_evidences
        ],
    }
    timeline = [
        {
            "seq": item["seq"],
            "timestamp": item["timestamp"],
            "phase": item["phase"],
            "event": item["event"],
            "rule": item["rule"],
            "decision": item["decision"],
            "actor": item["actor"],
            "toolCallId": item["toolCallId"],
        }
        for item in records
    ]
    files = {
        "state": display_path(run_dir / "state.json"),
        "checkpoint": display_path(run_dir / "checkpoint.json"),
        "audit": display_path(audit_path),
        "source": display_path(workspace / "repo" / "app.py"),
        "artifact": display_path(artifact_path),
    }
    summary = {
        "runId": COMPLETE_RUN_ID,
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "model": "ScriptedModel（离线确定性 Fake Model）",
        "entryPoint": "Harness.run()",
        "task": state.task,
        "status": str(state.status),
        "stopReason": str(state.stop_reason),
        "revision": state.revision,
        "finalAnswer": state.final_answer,
        "modelCursor": state.model_cursor,
        "budget": state.budget.to_dict(),
        "plan": [item.to_dict() for item in state.plan.steps],
        "timeline": timeline,
        "toolCalls": tool_calls,
        "deliverables": deliverables,
        "auditChainValid": harness.audit.verify_chain(),
        "files": files,
    }
    (out / "complete_run.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (out / "complete_run.md").write_text(
        _complete_markdown(summary), encoding="utf-8"
    )
    return {"harness": harness, "runId": COMPLETE_RUN_ID, "summary": summary}


def _complete_markdown(summary: dict[str, Any]) -> str:
    deliverables = summary["deliverables"]
    rows = [
        [
            item["seq"], item["phase"], item["event"], item["rule"],
            item["decision"], item["actor"], item["toolCallId"],
        ]
        for item in summary["timeline"]
    ]
    call_rows = [
        [
            item["toolCallId"], item["tool"], item["gateDecision"] or "-",
            item["sandboxRule"] or "-", ", ".join(item["approvalEvents"]) or "-",
            ", ".join(item["executionEvents"]),
            ", ".join(
                f"{ev['kind']}(stale={ev['stale']})" for ev in item["evidence"]
            ) or "-",
        ]
        for item in summary["toolCalls"]
    ]
    test_rows = [
        [
            item["scope"], item["exitCode"], item["passed"], item["stale"],
            item["contentDigest"], " ".join(item["command"]),
        ]
        for item in deliverables["tests"]
    ]
    files = "\n".join(f"- `{key}`: `{value}`" for key, value in summary["files"].items())
    return "\n".join(
        [
            f"# 完整运行记录 `{summary['runId']}`",
            "",
            f"- 生成时间：{summary['generatedAt']}",
            f"- 模型：{summary['model']}；运行入口：`{summary['entryPoint']}`",
            f"- 任务：{summary['task']['title']}（{summary['task']['kind']}）",
            f"- 结果：`{summary['status']}` / `{summary['stopReason']}`，代码版本 `{summary['revision']}`",
            f"- 模型决策数：{summary['modelCursor']}；预算：{json.dumps(summary['budget'], ensure_ascii=False)}",
            f"- 最终答复：{summary['finalAnswer']}",
            f"- 审计哈希链完整：{summary['auditChainValid']}",
            "",
            "## 运行时间线（来自 append-only audit.jsonl）",
            "",
            md_table(
                ["seq", "phase", "event", "rule", "decision", "actor", "toolCallId"],
                rows,
            ),
            "",
            "## 工具调用与证据绑定",
            "",
            md_table(
                [
                    "toolCallId", "tool", "gate", "sandbox", "approval",
                    "execution", "evidence",
                ],
                call_rows,
            ),
            "",
            "## 交付物、Diff 与测试记录相互印证",
            "",
            f"- 交付物 `{deliverables['artifact']['path']}`："
            f"{deliverables['artifact']['bytes']} bytes，sha256="
            f"`{deliverables['artifact']['sha256']}`；内容：{deliverables['artifact']['content']}",
            f"- Diff `{deliverables['diff']['path']}`："
            f"`{deliverables['diff']['beforeDigest']}` → "
            f"`{deliverables['diff']['afterDigest']}`；"
            f"{deliverables['diff']['sourceBefore']} ⇒ {deliverables['diff']['sourceAfter']}",
            "",
            md_table(
                ["scope", "exitCode", "passed", "stale", "contentDigest", "command"],
                test_rows,
            ),
            "",
            "> 第一次测试在修复前运行（exit=1）；源码修改后旧证据被标记 stale，"
            "第二次测试在当前版本重新运行（exit=0）才允许进入完成态。",
            "",
            "## 可复查文件",
            "",
            files,
            "",
        ]
    )


# ------------------------------------------------------------------- 2. 审计记录

def build_audit_record(harness: Harness, out: Path, run_id: str) -> dict[str, Any]:
    source = harness.state_store.run_dir(run_id) / "audit.jsonl"
    target = out / "audit.jsonl"
    shutil.copyfile(source, target)
    records = [item.to_dict() for item in harness.audit.read_all()]
    by_call: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        by_call[record["toolCallId"] or "(run-level)"].append(record)
    denied = [item for item in records if item["decision"] in {"DENY", "NEEDS_APPROVAL"}]
    phases = sorted({item["phase"] for item in records})
    # 优先挑一条带审批的写操作，示例能覆盖 Gate/Sandbox/Approval/Execution 全链路。
    example_id = next(
        (item["toolCallId"] for item in records if item["phase"] == "approval"),
        "",
    ) or next(
        (item["toolCallId"] for item in records if item["event"] == "TOOL_STARTED"),
        "",
    )
    trace = [item for item in harness.audit.trace(run_id, example_id)]
    call_records = [
        item.to_dict()
        for item in harness.audit.records(run_id=run_id, tool_call_id=example_id)
    ]
    report = {
        "runId": run_id,
        "file": display_path(target),
        "recordCount": len(records),
        "chainValid": harness.audit.verify_chain(),
        "phases": phases,
        "decisionCounts": dict(Counter(item["decision"] for item in records)),
        "deniedRecords": denied,
        "byToolCall": dict(by_call),
        "traceExample": {
            "toolCallId": example_id,
            "callRecords": call_records,
            "runLevelRecordCount": len(trace) - len(call_records),
            "events": [
                {
                    "seq": item.seq,
                    "phase": item.phase,
                    "event": item.event,
                    "rule": item.rule,
                    "decision": item.decision,
                    "actor": item.actor,
                }
                for item in trace
            ],
        },
        "fullRecords": records,
    }
    (out / "audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (out / "audit.md").write_text(_audit_markdown(report), encoding="utf-8")
    return {
        "runId": run_id,
        "recordCount": len(records),
        "chainValid": report["chainValid"],
        "phases": phases,
        "files": [display_path(target), display_path(out / "audit.json"), display_path(out / "audit.md")],
    }


def _audit_markdown(report: dict[str, Any]) -> str:
    rows = [
        [
            item["seq"], item["phase"], item["event"], item["rule"],
            item["decision"], item["actor"], item["toolCallId"], item["tool"],
        ]
        for item in report["fullRecords"]
    ]
    denied_rows = [
        [
            item["seq"], item["toolCallId"], item["rule"],
            item["decision"], item["actor"], item["event"],
        ]
        for item in report["deniedRecords"]
    ]
    trace_rows = [
        [
            item["seq"], item["phase"], item["event"], item["rule"],
            item["decision"], item["actor"],
        ]
        for item in report["traceExample"]["callRecords"]
    ]
    return "\n".join(
        [
            f"# 审计记录 `{report['runId']}`",
            "",
            f"- 原始日志：`{report['file']}`（append-only JSONL，{report['recordCount']} 条）",
            f"- 哈希链校验：{report['chainValid']}",
            f"- 阶段：{', '.join(report['phases'])}",
            f"- decision 分布：{json.dumps(report['decisionCounts'], ensure_ascii=False)}",
            "",
            "## 全量记录",
            "",
            md_table(
                ["seq", "phase", "event", "rule", "decision", "actor", "toolCallId", "tool"],
                rows,
            ),
            "",
            "## 拒绝 / 待审批记录（A1：含 rule、decision、actor、toolCallId）",
            "",
            md_table(["seq", "toolCallId", "rule", "decision", "actor", "event"], denied_rows)
            if denied_rows
            else "本次完整运行没有拒绝记录（G1/G2/S1/S3 的拒绝路径见 pytest 用例）。",
            "",
            f"## 决策链还原示例 `{report['traceExample']['toolCallId']}`（A2）",
            "",
            md_table(["seq", "phase", "event", "rule", "decision", "actor"], trace_rows),
            "",
            f"> 另有 {report['traceExample']['runLevelRecordCount']} 条 run 级记录"
            "（RUN_STARTED / MODEL_DECISION / CHECKPOINT_SAVED / FINAL_ACCEPTED），"
            "由 `AuditLog.trace(run_id, tool_call_id)` 一并返回，用于关联同一 Run 的上下文。",
            "",
        ]
    )


# --------------------------------------------------------- 3. Checkpoint 恢复记录

class CrashAfterWrite(Exception):
    """模拟写入已落盘但结果未保存的进程崩溃。"""


def build_resume_record(out: Path) -> dict[str, Any]:
    workspace = out / "workspace" / "resume"
    reset_workspace(workspace)
    sink = workspace / "handler_calls.jsonl"
    params = {
        "workspace": str(workspace),
        "runId": RESUME_RUN_ID,
        "sink": str(sink),
        "phase": "first",
        "result": str(out / "_resume_first.json"),
    }
    params_path = out / "resume_child_params.json"
    processes: dict[str, dict[str, Any]] = {}
    checkpoint_after_first: dict[str, Any] | None = None
    for phase in ("first", "second"):
        params["phase"] = phase
        params["result"] = str(out / f"_resume_{phase}.json")
        params_path.write_text(json.dumps(params), encoding="utf-8")
        completed = subprocess.run(
            [sys.executable, str(ROOT / "run_demo.py"), "--child", str(params_path)],
            capture_output=True,
            text=True,
            timeout=120,
            cwd=str(ROOT),
        )
        processes[phase] = {
            "returncode": completed.returncode,
            "stdout": completed.stdout.strip(),
            "stderr": completed.stderr.strip(),
        }
        if phase == "first":
            checkpoint_after_first = json.loads(
                (workspace / ".agent-runs" / RESUME_RUN_ID / "checkpoint.json")
                .read_text(encoding="utf-8")
            )

    first_result = json.loads((out / "_resume_first.json").read_text(encoding="utf-8")) \
        if (out / "_resume_first.json").exists() else None
    second_result = json.loads((out / "_resume_second.json").read_text(encoding="utf-8"))
    run_dir = workspace / ".agent-runs" / RESUME_RUN_ID
    final_checkpoint = json.loads((run_dir / "checkpoint.json").read_text(encoding="utf-8"))
    final_state = json.loads((run_dir / "state.json").read_text(encoding="utf-8"))
    audit_records = read_jsonl(run_dir / "audit.jsonl")
    handler_calls = read_jsonl(sink)
    artifact_text = (workspace / "artifacts" / "report.md").read_text(encoding="utf-8")
    source_text = (workspace / "repo" / "app.py").read_text(encoding="utf-8")
    accepted = [item for item in audit_records if item["event"] == "RESUME_ACCEPTED"]
    blocked = [item for item in audit_records if item["event"] == "RESUME_BLOCKED"]
    open_writes = AuditLog(run_dir / "audit.jsonl").open_write_operations(RESUME_RUN_ID)
    unknown_case = build_unknown_result_case(out)

    summary = {
        "runId": RESUME_RUN_ID,
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "interruption": {
            "phase": "first",
            "mechanism": "安全步骤边界（checkpoint.save 之后）os._exit(9)",
            "returncode": processes["first"]["returncode"],
            "checkpointSeq": checkpoint_after_first["seq"] if checkpoint_after_first else None,
            "checkpointReason": checkpoint_after_first["reason"] if checkpoint_after_first else None,
            "checkpointContains": sorted(checkpoint_after_first["payload"].keys())
            if checkpoint_after_first
            else [],
            "modelResultFileWritten": first_result is not None,
        },
        "resumePrecheck": {
            "event": "RESUME_ACCEPTED",
            "count": len(accepted),
            "detail": accepted[-1]["detail"] if accepted else None,
            "openWriteOperations": len(open_writes),
            "blockedEvents": len(blocked),
            "checkpointSchemaVersion": final_checkpoint["schemaVersion"],
        },
        "afterResume": {
            "processReturncode": processes["second"]["returncode"],
            "status": second_result["status"],
            "stopReason": second_result["stopReason"],
            "toolCalls": second_result["toolCalls"],
            "modelCursor": second_result["modelCursor"],
            "checkpoints": second_result["checkpoints"],
            "revision": second_result["revision"],
            "finalCheckpointSeq": final_checkpoint["seq"],
            "finalStateStatus": final_state["status"],
        },
        "noReplay": {
            "writeToolCallId": "r2",
            "applyPatchHandlerInvocations": sum(
                1 for item in handler_calls if item["toolCallId"] == "r2"
            ),
            "allHandlerCalls": [item["toolCallId"] for item in handler_calls],
            "sourceContainsFixOnce": source_text.count("return a + b") == 1,
            "artifactSha256": sha256_text(artifact_text),
        },
        "unknownResultControl": unknown_case,
        "files": {
            "checkpoint": display_path(run_dir / "checkpoint.json"),
            "state": display_path(run_dir / "state.json"),
            "audit": display_path(run_dir / "audit.jsonl"),
            "handlerCalls": display_path(sink),
            "workspace": display_path(workspace),
        },
    }
    (out / "resume.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (out / "resume.md").write_text(_resume_markdown(summary), encoding="utf-8")
    for phase in ("first", "second"):
        (out / f"_resume_{phase}.json").unlink(missing_ok=True)
    params_path.unlink(missing_ok=True)
    return {"runId": RESUME_RUN_ID, **{k: v for k, v in summary.items() if k != "files"}}


def build_unknown_result_case(out: Path) -> dict[str, Any]:
    workspace = out / "workspace" / "unknown-result"
    reset_workspace(workspace)

    def crash(call: Any, result: Any) -> None:
        if call.tool_name == "write_file":
            raise CrashAfterWrite("写入已完成，结果未保存")

    first = Harness(
        model=ScriptedModel(
            [
                ToolCallAction(
                    "u1",
                    "write_file",
                    {"path": "artifacts/report.md", "content": "结果不明演示"},
                ),
                FinalAnswerAction("完成"),
            ]
        ),
        task=build_task(workspace),
        run_id=UNKNOWN_RUN_ID,
        config=HarnessConfig(
            auto_approve=True,
            extra_env=EXTRA_ENV,
            hooks=GateHooks(after_execute=crash),
        ),
    )
    with contextlib.suppress(CrashAfterWrite):
        first.run()
    sink = workspace / "replay_calls.jsonl"
    resumed = Harness(
        model=ScriptedModel([]),
        task=build_task(workspace),
        run_id=UNKNOWN_RUN_ID,
        config=HarnessConfig(auto_approve=True, extra_env=EXTRA_ENV),
    )
    wrap_handlers(resumed, sink)
    result = resumed.run(resume=True)
    return {
        "runId": UNKNOWN_RUN_ID,
        "crashPoint": "handler 写盘之后、TOOL_FINISHED / checkpoint 之前",
        "blocked": result.blocked,
        "stopReason": str(result.stop_reason),
        "unknownResults": result.state.unknown_results,
        "artifactStillOnDisk": (workspace / "artifacts" / "report.md").is_file(),
        "handlerReplaysAfterResume": len(read_jsonl(sink)),
        "conclusion": "结果不明的写操作被标记 UNKNOWN_RESULT，恢复时停止且不自动重放",
    }


def _resume_markdown(summary: dict[str, Any]) -> str:
    interruption = summary["interruption"]
    precheck = summary["resumePrecheck"]
    after = summary["afterResume"]
    replay = summary["noReplay"]
    unknown = summary["unknownResultControl"]
    files = "\n".join(f"- `{key}`: `{value}`" for key, value in summary["files"].items())
    return "\n".join(
        [
            f"# Checkpoint 恢复记录 `{summary['runId']}`",
            "",
            f"- 生成时间：{summary['generatedAt']}",
            "",
            "## 1. 正常中断（第一个进程）",
            "",
            f"- 中断方式：{interruption['mechanism']}，退出码 `{interruption['returncode']}`",
            f"- 中断点存档：seq=`{interruption['checkpointSeq']}`, "
            f"reason=`{interruption['checkpointReason']}`",
            f"- 存档包含：{', '.join(interruption['checkpointContains'])}"
            "（run / plan / steps / evidence / budget / approvals / pendingApproval / workspace）",
            "",
            "## 2. 恢复前现场核对（第二个进程）",
            "",
            f"- `{precheck['event']}` 记录数：{precheck['count']}，详情："
            f"{json.dumps(precheck['detail'], ensure_ascii=False)}",
            f"- 未闭合写操作数：{precheck['openWriteOperations']}；"
            f"阻断事件数：{precheck['blockedEvents']}；"
            f"存档 schemaVersion：{precheck['checkpointSchemaVersion']}",
            "",
            "## 3. 恢复后继续执行",
            "",
            md_table(
                ["项目", "值"],
                [
                    ["进程退出码", after["processReturncode"]],
                    ["status / stopReason", f"{after['status']} / {after['stopReason']}"],
                    ["toolCalls（不清零）", after["toolCalls"]],
                    ["modelCursor（不清零）", after["modelCursor"]],
                    ["checkpoints", after["checkpoints"]],
                    ["revision", after["revision"]],
                    ["最终 checkpoint seq", after["finalCheckpointSeq"]],
                ],
            ),
            "",
            "## 4. 已完成写入不重复",
            "",
            f"- `r2`（apply_patch）handler 调用次数：{replay['applyPatchHandlerInvocations']}",
            f"- 跨进程 handler 调用序列：{', '.join(replay['allHandlerCalls'])}",
            f"- 源码修复只出现一次：{replay['sourceContainsFixOnce']}；"
            f"交付物 sha256：`{replay['artifactSha256']}`",
            "",
            "## 5. 对照：结果不明时绝不自动重放",
            "",
            md_table(
                ["项目", "值"],
                [
                    ["runId", unknown["runId"]],
                    ["崩溃点", unknown["crashPoint"]],
                    ["blocked", unknown["blocked"]],
                    ["stopReason", unknown["stopReason"]],
                    ["unknownResults", ", ".join(unknown["unknownResults"])],
                    ["文件仍在磁盘", unknown["artifactStillOnDisk"]],
                    ["恢复后 handler 重放次数", unknown["handlerReplaysAfterResume"]],
                ],
            ),
            "",
            f"> {unknown['conclusion']}",
            "",
            "## 可复查文件",
            "",
            files,
            "",
        ]
    )


# ---------------------------------------------------------------------- CLI 入口

def child_main(params_path: Path) -> int:
    params = json.loads(params_path.read_text(encoding="utf-8"))
    workspace = Path(params["workspace"])
    sink = Path(params["sink"])

    def boundary(state: Any) -> None:
        if params["phase"] == "first" and state.budget.tool_calls >= 2:
            os._exit(9)

    harness = Harness(
        model=ScriptedModel(resume_actions()),
        task=build_task(workspace),
        run_id=params["runId"],
        config=HarnessConfig(
            auto_approve=True,
            extra_env=EXTRA_ENV,
            after_checkpoint=boundary,
        ),
    )
    wrap_handlers(harness, sink)
    result = (
        harness.run()
        if params["phase"] == "first"
        else harness.run(resume=True)
    )
    Path(params["result"]).write_text(
        json.dumps(
            {
                "status": str(result.status),
                "stopReason": str(result.stop_reason),
                "toolCalls": result.state.budget.tool_calls,
                "modelCursor": result.state.model_cursor,
                "checkpoints": result.state.budget.checkpoints,
                "revision": result.state.revision,
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return 0


def generate_all(out: Path) -> dict[str, Any]:
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    complete = build_complete_run(out)
    audit = build_audit_record(complete["harness"], out, COMPLETE_RUN_ID)
    resume = build_resume_record(out)
    index = {
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "command": f"python3 run_demo.py --out {display_path(out)}",
        "completeRun": {
            "runId": COMPLETE_RUN_ID,
            "status": complete["summary"]["status"],
            "stopReason": complete["summary"]["stopReason"],
            "files": [
                display_path(out / "complete_run.json"),
                display_path(out / "complete_run.md"),
            ],
        },
        "audit": audit,
        "resume": {
            "runId": RESUME_RUN_ID,
            "status": resume["afterResume"]["status"],
            "stopReason": resume["afterResume"]["stopReason"],
            "files": [
                display_path(out / "resume.json"),
                display_path(out / "resume.md"),
            ],
        },
    }
    (out / "records.json").write_text(
        json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return index


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="生成 week03 的三类运行记录")
    parser.add_argument(
        "--out", default=str(ROOT / "records"), help="输出目录（默认 ./records）"
    )
    parser.add_argument("--child", help="内部使用：跨进程恢复参数文件")
    args = parser.parse_args(argv)
    if args.child:
        return child_main(Path(args.child))
    out = Path(args.out).resolve()
    index = generate_all(out)
    print("已生成三类记录：")
    print(f"  1. 完整运行记录  {out / 'complete_run.json'}")
    print(f"                    {out / 'complete_run.md'}")
    print(f"  2. 审计记录      {out / 'audit.jsonl'}")
    print(f"                    {out / 'audit.json'}")
    print(f"                    {out / 'audit.md'}")
    print(f"  3. 恢复记录      {out / 'resume.json'}")
    print(f"                    {out / 'resume.md'}")
    print(f"  索引            {out / 'records.json'}")
    print(
        f"  完整运行：{index['completeRun']['status']} / "
        f"{index['completeRun']['stopReason']}；"
        f"审计 {index['audit']['recordCount']} 条，"
        f"哈希链 {'有效' if index['audit']['chainValid'] else '无效'}；"
        f"恢复：{index['resume']['status']} / {index['resume']['stopReason']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
