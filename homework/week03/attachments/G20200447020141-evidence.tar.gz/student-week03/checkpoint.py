"""Checkpoint：只在安全步骤边界保存状态，恢复前先核对现场。

存档是带 ``schemaVersion`` + ``checksum`` 的 JSON 信封，先写临时文件再
``os.replace`` 原子替换；读取时校验版本、必填字段、序号和校验和，损坏的
存档绝不"尽量修复"。恢复的三态判定：completed（有闭合记录）、
not_started（无启动记录）、unknown（有启动记录但没有闭合记录）——最后
一种必须标记为 ``UNKNOWN_RESULT`` 并停止自动推进。工作区摘要变化时，
旧证据与旧审批失效，同样停止等待人工核对。"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from audit import AuditDecision, AuditLog, AuditPhase
from sandbox import Sandbox
from state_store import (
    RunState,
    RunStatus,
    StateStore,
    StopReason,
    canonical_json,
)

CHECKPOINT_SCHEMA_VERSION = 1
_TERMINAL_STATUSES = {RunStatus.COMPLETED, RunStatus.STOPPED}


class CheckpointError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class ResumeRejected(CheckpointError):
    def __init__(self, code: str, message: str, inspection: "ResumeInspection") -> None:
        super().__init__(code, message)
        self.inspection = inspection


@dataclass(frozen=True, slots=True)
class CheckpointEnvelope:
    schema_version: int
    run_id: str
    seq: int
    created_at: str
    reason: str
    payload: dict[str, Any]
    checksum: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": self.schema_version,
            "runId": self.run_id,
            "seq": self.seq,
            "createdAt": self.created_at,
            "reason": self.reason,
            "payload": self.payload,
            "checksum": self.checksum,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CheckpointEnvelope:
        return cls(
            schema_version=int(data["schemaVersion"]),
            run_id=str(data["runId"]),
            seq=int(data["seq"]),
            created_at=str(data["createdAt"]),
            reason=str(data["reason"]),
            payload=dict(data["payload"]),
            checksum=str(data["checksum"]),
        )


@dataclass(slots=True)
class ResumeInspection:
    run_id: str
    can_resume: bool = False
    code: StopReason | None = None
    notes: list[str] = field(default_factory=list)
    unresolved: list[dict[str, Any]] = field(default_factory=list)
    state: RunState | None = None
    envelope: CheckpointEnvelope | None = None

    @property
    def stop_reason(self) -> StopReason:
        return self.code or StopReason.NONE


def payload_checksum(payload: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


class CheckpointManager:
    def __init__(
        self,
        *,
        state_store: StateStore,
        audit: AuditLog,
        sandbox: Sandbox,
        run_id: str,
    ) -> None:
        self.state_store = state_store
        self.audit = audit
        self.sandbox = sandbox
        self.run_id = run_id

    def path(self, run_id: str | None = None) -> Path:
        target = run_id or self.run_id
        return self.state_store.run_dir(target) / "checkpoint.json"

    def save(self, state: RunState, reason: str) -> CheckpointEnvelope:
        """在安全步骤边界调用：状态先原子落盘，再原子替换存档。"""
        state.budget.checkpoints += 1
        self.state_store.save(state)
        payload = {
            "state": state.to_dict(),
            "run": {
                "runId": state.run_id,
                "status": str(state.status),
                "stopReason": str(state.stop_reason),
                "revision": state.revision,
            },
            "plan": state.plan.to_dict(),
            "steps": [item.to_dict() for item in state.plan.steps],
            "evidence": [item.to_dict() for item in state.evidence],
            "budget": state.budget.to_dict(),
            "approvals": [item.to_dict() for item in state.approvals],
            "pendingApproval": (
                state.pending_approval.to_dict() if state.pending_approval else None
            ),
            "workspace": state.workspace.to_dict(),
        }
        envelope = CheckpointEnvelope(
            schema_version=CHECKPOINT_SCHEMA_VERSION,
            run_id=state.run_id,
            seq=state.budget.checkpoints,
            created_at=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            reason=reason,
            payload=payload,
            checksum=payload_checksum(payload),
        )
        target = self.path(state.run_id)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(envelope.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temporary, target)
        self.audit.append(
            run_id=state.run_id,
            phase=AuditPhase.CHECKPOINT,
            event="CHECKPOINT_SAVED",
            rule="SAFE_STEP_BOUNDARY",
            decision=AuditDecision.INFO,
            actor="harness",
            detail={
                "seq": envelope.seq,
                "reason": reason,
                "status": str(state.status),
                "stopReason": str(state.stop_reason),
                "pendingApproval": bool(state.pending_approval),
            },
        )
        return envelope

    def load(self, run_id: str | None = None) -> CheckpointEnvelope:
        target = self.path(run_id)
        rid = run_id or self.run_id
        try:
            raw = target.read_text(encoding="utf-8")
        except OSError as exc:
            raise CheckpointError(
                "CHECKPOINT_NOT_FOUND", f"找不到存档：{target} ({exc})"
            ) from exc
        try:
            data = json.loads(raw)
        except ValueError as exc:
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档不是合法 JSON") from exc
        if not isinstance(data, dict):
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档结构不是对象")
        try:
            envelope = CheckpointEnvelope.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档缺少必填字段") from exc
        if envelope.schema_version != CHECKPOINT_SCHEMA_VERSION:
            raise CheckpointError(
                "CHECKPOINT_SCHEMA_MISMATCH",
                f"存档版本不兼容：{envelope.schema_version}",
            )
        state_data = envelope.payload.get("state")
        workspace = envelope.payload.get("workspace")
        if not isinstance(state_data, dict) or not isinstance(workspace, dict):
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档缺少 state/workspace")
        if envelope.run_id != rid or envelope.run_id != state_data.get("runId"):
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档 runId 不一致")
        if envelope.seq != state_data.get("budget", {}).get("checkpoints"):
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档序号与预算计数不一致")
        if payload_checksum(envelope.payload) != envelope.checksum:
            raise CheckpointError("CHECKPOINT_CORRUPT", "存档校验和不匹配")
        return envelope

    def inspect_resume(self, run_id: str | None = None) -> ResumeInspection:
        rid = run_id or self.run_id
        inspection = ResumeInspection(run_id=rid)
        try:
            envelope = self.load(rid)
        except CheckpointError as exc:
            inspection.code = (
                StopReason.CHECKPOINT_NOT_FOUND
                if exc.code == "CHECKPOINT_NOT_FOUND"
                else StopReason.CHECKPOINT_CORRUPT
            )
            inspection.notes.append(exc.message)
            self._record_blocked(inspection)
            return inspection
        inspection.envelope = envelope
        state = RunState.from_dict(envelope.payload["state"])
        inspection.state = state

        # ① 未闭合的写操作优先：结果不明，绝不自动重放。
        open_operations = self.audit.open_write_operations(rid)
        if open_operations:
            state = self._newest_state(rid, state)
            inspection.state = state
            inspection.code = StopReason.UNKNOWN_RESULT
            for record in open_operations:
                tool_call_id = record.tool_call_id
                if tool_call_id not in state.unknown_results:
                    state.unknown_results.append(tool_call_id)
                known = next(
                    (
                        item
                        for item in state.tool_calls
                        if item.tool_call_id == tool_call_id
                    ),
                    None,
                )
                if known is not None:
                    known.unknown_result = True
                inspection.unresolved.append(
                    {
                        "toolCallId": tool_call_id,
                        "toolName": record.tool,
                        "state": "unknown",
                        "reason": "工具已启动但无完成记录，结果不明",
                    }
                )
                inspection.notes.append(
                    f"检测到未闭合写操作 {tool_call_id}（{record.tool}），标记 UNKNOWN_RESULT"
                )

        # ② 工作区必须仍然存在且内容未变。
        if not Path(state.workspace.project_root).is_dir() or not Path(
            state.workspace.repo_root
        ).is_dir():
            if inspection.code is None:
                inspection.code = StopReason.WORKSPACE_MISSING
            inspection.notes.append("工作区目录不存在，停止恢复")
        else:
            entries = [
                (item[0], item[1]) for item in state.workspace.digest_entries
            ]
            live_digest = self.sandbox.compute_digest(entries)
            if live_digest != state.workspace.digest:
                if inspection.code is None:
                    inspection.code = StopReason.WORKSPACE_CHANGED
                inspection.notes.append(
                    "工作区源码/交付物与存档摘要不一致，旧证据和旧审批失效"
                )
                self._mark_stale(state)

        # ③ 内容摘要绑定：即使工作区摘要恰好相同，也要逐条核对测试证据。
        for evidence in state.evidence:
            if evidence.stale or evidence.content_digest is None:
                continue
            files = evidence.payload.get("files") or evidence.payload.get(
                "digestFiles"
            )
            if not files:
                continue
            current = self.sandbox.content_digest(files)
            if current != evidence.content_digest:
                evidence.stale = True
                if inspection.code is None:
                    inspection.code = StopReason.WORKSPACE_CHANGED
                inspection.notes.append(
                    f"证据 {evidence.evidence_id} 的受测内容已变化，旧证据失效"
                )

        # ④ 未消费审批绑定的是批准时刻的工作区摘要。
        for approval in state.approvals:
            if approval.used or approval.stale:
                continue
            if approval.workspace_digest != state.workspace.digest:
                approval.stale = True
                inspection.code = inspection.code or StopReason.STALE_APPROVAL
                inspection.notes.append(
                    f"审批 {approval.approval_id} 已失效，需重新确认"
                )

        # ⑤ 终态运行不再续跑。
        if state.status in _TERMINAL_STATUSES and inspection.code is None:
            inspection.code = StopReason.RUN_TERMINAL
            inspection.notes.append(f"运行已处于终态：{state.status}")

        if inspection.code is None:
            inspection.can_resume = True
            state.status = RunStatus.RUNNING
            state.stop_reason = StopReason.NONE
            state.stop_detail = ""
        else:
            state.stop(inspection.code, "; ".join(inspection.notes))
            self._record_blocked(inspection)
        return inspection

    def resume(self, run_id: str | None = None) -> RunState:
        rid = run_id or self.run_id
        inspection = self.inspect_resume(rid)
        if not inspection.can_resume or inspection.state is None:
            raise ResumeRejected(
                str(inspection.stop_reason),
                "恢复条件不满足，已停止自动推进：" + "; ".join(inspection.notes),
                inspection,
            )
        self.audit.append(
            run_id=rid,
            phase=AuditPhase.RESUME,
            event="RESUME_ACCEPTED",
            rule="RESUME_PRECHECK",
            decision=AuditDecision.ALLOW,
            actor="harness",
            detail={
                "seq": inspection.envelope.seq if inspection.envelope else 0,
                "modelCursor": inspection.state.model_cursor,
                "toolCalls": inspection.state.budget.tool_calls,
            },
        )
        return inspection.state

    def _newest_state(self, run_id: str, fallback: RunState) -> RunState:
        """中断后 state.json 可能比存档新一点，用它补齐已启动的动作。"""
        try:
            newer = self.state_store.load(run_id)
        except OSError:
            return fallback
        return newer if newer.seq > fallback.seq else fallback

    def _mark_stale(self, state: RunState) -> None:
        for evidence in state.evidence:
            if not evidence.stale:
                evidence.stale = True
        for approval in state.approvals:
            if not approval.used:
                approval.stale = True

    def _record_blocked(self, inspection: ResumeInspection) -> None:
        self.audit.append(
            run_id=inspection.run_id,
            phase=AuditPhase.RESUME,
            event="RESUME_BLOCKED",
            rule=str(inspection.stop_reason),
            decision=AuditDecision.DENY,
            actor="harness",
            detail={
                "code": str(inspection.stop_reason),
                "notes": inspection.notes,
                "unresolved": inspection.unresolved,
            },
        )
