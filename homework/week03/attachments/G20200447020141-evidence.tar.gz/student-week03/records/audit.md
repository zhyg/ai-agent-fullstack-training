# 审计记录 `run-complete-001`

- 原始日志：`records/audit.jsonl`（append-only JSONL，65 条）
- 哈希链校验：True
- 阶段：approval, checkpoint, completion, execution, gate, model, sandbox, state
- decision 分布：{"INFO": 45, "DENY": 5, "ALLOW": 15}

## 全量记录

| seq | phase | event | rule | decision | actor | toolCallId | tool |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | model | RUN_STARTED | HARNESS_ASSEMBLY | INFO | harness |  |  |
| 2 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 3 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 4 | gate | GATE_DECISION | INVALID_ARGUMENTS | DENY | gate | c0-invalid | read_file |
| 5 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 6 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 7 | sandbox | SANDBOX_CHECK | PATH_ESCAPE | DENY | sandbox | c0-escape | write_file |
| 8 | gate | GATE_DECISION | SANDBOX_DENIED | DENY | gate | c0-escape | write_file |
| 9 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 10 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 11 | sandbox | SANDBOX_CHECK | COMMAND_NOT_ALLOWED | DENY | sandbox | c0-command | run_test |
| 12 | gate | GATE_DECISION | SANDBOX_DENIED | DENY | gate | c0-command | run_test |
| 13 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 14 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 15 | sandbox | SANDBOX_CHECK | ALLOW | ALLOW | sandbox | c1 | read_file |
| 16 | gate | GATE_DECISION | ALLOW | ALLOW | gate | c1 | read_file |
| 17 | execution | TOOL_STARTED | EXECUTION_BOUNDARY | INFO | harness | c1 | read_file |
| 18 | execution | TOOL_FINISHED | EXECUTION_BOUNDARY | INFO | harness | c1 | read_file |
| 19 | execution | EXECUTION_RESULT | RESULT_RECORDED | INFO | handler | c1 | read_file |
| 20 | state | STATE_UPDATE | TOOL_CALL_CLOSED | INFO | harness | c1 | read_file |
| 21 | state | EVIDENCE_RECORDED | EVIDENCE_BINDING | INFO | harness | c1 | read_file |
| 22 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 23 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 24 | sandbox | SANDBOX_CHECK | ALLOW | ALLOW | sandbox | c2 | run_test |
| 25 | gate | GATE_DECISION | ALLOW | ALLOW | gate | c2 | run_test |
| 26 | execution | TOOL_STARTED | EXECUTION_BOUNDARY | INFO | harness | c2 | run_test |
| 27 | execution | TOOL_FINISHED | EXECUTION_BOUNDARY | INFO | harness | c2 | run_test |
| 28 | execution | EXECUTION_RESULT | RESULT_RECORDED | INFO | handler | c2 | run_test |
| 29 | state | STATE_UPDATE | TOOL_CALL_CLOSED | INFO | harness | c2 | run_test |
| 30 | state | EVIDENCE_RECORDED | EVIDENCE_BINDING | INFO | harness | c2 | run_test |
| 31 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 32 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 33 | sandbox | SANDBOX_CHECK | ALLOW | ALLOW | sandbox | c3 | apply_patch |
| 34 | approval | APPROVAL_GRANTED | AUTO_APPROVAL | ALLOW | auto | c3 | apply_patch |
| 35 | approval | APPROVAL_CONSUMED | ONE_TIME_APPROVAL | ALLOW | gate | c3 | apply_patch |
| 36 | gate | GATE_DECISION | ALLOW | ALLOW | gate | c3 | apply_patch |
| 37 | execution | TOOL_STARTED | EXECUTION_BOUNDARY | INFO | harness | c3 | apply_patch |
| 38 | execution | TOOL_FINISHED | EXECUTION_BOUNDARY | INFO | harness | c3 | apply_patch |
| 39 | execution | EXECUTION_RESULT | RESULT_RECORDED | INFO | handler | c3 | apply_patch |
| 40 | state | STATE_UPDATE | TOOL_CALL_CLOSED | INFO | harness | c3 | apply_patch |
| 41 | state | EVIDENCE_RECORDED | EVIDENCE_BINDING | INFO | harness | c3 | apply_patch |
| 42 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 43 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 44 | sandbox | SANDBOX_CHECK | ALLOW | ALLOW | sandbox | c4 | run_test |
| 45 | gate | GATE_DECISION | ALLOW | ALLOW | gate | c4 | run_test |
| 46 | execution | TOOL_STARTED | EXECUTION_BOUNDARY | INFO | harness | c4 | run_test |
| 47 | execution | TOOL_FINISHED | EXECUTION_BOUNDARY | INFO | harness | c4 | run_test |
| 48 | execution | EXECUTION_RESULT | RESULT_RECORDED | INFO | handler | c4 | run_test |
| 49 | state | STATE_UPDATE | TOOL_CALL_CLOSED | INFO | harness | c4 | run_test |
| 50 | state | EVIDENCE_RECORDED | EVIDENCE_BINDING | INFO | harness | c4 | run_test |
| 51 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 52 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 53 | sandbox | SANDBOX_CHECK | ALLOW | ALLOW | sandbox | c5 | write_file |
| 54 | approval | APPROVAL_GRANTED | AUTO_APPROVAL | ALLOW | auto | c5 | write_file |
| 55 | approval | APPROVAL_CONSUMED | ONE_TIME_APPROVAL | ALLOW | gate | c5 | write_file |
| 56 | gate | GATE_DECISION | ALLOW | ALLOW | gate | c5 | write_file |
| 57 | execution | TOOL_STARTED | EXECUTION_BOUNDARY | INFO | harness | c5 | write_file |
| 58 | execution | TOOL_FINISHED | EXECUTION_BOUNDARY | INFO | harness | c5 | write_file |
| 59 | execution | EXECUTION_RESULT | RESULT_RECORDED | INFO | handler | c5 | write_file |
| 60 | state | STATE_UPDATE | TOOL_CALL_CLOSED | INFO | harness | c5 | write_file |
| 61 | state | EVIDENCE_RECORDED | EVIDENCE_BINDING | INFO | harness | c5 | write_file |
| 62 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |
| 63 | model | MODEL_DECISION | DECIDE_NEXT_ACTION | INFO | model |  |  |
| 64 | completion | FINAL_ACCEPTED | COMPLETION_CONTRACT | ALLOW | harness |  |  |
| 65 | checkpoint | CHECKPOINT_SAVED | SAFE_STEP_BOUNDARY | INFO | harness |  |  |

## 拒绝 / 待审批记录（A1：含 rule、decision、actor、toolCallId）

| seq | toolCallId | rule | decision | actor | event |
| --- | --- | --- | --- | --- | --- |
| 4 | c0-invalid | INVALID_ARGUMENTS | DENY | gate | GATE_DECISION |
| 7 | c0-escape | PATH_ESCAPE | DENY | sandbox | SANDBOX_CHECK |
| 8 | c0-escape | SANDBOX_DENIED | DENY | gate | GATE_DECISION |
| 11 | c0-command | COMMAND_NOT_ALLOWED | DENY | sandbox | SANDBOX_CHECK |
| 12 | c0-command | SANDBOX_DENIED | DENY | gate | GATE_DECISION |

## 决策链还原示例 `c3`（A2）

| seq | phase | event | rule | decision | actor |
| --- | --- | --- | --- | --- | --- |
| 33 | sandbox | SANDBOX_CHECK | ALLOW | ALLOW | sandbox |
| 34 | approval | APPROVAL_GRANTED | AUTO_APPROVAL | ALLOW | auto |
| 35 | approval | APPROVAL_CONSUMED | ONE_TIME_APPROVAL | ALLOW | gate |
| 36 | gate | GATE_DECISION | ALLOW | ALLOW | gate |
| 37 | execution | TOOL_STARTED | EXECUTION_BOUNDARY | INFO | harness |
| 38 | execution | TOOL_FINISHED | EXECUTION_BOUNDARY | INFO | harness |
| 39 | execution | EXECUTION_RESULT | RESULT_RECORDED | INFO | handler |
| 40 | state | STATE_UPDATE | TOOL_CALL_CLOSED | INFO | harness |
| 41 | state | EVIDENCE_RECORDED | EVIDENCE_BINDING | INFO | harness |

> 另有 21 条 run 级记录（RUN_STARTED / MODEL_DECISION / CHECKPOINT_SAVED / FINAL_ACCEPTED），由 `AuditLog.trace(run_id, tool_call_id)` 一并返回，用于关联同一 Run 的上下文。
