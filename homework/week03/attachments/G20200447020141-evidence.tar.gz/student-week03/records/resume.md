# Checkpoint 恢复记录 `run-resume-001`

- 生成时间：2026-11-09T07:06:04+00:00

## 1. 正常中断（第一个进程）

- 中断方式：安全步骤边界（checkpoint.save 之后）os._exit(9)，退出码 `9`
- 中断点存档：seq=`3`, reason=`after_tool_call:r2`
- 存档包含：approvals, budget, evidence, pendingApproval, plan, run, state, steps, workspace（run / plan / steps / evidence / budget / approvals / pendingApproval / workspace）

## 2. 恢复前现场核对（第二个进程）

- `RESUME_ACCEPTED` 记录数：1，详情：{"modelCursor": 2, "seq": 3, "toolCalls": 2}
- 未闭合写操作数：0；阻断事件数：0；存档 schemaVersion：1

## 3. 恢复后继续执行

| 项目 | 值 |
| --- | --- |
| 进程退出码 | 0 |
| status / stopReason | COMPLETED / COMPLETED |
| toolCalls（不清零） | 5 |
| modelCursor（不清零） | 6 |
| checkpoints | 7 |
| revision | r1 |
| 最终 checkpoint seq | 7 |

## 4. 已完成写入不重复

- `r2`（apply_patch）handler 调用次数：1
- 跨进程 handler 调用序列：r1, r2, r3, r4, r5
- 源码修复只出现一次：True；交付物 sha256：`4a7ab90e26921b49f0482b9e3f0265efba829df60009ab519858fd0b96d74a05`

## 5. 对照：结果不明时绝不自动重放

| 项目 | 值 |
| --- | --- |
| runId | run-unknown-001 |
| 崩溃点 | handler 写盘之后、TOOL_FINISHED / checkpoint 之前 |
| blocked | True |
| stopReason | UNKNOWN_RESULT |
| unknownResults | u1 |
| 文件仍在磁盘 | True |
| 恢复后 handler 重放次数 | 0 |

> 结果不明的写操作被标记 UNKNOWN_RESULT，恢复时停止且不自动重放

## 可复查文件

- `checkpoint`: `records/workspace/resume/.agent-runs/run-resume-001/checkpoint.json`
- `state`: `records/workspace/resume/.agent-runs/run-resume-001/state.json`
- `audit`: `records/workspace/resume/.agent-runs/run-resume-001/audit.jsonl`
- `handlerCalls`: `records/workspace/resume/handler_calls.jsonl`
- `workspace`: `records/workspace/resume`
