"""A1–A2：拒绝记录字段与完整任务的决策链。"""

from __future__ import annotations

import json

from audit import AuditLog, AuditDecision, AuditPhase
from gate import ToolCall
from harness import FinalAnswerAction, ScriptedModel, ToolCallAction
from tests.conftest import audit_path, fake_registry, raw_jsonl


def test_a1_denied_call_has_rule_decision_actor_and_original_tool_call_id(make_gate):
    counter: dict[str, int] = {}
    harness, gate = make_gate(handlers=fake_registry(("read_file",), counter))
    result = gate.invoke(ToolCall("a1-denied", "read_file", {"path": 123}))
    assert result.ok is False
    records = [
        item
        for item in raw_jsonl(audit_path(harness))
        if item["decision"] == AuditDecision.DENY
    ]
    assert len(records) == 1
    record = records[0]
    assert {"rule", "decision", "actor", "toolCallId"} <= set(record)
    assert record["toolCallId"] == "a1-denied"
    assert record["rule"] == "INVALID_ARGUMENTS"
    assert record["actor"] == "gate"
    assert record["runId"] == harness.run_id
    assert counter == {}


def test_a2_full_task_links_gate_sandbox_state_approval_and_result(make_harness):
    actions = [
        ToolCallAction("a2-read", "read_file", {"path": "app.py"}),
        ToolCallAction("a2-read-2", "read_file", {"path": "module.py"}),
        ToolCallAction(
            "a2-write",
            "write_file",
            {"path": "artifacts/report.md", "content": "说明文档"},
        ),
        FinalAnswerAction("完成"),
    ]
    harness = make_harness(model=ScriptedModel(actions), auto_approve=True)
    result = harness.run()
    assert result.completed is True

    records = raw_jsonl(audit_path(harness))
    assert all(item["runId"] == harness.run_id for item in records)
    assert [item["seq"] for item in records] == list(range(1, len(records) + 1))
    trace = [
        record.to_dict() for record in harness.audit.trace(harness.run_id, "a2-write")
    ]
    events = {item["event"] for item in trace}
    expected = {
        "GATE_DECISION",
        "SANDBOX_CHECK",
        "APPROVAL_GRANTED",
        "APPROVAL_CONSUMED",
        "TOOL_STARTED",
        "TOOL_FINISHED",
        "EXECUTION_RESULT",
        "STATE_UPDATE",
        "EVIDENCE_RECORDED",
        "CHECKPOINT_SAVED",
        "FINAL_ACCEPTED",
    }
    assert expected <= events
    phases = {item["phase"] for item in trace}
    assert {
        AuditPhase.GATE,
        AuditPhase.SANDBOX,
        AuditPhase.APPROVAL,
        AuditPhase.STATE,
        AuditPhase.EXECUTION,
        AuditPhase.CHECKPOINT,
        AuditPhase.COMPLETION,
    } <= phases
    assert all(
        item["toolCallId"] in {"a2-write", ""} for item in trace
    )
    assert harness.audit.verify_chain() is True


def test_append_only_log_rejects_tampering(tmp_path):
    path = tmp_path / "audit.jsonl"
    log = AuditLog(path)
    log.append(
        run_id="run-1",
        tool_call_id="c1",
        phase=AuditPhase.GATE,
        event="GATE_DECISION",
        rule="ALLOW",
        decision=AuditDecision.ALLOW,
        actor="gate",
        detail={"token": "must-not-be-stored", "message": "hello"},
    )
    log.append(
        run_id="run-1",
        tool_call_id="c1",
        phase=AuditPhase.EXECUTION,
        event="TOOL_FINISHED",
        rule="RESULT_RECORDED",
        decision=AuditDecision.INFO,
        actor="harness",
    )
    lines = path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2
    assert json.loads(lines[0])["detail"]["token"] == "[REDACTED]"
    assert log.verify_chain() is True

    tampered = json.loads(lines[0])
    tampered["rule"] = "TAMPERED"
    lines[0] = json.dumps(tampered, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    assert log.verify_chain() is False
    assert len(log.records(run_id="run-1", tool_call_id="c1")) == 2
