"""H1/H3 与循环装配：Fake Model 驱动、完成拒绝、预算停止、审批续跑。"""

from __future__ import annotations

from harness import FinalAnswerAction, ScriptedModel, ToolCallAction
from state_store import RunStatus, StopReason
from tests.conftest import audit_path, counted_registry, raw_jsonl


def _understanding_actions():
    return [
        ToolCallAction("h1-read-1", "read_file", {"path": "app.py"}),
        ToolCallAction("h1-read-2", "read_file", {"path": "module.py"}),
        ToolCallAction(
            "h1-write",
            "write_file",
            {"path": "artifacts/report.md", "content": "交付说明"},
        ),
        FinalAnswerAction("完成"),
    ]


def test_normal_path_completes_with_fake_model_only(make_harness, workspace):
    harness = make_harness(model=ScriptedModel(_understanding_actions()))
    counter: dict[str, int] = {}
    counted_registry(harness, counter)
    result = harness.run()
    assert result.completed is True
    assert result.stop_reason == StopReason.COMPLETED
    assert result.final_answer == "完成"
    assert result.missing == ()
    assert workspace.artifact.read_text(encoding="utf-8") == "交付说明"
    records = raw_jsonl(audit_path(harness))
    started = [item for item in records if item["event"] == "TOOL_STARTED"]
    assert len(started) == sum(counter.values()), "所有 handler 调用都经过 Gate"
    assert all(item["toolCallId"] for item in started)


def test_h1_final_answer_without_deliverable_is_rejected(make_harness, make_task):
    harness = make_harness(
        model=ScriptedModel([FinalAnswerAction("我已经完成了")]),
        task=make_task(max_turns=3),
    )
    result = harness.run()
    assert result.completed is False
    assert result.status == RunStatus.STOPPED
    assert result.stop_reason == StopReason.MAX_TURNS_EXCEEDED
    assert result.final_answer is None, "模型自述不能成为最终答复"
    assert result.missing
    rejected = [
        item
        for item in raw_jsonl(audit_path(harness))
        if item["event"] == "FINAL_REJECTED"
    ]
    assert len(rejected) >= 1
    assert rejected[0]["decision"] == "DENY"
    assert any("交付物" in item for item in result.missing)


def test_h3_max_turns_and_budget_stop_with_explicit_reason(
    make_harness, make_task
):
    reads = [
        ToolCallAction("h3-turn-1", "read_file", {"path": "app.py"}),
        ToolCallAction("h3-turn-2", "read_file", {"path": "module.py"}),
        ToolCallAction("h3-turn-3", "read_file", {"path": "README.md"}),
    ]
    harness_turns = make_harness(
        model=ScriptedModel(reads), task=make_task(max_turns=2)
    )
    by_turns = harness_turns.run()
    assert by_turns.status == RunStatus.STOPPED
    assert by_turns.stop_reason == StopReason.MAX_TURNS_EXCEEDED
    assert by_turns.state.budget.turns == 2
    assert by_turns.final_answer is None

    harness_budget = make_harness(
        model=ScriptedModel(reads), task=make_task(max_tool_calls=2)
    )
    by_budget = harness_budget.run()
    assert by_budget.status == RunStatus.STOPPED
    assert by_budget.stop_reason == StopReason.BUDGET_EXHAUSTED
    assert by_budget.state.budget.tool_calls == 2
    assert by_budget.final_answer is None

    for result, harness in (
        (by_turns, harness_turns),
        (by_budget, harness_budget),
    ):
        assert isinstance(result.stop_reason, StopReason)
        stops = [
            item
            for item in raw_jsonl(audit_path(harness))
            if item["event"] == "STOP"
        ]
        assert stops and stops[-1]["rule"] == str(result.stop_reason)


def test_waiting_approval_stops_loop_and_resume_replays_once(
    make_harness, workspace
):
    actions = _understanding_actions()
    harness = make_harness(model=ScriptedModel(actions), auto_approve=False)
    sink = workspace.root / "approval_handler_calls.jsonl"
    counted_registry(harness, {}, sink)
    first = harness.run()
    assert first.stop_reason == StopReason.WAITING_APPROVAL
    assert first.state.pending_approval is not None
    assert not workspace.artifact.exists()
    action_id = first.state.pending_approval.action_id

    harness.approve(action_id)
    resumed = make_harness(
        model=ScriptedModel(actions), run_id=harness.run_id, auto_approve=False
    )
    second_counter: dict[str, int] = {}
    counted_registry(resumed, second_counter, sink)
    result = resumed.run(resume=True)

    assert result.completed is True
    assert workspace.artifact.read_text(encoding="utf-8") == "交付说明"
    assert second_counter.get("write_file", 0) == 1, "审批后的写入只执行一次"
    events = [item["event"] for item in raw_jsonl(audit_path(resumed))]
    assert "APPROVAL_GRANTED" in events
    assert "APPROVED_ACTION_REPLAY" in events
    assert "APPROVAL_CONSUMED" in events


def test_repeated_action_stops_loop_with_explicit_reason(make_harness):
    actions = [
        ToolCallAction("repeat-1", "read_file", {"path": "app.py"}),
        ToolCallAction("repeat-2", "read_file", {"path": "app.py"}),
        ToolCallAction("repeat-3", "read_file", {"path": "app.py"}),
        FinalAnswerAction("完成"),
    ]
    harness = make_harness(model=ScriptedModel(actions))
    counter: dict[str, int] = {}
    counted_registry(harness, counter)
    result = harness.run()
    assert counter["read_file"] == 2
    assert result.stop_reason == StopReason.REPEATED_ACTION
    assert result.status == RunStatus.STOPPED
    assert result.final_answer is None
