"""week03 测试夹具：Fake Model、隔离工作区、计数 handler、真实子进程命令。

所有测试都不依赖 smolagents 或网络；跨进程恢复用真实的 python 子进程。"""

from __future__ import annotations

import json
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pytest

WEEK03 = Path(__file__).resolve().parents[1]
if str(WEEK03) not in sys.path:
    sys.path.insert(0, str(WEEK03))

from gate import GateHooks, HandlerRegistry, ToolCall, ToolResult  # noqa: E402
from harness import (  # noqa: E402
    KIND_CODE_UNDERSTANDING,
    KIND_TEST_FIX,
    Harness,
    HarnessConfig,
    ScriptedModel,
    TaskSpec,
)

PASS_COMMAND = (sys.executable, "-c", "print('ok')")
FAIL_COMMAND = (sys.executable, "-c", "import sys; sys.exit(1)")
SLOW_COMMAND = (sys.executable, "-c", "import time; time.sleep(30)")
TRACKED_FILES = ("app.py", "module.py", "README.md", "tests/test_app.py")


@dataclass(frozen=True, slots=True)
class Workspace:
    root: Path
    repo: Path

    @property
    def artifact(self) -> Path:
        return self.root / "artifacts" / "report.md"

    @property
    def source(self) -> Path:
        return self.repo / "app.py"


@pytest.fixture
def workspace(tmp_path: Path) -> Workspace:
    root = tmp_path
    repo = root / "repo"
    (root / "artifacts").mkdir()
    repo.mkdir()
    (repo / "tests").mkdir()
    (repo / "app.py").write_text("def add(a, b):\n    return a - b\n", encoding="utf-8")
    (repo / "module.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "README.md").write_text("# demo repository\n", encoding="utf-8")
    (repo / "tests" / "test_app.py").write_text(
        "def test_add():\n    assert 1 == 1\n", encoding="utf-8"
    )
    (root / ".env").write_text("SECRET=local-only\n", encoding="utf-8")
    return Workspace(root=root, repo=repo)


@pytest.fixture
def make_task(workspace: Workspace):
    def build(kind: str = KIND_CODE_UNDERSTANDING, **overrides: Any) -> TaskSpec:
        is_fix = kind == KIND_TEST_FIX
        params: dict[str, Any] = dict(
            kind=kind,
            title="week03 guarded coding harness",
            repo_root=workspace.repo,
            project_root=workspace.root,
            target_source="app.py" if is_fix else "",
            artifact="artifacts/report.md",
            required_scopes=("target",) if is_fix else (),
            suite_files={"target": ("tests/test_app.py",)} if is_fix else {},
            allowed_commands=(
                {"pass": PASS_COMMAND, "fail": FAIL_COMMAND, "slow": SLOW_COMMAND}
                if is_fix
                else {}
            ),
            test_scopes={"target": "pass"} if is_fix else {},
            tracked_files=TRACKED_FILES,
            min_read_files=1 if is_fix else 2,
            max_turns=12,
            max_tool_calls=20,
            timeout_seconds=1.0,
            kill_grace_seconds=0.3,
            max_output_bytes=4096,
        )
        params.update(overrides)
        return TaskSpec(**params)

    return build


@pytest.fixture
def make_harness(make_task):
    def build(
        *,
        model=None,
        task: TaskSpec | None = None,
        run_id: str | None = None,
        auto_approve: bool = True,
        handlers: HandlerRegistry | None = None,
        hooks: GateHooks | None = None,
        after_checkpoint=None,
        cancel_event=None,
        actor_permissions=None,
        repeat_limit: int = 2,
    ) -> Harness:
        return Harness(
            model=model or ScriptedModel([]),
            task=task or make_task(),
            run_id=run_id or f"run-{uuid.uuid4().hex[:10]}",
            handlers=handlers,
            config=HarnessConfig(
                auto_approve=auto_approve,
                hooks=hooks,
                after_checkpoint=after_checkpoint,
                cancel_event=cancel_event,
                actor_permissions=actor_permissions,
                repeat_limit=repeat_limit,
            ),
        )

    return build


@pytest.fixture
def make_gate(make_harness):
    """返回 (harness, gate)，状态已装配并写好初始存档。"""

    def build(*, handlers=None, auto_approve=False, **kwargs):
        harness = make_harness(
            handlers=handlers, auto_approve=auto_approve, **kwargs
        )
        harness.prepare()
        return harness, harness.gate

    return build


def fake_registry(
    names: tuple[str, ...],
    counter: dict[str, int],
    sink: Path | None = None,
) -> HandlerRegistry:
    """假 handler：只计数，不碰业务状态。"""

    def make(name: str):
        def handler(call: ToolCall, context: Any) -> ToolResult:
            counter[name] = counter.get(name, 0) + 1
            if sink is not None:
                with open(sink, "a", encoding="utf-8") as handle:
                    handle.write(
                        json.dumps({"tool": name, "toolCallId": call.tool_call_id})
                        + "\n"
                    )
            return ToolResult(
                tool_call_id=call.tool_call_id,
                tool_name=name,
                ok=True,
                code="OK",
                output={"handled": True},
            )

        return handler

    return HandlerRegistry({name: make(name) for name in names})


def counted_registry(
    harness: Harness, counter: dict[str, int], sink: Path | None = None
) -> dict[str, int]:
    """把真实 handler 包一层计数，用于断言拒绝路径零调用。"""
    registry = harness.registry
    original = {
        name: registry.get(name)
        for name in ("read_file", "list_files", "search_code", "write_file", "apply_patch", "run_test")
    }

    def make(name: str, handler):
        def wrapped(call: ToolCall, context: Any) -> ToolResult:
            counter[name] = counter.get(name, 0) + 1
            if sink is not None:
                with open(sink, "a", encoding="utf-8") as handle:
                    handle.write(
                        json.dumps({"tool": name, "toolCallId": call.tool_call_id})
                        + "\n"
                    )
            return handler(call, context)

        return wrapped

    for name, handler in original.items():
        if handler is not None:
            registry.register(name, make(name, handler))
    return counter


def raw_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def audit_path(harness: Harness) -> Path:
    return harness.state_store.run_dir(harness.run_id) / "audit.jsonl"


def pid_alive(pid: int) -> bool:
    try:
        Path(f"/proc/{pid}").stat()
    except OSError:
        return False
    try:
        state = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8").split()[2]
        return state != "Z"
    except OSError:
        return False
