"""G1–G4：参数、重复动作、审批与一次性执行。"""

from __future__ import annotations

from gate import ToolCall
from state_store import RunStatus, StopReason
from tests.conftest import audit_path, counted_registry, fake_registry, raw_jsonl


def test_g1_missing_or_wrong_typed_arguments_never_call_handler(make_gate):
    counter: dict[str, int] = {}
    harness, gate = make_gate(
        handlers=fake_registry(("read_file", "write_file"), counter)
    )
    missing = gate.invoke(
        ToolCall("g1-missing", "write_file", {"path": "artifacts/report.md"})
    )
    assert missing.ok is False
    assert missing.code == "INVALID_ARGUMENTS"
    assert missing.tool_call_id == "g1-missing"
    assert "content" in missing.error

    wrong_type = gate.invoke(ToolCall("g1-type", "read_file", {"path": 123}))
    assert wrong_type.ok is False
    assert wrong_type.code == "INVALID_ARGUMENTS"
    assert wrong_type.tool_call_id == "g1-type"

    unknown = gate.invoke(ToolCall("g1-unknown", "unknown_tool", {}))
    assert unknown.code == "TOOL_NOT_FOUND"
    extra = gate.invoke(
        ToolCall("g1-extra", "read_file", {"path": "app.py", "oops": True})
    )
    assert extra.code == "INVALID_ARGUMENTS"
    assert counter == {}, "任何参数/工具错误都不能进入 handler"

    records = raw_jsonl(audit_path(harness))
    denied = [item for item in records if item["decision"] == "DENY"]
    assert denied and all(
        {"rule", "decision", "actor", "toolCallId"} <= set(item) for item in denied
    )
    assert {item["toolCallId"] for item in denied} == {
        "g1-missing",
        "g1-type",
        "g1-unknown",
        "g1-extra",
    }


def test_g2_three_identical_calls_third_blocked_before_handler(make_gate):
    counter: dict[str, int] = {}
    harness, gate = make_gate(handlers=fake_registry(("read_file",), counter))
    outcomes = [
        gate.invoke(ToolCall(f"g2-{index}", "read_file", {"path": "app.py"}))
        for index in range(3)
    ]
    assert [item.ok for item in outcomes[:2]] == [True, True]
    assert outcomes[2].ok is False
    assert outcomes[2].code == "REPEATED_ACTION"
    assert outcomes[2].tool_call_id == "g2-2"
    assert counter["read_file"] == 2
    assert harness.state.stop_reason == StopReason.REPEATED_ACTION
    rules = [item["rule"] for item in raw_jsonl(audit_path(harness))]
    assert "REPEATED_ACTION" in rules


def test_g3_unapproved_write_enters_waiting_approval_without_touching_file(
    make_gate, workspace
):
    counter: dict[str, int] = {}
    harness, gate = make_gate()
    counted_registry(harness, counter)
    result = gate.invoke(
        ToolCall(
            "g3-write",
            "write_file",
            {"path": "artifacts/report.md", "content": "交付说明"},
        )
    )
    assert result.ok is False
    assert result.code == "WAITING_APPROVAL"
    assert result.action_id
    assert result.tool_call_id == "g3-write"
    assert harness.state.status == RunStatus.WAITING_APPROVAL
    assert harness.state.stop_reason == StopReason.WAITING_APPROVAL
    assert harness.state.pending_approval is not None
    assert harness.state.pending_approval.patch_hash
    assert not workspace.artifact.exists(), "未审批的写操作不能改变目标文件"
    assert counter.get("write_file", 0) == 0
    events = [item["event"] for item in raw_jsonl(audit_path(harness))]
    assert "APPROVAL_REQUIRED" in events


def test_g4_approved_call_executes_once_and_replay_is_rejected(make_gate, workspace):
    counter: dict[str, int] = {}
    harness, gate = make_gate()
    counted_registry(harness, counter)
    call = ToolCall(
        "g4-write",
        "write_file",
        {"path": "artifacts/report.md", "content": "只写一次"},
    )
    waiting = gate.invoke(call)
    assert waiting.code == "WAITING_APPROVAL"

    harness.approve(waiting.action_id)
    first = gate.invoke(call)
    assert first.ok is True and first.executed is True
    assert workspace.artifact.read_text(encoding="utf-8") == "只写一次"

    second = gate.invoke(call)
    assert second.ok is False
    assert second.code == "DUPLICATE_TOOL_CALL_ID"
    assert second.tool_call_id == "g4-write"
    assert counter["write_file"] == 1, "handler 只执行一次"
    assert workspace.artifact.read_text(encoding="utf-8") == "只写一次"
    assert harness.state.approvals[-1].used is True
    events = [item["event"] for item in raw_jsonl(audit_path(harness))]
    assert "APPROVAL_GRANTED" in events and "APPROVAL_CONSUMED" in events


def test_permission_and_plan_step_denials_never_call_handler(make_gate):
    counter: dict[str, int] = {}
    harness, gate = make_gate(
        handlers=fake_registry(("write_file",), counter), auto_approve=True
    )
    denied = gate.invoke(
        ToolCall(
            "perm-1",
            "write_file",
            {"path": "artifacts/report.md", "content": "x"},
            actor="readonly",
        )
    )
    assert denied.code == "PERMISSION_DENIED"
    bad_step = gate.invoke(
        ToolCall(
            "plan-1",
            "write_file",
            {"path": "artifacts/report.md", "content": "x"},
            plan_step_id="not-in-plan",
        )
    )
    assert bad_step.code == "PLAN_STEP_NOT_READY"
    assert counter == {}
