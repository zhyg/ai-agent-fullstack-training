"""S1–S4：路径真实落点、敏感目录、命令白名单、进程组超时/取消、输出边界。"""

from __future__ import annotations

import sys
import threading
import time
import uuid
from pathlib import Path

from gate import ToolCall
from harness import KIND_TEST_FIX
from tests.conftest import (
    PASS_COMMAND,
    audit_path,
    fake_registry,
    pid_alive,
    raw_jsonl,
)

SLOW_WITH_GRANDCHILD = (
    "import os, subprocess, sys, time\n"
    "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'])\n"
    "open(sys.argv[1], 'w').write(f'{os.getpid()} {child.pid}\\n')\n"
    "time.sleep(30)\n"
)


def _wait_for_pids(path: Path, timeout: float = 5.0) -> list[int]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if path.exists() and path.read_text(encoding="utf-8").strip():
            return [int(item) for item in path.read_text().split()]
        time.sleep(0.02)
    raise AssertionError("子进程未写出 pid 文件")


def _wait_until_gone(pids: list[int], timeout: float = 5.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not any(pid_alive(pid) for pid in pids):
            return
        time.sleep(0.02)
    raise AssertionError(f"进程组仍存活：{pids}")


def test_s1_path_escape_is_denied_before_handler(make_gate, make_task, workspace):
    counter: dict[str, int] = {}
    harness, gate = make_gate(handlers=fake_registry(("write_file",), counter))
    result = gate.invoke(
        ToolCall(
            "s1-escape",
            "write_file",
            {"path": "artifacts/../../.env", "content": "pwned"},
        )
    )
    assert result.ok is False
    assert result.code == "SANDBOX_DENIED"
    assert result.tool_call_id == "s1-escape"
    assert counter == {}
    assert (workspace.root / ".env").read_text(encoding="utf-8") == "SECRET=local-only\n"
    sandbox_records = [
        item
        for item in raw_jsonl(audit_path(harness))
        if item["event"] == "SANDBOX_CHECK"
    ]
    assert sandbox_records[-1]["decision"] == "DENY"
    assert sandbox_records[-1]["rule"] == "PATH_ESCAPE"


def test_s2_symlink_escape_and_sensitive_paths(make_gate, workspace):
    counter: dict[str, int] = {}
    harness, gate = make_gate(
        handlers=fake_registry(("read_file", "write_file"), counter)
    )
    outside = workspace.root.parent / f"outside-{uuid.uuid4().hex[:8]}"
    outside.mkdir()
    (workspace.root / "artifacts" / "escape").symlink_to(
        outside, target_is_directory=True
    )

    symlink = gate.invoke(
        ToolCall(
            "s2-link",
            "write_file",
            {"path": "artifacts/escape/evil.txt", "content": "x"},
        )
    )
    assert symlink.ok is False
    assert symlink.code == "SANDBOX_DENIED"
    assert not (outside / "evil.txt").exists()

    sensitive = gate.invoke(ToolCall("s2-env", "read_file", {"path": ".env"}))
    git_dir = gate.invoke(
        ToolCall("s2-git", "read_file", {"path": ".git/config"})
    )
    up_one = gate.invoke(
        ToolCall(
            "s2-up",
            "write_file",
            {"path": "artifacts/../.env", "content": "x"},
        )
    )
    for item in (sensitive, git_dir, up_one):
        assert item.ok is False and item.code == "SANDBOX_DENIED"
    assert counter == {}
    rules = [
        item["rule"]
        for item in raw_jsonl(audit_path(harness))
        if item["event"] == "SANDBOX_CHECK" and item["decision"] == "DENY"
    ]
    assert {"SYMLINK_ESCAPE", "SENSITIVE_PATH"} <= set(rules), "拒绝必须留审计痕迹"


def test_s3_command_allowlist_blocks_unconfigured_commands(
    make_gate, make_task, workspace
):
    counter: dict[str, int] = {}
    task = make_task(KIND_TEST_FIX)
    harness, gate = make_gate(
        task=task,
        handlers=fake_registry(("run_test",), counter),
        auto_approve=True,
    )
    dangerous = gate.invoke(ToolCall("s3-danger", "run_test", {"command": "rm -rf /"}))
    assert dangerous.ok is False and dangerous.code == "SANDBOX_DENIED"

    marker = workspace.root / "marker.txt"
    unlisted = gate.invoke(
        ToolCall(
            "s3-unlisted",
            "run_test",
            {"command": [sys.executable, "-c", f"open({str(marker)!r}, 'w').write('x')"]},
        )
    )
    assert unlisted.ok is False
    assert not marker.exists(), "配置外命令不得真正执行"

    unknown_scope = gate.invoke(
        ToolCall("s3-scope", "run_test", {"scope": "not-configured"})
    )
    assert unknown_scope.ok is False

    configured = gate.invoke(
        ToolCall("s3-configured", "run_test", {"command": list(PASS_COMMAND)})
    )
    by_scope = gate.invoke(ToolCall("s3-by-scope", "run_test", {"scope": "target"}))
    assert configured.ok is True and by_scope.ok is True
    assert counter["run_test"] == 2
    events = [
        item
        for item in raw_jsonl(audit_path(harness))
        if item["event"] == "SANDBOX_CHECK" and item["decision"] == "DENY"
    ]
    assert len(events) == 3


def test_s4_timeout_really_terminates_the_process_group(make_harness, make_task):
    task = make_task(KIND_TEST_FIX, timeout_seconds=0.4, kill_grace_seconds=0.2)
    harness = make_harness(task=task)
    pid_file = Path(harness.task.project_root) / "pids.txt"
    result = harness.sandbox.run_command(
        (sys.executable, "-c", SLOW_WITH_GRANDCHILD, str(pid_file)), timeout=0.4
    )
    assert result.code == "TIMEOUT"
    assert result.exit_code is None
    assert result.terminated is True
    assert result.group_exited is True
    pids = _wait_for_pids(pid_file)
    _wait_until_gone(pids)


def test_s4_user_cancel_really_terminates_the_process_group(make_harness, make_task):
    task = make_task(KIND_TEST_FIX, timeout_seconds=20.0, kill_grace_seconds=0.2)
    harness = make_harness(task=task)
    sandbox = harness.sandbox
    pid_file = Path(harness.task.project_root) / "cancel-pids.txt"
    cancel = threading.Event()
    outcomes: list = []
    thread = threading.Thread(
        target=lambda: outcomes.append(
            sandbox.run_command(
                (sys.executable, "-c", SLOW_WITH_GRANDCHILD, str(pid_file)),
                timeout=20.0,
                cancel_event=cancel,
            )
        ),
        daemon=True,
    )
    thread.start()
    pids = _wait_for_pids(pid_file)
    cancel.set()
    thread.join(timeout=15.0)
    assert not thread.is_alive(), "取消后不能只停止等待"
    assert outcomes and outcomes[0].code == "CANCELLED"
    assert outcomes[0].cancelled is True
    assert outcomes[0].terminated is True
    assert outcomes[0].group_exited is True
    _wait_until_gone(pids)


def test_env_allowlist_and_output_limit(make_harness, make_task, monkeypatch):
    monkeypatch.setenv("API_TOKEN", "top-secret")
    monkeypatch.setenv("MY_SECRET_VALUE", "hidden")
    task = make_task(KIND_TEST_FIX, max_output_bytes=64)
    harness = make_harness(task=task)
    sandbox = harness.sandbox
    env = sandbox.filtered_env()
    assert "API_TOKEN" not in env and "MY_SECRET_VALUE" not in env

    probe = sandbox.run_command(
        (
            sys.executable,
            "-c",
            "import os; print([k for k in os.environ if 'TOKEN' in k or 'SECRET' in k])",
        ),
        timeout=2.0,
    )
    assert probe.code == "OK" and probe.output.strip() == "[]"

    noisy = sandbox.run_command(
        (sys.executable, "-c", "print('x' * 1000)"), timeout=2.0
    )
    assert noisy.code == "OK"
    assert "[OUTPUT_TRUNCATED" in noisy.output
    assert len(noisy.output.encode()) < 200
