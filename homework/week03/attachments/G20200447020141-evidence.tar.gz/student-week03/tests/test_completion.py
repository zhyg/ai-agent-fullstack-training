"""H1/H2 与完成契约：交付物、当前版本测试证据、最新一条证据优先。"""

from __future__ import annotations

from harness import (
    KIND_TEST_FIX,
    FinalAnswerAction,
    ScriptedModel,
    ToolCallAction,
)
from state_store import Evidence, EvidenceKind, RunStatus, StepStatus
from tests.conftest import audit_path, raw_jsonl


def test_h1_final_answer_without_artifact_file_is_rejected(make_harness, make_task):
    harness = make_harness(
        model=ScriptedModel(
            [
                ToolCallAction("h1b-read-1", "read_file", {"path": "app.py"}),
                ToolCallAction("h1b-read-2", "read_file", {"path": "module.py"}),
                FinalAnswerAction("说明已经写完"),
            ]
        ),
        task=make_task(max_turns=3),
    )
    result = harness.run()
    assert result.status == RunStatus.STOPPED
    assert result.completed is False
    assert any("交付物" in item for item in result.missing)
    assert any(
        item["event"] == "FINAL_REJECTED"
        for item in raw_jsonl(audit_path(harness))
    )


def test_h2_source_change_after_passing_test_invalidates_evidence(
    make_harness, make_task, workspace
):
    task = make_task(KIND_TEST_FIX, max_turns=8)
    actions = [
        ToolCallAction("h2-read", "read_file", {"path": "app.py"}),
        ToolCallAction(
            "h2-patch-1",
            "apply_patch",
            {"path": "app.py", "search": "return a - b", "replace": "return a + b"},
        ),
        ToolCallAction("h2-test", "run_test", {"scope": "target"}),
        ToolCallAction(
            "h2-patch-2",
            "apply_patch",
            {
                "path": "app.py",
                "search": "return a + b",
                "replace": "return a + b  # v2",
            },
        ),
        FinalAnswerAction("测试已通过，任务完成"),
    ]
    harness = make_harness(model=ScriptedModel(actions), task=task)
    result = harness.run()

    assert result.completed is False
    test_evidence = [
        item for item in result.state.evidence if item.kind == EvidenceKind.TEST
    ]
    assert test_evidence and test_evidence[0].stale is True, "旧测试证据必须失效"
    assert result.state.plan.step("verify").status != StepStatus.COMPLETED
    assert any(
        "测试证据已过期" in item or "缺少通过的测试范围" in item
        for item in result.state.missing
    ), "必须重跑当前版本测试"
    rejected = [
        item
        for item in raw_jsonl(audit_path(harness))
        if item["event"] == "FINAL_REJECTED"
    ]
    assert rejected
    assert any("测试" in item for item in rejected[-1]["detail"]["missing"])


def _fix_actions():
    return [
        ToolCallAction("fix-read", "read_file", {"path": "app.py"}),
        ToolCallAction(
            "fix-patch",
            "apply_patch",
            {"path": "app.py", "search": "return a - b", "replace": "return a + b"},
        ),
        ToolCallAction("fix-test", "run_test", {"scope": "target"}),
        ToolCallAction(
            "fix-write",
            "write_file",
            {"path": "artifacts/report.md", "content": "修复说明"},
        ),
        FinalAnswerAction("修复完成"),
    ]


def test_test_fix_completes_with_current_version_test_and_artifact(
    make_harness, make_task, workspace
):
    harness = make_harness(
        model=ScriptedModel(_fix_actions()), task=make_task(KIND_TEST_FIX)
    )
    result = harness.run()
    assert result.completed is True
    assert result.state.revision == "r1"
    assert result.state.plan.step("verify").status == StepStatus.COMPLETED
    test_evidence = [
        item for item in result.state.evidence if item.kind == EvidenceKind.TEST
    ][-1]
    assert test_evidence.stale is False
    assert test_evidence.content_digest == harness.sandbox.content_digest(
        harness.task.scope_files("target")
    )
    assert (workspace.root / "artifacts" / "report.md").is_file()


def test_failed_test_is_not_a_pass_even_when_tool_succeeds(
    make_harness, make_task
):
    task = make_task(KIND_TEST_FIX, test_scopes={"target": "fail"}, max_turns=6)
    harness = make_harness(model=ScriptedModel(_fix_actions()), task=task)
    result = harness.run()
    assert result.completed is False
    assert result.state.plan.step("verify").status != StepStatus.COMPLETED
    assert any("最新验证未通过" in item for item in result.state.missing)
    records = raw_jsonl(audit_path(harness))
    assert any(item["event"] == "FINAL_REJECTED" for item in records)


def _complete_plan(state):
    for step in state.plan.steps:
        step.status = StepStatus.COMPLETED


def _add_evidence(state, *, kind, payload, revision, content_digest=None):
    return state.add_evidence(
        Evidence(
            evidence_id="",
            kind=kind,
            summary="synthetic evidence",
            payload=payload,
            tool_call_id="synthetic",
            step_id=None,
            revision=revision,
            content_digest=content_digest,
        )
    )


def _valid_fix_state(harness, make_task):
    task = make_task(KIND_TEST_FIX)
    state = harness.prepare()
    _complete_plan(state)
    harness.sandbox.write_text(
        harness.sandbox.project_root / task.artifact, "修复说明",
    )
    files = list(task.scope_files("target"))
    digest = harness.sandbox.content_digest(files)
    _add_evidence(
        state,
        kind=EvidenceKind.DIFF,
        payload={"path": task.target_source, "alreadyApplied": False},
        revision=state.revision,
    )
    _add_evidence(
        state,
        kind=EvidenceKind.TEST,
        payload={"scope": "target", "exitCode": 0, "files": files},
        revision=state.revision,
        content_digest=digest,
    )
    _add_evidence(
        state,
        kind=EvidenceKind.ARTIFACT,
        payload={"artifact": task.artifact},
        revision=state.revision,
    )
    return state


def test_contract_accepts_a_fully_evidenced_fix(make_harness, make_task):
    harness = make_harness(task=make_task(KIND_TEST_FIX))
    state = _valid_fix_state(harness, make_task)
    assert harness.contract.verify(state) == []


def test_latest_failed_test_evidence_wins(make_harness, make_task):
    harness = make_harness(task=make_task(KIND_TEST_FIX))
    state = _valid_fix_state(harness, make_task)
    files = list(harness.task.scope_files("target"))
    _add_evidence(
        state,
        kind=EvidenceKind.TEST,
        payload={"scope": "target", "exitCode": 1, "files": files},
        revision=state.revision,
        content_digest=harness.sandbox.content_digest(files),
    )
    missing = harness.contract.verify(state)
    assert any("最新验证未通过" in item for item in missing)
    assert not any("缺少通过的测试范围" in item for item in missing)


def test_contract_rejects_missing_artifact_file(make_harness, make_task):
    harness = make_harness(task=make_task(KIND_TEST_FIX))
    state = _valid_fix_state(harness, make_task)
    (harness.sandbox.project_root / harness.task.artifact).unlink()
    missing = harness.contract.verify(state)
    assert any("交付物文件不存在" in item for item in missing)


def test_contract_rejects_stale_test_evidence(make_harness, make_task, workspace):
    harness = make_harness(task=make_task(KIND_TEST_FIX))
    state = _valid_fix_state(harness, make_task)
    workspace.source.write_text(
        workspace.source.read_text(encoding="utf-8") + "# changed after test\n",
        encoding="utf-8",
    )
    missing = harness.contract.verify(state)
    assert any("测试证据已过期" in item for item in missing)
    test_evidence = [
        item for item in state.evidence if item.kind == EvidenceKind.TEST
    ]
    assert test_evidence[0].stale is True
