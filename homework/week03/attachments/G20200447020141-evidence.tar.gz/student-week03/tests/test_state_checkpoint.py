"""C1–C4：安全边界存档、结果不明、跨进程恢复、工作区变化失效。"""

from __future__ import annotations

import json
import subprocess
import sys
import textwrap

import pytest

from gate import Gate, GateHooks, ToolCall
from harness import (
    KIND_TEST_FIX,
    FinalAnswerAction,
    ScriptedModel,
    ToolCallAction,
)
from state_store import RunStatus, StopReason
from tests.conftest import (
    WEEK03,
    audit_path,
    counted_registry,
    raw_jsonl,
)

CHILD_SCRIPT = textwrap.dedent(
    '''
    import json, os, sys
    from pathlib import Path

    sys.path.insert(0, sys.argv[2])
    from harness import (
        FinalAnswerAction, Harness, HarnessConfig, ScriptedModel,
        TaskSpec, ToolCallAction,
    )

    params = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    task = TaskSpec(
        kind="code_understanding",
        title="cross-process resume",
        repo_root=Path(params["repo"]),
        project_root=Path(params["root"]),
        tracked_files=("app.py", "module.py", "README.md", "tests/test_app.py"),
        min_read_files=2,
        max_turns=8,
        max_tool_calls=8,
    )
    actions = [
        ToolCallAction("c3-read-1", "read_file", {"path": "app.py"}),
        ToolCallAction("c3-write", "write_file",
                       {"path": "artifacts/report.md", "content": "报告\\n"}),
        ToolCallAction("c3-read-2", "read_file", {"path": "module.py"}),
        FinalAnswerAction("完成"),
    ]

    def boundary(state):
        if params["phase"] == "first" and state.budget.tool_calls >= 2:
            os._exit(9)

    harness = Harness(
        model=ScriptedModel(actions), task=task, run_id=params["run_id"],
        config=HarnessConfig(auto_approve=True, after_checkpoint=boundary),
    )
    sink = Path(params["sink"])
    for name in ("read_file", "write_file", "apply_patch", "run_test",
                 "list_files", "search_code"):
        original = harness.registry.get(name)
        if original is None:
            continue
        def make(tool_name, handler):
            def wrapped(call, context):
                with open(sink, "a", encoding="utf-8") as handle:
                    handle.write(json.dumps(
                        {"tool": tool_name, "toolCallId": call.tool_call_id}) + "\\n")
                return handler(call, context)
            return wrapped
        harness.registry.register(name, make(name, original))

    result = harness.resume() if params["phase"] == "second" else harness.run()
    Path(params["out"]).write_text(json.dumps({
        "status": str(result.status),
        "stopReason": str(result.stop_reason),
        "toolCalls": result.state.budget.tool_calls,
        "modelCursor": result.state.model_cursor,
        "checkpoints": result.state.budget.checkpoints,
    }), encoding="utf-8")
    '''
)


def _understanding_actions():
    return [
        ToolCallAction("c1-read-1", "read_file", {"path": "app.py"}),
        ToolCallAction("c1-read-2", "read_file", {"path": "module.py"}),
        ToolCallAction(
            "c1-write",
            "write_file",
            {"path": "artifacts/report.md", "content": "代码理解说明"},
        ),
        FinalAnswerAction("完成"),
    ]


def test_c1_checkpoint_after_every_safe_step_contains_full_state(
    make_harness, workspace
):
    harness = make_harness(model=ScriptedModel(_understanding_actions()))
    result = harness.run()
    assert result.completed is True
    assert result.stop_reason == StopReason.COMPLETED

    envelope = harness.checkpoint.load()
    payload = envelope.payload
    assert envelope.schema_version >= 1
    assert payload["run"]["runId"] == harness.run_id
    assert payload["plan"]["steps"] and payload["steps"]
    assert len(payload["evidence"]) >= 3
    assert payload["budget"]["toolCalls"] == 3
    assert payload["budget"]["checkpoints"] >= 4
    assert payload["pendingApproval"] is None
    assert payload["approvals"]
    assert payload["workspace"]["digestEntries"]

    saved = json.loads(
        harness.state_store.state_path(harness.run_id).read_text(encoding="utf-8")
    )
    assert saved["status"] == "COMPLETED"
    assert saved["stopReason"] == "COMPLETED"
    assert saved["finalAnswer"] == "完成"
    assert saved["toolCalls"] and saved["evidence"]
    assert harness.audit.verify_chain() is True
    checkpoint_events = [
        item
        for item in raw_jsonl(audit_path(harness))
        if item["event"] == "CHECKPOINT_SAVED"
    ]
    assert len(checkpoint_events) >= 4


def test_c1_checkpoint_keeps_pending_approval_action(make_harness):
    harness = make_harness(
        model=ScriptedModel(_understanding_actions()), auto_approve=False
    )
    result = harness.run()
    assert result.stop_reason == StopReason.WAITING_APPROVAL
    payload = harness.checkpoint.load().payload
    pending = payload["pendingApproval"]
    assert pending is not None
    assert pending["actionId"] and pending["toolCallId"] and pending["patchHash"]
    assert payload["run"]["stopReason"] == "WAITING_APPROVAL"
    assert payload["budget"]["turns"] >= 1


class SimulatedCrash(Exception):
    """写入已落盘、结果尚未保存的进程崩溃。"""


def test_c2_write_without_saved_result_is_unknown_not_replayed(
    make_harness, workspace
):
    def crash_after_handler(call, result):
        if call.tool_name == "write_file":
            raise SimulatedCrash("结果未保存")

    harness = make_harness(
        model=ScriptedModel(
            [
                ToolCallAction(
                    "c2-write",
                    "write_file",
                    {"path": "artifacts/report.md", "content": "已写入"},
                ),
                FinalAnswerAction("完成"),
            ]
        ),
        hooks=GateHooks(after_execute=crash_after_handler),
    )
    sink = workspace.root / "handler_calls.jsonl"
    first_counter: dict[str, int] = {}
    counted_registry(harness, first_counter, sink)
    with pytest.raises(SimulatedCrash):
        harness.run()
    assert workspace.artifact.read_text(encoding="utf-8") == "已写入"

    resumed = make_harness(
        model=ScriptedModel([]), run_id=harness.run_id, auto_approve=True
    )
    second_counter: dict[str, int] = {}
    counted_registry(resumed, second_counter, sink)
    result = resumed.resume()
    assert result.blocked is True
    assert result.stop_reason == StopReason.UNKNOWN_RESULT
    assert "c2-write" in result.state.unknown_results
    assert second_counter == {}, "结果不明时不得自动重放写操作"
    assert workspace.artifact.read_text(encoding="utf-8") == "已写入"

    saved = json.loads(
        resumed.state_store.state_path(harness.run_id).read_text(encoding="utf-8")
    )
    assert saved["toolCalls"][0]["finishedSeq"] is None
    assert saved["stopReason"] == "UNKNOWN_RESULT"
    blocked = [
        item
        for item in raw_jsonl(audit_path(resumed))
        if item["event"] == "RESUME_BLOCKED"
    ]
    assert blocked and blocked[-1]["rule"] == "UNKNOWN_RESULT"


def test_c3_resume_in_a_new_process_keeps_progress_and_never_repeats_writes(
    workspace,
):
    run_id = "run-cross-process"
    root = workspace.root
    script = root / "child_run.py"
    script.write_text(CHILD_SCRIPT, encoding="utf-8")
    sink = root / "handler_calls.jsonl"
    params_path = root / "child_params.json"

    def run_phase(phase: str) -> subprocess.CompletedProcess[str]:
        params_path.write_text(
            json.dumps(
                {
                    "repo": str(workspace.repo),
                    "root": str(root),
                    "run_id": run_id,
                    "sink": str(sink),
                    "phase": phase,
                    "out": str(root / f"{phase}_result.json"),
                }
            ),
            encoding="utf-8",
        )
        return subprocess.run(
            [sys.executable, str(script), str(params_path), str(WEEK03)],
            capture_output=True,
            text=True,
            timeout=60,
            cwd=str(root),
        )

    first = run_phase("first")
    assert first.returncode == 9, first.stderr
    second = run_phase("second")
    assert second.returncode == 0, second.stderr + second.stdout

    outcome = json.loads((root / "second_result.json").read_text(encoding="utf-8"))
    assert outcome["status"] == "COMPLETED"
    assert outcome["toolCalls"] == 3, "恢复后计数不能清零"
    assert outcome["modelCursor"] == 4
    assert outcome["checkpoints"] > 2

    calls = raw_jsonl(sink)
    ids = [item["toolCallId"] for item in calls]
    assert ids.count("c3-read-1") == 1
    assert ids.count("c3-write") == 1, "已完成写入不得重复执行"
    assert ids.count("c3-read-2") == 1
    assert workspace.artifact.read_text(encoding="utf-8") == "报告\n"


class BoundaryInterrupt(Exception):
    """在安全步骤边界正常中断。"""


def test_c4_workspace_change_invalidates_evidence_and_approvals(
    make_harness, make_task, workspace
):
    task = make_task(KIND_TEST_FIX)
    actions = [
        ToolCallAction("c4-read", "read_file", {"path": "app.py"}),
        ToolCallAction(
            "c4-patch",
            "apply_patch",
            {"path": "app.py", "search": "return a - b", "replace": "return a + b"},
        ),
        ToolCallAction("c4-test", "run_test", {"scope": "target"}),
        FinalAnswerAction("完成"),
    ]

    def boundary(state):
        if state.budget.tool_calls >= 3:
            raise BoundaryInterrupt()

    harness = make_harness(
        model=ScriptedModel(actions), task=task, after_checkpoint=boundary
    )
    sink = workspace.root / "c4_handler_calls.jsonl"
    counted_registry(harness, {}, sink)
    with pytest.raises(BoundaryInterrupt):
        harness.run()
    assert any(item.kind.value == "test" for item in harness.state.evidence)

    # 制造一个"尚未消费"的旧审批，让恢复时能同时检验审批失效。
    human_gate = Gate(
        state=harness.state,
        state_store=harness.state_store,
        audit=harness.audit,
        sandbox=harness.sandbox,
        handlers=harness.registry,
        auto_approve=False,
    )
    waiting = human_gate.invoke(
        ToolCall(
            "c4-pending",
            "write_file",
            {"path": "artifacts/pending.md", "content": "待审批"},
        )
    )
    assert waiting.code == "WAITING_APPROVAL"
    harness.approve(waiting.action_id)

    original = workspace.source.read_text(encoding="utf-8")
    workspace.source.write_text(original + "# 外部改动\n", encoding="utf-8")

    fresh_model = ScriptedModel(actions)
    resumed = make_harness(
        model=fresh_model, task=task, run_id=harness.run_id, auto_approve=True
    )
    second_counter: dict[str, int] = {}
    counted_registry(resumed, second_counter, sink)
    result = resumed.resume()

    assert result.blocked is True
    assert result.stop_reason == StopReason.WORKSPACE_CHANGED
    assert result.state.status == RunStatus.STOPPED
    assert result.state.evidence and all(item.stale for item in result.state.evidence)
    assert any(
        item.stale and not item.used for item in result.state.approvals
    ), "旧审批必须失效"
    assert fresh_model.decisions == 0, "拒绝恢复时不得启动模型"
    assert second_counter == {}, "拒绝恢复时不得执行任何工具"
    blocked = [
        item
        for item in raw_jsonl(audit_path(resumed))
        if item["event"] == "RESUME_BLOCKED"
    ]
    assert blocked and blocked[-1]["rule"] == "WORKSPACE_CHANGED"


def test_run_demo_generates_all_three_records(tmp_path):
    """项目运行入口必须能离线复现三类记录，且内容可相互印证。"""
    import run_demo

    out = tmp_path / "records"
    index = run_demo.generate_all(out)
    expected = (
        "complete_run.json", "complete_run.md",
        "audit.jsonl", "audit.json", "audit.md",
        "resume.json", "resume.md", "records.json",
    )
    for name in expected:
        assert (out / name).is_file(), f"缺少记录文件：{name}"

    complete = json.loads((out / "complete_run.json").read_text(encoding="utf-8"))
    assert complete["status"] == "COMPLETED"
    assert complete["stopReason"] == "COMPLETED"
    assert [item["exitCode"] for item in complete["deliverables"]["tests"]] == [1, 0]
    assert complete["deliverables"]["diff"]["sourceAfter"] == "def add(a, b):\n    return a + b"

    audit = json.loads((out / "audit.json").read_text(encoding="utf-8"))
    assert audit["chainValid"] is True
    assert audit["recordCount"] == len(raw_jsonl(out / "audit.jsonl"))
    assert audit["deniedRecords"]
    assert all(
        {"rule", "decision", "actor", "toolCallId"} <= set(item)
        for item in audit["deniedRecords"]
    )
    assert {"gate", "sandbox", "approval", "state", "execution", "checkpoint"} <= set(
        audit["phases"]
    )

    resume = json.loads((out / "resume.json").read_text(encoding="utf-8"))
    assert resume["interruption"]["returncode"] == 9
    assert resume["resumePrecheck"]["openWriteOperations"] == 0
    assert resume["afterResume"]["status"] == "COMPLETED"
    assert resume["afterResume"]["toolCalls"] == 5
    assert resume["noReplay"]["applyPatchHandlerInvocations"] == 1
    assert resume["unknownResultControl"]["stopReason"] == "UNKNOWN_RESULT"
    assert resume["unknownResultControl"]["handlerReplaysAfterResume"] == 0
    assert index["completeRun"]["status"] == "COMPLETED"
