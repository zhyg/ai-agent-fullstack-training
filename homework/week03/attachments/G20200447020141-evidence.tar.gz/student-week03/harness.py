"""Harness：装配模型、工具、Gate、Sandbox、State、Checkpoint、Audit 与完成检查。

模型只负责"下一步做什么"；循环、门禁、证据、状态、存档、恢复和最终验收全
在程序侧。Agent 的运行入口只有一个：``Harness.run(resume=...)``；
``approve`` 是人工控制面，不是模型可调用的动作。

默认不依赖任何第三方库：``ScriptedModel`` 是确定性 Fake Model，
``SmolagentsModel`` 是可选的 T2 后端（惰性导入，不改写 smolagents 核心）。"""

from __future__ import annotations

import hashlib
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from audit import AuditDecision, AuditLog, AuditPhase
from checkpoint import CheckpointManager, ResumeInspection
from gate import (
    EvidenceDraft,
    Gate,
    GateHooks,
    HandlerContext,
    HandlerRegistry,
    ToolCall,
    ToolResult,
    default_specs,
)
from sandbox import Sandbox, SandboxConfig
from state_store import (
    Budget,
    Evidence,
    EvidenceKind,
    Plan,
    PlanStep,
    RunState,
    RunStatus,
    StateStore,
    StepStatus,
    StopReason,
    WorkspaceReference,
)

KIND_CODE_UNDERSTANDING = "code_understanding"
KIND_TEST_FIX = "test_fix"


@dataclass(frozen=True, slots=True)
class TaskSpec:
    kind: str
    title: str
    repo_root: Path
    project_root: Path
    target_source: str = ""
    artifact: str = "artifacts/report.md"
    required_scopes: tuple[str, ...] = ()
    suite_files: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    allowed_commands: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    test_scopes: Mapping[str, str] = field(default_factory=dict)
    tracked_files: tuple[str, ...] = ()
    min_read_files: int = 2
    max_turns: int = 12
    max_tool_calls: int = 20
    timeout_seconds: float = 5.0
    kill_grace_seconds: float = 0.5
    max_output_bytes: int = 8192

    def scope_files(self, scope: str) -> tuple[str, ...]:
        files = list(self.suite_files.get(scope, ()))
        if self.target_source:
            files.append(self.target_source)
        return tuple(sorted(set(files)))

    def effective_tracked_files(self) -> tuple[str, ...]:
        if self.tracked_files:
            return self.tracked_files
        files: list[str] = []
        if self.target_source:
            files.append(self.target_source)
        for group in self.suite_files.values():
            files.extend(group)
        return tuple(sorted(set(files)))

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "title": self.title,
            "repoRoot": str(self.repo_root),
            "projectRoot": str(self.project_root),
            "targetSource": self.target_source,
            "artifact": self.artifact,
            "requiredScopes": list(self.required_scopes),
            "suiteFiles": {k: list(v) for k, v in self.suite_files.items()},
            "allowedCommands": {k: list(v) for k, v in self.allowed_commands.items()},
            "testScopes": dict(self.test_scopes),
            "trackedFiles": list(self.tracked_files),
            "minReadFiles": self.min_read_files,
            "maxTurns": self.max_turns,
            "maxToolCalls": self.max_tool_calls,
        }


@dataclass(slots=True)
class HarnessConfig:
    auto_approve: bool = False
    state_root: Path | None = None
    hooks: GateHooks | None = None
    # 测试注入点：只在安全步骤边界（存档已落盘）触发，用于跨进程中断实验。
    after_checkpoint: Callable[[RunState], None] | None = None
    cancel_event: threading.Event | None = None
    actor_permissions: Mapping[str, frozenset[str]] | None = None
    repeat_limit: int = 2
    extra_env: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ModelView:
    run_id: str
    task: dict[str, Any]
    model_cursor: int
    messages: tuple[dict[str, Any], ...]
    feedback: str | None
    completed_tool_call_ids: tuple[str, ...]
    state: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ToolCallAction:
    tool_call_id: str
    tool_name: str
    args: dict[str, Any] = field(default_factory=dict)
    actor: str = "model"


@dataclass(frozen=True, slots=True)
class FinalAnswerAction:
    content: str


ModelAction = ToolCallAction | FinalAnswerAction


class Model(Protocol):
    def decide(self, view: ModelView) -> ModelAction: ...


class ScriptedModel:
    """确定性 Fake Model：按模型决策游标返回脚本中的下一个动作。

    游标随状态落盘，跨进程恢复后不会重放已完成的动作；脚本用尽后持续
    给出 final answer，用于验证"模型说完成但证据不足"的拒绝路径。
    """

    def __init__(self, actions: Sequence[ModelAction]) -> None:
        self.actions = list(actions)
        self.decisions = 0

    def decide(self, view: ModelView) -> ModelAction:
        self.decisions += 1
        if view.model_cursor < len(self.actions):
            return self.actions[view.model_cursor]
        return FinalAnswerAction("任务已完成（模型自述）")


class SmolagentsModel:
    """可选 T2 后端：借用 ``ToolCallingAgent`` 的模型与系统提示做决策。

    不重写 smolagents 核心：只调用其 ``model(...)`` 得到 tool call / 文本，
    循环与执行边界仍由 Harness 持有。未安装 smolagents 时只有构造会报错。
    """

    def __init__(self, agent: Any | None = None, **agent_kwargs: Any) -> None:
        if agent is None:
            try:
                from smolagents import ToolCallingAgent
            except ImportError as exc:  # pragma: no cover - 取决于环境
                raise RuntimeError(
                    "T2 需要 pip install smolagents 并提供模型凭据；"
                    "离线测试请使用 ScriptedModel"
                ) from exc
            agent = ToolCallingAgent(**agent_kwargs)
        self.agent = agent

    def decide(self, view: ModelView) -> ModelAction:
        system_prompt = getattr(self.agent, "system_prompt", None) or (
            "你是受控编码助手。只通过工具完成任务；最终答复必须由程序验收。"
        )
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": [{"type": "text", "text": system_prompt}]},
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"任务：{view.task.get('title', '')}\n"
                        f"已完成工具调用：{', '.join(view.completed_tool_call_ids) or '无'}",
                    }
                ],
            },
        ]
        for message in view.messages:
            messages.append(
                {
                    "role": message.get("role", "user"),
                    "content": [
                        {"type": "text", "text": str(message.get("content", ""))[:4000]}
                    ],
                }
            )
        if view.feedback:
            messages.append(
                {
                    "role": "user",
                    "content": [{"type": "text", "text": view.feedback}],
                }
            )
        response = self.agent.model(
            messages,
            tools_to_call_from=getattr(self.agent, "tools", None),
        )
        tool_calls = getattr(response, "tool_calls", None) or []
        if tool_calls:
            call = tool_calls[0]
            function = getattr(call, "function", call)
            name = getattr(function, "name", None) or getattr(call, "name", "")
            arguments = getattr(function, "arguments", None) or getattr(
                call, "arguments", {}
            )
            if isinstance(arguments, str):
                import json

                arguments = json.loads(arguments)
            return ToolCallAction(
                tool_call_id=getattr(call, "id", None) or f"smol-{view.model_cursor}",
                tool_name=str(name),
                args=dict(arguments or {}),
            )
        return FinalAnswerAction(str(getattr(response, "content", "") or ""))


@dataclass(frozen=True, slots=True)
class RunResult:
    run_id: str
    state: RunState
    status: RunStatus
    stop_reason: StopReason
    final_answer: str | None
    missing: tuple[str, ...]
    blocked: bool = False

    @property
    def completed(self) -> bool:
        return self.status == RunStatus.COMPLETED and self.stop_reason == StopReason.COMPLETED


class CompletionContract:
    """什么算完成由程序裁决，模型自述不作数。"""

    def __init__(self, task: TaskSpec, sandbox: Sandbox) -> None:
        self.task = task
        self.sandbox = sandbox

    def verify(self, state: RunState) -> list[str]:
        missing: list[str] = [
            f"步骤未完成：{step.step_id}（{step.status}）"
            for step in state.plan.unfinished()
        ]
        for evidence in state.evidence:
            if evidence.kind == EvidenceKind.TEST and self._expired(evidence):
                if not evidence.stale:
                    evidence.stale = True
        artifact_evidence = any(
            item.kind == EvidenceKind.ARTIFACT
            and not item.stale
            and item.revision == state.revision
            and item.payload.get("artifact") == self.task.artifact
            for item in state.evidence
        )
        artifact_path = self.sandbox.project_root / self.task.artifact
        if not artifact_evidence:
            missing.append(f"缺少当前版本的交付物证据：{self.task.artifact}")
        if not artifact_path.is_file():
            missing.append(f"交付物文件不存在：{self.task.artifact}")

        if self.task.kind == KIND_CODE_UNDERSTANDING:
            paths = {
                item.payload.get("path")
                for item in state.evidence
                if item.kind == EvidenceKind.INSPECTION and not item.stale
            }
            if len(paths) < self.task.min_read_files:
                missing.append(
                    f"至少读取 {self.task.min_read_files} 个源码文件，当前 {len(paths)} 个"
                )
        elif self.task.kind == KIND_TEST_FIX:
            changed = any(
                item.kind == EvidenceKind.DIFF
                and not item.stale
                and item.revision == state.revision
                and item.payload.get("path") == self.task.target_source
                and not item.payload.get("alreadyApplied")
                for item in state.evidence
            )
            if not changed:
                missing.append(
                    f"当前版本缺少 {self.task.target_source} 的修改证据"
                )
            for scope in self.task.required_scopes:
                missing.extend(self._verify_scope(state, scope))
        return missing

    def _verify_scope(self, state: RunState, scope: str) -> list[str]:
        candidates = [
            item
            for item in state.evidence
            if item.kind == EvidenceKind.TEST
            and item.payload.get("scope") == scope
            and item.revision == state.revision
        ]
        latest = candidates[-1] if candidates else None
        if latest is None:
            return [f"当前版本缺少通过的测试范围：{scope}"]
        if latest.stale or self._expired(latest):
            latest.stale = True
            return [
                f"测试证据已过期：{scope} 的受测文件在验证后发生变化，必须重跑当前版本测试"
            ]
        if latest.payload.get("exitCode") != 0:
            return [
                f"最新验证未通过：{scope}（exit={latest.payload.get('exitCode')}），"
                "不能用更早的通过记录代替"
            ]
        return []

    def _expired(self, evidence: Evidence) -> bool:
        if evidence.content_digest is None:
            return False
        files = self.task.scope_files(str(evidence.payload.get("scope", "")))
        if not files:
            return False
        return self.sandbox.content_digest(files) != evidence.content_digest


class Harness:
    """唯一运行入口 ``run``；其余模块都是被它装配的能力。"""

    def __init__(
        self,
        *,
        model: Model,
        task: TaskSpec,
        run_id: str | None = None,
        config: HarnessConfig | None = None,
        handlers: HandlerRegistry | None = None,
    ) -> None:
        self.model = model
        self.task = task
        self.config = config or HarnessConfig()
        self.run_id = run_id or f"run-{uuid.uuid4().hex[:10]}"
        root = self.config.state_root or (
            Path(task.project_root) / ".agent-runs"
        )
        self.state_store = StateStore(Path(root))
        self.audit = AuditLog(self.state_store.run_dir(self.run_id) / "audit.jsonl")
        digest_entries = self._digest_entries()
        self.sandbox = Sandbox(
            SandboxConfig(
                repo_root=Path(task.repo_root),
                project_root=Path(task.project_root),
                target_source=task.target_source,
                artifact=task.artifact,
                allowed_write_paths=(task.target_source,) if task.target_source else (),
                allowed_commands=task.allowed_commands,
                test_scopes=task.test_scopes,
                suite_files=task.suite_files,
                digest_entries=digest_entries,
                timeout_seconds=task.timeout_seconds,
                kill_grace_seconds=task.kill_grace_seconds,
                max_output_bytes=task.max_output_bytes,
                extra_env=self.config.extra_env,
            )
        )
        self.checkpoint = CheckpointManager(
            state_store=self.state_store,
            audit=self.audit,
            sandbox=self.sandbox,
            run_id=self.run_id,
        )
        self.contract = CompletionContract(task, self.sandbox)
        self.registry = handlers or build_default_handlers(self.sandbox, task)
        self.state: RunState | None = None
        self.gate = Gate(
            state=RunState(
                run_id=self.run_id,
                task=task.to_dict(),
                plan=Plan(),
                budget=Budget(),
                workspace=WorkspaceReference("", "", "r0", ""),
            ),
            state_store=self.state_store,
            audit=self.audit,
            sandbox=self.sandbox,
            handlers=self.registry,
            auto_approve=self.config.auto_approve,
            actor_permissions=self.config.actor_permissions,
            repeat_limit=self.config.repeat_limit,
            hooks=self.config.hooks,
            cancel_event=self.config.cancel_event,
        )

    # ------------------------------------------------------------------ 运行入口

    def prepare(self) -> RunState:
        """装配一个新 Run 并写入初始存档；Gate 单测也从此入口拿到完整状态。"""
        state = self._new_state()
        self._bind(state)
        self.audit.append(
            run_id=self.run_id,
            phase=AuditPhase.MODEL,
            event="RUN_STARTED",
            rule="HARNESS_ASSEMBLY",
            decision=AuditDecision.INFO,
            actor="harness",
            detail={"kind": self.task.kind, "title": self.task.title},
        )
        self.checkpoint.save(state, "run_started")
        return state

    def run(self, *, resume: bool = False) -> RunResult:
        if resume:
            blocked = self._resume_blocked()
            if blocked is not None:
                return blocked
        else:
            self.prepare()

        state = self._require_state()
        while True:
            if state.status in {
                RunStatus.COMPLETED,
                RunStatus.WAITING_APPROVAL,
                RunStatus.STOPPED,
            }:
                break
            if self.config.cancel_event and self.config.cancel_event.is_set():
                self._stop(StopReason.CANCELLED, "用户取消")
                break
            if state.budget.turns >= state.budget.max_turns:
                self._stop(StopReason.MAX_TURNS_EXCEEDED, "达到最大轮数")
                break

            approved_call = self.gate.take_approved_call()
            if approved_call is not None:
                self.audit.append(
                    run_id=self.run_id,
                    tool_call_id=approved_call.tool_call_id,
                    tool=approved_call.tool_name,
                    phase=AuditPhase.APPROVAL,
                    event="APPROVED_ACTION_REPLAY",
                    rule="ONE_TIME_APPROVAL",
                    decision=AuditDecision.ALLOW,
                    actor="harness",
                    detail={"reason": "人工批准后由程序重放一次"},
                )
                self._execute_tool_call(approved_call)
                self.checkpoint.save(state, "approved_action_executed")
                self._after_checkpoint(state)
                continue

            view = self._model_view(state)
            action = self.model.decide(view)
            state.model_cursor += 1
            state.budget.turns += 1
            self.audit.append(
                run_id=self.run_id,
                phase=AuditPhase.MODEL,
                event="MODEL_DECISION",
                rule="DECIDE_NEXT_ACTION",
                decision=AuditDecision.INFO,
                actor="model",
                detail={
                    "cursor": state.model_cursor,
                    "kind": (
                        "final_answer"
                        if isinstance(action, FinalAnswerAction)
                        else "tool_call"
                    ),
                    "tool": getattr(action, "tool_name", ""),
                    "toolCallId": getattr(action, "tool_call_id", ""),
                },
            )
            if isinstance(action, FinalAnswerAction):
                missing = self.contract.verify(state)
                if missing:
                    self._reject_final(state, action.content, missing)
                    self.checkpoint.save(state, "final_rejected")
                    continue
                state.final_answer = action.content
                state.status = RunStatus.COMPLETED
                state.stop_reason = StopReason.COMPLETED
                state.missing = []
                self.audit.append(
                    run_id=self.run_id,
                    phase=AuditPhase.COMPLETION,
                    event="FINAL_ACCEPTED",
                    rule="COMPLETION_CONTRACT",
                    decision=AuditDecision.ALLOW,
                    actor="harness",
                    detail={"finalAnswer": action.content[:200]},
                )
                self.checkpoint.save(state, "completed")
                break
            if state.budget.tool_calls >= state.budget.max_tool_calls:
                self._stop(StopReason.BUDGET_EXHAUSTED, "达到工具调用预算上限")
                break
            call = ToolCall(
                tool_call_id=action.tool_call_id,
                tool_name=action.tool_name,
                args=dict(action.args),
                actor=action.actor,
            )
            self._execute_tool_call(call)
            self.checkpoint.save(state, f"after_tool_call:{call.tool_call_id}")
            self._after_checkpoint(state)

        if state.stop_reason == StopReason.NONE and state.status == RunStatus.RUNNING:
            self._stop(StopReason.INTERRUPTED, "循环结束但未形成停止原因")
        self.state_store.save(state)
        return RunResult(
            run_id=self.run_id,
            state=state,
            status=state.status,
            stop_reason=state.stop_reason,
            final_answer=state.final_answer,
            missing=tuple(state.missing),
        )

    def resume(self) -> RunResult:
        return self.run(resume=True)

    # ------------------------------------------------------------ 人工控制面

    def approve(self, action_id: str, actor: str = "human") -> Any:
        if self.state is None:
            self._bind(self.state_store.load(self.run_id))
        approval = self.gate.approve(action_id, actor=actor)
        self.checkpoint.save(self._require_state(), "approval_granted")
        return approval

    def inspect_resume(self) -> ResumeInspection:
        return self.checkpoint.inspect_resume()

    # -------------------------------------------------------------- 内部流程

    def _execute_tool_call(self, call: ToolCall) -> ToolResult:
        state = self._require_state()
        result = self.gate.invoke(call)
        state.messages.append(
            {
                "role": "tool",
                "toolCallId": call.tool_call_id,
                "tool": call.tool_name,
                "content": self.sandbox.clip(str(result.model_view())),
            }
        )
        if result.ok and result.evidence is not None:
            self._record_evidence(state, call, result)
        if result.code == "WAITING_APPROVAL":
            return result
        if result.code in {"TIMEOUT", "CANCELLED", "TEST_RESULT_UNKNOWN"}:
            self._stop(
                StopReason.CANCELLED
                if result.code == "CANCELLED"
                else StopReason.TIMEOUT,
                f"{call.tool_name} 未获得完整结果：{result.code}",
            )
        self.state_store.save(state)
        return result

    def _record_evidence(
        self, state: RunState, call: ToolCall, result: ToolResult
    ) -> None:
        draft: EvidenceDraft = result.evidence  # type: ignore[assignment]
        payload = dict(draft.payload)
        step_id = call.plan_step_id or default_specs()[call.tool_name].plan_step
        if draft.kind == EvidenceKind.DIFF and not payload.get("alreadyApplied"):
            state.revision = _next_revision(state.revision)
            state.workspace.revision = state.revision
        payload["revision"] = state.revision
        evidence = Evidence(
            evidence_id="",
            kind=draft.kind,
            summary=draft.summary,
            payload=payload,
            tool_call_id=call.tool_call_id,
            step_id=step_id,
            revision=state.revision,
            content_digest=payload.get("contentDigest"),
        )
        state.add_evidence(evidence)
        step = state.plan.step(step_id) if step_id else None
        if step is not None:
            step.evidence_ids.append(evidence.evidence_id)
        if draft.kind == EvidenceKind.DIFF and not payload.get("alreadyApplied"):
            for older in state.evidence:
                if older.kind == EvidenceKind.TEST and not older.stale:
                    if self.contract._expired(older):
                        older.stale = True
        if draft.kind in {EvidenceKind.DIFF, EvidenceKind.ARTIFACT}:
            # 任何落盘写入后都要刷新工作区摘要，否则正常恢复会被误判为"现场变化"。
            state.workspace.digest = self.sandbox.workspace_digest()
        self._sync_plan(state)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.STATE,
            event="EVIDENCE_RECORDED",
            rule="EVIDENCE_BINDING",
            decision=AuditDecision.INFO,
            actor="harness",
            detail={
                "evidenceId": evidence.evidence_id,
                "kind": str(draft.kind),
                "revision": state.revision,
                "stepId": step_id,
                "staleTestEvidence": sum(
                    1 for item in state.evidence if item.stale
                ),
            },
        )

    def _sync_plan(self, state: RunState) -> None:
        for step in state.plan.steps:
            if step.status == StepStatus.SKIPPED:
                continue
            kinds = set(step.required_evidence)
            matched = [
                item
                for item in state.evidence
                if str(item.kind) in kinds and not item.stale
            ]
            if "inspection" in kinds:
                paths = {item.payload.get("path") for item in matched}
                minimum = (
                    self.task.min_read_files if step.step_id == "inspect" else 1
                )
                done = len(paths) >= minimum
            elif "test" in kinds:
                done = all(
                    self._scope_valid(state, scope)
                    for scope in self.task.required_scopes
                )
            else:
                done = bool(matched)
            step.status = (
                StepStatus.COMPLETED
                if done
                else (StepStatus.IN_PROGRESS if matched else StepStatus.PENDING)
            )

    def _scope_valid(self, state: RunState, scope: str) -> bool:
        candidates = [
            item
            for item in state.evidence
            if item.kind == EvidenceKind.TEST
            and item.payload.get("scope") == scope
            and item.revision == state.revision
            and not item.stale
        ]
        if not candidates:
            return False
        latest = candidates[-1]
        return (
            latest.payload.get("exitCode") == 0
            and not self.contract._expired(latest)
        )

    def _reject_final(self, state: RunState, answer: str, missing: list[str]) -> None:
        state.missing = list(missing)
        real_errors = [
            item for item in state.followups[-3:] if item.startswith("STEP_ERROR")
        ]
        feedback = "\n".join(
            [
                "FINAL_REJECTED：完成证据不足，不能进入完成态。",
                *[f"- {item}" for item in missing],
                *real_errors,
                "请继续使用工具补齐证据和交付物，不要只给出文字说明。",
            ]
        )
        state.followups.append(feedback)
        state.messages.append({"role": "user", "content": feedback})
        self.audit.append(
            run_id=state.run_id,
            phase=AuditPhase.COMPLETION,
            event="FINAL_REJECTED",
            rule="COMPLETION_CONTRACT",
            decision=AuditDecision.DENY,
            actor="harness",
            detail={"missing": missing, "modelAnswer": answer[:200]},
        )

    def _stop(self, reason: StopReason, detail: str) -> None:
        state = self._require_state()
        if state.stop_reason not in {StopReason.NONE, reason}:
            return
        state.stop(reason, detail)
        self.state_store.save(state)
        self.audit.append(
            run_id=self.run_id,
            phase=AuditPhase.COMPLETION,
            event="STOP",
            rule=str(reason),
            decision=AuditDecision.DENY,
            actor="harness",
            detail={"reason": detail, "stopReason": str(reason)},
        )
        if state.status != RunStatus.WAITING_APPROVAL:
            self.checkpoint.save(state, f"stop:{reason}")

    def _resume_blocked(self) -> RunResult | None:
        try:
            state = self.checkpoint.resume()
        except Exception as exc:  # ResumeRejected / CheckpointError
            inspection = getattr(exc, "inspection", None)
            if inspection is None:
                state = (
                    self.state_store.load(self.run_id)
                    if self.state_store.exists(self.run_id)
                    else self._new_state()
                )
                reason = StopReason.CHECKPOINT_CORRUPT
                state.stop(reason, str(exc))
                self.audit.append(
                    run_id=self.run_id,
                    phase=AuditPhase.RESUME,
                    event="RESUME_BLOCKED",
                    rule=str(reason),
                    decision=AuditDecision.DENY,
                    actor="harness",
                    detail={"reason": str(exc)},
                )
            else:
                state = inspection.state or self._new_state()
                reason = inspection.stop_reason
            self._bind(state)
            self.state_store.save(state)
            return RunResult(
                run_id=self.run_id,
                state=state,
                status=state.status,
                stop_reason=reason,
                final_answer=state.final_answer,
                missing=tuple(state.missing),
                blocked=True,
            )
        self._bind(state)
        return None

    def _after_checkpoint(self, state: RunState) -> None:
        hook = self.config.after_checkpoint
        if hook is not None:
            hook(state)

    def _new_state(self) -> RunState:
        entries = self._digest_entries()
        workspace = WorkspaceReference(
            project_root=str(self.sandbox.project_root),
            repo_root=str(self.sandbox.repo_root),
            revision="r0",
            digest=self.sandbox.workspace_digest(),
            digest_entries=[list(item) for item in entries],
        )
        plan = self._new_plan()
        budget = Budget(
            max_turns=self.task.max_turns,
            max_tool_calls=self.task.max_tool_calls,
        )
        return self.state_store.create(
            self.run_id,
            task=self.task.to_dict(),
            plan=plan,
            budget=budget,
            workspace=workspace,
        )

    def _new_plan(self) -> Plan:
        if self.task.kind == KIND_TEST_FIX:
            return Plan(
                steps=[
                    PlanStep("inspect", "阅读源码与测试", (EvidenceKind.INSPECTION.value,)),
                    PlanStep("patch", "修复目标源码", (EvidenceKind.DIFF.value,)),
                    PlanStep("verify", "运行当前版本测试", (EvidenceKind.TEST.value,)),
                    PlanStep("document", "生成交付说明", (EvidenceKind.ARTIFACT.value,)),
                ]
            )
        return Plan(
            steps=[
                PlanStep("inspect", "阅读相关源码", (EvidenceKind.INSPECTION.value,)),
                PlanStep("document", "生成说明文档", (EvidenceKind.ARTIFACT.value,)),
            ]
        )

    def _digest_entries(self) -> tuple[tuple[str, str], ...]:
        entries = [("repo", item) for item in self.task.effective_tracked_files()]
        entries.append(("project", self.task.artifact))
        return tuple(sorted(set(entries)))

    def _model_view(self, state: RunState) -> ModelView:
        return ModelView(
            run_id=self.run_id,
            task=state.task,
            model_cursor=state.model_cursor,
            messages=tuple(state.messages),
            feedback=state.followups[-1] if state.followups else None,
            completed_tool_call_ids=tuple(
                item.tool_call_id for item in state.tool_calls
            ),
            state={
                "status": str(state.status),
                "stopReason": str(state.stop_reason),
                "revision": state.revision,
                "turns": state.budget.turns,
                "evidence": len(state.evidence),
                "missing": list(state.missing),
            },
        )

    def _bind(self, state: RunState) -> None:
        self.state = state
        self.gate.bind(state)

    def _require_state(self) -> RunState:
        if self.state is None:
            raise RuntimeError("Harness 尚未初始化状态")
        return self.state


def _next_revision(revision: str) -> str:
    if revision.startswith("r") and revision[1:].isdigit():
        return f"r{int(revision[1:]) + 1}"
    return "r1"


# ----------------------------------------------------------------- 默认 handler

def build_default_handlers(sandbox: Sandbox, task: TaskSpec) -> HandlerRegistry:
    """内置 handler 只做 IO；校验、状态、证据、审批都在 Gate / Harness。"""

    def ok(
        call: ToolCall,
        output: dict[str, Any],
        *,
        code: str = "OK",
        evidence: EvidenceDraft | None = None,
    ) -> ToolResult:
        return ToolResult(
            tool_call_id=call.tool_call_id,
            tool_name=call.tool_name,
            ok=True,
            code=code,
            output=output,
            evidence=evidence,
        )

    def fail(call: ToolCall, code: str, message: str) -> ToolResult:
        return ToolResult(
            tool_call_id=call.tool_call_id,
            tool_name=call.tool_name,
            ok=False,
            code=code,
            error=message,
            rule=code,
            decision=AuditDecision.ERROR,
        )

    def read_file(call: ToolCall, context: HandlerContext) -> ToolResult:
        path = context.verdict.resolved_path
        assert path is not None
        try:
            content = sandbox.read_text(path)
        except OSError as exc:
            return fail(call, "READ_FAILED", str(exc))
        raw = call.args["path"]
        return ok(
            call,
            {"path": raw, "content": sandbox.clip(content), "bytes": len(content)},
            evidence=EvidenceDraft(
                EvidenceKind.INSPECTION,
                f"读取 {raw}",
                {
                    "path": raw,
                    "bytes": len(content),
                    "digest": hashlib.sha256(content.encode()).hexdigest(),
                },
            ),
        )

    def list_files(call: ToolCall, context: HandlerContext) -> ToolResult:
        path = context.verdict.resolved_path
        assert path is not None
        files = [
            str(item.relative_to(sandbox.repo_root))
            for item in sorted(path.rglob("*"))
            if item.is_file()
            and not any(part in {".git", ".agent-runs"} for part in item.parts)
        ][:200]
        return ok(
            call,
            {"path": call.args.get("path", "."), "files": files},
            evidence=EvidenceDraft(
                EvidenceKind.TOOL, "列出文件", {"count": len(files)}
            ),
        )

    def search_code(call: ToolCall, context: HandlerContext) -> ToolResult:
        path = context.verdict.resolved_path
        assert path is not None
        query = call.args["query"]
        matches: list[dict[str, Any]] = []
        for item in sorted(path.rglob("*")):
            if not item.is_file() or item.suffix not in {".py", ".md", ".txt", ".json"}:
                continue
            for number, line in enumerate(
                sandbox.read_text(item).splitlines(), start=1
            ):
                if query in line:
                    matches.append(
                        {
                            "path": str(item.relative_to(sandbox.repo_root)),
                            "line": number,
                            "preview": line.strip()[:200],
                        }
                    )
        return ok(
            call,
            {"query": query, "matches": matches[:20], "total": len(matches)},
            evidence=EvidenceDraft(
                EvidenceKind.TOOL, f"搜索 {query}", {"total": len(matches)}
            ),
        )

    def write_file(call: ToolCall, context: HandlerContext) -> ToolResult:
        path = context.verdict.resolved_path
        assert path is not None
        raw = call.args["path"]
        content = call.args["content"]
        try:
            sandbox.write_text(path, content)
        except OSError as exc:
            return fail(call, "WRITE_FAILED", str(exc))
        return ok(
            call,
            {"path": raw, "bytes": len(content)},
            evidence=EvidenceDraft(
                EvidenceKind.ARTIFACT,
                f"写入交付物 {raw}",
                {
                    "artifact": raw,
                    "bytes": len(content),
                    "digest": hashlib.sha256(content.encode()).hexdigest(),
                },
            ),
        )

    def apply_patch(call: ToolCall, context: HandlerContext) -> ToolResult:
        path = context.verdict.resolved_path
        assert path is not None
        raw = call.args["path"]
        search = call.args["search"]
        replace = call.args["replace"]
        try:
            content = sandbox.read_text(path)
        except OSError as exc:
            return fail(call, "PATCH_READ_FAILED", str(exc))
        occurrences = content.count(search)
        before = hashlib.sha256(content.encode()).hexdigest()
        if occurrences == 0:
            if replace and replace in content:
                return ok(
                    call,
                    {"path": raw, "alreadyApplied": True},
                    code="PATCH_ALREADY_APPLIED",
                    evidence=EvidenceDraft(
                        EvidenceKind.DIFF,
                        f"{raw} 的修改已生效，本次未重复写入",
                        {
                            "path": raw,
                            "path_digest": before,
                            "alreadyApplied": True,
                        },
                    ),
                )
            return fail(call, "PATCH_ANCHOR_NOT_FOUND", f"未找到替换锚点：{raw}")
        if occurrences > 1:
            return fail(
                call,
                "PATCH_ANCHOR_NOT_UNIQUE",
                f"替换锚点出现 {occurrences} 次：{raw}",
            )
        updated = content.replace(search, replace, 1)
        try:
            sandbox.write_text(path, updated)
        except OSError as exc:
            return fail(call, "PATCH_WRITE_FAILED", str(exc))
        return ok(
            call,
            {"path": raw, "alreadyApplied": False, "bytes": len(updated)},
            evidence=EvidenceDraft(
                EvidenceKind.DIFF,
                f"修改 {raw}",
                {
                    "path": raw,
                    "beforeDigest": before,
                    "afterDigest": hashlib.sha256(updated.encode()).hexdigest(),
                    "alreadyApplied": False,
                },
            ),
        )

    def run_test(call: ToolCall, context: HandlerContext) -> ToolResult:
        command = context.verdict.command
        assert command is not None
        scope = str(call.args.get("scope", "custom"))
        files = tuple(context.verdict.digest_files)
        content_digest = sandbox.content_digest(files)
        result = sandbox.run_command(command, cancel_event=context.cancel_event)
        metadata = result.to_dict()
        if result.code != "OK":
            return ToolResult(
                tool_call_id=call.tool_call_id,
                tool_name=call.tool_name,
                ok=False,
                code=(
                    "TEST_RESULT_UNKNOWN"
                    if result.code in {"TIMEOUT", "CANCELLED"}
                    else result.code
                ),
                error="测试已启动但未获得完整结果，不得记为通过",
                rule="TEST_RESULT_UNKNOWN",
                decision=AuditDecision.UNKNOWN_RESULT,
                metadata=metadata,
            )
        payload = {
            "scope": scope,
            "exitCode": result.exit_code,
            "passed": result.exit_code == 0,
            "files": list(files),
            "contentDigest": content_digest,
            "output": result.output[-1000:],
            "command": list(command),
        }
        return ok(
            call,
            {**payload, "output": result.output},
            evidence=EvidenceDraft(
                EvidenceKind.TEST,
                f"{scope} 测试 exit={result.exit_code}",
                payload,
            ),
        )

    return HandlerRegistry(
        {
            "read_file": read_file,
            "list_files": list_files,
            "search_code": search_code,
            "write_file": write_file,
            "apply_patch": apply_patch,
            "run_test": run_test,
        }
    )
