"""Sandbox：一切文件与子进程访问的真实边界。

Gate 在执行 handler 之前调用 ``validate_tool_call`` 做预检；内置 handler 只
使用预检产出的绝对落点 / 命令 argv，不再自行拼接路径。真实落点用
``os.path.realpath`` 解析（覆盖不存在的尾部与软链接），而不是只做字符串前缀
比较。命令以独立进程组运行，超时/取消时 SIGTERM → 宽限 → SIGKILL，并核实
进程组已退出；输出与环境变量都有上限/白名单。

本模块只依赖标准库，不依赖 smolagents。"""

from __future__ import annotations

import hashlib
import os
import re
import shlex
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

SENSITIVE_NAMES = frozenset(
    {
        ".git",
        ".ssh",
        ".env",
        ".codebuddy",
        ".agent-runs",
        "secrets",
        "credentials",
        "node_modules",
        "__pycache__",
    }
)
SENSITIVE_SUFFIXES = (".pem", ".key", ".p12")
SECRET_ENV_PATTERN = re.compile(
    r"SECRET|TOKEN|PASSWORD|CREDENTIAL|PRIVATE|API_KEY|ACCESS_KEY", re.IGNORECASE
)
DANGEROUS_COMMAND_PATTERN = re.compile(
    r"rm\s+-rf|mkfs|shutdown|curl\s|wget\s|;\s*|&&|\|\||\||`|\$\(|>\s*/|sudo\s",
    re.IGNORECASE,
)
MISSING = "<missing>"


class SandboxViolation(Exception):
    """路径 / 命令越界。"""

    def __init__(self, rule: str, message: str) -> None:
        super().__init__(message)
        self.rule = rule
        self.message = message


@dataclass(frozen=True, slots=True)
class SandboxConfig:
    repo_root: Path
    project_root: Path
    target_source: str = ""
    artifact: str = "artifacts/report.md"
    allowed_write_paths: tuple[str, ...] = ()
    # 命令白名单：命令 id -> argv（绝不使用 shell=True）
    allowed_commands: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    # 测试范围 -> 命令 id
    test_scopes: Mapping[str, str] = field(default_factory=dict)
    # 测试范围 -> 受测文件（相对 repo_root）
    suite_files: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    # 工作区摘要覆盖的文件：(根类型 "repo"|"project", 相对路径)
    digest_entries: tuple[tuple[str, str], ...] = ()
    timeout_seconds: float = 5.0
    kill_grace_seconds: float = 0.5
    max_output_bytes: int = 8192
    max_read_bytes: int = 256 * 1024
    env_allowlist: tuple[str, ...] = ("PATH", "LANG", "LC_ALL", "HOME", "TMPDIR")
    extra_env: Mapping[str, str] = field(default_factory=dict)
    cancel_poll_seconds: float = 0.05


@dataclass(frozen=True, slots=True)
class SandboxVerdict:
    allowed: bool
    rule: str
    detail: dict[str, Any] = field(default_factory=dict)
    resolved_path: Path | None = None
    command: tuple[str, ...] | None = None
    digest_files: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CommandResult:
    ok: bool
    code: str
    pid: int
    pgid: int | None
    exit_code: int | None
    output: str
    timed_out: bool = False
    cancelled: bool = False
    terminated: bool = False
    group_exited: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "code": self.code,
            "pid": self.pid,
            "pgid": self.pgid,
            "exitCode": self.exit_code,
            "output": self.output,
            "timedOut": self.timed_out,
            "cancelled": self.cancelled,
            "terminated": self.terminated,
            "groupExited": self.group_exited,
        }


class Sandbox:
    """文件路径、敏感目录、命令白名单、超时、环境变量和输出边界。"""

    def __init__(self, config: SandboxConfig) -> None:
        self.config = config
        self.repo_root = Path(os.path.realpath(config.repo_root))
        self.project_root = Path(os.path.realpath(config.project_root))
        self.artifact_root = Path(
            os.path.realpath(self.project_root / Path(config.artifact).parts[0])
        )
        self.artifact_root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ 路径

    @staticmethod
    def _check_sensitive(raw: str, real: Path, root: Path) -> None:
        parts = list(Path(raw).parts) + list(Path(os.path.relpath(real, root)).parts)
        for part in parts:
            if part in SENSITIVE_NAMES or part.startswith(".env"):
                raise SandboxViolation(
                    "SENSITIVE_PATH", f"敏感目录/文件禁止访问：{part}"
                )
            if part.endswith(SENSITIVE_SUFFIXES):
                raise SandboxViolation("SENSITIVE_PATH", f"敏感文件禁止访问：{part}")

    def resolve_path(
        self, raw_path: str, *, root: str = "repo", for_write: bool = False
    ) -> Path:
        """把模型给的相对路径解析为经过 realpath 校验的绝对真实落点。"""
        if not isinstance(raw_path, str) or not raw_path or "\x00" in raw_path:
            raise SandboxViolation("INVALID_PATH", "路径必须是非空字符串")
        base = self.repo_root if root == "repo" else self.project_root
        if os.path.isabs(raw_path):
            raise SandboxViolation("PATH_ESCAPE", f"不允许绝对路径：{raw_path}")
        lexical = Path(os.path.normpath(os.path.join(base, raw_path)))
        if os.path.commonpath([str(base), str(lexical)]) != str(base):
            raise SandboxViolation("PATH_ESCAPE", f"路径越界：{raw_path}")
        real = Path(os.path.realpath(lexical))
        if os.path.commonpath([str(base), str(real)]) != str(base):
            raise SandboxViolation("SYMLINK_ESCAPE", f"真实落点越界：{raw_path} -> {real}")
        self._check_sensitive(raw_path, real, base)
        if for_write and root == "artifact":
            if os.path.commonpath([str(self.artifact_root), str(real)]) != str(
                self.artifact_root
            ):
                raise SandboxViolation(
                    "ARTIFACT_PATH_DENIED", f"交付物只能写入 {self.artifact_root.name}/：{raw_path}"
                )
        if for_write and root == "repo":
            rel = os.path.relpath(real, self.repo_root)
            if rel not in self.config.allowed_write_paths:
                raise SandboxViolation(
                    "WRITE_PATH_DENIED", f"该文件不在允许修改范围：{rel}"
                )
        return real

    # ------------------------------------------------------------------ 摘要

    def compute_digest(self, entries: Iterable[tuple[str, str] | str]) -> str:
        """按稳定顺序哈希文件真实内容；缺失文件记占位符。"""
        digest = hashlib.sha256()
        normalized: list[tuple[str, str]] = []
        for entry in entries:
            if isinstance(entry, str):
                normalized.append(("repo", entry))
            else:
                normalized.append((entry[0], entry[1]))
        for root_kind, rel in sorted(set(normalized)):
            base = self.repo_root if root_kind == "repo" else self.project_root
            digest.update(f"{root_kind}:{rel}\n".encode())
            try:
                digest.update((base / rel).read_bytes())
            except OSError:
                digest.update(MISSING.encode())
            digest.update(b"\n")
        return digest.hexdigest()

    def workspace_digest(self) -> str:
        return self.compute_digest(self.config.digest_entries)

    def content_digest(self, files: Iterable[str]) -> str:
        return self.compute_digest([("repo", item) for item in files])

    # -------------------------------------------------------------- 工具预检

    def validate_tool_call(self, tool_name: str, args: Mapping[str, Any]) -> SandboxVerdict:
        try:
            return self._validate(tool_name, args)
        except SandboxViolation as exc:
            return SandboxVerdict(False, exc.rule, {"reason": exc.message})

    def _validate(self, tool_name: str, args: Mapping[str, Any]) -> SandboxVerdict:
        if tool_name in {"read_file", "list_files", "search_code"}:
            raw = str(args.get("path", "."))
            path = self.resolve_path(raw, root="repo")
            return SandboxVerdict(
                True,
                "ALLOW",
                {"requestedPath": raw, "realPath": str(path)},
                resolved_path=path,
            )
        if tool_name == "write_file":
            raw = str(args["path"])
            artifact_prefix = f"{Path(self.config.artifact).parts[0]}/"
            if not raw.startswith(artifact_prefix):
                raise SandboxViolation(
                    "ARTIFACT_PATH_DENIED",
                    f"交付物必须以 {artifact_prefix} 开头：{raw}",
                )
            path = self.resolve_path(raw, root="artifact", for_write=True)
            return SandboxVerdict(
                True,
                "ALLOW",
                {"requestedPath": raw, "realPath": str(path)},
                resolved_path=path,
            )
        if tool_name == "apply_patch":
            raw = str(args["path"])
            path = self.resolve_path(raw, root="repo", for_write=True)
            return SandboxVerdict(
                True,
                "ALLOW",
                {"requestedPath": raw, "realPath": str(path)},
                resolved_path=path,
            )
        if tool_name == "run_test":
            command, scope = self._resolve_command(args)
            files: list[str] = []
            if scope:
                files.extend(self.config.suite_files.get(scope, ()))
            if self.config.target_source:
                files.append(self.config.target_source)
            return SandboxVerdict(
                True,
                "ALLOW",
                {"command": list(command), "scope": scope},
                command=command,
                digest_files=tuple(sorted(set(files))),
            )
        return SandboxVerdict(False, "TOOL_NOT_FOUND", {"reason": tool_name})

    def _resolve_command(
        self, args: Mapping[str, Any]
    ) -> tuple[tuple[str, ...], str | None]:
        scope = args.get("scope")
        requested = args.get("command")
        mapped: tuple[str, ...] | None = None
        if scope is not None:
            command_id = self.config.test_scopes.get(str(scope))
            if command_id is None:
                raise SandboxViolation("TEST_SCOPE_INVALID", f"未知测试范围：{scope}")
            mapped = tuple(self.config.allowed_commands.get(command_id, ()))
            if not mapped:
                raise SandboxViolation(
                    "COMMAND_NOT_ALLOWED", f"范围 {scope} 没有配置命令"
                )
        if requested is not None:
            candidate = self._normalize_command(requested)
            allowed = {tuple(value) for value in self.config.allowed_commands.values()}
            if candidate not in allowed:
                raise SandboxViolation(
                    "COMMAND_NOT_ALLOWED",
                    f"命令不在允许范围：{' '.join(candidate)}",
                )
            if mapped is not None and candidate != mapped:
                raise SandboxViolation(
                    "COMMAND_NOT_ALLOWED", "命令与测试范围配置不一致"
                )
            return candidate, str(scope) if scope is not None else None
        if mapped is None:
            raise SandboxViolation("COMMAND_NOT_ALLOWED", "缺少 scope 或 command")
        return mapped, str(scope)

    @staticmethod
    def _normalize_command(command: Any) -> tuple[str, ...]:
        if isinstance(command, str):
            candidate = tuple(shlex.split(command))
            text = command
        elif isinstance(command, (list, tuple)) and all(
            isinstance(item, str) for item in command
        ):
            candidate = tuple(command)
            text = " ".join(candidate)
        else:
            raise SandboxViolation("COMMAND_NOT_ALLOWED", "命令格式非法")
        if not candidate or DANGEROUS_COMMAND_PATTERN.search(text):
            raise SandboxViolation("COMMAND_NOT_ALLOWED", f"危险命令：{text}")
        return candidate

    # ---------------------------------------------------------------- 文件 IO

    def read_text(self, path: Path) -> str:
        data = path.read_bytes()[: self.config.max_read_bytes]
        return data.decode("utf-8", "replace")

    def write_text(self, path: Path, content: str) -> None:
        """原子替换：崩溃后要么看到旧文件，要么看到完整新文件。"""
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(content, encoding="utf-8")
        os.replace(temporary, path)

    # ------------------------------------------------------------ 子进程执行

    def filtered_env(self) -> dict[str, str]:
        env = {
            key: value
            for key, value in os.environ.items()
            if key in self.config.env_allowlist and not SECRET_ENV_PATTERN.search(key)
        }
        env.update(
            {
                key: value
                for key, value in self.config.extra_env.items()
                if not SECRET_ENV_PATTERN.search(key)
            }
        )
        env["PYTHONUNBUFFERED"] = "1"
        return env

    def run_command(
        self,
        argv: Sequence[str],
        *,
        timeout: float | None = None,
        cancel_event: threading.Event | None = None,
        cwd: Path | None = None,
    ) -> CommandResult:
        limit = self.config.timeout_seconds if timeout is None else timeout
        try:
            proc = subprocess.Popen(
                list(argv),
                cwd=str(cwd or self.repo_root),
                env=self.filtered_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                start_new_session=os.name == "posix",
            )
        except OSError as exc:
            return CommandResult(False, "SPAWN_FAILED", 0, None, None, str(exc))
        pgid: int | None = proc.pid if os.name == "posix" else None
        deadline = time.monotonic() + limit
        timed_out = False
        cancelled = False
        stdout = ""
        stderr = ""
        while True:
            if cancel_event is not None and cancel_event.is_set():
                cancelled = True
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timed_out = True
                break
            try:
                # 重试 communicate 不会丢失此前已读到的输出（CPython 保证）。
                out, err = proc.communicate(
                    timeout=min(self.config.cancel_poll_seconds, remaining)
                )
                stdout += out or ""
                stderr += err or ""
                break
            except subprocess.TimeoutExpired:
                continue

        terminated = False
        group_exited = True
        exit_code: int | None = None
        if timed_out or cancelled:
            terminated = self._terminate_group(proc, pgid)
            group_exited = self._group_gone(pgid, proc)
            try:
                out, err = proc.communicate(timeout=2.0)
                stdout += out or ""
                stderr += err or ""
            except subprocess.TimeoutExpired:
                pass
        else:
            exit_code = proc.returncode

        output = self.clip(stdout + stderr)
        code = "OK"
        if timed_out:
            code = "TIMEOUT"
        elif cancelled:
            code = "CANCELLED"
        return CommandResult(
            ok=code == "OK" and exit_code == 0,
            code=code,
            pid=proc.pid,
            pgid=pgid,
            exit_code=exit_code,
            output=output,
            timed_out=timed_out,
            cancelled=cancelled,
            terminated=terminated,
            group_exited=group_exited,
        )

    def _terminate_group(self, proc: subprocess.Popen[str], pgid: int | None) -> bool:
        def send(sig: int) -> None:
            if pgid is None:
                try:
                    proc.send_signal(sig)
                except OSError:
                    pass
                return
            try:
                os.killpg(pgid, sig)
            except ProcessLookupError:
                return
            except OSError:
                try:
                    proc.send_signal(sig)
                except OSError:
                    pass

        send(signal.SIGTERM)
        try:
            proc.wait(timeout=self.config.kill_grace_seconds)
        except subprocess.TimeoutExpired:
            send(signal.SIGKILL)
            try:
                proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                return False
        return proc.poll() is not None

    def _group_gone(self, pgid: int | None, proc: subprocess.Popen[str]) -> bool:
        if pgid is None:
            return proc.poll() is not None
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            try:
                os.killpg(pgid, 0)
            except ProcessLookupError:
                return True
            except OSError:
                return True
            time.sleep(0.02)
        return False

    def clip(self, text: str) -> str:
        raw = text.encode("utf-8", "replace")
        limit = self.config.max_output_bytes
        if len(raw) <= limit:
            return text
        clipped = raw[:limit].decode("utf-8", "ignore")
        return f"{clipped}\n[OUTPUT_TRUNCATED +{len(raw) - limit} bytes]"
