"""State Store：Run 的全部业务状态与唯一真相。

保存 Run、计划、步骤、证据、预算、审批、工具调用记录、停止原因和模型进度；
提供显式的序列化与原子落盘，完成或中断后都能读到完整状态。状态变更只通过
这里的方法进行，handler 不持有也不修改业务状态。"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any, Mapping


class RunStatus(StrEnum):
    RUNNING = "RUNNING"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    SUSPENDED = "SUSPENDED"
    COMPLETED = "COMPLETED"
    STOPPED = "STOPPED"


class StopReason(StrEnum):
    NONE = "NONE"
    COMPLETED = "COMPLETED"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    REPEATED_ACTION = "REPEATED_ACTION"
    MAX_TURNS_EXCEEDED = "MAX_TURNS_EXCEEDED"
    BUDGET_EXHAUSTED = "BUDGET_EXHAUSTED"
    UNKNOWN_RESULT = "UNKNOWN_RESULT"
    WORKSPACE_CHANGED = "WORKSPACE_CHANGED"
    STALE_APPROVAL = "STALE_APPROVAL"
    CHECKPOINT_CORRUPT = "CHECKPOINT_CORRUPT"
    CHECKPOINT_NOT_FOUND = "CHECKPOINT_NOT_FOUND"
    RUN_TERMINAL = "RUN_TERMINAL"
    WORKSPACE_MISSING = "WORKSPACE_MISSING"
    CANCELLED = "CANCELLED"
    TIMEOUT = "TIMEOUT"
    SANDBOX_DENIED = "SANDBOX_DENIED"
    INVALID_ARGUMENTS = "INVALID_ARGUMENTS"
    INTERRUPTED = "INTERRUPTED"


class StepStatus(StrEnum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"


class EvidenceKind(StrEnum):
    INSPECTION = "inspection"
    DIFF = "diff"
    TEST = "test"
    ARTIFACT = "artifact"
    TOOL = "tool"


class Effect(StrEnum):
    READ = "read"
    WRITE = "write"
    SHELL = "shell"


class Risk(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def args_digest(args: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_json(dict(args)).encode("utf-8")).hexdigest()


def action_fingerprint(tool_name: str, args: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        canonical_json({"tool": tool_name, "args": dict(args)}).encode("utf-8")
    ).hexdigest()


@dataclass(slots=True)
class Budget:
    max_turns: int = 12
    max_tool_calls: int = 20
    turns: int = 0
    tool_calls: int = 0
    writes: int = 0
    rejects: int = 0
    checkpoints: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "maxTurns": self.max_turns,
            "maxToolCalls": self.max_tool_calls,
            "turns": self.turns,
            "toolCalls": self.tool_calls,
            "writes": self.writes,
            "rejects": self.rejects,
            "checkpoints": self.checkpoints,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Budget:
        return cls(
            max_turns=int(data["maxTurns"]),
            max_tool_calls=int(data["maxToolCalls"]),
            turns=int(data["turns"]),
            tool_calls=int(data["toolCalls"]),
            writes=int(data.get("writes", 0)),
            rejects=int(data.get("rejects", 0)),
            checkpoints=int(data.get("checkpoints", 0)),
        )


@dataclass(slots=True)
class PlanStep:
    step_id: str
    title: str
    required_evidence: tuple[str, ...] = ()
    status: StepStatus = StepStatus.PENDING
    attempts: int = 0
    evidence_ids: list[str] = field(default_factory=list)
    last_error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "stepId": self.step_id,
            "title": self.title,
            "requiredEvidence": list(self.required_evidence),
            "status": str(self.status),
            "attempts": self.attempts,
            "evidenceIds": list(self.evidence_ids),
            "lastError": self.last_error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PlanStep:
        return cls(
            step_id=str(data["stepId"]),
            title=str(data["title"]),
            required_evidence=tuple(data.get("requiredEvidence", ())),
            status=StepStatus(data["status"]),
            attempts=int(data.get("attempts", 0)),
            evidence_ids=list(data.get("evidenceIds", [])),
            last_error=data.get("lastError"),
        )


@dataclass(slots=True)
class Plan:
    steps: list[PlanStep] = field(default_factory=list)

    def step(self, step_id: str) -> PlanStep | None:
        return next((item for item in self.steps if item.step_id == step_id), None)

    def unfinished(self) -> list[PlanStep]:
        return [
            item
            for item in self.steps
            if item.status not in {StepStatus.COMPLETED, StepStatus.SKIPPED}
        ]

    def to_dict(self) -> dict[str, Any]:
        return {"steps": [item.to_dict() for item in self.steps]}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Plan:
        return cls(steps=[PlanStep.from_dict(item) for item in data.get("steps", [])])


@dataclass(slots=True)
class Evidence:
    evidence_id: str
    kind: EvidenceKind
    summary: str
    payload: dict[str, Any]
    tool_call_id: str
    step_id: str | None
    revision: str
    content_digest: str | None = None
    stale: bool = False
    seq: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "evidenceId": self.evidence_id,
            "kind": str(self.kind),
            "summary": self.summary,
            "payload": dict(self.payload),
            "toolCallId": self.tool_call_id,
            "stepId": self.step_id,
            "revision": self.revision,
            "contentDigest": self.content_digest,
            "stale": self.stale,
            "seq": self.seq,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Evidence:
        return cls(
            evidence_id=str(data["evidenceId"]),
            kind=EvidenceKind(data["kind"]),
            summary=str(data["summary"]),
            payload=dict(data.get("payload", {})),
            tool_call_id=str(data["toolCallId"]),
            step_id=data.get("stepId"),
            revision=str(data["revision"]),
            content_digest=data.get("contentDigest"),
            stale=bool(data.get("stale", False)),
            seq=int(data.get("seq", 0)),
        )


@dataclass(slots=True)
class ToolCallRecord:
    tool_call_id: str
    tool_name: str
    args_digest: str
    started_seq: int
    finished_seq: int | None = None
    ok: bool | None = None
    code: str | None = None
    unknown_result: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "toolCallId": self.tool_call_id,
            "toolName": self.tool_name,
            "argsDigest": self.args_digest,
            "startedSeq": self.started_seq,
            "finishedSeq": self.finished_seq,
            "ok": self.ok,
            "code": self.code,
            "unknownResult": self.unknown_result,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ToolCallRecord:
        return cls(
            tool_call_id=str(data["toolCallId"]),
            tool_name=str(data["toolName"]),
            args_digest=str(data["argsDigest"]),
            started_seq=int(data["startedSeq"]),
            finished_seq=data.get("finishedSeq"),
            ok=data.get("ok"),
            code=data.get("code"),
            unknown_result=bool(data.get("unknownResult", False)),
        )


@dataclass(slots=True)
class ApprovalRecord:
    approval_id: str
    action_id: str
    tool_call_id: str
    tool_name: str
    fingerprint: str
    args_digest: str
    workspace_digest: str
    plan_step_id: str | None
    actor: str
    used: bool = False
    stale: bool = False
    seq: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "approvalId": self.approval_id,
            "actionId": self.action_id,
            "toolCallId": self.tool_call_id,
            "toolName": self.tool_name,
            "fingerprint": self.fingerprint,
            "argsDigest": self.args_digest,
            "workspaceDigest": self.workspace_digest,
            "planStepId": self.plan_step_id,
            "actor": self.actor,
            "used": self.used,
            "stale": self.stale,
            "seq": self.seq,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ApprovalRecord:
        return cls(
            approval_id=str(data["approvalId"]),
            action_id=str(data["actionId"]),
            tool_call_id=str(data["toolCallId"]),
            tool_name=str(data["toolName"]),
            fingerprint=str(data["fingerprint"]),
            args_digest=str(data["argsDigest"]),
            workspace_digest=str(data["workspaceDigest"]),
            plan_step_id=data.get("planStepId"),
            actor=str(data["actor"]),
            used=bool(data["used"]),
            stale=bool(data.get("stale", False)),
            seq=int(data.get("seq", 0)),
        )


@dataclass(slots=True)
class PendingApproval:
    action_id: str
    tool_call_id: str
    tool_name: str
    fingerprint: str
    args: dict[str, Any]
    args_digest: str
    workspace_digest: str
    plan_step_id: str | None
    patch_hash: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "actionId": self.action_id,
            "toolCallId": self.tool_call_id,
            "toolName": self.tool_name,
            "fingerprint": self.fingerprint,
            "args": dict(self.args),
            "argsDigest": self.args_digest,
            "workspaceDigest": self.workspace_digest,
            "planStepId": self.plan_step_id,
            "patchHash": self.patch_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PendingApproval:
        return cls(
            action_id=str(data["actionId"]),
            tool_call_id=str(data["toolCallId"]),
            tool_name=str(data["toolName"]),
            fingerprint=str(data["fingerprint"]),
            args=dict(data["args"]),
            args_digest=str(data["argsDigest"]),
            workspace_digest=str(data["workspaceDigest"]),
            plan_step_id=data.get("planStepId"),
            patch_hash=str(data["patchHash"]),
        )


@dataclass(slots=True)
class WorkspaceReference:
    project_root: str
    repo_root: str
    revision: str
    digest: str
    digest_entries: list[list[str]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "projectRoot": self.project_root,
            "repoRoot": self.repo_root,
            "revision": self.revision,
            "digest": self.digest,
            "digestEntries": [list(item) for item in self.digest_entries],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkspaceReference:
        return cls(
            project_root=str(data["projectRoot"]),
            repo_root=str(data["repoRoot"]),
            revision=str(data["revision"]),
            digest=str(data["digest"]),
            digest_entries=[
                list(item) for item in data.get("digestEntries", [])
            ],
        )


@dataclass(slots=True)
class RunState:
    run_id: str
    task: dict[str, Any]
    plan: Plan
    budget: Budget
    workspace: WorkspaceReference
    status: RunStatus = RunStatus.RUNNING
    stop_reason: StopReason = StopReason.NONE
    stop_detail: str = ""
    revision: str = "r0"
    evidence: list[Evidence] = field(default_factory=list)
    approvals: list[ApprovalRecord] = field(default_factory=list)
    pending_approval: PendingApproval | None = None
    approved_action: dict[str, Any] | None = None
    tool_calls: list[ToolCallRecord] = field(default_factory=list)
    action_counts: dict[str, int] = field(default_factory=dict)
    followups: list[str] = field(default_factory=list)
    messages: list[dict[str, Any]] = field(default_factory=list)
    model_cursor: int = 0
    final_answer: str | None = None
    missing: list[str] = field(default_factory=list)
    unknown_results: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    seq: int = 0

    def next_seq(self) -> int:
        self.seq += 1
        return self.seq

    def new_id(self, prefix: str) -> str:
        return f"{prefix}-{self.next_seq():05d}"

    def has_tool_call(self, tool_call_id: str) -> bool:
        return any(item.tool_call_id == tool_call_id for item in self.tool_calls)

    def begin_tool_call(self, record: ToolCallRecord) -> None:
        self.tool_calls.append(record)

    def finish_tool_call(
        self, tool_call_id: str, *, ok: bool, code: str
    ) -> ToolCallRecord | None:
        record = next(
            (item for item in self.tool_calls if item.tool_call_id == tool_call_id),
            None,
        )
        if record is None:
            return None
        record.finished_seq = self.next_seq()
        record.ok = ok
        record.code = code
        record.unknown_result = False
        return record

    def add_evidence(self, evidence: Evidence) -> Evidence:
        evidence.evidence_id = evidence.evidence_id or self.new_id("ev")
        evidence.seq = self.next_seq()
        self.evidence.append(evidence)
        return evidence

    def find_usable_approval(
        self, tool_call_id: str, fingerprint: str
    ) -> ApprovalRecord | None:
        return next(
            (
                item
                for item in self.approvals
                if not item.used
                and not item.stale
                and (item.tool_call_id == tool_call_id or item.fingerprint == fingerprint)
            ),
            None,
        )

    def stop(self, reason: StopReason, detail: str = "") -> None:
        self.stop_reason = reason
        self.stop_detail = detail
        if self.status != RunStatus.COMPLETED:
            self.status = RunStatus.STOPPED

    def to_dict(self) -> dict[str, Any]:
        return {
            "runId": self.run_id,
            "task": dict(self.task),
            "status": str(self.status),
            "stopReason": str(self.stop_reason),
            "stopDetail": self.stop_detail,
            "revision": self.revision,
            "plan": self.plan.to_dict(),
            "budget": self.budget.to_dict(),
            "workspace": self.workspace.to_dict(),
            "evidence": [item.to_dict() for item in self.evidence],
            "approvals": [item.to_dict() for item in self.approvals],
            "pendingApproval": (
                self.pending_approval.to_dict() if self.pending_approval else None
            ),
            "approvedAction": dict(self.approved_action) if self.approved_action else None,
            "toolCalls": [item.to_dict() for item in self.tool_calls],
            "actionCounts": dict(self.action_counts),
            "followups": list(self.followups),
            "messages": list(self.messages),
            "modelCursor": self.model_cursor,
            "finalAnswer": self.final_answer,
            "missing": list(self.missing),
            "unknownResults": list(self.unknown_results),
            "notes": list(self.notes),
            "seq": self.seq,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunState:
        return cls(
            run_id=str(data["runId"]),
            task=dict(data["task"]),
            status=RunStatus(data["status"]),
            stop_reason=StopReason(data["stopReason"]),
            stop_detail=str(data.get("stopDetail", "")),
            revision=str(data["revision"]),
            plan=Plan.from_dict(data["plan"]),
            budget=Budget.from_dict(data["budget"]),
            workspace=WorkspaceReference.from_dict(data["workspace"]),
            evidence=[Evidence.from_dict(item) for item in data.get("evidence", [])],
            approvals=[
                ApprovalRecord.from_dict(item) for item in data.get("approvals", [])
            ],
            pending_approval=(
                PendingApproval.from_dict(data["pendingApproval"])
                if data.get("pendingApproval")
                else None
            ),
            approved_action=data.get("approvedAction"),
            tool_calls=[
                ToolCallRecord.from_dict(item) for item in data.get("toolCalls", [])
            ],
            action_counts=dict(data.get("actionCounts", {})),
            followups=list(data.get("followups", [])),
            messages=list(data.get("messages", [])),
            model_cursor=int(data.get("modelCursor", 0)),
            final_answer=data.get("finalAnswer"),
            missing=list(data.get("missing", [])),
            unknown_results=list(data.get("unknownResults", [])),
            notes=list(data.get("notes", [])),
            seq=int(data.get("seq", 0)),
        )


class StateStore:
    """完整业务状态的原子落盘；中断后仍可读到最近一次状态。"""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def run_dir(self, run_id: str) -> Path:
        return self.root / run_id

    def state_path(self, run_id: str) -> Path:
        return self.run_dir(run_id) / "state.json"

    def create(
        self,
        run_id: str,
        *,
        task: dict[str, Any],
        plan: Plan,
        budget: Budget,
        workspace: WorkspaceReference,
    ) -> RunState:
        state = RunState(
            run_id=run_id,
            task=task,
            plan=plan,
            budget=budget,
            workspace=workspace,
            revision=workspace.revision,
        )
        self.save(state)
        return state

    def save(self, state: RunState) -> Path:
        target = self.state_path(state.run_id)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(state.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temporary, target)
        return target

    def load(self, run_id: str) -> RunState:
        return RunState.from_dict(
            json.loads(self.state_path(run_id).read_text(encoding="utf-8"))
        )

    def exists(self, run_id: str) -> bool:
        return self.state_path(run_id).exists()
