"""Gate：所有 Tool Call 的唯一入口。

固定顺序：调用 ID 去重 → 参数校验 → 权限 → 风险/重复动作 → 等待审批状态 →
计划步骤 → Sandbox 预检 → 审批 → 放行登记 → handler → 结果登记。任何一步
拒绝都不会进入 handler，返回的 ToolResult 保留原始 ``tool_call_id`` 并带
结构化错误码。业务状态只经 RunState / StateStore 修改，handler 只做 IO。"""

from __future__ import annotations

import hashlib
import threading
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Callable, Mapping, Protocol

from audit import AuditDecision, AuditLog, AuditPhase
from sandbox import Sandbox, SandboxVerdict
from state_store import (
    Effect,
    EvidenceKind,
    PendingApproval,
    Risk,
    RunState,
    StepStatus,
    RunStatus,
    StateStore,
    StopReason,
    ToolCallRecord,
    action_fingerprint,
    args_digest,
    canonical_json,
    ApprovalRecord,
)


class GateRule(StrEnum):
    ALLOW = "ALLOW"
    INVALID_CALL_ID = "INVALID_CALL_ID"
    TOOL_NOT_FOUND = "TOOL_NOT_FOUND"
    INVALID_ARGUMENTS = "INVALID_ARGUMENTS"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    REPEATED_ACTION = "REPEATED_ACTION"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    PLAN_STEP_REQUIRED = "PLAN_STEP_REQUIRED"
    PLAN_STEP_NOT_READY = "PLAN_STEP_NOT_READY"
    SANDBOX_DENIED = "SANDBOX_DENIED"
    STALE_APPROVAL = "STALE_APPROVAL"
    DUPLICATE_TOOL_CALL_ID = "DUPLICATE_TOOL_CALL_ID"
    APPROVAL_ALREADY_USED = "APPROVAL_ALREADY_USED"
    EXECUTION_ERROR = "EXECUTION_ERROR"


@dataclass(frozen=True, slots=True)
class FieldSpec:
    python_type: type | tuple[type, ...]
    required: bool = True
    allow_empty: bool = False


@dataclass(frozen=True, slots=True)
class ToolSpec:
    name: str
    effect: Effect
    risk: Risk
    permission: str
    requires_approval: bool
    fields: Mapping[str, FieldSpec] = field(default_factory=dict)
    one_of: tuple[str, ...] = ()
    plan_step: str | None = None
    replay: str = "safe"
    evidence_kind: EvidenceKind | None = None


def default_specs() -> dict[str, ToolSpec]:
    string = FieldSpec(str)
    optional_string = FieldSpec(str, required=False)
    return {
        "read_file": ToolSpec(
            name="read_file",
            effect=Effect.READ,
            risk=Risk.LOW,
            permission="read",
            requires_approval=False,
            fields={"path": string},
            evidence_kind=EvidenceKind.INSPECTION,
        ),
        "list_files": ToolSpec(
            name="list_files",
            effect=Effect.READ,
            risk=Risk.LOW,
            permission="read",
            requires_approval=False,
            fields={"path": optional_string},
        ),
        "search_code": ToolSpec(
            name="search_code",
            effect=Effect.READ,
            risk=Risk.LOW,
            permission="read",
            requires_approval=False,
            fields={"query": string, "path": optional_string},
        ),
        "write_file": ToolSpec(
            name="write_file",
            effect=Effect.WRITE,
            risk=Risk.HIGH,
            permission="write",
            requires_approval=True,
            fields={
                "path": string,
                "content": FieldSpec(str, allow_empty=True),
            },
            plan_step="document",
            replay="never",
            evidence_kind=EvidenceKind.ARTIFACT,
        ),
        "apply_patch": ToolSpec(
            name="apply_patch",
            effect=Effect.WRITE,
            risk=Risk.HIGH,
            permission="write",
            requires_approval=True,
            fields={"path": string, "search": string, "replace": string},
            plan_step="patch",
            replay="never",
            evidence_kind=EvidenceKind.DIFF,
        ),
        "run_test": ToolSpec(
            name="run_test",
            effect=Effect.SHELL,
            risk=Risk.MEDIUM,
            permission="shell",
            requires_approval=False,
            fields={
                "scope": optional_string,
                "command": FieldSpec((str, list), required=False),
            },
            one_of=("scope", "command"),
            plan_step="verify",
            replay="never",
            evidence_kind=EvidenceKind.TEST,
        ),
    }


@dataclass(frozen=True, slots=True)
class ToolCall:
    tool_call_id: str
    tool_name: str
    args: dict[str, Any] = field(default_factory=dict)
    actor: str = "model"
    plan_step_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "toolCallId": self.tool_call_id,
            "toolName": self.tool_name,
            "args": dict(self.args),
            "actor": self.actor,
            "planStepId": self.plan_step_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ToolCall:
        return cls(
            tool_call_id=str(data["toolCallId"]),
            tool_name=str(data["toolName"]),
            args=dict(data.get("args", {})),
            actor=str(data.get("actor", "model")),
            plan_step_id=data.get("planStepId"),
        )


@dataclass(frozen=True, slots=True)
class EvidenceDraft:
    kind: EvidenceKind
    summary: str
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ToolResult:
    tool_call_id: str
    tool_name: str
    ok: bool
    code: str
    output: dict[str, Any] = field(default_factory=dict)
    error: str = ""
    rule: str = GateRule.ALLOW
    decision: str = AuditDecision.ALLOW
    action_id: str | None = None
    executed: bool = False
    evidence: EvidenceDraft | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def model_view(self) -> dict[str, Any]:
        if self.ok:
            return {"ok": True, "code": self.code, **self.output}
        return {
            "ok": False,
            "code": self.code,
            "rule": self.rule,
            "error": self.error,
            **({"actionId": self.action_id} if self.action_id else {}),
        }


@dataclass(frozen=True, slots=True)
class HandlerContext:
    sandbox: Sandbox
    verdict: SandboxVerdict
    cancel_event: threading.Event | None = None


class ToolHandler(Protocol):
    def __call__(self, call: ToolCall, context: HandlerContext) -> ToolResult: ...


class HandlerRegistry:
    """handler 注册表；计数只在真正调用 handler 时递增。"""

    def __init__(
        self, handlers: Mapping[str, ToolHandler] | None = None
    ) -> None:
        self._handlers: dict[str, ToolHandler] = dict(handlers or {})
        self.call_counts: dict[str, int] = {}

    def register(self, name: str, handler: ToolHandler) -> None:
        self._handlers[name] = handler

    def get(self, name: str) -> ToolHandler | None:
        return self._handlers.get(name)

    def invoke(self, call: ToolCall, context: HandlerContext) -> ToolResult:
        self.call_counts[call.tool_name] = self.call_counts.get(call.tool_name, 0) + 1
        handler = self._handlers.get(call.tool_name)
        if handler is None:
            return ToolResult(
                tool_call_id=call.tool_call_id,
                tool_name=call.tool_name,
                ok=False,
                code="HANDLER_NOT_FOUND",
                error=f"未注册 handler：{call.tool_name}",
                rule=GateRule.TOOL_NOT_FOUND,
                decision=AuditDecision.ERROR,
            )
        return handler(call, context)


@dataclass(slots=True)
class GateHooks:
    """测试注入点：在结果落盘前模拟进程崩溃 / 用户取消。"""

    before_execute: Callable[[ToolCall], None] | None = None
    after_execute: Callable[[ToolCall, ToolResult], None] | None = None


class ApprovalError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class Gate:
    def __init__(
        self,
        *,
        state: RunState,
        state_store: StateStore,
        audit: AuditLog,
        sandbox: Sandbox,
        handlers: HandlerRegistry,
        specs: Mapping[str, ToolSpec] | None = None,
        auto_approve: bool = False,
        actor_permissions: Mapping[str, frozenset[str]] | None = None,
        repeat_limit: int = 2,
        hooks: GateHooks | None = None,
        cancel_event: threading.Event | None = None,
    ) -> None:
        self.state = state
        self.state_store = state_store
        self.audit = audit
        self.sandbox = sandbox
        self.handlers = handlers
        self.specs: dict[str, ToolSpec] = dict(specs or default_specs())
        self.auto_approve = auto_approve
        self.actor_permissions = dict(
            actor_permissions
            or {
                "model": frozenset({"read", "write", "shell"}),
                "human": frozenset({"read", "write", "shell"}),
                "readonly": frozenset({"read"}),
            }
        )
        self.repeat_limit = repeat_limit
        self.hooks = hooks or GateHooks()
        self.cancel_event = cancel_event

    def bind(self, state: RunState) -> None:
        self.state = state

    # ------------------------------------------------------------------ 主入口

    def invoke(self, call: ToolCall) -> ToolResult:
        state = self.state
        if not call.tool_call_id:
            return self._deny(call, GateRule.INVALID_CALL_ID, "缺少 tool_call_id")
        spec = self.specs.get(call.tool_name)
        if spec is None:
            return self._deny(call, GateRule.TOOL_NOT_FOUND, f"未注册工具：{call.tool_name}")
        if state.has_tool_call(call.tool_call_id):
            return self._deny(
                call,
                GateRule.DUPLICATE_TOOL_CALL_ID,
                f"工具调用 {call.tool_call_id} 已完成登记，禁止重复执行",
            )
        args_error = self._validate_args(spec, call.args)
        if args_error:
            return self._deny(call, GateRule.INVALID_ARGUMENTS, args_error)
        if spec.permission not in self.actor_permissions.get(call.actor, frozenset()):
            return self._deny(
                call,
                GateRule.PERMISSION_DENIED,
                f"actor={call.actor} 无 {spec.permission} 权限",
            )

        fingerprint = action_fingerprint(call.tool_name, call.args)
        if state.action_counts.get(fingerprint, 0) >= self.repeat_limit:
            state.stop(
                StopReason.REPEATED_ACTION,
                f"相同工具和参数已连续执行 {self.repeat_limit} 次",
            )
            self.state_store.save(state)
            self.audit.append(
                run_id=state.run_id,
                tool_call_id=call.tool_call_id,
                tool=call.tool_name,
                phase=AuditPhase.GATE,
                event="STOP",
                rule=GateRule.REPEATED_ACTION,
                decision=AuditDecision.DENY,
                actor="gate",
                detail={"fingerprint": fingerprint},
            )
            return self._deny(
                call,
                GateRule.REPEATED_ACTION,
                "相同工具和参数已出现三次，本次调用未执行",
                persist=False,
            )

        if state.status == RunStatus.WAITING_APPROVAL:
            pending = state.pending_approval
            if call.actor != "human" or (
                pending and call.tool_call_id != pending.tool_call_id
            ):
                return self._deny(
                    call,
                    GateRule.WAITING_APPROVAL,
                    "存在待审批动作，自动推进已暂停",
                )

        plan_step_id = call.plan_step_id or spec.plan_step
        if spec.effect != Effect.READ:
            if not plan_step_id:
                return self._deny(
                    call, GateRule.PLAN_STEP_REQUIRED, "写入/执行动作必须绑定计划步骤"
                )
            step = state.plan.step(plan_step_id) if state.plan.steps else None
            if step is None and state.plan.steps:
                return self._deny(
                    call,
                    GateRule.PLAN_STEP_NOT_READY,
                    f"计划中不存在步骤 {plan_step_id}",
                )
            if step is not None and step.status == StepStatus.SKIPPED:
                return self._deny(
                    call,
                    GateRule.PLAN_STEP_NOT_READY,
                    f"步骤 {plan_step_id} 已跳过",
                )

        # Sandbox 预检：路径真实落点、敏感目录、命令白名单都在 handler 之前。
        verdict = self.sandbox.validate_tool_call(call.tool_name, call.args)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.SANDBOX,
            event="SANDBOX_CHECK",
            rule=verdict.rule,
            decision=(
                AuditDecision.ALLOW if verdict.allowed else AuditDecision.DENY
            ),
            actor="sandbox",
            detail=self._clip_detail(verdict.detail),
        )
        if not verdict.allowed:
            return self._deny(
                call,
                GateRule.SANDBOX_DENIED,
                f"{verdict.rule}: {verdict.detail.get('reason', '越界访问')}",
                detail={"sandboxRule": verdict.rule, "reason": verdict.detail.get("reason", "")},
            )

        # 审批：高风险动作一律需要审批；一次性、绑定工作区摘要与动作指纹。
        if spec.requires_approval or spec.risk == Risk.HIGH:
            approval = state.find_usable_approval(call.tool_call_id, fingerprint)
            live_digest = self.sandbox.workspace_digest()
            if approval is None and self.auto_approve:
                approval = self._create_approval(
                    call,
                    fingerprint=fingerprint,
                    workspace_digest=live_digest,
                    plan_step_id=plan_step_id,
                    actor="auto",
                )
            if approval is None:
                return self._require_approval(
                    call,
                    fingerprint=fingerprint,
                    workspace_digest=live_digest,
                    plan_step_id=plan_step_id,
                )
            if approval.workspace_digest != live_digest:
                approval.stale = True
                self.audit.append(
                    run_id=state.run_id,
                    tool_call_id=call.tool_call_id,
                    tool=call.tool_name,
                    phase=AuditPhase.APPROVAL,
                    event="APPROVAL_STALE",
                    rule=GateRule.STALE_APPROVAL,
                    decision=AuditDecision.DENY,
                    actor="gate",
                    detail={"approvalId": approval.approval_id},
                )
                return self._deny(
                    call,
                    GateRule.STALE_APPROVAL,
                    "工作区已变化，审批失效，需重新确认",
                )
            approval.used = True
            self.audit.append(
                run_id=state.run_id,
                tool_call_id=call.tool_call_id,
                tool=call.tool_name,
                phase=AuditPhase.APPROVAL,
                event="APPROVAL_CONSUMED",
                rule="ONE_TIME_APPROVAL",
                decision=AuditDecision.ALLOW,
                actor="gate",
                detail={"approvalId": approval.approval_id, "by": approval.actor},
            )

        # 放行：先登记「已启动」，中断时才能判定结果不明。
        state.action_counts[fingerprint] = state.action_counts.get(fingerprint, 0) + 1
        state.begin_tool_call(
            ToolCallRecord(
                tool_call_id=call.tool_call_id,
                tool_name=call.tool_name,
                args_digest=args_digest(call.args),
                started_seq=state.next_seq(),
            )
        )
        self.state_store.save(state)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.GATE,
            event="GATE_DECISION",
            rule=GateRule.ALLOW,
            decision=AuditDecision.ALLOW,
            actor="gate",
            detail={
                "requestedBy": call.actor,
                "effect": str(spec.effect),
                "risk": str(spec.risk),
                "planStepId": plan_step_id,
                "fingerprint": fingerprint,
            },
        )
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.EXECUTION,
            event="TOOL_STARTED",
            rule="EXECUTION_BOUNDARY",
            decision=AuditDecision.INFO,
            actor="harness",
            detail={
                "replay": spec.replay,
                "argsDigest": args_digest(call.args),
                "effect": str(spec.effect),
            },
        )

        context = HandlerContext(
            sandbox=self.sandbox,
            verdict=verdict,
            cancel_event=self.cancel_event,
        )
        if self.hooks.before_execute:
            self.hooks.before_execute(call)
        try:
            result = self.handlers.invoke(call, context)
        except Exception as exc:  # handler 的异常也是"结果明确"的失败
            result = ToolResult(
                tool_call_id=call.tool_call_id,
                tool_name=call.tool_name,
                ok=False,
                code=GateRule.EXECUTION_ERROR,
                error=f"{type(exc).__name__}: {exc}",
                rule=GateRule.EXECUTION_ERROR,
                decision=AuditDecision.ERROR,
                executed=True,
            )
        if self.hooks.after_execute:
            # 崩溃点：此处若进程退出/抛异常，TOOL_FINISHED 与状态结果都不会落盘。
            self.hooks.after_execute(call, result)

        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.EXECUTION,
            event="TOOL_FINISHED",
            rule="EXECUTION_BOUNDARY",
            decision=AuditDecision.INFO,
            actor="harness",
            detail={"ok": result.ok, "code": result.code},
        )
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.EXECUTION,
            event="EXECUTION_RESULT",
            rule="RESULT_RECORDED",
            decision=AuditDecision.INFO if result.ok else AuditDecision.ERROR,
            actor="handler",
            detail=self._clip_detail({**result.output, "code": result.code}),
        )
        state.finish_tool_call(call.tool_call_id, ok=result.ok, code=result.code)
        state.budget.tool_calls += 1
        if spec.effect == Effect.WRITE and result.ok:
            state.budget.writes += 1
        self.state_store.save(state)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.STATE,
            event="STATE_UPDATE",
            rule="TOOL_CALL_CLOSED",
            decision=AuditDecision.INFO,
            actor="harness",
            detail={
                "toolCalls": state.budget.tool_calls,
                "writes": state.budget.writes,
                "status": str(state.status),
            },
        )
        return ToolResult(
            tool_call_id=result.tool_call_id,
            tool_name=result.tool_name,
            ok=result.ok,
            code=result.code,
            output=result.output,
            error=result.error,
            rule=result.rule,
            decision=result.decision,
            action_id=result.action_id,
            executed=True,
            evidence=result.evidence,
            metadata=result.metadata,
        )

    # ---------------------------------------------------------------- 审批控制

    def approve(self, action_id: str, actor: str = "human") -> ApprovalRecord:
        state = self.state
        pending = state.pending_approval
        if pending is None or pending.action_id != action_id:
            raise ApprovalError("APPROVAL_NOT_FOUND", f"没有待审批动作：{action_id}")
        live_digest = self.sandbox.workspace_digest()
        if pending.workspace_digest != live_digest:
            raise ApprovalError(
                GateRule.STALE_APPROVAL, "工作区已变化，待审批动作失效"
            )
        approval = ApprovalRecord(
            approval_id=state.new_id("approval"),
            action_id=action_id,
            tool_call_id=pending.tool_call_id,
            tool_name=pending.tool_name,
            fingerprint=pending.fingerprint,
            args_digest=pending.args_digest,
            workspace_digest=pending.workspace_digest,
            plan_step_id=pending.plan_step_id,
            actor=actor,
            seq=state.next_seq(),
        )
        state.approvals.append(approval)
        state.approved_action = {
            "approvalId": approval.approval_id,
            "toolCall": ToolCall(
                tool_call_id=pending.tool_call_id,
                tool_name=pending.tool_name,
                args=pending.args,
                actor="human",
                plan_step_id=pending.plan_step_id,
            ).to_dict(),
        }
        state.pending_approval = None
        state.status = RunStatus.RUNNING
        state.stop_reason = StopReason.NONE
        state.stop_detail = ""
        self.state_store.save(state)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=pending.tool_call_id,
            tool=pending.tool_name,
            phase=AuditPhase.APPROVAL,
            event="APPROVAL_GRANTED",
            rule="ONE_TIME_APPROVAL",
            decision=AuditDecision.ALLOW,
            actor=actor,
            detail={
                "actionId": action_id,
                "approvalId": approval.approval_id,
                "patchHash": pending.patch_hash,
                "workspaceDigest": pending.workspace_digest,
            },
        )
        return approval

    def take_approved_call(self) -> ToolCall | None:
        state = self.state
        if not state.approved_action:
            return None
        payload = dict(state.approved_action)
        state.approved_action = None
        self.state_store.save(state)
        return ToolCall.from_dict(payload["toolCall"])

    def _require_approval(
        self,
        call: ToolCall,
        *,
        fingerprint: str,
        workspace_digest: str,
        plan_step_id: str | None,
    ) -> ToolResult:
        state = self.state
        if state.pending_approval is None:
            digest = args_digest(call.args)
            patch_hash = hashlib.sha256(
                canonical_json(
                    {"args": call.args, "workspaceDigest": workspace_digest}
                ).encode("utf-8")
            ).hexdigest()
            state.pending_approval = PendingApproval(
                action_id=state.new_id("action"),
                tool_call_id=call.tool_call_id,
                tool_name=call.tool_name,
                fingerprint=fingerprint,
                args=dict(call.args),
                args_digest=digest,
                workspace_digest=workspace_digest,
                plan_step_id=plan_step_id,
                patch_hash=patch_hash,
            )
        state.status = RunStatus.WAITING_APPROVAL
        state.stop_reason = StopReason.WAITING_APPROVAL
        state.stop_detail = f"等待审批：{state.pending_approval.action_id}"
        self.state_store.save(state)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.APPROVAL,
            event="APPROVAL_REQUIRED",
            rule="WRITE_REQUIRES_APPROVAL",
            decision=AuditDecision.NEEDS_APPROVAL,
            actor="gate",
            detail={
                "actionId": state.pending_approval.action_id,
                "patchHash": state.pending_approval.patch_hash,
                "workspaceDigest": workspace_digest,
            },
        )
        result = self._deny(
            call,
            GateRule.WAITING_APPROVAL,
            "写操作需要人工审批，本次调用未执行",
            decision=AuditDecision.NEEDS_APPROVAL,
            persist=False,
        )
        return ToolResult(
            tool_call_id=result.tool_call_id,
            tool_name=result.tool_name,
            ok=False,
            code="WAITING_APPROVAL",
            output=result.output,
            error=result.error,
            rule=result.rule,
            decision=result.decision,
            action_id=state.pending_approval.action_id,
        )

    def _create_approval(
        self,
        call: ToolCall,
        *,
        fingerprint: str,
        workspace_digest: str,
        plan_step_id: str | None,
        actor: str,
    ) -> ApprovalRecord:
        state = self.state
        approval = ApprovalRecord(
            approval_id=state.new_id("approval"),
            action_id=state.new_id("action"),
            tool_call_id=call.tool_call_id,
            tool_name=call.tool_name,
            fingerprint=fingerprint,
            args_digest=args_digest(call.args),
            workspace_digest=workspace_digest,
            plan_step_id=plan_step_id,
            actor=actor,
            seq=state.next_seq(),
        )
        state.approvals.append(approval)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.APPROVAL,
            event="APPROVAL_GRANTED",
            rule="AUTO_APPROVAL",
            decision=AuditDecision.ALLOW,
            actor=actor,
            detail={"approvalId": approval.approval_id},
        )
        return approval

    # ------------------------------------------------------------------ 工具函数

    def _deny(
        self,
        call: ToolCall,
        rule: GateRule | str,
        message: str,
        *,
        decision: AuditDecision = AuditDecision.DENY,
        persist: bool = True,
        detail: dict[str, Any] | None = None,
    ) -> ToolResult:
        state = self.state
        state.budget.rejects += 1
        if persist:
            self.state_store.save(state)
        audit_detail: dict[str, Any] = {"reason": message, "requestedBy": call.actor}
        if detail:
            audit_detail.update(detail)
        self.audit.append(
            run_id=state.run_id,
            tool_call_id=call.tool_call_id,
            tool=call.tool_name,
            phase=AuditPhase.GATE,
            event="GATE_DECISION",
            rule=str(rule),
            decision=str(decision),
            actor="gate",
            detail=audit_detail,
        )
        return ToolResult(
            tool_call_id=call.tool_call_id,
            tool_name=call.tool_name,
            ok=False,
            code=str(rule),
            output=dict(detail or {}),
            error=message,
            rule=str(rule),
            decision=str(decision),
        )

    @staticmethod
    def _validate_args(spec: ToolSpec, args: Mapping[str, Any]) -> str | None:
        for name, field_spec in spec.fields.items():
            if field_spec.required and name not in args:
                return f"缺少必填参数：{name}"
        for name, value in args.items():
            field_spec = spec.fields.get(name)
            if field_spec is None:
                return f"未知参数：{name}"
            expected = field_spec.python_type
            types = expected if isinstance(expected, tuple) else (expected,)
            if type(value) not in types:
                return (
                    f"参数 {name} 类型错误：期望 "
                    f"{'/'.join(item.__name__ for item in types)}，实际 {type(value).__name__}"
                )
            if isinstance(value, str) and not value and not field_spec.allow_empty:
                return f"参数 {name} 不能为空"
        if spec.one_of and not any(name in args for name in spec.one_of):
            return f"必须提供以下参数之一：{', '.join(spec.one_of)}"
        return None

    @staticmethod
    def _clip_detail(detail: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in detail.items():
            if isinstance(value, str) and len(value) > 300:
                result[key] = value[:300] + "..."
            else:
                result[key] = value
        return result
